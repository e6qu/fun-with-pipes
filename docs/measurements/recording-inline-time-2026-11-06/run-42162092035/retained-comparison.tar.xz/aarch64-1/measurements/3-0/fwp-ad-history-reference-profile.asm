
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-reference-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <_IO_stdin_used+0x350>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	910020a5 	add	x5, x5, #0x8
    2a20:	b0000044 	adrp	x4, b000 <_IO_stdin_used+0x350>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	91004084 	add	x4, x4, #0x10
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	9400034c 	bl	3780 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	d00000f3 	adrp	x19, 20000 <__data_start>
    2a7c:	91014261 	add	x1, x19, #0x50
    2a80:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a84:	f947ee94 	ldr	x20, [x20, #4056]
    2a88:	f9400282 	ldr	x2, [x20]
    2a8c:	f90043f5 	str	x21, [sp, #128]
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10f40>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9006820 	str	x0, [x1, #208]
    2aac:	94000395 	bl	3900 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2ab4:	91156000 	add	x0, x0, #0x558
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f5 	mov	x21, x0
    2ac8:	35000801 	cbnz	w1, 2bc8 <main+0x168>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	35000900 	cbnz	w0, 2bf8 <main+0x198>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b50009a0 	cbnz	x0, 2c38 <main+0x1d8>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f5 	add	x21, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1503e0 	mov	x0, x21
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007c0 	cbnz	w0, 2c2c <main+0x1cc>
    2b38:	aa1503e0 	mov	x0, x21
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000680 	cbnz	w0, 2c14 <main+0x1b4>
    2b48:	aa1503e1 	mov	x1, x21
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x640>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	9126c042 	add	x2, x2, #0x9b0
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1503e0 	mov	x0, x21
    2b68:	2a0103f5 	mov	w21, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	350004b5 	cbnz	w21, 2c08 <main+0x1a8>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	91014273 	add	x19, x19, #0x50
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943da60 	ldr	w0, [x19, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	540002a1 	b.ne	2c04 <main+0x1a4>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	910003e1 	mov	x1, sp
    2bcc:	52800142 	mov	w2, #0xa                   	// #10
    2bd0:	97ffff4c 	bl	2900 <strtoull@plt>
    2bd4:	f94003e0 	ldr	x0, [sp]
    2bd8:	39400000 	ldrb	w0, [x0]
    2bdc:	35fff780 	cbnz	w0, 2acc <main+0x6c>
    2be0:	394002a0 	ldrb	w0, [x21]
    2be4:	52801fa1 	mov	w1, #0xfd                  	// #253
    2be8:	5100ac00 	sub	w0, w0, #0x2b
    2bec:	6a01001f 	tst	w0, w1
    2bf0:	54fff6e0 	b.eq	2acc <main+0x6c>  // b.none
    2bf4:	17ffffc5 	b	2b08 <main+0xa8>
    2bf8:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2bfc:	9115a000 	add	x0, x0, #0x568
    2c00:	940002e0 	bl	3780 <fwp_trap>
    2c04:	97ffff03 	bl	2810 <__stack_chk_fail@plt>
    2c08:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2c0c:	91182000 	add	x0, x0, #0x608
    2c10:	940002dc 	bl	3780 <fwp_trap>
    2c14:	aa1503e0 	mov	x0, x21
    2c18:	97fffeea 	bl	27c0 <pthread_attr_destroy@plt>
    2c1c:	35000140 	cbnz	w0, 2c44 <main+0x1e4>
    2c20:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2c24:	91178000 	add	x0, x0, #0x5e0
    2c28:	940002d6 	bl	3780 <fwp_trap>
    2c2c:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2c30:	9116c000 	add	x0, x0, #0x5b0
    2c34:	940002d3 	bl	3780 <fwp_trap>
    2c38:	b0000040 	adrp	x0, b000 <_IO_stdin_used+0x350>
    2c3c:	91162000 	add	x0, x0, #0x588
    2c40:	940002d0 	bl	3780 <fwp_trap>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91010000 	add	x0, x0, #0x40
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91010021 	add	x1, x1, #0x40
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91010000 	add	x0, x0, #0x40
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91010021 	add	x1, x1, #0x40
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39410260 	ldrb	w0, [x19, #64]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39010260 	strb	w0, [x19, #64]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	b0000041 	adrp	x1, b000 <_IO_stdin_used+0x350>
    2e34:	91310021 	add	x1, x1, #0xc40
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910140e6 	add	x6, x7, #0x50
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910140e1 	add	x1, x7, #0x50
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9406c84 	ldr	x4, [x4, #216]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9406c63 	ldr	x3, [x3, #216]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407000 	ldr	x0, [x0, #224]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91014043 	add	x3, x2, #0x50
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91014042 	add	x2, x2, #0x50
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x350>
    30d8:	91308021 	add	x1, x1, #0xc20
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3110:	9132e000 	add	x0, x0, #0xcb8
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    3144:	9118c2a1 	add	x1, x21, #0x630
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3158:	912880a5 	add	x5, x5, #0xa20
    315c:	9118c2a1 	add	x1, x21, #0x630
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	9118c2b7 	add	x23, x21, #0x630
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	9118c2b5 	add	x21, x21, #0x630
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	9118c2b5 	add	x21, x21, #0x630
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    32e8:	912860a5 	add	x5, x5, #0xa18
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x650>
    331c:	91334042 	add	x2, x2, #0xcd0
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91014315 	add	x21, x24, #0x50
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x650>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	9134a042 	add	x2, x2, #0xd28
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	f0000039 	adrp	x25, a000 <fwp_main_thread+0x650>
    33a8:	f000003a 	adrp	x26, a000 <fwp_main_thread+0x650>
    33ac:	91362339 	add	x25, x25, #0xd88
    33b0:	9133c35a 	add	x26, x26, #0xcf0
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	f000003b 	adrp	x27, a000 <fwp_main_thread+0x650>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	9133e377 	add	x23, x27, #0xcf8
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	91372000 	add	x0, x0, #0xdc8
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    347c:	f0000023 	adrp	x3, a000 <fwp_main_thread+0x650>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	f0000035 	adrp	x21, a000 <fwp_main_thread+0x650>
    3488:	f9422824 	ldr	x4, [x1, #1104]
    348c:	91014318 	add	x24, x24, #0x50
    3490:	f9422ca5 	ldr	x5, [x5, #1112]
    3494:	91114033 	add	x19, x1, #0x450
    3498:	f9423046 	ldr	x6, [x2, #1120]
    349c:	9133c063 	add	x3, x3, #0xcf0
    34a0:	913782b5 	add	x21, x21, #0xde0
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	91388000 	add	x0, x0, #0xe20
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    352c:	91340000 	add	x0, x0, #0xd00
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    35ec:	9132e000 	add	x0, x0, #0xcb8
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91014022 	add	x2, x1, #0x50
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91014021 	add	x1, x1, #0x50
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x650>
    3730:	aa1303e0 	mov	x0, x19
    3734:	9138a021 	add	x1, x1, #0xe28
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x650>
    3744:	aa1303e0 	mov	x0, x19
    3748:	9138c021 	add	x1, x1, #0xe30
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x650>
    3760:	9138e021 	add	x1, x1, #0xe38
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_trap>:
    3780:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3784:	d53bd041 	mrs	x1, tpidr_el0
    3788:	91400021 	add	x1, x1, #0x0, lsl #12
    378c:	91004021 	add	x1, x1, #0x10
    3790:	910003fd 	mov	x29, sp
    3794:	a90153f3 	stp	x19, x20, [sp, #16]
    3798:	aa0003f3 	mov	x19, x0
    379c:	900000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    37a0:	f947ea94 	ldr	x20, [x20, #4048]
    37a4:	f90013f5 	str	x21, [sp, #32]
    37a8:	f9400035 	ldr	x21, [x1]
    37ac:	97fffe12 	bl	2ff4 <fwp_flush>
    37b0:	f9400280 	ldr	x0, [x20]
    37b4:	f0000022 	adrp	x2, a000 <fwp_main_thread+0x650>
    37b8:	aa1303e3 	mov	x3, x19
    37bc:	91390042 	add	x2, x2, #0xe40
    37c0:	52800041 	mov	w1, #0x2                   	// #2
    37c4:	97fffc2f 	bl	2880 <__fprintf_chk@plt>
    37c8:	b40000b5 	cbz	x21, 37dc <fwp_trap+0x5c>
    37cc:	f9400280 	ldr	x0, [x20]
    37d0:	97fffc5c 	bl	2940 <fflush@plt>
    37d4:	52800ca0 	mov	w0, #0x65                  	// #101
    37d8:	97fffc6a 	bl	2980 <_Exit@plt>
    37dc:	52800ca0 	mov	w0, #0x65                  	// #101
    37e0:	97fffbb8 	bl	26c0 <exit@plt>

00000000000037e4 <fwp_closure_drop_push>:
    37e4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    37e8:	910003fd 	mov	x29, sp
    37ec:	a90153f3 	stp	x19, x20, [sp, #16]
    37f0:	aa0003f3 	mov	x19, x0
    37f4:	a9408014 	ldp	x20, x0, [x0, #8]
    37f8:	a9025bf5 	stp	x21, x22, [sp, #32]
    37fc:	aa0103f5 	mov	x21, x1
    3800:	a90363f7 	stp	x23, x24, [sp, #48]
    3804:	eb00029f 	cmp	x20, x0
    3808:	54000160 	b.eq	3834 <fwp_closure_drop_push+0x50>  // b.none
    380c:	f9400276 	ldr	x22, [x19]
    3810:	d37df297 	lsl	x23, x20, #3
    3814:	91000694 	add	x20, x20, #0x1
    3818:	f9000674 	str	x20, [x19, #8]
    381c:	a94153f3 	ldp	x19, x20, [sp, #16]
    3820:	f8376ad5 	str	x21, [x22, x23]
    3824:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3828:	a94363f7 	ldp	x23, x24, [sp, #48]
    382c:	a8c57bfd 	ldp	x29, x30, [sp], #80
    3830:	d65f03c0 	ret
    3834:	a9046bf9 	stp	x25, x26, [sp, #64]
    3838:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    383c:	eb00029f 	cmp	x20, x0
    3840:	54000568 	b.hi	38ec <fwp_closure_drop_push+0x108>  // b.pmore
    3844:	d37cee99 	lsl	x25, x20, #4
    3848:	d37ffa9a 	lsl	x26, x20, #1
    384c:	aa1903e0 	mov	x0, x25
    3850:	97fffbd8 	bl	27b0 <malloc@plt>
    3854:	aa0003f6 	mov	x22, x0
    3858:	b4000320 	cbz	x0, 38bc <fwp_closure_drop_push+0xd8>
    385c:	aa1303f8 	mov	x24, x19
    3860:	aa1903e3 	mov	x3, x25
    3864:	d37df297 	lsl	x23, x20, #3
    3868:	aa1703e2 	mov	x2, x23
    386c:	f8418719 	ldr	x25, [x24], #24
    3870:	aa1903e1 	mov	x1, x25
    3874:	97fffbbb 	bl	2760 <__memcpy_chk@plt>
    3878:	eb18033f 	cmp	x25, x24
    387c:	540000a0 	b.eq	3890 <fwp_closure_drop_push+0xac>  // b.none
    3880:	aa1903e0 	mov	x0, x25
    3884:	97fffc13 	bl	28d0 <free@plt>
    3888:	f9400674 	ldr	x20, [x19, #8]
    388c:	d37df297 	lsl	x23, x20, #3
    3890:	91000694 	add	x20, x20, #0x1
    3894:	f9000276 	str	x22, [x19]
    3898:	f9000a7a 	str	x26, [x19, #16]
    389c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    38a0:	f9000674 	str	x20, [x19, #8]
    38a4:	f8376ad5 	str	x21, [x22, x23]
    38a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    38ac:	a9425bf5 	ldp	x21, x22, [sp, #32]
    38b0:	a94363f7 	ldp	x23, x24, [sp, #48]
    38b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    38b8:	d65f03c0 	ret
    38bc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    38c0:	f947e863 	ldr	x3, [x3, #4048]
    38c4:	d2800262 	mov	x2, #0x13                  	// #19
    38c8:	d2800021 	mov	x1, #0x1                   	// #1
    38cc:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    38d0:	9132e000 	add	x0, x0, #0xcb8
    38d4:	f9400063 	ldr	x3, [x3]
    38d8:	97fffc0e 	bl	2910 <fwrite@plt>
    38dc:	d2800000 	mov	x0, #0x0                   	// #0
    38e0:	97fffc18 	bl	2940 <fflush@plt>
    38e4:	52800cc0 	mov	w0, #0x66                  	// #102
    38e8:	97fffc26 	bl	2980 <_Exit@plt>
    38ec:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    38f0:	91394000 	add	x0, x0, #0xe50
    38f4:	97ffffa3 	bl	3780 <fwp_trap>
    38f8:	d503201f 	nop
    38fc:	d503201f 	nop

0000000000003900 <fwp_now_ns>:
    3900:	d100c3ff 	sub	sp, sp, #0x30
    3904:	52800020 	mov	w0, #0x1                   	// #1
    3908:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    390c:	f947f442 	ldr	x2, [x2, #4072]
    3910:	910023e1 	add	x1, sp, #0x8
    3914:	a9027bfd 	stp	x29, x30, [sp, #32]
    3918:	910083fd 	add	x29, sp, #0x20
    391c:	f9400043 	ldr	x3, [x2]
    3920:	f9000fe3 	str	x3, [sp, #24]
    3924:	d2800003 	mov	x3, #0x0                   	// #0
    3928:	97fffb86 	bl	2740 <clock_gettime@plt>
    392c:	350002c0 	cbnz	w0, 3984 <fwp_now_ns+0x84>
    3930:	a9408be1 	ldp	x1, x2, [sp, #8]
    3934:	d2994003 	mov	x3, #0xca00                	// #51712
    3938:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    393c:	9b037c20 	mul	x0, x1, x3
    3940:	9b437c21 	smulh	x1, x1, x3
    3944:	ab020000 	adds	x0, x0, x2
    3948:	937ffc42 	asr	x2, x2, #63
    394c:	9a020021 	adc	x1, x1, x2
    3950:	f100001f 	cmp	x0, #0x0
    3954:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    3958:	b50001e1 	cbnz	x1, 3994 <fwp_now_ns+0x94>
    395c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3960:	f947f421 	ldr	x1, [x1, #4072]
    3964:	f9400fe3 	ldr	x3, [sp, #24]
    3968:	f9400022 	ldr	x2, [x1]
    396c:	eb020063 	subs	x3, x3, x2
    3970:	d2800002 	mov	x2, #0x0                   	// #0
    3974:	540000e1 	b.ne	3990 <fwp_now_ns+0x90>  // b.any
    3978:	a9427bfd 	ldp	x29, x30, [sp, #32]
    397c:	9100c3ff 	add	sp, sp, #0x30
    3980:	d65f03c0 	ret
    3984:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3988:	9139c000 	add	x0, x0, #0xe70
    398c:	97ffff7d 	bl	3780 <fwp_trap>
    3990:	97fffba0 	bl	2810 <__stack_chk_fail@plt>
    3994:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3998:	913a4000 	add	x0, x0, #0xe90
    399c:	97ffff79 	bl	3780 <fwp_trap>

00000000000039a0 <fwp_closure_drop.part.0>:
    39a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    39a4:	90000041 	adrp	x1, b000 <_IO_stdin_used+0x350>
    39a8:	910003fd 	mov	x29, sp
    39ac:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    39b0:	f947f463 	ldr	x3, [x3, #4072]
    39b4:	a90153f3 	stp	x19, x20, [sp, #16]
    39b8:	d10883ff 	sub	sp, sp, #0x220
    39bc:	910003e2 	mov	x2, sp
    39c0:	d53bd053 	mrs	x19, tpidr_el0
    39c4:	910063f4 	add	x20, sp, #0x18
    39c8:	3dc31420 	ldr	q0, [x1, #3152]
    39cc:	91400264 	add	x4, x19, #0x0, lsl #12
    39d0:	91004084 	add	x4, x4, #0x10
    39d4:	aa0003e1 	mov	x1, x0
    39d8:	aa0203e0 	mov	x0, x2
    39dc:	f9400062 	ldr	x2, [x3]
    39e0:	f9010fe2 	str	x2, [sp, #536]
    39e4:	d2800002 	mov	x2, #0x0                   	// #0
    39e8:	f90003f4 	str	x20, [sp]
    39ec:	f9000080 	str	x0, [x4]
    39f0:	3c8083e0 	stur	q0, [sp, #8]
    39f4:	97ffff7c 	bl	37e4 <fwp_closure_drop_push>
    39f8:	f94007e0 	ldr	x0, [sp, #8]
    39fc:	b4000280 	cbz	x0, 3a4c <fwp_closure_drop.part.0+0xac>
    3a00:	f90123f5 	str	x21, [sp, #576]
    3a04:	b00000f5 	adrp	x21, 20000 <__data_start>
    3a08:	910142b5 	add	x21, x21, #0x50
    3a0c:	d503201f 	nop
    3a10:	f94003e1 	ldr	x1, [sp]
    3a14:	d1000400 	sub	x0, x0, #0x1
    3a18:	f90007e0 	str	x0, [sp, #8]
    3a1c:	f9406aa2 	ldr	x2, [x21, #208]
    3a20:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    3a24:	b9400001 	ldr	w1, [x0]
    3a28:	8b011441 	add	x1, x2, x1, lsl #5
    3a2c:	f9400c21 	ldr	x1, [x1, #24]
    3a30:	b4000321 	cbz	x1, 3a94 <fwp_closure_drop.part.0+0xf4>
    3a34:	f9400422 	ldr	x2, [x1, #8]
    3a38:	52800001 	mov	w1, #0x0                   	// #0
    3a3c:	d63f0040 	blr	x2
    3a40:	f94007e0 	ldr	x0, [sp, #8]
    3a44:	b5fffe60 	cbnz	x0, 3a10 <fwp_closure_drop.part.0+0x70>
    3a48:	f94123f5 	ldr	x21, [sp, #576]
    3a4c:	91400273 	add	x19, x19, #0x0, lsl #12
    3a50:	91004273 	add	x19, x19, #0x10
    3a54:	f94003e0 	ldr	x0, [sp]
    3a58:	f900027f 	str	xzr, [x19]
    3a5c:	eb14001f 	cmp	x0, x20
    3a60:	54000040 	b.eq	3a68 <fwp_closure_drop.part.0+0xc8>  // b.none
    3a64:	97fffb9b 	bl	28d0 <free@plt>
    3a68:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3a6c:	f947f400 	ldr	x0, [x0, #4072]
    3a70:	f9410fe2 	ldr	x2, [sp, #536]
    3a74:	f9400001 	ldr	x1, [x0]
    3a78:	eb010042 	subs	x2, x2, x1
    3a7c:	d2800001 	mov	x1, #0x0                   	// #0
    3a80:	54000101 	b.ne	3aa0 <fwp_closure_drop.part.0+0x100>  // b.any
    3a84:	910883ff 	add	sp, sp, #0x220
    3a88:	a94153f3 	ldp	x19, x20, [sp, #16]
    3a8c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3a90:	d65f03c0 	ret
    3a94:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3a98:	913ae000 	add	x0, x0, #0xeb8
    3a9c:	97ffff39 	bl	3780 <fwp_trap>
    3aa0:	f90123f5 	str	x21, [sp, #576]
    3aa4:	97fffb5b 	bl	2810 <__stack_chk_fail@plt>
    3aa8:	d503201f 	nop
    3aac:	d503201f 	nop

0000000000003ab0 <fwp_tape_of>:
    3ab0:	92403c02 	and	x2, x0, #0xffff
    3ab4:	b4000262 	cbz	x2, 3b00 <fwp_tape_of+0x50>
    3ab8:	b00000e3 	adrp	x3, 20000 <__data_start>
    3abc:	91014063 	add	x3, x3, #0x50
    3ac0:	9350fc01 	asr	x1, x0, #16
    3ac4:	d1000440 	sub	x0, x2, #0x1
    3ac8:	f9406c62 	ldr	x2, [x3, #216]
    3acc:	eb00005f 	cmp	x2, x0
    3ad0:	5400018d 	b.le	3b00 <fwp_tape_of+0x50>
    3ad4:	8b000402 	add	x2, x0, x0, lsl #1
    3ad8:	f9404463 	ldr	x3, [x3, #136]
    3adc:	8b020802 	add	x2, x0, x2, lsl #2
    3ae0:	d37df042 	lsl	x2, x2, #3
    3ae4:	8b020060 	add	x0, x3, x2
    3ae8:	b9400404 	ldr	w4, [x0, #4]
    3aec:	340000a4 	cbz	w4, 3b00 <fwp_tape_of+0x50>
    3af0:	b8626862 	ldr	w2, [x3, x2]
    3af4:	6b01005f 	cmp	w2, w1
    3af8:	54000041 	b.ne	3b00 <fwp_tape_of+0x50>  // b.any
    3afc:	d65f03c0 	ret
    3b00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3b04:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3b08:	913ba000 	add	x0, x0, #0xee8
    3b0c:	910003fd 	mov	x29, sp
    3b10:	97ffff1c 	bl	3780 <fwp_trap>

0000000000003b14 <fwp_format_g.constprop.0>:
    3b14:	d10483ff 	sub	sp, sp, #0x120
    3b18:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x650>
    3b1c:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    3b20:	f947f442 	ldr	x2, [x2, #4072]
    3b24:	913ce084 	add	x4, x4, #0xf38
    3b28:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3b2c:	9102c3fd 	add	x29, sp, #0xb0
    3b30:	d2800803 	mov	x3, #0x40                  	// #64
    3b34:	a90e63f7 	stp	x23, x24, [sp, #224]
    3b38:	93407c38 	sxtw	x24, w1
    3b3c:	aa0303e1 	mov	x1, x3
    3b40:	fd008be8 	str	d8, [sp, #272]
    3b44:	1e604008 	fmov	d8, d0
    3b48:	a90c53f3 	stp	x19, x20, [sp, #192]
    3b4c:	910083f4 	add	x20, sp, #0x20
    3b50:	a90d5bf5 	stp	x21, x22, [sp, #208]
    3b54:	aa0003f5 	mov	x21, x0
    3b58:	a91073fb 	stp	x27, x28, [sp, #256]
    3b5c:	5100071c 	sub	w28, w24, #0x1
    3b60:	2a1c03e5 	mov	w5, w28
    3b64:	f9400040 	ldr	x0, [x2]
    3b68:	f90057e0 	str	x0, [sp, #168]
    3b6c:	d2800000 	mov	x0, #0x0                   	// #0
    3b70:	52800042 	mov	w2, #0x2                   	// #2
    3b74:	aa1403e0 	mov	x0, x20
    3b78:	97fffb02 	bl	2780 <__snprintf_chk@plt>
    3b7c:	52800ca1 	mov	w1, #0x65                  	// #101
    3b80:	aa1403e0 	mov	x0, x20
    3b84:	97fffb5b 	bl	28f0 <strchr@plt>
    3b88:	aa0003f3 	mov	x19, x0
    3b8c:	52800142 	mov	w2, #0xa                   	// #10
    3b90:	91000400 	add	x0, x0, #0x1
    3b94:	d2800001 	mov	x1, #0x0                   	// #0
    3b98:	97fffb46 	bl	28b0 <strtol@plt>
    3b9c:	aa0003f7 	mov	x23, x0
    3ba0:	11001400 	add	w0, w0, #0x5
    3ba4:	7100541f 	cmp	w0, #0x15
    3ba8:	54000d88 	b.hi	3d58 <fwp_format_g.constprop.0+0x244>  // b.pmore
    3bac:	4b170385 	sub	w5, w28, w23
    3bb0:	710000bf 	cmp	w5, #0x0
    3bb4:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3bb8:	54000ba0 	b.eq	3d2c <fwp_format_g.constprop.0+0x218>  // b.none
    3bbc:	394083e0 	ldrb	w0, [sp, #32]
    3bc0:	cb180273 	sub	x19, x19, x24
    3bc4:	91000673 	add	x19, x19, #0x1
    3bc8:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3bcc:	7100b41f 	cmp	w0, #0x2d
    3bd0:	9a941681 	cinc	x1, x20, eq	// eq = none
    3bd4:	1a9f17e4 	cset	w4, eq	// eq = none
    3bd8:	cb010266 	sub	x6, x19, x1
    3bdc:	d10004da 	sub	x26, x6, #0x1
    3be0:	540018c0 	b.eq	3ef8 <fwp_format_g.constprop.0+0x3e4>  // b.none
    3be4:	910183f9 	add	x25, sp, #0x60
    3be8:	d280091b 	mov	x27, #0x48                  	// #72
    3bec:	aa1903e7 	mov	x7, x25
    3bf0:	91000423 	add	x3, x1, #0x1
    3bf4:	91011cc6 	add	x6, x6, #0x47
    3bf8:	910004f6 	add	x22, x7, #0x1
    3bfc:	37f81017 	tbnz	w23, #31, 3dfc <fwp_format_g.constprop.0+0x2e8>
    3c00:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3c04:	93407ef7 	sxtw	x23, w23
    3c08:	390000e4 	strb	w4, [x7]
    3c0c:	aa1303e1 	mov	x1, x19
    3c10:	aa1703e2 	mov	x2, x23
    3c14:	aa1603e0 	mov	x0, x22
    3c18:	b9000be5 	str	w5, [sp, #8]
    3c1c:	cb170374 	sub	x20, x27, x23
    3c20:	a9011be3 	stp	x3, x6, [sp, #16]
    3c24:	97fffa8f 	bl	2660 <memcpy@plt>
    3c28:	d1000694 	sub	x20, x20, #0x1
    3c2c:	f9400be3 	ldr	x3, [sp, #16]
    3c30:	8b1702d6 	add	x22, x22, x23
    3c34:	aa1603e0 	mov	x0, x22
    3c38:	aa1a03e2 	mov	x2, x26
    3c3c:	aa0303e1 	mov	x1, x3
    3c40:	aa1403e3 	mov	x3, x20
    3c44:	97fffac7 	bl	2760 <__memcpy_chk@plt>
    3c48:	8b1a02d6 	add	x22, x22, x26
    3c4c:	f9400fe6 	ldr	x6, [sp, #24]
    3c50:	d2800900 	mov	x0, #0x48                  	// #72
    3c54:	b9400be5 	ldr	w5, [sp, #8]
    3c58:	8b170261 	add	x1, x19, x23
    3c5c:	cb1400c3 	sub	x3, x6, x20
    3c60:	cb060294 	sub	x20, x20, x6
    3c64:	f101207f 	cmp	x3, #0x48
    3c68:	93407cb8 	sxtw	x24, w5
    3c6c:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3c70:	aa1803e2 	mov	x2, x24
    3c74:	8b1802d3 	add	x19, x22, x24
    3c78:	8b140063 	add	x3, x3, x20
    3c7c:	aa1603e0 	mov	x0, x22
    3c80:	97fffab8 	bl	2760 <__memcpy_chk@plt>
    3c84:	cb190273 	sub	x19, x19, x25
    3c88:	d28031e0 	mov	x0, #0x18f                 	// #399
    3c8c:	eb00027f 	cmp	x19, x0
    3c90:	aa1903e1 	mov	x1, x25
    3c94:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3c98:	aa1503e0 	mov	x0, x21
    3c9c:	aa1303e2 	mov	x2, x19
    3ca0:	97fffa70 	bl	2660 <memcpy@plt>
    3ca4:	38336abf 	strb	wzr, [x21, x19]
    3ca8:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3cac:	aa1503e0 	mov	x0, x21
    3cb0:	97fffa7c 	bl	26a0 <strlen@plt>
    3cb4:	aa0003f3 	mov	x19, x0
    3cb8:	528005c1 	mov	w1, #0x2e                  	// #46
    3cbc:	aa1503e0 	mov	x0, x21
    3cc0:	97fffb0c 	bl	28f0 <strchr@plt>
    3cc4:	b4000160 	cbz	x0, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3cc8:	b4000153 	cbz	x19, 3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ccc:	d503201f 	nop
    3cd0:	aa1303e1 	mov	x1, x19
    3cd4:	d1000673 	sub	x19, x19, #0x1
    3cd8:	38736aa0 	ldrb	w0, [x21, x19]
    3cdc:	7100c01f 	cmp	w0, #0x30
    3ce0:	54001001 	b.ne	3ee0 <fwp_format_g.constprop.0+0x3cc>  // b.any
    3ce4:	38336abf 	strb	wzr, [x21, x19]
    3ce8:	b5ffff53 	cbnz	x19, 3cd0 <fwp_format_g.constprop.0+0x1bc>
    3cec:	d503201f 	nop
    3cf0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3cf4:	f947f400 	ldr	x0, [x0, #4072]
    3cf8:	f94057e2 	ldr	x2, [sp, #168]
    3cfc:	f9400001 	ldr	x1, [x0]
    3d00:	eb010042 	subs	x2, x2, x1
    3d04:	d2800001 	mov	x1, #0x0                   	// #0
    3d08:	54001061 	b.ne	3f14 <fwp_format_g.constprop.0+0x400>  // b.any
    3d0c:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3d10:	a94c53f3 	ldp	x19, x20, [sp, #192]
    3d14:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3d18:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3d1c:	a95073fb 	ldp	x27, x28, [sp, #256]
    3d20:	fd408be8 	ldr	d8, [sp, #272]
    3d24:	910483ff 	add	sp, sp, #0x120
    3d28:	d65f03c0 	ret
    3d2c:	1e604100 	fmov	d0, d8
    3d30:	710000bf 	cmp	w5, #0x0
    3d34:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    3d38:	aa1503e0 	mov	x0, x21
    3d3c:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x650>
    3d40:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3d44:	913d4084 	add	x4, x4, #0xf50
    3d48:	52800042 	mov	w2, #0x2                   	// #2
    3d4c:	d2803201 	mov	x1, #0x190                 	// #400
    3d50:	97fffa8c 	bl	2780 <__snprintf_chk@plt>
    3d54:	17ffffd6 	b	3cac <fwp_format_g.constprop.0+0x198>
    3d58:	cb140273 	sub	x19, x19, x20
    3d5c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3d60:	910183f9 	add	x25, sp, #0x60
    3d64:	aa1303e2 	mov	x2, x19
    3d68:	aa1403e1 	mov	x1, x20
    3d6c:	aa1903e0 	mov	x0, x25
    3d70:	d2800803 	mov	x3, #0x40                  	// #64
    3d74:	97fffa7b 	bl	2760 <__memcpy_chk@plt>
    3d78:	38336b3f 	strb	wzr, [x25, x19]
    3d7c:	aa1903e0 	mov	x0, x25
    3d80:	528005c1 	mov	w1, #0x2e                  	// #46
    3d84:	97fffadb 	bl	28f0 <strchr@plt>
    3d88:	b40001c0 	cbz	x0, 3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d8c:	b50000b3 	cbnz	x19, 3da0 <fwp_format_g.constprop.0+0x28c>
    3d90:	1400000c 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3d94:	381ff01f 	sturb	wzr, [x0, #-1]
    3d98:	f1000673 	subs	x19, x19, #0x1
    3d9c:	54000120 	b.eq	3dc0 <fwp_format_g.constprop.0+0x2ac>  // b.none
    3da0:	8b130320 	add	x0, x25, x19
    3da4:	385ff001 	ldurb	w1, [x0, #-1]
    3da8:	7100c03f 	cmp	w1, #0x30
    3dac:	54ffff40 	b.eq	3d94 <fwp_format_g.constprop.0+0x280>  // b.none
    3db0:	d1000673 	sub	x19, x19, #0x1
    3db4:	38736b20 	ldrb	w0, [x25, x19]
    3db8:	7100b81f 	cmp	w0, #0x2e
    3dbc:	54000a80 	b.eq	3f0c <fwp_format_g.constprop.0+0x3f8>  // b.none
    3dc0:	710002ff 	cmp	w23, #0x0
    3dc4:	528005a1 	mov	w1, #0x2d                  	// #45
    3dc8:	aa1903e5 	mov	x5, x25
    3dcc:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3dd0:	aa1503e0 	mov	x0, x21
    3dd4:	52800566 	mov	w6, #0x2b                  	// #43
    3dd8:	f0000024 	adrp	x4, a000 <fwp_main_thread+0x650>
    3ddc:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3de0:	913d0084 	add	x4, x4, #0xf40
    3de4:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3de8:	52800042 	mov	w2, #0x2                   	// #2
    3dec:	d2803201 	mov	x1, #0x190                 	// #400
    3df0:	97fffa64 	bl	2780 <__snprintf_chk@plt>
    3df4:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3df8:	17ffffbe 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3dfc:	52800605 	mov	w5, #0x30                  	// #48
    3e00:	390000e5 	strb	w5, [x7]
    3e04:	d100077b 	sub	x27, x27, #0x1
    3e08:	aa0303e1 	mov	x1, x3
    3e0c:	aa1603e0 	mov	x0, x22
    3e10:	aa1b03e3 	mov	x3, x27
    3e14:	aa1a03e2 	mov	x2, x26
    3e18:	f90007e6 	str	x6, [sp, #8]
    3e1c:	b90013e4 	str	w4, [sp, #16]
    3e20:	8b1a02d6 	add	x22, x22, x26
    3e24:	b9001be5 	str	w5, [sp, #24]
    3e28:	97fffa4e 	bl	2760 <__memcpy_chk@plt>
    3e2c:	f94007e6 	ldr	x6, [sp, #8]
    3e30:	2a3703e7 	mvn	w7, w23
    3e34:	b94013e4 	ldr	w4, [sp, #16]
    3e38:	cb1b00c1 	sub	x1, x6, x27
    3e3c:	cb06037b 	sub	x27, x27, x6
    3e40:	f101203f 	cmp	x1, #0x48
    3e44:	d2800906 	mov	x6, #0x48                  	// #72
    3e48:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3e4c:	8b1b0023 	add	x3, x1, x27
    3e50:	310006ff 	cmn	w23, #0x1
    3e54:	54000220 	b.eq	3e98 <fwp_format_g.constprop.0+0x384>  // b.none
    3e58:	b9401be5 	ldr	w5, [sp, #24]
    3e5c:	d2800001 	mov	x1, #0x0                   	// #0
    3e60:	f101207f 	cmp	x3, #0x48
    3e64:	d1000462 	sub	x2, x3, #0x1
    3e68:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3e6c:	38216ac5 	strb	w5, [x22, x1]
    3e70:	cb030003 	sub	x3, x0, x3
    3e74:	91000421 	add	x1, x1, #0x1
    3e78:	91000463 	add	x3, x3, #0x1
    3e7c:	eb00007f 	cmp	x3, x0
    3e80:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3e84:	cb000063 	sub	x3, x3, x0
    3e88:	8b020063 	add	x3, x3, x2
    3e8c:	6b0100ff 	cmp	w7, w1
    3e90:	54fffe8c 	b.gt	3e60 <fwp_format_g.constprop.0+0x34c>
    3e94:	8b2742d6 	add	x22, x22, w7, uxtw
    3e98:	f101207f 	cmp	x3, #0x48
    3e9c:	d2800905 	mov	x5, #0x48                  	// #72
    3ea0:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3ea4:	aa1603e0 	mov	x0, x22
    3ea8:	cb0300a1 	sub	x1, x5, x3
    3eac:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3eb0:	91000421 	add	x1, x1, #0x1
    3eb4:	d1000463 	sub	x3, x3, #0x1
    3eb8:	eb05003f 	cmp	x1, x5
    3ebc:	38001402 	strb	w2, [x0], #1
    3ec0:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3ec4:	93407f82 	sxtw	x2, w28
    3ec8:	cb050025 	sub	x5, x1, x5
    3ecc:	aa1303e1 	mov	x1, x19
    3ed0:	8b0300a3 	add	x3, x5, x3
    3ed4:	8b1802d3 	add	x19, x22, x24
    3ed8:	97fffa22 	bl	2760 <__memcpy_chk@plt>
    3edc:	17ffff6a 	b	3c84 <fwp_format_g.constprop.0+0x170>
    3ee0:	d1000421 	sub	x1, x1, #0x1
    3ee4:	38616aa0 	ldrb	w0, [x21, x1]
    3ee8:	7100b81f 	cmp	w0, #0x2e
    3eec:	54fff021 	b.ne	3cf0 <fwp_format_g.constprop.0+0x1dc>  // b.any
    3ef0:	38216abf 	strb	wzr, [x21, x1]
    3ef4:	17ffff7f 	b	3cf0 <fwp_format_g.constprop.0+0x1dc>
    3ef8:	910187e7 	add	x7, sp, #0x61
    3efc:	910183f9 	add	x25, sp, #0x60
    3f00:	d28008fb 	mov	x27, #0x47                  	// #71
    3f04:	390183e0 	strb	w0, [sp, #96]
    3f08:	17ffff3a 	b	3bf0 <fwp_format_g.constprop.0+0xdc>
    3f0c:	38336b3f 	strb	wzr, [x25, x19]
    3f10:	17ffffac 	b	3dc0 <fwp_format_g.constprop.0+0x2ac>
    3f14:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3f18:	97fffa3e 	bl	2810 <__stack_chk_fail@plt>
    3f1c:	d503201f 	nop

0000000000003f20 <fwp_heap_report>:
    3f20:	d105c3ff 	sub	sp, sp, #0x170
    3f24:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3f28:	9118c042 	add	x2, x2, #0x630
    3f2c:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3f30:	f947e821 	ldr	x1, [x1, #4048]
    3f34:	a9117bfd 	stp	x29, x30, [sp, #272]
    3f38:	910443fd 	add	x29, sp, #0x110
    3f3c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3f40:	f947f400 	ldr	x0, [x0, #4072]
    3f44:	a9135bf5 	stp	x21, x22, [sp, #304]
    3f48:	a91463f7 	stp	x23, x24, [sp, #320]
    3f4c:	a9156bf9 	stp	x25, x26, [sp, #336]
    3f50:	6d1627e8 	stp	d8, d9, [sp, #352]
    3f54:	fd4a1c48 	ldr	d8, [x2, #5176]
    3f58:	fd4a2049 	ldr	d9, [x2, #5184]
    3f5c:	f9400036 	ldr	x22, [x1]
    3f60:	f9400001 	ldr	x1, [x0]
    3f64:	f90087e1 	str	x1, [sp, #264]
    3f68:	d2800001 	mov	x1, #0x0                   	// #0
    3f6c:	f949e459 	ldr	x25, [x2, #5064]
    3f70:	f0000021 	adrp	x1, a000 <fwp_main_thread+0x650>
    3f74:	f94a1057 	ldr	x23, [x2, #5152]
    3f78:	f0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    3f7c:	f94a1458 	ldr	x24, [x2, #5160]
    3f80:	913d6021 	add	x1, x1, #0xf58
    3f84:	913d8000 	add	x0, x0, #0xf60
    3f88:	97fffa06 	bl	27a0 <fopen@plt>
    3f8c:	b4000740 	cbz	x0, 4074 <fwp_heap_report+0x154>
    3f90:	528daad5 	mov	w21, #0x6d56                	// #27990
    3f94:	a91253f3 	stp	x19, x20, [sp, #288]
    3f98:	aa0003f4 	mov	x20, x0
    3f9c:	910023f3 	add	x19, sp, #0x8
    3fa0:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3fa4:	72aae915 	movk	w21, #0x5748, lsl #16
    3fa8:	aa1403e2 	mov	x2, x20
    3fac:	aa1303e0 	mov	x0, x19
    3fb0:	52802001 	mov	w1, #0x100                 	// #256
    3fb4:	97fffa83 	bl	29c0 <fgets@plt>
    3fb8:	b4000280 	cbz	x0, 4008 <fwp_heap_report+0xe8>
    3fbc:	b9400261 	ldr	w1, [x19]
    3fc0:	6b15003f 	cmp	w1, w21
    3fc4:	54ffff21 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fc8:	39401260 	ldrb	w0, [x19, #4]
    3fcc:	7101341f 	cmp	w0, #0x4d
    3fd0:	54fffec1 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fd4:	394037e0 	ldrb	w0, [sp, #13]
    3fd8:	7100e81f 	cmp	w0, #0x3a
    3fdc:	54fffe61 	b.ne	3fa8 <fwp_heap_report+0x88>  // b.any
    3fe0:	52800142 	mov	w2, #0xa                   	// #10
    3fe4:	d2800001 	mov	x1, #0x0                   	// #0
    3fe8:	91003be0 	add	x0, sp, #0xe
    3fec:	97fffa31 	bl	28b0 <strtol@plt>
    3ff0:	aa1403e2 	mov	x2, x20
    3ff4:	aa0003fa 	mov	x26, x0
    3ff8:	52802001 	mov	w1, #0x100                 	// #256
    3ffc:	aa1303e0 	mov	x0, x19
    4000:	97fffa70 	bl	29c0 <fgets@plt>
    4004:	b5fffdc0 	cbnz	x0, 3fbc <fwp_heap_report+0x9c>
    4008:	aa1403e0 	mov	x0, x20
    400c:	97fff9e1 	bl	2790 <fclose@plt>
    4010:	a95253f3 	ldp	x19, x20, [sp, #288]
    4014:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4018:	f947f400 	ldr	x0, [x0, #4072]
    401c:	f94087e2 	ldr	x2, [sp, #264]
    4020:	f9400001 	ldr	x1, [x0]
    4024:	eb010042 	subs	x2, x2, x1
    4028:	d2800001 	mov	x1, #0x0                   	// #0
    402c:	54000281 	b.ne	407c <fwp_heap_report+0x15c>  // b.any
    4030:	a9517bfd 	ldp	x29, x30, [sp, #272]
    4034:	aa1a03e6 	mov	x6, x26
    4038:	aa1903e5 	mov	x5, x25
    403c:	aa1803e4 	mov	x4, x24
    4040:	a9556bf9 	ldp	x25, x26, [sp, #336]
    4044:	aa1703e3 	mov	x3, x23
    4048:	a95463f7 	ldp	x23, x24, [sp, #320]
    404c:	aa1603e0 	mov	x0, x22
    4050:	a9535bf5 	ldp	x21, x22, [sp, #304]
    4054:	1e604121 	fmov	d1, d9
    4058:	1e604100 	fmov	d0, d8
    405c:	d0000022 	adrp	x2, a000 <fwp_main_thread+0x650>
    4060:	6d5627e8 	ldp	d8, d9, [sp, #352]
    4064:	913e0042 	add	x2, x2, #0xf80
    4068:	9105c3ff 	add	sp, sp, #0x170
    406c:	52800041 	mov	w1, #0x2                   	// #2
    4070:	17fffa04 	b	2880 <__fprintf_chk@plt>
    4074:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    4078:	17ffffe7 	b	4014 <fwp_heap_report+0xf4>
    407c:	a91253f3 	stp	x19, x20, [sp, #288]
    4080:	97fff9e4 	bl	2810 <__stack_chk_fail@plt>

0000000000004084 <fwp_heap_init>:
    4084:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4088:	d00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    408c:	9114c061 	add	x1, x3, #0x530
    4090:	910003fd 	mov	x29, sp
    4094:	a90153f3 	stp	x19, x20, [sp, #16]
    4098:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    409c:	9118c262 	add	x2, x19, #0x630
    40a0:	a9025bf5 	stp	x21, x22, [sp, #32]
    40a4:	52800024 	mov	w4, #0x1                   	// #1
    40a8:	52800200 	mov	w0, #0x10                  	// #16
    40ac:	b913a444 	str	w4, [x2, #5028]
    40b0:	b8004420 	str	w0, [x1], #4
    40b4:	11004000 	add	w0, w0, #0x10
    40b8:	7104401f 	cmp	w0, #0x110
    40bc:	54ffffa1 	b.ne	40b0 <fwp_heap_init+0x2c>  // b.any
    40c0:	f0000022 	adrp	x2, b000 <_IO_stdin_used+0x350>
    40c4:	0f002420 	movi	v0.2s, #0x1, lsl #8
    40c8:	d00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    40cc:	9115c021 	add	x1, x1, #0x570
    40d0:	3dc31843 	ldr	q3, [x2, #3168]
    40d4:	d2800000 	mov	x0, #0x0                   	// #0
    40d8:	4e040401 	dup	v1.4s, v0.s[0]
    40dc:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    40e0:	0f215400 	shl	v0.2s, v0.2s, #1
    40e4:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    40e8:	3ca06821 	str	q1, [x1, x0]
    40ec:	91004000 	add	x0, x0, #0x10
    40f0:	f101801f 	cmp	x0, #0x60
    40f4:	54ffff21 	b.ne	40d8 <fwp_heap_init+0x54>  // b.any
    40f8:	d00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    40fc:	9114c063 	add	x3, x3, #0x530
    4100:	91174084 	add	x4, x4, #0x5d0
    4104:	9118c266 	add	x6, x19, #0x630
    4108:	d2800002 	mov	x2, #0x0                   	// #0
    410c:	d2800000 	mov	x0, #0x0                   	// #0
    4110:	d2880205 	mov	x5, #0x4010                	// #16400
    4114:	d503201f 	nop
    4118:	910f0001 	add	x1, x0, #0x3c0
    411c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    4120:	eb02003f 	cmp	x1, x2
    4124:	540000a2 	b.cs	4138 <fwp_heap_init+0xb4>  // b.hs, b.nlast
    4128:	91000400 	add	x0, x0, #0x1
    412c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    4130:	eb02003f 	cmp	x1, x2
    4134:	54ffffa3 	b.cc	4128 <fwp_heap_init+0xa4>  // b.lo, b.ul, b.last
    4138:	91004042 	add	x2, x2, #0x10
    413c:	38001480 	strb	w0, [x4], #1
    4140:	eb05005f 	cmp	x2, x5
    4144:	54fffea1 	b.ne	4118 <fwp_heap_init+0x94>  // b.any
    4148:	528000b5 	mov	w21, #0x5                   	// #5
    414c:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    4150:	14000004 	b	4160 <fwp_heap_init+0xdc>
    4154:	d342fe94 	lsr	x20, x20, #2
    4158:	710006b5 	subs	w21, w21, #0x1
    415c:	54000720 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    4160:	91404296 	add	x22, x20, #0x10, lsl #12
    4164:	d2800005 	mov	x5, #0x0                   	// #0
    4168:	aa1603e1 	mov	x1, x22
    416c:	12800004 	mov	w4, #0xffffffff            	// #-1
    4170:	52880443 	mov	w3, #0x4022                	// #16418
    4174:	52800002 	mov	w2, #0x0                   	// #0
    4178:	d2800000 	mov	x0, #0x0                   	// #0
    417c:	97fff9c9 	bl	28a0 <mmap@plt>
    4180:	aa0003e6 	mov	x6, x0
    4184:	b100041f 	cmn	x0, #0x1
    4188:	54fffe60 	b.eq	4154 <fwp_heap_init+0xd0>  // b.none
    418c:	b40005a0 	cbz	x0, 4240 <fwp_heap_init+0x1bc>
    4190:	d350fe94 	lsr	x20, x20, #16
    4194:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4198:	8b0000c7 	add	x7, x6, x0
    419c:	9118c275 	add	x21, x19, #0x630
    41a0:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    41a4:	8b140a81 	add	x1, x20, x20, lsl #2
    41a8:	d2800005 	mov	x5, #0x0                   	// #0
    41ac:	12800004 	mov	w4, #0xffffffff            	// #-1
    41b0:	d37df021 	lsl	x1, x1, #3
    41b4:	52880443 	mov	w3, #0x4022                	// #16418
    41b8:	52800002 	mov	w2, #0x0                   	// #0
    41bc:	d2800000 	mov	x0, #0x0                   	// #0
    41c0:	f909daa7 	str	x7, [x21, #5040]
    41c4:	f909dea6 	str	x6, [x21, #5048]
    41c8:	f909e2b6 	str	x22, [x21, #5056]
    41cc:	f909eab4 	str	x20, [x21, #5072]
    41d0:	f90a02a1 	str	x1, [x21, #5120]
    41d4:	97fff9b3 	bl	28a0 <mmap@plt>
    41d8:	aa0003e1 	mov	x1, x0
    41dc:	b100041f 	cmn	x0, #0x1
    41e0:	54000300 	b.eq	4240 <fwp_heap_init+0x1bc>  // b.none
    41e4:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    41e8:	9100c000 	add	x0, x0, #0x30
    41ec:	f909fea1 	str	x1, [x21, #5112]
    41f0:	97fff9ec 	bl	29a0 <getenv@plt>
    41f4:	52800002 	mov	w2, #0x0                   	// #0
    41f8:	aa0003e1 	mov	x1, x0
    41fc:	b40000e0 	cbz	x0, 4218 <fwp_heap_init+0x194>
    4200:	39400000 	ldrb	w0, [x0]
    4204:	340000a0 	cbz	w0, 4218 <fwp_heap_init+0x194>
    4208:	7100c000 	subs	w0, w0, #0x30
    420c:	54000120 	b.eq	4230 <fwp_heap_init+0x1ac>  // b.none
    4210:	7100001f 	cmp	w0, #0x0
    4214:	1a9f07e2 	cset	w2, ne	// ne = any
    4218:	9118c273 	add	x19, x19, #0x630
    421c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4220:	b913aa62 	str	w2, [x19, #5032]
    4224:	a94153f3 	ldp	x19, x20, [sp, #16]
    4228:	a8c37bfd 	ldp	x29, x30, [sp], #48
    422c:	d65f03c0 	ret
    4230:	39400420 	ldrb	w0, [x1, #1]
    4234:	7100001f 	cmp	w0, #0x0
    4238:	1a9f07e2 	cset	w2, ne	// ne = any
    423c:	17fffff7 	b	4218 <fwp_heap_init+0x194>
    4240:	97fffbac 	bl	30f0 <fwp_heap_oom>

0000000000004244 <fwp_wake_io>:
    4244:	900000e9 	adrp	x9, 20000 <__data_start>
    4248:	91014122 	add	x2, x9, #0x50
    424c:	f9400001 	ldr	x1, [x0]
    4250:	5280000a 	mov	w10, #0x0                   	// #0
    4254:	f9406046 	ldr	x6, [x2, #192]
    4258:	52800008 	mov	w8, #0x0                   	// #0
    425c:	4f000400 	movi	v0.4s, #0x0
    4260:	52800027 	mov	w7, #0x1                   	// #1
    4264:	aa0103e2 	mov	x2, x1
    4268:	b4000321 	cbz	x1, 42cc <fwp_wake_io+0x88>
    426c:	f9408c25 	ldr	x5, [x1, #280]
    4270:	39015c27 	strb	w7, [x1, #87]
    4274:	b4000165 	cbz	x5, 42a0 <fwp_wake_io+0x5c>
    4278:	a9520c24 	ldp	x4, x3, [x1, #288]
    427c:	b4000364 	cbz	x4, 42e8 <fwp_wake_io+0xa4>
    4280:	f9009483 	str	x3, [x4, #296]
    4284:	f9409423 	ldr	x3, [x1, #296]
    4288:	b4000043 	cbz	x3, 4290 <fwp_wake_io+0x4c>
    428c:	f9009064 	str	x4, [x3, #288]
    4290:	91080023 	add	x3, x1, #0x200
    4294:	f900943f 	str	xzr, [x1, #296]
    4298:	3c918060 	stur	q0, [x3, #-232]
    429c:	f9400001 	ldr	x1, [x0]
    42a0:	f9402843 	ldr	x3, [x2, #80]
    42a4:	f2001c7f 	tst	x3, #0xff000000ff
    42a8:	54fffde1 	b.ne	4264 <fwp_wake_io+0x20>  // b.any
    42ac:	39015047 	strb	w7, [x2, #84]
    42b0:	f900805f 	str	xzr, [x2, #256]
    42b4:	b40001e6 	cbz	x6, 42f0 <fwp_wake_io+0xac>
    42b8:	f90080c2 	str	x2, [x6, #256]
    42bc:	aa0203e6 	mov	x6, x2
    42c0:	52800028 	mov	w8, #0x1                   	// #1
    42c4:	aa0103e2 	mov	x2, x1
    42c8:	b5fffd21 	cbnz	x1, 426c <fwp_wake_io+0x28>
    42cc:	3400006a 	cbz	w10, 42d8 <fwp_wake_io+0x94>
    42d0:	91014120 	add	x0, x9, #0x50
    42d4:	f900640b 	str	x11, [x0, #200]
    42d8:	34000068 	cbz	w8, 42e4 <fwp_wake_io+0xa0>
    42dc:	91014129 	add	x9, x9, #0x50
    42e0:	f9006126 	str	x6, [x9, #192]
    42e4:	d65f03c0 	ret
    42e8:	f90000a3 	str	x3, [x5]
    42ec:	17ffffe7 	b	4288 <fwp_wake_io+0x44>
    42f0:	aa0203eb 	mov	x11, x2
    42f4:	5280002a 	mov	w10, #0x1                   	// #1
    42f8:	17fffff1 	b	42bc <fwp_wake_io+0x78>
    42fc:	d503201f 	nop

0000000000004300 <ad_raw_free.part.0>:
    4300:	900002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    4304:	d2800001 	mov	x1, #0x0                   	// #0
    4308:	91114082 	add	x2, x4, #0x450
    430c:	14000005 	b	4320 <ad_raw_free.part.0+0x20>
    4310:	91000421 	add	x1, x1, #0x1
    4314:	91006042 	add	x2, x2, #0x18
    4318:	f140043f 	cmp	x1, #0x1, lsl #12
    431c:	54000220 	b.eq	4360 <ad_raw_free.part.0+0x60>  // b.none
    4320:	f9400043 	ldr	x3, [x2]
    4324:	eb03001f 	cmp	x0, x3
    4328:	54ffff41 	b.ne	4310 <ad_raw_free.part.0+0x10>  // b.any
    432c:	8b010421 	add	x1, x1, x1, lsl #1
    4330:	91114084 	add	x4, x4, #0x450
    4334:	900000e2 	adrp	x2, 20000 <__data_start>
    4338:	91014042 	add	x2, x2, #0x50
    433c:	8b010c81 	add	x1, x4, x1, lsl #3
    4340:	b9401024 	ldr	w4, [x1, #16]
    4344:	f9400425 	ldr	x5, [x1, #8]
    4348:	a9007c3f 	stp	xzr, xzr, [x1]
    434c:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    4350:	f900083f 	str	xzr, [x1, #16]
    4354:	cb050061 	sub	x1, x3, x5
    4358:	f8247841 	str	x1, [x2, x4, lsl #3]
    435c:	17fff95d 	b	28d0 <free@plt>
    4360:	f100001f 	cmp	x0, #0x0
    4364:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x350>
    4368:	91016021 	add	x1, x1, #0x58
    436c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4370:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4374:	91010000 	add	x0, x0, #0x40
    4378:	910003fd 	mov	x29, sp
    437c:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4380:	97fffbe0 	bl	3300 <ad_raw_fail>

0000000000004384 <fwp_tape_buffers_dispose>:
    4384:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    4388:	910003fd 	mov	x29, sp
    438c:	f9000bf3 	str	x19, [sp, #16]
    4390:	aa0003f3 	mov	x19, x0
    4394:	f9400000 	ldr	x0, [x0]
    4398:	b4000040 	cbz	x0, 43a0 <fwp_tape_buffers_dispose+0x1c>
    439c:	97ffffd9 	bl	4300 <ad_raw_free.part.0>
    43a0:	f9400a60 	ldr	x0, [x19, #16]
    43a4:	b4000040 	cbz	x0, 43ac <fwp_tape_buffers_dispose+0x28>
    43a8:	97ffffd6 	bl	4300 <ad_raw_free.part.0>
    43ac:	f9401260 	ldr	x0, [x19, #32]
    43b0:	b4000040 	cbz	x0, 43b8 <fwp_tape_buffers_dispose+0x34>
    43b4:	97ffffd3 	bl	4300 <ad_raw_free.part.0>
    43b8:	4f000400 	movi	v0.4s, #0x0
    43bc:	f9001a7f 	str	xzr, [x19, #48]
    43c0:	ad000260 	stp	q0, q0, [x19]
    43c4:	3d800a60 	str	q0, [x19, #32]
    43c8:	f9400bf3 	ldr	x19, [sp, #16]
    43cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43d0:	d65f03c0 	ret

00000000000043d4 <ad_raw_realloc>:
    43d4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43d8:	910003fd 	mov	x29, sp
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	f90013f5 	str	x21, [sp, #32]
    43e4:	b40005a1 	cbz	x1, 4498 <ad_raw_realloc+0xc4>
    43e8:	aa0103f4 	mov	x20, x1
    43ec:	2a0203f5 	mov	w21, w2
    43f0:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    43f4:	d2800004 	mov	x4, #0x0                   	// #0
    43f8:	91114025 	add	x5, x1, #0x450
    43fc:	14000005 	b	4410 <ad_raw_realloc+0x3c>
    4400:	91000484 	add	x4, x4, #0x1
    4404:	910060a5 	add	x5, x5, #0x18
    4408:	f140049f 	cmp	x4, #0x1, lsl #12
    440c:	54000320 	b.eq	4470 <ad_raw_realloc+0x9c>  // b.none
    4410:	f94000a6 	ldr	x6, [x5]
    4414:	eb06001f 	cmp	x0, x6
    4418:	54ffff41 	b.ne	4400 <ad_raw_realloc+0x2c>  // b.any
    441c:	8b040484 	add	x4, x4, x4, lsl #1
    4420:	91114021 	add	x1, x1, #0x450
    4424:	8b040c33 	add	x19, x1, x4, lsl #3
    4428:	b4000080 	cbz	x0, 4438 <ad_raw_realloc+0x64>
    442c:	b9401261 	ldr	w1, [x19, #16]
    4430:	6b15003f 	cmp	w1, w21
    4434:	540002c1 	b.ne	448c <ad_raw_realloc+0xb8>  // b.any
    4438:	aa1403e1 	mov	x1, x20
    443c:	97fff8f1 	bl	2800 <realloc@plt>
    4440:	aa0003ed 	mov	x13, x0
    4444:	b40000c0 	cbz	x0, 445c <ad_raw_realloc+0x88>
    4448:	2a1503e3 	mov	w3, w21
    444c:	aa1403e2 	mov	x2, x20
    4450:	aa1303e0 	mov	x0, x19
    4454:	aa0d03e1 	mov	x1, x13
    4458:	97fffaae 	bl	2f10 <ad_raw_record>
    445c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4460:	aa0d03e0 	mov	x0, x13
    4464:	f94013f5 	ldr	x21, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	f100001f 	cmp	x0, #0x0
    4474:	f0000021 	adrp	x1, b000 <_IO_stdin_used+0x350>
    4478:	91016021 	add	x1, x1, #0x58
    447c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4480:	91010000 	add	x0, x0, #0x40
    4484:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    4488:	97fffb9e 	bl	3300 <ad_raw_fail>
    448c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4490:	91026000 	add	x0, x0, #0x98
    4494:	97fffb9b 	bl	3300 <ad_raw_fail>
    4498:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    449c:	9101e000 	add	x0, x0, #0x78
    44a0:	97fffb98 	bl	3300 <ad_raw_fail>

00000000000044a4 <fwp_tape_buffers_release>:
    44a4:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44a8:	910003fd 	mov	x29, sp
    44ac:	a90153f3 	stp	x19, x20, [sp, #16]
    44b0:	aa0003f4 	mov	x20, x0
    44b4:	f9401400 	ldr	x0, [x0, #40]
    44b8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44bc:	b7f80560 	tbnz	x0, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c0:	f9401a93 	ldr	x19, [x20, #48]
    44c4:	b7f80533 	tbnz	x19, #63, 4568 <fwp_tape_buffers_release+0xc4>
    44c8:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    44cc:	eb01001f 	cmp	x0, x1
    44d0:	540004c8 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44d4:	8b000400 	add	x0, x0, x0, lsl #1
    44d8:	d2a00101 	mov	x1, #0x80000               	// #524288
    44dc:	d37df000 	lsl	x0, x0, #3
    44e0:	cb000021 	sub	x1, x1, x0
    44e4:	eb410e7f 	cmp	x19, x1, lsr #3
    44e8:	54000408 	b.hi	4568 <fwp_tape_buffers_release+0xc4>  // b.pmore
    44ec:	8b130c13 	add	x19, x0, x19, lsl #3
    44f0:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    44f4:	9102c000 	add	x0, x0, #0xb0
    44f8:	97fff92a 	bl	29a0 <getenv@plt>
    44fc:	b4000080 	cbz	x0, 450c <fwp_tape_buffers_release+0x68>
    4500:	39400001 	ldrb	w1, [x0]
    4504:	7100c03f 	cmp	w1, #0x30
    4508:	54000880 	b.eq	4618 <fwp_tape_buffers_release+0x174>  // b.none
    450c:	d1000661 	sub	x1, x19, #0x1
    4510:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4514:	eb00003f 	cmp	x1, x0
    4518:	54000328 	b.hi	457c <fwp_tape_buffers_release+0xd8>  // b.pmore
    451c:	900000f5 	adrp	x21, 20000 <__data_start>
    4520:	f9001bf7 	str	x23, [sp, #48]
    4524:	910142b7 	add	x23, x21, #0x50
    4528:	910382f6 	add	x22, x23, #0xe0
    452c:	aa1603e0 	mov	x0, x22
    4530:	97ffff95 	bl	4384 <fwp_tape_buffers_dispose>
    4534:	ad400a81 	ldp	q1, q2, [x20]
    4538:	f9008ef3 	str	x19, [x23, #280]
    453c:	4f000400 	movi	v0.4s, #0x0
    4540:	ad000ac1 	stp	q1, q2, [x22]
    4544:	3dc00a81 	ldr	q1, [x20, #32]
    4548:	3d800ac1 	str	q1, [x22, #32]
    454c:	f9401a80 	ldr	x0, [x20, #48]
    4550:	f9001ac0 	str	x0, [x22, #48]
    4554:	f9001a9f 	str	xzr, [x20, #48]
    4558:	ad000280 	stp	q0, q0, [x20]
    455c:	3d800a80 	str	q0, [x20, #32]
    4560:	f9401bf7 	ldr	x23, [sp, #48]
    4564:	1400000b 	b	4590 <fwp_tape_buffers_release+0xec>
    4568:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    456c:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    4570:	9102c000 	add	x0, x0, #0xb0
    4574:	97fff90b 	bl	29a0 <getenv@plt>
    4578:	b5fffc40 	cbnz	x0, 4500 <fwp_tape_buffers_release+0x5c>
    457c:	aa1403e0 	mov	x0, x20
    4580:	97ffff81 	bl	4384 <fwp_tape_buffers_dispose>
    4584:	900000f5 	adrp	x21, 20000 <__data_start>
    4588:	910142a0 	add	x0, x21, #0x50
    458c:	f9408c13 	ldr	x19, [x0, #280]
    4590:	910142a2 	add	x2, x21, #0x50
    4594:	f9409044 	ldr	x4, [x2, #288]
    4598:	a9400c45 	ldp	x5, x3, [x2]
    459c:	8b040481 	add	x1, x4, x4, lsl #1
    45a0:	f9400840 	ldr	x0, [x2, #16]
    45a4:	8b010881 	add	x1, x4, x1, lsl #2
    45a8:	f9400c44 	ldr	x4, [x2, #24]
    45ac:	8b0300a3 	add	x3, x5, x3
    45b0:	d37df021 	lsl	x1, x1, #3
    45b4:	8b040000 	add	x0, x0, x4
    45b8:	8b030000 	add	x0, x0, x3
    45bc:	eb05003f 	cmp	x1, x5
    45c0:	54000321 	b.ne	4624 <fwp_tape_buffers_release+0x180>  // b.any
    45c4:	8b130023 	add	x3, x1, x19
    45c8:	eb00007f 	cmp	x3, x0
    45cc:	540002c8 	b.hi	4624 <fwp_tape_buffers_release+0x180>  // b.pmore
    45d0:	f9405c43 	ldr	x3, [x2, #184]
    45d4:	f140087f 	cmp	x3, #0x2, lsl #12
    45d8:	540002e0 	b.eq	4634 <fwp_tape_buffers_release+0x190>  // b.none
    45dc:	8b030464 	add	x4, x3, x3, lsl #1
    45e0:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    45e4:	911140a5 	add	x5, x5, #0x450
    45e8:	cb010000 	sub	x0, x0, x1
    45ec:	d37df084 	lsl	x4, x4, #3
    45f0:	cb130000 	sub	x0, x0, x19
    45f4:	8b0400a6 	add	x6, x5, x4
    45f8:	91000463 	add	x3, x3, #0x1
    45fc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4600:	f82468a1 	str	x1, [x5, x4]
    4604:	a90080d3 	stp	x19, x0, [x6, #8]
    4608:	f9005c43 	str	x3, [x2, #184]
    460c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4610:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4614:	d65f03c0 	ret
    4618:	39400400 	ldrb	w0, [x0, #1]
    461c:	34fffb00 	cbz	w0, 457c <fwp_tape_buffers_release+0xd8>
    4620:	17ffffbb 	b	450c <fwp_tape_buffers_release+0x68>
    4624:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4628:	91032000 	add	x0, x0, #0xc8
    462c:	f9001bf7 	str	x23, [sp, #48]
    4630:	97fffb34 	bl	3300 <ad_raw_fail>
    4634:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4638:	9103e000 	add	x0, x0, #0xf8
    463c:	f9001bf7 	str	x23, [sp, #48]
    4640:	97fffb30 	bl	3300 <ad_raw_fail>

0000000000004644 <fwp_poll_events>:
    4644:	d10103ff 	sub	sp, sp, #0x40
    4648:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    464c:	f947f400 	ldr	x0, [x0, #4072]
    4650:	a9027bfd 	stp	x29, x30, [sp, #32]
    4654:	910083fd 	add	x29, sp, #0x20
    4658:	a90353f3 	stp	x19, x20, [sp, #48]
    465c:	900000f4 	adrp	x20, 20000 <__data_start>
    4660:	f9400001 	ldr	x1, [x0]
    4664:	f9000fe1 	str	x1, [sp, #24]
    4668:	d2800001 	mov	x1, #0x0                   	// #0
    466c:	97fffca5 	bl	3900 <fwp_now_ns>
    4670:	91014281 	add	x1, x20, #0x50
    4674:	f9409433 	ldr	x19, [x1, #296]
    4678:	b4000e73 	cbz	x19, 4844 <fwp_poll_events+0x200>
    467c:	aa1303e1 	mov	x1, x19
    4680:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4684:	14000005 	b	4698 <fwp_poll_events+0x54>
    4688:	f9408821 	ldr	x1, [x1, #272]
    468c:	eb03005f 	cmp	x2, x3
    4690:	9a83d042 	csel	x2, x2, x3, le
    4694:	b40000c1 	cbz	x1, 46ac <fwp_poll_events+0x68>
    4698:	f9403423 	ldr	x3, [x1, #104]
    469c:	b6ffff62 	tbz	x2, #63, 4688 <fwp_poll_events+0x44>
    46a0:	f9408821 	ldr	x1, [x1, #272]
    46a4:	aa0303e2 	mov	x2, x3
    46a8:	b5ffff81 	cbnz	x1, 4698 <fwp_poll_events+0x54>
    46ac:	b7f80cc2 	tbnz	x2, #63, 4844 <fwp_poll_events+0x200>
    46b0:	cb000042 	sub	x2, x2, x0
    46b4:	f100005f 	cmp	x2, #0x0
    46b8:	540005ad 	b.le	476c <fwp_poll_events+0x128>
    46bc:	d2869b60 	mov	x0, #0x34db                	// #13531
    46c0:	d2884801 	mov	x1, #0x4240                	// #16960
    46c4:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    46c8:	f2a001e1 	movk	x1, #0xf, lsl #16
    46cc:	f2dbd040 	movk	x0, #0xde82, lsl #32
    46d0:	b2407be3 	mov	x3, #0x7fffffff            	// #2147483647
    46d4:	f2e86360 	movk	x0, #0x431b, lsl #48
    46d8:	9b407c40 	smulh	x0, x2, x0
    46dc:	9352fc00 	asr	x0, x0, #18
    46e0:	cb82fc00 	sub	x0, x0, x2, asr #63
    46e4:	9b018802 	msub	x2, x0, x1, x2
    46e8:	f100005f 	cmp	x2, #0x0
    46ec:	9a800400 	cinc	x0, x0, ne	// ne = any
    46f0:	eb03001f 	cmp	x0, x3
    46f4:	540009ec 	b.gt	4830 <fwp_poll_events+0x1ec>
    46f8:	340003a0 	cbz	w0, 476c <fwp_poll_events+0x128>
    46fc:	5289ba62 	mov	w2, #0x4dd3                	// #19923
    4700:	52807d04 	mov	w4, #0x3e8                 	// #1000
    4704:	72a20c42 	movk	w2, #0x1062, lsl #16
    4708:	9ba27c02 	umull	x2, w0, w2
    470c:	d366fc43 	lsr	x3, x2, #38
    4710:	aa0303e2 	mov	x2, x3
    4714:	1b048063 	msub	w3, w3, w4, w0
    4718:	9b217c63 	smull	x3, w3, w1
    471c:	d2800001 	mov	x1, #0x0                   	// #0
    4720:	910023e0 	add	x0, sp, #0x8
    4724:	a9008fe2 	stp	x2, x3, [sp, #8]
    4728:	97fff86e 	bl	28e0 <nanosleep@plt>
    472c:	91014280 	add	x0, x20, #0x50
    4730:	f9409413 	ldr	x19, [x0, #296]
    4734:	97fffc73 	bl	3900 <fwp_now_ns>
    4738:	aa0003e6 	mov	x6, x0
    473c:	b50001d3 	cbnz	x19, 4774 <fwp_poll_events+0x130>
    4740:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4744:	f947f400 	ldr	x0, [x0, #4072]
    4748:	f9400fe2 	ldr	x2, [sp, #24]
    474c:	f9400001 	ldr	x1, [x0]
    4750:	eb010042 	subs	x2, x2, x1
    4754:	d2800001 	mov	x1, #0x0                   	// #0
    4758:	540008c1 	b.ne	4870 <fwp_poll_events+0x22c>  // b.any
    475c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4760:	a94353f3 	ldp	x19, x20, [sp, #48]
    4764:	910103ff 	add	sp, sp, #0x40
    4768:	d65f03c0 	ret
    476c:	97fffc65 	bl	3900 <fwp_now_ns>
    4770:	aa0003e6 	mov	x6, x0
    4774:	4f000400 	movi	v0.4s, #0x0
    4778:	91014288 	add	x8, x20, #0x50
    477c:	52800027 	mov	w7, #0x1                   	// #1
    4780:	f9403661 	ldr	x1, [x19, #104]
    4784:	aa1303e5 	mov	x5, x19
    4788:	f9408a73 	ldr	x19, [x19, #272]
    478c:	eb06003f 	cmp	x1, x6
    4790:	5400032c 	b.gt	47f4 <fwp_poll_events+0x1b0>
    4794:	394154a0 	ldrb	w0, [x5, #85]
    4798:	36000120 	tbz	w0, #0, 47bc <fwp_poll_events+0x178>
    479c:	f94084a0 	ldr	x0, [x5, #264]
    47a0:	b40003c0 	cbz	x0, 4818 <fwp_poll_events+0x1d4>
    47a4:	f9008813 	str	x19, [x0, #272]
    47a8:	b4000053 	cbz	x19, 47b0 <fwp_poll_events+0x16c>
    47ac:	f9008660 	str	x0, [x19, #264]
    47b0:	910800a0 	add	x0, x5, #0x200
    47b4:	390154bf 	strb	wzr, [x5, #85]
    47b8:	3c908000 	stur	q0, [x0, #-248]
    47bc:	f94030a0 	ldr	x0, [x5, #96]
    47c0:	390158a7 	strb	w7, [x5, #86]
    47c4:	f100001f 	cmp	x0, #0x0
    47c8:	fa461000 	ccmp	x0, x6, #0x0, ne	// ne = any
    47cc:	5400018d 	b.le	47fc <fwp_poll_events+0x1b8>
    47d0:	f94028a0 	ldr	x0, [x5, #80]
    47d4:	f2001c1f 	tst	x0, #0xff000000ff
    47d8:	540000e1 	b.ne	47f4 <fwp_poll_events+0x1b0>  // b.any
    47dc:	f9406100 	ldr	x0, [x8, #192]
    47e0:	390150a7 	strb	w7, [x5, #84]
    47e4:	f90080bf 	str	xzr, [x5, #256]
    47e8:	b40001e0 	cbz	x0, 4824 <fwp_poll_events+0x1e0>
    47ec:	f9006105 	str	x5, [x8, #192]
    47f0:	f9008005 	str	x5, [x0, #256]
    47f4:	b5fffc73 	cbnz	x19, 4780 <fwp_poll_events+0x13c>
    47f8:	17ffffd2 	b	4740 <fwp_poll_events+0xfc>
    47fc:	394144a0 	ldrb	w0, [x5, #81]
    4800:	3707fe80 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    4804:	394140a0 	ldrb	w0, [x5, #80]
    4808:	3707fe40 	tbnz	w0, #0, 47d0 <fwp_poll_events+0x18c>
    480c:	aa0503e0 	mov	x0, x5
    4810:	97fffb98 	bl	3670 <fwp_cancel_tree.part.0>
    4814:	17ffffef 	b	47d0 <fwp_poll_events+0x18c>
    4818:	91014281 	add	x1, x20, #0x50
    481c:	f9009433 	str	x19, [x1, #296]
    4820:	17ffffe2 	b	47a8 <fwp_poll_events+0x164>
    4824:	f9006105 	str	x5, [x8, #192]
    4828:	f9006505 	str	x5, [x8, #200]
    482c:	17fffff2 	b	47f4 <fwp_poll_events+0x1b0>
    4830:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4834:	d2989362 	mov	x2, #0xc49b                	// #50331
    4838:	f2a4d203 	movk	x3, #0x2690, lsl #16
    483c:	f2a00402 	movk	x2, #0x20, lsl #16
    4840:	17ffffb7 	b	471c <fwp_poll_events+0xd8>
    4844:	97fff9ec 	bl	2ff4 <fwp_flush>
    4848:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    484c:	f947e863 	ldr	x3, [x3, #4048]
    4850:	d2800562 	mov	x2, #0x2b                  	// #43
    4854:	d2800021 	mov	x1, #0x1                   	// #1
    4858:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    485c:	91046000 	add	x0, x0, #0x118
    4860:	f9400063 	ldr	x3, [x3]
    4864:	97fff82b 	bl	2910 <fwrite@plt>
    4868:	52800ca0 	mov	w0, #0x65                  	// #101
    486c:	97fff795 	bl	26c0 <exit@plt>
    4870:	97fff7e8 	bl	2810 <__stack_chk_fail@plt>

0000000000004874 <fwp_rc_wide_dup>:
    4874:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4878:	910003fd 	mov	x29, sp
    487c:	a90153f3 	stp	x19, x20, [sp, #16]
    4880:	aa0003f3 	mov	x19, x0
    4884:	ca404400 	eor	x0, x0, x0, lsr #17
    4888:	f90013f5 	str	x21, [sp, #32]
    488c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4890:	ca402400 	eor	x0, x0, x0, lsr #9
    4894:	9118c2a2 	add	x2, x21, #0x630
    4898:	92401c00 	and	x0, x0, #0xff
    489c:	910a2403 	add	x3, x0, #0x289
    48a0:	8b000c40 	add	x0, x2, x0, lsl #3
    48a4:	8b030c54 	add	x20, x2, x3, lsl #3
    48a8:	f94a2401 	ldr	x1, [x0, #5192]
    48ac:	b50000a1 	cbnz	x1, 48c0 <fwp_rc_wide_dup+0x4c>
    48b0:	1400002d 	b	4964 <fwp_rc_wide_dup+0xf0>
    48b4:	91004034 	add	x20, x1, #0x10
    48b8:	f9400821 	ldr	x1, [x1, #16]
    48bc:	b4000241 	cbz	x1, 4904 <fwp_rc_wide_dup+0x90>
    48c0:	f9400022 	ldr	x2, [x1]
    48c4:	eb02027f 	cmp	x19, x2
    48c8:	54ffff61 	b.ne	48b4 <fwp_rc_wide_dup+0x40>  // b.any
    48cc:	f9400281 	ldr	x1, [x20]
    48d0:	39400260 	ldrb	w0, [x19]
    48d4:	7103f81f 	cmp	w0, #0xfe
    48d8:	54000220 	b.eq	491c <fwp_rc_wide_dup+0xa8>  // b.none
    48dc:	b40001a1 	cbz	x1, 4910 <fwp_rc_wide_dup+0x9c>
    48e0:	f9400420 	ldr	x0, [x1, #8]
    48e4:	b100041f 	cmn	x0, #0x1
    48e8:	540004a0 	b.eq	497c <fwp_rc_wide_dup+0x108>  // b.none
    48ec:	91000400 	add	x0, x0, #0x1
    48f0:	f9000420 	str	x0, [x1, #8]
    48f4:	a94153f3 	ldp	x19, x20, [sp, #16]
    48f8:	f94013f5 	ldr	x21, [sp, #32]
    48fc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4900:	d65f03c0 	ret
    4904:	39400260 	ldrb	w0, [x19]
    4908:	7103f81f 	cmp	w0, #0xfe
    490c:	540000a0 	b.eq	4920 <fwp_rc_wide_dup+0xac>  // b.none
    4910:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4914:	9105c000 	add	x0, x0, #0x170
    4918:	97fffb9a 	bl	3780 <fwp_trap>
    491c:	b5000281 	cbnz	x1, 496c <fwp_rc_wide_dup+0xf8>
    4920:	d2800300 	mov	x0, #0x18                  	// #24
    4924:	97fff7a3 	bl	27b0 <malloc@plt>
    4928:	b4000280 	cbz	x0, 4978 <fwp_rc_wide_dup+0x104>
    492c:	d2801fe1 	mov	x1, #0xff                  	// #255
    4930:	a9000413 	stp	x19, x1, [x0]
    4934:	9118c2b5 	add	x21, x21, #0x630
    4938:	f900081f 	str	xzr, [x0, #16]
    493c:	12800001 	mov	w1, #0xffffffff            	// #-1
    4940:	f9000280 	str	x0, [x20]
    4944:	39000261 	strb	w1, [x19]
    4948:	f94e26a0 	ldr	x0, [x21, #7240]
    494c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4950:	91000400 	add	x0, x0, #0x1
    4954:	f90e26a0 	str	x0, [x21, #7240]
    4958:	f94013f5 	ldr	x21, [sp, #32]
    495c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4960:	d65f03c0 	ret
    4964:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4968:	17ffffda 	b	48d0 <fwp_rc_wide_dup+0x5c>
    496c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4970:	91052000 	add	x0, x0, #0x148
    4974:	97fffb83 	bl	3780 <fwp_trap>
    4978:	97fff9de 	bl	30f0 <fwp_heap_oom>
    497c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4980:	91066000 	add	x0, x0, #0x198
    4984:	97fffb7f 	bl	3780 <fwp_trap>
    4988:	d503201f 	nop
    498c:	d503201f 	nop

0000000000004990 <fwp_rc_forget_slot>:
    4990:	aa0003e1 	mov	x1, x0
    4994:	39400000 	ldrb	w0, [x0]
    4998:	7103fc1f 	cmp	w0, #0xff
    499c:	54000040 	b.eq	49a4 <fwp_rc_forget_slot+0x14>  // b.none
    49a0:	d65f03c0 	ret
    49a4:	ca414420 	eor	x0, x1, x1, lsr #17
    49a8:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    49ac:	ca402400 	eor	x0, x0, x0, lsr #9
    49b0:	910003fd 	mov	x29, sp
    49b4:	92401c00 	and	x0, x0, #0xff
    49b8:	f9000bf3 	str	x19, [sp, #16]
    49bc:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    49c0:	9118c262 	add	x2, x19, #0x630
    49c4:	910a2403 	add	x3, x0, #0x289
    49c8:	8b000c40 	add	x0, x2, x0, lsl #3
    49cc:	8b030c43 	add	x3, x2, x3, lsl #3
    49d0:	f94a2400 	ldr	x0, [x0, #5192]
    49d4:	b50000a0 	cbnz	x0, 49e8 <fwp_rc_forget_slot+0x58>
    49d8:	14000011 	b	4a1c <fwp_rc_forget_slot+0x8c>
    49dc:	91004003 	add	x3, x0, #0x10
    49e0:	f9400800 	ldr	x0, [x0, #16]
    49e4:	b40001c0 	cbz	x0, 4a1c <fwp_rc_forget_slot+0x8c>
    49e8:	f9400002 	ldr	x2, [x0]
    49ec:	eb02003f 	cmp	x1, x2
    49f0:	54ffff61 	b.ne	49dc <fwp_rc_forget_slot+0x4c>  // b.any
    49f4:	f9400801 	ldr	x1, [x0, #16]
    49f8:	9118c273 	add	x19, x19, #0x630
    49fc:	f9000061 	str	x1, [x3]
    4a00:	97fff7b4 	bl	28d0 <free@plt>
    4a04:	f94e2660 	ldr	x0, [x19, #7240]
    4a08:	d1000400 	sub	x0, x0, #0x1
    4a0c:	f90e2660 	str	x0, [x19, #7240]
    4a10:	f9400bf3 	ldr	x19, [sp, #16]
    4a14:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4a18:	d65f03c0 	ret
    4a1c:	f0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    4a20:	9105c000 	add	x0, x0, #0x170
    4a24:	97fffb57 	bl	3780 <fwp_trap>
    4a28:	d503201f 	nop
    4a2c:	d503201f 	nop

0000000000004a30 <fwp_rc_prepare_chunk>:
    4a30:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4a34:	910003fd 	mov	x29, sp
    4a38:	a9025bf5 	stp	x21, x22, [sp, #32]
    4a3c:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    4a40:	9118c2c2 	add	x2, x22, #0x630
    4a44:	b9401c03 	ldr	w3, [x0, #28]
    4a48:	aa0103f5 	mov	x21, x1
    4a4c:	a90153f3 	stp	x19, x20, [sp, #16]
    4a50:	aa0003f4 	mov	x20, x0
    4a54:	f94e2440 	ldr	x0, [x2, #7240]
    4a58:	b4000440 	cbz	x0, 4ae0 <fwp_rc_prepare_chunk+0xb0>
    4a5c:	d2800013 	mov	x19, #0x0                   	// #0
    4a60:	35000203 	cbnz	w3, 4aa0 <fwp_rc_prepare_chunk+0x70>
    4a64:	b4000361 	cbz	x1, 4ad0 <fwp_rc_prepare_chunk+0xa0>
    4a68:	f9401280 	ldr	x0, [x20, #32]
    4a6c:	97fff799 	bl	28d0 <free@plt>
    4a70:	aa1503e0 	mov	x0, x21
    4a74:	d2800021 	mov	x1, #0x1                   	// #1
    4a78:	97fff75e 	bl	27f0 <calloc@plt>
    4a7c:	f9001280 	str	x0, [x20, #32]
    4a80:	b5000460 	cbnz	x0, 4b0c <fwp_rc_prepare_chunk+0xdc>
    4a84:	97fff99b 	bl	30f0 <fwp_heap_oom>
    4a88:	97ffffc2 	bl	4990 <fwp_rc_forget_slot>
    4a8c:	91000673 	add	x19, x19, #0x1
    4a90:	b9401e83 	ldr	w3, [x20, #28]
    4a94:	eb13007f 	cmp	x3, x19
    4a98:	54000169 	b.ls	4ac4 <fwp_rc_prepare_chunk+0x94>  // b.plast
    4a9c:	d503201f 	nop
    4aa0:	f9401283 	ldr	x3, [x20, #32]
    4aa4:	8b130060 	add	x0, x3, x19
    4aa8:	38736863 	ldrb	w3, [x3, x19]
    4aac:	7103fc7f 	cmp	w3, #0xff
    4ab0:	54fffec0 	b.eq	4a88 <fwp_rc_prepare_chunk+0x58>  // b.none
    4ab4:	b9401e83 	ldr	w3, [x20, #28]
    4ab8:	91000673 	add	x19, x19, #0x1
    4abc:	eb13007f 	cmp	x3, x19
    4ac0:	54ffff08 	b.hi	4aa0 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4ac4:	eb0302bf 	cmp	x21, x3
    4ac8:	54000121 	b.ne	4aec <fwp_rc_prepare_chunk+0xbc>  // b.any
    4acc:	b5000335 	cbnz	x21, 4b30 <fwp_rc_prepare_chunk+0x100>
    4ad0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ad4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ad8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4adc:	d65f03c0 	ret
    4ae0:	2a0303e3 	mov	w3, w3
    4ae4:	eb0302bf 	cmp	x21, x3
    4ae8:	54ffff20 	b.eq	4acc <fwp_rc_prepare_chunk+0x9c>  // b.none
    4aec:	9118c2c2 	add	x2, x22, #0x630
    4af0:	f9401280 	ldr	x0, [x20, #32]
    4af4:	f94e2841 	ldr	x1, [x2, #7248]
    4af8:	cb030021 	sub	x1, x1, x3
    4afc:	f90e2841 	str	x1, [x2, #7248]
    4b00:	97fff774 	bl	28d0 <free@plt>
    4b04:	b5fffb75 	cbnz	x21, 4a70 <fwp_rc_prepare_chunk+0x40>
    4b08:	f900129f 	str	xzr, [x20, #32]
    4b0c:	9118c2d6 	add	x22, x22, #0x630
    4b10:	f94e2ac0 	ldr	x0, [x22, #7248]
    4b14:	b9001e95 	str	w21, [x20, #28]
    4b18:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b1c:	8b150000 	add	x0, x0, x21
    4b20:	f90e2ac0 	str	x0, [x22, #7248]
    4b24:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b28:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b2c:	d65f03c0 	ret
    4b30:	f9401280 	ldr	x0, [x20, #32]
    4b34:	aa1503e2 	mov	x2, x21
    4b38:	a94153f3 	ldp	x19, x20, [sp, #16]
    4b3c:	52800001 	mov	w1, #0x0                   	// #0
    4b40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4b44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4b48:	17fff726 	b	27e0 <memset@plt>
    4b4c:	d503201f 	nop

0000000000004b50 <fwp_heap_refill>:
    4b50:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b54:	910003fd 	mov	x29, sp
    4b58:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b5c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4b60:	9118c2b5 	add	x21, x21, #0x630
    4b64:	aa0003f6 	mov	x22, x0
    4b68:	d2800020 	mov	x0, #0x1                   	// #1
    4b6c:	a90153f3 	stp	x19, x20, [sp, #16]
    4b70:	a90363f7 	stp	x23, x24, [sp, #48]
    4b74:	2a0103f7 	mov	w23, w1
    4b78:	2a0203f8 	mov	w24, w2
    4b7c:	97fff96d 	bl	3130 <fwp_heap_chunks>
    4b80:	aa0003f3 	mov	x19, x0
    4b84:	f949fea2 	ldr	x2, [x21, #5112]
    4b88:	8b000800 	add	x0, x0, x0, lsl #2
    4b8c:	2a1703e1 	mov	w1, w23
    4b90:	52800025 	mov	w5, #0x1                   	// #1
    4b94:	d37df000 	lsl	x0, x0, #3
    4b98:	910f0021 	add	x1, x1, #0x3c0
    4b9c:	8b000054 	add	x20, x2, x0
    4ba0:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4ba4:	52a00024 	mov	w4, #0x10000               	// #65536
    4ba8:	38206845 	strb	w5, [x2, x0]
    4bac:	aa1403e0 	mov	x0, x20
    4bb0:	39000698 	strb	w24, [x20, #1]
    4bb4:	39000a97 	strb	w23, [x20, #2]
    4bb8:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    4bbc:	b9000681 	str	w1, [x20, #4]
    4bc0:	2a0103e5 	mov	w5, w1
    4bc4:	8b0300a2 	add	x2, x5, x3
    4bc8:	1ac10881 	udiv	w1, w4, w1
    4bcc:	9ac50842 	udiv	x2, x2, x5
    4bd0:	b9000a81 	str	w1, [x20, #8]
    4bd4:	92404021 	and	x1, x1, #0x1ffff
    4bd8:	b9001a82 	str	w2, [x20, #24]
    4bdc:	97ffff95 	bl	4a30 <fwp_rc_prepare_chunk>
    4be0:	f949daa0 	ldr	x0, [x21, #5040]
    4be4:	29408a81 	ldp	w1, w2, [x20, #4]
    4be8:	8b134000 	add	x0, x0, x19, lsl #16
    4bec:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bf0:	8b214003 	add	x3, x0, w1, uxtw
    4bf4:	9ba20021 	umaddl	x1, w1, w2, x0
    4bf8:	a94363f7 	ldp	x23, x24, [sp, #48]
    4bfc:	a90086c3 	stp	x3, x1, [x22, #8]
    4c00:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c04:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c08:	d65f03c0 	ret
    4c0c:	d503201f 	nop

0000000000004c10 <fwp_mem_free>:
    4c10:	b40003c0 	cbz	x0, 4c88 <fwp_mem_free+0x78>
    4c14:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4c18:	910003fd 	mov	x29, sp
    4c1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c20:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    4c24:	9118c2a1 	add	x1, x21, #0x630
    4c28:	a90153f3 	stp	x19, x20, [sp, #16]
    4c2c:	aa0003f3 	mov	x19, x0
    4c30:	f949d823 	ldr	x3, [x1, #5040]
    4c34:	f949ec22 	ldr	x2, [x1, #5080]
    4c38:	cb030000 	sub	x0, x0, x3
    4c3c:	eb02401f 	cmp	x0, x2, lsl #16
    4c40:	540001c2 	b.cs	4c78 <fwp_mem_free+0x68>  // b.hs, b.nlast
    4c44:	d350fc16 	lsr	x22, x0, #16
    4c48:	a90363f7 	stp	x23, x24, [sp, #48]
    4c4c:	f949fc22 	ldr	x2, [x1, #5112]
    4c50:	8b160ad4 	add	x20, x22, x22, lsl #2
    4c54:	d37df294 	lsl	x20, x20, #3
    4c58:	ab140057 	adds	x23, x2, x20
    4c5c:	540000c0 	b.eq	4c74 <fwp_mem_free+0x64>  // b.none
    4c60:	38746842 	ldrb	w2, [x2, x20]
    4c64:	7100045f 	cmp	w2, #0x1
    4c68:	54000120 	b.eq	4c8c <fwp_mem_free+0x7c>  // b.none
    4c6c:	7100085f 	cmp	w2, #0x2
    4c70:	540005e0 	b.eq	4d2c <fwp_mem_free+0x11c>  // b.none
    4c74:	a94363f7 	ldp	x23, x24, [sp, #48]
    4c78:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c7c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c80:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4c84:	d65f03c0 	ret
    4c88:	d65f03c0 	ret
    4c8c:	f94012f8 	ldr	x24, [x23, #32]
    4c90:	b94006e1 	ldr	w1, [x23, #4]
    4c94:	f90023f9 	str	x25, [sp, #64]
    4c98:	2a0103e2 	mov	w2, w1
    4c9c:	394006f9 	ldrb	w25, [x23, #1]
    4ca0:	39400af4 	ldrb	w20, [x23, #2]
    4ca4:	b4000158 	cbz	x24, 4ccc <fwp_mem_free+0xbc>
    4ca8:	92403e76 	and	x22, x19, #0xffff
    4cac:	9ac20ad6 	udiv	x22, x22, x2
    4cb0:	38766b01 	ldrb	w1, [x24, x22]
    4cb4:	8b160300 	add	x0, x24, x22
    4cb8:	7103fc3f 	cmp	w1, #0xff
    4cbc:	54000980 	b.eq	4dec <fwp_mem_free+0x1dc>  // b.none
    4cc0:	38366b1f 	strb	wzr, [x24, x22]
    4cc4:	b94006e1 	ldr	w1, [x23, #4]
    4cc8:	2a0103e2 	mov	w2, w1
    4ccc:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4cd0:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4cd4:	cb390000 	sub	x0, x0, w25, uxtb
    4cd8:	8b340074 	add	x20, x3, w20, uxtb
    4cdc:	9118c2b5 	add	x21, x21, #0x630
    4ce0:	1e630021 	ucvtf	d1, w1
    4ce4:	d37ae400 	lsl	x0, x0, #6
    4ce8:	8b140c14 	add	x20, x0, x20, lsl #3
    4cec:	a94363f7 	ldp	x23, x24, [sp, #48]
    4cf0:	f8746aa0 	ldr	x0, [x21, x20]
    4cf4:	f94023f9 	ldr	x25, [sp, #64]
    4cf8:	aa2003e0 	mvn	x0, x0
    4cfc:	fd4a22a0 	ldr	d0, [x21, #5184]
    4d00:	f9000260 	str	x0, [x19]
    4d04:	f8346ab3 	str	x19, [x21, x20]
    4d08:	f94a12a0 	ldr	x0, [x21, #5152]
    4d0c:	1e612800 	fadd	d0, d0, d1
    4d10:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d14:	cb020000 	sub	x0, x0, x2
    4d18:	f90a12a0 	str	x0, [x21, #5152]
    4d1c:	fd0a22a0 	str	d0, [x21, #5184]
    4d20:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d24:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4d28:	d65f03c0 	ret
    4d2c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    4d30:	8b000063 	add	x3, x3, x0
    4d34:	eb03027f 	cmp	x19, x3
    4d38:	54fff9e1 	b.ne	4c74 <fwp_mem_free+0x64>  // b.any
    4d3c:	fd400ae1 	ldr	d1, [x23, #16]
    4d40:	fd4a2020 	ldr	d0, [x1, #5184]
    4d44:	f9400ae0 	ldr	x0, [x23, #16]
    4d48:	7e61d821 	ucvtf	d1, d1
    4d4c:	f94a1022 	ldr	x2, [x1, #5152]
    4d50:	f94012f3 	ldr	x19, [x23, #32]
    4d54:	1e612800 	fadd	d0, d0, d1
    4d58:	cb000042 	sub	x2, x2, x0
    4d5c:	f90a1022 	str	x2, [x1, #5152]
    4d60:	fd0a2020 	str	d0, [x1, #5184]
    4d64:	b40000b3 	cbz	x19, 4d78 <fwp_mem_free+0x168>
    4d68:	39400260 	ldrb	w0, [x19]
    4d6c:	7103fc1f 	cmp	w0, #0xff
    4d70:	54000380 	b.eq	4de0 <fwp_mem_free+0x1d0>  // b.none
    4d74:	3900027f 	strb	wzr, [x19]
    4d78:	b9400ee2 	ldr	w2, [x23, #12]
    4d7c:	b4000142 	cbz	x2, 4da4 <fwp_mem_free+0x194>
    4d80:	9118c2a1 	add	x1, x21, #0x630
    4d84:	8b160040 	add	x0, x2, x22
    4d88:	8b000800 	add	x0, x0, x0, lsl #2
    4d8c:	f949fc21 	ldr	x1, [x1, #5112]
    4d90:	8b140034 	add	x20, x1, x20
    4d94:	8b000c20 	add	x0, x1, x0, lsl #3
    4d98:	3802869f 	strb	wzr, [x20], #40
    4d9c:	eb00029f 	cmp	x20, x0
    4da0:	54ffffc1 	b.ne	4d98 <fwp_mem_free+0x188>  // b.any
    4da4:	9118c2a0 	add	x0, x21, #0x630
    4da8:	f94a1801 	ldr	x1, [x0, #5168]
    4dac:	f949f803 	ldr	x3, [x0, #5104]
    4db0:	8b020021 	add	x1, x1, x2
    4db4:	f90a1801 	str	x1, [x0, #5168]
    4db8:	eb16007f 	cmp	x3, x22
    4dbc:	54000049 	b.ls	4dc4 <fwp_mem_free+0x1b4>  // b.plast
    4dc0:	f909f816 	str	x22, [x0, #5104]
    4dc4:	9118c2b5 	add	x21, x21, #0x630
    4dc8:	f949f6a0 	ldr	x0, [x21, #5096]
    4dcc:	eb16001f 	cmp	x0, x22
    4dd0:	54fff529 	b.ls	4c74 <fwp_mem_free+0x64>  // b.plast
    4dd4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4dd8:	f909f6b6 	str	x22, [x21, #5096]
    4ddc:	17ffffa7 	b	4c78 <fwp_mem_free+0x68>
    4de0:	aa1303e0 	mov	x0, x19
    4de4:	97fffeeb 	bl	4990 <fwp_rc_forget_slot>
    4de8:	17ffffe3 	b	4d74 <fwp_mem_free+0x164>
    4dec:	97fffee9 	bl	4990 <fwp_rc_forget_slot>
    4df0:	17ffffb4 	b	4cc0 <fwp_mem_free+0xb0>

0000000000004df4 <fwp_heap_alloc_big>:
    4df4:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df8:	910003fd 	mov	x29, sp
    4dfc:	a90153f3 	stp	x19, x20, [sp, #16]
    4e00:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e04:	a90363f7 	stp	x23, x24, [sp, #48]
    4e08:	aa0003f7 	mov	x23, x0
    4e0c:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e10:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e14:	eb0002ff 	cmp	x23, x0
    4e18:	54000888 	b.hi	4f28 <fwp_heap_alloc_big+0x134>  // b.pmore
    4e1c:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e20:	8b0002f4 	add	x20, x23, x0
    4e24:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4e28:	9118c359 	add	x25, x26, #0x630
    4e2c:	d350fe94 	lsr	x20, x20, #16
    4e30:	2a0103f5 	mov	w21, w1
    4e34:	aa1403e0 	mov	x0, x20
    4e38:	97fff8be 	bl	3130 <fwp_heap_chunks>
    4e3c:	f949ff22 	ldr	x2, [x25, #5112]
    4e40:	8b000813 	add	x19, x0, x0, lsl #2
    4e44:	aa0003f8 	mov	x24, x0
    4e48:	52800043 	mov	w3, #0x2                   	// #2
    4e4c:	d37df273 	lsl	x19, x19, #3
    4e50:	d2800021 	mov	x1, #0x1                   	// #1
    4e54:	8b130040 	add	x0, x2, x19
    4e58:	38336843 	strb	w3, [x2, x19]
    4e5c:	39000415 	strb	w21, [x0, #1]
    4e60:	b9000c14 	str	w20, [x0, #12]
    4e64:	f9000817 	str	x23, [x0, #16]
    4e68:	97fffef2 	bl	4a30 <fwp_rc_prepare_chunk>
    4e6c:	f100069f 	cmp	x20, #0x1
    4e70:	54000269 	b.ls	4ebc <fwp_heap_alloc_big+0xc8>  // b.plast
    4e74:	8b180294 	add	x20, x20, x24
    4e78:	9100a273 	add	x19, x19, #0x28
    4e7c:	a90573fb 	stp	x27, x28, [sp, #80]
    4e80:	5280007b 	mov	w27, #0x3                   	// #3
    4e84:	8b140a94 	add	x20, x20, x20, lsl #2
    4e88:	2a1803fc 	mov	w28, w24
    4e8c:	9adb2296 	lsl	x22, x20, x27
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffee4 	bl	4a30 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0x9c>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	9118c353 	add	x19, x26, #0x630
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x134>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x104>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9118c35a 	add	x26, x26, #0x630
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4f40:	9118c262 	add	x2, x19, #0x630
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	9118c262 	add	x2, x19, #0x630
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	9118c260 	add	x0, x19, #0x630
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	9118c273 	add	x19, x19, #0x630
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffc1c 	bl	4084 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff70 	b	4df4 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	9118c260 	add	x0, x19, #0x630
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffeb5 	bl	4b50 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910142c2 	add	x2, x22, #0x50
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	54000861 	b.ne	51c4 <fwp_heap_alloc+0x134>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    50c0:	9118c2f3 	add	x19, x23, #0x630
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	540006e2 	b.cs	5210 <fwp_heap_alloc+0x180>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	9118c2e0 	add	x0, x23, #0x630
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	9118c2e1 	add	x1, x23, #0x630
    5168:	910142c0 	add	x0, x22, #0x50
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	540002cc 	b.gt	51d8 <fwp_heap_alloc+0x148>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000209 	b.ls	51f4 <fwp_heap_alloc+0x164>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	17ffffe8 	b	5160 <fwp_heap_alloc+0xd0>
    51c4:	a9538c44 	ldp	x4, x3, [x2, #312]
    51c8:	91000484 	add	x4, x4, #0x1
    51cc:	8b000063 	add	x3, x3, x0
    51d0:	a9138c44 	stp	x4, x3, [x2, #312]
    51d4:	17ffffba 	b	50bc <fwp_heap_alloc+0x2c>
    51d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51dc:	fd00a800 	str	d0, [x0, #336]
    51e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51e4:	aa0403e0 	mov	x0, x4
    51e8:	a94363f7 	ldp	x23, x24, [sp, #48]
    51ec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f0:	d65f03c0 	ret
    51f4:	7100043f 	cmp	w1, #0x1
    51f8:	8b140085 	add	x5, x4, x20
    51fc:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5200:	52800001 	mov	w1, #0x0                   	// #0
    5204:	aa0403e0 	mov	x0, x4
    5208:	f9000465 	str	x5, [x3, #8]
    520c:	17ffffc6 	b	5124 <fwp_heap_alloc+0x94>
    5210:	97fff7b8 	bl	30f0 <fwp_heap_oom>

0000000000005214 <fwp_apply>:
    5214:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5218:	aa0003e6 	mov	x6, x0
    521c:	910003fd 	mov	x29, sp
    5220:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5224:	f947f463 	ldr	x3, [x3, #4072]
    5228:	a90153f3 	stp	x19, x20, [sp, #16]
    522c:	aa0203f4 	mov	x20, x2
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	2a0103f5 	mov	w21, w1
    5238:	52800033 	mov	w19, #0x1                   	// #1
    523c:	a90363f7 	stp	x23, x24, [sp, #48]
    5240:	f00000d7 	adrp	x23, 20000 <__data_start>
    5244:	910142f7 	add	x23, x23, #0x50
    5248:	a9046bf9 	stp	x25, x26, [sp, #64]
    524c:	d100c3ff 	sub	sp, sp, #0x30
    5250:	f9400060 	ldr	x0, [x3]
    5254:	f81f83a0 	stur	x0, [x29, #-8]
    5258:	d2800000 	mov	x0, #0x0                   	// #0
    525c:	294058c3 	ldp	w3, w22, [x6]
    5260:	910003f8 	mov	x24, sp
    5264:	f9406ae0 	ldr	x0, [x23, #208]
    5268:	710002df 	cmp	w22, #0x0
    526c:	d37be863 	lsl	x3, x3, #5
    5270:	8b030007 	add	x7, x0, x3
    5274:	b8636819 	ldr	w25, [x0, x3]
    5278:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    527c:	54000163 	b.cc	52a8 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    5280:	f94004e3 	ldr	x3, [x7, #8]
    5284:	34000bd9 	cbz	w25, 53fc <fwp_apply+0x1e8>
    5288:	aa1403e0 	mov	x0, x20
    528c:	d63f0060 	blr	x3
    5290:	aa0003e6 	mov	x6, x0
    5294:	6b1902bf 	cmp	w21, w25
    5298:	54000940 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    529c:	8b394e94 	add	x20, x20, w25, uxtw #3
    52a0:	4b1902b5 	sub	w21, w21, w25
    52a4:	17ffffee 	b	525c <fwp_apply+0x48>
    52a8:	0b1602ba 	add	w26, w21, w22
    52ac:	6b19035f 	cmp	w26, w25
    52b0:	54000543 	b.cc	5358 <fwp_apply+0x144>  // b.lo, b.ul, b.last
    52b4:	7100033f 	cmp	w25, #0x0
    52b8:	4b16033a 	sub	w26, w25, w22
    52bc:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52c0:	d37df000 	lsl	x0, x0, #3
    52c4:	91003c00 	add	x0, x0, #0xf
    52c8:	92704c01 	and	x1, x0, #0xfffff0000
    52cc:	927c7c00 	and	x0, x0, #0xffffffff0
    52d0:	cb2163e1 	sub	x1, sp, x1
    52d4:	eb2163ff 	cmp	sp, x1
    52d8:	540000a0 	b.eq	52ec <fwp_apply+0xd8>  // b.none
    52dc:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52e0:	f90203ff 	str	xzr, [sp, #1024]
    52e4:	eb2163ff 	cmp	sp, x1
    52e8:	54ffffa1 	b.ne	52dc <fwp_apply+0xc8>  // b.any
    52ec:	92403c00 	and	x0, x0, #0xffff
    52f0:	cb2063ff 	sub	sp, sp, x0
    52f4:	f90003ff 	str	xzr, [sp]
    52f8:	f110001f 	cmp	x0, #0x400
    52fc:	54000962 	b.cs	5428 <fwp_apply+0x214>  // b.hs, b.nlast
    5300:	910020c6 	add	x6, x6, #0x8
    5304:	910043e0 	add	x0, sp, #0x10
    5308:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    530c:	d2800003 	mov	x3, #0x0                   	// #0
    5310:	340000f6 	cbz	w22, 532c <fwp_apply+0x118>
    5314:	d503201f 	nop
    5318:	f86368c4 	ldr	x4, [x6, x3]
    531c:	f8236804 	str	x4, [x0, x3]
    5320:	91002063 	add	x3, x3, #0x8
    5324:	eb0300bf 	cmp	x5, x3
    5328:	54ffff81 	b.ne	5318 <fwp_apply+0x104>  // b.any
    532c:	3400013a 	cbz	w26, 5350 <fwp_apply+0x13c>
    5330:	2a1a03e6 	mov	w6, w26
    5334:	d2800003 	mov	x3, #0x0                   	// #0
    5338:	0b0302c4 	add	w4, w22, w3
    533c:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5340:	91000463 	add	x3, x3, #0x1
    5344:	f8247805 	str	x5, [x0, x4, lsl #3]
    5348:	eb0300df 	cmp	x6, x3
    534c:	54ffff61 	b.ne	5338 <fwp_apply+0x124>  // b.any
    5350:	f94004e3 	ldr	x3, [x7, #8]
    5354:	1400002c 	b	5404 <fwp_apply+0x1f0>
    5358:	11000740 	add	w0, w26, #0x1
    535c:	52800041 	mov	w1, #0x2                   	// #2
    5360:	f81e83a6 	stur	x6, [x29, #-24]
    5364:	d37df000 	lsl	x0, x0, #3
    5368:	97ffff4a 	bl	5090 <fwp_heap_alloc>
    536c:	f85e83a6 	ldur	x6, [x29, #-24]
    5370:	aa0003f3 	mov	x19, x0
    5374:	b94000c1 	ldr	w1, [x6]
    5378:	29006801 	stp	w1, w26, [x0]
    537c:	340000b6 	cbz	w22, 5390 <fwp_apply+0x17c>
    5380:	910020c1 	add	x1, x6, #0x8
    5384:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5388:	91002000 	add	x0, x0, #0x8
    538c:	97fff4bd 	bl	2680 <memmove@plt>
    5390:	2a1503e3 	mov	w3, w21
    5394:	d2800000 	mov	x0, #0x0                   	// #0
    5398:	34000135 	cbz	w21, 53bc <fwp_apply+0x1a8>
    539c:	d503201f 	nop
    53a0:	0b0002c1 	add	w1, w22, w0
    53a4:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53a8:	8b010e61 	add	x1, x19, x1, lsl #3
    53ac:	91000400 	add	x0, x0, #0x1
    53b0:	f9000422 	str	x2, [x1, #8]
    53b4:	eb00007f 	cmp	x3, x0
    53b8:	54ffff41 	b.ne	53a0 <fwp_apply+0x18c>  // b.any
    53bc:	aa1303e6 	mov	x6, x19
    53c0:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53c4:	f947f400 	ldr	x0, [x0, #4072]
    53c8:	f85f83a2 	ldur	x2, [x29, #-8]
    53cc:	f9400001 	ldr	x1, [x0]
    53d0:	eb010042 	subs	x2, x2, x1
    53d4:	d2800001 	mov	x1, #0x0                   	// #0
    53d8:	540002c1 	b.ne	5430 <fwp_apply+0x21c>  // b.any
    53dc:	910003bf 	mov	sp, x29
    53e0:	aa0603e0 	mov	x0, x6
    53e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    53e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53ec:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f0:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53f4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    53f8:	d65f03c0 	ret
    53fc:	d10043a0 	sub	x0, x29, #0x10
    5400:	5280001a 	mov	w26, #0x0                   	// #0
    5404:	d63f0060 	blr	x3
    5408:	aa0003e6 	mov	x6, x0
    540c:	6b1a02bf 	cmp	w21, w26
    5410:	54fffd80 	b.eq	53c0 <fwp_apply+0x1ac>  // b.none
    5414:	0b1602b6 	add	w22, w21, w22
    5418:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    541c:	4b1902d5 	sub	w21, w22, w25
    5420:	9100031f 	mov	sp, x24
    5424:	17ffff8e 	b	525c <fwp_apply+0x48>
    5428:	f90203ff 	str	xzr, [sp, #1024]
    542c:	17ffffb5 	b	5300 <fwp_apply+0xec>
    5430:	97fff4f8 	bl	2810 <__stack_chk_fail@plt>

0000000000005434 <fwp_p_ad_push>:
    5434:	f100001f 	cmp	x0, #0x0
    5438:	fa40b840 	ccmp	x2, #0x0, #0x0, lt	// lt = tstop
    543c:	540011ab 	b.lt	5670 <fwp_p_ad_push+0x23c>  // b.tstop
    5440:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5450:	aa0403f6 	mov	x22, x4
    5454:	aa0003f5 	mov	x21, x0
    5458:	a90363f7 	stp	x23, x24, [sp, #48]
    545c:	aa0203f8 	mov	x24, x2
    5460:	6d0627e8 	stp	d8, d9, [sp, #96]
    5464:	9e670029 	fmov	d9, x1
    5468:	9e670068 	fmov	d8, x3
    546c:	aa020001 	orr	x1, x0, x2
    5470:	b6f80de1 	tbz	x1, #63, 562c <fwp_p_ad_push+0x1f8>
    5474:	9360fc14 	asr	x20, x0, #32
    5478:	b6f800c0 	tbz	x0, #63, 5490 <fwp_p_ad_push+0x5c>
    547c:	1e604109 	fmov	d9, d8
    5480:	2f00e408 	movi	d8, #0x0
    5484:	9360fc54 	asr	x20, x2, #32
    5488:	aa0203f5 	mov	x21, x2
    548c:	92800018 	mov	x24, #0xffffffffffffffff    	// #-1
    5490:	b4001156 	cbz	x22, 56b8 <fwp_p_ad_push+0x284>
    5494:	f94002c0 	ldr	x0, [x22]
    5498:	eb14001f 	cmp	x0, x20
    549c:	54000e60 	b.eq	5668 <fwp_p_ad_push+0x234>  // b.none
    54a0:	aa1403e0 	mov	x0, x20
    54a4:	97fff983 	bl	3ab0 <fwp_tape_of>
    54a8:	aa0003f3 	mov	x19, x0
    54ac:	f9403000 	ldr	x0, [x0, #96]
    54b0:	b50010e0 	cbnz	x0, 56cc <fwp_p_ad_push+0x298>
    54b4:	a9004ed4 	stp	x20, x19, [x22]
    54b8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54bc:	f9400a77 	ldr	x23, [x19, #16]
    54c0:	a9046bf9 	stp	x25, x26, [sp, #64]
    54c4:	eb0002ff 	cmp	x23, x0
    54c8:	540013ac 	b.gt	573c <fwp_p_ad_push+0x308>
    54cc:	eb3542ff 	cmp	x23, w21, uxtw
    54d0:	540012ed 	b.le	572c <fwp_p_ad_push+0x2f8>
    54d4:	b7f80078 	tbnz	x24, #63, 54e0 <fwp_p_ad_push+0xac>
    54d8:	eb3842ff 	cmp	x23, w24, uxtw
    54dc:	5400128d 	b.le	572c <fwp_p_ad_push+0x2f8>
    54e0:	f9400676 	ldr	x22, [x19, #8]
    54e4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    54e8:	cb1602f6 	sub	x22, x23, x22
    54ec:	910006c1 	add	x1, x22, #0x1
    54f0:	aa1603f9 	mov	x25, x22
    54f4:	eb00003f 	cmp	x1, x0
    54f8:	54001228 	b.hi	573c <fwp_p_ad_push+0x308>  // b.pmore
    54fc:	a9418274 	ldp	x20, x0, [x19, #24]
    5500:	eb14003f 	cmp	x1, x20
    5504:	54000a8d 	b.le	5654 <fwp_p_ad_push+0x220>
    5508:	f100029f 	cmp	x20, #0x0
    550c:	d2800803 	mov	x3, #0x40                  	// #64
    5510:	9a831294 	csel	x20, x20, x3, ne	// ne = any
    5514:	b24077e2 	mov	x2, #0x3fffffff            	// #1073741823
    5518:	a90573fb 	stp	x27, x28, [sp, #80]
    551c:	eb14003f 	cmp	x1, x20
    5520:	5400008d 	b.le	5530 <fwp_p_ad_push+0xfc>
    5524:	eb02029f 	cmp	x20, x2
    5528:	5400092d 	b.le	564c <fwp_p_ad_push+0x218>
    552c:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5530:	d37df29a 	lsl	x26, x20, #3
    5534:	52800022 	mov	w2, #0x1                   	// #1
    5538:	f940327b 	ldr	x27, [x19, #96]
    553c:	aa1a03e1 	mov	x1, x26
    5540:	97fffba5 	bl	43d4 <ad_raw_realloc>
    5544:	b4001040 	cbz	x0, 574c <fwp_p_ad_push+0x318>
    5548:	f9400e61 	ldr	x1, [x19, #24]
    554c:	8b010801 	add	x1, x0, x1, lsl #2
    5550:	a9020660 	stp	x0, x1, [x19, #32]
    5554:	b400093b 	cbz	x27, 5678 <fwp_p_ad_push+0x244>
    5558:	f9403363 	ldr	x3, [x27, #96]
    555c:	f9003be3 	str	x3, [sp, #112]
    5560:	eb03029f 	cmp	x20, x3
    5564:	5400034d 	b.le	55cc <fwp_p_ad_push+0x198>
    5568:	f940237c 	ldr	x28, [x27, #64]
    556c:	d37cee82 	lsl	x2, x20, #4
    5570:	aa0203e0 	mov	x0, x2
    5574:	52800041 	mov	w1, #0x2                   	// #2
    5578:	f9003fe2 	str	x2, [sp, #120]
    557c:	97fffec5 	bl	5090 <fwp_heap_alloc>
    5580:	aa0003fa 	mov	x26, x0
    5584:	b400013c 	cbz	x28, 55a8 <fwp_p_ad_push+0x174>
    5588:	a9470be3 	ldp	x3, x2, [sp, #112]
    558c:	aa1c03e1 	mov	x1, x28
    5590:	d37cec63 	lsl	x3, x3, #4
    5594:	eb02007f 	cmp	x3, x2
    5598:	9a829062 	csel	x2, x3, x2, ls	// ls = plast
    559c:	97fff431 	bl	2660 <memcpy@plt>
    55a0:	aa1c03e0 	mov	x0, x28
    55a4:	97fffd9b 	bl	4c10 <fwp_mem_free>
    55a8:	f9403360 	ldr	x0, [x27, #96]
    55ac:	52800001 	mov	w1, #0x0                   	// #0
    55b0:	cb000282 	sub	x2, x20, x0
    55b4:	8b001340 	add	x0, x26, x0, lsl #4
    55b8:	d37cec42 	lsl	x2, x2, #4
    55bc:	97fff489 	bl	27e0 <memset@plt>
    55c0:	f9401260 	ldr	x0, [x19, #32]
    55c4:	f900237a 	str	x26, [x27, #64]
    55c8:	f9003374 	str	x20, [x27, #96]
    55cc:	b50008b6 	cbnz	x22, 56e0 <fwp_p_ad_push+0x2ac>
    55d0:	a9431263 	ldp	x3, x4, [x19, #48]
    55d4:	d37ef69a 	lsl	x26, x20, #2
    55d8:	a94573fb 	ldp	x27, x28, [sp, #80]
    55dc:	8b1a0002 	add	x2, x0, x26
    55e0:	f9000e74 	str	x20, [x19, #24]
    55e4:	f9001662 	str	x2, [x19, #40]
    55e8:	b8366815 	str	w21, [x0, x22]
    55ec:	f100031f 	cmp	x24, #0x0
    55f0:	da9fa301 	csinv	x1, x24, xzr, ge	// ge = tcont
    55f4:	92607eb5 	and	x21, x21, #0xffffffff00000000
    55f8:	fc396869 	str	d9, [x3, x25]
    55fc:	aa1702a0 	orr	x0, x21, x23
    5600:	b8366841 	str	w1, [x2, x22]
    5604:	910006e1 	add	x1, x23, #0x1
    5608:	a9425bf5 	ldp	x21, x22, [sp, #32]
    560c:	fc396888 	str	d8, [x4, x25]
    5610:	a94363f7 	ldp	x23, x24, [sp, #48]
    5614:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5618:	6d4627e8 	ldp	d8, d9, [sp, #96]
    561c:	f9000a61 	str	x1, [x19, #16]
    5620:	a94153f3 	ldp	x19, x20, [sp, #16]
    5624:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5628:	d65f03c0 	ret
    562c:	9360fc54 	asr	x20, x2, #32
    5630:	eb80829f 	cmp	x20, x0, asr #32
    5634:	54fff2e0 	b.eq	5490 <fwp_p_ad_push+0x5c>  // b.none
    5638:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    563c:	9106e000 	add	x0, x0, #0x1b8
    5640:	a9046bf9 	stp	x25, x26, [sp, #64]
    5644:	a90573fb 	stp	x27, x28, [sp, #80]
    5648:	97fff84e 	bl	3780 <fwp_trap>
    564c:	d37ffa94 	lsl	x20, x20, #1
    5650:	17ffffb3 	b	551c <fwp_p_ad_push+0xe8>
    5654:	a9428e62 	ldp	x2, x3, [x19, #40]
    5658:	d37ef6d6 	lsl	x22, x22, #2
    565c:	f9401e64 	ldr	x4, [x19, #56]
    5660:	d37df339 	lsl	x25, x25, #3
    5664:	17ffffe1 	b	55e8 <fwp_p_ad_push+0x1b4>
    5668:	f94006d3 	ldr	x19, [x22, #8]
    566c:	17ffff93 	b	54b8 <fwp_p_ad_push+0x84>
    5670:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5674:	d65f03c0 	ret
    5678:	f9401a60 	ldr	x0, [x19, #48]
    567c:	d37cee81 	lsl	x1, x20, #4
    5680:	52800042 	mov	w2, #0x2                   	// #2
    5684:	97fffb54 	bl	43d4 <ad_raw_realloc>
    5688:	aa0003e3 	mov	x3, x0
    568c:	b4000600 	cbz	x0, 574c <fwp_p_ad_push+0x318>
    5690:	f9400e61 	ldr	x1, [x19, #24]
    5694:	8b1a0004 	add	x4, x0, x26
    5698:	8b010c01 	add	x1, x0, x1, lsl #3
    569c:	a9030660 	stp	x0, x1, [x19, #48]
    56a0:	b5000356 	cbnz	x22, 5708 <fwp_p_ad_push+0x2d4>
    56a4:	f9401260 	ldr	x0, [x19, #32]
    56a8:	d37ef69a 	lsl	x26, x20, #2
    56ac:	d2800016 	mov	x22, #0x0                   	// #0
    56b0:	f9001e64 	str	x4, [x19, #56]
    56b4:	17ffffc9 	b	55d8 <fwp_p_ad_push+0x1a4>
    56b8:	aa1403e0 	mov	x0, x20
    56bc:	97fff8fd 	bl	3ab0 <fwp_tape_of>
    56c0:	aa0003f3 	mov	x19, x0
    56c4:	f9403000 	ldr	x0, [x0, #96]
    56c8:	b4ffef80 	cbz	x0, 54b8 <fwp_p_ad_push+0x84>
    56cc:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    56d0:	91080000 	add	x0, x0, #0x200
    56d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    56d8:	a90573fb 	stp	x27, x28, [sp, #80]
    56dc:	97fff829 	bl	3780 <fwp_trap>
    56e0:	d37df2d9 	lsl	x25, x22, #3
    56e4:	f9401661 	ldr	x1, [x19, #40]
    56e8:	d37ef6d6 	lsl	x22, x22, #2
    56ec:	d37ef69a 	lsl	x26, x20, #2
    56f0:	aa1603e2 	mov	x2, x22
    56f4:	8b1a0000 	add	x0, x0, x26
    56f8:	97fff3e2 	bl	2680 <memmove@plt>
    56fc:	f9401260 	ldr	x0, [x19, #32]
    5700:	a9431263 	ldp	x3, x4, [x19, #48]
    5704:	17ffffb5 	b	55d8 <fwp_p_ad_push+0x1a4>
    5708:	d37df2d9 	lsl	x25, x22, #3
    570c:	aa0403e0 	mov	x0, x4
    5710:	aa1903e2 	mov	x2, x25
    5714:	97fff3db 	bl	2680 <memmove@plt>
    5718:	f9401a61 	ldr	x1, [x19, #48]
    571c:	f9401260 	ldr	x0, [x19, #32]
    5720:	8b1a0021 	add	x1, x1, x26
    5724:	f9001e61 	str	x1, [x19, #56]
    5728:	17ffffef 	b	56e4 <fwp_p_ad_push+0x2b0>
    572c:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    5730:	91094000 	add	x0, x0, #0x250
    5734:	a90573fb 	stp	x27, x28, [sp, #80]
    5738:	97fff812 	bl	3780 <fwp_trap>
    573c:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    5740:	9108c000 	add	x0, x0, #0x230
    5744:	a90573fb 	stp	x27, x28, [sp, #80]
    5748:	97fff80e 	bl	3780 <fwp_trap>
    574c:	aa1303e0 	mov	x0, x19
    5750:	97fff611 	bl	2f94 <fwp_tape_unlink_scope>
    5754:	f9401260 	ldr	x0, [x19, #32]
    5758:	b4000040 	cbz	x0, 5760 <fwp_p_ad_push+0x32c>
    575c:	97fffae9 	bl	4300 <ad_raw_free.part.0>
    5760:	f9401a60 	ldr	x0, [x19, #48]
    5764:	b4000040 	cbz	x0, 576c <fwp_p_ad_push+0x338>
    5768:	97fffae6 	bl	4300 <ad_raw_free.part.0>
    576c:	f9402260 	ldr	x0, [x19, #64]
    5770:	b4000040 	cbz	x0, 5778 <fwp_p_ad_push+0x344>
    5774:	97fffae3 	bl	4300 <ad_raw_free.part.0>
    5778:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    577c:	f947e821 	ldr	x1, [x1, #4048]
    5780:	f9000e7f 	str	xzr, [x19, #24]
    5784:	4f000400 	movi	v0.4s, #0x0
    5788:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    578c:	d2800262 	mov	x2, #0x13                  	// #19
    5790:	f9400023 	ldr	x3, [x1]
    5794:	b900067f 	str	wzr, [x19, #4]
    5798:	d2800021 	mov	x1, #0x1                   	// #1
    579c:	b0000020 	adrp	x0, a000 <fwp_main_thread+0x650>
    57a0:	9132e000 	add	x0, x0, #0xcb8
    57a4:	3c808260 	stur	q0, [x19, #8]
    57a8:	ad010260 	stp	q0, q0, [x19, #32]
    57ac:	97fff459 	bl	2910 <fwrite@plt>
    57b0:	d2800000 	mov	x0, #0x0                   	// #0
    57b4:	97fff463 	bl	2940 <fflush@plt>
    57b8:	52800cc0 	mov	w0, #0x66                  	// #102
    57bc:	97fff471 	bl	2980 <_Exit@plt>

00000000000057c0 <w107>:
    57c0:	d10203ff 	sub	sp, sp, #0x80
    57c4:	9e660003 	fmov	x3, d0
    57c8:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    57cc:	f947f442 	ldr	x2, [x2, #4072]
    57d0:	a9027bfd 	stp	x29, x30, [sp, #32]
    57d4:	910083fd 	add	x29, sp, #0x20
    57d8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57dc:	1e604009 	fmov	d9, d0
    57e0:	1e604028 	fmov	d8, d1
    57e4:	fd003bea 	str	d10, [sp, #112]
    57e8:	1e60080a 	fmul	d10, d0, d0
    57ec:	a90353f3 	stp	x19, x20, [sp, #48]
    57f0:	910023f3 	add	x19, sp, #0x8
    57f4:	aa0003f4 	mov	x20, x0
    57f8:	a9045bf5 	stp	x21, x22, [sp, #64]
    57fc:	aa0103f6 	mov	x22, x1
    5800:	92800015 	mov	x21, #0xffffffffffffffff    	// #-1
    5804:	a90563f7 	stp	x23, x24, [sp, #80]
    5808:	aa0303e1 	mov	x1, x3
    580c:	f9400044 	ldr	x4, [x2]
    5810:	f9000fe4 	str	x4, [sp, #24]
    5814:	d2800004 	mov	x4, #0x0                   	// #0
    5818:	aa0003e2 	mov	x2, x0
    581c:	aa1303e4 	mov	x4, x19
    5820:	a900fff5 	stp	x21, xzr, [sp, #8]
    5824:	97ffff04 	bl	5434 <fwp_p_ad_push>
    5828:	1e6a3908 	fsub	d8, d8, d10
    582c:	aa1603e2 	mov	x2, x22
    5830:	aa1303e4 	mov	x4, x19
    5834:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5838:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    583c:	9e660118 	fmov	x24, d8
    5840:	97fffefd 	bl	5434 <fwp_p_ad_push>
    5844:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5848:	aa0003f6 	mov	x22, x0
    584c:	aa1303e4 	mov	x4, x19
    5850:	aa1403e0 	mov	x0, x20
    5854:	1e69394a 	fsub	d10, d10, d9
    5858:	aa1503e2 	mov	x2, x21
    585c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5860:	d2f7fe01 	mov	x1, #0xbff0000000000000    	// #-4616189618054758400
    5864:	9e660157 	fmov	x23, d10
    5868:	97fffef3 	bl	5434 <fwp_p_ad_push>
    586c:	1e680908 	fmul	d8, d8, d8
    5870:	aa0003f4 	mov	x20, x0
    5874:	aa1303e4 	mov	x4, x19
    5878:	aa1803e3 	mov	x3, x24
    587c:	aa1803e1 	mov	x1, x24
    5880:	aa1603e2 	mov	x2, x22
    5884:	aa1603e0 	mov	x0, x22
    5888:	97fffeeb 	bl	5434 <fwp_p_ad_push>
    588c:	aa0003e2 	mov	x2, x0
    5890:	d2e80b21 	mov	x1, #0x4059000000000000    	// #4636737291354636288
    5894:	9e670029 	fmov	d9, x1
    5898:	9e660101 	fmov	x1, d8
    589c:	aa1303e4 	mov	x4, x19
    58a0:	1e690909 	fmul	d9, d8, d9
    58a4:	d2e80b23 	mov	x3, #0x4059000000000000    	// #4636737291354636288
    58a8:	aa1503e0 	mov	x0, x21
    58ac:	97fffee2 	bl	5434 <fwp_p_ad_push>
    58b0:	1e6a094a 	fmul	d10, d10, d10
    58b4:	aa1303e4 	mov	x4, x19
    58b8:	aa1703e3 	mov	x3, x23
    58bc:	aa0003f3 	mov	x19, x0
    58c0:	aa1703e1 	mov	x1, x23
    58c4:	aa1403e2 	mov	x2, x20
    58c8:	aa1403e0 	mov	x0, x20
    58cc:	97fffeda 	bl	5434 <fwp_p_ad_push>
    58d0:	1e6a2929 	fadd	d9, d9, d10
    58d4:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    58d8:	d2800004 	mov	x4, #0x0                   	// #0
    58dc:	aa0303e1 	mov	x1, x3
    58e0:	aa1303e2 	mov	x2, x19
    58e4:	97fffed4 	bl	5434 <fwp_p_ad_push>
    58e8:	aa0003e1 	mov	x1, x0
    58ec:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    58f0:	f947f463 	ldr	x3, [x3, #4072]
    58f4:	f9400fe0 	ldr	x0, [sp, #24]
    58f8:	f9400064 	ldr	x4, [x3]
    58fc:	eb040000 	subs	x0, x0, x4
    5900:	d2800004 	mov	x4, #0x0                   	// #0
    5904:	54000161 	b.ne	5930 <w107+0x170>  // b.any
    5908:	9e660122 	fmov	x2, d9
    590c:	fd403bea 	ldr	d10, [sp, #112]
    5910:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5914:	a94353f3 	ldp	x19, x20, [sp, #48]
    5918:	aa0203e0 	mov	x0, x2
    591c:	a9445bf5 	ldp	x21, x22, [sp, #64]
    5920:	a94563f7 	ldp	x23, x24, [sp, #80]
    5924:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5928:	910203ff 	add	sp, sp, #0x80
    592c:	d65f03c0 	ret
    5930:	97fff3b8 	bl	2810 <__stack_chk_fail@plt>

0000000000005934 <w164.constprop.0>:
    5934:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5938:	910003fd 	mov	x29, sp
    593c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5940:	fd001be8 	str	d8, [sp, #48]
    5944:	f9400015 	ldr	x21, [x0]
    5948:	b4000355 	cbz	x21, 59b0 <w164.constprop.0+0x7c>
    594c:	2f00e408 	movi	d8, #0x0
    5950:	91002016 	add	x22, x0, #0x8
    5954:	a90153f3 	stp	x19, x20, [sp, #16]
    5958:	91004014 	add	x20, x0, #0x10
    595c:	d2800013 	mov	x19, #0x0                   	// #0
    5960:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5964:	d503201f 	nop
    5968:	fc737ac0 	ldr	d0, [x22, x19, lsl #3]
    596c:	d2e7fe03 	mov	x3, #0x3ff0000000000000    	// #4607182418800017408
    5970:	f8737a82 	ldr	x2, [x20, x19, lsl #3]
    5974:	aa0303e1 	mov	x1, x3
    5978:	1e602908 	fadd	d8, d8, d0
    597c:	d2800004 	mov	x4, #0x0                   	// #0
    5980:	91000a73 	add	x19, x19, #0x2
    5984:	97fffeac 	bl	5434 <fwp_p_ad_push>
    5988:	eb1302bf 	cmp	x21, x19
    598c:	54fffee8 	b.hi	5968 <w164.constprop.0+0x34>  // b.pmore
    5990:	9e660102 	fmov	x2, d8
    5994:	fd401be8 	ldr	d8, [sp, #48]
    5998:	a94153f3 	ldp	x19, x20, [sp, #16]
    599c:	aa0003e1 	mov	x1, x0
    59a0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59a4:	aa0203e0 	mov	x0, x2
    59a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59ac:	d65f03c0 	ret
    59b0:	2f00e408 	movi	d8, #0x0
    59b4:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    59b8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    59bc:	aa0003e1 	mov	x1, x0
    59c0:	9e660102 	fmov	x2, d8
    59c4:	fd401be8 	ldr	d8, [sp, #48]
    59c8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    59cc:	aa0203e0 	mov	x0, x2
    59d0:	d65f03c0 	ret

00000000000059d4 <fwp_data.part.0.constprop.0>:
    59d4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    59d8:	910003fd 	mov	x29, sp
    59dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    59e0:	f00000d6 	adrp	x22, 20000 <__data_start>
    59e4:	910142c2 	add	x2, x22, #0x50
    59e8:	a9046bf9 	stp	x25, x26, [sp, #64]
    59ec:	b9413059 	ldr	w25, [x2, #304]
    59f0:	a90153f3 	stp	x19, x20, [sp, #16]
    59f4:	aa0103f4 	mov	x20, x1
    59f8:	a90363f7 	stp	x23, x24, [sp, #48]
    59fc:	2a0003f7 	mov	w23, w0
    5a00:	340000b9 	cbz	w25, 5a14 <fwp_data.part.0.constprop.0+0x40>
    5a04:	a9538041 	ldp	x1, x0, [x2, #312]
    5a08:	91000421 	add	x1, x1, #0x1
    5a0c:	91006000 	add	x0, x0, #0x18
    5a10:	a9138041 	stp	x1, x0, [x2, #312]
    5a14:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5a18:	9118c2a3 	add	x3, x21, #0x630
    5a1c:	b953a460 	ldr	w0, [x3, #5028]
    5a20:	34000840 	cbz	w0, 5b28 <fwp_data.part.0.constprop.0+0x154>
    5a24:	397e8862 	ldrb	w2, [x3, #4002]
    5a28:	910f0040 	add	x0, x2, #0x3c0
    5a2c:	8b020442 	add	x2, x2, x2, lsl #1
    5a30:	d37df042 	lsl	x2, x2, #3
    5a34:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5a38:	2a1a03f8 	mov	w24, w26
    5a3c:	f8626873 	ldr	x19, [x3, x2]
    5a40:	b4000613 	cbz	x19, 5b00 <fwp_data.part.0.constprop.0+0x12c>
    5a44:	f9400260 	ldr	x0, [x19]
    5a48:	aa2003e0 	mvn	x0, x0
    5a4c:	f8226860 	str	x0, [x3, x2]
    5a50:	f100631f 	cmp	x24, #0x18
    5a54:	540000e9 	b.ls	5a70 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5a58:	d1006702 	sub	x2, x24, #0x19
    5a5c:	91006260 	add	x0, x19, #0x18
    5a60:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5a64:	52800001 	mov	w1, #0x0                   	// #0
    5a68:	91002042 	add	x2, x2, #0x8
    5a6c:	97fff35d 	bl	27e0 <memset@plt>
    5a70:	9118c2a0 	add	x0, x21, #0x630
    5a74:	f94a1001 	ldr	x1, [x0, #5152]
    5a78:	ab180021 	adds	x1, x1, x24
    5a7c:	54000642 	b.cs	5b44 <fwp_data.part.0.constprop.0+0x170>  // b.hs, b.nlast
    5a80:	f94a1402 	ldr	x2, [x0, #5160]
    5a84:	f90a1001 	str	x1, [x0, #5152]
    5a88:	eb02003f 	cmp	x1, x2
    5a8c:	54000049 	b.ls	5a94 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5a90:	f90a1401 	str	x1, [x0, #5160]
    5a94:	9118c2a0 	add	x0, x21, #0x630
    5a98:	1e630341 	ucvtf	d1, w26
    5a9c:	fd4a1c00 	ldr	d0, [x0, #5176]
    5aa0:	1e612800 	fadd	d0, d0, d1
    5aa4:	fd0a1c00 	str	d0, [x0, #5176]
    5aa8:	34000139 	cbz	w25, 5acc <fwp_data.part.0.constprop.0+0xf8>
    5aac:	9118c2b5 	add	x21, x21, #0x630
    5ab0:	910142d6 	add	x22, x22, #0x50
    5ab4:	fd4a12a0 	ldr	d0, [x21, #5152]
    5ab8:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5abc:	7e61d800 	ucvtf	d0, d0
    5ac0:	1e623800 	fsub	d0, d0, d2
    5ac4:	1e612010 	fcmpe	d0, d1
    5ac8:	540003ac 	b.gt	5b3c <fwp_data.part.0.constprop.0+0x168>
    5acc:	52800040 	mov	w0, #0x2                   	// #2
    5ad0:	29000277 	stp	w23, w0, [x19]
    5ad4:	aa1303e0 	mov	x0, x19
    5ad8:	f9400281 	ldr	x1, [x20]
    5adc:	f9000661 	str	x1, [x19, #8]
    5ae0:	f9400681 	ldr	x1, [x20, #8]
    5ae4:	f9000a61 	str	x1, [x19, #16]
    5ae8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5af0:	a94363f7 	ldp	x23, x24, [sp, #48]
    5af4:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5af8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5afc:	d65f03c0 	ret
    5b00:	8b020063 	add	x3, x3, x2
    5b04:	f9400473 	ldr	x19, [x3, #8]
    5b08:	b4000113 	cbz	x19, 5b28 <fwp_data.part.0.constprop.0+0x154>
    5b0c:	f9400860 	ldr	x0, [x3, #16]
    5b10:	cb130000 	sub	x0, x0, x19
    5b14:	eb00031f 	cmp	x24, x0
    5b18:	54000088 	b.hi	5b28 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5b1c:	8b180260 	add	x0, x19, x24
    5b20:	f9000460 	str	x0, [x3, #8]
    5b24:	17ffffcb 	b	5a50 <fwp_data.part.0.constprop.0+0x7c>
    5b28:	52800001 	mov	w1, #0x0                   	// #0
    5b2c:	d2800300 	mov	x0, #0x18                  	// #24
    5b30:	97fffd58 	bl	5090 <fwp_heap_alloc>
    5b34:	aa0003f3 	mov	x19, x0
    5b38:	17ffffdc 	b	5aa8 <fwp_data.part.0.constprop.0+0xd4>
    5b3c:	fd00aac0 	str	d0, [x22, #336]
    5b40:	17ffffe3 	b	5acc <fwp_data.part.0.constprop.0+0xf8>
    5b44:	97fff56b 	bl	30f0 <fwp_heap_oom>
    5b48:	d503201f 	nop
    5b4c:	d503201f 	nop

0000000000005b50 <fwp_rc_share>:
    5b50:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5b54:	9118c042 	add	x2, x2, #0x630
    5b58:	f949d843 	ldr	x3, [x2, #5040]
    5b5c:	f949ec41 	ldr	x1, [x2, #5080]
    5b60:	cb030000 	sub	x0, x0, x3
    5b64:	eb01401f 	cmp	x0, x1, lsl #16
    5b68:	540002c2 	b.cs	5bc0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5b6c:	d350fc01 	lsr	x1, x0, #16
    5b70:	f949fc44 	ldr	x4, [x2, #5112]
    5b74:	8b010821 	add	x1, x1, x1, lsl #2
    5b78:	d37df021 	lsl	x1, x1, #3
    5b7c:	8b010083 	add	x3, x4, x1
    5b80:	f9401062 	ldr	x2, [x3, #32]
    5b84:	b40001e2 	cbz	x2, 5bc0 <fwp_rc_share+0x70>
    5b88:	38616881 	ldrb	w1, [x4, x1]
    5b8c:	7100083f 	cmp	w1, #0x2
    5b90:	540001a0 	b.eq	5bc4 <fwp_rc_share+0x74>  // b.none
    5b94:	7100043f 	cmp	w1, #0x1
    5b98:	54000141 	b.ne	5bc0 <fwp_rc_share+0x70>  // b.any
    5b9c:	29430464 	ldp	w4, w1, [x3, #24]
    5ba0:	92403c00 	and	x0, x0, #0xffff
    5ba4:	9b047c00 	mul	x0, x0, x4
    5ba8:	d360fc00 	lsr	x0, x0, #32
    5bac:	eb01001f 	cmp	x0, x1
    5bb0:	54000082 	b.cs	5bc0 <fwp_rc_share+0x70>  // b.hs, b.nlast
    5bb4:	8b000042 	add	x2, x2, x0
    5bb8:	39400040 	ldrb	w0, [x2]
    5bbc:	350000a0 	cbnz	w0, 5bd0 <fwp_rc_share+0x80>
    5bc0:	d65f03c0 	ret
    5bc4:	72003c1f 	tst	w0, #0xffff
    5bc8:	54ffff80 	b.eq	5bb8 <fwp_rc_share+0x68>  // b.none
    5bcc:	d65f03c0 	ret
    5bd0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5bd4:	d0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    5bd8:	9109c000 	add	x0, x0, #0x270
    5bdc:	910003fd 	mov	x29, sp
    5be0:	97fff6e8 	bl	3780 <fwp_trap>

0000000000005be4 <fwp_rc_free_arr>:
    5be4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5be8:	9118c063 	add	x3, x3, #0x630
    5bec:	f949d861 	ldr	x1, [x3, #5040]
    5bf0:	f949ec62 	ldr	x2, [x3, #5080]
    5bf4:	cb010001 	sub	x1, x0, x1
    5bf8:	eb02403f 	cmp	x1, x2, lsl #16
    5bfc:	54000342 	b.cs	5c64 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c00:	d350fc22 	lsr	x2, x1, #16
    5c04:	f949fc65 	ldr	x5, [x3, #5112]
    5c08:	8b020842 	add	x2, x2, x2, lsl #2
    5c0c:	d37df042 	lsl	x2, x2, #3
    5c10:	8b0200a4 	add	x4, x5, x2
    5c14:	f9401083 	ldr	x3, [x4, #32]
    5c18:	b4000263 	cbz	x3, 5c64 <fwp_rc_free_arr+0x80>
    5c1c:	386268a2 	ldrb	w2, [x5, x2]
    5c20:	7100085f 	cmp	w2, #0x2
    5c24:	540001c0 	b.eq	5c5c <fwp_rc_free_arr+0x78>  // b.none
    5c28:	7100045f 	cmp	w2, #0x1
    5c2c:	540001c1 	b.ne	5c64 <fwp_rc_free_arr+0x80>  // b.any
    5c30:	29430885 	ldp	w5, w2, [x4, #24]
    5c34:	92403c21 	and	x1, x1, #0xffff
    5c38:	9b057c21 	mul	x1, x1, x5
    5c3c:	d360fc21 	lsr	x1, x1, #32
    5c40:	eb02003f 	cmp	x1, x2
    5c44:	54000102 	b.cs	5c64 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5c48:	8b010063 	add	x3, x3, x1
    5c4c:	39400061 	ldrb	w1, [x3]
    5c50:	7100043f 	cmp	w1, #0x1
    5c54:	54000081 	b.ne	5c64 <fwp_rc_free_arr+0x80>  // b.any
    5c58:	17fffbee 	b	4c10 <fwp_mem_free>
    5c5c:	72003c3f 	tst	w1, #0xffff
    5c60:	54ffff60 	b.eq	5c4c <fwp_rc_free_arr+0x68>  // b.none
    5c64:	d65f03c0 	ret
    5c68:	d503201f 	nop
    5c6c:	d503201f 	nop

0000000000005c70 <fwp_rc_dup>:
    5c70:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5c74:	9118c042 	add	x2, x2, #0x630
    5c78:	f949d841 	ldr	x1, [x2, #5040]
    5c7c:	f949ec43 	ldr	x3, [x2, #5080]
    5c80:	cb010001 	sub	x1, x0, x1
    5c84:	eb03403f 	cmp	x1, x3, lsl #16
    5c88:	540003c2 	b.cs	5d00 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5c8c:	d350fc20 	lsr	x0, x1, #16
    5c90:	f949fc44 	ldr	x4, [x2, #5112]
    5c94:	8b000800 	add	x0, x0, x0, lsl #2
    5c98:	d37df002 	lsl	x2, x0, #3
    5c9c:	8b020083 	add	x3, x4, x2
    5ca0:	f9401060 	ldr	x0, [x3, #32]
    5ca4:	b40002e0 	cbz	x0, 5d00 <fwp_rc_dup+0x90>
    5ca8:	38626882 	ldrb	w2, [x4, x2]
    5cac:	7100085f 	cmp	w2, #0x2
    5cb0:	540002a0 	b.eq	5d04 <fwp_rc_dup+0x94>  // b.none
    5cb4:	7100045f 	cmp	w2, #0x1
    5cb8:	54000241 	b.ne	5d00 <fwp_rc_dup+0x90>  // b.any
    5cbc:	29430864 	ldp	w4, w2, [x3, #24]
    5cc0:	92403c21 	and	x1, x1, #0xffff
    5cc4:	9b047c21 	mul	x1, x1, x4
    5cc8:	d360fc21 	lsr	x1, x1, #32
    5ccc:	eb02003f 	cmp	x1, x2
    5cd0:	54000182 	b.cs	5d00 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5cd4:	8b010000 	add	x0, x0, x1
    5cd8:	39400001 	ldrb	w1, [x0]
    5cdc:	34000121 	cbz	w1, 5d00 <fwp_rc_dup+0x90>
    5ce0:	f00000c2 	adrp	x2, 20000 <__data_start>
    5ce4:	91014042 	add	x2, x2, #0x50
    5ce8:	b9413043 	ldr	w3, [x2, #304]
    5cec:	35000123 	cbnz	w3, 5d10 <fwp_rc_dup+0xa0>
    5cf0:	7103f43f 	cmp	w1, #0xfd
    5cf4:	54000168 	b.hi	5d20 <fwp_rc_dup+0xb0>  // b.pmore
    5cf8:	11000421 	add	w1, w1, #0x1
    5cfc:	39000001 	strb	w1, [x0]
    5d00:	d65f03c0 	ret
    5d04:	72003c3f 	tst	w1, #0xffff
    5d08:	54fffe80 	b.eq	5cd8 <fwp_rc_dup+0x68>  // b.none
    5d0c:	d65f03c0 	ret
    5d10:	f940ac43 	ldr	x3, [x2, #344]
    5d14:	91000463 	add	x3, x3, #0x1
    5d18:	f900ac43 	str	x3, [x2, #344]
    5d1c:	17fffff5 	b	5cf0 <fwp_rc_dup+0x80>
    5d20:	17fffad5 	b	4874 <fwp_rc_wide_dup>

0000000000005d24 <fwp_owned_entry161>:
    5d24:	d10103ff 	sub	sp, sp, #0x40
    5d28:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5d2c:	f947f442 	ldr	x2, [x2, #4072]
    5d30:	a9027bfd 	stp	x29, x30, [sp, #32]
    5d34:	910083fd 	add	x29, sp, #0x20
    5d38:	a90353f3 	stp	x19, x20, [sp, #48]
    5d3c:	f9400043 	ldr	x3, [x2]
    5d40:	f9000fe3 	str	x3, [sp, #24]
    5d44:	d2800003 	mov	x3, #0x0                   	// #0
    5d48:	a9400c01 	ldp	x1, x3, [x0]
    5d4c:	f9400802 	ldr	x2, [x0, #16]
    5d50:	ab020022 	adds	x2, x1, x2
    5d54:	540006e6 	b.vs	5e30 <fwp_owned_entry161+0x10c>
    5d58:	910023e1 	add	x1, sp, #0x8
    5d5c:	52800000 	mov	w0, #0x0                   	// #0
    5d60:	a9008be3 	stp	x3, x2, [sp, #8]
    5d64:	97ffff1c 	bl	59d4 <fwp_data.part.0.constprop.0>
    5d68:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5d6c:	9118c063 	add	x3, x3, #0x630
    5d70:	aa0003f3 	mov	x19, x0
    5d74:	f949d861 	ldr	x1, [x3, #5040]
    5d78:	f949ec60 	ldr	x0, [x3, #5080]
    5d7c:	cb010261 	sub	x1, x19, x1
    5d80:	eb00403f 	cmp	x1, x0, lsl #16
    5d84:	54000322 	b.cs	5de8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5d88:	d350fc22 	lsr	x2, x1, #16
    5d8c:	f949fc63 	ldr	x3, [x3, #5112]
    5d90:	8b020842 	add	x2, x2, x2, lsl #2
    5d94:	d37df042 	lsl	x2, x2, #3
    5d98:	8b020060 	add	x0, x3, x2
    5d9c:	f9401014 	ldr	x20, [x0, #32]
    5da0:	b4000254 	cbz	x20, 5de8 <fwp_owned_entry161+0xc4>
    5da4:	38626862 	ldrb	w2, [x3, x2]
    5da8:	7100085f 	cmp	w2, #0x2
    5dac:	54000360 	b.eq	5e18 <fwp_owned_entry161+0xf4>  // b.none
    5db0:	7100045f 	cmp	w2, #0x1
    5db4:	540001a1 	b.ne	5de8 <fwp_owned_entry161+0xc4>  // b.any
    5db8:	29430002 	ldp	w2, w0, [x0, #24]
    5dbc:	92403c21 	and	x1, x1, #0xffff
    5dc0:	9b027c21 	mul	x1, x1, x2
    5dc4:	d360fc21 	lsr	x1, x1, #32
    5dc8:	eb00003f 	cmp	x1, x0
    5dcc:	540000e2 	b.cs	5de8 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5dd0:	8b010294 	add	x20, x20, x1
    5dd4:	39400280 	ldrb	w0, [x20]
    5dd8:	7103fc1f 	cmp	w0, #0xff
    5ddc:	54000240 	b.eq	5e24 <fwp_owned_entry161+0x100>  // b.none
    5de0:	52800020 	mov	w0, #0x1                   	// #1
    5de4:	39000280 	strb	w0, [x20]
    5de8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5dec:	f947f400 	ldr	x0, [x0, #4072]
    5df0:	f9400fe2 	ldr	x2, [sp, #24]
    5df4:	f9400001 	ldr	x1, [x0]
    5df8:	eb010042 	subs	x2, x2, x1
    5dfc:	d2800001 	mov	x1, #0x0                   	// #0
    5e00:	540001a1 	b.ne	5e34 <fwp_owned_entry161+0x110>  // b.any
    5e04:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5e08:	aa1303e0 	mov	x0, x19
    5e0c:	a94353f3 	ldp	x19, x20, [sp, #48]
    5e10:	910103ff 	add	sp, sp, #0x40
    5e14:	d65f03c0 	ret
    5e18:	72003c3f 	tst	w1, #0xffff
    5e1c:	54fffe61 	b.ne	5de8 <fwp_owned_entry161+0xc4>  // b.any
    5e20:	17ffffed 	b	5dd4 <fwp_owned_entry161+0xb0>
    5e24:	aa1403e0 	mov	x0, x20
    5e28:	97fffada 	bl	4990 <fwp_rc_forget_slot>
    5e2c:	17ffffed 	b	5de0 <fwp_owned_entry161+0xbc>
    5e30:	97fff2f4 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5e34:	97fff277 	bl	2810 <__stack_chk_fail@plt>
    5e38:	d503201f 	nop
    5e3c:	d503201f 	nop

0000000000005e40 <e161>:
    5e40:	d10103ff 	sub	sp, sp, #0x40
    5e44:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5e48:	f947f442 	ldr	x2, [x2, #4072]
    5e4c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5e50:	910083fd 	add	x29, sp, #0x20
    5e54:	a90353f3 	stp	x19, x20, [sp, #48]
    5e58:	f9400043 	ldr	x3, [x2]
    5e5c:	f9000fe3 	str	x3, [sp, #24]
    5e60:	d2800003 	mov	x3, #0x0                   	// #0
    5e64:	a9400c01 	ldp	x1, x3, [x0]
    5e68:	f9400802 	ldr	x2, [x0, #16]
    5e6c:	ab020022 	adds	x2, x1, x2
    5e70:	54000726 	b.vs	5f54 <e161+0x114>
    5e74:	910023e1 	add	x1, sp, #0x8
    5e78:	52800000 	mov	w0, #0x0                   	// #0
    5e7c:	a9008be3 	stp	x3, x2, [sp, #8]
    5e80:	97fffed5 	bl	59d4 <fwp_data.part.0.constprop.0>
    5e84:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5e88:	9118c063 	add	x3, x3, #0x630
    5e8c:	aa0003f3 	mov	x19, x0
    5e90:	f949d861 	ldr	x1, [x3, #5040]
    5e94:	f949ec60 	ldr	x0, [x3, #5080]
    5e98:	cb010261 	sub	x1, x19, x1
    5e9c:	eb00403f 	cmp	x1, x0, lsl #16
    5ea0:	54000322 	b.cs	5f04 <e161+0xc4>  // b.hs, b.nlast
    5ea4:	d350fc22 	lsr	x2, x1, #16
    5ea8:	f949fc63 	ldr	x3, [x3, #5112]
    5eac:	8b020842 	add	x2, x2, x2, lsl #2
    5eb0:	d37df042 	lsl	x2, x2, #3
    5eb4:	8b020060 	add	x0, x3, x2
    5eb8:	f9401014 	ldr	x20, [x0, #32]
    5ebc:	b4000254 	cbz	x20, 5f04 <e161+0xc4>
    5ec0:	38626862 	ldrb	w2, [x3, x2]
    5ec4:	7100085f 	cmp	w2, #0x2
    5ec8:	540003a0 	b.eq	5f3c <e161+0xfc>  // b.none
    5ecc:	7100045f 	cmp	w2, #0x1
    5ed0:	540001a1 	b.ne	5f04 <e161+0xc4>  // b.any
    5ed4:	29430002 	ldp	w2, w0, [x0, #24]
    5ed8:	92403c21 	and	x1, x1, #0xffff
    5edc:	9b027c21 	mul	x1, x1, x2
    5ee0:	d360fc21 	lsr	x1, x1, #32
    5ee4:	eb00003f 	cmp	x1, x0
    5ee8:	540000e2 	b.cs	5f04 <e161+0xc4>  // b.hs, b.nlast
    5eec:	8b010294 	add	x20, x20, x1
    5ef0:	39400280 	ldrb	w0, [x20]
    5ef4:	7103fc1f 	cmp	w0, #0xff
    5ef8:	54000280 	b.eq	5f48 <e161+0x108>  // b.none
    5efc:	52800020 	mov	w0, #0x1                   	// #1
    5f00:	39000280 	strb	w0, [x20]
    5f04:	aa1303e0 	mov	x0, x19
    5f08:	97ffff12 	bl	5b50 <fwp_rc_share>
    5f0c:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    5f10:	f947f400 	ldr	x0, [x0, #4072]
    5f14:	f9400fe2 	ldr	x2, [sp, #24]
    5f18:	f9400001 	ldr	x1, [x0]
    5f1c:	eb010042 	subs	x2, x2, x1
    5f20:	d2800001 	mov	x1, #0x0                   	// #0
    5f24:	540001a1 	b.ne	5f58 <e161+0x118>  // b.any
    5f28:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5f2c:	aa1303e0 	mov	x0, x19
    5f30:	a94353f3 	ldp	x19, x20, [sp, #48]
    5f34:	910103ff 	add	sp, sp, #0x40
    5f38:	d65f03c0 	ret
    5f3c:	72003c3f 	tst	w1, #0xffff
    5f40:	54fffe21 	b.ne	5f04 <e161+0xc4>  // b.any
    5f44:	17ffffeb 	b	5ef0 <e161+0xb0>
    5f48:	aa1403e0 	mov	x0, x20
    5f4c:	97fffa91 	bl	4990 <fwp_rc_forget_slot>
    5f50:	17ffffeb 	b	5efc <e161+0xbc>
    5f54:	97fff2ab 	bl	2a00 <fwp_trap_overflow.constprop.0>
    5f58:	97fff22e 	bl	2810 <__stack_chk_fail@plt>
    5f5c:	d503201f 	nop

0000000000005f60 <fwp_drop0>:
    5f60:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5f64:	910003fd 	mov	x29, sp
    5f68:	a90153f3 	stp	x19, x20, [sp, #16]
    5f6c:	f90013f5 	str	x21, [sp, #32]
    5f70:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5f74:	9118c2b4 	add	x20, x21, #0x630
    5f78:	f949da81 	ldr	x1, [x20, #5040]
    5f7c:	f949ee82 	ldr	x2, [x20, #5080]
    5f80:	cb010001 	sub	x1, x0, x1
    5f84:	eb02403f 	cmp	x1, x2, lsl #16
    5f88:	54000382 	b.cs	5ff8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5f8c:	d350fc22 	lsr	x2, x1, #16
    5f90:	f949fe84 	ldr	x4, [x20, #5112]
    5f94:	8b020842 	add	x2, x2, x2, lsl #2
    5f98:	d37df042 	lsl	x2, x2, #3
    5f9c:	8b020083 	add	x3, x4, x2
    5fa0:	f9401073 	ldr	x19, [x3, #32]
    5fa4:	b40002b3 	cbz	x19, 5ff8 <fwp_drop0+0x98>
    5fa8:	38626882 	ldrb	w2, [x4, x2]
    5fac:	7100085f 	cmp	w2, #0x2
    5fb0:	540002c0 	b.eq	6008 <fwp_drop0+0xa8>  // b.none
    5fb4:	7100045f 	cmp	w2, #0x1
    5fb8:	54000201 	b.ne	5ff8 <fwp_drop0+0x98>  // b.any
    5fbc:	29430864 	ldp	w4, w2, [x3, #24]
    5fc0:	92403c21 	and	x1, x1, #0xffff
    5fc4:	9b047c21 	mul	x1, x1, x4
    5fc8:	d360fc21 	lsr	x1, x1, #32
    5fcc:	eb02003f 	cmp	x1, x2
    5fd0:	54000142 	b.cs	5ff8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5fd4:	8b010273 	add	x19, x19, x1
    5fd8:	39400261 	ldrb	w1, [x19]
    5fdc:	340000e1 	cbz	w1, 5ff8 <fwp_drop0+0x98>
    5fe0:	7100043f 	cmp	w1, #0x1
    5fe4:	540001e0 	b.eq	6020 <fwp_drop0+0xc0>  // b.none
    5fe8:	7103fc3f 	cmp	w1, #0xff
    5fec:	540002e0 	b.eq	6048 <fwp_drop0+0xe8>  // b.none
    5ff0:	51000421 	sub	w1, w1, #0x1
    5ff4:	39000261 	strb	w1, [x19]
    5ff8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5ffc:	f94013f5 	ldr	x21, [sp, #32]
    6000:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6004:	d65f03c0 	ret
    6008:	72003c3f 	tst	w1, #0xffff
    600c:	54fffe60 	b.eq	5fd8 <fwp_drop0+0x78>  // b.none
    6010:	a94153f3 	ldp	x19, x20, [sp, #16]
    6014:	f94013f5 	ldr	x21, [sp, #32]
    6018:	a8c37bfd 	ldp	x29, x30, [sp], #48
    601c:	d65f03c0 	ret
    6020:	f9400813 	ldr	x19, [x0, #16]
    6024:	97fffef0 	bl	5be4 <fwp_rc_free_arr>
    6028:	9118c2a0 	add	x0, x21, #0x630
    602c:	f949d801 	ldr	x1, [x0, #5040]
    6030:	f949ec00 	ldr	x0, [x0, #5080]
    6034:	cb010261 	sub	x1, x19, x1
    6038:	eb00403f 	cmp	x1, x0, lsl #16
    603c:	54fffde2 	b.cs	5ff8 <fwp_drop0+0x98>  // b.hs, b.nlast
    6040:	aa1303e0 	mov	x0, x19
    6044:	17ffffd2 	b	5f8c <fwp_drop0+0x2c>
    6048:	ca534660 	eor	x0, x19, x19, lsr #17
    604c:	9118c2b5 	add	x21, x21, #0x630
    6050:	ca402400 	eor	x0, x0, x0, lsr #9
    6054:	8b200ea0 	add	x0, x21, w0, uxtb #3
    6058:	f94a2400 	ldr	x0, [x0, #5192]
    605c:	b5000080 	cbnz	x0, 606c <fwp_drop0+0x10c>
    6060:	14000010 	b	60a0 <fwp_drop0+0x140>
    6064:	f9400800 	ldr	x0, [x0, #16]
    6068:	b40001c0 	cbz	x0, 60a0 <fwp_drop0+0x140>
    606c:	f9400001 	ldr	x1, [x0]
    6070:	eb13003f 	cmp	x1, x19
    6074:	54ffff81 	b.ne	6064 <fwp_drop0+0x104>  // b.any
    6078:	f9400401 	ldr	x1, [x0, #8]
    607c:	d1000421 	sub	x1, x1, #0x1
    6080:	f9000401 	str	x1, [x0, #8]
    6084:	f103f83f 	cmp	x1, #0xfe
    6088:	54fffb81 	b.ne	5ff8 <fwp_drop0+0x98>  // b.any
    608c:	aa1303e0 	mov	x0, x19
    6090:	97fffa40 	bl	4990 <fwp_rc_forget_slot>
    6094:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6098:	39000260 	strb	w0, [x19]
    609c:	17ffffd7 	b	5ff8 <fwp_drop0+0x98>
    60a0:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    60a4:	9105c000 	add	x0, x0, #0x170
    60a8:	97fff5b6 	bl	3780 <fwp_trap>
    60ac:	d503201f 	nop

00000000000060b0 <fwp_arg_drop12>:
    60b0:	7100003f 	cmp	w1, #0x0
    60b4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    60b8:	54000041 	b.ne	60c0 <fwp_arg_drop12+0x10>  // b.any
    60bc:	d65f03c0 	ret
    60c0:	f9400000 	ldr	x0, [x0]
    60c4:	17ffffa7 	b	5f60 <fwp_drop0>
    60c8:	d503201f 	nop
    60cc:	d503201f 	nop

00000000000060d0 <fwp_drop1>:
    60d0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    60d4:	910003fd 	mov	x29, sp
    60d8:	a90153f3 	stp	x19, x20, [sp, #16]
    60dc:	f90013f5 	str	x21, [sp, #32]
    60e0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    60e4:	9118c2b4 	add	x20, x21, #0x630
    60e8:	f949da81 	ldr	x1, [x20, #5040]
    60ec:	f949ee82 	ldr	x2, [x20, #5080]
    60f0:	cb010001 	sub	x1, x0, x1
    60f4:	eb02403f 	cmp	x1, x2, lsl #16
    60f8:	54000382 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    60fc:	d350fc22 	lsr	x2, x1, #16
    6100:	f949fe84 	ldr	x4, [x20, #5112]
    6104:	8b020842 	add	x2, x2, x2, lsl #2
    6108:	d37df042 	lsl	x2, x2, #3
    610c:	8b020083 	add	x3, x4, x2
    6110:	f9401073 	ldr	x19, [x3, #32]
    6114:	b40002b3 	cbz	x19, 6168 <fwp_drop1+0x98>
    6118:	38626882 	ldrb	w2, [x4, x2]
    611c:	7100085f 	cmp	w2, #0x2
    6120:	540002c0 	b.eq	6178 <fwp_drop1+0xa8>  // b.none
    6124:	7100045f 	cmp	w2, #0x1
    6128:	54000201 	b.ne	6168 <fwp_drop1+0x98>  // b.any
    612c:	29430864 	ldp	w4, w2, [x3, #24]
    6130:	92403c21 	and	x1, x1, #0xffff
    6134:	9b047c21 	mul	x1, x1, x4
    6138:	d360fc21 	lsr	x1, x1, #32
    613c:	eb02003f 	cmp	x1, x2
    6140:	54000142 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    6144:	8b010273 	add	x19, x19, x1
    6148:	39400261 	ldrb	w1, [x19]
    614c:	340000e1 	cbz	w1, 6168 <fwp_drop1+0x98>
    6150:	7100043f 	cmp	w1, #0x1
    6154:	540001e0 	b.eq	6190 <fwp_drop1+0xc0>  // b.none
    6158:	7103fc3f 	cmp	w1, #0xff
    615c:	540002e0 	b.eq	61b8 <fwp_drop1+0xe8>  // b.none
    6160:	51000421 	sub	w1, w1, #0x1
    6164:	39000261 	strb	w1, [x19]
    6168:	a94153f3 	ldp	x19, x20, [sp, #16]
    616c:	f94013f5 	ldr	x21, [sp, #32]
    6170:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6174:	d65f03c0 	ret
    6178:	72003c3f 	tst	w1, #0xffff
    617c:	54fffe60 	b.eq	6148 <fwp_drop1+0x78>  // b.none
    6180:	a94153f3 	ldp	x19, x20, [sp, #16]
    6184:	f94013f5 	ldr	x21, [sp, #32]
    6188:	a8c37bfd 	ldp	x29, x30, [sp], #48
    618c:	d65f03c0 	ret
    6190:	f9400813 	ldr	x19, [x0, #16]
    6194:	97fffe94 	bl	5be4 <fwp_rc_free_arr>
    6198:	9118c2a0 	add	x0, x21, #0x630
    619c:	f949d801 	ldr	x1, [x0, #5040]
    61a0:	f949ec00 	ldr	x0, [x0, #5080]
    61a4:	cb010261 	sub	x1, x19, x1
    61a8:	eb00403f 	cmp	x1, x0, lsl #16
    61ac:	54fffde2 	b.cs	6168 <fwp_drop1+0x98>  // b.hs, b.nlast
    61b0:	aa1303e0 	mov	x0, x19
    61b4:	17ffffd2 	b	60fc <fwp_drop1+0x2c>
    61b8:	ca534660 	eor	x0, x19, x19, lsr #17
    61bc:	9118c2b5 	add	x21, x21, #0x630
    61c0:	ca402400 	eor	x0, x0, x0, lsr #9
    61c4:	8b200ea0 	add	x0, x21, w0, uxtb #3
    61c8:	f94a2400 	ldr	x0, [x0, #5192]
    61cc:	b5000080 	cbnz	x0, 61dc <fwp_drop1+0x10c>
    61d0:	14000010 	b	6210 <fwp_drop1+0x140>
    61d4:	f9400800 	ldr	x0, [x0, #16]
    61d8:	b40001c0 	cbz	x0, 6210 <fwp_drop1+0x140>
    61dc:	f9400001 	ldr	x1, [x0]
    61e0:	eb13003f 	cmp	x1, x19
    61e4:	54ffff81 	b.ne	61d4 <fwp_drop1+0x104>  // b.any
    61e8:	f9400401 	ldr	x1, [x0, #8]
    61ec:	d1000421 	sub	x1, x1, #0x1
    61f0:	f9000401 	str	x1, [x0, #8]
    61f4:	f103f83f 	cmp	x1, #0xfe
    61f8:	54fffb81 	b.ne	6168 <fwp_drop1+0x98>  // b.any
    61fc:	aa1303e0 	mov	x0, x19
    6200:	97fff9e4 	bl	4990 <fwp_rc_forget_slot>
    6204:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6208:	39000260 	strb	w0, [x19]
    620c:	17ffffd7 	b	6168 <fwp_drop1+0x98>
    6210:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    6214:	9105c000 	add	x0, x0, #0x170
    6218:	97fff55a 	bl	3780 <fwp_trap>
    621c:	d503201f 	nop

0000000000006220 <fwp_closure_drop>:
    6220:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    6224:	9118c0a4 	add	x4, x5, #0x630
    6228:	aa0003e1 	mov	x1, x0
    622c:	f949d882 	ldr	x2, [x4, #5040]
    6230:	f949ec80 	ldr	x0, [x4, #5080]
    6234:	cb020022 	sub	x2, x1, x2
    6238:	eb00405f 	cmp	x2, x0, lsl #16
    623c:	54000662 	b.cs	6308 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    6240:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6244:	d350fc43 	lsr	x3, x2, #16
    6248:	910003fd 	mov	x29, sp
    624c:	8b030863 	add	x3, x3, x3, lsl #2
    6250:	f949fc84 	ldr	x4, [x4, #5112]
    6254:	d37df063 	lsl	x3, x3, #3
    6258:	f9000bf3 	str	x19, [sp, #16]
    625c:	8b030080 	add	x0, x4, x3
    6260:	f9401013 	ldr	x19, [x0, #32]
    6264:	b40002b3 	cbz	x19, 62b8 <fwp_closure_drop+0x98>
    6268:	38636883 	ldrb	w3, [x4, x3]
    626c:	7100087f 	cmp	w3, #0x2
    6270:	54000420 	b.eq	62f4 <fwp_closure_drop+0xd4>  // b.none
    6274:	7100047f 	cmp	w3, #0x1
    6278:	54000201 	b.ne	62b8 <fwp_closure_drop+0x98>  // b.any
    627c:	29430003 	ldp	w3, w0, [x0, #24]
    6280:	92403c42 	and	x2, x2, #0xffff
    6284:	9b037c42 	mul	x2, x2, x3
    6288:	d360fc42 	lsr	x2, x2, #32
    628c:	eb00005f 	cmp	x2, x0
    6290:	54000142 	b.cs	62b8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6294:	8b020273 	add	x19, x19, x2
    6298:	39400260 	ldrb	w0, [x19]
    629c:	340000e0 	cbz	w0, 62b8 <fwp_closure_drop+0x98>
    62a0:	7100041f 	cmp	w0, #0x1
    62a4:	54000100 	b.eq	62c4 <fwp_closure_drop+0xa4>  // b.none
    62a8:	7103fc1f 	cmp	w0, #0xff
    62ac:	54000300 	b.eq	630c <fwp_closure_drop+0xec>  // b.none
    62b0:	51000400 	sub	w0, w0, #0x1
    62b4:	39000260 	strb	w0, [x19]
    62b8:	f9400bf3 	ldr	x19, [sp, #16]
    62bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62c0:	d65f03c0 	ret
    62c4:	d53bd040 	mrs	x0, tpidr_el0
    62c8:	91400000 	add	x0, x0, #0x0, lsl #12
    62cc:	91004000 	add	x0, x0, #0x10
    62d0:	f9400000 	ldr	x0, [x0]
    62d4:	b4000080 	cbz	x0, 62e4 <fwp_closure_drop+0xc4>
    62d8:	f9400bf3 	ldr	x19, [sp, #16]
    62dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62e0:	17fff541 	b	37e4 <fwp_closure_drop_push>
    62e4:	f9400bf3 	ldr	x19, [sp, #16]
    62e8:	aa0103e0 	mov	x0, x1
    62ec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    62f0:	17fff5ac 	b	39a0 <fwp_closure_drop.part.0>
    62f4:	72003c5f 	tst	w2, #0xffff
    62f8:	54fffd00 	b.eq	6298 <fwp_closure_drop+0x78>  // b.none
    62fc:	f9400bf3 	ldr	x19, [sp, #16]
    6300:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6304:	d65f03c0 	ret
    6308:	d65f03c0 	ret
    630c:	ca534660 	eor	x0, x19, x19, lsr #17
    6310:	9118c0a5 	add	x5, x5, #0x630
    6314:	ca402400 	eor	x0, x0, x0, lsr #9
    6318:	8b200ca0 	add	x0, x5, w0, uxtb #3
    631c:	f94a2400 	ldr	x0, [x0, #5192]
    6320:	b5000080 	cbnz	x0, 6330 <fwp_closure_drop+0x110>
    6324:	14000010 	b	6364 <fwp_closure_drop+0x144>
    6328:	f9400800 	ldr	x0, [x0, #16]
    632c:	b40001c0 	cbz	x0, 6364 <fwp_closure_drop+0x144>
    6330:	f9400001 	ldr	x1, [x0]
    6334:	eb13003f 	cmp	x1, x19
    6338:	54ffff81 	b.ne	6328 <fwp_closure_drop+0x108>  // b.any
    633c:	f9400401 	ldr	x1, [x0, #8]
    6340:	d1000421 	sub	x1, x1, #0x1
    6344:	f9000401 	str	x1, [x0, #8]
    6348:	f103f83f 	cmp	x1, #0xfe
    634c:	54fffb61 	b.ne	62b8 <fwp_closure_drop+0x98>  // b.any
    6350:	aa1303e0 	mov	x0, x19
    6354:	97fff98f 	bl	4990 <fwp_rc_forget_slot>
    6358:	12800020 	mov	w0, #0xfffffffe            	// #-2
    635c:	39000260 	strb	w0, [x19]
    6360:	17ffffd6 	b	62b8 <fwp_closure_drop+0x98>
    6364:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    6368:	9105c000 	add	x0, x0, #0x170
    636c:	97fff505 	bl	3780 <fwp_trap>

0000000000006370 <fwp_owned_tape_release>:
    6370:	b4000940 	cbz	x0, 6498 <fwp_owned_tape_release+0x128>
    6374:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6378:	910003fd 	mov	x29, sp
    637c:	a90153f3 	stp	x19, x20, [sp, #16]
    6380:	aa0003f3 	mov	x19, x0
    6384:	f9400000 	ldr	x0, [x0]
    6388:	b4000060 	cbz	x0, 6394 <fwp_owned_tape_release+0x24>
    638c:	f9400661 	ldr	x1, [x19, #8]
    6390:	f9000401 	str	x1, [x0, #8]
    6394:	f9400661 	ldr	x1, [x19, #8]
    6398:	b4000041 	cbz	x1, 63a0 <fwp_owned_tape_release+0x30>
    639c:	f9000020 	str	x0, [x1]
    63a0:	f9400a60 	ldr	x0, [x19, #16]
    63a4:	f9403401 	ldr	x1, [x0, #104]
    63a8:	b40005c1 	cbz	x1, 6460 <fwp_owned_tape_release+0xf0>
    63ac:	a9450a60 	ldp	x0, x2, [x19, #80]
    63b0:	eb00005f 	cmp	x2, x0
    63b4:	540002ed 	b.le	6410 <fwp_owned_tape_release+0xa0>
    63b8:	d2800014 	mov	x20, #0x0                   	// #0
    63bc:	f90013f5 	str	x21, [sp, #32]
    63c0:	d2800015 	mov	x21, #0x0                   	// #0
    63c4:	d503201f 	nop
    63c8:	f9402260 	ldr	x0, [x19, #64]
    63cc:	910006b5 	add	x21, x21, #0x1
    63d0:	f8746800 	ldr	x0, [x0, x20]
    63d4:	d63f0020 	blr	x1
    63d8:	f9402260 	ldr	x0, [x19, #64]
    63dc:	f9400a61 	ldr	x1, [x19, #16]
    63e0:	8b140000 	add	x0, x0, x20
    63e4:	91004294 	add	x20, x20, #0x10
    63e8:	f9400400 	ldr	x0, [x0, #8]
    63ec:	f9403421 	ldr	x1, [x1, #104]
    63f0:	d63f0020 	blr	x1
    63f4:	a9450261 	ldp	x1, x0, [x19, #80]
    63f8:	cb010000 	sub	x0, x0, x1
    63fc:	eb15001f 	cmp	x0, x21
    6400:	f9400a60 	ldr	x0, [x19, #16]
    6404:	f9403401 	ldr	x1, [x0, #104]
    6408:	54fffe0c 	b.gt	63c8 <fwp_owned_tape_release+0x58>
    640c:	f94013f5 	ldr	x21, [sp, #32]
    6410:	f9403663 	ldr	x3, [x19, #104]
    6414:	f9401262 	ldr	x2, [x19, #32]
    6418:	f100007f 	cmp	x3, #0x0
    641c:	540001ed 	b.le	6458 <fwp_owned_tape_release+0xe8>
    6420:	d2800014 	mov	x20, #0x0                   	// #0
    6424:	d503201f 	nop
    6428:	f9402660 	ldr	x0, [x19, #72]
    642c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    6430:	eb02001f 	cmp	x0, x2
    6434:	540000c0 	b.eq	644c <fwp_owned_tape_release+0xdc>  // b.none
    6438:	d63f0020 	blr	x1
    643c:	f9400a60 	ldr	x0, [x19, #16]
    6440:	f9401262 	ldr	x2, [x19, #32]
    6444:	f9403663 	ldr	x3, [x19, #104]
    6448:	f9403401 	ldr	x1, [x0, #104]
    644c:	91000694 	add	x20, x20, #0x1
    6450:	eb14007f 	cmp	x3, x20
    6454:	54fffeac 	b.gt	6428 <fwp_owned_tape_release+0xb8>
    6458:	aa0203e0 	mov	x0, x2
    645c:	d63f0020 	blr	x1
    6460:	f9401660 	ldr	x0, [x19, #40]
    6464:	97ffff6f 	bl	6220 <fwp_closure_drop>
    6468:	f9401a60 	ldr	x0, [x19, #48]
    646c:	97ffff6d 	bl	6220 <fwp_closure_drop>
    6470:	f9401e60 	ldr	x0, [x19, #56]
    6474:	97ffff6b 	bl	6220 <fwp_closure_drop>
    6478:	f9402260 	ldr	x0, [x19, #64]
    647c:	97fff9e5 	bl	4c10 <fwp_mem_free>
    6480:	f9402660 	ldr	x0, [x19, #72]
    6484:	97fff9e3 	bl	4c10 <fwp_mem_free>
    6488:	aa1303e0 	mov	x0, x19
    648c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6490:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6494:	17fff9df 	b	4c10 <fwp_mem_free>
    6498:	d65f03c0 	ret
    649c:	d503201f 	nop

00000000000064a0 <fwp_tape_finish>:
    64a0:	d10203ff 	sub	sp, sp, #0x80
    64a4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    64a8:	f947f421 	ldr	x1, [x1, #4072]
    64ac:	a9047bfd 	stp	x29, x30, [sp, #64]
    64b0:	910103fd 	add	x29, sp, #0x40
    64b4:	a9065bf5 	stp	x21, x22, [sp, #96]
    64b8:	a90763f7 	stp	x23, x24, [sp, #112]
    64bc:	d00000d7 	adrp	x23, 20000 <__data_start>
    64c0:	910142f6 	add	x22, x23, #0x50
    64c4:	f9400022 	ldr	x2, [x1]
    64c8:	f9001fe2 	str	x2, [sp, #56]
    64cc:	d2800002 	mov	x2, #0x0                   	// #0
    64d0:	910382c0 	add	x0, x22, #0xe0
    64d4:	97fff7ac 	bl	4384 <fwp_tape_buffers_dispose>
    64d8:	f9008edf 	str	xzr, [x22, #280]
    64dc:	f9406ec0 	ldr	x0, [x22, #216]
    64e0:	f100001f 	cmp	x0, #0x0
    64e4:	5400034d 	b.le	654c <fwp_tape_finish+0xac>
    64e8:	910003f8 	mov	x24, sp
    64ec:	d2800015 	mov	x21, #0x0                   	// #0
    64f0:	a90553f3 	stp	x19, x20, [sp, #80]
    64f4:	d2800014 	mov	x20, #0x0                   	// #0
    64f8:	91000694 	add	x20, x20, #0x1
    64fc:	f94046d3 	ldr	x19, [x22, #136]
    6500:	8b150273 	add	x19, x19, x21
    6504:	9101a2b5 	add	x21, x21, #0x68
    6508:	aa1303e0 	mov	x0, x19
    650c:	97fff2a2 	bl	2f94 <fwp_tape_unlink_scope>
    6510:	aa1803e0 	mov	x0, x24
    6514:	a9440663 	ldp	x3, x1, [x19, #64]
    6518:	f9001be1 	str	x1, [sp, #48]
    651c:	f9400e62 	ldr	x2, [x19, #24]
    6520:	a9020be3 	stp	x3, x2, [sp, #32]
    6524:	ad410261 	ldp	q1, q0, [x19, #32]
    6528:	ad0003e1 	stp	q1, q0, [sp]
    652c:	97fff796 	bl	4384 <fwp_tape_buffers_dispose>
    6530:	f9403260 	ldr	x0, [x19, #96]
    6534:	97ffff8f 	bl	6370 <fwp_owned_tape_release>
    6538:	f900327f 	str	xzr, [x19, #96]
    653c:	f9406ec0 	ldr	x0, [x22, #216]
    6540:	eb14001f 	cmp	x0, x20
    6544:	54fffdac 	b.gt	64f8 <fwp_tape_finish+0x58>
    6548:	a94553f3 	ldp	x19, x20, [sp, #80]
    654c:	910142e0 	add	x0, x23, #0x50
    6550:	f9404400 	ldr	x0, [x0, #136]
    6554:	b4000040 	cbz	x0, 655c <fwp_tape_finish+0xbc>
    6558:	97fff76a 	bl	4300 <ad_raw_free.part.0>
    655c:	910142f7 	add	x23, x23, #0x50
    6560:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6564:	f947f400 	ldr	x0, [x0, #4072]
    6568:	f90046ff 	str	xzr, [x23, #136]
    656c:	f9006eff 	str	xzr, [x23, #216]
    6570:	f90092ff 	str	xzr, [x23, #288]
    6574:	f900b2ff 	str	xzr, [x23, #352]
    6578:	f9401fe2 	ldr	x2, [sp, #56]
    657c:	f9400001 	ldr	x1, [x0]
    6580:	eb010042 	subs	x2, x2, x1
    6584:	d2800001 	mov	x1, #0x0                   	// #0
    6588:	540000c1 	b.ne	65a0 <fwp_tape_finish+0x100>  // b.any
    658c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6590:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6594:	a94763f7 	ldp	x23, x24, [sp, #112]
    6598:	910203ff 	add	sp, sp, #0x80
    659c:	d65f03c0 	ret
    65a0:	a90553f3 	stp	x19, x20, [sp, #80]
    65a4:	97fff09b 	bl	2810 <__stack_chk_fail@plt>
    65a8:	d503201f 	nop
    65ac:	d503201f 	nop

00000000000065b0 <fwp_tape_scope_release>:
    65b0:	d10243ff 	sub	sp, sp, #0x90
    65b4:	a9047bfd 	stp	x29, x30, [sp, #64]
    65b8:	910103fd 	add	x29, sp, #0x40
    65bc:	a90553f3 	stp	x19, x20, [sp, #80]
    65c0:	aa0003f4 	mov	x20, x0
    65c4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    65c8:	f947f400 	ldr	x0, [x0, #4072]
    65cc:	b9400285 	ldr	w5, [x20]
    65d0:	f9400001 	ldr	x1, [x0]
    65d4:	f9001fe1 	str	x1, [sp, #56]
    65d8:	d2800001 	mov	x1, #0x0                   	// #0
    65dc:	37f806c5 	tbnz	w5, #31, 66b4 <fwp_tape_scope_release+0x104>
    65e0:	a90763f7 	stp	x23, x24, [sp, #112]
    65e4:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    65e8:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    65ec:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    65f0:	d00000d3 	adrp	x19, 20000 <__data_start>
    65f4:	910003f7 	mov	x23, sp
    65f8:	91014273 	add	x19, x19, #0x50
    65fc:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6600:	a9065bf5 	stp	x21, x22, [sp, #96]
    6604:	52800d16 	mov	w22, #0x68                  	// #104
    6608:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    660c:	f90043f9 	str	x25, [sp, #128]
    6610:	14000006 	b	6628 <fwp_tape_scope_release+0x78>
    6614:	97fff75c 	bl	4384 <fwp_tape_buffers_dispose>
    6618:	aa1903e0 	mov	x0, x25
    661c:	97ffff55 	bl	6370 <fwp_owned_tape_release>
    6620:	b9400285 	ldr	w5, [x20]
    6624:	37f80425 	tbnz	w5, #31, 66a8 <fwp_tape_scope_release+0xf8>
    6628:	f9404666 	ldr	x6, [x19, #136]
    662c:	9b367ca5 	smull	x5, w5, w22
    6630:	8b0500c0 	add	x0, x6, x5
    6634:	97fff258 	bl	2f94 <fwp_tape_unlink_scope>
    6638:	ad410001 	ldp	q1, q0, [x0, #32]
    663c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6640:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6644:	f9400c03 	ldr	x3, [x0, #24]
    6648:	ad0003e1 	stp	q1, q0, [sp]
    664c:	b86568c1 	ldr	w1, [x6, x5]
    6650:	a9440804 	ldp	x4, x2, [x0, #64]
    6654:	b900041f 	str	wzr, [x0, #4]
    6658:	f9403019 	ldr	x25, [x0, #96]
    665c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6660:	f9000c1f 	str	xzr, [x0, #24]
    6664:	a9020fe4 	stp	x4, x3, [sp, #32]
    6668:	f9001be2 	str	x2, [sp, #48]
    666c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6670:	f900301f 	str	xzr, [x0, #96]
    6674:	6b15003f 	cmp	w1, w21
    6678:	540000e8 	b.hi	6694 <fwp_tape_scope_release+0xe4>  // b.pmore
    667c:	9343fca5 	asr	x5, x5, #3
    6680:	f940b260 	ldr	x0, [x19, #352]
    6684:	9b187ca5 	mul	x5, x5, x24
    6688:	eb0000bf 	cmp	x5, x0
    668c:	5400004a 	b.ge	6694 <fwp_tape_scope_release+0xe4>  // b.tcont
    6690:	f900b265 	str	x5, [x19, #352]
    6694:	aa1703e0 	mov	x0, x23
    6698:	b5fffbf9 	cbnz	x25, 6614 <fwp_tape_scope_release+0x64>
    669c:	97fff782 	bl	44a4 <fwp_tape_buffers_release>
    66a0:	b9400285 	ldr	w5, [x20]
    66a4:	36fffc25 	tbz	w5, #31, 6628 <fwp_tape_scope_release+0x78>
    66a8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    66ac:	a94763f7 	ldp	x23, x24, [sp, #112]
    66b0:	f94043f9 	ldr	x25, [sp, #128]
    66b4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    66b8:	f947f400 	ldr	x0, [x0, #4072]
    66bc:	f9401fe2 	ldr	x2, [sp, #56]
    66c0:	f9400001 	ldr	x1, [x0]
    66c4:	eb010042 	subs	x2, x2, x1
    66c8:	d2800001 	mov	x1, #0x0                   	// #0
    66cc:	540000a1 	b.ne	66e0 <fwp_tape_scope_release+0x130>  // b.any
    66d0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    66d4:	a94553f3 	ldp	x19, x20, [sp, #80]
    66d8:	910243ff 	add	sp, sp, #0x90
    66dc:	d65f03c0 	ret
    66e0:	a9065bf5 	stp	x21, x22, [sp, #96]
    66e4:	a90763f7 	stp	x23, x24, [sp, #112]
    66e8:	f90043f9 	str	x25, [sp, #128]
    66ec:	97fff049 	bl	2810 <__stack_chk_fail@plt>

00000000000066f0 <fwp_task_dispose>:
    66f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    66f4:	910003fd 	mov	x29, sp
    66f8:	f9000bf3 	str	x19, [sp, #16]
    66fc:	aa0003f3 	mov	x19, x0
    6700:	39414000 	ldrb	w0, [x0, #80]
    6704:	36000720 	tbz	w0, #0, 67e8 <fwp_task_dispose+0xf8>
    6708:	f9400a60 	ldr	x0, [x19, #16]
    670c:	b50006e0 	cbnz	x0, 67e8 <fwp_task_dispose+0xf8>
    6710:	a9478660 	ldp	x0, x1, [x19, #120]
    6714:	39014e7f 	strb	wzr, [x19, #83]
    6718:	f9003e7f 	str	xzr, [x19, #120]
    671c:	f100003f 	cmp	x1, #0x0
    6720:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    6724:	54000040 	b.eq	672c <fwp_task_dispose+0x3c>  // b.none
    6728:	d63f0020 	blr	x1
    672c:	f9405660 	ldr	x0, [x19, #168]
    6730:	97fff938 	bl	4c10 <fwp_mem_free>
    6734:	f900567f 	str	xzr, [x19, #168]
    6738:	b9405e60 	ldr	w0, [x19, #92]
    673c:	7100041f 	cmp	w0, #0x1
    6740:	54000420 	b.eq	67c4 <fwp_task_dispose+0xd4>  // b.none
    6744:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    6748:	9118c042 	add	x2, x2, #0x630
    674c:	f949d840 	ldr	x0, [x2, #5040]
    6750:	f949ec41 	ldr	x1, [x2, #5080]
    6754:	cb000260 	sub	x0, x19, x0
    6758:	eb01401f 	cmp	x0, x1, lsl #16
    675c:	540002e2 	b.cs	67b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6760:	d350fc01 	lsr	x1, x0, #16
    6764:	f949fc44 	ldr	x4, [x2, #5112]
    6768:	8b010821 	add	x1, x1, x1, lsl #2
    676c:	d37df021 	lsl	x1, x1, #3
    6770:	8b010083 	add	x3, x4, x1
    6774:	f9401062 	ldr	x2, [x3, #32]
    6778:	b4000202 	cbz	x2, 67b8 <fwp_task_dispose+0xc8>
    677c:	38616881 	ldrb	w1, [x4, x1]
    6780:	7100083f 	cmp	w1, #0x2
    6784:	54000280 	b.eq	67d4 <fwp_task_dispose+0xe4>  // b.none
    6788:	7100043f 	cmp	w1, #0x1
    678c:	54000161 	b.ne	67b8 <fwp_task_dispose+0xc8>  // b.any
    6790:	29430464 	ldp	w4, w1, [x3, #24]
    6794:	92403c00 	and	x0, x0, #0xffff
    6798:	9b047c00 	mul	x0, x0, x4
    679c:	d360fc00 	lsr	x0, x0, #32
    67a0:	eb01001f 	cmp	x0, x1
    67a4:	540000a2 	b.cs	67b8 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    67a8:	8b000042 	add	x2, x2, x0
    67ac:	39400040 	ldrb	w0, [x2]
    67b0:	7100041f 	cmp	w0, #0x1
    67b4:	54000080 	b.eq	67c4 <fwp_task_dispose+0xd4>  // b.none
    67b8:	f9400bf3 	ldr	x19, [sp, #16]
    67bc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67c0:	d65f03c0 	ret
    67c4:	aa1303e0 	mov	x0, x19
    67c8:	f9400bf3 	ldr	x19, [sp, #16]
    67cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67d0:	17fff910 	b	4c10 <fwp_mem_free>
    67d4:	72003c1f 	tst	w0, #0xffff
    67d8:	54fffea0 	b.eq	67ac <fwp_task_dispose+0xbc>  // b.none
    67dc:	f9400bf3 	ldr	x19, [sp, #16]
    67e0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    67e4:	d65f03c0 	ret
    67e8:	97fff01e 	bl	2860 <abort@plt>
    67ec:	d503201f 	nop

00000000000067f0 <fwp_free_zombie>:
    67f0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67f4:	910003fd 	mov	x29, sp
    67f8:	a90153f3 	stp	x19, x20, [sp, #16]
    67fc:	d00000d4 	adrp	x20, 20000 <__data_start>
    6800:	91014281 	add	x1, x20, #0x50
    6804:	f940b433 	ldr	x19, [x1, #360]
    6808:	b4000333 	cbz	x19, 686c <fwp_free_zombie+0x7c>
    680c:	f9404c20 	ldr	x0, [x1, #152]
    6810:	eb00027f 	cmp	x19, x0
    6814:	540002c0 	b.eq	686c <fwp_free_zombie+0x7c>  // b.none
    6818:	b9417022 	ldr	w2, [x1, #368]
    681c:	f9400a60 	ldr	x0, [x19, #16]
    6820:	7100fc5f 	cmp	w2, #0x3f
    6824:	5400078c 	b.gt	6914 <fwp_free_zombie+0x124>
    6828:	91060023 	add	x3, x1, #0x180
    682c:	11000444 	add	w4, w2, #0x1
    6830:	b9017024 	str	w4, [x1, #368]
    6834:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6838:	f822d860 	str	x0, [x3, w2, sxtw #3]
    683c:	a9530261 	ldp	x1, x0, [x19, #304]
    6840:	b4000741 	cbz	x1, 6928 <fwp_free_zombie+0x138>
    6844:	f9009c20 	str	x0, [x1, #312]
    6848:	b4000040 	cbz	x0, 6850 <fwp_free_zombie+0x60>
    684c:	f9009801 	str	x1, [x0, #304]
    6850:	91014294 	add	x20, x20, #0x50
    6854:	b9405e60 	ldr	w0, [x19, #92]
    6858:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    685c:	f900b69f 	str	xzr, [x20, #360]
    6860:	34000140 	cbz	w0, 6888 <fwp_free_zombie+0x98>
    6864:	7100041f 	cmp	w0, #0x1
    6868:	54000080 	b.eq	6878 <fwp_free_zombie+0x88>  // b.none
    686c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6870:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6874:	d65f03c0 	ret
    6878:	aa1303e0 	mov	x0, x19
    687c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6880:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6884:	17ffff9b 	b	66f0 <fwp_task_dispose>
    6888:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    688c:	9118c082 	add	x2, x4, #0x630
    6890:	f949d841 	ldr	x1, [x2, #5040]
    6894:	f949ec40 	ldr	x0, [x2, #5080]
    6898:	cb010261 	sub	x1, x19, x1
    689c:	eb00403f 	cmp	x1, x0, lsl #16
    68a0:	54fffe62 	b.cs	686c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68a4:	d350fc20 	lsr	x0, x1, #16
    68a8:	f949fc43 	ldr	x3, [x2, #5112]
    68ac:	8b000800 	add	x0, x0, x0, lsl #2
    68b0:	d37df000 	lsl	x0, x0, #3
    68b4:	8b000062 	add	x2, x3, x0
    68b8:	f9401054 	ldr	x20, [x2, #32]
    68bc:	b4fffd94 	cbz	x20, 686c <fwp_free_zombie+0x7c>
    68c0:	38606860 	ldrb	w0, [x3, x0]
    68c4:	7100081f 	cmp	w0, #0x2
    68c8:	54000360 	b.eq	6934 <fwp_free_zombie+0x144>  // b.none
    68cc:	7100041f 	cmp	w0, #0x1
    68d0:	54fffce1 	b.ne	686c <fwp_free_zombie+0x7c>  // b.any
    68d4:	29430043 	ldp	w3, w0, [x2, #24]
    68d8:	92403c21 	and	x1, x1, #0xffff
    68dc:	9b037c21 	mul	x1, x1, x3
    68e0:	d360fc21 	lsr	x1, x1, #32
    68e4:	eb00003f 	cmp	x1, x0
    68e8:	54fffc22 	b.cs	686c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    68ec:	8b010294 	add	x20, x20, x1
    68f0:	39400280 	ldrb	w0, [x20]
    68f4:	34fffbc0 	cbz	w0, 686c <fwp_free_zombie+0x7c>
    68f8:	7100041f 	cmp	w0, #0x1
    68fc:	54fffbe0 	b.eq	6878 <fwp_free_zombie+0x88>  // b.none
    6900:	7103fc1f 	cmp	w0, #0xff
    6904:	540001e0 	b.eq	6940 <fwp_free_zombie+0x150>  // b.none
    6908:	51000400 	sub	w0, w0, #0x1
    690c:	39000280 	strb	w0, [x20]
    6910:	17ffffd7 	b	686c <fwp_free_zombie+0x7c>
    6914:	f9400e61 	ldr	x1, [x19, #24]
    6918:	97fff006 	bl	2930 <munmap@plt>
    691c:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6920:	a9530261 	ldp	x1, x0, [x19, #304]
    6924:	b5fff901 	cbnz	x1, 6844 <fwp_free_zombie+0x54>
    6928:	91014282 	add	x2, x20, #0x50
    692c:	f901c040 	str	x0, [x2, #896]
    6930:	17ffffc6 	b	6848 <fwp_free_zombie+0x58>
    6934:	72003c3f 	tst	w1, #0xffff
    6938:	54fff9a1 	b.ne	686c <fwp_free_zombie+0x7c>  // b.any
    693c:	17ffffed 	b	68f0 <fwp_free_zombie+0x100>
    6940:	ca544680 	eor	x0, x20, x20, lsr #17
    6944:	9118c084 	add	x4, x4, #0x630
    6948:	ca402400 	eor	x0, x0, x0, lsr #9
    694c:	8b200c80 	add	x0, x4, w0, uxtb #3
    6950:	f94a2400 	ldr	x0, [x0, #5192]
    6954:	b5000080 	cbnz	x0, 6964 <fwp_free_zombie+0x174>
    6958:	14000010 	b	6998 <fwp_free_zombie+0x1a8>
    695c:	f9400800 	ldr	x0, [x0, #16]
    6960:	b40001c0 	cbz	x0, 6998 <fwp_free_zombie+0x1a8>
    6964:	f9400001 	ldr	x1, [x0]
    6968:	eb14003f 	cmp	x1, x20
    696c:	54ffff81 	b.ne	695c <fwp_free_zombie+0x16c>  // b.any
    6970:	f9400401 	ldr	x1, [x0, #8]
    6974:	d1000421 	sub	x1, x1, #0x1
    6978:	f9000401 	str	x1, [x0, #8]
    697c:	f103f83f 	cmp	x1, #0xfe
    6980:	54fff761 	b.ne	686c <fwp_free_zombie+0x7c>  // b.any
    6984:	aa1403e0 	mov	x0, x20
    6988:	97fff802 	bl	4990 <fwp_rc_forget_slot>
    698c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6990:	39000280 	strb	w0, [x20]
    6994:	17ffffb6 	b	686c <fwp_free_zombie+0x7c>
    6998:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    699c:	9105c000 	add	x0, x0, #0x170
    69a0:	97fff378 	bl	3780 <fwp_trap>

00000000000069a4 <fwp_block>:
    69a4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    69a8:	910003fd 	mov	x29, sp
    69ac:	a90153f3 	stp	x19, x20, [sp, #16]
    69b0:	d00000d3 	adrp	x19, 20000 <__data_start>
    69b4:	91014274 	add	x20, x19, #0x50
    69b8:	f9406682 	ldr	x2, [x20, #200]
    69bc:	b4000622 	cbz	x2, 6a80 <fwp_block+0xdc>
    69c0:	91014261 	add	x1, x19, #0x50
    69c4:	f9408040 	ldr	x0, [x2, #256]
    69c8:	f9006420 	str	x0, [x1, #200]
    69cc:	b4000680 	cbz	x0, 6a9c <fwp_block+0xf8>
    69d0:	91014263 	add	x3, x19, #0x50
    69d4:	3901505f 	strb	wzr, [x2, #84]
    69d8:	f9404c64 	ldr	x4, [x3, #152]
    69dc:	eb02009f 	cmp	x4, x2
    69e0:	54000440 	b.eq	6a68 <fwp_block+0xc4>  // b.none
    69e4:	f941c465 	ldr	x5, [x3, #904]
    69e8:	f9004c62 	str	x2, [x3, #152]
    69ec:	f9400441 	ldr	x1, [x2, #8]
    69f0:	f9004885 	str	x5, [x4, #144]
    69f4:	f941c865 	ldr	x5, [x3, #912]
    69f8:	f9004c85 	str	x5, [x4, #152]
    69fc:	f941cc65 	ldr	x5, [x3, #920]
    6a00:	f9005085 	str	x5, [x4, #160]
    6a04:	f941d065 	ldr	x5, [x3, #928]
    6a08:	f9005485 	str	x5, [x4, #168]
    6a0c:	f941d465 	ldr	x5, [x3, #936]
    6a10:	f9005885 	str	x5, [x4, #176]
    6a14:	f941d865 	ldr	x5, [x3, #944]
    6a18:	f9005c85 	str	x5, [x4, #184]
    6a1c:	f941dc65 	ldr	x5, [x3, #952]
    6a20:	f9006085 	str	x5, [x4, #192]
    6a24:	f9400480 	ldr	x0, [x4, #8]
    6a28:	f9404844 	ldr	x4, [x2, #144]
    6a2c:	f901c464 	str	x4, [x3, #904]
    6a30:	f9404c44 	ldr	x4, [x2, #152]
    6a34:	f901c864 	str	x4, [x3, #912]
    6a38:	f9405044 	ldr	x4, [x2, #160]
    6a3c:	f901cc64 	str	x4, [x3, #920]
    6a40:	f9405444 	ldr	x4, [x2, #168]
    6a44:	f901d064 	str	x4, [x3, #928]
    6a48:	f9405844 	ldr	x4, [x2, #176]
    6a4c:	f901d464 	str	x4, [x3, #936]
    6a50:	a94b8844 	ldp	x4, x2, [x2, #184]
    6a54:	f901d864 	str	x4, [x3, #944]
    6a58:	f901dc62 	str	x2, [x3, #952]
    6a5c:	97ffef85 	bl	2870 <swapcontext@plt>
    6a60:	97ffff64 	bl	67f0 <fwp_free_zombie>
    6a64:	d503201f 	nop
    6a68:	91014260 	add	x0, x19, #0x50
    6a6c:	b943c000 	ldr	w0, [x0, #960]
    6a70:	340001a0 	cbz	w0, 6aa4 <fwp_block+0x100>
    6a74:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a78:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a7c:	d65f03c0 	ret
    6a80:	97fff6f1 	bl	4644 <fwp_poll_events>
    6a84:	f9406682 	ldr	x2, [x20, #200]
    6a88:	b4ffffc2 	cbz	x2, 6a80 <fwp_block+0xdc>
    6a8c:	91014261 	add	x1, x19, #0x50
    6a90:	f9408040 	ldr	x0, [x2, #256]
    6a94:	f9006420 	str	x0, [x1, #200]
    6a98:	b5fff9c0 	cbnz	x0, 69d0 <fwp_block+0x2c>
    6a9c:	f900603f 	str	xzr, [x1, #192]
    6aa0:	17ffffcc 	b	69d0 <fwp_block+0x2c>
    6aa4:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    6aa8:	910a8000 	add	x0, x0, #0x2a0
    6aac:	97ffefbd 	bl	29a0 <getenv@plt>
    6ab0:	5284e202 	mov	w2, #0x2710                	// #10000
    6ab4:	b4000060 	cbz	x0, 6ac0 <fwp_block+0x11c>
    6ab8:	39400001 	ldrb	w1, [x0]
    6abc:	350000c1 	cbnz	w1, 6ad4 <fwp_block+0x130>
    6ac0:	91014273 	add	x19, x19, #0x50
    6ac4:	b903c262 	str	w2, [x19, #960]
    6ac8:	a94153f3 	ldp	x19, x20, [sp, #16]
    6acc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6ad0:	d65f03c0 	ret
    6ad4:	52800142 	mov	w2, #0xa                   	// #10
    6ad8:	d2800001 	mov	x1, #0x0                   	// #0
    6adc:	97ffef01 	bl	26e0 <strtoll@plt>
    6ae0:	d1000403 	sub	x3, x0, #0x1
    6ae4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6ae8:	eb02007f 	cmp	x3, x2
    6aec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6af0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6af4:	17fffff3 	b	6ac0 <fwp_block+0x11c>
    6af8:	d503201f 	nop
    6afc:	d503201f 	nop

0000000000006b00 <fwp_drop4>:
    6b00:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6b04:	910003fd 	mov	x29, sp
    6b08:	a90153f3 	stp	x19, x20, [sp, #16]
    6b0c:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6b10:	f90013f5 	str	x21, [sp, #32]
    6b14:	9118c275 	add	x21, x19, #0x630
    6b18:	f949daa1 	ldr	x1, [x21, #5040]
    6b1c:	f949eea2 	ldr	x2, [x21, #5080]
    6b20:	cb010001 	sub	x1, x0, x1
    6b24:	eb02403f 	cmp	x1, x2, lsl #16
    6b28:	54000382 	b.cs	6b98 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b2c:	d350fc22 	lsr	x2, x1, #16
    6b30:	f949fea3 	ldr	x3, [x21, #5112]
    6b34:	8b020842 	add	x2, x2, x2, lsl #2
    6b38:	d37df042 	lsl	x2, x2, #3
    6b3c:	8b020064 	add	x4, x3, x2
    6b40:	f9401094 	ldr	x20, [x4, #32]
    6b44:	b40002b4 	cbz	x20, 6b98 <fwp_drop4+0x98>
    6b48:	38626862 	ldrb	w2, [x3, x2]
    6b4c:	7100085f 	cmp	w2, #0x2
    6b50:	540007a0 	b.eq	6c44 <fwp_drop4+0x144>  // b.none
    6b54:	7100045f 	cmp	w2, #0x1
    6b58:	54000201 	b.ne	6b98 <fwp_drop4+0x98>  // b.any
    6b5c:	29430885 	ldp	w5, w2, [x4, #24]
    6b60:	92403c21 	and	x1, x1, #0xffff
    6b64:	9b057c21 	mul	x1, x1, x5
    6b68:	d360fc21 	lsr	x1, x1, #32
    6b6c:	eb02003f 	cmp	x1, x2
    6b70:	54000142 	b.cs	6b98 <fwp_drop4+0x98>  // b.hs, b.nlast
    6b74:	8b010294 	add	x20, x20, x1
    6b78:	39400281 	ldrb	w1, [x20]
    6b7c:	340000e1 	cbz	w1, 6b98 <fwp_drop4+0x98>
    6b80:	7100043f 	cmp	w1, #0x1
    6b84:	54000120 	b.eq	6ba8 <fwp_drop4+0xa8>  // b.none
    6b88:	7103fc3f 	cmp	w1, #0xff
    6b8c:	540007c0 	b.eq	6c84 <fwp_drop4+0x184>  // b.none
    6b90:	51000421 	sub	w1, w1, #0x1
    6b94:	39000281 	strb	w1, [x20]
    6b98:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b9c:	f94013f5 	ldr	x21, [sp, #32]
    6ba0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ba4:	d65f03c0 	ret
    6ba8:	f9400001 	ldr	x1, [x0]
    6bac:	b7f80581 	tbnz	x1, #63, 6c5c <fwp_drop4+0x15c>
    6bb0:	9118c273 	add	x19, x19, #0x630
    6bb4:	f949da61 	ldr	x1, [x19, #5040]
    6bb8:	f949ee62 	ldr	x2, [x19, #5080]
    6bbc:	cb010001 	sub	x1, x0, x1
    6bc0:	eb02403f 	cmp	x1, x2, lsl #16
    6bc4:	54fffea2 	b.cs	6b98 <fwp_drop4+0x98>  // b.hs, b.nlast
    6bc8:	d350fc22 	lsr	x2, x1, #16
    6bcc:	8b020842 	add	x2, x2, x2, lsl #2
    6bd0:	d37df042 	lsl	x2, x2, #3
    6bd4:	8b020065 	add	x5, x3, x2
    6bd8:	f94010a4 	ldr	x4, [x5, #32]
    6bdc:	b4fffde4 	cbz	x4, 6b98 <fwp_drop4+0x98>
    6be0:	38626862 	ldrb	w2, [x3, x2]
    6be4:	7100085f 	cmp	w2, #0x2
    6be8:	54000220 	b.eq	6c2c <fwp_drop4+0x12c>  // b.none
    6bec:	7100045f 	cmp	w2, #0x1
    6bf0:	54fffd41 	b.ne	6b98 <fwp_drop4+0x98>  // b.any
    6bf4:	294308a3 	ldp	w3, w2, [x5, #24]
    6bf8:	92403c21 	and	x1, x1, #0xffff
    6bfc:	9b037c21 	mul	x1, x1, x3
    6c00:	d360fc21 	lsr	x1, x1, #32
    6c04:	eb02003f 	cmp	x1, x2
    6c08:	54fffc82 	b.cs	6b98 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c0c:	8b010084 	add	x4, x4, x1
    6c10:	39400081 	ldrb	w1, [x4]
    6c14:	7100043f 	cmp	w1, #0x1
    6c18:	54fffc01 	b.ne	6b98 <fwp_drop4+0x98>  // b.any
    6c1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c20:	f94013f5 	ldr	x21, [sp, #32]
    6c24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c28:	17fff7fa 	b	4c10 <fwp_mem_free>
    6c2c:	72003c3f 	tst	w1, #0xffff
    6c30:	54ffff00 	b.eq	6c10 <fwp_drop4+0x110>  // b.none
    6c34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c38:	f94013f5 	ldr	x21, [sp, #32]
    6c3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c40:	d65f03c0 	ret
    6c44:	72003c3f 	tst	w1, #0xffff
    6c48:	54fff980 	b.eq	6b78 <fwp_drop4+0x78>  // b.none
    6c4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6c50:	f94013f5 	ldr	x21, [sp, #32]
    6c54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6c58:	d65f03c0 	ret
    6c5c:	f9400414 	ldr	x20, [x0, #8]
    6c60:	97fffbe1 	bl	5be4 <fwp_rc_free_arr>
    6c64:	9118c260 	add	x0, x19, #0x630
    6c68:	f949d801 	ldr	x1, [x0, #5040]
    6c6c:	f949ec00 	ldr	x0, [x0, #5080]
    6c70:	cb010281 	sub	x1, x20, x1
    6c74:	eb00403f 	cmp	x1, x0, lsl #16
    6c78:	54fff902 	b.cs	6b98 <fwp_drop4+0x98>  // b.hs, b.nlast
    6c7c:	aa1403e0 	mov	x0, x20
    6c80:	17ffffab 	b	6b2c <fwp_drop4+0x2c>
    6c84:	ca544680 	eor	x0, x20, x20, lsr #17
    6c88:	9118c273 	add	x19, x19, #0x630
    6c8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6c90:	8b200e60 	add	x0, x19, w0, uxtb #3
    6c94:	f94a2400 	ldr	x0, [x0, #5192]
    6c98:	b5000080 	cbnz	x0, 6ca8 <fwp_drop4+0x1a8>
    6c9c:	14000010 	b	6cdc <fwp_drop4+0x1dc>
    6ca0:	f9400800 	ldr	x0, [x0, #16]
    6ca4:	b40001c0 	cbz	x0, 6cdc <fwp_drop4+0x1dc>
    6ca8:	f9400001 	ldr	x1, [x0]
    6cac:	eb14003f 	cmp	x1, x20
    6cb0:	54ffff81 	b.ne	6ca0 <fwp_drop4+0x1a0>  // b.any
    6cb4:	f9400401 	ldr	x1, [x0, #8]
    6cb8:	d1000421 	sub	x1, x1, #0x1
    6cbc:	f9000401 	str	x1, [x0, #8]
    6cc0:	f103f83f 	cmp	x1, #0xfe
    6cc4:	54fff6a1 	b.ne	6b98 <fwp_drop4+0x98>  // b.any
    6cc8:	aa1403e0 	mov	x0, x20
    6ccc:	97fff731 	bl	4990 <fwp_rc_forget_slot>
    6cd0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6cd4:	39000280 	strb	w0, [x20]
    6cd8:	17ffffb0 	b	6b98 <fwp_drop4+0x98>
    6cdc:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    6ce0:	9105c000 	add	x0, x0, #0x170
    6ce4:	97fff2a7 	bl	3780 <fwp_trap>
    6ce8:	d503201f 	nop
    6cec:	d503201f 	nop

0000000000006cf0 <fwp_caps161>:
    6cf0:	34000041 	cbz	w1, 6cf8 <fwp_caps161+0x8>
    6cf4:	d65f03c0 	ret
    6cf8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6cfc:	9118c063 	add	x3, x3, #0x630
    6d00:	f949d861 	ldr	x1, [x3, #5040]
    6d04:	f949ec62 	ldr	x2, [x3, #5080]
    6d08:	cb010001 	sub	x1, x0, x1
    6d0c:	eb02403f 	cmp	x1, x2, lsl #16
    6d10:	54ffff22 	b.cs	6cf4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6d14:	d350fc22 	lsr	x2, x1, #16
    6d18:	f949fc65 	ldr	x5, [x3, #5112]
    6d1c:	8b020842 	add	x2, x2, x2, lsl #2
    6d20:	d37df042 	lsl	x2, x2, #3
    6d24:	8b0200a4 	add	x4, x5, x2
    6d28:	f9401083 	ldr	x3, [x4, #32]
    6d2c:	b4fffe43 	cbz	x3, 6cf4 <fwp_caps161+0x4>
    6d30:	386268a2 	ldrb	w2, [x5, x2]
    6d34:	7100085f 	cmp	w2, #0x2
    6d38:	540001c0 	b.eq	6d70 <fwp_caps161+0x80>  // b.none
    6d3c:	7100045f 	cmp	w2, #0x1
    6d40:	54fffda1 	b.ne	6cf4 <fwp_caps161+0x4>  // b.any
    6d44:	29430885 	ldp	w5, w2, [x4, #24]
    6d48:	92403c21 	and	x1, x1, #0xffff
    6d4c:	9b057c21 	mul	x1, x1, x5
    6d50:	d360fc21 	lsr	x1, x1, #32
    6d54:	eb02003f 	cmp	x1, x2
    6d58:	54fffce2 	b.cs	6cf4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6d5c:	8b010063 	add	x3, x3, x1
    6d60:	39400061 	ldrb	w1, [x3]
    6d64:	7100043f 	cmp	w1, #0x1
    6d68:	54fffc61 	b.ne	6cf4 <fwp_caps161+0x4>  // b.any
    6d6c:	17fff7a9 	b	4c10 <fwp_mem_free>
    6d70:	72003c3f 	tst	w1, #0xffff
    6d74:	54ffff60 	b.eq	6d60 <fwp_caps161+0x70>  // b.none
    6d78:	d65f03c0 	ret
    6d7c:	d503201f 	nop

0000000000006d80 <f12>:
    6d80:	d10483ff 	sub	sp, sp, #0x120
    6d84:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    6d88:	f947f442 	ldr	x2, [x2, #4072]
    6d8c:	a90c7bfd 	stp	x29, x30, [sp, #192]
    6d90:	910303fd 	add	x29, sp, #0xc0
    6d94:	a90f63f7 	stp	x23, x24, [sp, #240]
    6d98:	f0000397 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    6d9c:	9118c2e3 	add	x3, x23, #0x630
    6da0:	a90e5bf5 	stp	x21, x22, [sp, #224]
    6da4:	d00000d5 	adrp	x21, 20000 <__data_start>
    6da8:	910142a4 	add	x4, x21, #0x50
    6dac:	f949d861 	ldr	x1, [x3, #5040]
    6db0:	a90d53f3 	stp	x19, x20, [sp, #208]
    6db4:	910103f8 	add	x24, sp, #0x40
    6db8:	f949ec65 	ldr	x5, [x3, #5080]
    6dbc:	a9106bf9 	stp	x25, x26, [sp, #256]
    6dc0:	d00000d9 	adrp	x25, 20000 <__data_start>
    6dc4:	a91173fb 	stp	x27, x28, [sp, #272]
    6dc8:	91004339 	add	x25, x25, #0x10
    6dcc:	91008339 	add	x25, x25, #0x20
    6dd0:	f941c886 	ldr	x6, [x4, #912]
    6dd4:	f9400047 	ldr	x7, [x2]
    6dd8:	f9005fe7 	str	x7, [sp, #184]
    6ddc:	d2800007 	mov	x7, #0x0                   	// #0
    6de0:	9100e3f6 	add	x22, sp, #0x38
    6de4:	90000013 	adrp	x19, 6000 <fwp_drop0+0xa0>
    6de8:	12800007 	mov	w7, #0xffffffff            	// #-1
    6dec:	9116c262 	add	x2, x19, #0x5b0
    6df0:	cb010321 	sub	x1, x25, x1
    6df4:	b9003be7 	str	w7, [sp, #56]
    6df8:	a9040be6 	stp	x6, x2, [sp, #64]
    6dfc:	aa0003f4 	mov	x20, x0
    6e00:	f9002bf6 	str	x22, [sp, #80]
    6e04:	f901c898 	str	x24, [x4, #912]
    6e08:	eb05403f 	cmp	x1, x5, lsl #16
    6e0c:	540003a2 	b.cs	6e80 <f12+0x100>  // b.hs, b.nlast
    6e10:	d350fc20 	lsr	x0, x1, #16
    6e14:	f949fc64 	ldr	x4, [x3, #5112]
    6e18:	8b000800 	add	x0, x0, x0, lsl #2
    6e1c:	d37df002 	lsl	x2, x0, #3
    6e20:	8b020083 	add	x3, x4, x2
    6e24:	f9401060 	ldr	x0, [x3, #32]
    6e28:	b40002c0 	cbz	x0, 6e80 <f12+0x100>
    6e2c:	38626882 	ldrb	w2, [x4, x2]
    6e30:	7100085f 	cmp	w2, #0x2
    6e34:	54006de0 	b.eq	7bf0 <f12+0xe70>  // b.none
    6e38:	7100045f 	cmp	w2, #0x1
    6e3c:	54000221 	b.ne	6e80 <f12+0x100>  // b.any
    6e40:	29430864 	ldp	w4, w2, [x3, #24]
    6e44:	92403c21 	and	x1, x1, #0xffff
    6e48:	9b047c21 	mul	x1, x1, x4
    6e4c:	d360fc21 	lsr	x1, x1, #32
    6e50:	eb02003f 	cmp	x1, x2
    6e54:	54000162 	b.cs	6e80 <f12+0x100>  // b.hs, b.nlast
    6e58:	8b010000 	add	x0, x0, x1
    6e5c:	39400001 	ldrb	w1, [x0]
    6e60:	34000101 	cbz	w1, 6e80 <f12+0x100>
    6e64:	910142a2 	add	x2, x21, #0x50
    6e68:	b9413043 	ldr	w3, [x2, #304]
    6e6c:	35006f63 	cbnz	w3, 7c58 <f12+0xed8>
    6e70:	7103f43f 	cmp	w1, #0xfd
    6e74:	54007948 	b.hi	7d9c <f12+0x101c>  // b.pmore
    6e78:	11000421 	add	w1, w1, #0x1
    6e7c:	39000001 	strb	w1, [x0]
    6e80:	aa1903e0 	mov	x0, x25
    6e84:	97fffce7 	bl	6220 <fwp_closure_drop>
    6e88:	b4006bf4 	cbz	x20, 7c04 <f12+0xe84>
    6e8c:	aa1403e0 	mov	x0, x20
    6e90:	d2800001 	mov	x1, #0x0                   	// #0
    6e94:	d503201f 	nop
    6e98:	f9400800 	ldr	x0, [x0, #16]
    6e9c:	91000421 	add	x1, x1, #0x1
    6ea0:	b5ffffc0 	cbnz	x0, 6e98 <f12+0x118>
    6ea4:	aa0103fa 	mov	x26, x1
    6ea8:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    6eac:	eb00003f 	cmp	x1, x0
    6eb0:	54007b48 	b.hi	7e18 <f12+0x1098>  // b.pmore
    6eb4:	910142b9 	add	x25, x21, #0x50
    6eb8:	b943c720 	ldr	w0, [x25, #964]
    6ebc:	34006860 	cbz	w0, 7bc8 <f12+0xe48>
    6ec0:	910142a0 	add	x0, x21, #0x50
    6ec4:	f9406c1b 	ldr	x27, [x0, #216]
    6ec8:	f940b019 	ldr	x25, [x0, #352]
    6ecc:	eb1b033f 	cmp	x25, x27
    6ed0:	5400358a 	b.ge	7580 <f12+0x800>  // b.tcont
    6ed4:	f9404401 	ldr	x1, [x0, #136]
    6ed8:	8b190720 	add	x0, x25, x25, lsl #1
    6edc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    6ee0:	8b000b20 	add	x0, x25, x0, lsl #2
    6ee4:	8b000c20 	add	x0, x1, x0, lsl #3
    6ee8:	b9400401 	ldr	w1, [x0, #4]
    6eec:	35000081 	cbnz	w1, 6efc <f12+0x17c>
    6ef0:	b9400001 	ldr	w1, [x0]
    6ef4:	6b02003f 	cmp	w1, w2
    6ef8:	54003449 	b.ls	7580 <f12+0x800>  // b.plast
    6efc:	91000739 	add	x25, x25, #0x1
    6f00:	9101a000 	add	x0, x0, #0x68
    6f04:	eb1b033f 	cmp	x25, x27
    6f08:	54ffff01 	b.ne	6ee8 <f12+0x168>  // b.any
    6f0c:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    6f10:	eb00037f 	cmp	x27, x0
    6f14:	540078ec 	b.gt	7e30 <f12+0x10b0>
    6f18:	910142a0 	add	x0, x21, #0x50
    6f1c:	f9409001 	ldr	x1, [x0, #288]
    6f20:	f940441c 	ldr	x28, [x0, #136]
    6f24:	eb1b003f 	cmp	x1, x27
    6f28:	54000221 	b.ne	6f6c <f12+0x1ec>  // b.any
    6f2c:	b400721b 	cbz	x27, 7d6c <f12+0xfec>
    6f30:	d37ffb79 	lsl	x25, x27, #1
    6f34:	d29fffe0 	mov	x0, #0xffff                	// #65535
    6f38:	eb00033f 	cmp	x25, x0
    6f3c:	9a80d339 	csel	x25, x25, x0, le
    6f40:	8b190721 	add	x1, x25, x25, lsl #1
    6f44:	8b010b21 	add	x1, x25, x1, lsl #2
    6f48:	d37df021 	lsl	x1, x1, #3
    6f4c:	aa1c03e0 	mov	x0, x28
    6f50:	52800002 	mov	w2, #0x0                   	// #0
    6f54:	97fff520 	bl	43d4 <ad_raw_realloc>
    6f58:	aa0003fc 	mov	x28, x0
    6f5c:	b40035e0 	cbz	x0, 7618 <f12+0x898>
    6f60:	910142a0 	add	x0, x21, #0x50
    6f64:	f900441c 	str	x28, [x0, #136]
    6f68:	f9009019 	str	x25, [x0, #288]
    6f6c:	8b1b0761 	add	x1, x27, x27, lsl #1
    6f70:	910142a0 	add	x0, x21, #0x50
    6f74:	4f000400 	movi	v0.4s, #0x0
    6f78:	aa1b03f9 	mov	x25, x27
    6f7c:	8b010b61 	add	x1, x27, x1, lsl #2
    6f80:	9100077b 	add	x27, x27, #0x1
    6f84:	f9006c1b 	str	x27, [x0, #216]
    6f88:	8b19073b 	add	x27, x25, x25, lsl #1
    6f8c:	8b010f81 	add	x1, x28, x1, lsl #3
    6f90:	b0000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    6f94:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    6f98:	9102c000 	add	x0, x0, #0xb0
    6f9c:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    6fa0:	ad000020 	stp	q0, q0, [x1]
    6fa4:	ad010020 	stp	q0, q0, [x1, #32]
    6fa8:	ad020020 	stp	q0, q0, [x1, #64]
    6fac:	f900303f 	str	xzr, [x1, #96]
    6fb0:	f900337f 	str	xzr, [x27, #96]
    6fb4:	97ffee7b 	bl	29a0 <getenv@plt>
    6fb8:	b5002fc0 	cbnz	x0, 75b0 <f12+0x830>
    6fbc:	d503201f 	nop
    6fc0:	910142a0 	add	x0, x21, #0x50
    6fc4:	f9408c01 	ldr	x1, [x0, #280]
    6fc8:	b50062c1 	cbnz	x1, 7c20 <f12+0xea0>
    6fcc:	910142a2 	add	x2, x21, #0x50
    6fd0:	2f000400 	mvni	v0.2s, #0x0
    6fd4:	b9400363 	ldr	w3, [x27]
    6fd8:	52800024 	mov	w4, #0x1                   	// #1
    6fdc:	91000720 	add	x0, x25, #0x1
    6fe0:	a900eb7a 	stp	x26, x26, [x27, #8]
    6fe4:	0b040063 	add	w3, w3, w4
    6fe8:	f941c841 	ldr	x1, [x2, #912]
    6fec:	29001363 	stp	w3, w4, [x27]
    6ff0:	f9002b7f 	str	xzr, [x27, #80]
    6ff4:	f900b040 	str	x0, [x2, #352]
    6ff8:	fd002f60 	str	d0, [x27, #88]
    6ffc:	b4007081 	cbz	x1, 7e0c <f12+0x108c>
    7000:	9116c273 	add	x19, x19, #0x5b0
    7004:	14000003 	b	7010 <f12+0x290>
    7008:	f9400021 	ldr	x1, [x1]
    700c:	b4007001 	cbz	x1, 7e0c <f12+0x108c>
    7010:	f9400422 	ldr	x2, [x1, #8]
    7014:	eb13005f 	cmp	x2, x19
    7018:	54ffff81 	b.ne	7008 <f12+0x288>  // b.any
    701c:	f9400821 	ldr	x1, [x1, #16]
    7020:	2a1903e4 	mov	w4, w25
    7024:	b9400022 	ldr	w2, [x1]
    7028:	f9002b61 	str	x1, [x27, #80]
    702c:	b9005f62 	str	w2, [x27, #92]
    7030:	37f80082 	tbnz	w2, #31, 7040 <f12+0x2c0>
    7034:	52800d05 	mov	w5, #0x68                  	// #104
    7038:	9b257042 	smaddl	x2, w2, w5, x28
    703c:	b9005859 	str	w25, [x2, #88]
    7040:	b9000024 	str	w4, [x1]
    7044:	d3707c79 	ubfiz	x25, x3, #16, #32
    7048:	aa000339 	orr	x25, x25, x0
    704c:	d2800002 	mov	x2, #0x0                   	// #0
    7050:	aa1403e0 	mov	x0, x20
    7054:	b4005934 	cbz	x20, 7b78 <f12+0xdf8>
    7058:	f9400800 	ldr	x0, [x0, #16]
    705c:	91000442 	add	x2, x2, #0x1
    7060:	b5ffffc0 	cbnz	x0, 7058 <f12+0x2d8>
    7064:	aa1403e1 	mov	x1, x20
    7068:	f9400821 	ldr	x1, [x1, #16]
    706c:	91000400 	add	x0, x0, #0x1
    7070:	b5ffffc1 	cbnz	x1, 7068 <f12+0x2e8>
    7074:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7078:	eb01001f 	cmp	x0, x1
    707c:	54006b68 	b.hi	7de8 <f12+0x1068>  // b.pmore
    7080:	f100005f 	cmp	x2, #0x0
    7084:	540057ad 	b.le	7b78 <f12+0xdf8>
    7088:	eb00005f 	cmp	x2, x0
    708c:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7090:	9a809053 	csel	x19, x2, x0, ls	// ls = plast
    7094:	eb01027f 	cmp	x19, x1
    7098:	54006a88 	b.hi	7de8 <f12+0x1068>  // b.pmore
    709c:	d37ffa7a 	lsl	x26, x19, #1
    70a0:	52800041 	mov	w1, #0x2                   	// #2
    70a4:	91000740 	add	x0, x26, #0x1
    70a8:	d37df000 	lsl	x0, x0, #3
    70ac:	97fff7f9 	bl	5090 <fwp_heap_alloc>
    70b0:	aa0003fb 	mov	x27, x0
    70b4:	9118c2e1 	add	x1, x23, #0x630
    70b8:	aa0103e0 	mov	x0, x1
    70bc:	f900037a 	str	x26, [x27]
    70c0:	f949d821 	ldr	x1, [x1, #5040]
    70c4:	f949ec00 	ldr	x0, [x0, #5080]
    70c8:	cb010361 	sub	x1, x27, x1
    70cc:	eb00403f 	cmp	x1, x0, lsl #16
    70d0:	54005742 	b.cs	7bb8 <f12+0xe38>  // b.hs, b.nlast
    70d4:	9118c2e2 	add	x2, x23, #0x630
    70d8:	d350fc20 	lsr	x0, x1, #16
    70dc:	8b000800 	add	x0, x0, x0, lsl #2
    70e0:	f949fc43 	ldr	x3, [x2, #5112]
    70e4:	d37df002 	lsl	x2, x0, #3
    70e8:	8b020060 	add	x0, x3, x2
    70ec:	f940101a 	ldr	x26, [x0, #32]
    70f0:	b400025a 	cbz	x26, 7138 <f12+0x3b8>
    70f4:	38626862 	ldrb	w2, [x3, x2]
    70f8:	7100085f 	cmp	w2, #0x2
    70fc:	54005740 	b.eq	7be4 <f12+0xe64>  // b.none
    7100:	7100045f 	cmp	w2, #0x1
    7104:	540001a1 	b.ne	7138 <f12+0x3b8>  // b.any
    7108:	29430002 	ldp	w2, w0, [x0, #24]
    710c:	92403c21 	and	x1, x1, #0xffff
    7110:	9b027c21 	mul	x1, x1, x2
    7114:	d360fc21 	lsr	x1, x1, #32
    7118:	eb00003f 	cmp	x1, x0
    711c:	540000e2 	b.cs	7138 <f12+0x3b8>  // b.hs, b.nlast
    7120:	8b01035a 	add	x26, x26, x1
    7124:	39400340 	ldrb	w0, [x26]
    7128:	7103fc1f 	cmp	w0, #0xff
    712c:	54006260 	b.eq	7d78 <f12+0xff8>  // b.none
    7130:	52800020 	mov	w0, #0x1                   	// #1
    7134:	39000340 	strb	w0, [x26]
    7138:	b4000233 	cbz	x19, 717c <f12+0x3fc>
    713c:	d3607f24 	lsl	x4, x25, #32
    7140:	aa1403e2 	mov	x2, x20
    7144:	f9400685 	ldr	x5, [x20, #8]
    7148:	aa0403e3 	mov	x3, x4
    714c:	91002360 	add	x0, x27, #0x8
    7150:	d2800001 	mov	x1, #0x0                   	// #0
    7154:	14000005 	b	7168 <f12+0x3e8>
    7158:	f9400445 	ldr	x5, [x2, #8]
    715c:	ab040023 	adds	x3, x1, x4
    7160:	91004000 	add	x0, x0, #0x10
    7164:	54006706 	b.vs	7e44 <f12+0x10c4>
    7168:	a9000c05 	stp	x5, x3, [x0]
    716c:	91000421 	add	x1, x1, #0x1
    7170:	f9400842 	ldr	x2, [x2, #16]
    7174:	eb01027f 	cmp	x19, x1
    7178:	54ffff08 	b.hi	7158 <f12+0x3d8>  // b.pmore
    717c:	f9400360 	ldr	x0, [x27]
    7180:	f100041f 	cmp	x0, #0x1
    7184:	540051e9 	b.ls	7bc0 <f12+0xe40>  // b.plast
    7188:	d341fc00 	lsr	x0, x0, #1
    718c:	92fe0002 	mov	x2, #0xfffffffffffffff     	// #1152921504606846975
    7190:	d1000401 	sub	x1, x0, #0x1
    7194:	eb02003f 	cmp	x1, x2
    7198:	54006288 	b.hi	7de8 <f12+0x1068>  // b.pmore
    719c:	d37ff83c 	lsl	x28, x1, #1
    71a0:	b4005101 	cbz	x1, 7bc0 <f12+0xe40>
    71a4:	d1002361 	sub	x1, x27, #0x8
    71a8:	91002373 	add	x19, x27, #0x8
    71ac:	8b00103a 	add	x26, x1, x0, lsl #4
    71b0:	f9400660 	ldr	x0, [x19, #8]
    71b4:	f9400e61 	ldr	x1, [x19, #24]
    71b8:	fd400260 	ldr	d0, [x19]
    71bc:	fd400a61 	ldr	d1, [x19, #16]
    71c0:	97fff980 	bl	57c0 <w107>
    71c4:	a9000660 	stp	x0, x1, [x19]
    71c8:	91004273 	add	x19, x19, #0x10
    71cc:	eb1a027f 	cmp	x19, x26
    71d0:	54ffff01 	b.ne	71b0 <f12+0x430>  // b.any
    71d4:	f900037c 	str	x28, [x27]
    71d8:	aa1b03e0 	mov	x0, x27
    71dc:	93407f33 	sxtw	x19, w25
    71e0:	97fff9d5 	bl	5934 <w164.constprop.0>
    71e4:	aa0103fa 	mov	x26, x1
    71e8:	aa1b03e0 	mov	x0, x27
    71ec:	97fffe45 	bl	6b00 <fwp_drop4>
    71f0:	aa1303e0 	mov	x0, x19
    71f4:	97fff22f 	bl	3ab0 <fwp_tape_of>
    71f8:	f9403001 	ldr	x1, [x0, #96]
    71fc:	aa0003ea 	mov	x10, x0
    7200:	b5006121 	cbnz	x1, 7e24 <f12+0x10a4>
    7204:	97ffef64 	bl	2f94 <fwp_tape_unlink_scope>
    7208:	b9400002 	ldr	w2, [x0]
    720c:	528fffc1 	mov	w1, #0x7ffe                	// #32766
    7210:	a940801c 	ldp	x28, x0, [x0, #8]
    7214:	b900055f 	str	wzr, [x10, #4]
    7218:	a941994b 	ldp	x11, x6, [x10, #24]
    721c:	a942a147 	ldp	x7, x8, [x10, #40]
    7220:	a9439549 	ldp	x9, x5, [x10, #56]
    7224:	f940255b 	ldr	x27, [x10, #72]
    7228:	6b01005f 	cmp	w2, w1
    722c:	54000108 	b.hi	724c <f12+0x4cc>  // b.pmore
    7230:	910142a2 	add	x2, x21, #0x50
    7234:	92403e61 	and	x1, x19, #0xffff
    7238:	d1000421 	sub	x1, x1, #0x1
    723c:	f940b043 	ldr	x3, [x2, #352]
    7240:	eb03003f 	cmp	x1, x3
    7244:	5400004a 	b.ge	724c <f12+0x4cc>  // b.tcont
    7248:	f900b041 	str	x1, [x2, #352]
    724c:	4f000400 	movi	v0.4s, #0x0
    7250:	910142a3 	add	x3, x21, #0x50
    7254:	f9000d5f 	str	xzr, [x10, #24]
    7258:	910163e1 	add	x1, sp, #0x58
    725c:	9101c3f9 	add	x25, sp, #0x70
    7260:	b0ffffe2 	adrp	x2, 4000 <fwp_heap_report+0xe0>
    7264:	f941c86c 	ldr	x12, [x3, #912]
    7268:	3c808140 	stur	q0, [x10, #8]
    726c:	91129042 	add	x2, x2, #0x4a4
    7270:	ad010140 	stp	q0, q0, [x10, #32]
    7274:	a9047d5f 	stp	xzr, xzr, [x10, #64]
    7278:	a9058bec 	stp	x12, x2, [sp, #88]
    727c:	a9069bf9 	stp	x25, x6, [sp, #104]
    7280:	a907a3e7 	stp	x7, x8, [sp, #120]
    7284:	a90897e9 	stp	x9, x5, [sp, #136]
    7288:	a909efeb 	stp	x11, x27, [sp, #152]
    728c:	f901c861 	str	x1, [x3, #912]
    7290:	b7f84bfa 	tbnz	x26, #63, 7c0c <f12+0xe8c>
    7294:	eb9a827f 	cmp	x19, x26, asr #32
    7298:	54005961 	b.ne	7dc4 <f12+0x1044>  // b.any
    729c:	92407f53 	and	x19, x26, #0xffffffff
    72a0:	eb3a401f 	cmp	x0, w26, uxtw
    72a4:	5400596d 	b.le	7dd0 <f12+0x1050>
    72a8:	eb13039f 	cmp	x28, x19
    72ac:	9a93c793 	csinc	x19, x28, x19, gt
    72b0:	eb13037f 	cmp	x27, x19
    72b4:	540019ea 	b.ge	75f0 <f12+0x870>  // b.tcont
    72b8:	f100037f 	cmp	x27, #0x0
    72bc:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    72c0:	9a93137b 	csel	x27, x27, x19, ne	// ne = any
    72c4:	14000004 	b	72d4 <f12+0x554>
    72c8:	eb01037f 	cmp	x27, x1
    72cc:	d37ffb7b 	lsl	x27, x27, #1
    72d0:	9a93d37b 	csel	x27, x27, x19, le
    72d4:	eb13037f 	cmp	x27, x19
    72d8:	54ffff8b 	b.lt	72c8 <f12+0x548>  // b.tstop
    72dc:	b4004e05 	cbz	x5, 7c9c <f12+0xf1c>
    72e0:	aa0503e0 	mov	x0, x5
    72e4:	d37df361 	lsl	x1, x27, #3
    72e8:	52800062 	mov	w2, #0x3                   	// #3
    72ec:	a9009fe6 	stp	x6, x7, [sp, #8]
    72f0:	a901a7e8 	stp	x8, x9, [sp, #24]
    72f4:	97fff438 	bl	43d4 <ad_raw_realloc>
    72f8:	aa0003e5 	mov	x5, x0
    72fc:	a9409fe6 	ldp	x6, x7, [sp, #8]
    7300:	a941a7e8 	ldp	x8, x9, [sp, #24]
    7304:	b4004b20 	cbz	x0, 7c68 <f12+0xee8>
    7308:	f9004be5 	str	x5, [sp, #144]
    730c:	f90053fb 	str	x27, [sp, #160]
    7310:	b50015d3 	cbnz	x19, 75c8 <f12+0x848>
    7314:	b7f800da 	tbnz	x26, #63, 732c <f12+0x5ac>
    7318:	92407f41 	and	x1, x26, #0xffffffff
    731c:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7320:	fc6178a0 	ldr	d0, [x5, x1, lsl #3]
    7324:	1e612800 	fadd	d0, d0, d1
    7328:	fc2178a0 	str	d0, [x5, x1, lsl #3]
    732c:	d1000673 	sub	x19, x19, #0x1
    7330:	d1000783 	sub	x3, x28, #0x1
    7334:	eb13039f 	cmp	x28, x19
    7338:	540003ac 	b.gt	73ac <f12+0x62c>
    733c:	fc7378a0 	ldr	d0, [x5, x19, lsl #3]
    7340:	1e602008 	fcmp	d0, #0.0
    7344:	540002e0 	b.eq	73a0 <f12+0x620>  // b.none
    7348:	cb1c0be0 	neg	x0, x28, lsl #2
    734c:	cb1c03e2 	neg	x2, x28
    7350:	8b0000c1 	add	x1, x6, x0
    7354:	b8737821 	ldr	w1, [x1, x19, lsl #2]
    7358:	37f80101 	tbnz	w1, #31, 7378 <f12+0x5f8>
    735c:	8b020d0a 	add	x10, x8, x2, lsl #3
    7360:	93407c21 	sxtw	x1, w1
    7364:	fc737942 	ldr	d2, [x10, x19, lsl #3]
    7368:	fc6178a1 	ldr	d1, [x5, x1, lsl #3]
    736c:	1e620802 	fmul	d2, d0, d2
    7370:	1e622821 	fadd	d1, d1, d2
    7374:	fc2178a1 	str	d1, [x5, x1, lsl #3]
    7378:	8b0000e0 	add	x0, x7, x0
    737c:	b8737800 	ldr	w0, [x0, x19, lsl #2]
    7380:	37f80100 	tbnz	w0, #31, 73a0 <f12+0x620>
    7384:	8b020d22 	add	x2, x9, x2, lsl #3
    7388:	93407c00 	sxtw	x0, w0
    738c:	fc737842 	ldr	d2, [x2, x19, lsl #3]
    7390:	fc6078a1 	ldr	d1, [x5, x0, lsl #3]
    7394:	1e620800 	fmul	d0, d0, d2
    7398:	1e602820 	fadd	d0, d1, d0
    739c:	fc2078a0 	str	d0, [x5, x0, lsl #3]
    73a0:	d1000673 	sub	x19, x19, #0x1
    73a4:	eb13007f 	cmp	x3, x19
    73a8:	54fffca1 	b.ne	733c <f12+0x5bc>  // b.any
    73ac:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    73b0:	eb00039f 	cmp	x28, x0
    73b4:	54005208 	b.hi	7df4 <f12+0x1074>  // b.pmore
    73b8:	91000780 	add	x0, x28, #0x1
    73bc:	52800041 	mov	w1, #0x2                   	// #2
    73c0:	f90007e5 	str	x5, [sp, #8]
    73c4:	d37df000 	lsl	x0, x0, #3
    73c8:	97fff732 	bl	5090 <fwp_heap_alloc>
    73cc:	aa0003e2 	mov	x2, x0
    73d0:	aa0003f3 	mov	x19, x0
    73d4:	f94007e5 	ldr	x5, [sp, #8]
    73d8:	d2800001 	mov	x1, #0x0                   	// #0
    73dc:	f800845c 	str	x28, [x2], #8
    73e0:	b40000fc 	cbz	x28, 73fc <f12+0x67c>
    73e4:	d503201f 	nop
    73e8:	f86178a0 	ldr	x0, [x5, x1, lsl #3]
    73ec:	f8217840 	str	x0, [x2, x1, lsl #3]
    73f0:	91000421 	add	x1, x1, #0x1
    73f4:	eb01039f 	cmp	x28, x1
    73f8:	54ffff81 	b.ne	73e8 <f12+0x668>  // b.any
    73fc:	910142a1 	add	x1, x21, #0x50
    7400:	aa1903e0 	mov	x0, x25
    7404:	f9402ffa 	ldr	x26, [sp, #88]
    7408:	f901c83a 	str	x26, [x1, #912]
    740c:	97fff426 	bl	44a4 <fwp_tape_buffers_release>
    7410:	9118c2e2 	add	x2, x23, #0x630
    7414:	f949d841 	ldr	x1, [x2, #5040]
    7418:	f949ec40 	ldr	x0, [x2, #5080]
    741c:	cb010261 	sub	x1, x19, x1
    7420:	eb00403f 	cmp	x1, x0, lsl #16
    7424:	54000322 	b.cs	7488 <f12+0x708>  // b.hs, b.nlast
    7428:	d350fc20 	lsr	x0, x1, #16
    742c:	f949fc43 	ldr	x3, [x2, #5112]
    7430:	8b000800 	add	x0, x0, x0, lsl #2
    7434:	d37df002 	lsl	x2, x0, #3
    7438:	8b020060 	add	x0, x3, x2
    743c:	f9401019 	ldr	x25, [x0, #32]
    7440:	b4000259 	cbz	x25, 7488 <f12+0x708>
    7444:	38626862 	ldrb	w2, [x3, x2]
    7448:	7100085f 	cmp	w2, #0x2
    744c:	54003e40 	b.eq	7c14 <f12+0xe94>  // b.none
    7450:	7100045f 	cmp	w2, #0x1
    7454:	540001a1 	b.ne	7488 <f12+0x708>  // b.any
    7458:	29430002 	ldp	w2, w0, [x0, #24]
    745c:	92403c21 	and	x1, x1, #0xffff
    7460:	9b027c21 	mul	x1, x1, x2
    7464:	d360fc21 	lsr	x1, x1, #32
    7468:	eb00003f 	cmp	x1, x0
    746c:	540000e2 	b.cs	7488 <f12+0x708>  // b.hs, b.nlast
    7470:	8b010339 	add	x25, x25, x1
    7474:	39400320 	ldrb	w0, [x25]
    7478:	7103fc1f 	cmp	w0, #0xff
    747c:	54004840 	b.eq	7d84 <f12+0x1004>  // b.none
    7480:	52800020 	mov	w0, #0x1                   	// #1
    7484:	39000320 	strb	w0, [x25]
    7488:	eb18035f 	cmp	x26, x24
    748c:	54004da1 	b.ne	7e40 <f12+0x10c0>  // b.any
    7490:	f94023e1 	ldr	x1, [sp, #64]
    7494:	910142b5 	add	x21, x21, #0x50
    7498:	aa1603e0 	mov	x0, x22
    749c:	f901caa1 	str	x1, [x21, #912]
    74a0:	97fffc44 	bl	65b0 <fwp_tape_scope_release>
    74a4:	f9400260 	ldr	x0, [x19]
    74a8:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    74ac:	b7f83120 	tbnz	x0, #63, 7ad0 <f12+0xd50>
    74b0:	9118c2e2 	add	x2, x23, #0x630
    74b4:	f949d840 	ldr	x0, [x2, #5040]
    74b8:	f949ec41 	ldr	x1, [x2, #5080]
    74bc:	cb000260 	sub	x0, x19, x0
    74c0:	eb01401f 	cmp	x0, x1, lsl #16
    74c4:	54003062 	b.cs	7ad0 <f12+0xd50>  // b.hs, b.nlast
    74c8:	d350fc01 	lsr	x1, x0, #16
    74cc:	f949fc44 	ldr	x4, [x2, #5112]
    74d0:	8b010821 	add	x1, x1, x1, lsl #2
    74d4:	d37df021 	lsl	x1, x1, #3
    74d8:	8b010083 	add	x3, x4, x1
    74dc:	f9401062 	ldr	x2, [x3, #32]
    74e0:	b4002f82 	cbz	x2, 7ad0 <f12+0xd50>
    74e4:	38616881 	ldrb	w1, [x4, x1]
    74e8:	7100083f 	cmp	w1, #0x2
    74ec:	54002ec0 	b.eq	7ac4 <f12+0xd44>  // b.none
    74f0:	7100043f 	cmp	w1, #0x1
    74f4:	54002ee1 	b.ne	7ad0 <f12+0xd50>  // b.any
    74f8:	29430464 	ldp	w4, w1, [x3, #24]
    74fc:	92403c00 	and	x0, x0, #0xffff
    7500:	9b047c00 	mul	x0, x0, x4
    7504:	d360fc00 	lsr	x0, x0, #32
    7508:	eb01001f 	cmp	x0, x1
    750c:	54002e22 	b.cs	7ad0 <f12+0xd50>  // b.hs, b.nlast
    7510:	8b000042 	add	x2, x2, x0
    7514:	39400040 	ldrb	w0, [x2]
    7518:	7100041f 	cmp	w0, #0x1
    751c:	54002da1 	b.ne	7ad0 <f12+0xd50>  // b.any
    7520:	aa1303f5 	mov	x21, x19
    7524:	d2800000 	mov	x0, #0x0                   	// #0
    7528:	f90007f3 	str	x19, [sp, #8]
    752c:	f94007e1 	ldr	x1, [sp, #8]
    7530:	91002023 	add	x3, x1, #0x8
    7534:	d2800001 	mov	x1, #0x0                   	// #0
    7538:	b4000898 	cbz	x24, 7648 <f12+0x8c8>
    753c:	90000022 	adrp	x2, b000 <_IO_stdin_used+0x350>
    7540:	91002265 	add	x5, x19, #0x8
    7544:	fd464041 	ldr	d1, [x2, #3200]
    7548:	14000009 	b	756c <f12+0x7ec>
    754c:	fc617840 	ldr	d0, [x2, x1, lsl #3]
    7550:	f94002a2 	ldr	x2, [x21]
    7554:	1e600820 	fmul	d0, d1, d0
    7558:	b7f84422 	tbnz	x2, #63, 7ddc <f12+0x105c>
    755c:	91000421 	add	x1, x1, #0x1
    7560:	fc008460 	str	d0, [x3], #8
    7564:	eb01031f 	cmp	x24, x1
    7568:	54000700 	b.eq	7648 <f12+0x8c8>  // b.none
    756c:	f9400264 	ldr	x4, [x19]
    7570:	aa0503e2 	mov	x2, x5
    7574:	b6fffec4 	tbz	x4, #63, 754c <f12+0x7cc>
    7578:	f9400a62 	ldr	x2, [x19, #16]
    757c:	17fffff4 	b	754c <f12+0x7cc>
    7580:	eb19037f 	cmp	x27, x25
    7584:	54ffcc40 	b.eq	6f0c <f12+0x18c>  // b.none
    7588:	910142a0 	add	x0, x21, #0x50
    758c:	8b19073b 	add	x27, x25, x25, lsl #1
    7590:	8b1b0b3b 	add	x27, x25, x27, lsl #2
    7594:	f940441c 	ldr	x28, [x0, #136]
    7598:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    759c:	9102c000 	add	x0, x0, #0xb0
    75a0:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    75a4:	f900337f 	str	xzr, [x27, #96]
    75a8:	97ffecfe 	bl	29a0 <getenv@plt>
    75ac:	b4ffd0a0 	cbz	x0, 6fc0 <f12+0x240>
    75b0:	39400001 	ldrb	w1, [x0]
    75b4:	7100c03f 	cmp	w1, #0x30
    75b8:	54ffd041 	b.ne	6fc0 <f12+0x240>  // b.any
    75bc:	39400400 	ldrb	w0, [x0, #1]
    75c0:	34ffd060 	cbz	w0, 6fcc <f12+0x24c>
    75c4:	17fffe7f 	b	6fc0 <f12+0x240>
    75c8:	aa0503e0 	mov	x0, x5
    75cc:	d37df262 	lsl	x2, x19, #3
    75d0:	52800001 	mov	w1, #0x0                   	// #0
    75d4:	a9009fe6 	stp	x6, x7, [sp, #8]
    75d8:	a901a7e8 	stp	x8, x9, [sp, #24]
    75dc:	97ffec81 	bl	27e0 <memset@plt>
    75e0:	aa0003e5 	mov	x5, x0
    75e4:	a9409fe6 	ldp	x6, x7, [sp, #8]
    75e8:	a941a7e8 	ldp	x8, x9, [sp, #24]
    75ec:	17ffff4a 	b	7314 <f12+0x594>
    75f0:	f10000bf 	cmp	x5, #0x0
    75f4:	1a9f17e0 	cset	w0, eq	// eq = none
    75f8:	f100027f 	cmp	x19, #0x0
    75fc:	7a401804 	ccmp	w0, #0x0, #0x4, ne	// ne = any
    7600:	54ffe880 	b.eq	7310 <f12+0x590>  // b.none
    7604:	f9402fe1 	ldr	x1, [sp, #88]
    7608:	910142b5 	add	x21, x21, #0x50
    760c:	aa1903e0 	mov	x0, x25
    7610:	f901caa1 	str	x1, [x21, #912]
    7614:	97fff3a4 	bl	44a4 <fwp_tape_buffers_release>
    7618:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    761c:	f947e863 	ldr	x3, [x3, #4048]
    7620:	d2800262 	mov	x2, #0x13                  	// #19
    7624:	d2800021 	mov	x1, #0x1                   	// #1
    7628:	f0000000 	adrp	x0, a000 <fwp_main_thread+0x650>
    762c:	9132e000 	add	x0, x0, #0xcb8
    7630:	f9400063 	ldr	x3, [x3]
    7634:	97ffecb7 	bl	2910 <fwrite@plt>
    7638:	d2800000 	mov	x0, #0x0                   	// #0
    763c:	97ffecc1 	bl	2940 <fflush@plt>
    7640:	52800cc0 	mov	w0, #0x66                  	// #102
    7644:	97ffeccf 	bl	2980 <_Exit@plt>
    7648:	97fffd2e 	bl	6b00 <fwp_drop4>
    764c:	aa1403e1 	mov	x1, x20
    7650:	d2800002 	mov	x2, #0x0                   	// #0
    7654:	b4003774 	cbz	x20, 7d40 <f12+0xfc0>
    7658:	f9400821 	ldr	x1, [x1, #16]
    765c:	91000442 	add	x2, x2, #0x1
    7660:	b5ffffc1 	cbnz	x1, 7658 <f12+0x8d8>
    7664:	f94002a3 	ldr	x3, [x21]
    7668:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    766c:	b7f81f43 	tbnz	x3, #63, 7a54 <f12+0xcd4>
    7670:	9118c2e1 	add	x1, x23, #0x630
    7674:	f94007e4 	ldr	x4, [sp, #8]
    7678:	f949d820 	ldr	x0, [x1, #5040]
    767c:	f949ec21 	ldr	x1, [x1, #5080]
    7680:	cb000080 	sub	x0, x4, x0
    7684:	eb01401f 	cmp	x0, x1, lsl #16
    7688:	54001e62 	b.cs	7a54 <f12+0xcd4>  // b.hs, b.nlast
    768c:	9118c2e4 	add	x4, x23, #0x630
    7690:	d350fc01 	lsr	x1, x0, #16
    7694:	8b010821 	add	x1, x1, x1, lsl #2
    7698:	f949fc86 	ldr	x6, [x4, #5112]
    769c:	d37df021 	lsl	x1, x1, #3
    76a0:	8b0100c5 	add	x5, x6, x1
    76a4:	f94010a4 	ldr	x4, [x5, #32]
    76a8:	b4001d44 	cbz	x4, 7a50 <f12+0xcd0>
    76ac:	386168c1 	ldrb	w1, [x6, x1]
    76b0:	7100083f 	cmp	w1, #0x2
    76b4:	54001ca0 	b.eq	7a48 <f12+0xcc8>  // b.none
    76b8:	7100043f 	cmp	w1, #0x1
    76bc:	54001ca1 	b.ne	7a50 <f12+0xcd0>  // b.any
    76c0:	294304a6 	ldp	w6, w1, [x5, #24]
    76c4:	92403c00 	and	x0, x0, #0xffff
    76c8:	9b067c00 	mul	x0, x0, x6
    76cc:	d360fc00 	lsr	x0, x0, #32
    76d0:	eb01001f 	cmp	x0, x1
    76d4:	54001be2 	b.cs	7a50 <f12+0xcd0>  // b.hs, b.nlast
    76d8:	8b000084 	add	x4, x4, x0
    76dc:	39400098 	ldrb	w24, [x4]
    76e0:	7100071f 	cmp	w24, #0x1
    76e4:	54001b61 	b.ne	7a50 <f12+0xcd0>  // b.any
    76e8:	b90013f8 	str	w24, [sp, #16]
    76ec:	eb1c005f 	cmp	x2, x28
    76f0:	9a9c905c 	csel	x28, x2, x28, ls	// ls = plast
    76f4:	910022b9 	add	x25, x21, #0x8
    76f8:	b400361c 	cbz	x28, 7db8 <f12+0x1038>
    76fc:	f94007e0 	ldr	x0, [sp, #8]
    7700:	d37df385 	lsl	x5, x28, #3
    7704:	aa1403e2 	mov	x2, x20
    7708:	d2800001 	mov	x1, #0x0                   	// #0
    770c:	91002000 	add	x0, x0, #0x8
    7710:	1400000a 	b	7738 <f12+0x9b8>
    7714:	fc616881 	ldr	d1, [x4, x1]
    7718:	fd400440 	ldr	d0, [x2, #8]
    771c:	1e613800 	fsub	d0, d0, d1
    7720:	fc216b20 	str	d0, [x25, x1]
    7724:	91002021 	add	x1, x1, #0x8
    7728:	f9400842 	ldr	x2, [x2, #16]
    772c:	eb05003f 	cmp	x1, x5
    7730:	540001c0 	b.eq	7768 <f12+0x9e8>  // b.none
    7734:	f94002a3 	ldr	x3, [x21]
    7738:	aa0003e4 	mov	x4, x0
    773c:	b6fffec3 	tbz	x3, #63, 7714 <f12+0x994>
    7740:	f94007e3 	ldr	x3, [sp, #8]
    7744:	fd400440 	ldr	d0, [x2, #8]
    7748:	f9400864 	ldr	x4, [x3, #16]
    774c:	fc616881 	ldr	d1, [x4, x1]
    7750:	1e613800 	fsub	d0, d0, d1
    7754:	fc216b20 	str	d0, [x25, x1]
    7758:	91002021 	add	x1, x1, #0x8
    775c:	f9400842 	ldr	x2, [x2, #16]
    7760:	eb05003f 	cmp	x1, x5
    7764:	54fffe81 	b.ne	7734 <f12+0x9b4>  // b.any
    7768:	b4003254 	cbz	x20, 7db0 <f12+0x1030>
    776c:	9118c2e0 	add	x0, x23, #0x630
    7770:	aa1403e2 	mov	x2, x20
    7774:	d280001a 	mov	x26, #0x0                   	// #0
    7778:	f949ec06 	ldr	x6, [x0, #5080]
    777c:	f949d807 	ldr	x7, [x0, #5040]
    7780:	f949fc05 	ldr	x5, [x0, #5112]
    7784:	d370bcc6 	lsl	x6, x6, #16
    7788:	14000006 	b	77a0 <f12+0xa20>
    778c:	f9400842 	ldr	x2, [x2, #16]
    7790:	9100075a 	add	x26, x26, #0x1
    7794:	f100005f 	cmp	x2, #0x0
    7798:	fa5a1380 	ccmp	x28, x26, #0x0, ne	// ne = any
    779c:	54000329 	b.ls	7800 <f12+0xa80>  // b.plast
    77a0:	cb070040 	sub	x0, x2, x7
    77a4:	eb06001f 	cmp	x0, x6
    77a8:	540002c2 	b.cs	7800 <f12+0xa80>  // b.hs, b.nlast
    77ac:	d350fc01 	lsr	x1, x0, #16
    77b0:	8b010821 	add	x1, x1, x1, lsl #2
    77b4:	d37df021 	lsl	x1, x1, #3
    77b8:	8b0100a4 	add	x4, x5, x1
    77bc:	f9401083 	ldr	x3, [x4, #32]
    77c0:	b4000203 	cbz	x3, 7800 <f12+0xa80>
    77c4:	386168a1 	ldrb	w1, [x5, x1]
    77c8:	7100083f 	cmp	w1, #0x2
    77cc:	54000de0 	b.eq	7988 <f12+0xc08>  // b.none
    77d0:	7100043f 	cmp	w1, #0x1
    77d4:	54000161 	b.ne	7800 <f12+0xa80>  // b.any
    77d8:	29430488 	ldp	w8, w1, [x4, #24]
    77dc:	92403c00 	and	x0, x0, #0xffff
    77e0:	9b087c00 	mul	x0, x0, x8
    77e4:	d360fc00 	lsr	x0, x0, #32
    77e8:	eb01001f 	cmp	x0, x1
    77ec:	540000a2 	b.cs	7800 <f12+0xa80>  // b.hs, b.nlast
    77f0:	8b000063 	add	x3, x3, x0
    77f4:	39400060 	ldrb	w0, [x3]
    77f8:	7100041f 	cmp	w0, #0x1
    77fc:	54fffc80 	b.eq	778c <f12+0xa0c>  // b.none
    7800:	eb1a039f 	cmp	x28, x26
    7804:	54000ca9 	b.ls	7998 <f12+0xc18>  // b.plast
    7808:	d1002336 	sub	x22, x25, #0x8
    780c:	9102a3f5 	add	x21, sp, #0xa8
    7810:	9118c2f8 	add	x24, x23, #0x630
    7814:	d2800013 	mov	x19, #0x0                   	// #0
    7818:	14000012 	b	7860 <f12+0xae0>
    781c:	7100045f 	cmp	w2, #0x1
    7820:	540001a1 	b.ne	7854 <f12+0xad4>  // b.any
    7824:	29430002 	ldp	w2, w0, [x0, #24]
    7828:	92403c21 	and	x1, x1, #0xffff
    782c:	9b027c21 	mul	x1, x1, x2
    7830:	d360fc21 	lsr	x1, x1, #32
    7834:	eb00003f 	cmp	x1, x0
    7838:	540000e2 	b.cs	7854 <f12+0xad4>  // b.hs, b.nlast
    783c:	8b01037b 	add	x27, x27, x1
    7840:	39400360 	ldrb	w0, [x27]
    7844:	7103fc1f 	cmp	w0, #0xff
    7848:	54001b20 	b.eq	7bac <f12+0xe2c>  // b.none
    784c:	52800020 	mov	w0, #0x1                   	// #1
    7850:	39000360 	strb	w0, [x27]
    7854:	d100079c 	sub	x28, x28, #0x1
    7858:	eb1c035f 	cmp	x26, x28
    785c:	54000362 	b.cs	78c8 <f12+0xb48>  // b.hs, b.nlast
    7860:	f87c7ac2 	ldr	x2, [x22, x28, lsl #3]
    7864:	aa1503e1 	mov	x1, x21
    7868:	52800020 	mov	w0, #0x1                   	// #1
    786c:	a90acfe2 	stp	x2, x19, [sp, #168]
    7870:	97fff859 	bl	59d4 <fwp_data.part.0.constprop.0>
    7874:	aa0003f3 	mov	x19, x0
    7878:	f949db01 	ldr	x1, [x24, #5040]
    787c:	f949ef00 	ldr	x0, [x24, #5080]
    7880:	cb010261 	sub	x1, x19, x1
    7884:	eb00403f 	cmp	x1, x0, lsl #16
    7888:	54fffe62 	b.cs	7854 <f12+0xad4>  // b.hs, b.nlast
    788c:	d350fc22 	lsr	x2, x1, #16
    7890:	f949ff03 	ldr	x3, [x24, #5112]
    7894:	8b020842 	add	x2, x2, x2, lsl #2
    7898:	d37df042 	lsl	x2, x2, #3
    789c:	8b020060 	add	x0, x3, x2
    78a0:	f940101b 	ldr	x27, [x0, #32]
    78a4:	b4fffd9b 	cbz	x27, 7854 <f12+0xad4>
    78a8:	38626862 	ldrb	w2, [x3, x2]
    78ac:	7100085f 	cmp	w2, #0x2
    78b0:	54fffb61 	b.ne	781c <f12+0xa9c>  // b.any
    78b4:	72003c3f 	tst	w1, #0xffff
    78b8:	54fffc40 	b.eq	7840 <f12+0xac0>  // b.none
    78bc:	d100079c 	sub	x28, x28, #0x1
    78c0:	eb1c035f 	cmp	x26, x28
    78c4:	54fffce3 	b.cc	7860 <f12+0xae0>  // b.lo, b.ul, b.last
    78c8:	b50006ba 	cbnz	x26, 799c <f12+0xc1c>
    78cc:	b94013e0 	ldr	w0, [sp, #16]
    78d0:	d2800038 	mov	x24, #0x1                   	// #1
    78d4:	d280001b 	mov	x27, #0x0                   	// #0
    78d8:	7100001f 	cmp	w0, #0x0
    78dc:	9a9f0339 	csel	x25, x25, xzr, eq	// eq = none
    78e0:	b40007db 	cbz	x27, 79d8 <f12+0xc58>
    78e4:	d100077b 	sub	x27, x27, #0x1
    78e8:	9118c2f7 	add	x23, x23, #0x630
    78ec:	d503201f 	nop
    78f0:	f87b7b22 	ldr	x2, [x25, x27, lsl #3]
    78f4:	aa1503e1 	mov	x1, x21
    78f8:	52800020 	mov	w0, #0x1                   	// #1
    78fc:	a90acfe2 	stp	x2, x19, [sp, #168]
    7900:	97fff835 	bl	59d4 <fwp_data.part.0.constprop.0>
    7904:	aa0003f3 	mov	x19, x0
    7908:	f949dae1 	ldr	x1, [x23, #5040]
    790c:	f949eee0 	ldr	x0, [x23, #5080]
    7910:	cb010261 	sub	x1, x19, x1
    7914:	eb00403f 	cmp	x1, x0, lsl #16
    7918:	54000302 	b.cs	7978 <f12+0xbf8>  // b.hs, b.nlast
    791c:	d350fc22 	lsr	x2, x1, #16
    7920:	f949fee3 	ldr	x3, [x23, #5112]
    7924:	8b020842 	add	x2, x2, x2, lsl #2
    7928:	d37df042 	lsl	x2, x2, #3
    792c:	8b020060 	add	x0, x3, x2
    7930:	f940101a 	ldr	x26, [x0, #32]
    7934:	b400023a 	cbz	x26, 7978 <f12+0xbf8>
    7938:	38626862 	ldrb	w2, [x3, x2]
    793c:	7100085f 	cmp	w2, #0x2
    7940:	540007e0 	b.eq	7a3c <f12+0xcbc>  // b.none
    7944:	7100045f 	cmp	w2, #0x1
    7948:	54000181 	b.ne	7978 <f12+0xbf8>  // b.any
    794c:	29430002 	ldp	w2, w0, [x0, #24]
    7950:	92403c21 	and	x1, x1, #0xffff
    7954:	9b027c21 	mul	x1, x1, x2
    7958:	d360fc21 	lsr	x1, x1, #32
    795c:	eb00003f 	cmp	x1, x0
    7960:	540000c2 	b.cs	7978 <f12+0xbf8>  // b.hs, b.nlast
    7964:	8b01035a 	add	x26, x26, x1
    7968:	39400340 	ldrb	w0, [x26]
    796c:	7103fc1f 	cmp	w0, #0xff
    7970:	54000600 	b.eq	7a30 <f12+0xcb0>  // b.none
    7974:	39000358 	strb	w24, [x26]
    7978:	d100077b 	sub	x27, x27, #0x1
    797c:	b100077f 	cmn	x27, #0x1
    7980:	54fffb81 	b.ne	78f0 <f12+0xb70>  // b.any
    7984:	14000015 	b	79d8 <f12+0xc58>
    7988:	72003c1f 	tst	w0, #0xffff
    798c:	54fff340 	b.eq	77f4 <f12+0xa74>  // b.none
    7990:	eb1a039f 	cmp	x28, x26
    7994:	54fff3a8 	b.hi	7808 <f12+0xa88>  // b.pmore
    7998:	d2800013 	mov	x19, #0x0                   	// #0
    799c:	8b1a0f3a 	add	x26, x25, x26, lsl #3
    79a0:	aa1903e1 	mov	x1, x25
    79a4:	aa1403e0 	mov	x0, x20
    79a8:	f8408422 	ldr	x2, [x1], #8
    79ac:	f9000402 	str	x2, [x0, #8]
    79b0:	aa0003e2 	mov	x2, x0
    79b4:	f9400800 	ldr	x0, [x0, #16]
    79b8:	eb01035f 	cmp	x26, x1
    79bc:	54ffff61 	b.ne	79a8 <f12+0xc28>  // b.any
    79c0:	b94013e1 	ldr	w1, [sp, #16]
    79c4:	f9000853 	str	x19, [x2, #16]
    79c8:	aa1403f3 	mov	x19, x20
    79cc:	aa0003f4 	mov	x20, x0
    79d0:	34000041 	cbz	w1, 79d8 <f12+0xc58>
    79d4:	d2800019 	mov	x25, #0x0                   	// #0
    79d8:	aa1903e0 	mov	x0, x25
    79dc:	97fff48d 	bl	4c10 <fwp_mem_free>
    79e0:	f94007e0 	ldr	x0, [sp, #8]
    79e4:	97fffc47 	bl	6b00 <fwp_drop4>
    79e8:	aa1403e0 	mov	x0, x20
    79ec:	97fff95d 	bl	5f60 <fwp_drop0>
    79f0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    79f4:	f947f400 	ldr	x0, [x0, #4072]
    79f8:	f9405fe2 	ldr	x2, [sp, #184]
    79fc:	f9400001 	ldr	x1, [x0]
    7a00:	eb010042 	subs	x2, x2, x1
    7a04:	d2800001 	mov	x1, #0x0                   	// #0
    7a08:	540021a1 	b.ne	7e3c <f12+0x10bc>  // b.any
    7a0c:	a94c7bfd 	ldp	x29, x30, [sp, #192]
    7a10:	aa1303e0 	mov	x0, x19
    7a14:	a94d53f3 	ldp	x19, x20, [sp, #208]
    7a18:	a94e5bf5 	ldp	x21, x22, [sp, #224]
    7a1c:	a94f63f7 	ldp	x23, x24, [sp, #240]
    7a20:	a9506bf9 	ldp	x25, x26, [sp, #256]
    7a24:	a95173fb 	ldp	x27, x28, [sp, #272]
    7a28:	910483ff 	add	sp, sp, #0x120
    7a2c:	d65f03c0 	ret
    7a30:	aa1a03e0 	mov	x0, x26
    7a34:	97fff3d7 	bl	4990 <fwp_rc_forget_slot>
    7a38:	17ffffcf 	b	7974 <f12+0xbf4>
    7a3c:	72003c3f 	tst	w1, #0xffff
    7a40:	54fff9c1 	b.ne	7978 <f12+0xbf8>  // b.any
    7a44:	17ffffc9 	b	7968 <f12+0xbe8>
    7a48:	72003c1f 	tst	w0, #0xffff
    7a4c:	54ffe480 	b.eq	76dc <f12+0x95c>  // b.none
    7a50:	b4001134 	cbz	x20, 7c74 <f12+0xef4>
    7a54:	aa1403f3 	mov	x19, x20
    7a58:	d2800018 	mov	x24, #0x0                   	// #0
    7a5c:	d503201f 	nop
    7a60:	f9400a73 	ldr	x19, [x19, #16]
    7a64:	aa1803e0 	mov	x0, x24
    7a68:	91000718 	add	x24, x24, #0x1
    7a6c:	b5ffffb3 	cbnz	x19, 7a60 <f12+0xce0>
    7a70:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7a74:	eb01031f 	cmp	x24, x1
    7a78:	54001b88 	b.hi	7de8 <f12+0x1068>  // b.pmore
    7a7c:	91000800 	add	x0, x0, #0x2
    7a80:	52800041 	mov	w1, #0x2                   	// #2
    7a84:	d37df000 	lsl	x0, x0, #3
    7a88:	97fff582 	bl	5090 <fwp_heap_alloc>
    7a8c:	eb1c031f 	cmp	x24, x28
    7a90:	aa0003f9 	mov	x25, x0
    7a94:	9a9c931c 	csel	x28, x24, x28, ls	// ls = plast
    7a98:	aa1403e1 	mov	x1, x20
    7a9c:	d503201f 	nop
    7aa0:	f9400420 	ldr	x0, [x1, #8]
    7aa4:	f8337b20 	str	x0, [x25, x19, lsl #3]
    7aa8:	91000673 	add	x19, x19, #0x1
    7aac:	f9400821 	ldr	x1, [x1, #16]
    7ab0:	b5ffff81 	cbnz	x1, 7aa0 <f12+0xd20>
    7ab4:	b4000e9c 	cbz	x28, 7c84 <f12+0xf04>
    7ab8:	f94002a3 	ldr	x3, [x21]
    7abc:	b90013ff 	str	wzr, [sp, #16]
    7ac0:	17ffff0f 	b	76fc <f12+0x97c>
    7ac4:	72003c1f 	tst	w0, #0xffff
    7ac8:	54ffd260 	b.eq	7514 <f12+0x794>  // b.none
    7acc:	d503201f 	nop
    7ad0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7ad4:	eb00031f 	cmp	x24, x0
    7ad8:	540018e8 	b.hi	7df4 <f12+0x1074>  // b.pmore
    7adc:	91000700 	add	x0, x24, #0x1
    7ae0:	52800021 	mov	w1, #0x1                   	// #1
    7ae4:	d37df000 	lsl	x0, x0, #3
    7ae8:	97fff56a 	bl	5090 <fwp_heap_alloc>
    7aec:	9118c2e2 	add	x2, x23, #0x630
    7af0:	f9000018 	str	x24, [x0]
    7af4:	aa0003f5 	mov	x21, x0
    7af8:	f90007f5 	str	x21, [sp, #8]
    7afc:	f949d841 	ldr	x1, [x2, #5040]
    7b00:	f949ec40 	ldr	x0, [x2, #5080]
    7b04:	cb0102a1 	sub	x1, x21, x1
    7b08:	eb00403f 	cmp	x1, x0, lsl #16
    7b0c:	54000322 	b.cs	7b70 <f12+0xdf0>  // b.hs, b.nlast
    7b10:	d350fc20 	lsr	x0, x1, #16
    7b14:	f949fc43 	ldr	x3, [x2, #5112]
    7b18:	8b000800 	add	x0, x0, x0, lsl #2
    7b1c:	d37df002 	lsl	x2, x0, #3
    7b20:	8b020060 	add	x0, x3, x2
    7b24:	f9401019 	ldr	x25, [x0, #32]
    7b28:	b4000259 	cbz	x25, 7b70 <f12+0xdf0>
    7b2c:	38626862 	ldrb	w2, [x3, x2]
    7b30:	7100085f 	cmp	w2, #0x2
    7b34:	54000ac0 	b.eq	7c8c <f12+0xf0c>  // b.none
    7b38:	7100045f 	cmp	w2, #0x1
    7b3c:	540001a1 	b.ne	7b70 <f12+0xdf0>  // b.any
    7b40:	29430002 	ldp	w2, w0, [x0, #24]
    7b44:	92403c21 	and	x1, x1, #0xffff
    7b48:	9b027c21 	mul	x1, x1, x2
    7b4c:	d360fc21 	lsr	x1, x1, #32
    7b50:	eb00003f 	cmp	x1, x0
    7b54:	540000e2 	b.cs	7b70 <f12+0xdf0>  // b.hs, b.nlast
    7b58:	8b010339 	add	x25, x25, x1
    7b5c:	39400320 	ldrb	w0, [x25]
    7b60:	7103fc1f 	cmp	w0, #0xff
    7b64:	54001160 	b.eq	7d90 <f12+0x1010>  // b.none
    7b68:	52800020 	mov	w0, #0x1                   	// #1
    7b6c:	39000320 	strb	w0, [x25]
    7b70:	aa1303e0 	mov	x0, x19
    7b74:	17fffe6e 	b	752c <f12+0x7ac>
    7b78:	52800041 	mov	w1, #0x2                   	// #2
    7b7c:	d2800100 	mov	x0, #0x8                   	// #8
    7b80:	97fff544 	bl	5090 <fwp_heap_alloc>
    7b84:	aa0003fb 	mov	x27, x0
    7b88:	9118c2e0 	add	x0, x23, #0x630
    7b8c:	f900037f 	str	xzr, [x27]
    7b90:	f949d801 	ldr	x1, [x0, #5040]
    7b94:	f949ec00 	ldr	x0, [x0, #5080]
    7b98:	cb010361 	sub	x1, x27, x1
    7b9c:	eb00403f 	cmp	x1, x0, lsl #16
    7ba0:	54000102 	b.cs	7bc0 <f12+0xe40>  // b.hs, b.nlast
    7ba4:	d2800013 	mov	x19, #0x0                   	// #0
    7ba8:	17fffd4b 	b	70d4 <f12+0x354>
    7bac:	aa1b03e0 	mov	x0, x27
    7bb0:	97fff378 	bl	4990 <fwp_rc_forget_slot>
    7bb4:	17ffff26 	b	784c <f12+0xacc>
    7bb8:	b5ffac33 	cbnz	x19, 713c <f12+0x3bc>
    7bbc:	d503201f 	nop
    7bc0:	d280001c 	mov	x28, #0x0                   	// #0
    7bc4:	17fffd84 	b	71d4 <f12+0x454>
    7bc8:	f0ffffe0 	adrp	x0, 6000 <fwp_drop0+0xa0>
    7bcc:	91128000 	add	x0, x0, #0x4a0
    7bd0:	94000c2c 	bl	ac80 <atexit>
    7bd4:	35ffd220 	cbnz	w0, 7618 <f12+0x898>
    7bd8:	52800020 	mov	w0, #0x1                   	// #1
    7bdc:	b903c720 	str	w0, [x25, #964]
    7be0:	17fffcb8 	b	6ec0 <f12+0x140>
    7be4:	72003c3f 	tst	w1, #0xffff
    7be8:	54ffaa81 	b.ne	7138 <f12+0x3b8>  // b.any
    7bec:	17fffd4e 	b	7124 <f12+0x3a4>
    7bf0:	72003c3f 	tst	w1, #0xffff
    7bf4:	54ff9340 	b.eq	6e5c <f12+0xdc>  // b.none
    7bf8:	aa1903e0 	mov	x0, x25
    7bfc:	97fff989 	bl	6220 <fwp_closure_drop>
    7c00:	b5ff9474 	cbnz	x20, 6e8c <f12+0x10c>
    7c04:	d280001a 	mov	x26, #0x0                   	// #0
    7c08:	17fffcab 	b	6eb4 <f12+0x134>
    7c0c:	aa1c03f3 	mov	x19, x28
    7c10:	17fffda8 	b	72b0 <f12+0x530>
    7c14:	72003c3f 	tst	w1, #0xffff
    7c18:	54ffc381 	b.ne	7488 <f12+0x708>  // b.any
    7c1c:	17fffe16 	b	7474 <f12+0x6f4>
    7c20:	ad470402 	ldp	q2, q1, [x0, #224]
    7c24:	91038001 	add	x1, x0, #0xe0
    7c28:	4f000400 	movi	v0.4s, #0x0
    7c2c:	f9008c1f 	str	xzr, [x0, #280]
    7c30:	ad010762 	stp	q2, q1, [x27, #32]
    7c34:	a9500002 	ldp	x2, x0, [x0, #256]
    7c38:	f9000f60 	str	x0, [x27, #24]
    7c3c:	f9401820 	ldr	x0, [x1, #48]
    7c40:	f9002362 	str	x2, [x27, #64]
    7c44:	f9002760 	str	x0, [x27, #72]
    7c48:	ad000020 	stp	q0, q0, [x1]
    7c4c:	3d800820 	str	q0, [x1, #32]
    7c50:	f900183f 	str	xzr, [x1, #48]
    7c54:	17fffcde 	b	6fcc <f12+0x24c>
    7c58:	f940ac43 	ldr	x3, [x2, #344]
    7c5c:	91000463 	add	x3, x3, #0x1
    7c60:	f900ac43 	str	x3, [x2, #344]
    7c64:	17fffc83 	b	6e70 <f12+0xf0>
    7c68:	d2800005 	mov	x5, #0x0                   	// #0
    7c6c:	52800020 	mov	w0, #0x1                   	// #1
    7c70:	17fffe62 	b	75f8 <f12+0x878>
    7c74:	52800041 	mov	w1, #0x2                   	// #2
    7c78:	d2800100 	mov	x0, #0x8                   	// #8
    7c7c:	97fff505 	bl	5090 <fwp_heap_alloc>
    7c80:	aa0003f9 	mov	x25, x0
    7c84:	d2800013 	mov	x19, #0x0                   	// #0
    7c88:	17ffff54 	b	79d8 <f12+0xc58>
    7c8c:	72003c3f 	tst	w1, #0xffff
    7c90:	54fff660 	b.eq	7b5c <f12+0xddc>  // b.none
    7c94:	aa1303e0 	mov	x0, x19
    7c98:	17fffe25 	b	752c <f12+0x7ac>
    7c9c:	d1000761 	sub	x1, x27, #0x1
    7ca0:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7ca4:	eb00003f 	cmp	x1, x0
    7ca8:	54000ac8 	b.hi	7e00 <f12+0x1080>  // b.pmore
    7cac:	b00002c3 	adrp	x3, 60000 <ad_raw_checkpoints+0x2fbb0>
    7cb0:	d2800000 	mov	x0, #0x0                   	// #0
    7cb4:	91114061 	add	x1, x3, #0x450
    7cb8:	14000005 	b	7ccc <f12+0xf4c>
    7cbc:	91000400 	add	x0, x0, #0x1
    7cc0:	91006021 	add	x1, x1, #0x18
    7cc4:	f140041f 	cmp	x0, #0x1, lsl #12
    7cc8:	540006e0 	b.eq	7da4 <f12+0x1024>  // b.none
    7ccc:	f9400022 	ldr	x2, [x1]
    7cd0:	b5ffff62 	cbnz	x2, 7cbc <f12+0xf3c>
    7cd4:	8b000402 	add	x2, x0, x0, lsl #1
    7cd8:	91114063 	add	x3, x3, #0x450
    7cdc:	aa1b03e0 	mov	x0, x27
    7ce0:	d2800101 	mov	x1, #0x8                   	// #8
    7ce4:	8b020c62 	add	x2, x3, x2, lsl #3
    7ce8:	a9009be2 	stp	x2, x6, [sp, #8]
    7cec:	a901a3e7 	stp	x7, x8, [sp, #24]
    7cf0:	f90017e9 	str	x9, [sp, #40]
    7cf4:	97ffeabf 	bl	27f0 <calloc@plt>
    7cf8:	a9411fe6 	ldp	x6, x7, [sp, #16]
    7cfc:	aa0003e5 	mov	x5, x0
    7d00:	a94227e8 	ldp	x8, x9, [sp, #32]
    7d04:	b4fffb20 	cbz	x0, 7c68 <f12+0xee8>
    7d08:	aa0003e1 	mov	x1, x0
    7d0c:	d37df362 	lsl	x2, x27, #3
    7d10:	f94007e0 	ldr	x0, [sp, #8]
    7d14:	52800063 	mov	w3, #0x3                   	// #3
    7d18:	a9009be5 	stp	x5, x6, [sp, #8]
    7d1c:	a901a3e7 	stp	x7, x8, [sp, #24]
    7d20:	f90017e9 	str	x9, [sp, #40]
    7d24:	97ffec7b 	bl	2f10 <ad_raw_record>
    7d28:	a9409be5 	ldp	x5, x6, [sp, #8]
    7d2c:	f9004be5 	str	x5, [sp, #144]
    7d30:	a941a3e7 	ldp	x7, x8, [sp, #24]
    7d34:	f90053fb 	str	x27, [sp, #160]
    7d38:	f94017e9 	ldr	x9, [sp, #40]
    7d3c:	17fffd75 	b	7310 <f12+0x590>
    7d40:	f94002a3 	ldr	x3, [x21]
    7d44:	b7fff983 	tbnz	x3, #63, 7c74 <f12+0xef4>
    7d48:	9118c2e1 	add	x1, x23, #0x630
    7d4c:	f94007e4 	ldr	x4, [sp, #8]
    7d50:	f949d820 	ldr	x0, [x1, #5040]
    7d54:	f949ec21 	ldr	x1, [x1, #5080]
    7d58:	cb000080 	sub	x0, x4, x0
    7d5c:	eb01401f 	cmp	x0, x1, lsl #16
    7d60:	54fff8a2 	b.cs	7c74 <f12+0xef4>  // b.hs, b.nlast
    7d64:	9240f87c 	and	x28, x3, #0x7fffffffffffffff
    7d68:	17fffe49 	b	768c <f12+0x90c>
    7d6c:	d2800d01 	mov	x1, #0x68                  	// #104
    7d70:	d2800039 	mov	x25, #0x1                   	// #1
    7d74:	17fffc76 	b	6f4c <f12+0x1cc>
    7d78:	aa1a03e0 	mov	x0, x26
    7d7c:	97fff305 	bl	4990 <fwp_rc_forget_slot>
    7d80:	17fffcec 	b	7130 <f12+0x3b0>
    7d84:	aa1903e0 	mov	x0, x25
    7d88:	97fff302 	bl	4990 <fwp_rc_forget_slot>
    7d8c:	17fffdbd 	b	7480 <f12+0x700>
    7d90:	aa1903e0 	mov	x0, x25
    7d94:	97fff2ff 	bl	4990 <fwp_rc_forget_slot>
    7d98:	17ffff74 	b	7b68 <f12+0xde8>
    7d9c:	97fff2b6 	bl	4874 <fwp_rc_wide_dup>
    7da0:	17fffc38 	b	6e80 <f12+0x100>
    7da4:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7da8:	91016000 	add	x0, x0, #0x58
    7dac:	97ffed55 	bl	3300 <ad_raw_fail>
    7db0:	d280001a 	mov	x26, #0x0                   	// #0
    7db4:	17fffe95 	b	7808 <f12+0xa88>
    7db8:	d2800019 	mov	x25, #0x0                   	// #0
    7dbc:	d2800013 	mov	x19, #0x0                   	// #0
    7dc0:	17ffff06 	b	79d8 <f12+0xc58>
    7dc4:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7dc8:	9106e000 	add	x0, x0, #0x1b8
    7dcc:	97ffee6d 	bl	3780 <fwp_trap>
    7dd0:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7dd4:	91094000 	add	x0, x0, #0x250
    7dd8:	97ffee6a 	bl	3780 <fwp_trap>
    7ddc:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7de0:	910dc000 	add	x0, x0, #0x370
    7de4:	97ffee67 	bl	3780 <fwp_trap>
    7de8:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7dec:	910cc000 	add	x0, x0, #0x330
    7df0:	97ffee64 	bl	3780 <fwp_trap>
    7df4:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7df8:	910d8000 	add	x0, x0, #0x360
    7dfc:	97ffee61 	bl	3780 <fwp_trap>
    7e00:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7e04:	910d0000 	add	x0, x0, #0x340
    7e08:	97ffed3e 	bl	3300 <ad_raw_fail>
    7e0c:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7e10:	910c0000 	add	x0, x0, #0x300
    7e14:	97ffee5b 	bl	3780 <fwp_trap>
    7e18:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7e1c:	910ac000 	add	x0, x0, #0x2b0
    7e20:	97ffee58 	bl	3780 <fwp_trap>
    7e24:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7e28:	91080000 	add	x0, x0, #0x200
    7e2c:	97ffee55 	bl	3780 <fwp_trap>
    7e30:	90000020 	adrp	x0, b000 <_IO_stdin_used+0x350>
    7e34:	910b4000 	add	x0, x0, #0x2d0
    7e38:	97ffee52 	bl	3780 <fwp_trap>
    7e3c:	97ffea75 	bl	2810 <__stack_chk_fail@plt>
    7e40:	97ffea88 	bl	2860 <abort@plt>
    7e44:	97ffeaef 	bl	2a00 <fwp_trap_overflow.constprop.0>
    7e48:	d503201f 	nop
    7e4c:	d503201f 	nop

0000000000007e50 <fwp_owned_entry12>:
    7e50:	f9400000 	ldr	x0, [x0]
    7e54:	17fffbcb 	b	6d80 <f12>
    7e58:	d503201f 	nop
    7e5c:	d503201f 	nop

0000000000007e60 <e12>:
    7e60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7e64:	910003fd 	mov	x29, sp
    7e68:	f9000bf3 	str	x19, [sp, #16]
    7e6c:	f9400013 	ldr	x19, [x0]
    7e70:	aa1303e0 	mov	x0, x19
    7e74:	97fff737 	bl	5b50 <fwp_rc_share>
    7e78:	aa1303e0 	mov	x0, x19
    7e7c:	97fffbc1 	bl	6d80 <f12>
    7e80:	aa0003f3 	mov	x19, x0
    7e84:	97fff733 	bl	5b50 <fwp_rc_share>
    7e88:	aa1303e0 	mov	x0, x19
    7e8c:	f9400bf3 	ldr	x19, [sp, #16]
    7e90:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7e94:	d65f03c0 	ret
    7e98:	d503201f 	nop
    7e9c:	d503201f 	nop

0000000000007ea0 <fwp_drop2>:
    7ea0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    7ea4:	910003fd 	mov	x29, sp
    7ea8:	a9025bf5 	stp	x21, x22, [sp, #32]
    7eac:	d0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    7eb0:	9118c2d5 	add	x21, x22, #0x630
    7eb4:	a90153f3 	stp	x19, x20, [sp, #16]
    7eb8:	aa0003f3 	mov	x19, x0
    7ebc:	f949daa1 	ldr	x1, [x21, #5040]
    7ec0:	f949eea0 	ldr	x0, [x21, #5080]
    7ec4:	cb010261 	sub	x1, x19, x1
    7ec8:	eb00403f 	cmp	x1, x0, lsl #16
    7ecc:	54000382 	b.cs	7f3c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7ed0:	d350fc22 	lsr	x2, x1, #16
    7ed4:	f949fea3 	ldr	x3, [x21, #5112]
    7ed8:	8b020842 	add	x2, x2, x2, lsl #2
    7edc:	d37df042 	lsl	x2, x2, #3
    7ee0:	8b020060 	add	x0, x3, x2
    7ee4:	f9401014 	ldr	x20, [x0, #32]
    7ee8:	b40002b4 	cbz	x20, 7f3c <fwp_drop2+0x9c>
    7eec:	38626862 	ldrb	w2, [x3, x2]
    7ef0:	7100085f 	cmp	w2, #0x2
    7ef4:	540002c0 	b.eq	7f4c <fwp_drop2+0xac>  // b.none
    7ef8:	7100045f 	cmp	w2, #0x1
    7efc:	54000201 	b.ne	7f3c <fwp_drop2+0x9c>  // b.any
    7f00:	29430002 	ldp	w2, w0, [x0, #24]
    7f04:	92403c21 	and	x1, x1, #0xffff
    7f08:	9b027c21 	mul	x1, x1, x2
    7f0c:	d360fc21 	lsr	x1, x1, #32
    7f10:	eb00003f 	cmp	x1, x0
    7f14:	54000142 	b.cs	7f3c <fwp_drop2+0x9c>  // b.hs, b.nlast
    7f18:	8b010294 	add	x20, x20, x1
    7f1c:	39400280 	ldrb	w0, [x20]
    7f20:	340000e0 	cbz	w0, 7f3c <fwp_drop2+0x9c>
    7f24:	7100041f 	cmp	w0, #0x1
    7f28:	540001e0 	b.eq	7f64 <fwp_drop2+0xc4>  // b.none
    7f2c:	7103fc1f 	cmp	w0, #0xff
    7f30:	540007c0 	b.eq	8028 <fwp_drop2+0x188>  // b.none
    7f34:	51000400 	sub	w0, w0, #0x1
    7f38:	39000280 	strb	w0, [x20]
    7f3c:	a94153f3 	ldp	x19, x20, [sp, #16]
    7f40:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7f44:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7f48:	d65f03c0 	ret
    7f4c:	72003c3f 	tst	w1, #0xffff
    7f50:	54fffe60 	b.eq	7f1c <fwp_drop2+0x7c>  // b.none
    7f54:	a94153f3 	ldp	x19, x20, [sp, #16]
    7f58:	a9425bf5 	ldp	x21, x22, [sp, #32]
    7f5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    7f60:	d65f03c0 	ret
    7f64:	9118c2c2 	add	x2, x22, #0x630
    7f68:	f9400660 	ldr	x0, [x19, #8]
    7f6c:	f949d841 	ldr	x1, [x2, #5040]
    7f70:	f949ec42 	ldr	x2, [x2, #5080]
    7f74:	cb010001 	sub	x1, x0, x1
    7f78:	eb02403f 	cmp	x1, x2, lsl #16
    7f7c:	54000362 	b.cs	7fe8 <fwp_drop2+0x148>  // b.hs, b.nlast
    7f80:	d350fc22 	lsr	x2, x1, #16
    7f84:	8b020842 	add	x2, x2, x2, lsl #2
    7f88:	d37df042 	lsl	x2, x2, #3
    7f8c:	8b020064 	add	x4, x3, x2
    7f90:	f9401094 	ldr	x20, [x4, #32]
    7f94:	b40002b4 	cbz	x20, 7fe8 <fwp_drop2+0x148>
    7f98:	38626862 	ldrb	w2, [x3, x2]
    7f9c:	7100085f 	cmp	w2, #0x2
    7fa0:	540003e0 	b.eq	801c <fwp_drop2+0x17c>  // b.none
    7fa4:	7100045f 	cmp	w2, #0x1
    7fa8:	54000201 	b.ne	7fe8 <fwp_drop2+0x148>  // b.any
    7fac:	29430883 	ldp	w3, w2, [x4, #24]
    7fb0:	92403c21 	and	x1, x1, #0xffff
    7fb4:	9b037c21 	mul	x1, x1, x3
    7fb8:	d360fc21 	lsr	x1, x1, #32
    7fbc:	eb02003f 	cmp	x1, x2
    7fc0:	54000142 	b.cs	7fe8 <fwp_drop2+0x148>  // b.hs, b.nlast
    7fc4:	8b010294 	add	x20, x20, x1
    7fc8:	39400281 	ldrb	w1, [x20]
    7fcc:	340000e1 	cbz	w1, 7fe8 <fwp_drop2+0x148>
    7fd0:	7100043f 	cmp	w1, #0x1
    7fd4:	54000200 	b.eq	8014 <fwp_drop2+0x174>  // b.none
    7fd8:	7103fc3f 	cmp	w1, #0xff
    7fdc:	54000580 	b.eq	808c <fwp_drop2+0x1ec>  // b.none
    7fe0:	51000421 	sub	w1, w1, #0x1
    7fe4:	39000281 	strb	w1, [x20]
    7fe8:	f9400a74 	ldr	x20, [x19, #16]
    7fec:	aa1303e0 	mov	x0, x19
    7ff0:	97fff6fd 	bl	5be4 <fwp_rc_free_arr>
    7ff4:	9118c2c0 	add	x0, x22, #0x630
    7ff8:	f949d801 	ldr	x1, [x0, #5040]
    7ffc:	f949ec00 	ldr	x0, [x0, #5080]
    8000:	cb010281 	sub	x1, x20, x1
    8004:	eb00403f 	cmp	x1, x0, lsl #16
    8008:	54fff9a2 	b.cs	7f3c <fwp_drop2+0x9c>  // b.hs, b.nlast
    800c:	aa1403f3 	mov	x19, x20
    8010:	17ffffb0 	b	7ed0 <fwp_drop2+0x30>
    8014:	97fff6f4 	bl	5be4 <fwp_rc_free_arr>
    8018:	17fffff4 	b	7fe8 <fwp_drop2+0x148>
    801c:	72003c3f 	tst	w1, #0xffff
    8020:	54fffe41 	b.ne	7fe8 <fwp_drop2+0x148>  // b.any
    8024:	17ffffe9 	b	7fc8 <fwp_drop2+0x128>
    8028:	ca544681 	eor	x1, x20, x20, lsr #17
    802c:	9118c2c0 	add	x0, x22, #0x630
    8030:	ca412421 	eor	x1, x1, x1, lsr #9
    8034:	8b210c01 	add	x1, x0, w1, uxtb #3
    8038:	f94a2420 	ldr	x0, [x1, #5192]
    803c:	b5000080 	cbnz	x0, 804c <fwp_drop2+0x1ac>
    8040:	14000010 	b	8080 <fwp_drop2+0x1e0>
    8044:	f9400800 	ldr	x0, [x0, #16]
    8048:	b40001c0 	cbz	x0, 8080 <fwp_drop2+0x1e0>
    804c:	f9400001 	ldr	x1, [x0]
    8050:	eb14003f 	cmp	x1, x20
    8054:	54ffff81 	b.ne	8044 <fwp_drop2+0x1a4>  // b.any
    8058:	f9400401 	ldr	x1, [x0, #8]
    805c:	d1000421 	sub	x1, x1, #0x1
    8060:	f9000401 	str	x1, [x0, #8]
    8064:	f103f83f 	cmp	x1, #0xfe
    8068:	54fff6a1 	b.ne	7f3c <fwp_drop2+0x9c>  // b.any
    806c:	aa1403e0 	mov	x0, x20
    8070:	97fff248 	bl	4990 <fwp_rc_forget_slot>
    8074:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8078:	39000280 	strb	w0, [x20]
    807c:	17ffffb0 	b	7f3c <fwp_drop2+0x9c>
    8080:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    8084:	9105c000 	add	x0, x0, #0x170
    8088:	97ffedbe 	bl	3780 <fwp_trap>
    808c:	ca544680 	eor	x0, x20, x20, lsr #17
    8090:	9118c2c1 	add	x1, x22, #0x630
    8094:	ca402400 	eor	x0, x0, x0, lsr #9
    8098:	8b200c20 	add	x0, x1, w0, uxtb #3
    809c:	f94a2400 	ldr	x0, [x0, #5192]
    80a0:	b5000080 	cbnz	x0, 80b0 <fwp_drop2+0x210>
    80a4:	17fffff7 	b	8080 <fwp_drop2+0x1e0>
    80a8:	f9400800 	ldr	x0, [x0, #16]
    80ac:	b4fffea0 	cbz	x0, 8080 <fwp_drop2+0x1e0>
    80b0:	f9400001 	ldr	x1, [x0]
    80b4:	eb14003f 	cmp	x1, x20
    80b8:	54ffff81 	b.ne	80a8 <fwp_drop2+0x208>  // b.any
    80bc:	f9400401 	ldr	x1, [x0, #8]
    80c0:	d1000421 	sub	x1, x1, #0x1
    80c4:	f9000401 	str	x1, [x0, #8]
    80c8:	f103f83f 	cmp	x1, #0xfe
    80cc:	54fff8e1 	b.ne	7fe8 <fwp_drop2+0x148>  // b.any
    80d0:	aa1403e0 	mov	x0, x20
    80d4:	97fff22f 	bl	4990 <fwp_rc_forget_slot>
    80d8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    80dc:	39000280 	strb	w0, [x20]
    80e0:	17ffffc2 	b	7fe8 <fwp_drop2+0x148>

00000000000080e4 <fwp_arg_drop23>:
    80e4:	7100003f 	cmp	w1, #0x0
    80e8:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    80ec:	54000041 	b.ne	80f4 <fwp_arg_drop23+0x10>  // b.any
    80f0:	d65f03c0 	ret
    80f4:	f9400000 	ldr	x0, [x0]
    80f8:	17ffff6a 	b	7ea0 <fwp_drop2>
    80fc:	d503201f 	nop

0000000000008100 <f23>:
    8100:	d101c3ff 	sub	sp, sp, #0x70
    8104:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    8108:	f947f421 	ldr	x1, [x1, #4072]
    810c:	a9027bfd 	stp	x29, x30, [sp, #32]
    8110:	910083fd 	add	x29, sp, #0x20
    8114:	a90563f7 	stp	x23, x24, [sp, #80]
    8118:	b0000397 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    811c:	9118c2e3 	add	x3, x23, #0x630
    8120:	a90353f3 	stp	x19, x20, [sp, #48]
    8124:	a9045bf5 	stp	x21, x22, [sp, #64]
    8128:	aa0003f6 	mov	x22, x0
    812c:	a9066bf9 	stp	x25, x26, [sp, #96]
    8130:	f949ec62 	ldr	x2, [x3, #5080]
    8134:	f9400024 	ldr	x4, [x1]
    8138:	f9000fe4 	str	x4, [sp, #24]
    813c:	d2800004 	mov	x4, #0x0                   	// #0
    8140:	f949d861 	ldr	x1, [x3, #5040]
    8144:	d370bc42 	lsl	x2, x2, #16
    8148:	b40016c0 	cbz	x0, 8420 <f23+0x320>
    814c:	f9400818 	ldr	x24, [x0, #16]
    8150:	cb010301 	sub	x1, x24, x1
    8154:	eb02003f 	cmp	x1, x2
    8158:	540003e2 	b.cs	81d4 <f23+0xd4>  // b.hs, b.nlast
    815c:	f949fc60 	ldr	x0, [x3, #5112]
    8160:	d350fc22 	lsr	x2, x1, #16
    8164:	8b020842 	add	x2, x2, x2, lsl #2
    8168:	8b020c02 	add	x2, x0, x2, lsl #3
    816c:	f9401040 	ldr	x0, [x2, #32]
    8170:	b4000320 	cbz	x0, 81d4 <f23+0xd4>
    8174:	39400043 	ldrb	w3, [x2]
    8178:	7100087f 	cmp	w3, #0x2
    817c:	54001440 	b.eq	8404 <f23+0x304>  // b.none
    8180:	7100047f 	cmp	w3, #0x1
    8184:	54000241 	b.ne	81cc <f23+0xcc>  // b.any
    8188:	29430843 	ldp	w3, w2, [x2, #24]
    818c:	92403c21 	and	x1, x1, #0xffff
    8190:	9b037c21 	mul	x1, x1, x3
    8194:	d360fc21 	lsr	x1, x1, #32
    8198:	eb02003f 	cmp	x1, x2
    819c:	54000182 	b.cs	81cc <f23+0xcc>  // b.hs, b.nlast
    81a0:	8b010000 	add	x0, x0, x1
    81a4:	39400001 	ldrb	w1, [x0]
    81a8:	34000121 	cbz	w1, 81cc <f23+0xcc>
    81ac:	900000c2 	adrp	x2, 20000 <__data_start>
    81b0:	91014042 	add	x2, x2, #0x50
    81b4:	b9413043 	ldr	w3, [x2, #304]
    81b8:	350012c3 	cbnz	w3, 8410 <f23+0x310>
    81bc:	7103f43f 	cmp	w1, #0xfd
    81c0:	54001728 	b.hi	84a4 <f23+0x3a4>  // b.pmore
    81c4:	11000421 	add	w1, w1, #0x1
    81c8:	39000001 	strb	w1, [x0]
    81cc:	d2800000 	mov	x0, #0x0                   	// #0
    81d0:	b40000f6 	cbz	x22, 81ec <f23+0xec>
    81d4:	aa1603e1 	mov	x1, x22
    81d8:	d2800000 	mov	x0, #0x0                   	// #0
    81dc:	d503201f 	nop
    81e0:	f9400821 	ldr	x1, [x1, #16]
    81e4:	91000400 	add	x0, x0, #0x1
    81e8:	b5ffffc1 	cbnz	x1, 81e0 <f23+0xe0>
    81ec:	b4001238 	cbz	x24, 8430 <f23+0x330>
    81f0:	aa1803e1 	mov	x1, x24
    81f4:	d2800002 	mov	x2, #0x0                   	// #0
    81f8:	f9400821 	ldr	x1, [x1, #16]
    81fc:	91000442 	add	x2, x2, #0x1
    8200:	b5ffffc1 	cbnz	x1, 81f8 <f23+0xf8>
    8204:	eb00005f 	cmp	x2, x0
    8208:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    820c:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    8210:	eb01033f 	cmp	x25, x1
    8214:	540014e8 	b.hi	84b0 <f23+0x3b0>  // b.pmore
    8218:	d37ffb33 	lsl	x19, x25, #1
    821c:	52800041 	mov	w1, #0x2                   	// #2
    8220:	91000660 	add	x0, x19, #0x1
    8224:	d37df000 	lsl	x0, x0, #3
    8228:	97fff39a 	bl	5090 <fwp_heap_alloc>
    822c:	9118c2e1 	add	x1, x23, #0x630
    8230:	aa0003fa 	mov	x26, x0
    8234:	f9000013 	str	x19, [x0]
    8238:	aa0103e0 	mov	x0, x1
    823c:	f949d821 	ldr	x1, [x1, #5040]
    8240:	f949ec00 	ldr	x0, [x0, #5080]
    8244:	cb010341 	sub	x1, x26, x1
    8248:	eb00403f 	cmp	x1, x0, lsl #16
    824c:	54000342 	b.cs	82b4 <f23+0x1b4>  // b.hs, b.nlast
    8250:	9118c2e2 	add	x2, x23, #0x630
    8254:	d350fc20 	lsr	x0, x1, #16
    8258:	8b000800 	add	x0, x0, x0, lsl #2
    825c:	f949fc43 	ldr	x3, [x2, #5112]
    8260:	d37df002 	lsl	x2, x0, #3
    8264:	8b020060 	add	x0, x3, x2
    8268:	f9401013 	ldr	x19, [x0, #32]
    826c:	b4000253 	cbz	x19, 82b4 <f23+0x1b4>
    8270:	38626862 	ldrb	w2, [x3, x2]
    8274:	7100085f 	cmp	w2, #0x2
    8278:	54000c00 	b.eq	83f8 <f23+0x2f8>  // b.none
    827c:	7100045f 	cmp	w2, #0x1
    8280:	540001a1 	b.ne	82b4 <f23+0x1b4>  // b.any
    8284:	29430002 	ldp	w2, w0, [x0, #24]
    8288:	92403c21 	and	x1, x1, #0xffff
    828c:	9b027c21 	mul	x1, x1, x2
    8290:	d360fc21 	lsr	x1, x1, #32
    8294:	eb00003f 	cmp	x1, x0
    8298:	540000e2 	b.cs	82b4 <f23+0x1b4>  // b.hs, b.nlast
    829c:	8b010273 	add	x19, x19, x1
    82a0:	39400260 	ldrb	w0, [x19]
    82a4:	7103fc1f 	cmp	w0, #0xff
    82a8:	54000e80 	b.eq	8478 <f23+0x378>  // b.none
    82ac:	52800020 	mov	w0, #0x1                   	// #1
    82b0:	39000260 	strb	w0, [x19]
    82b4:	b4000259 	cbz	x25, 82fc <f23+0x1fc>
    82b8:	8b191359 	add	x25, x26, x25, lsl #4
    82bc:	aa1a03f3 	mov	x19, x26
    82c0:	aa1603f5 	mov	x21, x22
    82c4:	aa1803f4 	mov	x20, x24
    82c8:	f9400683 	ldr	x3, [x20, #8]
    82cc:	f94006a2 	ldr	x2, [x21, #8]
    82d0:	f9400861 	ldr	x1, [x3, #16]
    82d4:	f9400840 	ldr	x0, [x2, #16]
    82d8:	fd400461 	ldr	d1, [x3, #8]
    82dc:	fd400440 	ldr	d0, [x2, #8]
    82e0:	97fff538 	bl	57c0 <w107>
    82e4:	f9000660 	str	x0, [x19, #8]
    82e8:	f8010e61 	str	x1, [x19, #16]!
    82ec:	f9400a94 	ldr	x20, [x20, #16]
    82f0:	f9400ab5 	ldr	x21, [x21, #16]
    82f4:	eb13033f 	cmp	x25, x19
    82f8:	54fffe81 	b.ne	82c8 <f23+0x1c8>  // b.any
    82fc:	aa1803e0 	mov	x0, x24
    8300:	97fffee8 	bl	7ea0 <fwp_drop2>
    8304:	aa1603e0 	mov	x0, x22
    8308:	97fffee6 	bl	7ea0 <fwp_drop2>
    830c:	9118c2f7 	add	x23, x23, #0x630
    8310:	aa1a03e0 	mov	x0, x26
    8314:	97fff588 	bl	5934 <w164.constprop.0>
    8318:	aa0103f3 	mov	x19, x1
    831c:	aa0003f4 	mov	x20, x0
    8320:	aa1a03e0 	mov	x0, x26
    8324:	97fff9f7 	bl	6b00 <fwp_drop4>
    8328:	a900cff4 	stp	x20, x19, [sp, #8]
    832c:	910023e1 	add	x1, sp, #0x8
    8330:	52800000 	mov	w0, #0x0                   	// #0
    8334:	97fff5a8 	bl	59d4 <fwp_data.part.0.constprop.0>
    8338:	f949dae1 	ldr	x1, [x23, #5040]
    833c:	aa0003f3 	mov	x19, x0
    8340:	f949eee0 	ldr	x0, [x23, #5080]
    8344:	cb010261 	sub	x1, x19, x1
    8348:	eb00403f 	cmp	x1, x0, lsl #16
    834c:	54000322 	b.cs	83b0 <f23+0x2b0>  // b.hs, b.nlast
    8350:	d350fc22 	lsr	x2, x1, #16
    8354:	f949fee3 	ldr	x3, [x23, #5112]
    8358:	8b020842 	add	x2, x2, x2, lsl #2
    835c:	d37df042 	lsl	x2, x2, #3
    8360:	8b020060 	add	x0, x3, x2
    8364:	f9401014 	ldr	x20, [x0, #32]
    8368:	b4000254 	cbz	x20, 83b0 <f23+0x2b0>
    836c:	38626862 	ldrb	w2, [x3, x2]
    8370:	7100085f 	cmp	w2, #0x2
    8374:	540003c0 	b.eq	83ec <f23+0x2ec>  // b.none
    8378:	7100045f 	cmp	w2, #0x1
    837c:	540001a1 	b.ne	83b0 <f23+0x2b0>  // b.any
    8380:	29430002 	ldp	w2, w0, [x0, #24]
    8384:	92403c21 	and	x1, x1, #0xffff
    8388:	9b027c21 	mul	x1, x1, x2
    838c:	d360fc21 	lsr	x1, x1, #32
    8390:	eb00003f 	cmp	x1, x0
    8394:	540000e2 	b.cs	83b0 <f23+0x2b0>  // b.hs, b.nlast
    8398:	8b010294 	add	x20, x20, x1
    839c:	39400280 	ldrb	w0, [x20]
    83a0:	7103fc1f 	cmp	w0, #0xff
    83a4:	54000640 	b.eq	846c <f23+0x36c>  // b.none
    83a8:	52800020 	mov	w0, #0x1                   	// #1
    83ac:	39000280 	strb	w0, [x20]
    83b0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    83b4:	f947f400 	ldr	x0, [x0, #4072]
    83b8:	f9400fe2 	ldr	x2, [sp, #24]
    83bc:	f9400001 	ldr	x1, [x0]
    83c0:	eb010042 	subs	x2, x2, x1
    83c4:	d2800001 	mov	x1, #0x0                   	// #0
    83c8:	54000721 	b.ne	84ac <f23+0x3ac>  // b.any
    83cc:	a9427bfd 	ldp	x29, x30, [sp, #32]
    83d0:	aa1303e0 	mov	x0, x19
    83d4:	a94353f3 	ldp	x19, x20, [sp, #48]
    83d8:	a9445bf5 	ldp	x21, x22, [sp, #64]
    83dc:	a94563f7 	ldp	x23, x24, [sp, #80]
    83e0:	a9466bf9 	ldp	x25, x26, [sp, #96]
    83e4:	9101c3ff 	add	sp, sp, #0x70
    83e8:	d65f03c0 	ret
    83ec:	72003c3f 	tst	w1, #0xffff
    83f0:	54fffe01 	b.ne	83b0 <f23+0x2b0>  // b.any
    83f4:	17ffffea 	b	839c <f23+0x29c>
    83f8:	72003c3f 	tst	w1, #0xffff
    83fc:	54fff5c1 	b.ne	82b4 <f23+0x1b4>  // b.any
    8400:	17ffffa8 	b	82a0 <f23+0x1a0>
    8404:	72003c3f 	tst	w1, #0xffff
    8408:	54ffee21 	b.ne	81cc <f23+0xcc>  // b.any
    840c:	17ffff66 	b	81a4 <f23+0xa4>
    8410:	f940ac43 	ldr	x3, [x2, #344]
    8414:	91000463 	add	x3, x3, #0x1
    8418:	f900ac43 	str	x3, [x2, #344]
    841c:	17ffff68 	b	81bc <f23+0xbc>
    8420:	cb0103e1 	neg	x1, x1
    8424:	eb02003f 	cmp	x1, x2
    8428:	540002e3 	b.cc	8484 <f23+0x384>  // b.lo, b.ul, b.last
    842c:	d503201f 	nop
    8430:	52800041 	mov	w1, #0x2                   	// #2
    8434:	d2800100 	mov	x0, #0x8                   	// #8
    8438:	97fff316 	bl	5090 <fwp_heap_alloc>
    843c:	aa0003e1 	mov	x1, x0
    8440:	9118c2e0 	add	x0, x23, #0x630
    8444:	aa0103fa 	mov	x26, x1
    8448:	d2800018 	mov	x24, #0x0                   	// #0
    844c:	f900003f 	str	xzr, [x1]
    8450:	f949d801 	ldr	x1, [x0, #5040]
    8454:	f949ec00 	ldr	x0, [x0, #5080]
    8458:	cb010341 	sub	x1, x26, x1
    845c:	eb00403f 	cmp	x1, x0, lsl #16
    8460:	54fff4e2 	b.cs	82fc <f23+0x1fc>  // b.hs, b.nlast
    8464:	d2800019 	mov	x25, #0x0                   	// #0
    8468:	17ffff7a 	b	8250 <f23+0x150>
    846c:	aa1403e0 	mov	x0, x20
    8470:	97fff148 	bl	4990 <fwp_rc_forget_slot>
    8474:	17ffffcd 	b	83a8 <f23+0x2a8>
    8478:	aa1303e0 	mov	x0, x19
    847c:	97fff145 	bl	4990 <fwp_rc_forget_slot>
    8480:	17ffff8b 	b	82ac <f23+0x1ac>
    8484:	f949fc62 	ldr	x2, [x3, #5112]
    8488:	d350fc20 	lsr	x0, x1, #16
    848c:	8b000800 	add	x0, x0, x0, lsl #2
    8490:	8b000c42 	add	x2, x2, x0, lsl #3
    8494:	f9401040 	ldr	x0, [x2, #32]
    8498:	b4fffcc0 	cbz	x0, 8430 <f23+0x330>
    849c:	d2800018 	mov	x24, #0x0                   	// #0
    84a0:	17ffff35 	b	8174 <f23+0x74>
    84a4:	97fff0f4 	bl	4874 <fwp_rc_wide_dup>
    84a8:	17ffff49 	b	81cc <f23+0xcc>
    84ac:	97ffe8d9 	bl	2810 <__stack_chk_fail@plt>
    84b0:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    84b4:	910cc000 	add	x0, x0, #0x330
    84b8:	97ffecb2 	bl	3780 <fwp_trap>
    84bc:	d503201f 	nop

00000000000084c0 <fwp_owned_entry23>:
    84c0:	f9400000 	ldr	x0, [x0]
    84c4:	17ffff0f 	b	8100 <f23>
    84c8:	d503201f 	nop
    84cc:	d503201f 	nop

00000000000084d0 <e23>:
    84d0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    84d4:	910003fd 	mov	x29, sp
    84d8:	f9000bf3 	str	x19, [sp, #16]
    84dc:	f9400013 	ldr	x19, [x0]
    84e0:	aa1303e0 	mov	x0, x19
    84e4:	97fff59b 	bl	5b50 <fwp_rc_share>
    84e8:	aa1303e0 	mov	x0, x19
    84ec:	97ffff05 	bl	8100 <f23>
    84f0:	aa0003f3 	mov	x19, x0
    84f4:	97fff597 	bl	5b50 <fwp_rc_share>
    84f8:	aa1303e0 	mov	x0, x19
    84fc:	f9400bf3 	ldr	x19, [sp, #16]
    8500:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8504:	d65f03c0 	ret
    8508:	d503201f 	nop
    850c:	d503201f 	nop

0000000000008510 <fwp_args23>:
    8510:	7100003f 	cmp	w1, #0x0
    8514:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8518:	54000041 	b.ne	8520 <fwp_args23+0x10>  // b.any
    851c:	d65f03c0 	ret
    8520:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8524:	9118c042 	add	x2, x2, #0x630
    8528:	f9400001 	ldr	x1, [x0]
    852c:	f949d843 	ldr	x3, [x2, #5040]
    8530:	f949ec40 	ldr	x0, [x2, #5080]
    8534:	cb030021 	sub	x1, x1, x3
    8538:	eb00403f 	cmp	x1, x0, lsl #16
    853c:	54ffff02 	b.cs	851c <fwp_args23+0xc>  // b.hs, b.nlast
    8540:	d350fc20 	lsr	x0, x1, #16
    8544:	f949fc44 	ldr	x4, [x2, #5112]
    8548:	8b000800 	add	x0, x0, x0, lsl #2
    854c:	d37df002 	lsl	x2, x0, #3
    8550:	8b020083 	add	x3, x4, x2
    8554:	f9401060 	ldr	x0, [x3, #32]
    8558:	b4fffe20 	cbz	x0, 851c <fwp_args23+0xc>
    855c:	38626882 	ldrb	w2, [x4, x2]
    8560:	7100085f 	cmp	w2, #0x2
    8564:	54000320 	b.eq	85c8 <fwp_args23+0xb8>  // b.none
    8568:	7100045f 	cmp	w2, #0x1
    856c:	54fffd81 	b.ne	851c <fwp_args23+0xc>  // b.any
    8570:	29430864 	ldp	w4, w2, [x3, #24]
    8574:	92403c21 	and	x1, x1, #0xffff
    8578:	9b047c21 	mul	x1, x1, x4
    857c:	d360fc21 	lsr	x1, x1, #32
    8580:	eb02003f 	cmp	x1, x2
    8584:	54fffcc2 	b.cs	851c <fwp_args23+0xc>  // b.hs, b.nlast
    8588:	8b010000 	add	x0, x0, x1
    858c:	39400001 	ldrb	w1, [x0]
    8590:	34fffc61 	cbz	w1, 851c <fwp_args23+0xc>
    8594:	900000c2 	adrp	x2, 20000 <__data_start>
    8598:	91014042 	add	x2, x2, #0x50
    859c:	b9413043 	ldr	w3, [x2, #304]
    85a0:	350000c3 	cbnz	w3, 85b8 <fwp_args23+0xa8>
    85a4:	7103f43f 	cmp	w1, #0xfd
    85a8:	54000168 	b.hi	85d4 <fwp_args23+0xc4>  // b.pmore
    85ac:	11000421 	add	w1, w1, #0x1
    85b0:	39000001 	strb	w1, [x0]
    85b4:	d65f03c0 	ret
    85b8:	f940ac43 	ldr	x3, [x2, #344]
    85bc:	91000463 	add	x3, x3, #0x1
    85c0:	f900ac43 	str	x3, [x2, #344]
    85c4:	17fffff8 	b	85a4 <fwp_args23+0x94>
    85c8:	72003c3f 	tst	w1, #0xffff
    85cc:	54fffe00 	b.eq	858c <fwp_args23+0x7c>  // b.none
    85d0:	d65f03c0 	ret
    85d4:	17fff0a8 	b	4874 <fwp_rc_wide_dup>
    85d8:	d503201f 	nop
    85dc:	d503201f 	nop

00000000000085e0 <fwp_args12>:
    85e0:	7100003f 	cmp	w1, #0x0
    85e4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    85e8:	54000041 	b.ne	85f0 <fwp_args12+0x10>  // b.any
    85ec:	d65f03c0 	ret
    85f0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    85f4:	9118c042 	add	x2, x2, #0x630
    85f8:	f9400001 	ldr	x1, [x0]
    85fc:	f949d843 	ldr	x3, [x2, #5040]
    8600:	f949ec40 	ldr	x0, [x2, #5080]
    8604:	cb030021 	sub	x1, x1, x3
    8608:	eb00403f 	cmp	x1, x0, lsl #16
    860c:	54ffff02 	b.cs	85ec <fwp_args12+0xc>  // b.hs, b.nlast
    8610:	d350fc20 	lsr	x0, x1, #16
    8614:	f949fc44 	ldr	x4, [x2, #5112]
    8618:	8b000800 	add	x0, x0, x0, lsl #2
    861c:	d37df002 	lsl	x2, x0, #3
    8620:	8b020083 	add	x3, x4, x2
    8624:	f9401060 	ldr	x0, [x3, #32]
    8628:	b4fffe20 	cbz	x0, 85ec <fwp_args12+0xc>
    862c:	38626882 	ldrb	w2, [x4, x2]
    8630:	7100085f 	cmp	w2, #0x2
    8634:	54000320 	b.eq	8698 <fwp_args12+0xb8>  // b.none
    8638:	7100045f 	cmp	w2, #0x1
    863c:	54fffd81 	b.ne	85ec <fwp_args12+0xc>  // b.any
    8640:	29430864 	ldp	w4, w2, [x3, #24]
    8644:	92403c21 	and	x1, x1, #0xffff
    8648:	9b047c21 	mul	x1, x1, x4
    864c:	d360fc21 	lsr	x1, x1, #32
    8650:	eb02003f 	cmp	x1, x2
    8654:	54fffcc2 	b.cs	85ec <fwp_args12+0xc>  // b.hs, b.nlast
    8658:	8b010000 	add	x0, x0, x1
    865c:	39400001 	ldrb	w1, [x0]
    8660:	34fffc61 	cbz	w1, 85ec <fwp_args12+0xc>
    8664:	900000c2 	adrp	x2, 20000 <__data_start>
    8668:	91014042 	add	x2, x2, #0x50
    866c:	b9413043 	ldr	w3, [x2, #304]
    8670:	350000c3 	cbnz	w3, 8688 <fwp_args12+0xa8>
    8674:	7103f43f 	cmp	w1, #0xfd
    8678:	54000168 	b.hi	86a4 <fwp_args12+0xc4>  // b.pmore
    867c:	11000421 	add	w1, w1, #0x1
    8680:	39000001 	strb	w1, [x0]
    8684:	d65f03c0 	ret
    8688:	f940ac43 	ldr	x3, [x2, #344]
    868c:	91000463 	add	x3, x3, #0x1
    8690:	f900ac43 	str	x3, [x2, #344]
    8694:	17fffff8 	b	8674 <fwp_args12+0x94>
    8698:	72003c3f 	tst	w1, #0xffff
    869c:	54fffe00 	b.eq	865c <fwp_args12+0x7c>  // b.none
    86a0:	d65f03c0 	ret
    86a4:	17fff074 	b	4874 <fwp_rc_wide_dup>
    86a8:	d503201f 	nop
    86ac:	d503201f 	nop

00000000000086b0 <fwp_caps12>:
    86b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    86b4:	910003fd 	mov	x29, sp
    86b8:	f9000bf3 	str	x19, [sp, #16]
    86bc:	aa0003f3 	mov	x19, x0
    86c0:	b9400400 	ldr	w0, [x0, #4]
    86c4:	340004a0 	cbz	w0, 8758 <fwp_caps12+0xa8>
    86c8:	f9400660 	ldr	x0, [x19, #8]
    86cc:	350004e1 	cbnz	w1, 8768 <fwp_caps12+0xb8>
    86d0:	97fff624 	bl	5f60 <fwp_drop0>
    86d4:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    86d8:	9118c042 	add	x2, x2, #0x630
    86dc:	f949d840 	ldr	x0, [x2, #5040]
    86e0:	f949ec41 	ldr	x1, [x2, #5080]
    86e4:	cb000260 	sub	x0, x19, x0
    86e8:	eb01401f 	cmp	x0, x1, lsl #16
    86ec:	54000382 	b.cs	875c <fwp_caps12+0xac>  // b.hs, b.nlast
    86f0:	d350fc01 	lsr	x1, x0, #16
    86f4:	f949fc44 	ldr	x4, [x2, #5112]
    86f8:	8b010821 	add	x1, x1, x1, lsl #2
    86fc:	d37df021 	lsl	x1, x1, #3
    8700:	8b010083 	add	x3, x4, x1
    8704:	f9401062 	ldr	x2, [x3, #32]
    8708:	b40002a2 	cbz	x2, 875c <fwp_caps12+0xac>
    870c:	38616881 	ldrb	w1, [x4, x1]
    8710:	7100083f 	cmp	w1, #0x2
    8714:	54000740 	b.eq	87fc <fwp_caps12+0x14c>  // b.none
    8718:	7100043f 	cmp	w1, #0x1
    871c:	54000201 	b.ne	875c <fwp_caps12+0xac>  // b.any
    8720:	29430464 	ldp	w4, w1, [x3, #24]
    8724:	92403c00 	and	x0, x0, #0xffff
    8728:	9b047c00 	mul	x0, x0, x4
    872c:	d360fc00 	lsr	x0, x0, #32
    8730:	eb01001f 	cmp	x0, x1
    8734:	54000142 	b.cs	875c <fwp_caps12+0xac>  // b.hs, b.nlast
    8738:	8b000042 	add	x2, x2, x0
    873c:	39400040 	ldrb	w0, [x2]
    8740:	7100041f 	cmp	w0, #0x1
    8744:	540000c1 	b.ne	875c <fwp_caps12+0xac>  // b.any
    8748:	aa1303e0 	mov	x0, x19
    874c:	f9400bf3 	ldr	x19, [sp, #16]
    8750:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8754:	17fff12f 	b	4c10 <fwp_mem_free>
    8758:	34fffbe1 	cbz	w1, 86d4 <fwp_caps12+0x24>
    875c:	f9400bf3 	ldr	x19, [sp, #16]
    8760:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8764:	d65f03c0 	ret
    8768:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    876c:	9118c042 	add	x2, x2, #0x630
    8770:	f949d843 	ldr	x3, [x2, #5040]
    8774:	f949ec41 	ldr	x1, [x2, #5080]
    8778:	cb030000 	sub	x0, x0, x3
    877c:	eb01401f 	cmp	x0, x1, lsl #16
    8780:	54fffee2 	b.cs	875c <fwp_caps12+0xac>  // b.hs, b.nlast
    8784:	d350fc01 	lsr	x1, x0, #16
    8788:	f949fc44 	ldr	x4, [x2, #5112]
    878c:	8b010821 	add	x1, x1, x1, lsl #2
    8790:	d37df021 	lsl	x1, x1, #3
    8794:	8b010083 	add	x3, x4, x1
    8798:	f9401062 	ldr	x2, [x3, #32]
    879c:	b4fffe02 	cbz	x2, 875c <fwp_caps12+0xac>
    87a0:	38616881 	ldrb	w1, [x4, x1]
    87a4:	7100083f 	cmp	w1, #0x2
    87a8:	54000300 	b.eq	8808 <fwp_caps12+0x158>  // b.none
    87ac:	7100043f 	cmp	w1, #0x1
    87b0:	54fffd61 	b.ne	875c <fwp_caps12+0xac>  // b.any
    87b4:	92403c01 	and	x1, x0, #0xffff
    87b8:	29430064 	ldp	w4, w0, [x3, #24]
    87bc:	9b047c21 	mul	x1, x1, x4
    87c0:	d360fc21 	lsr	x1, x1, #32
    87c4:	eb00003f 	cmp	x1, x0
    87c8:	54fffca2 	b.cs	875c <fwp_caps12+0xac>  // b.hs, b.nlast
    87cc:	8b010042 	add	x2, x2, x1
    87d0:	39400040 	ldrb	w0, [x2]
    87d4:	34fffc40 	cbz	w0, 875c <fwp_caps12+0xac>
    87d8:	900000c1 	adrp	x1, 20000 <__data_start>
    87dc:	91014021 	add	x1, x1, #0x50
    87e0:	b9413023 	ldr	w3, [x1, #304]
    87e4:	35000183 	cbnz	w3, 8814 <fwp_caps12+0x164>
    87e8:	7103f41f 	cmp	w0, #0xfd
    87ec:	540001c8 	b.hi	8824 <fwp_caps12+0x174>  // b.pmore
    87f0:	11000400 	add	w0, w0, #0x1
    87f4:	39000040 	strb	w0, [x2]
    87f8:	17ffffd9 	b	875c <fwp_caps12+0xac>
    87fc:	72003c1f 	tst	w0, #0xffff
    8800:	54fffae1 	b.ne	875c <fwp_caps12+0xac>  // b.any
    8804:	17ffffce 	b	873c <fwp_caps12+0x8c>
    8808:	72003c1f 	tst	w0, #0xffff
    880c:	54fffa81 	b.ne	875c <fwp_caps12+0xac>  // b.any
    8810:	17fffff0 	b	87d0 <fwp_caps12+0x120>
    8814:	f940ac23 	ldr	x3, [x1, #344]
    8818:	91000463 	add	x3, x3, #0x1
    881c:	f900ac23 	str	x3, [x1, #344]
    8820:	17fffff2 	b	87e8 <fwp_caps12+0x138>
    8824:	f9400bf3 	ldr	x19, [sp, #16]
    8828:	aa0203e0 	mov	x0, x2
    882c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8830:	17fff011 	b	4874 <fwp_rc_wide_dup>

0000000000008834 <fwp_caps23>:
    8834:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8838:	910003fd 	mov	x29, sp
    883c:	f9000bf3 	str	x19, [sp, #16]
    8840:	aa0003f3 	mov	x19, x0
    8844:	b9400400 	ldr	w0, [x0, #4]
    8848:	340004a0 	cbz	w0, 88dc <fwp_caps23+0xa8>
    884c:	f9400660 	ldr	x0, [x19, #8]
    8850:	350004e1 	cbnz	w1, 88ec <fwp_caps23+0xb8>
    8854:	97fffd93 	bl	7ea0 <fwp_drop2>
    8858:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    885c:	9118c042 	add	x2, x2, #0x630
    8860:	f949d840 	ldr	x0, [x2, #5040]
    8864:	f949ec41 	ldr	x1, [x2, #5080]
    8868:	cb000260 	sub	x0, x19, x0
    886c:	eb01401f 	cmp	x0, x1, lsl #16
    8870:	54000382 	b.cs	88e0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8874:	d350fc01 	lsr	x1, x0, #16
    8878:	f949fc44 	ldr	x4, [x2, #5112]
    887c:	8b010821 	add	x1, x1, x1, lsl #2
    8880:	d37df021 	lsl	x1, x1, #3
    8884:	8b010083 	add	x3, x4, x1
    8888:	f9401062 	ldr	x2, [x3, #32]
    888c:	b40002a2 	cbz	x2, 88e0 <fwp_caps23+0xac>
    8890:	38616881 	ldrb	w1, [x4, x1]
    8894:	7100083f 	cmp	w1, #0x2
    8898:	54000740 	b.eq	8980 <fwp_caps23+0x14c>  // b.none
    889c:	7100043f 	cmp	w1, #0x1
    88a0:	54000201 	b.ne	88e0 <fwp_caps23+0xac>  // b.any
    88a4:	29430464 	ldp	w4, w1, [x3, #24]
    88a8:	92403c00 	and	x0, x0, #0xffff
    88ac:	9b047c00 	mul	x0, x0, x4
    88b0:	d360fc00 	lsr	x0, x0, #32
    88b4:	eb01001f 	cmp	x0, x1
    88b8:	54000142 	b.cs	88e0 <fwp_caps23+0xac>  // b.hs, b.nlast
    88bc:	8b000042 	add	x2, x2, x0
    88c0:	39400040 	ldrb	w0, [x2]
    88c4:	7100041f 	cmp	w0, #0x1
    88c8:	540000c1 	b.ne	88e0 <fwp_caps23+0xac>  // b.any
    88cc:	aa1303e0 	mov	x0, x19
    88d0:	f9400bf3 	ldr	x19, [sp, #16]
    88d4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    88d8:	17fff0ce 	b	4c10 <fwp_mem_free>
    88dc:	34fffbe1 	cbz	w1, 8858 <fwp_caps23+0x24>
    88e0:	f9400bf3 	ldr	x19, [sp, #16]
    88e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    88e8:	d65f03c0 	ret
    88ec:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    88f0:	9118c042 	add	x2, x2, #0x630
    88f4:	f949d843 	ldr	x3, [x2, #5040]
    88f8:	f949ec41 	ldr	x1, [x2, #5080]
    88fc:	cb030000 	sub	x0, x0, x3
    8900:	eb01401f 	cmp	x0, x1, lsl #16
    8904:	54fffee2 	b.cs	88e0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8908:	d350fc01 	lsr	x1, x0, #16
    890c:	f949fc44 	ldr	x4, [x2, #5112]
    8910:	8b010821 	add	x1, x1, x1, lsl #2
    8914:	d37df021 	lsl	x1, x1, #3
    8918:	8b010083 	add	x3, x4, x1
    891c:	f9401062 	ldr	x2, [x3, #32]
    8920:	b4fffe02 	cbz	x2, 88e0 <fwp_caps23+0xac>
    8924:	38616881 	ldrb	w1, [x4, x1]
    8928:	7100083f 	cmp	w1, #0x2
    892c:	54000300 	b.eq	898c <fwp_caps23+0x158>  // b.none
    8930:	7100043f 	cmp	w1, #0x1
    8934:	54fffd61 	b.ne	88e0 <fwp_caps23+0xac>  // b.any
    8938:	92403c01 	and	x1, x0, #0xffff
    893c:	29430064 	ldp	w4, w0, [x3, #24]
    8940:	9b047c21 	mul	x1, x1, x4
    8944:	d360fc21 	lsr	x1, x1, #32
    8948:	eb00003f 	cmp	x1, x0
    894c:	54fffca2 	b.cs	88e0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8950:	8b010042 	add	x2, x2, x1
    8954:	39400040 	ldrb	w0, [x2]
    8958:	34fffc40 	cbz	w0, 88e0 <fwp_caps23+0xac>
    895c:	900000c1 	adrp	x1, 20000 <__data_start>
    8960:	91014021 	add	x1, x1, #0x50
    8964:	b9413023 	ldr	w3, [x1, #304]
    8968:	35000183 	cbnz	w3, 8998 <fwp_caps23+0x164>
    896c:	7103f41f 	cmp	w0, #0xfd
    8970:	540001c8 	b.hi	89a8 <fwp_caps23+0x174>  // b.pmore
    8974:	11000400 	add	w0, w0, #0x1
    8978:	39000040 	strb	w0, [x2]
    897c:	17ffffd9 	b	88e0 <fwp_caps23+0xac>
    8980:	72003c1f 	tst	w0, #0xffff
    8984:	54fffae1 	b.ne	88e0 <fwp_caps23+0xac>  // b.any
    8988:	17ffffce 	b	88c0 <fwp_caps23+0x8c>
    898c:	72003c1f 	tst	w0, #0xffff
    8990:	54fffa81 	b.ne	88e0 <fwp_caps23+0xac>  // b.any
    8994:	17fffff0 	b	8954 <fwp_caps23+0x120>
    8998:	f940ac23 	ldr	x3, [x1, #344]
    899c:	91000463 	add	x3, x3, #0x1
    89a0:	f900ac23 	str	x3, [x1, #344]
    89a4:	17fffff2 	b	896c <fwp_caps23+0x138>
    89a8:	f9400bf3 	ldr	x19, [sp, #16]
    89ac:	aa0203e0 	mov	x0, x2
    89b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    89b4:	17ffefb0 	b	4874 <fwp_rc_wide_dup>
    89b8:	d503201f 	nop
    89bc:	d503201f 	nop

00000000000089c0 <fwp_write>:
    89c0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    89c4:	910003fd 	mov	x29, sp
    89c8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    89cc:	f947f484 	ldr	x4, [x4, #4072]
    89d0:	a90153f3 	stp	x19, x20, [sp, #16]
    89d4:	d10943ff 	sub	sp, sp, #0x250
    89d8:	b9400045 	ldr	w5, [x2]
    89dc:	aa0003f4 	mov	x20, x0
    89e0:	f9400080 	ldr	x0, [x4]
    89e4:	f90127e0 	str	x0, [sp, #584]
    89e8:	d2800000 	mov	x0, #0x0                   	// #0
    89ec:	710064bf 	cmp	w5, #0x19
    89f0:	54000408 	b.hi	8a70 <fwp_write+0xb0>  // b.pmore
    89f4:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    89f8:	aa0103f3 	mov	x19, x1
    89fc:	912f8000 	add	x0, x0, #0xbe0
    8a00:	f9013bf5 	str	x21, [sp, #624]
    8a04:	f9013ff6 	str	x22, [sp, #632]
    8a08:	f90153fb 	str	x27, [sp, #672]
    8a0c:	f90157fc 	str	x28, [sp, #680]
    8a10:	aa0203fc 	mov	x28, x2
    8a14:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8a18:	10000061 	adr	x1, 8a24 <fwp_write+0x64>
    8a1c:	8b20a820 	add	x0, x1, w0, sxth #2
    8a20:	d61f0000 	br	x0
    8a24:	910123e0 	add	x0, sp, #0x48
    8a28:	aa1303e5 	mov	x5, x19
    8a2c:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x350>
    8a30:	aa0003f3 	mov	x19, x0
    8a34:	910f4084 	add	x4, x4, #0x3d0
    8a38:	d2804003 	mov	x3, #0x200                 	// #512
    8a3c:	aa0303e1 	mov	x1, x3
    8a40:	52800042 	mov	w2, #0x2                   	// #2
    8a44:	97ffe74f 	bl	2780 <__snprintf_chk@plt>
    8a48:	aa1303e0 	mov	x0, x19
    8a4c:	97ffe715 	bl	26a0 <strlen@plt>
    8a50:	aa1303e1 	mov	x1, x19
    8a54:	aa0003e2 	mov	x2, x0
    8a58:	aa1403e0 	mov	x0, x20
    8a5c:	97ffeaed 	bl	3610 <buf_put>
    8a60:	f9413bf5 	ldr	x21, [sp, #624]
    8a64:	f9413ff6 	ldr	x22, [sp, #632]
    8a68:	f94153fb 	ldr	x27, [sp, #672]
    8a6c:	f94157fc 	ldr	x28, [sp, #680]
    8a70:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8a74:	f947f400 	ldr	x0, [x0, #4072]
    8a78:	f94127e2 	ldr	x2, [sp, #584]
    8a7c:	f9400001 	ldr	x1, [x0]
    8a80:	eb010042 	subs	x2, x2, x1
    8a84:	d2800001 	mov	x1, #0x0                   	// #0
    8a88:	540077c1 	b.ne	9980 <fwp_write+0xfc0>  // b.any
    8a8c:	910943ff 	add	sp, sp, #0x250
    8a90:	a94153f3 	ldp	x19, x20, [sp, #16]
    8a94:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8a98:	d65f03c0 	ret
    8a9c:	910123e0 	add	x0, sp, #0x48
    8aa0:	aa1303e5 	mov	x5, x19
    8aa4:	f0000004 	adrp	x4, b000 <_IO_stdin_used+0x350>
    8aa8:	aa0003f3 	mov	x19, x0
    8aac:	910f2084 	add	x4, x4, #0x3c8
    8ab0:	d2804003 	mov	x3, #0x200                 	// #512
    8ab4:	17ffffe2 	b	8a3c <fwp_write+0x7c>
    8ab8:	71004cbf 	cmp	w5, #0x13
    8abc:	f0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    8ac0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8ac4:	910ee000 	add	x0, x0, #0x3b8
    8ac8:	910f0021 	add	x1, x1, #0x3c0
    8acc:	d2800082 	mov	x2, #0x4                   	// #4
    8ad0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8ad4:	aa1403e0 	mov	x0, x20
    8ad8:	f90143f7 	str	x23, [sp, #640]
    8adc:	d2800016 	mov	x22, #0x0                   	// #0
    8ae0:	f90147f8 	str	x24, [sp, #648]
    8ae4:	97ffeacb 	bl	3610 <buf_put>
    8ae8:	f9400260 	ldr	x0, [x19]
    8aec:	f0000017 	adrp	x23, b000 <_IO_stdin_used+0x350>
    8af0:	d2800015 	mov	x21, #0x0                   	// #0
    8af4:	911102f7 	add	x23, x23, #0x440
    8af8:	b40047a0 	cbz	x0, 93ec <fwp_write+0xa2c>
    8afc:	b9400380 	ldr	w0, [x28]
    8b00:	52800003 	mov	w3, #0x0                   	// #0
    8b04:	f9401f82 	ldr	x2, [x28, #56]
    8b08:	71004c1f 	cmp	w0, #0x13
    8b0c:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8b10:	aa1403e0 	mov	x0, x20
    8b14:	8b010e61 	add	x1, x19, x1, lsl #3
    8b18:	f9400421 	ldr	x1, [x1, #8]
    8b1c:	97ffffa9 	bl	89c0 <fwp_write>
    8b20:	b9400380 	ldr	w0, [x28]
    8b24:	7100481f 	cmp	w0, #0x12
    8b28:	54004b40 	b.eq	9490 <fwp_write+0xad0>  // b.none
    8b2c:	f9400260 	ldr	x0, [x19]
    8b30:	910006b5 	add	x21, x21, #0x1
    8b34:	91000ad6 	add	x22, x22, #0x2
    8b38:	eb15001f 	cmp	x0, x21
    8b3c:	54004589 	b.ls	93ec <fwp_write+0xa2c>  // b.plast
    8b40:	aa1703e1 	mov	x1, x23
    8b44:	aa1403e0 	mov	x0, x20
    8b48:	d2800042 	mov	x2, #0x2                   	// #2
    8b4c:	97ffeab1 	bl	3610 <buf_put>
    8b50:	17ffffeb 	b	8afc <fwp_write+0x13c>
    8b54:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8b58:	910fe021 	add	x1, x1, #0x3f8
    8b5c:	d28000c2 	mov	x2, #0x6                   	// #6
    8b60:	aa1403e0 	mov	x0, x20
    8b64:	91004273 	add	x19, x19, #0x10
    8b68:	97ffeaaa 	bl	3610 <buf_put>
    8b6c:	aa1303e0 	mov	x0, x19
    8b70:	97ffe6cc 	bl	26a0 <strlen@plt>
    8b74:	aa1303e1 	mov	x1, x19
    8b78:	aa0003e2 	mov	x2, x0
    8b7c:	aa1403e0 	mov	x0, x20
    8b80:	97ffeaa4 	bl	3610 <buf_put>
    8b84:	528007c3 	mov	w3, #0x3e                  	// #62
    8b88:	aa1403e0 	mov	x0, x20
    8b8c:	91001fe1 	add	x1, sp, #0x7
    8b90:	d2800022 	mov	x2, #0x1                   	// #1
    8b94:	39001fe3 	strb	w3, [sp, #7]
    8b98:	17ffffb1 	b	8a5c <fwp_write+0x9c>
    8b9c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8ba0:	f947f400 	ldr	x0, [x0, #4072]
    8ba4:	f94127e2 	ldr	x2, [sp, #584]
    8ba8:	f9400001 	ldr	x1, [x0]
    8bac:	eb010042 	subs	x2, x2, x1
    8bb0:	d2800001 	mov	x1, #0x0                   	// #0
    8bb4:	540034e1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8bb8:	f9413bf5 	ldr	x21, [sp, #624]
    8bbc:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8bc0:	f9413ff6 	ldr	x22, [sp, #632]
    8bc4:	aa1403e0 	mov	x0, x20
    8bc8:	910f6021 	add	x1, x1, #0x3d8
    8bcc:	d2800142 	mov	x2, #0xa                   	// #10
    8bd0:	f94153fb 	ldr	x27, [sp, #672]
    8bd4:	f94157fc 	ldr	x28, [sp, #680]
    8bd8:	910943ff 	add	sp, sp, #0x250
    8bdc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8be0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8be4:	17ffea8b 	b	3610 <buf_put>
    8be8:	f9400456 	ldr	x22, [x2, #8]
    8bec:	f90143f7 	str	x23, [sp, #640]
    8bf0:	f90147f8 	str	x24, [sp, #648]
    8bf4:	b4005b16 	cbz	x22, 9754 <fwp_write+0xd94>
    8bf8:	aa1603e0 	mov	x0, x22
    8bfc:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8c00:	91116021 	add	x1, x1, #0x458
    8c04:	97ffe723 	bl	2890 <strcmp@plt>
    8c08:	2a0003f5 	mov	w21, w0
    8c0c:	34005fe0 	cbz	w0, 9808 <fwp_write+0xe48>
    8c10:	aa1603e0 	mov	x0, x22
    8c14:	97ffe6a3 	bl	26a0 <strlen@plt>
    8c18:	aa1603e1 	mov	x1, x22
    8c1c:	aa0003e2 	mov	x2, x0
    8c20:	aa1403e0 	mov	x0, x20
    8c24:	97ffea7b 	bl	3610 <buf_put>
    8c28:	52800403 	mov	w3, #0x20                  	// #32
    8c2c:	91001ff5 	add	x21, sp, #0x7
    8c30:	aa1503e1 	mov	x1, x21
    8c34:	aa1403e0 	mov	x0, x20
    8c38:	d2800022 	mov	x2, #0x1                   	// #1
    8c3c:	39001fe3 	strb	w3, [sp, #7]
    8c40:	97ffea74 	bl	3610 <buf_put>
    8c44:	52800f63 	mov	w3, #0x7b                  	// #123
    8c48:	aa1403e0 	mov	x0, x20
    8c4c:	aa1503e1 	mov	x1, x21
    8c50:	d2800022 	mov	x2, #0x1                   	// #1
    8c54:	39001fe3 	strb	w3, [sp, #7]
    8c58:	97ffea6e 	bl	3610 <buf_put>
    8c5c:	b9401380 	ldr	w0, [x28, #16]
    8c60:	52800018 	mov	w24, #0x0                   	// #0
    8c64:	7100001f 	cmp	w0, #0x0
    8c68:	54003aad 	b.le	93bc <fwp_write+0x9fc>
    8c6c:	f9014bf9 	str	x25, [sp, #656]
    8c70:	f0000019 	adrp	x25, b000 <_IO_stdin_used+0x350>
    8c74:	91120339 	add	x25, x25, #0x480
    8c78:	f9014ffa 	str	x26, [sp, #664]
    8c7c:	f000001a 	adrp	x26, b000 <_IO_stdin_used+0x350>
    8c80:	9111035a 	add	x26, x26, #0x440
    8c84:	91002276 	add	x22, x19, #0x8
    8c88:	d2800013 	mov	x19, #0x0                   	// #0
    8c8c:	b5003e93 	cbnz	x19, 945c <fwp_write+0xa9c>
    8c90:	d37df277 	lsl	x23, x19, #3
    8c94:	34003cb8 	cbz	w24, 9428 <fwp_write+0xa68>
    8c98:	f9401382 	ldr	x2, [x28, #32]
    8c9c:	aa1403e0 	mov	x0, x20
    8ca0:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8ca4:	52800003 	mov	w3, #0x0                   	// #0
    8ca8:	f8776842 	ldr	x2, [x2, x23]
    8cac:	91000673 	add	x19, x19, #0x1
    8cb0:	97ffff44 	bl	89c0 <fwp_write>
    8cb4:	b9401380 	ldr	w0, [x28, #16]
    8cb8:	6b13001f 	cmp	w0, w19
    8cbc:	54fffe8c 	b.gt	8c8c <fwp_write+0x2cc>
    8cc0:	f9414bf9 	ldr	x25, [sp, #656]
    8cc4:	f9414ffa 	ldr	x26, [sp, #664]
    8cc8:	340037b8 	cbz	w24, 93bc <fwp_write+0x9fc>
    8ccc:	52800523 	mov	w3, #0x29                  	// #41
    8cd0:	aa1503e1 	mov	x1, x21
    8cd4:	aa1403e0 	mov	x0, x20
    8cd8:	d2800022 	mov	x2, #0x1                   	// #1
    8cdc:	39001fe3 	strb	w3, [sp, #7]
    8ce0:	97ffea4c 	bl	3610 <buf_put>
    8ce4:	f9413bf5 	ldr	x21, [sp, #624]
    8ce8:	f9413ff6 	ldr	x22, [sp, #632]
    8cec:	f94143f7 	ldr	x23, [sp, #640]
    8cf0:	f94147f8 	ldr	x24, [sp, #648]
    8cf4:	f94153fb 	ldr	x27, [sp, #672]
    8cf8:	f94157fc 	ldr	x28, [sp, #680]
    8cfc:	17ffff5d 	b	8a70 <fwp_write+0xb0>
    8d00:	b9404855 	ldr	w21, [x2, #72]
    8d04:	aa1403e0 	mov	x0, x20
    8d08:	93407eb6 	sxtw	x22, w21
    8d0c:	91000ac1 	add	x1, x22, #0x2
    8d10:	97ffea0c 	bl	3540 <buf_grow>
    8d14:	a9400281 	ldp	x1, x0, [x20]
    8d18:	528e8603 	mov	w3, #0x7430                	// #29744
    8d1c:	78206823 	strh	w3, [x1, x0]
    8d20:	8b000022 	add	x2, x1, x0
    8d24:	710002bf 	cmp	w21, #0x0
    8d28:	540036cd 	b.le	9400 <fwp_write+0xa40>
    8d2c:	110006a3 	add	w3, w21, #0x1
    8d30:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    8d34:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    8d38:	91000449 	add	x9, x2, #0x1
    8d3c:	8b23c043 	add	x3, x2, w3, sxtw
    8d40:	f28aaac6 	movk	x6, #0x5556
    8d44:	f2955568 	movk	x8, #0xaaab
    8d48:	1400000d 	b	8d7c <fwp_write+0x3bc>
    8d4c:	d2800021 	mov	x1, #0x1                   	// #1
    8d50:	528005a5 	mov	w5, #0x2d                  	// #45
    8d54:	f100001f 	cmp	x0, #0x0
    8d58:	9b467e60 	smulh	x0, x19, x6
    8d5c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    8d60:	381ff465 	strb	w5, [x3], #-1
    8d64:	cb040000 	sub	x0, x0, x4
    8d68:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    8d6c:	cb020000 	sub	x0, x0, x2
    8d70:	8b010013 	add	x19, x0, x1
    8d74:	eb03013f 	cmp	x9, x3
    8d78:	54003440 	b.eq	9400 <fwp_write+0xa40>  // b.none
    8d7c:	9b467e60 	smulh	x0, x19, x6
    8d80:	937ffe64 	asr	x4, x19, #63
    8d84:	52800605 	mov	w5, #0x30                  	// #48
    8d88:	cb040000 	sub	x0, x0, x4
    8d8c:	8b000400 	add	x0, x0, x0, lsl #1
    8d90:	cb000260 	sub	x0, x19, x0
    8d94:	91000c01 	add	x1, x0, #0x3
    8d98:	9bc87c22 	umulh	x2, x1, x8
    8d9c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    8da0:	8b4204e2 	add	x2, x7, x2, lsr #1
    8da4:	eb020021 	subs	x1, x1, x2
    8da8:	54fffd60 	b.eq	8d54 <fwp_write+0x394>  // b.none
    8dac:	f100043f 	cmp	x1, #0x1
    8db0:	54fffce1 	b.ne	8d4c <fwp_write+0x38c>  // b.any
    8db4:	d2800001 	mov	x1, #0x0                   	// #0
    8db8:	52800565 	mov	w5, #0x2b                  	// #43
    8dbc:	17ffffe6 	b	8d54 <fwp_write+0x394>
    8dc0:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8dc4:	f947f400 	ldr	x0, [x0, #4072]
    8dc8:	f94127e2 	ldr	x2, [sp, #584]
    8dcc:	f9400001 	ldr	x1, [x0]
    8dd0:	eb010042 	subs	x2, x2, x1
    8dd4:	d2800001 	mov	x1, #0x0                   	// #0
    8dd8:	540023c1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8ddc:	f9413bf5 	ldr	x21, [sp, #624]
    8de0:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8de4:	f9413ff6 	ldr	x22, [sp, #632]
    8de8:	aa1403e0 	mov	x0, x20
    8dec:	910fa021 	add	x1, x1, #0x3e8
    8df0:	d2800102 	mov	x2, #0x8                   	// #8
    8df4:	17ffff77 	b	8bd0 <fwp_write+0x210>
    8df8:	aa1403e0 	mov	x0, x20
    8dfc:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8e00:	d28000c2 	mov	x2, #0x6                   	// #6
    8e04:	91112021 	add	x1, x1, #0x448
    8e08:	97ffea02 	bl	3610 <buf_put>
    8e0c:	d2800015 	mov	x21, #0x0                   	// #0
    8e10:	f9400263 	ldr	x3, [x19]
    8e14:	f240f87f 	tst	x3, #0x7fffffffffffffff
    8e18:	54002c60 	b.eq	93a4 <fwp_write+0x9e4>  // b.none
    8e1c:	f9401f82 	ldr	x2, [x28, #56]
    8e20:	f90143f7 	str	x23, [sp, #640]
    8e24:	f90147f8 	str	x24, [sp, #648]
    8e28:	d2800857 	mov	x23, #0x42                  	// #66
    8e2c:	f9014bf9 	str	x25, [sp, #656]
    8e30:	f0000016 	adrp	x22, b000 <_IO_stdin_used+0x350>
    8e34:	f9014ffa 	str	x26, [sp, #664]
    8e38:	911102d6 	add	x22, x22, #0x440
    8e3c:	d2800038 	mov	x24, #0x1                   	// #1
    8e40:	f2a18017 	movk	x23, #0xc00, lsl #16
    8e44:	d2809099 	mov	x25, #0x484                 	// #1156
    8e48:	b40004a2 	cbz	x2, 8edc <fwp_write+0x51c>
    8e4c:	b9400040 	ldr	w0, [x2]
    8e50:	7100701f 	cmp	w0, #0x1c
    8e54:	540042c0 	b.eq	96ac <fwp_write+0xcec>  // b.none
    8e58:	71006c1f 	cmp	w0, #0x1b
    8e5c:	54000408 	b.hi	8edc <fwp_write+0x51c>  // b.pmore
    8e60:	9ac02301 	lsl	x1, x24, x0
    8e64:	ea17003f 	tst	x1, x23
    8e68:	540036a1 	b.ne	953c <fwp_write+0xb7c>  // b.any
    8e6c:	ea19003f 	tst	x1, x25
    8e70:	54003521 	b.ne	9514 <fwp_write+0xb54>  // b.any
    8e74:	d2800424 	mov	x4, #0x21                  	// #33
    8e78:	ea04003f 	tst	x1, x4
    8e7c:	54000300 	b.eq	8edc <fwp_write+0x51c>  // b.none
    8e80:	b7f849c3 	tbnz	x3, #63, 97b8 <fwp_write+0xdf8>
    8e84:	91002261 	add	x1, x19, #0x8
    8e88:	8b150021 	add	x1, x1, x21
    8e8c:	39400021 	ldrb	w1, [x1]
    8e90:	7100001f 	cmp	w0, #0x0
    8e94:	93401c23 	sxtb	x3, w1
    8e98:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    8e9c:	d503201f 	nop
    8ea0:	aa1403e0 	mov	x0, x20
    8ea4:	52800003 	mov	w3, #0x0                   	// #0
    8ea8:	97fffec6 	bl	89c0 <fwp_write>
    8eac:	910006b5 	add	x21, x21, #0x1
    8eb0:	f9400260 	ldr	x0, [x19]
    8eb4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    8eb8:	eb0002bf 	cmp	x21, x0
    8ebc:	540026c2 	b.cs	9394 <fwp_write+0x9d4>  // b.hs, b.nlast
    8ec0:	d2800042 	mov	x2, #0x2                   	// #2
    8ec4:	aa1603e1 	mov	x1, x22
    8ec8:	aa1403e0 	mov	x0, x20
    8ecc:	97ffe9d1 	bl	3610 <buf_put>
    8ed0:	f9401f82 	ldr	x2, [x28, #56]
    8ed4:	f9400263 	ldr	x3, [x19]
    8ed8:	b5fffba2 	cbnz	x2, 8e4c <fwp_write+0x48c>
    8edc:	d37df2a0 	lsl	x0, x21, #3
    8ee0:	b7f83f03 	tbnz	x3, #63, 96c0 <fwp_write+0xd00>
    8ee4:	91002261 	add	x1, x19, #0x8
    8ee8:	8b000020 	add	x0, x1, x0
    8eec:	f9400001 	ldr	x1, [x0]
    8ef0:	17ffffec 	b	8ea0 <fwp_write+0x4e0>
    8ef4:	a9400e62 	ldp	x2, x3, [x19]
    8ef8:	b7f83ca3 	tbnz	x3, #63, 968c <fwp_write+0xccc>
    8efc:	910123f5 	add	x21, sp, #0x48
    8f00:	aa1503e0 	mov	x0, x21
    8f04:	97ffe7a7 	bl	2da0 <fwp_fmt_u128>
    8f08:	aa1503e0 	mov	x0, x21
    8f0c:	97ffe5e5 	bl	26a0 <strlen@plt>
    8f10:	aa1503e1 	mov	x1, x21
    8f14:	aa0003e2 	mov	x2, x0
    8f18:	17fffed0 	b	8a58 <fwp_write+0x98>
    8f1c:	fd015be8 	str	d8, [sp, #688]
    8f20:	1e270268 	fmov	s8, w19
    8f24:	fd015fe9 	str	d9, [sp, #696]
    8f28:	1e282100 	fcmp	s8, s8
    8f2c:	54004d26 	b.vs	98d0 <fwp_write+0xf10>
    8f30:	1e20c101 	fabs	s1, s8
    8f34:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    8f38:	1e270000 	fmov	s0, w0
    8f3c:	1e202020 	fcmp	s1, s0
    8f40:	54002c0d 	b.le	94c0 <fwp_write+0xb00>
    8f44:	1e202118 	fcmpe	s8, #0.0
    8f48:	d0000002 	adrp	x2, a000 <fwp_main_thread+0x650>
    8f4c:	9138a042 	add	x2, x2, #0xe28
    8f50:	910123f5 	add	x21, sp, #0x48
    8f54:	f0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    8f58:	910e6021 	add	x1, x1, #0x398
    8f5c:	aa1503e0 	mov	x0, x21
    8f60:	9a81c041 	csel	x1, x2, x1, gt
    8f64:	97ffe67b 	bl	2950 <strcpy@plt>
    8f68:	aa1503e0 	mov	x0, x21
    8f6c:	97ffe5cd 	bl	26a0 <strlen@plt>
    8f70:	aa1503e1 	mov	x1, x21
    8f74:	aa0003e2 	mov	x2, x0
    8f78:	aa1403e0 	mov	x0, x20
    8f7c:	97ffe9a5 	bl	3610 <buf_put>
    8f80:	f9413bf5 	ldr	x21, [sp, #624]
    8f84:	f9413ff6 	ldr	x22, [sp, #632]
    8f88:	f94153fb 	ldr	x27, [sp, #672]
    8f8c:	f94157fc 	ldr	x28, [sp, #680]
    8f90:	fd415be8 	ldr	d8, [sp, #688]
    8f94:	fd415fe9 	ldr	d9, [sp, #696]
    8f98:	17fffeb6 	b	8a70 <fwp_write+0xb0>
    8f9c:	f9400276 	ldr	x22, [x19]
    8fa0:	34002e03 	cbz	w3, 9560 <fwp_write+0xba0>
    8fa4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8fa8:	f947f400 	ldr	x0, [x0, #4072]
    8fac:	f94127e2 	ldr	x2, [sp, #584]
    8fb0:	f9400001 	ldr	x1, [x0]
    8fb4:	eb010042 	subs	x2, x2, x1
    8fb8:	d2800001 	mov	x1, #0x0                   	// #0
    8fbc:	540014a1 	b.ne	9250 <fwp_write+0x890>  // b.any
    8fc0:	aa1603e2 	mov	x2, x22
    8fc4:	91002261 	add	x1, x19, #0x8
    8fc8:	f9413bf5 	ldr	x21, [sp, #624]
    8fcc:	aa1403e0 	mov	x0, x20
    8fd0:	f9413ff6 	ldr	x22, [sp, #632]
    8fd4:	17fffeff 	b	8bd0 <fwp_write+0x210>
    8fd8:	fd015be8 	str	d8, [sp, #688]
    8fdc:	9e670268 	fmov	d8, x19
    8fe0:	fd015fe9 	str	d9, [sp, #696]
    8fe4:	1e682100 	fcmp	d8, d8
    8fe8:	54004746 	b.vs	98d0 <fwp_write+0xf10>
    8fec:	1e60c101 	fabs	d1, d8
    8ff0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    8ff4:	9e670000 	fmov	d0, x0
    8ff8:	910123f5 	add	x21, sp, #0x48
    8ffc:	52800033 	mov	w19, #0x1                   	// #1
    9000:	1e602020 	fcmp	d1, d0
    9004:	540001ad 	b.le	9038 <fwp_write+0x678>
    9008:	1e602118 	fcmpe	d8, #0.0
    900c:	b0000002 	adrp	x2, a000 <fwp_main_thread+0x650>
    9010:	9138a042 	add	x2, x2, #0xe28
    9014:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    9018:	910e6021 	add	x1, x1, #0x398
    901c:	aa1503e0 	mov	x0, x21
    9020:	9a81c041 	csel	x1, x2, x1, gt
    9024:	97ffe64b 	bl	2950 <strcpy@plt>
    9028:	17ffffd0 	b	8f68 <fwp_write+0x5a8>
    902c:	11000673 	add	w19, w19, #0x1
    9030:	71004a7f 	cmp	w19, #0x12
    9034:	54003860 	b.eq	9740 <fwp_write+0xd80>  // b.none
    9038:	1e604100 	fmov	d0, d8
    903c:	2a1303e1 	mov	w1, w19
    9040:	aa1503e0 	mov	x0, x21
    9044:	97ffeab4 	bl	3b14 <fwp_format_g.constprop.0>
    9048:	aa1503e0 	mov	x0, x21
    904c:	d2800001 	mov	x1, #0x0                   	// #0
    9050:	97ffe5a8 	bl	26f0 <strtod@plt>
    9054:	1e602100 	fcmp	d8, d0
    9058:	54fffea1 	b.ne	902c <fwp_write+0x66c>  // b.any
    905c:	aa1503e0 	mov	x0, x21
    9060:	97ffe9a5 	bl	36f4 <fwp_finish_float>
    9064:	17ffffc1 	b	8f68 <fwp_write+0x5a8>
    9068:	a9400e62 	ldp	x2, x3, [x19]
    906c:	910123f3 	add	x19, sp, #0x48
    9070:	aa1303e0 	mov	x0, x19
    9074:	97ffe74b 	bl	2da0 <fwp_fmt_u128>
    9078:	17fffe74 	b	8a48 <fwp_write+0x88>
    907c:	f90143f7 	str	x23, [sp, #640]
    9080:	f90147f8 	str	x24, [sp, #648]
    9084:	2a1303f8 	mov	w24, w19
    9088:	f9014bf9 	str	x25, [sp, #656]
    908c:	f9014ffa 	str	x26, [sp, #664]
    9090:	f13ffe7f 	cmp	x19, #0xfff
    9094:	54000049 	b.ls	909c <fwp_write+0x6dc>  // b.plast
    9098:	b9400278 	ldr	w24, [x19]
    909c:	f9400f80 	ldr	x0, [x28, #24]
    90a0:	2a1803f5 	mov	w21, w24
    90a4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    90a8:	d37ef6b9 	lsl	x25, x21, #2
    90ac:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    90b0:	aa1603e0 	mov	x0, x22
    90b4:	97ffe57b 	bl	26a0 <strlen@plt>
    90b8:	aa1603e1 	mov	x1, x22
    90bc:	aa0003e2 	mov	x2, x0
    90c0:	aa1403e0 	mov	x0, x20
    90c4:	97ffe953 	bl	3610 <buf_put>
    90c8:	f9401780 	ldr	x0, [x28, #40]
    90cc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    90d0:	7100001f 	cmp	w0, #0x0
    90d4:	5400068d 	b.le	91a4 <fwp_write+0x7e4>
    90d8:	91002276 	add	x22, x19, #0x8
    90dc:	91001ff5 	add	x21, sp, #0x7
    90e0:	d280001b 	mov	x27, #0x0                   	// #0
    90e4:	5280041a 	mov	w26, #0x20                  	// #32
    90e8:	f9401b80 	ldr	x0, [x28, #48]
    90ec:	aa1503e1 	mov	x1, x21
    90f0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    90f4:	d2800022 	mov	x2, #0x1                   	// #1
    90f8:	f8786803 	ldr	x3, [x0, x24]
    90fc:	aa1403e0 	mov	x0, x20
    9100:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    9104:	39001ffa 	strb	w26, [sp, #7]
    9108:	97ffe942 	bl	3610 <buf_put>
    910c:	f13ffeff 	cmp	x23, #0xfff
    9110:	b9400261 	ldr	w1, [x19]
    9114:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9118:	7100383f 	cmp	w1, #0xe
    911c:	54000160 	b.eq	9148 <fwp_write+0x788>  // b.none
    9120:	7100403f 	cmp	w1, #0x10
    9124:	54001a60 	b.eq	9470 <fwp_write+0xab0>  // b.none
    9128:	7100283f 	cmp	w1, #0xa
    912c:	54002aa0 	b.eq	9680 <fwp_write+0xcc0>  // b.none
    9130:	540014ac 	b.gt	93c4 <fwp_write+0xa04>
    9134:	71000c3f 	cmp	w1, #0x3
    9138:	540029ac 	b.gt	966c <fwp_write+0xcac>
    913c:	d37ffee0 	lsr	x0, x23, #63
    9140:	37f814a1 	tbnz	w1, #31, 93d4 <fwp_write+0xa14>
    9144:	d503201f 	nop
    9148:	34001460 	cbz	w0, 93d4 <fwp_write+0xa14>
    914c:	52800503 	mov	w3, #0x28                  	// #40
    9150:	aa1503e1 	mov	x1, x21
    9154:	aa1403e0 	mov	x0, x20
    9158:	d2800022 	mov	x2, #0x1                   	// #1
    915c:	39001fe3 	strb	w3, [sp, #7]
    9160:	97ffe92c 	bl	3610 <buf_put>
    9164:	aa1303e2 	mov	x2, x19
    9168:	aa1703e1 	mov	x1, x23
    916c:	aa1403e0 	mov	x0, x20
    9170:	52800003 	mov	w3, #0x0                   	// #0
    9174:	97fffe13 	bl	89c0 <fwp_write>
    9178:	52800523 	mov	w3, #0x29                  	// #41
    917c:	aa1503e1 	mov	x1, x21
    9180:	aa1403e0 	mov	x0, x20
    9184:	d2800022 	mov	x2, #0x1                   	// #1
    9188:	39001fe3 	strb	w3, [sp, #7]
    918c:	97ffe921 	bl	3610 <buf_put>
    9190:	f9401780 	ldr	x0, [x28, #40]
    9194:	9100077b 	add	x27, x27, #0x1
    9198:	b8796800 	ldr	w0, [x0, x25]
    919c:	6b1b001f 	cmp	w0, w27
    91a0:	54fffa4c 	b.gt	90e8 <fwp_write+0x728>
    91a4:	f9413bf5 	ldr	x21, [sp, #624]
    91a8:	f9413ff6 	ldr	x22, [sp, #632]
    91ac:	f94143f7 	ldr	x23, [sp, #640]
    91b0:	f94147f8 	ldr	x24, [sp, #648]
    91b4:	f9414bf9 	ldr	x25, [sp, #656]
    91b8:	f9414ffa 	ldr	x26, [sp, #664]
    91bc:	f94153fb 	ldr	x27, [sp, #672]
    91c0:	f94157fc 	ldr	x28, [sp, #680]
    91c4:	17fffe2b 	b	8a70 <fwp_write+0xb0>
    91c8:	52800783 	mov	w3, #0x3c                  	// #60
    91cc:	91001ff3 	add	x19, sp, #0x7
    91d0:	aa1303e1 	mov	x1, x19
    91d4:	d2800022 	mov	x2, #0x1                   	// #1
    91d8:	aa1403e0 	mov	x0, x20
    91dc:	39001fe3 	strb	w3, [sp, #7]
    91e0:	97ffe90c 	bl	3610 <buf_put>
    91e4:	f9400795 	ldr	x21, [x28, #8]
    91e8:	aa1503e0 	mov	x0, x21
    91ec:	97ffe52d 	bl	26a0 <strlen@plt>
    91f0:	aa1503e1 	mov	x1, x21
    91f4:	aa0003e2 	mov	x2, x0
    91f8:	aa1403e0 	mov	x0, x20
    91fc:	97ffe905 	bl	3610 <buf_put>
    9200:	528007c3 	mov	w3, #0x3e                  	// #62
    9204:	aa1303e1 	mov	x1, x19
    9208:	aa1403e0 	mov	x0, x20
    920c:	d2800022 	mov	x2, #0x1                   	// #1
    9210:	39001fe3 	strb	w3, [sp, #7]
    9214:	17fffe12 	b	8a5c <fwp_write+0x9c>
    9218:	f100067f 	cmp	x19, #0x1
    921c:	540025a0 	b.eq	96d0 <fwp_write+0xd10>  // b.none
    9220:	b100067f 	cmn	x19, #0x1
    9224:	54002bc0 	b.eq	979c <fwp_write+0xddc>  // b.none
    9228:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    922c:	910e8021 	add	x1, x1, #0x3a0
    9230:	d2800022 	mov	x2, #0x1                   	// #1
    9234:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9238:	f947f400 	ldr	x0, [x0, #4072]
    923c:	f94127e4 	ldr	x4, [sp, #584]
    9240:	f9400003 	ldr	x3, [x0]
    9244:	eb030084 	subs	x4, x4, x3
    9248:	d2800003 	mov	x3, #0x0                   	// #0
    924c:	54ffebe0 	b.eq	8fc8 <fwp_write+0x608>  // b.none
    9250:	f90143f7 	str	x23, [sp, #640]
    9254:	f90147f8 	str	x24, [sp, #648]
    9258:	f9014bf9 	str	x25, [sp, #656]
    925c:	f9014ffa 	str	x26, [sp, #664]
    9260:	fd015be8 	str	d8, [sp, #688]
    9264:	fd015fe9 	str	d9, [sp, #696]
    9268:	97ffe56a 	bl	2810 <__stack_chk_fail@plt>
    926c:	52800b63 	mov	w3, #0x5b                  	// #91
    9270:	91001ff5 	add	x21, sp, #0x7
    9274:	aa1503e1 	mov	x1, x21
    9278:	aa1403e0 	mov	x0, x20
    927c:	d2800022 	mov	x2, #0x1                   	// #1
    9280:	d0000016 	adrp	x22, b000 <_IO_stdin_used+0x350>
    9284:	911102d6 	add	x22, x22, #0x440
    9288:	39001fe3 	strb	w3, [sp, #7]
    928c:	97ffe8e1 	bl	3610 <buf_put>
    9290:	b4000273 	cbz	x19, 92dc <fwp_write+0x91c>
    9294:	f9400661 	ldr	x1, [x19, #8]
    9298:	aa1403e0 	mov	x0, x20
    929c:	f9401f82 	ldr	x2, [x28, #56]
    92a0:	52800003 	mov	w3, #0x0                   	// #0
    92a4:	97fffdc7 	bl	89c0 <fwp_write>
    92a8:	f9400a73 	ldr	x19, [x19, #16]
    92ac:	b4000193 	cbz	x19, 92dc <fwp_write+0x91c>
    92b0:	aa1603e1 	mov	x1, x22
    92b4:	aa1403e0 	mov	x0, x20
    92b8:	d2800042 	mov	x2, #0x2                   	// #2
    92bc:	97ffe8d5 	bl	3610 <buf_put>
    92c0:	f9400661 	ldr	x1, [x19, #8]
    92c4:	aa1403e0 	mov	x0, x20
    92c8:	f9401f82 	ldr	x2, [x28, #56]
    92cc:	52800003 	mov	w3, #0x0                   	// #0
    92d0:	97fffdbc 	bl	89c0 <fwp_write>
    92d4:	f9400a73 	ldr	x19, [x19, #16]
    92d8:	b5fffed3 	cbnz	x19, 92b0 <fwp_write+0x8f0>
    92dc:	52800ba3 	mov	w3, #0x5d                  	// #93
    92e0:	aa1503e1 	mov	x1, x21
    92e4:	aa1403e0 	mov	x0, x20
    92e8:	d2800022 	mov	x2, #0x1                   	// #1
    92ec:	39001fe3 	strb	w3, [sp, #7]
    92f0:	17fffddb 	b	8a5c <fwp_write+0x9c>
    92f4:	aa1403e0 	mov	x0, x20
    92f8:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    92fc:	d28000c2 	mov	x2, #0x6                   	// #6
    9300:	9110c021 	add	x1, x1, #0x430
    9304:	97ffe8c3 	bl	3610 <buf_put>
    9308:	f9400260 	ldr	x0, [x19]
    930c:	b40004c0 	cbz	x0, 93a4 <fwp_write+0x9e4>
    9310:	910123f5 	add	x21, sp, #0x48
    9314:	91002276 	add	x22, x19, #0x8
    9318:	f90143f7 	str	x23, [sp, #640]
    931c:	d2800017 	mov	x23, #0x0                   	// #0
    9320:	f90147f8 	str	x24, [sp, #648]
    9324:	d0000018 	adrp	x24, b000 <_IO_stdin_used+0x350>
    9328:	9110e318 	add	x24, x24, #0x438
    932c:	f9014bf9 	str	x25, [sp, #656]
    9330:	d0000019 	adrp	x25, b000 <_IO_stdin_used+0x350>
    9334:	91110339 	add	x25, x25, #0x440
    9338:	f9014ffa 	str	x26, [sp, #664]
    933c:	14000005 	b	9350 <fwp_write+0x990>
    9340:	aa1903e1 	mov	x1, x25
    9344:	aa1403e0 	mov	x0, x20
    9348:	d2800042 	mov	x2, #0x2                   	// #2
    934c:	97ffe8b1 	bl	3610 <buf_put>
    9350:	38776ac5 	ldrb	w5, [x22, x23]
    9354:	d2804003 	mov	x3, #0x200                 	// #512
    9358:	aa1803e4 	mov	x4, x24
    935c:	aa0303e1 	mov	x1, x3
    9360:	52800042 	mov	w2, #0x2                   	// #2
    9364:	aa1503e0 	mov	x0, x21
    9368:	910006f7 	add	x23, x23, #0x1
    936c:	97ffe505 	bl	2780 <__snprintf_chk@plt>
    9370:	aa1503e0 	mov	x0, x21
    9374:	97ffe4cb 	bl	26a0 <strlen@plt>
    9378:	aa1503e1 	mov	x1, x21
    937c:	aa0003e2 	mov	x2, x0
    9380:	aa1403e0 	mov	x0, x20
    9384:	97ffe8a3 	bl	3610 <buf_put>
    9388:	f9400260 	ldr	x0, [x19]
    938c:	eb17001f 	cmp	x0, x23
    9390:	54fffd88 	b.hi	9340 <fwp_write+0x980>  // b.pmore
    9394:	f94143f7 	ldr	x23, [sp, #640]
    9398:	f94147f8 	ldr	x24, [sp, #648]
    939c:	f9414bf9 	ldr	x25, [sp, #656]
    93a0:	f9414ffa 	ldr	x26, [sp, #664]
    93a4:	52800ba3 	mov	w3, #0x5d                  	// #93
    93a8:	aa1403e0 	mov	x0, x20
    93ac:	91001fe1 	add	x1, sp, #0x7
    93b0:	d2800022 	mov	x2, #0x1                   	// #1
    93b4:	39001fe3 	strb	w3, [sp, #7]
    93b8:	17fffda9 	b	8a5c <fwp_write+0x9c>
    93bc:	52800fa3 	mov	w3, #0x7d                  	// #125
    93c0:	17fffe44 	b	8cd0 <fwp_write+0x310>
    93c4:	f10002ff 	cmp	x23, #0x0
    93c8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    93cc:	71002c3f 	cmp	w1, #0xb
    93d0:	54ffebc0 	b.eq	9148 <fwp_write+0x788>  // b.none
    93d4:	aa1303e2 	mov	x2, x19
    93d8:	aa1703e1 	mov	x1, x23
    93dc:	aa1403e0 	mov	x0, x20
    93e0:	52800003 	mov	w3, #0x0                   	// #0
    93e4:	97fffd77 	bl	89c0 <fwp_write>
    93e8:	17ffff6a 	b	9190 <fwp_write+0x7d0>
    93ec:	aa1403e0 	mov	x0, x20
    93f0:	91001fe1 	add	x1, sp, #0x7
    93f4:	52800fa3 	mov	w3, #0x7d                  	// #125
    93f8:	d2800022 	mov	x2, #0x1                   	// #1
    93fc:	17fffe38 	b	8cdc <fwp_write+0x31c>
    9400:	a9400281 	ldp	x1, x0, [x20]
    9404:	91000800 	add	x0, x0, #0x2
    9408:	8b160000 	add	x0, x0, x22
    940c:	f9000680 	str	x0, [x20, #8]
    9410:	3820683f 	strb	wzr, [x1, x0]
    9414:	f9413bf5 	ldr	x21, [sp, #624]
    9418:	f9413ff6 	ldr	x22, [sp, #632]
    941c:	f94153fb 	ldr	x27, [sp, #672]
    9420:	f94157fc 	ldr	x28, [sp, #680]
    9424:	17fffd93 	b	8a70 <fwp_write+0xb0>
    9428:	f9400f80 	ldr	x0, [x28, #24]
    942c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9430:	aa1b03e0 	mov	x0, x27
    9434:	97ffe49b 	bl	26a0 <strlen@plt>
    9438:	aa1b03e1 	mov	x1, x27
    943c:	aa0003e2 	mov	x2, x0
    9440:	aa1403e0 	mov	x0, x20
    9444:	97ffe873 	bl	3610 <buf_put>
    9448:	aa1903e1 	mov	x1, x25
    944c:	aa1403e0 	mov	x0, x20
    9450:	d2800062 	mov	x2, #0x3                   	// #3
    9454:	97ffe86f 	bl	3610 <buf_put>
    9458:	17fffe10 	b	8c98 <fwp_write+0x2d8>
    945c:	aa1a03e1 	mov	x1, x26
    9460:	aa1403e0 	mov	x0, x20
    9464:	d2800042 	mov	x2, #0x2                   	// #2
    9468:	97ffe86a 	bl	3610 <buf_put>
    946c:	17fffe09 	b	8c90 <fwp_write+0x2d0>
    9470:	f9400660 	ldr	x0, [x19, #8]
    9474:	b4fffb00 	cbz	x0, 93d4 <fwp_write+0xa14>
    9478:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    947c:	91116021 	add	x1, x1, #0x458
    9480:	97ffe504 	bl	2890 <strcmp@plt>
    9484:	7100001f 	cmp	w0, #0x0
    9488:	1a9f07e0 	cset	w0, ne	// ne = any
    948c:	17ffff2f 	b	9148 <fwp_write+0x788>
    9490:	aa1403e0 	mov	x0, x20
    9494:	d2800042 	mov	x2, #0x2                   	// #2
    9498:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    949c:	91114021 	add	x1, x1, #0x450
    94a0:	97ffe85c 	bl	3610 <buf_put>
    94a4:	91004261 	add	x1, x19, #0x10
    94a8:	aa1403e0 	mov	x0, x20
    94ac:	f9402382 	ldr	x2, [x28, #64]
    94b0:	52800003 	mov	w3, #0x0                   	// #0
    94b4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    94b8:	97fffd42 	bl	89c0 <fwp_write>
    94bc:	17fffd9c 	b	8b2c <fwp_write+0x16c>
    94c0:	1e22c109 	fcvt	d9, s8
    94c4:	910123f5 	add	x21, sp, #0x48
    94c8:	52800033 	mov	w19, #0x1                   	// #1
    94cc:	d503201f 	nop
    94d0:	1e604120 	fmov	d0, d9
    94d4:	2a1303e1 	mov	w1, w19
    94d8:	aa1503e0 	mov	x0, x21
    94dc:	97ffe98e 	bl	3b14 <fwp_format_g.constprop.0>
    94e0:	aa1503e0 	mov	x0, x21
    94e4:	d2800001 	mov	x1, #0x0                   	// #0
    94e8:	97ffe4f6 	bl	28c0 <strtof@plt>
    94ec:	1e202100 	fcmp	s8, s0
    94f0:	54ffdb60 	b.eq	905c <fwp_write+0x69c>  // b.none
    94f4:	11000673 	add	w19, w19, #0x1
    94f8:	71002a7f 	cmp	w19, #0xa
    94fc:	54fffea1 	b.ne	94d0 <fwp_write+0xb10>  // b.any
    9500:	1e604120 	fmov	d0, d9
    9504:	aa1503e0 	mov	x0, x21
    9508:	52800121 	mov	w1, #0x9                   	// #9
    950c:	97ffe982 	bl	3b14 <fwp_format_g.constprop.0>
    9510:	17fffed3 	b	905c <fwp_write+0x69c>
    9514:	d37ef6a1 	lsl	x1, x21, #2
    9518:	b7f81563 	tbnz	x3, #63, 97c4 <fwp_write+0xe04>
    951c:	91002263 	add	x3, x19, #0x8
    9520:	8b010061 	add	x1, x3, x1
    9524:	b9400023 	ldr	w3, [x1]
    9528:	7100081f 	cmp	w0, #0x2
    952c:	2a0303e1 	mov	w1, w3
    9530:	93407c63 	sxtw	x3, w3
    9534:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9538:	17fffe5a 	b	8ea0 <fwp_write+0x4e0>
    953c:	d37ffaa1 	lsl	x1, x21, #1
    9540:	b7f81363 	tbnz	x3, #63, 97ac <fwp_write+0xdec>
    9544:	91002263 	add	x3, x19, #0x8
    9548:	8b010061 	add	x1, x3, x1
    954c:	79400021 	ldrh	w1, [x1]
    9550:	7100041f 	cmp	w0, #0x1
    9554:	93403c23 	sxth	x3, w1
    9558:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    955c:	17fffe51 	b	8ea0 <fwp_write+0x4e0>
    9560:	52800443 	mov	w3, #0x22                  	// #34
    9564:	91001ff5 	add	x21, sp, #0x7
    9568:	91002273 	add	x19, x19, #0x8
    956c:	aa1503e1 	mov	x1, x21
    9570:	aa1403e0 	mov	x0, x20
    9574:	d2800022 	mov	x2, #0x1                   	// #1
    9578:	39001fe3 	strb	w3, [sp, #7]
    957c:	f90143f7 	str	x23, [sp, #640]
    9580:	8b160277 	add	x23, x19, x22
    9584:	f90147f8 	str	x24, [sp, #648]
    9588:	97ffe822 	bl	3610 <buf_put>
    958c:	b4000696 	cbz	x22, 965c <fwp_write+0xc9c>
    9590:	d0000018 	adrp	x24, b000 <_IO_stdin_used+0x350>
    9594:	91100318 	add	x24, x24, #0x400
    9598:	f9014bf9 	str	x25, [sp, #656]
    959c:	d0000019 	adrp	x25, b000 <_IO_stdin_used+0x350>
    95a0:	91108339 	add	x25, x25, #0x420
    95a4:	f9014ffa 	str	x26, [sp, #664]
    95a8:	1400000d 	b	95dc <fwp_write+0xc1c>
    95ac:	710024bf 	cmp	w5, #0x9
    95b0:	54000460 	b.eq	963c <fwp_write+0xc7c>  // b.none
    95b4:	710028bf 	cmp	w5, #0xa
    95b8:	54000a61 	b.ne	9704 <fwp_write+0xd44>  // b.any
    95bc:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    95c0:	aa1403e0 	mov	x0, x20
    95c4:	91104021 	add	x1, x1, #0x410
    95c8:	d2800042 	mov	x2, #0x2                   	// #2
    95cc:	97ffe811 	bl	3610 <buf_put>
    95d0:	91000673 	add	x19, x19, #0x1
    95d4:	eb17027f 	cmp	x19, x23
    95d8:	540003e0 	b.eq	9654 <fwp_write+0xc94>  // b.none
    95dc:	39400265 	ldrb	w5, [x19]
    95e0:	710034bf 	cmp	w5, #0xd
    95e4:	54000180 	b.eq	9614 <fwp_write+0xc54>  // b.none
    95e8:	54fffe29 	b.ls	95ac <fwp_write+0xbec>  // b.plast
    95ec:	710088bf 	cmp	w5, #0x22
    95f0:	540001c0 	b.eq	9628 <fwp_write+0xc68>  // b.none
    95f4:	710170bf 	cmp	w5, #0x5c
    95f8:	54000741 	b.ne	96e0 <fwp_write+0xd20>  // b.any
    95fc:	aa1403e0 	mov	x0, x20
    9600:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    9604:	d2800042 	mov	x2, #0x2                   	// #2
    9608:	91102021 	add	x1, x1, #0x408
    960c:	97ffe801 	bl	3610 <buf_put>
    9610:	17fffff0 	b	95d0 <fwp_write+0xc10>
    9614:	aa1903e1 	mov	x1, x25
    9618:	aa1403e0 	mov	x0, x20
    961c:	d2800042 	mov	x2, #0x2                   	// #2
    9620:	97ffe7fc 	bl	3610 <buf_put>
    9624:	17ffffeb 	b	95d0 <fwp_write+0xc10>
    9628:	aa1803e1 	mov	x1, x24
    962c:	aa1403e0 	mov	x0, x20
    9630:	d2800042 	mov	x2, #0x2                   	// #2
    9634:	97ffe7f7 	bl	3610 <buf_put>
    9638:	17ffffe6 	b	95d0 <fwp_write+0xc10>
    963c:	aa1403e0 	mov	x0, x20
    9640:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    9644:	d2800042 	mov	x2, #0x2                   	// #2
    9648:	91106021 	add	x1, x1, #0x418
    964c:	97ffe7f1 	bl	3610 <buf_put>
    9650:	17ffffe0 	b	95d0 <fwp_write+0xc10>
    9654:	f9414bf9 	ldr	x25, [sp, #656]
    9658:	f9414ffa 	ldr	x26, [sp, #664]
    965c:	aa1503e1 	mov	x1, x21
    9660:	aa1403e0 	mov	x0, x20
    9664:	52800443 	mov	w3, #0x22                  	// #34
    9668:	17fffd9c 	b	8cd8 <fwp_write+0x318>
    966c:	7100103f 	cmp	w1, #0x4
    9670:	54ffeb21 	b.ne	93d4 <fwp_write+0xa14>  // b.any
    9674:	f94006e0 	ldr	x0, [x23, #8]
    9678:	d37ffc00 	lsr	x0, x0, #63
    967c:	17fffeb3 	b	9148 <fwp_write+0x788>
    9680:	710002ff 	cmp	w23, #0x0
    9684:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9688:	17fffeb0 	b	9148 <fwp_write+0x788>
    968c:	528005a1 	mov	w1, #0x2d                  	// #45
    9690:	eb0203e2 	negs	x2, x2
    9694:	da0303e3 	ngc	x3, x3
    9698:	910127e0 	add	x0, sp, #0x49
    969c:	910123f5 	add	x21, sp, #0x48
    96a0:	390123e1 	strb	w1, [sp, #72]
    96a4:	97ffe5bf 	bl	2da0 <fwp_fmt_u128>
    96a8:	17fffe18 	b	8f08 <fwp_write+0x548>
    96ac:	d37ceea1 	lsl	x1, x21, #4
    96b0:	b7f810a3 	tbnz	x3, #63, 98c4 <fwp_write+0xf04>
    96b4:	91002260 	add	x0, x19, #0x8
    96b8:	8b010001 	add	x1, x0, x1
    96bc:	17fffdf9 	b	8ea0 <fwp_write+0x4e0>
    96c0:	f9400a61 	ldr	x1, [x19, #16]
    96c4:	8b010000 	add	x0, x0, x1
    96c8:	f9400001 	ldr	x1, [x0]
    96cc:	17fffdf5 	b	8ea0 <fwp_write+0x4e0>
    96d0:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    96d4:	d2800042 	mov	x2, #0x2                   	// #2
    96d8:	910ea021 	add	x1, x1, #0x3a8
    96dc:	17fffed6 	b	9234 <fwp_write+0x874>
    96e0:	7101fcbf 	cmp	w5, #0x7f
    96e4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    96e8:	540000e9 	b.ls	9704 <fwp_write+0xd44>  // b.plast
    96ec:	aa1503e1 	mov	x1, x21
    96f0:	aa1403e0 	mov	x0, x20
    96f4:	d2800022 	mov	x2, #0x1                   	// #1
    96f8:	39001fe5 	strb	w5, [sp, #7]
    96fc:	97ffe7c5 	bl	3610 <buf_put>
    9700:	17ffffb4 	b	95d0 <fwp_write+0xc10>
    9704:	d2800203 	mov	x3, #0x10                  	// #16
    9708:	d0000004 	adrp	x4, b000 <_IO_stdin_used+0x350>
    970c:	aa0303e1 	mov	x1, x3
    9710:	9110a084 	add	x4, x4, #0x428
    9714:	910123f6 	add	x22, sp, #0x48
    9718:	52800042 	mov	w2, #0x2                   	// #2
    971c:	aa1603e0 	mov	x0, x22
    9720:	97ffe418 	bl	2780 <__snprintf_chk@plt>
    9724:	aa1603e0 	mov	x0, x22
    9728:	97ffe3de 	bl	26a0 <strlen@plt>
    972c:	aa1603e1 	mov	x1, x22
    9730:	aa0003e2 	mov	x2, x0
    9734:	aa1403e0 	mov	x0, x20
    9738:	97ffe7b6 	bl	3610 <buf_put>
    973c:	17ffffa5 	b	95d0 <fwp_write+0xc10>
    9740:	1e604100 	fmov	d0, d8
    9744:	aa1503e0 	mov	x0, x21
    9748:	52800221 	mov	w1, #0x11                  	// #17
    974c:	97ffe8f2 	bl	3b14 <fwp_format_g.constprop.0>
    9750:	17fffe43 	b	905c <fwp_write+0x69c>
    9754:	b9401040 	ldr	w0, [x2, #16]
    9758:	350003c0 	cbnz	w0, 97d0 <fwp_write+0xe10>
    975c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9760:	f947f400 	ldr	x0, [x0, #4072]
    9764:	f94127e2 	ldr	x2, [sp, #584]
    9768:	f9400001 	ldr	x1, [x0]
    976c:	eb010042 	subs	x2, x2, x1
    9770:	d2800001 	mov	x1, #0x0                   	// #0
    9774:	54ffd721 	b.ne	9258 <fwp_write+0x898>  // b.any
    9778:	f9413bf5 	ldr	x21, [sp, #624]
    977c:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    9780:	f9413ff6 	ldr	x22, [sp, #632]
    9784:	aa1403e0 	mov	x0, x20
    9788:	f94143f7 	ldr	x23, [sp, #640]
    978c:	9111e021 	add	x1, x1, #0x478
    9790:	f94147f8 	ldr	x24, [sp, #648]
    9794:	d2800042 	mov	x2, #0x2                   	// #2
    9798:	17fffd0e 	b	8bd0 <fwp_write+0x210>
    979c:	d0000001 	adrp	x1, b000 <_IO_stdin_used+0x350>
    97a0:	d2800042 	mov	x2, #0x2                   	// #2
    97a4:	910ec021 	add	x1, x1, #0x3b0
    97a8:	17fffea3 	b	9234 <fwp_write+0x874>
    97ac:	f9400a63 	ldr	x3, [x19, #16]
    97b0:	8b030021 	add	x1, x1, x3
    97b4:	17ffff66 	b	954c <fwp_write+0xb8c>
    97b8:	f9400a61 	ldr	x1, [x19, #16]
    97bc:	8b0102a1 	add	x1, x21, x1
    97c0:	17fffdb3 	b	8e8c <fwp_write+0x4cc>
    97c4:	f9400a63 	ldr	x3, [x19, #16]
    97c8:	8b030021 	add	x1, x1, x3
    97cc:	17ffff56 	b	9524 <fwp_write+0xb64>
    97d0:	b9404840 	ldr	w0, [x2, #72]
    97d4:	91001ff5 	add	x21, sp, #0x7
    97d8:	34ffa360 	cbz	w0, 8c44 <fwp_write+0x284>
    97dc:	52800503 	mov	w3, #0x28                  	// #40
    97e0:	aa1403e0 	mov	x0, x20
    97e4:	aa1503e1 	mov	x1, x21
    97e8:	d2800022 	mov	x2, #0x1                   	// #1
    97ec:	39001fe3 	strb	w3, [sp, #7]
    97f0:	97ffe788 	bl	3610 <buf_put>
    97f4:	b9401380 	ldr	w0, [x28, #16]
    97f8:	52800038 	mov	w24, #0x1                   	// #1
    97fc:	7100001f 	cmp	w0, #0x0
    9800:	54ffa36c 	b.gt	8c6c <fwp_write+0x2ac>
    9804:	17fffd32 	b	8ccc <fwp_write+0x30c>
    9808:	f9014bf9 	str	x25, [sp, #656]
    980c:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10f40>
    9810:	f9014ffa 	str	x26, [sp, #664]
    9814:	f9400676 	ldr	x22, [x19, #8]
    9818:	91104333 	add	x19, x25, #0x410
    981c:	91002273 	add	x19, x19, #0x8
    9820:	937ffed8 	asr	x24, x22, #63
    9824:	aa1802c0 	orr	x0, x22, x24
    9828:	b5000320 	cbnz	x0, 988c <fwp_write+0xecc>
    982c:	110006b5 	add	w21, w21, #0x1
    9830:	710016bf 	cmp	w21, #0x5
    9834:	54ffffc1 	b.ne	982c <fwp_write+0xe6c>  // b.any
    9838:	b7f80578 	tbnz	x24, #63, 98e4 <fwp_write+0xf24>
    983c:	910023f3 	add	x19, sp, #0x8
    9840:	aa1603e2 	mov	x2, x22
    9844:	aa1303e0 	mov	x0, x19
    9848:	d2800003 	mov	x3, #0x0                   	// #0
    984c:	97ffe555 	bl	2da0 <fwp_fmt_u128>
    9850:	910123f5 	add	x21, sp, #0x48
    9854:	d0000003 	adrp	x3, b000 <_IO_stdin_used+0x350>
    9858:	aa1303e4 	mov	x4, x19
    985c:	aa1503e0 	mov	x0, x21
    9860:	9111c063 	add	x3, x3, #0x470
    9864:	d2804002 	mov	x2, #0x200                 	// #512
    9868:	52800041 	mov	w1, #0x2                   	// #2
    986c:	97ffe391 	bl	26b0 <__sprintf_chk@plt>
    9870:	aa1503e0 	mov	x0, x21
    9874:	97ffe38b 	bl	26a0 <strlen@plt>
    9878:	aa1503e1 	mov	x1, x21
    987c:	aa0003e2 	mov	x2, x0
    9880:	aa1403e0 	mov	x0, x20
    9884:	97ffe763 	bl	3610 <buf_put>
    9888:	17fffe47 	b	91a4 <fwp_write+0x7e4>
    988c:	f9400277 	ldr	x23, [x19]
    9890:	aa1603e0 	mov	x0, x22
    9894:	aa1803e1 	mov	x1, x24
    9898:	aa1703e2 	mov	x2, x23
    989c:	937ffefa 	asr	x26, x23, #63
    98a0:	aa1a03e3 	mov	x3, x26
    98a4:	9400041b 	bl	a910 <__modti3>
    98a8:	aa010000 	orr	x0, x0, x1
    98ac:	b40002c0 	cbz	x0, 9904 <fwp_write+0xf44>
    98b0:	110006b5 	add	w21, w21, #0x1
    98b4:	91004273 	add	x19, x19, #0x10
    98b8:	710016bf 	cmp	w21, #0x5
    98bc:	54fffe81 	b.ne	988c <fwp_write+0xecc>  // b.any
    98c0:	17ffffde 	b	9838 <fwp_write+0xe78>
    98c4:	f9400a60 	ldr	x0, [x19, #16]
    98c8:	8b000021 	add	x1, x1, x0
    98cc:	17fffd75 	b	8ea0 <fwp_write+0x4e0>
    98d0:	528c29c0 	mov	w0, #0x614e                	// #24910
    98d4:	910123f5 	add	x21, sp, #0x48
    98d8:	72a009c0 	movk	w0, #0x4e, lsl #16
    98dc:	b9004be0 	str	w0, [sp, #72]
    98e0:	17fffda2 	b	8f68 <fwp_write+0x5a8>
    98e4:	528005a1 	mov	w1, #0x2d                  	// #45
    98e8:	eb1603e2 	negs	x2, x22
    98ec:	da1803e3 	ngc	x3, x24
    98f0:	910027e0 	add	x0, sp, #0x9
    98f4:	910023f3 	add	x19, sp, #0x8
    98f8:	390023e1 	strb	w1, [sp, #8]
    98fc:	97ffe529 	bl	2da0 <fwp_fmt_u128>
    9900:	17ffffd4 	b	9850 <fwp_write+0xe90>
    9904:	aa1703e2 	mov	x2, x23
    9908:	aa1a03e3 	mov	x3, x26
    990c:	aa1603e0 	mov	x0, x22
    9910:	aa1803e1 	mov	x1, x24
    9914:	9400031f 	bl	a590 <__divti3>
    9918:	aa0003e2 	mov	x2, x0
    991c:	aa0103e3 	mov	x3, x1
    9920:	b7f80201 	tbnz	x1, #63, 9960 <fwp_write+0xfa0>
    9924:	910023f3 	add	x19, sp, #0x8
    9928:	aa1303e0 	mov	x0, x19
    992c:	97ffe51d 	bl	2da0 <fwp_fmt_u128>
    9930:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9934:	91104339 	add	x25, x25, #0x410
    9938:	910123f5 	add	x21, sp, #0x48
    993c:	aa1303e4 	mov	x4, x19
    9940:	aa1503e0 	mov	x0, x21
    9944:	d0000003 	adrp	x3, b000 <_IO_stdin_used+0x350>
    9948:	f8616b25 	ldr	x5, [x25, x1]
    994c:	9111a063 	add	x3, x3, #0x468
    9950:	d2804002 	mov	x2, #0x200                 	// #512
    9954:	52800041 	mov	w1, #0x2                   	// #2
    9958:	97ffe356 	bl	26b0 <__sprintf_chk@plt>
    995c:	17ffffc5 	b	9870 <fwp_write+0xeb0>
    9960:	528005a4 	mov	w4, #0x2d                  	// #45
    9964:	eb0003e2 	negs	x2, x0
    9968:	da0103e3 	ngc	x3, x1
    996c:	910027e0 	add	x0, sp, #0x9
    9970:	910023f3 	add	x19, sp, #0x8
    9974:	390023e4 	strb	w4, [sp, #8]
    9978:	97ffe50a 	bl	2da0 <fwp_fmt_u128>
    997c:	17ffffed 	b	9930 <fwp_write+0xf70>
    9980:	f9013bf5 	str	x21, [sp, #624]
    9984:	f9013ff6 	str	x22, [sp, #632]
    9988:	f90143f7 	str	x23, [sp, #640]
    998c:	f90147f8 	str	x24, [sp, #648]
    9990:	f9014bf9 	str	x25, [sp, #656]
    9994:	f9014ffa 	str	x26, [sp, #664]
    9998:	f90153fb 	str	x27, [sp, #672]
    999c:	f90157fc 	str	x28, [sp, #680]
    99a0:	fd015be8 	str	d8, [sp, #688]
    99a4:	fd015fe9 	str	d9, [sp, #696]
    99a8:	97ffe39a 	bl	2810 <__stack_chk_fail@plt>
    99ac:	d503201f 	nop

00000000000099b0 <fwp_main_thread>:
    99b0:	d105c3ff 	sub	sp, sp, #0x170
    99b4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    99b8:	f947f400 	ldr	x0, [x0, #4072]
    99bc:	a9117bfd 	stp	x29, x30, [sp, #272]
    99c0:	910443fd 	add	x29, sp, #0x110
    99c4:	a9135bf5 	stp	x21, x22, [sp, #304]
    99c8:	90000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    99cc:	9118c2a1 	add	x1, x21, #0x630
    99d0:	a91253f3 	stp	x19, x20, [sp, #288]
    99d4:	a91463f7 	stp	x23, x24, [sp, #320]
    99d8:	b953a421 	ldr	w1, [x1, #5028]
    99dc:	a9156bf9 	stp	x25, x26, [sp, #336]
    99e0:	a91673fb 	stp	x27, x28, [sp, #352]
    99e4:	f9400002 	ldr	x2, [x0]
    99e8:	f90087e2 	str	x2, [sp, #264]
    99ec:	d2800002 	mov	x2, #0x0                   	// #0
    99f0:	340052a1 	cbz	w1, a444 <fwp_main_thread+0xa94>
    99f4:	9118c2a0 	add	x0, x21, #0x630
    99f8:	b953a800 	ldr	w0, [x0, #5032]
    99fc:	350051c0 	cbnz	w0, a434 <fwp_main_thread+0xa84>
    9a00:	f00000b4 	adrp	x20, 20000 <__data_start>
    9a04:	f00000a2 	adrp	x2, 20000 <__data_start>
    9a08:	9101429b 	add	x27, x20, #0x50
    9a0c:	91114042 	add	x2, x2, #0x450
    9a10:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9a14:	d2a00024 	mov	x4, #0x10000               	// #65536
    9a18:	9100c3e0 	add	x0, sp, #0x30
    9a1c:	910063fa 	add	x26, sp, #0x18
    9a20:	d2800001 	mov	x1, #0x0                   	// #0
    9a24:	f90003e0 	str	x0, [sp]
    9a28:	f9001be2 	str	x2, [sp, #48]
    9a2c:	b9003bff 	str	wzr, [sp, #56]
    9a30:	f90023e4 	str	x4, [sp, #64]
    9a34:	a90a0f7a 	stp	x26, x3, [x27, #160]
    9a38:	97ffe30e 	bl	2670 <sigaltstack@plt>
    9a3c:	35005580 	cbnz	w0, a4ec <fwp_main_thread+0xb3c>
    9a40:	4f000400 	movi	v0.4s, #0x0
    9a44:	9101e3e0 	add	x0, sp, #0x78
    9a48:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    9a4c:	9100c021 	add	x1, x1, #0x30
    9a50:	f9003be1 	str	x1, [sp, #112]
    9a54:	52800082 	mov	w2, #0x4                   	// #4
    9a58:	72a10002 	movk	w2, #0x800, lsl #16
    9a5c:	9101c3f6 	add	x22, sp, #0x70
    9a60:	3d802000 	str	q0, [x0, #128]
    9a64:	b900fbe2 	str	w2, [sp, #248]
    9a68:	ad000000 	stp	q0, q0, [x0]
    9a6c:	ad010000 	stp	q0, q0, [x0, #32]
    9a70:	ad020000 	stp	q0, q0, [x0, #64]
    9a74:	ad030000 	stp	q0, q0, [x0, #96]
    9a78:	97ffe356 	bl	27d0 <sigemptyset@plt>
    9a7c:	35005380 	cbnz	w0, a4ec <fwp_main_thread+0xb3c>
    9a80:	aa1603e1 	mov	x1, x22
    9a84:	d2800002 	mov	x2, #0x0                   	// #0
    9a88:	52800160 	mov	w0, #0xb                   	// #11
    9a8c:	97ffe369 	bl	2830 <sigaction@plt>
    9a90:	350052e0 	cbnz	w0, a4ec <fwp_main_thread+0xb3c>
    9a94:	aa1603e1 	mov	x1, x22
    9a98:	d2800002 	mov	x2, #0x0                   	// #0
    9a9c:	528000e0 	mov	w0, #0x7                   	// #7
    9aa0:	97ffe364 	bl	2830 <sigaction@plt>
    9aa4:	35005240 	cbnz	w0, a4ec <fwp_main_thread+0xb3c>
    9aa8:	9118c2bc 	add	x28, x21, #0x630
    9aac:	52800038 	mov	w24, #0x1                   	// #1
    9ab0:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9ab4:	910cc000 	add	x0, x0, #0x330
    9ab8:	b9013378 	str	w24, [x27, #304]
    9abc:	fd4a1380 	ldr	d0, [x28, #5152]
    9ac0:	7e61d800 	ucvtf	d0, d0
    9ac4:	fd00a760 	str	d0, [x27, #328]
    9ac8:	9400046e 	bl	ac80 <atexit>
    9acc:	350050a0 	cbnz	w0, a4e0 <fwp_main_thread+0xb30>
    9ad0:	b943cb60 	ldr	w0, [x27, #968]
    9ad4:	34002180 	cbz	w0, 9f04 <fwp_main_thread+0x554>
    9ad8:	91014297 	add	x23, x20, #0x50
    9adc:	f9404ef6 	ldr	x22, [x23, #152]
    9ae0:	b4000bd6 	cbz	x22, 9c58 <fwp_main_thread+0x2a8>
    9ae4:	aa1603f3 	mov	x19, x22
    9ae8:	910102d9 	add	x25, x22, #0x40
    9aec:	39414ada 	ldrb	w26, [x22, #82]
    9af0:	52800038 	mov	w24, #0x1                   	// #1
    9af4:	39014ad8 	strb	w24, [x22, #82]
    9af8:	f94016c0 	ldr	x0, [x22, #40]
    9afc:	b4000620 	cbz	x0, 9bc0 <fwp_main_thread+0x210>
    9b00:	f94032c1 	ldr	x1, [x22, #96]
    9b04:	394146c0 	ldrb	w0, [x22, #81]
    9b08:	b4000de1 	cbz	x1, 9cc4 <fwp_main_thread+0x314>
    9b0c:	36000ca0 	tbz	w0, #0, 9ca0 <fwp_main_thread+0x2f0>
    9b10:	39414a62 	ldrb	w2, [x19, #82]
    9b14:	f94022c1 	ldr	x1, [x22, #64]
    9b18:	37001022 	tbnz	w2, #0, 9d1c <fwp_main_thread+0x36c>
    9b1c:	f9403260 	ldr	x0, [x19, #96]
    9b20:	a911fe79 	stp	x25, xzr, [x19, #280]
    9b24:	f9009661 	str	x1, [x19, #296]
    9b28:	b4000041 	cbz	x1, 9b30 <fwp_main_thread+0x180>
    9b2c:	f9009033 	str	x19, [x1, #288]
    9b30:	f90022d3 	str	x19, [x22, #64]
    9b34:	b4000100 	cbz	x0, 9b54 <fwp_main_thread+0x1a4>
    9b38:	f94096e1 	ldr	x1, [x23, #296]
    9b3c:	39015678 	strb	w24, [x19, #85]
    9b40:	f9003660 	str	x0, [x19, #104]
    9b44:	a910867f 	stp	xzr, x1, [x19, #264]
    9b48:	b4000041 	cbz	x1, 9b50 <fwp_main_thread+0x1a0>
    9b4c:	f9008433 	str	x19, [x1, #264]
    9b50:	f90096f3 	str	x19, [x23, #296]
    9b54:	39015a7f 	strb	wzr, [x19, #86]
    9b58:	97fff393 	bl	69a4 <fwp_block>
    9b5c:	f9408e62 	ldr	x2, [x19, #280]
    9b60:	b4000142 	cbz	x2, 9b88 <fwp_main_thread+0x1d8>
    9b64:	a9520261 	ldp	x1, x0, [x19, #288]
    9b68:	b4000d61 	cbz	x1, 9d14 <fwp_main_thread+0x364>
    9b6c:	f9009420 	str	x0, [x1, #296]
    9b70:	f9409660 	ldr	x0, [x19, #296]
    9b74:	b4000040 	cbz	x0, 9b7c <fwp_main_thread+0x1cc>
    9b78:	f9009001 	str	x1, [x0, #288]
    9b7c:	91080260 	add	x0, x19, #0x200
    9b80:	f900967f 	str	xzr, [x19, #296]
    9b84:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9b88:	39415660 	ldrb	w0, [x19, #85]
    9b8c:	f9404ee1 	ldr	x1, [x23, #152]
    9b90:	36000be0 	tbz	w0, #0, 9d0c <fwp_main_thread+0x35c>
    9b94:	a9508262 	ldp	x2, x0, [x19, #264]
    9b98:	b4000ce2 	cbz	x2, 9d34 <fwp_main_thread+0x384>
    9b9c:	f9008840 	str	x0, [x2, #272]
    9ba0:	b4000040 	cbz	x0, 9ba8 <fwp_main_thread+0x1f8>
    9ba4:	f9008402 	str	x2, [x0, #264]
    9ba8:	91080260 	add	x0, x19, #0x200
    9bac:	3901567f 	strb	wzr, [x19, #85]
    9bb0:	aa0103f3 	mov	x19, x1
    9bb4:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9bb8:	f94016c0 	ldr	x0, [x22, #40]
    9bbc:	b5fffa20 	cbnz	x0, 9b00 <fwp_main_thread+0x150>
    9bc0:	91014280 	add	x0, x20, #0x50
    9bc4:	39014ada 	strb	w26, [x22, #82]
    9bc8:	f941d400 	ldr	x0, [x0, #936]
    9bcc:	b40004c0 	cbz	x0, 9c64 <fwp_main_thread+0x2b4>
    9bd0:	91014280 	add	x0, x20, #0x50
    9bd4:	f941f001 	ldr	x1, [x0, #992]
    9bd8:	b903d81f 	str	wzr, [x0, #984]
    9bdc:	eb13003f 	cmp	x1, x19
    9be0:	540005e1 	b.ne	9c9c <fwp_main_thread+0x2ec>  // b.any
    9be4:	b4000b73 	cbz	x19, 9d50 <fwp_main_thread+0x3a0>
    9be8:	91014280 	add	x0, x20, #0x50
    9bec:	52800021 	mov	w1, #0x1                   	// #1
    9bf0:	39014a61 	strb	w1, [x19, #82]
    9bf4:	f941c005 	ldr	x5, [x0, #896]
    9bf8:	b4000ac5 	cbz	x5, 9d50 <fwp_main_thread+0x3a0>
    9bfc:	394140a0 	ldrb	w0, [x5, #80]
    9c00:	37000060 	tbnz	w0, #0, 9c0c <fwp_main_thread+0x25c>
    9c04:	aa0503e0 	mov	x0, x5
    9c08:	97ffe69a 	bl	3670 <fwp_cancel_tree.part.0>
    9c0c:	f9409ca5 	ldr	x5, [x5, #312]
    9c10:	b5ffff65 	cbnz	x5, 9bfc <fwp_main_thread+0x24c>
    9c14:	91014296 	add	x22, x20, #0x50
    9c18:	52800037 	mov	w23, #0x1                   	// #1
    9c1c:	f9402a60 	ldr	x0, [x19, #80]
    9c20:	f2001c1f 	tst	x0, #0xff000000ff
    9c24:	540000e1 	b.ne	9c40 <fwp_main_thread+0x290>  // b.any
    9c28:	f94062c0 	ldr	x0, [x22, #192]
    9c2c:	39015277 	strb	w23, [x19, #84]
    9c30:	f900827f 	str	xzr, [x19, #256]
    9c34:	b4000840 	cbz	x0, 9d3c <fwp_main_thread+0x38c>
    9c38:	f9008013 	str	x19, [x0, #256]
    9c3c:	f90062d3 	str	x19, [x22, #192]
    9c40:	97fff359 	bl	69a4 <fwp_block>
    9c44:	97fff2eb 	bl	67f0 <fwp_free_zombie>
    9c48:	f941c2c0 	ldr	x0, [x22, #896]
    9c4c:	b4000820 	cbz	x0, 9d50 <fwp_main_thread+0x3a0>
    9c50:	f941f2d3 	ldr	x19, [x22, #992]
    9c54:	17fffff2 	b	9c1c <fwp_main_thread+0x26c>
    9c58:	f941d6e0 	ldr	x0, [x23, #936]
    9c5c:	b5000740 	cbnz	x0, 9d44 <fwp_main_thread+0x394>
    9c60:	d2800013 	mov	x19, #0x0                   	// #0
    9c64:	91014296 	add	x22, x20, #0x50
    9c68:	f941dec0 	ldr	x0, [x22, #952]
    9c6c:	b5fffb20 	cbnz	x0, 9bd0 <fwp_main_thread+0x220>
    9c70:	f941d2c0 	ldr	x0, [x22, #928]
    9c74:	97ffebe7 	bl	4c10 <fwp_mem_free>
    9c78:	f901d2df 	str	xzr, [x22, #928]
    9c7c:	f901dadf 	str	xzr, [x22, #944]
    9c80:	f941f2c0 	ldr	x0, [x22, #992]
    9c84:	b4004433 	cbz	x19, a508 <fwp_main_thread+0xb58>
    9c88:	f900567f 	str	xzr, [x19, #168]
    9c8c:	f9005e7f 	str	xzr, [x19, #184]
    9c90:	b903dadf 	str	wzr, [x22, #984]
    9c94:	eb13001f 	cmp	x0, x19
    9c98:	54fffa80 	b.eq	9be8 <fwp_main_thread+0x238>  // b.none
    9c9c:	97ffe2f1 	bl	2860 <abort@plt>
    9ca0:	97ffe718 	bl	3900 <fwp_now_ns>
    9ca4:	f94032c1 	ldr	x1, [x22, #96]
    9ca8:	eb01001f 	cmp	x0, x1
    9cac:	540000ab 	b.lt	9cc0 <fwp_main_thread+0x310>  // b.tstop
    9cb0:	394142c0 	ldrb	w0, [x22, #80]
    9cb4:	37000060 	tbnz	w0, #0, 9cc0 <fwp_main_thread+0x310>
    9cb8:	aa1603e0 	mov	x0, x22
    9cbc:	97ffe66d 	bl	3670 <fwp_cancel_tree.part.0>
    9cc0:	394146c0 	ldrb	w0, [x22, #81]
    9cc4:	39414a62 	ldrb	w2, [x19, #82]
    9cc8:	3707f260 	tbnz	w0, #0, 9b14 <fwp_main_thread+0x164>
    9ccc:	f94032c0 	ldr	x0, [x22, #96]
    9cd0:	370001a2 	tbnz	w2, #0, 9d04 <fwp_main_thread+0x354>
    9cd4:	f9403261 	ldr	x1, [x19, #96]
    9cd8:	b4000161 	cbz	x1, 9d04 <fwp_main_thread+0x354>
    9cdc:	b4003d60 	cbz	x0, a488 <fwp_main_thread+0xad8>
    9ce0:	eb01001f 	cmp	x0, x1
    9ce4:	9a81d000 	csel	x0, x0, x1, le
    9ce8:	f94022c1 	ldr	x1, [x22, #64]
    9cec:	a911fe79 	stp	x25, xzr, [x19, #280]
    9cf0:	f9009661 	str	x1, [x19, #296]
    9cf4:	b4000041 	cbz	x1, 9cfc <fwp_main_thread+0x34c>
    9cf8:	f9009033 	str	x19, [x1, #288]
    9cfc:	f90022d3 	str	x19, [x22, #64]
    9d00:	17ffff8e 	b	9b38 <fwp_main_thread+0x188>
    9d04:	f94022c1 	ldr	x1, [x22, #64]
    9d08:	17ffff86 	b	9b20 <fwp_main_thread+0x170>
    9d0c:	aa0103f3 	mov	x19, x1
    9d10:	17ffff7a 	b	9af8 <fwp_main_thread+0x148>
    9d14:	f9000040 	str	x0, [x2]
    9d18:	17ffff97 	b	9b74 <fwp_main_thread+0x1c4>
    9d1c:	a911fe79 	stp	x25, xzr, [x19, #280]
    9d20:	f9009661 	str	x1, [x19, #296]
    9d24:	b4000041 	cbz	x1, 9d2c <fwp_main_thread+0x37c>
    9d28:	f9009033 	str	x19, [x1, #288]
    9d2c:	f90022d3 	str	x19, [x22, #64]
    9d30:	17ffff89 	b	9b54 <fwp_main_thread+0x1a4>
    9d34:	f90096e0 	str	x0, [x23, #296]
    9d38:	17ffff9a 	b	9ba0 <fwp_main_thread+0x1f0>
    9d3c:	f90066d3 	str	x19, [x22, #200]
    9d40:	17ffffbf 	b	9c3c <fwp_main_thread+0x28c>
    9d44:	f941f2e0 	ldr	x0, [x23, #992]
    9d48:	b903daff 	str	wzr, [x23, #984]
    9d4c:	b5fffa80 	cbnz	x0, 9c9c <fwp_main_thread+0x2ec>
    9d50:	91014297 	add	x23, x20, #0x50
    9d54:	97fff2a7 	bl	67f0 <fwp_free_zombie>
    9d58:	f94066e0 	ldr	x0, [x23, #200]
    9d5c:	b5fffa00 	cbnz	x0, 9c9c <fwp_main_thread+0x2ec>
    9d60:	f94096e0 	ldr	x0, [x23, #296]
    9d64:	b5fff9c0 	cbnz	x0, 9c9c <fwp_main_thread+0x2ec>
    9d68:	b94172e0 	ldr	w0, [x23, #368]
    9d6c:	340001c0 	cbz	w0, 9da4 <fwp_main_thread+0x3f4>
    9d70:	93407c16 	sxtw	x22, w0
    9d74:	51000400 	sub	w0, w0, #0x1
    9d78:	d1000ad6 	sub	x22, x22, #0x2
    9d7c:	910602f8 	add	x24, x23, #0x180
    9d80:	cb2042d6 	sub	x22, x22, w0, uxtw
    9d84:	93407c13 	sxtw	x19, w0
    9d88:	f8737b00 	ldr	x0, [x24, x19, lsl #3]
    9d8c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    9d90:	b90172f3 	str	w19, [x23, #368]
    9d94:	d1000673 	sub	x19, x19, #0x1
    9d98:	97ffe2e6 	bl	2930 <munmap@plt>
    9d9c:	eb1302df 	cmp	x22, x19
    9da0:	54ffff41 	b.ne	9d88 <fwp_main_thread+0x3d8>  // b.any
    9da4:	f00000b3 	adrp	x19, 20000 <__data_start>
    9da8:	91004260 	add	x0, x19, #0x10
    9dac:	b9402800 	ldr	w0, [x0, #40]
    9db0:	37f80040 	tbnz	w0, #31, 9db8 <fwp_main_thread+0x408>
    9db4:	97ffe29b 	bl	2820 <close@plt>
    9db8:	91014280 	add	x0, x20, #0x50
    9dbc:	91004261 	add	x1, x19, #0x10
    9dc0:	12800002 	mov	w2, #0xffffffff            	// #-1
    9dc4:	d2800013 	mov	x19, #0x0                   	// #0
    9dc8:	f941f417 	ldr	x23, [x0, #1000]
    9dcc:	b9002822 	str	w2, [x1, #40]
    9dd0:	f941f816 	ldr	x22, [x0, #1008]
    9dd4:	b4000177 	cbz	x23, 9e00 <fwp_main_thread+0x450>
    9dd8:	f8737ac0 	ldr	x0, [x22, x19, lsl #3]
    9ddc:	b40000c0 	cbz	x0, 9df4 <fwp_main_thread+0x444>
    9de0:	f9400001 	ldr	x1, [x0]
    9de4:	b5fff5c1 	cbnz	x1, 9c9c <fwp_main_thread+0x2ec>
    9de8:	f9400401 	ldr	x1, [x0, #8]
    9dec:	b5fff581 	cbnz	x1, 9c9c <fwp_main_thread+0x2ec>
    9df0:	97ffeb88 	bl	4c10 <fwp_mem_free>
    9df4:	91000673 	add	x19, x19, #0x1
    9df8:	eb17027f 	cmp	x19, x23
    9dfc:	54fffee1 	b.ne	9dd8 <fwp_main_thread+0x428>  // b.any
    9e00:	aa1603e0 	mov	x0, x22
    9e04:	97ffeb83 	bl	4c10 <fwp_mem_free>
    9e08:	91014280 	add	x0, x20, #0x50
    9e0c:	f941f013 	ldr	x19, [x0, #992]
    9e10:	f901f41f 	str	xzr, [x0, #1000]
    9e14:	f901f81f 	str	xzr, [x0, #1008]
    9e18:	b40001f3 	cbz	x19, 9e54 <fwp_main_thread+0x4a4>
    9e1c:	f9401661 	ldr	x1, [x19, #40]
    9e20:	b5fff3e1 	cbnz	x1, 9c9c <fwp_main_thread+0x2ec>
    9e24:	f9405661 	ldr	x1, [x19, #168]
    9e28:	b5fff3a1 	cbnz	x1, 9c9c <fwp_main_thread+0x2ec>
    9e2c:	f941d401 	ldr	x1, [x0, #936]
    9e30:	b5fff361 	cbnz	x1, 9c9c <fwp_main_thread+0x2ec>
    9e34:	f941dc00 	ldr	x0, [x0, #952]
    9e38:	b5fff320 	cbnz	x0, 9c9c <fwp_main_thread+0x2ec>
    9e3c:	d2823a02 	mov	x2, #0x11d0                	// #4560
    9e40:	f0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    9e44:	91114000 	add	x0, x0, #0x450
    9e48:	97ffe266 	bl	27e0 <memset@plt>
    9e4c:	aa1303e0 	mov	x0, x19
    9e50:	97ffeb70 	bl	4c10 <fwp_mem_free>
    9e54:	91014286 	add	x6, x20, #0x50
    9e58:	9118c2b5 	add	x21, x21, #0x630
    9e5c:	3dc01682 	ldr	q2, [x20, #80]
    9e60:	52800041 	mov	w1, #0x2                   	// #2
    9e64:	3dc004c1 	ldr	q1, [x6, #16]
    9e68:	d0000002 	adrp	x2, b000 <_IO_stdin_used+0x350>
    9e6c:	fd4a12a0 	ldr	d0, [x21, #5152]
    9e70:	9113a042 	add	x2, x2, #0x4e8
    9e74:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    9e78:	fd40a4c1 	ldr	d1, [x6, #328]
    9e7c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9e80:	f947e800 	ldr	x0, [x0, #4048]
    9e84:	7e61d800 	ucvtf	d0, d0
    9e88:	a95390c3 	ldp	x3, x4, [x6, #312]
    9e8c:	f9004cdf 	str	xzr, [x6, #152]
    9e90:	f9400000 	ldr	x0, [x0]
    9e94:	1e613801 	fsub	d1, d0, d1
    9e98:	f940acc5 	ldr	x5, [x6, #344]
    9e9c:	b90130df 	str	wzr, [x6, #304]
    9ea0:	5ef1b842 	addp	d2, v2.2d
    9ea4:	fd40a8c0 	ldr	d0, [x6, #336]
    9ea8:	f901f0df 	str	xzr, [x6, #992]
    9eac:	fd0058c2 	str	d2, [x6, #176]
    9eb0:	97ffe274 	bl	2880 <__fprintf_chk@plt>
    9eb4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9eb8:	f947ec00 	ldr	x0, [x0, #4056]
    9ebc:	f9400000 	ldr	x0, [x0]
    9ec0:	97ffe2a0 	bl	2940 <fflush@plt>
    9ec4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9ec8:	f947f400 	ldr	x0, [x0, #4072]
    9ecc:	f94087e2 	ldr	x2, [sp, #264]
    9ed0:	f9400001 	ldr	x1, [x0]
    9ed4:	eb010042 	subs	x2, x2, x1
    9ed8:	d2800001 	mov	x1, #0x0                   	// #0
    9edc:	540030e1 	b.ne	a4f8 <fwp_main_thread+0xb48>  // b.any
    9ee0:	a9517bfd 	ldp	x29, x30, [sp, #272]
    9ee4:	d2800000 	mov	x0, #0x0                   	// #0
    9ee8:	a95253f3 	ldp	x19, x20, [sp, #288]
    9eec:	a9535bf5 	ldp	x21, x22, [sp, #304]
    9ef0:	a95463f7 	ldp	x23, x24, [sp, #320]
    9ef4:	a9556bf9 	ldp	x25, x26, [sp, #336]
    9ef8:	a95673fb 	ldp	x27, x28, [sp, #352]
    9efc:	9105c3ff 	add	sp, sp, #0x170
    9f00:	d65f03c0 	ret
    9f04:	f941cb62 	ldr	x2, [x27, #912]
    9f08:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9f0c:	913b4021 	add	x1, x1, #0xed0
    9f10:	a90187e2 	stp	x2, x1, [sp, #24]
    9f14:	b0ffffe0 	adrp	x0, 6000 <fwp_drop0+0xa0>
    9f18:	f94003e1 	ldr	x1, [sp]
    9f1c:	91034000 	add	x0, x0, #0xd0
    9f20:	d2800013 	mov	x19, #0x0                   	// #0
    9f24:	d2900019 	mov	x25, #0x8000                	// #32768
    9f28:	d2800017 	mov	x23, #0x0                   	// #0
    9f2c:	390023f8 	strb	w24, [sp, #8]
    9f30:	f90017e1 	str	x1, [sp, #40]
    9f34:	f9001bff 	str	xzr, [sp, #48]
    9f38:	a90403ff 	stp	xzr, x0, [sp, #64]
    9f3c:	f901cb7a 	str	x26, [x27, #912]
    9f40:	14000012 	b	9f88 <fwp_main_thread+0x5d8>
    9f44:	7100043f 	cmp	w1, #0x1
    9f48:	540001a1 	b.ne	9f7c <fwp_main_thread+0x5cc>  // b.any
    9f4c:	29430005 	ldp	w5, w0, [x0, #24]
    9f50:	92403c41 	and	x1, x2, #0xffff
    9f54:	9b057c21 	mul	x1, x1, x5
    9f58:	d360fc21 	lsr	x1, x1, #32
    9f5c:	eb00003f 	cmp	x1, x0
    9f60:	540000e2 	b.cs	9f7c <fwp_main_thread+0x5cc>  // b.hs, b.nlast
    9f64:	8b01037b 	add	x27, x27, x1
    9f68:	39400360 	ldrb	w0, [x27]
    9f6c:	7103fc1f 	cmp	w0, #0xff
    9f70:	54002860 	b.eq	a47c <fwp_main_thread+0xacc>  // b.none
    9f74:	394023e0 	ldrb	w0, [sp, #8]
    9f78:	39000360 	strb	w0, [x27]
    9f7c:	f9001bf3 	str	x19, [sp, #48]
    9f80:	aa18035a 	orr	x26, x26, x24
    9f84:	b40003fa 	cbz	x26, a000 <fwp_main_thread+0x650>
    9f88:	f100073a 	subs	x26, x25, #0x1
    9f8c:	aa1603e1 	mov	x1, x22
    9f90:	da1f02f8 	sbc	x24, x23, xzr
    9f94:	52800020 	mov	w0, #0x1                   	// #1
    9f98:	f9001ffa 	str	x26, [sp, #56]
    9f9c:	aa1a03f9 	mov	x25, x26
    9fa0:	a9074ffa 	stp	x26, x19, [sp, #112]
    9fa4:	97ffee8c 	bl	59d4 <fwp_data.part.0.constprop.0>
    9fa8:	aa0003f3 	mov	x19, x0
    9fac:	f949db82 	ldr	x2, [x28, #5040]
    9fb0:	aa1803f7 	mov	x23, x24
    9fb4:	f949ef80 	ldr	x0, [x28, #5080]
    9fb8:	cb020262 	sub	x2, x19, x2
    9fbc:	eb00405f 	cmp	x2, x0, lsl #16
    9fc0:	54fffde2 	b.cs	9f7c <fwp_main_thread+0x5cc>  // b.hs, b.nlast
    9fc4:	d350fc40 	lsr	x0, x2, #16
    9fc8:	f949ff85 	ldr	x5, [x28, #5112]
    9fcc:	8b000800 	add	x0, x0, x0, lsl #2
    9fd0:	d37df001 	lsl	x1, x0, #3
    9fd4:	8b0100a0 	add	x0, x5, x1
    9fd8:	f940101b 	ldr	x27, [x0, #32]
    9fdc:	b4fffd1b 	cbz	x27, 9f7c <fwp_main_thread+0x5cc>
    9fe0:	386168a1 	ldrb	w1, [x5, x1]
    9fe4:	7100083f 	cmp	w1, #0x2
    9fe8:	54fffae1 	b.ne	9f44 <fwp_main_thread+0x594>  // b.any
    9fec:	72003c5f 	tst	w2, #0xffff
    9ff0:	54fffbc0 	b.eq	9f68 <fwp_main_thread+0x5b8>  // b.none
    9ff4:	f9001bf3 	str	x19, [sp, #48]
    9ff8:	aa18035a 	orr	x26, x26, x24
    9ffc:	b5fffc7a 	cbnz	x26, 9f88 <fwp_main_thread+0x5d8>
    a000:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    a004:	91014282 	add	x2, x20, #0x50
    a008:	f9400fe3 	ldr	x3, [sp, #24]
    a00c:	910143e1 	add	x1, sp, #0x50
    a010:	3dc31c00 	ldr	q0, [x0, #3184]
    a014:	52800020 	mov	w0, #0x1                   	// #1
    a018:	f901c843 	str	x3, [x2, #912]
    a01c:	3d8017e0 	str	q0, [sp, #80]
    a020:	97ffee6d 	bl	59d4 <fwp_data.part.0.constprop.0>
    a024:	9118c2a2 	add	x2, x21, #0x630
    a028:	aa0003f8 	mov	x24, x0
    a02c:	f949d841 	ldr	x1, [x2, #5040]
    a030:	f949ec40 	ldr	x0, [x2, #5080]
    a034:	cb010301 	sub	x1, x24, x1
    a038:	eb00403f 	cmp	x1, x0, lsl #16
    a03c:	54000322 	b.cs	a0a0 <fwp_main_thread+0x6f0>  // b.hs, b.nlast
    a040:	d350fc20 	lsr	x0, x1, #16
    a044:	f949fc43 	ldr	x3, [x2, #5112]
    a048:	8b000800 	add	x0, x0, x0, lsl #2
    a04c:	d37df002 	lsl	x2, x0, #3
    a050:	8b020060 	add	x0, x3, x2
    a054:	f9401017 	ldr	x23, [x0, #32]
    a058:	b4000257 	cbz	x23, a0a0 <fwp_main_thread+0x6f0>
    a05c:	38626862 	ldrb	w2, [x3, x2]
    a060:	7100085f 	cmp	w2, #0x2
    a064:	54002060 	b.eq	a470 <fwp_main_thread+0xac0>  // b.none
    a068:	7100045f 	cmp	w2, #0x1
    a06c:	540001a1 	b.ne	a0a0 <fwp_main_thread+0x6f0>  // b.any
    a070:	29430002 	ldp	w2, w0, [x0, #24]
    a074:	92403c21 	and	x1, x1, #0xffff
    a078:	9b027c21 	mul	x1, x1, x2
    a07c:	d360fc21 	lsr	x1, x1, #32
    a080:	eb00003f 	cmp	x1, x0
    a084:	540000e2 	b.cs	a0a0 <fwp_main_thread+0x6f0>  // b.hs, b.nlast
    a088:	8b0102f7 	add	x23, x23, x1
    a08c:	394002e0 	ldrb	w0, [x23]
    a090:	7103fc1f 	cmp	w0, #0xff
    a094:	540020a0 	b.eq	a4a8 <fwp_main_thread+0xaf8>  // b.none
    a098:	52800020 	mov	w0, #0x1                   	// #1
    a09c:	390002e0 	strb	w0, [x23]
    a0a0:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a0a4:	aa1603e1 	mov	x1, x22
    a0a8:	52800020 	mov	w0, #0x1                   	// #1
    a0ac:	a90763e2 	stp	x2, x24, [sp, #112]
    a0b0:	97ffee49 	bl	59d4 <fwp_data.part.0.constprop.0>
    a0b4:	9118c2a2 	add	x2, x21, #0x630
    a0b8:	aa0003f7 	mov	x23, x0
    a0bc:	f949d841 	ldr	x1, [x2, #5040]
    a0c0:	f949ec40 	ldr	x0, [x2, #5080]
    a0c4:	cb0102e1 	sub	x1, x23, x1
    a0c8:	eb00403f 	cmp	x1, x0, lsl #16
    a0cc:	54000322 	b.cs	a130 <fwp_main_thread+0x780>  // b.hs, b.nlast
    a0d0:	d350fc20 	lsr	x0, x1, #16
    a0d4:	f949fc43 	ldr	x3, [x2, #5112]
    a0d8:	8b000800 	add	x0, x0, x0, lsl #2
    a0dc:	d37df002 	lsl	x2, x0, #3
    a0e0:	8b020060 	add	x0, x3, x2
    a0e4:	f9401016 	ldr	x22, [x0, #32]
    a0e8:	b4000256 	cbz	x22, a130 <fwp_main_thread+0x780>
    a0ec:	38626862 	ldrb	w2, [x3, x2]
    a0f0:	7100085f 	cmp	w2, #0x2
    a0f4:	54001b80 	b.eq	a464 <fwp_main_thread+0xab4>  // b.none
    a0f8:	7100045f 	cmp	w2, #0x1
    a0fc:	540001a1 	b.ne	a130 <fwp_main_thread+0x780>  // b.any
    a100:	29430002 	ldp	w2, w0, [x0, #24]
    a104:	92403c21 	and	x1, x1, #0xffff
    a108:	9b027c21 	mul	x1, x1, x2
    a10c:	d360fc21 	lsr	x1, x1, #32
    a110:	eb00003f 	cmp	x1, x0
    a114:	540000e2 	b.cs	a130 <fwp_main_thread+0x780>  // b.hs, b.nlast
    a118:	8b0102d6 	add	x22, x22, x1
    a11c:	394002c0 	ldrb	w0, [x22]
    a120:	7103fc1f 	cmp	w0, #0xff
    a124:	54001c80 	b.eq	a4b4 <fwp_main_thread+0xb04>  // b.none
    a128:	52800020 	mov	w0, #0x1                   	// #1
    a12c:	390002c0 	strb	w0, [x22]
    a130:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a134:	910183e1 	add	x1, sp, #0x60
    a138:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a13c:	52800020 	mov	w0, #0x1                   	// #1
    a140:	a9065fe2 	stp	x2, x23, [sp, #96]
    a144:	97ffee24 	bl	59d4 <fwp_data.part.0.constprop.0>
    a148:	9118c2a2 	add	x2, x21, #0x630
    a14c:	aa0003f7 	mov	x23, x0
    a150:	f949d841 	ldr	x1, [x2, #5040]
    a154:	f949ec40 	ldr	x0, [x2, #5080]
    a158:	cb0102e1 	sub	x1, x23, x1
    a15c:	eb00403f 	cmp	x1, x0, lsl #16
    a160:	54000322 	b.cs	a1c4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    a164:	d350fc20 	lsr	x0, x1, #16
    a168:	f949fc43 	ldr	x3, [x2, #5112]
    a16c:	8b000800 	add	x0, x0, x0, lsl #2
    a170:	d37df002 	lsl	x2, x0, #3
    a174:	8b020060 	add	x0, x3, x2
    a178:	f9401016 	ldr	x22, [x0, #32]
    a17c:	b4000256 	cbz	x22, a1c4 <fwp_main_thread+0x814>
    a180:	38626862 	ldrb	w2, [x3, x2]
    a184:	7100085f 	cmp	w2, #0x2
    a188:	54001680 	b.eq	a458 <fwp_main_thread+0xaa8>  // b.none
    a18c:	7100045f 	cmp	w2, #0x1
    a190:	540001a1 	b.ne	a1c4 <fwp_main_thread+0x814>  // b.any
    a194:	29430002 	ldp	w2, w0, [x0, #24]
    a198:	92403c21 	and	x1, x1, #0xffff
    a19c:	9b027c21 	mul	x1, x1, x2
    a1a0:	d360fc21 	lsr	x1, x1, #32
    a1a4:	eb00003f 	cmp	x1, x0
    a1a8:	540000e2 	b.cs	a1c4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    a1ac:	8b0102d6 	add	x22, x22, x1
    a1b0:	394002c0 	ldrb	w0, [x22]
    a1b4:	7103fc1f 	cmp	w0, #0xff
    a1b8:	54001840 	b.eq	a4c0 <fwp_main_thread+0xb10>  // b.none
    a1bc:	52800020 	mov	w0, #0x1                   	// #1
    a1c0:	390002c0 	strb	w0, [x22]
    a1c4:	aa1303fb 	mov	x27, x19
    a1c8:	900000a0 	adrp	x0, 1e000 <__FRAME_END__+0x10f40>
    a1cc:	b4001233 	cbz	x19, a410 <fwp_main_thread+0xa60>
    a1d0:	91104000 	add	x0, x0, #0x410
    a1d4:	9000001a 	adrp	x26, a000 <fwp_main_thread+0x650>
    a1d8:	9118c2b9 	add	x25, x21, #0x630
    a1dc:	9133c35a 	add	x26, x26, #0xcf0
    a1e0:	91014000 	add	x0, x0, #0x50
    a1e4:	f90007e0 	str	x0, [sp, #8]
    a1e8:	f949db21 	ldr	x1, [x25, #5040]
    a1ec:	f949ef20 	ldr	x0, [x25, #5080]
    a1f0:	cb0102e1 	sub	x1, x23, x1
    a1f4:	eb00403f 	cmp	x1, x0, lsl #16
    a1f8:	54000402 	b.cs	a278 <fwp_main_thread+0x8c8>  // b.hs, b.nlast
    a1fc:	d350fc20 	lsr	x0, x1, #16
    a200:	f949ff24 	ldr	x4, [x25, #5112]
    a204:	8b000800 	add	x0, x0, x0, lsl #2
    a208:	d37df002 	lsl	x2, x0, #3
    a20c:	8b020083 	add	x3, x4, x2
    a210:	f9401060 	ldr	x0, [x3, #32]
    a214:	b4000320 	cbz	x0, a278 <fwp_main_thread+0x8c8>
    a218:	38626882 	ldrb	w2, [x4, x2]
    a21c:	7100085f 	cmp	w2, #0x2
    a220:	54001160 	b.eq	a44c <fwp_main_thread+0xa9c>  // b.none
    a224:	7100045f 	cmp	w2, #0x1
    a228:	54000281 	b.ne	a278 <fwp_main_thread+0x8c8>  // b.any
    a22c:	29430864 	ldp	w4, w2, [x3, #24]
    a230:	92403c21 	and	x1, x1, #0xffff
    a234:	9b047c21 	mul	x1, x1, x4
    a238:	d360fc21 	lsr	x1, x1, #32
    a23c:	eb02003f 	cmp	x1, x2
    a240:	540001c2 	b.cs	a278 <fwp_main_thread+0x8c8>  // b.hs, b.nlast
    a244:	8b010000 	add	x0, x0, x1
    a248:	39400001 	ldrb	w1, [x0]
    a24c:	34000161 	cbz	w1, a278 <fwp_main_thread+0x8c8>
    a250:	91014282 	add	x2, x20, #0x50
    a254:	b9413043 	ldr	w3, [x2, #304]
    a258:	34000083 	cbz	w3, a268 <fwp_main_thread+0x8b8>
    a25c:	f940ac43 	ldr	x3, [x2, #344]
    a260:	91000463 	add	x3, x3, #0x1
    a264:	f900ac43 	str	x3, [x2, #344]
    a268:	7103f43f 	cmp	w1, #0xfd
    a26c:	54001308 	b.hi	a4cc <fwp_main_thread+0xb1c>  // b.pmore
    a270:	11000421 	add	w1, w1, #0x1
    a274:	39000001 	strb	w1, [x0]
    a278:	a9400be0 	ldp	x0, x2, [sp]
    a27c:	aa1703e1 	mov	x1, x23
    a280:	52800023 	mov	w3, #0x1                   	// #1
    a284:	a9037fff 	stp	xzr, xzr, [sp, #48]
    a288:	f90023ff 	str	xzr, [sp, #64]
    a28c:	97fff9cd 	bl	89c0 <fwp_write>
    a290:	a94373f8 	ldp	x24, x28, [sp, #48]
    a294:	f100031f 	cmp	x24, #0x0
    a298:	9a980358 	csel	x24, x26, x24, eq	// eq = none
    a29c:	b1002b9f 	cmn	x28, #0xa
    a2a0:	540011a8 	b.hi	a4d4 <fwp_main_thread+0xb24>  // b.pmore
    a2a4:	52800021 	mov	w1, #0x1                   	// #1
    a2a8:	91002780 	add	x0, x28, #0x9
    a2ac:	97ffeb79 	bl	5090 <fwp_heap_alloc>
    a2b0:	aa0003f6 	mov	x22, x0
    a2b4:	aa1803e1 	mov	x1, x24
    a2b8:	aa0003f8 	mov	x24, x0
    a2bc:	aa1c03e2 	mov	x2, x28
    a2c0:	f800871c 	str	x28, [x24], #8
    a2c4:	aa1803e0 	mov	x0, x24
    a2c8:	97ffe0e6 	bl	2660 <memcpy@plt>
    a2cc:	8b1c02c2 	add	x2, x22, x28
    a2d0:	3900205f 	strb	wzr, [x2, #8]
    a2d4:	f9401be0 	ldr	x0, [sp, #48]
    a2d8:	97ffe17e 	bl	28d0 <free@plt>
    a2dc:	9118c2a2 	add	x2, x21, #0x630
    a2e0:	f949d841 	ldr	x1, [x2, #5040]
    a2e4:	f949ec40 	ldr	x0, [x2, #5080]
    a2e8:	cb0102c1 	sub	x1, x22, x1
    a2ec:	eb00403f 	cmp	x1, x0, lsl #16
    a2f0:	54000322 	b.cs	a354 <fwp_main_thread+0x9a4>  // b.hs, b.nlast
    a2f4:	d350fc20 	lsr	x0, x1, #16
    a2f8:	f949fc44 	ldr	x4, [x2, #5112]
    a2fc:	8b000800 	add	x0, x0, x0, lsl #2
    a300:	d37df002 	lsl	x2, x0, #3
    a304:	8b020083 	add	x3, x4, x2
    a308:	f940107c 	ldr	x28, [x3, #32]
    a30c:	b400025c 	cbz	x28, a354 <fwp_main_thread+0x9a4>
    a310:	38626882 	ldrb	w2, [x4, x2]
    a314:	7100085f 	cmp	w2, #0x2
    a318:	54000bc0 	b.eq	a490 <fwp_main_thread+0xae0>  // b.none
    a31c:	7100045f 	cmp	w2, #0x1
    a320:	540001a1 	b.ne	a354 <fwp_main_thread+0x9a4>  // b.any
    a324:	29430864 	ldp	w4, w2, [x3, #24]
    a328:	92403c21 	and	x1, x1, #0xffff
    a32c:	9b047c21 	mul	x1, x1, x4
    a330:	d360fc21 	lsr	x1, x1, #32
    a334:	eb02003f 	cmp	x1, x2
    a338:	540000e2 	b.cs	a354 <fwp_main_thread+0x9a4>  // b.hs, b.nlast
    a33c:	8b01039c 	add	x28, x28, x1
    a340:	39400381 	ldrb	w1, [x28]
    a344:	7103fc3f 	cmp	w1, #0xff
    a348:	54000aa0 	b.eq	a49c <fwp_main_thread+0xaec>  // b.none
    a34c:	52800021 	mov	w1, #0x1                   	// #1
    a350:	39000381 	strb	w1, [x28]
    a354:	aa1703e0 	mov	x0, x23
    a358:	97ffef02 	bl	5f60 <fwp_drop0>
    a35c:	91014283 	add	x3, x20, #0x50
    a360:	aa1803e0 	mov	x0, x24
    a364:	f94002c2 	ldr	x2, [x22]
    a368:	aa0303f8 	mov	x24, x3
    a36c:	f9404863 	ldr	x3, [x3, #144]
    a370:	d2800021 	mov	x1, #0x1                   	// #1
    a374:	97ffe167 	bl	2910 <fwrite@plt>
    a378:	f9404b01 	ldr	x1, [x24, #144]
    a37c:	52800140 	mov	w0, #0xa                   	// #10
    a380:	97ffe0ec 	bl	2730 <fputc@plt>
    a384:	9118c2a2 	add	x2, x21, #0x630
    a388:	f949d841 	ldr	x1, [x2, #5040]
    a38c:	f949ec40 	ldr	x0, [x2, #5080]
    a390:	cb0102c1 	sub	x1, x22, x1
    a394:	eb00403f 	cmp	x1, x0, lsl #16
    a398:	54000382 	b.cs	a408 <fwp_main_thread+0xa58>  // b.hs, b.nlast
    a39c:	d350fc20 	lsr	x0, x1, #16
    a3a0:	f949fc43 	ldr	x3, [x2, #5112]
    a3a4:	8b000800 	add	x0, x0, x0, lsl #2
    a3a8:	d37df000 	lsl	x0, x0, #3
    a3ac:	8b000062 	add	x2, x3, x0
    a3b0:	f9401058 	ldr	x24, [x2, #32]
    a3b4:	b40002b8 	cbz	x24, a408 <fwp_main_thread+0xa58>
    a3b8:	38606860 	ldrb	w0, [x3, x0]
    a3bc:	7100081f 	cmp	w0, #0x2
    a3c0:	540009e0 	b.eq	a4fc <fwp_main_thread+0xb4c>  // b.none
    a3c4:	7100041f 	cmp	w0, #0x1
    a3c8:	54000201 	b.ne	a408 <fwp_main_thread+0xa58>  // b.any
    a3cc:	29430043 	ldp	w3, w0, [x2, #24]
    a3d0:	92403c21 	and	x1, x1, #0xffff
    a3d4:	9b037c21 	mul	x1, x1, x3
    a3d8:	d360fc21 	lsr	x1, x1, #32
    a3dc:	eb00003f 	cmp	x1, x0
    a3e0:	54000142 	b.cs	a408 <fwp_main_thread+0xa58>  // b.hs, b.nlast
    a3e4:	8b010318 	add	x24, x24, x1
    a3e8:	39400300 	ldrb	w0, [x24]
    a3ec:	340000e0 	cbz	w0, a408 <fwp_main_thread+0xa58>
    a3f0:	7100041f 	cmp	w0, #0x1
    a3f4:	54000bc0 	b.eq	a56c <fwp_main_thread+0xbbc>  // b.none
    a3f8:	7103fc1f 	cmp	w0, #0xff
    a3fc:	540008c0 	b.eq	a514 <fwp_main_thread+0xb64>  // b.none
    a400:	51000400 	sub	w0, w0, #0x1
    a404:	39000300 	strb	w0, [x24]
    a408:	f9400b7b 	ldr	x27, [x27, #16]
    a40c:	b5ffeefb 	cbnz	x27, a1e8 <fwp_main_thread+0x838>
    a410:	aa1703e0 	mov	x0, x23
    a414:	97ffeed3 	bl	5f60 <fwp_drop0>
    a418:	aa1303e0 	mov	x0, x19
    a41c:	97ffeed1 	bl	5f60 <fwp_drop0>
    a420:	91014280 	add	x0, x20, #0x50
    a424:	52800021 	mov	w1, #0x1                   	// #1
    a428:	b903c801 	str	w1, [x0, #968]
    a42c:	f901e81f 	str	xzr, [x0, #976]
    a430:	17fffdaa 	b	9ad8 <fwp_main_thread+0x128>
    a434:	b0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    a438:	913c8000 	add	x0, x0, #0xf20
    a43c:	94000211 	bl	ac80 <atexit>
    a440:	17fffd70 	b	9a00 <fwp_main_thread+0x50>
    a444:	97ffe710 	bl	4084 <fwp_heap_init>
    a448:	17fffd6b 	b	99f4 <fwp_main_thread+0x44>
    a44c:	72003c3f 	tst	w1, #0xffff
    a450:	54fff141 	b.ne	a278 <fwp_main_thread+0x8c8>  // b.any
    a454:	17ffff7d 	b	a248 <fwp_main_thread+0x898>
    a458:	72003c3f 	tst	w1, #0xffff
    a45c:	54ffeb41 	b.ne	a1c4 <fwp_main_thread+0x814>  // b.any
    a460:	17ffff54 	b	a1b0 <fwp_main_thread+0x800>
    a464:	72003c3f 	tst	w1, #0xffff
    a468:	54ffe641 	b.ne	a130 <fwp_main_thread+0x780>  // b.any
    a46c:	17ffff2c 	b	a11c <fwp_main_thread+0x76c>
    a470:	72003c3f 	tst	w1, #0xffff
    a474:	54ffe161 	b.ne	a0a0 <fwp_main_thread+0x6f0>  // b.any
    a478:	17ffff05 	b	a08c <fwp_main_thread+0x6dc>
    a47c:	aa1b03e0 	mov	x0, x27
    a480:	97ffe944 	bl	4990 <fwp_rc_forget_slot>
    a484:	17fffebc 	b	9f74 <fwp_main_thread+0x5c4>
    a488:	aa0103e0 	mov	x0, x1
    a48c:	17fffe17 	b	9ce8 <fwp_main_thread+0x338>
    a490:	72003c3f 	tst	w1, #0xffff
    a494:	54fff601 	b.ne	a354 <fwp_main_thread+0x9a4>  // b.any
    a498:	17ffffaa 	b	a340 <fwp_main_thread+0x990>
    a49c:	aa1c03e0 	mov	x0, x28
    a4a0:	97ffe93c 	bl	4990 <fwp_rc_forget_slot>
    a4a4:	17ffffaa 	b	a34c <fwp_main_thread+0x99c>
    a4a8:	aa1703e0 	mov	x0, x23
    a4ac:	97ffe939 	bl	4990 <fwp_rc_forget_slot>
    a4b0:	17fffefa 	b	a098 <fwp_main_thread+0x6e8>
    a4b4:	aa1603e0 	mov	x0, x22
    a4b8:	97ffe936 	bl	4990 <fwp_rc_forget_slot>
    a4bc:	17ffff1b 	b	a128 <fwp_main_thread+0x778>
    a4c0:	aa1603e0 	mov	x0, x22
    a4c4:	97ffe933 	bl	4990 <fwp_rc_forget_slot>
    a4c8:	17ffff3d 	b	a1bc <fwp_main_thread+0x80c>
    a4cc:	97ffe8ea 	bl	4874 <fwp_rc_wide_dup>
    a4d0:	17ffff6a 	b	a278 <fwp_main_thread+0x8c8>
    a4d4:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    a4d8:	91134000 	add	x0, x0, #0x4d0
    a4dc:	97ffe4a9 	bl	3780 <fwp_trap>
    a4e0:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    a4e4:	9112c000 	add	x0, x0, #0x4b0
    a4e8:	97ffe386 	bl	3300 <ad_raw_fail>
    a4ec:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    a4f0:	91122000 	add	x0, x0, #0x488
    a4f4:	97ffe4a3 	bl	3780 <fwp_trap>
    a4f8:	97ffe0c6 	bl	2810 <__stack_chk_fail@plt>
    a4fc:	72003c3f 	tst	w1, #0xffff
    a500:	54fff841 	b.ne	a408 <fwp_main_thread+0xa58>  // b.any
    a504:	17ffffb9 	b	a3e8 <fwp_main_thread+0xa38>
    a508:	b903dadf 	str	wzr, [x22, #984]
    a50c:	b4ffc220 	cbz	x0, 9d50 <fwp_main_thread+0x3a0>
    a510:	97ffe0d4 	bl	2860 <abort@plt>
    a514:	ca584700 	eor	x0, x24, x24, lsr #17
    a518:	9118c2a1 	add	x1, x21, #0x630
    a51c:	ca402400 	eor	x0, x0, x0, lsr #9
    a520:	8b200c20 	add	x0, x1, w0, uxtb #3
    a524:	f94a2400 	ldr	x0, [x0, #5192]
    a528:	b5000080 	cbnz	x0, a538 <fwp_main_thread+0xb88>
    a52c:	14000013 	b	a578 <fwp_main_thread+0xbc8>
    a530:	f9400800 	ldr	x0, [x0, #16]
    a534:	b4000220 	cbz	x0, a578 <fwp_main_thread+0xbc8>
    a538:	f9400001 	ldr	x1, [x0]
    a53c:	eb01031f 	cmp	x24, x1
    a540:	54ffff81 	b.ne	a530 <fwp_main_thread+0xb80>  // b.any
    a544:	f9400401 	ldr	x1, [x0, #8]
    a548:	d1000421 	sub	x1, x1, #0x1
    a54c:	f9000401 	str	x1, [x0, #8]
    a550:	f103f83f 	cmp	x1, #0xfe
    a554:	54fff5a1 	b.ne	a408 <fwp_main_thread+0xa58>  // b.any
    a558:	aa1803e0 	mov	x0, x24
    a55c:	97ffe90d 	bl	4990 <fwp_rc_forget_slot>
    a560:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a564:	39000300 	strb	w0, [x24]
    a568:	17ffffa8 	b	a408 <fwp_main_thread+0xa58>
    a56c:	aa1603e0 	mov	x0, x22
    a570:	97ffed9d 	bl	5be4 <fwp_rc_free_arr>
    a574:	17ffffa5 	b	a408 <fwp_main_thread+0xa58>
    a578:	b0000000 	adrp	x0, b000 <_IO_stdin_used+0x350>
    a57c:	9105c000 	add	x0, x0, #0x170
    a580:	97ffe480 	bl	3780 <fwp_trap>
    a584:	d503201f 	nop
    a588:	d503201f 	nop
    a58c:	d503201f 	nop

000000000000a590 <__divti3>:
    a590:	d503245f 	bti	c
    a594:	d2800004 	mov	x4, #0x0                   	// #0
    a598:	b7f80721 	tbnz	x1, #63, a67c <__divti3+0xec>
    a59c:	b6f80083 	tbz	x3, #63, a5ac <__divti3+0x1c>
    a5a0:	eb0203e2 	negs	x2, x2
    a5a4:	aa2403e4 	mvn	x4, x4
    a5a8:	da0303e3 	ngc	x3, x3
    a5ac:	aa0203e6 	mov	x6, x2
    a5b0:	aa0003e7 	mov	x7, x0
    a5b4:	aa0103e5 	mov	x5, x1
    a5b8:	b5000583 	cbnz	x3, a668 <__divti3+0xd8>
    a5bc:	eb01005f 	cmp	x2, x1
    a5c0:	54000e69 	b.ls	a78c <__divti3+0x1fc>  // b.plast
    a5c4:	dac01040 	clz	x0, x2
    a5c8:	b40000e0 	cbz	x0, a5e4 <__divti3+0x54>
    a5cc:	4b0003e1 	neg	w1, w0
    a5d0:	9ac020a5 	lsl	x5, x5, x0
    a5d4:	9ac02046 	lsl	x6, x2, x0
    a5d8:	9ac124e1 	lsr	x1, x7, x1
    a5dc:	aa050025 	orr	x5, x1, x5
    a5e0:	9ac020e7 	lsl	x7, x7, x0
    a5e4:	d360fcc8 	lsr	x8, x6, #32
    a5e8:	92407cc2 	and	x2, x6, #0xffffffff
    a5ec:	9ac808a3 	udiv	x3, x5, x8
    a5f0:	9b089465 	msub	x5, x3, x8, x5
    a5f4:	aa0303e0 	mov	x0, x3
    a5f8:	9b037c41 	mul	x1, x2, x3
    a5fc:	93c780a5 	extr	x5, x5, x7, #32
    a600:	eb05003f 	cmp	x1, x5
    a604:	540000a9 	b.ls	a618 <__divti3+0x88>  // b.plast
    a608:	ab0500c5 	adds	x5, x6, x5
    a60c:	d1000460 	sub	x0, x3, #0x1
    a610:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    a614:	540015a8 	b.hi	a8c8 <__divti3+0x338>  // b.pmore
    a618:	cb0100a5 	sub	x5, x5, x1
    a61c:	9ac808a3 	udiv	x3, x5, x8
    a620:	9b089465 	msub	x5, x3, x8, x5
    a624:	aa0303e1 	mov	x1, x3
    a628:	9b037c42 	mul	x2, x2, x3
    a62c:	aa0703e3 	mov	x3, x7
    a630:	b3607ca3 	bfi	x3, x5, #32, #32
    a634:	eb03005f 	cmp	x2, x3
    a638:	540000c9 	b.ls	a650 <__divti3+0xc0>  // b.plast
    a63c:	ab0300c3 	adds	x3, x6, x3
    a640:	d1000425 	sub	x5, x1, #0x1
    a644:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a648:	d1000821 	sub	x1, x1, #0x2
    a64c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    a650:	aa008020 	orr	x0, x1, x0, lsl #32
    a654:	d2800001 	mov	x1, #0x0                   	// #0
    a658:	b4000064 	cbz	x4, a664 <__divti3+0xd4>
    a65c:	eb0003e0 	negs	x0, x0
    a660:	da0103e1 	ngc	x1, x1
    a664:	d65f03c0 	ret
    a668:	eb01007f 	cmp	x3, x1
    a66c:	54000109 	b.ls	a68c <__divti3+0xfc>  // b.plast
    a670:	d2800001 	mov	x1, #0x0                   	// #0
    a674:	d2800000 	mov	x0, #0x0                   	// #0
    a678:	17fffff8 	b	a658 <__divti3+0xc8>
    a67c:	eb0003e0 	negs	x0, x0
    a680:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a684:	da0103e1 	ngc	x1, x1
    a688:	17ffffc5 	b	a59c <__divti3+0xc>
    a68c:	dac01067 	clz	x7, x3
    a690:	b40010e7 	cbz	x7, a8ac <__divti3+0x31c>
    a694:	d2800805 	mov	x5, #0x40                  	// #64
    a698:	cb0700a5 	sub	x5, x5, x7
    a69c:	9ac72063 	lsl	x3, x3, x7
    a6a0:	9ac52448 	lsr	x8, x2, x5
    a6a4:	aa030108 	orr	x8, x8, x3
    a6a8:	9ac52426 	lsr	x6, x1, x5
    a6ac:	92407d0a 	and	x10, x8, #0xffffffff
    a6b0:	d360fd09 	lsr	x9, x8, #32
    a6b4:	9ac52403 	lsr	x3, x0, x5
    a6b8:	9ac72021 	lsl	x1, x1, x7
    a6bc:	aa010063 	orr	x3, x3, x1
    a6c0:	9ac72042 	lsl	x2, x2, x7
    a6c4:	9ac908cb 	udiv	x11, x6, x9
    a6c8:	9b099965 	msub	x5, x11, x9, x6
    a6cc:	aa0b03e1 	mov	x1, x11
    a6d0:	9b0b7d46 	mul	x6, x10, x11
    a6d4:	93c380a5 	extr	x5, x5, x3, #32
    a6d8:	eb0500df 	cmp	x6, x5
    a6dc:	540000a9 	b.ls	a6f0 <__divti3+0x160>  // b.plast
    a6e0:	ab050105 	adds	x5, x8, x5
    a6e4:	d1000561 	sub	x1, x11, #0x1
    a6e8:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    a6ec:	54000f48 	b.hi	a8d4 <__divti3+0x344>  // b.pmore
    a6f0:	cb0600a6 	sub	x6, x5, x6
    a6f4:	9ac908cb 	udiv	x11, x6, x9
    a6f8:	9b099969 	msub	x9, x11, x9, x6
    a6fc:	aa0b03e5 	mov	x5, x11
    a700:	9b0b7d4a 	mul	x10, x10, x11
    a704:	b3607d23 	bfi	x3, x9, #32, #32
    a708:	eb03015f 	cmp	x10, x3
    a70c:	540000a9 	b.ls	a720 <__divti3+0x190>  // b.plast
    a710:	ab030103 	adds	x3, x8, x3
    a714:	d1000565 	sub	x5, x11, #0x1
    a718:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    a71c:	54000e28 	b.hi	a8e0 <__divti3+0x350>  // b.pmore
    a720:	aa0180a1 	orr	x1, x5, x1, lsl #32
    a724:	92407c48 	and	x8, x2, #0xffffffff
    a728:	2a0503e5 	mov	w5, w5
    a72c:	d360fc42 	lsr	x2, x2, #32
    a730:	d360fc26 	lsr	x6, x1, #32
    a734:	cb0a0063 	sub	x3, x3, x10
    a738:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    a73c:	9b087caa 	mul	x10, x5, x8
    a740:	9b087cc8 	mul	x8, x6, x8
    a744:	9b0220a5 	madd	x5, x5, x2, x8
    a748:	9b027cc6 	mul	x6, x6, x2
    a74c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    a750:	8b0900c5 	add	x5, x6, x9
    a754:	eb02011f 	cmp	x8, x2
    a758:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    a75c:	8b4280c6 	add	x6, x6, x2, lsr #32
    a760:	eb06007f 	cmp	x3, x6
    a764:	540000e3 	b.cc	a780 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    a768:	92407d4a 	and	x10, x10, #0xffffffff
    a76c:	9ac72000 	lsl	x0, x0, x7
    a770:	8b028142 	add	x2, x10, x2, lsl #32
    a774:	eb02001f 	cmp	x0, x2
    a778:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    a77c:	54000a01 	b.ne	a8bc <__divti3+0x32c>  // b.any
    a780:	d1000420 	sub	x0, x1, #0x1
    a784:	d2800001 	mov	x1, #0x0                   	// #0
    a788:	17ffffb4 	b	a658 <__divti3+0xc8>
    a78c:	b5000062 	cbnz	x2, a798 <__divti3+0x208>
    a790:	d2800022 	mov	x2, #0x1                   	// #1
    a794:	9ac30846 	udiv	x6, x2, x3
    a798:	dac010c8 	clz	x8, x6
    a79c:	b5000408 	cbnz	x8, a81c <__divti3+0x28c>
    a7a0:	d360fcc9 	lsr	x9, x6, #32
    a7a4:	92407cc5 	and	x5, x6, #0xffffffff
    a7a8:	cb060023 	sub	x3, x1, x6
    a7ac:	d2800021 	mov	x1, #0x1                   	// #1
    a7b0:	9ac90868 	udiv	x8, x3, x9
    a7b4:	9b098d03 	msub	x3, x8, x9, x3
    a7b8:	aa0803e0 	mov	x0, x8
    a7bc:	9b057d02 	mul	x2, x8, x5
    a7c0:	93c78063 	extr	x3, x3, x7, #32
    a7c4:	eb03005f 	cmp	x2, x3
    a7c8:	540000a9 	b.ls	a7dc <__divti3+0x24c>  // b.plast
    a7cc:	ab0300c3 	adds	x3, x6, x3
    a7d0:	d1000500 	sub	x0, x8, #0x1
    a7d4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    a7d8:	54000968 	b.hi	a904 <__divti3+0x374>  // b.pmore
    a7dc:	cb020063 	sub	x3, x3, x2
    a7e0:	9ac90862 	udiv	x2, x3, x9
    a7e4:	aa0203e8 	mov	x8, x2
    a7e8:	9b098c42 	msub	x2, x2, x9, x3
    a7ec:	aa0703e3 	mov	x3, x7
    a7f0:	9b057d05 	mul	x5, x8, x5
    a7f4:	b3607c43 	bfi	x3, x2, #32, #32
    a7f8:	eb0300bf 	cmp	x5, x3
    a7fc:	540000c9 	b.ls	a814 <__divti3+0x284>  // b.plast
    a800:	ab0300c2 	adds	x2, x6, x3
    a804:	d1000503 	sub	x3, x8, #0x1
    a808:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    a80c:	d1000908 	sub	x8, x8, #0x2
    a810:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    a814:	aa008100 	orr	x0, x8, x0, lsl #32
    a818:	17ffff90 	b	a658 <__divti3+0xc8>
    a81c:	9ac820c6 	lsl	x6, x6, x8
    a820:	d2800803 	mov	x3, #0x40                  	// #64
    a824:	cb080063 	sub	x3, x3, x8
    a828:	d360fcc9 	lsr	x9, x6, #32
    a82c:	9ac82027 	lsl	x7, x1, x8
    a830:	92407cc5 	and	x5, x6, #0xffffffff
    a834:	9ac32422 	lsr	x2, x1, x3
    a838:	9ac32403 	lsr	x3, x0, x3
    a83c:	aa070063 	orr	x3, x3, x7
    a840:	9ac9084a 	udiv	x10, x2, x9
    a844:	9ac82007 	lsl	x7, x0, x8
    a848:	9b098940 	msub	x0, x10, x9, x2
    a84c:	aa0a03e1 	mov	x1, x10
    a850:	9b0a7ca2 	mul	x2, x5, x10
    a854:	93c38000 	extr	x0, x0, x3, #32
    a858:	eb00005f 	cmp	x2, x0
    a85c:	540000a9 	b.ls	a870 <__divti3+0x2e0>  // b.plast
    a860:	ab0000c0 	adds	x0, x6, x0
    a864:	d1000541 	sub	x1, x10, #0x1
    a868:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    a86c:	54000468 	b.hi	a8f8 <__divti3+0x368>  // b.pmore
    a870:	cb020000 	sub	x0, x0, x2
    a874:	9ac9080a 	udiv	x10, x0, x9
    a878:	9b098140 	msub	x0, x10, x9, x0
    a87c:	aa0a03e2 	mov	x2, x10
    a880:	9b0a7ca8 	mul	x8, x5, x10
    a884:	b3607c03 	bfi	x3, x0, #32, #32
    a888:	eb03011f 	cmp	x8, x3
    a88c:	540000a9 	b.ls	a8a0 <__divti3+0x310>  // b.plast
    a890:	ab0300c3 	adds	x3, x6, x3
    a894:	d1000542 	sub	x2, x10, #0x1
    a898:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    a89c:	54000288 	b.hi	a8ec <__divti3+0x35c>  // b.pmore
    a8a0:	cb080063 	sub	x3, x3, x8
    a8a4:	aa018041 	orr	x1, x2, x1, lsl #32
    a8a8:	17ffffc2 	b	a7b0 <__divti3+0x220>
    a8ac:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    a8b0:	d2800001 	mov	x1, #0x0                   	// #0
    a8b4:	9a9f87e0 	cset	x0, ls	// ls = plast
    a8b8:	17ffff68 	b	a658 <__divti3+0xc8>
    a8bc:	aa0103e0 	mov	x0, x1
    a8c0:	d2800001 	mov	x1, #0x0                   	// #0
    a8c4:	17ffff65 	b	a658 <__divti3+0xc8>
    a8c8:	d1000860 	sub	x0, x3, #0x2
    a8cc:	8b0600a5 	add	x5, x5, x6
    a8d0:	17ffff52 	b	a618 <__divti3+0x88>
    a8d4:	d1000961 	sub	x1, x11, #0x2
    a8d8:	8b0800a5 	add	x5, x5, x8
    a8dc:	17ffff85 	b	a6f0 <__divti3+0x160>
    a8e0:	d1000965 	sub	x5, x11, #0x2
    a8e4:	8b080063 	add	x3, x3, x8
    a8e8:	17ffff8e 	b	a720 <__divti3+0x190>
    a8ec:	d1000942 	sub	x2, x10, #0x2
    a8f0:	8b060063 	add	x3, x3, x6
    a8f4:	17ffffeb 	b	a8a0 <__divti3+0x310>
    a8f8:	d1000941 	sub	x1, x10, #0x2
    a8fc:	8b060000 	add	x0, x0, x6
    a900:	17ffffdc 	b	a870 <__divti3+0x2e0>
    a904:	d1000900 	sub	x0, x8, #0x2
    a908:	8b060063 	add	x3, x3, x6
    a90c:	17ffffb4 	b	a7dc <__divti3+0x24c>

000000000000a910 <__modti3>:
    a910:	d503245f 	bti	c
    a914:	d2800004 	mov	x4, #0x0                   	// #0
    a918:	b6f80081 	tbz	x1, #63, a928 <__modti3+0x18>
    a91c:	eb0003e0 	negs	x0, x0
    a920:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    a924:	da0103e1 	ngc	x1, x1
    a928:	f100007f 	cmp	x3, #0x0
    a92c:	5400128b 	b.lt	ab7c <__modti3+0x26c>  // b.tstop
    a930:	aa0003e7 	mov	x7, x0
    a934:	aa0103e6 	mov	x6, x1
    a938:	540004e1 	b.ne	a9d4 <__modti3+0xc4>  // b.any
    a93c:	eb02003f 	cmp	x1, x2
    a940:	54000dc2 	b.cs	aaf8 <__modti3+0x1e8>  // b.hs, b.nlast
    a944:	dac01043 	clz	x3, x2
    a948:	aa0303e5 	mov	x5, x3
    a94c:	b40000e3 	cbz	x3, a968 <__modti3+0x58>
    a950:	4b0303e6 	neg	w6, w3
    a954:	9ac32021 	lsl	x1, x1, x3
    a958:	9ac32042 	lsl	x2, x2, x3
    a95c:	9ac62406 	lsr	x6, x0, x6
    a960:	aa0100c6 	orr	x6, x6, x1
    a964:	9ac32007 	lsl	x7, x0, x3
    a968:	d360fc40 	lsr	x0, x2, #32
    a96c:	92407c43 	and	x3, x2, #0xffffffff
    a970:	9ac008c1 	udiv	x1, x6, x0
    a974:	9b009826 	msub	x6, x1, x0, x6
    a978:	9b017c61 	mul	x1, x3, x1
    a97c:	93c780c6 	extr	x6, x6, x7, #32
    a980:	eb06003f 	cmp	x1, x6
    a984:	540000a9 	b.ls	a998 <__modti3+0x88>  // b.plast
    a988:	ab060046 	adds	x6, x2, x6
    a98c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    a990:	8b0200c8 	add	x8, x6, x2
    a994:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    a998:	cb0100c6 	sub	x6, x6, x1
    a99c:	9ac008c8 	udiv	x8, x6, x0
    a9a0:	9b009901 	msub	x1, x8, x0, x6
    a9a4:	aa0703e0 	mov	x0, x7
    a9a8:	9b087c63 	mul	x3, x3, x8
    a9ac:	b3607c20 	bfi	x0, x1, #32, #32
    a9b0:	eb00007f 	cmp	x3, x0
    a9b4:	54001088 	b.hi	abc4 <__modti3+0x2b4>  // b.pmore
    a9b8:	cb030000 	sub	x0, x0, x3
    a9bc:	9ac52400 	lsr	x0, x0, x5
    a9c0:	d2800001 	mov	x1, #0x0                   	// #0
    a9c4:	b4000064 	cbz	x4, a9d0 <__modti3+0xc0>
    a9c8:	eb0003e0 	negs	x0, x0
    a9cc:	da0103e1 	ngc	x1, x1
    a9d0:	d65f03c0 	ret
    a9d4:	dac01066 	clz	x6, x3
    a9d8:	eb03003f 	cmp	x1, x3
    a9dc:	54ffff43 	b.cc	a9c4 <__modti3+0xb4>  // b.lo, b.ul, b.last
    a9e0:	93407cc5 	sxtw	x5, w6
    a9e4:	d2800808 	mov	x8, #0x40                  	// #64
    a9e8:	cb050108 	sub	x8, x8, x5
    a9ec:	9ac62063 	lsl	x3, x3, x6
    a9f0:	9ac62025 	lsl	x5, x1, x6
    a9f4:	9ac82447 	lsr	x7, x2, x8
    a9f8:	aa0300e7 	orr	x7, x7, x3
    a9fc:	9ac82423 	lsr	x3, x1, x8
    aa00:	92407cec 	and	x12, x7, #0xffffffff
    aa04:	d360fcea 	lsr	x10, x7, #32
    aa08:	9ac82401 	lsr	x1, x0, x8
    aa0c:	aa050021 	orr	x1, x1, x5
    aa10:	9ac62042 	lsl	x2, x2, x6
    aa14:	9ac62000 	lsl	x0, x0, x6
    aa18:	9aca086b 	udiv	x11, x3, x10
    aa1c:	9b0a8d63 	msub	x3, x11, x10, x3
    aa20:	aa0b03e5 	mov	x5, x11
    aa24:	9b0b7d89 	mul	x9, x12, x11
    aa28:	93c18063 	extr	x3, x3, x1, #32
    aa2c:	eb03013f 	cmp	x9, x3
    aa30:	540000a9 	b.ls	aa44 <__modti3+0x134>  // b.plast
    aa34:	ab0300e3 	adds	x3, x7, x3
    aa38:	d1000565 	sub	x5, x11, #0x1
    aa3c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    aa40:	54001168 	b.hi	ac6c <__modti3+0x35c>  // b.pmore
    aa44:	cb090063 	sub	x3, x3, x9
    aa48:	9aca086b 	udiv	x11, x3, x10
    aa4c:	9b0a8d6a 	msub	x10, x11, x10, x3
    aa50:	aa0b03e9 	mov	x9, x11
    aa54:	9b0b7d8c 	mul	x12, x12, x11
    aa58:	b3607d41 	bfi	x1, x10, #32, #32
    aa5c:	eb01019f 	cmp	x12, x1
    aa60:	540000a9 	b.ls	aa74 <__modti3+0x164>  // b.plast
    aa64:	ab0100e1 	adds	x1, x7, x1
    aa68:	d1000569 	sub	x9, x11, #0x1
    aa6c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    aa70:	54000f88 	b.hi	ac60 <__modti3+0x350>  // b.pmore
    aa74:	aa058123 	orr	x3, x9, x5, lsl #32
    aa78:	92407c4b 	and	x11, x2, #0xffffffff
    aa7c:	2a0903e9 	mov	w9, w9
    aa80:	d360fc4a 	lsr	x10, x2, #32
    aa84:	d360fc63 	lsr	x3, x3, #32
    aa88:	cb0c0021 	sub	x1, x1, x12
    aa8c:	aa0a03ec 	mov	x12, x10
    aa90:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    aa94:	9b0b7d25 	mul	x5, x9, x11
    aa98:	9b0b7c6b 	mul	x11, x3, x11
    aa9c:	9b0a2d29 	madd	x9, x9, x10, x11
    aaa0:	92407caa 	and	x10, x5, #0xffffffff
    aaa4:	9b0c7c63 	mul	x3, x3, x12
    aaa8:	8b458125 	add	x5, x9, x5, lsr #32
    aaac:	8b0d0069 	add	x9, x3, x13
    aab0:	eb05017f 	cmp	x11, x5
    aab4:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    aab8:	8b058149 	add	x9, x10, x5, lsl #32
    aabc:	8b458063 	add	x3, x3, x5, lsr #32
    aac0:	eb03003f 	cmp	x1, x3
    aac4:	54000063 	b.cc	aad0 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    aac8:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    aacc:	54000082 	b.cs	aadc <__modti3+0x1cc>  // b.hs, b.nlast
    aad0:	eb020129 	subs	x9, x9, x2
    aad4:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    aad8:	cb070063 	sub	x3, x3, x7
    aadc:	eb090000 	subs	x0, x0, x9
    aae0:	da030021 	sbc	x1, x1, x3
    aae4:	9ac62400 	lsr	x0, x0, x6
    aae8:	9ac82028 	lsl	x8, x1, x8
    aaec:	aa000100 	orr	x0, x8, x0
    aaf0:	9ac62421 	lsr	x1, x1, x6
    aaf4:	17ffffb4 	b	a9c4 <__modti3+0xb4>
    aaf8:	b5000062 	cbnz	x2, ab04 <__modti3+0x1f4>
    aafc:	d2800023 	mov	x3, #0x1                   	// #1
    ab00:	9ac20862 	udiv	x2, x3, x2
    ab04:	dac01048 	clz	x8, x2
    ab08:	aa0803e5 	mov	x5, x8
    ab0c:	b5000668 	cbnz	x8, abd8 <__modti3+0x2c8>
    ab10:	cb020020 	sub	x0, x1, x2
    ab14:	d360fc49 	lsr	x9, x2, #32
    ab18:	92407c4a 	and	x10, x2, #0xffffffff
    ab1c:	9ac90801 	udiv	x1, x0, x9
    ab20:	9b098020 	msub	x0, x1, x9, x0
    ab24:	9b0a7c21 	mul	x1, x1, x10
    ab28:	93c78000 	extr	x0, x0, x7, #32
    ab2c:	eb00003f 	cmp	x1, x0
    ab30:	540000a9 	b.ls	ab44 <__modti3+0x234>  // b.plast
    ab34:	ab000040 	adds	x0, x2, x0
    ab38:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ab3c:	8b020003 	add	x3, x0, x2
    ab40:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ab44:	cb010001 	sub	x1, x0, x1
    ab48:	9ac90820 	udiv	x0, x1, x9
    ab4c:	9b098403 	msub	x3, x0, x9, x1
    ab50:	aa0703e1 	mov	x1, x7
    ab54:	9b0a7c00 	mul	x0, x0, x10
    ab58:	b3607c61 	bfi	x1, x3, #32, #32
    ab5c:	eb01001f 	cmp	x0, x1
    ab60:	540000a9 	b.ls	ab74 <__modti3+0x264>  // b.plast
    ab64:	ab010041 	adds	x1, x2, x1
    ab68:	8b020022 	add	x2, x1, x2
    ab6c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    ab70:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    ab74:	cb000020 	sub	x0, x1, x0
    ab78:	17ffff91 	b	a9bc <__modti3+0xac>
    ab7c:	eb0203e5 	negs	x5, x2
    ab80:	aa0003e7 	mov	x7, x0
    ab84:	da0303e8 	ngc	x8, x3
    ab88:	aa0503e2 	mov	x2, x5
    ab8c:	aa0803e3 	mov	x3, x8
    ab90:	aa0103e6 	mov	x6, x1
    ab94:	b4ffed48 	cbz	x8, a93c <__modti3+0x2c>
    ab98:	eb01011f 	cmp	x8, x1
    ab9c:	54fff148 	b.hi	a9c4 <__modti3+0xb4>  // b.pmore
    aba0:	dac01109 	clz	x9, x8
    aba4:	2a0903e6 	mov	w6, w9
    aba8:	b5fff1c9 	cbnz	x9, a9e0 <__modti3+0xd0>
    abac:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    abb0:	54000068 	b.hi	abbc <__modti3+0x2ac>  // b.pmore
    abb4:	eb050007 	subs	x7, x0, x5
    abb8:	da080021 	sbc	x1, x1, x8
    abbc:	aa0703e0 	mov	x0, x7
    abc0:	17ffff81 	b	a9c4 <__modti3+0xb4>
    abc4:	ab000040 	adds	x0, x2, x0
    abc8:	8b020002 	add	x2, x0, x2
    abcc:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    abd0:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    abd4:	17ffff79 	b	a9b8 <__modti3+0xa8>
    abd8:	9ac82042 	lsl	x2, x2, x8
    abdc:	d2800803 	mov	x3, #0x40                  	// #64
    abe0:	cb080063 	sub	x3, x3, x8
    abe4:	d360fc49 	lsr	x9, x2, #32
    abe8:	9ac82027 	lsl	x7, x1, x8
    abec:	92407c4a 	and	x10, x2, #0xffffffff
    abf0:	9ac32426 	lsr	x6, x1, x3
    abf4:	9ac32403 	lsr	x3, x0, x3
    abf8:	aa070063 	orr	x3, x3, x7
    abfc:	9ac908c1 	udiv	x1, x6, x9
    ac00:	9ac82007 	lsl	x7, x0, x8
    ac04:	9b099820 	msub	x0, x1, x9, x6
    ac08:	9b017d41 	mul	x1, x10, x1
    ac0c:	93c38000 	extr	x0, x0, x3, #32
    ac10:	eb00003f 	cmp	x1, x0
    ac14:	540000a9 	b.ls	ac28 <__modti3+0x318>  // b.plast
    ac18:	ab000040 	adds	x0, x2, x0
    ac1c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ac20:	8b020006 	add	x6, x0, x2
    ac24:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    ac28:	cb010000 	sub	x0, x0, x1
    ac2c:	9ac90801 	udiv	x1, x0, x9
    ac30:	9b098026 	msub	x6, x1, x9, x0
    ac34:	aa0303e0 	mov	x0, x3
    ac38:	9b017d41 	mul	x1, x10, x1
    ac3c:	b3607cc0 	bfi	x0, x6, #32, #32
    ac40:	eb00003f 	cmp	x1, x0
    ac44:	540000a9 	b.ls	ac58 <__modti3+0x348>  // b.plast
    ac48:	ab000040 	adds	x0, x2, x0
    ac4c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    ac50:	8b020003 	add	x3, x0, x2
    ac54:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    ac58:	cb010000 	sub	x0, x0, x1
    ac5c:	17ffffb0 	b	ab1c <__modti3+0x20c>
    ac60:	d1000969 	sub	x9, x11, #0x2
    ac64:	8b070021 	add	x1, x1, x7
    ac68:	17ffff83 	b	aa74 <__modti3+0x164>
    ac6c:	d1000965 	sub	x5, x11, #0x2
    ac70:	8b070063 	add	x3, x3, x7
    ac74:	17ffff74 	b	aa44 <__modti3+0x134>
    ac78:	d503201f 	nop
    ac7c:	d503201f 	nop

000000000000ac80 <atexit>:
    ac80:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    ac84:	d00000a2 	adrp	x2, 20000 <__data_start>
    ac88:	d2800001 	mov	x1, #0x0                   	// #0
    ac8c:	910003fd 	mov	x29, sp
    ac90:	a8c17bfd 	ldp	x29, x30, [sp], #16
    ac94:	f9400442 	ldr	x2, [x2, #8]
    ac98:	17ffde9e 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ac9c <_fini>:
    ac9c:	d503201f 	nop
    aca0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    aca4:	910003fd 	mov	x29, sp
    aca8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    acac:	d65f03c0 	ret
