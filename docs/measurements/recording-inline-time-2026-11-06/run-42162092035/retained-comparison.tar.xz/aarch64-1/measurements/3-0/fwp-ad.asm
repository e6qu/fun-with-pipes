
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002698 <_init>:
    2698:	d503201f 	nop
    269c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    26a0:	910003fd 	mov	x29, sp
    26a4:	940001a4 	bl	2d34 <call_weak_fn>
    26a8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    26ac:	d65f03c0 	ret

Disassembly of section .plt:

00000000000026b0 <.plt>:
    26b0:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    26b4:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26b8:	f946f611 	ldr	x17, [x16, #3560]
    26bc:	9137a210 	add	x16, x16, #0xde8
    26c0:	d61f0220 	br	x17
    26c4:	d503201f 	nop
    26c8:	d503201f 	nop
    26cc:	d503201f 	nop

00000000000026d0 <memcpy@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26d4:	f946fa11 	ldr	x17, [x16, #3568]
    26d8:	9137c210 	add	x16, x16, #0xdf0
    26dc:	d61f0220 	br	x17

00000000000026e0 <sigaltstack@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26e4:	f946fe11 	ldr	x17, [x16, #3576]
    26e8:	9137e210 	add	x16, x16, #0xdf8
    26ec:	d61f0220 	br	x17

00000000000026f0 <memmove@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    26f4:	f9470211 	ldr	x17, [x16, #3584]
    26f8:	91380210 	add	x16, x16, #0xe00
    26fc:	d61f0220 	br	x17

0000000000002700 <_exit@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2704:	f9470611 	ldr	x17, [x16, #3592]
    2708:	91382210 	add	x16, x16, #0xe08
    270c:	d61f0220 	br	x17

0000000000002710 <strlen@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2714:	f9470a11 	ldr	x17, [x16, #3600]
    2718:	91384210 	add	x16, x16, #0xe10
    271c:	d61f0220 	br	x17

0000000000002720 <__sprintf_chk@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2724:	f9470e11 	ldr	x17, [x16, #3608]
    2728:	91386210 	add	x16, x16, #0xe18
    272c:	d61f0220 	br	x17

0000000000002730 <exit@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2734:	f9471211 	ldr	x17, [x16, #3616]
    2738:	91388210 	add	x16, x16, #0xe20
    273c:	d61f0220 	br	x17

0000000000002740 <__libc_start_main@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2744:	f9471611 	ldr	x17, [x16, #3624]
    2748:	9138a210 	add	x16, x16, #0xe28
    274c:	d61f0220 	br	x17

0000000000002750 <strtoll@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2754:	f9471a11 	ldr	x17, [x16, #3632]
    2758:	9138c210 	add	x16, x16, #0xe30
    275c:	d61f0220 	br	x17

0000000000002760 <strtod@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2764:	f9471e11 	ldr	x17, [x16, #3640]
    2768:	9138e210 	add	x16, x16, #0xe38
    276c:	d61f0220 	br	x17

0000000000002770 <__cxa_finalize@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2774:	f9472211 	ldr	x17, [x16, #3648]
    2778:	91390210 	add	x16, x16, #0xe40
    277c:	d61f0220 	br	x17

0000000000002780 <__cxa_atexit@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2784:	f9472611 	ldr	x17, [x16, #3656]
    2788:	91392210 	add	x16, x16, #0xe48
    278c:	d61f0220 	br	x17

0000000000002790 <pthread_attr_init@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2794:	f9472a11 	ldr	x17, [x16, #3664]
    2798:	91394210 	add	x16, x16, #0xe50
    279c:	d61f0220 	br	x17

00000000000027a0 <fputc@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27a4:	f9472e11 	ldr	x17, [x16, #3672]
    27a8:	91396210 	add	x16, x16, #0xe58
    27ac:	d61f0220 	br	x17

00000000000027b0 <clock_gettime@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27b4:	f9473211 	ldr	x17, [x16, #3680]
    27b8:	91398210 	add	x16, x16, #0xe60
    27bc:	d61f0220 	br	x17

00000000000027c0 <setvbuf@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27c4:	f9473611 	ldr	x17, [x16, #3688]
    27c8:	9139a210 	add	x16, x16, #0xe68
    27cc:	d61f0220 	br	x17

00000000000027d0 <__memcpy_chk@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27d4:	f9473a11 	ldr	x17, [x16, #3696]
    27d8:	9139c210 	add	x16, x16, #0xe70
    27dc:	d61f0220 	br	x17

00000000000027e0 <signal@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27e4:	f9473e11 	ldr	x17, [x16, #3704]
    27e8:	9139e210 	add	x16, x16, #0xe78
    27ec:	d61f0220 	br	x17

00000000000027f0 <__snprintf_chk@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    27f4:	f9474211 	ldr	x17, [x16, #3712]
    27f8:	913a0210 	add	x16, x16, #0xe80
    27fc:	d61f0220 	br	x17

0000000000002800 <fclose@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2804:	f9474611 	ldr	x17, [x16, #3720]
    2808:	913a2210 	add	x16, x16, #0xe88
    280c:	d61f0220 	br	x17

0000000000002810 <fopen@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2814:	f9474a11 	ldr	x17, [x16, #3728]
    2818:	913a4210 	add	x16, x16, #0xe90
    281c:	d61f0220 	br	x17

0000000000002820 <malloc@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2824:	f9474e11 	ldr	x17, [x16, #3736]
    2828:	913a6210 	add	x16, x16, #0xe98
    282c:	d61f0220 	br	x17

0000000000002830 <pthread_attr_destroy@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2834:	f9475211 	ldr	x17, [x16, #3744]
    2838:	913a8210 	add	x16, x16, #0xea0
    283c:	d61f0220 	br	x17

0000000000002840 <sigemptyset@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2844:	f9475611 	ldr	x17, [x16, #3752]
    2848:	913aa210 	add	x16, x16, #0xea8
    284c:	d61f0220 	br	x17

0000000000002850 <memset@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2854:	f9475a11 	ldr	x17, [x16, #3760]
    2858:	913ac210 	add	x16, x16, #0xeb0
    285c:	d61f0220 	br	x17

0000000000002860 <calloc@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2864:	f9475e11 	ldr	x17, [x16, #3768]
    2868:	913ae210 	add	x16, x16, #0xeb8
    286c:	d61f0220 	br	x17

0000000000002870 <realloc@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2874:	f9476211 	ldr	x17, [x16, #3776]
    2878:	913b0210 	add	x16, x16, #0xec0
    287c:	d61f0220 	br	x17

0000000000002880 <__stack_chk_fail@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2884:	f9476611 	ldr	x17, [x16, #3784]
    2888:	913b2210 	add	x16, x16, #0xec8
    288c:	d61f0220 	br	x17

0000000000002890 <close@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2894:	f9476a11 	ldr	x17, [x16, #3792]
    2898:	913b4210 	add	x16, x16, #0xed0
    289c:	d61f0220 	br	x17

00000000000028a0 <sigaction@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28a4:	f9476e11 	ldr	x17, [x16, #3800]
    28a8:	913b6210 	add	x16, x16, #0xed8
    28ac:	d61f0220 	br	x17

00000000000028b0 <__gmon_start__@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28b4:	f9477211 	ldr	x17, [x16, #3808]
    28b8:	913b8210 	add	x16, x16, #0xee0
    28bc:	d61f0220 	br	x17

00000000000028c0 <write@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28c4:	f9477611 	ldr	x17, [x16, #3816]
    28c8:	913ba210 	add	x16, x16, #0xee8
    28cc:	d61f0220 	br	x17

00000000000028d0 <abort@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28d4:	f9477a11 	ldr	x17, [x16, #3824]
    28d8:	913bc210 	add	x16, x16, #0xef0
    28dc:	d61f0220 	br	x17

00000000000028e0 <swapcontext@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28e4:	f9477e11 	ldr	x17, [x16, #3832]
    28e8:	913be210 	add	x16, x16, #0xef8
    28ec:	d61f0220 	br	x17

00000000000028f0 <__fprintf_chk@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    28f4:	f9478211 	ldr	x17, [x16, #3840]
    28f8:	913c0210 	add	x16, x16, #0xf00
    28fc:	d61f0220 	br	x17

0000000000002900 <strcmp@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2904:	f9478611 	ldr	x17, [x16, #3848]
    2908:	913c2210 	add	x16, x16, #0xf08
    290c:	d61f0220 	br	x17

0000000000002910 <mmap@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2914:	f9478a11 	ldr	x17, [x16, #3856]
    2918:	913c4210 	add	x16, x16, #0xf10
    291c:	d61f0220 	br	x17

0000000000002920 <strtol@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2924:	f9478e11 	ldr	x17, [x16, #3864]
    2928:	913c6210 	add	x16, x16, #0xf18
    292c:	d61f0220 	br	x17

0000000000002930 <strtof@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2934:	f9479211 	ldr	x17, [x16, #3872]
    2938:	913c8210 	add	x16, x16, #0xf20
    293c:	d61f0220 	br	x17

0000000000002940 <free@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2944:	f9479611 	ldr	x17, [x16, #3880]
    2948:	913ca210 	add	x16, x16, #0xf28
    294c:	d61f0220 	br	x17

0000000000002950 <nanosleep@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2954:	f9479a11 	ldr	x17, [x16, #3888]
    2958:	913cc210 	add	x16, x16, #0xf30
    295c:	d61f0220 	br	x17

0000000000002960 <strchr@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2964:	f9479e11 	ldr	x17, [x16, #3896]
    2968:	913ce210 	add	x16, x16, #0xf38
    296c:	d61f0220 	br	x17

0000000000002970 <strtoull@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2974:	f947a211 	ldr	x17, [x16, #3904]
    2978:	913d0210 	add	x16, x16, #0xf40
    297c:	d61f0220 	br	x17

0000000000002980 <fwrite@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2984:	f947a611 	ldr	x17, [x16, #3912]
    2988:	913d2210 	add	x16, x16, #0xf48
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_create@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2994:	f947aa11 	ldr	x17, [x16, #3920]
    2998:	913d4210 	add	x16, x16, #0xf50
    299c:	d61f0220 	br	x17

00000000000029a0 <munmap@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29a4:	f947ae11 	ldr	x17, [x16, #3928]
    29a8:	913d6210 	add	x16, x16, #0xf58
    29ac:	d61f0220 	br	x17

00000000000029b0 <fflush@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29b4:	f947b211 	ldr	x17, [x16, #3936]
    29b8:	913d8210 	add	x16, x16, #0xf60
    29bc:	d61f0220 	br	x17

00000000000029c0 <strcpy@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29c4:	f947b611 	ldr	x17, [x16, #3944]
    29c8:	913da210 	add	x16, x16, #0xf68
    29cc:	d61f0220 	br	x17

00000000000029d0 <sysconf@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29d4:	f947ba11 	ldr	x17, [x16, #3952]
    29d8:	913dc210 	add	x16, x16, #0xf70
    29dc:	d61f0220 	br	x17

00000000000029e0 <strstr@plt>:
    29e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29e4:	f947be11 	ldr	x17, [x16, #3960]
    29e8:	913de210 	add	x16, x16, #0xf78
    29ec:	d61f0220 	br	x17

00000000000029f0 <_Exit@plt>:
    29f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    29f4:	f947c211 	ldr	x17, [x16, #3968]
    29f8:	913e0210 	add	x16, x16, #0xf80
    29fc:	d61f0220 	br	x17

0000000000002a00 <pthread_join@plt>:
    2a00:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a04:	f947c611 	ldr	x17, [x16, #3976]
    2a08:	913e2210 	add	x16, x16, #0xf88
    2a0c:	d61f0220 	br	x17

0000000000002a10 <getenv@plt>:
    2a10:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a14:	f947ca11 	ldr	x17, [x16, #3984]
    2a18:	913e4210 	add	x16, x16, #0xf90
    2a1c:	d61f0220 	br	x17

0000000000002a20 <__memmove_chk@plt>:
    2a20:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a24:	f947ce11 	ldr	x17, [x16, #3992]
    2a28:	913e6210 	add	x16, x16, #0xf98
    2a2c:	d61f0220 	br	x17

0000000000002a30 <mprotect@plt>:
    2a30:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a34:	f947d211 	ldr	x17, [x16, #4000]
    2a38:	913e8210 	add	x16, x16, #0xfa0
    2a3c:	d61f0220 	br	x17

0000000000002a40 <fgets@plt>:
    2a40:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a44:	f947d611 	ldr	x17, [x16, #4008]
    2a48:	913ea210 	add	x16, x16, #0xfa8
    2a4c:	d61f0220 	br	x17

0000000000002a50 <pthread_attr_setstacksize@plt>:
    2a50:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xc98>
    2a54:	f947da11 	ldr	x17, [x16, #4016]
    2a58:	913ec210 	add	x16, x16, #0xfb0
    2a5c:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a80 <fwp_trap_overflow.constprop.0>:
    2a80:	d10243ff 	sub	sp, sp, #0x90
    2a84:	d2800c03 	mov	x3, #0x60                  	// #96
    2a88:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2a8c:	f947f421 	ldr	x1, [x1, #4072]
    2a90:	f0000025 	adrp	x5, 9000 <__divti3+0x2c0>
    2a94:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a98:	9101c3fd 	add	x29, sp, #0x70
    2a9c:	911ca0a5 	add	x5, x5, #0x728
    2aa0:	f0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    2aa4:	f90043f3 	str	x19, [sp, #128]
    2aa8:	911cc084 	add	x4, x4, #0x730
    2aac:	910023f3 	add	x19, sp, #0x8
    2ab0:	f9400022 	ldr	x2, [x1]
    2ab4:	f90037e2 	str	x2, [sp, #104]
    2ab8:	d2800002 	mov	x2, #0x0                   	// #0
    2abc:	aa0303e1 	mov	x1, x3
    2ac0:	52800042 	mov	w2, #0x2                   	// #2
    2ac4:	aa1303e0 	mov	x0, x19
    2ac8:	97ffff4a 	bl	27f0 <__snprintf_chk@plt>
    2acc:	aa1303e0 	mov	x0, x19
    2ad0:	940004f0 	bl	3e90 <fwp_trap>
    2ad4:	d503201f 	nop
    2ad8:	d503201f 	nop
    2adc:	d503201f 	nop

0000000000002ae0 <main>:
    2ae0:	d10243ff 	sub	sp, sp, #0x90
    2ae4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2ae8:	f947f400 	ldr	x0, [x0, #4072]
    2aec:	a9067bfd 	stp	x29, x30, [sp, #96]
    2af0:	910183fd 	add	x29, sp, #0x60
    2af4:	a90753f3 	stp	x19, x20, [sp, #112]
    2af8:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xc98>
    2afc:	f947ee94 	ldr	x20, [x20, #4056]
    2b00:	f9400282 	ldr	x2, [x20]
    2b04:	f90043f5 	str	x21, [sp, #128]
    2b08:	d00000f5 	adrp	x21, 20000 <__data_start>
    2b0c:	9100c2a1 	add	x1, x21, #0x30
    2b10:	f9400003 	ldr	x3, [x0]
    2b14:	f9002fe3 	str	x3, [sp, #88]
    2b18:	d2800003 	mov	x3, #0x0                   	// #0
    2b1c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x12d20>
    2b20:	910da000 	add	x0, x0, #0x368
    2b24:	f9000422 	str	x2, [x1, #8]
    2b28:	f9003c20 	str	x0, [x1, #120]
    2b2c:	940006f9 	bl	4710 <fwp_now_ns>
    2b30:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2b34:	91262000 	add	x0, x0, #0x988
    2b38:	97ffffb6 	bl	2a10 <getenv@plt>
    2b3c:	b4000080 	cbz	x0, 2b4c <main+0x6c>
    2b40:	39400001 	ldrb	w1, [x0]
    2b44:	aa0003f3 	mov	x19, x0
    2b48:	350008c1 	cbnz	w1, 2c60 <main+0x180>
    2b4c:	910023e1 	add	x1, sp, #0x8
    2b50:	52800000 	mov	w0, #0x0                   	// #0
    2b54:	97ffff17 	bl	27b0 <clock_gettime@plt>
    2b58:	350007e0 	cbnz	w0, 2c54 <main+0x174>
    2b5c:	a9408be0 	ldp	x0, x2, [sp, #8]
    2b60:	d2994003 	mov	x3, #0xca00                	// #51712
    2b64:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2b68:	9b037c01 	mul	x1, x0, x3
    2b6c:	9b437c00 	smulh	x0, x0, x3
    2b70:	ab020021 	adds	x1, x1, x2
    2b74:	937ffc42 	asr	x2, x2, #63
    2b78:	9a020000 	adc	x0, x0, x2
    2b7c:	f100003f 	cmp	x1, #0x0
    2b80:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b84:	b5000620 	cbnz	x0, 2c48 <main+0x168>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b90:	52800002 	mov	w2, #0x0                   	// #0
    2b94:	d2800001 	mov	x1, #0x0                   	// #0
    2b98:	910063f3 	add	x19, sp, #0x18
    2b9c:	97ffff09 	bl	27c0 <setvbuf@plt>
    2ba0:	d2800021 	mov	x1, #0x1                   	// #1
    2ba4:	528001a0 	mov	w0, #0xd                   	// #13
    2ba8:	97ffff0e 	bl	27e0 <signal@plt>
    2bac:	aa1303e0 	mov	x0, x19
    2bb0:	97fffef8 	bl	2790 <pthread_attr_init@plt>
    2bb4:	350007a0 	cbnz	w0, 2ca8 <main+0x1c8>
    2bb8:	aa1303e0 	mov	x0, x19
    2bbc:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2bc0:	97ffffa4 	bl	2a50 <pthread_attr_setstacksize@plt>
    2bc4:	35000660 	cbnz	w0, 2c90 <main+0x1b0>
    2bc8:	aa1303e1 	mov	x1, x19
    2bcc:	910023e0 	add	x0, sp, #0x8
    2bd0:	d0000022 	adrp	x2, 8000 <fwp_write+0xe1c>
    2bd4:	d2800003 	mov	x3, #0x0                   	// #0
    2bd8:	91074042 	add	x2, x2, #0x1d0
    2bdc:	97ffff6d 	bl	2990 <pthread_create@plt>
    2be0:	2a0003e1 	mov	w1, w0
    2be4:	aa1303e0 	mov	x0, x19
    2be8:	2a0103f3 	mov	w19, w1
    2bec:	97ffff11 	bl	2830 <pthread_attr_destroy@plt>
    2bf0:	350006a0 	cbnz	w0, 2cc4 <main+0x1e4>
    2bf4:	35000613 	cbnz	w19, 2cb4 <main+0x1d4>
    2bf8:	f94007e0 	ldr	x0, [sp, #8]
    2bfc:	d2800001 	mov	x1, #0x0                   	// #0
    2c00:	97ffff80 	bl	2a00 <pthread_join@plt>
    2c04:	35000600 	cbnz	w0, 2cc4 <main+0x1e4>
    2c08:	f9400280 	ldr	x0, [x20]
    2c0c:	9100c2b5 	add	x21, x21, #0x30
    2c10:	97ffff68 	bl	29b0 <fflush@plt>
    2c14:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2c18:	f947f421 	ldr	x1, [x1, #4072]
    2c1c:	b94302a0 	ldr	w0, [x21, #768]
    2c20:	f9402fe3 	ldr	x3, [sp, #88]
    2c24:	f9400022 	ldr	x2, [x1]
    2c28:	eb020063 	subs	x3, x3, x2
    2c2c:	d2800002 	mov	x2, #0x0                   	// #0
    2c30:	54000481 	b.ne	2cc0 <main+0x1e0>  // b.any
    2c34:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2c38:	a94753f3 	ldp	x19, x20, [sp, #112]
    2c3c:	f94043f5 	ldr	x21, [sp, #128]
    2c40:	910243ff 	add	sp, sp, #0x90
    2c44:	d65f03c0 	ret
    2c48:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2c4c:	9126e000 	add	x0, x0, #0x9b8
    2c50:	94000490 	bl	3e90 <fwp_trap>
    2c54:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2c58:	91266000 	add	x0, x0, #0x998
    2c5c:	9400048d 	bl	3e90 <fwp_trap>
    2c60:	910003e1 	mov	x1, sp
    2c64:	52800142 	mov	w2, #0xa                   	// #10
    2c68:	97ffff42 	bl	2970 <strtoull@plt>
    2c6c:	f94003e0 	ldr	x0, [sp]
    2c70:	39400000 	ldrb	w0, [x0]
    2c74:	35fff6c0 	cbnz	w0, 2b4c <main+0x6c>
    2c78:	39400260 	ldrb	w0, [x19]
    2c7c:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c80:	5100ac00 	sub	w0, w0, #0x2b
    2c84:	6a01001f 	tst	w0, w1
    2c88:	54fff620 	b.eq	2b4c <main+0x6c>  // b.none
    2c8c:	17ffffbf 	b	2b88 <main+0xa8>
    2c90:	aa1303e0 	mov	x0, x19
    2c94:	97fffee7 	bl	2830 <pthread_attr_destroy@plt>
    2c98:	35000160 	cbnz	w0, 2cc4 <main+0x1e4>
    2c9c:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2ca0:	91284000 	add	x0, x0, #0xa10
    2ca4:	9400047b 	bl	3e90 <fwp_trap>
    2ca8:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2cac:	91278000 	add	x0, x0, #0x9e0
    2cb0:	94000478 	bl	3e90 <fwp_trap>
    2cb4:	f0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    2cb8:	9128e000 	add	x0, x0, #0xa38
    2cbc:	94000475 	bl	3e90 <fwp_trap>
    2cc0:	97fffef0 	bl	2880 <__stack_chk_fail@plt>
    2cc4:	97ffff03 	bl	28d0 <abort@plt>
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop
    2cd0:	d503201f 	nop
    2cd4:	d503201f 	nop
    2cd8:	d503201f 	nop
    2cdc:	d503201f 	nop
    2ce0:	d503201f 	nop
    2ce4:	d503201f 	nop
    2ce8:	d503201f 	nop
    2cec:	d503201f 	nop
    2cf0:	d503201f 	nop
    2cf4:	d503201f 	nop
    2cf8:	d503201f 	nop
    2cfc:	d503201f 	nop

0000000000002d00 <_start>:
    2d00:	d503201f 	nop
    2d04:	d280001d 	mov	x29, #0x0                   	// #0
    2d08:	d280001e 	mov	x30, #0x0                   	// #0
    2d0c:	aa0003e5 	mov	x5, x0
    2d10:	f94003e1 	ldr	x1, [sp]
    2d14:	910023e2 	add	x2, sp, #0x8
    2d18:	910003e6 	mov	x6, sp
    2d1c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d20:	f947f800 	ldr	x0, [x0, #4080]
    2d24:	d2800003 	mov	x3, #0x0                   	// #0
    2d28:	d2800004 	mov	x4, #0x0                   	// #0
    2d2c:	97fffe85 	bl	2740 <__libc_start_main@plt>
    2d30:	97fffee8 	bl	28d0 <abort@plt>

0000000000002d34 <call_weak_fn>:
    2d34:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2d38:	f947f000 	ldr	x0, [x0, #4064]
    2d3c:	b4000040 	cbz	x0, 2d44 <call_weak_fn+0x10>
    2d40:	17fffedc 	b	28b0 <__gmon_start__@plt>
    2d44:	d65f03c0 	ret
    2d48:	d503201f 	nop
    2d4c:	d503201f 	nop

0000000000002d50 <deregister_tm_clones>:
    2d50:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d54:	91006000 	add	x0, x0, #0x18
    2d58:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d5c:	91006021 	add	x1, x1, #0x18
    2d60:	eb00003f 	cmp	x1, x0
    2d64:	540000c0 	b.eq	2d7c <deregister_tm_clones+0x2c>  // b.none
    2d68:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2d6c:	f947e021 	ldr	x1, [x1, #4032]
    2d70:	b4000061 	cbz	x1, 2d7c <deregister_tm_clones+0x2c>
    2d74:	aa0103f0 	mov	x16, x1
    2d78:	d61f0200 	br	x16
    2d7c:	d65f03c0 	ret

0000000000002d80 <register_tm_clones>:
    2d80:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d84:	91006000 	add	x0, x0, #0x18
    2d88:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d8c:	91006021 	add	x1, x1, #0x18
    2d90:	cb000021 	sub	x1, x1, x0
    2d94:	d37ffc22 	lsr	x2, x1, #63
    2d98:	8b810c41 	add	x1, x2, x1, asr #3
    2d9c:	9341fc21 	asr	x1, x1, #1
    2da0:	b40000c1 	cbz	x1, 2db8 <register_tm_clones+0x38>
    2da4:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    2da8:	f947fc42 	ldr	x2, [x2, #4088]
    2dac:	b4000062 	cbz	x2, 2db8 <register_tm_clones+0x38>
    2db0:	aa0203f0 	mov	x16, x2
    2db4:	d61f0200 	br	x16
    2db8:	d65f03c0 	ret
    2dbc:	d503201f 	nop

0000000000002dc0 <__do_global_dtors_aux>:
    2dc0:	d503233f 	paciasp
    2dc4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2dc8:	910003fd 	mov	x29, sp
    2dcc:	f9000bf3 	str	x19, [sp, #16]
    2dd0:	d00000f3 	adrp	x19, 20000 <__data_start>
    2dd4:	39408260 	ldrb	w0, [x19, #32]
    2dd8:	37000140 	tbnz	w0, #0, 2e00 <__do_global_dtors_aux+0x40>
    2ddc:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    2de0:	f947e400 	ldr	x0, [x0, #4040]
    2de4:	b4000080 	cbz	x0, 2df4 <__do_global_dtors_aux+0x34>
    2de8:	d00000e0 	adrp	x0, 20000 <__data_start>
    2dec:	f9400400 	ldr	x0, [x0, #8]
    2df0:	97fffe60 	bl	2770 <__cxa_finalize@plt>
    2df4:	97ffffd7 	bl	2d50 <deregister_tm_clones>
    2df8:	52800020 	mov	w0, #0x1                   	// #1
    2dfc:	39008260 	strb	w0, [x19, #32]
    2e00:	f9400bf3 	ldr	x19, [sp, #16]
    2e04:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2e08:	d50323bf 	autiasp
    2e0c:	d65f03c0 	ret

0000000000002e10 <frame_dummy>:
    2e10:	d503245f 	bti	c
    2e14:	17ffffdb 	b	2d80 <register_tm_clones>
    2e18:	d503201f 	nop
    2e1c:	d503201f 	nop

0000000000002e20 <fwp_fmt_u128>:
    2e20:	d10183ff 	sub	sp, sp, #0x60
    2e24:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e28:	f947f421 	ldr	x1, [x1, #4072]
    2e2c:	a9057bfd 	stp	x29, x30, [sp, #80]
    2e30:	910143fd 	add	x29, sp, #0x50
    2e34:	f9400024 	ldr	x4, [x1]
    2e38:	f90027e4 	str	x4, [sp, #72]
    2e3c:	d2800004 	mov	x4, #0x0                   	// #0
    2e40:	aa030041 	orr	x1, x2, x3
    2e44:	b5000361 	cbnz	x1, 2eb0 <fwp_fmt_u128+0x90>
    2e48:	910023e9 	add	x9, sp, #0x8
    2e4c:	52800601 	mov	w1, #0x30                  	// #48
    2e50:	5280002d 	mov	w13, #0x1                   	// #1
    2e54:	390023e1 	strb	w1, [sp, #8]
    2e58:	93407dad 	sxtw	x13, w13
    2e5c:	aa0d03e1 	mov	x1, x13
    2e60:	8b0d0004 	add	x4, x0, x13
    2e64:	d503201f 	nop
    2e68:	8b010123 	add	x3, x9, x1
    2e6c:	cb0103e2 	neg	x2, x1
    2e70:	d1000421 	sub	x1, x1, #0x1
    2e74:	385ff063 	ldurb	w3, [x3, #-1]
    2e78:	38226883 	strb	w3, [x4, x2]
    2e7c:	35ffff61 	cbnz	w1, 2e68 <fwp_fmt_u128+0x48>
    2e80:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    2e84:	f947f421 	ldr	x1, [x1, #4072]
    2e88:	382d681f 	strb	wzr, [x0, x13]
    2e8c:	aa0103e0 	mov	x0, x1
    2e90:	f94027e2 	ldr	x2, [sp, #72]
    2e94:	f9400001 	ldr	x1, [x0]
    2e98:	eb010042 	subs	x2, x2, x1
    2e9c:	d2800001 	mov	x1, #0x0                   	// #0
    2ea0:	54000561 	b.ne	2f4c <fwp_fmt_u128+0x12c>  // b.any
    2ea4:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2ea8:	910183ff 	add	sp, sp, #0x60
    2eac:	d65f03c0 	ret
    2eb0:	90000041 	adrp	x1, a000 <_IO_stdin_used+0xba0>
    2eb4:	91014021 	add	x1, x1, #0x50
    2eb8:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2ebc:	910023e9 	add	x9, sp, #0x8
    2ec0:	d2800027 	mov	x7, #0x1                   	// #1
    2ec4:	f29999af 	movk	x15, #0xcccd
    2ec8:	a9402826 	ldp	x6, x10, [x1]
    2ecc:	d503201f 	nop
    2ed0:	ab030041 	adds	x1, x2, x3
    2ed4:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2ed8:	aa0303eb 	mov	x11, x3
    2edc:	8b070128 	add	x8, x9, x7
    2ee0:	aa0203ee 	mov	x14, x2
    2ee4:	aa0703ed 	mov	x13, x7
    2ee8:	910004e7 	add	x7, x7, #0x1
    2eec:	9bcf7c24 	umulh	x4, x1, x15
    2ef0:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2ef4:	8b4408a4 	add	x4, x5, x4, lsr #2
    2ef8:	cb040021 	sub	x1, x1, x4
    2efc:	eb010041 	subs	x1, x2, x1
    2f00:	da1f0063 	sbc	x3, x3, xzr
    2f04:	9bc67c24 	umulh	x4, x1, x6
    2f08:	9b061064 	madd	x4, x3, x6, x4
    2f0c:	9b067c2c 	mul	x12, x1, x6
    2f10:	9b0a1024 	madd	x4, x1, x10, x4
    2f14:	9bc67c25 	umulh	x5, x1, x6
    2f18:	9b061465 	madd	x5, x3, x6, x5
    2f1c:	9b0a1425 	madd	x5, x1, x10, x5
    2f20:	93cc0484 	extr	x4, x4, x12, #1
    2f24:	8b040884 	add	x4, x4, x4, lsl #2
    2f28:	d341fca3 	lsr	x3, x5, #1
    2f2c:	cb040444 	sub	x4, x2, x4, lsl #1
    2f30:	93cc04a2 	extr	x2, x5, x12, #1
    2f34:	1100c084 	add	w4, w4, #0x30
    2f38:	381ff104 	sturb	w4, [x8, #-1]
    2f3c:	b5fffcab 	cbnz	x11, 2ed0 <fwp_fmt_u128+0xb0>
    2f40:	f10025df 	cmp	x14, #0x9
    2f44:	54fffc68 	b.hi	2ed0 <fwp_fmt_u128+0xb0>  // b.pmore
    2f48:	17ffffc4 	b	2e58 <fwp_fmt_u128+0x38>
    2f4c:	97fffe4d 	bl	2880 <__stack_chk_fail@plt>

0000000000002f50 <fwp_range_release>:
    2f50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2f54:	910003fd 	mov	x29, sp
    2f58:	f9400801 	ldr	x1, [x0, #16]
    2f5c:	f9000bf3 	str	x19, [sp, #16]
    2f60:	aa0003f3 	mov	x19, x0
    2f64:	b4000061 	cbz	x1, 2f70 <fwp_range_release+0x20>
    2f68:	f9400400 	ldr	x0, [x0, #8]
    2f6c:	d63f0020 	blr	x1
    2f70:	f9400260 	ldr	x0, [x19]
    2f74:	f9400e61 	ldr	x1, [x19, #24]
    2f78:	f9400bf3 	ldr	x19, [sp, #16]
    2f7c:	aa0103f0 	mov	x16, x1
    2f80:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f84:	d61f0200 	br	x16
    2f88:	d503201f 	nop
    2f8c:	d503201f 	nop

0000000000002f90 <fwp_tape_unlink_scope>:
    2f90:	f9402803 	ldr	x3, [x0, #80]
    2f94:	b4000223 	cbz	x3, 2fd8 <fwp_tape_unlink_scope+0x48>
    2f98:	294b0402 	ldp	w2, w1, [x0, #88]
    2f9c:	37f80202 	tbnz	w2, #31, 2fdc <fwp_tape_unlink_scope+0x4c>
    2fa0:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa4:	52800d03 	mov	w3, #0x68                  	// #104
    2fa8:	f9401884 	ldr	x4, [x4, #48]
    2fac:	9b231043 	smaddl	x3, w2, w3, x4
    2fb0:	b9005c61 	str	w1, [x3, #92]
    2fb4:	37f800c1 	tbnz	w1, #31, 2fcc <fwp_tape_unlink_scope+0x3c>
    2fb8:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fbc:	52800d04 	mov	w4, #0x68                  	// #104
    2fc0:	f9401863 	ldr	x3, [x3, #48]
    2fc4:	9b240c21 	smaddl	x1, w1, w4, x3
    2fc8:	b9005822 	str	w2, [x1, #88]
    2fcc:	2f000400 	mvni	v0.2s, #0x0
    2fd0:	f900281f 	str	xzr, [x0, #80]
    2fd4:	fd002c00 	str	d0, [x0, #88]
    2fd8:	d65f03c0 	ret
    2fdc:	b9000061 	str	w1, [x3]
    2fe0:	17fffff5 	b	2fb4 <fwp_tape_unlink_scope+0x24>

0000000000002fe4 <fwp_args173>:
    2fe4:	d65f03c0 	ret
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_flush>:
    2ff0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff4:	f9401c00 	ldr	x0, [x0, #56]
    2ff8:	b4000120 	cbz	x0, 301c <fwp_flush+0x2c>
    2ffc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3000:	910003fd 	mov	x29, sp
    3004:	97fffe6b 	bl	29b0 <fflush@plt>
    3008:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    300c:	f947ec00 	ldr	x0, [x0, #4056]
    3010:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3014:	f9400000 	ldr	x0, [x0]
    3018:	17fffe66 	b	29b0 <fflush@plt>
    301c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3020:	f947ec00 	ldr	x0, [x0, #4056]
    3024:	f9400000 	ldr	x0, [x0]
    3028:	17fffe62 	b	29b0 <fflush@plt>
    302c:	d503201f 	nop

0000000000003030 <fwp_heap_oom>:
    3030:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    3034:	f947e863 	ldr	x3, [x3, #4048]
    3038:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    303c:	d2800262 	mov	x2, #0x13                  	// #19
    3040:	910003fd 	mov	x29, sp
    3044:	f9400063 	ldr	x3, [x3]
    3048:	d2800021 	mov	x1, #0x1                   	// #1
    304c:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3050:	9111a000 	add	x0, x0, #0x468
    3054:	97fffe4b 	bl	2980 <fwrite@plt>
    3058:	d2800000 	mov	x0, #0x0                   	// #0
    305c:	97fffe55 	bl	29b0 <fflush@plt>
    3060:	52800cc0 	mov	w0, #0x66                  	// #102
    3064:	97fffe63 	bl	29f0 <_Exit@plt>
    3068:	d503201f 	nop
    306c:	d503201f 	nop

0000000000003070 <fwp_segv>:
    3070:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3074:	b00000e2 	adrp	x2, 20000 <__data_start>
    3078:	9100c043 	add	x3, x2, #0x30
    307c:	910003fd 	mov	x29, sp
    3080:	a90153f3 	stp	x19, x20, [sp, #16]
    3084:	2a0003f3 	mov	w19, w0
    3088:	f9400860 	ldr	x0, [x3, #16]
    308c:	f90013f5 	str	x21, [sp, #32]
    3090:	f9400835 	ldr	x21, [x1, #16]
    3094:	b4000280 	cbz	x0, 30e4 <fwp_segv+0x74>
    3098:	f9400814 	ldr	x20, [x0, #16]
    309c:	b4000254 	cbz	x20, 30e4 <fwp_segv+0x74>
    30a0:	528003c0 	mov	w0, #0x1e                  	// #30
    30a4:	97fffe4b 	bl	29d0 <sysconf@plt>
    30a8:	f144029f 	cmp	x20, #0x100, lsl #12
    30ac:	d2a00201 	mov	x1, #0x100000              	// #1048576
    30b0:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    30b4:	8b000294 	add	x20, x20, x0
    30b8:	d1440021 	sub	x1, x1, #0x100, lsl #12
    30bc:	eb0102bf 	cmp	x21, x1
    30c0:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    30c4:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30c8:	35000240 	cbnz	w0, 3110 <fwp_segv+0xa0>
    30cc:	f94013f5 	ldr	x21, [sp, #32]
    30d0:	2a1303e0 	mov	w0, w19
    30d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    30d8:	d2800001 	mov	x1, #0x0                   	// #0
    30dc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30e0:	17fffdc0 	b	27e0 <signal@plt>
    30e4:	9100c042 	add	x2, x2, #0x30
    30e8:	f9400c40 	ldr	x0, [x2, #24]
    30ec:	b4ffff00 	cbz	x0, 30cc <fwp_segv+0x5c>
    30f0:	f9401041 	ldr	x1, [x2, #32]
    30f4:	cb010000 	sub	x0, x0, x1
    30f8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30fc:	91440000 	add	x0, x0, #0x100, lsl #12
    3100:	eb15003f 	cmp	x1, x21
    3104:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    3108:	1a9f97e0 	cset	w0, hi	// hi = pmore
    310c:	34fffe00 	cbz	w0, 30cc <fwp_segv+0x5c>
    3110:	97ffffb8 	bl	2ff0 <fwp_flush>
    3114:	f0000021 	adrp	x1, a000 <_IO_stdin_used+0xba0>
    3118:	9100c021 	add	x1, x1, #0x30
    311c:	d2800342 	mov	x2, #0x1a                  	// #26
    3120:	52800040 	mov	w0, #0x2                   	// #2
    3124:	97fffde7 	bl	28c0 <write@plt>
    3128:	52800ca0 	mov	w0, #0x65                  	// #101
    312c:	97fffd75 	bl	2700 <_exit@plt>

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    3144:	9114c2a1 	add	x1, x21, #0x530
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    3158:	912480a5 	add	x5, x5, #0x920
    315c:	9114c2a1 	add	x1, x21, #0x530
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	9114c2b7 	add	x23, x21, #0x530
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffe08 	bl	2a30 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffded 	bl	29d0 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdf6 	bl	2a30 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	9114c2b5 	add	x21, x21, #0x530
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	9114c2b5 	add	x21, x21, #0x530
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f0000165 	adrp	x5, 32000 <fwp_heap+0xad0>
    32e8:	912460a5 	add	x5, x5, #0x918
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff4d 	bl	3030 <fwp_heap_oom>

0000000000003300 <fwp_tape_buffers_dispose>:
    3300:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3304:	910003fd 	mov	x29, sp
    3308:	f9000bf3 	str	x19, [sp, #16]
    330c:	aa0003f3 	mov	x19, x0
    3310:	f9400000 	ldr	x0, [x0]
    3314:	97fffd8b 	bl	2940 <free@plt>
    3318:	f9400a60 	ldr	x0, [x19, #16]
    331c:	97fffd89 	bl	2940 <free@plt>
    3320:	f9401260 	ldr	x0, [x19, #32]
    3324:	97fffd87 	bl	2940 <free@plt>
    3328:	f9001a7f 	str	xzr, [x19, #48]
    332c:	4f000400 	movi	v0.4s, #0x0
    3330:	ad000260 	stp	q0, q0, [x19]
    3334:	3d800a60 	str	q0, [x19, #32]
    3338:	f9400bf3 	ldr	x19, [sp, #16]
    333c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3340:	d65f03c0 	ret

0000000000003344 <buf_grow>:
    3344:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3348:	910003fd 	mov	x29, sp
    334c:	a90153f3 	stp	x19, x20, [sp, #16]
    3350:	aa0003f4 	mov	x20, x0
    3354:	f9400400 	ldr	x0, [x0, #8]
    3358:	b100041f 	cmn	x0, #0x1
    335c:	54000400 	b.eq	33dc <buf_grow+0x98>  // b.none
    3360:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3364:	cb000042 	sub	x2, x2, x0
    3368:	eb01005f 	cmp	x2, x1
    336c:	54000383 	b.cc	33dc <buf_grow+0x98>  // b.lo, b.ul, b.last
    3370:	f9400a82 	ldr	x2, [x20, #16]
    3374:	91000421 	add	x1, x1, #0x1
    3378:	8b000033 	add	x19, x1, x0
    337c:	eb13005f 	cmp	x2, x19
    3380:	54000242 	b.cs	33c8 <buf_grow+0x84>  // b.hs, b.nlast
    3384:	f100005f 	cmp	x2, #0x0
    3388:	b5000262 	cbnz	x2, 33d4 <buf_grow+0x90>
    338c:	d2800802 	mov	x2, #0x40                  	// #64
    3390:	eb02027f 	cmp	x19, x2
    3394:	54000068 	b.hi	33a0 <buf_grow+0x5c>  // b.pmore
    3398:	14000005 	b	33ac <buf_grow+0x68>
    339c:	b7f800a2 	tbnz	x2, #63, 33b0 <buf_grow+0x6c>
    33a0:	d37ff842 	lsl	x2, x2, #1
    33a4:	eb02027f 	cmp	x19, x2
    33a8:	54ffffa8 	b.hi	339c <buf_grow+0x58>  // b.pmore
    33ac:	aa0203f3 	mov	x19, x2
    33b0:	f9400280 	ldr	x0, [x20]
    33b4:	aa1303e1 	mov	x1, x19
    33b8:	97fffd2e 	bl	2870 <realloc@plt>
    33bc:	b4000100 	cbz	x0, 33dc <buf_grow+0x98>
    33c0:	f9000280 	str	x0, [x20]
    33c4:	f9000a93 	str	x19, [x20, #16]
    33c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    33cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    33d0:	d65f03c0 	ret
    33d4:	54fffe6a 	b.ge	33a0 <buf_grow+0x5c>  // b.tcont
    33d8:	17fffff6 	b	33b0 <buf_grow+0x6c>
    33dc:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    33e0:	f947e863 	ldr	x3, [x3, #4048]
    33e4:	d2800262 	mov	x2, #0x13                  	// #19
    33e8:	d2800021 	mov	x1, #0x1                   	// #1
    33ec:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    33f0:	9111a000 	add	x0, x0, #0x468
    33f4:	f9400063 	ldr	x3, [x3]
    33f8:	97fffd62 	bl	2980 <fwrite@plt>
    33fc:	d2800000 	mov	x0, #0x0                   	// #0
    3400:	97fffd6c 	bl	29b0 <fflush@plt>
    3404:	52800cc0 	mov	w0, #0x66                  	// #102
    3408:	97fffd7a 	bl	29f0 <_Exit@plt>
    340c:	d503201f 	nop

0000000000003410 <buf_put>:
    3410:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3414:	910003fd 	mov	x29, sp
    3418:	a90153f3 	stp	x19, x20, [sp, #16]
    341c:	aa0003f4 	mov	x20, x0
    3420:	aa0203f3 	mov	x19, x2
    3424:	f90013f5 	str	x21, [sp, #32]
    3428:	aa0103f5 	mov	x21, x1
    342c:	aa0203e1 	mov	x1, x2
    3430:	97ffffc5 	bl	3344 <buf_grow>
    3434:	a9400283 	ldp	x3, x0, [x20]
    3438:	aa1503e1 	mov	x1, x21
    343c:	aa1303e2 	mov	x2, x19
    3440:	8b000060 	add	x0, x3, x0
    3444:	97fffca3 	bl	26d0 <memcpy@plt>
    3448:	a9400680 	ldp	x0, x1, [x20]
    344c:	8b010273 	add	x19, x19, x1
    3450:	f9000693 	str	x19, [x20, #8]
    3454:	3833681f 	strb	wzr, [x0, x19]
    3458:	a94153f3 	ldp	x19, x20, [sp, #16]
    345c:	f94013f5 	ldr	x21, [sp, #32]
    3460:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3464:	d65f03c0 	ret
    3468:	d503201f 	nop
    346c:	d503201f 	nop

0000000000003470 <fwp_cancel_tree.part.0>:
    3470:	b00000e1 	adrp	x1, 20000 <__data_start>
    3474:	9100c022 	add	x2, x1, #0x30
    3478:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    347c:	52800023 	mov	w3, #0x1                   	// #1
    3480:	910003fd 	mov	x29, sp
    3484:	f9400844 	ldr	x4, [x2, #16]
    3488:	f9000bf3 	str	x19, [sp, #16]
    348c:	39014403 	strb	w3, [x0, #81]
    3490:	eb04001f 	cmp	x0, x4
    3494:	54000160 	b.eq	34c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3498:	f9402804 	ldr	x4, [x0, #80]
    349c:	f2001c9f 	tst	x4, #0xff000000ff
    34a0:	54000101 	b.ne	34c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    34a4:	f9401444 	ldr	x4, [x2, #40]
    34a8:	39015003 	strb	w3, [x0, #84]
    34ac:	f900801f 	str	xzr, [x0, #256]
    34b0:	b40001e4 	cbz	x4, 34ec <fwp_cancel_tree.part.0+0x7c>
    34b4:	f9008080 	str	x0, [x4, #256]
    34b8:	9100c021 	add	x1, x1, #0x30
    34bc:	f9001420 	str	x0, [x1, #40]
    34c0:	f9401413 	ldr	x19, [x0, #40]
    34c4:	b40000f3 	cbz	x19, 34e0 <fwp_cancel_tree.part.0+0x70>
    34c8:	39414261 	ldrb	w1, [x19, #80]
    34cc:	aa1303e0 	mov	x0, x19
    34d0:	37000041 	tbnz	w1, #0, 34d8 <fwp_cancel_tree.part.0+0x68>
    34d4:	97ffffe7 	bl	3470 <fwp_cancel_tree.part.0>
    34d8:	f9401a73 	ldr	x19, [x19, #48]
    34dc:	b5ffff73 	cbnz	x19, 34c8 <fwp_cancel_tree.part.0+0x58>
    34e0:	f9400bf3 	ldr	x19, [sp, #16]
    34e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    34e8:	d65f03c0 	ret
    34ec:	f9001840 	str	x0, [x2, #48]
    34f0:	17fffff2 	b	34b8 <fwp_cancel_tree.part.0+0x48>

00000000000034f4 <fwp_finish_float>:
    34f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    34f8:	528005c1 	mov	w1, #0x2e                  	// #46
    34fc:	910003fd 	mov	x29, sp
    3500:	f9000bf3 	str	x19, [sp, #16]
    3504:	aa0003f3 	mov	x19, x0
    3508:	97fffd16 	bl	2960 <strchr@plt>
    350c:	b4000080 	cbz	x0, 351c <fwp_finish_float+0x28>
    3510:	f9400bf3 	ldr	x19, [sp, #16]
    3514:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3518:	d65f03c0 	ret
    351c:	aa1303e0 	mov	x0, x19
    3520:	52800ca1 	mov	w1, #0x65                  	// #101
    3524:	97fffd0f 	bl	2960 <strchr@plt>
    3528:	b5ffff40 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    352c:	d0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    3530:	aa1303e0 	mov	x0, x19
    3534:	91120021 	add	x1, x1, #0x480
    3538:	97fffd2a 	bl	29e0 <strstr@plt>
    353c:	b5fffea0 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3540:	d0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    3544:	aa1303e0 	mov	x0, x19
    3548:	91122021 	add	x1, x1, #0x488
    354c:	97fffd25 	bl	29e0 <strstr@plt>
    3550:	b5fffe00 	cbnz	x0, 3510 <fwp_finish_float+0x1c>
    3554:	aa1303e0 	mov	x0, x19
    3558:	97fffc6e 	bl	2710 <strlen@plt>
    355c:	d0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    3560:	91124021 	add	x1, x1, #0x490
    3564:	8b000262 	add	x2, x19, x0
    3568:	79400023 	ldrh	w3, [x1]
    356c:	39400821 	ldrb	w1, [x1, #2]
    3570:	78206a63 	strh	w3, [x19, x0]
    3574:	39000841 	strb	w1, [x2, #2]
    3578:	17ffffe6 	b	3510 <fwp_finish_float+0x1c>
    357c:	d503201f 	nop

0000000000003580 <fwp_format_g.constprop.0>:
    3580:	d10483ff 	sub	sp, sp, #0x120
    3584:	d0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    3588:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    358c:	f947f442 	ldr	x2, [x2, #4072]
    3590:	91126084 	add	x4, x4, #0x498
    3594:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3598:	9102c3fd 	add	x29, sp, #0xb0
    359c:	d2800803 	mov	x3, #0x40                  	// #64
    35a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    35a4:	93407c38 	sxtw	x24, w1
    35a8:	aa0303e1 	mov	x1, x3
    35ac:	fd008be8 	str	d8, [sp, #272]
    35b0:	1e604008 	fmov	d8, d0
    35b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    35b8:	910083f4 	add	x20, sp, #0x20
    35bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    35c0:	aa0003f5 	mov	x21, x0
    35c4:	a91073fb 	stp	x27, x28, [sp, #256]
    35c8:	5100071c 	sub	w28, w24, #0x1
    35cc:	2a1c03e5 	mov	w5, w28
    35d0:	f9400040 	ldr	x0, [x2]
    35d4:	f90057e0 	str	x0, [sp, #168]
    35d8:	d2800000 	mov	x0, #0x0                   	// #0
    35dc:	52800042 	mov	w2, #0x2                   	// #2
    35e0:	aa1403e0 	mov	x0, x20
    35e4:	97fffc83 	bl	27f0 <__snprintf_chk@plt>
    35e8:	52800ca1 	mov	w1, #0x65                  	// #101
    35ec:	aa1403e0 	mov	x0, x20
    35f0:	97fffcdc 	bl	2960 <strchr@plt>
    35f4:	aa0003f3 	mov	x19, x0
    35f8:	52800142 	mov	w2, #0xa                   	// #10
    35fc:	91000400 	add	x0, x0, #0x1
    3600:	d2800001 	mov	x1, #0x0                   	// #0
    3604:	97fffcc7 	bl	2920 <strtol@plt>
    3608:	aa0003f7 	mov	x23, x0
    360c:	11001400 	add	w0, w0, #0x5
    3610:	7100541f 	cmp	w0, #0x15
    3614:	54000d68 	b.hi	37c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3618:	4b170385 	sub	w5, w28, w23
    361c:	710000bf 	cmp	w5, #0x0
    3620:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3624:	54000b80 	b.eq	3794 <fwp_format_g.constprop.0+0x214>  // b.none
    3628:	394083e0 	ldrb	w0, [sp, #32]
    362c:	cb180273 	sub	x19, x19, x24
    3630:	91000673 	add	x19, x19, #0x1
    3634:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3638:	7100b41f 	cmp	w0, #0x2d
    363c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3640:	1a9f17e4 	cset	w4, eq	// eq = none
    3644:	cb010266 	sub	x6, x19, x1
    3648:	d10004da 	sub	x26, x6, #0x1
    364c:	540018a0 	b.eq	3960 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3650:	910183f9 	add	x25, sp, #0x60
    3654:	d280091b 	mov	x27, #0x48                  	// #72
    3658:	aa1903e7 	mov	x7, x25
    365c:	91000423 	add	x3, x1, #0x1
    3660:	91011cc6 	add	x6, x6, #0x47
    3664:	910004f6 	add	x22, x7, #0x1
    3668:	37f80ff7 	tbnz	w23, #31, 3864 <fwp_format_g.constprop.0+0x2e4>
    366c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3670:	93407ef7 	sxtw	x23, w23
    3674:	390000e4 	strb	w4, [x7]
    3678:	aa1303e1 	mov	x1, x19
    367c:	aa1703e2 	mov	x2, x23
    3680:	aa1603e0 	mov	x0, x22
    3684:	b9000be5 	str	w5, [sp, #8]
    3688:	cb170374 	sub	x20, x27, x23
    368c:	a9011be3 	stp	x3, x6, [sp, #16]
    3690:	97fffc10 	bl	26d0 <memcpy@plt>
    3694:	d1000694 	sub	x20, x20, #0x1
    3698:	f9400be3 	ldr	x3, [sp, #16]
    369c:	8b1702d6 	add	x22, x22, x23
    36a0:	aa1603e0 	mov	x0, x22
    36a4:	aa1a03e2 	mov	x2, x26
    36a8:	aa0303e1 	mov	x1, x3
    36ac:	aa1403e3 	mov	x3, x20
    36b0:	97fffc48 	bl	27d0 <__memcpy_chk@plt>
    36b4:	8b1a02d6 	add	x22, x22, x26
    36b8:	f9400fe6 	ldr	x6, [sp, #24]
    36bc:	d2800900 	mov	x0, #0x48                  	// #72
    36c0:	b9400be5 	ldr	w5, [sp, #8]
    36c4:	8b170261 	add	x1, x19, x23
    36c8:	cb1400c3 	sub	x3, x6, x20
    36cc:	cb060294 	sub	x20, x20, x6
    36d0:	f101207f 	cmp	x3, #0x48
    36d4:	93407cb8 	sxtw	x24, w5
    36d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    36dc:	aa1803e2 	mov	x2, x24
    36e0:	8b1802d3 	add	x19, x22, x24
    36e4:	8b140063 	add	x3, x3, x20
    36e8:	aa1603e0 	mov	x0, x22
    36ec:	97fffc39 	bl	27d0 <__memcpy_chk@plt>
    36f0:	cb190273 	sub	x19, x19, x25
    36f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    36f8:	eb00027f 	cmp	x19, x0
    36fc:	aa1903e1 	mov	x1, x25
    3700:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3704:	aa1503e0 	mov	x0, x21
    3708:	aa1303e2 	mov	x2, x19
    370c:	97fffbf1 	bl	26d0 <memcpy@plt>
    3710:	38336abf 	strb	wzr, [x21, x19]
    3714:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3718:	aa1503e0 	mov	x0, x21
    371c:	97fffbfd 	bl	2710 <strlen@plt>
    3720:	aa0003f3 	mov	x19, x0
    3724:	528005c1 	mov	w1, #0x2e                  	// #46
    3728:	aa1503e0 	mov	x0, x21
    372c:	97fffc8d 	bl	2960 <strchr@plt>
    3730:	b4000140 	cbz	x0, 3758 <fwp_format_g.constprop.0+0x1d8>
    3734:	b4000133 	cbz	x19, 3758 <fwp_format_g.constprop.0+0x1d8>
    3738:	aa1303e1 	mov	x1, x19
    373c:	d1000673 	sub	x19, x19, #0x1
    3740:	38736aa0 	ldrb	w0, [x21, x19]
    3744:	7100c01f 	cmp	w0, #0x30
    3748:	54001001 	b.ne	3948 <fwp_format_g.constprop.0+0x3c8>  // b.any
    374c:	38336abf 	strb	wzr, [x21, x19]
    3750:	b5ffff53 	cbnz	x19, 3738 <fwp_format_g.constprop.0+0x1b8>
    3754:	d503201f 	nop
    3758:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    375c:	f947f400 	ldr	x0, [x0, #4072]
    3760:	f94057e2 	ldr	x2, [sp, #168]
    3764:	f9400001 	ldr	x1, [x0]
    3768:	eb010042 	subs	x2, x2, x1
    376c:	d2800001 	mov	x1, #0x0                   	// #0
    3770:	54001061 	b.ne	397c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3774:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3778:	a94c53f3 	ldp	x19, x20, [sp, #192]
    377c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3780:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3784:	a95073fb 	ldp	x27, x28, [sp, #256]
    3788:	fd408be8 	ldr	d8, [sp, #272]
    378c:	910483ff 	add	sp, sp, #0x120
    3790:	d65f03c0 	ret
    3794:	1e604100 	fmov	d0, d8
    3798:	710000bf 	cmp	w5, #0x0
    379c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    37a0:	aa1503e0 	mov	x0, x21
    37a4:	d0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    37a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    37ac:	9112c084 	add	x4, x4, #0x4b0
    37b0:	52800042 	mov	w2, #0x2                   	// #2
    37b4:	d2803201 	mov	x1, #0x190                 	// #400
    37b8:	97fffc0e 	bl	27f0 <__snprintf_chk@plt>
    37bc:	17ffffd7 	b	3718 <fwp_format_g.constprop.0+0x198>
    37c0:	cb140273 	sub	x19, x19, x20
    37c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    37c8:	910183f9 	add	x25, sp, #0x60
    37cc:	aa1303e2 	mov	x2, x19
    37d0:	aa1403e1 	mov	x1, x20
    37d4:	aa1903e0 	mov	x0, x25
    37d8:	d2800803 	mov	x3, #0x40                  	// #64
    37dc:	97fffbfd 	bl	27d0 <__memcpy_chk@plt>
    37e0:	38336b3f 	strb	wzr, [x25, x19]
    37e4:	aa1903e0 	mov	x0, x25
    37e8:	528005c1 	mov	w1, #0x2e                  	// #46
    37ec:	97fffc5d 	bl	2960 <strchr@plt>
    37f0:	b40001c0 	cbz	x0, 3828 <fwp_format_g.constprop.0+0x2a8>
    37f4:	b50000b3 	cbnz	x19, 3808 <fwp_format_g.constprop.0+0x288>
    37f8:	1400000c 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    37fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3800:	f1000673 	subs	x19, x19, #0x1
    3804:	54000120 	b.eq	3828 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3808:	8b130320 	add	x0, x25, x19
    380c:	385ff001 	ldurb	w1, [x0, #-1]
    3810:	7100c03f 	cmp	w1, #0x30
    3814:	54ffff40 	b.eq	37fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3818:	d1000673 	sub	x19, x19, #0x1
    381c:	38736b20 	ldrb	w0, [x25, x19]
    3820:	7100b81f 	cmp	w0, #0x2e
    3824:	54000a80 	b.eq	3974 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3828:	710002ff 	cmp	w23, #0x0
    382c:	528005a1 	mov	w1, #0x2d                  	// #45
    3830:	aa1903e5 	mov	x5, x25
    3834:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3838:	aa1503e0 	mov	x0, x21
    383c:	52800566 	mov	w6, #0x2b                  	// #43
    3840:	d0000024 	adrp	x4, 9000 <__divti3+0x2c0>
    3844:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3848:	91128084 	add	x4, x4, #0x4a0
    384c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3850:	52800042 	mov	w2, #0x2                   	// #2
    3854:	d2803201 	mov	x1, #0x190                 	// #400
    3858:	97fffbe6 	bl	27f0 <__snprintf_chk@plt>
    385c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3860:	17ffffbe 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3864:	52800605 	mov	w5, #0x30                  	// #48
    3868:	390000e5 	strb	w5, [x7]
    386c:	d100077b 	sub	x27, x27, #0x1
    3870:	aa0303e1 	mov	x1, x3
    3874:	aa1603e0 	mov	x0, x22
    3878:	aa1b03e3 	mov	x3, x27
    387c:	aa1a03e2 	mov	x2, x26
    3880:	f90007e6 	str	x6, [sp, #8]
    3884:	b90013e4 	str	w4, [sp, #16]
    3888:	8b1a02d6 	add	x22, x22, x26
    388c:	b9001be5 	str	w5, [sp, #24]
    3890:	97fffbd0 	bl	27d0 <__memcpy_chk@plt>
    3894:	f94007e6 	ldr	x6, [sp, #8]
    3898:	2a3703e7 	mvn	w7, w23
    389c:	b94013e4 	ldr	w4, [sp, #16]
    38a0:	cb1b00c1 	sub	x1, x6, x27
    38a4:	cb06037b 	sub	x27, x27, x6
    38a8:	f101203f 	cmp	x1, #0x48
    38ac:	d2800906 	mov	x6, #0x48                  	// #72
    38b0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    38b4:	8b1b0023 	add	x3, x1, x27
    38b8:	310006ff 	cmn	w23, #0x1
    38bc:	54000220 	b.eq	3900 <fwp_format_g.constprop.0+0x380>  // b.none
    38c0:	b9401be5 	ldr	w5, [sp, #24]
    38c4:	d2800001 	mov	x1, #0x0                   	// #0
    38c8:	f101207f 	cmp	x3, #0x48
    38cc:	d1000462 	sub	x2, x3, #0x1
    38d0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    38d4:	38216ac5 	strb	w5, [x22, x1]
    38d8:	cb030003 	sub	x3, x0, x3
    38dc:	91000421 	add	x1, x1, #0x1
    38e0:	91000463 	add	x3, x3, #0x1
    38e4:	eb00007f 	cmp	x3, x0
    38e8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38ec:	cb000063 	sub	x3, x3, x0
    38f0:	8b020063 	add	x3, x3, x2
    38f4:	6b0100ff 	cmp	w7, w1
    38f8:	54fffe8c 	b.gt	38c8 <fwp_format_g.constprop.0+0x348>
    38fc:	8b2742d6 	add	x22, x22, w7, uxtw
    3900:	f101207f 	cmp	x3, #0x48
    3904:	d2800905 	mov	x5, #0x48                  	// #72
    3908:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    390c:	aa1603e0 	mov	x0, x22
    3910:	cb0300a1 	sub	x1, x5, x3
    3914:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3918:	91000421 	add	x1, x1, #0x1
    391c:	d1000463 	sub	x3, x3, #0x1
    3920:	eb05003f 	cmp	x1, x5
    3924:	38001402 	strb	w2, [x0], #1
    3928:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    392c:	93407f82 	sxtw	x2, w28
    3930:	cb050025 	sub	x5, x1, x5
    3934:	aa1303e1 	mov	x1, x19
    3938:	8b0300a3 	add	x3, x5, x3
    393c:	8b1802d3 	add	x19, x22, x24
    3940:	97fffba4 	bl	27d0 <__memcpy_chk@plt>
    3944:	17ffff6b 	b	36f0 <fwp_format_g.constprop.0+0x170>
    3948:	d1000421 	sub	x1, x1, #0x1
    394c:	38616aa0 	ldrb	w0, [x21, x1]
    3950:	7100b81f 	cmp	w0, #0x2e
    3954:	54fff021 	b.ne	3758 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3958:	38216abf 	strb	wzr, [x21, x1]
    395c:	17ffff7f 	b	3758 <fwp_format_g.constprop.0+0x1d8>
    3960:	910187e7 	add	x7, sp, #0x61
    3964:	910183f9 	add	x25, sp, #0x60
    3968:	d28008fb 	mov	x27, #0x47                  	// #71
    396c:	390183e0 	strb	w0, [sp, #96]
    3970:	17ffff3b 	b	365c <fwp_format_g.constprop.0+0xdc>
    3974:	38336b3f 	strb	wzr, [x25, x19]
    3978:	17ffffac 	b	3828 <fwp_format_g.constprop.0+0x2a8>
    397c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3980:	97fffbc0 	bl	2880 <__stack_chk_fail@plt>

0000000000003984 <fwp_heap_report>:
    3984:	d105c3ff 	sub	sp, sp, #0x170
    3988:	d0000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    398c:	9114c042 	add	x2, x2, #0x530
    3990:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    3994:	f947e821 	ldr	x1, [x1, #4048]
    3998:	a9117bfd 	stp	x29, x30, [sp, #272]
    399c:	910443fd 	add	x29, sp, #0x110
    39a0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    39a4:	f947f400 	ldr	x0, [x0, #4072]
    39a8:	a9135bf5 	stp	x21, x22, [sp, #304]
    39ac:	a91463f7 	stp	x23, x24, [sp, #320]
    39b0:	a9156bf9 	stp	x25, x26, [sp, #336]
    39b4:	6d1627e8 	stp	d8, d9, [sp, #352]
    39b8:	fd4a1c48 	ldr	d8, [x2, #5176]
    39bc:	fd4a2049 	ldr	d9, [x2, #5184]
    39c0:	f9400036 	ldr	x22, [x1]
    39c4:	f9400001 	ldr	x1, [x0]
    39c8:	f90087e1 	str	x1, [sp, #264]
    39cc:	d2800001 	mov	x1, #0x0                   	// #0
    39d0:	f949e459 	ldr	x25, [x2, #5064]
    39d4:	d0000021 	adrp	x1, 9000 <__divti3+0x2c0>
    39d8:	f94a1057 	ldr	x23, [x2, #5152]
    39dc:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    39e0:	f94a1458 	ldr	x24, [x2, #5160]
    39e4:	9112e021 	add	x1, x1, #0x4b8
    39e8:	91130000 	add	x0, x0, #0x4c0
    39ec:	97fffb89 	bl	2810 <fopen@plt>
    39f0:	b4000760 	cbz	x0, 3adc <fwp_heap_report+0x158>
    39f4:	528daad5 	mov	w21, #0x6d56                	// #27990
    39f8:	a91253f3 	stp	x19, x20, [sp, #288]
    39fc:	aa0003f4 	mov	x20, x0
    3a00:	910023f3 	add	x19, sp, #0x8
    3a04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3a08:	72aae915 	movk	w21, #0x5748, lsl #16
    3a0c:	d503201f 	nop
    3a10:	aa1403e2 	mov	x2, x20
    3a14:	aa1303e0 	mov	x0, x19
    3a18:	52802001 	mov	w1, #0x100                 	// #256
    3a1c:	97fffc09 	bl	2a40 <fgets@plt>
    3a20:	b4000280 	cbz	x0, 3a70 <fwp_heap_report+0xec>
    3a24:	b9400261 	ldr	w1, [x19]
    3a28:	6b15003f 	cmp	w1, w21
    3a2c:	54ffff21 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a30:	39401260 	ldrb	w0, [x19, #4]
    3a34:	7101341f 	cmp	w0, #0x4d
    3a38:	54fffec1 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a3c:	394037e0 	ldrb	w0, [sp, #13]
    3a40:	7100e81f 	cmp	w0, #0x3a
    3a44:	54fffe61 	b.ne	3a10 <fwp_heap_report+0x8c>  // b.any
    3a48:	52800142 	mov	w2, #0xa                   	// #10
    3a4c:	d2800001 	mov	x1, #0x0                   	// #0
    3a50:	91003be0 	add	x0, sp, #0xe
    3a54:	97fffbb3 	bl	2920 <strtol@plt>
    3a58:	aa1403e2 	mov	x2, x20
    3a5c:	aa0003fa 	mov	x26, x0
    3a60:	52802001 	mov	w1, #0x100                 	// #256
    3a64:	aa1303e0 	mov	x0, x19
    3a68:	97fffbf6 	bl	2a40 <fgets@plt>
    3a6c:	b5fffdc0 	cbnz	x0, 3a24 <fwp_heap_report+0xa0>
    3a70:	aa1403e0 	mov	x0, x20
    3a74:	97fffb63 	bl	2800 <fclose@plt>
    3a78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3a7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3a80:	f947f400 	ldr	x0, [x0, #4072]
    3a84:	f94087e2 	ldr	x2, [sp, #264]
    3a88:	f9400001 	ldr	x1, [x0]
    3a8c:	eb010042 	subs	x2, x2, x1
    3a90:	d2800001 	mov	x1, #0x0                   	// #0
    3a94:	54000281 	b.ne	3ae4 <fwp_heap_report+0x160>  // b.any
    3a98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3a9c:	aa1a03e6 	mov	x6, x26
    3aa0:	aa1903e5 	mov	x5, x25
    3aa4:	aa1803e4 	mov	x4, x24
    3aa8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3aac:	aa1703e3 	mov	x3, x23
    3ab0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3ab4:	aa1603e0 	mov	x0, x22
    3ab8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3abc:	1e604121 	fmov	d1, d9
    3ac0:	1e604100 	fmov	d0, d8
    3ac4:	d0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    3ac8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3acc:	91138042 	add	x2, x2, #0x4e0
    3ad0:	9105c3ff 	add	sp, sp, #0x170
    3ad4:	52800041 	mov	w1, #0x2                   	// #2
    3ad8:	17fffb86 	b	28f0 <__fprintf_chk@plt>
    3adc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ae0:	17ffffe7 	b	3a7c <fwp_heap_report+0xf8>
    3ae4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ae8:	97fffb66 	bl	2880 <__stack_chk_fail@plt>
    3aec:	d503201f 	nop

0000000000003af0 <fwp_heap_init>:
    3af0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3af4:	f0000163 	adrp	x3, 32000 <fwp_heap+0xad0>
    3af8:	9110c061 	add	x1, x3, #0x430
    3afc:	910003fd 	mov	x29, sp
    3b00:	a90153f3 	stp	x19, x20, [sp, #16]
    3b04:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3b08:	9114c262 	add	x2, x19, #0x530
    3b0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3b10:	52800024 	mov	w4, #0x1                   	// #1
    3b14:	52800200 	mov	w0, #0x10                  	// #16
    3b18:	b913a444 	str	w4, [x2, #5028]
    3b1c:	d503201f 	nop
    3b20:	b8004420 	str	w0, [x1], #4
    3b24:	11004000 	add	w0, w0, #0x10
    3b28:	7104401f 	cmp	w0, #0x110
    3b2c:	54ffffa1 	b.ne	3b20 <fwp_heap_init+0x30>  // b.any
    3b30:	f0000022 	adrp	x2, a000 <_IO_stdin_used+0xba0>
    3b34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3b38:	f0000161 	adrp	x1, 32000 <fwp_heap+0xad0>
    3b3c:	9111c021 	add	x1, x1, #0x470
    3b40:	3dc01843 	ldr	q3, [x2, #96]
    3b44:	d2800000 	mov	x0, #0x0                   	// #0
    3b48:	4e040401 	dup	v1.4s, v0.s[0]
    3b4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3b50:	0f215400 	shl	v0.2s, v0.2s, #1
    3b54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3b58:	3ca06821 	str	q1, [x1, x0]
    3b5c:	91004000 	add	x0, x0, #0x10
    3b60:	f101801f 	cmp	x0, #0x60
    3b64:	54ffff21 	b.ne	3b48 <fwp_heap_init+0x58>  // b.any
    3b68:	f0000164 	adrp	x4, 32000 <fwp_heap+0xad0>
    3b6c:	9110c063 	add	x3, x3, #0x430
    3b70:	91134084 	add	x4, x4, #0x4d0
    3b74:	9114c266 	add	x6, x19, #0x530
    3b78:	d2800002 	mov	x2, #0x0                   	// #0
    3b7c:	d2800000 	mov	x0, #0x0                   	// #0
    3b80:	d2880205 	mov	x5, #0x4010                	// #16400
    3b84:	d503201f 	nop
    3b88:	910f0001 	add	x1, x0, #0x3c0
    3b8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3b90:	eb02003f 	cmp	x1, x2
    3b94:	540000a2 	b.cs	3ba8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3b98:	91000400 	add	x0, x0, #0x1
    3b9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3ba0:	eb02003f 	cmp	x1, x2
    3ba4:	54ffffa3 	b.cc	3b98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3ba8:	91004042 	add	x2, x2, #0x10
    3bac:	38001480 	strb	w0, [x4], #1
    3bb0:	eb05005f 	cmp	x2, x5
    3bb4:	54fffea1 	b.ne	3b88 <fwp_heap_init+0x98>  // b.any
    3bb8:	528000b5 	mov	w21, #0x5                   	// #5
    3bbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3bc0:	14000004 	b	3bd0 <fwp_heap_init+0xe0>
    3bc4:	d342fe94 	lsr	x20, x20, #2
    3bc8:	710006b5 	subs	w21, w21, #0x1
    3bcc:	54000720 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3bd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3bd4:	d2800005 	mov	x5, #0x0                   	// #0
    3bd8:	aa1603e1 	mov	x1, x22
    3bdc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3be0:	52880443 	mov	w3, #0x4022                	// #16418
    3be4:	52800002 	mov	w2, #0x0                   	// #0
    3be8:	d2800000 	mov	x0, #0x0                   	// #0
    3bec:	97fffb49 	bl	2910 <mmap@plt>
    3bf0:	aa0003e6 	mov	x6, x0
    3bf4:	b100041f 	cmn	x0, #0x1
    3bf8:	54fffe60 	b.eq	3bc4 <fwp_heap_init+0xd4>  // b.none
    3bfc:	b40005a0 	cbz	x0, 3cb0 <fwp_heap_init+0x1c0>
    3c00:	d350fe94 	lsr	x20, x20, #16
    3c04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3c08:	8b0000c7 	add	x7, x6, x0
    3c0c:	9114c275 	add	x21, x19, #0x530
    3c10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3c14:	8b140a81 	add	x1, x20, x20, lsl #2
    3c18:	d2800005 	mov	x5, #0x0                   	// #0
    3c1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3c20:	d37df021 	lsl	x1, x1, #3
    3c24:	52880443 	mov	w3, #0x4022                	// #16418
    3c28:	52800002 	mov	w2, #0x0                   	// #0
    3c2c:	d2800000 	mov	x0, #0x0                   	// #0
    3c30:	f909daa7 	str	x7, [x21, #5040]
    3c34:	f909dea6 	str	x6, [x21, #5048]
    3c38:	f909e2b6 	str	x22, [x21, #5056]
    3c3c:	f909eab4 	str	x20, [x21, #5072]
    3c40:	f90a02a1 	str	x1, [x21, #5120]
    3c44:	97fffb33 	bl	2910 <mmap@plt>
    3c48:	aa0003e1 	mov	x1, x0
    3c4c:	b100041f 	cmn	x0, #0x1
    3c50:	54000300 	b.eq	3cb0 <fwp_heap_init+0x1c0>  // b.none
    3c54:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3c58:	9115a000 	add	x0, x0, #0x568
    3c5c:	f909fea1 	str	x1, [x21, #5112]
    3c60:	97fffb6c 	bl	2a10 <getenv@plt>
    3c64:	52800002 	mov	w2, #0x0                   	// #0
    3c68:	aa0003e1 	mov	x1, x0
    3c6c:	b40000e0 	cbz	x0, 3c88 <fwp_heap_init+0x198>
    3c70:	39400000 	ldrb	w0, [x0]
    3c74:	340000a0 	cbz	w0, 3c88 <fwp_heap_init+0x198>
    3c78:	7100c000 	subs	w0, w0, #0x30
    3c7c:	54000120 	b.eq	3ca0 <fwp_heap_init+0x1b0>  // b.none
    3c80:	7100001f 	cmp	w0, #0x0
    3c84:	1a9f07e2 	cset	w2, ne	// ne = any
    3c88:	9114c273 	add	x19, x19, #0x530
    3c8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3c90:	b913aa62 	str	w2, [x19, #5032]
    3c94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3c98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3c9c:	d65f03c0 	ret
    3ca0:	39400420 	ldrb	w0, [x1, #1]
    3ca4:	7100001f 	cmp	w0, #0x0
    3ca8:	1a9f07e2 	cset	w2, ne	// ne = any
    3cac:	17fffff7 	b	3c88 <fwp_heap_init+0x198>
    3cb0:	97fffce0 	bl	3030 <fwp_heap_oom>

0000000000003cb4 <fwp_wake_io>:
    3cb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3cb8:	9100c122 	add	x2, x9, #0x30
    3cbc:	f9400001 	ldr	x1, [x0]
    3cc0:	5280000a 	mov	w10, #0x0                   	// #0
    3cc4:	f9401446 	ldr	x6, [x2, #40]
    3cc8:	52800008 	mov	w8, #0x0                   	// #0
    3ccc:	4f000400 	movi	v0.4s, #0x0
    3cd0:	52800027 	mov	w7, #0x1                   	// #1
    3cd4:	aa0103e2 	mov	x2, x1
    3cd8:	b4000321 	cbz	x1, 3d3c <fwp_wake_io+0x88>
    3cdc:	f9408c25 	ldr	x5, [x1, #280]
    3ce0:	39015c27 	strb	w7, [x1, #87]
    3ce4:	b4000165 	cbz	x5, 3d10 <fwp_wake_io+0x5c>
    3ce8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3cec:	b4000364 	cbz	x4, 3d58 <fwp_wake_io+0xa4>
    3cf0:	f9009483 	str	x3, [x4, #296]
    3cf4:	f9409423 	ldr	x3, [x1, #296]
    3cf8:	b4000043 	cbz	x3, 3d00 <fwp_wake_io+0x4c>
    3cfc:	f9009064 	str	x4, [x3, #288]
    3d00:	91080023 	add	x3, x1, #0x200
    3d04:	f900943f 	str	xzr, [x1, #296]
    3d08:	3c918060 	stur	q0, [x3, #-232]
    3d0c:	f9400001 	ldr	x1, [x0]
    3d10:	f9402843 	ldr	x3, [x2, #80]
    3d14:	f2001c7f 	tst	x3, #0xff000000ff
    3d18:	54fffde1 	b.ne	3cd4 <fwp_wake_io+0x20>  // b.any
    3d1c:	39015047 	strb	w7, [x2, #84]
    3d20:	f900805f 	str	xzr, [x2, #256]
    3d24:	b40001e6 	cbz	x6, 3d60 <fwp_wake_io+0xac>
    3d28:	f90080c2 	str	x2, [x6, #256]
    3d2c:	aa0203e6 	mov	x6, x2
    3d30:	52800028 	mov	w8, #0x1                   	// #1
    3d34:	aa0103e2 	mov	x2, x1
    3d38:	b5fffd21 	cbnz	x1, 3cdc <fwp_wake_io+0x28>
    3d3c:	3400006a 	cbz	w10, 3d48 <fwp_wake_io+0x94>
    3d40:	9100c120 	add	x0, x9, #0x30
    3d44:	f900180b 	str	x11, [x0, #48]
    3d48:	34000068 	cbz	w8, 3d54 <fwp_wake_io+0xa0>
    3d4c:	9100c129 	add	x9, x9, #0x30
    3d50:	f9001526 	str	x6, [x9, #40]
    3d54:	d65f03c0 	ret
    3d58:	f90000a3 	str	x3, [x5]
    3d5c:	17ffffe7 	b	3cf8 <fwp_wake_io+0x44>
    3d60:	aa0203eb 	mov	x11, x2
    3d64:	5280002a 	mov	w10, #0x1                   	// #1
    3d68:	17fffff1 	b	3d2c <fwp_wake_io+0x78>
    3d6c:	d503201f 	nop

0000000000003d70 <fwp_tape_buffers_release>:
    3d70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3d74:	910003fd 	mov	x29, sp
    3d78:	a90153f3 	stp	x19, x20, [sp, #16]
    3d7c:	aa0003f3 	mov	x19, x0
    3d80:	f9401400 	ldr	x0, [x0, #40]
    3d84:	b7f80760 	tbnz	x0, #63, 3e70 <fwp_tape_buffers_release+0x100>
    3d88:	f9401a61 	ldr	x1, [x19, #48]
    3d8c:	b7f80301 	tbnz	x1, #63, 3dec <fwp_tape_buffers_release+0x7c>
    3d90:	d28aaaa2 	mov	x2, #0x5555                	// #21845
    3d94:	eb02001f 	cmp	x0, x2
    3d98:	540002a8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3d9c:	8b000400 	add	x0, x0, x0, lsl #1
    3da0:	d2a00102 	mov	x2, #0x80000               	// #524288
    3da4:	d37df000 	lsl	x0, x0, #3
    3da8:	cb000042 	sub	x2, x2, x0
    3dac:	eb420c3f 	cmp	x1, x2, lsr #3
    3db0:	540001e8 	b.hi	3dec <fwp_tape_buffers_release+0x7c>  // b.pmore
    3db4:	8b010c14 	add	x20, x0, x1, lsl #3
    3db8:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3dbc:	9115e000 	add	x0, x0, #0x578
    3dc0:	97fffb14 	bl	2a10 <getenv@plt>
    3dc4:	b4000240 	cbz	x0, 3e0c <fwp_tape_buffers_release+0x9c>
    3dc8:	39400001 	ldrb	w1, [x0]
    3dcc:	7100c03f 	cmp	w1, #0x30
    3dd0:	540001e1 	b.ne	3e0c <fwp_tape_buffers_release+0x9c>  // b.any
    3dd4:	39400400 	ldrb	w0, [x0, #1]
    3dd8:	350001a0 	cbnz	w0, 3e0c <fwp_tape_buffers_release+0x9c>
    3ddc:	aa1303e0 	mov	x0, x19
    3de0:	a94153f3 	ldp	x19, x20, [sp, #16]
    3de4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3de8:	17fffd46 	b	3300 <fwp_tape_buffers_dispose>
    3dec:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3df0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3df4:	9115e000 	add	x0, x0, #0x578
    3df8:	97fffb06 	bl	2a10 <getenv@plt>
    3dfc:	b4ffff00 	cbz	x0, 3ddc <fwp_tape_buffers_release+0x6c>
    3e00:	39400001 	ldrb	w1, [x0]
    3e04:	7100c03f 	cmp	w1, #0x30
    3e08:	54fffe60 	b.eq	3dd4 <fwp_tape_buffers_release+0x64>  // b.none
    3e0c:	d1000681 	sub	x1, x20, #0x1
    3e10:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    3e14:	eb00003f 	cmp	x1, x0
    3e18:	54fffe28 	b.hi	3ddc <fwp_tape_buffers_release+0x6c>  // b.pmore
    3e1c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3e20:	b00000f6 	adrp	x22, 20000 <__data_start>
    3e24:	9100c2d6 	add	x22, x22, #0x30
    3e28:	9100e2d5 	add	x21, x22, #0x38
    3e2c:	aa1503e0 	mov	x0, x21
    3e30:	97fffd34 	bl	3300 <fwp_tape_buffers_dispose>
    3e34:	ad400a61 	ldp	q1, q2, [x19]
    3e38:	f9003ad4 	str	x20, [x22, #112]
    3e3c:	4f000400 	movi	v0.4s, #0x0
    3e40:	ad000aa1 	stp	q1, q2, [x21]
    3e44:	3dc00a61 	ldr	q1, [x19, #32]
    3e48:	3d800aa1 	str	q1, [x21, #32]
    3e4c:	f9401a60 	ldr	x0, [x19, #48]
    3e50:	f9001aa0 	str	x0, [x21, #48]
    3e54:	f9001a7f 	str	xzr, [x19, #48]
    3e58:	ad000260 	stp	q0, q0, [x19]
    3e5c:	3d800a60 	str	q0, [x19, #32]
    3e60:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e64:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e68:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e6c:	d65f03c0 	ret
    3e70:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3e74:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    3e78:	9115e000 	add	x0, x0, #0x578
    3e7c:	97fffae5 	bl	2a10 <getenv@plt>
    3e80:	b5fffa40 	cbnz	x0, 3dc8 <fwp_tape_buffers_release+0x58>
    3e84:	17ffffd6 	b	3ddc <fwp_tape_buffers_release+0x6c>
    3e88:	d503201f 	nop
    3e8c:	d503201f 	nop

0000000000003e90 <fwp_trap>:
    3e90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3e94:	b00000e2 	adrp	x2, 20000 <__data_start>
    3e98:	d53bd041 	mrs	x1, tpidr_el0
    3e9c:	910003fd 	mov	x29, sp
    3ea0:	f9401c42 	ldr	x2, [x2, #56]
    3ea4:	91400021 	add	x1, x1, #0x0, lsl #12
    3ea8:	91004021 	add	x1, x1, #0x10
    3eac:	a90153f3 	stp	x19, x20, [sp, #16]
    3eb0:	aa0003f3 	mov	x19, x0
    3eb4:	f9400034 	ldr	x20, [x1]
    3eb8:	b4000062 	cbz	x2, 3ec4 <fwp_trap+0x34>
    3ebc:	aa0203e0 	mov	x0, x2
    3ec0:	97fffabc 	bl	29b0 <fflush@plt>
    3ec4:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    3ec8:	f947ec00 	ldr	x0, [x0, #4056]
    3ecc:	f9400000 	ldr	x0, [x0]
    3ed0:	97fffab8 	bl	29b0 <fflush@plt>
    3ed4:	aa1303e3 	mov	x3, x19
    3ed8:	d0000022 	adrp	x2, 9000 <__divti3+0x2c0>
    3edc:	900000f3 	adrp	x19, 1f000 <fwp_fn_table+0xc98>
    3ee0:	f947ea73 	ldr	x19, [x19, #4048]
    3ee4:	91164042 	add	x2, x2, #0x590
    3ee8:	52800041 	mov	w1, #0x2                   	// #2
    3eec:	f9400260 	ldr	x0, [x19]
    3ef0:	97fffa80 	bl	28f0 <__fprintf_chk@plt>
    3ef4:	b40000b4 	cbz	x20, 3f08 <fwp_trap+0x78>
    3ef8:	f9400260 	ldr	x0, [x19]
    3efc:	97fffaad 	bl	29b0 <fflush@plt>
    3f00:	52800ca0 	mov	w0, #0x65                  	// #101
    3f04:	97fffabb 	bl	29f0 <_Exit@plt>
    3f08:	52800ca0 	mov	w0, #0x65                  	// #101
    3f0c:	97fffa09 	bl	2730 <exit@plt>

0000000000003f10 <fwp_rc_forget_slot.part.0>:
    3f10:	ca404401 	eor	x1, x0, x0, lsr #17
    3f14:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3f18:	ca412421 	eor	x1, x1, x1, lsr #9
    3f1c:	910003fd 	mov	x29, sp
    3f20:	92401c21 	and	x1, x1, #0xff
    3f24:	f9000bf3 	str	x19, [sp, #16]
    3f28:	d0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    3f2c:	9114c262 	add	x2, x19, #0x530
    3f30:	910a2423 	add	x3, x1, #0x289
    3f34:	8b010c41 	add	x1, x2, x1, lsl #3
    3f38:	8b030c43 	add	x3, x2, x3, lsl #3
    3f3c:	f94a2421 	ldr	x1, [x1, #5192]
    3f40:	b50000a1 	cbnz	x1, 3f54 <fwp_rc_forget_slot.part.0+0x44>
    3f44:	14000012 	b	3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f48:	91004023 	add	x3, x1, #0x10
    3f4c:	f9400821 	ldr	x1, [x1, #16]
    3f50:	b40001e1 	cbz	x1, 3f8c <fwp_rc_forget_slot.part.0+0x7c>
    3f54:	f9400022 	ldr	x2, [x1]
    3f58:	eb02001f 	cmp	x0, x2
    3f5c:	54ffff61 	b.ne	3f48 <fwp_rc_forget_slot.part.0+0x38>  // b.any
    3f60:	f9400060 	ldr	x0, [x3]
    3f64:	9114c273 	add	x19, x19, #0x530
    3f68:	f9400801 	ldr	x1, [x0, #16]
    3f6c:	f9000061 	str	x1, [x3]
    3f70:	97fffa74 	bl	2940 <free@plt>
    3f74:	f94e2660 	ldr	x0, [x19, #7240]
    3f78:	d1000400 	sub	x0, x0, #0x1
    3f7c:	f90e2660 	str	x0, [x19, #7240]
    3f80:	f9400bf3 	ldr	x19, [sp, #16]
    3f84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3f88:	d65f03c0 	ret
    3f8c:	d0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    3f90:	91168000 	add	x0, x0, #0x5a0
    3f94:	97ffffbf 	bl	3e90 <fwp_trap>
    3f98:	d503201f 	nop
    3f9c:	d503201f 	nop

0000000000003fa0 <fwp_rc_prepare_chunk>:
    3fa0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3fa4:	910003fd 	mov	x29, sp
    3fa8:	a9025bf5 	stp	x21, x22, [sp, #32]
    3fac:	d0000176 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    3fb0:	9114c2c2 	add	x2, x22, #0x530
    3fb4:	b9401c03 	ldr	w3, [x0, #28]
    3fb8:	aa0103f5 	mov	x21, x1
    3fbc:	a90153f3 	stp	x19, x20, [sp, #16]
    3fc0:	aa0003f4 	mov	x20, x0
    3fc4:	f94e2440 	ldr	x0, [x2, #7240]
    3fc8:	b4000440 	cbz	x0, 4050 <fwp_rc_prepare_chunk+0xb0>
    3fcc:	d2800013 	mov	x19, #0x0                   	// #0
    3fd0:	35000203 	cbnz	w3, 4010 <fwp_rc_prepare_chunk+0x70>
    3fd4:	b4000361 	cbz	x1, 4040 <fwp_rc_prepare_chunk+0xa0>
    3fd8:	f9401280 	ldr	x0, [x20, #32]
    3fdc:	97fffa59 	bl	2940 <free@plt>
    3fe0:	aa1503e0 	mov	x0, x21
    3fe4:	d2800021 	mov	x1, #0x1                   	// #1
    3fe8:	97fffa1e 	bl	2860 <calloc@plt>
    3fec:	f9001280 	str	x0, [x20, #32]
    3ff0:	b5000460 	cbnz	x0, 407c <fwp_rc_prepare_chunk+0xdc>
    3ff4:	97fffc0f 	bl	3030 <fwp_heap_oom>
    3ff8:	97ffffc6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    3ffc:	91000673 	add	x19, x19, #0x1
    4000:	b9401e83 	ldr	w3, [x20, #28]
    4004:	eb13007f 	cmp	x3, x19
    4008:	54000169 	b.ls	4034 <fwp_rc_prepare_chunk+0x94>  // b.plast
    400c:	d503201f 	nop
    4010:	f9401283 	ldr	x3, [x20, #32]
    4014:	8b130060 	add	x0, x3, x19
    4018:	38736863 	ldrb	w3, [x3, x19]
    401c:	7103fc7f 	cmp	w3, #0xff
    4020:	54fffec0 	b.eq	3ff8 <fwp_rc_prepare_chunk+0x58>  // b.none
    4024:	b9401e83 	ldr	w3, [x20, #28]
    4028:	91000673 	add	x19, x19, #0x1
    402c:	eb13007f 	cmp	x3, x19
    4030:	54ffff08 	b.hi	4010 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4034:	eb0302bf 	cmp	x21, x3
    4038:	54000121 	b.ne	405c <fwp_rc_prepare_chunk+0xbc>  // b.any
    403c:	b5000335 	cbnz	x21, 40a0 <fwp_rc_prepare_chunk+0x100>
    4040:	a94153f3 	ldp	x19, x20, [sp, #16]
    4044:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4048:	a8c37bfd 	ldp	x29, x30, [sp], #48
    404c:	d65f03c0 	ret
    4050:	2a0303e3 	mov	w3, w3
    4054:	eb0302bf 	cmp	x21, x3
    4058:	54ffff20 	b.eq	403c <fwp_rc_prepare_chunk+0x9c>  // b.none
    405c:	9114c2c2 	add	x2, x22, #0x530
    4060:	f9401280 	ldr	x0, [x20, #32]
    4064:	f94e2841 	ldr	x1, [x2, #7248]
    4068:	cb030021 	sub	x1, x1, x3
    406c:	f90e2841 	str	x1, [x2, #7248]
    4070:	97fffa34 	bl	2940 <free@plt>
    4074:	b5fffb75 	cbnz	x21, 3fe0 <fwp_rc_prepare_chunk+0x40>
    4078:	f900129f 	str	xzr, [x20, #32]
    407c:	9114c2d6 	add	x22, x22, #0x530
    4080:	f94e2ac0 	ldr	x0, [x22, #7248]
    4084:	b9001e95 	str	w21, [x20, #28]
    4088:	a94153f3 	ldp	x19, x20, [sp, #16]
    408c:	8b150000 	add	x0, x0, x21
    4090:	f90e2ac0 	str	x0, [x22, #7248]
    4094:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4098:	a8c37bfd 	ldp	x29, x30, [sp], #48
    409c:	d65f03c0 	ret
    40a0:	f9401280 	ldr	x0, [x20, #32]
    40a4:	aa1503e2 	mov	x2, x21
    40a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    40ac:	52800001 	mov	w1, #0x0                   	// #0
    40b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    40b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40b8:	17fff9e6 	b	2850 <memset@plt>
    40bc:	d503201f 	nop

00000000000040c0 <fwp_heap_refill>:
    40c0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    40c4:	910003fd 	mov	x29, sp
    40c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    40cc:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    40d0:	9114c2b5 	add	x21, x21, #0x530
    40d4:	aa0003f6 	mov	x22, x0
    40d8:	d2800020 	mov	x0, #0x1                   	// #1
    40dc:	a90153f3 	stp	x19, x20, [sp, #16]
    40e0:	a90363f7 	stp	x23, x24, [sp, #48]
    40e4:	2a0103f7 	mov	w23, w1
    40e8:	2a0203f8 	mov	w24, w2
    40ec:	97fffc11 	bl	3130 <fwp_heap_chunks>
    40f0:	aa0003f3 	mov	x19, x0
    40f4:	f949fea2 	ldr	x2, [x21, #5112]
    40f8:	8b000800 	add	x0, x0, x0, lsl #2
    40fc:	2a1703e1 	mov	w1, w23
    4100:	52800025 	mov	w5, #0x1                   	// #1
    4104:	d37df000 	lsl	x0, x0, #3
    4108:	910f0021 	add	x1, x1, #0x3c0
    410c:	8b000054 	add	x20, x2, x0
    4110:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4114:	52a00024 	mov	w4, #0x10000               	// #65536
    4118:	38206845 	strb	w5, [x2, x0]
    411c:	aa1403e0 	mov	x0, x20
    4120:	39000698 	strb	w24, [x20, #1]
    4124:	39000a97 	strb	w23, [x20, #2]
    4128:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    412c:	b9000681 	str	w1, [x20, #4]
    4130:	2a0103e5 	mov	w5, w1
    4134:	8b0300a2 	add	x2, x5, x3
    4138:	1ac10881 	udiv	w1, w4, w1
    413c:	9ac50842 	udiv	x2, x2, x5
    4140:	b9000a81 	str	w1, [x20, #8]
    4144:	92404021 	and	x1, x1, #0x1ffff
    4148:	b9001a82 	str	w2, [x20, #24]
    414c:	97ffff95 	bl	3fa0 <fwp_rc_prepare_chunk>
    4150:	f949daa0 	ldr	x0, [x21, #5040]
    4154:	29408a81 	ldp	w1, w2, [x20, #4]
    4158:	8b134000 	add	x0, x0, x19, lsl #16
    415c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4160:	8b214003 	add	x3, x0, w1, uxtw
    4164:	9ba20021 	umaddl	x1, w1, w2, x0
    4168:	a94363f7 	ldp	x23, x24, [sp, #48]
    416c:	a90086c3 	stp	x3, x1, [x22, #8]
    4170:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4174:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4178:	d65f03c0 	ret
    417c:	d503201f 	nop

0000000000004180 <fwp_mem_free>:
    4180:	b40003c0 	cbz	x0, 41f8 <fwp_mem_free+0x78>
    4184:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4188:	910003fd 	mov	x29, sp
    418c:	a9025bf5 	stp	x21, x22, [sp, #32]
    4190:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4194:	9114c2a1 	add	x1, x21, #0x530
    4198:	a90153f3 	stp	x19, x20, [sp, #16]
    419c:	aa0003f3 	mov	x19, x0
    41a0:	f949d823 	ldr	x3, [x1, #5040]
    41a4:	f949ec22 	ldr	x2, [x1, #5080]
    41a8:	cb030000 	sub	x0, x0, x3
    41ac:	eb02401f 	cmp	x0, x2, lsl #16
    41b0:	540001c2 	b.cs	41e8 <fwp_mem_free+0x68>  // b.hs, b.nlast
    41b4:	d350fc16 	lsr	x22, x0, #16
    41b8:	a90363f7 	stp	x23, x24, [sp, #48]
    41bc:	f949fc22 	ldr	x2, [x1, #5112]
    41c0:	8b160ad4 	add	x20, x22, x22, lsl #2
    41c4:	d37df294 	lsl	x20, x20, #3
    41c8:	ab140057 	adds	x23, x2, x20
    41cc:	540000c0 	b.eq	41e4 <fwp_mem_free+0x64>  // b.none
    41d0:	38746842 	ldrb	w2, [x2, x20]
    41d4:	7100045f 	cmp	w2, #0x1
    41d8:	54000120 	b.eq	41fc <fwp_mem_free+0x7c>  // b.none
    41dc:	7100085f 	cmp	w2, #0x2
    41e0:	540005e0 	b.eq	429c <fwp_mem_free+0x11c>  // b.none
    41e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    41e8:	a94153f3 	ldp	x19, x20, [sp, #16]
    41ec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    41f0:	a8c57bfd 	ldp	x29, x30, [sp], #80
    41f4:	d65f03c0 	ret
    41f8:	d65f03c0 	ret
    41fc:	f94012f8 	ldr	x24, [x23, #32]
    4200:	b94006e1 	ldr	w1, [x23, #4]
    4204:	f90023f9 	str	x25, [sp, #64]
    4208:	2a0103e2 	mov	w2, w1
    420c:	394006f9 	ldrb	w25, [x23, #1]
    4210:	39400af4 	ldrb	w20, [x23, #2]
    4214:	b4000158 	cbz	x24, 423c <fwp_mem_free+0xbc>
    4218:	92403e76 	and	x22, x19, #0xffff
    421c:	9ac20ad6 	udiv	x22, x22, x2
    4220:	38766b01 	ldrb	w1, [x24, x22]
    4224:	8b160300 	add	x0, x24, x22
    4228:	7103fc3f 	cmp	w1, #0xff
    422c:	54000980 	b.eq	435c <fwp_mem_free+0x1dc>  // b.none
    4230:	38366b1f 	strb	wzr, [x24, x22]
    4234:	b94006e1 	ldr	w1, [x23, #4]
    4238:	2a0103e2 	mov	w2, w1
    423c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4240:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4244:	cb390000 	sub	x0, x0, w25, uxtb
    4248:	8b340074 	add	x20, x3, w20, uxtb
    424c:	9114c2b5 	add	x21, x21, #0x530
    4250:	1e630021 	ucvtf	d1, w1
    4254:	d37ae400 	lsl	x0, x0, #6
    4258:	8b140c14 	add	x20, x0, x20, lsl #3
    425c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4260:	f8746aa0 	ldr	x0, [x21, x20]
    4264:	f94023f9 	ldr	x25, [sp, #64]
    4268:	aa2003e0 	mvn	x0, x0
    426c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4270:	f9000260 	str	x0, [x19]
    4274:	f8346ab3 	str	x19, [x21, x20]
    4278:	f94a12a0 	ldr	x0, [x21, #5152]
    427c:	1e612800 	fadd	d0, d0, d1
    4280:	a94153f3 	ldp	x19, x20, [sp, #16]
    4284:	cb020000 	sub	x0, x0, x2
    4288:	f90a12a0 	str	x0, [x21, #5152]
    428c:	fd0a22a0 	str	d0, [x21, #5184]
    4290:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4294:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4298:	d65f03c0 	ret
    429c:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    42a0:	8b000063 	add	x3, x3, x0
    42a4:	eb03027f 	cmp	x19, x3
    42a8:	54fff9e1 	b.ne	41e4 <fwp_mem_free+0x64>  // b.any
    42ac:	fd400ae1 	ldr	d1, [x23, #16]
    42b0:	fd4a2020 	ldr	d0, [x1, #5184]
    42b4:	f9400ae0 	ldr	x0, [x23, #16]
    42b8:	7e61d821 	ucvtf	d1, d1
    42bc:	f94a1022 	ldr	x2, [x1, #5152]
    42c0:	f94012f3 	ldr	x19, [x23, #32]
    42c4:	1e612800 	fadd	d0, d0, d1
    42c8:	cb000042 	sub	x2, x2, x0
    42cc:	f90a1022 	str	x2, [x1, #5152]
    42d0:	fd0a2020 	str	d0, [x1, #5184]
    42d4:	b40000b3 	cbz	x19, 42e8 <fwp_mem_free+0x168>
    42d8:	39400260 	ldrb	w0, [x19]
    42dc:	7103fc1f 	cmp	w0, #0xff
    42e0:	54000380 	b.eq	4350 <fwp_mem_free+0x1d0>  // b.none
    42e4:	3900027f 	strb	wzr, [x19]
    42e8:	b9400ee2 	ldr	w2, [x23, #12]
    42ec:	b4000142 	cbz	x2, 4314 <fwp_mem_free+0x194>
    42f0:	9114c2a1 	add	x1, x21, #0x530
    42f4:	8b160040 	add	x0, x2, x22
    42f8:	8b000800 	add	x0, x0, x0, lsl #2
    42fc:	f949fc21 	ldr	x1, [x1, #5112]
    4300:	8b140034 	add	x20, x1, x20
    4304:	8b000c20 	add	x0, x1, x0, lsl #3
    4308:	3802869f 	strb	wzr, [x20], #40
    430c:	eb00029f 	cmp	x20, x0
    4310:	54ffffc1 	b.ne	4308 <fwp_mem_free+0x188>  // b.any
    4314:	9114c2a0 	add	x0, x21, #0x530
    4318:	f94a1801 	ldr	x1, [x0, #5168]
    431c:	f949f803 	ldr	x3, [x0, #5104]
    4320:	8b020021 	add	x1, x1, x2
    4324:	f90a1801 	str	x1, [x0, #5168]
    4328:	eb16007f 	cmp	x3, x22
    432c:	54000049 	b.ls	4334 <fwp_mem_free+0x1b4>  // b.plast
    4330:	f909f816 	str	x22, [x0, #5104]
    4334:	9114c2b5 	add	x21, x21, #0x530
    4338:	f949f6a0 	ldr	x0, [x21, #5096]
    433c:	eb16001f 	cmp	x0, x22
    4340:	54fff529 	b.ls	41e4 <fwp_mem_free+0x64>  // b.plast
    4344:	a94363f7 	ldp	x23, x24, [sp, #48]
    4348:	f909f6b6 	str	x22, [x21, #5096]
    434c:	17ffffa7 	b	41e8 <fwp_mem_free+0x68>
    4350:	aa1303e0 	mov	x0, x19
    4354:	97fffeef 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4358:	17ffffe3 	b	42e4 <fwp_mem_free+0x164>
    435c:	97fffeed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    4360:	17ffffb4 	b	4230 <fwp_mem_free+0xb0>

0000000000004364 <fwp_rc_wide_dup>:
    4364:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4368:	910003fd 	mov	x29, sp
    436c:	a90153f3 	stp	x19, x20, [sp, #16]
    4370:	aa0003f3 	mov	x19, x0
    4374:	ca404400 	eor	x0, x0, x0, lsr #17
    4378:	f90013f5 	str	x21, [sp, #32]
    437c:	b0000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    4380:	ca402400 	eor	x0, x0, x0, lsr #9
    4384:	9114c2a2 	add	x2, x21, #0x530
    4388:	92401c00 	and	x0, x0, #0xff
    438c:	910a2403 	add	x3, x0, #0x289
    4390:	8b000c40 	add	x0, x2, x0, lsl #3
    4394:	8b030c54 	add	x20, x2, x3, lsl #3
    4398:	f94a2401 	ldr	x1, [x0, #5192]
    439c:	b50000a1 	cbnz	x1, 43b0 <fwp_rc_wide_dup+0x4c>
    43a0:	14000033 	b	446c <fwp_rc_wide_dup+0x108>
    43a4:	91004034 	add	x20, x1, #0x10
    43a8:	f9400821 	ldr	x1, [x1, #16]
    43ac:	b4000241 	cbz	x1, 43f4 <fwp_rc_wide_dup+0x90>
    43b0:	f9400022 	ldr	x2, [x1]
    43b4:	eb02027f 	cmp	x19, x2
    43b8:	54ffff61 	b.ne	43a4 <fwp_rc_wide_dup+0x40>  // b.any
    43bc:	f9400281 	ldr	x1, [x20]
    43c0:	39400260 	ldrb	w0, [x19]
    43c4:	7103f81f 	cmp	w0, #0xfe
    43c8:	54000220 	b.eq	440c <fwp_rc_wide_dup+0xa8>  // b.none
    43cc:	b40001a1 	cbz	x1, 4400 <fwp_rc_wide_dup+0x9c>
    43d0:	f9400420 	ldr	x0, [x1, #8]
    43d4:	b100041f 	cmn	x0, #0x1
    43d8:	54000440 	b.eq	4460 <fwp_rc_wide_dup+0xfc>  // b.none
    43dc:	91000400 	add	x0, x0, #0x1
    43e0:	f9000420 	str	x0, [x1, #8]
    43e4:	a94153f3 	ldp	x19, x20, [sp, #16]
    43e8:	f94013f5 	ldr	x21, [sp, #32]
    43ec:	a8c37bfd 	ldp	x29, x30, [sp], #48
    43f0:	d65f03c0 	ret
    43f4:	39400260 	ldrb	w0, [x19]
    43f8:	7103f81f 	cmp	w0, #0xfe
    43fc:	54000100 	b.eq	441c <fwp_rc_wide_dup+0xb8>  // b.none
    4400:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4404:	91168000 	add	x0, x0, #0x5a0
    4408:	97fffea2 	bl	3e90 <fwp_trap>
    440c:	b4000081 	cbz	x1, 441c <fwp_rc_wide_dup+0xb8>
    4410:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4414:	91172000 	add	x0, x0, #0x5c8
    4418:	97fffe9e 	bl	3e90 <fwp_trap>
    441c:	d2800300 	mov	x0, #0x18                  	// #24
    4420:	97fff900 	bl	2820 <malloc@plt>
    4424:	b4000280 	cbz	x0, 4474 <fwp_rc_wide_dup+0x110>
    4428:	d2801fe1 	mov	x1, #0xff                  	// #255
    442c:	a9000413 	stp	x19, x1, [x0]
    4430:	9114c2b5 	add	x21, x21, #0x530
    4434:	f900081f 	str	xzr, [x0, #16]
    4438:	12800001 	mov	w1, #0xffffffff            	// #-1
    443c:	f9000280 	str	x0, [x20]
    4440:	39000261 	strb	w1, [x19]
    4444:	f94e26a0 	ldr	x0, [x21, #7240]
    4448:	a94153f3 	ldp	x19, x20, [sp, #16]
    444c:	91000400 	add	x0, x0, #0x1
    4450:	f90e26a0 	str	x0, [x21, #7240]
    4454:	f94013f5 	ldr	x21, [sp, #32]
    4458:	a8c37bfd 	ldp	x29, x30, [sp], #48
    445c:	d65f03c0 	ret
    4460:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4464:	9117c000 	add	x0, x0, #0x5f0
    4468:	97fffe8a 	bl	3e90 <fwp_trap>
    446c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4470:	17ffffd4 	b	43c0 <fwp_rc_wide_dup+0x5c>
    4474:	97fffaef 	bl	3030 <fwp_heap_oom>
    4478:	d503201f 	nop
    447c:	d503201f 	nop

0000000000004480 <fwp_closure_drop_push>:
    4480:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4484:	910003fd 	mov	x29, sp
    4488:	a90153f3 	stp	x19, x20, [sp, #16]
    448c:	aa0003f3 	mov	x19, x0
    4490:	a9408014 	ldp	x20, x0, [x0, #8]
    4494:	a9025bf5 	stp	x21, x22, [sp, #32]
    4498:	aa0103f5 	mov	x21, x1
    449c:	a90363f7 	stp	x23, x24, [sp, #48]
    44a0:	eb00029f 	cmp	x20, x0
    44a4:	54000160 	b.eq	44d0 <fwp_closure_drop_push+0x50>  // b.none
    44a8:	f9400276 	ldr	x22, [x19]
    44ac:	d37df297 	lsl	x23, x20, #3
    44b0:	91000694 	add	x20, x20, #0x1
    44b4:	f9000674 	str	x20, [x19, #8]
    44b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44bc:	f8376ad5 	str	x21, [x22, x23]
    44c0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44c4:	a94363f7 	ldp	x23, x24, [sp, #48]
    44c8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    44cc:	d65f03c0 	ret
    44d0:	a9046bf9 	stp	x25, x26, [sp, #64]
    44d4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    44d8:	eb00029f 	cmp	x20, x0
    44dc:	540003e8 	b.hi	4558 <fwp_closure_drop_push+0xd8>  // b.pmore
    44e0:	d37cee99 	lsl	x25, x20, #4
    44e4:	d37ffa9a 	lsl	x26, x20, #1
    44e8:	aa1903e0 	mov	x0, x25
    44ec:	97fff8cd 	bl	2820 <malloc@plt>
    44f0:	aa0003f6 	mov	x22, x0
    44f4:	b4000380 	cbz	x0, 4564 <fwp_closure_drop_push+0xe4>
    44f8:	aa1303f8 	mov	x24, x19
    44fc:	aa1903e3 	mov	x3, x25
    4500:	d37df297 	lsl	x23, x20, #3
    4504:	aa1703e2 	mov	x2, x23
    4508:	f8418719 	ldr	x25, [x24], #24
    450c:	aa1903e1 	mov	x1, x25
    4510:	97fff8b0 	bl	27d0 <__memcpy_chk@plt>
    4514:	eb18033f 	cmp	x25, x24
    4518:	540000a0 	b.eq	452c <fwp_closure_drop_push+0xac>  // b.none
    451c:	aa1903e0 	mov	x0, x25
    4520:	97fff908 	bl	2940 <free@plt>
    4524:	f9400674 	ldr	x20, [x19, #8]
    4528:	d37df297 	lsl	x23, x20, #3
    452c:	91000694 	add	x20, x20, #0x1
    4530:	f9000276 	str	x22, [x19]
    4534:	f9000a7a 	str	x26, [x19, #16]
    4538:	a9446bf9 	ldp	x25, x26, [sp, #64]
    453c:	f9000674 	str	x20, [x19, #8]
    4540:	f8376ad5 	str	x21, [x22, x23]
    4544:	a94153f3 	ldp	x19, x20, [sp, #16]
    4548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    454c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4550:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4554:	d65f03c0 	ret
    4558:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    455c:	91184000 	add	x0, x0, #0x610
    4560:	97fffe4c 	bl	3e90 <fwp_trap>
    4564:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    4568:	f947e863 	ldr	x3, [x3, #4048]
    456c:	d2800262 	mov	x2, #0x13                  	// #19
    4570:	d2800021 	mov	x1, #0x1                   	// #1
    4574:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4578:	9111a000 	add	x0, x0, #0x468
    457c:	f9400063 	ldr	x3, [x3]
    4580:	97fff900 	bl	2980 <fwrite@plt>
    4584:	d2800000 	mov	x0, #0x0                   	// #0
    4588:	97fff90a 	bl	29b0 <fflush@plt>
    458c:	52800cc0 	mov	w0, #0x66                  	// #102
    4590:	97fff918 	bl	29f0 <_Exit@plt>

0000000000004594 <fwp_closure_drop.part.0>:
    4594:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4598:	d0000021 	adrp	x1, a000 <_IO_stdin_used+0xba0>
    459c:	910003fd 	mov	x29, sp
    45a0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    45a4:	f947f463 	ldr	x3, [x3, #4072]
    45a8:	a90153f3 	stp	x19, x20, [sp, #16]
    45ac:	d10883ff 	sub	sp, sp, #0x220
    45b0:	910003e2 	mov	x2, sp
    45b4:	d53bd053 	mrs	x19, tpidr_el0
    45b8:	910063f4 	add	x20, sp, #0x18
    45bc:	3dc01c20 	ldr	q0, [x1, #112]
    45c0:	91400264 	add	x4, x19, #0x0, lsl #12
    45c4:	91004084 	add	x4, x4, #0x10
    45c8:	aa0003e1 	mov	x1, x0
    45cc:	aa0203e0 	mov	x0, x2
    45d0:	f9400062 	ldr	x2, [x3]
    45d4:	f9010fe2 	str	x2, [sp, #536]
    45d8:	d2800002 	mov	x2, #0x0                   	// #0
    45dc:	f90003f4 	str	x20, [sp]
    45e0:	f9000080 	str	x0, [x4]
    45e4:	3c8083e0 	stur	q0, [sp, #8]
    45e8:	97ffffa6 	bl	4480 <fwp_closure_drop_push>
    45ec:	f94007e0 	ldr	x0, [sp, #8]
    45f0:	b40002e0 	cbz	x0, 464c <fwp_closure_drop.part.0+0xb8>
    45f4:	f90123f5 	str	x21, [sp, #576]
    45f8:	900000f5 	adrp	x21, 20000 <__data_start>
    45fc:	9100c2b5 	add	x21, x21, #0x30
    4600:	14000006 	b	4618 <fwp_closure_drop.part.0+0x84>
    4604:	f9400422 	ldr	x2, [x1, #8]
    4608:	52800001 	mov	w1, #0x0                   	// #0
    460c:	d63f0040 	blr	x2
    4610:	f94007e0 	ldr	x0, [sp, #8]
    4614:	b40001a0 	cbz	x0, 4648 <fwp_closure_drop.part.0+0xb4>
    4618:	f94003e1 	ldr	x1, [sp]
    461c:	d1000400 	sub	x0, x0, #0x1
    4620:	f90007e0 	str	x0, [sp, #8]
    4624:	f9403ea2 	ldr	x2, [x21, #120]
    4628:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    462c:	b9400001 	ldr	w1, [x0]
    4630:	8b011441 	add	x1, x2, x1, lsl #5
    4634:	f9400c21 	ldr	x1, [x1, #24]
    4638:	b5fffe61 	cbnz	x1, 4604 <fwp_closure_drop.part.0+0x70>
    463c:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4640:	9118c000 	add	x0, x0, #0x630
    4644:	97fffe13 	bl	3e90 <fwp_trap>
    4648:	f94123f5 	ldr	x21, [sp, #576]
    464c:	91400273 	add	x19, x19, #0x0, lsl #12
    4650:	91004273 	add	x19, x19, #0x10
    4654:	f94003e0 	ldr	x0, [sp]
    4658:	f900027f 	str	xzr, [x19]
    465c:	eb14001f 	cmp	x0, x20
    4660:	54000040 	b.eq	4668 <fwp_closure_drop.part.0+0xd4>  // b.none
    4664:	97fff8b7 	bl	2940 <free@plt>
    4668:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    466c:	f947f400 	ldr	x0, [x0, #4072]
    4670:	f9410fe2 	ldr	x2, [sp, #536]
    4674:	f9400001 	ldr	x1, [x0]
    4678:	eb010042 	subs	x2, x2, x1
    467c:	d2800001 	mov	x1, #0x0                   	// #0
    4680:	540000a1 	b.ne	4694 <fwp_closure_drop.part.0+0x100>  // b.any
    4684:	910883ff 	add	sp, sp, #0x220
    4688:	a94153f3 	ldp	x19, x20, [sp, #16]
    468c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4690:	d65f03c0 	ret
    4694:	f90123f5 	str	x21, [sp, #576]
    4698:	97fff87a 	bl	2880 <__stack_chk_fail@plt>
    469c:	d503201f 	nop

00000000000046a0 <fwp_tape_of>:
    46a0:	aa0003e1 	mov	x1, x0
    46a4:	92403c00 	and	x0, x0, #0xffff
    46a8:	b40000e0 	cbz	x0, 46c4 <fwp_tape_of+0x24>
    46ac:	d1000402 	sub	x2, x0, #0x1
    46b0:	900000e3 	adrp	x3, 20000 <__data_start>
    46b4:	9100c060 	add	x0, x3, #0x30
    46b8:	f9404000 	ldr	x0, [x0, #128]
    46bc:	eb02001f 	cmp	x0, x2
    46c0:	540000cc 	b.gt	46d8 <fwp_tape_of+0x38>
    46c4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    46c8:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    46cc:	91198000 	add	x0, x0, #0x660
    46d0:	910003fd 	mov	x29, sp
    46d4:	97fffdef 	bl	3e90 <fwp_trap>
    46d8:	8b020440 	add	x0, x2, x2, lsl #1
    46dc:	f9401863 	ldr	x3, [x3, #48]
    46e0:	8b000842 	add	x2, x2, x0, lsl #2
    46e4:	d37df042 	lsl	x2, x2, #3
    46e8:	8b020060 	add	x0, x3, x2
    46ec:	b9400404 	ldr	w4, [x0, #4]
    46f0:	34fffea4 	cbz	w4, 46c4 <fwp_tape_of+0x24>
    46f4:	b8626862 	ldr	w2, [x3, x2]
    46f8:	9350fc21 	asr	x1, x1, #16
    46fc:	6b01005f 	cmp	w2, w1
    4700:	54fffe21 	b.ne	46c4 <fwp_tape_of+0x24>  // b.any
    4704:	d65f03c0 	ret
    4708:	d503201f 	nop
    470c:	d503201f 	nop

0000000000004710 <fwp_now_ns>:
    4710:	d100c3ff 	sub	sp, sp, #0x30
    4714:	52800020 	mov	w0, #0x1                   	// #1
    4718:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    471c:	f947f442 	ldr	x2, [x2, #4072]
    4720:	910023e1 	add	x1, sp, #0x8
    4724:	a9027bfd 	stp	x29, x30, [sp, #32]
    4728:	910083fd 	add	x29, sp, #0x20
    472c:	f9400043 	ldr	x3, [x2]
    4730:	f9000fe3 	str	x3, [sp, #24]
    4734:	d2800003 	mov	x3, #0x0                   	// #0
    4738:	97fff81e 	bl	27b0 <clock_gettime@plt>
    473c:	350002c0 	cbnz	w0, 4794 <fwp_now_ns+0x84>
    4740:	a9408be1 	ldp	x1, x2, [sp, #8]
    4744:	d2994003 	mov	x3, #0xca00                	// #51712
    4748:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    474c:	9b037c20 	mul	x0, x1, x3
    4750:	9b437c21 	smulh	x1, x1, x3
    4754:	ab020000 	adds	x0, x0, x2
    4758:	937ffc42 	asr	x2, x2, #63
    475c:	9a020021 	adc	x1, x1, x2
    4760:	f100001f 	cmp	x0, #0x0
    4764:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4768:	b50001c1 	cbnz	x1, 47a0 <fwp_now_ns+0x90>
    476c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    4770:	f947f421 	ldr	x1, [x1, #4072]
    4774:	f9400fe3 	ldr	x3, [sp, #24]
    4778:	f9400022 	ldr	x2, [x1]
    477c:	eb020063 	subs	x3, x3, x2
    4780:	d2800002 	mov	x2, #0x0                   	// #0
    4784:	54000141 	b.ne	47ac <fwp_now_ns+0x9c>  // b.any
    4788:	a9427bfd 	ldp	x29, x30, [sp, #32]
    478c:	9100c3ff 	add	sp, sp, #0x30
    4790:	d65f03c0 	ret
    4794:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4798:	911ac000 	add	x0, x0, #0x6b0
    479c:	97fffdbd 	bl	3e90 <fwp_trap>
    47a0:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    47a4:	911b4000 	add	x0, x0, #0x6d0
    47a8:	97fffdba 	bl	3e90 <fwp_trap>
    47ac:	97fff835 	bl	2880 <__stack_chk_fail@plt>

00000000000047b0 <fwp_poll_events>:
    47b0:	d10103ff 	sub	sp, sp, #0x40
    47b4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    47b8:	f947f400 	ldr	x0, [x0, #4072]
    47bc:	a9027bfd 	stp	x29, x30, [sp, #32]
    47c0:	910083fd 	add	x29, sp, #0x20
    47c4:	f9001bf3 	str	x19, [sp, #48]
    47c8:	900000f3 	adrp	x19, 20000 <__data_start>
    47cc:	f9400001 	ldr	x1, [x0]
    47d0:	f9000fe1 	str	x1, [sp, #24]
    47d4:	d2800001 	mov	x1, #0x0                   	// #0
    47d8:	97ffffce 	bl	4710 <fwp_now_ns>
    47dc:	9100c261 	add	x1, x19, #0x30
    47e0:	f9404421 	ldr	x1, [x1, #136]
    47e4:	b4000e01 	cbz	x1, 49a4 <fwp_poll_events+0x1f4>
    47e8:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    47ec:	14000005 	b	4800 <fwp_poll_events+0x50>
    47f0:	f9408821 	ldr	x1, [x1, #272]
    47f4:	eb03005f 	cmp	x2, x3
    47f8:	9a83d042 	csel	x2, x2, x3, le
    47fc:	b40000c1 	cbz	x1, 4814 <fwp_poll_events+0x64>
    4800:	f9403423 	ldr	x3, [x1, #104]
    4804:	b6ffff62 	tbz	x2, #63, 47f0 <fwp_poll_events+0x40>
    4808:	f9408821 	ldr	x1, [x1, #272]
    480c:	aa0303e2 	mov	x2, x3
    4810:	b5ffff81 	cbnz	x1, 4800 <fwp_poll_events+0x50>
    4814:	b7f80c82 	tbnz	x2, #63, 49a4 <fwp_poll_events+0x1f4>
    4818:	cb000042 	sub	x2, x2, x0
    481c:	f100005f 	cmp	x2, #0x0
    4820:	540003ad 	b.le	4894 <fwp_poll_events+0xe4>
    4824:	d2869b60 	mov	x0, #0x34db                	// #13531
    4828:	d2884804 	mov	x4, #0x4240                	// #16960
    482c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4830:	f2a001e4 	movk	x4, #0xf, lsl #16
    4834:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4838:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    483c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4840:	9b407c40 	smulh	x0, x2, x0
    4844:	9352fc00 	asr	x0, x0, #18
    4848:	cb82fc00 	sub	x0, x0, x2, asr #63
    484c:	9b048802 	msub	x2, x0, x4, x2
    4850:	f100005f 	cmp	x2, #0x0
    4854:	9a800400 	cinc	x0, x0, ne	// ne = any
    4858:	eb01001f 	cmp	x0, x1
    485c:	5400098c 	b.gt	498c <fwp_poll_events+0x1dc>
    4860:	340001a0 	cbz	w0, 4894 <fwp_poll_events+0xe4>
    4864:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4868:	52807d05 	mov	w5, #0x3e8                 	// #1000
    486c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4870:	9ba17c01 	umull	x1, w0, w1
    4874:	d366fc23 	lsr	x3, x1, #38
    4878:	aa0303e2 	mov	x2, x3
    487c:	1b058063 	msub	w3, w3, w5, w0
    4880:	9b247c63 	smull	x3, w3, w4
    4884:	910023e0 	add	x0, sp, #0x8
    4888:	d2800001 	mov	x1, #0x0                   	// #0
    488c:	a9008fe2 	stp	x2, x3, [sp, #8]
    4890:	97fff830 	bl	2950 <nanosleep@plt>
    4894:	97ffff9f 	bl	4710 <fwp_now_ns>
    4898:	9100c268 	add	x8, x19, #0x30
    489c:	aa0003e7 	mov	x7, x0
    48a0:	4f000400 	movi	v0.4s, #0x0
    48a4:	52800029 	mov	w9, #0x1                   	// #1
    48a8:	f9404506 	ldr	x6, [x8, #136]
    48ac:	d503201f 	nop
    48b0:	b40003e6 	cbz	x6, 492c <fwp_poll_events+0x17c>
    48b4:	f94034c1 	ldr	x1, [x6, #104]
    48b8:	aa0603e5 	mov	x5, x6
    48bc:	f94088c6 	ldr	x6, [x6, #272]
    48c0:	eb07003f 	cmp	x1, x7
    48c4:	54ffff6c 	b.gt	48b0 <fwp_poll_events+0x100>
    48c8:	394154a0 	ldrb	w0, [x5, #85]
    48cc:	36000120 	tbz	w0, #0, 48f0 <fwp_poll_events+0x140>
    48d0:	f94084a0 	ldr	x0, [x5, #264]
    48d4:	b4000560 	cbz	x0, 4980 <fwp_poll_events+0x1d0>
    48d8:	f9008806 	str	x6, [x0, #272]
    48dc:	b4000046 	cbz	x6, 48e4 <fwp_poll_events+0x134>
    48e0:	f90084c0 	str	x0, [x6, #264]
    48e4:	910800a0 	add	x0, x5, #0x200
    48e8:	390154bf 	strb	wzr, [x5, #85]
    48ec:	3c908000 	stur	q0, [x0, #-248]
    48f0:	f94030a0 	ldr	x0, [x5, #96]
    48f4:	390158a9 	strb	w9, [x5, #86]
    48f8:	f100001f 	cmp	x0, #0x0
    48fc:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4900:	540002cd 	b.le	4958 <fwp_poll_events+0x1a8>
    4904:	f94028a0 	ldr	x0, [x5, #80]
    4908:	f2001c1f 	tst	x0, #0xff000000ff
    490c:	54fffd21 	b.ne	48b0 <fwp_poll_events+0x100>  // b.any
    4910:	f9401500 	ldr	x0, [x8, #40]
    4914:	390150a9 	strb	w9, [x5, #84]
    4918:	f90080bf 	str	xzr, [x5, #256]
    491c:	b40002c0 	cbz	x0, 4974 <fwp_poll_events+0x1c4>
    4920:	f9001505 	str	x5, [x8, #40]
    4924:	f9008005 	str	x5, [x0, #256]
    4928:	b5fffc66 	cbnz	x6, 48b4 <fwp_poll_events+0x104>
    492c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    4930:	f947f400 	ldr	x0, [x0, #4072]
    4934:	f9400fe2 	ldr	x2, [sp, #24]
    4938:	f9400001 	ldr	x1, [x0]
    493c:	eb010042 	subs	x2, x2, x1
    4940:	d2800001 	mov	x1, #0x0                   	// #0
    4944:	540002e1 	b.ne	49a0 <fwp_poll_events+0x1f0>  // b.any
    4948:	a9427bfd 	ldp	x29, x30, [sp, #32]
    494c:	f9401bf3 	ldr	x19, [sp, #48]
    4950:	910103ff 	add	sp, sp, #0x40
    4954:	d65f03c0 	ret
    4958:	394144a0 	ldrb	w0, [x5, #81]
    495c:	3707fd40 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4960:	394140a0 	ldrb	w0, [x5, #80]
    4964:	3707fd00 	tbnz	w0, #0, 4904 <fwp_poll_events+0x154>
    4968:	aa0503e0 	mov	x0, x5
    496c:	97fffac1 	bl	3470 <fwp_cancel_tree.part.0>
    4970:	17ffffe5 	b	4904 <fwp_poll_events+0x154>
    4974:	f9001505 	str	x5, [x8, #40]
    4978:	f9001905 	str	x5, [x8, #48]
    497c:	17ffffeb 	b	4928 <fwp_poll_events+0x178>
    4980:	9100c261 	add	x1, x19, #0x30
    4984:	f9004426 	str	x6, [x1, #136]
    4988:	17ffffd5 	b	48dc <fwp_poll_events+0x12c>
    498c:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4990:	d2989362 	mov	x2, #0xc49b                	// #50331
    4994:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4998:	f2a00402 	movk	x2, #0x20, lsl #16
    499c:	17ffffba 	b	4884 <fwp_poll_events+0xd4>
    49a0:	97fff7b8 	bl	2880 <__stack_chk_fail@plt>
    49a4:	97fff993 	bl	2ff0 <fwp_flush>
    49a8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xc98>
    49ac:	f947e863 	ldr	x3, [x3, #4048]
    49b0:	d2800562 	mov	x2, #0x2b                  	// #43
    49b4:	d2800021 	mov	x1, #0x1                   	// #1
    49b8:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    49bc:	911be000 	add	x0, x0, #0x6f8
    49c0:	f9400063 	ldr	x3, [x3]
    49c4:	97fff7ef 	bl	2980 <fwrite@plt>
    49c8:	52800ca0 	mov	w0, #0x65                  	// #101
    49cc:	97fff759 	bl	2730 <exit@plt>

00000000000049d0 <fwp_heap_alloc_big>:
    49d0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    49d4:	910003fd 	mov	x29, sp
    49d8:	a90153f3 	stp	x19, x20, [sp, #16]
    49dc:	a9025bf5 	stp	x21, x22, [sp, #32]
    49e0:	a90363f7 	stp	x23, x24, [sp, #48]
    49e4:	aa0003f7 	mov	x23, x0
    49e8:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    49ec:	a9046bf9 	stp	x25, x26, [sp, #64]
    49f0:	eb0002ff 	cmp	x23, x0
    49f4:	540008a8 	b.hi	4b08 <fwp_heap_alloc_big+0x138>  // b.pmore
    49f8:	d29fffe0 	mov	x0, #0xffff                	// #65535
    49fc:	8b0002f4 	add	x20, x23, x0
    4a00:	b000017a 	adrp	x26, 31000 <fwp_root_context+0xcb0>
    4a04:	9114c359 	add	x25, x26, #0x530
    4a08:	d350fe94 	lsr	x20, x20, #16
    4a0c:	2a0103f5 	mov	w21, w1
    4a10:	aa1403e0 	mov	x0, x20
    4a14:	97fff9c7 	bl	3130 <fwp_heap_chunks>
    4a18:	f949ff22 	ldr	x2, [x25, #5112]
    4a1c:	8b000813 	add	x19, x0, x0, lsl #2
    4a20:	aa0003f8 	mov	x24, x0
    4a24:	52800043 	mov	w3, #0x2                   	// #2
    4a28:	d37df273 	lsl	x19, x19, #3
    4a2c:	d2800021 	mov	x1, #0x1                   	// #1
    4a30:	8b130040 	add	x0, x2, x19
    4a34:	38336843 	strb	w3, [x2, x19]
    4a38:	39000415 	strb	w21, [x0, #1]
    4a3c:	b9000c14 	str	w20, [x0, #12]
    4a40:	f9000817 	str	x23, [x0, #16]
    4a44:	97fffd57 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a48:	f100069f 	cmp	x20, #0x1
    4a4c:	54000289 	b.ls	4a9c <fwp_heap_alloc_big+0xcc>  // b.plast
    4a50:	8b180294 	add	x20, x20, x24
    4a54:	9100a273 	add	x19, x19, #0x28
    4a58:	a90573fb 	stp	x27, x28, [sp, #80]
    4a5c:	5280007b 	mov	w27, #0x3                   	// #3
    4a60:	8b140a94 	add	x20, x20, x20, lsl #2
    4a64:	2a1803fc 	mov	w28, w24
    4a68:	9adb2296 	lsl	x22, x20, x27
    4a6c:	d503201f 	nop
    4a70:	f949ff35 	ldr	x21, [x25, #5112]
    4a74:	d2800001 	mov	x1, #0x0                   	// #0
    4a78:	8b1302b4 	add	x20, x21, x19
    4a7c:	aa1403e0 	mov	x0, x20
    4a80:	97fffd48 	bl	3fa0 <fwp_rc_prepare_chunk>
    4a84:	38336abb 	strb	w27, [x21, x19]
    4a88:	9100a273 	add	x19, x19, #0x28
    4a8c:	b9000e9c 	str	w28, [x20, #12]
    4a90:	eb1302df 	cmp	x22, x19
    4a94:	54fffee1 	b.ne	4a70 <fwp_heap_alloc_big+0xa0>  // b.any
    4a98:	a94573fb 	ldp	x27, x28, [sp, #80]
    4a9c:	9114c353 	add	x19, x26, #0x530
    4aa0:	aa1703e2 	mov	x2, x23
    4aa4:	52800001 	mov	w1, #0x0                   	// #0
    4aa8:	f949da60 	ldr	x0, [x19, #5040]
    4aac:	8b184018 	add	x24, x0, x24, lsl #16
    4ab0:	aa1803e0 	mov	x0, x24
    4ab4:	97fff767 	bl	2850 <memset@plt>
    4ab8:	f94a1260 	ldr	x0, [x19, #5152]
    4abc:	ab170000 	adds	x0, x0, x23
    4ac0:	54000242 	b.cs	4b08 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ac4:	f94a1661 	ldr	x1, [x19, #5160]
    4ac8:	f90a1260 	str	x0, [x19, #5152]
    4acc:	eb01001f 	cmp	x0, x1
    4ad0:	54000049 	b.ls	4ad8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ad4:	f90a1660 	str	x0, [x19, #5160]
    4ad8:	9114c35a 	add	x26, x26, #0x530
    4adc:	9e6202e0 	scvtf	d0, x23
    4ae0:	a94153f3 	ldp	x19, x20, [sp, #16]
    4ae4:	aa1803e0 	mov	x0, x24
    4ae8:	fd4a1f41 	ldr	d1, [x26, #5176]
    4aec:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4af0:	1e602820 	fadd	d0, d1, d0
    4af4:	a94363f7 	ldp	x23, x24, [sp, #48]
    4af8:	fd0a1f40 	str	d0, [x26, #5176]
    4afc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4b00:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4b04:	d65f03c0 	ret
    4b08:	a90573fb 	stp	x27, x28, [sp, #80]
    4b0c:	97fff949 	bl	3030 <fwp_heap_oom>

0000000000004b10 <fwp_heap_alloc_slow>:
    4b10:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4b14:	910003fd 	mov	x29, sp
    4b18:	a90153f3 	stp	x19, x20, [sp, #16]
    4b1c:	b0000173 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    4b20:	9114c262 	add	x2, x19, #0x530
    4b24:	a9025bf5 	stp	x21, x22, [sp, #32]
    4b28:	aa0003f5 	mov	x21, x0
    4b2c:	2a0103f4 	mov	w20, w1
    4b30:	b953a440 	ldr	w0, [x2, #5028]
    4b34:	34000600 	cbz	w0, 4bf4 <fwp_heap_alloc_slow+0xe4>
    4b38:	f14012bf 	cmp	x21, #0x4, lsl #12
    4b3c:	54000628 	b.hi	4c00 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4b40:	91003ea0 	add	x0, x21, #0xf
    4b44:	9114c262 	add	x2, x19, #0x530
    4b48:	f9001bf7 	str	x23, [sp, #48]
    4b4c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4b50:	8b401040 	add	x0, x2, x0, lsr #4
    4b54:	cb34c084 	sub	x4, x4, w20, sxtw
    4b58:	d37ae484 	lsl	x4, x4, #6
    4b5c:	397e8003 	ldrb	w3, [x0, #4000]
    4b60:	910f0060 	add	x0, x3, #0x3c0
    4b64:	aa0303e1 	mov	x1, x3
    4b68:	8b030463 	add	x3, x3, x3, lsl #1
    4b6c:	8b030c83 	add	x3, x4, x3, lsl #3
    4b70:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4b74:	2a1703f6 	mov	w22, w23
    4b78:	f8636844 	ldr	x4, [x2, x3]
    4b7c:	b40004e4 	cbz	x4, 4c18 <fwp_heap_alloc_slow+0x108>
    4b80:	f9400080 	ldr	x0, [x4]
    4b84:	aa2003e0 	mvn	x0, x0
    4b88:	f8236840 	str	x0, [x2, x3]
    4b8c:	7100069f 	cmp	w20, #0x1
    4b90:	aa0403e0 	mov	x0, x4
    4b94:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4b98:	52800001 	mov	w1, #0x0                   	// #0
    4b9c:	97fff72d 	bl	2850 <memset@plt>
    4ba0:	aa0003e4 	mov	x4, x0
    4ba4:	9114c260 	add	x0, x19, #0x530
    4ba8:	f94a1001 	ldr	x1, [x0, #5152]
    4bac:	ab160021 	adds	x1, x1, x22
    4bb0:	540005c2 	b.cs	4c68 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4bb4:	f94a1402 	ldr	x2, [x0, #5160]
    4bb8:	f90a1001 	str	x1, [x0, #5152]
    4bbc:	eb02003f 	cmp	x1, x2
    4bc0:	54000049 	b.ls	4bc8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4bc4:	f90a1401 	str	x1, [x0, #5160]
    4bc8:	9114c273 	add	x19, x19, #0x530
    4bcc:	1e6302e1 	ucvtf	d1, w23
    4bd0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4bd4:	aa0403e0 	mov	x0, x4
    4bd8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4bdc:	f9401bf7 	ldr	x23, [sp, #48]
    4be0:	1e612800 	fadd	d0, d0, d1
    4be4:	fd0a1e60 	str	d0, [x19, #5176]
    4be8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4bec:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4bf0:	d65f03c0 	ret
    4bf4:	97fffbbf 	bl	3af0 <fwp_heap_init>
    4bf8:	f14012bf 	cmp	x21, #0x4, lsl #12
    4bfc:	54fffa29 	b.ls	4b40 <fwp_heap_alloc_slow+0x30>  // b.plast
    4c00:	2a1403e1 	mov	w1, w20
    4c04:	aa1503e0 	mov	x0, x21
    4c08:	a94153f3 	ldp	x19, x20, [sp, #16]
    4c0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4c10:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4c14:	17ffff6f 	b	49d0 <fwp_heap_alloc_big>
    4c18:	8b030042 	add	x2, x2, x3
    4c1c:	f9400444 	ldr	x4, [x2, #8]
    4c20:	b4000104 	cbz	x4, 4c40 <fwp_heap_alloc_slow+0x130>
    4c24:	f9400840 	ldr	x0, [x2, #16]
    4c28:	cb040000 	sub	x0, x0, x4
    4c2c:	eb16001f 	cmp	x0, x22
    4c30:	54000083 	b.cc	4c40 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    4c34:	8b160080 	add	x0, x4, x22
    4c38:	f9000440 	str	x0, [x2, #8]
    4c3c:	17ffffd4 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c40:	52800302 	mov	w2, #0x18                  	// #24
    4c44:	52807804 	mov	w4, #0x3c0                 	// #960
    4c48:	9114c260 	add	x0, x19, #0x530
    4c4c:	9ba27c23 	umull	x3, w1, w2
    4c50:	2a1403e2 	mov	w2, w20
    4c54:	9b240e84 	smaddl	x4, w20, w4, x3
    4c58:	8b040000 	add	x0, x0, x4
    4c5c:	97fffd19 	bl	40c0 <fwp_heap_refill>
    4c60:	aa0003e4 	mov	x4, x0
    4c64:	17ffffca 	b	4b8c <fwp_heap_alloc_slow+0x7c>
    4c68:	97fff8f2 	bl	3030 <fwp_heap_oom>
    4c6c:	d503201f 	nop

0000000000004c70 <fwp_heap_alloc>:
    4c70:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4c74:	f140101f 	cmp	x0, #0x4, lsl #12
    4c78:	910003fd 	mov	x29, sp
    4c7c:	a90153f3 	stp	x19, x20, [sp, #16]
    4c80:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4c84:	9114c293 	add	x19, x20, #0x530
    4c88:	b953a662 	ldr	w2, [x19, #5028]
    4c8c:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    4c90:	54000640 	b.eq	4d58 <fwp_heap_alloc+0xe8>  // b.none
    4c94:	91003c03 	add	x3, x0, #0xf
    4c98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4c9c:	937c7c22 	sbfiz	x2, x1, #4, #32
    4ca0:	8b431263 	add	x3, x19, x3, lsr #4
    4ca4:	cb21c042 	sub	x2, x2, w1, sxtw
    4ca8:	d37ae442 	lsl	x2, x2, #6
    4cac:	397e8063 	ldrb	w3, [x3, #4000]
    4cb0:	910f0064 	add	x4, x3, #0x3c0
    4cb4:	8b030463 	add	x3, x3, x3, lsl #1
    4cb8:	8b030c43 	add	x3, x2, x3, lsl #3
    4cbc:	b8647a76 	ldr	w22, [x19, x4, lsl #2]
    4cc0:	2a1603f5 	mov	w21, w22
    4cc4:	f8636a64 	ldr	x4, [x19, x3]
    4cc8:	b4000384 	cbz	x4, 4d38 <fwp_heap_alloc+0xc8>
    4ccc:	f9400085 	ldr	x5, [x4]
    4cd0:	7100043f 	cmp	w1, #0x1
    4cd4:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4cd8:	aa0403e0 	mov	x0, x4
    4cdc:	aa2503e5 	mvn	x5, x5
    4ce0:	52800001 	mov	w1, #0x0                   	// #0
    4ce4:	f8236a65 	str	x5, [x19, x3]
    4ce8:	97fff6da 	bl	2850 <memset@plt>
    4cec:	aa0003e4 	mov	x4, x0
    4cf0:	f94a1260 	ldr	x0, [x19, #5152]
    4cf4:	ab150000 	adds	x0, x0, x21
    4cf8:	54000442 	b.cs	4d80 <fwp_heap_alloc+0x110>  // b.hs, b.nlast
    4cfc:	f94a1661 	ldr	x1, [x19, #5160]
    4d00:	f90a1260 	str	x0, [x19, #5152]
    4d04:	eb01001f 	cmp	x0, x1
    4d08:	54000049 	b.ls	4d10 <fwp_heap_alloc+0xa0>  // b.plast
    4d0c:	f90a1660 	str	x0, [x19, #5160]
    4d10:	9114c294 	add	x20, x20, #0x530
    4d14:	1e6302c1 	ucvtf	d1, w22
    4d18:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d1c:	aa0403e0 	mov	x0, x4
    4d20:	fd4a1e80 	ldr	d0, [x20, #5176]
    4d24:	1e612800 	fadd	d0, d0, d1
    4d28:	fd0a1e80 	str	d0, [x20, #5176]
    4d2c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d30:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d34:	d65f03c0 	ret
    4d38:	8b030263 	add	x3, x19, x3
    4d3c:	f9400464 	ldr	x4, [x3, #8]
    4d40:	b40000a4 	cbz	x4, 4d54 <fwp_heap_alloc+0xe4>
    4d44:	f9400862 	ldr	x2, [x3, #16]
    4d48:	cb040042 	sub	x2, x2, x4
    4d4c:	eb15005f 	cmp	x2, x21
    4d50:	540000a2 	b.cs	4d64 <fwp_heap_alloc+0xf4>  // b.hs, b.nlast
    4d54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4d58:	a94153f3 	ldp	x19, x20, [sp, #16]
    4d5c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4d60:	17ffff6c 	b	4b10 <fwp_heap_alloc_slow>
    4d64:	7100043f 	cmp	w1, #0x1
    4d68:	8b150085 	add	x5, x4, x21
    4d6c:	9a950002 	csel	x2, x0, x21, eq	// eq = none
    4d70:	52800001 	mov	w1, #0x0                   	// #0
    4d74:	aa0403e0 	mov	x0, x4
    4d78:	f9000465 	str	x5, [x3, #8]
    4d7c:	17ffffdb 	b	4ce8 <fwp_heap_alloc+0x78>
    4d80:	97fff8ac 	bl	3030 <fwp_heap_oom>

0000000000004d84 <fwp_data.part.0.constprop.0>:
    4d84:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4d88:	910003fd 	mov	x29, sp
    4d8c:	a90153f3 	stp	x19, x20, [sp, #16]
    4d90:	b0000174 	adrp	x20, 31000 <fwp_root_context+0xcb0>
    4d94:	9114c283 	add	x3, x20, #0x530
    4d98:	a9025bf5 	stp	x21, x22, [sp, #32]
    4d9c:	aa0103f5 	mov	x21, x1
    4da0:	b953a461 	ldr	w1, [x3, #5028]
    4da4:	a90363f7 	stp	x23, x24, [sp, #48]
    4da8:	2a0003f8 	mov	w24, w0
    4dac:	34000701 	cbz	w1, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4db0:	397e8862 	ldrb	w2, [x3, #4002]
    4db4:	910f0040 	add	x0, x2, #0x3c0
    4db8:	8b020442 	add	x2, x2, x2, lsl #1
    4dbc:	d37df042 	lsl	x2, x2, #3
    4dc0:	b8607877 	ldr	w23, [x3, x0, lsl #2]
    4dc4:	2a1703f6 	mov	w22, w23
    4dc8:	f8626873 	ldr	x19, [x3, x2]
    4dcc:	b40004d3 	cbz	x19, 4e64 <fwp_data.part.0.constprop.0+0xe0>
    4dd0:	f9400260 	ldr	x0, [x19]
    4dd4:	aa2003e0 	mvn	x0, x0
    4dd8:	f8226860 	str	x0, [x3, x2]
    4ddc:	f10062df 	cmp	x22, #0x18
    4de0:	540000e9 	b.ls	4dfc <fwp_data.part.0.constprop.0+0x78>  // b.plast
    4de4:	d10066c2 	sub	x2, x22, #0x19
    4de8:	91006260 	add	x0, x19, #0x18
    4dec:	927df042 	and	x2, x2, #0xfffffffffffffff8
    4df0:	52800001 	mov	w1, #0x0                   	// #0
    4df4:	91002042 	add	x2, x2, #0x8
    4df8:	97fff696 	bl	2850 <memset@plt>
    4dfc:	9114c282 	add	x2, x20, #0x530
    4e00:	f94a1041 	ldr	x1, [x2, #5152]
    4e04:	ab160021 	adds	x1, x1, x22
    4e08:	540004c2 	b.cs	4ea0 <fwp_data.part.0.constprop.0+0x11c>  // b.hs, b.nlast
    4e0c:	f94a1440 	ldr	x0, [x2, #5160]
    4e10:	f90a1041 	str	x1, [x2, #5152]
    4e14:	eb00003f 	cmp	x1, x0
    4e18:	54000049 	b.ls	4e20 <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    4e1c:	f90a1441 	str	x1, [x2, #5160]
    4e20:	9114c294 	add	x20, x20, #0x530
    4e24:	1e6302e1 	ucvtf	d1, w23
    4e28:	fd4a1e80 	ldr	d0, [x20, #5176]
    4e2c:	1e612800 	fadd	d0, d0, d1
    4e30:	fd0a1e80 	str	d0, [x20, #5176]
    4e34:	52800041 	mov	w1, #0x2                   	// #2
    4e38:	29000678 	stp	w24, w1, [x19]
    4e3c:	aa1303e0 	mov	x0, x19
    4e40:	f94002a1 	ldr	x1, [x21]
    4e44:	f9000661 	str	x1, [x19, #8]
    4e48:	f94006a1 	ldr	x1, [x21, #8]
    4e4c:	f9000a61 	str	x1, [x19, #16]
    4e50:	a94153f3 	ldp	x19, x20, [sp, #16]
    4e54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4e58:	a94363f7 	ldp	x23, x24, [sp, #48]
    4e5c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4e60:	d65f03c0 	ret
    4e64:	8b020063 	add	x3, x3, x2
    4e68:	f9400473 	ldr	x19, [x3, #8]
    4e6c:	b4000113 	cbz	x19, 4e8c <fwp_data.part.0.constprop.0+0x108>
    4e70:	f9400860 	ldr	x0, [x3, #16]
    4e74:	cb130000 	sub	x0, x0, x19
    4e78:	eb0002df 	cmp	x22, x0
    4e7c:	54000088 	b.hi	4e8c <fwp_data.part.0.constprop.0+0x108>  // b.pmore
    4e80:	8b160260 	add	x0, x19, x22
    4e84:	f9000460 	str	x0, [x3, #8]
    4e88:	17ffffd5 	b	4ddc <fwp_data.part.0.constprop.0+0x58>
    4e8c:	52800001 	mov	w1, #0x0                   	// #0
    4e90:	d2800300 	mov	x0, #0x18                  	// #24
    4e94:	97ffff77 	bl	4c70 <fwp_heap_alloc>
    4e98:	aa0003f3 	mov	x19, x0
    4e9c:	17ffffe6 	b	4e34 <fwp_data.part.0.constprop.0+0xb0>
    4ea0:	97fff864 	bl	3030 <fwp_heap_oom>

0000000000004ea4 <fwp_tape_reserve>:
    4ea4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    4ea8:	910003fd 	mov	x29, sp
    4eac:	a90153f3 	stp	x19, x20, [sp, #16]
    4eb0:	aa0003f3 	mov	x19, x0
    4eb4:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    4eb8:	eb00003f 	cmp	x1, x0
    4ebc:	54000868 	b.hi	4fc8 <fwp_tape_reserve+0x124>  // b.pmore
    4ec0:	f9400e74 	ldr	x20, [x19, #24]
    4ec4:	eb01029f 	cmp	x20, x1
    4ec8:	5400076a 	b.ge	4fb4 <fwp_tape_reserve+0x110>  // b.tcont
    4ecc:	f100029f 	cmp	x20, #0x0
    4ed0:	d2800802 	mov	x2, #0x40                  	// #64
    4ed4:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    4ed8:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    4edc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4ee0:	a90363f7 	stp	x23, x24, [sp, #48]
    4ee4:	eb01029f 	cmp	x20, x1
    4ee8:	5400008a 	b.ge	4ef8 <fwp_tape_reserve+0x54>  // b.tcont
    4eec:	eb00029f 	cmp	x20, x0
    4ef0:	5400068d 	b.le	4fc0 <fwp_tape_reserve+0x11c>
    4ef4:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    4ef8:	a940d662 	ldp	x2, x21, [x19, #8]
    4efc:	d37df297 	lsl	x23, x20, #3
    4f00:	f9401260 	ldr	x0, [x19, #32]
    4f04:	aa1703e1 	mov	x1, x23
    4f08:	f9403276 	ldr	x22, [x19, #96]
    4f0c:	cb0202b5 	sub	x21, x21, x2
    4f10:	97fff658 	bl	2870 <realloc@plt>
    4f14:	b4000b00 	cbz	x0, 5074 <fwp_tape_reserve+0x1d0>
    4f18:	f9400e61 	ldr	x1, [x19, #24]
    4f1c:	8b010801 	add	x1, x0, x1, lsl #2
    4f20:	a9020660 	stp	x0, x1, [x19, #32]
    4f24:	b40008b6 	cbz	x22, 5038 <fwp_tape_reserve+0x194>
    4f28:	f94032d7 	ldr	x23, [x22, #96]
    4f2c:	eb17029f 	cmp	x20, x23
    4f30:	5400034d 	b.le	4f98 <fwp_tape_reserve+0xf4>
    4f34:	a9046bf9 	stp	x25, x26, [sp, #64]
    4f38:	d37cee9a 	lsl	x26, x20, #4
    4f3c:	aa1a03e0 	mov	x0, x26
    4f40:	f94022d9 	ldr	x25, [x22, #64]
    4f44:	52800041 	mov	w1, #0x2                   	// #2
    4f48:	97ffff4a 	bl	4c70 <fwp_heap_alloc>
    4f4c:	aa0003f8 	mov	x24, x0
    4f50:	b4000119 	cbz	x25, 4f70 <fwp_tape_reserve+0xcc>
    4f54:	d37ceef7 	lsl	x23, x23, #4
    4f58:	aa1903e1 	mov	x1, x25
    4f5c:	eb1a02ff 	cmp	x23, x26
    4f60:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    4f64:	97fff5db 	bl	26d0 <memcpy@plt>
    4f68:	aa1903e0 	mov	x0, x25
    4f6c:	97fffc85 	bl	4180 <fwp_mem_free>
    4f70:	f94032c0 	ldr	x0, [x22, #96]
    4f74:	52800001 	mov	w1, #0x0                   	// #0
    4f78:	cb000282 	sub	x2, x20, x0
    4f7c:	8b001300 	add	x0, x24, x0, lsl #4
    4f80:	d37cec42 	lsl	x2, x2, #4
    4f84:	97fff633 	bl	2850 <memset@plt>
    4f88:	f9401260 	ldr	x0, [x19, #32]
    4f8c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f90:	f90022d8 	str	x24, [x22, #64]
    4f94:	f90032d4 	str	x20, [x22, #96]
    4f98:	d37ef696 	lsl	x22, x20, #2
    4f9c:	b5000375 	cbnz	x21, 5008 <fwp_tape_reserve+0x164>
    4fa0:	a94363f7 	ldp	x23, x24, [sp, #48]
    4fa4:	8b160000 	add	x0, x0, x22
    4fa8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4fac:	f9000e74 	str	x20, [x19, #24]
    4fb0:	f9001660 	str	x0, [x19, #40]
    4fb4:	a94153f3 	ldp	x19, x20, [sp, #16]
    4fb8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4fbc:	d65f03c0 	ret
    4fc0:	d37ffa94 	lsl	x20, x20, #1
    4fc4:	17ffffc8 	b	4ee4 <fwp_tape_reserve+0x40>
    4fc8:	b0000020 	adrp	x0, 9000 <__divti3+0x2c0>
    4fcc:	911d4000 	add	x0, x0, #0x750
    4fd0:	a9025bf5 	stp	x21, x22, [sp, #32]
    4fd4:	a90363f7 	stp	x23, x24, [sp, #48]
    4fd8:	a9046bf9 	stp	x25, x26, [sp, #64]
    4fdc:	97fffbad 	bl	3e90 <fwp_trap>
    4fe0:	eb1602ff 	cmp	x23, x22
    4fe4:	aa0403e0 	mov	x0, x4
    4fe8:	9a9622e3 	csel	x3, x23, x22, cs	// cs = hs, nlast
    4fec:	d37df2a2 	lsl	x2, x21, #3
    4ff0:	cb170063 	sub	x3, x3, x23
    4ff4:	97fff68b 	bl	2a20 <__memmove_chk@plt>
    4ff8:	f9401a61 	ldr	x1, [x19, #48]
    4ffc:	f9401260 	ldr	x0, [x19, #32]
    5000:	8b170021 	add	x1, x1, x23
    5004:	f9001e61 	str	x1, [x19, #56]
    5008:	f9401661 	ldr	x1, [x19, #40]
    500c:	d37ef696 	lsl	x22, x20, #2
    5010:	d37ef6a2 	lsl	x2, x21, #2
    5014:	8b160000 	add	x0, x0, x22
    5018:	97fff5b6 	bl	26f0 <memmove@plt>
    501c:	f9401260 	ldr	x0, [x19, #32]
    5020:	a94363f7 	ldp	x23, x24, [sp, #48]
    5024:	8b160000 	add	x0, x0, x22
    5028:	a9425bf5 	ldp	x21, x22, [sp, #32]
    502c:	f9000e74 	str	x20, [x19, #24]
    5030:	f9001660 	str	x0, [x19, #40]
    5034:	17ffffe0 	b	4fb4 <fwp_tape_reserve+0x110>
    5038:	f9401a60 	ldr	x0, [x19, #48]
    503c:	d37cee96 	lsl	x22, x20, #4
    5040:	aa1603e1 	mov	x1, x22
    5044:	97fff60b 	bl	2870 <realloc@plt>
    5048:	b4000160 	cbz	x0, 5074 <fwp_tape_reserve+0x1d0>
    504c:	f9400e62 	ldr	x2, [x19, #24]
    5050:	f9001a60 	str	x0, [x19, #48]
    5054:	8b170004 	add	x4, x0, x23
    5058:	8b020c01 	add	x1, x0, x2, lsl #3
    505c:	f9001e61 	str	x1, [x19, #56]
    5060:	b5fffc15 	cbnz	x21, 4fe0 <fwp_tape_reserve+0x13c>
    5064:	f9401260 	ldr	x0, [x19, #32]
    5068:	d37ef696 	lsl	x22, x20, #2
    506c:	f9001e64 	str	x4, [x19, #56]
    5070:	17ffffcc 	b	4fa0 <fwp_tape_reserve+0xfc>
    5074:	aa1303e0 	mov	x0, x19
    5078:	a9046bf9 	stp	x25, x26, [sp, #64]
    507c:	97fff7c5 	bl	2f90 <fwp_tape_unlink_scope>
    5080:	f9401260 	ldr	x0, [x19, #32]
    5084:	97fff62f 	bl	2940 <free@plt>
    5088:	f9401a60 	ldr	x0, [x19, #48]
    508c:	97fff62d 	bl	2940 <free@plt>
    5090:	f9402260 	ldr	x0, [x19, #64]
    5094:	97fff62b 	bl	2940 <free@plt>
    5098:	f9000e7f 	str	xzr, [x19, #24]
    509c:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    50a0:	f947e821 	ldr	x1, [x1, #4048]
    50a4:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    50a8:	d2800262 	mov	x2, #0x13                  	// #19
    50ac:	4f000400 	movi	v0.4s, #0x0
    50b0:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    50b4:	f9400023 	ldr	x3, [x1]
    50b8:	b900067f 	str	wzr, [x19, #4]
    50bc:	d2800021 	mov	x1, #0x1                   	// #1
    50c0:	9111a000 	add	x0, x0, #0x468
    50c4:	3c808260 	stur	q0, [x19, #8]
    50c8:	ad010260 	stp	q0, q0, [x19, #32]
    50cc:	97fff62d 	bl	2980 <fwrite@plt>
    50d0:	d2800000 	mov	x0, #0x0                   	// #0
    50d4:	97fff637 	bl	29b0 <fflush@plt>
    50d8:	52800cc0 	mov	w0, #0x66                  	// #102
    50dc:	97fff645 	bl	29f0 <_Exit@plt>

00000000000050e0 <f141.constprop.0>:
    50e0:	f100001f 	cmp	x0, #0x0
    50e4:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    50e8:	5400094b 	b.lt	5210 <f141.constprop.0+0x130>  // b.tstop
    50ec:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    50f0:	aa0003e2 	mov	x2, x0
    50f4:	910003fd 	mov	x29, sp
    50f8:	a90153f3 	stp	x19, x20, [sp, #16]
    50fc:	aa0003f4 	mov	x20, x0
    5100:	aa010000 	orr	x0, x0, x1
    5104:	a9025bf5 	stp	x21, x22, [sp, #32]
    5108:	aa0103f6 	mov	x22, x1
    510c:	f9001bf7 	str	x23, [sp, #48]
    5110:	fd001fe8 	str	d8, [sp, #56]
    5114:	b7f80180 	tbnz	x0, #63, 5144 <f141.constprop.0+0x64>
    5118:	9360fc20 	asr	x0, x1, #32
    511c:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    5120:	eb82801f 	cmp	x0, x2, asr #32
    5124:	540007a1 	b.ne	5218 <f141.constprop.0+0x138>  // b.any
    5128:	97fffd5e 	bl	46a0 <fwp_tape_of>
    512c:	aa0003f3 	mov	x19, x0
    5130:	f9403000 	ldr	x0, [x0, #96]
    5134:	b40001e0 	cbz	x0, 5170 <f141.constprop.0+0x90>
    5138:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    513c:	911ee000 	add	x0, x0, #0x7b8
    5140:	97fffb54 	bl	3e90 <fwp_trap>
    5144:	9360fc40 	asr	x0, x2, #32
    5148:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    514c:	b6fffee2 	tbz	x2, #63, 5128 <f141.constprop.0+0x48>
    5150:	2f00e408 	movi	d8, #0x0
    5154:	9360fc20 	asr	x0, x1, #32
    5158:	aa0103f4 	mov	x20, x1
    515c:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5160:	97fffd50 	bl	46a0 <fwp_tape_of>
    5164:	aa0003f3 	mov	x19, x0
    5168:	f9403000 	ldr	x0, [x0, #96]
    516c:	b5fffe60 	cbnz	x0, 5138 <f141.constprop.0+0x58>
    5170:	f9400a77 	ldr	x23, [x19, #16]
    5174:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5178:	eb0002ff 	cmp	x23, x0
    517c:	5400044c 	b.gt	5204 <f141.constprop.0+0x124>
    5180:	eb3442ff 	cmp	x23, w20, uxtw
    5184:	5400008d 	b.le	5194 <f141.constprop.0+0xb4>
    5188:	b7f800d6 	tbnz	x22, #63, 51a0 <f141.constprop.0+0xc0>
    518c:	eb3642ff 	cmp	x23, w22, uxtw
    5190:	5400008c 	b.gt	51a0 <f141.constprop.0+0xc0>
    5194:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5198:	911fa000 	add	x0, x0, #0x7e8
    519c:	97fffb3d 	bl	3e90 <fwp_trap>
    51a0:	f9400675 	ldr	x21, [x19, #8]
    51a4:	aa1303e0 	mov	x0, x19
    51a8:	cb1502f5 	sub	x21, x23, x21
    51ac:	910006a1 	add	x1, x21, #0x1
    51b0:	97ffff3d 	bl	4ea4 <fwp_tape_reserve>
    51b4:	a9420262 	ldp	x2, x0, [x19, #32]
    51b8:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    51bc:	f9401a61 	ldr	x1, [x19, #48]
    51c0:	b8357854 	str	w20, [x2, x21, lsl #2]
    51c4:	f9401e62 	ldr	x2, [x19, #56]
    51c8:	f10002df 	cmp	x22, #0x0
    51cc:	fc357820 	str	d0, [x1, x21, lsl #3]
    51d0:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    51d4:	b8357816 	str	w22, [x0, x21, lsl #2]
    51d8:	92607e80 	and	x0, x20, #0xffffffff00000000
    51dc:	910006e1 	add	x1, x23, #0x1
    51e0:	aa170000 	orr	x0, x0, x23
    51e4:	fc357848 	str	d8, [x2, x21, lsl #3]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	f9401bf7 	ldr	x23, [sp, #48]
    51f0:	fd401fe8 	ldr	d8, [sp, #56]
    51f4:	f9000a61 	str	x1, [x19, #16]
    51f8:	a94153f3 	ldp	x19, x20, [sp, #16]
    51fc:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5200:	d65f03c0 	ret
    5204:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5208:	911d4000 	add	x0, x0, #0x750
    520c:	97fffb21 	bl	3e90 <fwp_trap>
    5210:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5214:	d65f03c0 	ret
    5218:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    521c:	911dc000 	add	x0, x0, #0x770
    5220:	97fffb1c 	bl	3e90 <fwp_trap>

0000000000005224 <w120>:
    5224:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    5228:	910003fd 	mov	x29, sp
    522c:	a90153f3 	stp	x19, x20, [sp, #16]
    5230:	a9025bf5 	stp	x21, x22, [sp, #32]
    5234:	aa0003f5 	mov	x21, x0
    5238:	a90363f7 	stp	x23, x24, [sp, #48]
    523c:	aa0103f7 	mov	x23, x1
    5240:	a9046bf9 	stp	x25, x26, [sp, #64]
    5244:	f9002bfb 	str	x27, [sp, #80]
    5248:	6d0627e8 	stp	d8, d9, [sp, #96]
    524c:	1e604028 	fmov	d8, d1
    5250:	1e600809 	fmul	d9, d0, d0
    5254:	6d072fea 	stp	d10, d11, [sp, #112]
    5258:	1e60400b 	fmov	d11, d0
    525c:	b7f81c80 	tbnz	x0, #63, 55ec <w120+0x3c8>
    5260:	9360fc19 	asr	x25, x0, #32
    5264:	aa1903e0 	mov	x0, x25
    5268:	97fffd0e 	bl	46a0 <fwp_tape_of>
    526c:	f9403001 	ldr	x1, [x0, #96]
    5270:	aa0003f3 	mov	x19, x0
    5274:	b4000081 	cbz	x1, 5284 <w120+0x60>
    5278:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    527c:	911ee000 	add	x0, x0, #0x7b8
    5280:	97fffb04 	bl	3e90 <fwp_trap>
    5284:	f9400818 	ldr	x24, [x0, #16]
    5288:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    528c:	eb01031f 	cmp	x24, x1
    5290:	54001a8c 	b.gt	55e0 <w120+0x3bc>
    5294:	eb35431f 	cmp	x24, w21, uxtw
    5298:	540019ed 	b.le	55d4 <w120+0x3b0>
    529c:	f9400416 	ldr	x22, [x0, #8]
    52a0:	92607eb4 	and	x20, x21, #0xffffffff00000000
    52a4:	aa180294 	orr	x20, x20, x24
    52a8:	cb160316 	sub	x22, x24, x22
    52ac:	910006c1 	add	x1, x22, #0x1
    52b0:	97fffefd 	bl	4ea4 <fwp_tape_reserve>
    52b4:	a9420a61 	ldp	x1, x2, [x19, #32]
    52b8:	91000700 	add	x0, x24, #0x1
    52bc:	f9401a63 	ldr	x3, [x19, #48]
    52c0:	b8367835 	str	w21, [x1, x22, lsl #2]
    52c4:	f9401e61 	ldr	x1, [x19, #56]
    52c8:	1e693908 	fsub	d8, d8, d9
    52cc:	fc36786b 	str	d11, [x3, x22, lsl #3]
    52d0:	9360fe9a 	asr	x26, x20, #32
    52d4:	b8367855 	str	w21, [x2, x22, lsl #2]
    52d8:	fc36782b 	str	d11, [x1, x22, lsl #3]
    52dc:	f9000a60 	str	x0, [x19, #16]
    52e0:	b7f80077 	tbnz	x23, #63, 52ec <w120+0xc8>
    52e4:	eb97835f 	cmp	x26, x23, asr #32
    52e8:	540019a1 	b.ne	561c <w120+0x3f8>  // b.any
    52ec:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    52f0:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    52f4:	eb19035f 	cmp	x26, x25
    52f8:	540000c0 	b.eq	5310 <w120+0xec>  // b.none
    52fc:	aa1a03e0 	mov	x0, x26
    5300:	97fffce8 	bl	46a0 <fwp_tape_of>
    5304:	aa0003f3 	mov	x19, x0
    5308:	f9403000 	ldr	x0, [x0, #96]
    530c:	b5fffb60 	cbnz	x0, 5278 <w120+0x54>
    5310:	f9400a79 	ldr	x25, [x19, #16]
    5314:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5318:	eb00033f 	cmp	x25, x0
    531c:	5400162c 	b.gt	55e0 <w120+0x3bc>
    5320:	eb34433f 	cmp	x25, w20, uxtw
    5324:	5400158d 	b.le	55d4 <w120+0x3b0>
    5328:	b7f80077 	tbnz	x23, #63, 5334 <w120+0x110>
    532c:	eb37433f 	cmp	x25, w23, uxtw
    5330:	5400152d 	b.le	55d4 <w120+0x3b0>
    5334:	f9400676 	ldr	x22, [x19, #8]
    5338:	aa1303e0 	mov	x0, x19
    533c:	cb160336 	sub	x22, x25, x22
    5340:	910006c1 	add	x1, x22, #0x1
    5344:	97fffed8 	bl	4ea4 <fwp_tape_reserve>
    5348:	a9420e62 	ldp	x2, x3, [x19, #32]
    534c:	f10002ff 	cmp	x23, #0x0
    5350:	f9401a61 	ldr	x1, [x19, #48]
    5354:	b8367854 	str	w20, [x2, x22, lsl #2]
    5358:	f9401e62 	ldr	x2, [x19, #56]
    535c:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5360:	fc367829 	str	d9, [x1, x22, lsl #3]
    5364:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5368:	b8367861 	str	w1, [x3, x22, lsl #2]
    536c:	91000737 	add	x23, x25, #0x1
    5370:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5374:	92607e94 	and	x20, x20, #0xffffffff00000000
    5378:	fc36784a 	str	d10, [x2, x22, lsl #3]
    537c:	aa190294 	orr	x20, x20, x25
    5380:	f9000a77 	str	x23, [x19, #16]
    5384:	1e6b3929 	fsub	d9, d9, d11
    5388:	b7f81675 	tbnz	x21, #63, 5654 <w120+0x430>
    538c:	9360febb 	asr	x27, x21, #32
    5390:	eb1a037f 	cmp	x27, x26
    5394:	540000e0 	b.eq	53b0 <w120+0x18c>  // b.none
    5398:	aa1b03e0 	mov	x0, x27
    539c:	97fffcc1 	bl	46a0 <fwp_tape_of>
    53a0:	aa0003f3 	mov	x19, x0
    53a4:	f9403000 	ldr	x0, [x0, #96]
    53a8:	b5fff680 	cbnz	x0, 5278 <w120+0x54>
    53ac:	f9400a77 	ldr	x23, [x19, #16]
    53b0:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    53b4:	eb0002ff 	cmp	x23, x0
    53b8:	5400114c 	b.gt	55e0 <w120+0x3bc>
    53bc:	eb3542ff 	cmp	x23, w21, uxtw
    53c0:	540010ad 	b.le	55d4 <w120+0x3b0>
    53c4:	f9400676 	ldr	x22, [x19, #8]
    53c8:	aa1303e0 	mov	x0, x19
    53cc:	cb1602f6 	sub	x22, x23, x22
    53d0:	910006c1 	add	x1, x22, #0x1
    53d4:	97fffeb4 	bl	4ea4 <fwp_tape_reserve>
    53d8:	a9420261 	ldp	x1, x0, [x19, #32]
    53dc:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    53e0:	f9401a63 	ldr	x3, [x19, #48]
    53e4:	b8367835 	str	w21, [x1, x22, lsl #2]
    53e8:	f9401e61 	ldr	x1, [x19, #56]
    53ec:	12800002 	mov	w2, #0xffffffff            	// #-1
    53f0:	fc367860 	str	d0, [x3, x22, lsl #3]
    53f4:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    53f8:	b8367802 	str	w2, [x0, x22, lsl #2]
    53fc:	92607eb5 	and	x21, x21, #0xffffffff00000000
    5400:	910006e0 	add	x0, x23, #0x1
    5404:	aa1702b7 	orr	x23, x21, x23
    5408:	fc367820 	str	d0, [x1, x22, lsl #3]
    540c:	f9000a60 	str	x0, [x19, #16]
    5410:	9360fe99 	asr	x25, x20, #32
    5414:	1e68090a 	fmul	d10, d8, d8
    5418:	eb1b033f 	cmp	x25, x27
    541c:	540000c0 	b.eq	5434 <w120+0x210>  // b.none
    5420:	aa1903e0 	mov	x0, x25
    5424:	97fffc9f 	bl	46a0 <fwp_tape_of>
    5428:	aa0003f3 	mov	x19, x0
    542c:	f9403000 	ldr	x0, [x0, #96]
    5430:	b5fff240 	cbnz	x0, 5278 <w120+0x54>
    5434:	f9400a75 	ldr	x21, [x19, #16]
    5438:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    543c:	eb0002bf 	cmp	x21, x0
    5440:	54000d0c 	b.gt	55e0 <w120+0x3bc>
    5444:	eb3442bf 	cmp	x21, w20, uxtw
    5448:	54000c6d 	b.le	55d4 <w120+0x3b0>
    544c:	f9400678 	ldr	x24, [x19, #8]
    5450:	aa1303e0 	mov	x0, x19
    5454:	92607e96 	and	x22, x20, #0xffffffff00000000
    5458:	cb1802b8 	sub	x24, x21, x24
    545c:	aa1502d6 	orr	x22, x22, x21
    5460:	91000701 	add	x1, x24, #0x1
    5464:	97fffe90 	bl	4ea4 <fwp_tape_reserve>
    5468:	a9420261 	ldp	x1, x0, [x19, #32]
    546c:	f9401a62 	ldr	x2, [x19, #48]
    5470:	b8387834 	str	w20, [x1, x24, lsl #2]
    5474:	f9401e61 	ldr	x1, [x19, #56]
    5478:	fc387848 	str	d8, [x2, x24, lsl #3]
    547c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5480:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5484:	9e670000 	fmov	d0, x0
    5488:	910006b4 	add	x20, x21, #0x1
    548c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5490:	9360fed8 	asr	x24, x22, #32
    5494:	f9000a74 	str	x20, [x19, #16]
    5498:	1e60094a 	fmul	d10, d10, d0
    549c:	eb19031f 	cmp	x24, x25
    54a0:	540000e0 	b.eq	54bc <w120+0x298>  // b.none
    54a4:	aa1803e0 	mov	x0, x24
    54a8:	97fffc7e 	bl	46a0 <fwp_tape_of>
    54ac:	aa0003f3 	mov	x19, x0
    54b0:	f9403000 	ldr	x0, [x0, #96]
    54b4:	b5ffee20 	cbnz	x0, 5278 <w120+0x54>
    54b8:	f9400a74 	ldr	x20, [x19, #16]
    54bc:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    54c0:	eb00029f 	cmp	x20, x0
    54c4:	540008ec 	b.gt	55e0 <w120+0x3bc>
    54c8:	eb36429f 	cmp	x20, w22, uxtw
    54cc:	5400084d 	b.le	55d4 <w120+0x3b0>
    54d0:	f9400675 	ldr	x21, [x19, #8]
    54d4:	aa1303e0 	mov	x0, x19
    54d8:	cb150295 	sub	x21, x20, x21
    54dc:	910006a1 	add	x1, x21, #0x1
    54e0:	97fffe71 	bl	4ea4 <fwp_tape_reserve>
    54e4:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    54e8:	9e670000 	fmov	d0, x0
    54ec:	a9420261 	ldp	x1, x0, [x19, #32]
    54f0:	1e690928 	fmul	d8, d9, d9
    54f4:	f9401a62 	ldr	x2, [x19, #48]
    54f8:	b8357836 	str	w22, [x1, x21, lsl #2]
    54fc:	f9401e61 	ldr	x1, [x19, #56]
    5500:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5504:	fc357840 	str	d0, [x2, x21, lsl #3]
    5508:	12800002 	mov	w2, #0xffffffff            	// #-1
    550c:	b8357802 	str	w2, [x0, x21, lsl #2]
    5510:	91000680 	add	x0, x20, #0x1
    5514:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5518:	aa1402d6 	orr	x22, x22, x20
    551c:	f9000a60 	str	x0, [x19, #16]
    5520:	b10006ff 	cmn	x23, #0x1
    5524:	540009e0 	b.eq	5660 <w120+0x43c>  // b.none
    5528:	9360fee0 	asr	x0, x23, #32
    552c:	eb18001f 	cmp	x0, x24
    5530:	540000a0 	b.eq	5544 <w120+0x320>  // b.none
    5534:	97fffc5b 	bl	46a0 <fwp_tape_of>
    5538:	aa0003f3 	mov	x19, x0
    553c:	f9403000 	ldr	x0, [x0, #96]
    5540:	b5ffe9c0 	cbnz	x0, 5278 <w120+0x54>
    5544:	f9400a74 	ldr	x20, [x19, #16]
    5548:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    554c:	eb00029f 	cmp	x20, x0
    5550:	5400048c 	b.gt	55e0 <w120+0x3bc>
    5554:	eb37429f 	cmp	x20, w23, uxtw
    5558:	540003ed 	b.le	55d4 <w120+0x3b0>
    555c:	f9400675 	ldr	x21, [x19, #8]
    5560:	aa1303e0 	mov	x0, x19
    5564:	cb150295 	sub	x21, x20, x21
    5568:	910006a1 	add	x1, x21, #0x1
    556c:	97fffe4e 	bl	4ea4 <fwp_tape_reserve>
    5570:	a9420a61 	ldp	x1, x2, [x19, #32]
    5574:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5578:	f9401a63 	ldr	x3, [x19, #48]
    557c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5580:	f9401e61 	ldr	x1, [x19, #56]
    5584:	aa140000 	orr	x0, x0, x20
    5588:	fc357869 	str	d9, [x3, x21, lsl #3]
    558c:	91000694 	add	x20, x20, #0x1
    5590:	b8357857 	str	w23, [x2, x21, lsl #2]
    5594:	fc357829 	str	d9, [x1, x21, lsl #3]
    5598:	f9000a74 	str	x20, [x19, #16]
    559c:	1e6a2908 	fadd	d8, d8, d10
    55a0:	aa1603e1 	mov	x1, x22
    55a4:	97fffecf 	bl	50e0 <f141.constprop.0>
    55a8:	aa0003e1 	mov	x1, x0
    55ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    55b0:	9e660100 	fmov	x0, d8
    55b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55b8:	a94363f7 	ldp	x23, x24, [sp, #48]
    55bc:	a9446bf9 	ldp	x25, x26, [sp, #64]
    55c0:	f9402bfb 	ldr	x27, [sp, #80]
    55c4:	6d4627e8 	ldp	d8, d9, [sp, #96]
    55c8:	6d472fea 	ldp	d10, d11, [sp, #112]
    55cc:	a8c87bfd 	ldp	x29, x30, [sp], #128
    55d0:	d65f03c0 	ret
    55d4:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    55d8:	911fa000 	add	x0, x0, #0x7e8
    55dc:	97fffa2d 	bl	3e90 <fwp_trap>
    55e0:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    55e4:	911d4000 	add	x0, x0, #0x750
    55e8:	97fffa2a 	bl	3e90 <fwp_trap>
    55ec:	1e693828 	fsub	d8, d1, d9
    55f0:	b6f801c1 	tbz	x1, #63, 5628 <w120+0x404>
    55f4:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    55f8:	1e68090a 	fmul	d10, d8, d8
    55fc:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5600:	9e670000 	fmov	d0, x0
    5604:	1e6b3828 	fsub	d8, d1, d11
    5608:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    560c:	aa1603e0 	mov	x0, x22
    5610:	1e60094a 	fmul	d10, d10, d0
    5614:	1e680908 	fmul	d8, d8, d8
    5618:	17ffffe1 	b	559c <w120+0x378>
    561c:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5620:	911dc000 	add	x0, x0, #0x770
    5624:	97fffa1b 	bl	3e90 <fwp_trap>
    5628:	2f00e40a 	movi	d10, #0x0
    562c:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5630:	9360fc3a 	asr	x26, x1, #32
    5634:	aa0103f4 	mov	x20, x1
    5638:	aa1a03e0 	mov	x0, x26
    563c:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5640:	97fffc18 	bl	46a0 <fwp_tape_of>
    5644:	aa0003f3 	mov	x19, x0
    5648:	f9403000 	ldr	x0, [x0, #96]
    564c:	b5ffe160 	cbnz	x0, 5278 <w120+0x54>
    5650:	17ffff30 	b	5310 <w120+0xec>
    5654:	aa1a03fb 	mov	x27, x26
    5658:	aa0003f7 	mov	x23, x0
    565c:	17ffff6d 	b	5410 <w120+0x1ec>
    5660:	aa1703e0 	mov	x0, x23
    5664:	17ffffce 	b	559c <w120+0x378>
    5668:	d503201f 	nop
    566c:	d503201f 	nop

0000000000005670 <fwp_rc_share>:
    5670:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5674:	9114c042 	add	x2, x2, #0x530
    5678:	f949d843 	ldr	x3, [x2, #5040]
    567c:	f949ec41 	ldr	x1, [x2, #5080]
    5680:	cb030000 	sub	x0, x0, x3
    5684:	eb01401f 	cmp	x0, x1, lsl #16
    5688:	540003a2 	b.cs	56fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    568c:	d350fc01 	lsr	x1, x0, #16
    5690:	f949fc44 	ldr	x4, [x2, #5112]
    5694:	8b010821 	add	x1, x1, x1, lsl #2
    5698:	d37df021 	lsl	x1, x1, #3
    569c:	8b010083 	add	x3, x4, x1
    56a0:	f9401062 	ldr	x2, [x3, #32]
    56a4:	b40002c2 	cbz	x2, 56fc <fwp_rc_share+0x8c>
    56a8:	38616881 	ldrb	w1, [x4, x1]
    56ac:	7100083f 	cmp	w1, #0x2
    56b0:	54000220 	b.eq	56f4 <fwp_rc_share+0x84>  // b.none
    56b4:	7100043f 	cmp	w1, #0x1
    56b8:	54000221 	b.ne	56fc <fwp_rc_share+0x8c>  // b.any
    56bc:	29430464 	ldp	w4, w1, [x3, #24]
    56c0:	92403c00 	and	x0, x0, #0xffff
    56c4:	9b047c00 	mul	x0, x0, x4
    56c8:	d360fc00 	lsr	x0, x0, #32
    56cc:	eb01001f 	cmp	x0, x1
    56d0:	54000162 	b.cs	56fc <fwp_rc_share+0x8c>  // b.hs, b.nlast
    56d4:	8b000042 	add	x2, x2, x0
    56d8:	39400040 	ldrb	w0, [x2]
    56dc:	34000100 	cbz	w0, 56fc <fwp_rc_share+0x8c>
    56e0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    56e4:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    56e8:	91202000 	add	x0, x0, #0x808
    56ec:	910003fd 	mov	x29, sp
    56f0:	97fff9e8 	bl	3e90 <fwp_trap>
    56f4:	72003c1f 	tst	w0, #0xffff
    56f8:	54ffff00 	b.eq	56d8 <fwp_rc_share+0x68>  // b.none
    56fc:	d65f03c0 	ret

0000000000005700 <fwp_rc_free_arr>:
    5700:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5704:	9114c063 	add	x3, x3, #0x530
    5708:	f949d861 	ldr	x1, [x3, #5040]
    570c:	f949ec62 	ldr	x2, [x3, #5080]
    5710:	cb010001 	sub	x1, x0, x1
    5714:	eb02403f 	cmp	x1, x2, lsl #16
    5718:	54000342 	b.cs	5780 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    571c:	d350fc22 	lsr	x2, x1, #16
    5720:	f949fc65 	ldr	x5, [x3, #5112]
    5724:	8b020842 	add	x2, x2, x2, lsl #2
    5728:	d37df042 	lsl	x2, x2, #3
    572c:	8b0200a4 	add	x4, x5, x2
    5730:	f9401083 	ldr	x3, [x4, #32]
    5734:	b4000263 	cbz	x3, 5780 <fwp_rc_free_arr+0x80>
    5738:	386268a2 	ldrb	w2, [x5, x2]
    573c:	7100085f 	cmp	w2, #0x2
    5740:	540001c0 	b.eq	5778 <fwp_rc_free_arr+0x78>  // b.none
    5744:	7100045f 	cmp	w2, #0x1
    5748:	540001c1 	b.ne	5780 <fwp_rc_free_arr+0x80>  // b.any
    574c:	29430885 	ldp	w5, w2, [x4, #24]
    5750:	92403c21 	and	x1, x1, #0xffff
    5754:	9b057c21 	mul	x1, x1, x5
    5758:	d360fc21 	lsr	x1, x1, #32
    575c:	eb02003f 	cmp	x1, x2
    5760:	54000102 	b.cs	5780 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5764:	8b010063 	add	x3, x3, x1
    5768:	39400061 	ldrb	w1, [x3]
    576c:	7100043f 	cmp	w1, #0x1
    5770:	54000081 	b.ne	5780 <fwp_rc_free_arr+0x80>  // b.any
    5774:	17fffa83 	b	4180 <fwp_mem_free>
    5778:	72003c3f 	tst	w1, #0xffff
    577c:	54ffff60 	b.eq	5768 <fwp_rc_free_arr+0x68>  // b.none
    5780:	d65f03c0 	ret

0000000000005784 <fwp_rc_dup>:
    5784:	90000162 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    5788:	9114c042 	add	x2, x2, #0x530
    578c:	f949d841 	ldr	x1, [x2, #5040]
    5790:	f949ec43 	ldr	x3, [x2, #5080]
    5794:	cb010001 	sub	x1, x0, x1
    5798:	eb03403f 	cmp	x1, x3, lsl #16
    579c:	54000342 	b.cs	5804 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57a0:	d350fc20 	lsr	x0, x1, #16
    57a4:	f949fc44 	ldr	x4, [x2, #5112]
    57a8:	8b000800 	add	x0, x0, x0, lsl #2
    57ac:	d37df002 	lsl	x2, x0, #3
    57b0:	8b020083 	add	x3, x4, x2
    57b4:	f9401060 	ldr	x0, [x3, #32]
    57b8:	b4000260 	cbz	x0, 5804 <fwp_rc_dup+0x80>
    57bc:	38626882 	ldrb	w2, [x4, x2]
    57c0:	7100085f 	cmp	w2, #0x2
    57c4:	54000220 	b.eq	5808 <fwp_rc_dup+0x84>  // b.none
    57c8:	7100045f 	cmp	w2, #0x1
    57cc:	540001c1 	b.ne	5804 <fwp_rc_dup+0x80>  // b.any
    57d0:	29430864 	ldp	w4, w2, [x3, #24]
    57d4:	92403c21 	and	x1, x1, #0xffff
    57d8:	9b047c21 	mul	x1, x1, x4
    57dc:	d360fc21 	lsr	x1, x1, #32
    57e0:	eb02003f 	cmp	x1, x2
    57e4:	54000102 	b.cs	5804 <fwp_rc_dup+0x80>  // b.hs, b.nlast
    57e8:	8b010000 	add	x0, x0, x1
    57ec:	39400001 	ldrb	w1, [x0]
    57f0:	340000a1 	cbz	w1, 5804 <fwp_rc_dup+0x80>
    57f4:	7103f43f 	cmp	w1, #0xfd
    57f8:	540000e8 	b.hi	5814 <fwp_rc_dup+0x90>  // b.pmore
    57fc:	11000421 	add	w1, w1, #0x1
    5800:	39000001 	strb	w1, [x0]
    5804:	d65f03c0 	ret
    5808:	72003c3f 	tst	w1, #0xffff
    580c:	54ffff00 	b.eq	57ec <fwp_rc_dup+0x68>  // b.none
    5810:	d65f03c0 	ret
    5814:	17fffad4 	b	4364 <fwp_rc_wide_dup>
    5818:	d503201f 	nop
    581c:	d503201f 	nop

0000000000005820 <fwp_owned_entry173>:
    5820:	d10103ff 	sub	sp, sp, #0x40
    5824:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    5828:	f947f442 	ldr	x2, [x2, #4072]
    582c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5830:	910083fd 	add	x29, sp, #0x20
    5834:	a90353f3 	stp	x19, x20, [sp, #48]
    5838:	f9400043 	ldr	x3, [x2]
    583c:	f9000fe3 	str	x3, [sp, #24]
    5840:	d2800003 	mov	x3, #0x0                   	// #0
    5844:	a9400c01 	ldp	x1, x3, [x0]
    5848:	f9400802 	ldr	x2, [x0, #16]
    584c:	ab020022 	adds	x2, x1, x2
    5850:	540006e6 	b.vs	592c <fwp_owned_entry173+0x10c>
    5854:	910023e1 	add	x1, sp, #0x8
    5858:	52800000 	mov	w0, #0x0                   	// #0
    585c:	a9008be3 	stp	x3, x2, [sp, #8]
    5860:	97fffd49 	bl	4d84 <fwp_data.part.0.constprop.0>
    5864:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    5868:	9114c063 	add	x3, x3, #0x530
    586c:	aa0003f3 	mov	x19, x0
    5870:	f949d861 	ldr	x1, [x3, #5040]
    5874:	f949ec60 	ldr	x0, [x3, #5080]
    5878:	cb010261 	sub	x1, x19, x1
    587c:	eb00403f 	cmp	x1, x0, lsl #16
    5880:	54000322 	b.cs	58e4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    5884:	d350fc22 	lsr	x2, x1, #16
    5888:	f949fc63 	ldr	x3, [x3, #5112]
    588c:	8b020842 	add	x2, x2, x2, lsl #2
    5890:	d37df042 	lsl	x2, x2, #3
    5894:	8b020060 	add	x0, x3, x2
    5898:	f9401014 	ldr	x20, [x0, #32]
    589c:	b4000254 	cbz	x20, 58e4 <fwp_owned_entry173+0xc4>
    58a0:	38626862 	ldrb	w2, [x3, x2]
    58a4:	7100085f 	cmp	w2, #0x2
    58a8:	54000360 	b.eq	5914 <fwp_owned_entry173+0xf4>  // b.none
    58ac:	7100045f 	cmp	w2, #0x1
    58b0:	540001a1 	b.ne	58e4 <fwp_owned_entry173+0xc4>  // b.any
    58b4:	29430002 	ldp	w2, w0, [x0, #24]
    58b8:	92403c21 	and	x1, x1, #0xffff
    58bc:	9b027c21 	mul	x1, x1, x2
    58c0:	d360fc21 	lsr	x1, x1, #32
    58c4:	eb00003f 	cmp	x1, x0
    58c8:	540000e2 	b.cs	58e4 <fwp_owned_entry173+0xc4>  // b.hs, b.nlast
    58cc:	8b010294 	add	x20, x20, x1
    58d0:	39400280 	ldrb	w0, [x20]
    58d4:	7103fc1f 	cmp	w0, #0xff
    58d8:	54000240 	b.eq	5920 <fwp_owned_entry173+0x100>  // b.none
    58dc:	52800020 	mov	w0, #0x1                   	// #1
    58e0:	39000280 	strb	w0, [x20]
    58e4:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    58e8:	f947f400 	ldr	x0, [x0, #4072]
    58ec:	f9400fe2 	ldr	x2, [sp, #24]
    58f0:	f9400001 	ldr	x1, [x0]
    58f4:	eb010042 	subs	x2, x2, x1
    58f8:	d2800001 	mov	x1, #0x0                   	// #0
    58fc:	540001a1 	b.ne	5930 <fwp_owned_entry173+0x110>  // b.any
    5900:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5904:	aa1303e0 	mov	x0, x19
    5908:	a94353f3 	ldp	x19, x20, [sp, #48]
    590c:	910103ff 	add	sp, sp, #0x40
    5910:	d65f03c0 	ret
    5914:	72003c3f 	tst	w1, #0xffff
    5918:	54fffe61 	b.ne	58e4 <fwp_owned_entry173+0xc4>  // b.any
    591c:	17ffffed 	b	58d0 <fwp_owned_entry173+0xb0>
    5920:	aa1403e0 	mov	x0, x20
    5924:	97fff97b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5928:	17ffffed 	b	58dc <fwp_owned_entry173+0xbc>
    592c:	97fff455 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5930:	97fff3d4 	bl	2880 <__stack_chk_fail@plt>

0000000000005934 <e173>:
    5934:	d10103ff 	sub	sp, sp, #0x40
    5938:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xc98>
    593c:	f947f442 	ldr	x2, [x2, #4072]
    5940:	a9027bfd 	stp	x29, x30, [sp, #32]
    5944:	910083fd 	add	x29, sp, #0x20
    5948:	a90353f3 	stp	x19, x20, [sp, #48]
    594c:	f9400043 	ldr	x3, [x2]
    5950:	f9000fe3 	str	x3, [sp, #24]
    5954:	d2800003 	mov	x3, #0x0                   	// #0
    5958:	a9400c01 	ldp	x1, x3, [x0]
    595c:	f9400802 	ldr	x2, [x0, #16]
    5960:	ab020022 	adds	x2, x1, x2
    5964:	54000726 	b.vs	5a48 <e173+0x114>
    5968:	910023e1 	add	x1, sp, #0x8
    596c:	52800000 	mov	w0, #0x0                   	// #0
    5970:	a9008be3 	stp	x3, x2, [sp, #8]
    5974:	97fffd04 	bl	4d84 <fwp_data.part.0.constprop.0>
    5978:	90000163 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    597c:	9114c063 	add	x3, x3, #0x530
    5980:	aa0003f3 	mov	x19, x0
    5984:	f949d861 	ldr	x1, [x3, #5040]
    5988:	f949ec60 	ldr	x0, [x3, #5080]
    598c:	cb010261 	sub	x1, x19, x1
    5990:	eb00403f 	cmp	x1, x0, lsl #16
    5994:	54000322 	b.cs	59f8 <e173+0xc4>  // b.hs, b.nlast
    5998:	d350fc22 	lsr	x2, x1, #16
    599c:	f949fc63 	ldr	x3, [x3, #5112]
    59a0:	8b020842 	add	x2, x2, x2, lsl #2
    59a4:	d37df042 	lsl	x2, x2, #3
    59a8:	8b020060 	add	x0, x3, x2
    59ac:	f9401014 	ldr	x20, [x0, #32]
    59b0:	b4000254 	cbz	x20, 59f8 <e173+0xc4>
    59b4:	38626862 	ldrb	w2, [x3, x2]
    59b8:	7100085f 	cmp	w2, #0x2
    59bc:	540003a0 	b.eq	5a30 <e173+0xfc>  // b.none
    59c0:	7100045f 	cmp	w2, #0x1
    59c4:	540001a1 	b.ne	59f8 <e173+0xc4>  // b.any
    59c8:	29430002 	ldp	w2, w0, [x0, #24]
    59cc:	92403c21 	and	x1, x1, #0xffff
    59d0:	9b027c21 	mul	x1, x1, x2
    59d4:	d360fc21 	lsr	x1, x1, #32
    59d8:	eb00003f 	cmp	x1, x0
    59dc:	540000e2 	b.cs	59f8 <e173+0xc4>  // b.hs, b.nlast
    59e0:	8b010294 	add	x20, x20, x1
    59e4:	39400280 	ldrb	w0, [x20]
    59e8:	7103fc1f 	cmp	w0, #0xff
    59ec:	54000280 	b.eq	5a3c <e173+0x108>  // b.none
    59f0:	52800020 	mov	w0, #0x1                   	// #1
    59f4:	39000280 	strb	w0, [x20]
    59f8:	aa1303e0 	mov	x0, x19
    59fc:	97ffff1d 	bl	5670 <fwp_rc_share>
    5a00:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    5a04:	f947f400 	ldr	x0, [x0, #4072]
    5a08:	f9400fe2 	ldr	x2, [sp, #24]
    5a0c:	f9400001 	ldr	x1, [x0]
    5a10:	eb010042 	subs	x2, x2, x1
    5a14:	d2800001 	mov	x1, #0x0                   	// #0
    5a18:	540001a1 	b.ne	5a4c <e173+0x118>  // b.any
    5a1c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    5a20:	aa1303e0 	mov	x0, x19
    5a24:	a94353f3 	ldp	x19, x20, [sp, #48]
    5a28:	910103ff 	add	sp, sp, #0x40
    5a2c:	d65f03c0 	ret
    5a30:	72003c3f 	tst	w1, #0xffff
    5a34:	54fffe21 	b.ne	59f8 <e173+0xc4>  // b.any
    5a38:	17ffffeb 	b	59e4 <e173+0xb0>
    5a3c:	aa1403e0 	mov	x0, x20
    5a40:	97fff934 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5a44:	17ffffeb 	b	59f0 <e173+0xbc>
    5a48:	97fff40e 	bl	2a80 <fwp_trap_overflow.constprop.0>
    5a4c:	97fff38d 	bl	2880 <__stack_chk_fail@plt>

0000000000005a50 <fwp_drop0>:
    5a50:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5a54:	910003fd 	mov	x29, sp
    5a58:	a90153f3 	stp	x19, x20, [sp, #16]
    5a5c:	f90013f5 	str	x21, [sp, #32]
    5a60:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5a64:	9114c2b4 	add	x20, x21, #0x530
    5a68:	f949da81 	ldr	x1, [x20, #5040]
    5a6c:	f949ee82 	ldr	x2, [x20, #5080]
    5a70:	cb010001 	sub	x1, x0, x1
    5a74:	eb02403f 	cmp	x1, x2, lsl #16
    5a78:	54000382 	b.cs	5ae8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5a7c:	d350fc22 	lsr	x2, x1, #16
    5a80:	f949fe84 	ldr	x4, [x20, #5112]
    5a84:	8b020842 	add	x2, x2, x2, lsl #2
    5a88:	d37df042 	lsl	x2, x2, #3
    5a8c:	8b020083 	add	x3, x4, x2
    5a90:	f9401073 	ldr	x19, [x3, #32]
    5a94:	b40002b3 	cbz	x19, 5ae8 <fwp_drop0+0x98>
    5a98:	38626882 	ldrb	w2, [x4, x2]
    5a9c:	7100085f 	cmp	w2, #0x2
    5aa0:	540002c0 	b.eq	5af8 <fwp_drop0+0xa8>  // b.none
    5aa4:	7100045f 	cmp	w2, #0x1
    5aa8:	54000201 	b.ne	5ae8 <fwp_drop0+0x98>  // b.any
    5aac:	29430864 	ldp	w4, w2, [x3, #24]
    5ab0:	92403c21 	and	x1, x1, #0xffff
    5ab4:	9b047c21 	mul	x1, x1, x4
    5ab8:	d360fc21 	lsr	x1, x1, #32
    5abc:	eb02003f 	cmp	x1, x2
    5ac0:	54000142 	b.cs	5ae8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5ac4:	8b010273 	add	x19, x19, x1
    5ac8:	39400261 	ldrb	w1, [x19]
    5acc:	340000e1 	cbz	w1, 5ae8 <fwp_drop0+0x98>
    5ad0:	7100043f 	cmp	w1, #0x1
    5ad4:	540001e0 	b.eq	5b10 <fwp_drop0+0xc0>  // b.none
    5ad8:	7103fc3f 	cmp	w1, #0xff
    5adc:	540002e0 	b.eq	5b38 <fwp_drop0+0xe8>  // b.none
    5ae0:	51000421 	sub	w1, w1, #0x1
    5ae4:	39000261 	strb	w1, [x19]
    5ae8:	a94153f3 	ldp	x19, x20, [sp, #16]
    5aec:	f94013f5 	ldr	x21, [sp, #32]
    5af0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5af4:	d65f03c0 	ret
    5af8:	72003c3f 	tst	w1, #0xffff
    5afc:	54fffe60 	b.eq	5ac8 <fwp_drop0+0x78>  // b.none
    5b00:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b04:	f94013f5 	ldr	x21, [sp, #32]
    5b08:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5b0c:	d65f03c0 	ret
    5b10:	f9400813 	ldr	x19, [x0, #16]
    5b14:	97fffefb 	bl	5700 <fwp_rc_free_arr>
    5b18:	9114c2a0 	add	x0, x21, #0x530
    5b1c:	f949d801 	ldr	x1, [x0, #5040]
    5b20:	f949ec00 	ldr	x0, [x0, #5080]
    5b24:	cb010261 	sub	x1, x19, x1
    5b28:	eb00403f 	cmp	x1, x0, lsl #16
    5b2c:	54fffde2 	b.cs	5ae8 <fwp_drop0+0x98>  // b.hs, b.nlast
    5b30:	aa1303e0 	mov	x0, x19
    5b34:	17ffffd2 	b	5a7c <fwp_drop0+0x2c>
    5b38:	ca534660 	eor	x0, x19, x19, lsr #17
    5b3c:	9114c2b5 	add	x21, x21, #0x530
    5b40:	ca402400 	eor	x0, x0, x0, lsr #9
    5b44:	92401c00 	and	x0, x0, #0xff
    5b48:	910a2402 	add	x2, x0, #0x289
    5b4c:	8b000ea0 	add	x0, x21, x0, lsl #3
    5b50:	8b020ea2 	add	x2, x21, x2, lsl #3
    5b54:	f94a2400 	ldr	x0, [x0, #5192]
    5b58:	b50000a0 	cbnz	x0, 5b6c <fwp_drop0+0x11c>
    5b5c:	14000013 	b	5ba8 <fwp_drop0+0x158>
    5b60:	91004002 	add	x2, x0, #0x10
    5b64:	f9400800 	ldr	x0, [x0, #16]
    5b68:	b4000200 	cbz	x0, 5ba8 <fwp_drop0+0x158>
    5b6c:	f9400001 	ldr	x1, [x0]
    5b70:	eb13003f 	cmp	x1, x19
    5b74:	54ffff61 	b.ne	5b60 <fwp_drop0+0x110>  // b.any
    5b78:	f9400041 	ldr	x1, [x2]
    5b7c:	f9400420 	ldr	x0, [x1, #8]
    5b80:	d1000400 	sub	x0, x0, #0x1
    5b84:	f9000420 	str	x0, [x1, #8]
    5b88:	f103f81f 	cmp	x0, #0xfe
    5b8c:	54fffae1 	b.ne	5ae8 <fwp_drop0+0x98>  // b.any
    5b90:	39400260 	ldrb	w0, [x19]
    5b94:	7103fc1f 	cmp	w0, #0xff
    5b98:	540000e0 	b.eq	5bb4 <fwp_drop0+0x164>  // b.none
    5b9c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5ba0:	39000260 	strb	w0, [x19]
    5ba4:	17ffffd1 	b	5ae8 <fwp_drop0+0x98>
    5ba8:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5bac:	91168000 	add	x0, x0, #0x5a0
    5bb0:	97fff8b8 	bl	3e90 <fwp_trap>
    5bb4:	aa1303e0 	mov	x0, x19
    5bb8:	97fff8d6 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5bbc:	17fffff8 	b	5b9c <fwp_drop0+0x14c>

0000000000005bc0 <fwp_drop1>:
    5bc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5bc4:	910003fd 	mov	x29, sp
    5bc8:	a90153f3 	stp	x19, x20, [sp, #16]
    5bcc:	f90013f5 	str	x21, [sp, #32]
    5bd0:	90000175 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    5bd4:	9114c2b4 	add	x20, x21, #0x530
    5bd8:	f949da81 	ldr	x1, [x20, #5040]
    5bdc:	f949ee82 	ldr	x2, [x20, #5080]
    5be0:	cb010001 	sub	x1, x0, x1
    5be4:	eb02403f 	cmp	x1, x2, lsl #16
    5be8:	54000382 	b.cs	5c58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5bec:	d350fc22 	lsr	x2, x1, #16
    5bf0:	f949fe84 	ldr	x4, [x20, #5112]
    5bf4:	8b020842 	add	x2, x2, x2, lsl #2
    5bf8:	d37df042 	lsl	x2, x2, #3
    5bfc:	8b020083 	add	x3, x4, x2
    5c00:	f9401073 	ldr	x19, [x3, #32]
    5c04:	b40002b3 	cbz	x19, 5c58 <fwp_drop1+0x98>
    5c08:	38626882 	ldrb	w2, [x4, x2]
    5c0c:	7100085f 	cmp	w2, #0x2
    5c10:	540002c0 	b.eq	5c68 <fwp_drop1+0xa8>  // b.none
    5c14:	7100045f 	cmp	w2, #0x1
    5c18:	54000201 	b.ne	5c58 <fwp_drop1+0x98>  // b.any
    5c1c:	29430864 	ldp	w4, w2, [x3, #24]
    5c20:	92403c21 	and	x1, x1, #0xffff
    5c24:	9b047c21 	mul	x1, x1, x4
    5c28:	d360fc21 	lsr	x1, x1, #32
    5c2c:	eb02003f 	cmp	x1, x2
    5c30:	54000142 	b.cs	5c58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5c34:	8b010273 	add	x19, x19, x1
    5c38:	39400261 	ldrb	w1, [x19]
    5c3c:	340000e1 	cbz	w1, 5c58 <fwp_drop1+0x98>
    5c40:	7100043f 	cmp	w1, #0x1
    5c44:	540001e0 	b.eq	5c80 <fwp_drop1+0xc0>  // b.none
    5c48:	7103fc3f 	cmp	w1, #0xff
    5c4c:	540002e0 	b.eq	5ca8 <fwp_drop1+0xe8>  // b.none
    5c50:	51000421 	sub	w1, w1, #0x1
    5c54:	39000261 	strb	w1, [x19]
    5c58:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c5c:	f94013f5 	ldr	x21, [sp, #32]
    5c60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c64:	d65f03c0 	ret
    5c68:	72003c3f 	tst	w1, #0xffff
    5c6c:	54fffe60 	b.eq	5c38 <fwp_drop1+0x78>  // b.none
    5c70:	a94153f3 	ldp	x19, x20, [sp, #16]
    5c74:	f94013f5 	ldr	x21, [sp, #32]
    5c78:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5c7c:	d65f03c0 	ret
    5c80:	f9400813 	ldr	x19, [x0, #16]
    5c84:	97fffe9f 	bl	5700 <fwp_rc_free_arr>
    5c88:	9114c2a0 	add	x0, x21, #0x530
    5c8c:	f949d801 	ldr	x1, [x0, #5040]
    5c90:	f949ec00 	ldr	x0, [x0, #5080]
    5c94:	cb010261 	sub	x1, x19, x1
    5c98:	eb00403f 	cmp	x1, x0, lsl #16
    5c9c:	54fffde2 	b.cs	5c58 <fwp_drop1+0x98>  // b.hs, b.nlast
    5ca0:	aa1303e0 	mov	x0, x19
    5ca4:	17ffffd2 	b	5bec <fwp_drop1+0x2c>
    5ca8:	ca534660 	eor	x0, x19, x19, lsr #17
    5cac:	9114c2b5 	add	x21, x21, #0x530
    5cb0:	ca402400 	eor	x0, x0, x0, lsr #9
    5cb4:	92401c00 	and	x0, x0, #0xff
    5cb8:	910a2402 	add	x2, x0, #0x289
    5cbc:	8b000ea0 	add	x0, x21, x0, lsl #3
    5cc0:	8b020ea2 	add	x2, x21, x2, lsl #3
    5cc4:	f94a2400 	ldr	x0, [x0, #5192]
    5cc8:	b50000a0 	cbnz	x0, 5cdc <fwp_drop1+0x11c>
    5ccc:	14000013 	b	5d18 <fwp_drop1+0x158>
    5cd0:	91004002 	add	x2, x0, #0x10
    5cd4:	f9400800 	ldr	x0, [x0, #16]
    5cd8:	b4000200 	cbz	x0, 5d18 <fwp_drop1+0x158>
    5cdc:	f9400001 	ldr	x1, [x0]
    5ce0:	eb13003f 	cmp	x1, x19
    5ce4:	54ffff61 	b.ne	5cd0 <fwp_drop1+0x110>  // b.any
    5ce8:	f9400041 	ldr	x1, [x2]
    5cec:	f9400420 	ldr	x0, [x1, #8]
    5cf0:	d1000400 	sub	x0, x0, #0x1
    5cf4:	f9000420 	str	x0, [x1, #8]
    5cf8:	f103f81f 	cmp	x0, #0xfe
    5cfc:	54fffae1 	b.ne	5c58 <fwp_drop1+0x98>  // b.any
    5d00:	39400260 	ldrb	w0, [x19]
    5d04:	7103fc1f 	cmp	w0, #0xff
    5d08:	540000e0 	b.eq	5d24 <fwp_drop1+0x164>  // b.none
    5d0c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5d10:	39000260 	strb	w0, [x19]
    5d14:	17ffffd1 	b	5c58 <fwp_drop1+0x98>
    5d18:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5d1c:	91168000 	add	x0, x0, #0x5a0
    5d20:	97fff85c 	bl	3e90 <fwp_trap>
    5d24:	aa1303e0 	mov	x0, x19
    5d28:	97fff87a 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5d2c:	17fffff8 	b	5d0c <fwp_drop1+0x14c>

0000000000005d30 <fwp_closure_drop>:
    5d30:	90000165 	adrp	x5, 31000 <fwp_root_context+0xcb0>
    5d34:	9114c0a4 	add	x4, x5, #0x530
    5d38:	aa0003e1 	mov	x1, x0
    5d3c:	f949d882 	ldr	x2, [x4, #5040]
    5d40:	f949ec80 	ldr	x0, [x4, #5080]
    5d44:	cb020022 	sub	x2, x1, x2
    5d48:	eb00405f 	cmp	x2, x0, lsl #16
    5d4c:	54000662 	b.cs	5e18 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    5d50:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    5d54:	d350fc43 	lsr	x3, x2, #16
    5d58:	910003fd 	mov	x29, sp
    5d5c:	8b030863 	add	x3, x3, x3, lsl #2
    5d60:	f949fc84 	ldr	x4, [x4, #5112]
    5d64:	d37df063 	lsl	x3, x3, #3
    5d68:	f9000bf3 	str	x19, [sp, #16]
    5d6c:	8b030080 	add	x0, x4, x3
    5d70:	f9401013 	ldr	x19, [x0, #32]
    5d74:	b40002b3 	cbz	x19, 5dc8 <fwp_closure_drop+0x98>
    5d78:	38636883 	ldrb	w3, [x4, x3]
    5d7c:	7100087f 	cmp	w3, #0x2
    5d80:	54000420 	b.eq	5e04 <fwp_closure_drop+0xd4>  // b.none
    5d84:	7100047f 	cmp	w3, #0x1
    5d88:	54000201 	b.ne	5dc8 <fwp_closure_drop+0x98>  // b.any
    5d8c:	29430003 	ldp	w3, w0, [x0, #24]
    5d90:	92403c42 	and	x2, x2, #0xffff
    5d94:	9b037c42 	mul	x2, x2, x3
    5d98:	d360fc42 	lsr	x2, x2, #32
    5d9c:	eb00005f 	cmp	x2, x0
    5da0:	54000142 	b.cs	5dc8 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    5da4:	8b020273 	add	x19, x19, x2
    5da8:	39400260 	ldrb	w0, [x19]
    5dac:	340000e0 	cbz	w0, 5dc8 <fwp_closure_drop+0x98>
    5db0:	7100041f 	cmp	w0, #0x1
    5db4:	54000100 	b.eq	5dd4 <fwp_closure_drop+0xa4>  // b.none
    5db8:	7103fc1f 	cmp	w0, #0xff
    5dbc:	54000300 	b.eq	5e1c <fwp_closure_drop+0xec>  // b.none
    5dc0:	51000400 	sub	w0, w0, #0x1
    5dc4:	39000260 	strb	w0, [x19]
    5dc8:	f9400bf3 	ldr	x19, [sp, #16]
    5dcc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5dd0:	d65f03c0 	ret
    5dd4:	d53bd040 	mrs	x0, tpidr_el0
    5dd8:	91400000 	add	x0, x0, #0x0, lsl #12
    5ddc:	91004000 	add	x0, x0, #0x10
    5de0:	f9400000 	ldr	x0, [x0]
    5de4:	b4000080 	cbz	x0, 5df4 <fwp_closure_drop+0xc4>
    5de8:	f9400bf3 	ldr	x19, [sp, #16]
    5dec:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5df0:	17fff9a4 	b	4480 <fwp_closure_drop_push>
    5df4:	f9400bf3 	ldr	x19, [sp, #16]
    5df8:	aa0103e0 	mov	x0, x1
    5dfc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e00:	17fff9e5 	b	4594 <fwp_closure_drop.part.0>
    5e04:	72003c5f 	tst	w2, #0xffff
    5e08:	54fffd00 	b.eq	5da8 <fwp_closure_drop+0x78>  // b.none
    5e0c:	f9400bf3 	ldr	x19, [sp, #16]
    5e10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    5e14:	d65f03c0 	ret
    5e18:	d65f03c0 	ret
    5e1c:	ca534660 	eor	x0, x19, x19, lsr #17
    5e20:	9114c0a5 	add	x5, x5, #0x530
    5e24:	ca402400 	eor	x0, x0, x0, lsr #9
    5e28:	92401c00 	and	x0, x0, #0xff
    5e2c:	910a2402 	add	x2, x0, #0x289
    5e30:	8b000ca0 	add	x0, x5, x0, lsl #3
    5e34:	8b020ca2 	add	x2, x5, x2, lsl #3
    5e38:	f94a2400 	ldr	x0, [x0, #5192]
    5e3c:	b50000a0 	cbnz	x0, 5e50 <fwp_closure_drop+0x120>
    5e40:	14000013 	b	5e8c <fwp_closure_drop+0x15c>
    5e44:	91004002 	add	x2, x0, #0x10
    5e48:	f9400800 	ldr	x0, [x0, #16]
    5e4c:	b4000200 	cbz	x0, 5e8c <fwp_closure_drop+0x15c>
    5e50:	f9400001 	ldr	x1, [x0]
    5e54:	eb13003f 	cmp	x1, x19
    5e58:	54ffff61 	b.ne	5e44 <fwp_closure_drop+0x114>  // b.any
    5e5c:	f9400041 	ldr	x1, [x2]
    5e60:	f9400420 	ldr	x0, [x1, #8]
    5e64:	d1000400 	sub	x0, x0, #0x1
    5e68:	f9000420 	str	x0, [x1, #8]
    5e6c:	f103f81f 	cmp	x0, #0xfe
    5e70:	54fffac1 	b.ne	5dc8 <fwp_closure_drop+0x98>  // b.any
    5e74:	39400260 	ldrb	w0, [x19]
    5e78:	7103fc1f 	cmp	w0, #0xff
    5e7c:	540000e0 	b.eq	5e98 <fwp_closure_drop+0x168>  // b.none
    5e80:	12800020 	mov	w0, #0xfffffffe            	// #-2
    5e84:	39000260 	strb	w0, [x19]
    5e88:	17ffffd0 	b	5dc8 <fwp_closure_drop+0x98>
    5e8c:	90000020 	adrp	x0, 9000 <__divti3+0x2c0>
    5e90:	91168000 	add	x0, x0, #0x5a0
    5e94:	97fff7ff 	bl	3e90 <fwp_trap>
    5e98:	aa1303e0 	mov	x0, x19
    5e9c:	97fff81d 	bl	3f10 <fwp_rc_forget_slot.part.0>
    5ea0:	17fffff8 	b	5e80 <fwp_closure_drop+0x150>

0000000000005ea4 <fwp_owned_tape_release>:
    5ea4:	b4000920 	cbz	x0, 5fc8 <fwp_owned_tape_release+0x124>
    5ea8:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    5eac:	910003fd 	mov	x29, sp
    5eb0:	a90153f3 	stp	x19, x20, [sp, #16]
    5eb4:	aa0003f3 	mov	x19, x0
    5eb8:	f9400000 	ldr	x0, [x0]
    5ebc:	b4000060 	cbz	x0, 5ec8 <fwp_owned_tape_release+0x24>
    5ec0:	f9400661 	ldr	x1, [x19, #8]
    5ec4:	f9000401 	str	x1, [x0, #8]
    5ec8:	f9400661 	ldr	x1, [x19, #8]
    5ecc:	b4000041 	cbz	x1, 5ed4 <fwp_owned_tape_release+0x30>
    5ed0:	f9000020 	str	x0, [x1]
    5ed4:	f9400a60 	ldr	x0, [x19, #16]
    5ed8:	f9403401 	ldr	x1, [x0, #104]
    5edc:	b40005a1 	cbz	x1, 5f90 <fwp_owned_tape_release+0xec>
    5ee0:	a9450a60 	ldp	x0, x2, [x19, #80]
    5ee4:	eb00005f 	cmp	x2, x0
    5ee8:	540002cd 	b.le	5f40 <fwp_owned_tape_release+0x9c>
    5eec:	d2800014 	mov	x20, #0x0                   	// #0
    5ef0:	f90013f5 	str	x21, [sp, #32]
    5ef4:	d2800015 	mov	x21, #0x0                   	// #0
    5ef8:	f9402260 	ldr	x0, [x19, #64]
    5efc:	910006b5 	add	x21, x21, #0x1
    5f00:	f8746800 	ldr	x0, [x0, x20]
    5f04:	d63f0020 	blr	x1
    5f08:	f9402260 	ldr	x0, [x19, #64]
    5f0c:	f9400a61 	ldr	x1, [x19, #16]
    5f10:	8b140000 	add	x0, x0, x20
    5f14:	91004294 	add	x20, x20, #0x10
    5f18:	f9400400 	ldr	x0, [x0, #8]
    5f1c:	f9403421 	ldr	x1, [x1, #104]
    5f20:	d63f0020 	blr	x1
    5f24:	a9450261 	ldp	x1, x0, [x19, #80]
    5f28:	cb010000 	sub	x0, x0, x1
    5f2c:	eb15001f 	cmp	x0, x21
    5f30:	f9400a60 	ldr	x0, [x19, #16]
    5f34:	f9403401 	ldr	x1, [x0, #104]
    5f38:	54fffe0c 	b.gt	5ef8 <fwp_owned_tape_release+0x54>
    5f3c:	f94013f5 	ldr	x21, [sp, #32]
    5f40:	f9403663 	ldr	x3, [x19, #104]
    5f44:	f9401262 	ldr	x2, [x19, #32]
    5f48:	f100007f 	cmp	x3, #0x0
    5f4c:	540001ed 	b.le	5f88 <fwp_owned_tape_release+0xe4>
    5f50:	d2800014 	mov	x20, #0x0                   	// #0
    5f54:	d503201f 	nop
    5f58:	f9402660 	ldr	x0, [x19, #72]
    5f5c:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    5f60:	eb02001f 	cmp	x0, x2
    5f64:	540000c0 	b.eq	5f7c <fwp_owned_tape_release+0xd8>  // b.none
    5f68:	d63f0020 	blr	x1
    5f6c:	f9400a60 	ldr	x0, [x19, #16]
    5f70:	f9401262 	ldr	x2, [x19, #32]
    5f74:	f9403663 	ldr	x3, [x19, #104]
    5f78:	f9403401 	ldr	x1, [x0, #104]
    5f7c:	91000694 	add	x20, x20, #0x1
    5f80:	eb14007f 	cmp	x3, x20
    5f84:	54fffeac 	b.gt	5f58 <fwp_owned_tape_release+0xb4>
    5f88:	aa0203e0 	mov	x0, x2
    5f8c:	d63f0020 	blr	x1
    5f90:	f9401660 	ldr	x0, [x19, #40]
    5f94:	97ffff67 	bl	5d30 <fwp_closure_drop>
    5f98:	f9401a60 	ldr	x0, [x19, #48]
    5f9c:	97ffff65 	bl	5d30 <fwp_closure_drop>
    5fa0:	f9401e60 	ldr	x0, [x19, #56]
    5fa4:	97ffff63 	bl	5d30 <fwp_closure_drop>
    5fa8:	f9402260 	ldr	x0, [x19, #64]
    5fac:	97fff875 	bl	4180 <fwp_mem_free>
    5fb0:	f9402660 	ldr	x0, [x19, #72]
    5fb4:	97fff873 	bl	4180 <fwp_mem_free>
    5fb8:	aa1303e0 	mov	x0, x19
    5fbc:	a94153f3 	ldp	x19, x20, [sp, #16]
    5fc0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    5fc4:	17fff86f 	b	4180 <fwp_mem_free>
    5fc8:	d65f03c0 	ret
    5fcc:	d503201f 	nop

0000000000005fd0 <fwp_tape_finish>:
    5fd0:	d10203ff 	sub	sp, sp, #0x80
    5fd4:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    5fd8:	f947f421 	ldr	x1, [x1, #4072]
    5fdc:	a9047bfd 	stp	x29, x30, [sp, #64]
    5fe0:	910103fd 	add	x29, sp, #0x40
    5fe4:	a90553f3 	stp	x19, x20, [sp, #80]
    5fe8:	a9065bf5 	stp	x21, x22, [sp, #96]
    5fec:	a90763f7 	stp	x23, x24, [sp, #112]
    5ff0:	f00000d8 	adrp	x24, 20000 <__data_start>
    5ff4:	9100c316 	add	x22, x24, #0x30
    5ff8:	f9400022 	ldr	x2, [x1]
    5ffc:	f9001fe2 	str	x2, [sp, #56]
    6000:	d2800002 	mov	x2, #0x0                   	// #0
    6004:	9100e2c0 	add	x0, x22, #0x38
    6008:	97fff4be 	bl	3300 <fwp_tape_buffers_dispose>
    600c:	f9003adf 	str	xzr, [x22, #112]
    6010:	f94042c0 	ldr	x0, [x22, #128]
    6014:	f100001f 	cmp	x0, #0x0
    6018:	5400030d 	b.le	6078 <fwp_tape_finish+0xa8>
    601c:	910003f7 	mov	x23, sp
    6020:	d2800015 	mov	x21, #0x0                   	// #0
    6024:	d2800014 	mov	x20, #0x0                   	// #0
    6028:	f94002d3 	ldr	x19, [x22]
    602c:	91000694 	add	x20, x20, #0x1
    6030:	8b150273 	add	x19, x19, x21
    6034:	9101a2b5 	add	x21, x21, #0x68
    6038:	aa1303e0 	mov	x0, x19
    603c:	97fff3d5 	bl	2f90 <fwp_tape_unlink_scope>
    6040:	aa1703e0 	mov	x0, x23
    6044:	f9401261 	ldr	x1, [x19, #32]
    6048:	f90003e1 	str	x1, [sp]
    604c:	f9401a62 	ldr	x2, [x19, #48]
    6050:	f9000be2 	str	x2, [sp, #16]
    6054:	f9402261 	ldr	x1, [x19, #64]
    6058:	f90013e1 	str	x1, [sp, #32]
    605c:	97fff4a9 	bl	3300 <fwp_tape_buffers_dispose>
    6060:	f9403260 	ldr	x0, [x19, #96]
    6064:	97ffff90 	bl	5ea4 <fwp_owned_tape_release>
    6068:	f900327f 	str	xzr, [x19, #96]
    606c:	f94042c0 	ldr	x0, [x22, #128]
    6070:	eb14001f 	cmp	x0, x20
    6074:	54fffdac 	b.gt	6028 <fwp_tape_finish+0x58>
    6078:	f9401b00 	ldr	x0, [x24, #48]
    607c:	9100c313 	add	x19, x24, #0x30
    6080:	97fff230 	bl	2940 <free@plt>
    6084:	f9001b1f 	str	xzr, [x24, #48]
    6088:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    608c:	f947f400 	ldr	x0, [x0, #4072]
    6090:	f900427f 	str	xzr, [x19, #128]
    6094:	a9097e7f 	stp	xzr, xzr, [x19, #144]
    6098:	f9401fe2 	ldr	x2, [sp, #56]
    609c:	f9400001 	ldr	x1, [x0]
    60a0:	eb010042 	subs	x2, x2, x1
    60a4:	d2800001 	mov	x1, #0x0                   	// #0
    60a8:	540000e1 	b.ne	60c4 <fwp_tape_finish+0xf4>  // b.any
    60ac:	a9447bfd 	ldp	x29, x30, [sp, #64]
    60b0:	a94553f3 	ldp	x19, x20, [sp, #80]
    60b4:	a9465bf5 	ldp	x21, x22, [sp, #96]
    60b8:	a94763f7 	ldp	x23, x24, [sp, #112]
    60bc:	910203ff 	add	sp, sp, #0x80
    60c0:	d65f03c0 	ret
    60c4:	97fff1ef 	bl	2880 <__stack_chk_fail@plt>
    60c8:	d503201f 	nop
    60cc:	d503201f 	nop

00000000000060d0 <fwp_tape_scope_release>:
    60d0:	d10243ff 	sub	sp, sp, #0x90
    60d4:	a9047bfd 	stp	x29, x30, [sp, #64]
    60d8:	910103fd 	add	x29, sp, #0x40
    60dc:	a90553f3 	stp	x19, x20, [sp, #80]
    60e0:	aa0003f4 	mov	x20, x0
    60e4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    60e8:	f947f400 	ldr	x0, [x0, #4072]
    60ec:	b9400285 	ldr	w5, [x20]
    60f0:	f9400001 	ldr	x1, [x0]
    60f4:	f9001fe1 	str	x1, [sp, #56]
    60f8:	d2800001 	mov	x1, #0x0                   	// #0
    60fc:	37f806c5 	tbnz	w5, #31, 61d4 <fwp_tape_scope_release+0x104>
    6100:	a90763f7 	stp	x23, x24, [sp, #112]
    6104:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6108:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    610c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6110:	d00000d3 	adrp	x19, 20000 <__data_start>
    6114:	910003f7 	mov	x23, sp
    6118:	9100c273 	add	x19, x19, #0x30
    611c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6120:	a9065bf5 	stp	x21, x22, [sp, #96]
    6124:	52800d16 	mov	w22, #0x68                  	// #104
    6128:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    612c:	f90043f9 	str	x25, [sp, #128]
    6130:	14000006 	b	6148 <fwp_tape_scope_release+0x78>
    6134:	97fff473 	bl	3300 <fwp_tape_buffers_dispose>
    6138:	aa1903e0 	mov	x0, x25
    613c:	97ffff5a 	bl	5ea4 <fwp_owned_tape_release>
    6140:	b9400285 	ldr	w5, [x20]
    6144:	37f80425 	tbnz	w5, #31, 61c8 <fwp_tape_scope_release+0xf8>
    6148:	f9400266 	ldr	x6, [x19]
    614c:	9b367ca5 	smull	x5, w5, w22
    6150:	8b0500c0 	add	x0, x6, x5
    6154:	97fff38f 	bl	2f90 <fwp_tape_unlink_scope>
    6158:	ad410001 	ldp	q1, q0, [x0, #32]
    615c:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    6160:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    6164:	f9400c03 	ldr	x3, [x0, #24]
    6168:	ad0003e1 	stp	q1, q0, [sp]
    616c:	b86568c1 	ldr	w1, [x6, x5]
    6170:	a9440804 	ldp	x4, x2, [x0, #64]
    6174:	b900041f 	str	wzr, [x0, #4]
    6178:	f9403019 	ldr	x25, [x0, #96]
    617c:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    6180:	f9000c1f 	str	xzr, [x0, #24]
    6184:	a9020fe4 	stp	x4, x3, [sp, #32]
    6188:	f9001be2 	str	x2, [sp, #48]
    618c:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6190:	f900301f 	str	xzr, [x0, #96]
    6194:	6b15003f 	cmp	w1, w21
    6198:	540000e8 	b.hi	61b4 <fwp_tape_scope_release+0xe4>  // b.pmore
    619c:	9343fca5 	asr	x5, x5, #3
    61a0:	f9404e60 	ldr	x0, [x19, #152]
    61a4:	9b187ca5 	mul	x5, x5, x24
    61a8:	eb0000bf 	cmp	x5, x0
    61ac:	5400004a 	b.ge	61b4 <fwp_tape_scope_release+0xe4>  // b.tcont
    61b0:	f9004e65 	str	x5, [x19, #152]
    61b4:	aa1703e0 	mov	x0, x23
    61b8:	b5fffbf9 	cbnz	x25, 6134 <fwp_tape_scope_release+0x64>
    61bc:	97fff6ed 	bl	3d70 <fwp_tape_buffers_release>
    61c0:	b9400285 	ldr	w5, [x20]
    61c4:	36fffc25 	tbz	w5, #31, 6148 <fwp_tape_scope_release+0x78>
    61c8:	a9465bf5 	ldp	x21, x22, [sp, #96]
    61cc:	a94763f7 	ldp	x23, x24, [sp, #112]
    61d0:	f94043f9 	ldr	x25, [sp, #128]
    61d4:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    61d8:	f947f400 	ldr	x0, [x0, #4072]
    61dc:	f9401fe2 	ldr	x2, [sp, #56]
    61e0:	f9400001 	ldr	x1, [x0]
    61e4:	eb010042 	subs	x2, x2, x1
    61e8:	d2800001 	mov	x1, #0x0                   	// #0
    61ec:	540000a1 	b.ne	6200 <fwp_tape_scope_release+0x130>  // b.any
    61f0:	a9447bfd 	ldp	x29, x30, [sp, #64]
    61f4:	a94553f3 	ldp	x19, x20, [sp, #80]
    61f8:	910243ff 	add	sp, sp, #0x90
    61fc:	d65f03c0 	ret
    6200:	a9065bf5 	stp	x21, x22, [sp, #96]
    6204:	a90763f7 	stp	x23, x24, [sp, #112]
    6208:	f90043f9 	str	x25, [sp, #128]
    620c:	97fff19d 	bl	2880 <__stack_chk_fail@plt>

0000000000006210 <fwp_drop4>:
    6210:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6214:	910003fd 	mov	x29, sp
    6218:	a9025bf5 	stp	x21, x22, [sp, #32]
    621c:	f0000156 	adrp	x22, 31000 <fwp_root_context+0xcb0>
    6220:	9114c2d5 	add	x21, x22, #0x530
    6224:	a90153f3 	stp	x19, x20, [sp, #16]
    6228:	aa0003f3 	mov	x19, x0
    622c:	f949daa1 	ldr	x1, [x21, #5040]
    6230:	f949eea0 	ldr	x0, [x21, #5080]
    6234:	cb010261 	sub	x1, x19, x1
    6238:	eb00403f 	cmp	x1, x0, lsl #16
    623c:	54000382 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6240:	d350fc22 	lsr	x2, x1, #16
    6244:	f949fea3 	ldr	x3, [x21, #5112]
    6248:	8b020842 	add	x2, x2, x2, lsl #2
    624c:	d37df042 	lsl	x2, x2, #3
    6250:	8b020060 	add	x0, x3, x2
    6254:	f9401014 	ldr	x20, [x0, #32]
    6258:	b40002b4 	cbz	x20, 62ac <fwp_drop4+0x9c>
    625c:	38626862 	ldrb	w2, [x3, x2]
    6260:	7100085f 	cmp	w2, #0x2
    6264:	540002c0 	b.eq	62bc <fwp_drop4+0xac>  // b.none
    6268:	7100045f 	cmp	w2, #0x1
    626c:	54000201 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    6270:	29430002 	ldp	w2, w0, [x0, #24]
    6274:	92403c21 	and	x1, x1, #0xffff
    6278:	9b027c21 	mul	x1, x1, x2
    627c:	d360fc21 	lsr	x1, x1, #32
    6280:	eb00003f 	cmp	x1, x0
    6284:	54000142 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    6288:	8b010294 	add	x20, x20, x1
    628c:	39400280 	ldrb	w0, [x20]
    6290:	340000e0 	cbz	w0, 62ac <fwp_drop4+0x9c>
    6294:	7100041f 	cmp	w0, #0x1
    6298:	540001e0 	b.eq	62d4 <fwp_drop4+0xc4>  // b.none
    629c:	7103fc1f 	cmp	w0, #0xff
    62a0:	540007c0 	b.eq	6398 <fwp_drop4+0x188>  // b.none
    62a4:	51000400 	sub	w0, w0, #0x1
    62a8:	39000280 	strb	w0, [x20]
    62ac:	a94153f3 	ldp	x19, x20, [sp, #16]
    62b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62b4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62b8:	d65f03c0 	ret
    62bc:	72003c3f 	tst	w1, #0xffff
    62c0:	54fffe60 	b.eq	628c <fwp_drop4+0x7c>  // b.none
    62c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    62c8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    62cc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    62d0:	d65f03c0 	ret
    62d4:	9114c2c2 	add	x2, x22, #0x530
    62d8:	f9400660 	ldr	x0, [x19, #8]
    62dc:	f949d841 	ldr	x1, [x2, #5040]
    62e0:	f949ec42 	ldr	x2, [x2, #5080]
    62e4:	cb010001 	sub	x1, x0, x1
    62e8:	eb02403f 	cmp	x1, x2, lsl #16
    62ec:	54000362 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    62f0:	d350fc22 	lsr	x2, x1, #16
    62f4:	8b020842 	add	x2, x2, x2, lsl #2
    62f8:	d37df042 	lsl	x2, x2, #3
    62fc:	8b020064 	add	x4, x3, x2
    6300:	f9401094 	ldr	x20, [x4, #32]
    6304:	b40002b4 	cbz	x20, 6358 <fwp_drop4+0x148>
    6308:	38626862 	ldrb	w2, [x3, x2]
    630c:	7100085f 	cmp	w2, #0x2
    6310:	540003e0 	b.eq	638c <fwp_drop4+0x17c>  // b.none
    6314:	7100045f 	cmp	w2, #0x1
    6318:	54000201 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    631c:	29430883 	ldp	w3, w2, [x4, #24]
    6320:	92403c21 	and	x1, x1, #0xffff
    6324:	9b037c21 	mul	x1, x1, x3
    6328:	d360fc21 	lsr	x1, x1, #32
    632c:	eb02003f 	cmp	x1, x2
    6330:	54000142 	b.cs	6358 <fwp_drop4+0x148>  // b.hs, b.nlast
    6334:	8b010294 	add	x20, x20, x1
    6338:	39400281 	ldrb	w1, [x20]
    633c:	340000e1 	cbz	w1, 6358 <fwp_drop4+0x148>
    6340:	7100043f 	cmp	w1, #0x1
    6344:	54000200 	b.eq	6384 <fwp_drop4+0x174>  // b.none
    6348:	7103fc3f 	cmp	w1, #0xff
    634c:	54000640 	b.eq	6414 <fwp_drop4+0x204>  // b.none
    6350:	51000421 	sub	w1, w1, #0x1
    6354:	39000281 	strb	w1, [x20]
    6358:	f9400a74 	ldr	x20, [x19, #16]
    635c:	aa1303e0 	mov	x0, x19
    6360:	97fffce8 	bl	5700 <fwp_rc_free_arr>
    6364:	9114c2c0 	add	x0, x22, #0x530
    6368:	f949d801 	ldr	x1, [x0, #5040]
    636c:	f949ec00 	ldr	x0, [x0, #5080]
    6370:	cb010281 	sub	x1, x20, x1
    6374:	eb00403f 	cmp	x1, x0, lsl #16
    6378:	54fff9a2 	b.cs	62ac <fwp_drop4+0x9c>  // b.hs, b.nlast
    637c:	aa1403f3 	mov	x19, x20
    6380:	17ffffb0 	b	6240 <fwp_drop4+0x30>
    6384:	97fffcdf 	bl	5700 <fwp_rc_free_arr>
    6388:	17fffff4 	b	6358 <fwp_drop4+0x148>
    638c:	72003c3f 	tst	w1, #0xffff
    6390:	54fffe41 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    6394:	17ffffe9 	b	6338 <fwp_drop4+0x128>
    6398:	ca544681 	eor	x1, x20, x20, lsr #17
    639c:	9114c2c0 	add	x0, x22, #0x530
    63a0:	ca412421 	eor	x1, x1, x1, lsr #9
    63a4:	92401c21 	and	x1, x1, #0xff
    63a8:	910a2422 	add	x2, x1, #0x289
    63ac:	8b010c01 	add	x1, x0, x1, lsl #3
    63b0:	8b020c02 	add	x2, x0, x2, lsl #3
    63b4:	f94a2420 	ldr	x0, [x1, #5192]
    63b8:	b50000a0 	cbnz	x0, 63cc <fwp_drop4+0x1bc>
    63bc:	14000013 	b	6408 <fwp_drop4+0x1f8>
    63c0:	91004002 	add	x2, x0, #0x10
    63c4:	f9400800 	ldr	x0, [x0, #16]
    63c8:	b4000200 	cbz	x0, 6408 <fwp_drop4+0x1f8>
    63cc:	f9400001 	ldr	x1, [x0]
    63d0:	eb14003f 	cmp	x1, x20
    63d4:	54ffff61 	b.ne	63c0 <fwp_drop4+0x1b0>  // b.any
    63d8:	f9400041 	ldr	x1, [x2]
    63dc:	f9400420 	ldr	x0, [x1, #8]
    63e0:	d1000400 	sub	x0, x0, #0x1
    63e4:	f9000420 	str	x0, [x1, #8]
    63e8:	f103f81f 	cmp	x0, #0xfe
    63ec:	54fff601 	b.ne	62ac <fwp_drop4+0x9c>  // b.any
    63f0:	39400280 	ldrb	w0, [x20]
    63f4:	7103fc1f 	cmp	w0, #0xff
    63f8:	54000460 	b.eq	6484 <fwp_drop4+0x274>  // b.none
    63fc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6400:	39000280 	strb	w0, [x20]
    6404:	17ffffaa 	b	62ac <fwp_drop4+0x9c>
    6408:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    640c:	91168000 	add	x0, x0, #0x5a0
    6410:	97fff6a0 	bl	3e90 <fwp_trap>
    6414:	ca544680 	eor	x0, x20, x20, lsr #17
    6418:	9114c2c1 	add	x1, x22, #0x530
    641c:	ca402400 	eor	x0, x0, x0, lsr #9
    6420:	92401c00 	and	x0, x0, #0xff
    6424:	910a2402 	add	x2, x0, #0x289
    6428:	8b000c20 	add	x0, x1, x0, lsl #3
    642c:	8b020c22 	add	x2, x1, x2, lsl #3
    6430:	f94a2400 	ldr	x0, [x0, #5192]
    6434:	b50000a0 	cbnz	x0, 6448 <fwp_drop4+0x238>
    6438:	17fffff4 	b	6408 <fwp_drop4+0x1f8>
    643c:	91004002 	add	x2, x0, #0x10
    6440:	f9400800 	ldr	x0, [x0, #16]
    6444:	b4fffe20 	cbz	x0, 6408 <fwp_drop4+0x1f8>
    6448:	f9400001 	ldr	x1, [x0]
    644c:	eb14003f 	cmp	x1, x20
    6450:	54ffff61 	b.ne	643c <fwp_drop4+0x22c>  // b.any
    6454:	f9400041 	ldr	x1, [x2]
    6458:	f9400420 	ldr	x0, [x1, #8]
    645c:	d1000400 	sub	x0, x0, #0x1
    6460:	f9000420 	str	x0, [x1, #8]
    6464:	f103f81f 	cmp	x0, #0xfe
    6468:	54fff781 	b.ne	6358 <fwp_drop4+0x148>  // b.any
    646c:	39400280 	ldrb	w0, [x20]
    6470:	7103fc1f 	cmp	w0, #0xff
    6474:	540000e0 	b.eq	6490 <fwp_drop4+0x280>  // b.none
    6478:	12800020 	mov	w0, #0xfffffffe            	// #-2
    647c:	39000280 	strb	w0, [x20]
    6480:	17ffffb6 	b	6358 <fwp_drop4+0x148>
    6484:	aa1403e0 	mov	x0, x20
    6488:	97fff6a2 	bl	3f10 <fwp_rc_forget_slot.part.0>
    648c:	17ffffdc 	b	63fc <fwp_drop4+0x1ec>
    6490:	aa1403e0 	mov	x0, x20
    6494:	97fff69f 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6498:	17fffff8 	b	6478 <fwp_drop4+0x268>
    649c:	d503201f 	nop

00000000000064a0 <fwp_arg_drop37>:
    64a0:	7100003f 	cmp	w1, #0x0
    64a4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    64a8:	54000041 	b.ne	64b0 <fwp_arg_drop37+0x10>  // b.any
    64ac:	d65f03c0 	ret
    64b0:	f9400000 	ldr	x0, [x0]
    64b4:	17ffff57 	b	6210 <fwp_drop4>
    64b8:	d503201f 	nop
    64bc:	d503201f 	nop

00000000000064c0 <fwp_task_dispose>:
    64c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64c4:	910003fd 	mov	x29, sp
    64c8:	f9000bf3 	str	x19, [sp, #16]
    64cc:	aa0003f3 	mov	x19, x0
    64d0:	39414000 	ldrb	w0, [x0, #80]
    64d4:	36000720 	tbz	w0, #0, 65b8 <fwp_task_dispose+0xf8>
    64d8:	f9400a60 	ldr	x0, [x19, #16]
    64dc:	b50006e0 	cbnz	x0, 65b8 <fwp_task_dispose+0xf8>
    64e0:	a9478660 	ldp	x0, x1, [x19, #120]
    64e4:	39014e7f 	strb	wzr, [x19, #83]
    64e8:	f9003e7f 	str	xzr, [x19, #120]
    64ec:	f100003f 	cmp	x1, #0x0
    64f0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    64f4:	54000040 	b.eq	64fc <fwp_task_dispose+0x3c>  // b.none
    64f8:	d63f0020 	blr	x1
    64fc:	f9405660 	ldr	x0, [x19, #168]
    6500:	97fff720 	bl	4180 <fwp_mem_free>
    6504:	f900567f 	str	xzr, [x19, #168]
    6508:	b9405e60 	ldr	w0, [x19, #92]
    650c:	7100041f 	cmp	w0, #0x1
    6510:	54000420 	b.eq	6594 <fwp_task_dispose+0xd4>  // b.none
    6514:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6518:	9114c042 	add	x2, x2, #0x530
    651c:	f949d840 	ldr	x0, [x2, #5040]
    6520:	f949ec41 	ldr	x1, [x2, #5080]
    6524:	cb000260 	sub	x0, x19, x0
    6528:	eb01401f 	cmp	x0, x1, lsl #16
    652c:	540002e2 	b.cs	6588 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6530:	d350fc01 	lsr	x1, x0, #16
    6534:	f949fc44 	ldr	x4, [x2, #5112]
    6538:	8b010821 	add	x1, x1, x1, lsl #2
    653c:	d37df021 	lsl	x1, x1, #3
    6540:	8b010083 	add	x3, x4, x1
    6544:	f9401062 	ldr	x2, [x3, #32]
    6548:	b4000202 	cbz	x2, 6588 <fwp_task_dispose+0xc8>
    654c:	38616881 	ldrb	w1, [x4, x1]
    6550:	7100083f 	cmp	w1, #0x2
    6554:	54000280 	b.eq	65a4 <fwp_task_dispose+0xe4>  // b.none
    6558:	7100043f 	cmp	w1, #0x1
    655c:	54000161 	b.ne	6588 <fwp_task_dispose+0xc8>  // b.any
    6560:	29430464 	ldp	w4, w1, [x3, #24]
    6564:	92403c00 	and	x0, x0, #0xffff
    6568:	9b047c00 	mul	x0, x0, x4
    656c:	d360fc00 	lsr	x0, x0, #32
    6570:	eb01001f 	cmp	x0, x1
    6574:	540000a2 	b.cs	6588 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6578:	8b000042 	add	x2, x2, x0
    657c:	39400040 	ldrb	w0, [x2]
    6580:	7100041f 	cmp	w0, #0x1
    6584:	54000080 	b.eq	6594 <fwp_task_dispose+0xd4>  // b.none
    6588:	f9400bf3 	ldr	x19, [sp, #16]
    658c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6590:	d65f03c0 	ret
    6594:	aa1303e0 	mov	x0, x19
    6598:	f9400bf3 	ldr	x19, [sp, #16]
    659c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65a0:	17fff6f8 	b	4180 <fwp_mem_free>
    65a4:	72003c1f 	tst	w0, #0xffff
    65a8:	54fffea0 	b.eq	657c <fwp_task_dispose+0xbc>  // b.none
    65ac:	f9400bf3 	ldr	x19, [sp, #16]
    65b0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    65b4:	d65f03c0 	ret
    65b8:	97fff0c6 	bl	28d0 <abort@plt>
    65bc:	d503201f 	nop

00000000000065c0 <fwp_free_zombie>:
    65c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    65c4:	910003fd 	mov	x29, sp
    65c8:	a90153f3 	stp	x19, x20, [sp, #16]
    65cc:	d00000d4 	adrp	x20, 20000 <__data_start>
    65d0:	9100c281 	add	x1, x20, #0x30
    65d4:	f9405033 	ldr	x19, [x1, #160]
    65d8:	b4000333 	cbz	x19, 663c <fwp_free_zombie+0x7c>
    65dc:	f9400820 	ldr	x0, [x1, #16]
    65e0:	eb00027f 	cmp	x19, x0
    65e4:	540002c0 	b.eq	663c <fwp_free_zombie+0x7c>  // b.none
    65e8:	b940a822 	ldr	w2, [x1, #168]
    65ec:	f9400a60 	ldr	x0, [x19, #16]
    65f0:	7100fc5f 	cmp	w2, #0x3f
    65f4:	5400078c 	b.gt	66e4 <fwp_free_zombie+0x124>
    65f8:	9102c023 	add	x3, x1, #0xb0
    65fc:	11000444 	add	w4, w2, #0x1
    6600:	b900a824 	str	w4, [x1, #168]
    6604:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6608:	f822d860 	str	x0, [x3, w2, sxtw #3]
    660c:	a9530261 	ldp	x1, x0, [x19, #304]
    6610:	b4000741 	cbz	x1, 66f8 <fwp_free_zombie+0x138>
    6614:	f9009c20 	str	x0, [x1, #312]
    6618:	b4000040 	cbz	x0, 6620 <fwp_free_zombie+0x60>
    661c:	f9009801 	str	x1, [x0, #304]
    6620:	9100c294 	add	x20, x20, #0x30
    6624:	b9405e60 	ldr	w0, [x19, #92]
    6628:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    662c:	f900529f 	str	xzr, [x20, #160]
    6630:	34000140 	cbz	w0, 6658 <fwp_free_zombie+0x98>
    6634:	7100041f 	cmp	w0, #0x1
    6638:	54000080 	b.eq	6648 <fwp_free_zombie+0x88>  // b.none
    663c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6640:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6644:	d65f03c0 	ret
    6648:	aa1303e0 	mov	x0, x19
    664c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6650:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6654:	17ffff9b 	b	64c0 <fwp_task_dispose>
    6658:	f0000144 	adrp	x4, 31000 <fwp_root_context+0xcb0>
    665c:	9114c082 	add	x2, x4, #0x530
    6660:	f949d841 	ldr	x1, [x2, #5040]
    6664:	f949ec40 	ldr	x0, [x2, #5080]
    6668:	cb010261 	sub	x1, x19, x1
    666c:	eb00403f 	cmp	x1, x0, lsl #16
    6670:	54fffe62 	b.cs	663c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6674:	d350fc20 	lsr	x0, x1, #16
    6678:	f949fc43 	ldr	x3, [x2, #5112]
    667c:	8b000800 	add	x0, x0, x0, lsl #2
    6680:	d37df000 	lsl	x0, x0, #3
    6684:	8b000062 	add	x2, x3, x0
    6688:	f9401054 	ldr	x20, [x2, #32]
    668c:	b4fffd94 	cbz	x20, 663c <fwp_free_zombie+0x7c>
    6690:	38606860 	ldrb	w0, [x3, x0]
    6694:	7100081f 	cmp	w0, #0x2
    6698:	54000360 	b.eq	6704 <fwp_free_zombie+0x144>  // b.none
    669c:	7100041f 	cmp	w0, #0x1
    66a0:	54fffce1 	b.ne	663c <fwp_free_zombie+0x7c>  // b.any
    66a4:	29430043 	ldp	w3, w0, [x2, #24]
    66a8:	92403c21 	and	x1, x1, #0xffff
    66ac:	9b037c21 	mul	x1, x1, x3
    66b0:	d360fc21 	lsr	x1, x1, #32
    66b4:	eb00003f 	cmp	x1, x0
    66b8:	54fffc22 	b.cs	663c <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    66bc:	8b010294 	add	x20, x20, x1
    66c0:	39400280 	ldrb	w0, [x20]
    66c4:	34fffbc0 	cbz	w0, 663c <fwp_free_zombie+0x7c>
    66c8:	7100041f 	cmp	w0, #0x1
    66cc:	54fffbe0 	b.eq	6648 <fwp_free_zombie+0x88>  // b.none
    66d0:	7103fc1f 	cmp	w0, #0xff
    66d4:	540001e0 	b.eq	6710 <fwp_free_zombie+0x150>  // b.none
    66d8:	51000400 	sub	w0, w0, #0x1
    66dc:	39000280 	strb	w0, [x20]
    66e0:	17ffffd7 	b	663c <fwp_free_zombie+0x7c>
    66e4:	f9400e61 	ldr	x1, [x19, #24]
    66e8:	97fff0ae 	bl	29a0 <munmap@plt>
    66ec:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    66f0:	a9530261 	ldp	x1, x0, [x19, #304]
    66f4:	b5fff901 	cbnz	x1, 6614 <fwp_free_zombie+0x54>
    66f8:	9100c282 	add	x2, x20, #0x30
    66fc:	f9015840 	str	x0, [x2, #688]
    6700:	17ffffc6 	b	6618 <fwp_free_zombie+0x58>
    6704:	72003c3f 	tst	w1, #0xffff
    6708:	54fff9a1 	b.ne	663c <fwp_free_zombie+0x7c>  // b.any
    670c:	17ffffed 	b	66c0 <fwp_free_zombie+0x100>
    6710:	ca544680 	eor	x0, x20, x20, lsr #17
    6714:	9114c084 	add	x4, x4, #0x530
    6718:	ca402400 	eor	x0, x0, x0, lsr #9
    671c:	92401c00 	and	x0, x0, #0xff
    6720:	910a2402 	add	x2, x0, #0x289
    6724:	8b000c80 	add	x0, x4, x0, lsl #3
    6728:	8b020c82 	add	x2, x4, x2, lsl #3
    672c:	f94a2400 	ldr	x0, [x0, #5192]
    6730:	b50000a0 	cbnz	x0, 6744 <fwp_free_zombie+0x184>
    6734:	14000013 	b	6780 <fwp_free_zombie+0x1c0>
    6738:	91004002 	add	x2, x0, #0x10
    673c:	f9400800 	ldr	x0, [x0, #16]
    6740:	b4000200 	cbz	x0, 6780 <fwp_free_zombie+0x1c0>
    6744:	f9400001 	ldr	x1, [x0]
    6748:	eb14003f 	cmp	x1, x20
    674c:	54ffff61 	b.ne	6738 <fwp_free_zombie+0x178>  // b.any
    6750:	f9400041 	ldr	x1, [x2]
    6754:	f9400420 	ldr	x0, [x1, #8]
    6758:	d1000400 	sub	x0, x0, #0x1
    675c:	f9000420 	str	x0, [x1, #8]
    6760:	f103f81f 	cmp	x0, #0xfe
    6764:	54fff6c1 	b.ne	663c <fwp_free_zombie+0x7c>  // b.any
    6768:	39400280 	ldrb	w0, [x20]
    676c:	7103fc1f 	cmp	w0, #0xff
    6770:	540000e0 	b.eq	678c <fwp_free_zombie+0x1cc>  // b.none
    6774:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6778:	39000280 	strb	w0, [x20]
    677c:	17ffffb0 	b	663c <fwp_free_zombie+0x7c>
    6780:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6784:	91168000 	add	x0, x0, #0x5a0
    6788:	97fff5c2 	bl	3e90 <fwp_trap>
    678c:	aa1403e0 	mov	x0, x20
    6790:	97fff5e0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6794:	17fffff8 	b	6774 <fwp_free_zombie+0x1b4>
    6798:	d503201f 	nop
    679c:	d503201f 	nop

00000000000067a0 <fwp_block>:
    67a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    67a4:	910003fd 	mov	x29, sp
    67a8:	a90153f3 	stp	x19, x20, [sp, #16]
    67ac:	d00000d3 	adrp	x19, 20000 <__data_start>
    67b0:	9100c274 	add	x20, x19, #0x30
    67b4:	f9401a82 	ldr	x2, [x20, #48]
    67b8:	b4000642 	cbz	x2, 6880 <fwp_block+0xe0>
    67bc:	9100c261 	add	x1, x19, #0x30
    67c0:	f9408040 	ldr	x0, [x2, #256]
    67c4:	f9001820 	str	x0, [x1, #48]
    67c8:	b40006a0 	cbz	x0, 689c <fwp_block+0xfc>
    67cc:	d503201f 	nop
    67d0:	9100c263 	add	x3, x19, #0x30
    67d4:	3901505f 	strb	wzr, [x2, #84]
    67d8:	f9400864 	ldr	x4, [x3, #16]
    67dc:	eb02009f 	cmp	x4, x2
    67e0:	54000440 	b.eq	6868 <fwp_block+0xc8>  // b.none
    67e4:	f9415c65 	ldr	x5, [x3, #696]
    67e8:	f9000862 	str	x2, [x3, #16]
    67ec:	f9400441 	ldr	x1, [x2, #8]
    67f0:	f9004885 	str	x5, [x4, #144]
    67f4:	f9416065 	ldr	x5, [x3, #704]
    67f8:	f9004c85 	str	x5, [x4, #152]
    67fc:	f9416465 	ldr	x5, [x3, #712]
    6800:	f9005085 	str	x5, [x4, #160]
    6804:	f9416865 	ldr	x5, [x3, #720]
    6808:	f9005485 	str	x5, [x4, #168]
    680c:	f9416c65 	ldr	x5, [x3, #728]
    6810:	f9005885 	str	x5, [x4, #176]
    6814:	f9417065 	ldr	x5, [x3, #736]
    6818:	f9005c85 	str	x5, [x4, #184]
    681c:	f9417465 	ldr	x5, [x3, #744]
    6820:	f9006085 	str	x5, [x4, #192]
    6824:	f9400480 	ldr	x0, [x4, #8]
    6828:	f9404844 	ldr	x4, [x2, #144]
    682c:	f9015c64 	str	x4, [x3, #696]
    6830:	f9404c44 	ldr	x4, [x2, #152]
    6834:	f9016064 	str	x4, [x3, #704]
    6838:	f9405044 	ldr	x4, [x2, #160]
    683c:	f9016464 	str	x4, [x3, #712]
    6840:	f9405444 	ldr	x4, [x2, #168]
    6844:	f9016864 	str	x4, [x3, #720]
    6848:	f9405844 	ldr	x4, [x2, #176]
    684c:	f9016c64 	str	x4, [x3, #728]
    6850:	a94b8844 	ldp	x4, x2, [x2, #184]
    6854:	f9017064 	str	x4, [x3, #736]
    6858:	f9017462 	str	x2, [x3, #744]
    685c:	97fff021 	bl	28e0 <swapcontext@plt>
    6860:	97ffff58 	bl	65c0 <fwp_free_zombie>
    6864:	d503201f 	nop
    6868:	9100c260 	add	x0, x19, #0x30
    686c:	b942f000 	ldr	w0, [x0, #752]
    6870:	340001a0 	cbz	w0, 68a4 <fwp_block+0x104>
    6874:	a94153f3 	ldp	x19, x20, [sp, #16]
    6878:	a8c27bfd 	ldp	x29, x30, [sp], #32
    687c:	d65f03c0 	ret
    6880:	97fff7cc 	bl	47b0 <fwp_poll_events>
    6884:	f9401a82 	ldr	x2, [x20, #48]
    6888:	b4ffffc2 	cbz	x2, 6880 <fwp_block+0xe0>
    688c:	9100c261 	add	x1, x19, #0x30
    6890:	f9408040 	ldr	x0, [x2, #256]
    6894:	f9001820 	str	x0, [x1, #48]
    6898:	b5fff9c0 	cbnz	x0, 67d0 <fwp_block+0x30>
    689c:	f900143f 	str	xzr, [x1, #40]
    68a0:	17ffffcc 	b	67d0 <fwp_block+0x30>
    68a4:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    68a8:	9120e000 	add	x0, x0, #0x838
    68ac:	97fff059 	bl	2a10 <getenv@plt>
    68b0:	5284e202 	mov	w2, #0x2710                	// #10000
    68b4:	b4000060 	cbz	x0, 68c0 <fwp_block+0x120>
    68b8:	39400001 	ldrb	w1, [x0]
    68bc:	350000c1 	cbnz	w1, 68d4 <fwp_block+0x134>
    68c0:	9100c273 	add	x19, x19, #0x30
    68c4:	b902f262 	str	w2, [x19, #752]
    68c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    68cc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    68d0:	d65f03c0 	ret
    68d4:	52800142 	mov	w2, #0xa                   	// #10
    68d8:	d2800001 	mov	x1, #0x0                   	// #0
    68dc:	97ffef9d 	bl	2750 <strtoll@plt>
    68e0:	d1000403 	sub	x3, x0, #0x1
    68e4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    68e8:	eb02007f 	cmp	x3, x2
    68ec:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    68f0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    68f4:	17fffff3 	b	68c0 <fwp_block+0x120>
    68f8:	d503201f 	nop
    68fc:	d503201f 	nop

0000000000006900 <fwp_drop10>:
    6900:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6904:	910003fd 	mov	x29, sp
    6908:	a90153f3 	stp	x19, x20, [sp, #16]
    690c:	f0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    6910:	f90013f5 	str	x21, [sp, #32]
    6914:	9114c275 	add	x21, x19, #0x530
    6918:	f949daa1 	ldr	x1, [x21, #5040]
    691c:	f949eea2 	ldr	x2, [x21, #5080]
    6920:	cb010001 	sub	x1, x0, x1
    6924:	eb02403f 	cmp	x1, x2, lsl #16
    6928:	54000382 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    692c:	d350fc22 	lsr	x2, x1, #16
    6930:	f949fea3 	ldr	x3, [x21, #5112]
    6934:	8b020842 	add	x2, x2, x2, lsl #2
    6938:	d37df042 	lsl	x2, x2, #3
    693c:	8b020064 	add	x4, x3, x2
    6940:	f9401094 	ldr	x20, [x4, #32]
    6944:	b40002b4 	cbz	x20, 6998 <fwp_drop10+0x98>
    6948:	38626862 	ldrb	w2, [x3, x2]
    694c:	7100085f 	cmp	w2, #0x2
    6950:	540007a0 	b.eq	6a44 <fwp_drop10+0x144>  // b.none
    6954:	7100045f 	cmp	w2, #0x1
    6958:	54000201 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    695c:	29430885 	ldp	w5, w2, [x4, #24]
    6960:	92403c21 	and	x1, x1, #0xffff
    6964:	9b057c21 	mul	x1, x1, x5
    6968:	d360fc21 	lsr	x1, x1, #32
    696c:	eb02003f 	cmp	x1, x2
    6970:	54000142 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6974:	8b010294 	add	x20, x20, x1
    6978:	39400281 	ldrb	w1, [x20]
    697c:	340000e1 	cbz	w1, 6998 <fwp_drop10+0x98>
    6980:	7100043f 	cmp	w1, #0x1
    6984:	54000120 	b.eq	69a8 <fwp_drop10+0xa8>  // b.none
    6988:	7103fc3f 	cmp	w1, #0xff
    698c:	540007c0 	b.eq	6a84 <fwp_drop10+0x184>  // b.none
    6990:	51000421 	sub	w1, w1, #0x1
    6994:	39000281 	strb	w1, [x20]
    6998:	a94153f3 	ldp	x19, x20, [sp, #16]
    699c:	f94013f5 	ldr	x21, [sp, #32]
    69a0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    69a4:	d65f03c0 	ret
    69a8:	f9400001 	ldr	x1, [x0]
    69ac:	b7f80581 	tbnz	x1, #63, 6a5c <fwp_drop10+0x15c>
    69b0:	9114c273 	add	x19, x19, #0x530
    69b4:	f949da61 	ldr	x1, [x19, #5040]
    69b8:	f949ee62 	ldr	x2, [x19, #5080]
    69bc:	cb010001 	sub	x1, x0, x1
    69c0:	eb02403f 	cmp	x1, x2, lsl #16
    69c4:	54fffea2 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    69c8:	d350fc22 	lsr	x2, x1, #16
    69cc:	8b020842 	add	x2, x2, x2, lsl #2
    69d0:	d37df042 	lsl	x2, x2, #3
    69d4:	8b020065 	add	x5, x3, x2
    69d8:	f94010a4 	ldr	x4, [x5, #32]
    69dc:	b4fffde4 	cbz	x4, 6998 <fwp_drop10+0x98>
    69e0:	38626862 	ldrb	w2, [x3, x2]
    69e4:	7100085f 	cmp	w2, #0x2
    69e8:	54000220 	b.eq	6a2c <fwp_drop10+0x12c>  // b.none
    69ec:	7100045f 	cmp	w2, #0x1
    69f0:	54fffd41 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    69f4:	294308a3 	ldp	w3, w2, [x5, #24]
    69f8:	92403c21 	and	x1, x1, #0xffff
    69fc:	9b037c21 	mul	x1, x1, x3
    6a00:	d360fc21 	lsr	x1, x1, #32
    6a04:	eb02003f 	cmp	x1, x2
    6a08:	54fffc82 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a0c:	8b010084 	add	x4, x4, x1
    6a10:	39400081 	ldrb	w1, [x4]
    6a14:	7100043f 	cmp	w1, #0x1
    6a18:	54fffc01 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    6a1c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a20:	f94013f5 	ldr	x21, [sp, #32]
    6a24:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a28:	17fff5d6 	b	4180 <fwp_mem_free>
    6a2c:	72003c3f 	tst	w1, #0xffff
    6a30:	54ffff00 	b.eq	6a10 <fwp_drop10+0x110>  // b.none
    6a34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a38:	f94013f5 	ldr	x21, [sp, #32]
    6a3c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a40:	d65f03c0 	ret
    6a44:	72003c3f 	tst	w1, #0xffff
    6a48:	54fff980 	b.eq	6978 <fwp_drop10+0x78>  // b.none
    6a4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6a50:	f94013f5 	ldr	x21, [sp, #32]
    6a54:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6a58:	d65f03c0 	ret
    6a5c:	f9400414 	ldr	x20, [x0, #8]
    6a60:	97fffb28 	bl	5700 <fwp_rc_free_arr>
    6a64:	9114c260 	add	x0, x19, #0x530
    6a68:	f949d801 	ldr	x1, [x0, #5040]
    6a6c:	f949ec00 	ldr	x0, [x0, #5080]
    6a70:	cb010281 	sub	x1, x20, x1
    6a74:	eb00403f 	cmp	x1, x0, lsl #16
    6a78:	54fff902 	b.cs	6998 <fwp_drop10+0x98>  // b.hs, b.nlast
    6a7c:	aa1403e0 	mov	x0, x20
    6a80:	17ffffab 	b	692c <fwp_drop10+0x2c>
    6a84:	ca544680 	eor	x0, x20, x20, lsr #17
    6a88:	9114c273 	add	x19, x19, #0x530
    6a8c:	ca402400 	eor	x0, x0, x0, lsr #9
    6a90:	92401c00 	and	x0, x0, #0xff
    6a94:	910a2402 	add	x2, x0, #0x289
    6a98:	8b000e60 	add	x0, x19, x0, lsl #3
    6a9c:	8b020e62 	add	x2, x19, x2, lsl #3
    6aa0:	f94a2400 	ldr	x0, [x0, #5192]
    6aa4:	b50000a0 	cbnz	x0, 6ab8 <fwp_drop10+0x1b8>
    6aa8:	14000013 	b	6af4 <fwp_drop10+0x1f4>
    6aac:	91004002 	add	x2, x0, #0x10
    6ab0:	f9400800 	ldr	x0, [x0, #16]
    6ab4:	b4000200 	cbz	x0, 6af4 <fwp_drop10+0x1f4>
    6ab8:	f9400001 	ldr	x1, [x0]
    6abc:	eb14003f 	cmp	x1, x20
    6ac0:	54ffff61 	b.ne	6aac <fwp_drop10+0x1ac>  // b.any
    6ac4:	f9400041 	ldr	x1, [x2]
    6ac8:	f9400420 	ldr	x0, [x1, #8]
    6acc:	d1000400 	sub	x0, x0, #0x1
    6ad0:	f9000420 	str	x0, [x1, #8]
    6ad4:	f103f81f 	cmp	x0, #0xfe
    6ad8:	54fff601 	b.ne	6998 <fwp_drop10+0x98>  // b.any
    6adc:	39400280 	ldrb	w0, [x20]
    6ae0:	7103fc1f 	cmp	w0, #0xff
    6ae4:	540000e0 	b.eq	6b00 <fwp_drop10+0x200>  // b.none
    6ae8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6aec:	39000280 	strb	w0, [x20]
    6af0:	17ffffaa 	b	6998 <fwp_drop10+0x98>
    6af4:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6af8:	91168000 	add	x0, x0, #0x5a0
    6afc:	97fff4e5 	bl	3e90 <fwp_trap>
    6b00:	aa1403e0 	mov	x0, x20
    6b04:	97fff503 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6b08:	17fffff8 	b	6ae8 <fwp_drop10+0x1e8>
    6b0c:	d503201f 	nop

0000000000006b10 <fwp_caps173>:
    6b10:	34000041 	cbz	w1, 6b18 <fwp_caps173+0x8>
    6b14:	d65f03c0 	ret
    6b18:	f0000143 	adrp	x3, 31000 <fwp_root_context+0xcb0>
    6b1c:	9114c063 	add	x3, x3, #0x530
    6b20:	f949d861 	ldr	x1, [x3, #5040]
    6b24:	f949ec62 	ldr	x2, [x3, #5080]
    6b28:	cb010001 	sub	x1, x0, x1
    6b2c:	eb02403f 	cmp	x1, x2, lsl #16
    6b30:	54ffff22 	b.cs	6b14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b34:	d350fc22 	lsr	x2, x1, #16
    6b38:	f949fc65 	ldr	x5, [x3, #5112]
    6b3c:	8b020842 	add	x2, x2, x2, lsl #2
    6b40:	d37df042 	lsl	x2, x2, #3
    6b44:	8b0200a4 	add	x4, x5, x2
    6b48:	f9401083 	ldr	x3, [x4, #32]
    6b4c:	b4fffe43 	cbz	x3, 6b14 <fwp_caps173+0x4>
    6b50:	386268a2 	ldrb	w2, [x5, x2]
    6b54:	7100085f 	cmp	w2, #0x2
    6b58:	540001c0 	b.eq	6b90 <fwp_caps173+0x80>  // b.none
    6b5c:	7100045f 	cmp	w2, #0x1
    6b60:	54fffda1 	b.ne	6b14 <fwp_caps173+0x4>  // b.any
    6b64:	29430885 	ldp	w5, w2, [x4, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b057c21 	mul	x1, x1, x5
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb02003f 	cmp	x1, x2
    6b78:	54fffce2 	b.cs	6b14 <fwp_caps173+0x4>  // b.hs, b.nlast
    6b7c:	8b010063 	add	x3, x3, x1
    6b80:	39400061 	ldrb	w1, [x3]
    6b84:	7100043f 	cmp	w1, #0x1
    6b88:	54fffc61 	b.ne	6b14 <fwp_caps173+0x4>  // b.any
    6b8c:	17fff57d 	b	4180 <fwp_mem_free>
    6b90:	72003c3f 	tst	w1, #0xffff
    6b94:	54ffff60 	b.eq	6b80 <fwp_caps173+0x70>  // b.none
    6b98:	d65f03c0 	ret
    6b9c:	d503201f 	nop

0000000000006ba0 <f37>:
    6ba0:	d10203ff 	sub	sp, sp, #0x80
    6ba4:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xc98>
    6ba8:	f947f421 	ldr	x1, [x1, #4072]
    6bac:	a9027bfd 	stp	x29, x30, [sp, #32]
    6bb0:	910083fd 	add	x29, sp, #0x20
    6bb4:	a9045bf5 	stp	x21, x22, [sp, #64]
    6bb8:	f0000155 	adrp	x21, 31000 <fwp_root_context+0xcb0>
    6bbc:	9114c2a3 	add	x3, x21, #0x530
    6bc0:	a90353f3 	stp	x19, x20, [sp, #48]
    6bc4:	aa0003f6 	mov	x22, x0
    6bc8:	a90563f7 	stp	x23, x24, [sp, #80]
    6bcc:	a9066bf9 	stp	x25, x26, [sp, #96]
    6bd0:	f949ec62 	ldr	x2, [x3, #5080]
    6bd4:	f9400024 	ldr	x4, [x1]
    6bd8:	f9000fe4 	str	x4, [sp, #24]
    6bdc:	d2800004 	mov	x4, #0x0                   	// #0
    6be0:	f949d861 	ldr	x1, [x3, #5040]
    6be4:	d370bc42 	lsl	x2, x2, #16
    6be8:	b4001820 	cbz	x0, 6eec <f37+0x34c>
    6bec:	f9400817 	ldr	x23, [x0, #16]
    6bf0:	cb0102e1 	sub	x1, x23, x1
    6bf4:	eb02003f 	cmp	x1, x2
    6bf8:	54000362 	b.cs	6c64 <f37+0xc4>  // b.hs, b.nlast
    6bfc:	f949fc60 	ldr	x0, [x3, #5112]
    6c00:	d350fc22 	lsr	x2, x1, #16
    6c04:	8b020842 	add	x2, x2, x2, lsl #2
    6c08:	8b020c02 	add	x2, x0, x2, lsl #3
    6c0c:	f9401040 	ldr	x0, [x2, #32]
    6c10:	b40002a0 	cbz	x0, 6c64 <f37+0xc4>
    6c14:	39400043 	ldrb	w3, [x2]
    6c18:	7100087f 	cmp	w3, #0x2
    6c1c:	54001560 	b.eq	6ec8 <f37+0x328>  // b.none
    6c20:	7100047f 	cmp	w3, #0x1
    6c24:	540001c1 	b.ne	6c5c <f37+0xbc>  // b.any
    6c28:	29430843 	ldp	w3, w2, [x2, #24]
    6c2c:	92403c21 	and	x1, x1, #0xffff
    6c30:	9b037c21 	mul	x1, x1, x3
    6c34:	d360fc21 	lsr	x1, x1, #32
    6c38:	eb02003f 	cmp	x1, x2
    6c3c:	54000102 	b.cs	6c5c <f37+0xbc>  // b.hs, b.nlast
    6c40:	8b010000 	add	x0, x0, x1
    6c44:	39400001 	ldrb	w1, [x0]
    6c48:	340000a1 	cbz	w1, 6c5c <f37+0xbc>
    6c4c:	7103f43f 	cmp	w1, #0xfd
    6c50:	54001808 	b.hi	6f50 <f37+0x3b0>  // b.pmore
    6c54:	11000421 	add	w1, w1, #0x1
    6c58:	39000001 	strb	w1, [x0]
    6c5c:	d2800002 	mov	x2, #0x0                   	// #0
    6c60:	b40000f6 	cbz	x22, 6c7c <f37+0xdc>
    6c64:	aa1603e1 	mov	x1, x22
    6c68:	d2800002 	mov	x2, #0x0                   	// #0
    6c6c:	d503201f 	nop
    6c70:	f9400821 	ldr	x1, [x1, #16]
    6c74:	91000442 	add	x2, x2, #0x1
    6c78:	b5ffffc1 	cbnz	x1, 6c70 <f37+0xd0>
    6c7c:	b40013f7 	cbz	x23, 6ef8 <f37+0x358>
    6c80:	aa1703e1 	mov	x1, x23
    6c84:	d2800003 	mov	x3, #0x0                   	// #0
    6c88:	f9400821 	ldr	x1, [x1, #16]
    6c8c:	91000463 	add	x3, x3, #0x1
    6c90:	b5ffffc1 	cbnz	x1, 6c88 <f37+0xe8>
    6c94:	eb02007f 	cmp	x3, x2
    6c98:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    6c9c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    6ca0:	eb00027f 	cmp	x19, x0
    6ca4:	540010a8 	b.hi	6eb8 <f37+0x318>  // b.pmore
    6ca8:	d37ffa74 	lsl	x20, x19, #1
    6cac:	52800041 	mov	w1, #0x2                   	// #2
    6cb0:	91000680 	add	x0, x20, #0x1
    6cb4:	d37df000 	lsl	x0, x0, #3
    6cb8:	97fff7ee 	bl	4c70 <fwp_heap_alloc>
    6cbc:	aa0003f8 	mov	x24, x0
    6cc0:	9114c2a1 	add	x1, x21, #0x530
    6cc4:	aa0103e0 	mov	x0, x1
    6cc8:	f9000314 	str	x20, [x24]
    6ccc:	f949d821 	ldr	x1, [x1, #5040]
    6cd0:	f949ec00 	ldr	x0, [x0, #5080]
    6cd4:	cb010301 	sub	x1, x24, x1
    6cd8:	eb00403f 	cmp	x1, x0, lsl #16
    6cdc:	54000342 	b.cs	6d44 <f37+0x1a4>  // b.hs, b.nlast
    6ce0:	9114c2a2 	add	x2, x21, #0x530
    6ce4:	d350fc20 	lsr	x0, x1, #16
    6ce8:	8b000800 	add	x0, x0, x0, lsl #2
    6cec:	f949fc43 	ldr	x3, [x2, #5112]
    6cf0:	d37df002 	lsl	x2, x0, #3
    6cf4:	8b020060 	add	x0, x3, x2
    6cf8:	f9401014 	ldr	x20, [x0, #32]
    6cfc:	b4000254 	cbz	x20, 6d44 <f37+0x1a4>
    6d00:	38626862 	ldrb	w2, [x3, x2]
    6d04:	7100085f 	cmp	w2, #0x2
    6d08:	54000ec0 	b.eq	6ee0 <f37+0x340>  // b.none
    6d0c:	7100045f 	cmp	w2, #0x1
    6d10:	540001a1 	b.ne	6d44 <f37+0x1a4>  // b.any
    6d14:	29430002 	ldp	w2, w0, [x0, #24]
    6d18:	92403c21 	and	x1, x1, #0xffff
    6d1c:	9b027c21 	mul	x1, x1, x2
    6d20:	d360fc21 	lsr	x1, x1, #32
    6d24:	eb00003f 	cmp	x1, x0
    6d28:	540000e2 	b.cs	6d44 <f37+0x1a4>  // b.hs, b.nlast
    6d2c:	8b010294 	add	x20, x20, x1
    6d30:	39400280 	ldrb	w0, [x20]
    6d34:	7103fc1f 	cmp	w0, #0xff
    6d38:	54001100 	b.eq	6f58 <f37+0x3b8>  // b.none
    6d3c:	52800020 	mov	w0, #0x1                   	// #1
    6d40:	39000280 	strb	w0, [x20]
    6d44:	b4000253 	cbz	x19, 6d8c <f37+0x1ec>
    6d48:	8b131313 	add	x19, x24, x19, lsl #4
    6d4c:	aa1803f4 	mov	x20, x24
    6d50:	aa1603fa 	mov	x26, x22
    6d54:	aa1703f9 	mov	x25, x23
    6d58:	f9400723 	ldr	x3, [x25, #8]
    6d5c:	f9400742 	ldr	x2, [x26, #8]
    6d60:	f9400861 	ldr	x1, [x3, #16]
    6d64:	f9400840 	ldr	x0, [x2, #16]
    6d68:	fd400461 	ldr	d1, [x3, #8]
    6d6c:	fd400440 	ldr	d0, [x2, #8]
    6d70:	97fff92d 	bl	5224 <w120>
    6d74:	f9000680 	str	x0, [x20, #8]
    6d78:	f8010e81 	str	x1, [x20, #16]!
    6d7c:	f9400b39 	ldr	x25, [x25, #16]
    6d80:	f9400b5a 	ldr	x26, [x26, #16]
    6d84:	eb14027f 	cmp	x19, x20
    6d88:	54fffe81 	b.ne	6d58 <f37+0x1b8>  // b.any
    6d8c:	aa1703e0 	mov	x0, x23
    6d90:	97fffd20 	bl	6210 <fwp_drop4>
    6d94:	aa1603e0 	mov	x0, x22
    6d98:	97fffd1e 	bl	6210 <fwp_drop4>
    6d9c:	f9400316 	ldr	x22, [x24]
    6da0:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    6da4:	b4000236 	cbz	x22, 6de8 <f37+0x248>
    6da8:	fd003be8 	str	d8, [sp, #112]
    6dac:	2f00e408 	movi	d8, #0x0
    6db0:	91002319 	add	x25, x24, #0x8
    6db4:	91004317 	add	x23, x24, #0x10
    6db8:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    6dbc:	d2800013 	mov	x19, #0x0                   	// #0
    6dc0:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    6dc4:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    6dc8:	91000a73 	add	x19, x19, #0x2
    6dcc:	1e602908 	fadd	d8, d8, d0
    6dd0:	97fff8c4 	bl	50e0 <f141.constprop.0>
    6dd4:	aa0003f4 	mov	x20, x0
    6dd8:	eb1302df 	cmp	x22, x19
    6ddc:	54ffff28 	b.hi	6dc0 <f37+0x220>  // b.pmore
    6de0:	9e660116 	fmov	x22, d8
    6de4:	fd403be8 	ldr	d8, [sp, #112]
    6de8:	9114c2b5 	add	x21, x21, #0x530
    6dec:	aa1803e0 	mov	x0, x24
    6df0:	97fffec4 	bl	6900 <fwp_drop10>
    6df4:	a900d3f6 	stp	x22, x20, [sp, #8]
    6df8:	910023e1 	add	x1, sp, #0x8
    6dfc:	52800000 	mov	w0, #0x0                   	// #0
    6e00:	97fff7e1 	bl	4d84 <fwp_data.part.0.constprop.0>
    6e04:	f949daa1 	ldr	x1, [x21, #5040]
    6e08:	aa0003f3 	mov	x19, x0
    6e0c:	f949eea0 	ldr	x0, [x21, #5080]
    6e10:	cb010261 	sub	x1, x19, x1
    6e14:	eb00403f 	cmp	x1, x0, lsl #16
    6e18:	54000322 	b.cs	6e7c <f37+0x2dc>  // b.hs, b.nlast
    6e1c:	d350fc22 	lsr	x2, x1, #16
    6e20:	f949fea3 	ldr	x3, [x21, #5112]
    6e24:	8b020842 	add	x2, x2, x2, lsl #2
    6e28:	d37df042 	lsl	x2, x2, #3
    6e2c:	8b020060 	add	x0, x3, x2
    6e30:	f9401014 	ldr	x20, [x0, #32]
    6e34:	b4000254 	cbz	x20, 6e7c <f37+0x2dc>
    6e38:	38626862 	ldrb	w2, [x3, x2]
    6e3c:	7100085f 	cmp	w2, #0x2
    6e40:	540004a0 	b.eq	6ed4 <f37+0x334>  // b.none
    6e44:	7100045f 	cmp	w2, #0x1
    6e48:	540001a1 	b.ne	6e7c <f37+0x2dc>  // b.any
    6e4c:	29430002 	ldp	w2, w0, [x0, #24]
    6e50:	92403c21 	and	x1, x1, #0xffff
    6e54:	9b027c21 	mul	x1, x1, x2
    6e58:	d360fc21 	lsr	x1, x1, #32
    6e5c:	eb00003f 	cmp	x1, x0
    6e60:	540000e2 	b.cs	6e7c <f37+0x2dc>  // b.hs, b.nlast
    6e64:	8b010294 	add	x20, x20, x1
    6e68:	39400280 	ldrb	w0, [x20]
    6e6c:	7103fc1f 	cmp	w0, #0xff
    6e70:	540007a0 	b.eq	6f64 <f37+0x3c4>  // b.none
    6e74:	52800020 	mov	w0, #0x1                   	// #1
    6e78:	39000280 	strb	w0, [x20]
    6e7c:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    6e80:	f947f400 	ldr	x0, [x0, #4072]
    6e84:	f9400fe2 	ldr	x2, [sp, #24]
    6e88:	f9400001 	ldr	x1, [x0]
    6e8c:	eb010042 	subs	x2, x2, x1
    6e90:	d2800001 	mov	x1, #0x0                   	// #0
    6e94:	54000721 	b.ne	6f78 <f37+0x3d8>  // b.any
    6e98:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6e9c:	aa1303e0 	mov	x0, x19
    6ea0:	a94353f3 	ldp	x19, x20, [sp, #48]
    6ea4:	a9445bf5 	ldp	x21, x22, [sp, #64]
    6ea8:	a94563f7 	ldp	x23, x24, [sp, #80]
    6eac:	a9466bf9 	ldp	x25, x26, [sp, #96]
    6eb0:	910203ff 	add	sp, sp, #0x80
    6eb4:	d65f03c0 	ret
    6eb8:	f0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    6ebc:	91212000 	add	x0, x0, #0x848
    6ec0:	fd003be8 	str	d8, [sp, #112]
    6ec4:	97fff3f3 	bl	3e90 <fwp_trap>
    6ec8:	72003c3f 	tst	w1, #0xffff
    6ecc:	54ffec81 	b.ne	6c5c <f37+0xbc>  // b.any
    6ed0:	17ffff5d 	b	6c44 <f37+0xa4>
    6ed4:	72003c3f 	tst	w1, #0xffff
    6ed8:	54fffd21 	b.ne	6e7c <f37+0x2dc>  // b.any
    6edc:	17ffffe3 	b	6e68 <f37+0x2c8>
    6ee0:	72003c3f 	tst	w1, #0xffff
    6ee4:	54fff301 	b.ne	6d44 <f37+0x1a4>  // b.any
    6ee8:	17ffff92 	b	6d30 <f37+0x190>
    6eec:	cb0103e1 	neg	x1, x1
    6ef0:	eb02003f 	cmp	x1, x2
    6ef4:	540001e3 	b.cc	6f30 <f37+0x390>  // b.lo, b.ul, b.last
    6ef8:	52800041 	mov	w1, #0x2                   	// #2
    6efc:	d2800100 	mov	x0, #0x8                   	// #8
    6f00:	97fff75c 	bl	4c70 <fwp_heap_alloc>
    6f04:	aa0003f8 	mov	x24, x0
    6f08:	9114c2a0 	add	x0, x21, #0x530
    6f0c:	f900031f 	str	xzr, [x24]
    6f10:	f949d801 	ldr	x1, [x0, #5040]
    6f14:	f949ec00 	ldr	x0, [x0, #5080]
    6f18:	cb010301 	sub	x1, x24, x1
    6f1c:	eb00403f 	cmp	x1, x0, lsl #16
    6f20:	54000282 	b.cs	6f70 <f37+0x3d0>  // b.hs, b.nlast
    6f24:	d2800013 	mov	x19, #0x0                   	// #0
    6f28:	d2800017 	mov	x23, #0x0                   	// #0
    6f2c:	17ffff6d 	b	6ce0 <f37+0x140>
    6f30:	f949fc62 	ldr	x2, [x3, #5112]
    6f34:	d350fc20 	lsr	x0, x1, #16
    6f38:	8b000800 	add	x0, x0, x0, lsl #2
    6f3c:	8b000c42 	add	x2, x2, x0, lsl #3
    6f40:	f9401040 	ldr	x0, [x2, #32]
    6f44:	b4fffda0 	cbz	x0, 6ef8 <f37+0x358>
    6f48:	d2800017 	mov	x23, #0x0                   	// #0
    6f4c:	17ffff32 	b	6c14 <f37+0x74>
    6f50:	97fff505 	bl	4364 <fwp_rc_wide_dup>
    6f54:	17ffff42 	b	6c5c <f37+0xbc>
    6f58:	aa1403e0 	mov	x0, x20
    6f5c:	97fff3ed 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6f60:	17ffff77 	b	6d3c <f37+0x19c>
    6f64:	aa1403e0 	mov	x0, x20
    6f68:	97fff3ea 	bl	3f10 <fwp_rc_forget_slot.part.0>
    6f6c:	17ffffc2 	b	6e74 <f37+0x2d4>
    6f70:	d2800017 	mov	x23, #0x0                   	// #0
    6f74:	17ffff86 	b	6d8c <f37+0x1ec>
    6f78:	fd003be8 	str	d8, [sp, #112]
    6f7c:	97ffee41 	bl	2880 <__stack_chk_fail@plt>

0000000000006f80 <fwp_owned_entry37>:
    6f80:	f9400000 	ldr	x0, [x0]
    6f84:	17ffff07 	b	6ba0 <f37>
    6f88:	d503201f 	nop
    6f8c:	d503201f 	nop

0000000000006f90 <e37>:
    6f90:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6f94:	910003fd 	mov	x29, sp
    6f98:	f9000bf3 	str	x19, [sp, #16]
    6f9c:	f9400013 	ldr	x19, [x0]
    6fa0:	aa1303e0 	mov	x0, x19
    6fa4:	97fff9b3 	bl	5670 <fwp_rc_share>
    6fa8:	aa1303e0 	mov	x0, x19
    6fac:	97fffefd 	bl	6ba0 <f37>
    6fb0:	aa0003f3 	mov	x19, x0
    6fb4:	97fff9af 	bl	5670 <fwp_rc_share>
    6fb8:	aa1303e0 	mov	x0, x19
    6fbc:	f9400bf3 	ldr	x19, [sp, #16]
    6fc0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6fc4:	d65f03c0 	ret
    6fc8:	d503201f 	nop
    6fcc:	d503201f 	nop

0000000000006fd0 <fwp_args37>:
    6fd0:	7100003f 	cmp	w1, #0x0
    6fd4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6fd8:	54000041 	b.ne	6fe0 <fwp_args37+0x10>  // b.any
    6fdc:	d65f03c0 	ret
    6fe0:	f0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    6fe4:	9114c042 	add	x2, x2, #0x530
    6fe8:	f9400001 	ldr	x1, [x0]
    6fec:	f949d843 	ldr	x3, [x2, #5040]
    6ff0:	f949ec40 	ldr	x0, [x2, #5080]
    6ff4:	cb030021 	sub	x1, x1, x3
    6ff8:	eb00403f 	cmp	x1, x0, lsl #16
    6ffc:	54ffff02 	b.cs	6fdc <fwp_args37+0xc>  // b.hs, b.nlast
    7000:	d350fc20 	lsr	x0, x1, #16
    7004:	f949fc44 	ldr	x4, [x2, #5112]
    7008:	8b000800 	add	x0, x0, x0, lsl #2
    700c:	d37df002 	lsl	x2, x0, #3
    7010:	8b020083 	add	x3, x4, x2
    7014:	f9401060 	ldr	x0, [x3, #32]
    7018:	b4fffe20 	cbz	x0, 6fdc <fwp_args37+0xc>
    701c:	38626882 	ldrb	w2, [x4, x2]
    7020:	7100085f 	cmp	w2, #0x2
    7024:	54000220 	b.eq	7068 <fwp_args37+0x98>  // b.none
    7028:	7100045f 	cmp	w2, #0x1
    702c:	54fffd81 	b.ne	6fdc <fwp_args37+0xc>  // b.any
    7030:	29430864 	ldp	w4, w2, [x3, #24]
    7034:	92403c21 	and	x1, x1, #0xffff
    7038:	9b047c21 	mul	x1, x1, x4
    703c:	d360fc21 	lsr	x1, x1, #32
    7040:	eb02003f 	cmp	x1, x2
    7044:	54fffcc2 	b.cs	6fdc <fwp_args37+0xc>  // b.hs, b.nlast
    7048:	8b010000 	add	x0, x0, x1
    704c:	39400001 	ldrb	w1, [x0]
    7050:	34fffc61 	cbz	w1, 6fdc <fwp_args37+0xc>
    7054:	7103f43f 	cmp	w1, #0xfd
    7058:	540000e8 	b.hi	7074 <fwp_args37+0xa4>  // b.pmore
    705c:	11000421 	add	w1, w1, #0x1
    7060:	39000001 	strb	w1, [x0]
    7064:	d65f03c0 	ret
    7068:	72003c3f 	tst	w1, #0xffff
    706c:	54ffff00 	b.eq	704c <fwp_args37+0x7c>  // b.none
    7070:	d65f03c0 	ret
    7074:	17fff4bc 	b	4364 <fwp_rc_wide_dup>
    7078:	d503201f 	nop
    707c:	d503201f 	nop

0000000000007080 <fwp_caps37>:
    7080:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    7084:	910003fd 	mov	x29, sp
    7088:	f9000bf3 	str	x19, [sp, #16]
    708c:	aa0003f3 	mov	x19, x0
    7090:	b9400400 	ldr	w0, [x0, #4]
    7094:	340004a0 	cbz	w0, 7128 <fwp_caps37+0xa8>
    7098:	f9400660 	ldr	x0, [x19, #8]
    709c:	350004e1 	cbnz	w1, 7138 <fwp_caps37+0xb8>
    70a0:	97fffc5c 	bl	6210 <fwp_drop4>
    70a4:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    70a8:	9114c042 	add	x2, x2, #0x530
    70ac:	f949d840 	ldr	x0, [x2, #5040]
    70b0:	f949ec41 	ldr	x1, [x2, #5080]
    70b4:	cb000260 	sub	x0, x19, x0
    70b8:	eb01401f 	cmp	x0, x1, lsl #16
    70bc:	54000382 	b.cs	712c <fwp_caps37+0xac>  // b.hs, b.nlast
    70c0:	d350fc01 	lsr	x1, x0, #16
    70c4:	f949fc44 	ldr	x4, [x2, #5112]
    70c8:	8b010821 	add	x1, x1, x1, lsl #2
    70cc:	d37df021 	lsl	x1, x1, #3
    70d0:	8b010083 	add	x3, x4, x1
    70d4:	f9401062 	ldr	x2, [x3, #32]
    70d8:	b40002a2 	cbz	x2, 712c <fwp_caps37+0xac>
    70dc:	38616881 	ldrb	w1, [x4, x1]
    70e0:	7100083f 	cmp	w1, #0x2
    70e4:	540006c0 	b.eq	71bc <fwp_caps37+0x13c>  // b.none
    70e8:	7100043f 	cmp	w1, #0x1
    70ec:	54000201 	b.ne	712c <fwp_caps37+0xac>  // b.any
    70f0:	29430464 	ldp	w4, w1, [x3, #24]
    70f4:	92403c00 	and	x0, x0, #0xffff
    70f8:	9b047c00 	mul	x0, x0, x4
    70fc:	d360fc00 	lsr	x0, x0, #32
    7100:	eb01001f 	cmp	x0, x1
    7104:	54000142 	b.cs	712c <fwp_caps37+0xac>  // b.hs, b.nlast
    7108:	8b000042 	add	x2, x2, x0
    710c:	39400040 	ldrb	w0, [x2]
    7110:	7100041f 	cmp	w0, #0x1
    7114:	540000c1 	b.ne	712c <fwp_caps37+0xac>  // b.any
    7118:	aa1303e0 	mov	x0, x19
    711c:	f9400bf3 	ldr	x19, [sp, #16]
    7120:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7124:	17fff417 	b	4180 <fwp_mem_free>
    7128:	34fffbe1 	cbz	w1, 70a4 <fwp_caps37+0x24>
    712c:	f9400bf3 	ldr	x19, [sp, #16]
    7130:	a8c27bfd 	ldp	x29, x30, [sp], #32
    7134:	d65f03c0 	ret
    7138:	d0000142 	adrp	x2, 31000 <fwp_root_context+0xcb0>
    713c:	9114c042 	add	x2, x2, #0x530
    7140:	f949d843 	ldr	x3, [x2, #5040]
    7144:	f949ec41 	ldr	x1, [x2, #5080]
    7148:	cb030000 	sub	x0, x0, x3
    714c:	eb01401f 	cmp	x0, x1, lsl #16
    7150:	54fffee2 	b.cs	712c <fwp_caps37+0xac>  // b.hs, b.nlast
    7154:	d350fc01 	lsr	x1, x0, #16
    7158:	f949fc44 	ldr	x4, [x2, #5112]
    715c:	8b010821 	add	x1, x1, x1, lsl #2
    7160:	d37df021 	lsl	x1, x1, #3
    7164:	8b010083 	add	x3, x4, x1
    7168:	f9401062 	ldr	x2, [x3, #32]
    716c:	b4fffe02 	cbz	x2, 712c <fwp_caps37+0xac>
    7170:	38616881 	ldrb	w1, [x4, x1]
    7174:	7100083f 	cmp	w1, #0x2
    7178:	54000280 	b.eq	71c8 <fwp_caps37+0x148>  // b.none
    717c:	7100043f 	cmp	w1, #0x1
    7180:	54fffd61 	b.ne	712c <fwp_caps37+0xac>  // b.any
    7184:	92403c01 	and	x1, x0, #0xffff
    7188:	29430064 	ldp	w4, w0, [x3, #24]
    718c:	9b047c21 	mul	x1, x1, x4
    7190:	d360fc21 	lsr	x1, x1, #32
    7194:	eb00003f 	cmp	x1, x0
    7198:	54fffca2 	b.cs	712c <fwp_caps37+0xac>  // b.hs, b.nlast
    719c:	8b010042 	add	x2, x2, x1
    71a0:	39400040 	ldrb	w0, [x2]
    71a4:	34fffc40 	cbz	w0, 712c <fwp_caps37+0xac>
    71a8:	7103f41f 	cmp	w0, #0xfd
    71ac:	54000148 	b.hi	71d4 <fwp_caps37+0x154>  // b.pmore
    71b0:	11000400 	add	w0, w0, #0x1
    71b4:	39000040 	strb	w0, [x2]
    71b8:	17ffffdd 	b	712c <fwp_caps37+0xac>
    71bc:	72003c1f 	tst	w0, #0xffff
    71c0:	54fffb61 	b.ne	712c <fwp_caps37+0xac>  // b.any
    71c4:	17ffffd2 	b	710c <fwp_caps37+0x8c>
    71c8:	72003c1f 	tst	w0, #0xffff
    71cc:	54fffb01 	b.ne	712c <fwp_caps37+0xac>  // b.any
    71d0:	17fffff4 	b	71a0 <fwp_caps37+0x120>
    71d4:	f9400bf3 	ldr	x19, [sp, #16]
    71d8:	aa0203e0 	mov	x0, x2
    71dc:	a8c27bfd 	ldp	x29, x30, [sp], #32
    71e0:	17fff461 	b	4364 <fwp_rc_wide_dup>

00000000000071e4 <fwp_write>:
    71e4:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    71e8:	910003fd 	mov	x29, sp
    71ec:	900000c4 	adrp	x4, 1f000 <fwp_fn_table+0xc98>
    71f0:	f947f484 	ldr	x4, [x4, #4072]
    71f4:	a90153f3 	stp	x19, x20, [sp, #16]
    71f8:	d10943ff 	sub	sp, sp, #0x250
    71fc:	b9400045 	ldr	w5, [x2]
    7200:	aa0003f4 	mov	x20, x0
    7204:	f9400080 	ldr	x0, [x4]
    7208:	f90127e0 	str	x0, [sp, #584]
    720c:	d2800000 	mov	x0, #0x0                   	// #0
    7210:	710064bf 	cmp	w5, #0x19
    7214:	54000408 	b.hi	7294 <fwp_write+0xb0>  // b.pmore
    7218:	d0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    721c:	aa0103f3 	mov	x19, x1
    7220:	913fc000 	add	x0, x0, #0xff0
    7224:	f9013bf5 	str	x21, [sp, #624]
    7228:	f9013ff6 	str	x22, [sp, #632]
    722c:	f90153fb 	str	x27, [sp, #672]
    7230:	f90157fc 	str	x28, [sp, #680]
    7234:	aa0203fc 	mov	x28, x2
    7238:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    723c:	10000061 	adr	x1, 7248 <fwp_write+0x64>
    7240:	8b20a820 	add	x0, x1, w0, sxth #2
    7244:	d61f0000 	br	x0
    7248:	910123e0 	add	x0, sp, #0x48
    724c:	aa1303e5 	mov	x5, x19
    7250:	d0000004 	adrp	x4, 9000 <__divti3+0x2c0>
    7254:	aa0003f3 	mov	x19, x0
    7258:	91224084 	add	x4, x4, #0x890
    725c:	d2804003 	mov	x3, #0x200                 	// #512
    7260:	aa0303e1 	mov	x1, x3
    7264:	52800042 	mov	w2, #0x2                   	// #2
    7268:	97ffed62 	bl	27f0 <__snprintf_chk@plt>
    726c:	aa1303e0 	mov	x0, x19
    7270:	97ffed28 	bl	2710 <strlen@plt>
    7274:	aa1303e1 	mov	x1, x19
    7278:	aa0003e2 	mov	x2, x0
    727c:	aa1403e0 	mov	x0, x20
    7280:	97fff064 	bl	3410 <buf_put>
    7284:	f9413bf5 	ldr	x21, [sp, #624]
    7288:	f9413ff6 	ldr	x22, [sp, #632]
    728c:	f94153fb 	ldr	x27, [sp, #672]
    7290:	f94157fc 	ldr	x28, [sp, #680]
    7294:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7298:	f947f400 	ldr	x0, [x0, #4072]
    729c:	f94127e2 	ldr	x2, [sp, #584]
    72a0:	f9400001 	ldr	x1, [x0]
    72a4:	eb010042 	subs	x2, x2, x1
    72a8:	d2800001 	mov	x1, #0x0                   	// #0
    72ac:	540077a1 	b.ne	81a0 <fwp_write+0xfbc>  // b.any
    72b0:	910943ff 	add	sp, sp, #0x250
    72b4:	a94153f3 	ldp	x19, x20, [sp, #16]
    72b8:	a8c77bfd 	ldp	x29, x30, [sp], #112
    72bc:	d65f03c0 	ret
    72c0:	910123e0 	add	x0, sp, #0x48
    72c4:	aa1303e5 	mov	x5, x19
    72c8:	d0000004 	adrp	x4, 9000 <__divti3+0x2c0>
    72cc:	aa0003f3 	mov	x19, x0
    72d0:	91222084 	add	x4, x4, #0x888
    72d4:	d2804003 	mov	x3, #0x200                 	// #512
    72d8:	17ffffe2 	b	7260 <fwp_write+0x7c>
    72dc:	71004cbf 	cmp	w5, #0x13
    72e0:	d0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    72e4:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    72e8:	9121e000 	add	x0, x0, #0x878
    72ec:	91220021 	add	x1, x1, #0x880
    72f0:	d2800082 	mov	x2, #0x4                   	// #4
    72f4:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    72f8:	aa1403e0 	mov	x0, x20
    72fc:	f90143f7 	str	x23, [sp, #640]
    7300:	d2800016 	mov	x22, #0x0                   	// #0
    7304:	f90147f8 	str	x24, [sp, #648]
    7308:	97fff042 	bl	3410 <buf_put>
    730c:	f9400260 	ldr	x0, [x19]
    7310:	d0000017 	adrp	x23, 9000 <__divti3+0x2c0>
    7314:	d2800015 	mov	x21, #0x0                   	// #0
    7318:	912402f7 	add	x23, x23, #0x900
    731c:	b4004780 	cbz	x0, 7c0c <fwp_write+0xa28>
    7320:	b9400380 	ldr	w0, [x28]
    7324:	52800003 	mov	w3, #0x0                   	// #0
    7328:	f9401f82 	ldr	x2, [x28, #56]
    732c:	71004c1f 	cmp	w0, #0x13
    7330:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    7334:	aa1403e0 	mov	x0, x20
    7338:	8b010e61 	add	x1, x19, x1, lsl #3
    733c:	f9400421 	ldr	x1, [x1, #8]
    7340:	97ffffa9 	bl	71e4 <fwp_write>
    7344:	b9400380 	ldr	w0, [x28]
    7348:	7100481f 	cmp	w0, #0x12
    734c:	54004b20 	b.eq	7cb0 <fwp_write+0xacc>  // b.none
    7350:	f9400260 	ldr	x0, [x19]
    7354:	910006b5 	add	x21, x21, #0x1
    7358:	91000ad6 	add	x22, x22, #0x2
    735c:	eb15001f 	cmp	x0, x21
    7360:	54004569 	b.ls	7c0c <fwp_write+0xa28>  // b.plast
    7364:	aa1703e1 	mov	x1, x23
    7368:	aa1403e0 	mov	x0, x20
    736c:	d2800042 	mov	x2, #0x2                   	// #2
    7370:	97fff028 	bl	3410 <buf_put>
    7374:	17ffffeb 	b	7320 <fwp_write+0x13c>
    7378:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    737c:	9122e021 	add	x1, x1, #0x8b8
    7380:	d28000c2 	mov	x2, #0x6                   	// #6
    7384:	aa1403e0 	mov	x0, x20
    7388:	91004273 	add	x19, x19, #0x10
    738c:	97fff021 	bl	3410 <buf_put>
    7390:	aa1303e0 	mov	x0, x19
    7394:	97ffecdf 	bl	2710 <strlen@plt>
    7398:	aa1303e1 	mov	x1, x19
    739c:	aa0003e2 	mov	x2, x0
    73a0:	aa1403e0 	mov	x0, x20
    73a4:	97fff01b 	bl	3410 <buf_put>
    73a8:	528007c3 	mov	w3, #0x3e                  	// #62
    73ac:	aa1403e0 	mov	x0, x20
    73b0:	91001fe1 	add	x1, sp, #0x7
    73b4:	d2800022 	mov	x2, #0x1                   	// #1
    73b8:	39001fe3 	strb	w3, [sp, #7]
    73bc:	17ffffb1 	b	7280 <fwp_write+0x9c>
    73c0:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    73c4:	f947f400 	ldr	x0, [x0, #4072]
    73c8:	f94127e2 	ldr	x2, [sp, #584]
    73cc:	f9400001 	ldr	x1, [x0]
    73d0:	eb010042 	subs	x2, x2, x1
    73d4:	d2800001 	mov	x1, #0x0                   	// #0
    73d8:	540034c1 	b.ne	7a70 <fwp_write+0x88c>  // b.any
    73dc:	f9413bf5 	ldr	x21, [sp, #624]
    73e0:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    73e4:	f9413ff6 	ldr	x22, [sp, #632]
    73e8:	aa1403e0 	mov	x0, x20
    73ec:	91226021 	add	x1, x1, #0x898
    73f0:	d2800142 	mov	x2, #0xa                   	// #10
    73f4:	f94153fb 	ldr	x27, [sp, #672]
    73f8:	f94157fc 	ldr	x28, [sp, #680]
    73fc:	910943ff 	add	sp, sp, #0x250
    7400:	a94153f3 	ldp	x19, x20, [sp, #16]
    7404:	a8c77bfd 	ldp	x29, x30, [sp], #112
    7408:	17fff002 	b	3410 <buf_put>
    740c:	f9400456 	ldr	x22, [x2, #8]
    7410:	f90143f7 	str	x23, [sp, #640]
    7414:	f90147f8 	str	x24, [sp, #648]
    7418:	b4005af6 	cbz	x22, 7f74 <fwp_write+0xd90>
    741c:	aa1603e0 	mov	x0, x22
    7420:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7424:	91246021 	add	x1, x1, #0x918
    7428:	97ffed36 	bl	2900 <strcmp@plt>
    742c:	2a0003f5 	mov	w21, w0
    7430:	34005fc0 	cbz	w0, 8028 <fwp_write+0xe44>
    7434:	aa1603e0 	mov	x0, x22
    7438:	97ffecb6 	bl	2710 <strlen@plt>
    743c:	aa1603e1 	mov	x1, x22
    7440:	aa0003e2 	mov	x2, x0
    7444:	aa1403e0 	mov	x0, x20
    7448:	97ffeff2 	bl	3410 <buf_put>
    744c:	52800403 	mov	w3, #0x20                  	// #32
    7450:	91001ff5 	add	x21, sp, #0x7
    7454:	aa1503e1 	mov	x1, x21
    7458:	aa1403e0 	mov	x0, x20
    745c:	d2800022 	mov	x2, #0x1                   	// #1
    7460:	39001fe3 	strb	w3, [sp, #7]
    7464:	97ffefeb 	bl	3410 <buf_put>
    7468:	52800f63 	mov	w3, #0x7b                  	// #123
    746c:	aa1403e0 	mov	x0, x20
    7470:	aa1503e1 	mov	x1, x21
    7474:	d2800022 	mov	x2, #0x1                   	// #1
    7478:	39001fe3 	strb	w3, [sp, #7]
    747c:	97ffefe5 	bl	3410 <buf_put>
    7480:	b9401380 	ldr	w0, [x28, #16]
    7484:	52800018 	mov	w24, #0x0                   	// #0
    7488:	7100001f 	cmp	w0, #0x0
    748c:	54003a8d 	b.le	7bdc <fwp_write+0x9f8>
    7490:	f9014bf9 	str	x25, [sp, #656]
    7494:	d0000019 	adrp	x25, 9000 <__divti3+0x2c0>
    7498:	91250339 	add	x25, x25, #0x940
    749c:	f9014ffa 	str	x26, [sp, #664]
    74a0:	d000001a 	adrp	x26, 9000 <__divti3+0x2c0>
    74a4:	9124035a 	add	x26, x26, #0x900
    74a8:	91002276 	add	x22, x19, #0x8
    74ac:	d2800013 	mov	x19, #0x0                   	// #0
    74b0:	b5003e73 	cbnz	x19, 7c7c <fwp_write+0xa98>
    74b4:	d37df277 	lsl	x23, x19, #3
    74b8:	34003c98 	cbz	w24, 7c48 <fwp_write+0xa64>
    74bc:	f9401382 	ldr	x2, [x28, #32]
    74c0:	aa1403e0 	mov	x0, x20
    74c4:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    74c8:	52800003 	mov	w3, #0x0                   	// #0
    74cc:	f8776842 	ldr	x2, [x2, x23]
    74d0:	91000673 	add	x19, x19, #0x1
    74d4:	97ffff44 	bl	71e4 <fwp_write>
    74d8:	b9401380 	ldr	w0, [x28, #16]
    74dc:	6b13001f 	cmp	w0, w19
    74e0:	54fffe8c 	b.gt	74b0 <fwp_write+0x2cc>
    74e4:	f9414bf9 	ldr	x25, [sp, #656]
    74e8:	f9414ffa 	ldr	x26, [sp, #664]
    74ec:	34003798 	cbz	w24, 7bdc <fwp_write+0x9f8>
    74f0:	52800523 	mov	w3, #0x29                  	// #41
    74f4:	aa1503e1 	mov	x1, x21
    74f8:	aa1403e0 	mov	x0, x20
    74fc:	d2800022 	mov	x2, #0x1                   	// #1
    7500:	39001fe3 	strb	w3, [sp, #7]
    7504:	97ffefc3 	bl	3410 <buf_put>
    7508:	f9413bf5 	ldr	x21, [sp, #624]
    750c:	f9413ff6 	ldr	x22, [sp, #632]
    7510:	f94143f7 	ldr	x23, [sp, #640]
    7514:	f94147f8 	ldr	x24, [sp, #648]
    7518:	f94153fb 	ldr	x27, [sp, #672]
    751c:	f94157fc 	ldr	x28, [sp, #680]
    7520:	17ffff5d 	b	7294 <fwp_write+0xb0>
    7524:	b9404855 	ldr	w21, [x2, #72]
    7528:	aa1403e0 	mov	x0, x20
    752c:	93407eb6 	sxtw	x22, w21
    7530:	91000ac1 	add	x1, x22, #0x2
    7534:	97ffef84 	bl	3344 <buf_grow>
    7538:	a9400281 	ldp	x1, x0, [x20]
    753c:	528e8603 	mov	w3, #0x7430                	// #29744
    7540:	78206823 	strh	w3, [x1, x0]
    7544:	8b000022 	add	x2, x1, x0
    7548:	710002bf 	cmp	w21, #0x0
    754c:	540036ad 	b.le	7c20 <fwp_write+0xa3c>
    7550:	110006a3 	add	w3, w21, #0x1
    7554:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    7558:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    755c:	91000449 	add	x9, x2, #0x1
    7560:	8b23c043 	add	x3, x2, w3, sxtw
    7564:	f28aaac6 	movk	x6, #0x5556
    7568:	f2955568 	movk	x8, #0xaaab
    756c:	1400000d 	b	75a0 <fwp_write+0x3bc>
    7570:	d2800021 	mov	x1, #0x1                   	// #1
    7574:	528005a5 	mov	w5, #0x2d                  	// #45
    7578:	f100001f 	cmp	x0, #0x0
    757c:	9b467e60 	smulh	x0, x19, x6
    7580:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    7584:	381ff465 	strb	w5, [x3], #-1
    7588:	cb040000 	sub	x0, x0, x4
    758c:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    7590:	cb020000 	sub	x0, x0, x2
    7594:	8b010013 	add	x19, x0, x1
    7598:	eb03013f 	cmp	x9, x3
    759c:	54003420 	b.eq	7c20 <fwp_write+0xa3c>  // b.none
    75a0:	9b467e60 	smulh	x0, x19, x6
    75a4:	937ffe64 	asr	x4, x19, #63
    75a8:	52800605 	mov	w5, #0x30                  	// #48
    75ac:	cb040000 	sub	x0, x0, x4
    75b0:	8b000400 	add	x0, x0, x0, lsl #1
    75b4:	cb000260 	sub	x0, x19, x0
    75b8:	91000c01 	add	x1, x0, #0x3
    75bc:	9bc87c22 	umulh	x2, x1, x8
    75c0:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    75c4:	8b4204e2 	add	x2, x7, x2, lsr #1
    75c8:	eb020021 	subs	x1, x1, x2
    75cc:	54fffd60 	b.eq	7578 <fwp_write+0x394>  // b.none
    75d0:	f100043f 	cmp	x1, #0x1
    75d4:	54fffce1 	b.ne	7570 <fwp_write+0x38c>  // b.any
    75d8:	d2800001 	mov	x1, #0x0                   	// #0
    75dc:	52800565 	mov	w5, #0x2b                  	// #43
    75e0:	17ffffe6 	b	7578 <fwp_write+0x394>
    75e4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    75e8:	f947f400 	ldr	x0, [x0, #4072]
    75ec:	f94127e2 	ldr	x2, [sp, #584]
    75f0:	f9400001 	ldr	x1, [x0]
    75f4:	eb010042 	subs	x2, x2, x1
    75f8:	d2800001 	mov	x1, #0x0                   	// #0
    75fc:	540023a1 	b.ne	7a70 <fwp_write+0x88c>  // b.any
    7600:	f9413bf5 	ldr	x21, [sp, #624]
    7604:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7608:	f9413ff6 	ldr	x22, [sp, #632]
    760c:	aa1403e0 	mov	x0, x20
    7610:	9122a021 	add	x1, x1, #0x8a8
    7614:	d2800102 	mov	x2, #0x8                   	// #8
    7618:	17ffff77 	b	73f4 <fwp_write+0x210>
    761c:	aa1403e0 	mov	x0, x20
    7620:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7624:	d28000c2 	mov	x2, #0x6                   	// #6
    7628:	91242021 	add	x1, x1, #0x908
    762c:	97ffef79 	bl	3410 <buf_put>
    7630:	d2800015 	mov	x21, #0x0                   	// #0
    7634:	f9400263 	ldr	x3, [x19]
    7638:	f240f87f 	tst	x3, #0x7fffffffffffffff
    763c:	54002c40 	b.eq	7bc4 <fwp_write+0x9e0>  // b.none
    7640:	f9401f82 	ldr	x2, [x28, #56]
    7644:	f90143f7 	str	x23, [sp, #640]
    7648:	f90147f8 	str	x24, [sp, #648]
    764c:	d2800857 	mov	x23, #0x42                  	// #66
    7650:	f9014bf9 	str	x25, [sp, #656]
    7654:	d0000016 	adrp	x22, 9000 <__divti3+0x2c0>
    7658:	f9014ffa 	str	x26, [sp, #664]
    765c:	912402d6 	add	x22, x22, #0x900
    7660:	d2800038 	mov	x24, #0x1                   	// #1
    7664:	f2a18017 	movk	x23, #0xc00, lsl #16
    7668:	d2809099 	mov	x25, #0x484                 	// #1156
    766c:	b4000482 	cbz	x2, 76fc <fwp_write+0x518>
    7670:	b9400040 	ldr	w0, [x2]
    7674:	7100701f 	cmp	w0, #0x1c
    7678:	540042a0 	b.eq	7ecc <fwp_write+0xce8>  // b.none
    767c:	71006c1f 	cmp	w0, #0x1b
    7680:	540003e8 	b.hi	76fc <fwp_write+0x518>  // b.pmore
    7684:	9ac02301 	lsl	x1, x24, x0
    7688:	ea17003f 	tst	x1, x23
    768c:	54003681 	b.ne	7d5c <fwp_write+0xb78>  // b.any
    7690:	ea19003f 	tst	x1, x25
    7694:	54003501 	b.ne	7d34 <fwp_write+0xb50>  // b.any
    7698:	d2800424 	mov	x4, #0x21                  	// #33
    769c:	ea04003f 	tst	x1, x4
    76a0:	540002e0 	b.eq	76fc <fwp_write+0x518>  // b.none
    76a4:	b7f849a3 	tbnz	x3, #63, 7fd8 <fwp_write+0xdf4>
    76a8:	91002261 	add	x1, x19, #0x8
    76ac:	8b150021 	add	x1, x1, x21
    76b0:	39400021 	ldrb	w1, [x1]
    76b4:	7100001f 	cmp	w0, #0x0
    76b8:	93401c23 	sxtb	x3, w1
    76bc:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    76c0:	aa1403e0 	mov	x0, x20
    76c4:	52800003 	mov	w3, #0x0                   	// #0
    76c8:	97fffec7 	bl	71e4 <fwp_write>
    76cc:	910006b5 	add	x21, x21, #0x1
    76d0:	f9400260 	ldr	x0, [x19]
    76d4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    76d8:	eb0002bf 	cmp	x21, x0
    76dc:	540026c2 	b.cs	7bb4 <fwp_write+0x9d0>  // b.hs, b.nlast
    76e0:	d2800042 	mov	x2, #0x2                   	// #2
    76e4:	aa1603e1 	mov	x1, x22
    76e8:	aa1403e0 	mov	x0, x20
    76ec:	97ffef49 	bl	3410 <buf_put>
    76f0:	f9401f82 	ldr	x2, [x28, #56]
    76f4:	f9400263 	ldr	x3, [x19]
    76f8:	b5fffbc2 	cbnz	x2, 7670 <fwp_write+0x48c>
    76fc:	d37df2a0 	lsl	x0, x21, #3
    7700:	b7f83f03 	tbnz	x3, #63, 7ee0 <fwp_write+0xcfc>
    7704:	91002261 	add	x1, x19, #0x8
    7708:	8b000020 	add	x0, x1, x0
    770c:	f9400001 	ldr	x1, [x0]
    7710:	17ffffec 	b	76c0 <fwp_write+0x4dc>
    7714:	a9400e62 	ldp	x2, x3, [x19]
    7718:	b7f83ca3 	tbnz	x3, #63, 7eac <fwp_write+0xcc8>
    771c:	910123f5 	add	x21, sp, #0x48
    7720:	aa1503e0 	mov	x0, x21
    7724:	97ffedbf 	bl	2e20 <fwp_fmt_u128>
    7728:	aa1503e0 	mov	x0, x21
    772c:	97ffebf9 	bl	2710 <strlen@plt>
    7730:	aa1503e1 	mov	x1, x21
    7734:	aa0003e2 	mov	x2, x0
    7738:	17fffed1 	b	727c <fwp_write+0x98>
    773c:	fd015be8 	str	d8, [sp, #688]
    7740:	1e270268 	fmov	s8, w19
    7744:	fd015fe9 	str	d9, [sp, #696]
    7748:	1e282100 	fcmp	s8, s8
    774c:	54004d26 	b.vs	80f0 <fwp_write+0xf0c>
    7750:	1e20c101 	fabs	s1, s8
    7754:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    7758:	1e270000 	fmov	s0, w0
    775c:	1e202020 	fcmp	s1, s0
    7760:	54002c0d 	b.le	7ce0 <fwp_write+0xafc>
    7764:	1e202118 	fcmpe	s8, #0.0
    7768:	d0000002 	adrp	x2, 9000 <__divti3+0x2c0>
    776c:	91120042 	add	x2, x2, #0x480
    7770:	910123f5 	add	x21, sp, #0x48
    7774:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7778:	91216021 	add	x1, x1, #0x858
    777c:	aa1503e0 	mov	x0, x21
    7780:	9a81c041 	csel	x1, x2, x1, gt
    7784:	97ffec8f 	bl	29c0 <strcpy@plt>
    7788:	aa1503e0 	mov	x0, x21
    778c:	97ffebe1 	bl	2710 <strlen@plt>
    7790:	aa1503e1 	mov	x1, x21
    7794:	aa0003e2 	mov	x2, x0
    7798:	aa1403e0 	mov	x0, x20
    779c:	97ffef1d 	bl	3410 <buf_put>
    77a0:	f9413bf5 	ldr	x21, [sp, #624]
    77a4:	f9413ff6 	ldr	x22, [sp, #632]
    77a8:	f94153fb 	ldr	x27, [sp, #672]
    77ac:	f94157fc 	ldr	x28, [sp, #680]
    77b0:	fd415be8 	ldr	d8, [sp, #688]
    77b4:	fd415fe9 	ldr	d9, [sp, #696]
    77b8:	17fffeb7 	b	7294 <fwp_write+0xb0>
    77bc:	f9400276 	ldr	x22, [x19]
    77c0:	34002e03 	cbz	w3, 7d80 <fwp_write+0xb9c>
    77c4:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    77c8:	f947f400 	ldr	x0, [x0, #4072]
    77cc:	f94127e2 	ldr	x2, [sp, #584]
    77d0:	f9400001 	ldr	x1, [x0]
    77d4:	eb010042 	subs	x2, x2, x1
    77d8:	d2800001 	mov	x1, #0x0                   	// #0
    77dc:	540014a1 	b.ne	7a70 <fwp_write+0x88c>  // b.any
    77e0:	aa1603e2 	mov	x2, x22
    77e4:	91002261 	add	x1, x19, #0x8
    77e8:	f9413bf5 	ldr	x21, [sp, #624]
    77ec:	aa1403e0 	mov	x0, x20
    77f0:	f9413ff6 	ldr	x22, [sp, #632]
    77f4:	17ffff00 	b	73f4 <fwp_write+0x210>
    77f8:	fd015be8 	str	d8, [sp, #688]
    77fc:	9e670268 	fmov	d8, x19
    7800:	fd015fe9 	str	d9, [sp, #696]
    7804:	1e682100 	fcmp	d8, d8
    7808:	54004746 	b.vs	80f0 <fwp_write+0xf0c>
    780c:	1e60c101 	fabs	d1, d8
    7810:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    7814:	9e670000 	fmov	d0, x0
    7818:	910123f5 	add	x21, sp, #0x48
    781c:	52800033 	mov	w19, #0x1                   	// #1
    7820:	1e602020 	fcmp	d1, d0
    7824:	540001ad 	b.le	7858 <fwp_write+0x674>
    7828:	1e602118 	fcmpe	d8, #0.0
    782c:	d0000002 	adrp	x2, 9000 <__divti3+0x2c0>
    7830:	91120042 	add	x2, x2, #0x480
    7834:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7838:	91216021 	add	x1, x1, #0x858
    783c:	aa1503e0 	mov	x0, x21
    7840:	9a81c041 	csel	x1, x2, x1, gt
    7844:	97ffec5f 	bl	29c0 <strcpy@plt>
    7848:	17ffffd0 	b	7788 <fwp_write+0x5a4>
    784c:	11000673 	add	w19, w19, #0x1
    7850:	71004a7f 	cmp	w19, #0x12
    7854:	54003860 	b.eq	7f60 <fwp_write+0xd7c>  // b.none
    7858:	1e604100 	fmov	d0, d8
    785c:	2a1303e1 	mov	w1, w19
    7860:	aa1503e0 	mov	x0, x21
    7864:	97ffef47 	bl	3580 <fwp_format_g.constprop.0>
    7868:	aa1503e0 	mov	x0, x21
    786c:	d2800001 	mov	x1, #0x0                   	// #0
    7870:	97ffebbc 	bl	2760 <strtod@plt>
    7874:	1e602100 	fcmp	d8, d0
    7878:	54fffea1 	b.ne	784c <fwp_write+0x668>  // b.any
    787c:	aa1503e0 	mov	x0, x21
    7880:	97ffef1d 	bl	34f4 <fwp_finish_float>
    7884:	17ffffc1 	b	7788 <fwp_write+0x5a4>
    7888:	a9400e62 	ldp	x2, x3, [x19]
    788c:	910123f3 	add	x19, sp, #0x48
    7890:	aa1303e0 	mov	x0, x19
    7894:	97ffed63 	bl	2e20 <fwp_fmt_u128>
    7898:	17fffe75 	b	726c <fwp_write+0x88>
    789c:	f90143f7 	str	x23, [sp, #640]
    78a0:	f90147f8 	str	x24, [sp, #648]
    78a4:	2a1303f8 	mov	w24, w19
    78a8:	f9014bf9 	str	x25, [sp, #656]
    78ac:	f9014ffa 	str	x26, [sp, #664]
    78b0:	f13ffe7f 	cmp	x19, #0xfff
    78b4:	54000049 	b.ls	78bc <fwp_write+0x6d8>  // b.plast
    78b8:	b9400278 	ldr	w24, [x19]
    78bc:	f9400f80 	ldr	x0, [x28, #24]
    78c0:	2a1803f5 	mov	w21, w24
    78c4:	d37d7f18 	ubfiz	x24, x24, #3, #32
    78c8:	d37ef6b9 	lsl	x25, x21, #2
    78cc:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    78d0:	aa1603e0 	mov	x0, x22
    78d4:	97ffeb8f 	bl	2710 <strlen@plt>
    78d8:	aa1603e1 	mov	x1, x22
    78dc:	aa0003e2 	mov	x2, x0
    78e0:	aa1403e0 	mov	x0, x20
    78e4:	97ffeecb 	bl	3410 <buf_put>
    78e8:	f9401780 	ldr	x0, [x28, #40]
    78ec:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    78f0:	7100001f 	cmp	w0, #0x0
    78f4:	5400068d 	b.le	79c4 <fwp_write+0x7e0>
    78f8:	91002276 	add	x22, x19, #0x8
    78fc:	91001ff5 	add	x21, sp, #0x7
    7900:	d280001b 	mov	x27, #0x0                   	// #0
    7904:	5280041a 	mov	w26, #0x20                  	// #32
    7908:	f9401b80 	ldr	x0, [x28, #48]
    790c:	aa1503e1 	mov	x1, x21
    7910:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    7914:	d2800022 	mov	x2, #0x1                   	// #1
    7918:	f8786803 	ldr	x3, [x0, x24]
    791c:	aa1403e0 	mov	x0, x20
    7920:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    7924:	39001ffa 	strb	w26, [sp, #7]
    7928:	97ffeeba 	bl	3410 <buf_put>
    792c:	f13ffeff 	cmp	x23, #0xfff
    7930:	b9400261 	ldr	w1, [x19]
    7934:	1a9f97e0 	cset	w0, hi	// hi = pmore
    7938:	7100383f 	cmp	w1, #0xe
    793c:	54000160 	b.eq	7968 <fwp_write+0x784>  // b.none
    7940:	7100403f 	cmp	w1, #0x10
    7944:	54001a60 	b.eq	7c90 <fwp_write+0xaac>  // b.none
    7948:	7100283f 	cmp	w1, #0xa
    794c:	54002aa0 	b.eq	7ea0 <fwp_write+0xcbc>  // b.none
    7950:	540014ac 	b.gt	7be4 <fwp_write+0xa00>
    7954:	71000c3f 	cmp	w1, #0x3
    7958:	540029ac 	b.gt	7e8c <fwp_write+0xca8>
    795c:	d37ffee0 	lsr	x0, x23, #63
    7960:	37f814a1 	tbnz	w1, #31, 7bf4 <fwp_write+0xa10>
    7964:	d503201f 	nop
    7968:	34001460 	cbz	w0, 7bf4 <fwp_write+0xa10>
    796c:	52800503 	mov	w3, #0x28                  	// #40
    7970:	aa1503e1 	mov	x1, x21
    7974:	aa1403e0 	mov	x0, x20
    7978:	d2800022 	mov	x2, #0x1                   	// #1
    797c:	39001fe3 	strb	w3, [sp, #7]
    7980:	97ffeea4 	bl	3410 <buf_put>
    7984:	aa1303e2 	mov	x2, x19
    7988:	aa1703e1 	mov	x1, x23
    798c:	aa1403e0 	mov	x0, x20
    7990:	52800003 	mov	w3, #0x0                   	// #0
    7994:	97fffe14 	bl	71e4 <fwp_write>
    7998:	52800523 	mov	w3, #0x29                  	// #41
    799c:	aa1503e1 	mov	x1, x21
    79a0:	aa1403e0 	mov	x0, x20
    79a4:	d2800022 	mov	x2, #0x1                   	// #1
    79a8:	39001fe3 	strb	w3, [sp, #7]
    79ac:	97ffee99 	bl	3410 <buf_put>
    79b0:	f9401780 	ldr	x0, [x28, #40]
    79b4:	9100077b 	add	x27, x27, #0x1
    79b8:	b8796800 	ldr	w0, [x0, x25]
    79bc:	6b1b001f 	cmp	w0, w27
    79c0:	54fffa4c 	b.gt	7908 <fwp_write+0x724>
    79c4:	f9413bf5 	ldr	x21, [sp, #624]
    79c8:	f9413ff6 	ldr	x22, [sp, #632]
    79cc:	f94143f7 	ldr	x23, [sp, #640]
    79d0:	f94147f8 	ldr	x24, [sp, #648]
    79d4:	f9414bf9 	ldr	x25, [sp, #656]
    79d8:	f9414ffa 	ldr	x26, [sp, #664]
    79dc:	f94153fb 	ldr	x27, [sp, #672]
    79e0:	f94157fc 	ldr	x28, [sp, #680]
    79e4:	17fffe2c 	b	7294 <fwp_write+0xb0>
    79e8:	52800783 	mov	w3, #0x3c                  	// #60
    79ec:	91001ff3 	add	x19, sp, #0x7
    79f0:	aa1303e1 	mov	x1, x19
    79f4:	d2800022 	mov	x2, #0x1                   	// #1
    79f8:	aa1403e0 	mov	x0, x20
    79fc:	39001fe3 	strb	w3, [sp, #7]
    7a00:	97ffee84 	bl	3410 <buf_put>
    7a04:	f9400795 	ldr	x21, [x28, #8]
    7a08:	aa1503e0 	mov	x0, x21
    7a0c:	97ffeb41 	bl	2710 <strlen@plt>
    7a10:	aa1503e1 	mov	x1, x21
    7a14:	aa0003e2 	mov	x2, x0
    7a18:	aa1403e0 	mov	x0, x20
    7a1c:	97ffee7d 	bl	3410 <buf_put>
    7a20:	528007c3 	mov	w3, #0x3e                  	// #62
    7a24:	aa1303e1 	mov	x1, x19
    7a28:	aa1403e0 	mov	x0, x20
    7a2c:	d2800022 	mov	x2, #0x1                   	// #1
    7a30:	39001fe3 	strb	w3, [sp, #7]
    7a34:	17fffe13 	b	7280 <fwp_write+0x9c>
    7a38:	f100067f 	cmp	x19, #0x1
    7a3c:	540025a0 	b.eq	7ef0 <fwp_write+0xd0c>  // b.none
    7a40:	b100067f 	cmn	x19, #0x1
    7a44:	54002bc0 	b.eq	7fbc <fwp_write+0xdd8>  // b.none
    7a48:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7a4c:	91218021 	add	x1, x1, #0x860
    7a50:	d2800022 	mov	x2, #0x1                   	// #1
    7a54:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7a58:	f947f400 	ldr	x0, [x0, #4072]
    7a5c:	f94127e4 	ldr	x4, [sp, #584]
    7a60:	f9400003 	ldr	x3, [x0]
    7a64:	eb030084 	subs	x4, x4, x3
    7a68:	d2800003 	mov	x3, #0x0                   	// #0
    7a6c:	54ffebe0 	b.eq	77e8 <fwp_write+0x604>  // b.none
    7a70:	f90143f7 	str	x23, [sp, #640]
    7a74:	f90147f8 	str	x24, [sp, #648]
    7a78:	f9014bf9 	str	x25, [sp, #656]
    7a7c:	f9014ffa 	str	x26, [sp, #664]
    7a80:	fd015be8 	str	d8, [sp, #688]
    7a84:	fd015fe9 	str	d9, [sp, #696]
    7a88:	97ffeb7e 	bl	2880 <__stack_chk_fail@plt>
    7a8c:	52800b63 	mov	w3, #0x5b                  	// #91
    7a90:	91001ff5 	add	x21, sp, #0x7
    7a94:	aa1503e1 	mov	x1, x21
    7a98:	aa1403e0 	mov	x0, x20
    7a9c:	d2800022 	mov	x2, #0x1                   	// #1
    7aa0:	d0000016 	adrp	x22, 9000 <__divti3+0x2c0>
    7aa4:	912402d6 	add	x22, x22, #0x900
    7aa8:	39001fe3 	strb	w3, [sp, #7]
    7aac:	97ffee59 	bl	3410 <buf_put>
    7ab0:	b4000273 	cbz	x19, 7afc <fwp_write+0x918>
    7ab4:	f9400661 	ldr	x1, [x19, #8]
    7ab8:	aa1403e0 	mov	x0, x20
    7abc:	f9401f82 	ldr	x2, [x28, #56]
    7ac0:	52800003 	mov	w3, #0x0                   	// #0
    7ac4:	97fffdc8 	bl	71e4 <fwp_write>
    7ac8:	f9400a73 	ldr	x19, [x19, #16]
    7acc:	b4000193 	cbz	x19, 7afc <fwp_write+0x918>
    7ad0:	aa1603e1 	mov	x1, x22
    7ad4:	aa1403e0 	mov	x0, x20
    7ad8:	d2800042 	mov	x2, #0x2                   	// #2
    7adc:	97ffee4d 	bl	3410 <buf_put>
    7ae0:	f9400661 	ldr	x1, [x19, #8]
    7ae4:	aa1403e0 	mov	x0, x20
    7ae8:	f9401f82 	ldr	x2, [x28, #56]
    7aec:	52800003 	mov	w3, #0x0                   	// #0
    7af0:	97fffdbd 	bl	71e4 <fwp_write>
    7af4:	f9400a73 	ldr	x19, [x19, #16]
    7af8:	b5fffed3 	cbnz	x19, 7ad0 <fwp_write+0x8ec>
    7afc:	52800ba3 	mov	w3, #0x5d                  	// #93
    7b00:	aa1503e1 	mov	x1, x21
    7b04:	aa1403e0 	mov	x0, x20
    7b08:	d2800022 	mov	x2, #0x1                   	// #1
    7b0c:	39001fe3 	strb	w3, [sp, #7]
    7b10:	17fffddc 	b	7280 <fwp_write+0x9c>
    7b14:	aa1403e0 	mov	x0, x20
    7b18:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7b1c:	d28000c2 	mov	x2, #0x6                   	// #6
    7b20:	9123c021 	add	x1, x1, #0x8f0
    7b24:	97ffee3b 	bl	3410 <buf_put>
    7b28:	f9400260 	ldr	x0, [x19]
    7b2c:	b40004c0 	cbz	x0, 7bc4 <fwp_write+0x9e0>
    7b30:	910123f5 	add	x21, sp, #0x48
    7b34:	91002276 	add	x22, x19, #0x8
    7b38:	f90143f7 	str	x23, [sp, #640]
    7b3c:	d2800017 	mov	x23, #0x0                   	// #0
    7b40:	f90147f8 	str	x24, [sp, #648]
    7b44:	d0000018 	adrp	x24, 9000 <__divti3+0x2c0>
    7b48:	9123e318 	add	x24, x24, #0x8f8
    7b4c:	f9014bf9 	str	x25, [sp, #656]
    7b50:	d0000019 	adrp	x25, 9000 <__divti3+0x2c0>
    7b54:	91240339 	add	x25, x25, #0x900
    7b58:	f9014ffa 	str	x26, [sp, #664]
    7b5c:	14000005 	b	7b70 <fwp_write+0x98c>
    7b60:	aa1903e1 	mov	x1, x25
    7b64:	aa1403e0 	mov	x0, x20
    7b68:	d2800042 	mov	x2, #0x2                   	// #2
    7b6c:	97ffee29 	bl	3410 <buf_put>
    7b70:	38776ac5 	ldrb	w5, [x22, x23]
    7b74:	d2804003 	mov	x3, #0x200                 	// #512
    7b78:	aa1803e4 	mov	x4, x24
    7b7c:	aa0303e1 	mov	x1, x3
    7b80:	52800042 	mov	w2, #0x2                   	// #2
    7b84:	aa1503e0 	mov	x0, x21
    7b88:	910006f7 	add	x23, x23, #0x1
    7b8c:	97ffeb19 	bl	27f0 <__snprintf_chk@plt>
    7b90:	aa1503e0 	mov	x0, x21
    7b94:	97ffeadf 	bl	2710 <strlen@plt>
    7b98:	aa1503e1 	mov	x1, x21
    7b9c:	aa0003e2 	mov	x2, x0
    7ba0:	aa1403e0 	mov	x0, x20
    7ba4:	97ffee1b 	bl	3410 <buf_put>
    7ba8:	f9400260 	ldr	x0, [x19]
    7bac:	eb17001f 	cmp	x0, x23
    7bb0:	54fffd88 	b.hi	7b60 <fwp_write+0x97c>  // b.pmore
    7bb4:	f94143f7 	ldr	x23, [sp, #640]
    7bb8:	f94147f8 	ldr	x24, [sp, #648]
    7bbc:	f9414bf9 	ldr	x25, [sp, #656]
    7bc0:	f9414ffa 	ldr	x26, [sp, #664]
    7bc4:	52800ba3 	mov	w3, #0x5d                  	// #93
    7bc8:	aa1403e0 	mov	x0, x20
    7bcc:	91001fe1 	add	x1, sp, #0x7
    7bd0:	d2800022 	mov	x2, #0x1                   	// #1
    7bd4:	39001fe3 	strb	w3, [sp, #7]
    7bd8:	17fffdaa 	b	7280 <fwp_write+0x9c>
    7bdc:	52800fa3 	mov	w3, #0x7d                  	// #125
    7be0:	17fffe45 	b	74f4 <fwp_write+0x310>
    7be4:	f10002ff 	cmp	x23, #0x0
    7be8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7bec:	71002c3f 	cmp	w1, #0xb
    7bf0:	54ffebc0 	b.eq	7968 <fwp_write+0x784>  // b.none
    7bf4:	aa1303e2 	mov	x2, x19
    7bf8:	aa1703e1 	mov	x1, x23
    7bfc:	aa1403e0 	mov	x0, x20
    7c00:	52800003 	mov	w3, #0x0                   	// #0
    7c04:	97fffd78 	bl	71e4 <fwp_write>
    7c08:	17ffff6a 	b	79b0 <fwp_write+0x7cc>
    7c0c:	aa1403e0 	mov	x0, x20
    7c10:	91001fe1 	add	x1, sp, #0x7
    7c14:	52800fa3 	mov	w3, #0x7d                  	// #125
    7c18:	d2800022 	mov	x2, #0x1                   	// #1
    7c1c:	17fffe39 	b	7500 <fwp_write+0x31c>
    7c20:	a9400281 	ldp	x1, x0, [x20]
    7c24:	91000800 	add	x0, x0, #0x2
    7c28:	8b160000 	add	x0, x0, x22
    7c2c:	f9000680 	str	x0, [x20, #8]
    7c30:	3820683f 	strb	wzr, [x1, x0]
    7c34:	f9413bf5 	ldr	x21, [sp, #624]
    7c38:	f9413ff6 	ldr	x22, [sp, #632]
    7c3c:	f94153fb 	ldr	x27, [sp, #672]
    7c40:	f94157fc 	ldr	x28, [sp, #680]
    7c44:	17fffd94 	b	7294 <fwp_write+0xb0>
    7c48:	f9400f80 	ldr	x0, [x28, #24]
    7c4c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    7c50:	aa1b03e0 	mov	x0, x27
    7c54:	97ffeaaf 	bl	2710 <strlen@plt>
    7c58:	aa1b03e1 	mov	x1, x27
    7c5c:	aa0003e2 	mov	x2, x0
    7c60:	aa1403e0 	mov	x0, x20
    7c64:	97ffedeb 	bl	3410 <buf_put>
    7c68:	aa1903e1 	mov	x1, x25
    7c6c:	aa1403e0 	mov	x0, x20
    7c70:	d2800062 	mov	x2, #0x3                   	// #3
    7c74:	97ffede7 	bl	3410 <buf_put>
    7c78:	17fffe11 	b	74bc <fwp_write+0x2d8>
    7c7c:	aa1a03e1 	mov	x1, x26
    7c80:	aa1403e0 	mov	x0, x20
    7c84:	d2800042 	mov	x2, #0x2                   	// #2
    7c88:	97ffede2 	bl	3410 <buf_put>
    7c8c:	17fffe0a 	b	74b4 <fwp_write+0x2d0>
    7c90:	f9400660 	ldr	x0, [x19, #8]
    7c94:	b4fffb00 	cbz	x0, 7bf4 <fwp_write+0xa10>
    7c98:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7c9c:	91246021 	add	x1, x1, #0x918
    7ca0:	97ffeb18 	bl	2900 <strcmp@plt>
    7ca4:	7100001f 	cmp	w0, #0x0
    7ca8:	1a9f07e0 	cset	w0, ne	// ne = any
    7cac:	17ffff2f 	b	7968 <fwp_write+0x784>
    7cb0:	aa1403e0 	mov	x0, x20
    7cb4:	d2800042 	mov	x2, #0x2                   	// #2
    7cb8:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7cbc:	91244021 	add	x1, x1, #0x910
    7cc0:	97ffedd4 	bl	3410 <buf_put>
    7cc4:	91004261 	add	x1, x19, #0x10
    7cc8:	aa1403e0 	mov	x0, x20
    7ccc:	f9402382 	ldr	x2, [x28, #64]
    7cd0:	52800003 	mov	w3, #0x0                   	// #0
    7cd4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    7cd8:	97fffd43 	bl	71e4 <fwp_write>
    7cdc:	17fffd9d 	b	7350 <fwp_write+0x16c>
    7ce0:	1e22c109 	fcvt	d9, s8
    7ce4:	910123f5 	add	x21, sp, #0x48
    7ce8:	52800033 	mov	w19, #0x1                   	// #1
    7cec:	d503201f 	nop
    7cf0:	1e604120 	fmov	d0, d9
    7cf4:	2a1303e1 	mov	w1, w19
    7cf8:	aa1503e0 	mov	x0, x21
    7cfc:	97ffee21 	bl	3580 <fwp_format_g.constprop.0>
    7d00:	aa1503e0 	mov	x0, x21
    7d04:	d2800001 	mov	x1, #0x0                   	// #0
    7d08:	97ffeb0a 	bl	2930 <strtof@plt>
    7d0c:	1e202100 	fcmp	s8, s0
    7d10:	54ffdb60 	b.eq	787c <fwp_write+0x698>  // b.none
    7d14:	11000673 	add	w19, w19, #0x1
    7d18:	71002a7f 	cmp	w19, #0xa
    7d1c:	54fffea1 	b.ne	7cf0 <fwp_write+0xb0c>  // b.any
    7d20:	1e604120 	fmov	d0, d9
    7d24:	aa1503e0 	mov	x0, x21
    7d28:	52800121 	mov	w1, #0x9                   	// #9
    7d2c:	97ffee15 	bl	3580 <fwp_format_g.constprop.0>
    7d30:	17fffed3 	b	787c <fwp_write+0x698>
    7d34:	d37ef6a1 	lsl	x1, x21, #2
    7d38:	b7f81563 	tbnz	x3, #63, 7fe4 <fwp_write+0xe00>
    7d3c:	91002263 	add	x3, x19, #0x8
    7d40:	8b010061 	add	x1, x3, x1
    7d44:	b9400023 	ldr	w3, [x1]
    7d48:	7100081f 	cmp	w0, #0x2
    7d4c:	2a0303e1 	mov	w1, w3
    7d50:	93407c63 	sxtw	x3, w3
    7d54:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d58:	17fffe5a 	b	76c0 <fwp_write+0x4dc>
    7d5c:	d37ffaa1 	lsl	x1, x21, #1
    7d60:	b7f81363 	tbnz	x3, #63, 7fcc <fwp_write+0xde8>
    7d64:	91002263 	add	x3, x19, #0x8
    7d68:	8b010061 	add	x1, x3, x1
    7d6c:	79400021 	ldrh	w1, [x1]
    7d70:	7100041f 	cmp	w0, #0x1
    7d74:	93403c23 	sxth	x3, w1
    7d78:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    7d7c:	17fffe51 	b	76c0 <fwp_write+0x4dc>
    7d80:	52800443 	mov	w3, #0x22                  	// #34
    7d84:	91001ff5 	add	x21, sp, #0x7
    7d88:	91002273 	add	x19, x19, #0x8
    7d8c:	aa1503e1 	mov	x1, x21
    7d90:	aa1403e0 	mov	x0, x20
    7d94:	d2800022 	mov	x2, #0x1                   	// #1
    7d98:	39001fe3 	strb	w3, [sp, #7]
    7d9c:	f90143f7 	str	x23, [sp, #640]
    7da0:	8b160277 	add	x23, x19, x22
    7da4:	f90147f8 	str	x24, [sp, #648]
    7da8:	97ffed9a 	bl	3410 <buf_put>
    7dac:	b4000696 	cbz	x22, 7e7c <fwp_write+0xc98>
    7db0:	d0000018 	adrp	x24, 9000 <__divti3+0x2c0>
    7db4:	91230318 	add	x24, x24, #0x8c0
    7db8:	f9014bf9 	str	x25, [sp, #656]
    7dbc:	d0000019 	adrp	x25, 9000 <__divti3+0x2c0>
    7dc0:	91238339 	add	x25, x25, #0x8e0
    7dc4:	f9014ffa 	str	x26, [sp, #664]
    7dc8:	1400000d 	b	7dfc <fwp_write+0xc18>
    7dcc:	710024bf 	cmp	w5, #0x9
    7dd0:	54000460 	b.eq	7e5c <fwp_write+0xc78>  // b.none
    7dd4:	710028bf 	cmp	w5, #0xa
    7dd8:	54000a61 	b.ne	7f24 <fwp_write+0xd40>  // b.any
    7ddc:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7de0:	aa1403e0 	mov	x0, x20
    7de4:	91234021 	add	x1, x1, #0x8d0
    7de8:	d2800042 	mov	x2, #0x2                   	// #2
    7dec:	97ffed89 	bl	3410 <buf_put>
    7df0:	91000673 	add	x19, x19, #0x1
    7df4:	eb17027f 	cmp	x19, x23
    7df8:	540003e0 	b.eq	7e74 <fwp_write+0xc90>  // b.none
    7dfc:	39400265 	ldrb	w5, [x19]
    7e00:	710034bf 	cmp	w5, #0xd
    7e04:	54000180 	b.eq	7e34 <fwp_write+0xc50>  // b.none
    7e08:	54fffe29 	b.ls	7dcc <fwp_write+0xbe8>  // b.plast
    7e0c:	710088bf 	cmp	w5, #0x22
    7e10:	540001c0 	b.eq	7e48 <fwp_write+0xc64>  // b.none
    7e14:	710170bf 	cmp	w5, #0x5c
    7e18:	54000741 	b.ne	7f00 <fwp_write+0xd1c>  // b.any
    7e1c:	aa1403e0 	mov	x0, x20
    7e20:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7e24:	d2800042 	mov	x2, #0x2                   	// #2
    7e28:	91232021 	add	x1, x1, #0x8c8
    7e2c:	97ffed79 	bl	3410 <buf_put>
    7e30:	17fffff0 	b	7df0 <fwp_write+0xc0c>
    7e34:	aa1903e1 	mov	x1, x25
    7e38:	aa1403e0 	mov	x0, x20
    7e3c:	d2800042 	mov	x2, #0x2                   	// #2
    7e40:	97ffed74 	bl	3410 <buf_put>
    7e44:	17ffffeb 	b	7df0 <fwp_write+0xc0c>
    7e48:	aa1803e1 	mov	x1, x24
    7e4c:	aa1403e0 	mov	x0, x20
    7e50:	d2800042 	mov	x2, #0x2                   	// #2
    7e54:	97ffed6f 	bl	3410 <buf_put>
    7e58:	17ffffe6 	b	7df0 <fwp_write+0xc0c>
    7e5c:	aa1403e0 	mov	x0, x20
    7e60:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7e64:	d2800042 	mov	x2, #0x2                   	// #2
    7e68:	91236021 	add	x1, x1, #0x8d8
    7e6c:	97ffed69 	bl	3410 <buf_put>
    7e70:	17ffffe0 	b	7df0 <fwp_write+0xc0c>
    7e74:	f9414bf9 	ldr	x25, [sp, #656]
    7e78:	f9414ffa 	ldr	x26, [sp, #664]
    7e7c:	aa1503e1 	mov	x1, x21
    7e80:	aa1403e0 	mov	x0, x20
    7e84:	52800443 	mov	w3, #0x22                  	// #34
    7e88:	17fffd9d 	b	74fc <fwp_write+0x318>
    7e8c:	7100103f 	cmp	w1, #0x4
    7e90:	54ffeb21 	b.ne	7bf4 <fwp_write+0xa10>  // b.any
    7e94:	f94006e0 	ldr	x0, [x23, #8]
    7e98:	d37ffc00 	lsr	x0, x0, #63
    7e9c:	17fffeb3 	b	7968 <fwp_write+0x784>
    7ea0:	710002ff 	cmp	w23, #0x0
    7ea4:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    7ea8:	17fffeb0 	b	7968 <fwp_write+0x784>
    7eac:	528005a1 	mov	w1, #0x2d                  	// #45
    7eb0:	eb0203e2 	negs	x2, x2
    7eb4:	da0303e3 	ngc	x3, x3
    7eb8:	910127e0 	add	x0, sp, #0x49
    7ebc:	910123f5 	add	x21, sp, #0x48
    7ec0:	390123e1 	strb	w1, [sp, #72]
    7ec4:	97ffebd7 	bl	2e20 <fwp_fmt_u128>
    7ec8:	17fffe18 	b	7728 <fwp_write+0x544>
    7ecc:	d37ceea1 	lsl	x1, x21, #4
    7ed0:	b7f810a3 	tbnz	x3, #63, 80e4 <fwp_write+0xf00>
    7ed4:	91002260 	add	x0, x19, #0x8
    7ed8:	8b010001 	add	x1, x0, x1
    7edc:	17fffdf9 	b	76c0 <fwp_write+0x4dc>
    7ee0:	f9400a61 	ldr	x1, [x19, #16]
    7ee4:	8b010000 	add	x0, x0, x1
    7ee8:	f9400001 	ldr	x1, [x0]
    7eec:	17fffdf5 	b	76c0 <fwp_write+0x4dc>
    7ef0:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7ef4:	d2800042 	mov	x2, #0x2                   	// #2
    7ef8:	9121a021 	add	x1, x1, #0x868
    7efc:	17fffed6 	b	7a54 <fwp_write+0x870>
    7f00:	7101fcbf 	cmp	w5, #0x7f
    7f04:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    7f08:	540000e9 	b.ls	7f24 <fwp_write+0xd40>  // b.plast
    7f0c:	aa1503e1 	mov	x1, x21
    7f10:	aa1403e0 	mov	x0, x20
    7f14:	d2800022 	mov	x2, #0x1                   	// #1
    7f18:	39001fe5 	strb	w5, [sp, #7]
    7f1c:	97ffed3d 	bl	3410 <buf_put>
    7f20:	17ffffb4 	b	7df0 <fwp_write+0xc0c>
    7f24:	d2800203 	mov	x3, #0x10                  	// #16
    7f28:	d0000004 	adrp	x4, 9000 <__divti3+0x2c0>
    7f2c:	aa0303e1 	mov	x1, x3
    7f30:	9123a084 	add	x4, x4, #0x8e8
    7f34:	910123f6 	add	x22, sp, #0x48
    7f38:	52800042 	mov	w2, #0x2                   	// #2
    7f3c:	aa1603e0 	mov	x0, x22
    7f40:	97ffea2c 	bl	27f0 <__snprintf_chk@plt>
    7f44:	aa1603e0 	mov	x0, x22
    7f48:	97ffe9f2 	bl	2710 <strlen@plt>
    7f4c:	aa1603e1 	mov	x1, x22
    7f50:	aa0003e2 	mov	x2, x0
    7f54:	aa1403e0 	mov	x0, x20
    7f58:	97ffed2e 	bl	3410 <buf_put>
    7f5c:	17ffffa5 	b	7df0 <fwp_write+0xc0c>
    7f60:	1e604100 	fmov	d0, d8
    7f64:	aa1503e0 	mov	x0, x21
    7f68:	52800221 	mov	w1, #0x11                  	// #17
    7f6c:	97ffed85 	bl	3580 <fwp_format_g.constprop.0>
    7f70:	17fffe43 	b	787c <fwp_write+0x698>
    7f74:	b9401040 	ldr	w0, [x2, #16]
    7f78:	350003c0 	cbnz	w0, 7ff0 <fwp_write+0xe0c>
    7f7c:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    7f80:	f947f400 	ldr	x0, [x0, #4072]
    7f84:	f94127e2 	ldr	x2, [sp, #584]
    7f88:	f9400001 	ldr	x1, [x0]
    7f8c:	eb010042 	subs	x2, x2, x1
    7f90:	d2800001 	mov	x1, #0x0                   	// #0
    7f94:	54ffd721 	b.ne	7a78 <fwp_write+0x894>  // b.any
    7f98:	f9413bf5 	ldr	x21, [sp, #624]
    7f9c:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7fa0:	f9413ff6 	ldr	x22, [sp, #632]
    7fa4:	aa1403e0 	mov	x0, x20
    7fa8:	f94143f7 	ldr	x23, [sp, #640]
    7fac:	9124e021 	add	x1, x1, #0x938
    7fb0:	f94147f8 	ldr	x24, [sp, #648]
    7fb4:	d2800042 	mov	x2, #0x2                   	// #2
    7fb8:	17fffd0f 	b	73f4 <fwp_write+0x210>
    7fbc:	d0000001 	adrp	x1, 9000 <__divti3+0x2c0>
    7fc0:	d2800042 	mov	x2, #0x2                   	// #2
    7fc4:	9121c021 	add	x1, x1, #0x870
    7fc8:	17fffea3 	b	7a54 <fwp_write+0x870>
    7fcc:	f9400a63 	ldr	x3, [x19, #16]
    7fd0:	8b030021 	add	x1, x1, x3
    7fd4:	17ffff66 	b	7d6c <fwp_write+0xb88>
    7fd8:	f9400a61 	ldr	x1, [x19, #16]
    7fdc:	8b0102a1 	add	x1, x21, x1
    7fe0:	17fffdb4 	b	76b0 <fwp_write+0x4cc>
    7fe4:	f9400a63 	ldr	x3, [x19, #16]
    7fe8:	8b030021 	add	x1, x1, x3
    7fec:	17ffff56 	b	7d44 <fwp_write+0xb60>
    7ff0:	b9404840 	ldr	w0, [x2, #72]
    7ff4:	91001ff5 	add	x21, sp, #0x7
    7ff8:	34ffa380 	cbz	w0, 7468 <fwp_write+0x284>
    7ffc:	52800503 	mov	w3, #0x28                  	// #40
    8000:	aa1403e0 	mov	x0, x20
    8004:	aa1503e1 	mov	x1, x21
    8008:	d2800022 	mov	x2, #0x1                   	// #1
    800c:	39001fe3 	strb	w3, [sp, #7]
    8010:	97ffed00 	bl	3410 <buf_put>
    8014:	b9401380 	ldr	w0, [x28, #16]
    8018:	52800038 	mov	w24, #0x1                   	// #1
    801c:	7100001f 	cmp	w0, #0x0
    8020:	54ffa38c 	b.gt	7490 <fwp_write+0x2ac>
    8024:	17fffd33 	b	74f0 <fwp_write+0x30c>
    8028:	f9014bf9 	str	x25, [sp, #656]
    802c:	d00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x12d20>
    8030:	f9014ffa 	str	x26, [sp, #664]
    8034:	f9400676 	ldr	x22, [x19, #8]
    8038:	910aa333 	add	x19, x25, #0x2a8
    803c:	91002273 	add	x19, x19, #0x8
    8040:	937ffed8 	asr	x24, x22, #63
    8044:	aa1802c0 	orr	x0, x22, x24
    8048:	b5000320 	cbnz	x0, 80ac <fwp_write+0xec8>
    804c:	110006b5 	add	w21, w21, #0x1
    8050:	710016bf 	cmp	w21, #0x5
    8054:	54ffffc1 	b.ne	804c <fwp_write+0xe68>  // b.any
    8058:	b7f80578 	tbnz	x24, #63, 8104 <fwp_write+0xf20>
    805c:	910023f3 	add	x19, sp, #0x8
    8060:	aa1603e2 	mov	x2, x22
    8064:	aa1303e0 	mov	x0, x19
    8068:	d2800003 	mov	x3, #0x0                   	// #0
    806c:	97ffeb6d 	bl	2e20 <fwp_fmt_u128>
    8070:	910123f5 	add	x21, sp, #0x48
    8074:	b0000003 	adrp	x3, 9000 <__divti3+0x2c0>
    8078:	aa1303e4 	mov	x4, x19
    807c:	aa1503e0 	mov	x0, x21
    8080:	9124c063 	add	x3, x3, #0x930
    8084:	d2804002 	mov	x2, #0x200                 	// #512
    8088:	52800041 	mov	w1, #0x2                   	// #2
    808c:	97ffe9a5 	bl	2720 <__sprintf_chk@plt>
    8090:	aa1503e0 	mov	x0, x21
    8094:	97ffe99f 	bl	2710 <strlen@plt>
    8098:	aa1503e1 	mov	x1, x21
    809c:	aa0003e2 	mov	x2, x0
    80a0:	aa1403e0 	mov	x0, x20
    80a4:	97ffecdb 	bl	3410 <buf_put>
    80a8:	17fffe47 	b	79c4 <fwp_write+0x7e0>
    80ac:	f9400277 	ldr	x23, [x19]
    80b0:	aa1603e0 	mov	x0, x22
    80b4:	aa1803e1 	mov	x1, x24
    80b8:	aa1703e2 	mov	x2, x23
    80bc:	937ffefa 	asr	x26, x23, #63
    80c0:	aa1a03e3 	mov	x3, x26
    80c4:	940003ff 	bl	90c0 <__modti3>
    80c8:	aa010000 	orr	x0, x0, x1
    80cc:	b40002c0 	cbz	x0, 8124 <fwp_write+0xf40>
    80d0:	110006b5 	add	w21, w21, #0x1
    80d4:	91004273 	add	x19, x19, #0x10
    80d8:	710016bf 	cmp	w21, #0x5
    80dc:	54fffe81 	b.ne	80ac <fwp_write+0xec8>  // b.any
    80e0:	17ffffde 	b	8058 <fwp_write+0xe74>
    80e4:	f9400a60 	ldr	x0, [x19, #16]
    80e8:	8b000021 	add	x1, x1, x0
    80ec:	17fffd75 	b	76c0 <fwp_write+0x4dc>
    80f0:	528c29c0 	mov	w0, #0x614e                	// #24910
    80f4:	910123f5 	add	x21, sp, #0x48
    80f8:	72a009c0 	movk	w0, #0x4e, lsl #16
    80fc:	b9004be0 	str	w0, [sp, #72]
    8100:	17fffda2 	b	7788 <fwp_write+0x5a4>
    8104:	528005a1 	mov	w1, #0x2d                  	// #45
    8108:	eb1603e2 	negs	x2, x22
    810c:	da1803e3 	ngc	x3, x24
    8110:	910027e0 	add	x0, sp, #0x9
    8114:	910023f3 	add	x19, sp, #0x8
    8118:	390023e1 	strb	w1, [sp, #8]
    811c:	97ffeb41 	bl	2e20 <fwp_fmt_u128>
    8120:	17ffffd4 	b	8070 <fwp_write+0xe8c>
    8124:	aa1703e2 	mov	x2, x23
    8128:	aa1a03e3 	mov	x3, x26
    812c:	aa1603e0 	mov	x0, x22
    8130:	aa1803e1 	mov	x1, x24
    8134:	94000303 	bl	8d40 <__divti3>
    8138:	aa0003e2 	mov	x2, x0
    813c:	aa0103e3 	mov	x3, x1
    8140:	b7f80201 	tbnz	x1, #63, 8180 <fwp_write+0xf9c>
    8144:	910023f3 	add	x19, sp, #0x8
    8148:	aa1303e0 	mov	x0, x19
    814c:	97ffeb35 	bl	2e20 <fwp_fmt_u128>
    8150:	937c7ea1 	sbfiz	x1, x21, #4, #32
    8154:	910aa339 	add	x25, x25, #0x2a8
    8158:	910123f5 	add	x21, sp, #0x48
    815c:	aa1303e4 	mov	x4, x19
    8160:	aa1503e0 	mov	x0, x21
    8164:	b0000003 	adrp	x3, 9000 <__divti3+0x2c0>
    8168:	f8616b25 	ldr	x5, [x25, x1]
    816c:	9124a063 	add	x3, x3, #0x928
    8170:	d2804002 	mov	x2, #0x200                 	// #512
    8174:	52800041 	mov	w1, #0x2                   	// #2
    8178:	97ffe96a 	bl	2720 <__sprintf_chk@plt>
    817c:	17ffffc5 	b	8090 <fwp_write+0xeac>
    8180:	528005a4 	mov	w4, #0x2d                  	// #45
    8184:	eb0003e2 	negs	x2, x0
    8188:	da0103e3 	ngc	x3, x1
    818c:	910027e0 	add	x0, sp, #0x9
    8190:	910023f3 	add	x19, sp, #0x8
    8194:	390023e4 	strb	w4, [sp, #8]
    8198:	97ffeb22 	bl	2e20 <fwp_fmt_u128>
    819c:	17ffffed 	b	8150 <fwp_write+0xf6c>
    81a0:	f9013bf5 	str	x21, [sp, #624]
    81a4:	f9013ff6 	str	x22, [sp, #632]
    81a8:	f90143f7 	str	x23, [sp, #640]
    81ac:	f90147f8 	str	x24, [sp, #648]
    81b0:	f9014bf9 	str	x25, [sp, #656]
    81b4:	f9014ffa 	str	x26, [sp, #664]
    81b8:	f90153fb 	str	x27, [sp, #672]
    81bc:	f90157fc 	str	x28, [sp, #680]
    81c0:	fd015be8 	str	d8, [sp, #688]
    81c4:	fd015fe9 	str	d9, [sp, #696]
    81c8:	97ffe9ae 	bl	2880 <__stack_chk_fail@plt>
    81cc:	d503201f 	nop

00000000000081d0 <fwp_main_thread>:
    81d0:	d105c3ff 	sub	sp, sp, #0x170
    81d4:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    81d8:	f947f400 	ldr	x0, [x0, #4072]
    81dc:	a9117bfd 	stp	x29, x30, [sp, #272]
    81e0:	910443fd 	add	x29, sp, #0x110
    81e4:	a91253f3 	stp	x19, x20, [sp, #288]
    81e8:	b0000153 	adrp	x19, 31000 <fwp_root_context+0xcb0>
    81ec:	9114c261 	add	x1, x19, #0x530
    81f0:	a9135bf5 	stp	x21, x22, [sp, #304]
    81f4:	a91463f7 	stp	x23, x24, [sp, #320]
    81f8:	b953a421 	ldr	w1, [x1, #5028]
    81fc:	f9400002 	ldr	x2, [x0]
    8200:	f90087e2 	str	x2, [sp, #264]
    8204:	d2800002 	mov	x2, #0x0                   	// #0
    8208:	34000e41 	cbz	w1, 83d0 <fwp_main_thread+0x200>
    820c:	9114c260 	add	x0, x19, #0x530
    8210:	b953a800 	ldr	w0, [x0, #5032]
    8214:	35000d60 	cbnz	w0, 83c0 <fwp_main_thread+0x1f0>
    8218:	900000d5 	adrp	x21, 20000 <__data_start>
    821c:	900000c2 	adrp	x2, 20000 <__data_start>
    8220:	9100c2b4 	add	x20, x21, #0x30
    8224:	910d4042 	add	x2, x2, #0x350
    8228:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    822c:	d2a00024 	mov	x4, #0x10000               	// #65536
    8230:	9100c3f7 	add	x23, sp, #0x30
    8234:	910063f6 	add	x22, sp, #0x18
    8238:	aa1703e0 	mov	x0, x23
    823c:	d2800001 	mov	x1, #0x0                   	// #0
    8240:	a9018e96 	stp	x22, x3, [x20, #24]
    8244:	f9001be2 	str	x2, [sp, #48]
    8248:	b9003bff 	str	wzr, [sp, #56]
    824c:	f90023e4 	str	x4, [sp, #64]
    8250:	97ffe924 	bl	26e0 <sigaltstack@plt>
    8254:	35000220 	cbnz	w0, 8298 <fwp_main_thread+0xc8>
    8258:	4f000400 	movi	v0.4s, #0x0
    825c:	9101e3e0 	add	x0, sp, #0x78
    8260:	f0ffffc1 	adrp	x1, 3000 <fwp_flush+0x10>
    8264:	9101c021 	add	x1, x1, #0x70
    8268:	f9003be1 	str	x1, [sp, #112]
    826c:	52800082 	mov	w2, #0x4                   	// #4
    8270:	72a10002 	movk	w2, #0x800, lsl #16
    8274:	9101c3f8 	add	x24, sp, #0x70
    8278:	3d802000 	str	q0, [x0, #128]
    827c:	b900fbe2 	str	w2, [sp, #248]
    8280:	ad000000 	stp	q0, q0, [x0]
    8284:	ad010000 	stp	q0, q0, [x0, #32]
    8288:	ad020000 	stp	q0, q0, [x0, #64]
    828c:	ad030000 	stp	q0, q0, [x0, #96]
    8290:	97ffe96c 	bl	2840 <sigemptyset@plt>
    8294:	340000c0 	cbz	w0, 82ac <fwp_main_thread+0xdc>
    8298:	b0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    829c:	91252000 	add	x0, x0, #0x948
    82a0:	a9156bf9 	stp	x25, x26, [sp, #336]
    82a4:	a91673fb 	stp	x27, x28, [sp, #352]
    82a8:	97ffeefa 	bl	3e90 <fwp_trap>
    82ac:	aa1803e1 	mov	x1, x24
    82b0:	d2800002 	mov	x2, #0x0                   	// #0
    82b4:	52800160 	mov	w0, #0xb                   	// #11
    82b8:	97ffe97a 	bl	28a0 <sigaction@plt>
    82bc:	35fffee0 	cbnz	w0, 8298 <fwp_main_thread+0xc8>
    82c0:	aa1803e1 	mov	x1, x24
    82c4:	d2800002 	mov	x2, #0x0                   	// #0
    82c8:	528000e0 	mov	w0, #0x7                   	// #7
    82cc:	97ffe975 	bl	28a0 <sigaction@plt>
    82d0:	35fffe40 	cbnz	w0, 8298 <fwp_main_thread+0xc8>
    82d4:	b942f680 	ldr	w0, [x20, #756]
    82d8:	34000800 	cbz	w0, 83d8 <fwp_main_thread+0x208>
    82dc:	9100c2b6 	add	x22, x21, #0x30
    82e0:	f9400ad4 	ldr	x20, [x22, #16]
    82e4:	b4001454 	cbz	x20, 856c <fwp_main_thread+0x39c>
    82e8:	91010297 	add	x23, x20, #0x40
    82ec:	a9156bf9 	stp	x25, x26, [sp, #336]
    82f0:	52800038 	mov	w24, #0x1                   	// #1
    82f4:	39414a99 	ldrb	w25, [x20, #82]
    82f8:	39014a98 	strb	w24, [x20, #82]
    82fc:	d503201f 	nop
    8300:	f9401680 	ldr	x0, [x20, #40]
    8304:	b4001300 	cbz	x0, 8564 <fwp_main_thread+0x394>
    8308:	f9403281 	ldr	x1, [x20, #96]
    830c:	39414680 	ldrb	w0, [x20, #81]
    8310:	b4000f21 	cbz	x1, 84f4 <fwp_main_thread+0x324>
    8314:	36000de0 	tbz	w0, #0, 84d0 <fwp_main_thread+0x300>
    8318:	f9400ad3 	ldr	x19, [x22, #16]
    831c:	f9402280 	ldr	x0, [x20, #64]
    8320:	39414a61 	ldrb	w1, [x19, #82]
    8324:	37001101 	tbnz	w1, #0, 8544 <fwp_main_thread+0x374>
    8328:	f9403261 	ldr	x1, [x19, #96]
    832c:	a911fe77 	stp	x23, xzr, [x19, #280]
    8330:	f9009660 	str	x0, [x19, #296]
    8334:	b4000040 	cbz	x0, 833c <fwp_main_thread+0x16c>
    8338:	f9009013 	str	x19, [x0, #288]
    833c:	f9002293 	str	x19, [x20, #64]
    8340:	b4000101 	cbz	x1, 8360 <fwp_main_thread+0x190>
    8344:	f94046c0 	ldr	x0, [x22, #136]
    8348:	39015678 	strb	w24, [x19, #85]
    834c:	f9003661 	str	x1, [x19, #104]
    8350:	a910827f 	stp	xzr, x0, [x19, #264]
    8354:	b4000040 	cbz	x0, 835c <fwp_main_thread+0x18c>
    8358:	f9008413 	str	x19, [x0, #264]
    835c:	f90046d3 	str	x19, [x22, #136]
    8360:	39015a7f 	strb	wzr, [x19, #86]
    8364:	97fff90f 	bl	67a0 <fwp_block>
    8368:	f9408e62 	ldr	x2, [x19, #280]
    836c:	b4000142 	cbz	x2, 8394 <fwp_main_thread+0x1c4>
    8370:	a9520261 	ldp	x1, x0, [x19, #288]
    8374:	b4000f41 	cbz	x1, 855c <fwp_main_thread+0x38c>
    8378:	f9009420 	str	x0, [x1, #296]
    837c:	f9409660 	ldr	x0, [x19, #296]
    8380:	b4000040 	cbz	x0, 8388 <fwp_main_thread+0x1b8>
    8384:	f9009001 	str	x1, [x0, #288]
    8388:	91080260 	add	x0, x19, #0x200
    838c:	f900967f 	str	xzr, [x19, #296]
    8390:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    8394:	39415660 	ldrb	w0, [x19, #85]
    8398:	3607fb40 	tbz	w0, #0, 8300 <fwp_main_thread+0x130>
    839c:	a9508261 	ldp	x1, x0, [x19, #264]
    83a0:	b4001e81 	cbz	x1, 8770 <fwp_main_thread+0x5a0>
    83a4:	f9008820 	str	x0, [x1, #272]
    83a8:	b4000040 	cbz	x0, 83b0 <fwp_main_thread+0x1e0>
    83ac:	f9008401 	str	x1, [x0, #264]
    83b0:	91080260 	add	x0, x19, #0x200
    83b4:	3901567f 	strb	wzr, [x19, #85]
    83b8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    83bc:	17ffffd1 	b	8300 <fwp_main_thread+0x130>
    83c0:	f0ffffc0 	adrp	x0, 3000 <fwp_flush+0x10>
    83c4:	91261000 	add	x0, x0, #0x984
    83c8:	9400041a 	bl	9430 <atexit>
    83cc:	17ffff93 	b	8218 <fwp_main_thread+0x48>
    83d0:	97ffedc8 	bl	3af0 <fwp_heap_init>
    83d4:	17ffff8e 	b	820c <fwp_main_thread+0x3c>
    83d8:	f9416282 	ldr	x2, [x20, #704]
    83dc:	a9156bf9 	stp	x25, x26, [sp, #336]
    83e0:	b0ffffe0 	adrp	x0, 5000 <fwp_tape_reserve+0x15c>
    83e4:	a91673fb 	stp	x27, x28, [sp, #352]
    83e8:	912f0000 	add	x0, x0, #0xbc0
    83ec:	d0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    83f0:	9114c27a 	add	x26, x19, #0x530
    83f4:	913d4021 	add	x1, x1, #0xf50
    83f8:	d280001b 	mov	x27, #0x0                   	// #0
    83fc:	d290001c 	mov	x28, #0x8000                	// #32768
    8400:	f90003ff 	str	xzr, [sp]
    8404:	a90187e2 	stp	x2, x1, [sp, #24]
    8408:	a902fff7 	stp	x23, xzr, [sp, #40]
    840c:	a90403ff 	stp	xzr, x0, [sp, #64]
    8410:	f9016296 	str	x22, [x20, #704]
    8414:	14000012 	b	845c <fwp_main_thread+0x28c>
    8418:	7100045f 	cmp	w2, #0x1
    841c:	540001a1 	b.ne	8450 <fwp_main_thread+0x280>  // b.any
    8420:	294308a6 	ldp	w6, w2, [x5, #24]
    8424:	92403c21 	and	x1, x1, #0xffff
    8428:	9b067c21 	mul	x1, x1, x6
    842c:	d360fc21 	lsr	x1, x1, #32
    8430:	eb02003f 	cmp	x1, x2
    8434:	540000e2 	b.cs	8450 <fwp_main_thread+0x280>  // b.hs, b.nlast
    8438:	8b010000 	add	x0, x0, x1
    843c:	39400001 	ldrb	w1, [x0]
    8440:	7103fc3f 	cmp	w1, #0xff
    8444:	54003be0 	b.eq	8bc0 <fwp_main_thread+0x9f0>  // b.none
    8448:	52800021 	mov	w1, #0x1                   	// #1
    844c:	39000001 	strb	w1, [x0]
    8450:	a9037ffb 	stp	x27, xzr, [sp, #48]
    8454:	aa190294 	orr	x20, x20, x25
    8458:	b4001914 	cbz	x20, 8778 <fwp_main_thread+0x5a8>
    845c:	f94003e0 	ldr	x0, [sp]
    8460:	f1000794 	subs	x20, x28, #0x1
    8464:	aa1803e1 	mov	x1, x24
    8468:	f9001ff4 	str	x20, [sp, #56]
    846c:	da1f0019 	sbc	x25, x0, xzr
    8470:	52800020 	mov	w0, #0x1                   	// #1
    8474:	f90003f9 	str	x25, [sp]
    8478:	aa1403fc 	mov	x28, x20
    847c:	a9076ff4 	stp	x20, x27, [sp, #112]
    8480:	97fff241 	bl	4d84 <fwp_data.part.0.constprop.0>
    8484:	aa0003fb 	mov	x27, x0
    8488:	f949db41 	ldr	x1, [x26, #5040]
    848c:	f949ef40 	ldr	x0, [x26, #5080]
    8490:	cb010361 	sub	x1, x27, x1
    8494:	eb00403f 	cmp	x1, x0, lsl #16
    8498:	54fffdc2 	b.cs	8450 <fwp_main_thread+0x280>  // b.hs, b.nlast
    849c:	d350fc22 	lsr	x2, x1, #16
    84a0:	f949ff46 	ldr	x6, [x26, #5112]
    84a4:	8b020842 	add	x2, x2, x2, lsl #2
    84a8:	d37df042 	lsl	x2, x2, #3
    84ac:	8b0200c5 	add	x5, x6, x2
    84b0:	f94010a0 	ldr	x0, [x5, #32]
    84b4:	b4fffce0 	cbz	x0, 8450 <fwp_main_thread+0x280>
    84b8:	386268c2 	ldrb	w2, [x6, x2]
    84bc:	7100085f 	cmp	w2, #0x2
    84c0:	54fffac1 	b.ne	8418 <fwp_main_thread+0x248>  // b.any
    84c4:	72003c3f 	tst	w1, #0xffff
    84c8:	54fffc41 	b.ne	8450 <fwp_main_thread+0x280>  // b.any
    84cc:	17ffffdc 	b	843c <fwp_main_thread+0x26c>
    84d0:	97fff090 	bl	4710 <fwp_now_ns>
    84d4:	f9403281 	ldr	x1, [x20, #96]
    84d8:	eb01001f 	cmp	x0, x1
    84dc:	540000ab 	b.lt	84f0 <fwp_main_thread+0x320>  // b.tstop
    84e0:	39414280 	ldrb	w0, [x20, #80]
    84e4:	37000060 	tbnz	w0, #0, 84f0 <fwp_main_thread+0x320>
    84e8:	aa1403e0 	mov	x0, x20
    84ec:	97ffebe1 	bl	3470 <fwp_cancel_tree.part.0>
    84f0:	39414680 	ldrb	w0, [x20, #81]
    84f4:	f9400ad3 	ldr	x19, [x22, #16]
    84f8:	39414a62 	ldrb	w2, [x19, #82]
    84fc:	3707f0e0 	tbnz	w0, #0, 8318 <fwp_main_thread+0x148>
    8500:	f9403281 	ldr	x1, [x20, #96]
    8504:	370001c2 	tbnz	w2, #0, 853c <fwp_main_thread+0x36c>
    8508:	f9403260 	ldr	x0, [x19, #96]
    850c:	b4000180 	cbz	x0, 853c <fwp_main_thread+0x36c>
    8510:	b4000061 	cbz	x1, 851c <fwp_main_thread+0x34c>
    8514:	eb01001f 	cmp	x0, x1
    8518:	9a81d000 	csel	x0, x0, x1, le
    851c:	f9402281 	ldr	x1, [x20, #64]
    8520:	a911fe77 	stp	x23, xzr, [x19, #280]
    8524:	f9009661 	str	x1, [x19, #296]
    8528:	b4003541 	cbz	x1, 8bd0 <fwp_main_thread+0xa00>
    852c:	f9009033 	str	x19, [x1, #288]
    8530:	aa0003e1 	mov	x1, x0
    8534:	f9002293 	str	x19, [x20, #64]
    8538:	17ffff83 	b	8344 <fwp_main_thread+0x174>
    853c:	f9402280 	ldr	x0, [x20, #64]
    8540:	17ffff7b 	b	832c <fwp_main_thread+0x15c>
    8544:	a911fe77 	stp	x23, xzr, [x19, #280]
    8548:	f9009660 	str	x0, [x19, #296]
    854c:	b4000040 	cbz	x0, 8554 <fwp_main_thread+0x384>
    8550:	f9009013 	str	x19, [x0, #288]
    8554:	f9002293 	str	x19, [x20, #64]
    8558:	17ffff82 	b	8360 <fwp_main_thread+0x190>
    855c:	f9000040 	str	x0, [x2]
    8560:	17ffff88 	b	8380 <fwp_main_thread+0x1b0>
    8564:	39014a99 	strb	w25, [x20, #82]
    8568:	a9556bf9 	ldp	x25, x26, [sp, #336]
    856c:	9100c2b3 	add	x19, x21, #0x30
    8570:	f9416e60 	ldr	x0, [x19, #728]
    8574:	b5000060 	cbnz	x0, 8580 <fwp_main_thread+0x3b0>
    8578:	f9417660 	ldr	x0, [x19, #744]
    857c:	b4003480 	cbz	x0, 8c0c <fwp_main_thread+0xa3c>
    8580:	9100c2a0 	add	x0, x21, #0x30
    8584:	f9400800 	ldr	x0, [x0, #16]
    8588:	9100c2a1 	add	x1, x21, #0x30
    858c:	f9418426 	ldr	x6, [x1, #776]
    8590:	b903003f 	str	wzr, [x1, #768]
    8594:	eb0000df 	cmp	x6, x0
    8598:	54003ca1 	b.ne	8d2c <fwp_main_thread+0xb5c>  // b.any
    859c:	b40003c0 	cbz	x0, 8614 <fwp_main_thread+0x444>
    85a0:	f9415825 	ldr	x5, [x1, #688]
    85a4:	52800021 	mov	w1, #0x1                   	// #1
    85a8:	39014801 	strb	w1, [x0, #82]
    85ac:	b4000345 	cbz	x5, 8614 <fwp_main_thread+0x444>
    85b0:	394140a0 	ldrb	w0, [x5, #80]
    85b4:	37000060 	tbnz	w0, #0, 85c0 <fwp_main_thread+0x3f0>
    85b8:	aa0503e0 	mov	x0, x5
    85bc:	97ffebad 	bl	3470 <fwp_cancel_tree.part.0>
    85c0:	f9409ca5 	ldr	x5, [x5, #312]
    85c4:	b5ffff65 	cbnz	x5, 85b0 <fwp_main_thread+0x3e0>
    85c8:	9100c2b3 	add	x19, x21, #0x30
    85cc:	52800034 	mov	w20, #0x1                   	// #1
    85d0:	f94028c0 	ldr	x0, [x6, #80]
    85d4:	f2001c1f 	tst	x0, #0xff000000ff
    85d8:	540000e1 	b.ne	85f4 <fwp_main_thread+0x424>  // b.any
    85dc:	f9401660 	ldr	x0, [x19, #40]
    85e0:	390150d4 	strb	w20, [x6, #84]
    85e4:	f90080df 	str	xzr, [x6, #256]
    85e8:	b4000120 	cbz	x0, 860c <fwp_main_thread+0x43c>
    85ec:	f9008006 	str	x6, [x0, #256]
    85f0:	f9001666 	str	x6, [x19, #40]
    85f4:	97fff86b 	bl	67a0 <fwp_block>
    85f8:	97fff7f2 	bl	65c0 <fwp_free_zombie>
    85fc:	f9415a60 	ldr	x0, [x19, #688]
    8600:	b40000a0 	cbz	x0, 8614 <fwp_main_thread+0x444>
    8604:	f9418666 	ldr	x6, [x19, #776]
    8608:	17fffff2 	b	85d0 <fwp_main_thread+0x400>
    860c:	f9001a66 	str	x6, [x19, #48]
    8610:	17fffff8 	b	85f0 <fwp_main_thread+0x420>
    8614:	9100c2b4 	add	x20, x21, #0x30
    8618:	97fff7ea 	bl	65c0 <fwp_free_zombie>
    861c:	f9401a80 	ldr	x0, [x20, #48]
    8620:	b5003860 	cbnz	x0, 8d2c <fwp_main_thread+0xb5c>
    8624:	f9404680 	ldr	x0, [x20, #136]
    8628:	b5003820 	cbnz	x0, 8d2c <fwp_main_thread+0xb5c>
    862c:	b940aa93 	ldr	w19, [x20, #168]
    8630:	340001f3 	cbz	w19, 866c <fwp_main_thread+0x49c>
    8634:	93407e76 	sxtw	x22, w19
    8638:	51000673 	sub	w19, w19, #0x1
    863c:	d1000ad6 	sub	x22, x22, #0x2
    8640:	9102c297 	add	x23, x20, #0xb0
    8644:	cb3342d6 	sub	x22, x22, w19, uxtw
    8648:	93407e73 	sxtw	x19, w19
    864c:	d503201f 	nop
    8650:	f8737ae0 	ldr	x0, [x23, x19, lsl #3]
    8654:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    8658:	b900aa93 	str	w19, [x20, #168]
    865c:	d1000673 	sub	x19, x19, #0x1
    8660:	97ffe8d0 	bl	29a0 <munmap@plt>
    8664:	eb1302df 	cmp	x22, x19
    8668:	54ffff41 	b.ne	8650 <fwp_main_thread+0x480>  // b.any
    866c:	900000d3 	adrp	x19, 20000 <__data_start>
    8670:	b9401260 	ldr	w0, [x19, #16]
    8674:	37f80040 	tbnz	w0, #31, 867c <fwp_main_thread+0x4ac>
    8678:	97ffe886 	bl	2890 <close@plt>
    867c:	9100c2b4 	add	x20, x21, #0x30
    8680:	12800000 	mov	w0, #0xffffffff            	// #-1
    8684:	b9001260 	str	w0, [x19, #16]
    8688:	f9418e80 	ldr	x0, [x20, #792]
    868c:	f9418a81 	ldr	x1, [x20, #784]
    8690:	b40001c0 	cbz	x0, 86c8 <fwp_main_thread+0x4f8>
    8694:	d2800013 	mov	x19, #0x0                   	// #0
    8698:	f8737820 	ldr	x0, [x1, x19, lsl #3]
    869c:	b40000e0 	cbz	x0, 86b8 <fwp_main_thread+0x4e8>
    86a0:	f9400001 	ldr	x1, [x0]
    86a4:	b5003441 	cbnz	x1, 8d2c <fwp_main_thread+0xb5c>
    86a8:	f9400401 	ldr	x1, [x0, #8]
    86ac:	b5003401 	cbnz	x1, 8d2c <fwp_main_thread+0xb5c>
    86b0:	97ffeeb4 	bl	4180 <fwp_mem_free>
    86b4:	f9418a81 	ldr	x1, [x20, #784]
    86b8:	91000673 	add	x19, x19, #0x1
    86bc:	f9418e80 	ldr	x0, [x20, #792]
    86c0:	eb00027f 	cmp	x19, x0
    86c4:	54fffea3 	b.cc	8698 <fwp_main_thread+0x4c8>  // b.lo, b.ul, b.last
    86c8:	aa0103e0 	mov	x0, x1
    86cc:	97ffeead 	bl	4180 <fwp_mem_free>
    86d0:	9100c2a0 	add	x0, x21, #0x30
    86d4:	f9418413 	ldr	x19, [x0, #776]
    86d8:	f901881f 	str	xzr, [x0, #784]
    86dc:	f9018c1f 	str	xzr, [x0, #792]
    86e0:	b40001f3 	cbz	x19, 871c <fwp_main_thread+0x54c>
    86e4:	f9401661 	ldr	x1, [x19, #40]
    86e8:	b5003221 	cbnz	x1, 8d2c <fwp_main_thread+0xb5c>
    86ec:	f9405661 	ldr	x1, [x19, #168]
    86f0:	b50031e1 	cbnz	x1, 8d2c <fwp_main_thread+0xb5c>
    86f4:	f9416c01 	ldr	x1, [x0, #728]
    86f8:	b50031a1 	cbnz	x1, 8d2c <fwp_main_thread+0xb5c>
    86fc:	f9417400 	ldr	x0, [x0, #744]
    8700:	b5003160 	cbnz	x0, 8d2c <fwp_main_thread+0xb5c>
    8704:	d2823a02 	mov	x2, #0x11d0                	// #4560
    8708:	90000140 	adrp	x0, 30000 <alt.5+0xfcb0>
    870c:	910d4000 	add	x0, x0, #0x350
    8710:	97ffe850 	bl	2850 <memset@plt>
    8714:	aa1303e0 	mov	x0, x19
    8718:	97ffee9a 	bl	4180 <fwp_mem_free>
    871c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    8720:	f947ec00 	ldr	x0, [x0, #4056]
    8724:	9100c2b5 	add	x21, x21, #0x30
    8728:	f9400000 	ldr	x0, [x0]
    872c:	f9000abf 	str	xzr, [x21, #16]
    8730:	f90186bf 	str	xzr, [x21, #776]
    8734:	97ffe89f 	bl	29b0 <fflush@plt>
    8738:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xc98>
    873c:	f947f400 	ldr	x0, [x0, #4072]
    8740:	f94087e2 	ldr	x2, [sp, #264]
    8744:	f9400001 	ldr	x1, [x0]
    8748:	eb010042 	subs	x2, x2, x1
    874c:	d2800001 	mov	x1, #0x0                   	// #0
    8750:	54002c41 	b.ne	8cd8 <fwp_main_thread+0xb08>  // b.any
    8754:	a9517bfd 	ldp	x29, x30, [sp, #272]
    8758:	d2800000 	mov	x0, #0x0                   	// #0
    875c:	a95253f3 	ldp	x19, x20, [sp, #288]
    8760:	a9535bf5 	ldp	x21, x22, [sp, #304]
    8764:	a95463f7 	ldp	x23, x24, [sp, #320]
    8768:	9105c3ff 	add	sp, sp, #0x170
    876c:	d65f03c0 	ret
    8770:	f90046c0 	str	x0, [x22, #136]
    8774:	17ffff0d 	b	83a8 <fwp_main_thread+0x1d8>
    8778:	9100c2a2 	add	x2, x21, #0x30
    877c:	f9001bff 	str	xzr, [sp, #48]
    8780:	f9416040 	ldr	x0, [x2, #704]
    8784:	eb16001f 	cmp	x0, x22
    8788:	54002d61 	b.ne	8d34 <fwp_main_thread+0xb64>  // b.any
    878c:	d0000000 	adrp	x0, a000 <_IO_stdin_used+0xba0>
    8790:	910143e1 	add	x1, sp, #0x50
    8794:	f9400fe3 	ldr	x3, [sp, #24]
    8798:	f9016043 	str	x3, [x2, #704]
    879c:	3dc02000 	ldr	q0, [x0, #128]
    87a0:	52800020 	mov	w0, #0x1                   	// #1
    87a4:	3d8017e0 	str	q0, [sp, #80]
    87a8:	97fff177 	bl	4d84 <fwp_data.part.0.constprop.0>
    87ac:	9114c263 	add	x3, x19, #0x530
    87b0:	aa0003f4 	mov	x20, x0
    87b4:	f949d861 	ldr	x1, [x3, #5040]
    87b8:	f949ec60 	ldr	x0, [x3, #5080]
    87bc:	cb010281 	sub	x1, x20, x1
    87c0:	eb00403f 	cmp	x1, x0, lsl #16
    87c4:	54000322 	b.cs	8828 <fwp_main_thread+0x658>  // b.hs, b.nlast
    87c8:	d350fc22 	lsr	x2, x1, #16
    87cc:	f949fc63 	ldr	x3, [x3, #5112]
    87d0:	8b020842 	add	x2, x2, x2, lsl #2
    87d4:	d37df042 	lsl	x2, x2, #3
    87d8:	8b020060 	add	x0, x3, x2
    87dc:	f9401016 	ldr	x22, [x0, #32]
    87e0:	b4000256 	cbz	x22, 8828 <fwp_main_thread+0x658>
    87e4:	38626862 	ldrb	w2, [x3, x2]
    87e8:	7100085f 	cmp	w2, #0x2
    87ec:	54001f80 	b.eq	8bdc <fwp_main_thread+0xa0c>  // b.none
    87f0:	7100045f 	cmp	w2, #0x1
    87f4:	540001a1 	b.ne	8828 <fwp_main_thread+0x658>  // b.any
    87f8:	29430002 	ldp	w2, w0, [x0, #24]
    87fc:	92403c21 	and	x1, x1, #0xffff
    8800:	9b027c21 	mul	x1, x1, x2
    8804:	d360fc21 	lsr	x1, x1, #32
    8808:	eb00003f 	cmp	x1, x0
    880c:	540000e2 	b.cs	8828 <fwp_main_thread+0x658>  // b.hs, b.nlast
    8810:	8b0102d6 	add	x22, x22, x1
    8814:	394002c0 	ldrb	w0, [x22]
    8818:	7103fc1f 	cmp	w0, #0xff
    881c:	54002100 	b.eq	8c3c <fwp_main_thread+0xa6c>  // b.none
    8820:	52800020 	mov	w0, #0x1                   	// #1
    8824:	390002c0 	strb	w0, [x22]
    8828:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    882c:	aa1803e1 	mov	x1, x24
    8830:	52800020 	mov	w0, #0x1                   	// #1
    8834:	a90753e2 	stp	x2, x20, [sp, #112]
    8838:	97fff153 	bl	4d84 <fwp_data.part.0.constprop.0>
    883c:	9114c263 	add	x3, x19, #0x530
    8840:	aa0003f4 	mov	x20, x0
    8844:	f949d861 	ldr	x1, [x3, #5040]
    8848:	f949ec60 	ldr	x0, [x3, #5080]
    884c:	cb010281 	sub	x1, x20, x1
    8850:	eb00403f 	cmp	x1, x0, lsl #16
    8854:	54000322 	b.cs	88b8 <fwp_main_thread+0x6e8>  // b.hs, b.nlast
    8858:	d350fc22 	lsr	x2, x1, #16
    885c:	f949fc63 	ldr	x3, [x3, #5112]
    8860:	8b020842 	add	x2, x2, x2, lsl #2
    8864:	d37df042 	lsl	x2, x2, #3
    8868:	8b020060 	add	x0, x3, x2
    886c:	f9401016 	ldr	x22, [x0, #32]
    8870:	b4000256 	cbz	x22, 88b8 <fwp_main_thread+0x6e8>
    8874:	38626862 	ldrb	w2, [x3, x2]
    8878:	7100085f 	cmp	w2, #0x2
    887c:	54001b60 	b.eq	8be8 <fwp_main_thread+0xa18>  // b.none
    8880:	7100045f 	cmp	w2, #0x1
    8884:	540001a1 	b.ne	88b8 <fwp_main_thread+0x6e8>  // b.any
    8888:	29430002 	ldp	w2, w0, [x0, #24]
    888c:	92403c21 	and	x1, x1, #0xffff
    8890:	9b027c21 	mul	x1, x1, x2
    8894:	d360fc21 	lsr	x1, x1, #32
    8898:	eb00003f 	cmp	x1, x0
    889c:	540000e2 	b.cs	88b8 <fwp_main_thread+0x6e8>  // b.hs, b.nlast
    88a0:	8b0102d6 	add	x22, x22, x1
    88a4:	394002c0 	ldrb	w0, [x22]
    88a8:	7103fc1f 	cmp	w0, #0xff
    88ac:	54001ce0 	b.eq	8c48 <fwp_main_thread+0xa78>  // b.none
    88b0:	52800020 	mov	w0, #0x1                   	// #1
    88b4:	390002c0 	strb	w0, [x22]
    88b8:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    88bc:	910183e1 	add	x1, sp, #0x60
    88c0:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    88c4:	52800020 	mov	w0, #0x1                   	// #1
    88c8:	a90653e2 	stp	x2, x20, [sp, #96]
    88cc:	97fff12e 	bl	4d84 <fwp_data.part.0.constprop.0>
    88d0:	9114c263 	add	x3, x19, #0x530
    88d4:	aa0003f9 	mov	x25, x0
    88d8:	f949d861 	ldr	x1, [x3, #5040]
    88dc:	f949ec60 	ldr	x0, [x3, #5080]
    88e0:	cb010321 	sub	x1, x25, x1
    88e4:	eb00403f 	cmp	x1, x0, lsl #16
    88e8:	54000322 	b.cs	894c <fwp_main_thread+0x77c>  // b.hs, b.nlast
    88ec:	d350fc22 	lsr	x2, x1, #16
    88f0:	f949fc63 	ldr	x3, [x3, #5112]
    88f4:	8b020842 	add	x2, x2, x2, lsl #2
    88f8:	d37df042 	lsl	x2, x2, #3
    88fc:	8b020060 	add	x0, x3, x2
    8900:	f9401014 	ldr	x20, [x0, #32]
    8904:	b4000254 	cbz	x20, 894c <fwp_main_thread+0x77c>
    8908:	38626862 	ldrb	w2, [x3, x2]
    890c:	7100085f 	cmp	w2, #0x2
    8910:	54001720 	b.eq	8bf4 <fwp_main_thread+0xa24>  // b.none
    8914:	7100045f 	cmp	w2, #0x1
    8918:	540001a1 	b.ne	894c <fwp_main_thread+0x77c>  // b.any
    891c:	29430002 	ldp	w2, w0, [x0, #24]
    8920:	92403c21 	and	x1, x1, #0xffff
    8924:	9b027c21 	mul	x1, x1, x2
    8928:	d360fc21 	lsr	x1, x1, #32
    892c:	eb00003f 	cmp	x1, x0
    8930:	540000e2 	b.cs	894c <fwp_main_thread+0x77c>  // b.hs, b.nlast
    8934:	8b010294 	add	x20, x20, x1
    8938:	39400280 	ldrb	w0, [x20]
    893c:	7103fc1f 	cmp	w0, #0xff
    8940:	54001780 	b.eq	8c30 <fwp_main_thread+0xa60>  // b.none
    8944:	52800020 	mov	w0, #0x1                   	// #1
    8948:	39000280 	strb	w0, [x20]
    894c:	aa1b03f8 	mov	x24, x27
    8950:	d00000a0 	adrp	x0, 1e000 <__FRAME_END__+0x12d20>
    8954:	b400121b 	cbz	x27, 8b94 <fwp_main_thread+0x9c4>
    8958:	910aa000 	add	x0, x0, #0x2a8
    895c:	b0000016 	adrp	x22, 9000 <__divti3+0x2c0>
    8960:	91014014 	add	x20, x0, #0x50
    8964:	913762d6 	add	x22, x22, #0xdd8
    8968:	9114c27a 	add	x26, x19, #0x530
    896c:	f949db41 	ldr	x1, [x26, #5040]
    8970:	f949ef40 	ldr	x0, [x26, #5080]
    8974:	cb010321 	sub	x1, x25, x1
    8978:	eb00403f 	cmp	x1, x0, lsl #16
    897c:	54000342 	b.cs	89e4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    8980:	d350fc22 	lsr	x2, x1, #16
    8984:	f949ff45 	ldr	x5, [x26, #5112]
    8988:	8b020842 	add	x2, x2, x2, lsl #2
    898c:	d37df042 	lsl	x2, x2, #3
    8990:	8b0200a3 	add	x3, x5, x2
    8994:	f9401060 	ldr	x0, [x3, #32]
    8998:	b4000260 	cbz	x0, 89e4 <fwp_main_thread+0x814>
    899c:	386268a2 	ldrb	w2, [x5, x2]
    89a0:	7100085f 	cmp	w2, #0x2
    89a4:	540012e0 	b.eq	8c00 <fwp_main_thread+0xa30>  // b.none
    89a8:	7100045f 	cmp	w2, #0x1
    89ac:	540001c1 	b.ne	89e4 <fwp_main_thread+0x814>  // b.any
    89b0:	29430865 	ldp	w5, w2, [x3, #24]
    89b4:	92403c21 	and	x1, x1, #0xffff
    89b8:	9b057c21 	mul	x1, x1, x5
    89bc:	d360fc21 	lsr	x1, x1, #32
    89c0:	eb02003f 	cmp	x1, x2
    89c4:	54000102 	b.cs	89e4 <fwp_main_thread+0x814>  // b.hs, b.nlast
    89c8:	8b010000 	add	x0, x0, x1
    89cc:	39400001 	ldrb	w1, [x0]
    89d0:	340000a1 	cbz	w1, 89e4 <fwp_main_thread+0x814>
    89d4:	7103f43f 	cmp	w1, #0xfd
    89d8:	540013e8 	b.hi	8c54 <fwp_main_thread+0xa84>  // b.pmore
    89dc:	11000421 	add	w1, w1, #0x1
    89e0:	39000001 	strb	w1, [x0]
    89e4:	aa1403e2 	mov	x2, x20
    89e8:	aa1903e1 	mov	x1, x25
    89ec:	aa1703e0 	mov	x0, x23
    89f0:	52800023 	mov	w3, #0x1                   	// #1
    89f4:	a9037fff 	stp	xzr, xzr, [sp, #48]
    89f8:	f90023ff 	str	xzr, [sp, #64]
    89fc:	97fff9fa 	bl	71e4 <fwp_write>
    8a00:	a9430bfc 	ldp	x28, x2, [sp, #48]
    8a04:	f100039f 	cmp	x28, #0x0
    8a08:	9a9c02dc 	csel	x28, x22, x28, eq	// eq = none
    8a0c:	b100285f 	cmn	x2, #0xa
    8a10:	54001268 	b.hi	8c5c <fwp_main_thread+0xa8c>  // b.pmore
    8a14:	91002440 	add	x0, x2, #0x9
    8a18:	52800021 	mov	w1, #0x1                   	// #1
    8a1c:	f90007e2 	str	x2, [sp, #8]
    8a20:	97fff094 	bl	4c70 <fwp_heap_alloc>
    8a24:	aa1c03e1 	mov	x1, x28
    8a28:	aa0003fc 	mov	x28, x0
    8a2c:	f94007e2 	ldr	x2, [sp, #8]
    8a30:	f90003e0 	str	x0, [sp]
    8a34:	f8008782 	str	x2, [x28], #8
    8a38:	aa1c03e0 	mov	x0, x28
    8a3c:	97ffe725 	bl	26d0 <memcpy@plt>
    8a40:	a9400be0 	ldp	x0, x2, [sp]
    8a44:	8b020002 	add	x2, x0, x2
    8a48:	3900205f 	strb	wzr, [x2, #8]
    8a4c:	f9401be0 	ldr	x0, [sp, #48]
    8a50:	97ffe7bc 	bl	2940 <free@plt>
    8a54:	9114c260 	add	x0, x19, #0x530
    8a58:	f94003e3 	ldr	x3, [sp]
    8a5c:	f949d801 	ldr	x1, [x0, #5040]
    8a60:	f949ec02 	ldr	x2, [x0, #5080]
    8a64:	cb010061 	sub	x1, x3, x1
    8a68:	eb02403f 	cmp	x1, x2, lsl #16
    8a6c:	54000322 	b.cs	8ad0 <fwp_main_thread+0x900>  // b.hs, b.nlast
    8a70:	d350fc22 	lsr	x2, x1, #16
    8a74:	d2800503 	mov	x3, #0x28                  	// #40
    8a78:	f949fc05 	ldr	x5, [x0, #5112]
    8a7c:	9b037c42 	mul	x2, x2, x3
    8a80:	8b0200a3 	add	x3, x5, x2
    8a84:	f9401060 	ldr	x0, [x3, #32]
    8a88:	b4000240 	cbz	x0, 8ad0 <fwp_main_thread+0x900>
    8a8c:	386268a2 	ldrb	w2, [x5, x2]
    8a90:	7100085f 	cmp	w2, #0x2
    8a94:	54000f60 	b.eq	8c80 <fwp_main_thread+0xab0>  // b.none
    8a98:	7100045f 	cmp	w2, #0x1
    8a9c:	540001a1 	b.ne	8ad0 <fwp_main_thread+0x900>  // b.any
    8aa0:	29430865 	ldp	w5, w2, [x3, #24]
    8aa4:	92403c21 	and	x1, x1, #0xffff
    8aa8:	9b057c21 	mul	x1, x1, x5
    8aac:	d360fc21 	lsr	x1, x1, #32
    8ab0:	eb02003f 	cmp	x1, x2
    8ab4:	540000e2 	b.cs	8ad0 <fwp_main_thread+0x900>  // b.hs, b.nlast
    8ab8:	8b010000 	add	x0, x0, x1
    8abc:	39400001 	ldrb	w1, [x0]
    8ac0:	7103fc3f 	cmp	w1, #0xff
    8ac4:	54000e40 	b.eq	8c8c <fwp_main_thread+0xabc>  // b.none
    8ac8:	52800021 	mov	w1, #0x1                   	// #1
    8acc:	39000001 	strb	w1, [x0]
    8ad0:	aa1903e0 	mov	x0, x25
    8ad4:	97fff3df 	bl	5a50 <fwp_drop0>
    8ad8:	f94003e1 	ldr	x1, [sp]
    8adc:	9100c2a3 	add	x3, x21, #0x30
    8ae0:	aa1c03e0 	mov	x0, x28
    8ae4:	aa0303fc 	mov	x28, x3
    8ae8:	f9400022 	ldr	x2, [x1]
    8aec:	d2800021 	mov	x1, #0x1                   	// #1
    8af0:	f9400463 	ldr	x3, [x3, #8]
    8af4:	97ffe7a3 	bl	2980 <fwrite@plt>
    8af8:	f9400781 	ldr	x1, [x28, #8]
    8afc:	52800140 	mov	w0, #0xa                   	// #10
    8b00:	97ffe728 	bl	27a0 <fputc@plt>
    8b04:	9114c262 	add	x2, x19, #0x530
    8b08:	f94003e3 	ldr	x3, [sp]
    8b0c:	f949d841 	ldr	x1, [x2, #5040]
    8b10:	f949ec40 	ldr	x0, [x2, #5080]
    8b14:	cb010061 	sub	x1, x3, x1
    8b18:	eb00403f 	cmp	x1, x0, lsl #16
    8b1c:	54000382 	b.cs	8b8c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8b20:	d350fc20 	lsr	x0, x1, #16
    8b24:	d2800505 	mov	x5, #0x28                  	// #40
    8b28:	f949fc43 	ldr	x3, [x2, #5112]
    8b2c:	9b057c00 	mul	x0, x0, x5
    8b30:	8b000062 	add	x2, x3, x0
    8b34:	f940105c 	ldr	x28, [x2, #32]
    8b38:	b40002bc 	cbz	x28, 8b8c <fwp_main_thread+0x9bc>
    8b3c:	38606860 	ldrb	w0, [x3, x0]
    8b40:	7100081f 	cmp	w0, #0x2
    8b44:	54000980 	b.eq	8c74 <fwp_main_thread+0xaa4>  // b.none
    8b48:	7100041f 	cmp	w0, #0x1
    8b4c:	54000201 	b.ne	8b8c <fwp_main_thread+0x9bc>  // b.any
    8b50:	29430043 	ldp	w3, w0, [x2, #24]
    8b54:	92403c21 	and	x1, x1, #0xffff
    8b58:	9b037c21 	mul	x1, x1, x3
    8b5c:	d360fc21 	lsr	x1, x1, #32
    8b60:	eb00003f 	cmp	x1, x0
    8b64:	54000142 	b.cs	8b8c <fwp_main_thread+0x9bc>  // b.hs, b.nlast
    8b68:	8b01039c 	add	x28, x28, x1
    8b6c:	39400380 	ldrb	w0, [x28]
    8b70:	340000e0 	cbz	w0, 8b8c <fwp_main_thread+0x9bc>
    8b74:	7100041f 	cmp	w0, #0x1
    8b78:	54000780 	b.eq	8c68 <fwp_main_thread+0xa98>  // b.none
    8b7c:	7103fc1f 	cmp	w0, #0xff
    8b80:	540008e0 	b.eq	8c9c <fwp_main_thread+0xacc>  // b.none
    8b84:	51000400 	sub	w0, w0, #0x1
    8b88:	39000380 	strb	w0, [x28]
    8b8c:	f9400b18 	ldr	x24, [x24, #16]
    8b90:	b5ffeef8 	cbnz	x24, 896c <fwp_main_thread+0x79c>
    8b94:	aa1903e0 	mov	x0, x25
    8b98:	97fff3ae 	bl	5a50 <fwp_drop0>
    8b9c:	aa1b03e0 	mov	x0, x27
    8ba0:	97fff3ac 	bl	5a50 <fwp_drop0>
    8ba4:	9100c2a0 	add	x0, x21, #0x30
    8ba8:	52800021 	mov	w1, #0x1                   	// #1
    8bac:	a9556bf9 	ldp	x25, x26, [sp, #336]
    8bb0:	a95673fb 	ldp	x27, x28, [sp, #352]
    8bb4:	b902f401 	str	w1, [x0, #756]
    8bb8:	f9017c1f 	str	xzr, [x0, #760]
    8bbc:	17fffdc8 	b	82dc <fwp_main_thread+0x10c>
    8bc0:	f90007e0 	str	x0, [sp, #8]
    8bc4:	97ffecd3 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8bc8:	f94007e0 	ldr	x0, [sp, #8]
    8bcc:	17fffe1f 	b	8448 <fwp_main_thread+0x278>
    8bd0:	aa0003e1 	mov	x1, x0
    8bd4:	f9002293 	str	x19, [x20, #64]
    8bd8:	17fffddb 	b	8344 <fwp_main_thread+0x174>
    8bdc:	72003c3f 	tst	w1, #0xffff
    8be0:	54ffe241 	b.ne	8828 <fwp_main_thread+0x658>  // b.any
    8be4:	17ffff0c 	b	8814 <fwp_main_thread+0x644>
    8be8:	72003c3f 	tst	w1, #0xffff
    8bec:	54ffe661 	b.ne	88b8 <fwp_main_thread+0x6e8>  // b.any
    8bf0:	17ffff2d 	b	88a4 <fwp_main_thread+0x6d4>
    8bf4:	72003c3f 	tst	w1, #0xffff
    8bf8:	54ffeaa1 	b.ne	894c <fwp_main_thread+0x77c>  // b.any
    8bfc:	17ffff4f 	b	8938 <fwp_main_thread+0x768>
    8c00:	72003c3f 	tst	w1, #0xffff
    8c04:	54ffef01 	b.ne	89e4 <fwp_main_thread+0x814>  // b.any
    8c08:	17ffff71 	b	89cc <fwp_main_thread+0x7fc>
    8c0c:	f9416a60 	ldr	x0, [x19, #720]
    8c10:	97ffed5c 	bl	4180 <fwp_mem_free>
    8c14:	f9016a7f 	str	xzr, [x19, #720]
    8c18:	f9400a60 	ldr	x0, [x19, #16]
    8c1c:	f901727f 	str	xzr, [x19, #736]
    8c20:	b4ffcb40 	cbz	x0, 8588 <fwp_main_thread+0x3b8>
    8c24:	f900541f 	str	xzr, [x0, #168]
    8c28:	f9005c1f 	str	xzr, [x0, #184]
    8c2c:	17fffe57 	b	8588 <fwp_main_thread+0x3b8>
    8c30:	aa1403e0 	mov	x0, x20
    8c34:	97ffecb7 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8c38:	17ffff43 	b	8944 <fwp_main_thread+0x774>
    8c3c:	aa1603e0 	mov	x0, x22
    8c40:	97ffecb4 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8c44:	17fffef7 	b	8820 <fwp_main_thread+0x650>
    8c48:	aa1603e0 	mov	x0, x22
    8c4c:	97ffecb1 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8c50:	17ffff18 	b	88b0 <fwp_main_thread+0x6e0>
    8c54:	97ffedc4 	bl	4364 <fwp_rc_wide_dup>
    8c58:	17ffff63 	b	89e4 <fwp_main_thread+0x814>
    8c5c:	b0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    8c60:	9125c000 	add	x0, x0, #0x970
    8c64:	97ffec8b 	bl	3e90 <fwp_trap>
    8c68:	f94003e0 	ldr	x0, [sp]
    8c6c:	97fff2a5 	bl	5700 <fwp_rc_free_arr>
    8c70:	17ffffc7 	b	8b8c <fwp_main_thread+0x9bc>
    8c74:	72003c3f 	tst	w1, #0xffff
    8c78:	54fff8a1 	b.ne	8b8c <fwp_main_thread+0x9bc>  // b.any
    8c7c:	17ffffbc 	b	8b6c <fwp_main_thread+0x99c>
    8c80:	72003c3f 	tst	w1, #0xffff
    8c84:	54fff261 	b.ne	8ad0 <fwp_main_thread+0x900>  // b.any
    8c88:	17ffff8d 	b	8abc <fwp_main_thread+0x8ec>
    8c8c:	f90007e0 	str	x0, [sp, #8]
    8c90:	97ffeca0 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8c94:	f94007e0 	ldr	x0, [sp, #8]
    8c98:	17ffff8c 	b	8ac8 <fwp_main_thread+0x8f8>
    8c9c:	ca5c4780 	eor	x0, x28, x28, lsr #17
    8ca0:	9114c262 	add	x2, x19, #0x530
    8ca4:	ca402400 	eor	x0, x0, x0, lsr #9
    8ca8:	92401c00 	and	x0, x0, #0xff
    8cac:	910a2401 	add	x1, x0, #0x289
    8cb0:	8b000c40 	add	x0, x2, x0, lsl #3
    8cb4:	8b010c41 	add	x1, x2, x1, lsl #3
    8cb8:	f94a2400 	ldr	x0, [x0, #5192]
    8cbc:	b40002c0 	cbz	x0, 8d14 <fwp_main_thread+0xb44>
    8cc0:	f9400002 	ldr	x2, [x0]
    8cc4:	eb02039f 	cmp	x28, x2
    8cc8:	540000e0 	b.eq	8ce4 <fwp_main_thread+0xb14>  // b.none
    8ccc:	91004001 	add	x1, x0, #0x10
    8cd0:	f9400800 	ldr	x0, [x0, #16]
    8cd4:	17fffffa 	b	8cbc <fwp_main_thread+0xaec>
    8cd8:	a9156bf9 	stp	x25, x26, [sp, #336]
    8cdc:	a91673fb 	stp	x27, x28, [sp, #352]
    8ce0:	97ffe6e8 	bl	2880 <__stack_chk_fail@plt>
    8ce4:	f9400021 	ldr	x1, [x1]
    8ce8:	f9400420 	ldr	x0, [x1, #8]
    8cec:	d1000400 	sub	x0, x0, #0x1
    8cf0:	f9000420 	str	x0, [x1, #8]
    8cf4:	f103f81f 	cmp	x0, #0xfe
    8cf8:	54fff4a1 	b.ne	8b8c <fwp_main_thread+0x9bc>  // b.any
    8cfc:	39400380 	ldrb	w0, [x28]
    8d00:	7103fc1f 	cmp	w0, #0xff
    8d04:	540000e0 	b.eq	8d20 <fwp_main_thread+0xb50>  // b.none
    8d08:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8d0c:	39000380 	strb	w0, [x28]
    8d10:	17ffff9f 	b	8b8c <fwp_main_thread+0x9bc>
    8d14:	b0000000 	adrp	x0, 9000 <__divti3+0x2c0>
    8d18:	91168000 	add	x0, x0, #0x5a0
    8d1c:	97ffec5d 	bl	3e90 <fwp_trap>
    8d20:	aa1c03e0 	mov	x0, x28
    8d24:	97ffec7b 	bl	3f10 <fwp_rc_forget_slot.part.0>
    8d28:	17fffff8 	b	8d08 <fwp_main_thread+0xb38>
    8d2c:	a9156bf9 	stp	x25, x26, [sp, #336]
    8d30:	a91673fb 	stp	x27, x28, [sp, #352]
    8d34:	97ffe6e7 	bl	28d0 <abort@plt>
    8d38:	d503201f 	nop
    8d3c:	d503201f 	nop

0000000000008d40 <__divti3>:
    8d40:	d503245f 	bti	c
    8d44:	d2800004 	mov	x4, #0x0                   	// #0
    8d48:	b7f80721 	tbnz	x1, #63, 8e2c <__divti3+0xec>
    8d4c:	b6f80083 	tbz	x3, #63, 8d5c <__divti3+0x1c>
    8d50:	eb0203e2 	negs	x2, x2
    8d54:	aa2403e4 	mvn	x4, x4
    8d58:	da0303e3 	ngc	x3, x3
    8d5c:	aa0203e6 	mov	x6, x2
    8d60:	aa0003e7 	mov	x7, x0
    8d64:	aa0103e5 	mov	x5, x1
    8d68:	b5000583 	cbnz	x3, 8e18 <__divti3+0xd8>
    8d6c:	eb01005f 	cmp	x2, x1
    8d70:	54000e69 	b.ls	8f3c <__divti3+0x1fc>  // b.plast
    8d74:	dac01040 	clz	x0, x2
    8d78:	b40000e0 	cbz	x0, 8d94 <__divti3+0x54>
    8d7c:	4b0003e1 	neg	w1, w0
    8d80:	9ac020a5 	lsl	x5, x5, x0
    8d84:	9ac02046 	lsl	x6, x2, x0
    8d88:	9ac124e1 	lsr	x1, x7, x1
    8d8c:	aa050025 	orr	x5, x1, x5
    8d90:	9ac020e7 	lsl	x7, x7, x0
    8d94:	d360fcc8 	lsr	x8, x6, #32
    8d98:	92407cc2 	and	x2, x6, #0xffffffff
    8d9c:	9ac808a3 	udiv	x3, x5, x8
    8da0:	9b089465 	msub	x5, x3, x8, x5
    8da4:	aa0303e0 	mov	x0, x3
    8da8:	9b037c41 	mul	x1, x2, x3
    8dac:	93c780a5 	extr	x5, x5, x7, #32
    8db0:	eb05003f 	cmp	x1, x5
    8db4:	540000a9 	b.ls	8dc8 <__divti3+0x88>  // b.plast
    8db8:	ab0500c5 	adds	x5, x6, x5
    8dbc:	d1000460 	sub	x0, x3, #0x1
    8dc0:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    8dc4:	540015a8 	b.hi	9078 <__divti3+0x338>  // b.pmore
    8dc8:	cb0100a5 	sub	x5, x5, x1
    8dcc:	9ac808a3 	udiv	x3, x5, x8
    8dd0:	9b089465 	msub	x5, x3, x8, x5
    8dd4:	aa0303e1 	mov	x1, x3
    8dd8:	9b037c42 	mul	x2, x2, x3
    8ddc:	aa0703e3 	mov	x3, x7
    8de0:	b3607ca3 	bfi	x3, x5, #32, #32
    8de4:	eb03005f 	cmp	x2, x3
    8de8:	540000c9 	b.ls	8e00 <__divti3+0xc0>  // b.plast
    8dec:	ab0300c3 	adds	x3, x6, x3
    8df0:	d1000425 	sub	x5, x1, #0x1
    8df4:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8df8:	d1000821 	sub	x1, x1, #0x2
    8dfc:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    8e00:	aa008020 	orr	x0, x1, x0, lsl #32
    8e04:	d2800001 	mov	x1, #0x0                   	// #0
    8e08:	b4000064 	cbz	x4, 8e14 <__divti3+0xd4>
    8e0c:	eb0003e0 	negs	x0, x0
    8e10:	da0103e1 	ngc	x1, x1
    8e14:	d65f03c0 	ret
    8e18:	eb01007f 	cmp	x3, x1
    8e1c:	54000109 	b.ls	8e3c <__divti3+0xfc>  // b.plast
    8e20:	d2800001 	mov	x1, #0x0                   	// #0
    8e24:	d2800000 	mov	x0, #0x0                   	// #0
    8e28:	17fffff8 	b	8e08 <__divti3+0xc8>
    8e2c:	eb0003e0 	negs	x0, x0
    8e30:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    8e34:	da0103e1 	ngc	x1, x1
    8e38:	17ffffc5 	b	8d4c <__divti3+0xc>
    8e3c:	dac01067 	clz	x7, x3
    8e40:	b40010e7 	cbz	x7, 905c <__divti3+0x31c>
    8e44:	d2800805 	mov	x5, #0x40                  	// #64
    8e48:	cb0700a5 	sub	x5, x5, x7
    8e4c:	9ac72063 	lsl	x3, x3, x7
    8e50:	9ac52448 	lsr	x8, x2, x5
    8e54:	aa030108 	orr	x8, x8, x3
    8e58:	9ac52426 	lsr	x6, x1, x5
    8e5c:	92407d0a 	and	x10, x8, #0xffffffff
    8e60:	d360fd09 	lsr	x9, x8, #32
    8e64:	9ac52403 	lsr	x3, x0, x5
    8e68:	9ac72021 	lsl	x1, x1, x7
    8e6c:	aa010063 	orr	x3, x3, x1
    8e70:	9ac72042 	lsl	x2, x2, x7
    8e74:	9ac908cb 	udiv	x11, x6, x9
    8e78:	9b099965 	msub	x5, x11, x9, x6
    8e7c:	aa0b03e1 	mov	x1, x11
    8e80:	9b0b7d46 	mul	x6, x10, x11
    8e84:	93c380a5 	extr	x5, x5, x3, #32
    8e88:	eb0500df 	cmp	x6, x5
    8e8c:	540000a9 	b.ls	8ea0 <__divti3+0x160>  // b.plast
    8e90:	ab050105 	adds	x5, x8, x5
    8e94:	d1000561 	sub	x1, x11, #0x1
    8e98:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    8e9c:	54000f48 	b.hi	9084 <__divti3+0x344>  // b.pmore
    8ea0:	cb0600a6 	sub	x6, x5, x6
    8ea4:	9ac908cb 	udiv	x11, x6, x9
    8ea8:	9b099969 	msub	x9, x11, x9, x6
    8eac:	aa0b03e5 	mov	x5, x11
    8eb0:	9b0b7d4a 	mul	x10, x10, x11
    8eb4:	b3607d23 	bfi	x3, x9, #32, #32
    8eb8:	eb03015f 	cmp	x10, x3
    8ebc:	540000a9 	b.ls	8ed0 <__divti3+0x190>  // b.plast
    8ec0:	ab030103 	adds	x3, x8, x3
    8ec4:	d1000565 	sub	x5, x11, #0x1
    8ec8:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    8ecc:	54000e28 	b.hi	9090 <__divti3+0x350>  // b.pmore
    8ed0:	aa0180a1 	orr	x1, x5, x1, lsl #32
    8ed4:	92407c48 	and	x8, x2, #0xffffffff
    8ed8:	2a0503e5 	mov	w5, w5
    8edc:	d360fc42 	lsr	x2, x2, #32
    8ee0:	d360fc26 	lsr	x6, x1, #32
    8ee4:	cb0a0063 	sub	x3, x3, x10
    8ee8:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    8eec:	9b087caa 	mul	x10, x5, x8
    8ef0:	9b087cc8 	mul	x8, x6, x8
    8ef4:	9b0220a5 	madd	x5, x5, x2, x8
    8ef8:	9b027cc6 	mul	x6, x6, x2
    8efc:	8b4a80a2 	add	x2, x5, x10, lsr #32
    8f00:	8b0900c5 	add	x5, x6, x9
    8f04:	eb02011f 	cmp	x8, x2
    8f08:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    8f0c:	8b4280c6 	add	x6, x6, x2, lsr #32
    8f10:	eb06007f 	cmp	x3, x6
    8f14:	540000e3 	b.cc	8f30 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    8f18:	92407d4a 	and	x10, x10, #0xffffffff
    8f1c:	9ac72000 	lsl	x0, x0, x7
    8f20:	8b028142 	add	x2, x10, x2, lsl #32
    8f24:	eb02001f 	cmp	x0, x2
    8f28:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    8f2c:	54000a01 	b.ne	906c <__divti3+0x32c>  // b.any
    8f30:	d1000420 	sub	x0, x1, #0x1
    8f34:	d2800001 	mov	x1, #0x0                   	// #0
    8f38:	17ffffb4 	b	8e08 <__divti3+0xc8>
    8f3c:	b5000062 	cbnz	x2, 8f48 <__divti3+0x208>
    8f40:	d2800022 	mov	x2, #0x1                   	// #1
    8f44:	9ac30846 	udiv	x6, x2, x3
    8f48:	dac010c8 	clz	x8, x6
    8f4c:	b5000408 	cbnz	x8, 8fcc <__divti3+0x28c>
    8f50:	d360fcc9 	lsr	x9, x6, #32
    8f54:	92407cc5 	and	x5, x6, #0xffffffff
    8f58:	cb060023 	sub	x3, x1, x6
    8f5c:	d2800021 	mov	x1, #0x1                   	// #1
    8f60:	9ac90868 	udiv	x8, x3, x9
    8f64:	9b098d03 	msub	x3, x8, x9, x3
    8f68:	aa0803e0 	mov	x0, x8
    8f6c:	9b057d02 	mul	x2, x8, x5
    8f70:	93c78063 	extr	x3, x3, x7, #32
    8f74:	eb03005f 	cmp	x2, x3
    8f78:	540000a9 	b.ls	8f8c <__divti3+0x24c>  // b.plast
    8f7c:	ab0300c3 	adds	x3, x6, x3
    8f80:	d1000500 	sub	x0, x8, #0x1
    8f84:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    8f88:	54000968 	b.hi	90b4 <__divti3+0x374>  // b.pmore
    8f8c:	cb020063 	sub	x3, x3, x2
    8f90:	9ac90862 	udiv	x2, x3, x9
    8f94:	aa0203e8 	mov	x8, x2
    8f98:	9b098c42 	msub	x2, x2, x9, x3
    8f9c:	aa0703e3 	mov	x3, x7
    8fa0:	9b057d05 	mul	x5, x8, x5
    8fa4:	b3607c43 	bfi	x3, x2, #32, #32
    8fa8:	eb0300bf 	cmp	x5, x3
    8fac:	540000c9 	b.ls	8fc4 <__divti3+0x284>  // b.plast
    8fb0:	ab0300c2 	adds	x2, x6, x3
    8fb4:	d1000503 	sub	x3, x8, #0x1
    8fb8:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    8fbc:	d1000908 	sub	x8, x8, #0x2
    8fc0:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    8fc4:	aa008100 	orr	x0, x8, x0, lsl #32
    8fc8:	17ffff90 	b	8e08 <__divti3+0xc8>
    8fcc:	9ac820c6 	lsl	x6, x6, x8
    8fd0:	d2800803 	mov	x3, #0x40                  	// #64
    8fd4:	cb080063 	sub	x3, x3, x8
    8fd8:	d360fcc9 	lsr	x9, x6, #32
    8fdc:	9ac82027 	lsl	x7, x1, x8
    8fe0:	92407cc5 	and	x5, x6, #0xffffffff
    8fe4:	9ac32422 	lsr	x2, x1, x3
    8fe8:	9ac32403 	lsr	x3, x0, x3
    8fec:	aa070063 	orr	x3, x3, x7
    8ff0:	9ac9084a 	udiv	x10, x2, x9
    8ff4:	9ac82007 	lsl	x7, x0, x8
    8ff8:	9b098940 	msub	x0, x10, x9, x2
    8ffc:	aa0a03e1 	mov	x1, x10
    9000:	9b0a7ca2 	mul	x2, x5, x10
    9004:	93c38000 	extr	x0, x0, x3, #32
    9008:	eb00005f 	cmp	x2, x0
    900c:	540000a9 	b.ls	9020 <__divti3+0x2e0>  // b.plast
    9010:	ab0000c0 	adds	x0, x6, x0
    9014:	d1000541 	sub	x1, x10, #0x1
    9018:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    901c:	54000468 	b.hi	90a8 <__divti3+0x368>  // b.pmore
    9020:	cb020000 	sub	x0, x0, x2
    9024:	9ac9080a 	udiv	x10, x0, x9
    9028:	9b098140 	msub	x0, x10, x9, x0
    902c:	aa0a03e2 	mov	x2, x10
    9030:	9b0a7ca8 	mul	x8, x5, x10
    9034:	b3607c03 	bfi	x3, x0, #32, #32
    9038:	eb03011f 	cmp	x8, x3
    903c:	540000a9 	b.ls	9050 <__divti3+0x310>  // b.plast
    9040:	ab0300c3 	adds	x3, x6, x3
    9044:	d1000542 	sub	x2, x10, #0x1
    9048:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    904c:	54000288 	b.hi	909c <__divti3+0x35c>  // b.pmore
    9050:	cb080063 	sub	x3, x3, x8
    9054:	aa018041 	orr	x1, x2, x1, lsl #32
    9058:	17ffffc2 	b	8f60 <__divti3+0x220>
    905c:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    9060:	d2800001 	mov	x1, #0x0                   	// #0
    9064:	9a9f87e0 	cset	x0, ls	// ls = plast
    9068:	17ffff68 	b	8e08 <__divti3+0xc8>
    906c:	aa0103e0 	mov	x0, x1
    9070:	d2800001 	mov	x1, #0x0                   	// #0
    9074:	17ffff65 	b	8e08 <__divti3+0xc8>
    9078:	d1000860 	sub	x0, x3, #0x2
    907c:	8b0600a5 	add	x5, x5, x6
    9080:	17ffff52 	b	8dc8 <__divti3+0x88>
    9084:	d1000961 	sub	x1, x11, #0x2
    9088:	8b0800a5 	add	x5, x5, x8
    908c:	17ffff85 	b	8ea0 <__divti3+0x160>
    9090:	d1000965 	sub	x5, x11, #0x2
    9094:	8b080063 	add	x3, x3, x8
    9098:	17ffff8e 	b	8ed0 <__divti3+0x190>
    909c:	d1000942 	sub	x2, x10, #0x2
    90a0:	8b060063 	add	x3, x3, x6
    90a4:	17ffffeb 	b	9050 <__divti3+0x310>
    90a8:	d1000941 	sub	x1, x10, #0x2
    90ac:	8b060000 	add	x0, x0, x6
    90b0:	17ffffdc 	b	9020 <__divti3+0x2e0>
    90b4:	d1000900 	sub	x0, x8, #0x2
    90b8:	8b060063 	add	x3, x3, x6
    90bc:	17ffffb4 	b	8f8c <__divti3+0x24c>

00000000000090c0 <__modti3>:
    90c0:	d503245f 	bti	c
    90c4:	d2800004 	mov	x4, #0x0                   	// #0
    90c8:	b6f80081 	tbz	x1, #63, 90d8 <__modti3+0x18>
    90cc:	eb0003e0 	negs	x0, x0
    90d0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    90d4:	da0103e1 	ngc	x1, x1
    90d8:	f100007f 	cmp	x3, #0x0
    90dc:	5400128b 	b.lt	932c <__modti3+0x26c>  // b.tstop
    90e0:	aa0003e7 	mov	x7, x0
    90e4:	aa0103e6 	mov	x6, x1
    90e8:	540004e1 	b.ne	9184 <__modti3+0xc4>  // b.any
    90ec:	eb02003f 	cmp	x1, x2
    90f0:	54000dc2 	b.cs	92a8 <__modti3+0x1e8>  // b.hs, b.nlast
    90f4:	dac01043 	clz	x3, x2
    90f8:	aa0303e5 	mov	x5, x3
    90fc:	b40000e3 	cbz	x3, 9118 <__modti3+0x58>
    9100:	4b0303e6 	neg	w6, w3
    9104:	9ac32021 	lsl	x1, x1, x3
    9108:	9ac32042 	lsl	x2, x2, x3
    910c:	9ac62406 	lsr	x6, x0, x6
    9110:	aa0100c6 	orr	x6, x6, x1
    9114:	9ac32007 	lsl	x7, x0, x3
    9118:	d360fc40 	lsr	x0, x2, #32
    911c:	92407c43 	and	x3, x2, #0xffffffff
    9120:	9ac008c1 	udiv	x1, x6, x0
    9124:	9b009826 	msub	x6, x1, x0, x6
    9128:	9b017c61 	mul	x1, x3, x1
    912c:	93c780c6 	extr	x6, x6, x7, #32
    9130:	eb06003f 	cmp	x1, x6
    9134:	540000a9 	b.ls	9148 <__modti3+0x88>  // b.plast
    9138:	ab060046 	adds	x6, x2, x6
    913c:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    9140:	8b0200c8 	add	x8, x6, x2
    9144:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    9148:	cb0100c6 	sub	x6, x6, x1
    914c:	9ac008c8 	udiv	x8, x6, x0
    9150:	9b009901 	msub	x1, x8, x0, x6
    9154:	aa0703e0 	mov	x0, x7
    9158:	9b087c63 	mul	x3, x3, x8
    915c:	b3607c20 	bfi	x0, x1, #32, #32
    9160:	eb00007f 	cmp	x3, x0
    9164:	54001088 	b.hi	9374 <__modti3+0x2b4>  // b.pmore
    9168:	cb030000 	sub	x0, x0, x3
    916c:	9ac52400 	lsr	x0, x0, x5
    9170:	d2800001 	mov	x1, #0x0                   	// #0
    9174:	b4000064 	cbz	x4, 9180 <__modti3+0xc0>
    9178:	eb0003e0 	negs	x0, x0
    917c:	da0103e1 	ngc	x1, x1
    9180:	d65f03c0 	ret
    9184:	dac01066 	clz	x6, x3
    9188:	eb03003f 	cmp	x1, x3
    918c:	54ffff43 	b.cc	9174 <__modti3+0xb4>  // b.lo, b.ul, b.last
    9190:	93407cc5 	sxtw	x5, w6
    9194:	d2800808 	mov	x8, #0x40                  	// #64
    9198:	cb050108 	sub	x8, x8, x5
    919c:	9ac62063 	lsl	x3, x3, x6
    91a0:	9ac62025 	lsl	x5, x1, x6
    91a4:	9ac82447 	lsr	x7, x2, x8
    91a8:	aa0300e7 	orr	x7, x7, x3
    91ac:	9ac82423 	lsr	x3, x1, x8
    91b0:	92407cec 	and	x12, x7, #0xffffffff
    91b4:	d360fcea 	lsr	x10, x7, #32
    91b8:	9ac82401 	lsr	x1, x0, x8
    91bc:	aa050021 	orr	x1, x1, x5
    91c0:	9ac62042 	lsl	x2, x2, x6
    91c4:	9ac62000 	lsl	x0, x0, x6
    91c8:	9aca086b 	udiv	x11, x3, x10
    91cc:	9b0a8d63 	msub	x3, x11, x10, x3
    91d0:	aa0b03e5 	mov	x5, x11
    91d4:	9b0b7d89 	mul	x9, x12, x11
    91d8:	93c18063 	extr	x3, x3, x1, #32
    91dc:	eb03013f 	cmp	x9, x3
    91e0:	540000a9 	b.ls	91f4 <__modti3+0x134>  // b.plast
    91e4:	ab0300e3 	adds	x3, x7, x3
    91e8:	d1000565 	sub	x5, x11, #0x1
    91ec:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    91f0:	54001168 	b.hi	941c <__modti3+0x35c>  // b.pmore
    91f4:	cb090063 	sub	x3, x3, x9
    91f8:	9aca086b 	udiv	x11, x3, x10
    91fc:	9b0a8d6a 	msub	x10, x11, x10, x3
    9200:	aa0b03e9 	mov	x9, x11
    9204:	9b0b7d8c 	mul	x12, x12, x11
    9208:	b3607d41 	bfi	x1, x10, #32, #32
    920c:	eb01019f 	cmp	x12, x1
    9210:	540000a9 	b.ls	9224 <__modti3+0x164>  // b.plast
    9214:	ab0100e1 	adds	x1, x7, x1
    9218:	d1000569 	sub	x9, x11, #0x1
    921c:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    9220:	54000f88 	b.hi	9410 <__modti3+0x350>  // b.pmore
    9224:	aa058123 	orr	x3, x9, x5, lsl #32
    9228:	92407c4b 	and	x11, x2, #0xffffffff
    922c:	2a0903e9 	mov	w9, w9
    9230:	d360fc4a 	lsr	x10, x2, #32
    9234:	d360fc63 	lsr	x3, x3, #32
    9238:	cb0c0021 	sub	x1, x1, x12
    923c:	aa0a03ec 	mov	x12, x10
    9240:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    9244:	9b0b7d25 	mul	x5, x9, x11
    9248:	9b0b7c6b 	mul	x11, x3, x11
    924c:	9b0a2d29 	madd	x9, x9, x10, x11
    9250:	92407caa 	and	x10, x5, #0xffffffff
    9254:	9b0c7c63 	mul	x3, x3, x12
    9258:	8b458125 	add	x5, x9, x5, lsr #32
    925c:	8b0d0069 	add	x9, x3, x13
    9260:	eb05017f 	cmp	x11, x5
    9264:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    9268:	8b058149 	add	x9, x10, x5, lsl #32
    926c:	8b458063 	add	x3, x3, x5, lsr #32
    9270:	eb03003f 	cmp	x1, x3
    9274:	54000063 	b.cc	9280 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    9278:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    927c:	54000082 	b.cs	928c <__modti3+0x1cc>  // b.hs, b.nlast
    9280:	eb020129 	subs	x9, x9, x2
    9284:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    9288:	cb070063 	sub	x3, x3, x7
    928c:	eb090000 	subs	x0, x0, x9
    9290:	da030021 	sbc	x1, x1, x3
    9294:	9ac62400 	lsr	x0, x0, x6
    9298:	9ac82028 	lsl	x8, x1, x8
    929c:	aa000100 	orr	x0, x8, x0
    92a0:	9ac62421 	lsr	x1, x1, x6
    92a4:	17ffffb4 	b	9174 <__modti3+0xb4>
    92a8:	b5000062 	cbnz	x2, 92b4 <__modti3+0x1f4>
    92ac:	d2800023 	mov	x3, #0x1                   	// #1
    92b0:	9ac20862 	udiv	x2, x3, x2
    92b4:	dac01048 	clz	x8, x2
    92b8:	aa0803e5 	mov	x5, x8
    92bc:	b5000668 	cbnz	x8, 9388 <__modti3+0x2c8>
    92c0:	cb020020 	sub	x0, x1, x2
    92c4:	d360fc49 	lsr	x9, x2, #32
    92c8:	92407c4a 	and	x10, x2, #0xffffffff
    92cc:	9ac90801 	udiv	x1, x0, x9
    92d0:	9b098020 	msub	x0, x1, x9, x0
    92d4:	9b0a7c21 	mul	x1, x1, x10
    92d8:	93c78000 	extr	x0, x0, x7, #32
    92dc:	eb00003f 	cmp	x1, x0
    92e0:	540000a9 	b.ls	92f4 <__modti3+0x234>  // b.plast
    92e4:	ab000040 	adds	x0, x2, x0
    92e8:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    92ec:	8b020003 	add	x3, x0, x2
    92f0:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    92f4:	cb010001 	sub	x1, x0, x1
    92f8:	9ac90820 	udiv	x0, x1, x9
    92fc:	9b098403 	msub	x3, x0, x9, x1
    9300:	aa0703e1 	mov	x1, x7
    9304:	9b0a7c00 	mul	x0, x0, x10
    9308:	b3607c61 	bfi	x1, x3, #32, #32
    930c:	eb01001f 	cmp	x0, x1
    9310:	540000a9 	b.ls	9324 <__modti3+0x264>  // b.plast
    9314:	ab010041 	adds	x1, x2, x1
    9318:	8b020022 	add	x2, x1, x2
    931c:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    9320:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    9324:	cb000020 	sub	x0, x1, x0
    9328:	17ffff91 	b	916c <__modti3+0xac>
    932c:	eb0203e5 	negs	x5, x2
    9330:	aa0003e7 	mov	x7, x0
    9334:	da0303e8 	ngc	x8, x3
    9338:	aa0503e2 	mov	x2, x5
    933c:	aa0803e3 	mov	x3, x8
    9340:	aa0103e6 	mov	x6, x1
    9344:	b4ffed48 	cbz	x8, 90ec <__modti3+0x2c>
    9348:	eb01011f 	cmp	x8, x1
    934c:	54fff148 	b.hi	9174 <__modti3+0xb4>  // b.pmore
    9350:	dac01109 	clz	x9, x8
    9354:	2a0903e6 	mov	w6, w9
    9358:	b5fff1c9 	cbnz	x9, 9190 <__modti3+0xd0>
    935c:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    9360:	54000068 	b.hi	936c <__modti3+0x2ac>  // b.pmore
    9364:	eb050007 	subs	x7, x0, x5
    9368:	da080021 	sbc	x1, x1, x8
    936c:	aa0703e0 	mov	x0, x7
    9370:	17ffff81 	b	9174 <__modti3+0xb4>
    9374:	ab000040 	adds	x0, x2, x0
    9378:	8b020002 	add	x2, x0, x2
    937c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    9380:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    9384:	17ffff79 	b	9168 <__modti3+0xa8>
    9388:	9ac82042 	lsl	x2, x2, x8
    938c:	d2800803 	mov	x3, #0x40                  	// #64
    9390:	cb080063 	sub	x3, x3, x8
    9394:	d360fc49 	lsr	x9, x2, #32
    9398:	9ac82027 	lsl	x7, x1, x8
    939c:	92407c4a 	and	x10, x2, #0xffffffff
    93a0:	9ac32426 	lsr	x6, x1, x3
    93a4:	9ac32403 	lsr	x3, x0, x3
    93a8:	aa070063 	orr	x3, x3, x7
    93ac:	9ac908c1 	udiv	x1, x6, x9
    93b0:	9ac82007 	lsl	x7, x0, x8
    93b4:	9b099820 	msub	x0, x1, x9, x6
    93b8:	9b017d41 	mul	x1, x10, x1
    93bc:	93c38000 	extr	x0, x0, x3, #32
    93c0:	eb00003f 	cmp	x1, x0
    93c4:	540000a9 	b.ls	93d8 <__modti3+0x318>  // b.plast
    93c8:	ab000040 	adds	x0, x2, x0
    93cc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    93d0:	8b020006 	add	x6, x0, x2
    93d4:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    93d8:	cb010000 	sub	x0, x0, x1
    93dc:	9ac90801 	udiv	x1, x0, x9
    93e0:	9b098026 	msub	x6, x1, x9, x0
    93e4:	aa0303e0 	mov	x0, x3
    93e8:	9b017d41 	mul	x1, x10, x1
    93ec:	b3607cc0 	bfi	x0, x6, #32, #32
    93f0:	eb00003f 	cmp	x1, x0
    93f4:	540000a9 	b.ls	9408 <__modti3+0x348>  // b.plast
    93f8:	ab000040 	adds	x0, x2, x0
    93fc:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    9400:	8b020003 	add	x3, x0, x2
    9404:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    9408:	cb010000 	sub	x0, x0, x1
    940c:	17ffffb0 	b	92cc <__modti3+0x20c>
    9410:	d1000969 	sub	x9, x11, #0x2
    9414:	8b070021 	add	x1, x1, x7
    9418:	17ffff83 	b	9224 <__modti3+0x164>
    941c:	d1000965 	sub	x5, x11, #0x2
    9420:	8b070063 	add	x3, x3, x7
    9424:	17ffff74 	b	91f4 <__modti3+0x134>
    9428:	d503201f 	nop
    942c:	d503201f 	nop

0000000000009430 <atexit>:
    9430:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9434:	f00000a2 	adrp	x2, 20000 <__data_start>
    9438:	d2800001 	mov	x1, #0x0                   	// #0
    943c:	910003fd 	mov	x29, sp
    9440:	a8c17bfd 	ldp	x29, x30, [sp], #16
    9444:	f9400442 	ldr	x2, [x2, #8]
    9448:	17ffe4ce 	b	2780 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000944c <_fini>:
    944c:	d503201f 	nop
    9450:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    9454:	910003fd 	mov	x29, sp
    9458:	a8c17bfd 	ldp	x29, x30, [sp], #16
    945c:	d65f03c0 	ret
