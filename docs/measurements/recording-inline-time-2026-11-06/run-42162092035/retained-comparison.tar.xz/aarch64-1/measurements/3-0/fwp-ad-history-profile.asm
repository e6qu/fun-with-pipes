
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history-profile:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000002628 <_init>:
    2628:	d503201f 	nop
    262c:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    2630:	910003fd 	mov	x29, sp
    2634:	940001a0 	bl	2cb4 <call_weak_fn>
    2638:	a8c17bfd 	ldp	x29, x30, [sp], #16
    263c:	d65f03c0 	ret

Disassembly of section .plt:

0000000000002640 <.plt>:
    2640:	a9bf7bf0 	stp	x16, x30, [sp, #-16]!
    2644:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2648:	f946fa11 	ldr	x17, [x16, #3568]
    264c:	9137c210 	add	x16, x16, #0xdf0
    2650:	d61f0220 	br	x17
    2654:	d503201f 	nop
    2658:	d503201f 	nop
    265c:	d503201f 	nop

0000000000002660 <memcpy@plt>:
    2660:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2664:	f946fe11 	ldr	x17, [x16, #3576]
    2668:	9137e210 	add	x16, x16, #0xdf8
    266c:	d61f0220 	br	x17

0000000000002670 <sigaltstack@plt>:
    2670:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2674:	f9470211 	ldr	x17, [x16, #3584]
    2678:	91380210 	add	x16, x16, #0xe00
    267c:	d61f0220 	br	x17

0000000000002680 <memmove@plt>:
    2680:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2684:	f9470611 	ldr	x17, [x16, #3592]
    2688:	91382210 	add	x16, x16, #0xe08
    268c:	d61f0220 	br	x17

0000000000002690 <_exit@plt>:
    2690:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2694:	f9470a11 	ldr	x17, [x16, #3600]
    2698:	91384210 	add	x16, x16, #0xe10
    269c:	d61f0220 	br	x17

00000000000026a0 <strlen@plt>:
    26a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26a4:	f9470e11 	ldr	x17, [x16, #3608]
    26a8:	91386210 	add	x16, x16, #0xe18
    26ac:	d61f0220 	br	x17

00000000000026b0 <__sprintf_chk@plt>:
    26b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26b4:	f9471211 	ldr	x17, [x16, #3616]
    26b8:	91388210 	add	x16, x16, #0xe20
    26bc:	d61f0220 	br	x17

00000000000026c0 <exit@plt>:
    26c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26c4:	f9471611 	ldr	x17, [x16, #3624]
    26c8:	9138a210 	add	x16, x16, #0xe28
    26cc:	d61f0220 	br	x17

00000000000026d0 <__libc_start_main@plt>:
    26d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26d4:	f9471a11 	ldr	x17, [x16, #3632]
    26d8:	9138c210 	add	x16, x16, #0xe30
    26dc:	d61f0220 	br	x17

00000000000026e0 <strtoll@plt>:
    26e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26e4:	f9471e11 	ldr	x17, [x16, #3640]
    26e8:	9138e210 	add	x16, x16, #0xe38
    26ec:	d61f0220 	br	x17

00000000000026f0 <strtod@plt>:
    26f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    26f4:	f9472211 	ldr	x17, [x16, #3648]
    26f8:	91390210 	add	x16, x16, #0xe40
    26fc:	d61f0220 	br	x17

0000000000002700 <__cxa_finalize@plt>:
    2700:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2704:	f9472611 	ldr	x17, [x16, #3656]
    2708:	91392210 	add	x16, x16, #0xe48
    270c:	d61f0220 	br	x17

0000000000002710 <__cxa_atexit@plt>:
    2710:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2714:	f9472a11 	ldr	x17, [x16, #3664]
    2718:	91394210 	add	x16, x16, #0xe50
    271c:	d61f0220 	br	x17

0000000000002720 <pthread_attr_init@plt>:
    2720:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2724:	f9472e11 	ldr	x17, [x16, #3672]
    2728:	91396210 	add	x16, x16, #0xe58
    272c:	d61f0220 	br	x17

0000000000002730 <fputc@plt>:
    2730:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2734:	f9473211 	ldr	x17, [x16, #3680]
    2738:	91398210 	add	x16, x16, #0xe60
    273c:	d61f0220 	br	x17

0000000000002740 <clock_gettime@plt>:
    2740:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2744:	f9473611 	ldr	x17, [x16, #3688]
    2748:	9139a210 	add	x16, x16, #0xe68
    274c:	d61f0220 	br	x17

0000000000002750 <setvbuf@plt>:
    2750:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2754:	f9473a11 	ldr	x17, [x16, #3696]
    2758:	9139c210 	add	x16, x16, #0xe70
    275c:	d61f0220 	br	x17

0000000000002760 <__memcpy_chk@plt>:
    2760:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2764:	f9473e11 	ldr	x17, [x16, #3704]
    2768:	9139e210 	add	x16, x16, #0xe78
    276c:	d61f0220 	br	x17

0000000000002770 <signal@plt>:
    2770:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2774:	f9474211 	ldr	x17, [x16, #3712]
    2778:	913a0210 	add	x16, x16, #0xe80
    277c:	d61f0220 	br	x17

0000000000002780 <__snprintf_chk@plt>:
    2780:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2784:	f9474611 	ldr	x17, [x16, #3720]
    2788:	913a2210 	add	x16, x16, #0xe88
    278c:	d61f0220 	br	x17

0000000000002790 <fclose@plt>:
    2790:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2794:	f9474a11 	ldr	x17, [x16, #3728]
    2798:	913a4210 	add	x16, x16, #0xe90
    279c:	d61f0220 	br	x17

00000000000027a0 <fopen@plt>:
    27a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27a4:	f9474e11 	ldr	x17, [x16, #3736]
    27a8:	913a6210 	add	x16, x16, #0xe98
    27ac:	d61f0220 	br	x17

00000000000027b0 <malloc@plt>:
    27b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27b4:	f9475211 	ldr	x17, [x16, #3744]
    27b8:	913a8210 	add	x16, x16, #0xea0
    27bc:	d61f0220 	br	x17

00000000000027c0 <pthread_attr_destroy@plt>:
    27c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27c4:	f9475611 	ldr	x17, [x16, #3752]
    27c8:	913aa210 	add	x16, x16, #0xea8
    27cc:	d61f0220 	br	x17

00000000000027d0 <sigemptyset@plt>:
    27d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27d4:	f9475a11 	ldr	x17, [x16, #3760]
    27d8:	913ac210 	add	x16, x16, #0xeb0
    27dc:	d61f0220 	br	x17

00000000000027e0 <memset@plt>:
    27e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27e4:	f9475e11 	ldr	x17, [x16, #3768]
    27e8:	913ae210 	add	x16, x16, #0xeb8
    27ec:	d61f0220 	br	x17

00000000000027f0 <calloc@plt>:
    27f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    27f4:	f9476211 	ldr	x17, [x16, #3776]
    27f8:	913b0210 	add	x16, x16, #0xec0
    27fc:	d61f0220 	br	x17

0000000000002800 <realloc@plt>:
    2800:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2804:	f9476611 	ldr	x17, [x16, #3784]
    2808:	913b2210 	add	x16, x16, #0xec8
    280c:	d61f0220 	br	x17

0000000000002810 <__stack_chk_fail@plt>:
    2810:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2814:	f9476a11 	ldr	x17, [x16, #3792]
    2818:	913b4210 	add	x16, x16, #0xed0
    281c:	d61f0220 	br	x17

0000000000002820 <close@plt>:
    2820:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2824:	f9476e11 	ldr	x17, [x16, #3800]
    2828:	913b6210 	add	x16, x16, #0xed8
    282c:	d61f0220 	br	x17

0000000000002830 <sigaction@plt>:
    2830:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2834:	f9477211 	ldr	x17, [x16, #3808]
    2838:	913b8210 	add	x16, x16, #0xee0
    283c:	d61f0220 	br	x17

0000000000002840 <__gmon_start__@plt>:
    2840:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2844:	f9477611 	ldr	x17, [x16, #3816]
    2848:	913ba210 	add	x16, x16, #0xee8
    284c:	d61f0220 	br	x17

0000000000002850 <write@plt>:
    2850:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2854:	f9477a11 	ldr	x17, [x16, #3824]
    2858:	913bc210 	add	x16, x16, #0xef0
    285c:	d61f0220 	br	x17

0000000000002860 <abort@plt>:
    2860:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2864:	f9477e11 	ldr	x17, [x16, #3832]
    2868:	913be210 	add	x16, x16, #0xef8
    286c:	d61f0220 	br	x17

0000000000002870 <swapcontext@plt>:
    2870:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2874:	f9478211 	ldr	x17, [x16, #3840]
    2878:	913c0210 	add	x16, x16, #0xf00
    287c:	d61f0220 	br	x17

0000000000002880 <__fprintf_chk@plt>:
    2880:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2884:	f9478611 	ldr	x17, [x16, #3848]
    2888:	913c2210 	add	x16, x16, #0xf08
    288c:	d61f0220 	br	x17

0000000000002890 <strcmp@plt>:
    2890:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2894:	f9478a11 	ldr	x17, [x16, #3856]
    2898:	913c4210 	add	x16, x16, #0xf10
    289c:	d61f0220 	br	x17

00000000000028a0 <mmap@plt>:
    28a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28a4:	f9478e11 	ldr	x17, [x16, #3864]
    28a8:	913c6210 	add	x16, x16, #0xf18
    28ac:	d61f0220 	br	x17

00000000000028b0 <strtol@plt>:
    28b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28b4:	f9479211 	ldr	x17, [x16, #3872]
    28b8:	913c8210 	add	x16, x16, #0xf20
    28bc:	d61f0220 	br	x17

00000000000028c0 <strtof@plt>:
    28c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28c4:	f9479611 	ldr	x17, [x16, #3880]
    28c8:	913ca210 	add	x16, x16, #0xf28
    28cc:	d61f0220 	br	x17

00000000000028d0 <free@plt>:
    28d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28d4:	f9479a11 	ldr	x17, [x16, #3888]
    28d8:	913cc210 	add	x16, x16, #0xf30
    28dc:	d61f0220 	br	x17

00000000000028e0 <nanosleep@plt>:
    28e0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28e4:	f9479e11 	ldr	x17, [x16, #3896]
    28e8:	913ce210 	add	x16, x16, #0xf38
    28ec:	d61f0220 	br	x17

00000000000028f0 <strchr@plt>:
    28f0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    28f4:	f947a211 	ldr	x17, [x16, #3904]
    28f8:	913d0210 	add	x16, x16, #0xf40
    28fc:	d61f0220 	br	x17

0000000000002900 <strtoull@plt>:
    2900:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2904:	f947a611 	ldr	x17, [x16, #3912]
    2908:	913d2210 	add	x16, x16, #0xf48
    290c:	d61f0220 	br	x17

0000000000002910 <fwrite@plt>:
    2910:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2914:	f947aa11 	ldr	x17, [x16, #3920]
    2918:	913d4210 	add	x16, x16, #0xf50
    291c:	d61f0220 	br	x17

0000000000002920 <pthread_create@plt>:
    2920:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2924:	f947ae11 	ldr	x17, [x16, #3928]
    2928:	913d6210 	add	x16, x16, #0xf58
    292c:	d61f0220 	br	x17

0000000000002930 <munmap@plt>:
    2930:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2934:	f947b211 	ldr	x17, [x16, #3936]
    2938:	913d8210 	add	x16, x16, #0xf60
    293c:	d61f0220 	br	x17

0000000000002940 <fflush@plt>:
    2940:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2944:	f947b611 	ldr	x17, [x16, #3944]
    2948:	913da210 	add	x16, x16, #0xf68
    294c:	d61f0220 	br	x17

0000000000002950 <strcpy@plt>:
    2950:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2954:	f947ba11 	ldr	x17, [x16, #3952]
    2958:	913dc210 	add	x16, x16, #0xf70
    295c:	d61f0220 	br	x17

0000000000002960 <sysconf@plt>:
    2960:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2964:	f947be11 	ldr	x17, [x16, #3960]
    2968:	913de210 	add	x16, x16, #0xf78
    296c:	d61f0220 	br	x17

0000000000002970 <strstr@plt>:
    2970:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2974:	f947c211 	ldr	x17, [x16, #3968]
    2978:	913e0210 	add	x16, x16, #0xf80
    297c:	d61f0220 	br	x17

0000000000002980 <_Exit@plt>:
    2980:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2984:	f947c611 	ldr	x17, [x16, #3976]
    2988:	913e2210 	add	x16, x16, #0xf88
    298c:	d61f0220 	br	x17

0000000000002990 <pthread_join@plt>:
    2990:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    2994:	f947ca11 	ldr	x17, [x16, #3984]
    2998:	913e4210 	add	x16, x16, #0xf90
    299c:	d61f0220 	br	x17

00000000000029a0 <getenv@plt>:
    29a0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29a4:	f947ce11 	ldr	x17, [x16, #3992]
    29a8:	913e6210 	add	x16, x16, #0xf98
    29ac:	d61f0220 	br	x17

00000000000029b0 <mprotect@plt>:
    29b0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29b4:	f947d211 	ldr	x17, [x16, #4000]
    29b8:	913e8210 	add	x16, x16, #0xfa0
    29bc:	d61f0220 	br	x17

00000000000029c0 <fgets@plt>:
    29c0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29c4:	f947d611 	ldr	x17, [x16, #4008]
    29c8:	913ea210 	add	x16, x16, #0xfa8
    29cc:	d61f0220 	br	x17

00000000000029d0 <pthread_attr_setstacksize@plt>:
    29d0:	b00000f0 	adrp	x16, 1f000 <fwp_fn_table+0xb30>
    29d4:	f947da11 	ldr	x17, [x16, #4016]
    29d8:	913ec210 	add	x16, x16, #0xfb0
    29dc:	d61f0220 	br	x17

Disassembly of section .text:

0000000000002a00 <fwp_trap_overflow.constprop.0>:
    2a00:	d10243ff 	sub	sp, sp, #0x90
    2a04:	d2800c03 	mov	x3, #0x60                  	// #96
    2a08:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2a0c:	f947f421 	ldr	x1, [x1, #4072]
    2a10:	b0000045 	adrp	x5, b000 <__modti3+0x2a0>
    2a14:	a9077bfd 	stp	x29, x30, [sp, #112]
    2a18:	9101c3fd 	add	x29, sp, #0x70
    2a1c:	911780a5 	add	x5, x5, #0x5e0
    2a20:	b0000044 	adrp	x4, b000 <__modti3+0x2a0>
    2a24:	f90043f3 	str	x19, [sp, #128]
    2a28:	9117a084 	add	x4, x4, #0x5e8
    2a2c:	910023f3 	add	x19, sp, #0x8
    2a30:	f9400022 	ldr	x2, [x1]
    2a34:	f90037e2 	str	x2, [sp, #104]
    2a38:	d2800002 	mov	x2, #0x0                   	// #0
    2a3c:	aa0303e1 	mov	x1, x3
    2a40:	52800042 	mov	w2, #0x2                   	// #2
    2a44:	aa1303e0 	mov	x0, x19
    2a48:	97ffff4e 	bl	2780 <__snprintf_chk@plt>
    2a4c:	aa1303e0 	mov	x0, x19
    2a50:	94000619 	bl	42b4 <fwp_trap>
    2a54:	d503201f 	nop
    2a58:	d503201f 	nop
    2a5c:	d503201f 	nop

0000000000002a60 <main>:
    2a60:	d10243ff 	sub	sp, sp, #0x90
    2a64:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2a68:	f947f400 	ldr	x0, [x0, #4072]
    2a6c:	a9067bfd 	stp	x29, x30, [sp, #96]
    2a70:	910183fd 	add	x29, sp, #0x60
    2a74:	a90753f3 	stp	x19, x20, [sp, #112]
    2a78:	b00000f4 	adrp	x20, 1f000 <fwp_fn_table+0xb30>
    2a7c:	f947ee94 	ldr	x20, [x20, #4056]
    2a80:	f9400282 	ldr	x2, [x20]
    2a84:	f90043f5 	str	x21, [sp, #128]
    2a88:	d00000f5 	adrp	x21, 20000 <__data_start>
    2a8c:	910142a1 	add	x1, x21, #0x50
    2a90:	f9400003 	ldr	x3, [x0]
    2a94:	f9002fe3 	str	x3, [sp, #88]
    2a98:	d2800003 	mov	x3, #0x0                   	// #0
    2a9c:	900000e0 	adrp	x0, 1e000 <__FRAME_END__+0x10ad8>
    2aa0:	91134000 	add	x0, x0, #0x4d0
    2aa4:	f9004822 	str	x2, [x1, #144]
    2aa8:	f9008c20 	str	x0, [x1, #280]
    2aac:	94000821 	bl	4b30 <fwp_now_ns>
    2ab0:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2ab4:	9126a000 	add	x0, x0, #0x9a8
    2ab8:	97ffffba 	bl	29a0 <getenv@plt>
    2abc:	b4000080 	cbz	x0, 2acc <main+0x6c>
    2ac0:	39400001 	ldrb	w1, [x0]
    2ac4:	aa0003f3 	mov	x19, x0
    2ac8:	350008c1 	cbnz	w1, 2be0 <main+0x180>
    2acc:	910023e1 	add	x1, sp, #0x8
    2ad0:	52800000 	mov	w0, #0x0                   	// #0
    2ad4:	97ffff1b 	bl	2740 <clock_gettime@plt>
    2ad8:	350007e0 	cbnz	w0, 2bd4 <main+0x174>
    2adc:	a9408be0 	ldp	x0, x2, [sp, #8]
    2ae0:	d2994003 	mov	x3, #0xca00                	// #51712
    2ae4:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    2ae8:	9b037c01 	mul	x1, x0, x3
    2aec:	9b437c00 	smulh	x0, x0, x3
    2af0:	ab020021 	adds	x1, x1, x2
    2af4:	937ffc42 	asr	x2, x2, #63
    2af8:	9a020000 	adc	x0, x0, x2
    2afc:	f100003f 	cmp	x1, #0x0
    2b00:	9a80a400 	cinc	x0, x0, lt	// lt = tstop
    2b04:	b5000620 	cbnz	x0, 2bc8 <main+0x168>
    2b08:	f9400280 	ldr	x0, [x20]
    2b0c:	d2a00023 	mov	x3, #0x10000               	// #65536
    2b10:	52800002 	mov	w2, #0x0                   	// #0
    2b14:	d2800001 	mov	x1, #0x0                   	// #0
    2b18:	910063f3 	add	x19, sp, #0x18
    2b1c:	97ffff0d 	bl	2750 <setvbuf@plt>
    2b20:	d2800021 	mov	x1, #0x1                   	// #1
    2b24:	528001a0 	mov	w0, #0xd                   	// #13
    2b28:	97ffff12 	bl	2770 <signal@plt>
    2b2c:	aa1303e0 	mov	x0, x19
    2b30:	97fffefc 	bl	2720 <pthread_attr_init@plt>
    2b34:	350007a0 	cbnz	w0, 2c28 <main+0x1c8>
    2b38:	aa1303e0 	mov	x0, x19
    2b3c:	d2a80001 	mov	x1, #0x40000000            	// #1073741824
    2b40:	97ffffa4 	bl	29d0 <pthread_attr_setstacksize@plt>
    2b44:	35000660 	cbnz	w0, 2c10 <main+0x1b0>
    2b48:	aa1303e1 	mov	x1, x19
    2b4c:	910023e0 	add	x0, sp, #0x8
    2b50:	f0000022 	adrp	x2, 9000 <fwp_write+0x350>
    2b54:	d2800003 	mov	x3, #0x0                   	// #0
    2b58:	91328042 	add	x2, x2, #0xca0
    2b5c:	97ffff71 	bl	2920 <pthread_create@plt>
    2b60:	2a0003e1 	mov	w1, w0
    2b64:	aa1303e0 	mov	x0, x19
    2b68:	2a0103f3 	mov	w19, w1
    2b6c:	97ffff15 	bl	27c0 <pthread_attr_destroy@plt>
    2b70:	350006a0 	cbnz	w0, 2c44 <main+0x1e4>
    2b74:	35000613 	cbnz	w19, 2c34 <main+0x1d4>
    2b78:	f94007e0 	ldr	x0, [sp, #8]
    2b7c:	d2800001 	mov	x1, #0x0                   	// #0
    2b80:	97ffff84 	bl	2990 <pthread_join@plt>
    2b84:	35000600 	cbnz	w0, 2c44 <main+0x1e4>
    2b88:	f9400280 	ldr	x0, [x20]
    2b8c:	910142b5 	add	x21, x21, #0x50
    2b90:	97ffff6c 	bl	2940 <fflush@plt>
    2b94:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2b98:	f947f421 	ldr	x1, [x1, #4072]
    2b9c:	b943daa0 	ldr	w0, [x21, #984]
    2ba0:	f9402fe3 	ldr	x3, [sp, #88]
    2ba4:	f9400022 	ldr	x2, [x1]
    2ba8:	eb020063 	subs	x3, x3, x2
    2bac:	d2800002 	mov	x2, #0x0                   	// #0
    2bb0:	54000481 	b.ne	2c40 <main+0x1e0>  // b.any
    2bb4:	a9467bfd 	ldp	x29, x30, [sp, #96]
    2bb8:	a94753f3 	ldp	x19, x20, [sp, #112]
    2bbc:	f94043f5 	ldr	x21, [sp, #128]
    2bc0:	910243ff 	add	sp, sp, #0x90
    2bc4:	d65f03c0 	ret
    2bc8:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2bcc:	91276000 	add	x0, x0, #0x9d8
    2bd0:	940005b9 	bl	42b4 <fwp_trap>
    2bd4:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2bd8:	9126e000 	add	x0, x0, #0x9b8
    2bdc:	940005b6 	bl	42b4 <fwp_trap>
    2be0:	910003e1 	mov	x1, sp
    2be4:	52800142 	mov	w2, #0xa                   	// #10
    2be8:	97ffff46 	bl	2900 <strtoull@plt>
    2bec:	f94003e0 	ldr	x0, [sp]
    2bf0:	39400000 	ldrb	w0, [x0]
    2bf4:	35fff6c0 	cbnz	w0, 2acc <main+0x6c>
    2bf8:	39400260 	ldrb	w0, [x19]
    2bfc:	52801fa1 	mov	w1, #0xfd                  	// #253
    2c00:	5100ac00 	sub	w0, w0, #0x2b
    2c04:	6a01001f 	tst	w0, w1
    2c08:	54fff620 	b.eq	2acc <main+0x6c>  // b.none
    2c0c:	17ffffbf 	b	2b08 <main+0xa8>
    2c10:	aa1303e0 	mov	x0, x19
    2c14:	97fffeeb 	bl	27c0 <pthread_attr_destroy@plt>
    2c18:	35000160 	cbnz	w0, 2c44 <main+0x1e4>
    2c1c:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2c20:	9128c000 	add	x0, x0, #0xa30
    2c24:	940005a4 	bl	42b4 <fwp_trap>
    2c28:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2c2c:	91280000 	add	x0, x0, #0xa00
    2c30:	940005a1 	bl	42b4 <fwp_trap>
    2c34:	b0000040 	adrp	x0, b000 <__modti3+0x2a0>
    2c38:	91296000 	add	x0, x0, #0xa58
    2c3c:	9400059e 	bl	42b4 <fwp_trap>
    2c40:	97fffef4 	bl	2810 <__stack_chk_fail@plt>
    2c44:	97ffff07 	bl	2860 <abort@plt>
    2c48:	d503201f 	nop
    2c4c:	d503201f 	nop
    2c50:	d503201f 	nop
    2c54:	d503201f 	nop
    2c58:	d503201f 	nop
    2c5c:	d503201f 	nop
    2c60:	d503201f 	nop
    2c64:	d503201f 	nop
    2c68:	d503201f 	nop
    2c6c:	d503201f 	nop
    2c70:	d503201f 	nop
    2c74:	d503201f 	nop
    2c78:	d503201f 	nop
    2c7c:	d503201f 	nop

0000000000002c80 <_start>:
    2c80:	d503201f 	nop
    2c84:	d280001d 	mov	x29, #0x0                   	// #0
    2c88:	d280001e 	mov	x30, #0x0                   	// #0
    2c8c:	aa0003e5 	mov	x5, x0
    2c90:	f94003e1 	ldr	x1, [sp]
    2c94:	910023e2 	add	x2, sp, #0x8
    2c98:	910003e6 	mov	x6, sp
    2c9c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2ca0:	f947f800 	ldr	x0, [x0, #4080]
    2ca4:	d2800003 	mov	x3, #0x0                   	// #0
    2ca8:	d2800004 	mov	x4, #0x0                   	// #0
    2cac:	97fffe89 	bl	26d0 <__libc_start_main@plt>
    2cb0:	97fffeec 	bl	2860 <abort@plt>

0000000000002cb4 <call_weak_fn>:
    2cb4:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2cb8:	f947f000 	ldr	x0, [x0, #4064]
    2cbc:	b4000040 	cbz	x0, 2cc4 <call_weak_fn+0x10>
    2cc0:	17fffee0 	b	2840 <__gmon_start__@plt>
    2cc4:	d65f03c0 	ret
    2cc8:	d503201f 	nop
    2ccc:	d503201f 	nop

0000000000002cd0 <deregister_tm_clones>:
    2cd0:	d00000e0 	adrp	x0, 20000 <__data_start>
    2cd4:	91010000 	add	x0, x0, #0x40
    2cd8:	d00000e1 	adrp	x1, 20000 <__data_start>
    2cdc:	91010021 	add	x1, x1, #0x40
    2ce0:	eb00003f 	cmp	x1, x0
    2ce4:	540000c0 	b.eq	2cfc <deregister_tm_clones+0x2c>  // b.none
    2ce8:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2cec:	f947e021 	ldr	x1, [x1, #4032]
    2cf0:	b4000061 	cbz	x1, 2cfc <deregister_tm_clones+0x2c>
    2cf4:	aa0103f0 	mov	x16, x1
    2cf8:	d61f0200 	br	x16
    2cfc:	d65f03c0 	ret

0000000000002d00 <register_tm_clones>:
    2d00:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d04:	91010000 	add	x0, x0, #0x40
    2d08:	d00000e1 	adrp	x1, 20000 <__data_start>
    2d0c:	91010021 	add	x1, x1, #0x40
    2d10:	cb000021 	sub	x1, x1, x0
    2d14:	d37ffc22 	lsr	x2, x1, #63
    2d18:	8b810c41 	add	x1, x2, x1, asr #3
    2d1c:	9341fc21 	asr	x1, x1, #1
    2d20:	b40000c1 	cbz	x1, 2d38 <register_tm_clones+0x38>
    2d24:	b00000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    2d28:	f947fc42 	ldr	x2, [x2, #4088]
    2d2c:	b4000062 	cbz	x2, 2d38 <register_tm_clones+0x38>
    2d30:	aa0203f0 	mov	x16, x2
    2d34:	d61f0200 	br	x16
    2d38:	d65f03c0 	ret
    2d3c:	d503201f 	nop

0000000000002d40 <__do_global_dtors_aux>:
    2d40:	d503233f 	paciasp
    2d44:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2d48:	910003fd 	mov	x29, sp
    2d4c:	f9000bf3 	str	x19, [sp, #16]
    2d50:	d00000f3 	adrp	x19, 20000 <__data_start>
    2d54:	39410260 	ldrb	w0, [x19, #64]
    2d58:	37000140 	tbnz	w0, #0, 2d80 <__do_global_dtors_aux+0x40>
    2d5c:	b00000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    2d60:	f947e400 	ldr	x0, [x0, #4040]
    2d64:	b4000080 	cbz	x0, 2d74 <__do_global_dtors_aux+0x34>
    2d68:	d00000e0 	adrp	x0, 20000 <__data_start>
    2d6c:	f9400400 	ldr	x0, [x0, #8]
    2d70:	97fffe64 	bl	2700 <__cxa_finalize@plt>
    2d74:	97ffffd7 	bl	2cd0 <deregister_tm_clones>
    2d78:	52800020 	mov	w0, #0x1                   	// #1
    2d7c:	39010260 	strb	w0, [x19, #64]
    2d80:	f9400bf3 	ldr	x19, [sp, #16]
    2d84:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2d88:	d50323bf 	autiasp
    2d8c:	d65f03c0 	ret

0000000000002d90 <frame_dummy>:
    2d90:	d503245f 	bti	c
    2d94:	17ffffdb 	b	2d00 <register_tm_clones>
    2d98:	d503201f 	nop
    2d9c:	d503201f 	nop

0000000000002da0 <fwp_fmt_u128>:
    2da0:	d10183ff 	sub	sp, sp, #0x60
    2da4:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2da8:	f947f421 	ldr	x1, [x1, #4072]
    2dac:	a9057bfd 	stp	x29, x30, [sp, #80]
    2db0:	910143fd 	add	x29, sp, #0x50
    2db4:	f9400024 	ldr	x4, [x1]
    2db8:	f90027e4 	str	x4, [sp, #72]
    2dbc:	d2800004 	mov	x4, #0x0                   	// #0
    2dc0:	aa030041 	orr	x1, x2, x3
    2dc4:	b5000361 	cbnz	x1, 2e30 <fwp_fmt_u128+0x90>
    2dc8:	910023e9 	add	x9, sp, #0x8
    2dcc:	52800601 	mov	w1, #0x30                  	// #48
    2dd0:	5280002d 	mov	w13, #0x1                   	// #1
    2dd4:	390023e1 	strb	w1, [sp, #8]
    2dd8:	93407dad 	sxtw	x13, w13
    2ddc:	aa0d03e1 	mov	x1, x13
    2de0:	8b0d0004 	add	x4, x0, x13
    2de4:	d503201f 	nop
    2de8:	8b010123 	add	x3, x9, x1
    2dec:	cb0103e2 	neg	x2, x1
    2df0:	d1000421 	sub	x1, x1, #0x1
    2df4:	385ff063 	ldurb	w3, [x3, #-1]
    2df8:	38226883 	strb	w3, [x4, x2]
    2dfc:	35ffff61 	cbnz	w1, 2de8 <fwp_fmt_u128+0x48>
    2e00:	b00000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    2e04:	f947f421 	ldr	x1, [x1, #4072]
    2e08:	382d681f 	strb	wzr, [x0, x13]
    2e0c:	aa0103e0 	mov	x0, x1
    2e10:	f94027e2 	ldr	x2, [sp, #72]
    2e14:	f9400001 	ldr	x1, [x0]
    2e18:	eb010042 	subs	x2, x2, x1
    2e1c:	d2800001 	mov	x1, #0x0                   	// #0
    2e20:	54000561 	b.ne	2ecc <fwp_fmt_u128+0x12c>  // b.any
    2e24:	a9457bfd 	ldp	x29, x30, [sp, #80]
    2e28:	910183ff 	add	sp, sp, #0x60
    2e2c:	d65f03c0 	ret
    2e30:	d0000041 	adrp	x1, c000 <_IO_stdin_used+0xf00>
    2e34:	91024021 	add	x1, x1, #0x90
    2e38:	b202e7ef 	mov	x15, #0xcccccccccccccccc    	// #-3689348814741910324
    2e3c:	910023e9 	add	x9, sp, #0x8
    2e40:	d2800027 	mov	x7, #0x1                   	// #1
    2e44:	f29999af 	movk	x15, #0xcccd
    2e48:	a9402826 	ldp	x6, x10, [x1]
    2e4c:	d503201f 	nop
    2e50:	ab030041 	adds	x1, x2, x3
    2e54:	9a813421 	cinc	x1, x1, cs	// cs = hs, nlast
    2e58:	aa0303eb 	mov	x11, x3
    2e5c:	8b070128 	add	x8, x9, x7
    2e60:	aa0203ee 	mov	x14, x2
    2e64:	aa0703ed 	mov	x13, x7
    2e68:	910004e7 	add	x7, x7, #0x1
    2e6c:	9bcf7c24 	umulh	x4, x1, x15
    2e70:	927ef485 	and	x5, x4, #0xfffffffffffffffc
    2e74:	8b4408a4 	add	x4, x5, x4, lsr #2
    2e78:	cb040021 	sub	x1, x1, x4
    2e7c:	eb010041 	subs	x1, x2, x1
    2e80:	da1f0063 	sbc	x3, x3, xzr
    2e84:	9bc67c24 	umulh	x4, x1, x6
    2e88:	9b061064 	madd	x4, x3, x6, x4
    2e8c:	9b067c2c 	mul	x12, x1, x6
    2e90:	9b0a1024 	madd	x4, x1, x10, x4
    2e94:	9bc67c25 	umulh	x5, x1, x6
    2e98:	9b061465 	madd	x5, x3, x6, x5
    2e9c:	9b0a1425 	madd	x5, x1, x10, x5
    2ea0:	93cc0484 	extr	x4, x4, x12, #1
    2ea4:	8b040884 	add	x4, x4, x4, lsl #2
    2ea8:	d341fca3 	lsr	x3, x5, #1
    2eac:	cb040444 	sub	x4, x2, x4, lsl #1
    2eb0:	93cc04a2 	extr	x2, x5, x12, #1
    2eb4:	1100c084 	add	w4, w4, #0x30
    2eb8:	381ff104 	sturb	w4, [x8, #-1]
    2ebc:	b5fffcab 	cbnz	x11, 2e50 <fwp_fmt_u128+0xb0>
    2ec0:	f10025df 	cmp	x14, #0x9
    2ec4:	54fffc68 	b.hi	2e50 <fwp_fmt_u128+0xb0>  // b.pmore
    2ec8:	17ffffc4 	b	2dd8 <fwp_fmt_u128+0x38>
    2ecc:	97fffe51 	bl	2810 <__stack_chk_fail@plt>

0000000000002ed0 <fwp_range_release>:
    2ed0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    2ed4:	910003fd 	mov	x29, sp
    2ed8:	f9400801 	ldr	x1, [x0, #16]
    2edc:	f9000bf3 	str	x19, [sp, #16]
    2ee0:	aa0003f3 	mov	x19, x0
    2ee4:	b4000061 	cbz	x1, 2ef0 <fwp_range_release+0x20>
    2ee8:	f9400400 	ldr	x0, [x0, #8]
    2eec:	d63f0020 	blr	x1
    2ef0:	f9400260 	ldr	x0, [x19]
    2ef4:	f9400e61 	ldr	x1, [x19, #24]
    2ef8:	f9400bf3 	ldr	x19, [sp, #16]
    2efc:	aa0103f0 	mov	x16, x1
    2f00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    2f04:	d61f0200 	br	x16
    2f08:	d503201f 	nop
    2f0c:	d503201f 	nop

0000000000002f10 <ad_raw_record>:
    2f10:	2a0303e4 	mov	w4, w3
    2f14:	d00000e7 	adrp	x7, 20000 <__data_start>
    2f18:	910140e6 	add	x6, x7, #0x50
    2f1c:	b9001003 	str	w3, [x0, #16]
    2f20:	f940040c 	ldr	x12, [x0, #8]
    2f24:	910080ca 	add	x10, x6, #0x20
    2f28:	f86478c5 	ldr	x5, [x6, x4, lsl #3]
    2f2c:	910100c9 	add	x9, x6, #0x40
    2f30:	910180cb 	add	x11, x6, #0x60
    2f34:	a9000801 	stp	x1, x2, [x0]
    2f38:	cb0c00a1 	sub	x1, x5, x12
    2f3c:	f8647948 	ldr	x8, [x10, x4, lsl #3]
    2f40:	8b020021 	add	x1, x1, x2
    2f44:	f8647925 	ldr	x5, [x9, x4, lsl #3]
    2f48:	91000508 	add	x8, x8, #0x1
    2f4c:	f864796c 	ldr	x12, [x11, x4, lsl #3]
    2f50:	8b0200a5 	add	x5, x5, x2
    2f54:	f8247948 	str	x8, [x10, x4, lsl #3]
    2f58:	f8247925 	str	x5, [x9, x4, lsl #3]
    2f5c:	f82478c1 	str	x1, [x6, x4, lsl #3]
    2f60:	eb0c003f 	cmp	x1, x12
    2f64:	54000049 	b.ls	2f6c <ad_raw_record+0x5c>  // b.plast
    2f68:	f8247961 	str	x1, [x11, x4, lsl #3]
    2f6c:	910140e1 	add	x1, x7, #0x50
    2f70:	ad400021 	ldp	q1, q0, [x1]
    2f74:	f9404022 	ldr	x2, [x1, #128]
    2f78:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    2f7c:	5ef1b800 	addp	d0, v0.2d
    2f80:	9e660000 	fmov	x0, d0
    2f84:	eb00005f 	cmp	x2, x0
    2f88:	54000042 	b.cs	2f90 <ad_raw_record+0x80>  // b.hs, b.nlast
    2f8c:	fd004020 	str	d0, [x1, #128]
    2f90:	d65f03c0 	ret

0000000000002f94 <fwp_tape_unlink_scope>:
    2f94:	f9402803 	ldr	x3, [x0, #80]
    2f98:	b4000223 	cbz	x3, 2fdc <fwp_tape_unlink_scope+0x48>
    2f9c:	294b0402 	ldp	w2, w1, [x0, #88]
    2fa0:	37f80202 	tbnz	w2, #31, 2fe0 <fwp_tape_unlink_scope+0x4c>
    2fa4:	d00000e4 	adrp	x4, 20000 <__data_start>
    2fa8:	52800d03 	mov	w3, #0x68                  	// #104
    2fac:	f9406c84 	ldr	x4, [x4, #216]
    2fb0:	9b231043 	smaddl	x3, w2, w3, x4
    2fb4:	b9005c61 	str	w1, [x3, #92]
    2fb8:	37f800c1 	tbnz	w1, #31, 2fd0 <fwp_tape_unlink_scope+0x3c>
    2fbc:	d00000e3 	adrp	x3, 20000 <__data_start>
    2fc0:	52800d04 	mov	w4, #0x68                  	// #104
    2fc4:	f9406c63 	ldr	x3, [x3, #216]
    2fc8:	9b240c21 	smaddl	x1, w1, w4, x3
    2fcc:	b9005822 	str	w2, [x1, #88]
    2fd0:	2f000400 	mvni	v0.2s, #0x0
    2fd4:	f900281f 	str	xzr, [x0, #80]
    2fd8:	fd002c00 	str	d0, [x0, #88]
    2fdc:	d65f03c0 	ret
    2fe0:	b9000061 	str	w1, [x3]
    2fe4:	17fffff5 	b	2fb8 <fwp_tape_unlink_scope+0x24>
    2fe8:	d503201f 	nop
    2fec:	d503201f 	nop

0000000000002ff0 <fwp_args161>:
    2ff0:	d65f03c0 	ret

0000000000002ff4 <fwp_flush>:
    2ff4:	d00000e0 	adrp	x0, 20000 <__data_start>
    2ff8:	f9407000 	ldr	x0, [x0, #224]
    2ffc:	b4000120 	cbz	x0, 3020 <fwp_flush+0x2c>
    3000:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3004:	910003fd 	mov	x29, sp
    3008:	97fffe4e 	bl	2940 <fflush@plt>
    300c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3010:	f947ec00 	ldr	x0, [x0, #4056]
    3014:	a8c17bfd 	ldp	x29, x30, [sp], #16
    3018:	f9400000 	ldr	x0, [x0]
    301c:	17fffe49 	b	2940 <fflush@plt>
    3020:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3024:	f947ec00 	ldr	x0, [x0, #4056]
    3028:	f9400000 	ldr	x0, [x0]
    302c:	17fffe45 	b	2940 <fflush@plt>

0000000000003030 <fwp_segv>:
    3030:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3034:	b00000e2 	adrp	x2, 20000 <__data_start>
    3038:	91014043 	add	x3, x2, #0x50
    303c:	910003fd 	mov	x29, sp
    3040:	a90153f3 	stp	x19, x20, [sp, #16]
    3044:	2a0003f3 	mov	w19, w0
    3048:	f9404c60 	ldr	x0, [x3, #152]
    304c:	f90013f5 	str	x21, [sp, #32]
    3050:	f9400835 	ldr	x21, [x1, #16]
    3054:	b4000280 	cbz	x0, 30a4 <fwp_segv+0x74>
    3058:	f9400814 	ldr	x20, [x0, #16]
    305c:	b4000254 	cbz	x20, 30a4 <fwp_segv+0x74>
    3060:	528003c0 	mov	w0, #0x1e                  	// #30
    3064:	97fffe3f 	bl	2960 <sysconf@plt>
    3068:	f144029f 	cmp	x20, #0x100, lsl #12
    306c:	d2a00201 	mov	x1, #0x100000              	// #1048576
    3070:	9a812281 	csel	x1, x20, x1, cs	// cs = hs, nlast
    3074:	8b000294 	add	x20, x20, x0
    3078:	d1440021 	sub	x1, x1, #0x100, lsl #12
    307c:	eb0102bf 	cmp	x21, x1
    3080:	fa552280 	ccmp	x20, x21, #0x0, cs	// cs = hs, nlast
    3084:	1a9f97e0 	cset	w0, hi	// hi = pmore
    3088:	35000240 	cbnz	w0, 30d0 <fwp_segv+0xa0>
    308c:	f94013f5 	ldr	x21, [sp, #32]
    3090:	2a1303e0 	mov	w0, w19
    3094:	a94153f3 	ldp	x19, x20, [sp, #16]
    3098:	d2800001 	mov	x1, #0x0                   	// #0
    309c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    30a0:	17fffdb4 	b	2770 <signal@plt>
    30a4:	91014042 	add	x2, x2, #0x50
    30a8:	f9405040 	ldr	x0, [x2, #160]
    30ac:	b4ffff00 	cbz	x0, 308c <fwp_segv+0x5c>
    30b0:	f9405441 	ldr	x1, [x2, #168]
    30b4:	cb010000 	sub	x0, x0, x1
    30b8:	d1440001 	sub	x1, x0, #0x100, lsl #12
    30bc:	91440000 	add	x0, x0, #0x100, lsl #12
    30c0:	eb15003f 	cmp	x1, x21
    30c4:	fa559000 	ccmp	x0, x21, #0x0, ls	// ls = plast
    30c8:	1a9f97e0 	cset	w0, hi	// hi = pmore
    30cc:	34fffe00 	cbz	w0, 308c <fwp_segv+0x5c>
    30d0:	97ffffc9 	bl	2ff4 <fwp_flush>
    30d4:	b0000041 	adrp	x1, c000 <_IO_stdin_used+0xf00>
    30d8:	9101c021 	add	x1, x1, #0x70
    30dc:	d2800342 	mov	x2, #0x1a                  	// #26
    30e0:	52800040 	mov	w0, #0x2                   	// #2
    30e4:	97fffddb 	bl	2850 <write@plt>
    30e8:	52800ca0 	mov	w0, #0x65                  	// #101
    30ec:	97fffd69 	bl	2690 <_exit@plt>

00000000000030f0 <fwp_heap_oom>:
    30f0:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    30f4:	f947e863 	ldr	x3, [x3, #4048]
    30f8:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    30fc:	d2800262 	mov	x2, #0x13                  	// #19
    3100:	910003fd 	mov	x29, sp
    3104:	f9400063 	ldr	x3, [x3]
    3108:	d2800021 	mov	x1, #0x1                   	// #1
    310c:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    3110:	91042000 	add	x0, x0, #0x108
    3114:	97fffdff 	bl	2910 <fwrite@plt>
    3118:	d2800000 	mov	x0, #0x0                   	// #0
    311c:	97fffe09 	bl	2940 <fflush@plt>
    3120:	52800cc0 	mov	w0, #0x66                  	// #102
    3124:	97fffe17 	bl	2980 <_Exit@plt>
    3128:	d503201f 	nop
    312c:	d503201f 	nop

0000000000003130 <fwp_heap_chunks>:
    3130:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    3134:	910003fd 	mov	x29, sp
    3138:	a90153f3 	stp	x19, x20, [sp, #16]
    313c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3140:	d00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    3144:	9118c2a1 	add	x1, x21, #0x630
    3148:	f100041f 	cmp	x0, #0x1
    314c:	54000ca0 	b.eq	32e0 <fwp_heap_chunks+0x1b0>  // b.none
    3150:	f949f822 	ldr	x2, [x1, #5104]
    3154:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    3158:	912880a5 	add	x5, x5, #0xa20
    315c:	9118c2a1 	add	x1, x21, #0x630
    3160:	f949ec34 	ldr	x20, [x1, #5080]
    3164:	eb14005f 	cmp	x2, x20
    3168:	54000c42 	b.cs	32f0 <fwp_heap_chunks+0x1c0>  // b.hs, b.nlast
    316c:	f949fc23 	ldr	x3, [x1, #5112]
    3170:	8b020841 	add	x1, x2, x2, lsl #2
    3174:	d2800004 	mov	x4, #0x0                   	// #0
    3178:	8b010c61 	add	x1, x3, x1, lsl #3
    317c:	14000009 	b	31a0 <fwp_heap_chunks+0x70>
    3180:	91000483 	add	x3, x4, #0x1
    3184:	eb03001f 	cmp	x0, x3
    3188:	54000940 	b.eq	32b0 <fwp_heap_chunks+0x180>  // b.none
    318c:	91000442 	add	x2, x2, #0x1
    3190:	aa0303e4 	mov	x4, x3
    3194:	9100a021 	add	x1, x1, #0x28
    3198:	eb02029f 	cmp	x20, x2
    319c:	54000100 	b.eq	31bc <fwp_heap_chunks+0x8c>  // b.none
    31a0:	39400023 	ldrb	w3, [x1]
    31a4:	34fffee3 	cbz	w3, 3180 <fwp_heap_chunks+0x50>
    31a8:	91000442 	add	x2, x2, #0x1
    31ac:	9100a021 	add	x1, x1, #0x28
    31b0:	d2800004 	mov	x4, #0x0                   	// #0
    31b4:	eb02029f 	cmp	x20, x2
    31b8:	54ffff41 	b.ne	31a0 <fwp_heap_chunks+0x70>  // b.any
    31bc:	cb040294 	sub	x20, x20, x4
    31c0:	f9001bf7 	str	x23, [sp, #48]
    31c4:	9118c2b7 	add	x23, x21, #0x630
    31c8:	8b140013 	add	x19, x0, x20
    31cc:	f94a1ae1 	ldr	x1, [x23, #5168]
    31d0:	f949f2e0 	ldr	x0, [x23, #5088]
    31d4:	cb040021 	sub	x1, x1, x4
    31d8:	f90a1ae1 	str	x1, [x23, #5168]
    31dc:	eb00027f 	cmp	x19, x0
    31e0:	54000429 	b.ls	3264 <fwp_heap_chunks+0x134>  // b.plast
    31e4:	f949eae1 	ldr	x1, [x23, #5072]
    31e8:	eb01027f 	cmp	x19, x1
    31ec:	54000888 	b.hi	32fc <fwp_heap_chunks+0x1cc>  // b.pmore
    31f0:	91010276 	add	x22, x19, #0x40
    31f4:	52800062 	mov	w2, #0x3                   	// #3
    31f8:	f949dae3 	ldr	x3, [x23, #5040]
    31fc:	eb0102df 	cmp	x22, x1
    3200:	9a8192d6 	csel	x22, x22, x1, ls	// ls = plast
    3204:	cb0002c1 	sub	x1, x22, x0
    3208:	8b004060 	add	x0, x3, x0, lsl #16
    320c:	d370bc21 	lsl	x1, x1, #16
    3210:	97fffde8 	bl	29b0 <mprotect@plt>
    3214:	35000740 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3218:	528003c0 	mov	w0, #0x1e                  	// #30
    321c:	97fffdd1 	bl	2960 <sysconf@plt>
    3220:	f949f2e2 	ldr	x2, [x23, #5088]
    3224:	cb0003e5 	neg	x5, x0
    3228:	aa0003e4 	mov	x4, x0
    322c:	8b160ac1 	add	x1, x22, x22, lsl #2
    3230:	f949fee0 	ldr	x0, [x23, #5112]
    3234:	8b020843 	add	x3, x2, x2, lsl #2
    3238:	52800062 	mov	w2, #0x3                   	// #3
    323c:	8b010c01 	add	x1, x0, x1, lsl #3
    3240:	8b030c03 	add	x3, x0, x3, lsl #3
    3244:	d1000421 	sub	x1, x1, #0x1
    3248:	8a050060 	and	x0, x3, x5
    324c:	8b040021 	add	x1, x1, x4
    3250:	8a050021 	and	x1, x1, x5
    3254:	cb000021 	sub	x1, x1, x0
    3258:	97fffdd6 	bl	29b0 <mprotect@plt>
    325c:	35000500 	cbnz	w0, 32fc <fwp_heap_chunks+0x1cc>
    3260:	f909f2f6 	str	x22, [x23, #5088]
    3264:	9118c2b5 	add	x21, x21, #0x630
    3268:	d370be60 	lsl	x0, x19, #16
    326c:	f949e6a1 	ldr	x1, [x21, #5064]
    3270:	f909eeb3 	str	x19, [x21, #5080]
    3274:	eb01001f 	cmp	x0, x1
    3278:	540000e8 	b.hi	3294 <fwp_heap_chunks+0x164>  // b.pmore
    327c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3280:	aa1403e0 	mov	x0, x20
    3284:	a94153f3 	ldp	x19, x20, [sp, #16]
    3288:	f9401bf7 	ldr	x23, [sp, #48]
    328c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    3290:	d65f03c0 	ret
    3294:	f9401bf7 	ldr	x23, [sp, #48]
    3298:	f909e6a0 	str	x0, [x21, #5064]
    329c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32a0:	aa1403e0 	mov	x0, x20
    32a4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32a8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32ac:	d65f03c0 	ret
    32b0:	9118c2b5 	add	x21, x21, #0x630
    32b4:	91000441 	add	x1, x2, #0x1
    32b8:	f90000a1 	str	x1, [x5]
    32bc:	cb040054 	sub	x20, x2, x4
    32c0:	f94a1aa1 	ldr	x1, [x21, #5168]
    32c4:	cb000020 	sub	x0, x1, x0
    32c8:	f90a1aa0 	str	x0, [x21, #5168]
    32cc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    32d0:	aa1403e0 	mov	x0, x20
    32d4:	a94153f3 	ldp	x19, x20, [sp, #16]
    32d8:	a8c47bfd 	ldp	x29, x30, [sp], #64
    32dc:	d65f03c0 	ret
    32e0:	f949f422 	ldr	x2, [x1, #5096]
    32e4:	f00003a5 	adrp	x5, 7a000 <fwp_heap+0x9d0>
    32e8:	912860a5 	add	x5, x5, #0xa18
    32ec:	17ffff9c 	b	315c <fwp_heap_chunks+0x2c>
    32f0:	d2800004 	mov	x4, #0x0                   	// #0
    32f4:	f9001bf7 	str	x23, [sp, #48]
    32f8:	17ffffb3 	b	31c4 <fwp_heap_chunks+0x94>
    32fc:	97ffff7d 	bl	30f0 <fwp_heap_oom>

0000000000003300 <ad_raw_fail>:
    3300:	900000e4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    3304:	f947e884 	ldr	x4, [x4, #4048]
    3308:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    330c:	aa0003e3 	mov	x3, x0
    3310:	910003fd 	mov	x29, sp
    3314:	f9400080 	ldr	x0, [x4]
    3318:	90000042 	adrp	x2, b000 <__modti3+0x2a0>
    331c:	91048042 	add	x2, x2, #0x120
    3320:	52800041 	mov	w1, #0x2                   	// #2
    3324:	97fffd57 	bl	2880 <__fprintf_chk@plt>
    3328:	52801d00 	mov	w0, #0xe8                  	// #232
    332c:	97fffce5 	bl	26c0 <exit@plt>

0000000000003330 <ad_raw_report>:
    3330:	d10243ff 	sub	sp, sp, #0x90
    3334:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3338:	f947f400 	ldr	x0, [x0, #4072]
    333c:	a9037bfd 	stp	x29, x30, [sp, #48]
    3340:	9100c3fd 	add	x29, sp, #0x30
    3344:	a9055bf5 	stp	x21, x22, [sp, #80]
    3348:	a90663f7 	stp	x23, x24, [sp, #96]
    334c:	b00000f8 	adrp	x24, 20000 <__data_start>
    3350:	91014315 	add	x21, x24, #0x50
    3354:	a90453f3 	stp	x19, x20, [sp, #64]
    3358:	ad4002a1 	ldp	q1, q0, [x21]
    335c:	a9076bf9 	stp	x25, x26, [sp, #112]
    3360:	a90873fb 	stp	x27, x28, [sp, #128]
    3364:	4ee18400 	add	v0.2d, v0.2d, v1.2d
    3368:	f9400001 	ldr	x1, [x0]
    336c:	f90017e1 	str	x1, [sp, #40]
    3370:	d2800001 	mov	x1, #0x0                   	// #0
    3374:	5ef1b800 	addp	d0, v0.2d
    3378:	9e660014 	fmov	x20, d0
    337c:	b5000d74 	cbnz	x20, 3528 <ad_raw_report+0x1f8>
    3380:	900000f6 	adrp	x22, 1f000 <fwp_fn_table+0xb30>
    3384:	f947ead6 	ldr	x22, [x22, #4048]
    3388:	52800041 	mov	w1, #0x2                   	// #2
    338c:	f94042a3 	ldr	x3, [x21, #128]
    3390:	90000042 	adrp	x2, b000 <__modti3+0x2a0>
    3394:	f94002c0 	ldr	x0, [x22]
    3398:	9105e042 	add	x2, x2, #0x178
    339c:	f9405aa4 	ldr	x4, [x21, #176]
    33a0:	d2800005 	mov	x5, #0x0                   	// #0
    33a4:	90000059 	adrp	x25, b000 <__modti3+0x2a0>
    33a8:	9000005a 	adrp	x26, b000 <__modti3+0x2a0>
    33ac:	91076339 	add	x25, x25, #0x1d8
    33b0:	9105035a 	add	x26, x26, #0x140
    33b4:	97fffd33 	bl	2880 <__fprintf_chk@plt>
    33b8:	d2800013 	mov	x19, #0x0                   	// #0
    33bc:	b00000e0 	adrp	x0, 20000 <__data_start>
    33c0:	91004000 	add	x0, x0, #0x10
    33c4:	910023e1 	add	x1, sp, #0x8
    33c8:	9000005b 	adrp	x27, b000 <__modti3+0x2a0>
    33cc:	aa0103fc 	mov	x28, x1
    33d0:	4c40a000 	ld1	{v0.16b-v1.16b}, [x0]
    33d4:	4c00a020 	st1	{v0.16b-v1.16b}, [x1]
    33d8:	f94002c0 	ldr	x0, [x22]
    33dc:	b4000273 	cbz	x19, 3428 <ad_raw_report+0xf8>
    33e0:	910182a3 	add	x3, x21, #0x60
    33e4:	910102a2 	add	x2, x21, #0x40
    33e8:	910082a1 	add	x1, x21, #0x20
    33ec:	91052377 	add	x23, x27, #0x148
    33f0:	f9400384 	ldr	x4, [x28]
    33f4:	f8737867 	ldr	x7, [x3, x19, lsl #3]
    33f8:	aa1703e3 	mov	x3, x23
    33fc:	f8737846 	ldr	x6, [x2, x19, lsl #3]
    3400:	aa1903e2 	mov	x2, x25
    3404:	f8737825 	ldr	x5, [x1, x19, lsl #3]
    3408:	91000673 	add	x19, x19, #0x1
    340c:	52800041 	mov	w1, #0x2                   	// #2
    3410:	97fffd1c 	bl	2880 <__fprintf_chk@plt>
    3414:	f100127f 	cmp	x19, #0x4
    3418:	540001c0 	b.eq	3450 <ad_raw_report+0x120>  // b.none
    341c:	f94002c0 	ldr	x0, [x22]
    3420:	9100239c 	add	x28, x28, #0x8
    3424:	b5fffdf3 	cbnz	x19, 33e0 <ad_raw_report+0xb0>
    3428:	f8408784 	ldr	x4, [x28], #8
    342c:	aa1a03e3 	mov	x3, x26
    3430:	f94012a5 	ldr	x5, [x21, #32]
    3434:	aa1903e2 	mov	x2, x25
    3438:	f94022a6 	ldr	x6, [x21, #64]
    343c:	52800041 	mov	w1, #0x2                   	// #2
    3440:	f94032a7 	ldr	x7, [x21, #96]
    3444:	d2800033 	mov	x19, #0x1                   	// #1
    3448:	97fffd0e 	bl	2880 <__fprintf_chk@plt>
    344c:	17ffffe3 	b	33d8 <ad_raw_report+0xa8>
    3450:	f94002c3 	ldr	x3, [x22]
    3454:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    3458:	d2800262 	mov	x2, #0x13                  	// #19
    345c:	91086000 	add	x0, x0, #0x218
    3460:	d2800021 	mov	x1, #0x1                   	// #1
    3464:	97fffd2b 	bl	2910 <fwrite@plt>
    3468:	f9405ea0 	ldr	x0, [x21, #184]
    346c:	b4000360 	cbz	x0, 34d8 <ad_raw_report+0x1a8>
    3470:	b0000161 	adrp	x1, 30000 <alt.5+0xfbb0>
    3474:	b0000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    3478:	b0000162 	adrp	x2, 30000 <alt.5+0xfbb0>
    347c:	90000043 	adrp	x3, b000 <__modti3+0x2a0>
    3480:	f94002c0 	ldr	x0, [x22]
    3484:	90000055 	adrp	x21, b000 <__modti3+0x2a0>
    3488:	f9422824 	ldr	x4, [x1, #1104]
    348c:	91014318 	add	x24, x24, #0x50
    3490:	f9422ca5 	ldr	x5, [x5, #1112]
    3494:	91114033 	add	x19, x1, #0x450
    3498:	f9423046 	ldr	x6, [x2, #1120]
    349c:	91050063 	add	x3, x3, #0x140
    34a0:	9108c2b5 	add	x21, x21, #0x230
    34a4:	14000005 	b	34b8 <ad_raw_report+0x188>
    34a8:	a9401664 	ldp	x4, x5, [x19]
    34ac:	aa1703e3 	mov	x3, x23
    34b0:	f94002c0 	ldr	x0, [x22]
    34b4:	f9400a66 	ldr	x6, [x19, #16]
    34b8:	aa1503e2 	mov	x2, x21
    34bc:	52800041 	mov	w1, #0x2                   	// #2
    34c0:	97fffcf0 	bl	2880 <__fprintf_chk@plt>
    34c4:	f9405f00 	ldr	x0, [x24, #184]
    34c8:	91000694 	add	x20, x20, #0x1
    34cc:	91006273 	add	x19, x19, #0x18
    34d0:	eb14001f 	cmp	x0, x20
    34d4:	54fffea8 	b.hi	34a8 <ad_raw_report+0x178>  // b.pmore
    34d8:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    34dc:	f947f400 	ldr	x0, [x0, #4072]
    34e0:	f94017e2 	ldr	x2, [sp, #40]
    34e4:	f9400001 	ldr	x1, [x0]
    34e8:	eb010042 	subs	x2, x2, x1
    34ec:	d2800001 	mov	x1, #0x0                   	// #0
    34f0:	54000221 	b.ne	3534 <ad_raw_report+0x204>  // b.any
    34f4:	f94002c3 	ldr	x3, [x22]
    34f8:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    34fc:	a9437bfd 	ldp	x29, x30, [sp, #48]
    3500:	9109c000 	add	x0, x0, #0x270
    3504:	a94453f3 	ldp	x19, x20, [sp, #64]
    3508:	d2800082 	mov	x2, #0x4                   	// #4
    350c:	a9455bf5 	ldp	x21, x22, [sp, #80]
    3510:	d2800021 	mov	x1, #0x1                   	// #1
    3514:	a94663f7 	ldp	x23, x24, [sp, #96]
    3518:	a9476bf9 	ldp	x25, x26, [sp, #112]
    351c:	a94873fb 	ldp	x27, x28, [sp, #128]
    3520:	910243ff 	add	sp, sp, #0x90
    3524:	17fffcfb 	b	2910 <fwrite@plt>
    3528:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    352c:	91054000 	add	x0, x0, #0x150
    3530:	97ffff74 	bl	3300 <ad_raw_fail>
    3534:	97fffcb7 	bl	2810 <__stack_chk_fail@plt>
    3538:	d503201f 	nop
    353c:	d503201f 	nop

0000000000003540 <buf_grow>:
    3540:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3544:	910003fd 	mov	x29, sp
    3548:	a90153f3 	stp	x19, x20, [sp, #16]
    354c:	aa0003f4 	mov	x20, x0
    3550:	f9400400 	ldr	x0, [x0, #8]
    3554:	b100041f 	cmn	x0, #0x1
    3558:	54000400 	b.eq	35d8 <buf_grow+0x98>  // b.none
    355c:	92800022 	mov	x2, #0xfffffffffffffffe    	// #-2
    3560:	cb000042 	sub	x2, x2, x0
    3564:	eb01005f 	cmp	x2, x1
    3568:	54000383 	b.cc	35d8 <buf_grow+0x98>  // b.lo, b.ul, b.last
    356c:	f9400a82 	ldr	x2, [x20, #16]
    3570:	91000421 	add	x1, x1, #0x1
    3574:	8b000033 	add	x19, x1, x0
    3578:	eb13005f 	cmp	x2, x19
    357c:	54000242 	b.cs	35c4 <buf_grow+0x84>  // b.hs, b.nlast
    3580:	f100005f 	cmp	x2, #0x0
    3584:	b5000262 	cbnz	x2, 35d0 <buf_grow+0x90>
    3588:	d2800802 	mov	x2, #0x40                  	// #64
    358c:	eb02027f 	cmp	x19, x2
    3590:	54000068 	b.hi	359c <buf_grow+0x5c>  // b.pmore
    3594:	14000005 	b	35a8 <buf_grow+0x68>
    3598:	b7f800a2 	tbnz	x2, #63, 35ac <buf_grow+0x6c>
    359c:	d37ff842 	lsl	x2, x2, #1
    35a0:	eb02027f 	cmp	x19, x2
    35a4:	54ffffa8 	b.hi	3598 <buf_grow+0x58>  // b.pmore
    35a8:	aa0203f3 	mov	x19, x2
    35ac:	f9400280 	ldr	x0, [x20]
    35b0:	aa1303e1 	mov	x1, x19
    35b4:	97fffc93 	bl	2800 <realloc@plt>
    35b8:	b4000100 	cbz	x0, 35d8 <buf_grow+0x98>
    35bc:	f9000280 	str	x0, [x20]
    35c0:	f9000a93 	str	x19, [x20, #16]
    35c4:	a94153f3 	ldp	x19, x20, [sp, #16]
    35c8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    35cc:	d65f03c0 	ret
    35d0:	54fffe6a 	b.ge	359c <buf_grow+0x5c>  // b.tcont
    35d4:	17fffff6 	b	35ac <buf_grow+0x6c>
    35d8:	900000e3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    35dc:	f947e863 	ldr	x3, [x3, #4048]
    35e0:	d2800262 	mov	x2, #0x13                  	// #19
    35e4:	d2800021 	mov	x1, #0x1                   	// #1
    35e8:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    35ec:	91042000 	add	x0, x0, #0x108
    35f0:	f9400063 	ldr	x3, [x3]
    35f4:	97fffcc7 	bl	2910 <fwrite@plt>
    35f8:	d2800000 	mov	x0, #0x0                   	// #0
    35fc:	97fffcd1 	bl	2940 <fflush@plt>
    3600:	52800cc0 	mov	w0, #0x66                  	// #102
    3604:	97fffcdf 	bl	2980 <_Exit@plt>
    3608:	d503201f 	nop
    360c:	d503201f 	nop

0000000000003610 <buf_put>:
    3610:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3614:	910003fd 	mov	x29, sp
    3618:	a90153f3 	stp	x19, x20, [sp, #16]
    361c:	aa0003f4 	mov	x20, x0
    3620:	aa0203f3 	mov	x19, x2
    3624:	f90013f5 	str	x21, [sp, #32]
    3628:	aa0103f5 	mov	x21, x1
    362c:	aa0203e1 	mov	x1, x2
    3630:	97ffffc4 	bl	3540 <buf_grow>
    3634:	a9400283 	ldp	x3, x0, [x20]
    3638:	aa1503e1 	mov	x1, x21
    363c:	aa1303e2 	mov	x2, x19
    3640:	8b000060 	add	x0, x3, x0
    3644:	97fffc07 	bl	2660 <memcpy@plt>
    3648:	a9400680 	ldp	x0, x1, [x20]
    364c:	8b010273 	add	x19, x19, x1
    3650:	f9000693 	str	x19, [x20, #8]
    3654:	3833681f 	strb	wzr, [x0, x19]
    3658:	a94153f3 	ldp	x19, x20, [sp, #16]
    365c:	f94013f5 	ldr	x21, [sp, #32]
    3660:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3664:	d65f03c0 	ret
    3668:	d503201f 	nop
    366c:	d503201f 	nop

0000000000003670 <fwp_cancel_tree.part.0>:
    3670:	b00000e1 	adrp	x1, 20000 <__data_start>
    3674:	91014022 	add	x2, x1, #0x50
    3678:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    367c:	52800023 	mov	w3, #0x1                   	// #1
    3680:	910003fd 	mov	x29, sp
    3684:	f9404c44 	ldr	x4, [x2, #152]
    3688:	f9000bf3 	str	x19, [sp, #16]
    368c:	39014403 	strb	w3, [x0, #81]
    3690:	eb04001f 	cmp	x0, x4
    3694:	54000160 	b.eq	36c0 <fwp_cancel_tree.part.0+0x50>  // b.none
    3698:	f9402804 	ldr	x4, [x0, #80]
    369c:	f2001c9f 	tst	x4, #0xff000000ff
    36a0:	54000101 	b.ne	36c0 <fwp_cancel_tree.part.0+0x50>  // b.any
    36a4:	f9406044 	ldr	x4, [x2, #192]
    36a8:	39015003 	strb	w3, [x0, #84]
    36ac:	f900801f 	str	xzr, [x0, #256]
    36b0:	b40001e4 	cbz	x4, 36ec <fwp_cancel_tree.part.0+0x7c>
    36b4:	f9008080 	str	x0, [x4, #256]
    36b8:	91014021 	add	x1, x1, #0x50
    36bc:	f9006020 	str	x0, [x1, #192]
    36c0:	f9401413 	ldr	x19, [x0, #40]
    36c4:	b40000f3 	cbz	x19, 36e0 <fwp_cancel_tree.part.0+0x70>
    36c8:	39414261 	ldrb	w1, [x19, #80]
    36cc:	aa1303e0 	mov	x0, x19
    36d0:	37000041 	tbnz	w1, #0, 36d8 <fwp_cancel_tree.part.0+0x68>
    36d4:	97ffffe7 	bl	3670 <fwp_cancel_tree.part.0>
    36d8:	f9401a73 	ldr	x19, [x19, #48]
    36dc:	b5ffff73 	cbnz	x19, 36c8 <fwp_cancel_tree.part.0+0x58>
    36e0:	f9400bf3 	ldr	x19, [sp, #16]
    36e4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    36e8:	d65f03c0 	ret
    36ec:	f9006440 	str	x0, [x2, #200]
    36f0:	17fffff2 	b	36b8 <fwp_cancel_tree.part.0+0x48>

00000000000036f4 <fwp_finish_float>:
    36f4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    36f8:	528005c1 	mov	w1, #0x2e                  	// #46
    36fc:	910003fd 	mov	x29, sp
    3700:	f9000bf3 	str	x19, [sp, #16]
    3704:	aa0003f3 	mov	x19, x0
    3708:	97fffc7a 	bl	28f0 <strchr@plt>
    370c:	b4000080 	cbz	x0, 371c <fwp_finish_float+0x28>
    3710:	f9400bf3 	ldr	x19, [sp, #16]
    3714:	a8c27bfd 	ldp	x29, x30, [sp], #32
    3718:	d65f03c0 	ret
    371c:	aa1303e0 	mov	x0, x19
    3720:	52800ca1 	mov	w1, #0x65                  	// #101
    3724:	97fffc73 	bl	28f0 <strchr@plt>
    3728:	b5ffff40 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    372c:	90000041 	adrp	x1, b000 <__modti3+0x2a0>
    3730:	aa1303e0 	mov	x0, x19
    3734:	9109e021 	add	x1, x1, #0x278
    3738:	97fffc8e 	bl	2970 <strstr@plt>
    373c:	b5fffea0 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3740:	90000041 	adrp	x1, b000 <__modti3+0x2a0>
    3744:	aa1303e0 	mov	x0, x19
    3748:	910a0021 	add	x1, x1, #0x280
    374c:	97fffc89 	bl	2970 <strstr@plt>
    3750:	b5fffe00 	cbnz	x0, 3710 <fwp_finish_float+0x1c>
    3754:	aa1303e0 	mov	x0, x19
    3758:	97fffbd2 	bl	26a0 <strlen@plt>
    375c:	90000041 	adrp	x1, b000 <__modti3+0x2a0>
    3760:	910a2021 	add	x1, x1, #0x288
    3764:	8b000262 	add	x2, x19, x0
    3768:	79400023 	ldrh	w3, [x1]
    376c:	39400821 	ldrb	w1, [x1, #2]
    3770:	78206a63 	strh	w3, [x19, x0]
    3774:	39000841 	strb	w1, [x2, #2]
    3778:	17ffffe6 	b	3710 <fwp_finish_float+0x1c>
    377c:	d503201f 	nop

0000000000003780 <fwp_format_g.constprop.0>:
    3780:	d10483ff 	sub	sp, sp, #0x120
    3784:	90000044 	adrp	x4, b000 <__modti3+0x2a0>
    3788:	900000e2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    378c:	f947f442 	ldr	x2, [x2, #4072]
    3790:	910a4084 	add	x4, x4, #0x290
    3794:	a90b7bfd 	stp	x29, x30, [sp, #176]
    3798:	9102c3fd 	add	x29, sp, #0xb0
    379c:	d2800803 	mov	x3, #0x40                  	// #64
    37a0:	a90e63f7 	stp	x23, x24, [sp, #224]
    37a4:	93407c38 	sxtw	x24, w1
    37a8:	aa0303e1 	mov	x1, x3
    37ac:	fd008be8 	str	d8, [sp, #272]
    37b0:	1e604008 	fmov	d8, d0
    37b4:	a90c53f3 	stp	x19, x20, [sp, #192]
    37b8:	910083f4 	add	x20, sp, #0x20
    37bc:	a90d5bf5 	stp	x21, x22, [sp, #208]
    37c0:	aa0003f5 	mov	x21, x0
    37c4:	a91073fb 	stp	x27, x28, [sp, #256]
    37c8:	5100071c 	sub	w28, w24, #0x1
    37cc:	2a1c03e5 	mov	w5, w28
    37d0:	f9400040 	ldr	x0, [x2]
    37d4:	f90057e0 	str	x0, [sp, #168]
    37d8:	d2800000 	mov	x0, #0x0                   	// #0
    37dc:	52800042 	mov	w2, #0x2                   	// #2
    37e0:	aa1403e0 	mov	x0, x20
    37e4:	97fffbe7 	bl	2780 <__snprintf_chk@plt>
    37e8:	52800ca1 	mov	w1, #0x65                  	// #101
    37ec:	aa1403e0 	mov	x0, x20
    37f0:	97fffc40 	bl	28f0 <strchr@plt>
    37f4:	aa0003f3 	mov	x19, x0
    37f8:	52800142 	mov	w2, #0xa                   	// #10
    37fc:	91000400 	add	x0, x0, #0x1
    3800:	d2800001 	mov	x1, #0x0                   	// #0
    3804:	97fffc2b 	bl	28b0 <strtol@plt>
    3808:	aa0003f7 	mov	x23, x0
    380c:	11001400 	add	w0, w0, #0x5
    3810:	7100541f 	cmp	w0, #0x15
    3814:	54000d68 	b.hi	39c0 <fwp_format_g.constprop.0+0x240>  // b.pmore
    3818:	4b170385 	sub	w5, w28, w23
    381c:	710000bf 	cmp	w5, #0x0
    3820:	7a41cb04 	ccmp	w24, #0x1, #0x4, gt
    3824:	54000b80 	b.eq	3994 <fwp_format_g.constprop.0+0x214>  // b.none
    3828:	394083e0 	ldrb	w0, [sp, #32]
    382c:	cb180273 	sub	x19, x19, x24
    3830:	91000673 	add	x19, x19, #0x1
    3834:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3838:	7100b41f 	cmp	w0, #0x2d
    383c:	9a941681 	cinc	x1, x20, eq	// eq = none
    3840:	1a9f17e4 	cset	w4, eq	// eq = none
    3844:	cb010266 	sub	x6, x19, x1
    3848:	d10004da 	sub	x26, x6, #0x1
    384c:	540018a0 	b.eq	3b60 <fwp_format_g.constprop.0+0x3e0>  // b.none
    3850:	910183f9 	add	x25, sp, #0x60
    3854:	d280091b 	mov	x27, #0x48                  	// #72
    3858:	aa1903e7 	mov	x7, x25
    385c:	91000423 	add	x3, x1, #0x1
    3860:	91011cc6 	add	x6, x6, #0x47
    3864:	910004f6 	add	x22, x7, #0x1
    3868:	37f80ff7 	tbnz	w23, #31, 3a64 <fwp_format_g.constprop.0+0x2e4>
    386c:	38644a84 	ldrb	w4, [x20, w4, uxtw]
    3870:	93407ef7 	sxtw	x23, w23
    3874:	390000e4 	strb	w4, [x7]
    3878:	aa1303e1 	mov	x1, x19
    387c:	aa1703e2 	mov	x2, x23
    3880:	aa1603e0 	mov	x0, x22
    3884:	b9000be5 	str	w5, [sp, #8]
    3888:	cb170374 	sub	x20, x27, x23
    388c:	a9011be3 	stp	x3, x6, [sp, #16]
    3890:	97fffb74 	bl	2660 <memcpy@plt>
    3894:	d1000694 	sub	x20, x20, #0x1
    3898:	f9400be3 	ldr	x3, [sp, #16]
    389c:	8b1702d6 	add	x22, x22, x23
    38a0:	aa1603e0 	mov	x0, x22
    38a4:	aa1a03e2 	mov	x2, x26
    38a8:	aa0303e1 	mov	x1, x3
    38ac:	aa1403e3 	mov	x3, x20
    38b0:	97fffbac 	bl	2760 <__memcpy_chk@plt>
    38b4:	8b1a02d6 	add	x22, x22, x26
    38b8:	f9400fe6 	ldr	x6, [sp, #24]
    38bc:	d2800900 	mov	x0, #0x48                  	// #72
    38c0:	b9400be5 	ldr	w5, [sp, #8]
    38c4:	8b170261 	add	x1, x19, x23
    38c8:	cb1400c3 	sub	x3, x6, x20
    38cc:	cb060294 	sub	x20, x20, x6
    38d0:	f101207f 	cmp	x3, #0x48
    38d4:	93407cb8 	sxtw	x24, w5
    38d8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    38dc:	aa1803e2 	mov	x2, x24
    38e0:	8b1802d3 	add	x19, x22, x24
    38e4:	8b140063 	add	x3, x3, x20
    38e8:	aa1603e0 	mov	x0, x22
    38ec:	97fffb9d 	bl	2760 <__memcpy_chk@plt>
    38f0:	cb190273 	sub	x19, x19, x25
    38f4:	d28031e0 	mov	x0, #0x18f                 	// #399
    38f8:	eb00027f 	cmp	x19, x0
    38fc:	aa1903e1 	mov	x1, x25
    3900:	9a809273 	csel	x19, x19, x0, ls	// ls = plast
    3904:	aa1503e0 	mov	x0, x21
    3908:	aa1303e2 	mov	x2, x19
    390c:	97fffb55 	bl	2660 <memcpy@plt>
    3910:	38336abf 	strb	wzr, [x21, x19]
    3914:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3918:	aa1503e0 	mov	x0, x21
    391c:	97fffb61 	bl	26a0 <strlen@plt>
    3920:	aa0003f3 	mov	x19, x0
    3924:	528005c1 	mov	w1, #0x2e                  	// #46
    3928:	aa1503e0 	mov	x0, x21
    392c:	97fffbf1 	bl	28f0 <strchr@plt>
    3930:	b4000140 	cbz	x0, 3958 <fwp_format_g.constprop.0+0x1d8>
    3934:	b4000133 	cbz	x19, 3958 <fwp_format_g.constprop.0+0x1d8>
    3938:	aa1303e1 	mov	x1, x19
    393c:	d1000673 	sub	x19, x19, #0x1
    3940:	38736aa0 	ldrb	w0, [x21, x19]
    3944:	7100c01f 	cmp	w0, #0x30
    3948:	54001001 	b.ne	3b48 <fwp_format_g.constprop.0+0x3c8>  // b.any
    394c:	38336abf 	strb	wzr, [x21, x19]
    3950:	b5ffff53 	cbnz	x19, 3938 <fwp_format_g.constprop.0+0x1b8>
    3954:	d503201f 	nop
    3958:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    395c:	f947f400 	ldr	x0, [x0, #4072]
    3960:	f94057e2 	ldr	x2, [sp, #168]
    3964:	f9400001 	ldr	x1, [x0]
    3968:	eb010042 	subs	x2, x2, x1
    396c:	d2800001 	mov	x1, #0x0                   	// #0
    3970:	54001061 	b.ne	3b7c <fwp_format_g.constprop.0+0x3fc>  // b.any
    3974:	a94b7bfd 	ldp	x29, x30, [sp, #176]
    3978:	a94c53f3 	ldp	x19, x20, [sp, #192]
    397c:	a94d5bf5 	ldp	x21, x22, [sp, #208]
    3980:	a94e63f7 	ldp	x23, x24, [sp, #224]
    3984:	a95073fb 	ldp	x27, x28, [sp, #256]
    3988:	fd408be8 	ldr	d8, [sp, #272]
    398c:	910483ff 	add	sp, sp, #0x120
    3990:	d65f03c0 	ret
    3994:	1e604100 	fmov	d0, d8
    3998:	710000bf 	cmp	w5, #0x0
    399c:	1a9fa0a5 	csel	w5, w5, wzr, ge	// ge = tcont
    39a0:	aa1503e0 	mov	x0, x21
    39a4:	90000044 	adrp	x4, b000 <__modti3+0x2a0>
    39a8:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    39ac:	910aa084 	add	x4, x4, #0x2a8
    39b0:	52800042 	mov	w2, #0x2                   	// #2
    39b4:	d2803201 	mov	x1, #0x190                 	// #400
    39b8:	97fffb72 	bl	2780 <__snprintf_chk@plt>
    39bc:	17ffffd7 	b	3918 <fwp_format_g.constprop.0+0x198>
    39c0:	cb140273 	sub	x19, x19, x20
    39c4:	a90f6bf9 	stp	x25, x26, [sp, #240]
    39c8:	910183f9 	add	x25, sp, #0x60
    39cc:	aa1303e2 	mov	x2, x19
    39d0:	aa1403e1 	mov	x1, x20
    39d4:	aa1903e0 	mov	x0, x25
    39d8:	d2800803 	mov	x3, #0x40                  	// #64
    39dc:	97fffb61 	bl	2760 <__memcpy_chk@plt>
    39e0:	38336b3f 	strb	wzr, [x25, x19]
    39e4:	aa1903e0 	mov	x0, x25
    39e8:	528005c1 	mov	w1, #0x2e                  	// #46
    39ec:	97fffbc1 	bl	28f0 <strchr@plt>
    39f0:	b40001c0 	cbz	x0, 3a28 <fwp_format_g.constprop.0+0x2a8>
    39f4:	b50000b3 	cbnz	x19, 3a08 <fwp_format_g.constprop.0+0x288>
    39f8:	1400000c 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    39fc:	381ff01f 	sturb	wzr, [x0, #-1]
    3a00:	f1000673 	subs	x19, x19, #0x1
    3a04:	54000120 	b.eq	3a28 <fwp_format_g.constprop.0+0x2a8>  // b.none
    3a08:	8b130320 	add	x0, x25, x19
    3a0c:	385ff001 	ldurb	w1, [x0, #-1]
    3a10:	7100c03f 	cmp	w1, #0x30
    3a14:	54ffff40 	b.eq	39fc <fwp_format_g.constprop.0+0x27c>  // b.none
    3a18:	d1000673 	sub	x19, x19, #0x1
    3a1c:	38736b20 	ldrb	w0, [x25, x19]
    3a20:	7100b81f 	cmp	w0, #0x2e
    3a24:	54000a80 	b.eq	3b74 <fwp_format_g.constprop.0+0x3f4>  // b.none
    3a28:	710002ff 	cmp	w23, #0x0
    3a2c:	528005a1 	mov	w1, #0x2d                  	// #45
    3a30:	aa1903e5 	mov	x5, x25
    3a34:	5a97a6e7 	cneg	w7, w23, lt	// lt = tstop
    3a38:	aa1503e0 	mov	x0, x21
    3a3c:	52800566 	mov	w6, #0x2b                  	// #43
    3a40:	90000044 	adrp	x4, b000 <__modti3+0x2a0>
    3a44:	1a81a0c6 	csel	w6, w6, w1, ge	// ge = tcont
    3a48:	910a6084 	add	x4, x4, #0x298
    3a4c:	92800003 	mov	x3, #0xffffffffffffffff    	// #-1
    3a50:	52800042 	mov	w2, #0x2                   	// #2
    3a54:	d2803201 	mov	x1, #0x190                 	// #400
    3a58:	97fffb4a 	bl	2780 <__snprintf_chk@plt>
    3a5c:	a94f6bf9 	ldp	x25, x26, [sp, #240]
    3a60:	17ffffbe 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3a64:	52800605 	mov	w5, #0x30                  	// #48
    3a68:	390000e5 	strb	w5, [x7]
    3a6c:	d100077b 	sub	x27, x27, #0x1
    3a70:	aa0303e1 	mov	x1, x3
    3a74:	aa1603e0 	mov	x0, x22
    3a78:	aa1b03e3 	mov	x3, x27
    3a7c:	aa1a03e2 	mov	x2, x26
    3a80:	f90007e6 	str	x6, [sp, #8]
    3a84:	b90013e4 	str	w4, [sp, #16]
    3a88:	8b1a02d6 	add	x22, x22, x26
    3a8c:	b9001be5 	str	w5, [sp, #24]
    3a90:	97fffb34 	bl	2760 <__memcpy_chk@plt>
    3a94:	f94007e6 	ldr	x6, [sp, #8]
    3a98:	2a3703e7 	mvn	w7, w23
    3a9c:	b94013e4 	ldr	w4, [sp, #16]
    3aa0:	cb1b00c1 	sub	x1, x6, x27
    3aa4:	cb06037b 	sub	x27, x27, x6
    3aa8:	f101203f 	cmp	x1, #0x48
    3aac:	d2800906 	mov	x6, #0x48                  	// #72
    3ab0:	9a862021 	csel	x1, x1, x6, cs	// cs = hs, nlast
    3ab4:	8b1b0023 	add	x3, x1, x27
    3ab8:	310006ff 	cmn	w23, #0x1
    3abc:	54000220 	b.eq	3b00 <fwp_format_g.constprop.0+0x380>  // b.none
    3ac0:	b9401be5 	ldr	w5, [sp, #24]
    3ac4:	d2800001 	mov	x1, #0x0                   	// #0
    3ac8:	f101207f 	cmp	x3, #0x48
    3acc:	d1000462 	sub	x2, x3, #0x1
    3ad0:	9a862060 	csel	x0, x3, x6, cs	// cs = hs, nlast
    3ad4:	38216ac5 	strb	w5, [x22, x1]
    3ad8:	cb030003 	sub	x3, x0, x3
    3adc:	91000421 	add	x1, x1, #0x1
    3ae0:	91000463 	add	x3, x3, #0x1
    3ae4:	eb00007f 	cmp	x3, x0
    3ae8:	9a802063 	csel	x3, x3, x0, cs	// cs = hs, nlast
    3aec:	cb000063 	sub	x3, x3, x0
    3af0:	8b020063 	add	x3, x3, x2
    3af4:	6b0100ff 	cmp	w7, w1
    3af8:	54fffe8c 	b.gt	3ac8 <fwp_format_g.constprop.0+0x348>
    3afc:	8b2742d6 	add	x22, x22, w7, uxtw
    3b00:	f101207f 	cmp	x3, #0x48
    3b04:	d2800905 	mov	x5, #0x48                  	// #72
    3b08:	9a852065 	csel	x5, x3, x5, cs	// cs = hs, nlast
    3b0c:	aa1603e0 	mov	x0, x22
    3b10:	cb0300a1 	sub	x1, x5, x3
    3b14:	38644a82 	ldrb	w2, [x20, w4, uxtw]
    3b18:	91000421 	add	x1, x1, #0x1
    3b1c:	d1000463 	sub	x3, x3, #0x1
    3b20:	eb05003f 	cmp	x1, x5
    3b24:	38001402 	strb	w2, [x0], #1
    3b28:	9a852021 	csel	x1, x1, x5, cs	// cs = hs, nlast
    3b2c:	93407f82 	sxtw	x2, w28
    3b30:	cb050025 	sub	x5, x1, x5
    3b34:	aa1303e1 	mov	x1, x19
    3b38:	8b0300a3 	add	x3, x5, x3
    3b3c:	8b1802d3 	add	x19, x22, x24
    3b40:	97fffb08 	bl	2760 <__memcpy_chk@plt>
    3b44:	17ffff6b 	b	38f0 <fwp_format_g.constprop.0+0x170>
    3b48:	d1000421 	sub	x1, x1, #0x1
    3b4c:	38616aa0 	ldrb	w0, [x21, x1]
    3b50:	7100b81f 	cmp	w0, #0x2e
    3b54:	54fff021 	b.ne	3958 <fwp_format_g.constprop.0+0x1d8>  // b.any
    3b58:	38216abf 	strb	wzr, [x21, x1]
    3b5c:	17ffff7f 	b	3958 <fwp_format_g.constprop.0+0x1d8>
    3b60:	910187e7 	add	x7, sp, #0x61
    3b64:	910183f9 	add	x25, sp, #0x60
    3b68:	d28008fb 	mov	x27, #0x47                  	// #71
    3b6c:	390183e0 	strb	w0, [sp, #96]
    3b70:	17ffff3b 	b	385c <fwp_format_g.constprop.0+0xdc>
    3b74:	38336b3f 	strb	wzr, [x25, x19]
    3b78:	17ffffac 	b	3a28 <fwp_format_g.constprop.0+0x2a8>
    3b7c:	a90f6bf9 	stp	x25, x26, [sp, #240]
    3b80:	97fffb24 	bl	2810 <__stack_chk_fail@plt>

0000000000003b84 <fwp_heap_report>:
    3b84:	d105c3ff 	sub	sp, sp, #0x170
    3b88:	d00003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    3b8c:	9118c042 	add	x2, x2, #0x630
    3b90:	900000e1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    3b94:	f947e821 	ldr	x1, [x1, #4048]
    3b98:	a9117bfd 	stp	x29, x30, [sp, #272]
    3b9c:	910443fd 	add	x29, sp, #0x110
    3ba0:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3ba4:	f947f400 	ldr	x0, [x0, #4072]
    3ba8:	a9135bf5 	stp	x21, x22, [sp, #304]
    3bac:	a91463f7 	stp	x23, x24, [sp, #320]
    3bb0:	a9156bf9 	stp	x25, x26, [sp, #336]
    3bb4:	6d1627e8 	stp	d8, d9, [sp, #352]
    3bb8:	fd4a1c48 	ldr	d8, [x2, #5176]
    3bbc:	fd4a2049 	ldr	d9, [x2, #5184]
    3bc0:	f9400036 	ldr	x22, [x1]
    3bc4:	f9400001 	ldr	x1, [x0]
    3bc8:	f90087e1 	str	x1, [sp, #264]
    3bcc:	d2800001 	mov	x1, #0x0                   	// #0
    3bd0:	f949e459 	ldr	x25, [x2, #5064]
    3bd4:	90000041 	adrp	x1, b000 <__modti3+0x2a0>
    3bd8:	f94a1057 	ldr	x23, [x2, #5152]
    3bdc:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    3be0:	f94a1458 	ldr	x24, [x2, #5160]
    3be4:	910ac021 	add	x1, x1, #0x2b0
    3be8:	910ae000 	add	x0, x0, #0x2b8
    3bec:	97fffaed 	bl	27a0 <fopen@plt>
    3bf0:	b4000760 	cbz	x0, 3cdc <fwp_heap_report+0x158>
    3bf4:	528daad5 	mov	w21, #0x6d56                	// #27990
    3bf8:	a91253f3 	stp	x19, x20, [sp, #288]
    3bfc:	aa0003f4 	mov	x20, x0
    3c00:	910023f3 	add	x19, sp, #0x8
    3c04:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3c08:	72aae915 	movk	w21, #0x5748, lsl #16
    3c0c:	d503201f 	nop
    3c10:	aa1403e2 	mov	x2, x20
    3c14:	aa1303e0 	mov	x0, x19
    3c18:	52802001 	mov	w1, #0x100                 	// #256
    3c1c:	97fffb69 	bl	29c0 <fgets@plt>
    3c20:	b4000280 	cbz	x0, 3c70 <fwp_heap_report+0xec>
    3c24:	b9400261 	ldr	w1, [x19]
    3c28:	6b15003f 	cmp	w1, w21
    3c2c:	54ffff21 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c30:	39401260 	ldrb	w0, [x19, #4]
    3c34:	7101341f 	cmp	w0, #0x4d
    3c38:	54fffec1 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c3c:	394037e0 	ldrb	w0, [sp, #13]
    3c40:	7100e81f 	cmp	w0, #0x3a
    3c44:	54fffe61 	b.ne	3c10 <fwp_heap_report+0x8c>  // b.any
    3c48:	52800142 	mov	w2, #0xa                   	// #10
    3c4c:	d2800001 	mov	x1, #0x0                   	// #0
    3c50:	91003be0 	add	x0, sp, #0xe
    3c54:	97fffb17 	bl	28b0 <strtol@plt>
    3c58:	aa1403e2 	mov	x2, x20
    3c5c:	aa0003fa 	mov	x26, x0
    3c60:	52802001 	mov	w1, #0x100                 	// #256
    3c64:	aa1303e0 	mov	x0, x19
    3c68:	97fffb56 	bl	29c0 <fgets@plt>
    3c6c:	b5fffdc0 	cbnz	x0, 3c24 <fwp_heap_report+0xa0>
    3c70:	aa1403e0 	mov	x0, x20
    3c74:	97fffac7 	bl	2790 <fclose@plt>
    3c78:	a95253f3 	ldp	x19, x20, [sp, #288]
    3c7c:	900000e0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    3c80:	f947f400 	ldr	x0, [x0, #4072]
    3c84:	f94087e2 	ldr	x2, [sp, #264]
    3c88:	f9400001 	ldr	x1, [x0]
    3c8c:	eb010042 	subs	x2, x2, x1
    3c90:	d2800001 	mov	x1, #0x0                   	// #0
    3c94:	54000281 	b.ne	3ce4 <fwp_heap_report+0x160>  // b.any
    3c98:	a9517bfd 	ldp	x29, x30, [sp, #272]
    3c9c:	aa1a03e6 	mov	x6, x26
    3ca0:	aa1903e5 	mov	x5, x25
    3ca4:	aa1803e4 	mov	x4, x24
    3ca8:	a9556bf9 	ldp	x25, x26, [sp, #336]
    3cac:	aa1703e3 	mov	x3, x23
    3cb0:	a95463f7 	ldp	x23, x24, [sp, #320]
    3cb4:	aa1603e0 	mov	x0, x22
    3cb8:	a9535bf5 	ldp	x21, x22, [sp, #304]
    3cbc:	1e604121 	fmov	d1, d9
    3cc0:	1e604100 	fmov	d0, d8
    3cc4:	90000042 	adrp	x2, b000 <__modti3+0x2a0>
    3cc8:	6d5627e8 	ldp	d8, d9, [sp, #352]
    3ccc:	910b6042 	add	x2, x2, #0x2d8
    3cd0:	9105c3ff 	add	sp, sp, #0x170
    3cd4:	52800041 	mov	w1, #0x2                   	// #2
    3cd8:	17fffaea 	b	2880 <__fprintf_chk@plt>
    3cdc:	9280001a 	mov	x26, #0xffffffffffffffff    	// #-1
    3ce0:	17ffffe7 	b	3c7c <fwp_heap_report+0xf8>
    3ce4:	a91253f3 	stp	x19, x20, [sp, #288]
    3ce8:	97fffaca 	bl	2810 <__stack_chk_fail@plt>
    3cec:	d503201f 	nop

0000000000003cf0 <fwp_heap_init>:
    3cf0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    3cf4:	f00003a3 	adrp	x3, 7a000 <fwp_heap+0x9d0>
    3cf8:	9114c061 	add	x1, x3, #0x530
    3cfc:	910003fd 	mov	x29, sp
    3d00:	a90153f3 	stp	x19, x20, [sp, #16]
    3d04:	d00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    3d08:	9118c262 	add	x2, x19, #0x630
    3d0c:	a9025bf5 	stp	x21, x22, [sp, #32]
    3d10:	52800024 	mov	w4, #0x1                   	// #1
    3d14:	52800200 	mov	w0, #0x10                  	// #16
    3d18:	b913a444 	str	w4, [x2, #5028]
    3d1c:	d503201f 	nop
    3d20:	b8004420 	str	w0, [x1], #4
    3d24:	11004000 	add	w0, w0, #0x10
    3d28:	7104401f 	cmp	w0, #0x110
    3d2c:	54ffffa1 	b.ne	3d20 <fwp_heap_init+0x30>  // b.any
    3d30:	b0000042 	adrp	x2, c000 <_IO_stdin_used+0xf00>
    3d34:	0f002420 	movi	v0.2s, #0x1, lsl #8
    3d38:	f00003a1 	adrp	x1, 7a000 <fwp_heap+0x9d0>
    3d3c:	9115c021 	add	x1, x1, #0x570
    3d40:	3dc02843 	ldr	q3, [x2, #160]
    3d44:	d2800000 	mov	x0, #0x0                   	// #0
    3d48:	4e040401 	dup	v1.4s, v0.s[0]
    3d4c:	2f3e0402 	ushr	v2.2s, v0.2s, #2
    3d50:	0f215400 	shl	v0.2s, v0.2s, #1
    3d54:	6f820061 	mla	v1.4s, v3.4s, v2.s[0]
    3d58:	3ca06821 	str	q1, [x1, x0]
    3d5c:	91004000 	add	x0, x0, #0x10
    3d60:	f101801f 	cmp	x0, #0x60
    3d64:	54ffff21 	b.ne	3d48 <fwp_heap_init+0x58>  // b.any
    3d68:	f00003a4 	adrp	x4, 7a000 <fwp_heap+0x9d0>
    3d6c:	9114c063 	add	x3, x3, #0x530
    3d70:	91174084 	add	x4, x4, #0x5d0
    3d74:	9118c266 	add	x6, x19, #0x630
    3d78:	d2800002 	mov	x2, #0x0                   	// #0
    3d7c:	d2800000 	mov	x0, #0x0                   	// #0
    3d80:	d2880205 	mov	x5, #0x4010                	// #16400
    3d84:	d503201f 	nop
    3d88:	910f0001 	add	x1, x0, #0x3c0
    3d8c:	b86178c1 	ldr	w1, [x6, x1, lsl #2]
    3d90:	eb02003f 	cmp	x1, x2
    3d94:	540000a2 	b.cs	3da8 <fwp_heap_init+0xb8>  // b.hs, b.nlast
    3d98:	91000400 	add	x0, x0, #0x1
    3d9c:	b8607861 	ldr	w1, [x3, x0, lsl #2]
    3da0:	eb02003f 	cmp	x1, x2
    3da4:	54ffffa3 	b.cc	3d98 <fwp_heap_init+0xa8>  // b.lo, b.ul, b.last
    3da8:	91004042 	add	x2, x2, #0x10
    3dac:	38001480 	strb	w0, [x4], #1
    3db0:	eb05005f 	cmp	x2, x5
    3db4:	54fffea1 	b.ne	3d88 <fwp_heap_init+0x98>  // b.any
    3db8:	528000b5 	mov	w21, #0x5                   	// #5
    3dbc:	d2c00214 	mov	x20, #0x1000000000          	// #68719476736
    3dc0:	14000004 	b	3dd0 <fwp_heap_init+0xe0>
    3dc4:	d342fe94 	lsr	x20, x20, #2
    3dc8:	710006b5 	subs	w21, w21, #0x1
    3dcc:	54000720 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3dd0:	91404296 	add	x22, x20, #0x10, lsl #12
    3dd4:	d2800005 	mov	x5, #0x0                   	// #0
    3dd8:	aa1603e1 	mov	x1, x22
    3ddc:	12800004 	mov	w4, #0xffffffff            	// #-1
    3de0:	52880443 	mov	w3, #0x4022                	// #16418
    3de4:	52800002 	mov	w2, #0x0                   	// #0
    3de8:	d2800000 	mov	x0, #0x0                   	// #0
    3dec:	97fffaad 	bl	28a0 <mmap@plt>
    3df0:	aa0003e6 	mov	x6, x0
    3df4:	b100041f 	cmn	x0, #0x1
    3df8:	54fffe60 	b.eq	3dc4 <fwp_heap_init+0xd4>  // b.none
    3dfc:	b40005a0 	cbz	x0, 3eb0 <fwp_heap_init+0x1c0>
    3e00:	d350fe94 	lsr	x20, x20, #16
    3e04:	d29fffe0 	mov	x0, #0xffff                	// #65535
    3e08:	8b0000c7 	add	x7, x6, x0
    3e0c:	9118c275 	add	x21, x19, #0x630
    3e10:	9270bce7 	and	x7, x7, #0xffffffffffff0000
    3e14:	8b140a81 	add	x1, x20, x20, lsl #2
    3e18:	d2800005 	mov	x5, #0x0                   	// #0
    3e1c:	12800004 	mov	w4, #0xffffffff            	// #-1
    3e20:	d37df021 	lsl	x1, x1, #3
    3e24:	52880443 	mov	w3, #0x4022                	// #16418
    3e28:	52800002 	mov	w2, #0x0                   	// #0
    3e2c:	d2800000 	mov	x0, #0x0                   	// #0
    3e30:	f909daa7 	str	x7, [x21, #5040]
    3e34:	f909dea6 	str	x6, [x21, #5048]
    3e38:	f909e2b6 	str	x22, [x21, #5056]
    3e3c:	f909eab4 	str	x20, [x21, #5072]
    3e40:	f90a02a1 	str	x1, [x21, #5120]
    3e44:	97fffa97 	bl	28a0 <mmap@plt>
    3e48:	aa0003e1 	mov	x1, x0
    3e4c:	b100041f 	cmn	x0, #0x1
    3e50:	54000300 	b.eq	3eb0 <fwp_heap_init+0x1c0>  // b.none
    3e54:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    3e58:	910d8000 	add	x0, x0, #0x360
    3e5c:	f909fea1 	str	x1, [x21, #5112]
    3e60:	97fffad0 	bl	29a0 <getenv@plt>
    3e64:	52800002 	mov	w2, #0x0                   	// #0
    3e68:	aa0003e1 	mov	x1, x0
    3e6c:	b40000e0 	cbz	x0, 3e88 <fwp_heap_init+0x198>
    3e70:	39400000 	ldrb	w0, [x0]
    3e74:	340000a0 	cbz	w0, 3e88 <fwp_heap_init+0x198>
    3e78:	7100c000 	subs	w0, w0, #0x30
    3e7c:	54000120 	b.eq	3ea0 <fwp_heap_init+0x1b0>  // b.none
    3e80:	7100001f 	cmp	w0, #0x0
    3e84:	1a9f07e2 	cset	w2, ne	// ne = any
    3e88:	9118c273 	add	x19, x19, #0x630
    3e8c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    3e90:	b913aa62 	str	w2, [x19, #5032]
    3e94:	a94153f3 	ldp	x19, x20, [sp, #16]
    3e98:	a8c37bfd 	ldp	x29, x30, [sp], #48
    3e9c:	d65f03c0 	ret
    3ea0:	39400420 	ldrb	w0, [x1, #1]
    3ea4:	7100001f 	cmp	w0, #0x0
    3ea8:	1a9f07e2 	cset	w2, ne	// ne = any
    3eac:	17fffff7 	b	3e88 <fwp_heap_init+0x198>
    3eb0:	97fffc90 	bl	30f0 <fwp_heap_oom>

0000000000003eb4 <fwp_wake_io>:
    3eb4:	b00000e9 	adrp	x9, 20000 <__data_start>
    3eb8:	91014122 	add	x2, x9, #0x50
    3ebc:	f9400001 	ldr	x1, [x0]
    3ec0:	5280000a 	mov	w10, #0x0                   	// #0
    3ec4:	f9406046 	ldr	x6, [x2, #192]
    3ec8:	52800008 	mov	w8, #0x0                   	// #0
    3ecc:	4f000400 	movi	v0.4s, #0x0
    3ed0:	52800027 	mov	w7, #0x1                   	// #1
    3ed4:	aa0103e2 	mov	x2, x1
    3ed8:	b4000321 	cbz	x1, 3f3c <fwp_wake_io+0x88>
    3edc:	f9408c25 	ldr	x5, [x1, #280]
    3ee0:	39015c27 	strb	w7, [x1, #87]
    3ee4:	b4000165 	cbz	x5, 3f10 <fwp_wake_io+0x5c>
    3ee8:	a9520c24 	ldp	x4, x3, [x1, #288]
    3eec:	b4000364 	cbz	x4, 3f58 <fwp_wake_io+0xa4>
    3ef0:	f9009483 	str	x3, [x4, #296]
    3ef4:	f9409423 	ldr	x3, [x1, #296]
    3ef8:	b4000043 	cbz	x3, 3f00 <fwp_wake_io+0x4c>
    3efc:	f9009064 	str	x4, [x3, #288]
    3f00:	91080023 	add	x3, x1, #0x200
    3f04:	f900943f 	str	xzr, [x1, #296]
    3f08:	3c918060 	stur	q0, [x3, #-232]
    3f0c:	f9400001 	ldr	x1, [x0]
    3f10:	f9402843 	ldr	x3, [x2, #80]
    3f14:	f2001c7f 	tst	x3, #0xff000000ff
    3f18:	54fffde1 	b.ne	3ed4 <fwp_wake_io+0x20>  // b.any
    3f1c:	39015047 	strb	w7, [x2, #84]
    3f20:	f900805f 	str	xzr, [x2, #256]
    3f24:	b40001e6 	cbz	x6, 3f60 <fwp_wake_io+0xac>
    3f28:	f90080c2 	str	x2, [x6, #256]
    3f2c:	aa0203e6 	mov	x6, x2
    3f30:	52800028 	mov	w8, #0x1                   	// #1
    3f34:	aa0103e2 	mov	x2, x1
    3f38:	b5fffd21 	cbnz	x1, 3edc <fwp_wake_io+0x28>
    3f3c:	3400006a 	cbz	w10, 3f48 <fwp_wake_io+0x94>
    3f40:	91014120 	add	x0, x9, #0x50
    3f44:	f900640b 	str	x11, [x0, #200]
    3f48:	34000068 	cbz	w8, 3f54 <fwp_wake_io+0xa0>
    3f4c:	91014129 	add	x9, x9, #0x50
    3f50:	f9006126 	str	x6, [x9, #192]
    3f54:	d65f03c0 	ret
    3f58:	f90000a3 	str	x3, [x5]
    3f5c:	17ffffe7 	b	3ef8 <fwp_wake_io+0x44>
    3f60:	aa0203eb 	mov	x11, x2
    3f64:	5280002a 	mov	w10, #0x1                   	// #1
    3f68:	17fffff1 	b	3f2c <fwp_wake_io+0x78>
    3f6c:	d503201f 	nop

0000000000003f70 <ad_raw_free.part.0>:
    3f70:	b00002e4 	adrp	x4, 60000 <ad_raw_checkpoints+0x2fbb0>
    3f74:	d2800001 	mov	x1, #0x0                   	// #0
    3f78:	91114082 	add	x2, x4, #0x450
    3f7c:	14000005 	b	3f90 <ad_raw_free.part.0+0x20>
    3f80:	91000421 	add	x1, x1, #0x1
    3f84:	91006042 	add	x2, x2, #0x18
    3f88:	f140043f 	cmp	x1, #0x1, lsl #12
    3f8c:	54000220 	b.eq	3fd0 <ad_raw_free.part.0+0x60>  // b.none
    3f90:	f9400043 	ldr	x3, [x2]
    3f94:	eb03001f 	cmp	x0, x3
    3f98:	54ffff41 	b.ne	3f80 <ad_raw_free.part.0+0x10>  // b.any
    3f9c:	8b010421 	add	x1, x1, x1, lsl #1
    3fa0:	91114084 	add	x4, x4, #0x450
    3fa4:	b00000e2 	adrp	x2, 20000 <__data_start>
    3fa8:	91014042 	add	x2, x2, #0x50
    3fac:	8b010c81 	add	x1, x4, x1, lsl #3
    3fb0:	b9401024 	ldr	w4, [x1, #16]
    3fb4:	f9400425 	ldr	x5, [x1, #8]
    3fb8:	a9007c3f 	stp	xzr, xzr, [x1]
    3fbc:	f8647843 	ldr	x3, [x2, x4, lsl #3]
    3fc0:	f900083f 	str	xzr, [x1, #16]
    3fc4:	cb050061 	sub	x1, x3, x5
    3fc8:	f8247841 	str	x1, [x2, x4, lsl #3]
    3fcc:	17fffa41 	b	28d0 <free@plt>
    3fd0:	f100001f 	cmp	x0, #0x0
    3fd4:	90000041 	adrp	x1, b000 <__modti3+0x2a0>
    3fd8:	910e2021 	add	x1, x1, #0x388
    3fdc:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    3fe0:	90000040 	adrp	x0, b000 <__modti3+0x2a0>
    3fe4:	910dc000 	add	x0, x0, #0x370
    3fe8:	910003fd 	mov	x29, sp
    3fec:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    3ff0:	97fffcc4 	bl	3300 <ad_raw_fail>

0000000000003ff4 <fwp_tape_buffers_dispose>:
    3ff4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    3ff8:	910003fd 	mov	x29, sp
    3ffc:	f9000bf3 	str	x19, [sp, #16]
    4000:	aa0003f3 	mov	x19, x0
    4004:	f9400000 	ldr	x0, [x0]
    4008:	b4000040 	cbz	x0, 4010 <fwp_tape_buffers_dispose+0x1c>
    400c:	97ffffd9 	bl	3f70 <ad_raw_free.part.0>
    4010:	f9400a60 	ldr	x0, [x19, #16]
    4014:	b4000040 	cbz	x0, 401c <fwp_tape_buffers_dispose+0x28>
    4018:	97ffffd6 	bl	3f70 <ad_raw_free.part.0>
    401c:	f9401260 	ldr	x0, [x19, #32]
    4020:	b4000040 	cbz	x0, 4028 <fwp_tape_buffers_dispose+0x34>
    4024:	97ffffd3 	bl	3f70 <ad_raw_free.part.0>
    4028:	4f000400 	movi	v0.4s, #0x0
    402c:	f9001a7f 	str	xzr, [x19, #48]
    4030:	ad000260 	stp	q0, q0, [x19]
    4034:	3d800a60 	str	q0, [x19, #32]
    4038:	f9400bf3 	ldr	x19, [sp, #16]
    403c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    4040:	d65f03c0 	ret

0000000000004044 <ad_raw_realloc>:
    4044:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4048:	910003fd 	mov	x29, sp
    404c:	a90153f3 	stp	x19, x20, [sp, #16]
    4050:	f90013f5 	str	x21, [sp, #32]
    4054:	b40005a1 	cbz	x1, 4108 <ad_raw_realloc+0xc4>
    4058:	aa0103f4 	mov	x20, x1
    405c:	2a0203f5 	mov	w21, w2
    4060:	900002e1 	adrp	x1, 60000 <ad_raw_checkpoints+0x2fbb0>
    4064:	d2800004 	mov	x4, #0x0                   	// #0
    4068:	91114025 	add	x5, x1, #0x450
    406c:	14000005 	b	4080 <ad_raw_realloc+0x3c>
    4070:	91000484 	add	x4, x4, #0x1
    4074:	910060a5 	add	x5, x5, #0x18
    4078:	f140049f 	cmp	x4, #0x1, lsl #12
    407c:	54000320 	b.eq	40e0 <ad_raw_realloc+0x9c>  // b.none
    4080:	f94000a6 	ldr	x6, [x5]
    4084:	eb06001f 	cmp	x0, x6
    4088:	54ffff41 	b.ne	4070 <ad_raw_realloc+0x2c>  // b.any
    408c:	8b040484 	add	x4, x4, x4, lsl #1
    4090:	91114021 	add	x1, x1, #0x450
    4094:	8b040c33 	add	x19, x1, x4, lsl #3
    4098:	b4000080 	cbz	x0, 40a8 <ad_raw_realloc+0x64>
    409c:	b9401261 	ldr	w1, [x19, #16]
    40a0:	6b15003f 	cmp	w1, w21
    40a4:	540002c1 	b.ne	40fc <ad_raw_realloc+0xb8>  // b.any
    40a8:	aa1403e1 	mov	x1, x20
    40ac:	97fff9d5 	bl	2800 <realloc@plt>
    40b0:	aa0003ed 	mov	x13, x0
    40b4:	b40000c0 	cbz	x0, 40cc <ad_raw_realloc+0x88>
    40b8:	2a1503e3 	mov	w3, w21
    40bc:	aa1403e2 	mov	x2, x20
    40c0:	aa1303e0 	mov	x0, x19
    40c4:	aa0d03e1 	mov	x1, x13
    40c8:	97fffb92 	bl	2f10 <ad_raw_record>
    40cc:	a94153f3 	ldp	x19, x20, [sp, #16]
    40d0:	aa0d03e0 	mov	x0, x13
    40d4:	f94013f5 	ldr	x21, [sp, #32]
    40d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    40dc:	d65f03c0 	ret
    40e0:	f100001f 	cmp	x0, #0x0
    40e4:	f0000021 	adrp	x1, b000 <__modti3+0x2a0>
    40e8:	910e2021 	add	x1, x1, #0x388
    40ec:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    40f0:	910dc000 	add	x0, x0, #0x370
    40f4:	9a800020 	csel	x0, x1, x0, eq	// eq = none
    40f8:	97fffc82 	bl	3300 <ad_raw_fail>
    40fc:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4100:	910f2000 	add	x0, x0, #0x3c8
    4104:	97fffc7f 	bl	3300 <ad_raw_fail>
    4108:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    410c:	910ea000 	add	x0, x0, #0x3a8
    4110:	97fffc7c 	bl	3300 <ad_raw_fail>

0000000000004114 <fwp_tape_buffers_release>:
    4114:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4118:	910003fd 	mov	x29, sp
    411c:	a90153f3 	stp	x19, x20, [sp, #16]
    4120:	aa0003f4 	mov	x20, x0
    4124:	f9401400 	ldr	x0, [x0, #40]
    4128:	a9025bf5 	stp	x21, x22, [sp, #32]
    412c:	b7f80560 	tbnz	x0, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4130:	f9401a93 	ldr	x19, [x20, #48]
    4134:	b7f80533 	tbnz	x19, #63, 41d8 <fwp_tape_buffers_release+0xc4>
    4138:	d28aaaa1 	mov	x1, #0x5555                	// #21845
    413c:	eb01001f 	cmp	x0, x1
    4140:	540004c8 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    4144:	8b000400 	add	x0, x0, x0, lsl #1
    4148:	d2a00101 	mov	x1, #0x80000               	// #524288
    414c:	d37df000 	lsl	x0, x0, #3
    4150:	cb000021 	sub	x1, x1, x0
    4154:	eb410e7f 	cmp	x19, x1, lsr #3
    4158:	54000408 	b.hi	41d8 <fwp_tape_buffers_release+0xc4>  // b.pmore
    415c:	8b130c13 	add	x19, x0, x19, lsl #3
    4160:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4164:	910f8000 	add	x0, x0, #0x3e0
    4168:	97fffa0e 	bl	29a0 <getenv@plt>
    416c:	b4000080 	cbz	x0, 417c <fwp_tape_buffers_release+0x68>
    4170:	39400001 	ldrb	w1, [x0]
    4174:	7100c03f 	cmp	w1, #0x30
    4178:	54000880 	b.eq	4288 <fwp_tape_buffers_release+0x174>  // b.none
    417c:	d1000661 	sub	x1, x19, #0x1
    4180:	b2404be0 	mov	x0, #0x7ffff               	// #524287
    4184:	eb00003f 	cmp	x1, x0
    4188:	54000328 	b.hi	41ec <fwp_tape_buffers_release+0xd8>  // b.pmore
    418c:	900000f5 	adrp	x21, 20000 <__data_start>
    4190:	f9001bf7 	str	x23, [sp, #48]
    4194:	910142b7 	add	x23, x21, #0x50
    4198:	910342f6 	add	x22, x23, #0xd0
    419c:	aa1603e0 	mov	x0, x22
    41a0:	97ffff95 	bl	3ff4 <fwp_tape_buffers_dispose>
    41a4:	ad400a81 	ldp	q1, q2, [x20]
    41a8:	f90086f3 	str	x19, [x23, #264]
    41ac:	4f000400 	movi	v0.4s, #0x0
    41b0:	ad000ac1 	stp	q1, q2, [x22]
    41b4:	3dc00a81 	ldr	q1, [x20, #32]
    41b8:	3d800ac1 	str	q1, [x22, #32]
    41bc:	f9401a80 	ldr	x0, [x20, #48]
    41c0:	f9001ac0 	str	x0, [x22, #48]
    41c4:	f9001a9f 	str	xzr, [x20, #48]
    41c8:	ad000280 	stp	q0, q0, [x20]
    41cc:	3d800a80 	str	q0, [x20, #32]
    41d0:	f9401bf7 	ldr	x23, [sp, #48]
    41d4:	1400000b 	b	4200 <fwp_tape_buffers_release+0xec>
    41d8:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    41dc:	92800013 	mov	x19, #0xffffffffffffffff    	// #-1
    41e0:	910f8000 	add	x0, x0, #0x3e0
    41e4:	97fff9ef 	bl	29a0 <getenv@plt>
    41e8:	b5fffc40 	cbnz	x0, 4170 <fwp_tape_buffers_release+0x5c>
    41ec:	aa1403e0 	mov	x0, x20
    41f0:	97ffff81 	bl	3ff4 <fwp_tape_buffers_dispose>
    41f4:	900000f5 	adrp	x21, 20000 <__data_start>
    41f8:	910142a0 	add	x0, x21, #0x50
    41fc:	f9408413 	ldr	x19, [x0, #264]
    4200:	910142a2 	add	x2, x21, #0x50
    4204:	f9408844 	ldr	x4, [x2, #272]
    4208:	a9400c45 	ldp	x5, x3, [x2]
    420c:	8b040481 	add	x1, x4, x4, lsl #1
    4210:	f9400840 	ldr	x0, [x2, #16]
    4214:	8b010881 	add	x1, x4, x1, lsl #2
    4218:	f9400c44 	ldr	x4, [x2, #24]
    421c:	8b0300a3 	add	x3, x5, x3
    4220:	d37df021 	lsl	x1, x1, #3
    4224:	8b040000 	add	x0, x0, x4
    4228:	8b030000 	add	x0, x0, x3
    422c:	eb05003f 	cmp	x1, x5
    4230:	54000321 	b.ne	4294 <fwp_tape_buffers_release+0x180>  // b.any
    4234:	8b130023 	add	x3, x1, x19
    4238:	eb00007f 	cmp	x3, x0
    423c:	540002c8 	b.hi	4294 <fwp_tape_buffers_release+0x180>  // b.pmore
    4240:	f9405c43 	ldr	x3, [x2, #184]
    4244:	f140087f 	cmp	x3, #0x2, lsl #12
    4248:	540002e0 	b.eq	42a4 <fwp_tape_buffers_release+0x190>  // b.none
    424c:	8b030464 	add	x4, x3, x3, lsl #1
    4250:	90000165 	adrp	x5, 30000 <alt.5+0xfbb0>
    4254:	911140a5 	add	x5, x5, #0x450
    4258:	cb010000 	sub	x0, x0, x1
    425c:	d37df084 	lsl	x4, x4, #3
    4260:	cb130000 	sub	x0, x0, x19
    4264:	8b0400a6 	add	x6, x5, x4
    4268:	91000463 	add	x3, x3, #0x1
    426c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4270:	f82468a1 	str	x1, [x5, x4]
    4274:	a90080d3 	stp	x19, x0, [x6, #8]
    4278:	f9005c43 	str	x3, [x2, #184]
    427c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4280:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4284:	d65f03c0 	ret
    4288:	39400400 	ldrb	w0, [x0, #1]
    428c:	34fffb00 	cbz	w0, 41ec <fwp_tape_buffers_release+0xd8>
    4290:	17ffffbb 	b	417c <fwp_tape_buffers_release+0x68>
    4294:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4298:	910fe000 	add	x0, x0, #0x3f8
    429c:	f9001bf7 	str	x23, [sp, #48]
    42a0:	97fffc18 	bl	3300 <ad_raw_fail>
    42a4:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    42a8:	9110a000 	add	x0, x0, #0x428
    42ac:	f9001bf7 	str	x23, [sp, #48]
    42b0:	97fffc14 	bl	3300 <ad_raw_fail>

00000000000042b4 <fwp_trap>:
    42b4:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    42b8:	900000e2 	adrp	x2, 20000 <__data_start>
    42bc:	d53bd041 	mrs	x1, tpidr_el0
    42c0:	910003fd 	mov	x29, sp
    42c4:	f9407042 	ldr	x2, [x2, #224]
    42c8:	91400021 	add	x1, x1, #0x0, lsl #12
    42cc:	91004021 	add	x1, x1, #0x10
    42d0:	a90153f3 	stp	x19, x20, [sp, #16]
    42d4:	aa0003f3 	mov	x19, x0
    42d8:	f9400034 	ldr	x20, [x1]
    42dc:	b4000062 	cbz	x2, 42e8 <fwp_trap+0x34>
    42e0:	aa0203e0 	mov	x0, x2
    42e4:	97fff997 	bl	2940 <fflush@plt>
    42e8:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    42ec:	f947ec00 	ldr	x0, [x0, #4056]
    42f0:	f9400000 	ldr	x0, [x0]
    42f4:	97fff993 	bl	2940 <fflush@plt>
    42f8:	aa1303e3 	mov	x3, x19
    42fc:	f0000022 	adrp	x2, b000 <__modti3+0x2a0>
    4300:	f00000d3 	adrp	x19, 1f000 <fwp_fn_table+0xb30>
    4304:	f947ea73 	ldr	x19, [x19, #4048]
    4308:	91112042 	add	x2, x2, #0x448
    430c:	52800041 	mov	w1, #0x2                   	// #2
    4310:	f9400260 	ldr	x0, [x19]
    4314:	97fff95b 	bl	2880 <__fprintf_chk@plt>
    4318:	b40000b4 	cbz	x20, 432c <fwp_trap+0x78>
    431c:	f9400260 	ldr	x0, [x19]
    4320:	97fff988 	bl	2940 <fflush@plt>
    4324:	52800ca0 	mov	w0, #0x65                  	// #101
    4328:	97fff996 	bl	2980 <_Exit@plt>
    432c:	52800ca0 	mov	w0, #0x65                  	// #101
    4330:	97fff8e4 	bl	26c0 <exit@plt>

0000000000004334 <fwp_rc_forget_slot.part.0>:
    4334:	ca404401 	eor	x1, x0, x0, lsr #17
    4338:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    433c:	ca412421 	eor	x1, x1, x1, lsr #9
    4340:	910003fd 	mov	x29, sp
    4344:	92401c21 	and	x1, x1, #0xff
    4348:	f9000bf3 	str	x19, [sp, #16]
    434c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4350:	9118c262 	add	x2, x19, #0x630
    4354:	910a2423 	add	x3, x1, #0x289
    4358:	8b010c41 	add	x1, x2, x1, lsl #3
    435c:	8b030c43 	add	x3, x2, x3, lsl #3
    4360:	f94a2421 	ldr	x1, [x1, #5192]
    4364:	b50000a1 	cbnz	x1, 4378 <fwp_rc_forget_slot.part.0+0x44>
    4368:	14000012 	b	43b0 <fwp_rc_forget_slot.part.0+0x7c>
    436c:	91004023 	add	x3, x1, #0x10
    4370:	f9400821 	ldr	x1, [x1, #16]
    4374:	b40001e1 	cbz	x1, 43b0 <fwp_rc_forget_slot.part.0+0x7c>
    4378:	f9400022 	ldr	x2, [x1]
    437c:	eb02001f 	cmp	x0, x2
    4380:	54ffff61 	b.ne	436c <fwp_rc_forget_slot.part.0+0x38>  // b.any
    4384:	f9400060 	ldr	x0, [x3]
    4388:	9118c273 	add	x19, x19, #0x630
    438c:	f9400801 	ldr	x1, [x0, #16]
    4390:	f9000061 	str	x1, [x3]
    4394:	97fff94f 	bl	28d0 <free@plt>
    4398:	f94e2660 	ldr	x0, [x19, #7240]
    439c:	d1000400 	sub	x0, x0, #0x1
    43a0:	f90e2660 	str	x0, [x19, #7240]
    43a4:	f9400bf3 	ldr	x19, [sp, #16]
    43a8:	a8c27bfd 	ldp	x29, x30, [sp], #32
    43ac:	d65f03c0 	ret
    43b0:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    43b4:	91116000 	add	x0, x0, #0x458
    43b8:	97ffffbf 	bl	42b4 <fwp_trap>
    43bc:	d503201f 	nop

00000000000043c0 <fwp_rc_prepare_chunk>:
    43c0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    43c4:	910003fd 	mov	x29, sp
    43c8:	a9025bf5 	stp	x21, x22, [sp, #32]
    43cc:	b00003b6 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    43d0:	9118c2c2 	add	x2, x22, #0x630
    43d4:	b9401c03 	ldr	w3, [x0, #28]
    43d8:	aa0103f5 	mov	x21, x1
    43dc:	a90153f3 	stp	x19, x20, [sp, #16]
    43e0:	aa0003f4 	mov	x20, x0
    43e4:	f94e2440 	ldr	x0, [x2, #7240]
    43e8:	b4000440 	cbz	x0, 4470 <fwp_rc_prepare_chunk+0xb0>
    43ec:	d2800013 	mov	x19, #0x0                   	// #0
    43f0:	35000203 	cbnz	w3, 4430 <fwp_rc_prepare_chunk+0x70>
    43f4:	b4000361 	cbz	x1, 4460 <fwp_rc_prepare_chunk+0xa0>
    43f8:	f9401280 	ldr	x0, [x20, #32]
    43fc:	97fff935 	bl	28d0 <free@plt>
    4400:	aa1503e0 	mov	x0, x21
    4404:	d2800021 	mov	x1, #0x1                   	// #1
    4408:	97fff8fa 	bl	27f0 <calloc@plt>
    440c:	f9001280 	str	x0, [x20, #32]
    4410:	b5000460 	cbnz	x0, 449c <fwp_rc_prepare_chunk+0xdc>
    4414:	97fffb37 	bl	30f0 <fwp_heap_oom>
    4418:	97ffffc7 	bl	4334 <fwp_rc_forget_slot.part.0>
    441c:	91000673 	add	x19, x19, #0x1
    4420:	b9401e83 	ldr	w3, [x20, #28]
    4424:	eb13007f 	cmp	x3, x19
    4428:	54000169 	b.ls	4454 <fwp_rc_prepare_chunk+0x94>  // b.plast
    442c:	d503201f 	nop
    4430:	f9401283 	ldr	x3, [x20, #32]
    4434:	8b130060 	add	x0, x3, x19
    4438:	38736863 	ldrb	w3, [x3, x19]
    443c:	7103fc7f 	cmp	w3, #0xff
    4440:	54fffec0 	b.eq	4418 <fwp_rc_prepare_chunk+0x58>  // b.none
    4444:	b9401e83 	ldr	w3, [x20, #28]
    4448:	91000673 	add	x19, x19, #0x1
    444c:	eb13007f 	cmp	x3, x19
    4450:	54ffff08 	b.hi	4430 <fwp_rc_prepare_chunk+0x70>  // b.pmore
    4454:	eb0302bf 	cmp	x21, x3
    4458:	54000121 	b.ne	447c <fwp_rc_prepare_chunk+0xbc>  // b.any
    445c:	b5000335 	cbnz	x21, 44c0 <fwp_rc_prepare_chunk+0x100>
    4460:	a94153f3 	ldp	x19, x20, [sp, #16]
    4464:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4468:	a8c37bfd 	ldp	x29, x30, [sp], #48
    446c:	d65f03c0 	ret
    4470:	2a0303e3 	mov	w3, w3
    4474:	eb0302bf 	cmp	x21, x3
    4478:	54ffff20 	b.eq	445c <fwp_rc_prepare_chunk+0x9c>  // b.none
    447c:	9118c2c2 	add	x2, x22, #0x630
    4480:	f9401280 	ldr	x0, [x20, #32]
    4484:	f94e2841 	ldr	x1, [x2, #7248]
    4488:	cb030021 	sub	x1, x1, x3
    448c:	f90e2841 	str	x1, [x2, #7248]
    4490:	97fff910 	bl	28d0 <free@plt>
    4494:	b5fffb75 	cbnz	x21, 4400 <fwp_rc_prepare_chunk+0x40>
    4498:	f900129f 	str	xzr, [x20, #32]
    449c:	9118c2d6 	add	x22, x22, #0x630
    44a0:	f94e2ac0 	ldr	x0, [x22, #7248]
    44a4:	b9001e95 	str	w21, [x20, #28]
    44a8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44ac:	8b150000 	add	x0, x0, x21
    44b0:	f90e2ac0 	str	x0, [x22, #7248]
    44b4:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44b8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44bc:	d65f03c0 	ret
    44c0:	f9401280 	ldr	x0, [x20, #32]
    44c4:	aa1503e2 	mov	x2, x21
    44c8:	a94153f3 	ldp	x19, x20, [sp, #16]
    44cc:	52800001 	mov	w1, #0x0                   	// #0
    44d0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    44d4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    44d8:	17fff8c2 	b	27e0 <memset@plt>
    44dc:	d503201f 	nop

00000000000044e0 <fwp_heap_refill>:
    44e0:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    44e4:	910003fd 	mov	x29, sp
    44e8:	a9025bf5 	stp	x21, x22, [sp, #32]
    44ec:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    44f0:	9118c2b5 	add	x21, x21, #0x630
    44f4:	aa0003f6 	mov	x22, x0
    44f8:	d2800020 	mov	x0, #0x1                   	// #1
    44fc:	a90153f3 	stp	x19, x20, [sp, #16]
    4500:	a90363f7 	stp	x23, x24, [sp, #48]
    4504:	2a0103f7 	mov	w23, w1
    4508:	2a0203f8 	mov	w24, w2
    450c:	97fffb09 	bl	3130 <fwp_heap_chunks>
    4510:	aa0003f3 	mov	x19, x0
    4514:	f949fea2 	ldr	x2, [x21, #5112]
    4518:	8b000800 	add	x0, x0, x0, lsl #2
    451c:	2a1703e1 	mov	w1, w23
    4520:	52800025 	mov	w5, #0x1                   	// #1
    4524:	d37df000 	lsl	x0, x0, #3
    4528:	910f0021 	add	x1, x1, #0x3c0
    452c:	8b000054 	add	x20, x2, x0
    4530:	b2407fe3 	mov	x3, #0xffffffff            	// #4294967295
    4534:	52a00024 	mov	w4, #0x10000               	// #65536
    4538:	38206845 	strb	w5, [x2, x0]
    453c:	aa1403e0 	mov	x0, x20
    4540:	39000698 	strb	w24, [x20, #1]
    4544:	39000a97 	strb	w23, [x20, #2]
    4548:	b8617aa1 	ldr	w1, [x21, x1, lsl #2]
    454c:	b9000681 	str	w1, [x20, #4]
    4550:	2a0103e5 	mov	w5, w1
    4554:	8b0300a2 	add	x2, x5, x3
    4558:	1ac10881 	udiv	w1, w4, w1
    455c:	9ac50842 	udiv	x2, x2, x5
    4560:	b9000a81 	str	w1, [x20, #8]
    4564:	92404021 	and	x1, x1, #0x1ffff
    4568:	b9001a82 	str	w2, [x20, #24]
    456c:	97ffff95 	bl	43c0 <fwp_rc_prepare_chunk>
    4570:	f949daa0 	ldr	x0, [x21, #5040]
    4574:	29408a81 	ldp	w1, w2, [x20, #4]
    4578:	8b134000 	add	x0, x0, x19, lsl #16
    457c:	a94153f3 	ldp	x19, x20, [sp, #16]
    4580:	8b214003 	add	x3, x0, w1, uxtw
    4584:	9ba20021 	umaddl	x1, w1, w2, x0
    4588:	a94363f7 	ldp	x23, x24, [sp, #48]
    458c:	a90086c3 	stp	x3, x1, [x22, #8]
    4590:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4594:	a8c47bfd 	ldp	x29, x30, [sp], #64
    4598:	d65f03c0 	ret
    459c:	d503201f 	nop

00000000000045a0 <fwp_mem_free>:
    45a0:	b40003c0 	cbz	x0, 4618 <fwp_mem_free+0x78>
    45a4:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    45a8:	910003fd 	mov	x29, sp
    45ac:	a9025bf5 	stp	x21, x22, [sp, #32]
    45b0:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    45b4:	9118c2a1 	add	x1, x21, #0x630
    45b8:	a90153f3 	stp	x19, x20, [sp, #16]
    45bc:	aa0003f3 	mov	x19, x0
    45c0:	f949d823 	ldr	x3, [x1, #5040]
    45c4:	f949ec22 	ldr	x2, [x1, #5080]
    45c8:	cb030000 	sub	x0, x0, x3
    45cc:	eb02401f 	cmp	x0, x2, lsl #16
    45d0:	540001c2 	b.cs	4608 <fwp_mem_free+0x68>  // b.hs, b.nlast
    45d4:	d350fc16 	lsr	x22, x0, #16
    45d8:	a90363f7 	stp	x23, x24, [sp, #48]
    45dc:	f949fc22 	ldr	x2, [x1, #5112]
    45e0:	8b160ad4 	add	x20, x22, x22, lsl #2
    45e4:	d37df294 	lsl	x20, x20, #3
    45e8:	ab140057 	adds	x23, x2, x20
    45ec:	540000c0 	b.eq	4604 <fwp_mem_free+0x64>  // b.none
    45f0:	38746842 	ldrb	w2, [x2, x20]
    45f4:	7100045f 	cmp	w2, #0x1
    45f8:	54000120 	b.eq	461c <fwp_mem_free+0x7c>  // b.none
    45fc:	7100085f 	cmp	w2, #0x2
    4600:	540005e0 	b.eq	46bc <fwp_mem_free+0x11c>  // b.none
    4604:	a94363f7 	ldp	x23, x24, [sp, #48]
    4608:	a94153f3 	ldp	x19, x20, [sp, #16]
    460c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4610:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4614:	d65f03c0 	ret
    4618:	d65f03c0 	ret
    461c:	f94012f8 	ldr	x24, [x23, #32]
    4620:	b94006e1 	ldr	w1, [x23, #4]
    4624:	f90023f9 	str	x25, [sp, #64]
    4628:	2a0103e2 	mov	w2, w1
    462c:	394006f9 	ldrb	w25, [x23, #1]
    4630:	39400af4 	ldrb	w20, [x23, #2]
    4634:	b4000158 	cbz	x24, 465c <fwp_mem_free+0xbc>
    4638:	92403e76 	and	x22, x19, #0xffff
    463c:	9ac20ad6 	udiv	x22, x22, x2
    4640:	38766b01 	ldrb	w1, [x24, x22]
    4644:	8b160300 	add	x0, x24, x22
    4648:	7103fc3f 	cmp	w1, #0xff
    464c:	54000980 	b.eq	477c <fwp_mem_free+0x1dc>  // b.none
    4650:	38366b1f 	strb	wzr, [x24, x22]
    4654:	b94006e1 	ldr	w1, [x23, #4]
    4658:	2a0103e2 	mov	w2, w1
    465c:	d37c1f20 	ubfiz	x0, x25, #4, #8
    4660:	d37f1e83 	ubfiz	x3, x20, #1, #8
    4664:	cb390000 	sub	x0, x0, w25, uxtb
    4668:	8b340074 	add	x20, x3, w20, uxtb
    466c:	9118c2b5 	add	x21, x21, #0x630
    4670:	1e630021 	ucvtf	d1, w1
    4674:	d37ae400 	lsl	x0, x0, #6
    4678:	8b140c14 	add	x20, x0, x20, lsl #3
    467c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4680:	f8746aa0 	ldr	x0, [x21, x20]
    4684:	f94023f9 	ldr	x25, [sp, #64]
    4688:	aa2003e0 	mvn	x0, x0
    468c:	fd4a22a0 	ldr	d0, [x21, #5184]
    4690:	f9000260 	str	x0, [x19]
    4694:	f8346ab3 	str	x19, [x21, x20]
    4698:	f94a12a0 	ldr	x0, [x21, #5152]
    469c:	1e612800 	fadd	d0, d0, d1
    46a0:	a94153f3 	ldp	x19, x20, [sp, #16]
    46a4:	cb020000 	sub	x0, x0, x2
    46a8:	f90a12a0 	str	x0, [x21, #5152]
    46ac:	fd0a22a0 	str	d0, [x21, #5184]
    46b0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    46b4:	a8c57bfd 	ldp	x29, x30, [sp], #80
    46b8:	d65f03c0 	ret
    46bc:	9270bc00 	and	x0, x0, #0xffffffffffff0000
    46c0:	8b000063 	add	x3, x3, x0
    46c4:	eb03027f 	cmp	x19, x3
    46c8:	54fff9e1 	b.ne	4604 <fwp_mem_free+0x64>  // b.any
    46cc:	fd400ae1 	ldr	d1, [x23, #16]
    46d0:	fd4a2020 	ldr	d0, [x1, #5184]
    46d4:	f9400ae0 	ldr	x0, [x23, #16]
    46d8:	7e61d821 	ucvtf	d1, d1
    46dc:	f94a1022 	ldr	x2, [x1, #5152]
    46e0:	f94012f3 	ldr	x19, [x23, #32]
    46e4:	1e612800 	fadd	d0, d0, d1
    46e8:	cb000042 	sub	x2, x2, x0
    46ec:	f90a1022 	str	x2, [x1, #5152]
    46f0:	fd0a2020 	str	d0, [x1, #5184]
    46f4:	b40000b3 	cbz	x19, 4708 <fwp_mem_free+0x168>
    46f8:	39400260 	ldrb	w0, [x19]
    46fc:	7103fc1f 	cmp	w0, #0xff
    4700:	54000380 	b.eq	4770 <fwp_mem_free+0x1d0>  // b.none
    4704:	3900027f 	strb	wzr, [x19]
    4708:	b9400ee2 	ldr	w2, [x23, #12]
    470c:	b4000142 	cbz	x2, 4734 <fwp_mem_free+0x194>
    4710:	9118c2a1 	add	x1, x21, #0x630
    4714:	8b160040 	add	x0, x2, x22
    4718:	8b000800 	add	x0, x0, x0, lsl #2
    471c:	f949fc21 	ldr	x1, [x1, #5112]
    4720:	8b140034 	add	x20, x1, x20
    4724:	8b000c20 	add	x0, x1, x0, lsl #3
    4728:	3802869f 	strb	wzr, [x20], #40
    472c:	eb00029f 	cmp	x20, x0
    4730:	54ffffc1 	b.ne	4728 <fwp_mem_free+0x188>  // b.any
    4734:	9118c2a0 	add	x0, x21, #0x630
    4738:	f94a1801 	ldr	x1, [x0, #5168]
    473c:	f949f803 	ldr	x3, [x0, #5104]
    4740:	8b020021 	add	x1, x1, x2
    4744:	f90a1801 	str	x1, [x0, #5168]
    4748:	eb16007f 	cmp	x3, x22
    474c:	54000049 	b.ls	4754 <fwp_mem_free+0x1b4>  // b.plast
    4750:	f909f816 	str	x22, [x0, #5104]
    4754:	9118c2b5 	add	x21, x21, #0x630
    4758:	f949f6a0 	ldr	x0, [x21, #5096]
    475c:	eb16001f 	cmp	x0, x22
    4760:	54fff529 	b.ls	4604 <fwp_mem_free+0x64>  // b.plast
    4764:	a94363f7 	ldp	x23, x24, [sp, #48]
    4768:	f909f6b6 	str	x22, [x21, #5096]
    476c:	17ffffa7 	b	4608 <fwp_mem_free+0x68>
    4770:	aa1303e0 	mov	x0, x19
    4774:	97fffef0 	bl	4334 <fwp_rc_forget_slot.part.0>
    4778:	17ffffe3 	b	4704 <fwp_mem_free+0x164>
    477c:	97fffeee 	bl	4334 <fwp_rc_forget_slot.part.0>
    4780:	17ffffb4 	b	4650 <fwp_mem_free+0xb0>

0000000000004784 <fwp_rc_wide_dup>:
    4784:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    4788:	910003fd 	mov	x29, sp
    478c:	a90153f3 	stp	x19, x20, [sp, #16]
    4790:	aa0003f3 	mov	x19, x0
    4794:	ca404400 	eor	x0, x0, x0, lsr #17
    4798:	f90013f5 	str	x21, [sp, #32]
    479c:	b00003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    47a0:	ca402400 	eor	x0, x0, x0, lsr #9
    47a4:	9118c2a2 	add	x2, x21, #0x630
    47a8:	92401c00 	and	x0, x0, #0xff
    47ac:	910a2403 	add	x3, x0, #0x289
    47b0:	8b000c40 	add	x0, x2, x0, lsl #3
    47b4:	8b030c54 	add	x20, x2, x3, lsl #3
    47b8:	f94a2401 	ldr	x1, [x0, #5192]
    47bc:	b50000a1 	cbnz	x1, 47d0 <fwp_rc_wide_dup+0x4c>
    47c0:	14000033 	b	488c <fwp_rc_wide_dup+0x108>
    47c4:	91004034 	add	x20, x1, #0x10
    47c8:	f9400821 	ldr	x1, [x1, #16]
    47cc:	b4000241 	cbz	x1, 4814 <fwp_rc_wide_dup+0x90>
    47d0:	f9400022 	ldr	x2, [x1]
    47d4:	eb02027f 	cmp	x19, x2
    47d8:	54ffff61 	b.ne	47c4 <fwp_rc_wide_dup+0x40>  // b.any
    47dc:	f9400281 	ldr	x1, [x20]
    47e0:	39400260 	ldrb	w0, [x19]
    47e4:	7103f81f 	cmp	w0, #0xfe
    47e8:	54000220 	b.eq	482c <fwp_rc_wide_dup+0xa8>  // b.none
    47ec:	b40001a1 	cbz	x1, 4820 <fwp_rc_wide_dup+0x9c>
    47f0:	f9400420 	ldr	x0, [x1, #8]
    47f4:	b100041f 	cmn	x0, #0x1
    47f8:	54000440 	b.eq	4880 <fwp_rc_wide_dup+0xfc>  // b.none
    47fc:	91000400 	add	x0, x0, #0x1
    4800:	f9000420 	str	x0, [x1, #8]
    4804:	a94153f3 	ldp	x19, x20, [sp, #16]
    4808:	f94013f5 	ldr	x21, [sp, #32]
    480c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4810:	d65f03c0 	ret
    4814:	39400260 	ldrb	w0, [x19]
    4818:	7103f81f 	cmp	w0, #0xfe
    481c:	54000100 	b.eq	483c <fwp_rc_wide_dup+0xb8>  // b.none
    4820:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4824:	91116000 	add	x0, x0, #0x458
    4828:	97fffea3 	bl	42b4 <fwp_trap>
    482c:	b4000081 	cbz	x1, 483c <fwp_rc_wide_dup+0xb8>
    4830:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4834:	91120000 	add	x0, x0, #0x480
    4838:	97fffe9f 	bl	42b4 <fwp_trap>
    483c:	d2800300 	mov	x0, #0x18                  	// #24
    4840:	97fff7dc 	bl	27b0 <malloc@plt>
    4844:	b4000280 	cbz	x0, 4894 <fwp_rc_wide_dup+0x110>
    4848:	d2801fe1 	mov	x1, #0xff                  	// #255
    484c:	a9000413 	stp	x19, x1, [x0]
    4850:	9118c2b5 	add	x21, x21, #0x630
    4854:	f900081f 	str	xzr, [x0, #16]
    4858:	12800001 	mov	w1, #0xffffffff            	// #-1
    485c:	f9000280 	str	x0, [x20]
    4860:	39000261 	strb	w1, [x19]
    4864:	f94e26a0 	ldr	x0, [x21, #7240]
    4868:	a94153f3 	ldp	x19, x20, [sp, #16]
    486c:	91000400 	add	x0, x0, #0x1
    4870:	f90e26a0 	str	x0, [x21, #7240]
    4874:	f94013f5 	ldr	x21, [sp, #32]
    4878:	a8c37bfd 	ldp	x29, x30, [sp], #48
    487c:	d65f03c0 	ret
    4880:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4884:	9112a000 	add	x0, x0, #0x4a8
    4888:	97fffe8b 	bl	42b4 <fwp_trap>
    488c:	f8637841 	ldr	x1, [x2, x3, lsl #3]
    4890:	17ffffd4 	b	47e0 <fwp_rc_wide_dup+0x5c>
    4894:	97fffa17 	bl	30f0 <fwp_heap_oom>
    4898:	d503201f 	nop
    489c:	d503201f 	nop

00000000000048a0 <fwp_closure_drop_push>:
    48a0:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    48a4:	910003fd 	mov	x29, sp
    48a8:	a90153f3 	stp	x19, x20, [sp, #16]
    48ac:	aa0003f3 	mov	x19, x0
    48b0:	a9408014 	ldp	x20, x0, [x0, #8]
    48b4:	a9025bf5 	stp	x21, x22, [sp, #32]
    48b8:	aa0103f5 	mov	x21, x1
    48bc:	a90363f7 	stp	x23, x24, [sp, #48]
    48c0:	eb00029f 	cmp	x20, x0
    48c4:	54000160 	b.eq	48f0 <fwp_closure_drop_push+0x50>  // b.none
    48c8:	f9400276 	ldr	x22, [x19]
    48cc:	d37df297 	lsl	x23, x20, #3
    48d0:	91000694 	add	x20, x20, #0x1
    48d4:	f9000674 	str	x20, [x19, #8]
    48d8:	a94153f3 	ldp	x19, x20, [sp, #16]
    48dc:	f8376ad5 	str	x21, [x22, x23]
    48e0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    48e4:	a94363f7 	ldp	x23, x24, [sp, #48]
    48e8:	a8c57bfd 	ldp	x29, x30, [sp], #80
    48ec:	d65f03c0 	ret
    48f0:	a9046bf9 	stp	x25, x26, [sp, #64]
    48f4:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    48f8:	eb00029f 	cmp	x20, x0
    48fc:	540003e8 	b.hi	4978 <fwp_closure_drop_push+0xd8>  // b.pmore
    4900:	d37cee99 	lsl	x25, x20, #4
    4904:	d37ffa9a 	lsl	x26, x20, #1
    4908:	aa1903e0 	mov	x0, x25
    490c:	97fff7a9 	bl	27b0 <malloc@plt>
    4910:	aa0003f6 	mov	x22, x0
    4914:	b4000380 	cbz	x0, 4984 <fwp_closure_drop_push+0xe4>
    4918:	aa1303f8 	mov	x24, x19
    491c:	aa1903e3 	mov	x3, x25
    4920:	d37df297 	lsl	x23, x20, #3
    4924:	aa1703e2 	mov	x2, x23
    4928:	f8418719 	ldr	x25, [x24], #24
    492c:	aa1903e1 	mov	x1, x25
    4930:	97fff78c 	bl	2760 <__memcpy_chk@plt>
    4934:	eb18033f 	cmp	x25, x24
    4938:	540000a0 	b.eq	494c <fwp_closure_drop_push+0xac>  // b.none
    493c:	aa1903e0 	mov	x0, x25
    4940:	97fff7e4 	bl	28d0 <free@plt>
    4944:	f9400674 	ldr	x20, [x19, #8]
    4948:	d37df297 	lsl	x23, x20, #3
    494c:	91000694 	add	x20, x20, #0x1
    4950:	f9000276 	str	x22, [x19]
    4954:	f9000a7a 	str	x26, [x19, #16]
    4958:	a9446bf9 	ldp	x25, x26, [sp, #64]
    495c:	f9000674 	str	x20, [x19, #8]
    4960:	f8376ad5 	str	x21, [x22, x23]
    4964:	a94153f3 	ldp	x19, x20, [sp, #16]
    4968:	a9425bf5 	ldp	x21, x22, [sp, #32]
    496c:	a94363f7 	ldp	x23, x24, [sp, #48]
    4970:	a8c57bfd 	ldp	x29, x30, [sp], #80
    4974:	d65f03c0 	ret
    4978:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    497c:	91132000 	add	x0, x0, #0x4c8
    4980:	97fffe4d 	bl	42b4 <fwp_trap>
    4984:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    4988:	f947e863 	ldr	x3, [x3, #4048]
    498c:	d2800262 	mov	x2, #0x13                  	// #19
    4990:	d2800021 	mov	x1, #0x1                   	// #1
    4994:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4998:	91042000 	add	x0, x0, #0x108
    499c:	f9400063 	ldr	x3, [x3]
    49a0:	97fff7dc 	bl	2910 <fwrite@plt>
    49a4:	d2800000 	mov	x0, #0x0                   	// #0
    49a8:	97fff7e6 	bl	2940 <fflush@plt>
    49ac:	52800cc0 	mov	w0, #0x66                  	// #102
    49b0:	97fff7f4 	bl	2980 <_Exit@plt>

00000000000049b4 <fwp_closure_drop.part.0>:
    49b4:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    49b8:	90000041 	adrp	x1, c000 <_IO_stdin_used+0xf00>
    49bc:	910003fd 	mov	x29, sp
    49c0:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    49c4:	f947f463 	ldr	x3, [x3, #4072]
    49c8:	a90153f3 	stp	x19, x20, [sp, #16]
    49cc:	d10883ff 	sub	sp, sp, #0x220
    49d0:	910003e2 	mov	x2, sp
    49d4:	d53bd053 	mrs	x19, tpidr_el0
    49d8:	910063f4 	add	x20, sp, #0x18
    49dc:	3dc02c20 	ldr	q0, [x1, #176]
    49e0:	91400264 	add	x4, x19, #0x0, lsl #12
    49e4:	91004084 	add	x4, x4, #0x10
    49e8:	aa0003e1 	mov	x1, x0
    49ec:	aa0203e0 	mov	x0, x2
    49f0:	f9400062 	ldr	x2, [x3]
    49f4:	f9010fe2 	str	x2, [sp, #536]
    49f8:	d2800002 	mov	x2, #0x0                   	// #0
    49fc:	f90003f4 	str	x20, [sp]
    4a00:	f9000080 	str	x0, [x4]
    4a04:	3c8083e0 	stur	q0, [sp, #8]
    4a08:	97ffffa6 	bl	48a0 <fwp_closure_drop_push>
    4a0c:	f94007e0 	ldr	x0, [sp, #8]
    4a10:	b40002e0 	cbz	x0, 4a6c <fwp_closure_drop.part.0+0xb8>
    4a14:	f90123f5 	str	x21, [sp, #576]
    4a18:	900000f5 	adrp	x21, 20000 <__data_start>
    4a1c:	910142b5 	add	x21, x21, #0x50
    4a20:	14000006 	b	4a38 <fwp_closure_drop.part.0+0x84>
    4a24:	f9400422 	ldr	x2, [x1, #8]
    4a28:	52800001 	mov	w1, #0x0                   	// #0
    4a2c:	d63f0040 	blr	x2
    4a30:	f94007e0 	ldr	x0, [sp, #8]
    4a34:	b40001a0 	cbz	x0, 4a68 <fwp_closure_drop.part.0+0xb4>
    4a38:	f94003e1 	ldr	x1, [sp]
    4a3c:	d1000400 	sub	x0, x0, #0x1
    4a40:	f90007e0 	str	x0, [sp, #8]
    4a44:	f9408ea2 	ldr	x2, [x21, #280]
    4a48:	f8607820 	ldr	x0, [x1, x0, lsl #3]
    4a4c:	b9400001 	ldr	w1, [x0]
    4a50:	8b011441 	add	x1, x2, x1, lsl #5
    4a54:	f9400c21 	ldr	x1, [x1, #24]
    4a58:	b5fffe61 	cbnz	x1, 4a24 <fwp_closure_drop.part.0+0x70>
    4a5c:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4a60:	9113a000 	add	x0, x0, #0x4e8
    4a64:	97fffe14 	bl	42b4 <fwp_trap>
    4a68:	f94123f5 	ldr	x21, [sp, #576]
    4a6c:	91400273 	add	x19, x19, #0x0, lsl #12
    4a70:	91004273 	add	x19, x19, #0x10
    4a74:	f94003e0 	ldr	x0, [sp]
    4a78:	f900027f 	str	xzr, [x19]
    4a7c:	eb14001f 	cmp	x0, x20
    4a80:	54000040 	b.eq	4a88 <fwp_closure_drop.part.0+0xd4>  // b.none
    4a84:	97fff793 	bl	28d0 <free@plt>
    4a88:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4a8c:	f947f400 	ldr	x0, [x0, #4072]
    4a90:	f9410fe2 	ldr	x2, [sp, #536]
    4a94:	f9400001 	ldr	x1, [x0]
    4a98:	eb010042 	subs	x2, x2, x1
    4a9c:	d2800001 	mov	x1, #0x0                   	// #0
    4aa0:	540000a1 	b.ne	4ab4 <fwp_closure_drop.part.0+0x100>  // b.any
    4aa4:	910883ff 	add	sp, sp, #0x220
    4aa8:	a94153f3 	ldp	x19, x20, [sp, #16]
    4aac:	a8c37bfd 	ldp	x29, x30, [sp], #48
    4ab0:	d65f03c0 	ret
    4ab4:	f90123f5 	str	x21, [sp, #576]
    4ab8:	97fff756 	bl	2810 <__stack_chk_fail@plt>
    4abc:	d503201f 	nop

0000000000004ac0 <fwp_tape_of>:
    4ac0:	aa0003e1 	mov	x1, x0
    4ac4:	92403c00 	and	x0, x0, #0xffff
    4ac8:	b40000e0 	cbz	x0, 4ae4 <fwp_tape_of+0x24>
    4acc:	d1000402 	sub	x2, x0, #0x1
    4ad0:	900000e0 	adrp	x0, 20000 <__data_start>
    4ad4:	91014000 	add	x0, x0, #0x50
    4ad8:	f9409003 	ldr	x3, [x0, #288]
    4adc:	eb02007f 	cmp	x3, x2
    4ae0:	540000cc 	b.gt	4af8 <fwp_tape_of+0x38>
    4ae4:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    4ae8:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4aec:	91146000 	add	x0, x0, #0x518
    4af0:	910003fd 	mov	x29, sp
    4af4:	97fffdf0 	bl	42b4 <fwp_trap>
    4af8:	8b020443 	add	x3, x2, x2, lsl #1
    4afc:	f9404404 	ldr	x4, [x0, #136]
    4b00:	8b030842 	add	x2, x2, x3, lsl #2
    4b04:	d37df042 	lsl	x2, x2, #3
    4b08:	8b020080 	add	x0, x4, x2
    4b0c:	b9400403 	ldr	w3, [x0, #4]
    4b10:	34fffea3 	cbz	w3, 4ae4 <fwp_tape_of+0x24>
    4b14:	b8626882 	ldr	w2, [x4, x2]
    4b18:	9350fc21 	asr	x1, x1, #16
    4b1c:	6b01005f 	cmp	w2, w1
    4b20:	54fffe21 	b.ne	4ae4 <fwp_tape_of+0x24>  // b.any
    4b24:	d65f03c0 	ret
    4b28:	d503201f 	nop
    4b2c:	d503201f 	nop

0000000000004b30 <fwp_now_ns>:
    4b30:	d100c3ff 	sub	sp, sp, #0x30
    4b34:	52800020 	mov	w0, #0x1                   	// #1
    4b38:	f00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    4b3c:	f947f442 	ldr	x2, [x2, #4072]
    4b40:	910023e1 	add	x1, sp, #0x8
    4b44:	a9027bfd 	stp	x29, x30, [sp, #32]
    4b48:	910083fd 	add	x29, sp, #0x20
    4b4c:	f9400043 	ldr	x3, [x2]
    4b50:	f9000fe3 	str	x3, [sp, #24]
    4b54:	d2800003 	mov	x3, #0x0                   	// #0
    4b58:	97fff6fa 	bl	2740 <clock_gettime@plt>
    4b5c:	350002c0 	cbnz	w0, 4bb4 <fwp_now_ns+0x84>
    4b60:	a9408be1 	ldp	x1, x2, [sp, #8]
    4b64:	d2994003 	mov	x3, #0xca00                	// #51712
    4b68:	f2a77343 	movk	x3, #0x3b9a, lsl #16
    4b6c:	9b037c20 	mul	x0, x1, x3
    4b70:	9b437c21 	smulh	x1, x1, x3
    4b74:	ab020000 	adds	x0, x0, x2
    4b78:	937ffc42 	asr	x2, x2, #63
    4b7c:	9a020021 	adc	x1, x1, x2
    4b80:	f100001f 	cmp	x0, #0x0
    4b84:	9a81a421 	cinc	x1, x1, lt	// lt = tstop
    4b88:	b50001c1 	cbnz	x1, 4bc0 <fwp_now_ns+0x90>
    4b8c:	f00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    4b90:	f947f421 	ldr	x1, [x1, #4072]
    4b94:	f9400fe3 	ldr	x3, [sp, #24]
    4b98:	f9400022 	ldr	x2, [x1]
    4b9c:	eb020063 	subs	x3, x3, x2
    4ba0:	d2800002 	mov	x2, #0x0                   	// #0
    4ba4:	54000141 	b.ne	4bcc <fwp_now_ns+0x9c>  // b.any
    4ba8:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4bac:	9100c3ff 	add	sp, sp, #0x30
    4bb0:	d65f03c0 	ret
    4bb4:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4bb8:	9115a000 	add	x0, x0, #0x568
    4bbc:	97fffdbe 	bl	42b4 <fwp_trap>
    4bc0:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4bc4:	91162000 	add	x0, x0, #0x588
    4bc8:	97fffdbb 	bl	42b4 <fwp_trap>
    4bcc:	97fff711 	bl	2810 <__stack_chk_fail@plt>

0000000000004bd0 <fwp_poll_events>:
    4bd0:	d10103ff 	sub	sp, sp, #0x40
    4bd4:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4bd8:	f947f400 	ldr	x0, [x0, #4072]
    4bdc:	a9027bfd 	stp	x29, x30, [sp, #32]
    4be0:	910083fd 	add	x29, sp, #0x20
    4be4:	f9001bf3 	str	x19, [sp, #48]
    4be8:	900000f3 	adrp	x19, 20000 <__data_start>
    4bec:	f9400001 	ldr	x1, [x0]
    4bf0:	f9000fe1 	str	x1, [sp, #24]
    4bf4:	d2800001 	mov	x1, #0x0                   	// #0
    4bf8:	97ffffce 	bl	4b30 <fwp_now_ns>
    4bfc:	91014261 	add	x1, x19, #0x50
    4c00:	f9409421 	ldr	x1, [x1, #296]
    4c04:	b4000e01 	cbz	x1, 4dc4 <fwp_poll_events+0x1f4>
    4c08:	92800002 	mov	x2, #0xffffffffffffffff    	// #-1
    4c0c:	14000005 	b	4c20 <fwp_poll_events+0x50>
    4c10:	f9408821 	ldr	x1, [x1, #272]
    4c14:	eb03005f 	cmp	x2, x3
    4c18:	9a83d042 	csel	x2, x2, x3, le
    4c1c:	b40000c1 	cbz	x1, 4c34 <fwp_poll_events+0x64>
    4c20:	f9403423 	ldr	x3, [x1, #104]
    4c24:	b6ffff62 	tbz	x2, #63, 4c10 <fwp_poll_events+0x40>
    4c28:	f9408821 	ldr	x1, [x1, #272]
    4c2c:	aa0303e2 	mov	x2, x3
    4c30:	b5ffff81 	cbnz	x1, 4c20 <fwp_poll_events+0x50>
    4c34:	b7f80c82 	tbnz	x2, #63, 4dc4 <fwp_poll_events+0x1f4>
    4c38:	cb000042 	sub	x2, x2, x0
    4c3c:	f100005f 	cmp	x2, #0x0
    4c40:	540003ad 	b.le	4cb4 <fwp_poll_events+0xe4>
    4c44:	d2869b60 	mov	x0, #0x34db                	// #13531
    4c48:	d2884804 	mov	x4, #0x4240                	// #16960
    4c4c:	f2baf6c0 	movk	x0, #0xd7b6, lsl #16
    4c50:	f2a001e4 	movk	x4, #0xf, lsl #16
    4c54:	f2dbd040 	movk	x0, #0xde82, lsl #32
    4c58:	b2407be1 	mov	x1, #0x7fffffff            	// #2147483647
    4c5c:	f2e86360 	movk	x0, #0x431b, lsl #48
    4c60:	9b407c40 	smulh	x0, x2, x0
    4c64:	9352fc00 	asr	x0, x0, #18
    4c68:	cb82fc00 	sub	x0, x0, x2, asr #63
    4c6c:	9b048802 	msub	x2, x0, x4, x2
    4c70:	f100005f 	cmp	x2, #0x0
    4c74:	9a800400 	cinc	x0, x0, ne	// ne = any
    4c78:	eb01001f 	cmp	x0, x1
    4c7c:	5400098c 	b.gt	4dac <fwp_poll_events+0x1dc>
    4c80:	340001a0 	cbz	w0, 4cb4 <fwp_poll_events+0xe4>
    4c84:	5289ba61 	mov	w1, #0x4dd3                	// #19923
    4c88:	52807d05 	mov	w5, #0x3e8                 	// #1000
    4c8c:	72a20c41 	movk	w1, #0x1062, lsl #16
    4c90:	9ba17c01 	umull	x1, w0, w1
    4c94:	d366fc23 	lsr	x3, x1, #38
    4c98:	aa0303e2 	mov	x2, x3
    4c9c:	1b058063 	msub	w3, w3, w5, w0
    4ca0:	9b247c63 	smull	x3, w3, w4
    4ca4:	910023e0 	add	x0, sp, #0x8
    4ca8:	d2800001 	mov	x1, #0x0                   	// #0
    4cac:	a9008fe2 	stp	x2, x3, [sp, #8]
    4cb0:	97fff70c 	bl	28e0 <nanosleep@plt>
    4cb4:	97ffff9f 	bl	4b30 <fwp_now_ns>
    4cb8:	91014268 	add	x8, x19, #0x50
    4cbc:	aa0003e7 	mov	x7, x0
    4cc0:	4f000400 	movi	v0.4s, #0x0
    4cc4:	52800029 	mov	w9, #0x1                   	// #1
    4cc8:	f9409506 	ldr	x6, [x8, #296]
    4ccc:	d503201f 	nop
    4cd0:	b40003e6 	cbz	x6, 4d4c <fwp_poll_events+0x17c>
    4cd4:	f94034c1 	ldr	x1, [x6, #104]
    4cd8:	aa0603e5 	mov	x5, x6
    4cdc:	f94088c6 	ldr	x6, [x6, #272]
    4ce0:	eb07003f 	cmp	x1, x7
    4ce4:	54ffff6c 	b.gt	4cd0 <fwp_poll_events+0x100>
    4ce8:	394154a0 	ldrb	w0, [x5, #85]
    4cec:	36000120 	tbz	w0, #0, 4d10 <fwp_poll_events+0x140>
    4cf0:	f94084a0 	ldr	x0, [x5, #264]
    4cf4:	b4000560 	cbz	x0, 4da0 <fwp_poll_events+0x1d0>
    4cf8:	f9008806 	str	x6, [x0, #272]
    4cfc:	b4000046 	cbz	x6, 4d04 <fwp_poll_events+0x134>
    4d00:	f90084c0 	str	x0, [x6, #264]
    4d04:	910800a0 	add	x0, x5, #0x200
    4d08:	390154bf 	strb	wzr, [x5, #85]
    4d0c:	3c908000 	stur	q0, [x0, #-248]
    4d10:	f94030a0 	ldr	x0, [x5, #96]
    4d14:	390158a9 	strb	w9, [x5, #86]
    4d18:	f100001f 	cmp	x0, #0x0
    4d1c:	fa471000 	ccmp	x0, x7, #0x0, ne	// ne = any
    4d20:	540002cd 	b.le	4d78 <fwp_poll_events+0x1a8>
    4d24:	f94028a0 	ldr	x0, [x5, #80]
    4d28:	f2001c1f 	tst	x0, #0xff000000ff
    4d2c:	54fffd21 	b.ne	4cd0 <fwp_poll_events+0x100>  // b.any
    4d30:	f9406100 	ldr	x0, [x8, #192]
    4d34:	390150a9 	strb	w9, [x5, #84]
    4d38:	f90080bf 	str	xzr, [x5, #256]
    4d3c:	b40002c0 	cbz	x0, 4d94 <fwp_poll_events+0x1c4>
    4d40:	f9006105 	str	x5, [x8, #192]
    4d44:	f9008005 	str	x5, [x0, #256]
    4d48:	b5fffc66 	cbnz	x6, 4cd4 <fwp_poll_events+0x104>
    4d4c:	f00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    4d50:	f947f400 	ldr	x0, [x0, #4072]
    4d54:	f9400fe2 	ldr	x2, [sp, #24]
    4d58:	f9400001 	ldr	x1, [x0]
    4d5c:	eb010042 	subs	x2, x2, x1
    4d60:	d2800001 	mov	x1, #0x0                   	// #0
    4d64:	540002e1 	b.ne	4dc0 <fwp_poll_events+0x1f0>  // b.any
    4d68:	a9427bfd 	ldp	x29, x30, [sp, #32]
    4d6c:	f9401bf3 	ldr	x19, [sp, #48]
    4d70:	910103ff 	add	sp, sp, #0x40
    4d74:	d65f03c0 	ret
    4d78:	394144a0 	ldrb	w0, [x5, #81]
    4d7c:	3707fd40 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d80:	394140a0 	ldrb	w0, [x5, #80]
    4d84:	3707fd00 	tbnz	w0, #0, 4d24 <fwp_poll_events+0x154>
    4d88:	aa0503e0 	mov	x0, x5
    4d8c:	97fffa39 	bl	3670 <fwp_cancel_tree.part.0>
    4d90:	17ffffe5 	b	4d24 <fwp_poll_events+0x154>
    4d94:	f9006105 	str	x5, [x8, #192]
    4d98:	f9006505 	str	x5, [x8, #200]
    4d9c:	17ffffeb 	b	4d48 <fwp_poll_events+0x178>
    4da0:	91014261 	add	x1, x19, #0x50
    4da4:	f9009426 	str	x6, [x1, #296]
    4da8:	17ffffd5 	b	4cfc <fwp_poll_events+0x12c>
    4dac:	d28df803 	mov	x3, #0x6fc0                	// #28608
    4db0:	d2989362 	mov	x2, #0xc49b                	// #50331
    4db4:	f2a4d203 	movk	x3, #0x2690, lsl #16
    4db8:	f2a00402 	movk	x2, #0x20, lsl #16
    4dbc:	17ffffba 	b	4ca4 <fwp_poll_events+0xd4>
    4dc0:	97fff694 	bl	2810 <__stack_chk_fail@plt>
    4dc4:	97fff88c 	bl	2ff4 <fwp_flush>
    4dc8:	f00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    4dcc:	f947e863 	ldr	x3, [x3, #4048]
    4dd0:	d2800562 	mov	x2, #0x2b                  	// #43
    4dd4:	d2800021 	mov	x1, #0x1                   	// #1
    4dd8:	f0000020 	adrp	x0, b000 <__modti3+0x2a0>
    4ddc:	9116c000 	add	x0, x0, #0x5b0
    4de0:	f9400063 	ldr	x3, [x3]
    4de4:	97fff6cb 	bl	2910 <fwrite@plt>
    4de8:	52800ca0 	mov	w0, #0x65                  	// #101
    4dec:	97fff635 	bl	26c0 <exit@plt>

0000000000004df0 <fwp_heap_alloc_big>:
    4df0:	a9ba7bfd 	stp	x29, x30, [sp, #-96]!
    4df4:	910003fd 	mov	x29, sp
    4df8:	a90153f3 	stp	x19, x20, [sp, #16]
    4dfc:	a9025bf5 	stp	x21, x22, [sp, #32]
    4e00:	a90363f7 	stp	x23, x24, [sp, #48]
    4e04:	aa0003f7 	mov	x23, x0
    4e08:	d2e80000 	mov	x0, #0x4000000000000000    	// #4611686018427387904
    4e0c:	a9046bf9 	stp	x25, x26, [sp, #64]
    4e10:	eb0002ff 	cmp	x23, x0
    4e14:	540008a8 	b.hi	4f28 <fwp_heap_alloc_big+0x138>  // b.pmore
    4e18:	d29fffe0 	mov	x0, #0xffff                	// #65535
    4e1c:	8b0002f4 	add	x20, x23, x0
    4e20:	b00003ba 	adrp	x26, 79000 <fwp_root_context+0xbb0>
    4e24:	9118c359 	add	x25, x26, #0x630
    4e28:	d350fe94 	lsr	x20, x20, #16
    4e2c:	2a0103f5 	mov	w21, w1
    4e30:	aa1403e0 	mov	x0, x20
    4e34:	97fff8bf 	bl	3130 <fwp_heap_chunks>
    4e38:	f949ff22 	ldr	x2, [x25, #5112]
    4e3c:	8b000813 	add	x19, x0, x0, lsl #2
    4e40:	aa0003f8 	mov	x24, x0
    4e44:	52800043 	mov	w3, #0x2                   	// #2
    4e48:	d37df273 	lsl	x19, x19, #3
    4e4c:	d2800021 	mov	x1, #0x1                   	// #1
    4e50:	8b130040 	add	x0, x2, x19
    4e54:	38336843 	strb	w3, [x2, x19]
    4e58:	39000415 	strb	w21, [x0, #1]
    4e5c:	b9000c14 	str	w20, [x0, #12]
    4e60:	f9000817 	str	x23, [x0, #16]
    4e64:	97fffd57 	bl	43c0 <fwp_rc_prepare_chunk>
    4e68:	f100069f 	cmp	x20, #0x1
    4e6c:	54000289 	b.ls	4ebc <fwp_heap_alloc_big+0xcc>  // b.plast
    4e70:	8b180294 	add	x20, x20, x24
    4e74:	9100a273 	add	x19, x19, #0x28
    4e78:	a90573fb 	stp	x27, x28, [sp, #80]
    4e7c:	5280007b 	mov	w27, #0x3                   	// #3
    4e80:	8b140a94 	add	x20, x20, x20, lsl #2
    4e84:	2a1803fc 	mov	w28, w24
    4e88:	9adb2296 	lsl	x22, x20, x27
    4e8c:	d503201f 	nop
    4e90:	f949ff35 	ldr	x21, [x25, #5112]
    4e94:	d2800001 	mov	x1, #0x0                   	// #0
    4e98:	8b1302b4 	add	x20, x21, x19
    4e9c:	aa1403e0 	mov	x0, x20
    4ea0:	97fffd48 	bl	43c0 <fwp_rc_prepare_chunk>
    4ea4:	38336abb 	strb	w27, [x21, x19]
    4ea8:	9100a273 	add	x19, x19, #0x28
    4eac:	b9000e9c 	str	w28, [x20, #12]
    4eb0:	eb1302df 	cmp	x22, x19
    4eb4:	54fffee1 	b.ne	4e90 <fwp_heap_alloc_big+0xa0>  // b.any
    4eb8:	a94573fb 	ldp	x27, x28, [sp, #80]
    4ebc:	9118c353 	add	x19, x26, #0x630
    4ec0:	aa1703e2 	mov	x2, x23
    4ec4:	52800001 	mov	w1, #0x0                   	// #0
    4ec8:	f949da60 	ldr	x0, [x19, #5040]
    4ecc:	8b184018 	add	x24, x0, x24, lsl #16
    4ed0:	aa1803e0 	mov	x0, x24
    4ed4:	97fff643 	bl	27e0 <memset@plt>
    4ed8:	f94a1260 	ldr	x0, [x19, #5152]
    4edc:	ab170000 	adds	x0, x0, x23
    4ee0:	54000242 	b.cs	4f28 <fwp_heap_alloc_big+0x138>  // b.hs, b.nlast
    4ee4:	f94a1661 	ldr	x1, [x19, #5160]
    4ee8:	f90a1260 	str	x0, [x19, #5152]
    4eec:	eb01001f 	cmp	x0, x1
    4ef0:	54000049 	b.ls	4ef8 <fwp_heap_alloc_big+0x108>  // b.plast
    4ef4:	f90a1660 	str	x0, [x19, #5160]
    4ef8:	9118c35a 	add	x26, x26, #0x630
    4efc:	9e6202e0 	scvtf	d0, x23
    4f00:	a94153f3 	ldp	x19, x20, [sp, #16]
    4f04:	aa1803e0 	mov	x0, x24
    4f08:	fd4a1f41 	ldr	d1, [x26, #5176]
    4f0c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4f10:	1e602820 	fadd	d0, d1, d0
    4f14:	a94363f7 	ldp	x23, x24, [sp, #48]
    4f18:	fd0a1f40 	str	d0, [x26, #5176]
    4f1c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    4f20:	a8c67bfd 	ldp	x29, x30, [sp], #96
    4f24:	d65f03c0 	ret
    4f28:	a90573fb 	stp	x27, x28, [sp, #80]
    4f2c:	97fff871 	bl	30f0 <fwp_heap_oom>

0000000000004f30 <fwp_heap_alloc_slow>:
    4f30:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    4f34:	910003fd 	mov	x29, sp
    4f38:	a90153f3 	stp	x19, x20, [sp, #16]
    4f3c:	b00003b3 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    4f40:	9118c262 	add	x2, x19, #0x630
    4f44:	a9025bf5 	stp	x21, x22, [sp, #32]
    4f48:	aa0003f5 	mov	x21, x0
    4f4c:	2a0103f4 	mov	w20, w1
    4f50:	b953a440 	ldr	w0, [x2, #5028]
    4f54:	34000600 	cbz	w0, 5014 <fwp_heap_alloc_slow+0xe4>
    4f58:	f14012bf 	cmp	x21, #0x4, lsl #12
    4f5c:	54000628 	b.hi	5020 <fwp_heap_alloc_slow+0xf0>  // b.pmore
    4f60:	91003ea0 	add	x0, x21, #0xf
    4f64:	9118c262 	add	x2, x19, #0x630
    4f68:	f9001bf7 	str	x23, [sp, #48]
    4f6c:	937c7e84 	sbfiz	x4, x20, #4, #32
    4f70:	8b401040 	add	x0, x2, x0, lsr #4
    4f74:	cb34c084 	sub	x4, x4, w20, sxtw
    4f78:	d37ae484 	lsl	x4, x4, #6
    4f7c:	397e8003 	ldrb	w3, [x0, #4000]
    4f80:	910f0060 	add	x0, x3, #0x3c0
    4f84:	aa0303e1 	mov	x1, x3
    4f88:	8b030463 	add	x3, x3, x3, lsl #1
    4f8c:	8b030c83 	add	x3, x4, x3, lsl #3
    4f90:	b8607857 	ldr	w23, [x2, x0, lsl #2]
    4f94:	2a1703f6 	mov	w22, w23
    4f98:	f8636844 	ldr	x4, [x2, x3]
    4f9c:	b40004e4 	cbz	x4, 5038 <fwp_heap_alloc_slow+0x108>
    4fa0:	f9400080 	ldr	x0, [x4]
    4fa4:	aa2003e0 	mvn	x0, x0
    4fa8:	f8236840 	str	x0, [x2, x3]
    4fac:	7100069f 	cmp	w20, #0x1
    4fb0:	aa0403e0 	mov	x0, x4
    4fb4:	9a9602a2 	csel	x2, x21, x22, eq	// eq = none
    4fb8:	52800001 	mov	w1, #0x0                   	// #0
    4fbc:	97fff609 	bl	27e0 <memset@plt>
    4fc0:	aa0003e4 	mov	x4, x0
    4fc4:	9118c260 	add	x0, x19, #0x630
    4fc8:	f94a1001 	ldr	x1, [x0, #5152]
    4fcc:	ab160021 	adds	x1, x1, x22
    4fd0:	540005c2 	b.cs	5088 <fwp_heap_alloc_slow+0x158>  // b.hs, b.nlast
    4fd4:	f94a1402 	ldr	x2, [x0, #5160]
    4fd8:	f90a1001 	str	x1, [x0, #5152]
    4fdc:	eb02003f 	cmp	x1, x2
    4fe0:	54000049 	b.ls	4fe8 <fwp_heap_alloc_slow+0xb8>  // b.plast
    4fe4:	f90a1401 	str	x1, [x0, #5160]
    4fe8:	9118c273 	add	x19, x19, #0x630
    4fec:	1e6302e1 	ucvtf	d1, w23
    4ff0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    4ff4:	aa0403e0 	mov	x0, x4
    4ff8:	fd4a1e60 	ldr	d0, [x19, #5176]
    4ffc:	f9401bf7 	ldr	x23, [sp, #48]
    5000:	1e612800 	fadd	d0, d0, d1
    5004:	fd0a1e60 	str	d0, [x19, #5176]
    5008:	a94153f3 	ldp	x19, x20, [sp, #16]
    500c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5010:	d65f03c0 	ret
    5014:	97fffb37 	bl	3cf0 <fwp_heap_init>
    5018:	f14012bf 	cmp	x21, #0x4, lsl #12
    501c:	54fffa29 	b.ls	4f60 <fwp_heap_alloc_slow+0x30>  // b.plast
    5020:	2a1403e1 	mov	w1, w20
    5024:	aa1503e0 	mov	x0, x21
    5028:	a94153f3 	ldp	x19, x20, [sp, #16]
    502c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5030:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5034:	17ffff6f 	b	4df0 <fwp_heap_alloc_big>
    5038:	8b030042 	add	x2, x2, x3
    503c:	f9400444 	ldr	x4, [x2, #8]
    5040:	b4000104 	cbz	x4, 5060 <fwp_heap_alloc_slow+0x130>
    5044:	f9400840 	ldr	x0, [x2, #16]
    5048:	cb040000 	sub	x0, x0, x4
    504c:	eb16001f 	cmp	x0, x22
    5050:	54000083 	b.cc	5060 <fwp_heap_alloc_slow+0x130>  // b.lo, b.ul, b.last
    5054:	8b160080 	add	x0, x4, x22
    5058:	f9000440 	str	x0, [x2, #8]
    505c:	17ffffd4 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5060:	52800302 	mov	w2, #0x18                  	// #24
    5064:	52807804 	mov	w4, #0x3c0                 	// #960
    5068:	9118c260 	add	x0, x19, #0x630
    506c:	9ba27c23 	umull	x3, w1, w2
    5070:	2a1403e2 	mov	w2, w20
    5074:	9b240e84 	smaddl	x4, w20, w4, x3
    5078:	8b040000 	add	x0, x0, x4
    507c:	97fffd19 	bl	44e0 <fwp_heap_refill>
    5080:	aa0003e4 	mov	x4, x0
    5084:	17ffffca 	b	4fac <fwp_heap_alloc_slow+0x7c>
    5088:	97fff81a 	bl	30f0 <fwp_heap_oom>
    508c:	d503201f 	nop

0000000000005090 <fwp_heap_alloc>:
    5090:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5094:	910003fd 	mov	x29, sp
    5098:	a9025bf5 	stp	x21, x22, [sp, #32]
    509c:	f00000d6 	adrp	x22, 20000 <__data_start>
    50a0:	910142c2 	add	x2, x22, #0x50
    50a4:	a90363f7 	stp	x23, x24, [sp, #48]
    50a8:	b9413058 	ldr	w24, [x2, #304]
    50ac:	a90153f3 	stp	x19, x20, [sp, #16]
    50b0:	7100031f 	cmp	w24, #0x0
    50b4:	7a401824 	ccmp	w1, #0x0, #0x4, ne	// ne = any
    50b8:	540008a1 	b.ne	51cc <fwp_heap_alloc+0x13c>  // b.any
    50bc:	900003b7 	adrp	x23, 79000 <fwp_root_context+0xbb0>
    50c0:	9118c2f3 	add	x19, x23, #0x630
    50c4:	f140101f 	cmp	x0, #0x4, lsl #12
    50c8:	b953a662 	ldr	w2, [x19, #5028]
    50cc:	7a409844 	ccmp	w2, #0x0, #0x4, ls	// ls = plast
    50d0:	54000740 	b.eq	51b8 <fwp_heap_alloc+0x128>  // b.none
    50d4:	91003c03 	add	x3, x0, #0xf
    50d8:	937c7c22 	sbfiz	x2, x1, #4, #32
    50dc:	cb21c042 	sub	x2, x2, w1, sxtw
    50e0:	8b431263 	add	x3, x19, x3, lsr #4
    50e4:	d37ae442 	lsl	x2, x2, #6
    50e8:	397e8063 	ldrb	w3, [x3, #4000]
    50ec:	910f0064 	add	x4, x3, #0x3c0
    50f0:	8b030463 	add	x3, x3, x3, lsl #1
    50f4:	8b030c43 	add	x3, x2, x3, lsl #3
    50f8:	b8647a75 	ldr	w21, [x19, x4, lsl #2]
    50fc:	2a1503f4 	mov	w20, w21
    5100:	f8636a64 	ldr	x4, [x19, x3]
    5104:	b40004c4 	cbz	x4, 519c <fwp_heap_alloc+0x10c>
    5108:	f9400085 	ldr	x5, [x4]
    510c:	7100043f 	cmp	w1, #0x1
    5110:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5114:	aa0403e0 	mov	x0, x4
    5118:	aa2503e5 	mvn	x5, x5
    511c:	52800001 	mov	w1, #0x0                   	// #0
    5120:	f8236a65 	str	x5, [x19, x3]
    5124:	97fff5af 	bl	27e0 <memset@plt>
    5128:	aa0003e4 	mov	x4, x0
    512c:	f94a1260 	ldr	x0, [x19, #5152]
    5130:	ab140000 	adds	x0, x0, x20
    5134:	54000722 	b.cs	5218 <fwp_heap_alloc+0x188>  // b.hs, b.nlast
    5138:	f94a1661 	ldr	x1, [x19, #5160]
    513c:	f90a1260 	str	x0, [x19, #5152]
    5140:	eb01001f 	cmp	x0, x1
    5144:	54000049 	b.ls	514c <fwp_heap_alloc+0xbc>  // b.plast
    5148:	f90a1660 	str	x0, [x19, #5160]
    514c:	9118c2e0 	add	x0, x23, #0x630
    5150:	1e6302a1 	ucvtf	d1, w21
    5154:	fd4a1c00 	ldr	d0, [x0, #5176]
    5158:	1e612800 	fadd	d0, d0, d1
    515c:	fd0a1c00 	str	d0, [x0, #5176]
    5160:	34000138 	cbz	w24, 5184 <fwp_heap_alloc+0xf4>
    5164:	9118c2e1 	add	x1, x23, #0x630
    5168:	910142c0 	add	x0, x22, #0x50
    516c:	fd4a1020 	ldr	d0, [x1, #5152]
    5170:	6d548402 	ldp	d2, d1, [x0, #328]
    5174:	7e61d800 	ucvtf	d0, d0
    5178:	1e623800 	fsub	d0, d0, d2
    517c:	1e612010 	fcmpe	d0, d1
    5180:	5400030c 	b.gt	51e0 <fwp_heap_alloc+0x150>
    5184:	a94153f3 	ldp	x19, x20, [sp, #16]
    5188:	aa0403e0 	mov	x0, x4
    518c:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5190:	a94363f7 	ldp	x23, x24, [sp, #48]
    5194:	a8c47bfd 	ldp	x29, x30, [sp], #64
    5198:	d65f03c0 	ret
    519c:	8b030263 	add	x3, x19, x3
    51a0:	f9400464 	ldr	x4, [x3, #8]
    51a4:	b40000a4 	cbz	x4, 51b8 <fwp_heap_alloc+0x128>
    51a8:	f9400862 	ldr	x2, [x3, #16]
    51ac:	cb040042 	sub	x2, x2, x4
    51b0:	eb02029f 	cmp	x20, x2
    51b4:	54000249 	b.ls	51fc <fwp_heap_alloc+0x16c>  // b.plast
    51b8:	97ffff5e 	bl	4f30 <fwp_heap_alloc_slow>
    51bc:	aa0003e4 	mov	x4, x0
    51c0:	910142c1 	add	x1, x22, #0x50
    51c4:	b9413038 	ldr	w24, [x1, #304]
    51c8:	17ffffe6 	b	5160 <fwp_heap_alloc+0xd0>
    51cc:	a9538c44 	ldp	x4, x3, [x2, #312]
    51d0:	91000484 	add	x4, x4, #0x1
    51d4:	8b000063 	add	x3, x3, x0
    51d8:	a9138c44 	stp	x4, x3, [x2, #312]
    51dc:	17ffffb8 	b	50bc <fwp_heap_alloc+0x2c>
    51e0:	a94153f3 	ldp	x19, x20, [sp, #16]
    51e4:	fd00a800 	str	d0, [x0, #336]
    51e8:	a9425bf5 	ldp	x21, x22, [sp, #32]
    51ec:	aa0403e0 	mov	x0, x4
    51f0:	a94363f7 	ldp	x23, x24, [sp, #48]
    51f4:	a8c47bfd 	ldp	x29, x30, [sp], #64
    51f8:	d65f03c0 	ret
    51fc:	7100043f 	cmp	w1, #0x1
    5200:	8b140085 	add	x5, x4, x20
    5204:	9a940002 	csel	x2, x0, x20, eq	// eq = none
    5208:	52800001 	mov	w1, #0x0                   	// #0
    520c:	aa0403e0 	mov	x0, x4
    5210:	f9000465 	str	x5, [x3, #8]
    5214:	17ffffc4 	b	5124 <fwp_heap_alloc+0x94>
    5218:	97fff7b6 	bl	30f0 <fwp_heap_oom>
    521c:	d503201f 	nop

0000000000005220 <fwp_apply>:
    5220:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5224:	aa0003e6 	mov	x6, x0
    5228:	910003fd 	mov	x29, sp
    522c:	d00000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    5230:	f947f463 	ldr	x3, [x3, #4072]
    5234:	a90153f3 	stp	x19, x20, [sp, #16]
    5238:	aa0203f4 	mov	x20, x2
    523c:	a9025bf5 	stp	x21, x22, [sp, #32]
    5240:	2a0103f5 	mov	w21, w1
    5244:	52800033 	mov	w19, #0x1                   	// #1
    5248:	a90363f7 	stp	x23, x24, [sp, #48]
    524c:	f00000d7 	adrp	x23, 20000 <__data_start>
    5250:	910142f7 	add	x23, x23, #0x50
    5254:	a9046bf9 	stp	x25, x26, [sp, #64]
    5258:	d100c3ff 	sub	sp, sp, #0x30
    525c:	f9400060 	ldr	x0, [x3]
    5260:	f81f83a0 	stur	x0, [x29, #-8]
    5264:	d2800000 	mov	x0, #0x0                   	// #0
    5268:	294058c3 	ldp	w3, w22, [x6]
    526c:	910003f8 	mov	x24, sp
    5270:	f9408ee0 	ldr	x0, [x23, #280]
    5274:	710002df 	cmp	w22, #0x0
    5278:	d37be863 	lsl	x3, x3, #5
    527c:	8b030007 	add	x7, x0, x3
    5280:	b8636819 	ldr	w25, [x0, x3]
    5284:	7a5902a0 	ccmp	w21, w25, #0x0, eq	// eq = none
    5288:	54000163 	b.cc	52b4 <fwp_apply+0x94>  // b.lo, b.ul, b.last
    528c:	f94004e3 	ldr	x3, [x7, #8]
    5290:	34000bb9 	cbz	w25, 5404 <fwp_apply+0x1e4>
    5294:	aa1403e0 	mov	x0, x20
    5298:	d63f0060 	blr	x3
    529c:	aa0003e6 	mov	x6, x0
    52a0:	6b1902bf 	cmp	w21, w25
    52a4:	54000920 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    52a8:	8b394e94 	add	x20, x20, w25, uxtw #3
    52ac:	4b1902b5 	sub	w21, w21, w25
    52b0:	17ffffee 	b	5268 <fwp_apply+0x48>
    52b4:	0b1602ba 	add	w26, w21, w22
    52b8:	6b19035f 	cmp	w26, w25
    52bc:	54000523 	b.cc	5360 <fwp_apply+0x140>  // b.lo, b.ul, b.last
    52c0:	7100033f 	cmp	w25, #0x0
    52c4:	4b16033a 	sub	w26, w25, w22
    52c8:	1a931320 	csel	w0, w25, w19, ne	// ne = any
    52cc:	d37df000 	lsl	x0, x0, #3
    52d0:	91003c00 	add	x0, x0, #0xf
    52d4:	92704c01 	and	x1, x0, #0xfffff0000
    52d8:	927c7c00 	and	x0, x0, #0xffffffff0
    52dc:	cb2163e1 	sub	x1, sp, x1
    52e0:	eb2163ff 	cmp	sp, x1
    52e4:	540000a0 	b.eq	52f8 <fwp_apply+0xd8>  // b.none
    52e8:	d14043ff 	sub	sp, sp, #0x10, lsl #12
    52ec:	f90203ff 	str	xzr, [sp, #1024]
    52f0:	eb2163ff 	cmp	sp, x1
    52f4:	54ffffa1 	b.ne	52e8 <fwp_apply+0xc8>  // b.any
    52f8:	92403c00 	and	x0, x0, #0xffff
    52fc:	cb2063ff 	sub	sp, sp, x0
    5300:	f90003ff 	str	xzr, [sp]
    5304:	f110001f 	cmp	x0, #0x400
    5308:	54000942 	b.cs	5430 <fwp_apply+0x210>  // b.hs, b.nlast
    530c:	910020c6 	add	x6, x6, #0x8
    5310:	910043e0 	add	x0, sp, #0x10
    5314:	d37d7ec5 	ubfiz	x5, x22, #3, #32
    5318:	d2800003 	mov	x3, #0x0                   	// #0
    531c:	340000d6 	cbz	w22, 5334 <fwp_apply+0x114>
    5320:	f86368c4 	ldr	x4, [x6, x3]
    5324:	f8236804 	str	x4, [x0, x3]
    5328:	91002063 	add	x3, x3, #0x8
    532c:	eb0300bf 	cmp	x5, x3
    5330:	54ffff81 	b.ne	5320 <fwp_apply+0x100>  // b.any
    5334:	3400013a 	cbz	w26, 5358 <fwp_apply+0x138>
    5338:	2a1a03e6 	mov	w6, w26
    533c:	d2800003 	mov	x3, #0x0                   	// #0
    5340:	0b0302c4 	add	w4, w22, w3
    5344:	f8637a85 	ldr	x5, [x20, x3, lsl #3]
    5348:	91000463 	add	x3, x3, #0x1
    534c:	f8247805 	str	x5, [x0, x4, lsl #3]
    5350:	eb0300df 	cmp	x6, x3
    5354:	54ffff61 	b.ne	5340 <fwp_apply+0x120>  // b.any
    5358:	f94004e3 	ldr	x3, [x7, #8]
    535c:	1400002c 	b	540c <fwp_apply+0x1ec>
    5360:	11000740 	add	w0, w26, #0x1
    5364:	52800041 	mov	w1, #0x2                   	// #2
    5368:	f81e83a6 	stur	x6, [x29, #-24]
    536c:	d37df000 	lsl	x0, x0, #3
    5370:	97ffff48 	bl	5090 <fwp_heap_alloc>
    5374:	f85e83a6 	ldur	x6, [x29, #-24]
    5378:	aa0003f3 	mov	x19, x0
    537c:	b94000c1 	ldr	w1, [x6]
    5380:	29006801 	stp	w1, w26, [x0]
    5384:	340000b6 	cbz	w22, 5398 <fwp_apply+0x178>
    5388:	910020c1 	add	x1, x6, #0x8
    538c:	d37d7ec2 	ubfiz	x2, x22, #3, #32
    5390:	91002000 	add	x0, x0, #0x8
    5394:	97fff4bb 	bl	2680 <memmove@plt>
    5398:	2a1503e3 	mov	w3, w21
    539c:	d2800000 	mov	x0, #0x0                   	// #0
    53a0:	34000135 	cbz	w21, 53c4 <fwp_apply+0x1a4>
    53a4:	d503201f 	nop
    53a8:	0b0002c1 	add	w1, w22, w0
    53ac:	f8607a82 	ldr	x2, [x20, x0, lsl #3]
    53b0:	8b010e61 	add	x1, x19, x1, lsl #3
    53b4:	91000400 	add	x0, x0, #0x1
    53b8:	f9000422 	str	x2, [x1, #8]
    53bc:	eb00007f 	cmp	x3, x0
    53c0:	54ffff41 	b.ne	53a8 <fwp_apply+0x188>  // b.any
    53c4:	aa1303e6 	mov	x6, x19
    53c8:	d00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    53cc:	f947f400 	ldr	x0, [x0, #4072]
    53d0:	f85f83a2 	ldur	x2, [x29, #-8]
    53d4:	f9400001 	ldr	x1, [x0]
    53d8:	eb010042 	subs	x2, x2, x1
    53dc:	d2800001 	mov	x1, #0x0                   	// #0
    53e0:	540002c1 	b.ne	5438 <fwp_apply+0x218>  // b.any
    53e4:	910003bf 	mov	sp, x29
    53e8:	aa0603e0 	mov	x0, x6
    53ec:	a94153f3 	ldp	x19, x20, [sp, #16]
    53f0:	a9425bf5 	ldp	x21, x22, [sp, #32]
    53f4:	a94363f7 	ldp	x23, x24, [sp, #48]
    53f8:	a9446bf9 	ldp	x25, x26, [sp, #64]
    53fc:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5400:	d65f03c0 	ret
    5404:	d10043a0 	sub	x0, x29, #0x10
    5408:	5280001a 	mov	w26, #0x0                   	// #0
    540c:	d63f0060 	blr	x3
    5410:	aa0003e6 	mov	x6, x0
    5414:	6b1a02bf 	cmp	w21, w26
    5418:	54fffd80 	b.eq	53c8 <fwp_apply+0x1a8>  // b.none
    541c:	0b1602b6 	add	w22, w21, w22
    5420:	8b3a4e94 	add	x20, x20, w26, uxtw #3
    5424:	4b1902d5 	sub	w21, w22, w25
    5428:	9100031f 	mov	sp, x24
    542c:	17ffff8f 	b	5268 <fwp_apply+0x48>
    5430:	f90203ff 	str	xzr, [sp, #1024]
    5434:	17ffffb6 	b	530c <fwp_apply+0xec>
    5438:	97fff4f6 	bl	2810 <__stack_chk_fail@plt>
    543c:	d503201f 	nop

0000000000005440 <fwp_tape_reserve>:
    5440:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5444:	910003fd 	mov	x29, sp
    5448:	a90153f3 	stp	x19, x20, [sp, #16]
    544c:	aa0003f3 	mov	x19, x0
    5450:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    5454:	eb00003f 	cmp	x1, x0
    5458:	54000888 	b.hi	5568 <fwp_tape_reserve+0x128>  // b.pmore
    545c:	f9400e74 	ldr	x20, [x19, #24]
    5460:	eb01029f 	cmp	x20, x1
    5464:	5400078a 	b.ge	5554 <fwp_tape_reserve+0x114>  // b.tcont
    5468:	f100029f 	cmp	x20, #0x0
    546c:	d2800802 	mov	x2, #0x40                  	// #64
    5470:	9a821294 	csel	x20, x20, x2, ne	// ne = any
    5474:	b24077e0 	mov	x0, #0x3fffffff            	// #1073741823
    5478:	a9025bf5 	stp	x21, x22, [sp, #32]
    547c:	a90363f7 	stp	x23, x24, [sp, #48]
    5480:	eb01029f 	cmp	x20, x1
    5484:	5400008a 	b.ge	5494 <fwp_tape_reserve+0x54>  // b.tcont
    5488:	eb00029f 	cmp	x20, x0
    548c:	540006ad 	b.le	5560 <fwp_tape_reserve+0x120>
    5490:	b2407bf4 	mov	x20, #0x7fffffff            	// #2147483647
    5494:	a940d663 	ldp	x3, x21, [x19, #8]
    5498:	d37df297 	lsl	x23, x20, #3
    549c:	f9401260 	ldr	x0, [x19, #32]
    54a0:	aa1703e1 	mov	x1, x23
    54a4:	f9403276 	ldr	x22, [x19, #96]
    54a8:	52800022 	mov	w2, #0x1                   	// #1
    54ac:	cb0302b5 	sub	x21, x21, x3
    54b0:	97fffae5 	bl	4044 <ad_raw_realloc>
    54b4:	b4000aa0 	cbz	x0, 5608 <fwp_tape_reserve+0x1c8>
    54b8:	f9400e61 	ldr	x1, [x19, #24]
    54bc:	8b010801 	add	x1, x0, x1, lsl #2
    54c0:	a9020660 	stp	x0, x1, [x19, #32]
    54c4:	b4000856 	cbz	x22, 55cc <fwp_tape_reserve+0x18c>
    54c8:	f94032d7 	ldr	x23, [x22, #96]
    54cc:	eb17029f 	cmp	x20, x23
    54d0:	5400034d 	b.le	5538 <fwp_tape_reserve+0xf8>
    54d4:	a9046bf9 	stp	x25, x26, [sp, #64]
    54d8:	d37cee9a 	lsl	x26, x20, #4
    54dc:	aa1a03e0 	mov	x0, x26
    54e0:	f94022d9 	ldr	x25, [x22, #64]
    54e4:	52800041 	mov	w1, #0x2                   	// #2
    54e8:	97fffeea 	bl	5090 <fwp_heap_alloc>
    54ec:	aa0003f8 	mov	x24, x0
    54f0:	b4000119 	cbz	x25, 5510 <fwp_tape_reserve+0xd0>
    54f4:	d37ceef7 	lsl	x23, x23, #4
    54f8:	aa1903e1 	mov	x1, x25
    54fc:	eb1a02ff 	cmp	x23, x26
    5500:	9a9a92e2 	csel	x2, x23, x26, ls	// ls = plast
    5504:	97fff457 	bl	2660 <memcpy@plt>
    5508:	aa1903e0 	mov	x0, x25
    550c:	97fffc25 	bl	45a0 <fwp_mem_free>
    5510:	f94032c0 	ldr	x0, [x22, #96]
    5514:	52800001 	mov	w1, #0x0                   	// #0
    5518:	cb000282 	sub	x2, x20, x0
    551c:	8b001300 	add	x0, x24, x0, lsl #4
    5520:	d37cec42 	lsl	x2, x2, #4
    5524:	97fff4af 	bl	27e0 <memset@plt>
    5528:	f9401260 	ldr	x0, [x19, #32]
    552c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5530:	f90022d8 	str	x24, [x22, #64]
    5534:	f90032d4 	str	x20, [x22, #96]
    5538:	d37ef696 	lsl	x22, x20, #2
    553c:	b5000315 	cbnz	x21, 559c <fwp_tape_reserve+0x15c>
    5540:	a94363f7 	ldp	x23, x24, [sp, #48]
    5544:	8b160000 	add	x0, x0, x22
    5548:	a9425bf5 	ldp	x21, x22, [sp, #32]
    554c:	f9000e74 	str	x20, [x19, #24]
    5550:	f9001660 	str	x0, [x19, #40]
    5554:	a94153f3 	ldp	x19, x20, [sp, #16]
    5558:	a8c57bfd 	ldp	x29, x30, [sp], #80
    555c:	d65f03c0 	ret
    5560:	d37ffa94 	lsl	x20, x20, #1
    5564:	17ffffc7 	b	5480 <fwp_tape_reserve+0x40>
    5568:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    556c:	91182000 	add	x0, x0, #0x608
    5570:	a9025bf5 	stp	x21, x22, [sp, #32]
    5574:	a90363f7 	stp	x23, x24, [sp, #48]
    5578:	a9046bf9 	stp	x25, x26, [sp, #64]
    557c:	97fffb4e 	bl	42b4 <fwp_trap>
    5580:	aa0303e0 	mov	x0, x3
    5584:	d37df2a2 	lsl	x2, x21, #3
    5588:	97fff43e 	bl	2680 <memmove@plt>
    558c:	f9401a61 	ldr	x1, [x19, #48]
    5590:	f9401260 	ldr	x0, [x19, #32]
    5594:	8b170021 	add	x1, x1, x23
    5598:	f9001e61 	str	x1, [x19, #56]
    559c:	f9401661 	ldr	x1, [x19, #40]
    55a0:	d37ef696 	lsl	x22, x20, #2
    55a4:	d37ef6a2 	lsl	x2, x21, #2
    55a8:	8b160000 	add	x0, x0, x22
    55ac:	97fff435 	bl	2680 <memmove@plt>
    55b0:	f9401260 	ldr	x0, [x19, #32]
    55b4:	a94363f7 	ldp	x23, x24, [sp, #48]
    55b8:	8b160000 	add	x0, x0, x22
    55bc:	a9425bf5 	ldp	x21, x22, [sp, #32]
    55c0:	f9000e74 	str	x20, [x19, #24]
    55c4:	f9001660 	str	x0, [x19, #40]
    55c8:	17ffffe3 	b	5554 <fwp_tape_reserve+0x114>
    55cc:	f9401a60 	ldr	x0, [x19, #48]
    55d0:	d37cee81 	lsl	x1, x20, #4
    55d4:	52800042 	mov	w2, #0x2                   	// #2
    55d8:	97fffa9b 	bl	4044 <ad_raw_realloc>
    55dc:	b4000160 	cbz	x0, 5608 <fwp_tape_reserve+0x1c8>
    55e0:	f9400e62 	ldr	x2, [x19, #24]
    55e4:	f9001a60 	str	x0, [x19, #48]
    55e8:	8b170003 	add	x3, x0, x23
    55ec:	8b020c01 	add	x1, x0, x2, lsl #3
    55f0:	f9001e61 	str	x1, [x19, #56]
    55f4:	b5fffc75 	cbnz	x21, 5580 <fwp_tape_reserve+0x140>
    55f8:	f9401260 	ldr	x0, [x19, #32]
    55fc:	d37ef696 	lsl	x22, x20, #2
    5600:	f9001e63 	str	x3, [x19, #56]
    5604:	17ffffcf 	b	5540 <fwp_tape_reserve+0x100>
    5608:	aa1303e0 	mov	x0, x19
    560c:	a9046bf9 	stp	x25, x26, [sp, #64]
    5610:	97fff661 	bl	2f94 <fwp_tape_unlink_scope>
    5614:	f9401260 	ldr	x0, [x19, #32]
    5618:	b4000040 	cbz	x0, 5620 <fwp_tape_reserve+0x1e0>
    561c:	97fffa55 	bl	3f70 <ad_raw_free.part.0>
    5620:	f9401a60 	ldr	x0, [x19, #48]
    5624:	b4000040 	cbz	x0, 562c <fwp_tape_reserve+0x1ec>
    5628:	97fffa52 	bl	3f70 <ad_raw_free.part.0>
    562c:	f9402260 	ldr	x0, [x19, #64]
    5630:	b4000040 	cbz	x0, 5638 <fwp_tape_reserve+0x1f8>
    5634:	97fffa4f 	bl	3f70 <ad_raw_free.part.0>
    5638:	d00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    563c:	f947e821 	ldr	x1, [x1, #4048]
    5640:	f9000e7f 	str	xzr, [x19, #24]
    5644:	4f000400 	movi	v0.4s, #0x0
    5648:	a9047e7f 	stp	xzr, xzr, [x19, #64]
    564c:	d2800262 	mov	x2, #0x13                  	// #19
    5650:	f9400023 	ldr	x3, [x1]
    5654:	b900067f 	str	wzr, [x19, #4]
    5658:	d2800021 	mov	x1, #0x1                   	// #1
    565c:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5660:	91042000 	add	x0, x0, #0x108
    5664:	3c808260 	stur	q0, [x19, #8]
    5668:	ad010260 	stp	q0, q0, [x19, #32]
    566c:	97fff4a9 	bl	2910 <fwrite@plt>
    5670:	d2800000 	mov	x0, #0x0                   	// #0
    5674:	97fff4b3 	bl	2940 <fflush@plt>
    5678:	52800cc0 	mov	w0, #0x66                  	// #102
    567c:	97fff4c1 	bl	2980 <_Exit@plt>

0000000000005680 <f128.constprop.0>:
    5680:	f100001f 	cmp	x0, #0x0
    5684:	fa40b820 	ccmp	x1, #0x0, #0x0, lt	// lt = tstop
    5688:	5400094b 	b.lt	57b0 <f128.constprop.0+0x130>  // b.tstop
    568c:	a9bc7bfd 	stp	x29, x30, [sp, #-64]!
    5690:	aa0003e2 	mov	x2, x0
    5694:	910003fd 	mov	x29, sp
    5698:	a90153f3 	stp	x19, x20, [sp, #16]
    569c:	aa0003f4 	mov	x20, x0
    56a0:	aa010000 	orr	x0, x0, x1
    56a4:	a9025bf5 	stp	x21, x22, [sp, #32]
    56a8:	aa0103f6 	mov	x22, x1
    56ac:	f9001bf7 	str	x23, [sp, #48]
    56b0:	fd001fe8 	str	d8, [sp, #56]
    56b4:	b7f80180 	tbnz	x0, #63, 56e4 <f128.constprop.0+0x64>
    56b8:	9360fc20 	asr	x0, x1, #32
    56bc:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56c0:	eb82801f 	cmp	x0, x2, asr #32
    56c4:	540007a1 	b.ne	57b8 <f128.constprop.0+0x138>  // b.any
    56c8:	97fffcfe 	bl	4ac0 <fwp_tape_of>
    56cc:	aa0003f3 	mov	x19, x0
    56d0:	f9403000 	ldr	x0, [x0, #96]
    56d4:	b40001e0 	cbz	x0, 5710 <f128.constprop.0+0x90>
    56d8:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    56dc:	9119c000 	add	x0, x0, #0x670
    56e0:	97fffaf5 	bl	42b4 <fwp_trap>
    56e4:	9360fc40 	asr	x0, x2, #32
    56e8:	1e6e1008 	fmov	d8, #1.000000000000000000e+00
    56ec:	b6fffee2 	tbz	x2, #63, 56c8 <f128.constprop.0+0x48>
    56f0:	2f00e408 	movi	d8, #0x0
    56f4:	9360fc20 	asr	x0, x1, #32
    56f8:	aa0103f4 	mov	x20, x1
    56fc:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5700:	97fffcf0 	bl	4ac0 <fwp_tape_of>
    5704:	aa0003f3 	mov	x19, x0
    5708:	f9403000 	ldr	x0, [x0, #96]
    570c:	b5fffe60 	cbnz	x0, 56d8 <f128.constprop.0+0x58>
    5710:	f9400a77 	ldr	x23, [x19, #16]
    5714:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5718:	eb0002ff 	cmp	x23, x0
    571c:	5400044c 	b.gt	57a4 <f128.constprop.0+0x124>
    5720:	eb3442ff 	cmp	x23, w20, uxtw
    5724:	5400008d 	b.le	5734 <f128.constprop.0+0xb4>
    5728:	b7f800d6 	tbnz	x22, #63, 5740 <f128.constprop.0+0xc0>
    572c:	eb3642ff 	cmp	x23, w22, uxtw
    5730:	5400008c 	b.gt	5740 <f128.constprop.0+0xc0>
    5734:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5738:	911a8000 	add	x0, x0, #0x6a0
    573c:	97fffade 	bl	42b4 <fwp_trap>
    5740:	f9400675 	ldr	x21, [x19, #8]
    5744:	aa1303e0 	mov	x0, x19
    5748:	cb1502f5 	sub	x21, x23, x21
    574c:	910006a1 	add	x1, x21, #0x1
    5750:	97ffff3c 	bl	5440 <fwp_tape_reserve>
    5754:	a9420262 	ldp	x2, x0, [x19, #32]
    5758:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    575c:	f9401a61 	ldr	x1, [x19, #48]
    5760:	b8357854 	str	w20, [x2, x21, lsl #2]
    5764:	f9401e62 	ldr	x2, [x19, #56]
    5768:	f10002df 	cmp	x22, #0x0
    576c:	fc357820 	str	d0, [x1, x21, lsl #3]
    5770:	da9fa2d6 	csinv	x22, x22, xzr, ge	// ge = tcont
    5774:	b8357816 	str	w22, [x0, x21, lsl #2]
    5778:	92607e80 	and	x0, x20, #0xffffffff00000000
    577c:	910006e1 	add	x1, x23, #0x1
    5780:	aa170000 	orr	x0, x0, x23
    5784:	fc357848 	str	d8, [x2, x21, lsl #3]
    5788:	a9425bf5 	ldp	x21, x22, [sp, #32]
    578c:	f9401bf7 	ldr	x23, [sp, #48]
    5790:	fd401fe8 	ldr	d8, [sp, #56]
    5794:	f9000a61 	str	x1, [x19, #16]
    5798:	a94153f3 	ldp	x19, x20, [sp, #16]
    579c:	a8c47bfd 	ldp	x29, x30, [sp], #64
    57a0:	d65f03c0 	ret
    57a4:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    57a8:	91182000 	add	x0, x0, #0x608
    57ac:	97fffac2 	bl	42b4 <fwp_trap>
    57b0:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    57b4:	d65f03c0 	ret
    57b8:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    57bc:	9118a000 	add	x0, x0, #0x628
    57c0:	97fffabd 	bl	42b4 <fwp_trap>

00000000000057c4 <w107>:
    57c4:	a9b87bfd 	stp	x29, x30, [sp, #-128]!
    57c8:	910003fd 	mov	x29, sp
    57cc:	a90153f3 	stp	x19, x20, [sp, #16]
    57d0:	a9025bf5 	stp	x21, x22, [sp, #32]
    57d4:	aa0003f5 	mov	x21, x0
    57d8:	a90363f7 	stp	x23, x24, [sp, #48]
    57dc:	aa0103f7 	mov	x23, x1
    57e0:	a9046bf9 	stp	x25, x26, [sp, #64]
    57e4:	f9002bfb 	str	x27, [sp, #80]
    57e8:	6d0627e8 	stp	d8, d9, [sp, #96]
    57ec:	1e604028 	fmov	d8, d1
    57f0:	1e600809 	fmul	d9, d0, d0
    57f4:	6d072fea 	stp	d10, d11, [sp, #112]
    57f8:	1e60400b 	fmov	d11, d0
    57fc:	b7f81c80 	tbnz	x0, #63, 5b8c <w107+0x3c8>
    5800:	9360fc19 	asr	x25, x0, #32
    5804:	aa1903e0 	mov	x0, x25
    5808:	97fffcae 	bl	4ac0 <fwp_tape_of>
    580c:	f9403001 	ldr	x1, [x0, #96]
    5810:	aa0003f3 	mov	x19, x0
    5814:	b4000081 	cbz	x1, 5824 <w107+0x60>
    5818:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    581c:	9119c000 	add	x0, x0, #0x670
    5820:	97fffaa5 	bl	42b4 <fwp_trap>
    5824:	f9400818 	ldr	x24, [x0, #16]
    5828:	b27f77e1 	mov	x1, #0x7ffffffe            	// #2147483646
    582c:	eb01031f 	cmp	x24, x1
    5830:	54001a8c 	b.gt	5b80 <w107+0x3bc>
    5834:	eb35431f 	cmp	x24, w21, uxtw
    5838:	540019ed 	b.le	5b74 <w107+0x3b0>
    583c:	f9400416 	ldr	x22, [x0, #8]
    5840:	92607eb4 	and	x20, x21, #0xffffffff00000000
    5844:	aa180294 	orr	x20, x20, x24
    5848:	cb160316 	sub	x22, x24, x22
    584c:	910006c1 	add	x1, x22, #0x1
    5850:	97fffefc 	bl	5440 <fwp_tape_reserve>
    5854:	a9420a61 	ldp	x1, x2, [x19, #32]
    5858:	91000700 	add	x0, x24, #0x1
    585c:	f9401a63 	ldr	x3, [x19, #48]
    5860:	b8367835 	str	w21, [x1, x22, lsl #2]
    5864:	f9401e61 	ldr	x1, [x19, #56]
    5868:	1e693908 	fsub	d8, d8, d9
    586c:	fc36786b 	str	d11, [x3, x22, lsl #3]
    5870:	9360fe9a 	asr	x26, x20, #32
    5874:	b8367855 	str	w21, [x2, x22, lsl #2]
    5878:	fc36782b 	str	d11, [x1, x22, lsl #3]
    587c:	f9000a60 	str	x0, [x19, #16]
    5880:	b7f80077 	tbnz	x23, #63, 588c <w107+0xc8>
    5884:	eb97835f 	cmp	x26, x23, asr #32
    5888:	540019a1 	b.ne	5bbc <w107+0x3f8>  // b.any
    588c:	1e6e100a 	fmov	d10, #1.000000000000000000e+00
    5890:	1e7e1009 	fmov	d9, #-1.000000000000000000e+00
    5894:	eb19035f 	cmp	x26, x25
    5898:	540000c0 	b.eq	58b0 <w107+0xec>  // b.none
    589c:	aa1a03e0 	mov	x0, x26
    58a0:	97fffc88 	bl	4ac0 <fwp_tape_of>
    58a4:	aa0003f3 	mov	x19, x0
    58a8:	f9403000 	ldr	x0, [x0, #96]
    58ac:	b5fffb60 	cbnz	x0, 5818 <w107+0x54>
    58b0:	f9400a79 	ldr	x25, [x19, #16]
    58b4:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    58b8:	eb00033f 	cmp	x25, x0
    58bc:	5400162c 	b.gt	5b80 <w107+0x3bc>
    58c0:	eb34433f 	cmp	x25, w20, uxtw
    58c4:	5400158d 	b.le	5b74 <w107+0x3b0>
    58c8:	b7f80077 	tbnz	x23, #63, 58d4 <w107+0x110>
    58cc:	eb37433f 	cmp	x25, w23, uxtw
    58d0:	5400152d 	b.le	5b74 <w107+0x3b0>
    58d4:	f9400676 	ldr	x22, [x19, #8]
    58d8:	aa1303e0 	mov	x0, x19
    58dc:	cb160336 	sub	x22, x25, x22
    58e0:	910006c1 	add	x1, x22, #0x1
    58e4:	97fffed7 	bl	5440 <fwp_tape_reserve>
    58e8:	a9420e62 	ldp	x2, x3, [x19, #32]
    58ec:	f10002ff 	cmp	x23, #0x0
    58f0:	f9401a61 	ldr	x1, [x19, #48]
    58f4:	b8367854 	str	w20, [x2, x22, lsl #2]
    58f8:	f9401e62 	ldr	x2, [x19, #56]
    58fc:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    5900:	fc367829 	str	d9, [x1, x22, lsl #3]
    5904:	9a80a2e1 	csel	x1, x23, x0, ge	// ge = tcont
    5908:	b8367861 	str	w1, [x3, x22, lsl #2]
    590c:	91000737 	add	x23, x25, #0x1
    5910:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5914:	92607e94 	and	x20, x20, #0xffffffff00000000
    5918:	fc36784a 	str	d10, [x2, x22, lsl #3]
    591c:	aa190294 	orr	x20, x20, x25
    5920:	f9000a77 	str	x23, [x19, #16]
    5924:	1e6b3929 	fsub	d9, d9, d11
    5928:	b7f81675 	tbnz	x21, #63, 5bf4 <w107+0x430>
    592c:	9360febb 	asr	x27, x21, #32
    5930:	eb1a037f 	cmp	x27, x26
    5934:	540000e0 	b.eq	5950 <w107+0x18c>  // b.none
    5938:	aa1b03e0 	mov	x0, x27
    593c:	97fffc61 	bl	4ac0 <fwp_tape_of>
    5940:	aa0003f3 	mov	x19, x0
    5944:	f9403000 	ldr	x0, [x0, #96]
    5948:	b5fff680 	cbnz	x0, 5818 <w107+0x54>
    594c:	f9400a77 	ldr	x23, [x19, #16]
    5950:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5954:	eb0002ff 	cmp	x23, x0
    5958:	5400114c 	b.gt	5b80 <w107+0x3bc>
    595c:	eb3542ff 	cmp	x23, w21, uxtw
    5960:	540010ad 	b.le	5b74 <w107+0x3b0>
    5964:	f9400676 	ldr	x22, [x19, #8]
    5968:	aa1303e0 	mov	x0, x19
    596c:	cb1602f6 	sub	x22, x23, x22
    5970:	910006c1 	add	x1, x22, #0x1
    5974:	97fffeb3 	bl	5440 <fwp_tape_reserve>
    5978:	a9420261 	ldp	x1, x0, [x19, #32]
    597c:	1e7e1000 	fmov	d0, #-1.000000000000000000e+00
    5980:	f9401a63 	ldr	x3, [x19, #48]
    5984:	b8367835 	str	w21, [x1, x22, lsl #2]
    5988:	f9401e61 	ldr	x1, [x19, #56]
    598c:	12800002 	mov	w2, #0xffffffff            	// #-1
    5990:	fc367860 	str	d0, [x3, x22, lsl #3]
    5994:	1e6e1000 	fmov	d0, #1.000000000000000000e+00
    5998:	b8367802 	str	w2, [x0, x22, lsl #2]
    599c:	92607eb5 	and	x21, x21, #0xffffffff00000000
    59a0:	910006e0 	add	x0, x23, #0x1
    59a4:	aa1702b7 	orr	x23, x21, x23
    59a8:	fc367820 	str	d0, [x1, x22, lsl #3]
    59ac:	f9000a60 	str	x0, [x19, #16]
    59b0:	9360fe99 	asr	x25, x20, #32
    59b4:	1e68090a 	fmul	d10, d8, d8
    59b8:	eb1b033f 	cmp	x25, x27
    59bc:	540000c0 	b.eq	59d4 <w107+0x210>  // b.none
    59c0:	aa1903e0 	mov	x0, x25
    59c4:	97fffc3f 	bl	4ac0 <fwp_tape_of>
    59c8:	aa0003f3 	mov	x19, x0
    59cc:	f9403000 	ldr	x0, [x0, #96]
    59d0:	b5fff240 	cbnz	x0, 5818 <w107+0x54>
    59d4:	f9400a75 	ldr	x21, [x19, #16]
    59d8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    59dc:	eb0002bf 	cmp	x21, x0
    59e0:	54000d0c 	b.gt	5b80 <w107+0x3bc>
    59e4:	eb3442bf 	cmp	x21, w20, uxtw
    59e8:	54000c6d 	b.le	5b74 <w107+0x3b0>
    59ec:	f9400678 	ldr	x24, [x19, #8]
    59f0:	aa1303e0 	mov	x0, x19
    59f4:	92607e96 	and	x22, x20, #0xffffffff00000000
    59f8:	cb1802b8 	sub	x24, x21, x24
    59fc:	aa1502d6 	orr	x22, x22, x21
    5a00:	91000701 	add	x1, x24, #0x1
    5a04:	97fffe8f 	bl	5440 <fwp_tape_reserve>
    5a08:	a9420261 	ldp	x1, x0, [x19, #32]
    5a0c:	f9401a62 	ldr	x2, [x19, #48]
    5a10:	b8387834 	str	w20, [x1, x24, lsl #2]
    5a14:	f9401e61 	ldr	x1, [x19, #56]
    5a18:	fc387848 	str	d8, [x2, x24, lsl #3]
    5a1c:	b8387814 	str	w20, [x0, x24, lsl #2]
    5a20:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a24:	9e670000 	fmov	d0, x0
    5a28:	910006b4 	add	x20, x21, #0x1
    5a2c:	fc387828 	str	d8, [x1, x24, lsl #3]
    5a30:	9360fed8 	asr	x24, x22, #32
    5a34:	f9000a74 	str	x20, [x19, #16]
    5a38:	1e60094a 	fmul	d10, d10, d0
    5a3c:	eb19031f 	cmp	x24, x25
    5a40:	540000e0 	b.eq	5a5c <w107+0x298>  // b.none
    5a44:	aa1803e0 	mov	x0, x24
    5a48:	97fffc1e 	bl	4ac0 <fwp_tape_of>
    5a4c:	aa0003f3 	mov	x19, x0
    5a50:	f9403000 	ldr	x0, [x0, #96]
    5a54:	b5ffee20 	cbnz	x0, 5818 <w107+0x54>
    5a58:	f9400a74 	ldr	x20, [x19, #16]
    5a5c:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5a60:	eb00029f 	cmp	x20, x0
    5a64:	540008ec 	b.gt	5b80 <w107+0x3bc>
    5a68:	eb36429f 	cmp	x20, w22, uxtw
    5a6c:	5400084d 	b.le	5b74 <w107+0x3b0>
    5a70:	f9400675 	ldr	x21, [x19, #8]
    5a74:	aa1303e0 	mov	x0, x19
    5a78:	cb150295 	sub	x21, x20, x21
    5a7c:	910006a1 	add	x1, x21, #0x1
    5a80:	97fffe70 	bl	5440 <fwp_tape_reserve>
    5a84:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5a88:	9e670000 	fmov	d0, x0
    5a8c:	a9420261 	ldp	x1, x0, [x19, #32]
    5a90:	1e690928 	fmul	d8, d9, d9
    5a94:	f9401a62 	ldr	x2, [x19, #48]
    5a98:	b8357836 	str	w22, [x1, x21, lsl #2]
    5a9c:	f9401e61 	ldr	x1, [x19, #56]
    5aa0:	92607ed6 	and	x22, x22, #0xffffffff00000000
    5aa4:	fc357840 	str	d0, [x2, x21, lsl #3]
    5aa8:	12800002 	mov	w2, #0xffffffff            	// #-1
    5aac:	b8357802 	str	w2, [x0, x21, lsl #2]
    5ab0:	91000680 	add	x0, x20, #0x1
    5ab4:	f835783f 	str	xzr, [x1, x21, lsl #3]
    5ab8:	aa1402d6 	orr	x22, x22, x20
    5abc:	f9000a60 	str	x0, [x19, #16]
    5ac0:	b10006ff 	cmn	x23, #0x1
    5ac4:	540009e0 	b.eq	5c00 <w107+0x43c>  // b.none
    5ac8:	9360fee0 	asr	x0, x23, #32
    5acc:	eb18001f 	cmp	x0, x24
    5ad0:	540000a0 	b.eq	5ae4 <w107+0x320>  // b.none
    5ad4:	97fffbfb 	bl	4ac0 <fwp_tape_of>
    5ad8:	aa0003f3 	mov	x19, x0
    5adc:	f9403000 	ldr	x0, [x0, #96]
    5ae0:	b5ffe9c0 	cbnz	x0, 5818 <w107+0x54>
    5ae4:	f9400a74 	ldr	x20, [x19, #16]
    5ae8:	b27f77e0 	mov	x0, #0x7ffffffe            	// #2147483646
    5aec:	eb00029f 	cmp	x20, x0
    5af0:	5400048c 	b.gt	5b80 <w107+0x3bc>
    5af4:	eb37429f 	cmp	x20, w23, uxtw
    5af8:	540003ed 	b.le	5b74 <w107+0x3b0>
    5afc:	f9400675 	ldr	x21, [x19, #8]
    5b00:	aa1303e0 	mov	x0, x19
    5b04:	cb150295 	sub	x21, x20, x21
    5b08:	910006a1 	add	x1, x21, #0x1
    5b0c:	97fffe4d 	bl	5440 <fwp_tape_reserve>
    5b10:	a9420a61 	ldp	x1, x2, [x19, #32]
    5b14:	92607ee0 	and	x0, x23, #0xffffffff00000000
    5b18:	f9401a63 	ldr	x3, [x19, #48]
    5b1c:	b8357837 	str	w23, [x1, x21, lsl #2]
    5b20:	f9401e61 	ldr	x1, [x19, #56]
    5b24:	aa140000 	orr	x0, x0, x20
    5b28:	fc357869 	str	d9, [x3, x21, lsl #3]
    5b2c:	91000694 	add	x20, x20, #0x1
    5b30:	b8357857 	str	w23, [x2, x21, lsl #2]
    5b34:	fc357829 	str	d9, [x1, x21, lsl #3]
    5b38:	f9000a74 	str	x20, [x19, #16]
    5b3c:	1e6a2908 	fadd	d8, d8, d10
    5b40:	aa1603e1 	mov	x1, x22
    5b44:	97fffecf 	bl	5680 <f128.constprop.0>
    5b48:	aa0003e1 	mov	x1, x0
    5b4c:	a94153f3 	ldp	x19, x20, [sp, #16]
    5b50:	9e660100 	fmov	x0, d8
    5b54:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5b58:	a94363f7 	ldp	x23, x24, [sp, #48]
    5b5c:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5b60:	f9402bfb 	ldr	x27, [sp, #80]
    5b64:	6d4627e8 	ldp	d8, d9, [sp, #96]
    5b68:	6d472fea 	ldp	d10, d11, [sp, #112]
    5b6c:	a8c87bfd 	ldp	x29, x30, [sp], #128
    5b70:	d65f03c0 	ret
    5b74:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5b78:	911a8000 	add	x0, x0, #0x6a0
    5b7c:	97fff9ce 	bl	42b4 <fwp_trap>
    5b80:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5b84:	91182000 	add	x0, x0, #0x608
    5b88:	97fff9cb 	bl	42b4 <fwp_trap>
    5b8c:	1e693828 	fsub	d8, d1, d9
    5b90:	b6f801c1 	tbz	x1, #63, 5bc8 <w107+0x404>
    5b94:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    5b98:	1e68090a 	fmul	d10, d8, d8
    5b9c:	d2e80b20 	mov	x0, #0x4059000000000000    	// #4636737291354636288
    5ba0:	9e670000 	fmov	d0, x0
    5ba4:	1e6b3828 	fsub	d8, d1, d11
    5ba8:	92800016 	mov	x22, #0xffffffffffffffff    	// #-1
    5bac:	aa1603e0 	mov	x0, x22
    5bb0:	1e60094a 	fmul	d10, d10, d0
    5bb4:	1e680908 	fmul	d8, d8, d8
    5bb8:	17ffffe1 	b	5b3c <w107+0x378>
    5bbc:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5bc0:	9118a000 	add	x0, x0, #0x628
    5bc4:	97fff9bc 	bl	42b4 <fwp_trap>
    5bc8:	2f00e40a 	movi	d10, #0x0
    5bcc:	1e6e1009 	fmov	d9, #1.000000000000000000e+00
    5bd0:	9360fc3a 	asr	x26, x1, #32
    5bd4:	aa0103f4 	mov	x20, x1
    5bd8:	aa1a03e0 	mov	x0, x26
    5bdc:	92800017 	mov	x23, #0xffffffffffffffff    	// #-1
    5be0:	97fffbb8 	bl	4ac0 <fwp_tape_of>
    5be4:	aa0003f3 	mov	x19, x0
    5be8:	f9403000 	ldr	x0, [x0, #96]
    5bec:	b5ffe160 	cbnz	x0, 5818 <w107+0x54>
    5bf0:	17ffff30 	b	58b0 <w107+0xec>
    5bf4:	aa1a03fb 	mov	x27, x26
    5bf8:	aa0003f7 	mov	x23, x0
    5bfc:	17ffff6d 	b	59b0 <w107+0x1ec>
    5c00:	aa1703e0 	mov	x0, x23
    5c04:	17ffffce 	b	5b3c <w107+0x378>
    5c08:	d503201f 	nop
    5c0c:	d503201f 	nop

0000000000005c10 <fwp_data.part.0.constprop.0>:
    5c10:	a9bb7bfd 	stp	x29, x30, [sp, #-80]!
    5c14:	910003fd 	mov	x29, sp
    5c18:	a9025bf5 	stp	x21, x22, [sp, #32]
    5c1c:	f00000d6 	adrp	x22, 20000 <__data_start>
    5c20:	910142c2 	add	x2, x22, #0x50
    5c24:	a9046bf9 	stp	x25, x26, [sp, #64]
    5c28:	b9413059 	ldr	w25, [x2, #304]
    5c2c:	a90153f3 	stp	x19, x20, [sp, #16]
    5c30:	aa0103f4 	mov	x20, x1
    5c34:	a90363f7 	stp	x23, x24, [sp, #48]
    5c38:	2a0003f7 	mov	w23, w0
    5c3c:	340000b9 	cbz	w25, 5c50 <fwp_data.part.0.constprop.0+0x40>
    5c40:	a9538041 	ldp	x1, x0, [x2, #312]
    5c44:	91000421 	add	x1, x1, #0x1
    5c48:	91006000 	add	x0, x0, #0x18
    5c4c:	a9138041 	stp	x1, x0, [x2, #312]
    5c50:	900003b5 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    5c54:	9118c2a3 	add	x3, x21, #0x630
    5c58:	b953a460 	ldr	w0, [x3, #5028]
    5c5c:	34000840 	cbz	w0, 5d64 <fwp_data.part.0.constprop.0+0x154>
    5c60:	397e8862 	ldrb	w2, [x3, #4002]
    5c64:	910f0040 	add	x0, x2, #0x3c0
    5c68:	8b020442 	add	x2, x2, x2, lsl #1
    5c6c:	d37df042 	lsl	x2, x2, #3
    5c70:	b860787a 	ldr	w26, [x3, x0, lsl #2]
    5c74:	2a1a03f8 	mov	w24, w26
    5c78:	f8626873 	ldr	x19, [x3, x2]
    5c7c:	b4000613 	cbz	x19, 5d3c <fwp_data.part.0.constprop.0+0x12c>
    5c80:	f9400260 	ldr	x0, [x19]
    5c84:	aa2003e0 	mvn	x0, x0
    5c88:	f8226860 	str	x0, [x3, x2]
    5c8c:	f100631f 	cmp	x24, #0x18
    5c90:	540000e9 	b.ls	5cac <fwp_data.part.0.constprop.0+0x9c>  // b.plast
    5c94:	d1006702 	sub	x2, x24, #0x19
    5c98:	91006260 	add	x0, x19, #0x18
    5c9c:	927df042 	and	x2, x2, #0xfffffffffffffff8
    5ca0:	52800001 	mov	w1, #0x0                   	// #0
    5ca4:	91002042 	add	x2, x2, #0x8
    5ca8:	97fff2ce 	bl	27e0 <memset@plt>
    5cac:	9118c2a0 	add	x0, x21, #0x630
    5cb0:	f94a1001 	ldr	x1, [x0, #5152]
    5cb4:	ab180021 	adds	x1, x1, x24
    5cb8:	54000682 	b.cs	5d88 <fwp_data.part.0.constprop.0+0x178>  // b.hs, b.nlast
    5cbc:	f94a1402 	ldr	x2, [x0, #5160]
    5cc0:	f90a1001 	str	x1, [x0, #5152]
    5cc4:	eb02003f 	cmp	x1, x2
    5cc8:	54000049 	b.ls	5cd0 <fwp_data.part.0.constprop.0+0xc0>  // b.plast
    5ccc:	f90a1401 	str	x1, [x0, #5160]
    5cd0:	9118c2a0 	add	x0, x21, #0x630
    5cd4:	1e630341 	ucvtf	d1, w26
    5cd8:	fd4a1c00 	ldr	d0, [x0, #5176]
    5cdc:	1e612800 	fadd	d0, d0, d1
    5ce0:	fd0a1c00 	str	d0, [x0, #5176]
    5ce4:	34000139 	cbz	w25, 5d08 <fwp_data.part.0.constprop.0+0xf8>
    5ce8:	9118c2b5 	add	x21, x21, #0x630
    5cec:	910142d6 	add	x22, x22, #0x50
    5cf0:	fd4a12a0 	ldr	d0, [x21, #5152]
    5cf4:	6d5486c2 	ldp	d2, d1, [x22, #328]
    5cf8:	7e61d800 	ucvtf	d0, d0
    5cfc:	1e623800 	fsub	d0, d0, d2
    5d00:	1e612010 	fcmpe	d0, d1
    5d04:	540003ec 	b.gt	5d80 <fwp_data.part.0.constprop.0+0x170>
    5d08:	52800040 	mov	w0, #0x2                   	// #2
    5d0c:	29000277 	stp	w23, w0, [x19]
    5d10:	aa1303e0 	mov	x0, x19
    5d14:	f9400281 	ldr	x1, [x20]
    5d18:	f9000661 	str	x1, [x19, #8]
    5d1c:	f9400681 	ldr	x1, [x20, #8]
    5d20:	f9000a61 	str	x1, [x19, #16]
    5d24:	a94153f3 	ldp	x19, x20, [sp, #16]
    5d28:	a9425bf5 	ldp	x21, x22, [sp, #32]
    5d2c:	a94363f7 	ldp	x23, x24, [sp, #48]
    5d30:	a9446bf9 	ldp	x25, x26, [sp, #64]
    5d34:	a8c57bfd 	ldp	x29, x30, [sp], #80
    5d38:	d65f03c0 	ret
    5d3c:	8b020063 	add	x3, x3, x2
    5d40:	f9400473 	ldr	x19, [x3, #8]
    5d44:	b4000113 	cbz	x19, 5d64 <fwp_data.part.0.constprop.0+0x154>
    5d48:	f9400860 	ldr	x0, [x3, #16]
    5d4c:	cb130000 	sub	x0, x0, x19
    5d50:	eb00031f 	cmp	x24, x0
    5d54:	54000088 	b.hi	5d64 <fwp_data.part.0.constprop.0+0x154>  // b.pmore
    5d58:	8b180260 	add	x0, x19, x24
    5d5c:	f9000460 	str	x0, [x3, #8]
    5d60:	17ffffcb 	b	5c8c <fwp_data.part.0.constprop.0+0x7c>
    5d64:	52800001 	mov	w1, #0x0                   	// #0
    5d68:	d2800300 	mov	x0, #0x18                  	// #24
    5d6c:	97fffcc9 	bl	5090 <fwp_heap_alloc>
    5d70:	aa0003f3 	mov	x19, x0
    5d74:	910142c1 	add	x1, x22, #0x50
    5d78:	b9413039 	ldr	w25, [x1, #304]
    5d7c:	17ffffda 	b	5ce4 <fwp_data.part.0.constprop.0+0xd4>
    5d80:	fd00aac0 	str	d0, [x22, #336]
    5d84:	17ffffe1 	b	5d08 <fwp_data.part.0.constprop.0+0xf8>
    5d88:	97fff4da 	bl	30f0 <fwp_heap_oom>
    5d8c:	d503201f 	nop

0000000000005d90 <fwp_rc_share>:
    5d90:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5d94:	9118c042 	add	x2, x2, #0x630
    5d98:	f949d843 	ldr	x3, [x2, #5040]
    5d9c:	f949ec41 	ldr	x1, [x2, #5080]
    5da0:	cb030000 	sub	x0, x0, x3
    5da4:	eb01401f 	cmp	x0, x1, lsl #16
    5da8:	540003a2 	b.cs	5e1c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5dac:	d350fc01 	lsr	x1, x0, #16
    5db0:	f949fc44 	ldr	x4, [x2, #5112]
    5db4:	8b010821 	add	x1, x1, x1, lsl #2
    5db8:	d37df021 	lsl	x1, x1, #3
    5dbc:	8b010083 	add	x3, x4, x1
    5dc0:	f9401062 	ldr	x2, [x3, #32]
    5dc4:	b40002c2 	cbz	x2, 5e1c <fwp_rc_share+0x8c>
    5dc8:	38616881 	ldrb	w1, [x4, x1]
    5dcc:	7100083f 	cmp	w1, #0x2
    5dd0:	54000220 	b.eq	5e14 <fwp_rc_share+0x84>  // b.none
    5dd4:	7100043f 	cmp	w1, #0x1
    5dd8:	54000221 	b.ne	5e1c <fwp_rc_share+0x8c>  // b.any
    5ddc:	29430464 	ldp	w4, w1, [x3, #24]
    5de0:	92403c00 	and	x0, x0, #0xffff
    5de4:	9b047c00 	mul	x0, x0, x4
    5de8:	d360fc00 	lsr	x0, x0, #32
    5dec:	eb01001f 	cmp	x0, x1
    5df0:	54000162 	b.cs	5e1c <fwp_rc_share+0x8c>  // b.hs, b.nlast
    5df4:	8b000042 	add	x2, x2, x0
    5df8:	39400040 	ldrb	w0, [x2]
    5dfc:	34000100 	cbz	w0, 5e1c <fwp_rc_share+0x8c>
    5e00:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    5e04:	d0000020 	adrp	x0, b000 <__modti3+0x2a0>
    5e08:	911b0000 	add	x0, x0, #0x6c0
    5e0c:	910003fd 	mov	x29, sp
    5e10:	97fff929 	bl	42b4 <fwp_trap>
    5e14:	72003c1f 	tst	w0, #0xffff
    5e18:	54ffff00 	b.eq	5df8 <fwp_rc_share+0x68>  // b.none
    5e1c:	d65f03c0 	ret

0000000000005e20 <fwp_rc_free_arr>:
    5e20:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5e24:	9118c063 	add	x3, x3, #0x630
    5e28:	f949d861 	ldr	x1, [x3, #5040]
    5e2c:	f949ec62 	ldr	x2, [x3, #5080]
    5e30:	cb010001 	sub	x1, x0, x1
    5e34:	eb02403f 	cmp	x1, x2, lsl #16
    5e38:	54000342 	b.cs	5ea0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5e3c:	d350fc22 	lsr	x2, x1, #16
    5e40:	f949fc65 	ldr	x5, [x3, #5112]
    5e44:	8b020842 	add	x2, x2, x2, lsl #2
    5e48:	d37df042 	lsl	x2, x2, #3
    5e4c:	8b0200a4 	add	x4, x5, x2
    5e50:	f9401083 	ldr	x3, [x4, #32]
    5e54:	b4000263 	cbz	x3, 5ea0 <fwp_rc_free_arr+0x80>
    5e58:	386268a2 	ldrb	w2, [x5, x2]
    5e5c:	7100085f 	cmp	w2, #0x2
    5e60:	540001c0 	b.eq	5e98 <fwp_rc_free_arr+0x78>  // b.none
    5e64:	7100045f 	cmp	w2, #0x1
    5e68:	540001c1 	b.ne	5ea0 <fwp_rc_free_arr+0x80>  // b.any
    5e6c:	29430885 	ldp	w5, w2, [x4, #24]
    5e70:	92403c21 	and	x1, x1, #0xffff
    5e74:	9b057c21 	mul	x1, x1, x5
    5e78:	d360fc21 	lsr	x1, x1, #32
    5e7c:	eb02003f 	cmp	x1, x2
    5e80:	54000102 	b.cs	5ea0 <fwp_rc_free_arr+0x80>  // b.hs, b.nlast
    5e84:	8b010063 	add	x3, x3, x1
    5e88:	39400061 	ldrb	w1, [x3]
    5e8c:	7100043f 	cmp	w1, #0x1
    5e90:	54000081 	b.ne	5ea0 <fwp_rc_free_arr+0x80>  // b.any
    5e94:	17fff9c3 	b	45a0 <fwp_mem_free>
    5e98:	72003c3f 	tst	w1, #0xffff
    5e9c:	54ffff60 	b.eq	5e88 <fwp_rc_free_arr+0x68>  // b.none
    5ea0:	d65f03c0 	ret

0000000000005ea4 <fwp_rc_dup>:
    5ea4:	900003a2 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    5ea8:	9118c042 	add	x2, x2, #0x630
    5eac:	f949d841 	ldr	x1, [x2, #5040]
    5eb0:	f949ec43 	ldr	x3, [x2, #5080]
    5eb4:	cb010001 	sub	x1, x0, x1
    5eb8:	eb03403f 	cmp	x1, x3, lsl #16
    5ebc:	540003c2 	b.cs	5f34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5ec0:	d350fc20 	lsr	x0, x1, #16
    5ec4:	f949fc44 	ldr	x4, [x2, #5112]
    5ec8:	8b000800 	add	x0, x0, x0, lsl #2
    5ecc:	d37df002 	lsl	x2, x0, #3
    5ed0:	8b020083 	add	x3, x4, x2
    5ed4:	f9401060 	ldr	x0, [x3, #32]
    5ed8:	b40002e0 	cbz	x0, 5f34 <fwp_rc_dup+0x90>
    5edc:	38626882 	ldrb	w2, [x4, x2]
    5ee0:	7100085f 	cmp	w2, #0x2
    5ee4:	540002a0 	b.eq	5f38 <fwp_rc_dup+0x94>  // b.none
    5ee8:	7100045f 	cmp	w2, #0x1
    5eec:	54000241 	b.ne	5f34 <fwp_rc_dup+0x90>  // b.any
    5ef0:	29430864 	ldp	w4, w2, [x3, #24]
    5ef4:	92403c21 	and	x1, x1, #0xffff
    5ef8:	9b047c21 	mul	x1, x1, x4
    5efc:	d360fc21 	lsr	x1, x1, #32
    5f00:	eb02003f 	cmp	x1, x2
    5f04:	54000182 	b.cs	5f34 <fwp_rc_dup+0x90>  // b.hs, b.nlast
    5f08:	8b010000 	add	x0, x0, x1
    5f0c:	39400001 	ldrb	w1, [x0]
    5f10:	34000121 	cbz	w1, 5f34 <fwp_rc_dup+0x90>
    5f14:	f00000c2 	adrp	x2, 20000 <__data_start>
    5f18:	91014042 	add	x2, x2, #0x50
    5f1c:	b9413043 	ldr	w3, [x2, #304]
    5f20:	35000123 	cbnz	w3, 5f44 <fwp_rc_dup+0xa0>
    5f24:	7103f43f 	cmp	w1, #0xfd
    5f28:	54000168 	b.hi	5f54 <fwp_rc_dup+0xb0>  // b.pmore
    5f2c:	11000421 	add	w1, w1, #0x1
    5f30:	39000001 	strb	w1, [x0]
    5f34:	d65f03c0 	ret
    5f38:	72003c3f 	tst	w1, #0xffff
    5f3c:	54fffe80 	b.eq	5f0c <fwp_rc_dup+0x68>  // b.none
    5f40:	d65f03c0 	ret
    5f44:	f940ac43 	ldr	x3, [x2, #344]
    5f48:	91000463 	add	x3, x3, #0x1
    5f4c:	f900ac43 	str	x3, [x2, #344]
    5f50:	17fffff5 	b	5f24 <fwp_rc_dup+0x80>
    5f54:	17fffa0c 	b	4784 <fwp_rc_wide_dup>
    5f58:	d503201f 	nop
    5f5c:	d503201f 	nop

0000000000005f60 <fwp_owned_entry161>:
    5f60:	d10103ff 	sub	sp, sp, #0x40
    5f64:	d00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    5f68:	f947f442 	ldr	x2, [x2, #4072]
    5f6c:	a9027bfd 	stp	x29, x30, [sp, #32]
    5f70:	910083fd 	add	x29, sp, #0x20
    5f74:	a90353f3 	stp	x19, x20, [sp, #48]
    5f78:	f9400043 	ldr	x3, [x2]
    5f7c:	f9000fe3 	str	x3, [sp, #24]
    5f80:	d2800003 	mov	x3, #0x0                   	// #0
    5f84:	a9400c01 	ldp	x1, x3, [x0]
    5f88:	f9400802 	ldr	x2, [x0, #16]
    5f8c:	ab020022 	adds	x2, x1, x2
    5f90:	540006e6 	b.vs	606c <fwp_owned_entry161+0x10c>
    5f94:	910023e1 	add	x1, sp, #0x8
    5f98:	52800000 	mov	w0, #0x0                   	// #0
    5f9c:	a9008be3 	stp	x3, x2, [sp, #8]
    5fa0:	97ffff1c 	bl	5c10 <fwp_data.part.0.constprop.0>
    5fa4:	900003a3 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    5fa8:	9118c063 	add	x3, x3, #0x630
    5fac:	aa0003f3 	mov	x19, x0
    5fb0:	f949d861 	ldr	x1, [x3, #5040]
    5fb4:	f949ec60 	ldr	x0, [x3, #5080]
    5fb8:	cb010261 	sub	x1, x19, x1
    5fbc:	eb00403f 	cmp	x1, x0, lsl #16
    5fc0:	54000322 	b.cs	6024 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    5fc4:	d350fc22 	lsr	x2, x1, #16
    5fc8:	f949fc63 	ldr	x3, [x3, #5112]
    5fcc:	8b020842 	add	x2, x2, x2, lsl #2
    5fd0:	d37df042 	lsl	x2, x2, #3
    5fd4:	8b020060 	add	x0, x3, x2
    5fd8:	f9401014 	ldr	x20, [x0, #32]
    5fdc:	b4000254 	cbz	x20, 6024 <fwp_owned_entry161+0xc4>
    5fe0:	38626862 	ldrb	w2, [x3, x2]
    5fe4:	7100085f 	cmp	w2, #0x2
    5fe8:	54000360 	b.eq	6054 <fwp_owned_entry161+0xf4>  // b.none
    5fec:	7100045f 	cmp	w2, #0x1
    5ff0:	540001a1 	b.ne	6024 <fwp_owned_entry161+0xc4>  // b.any
    5ff4:	29430002 	ldp	w2, w0, [x0, #24]
    5ff8:	92403c21 	and	x1, x1, #0xffff
    5ffc:	9b027c21 	mul	x1, x1, x2
    6000:	d360fc21 	lsr	x1, x1, #32
    6004:	eb00003f 	cmp	x1, x0
    6008:	540000e2 	b.cs	6024 <fwp_owned_entry161+0xc4>  // b.hs, b.nlast
    600c:	8b010294 	add	x20, x20, x1
    6010:	39400280 	ldrb	w0, [x20]
    6014:	7103fc1f 	cmp	w0, #0xff
    6018:	54000240 	b.eq	6060 <fwp_owned_entry161+0x100>  // b.none
    601c:	52800020 	mov	w0, #0x1                   	// #1
    6020:	39000280 	strb	w0, [x20]
    6024:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6028:	f947f400 	ldr	x0, [x0, #4072]
    602c:	f9400fe2 	ldr	x2, [sp, #24]
    6030:	f9400001 	ldr	x1, [x0]
    6034:	eb010042 	subs	x2, x2, x1
    6038:	d2800001 	mov	x1, #0x0                   	// #0
    603c:	540001a1 	b.ne	6070 <fwp_owned_entry161+0x110>  // b.any
    6040:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6044:	aa1303e0 	mov	x0, x19
    6048:	a94353f3 	ldp	x19, x20, [sp, #48]
    604c:	910103ff 	add	sp, sp, #0x40
    6050:	d65f03c0 	ret
    6054:	72003c3f 	tst	w1, #0xffff
    6058:	54fffe61 	b.ne	6024 <fwp_owned_entry161+0xc4>  // b.any
    605c:	17ffffed 	b	6010 <fwp_owned_entry161+0xb0>
    6060:	aa1403e0 	mov	x0, x20
    6064:	97fff8b4 	bl	4334 <fwp_rc_forget_slot.part.0>
    6068:	17ffffed 	b	601c <fwp_owned_entry161+0xbc>
    606c:	97fff265 	bl	2a00 <fwp_trap_overflow.constprop.0>
    6070:	97fff1e8 	bl	2810 <__stack_chk_fail@plt>

0000000000006074 <e161>:
    6074:	d10103ff 	sub	sp, sp, #0x40
    6078:	b00000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    607c:	f947f442 	ldr	x2, [x2, #4072]
    6080:	a9027bfd 	stp	x29, x30, [sp, #32]
    6084:	910083fd 	add	x29, sp, #0x20
    6088:	a90353f3 	stp	x19, x20, [sp, #48]
    608c:	f9400043 	ldr	x3, [x2]
    6090:	f9000fe3 	str	x3, [sp, #24]
    6094:	d2800003 	mov	x3, #0x0                   	// #0
    6098:	a9400c01 	ldp	x1, x3, [x0]
    609c:	f9400802 	ldr	x2, [x0, #16]
    60a0:	ab020022 	adds	x2, x1, x2
    60a4:	54000726 	b.vs	6188 <e161+0x114>
    60a8:	910023e1 	add	x1, sp, #0x8
    60ac:	52800000 	mov	w0, #0x0                   	// #0
    60b0:	a9008be3 	stp	x3, x2, [sp, #8]
    60b4:	97fffed7 	bl	5c10 <fwp_data.part.0.constprop.0>
    60b8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    60bc:	9118c063 	add	x3, x3, #0x630
    60c0:	aa0003f3 	mov	x19, x0
    60c4:	f949d861 	ldr	x1, [x3, #5040]
    60c8:	f949ec60 	ldr	x0, [x3, #5080]
    60cc:	cb010261 	sub	x1, x19, x1
    60d0:	eb00403f 	cmp	x1, x0, lsl #16
    60d4:	54000322 	b.cs	6138 <e161+0xc4>  // b.hs, b.nlast
    60d8:	d350fc22 	lsr	x2, x1, #16
    60dc:	f949fc63 	ldr	x3, [x3, #5112]
    60e0:	8b020842 	add	x2, x2, x2, lsl #2
    60e4:	d37df042 	lsl	x2, x2, #3
    60e8:	8b020060 	add	x0, x3, x2
    60ec:	f9401014 	ldr	x20, [x0, #32]
    60f0:	b4000254 	cbz	x20, 6138 <e161+0xc4>
    60f4:	38626862 	ldrb	w2, [x3, x2]
    60f8:	7100085f 	cmp	w2, #0x2
    60fc:	540003a0 	b.eq	6170 <e161+0xfc>  // b.none
    6100:	7100045f 	cmp	w2, #0x1
    6104:	540001a1 	b.ne	6138 <e161+0xc4>  // b.any
    6108:	29430002 	ldp	w2, w0, [x0, #24]
    610c:	92403c21 	and	x1, x1, #0xffff
    6110:	9b027c21 	mul	x1, x1, x2
    6114:	d360fc21 	lsr	x1, x1, #32
    6118:	eb00003f 	cmp	x1, x0
    611c:	540000e2 	b.cs	6138 <e161+0xc4>  // b.hs, b.nlast
    6120:	8b010294 	add	x20, x20, x1
    6124:	39400280 	ldrb	w0, [x20]
    6128:	7103fc1f 	cmp	w0, #0xff
    612c:	54000280 	b.eq	617c <e161+0x108>  // b.none
    6130:	52800020 	mov	w0, #0x1                   	// #1
    6134:	39000280 	strb	w0, [x20]
    6138:	aa1303e0 	mov	x0, x19
    613c:	97ffff15 	bl	5d90 <fwp_rc_share>
    6140:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6144:	f947f400 	ldr	x0, [x0, #4072]
    6148:	f9400fe2 	ldr	x2, [sp, #24]
    614c:	f9400001 	ldr	x1, [x0]
    6150:	eb010042 	subs	x2, x2, x1
    6154:	d2800001 	mov	x1, #0x0                   	// #0
    6158:	540001a1 	b.ne	618c <e161+0x118>  // b.any
    615c:	a9427bfd 	ldp	x29, x30, [sp, #32]
    6160:	aa1303e0 	mov	x0, x19
    6164:	a94353f3 	ldp	x19, x20, [sp, #48]
    6168:	910103ff 	add	sp, sp, #0x40
    616c:	d65f03c0 	ret
    6170:	72003c3f 	tst	w1, #0xffff
    6174:	54fffe21 	b.ne	6138 <e161+0xc4>  // b.any
    6178:	17ffffeb 	b	6124 <e161+0xb0>
    617c:	aa1403e0 	mov	x0, x20
    6180:	97fff86d 	bl	4334 <fwp_rc_forget_slot.part.0>
    6184:	17ffffeb 	b	6130 <e161+0xbc>
    6188:	97fff21e 	bl	2a00 <fwp_trap_overflow.constprop.0>
    618c:	97fff1a1 	bl	2810 <__stack_chk_fail@plt>

0000000000006190 <fwp_drop0>:
    6190:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6194:	910003fd 	mov	x29, sp
    6198:	a90153f3 	stp	x19, x20, [sp, #16]
    619c:	f90013f5 	str	x21, [sp, #32]
    61a0:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    61a4:	9118c2b4 	add	x20, x21, #0x630
    61a8:	f949da81 	ldr	x1, [x20, #5040]
    61ac:	f949ee82 	ldr	x2, [x20, #5080]
    61b0:	cb010001 	sub	x1, x0, x1
    61b4:	eb02403f 	cmp	x1, x2, lsl #16
    61b8:	54000382 	b.cs	6228 <fwp_drop0+0x98>  // b.hs, b.nlast
    61bc:	d350fc22 	lsr	x2, x1, #16
    61c0:	f949fe84 	ldr	x4, [x20, #5112]
    61c4:	8b020842 	add	x2, x2, x2, lsl #2
    61c8:	d37df042 	lsl	x2, x2, #3
    61cc:	8b020083 	add	x3, x4, x2
    61d0:	f9401073 	ldr	x19, [x3, #32]
    61d4:	b40002b3 	cbz	x19, 6228 <fwp_drop0+0x98>
    61d8:	38626882 	ldrb	w2, [x4, x2]
    61dc:	7100085f 	cmp	w2, #0x2
    61e0:	540002c0 	b.eq	6238 <fwp_drop0+0xa8>  // b.none
    61e4:	7100045f 	cmp	w2, #0x1
    61e8:	54000201 	b.ne	6228 <fwp_drop0+0x98>  // b.any
    61ec:	29430864 	ldp	w4, w2, [x3, #24]
    61f0:	92403c21 	and	x1, x1, #0xffff
    61f4:	9b047c21 	mul	x1, x1, x4
    61f8:	d360fc21 	lsr	x1, x1, #32
    61fc:	eb02003f 	cmp	x1, x2
    6200:	54000142 	b.cs	6228 <fwp_drop0+0x98>  // b.hs, b.nlast
    6204:	8b010273 	add	x19, x19, x1
    6208:	39400261 	ldrb	w1, [x19]
    620c:	340000e1 	cbz	w1, 6228 <fwp_drop0+0x98>
    6210:	7100043f 	cmp	w1, #0x1
    6214:	540001e0 	b.eq	6250 <fwp_drop0+0xc0>  // b.none
    6218:	7103fc3f 	cmp	w1, #0xff
    621c:	540002e0 	b.eq	6278 <fwp_drop0+0xe8>  // b.none
    6220:	51000421 	sub	w1, w1, #0x1
    6224:	39000261 	strb	w1, [x19]
    6228:	a94153f3 	ldp	x19, x20, [sp, #16]
    622c:	f94013f5 	ldr	x21, [sp, #32]
    6230:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6234:	d65f03c0 	ret
    6238:	72003c3f 	tst	w1, #0xffff
    623c:	54fffe60 	b.eq	6208 <fwp_drop0+0x78>  // b.none
    6240:	a94153f3 	ldp	x19, x20, [sp, #16]
    6244:	f94013f5 	ldr	x21, [sp, #32]
    6248:	a8c37bfd 	ldp	x29, x30, [sp], #48
    624c:	d65f03c0 	ret
    6250:	f9400813 	ldr	x19, [x0, #16]
    6254:	97fffef3 	bl	5e20 <fwp_rc_free_arr>
    6258:	9118c2a0 	add	x0, x21, #0x630
    625c:	f949d801 	ldr	x1, [x0, #5040]
    6260:	f949ec00 	ldr	x0, [x0, #5080]
    6264:	cb010261 	sub	x1, x19, x1
    6268:	eb00403f 	cmp	x1, x0, lsl #16
    626c:	54fffde2 	b.cs	6228 <fwp_drop0+0x98>  // b.hs, b.nlast
    6270:	aa1303e0 	mov	x0, x19
    6274:	17ffffd2 	b	61bc <fwp_drop0+0x2c>
    6278:	ca534660 	eor	x0, x19, x19, lsr #17
    627c:	9118c2b5 	add	x21, x21, #0x630
    6280:	ca402400 	eor	x0, x0, x0, lsr #9
    6284:	92401c00 	and	x0, x0, #0xff
    6288:	910a2402 	add	x2, x0, #0x289
    628c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6290:	8b020ea2 	add	x2, x21, x2, lsl #3
    6294:	f94a2400 	ldr	x0, [x0, #5192]
    6298:	b50000a0 	cbnz	x0, 62ac <fwp_drop0+0x11c>
    629c:	14000013 	b	62e8 <fwp_drop0+0x158>
    62a0:	91004002 	add	x2, x0, #0x10
    62a4:	f9400800 	ldr	x0, [x0, #16]
    62a8:	b4000200 	cbz	x0, 62e8 <fwp_drop0+0x158>
    62ac:	f9400001 	ldr	x1, [x0]
    62b0:	eb13003f 	cmp	x1, x19
    62b4:	54ffff61 	b.ne	62a0 <fwp_drop0+0x110>  // b.any
    62b8:	f9400041 	ldr	x1, [x2]
    62bc:	f9400420 	ldr	x0, [x1, #8]
    62c0:	d1000400 	sub	x0, x0, #0x1
    62c4:	f9000420 	str	x0, [x1, #8]
    62c8:	f103f81f 	cmp	x0, #0xfe
    62cc:	54fffae1 	b.ne	6228 <fwp_drop0+0x98>  // b.any
    62d0:	39400260 	ldrb	w0, [x19]
    62d4:	7103fc1f 	cmp	w0, #0xff
    62d8:	540000e0 	b.eq	62f4 <fwp_drop0+0x164>  // b.none
    62dc:	12800020 	mov	w0, #0xfffffffe            	// #-2
    62e0:	39000260 	strb	w0, [x19]
    62e4:	17ffffd1 	b	6228 <fwp_drop0+0x98>
    62e8:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    62ec:	91116000 	add	x0, x0, #0x458
    62f0:	97fff7f1 	bl	42b4 <fwp_trap>
    62f4:	aa1303e0 	mov	x0, x19
    62f8:	97fff80f 	bl	4334 <fwp_rc_forget_slot.part.0>
    62fc:	17fffff8 	b	62dc <fwp_drop0+0x14c>

0000000000006300 <fwp_arg_drop12>:
    6300:	7100003f 	cmp	w1, #0x0
    6304:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    6308:	54000041 	b.ne	6310 <fwp_arg_drop12+0x10>  // b.any
    630c:	d65f03c0 	ret
    6310:	f9400000 	ldr	x0, [x0]
    6314:	17ffff9f 	b	6190 <fwp_drop0>
    6318:	d503201f 	nop
    631c:	d503201f 	nop

0000000000006320 <fwp_drop1>:
    6320:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6324:	910003fd 	mov	x29, sp
    6328:	a90153f3 	stp	x19, x20, [sp, #16]
    632c:	f90013f5 	str	x21, [sp, #32]
    6330:	f0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    6334:	9118c2b4 	add	x20, x21, #0x630
    6338:	f949da81 	ldr	x1, [x20, #5040]
    633c:	f949ee82 	ldr	x2, [x20, #5080]
    6340:	cb010001 	sub	x1, x0, x1
    6344:	eb02403f 	cmp	x1, x2, lsl #16
    6348:	54000382 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    634c:	d350fc22 	lsr	x2, x1, #16
    6350:	f949fe84 	ldr	x4, [x20, #5112]
    6354:	8b020842 	add	x2, x2, x2, lsl #2
    6358:	d37df042 	lsl	x2, x2, #3
    635c:	8b020083 	add	x3, x4, x2
    6360:	f9401073 	ldr	x19, [x3, #32]
    6364:	b40002b3 	cbz	x19, 63b8 <fwp_drop1+0x98>
    6368:	38626882 	ldrb	w2, [x4, x2]
    636c:	7100085f 	cmp	w2, #0x2
    6370:	540002c0 	b.eq	63c8 <fwp_drop1+0xa8>  // b.none
    6374:	7100045f 	cmp	w2, #0x1
    6378:	54000201 	b.ne	63b8 <fwp_drop1+0x98>  // b.any
    637c:	29430864 	ldp	w4, w2, [x3, #24]
    6380:	92403c21 	and	x1, x1, #0xffff
    6384:	9b047c21 	mul	x1, x1, x4
    6388:	d360fc21 	lsr	x1, x1, #32
    638c:	eb02003f 	cmp	x1, x2
    6390:	54000142 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6394:	8b010273 	add	x19, x19, x1
    6398:	39400261 	ldrb	w1, [x19]
    639c:	340000e1 	cbz	w1, 63b8 <fwp_drop1+0x98>
    63a0:	7100043f 	cmp	w1, #0x1
    63a4:	540001e0 	b.eq	63e0 <fwp_drop1+0xc0>  // b.none
    63a8:	7103fc3f 	cmp	w1, #0xff
    63ac:	540002e0 	b.eq	6408 <fwp_drop1+0xe8>  // b.none
    63b0:	51000421 	sub	w1, w1, #0x1
    63b4:	39000261 	strb	w1, [x19]
    63b8:	a94153f3 	ldp	x19, x20, [sp, #16]
    63bc:	f94013f5 	ldr	x21, [sp, #32]
    63c0:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63c4:	d65f03c0 	ret
    63c8:	72003c3f 	tst	w1, #0xffff
    63cc:	54fffe60 	b.eq	6398 <fwp_drop1+0x78>  // b.none
    63d0:	a94153f3 	ldp	x19, x20, [sp, #16]
    63d4:	f94013f5 	ldr	x21, [sp, #32]
    63d8:	a8c37bfd 	ldp	x29, x30, [sp], #48
    63dc:	d65f03c0 	ret
    63e0:	f9400813 	ldr	x19, [x0, #16]
    63e4:	97fffe8f 	bl	5e20 <fwp_rc_free_arr>
    63e8:	9118c2a0 	add	x0, x21, #0x630
    63ec:	f949d801 	ldr	x1, [x0, #5040]
    63f0:	f949ec00 	ldr	x0, [x0, #5080]
    63f4:	cb010261 	sub	x1, x19, x1
    63f8:	eb00403f 	cmp	x1, x0, lsl #16
    63fc:	54fffde2 	b.cs	63b8 <fwp_drop1+0x98>  // b.hs, b.nlast
    6400:	aa1303e0 	mov	x0, x19
    6404:	17ffffd2 	b	634c <fwp_drop1+0x2c>
    6408:	ca534660 	eor	x0, x19, x19, lsr #17
    640c:	9118c2b5 	add	x21, x21, #0x630
    6410:	ca402400 	eor	x0, x0, x0, lsr #9
    6414:	92401c00 	and	x0, x0, #0xff
    6418:	910a2402 	add	x2, x0, #0x289
    641c:	8b000ea0 	add	x0, x21, x0, lsl #3
    6420:	8b020ea2 	add	x2, x21, x2, lsl #3
    6424:	f94a2400 	ldr	x0, [x0, #5192]
    6428:	b50000a0 	cbnz	x0, 643c <fwp_drop1+0x11c>
    642c:	14000013 	b	6478 <fwp_drop1+0x158>
    6430:	91004002 	add	x2, x0, #0x10
    6434:	f9400800 	ldr	x0, [x0, #16]
    6438:	b4000200 	cbz	x0, 6478 <fwp_drop1+0x158>
    643c:	f9400001 	ldr	x1, [x0]
    6440:	eb13003f 	cmp	x1, x19
    6444:	54ffff61 	b.ne	6430 <fwp_drop1+0x110>  // b.any
    6448:	f9400041 	ldr	x1, [x2]
    644c:	f9400420 	ldr	x0, [x1, #8]
    6450:	d1000400 	sub	x0, x0, #0x1
    6454:	f9000420 	str	x0, [x1, #8]
    6458:	f103f81f 	cmp	x0, #0xfe
    645c:	54fffae1 	b.ne	63b8 <fwp_drop1+0x98>  // b.any
    6460:	39400260 	ldrb	w0, [x19]
    6464:	7103fc1f 	cmp	w0, #0xff
    6468:	540000e0 	b.eq	6484 <fwp_drop1+0x164>  // b.none
    646c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6470:	39000260 	strb	w0, [x19]
    6474:	17ffffd1 	b	63b8 <fwp_drop1+0x98>
    6478:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    647c:	91116000 	add	x0, x0, #0x458
    6480:	97fff78d 	bl	42b4 <fwp_trap>
    6484:	aa1303e0 	mov	x0, x19
    6488:	97fff7ab 	bl	4334 <fwp_rc_forget_slot.part.0>
    648c:	17fffff8 	b	646c <fwp_drop1+0x14c>

0000000000006490 <fwp_closure_drop>:
    6490:	f0000385 	adrp	x5, 79000 <fwp_root_context+0xbb0>
    6494:	9118c0a4 	add	x4, x5, #0x630
    6498:	aa0003e1 	mov	x1, x0
    649c:	f949d882 	ldr	x2, [x4, #5040]
    64a0:	f949ec80 	ldr	x0, [x4, #5080]
    64a4:	cb020022 	sub	x2, x1, x2
    64a8:	eb00405f 	cmp	x2, x0, lsl #16
    64ac:	54000662 	b.cs	6578 <fwp_closure_drop+0xe8>  // b.hs, b.nlast
    64b0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    64b4:	d350fc43 	lsr	x3, x2, #16
    64b8:	910003fd 	mov	x29, sp
    64bc:	8b030863 	add	x3, x3, x3, lsl #2
    64c0:	f949fc84 	ldr	x4, [x4, #5112]
    64c4:	d37df063 	lsl	x3, x3, #3
    64c8:	f9000bf3 	str	x19, [sp, #16]
    64cc:	8b030080 	add	x0, x4, x3
    64d0:	f9401013 	ldr	x19, [x0, #32]
    64d4:	b40002b3 	cbz	x19, 6528 <fwp_closure_drop+0x98>
    64d8:	38636883 	ldrb	w3, [x4, x3]
    64dc:	7100087f 	cmp	w3, #0x2
    64e0:	54000420 	b.eq	6564 <fwp_closure_drop+0xd4>  // b.none
    64e4:	7100047f 	cmp	w3, #0x1
    64e8:	54000201 	b.ne	6528 <fwp_closure_drop+0x98>  // b.any
    64ec:	29430003 	ldp	w3, w0, [x0, #24]
    64f0:	92403c42 	and	x2, x2, #0xffff
    64f4:	9b037c42 	mul	x2, x2, x3
    64f8:	d360fc42 	lsr	x2, x2, #32
    64fc:	eb00005f 	cmp	x2, x0
    6500:	54000142 	b.cs	6528 <fwp_closure_drop+0x98>  // b.hs, b.nlast
    6504:	8b020273 	add	x19, x19, x2
    6508:	39400260 	ldrb	w0, [x19]
    650c:	340000e0 	cbz	w0, 6528 <fwp_closure_drop+0x98>
    6510:	7100041f 	cmp	w0, #0x1
    6514:	54000100 	b.eq	6534 <fwp_closure_drop+0xa4>  // b.none
    6518:	7103fc1f 	cmp	w0, #0xff
    651c:	54000300 	b.eq	657c <fwp_closure_drop+0xec>  // b.none
    6520:	51000400 	sub	w0, w0, #0x1
    6524:	39000260 	strb	w0, [x19]
    6528:	f9400bf3 	ldr	x19, [sp, #16]
    652c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6530:	d65f03c0 	ret
    6534:	d53bd040 	mrs	x0, tpidr_el0
    6538:	91400000 	add	x0, x0, #0x0, lsl #12
    653c:	91004000 	add	x0, x0, #0x10
    6540:	f9400000 	ldr	x0, [x0]
    6544:	b4000080 	cbz	x0, 6554 <fwp_closure_drop+0xc4>
    6548:	f9400bf3 	ldr	x19, [sp, #16]
    654c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6550:	17fff8d4 	b	48a0 <fwp_closure_drop_push>
    6554:	f9400bf3 	ldr	x19, [sp, #16]
    6558:	aa0103e0 	mov	x0, x1
    655c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6560:	17fff915 	b	49b4 <fwp_closure_drop.part.0>
    6564:	72003c5f 	tst	w2, #0xffff
    6568:	54fffd00 	b.eq	6508 <fwp_closure_drop+0x78>  // b.none
    656c:	f9400bf3 	ldr	x19, [sp, #16]
    6570:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6574:	d65f03c0 	ret
    6578:	d65f03c0 	ret
    657c:	ca534660 	eor	x0, x19, x19, lsr #17
    6580:	9118c0a5 	add	x5, x5, #0x630
    6584:	ca402400 	eor	x0, x0, x0, lsr #9
    6588:	92401c00 	and	x0, x0, #0xff
    658c:	910a2402 	add	x2, x0, #0x289
    6590:	8b000ca0 	add	x0, x5, x0, lsl #3
    6594:	8b020ca2 	add	x2, x5, x2, lsl #3
    6598:	f94a2400 	ldr	x0, [x0, #5192]
    659c:	b50000a0 	cbnz	x0, 65b0 <fwp_closure_drop+0x120>
    65a0:	14000013 	b	65ec <fwp_closure_drop+0x15c>
    65a4:	91004002 	add	x2, x0, #0x10
    65a8:	f9400800 	ldr	x0, [x0, #16]
    65ac:	b4000200 	cbz	x0, 65ec <fwp_closure_drop+0x15c>
    65b0:	f9400001 	ldr	x1, [x0]
    65b4:	eb13003f 	cmp	x1, x19
    65b8:	54ffff61 	b.ne	65a4 <fwp_closure_drop+0x114>  // b.any
    65bc:	f9400041 	ldr	x1, [x2]
    65c0:	f9400420 	ldr	x0, [x1, #8]
    65c4:	d1000400 	sub	x0, x0, #0x1
    65c8:	f9000420 	str	x0, [x1, #8]
    65cc:	f103f81f 	cmp	x0, #0xfe
    65d0:	54fffac1 	b.ne	6528 <fwp_closure_drop+0x98>  // b.any
    65d4:	39400260 	ldrb	w0, [x19]
    65d8:	7103fc1f 	cmp	w0, #0xff
    65dc:	540000e0 	b.eq	65f8 <fwp_closure_drop+0x168>  // b.none
    65e0:	12800020 	mov	w0, #0xfffffffe            	// #-2
    65e4:	39000260 	strb	w0, [x19]
    65e8:	17ffffd0 	b	6528 <fwp_closure_drop+0x98>
    65ec:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    65f0:	91116000 	add	x0, x0, #0x458
    65f4:	97fff730 	bl	42b4 <fwp_trap>
    65f8:	aa1303e0 	mov	x0, x19
    65fc:	97fff74e 	bl	4334 <fwp_rc_forget_slot.part.0>
    6600:	17fffff8 	b	65e0 <fwp_closure_drop+0x150>

0000000000006604 <fwp_owned_tape_release>:
    6604:	b4000920 	cbz	x0, 6728 <fwp_owned_tape_release+0x124>
    6608:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    660c:	910003fd 	mov	x29, sp
    6610:	a90153f3 	stp	x19, x20, [sp, #16]
    6614:	aa0003f3 	mov	x19, x0
    6618:	f9400000 	ldr	x0, [x0]
    661c:	b4000060 	cbz	x0, 6628 <fwp_owned_tape_release+0x24>
    6620:	f9400661 	ldr	x1, [x19, #8]
    6624:	f9000401 	str	x1, [x0, #8]
    6628:	f9400661 	ldr	x1, [x19, #8]
    662c:	b4000041 	cbz	x1, 6634 <fwp_owned_tape_release+0x30>
    6630:	f9000020 	str	x0, [x1]
    6634:	f9400a60 	ldr	x0, [x19, #16]
    6638:	f9403401 	ldr	x1, [x0, #104]
    663c:	b40005a1 	cbz	x1, 66f0 <fwp_owned_tape_release+0xec>
    6640:	a9450a60 	ldp	x0, x2, [x19, #80]
    6644:	eb00005f 	cmp	x2, x0
    6648:	540002cd 	b.le	66a0 <fwp_owned_tape_release+0x9c>
    664c:	d2800014 	mov	x20, #0x0                   	// #0
    6650:	f90013f5 	str	x21, [sp, #32]
    6654:	d2800015 	mov	x21, #0x0                   	// #0
    6658:	f9402260 	ldr	x0, [x19, #64]
    665c:	910006b5 	add	x21, x21, #0x1
    6660:	f8746800 	ldr	x0, [x0, x20]
    6664:	d63f0020 	blr	x1
    6668:	f9402260 	ldr	x0, [x19, #64]
    666c:	f9400a61 	ldr	x1, [x19, #16]
    6670:	8b140000 	add	x0, x0, x20
    6674:	91004294 	add	x20, x20, #0x10
    6678:	f9400400 	ldr	x0, [x0, #8]
    667c:	f9403421 	ldr	x1, [x1, #104]
    6680:	d63f0020 	blr	x1
    6684:	a9450261 	ldp	x1, x0, [x19, #80]
    6688:	cb010000 	sub	x0, x0, x1
    668c:	eb15001f 	cmp	x0, x21
    6690:	f9400a60 	ldr	x0, [x19, #16]
    6694:	f9403401 	ldr	x1, [x0, #104]
    6698:	54fffe0c 	b.gt	6658 <fwp_owned_tape_release+0x54>
    669c:	f94013f5 	ldr	x21, [sp, #32]
    66a0:	f9403663 	ldr	x3, [x19, #104]
    66a4:	f9401262 	ldr	x2, [x19, #32]
    66a8:	f100007f 	cmp	x3, #0x0
    66ac:	540001ed 	b.le	66e8 <fwp_owned_tape_release+0xe4>
    66b0:	d2800014 	mov	x20, #0x0                   	// #0
    66b4:	d503201f 	nop
    66b8:	f9402660 	ldr	x0, [x19, #72]
    66bc:	f8747800 	ldr	x0, [x0, x20, lsl #3]
    66c0:	eb02001f 	cmp	x0, x2
    66c4:	540000c0 	b.eq	66dc <fwp_owned_tape_release+0xd8>  // b.none
    66c8:	d63f0020 	blr	x1
    66cc:	f9400a60 	ldr	x0, [x19, #16]
    66d0:	f9401262 	ldr	x2, [x19, #32]
    66d4:	f9403663 	ldr	x3, [x19, #104]
    66d8:	f9403401 	ldr	x1, [x0, #104]
    66dc:	91000694 	add	x20, x20, #0x1
    66e0:	eb14007f 	cmp	x3, x20
    66e4:	54fffeac 	b.gt	66b8 <fwp_owned_tape_release+0xb4>
    66e8:	aa0203e0 	mov	x0, x2
    66ec:	d63f0020 	blr	x1
    66f0:	f9401660 	ldr	x0, [x19, #40]
    66f4:	97ffff67 	bl	6490 <fwp_closure_drop>
    66f8:	f9401a60 	ldr	x0, [x19, #48]
    66fc:	97ffff65 	bl	6490 <fwp_closure_drop>
    6700:	f9401e60 	ldr	x0, [x19, #56]
    6704:	97ffff63 	bl	6490 <fwp_closure_drop>
    6708:	f9402260 	ldr	x0, [x19, #64]
    670c:	97fff7a5 	bl	45a0 <fwp_mem_free>
    6710:	f9402660 	ldr	x0, [x19, #72]
    6714:	97fff7a3 	bl	45a0 <fwp_mem_free>
    6718:	aa1303e0 	mov	x0, x19
    671c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6720:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6724:	17fff79f 	b	45a0 <fwp_mem_free>
    6728:	d65f03c0 	ret
    672c:	d503201f 	nop

0000000000006730 <fwp_tape_finish>:
    6730:	d10203ff 	sub	sp, sp, #0x80
    6734:	b00000c1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    6738:	f947f421 	ldr	x1, [x1, #4072]
    673c:	a9047bfd 	stp	x29, x30, [sp, #64]
    6740:	910103fd 	add	x29, sp, #0x40
    6744:	a9065bf5 	stp	x21, x22, [sp, #96]
    6748:	a90763f7 	stp	x23, x24, [sp, #112]
    674c:	d00000d7 	adrp	x23, 20000 <__data_start>
    6750:	910142f6 	add	x22, x23, #0x50
    6754:	f9400022 	ldr	x2, [x1]
    6758:	f9001fe2 	str	x2, [sp, #56]
    675c:	d2800002 	mov	x2, #0x0                   	// #0
    6760:	910342c0 	add	x0, x22, #0xd0
    6764:	97fff624 	bl	3ff4 <fwp_tape_buffers_dispose>
    6768:	f90086df 	str	xzr, [x22, #264]
    676c:	f94092c0 	ldr	x0, [x22, #288]
    6770:	f100001f 	cmp	x0, #0x0
    6774:	5400034d 	b.le	67dc <fwp_tape_finish+0xac>
    6778:	910003f8 	mov	x24, sp
    677c:	d2800015 	mov	x21, #0x0                   	// #0
    6780:	a90553f3 	stp	x19, x20, [sp, #80]
    6784:	d2800014 	mov	x20, #0x0                   	// #0
    6788:	91000694 	add	x20, x20, #0x1
    678c:	f94046d3 	ldr	x19, [x22, #136]
    6790:	8b150273 	add	x19, x19, x21
    6794:	9101a2b5 	add	x21, x21, #0x68
    6798:	aa1303e0 	mov	x0, x19
    679c:	97fff1fe 	bl	2f94 <fwp_tape_unlink_scope>
    67a0:	aa1803e0 	mov	x0, x24
    67a4:	a9440663 	ldp	x3, x1, [x19, #64]
    67a8:	f9001be1 	str	x1, [sp, #48]
    67ac:	f9400e62 	ldr	x2, [x19, #24]
    67b0:	a9020be3 	stp	x3, x2, [sp, #32]
    67b4:	ad410261 	ldp	q1, q0, [x19, #32]
    67b8:	ad0003e1 	stp	q1, q0, [sp]
    67bc:	97fff60e 	bl	3ff4 <fwp_tape_buffers_dispose>
    67c0:	f9403260 	ldr	x0, [x19, #96]
    67c4:	97ffff90 	bl	6604 <fwp_owned_tape_release>
    67c8:	f900327f 	str	xzr, [x19, #96]
    67cc:	f94092c0 	ldr	x0, [x22, #288]
    67d0:	eb14001f 	cmp	x0, x20
    67d4:	54fffdac 	b.gt	6788 <fwp_tape_finish+0x58>
    67d8:	a94553f3 	ldp	x19, x20, [sp, #80]
    67dc:	910142e0 	add	x0, x23, #0x50
    67e0:	f9404400 	ldr	x0, [x0, #136]
    67e4:	b4000040 	cbz	x0, 67ec <fwp_tape_finish+0xbc>
    67e8:	97fff5e2 	bl	3f70 <ad_raw_free.part.0>
    67ec:	910142f7 	add	x23, x23, #0x50
    67f0:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    67f4:	f947f400 	ldr	x0, [x0, #4072]
    67f8:	f90046ff 	str	xzr, [x23, #136]
    67fc:	f9008aff 	str	xzr, [x23, #272]
    6800:	f90092ff 	str	xzr, [x23, #288]
    6804:	f900b2ff 	str	xzr, [x23, #352]
    6808:	f9401fe2 	ldr	x2, [sp, #56]
    680c:	f9400001 	ldr	x1, [x0]
    6810:	eb010042 	subs	x2, x2, x1
    6814:	d2800001 	mov	x1, #0x0                   	// #0
    6818:	540000c1 	b.ne	6830 <fwp_tape_finish+0x100>  // b.any
    681c:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6820:	a9465bf5 	ldp	x21, x22, [sp, #96]
    6824:	a94763f7 	ldp	x23, x24, [sp, #112]
    6828:	910203ff 	add	sp, sp, #0x80
    682c:	d65f03c0 	ret
    6830:	a90553f3 	stp	x19, x20, [sp, #80]
    6834:	97ffeff7 	bl	2810 <__stack_chk_fail@plt>
    6838:	d503201f 	nop
    683c:	d503201f 	nop

0000000000006840 <fwp_tape_scope_release>:
    6840:	d10243ff 	sub	sp, sp, #0x90
    6844:	a9047bfd 	stp	x29, x30, [sp, #64]
    6848:	910103fd 	add	x29, sp, #0x40
    684c:	a90553f3 	stp	x19, x20, [sp, #80]
    6850:	aa0003f4 	mov	x20, x0
    6854:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6858:	f947f400 	ldr	x0, [x0, #4072]
    685c:	b9400285 	ldr	w5, [x20]
    6860:	f9400001 	ldr	x1, [x0]
    6864:	f9001fe1 	str	x1, [sp, #56]
    6868:	d2800001 	mov	x1, #0x0                   	// #0
    686c:	37f806c5 	tbnz	w5, #31, 6944 <fwp_tape_scope_release+0x104>
    6870:	a90763f7 	stp	x23, x24, [sp, #112]
    6874:	d289d8b8 	mov	x24, #0x4ec5                	// #20165
    6878:	f2b89d98 	movk	x24, #0xc4ec, lsl #16
    687c:	f2dd89d8 	movk	x24, #0xec4e, lsl #32
    6880:	d00000d3 	adrp	x19, 20000 <__data_start>
    6884:	910003f7 	mov	x23, sp
    6888:	91014273 	add	x19, x19, #0x50
    688c:	f2e9d898 	movk	x24, #0x4ec4, lsl #48
    6890:	a9065bf5 	stp	x21, x22, [sp, #96]
    6894:	52800d16 	mov	w22, #0x68                  	// #104
    6898:	528fffd5 	mov	w21, #0x7ffe                	// #32766
    689c:	f90043f9 	str	x25, [sp, #128]
    68a0:	14000006 	b	68b8 <fwp_tape_scope_release+0x78>
    68a4:	97fff5d4 	bl	3ff4 <fwp_tape_buffers_dispose>
    68a8:	aa1903e0 	mov	x0, x25
    68ac:	97ffff56 	bl	6604 <fwp_owned_tape_release>
    68b0:	b9400285 	ldr	w5, [x20]
    68b4:	37f80425 	tbnz	w5, #31, 6938 <fwp_tape_scope_release+0xf8>
    68b8:	f9404666 	ldr	x6, [x19, #136]
    68bc:	9b367ca5 	smull	x5, w5, w22
    68c0:	8b0500c0 	add	x0, x6, x5
    68c4:	97fff1b4 	bl	2f94 <fwp_tape_unlink_scope>
    68c8:	ad410001 	ldp	q1, q0, [x0, #32]
    68cc:	a9027c1f 	stp	xzr, xzr, [x0, #32]
    68d0:	a9037c1f 	stp	xzr, xzr, [x0, #48]
    68d4:	f9400c03 	ldr	x3, [x0, #24]
    68d8:	ad0003e1 	stp	q1, q0, [sp]
    68dc:	b86568c1 	ldr	w1, [x6, x5]
    68e0:	a9440804 	ldp	x4, x2, [x0, #64]
    68e4:	b900041f 	str	wzr, [x0, #4]
    68e8:	f9403019 	ldr	x25, [x0, #96]
    68ec:	a900fc1f 	stp	xzr, xzr, [x0, #8]
    68f0:	f9000c1f 	str	xzr, [x0, #24]
    68f4:	a9020fe4 	stp	x4, x3, [sp, #32]
    68f8:	f9001be2 	str	x2, [sp, #48]
    68fc:	a9047c1f 	stp	xzr, xzr, [x0, #64]
    6900:	f900301f 	str	xzr, [x0, #96]
    6904:	6b15003f 	cmp	w1, w21
    6908:	540000e8 	b.hi	6924 <fwp_tape_scope_release+0xe4>  // b.pmore
    690c:	9343fca5 	asr	x5, x5, #3
    6910:	f940b260 	ldr	x0, [x19, #352]
    6914:	9b187ca5 	mul	x5, x5, x24
    6918:	eb0000bf 	cmp	x5, x0
    691c:	5400004a 	b.ge	6924 <fwp_tape_scope_release+0xe4>  // b.tcont
    6920:	f900b265 	str	x5, [x19, #352]
    6924:	aa1703e0 	mov	x0, x23
    6928:	b5fffbf9 	cbnz	x25, 68a4 <fwp_tape_scope_release+0x64>
    692c:	97fff5fa 	bl	4114 <fwp_tape_buffers_release>
    6930:	b9400285 	ldr	w5, [x20]
    6934:	36fffc25 	tbz	w5, #31, 68b8 <fwp_tape_scope_release+0x78>
    6938:	a9465bf5 	ldp	x21, x22, [sp, #96]
    693c:	a94763f7 	ldp	x23, x24, [sp, #112]
    6940:	f94043f9 	ldr	x25, [sp, #128]
    6944:	b00000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    6948:	f947f400 	ldr	x0, [x0, #4072]
    694c:	f9401fe2 	ldr	x2, [sp, #56]
    6950:	f9400001 	ldr	x1, [x0]
    6954:	eb010042 	subs	x2, x2, x1
    6958:	d2800001 	mov	x1, #0x0                   	// #0
    695c:	540000a1 	b.ne	6970 <fwp_tape_scope_release+0x130>  // b.any
    6960:	a9447bfd 	ldp	x29, x30, [sp, #64]
    6964:	a94553f3 	ldp	x19, x20, [sp, #80]
    6968:	910243ff 	add	sp, sp, #0x90
    696c:	d65f03c0 	ret
    6970:	a9065bf5 	stp	x21, x22, [sp, #96]
    6974:	a90763f7 	stp	x23, x24, [sp, #112]
    6978:	f90043f9 	str	x25, [sp, #128]
    697c:	97ffefa5 	bl	2810 <__stack_chk_fail@plt>

0000000000006980 <fwp_task_dispose>:
    6980:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6984:	910003fd 	mov	x29, sp
    6988:	f9000bf3 	str	x19, [sp, #16]
    698c:	aa0003f3 	mov	x19, x0
    6990:	39414000 	ldrb	w0, [x0, #80]
    6994:	36000720 	tbz	w0, #0, 6a78 <fwp_task_dispose+0xf8>
    6998:	f9400a60 	ldr	x0, [x19, #16]
    699c:	b50006e0 	cbnz	x0, 6a78 <fwp_task_dispose+0xf8>
    69a0:	a9478660 	ldp	x0, x1, [x19, #120]
    69a4:	39014e7f 	strb	wzr, [x19, #83]
    69a8:	f9003e7f 	str	xzr, [x19, #120]
    69ac:	f100003f 	cmp	x1, #0x0
    69b0:	fa401804 	ccmp	x0, #0x0, #0x4, ne	// ne = any
    69b4:	54000040 	b.eq	69bc <fwp_task_dispose+0x3c>  // b.none
    69b8:	d63f0020 	blr	x1
    69bc:	f9405660 	ldr	x0, [x19, #168]
    69c0:	97fff6f8 	bl	45a0 <fwp_mem_free>
    69c4:	f900567f 	str	xzr, [x19, #168]
    69c8:	b9405e60 	ldr	w0, [x19, #92]
    69cc:	7100041f 	cmp	w0, #0x1
    69d0:	54000420 	b.eq	6a54 <fwp_task_dispose+0xd4>  // b.none
    69d4:	f0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    69d8:	9118c042 	add	x2, x2, #0x630
    69dc:	f949d840 	ldr	x0, [x2, #5040]
    69e0:	f949ec41 	ldr	x1, [x2, #5080]
    69e4:	cb000260 	sub	x0, x19, x0
    69e8:	eb01401f 	cmp	x0, x1, lsl #16
    69ec:	540002e2 	b.cs	6a48 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    69f0:	d350fc01 	lsr	x1, x0, #16
    69f4:	f949fc44 	ldr	x4, [x2, #5112]
    69f8:	8b010821 	add	x1, x1, x1, lsl #2
    69fc:	d37df021 	lsl	x1, x1, #3
    6a00:	8b010083 	add	x3, x4, x1
    6a04:	f9401062 	ldr	x2, [x3, #32]
    6a08:	b4000202 	cbz	x2, 6a48 <fwp_task_dispose+0xc8>
    6a0c:	38616881 	ldrb	w1, [x4, x1]
    6a10:	7100083f 	cmp	w1, #0x2
    6a14:	54000280 	b.eq	6a64 <fwp_task_dispose+0xe4>  // b.none
    6a18:	7100043f 	cmp	w1, #0x1
    6a1c:	54000161 	b.ne	6a48 <fwp_task_dispose+0xc8>  // b.any
    6a20:	29430464 	ldp	w4, w1, [x3, #24]
    6a24:	92403c00 	and	x0, x0, #0xffff
    6a28:	9b047c00 	mul	x0, x0, x4
    6a2c:	d360fc00 	lsr	x0, x0, #32
    6a30:	eb01001f 	cmp	x0, x1
    6a34:	540000a2 	b.cs	6a48 <fwp_task_dispose+0xc8>  // b.hs, b.nlast
    6a38:	8b000042 	add	x2, x2, x0
    6a3c:	39400040 	ldrb	w0, [x2]
    6a40:	7100041f 	cmp	w0, #0x1
    6a44:	54000080 	b.eq	6a54 <fwp_task_dispose+0xd4>  // b.none
    6a48:	f9400bf3 	ldr	x19, [sp, #16]
    6a4c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a50:	d65f03c0 	ret
    6a54:	aa1303e0 	mov	x0, x19
    6a58:	f9400bf3 	ldr	x19, [sp, #16]
    6a5c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a60:	17fff6d0 	b	45a0 <fwp_mem_free>
    6a64:	72003c1f 	tst	w0, #0xffff
    6a68:	54fffea0 	b.eq	6a3c <fwp_task_dispose+0xbc>  // b.none
    6a6c:	f9400bf3 	ldr	x19, [sp, #16]
    6a70:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6a74:	d65f03c0 	ret
    6a78:	97ffef7a 	bl	2860 <abort@plt>
    6a7c:	d503201f 	nop

0000000000006a80 <fwp_free_zombie>:
    6a80:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6a84:	910003fd 	mov	x29, sp
    6a88:	a90153f3 	stp	x19, x20, [sp, #16]
    6a8c:	d00000d4 	adrp	x20, 20000 <__data_start>
    6a90:	91014281 	add	x1, x20, #0x50
    6a94:	f940b433 	ldr	x19, [x1, #360]
    6a98:	b4000333 	cbz	x19, 6afc <fwp_free_zombie+0x7c>
    6a9c:	f9404c20 	ldr	x0, [x1, #152]
    6aa0:	eb00027f 	cmp	x19, x0
    6aa4:	540002c0 	b.eq	6afc <fwp_free_zombie+0x7c>  // b.none
    6aa8:	b9417022 	ldr	w2, [x1, #368]
    6aac:	f9400a60 	ldr	x0, [x19, #16]
    6ab0:	7100fc5f 	cmp	w2, #0x3f
    6ab4:	5400078c 	b.gt	6ba4 <fwp_free_zombie+0x124>
    6ab8:	91060023 	add	x3, x1, #0x180
    6abc:	11000444 	add	w4, w2, #0x1
    6ac0:	b9017024 	str	w4, [x1, #368]
    6ac4:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6ac8:	f822d860 	str	x0, [x3, w2, sxtw #3]
    6acc:	a9530261 	ldp	x1, x0, [x19, #304]
    6ad0:	b4000741 	cbz	x1, 6bb8 <fwp_free_zombie+0x138>
    6ad4:	f9009c20 	str	x0, [x1, #312]
    6ad8:	b4000040 	cbz	x0, 6ae0 <fwp_free_zombie+0x60>
    6adc:	f9009801 	str	x1, [x0, #304]
    6ae0:	91014294 	add	x20, x20, #0x50
    6ae4:	b9405e60 	ldr	w0, [x19, #92]
    6ae8:	a9137e7f 	stp	xzr, xzr, [x19, #304]
    6aec:	f900b69f 	str	xzr, [x20, #360]
    6af0:	34000140 	cbz	w0, 6b18 <fwp_free_zombie+0x98>
    6af4:	7100041f 	cmp	w0, #0x1
    6af8:	54000080 	b.eq	6b08 <fwp_free_zombie+0x88>  // b.none
    6afc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b00:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b04:	d65f03c0 	ret
    6b08:	aa1303e0 	mov	x0, x19
    6b0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6b10:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6b14:	17ffff9b 	b	6980 <fwp_task_dispose>
    6b18:	f0000384 	adrp	x4, 79000 <fwp_root_context+0xbb0>
    6b1c:	9118c082 	add	x2, x4, #0x630
    6b20:	f949d841 	ldr	x1, [x2, #5040]
    6b24:	f949ec40 	ldr	x0, [x2, #5080]
    6b28:	cb010261 	sub	x1, x19, x1
    6b2c:	eb00403f 	cmp	x1, x0, lsl #16
    6b30:	54fffe62 	b.cs	6afc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b34:	d350fc20 	lsr	x0, x1, #16
    6b38:	f949fc43 	ldr	x3, [x2, #5112]
    6b3c:	8b000800 	add	x0, x0, x0, lsl #2
    6b40:	d37df000 	lsl	x0, x0, #3
    6b44:	8b000062 	add	x2, x3, x0
    6b48:	f9401054 	ldr	x20, [x2, #32]
    6b4c:	b4fffd94 	cbz	x20, 6afc <fwp_free_zombie+0x7c>
    6b50:	38606860 	ldrb	w0, [x3, x0]
    6b54:	7100081f 	cmp	w0, #0x2
    6b58:	54000360 	b.eq	6bc4 <fwp_free_zombie+0x144>  // b.none
    6b5c:	7100041f 	cmp	w0, #0x1
    6b60:	54fffce1 	b.ne	6afc <fwp_free_zombie+0x7c>  // b.any
    6b64:	29430043 	ldp	w3, w0, [x2, #24]
    6b68:	92403c21 	and	x1, x1, #0xffff
    6b6c:	9b037c21 	mul	x1, x1, x3
    6b70:	d360fc21 	lsr	x1, x1, #32
    6b74:	eb00003f 	cmp	x1, x0
    6b78:	54fffc22 	b.cs	6afc <fwp_free_zombie+0x7c>  // b.hs, b.nlast
    6b7c:	8b010294 	add	x20, x20, x1
    6b80:	39400280 	ldrb	w0, [x20]
    6b84:	34fffbc0 	cbz	w0, 6afc <fwp_free_zombie+0x7c>
    6b88:	7100041f 	cmp	w0, #0x1
    6b8c:	54fffbe0 	b.eq	6b08 <fwp_free_zombie+0x88>  // b.none
    6b90:	7103fc1f 	cmp	w0, #0xff
    6b94:	540001e0 	b.eq	6bd0 <fwp_free_zombie+0x150>  // b.none
    6b98:	51000400 	sub	w0, w0, #0x1
    6b9c:	39000280 	strb	w0, [x20]
    6ba0:	17ffffd7 	b	6afc <fwp_free_zombie+0x7c>
    6ba4:	f9400e61 	ldr	x1, [x19, #24]
    6ba8:	97ffef62 	bl	2930 <munmap@plt>
    6bac:	a900fe7f 	stp	xzr, xzr, [x19, #8]
    6bb0:	a9530261 	ldp	x1, x0, [x19, #304]
    6bb4:	b5fff901 	cbnz	x1, 6ad4 <fwp_free_zombie+0x54>
    6bb8:	91014282 	add	x2, x20, #0x50
    6bbc:	f901c040 	str	x0, [x2, #896]
    6bc0:	17ffffc6 	b	6ad8 <fwp_free_zombie+0x58>
    6bc4:	72003c3f 	tst	w1, #0xffff
    6bc8:	54fff9a1 	b.ne	6afc <fwp_free_zombie+0x7c>  // b.any
    6bcc:	17ffffed 	b	6b80 <fwp_free_zombie+0x100>
    6bd0:	ca544680 	eor	x0, x20, x20, lsr #17
    6bd4:	9118c084 	add	x4, x4, #0x630
    6bd8:	ca402400 	eor	x0, x0, x0, lsr #9
    6bdc:	92401c00 	and	x0, x0, #0xff
    6be0:	910a2402 	add	x2, x0, #0x289
    6be4:	8b000c80 	add	x0, x4, x0, lsl #3
    6be8:	8b020c82 	add	x2, x4, x2, lsl #3
    6bec:	f94a2400 	ldr	x0, [x0, #5192]
    6bf0:	b50000a0 	cbnz	x0, 6c04 <fwp_free_zombie+0x184>
    6bf4:	14000013 	b	6c40 <fwp_free_zombie+0x1c0>
    6bf8:	91004002 	add	x2, x0, #0x10
    6bfc:	f9400800 	ldr	x0, [x0, #16]
    6c00:	b4000200 	cbz	x0, 6c40 <fwp_free_zombie+0x1c0>
    6c04:	f9400001 	ldr	x1, [x0]
    6c08:	eb14003f 	cmp	x1, x20
    6c0c:	54ffff61 	b.ne	6bf8 <fwp_free_zombie+0x178>  // b.any
    6c10:	f9400041 	ldr	x1, [x2]
    6c14:	f9400420 	ldr	x0, [x1, #8]
    6c18:	d1000400 	sub	x0, x0, #0x1
    6c1c:	f9000420 	str	x0, [x1, #8]
    6c20:	f103f81f 	cmp	x0, #0xfe
    6c24:	54fff6c1 	b.ne	6afc <fwp_free_zombie+0x7c>  // b.any
    6c28:	39400280 	ldrb	w0, [x20]
    6c2c:	7103fc1f 	cmp	w0, #0xff
    6c30:	540000e0 	b.eq	6c4c <fwp_free_zombie+0x1cc>  // b.none
    6c34:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6c38:	39000280 	strb	w0, [x20]
    6c3c:	17ffffb0 	b	6afc <fwp_free_zombie+0x7c>
    6c40:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    6c44:	91116000 	add	x0, x0, #0x458
    6c48:	97fff59b 	bl	42b4 <fwp_trap>
    6c4c:	aa1403e0 	mov	x0, x20
    6c50:	97fff5b9 	bl	4334 <fwp_rc_forget_slot.part.0>
    6c54:	17fffff8 	b	6c34 <fwp_free_zombie+0x1b4>
    6c58:	d503201f 	nop
    6c5c:	d503201f 	nop

0000000000006c60 <fwp_block>:
    6c60:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    6c64:	910003fd 	mov	x29, sp
    6c68:	a90153f3 	stp	x19, x20, [sp, #16]
    6c6c:	d00000d3 	adrp	x19, 20000 <__data_start>
    6c70:	91014274 	add	x20, x19, #0x50
    6c74:	f9406682 	ldr	x2, [x20, #200]
    6c78:	b4000642 	cbz	x2, 6d40 <fwp_block+0xe0>
    6c7c:	91014261 	add	x1, x19, #0x50
    6c80:	f9408040 	ldr	x0, [x2, #256]
    6c84:	f9006420 	str	x0, [x1, #200]
    6c88:	b40006a0 	cbz	x0, 6d5c <fwp_block+0xfc>
    6c8c:	d503201f 	nop
    6c90:	91014263 	add	x3, x19, #0x50
    6c94:	3901505f 	strb	wzr, [x2, #84]
    6c98:	f9404c64 	ldr	x4, [x3, #152]
    6c9c:	eb02009f 	cmp	x4, x2
    6ca0:	54000440 	b.eq	6d28 <fwp_block+0xc8>  // b.none
    6ca4:	f941c465 	ldr	x5, [x3, #904]
    6ca8:	f9004c62 	str	x2, [x3, #152]
    6cac:	f9400441 	ldr	x1, [x2, #8]
    6cb0:	f9004885 	str	x5, [x4, #144]
    6cb4:	f941c865 	ldr	x5, [x3, #912]
    6cb8:	f9004c85 	str	x5, [x4, #152]
    6cbc:	f941cc65 	ldr	x5, [x3, #920]
    6cc0:	f9005085 	str	x5, [x4, #160]
    6cc4:	f941d065 	ldr	x5, [x3, #928]
    6cc8:	f9005485 	str	x5, [x4, #168]
    6ccc:	f941d465 	ldr	x5, [x3, #936]
    6cd0:	f9005885 	str	x5, [x4, #176]
    6cd4:	f941d865 	ldr	x5, [x3, #944]
    6cd8:	f9005c85 	str	x5, [x4, #184]
    6cdc:	f941dc65 	ldr	x5, [x3, #952]
    6ce0:	f9006085 	str	x5, [x4, #192]
    6ce4:	f9400480 	ldr	x0, [x4, #8]
    6ce8:	f9404844 	ldr	x4, [x2, #144]
    6cec:	f901c464 	str	x4, [x3, #904]
    6cf0:	f9404c44 	ldr	x4, [x2, #152]
    6cf4:	f901c864 	str	x4, [x3, #912]
    6cf8:	f9405044 	ldr	x4, [x2, #160]
    6cfc:	f901cc64 	str	x4, [x3, #920]
    6d00:	f9405444 	ldr	x4, [x2, #168]
    6d04:	f901d064 	str	x4, [x3, #928]
    6d08:	f9405844 	ldr	x4, [x2, #176]
    6d0c:	f901d464 	str	x4, [x3, #936]
    6d10:	a94b8844 	ldp	x4, x2, [x2, #184]
    6d14:	f901d864 	str	x4, [x3, #944]
    6d18:	f901dc62 	str	x2, [x3, #952]
    6d1c:	97ffeed5 	bl	2870 <swapcontext@plt>
    6d20:	97ffff58 	bl	6a80 <fwp_free_zombie>
    6d24:	d503201f 	nop
    6d28:	91014260 	add	x0, x19, #0x50
    6d2c:	b943c000 	ldr	w0, [x0, #960]
    6d30:	340001a0 	cbz	w0, 6d64 <fwp_block+0x104>
    6d34:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d38:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d3c:	d65f03c0 	ret
    6d40:	97fff7a4 	bl	4bd0 <fwp_poll_events>
    6d44:	f9406682 	ldr	x2, [x20, #200]
    6d48:	b4ffffc2 	cbz	x2, 6d40 <fwp_block+0xe0>
    6d4c:	91014261 	add	x1, x19, #0x50
    6d50:	f9408040 	ldr	x0, [x2, #256]
    6d54:	f9006420 	str	x0, [x1, #200]
    6d58:	b5fff9c0 	cbnz	x0, 6c90 <fwp_block+0x30>
    6d5c:	f900603f 	str	xzr, [x1, #192]
    6d60:	17ffffcc 	b	6c90 <fwp_block+0x30>
    6d64:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    6d68:	911bc000 	add	x0, x0, #0x6f0
    6d6c:	97ffef0d 	bl	29a0 <getenv@plt>
    6d70:	5284e202 	mov	w2, #0x2710                	// #10000
    6d74:	b4000060 	cbz	x0, 6d80 <fwp_block+0x120>
    6d78:	39400001 	ldrb	w1, [x0]
    6d7c:	350000c1 	cbnz	w1, 6d94 <fwp_block+0x134>
    6d80:	91014273 	add	x19, x19, #0x50
    6d84:	b903c262 	str	w2, [x19, #960]
    6d88:	a94153f3 	ldp	x19, x20, [sp, #16]
    6d8c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    6d90:	d65f03c0 	ret
    6d94:	52800142 	mov	w2, #0xa                   	// #10
    6d98:	d2800001 	mov	x1, #0x0                   	// #0
    6d9c:	97ffee51 	bl	26e0 <strtoll@plt>
    6da0:	d1000403 	sub	x3, x0, #0x1
    6da4:	b27f77e2 	mov	x2, #0x7ffffffe            	// #2147483646
    6da8:	eb02007f 	cmp	x3, x2
    6dac:	12b00001 	mov	w1, #0x7fffffff            	// #2147483647
    6db0:	1a819002 	csel	w2, w0, w1, ls	// ls = plast
    6db4:	17fffff3 	b	6d80 <fwp_block+0x120>
    6db8:	d503201f 	nop
    6dbc:	d503201f 	nop

0000000000006dc0 <fwp_drop4>:
    6dc0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    6dc4:	910003fd 	mov	x29, sp
    6dc8:	a90153f3 	stp	x19, x20, [sp, #16]
    6dcc:	f0000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    6dd0:	f90013f5 	str	x21, [sp, #32]
    6dd4:	9118c275 	add	x21, x19, #0x630
    6dd8:	f949daa1 	ldr	x1, [x21, #5040]
    6ddc:	f949eea2 	ldr	x2, [x21, #5080]
    6de0:	cb010001 	sub	x1, x0, x1
    6de4:	eb02403f 	cmp	x1, x2, lsl #16
    6de8:	54000382 	b.cs	6e58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6dec:	d350fc22 	lsr	x2, x1, #16
    6df0:	f949fea3 	ldr	x3, [x21, #5112]
    6df4:	8b020842 	add	x2, x2, x2, lsl #2
    6df8:	d37df042 	lsl	x2, x2, #3
    6dfc:	8b020064 	add	x4, x3, x2
    6e00:	f9401094 	ldr	x20, [x4, #32]
    6e04:	b40002b4 	cbz	x20, 6e58 <fwp_drop4+0x98>
    6e08:	38626862 	ldrb	w2, [x3, x2]
    6e0c:	7100085f 	cmp	w2, #0x2
    6e10:	540007a0 	b.eq	6f04 <fwp_drop4+0x144>  // b.none
    6e14:	7100045f 	cmp	w2, #0x1
    6e18:	54000201 	b.ne	6e58 <fwp_drop4+0x98>  // b.any
    6e1c:	29430885 	ldp	w5, w2, [x4, #24]
    6e20:	92403c21 	and	x1, x1, #0xffff
    6e24:	9b057c21 	mul	x1, x1, x5
    6e28:	d360fc21 	lsr	x1, x1, #32
    6e2c:	eb02003f 	cmp	x1, x2
    6e30:	54000142 	b.cs	6e58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e34:	8b010294 	add	x20, x20, x1
    6e38:	39400281 	ldrb	w1, [x20]
    6e3c:	340000e1 	cbz	w1, 6e58 <fwp_drop4+0x98>
    6e40:	7100043f 	cmp	w1, #0x1
    6e44:	54000120 	b.eq	6e68 <fwp_drop4+0xa8>  // b.none
    6e48:	7103fc3f 	cmp	w1, #0xff
    6e4c:	540007c0 	b.eq	6f44 <fwp_drop4+0x184>  // b.none
    6e50:	51000421 	sub	w1, w1, #0x1
    6e54:	39000281 	strb	w1, [x20]
    6e58:	a94153f3 	ldp	x19, x20, [sp, #16]
    6e5c:	f94013f5 	ldr	x21, [sp, #32]
    6e60:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6e64:	d65f03c0 	ret
    6e68:	f9400001 	ldr	x1, [x0]
    6e6c:	b7f80581 	tbnz	x1, #63, 6f1c <fwp_drop4+0x15c>
    6e70:	9118c273 	add	x19, x19, #0x630
    6e74:	f949da61 	ldr	x1, [x19, #5040]
    6e78:	f949ee62 	ldr	x2, [x19, #5080]
    6e7c:	cb010001 	sub	x1, x0, x1
    6e80:	eb02403f 	cmp	x1, x2, lsl #16
    6e84:	54fffea2 	b.cs	6e58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6e88:	d350fc22 	lsr	x2, x1, #16
    6e8c:	8b020842 	add	x2, x2, x2, lsl #2
    6e90:	d37df042 	lsl	x2, x2, #3
    6e94:	8b020065 	add	x5, x3, x2
    6e98:	f94010a4 	ldr	x4, [x5, #32]
    6e9c:	b4fffde4 	cbz	x4, 6e58 <fwp_drop4+0x98>
    6ea0:	38626862 	ldrb	w2, [x3, x2]
    6ea4:	7100085f 	cmp	w2, #0x2
    6ea8:	54000220 	b.eq	6eec <fwp_drop4+0x12c>  // b.none
    6eac:	7100045f 	cmp	w2, #0x1
    6eb0:	54fffd41 	b.ne	6e58 <fwp_drop4+0x98>  // b.any
    6eb4:	294308a3 	ldp	w3, w2, [x5, #24]
    6eb8:	92403c21 	and	x1, x1, #0xffff
    6ebc:	9b037c21 	mul	x1, x1, x3
    6ec0:	d360fc21 	lsr	x1, x1, #32
    6ec4:	eb02003f 	cmp	x1, x2
    6ec8:	54fffc82 	b.cs	6e58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6ecc:	8b010084 	add	x4, x4, x1
    6ed0:	39400081 	ldrb	w1, [x4]
    6ed4:	7100043f 	cmp	w1, #0x1
    6ed8:	54fffc01 	b.ne	6e58 <fwp_drop4+0x98>  // b.any
    6edc:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ee0:	f94013f5 	ldr	x21, [sp, #32]
    6ee4:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6ee8:	17fff5ae 	b	45a0 <fwp_mem_free>
    6eec:	72003c3f 	tst	w1, #0xffff
    6ef0:	54ffff00 	b.eq	6ed0 <fwp_drop4+0x110>  // b.none
    6ef4:	a94153f3 	ldp	x19, x20, [sp, #16]
    6ef8:	f94013f5 	ldr	x21, [sp, #32]
    6efc:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f00:	d65f03c0 	ret
    6f04:	72003c3f 	tst	w1, #0xffff
    6f08:	54fff980 	b.eq	6e38 <fwp_drop4+0x78>  // b.none
    6f0c:	a94153f3 	ldp	x19, x20, [sp, #16]
    6f10:	f94013f5 	ldr	x21, [sp, #32]
    6f14:	a8c37bfd 	ldp	x29, x30, [sp], #48
    6f18:	d65f03c0 	ret
    6f1c:	f9400414 	ldr	x20, [x0, #8]
    6f20:	97fffbc0 	bl	5e20 <fwp_rc_free_arr>
    6f24:	9118c260 	add	x0, x19, #0x630
    6f28:	f949d801 	ldr	x1, [x0, #5040]
    6f2c:	f949ec00 	ldr	x0, [x0, #5080]
    6f30:	cb010281 	sub	x1, x20, x1
    6f34:	eb00403f 	cmp	x1, x0, lsl #16
    6f38:	54fff902 	b.cs	6e58 <fwp_drop4+0x98>  // b.hs, b.nlast
    6f3c:	aa1403e0 	mov	x0, x20
    6f40:	17ffffab 	b	6dec <fwp_drop4+0x2c>
    6f44:	ca544680 	eor	x0, x20, x20, lsr #17
    6f48:	9118c273 	add	x19, x19, #0x630
    6f4c:	ca402400 	eor	x0, x0, x0, lsr #9
    6f50:	92401c00 	and	x0, x0, #0xff
    6f54:	910a2402 	add	x2, x0, #0x289
    6f58:	8b000e60 	add	x0, x19, x0, lsl #3
    6f5c:	8b020e62 	add	x2, x19, x2, lsl #3
    6f60:	f94a2400 	ldr	x0, [x0, #5192]
    6f64:	b50000a0 	cbnz	x0, 6f78 <fwp_drop4+0x1b8>
    6f68:	14000013 	b	6fb4 <fwp_drop4+0x1f4>
    6f6c:	91004002 	add	x2, x0, #0x10
    6f70:	f9400800 	ldr	x0, [x0, #16]
    6f74:	b4000200 	cbz	x0, 6fb4 <fwp_drop4+0x1f4>
    6f78:	f9400001 	ldr	x1, [x0]
    6f7c:	eb14003f 	cmp	x1, x20
    6f80:	54ffff61 	b.ne	6f6c <fwp_drop4+0x1ac>  // b.any
    6f84:	f9400041 	ldr	x1, [x2]
    6f88:	f9400420 	ldr	x0, [x1, #8]
    6f8c:	d1000400 	sub	x0, x0, #0x1
    6f90:	f9000420 	str	x0, [x1, #8]
    6f94:	f103f81f 	cmp	x0, #0xfe
    6f98:	54fff601 	b.ne	6e58 <fwp_drop4+0x98>  // b.any
    6f9c:	39400280 	ldrb	w0, [x20]
    6fa0:	7103fc1f 	cmp	w0, #0xff
    6fa4:	540000e0 	b.eq	6fc0 <fwp_drop4+0x200>  // b.none
    6fa8:	12800020 	mov	w0, #0xfffffffe            	// #-2
    6fac:	39000280 	strb	w0, [x20]
    6fb0:	17ffffaa 	b	6e58 <fwp_drop4+0x98>
    6fb4:	b0000020 	adrp	x0, b000 <__modti3+0x2a0>
    6fb8:	91116000 	add	x0, x0, #0x458
    6fbc:	97fff4be 	bl	42b4 <fwp_trap>
    6fc0:	aa1403e0 	mov	x0, x20
    6fc4:	97fff4dc 	bl	4334 <fwp_rc_forget_slot.part.0>
    6fc8:	17fffff8 	b	6fa8 <fwp_drop4+0x1e8>
    6fcc:	d503201f 	nop

0000000000006fd0 <fwp_caps161>:
    6fd0:	34000041 	cbz	w1, 6fd8 <fwp_caps161+0x8>
    6fd4:	d65f03c0 	ret
    6fd8:	f0000383 	adrp	x3, 79000 <fwp_root_context+0xbb0>
    6fdc:	9118c063 	add	x3, x3, #0x630
    6fe0:	f949d861 	ldr	x1, [x3, #5040]
    6fe4:	f949ec62 	ldr	x2, [x3, #5080]
    6fe8:	cb010001 	sub	x1, x0, x1
    6fec:	eb02403f 	cmp	x1, x2, lsl #16
    6ff0:	54ffff22 	b.cs	6fd4 <fwp_caps161+0x4>  // b.hs, b.nlast
    6ff4:	d350fc22 	lsr	x2, x1, #16
    6ff8:	f949fc65 	ldr	x5, [x3, #5112]
    6ffc:	8b020842 	add	x2, x2, x2, lsl #2
    7000:	d37df042 	lsl	x2, x2, #3
    7004:	8b0200a4 	add	x4, x5, x2
    7008:	f9401083 	ldr	x3, [x4, #32]
    700c:	b4fffe43 	cbz	x3, 6fd4 <fwp_caps161+0x4>
    7010:	386268a2 	ldrb	w2, [x5, x2]
    7014:	7100085f 	cmp	w2, #0x2
    7018:	540001c0 	b.eq	7050 <fwp_caps161+0x80>  // b.none
    701c:	7100045f 	cmp	w2, #0x1
    7020:	54fffda1 	b.ne	6fd4 <fwp_caps161+0x4>  // b.any
    7024:	29430885 	ldp	w5, w2, [x4, #24]
    7028:	92403c21 	and	x1, x1, #0xffff
    702c:	9b057c21 	mul	x1, x1, x5
    7030:	d360fc21 	lsr	x1, x1, #32
    7034:	eb02003f 	cmp	x1, x2
    7038:	54fffce2 	b.cs	6fd4 <fwp_caps161+0x4>  // b.hs, b.nlast
    703c:	8b010063 	add	x3, x3, x1
    7040:	39400061 	ldrb	w1, [x3]
    7044:	7100043f 	cmp	w1, #0x1
    7048:	54fffc61 	b.ne	6fd4 <fwp_caps161+0x4>  // b.any
    704c:	17fff555 	b	45a0 <fwp_mem_free>
    7050:	72003c3f 	tst	w1, #0xffff
    7054:	54ffff60 	b.eq	7040 <fwp_caps161+0x70>  // b.none
    7058:	d65f03c0 	ret
    705c:	d503201f 	nop

0000000000007060 <f12>:
    7060:	d104c3ff 	sub	sp, sp, #0x130
    7064:	900000c2 	adrp	x2, 1f000 <fwp_fn_table+0xb30>
    7068:	f947f442 	ldr	x2, [x2, #4072]
    706c:	a90d7bfd 	stp	x29, x30, [sp, #208]
    7070:	910343fd 	add	x29, sp, #0xd0
    7074:	a90f5bf5 	stp	x21, x22, [sp, #240]
    7078:	d0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    707c:	9118c2a3 	add	x3, x21, #0x630
    7080:	a90e53f3 	stp	x19, x20, [sp, #224]
    7084:	b00000d4 	adrp	x20, 20000 <__data_start>
    7088:	91014284 	add	x4, x20, #0x50
    708c:	f949d861 	ldr	x1, [x3, #5040]
    7090:	a91063f7 	stp	x23, x24, [sp, #256]
    7094:	b00000d8 	adrp	x24, 20000 <__data_start>
    7098:	f949ec65 	ldr	x5, [x3, #5080]
    709c:	a9116bf9 	stp	x25, x26, [sp, #272]
    70a0:	91004318 	add	x24, x24, #0x10
    70a4:	a91273fb 	stp	x27, x28, [sp, #288]
    70a8:	91008318 	add	x24, x24, #0x20
    70ac:	910143f7 	add	x23, sp, #0x50
    70b0:	f941c886 	ldr	x6, [x4, #912]
    70b4:	f9400047 	ldr	x7, [x2]
    70b8:	f90067e7 	str	x7, [sp, #200]
    70bc:	d2800007 	mov	x7, #0x0                   	// #0
    70c0:	910123f6 	add	x22, sp, #0x48
    70c4:	f0fffff9 	adrp	x25, 6000 <fwp_owned_entry161+0xa0>
    70c8:	12800007 	mov	w7, #0xffffffff            	// #-1
    70cc:	91210322 	add	x2, x25, #0x840
    70d0:	cb010301 	sub	x1, x24, x1
    70d4:	b9004be7 	str	w7, [sp, #72]
    70d8:	a9050be6 	stp	x6, x2, [sp, #80]
    70dc:	aa0003f3 	mov	x19, x0
    70e0:	f90033f6 	str	x22, [sp, #96]
    70e4:	f901c897 	str	x23, [x4, #912]
    70e8:	eb05403f 	cmp	x1, x5, lsl #16
    70ec:	540003a2 	b.cs	7160 <f12+0x100>  // b.hs, b.nlast
    70f0:	d350fc20 	lsr	x0, x1, #16
    70f4:	f949fc64 	ldr	x4, [x3, #5112]
    70f8:	8b000800 	add	x0, x0, x0, lsl #2
    70fc:	d37df002 	lsl	x2, x0, #3
    7100:	8b020083 	add	x3, x4, x2
    7104:	f9401060 	ldr	x0, [x3, #32]
    7108:	b40002c0 	cbz	x0, 7160 <f12+0x100>
    710c:	38626882 	ldrb	w2, [x4, x2]
    7110:	7100085f 	cmp	w2, #0x2
    7114:	54000c00 	b.eq	7294 <f12+0x234>  // b.none
    7118:	7100045f 	cmp	w2, #0x1
    711c:	54000221 	b.ne	7160 <f12+0x100>  // b.any
    7120:	29430864 	ldp	w4, w2, [x3, #24]
    7124:	92403c21 	and	x1, x1, #0xffff
    7128:	9b047c21 	mul	x1, x1, x4
    712c:	d360fc21 	lsr	x1, x1, #32
    7130:	eb02003f 	cmp	x1, x2
    7134:	54000162 	b.cs	7160 <f12+0x100>  // b.hs, b.nlast
    7138:	8b010000 	add	x0, x0, x1
    713c:	39400001 	ldrb	w1, [x0]
    7140:	34000101 	cbz	w1, 7160 <f12+0x100>
    7144:	91014282 	add	x2, x20, #0x50
    7148:	b9413043 	ldr	w3, [x2, #304]
    714c:	350013a3 	cbnz	w3, 73c0 <f12+0x360>
    7150:	7103f43f 	cmp	w1, #0xfd
    7154:	54002748 	b.hi	763c <f12+0x5dc>  // b.pmore
    7158:	11000421 	add	w1, w1, #0x1
    715c:	39000001 	strb	w1, [x0]
    7160:	aa1803e0 	mov	x0, x24
    7164:	97fffccb 	bl	6490 <fwp_closure_drop>
    7168:	b40001d3 	cbz	x19, 71a0 <f12+0x140>
    716c:	aa1303e0 	mov	x0, x19
    7170:	d2800001 	mov	x1, #0x0                   	// #0
    7174:	d503201f 	nop
    7178:	f9400800 	ldr	x0, [x0, #16]
    717c:	91000421 	add	x1, x1, #0x1
    7180:	b5ffffc0 	cbnz	x0, 7178 <f12+0x118>
    7184:	aa0103f8 	mov	x24, x1
    7188:	b2407be0 	mov	x0, #0x7fffffff            	// #2147483647
    718c:	eb00003f 	cmp	x1, x0
    7190:	540000a9 	b.ls	71a4 <f12+0x144>  // b.plast
    7194:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7198:	911c0000 	add	x0, x0, #0x700
    719c:	97fff446 	bl	42b4 <fwp_trap>
    71a0:	d2800018 	mov	x24, #0x0                   	// #0
    71a4:	9101429a 	add	x26, x20, #0x50
    71a8:	b943c740 	ldr	w0, [x26, #964]
    71ac:	34001340 	cbz	w0, 7414 <f12+0x3b4>
    71b0:	91014280 	add	x0, x20, #0x50
    71b4:	f940901b 	ldr	x27, [x0, #288]
    71b8:	f940b01a 	ldr	x26, [x0, #352]
    71bc:	eb1b035f 	cmp	x26, x27
    71c0:	5400070a 	b.ge	72a0 <f12+0x240>  // b.tcont
    71c4:	f9404401 	ldr	x1, [x0, #136]
    71c8:	8b1a0740 	add	x0, x26, x26, lsl #1
    71cc:	528fffc2 	mov	w2, #0x7ffe                	// #32766
    71d0:	8b000b40 	add	x0, x26, x0, lsl #2
    71d4:	8b000c20 	add	x0, x1, x0, lsl #3
    71d8:	b9400401 	ldr	w1, [x0, #4]
    71dc:	35000081 	cbnz	w1, 71ec <f12+0x18c>
    71e0:	b9400001 	ldr	w1, [x0]
    71e4:	6b02003f 	cmp	w1, w2
    71e8:	540005c9 	b.ls	72a0 <f12+0x240>  // b.plast
    71ec:	9100075a 	add	x26, x26, #0x1
    71f0:	9101a000 	add	x0, x0, #0x68
    71f4:	eb1b035f 	cmp	x26, x27
    71f8:	54ffff01 	b.ne	71d8 <f12+0x178>  // b.any
    71fc:	d29fffc0 	mov	x0, #0xfffe                	// #65534
    7200:	eb00037f 	cmp	x27, x0
    7204:	54001eec 	b.gt	75e0 <f12+0x580>
    7208:	91014280 	add	x0, x20, #0x50
    720c:	f9408801 	ldr	x1, [x0, #272]
    7210:	f940441c 	ldr	x28, [x0, #136]
    7214:	eb1b003f 	cmp	x1, x27
    7218:	54000261 	b.ne	7264 <f12+0x204>  // b.any
    721c:	b40027bb 	cbz	x27, 7710 <f12+0x6b0>
    7220:	d37ffb63 	lsl	x3, x27, #1
    7224:	d29fffe0 	mov	x0, #0xffff                	// #65535
    7228:	eb00007f 	cmp	x3, x0
    722c:	9a80d063 	csel	x3, x3, x0, le
    7230:	8b030461 	add	x1, x3, x3, lsl #1
    7234:	8b010861 	add	x1, x3, x1, lsl #2
    7238:	d37df021 	lsl	x1, x1, #3
    723c:	aa1c03e0 	mov	x0, x28
    7240:	52800002 	mov	w2, #0x0                   	// #0
    7244:	f90007e3 	str	x3, [sp, #8]
    7248:	97fff37f 	bl	4044 <ad_raw_realloc>
    724c:	f94007e3 	ldr	x3, [sp, #8]
    7250:	aa0003fc 	mov	x28, x0
    7254:	b4004760 	cbz	x0, 7b40 <f12+0xae0>
    7258:	91014280 	add	x0, x20, #0x50
    725c:	f900441c 	str	x28, [x0, #136]
    7260:	f9008803 	str	x3, [x0, #272]
    7264:	8b1b0760 	add	x0, x27, x27, lsl #1
    7268:	91014281 	add	x1, x20, #0x50
    726c:	4f000400 	movi	v0.4s, #0x0
    7270:	91000762 	add	x2, x27, #0x1
    7274:	8b000b60 	add	x0, x27, x0, lsl #2
    7278:	f9009022 	str	x2, [x1, #288]
    727c:	8b000f80 	add	x0, x28, x0, lsl #3
    7280:	ad000000 	stp	q0, q0, [x0]
    7284:	ad010000 	stp	q0, q0, [x0, #32]
    7288:	ad020000 	stp	q0, q0, [x0, #64]
    728c:	f900301f 	str	xzr, [x0, #96]
    7290:	14000008 	b	72b0 <f12+0x250>
    7294:	72003c3f 	tst	w1, #0xffff
    7298:	54fff641 	b.ne	7160 <f12+0x100>  // b.any
    729c:	17ffffa8 	b	713c <f12+0xdc>
    72a0:	eb1b035f 	cmp	x26, x27
    72a4:	54fffac0 	b.eq	71fc <f12+0x19c>  // b.none
    72a8:	91014280 	add	x0, x20, #0x50
    72ac:	f940441c 	ldr	x28, [x0, #136]
    72b0:	8b1a075b 	add	x27, x26, x26, lsl #1
    72b4:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    72b8:	910f8000 	add	x0, x0, #0x3e0
    72bc:	8b1b0b5b 	add	x27, x26, x27, lsl #2
    72c0:	8b1b0f9b 	add	x27, x28, x27, lsl #3
    72c4:	f900337f 	str	xzr, [x27, #96]
    72c8:	97ffedb6 	bl	29a0 <getenv@plt>
    72cc:	b4000080 	cbz	x0, 72dc <f12+0x27c>
    72d0:	39400001 	ldrb	w1, [x0]
    72d4:	7100c03f 	cmp	w1, #0x30
    72d8:	540007c0 	b.eq	73d0 <f12+0x370>  // b.none
    72dc:	91014280 	add	x0, x20, #0x50
    72e0:	f9408401 	ldr	x1, [x0, #264]
    72e4:	b50007c1 	cbnz	x1, 73dc <f12+0x37c>
    72e8:	91014282 	add	x2, x20, #0x50
    72ec:	2f000400 	mvni	v0.2s, #0x0
    72f0:	b9400363 	ldr	w3, [x27]
    72f4:	52800020 	mov	w0, #0x1                   	// #1
    72f8:	91000744 	add	x4, x26, #0x1
    72fc:	a900e378 	stp	x24, x24, [x27, #8]
    7300:	0b000063 	add	w3, w3, w0
    7304:	f941c841 	ldr	x1, [x2, #912]
    7308:	29000363 	stp	w3, w0, [x27]
    730c:	f9002b7f 	str	xzr, [x27, #80]
    7310:	f900b044 	str	x4, [x2, #352]
    7314:	fd002f60 	str	d0, [x27, #88]
    7318:	b4001581 	cbz	x1, 75c8 <f12+0x568>
    731c:	91210339 	add	x25, x25, #0x840
    7320:	14000003 	b	732c <f12+0x2cc>
    7324:	f9400021 	ldr	x1, [x1]
    7328:	b4001501 	cbz	x1, 75c8 <f12+0x568>
    732c:	f9400422 	ldr	x2, [x1, #8]
    7330:	eb19005f 	cmp	x2, x25
    7334:	54ffff81 	b.ne	7324 <f12+0x2c4>  // b.any
    7338:	f9400820 	ldr	x0, [x1, #16]
    733c:	2a1a03e2 	mov	w2, w26
    7340:	b9400001 	ldr	w1, [x0]
    7344:	f9002b60 	str	x0, [x27, #80]
    7348:	b9005f61 	str	w1, [x27, #92]
    734c:	37f80081 	tbnz	w1, #31, 735c <f12+0x2fc>
    7350:	52800d05 	mov	w5, #0x68                  	// #104
    7354:	9b257021 	smaddl	x1, w1, w5, x28
    7358:	b900583a 	str	w26, [x1, #88]
    735c:	b9000002 	str	w2, [x0]
    7360:	aa1303e0 	mov	x0, x19
    7364:	d2800002 	mov	x2, #0x0                   	// #0
    7368:	b4000653 	cbz	x19, 7430 <f12+0x3d0>
    736c:	d503201f 	nop
    7370:	f9400800 	ldr	x0, [x0, #16]
    7374:	91000442 	add	x2, x2, #0x1
    7378:	b5ffffc0 	cbnz	x0, 7370 <f12+0x310>
    737c:	aa1303e1 	mov	x1, x19
    7380:	f9400821 	ldr	x1, [x1, #16]
    7384:	91000400 	add	x0, x0, #0x1
    7388:	b5ffffc1 	cbnz	x1, 7380 <f12+0x320>
    738c:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7390:	eb01001f 	cmp	x0, x1
    7394:	54000108 	b.hi	73b4 <f12+0x354>  // b.pmore
    7398:	f100005f 	cmp	x2, #0x0
    739c:	540004ad 	b.le	7430 <f12+0x3d0>
    73a0:	eb00005f 	cmp	x2, x0
    73a4:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    73a8:	9a809059 	csel	x25, x2, x0, ls	// ls = plast
    73ac:	eb01033f 	cmp	x25, x1
    73b0:	540011e9 	b.ls	75ec <f12+0x58c>  // b.plast
    73b4:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    73b8:	911e0000 	add	x0, x0, #0x780
    73bc:	97fff3be 	bl	42b4 <fwp_trap>
    73c0:	f940ac43 	ldr	x3, [x2, #344]
    73c4:	91000463 	add	x3, x3, #0x1
    73c8:	f900ac43 	str	x3, [x2, #344]
    73cc:	17ffff61 	b	7150 <f12+0xf0>
    73d0:	39400400 	ldrb	w0, [x0, #1]
    73d4:	34fff8a0 	cbz	w0, 72e8 <f12+0x288>
    73d8:	17ffffc1 	b	72dc <f12+0x27c>
    73dc:	ad468402 	ldp	q2, q1, [x0, #208]
    73e0:	91034001 	add	x1, x0, #0xd0
    73e4:	4f000400 	movi	v0.4s, #0x0
    73e8:	f900841f 	str	xzr, [x0, #264]
    73ec:	ad010762 	stp	q2, q1, [x27, #32]
    73f0:	a94f0002 	ldp	x2, x0, [x0, #240]
    73f4:	f9000f60 	str	x0, [x27, #24]
    73f8:	f9401820 	ldr	x0, [x1, #48]
    73fc:	f9002362 	str	x2, [x27, #64]
    7400:	f9002760 	str	x0, [x27, #72]
    7404:	ad000020 	stp	q0, q0, [x1]
    7408:	3d800820 	str	q0, [x1, #32]
    740c:	f900183f 	str	xzr, [x1, #48]
    7410:	17ffffb6 	b	72e8 <f12+0x288>
    7414:	f0ffffe0 	adrp	x0, 6000 <fwp_owned_entry161+0xa0>
    7418:	911cc000 	add	x0, x0, #0x730
    741c:	94000f2d 	bl	b0d0 <atexit>
    7420:	35003900 	cbnz	w0, 7b40 <f12+0xae0>
    7424:	52800020 	mov	w0, #0x1                   	// #1
    7428:	b903c740 	str	w0, [x26, #964]
    742c:	17ffff61 	b	71b0 <f12+0x150>
    7430:	d3707c63 	ubfiz	x3, x3, #16, #32
    7434:	52800041 	mov	w1, #0x2                   	// #2
    7438:	aa040078 	orr	x24, x3, x4
    743c:	d2800100 	mov	x0, #0x8                   	// #8
    7440:	97fff714 	bl	5090 <fwp_heap_alloc>
    7444:	aa0003fa 	mov	x26, x0
    7448:	9118c2a0 	add	x0, x21, #0x630
    744c:	f900035f 	str	xzr, [x26]
    7450:	f949d801 	ldr	x1, [x0, #5040]
    7454:	f949ec00 	ldr	x0, [x0, #5080]
    7458:	cb010341 	sub	x1, x26, x1
    745c:	eb00403f 	cmp	x1, x0, lsl #16
    7460:	54000e82 	b.cs	7630 <f12+0x5d0>  // b.hs, b.nlast
    7464:	d2800019 	mov	x25, #0x0                   	// #0
    7468:	9118c2a2 	add	x2, x21, #0x630
    746c:	d350fc20 	lsr	x0, x1, #16
    7470:	8b000800 	add	x0, x0, x0, lsl #2
    7474:	f949fc43 	ldr	x3, [x2, #5112]
    7478:	d37df002 	lsl	x2, x0, #3
    747c:	8b020060 	add	x0, x3, x2
    7480:	f940101b 	ldr	x27, [x0, #32]
    7484:	b400025b 	cbz	x27, 74cc <f12+0x46c>
    7488:	38626862 	ldrb	w2, [x3, x2]
    748c:	7100085f 	cmp	w2, #0x2
    7490:	54000a20 	b.eq	75d4 <f12+0x574>  // b.none
    7494:	7100045f 	cmp	w2, #0x1
    7498:	540001a1 	b.ne	74cc <f12+0x46c>  // b.any
    749c:	29430002 	ldp	w2, w0, [x0, #24]
    74a0:	92403c21 	and	x1, x1, #0xffff
    74a4:	9b027c21 	mul	x1, x1, x2
    74a8:	d360fc21 	lsr	x1, x1, #32
    74ac:	eb00003f 	cmp	x1, x0
    74b0:	540000e2 	b.cs	74cc <f12+0x46c>  // b.hs, b.nlast
    74b4:	8b01037b 	add	x27, x27, x1
    74b8:	39400360 	ldrb	w0, [x27]
    74bc:	7103fc1f 	cmp	w0, #0xff
    74c0:	54003220 	b.eq	7b04 <f12+0xaa4>  // b.none
    74c4:	52800020 	mov	w0, #0x1                   	// #1
    74c8:	39000360 	strb	w0, [x27]
    74cc:	b4000239 	cbz	x25, 7510 <f12+0x4b0>
    74d0:	d3607f04 	lsl	x4, x24, #32
    74d4:	aa1303e0 	mov	x0, x19
    74d8:	f9400665 	ldr	x5, [x19, #8]
    74dc:	aa0403e3 	mov	x3, x4
    74e0:	91002342 	add	x2, x26, #0x8
    74e4:	d2800001 	mov	x1, #0x0                   	// #0
    74e8:	14000005 	b	74fc <f12+0x49c>
    74ec:	f9400405 	ldr	x5, [x0, #8]
    74f0:	ab040023 	adds	x3, x1, x4
    74f4:	91004042 	add	x2, x2, #0x10
    74f8:	54005da6 	b.vs	80ac <f12+0x104c>
    74fc:	a9000c45 	stp	x5, x3, [x2]
    7500:	91000421 	add	x1, x1, #0x1
    7504:	f9400800 	ldr	x0, [x0, #16]
    7508:	eb19003f 	cmp	x1, x25
    750c:	54ffff03 	b.cc	74ec <f12+0x48c>  // b.lo, b.ul, b.last
    7510:	f9400340 	ldr	x0, [x26]
    7514:	f100041f 	cmp	x0, #0x1
    7518:	540008c9 	b.ls	7630 <f12+0x5d0>  // b.plast
    751c:	d341fc00 	lsr	x0, x0, #1
    7520:	92fe0001 	mov	x1, #0xfffffffffffffff     	// #1152921504606846975
    7524:	d100041c 	sub	x28, x0, #0x1
    7528:	eb01039f 	cmp	x28, x1
    752c:	54fff448 	b.hi	73b4 <f12+0x354>  // b.pmore
    7530:	b400081c 	cbz	x28, 7630 <f12+0x5d0>
    7534:	d1002341 	sub	x1, x26, #0x8
    7538:	91002359 	add	x25, x26, #0x8
    753c:	8b00103b 	add	x27, x1, x0, lsl #4
    7540:	f9400720 	ldr	x0, [x25, #8]
    7544:	f9400f21 	ldr	x1, [x25, #24]
    7548:	fd400320 	ldr	d0, [x25]
    754c:	fd400b21 	ldr	d1, [x25, #16]
    7550:	97fff89d 	bl	57c4 <w107>
    7554:	a9000720 	stp	x0, x1, [x25]
    7558:	91004339 	add	x25, x25, #0x10
    755c:	eb1b033f 	cmp	x25, x27
    7560:	54ffff01 	b.ne	7540 <f12+0x4e0>  // b.any
    7564:	aa1a03fb 	mov	x27, x26
    7568:	d37ffb99 	lsl	x25, x28, #1
    756c:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7570:	d280001c 	mov	x28, #0x0                   	// #0
    7574:	f8010779 	str	x25, [x27], #16
    7578:	f87c7b61 	ldr	x1, [x27, x28, lsl #3]
    757c:	aa0403e0 	mov	x0, x4
    7580:	91000b9c 	add	x28, x28, #0x2
    7584:	97fff83f 	bl	5680 <f128.constprop.0>
    7588:	aa0003e4 	mov	x4, x0
    758c:	eb19039f 	cmp	x28, x25
    7590:	54ffff43 	b.cc	7578 <f12+0x518>  // b.lo, b.ul, b.last
    7594:	aa1a03e0 	mov	x0, x26
    7598:	93407f18 	sxtw	x24, w24
    759c:	f90007e4 	str	x4, [sp, #8]
    75a0:	97fffe08 	bl	6dc0 <fwp_drop4>
    75a4:	aa1803e0 	mov	x0, x24
    75a8:	97fff546 	bl	4ac0 <fwp_tape_of>
    75ac:	f9403019 	ldr	x25, [x0, #96]
    75b0:	aa0003e5 	mov	x5, x0
    75b4:	f94007e4 	ldr	x4, [sp, #8]
    75b8:	b4000479 	cbz	x25, 7644 <f12+0x5e4>
    75bc:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    75c0:	9119c000 	add	x0, x0, #0x670
    75c4:	97fff33c 	bl	42b4 <fwp_trap>
    75c8:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    75cc:	911d4000 	add	x0, x0, #0x750
    75d0:	97fff339 	bl	42b4 <fwp_trap>
    75d4:	72003c3f 	tst	w1, #0xffff
    75d8:	54fff7a1 	b.ne	74cc <f12+0x46c>  // b.any
    75dc:	17ffffb7 	b	74b8 <f12+0x458>
    75e0:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    75e4:	911c8000 	add	x0, x0, #0x720
    75e8:	97fff333 	bl	42b4 <fwp_trap>
    75ec:	d37ffb3b 	lsl	x27, x25, #1
    75f0:	d3707c63 	ubfiz	x3, x3, #16, #32
    75f4:	91000760 	add	x0, x27, #0x1
    75f8:	52800041 	mov	w1, #0x2                   	// #2
    75fc:	aa040078 	orr	x24, x3, x4
    7600:	d37df000 	lsl	x0, x0, #3
    7604:	97fff6a3 	bl	5090 <fwp_heap_alloc>
    7608:	aa0003fa 	mov	x26, x0
    760c:	9118c2a1 	add	x1, x21, #0x630
    7610:	aa0103e0 	mov	x0, x1
    7614:	f900035b 	str	x27, [x26]
    7618:	f949d821 	ldr	x1, [x1, #5040]
    761c:	f949ec00 	ldr	x0, [x0, #5080]
    7620:	cb010341 	sub	x1, x26, x1
    7624:	eb00403f 	cmp	x1, x0, lsl #16
    7628:	54fff203 	b.cc	7468 <f12+0x408>  // b.lo, b.ul, b.last
    762c:	b5fff539 	cbnz	x25, 74d0 <f12+0x470>
    7630:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    7634:	f900035f 	str	xzr, [x26]
    7638:	17ffffd7 	b	7594 <f12+0x534>
    763c:	97fff452 	bl	4784 <fwp_rc_wide_dup>
    7640:	17fffec8 	b	7160 <f12+0x100>
    7644:	f9000fe4 	str	x4, [sp, #24]
    7648:	97ffee53 	bl	2f94 <fwp_tape_unlink_scope>
    764c:	a9428cba 	ldp	x26, x3, [x5, #40]
    7650:	f90007e3 	str	x3, [sp, #8]
    7654:	f9401ca3 	ldr	x3, [x5, #56]
    7658:	b90004bf 	str	wzr, [x5, #4]
    765c:	b94000a1 	ldr	w1, [x5]
    7660:	528fffc0 	mov	w0, #0x7ffe                	// #32766
    7664:	f9000be3 	str	x3, [sp, #16]
    7668:	a940a4bc 	ldp	x28, x9, [x5, #8]
    766c:	6b00003f 	cmp	w1, w0
    7670:	a941e4a2 	ldp	x2, x25, [x5, #24]
    7674:	f9400fe4 	ldr	x4, [sp, #24]
    7678:	a94418bb 	ldp	x27, x6, [x5, #64]
    767c:	54000108 	b.hi	769c <f12+0x63c>  // b.pmore
    7680:	91014281 	add	x1, x20, #0x50
    7684:	92403f00 	and	x0, x24, #0xffff
    7688:	d1000400 	sub	x0, x0, #0x1
    768c:	f940b023 	ldr	x3, [x1, #352]
    7690:	eb03001f 	cmp	x0, x3
    7694:	5400004a 	b.ge	769c <f12+0x63c>  // b.tcont
    7698:	f900b020 	str	x0, [x1, #352]
    769c:	4f000400 	movi	v0.4s, #0x0
    76a0:	91014281 	add	x1, x20, #0x50
    76a4:	b0ffffe0 	adrp	x0, 4000 <fwp_tape_buffers_dispose+0xc>
    76a8:	91045000 	add	x0, x0, #0x114
    76ac:	f9000cbf 	str	xzr, [x5, #24]
    76b0:	9101a3e7 	add	x7, sp, #0x68
    76b4:	f941c823 	ldr	x3, [x1, #912]
    76b8:	3c8080a0 	stur	q0, [x5, #8]
    76bc:	a90683e3 	stp	x3, x0, [sp, #104]
    76c0:	910203e3 	add	x3, sp, #0x80
    76c4:	f94007e0 	ldr	x0, [sp, #8]
    76c8:	ad0100a0 	stp	q0, q0, [x5, #32]
    76cc:	f9004be0 	str	x0, [sp, #144]
    76d0:	f9400be0 	ldr	x0, [sp, #16]
    76d4:	f9000fe3 	str	x3, [sp, #24]
    76d8:	f90013e7 	str	x7, [sp, #32]
    76dc:	a9047cbf 	stp	xzr, xzr, [x5, #64]
    76e0:	f9003fe3 	str	x3, [sp, #120]
    76e4:	a9086bf9 	stp	x25, x26, [sp, #128]
    76e8:	f9004fe0 	str	x0, [sp, #152]
    76ec:	a90a0bfb 	stp	x27, x2, [sp, #160]
    76f0:	f9005be6 	str	x6, [sp, #176]
    76f4:	f901c827 	str	x7, [x1, #912]
    76f8:	b7f82024 	tbnz	x4, #63, 7afc <f12+0xa9c>
    76fc:	eb84831f 	cmp	x24, x4, asr #32
    7700:	540000e0 	b.eq	771c <f12+0x6bc>  // b.none
    7704:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7708:	9118a000 	add	x0, x0, #0x628
    770c:	97fff2ea 	bl	42b4 <fwp_trap>
    7710:	d2800d01 	mov	x1, #0x68                  	// #104
    7714:	d2800023 	mov	x3, #0x1                   	// #1
    7718:	17fffec9 	b	723c <f12+0x1dc>
    771c:	92407c80 	and	x0, x4, #0xffffffff
    7720:	eb00039f 	cmp	x28, x0
    7724:	9a80c798 	csinc	x24, x28, x0, gt
    7728:	eb24413f 	cmp	x9, w4, uxtw
    772c:	54001f2d 	b.le	7b10 <f12+0xab0>
    7730:	eb1800df 	cmp	x6, x24
    7734:	54001f6a 	b.ge	7b20 <f12+0xac0>  // b.tcont
    7738:	f10000df 	cmp	x6, #0x0
    773c:	b24077e1 	mov	x1, #0x3fffffff            	// #1073741823
    7740:	9a9810c6 	csel	x6, x6, x24, ne	// ne = any
    7744:	14000004 	b	7754 <f12+0x6f4>
    7748:	eb0100df 	cmp	x6, x1
    774c:	d37ff8c6 	lsl	x6, x6, #1
    7750:	9a98d0c6 	csel	x6, x6, x24, le
    7754:	eb1800df 	cmp	x6, x24
    7758:	54ffff8b 	b.lt	7748 <f12+0x6e8>  // b.tstop
    775c:	b400365b 	cbz	x27, 7e24 <f12+0xdc4>
    7760:	aa1b03e0 	mov	x0, x27
    7764:	d37df0c1 	lsl	x1, x6, #3
    7768:	52800062 	mov	w2, #0x3                   	// #3
    776c:	a90293e6 	stp	x6, x4, [sp, #40]
    7770:	97fff235 	bl	4044 <ad_raw_realloc>
    7774:	a94293e6 	ldp	x6, x4, [sp, #40]
    7778:	aa0003fb 	mov	x27, x0
    777c:	b4001d00 	cbz	x0, 7b1c <f12+0xabc>
    7780:	f90053fb 	str	x27, [sp, #160]
    7784:	f9005be6 	str	x6, [sp, #176]
    7788:	b5001ad8 	cbnz	x24, 7ae0 <f12+0xa80>
    778c:	b7f800c4 	tbnz	x4, #63, 77a4 <f12+0x744>
    7790:	92407c84 	and	x4, x4, #0xffffffff
    7794:	1e6e1001 	fmov	d1, #1.000000000000000000e+00
    7798:	fc647b60 	ldr	d0, [x27, x4, lsl #3]
    779c:	1e612800 	fadd	d0, d0, d1
    77a0:	fc247b60 	str	d0, [x27, x4, lsl #3]
    77a4:	d1000700 	sub	x0, x24, #0x1
    77a8:	d1000783 	sub	x3, x28, #0x1
    77ac:	eb00039f 	cmp	x28, x0
    77b0:	540003ec 	b.gt	782c <f12+0x7cc>
    77b4:	fc607b60 	ldr	d0, [x27, x0, lsl #3]
    77b8:	1e602008 	fcmp	d0, #0.0
    77bc:	54000320 	b.eq	7820 <f12+0x7c0>  // b.none
    77c0:	cb1c0be1 	neg	x1, x28, lsl #2
    77c4:	cb1c03e4 	neg	x4, x28
    77c8:	8b010322 	add	x2, x25, x1
    77cc:	b8607842 	ldr	w2, [x2, x0, lsl #2]
    77d0:	37f80122 	tbnz	w2, #31, 77f4 <f12+0x794>
    77d4:	f94007e5 	ldr	x5, [sp, #8]
    77d8:	93407c42 	sxtw	x2, w2
    77dc:	8b040ca5 	add	x5, x5, x4, lsl #3
    77e0:	fc627b61 	ldr	d1, [x27, x2, lsl #3]
    77e4:	fc6078a2 	ldr	d2, [x5, x0, lsl #3]
    77e8:	1e620802 	fmul	d2, d0, d2
    77ec:	1e622821 	fadd	d1, d1, d2
    77f0:	fc227b61 	str	d1, [x27, x2, lsl #3]
    77f4:	8b010341 	add	x1, x26, x1
    77f8:	b8607821 	ldr	w1, [x1, x0, lsl #2]
    77fc:	37f80121 	tbnz	w1, #31, 7820 <f12+0x7c0>
    7800:	f9400be2 	ldr	x2, [sp, #16]
    7804:	93407c21 	sxtw	x1, w1
    7808:	8b040c44 	add	x4, x2, x4, lsl #3
    780c:	fc617b61 	ldr	d1, [x27, x1, lsl #3]
    7810:	fc607882 	ldr	d2, [x4, x0, lsl #3]
    7814:	1e620800 	fmul	d0, d0, d2
    7818:	1e602820 	fadd	d0, d1, d0
    781c:	fc217b60 	str	d0, [x27, x1, lsl #3]
    7820:	d1000400 	sub	x0, x0, #0x1
    7824:	eb00007f 	cmp	x3, x0
    7828:	54fffc61 	b.ne	77b4 <f12+0x754>  // b.any
    782c:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7830:	eb00039f 	cmp	x28, x0
    7834:	540019e8 	b.hi	7b70 <f12+0xb10>  // b.pmore
    7838:	91000780 	add	x0, x28, #0x1
    783c:	52800041 	mov	w1, #0x2                   	// #2
    7840:	d37df000 	lsl	x0, x0, #3
    7844:	97fff613 	bl	5090 <fwp_heap_alloc>
    7848:	aa0003f8 	mov	x24, x0
    784c:	f800841c 	str	x28, [x0], #8
    7850:	d2800001 	mov	x1, #0x0                   	// #0
    7854:	b40000dc 	cbz	x28, 786c <f12+0x80c>
    7858:	f8617b62 	ldr	x2, [x27, x1, lsl #3]
    785c:	f8217802 	str	x2, [x0, x1, lsl #3]
    7860:	91000421 	add	x1, x1, #0x1
    7864:	eb01039f 	cmp	x28, x1
    7868:	54ffff81 	b.ne	7858 <f12+0x7f8>  // b.any
    786c:	91014281 	add	x1, x20, #0x50
    7870:	f94013e2 	ldr	x2, [sp, #32]
    7874:	f941c820 	ldr	x0, [x1, #912]
    7878:	eb02001f 	cmp	x0, x2
    787c:	540041a1 	b.ne	80b0 <f12+0x1050>  // b.any
    7880:	f9400fe0 	ldr	x0, [sp, #24]
    7884:	f94037fa 	ldr	x26, [sp, #104]
    7888:	f901c83a 	str	x26, [x1, #912]
    788c:	97fff222 	bl	4114 <fwp_tape_buffers_release>
    7890:	9118c2a2 	add	x2, x21, #0x630
    7894:	f949d841 	ldr	x1, [x2, #5040]
    7898:	f949ec40 	ldr	x0, [x2, #5080]
    789c:	cb010301 	sub	x1, x24, x1
    78a0:	eb00403f 	cmp	x1, x0, lsl #16
    78a4:	54000322 	b.cs	7908 <f12+0x8a8>  // b.hs, b.nlast
    78a8:	d350fc20 	lsr	x0, x1, #16
    78ac:	f949fc43 	ldr	x3, [x2, #5112]
    78b0:	8b000800 	add	x0, x0, x0, lsl #2
    78b4:	d37df002 	lsl	x2, x0, #3
    78b8:	8b020060 	add	x0, x3, x2
    78bc:	f9401019 	ldr	x25, [x0, #32]
    78c0:	b4000259 	cbz	x25, 7908 <f12+0x8a8>
    78c4:	38626862 	ldrb	w2, [x3, x2]
    78c8:	7100085f 	cmp	w2, #0x2
    78cc:	54002a00 	b.eq	7e0c <f12+0xdac>  // b.none
    78d0:	7100045f 	cmp	w2, #0x1
    78d4:	540001a1 	b.ne	7908 <f12+0x8a8>  // b.any
    78d8:	29430002 	ldp	w2, w0, [x0, #24]
    78dc:	92403c21 	and	x1, x1, #0xffff
    78e0:	9b027c21 	mul	x1, x1, x2
    78e4:	d360fc21 	lsr	x1, x1, #32
    78e8:	eb00003f 	cmp	x1, x0
    78ec:	540000e2 	b.cs	7908 <f12+0x8a8>  // b.hs, b.nlast
    78f0:	8b010339 	add	x25, x25, x1
    78f4:	39400320 	ldrb	w0, [x25]
    78f8:	7103fc1f 	cmp	w0, #0xff
    78fc:	54003a80 	b.eq	804c <f12+0xfec>  // b.none
    7900:	52800020 	mov	w0, #0x1                   	// #1
    7904:	39000320 	strb	w0, [x25]
    7908:	eb17035f 	cmp	x26, x23
    790c:	54003d21 	b.ne	80b0 <f12+0x1050>  // b.any
    7910:	f9402be1 	ldr	x1, [sp, #80]
    7914:	91014294 	add	x20, x20, #0x50
    7918:	aa1603e0 	mov	x0, x22
    791c:	f901ca81 	str	x1, [x20, #912]
    7920:	97fffbc8 	bl	6840 <fwp_tape_scope_release>
    7924:	f9400300 	ldr	x0, [x24]
    7928:	9240f819 	and	x25, x0, #0x7fffffffffffffff
    792c:	b7f81360 	tbnz	x0, #63, 7b98 <f12+0xb38>
    7930:	9118c2a2 	add	x2, x21, #0x630
    7934:	f949d840 	ldr	x0, [x2, #5040]
    7938:	f949ec41 	ldr	x1, [x2, #5080]
    793c:	cb000300 	sub	x0, x24, x0
    7940:	eb01401f 	cmp	x0, x1, lsl #16
    7944:	540012a2 	b.cs	7b98 <f12+0xb38>  // b.hs, b.nlast
    7948:	d350fc01 	lsr	x1, x0, #16
    794c:	f949fc44 	ldr	x4, [x2, #5112]
    7950:	8b010821 	add	x1, x1, x1, lsl #2
    7954:	d37df021 	lsl	x1, x1, #3
    7958:	8b010083 	add	x3, x4, x1
    795c:	f9401062 	ldr	x2, [x3, #32]
    7960:	b40011c2 	cbz	x2, 7b98 <f12+0xb38>
    7964:	38616881 	ldrb	w1, [x4, x1]
    7968:	7100083f 	cmp	w1, #0x2
    796c:	54001120 	b.eq	7b90 <f12+0xb30>  // b.none
    7970:	7100043f 	cmp	w1, #0x1
    7974:	54001121 	b.ne	7b98 <f12+0xb38>  // b.any
    7978:	29430464 	ldp	w4, w1, [x3, #24]
    797c:	92403c00 	and	x0, x0, #0xffff
    7980:	9b047c00 	mul	x0, x0, x4
    7984:	d360fc00 	lsr	x0, x0, #32
    7988:	eb01001f 	cmp	x0, x1
    798c:	54001062 	b.cs	7b98 <f12+0xb38>  // b.hs, b.nlast
    7990:	8b000042 	add	x2, x2, x0
    7994:	39400040 	ldrb	w0, [x2]
    7998:	7100041f 	cmp	w0, #0x1
    799c:	54000fe1 	b.ne	7b98 <f12+0xb38>  // b.any
    79a0:	aa1803f7 	mov	x23, x24
    79a4:	aa1803f6 	mov	x22, x24
    79a8:	d2800000 	mov	x0, #0x0                   	// #0
    79ac:	910022c2 	add	x2, x22, #0x8
    79b0:	d2800001 	mov	x1, #0x0                   	// #0
    79b4:	b40001f9 	cbz	x25, 79f0 <f12+0x990>
    79b8:	b0000023 	adrp	x3, c000 <_IO_stdin_used+0xf00>
    79bc:	91002304 	add	x4, x24, #0x8
    79c0:	fd406861 	ldr	d1, [x3, #208]
    79c4:	f9400305 	ldr	x5, [x24]
    79c8:	aa0403e3 	mov	x3, x4
    79cc:	b7f80de5 	tbnz	x5, #63, 7b88 <f12+0xb28>
    79d0:	f94002e5 	ldr	x5, [x23]
    79d4:	fc617860 	ldr	d0, [x3, x1, lsl #3]
    79d8:	b7f80d25 	tbnz	x5, #63, 7b7c <f12+0xb1c>
    79dc:	1e600820 	fmul	d0, d1, d0
    79e0:	91000421 	add	x1, x1, #0x1
    79e4:	fc008440 	str	d0, [x2], #8
    79e8:	eb01033f 	cmp	x25, x1
    79ec:	54fffec1 	b.ne	79c4 <f12+0x964>  // b.any
    79f0:	97fffcf4 	bl	6dc0 <fwp_drop4>
    79f4:	b4002a53 	cbz	x19, 7f3c <f12+0xedc>
    79f8:	aa1303e0 	mov	x0, x19
    79fc:	d2800014 	mov	x20, #0x0                   	// #0
    7a00:	f9400800 	ldr	x0, [x0, #16]
    7a04:	91000694 	add	x20, x20, #0x1
    7a08:	b5ffffc0 	cbnz	x0, 7a00 <f12+0x9a0>
    7a0c:	f94002e0 	ldr	x0, [x23]
    7a10:	9240f818 	and	x24, x0, #0x7fffffffffffffff
    7a14:	b7f811c0 	tbnz	x0, #63, 7c4c <f12+0xbec>
    7a18:	9118c2a1 	add	x1, x21, #0x630
    7a1c:	f949d820 	ldr	x0, [x1, #5040]
    7a20:	f949ec22 	ldr	x2, [x1, #5080]
    7a24:	cb0002c0 	sub	x0, x22, x0
    7a28:	eb02401f 	cmp	x0, x2, lsl #16
    7a2c:	540010e2 	b.cs	7c48 <f12+0xbe8>  // b.hs, b.nlast
    7a30:	d350fc02 	lsr	x2, x0, #16
    7a34:	d2800503 	mov	x3, #0x28                  	// #40
    7a38:	f949fc24 	ldr	x4, [x1, #5112]
    7a3c:	9b037c42 	mul	x2, x2, x3
    7a40:	8b020083 	add	x3, x4, x2
    7a44:	f9401061 	ldr	x1, [x3, #32]
    7a48:	b4001001 	cbz	x1, 7c48 <f12+0xbe8>
    7a4c:	38626882 	ldrb	w2, [x4, x2]
    7a50:	7100085f 	cmp	w2, #0x2
    7a54:	54000f60 	b.eq	7c40 <f12+0xbe0>  // b.none
    7a58:	7100045f 	cmp	w2, #0x1
    7a5c:	54000f61 	b.ne	7c48 <f12+0xbe8>  // b.any
    7a60:	29430864 	ldp	w4, w2, [x3, #24]
    7a64:	92403c00 	and	x0, x0, #0xffff
    7a68:	9b047c00 	mul	x0, x0, x4
    7a6c:	d360fc00 	lsr	x0, x0, #32
    7a70:	eb02001f 	cmp	x0, x2
    7a74:	54000ea2 	b.cs	7c48 <f12+0xbe8>  // b.hs, b.nlast
    7a78:	8b000021 	add	x1, x1, x0
    7a7c:	3940003c 	ldrb	w28, [x1]
    7a80:	7100079f 	cmp	w28, #0x1
    7a84:	54000e21 	b.ne	7c48 <f12+0xbe8>  // b.any
    7a88:	910022f9 	add	x25, x23, #0x8
    7a8c:	eb14031f 	cmp	x24, x20
    7a90:	9a949318 	csel	x24, x24, x20, ls	// ls = plast
    7a94:	b4002218 	cbz	x24, 7ed4 <f12+0xe74>
    7a98:	d37df304 	lsl	x4, x24, #3
    7a9c:	aa1303e1 	mov	x1, x19
    7aa0:	910022c3 	add	x3, x22, #0x8
    7aa4:	d2800000 	mov	x0, #0x0                   	// #0
    7aa8:	14000009 	b	7acc <f12+0xa6c>
    7aac:	fc606841 	ldr	d1, [x2, x0]
    7ab0:	fd400420 	ldr	d0, [x1, #8]
    7ab4:	1e613800 	fsub	d0, d0, d1
    7ab8:	fc206b20 	str	d0, [x25, x0]
    7abc:	91002000 	add	x0, x0, #0x8
    7ac0:	f9400821 	ldr	x1, [x1, #16]
    7ac4:	eb00009f 	cmp	x4, x0
    7ac8:	54000ee0 	b.eq	7ca4 <f12+0xc44>  // b.none
    7acc:	f94002e5 	ldr	x5, [x23]
    7ad0:	aa0303e2 	mov	x2, x3
    7ad4:	b6fffec5 	tbz	x5, #63, 7aac <f12+0xa4c>
    7ad8:	f9400ac2 	ldr	x2, [x22, #16]
    7adc:	17fffff4 	b	7aac <f12+0xa4c>
    7ae0:	d37df302 	lsl	x2, x24, #3
    7ae4:	aa1b03e0 	mov	x0, x27
    7ae8:	52800001 	mov	w1, #0x0                   	// #0
    7aec:	f90017e4 	str	x4, [sp, #40]
    7af0:	97ffeb3c 	bl	27e0 <memset@plt>
    7af4:	f94017e4 	ldr	x4, [sp, #40]
    7af8:	17ffff25 	b	778c <f12+0x72c>
    7afc:	aa1c03f8 	mov	x24, x28
    7b00:	17ffff0c 	b	7730 <f12+0x6d0>
    7b04:	aa1b03e0 	mov	x0, x27
    7b08:	97fff20b 	bl	4334 <fwp_rc_forget_slot.part.0>
    7b0c:	17fffe6e 	b	74c4 <f12+0x464>
    7b10:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7b14:	911a8000 	add	x0, x0, #0x6a0
    7b18:	97fff1e7 	bl	42b4 <fwp_trap>
    7b1c:	d280001b 	mov	x27, #0x0                   	// #0
    7b20:	f100031f 	cmp	x24, #0x0
    7b24:	fa401b60 	ccmp	x27, #0x0, #0x0, ne	// ne = any
    7b28:	54ffe301 	b.ne	7788 <f12+0x728>  // b.any
    7b2c:	f9400fe0 	ldr	x0, [sp, #24]
    7b30:	91014294 	add	x20, x20, #0x50
    7b34:	f94037e1 	ldr	x1, [sp, #104]
    7b38:	f901ca81 	str	x1, [x20, #912]
    7b3c:	97fff176 	bl	4114 <fwp_tape_buffers_release>
    7b40:	900000c3 	adrp	x3, 1f000 <fwp_fn_table+0xb30>
    7b44:	f947e863 	ldr	x3, [x3, #4048]
    7b48:	d2800262 	mov	x2, #0x13                  	// #19
    7b4c:	d2800021 	mov	x1, #0x1                   	// #1
    7b50:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7b54:	91042000 	add	x0, x0, #0x108
    7b58:	f9400063 	ldr	x3, [x3]
    7b5c:	97ffeb6d 	bl	2910 <fwrite@plt>
    7b60:	d2800000 	mov	x0, #0x0                   	// #0
    7b64:	97ffeb77 	bl	2940 <fflush@plt>
    7b68:	52800cc0 	mov	w0, #0x66                  	// #102
    7b6c:	97ffeb85 	bl	2980 <_Exit@plt>
    7b70:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7b74:	911ec000 	add	x0, x0, #0x7b0
    7b78:	97fff1cf 	bl	42b4 <fwp_trap>
    7b7c:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7b80:	911f0000 	add	x0, x0, #0x7c0
    7b84:	97fff1cc 	bl	42b4 <fwp_trap>
    7b88:	f9400b03 	ldr	x3, [x24, #16]
    7b8c:	17ffff91 	b	79d0 <f12+0x970>
    7b90:	72003c1f 	tst	w0, #0xffff
    7b94:	54fff000 	b.eq	7994 <f12+0x934>  // b.none
    7b98:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7b9c:	eb00033f 	cmp	x25, x0
    7ba0:	54fffe88 	b.hi	7b70 <f12+0xb10>  // b.pmore
    7ba4:	91000720 	add	x0, x25, #0x1
    7ba8:	52800021 	mov	w1, #0x1                   	// #1
    7bac:	d37df000 	lsl	x0, x0, #3
    7bb0:	97fff538 	bl	5090 <fwp_heap_alloc>
    7bb4:	9118c2a2 	add	x2, x21, #0x630
    7bb8:	f9000019 	str	x25, [x0]
    7bbc:	aa0003f7 	mov	x23, x0
    7bc0:	aa0003f6 	mov	x22, x0
    7bc4:	f949d841 	ldr	x1, [x2, #5040]
    7bc8:	f949ec40 	ldr	x0, [x2, #5080]
    7bcc:	cb0102e1 	sub	x1, x23, x1
    7bd0:	eb00403f 	cmp	x1, x0, lsl #16
    7bd4:	54000322 	b.cs	7c38 <f12+0xbd8>  // b.hs, b.nlast
    7bd8:	d350fc20 	lsr	x0, x1, #16
    7bdc:	d2800504 	mov	x4, #0x28                  	// #40
    7be0:	f949fc43 	ldr	x3, [x2, #5112]
    7be4:	9b047c00 	mul	x0, x0, x4
    7be8:	8b000062 	add	x2, x3, x0
    7bec:	f9401054 	ldr	x20, [x2, #32]
    7bf0:	b4000254 	cbz	x20, 7c38 <f12+0xbd8>
    7bf4:	38606860 	ldrb	w0, [x3, x0]
    7bf8:	7100081f 	cmp	w0, #0x2
    7bfc:	54002200 	b.eq	803c <f12+0xfdc>  // b.none
    7c00:	7100041f 	cmp	w0, #0x1
    7c04:	540001a1 	b.ne	7c38 <f12+0xbd8>  // b.any
    7c08:	29430043 	ldp	w3, w0, [x2, #24]
    7c0c:	92403c21 	and	x1, x1, #0xffff
    7c10:	9b037c21 	mul	x1, x1, x3
    7c14:	d360fc21 	lsr	x1, x1, #32
    7c18:	eb00003f 	cmp	x1, x0
    7c1c:	540000e2 	b.cs	7c38 <f12+0xbd8>  // b.hs, b.nlast
    7c20:	8b010294 	add	x20, x20, x1
    7c24:	39400280 	ldrb	w0, [x20]
    7c28:	7103fc1f 	cmp	w0, #0xff
    7c2c:	54002020 	b.eq	8030 <f12+0xfd0>  // b.none
    7c30:	52800020 	mov	w0, #0x1                   	// #1
    7c34:	39000280 	strb	w0, [x20]
    7c38:	aa1803e0 	mov	x0, x24
    7c3c:	17ffff5c 	b	79ac <f12+0x94c>
    7c40:	72003c1f 	tst	w0, #0xffff
    7c44:	54fff1c0 	b.eq	7a7c <f12+0xa1c>  // b.none
    7c48:	b40013d3 	cbz	x19, 7ec0 <f12+0xe60>
    7c4c:	aa1303fa 	mov	x26, x19
    7c50:	d2800014 	mov	x20, #0x0                   	// #0
    7c54:	f9400b5a 	ldr	x26, [x26, #16]
    7c58:	aa1403e0 	mov	x0, x20
    7c5c:	91000694 	add	x20, x20, #0x1
    7c60:	b5ffffba 	cbnz	x26, 7c54 <f12+0xbf4>
    7c64:	b27fefe1 	mov	x1, #0x1ffffffffffffffe    	// #2305843009213693950
    7c68:	eb01029f 	cmp	x20, x1
    7c6c:	54ffba48 	b.hi	73b4 <f12+0x354>  // b.pmore
    7c70:	91000800 	add	x0, x0, #0x2
    7c74:	52800041 	mov	w1, #0x2                   	// #2
    7c78:	d37df000 	lsl	x0, x0, #3
    7c7c:	97fff505 	bl	5090 <fwp_heap_alloc>
    7c80:	aa1303e1 	mov	x1, x19
    7c84:	aa0003f9 	mov	x25, x0
    7c88:	f9400420 	ldr	x0, [x1, #8]
    7c8c:	f83a7b20 	str	x0, [x25, x26, lsl #3]
    7c90:	9100075a 	add	x26, x26, #0x1
    7c94:	f9400821 	ldr	x1, [x1, #16]
    7c98:	b5ffff81 	cbnz	x1, 7c88 <f12+0xc28>
    7c9c:	5280001c 	mov	w28, #0x0                   	// #0
    7ca0:	17ffff7b 	b	7a8c <f12+0xa2c>
    7ca4:	b4001f93 	cbz	x19, 8094 <f12+0x1034>
    7ca8:	9118c2a0 	add	x0, x21, #0x630
    7cac:	aa1303e2 	mov	x2, x19
    7cb0:	d280001b 	mov	x27, #0x0                   	// #0
    7cb4:	f949ec04 	ldr	x4, [x0, #5080]
    7cb8:	f949d807 	ldr	x7, [x0, #5040]
    7cbc:	f949fc06 	ldr	x6, [x0, #5112]
    7cc0:	d370bc84 	lsl	x4, x4, #16
    7cc4:	14000006 	b	7cdc <f12+0xc7c>
    7cc8:	f9400842 	ldr	x2, [x2, #16]
    7ccc:	9100077b 	add	x27, x27, #0x1
    7cd0:	f100005f 	cmp	x2, #0x0
    7cd4:	fa581362 	ccmp	x27, x24, #0x2, ne	// ne = any
    7cd8:	54000322 	b.cs	7d3c <f12+0xcdc>  // b.hs, b.nlast
    7cdc:	cb070040 	sub	x0, x2, x7
    7ce0:	eb04001f 	cmp	x0, x4
    7ce4:	540002c2 	b.cs	7d3c <f12+0xcdc>  // b.hs, b.nlast
    7ce8:	d350fc01 	lsr	x1, x0, #16
    7cec:	8b010821 	add	x1, x1, x1, lsl #2
    7cf0:	d37df021 	lsl	x1, x1, #3
    7cf4:	8b0100c5 	add	x5, x6, x1
    7cf8:	f94010a3 	ldr	x3, [x5, #32]
    7cfc:	b4000203 	cbz	x3, 7d3c <f12+0xcdc>
    7d00:	386168c1 	ldrb	w1, [x6, x1]
    7d04:	7100083f 	cmp	w1, #0x2
    7d08:	54000880 	b.eq	7e18 <f12+0xdb8>  // b.none
    7d0c:	7100043f 	cmp	w1, #0x1
    7d10:	54000161 	b.ne	7d3c <f12+0xcdc>  // b.any
    7d14:	294304a8 	ldp	w8, w1, [x5, #24]
    7d18:	92403c00 	and	x0, x0, #0xffff
    7d1c:	9b087c00 	mul	x0, x0, x8
    7d20:	d360fc00 	lsr	x0, x0, #32
    7d24:	eb01001f 	cmp	x0, x1
    7d28:	540000a2 	b.cs	7d3c <f12+0xcdc>  // b.hs, b.nlast
    7d2c:	8b000063 	add	x3, x3, x0
    7d30:	39400060 	ldrb	w0, [x3]
    7d34:	7100041f 	cmp	w0, #0x1
    7d38:	54fffc80 	b.eq	7cc8 <f12+0xc68>  // b.none
    7d3c:	d280001a 	mov	x26, #0x0                   	// #0
    7d40:	eb1b031f 	cmp	x24, x27
    7d44:	540018e9 	b.ls	8060 <f12+0x1000>  // b.plast
    7d48:	d1002320 	sub	x0, x25, #0x8
    7d4c:	aa1803f4 	mov	x20, x24
    7d50:	9118c2b7 	add	x23, x21, #0x630
    7d54:	d280001a 	mov	x26, #0x0                   	// #0
    7d58:	f9000be0 	str	x0, [sp, #16]
    7d5c:	9102e3e0 	add	x0, sp, #0xb8
    7d60:	f90007e0 	str	x0, [sp, #8]
    7d64:	14000012 	b	7dac <f12+0xd4c>
    7d68:	7100045f 	cmp	w2, #0x1
    7d6c:	540001a1 	b.ne	7da0 <f12+0xd40>  // b.any
    7d70:	294308a6 	ldp	w6, w2, [x5, #24]
    7d74:	92403c21 	and	x1, x1, #0xffff
    7d78:	9b067c21 	mul	x1, x1, x6
    7d7c:	d360fc21 	lsr	x1, x1, #32
    7d80:	eb02003f 	cmp	x1, x2
    7d84:	540000e2 	b.cs	7da0 <f12+0xd40>  // b.hs, b.nlast
    7d88:	8b010000 	add	x0, x0, x1
    7d8c:	39400001 	ldrb	w1, [x0]
    7d90:	7103fc3f 	cmp	w1, #0xff
    7d94:	54001840 	b.eq	809c <f12+0x103c>  // b.none
    7d98:	52800021 	mov	w1, #0x1                   	// #1
    7d9c:	39000001 	strb	w1, [x0]
    7da0:	d1000694 	sub	x20, x20, #0x1
    7da4:	eb14037f 	cmp	x27, x20
    7da8:	54000d42 	b.cs	7f50 <f12+0xef0>  // b.hs, b.nlast
    7dac:	a94083e1 	ldp	x1, x0, [sp, #8]
    7db0:	f8747802 	ldr	x2, [x0, x20, lsl #3]
    7db4:	52800020 	mov	w0, #0x1                   	// #1
    7db8:	a90bebe2 	stp	x2, x26, [sp, #184]
    7dbc:	97fff795 	bl	5c10 <fwp_data.part.0.constprop.0>
    7dc0:	aa0003fa 	mov	x26, x0
    7dc4:	f949dae1 	ldr	x1, [x23, #5040]
    7dc8:	f949eee0 	ldr	x0, [x23, #5080]
    7dcc:	cb010341 	sub	x1, x26, x1
    7dd0:	eb00403f 	cmp	x1, x0, lsl #16
    7dd4:	54fffe62 	b.cs	7da0 <f12+0xd40>  // b.hs, b.nlast
    7dd8:	d350fc20 	lsr	x0, x1, #16
    7ddc:	f949fee6 	ldr	x6, [x23, #5112]
    7de0:	8b000800 	add	x0, x0, x0, lsl #2
    7de4:	d37df002 	lsl	x2, x0, #3
    7de8:	8b0200c5 	add	x5, x6, x2
    7dec:	f94010a0 	ldr	x0, [x5, #32]
    7df0:	b4fffd80 	cbz	x0, 7da0 <f12+0xd40>
    7df4:	386268c2 	ldrb	w2, [x6, x2]
    7df8:	7100085f 	cmp	w2, #0x2
    7dfc:	54fffb61 	b.ne	7d68 <f12+0xd08>  // b.any
    7e00:	72003c3f 	tst	w1, #0xffff
    7e04:	54fffce1 	b.ne	7da0 <f12+0xd40>  // b.any
    7e08:	17ffffe1 	b	7d8c <f12+0xd2c>
    7e0c:	72003c3f 	tst	w1, #0xffff
    7e10:	54ffd7c1 	b.ne	7908 <f12+0x8a8>  // b.any
    7e14:	17fffeb8 	b	78f4 <f12+0x894>
    7e18:	72003c1f 	tst	w0, #0xffff
    7e1c:	54fff901 	b.ne	7d3c <f12+0xcdc>  // b.any
    7e20:	17ffffc4 	b	7d30 <f12+0xcd0>
    7e24:	d10004c1 	sub	x1, x6, #0x1
    7e28:	b27fefe0 	mov	x0, #0x1ffffffffffffffe    	// #2305843009213693950
    7e2c:	eb00003f 	cmp	x1, x0
    7e30:	540003c8 	b.hi	7ea8 <f12+0xe48>  // b.pmore
    7e34:	b00002c0 	adrp	x0, 60000 <ad_raw_checkpoints+0x2fbb0>
    7e38:	d2800003 	mov	x3, #0x0                   	// #0
    7e3c:	91114001 	add	x1, x0, #0x450
    7e40:	14000005 	b	7e54 <f12+0xdf4>
    7e44:	91000463 	add	x3, x3, #0x1
    7e48:	91006021 	add	x1, x1, #0x18
    7e4c:	f140047f 	cmp	x3, #0x1, lsl #12
    7e50:	54000320 	b.eq	7eb4 <f12+0xe54>  // b.none
    7e54:	f9400022 	ldr	x2, [x1]
    7e58:	b5ffff62 	cbnz	x2, 7e44 <f12+0xde4>
    7e5c:	91114002 	add	x2, x0, #0x450
    7e60:	d2800307 	mov	x7, #0x18                  	// #24
    7e64:	aa0603e0 	mov	x0, x6
    7e68:	d2800101 	mov	x1, #0x8                   	// #8
    7e6c:	f9001fe4 	str	x4, [sp, #56]
    7e70:	9b070862 	madd	x2, x3, x7, x2
    7e74:	a9029be2 	stp	x2, x6, [sp, #40]
    7e78:	97ffea5e 	bl	27f0 <calloc@plt>
    7e7c:	aa0003fb 	mov	x27, x0
    7e80:	a94313e6 	ldp	x6, x4, [sp, #48]
    7e84:	b4ffe4c0 	cbz	x0, 7b1c <f12+0xabc>
    7e88:	aa0003e1 	mov	x1, x0
    7e8c:	d37df0c2 	lsl	x2, x6, #3
    7e90:	f94017e0 	ldr	x0, [sp, #40]
    7e94:	52800063 	mov	w3, #0x3                   	// #3
    7e98:	a90293e6 	stp	x6, x4, [sp, #40]
    7e9c:	97ffec1d 	bl	2f10 <ad_raw_record>
    7ea0:	a94293e6 	ldp	x6, x4, [sp, #40]
    7ea4:	17fffe37 	b	7780 <f12+0x720>
    7ea8:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7eac:	911e4000 	add	x0, x0, #0x790
    7eb0:	97ffed14 	bl	3300 <ad_raw_fail>
    7eb4:	90000020 	adrp	x0, b000 <__modti3+0x2a0>
    7eb8:	910e2000 	add	x0, x0, #0x388
    7ebc:	97ffed11 	bl	3300 <ad_raw_fail>
    7ec0:	52800041 	mov	w1, #0x2                   	// #2
    7ec4:	d2800100 	mov	x0, #0x8                   	// #8
    7ec8:	97fff472 	bl	5090 <fwp_heap_alloc>
    7ecc:	aa0003f9 	mov	x25, x0
    7ed0:	5280001c 	mov	w28, #0x0                   	// #0
    7ed4:	d280001a 	mov	x26, #0x0                   	// #0
    7ed8:	7100039f 	cmp	w28, #0x0
    7edc:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    7ee0:	aa1903e0 	mov	x0, x25
    7ee4:	97fff1af 	bl	45a0 <fwp_mem_free>
    7ee8:	aa1603e0 	mov	x0, x22
    7eec:	97fffbb5 	bl	6dc0 <fwp_drop4>
    7ef0:	aa1303e0 	mov	x0, x19
    7ef4:	97fff8a7 	bl	6190 <fwp_drop0>
    7ef8:	900000c0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    7efc:	f947f400 	ldr	x0, [x0, #4072]
    7f00:	f94067e2 	ldr	x2, [sp, #200]
    7f04:	f9400001 	ldr	x1, [x0]
    7f08:	eb010042 	subs	x2, x2, x1
    7f0c:	d2800001 	mov	x1, #0x0                   	// #0
    7f10:	54000141 	b.ne	7f38 <f12+0xed8>  // b.any
    7f14:	a94d7bfd 	ldp	x29, x30, [sp, #208]
    7f18:	aa1a03e0 	mov	x0, x26
    7f1c:	a94e53f3 	ldp	x19, x20, [sp, #224]
    7f20:	a94f5bf5 	ldp	x21, x22, [sp, #240]
    7f24:	a95063f7 	ldp	x23, x24, [sp, #256]
    7f28:	a9516bf9 	ldp	x25, x26, [sp, #272]
    7f2c:	a95273fb 	ldp	x27, x28, [sp, #288]
    7f30:	9104c3ff 	add	sp, sp, #0x130
    7f34:	d65f03c0 	ret
    7f38:	97ffea36 	bl	2810 <__stack_chk_fail@plt>
    7f3c:	f94002f8 	ldr	x24, [x23]
    7f40:	b7fffc18 	tbnz	x24, #63, 7ec0 <f12+0xe60>
    7f44:	9240fb18 	and	x24, x24, #0x7fffffffffffffff
    7f48:	d2800014 	mov	x20, #0x0                   	// #0
    7f4c:	17fffeb3 	b	7a18 <f12+0x9b8>
    7f50:	d1000701 	sub	x1, x24, #0x1
    7f54:	cb180360 	sub	x0, x27, x24
    7f58:	eb01037f 	cmp	x27, x1
    7f5c:	9a8087e0 	csinc	x0, xzr, x0, hi	// hi = pmore
    7f60:	8b010000 	add	x0, x0, x1
    7f64:	b50007fb 	cbnz	x27, 8060 <f12+0x1000>
    7f68:	7100039f 	cmp	w28, #0x0
    7f6c:	9a9913f9 	csel	x25, xzr, x25, ne	// ne = any
    7f70:	b4fffb80 	cbz	x0, 7ee0 <f12+0xe80>
    7f74:	d1000414 	sub	x20, x0, #0x1
    7f78:	9118c2b5 	add	x21, x21, #0x630
    7f7c:	52800038 	mov	w24, #0x1                   	// #1
    7f80:	f8747b22 	ldr	x2, [x25, x20, lsl #3]
    7f84:	52800020 	mov	w0, #0x1                   	// #1
    7f88:	f94007e1 	ldr	x1, [sp, #8]
    7f8c:	a90bebe2 	stp	x2, x26, [sp, #184]
    7f90:	97fff720 	bl	5c10 <fwp_data.part.0.constprop.0>
    7f94:	aa0003fa 	mov	x26, x0
    7f98:	f949daa1 	ldr	x1, [x21, #5040]
    7f9c:	f949eea0 	ldr	x0, [x21, #5080]
    7fa0:	cb010341 	sub	x1, x26, x1
    7fa4:	eb00403f 	cmp	x1, x0, lsl #16
    7fa8:	54000302 	b.cs	8008 <f12+0xfa8>  // b.hs, b.nlast
    7fac:	d350fc20 	lsr	x0, x1, #16
    7fb0:	f949fea3 	ldr	x3, [x21, #5112]
    7fb4:	8b000800 	add	x0, x0, x0, lsl #2
    7fb8:	d37df002 	lsl	x2, x0, #3
    7fbc:	8b020060 	add	x0, x3, x2
    7fc0:	f940101b 	ldr	x27, [x0, #32]
    7fc4:	b400023b 	cbz	x27, 8008 <f12+0xfa8>
    7fc8:	38626862 	ldrb	w2, [x3, x2]
    7fcc:	7100085f 	cmp	w2, #0x2
    7fd0:	54000240 	b.eq	8018 <f12+0xfb8>  // b.none
    7fd4:	7100045f 	cmp	w2, #0x1
    7fd8:	54000181 	b.ne	8008 <f12+0xfa8>  // b.any
    7fdc:	29430002 	ldp	w2, w0, [x0, #24]
    7fe0:	92403c21 	and	x1, x1, #0xffff
    7fe4:	9b027c21 	mul	x1, x1, x2
    7fe8:	d360fc21 	lsr	x1, x1, #32
    7fec:	eb00003f 	cmp	x1, x0
    7ff0:	540000c2 	b.cs	8008 <f12+0xfa8>  // b.hs, b.nlast
    7ff4:	8b01037b 	add	x27, x27, x1
    7ff8:	39400360 	ldrb	w0, [x27]
    7ffc:	7103fc1f 	cmp	w0, #0xff
    8000:	54000120 	b.eq	8024 <f12+0xfc4>  // b.none
    8004:	39000378 	strb	w24, [x27]
    8008:	d1000694 	sub	x20, x20, #0x1
    800c:	b100069f 	cmn	x20, #0x1
    8010:	54fffb81 	b.ne	7f80 <f12+0xf20>  // b.any
    8014:	17ffffb3 	b	7ee0 <f12+0xe80>
    8018:	72003c3f 	tst	w1, #0xffff
    801c:	54ffff61 	b.ne	8008 <f12+0xfa8>  // b.any
    8020:	17fffff6 	b	7ff8 <f12+0xf98>
    8024:	aa1b03e0 	mov	x0, x27
    8028:	97fff0c3 	bl	4334 <fwp_rc_forget_slot.part.0>
    802c:	17fffff6 	b	8004 <f12+0xfa4>
    8030:	aa1403e0 	mov	x0, x20
    8034:	97fff0c0 	bl	4334 <fwp_rc_forget_slot.part.0>
    8038:	17fffefe 	b	7c30 <f12+0xbd0>
    803c:	72003c3f 	tst	w1, #0xffff
    8040:	54ffdf20 	b.eq	7c24 <f12+0xbc4>  // b.none
    8044:	aa1803e0 	mov	x0, x24
    8048:	17fffe59 	b	79ac <f12+0x94c>
    804c:	aa1903e0 	mov	x0, x25
    8050:	97fff0b9 	bl	4334 <fwp_rc_forget_slot.part.0>
    8054:	91014280 	add	x0, x20, #0x50
    8058:	f941c81a 	ldr	x26, [x0, #912]
    805c:	17fffe29 	b	7900 <f12+0x8a0>
    8060:	aa1303e0 	mov	x0, x19
    8064:	d2800001 	mov	x1, #0x0                   	// #0
    8068:	f8617b22 	ldr	x2, [x25, x1, lsl #3]
    806c:	91000421 	add	x1, x1, #0x1
    8070:	f9000402 	str	x2, [x0, #8]
    8074:	aa0003e2 	mov	x2, x0
    8078:	f9400800 	ldr	x0, [x0, #16]
    807c:	eb1b003f 	cmp	x1, x27
    8080:	54ffff43 	b.cc	8068 <f12+0x1008>  // b.lo, b.ul, b.last
    8084:	f900085a 	str	x26, [x2, #16]
    8088:	aa1303fa 	mov	x26, x19
    808c:	aa0003f3 	mov	x19, x0
    8090:	17ffff92 	b	7ed8 <f12+0xe78>
    8094:	d280001b 	mov	x27, #0x0                   	// #0
    8098:	17ffff2c 	b	7d48 <f12+0xce8>
    809c:	f9000fe0 	str	x0, [sp, #24]
    80a0:	97fff0a5 	bl	4334 <fwp_rc_forget_slot.part.0>
    80a4:	f9400fe0 	ldr	x0, [sp, #24]
    80a8:	17ffff3c 	b	7d98 <f12+0xd38>
    80ac:	97ffea55 	bl	2a00 <fwp_trap_overflow.constprop.0>
    80b0:	97ffe9ec 	bl	2860 <abort@plt>

00000000000080b4 <fwp_owned_entry12>:
    80b4:	f9400000 	ldr	x0, [x0]
    80b8:	17fffbea 	b	7060 <f12>
    80bc:	d503201f 	nop

00000000000080c0 <e12>:
    80c0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    80c4:	910003fd 	mov	x29, sp
    80c8:	f9000bf3 	str	x19, [sp, #16]
    80cc:	f9400013 	ldr	x19, [x0]
    80d0:	aa1303e0 	mov	x0, x19
    80d4:	97fff72f 	bl	5d90 <fwp_rc_share>
    80d8:	aa1303e0 	mov	x0, x19
    80dc:	97fffbe1 	bl	7060 <f12>
    80e0:	aa0003f3 	mov	x19, x0
    80e4:	97fff72b 	bl	5d90 <fwp_rc_share>
    80e8:	aa1303e0 	mov	x0, x19
    80ec:	f9400bf3 	ldr	x19, [sp, #16]
    80f0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    80f4:	d65f03c0 	ret
    80f8:	d503201f 	nop
    80fc:	d503201f 	nop

0000000000008100 <fwp_args23>:
    8100:	7100003f 	cmp	w1, #0x0
    8104:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8108:	54000041 	b.ne	8110 <fwp_args23+0x10>  // b.any
    810c:	d65f03c0 	ret
    8110:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8114:	9118c042 	add	x2, x2, #0x630
    8118:	f9400001 	ldr	x1, [x0]
    811c:	f949d843 	ldr	x3, [x2, #5040]
    8120:	f949ec40 	ldr	x0, [x2, #5080]
    8124:	cb030021 	sub	x1, x1, x3
    8128:	eb00403f 	cmp	x1, x0, lsl #16
    812c:	54ffff02 	b.cs	810c <fwp_args23+0xc>  // b.hs, b.nlast
    8130:	d350fc20 	lsr	x0, x1, #16
    8134:	f949fc44 	ldr	x4, [x2, #5112]
    8138:	8b000800 	add	x0, x0, x0, lsl #2
    813c:	d37df002 	lsl	x2, x0, #3
    8140:	8b020083 	add	x3, x4, x2
    8144:	f9401060 	ldr	x0, [x3, #32]
    8148:	b4fffe20 	cbz	x0, 810c <fwp_args23+0xc>
    814c:	38626882 	ldrb	w2, [x4, x2]
    8150:	7100085f 	cmp	w2, #0x2
    8154:	54000320 	b.eq	81b8 <fwp_args23+0xb8>  // b.none
    8158:	7100045f 	cmp	w2, #0x1
    815c:	54fffd81 	b.ne	810c <fwp_args23+0xc>  // b.any
    8160:	29430864 	ldp	w4, w2, [x3, #24]
    8164:	92403c21 	and	x1, x1, #0xffff
    8168:	9b047c21 	mul	x1, x1, x4
    816c:	d360fc21 	lsr	x1, x1, #32
    8170:	eb02003f 	cmp	x1, x2
    8174:	54fffcc2 	b.cs	810c <fwp_args23+0xc>  // b.hs, b.nlast
    8178:	8b010000 	add	x0, x0, x1
    817c:	39400001 	ldrb	w1, [x0]
    8180:	34fffc61 	cbz	w1, 810c <fwp_args23+0xc>
    8184:	900000c2 	adrp	x2, 20000 <__data_start>
    8188:	91014042 	add	x2, x2, #0x50
    818c:	b9413043 	ldr	w3, [x2, #304]
    8190:	350000c3 	cbnz	w3, 81a8 <fwp_args23+0xa8>
    8194:	7103f43f 	cmp	w1, #0xfd
    8198:	54000168 	b.hi	81c4 <fwp_args23+0xc4>  // b.pmore
    819c:	11000421 	add	w1, w1, #0x1
    81a0:	39000001 	strb	w1, [x0]
    81a4:	d65f03c0 	ret
    81a8:	f940ac43 	ldr	x3, [x2, #344]
    81ac:	91000463 	add	x3, x3, #0x1
    81b0:	f900ac43 	str	x3, [x2, #344]
    81b4:	17fffff8 	b	8194 <fwp_args23+0x94>
    81b8:	72003c3f 	tst	w1, #0xffff
    81bc:	54fffe00 	b.eq	817c <fwp_args23+0x7c>  // b.none
    81c0:	d65f03c0 	ret
    81c4:	17fff170 	b	4784 <fwp_rc_wide_dup>
    81c8:	d503201f 	nop
    81cc:	d503201f 	nop

00000000000081d0 <fwp_args12>:
    81d0:	7100003f 	cmp	w1, #0x0
    81d4:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    81d8:	54000041 	b.ne	81e0 <fwp_args12+0x10>  // b.any
    81dc:	d65f03c0 	ret
    81e0:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    81e4:	9118c042 	add	x2, x2, #0x630
    81e8:	f9400001 	ldr	x1, [x0]
    81ec:	f949d843 	ldr	x3, [x2, #5040]
    81f0:	f949ec40 	ldr	x0, [x2, #5080]
    81f4:	cb030021 	sub	x1, x1, x3
    81f8:	eb00403f 	cmp	x1, x0, lsl #16
    81fc:	54ffff02 	b.cs	81dc <fwp_args12+0xc>  // b.hs, b.nlast
    8200:	d350fc20 	lsr	x0, x1, #16
    8204:	f949fc44 	ldr	x4, [x2, #5112]
    8208:	8b000800 	add	x0, x0, x0, lsl #2
    820c:	d37df002 	lsl	x2, x0, #3
    8210:	8b020083 	add	x3, x4, x2
    8214:	f9401060 	ldr	x0, [x3, #32]
    8218:	b4fffe20 	cbz	x0, 81dc <fwp_args12+0xc>
    821c:	38626882 	ldrb	w2, [x4, x2]
    8220:	7100085f 	cmp	w2, #0x2
    8224:	54000320 	b.eq	8288 <fwp_args12+0xb8>  // b.none
    8228:	7100045f 	cmp	w2, #0x1
    822c:	54fffd81 	b.ne	81dc <fwp_args12+0xc>  // b.any
    8230:	29430864 	ldp	w4, w2, [x3, #24]
    8234:	92403c21 	and	x1, x1, #0xffff
    8238:	9b047c21 	mul	x1, x1, x4
    823c:	d360fc21 	lsr	x1, x1, #32
    8240:	eb02003f 	cmp	x1, x2
    8244:	54fffcc2 	b.cs	81dc <fwp_args12+0xc>  // b.hs, b.nlast
    8248:	8b010000 	add	x0, x0, x1
    824c:	39400001 	ldrb	w1, [x0]
    8250:	34fffc61 	cbz	w1, 81dc <fwp_args12+0xc>
    8254:	900000c2 	adrp	x2, 20000 <__data_start>
    8258:	91014042 	add	x2, x2, #0x50
    825c:	b9413043 	ldr	w3, [x2, #304]
    8260:	350000c3 	cbnz	w3, 8278 <fwp_args12+0xa8>
    8264:	7103f43f 	cmp	w1, #0xfd
    8268:	54000168 	b.hi	8294 <fwp_args12+0xc4>  // b.pmore
    826c:	11000421 	add	w1, w1, #0x1
    8270:	39000001 	strb	w1, [x0]
    8274:	d65f03c0 	ret
    8278:	f940ac43 	ldr	x3, [x2, #344]
    827c:	91000463 	add	x3, x3, #0x1
    8280:	f900ac43 	str	x3, [x2, #344]
    8284:	17fffff8 	b	8264 <fwp_args12+0x94>
    8288:	72003c3f 	tst	w1, #0xffff
    828c:	54fffe00 	b.eq	824c <fwp_args12+0x7c>  // b.none
    8290:	d65f03c0 	ret
    8294:	17fff13c 	b	4784 <fwp_rc_wide_dup>
    8298:	d503201f 	nop
    829c:	d503201f 	nop

00000000000082a0 <fwp_drop2>:
    82a0:	a9bd7bfd 	stp	x29, x30, [sp, #-48]!
    82a4:	910003fd 	mov	x29, sp
    82a8:	a9025bf5 	stp	x21, x22, [sp, #32]
    82ac:	b0000396 	adrp	x22, 79000 <fwp_root_context+0xbb0>
    82b0:	9118c2d5 	add	x21, x22, #0x630
    82b4:	a90153f3 	stp	x19, x20, [sp, #16]
    82b8:	aa0003f3 	mov	x19, x0
    82bc:	f949daa1 	ldr	x1, [x21, #5040]
    82c0:	f949eea0 	ldr	x0, [x21, #5080]
    82c4:	cb010261 	sub	x1, x19, x1
    82c8:	eb00403f 	cmp	x1, x0, lsl #16
    82cc:	54000382 	b.cs	833c <fwp_drop2+0x9c>  // b.hs, b.nlast
    82d0:	d350fc22 	lsr	x2, x1, #16
    82d4:	f949fea3 	ldr	x3, [x21, #5112]
    82d8:	8b020842 	add	x2, x2, x2, lsl #2
    82dc:	d37df042 	lsl	x2, x2, #3
    82e0:	8b020060 	add	x0, x3, x2
    82e4:	f9401014 	ldr	x20, [x0, #32]
    82e8:	b40002b4 	cbz	x20, 833c <fwp_drop2+0x9c>
    82ec:	38626862 	ldrb	w2, [x3, x2]
    82f0:	7100085f 	cmp	w2, #0x2
    82f4:	540002c0 	b.eq	834c <fwp_drop2+0xac>  // b.none
    82f8:	7100045f 	cmp	w2, #0x1
    82fc:	54000201 	b.ne	833c <fwp_drop2+0x9c>  // b.any
    8300:	29430002 	ldp	w2, w0, [x0, #24]
    8304:	92403c21 	and	x1, x1, #0xffff
    8308:	9b027c21 	mul	x1, x1, x2
    830c:	d360fc21 	lsr	x1, x1, #32
    8310:	eb00003f 	cmp	x1, x0
    8314:	54000142 	b.cs	833c <fwp_drop2+0x9c>  // b.hs, b.nlast
    8318:	8b010294 	add	x20, x20, x1
    831c:	39400280 	ldrb	w0, [x20]
    8320:	340000e0 	cbz	w0, 833c <fwp_drop2+0x9c>
    8324:	7100041f 	cmp	w0, #0x1
    8328:	540001e0 	b.eq	8364 <fwp_drop2+0xc4>  // b.none
    832c:	7103fc1f 	cmp	w0, #0xff
    8330:	540007c0 	b.eq	8428 <fwp_drop2+0x188>  // b.none
    8334:	51000400 	sub	w0, w0, #0x1
    8338:	39000280 	strb	w0, [x20]
    833c:	a94153f3 	ldp	x19, x20, [sp, #16]
    8340:	a9425bf5 	ldp	x21, x22, [sp, #32]
    8344:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8348:	d65f03c0 	ret
    834c:	72003c3f 	tst	w1, #0xffff
    8350:	54fffe60 	b.eq	831c <fwp_drop2+0x7c>  // b.none
    8354:	a94153f3 	ldp	x19, x20, [sp, #16]
    8358:	a9425bf5 	ldp	x21, x22, [sp, #32]
    835c:	a8c37bfd 	ldp	x29, x30, [sp], #48
    8360:	d65f03c0 	ret
    8364:	9118c2c2 	add	x2, x22, #0x630
    8368:	f9400660 	ldr	x0, [x19, #8]
    836c:	f949d841 	ldr	x1, [x2, #5040]
    8370:	f949ec42 	ldr	x2, [x2, #5080]
    8374:	cb010001 	sub	x1, x0, x1
    8378:	eb02403f 	cmp	x1, x2, lsl #16
    837c:	54000362 	b.cs	83e8 <fwp_drop2+0x148>  // b.hs, b.nlast
    8380:	d350fc22 	lsr	x2, x1, #16
    8384:	8b020842 	add	x2, x2, x2, lsl #2
    8388:	d37df042 	lsl	x2, x2, #3
    838c:	8b020064 	add	x4, x3, x2
    8390:	f9401094 	ldr	x20, [x4, #32]
    8394:	b40002b4 	cbz	x20, 83e8 <fwp_drop2+0x148>
    8398:	38626862 	ldrb	w2, [x3, x2]
    839c:	7100085f 	cmp	w2, #0x2
    83a0:	540003e0 	b.eq	841c <fwp_drop2+0x17c>  // b.none
    83a4:	7100045f 	cmp	w2, #0x1
    83a8:	54000201 	b.ne	83e8 <fwp_drop2+0x148>  // b.any
    83ac:	29430883 	ldp	w3, w2, [x4, #24]
    83b0:	92403c21 	and	x1, x1, #0xffff
    83b4:	9b037c21 	mul	x1, x1, x3
    83b8:	d360fc21 	lsr	x1, x1, #32
    83bc:	eb02003f 	cmp	x1, x2
    83c0:	54000142 	b.cs	83e8 <fwp_drop2+0x148>  // b.hs, b.nlast
    83c4:	8b010294 	add	x20, x20, x1
    83c8:	39400281 	ldrb	w1, [x20]
    83cc:	340000e1 	cbz	w1, 83e8 <fwp_drop2+0x148>
    83d0:	7100043f 	cmp	w1, #0x1
    83d4:	54000200 	b.eq	8414 <fwp_drop2+0x174>  // b.none
    83d8:	7103fc3f 	cmp	w1, #0xff
    83dc:	54000640 	b.eq	84a4 <fwp_drop2+0x204>  // b.none
    83e0:	51000421 	sub	w1, w1, #0x1
    83e4:	39000281 	strb	w1, [x20]
    83e8:	f9400a74 	ldr	x20, [x19, #16]
    83ec:	aa1303e0 	mov	x0, x19
    83f0:	97fff68c 	bl	5e20 <fwp_rc_free_arr>
    83f4:	9118c2c0 	add	x0, x22, #0x630
    83f8:	f949d801 	ldr	x1, [x0, #5040]
    83fc:	f949ec00 	ldr	x0, [x0, #5080]
    8400:	cb010281 	sub	x1, x20, x1
    8404:	eb00403f 	cmp	x1, x0, lsl #16
    8408:	54fff9a2 	b.cs	833c <fwp_drop2+0x9c>  // b.hs, b.nlast
    840c:	aa1403f3 	mov	x19, x20
    8410:	17ffffb0 	b	82d0 <fwp_drop2+0x30>
    8414:	97fff683 	bl	5e20 <fwp_rc_free_arr>
    8418:	17fffff4 	b	83e8 <fwp_drop2+0x148>
    841c:	72003c3f 	tst	w1, #0xffff
    8420:	54fffe41 	b.ne	83e8 <fwp_drop2+0x148>  // b.any
    8424:	17ffffe9 	b	83c8 <fwp_drop2+0x128>
    8428:	ca544681 	eor	x1, x20, x20, lsr #17
    842c:	9118c2c0 	add	x0, x22, #0x630
    8430:	ca412421 	eor	x1, x1, x1, lsr #9
    8434:	92401c21 	and	x1, x1, #0xff
    8438:	910a2422 	add	x2, x1, #0x289
    843c:	8b010c01 	add	x1, x0, x1, lsl #3
    8440:	8b020c02 	add	x2, x0, x2, lsl #3
    8444:	f94a2420 	ldr	x0, [x1, #5192]
    8448:	b50000a0 	cbnz	x0, 845c <fwp_drop2+0x1bc>
    844c:	14000013 	b	8498 <fwp_drop2+0x1f8>
    8450:	91004002 	add	x2, x0, #0x10
    8454:	f9400800 	ldr	x0, [x0, #16]
    8458:	b4000200 	cbz	x0, 8498 <fwp_drop2+0x1f8>
    845c:	f9400001 	ldr	x1, [x0]
    8460:	eb14003f 	cmp	x1, x20
    8464:	54ffff61 	b.ne	8450 <fwp_drop2+0x1b0>  // b.any
    8468:	f9400041 	ldr	x1, [x2]
    846c:	f9400420 	ldr	x0, [x1, #8]
    8470:	d1000400 	sub	x0, x0, #0x1
    8474:	f9000420 	str	x0, [x1, #8]
    8478:	f103f81f 	cmp	x0, #0xfe
    847c:	54fff601 	b.ne	833c <fwp_drop2+0x9c>  // b.any
    8480:	39400280 	ldrb	w0, [x20]
    8484:	7103fc1f 	cmp	w0, #0xff
    8488:	54000460 	b.eq	8514 <fwp_drop2+0x274>  // b.none
    848c:	12800020 	mov	w0, #0xfffffffe            	// #-2
    8490:	39000280 	strb	w0, [x20]
    8494:	17ffffaa 	b	833c <fwp_drop2+0x9c>
    8498:	f0000000 	adrp	x0, b000 <__modti3+0x2a0>
    849c:	91116000 	add	x0, x0, #0x458
    84a0:	97ffef85 	bl	42b4 <fwp_trap>
    84a4:	ca544680 	eor	x0, x20, x20, lsr #17
    84a8:	9118c2c1 	add	x1, x22, #0x630
    84ac:	ca402400 	eor	x0, x0, x0, lsr #9
    84b0:	92401c00 	and	x0, x0, #0xff
    84b4:	910a2402 	add	x2, x0, #0x289
    84b8:	8b000c20 	add	x0, x1, x0, lsl #3
    84bc:	8b020c22 	add	x2, x1, x2, lsl #3
    84c0:	f94a2400 	ldr	x0, [x0, #5192]
    84c4:	b50000a0 	cbnz	x0, 84d8 <fwp_drop2+0x238>
    84c8:	17fffff4 	b	8498 <fwp_drop2+0x1f8>
    84cc:	91004002 	add	x2, x0, #0x10
    84d0:	f9400800 	ldr	x0, [x0, #16]
    84d4:	b4fffe20 	cbz	x0, 8498 <fwp_drop2+0x1f8>
    84d8:	f9400001 	ldr	x1, [x0]
    84dc:	eb14003f 	cmp	x1, x20
    84e0:	54ffff61 	b.ne	84cc <fwp_drop2+0x22c>  // b.any
    84e4:	f9400041 	ldr	x1, [x2]
    84e8:	f9400420 	ldr	x0, [x1, #8]
    84ec:	d1000400 	sub	x0, x0, #0x1
    84f0:	f9000420 	str	x0, [x1, #8]
    84f4:	f103f81f 	cmp	x0, #0xfe
    84f8:	54fff781 	b.ne	83e8 <fwp_drop2+0x148>  // b.any
    84fc:	39400280 	ldrb	w0, [x20]
    8500:	7103fc1f 	cmp	w0, #0xff
    8504:	540000e0 	b.eq	8520 <fwp_drop2+0x280>  // b.none
    8508:	12800020 	mov	w0, #0xfffffffe            	// #-2
    850c:	39000280 	strb	w0, [x20]
    8510:	17ffffb6 	b	83e8 <fwp_drop2+0x148>
    8514:	aa1403e0 	mov	x0, x20
    8518:	97ffef87 	bl	4334 <fwp_rc_forget_slot.part.0>
    851c:	17ffffdc 	b	848c <fwp_drop2+0x1ec>
    8520:	aa1403e0 	mov	x0, x20
    8524:	97ffef84 	bl	4334 <fwp_rc_forget_slot.part.0>
    8528:	17fffff8 	b	8508 <fwp_drop2+0x268>
    852c:	d503201f 	nop

0000000000008530 <fwp_arg_drop23>:
    8530:	7100003f 	cmp	w1, #0x0
    8534:	7a400844 	ccmp	w2, #0x0, #0x4, eq	// eq = none
    8538:	54000041 	b.ne	8540 <fwp_arg_drop23+0x10>  // b.any
    853c:	d65f03c0 	ret
    8540:	f9400000 	ldr	x0, [x0]
    8544:	17ffff57 	b	82a0 <fwp_drop2>
    8548:	d503201f 	nop
    854c:	d503201f 	nop

0000000000008550 <f23>:
    8550:	d10203ff 	sub	sp, sp, #0x80
    8554:	f00000a1 	adrp	x1, 1f000 <fwp_fn_table+0xb30>
    8558:	f947f421 	ldr	x1, [x1, #4072]
    855c:	a9027bfd 	stp	x29, x30, [sp, #32]
    8560:	910083fd 	add	x29, sp, #0x20
    8564:	a9045bf5 	stp	x21, x22, [sp, #64]
    8568:	b0000395 	adrp	x21, 79000 <fwp_root_context+0xbb0>
    856c:	9118c2a3 	add	x3, x21, #0x630
    8570:	a90353f3 	stp	x19, x20, [sp, #48]
    8574:	aa0003f6 	mov	x22, x0
    8578:	a90563f7 	stp	x23, x24, [sp, #80]
    857c:	a9066bf9 	stp	x25, x26, [sp, #96]
    8580:	f949ec62 	ldr	x2, [x3, #5080]
    8584:	f9400024 	ldr	x4, [x1]
    8588:	f9000fe4 	str	x4, [sp, #24]
    858c:	d2800004 	mov	x4, #0x0                   	// #0
    8590:	f949d861 	ldr	x1, [x3, #5040]
    8594:	d370bc42 	lsl	x2, x2, #16
    8598:	b4001920 	cbz	x0, 88bc <f23+0x36c>
    859c:	f9400817 	ldr	x23, [x0, #16]
    85a0:	cb0102e1 	sub	x1, x23, x1
    85a4:	eb02003f 	cmp	x1, x2
    85a8:	540003e2 	b.cs	8624 <f23+0xd4>  // b.hs, b.nlast
    85ac:	f949fc60 	ldr	x0, [x3, #5112]
    85b0:	d350fc22 	lsr	x2, x1, #16
    85b4:	8b020842 	add	x2, x2, x2, lsl #2
    85b8:	8b020c02 	add	x2, x0, x2, lsl #3
    85bc:	f9401040 	ldr	x0, [x2, #32]
    85c0:	b4000320 	cbz	x0, 8624 <f23+0xd4>
    85c4:	39400043 	ldrb	w3, [x2]
    85c8:	7100087f 	cmp	w3, #0x2
    85cc:	540015e0 	b.eq	8888 <f23+0x338>  // b.none
    85d0:	7100047f 	cmp	w3, #0x1
    85d4:	54000241 	b.ne	861c <f23+0xcc>  // b.any
    85d8:	29430843 	ldp	w3, w2, [x2, #24]
    85dc:	92403c21 	and	x1, x1, #0xffff
    85e0:	9b037c21 	mul	x1, x1, x3
    85e4:	d360fc21 	lsr	x1, x1, #32
    85e8:	eb02003f 	cmp	x1, x2
    85ec:	54000182 	b.cs	861c <f23+0xcc>  // b.hs, b.nlast
    85f0:	8b010000 	add	x0, x0, x1
    85f4:	39400001 	ldrb	w1, [x0]
    85f8:	34000121 	cbz	w1, 861c <f23+0xcc>
    85fc:	900000c2 	adrp	x2, 20000 <__data_start>
    8600:	91014042 	add	x2, x2, #0x50
    8604:	b9413043 	ldr	w3, [x2, #304]
    8608:	35001463 	cbnz	w3, 8894 <f23+0x344>
    860c:	7103f43f 	cmp	w1, #0xfd
    8610:	54001888 	b.hi	8920 <f23+0x3d0>  // b.pmore
    8614:	11000421 	add	w1, w1, #0x1
    8618:	39000001 	strb	w1, [x0]
    861c:	d2800002 	mov	x2, #0x0                   	// #0
    8620:	b40000f6 	cbz	x22, 863c <f23+0xec>
    8624:	aa1603e1 	mov	x1, x22
    8628:	d2800002 	mov	x2, #0x0                   	// #0
    862c:	d503201f 	nop
    8630:	f9400821 	ldr	x1, [x1, #16]
    8634:	91000442 	add	x2, x2, #0x1
    8638:	b5ffffc1 	cbnz	x1, 8630 <f23+0xe0>
    863c:	b4001477 	cbz	x23, 88c8 <f23+0x378>
    8640:	aa1703e1 	mov	x1, x23
    8644:	d2800003 	mov	x3, #0x0                   	// #0
    8648:	f9400821 	ldr	x1, [x1, #16]
    864c:	91000463 	add	x3, x3, #0x1
    8650:	b5ffffc1 	cbnz	x1, 8648 <f23+0xf8>
    8654:	eb02007f 	cmp	x3, x2
    8658:	92fe0000 	mov	x0, #0xfffffffffffffff     	// #1152921504606846975
    865c:	9a829073 	csel	x19, x3, x2, ls	// ls = plast
    8660:	eb00027f 	cmp	x19, x0
    8664:	540010a8 	b.hi	8878 <f23+0x328>  // b.pmore
    8668:	d37ffa74 	lsl	x20, x19, #1
    866c:	52800041 	mov	w1, #0x2                   	// #2
    8670:	91000680 	add	x0, x20, #0x1
    8674:	d37df000 	lsl	x0, x0, #3
    8678:	97fff286 	bl	5090 <fwp_heap_alloc>
    867c:	aa0003f8 	mov	x24, x0
    8680:	9118c2a1 	add	x1, x21, #0x630
    8684:	aa0103e0 	mov	x0, x1
    8688:	f9000314 	str	x20, [x24]
    868c:	f949d821 	ldr	x1, [x1, #5040]
    8690:	f949ec00 	ldr	x0, [x0, #5080]
    8694:	cb010301 	sub	x1, x24, x1
    8698:	eb00403f 	cmp	x1, x0, lsl #16
    869c:	54000342 	b.cs	8704 <f23+0x1b4>  // b.hs, b.nlast
    86a0:	9118c2a2 	add	x2, x21, #0x630
    86a4:	d350fc20 	lsr	x0, x1, #16
    86a8:	8b000800 	add	x0, x0, x0, lsl #2
    86ac:	f949fc43 	ldr	x3, [x2, #5112]
    86b0:	d37df002 	lsl	x2, x0, #3
    86b4:	8b020060 	add	x0, x3, x2
    86b8:	f9401014 	ldr	x20, [x0, #32]
    86bc:	b4000254 	cbz	x20, 8704 <f23+0x1b4>
    86c0:	38626862 	ldrb	w2, [x3, x2]
    86c4:	7100085f 	cmp	w2, #0x2
    86c8:	54000ee0 	b.eq	88a4 <f23+0x354>  // b.none
    86cc:	7100045f 	cmp	w2, #0x1
    86d0:	540001a1 	b.ne	8704 <f23+0x1b4>  // b.any
    86d4:	29430002 	ldp	w2, w0, [x0, #24]
    86d8:	92403c21 	and	x1, x1, #0xffff
    86dc:	9b027c21 	mul	x1, x1, x2
    86e0:	d360fc21 	lsr	x1, x1, #32
    86e4:	eb00003f 	cmp	x1, x0
    86e8:	540000e2 	b.cs	8704 <f23+0x1b4>  // b.hs, b.nlast
    86ec:	8b010294 	add	x20, x20, x1
    86f0:	39400280 	ldrb	w0, [x20]
    86f4:	7103fc1f 	cmp	w0, #0xff
    86f8:	54001180 	b.eq	8928 <f23+0x3d8>  // b.none
    86fc:	52800020 	mov	w0, #0x1                   	// #1
    8700:	39000280 	strb	w0, [x20]
    8704:	b4000253 	cbz	x19, 874c <f23+0x1fc>
    8708:	8b131313 	add	x19, x24, x19, lsl #4
    870c:	aa1803f4 	mov	x20, x24
    8710:	aa1603fa 	mov	x26, x22
    8714:	aa1703f9 	mov	x25, x23
    8718:	f9400723 	ldr	x3, [x25, #8]
    871c:	f9400742 	ldr	x2, [x26, #8]
    8720:	f9400861 	ldr	x1, [x3, #16]
    8724:	f9400840 	ldr	x0, [x2, #16]
    8728:	fd400461 	ldr	d1, [x3, #8]
    872c:	fd400440 	ldr	d0, [x2, #8]
    8730:	97fff425 	bl	57c4 <w107>
    8734:	f9000680 	str	x0, [x20, #8]
    8738:	f8010e81 	str	x1, [x20, #16]!
    873c:	f9400b39 	ldr	x25, [x25, #16]
    8740:	f9400b5a 	ldr	x26, [x26, #16]
    8744:	eb14027f 	cmp	x19, x20
    8748:	54fffe81 	b.ne	8718 <f23+0x1c8>  // b.any
    874c:	aa1703e0 	mov	x0, x23
    8750:	97fffed4 	bl	82a0 <fwp_drop2>
    8754:	aa1603e0 	mov	x0, x22
    8758:	97fffed2 	bl	82a0 <fwp_drop2>
    875c:	f9400316 	ldr	x22, [x24]
    8760:	92800014 	mov	x20, #0xffffffffffffffff    	// #-1
    8764:	b4000236 	cbz	x22, 87a8 <f23+0x258>
    8768:	fd003be8 	str	d8, [sp, #112]
    876c:	2f00e408 	movi	d8, #0x0
    8770:	91002319 	add	x25, x24, #0x8
    8774:	91004317 	add	x23, x24, #0x10
    8778:	92800000 	mov	x0, #0xffffffffffffffff    	// #-1
    877c:	d2800013 	mov	x19, #0x0                   	// #0
    8780:	fc737b20 	ldr	d0, [x25, x19, lsl #3]
    8784:	f8737ae1 	ldr	x1, [x23, x19, lsl #3]
    8788:	91000a73 	add	x19, x19, #0x2
    878c:	1e602908 	fadd	d8, d8, d0
    8790:	97fff3bc 	bl	5680 <f128.constprop.0>
    8794:	aa0003f4 	mov	x20, x0
    8798:	eb1302df 	cmp	x22, x19
    879c:	54ffff28 	b.hi	8780 <f23+0x230>  // b.pmore
    87a0:	9e660116 	fmov	x22, d8
    87a4:	fd403be8 	ldr	d8, [sp, #112]
    87a8:	9118c2b5 	add	x21, x21, #0x630
    87ac:	aa1803e0 	mov	x0, x24
    87b0:	97fff984 	bl	6dc0 <fwp_drop4>
    87b4:	a900d3f6 	stp	x22, x20, [sp, #8]
    87b8:	910023e1 	add	x1, sp, #0x8
    87bc:	52800000 	mov	w0, #0x0                   	// #0
    87c0:	97fff514 	bl	5c10 <fwp_data.part.0.constprop.0>
    87c4:	f949daa1 	ldr	x1, [x21, #5040]
    87c8:	aa0003f3 	mov	x19, x0
    87cc:	f949eea0 	ldr	x0, [x21, #5080]
    87d0:	cb010261 	sub	x1, x19, x1
    87d4:	eb00403f 	cmp	x1, x0, lsl #16
    87d8:	54000322 	b.cs	883c <f23+0x2ec>  // b.hs, b.nlast
    87dc:	d350fc22 	lsr	x2, x1, #16
    87e0:	f949fea3 	ldr	x3, [x21, #5112]
    87e4:	8b020842 	add	x2, x2, x2, lsl #2
    87e8:	d37df042 	lsl	x2, x2, #3
    87ec:	8b020060 	add	x0, x3, x2
    87f0:	f9401014 	ldr	x20, [x0, #32]
    87f4:	b4000254 	cbz	x20, 883c <f23+0x2ec>
    87f8:	38626862 	ldrb	w2, [x3, x2]
    87fc:	7100085f 	cmp	w2, #0x2
    8800:	54000580 	b.eq	88b0 <f23+0x360>  // b.none
    8804:	7100045f 	cmp	w2, #0x1
    8808:	540001a1 	b.ne	883c <f23+0x2ec>  // b.any
    880c:	29430002 	ldp	w2, w0, [x0, #24]
    8810:	92403c21 	and	x1, x1, #0xffff
    8814:	9b027c21 	mul	x1, x1, x2
    8818:	d360fc21 	lsr	x1, x1, #32
    881c:	eb00003f 	cmp	x1, x0
    8820:	540000e2 	b.cs	883c <f23+0x2ec>  // b.hs, b.nlast
    8824:	8b010294 	add	x20, x20, x1
    8828:	39400280 	ldrb	w0, [x20]
    882c:	7103fc1f 	cmp	w0, #0xff
    8830:	54000820 	b.eq	8934 <f23+0x3e4>  // b.none
    8834:	52800020 	mov	w0, #0x1                   	// #1
    8838:	39000280 	strb	w0, [x20]
    883c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8840:	f947f400 	ldr	x0, [x0, #4072]
    8844:	f9400fe2 	ldr	x2, [sp, #24]
    8848:	f9400001 	ldr	x1, [x0]
    884c:	eb010042 	subs	x2, x2, x1
    8850:	d2800001 	mov	x1, #0x0                   	// #0
    8854:	540007a1 	b.ne	8948 <f23+0x3f8>  // b.any
    8858:	a9427bfd 	ldp	x29, x30, [sp, #32]
    885c:	aa1303e0 	mov	x0, x19
    8860:	a94353f3 	ldp	x19, x20, [sp, #48]
    8864:	a9445bf5 	ldp	x21, x22, [sp, #64]
    8868:	a94563f7 	ldp	x23, x24, [sp, #80]
    886c:	a9466bf9 	ldp	x25, x26, [sp, #96]
    8870:	910203ff 	add	sp, sp, #0x80
    8874:	d65f03c0 	ret
    8878:	f0000000 	adrp	x0, b000 <__modti3+0x2a0>
    887c:	911e0000 	add	x0, x0, #0x780
    8880:	fd003be8 	str	d8, [sp, #112]
    8884:	97ffee8c 	bl	42b4 <fwp_trap>
    8888:	72003c3f 	tst	w1, #0xffff
    888c:	54ffec81 	b.ne	861c <f23+0xcc>  // b.any
    8890:	17ffff59 	b	85f4 <f23+0xa4>
    8894:	f940ac43 	ldr	x3, [x2, #344]
    8898:	91000463 	add	x3, x3, #0x1
    889c:	f900ac43 	str	x3, [x2, #344]
    88a0:	17ffff5b 	b	860c <f23+0xbc>
    88a4:	72003c3f 	tst	w1, #0xffff
    88a8:	54fff2e1 	b.ne	8704 <f23+0x1b4>  // b.any
    88ac:	17ffff91 	b	86f0 <f23+0x1a0>
    88b0:	72003c3f 	tst	w1, #0xffff
    88b4:	54fffc41 	b.ne	883c <f23+0x2ec>  // b.any
    88b8:	17ffffdc 	b	8828 <f23+0x2d8>
    88bc:	cb0103e1 	neg	x1, x1
    88c0:	eb02003f 	cmp	x1, x2
    88c4:	540001e3 	b.cc	8900 <f23+0x3b0>  // b.lo, b.ul, b.last
    88c8:	52800041 	mov	w1, #0x2                   	// #2
    88cc:	d2800100 	mov	x0, #0x8                   	// #8
    88d0:	97fff1f0 	bl	5090 <fwp_heap_alloc>
    88d4:	aa0003f8 	mov	x24, x0
    88d8:	9118c2a0 	add	x0, x21, #0x630
    88dc:	f900031f 	str	xzr, [x24]
    88e0:	f949d801 	ldr	x1, [x0, #5040]
    88e4:	f949ec00 	ldr	x0, [x0, #5080]
    88e8:	cb010301 	sub	x1, x24, x1
    88ec:	eb00403f 	cmp	x1, x0, lsl #16
    88f0:	54000282 	b.cs	8940 <f23+0x3f0>  // b.hs, b.nlast
    88f4:	d2800013 	mov	x19, #0x0                   	// #0
    88f8:	d2800017 	mov	x23, #0x0                   	// #0
    88fc:	17ffff69 	b	86a0 <f23+0x150>
    8900:	f949fc62 	ldr	x2, [x3, #5112]
    8904:	d350fc20 	lsr	x0, x1, #16
    8908:	8b000800 	add	x0, x0, x0, lsl #2
    890c:	8b000c42 	add	x2, x2, x0, lsl #3
    8910:	f9401040 	ldr	x0, [x2, #32]
    8914:	b4fffda0 	cbz	x0, 88c8 <f23+0x378>
    8918:	d2800017 	mov	x23, #0x0                   	// #0
    891c:	17ffff2a 	b	85c4 <f23+0x74>
    8920:	97ffef99 	bl	4784 <fwp_rc_wide_dup>
    8924:	17ffff3e 	b	861c <f23+0xcc>
    8928:	aa1403e0 	mov	x0, x20
    892c:	97ffee82 	bl	4334 <fwp_rc_forget_slot.part.0>
    8930:	17ffff73 	b	86fc <f23+0x1ac>
    8934:	aa1403e0 	mov	x0, x20
    8938:	97ffee7f 	bl	4334 <fwp_rc_forget_slot.part.0>
    893c:	17ffffbe 	b	8834 <f23+0x2e4>
    8940:	d2800017 	mov	x23, #0x0                   	// #0
    8944:	17ffff82 	b	874c <f23+0x1fc>
    8948:	fd003be8 	str	d8, [sp, #112]
    894c:	97ffe7b1 	bl	2810 <__stack_chk_fail@plt>

0000000000008950 <fwp_owned_entry23>:
    8950:	f9400000 	ldr	x0, [x0]
    8954:	17fffeff 	b	8550 <f23>
    8958:	d503201f 	nop
    895c:	d503201f 	nop

0000000000008960 <e23>:
    8960:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8964:	910003fd 	mov	x29, sp
    8968:	f9000bf3 	str	x19, [sp, #16]
    896c:	f9400013 	ldr	x19, [x0]
    8970:	aa1303e0 	mov	x0, x19
    8974:	97fff507 	bl	5d90 <fwp_rc_share>
    8978:	aa1303e0 	mov	x0, x19
    897c:	97fffef5 	bl	8550 <f23>
    8980:	aa0003f3 	mov	x19, x0
    8984:	97fff503 	bl	5d90 <fwp_rc_share>
    8988:	aa1303e0 	mov	x0, x19
    898c:	f9400bf3 	ldr	x19, [sp, #16]
    8990:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8994:	d65f03c0 	ret
    8998:	d503201f 	nop
    899c:	d503201f 	nop

00000000000089a0 <fwp_caps12>:
    89a0:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    89a4:	910003fd 	mov	x29, sp
    89a8:	f9000bf3 	str	x19, [sp, #16]
    89ac:	aa0003f3 	mov	x19, x0
    89b0:	b9400400 	ldr	w0, [x0, #4]
    89b4:	340004a0 	cbz	w0, 8a48 <fwp_caps12+0xa8>
    89b8:	f9400660 	ldr	x0, [x19, #8]
    89bc:	350004e1 	cbnz	w1, 8a58 <fwp_caps12+0xb8>
    89c0:	97fff5f4 	bl	6190 <fwp_drop0>
    89c4:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    89c8:	9118c042 	add	x2, x2, #0x630
    89cc:	f949d840 	ldr	x0, [x2, #5040]
    89d0:	f949ec41 	ldr	x1, [x2, #5080]
    89d4:	cb000260 	sub	x0, x19, x0
    89d8:	eb01401f 	cmp	x0, x1, lsl #16
    89dc:	54000382 	b.cs	8a4c <fwp_caps12+0xac>  // b.hs, b.nlast
    89e0:	d350fc01 	lsr	x1, x0, #16
    89e4:	f949fc44 	ldr	x4, [x2, #5112]
    89e8:	8b010821 	add	x1, x1, x1, lsl #2
    89ec:	d37df021 	lsl	x1, x1, #3
    89f0:	8b010083 	add	x3, x4, x1
    89f4:	f9401062 	ldr	x2, [x3, #32]
    89f8:	b40002a2 	cbz	x2, 8a4c <fwp_caps12+0xac>
    89fc:	38616881 	ldrb	w1, [x4, x1]
    8a00:	7100083f 	cmp	w1, #0x2
    8a04:	54000740 	b.eq	8aec <fwp_caps12+0x14c>  // b.none
    8a08:	7100043f 	cmp	w1, #0x1
    8a0c:	54000201 	b.ne	8a4c <fwp_caps12+0xac>  // b.any
    8a10:	29430464 	ldp	w4, w1, [x3, #24]
    8a14:	92403c00 	and	x0, x0, #0xffff
    8a18:	9b047c00 	mul	x0, x0, x4
    8a1c:	d360fc00 	lsr	x0, x0, #32
    8a20:	eb01001f 	cmp	x0, x1
    8a24:	54000142 	b.cs	8a4c <fwp_caps12+0xac>  // b.hs, b.nlast
    8a28:	8b000042 	add	x2, x2, x0
    8a2c:	39400040 	ldrb	w0, [x2]
    8a30:	7100041f 	cmp	w0, #0x1
    8a34:	540000c1 	b.ne	8a4c <fwp_caps12+0xac>  // b.any
    8a38:	aa1303e0 	mov	x0, x19
    8a3c:	f9400bf3 	ldr	x19, [sp, #16]
    8a40:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8a44:	17ffeed7 	b	45a0 <fwp_mem_free>
    8a48:	34fffbe1 	cbz	w1, 89c4 <fwp_caps12+0x24>
    8a4c:	f9400bf3 	ldr	x19, [sp, #16]
    8a50:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8a54:	d65f03c0 	ret
    8a58:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8a5c:	9118c042 	add	x2, x2, #0x630
    8a60:	f949d843 	ldr	x3, [x2, #5040]
    8a64:	f949ec41 	ldr	x1, [x2, #5080]
    8a68:	cb030000 	sub	x0, x0, x3
    8a6c:	eb01401f 	cmp	x0, x1, lsl #16
    8a70:	54fffee2 	b.cs	8a4c <fwp_caps12+0xac>  // b.hs, b.nlast
    8a74:	d350fc01 	lsr	x1, x0, #16
    8a78:	f949fc44 	ldr	x4, [x2, #5112]
    8a7c:	8b010821 	add	x1, x1, x1, lsl #2
    8a80:	d37df021 	lsl	x1, x1, #3
    8a84:	8b010083 	add	x3, x4, x1
    8a88:	f9401062 	ldr	x2, [x3, #32]
    8a8c:	b4fffe02 	cbz	x2, 8a4c <fwp_caps12+0xac>
    8a90:	38616881 	ldrb	w1, [x4, x1]
    8a94:	7100083f 	cmp	w1, #0x2
    8a98:	54000300 	b.eq	8af8 <fwp_caps12+0x158>  // b.none
    8a9c:	7100043f 	cmp	w1, #0x1
    8aa0:	54fffd61 	b.ne	8a4c <fwp_caps12+0xac>  // b.any
    8aa4:	92403c01 	and	x1, x0, #0xffff
    8aa8:	29430064 	ldp	w4, w0, [x3, #24]
    8aac:	9b047c21 	mul	x1, x1, x4
    8ab0:	d360fc21 	lsr	x1, x1, #32
    8ab4:	eb00003f 	cmp	x1, x0
    8ab8:	54fffca2 	b.cs	8a4c <fwp_caps12+0xac>  // b.hs, b.nlast
    8abc:	8b010042 	add	x2, x2, x1
    8ac0:	39400040 	ldrb	w0, [x2]
    8ac4:	34fffc40 	cbz	w0, 8a4c <fwp_caps12+0xac>
    8ac8:	900000c1 	adrp	x1, 20000 <__data_start>
    8acc:	91014021 	add	x1, x1, #0x50
    8ad0:	b9413023 	ldr	w3, [x1, #304]
    8ad4:	35000183 	cbnz	w3, 8b04 <fwp_caps12+0x164>
    8ad8:	7103f41f 	cmp	w0, #0xfd
    8adc:	540001c8 	b.hi	8b14 <fwp_caps12+0x174>  // b.pmore
    8ae0:	11000400 	add	w0, w0, #0x1
    8ae4:	39000040 	strb	w0, [x2]
    8ae8:	17ffffd9 	b	8a4c <fwp_caps12+0xac>
    8aec:	72003c1f 	tst	w0, #0xffff
    8af0:	54fffae1 	b.ne	8a4c <fwp_caps12+0xac>  // b.any
    8af4:	17ffffce 	b	8a2c <fwp_caps12+0x8c>
    8af8:	72003c1f 	tst	w0, #0xffff
    8afc:	54fffa81 	b.ne	8a4c <fwp_caps12+0xac>  // b.any
    8b00:	17fffff0 	b	8ac0 <fwp_caps12+0x120>
    8b04:	f940ac23 	ldr	x3, [x1, #344]
    8b08:	91000463 	add	x3, x3, #0x1
    8b0c:	f900ac23 	str	x3, [x1, #344]
    8b10:	17fffff2 	b	8ad8 <fwp_caps12+0x138>
    8b14:	f9400bf3 	ldr	x19, [sp, #16]
    8b18:	aa0203e0 	mov	x0, x2
    8b1c:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8b20:	17ffef19 	b	4784 <fwp_rc_wide_dup>

0000000000008b24 <fwp_caps23>:
    8b24:	a9be7bfd 	stp	x29, x30, [sp, #-32]!
    8b28:	910003fd 	mov	x29, sp
    8b2c:	f9000bf3 	str	x19, [sp, #16]
    8b30:	aa0003f3 	mov	x19, x0
    8b34:	b9400400 	ldr	w0, [x0, #4]
    8b38:	340004a0 	cbz	w0, 8bcc <fwp_caps23+0xa8>
    8b3c:	f9400660 	ldr	x0, [x19, #8]
    8b40:	350004e1 	cbnz	w1, 8bdc <fwp_caps23+0xb8>
    8b44:	97fffdd7 	bl	82a0 <fwp_drop2>
    8b48:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8b4c:	9118c042 	add	x2, x2, #0x630
    8b50:	f949d840 	ldr	x0, [x2, #5040]
    8b54:	f949ec41 	ldr	x1, [x2, #5080]
    8b58:	cb000260 	sub	x0, x19, x0
    8b5c:	eb01401f 	cmp	x0, x1, lsl #16
    8b60:	54000382 	b.cs	8bd0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8b64:	d350fc01 	lsr	x1, x0, #16
    8b68:	f949fc44 	ldr	x4, [x2, #5112]
    8b6c:	8b010821 	add	x1, x1, x1, lsl #2
    8b70:	d37df021 	lsl	x1, x1, #3
    8b74:	8b010083 	add	x3, x4, x1
    8b78:	f9401062 	ldr	x2, [x3, #32]
    8b7c:	b40002a2 	cbz	x2, 8bd0 <fwp_caps23+0xac>
    8b80:	38616881 	ldrb	w1, [x4, x1]
    8b84:	7100083f 	cmp	w1, #0x2
    8b88:	54000740 	b.eq	8c70 <fwp_caps23+0x14c>  // b.none
    8b8c:	7100043f 	cmp	w1, #0x1
    8b90:	54000201 	b.ne	8bd0 <fwp_caps23+0xac>  // b.any
    8b94:	29430464 	ldp	w4, w1, [x3, #24]
    8b98:	92403c00 	and	x0, x0, #0xffff
    8b9c:	9b047c00 	mul	x0, x0, x4
    8ba0:	d360fc00 	lsr	x0, x0, #32
    8ba4:	eb01001f 	cmp	x0, x1
    8ba8:	54000142 	b.cs	8bd0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8bac:	8b000042 	add	x2, x2, x0
    8bb0:	39400040 	ldrb	w0, [x2]
    8bb4:	7100041f 	cmp	w0, #0x1
    8bb8:	540000c1 	b.ne	8bd0 <fwp_caps23+0xac>  // b.any
    8bbc:	aa1303e0 	mov	x0, x19
    8bc0:	f9400bf3 	ldr	x19, [sp, #16]
    8bc4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8bc8:	17ffee76 	b	45a0 <fwp_mem_free>
    8bcc:	34fffbe1 	cbz	w1, 8b48 <fwp_caps23+0x24>
    8bd0:	f9400bf3 	ldr	x19, [sp, #16]
    8bd4:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8bd8:	d65f03c0 	ret
    8bdc:	b0000382 	adrp	x2, 79000 <fwp_root_context+0xbb0>
    8be0:	9118c042 	add	x2, x2, #0x630
    8be4:	f949d843 	ldr	x3, [x2, #5040]
    8be8:	f949ec41 	ldr	x1, [x2, #5080]
    8bec:	cb030000 	sub	x0, x0, x3
    8bf0:	eb01401f 	cmp	x0, x1, lsl #16
    8bf4:	54fffee2 	b.cs	8bd0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8bf8:	d350fc01 	lsr	x1, x0, #16
    8bfc:	f949fc44 	ldr	x4, [x2, #5112]
    8c00:	8b010821 	add	x1, x1, x1, lsl #2
    8c04:	d37df021 	lsl	x1, x1, #3
    8c08:	8b010083 	add	x3, x4, x1
    8c0c:	f9401062 	ldr	x2, [x3, #32]
    8c10:	b4fffe02 	cbz	x2, 8bd0 <fwp_caps23+0xac>
    8c14:	38616881 	ldrb	w1, [x4, x1]
    8c18:	7100083f 	cmp	w1, #0x2
    8c1c:	54000300 	b.eq	8c7c <fwp_caps23+0x158>  // b.none
    8c20:	7100043f 	cmp	w1, #0x1
    8c24:	54fffd61 	b.ne	8bd0 <fwp_caps23+0xac>  // b.any
    8c28:	92403c01 	and	x1, x0, #0xffff
    8c2c:	29430064 	ldp	w4, w0, [x3, #24]
    8c30:	9b047c21 	mul	x1, x1, x4
    8c34:	d360fc21 	lsr	x1, x1, #32
    8c38:	eb00003f 	cmp	x1, x0
    8c3c:	54fffca2 	b.cs	8bd0 <fwp_caps23+0xac>  // b.hs, b.nlast
    8c40:	8b010042 	add	x2, x2, x1
    8c44:	39400040 	ldrb	w0, [x2]
    8c48:	34fffc40 	cbz	w0, 8bd0 <fwp_caps23+0xac>
    8c4c:	900000c1 	adrp	x1, 20000 <__data_start>
    8c50:	91014021 	add	x1, x1, #0x50
    8c54:	b9413023 	ldr	w3, [x1, #304]
    8c58:	35000183 	cbnz	w3, 8c88 <fwp_caps23+0x164>
    8c5c:	7103f41f 	cmp	w0, #0xfd
    8c60:	540001c8 	b.hi	8c98 <fwp_caps23+0x174>  // b.pmore
    8c64:	11000400 	add	w0, w0, #0x1
    8c68:	39000040 	strb	w0, [x2]
    8c6c:	17ffffd9 	b	8bd0 <fwp_caps23+0xac>
    8c70:	72003c1f 	tst	w0, #0xffff
    8c74:	54fffae1 	b.ne	8bd0 <fwp_caps23+0xac>  // b.any
    8c78:	17ffffce 	b	8bb0 <fwp_caps23+0x8c>
    8c7c:	72003c1f 	tst	w0, #0xffff
    8c80:	54fffa81 	b.ne	8bd0 <fwp_caps23+0xac>  // b.any
    8c84:	17fffff0 	b	8c44 <fwp_caps23+0x120>
    8c88:	f940ac23 	ldr	x3, [x1, #344]
    8c8c:	91000463 	add	x3, x3, #0x1
    8c90:	f900ac23 	str	x3, [x1, #344]
    8c94:	17fffff2 	b	8c5c <fwp_caps23+0x138>
    8c98:	f9400bf3 	ldr	x19, [sp, #16]
    8c9c:	aa0203e0 	mov	x0, x2
    8ca0:	a8c27bfd 	ldp	x29, x30, [sp], #32
    8ca4:	17ffeeb8 	b	4784 <fwp_rc_wide_dup>
    8ca8:	d503201f 	nop
    8cac:	d503201f 	nop

0000000000008cb0 <fwp_write>:
    8cb0:	a9b97bfd 	stp	x29, x30, [sp, #-112]!
    8cb4:	910003fd 	mov	x29, sp
    8cb8:	f00000a4 	adrp	x4, 1f000 <fwp_fn_table+0xb30>
    8cbc:	f947f484 	ldr	x4, [x4, #4072]
    8cc0:	a90153f3 	stp	x19, x20, [sp, #16]
    8cc4:	d10943ff 	sub	sp, sp, #0x250
    8cc8:	b9400045 	ldr	w5, [x2]
    8ccc:	aa0003f4 	mov	x20, x0
    8cd0:	f9400080 	ldr	x0, [x4]
    8cd4:	f90127e0 	str	x0, [sp, #584]
    8cd8:	d2800000 	mov	x0, #0x0                   	// #0
    8cdc:	710064bf 	cmp	w5, #0x19
    8ce0:	54000408 	b.hi	8d60 <fwp_write+0xb0>  // b.pmore
    8ce4:	90000020 	adrp	x0, c000 <_IO_stdin_used+0xf00>
    8ce8:	aa0103f3 	mov	x19, x1
    8cec:	9100c000 	add	x0, x0, #0x30
    8cf0:	f9013bf5 	str	x21, [sp, #624]
    8cf4:	f9013ff6 	str	x22, [sp, #632]
    8cf8:	f90153fb 	str	x27, [sp, #672]
    8cfc:	f90157fc 	str	x28, [sp, #680]
    8d00:	aa0203fc 	mov	x28, x2
    8d04:	78655800 	ldrh	w0, [x0, w5, uxtw #1]
    8d08:	10000061 	adr	x1, 8d14 <fwp_write+0x64>
    8d0c:	8b20a820 	add	x0, x1, w0, sxth #2
    8d10:	d61f0000 	br	x0
    8d14:	910123e0 	add	x0, sp, #0x48
    8d18:	aa1303e5 	mov	x5, x19
    8d1c:	f0000004 	adrp	x4, b000 <__modti3+0x2a0>
    8d20:	aa0003f3 	mov	x19, x0
    8d24:	91208084 	add	x4, x4, #0x820
    8d28:	d2804003 	mov	x3, #0x200                 	// #512
    8d2c:	aa0303e1 	mov	x1, x3
    8d30:	52800042 	mov	w2, #0x2                   	// #2
    8d34:	97ffe693 	bl	2780 <__snprintf_chk@plt>
    8d38:	aa1303e0 	mov	x0, x19
    8d3c:	97ffe659 	bl	26a0 <strlen@plt>
    8d40:	aa1303e1 	mov	x1, x19
    8d44:	aa0003e2 	mov	x2, x0
    8d48:	aa1403e0 	mov	x0, x20
    8d4c:	97ffea31 	bl	3610 <buf_put>
    8d50:	f9413bf5 	ldr	x21, [sp, #624]
    8d54:	f9413ff6 	ldr	x22, [sp, #632]
    8d58:	f94153fb 	ldr	x27, [sp, #672]
    8d5c:	f94157fc 	ldr	x28, [sp, #680]
    8d60:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8d64:	f947f400 	ldr	x0, [x0, #4072]
    8d68:	f94127e2 	ldr	x2, [sp, #584]
    8d6c:	f9400001 	ldr	x1, [x0]
    8d70:	eb010042 	subs	x2, x2, x1
    8d74:	d2800001 	mov	x1, #0x0                   	// #0
    8d78:	540077c1 	b.ne	9c70 <fwp_write+0xfc0>  // b.any
    8d7c:	910943ff 	add	sp, sp, #0x250
    8d80:	a94153f3 	ldp	x19, x20, [sp, #16]
    8d84:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8d88:	d65f03c0 	ret
    8d8c:	910123e0 	add	x0, sp, #0x48
    8d90:	aa1303e5 	mov	x5, x19
    8d94:	f0000004 	adrp	x4, b000 <__modti3+0x2a0>
    8d98:	aa0003f3 	mov	x19, x0
    8d9c:	91206084 	add	x4, x4, #0x818
    8da0:	d2804003 	mov	x3, #0x200                 	// #512
    8da4:	17ffffe2 	b	8d2c <fwp_write+0x7c>
    8da8:	71004cbf 	cmp	w5, #0x13
    8dac:	f0000000 	adrp	x0, b000 <__modti3+0x2a0>
    8db0:	f0000001 	adrp	x1, b000 <__modti3+0x2a0>
    8db4:	91202000 	add	x0, x0, #0x808
    8db8:	91204021 	add	x1, x1, #0x810
    8dbc:	d2800082 	mov	x2, #0x4                   	// #4
    8dc0:	9a801021 	csel	x1, x1, x0, ne	// ne = any
    8dc4:	aa1403e0 	mov	x0, x20
    8dc8:	f90143f7 	str	x23, [sp, #640]
    8dcc:	d2800016 	mov	x22, #0x0                   	// #0
    8dd0:	f90147f8 	str	x24, [sp, #648]
    8dd4:	97ffea0f 	bl	3610 <buf_put>
    8dd8:	f9400260 	ldr	x0, [x19]
    8ddc:	f0000017 	adrp	x23, b000 <__modti3+0x2a0>
    8de0:	d2800015 	mov	x21, #0x0                   	// #0
    8de4:	912242f7 	add	x23, x23, #0x890
    8de8:	b40047a0 	cbz	x0, 96dc <fwp_write+0xa2c>
    8dec:	b9400380 	ldr	w0, [x28]
    8df0:	52800003 	mov	w3, #0x0                   	// #0
    8df4:	f9401f82 	ldr	x2, [x28, #56]
    8df8:	71004c1f 	cmp	w0, #0x13
    8dfc:	9a9602a1 	csel	x1, x21, x22, eq	// eq = none
    8e00:	aa1403e0 	mov	x0, x20
    8e04:	8b010e61 	add	x1, x19, x1, lsl #3
    8e08:	f9400421 	ldr	x1, [x1, #8]
    8e0c:	97ffffa9 	bl	8cb0 <fwp_write>
    8e10:	b9400380 	ldr	w0, [x28]
    8e14:	7100481f 	cmp	w0, #0x12
    8e18:	54004b40 	b.eq	9780 <fwp_write+0xad0>  // b.none
    8e1c:	f9400260 	ldr	x0, [x19]
    8e20:	910006b5 	add	x21, x21, #0x1
    8e24:	91000ad6 	add	x22, x22, #0x2
    8e28:	eb15001f 	cmp	x0, x21
    8e2c:	54004589 	b.ls	96dc <fwp_write+0xa2c>  // b.plast
    8e30:	aa1703e1 	mov	x1, x23
    8e34:	aa1403e0 	mov	x0, x20
    8e38:	d2800042 	mov	x2, #0x2                   	// #2
    8e3c:	97ffe9f5 	bl	3610 <buf_put>
    8e40:	17ffffeb 	b	8dec <fwp_write+0x13c>
    8e44:	f0000001 	adrp	x1, b000 <__modti3+0x2a0>
    8e48:	91212021 	add	x1, x1, #0x848
    8e4c:	d28000c2 	mov	x2, #0x6                   	// #6
    8e50:	aa1403e0 	mov	x0, x20
    8e54:	91004273 	add	x19, x19, #0x10
    8e58:	97ffe9ee 	bl	3610 <buf_put>
    8e5c:	aa1303e0 	mov	x0, x19
    8e60:	97ffe610 	bl	26a0 <strlen@plt>
    8e64:	aa1303e1 	mov	x1, x19
    8e68:	aa0003e2 	mov	x2, x0
    8e6c:	aa1403e0 	mov	x0, x20
    8e70:	97ffe9e8 	bl	3610 <buf_put>
    8e74:	528007c3 	mov	w3, #0x3e                  	// #62
    8e78:	aa1403e0 	mov	x0, x20
    8e7c:	91001fe1 	add	x1, sp, #0x7
    8e80:	d2800022 	mov	x2, #0x1                   	// #1
    8e84:	39001fe3 	strb	w3, [sp, #7]
    8e88:	17ffffb1 	b	8d4c <fwp_write+0x9c>
    8e8c:	f00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    8e90:	f947f400 	ldr	x0, [x0, #4072]
    8e94:	f94127e2 	ldr	x2, [sp, #584]
    8e98:	f9400001 	ldr	x1, [x0]
    8e9c:	eb010042 	subs	x2, x2, x1
    8ea0:	d2800001 	mov	x1, #0x0                   	// #0
    8ea4:	540034e1 	b.ne	9540 <fwp_write+0x890>  // b.any
    8ea8:	f9413bf5 	ldr	x21, [sp, #624]
    8eac:	f0000001 	adrp	x1, b000 <__modti3+0x2a0>
    8eb0:	f9413ff6 	ldr	x22, [sp, #632]
    8eb4:	aa1403e0 	mov	x0, x20
    8eb8:	9120a021 	add	x1, x1, #0x828
    8ebc:	d2800142 	mov	x2, #0xa                   	// #10
    8ec0:	f94153fb 	ldr	x27, [sp, #672]
    8ec4:	f94157fc 	ldr	x28, [sp, #680]
    8ec8:	910943ff 	add	sp, sp, #0x250
    8ecc:	a94153f3 	ldp	x19, x20, [sp, #16]
    8ed0:	a8c77bfd 	ldp	x29, x30, [sp], #112
    8ed4:	17ffe9cf 	b	3610 <buf_put>
    8ed8:	f9400456 	ldr	x22, [x2, #8]
    8edc:	f90143f7 	str	x23, [sp, #640]
    8ee0:	f90147f8 	str	x24, [sp, #648]
    8ee4:	b4005b16 	cbz	x22, 9a44 <fwp_write+0xd94>
    8ee8:	aa1603e0 	mov	x0, x22
    8eec:	f0000001 	adrp	x1, b000 <__modti3+0x2a0>
    8ef0:	9122a021 	add	x1, x1, #0x8a8
    8ef4:	97ffe667 	bl	2890 <strcmp@plt>
    8ef8:	2a0003f5 	mov	w21, w0
    8efc:	34005fe0 	cbz	w0, 9af8 <fwp_write+0xe48>
    8f00:	aa1603e0 	mov	x0, x22
    8f04:	97ffe5e7 	bl	26a0 <strlen@plt>
    8f08:	aa1603e1 	mov	x1, x22
    8f0c:	aa0003e2 	mov	x2, x0
    8f10:	aa1403e0 	mov	x0, x20
    8f14:	97ffe9bf 	bl	3610 <buf_put>
    8f18:	52800403 	mov	w3, #0x20                  	// #32
    8f1c:	91001ff5 	add	x21, sp, #0x7
    8f20:	aa1503e1 	mov	x1, x21
    8f24:	aa1403e0 	mov	x0, x20
    8f28:	d2800022 	mov	x2, #0x1                   	// #1
    8f2c:	39001fe3 	strb	w3, [sp, #7]
    8f30:	97ffe9b8 	bl	3610 <buf_put>
    8f34:	52800f63 	mov	w3, #0x7b                  	// #123
    8f38:	aa1403e0 	mov	x0, x20
    8f3c:	aa1503e1 	mov	x1, x21
    8f40:	d2800022 	mov	x2, #0x1                   	// #1
    8f44:	39001fe3 	strb	w3, [sp, #7]
    8f48:	97ffe9b2 	bl	3610 <buf_put>
    8f4c:	b9401380 	ldr	w0, [x28, #16]
    8f50:	52800018 	mov	w24, #0x0                   	// #0
    8f54:	7100001f 	cmp	w0, #0x0
    8f58:	54003aad 	b.le	96ac <fwp_write+0x9fc>
    8f5c:	f9014bf9 	str	x25, [sp, #656]
    8f60:	f0000019 	adrp	x25, b000 <__modti3+0x2a0>
    8f64:	91234339 	add	x25, x25, #0x8d0
    8f68:	f9014ffa 	str	x26, [sp, #664]
    8f6c:	f000001a 	adrp	x26, b000 <__modti3+0x2a0>
    8f70:	9122435a 	add	x26, x26, #0x890
    8f74:	91002276 	add	x22, x19, #0x8
    8f78:	d2800013 	mov	x19, #0x0                   	// #0
    8f7c:	b5003e93 	cbnz	x19, 974c <fwp_write+0xa9c>
    8f80:	d37df277 	lsl	x23, x19, #3
    8f84:	34003cb8 	cbz	w24, 9718 <fwp_write+0xa68>
    8f88:	f9401382 	ldr	x2, [x28, #32]
    8f8c:	aa1403e0 	mov	x0, x20
    8f90:	f8737ac1 	ldr	x1, [x22, x19, lsl #3]
    8f94:	52800003 	mov	w3, #0x0                   	// #0
    8f98:	f8776842 	ldr	x2, [x2, x23]
    8f9c:	91000673 	add	x19, x19, #0x1
    8fa0:	97ffff44 	bl	8cb0 <fwp_write>
    8fa4:	b9401380 	ldr	w0, [x28, #16]
    8fa8:	6b13001f 	cmp	w0, w19
    8fac:	54fffe8c 	b.gt	8f7c <fwp_write+0x2cc>
    8fb0:	f9414bf9 	ldr	x25, [sp, #656]
    8fb4:	f9414ffa 	ldr	x26, [sp, #664]
    8fb8:	340037b8 	cbz	w24, 96ac <fwp_write+0x9fc>
    8fbc:	52800523 	mov	w3, #0x29                  	// #41
    8fc0:	aa1503e1 	mov	x1, x21
    8fc4:	aa1403e0 	mov	x0, x20
    8fc8:	d2800022 	mov	x2, #0x1                   	// #1
    8fcc:	39001fe3 	strb	w3, [sp, #7]
    8fd0:	97ffe990 	bl	3610 <buf_put>
    8fd4:	f9413bf5 	ldr	x21, [sp, #624]
    8fd8:	f9413ff6 	ldr	x22, [sp, #632]
    8fdc:	f94143f7 	ldr	x23, [sp, #640]
    8fe0:	f94147f8 	ldr	x24, [sp, #648]
    8fe4:	f94153fb 	ldr	x27, [sp, #672]
    8fe8:	f94157fc 	ldr	x28, [sp, #680]
    8fec:	17ffff5d 	b	8d60 <fwp_write+0xb0>
    8ff0:	b9404855 	ldr	w21, [x2, #72]
    8ff4:	aa1403e0 	mov	x0, x20
    8ff8:	93407eb6 	sxtw	x22, w21
    8ffc:	91000ac1 	add	x1, x22, #0x2
    9000:	97ffe950 	bl	3540 <buf_grow>
    9004:	a9400281 	ldp	x1, x0, [x20]
    9008:	528e8603 	mov	w3, #0x7430                	// #29744
    900c:	78206823 	strh	w3, [x1, x0]
    9010:	8b000022 	add	x2, x1, x0
    9014:	710002bf 	cmp	w21, #0x0
    9018:	540036cd 	b.le	96f0 <fwp_write+0xa40>
    901c:	110006a3 	add	w3, w21, #0x1
    9020:	b200f3e6 	mov	x6, #0x5555555555555555    	// #6148914691236517205
    9024:	b201f3e8 	mov	x8, #0xaaaaaaaaaaaaaaaa    	// #-6148914691236517206
    9028:	91000449 	add	x9, x2, #0x1
    902c:	8b23c043 	add	x3, x2, w3, sxtw
    9030:	f28aaac6 	movk	x6, #0x5556
    9034:	f2955568 	movk	x8, #0xaaab
    9038:	1400000d 	b	906c <fwp_write+0x3bc>
    903c:	d2800021 	mov	x1, #0x1                   	// #1
    9040:	528005a5 	mov	w5, #0x2d                  	// #45
    9044:	f100001f 	cmp	x0, #0x0
    9048:	9b467e60 	smulh	x0, x19, x6
    904c:	fa401a60 	ccmp	x19, #0x0, #0x0, ne	// ne = any
    9050:	381ff465 	strb	w5, [x3], #-1
    9054:	cb040000 	sub	x0, x0, x4
    9058:	9a9fa7e2 	cset	x2, lt	// lt = tstop
    905c:	cb020000 	sub	x0, x0, x2
    9060:	8b010013 	add	x19, x0, x1
    9064:	eb03013f 	cmp	x9, x3
    9068:	54003440 	b.eq	96f0 <fwp_write+0xa40>  // b.none
    906c:	9b467e60 	smulh	x0, x19, x6
    9070:	937ffe64 	asr	x4, x19, #63
    9074:	52800605 	mov	w5, #0x30                  	// #48
    9078:	cb040000 	sub	x0, x0, x4
    907c:	8b000400 	add	x0, x0, x0, lsl #1
    9080:	cb000260 	sub	x0, x19, x0
    9084:	91000c01 	add	x1, x0, #0x3
    9088:	9bc87c22 	umulh	x2, x1, x8
    908c:	927ff847 	and	x7, x2, #0xfffffffffffffffe
    9090:	8b4204e2 	add	x2, x7, x2, lsr #1
    9094:	eb020021 	subs	x1, x1, x2
    9098:	54fffd60 	b.eq	9044 <fwp_write+0x394>  // b.none
    909c:	f100043f 	cmp	x1, #0x1
    90a0:	54fffce1 	b.ne	903c <fwp_write+0x38c>  // b.any
    90a4:	d2800001 	mov	x1, #0x0                   	// #0
    90a8:	52800565 	mov	w5, #0x2b                  	// #43
    90ac:	17ffffe6 	b	9044 <fwp_write+0x394>
    90b0:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    90b4:	f947f400 	ldr	x0, [x0, #4072]
    90b8:	f94127e2 	ldr	x2, [sp, #584]
    90bc:	f9400001 	ldr	x1, [x0]
    90c0:	eb010042 	subs	x2, x2, x1
    90c4:	d2800001 	mov	x1, #0x0                   	// #0
    90c8:	540023c1 	b.ne	9540 <fwp_write+0x890>  // b.any
    90cc:	f9413bf5 	ldr	x21, [sp, #624]
    90d0:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    90d4:	f9413ff6 	ldr	x22, [sp, #632]
    90d8:	aa1403e0 	mov	x0, x20
    90dc:	9120e021 	add	x1, x1, #0x838
    90e0:	d2800102 	mov	x2, #0x8                   	// #8
    90e4:	17ffff77 	b	8ec0 <fwp_write+0x210>
    90e8:	aa1403e0 	mov	x0, x20
    90ec:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    90f0:	d28000c2 	mov	x2, #0x6                   	// #6
    90f4:	91226021 	add	x1, x1, #0x898
    90f8:	97ffe946 	bl	3610 <buf_put>
    90fc:	d2800015 	mov	x21, #0x0                   	// #0
    9100:	f9400263 	ldr	x3, [x19]
    9104:	f240f87f 	tst	x3, #0x7fffffffffffffff
    9108:	54002c60 	b.eq	9694 <fwp_write+0x9e4>  // b.none
    910c:	f9401f82 	ldr	x2, [x28, #56]
    9110:	f90143f7 	str	x23, [sp, #640]
    9114:	f90147f8 	str	x24, [sp, #648]
    9118:	d2800857 	mov	x23, #0x42                  	// #66
    911c:	f9014bf9 	str	x25, [sp, #656]
    9120:	d0000016 	adrp	x22, b000 <__modti3+0x2a0>
    9124:	f9014ffa 	str	x26, [sp, #664]
    9128:	912242d6 	add	x22, x22, #0x890
    912c:	d2800038 	mov	x24, #0x1                   	// #1
    9130:	f2a18017 	movk	x23, #0xc00, lsl #16
    9134:	d2809099 	mov	x25, #0x484                 	// #1156
    9138:	b40004a2 	cbz	x2, 91cc <fwp_write+0x51c>
    913c:	b9400040 	ldr	w0, [x2]
    9140:	7100701f 	cmp	w0, #0x1c
    9144:	540042c0 	b.eq	999c <fwp_write+0xcec>  // b.none
    9148:	71006c1f 	cmp	w0, #0x1b
    914c:	54000408 	b.hi	91cc <fwp_write+0x51c>  // b.pmore
    9150:	9ac02301 	lsl	x1, x24, x0
    9154:	ea17003f 	tst	x1, x23
    9158:	540036a1 	b.ne	982c <fwp_write+0xb7c>  // b.any
    915c:	ea19003f 	tst	x1, x25
    9160:	54003521 	b.ne	9804 <fwp_write+0xb54>  // b.any
    9164:	d2800424 	mov	x4, #0x21                  	// #33
    9168:	ea04003f 	tst	x1, x4
    916c:	54000300 	b.eq	91cc <fwp_write+0x51c>  // b.none
    9170:	b7f849c3 	tbnz	x3, #63, 9aa8 <fwp_write+0xdf8>
    9174:	91002261 	add	x1, x19, #0x8
    9178:	8b150021 	add	x1, x1, x21
    917c:	39400021 	ldrb	w1, [x1]
    9180:	7100001f 	cmp	w0, #0x0
    9184:	93401c23 	sxtb	x3, w1
    9188:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    918c:	d503201f 	nop
    9190:	aa1403e0 	mov	x0, x20
    9194:	52800003 	mov	w3, #0x0                   	// #0
    9198:	97fffec6 	bl	8cb0 <fwp_write>
    919c:	910006b5 	add	x21, x21, #0x1
    91a0:	f9400260 	ldr	x0, [x19]
    91a4:	9240f800 	and	x0, x0, #0x7fffffffffffffff
    91a8:	eb0002bf 	cmp	x21, x0
    91ac:	540026c2 	b.cs	9684 <fwp_write+0x9d4>  // b.hs, b.nlast
    91b0:	d2800042 	mov	x2, #0x2                   	// #2
    91b4:	aa1603e1 	mov	x1, x22
    91b8:	aa1403e0 	mov	x0, x20
    91bc:	97ffe915 	bl	3610 <buf_put>
    91c0:	f9401f82 	ldr	x2, [x28, #56]
    91c4:	f9400263 	ldr	x3, [x19]
    91c8:	b5fffba2 	cbnz	x2, 913c <fwp_write+0x48c>
    91cc:	d37df2a0 	lsl	x0, x21, #3
    91d0:	b7f83f03 	tbnz	x3, #63, 99b0 <fwp_write+0xd00>
    91d4:	91002261 	add	x1, x19, #0x8
    91d8:	8b000020 	add	x0, x1, x0
    91dc:	f9400001 	ldr	x1, [x0]
    91e0:	17ffffec 	b	9190 <fwp_write+0x4e0>
    91e4:	a9400e62 	ldp	x2, x3, [x19]
    91e8:	b7f83ca3 	tbnz	x3, #63, 997c <fwp_write+0xccc>
    91ec:	910123f5 	add	x21, sp, #0x48
    91f0:	aa1503e0 	mov	x0, x21
    91f4:	97ffe6eb 	bl	2da0 <fwp_fmt_u128>
    91f8:	aa1503e0 	mov	x0, x21
    91fc:	97ffe529 	bl	26a0 <strlen@plt>
    9200:	aa1503e1 	mov	x1, x21
    9204:	aa0003e2 	mov	x2, x0
    9208:	17fffed0 	b	8d48 <fwp_write+0x98>
    920c:	fd015be8 	str	d8, [sp, #688]
    9210:	1e270268 	fmov	s8, w19
    9214:	fd015fe9 	str	d9, [sp, #696]
    9218:	1e282100 	fcmp	s8, s8
    921c:	54004d26 	b.vs	9bc0 <fwp_write+0xf10>
    9220:	1e20c101 	fabs	s1, s8
    9224:	12b01000 	mov	w0, #0x7f7fffff            	// #2139095039
    9228:	1e270000 	fmov	s0, w0
    922c:	1e202020 	fcmp	s1, s0
    9230:	54002c0d 	b.le	97b0 <fwp_write+0xb00>
    9234:	1e202118 	fcmpe	s8, #0.0
    9238:	d0000002 	adrp	x2, b000 <__modti3+0x2a0>
    923c:	9109e042 	add	x2, x2, #0x278
    9240:	910123f5 	add	x21, sp, #0x48
    9244:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    9248:	911fa021 	add	x1, x1, #0x7e8
    924c:	aa1503e0 	mov	x0, x21
    9250:	9a81c041 	csel	x1, x2, x1, gt
    9254:	97ffe5bf 	bl	2950 <strcpy@plt>
    9258:	aa1503e0 	mov	x0, x21
    925c:	97ffe511 	bl	26a0 <strlen@plt>
    9260:	aa1503e1 	mov	x1, x21
    9264:	aa0003e2 	mov	x2, x0
    9268:	aa1403e0 	mov	x0, x20
    926c:	97ffe8e9 	bl	3610 <buf_put>
    9270:	f9413bf5 	ldr	x21, [sp, #624]
    9274:	f9413ff6 	ldr	x22, [sp, #632]
    9278:	f94153fb 	ldr	x27, [sp, #672]
    927c:	f94157fc 	ldr	x28, [sp, #680]
    9280:	fd415be8 	ldr	d8, [sp, #688]
    9284:	fd415fe9 	ldr	d9, [sp, #696]
    9288:	17fffeb6 	b	8d60 <fwp_write+0xb0>
    928c:	f9400276 	ldr	x22, [x19]
    9290:	34002e03 	cbz	w3, 9850 <fwp_write+0xba0>
    9294:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9298:	f947f400 	ldr	x0, [x0, #4072]
    929c:	f94127e2 	ldr	x2, [sp, #584]
    92a0:	f9400001 	ldr	x1, [x0]
    92a4:	eb010042 	subs	x2, x2, x1
    92a8:	d2800001 	mov	x1, #0x0                   	// #0
    92ac:	540014a1 	b.ne	9540 <fwp_write+0x890>  // b.any
    92b0:	aa1603e2 	mov	x2, x22
    92b4:	91002261 	add	x1, x19, #0x8
    92b8:	f9413bf5 	ldr	x21, [sp, #624]
    92bc:	aa1403e0 	mov	x0, x20
    92c0:	f9413ff6 	ldr	x22, [sp, #632]
    92c4:	17fffeff 	b	8ec0 <fwp_write+0x210>
    92c8:	fd015be8 	str	d8, [sp, #688]
    92cc:	9e670268 	fmov	d8, x19
    92d0:	fd015fe9 	str	d9, [sp, #696]
    92d4:	1e682100 	fcmp	d8, d8
    92d8:	54004746 	b.vs	9bc0 <fwp_write+0xf10>
    92dc:	1e60c101 	fabs	d1, d8
    92e0:	92f00200 	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
    92e4:	9e670000 	fmov	d0, x0
    92e8:	910123f5 	add	x21, sp, #0x48
    92ec:	52800033 	mov	w19, #0x1                   	// #1
    92f0:	1e602020 	fcmp	d1, d0
    92f4:	540001ad 	b.le	9328 <fwp_write+0x678>
    92f8:	1e602118 	fcmpe	d8, #0.0
    92fc:	d0000002 	adrp	x2, b000 <__modti3+0x2a0>
    9300:	9109e042 	add	x2, x2, #0x278
    9304:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    9308:	911fa021 	add	x1, x1, #0x7e8
    930c:	aa1503e0 	mov	x0, x21
    9310:	9a81c041 	csel	x1, x2, x1, gt
    9314:	97ffe58f 	bl	2950 <strcpy@plt>
    9318:	17ffffd0 	b	9258 <fwp_write+0x5a8>
    931c:	11000673 	add	w19, w19, #0x1
    9320:	71004a7f 	cmp	w19, #0x12
    9324:	54003860 	b.eq	9a30 <fwp_write+0xd80>  // b.none
    9328:	1e604100 	fmov	d0, d8
    932c:	2a1303e1 	mov	w1, w19
    9330:	aa1503e0 	mov	x0, x21
    9334:	97ffe913 	bl	3780 <fwp_format_g.constprop.0>
    9338:	aa1503e0 	mov	x0, x21
    933c:	d2800001 	mov	x1, #0x0                   	// #0
    9340:	97ffe4ec 	bl	26f0 <strtod@plt>
    9344:	1e602100 	fcmp	d8, d0
    9348:	54fffea1 	b.ne	931c <fwp_write+0x66c>  // b.any
    934c:	aa1503e0 	mov	x0, x21
    9350:	97ffe8e9 	bl	36f4 <fwp_finish_float>
    9354:	17ffffc1 	b	9258 <fwp_write+0x5a8>
    9358:	a9400e62 	ldp	x2, x3, [x19]
    935c:	910123f3 	add	x19, sp, #0x48
    9360:	aa1303e0 	mov	x0, x19
    9364:	97ffe68f 	bl	2da0 <fwp_fmt_u128>
    9368:	17fffe74 	b	8d38 <fwp_write+0x88>
    936c:	f90143f7 	str	x23, [sp, #640]
    9370:	f90147f8 	str	x24, [sp, #648]
    9374:	2a1303f8 	mov	w24, w19
    9378:	f9014bf9 	str	x25, [sp, #656]
    937c:	f9014ffa 	str	x26, [sp, #664]
    9380:	f13ffe7f 	cmp	x19, #0xfff
    9384:	54000049 	b.ls	938c <fwp_write+0x6dc>  // b.plast
    9388:	b9400278 	ldr	w24, [x19]
    938c:	f9400f80 	ldr	x0, [x28, #24]
    9390:	2a1803f5 	mov	w21, w24
    9394:	d37d7f18 	ubfiz	x24, x24, #3, #32
    9398:	d37ef6b9 	lsl	x25, x21, #2
    939c:	f8757816 	ldr	x22, [x0, x21, lsl #3]
    93a0:	aa1603e0 	mov	x0, x22
    93a4:	97ffe4bf 	bl	26a0 <strlen@plt>
    93a8:	aa1603e1 	mov	x1, x22
    93ac:	aa0003e2 	mov	x2, x0
    93b0:	aa1403e0 	mov	x0, x20
    93b4:	97ffe897 	bl	3610 <buf_put>
    93b8:	f9401780 	ldr	x0, [x28, #40]
    93bc:	b8757800 	ldr	w0, [x0, x21, lsl #2]
    93c0:	7100001f 	cmp	w0, #0x0
    93c4:	5400068d 	b.le	9494 <fwp_write+0x7e4>
    93c8:	91002276 	add	x22, x19, #0x8
    93cc:	91001ff5 	add	x21, sp, #0x7
    93d0:	d280001b 	mov	x27, #0x0                   	// #0
    93d4:	5280041a 	mov	w26, #0x20                  	// #32
    93d8:	f9401b80 	ldr	x0, [x28, #48]
    93dc:	aa1503e1 	mov	x1, x21
    93e0:	f87b7ad7 	ldr	x23, [x22, x27, lsl #3]
    93e4:	d2800022 	mov	x2, #0x1                   	// #1
    93e8:	f8786803 	ldr	x3, [x0, x24]
    93ec:	aa1403e0 	mov	x0, x20
    93f0:	f87b7873 	ldr	x19, [x3, x27, lsl #3]
    93f4:	39001ffa 	strb	w26, [sp, #7]
    93f8:	97ffe886 	bl	3610 <buf_put>
    93fc:	f13ffeff 	cmp	x23, #0xfff
    9400:	b9400261 	ldr	w1, [x19]
    9404:	1a9f97e0 	cset	w0, hi	// hi = pmore
    9408:	7100383f 	cmp	w1, #0xe
    940c:	54000160 	b.eq	9438 <fwp_write+0x788>  // b.none
    9410:	7100403f 	cmp	w1, #0x10
    9414:	54001a60 	b.eq	9760 <fwp_write+0xab0>  // b.none
    9418:	7100283f 	cmp	w1, #0xa
    941c:	54002aa0 	b.eq	9970 <fwp_write+0xcc0>  // b.none
    9420:	540014ac 	b.gt	96b4 <fwp_write+0xa04>
    9424:	71000c3f 	cmp	w1, #0x3
    9428:	540029ac 	b.gt	995c <fwp_write+0xcac>
    942c:	d37ffee0 	lsr	x0, x23, #63
    9430:	37f814a1 	tbnz	w1, #31, 96c4 <fwp_write+0xa14>
    9434:	d503201f 	nop
    9438:	34001460 	cbz	w0, 96c4 <fwp_write+0xa14>
    943c:	52800503 	mov	w3, #0x28                  	// #40
    9440:	aa1503e1 	mov	x1, x21
    9444:	aa1403e0 	mov	x0, x20
    9448:	d2800022 	mov	x2, #0x1                   	// #1
    944c:	39001fe3 	strb	w3, [sp, #7]
    9450:	97ffe870 	bl	3610 <buf_put>
    9454:	aa1303e2 	mov	x2, x19
    9458:	aa1703e1 	mov	x1, x23
    945c:	aa1403e0 	mov	x0, x20
    9460:	52800003 	mov	w3, #0x0                   	// #0
    9464:	97fffe13 	bl	8cb0 <fwp_write>
    9468:	52800523 	mov	w3, #0x29                  	// #41
    946c:	aa1503e1 	mov	x1, x21
    9470:	aa1403e0 	mov	x0, x20
    9474:	d2800022 	mov	x2, #0x1                   	// #1
    9478:	39001fe3 	strb	w3, [sp, #7]
    947c:	97ffe865 	bl	3610 <buf_put>
    9480:	f9401780 	ldr	x0, [x28, #40]
    9484:	9100077b 	add	x27, x27, #0x1
    9488:	b8796800 	ldr	w0, [x0, x25]
    948c:	6b1b001f 	cmp	w0, w27
    9490:	54fffa4c 	b.gt	93d8 <fwp_write+0x728>
    9494:	f9413bf5 	ldr	x21, [sp, #624]
    9498:	f9413ff6 	ldr	x22, [sp, #632]
    949c:	f94143f7 	ldr	x23, [sp, #640]
    94a0:	f94147f8 	ldr	x24, [sp, #648]
    94a4:	f9414bf9 	ldr	x25, [sp, #656]
    94a8:	f9414ffa 	ldr	x26, [sp, #664]
    94ac:	f94153fb 	ldr	x27, [sp, #672]
    94b0:	f94157fc 	ldr	x28, [sp, #680]
    94b4:	17fffe2b 	b	8d60 <fwp_write+0xb0>
    94b8:	52800783 	mov	w3, #0x3c                  	// #60
    94bc:	91001ff3 	add	x19, sp, #0x7
    94c0:	aa1303e1 	mov	x1, x19
    94c4:	d2800022 	mov	x2, #0x1                   	// #1
    94c8:	aa1403e0 	mov	x0, x20
    94cc:	39001fe3 	strb	w3, [sp, #7]
    94d0:	97ffe850 	bl	3610 <buf_put>
    94d4:	f9400795 	ldr	x21, [x28, #8]
    94d8:	aa1503e0 	mov	x0, x21
    94dc:	97ffe471 	bl	26a0 <strlen@plt>
    94e0:	aa1503e1 	mov	x1, x21
    94e4:	aa0003e2 	mov	x2, x0
    94e8:	aa1403e0 	mov	x0, x20
    94ec:	97ffe849 	bl	3610 <buf_put>
    94f0:	528007c3 	mov	w3, #0x3e                  	// #62
    94f4:	aa1303e1 	mov	x1, x19
    94f8:	aa1403e0 	mov	x0, x20
    94fc:	d2800022 	mov	x2, #0x1                   	// #1
    9500:	39001fe3 	strb	w3, [sp, #7]
    9504:	17fffe12 	b	8d4c <fwp_write+0x9c>
    9508:	f100067f 	cmp	x19, #0x1
    950c:	540025a0 	b.eq	99c0 <fwp_write+0xd10>  // b.none
    9510:	b100067f 	cmn	x19, #0x1
    9514:	54002bc0 	b.eq	9a8c <fwp_write+0xddc>  // b.none
    9518:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    951c:	911fc021 	add	x1, x1, #0x7f0
    9520:	d2800022 	mov	x2, #0x1                   	// #1
    9524:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9528:	f947f400 	ldr	x0, [x0, #4072]
    952c:	f94127e4 	ldr	x4, [sp, #584]
    9530:	f9400003 	ldr	x3, [x0]
    9534:	eb030084 	subs	x4, x4, x3
    9538:	d2800003 	mov	x3, #0x0                   	// #0
    953c:	54ffebe0 	b.eq	92b8 <fwp_write+0x608>  // b.none
    9540:	f90143f7 	str	x23, [sp, #640]
    9544:	f90147f8 	str	x24, [sp, #648]
    9548:	f9014bf9 	str	x25, [sp, #656]
    954c:	f9014ffa 	str	x26, [sp, #664]
    9550:	fd015be8 	str	d8, [sp, #688]
    9554:	fd015fe9 	str	d9, [sp, #696]
    9558:	97ffe4ae 	bl	2810 <__stack_chk_fail@plt>
    955c:	52800b63 	mov	w3, #0x5b                  	// #91
    9560:	91001ff5 	add	x21, sp, #0x7
    9564:	aa1503e1 	mov	x1, x21
    9568:	aa1403e0 	mov	x0, x20
    956c:	d2800022 	mov	x2, #0x1                   	// #1
    9570:	d0000016 	adrp	x22, b000 <__modti3+0x2a0>
    9574:	912242d6 	add	x22, x22, #0x890
    9578:	39001fe3 	strb	w3, [sp, #7]
    957c:	97ffe825 	bl	3610 <buf_put>
    9580:	b4000273 	cbz	x19, 95cc <fwp_write+0x91c>
    9584:	f9400661 	ldr	x1, [x19, #8]
    9588:	aa1403e0 	mov	x0, x20
    958c:	f9401f82 	ldr	x2, [x28, #56]
    9590:	52800003 	mov	w3, #0x0                   	// #0
    9594:	97fffdc7 	bl	8cb0 <fwp_write>
    9598:	f9400a73 	ldr	x19, [x19, #16]
    959c:	b4000193 	cbz	x19, 95cc <fwp_write+0x91c>
    95a0:	aa1603e1 	mov	x1, x22
    95a4:	aa1403e0 	mov	x0, x20
    95a8:	d2800042 	mov	x2, #0x2                   	// #2
    95ac:	97ffe819 	bl	3610 <buf_put>
    95b0:	f9400661 	ldr	x1, [x19, #8]
    95b4:	aa1403e0 	mov	x0, x20
    95b8:	f9401f82 	ldr	x2, [x28, #56]
    95bc:	52800003 	mov	w3, #0x0                   	// #0
    95c0:	97fffdbc 	bl	8cb0 <fwp_write>
    95c4:	f9400a73 	ldr	x19, [x19, #16]
    95c8:	b5fffed3 	cbnz	x19, 95a0 <fwp_write+0x8f0>
    95cc:	52800ba3 	mov	w3, #0x5d                  	// #93
    95d0:	aa1503e1 	mov	x1, x21
    95d4:	aa1403e0 	mov	x0, x20
    95d8:	d2800022 	mov	x2, #0x1                   	// #1
    95dc:	39001fe3 	strb	w3, [sp, #7]
    95e0:	17fffddb 	b	8d4c <fwp_write+0x9c>
    95e4:	aa1403e0 	mov	x0, x20
    95e8:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    95ec:	d28000c2 	mov	x2, #0x6                   	// #6
    95f0:	91220021 	add	x1, x1, #0x880
    95f4:	97ffe807 	bl	3610 <buf_put>
    95f8:	f9400260 	ldr	x0, [x19]
    95fc:	b40004c0 	cbz	x0, 9694 <fwp_write+0x9e4>
    9600:	910123f5 	add	x21, sp, #0x48
    9604:	91002276 	add	x22, x19, #0x8
    9608:	f90143f7 	str	x23, [sp, #640]
    960c:	d2800017 	mov	x23, #0x0                   	// #0
    9610:	f90147f8 	str	x24, [sp, #648]
    9614:	d0000018 	adrp	x24, b000 <__modti3+0x2a0>
    9618:	91222318 	add	x24, x24, #0x888
    961c:	f9014bf9 	str	x25, [sp, #656]
    9620:	d0000019 	adrp	x25, b000 <__modti3+0x2a0>
    9624:	91224339 	add	x25, x25, #0x890
    9628:	f9014ffa 	str	x26, [sp, #664]
    962c:	14000005 	b	9640 <fwp_write+0x990>
    9630:	aa1903e1 	mov	x1, x25
    9634:	aa1403e0 	mov	x0, x20
    9638:	d2800042 	mov	x2, #0x2                   	// #2
    963c:	97ffe7f5 	bl	3610 <buf_put>
    9640:	38776ac5 	ldrb	w5, [x22, x23]
    9644:	d2804003 	mov	x3, #0x200                 	// #512
    9648:	aa1803e4 	mov	x4, x24
    964c:	aa0303e1 	mov	x1, x3
    9650:	52800042 	mov	w2, #0x2                   	// #2
    9654:	aa1503e0 	mov	x0, x21
    9658:	910006f7 	add	x23, x23, #0x1
    965c:	97ffe449 	bl	2780 <__snprintf_chk@plt>
    9660:	aa1503e0 	mov	x0, x21
    9664:	97ffe40f 	bl	26a0 <strlen@plt>
    9668:	aa1503e1 	mov	x1, x21
    966c:	aa0003e2 	mov	x2, x0
    9670:	aa1403e0 	mov	x0, x20
    9674:	97ffe7e7 	bl	3610 <buf_put>
    9678:	f9400260 	ldr	x0, [x19]
    967c:	eb17001f 	cmp	x0, x23
    9680:	54fffd88 	b.hi	9630 <fwp_write+0x980>  // b.pmore
    9684:	f94143f7 	ldr	x23, [sp, #640]
    9688:	f94147f8 	ldr	x24, [sp, #648]
    968c:	f9414bf9 	ldr	x25, [sp, #656]
    9690:	f9414ffa 	ldr	x26, [sp, #664]
    9694:	52800ba3 	mov	w3, #0x5d                  	// #93
    9698:	aa1403e0 	mov	x0, x20
    969c:	91001fe1 	add	x1, sp, #0x7
    96a0:	d2800022 	mov	x2, #0x1                   	// #1
    96a4:	39001fe3 	strb	w3, [sp, #7]
    96a8:	17fffda9 	b	8d4c <fwp_write+0x9c>
    96ac:	52800fa3 	mov	w3, #0x7d                  	// #125
    96b0:	17fffe44 	b	8fc0 <fwp_write+0x310>
    96b4:	f10002ff 	cmp	x23, #0x0
    96b8:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    96bc:	71002c3f 	cmp	w1, #0xb
    96c0:	54ffebc0 	b.eq	9438 <fwp_write+0x788>  // b.none
    96c4:	aa1303e2 	mov	x2, x19
    96c8:	aa1703e1 	mov	x1, x23
    96cc:	aa1403e0 	mov	x0, x20
    96d0:	52800003 	mov	w3, #0x0                   	// #0
    96d4:	97fffd77 	bl	8cb0 <fwp_write>
    96d8:	17ffff6a 	b	9480 <fwp_write+0x7d0>
    96dc:	aa1403e0 	mov	x0, x20
    96e0:	91001fe1 	add	x1, sp, #0x7
    96e4:	52800fa3 	mov	w3, #0x7d                  	// #125
    96e8:	d2800022 	mov	x2, #0x1                   	// #1
    96ec:	17fffe38 	b	8fcc <fwp_write+0x31c>
    96f0:	a9400281 	ldp	x1, x0, [x20]
    96f4:	91000800 	add	x0, x0, #0x2
    96f8:	8b160000 	add	x0, x0, x22
    96fc:	f9000680 	str	x0, [x20, #8]
    9700:	3820683f 	strb	wzr, [x1, x0]
    9704:	f9413bf5 	ldr	x21, [sp, #624]
    9708:	f9413ff6 	ldr	x22, [sp, #632]
    970c:	f94153fb 	ldr	x27, [sp, #672]
    9710:	f94157fc 	ldr	x28, [sp, #680]
    9714:	17fffd93 	b	8d60 <fwp_write+0xb0>
    9718:	f9400f80 	ldr	x0, [x28, #24]
    971c:	f873781b 	ldr	x27, [x0, x19, lsl #3]
    9720:	aa1b03e0 	mov	x0, x27
    9724:	97ffe3df 	bl	26a0 <strlen@plt>
    9728:	aa1b03e1 	mov	x1, x27
    972c:	aa0003e2 	mov	x2, x0
    9730:	aa1403e0 	mov	x0, x20
    9734:	97ffe7b7 	bl	3610 <buf_put>
    9738:	aa1903e1 	mov	x1, x25
    973c:	aa1403e0 	mov	x0, x20
    9740:	d2800062 	mov	x2, #0x3                   	// #3
    9744:	97ffe7b3 	bl	3610 <buf_put>
    9748:	17fffe10 	b	8f88 <fwp_write+0x2d8>
    974c:	aa1a03e1 	mov	x1, x26
    9750:	aa1403e0 	mov	x0, x20
    9754:	d2800042 	mov	x2, #0x2                   	// #2
    9758:	97ffe7ae 	bl	3610 <buf_put>
    975c:	17fffe09 	b	8f80 <fwp_write+0x2d0>
    9760:	f9400660 	ldr	x0, [x19, #8]
    9764:	b4fffb00 	cbz	x0, 96c4 <fwp_write+0xa14>
    9768:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    976c:	9122a021 	add	x1, x1, #0x8a8
    9770:	97ffe448 	bl	2890 <strcmp@plt>
    9774:	7100001f 	cmp	w0, #0x0
    9778:	1a9f07e0 	cset	w0, ne	// ne = any
    977c:	17ffff2f 	b	9438 <fwp_write+0x788>
    9780:	aa1403e0 	mov	x0, x20
    9784:	d2800042 	mov	x2, #0x2                   	// #2
    9788:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    978c:	91228021 	add	x1, x1, #0x8a0
    9790:	97ffe7a0 	bl	3610 <buf_put>
    9794:	91004261 	add	x1, x19, #0x10
    9798:	aa1403e0 	mov	x0, x20
    979c:	f9402382 	ldr	x2, [x28, #64]
    97a0:	52800003 	mov	w3, #0x0                   	// #0
    97a4:	f8767821 	ldr	x1, [x1, x22, lsl #3]
    97a8:	97fffd42 	bl	8cb0 <fwp_write>
    97ac:	17fffd9c 	b	8e1c <fwp_write+0x16c>
    97b0:	1e22c109 	fcvt	d9, s8
    97b4:	910123f5 	add	x21, sp, #0x48
    97b8:	52800033 	mov	w19, #0x1                   	// #1
    97bc:	d503201f 	nop
    97c0:	1e604120 	fmov	d0, d9
    97c4:	2a1303e1 	mov	w1, w19
    97c8:	aa1503e0 	mov	x0, x21
    97cc:	97ffe7ed 	bl	3780 <fwp_format_g.constprop.0>
    97d0:	aa1503e0 	mov	x0, x21
    97d4:	d2800001 	mov	x1, #0x0                   	// #0
    97d8:	97ffe43a 	bl	28c0 <strtof@plt>
    97dc:	1e202100 	fcmp	s8, s0
    97e0:	54ffdb60 	b.eq	934c <fwp_write+0x69c>  // b.none
    97e4:	11000673 	add	w19, w19, #0x1
    97e8:	71002a7f 	cmp	w19, #0xa
    97ec:	54fffea1 	b.ne	97c0 <fwp_write+0xb10>  // b.any
    97f0:	1e604120 	fmov	d0, d9
    97f4:	aa1503e0 	mov	x0, x21
    97f8:	52800121 	mov	w1, #0x9                   	// #9
    97fc:	97ffe7e1 	bl	3780 <fwp_format_g.constprop.0>
    9800:	17fffed3 	b	934c <fwp_write+0x69c>
    9804:	d37ef6a1 	lsl	x1, x21, #2
    9808:	b7f81563 	tbnz	x3, #63, 9ab4 <fwp_write+0xe04>
    980c:	91002263 	add	x3, x19, #0x8
    9810:	8b010061 	add	x1, x3, x1
    9814:	b9400023 	ldr	w3, [x1]
    9818:	7100081f 	cmp	w0, #0x2
    981c:	2a0303e1 	mov	w1, w3
    9820:	93407c63 	sxtw	x3, w3
    9824:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    9828:	17fffe5a 	b	9190 <fwp_write+0x4e0>
    982c:	d37ffaa1 	lsl	x1, x21, #1
    9830:	b7f81363 	tbnz	x3, #63, 9a9c <fwp_write+0xdec>
    9834:	91002263 	add	x3, x19, #0x8
    9838:	8b010061 	add	x1, x3, x1
    983c:	79400021 	ldrh	w1, [x1]
    9840:	7100041f 	cmp	w0, #0x1
    9844:	93403c23 	sxth	x3, w1
    9848:	9a831021 	csel	x1, x1, x3, ne	// ne = any
    984c:	17fffe51 	b	9190 <fwp_write+0x4e0>
    9850:	52800443 	mov	w3, #0x22                  	// #34
    9854:	91001ff5 	add	x21, sp, #0x7
    9858:	91002273 	add	x19, x19, #0x8
    985c:	aa1503e1 	mov	x1, x21
    9860:	aa1403e0 	mov	x0, x20
    9864:	d2800022 	mov	x2, #0x1                   	// #1
    9868:	39001fe3 	strb	w3, [sp, #7]
    986c:	f90143f7 	str	x23, [sp, #640]
    9870:	8b160277 	add	x23, x19, x22
    9874:	f90147f8 	str	x24, [sp, #648]
    9878:	97ffe766 	bl	3610 <buf_put>
    987c:	b4000696 	cbz	x22, 994c <fwp_write+0xc9c>
    9880:	d0000018 	adrp	x24, b000 <__modti3+0x2a0>
    9884:	91214318 	add	x24, x24, #0x850
    9888:	f9014bf9 	str	x25, [sp, #656]
    988c:	d0000019 	adrp	x25, b000 <__modti3+0x2a0>
    9890:	9121c339 	add	x25, x25, #0x870
    9894:	f9014ffa 	str	x26, [sp, #664]
    9898:	1400000d 	b	98cc <fwp_write+0xc1c>
    989c:	710024bf 	cmp	w5, #0x9
    98a0:	54000460 	b.eq	992c <fwp_write+0xc7c>  // b.none
    98a4:	710028bf 	cmp	w5, #0xa
    98a8:	54000a61 	b.ne	99f4 <fwp_write+0xd44>  // b.any
    98ac:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    98b0:	aa1403e0 	mov	x0, x20
    98b4:	91218021 	add	x1, x1, #0x860
    98b8:	d2800042 	mov	x2, #0x2                   	// #2
    98bc:	97ffe755 	bl	3610 <buf_put>
    98c0:	91000673 	add	x19, x19, #0x1
    98c4:	eb17027f 	cmp	x19, x23
    98c8:	540003e0 	b.eq	9944 <fwp_write+0xc94>  // b.none
    98cc:	39400265 	ldrb	w5, [x19]
    98d0:	710034bf 	cmp	w5, #0xd
    98d4:	54000180 	b.eq	9904 <fwp_write+0xc54>  // b.none
    98d8:	54fffe29 	b.ls	989c <fwp_write+0xbec>  // b.plast
    98dc:	710088bf 	cmp	w5, #0x22
    98e0:	540001c0 	b.eq	9918 <fwp_write+0xc68>  // b.none
    98e4:	710170bf 	cmp	w5, #0x5c
    98e8:	54000741 	b.ne	99d0 <fwp_write+0xd20>  // b.any
    98ec:	aa1403e0 	mov	x0, x20
    98f0:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    98f4:	d2800042 	mov	x2, #0x2                   	// #2
    98f8:	91216021 	add	x1, x1, #0x858
    98fc:	97ffe745 	bl	3610 <buf_put>
    9900:	17fffff0 	b	98c0 <fwp_write+0xc10>
    9904:	aa1903e1 	mov	x1, x25
    9908:	aa1403e0 	mov	x0, x20
    990c:	d2800042 	mov	x2, #0x2                   	// #2
    9910:	97ffe740 	bl	3610 <buf_put>
    9914:	17ffffeb 	b	98c0 <fwp_write+0xc10>
    9918:	aa1803e1 	mov	x1, x24
    991c:	aa1403e0 	mov	x0, x20
    9920:	d2800042 	mov	x2, #0x2                   	// #2
    9924:	97ffe73b 	bl	3610 <buf_put>
    9928:	17ffffe6 	b	98c0 <fwp_write+0xc10>
    992c:	aa1403e0 	mov	x0, x20
    9930:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    9934:	d2800042 	mov	x2, #0x2                   	// #2
    9938:	9121a021 	add	x1, x1, #0x868
    993c:	97ffe735 	bl	3610 <buf_put>
    9940:	17ffffe0 	b	98c0 <fwp_write+0xc10>
    9944:	f9414bf9 	ldr	x25, [sp, #656]
    9948:	f9414ffa 	ldr	x26, [sp, #664]
    994c:	aa1503e1 	mov	x1, x21
    9950:	aa1403e0 	mov	x0, x20
    9954:	52800443 	mov	w3, #0x22                  	// #34
    9958:	17fffd9c 	b	8fc8 <fwp_write+0x318>
    995c:	7100103f 	cmp	w1, #0x4
    9960:	54ffeb21 	b.ne	96c4 <fwp_write+0xa14>  // b.any
    9964:	f94006e0 	ldr	x0, [x23, #8]
    9968:	d37ffc00 	lsr	x0, x0, #63
    996c:	17fffeb3 	b	9438 <fwp_write+0x788>
    9970:	710002ff 	cmp	w23, #0x0
    9974:	1a9fa7e0 	cset	w0, lt	// lt = tstop
    9978:	17fffeb0 	b	9438 <fwp_write+0x788>
    997c:	528005a1 	mov	w1, #0x2d                  	// #45
    9980:	eb0203e2 	negs	x2, x2
    9984:	da0303e3 	ngc	x3, x3
    9988:	910127e0 	add	x0, sp, #0x49
    998c:	910123f5 	add	x21, sp, #0x48
    9990:	390123e1 	strb	w1, [sp, #72]
    9994:	97ffe503 	bl	2da0 <fwp_fmt_u128>
    9998:	17fffe18 	b	91f8 <fwp_write+0x548>
    999c:	d37ceea1 	lsl	x1, x21, #4
    99a0:	b7f810a3 	tbnz	x3, #63, 9bb4 <fwp_write+0xf04>
    99a4:	91002260 	add	x0, x19, #0x8
    99a8:	8b010001 	add	x1, x0, x1
    99ac:	17fffdf9 	b	9190 <fwp_write+0x4e0>
    99b0:	f9400a61 	ldr	x1, [x19, #16]
    99b4:	8b010000 	add	x0, x0, x1
    99b8:	f9400001 	ldr	x1, [x0]
    99bc:	17fffdf5 	b	9190 <fwp_write+0x4e0>
    99c0:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    99c4:	d2800042 	mov	x2, #0x2                   	// #2
    99c8:	911fe021 	add	x1, x1, #0x7f8
    99cc:	17fffed6 	b	9524 <fwp_write+0x874>
    99d0:	7101fcbf 	cmp	w5, #0x7f
    99d4:	7a5f18a0 	ccmp	w5, #0x1f, #0x0, ne	// ne = any
    99d8:	540000e9 	b.ls	99f4 <fwp_write+0xd44>  // b.plast
    99dc:	aa1503e1 	mov	x1, x21
    99e0:	aa1403e0 	mov	x0, x20
    99e4:	d2800022 	mov	x2, #0x1                   	// #1
    99e8:	39001fe5 	strb	w5, [sp, #7]
    99ec:	97ffe709 	bl	3610 <buf_put>
    99f0:	17ffffb4 	b	98c0 <fwp_write+0xc10>
    99f4:	d2800203 	mov	x3, #0x10                  	// #16
    99f8:	d0000004 	adrp	x4, b000 <__modti3+0x2a0>
    99fc:	aa0303e1 	mov	x1, x3
    9a00:	9121e084 	add	x4, x4, #0x878
    9a04:	910123f6 	add	x22, sp, #0x48
    9a08:	52800042 	mov	w2, #0x2                   	// #2
    9a0c:	aa1603e0 	mov	x0, x22
    9a10:	97ffe35c 	bl	2780 <__snprintf_chk@plt>
    9a14:	aa1603e0 	mov	x0, x22
    9a18:	97ffe322 	bl	26a0 <strlen@plt>
    9a1c:	aa1603e1 	mov	x1, x22
    9a20:	aa0003e2 	mov	x2, x0
    9a24:	aa1403e0 	mov	x0, x20
    9a28:	97ffe6fa 	bl	3610 <buf_put>
    9a2c:	17ffffa5 	b	98c0 <fwp_write+0xc10>
    9a30:	1e604100 	fmov	d0, d8
    9a34:	aa1503e0 	mov	x0, x21
    9a38:	52800221 	mov	w1, #0x11                  	// #17
    9a3c:	97ffe751 	bl	3780 <fwp_format_g.constprop.0>
    9a40:	17fffe43 	b	934c <fwp_write+0x69c>
    9a44:	b9401040 	ldr	w0, [x2, #16]
    9a48:	350003c0 	cbnz	w0, 9ac0 <fwp_write+0xe10>
    9a4c:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9a50:	f947f400 	ldr	x0, [x0, #4072]
    9a54:	f94127e2 	ldr	x2, [sp, #584]
    9a58:	f9400001 	ldr	x1, [x0]
    9a5c:	eb010042 	subs	x2, x2, x1
    9a60:	d2800001 	mov	x1, #0x0                   	// #0
    9a64:	54ffd721 	b.ne	9548 <fwp_write+0x898>  // b.any
    9a68:	f9413bf5 	ldr	x21, [sp, #624]
    9a6c:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    9a70:	f9413ff6 	ldr	x22, [sp, #632]
    9a74:	aa1403e0 	mov	x0, x20
    9a78:	f94143f7 	ldr	x23, [sp, #640]
    9a7c:	91232021 	add	x1, x1, #0x8c8
    9a80:	f94147f8 	ldr	x24, [sp, #648]
    9a84:	d2800042 	mov	x2, #0x2                   	// #2
    9a88:	17fffd0e 	b	8ec0 <fwp_write+0x210>
    9a8c:	d0000001 	adrp	x1, b000 <__modti3+0x2a0>
    9a90:	d2800042 	mov	x2, #0x2                   	// #2
    9a94:	91200021 	add	x1, x1, #0x800
    9a98:	17fffea3 	b	9524 <fwp_write+0x874>
    9a9c:	f9400a63 	ldr	x3, [x19, #16]
    9aa0:	8b030021 	add	x1, x1, x3
    9aa4:	17ffff66 	b	983c <fwp_write+0xb8c>
    9aa8:	f9400a61 	ldr	x1, [x19, #16]
    9aac:	8b0102a1 	add	x1, x21, x1
    9ab0:	17fffdb3 	b	917c <fwp_write+0x4cc>
    9ab4:	f9400a63 	ldr	x3, [x19, #16]
    9ab8:	8b030021 	add	x1, x1, x3
    9abc:	17ffff56 	b	9814 <fwp_write+0xb64>
    9ac0:	b9404840 	ldr	w0, [x2, #72]
    9ac4:	91001ff5 	add	x21, sp, #0x7
    9ac8:	34ffa360 	cbz	w0, 8f34 <fwp_write+0x284>
    9acc:	52800503 	mov	w3, #0x28                  	// #40
    9ad0:	aa1403e0 	mov	x0, x20
    9ad4:	aa1503e1 	mov	x1, x21
    9ad8:	d2800022 	mov	x2, #0x1                   	// #1
    9adc:	39001fe3 	strb	w3, [sp, #7]
    9ae0:	97ffe6cc 	bl	3610 <buf_put>
    9ae4:	b9401380 	ldr	w0, [x28, #16]
    9ae8:	52800038 	mov	w24, #0x1                   	// #1
    9aec:	7100001f 	cmp	w0, #0x0
    9af0:	54ffa36c 	b.gt	8f5c <fwp_write+0x2ac>
    9af4:	17fffd32 	b	8fbc <fwp_write+0x30c>
    9af8:	f9014bf9 	str	x25, [sp, #656]
    9afc:	b00000b9 	adrp	x25, 1e000 <__FRAME_END__+0x10ad8>
    9b00:	f9014ffa 	str	x26, [sp, #664]
    9b04:	f9400676 	ldr	x22, [x19, #8]
    9b08:	91104333 	add	x19, x25, #0x410
    9b0c:	91002273 	add	x19, x19, #0x8
    9b10:	937ffed8 	asr	x24, x22, #63
    9b14:	aa1802c0 	orr	x0, x22, x24
    9b18:	b5000320 	cbnz	x0, 9b7c <fwp_write+0xecc>
    9b1c:	110006b5 	add	w21, w21, #0x1
    9b20:	710016bf 	cmp	w21, #0x5
    9b24:	54ffffc1 	b.ne	9b1c <fwp_write+0xe6c>  // b.any
    9b28:	b7f80578 	tbnz	x24, #63, 9bd4 <fwp_write+0xf24>
    9b2c:	910023f3 	add	x19, sp, #0x8
    9b30:	aa1603e2 	mov	x2, x22
    9b34:	aa1303e0 	mov	x0, x19
    9b38:	d2800003 	mov	x3, #0x0                   	// #0
    9b3c:	97ffe499 	bl	2da0 <fwp_fmt_u128>
    9b40:	910123f5 	add	x21, sp, #0x48
    9b44:	d0000003 	adrp	x3, b000 <__modti3+0x2a0>
    9b48:	aa1303e4 	mov	x4, x19
    9b4c:	aa1503e0 	mov	x0, x21
    9b50:	91230063 	add	x3, x3, #0x8c0
    9b54:	d2804002 	mov	x2, #0x200                 	// #512
    9b58:	52800041 	mov	w1, #0x2                   	// #2
    9b5c:	97ffe2d5 	bl	26b0 <__sprintf_chk@plt>
    9b60:	aa1503e0 	mov	x0, x21
    9b64:	97ffe2cf 	bl	26a0 <strlen@plt>
    9b68:	aa1503e1 	mov	x1, x21
    9b6c:	aa0003e2 	mov	x2, x0
    9b70:	aa1403e0 	mov	x0, x20
    9b74:	97ffe6a7 	bl	3610 <buf_put>
    9b78:	17fffe47 	b	9494 <fwp_write+0x7e4>
    9b7c:	f9400277 	ldr	x23, [x19]
    9b80:	aa1603e0 	mov	x0, x22
    9b84:	aa1803e1 	mov	x1, x24
    9b88:	aa1703e2 	mov	x2, x23
    9b8c:	937ffefa 	asr	x26, x23, #63
    9b90:	aa1a03e3 	mov	x3, x26
    9b94:	94000473 	bl	ad60 <__modti3>
    9b98:	aa010000 	orr	x0, x0, x1
    9b9c:	b40002c0 	cbz	x0, 9bf4 <fwp_write+0xf44>
    9ba0:	110006b5 	add	w21, w21, #0x1
    9ba4:	91004273 	add	x19, x19, #0x10
    9ba8:	710016bf 	cmp	w21, #0x5
    9bac:	54fffe81 	b.ne	9b7c <fwp_write+0xecc>  // b.any
    9bb0:	17ffffde 	b	9b28 <fwp_write+0xe78>
    9bb4:	f9400a60 	ldr	x0, [x19, #16]
    9bb8:	8b000021 	add	x1, x1, x0
    9bbc:	17fffd75 	b	9190 <fwp_write+0x4e0>
    9bc0:	528c29c0 	mov	w0, #0x614e                	// #24910
    9bc4:	910123f5 	add	x21, sp, #0x48
    9bc8:	72a009c0 	movk	w0, #0x4e, lsl #16
    9bcc:	b9004be0 	str	w0, [sp, #72]
    9bd0:	17fffda2 	b	9258 <fwp_write+0x5a8>
    9bd4:	528005a1 	mov	w1, #0x2d                  	// #45
    9bd8:	eb1603e2 	negs	x2, x22
    9bdc:	da1803e3 	ngc	x3, x24
    9be0:	910027e0 	add	x0, sp, #0x9
    9be4:	910023f3 	add	x19, sp, #0x8
    9be8:	390023e1 	strb	w1, [sp, #8]
    9bec:	97ffe46d 	bl	2da0 <fwp_fmt_u128>
    9bf0:	17ffffd4 	b	9b40 <fwp_write+0xe90>
    9bf4:	aa1703e2 	mov	x2, x23
    9bf8:	aa1a03e3 	mov	x3, x26
    9bfc:	aa1603e0 	mov	x0, x22
    9c00:	aa1803e1 	mov	x1, x24
    9c04:	94000377 	bl	a9e0 <__divti3>
    9c08:	aa0003e2 	mov	x2, x0
    9c0c:	aa0103e3 	mov	x3, x1
    9c10:	b7f80201 	tbnz	x1, #63, 9c50 <fwp_write+0xfa0>
    9c14:	910023f3 	add	x19, sp, #0x8
    9c18:	aa1303e0 	mov	x0, x19
    9c1c:	97ffe461 	bl	2da0 <fwp_fmt_u128>
    9c20:	937c7ea1 	sbfiz	x1, x21, #4, #32
    9c24:	91104339 	add	x25, x25, #0x410
    9c28:	910123f5 	add	x21, sp, #0x48
    9c2c:	aa1303e4 	mov	x4, x19
    9c30:	aa1503e0 	mov	x0, x21
    9c34:	d0000003 	adrp	x3, b000 <__modti3+0x2a0>
    9c38:	f8616b25 	ldr	x5, [x25, x1]
    9c3c:	9122e063 	add	x3, x3, #0x8b8
    9c40:	d2804002 	mov	x2, #0x200                 	// #512
    9c44:	52800041 	mov	w1, #0x2                   	// #2
    9c48:	97ffe29a 	bl	26b0 <__sprintf_chk@plt>
    9c4c:	17ffffc5 	b	9b60 <fwp_write+0xeb0>
    9c50:	528005a4 	mov	w4, #0x2d                  	// #45
    9c54:	eb0003e2 	negs	x2, x0
    9c58:	da0103e3 	ngc	x3, x1
    9c5c:	910027e0 	add	x0, sp, #0x9
    9c60:	910023f3 	add	x19, sp, #0x8
    9c64:	390023e4 	strb	w4, [sp, #8]
    9c68:	97ffe44e 	bl	2da0 <fwp_fmt_u128>
    9c6c:	17ffffed 	b	9c20 <fwp_write+0xf70>
    9c70:	f9013bf5 	str	x21, [sp, #624]
    9c74:	f9013ff6 	str	x22, [sp, #632]
    9c78:	f90143f7 	str	x23, [sp, #640]
    9c7c:	f90147f8 	str	x24, [sp, #648]
    9c80:	f9014bf9 	str	x25, [sp, #656]
    9c84:	f9014ffa 	str	x26, [sp, #664]
    9c88:	f90153fb 	str	x27, [sp, #672]
    9c8c:	f90157fc 	str	x28, [sp, #680]
    9c90:	fd015be8 	str	d8, [sp, #688]
    9c94:	fd015fe9 	str	d9, [sp, #696]
    9c98:	97ffe2de 	bl	2810 <__stack_chk_fail@plt>
    9c9c:	d503201f 	nop

0000000000009ca0 <fwp_main_thread>:
    9ca0:	d10603ff 	sub	sp, sp, #0x180
    9ca4:	d00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    9ca8:	f947f400 	ldr	x0, [x0, #4072]
    9cac:	a9127bfd 	stp	x29, x30, [sp, #288]
    9cb0:	910483fd 	add	x29, sp, #0x120
    9cb4:	a91353f3 	stp	x19, x20, [sp, #304]
    9cb8:	90000393 	adrp	x19, 79000 <fwp_root_context+0xbb0>
    9cbc:	9118c261 	add	x1, x19, #0x630
    9cc0:	a9145bf5 	stp	x21, x22, [sp, #320]
    9cc4:	a91563f7 	stp	x23, x24, [sp, #336]
    9cc8:	b953a421 	ldr	w1, [x1, #5028]
    9ccc:	a9166bf9 	stp	x25, x26, [sp, #352]
    9cd0:	f9400002 	ldr	x2, [x0]
    9cd4:	f9008fe2 	str	x2, [sp, #280]
    9cd8:	d2800002 	mov	x2, #0x0                   	// #0
    9cdc:	34000f21 	cbz	w1, 9ec0 <fwp_main_thread+0x220>
    9ce0:	9118c260 	add	x0, x19, #0x630
    9ce4:	b953a800 	ldr	w0, [x0, #5032]
    9ce8:	35000e40 	cbnz	w0, 9eb0 <fwp_main_thread+0x210>
    9cec:	f00000b5 	adrp	x21, 20000 <__data_start>
    9cf0:	f00000a2 	adrp	x2, 20000 <__data_start>
    9cf4:	910142b4 	add	x20, x21, #0x50
    9cf8:	91114042 	add	x2, x2, #0x450
    9cfc:	d2a80003 	mov	x3, #0x40000000            	// #1073741824
    9d00:	d2a00024 	mov	x4, #0x10000               	// #65536
    9d04:	910103f7 	add	x23, sp, #0x40
    9d08:	9100a3f6 	add	x22, sp, #0x28
    9d0c:	aa1703e0 	mov	x0, x23
    9d10:	d2800001 	mov	x1, #0x0                   	// #0
    9d14:	f90023e2 	str	x2, [sp, #64]
    9d18:	b9004bff 	str	wzr, [sp, #72]
    9d1c:	f9002be4 	str	x4, [sp, #80]
    9d20:	a90a0e96 	stp	x22, x3, [x20, #160]
    9d24:	97ffe253 	bl	2670 <sigaltstack@plt>
    9d28:	35000220 	cbnz	w0, 9d6c <fwp_main_thread+0xcc>
    9d2c:	4f000400 	movi	v0.4s, #0x0
    9d30:	910223e0 	add	x0, sp, #0x88
    9d34:	d0ffffc1 	adrp	x1, 3000 <fwp_flush+0xc>
    9d38:	9100c021 	add	x1, x1, #0x30
    9d3c:	f90043e1 	str	x1, [sp, #128]
    9d40:	52800082 	mov	w2, #0x4                   	// #4
    9d44:	72a10002 	movk	w2, #0x800, lsl #16
    9d48:	910203f8 	add	x24, sp, #0x80
    9d4c:	3d802000 	str	q0, [x0, #128]
    9d50:	b9010be2 	str	w2, [sp, #264]
    9d54:	ad000000 	stp	q0, q0, [x0]
    9d58:	ad010000 	stp	q0, q0, [x0, #32]
    9d5c:	ad020000 	stp	q0, q0, [x0, #64]
    9d60:	ad030000 	stp	q0, q0, [x0, #96]
    9d64:	97ffe29b 	bl	27d0 <sigemptyset@plt>
    9d68:	340000a0 	cbz	w0, 9d7c <fwp_main_thread+0xdc>
    9d6c:	d0000000 	adrp	x0, b000 <__modti3+0x2a0>
    9d70:	91236000 	add	x0, x0, #0x8d8
    9d74:	a91773fb 	stp	x27, x28, [sp, #368]
    9d78:	97ffe94f 	bl	42b4 <fwp_trap>
    9d7c:	aa1803e1 	mov	x1, x24
    9d80:	d2800002 	mov	x2, #0x0                   	// #0
    9d84:	52800160 	mov	w0, #0xb                   	// #11
    9d88:	97ffe2aa 	bl	2830 <sigaction@plt>
    9d8c:	35ffff00 	cbnz	w0, 9d6c <fwp_main_thread+0xcc>
    9d90:	aa1803e1 	mov	x1, x24
    9d94:	d2800002 	mov	x2, #0x0                   	// #0
    9d98:	528000e0 	mov	w0, #0x7                   	// #7
    9d9c:	97ffe2a5 	bl	2830 <sigaction@plt>
    9da0:	35fffe60 	cbnz	w0, 9d6c <fwp_main_thread+0xcc>
    9da4:	9118c27a 	add	x26, x19, #0x630
    9da8:	52800039 	mov	w25, #0x1                   	// #1
    9dac:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9db0:	910cc000 	add	x0, x0, #0x330
    9db4:	b9013299 	str	w25, [x20, #304]
    9db8:	fd4a1340 	ldr	d0, [x26, #5152]
    9dbc:	7e61d800 	ucvtf	d0, d0
    9dc0:	fd00a680 	str	d0, [x20, #328]
    9dc4:	940004c3 	bl	b0d0 <atexit>
    9dc8:	350056e0 	cbnz	w0, a8a4 <fwp_main_thread+0xc04>
    9dcc:	b943ca80 	ldr	w0, [x20, #968]
    9dd0:	340007c0 	cbz	w0, 9ec8 <fwp_main_thread+0x228>
    9dd4:	910142ba 	add	x26, x21, #0x50
    9dd8:	f9404f56 	ldr	x22, [x26, #152]
    9ddc:	b40013d6 	cbz	x22, a054 <fwp_main_thread+0x3b4>
    9de0:	910102d7 	add	x23, x22, #0x40
    9de4:	39414ad9 	ldrb	w25, [x22, #82]
    9de8:	52800038 	mov	w24, #0x1                   	// #1
    9dec:	39014ad8 	strb	w24, [x22, #82]
    9df0:	f94016c0 	ldr	x0, [x22, #40]
    9df4:	b40012e0 	cbz	x0, a050 <fwp_main_thread+0x3b0>
    9df8:	f94032c1 	ldr	x1, [x22, #96]
    9dfc:	394146c0 	ldrb	w0, [x22, #81]
    9e00:	b4000f01 	cbz	x1, 9fe0 <fwp_main_thread+0x340>
    9e04:	36000dc0 	tbz	w0, #0, 9fbc <fwp_main_thread+0x31c>
    9e08:	f9404f54 	ldr	x20, [x26, #152]
    9e0c:	f94022c0 	ldr	x0, [x22, #64]
    9e10:	39414a81 	ldrb	w1, [x20, #82]
    9e14:	370010e1 	tbnz	w1, #0, a030 <fwp_main_thread+0x390>
    9e18:	f9403281 	ldr	x1, [x20, #96]
    9e1c:	a911fe97 	stp	x23, xzr, [x20, #280]
    9e20:	f9009680 	str	x0, [x20, #296]
    9e24:	b4000040 	cbz	x0, 9e2c <fwp_main_thread+0x18c>
    9e28:	f9009014 	str	x20, [x0, #288]
    9e2c:	f90022d4 	str	x20, [x22, #64]
    9e30:	b4000101 	cbz	x1, 9e50 <fwp_main_thread+0x1b0>
    9e34:	f9409740 	ldr	x0, [x26, #296]
    9e38:	39015698 	strb	w24, [x20, #85]
    9e3c:	f9003681 	str	x1, [x20, #104]
    9e40:	a910829f 	stp	xzr, x0, [x20, #264]
    9e44:	b4000040 	cbz	x0, 9e4c <fwp_main_thread+0x1ac>
    9e48:	f9008414 	str	x20, [x0, #264]
    9e4c:	f9009754 	str	x20, [x26, #296]
    9e50:	39015a9f 	strb	wzr, [x20, #86]
    9e54:	97fff383 	bl	6c60 <fwp_block>
    9e58:	f9408e82 	ldr	x2, [x20, #280]
    9e5c:	b4000142 	cbz	x2, 9e84 <fwp_main_thread+0x1e4>
    9e60:	a9520281 	ldp	x1, x0, [x20, #288]
    9e64:	b4000f21 	cbz	x1, a048 <fwp_main_thread+0x3a8>
    9e68:	f9009420 	str	x0, [x1, #296]
    9e6c:	f9409680 	ldr	x0, [x20, #296]
    9e70:	b4000040 	cbz	x0, 9e78 <fwp_main_thread+0x1d8>
    9e74:	f9009001 	str	x1, [x0, #288]
    9e78:	91080280 	add	x0, x20, #0x200
    9e7c:	f900969f 	str	xzr, [x20, #296]
    9e80:	a931fc1f 	stp	xzr, xzr, [x0, #-232]
    9e84:	39415680 	ldrb	w0, [x20, #85]
    9e88:	3607fb40 	tbz	w0, #0, 9df0 <fwp_main_thread+0x150>
    9e8c:	a9508281 	ldp	x1, x0, [x20, #264]
    9e90:	b4002141 	cbz	x1, a2b8 <fwp_main_thread+0x618>
    9e94:	f9008820 	str	x0, [x1, #272]
    9e98:	b4000040 	cbz	x0, 9ea0 <fwp_main_thread+0x200>
    9e9c:	f9008401 	str	x1, [x0, #264]
    9ea0:	91080280 	add	x0, x20, #0x200
    9ea4:	3901569f 	strb	wzr, [x20, #85]
    9ea8:	a930fc1f 	stp	xzr, xzr, [x0, #-248]
    9eac:	17ffffd1 	b	9df0 <fwp_main_thread+0x150>
    9eb0:	d0ffffc0 	adrp	x0, 3000 <fwp_flush+0xc>
    9eb4:	912e1000 	add	x0, x0, #0xb84
    9eb8:	94000486 	bl	b0d0 <atexit>
    9ebc:	17ffff8c 	b	9cec <fwp_main_thread+0x4c>
    9ec0:	97ffe78c 	bl	3cf0 <fwp_heap_init>
    9ec4:	17ffff87 	b	9ce0 <fwp_main_thread+0x40>
    9ec8:	f941ca82 	ldr	x2, [x20, #912]
    9ecc:	a91773fb 	stp	x27, x28, [sp, #368]
    9ed0:	b0ffffe0 	adrp	x0, 6000 <fwp_owned_entry161+0xa0>
    9ed4:	b0ffffc1 	adrp	x1, 2000 <__abi_tag+0x1d50>
    9ed8:	910c8000 	add	x0, x0, #0x320
    9edc:	913b4021 	add	x1, x1, #0xed0
    9ee0:	d280001b 	mov	x27, #0x0                   	// #0
    9ee4:	d290001c 	mov	x28, #0x8000                	// #32768
    9ee8:	f90007ff 	str	xzr, [sp, #8]
    9eec:	390043f9 	strb	w25, [sp, #16]
    9ef0:	a90287e2 	stp	x2, x1, [sp, #40]
    9ef4:	a903fff7 	stp	x23, xzr, [sp, #56]
    9ef8:	a90503ff 	stp	xzr, x0, [sp, #80]
    9efc:	f901ca96 	str	x22, [x20, #912]
    9f00:	14000012 	b	9f48 <fwp_main_thread+0x2a8>
    9f04:	7100045f 	cmp	w2, #0x1
    9f08:	540001a1 	b.ne	9f3c <fwp_main_thread+0x29c>  // b.any
    9f0c:	294308a6 	ldp	w6, w2, [x5, #24]
    9f10:	92403c21 	and	x1, x1, #0xffff
    9f14:	9b067c21 	mul	x1, x1, x6
    9f18:	d360fc21 	lsr	x1, x1, #32
    9f1c:	eb02003f 	cmp	x1, x2
    9f20:	540000e2 	b.cs	9f3c <fwp_main_thread+0x29c>  // b.hs, b.nlast
    9f24:	8b010000 	add	x0, x0, x1
    9f28:	39400001 	ldrb	w1, [x0]
    9f2c:	7103fc3f 	cmp	w1, #0xff
    9f30:	54004360 	b.eq	a79c <fwp_main_thread+0xafc>  // b.none
    9f34:	394043e1 	ldrb	w1, [sp, #16]
    9f38:	39000001 	strb	w1, [x0]
    9f3c:	a9047ffb 	stp	x27, xzr, [sp, #64]
    9f40:	aa190294 	orr	x20, x20, x25
    9f44:	b4001bf4 	cbz	x20, a2c0 <fwp_main_thread+0x620>
    9f48:	f94007e0 	ldr	x0, [sp, #8]
    9f4c:	f1000794 	subs	x20, x28, #0x1
    9f50:	aa1803e1 	mov	x1, x24
    9f54:	f90027f4 	str	x20, [sp, #72]
    9f58:	da1f0019 	sbc	x25, x0, xzr
    9f5c:	52800020 	mov	w0, #0x1                   	// #1
    9f60:	f90007f9 	str	x25, [sp, #8]
    9f64:	aa1403fc 	mov	x28, x20
    9f68:	a9086ff4 	stp	x20, x27, [sp, #128]
    9f6c:	97ffef29 	bl	5c10 <fwp_data.part.0.constprop.0>
    9f70:	aa0003fb 	mov	x27, x0
    9f74:	f949db41 	ldr	x1, [x26, #5040]
    9f78:	f949ef40 	ldr	x0, [x26, #5080]
    9f7c:	cb010361 	sub	x1, x27, x1
    9f80:	eb00403f 	cmp	x1, x0, lsl #16
    9f84:	54fffdc2 	b.cs	9f3c <fwp_main_thread+0x29c>  // b.hs, b.nlast
    9f88:	d350fc22 	lsr	x2, x1, #16
    9f8c:	f949ff46 	ldr	x6, [x26, #5112]
    9f90:	8b020842 	add	x2, x2, x2, lsl #2
    9f94:	d37df042 	lsl	x2, x2, #3
    9f98:	8b0200c5 	add	x5, x6, x2
    9f9c:	f94010a0 	ldr	x0, [x5, #32]
    9fa0:	b4fffce0 	cbz	x0, 9f3c <fwp_main_thread+0x29c>
    9fa4:	386268c2 	ldrb	w2, [x6, x2]
    9fa8:	7100085f 	cmp	w2, #0x2
    9fac:	54fffac1 	b.ne	9f04 <fwp_main_thread+0x264>  // b.any
    9fb0:	72003c3f 	tst	w1, #0xffff
    9fb4:	54fffc41 	b.ne	9f3c <fwp_main_thread+0x29c>  // b.any
    9fb8:	17ffffdc 	b	9f28 <fwp_main_thread+0x288>
    9fbc:	97ffeadd 	bl	4b30 <fwp_now_ns>
    9fc0:	f94032c1 	ldr	x1, [x22, #96]
    9fc4:	eb01001f 	cmp	x0, x1
    9fc8:	540000ab 	b.lt	9fdc <fwp_main_thread+0x33c>  // b.tstop
    9fcc:	394142c0 	ldrb	w0, [x22, #80]
    9fd0:	37000060 	tbnz	w0, #0, 9fdc <fwp_main_thread+0x33c>
    9fd4:	aa1603e0 	mov	x0, x22
    9fd8:	97ffe5a6 	bl	3670 <fwp_cancel_tree.part.0>
    9fdc:	394146c0 	ldrb	w0, [x22, #81]
    9fe0:	f9404f54 	ldr	x20, [x26, #152]
    9fe4:	39414a82 	ldrb	w2, [x20, #82]
    9fe8:	3707f100 	tbnz	w0, #0, 9e08 <fwp_main_thread+0x168>
    9fec:	f94032c1 	ldr	x1, [x22, #96]
    9ff0:	370001c2 	tbnz	w2, #0, a028 <fwp_main_thread+0x388>
    9ff4:	f9403280 	ldr	x0, [x20, #96]
    9ff8:	b4000180 	cbz	x0, a028 <fwp_main_thread+0x388>
    9ffc:	b4000061 	cbz	x1, a008 <fwp_main_thread+0x368>
    a000:	eb01001f 	cmp	x0, x1
    a004:	9a81d000 	csel	x0, x0, x1, le
    a008:	f94022c1 	ldr	x1, [x22, #64]
    a00c:	a911fe97 	stp	x23, xzr, [x20, #280]
    a010:	f9009681 	str	x1, [x20, #296]
    a014:	b4003cc1 	cbz	x1, a7ac <fwp_main_thread+0xb0c>
    a018:	f9009034 	str	x20, [x1, #288]
    a01c:	aa0003e1 	mov	x1, x0
    a020:	f90022d4 	str	x20, [x22, #64]
    a024:	17ffff84 	b	9e34 <fwp_main_thread+0x194>
    a028:	f94022c0 	ldr	x0, [x22, #64]
    a02c:	17ffff7c 	b	9e1c <fwp_main_thread+0x17c>
    a030:	a911fe97 	stp	x23, xzr, [x20, #280]
    a034:	f9009680 	str	x0, [x20, #296]
    a038:	b4000040 	cbz	x0, a040 <fwp_main_thread+0x3a0>
    a03c:	f9009014 	str	x20, [x0, #288]
    a040:	f90022d4 	str	x20, [x22, #64]
    a044:	17ffff83 	b	9e50 <fwp_main_thread+0x1b0>
    a048:	f9000040 	str	x0, [x2]
    a04c:	17ffff89 	b	9e70 <fwp_main_thread+0x1d0>
    a050:	39014ad9 	strb	w25, [x22, #82]
    a054:	910142b4 	add	x20, x21, #0x50
    a058:	f941d680 	ldr	x0, [x20, #936]
    a05c:	b5000060 	cbnz	x0, a068 <fwp_main_thread+0x3c8>
    a060:	f941de80 	ldr	x0, [x20, #952]
    a064:	b4003c20 	cbz	x0, a7e8 <fwp_main_thread+0xb48>
    a068:	910142a0 	add	x0, x21, #0x50
    a06c:	f9404c00 	ldr	x0, [x0, #152]
    a070:	910142a1 	add	x1, x21, #0x50
    a074:	f941f026 	ldr	x6, [x1, #992]
    a078:	b903d83f 	str	wzr, [x1, #984]
    a07c:	eb0000df 	cmp	x6, x0
    a080:	54004ac1 	b.ne	a9d8 <fwp_main_thread+0xd38>  // b.any
    a084:	b40003c0 	cbz	x0, a0fc <fwp_main_thread+0x45c>
    a088:	f941c025 	ldr	x5, [x1, #896]
    a08c:	52800021 	mov	w1, #0x1                   	// #1
    a090:	39014801 	strb	w1, [x0, #82]
    a094:	b4000345 	cbz	x5, a0fc <fwp_main_thread+0x45c>
    a098:	394140a0 	ldrb	w0, [x5, #80]
    a09c:	37000060 	tbnz	w0, #0, a0a8 <fwp_main_thread+0x408>
    a0a0:	aa0503e0 	mov	x0, x5
    a0a4:	97ffe573 	bl	3670 <fwp_cancel_tree.part.0>
    a0a8:	f9409ca5 	ldr	x5, [x5, #312]
    a0ac:	b5ffff65 	cbnz	x5, a098 <fwp_main_thread+0x3f8>
    a0b0:	910142b4 	add	x20, x21, #0x50
    a0b4:	52800036 	mov	w22, #0x1                   	// #1
    a0b8:	f94028c0 	ldr	x0, [x6, #80]
    a0bc:	f2001c1f 	tst	x0, #0xff000000ff
    a0c0:	540000e1 	b.ne	a0dc <fwp_main_thread+0x43c>  // b.any
    a0c4:	f9406280 	ldr	x0, [x20, #192]
    a0c8:	390150d6 	strb	w22, [x6, #84]
    a0cc:	f90080df 	str	xzr, [x6, #256]
    a0d0:	b4000120 	cbz	x0, a0f4 <fwp_main_thread+0x454>
    a0d4:	f9008006 	str	x6, [x0, #256]
    a0d8:	f9006286 	str	x6, [x20, #192]
    a0dc:	97fff2e1 	bl	6c60 <fwp_block>
    a0e0:	97fff268 	bl	6a80 <fwp_free_zombie>
    a0e4:	f941c280 	ldr	x0, [x20, #896]
    a0e8:	b40000a0 	cbz	x0, a0fc <fwp_main_thread+0x45c>
    a0ec:	f941f286 	ldr	x6, [x20, #992]
    a0f0:	17fffff2 	b	a0b8 <fwp_main_thread+0x418>
    a0f4:	f9006686 	str	x6, [x20, #200]
    a0f8:	17fffff8 	b	a0d8 <fwp_main_thread+0x438>
    a0fc:	910142b6 	add	x22, x21, #0x50
    a100:	97fff260 	bl	6a80 <fwp_free_zombie>
    a104:	f94066c0 	ldr	x0, [x22, #200]
    a108:	b5004680 	cbnz	x0, a9d8 <fwp_main_thread+0xd38>
    a10c:	f94096c0 	ldr	x0, [x22, #296]
    a110:	b5004640 	cbnz	x0, a9d8 <fwp_main_thread+0xd38>
    a114:	b94172c0 	ldr	w0, [x22, #368]
    a118:	340001e0 	cbz	w0, a154 <fwp_main_thread+0x4b4>
    a11c:	93407c17 	sxtw	x23, w0
    a120:	51000400 	sub	w0, w0, #0x1
    a124:	d1000af7 	sub	x23, x23, #0x2
    a128:	910602d8 	add	x24, x22, #0x180
    a12c:	cb2042f7 	sub	x23, x23, w0, uxtw
    a130:	93407c14 	sxtw	x20, w0
    a134:	d503201f 	nop
    a138:	f8747b00 	ldr	x0, [x24, x20, lsl #3]
    a13c:	d2a20001 	mov	x1, #0x10000000            	// #268435456
    a140:	b90172d4 	str	w20, [x22, #368]
    a144:	d1000694 	sub	x20, x20, #0x1
    a148:	97ffe1fa 	bl	2930 <munmap@plt>
    a14c:	eb17029f 	cmp	x20, x23
    a150:	54ffff41 	b.ne	a138 <fwp_main_thread+0x498>  // b.any
    a154:	d00000b4 	adrp	x20, 20000 <__data_start>
    a158:	91004280 	add	x0, x20, #0x10
    a15c:	b9402800 	ldr	w0, [x0, #40]
    a160:	37f80040 	tbnz	w0, #31, a168 <fwp_main_thread+0x4c8>
    a164:	97ffe1af 	bl	2820 <close@plt>
    a168:	910142b6 	add	x22, x21, #0x50
    a16c:	91004294 	add	x20, x20, #0x10
    a170:	12800001 	mov	w1, #0xffffffff            	// #-1
    a174:	f941fac0 	ldr	x0, [x22, #1008]
    a178:	b9002a81 	str	w1, [x20, #40]
    a17c:	f941f6c1 	ldr	x1, [x22, #1000]
    a180:	b40001c0 	cbz	x0, a1b8 <fwp_main_thread+0x518>
    a184:	d2800014 	mov	x20, #0x0                   	// #0
    a188:	f8747820 	ldr	x0, [x1, x20, lsl #3]
    a18c:	b40000e0 	cbz	x0, a1a8 <fwp_main_thread+0x508>
    a190:	f9400001 	ldr	x1, [x0]
    a194:	b5004221 	cbnz	x1, a9d8 <fwp_main_thread+0xd38>
    a198:	f9400401 	ldr	x1, [x0, #8]
    a19c:	b50041e1 	cbnz	x1, a9d8 <fwp_main_thread+0xd38>
    a1a0:	97ffe900 	bl	45a0 <fwp_mem_free>
    a1a4:	f941f6c1 	ldr	x1, [x22, #1000]
    a1a8:	91000694 	add	x20, x20, #0x1
    a1ac:	f941fac0 	ldr	x0, [x22, #1008]
    a1b0:	eb00029f 	cmp	x20, x0
    a1b4:	54fffea3 	b.cc	a188 <fwp_main_thread+0x4e8>  // b.lo, b.ul, b.last
    a1b8:	aa0103e0 	mov	x0, x1
    a1bc:	97ffe8f9 	bl	45a0 <fwp_mem_free>
    a1c0:	910142a0 	add	x0, x21, #0x50
    a1c4:	f941f014 	ldr	x20, [x0, #992]
    a1c8:	f901f41f 	str	xzr, [x0, #1000]
    a1cc:	f901f81f 	str	xzr, [x0, #1008]
    a1d0:	b40001f4 	cbz	x20, a20c <fwp_main_thread+0x56c>
    a1d4:	f9401681 	ldr	x1, [x20, #40]
    a1d8:	b5004001 	cbnz	x1, a9d8 <fwp_main_thread+0xd38>
    a1dc:	f9405681 	ldr	x1, [x20, #168]
    a1e0:	b5003fc1 	cbnz	x1, a9d8 <fwp_main_thread+0xd38>
    a1e4:	f941d401 	ldr	x1, [x0, #936]
    a1e8:	b5003f81 	cbnz	x1, a9d8 <fwp_main_thread+0xd38>
    a1ec:	f941dc00 	ldr	x0, [x0, #952]
    a1f0:	b5003f40 	cbnz	x0, a9d8 <fwp_main_thread+0xd38>
    a1f4:	d2823a02 	mov	x2, #0x11d0                	// #4560
    a1f8:	d0000360 	adrp	x0, 78000 <ad_raw_blocks+0x17bb0>
    a1fc:	91114000 	add	x0, x0, #0x450
    a200:	97ffe178 	bl	27e0 <memset@plt>
    a204:	aa1403e0 	mov	x0, x20
    a208:	97ffe8e6 	bl	45a0 <fwp_mem_free>
    a20c:	910142a6 	add	x6, x21, #0x50
    a210:	9118c273 	add	x19, x19, #0x630
    a214:	3dc016a2 	ldr	q2, [x21, #80]
    a218:	52800041 	mov	w1, #0x2                   	// #2
    a21c:	3dc004c1 	ldr	q1, [x6, #16]
    a220:	b0000002 	adrp	x2, b000 <__modti3+0x2a0>
    a224:	fd4a1260 	ldr	d0, [x19, #5152]
    a228:	9124e042 	add	x2, x2, #0x938
    a22c:	4ee18442 	add	v2.2d, v2.2d, v1.2d
    a230:	fd40a4c1 	ldr	d1, [x6, #328]
    a234:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a238:	f947e800 	ldr	x0, [x0, #4048]
    a23c:	7e61d800 	ucvtf	d0, d0
    a240:	a95390c3 	ldp	x3, x4, [x6, #312]
    a244:	f9004cdf 	str	xzr, [x6, #152]
    a248:	f9400000 	ldr	x0, [x0]
    a24c:	1e613801 	fsub	d1, d0, d1
    a250:	f940acc5 	ldr	x5, [x6, #344]
    a254:	b90130df 	str	wzr, [x6, #304]
    a258:	5ef1b842 	addp	d2, v2.2d
    a25c:	fd40a8c0 	ldr	d0, [x6, #336]
    a260:	f901f0df 	str	xzr, [x6, #992]
    a264:	fd0058c2 	str	d2, [x6, #176]
    a268:	97ffe186 	bl	2880 <__fprintf_chk@plt>
    a26c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a270:	f947ec00 	ldr	x0, [x0, #4056]
    a274:	f9400000 	ldr	x0, [x0]
    a278:	97ffe1b2 	bl	2940 <fflush@plt>
    a27c:	b00000a0 	adrp	x0, 1f000 <fwp_fn_table+0xb30>
    a280:	f947f400 	ldr	x0, [x0, #4072]
    a284:	f9408fe2 	ldr	x2, [sp, #280]
    a288:	f9400001 	ldr	x1, [x0]
    a28c:	eb010042 	subs	x2, x2, x1
    a290:	d2800001 	mov	x1, #0x0                   	// #0
    a294:	54003101 	b.ne	a8b4 <fwp_main_thread+0xc14>  // b.any
    a298:	a9527bfd 	ldp	x29, x30, [sp, #288]
    a29c:	d2800000 	mov	x0, #0x0                   	// #0
    a2a0:	a95353f3 	ldp	x19, x20, [sp, #304]
    a2a4:	a9545bf5 	ldp	x21, x22, [sp, #320]
    a2a8:	a95563f7 	ldp	x23, x24, [sp, #336]
    a2ac:	a9566bf9 	ldp	x25, x26, [sp, #352]
    a2b0:	910603ff 	add	sp, sp, #0x180
    a2b4:	d65f03c0 	ret
    a2b8:	f9009740 	str	x0, [x26, #296]
    a2bc:	17fffef7 	b	9e98 <fwp_main_thread+0x1f8>
    a2c0:	910142a2 	add	x2, x21, #0x50
    a2c4:	f90023ff 	str	xzr, [sp, #64]
    a2c8:	f941c840 	ldr	x0, [x2, #912]
    a2cc:	eb16001f 	cmp	x0, x22
    a2d0:	54003861 	b.ne	a9dc <fwp_main_thread+0xd3c>  // b.any
    a2d4:	d0000000 	adrp	x0, c000 <_IO_stdin_used+0xf00>
    a2d8:	910183e1 	add	x1, sp, #0x60
    a2dc:	f94017e3 	ldr	x3, [sp, #40]
    a2e0:	f901c843 	str	x3, [x2, #912]
    a2e4:	3dc03000 	ldr	q0, [x0, #192]
    a2e8:	52800020 	mov	w0, #0x1                   	// #1
    a2ec:	3d801be0 	str	q0, [sp, #96]
    a2f0:	97ffee48 	bl	5c10 <fwp_data.part.0.constprop.0>
    a2f4:	9118c263 	add	x3, x19, #0x630
    a2f8:	aa0003f4 	mov	x20, x0
    a2fc:	f949d861 	ldr	x1, [x3, #5040]
    a300:	f949ec60 	ldr	x0, [x3, #5080]
    a304:	cb010281 	sub	x1, x20, x1
    a308:	eb00403f 	cmp	x1, x0, lsl #16
    a30c:	54000322 	b.cs	a370 <fwp_main_thread+0x6d0>  // b.hs, b.nlast
    a310:	d350fc22 	lsr	x2, x1, #16
    a314:	f949fc63 	ldr	x3, [x3, #5112]
    a318:	8b020842 	add	x2, x2, x2, lsl #2
    a31c:	d37df042 	lsl	x2, x2, #3
    a320:	8b020060 	add	x0, x3, x2
    a324:	f9401016 	ldr	x22, [x0, #32]
    a328:	b4000256 	cbz	x22, a370 <fwp_main_thread+0x6d0>
    a32c:	38626862 	ldrb	w2, [x3, x2]
    a330:	7100085f 	cmp	w2, #0x2
    a334:	54002420 	b.eq	a7b8 <fwp_main_thread+0xb18>  // b.none
    a338:	7100045f 	cmp	w2, #0x1
    a33c:	540001a1 	b.ne	a370 <fwp_main_thread+0x6d0>  // b.any
    a340:	29430002 	ldp	w2, w0, [x0, #24]
    a344:	92403c21 	and	x1, x1, #0xffff
    a348:	9b027c21 	mul	x1, x1, x2
    a34c:	d360fc21 	lsr	x1, x1, #32
    a350:	eb00003f 	cmp	x1, x0
    a354:	540000e2 	b.cs	a370 <fwp_main_thread+0x6d0>  // b.hs, b.nlast
    a358:	8b0102d6 	add	x22, x22, x1
    a35c:	394002c0 	ldrb	w0, [x22]
    a360:	7103fc1f 	cmp	w0, #0xff
    a364:	54002600 	b.eq	a824 <fwp_main_thread+0xb84>  // b.none
    a368:	52800020 	mov	w0, #0x1                   	// #1
    a36c:	390002c0 	strb	w0, [x22]
    a370:	d2e7fe02 	mov	x2, #0x3ff0000000000000    	// #4607182418800017408
    a374:	aa1803e1 	mov	x1, x24
    a378:	52800020 	mov	w0, #0x1                   	// #1
    a37c:	a90853e2 	stp	x2, x20, [sp, #128]
    a380:	97ffee24 	bl	5c10 <fwp_data.part.0.constprop.0>
    a384:	9118c263 	add	x3, x19, #0x630
    a388:	aa0003f4 	mov	x20, x0
    a38c:	f949d861 	ldr	x1, [x3, #5040]
    a390:	f949ec60 	ldr	x0, [x3, #5080]
    a394:	cb010281 	sub	x1, x20, x1
    a398:	eb00403f 	cmp	x1, x0, lsl #16
    a39c:	54000322 	b.cs	a400 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a3a0:	d350fc22 	lsr	x2, x1, #16
    a3a4:	f949fc63 	ldr	x3, [x3, #5112]
    a3a8:	8b020842 	add	x2, x2, x2, lsl #2
    a3ac:	d37df042 	lsl	x2, x2, #3
    a3b0:	8b020060 	add	x0, x3, x2
    a3b4:	f9401016 	ldr	x22, [x0, #32]
    a3b8:	b4000256 	cbz	x22, a400 <fwp_main_thread+0x760>
    a3bc:	38626862 	ldrb	w2, [x3, x2]
    a3c0:	7100085f 	cmp	w2, #0x2
    a3c4:	54002000 	b.eq	a7c4 <fwp_main_thread+0xb24>  // b.none
    a3c8:	7100045f 	cmp	w2, #0x1
    a3cc:	540001a1 	b.ne	a400 <fwp_main_thread+0x760>  // b.any
    a3d0:	29430002 	ldp	w2, w0, [x0, #24]
    a3d4:	92403c21 	and	x1, x1, #0xffff
    a3d8:	9b027c21 	mul	x1, x1, x2
    a3dc:	d360fc21 	lsr	x1, x1, #32
    a3e0:	eb00003f 	cmp	x1, x0
    a3e4:	540000e2 	b.cs	a400 <fwp_main_thread+0x760>  // b.hs, b.nlast
    a3e8:	8b0102d6 	add	x22, x22, x1
    a3ec:	394002c0 	ldrb	w0, [x22]
    a3f0:	7103fc1f 	cmp	w0, #0xff
    a3f4:	540020c0 	b.eq	a80c <fwp_main_thread+0xb6c>  // b.none
    a3f8:	52800020 	mov	w0, #0x1                   	// #1
    a3fc:	390002c0 	strb	w0, [x22]
    a400:	b200e7e2 	mov	x2, #0x3333333333333333    	// #3689348814741910323
    a404:	9101c3e1 	add	x1, sp, #0x70
    a408:	f2f7fe62 	movk	x2, #0xbff3, lsl #48
    a40c:	52800020 	mov	w0, #0x1                   	// #1
    a410:	a90753e2 	stp	x2, x20, [sp, #112]
    a414:	97ffedff 	bl	5c10 <fwp_data.part.0.constprop.0>
    a418:	9118c262 	add	x2, x19, #0x630
    a41c:	aa0003f4 	mov	x20, x0
    a420:	f949d841 	ldr	x1, [x2, #5040]
    a424:	f949ec40 	ldr	x0, [x2, #5080]
    a428:	cb010281 	sub	x1, x20, x1
    a42c:	eb00403f 	cmp	x1, x0, lsl #16
    a430:	54000322 	b.cs	a494 <fwp_main_thread+0x7f4>  // b.hs, b.nlast
    a434:	d350fc20 	lsr	x0, x1, #16
    a438:	f949fc43 	ldr	x3, [x2, #5112]
    a43c:	8b000800 	add	x0, x0, x0, lsl #2
    a440:	d37df002 	lsl	x2, x0, #3
    a444:	8b020060 	add	x0, x3, x2
    a448:	f9401016 	ldr	x22, [x0, #32]
    a44c:	b4000256 	cbz	x22, a494 <fwp_main_thread+0x7f4>
    a450:	38626862 	ldrb	w2, [x3, x2]
    a454:	7100085f 	cmp	w2, #0x2
    a458:	54001bc0 	b.eq	a7d0 <fwp_main_thread+0xb30>  // b.none
    a45c:	7100045f 	cmp	w2, #0x1
    a460:	540001a1 	b.ne	a494 <fwp_main_thread+0x7f4>  // b.any
    a464:	29430002 	ldp	w2, w0, [x0, #24]
    a468:	92403c21 	and	x1, x1, #0xffff
    a46c:	9b027c21 	mul	x1, x1, x2
    a470:	d360fc21 	lsr	x1, x1, #32
    a474:	eb00003f 	cmp	x1, x0
    a478:	540000e2 	b.cs	a494 <fwp_main_thread+0x7f4>  // b.hs, b.nlast
    a47c:	8b0102d6 	add	x22, x22, x1
    a480:	394002c0 	ldrb	w0, [x22]
    a484:	7103fc1f 	cmp	w0, #0xff
    a488:	54001c80 	b.eq	a818 <fwp_main_thread+0xb78>  // b.none
    a48c:	52800020 	mov	w0, #0x1                   	// #1
    a490:	390002c0 	strb	w0, [x22]
    a494:	aa1b03f9 	mov	x25, x27
    a498:	900000a0 	adrp	x0, 1e000 <__FRAME_END__+0x10ad8>
    a49c:	b40016db 	cbz	x27, a774 <fwp_main_thread+0xad4>
    a4a0:	91104000 	add	x0, x0, #0x410
    a4a4:	b0000018 	adrp	x24, b000 <__modti3+0x2a0>
    a4a8:	91014016 	add	x22, x0, #0x50
    a4ac:	91050318 	add	x24, x24, #0x140
    a4b0:	9118c27a 	add	x26, x19, #0x630
    a4b4:	f949db42 	ldr	x2, [x26, #5040]
    a4b8:	f949ef40 	ldr	x0, [x26, #5080]
    a4bc:	cb020282 	sub	x2, x20, x2
    a4c0:	eb00405f 	cmp	x2, x0, lsl #16
    a4c4:	54000402 	b.cs	a544 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a4c8:	d350fc40 	lsr	x0, x2, #16
    a4cc:	f949ff45 	ldr	x5, [x26, #5112]
    a4d0:	8b000800 	add	x0, x0, x0, lsl #2
    a4d4:	d37df001 	lsl	x1, x0, #3
    a4d8:	8b0100a3 	add	x3, x5, x1
    a4dc:	f9401060 	ldr	x0, [x3, #32]
    a4e0:	b4000320 	cbz	x0, a544 <fwp_main_thread+0x8a4>
    a4e4:	386168a1 	ldrb	w1, [x5, x1]
    a4e8:	7100083f 	cmp	w1, #0x2
    a4ec:	54001780 	b.eq	a7dc <fwp_main_thread+0xb3c>  // b.none
    a4f0:	7100043f 	cmp	w1, #0x1
    a4f4:	54000281 	b.ne	a544 <fwp_main_thread+0x8a4>  // b.any
    a4f8:	92403c41 	and	x1, x2, #0xffff
    a4fc:	29430865 	ldp	w5, w2, [x3, #24]
    a500:	9b057c21 	mul	x1, x1, x5
    a504:	d360fc21 	lsr	x1, x1, #32
    a508:	eb02003f 	cmp	x1, x2
    a50c:	540001c2 	b.cs	a544 <fwp_main_thread+0x8a4>  // b.hs, b.nlast
    a510:	8b010000 	add	x0, x0, x1
    a514:	39400001 	ldrb	w1, [x0]
    a518:	34000161 	cbz	w1, a544 <fwp_main_thread+0x8a4>
    a51c:	910142a2 	add	x2, x21, #0x50
    a520:	b9413043 	ldr	w3, [x2, #304]
    a524:	34000083 	cbz	w3, a534 <fwp_main_thread+0x894>
    a528:	f940ac43 	ldr	x3, [x2, #344]
    a52c:	91000463 	add	x3, x3, #0x1
    a530:	f900ac43 	str	x3, [x2, #344]
    a534:	7103f43f 	cmp	w1, #0xfd
    a538:	540017c8 	b.hi	a830 <fwp_main_thread+0xb90>  // b.pmore
    a53c:	11000421 	add	w1, w1, #0x1
    a540:	39000001 	strb	w1, [x0]
    a544:	aa1603e2 	mov	x2, x22
    a548:	aa1403e1 	mov	x1, x20
    a54c:	aa1703e0 	mov	x0, x23
    a550:	52800023 	mov	w3, #0x1                   	// #1
    a554:	a9047fff 	stp	xzr, xzr, [sp, #64]
    a558:	f9002bff 	str	xzr, [sp, #80]
    a55c:	97fff9d5 	bl	8cb0 <fwp_write>
    a560:	a9440bfc 	ldp	x28, x2, [sp, #64]
    a564:	f100039f 	cmp	x28, #0x0
    a568:	9a9c031c 	csel	x28, x24, x28, eq	// eq = none
    a56c:	b100285f 	cmn	x2, #0xa
    a570:	54001648 	b.hi	a838 <fwp_main_thread+0xb98>  // b.pmore
    a574:	91002440 	add	x0, x2, #0x9
    a578:	52800021 	mov	w1, #0x1                   	// #1
    a57c:	f9000be2 	str	x2, [sp, #16]
    a580:	97ffeac4 	bl	5090 <fwp_heap_alloc>
    a584:	aa1c03e1 	mov	x1, x28
    a588:	aa0003fc 	mov	x28, x0
    a58c:	f9400be2 	ldr	x2, [sp, #16]
    a590:	f90007e0 	str	x0, [sp, #8]
    a594:	f8008782 	str	x2, [x28], #8
    a598:	aa1c03e0 	mov	x0, x28
    a59c:	97ffe031 	bl	2660 <memcpy@plt>
    a5a0:	a9408be0 	ldp	x0, x2, [sp, #8]
    a5a4:	8b020002 	add	x2, x0, x2
    a5a8:	3900205f 	strb	wzr, [x2, #8]
    a5ac:	f94023e0 	ldr	x0, [sp, #64]
    a5b0:	97ffe0c8 	bl	28d0 <free@plt>
    a5b4:	9118c260 	add	x0, x19, #0x630
    a5b8:	f94007e3 	ldr	x3, [sp, #8]
    a5bc:	f949d801 	ldr	x1, [x0, #5040]
    a5c0:	f949ec02 	ldr	x2, [x0, #5080]
    a5c4:	cb010061 	sub	x1, x3, x1
    a5c8:	eb02403f 	cmp	x1, x2, lsl #16
    a5cc:	54000322 	b.cs	a630 <fwp_main_thread+0x990>  // b.hs, b.nlast
    a5d0:	d350fc22 	lsr	x2, x1, #16
    a5d4:	d2800503 	mov	x3, #0x28                  	// #40
    a5d8:	f949fc05 	ldr	x5, [x0, #5112]
    a5dc:	9b037c42 	mul	x2, x2, x3
    a5e0:	8b0200a3 	add	x3, x5, x2
    a5e4:	f9401060 	ldr	x0, [x3, #32]
    a5e8:	b4000240 	cbz	x0, a630 <fwp_main_thread+0x990>
    a5ec:	386268a2 	ldrb	w2, [x5, x2]
    a5f0:	7100085f 	cmp	w2, #0x2
    a5f4:	540013a0 	b.eq	a868 <fwp_main_thread+0xbc8>  // b.none
    a5f8:	7100045f 	cmp	w2, #0x1
    a5fc:	540001a1 	b.ne	a630 <fwp_main_thread+0x990>  // b.any
    a600:	29430865 	ldp	w5, w2, [x3, #24]
    a604:	92403c21 	and	x1, x1, #0xffff
    a608:	9b057c21 	mul	x1, x1, x5
    a60c:	d360fc21 	lsr	x1, x1, #32
    a610:	eb02003f 	cmp	x1, x2
    a614:	540000e2 	b.cs	a630 <fwp_main_thread+0x990>  // b.hs, b.nlast
    a618:	8b010000 	add	x0, x0, x1
    a61c:	39400001 	ldrb	w1, [x0]
    a620:	7103fc3f 	cmp	w1, #0xff
    a624:	54001ce0 	b.eq	a9c0 <fwp_main_thread+0xd20>  // b.none
    a628:	52800021 	mov	w1, #0x1                   	// #1
    a62c:	39000001 	strb	w1, [x0]
    a630:	aa1403e0 	mov	x0, x20
    a634:	9118c265 	add	x5, x19, #0x630
    a638:	f949d8a1 	ldr	x1, [x5, #5040]
    a63c:	f949eca2 	ldr	x2, [x5, #5080]
    a640:	cb010001 	sub	x1, x0, x1
    a644:	eb02403f 	cmp	x1, x2, lsl #16
    a648:	54000382 	b.cs	a6b8 <fwp_main_thread+0xa18>  // b.hs, b.nlast
    a64c:	d350fc23 	lsr	x3, x1, #16
    a650:	d2800502 	mov	x2, #0x28                  	// #40
    a654:	f949fca7 	ldr	x7, [x5, #5112]
    a658:	9b027c63 	mul	x3, x3, x2
    a65c:	8b0300e6 	add	x6, x7, x3
    a660:	f94010c2 	ldr	x2, [x6, #32]
    a664:	b40002a2 	cbz	x2, a6b8 <fwp_main_thread+0xa18>
    a668:	386368e3 	ldrb	w3, [x7, x3]
    a66c:	7100087f 	cmp	w3, #0x2
    a670:	54000f60 	b.eq	a85c <fwp_main_thread+0xbbc>  // b.none
    a674:	7100047f 	cmp	w3, #0x1
    a678:	54000201 	b.ne	a6b8 <fwp_main_thread+0xa18>  // b.any
    a67c:	29430cc7 	ldp	w7, w3, [x6, #24]
    a680:	92403c21 	and	x1, x1, #0xffff
    a684:	9b077c21 	mul	x1, x1, x7
    a688:	d360fc21 	lsr	x1, x1, #32
    a68c:	eb03003f 	cmp	x1, x3
    a690:	54000142 	b.cs	a6b8 <fwp_main_thread+0xa18>  // b.hs, b.nlast
    a694:	8b010042 	add	x2, x2, x1
    a698:	39400041 	ldrb	w1, [x2]
    a69c:	340000e1 	cbz	w1, a6b8 <fwp_main_thread+0xa18>
    a6a0:	7100043f 	cmp	w1, #0x1
    a6a4:	54000d00 	b.eq	a844 <fwp_main_thread+0xba4>  // b.none
    a6a8:	7103fc3f 	cmp	w1, #0xff
    a6ac:	54001260 	b.eq	a8f8 <fwp_main_thread+0xc58>  // b.none
    a6b0:	51000421 	sub	w1, w1, #0x1
    a6b4:	39000041 	strb	w1, [x2]
    a6b8:	f94007e1 	ldr	x1, [sp, #8]
    a6bc:	910142a3 	add	x3, x21, #0x50
    a6c0:	aa1c03e0 	mov	x0, x28
    a6c4:	aa0303fc 	mov	x28, x3
    a6c8:	f9400022 	ldr	x2, [x1]
    a6cc:	d2800021 	mov	x1, #0x1                   	// #1
    a6d0:	f9404863 	ldr	x3, [x3, #144]
    a6d4:	97ffe08f 	bl	2910 <fwrite@plt>
    a6d8:	f9404b81 	ldr	x1, [x28, #144]
    a6dc:	52800140 	mov	w0, #0xa                   	// #10
    a6e0:	97ffe014 	bl	2730 <fputc@plt>
    a6e4:	9118c262 	add	x2, x19, #0x630
    a6e8:	f94007e3 	ldr	x3, [sp, #8]
    a6ec:	f949d841 	ldr	x1, [x2, #5040]
    a6f0:	f949ec40 	ldr	x0, [x2, #5080]
    a6f4:	cb010061 	sub	x1, x3, x1
    a6f8:	eb00403f 	cmp	x1, x0, lsl #16
    a6fc:	54000382 	b.cs	a76c <fwp_main_thread+0xacc>  // b.hs, b.nlast
    a700:	d350fc20 	lsr	x0, x1, #16
    a704:	d2800505 	mov	x5, #0x28                  	// #40
    a708:	f949fc43 	ldr	x3, [x2, #5112]
    a70c:	9b057c00 	mul	x0, x0, x5
    a710:	8b000062 	add	x2, x3, x0
    a714:	f940105c 	ldr	x28, [x2, #32]
    a718:	b40002bc 	cbz	x28, a76c <fwp_main_thread+0xacc>
    a71c:	38606863 	ldrb	w3, [x3, x0]
    a720:	7100087f 	cmp	w3, #0x2
    a724:	54000ba0 	b.eq	a898 <fwp_main_thread+0xbf8>  // b.none
    a728:	7100047f 	cmp	w3, #0x1
    a72c:	54000201 	b.ne	a76c <fwp_main_thread+0xacc>  // b.any
    a730:	29431440 	ldp	w0, w5, [x2, #24]
    a734:	92403c21 	and	x1, x1, #0xffff
    a738:	9b007c20 	mul	x0, x1, x0
    a73c:	d360fc00 	lsr	x0, x0, #32
    a740:	eb05001f 	cmp	x0, x5
    a744:	54000142 	b.cs	a76c <fwp_main_thread+0xacc>  // b.hs, b.nlast
    a748:	8b00039c 	add	x28, x28, x0
    a74c:	39400380 	ldrb	w0, [x28]
    a750:	340000e0 	cbz	w0, a76c <fwp_main_thread+0xacc>
    a754:	7100041f 	cmp	w0, #0x1
    a758:	540008e0 	b.eq	a874 <fwp_main_thread+0xbd4>  // b.none
    a75c:	7103fc1f 	cmp	w0, #0xff
    a760:	54000ae0 	b.eq	a8bc <fwp_main_thread+0xc1c>  // b.none
    a764:	51000400 	sub	w0, w0, #0x1
    a768:	39000380 	strb	w0, [x28]
    a76c:	f9400b39 	ldr	x25, [x25, #16]
    a770:	b5ffea39 	cbnz	x25, a4b4 <fwp_main_thread+0x814>
    a774:	aa1403e0 	mov	x0, x20
    a778:	97ffee86 	bl	6190 <fwp_drop0>
    a77c:	aa1b03e0 	mov	x0, x27
    a780:	97ffee84 	bl	6190 <fwp_drop0>
    a784:	910142a0 	add	x0, x21, #0x50
    a788:	52800021 	mov	w1, #0x1                   	// #1
    a78c:	a95773fb 	ldp	x27, x28, [sp, #368]
    a790:	b903c801 	str	w1, [x0, #968]
    a794:	f901e81f 	str	xzr, [x0, #976]
    a798:	17fffd8f 	b	9dd4 <fwp_main_thread+0x134>
    a79c:	f9000fe0 	str	x0, [sp, #24]
    a7a0:	97ffe6e5 	bl	4334 <fwp_rc_forget_slot.part.0>
    a7a4:	f9400fe0 	ldr	x0, [sp, #24]
    a7a8:	17fffde3 	b	9f34 <fwp_main_thread+0x294>
    a7ac:	aa0003e1 	mov	x1, x0
    a7b0:	f90022d4 	str	x20, [x22, #64]
    a7b4:	17fffda0 	b	9e34 <fwp_main_thread+0x194>
    a7b8:	72003c3f 	tst	w1, #0xffff
    a7bc:	54ffdda1 	b.ne	a370 <fwp_main_thread+0x6d0>  // b.any
    a7c0:	17fffee7 	b	a35c <fwp_main_thread+0x6bc>
    a7c4:	72003c3f 	tst	w1, #0xffff
    a7c8:	54ffe1c1 	b.ne	a400 <fwp_main_thread+0x760>  // b.any
    a7cc:	17ffff08 	b	a3ec <fwp_main_thread+0x74c>
    a7d0:	72003c3f 	tst	w1, #0xffff
    a7d4:	54ffe601 	b.ne	a494 <fwp_main_thread+0x7f4>  // b.any
    a7d8:	17ffff2a 	b	a480 <fwp_main_thread+0x7e0>
    a7dc:	72003c5f 	tst	w2, #0xffff
    a7e0:	54ffeb21 	b.ne	a544 <fwp_main_thread+0x8a4>  // b.any
    a7e4:	17ffff4c 	b	a514 <fwp_main_thread+0x874>
    a7e8:	f941d280 	ldr	x0, [x20, #928]
    a7ec:	97ffe76d 	bl	45a0 <fwp_mem_free>
    a7f0:	f901d29f 	str	xzr, [x20, #928]
    a7f4:	f9404e80 	ldr	x0, [x20, #152]
    a7f8:	f901da9f 	str	xzr, [x20, #944]
    a7fc:	b4ffc3a0 	cbz	x0, a070 <fwp_main_thread+0x3d0>
    a800:	f900541f 	str	xzr, [x0, #168]
    a804:	f9005c1f 	str	xzr, [x0, #184]
    a808:	17fffe1a 	b	a070 <fwp_main_thread+0x3d0>
    a80c:	aa1603e0 	mov	x0, x22
    a810:	97ffe6c9 	bl	4334 <fwp_rc_forget_slot.part.0>
    a814:	17fffef9 	b	a3f8 <fwp_main_thread+0x758>
    a818:	aa1603e0 	mov	x0, x22
    a81c:	97ffe6c6 	bl	4334 <fwp_rc_forget_slot.part.0>
    a820:	17ffff1b 	b	a48c <fwp_main_thread+0x7ec>
    a824:	aa1603e0 	mov	x0, x22
    a828:	97ffe6c3 	bl	4334 <fwp_rc_forget_slot.part.0>
    a82c:	17fffecf 	b	a368 <fwp_main_thread+0x6c8>
    a830:	97ffe7d5 	bl	4784 <fwp_rc_wide_dup>
    a834:	17ffff44 	b	a544 <fwp_main_thread+0x8a4>
    a838:	b0000000 	adrp	x0, b000 <__modti3+0x2a0>
    a83c:	91248000 	add	x0, x0, #0x920
    a840:	97ffe69d 	bl	42b4 <fwp_trap>
    a844:	f9400801 	ldr	x1, [x0, #16]
    a848:	a90117e1 	stp	x1, x5, [sp, #16]
    a84c:	97ffed75 	bl	5e20 <fwp_rc_free_arr>
    a850:	a94117e1 	ldp	x1, x5, [sp, #16]
    a854:	aa0103e0 	mov	x0, x1
    a858:	17ffff78 	b	a638 <fwp_main_thread+0x998>
    a85c:	72003c3f 	tst	w1, #0xffff
    a860:	54fff2c1 	b.ne	a6b8 <fwp_main_thread+0xa18>  // b.any
    a864:	17ffff8d 	b	a698 <fwp_main_thread+0x9f8>
    a868:	72003c3f 	tst	w1, #0xffff
    a86c:	54ffee21 	b.ne	a630 <fwp_main_thread+0x990>  // b.any
    a870:	17ffff6b 	b	a61c <fwp_main_thread+0x97c>
    a874:	7100087f 	cmp	w3, #0x2
    a878:	54000ac0 	b.eq	a9d0 <fwp_main_thread+0xd30>  // b.none
    a87c:	29430043 	ldp	w3, w0, [x2, #24]
    a880:	9b037c21 	mul	x1, x1, x3
    a884:	eb41801f 	cmp	x0, x1, lsr #32
    a888:	54fff729 	b.ls	a76c <fwp_main_thread+0xacc>  // b.plast
    a88c:	f94007e0 	ldr	x0, [sp, #8]
    a890:	97ffe744 	bl	45a0 <fwp_mem_free>
    a894:	17ffffb6 	b	a76c <fwp_main_thread+0xacc>
    a898:	f2403c21 	ands	x1, x1, #0xffff
    a89c:	54fff681 	b.ne	a76c <fwp_main_thread+0xacc>  // b.any
    a8a0:	17ffffab 	b	a74c <fwp_main_thread+0xaac>
    a8a4:	b0000000 	adrp	x0, b000 <__modti3+0x2a0>
    a8a8:	91240000 	add	x0, x0, #0x900
    a8ac:	a91773fb 	stp	x27, x28, [sp, #368]
    a8b0:	97ffe294 	bl	3300 <ad_raw_fail>
    a8b4:	a91773fb 	stp	x27, x28, [sp, #368]
    a8b8:	97ffdfd6 	bl	2810 <__stack_chk_fail@plt>
    a8bc:	ca5c4781 	eor	x1, x28, x28, lsr #17
    a8c0:	9118c260 	add	x0, x19, #0x630
    a8c4:	ca412421 	eor	x1, x1, x1, lsr #9
    a8c8:	92401c21 	and	x1, x1, #0xff
    a8cc:	910a2422 	add	x2, x1, #0x289
    a8d0:	8b010c01 	add	x1, x0, x1, lsl #3
    a8d4:	8b020c02 	add	x2, x0, x2, lsl #3
    a8d8:	f94a2420 	ldr	x0, [x1, #5192]
    a8dc:	b4000440 	cbz	x0, a964 <fwp_main_thread+0xcc4>
    a8e0:	f9400001 	ldr	x1, [x0]
    a8e4:	eb01039f 	cmp	x28, x1
    a8e8:	54000260 	b.eq	a934 <fwp_main_thread+0xc94>  // b.none
    a8ec:	91004002 	add	x2, x0, #0x10
    a8f0:	f9400800 	ldr	x0, [x0, #16]
    a8f4:	17fffffa 	b	a8dc <fwp_main_thread+0xc3c>
    a8f8:	ca424441 	eor	x1, x2, x2, lsr #17
    a8fc:	9118c260 	add	x0, x19, #0x630
    a900:	ca412421 	eor	x1, x1, x1, lsr #9
    a904:	92401c21 	and	x1, x1, #0xff
    a908:	910a2423 	add	x3, x1, #0x289
    a90c:	8b010c01 	add	x1, x0, x1, lsl #3
    a910:	8b030c03 	add	x3, x0, x3, lsl #3
    a914:	f94a2420 	ldr	x0, [x1, #5192]
    a918:	b4000260 	cbz	x0, a964 <fwp_main_thread+0xcc4>
    a91c:	f9400001 	ldr	x1, [x0]
    a920:	eb01005f 	cmp	x2, x1
    a924:	54000260 	b.eq	a970 <fwp_main_thread+0xcd0>  // b.none
    a928:	91004003 	add	x3, x0, #0x10
    a92c:	f9400800 	ldr	x0, [x0, #16]
    a930:	17fffffa 	b	a918 <fwp_main_thread+0xc78>
    a934:	f9400041 	ldr	x1, [x2]
    a938:	f9400420 	ldr	x0, [x1, #8]
    a93c:	d1000400 	sub	x0, x0, #0x1
    a940:	f9000420 	str	x0, [x1, #8]
    a944:	f103f81f 	cmp	x0, #0xfe
    a948:	54fff121 	b.ne	a76c <fwp_main_thread+0xacc>  // b.any
    a94c:	39400380 	ldrb	w0, [x28]
    a950:	7103fc1f 	cmp	w0, #0xff
    a954:	54000260 	b.eq	a9a0 <fwp_main_thread+0xd00>  // b.none
    a958:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a95c:	39000380 	strb	w0, [x28]
    a960:	17ffff83 	b	a76c <fwp_main_thread+0xacc>
    a964:	b0000000 	adrp	x0, b000 <__modti3+0x2a0>
    a968:	91116000 	add	x0, x0, #0x458
    a96c:	97ffe652 	bl	42b4 <fwp_trap>
    a970:	f9400061 	ldr	x1, [x3]
    a974:	f9400420 	ldr	x0, [x1, #8]
    a978:	d1000400 	sub	x0, x0, #0x1
    a97c:	f9000420 	str	x0, [x1, #8]
    a980:	f103f81f 	cmp	x0, #0xfe
    a984:	54ffe9a1 	b.ne	a6b8 <fwp_main_thread+0xa18>  // b.any
    a988:	39400040 	ldrb	w0, [x2]
    a98c:	7103fc1f 	cmp	w0, #0xff
    a990:	540000e0 	b.eq	a9ac <fwp_main_thread+0xd0c>  // b.none
    a994:	12800020 	mov	w0, #0xfffffffe            	// #-2
    a998:	39000040 	strb	w0, [x2]
    a99c:	17ffff47 	b	a6b8 <fwp_main_thread+0xa18>
    a9a0:	aa1c03e0 	mov	x0, x28
    a9a4:	97ffe664 	bl	4334 <fwp_rc_forget_slot.part.0>
    a9a8:	17ffffec 	b	a958 <fwp_main_thread+0xcb8>
    a9ac:	aa0203e0 	mov	x0, x2
    a9b0:	f9000be2 	str	x2, [sp, #16]
    a9b4:	97ffe660 	bl	4334 <fwp_rc_forget_slot.part.0>
    a9b8:	f9400be2 	ldr	x2, [sp, #16]
    a9bc:	17fffff6 	b	a994 <fwp_main_thread+0xcf4>
    a9c0:	f9000be0 	str	x0, [sp, #16]
    a9c4:	97ffe65c 	bl	4334 <fwp_rc_forget_slot.part.0>
    a9c8:	f9400be0 	ldr	x0, [sp, #16]
    a9cc:	17ffff17 	b	a628 <fwp_main_thread+0x988>
    a9d0:	b5ffece1 	cbnz	x1, a76c <fwp_main_thread+0xacc>
    a9d4:	17ffffae 	b	a88c <fwp_main_thread+0xbec>
    a9d8:	a91773fb 	stp	x27, x28, [sp, #368]
    a9dc:	97ffdfa1 	bl	2860 <abort@plt>

000000000000a9e0 <__divti3>:
    a9e0:	d503245f 	bti	c
    a9e4:	d2800004 	mov	x4, #0x0                   	// #0
    a9e8:	b7f80721 	tbnz	x1, #63, aacc <__divti3+0xec>
    a9ec:	b6f80083 	tbz	x3, #63, a9fc <__divti3+0x1c>
    a9f0:	eb0203e2 	negs	x2, x2
    a9f4:	aa2403e4 	mvn	x4, x4
    a9f8:	da0303e3 	ngc	x3, x3
    a9fc:	aa0203e6 	mov	x6, x2
    aa00:	aa0003e7 	mov	x7, x0
    aa04:	aa0103e5 	mov	x5, x1
    aa08:	b5000583 	cbnz	x3, aab8 <__divti3+0xd8>
    aa0c:	eb01005f 	cmp	x2, x1
    aa10:	54000e69 	b.ls	abdc <__divti3+0x1fc>  // b.plast
    aa14:	dac01040 	clz	x0, x2
    aa18:	b40000e0 	cbz	x0, aa34 <__divti3+0x54>
    aa1c:	4b0003e1 	neg	w1, w0
    aa20:	9ac020a5 	lsl	x5, x5, x0
    aa24:	9ac02046 	lsl	x6, x2, x0
    aa28:	9ac124e1 	lsr	x1, x7, x1
    aa2c:	aa050025 	orr	x5, x1, x5
    aa30:	9ac020e7 	lsl	x7, x7, x0
    aa34:	d360fcc8 	lsr	x8, x6, #32
    aa38:	92407cc2 	and	x2, x6, #0xffffffff
    aa3c:	9ac808a3 	udiv	x3, x5, x8
    aa40:	9b089465 	msub	x5, x3, x8, x5
    aa44:	aa0303e0 	mov	x0, x3
    aa48:	9b037c41 	mul	x1, x2, x3
    aa4c:	93c780a5 	extr	x5, x5, x7, #32
    aa50:	eb05003f 	cmp	x1, x5
    aa54:	540000a9 	b.ls	aa68 <__divti3+0x88>  // b.plast
    aa58:	ab0500c5 	adds	x5, x6, x5
    aa5c:	d1000460 	sub	x0, x3, #0x1
    aa60:	fa453020 	ccmp	x1, x5, #0x0, cc	// cc = lo, ul, last
    aa64:	540015a8 	b.hi	ad18 <__divti3+0x338>  // b.pmore
    aa68:	cb0100a5 	sub	x5, x5, x1
    aa6c:	9ac808a3 	udiv	x3, x5, x8
    aa70:	9b089465 	msub	x5, x3, x8, x5
    aa74:	aa0303e1 	mov	x1, x3
    aa78:	9b037c42 	mul	x2, x2, x3
    aa7c:	aa0703e3 	mov	x3, x7
    aa80:	b3607ca3 	bfi	x3, x5, #32, #32
    aa84:	eb03005f 	cmp	x2, x3
    aa88:	540000c9 	b.ls	aaa0 <__divti3+0xc0>  // b.plast
    aa8c:	ab0300c3 	adds	x3, x6, x3
    aa90:	d1000425 	sub	x5, x1, #0x1
    aa94:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    aa98:	d1000821 	sub	x1, x1, #0x2
    aa9c:	9a858021 	csel	x1, x1, x5, hi	// hi = pmore
    aaa0:	aa008020 	orr	x0, x1, x0, lsl #32
    aaa4:	d2800001 	mov	x1, #0x0                   	// #0
    aaa8:	b4000064 	cbz	x4, aab4 <__divti3+0xd4>
    aaac:	eb0003e0 	negs	x0, x0
    aab0:	da0103e1 	ngc	x1, x1
    aab4:	d65f03c0 	ret
    aab8:	eb01007f 	cmp	x3, x1
    aabc:	54000109 	b.ls	aadc <__divti3+0xfc>  // b.plast
    aac0:	d2800001 	mov	x1, #0x0                   	// #0
    aac4:	d2800000 	mov	x0, #0x0                   	// #0
    aac8:	17fffff8 	b	aaa8 <__divti3+0xc8>
    aacc:	eb0003e0 	negs	x0, x0
    aad0:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    aad4:	da0103e1 	ngc	x1, x1
    aad8:	17ffffc5 	b	a9ec <__divti3+0xc>
    aadc:	dac01067 	clz	x7, x3
    aae0:	b40010e7 	cbz	x7, acfc <__divti3+0x31c>
    aae4:	d2800805 	mov	x5, #0x40                  	// #64
    aae8:	cb0700a5 	sub	x5, x5, x7
    aaec:	9ac72063 	lsl	x3, x3, x7
    aaf0:	9ac52448 	lsr	x8, x2, x5
    aaf4:	aa030108 	orr	x8, x8, x3
    aaf8:	9ac52426 	lsr	x6, x1, x5
    aafc:	92407d0a 	and	x10, x8, #0xffffffff
    ab00:	d360fd09 	lsr	x9, x8, #32
    ab04:	9ac52403 	lsr	x3, x0, x5
    ab08:	9ac72021 	lsl	x1, x1, x7
    ab0c:	aa010063 	orr	x3, x3, x1
    ab10:	9ac72042 	lsl	x2, x2, x7
    ab14:	9ac908cb 	udiv	x11, x6, x9
    ab18:	9b099965 	msub	x5, x11, x9, x6
    ab1c:	aa0b03e1 	mov	x1, x11
    ab20:	9b0b7d46 	mul	x6, x10, x11
    ab24:	93c380a5 	extr	x5, x5, x3, #32
    ab28:	eb0500df 	cmp	x6, x5
    ab2c:	540000a9 	b.ls	ab40 <__divti3+0x160>  // b.plast
    ab30:	ab050105 	adds	x5, x8, x5
    ab34:	d1000561 	sub	x1, x11, #0x1
    ab38:	fa4530c0 	ccmp	x6, x5, #0x0, cc	// cc = lo, ul, last
    ab3c:	54000f48 	b.hi	ad24 <__divti3+0x344>  // b.pmore
    ab40:	cb0600a6 	sub	x6, x5, x6
    ab44:	9ac908cb 	udiv	x11, x6, x9
    ab48:	9b099969 	msub	x9, x11, x9, x6
    ab4c:	aa0b03e5 	mov	x5, x11
    ab50:	9b0b7d4a 	mul	x10, x10, x11
    ab54:	b3607d23 	bfi	x3, x9, #32, #32
    ab58:	eb03015f 	cmp	x10, x3
    ab5c:	540000a9 	b.ls	ab70 <__divti3+0x190>  // b.plast
    ab60:	ab030103 	adds	x3, x8, x3
    ab64:	d1000565 	sub	x5, x11, #0x1
    ab68:	fa433140 	ccmp	x10, x3, #0x0, cc	// cc = lo, ul, last
    ab6c:	54000e28 	b.hi	ad30 <__divti3+0x350>  // b.pmore
    ab70:	aa0180a1 	orr	x1, x5, x1, lsl #32
    ab74:	92407c48 	and	x8, x2, #0xffffffff
    ab78:	2a0503e5 	mov	w5, w5
    ab7c:	d360fc42 	lsr	x2, x2, #32
    ab80:	d360fc26 	lsr	x6, x1, #32
    ab84:	cb0a0063 	sub	x3, x3, x10
    ab88:	d2c00029 	mov	x9, #0x100000000           	// #4294967296
    ab8c:	9b087caa 	mul	x10, x5, x8
    ab90:	9b087cc8 	mul	x8, x6, x8
    ab94:	9b0220a5 	madd	x5, x5, x2, x8
    ab98:	9b027cc6 	mul	x6, x6, x2
    ab9c:	8b4a80a2 	add	x2, x5, x10, lsr #32
    aba0:	8b0900c5 	add	x5, x6, x9
    aba4:	eb02011f 	cmp	x8, x2
    aba8:	9a8680a6 	csel	x6, x5, x6, hi	// hi = pmore
    abac:	8b4280c6 	add	x6, x6, x2, lsr #32
    abb0:	eb06007f 	cmp	x3, x6
    abb4:	540000e3 	b.cc	abd0 <__divti3+0x1f0>  // b.lo, b.ul, b.last
    abb8:	92407d4a 	and	x10, x10, #0xffffffff
    abbc:	9ac72000 	lsl	x0, x0, x7
    abc0:	8b028142 	add	x2, x10, x2, lsl #32
    abc4:	eb02001f 	cmp	x0, x2
    abc8:	fa463060 	ccmp	x3, x6, #0x0, cc	// cc = lo, ul, last
    abcc:	54000a01 	b.ne	ad0c <__divti3+0x32c>  // b.any
    abd0:	d1000420 	sub	x0, x1, #0x1
    abd4:	d2800001 	mov	x1, #0x0                   	// #0
    abd8:	17ffffb4 	b	aaa8 <__divti3+0xc8>
    abdc:	b5000062 	cbnz	x2, abe8 <__divti3+0x208>
    abe0:	d2800022 	mov	x2, #0x1                   	// #1
    abe4:	9ac30846 	udiv	x6, x2, x3
    abe8:	dac010c8 	clz	x8, x6
    abec:	b5000408 	cbnz	x8, ac6c <__divti3+0x28c>
    abf0:	d360fcc9 	lsr	x9, x6, #32
    abf4:	92407cc5 	and	x5, x6, #0xffffffff
    abf8:	cb060023 	sub	x3, x1, x6
    abfc:	d2800021 	mov	x1, #0x1                   	// #1
    ac00:	9ac90868 	udiv	x8, x3, x9
    ac04:	9b098d03 	msub	x3, x8, x9, x3
    ac08:	aa0803e0 	mov	x0, x8
    ac0c:	9b057d02 	mul	x2, x8, x5
    ac10:	93c78063 	extr	x3, x3, x7, #32
    ac14:	eb03005f 	cmp	x2, x3
    ac18:	540000a9 	b.ls	ac2c <__divti3+0x24c>  // b.plast
    ac1c:	ab0300c3 	adds	x3, x6, x3
    ac20:	d1000500 	sub	x0, x8, #0x1
    ac24:	fa433040 	ccmp	x2, x3, #0x0, cc	// cc = lo, ul, last
    ac28:	54000968 	b.hi	ad54 <__divti3+0x374>  // b.pmore
    ac2c:	cb020063 	sub	x3, x3, x2
    ac30:	9ac90862 	udiv	x2, x3, x9
    ac34:	aa0203e8 	mov	x8, x2
    ac38:	9b098c42 	msub	x2, x2, x9, x3
    ac3c:	aa0703e3 	mov	x3, x7
    ac40:	9b057d05 	mul	x5, x8, x5
    ac44:	b3607c43 	bfi	x3, x2, #32, #32
    ac48:	eb0300bf 	cmp	x5, x3
    ac4c:	540000c9 	b.ls	ac64 <__divti3+0x284>  // b.plast
    ac50:	ab0300c2 	adds	x2, x6, x3
    ac54:	d1000503 	sub	x3, x8, #0x1
    ac58:	fa4230a0 	ccmp	x5, x2, #0x0, cc	// cc = lo, ul, last
    ac5c:	d1000908 	sub	x8, x8, #0x2
    ac60:	9a838108 	csel	x8, x8, x3, hi	// hi = pmore
    ac64:	aa008100 	orr	x0, x8, x0, lsl #32
    ac68:	17ffff90 	b	aaa8 <__divti3+0xc8>
    ac6c:	9ac820c6 	lsl	x6, x6, x8
    ac70:	d2800803 	mov	x3, #0x40                  	// #64
    ac74:	cb080063 	sub	x3, x3, x8
    ac78:	d360fcc9 	lsr	x9, x6, #32
    ac7c:	9ac82027 	lsl	x7, x1, x8
    ac80:	92407cc5 	and	x5, x6, #0xffffffff
    ac84:	9ac32422 	lsr	x2, x1, x3
    ac88:	9ac32403 	lsr	x3, x0, x3
    ac8c:	aa070063 	orr	x3, x3, x7
    ac90:	9ac9084a 	udiv	x10, x2, x9
    ac94:	9ac82007 	lsl	x7, x0, x8
    ac98:	9b098940 	msub	x0, x10, x9, x2
    ac9c:	aa0a03e1 	mov	x1, x10
    aca0:	9b0a7ca2 	mul	x2, x5, x10
    aca4:	93c38000 	extr	x0, x0, x3, #32
    aca8:	eb00005f 	cmp	x2, x0
    acac:	540000a9 	b.ls	acc0 <__divti3+0x2e0>  // b.plast
    acb0:	ab0000c0 	adds	x0, x6, x0
    acb4:	d1000541 	sub	x1, x10, #0x1
    acb8:	fa403040 	ccmp	x2, x0, #0x0, cc	// cc = lo, ul, last
    acbc:	54000468 	b.hi	ad48 <__divti3+0x368>  // b.pmore
    acc0:	cb020000 	sub	x0, x0, x2
    acc4:	9ac9080a 	udiv	x10, x0, x9
    acc8:	9b098140 	msub	x0, x10, x9, x0
    accc:	aa0a03e2 	mov	x2, x10
    acd0:	9b0a7ca8 	mul	x8, x5, x10
    acd4:	b3607c03 	bfi	x3, x0, #32, #32
    acd8:	eb03011f 	cmp	x8, x3
    acdc:	540000a9 	b.ls	acf0 <__divti3+0x310>  // b.plast
    ace0:	ab0300c3 	adds	x3, x6, x3
    ace4:	d1000542 	sub	x2, x10, #0x1
    ace8:	fa433100 	ccmp	x8, x3, #0x0, cc	// cc = lo, ul, last
    acec:	54000288 	b.hi	ad3c <__divti3+0x35c>  // b.pmore
    acf0:	cb080063 	sub	x3, x3, x8
    acf4:	aa018041 	orr	x1, x2, x1, lsl #32
    acf8:	17ffffc2 	b	ac00 <__divti3+0x220>
    acfc:	fa402040 	ccmp	x2, x0, #0x0, cs	// cs = hs, nlast
    ad00:	d2800001 	mov	x1, #0x0                   	// #0
    ad04:	9a9f87e0 	cset	x0, ls	// ls = plast
    ad08:	17ffff68 	b	aaa8 <__divti3+0xc8>
    ad0c:	aa0103e0 	mov	x0, x1
    ad10:	d2800001 	mov	x1, #0x0                   	// #0
    ad14:	17ffff65 	b	aaa8 <__divti3+0xc8>
    ad18:	d1000860 	sub	x0, x3, #0x2
    ad1c:	8b0600a5 	add	x5, x5, x6
    ad20:	17ffff52 	b	aa68 <__divti3+0x88>
    ad24:	d1000961 	sub	x1, x11, #0x2
    ad28:	8b0800a5 	add	x5, x5, x8
    ad2c:	17ffff85 	b	ab40 <__divti3+0x160>
    ad30:	d1000965 	sub	x5, x11, #0x2
    ad34:	8b080063 	add	x3, x3, x8
    ad38:	17ffff8e 	b	ab70 <__divti3+0x190>
    ad3c:	d1000942 	sub	x2, x10, #0x2
    ad40:	8b060063 	add	x3, x3, x6
    ad44:	17ffffeb 	b	acf0 <__divti3+0x310>
    ad48:	d1000941 	sub	x1, x10, #0x2
    ad4c:	8b060000 	add	x0, x0, x6
    ad50:	17ffffdc 	b	acc0 <__divti3+0x2e0>
    ad54:	d1000900 	sub	x0, x8, #0x2
    ad58:	8b060063 	add	x3, x3, x6
    ad5c:	17ffffb4 	b	ac2c <__divti3+0x24c>

000000000000ad60 <__modti3>:
    ad60:	d503245f 	bti	c
    ad64:	d2800004 	mov	x4, #0x0                   	// #0
    ad68:	b6f80081 	tbz	x1, #63, ad78 <__modti3+0x18>
    ad6c:	eb0003e0 	negs	x0, x0
    ad70:	92800004 	mov	x4, #0xffffffffffffffff    	// #-1
    ad74:	da0103e1 	ngc	x1, x1
    ad78:	f100007f 	cmp	x3, #0x0
    ad7c:	5400128b 	b.lt	afcc <__modti3+0x26c>  // b.tstop
    ad80:	aa0003e7 	mov	x7, x0
    ad84:	aa0103e6 	mov	x6, x1
    ad88:	540004e1 	b.ne	ae24 <__modti3+0xc4>  // b.any
    ad8c:	eb02003f 	cmp	x1, x2
    ad90:	54000dc2 	b.cs	af48 <__modti3+0x1e8>  // b.hs, b.nlast
    ad94:	dac01043 	clz	x3, x2
    ad98:	aa0303e5 	mov	x5, x3
    ad9c:	b40000e3 	cbz	x3, adb8 <__modti3+0x58>
    ada0:	4b0303e6 	neg	w6, w3
    ada4:	9ac32021 	lsl	x1, x1, x3
    ada8:	9ac32042 	lsl	x2, x2, x3
    adac:	9ac62406 	lsr	x6, x0, x6
    adb0:	aa0100c6 	orr	x6, x6, x1
    adb4:	9ac32007 	lsl	x7, x0, x3
    adb8:	d360fc40 	lsr	x0, x2, #32
    adbc:	92407c43 	and	x3, x2, #0xffffffff
    adc0:	9ac008c1 	udiv	x1, x6, x0
    adc4:	9b009826 	msub	x6, x1, x0, x6
    adc8:	9b017c61 	mul	x1, x3, x1
    adcc:	93c780c6 	extr	x6, x6, x7, #32
    add0:	eb06003f 	cmp	x1, x6
    add4:	540000a9 	b.ls	ade8 <__modti3+0x88>  // b.plast
    add8:	ab060046 	adds	x6, x2, x6
    addc:	fa463020 	ccmp	x1, x6, #0x0, cc	// cc = lo, ul, last
    ade0:	8b0200c8 	add	x8, x6, x2
    ade4:	9a868106 	csel	x6, x8, x6, hi	// hi = pmore
    ade8:	cb0100c6 	sub	x6, x6, x1
    adec:	9ac008c8 	udiv	x8, x6, x0
    adf0:	9b009901 	msub	x1, x8, x0, x6
    adf4:	aa0703e0 	mov	x0, x7
    adf8:	9b087c63 	mul	x3, x3, x8
    adfc:	b3607c20 	bfi	x0, x1, #32, #32
    ae00:	eb00007f 	cmp	x3, x0
    ae04:	54001088 	b.hi	b014 <__modti3+0x2b4>  // b.pmore
    ae08:	cb030000 	sub	x0, x0, x3
    ae0c:	9ac52400 	lsr	x0, x0, x5
    ae10:	d2800001 	mov	x1, #0x0                   	// #0
    ae14:	b4000064 	cbz	x4, ae20 <__modti3+0xc0>
    ae18:	eb0003e0 	negs	x0, x0
    ae1c:	da0103e1 	ngc	x1, x1
    ae20:	d65f03c0 	ret
    ae24:	dac01066 	clz	x6, x3
    ae28:	eb03003f 	cmp	x1, x3
    ae2c:	54ffff43 	b.cc	ae14 <__modti3+0xb4>  // b.lo, b.ul, b.last
    ae30:	93407cc5 	sxtw	x5, w6
    ae34:	d2800808 	mov	x8, #0x40                  	// #64
    ae38:	cb050108 	sub	x8, x8, x5
    ae3c:	9ac62063 	lsl	x3, x3, x6
    ae40:	9ac62025 	lsl	x5, x1, x6
    ae44:	9ac82447 	lsr	x7, x2, x8
    ae48:	aa0300e7 	orr	x7, x7, x3
    ae4c:	9ac82423 	lsr	x3, x1, x8
    ae50:	92407cec 	and	x12, x7, #0xffffffff
    ae54:	d360fcea 	lsr	x10, x7, #32
    ae58:	9ac82401 	lsr	x1, x0, x8
    ae5c:	aa050021 	orr	x1, x1, x5
    ae60:	9ac62042 	lsl	x2, x2, x6
    ae64:	9ac62000 	lsl	x0, x0, x6
    ae68:	9aca086b 	udiv	x11, x3, x10
    ae6c:	9b0a8d63 	msub	x3, x11, x10, x3
    ae70:	aa0b03e5 	mov	x5, x11
    ae74:	9b0b7d89 	mul	x9, x12, x11
    ae78:	93c18063 	extr	x3, x3, x1, #32
    ae7c:	eb03013f 	cmp	x9, x3
    ae80:	540000a9 	b.ls	ae94 <__modti3+0x134>  // b.plast
    ae84:	ab0300e3 	adds	x3, x7, x3
    ae88:	d1000565 	sub	x5, x11, #0x1
    ae8c:	fa433120 	ccmp	x9, x3, #0x0, cc	// cc = lo, ul, last
    ae90:	54001168 	b.hi	b0bc <__modti3+0x35c>  // b.pmore
    ae94:	cb090063 	sub	x3, x3, x9
    ae98:	9aca086b 	udiv	x11, x3, x10
    ae9c:	9b0a8d6a 	msub	x10, x11, x10, x3
    aea0:	aa0b03e9 	mov	x9, x11
    aea4:	9b0b7d8c 	mul	x12, x12, x11
    aea8:	b3607d41 	bfi	x1, x10, #32, #32
    aeac:	eb01019f 	cmp	x12, x1
    aeb0:	540000a9 	b.ls	aec4 <__modti3+0x164>  // b.plast
    aeb4:	ab0100e1 	adds	x1, x7, x1
    aeb8:	d1000569 	sub	x9, x11, #0x1
    aebc:	fa413180 	ccmp	x12, x1, #0x0, cc	// cc = lo, ul, last
    aec0:	54000f88 	b.hi	b0b0 <__modti3+0x350>  // b.pmore
    aec4:	aa058123 	orr	x3, x9, x5, lsl #32
    aec8:	92407c4b 	and	x11, x2, #0xffffffff
    aecc:	2a0903e9 	mov	w9, w9
    aed0:	d360fc4a 	lsr	x10, x2, #32
    aed4:	d360fc63 	lsr	x3, x3, #32
    aed8:	cb0c0021 	sub	x1, x1, x12
    aedc:	aa0a03ec 	mov	x12, x10
    aee0:	d2c0002d 	mov	x13, #0x100000000           	// #4294967296
    aee4:	9b0b7d25 	mul	x5, x9, x11
    aee8:	9b0b7c6b 	mul	x11, x3, x11
    aeec:	9b0a2d29 	madd	x9, x9, x10, x11
    aef0:	92407caa 	and	x10, x5, #0xffffffff
    aef4:	9b0c7c63 	mul	x3, x3, x12
    aef8:	8b458125 	add	x5, x9, x5, lsr #32
    aefc:	8b0d0069 	add	x9, x3, x13
    af00:	eb05017f 	cmp	x11, x5
    af04:	9a838123 	csel	x3, x9, x3, hi	// hi = pmore
    af08:	8b058149 	add	x9, x10, x5, lsl #32
    af0c:	8b458063 	add	x3, x3, x5, lsr #32
    af10:	eb03003f 	cmp	x1, x3
    af14:	54000063 	b.cc	af20 <__modti3+0x1c0>  // b.lo, b.ul, b.last
    af18:	fa490002 	ccmp	x0, x9, #0x2, eq	// eq = none
    af1c:	54000082 	b.cs	af2c <__modti3+0x1cc>  // b.hs, b.nlast
    af20:	eb020129 	subs	x9, x9, x2
    af24:	9a8724e7 	cinc	x7, x7, cc	// cc = lo, ul, last
    af28:	cb070063 	sub	x3, x3, x7
    af2c:	eb090000 	subs	x0, x0, x9
    af30:	da030021 	sbc	x1, x1, x3
    af34:	9ac62400 	lsr	x0, x0, x6
    af38:	9ac82028 	lsl	x8, x1, x8
    af3c:	aa000100 	orr	x0, x8, x0
    af40:	9ac62421 	lsr	x1, x1, x6
    af44:	17ffffb4 	b	ae14 <__modti3+0xb4>
    af48:	b5000062 	cbnz	x2, af54 <__modti3+0x1f4>
    af4c:	d2800023 	mov	x3, #0x1                   	// #1
    af50:	9ac20862 	udiv	x2, x3, x2
    af54:	dac01048 	clz	x8, x2
    af58:	aa0803e5 	mov	x5, x8
    af5c:	b5000668 	cbnz	x8, b028 <__modti3+0x2c8>
    af60:	cb020020 	sub	x0, x1, x2
    af64:	d360fc49 	lsr	x9, x2, #32
    af68:	92407c4a 	and	x10, x2, #0xffffffff
    af6c:	9ac90801 	udiv	x1, x0, x9
    af70:	9b098020 	msub	x0, x1, x9, x0
    af74:	9b0a7c21 	mul	x1, x1, x10
    af78:	93c78000 	extr	x0, x0, x7, #32
    af7c:	eb00003f 	cmp	x1, x0
    af80:	540000a9 	b.ls	af94 <__modti3+0x234>  // b.plast
    af84:	ab000040 	adds	x0, x2, x0
    af88:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    af8c:	8b020003 	add	x3, x0, x2
    af90:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    af94:	cb010001 	sub	x1, x0, x1
    af98:	9ac90820 	udiv	x0, x1, x9
    af9c:	9b098403 	msub	x3, x0, x9, x1
    afa0:	aa0703e1 	mov	x1, x7
    afa4:	9b0a7c00 	mul	x0, x0, x10
    afa8:	b3607c61 	bfi	x1, x3, #32, #32
    afac:	eb01001f 	cmp	x0, x1
    afb0:	540000a9 	b.ls	afc4 <__modti3+0x264>  // b.plast
    afb4:	ab010041 	adds	x1, x2, x1
    afb8:	8b020022 	add	x2, x1, x2
    afbc:	fa413000 	ccmp	x0, x1, #0x0, cc	// cc = lo, ul, last
    afc0:	9a818041 	csel	x1, x2, x1, hi	// hi = pmore
    afc4:	cb000020 	sub	x0, x1, x0
    afc8:	17ffff91 	b	ae0c <__modti3+0xac>
    afcc:	eb0203e5 	negs	x5, x2
    afd0:	aa0003e7 	mov	x7, x0
    afd4:	da0303e8 	ngc	x8, x3
    afd8:	aa0503e2 	mov	x2, x5
    afdc:	aa0803e3 	mov	x3, x8
    afe0:	aa0103e6 	mov	x6, x1
    afe4:	b4ffed48 	cbz	x8, ad8c <__modti3+0x2c>
    afe8:	eb01011f 	cmp	x8, x1
    afec:	54fff148 	b.hi	ae14 <__modti3+0xb4>  // b.pmore
    aff0:	dac01109 	clz	x9, x8
    aff4:	2a0903e6 	mov	w6, w9
    aff8:	b5fff1c9 	cbnz	x9, ae30 <__modti3+0xd0>
    affc:	fa4020a0 	ccmp	x5, x0, #0x0, cs	// cs = hs, nlast
    b000:	54000068 	b.hi	b00c <__modti3+0x2ac>  // b.pmore
    b004:	eb050007 	subs	x7, x0, x5
    b008:	da080021 	sbc	x1, x1, x8
    b00c:	aa0703e0 	mov	x0, x7
    b010:	17ffff81 	b	ae14 <__modti3+0xb4>
    b014:	ab000040 	adds	x0, x2, x0
    b018:	8b020002 	add	x2, x0, x2
    b01c:	fa403060 	ccmp	x3, x0, #0x0, cc	// cc = lo, ul, last
    b020:	9a808040 	csel	x0, x2, x0, hi	// hi = pmore
    b024:	17ffff79 	b	ae08 <__modti3+0xa8>
    b028:	9ac82042 	lsl	x2, x2, x8
    b02c:	d2800803 	mov	x3, #0x40                  	// #64
    b030:	cb080063 	sub	x3, x3, x8
    b034:	d360fc49 	lsr	x9, x2, #32
    b038:	9ac82027 	lsl	x7, x1, x8
    b03c:	92407c4a 	and	x10, x2, #0xffffffff
    b040:	9ac32426 	lsr	x6, x1, x3
    b044:	9ac32403 	lsr	x3, x0, x3
    b048:	aa070063 	orr	x3, x3, x7
    b04c:	9ac908c1 	udiv	x1, x6, x9
    b050:	9ac82007 	lsl	x7, x0, x8
    b054:	9b099820 	msub	x0, x1, x9, x6
    b058:	9b017d41 	mul	x1, x10, x1
    b05c:	93c38000 	extr	x0, x0, x3, #32
    b060:	eb00003f 	cmp	x1, x0
    b064:	540000a9 	b.ls	b078 <__modti3+0x318>  // b.plast
    b068:	ab000040 	adds	x0, x2, x0
    b06c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b070:	8b020006 	add	x6, x0, x2
    b074:	9a8080c0 	csel	x0, x6, x0, hi	// hi = pmore
    b078:	cb010000 	sub	x0, x0, x1
    b07c:	9ac90801 	udiv	x1, x0, x9
    b080:	9b098026 	msub	x6, x1, x9, x0
    b084:	aa0303e0 	mov	x0, x3
    b088:	9b017d41 	mul	x1, x10, x1
    b08c:	b3607cc0 	bfi	x0, x6, #32, #32
    b090:	eb00003f 	cmp	x1, x0
    b094:	540000a9 	b.ls	b0a8 <__modti3+0x348>  // b.plast
    b098:	ab000040 	adds	x0, x2, x0
    b09c:	fa403020 	ccmp	x1, x0, #0x0, cc	// cc = lo, ul, last
    b0a0:	8b020003 	add	x3, x0, x2
    b0a4:	9a808060 	csel	x0, x3, x0, hi	// hi = pmore
    b0a8:	cb010000 	sub	x0, x0, x1
    b0ac:	17ffffb0 	b	af6c <__modti3+0x20c>
    b0b0:	d1000969 	sub	x9, x11, #0x2
    b0b4:	8b070021 	add	x1, x1, x7
    b0b8:	17ffff83 	b	aec4 <__modti3+0x164>
    b0bc:	d1000965 	sub	x5, x11, #0x2
    b0c0:	8b070063 	add	x3, x3, x7
    b0c4:	17ffff74 	b	ae94 <__modti3+0x134>
    b0c8:	d503201f 	nop
    b0cc:	d503201f 	nop

000000000000b0d0 <atexit>:
    b0d0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b0d4:	b00000a2 	adrp	x2, 20000 <__data_start>
    b0d8:	d2800001 	mov	x1, #0x0                   	// #0
    b0dc:	910003fd 	mov	x29, sp
    b0e0:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b0e4:	f9400442 	ldr	x2, [x2, #8]
    b0e8:	17ffdd8a 	b	2710 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b0ec <_fini>:
    b0ec:	d503201f 	nop
    b0f0:	a9bf7bfd 	stp	x29, x30, [sp, #-16]!
    b0f4:	910003fd 	mov	x29, sp
    b0f8:	a8c17bfd 	ldp	x29, x30, [sp], #16
    b0fc:	d65f03c0 	ret
