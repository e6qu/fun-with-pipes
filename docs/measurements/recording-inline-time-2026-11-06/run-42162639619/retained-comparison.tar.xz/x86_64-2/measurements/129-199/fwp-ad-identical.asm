
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-identical:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 32 1c 02 00 	mov    %rax,0x21c32(%rip)        # 253b8 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c 1c 02 00 	mov    %rax,0x21c2c(%rip)        # 253c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 8f a2 00 00 	lea    0xa28f(%rip),%rdx        # daf0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 c0 00 00 	lea    0xc096(%rip),%rdi        # f9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 50 c0 00 00 	lea    0xc050(%rip),%rdi        # f978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 c0 00 00 	lea    0xc014(%rip),%rdi        # f948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 bf 00 00 	lea    0xbfe0(%rip),%rdi        # f920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 17 02 00 	mov    0x21749(%rip),%rdi        # 253c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 fa 01 00 	mov    0x1fa41(%rip),%rax        # 23740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 f3 01 00 	mov    0x1f381(%rip),%rax        # 23100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d f3 01 00 	sub    0x1f36d(%rip),%rax        # 230f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b 0d 02 00 	mov    0x20d5b(%rip),%rax        # 24b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 0d 02 00 	lea    0x20d54(%rip),%r8        # 24b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 0d 02 00 	mov    0x20d35(%rip),%rbx        # 24b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 0d 02 00 	mov    0x20d45(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 0c 02 00 	mov    0x20ce1(%rip),%rdi        # 24b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a 0d 02 00 	sub    %rsi,0x20d2a(%rip)        # 24b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba 0c 02 00 	mov    0x20cba(%rip),%rax        # 24b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 0c 02 00 	add    0x20c70(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e 0c 02 00 	mov    0x20c7e(%rip),%rsi        # 24b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c 0c 02 00 	mov    0x20c8c(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b 0c 02 00 	mov    %r12,0x20c3b(%rip)        # 24b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 0c 02 00 	mov    %rbp,0x20c29(%rip)        # 24b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e 0c 02 00 	cmp    %rdi,0x20c0e(%rip)        # 24b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 0c 02 00 	mov    %rdi,0x20c05(%rip)        # 24b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 0c 02 00 	sub    %rdi,0x20c49(%rip)        # 24b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 0b 02 00 	mov    0x20bf1(%rip),%rax        # 24b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea 0b 02 00 	lea    0x20bea(%rip),%r8        # 24b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd ef 00 00 	mov    0xeffd(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 f6 01 00 	cmp    0x1f689(%rip),%rdi        # 23740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f f6 01 00 	mov    0x1f64f(%rip),%rax        # 23720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d f6 01 00 	mov    %rdi,0x1f62d(%rip)        # 23720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 f6 01 00 	mov    %rdi,0x1f609(%rip)        # 23728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db af 00 00 	lea    0xafdb(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 ee 00 00 	mov    0xee78(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 ee 00 00 	mov    0xee60(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 ed 00 00 	mov    0xed71(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 b2 00 00 	lea    0xb270(%rip),%rdi        # f610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 b7 00 	movdqa 0xb710(%rip),%xmm0        # fad0 <msg.4+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a 0f 02 00 	add    0x20f9a(%rip),%rax        # 253b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc b1 00 00 	lea    0xb1cc(%rip),%rdi        # f640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 ec 01 00 	cmp    %rax,0x1ec55(%rip)        # 230e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 ec 01 00 	add    0x1ec50(%rip),%rax        # 230f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 b1 00 00 	lea    0xb1b5(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 a7 00 00 	lea    0xa736(%rip),%rsi        # f184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 00 02 00 	mov    0x20065(%rip),%r9        # 24b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be 00 02 00 	mov    0x200be(%rip),%r8        # 24b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef ab 00 00 	lea    0xabef(%rip),%rdx        # f6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 00 02 00 	mov    0x200a6(%rip),%rcx        # 24b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 00 02 	movsd  0x200b4(%rip),%xmm1        # 24ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 00 02 	movsd  0x200a4(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 e5 00 00 	mov    0xe545(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 af 00 	movdqa 0xafa8(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f fb 01 00 	lea    0x1fb5f(%rip),%rax        # 246a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 af 00 	movdqa 0xafd1(%rip),%xmm2        # fb20 <msg.4+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 fb 01 00 	movaps %xmm0,0x1fb05(%rip)        # 24660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d af 00 	movdqa 0xaf8d(%rip),%xmm0        # faf0 <msg.4+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 ff 01 00 01 	movl   $0x1,0x1ff93(%rip)        # 24b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 fa 01 00 	movaps %xmm0,0x1faf3(%rip)        # 24670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b af 00 	movdqa 0xaf7b(%rip),%xmm0        # fb00 <msg.4+0x80>
    4b84:	00 
    4b85:	0f 29 05 f4 fa 01 00 	movaps %xmm0,0x1faf4(%rip)        # 24680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c af 00 	movdqa 0xaf7c(%rip),%xmm0        # fb10 <msg.4+0x90>
    4b93:	00 
    4b94:	0f 29 05 f5 fa 01 00 	movaps %xmm0,0x1faf5(%rip)        # 24690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 eb 01 00 	lea    0x1eb75(%rip),%r8        # 23760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 fe 01 00 	mov    %rax,0x1fe90(%rip)        # 24b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e fe 01 00 	mov    %r12,0x1fe6e(%rip)        # 24b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 fe 01 00 	mov    %rax,0x1fe57(%rip)        # 24b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 fe 01 00 	mov    %rbx,0x1fe70(%rip)        # 24b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 fe 01 00 	mov    %rsi,0x1fe99(%rip)        # 24b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 fe 01 00 	mov    %rax,0x1fe78(%rip)        # 24b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc fd 01 00    	mov    %eax,0x1fdfc(%rip)        # 24b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec e9 01 00 	mov    0x1e9ec(%rip),%r8        # 23720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c e9 01 00 	mov    %rbx,0x1e91c(%rip)        # 23728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 e9 01 00 	mov    %r8,0x1e908(%rip)        # 23720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd e1 01 00 	lea    0x1e1dd(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 e1 01 00 	movaps %xmm0,0x1e1c5(%rip)        # 230a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 e1 01 00 	mov    %rax,0x1e1a1(%rip)        # 23088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 e1 01 00 	movaps %xmm0,0x1e1c2(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 e1 01 00 	movaps %xmm0,0x1e1c6(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 e1 01 00 	mov    %rdx,0x1e1c7(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 e7 01 00 	mov    0x1e797(%rip),%rbx        # 23718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca df 00 00 	mov    0xdfca(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d cb a6 00 00 	lea    0xa6cb(%rip),%rdi        # f748 <_IO_stdin_used+0x748>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d e6 01 00 	mov    0x1e66d(%rip),%rax        # 23720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 e6 01 00 	mov    %rdx,0x1e647(%rip)        # 23720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 e5 01 00 	mov    0x1e594(%rip),%rbx        # 23718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 e5 01 00 	mov    %rbx,0x1e551(%rip)        # 23718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 e5 01 00 	mov    %rdx,0x1e551(%rip)        # 23728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 e5 01 00 	lea    0x1e566(%rip),%rsi        # 23760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 00 02 00 	addq   $0x1,0x200e5(%rip)        # 253a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 9f a4 00 00 	lea    0xa49f(%rip),%rdi        # f778 <_IO_stdin_used+0x778>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d b0 a4 00 00 	lea    0xa4b0(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e e4 01 00 	lea    0x1e41e(%rip),%rcx        # 23760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f 00 02 00 	subq   $0x1,0x2001f(%rip)        # 253a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 0b a4 00 00 	lea    0xa40b(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 00 02 00 	cmpq   $0x0,0x20000(%rip)        # 253a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 ff 01 00 	sub    %rax,0x1ff55(%rip)        # 253b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 ff 01 00 	add    %r12,0x1ff33(%rip)        # 253b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f f6 01 00 	mov    0x1f68f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c e2 01 00 	lea    0x1e28c(%rip),%rax        # 23760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 f5 01 00 	add    0x1f5e3(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 f5 01 00 	mov    0x1f5b0(%rip),%rsi        # 24b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 f5 01 00 	mov    0x1f5d1(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 f5 01 00 	add    0x1f5c5(%rip),%r8        # 24b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d f5 01 	addsd  0x1f58d(%rip),%xmm0        # 24ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 e1 01 00 	lea    0x1e142(%rip),%rax        # 23760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c f5 01 00 	sub    %rdi,0x1f54c(%rip)        # 24b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 f5 01 	movsd  %xmm0,0x1f564(%rip)        # 24ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e f5 01 00 	sub    %rdx,0x1f51e(%rip)        # 24b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 f5 01 	addsd  0x1f524(%rip),%xmm0        # 24ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 f5 01 	movsd  %xmm0,0x1f518(%rip)        # 24ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af f4 01 00 	mov    0x1f4af(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 f4 01 00 	add    %rcx,0x1f4a9(%rip)        # 24b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 f4 01 00 	cmp    0x1f462(%rip),%r9        # 24b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 f4 01 00 	mov    %r9,0x1f459(%rip)        # 24b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a f4 01 00 	cmp    0x1f44a(%rip),%r9        # 24b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d f4 01 00 	mov    %r9,0x1f43d(%rip)        # 24b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 f3 01 00 	add    0x1f353(%rip),%rdi        # 24b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 df 01 00 	lea    0x1df30(%rip),%r15        # 23760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 f2 01 00 	add    0x1f2a0(%rip),%r12        # 24b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 f2 01 00 	add    0x1f2f9(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 f2 01 00 	cmp    %rax,0x1f2f8(%rip)        # 24b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 f2 01 00 	mov    %rax,0x1f2e9(%rip)        # 24b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 f2 01 00 	mov    %rax,0x1f2e8(%rip)        # 24b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 f2 01 	addsd  0x1f2e4(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc f2 01 	movsd  %xmm0,0x1f2dc(%rip)        # 24b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 f2 01 00    	mov    0x1f223(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f de 01 00 	lea    0x1de5f(%rip),%rdi        # 23760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 f2 01 00 	add    0x1f218(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 f2 01 00 	cmp    %rax,0x1f213(%rip)        # 24b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 f2 01 00 	mov    %rax,0x1f204(%rip)        # 24b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 f2 01 00 	mov    %rax,0x1f203(%rip)        # 24b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff f1 01 	addsd  0x1f1ff(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 f1 01 	movsd  %xmm0,0x1f1f7(%rip)        # 24b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae f0 01 00    	mov    0x1f0ae(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 dc 01 00 	lea    0x1dce5(%rip),%rax        # 23760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b f0 01 00 	add    0x1f09b(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a f0 01 00 	cmp    %rax,0x1f09a(%rip)        # 24b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b f0 01 00 	mov    %rax,0x1f08b(%rip)        # 24b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a f0 01 00 	mov    %rax,0x1f08a(%rip)        # 24b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 f0 01 	addsd  0x1f086(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e f0 01 	movsd  %xmm0,0x1f07e(%rip)        # 24b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e ef 01 00    	mov    0x1ef7e(%rip),%eax        # 24b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d eb 01 00 	movzbl 0x1eb6d(%rip),%eax        # 24702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 db 01 00 	lea    0x1dbc4(%rip),%rdx        # 23760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 ef 01 00 	add    0x1ef95(%rip),%rax        # 24b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 ef 01 00 	cmp    %rax,0x1ef90(%rip)        # 24b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 ef 01 00 	mov    %rax,0x1ef81(%rip)        # 24b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 ef 01 00 	mov    %rax,0x1ef80(%rip)        # 24b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f ef 01 	addsd  0x1ef7f(%rip),%xmm0        # 24b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 ef 01 	movsd  %xmm0,0x1ef77(%rip)        # 24b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_tape_reserve>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	41 54                	push   %r12
    5ca8:	55                   	push   %rbp
    5ca9:	53                   	push   %rbx
    5caa:	48 83 ec 18          	sub    $0x18,%rsp
    5cae:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5cb5:	0f 87 d3 01 00 00    	ja     5e8e <fwp_tape_reserve+0x1ee>
    5cbb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5cbf:	48 89 fd             	mov    %rdi,%rbp
    5cc2:	48 39 f3             	cmp    %rsi,%rbx
    5cc5:	0f 8d 13 01 00 00    	jge    5dde <fwp_tape_reserve+0x13e>
    5ccb:	48 85 db             	test   %rbx,%rbx
    5cce:	b8 40 00 00 00       	mov    $0x40,%eax
    5cd3:	48 0f 44 d8          	cmove  %rax,%rbx
    5cd7:	48 39 f3             	cmp    %rsi,%rbx
    5cda:	7d 24                	jge    5d00 <fwp_tape_reserve+0x60>
    5cdc:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5ce3:	0f 8f 07 01 00 00    	jg     5df0 <fwp_tape_reserve+0x150>
    5ce9:	48 01 db             	add    %rbx,%rbx
    5cec:	48 39 f3             	cmp    %rsi,%rbx
    5cef:	7c eb                	jl     5cdc <fwp_tape_reserve+0x3c>
    5cf1:	0f 1f 40 00          	nopl   0x0(%rax)
    5cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5cfc:	00 00 00 00 
    5d00:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5d07:	00 
    5d08:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5d0c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5d10:	4c 89 ee             	mov    %r13,%rsi
    5d13:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5d17:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5d1b:	e8 b0 d8 ff ff       	call   35d0 <realloc@plt>
    5d20:	48 85 c0             	test   %rax,%rax
    5d23:	0f 84 71 01 00 00    	je     5e9a <fwp_tape_reserve+0x1fa>
    5d29:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5d2d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5d31:	4d 29 fc             	sub    %r15,%r12
    5d34:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5d38:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5d3c:	4d 85 f6             	test   %r14,%r14
    5d3f:	0f 84 03 01 00 00    	je     5e48 <fwp_tape_reserve+0x1a8>
    5d45:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5d49:	48 39 da             	cmp    %rbx,%rdx
    5d4c:	7d 78                	jge    5dc6 <fwp_tape_reserve+0x126>
    5d4e:	48 89 d9             	mov    %rbx,%rcx
    5d51:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5d55:	be 02 00 00 00       	mov    $0x2,%esi
    5d5a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5d5f:	48 c1 e1 04          	shl    $0x4,%rcx
    5d63:	48 89 cf             	mov    %rcx,%rdi
    5d66:	48 89 0c 24          	mov    %rcx,(%rsp)
    5d6a:	e8 e1 fc ff ff       	call   5a50 <fwp_heap_alloc>
    5d6f:	49 89 c5             	mov    %rax,%r13
    5d72:	4d 85 ff             	test   %r15,%r15
    5d75:	74 27                	je     5d9e <fwp_tape_reserve+0xfe>
    5d77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5d7c:	48 8b 0c 24          	mov    (%rsp),%rcx
    5d80:	48 89 c7             	mov    %rax,%rdi
    5d83:	4c 89 fe             	mov    %r15,%rsi
    5d86:	48 c1 e2 04          	shl    $0x4,%rdx
    5d8a:	48 39 ca             	cmp    %rcx,%rdx
    5d8d:	48 0f 47 d1          	cmova  %rcx,%rdx
    5d91:	e8 0a d8 ff ff       	call   35a0 <memcpy@plt>
    5d96:	4c 89 ff             	mov    %r15,%rdi
    5d99:	e8 b2 f7 ff ff       	call   5550 <fwp_mem_free>
    5d9e:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5da2:	48 89 da             	mov    %rbx,%rdx
    5da5:	31 f6                	xor    %esi,%esi
    5da7:	48 29 fa             	sub    %rdi,%rdx
    5daa:	48 c1 e7 04          	shl    $0x4,%rdi
    5dae:	48 c1 e2 04          	shl    $0x4,%rdx
    5db2:	4c 01 ef             	add    %r13,%rdi
    5db5:	e8 06 d7 ff ff       	call   34c0 <memset@plt>
    5dba:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5dbe:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5dc2:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    5dc6:	4d 85 e4             	test   %r12,%r12
    5dc9:	75 55                	jne    5e20 <fwp_tape_reserve+0x180>
    5dcb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5dd2:	00 
    5dd3:	4c 01 e8             	add    %r13,%rax
    5dd6:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5dda:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5dde:	48 83 c4 18          	add    $0x18,%rsp
    5de2:	5b                   	pop    %rbx
    5de3:	5d                   	pop    %rbp
    5de4:	41 5c                	pop    %r12
    5de6:	41 5d                	pop    %r13
    5de8:	41 5e                	pop    %r14
    5dea:	41 5f                	pop    %r15
    5dec:	c3                   	ret
    5ded:	0f 1f 00             	nopl   (%rax)
    5df0:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5df5:	e9 06 ff ff ff       	jmp    5d00 <fwp_tape_reserve+0x60>
    5dfa:	4d 39 f5             	cmp    %r14,%r13
    5dfd:	4c 89 f1             	mov    %r14,%rcx
    5e00:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    5e07:	00 
    5e08:	49 0f 43 cd          	cmovae %r13,%rcx
    5e0c:	4c 29 e9             	sub    %r13,%rcx
    5e0f:	e8 4c d7 ff ff       	call   3560 <__memmove_chk@plt>
    5e14:	4c 03 6d 30          	add    0x30(%rbp),%r13
    5e18:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e1c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    5e20:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    5e24:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5e2b:	00 
    5e2c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    5e33:	00 
    5e34:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5e38:	e8 d3 d7 ff ff       	call   3610 <memmove@plt>
    5e3d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e41:	eb 90                	jmp    5dd3 <fwp_tape_reserve+0x133>
    5e43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e48:	49 89 de             	mov    %rbx,%r14
    5e4b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5e4f:	49 c1 e6 04          	shl    $0x4,%r14
    5e53:	4c 89 f6             	mov    %r14,%rsi
    5e56:	e8 75 d7 ff ff       	call   35d0 <realloc@plt>
    5e5b:	48 85 c0             	test   %rax,%rax
    5e5e:	74 3a                	je     5e9a <fwp_tape_reserve+0x1fa>
    5e60:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5e64:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5e68:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5e6c:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    5e70:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    5e74:	4d 85 e4             	test   %r12,%r12
    5e77:	75 81                	jne    5dfa <fwp_tape_reserve+0x15a>
    5e79:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    5e7d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5e81:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5e88:	00 
    5e89:	e9 45 ff ff ff       	jmp    5dd3 <fwp_tape_reserve+0x133>
    5e8e:	48 8d 3d 54 92 00 00 	lea    0x9254(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    5e95:	e8 06 e3 ff ff       	call   41a0 <fwp_trap>
    5e9a:	48 89 ef             	mov    %rbp,%rdi
    5e9d:	e8 5e dd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5ea2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5ea6:	e8 15 d5 ff ff       	call   33c0 <free@plt>
    5eab:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5eaf:	e8 0c d5 ff ff       	call   33c0 <free@plt>
    5eb4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    5eb8:	e8 03 d5 ff ff       	call   33c0 <free@plt>
    5ebd:	31 c9                	xor    %ecx,%ecx
    5ebf:	31 c0                	xor    %eax,%eax
    5ec1:	31 d2                	xor    %edx,%edx
    5ec3:	89 55 04             	mov    %edx,0x4(%rbp)
    5ec6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5eca:	ba 13 00 00 00       	mov    $0x13,%edx
    5ecf:	be 01 00 00 00       	mov    $0x1,%esi
    5ed4:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    5ed8:	48 8d 3d 29 91 00 00 	lea    0x9129(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    5edf:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5ee3:	48 8b 0d 56 d1 00 00 	mov    0xd156(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5eea:	48 89 45 40          	mov    %rax,0x40(%rbp)
    5eee:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    5ef2:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    5ef6:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    5efa:	e8 81 d7 ff ff       	call   3680 <fwrite@plt>
    5eff:	31 ff                	xor    %edi,%edi
    5f01:	e8 ba d6 ff ff       	call   35c0 <fflush@plt>
    5f06:	bf 66 00 00 00       	mov    $0x66,%edi
    5f0b:	e8 90 d7 ff ff       	call   36a0 <_Exit@plt>

0000000000005f10 <f141.constprop.0>:
    5f10:	41 57                	push   %r15
    5f12:	41 56                	push   %r14
    5f14:	41 55                	push   %r13
    5f16:	41 54                	push   %r12
    5f18:	49 89 f4             	mov    %rsi,%r12
    5f1b:	55                   	push   %rbp
    5f1c:	48 89 fd             	mov    %rdi,%rbp
    5f1f:	53                   	push   %rbx
    5f20:	48 83 ec 08          	sub    $0x8,%rsp
    5f24:	48 85 ff             	test   %rdi,%rdi
    5f27:	79 09                	jns    5f32 <f141.constprop.0+0x22>
    5f29:	48 85 f6             	test   %rsi,%rsi
    5f2c:	0f 88 fe 00 00 00    	js     6030 <f141.constprop.0+0x120>
    5f32:	48 89 f8             	mov    %rdi,%rax
    5f35:	48 09 f0             	or     %rsi,%rax
    5f38:	0f 89 d2 00 00 00    	jns    6010 <f141.constprop.0+0x100>
    5f3e:	48 89 f8             	mov    %rdi,%rax
    5f41:	48 c1 f8 20          	sar    $0x20,%rax
    5f45:	48 85 ff             	test   %rdi,%rdi
    5f48:	0f 88 02 01 00 00    	js     6050 <f141.constprop.0+0x140>
    5f4e:	4c 8b 3d 53 9b 00 00 	mov    0x9b53(%rip),%r15        # faa8 <msg.4+0x28>
    5f55:	48 89 c7             	mov    %rax,%rdi
    5f58:	e8 23 e5 ff ff       	call   4480 <fwp_tape_of>
    5f5d:	48 89 c3             	mov    %rax,%rbx
    5f60:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f65:	0f 85 16 01 00 00    	jne    6081 <f141.constprop.0+0x171>
    5f6b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    5f6f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    5f76:	0f 8f f9 00 00 00    	jg     6075 <f141.constprop.0+0x165>
    5f7c:	89 e8                	mov    %ebp,%eax
    5f7e:	49 39 c5             	cmp    %rax,%r13
    5f81:	0f 8e e2 00 00 00    	jle    6069 <f141.constprop.0+0x159>
    5f87:	4d 85 e4             	test   %r12,%r12
    5f8a:	78 0c                	js     5f98 <f141.constprop.0+0x88>
    5f8c:	44 89 e0             	mov    %r12d,%eax
    5f8f:	49 39 c5             	cmp    %rax,%r13
    5f92:	0f 8e d1 00 00 00    	jle    6069 <f141.constprop.0+0x159>
    5f98:	4d 89 ee             	mov    %r13,%r14
    5f9b:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    5f9f:	48 89 df             	mov    %rbx,%rdi
    5fa2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    5fa6:	e8 f5 fc ff ff       	call   5ca0 <fwp_tape_reserve>
    5fab:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5faf:	4d 85 e4             	test   %r12,%r12
    5fb2:	48 8b 0d ef 9a 00 00 	mov    0x9aef(%rip),%rcx        # faa8 <msg.4+0x28>
    5fb9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    5fc0:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    5fc4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    5fc8:	4c 0f 48 e2          	cmovs  %rdx,%r12
    5fcc:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    5fd0:	48 8b 43 28          	mov    0x28(%rbx),%rax
    5fd4:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    5fd8:	48 8b 43 38          	mov    0x38(%rbx),%rax
    5fdc:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    5fe0:	49 8d 45 01          	lea    0x1(%r13),%rax
    5fe4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5fe8:	48 83 c4 08          	add    $0x8,%rsp
    5fec:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5ff3:	ff ff ff 
    5ff6:	48 21 e8             	and    %rbp,%rax
    5ff9:	5b                   	pop    %rbx
    5ffa:	5d                   	pop    %rbp
    5ffb:	4c 09 e8             	or     %r13,%rax
    5ffe:	41 5c                	pop    %r12
    6000:	41 5d                	pop    %r13
    6002:	41 5e                	pop    %r14
    6004:	41 5f                	pop    %r15
    6006:	c3                   	ret
    6007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    600e:	00 00 
    6010:	48 89 f0             	mov    %rsi,%rax
    6013:	48 c1 ff 20          	sar    $0x20,%rdi
    6017:	48 c1 f8 20          	sar    $0x20,%rax
    601b:	48 39 c7             	cmp    %rax,%rdi
    601e:	0f 84 2a ff ff ff    	je     5f4e <f141.constprop.0+0x3e>
    6024:	48 8d 3d 9d 97 00 00 	lea    0x979d(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    602b:	e8 70 e1 ff ff       	call   41a0 <fwp_trap>
    6030:	48 83 c4 08          	add    $0x8,%rsp
    6034:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    603b:	5b                   	pop    %rbx
    603c:	5d                   	pop    %rbp
    603d:	41 5c                	pop    %r12
    603f:	41 5d                	pop    %r13
    6041:	41 5e                	pop    %r14
    6043:	41 5f                	pop    %r15
    6045:	c3                   	ret
    6046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    604d:	00 00 00 
    6050:	48 89 f0             	mov    %rsi,%rax
    6053:	48 89 f5             	mov    %rsi,%rbp
    6056:	45 31 ff             	xor    %r15d,%r15d
    6059:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6060:	48 c1 f8 20          	sar    $0x20,%rax
    6064:	e9 ec fe ff ff       	jmp    5f55 <f141.constprop.0+0x45>
    6069:	48 8d 3d 94 90 00 00 	lea    0x9094(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6070:	e8 2b e1 ff ff       	call   41a0 <fwp_trap>
    6075:	48 8d 3d 6d 90 00 00 	lea    0x906d(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    607c:	e8 1f e1 ff ff       	call   41a0 <fwp_trap>
    6081:	48 8d 3d 88 97 00 00 	lea    0x9788(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    6088:	e8 13 e1 ff ff       	call   41a0 <fwp_trap>
    608d:	0f 1f 00             	nopl   (%rax)

0000000000006090 <w120>:
    6090:	66 0f 28 d0          	movapd %xmm0,%xmm2
    6094:	41 57                	push   %r15
    6096:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    609a:	41 56                	push   %r14
    609c:	41 55                	push   %r13
    609e:	41 54                	push   %r12
    60a0:	49 89 f4             	mov    %rsi,%r12
    60a3:	55                   	push   %rbp
    60a4:	48 89 fd             	mov    %rdi,%rbp
    60a7:	53                   	push   %rbx
    60a8:	48 83 ec 38          	sub    $0x38,%rsp
    60ac:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    60b1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    60b7:	48 85 ff             	test   %rdi,%rdi
    60ba:	0f 88 d0 04 00 00    	js     6590 <w120+0x500>
    60c0:	49 89 ff             	mov    %rdi,%r15
    60c3:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    60c9:	49 c1 ff 20          	sar    $0x20,%r15
    60cd:	4c 89 ff             	mov    %r15,%rdi
    60d0:	e8 ab e3 ff ff       	call   4480 <fwp_tape_of>
    60d5:	48 89 c3             	mov    %rax,%rbx
    60d8:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    60dd:	0f 85 45 05 00 00    	jne    6628 <w120+0x598>
    60e3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    60e7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    60ee:	0f 8f 28 05 00 00    	jg     661c <w120+0x58c>
    60f4:	89 e8                	mov    %ebp,%eax
    60f6:	49 39 c5             	cmp    %rax,%r13
    60f9:	0f 8e 11 05 00 00    	jle    6610 <w120+0x580>
    60ff:	4d 89 ee             	mov    %r13,%r14
    6102:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6106:	48 89 df             	mov    %rbx,%rdi
    6109:	49 8d 76 01          	lea    0x1(%r14),%rsi
    610d:	e8 8e fb ff ff       	call   5ca0 <fwp_tape_reserve>
    6112:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6116:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    611b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6121:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6125:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6129:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    612f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6133:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6137:	48 8b 43 38          	mov    0x38(%rbx),%rax
    613b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6141:	49 8d 45 01          	lea    0x1(%r13),%rax
    6145:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    614c:	ff ff ff 
    614f:	49 21 ee             	and    %rbp,%r14
    6152:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6156:	4d 09 ee             	or     %r13,%r14
    6159:	4d 89 f5             	mov    %r14,%r13
    615c:	49 c1 fd 20          	sar    $0x20,%r13
    6160:	4d 85 e4             	test   %r12,%r12
    6163:	78 10                	js     6175 <w120+0xe5>
    6165:	4c 89 e0             	mov    %r12,%rax
    6168:	48 c1 f8 20          	sar    $0x20,%rax
    616c:	4c 39 e8             	cmp    %r13,%rax
    616f:	0f 85 87 04 00 00    	jne    65fc <w120+0x56c>
    6175:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    617b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6181:	4d 39 ef             	cmp    %r13,%r15
    6184:	0f 84 d6 03 00 00    	je     6560 <w120+0x4d0>
    618a:	f2 0f 10 1d 16 99 00 	movsd  0x9916(%rip),%xmm3        # faa8 <msg.4+0x28>
    6191:	00 
    6192:	f2 0f 10 25 16 99 00 	movsd  0x9916(%rip),%xmm4        # fab0 <msg.4+0x30>
    6199:	00 
    619a:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    61a0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    61a6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    61ac:	4c 89 ef             	mov    %r13,%rdi
    61af:	e8 cc e2 ff ff       	call   4480 <fwp_tape_of>
    61b4:	48 89 c3             	mov    %rax,%rbx
    61b7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61bc:	0f 85 66 04 00 00    	jne    6628 <w120+0x598>
    61c2:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    61c6:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    61cd:	0f 8f 49 04 00 00    	jg     661c <w120+0x58c>
    61d3:	44 89 f0             	mov    %r14d,%eax
    61d6:	49 39 c7             	cmp    %rax,%r15
    61d9:	0f 8e 31 04 00 00    	jle    6610 <w120+0x580>
    61df:	4d 85 e4             	test   %r12,%r12
    61e2:	78 0c                	js     61f0 <w120+0x160>
    61e4:	44 89 e0             	mov    %r12d,%eax
    61e7:	49 39 c7             	cmp    %rax,%r15
    61ea:	0f 8e 20 04 00 00    	jle    6610 <w120+0x580>
    61f0:	4c 89 f9             	mov    %r15,%rcx
    61f3:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    61f7:	48 89 df             	mov    %rbx,%rdi
    61fa:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    61fe:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6203:	e8 98 fa ff ff       	call   5ca0 <fwp_tape_reserve>
    6208:	48 8b 43 20          	mov    0x20(%rbx),%rax
    620c:	4d 85 e4             	test   %r12,%r12
    620f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6213:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6218:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    621e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6224:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6228:	48 8b 43 30          	mov    0x30(%rbx),%rax
    622c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6231:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6238:	49 0f 49 c4          	cmovns %r12,%rax
    623c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6240:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6243:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6247:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    624c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6250:	48 85 ed             	test   %rbp,%rbp
    6253:	0f 88 0e 04 00 00    	js     6667 <w120+0x5d7>
    6259:	48 89 e8             	mov    %rbp,%rax
    625c:	48 c1 f8 20          	sar    $0x20,%rax
    6260:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6265:	49 39 c5             	cmp    %rax,%r13
    6268:	74 1a                	je     6284 <w120+0x1f4>
    626a:	48 89 c7             	mov    %rax,%rdi
    626d:	e8 0e e2 ff ff       	call   4480 <fwp_tape_of>
    6272:	48 89 c3             	mov    %rax,%rbx
    6275:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    627a:	0f 85 a8 03 00 00    	jne    6628 <w120+0x598>
    6280:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6284:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    628b:	0f 8f 8b 03 00 00    	jg     661c <w120+0x58c>
    6291:	89 e8                	mov    %ebp,%eax
    6293:	4c 39 e0             	cmp    %r12,%rax
    6296:	0f 8d 74 03 00 00    	jge    6610 <w120+0x580>
    629c:	4c 89 e0             	mov    %r12,%rax
    629f:	48 2b 43 08          	sub    0x8(%rbx),%rax
    62a3:	48 89 df             	mov    %rbx,%rdi
    62a6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    62aa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    62af:	e8 ec f9 ff ff       	call   5ca0 <fwp_tape_reserve>
    62b4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    62b9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    62bd:	48 8b 0d ec 97 00 00 	mov    0x97ec(%rip),%rcx        # fab0 <msg.4+0x30>
    62c4:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    62ca:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    62cd:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    62d1:	66 0f 28 ee          	movapd %xmm6,%xmm5
    62d5:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    62db:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    62df:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    62e3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    62e7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    62ee:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    62f2:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    62f7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    62fc:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6300:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6307:	ff ff ff 
    630a:	48 21 c5             	and    %rax,%rbp
    630d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6313:	4c 09 e5             	or     %r12,%rbp
    6316:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    631d:	ff ff ff 
    6320:	49 21 c6             	and    %rax,%r14
    6323:	4d 09 fe             	or     %r15,%r14
    6326:	4d 89 f4             	mov    %r14,%r12
    6329:	49 c1 fc 20          	sar    $0x20,%r12
    632d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6332:	74 16                	je     634a <w120+0x2ba>
    6334:	4c 89 e7             	mov    %r12,%rdi
    6337:	e8 44 e1 ff ff       	call   4480 <fwp_tape_of>
    633c:	48 89 c3             	mov    %rax,%rbx
    633f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6344:	0f 85 de 02 00 00    	jne    6628 <w120+0x598>
    634a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    634e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6355:	0f 8f c1 02 00 00    	jg     661c <w120+0x58c>
    635b:	44 89 f0             	mov    %r14d,%eax
    635e:	49 39 c7             	cmp    %rax,%r15
    6361:	0f 8e a9 02 00 00    	jle    6610 <w120+0x580>
    6367:	4d 89 fd             	mov    %r15,%r13
    636a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    636e:	48 89 df             	mov    %rbx,%rdi
    6371:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6375:	e8 26 f9 ff ff       	call   5ca0 <fwp_tape_reserve>
    637a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    637e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6384:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6388:	48 8b 43 30          	mov    0x30(%rbx),%rax
    638c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6392:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6396:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    639a:	48 8b 43 38          	mov    0x38(%rbx),%rax
    639e:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    63a4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    63a8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    63af:	ff ff ff 
    63b2:	49 21 c6             	and    %rax,%r14
    63b5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    63b9:	4d 09 fe             	or     %r15,%r14
    63bc:	4d 89 f7             	mov    %r14,%r15
    63bf:	49 c1 ff 20          	sar    $0x20,%r15
    63c3:	4d 39 e7             	cmp    %r12,%r15
    63c6:	74 1d                	je     63e5 <w120+0x355>
    63c8:	4c 89 ff             	mov    %r15,%rdi
    63cb:	e8 b0 e0 ff ff       	call   4480 <fwp_tape_of>
    63d0:	48 89 c3             	mov    %rax,%rbx
    63d3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63d8:	0f 85 4a 02 00 00    	jne    6628 <w120+0x598>
    63de:	4c 8b 68 10          	mov    0x10(%rax),%r13
    63e2:	4d 89 fc             	mov    %r15,%r12
    63e5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    63ec:	0f 8f 2a 02 00 00    	jg     661c <w120+0x58c>
    63f2:	44 89 f0             	mov    %r14d,%eax
    63f5:	4c 39 e8             	cmp    %r13,%rax
    63f8:	0f 8d 12 02 00 00    	jge    6610 <w120+0x580>
    63fe:	f2 0f 10 3d b2 96 00 	movsd  0x96b2(%rip),%xmm7        # fab8 <msg.4+0x38>
    6405:	00 
    6406:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    640c:	4d 89 ef             	mov    %r13,%r15
    640f:	48 89 df             	mov    %rbx,%rdi
    6412:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6418:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    641d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6421:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6425:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    642a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6430:	e8 6b f8 ff ff       	call   5ca0 <fwp_tape_reserve>
    6435:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6439:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    643e:	48 8b 15 73 96 00 00 	mov    0x9673(%rip),%rdx        # fab8 <msg.4+0x38>
    6445:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6449:	48 8b 43 30          	mov    0x30(%rbx),%rax
    644d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6451:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6455:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6459:	48 8b 43 28          	mov    0x28(%rbx),%rax
    645d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6464:	ff 
    6465:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6469:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6470:	00 
    6471:	49 8d 45 01          	lea    0x1(%r13),%rax
    6475:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6479:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6480:	ff ff ff 
    6483:	49 21 c6             	and    %rax,%r14
    6486:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    648c:	4d 09 ee             	or     %r13,%r14
    648f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6493:	0f 84 57 01 00 00    	je     65f0 <w120+0x560>
    6499:	48 89 ef             	mov    %rbp,%rdi
    649c:	48 c1 ff 20          	sar    $0x20,%rdi
    64a0:	4c 39 e7             	cmp    %r12,%rdi
    64a3:	74 13                	je     64b8 <w120+0x428>
    64a5:	e8 d6 df ff ff       	call   4480 <fwp_tape_of>
    64aa:	48 89 c3             	mov    %rax,%rbx
    64ad:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64b2:	0f 85 70 01 00 00    	jne    6628 <w120+0x598>
    64b8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    64bc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    64c3:	0f 8f 53 01 00 00    	jg     661c <w120+0x58c>
    64c9:	89 e8                	mov    %ebp,%eax
    64cb:	4c 39 e0             	cmp    %r12,%rax
    64ce:	0f 8d 3c 01 00 00    	jge    6610 <w120+0x580>
    64d4:	4d 89 e5             	mov    %r12,%r13
    64d7:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    64db:	48 89 df             	mov    %rbx,%rdi
    64de:	49 8d 75 01          	lea    0x1(%r13),%rsi
    64e2:	e8 b9 f7 ff ff       	call   5ca0 <fwp_tape_reserve>
    64e7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    64eb:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    64f0:	48 89 ef             	mov    %rbp,%rdi
    64f3:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    64f7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    64fb:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6501:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6505:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6509:	48 8b 43 38          	mov    0x38(%rbx),%rax
    650d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6513:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6518:	48 89 43 10          	mov    %rax,0x10(%rbx)
    651c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6523:	ff ff ff 
    6526:	48 21 c7             	and    %rax,%rdi
    6529:	4c 09 e7             	or     %r12,%rdi
    652c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6532:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6538:	4c 89 f6             	mov    %r14,%rsi
    653b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6540:	e8 cb f9 ff ff       	call   5f10 <f141.constprop.0>
    6545:	48 83 c4 38          	add    $0x38,%rsp
    6549:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    654e:	5b                   	pop    %rbx
    654f:	5d                   	pop    %rbp
    6550:	41 5c                	pop    %r12
    6552:	41 5d                	pop    %r13
    6554:	41 5e                	pop    %r14
    6556:	41 5f                	pop    %r15
    6558:	c3                   	ret
    6559:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6560:	f2 0f 10 3d 40 95 00 	movsd  0x9540(%rip),%xmm7        # faa8 <msg.4+0x28>
    6567:	00 
    6568:	f2 0f 10 15 40 95 00 	movsd  0x9540(%rip),%xmm2        # fab0 <msg.4+0x30>
    656f:	00 
    6570:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6576:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    657c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6582:	e9 3b fc ff ff       	jmp    61c2 <w120+0x132>
    6587:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    658e:	00 00 
    6590:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6596:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    659c:	48 85 f6             	test   %rsi,%rsi
    659f:	0f 89 8f 00 00 00    	jns    6634 <w120+0x5a4>
    65a5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65ab:	f2 0f 10 05 f5 94 00 	movsd  0x94f5(%rip),%xmm0        # faa8 <msg.4+0x28>
    65b2:	00 
    65b3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    65ba:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65c1:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    65c6:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    65ca:	f2 0f 59 0d e6 94 00 	mulsd  0x94e6(%rip),%xmm1        # fab8 <msg.4+0x38>
    65d1:	00 
    65d2:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    65d6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    65dc:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    65e2:	e9 45 ff ff ff       	jmp    652c <w120+0x49c>
    65e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    65ee:	00 00 
    65f0:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65f7:	e9 30 ff ff ff       	jmp    652c <w120+0x49c>
    65fc:	48 8d 3d c5 91 00 00 	lea    0x91c5(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    6603:	e8 98 db ff ff       	call   41a0 <fwp_trap>
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 
    6610:	48 8d 3d ed 8a 00 00 	lea    0x8aed(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6617:	e8 84 db ff ff       	call   41a0 <fwp_trap>
    661c:	48 8d 3d c6 8a 00 00 	lea    0x8ac6(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    6623:	e8 78 db ff ff       	call   41a0 <fwp_trap>
    6628:	48 8d 3d e1 91 00 00 	lea    0x91e1(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    662f:	e8 6c db ff ff       	call   41a0 <fwp_trap>
    6634:	f2 0f 10 35 6c 94 00 	movsd  0x946c(%rip),%xmm6        # faa8 <msg.4+0x28>
    663b:	00 
    663c:	49 89 f5             	mov    %rsi,%r13
    663f:	49 89 f6             	mov    %rsi,%r14
    6642:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6649:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6650:	00 00 
    6652:	49 c1 fd 20          	sar    $0x20,%r13
    6656:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    665c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6662:	e9 45 fb ff ff       	jmp    61ac <w120+0x11c>
    6667:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    666d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6672:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6679:	66 0f 28 f4          	movapd %xmm4,%xmm6
    667d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6681:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6687:	e9 8a fc ff ff       	jmp    6316 <w120+0x286>
    668c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006690 <fwp_rc_share>:
    6690:	48 8b 05 a1 e4 01 00 	mov    0x1e4a1(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    6697:	48 2b 3d 72 e4 01 00 	sub    0x1e472(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    669e:	48 c1 e0 10          	shl    $0x10,%rax
    66a2:	48 39 c7             	cmp    %rax,%rdi
    66a5:	73 4a                	jae    66f1 <fwp_rc_share+0x61>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 c1 e8 10          	shr    $0x10,%rax
    66ae:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    66b2:	48 8b 05 9f e4 01 00 	mov    0x1e49f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    66b9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    66bd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    66c1:	48 85 d2             	test   %rdx,%rdx
    66c4:	74 2b                	je     66f1 <fwp_rc_share+0x61>
    66c6:	0f b6 08             	movzbl (%rax),%ecx
    66c9:	80 f9 02             	cmp    $0x2,%cl
    66cc:	74 2a                	je     66f8 <fwp_rc_share+0x68>
    66ce:	80 f9 01             	cmp    $0x1,%cl
    66d1:	75 1e                	jne    66f1 <fwp_rc_share+0x61>
    66d3:	8b 48 18             	mov    0x18(%rax),%ecx
    66d6:	0f b7 ff             	movzwl %di,%edi
    66d9:	8b 40 1c             	mov    0x1c(%rax),%eax
    66dc:	48 0f af f9          	imul   %rcx,%rdi
    66e0:	48 c1 ef 20          	shr    $0x20,%rdi
    66e4:	48 39 c7             	cmp    %rax,%rdi
    66e7:	73 08                	jae    66f1 <fwp_rc_share+0x61>
    66e9:	48 01 fa             	add    %rdi,%rdx
    66ec:	80 3a 00             	cmpb   $0x0,(%rdx)
    66ef:	75 0d                	jne    66fe <fwp_rc_share+0x6e>
    66f1:	c3                   	ret
    66f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    66f8:	66 85 ff             	test   %di,%di
    66fb:	74 ef                	je     66ec <fwp_rc_share+0x5c>
    66fd:	c3                   	ret
    66fe:	50                   	push   %rax
    66ff:	48 8d 3d 3a 91 00 00 	lea    0x913a(%rip),%rdi        # f840 <_IO_stdin_used+0x840>
    6706:	e8 95 da ff ff       	call   41a0 <fwp_trap>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006710 <fwp_rc_fresh>:
    6710:	48 8b 15 21 e4 01 00 	mov    0x1e421(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6717:	48 89 f8             	mov    %rdi,%rax
    671a:	48 89 fe             	mov    %rdi,%rsi
    671d:	48 2b 05 ec e3 01 00 	sub    0x1e3ec(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6724:	48 c1 e2 10          	shl    $0x10,%rdx
    6728:	48 39 d0             	cmp    %rdx,%rax
    672b:	73 4f                	jae    677c <fwp_rc_fresh+0x6c>
    672d:	48 89 c2             	mov    %rax,%rdx
    6730:	48 c1 ea 10          	shr    $0x10,%rdx
    6734:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6738:	48 8b 15 19 e4 01 00 	mov    0x1e419(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    673f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6743:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6747:	48 85 d2             	test   %rdx,%rdx
    674a:	74 30                	je     677c <fwp_rc_fresh+0x6c>
    674c:	0f b6 39             	movzbl (%rcx),%edi
    674f:	40 80 ff 02          	cmp    $0x2,%dil
    6753:	74 2b                	je     6780 <fwp_rc_fresh+0x70>
    6755:	40 80 ff 01          	cmp    $0x1,%dil
    6759:	75 21                	jne    677c <fwp_rc_fresh+0x6c>
    675b:	8b 79 18             	mov    0x18(%rcx),%edi
    675e:	0f b7 c0             	movzwl %ax,%eax
    6761:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6764:	48 0f af c7          	imul   %rdi,%rax
    6768:	48 c1 e8 20          	shr    $0x20,%rax
    676c:	48 39 c8             	cmp    %rcx,%rax
    676f:	73 0b                	jae    677c <fwp_rc_fresh+0x6c>
    6771:	48 01 c2             	add    %rax,%rdx
    6774:	80 3a ff             	cmpb   $0xff,(%rdx)
    6777:	74 17                	je     6790 <fwp_rc_fresh+0x80>
    6779:	c6 02 01             	movb   $0x1,(%rdx)
    677c:	48 89 f0             	mov    %rsi,%rax
    677f:	c3                   	ret
    6780:	66 85 c0             	test   %ax,%ax
    6783:	74 ef                	je     6774 <fwp_rc_fresh+0x64>
    6785:	48 89 f0             	mov    %rsi,%rax
    6788:	c3                   	ret
    6789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6790:	48 83 ec 18          	sub    $0x18,%rsp
    6794:	48 89 d7             	mov    %rdx,%rdi
    6797:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    679c:	48 89 14 24          	mov    %rdx,(%rsp)
    67a0:	e8 6b eb ff ff       	call   5310 <fwp_rc_forget_slot>
    67a5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    67aa:	48 8b 14 24          	mov    (%rsp),%rdx
    67ae:	48 89 f0             	mov    %rsi,%rax
    67b1:	c6 02 01             	movb   $0x1,(%rdx)
    67b4:	48 83 c4 18          	add    $0x18,%rsp
    67b8:	c3                   	ret
    67b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000067c0 <fwp_rc_free_obj>:
    67c0:	48 8b 15 71 e3 01 00 	mov    0x1e371(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    67c7:	48 89 f8             	mov    %rdi,%rax
    67ca:	48 2b 05 3f e3 01 00 	sub    0x1e33f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    67d1:	48 c1 e2 10          	shl    $0x10,%rdx
    67d5:	48 39 d0             	cmp    %rdx,%rax
    67d8:	73 5b                	jae    6835 <fwp_rc_free_obj+0x75>
    67da:	48 89 c2             	mov    %rax,%rdx
    67dd:	48 c1 ea 10          	shr    $0x10,%rdx
    67e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    67e5:	48 8b 15 6c e3 01 00 	mov    0x1e36c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    67ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    67f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    67f4:	48 85 c9             	test   %rcx,%rcx
    67f7:	74 3c                	je     6835 <fwp_rc_free_obj+0x75>
    67f9:	0f b6 32             	movzbl (%rdx),%esi
    67fc:	40 80 fe 02          	cmp    $0x2,%sil
    6800:	74 2e                	je     6830 <fwp_rc_free_obj+0x70>
    6802:	40 80 fe 01          	cmp    $0x1,%sil
    6806:	75 2d                	jne    6835 <fwp_rc_free_obj+0x75>
    6808:	8b 72 18             	mov    0x18(%rdx),%esi
    680b:	0f b7 c0             	movzwl %ax,%eax
    680e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6811:	48 0f af c6          	imul   %rsi,%rax
    6815:	48 c1 e8 20          	shr    $0x20,%rax
    6819:	48 39 d0             	cmp    %rdx,%rax
    681c:	73 17                	jae    6835 <fwp_rc_free_obj+0x75>
    681e:	48 01 c1             	add    %rax,%rcx
    6821:	80 39 01             	cmpb   $0x1,(%rcx)
    6824:	75 0f                	jne    6835 <fwp_rc_free_obj+0x75>
    6826:	e9 25 ed ff ff       	jmp    5550 <fwp_mem_free>
    682b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6830:	66 85 c0             	test   %ax,%ax
    6833:	74 ec                	je     6821 <fwp_rc_free_obj+0x61>
    6835:	c3                   	ret
    6836:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    683d:	00 00 00 

0000000000006840 <fwp_rc_dup>:
    6840:	f3 0f 1e fa          	endbr64
    6844:	48 8b 05 ed e2 01 00 	mov    0x1e2ed(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    684b:	48 2b 3d be e2 01 00 	sub    0x1e2be(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    6852:	48 c1 e0 10          	shl    $0x10,%rax
    6856:	48 39 c7             	cmp    %rax,%rdi
    6859:	73 56                	jae    68b1 <fwp_rc_dup+0x71>
    685b:	48 89 f8             	mov    %rdi,%rax
    685e:	48 c1 e8 10          	shr    $0x10,%rax
    6862:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6866:	48 8b 05 eb e2 01 00 	mov    0x1e2eb(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    686d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6871:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6875:	48 85 c0             	test   %rax,%rax
    6878:	74 37                	je     68b1 <fwp_rc_dup+0x71>
    687a:	0f b6 0a             	movzbl (%rdx),%ecx
    687d:	80 f9 02             	cmp    $0x2,%cl
    6880:	74 36                	je     68b8 <fwp_rc_dup+0x78>
    6882:	80 f9 01             	cmp    $0x1,%cl
    6885:	75 2a                	jne    68b1 <fwp_rc_dup+0x71>
    6887:	8b 4a 18             	mov    0x18(%rdx),%ecx
    688a:	0f b7 ff             	movzwl %di,%edi
    688d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6890:	48 0f af f9          	imul   %rcx,%rdi
    6894:	48 c1 ef 20          	shr    $0x20,%rdi
    6898:	48 39 d7             	cmp    %rdx,%rdi
    689b:	73 14                	jae    68b1 <fwp_rc_dup+0x71>
    689d:	48 01 f8             	add    %rdi,%rax
    68a0:	0f b6 10             	movzbl (%rax),%edx
    68a3:	84 d2                	test   %dl,%dl
    68a5:	74 0a                	je     68b1 <fwp_rc_dup+0x71>
    68a7:	80 fa fd             	cmp    $0xfd,%dl
    68aa:	77 14                	ja     68c0 <fwp_rc_dup+0x80>
    68ac:	83 c2 01             	add    $0x1,%edx
    68af:	88 10                	mov    %dl,(%rax)
    68b1:	c3                   	ret
    68b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68b8:	66 85 ff             	test   %di,%di
    68bb:	74 e3                	je     68a0 <fwp_rc_dup+0x60>
    68bd:	c3                   	ret
    68be:	66 90                	xchg   %ax,%ax
    68c0:	48 89 c7             	mov    %rax,%rdi
    68c3:	e9 28 e9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    68c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    68cf:	00 

00000000000068d0 <fwp_owned_entry173>:
    68d0:	f3 0f 1e fa          	endbr64
    68d4:	48 83 ec 38          	sub    $0x38,%rsp
    68d8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    68dd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    68e4:	00 00 
    68e6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    68eb:	31 c0                	xor    %eax,%eax
    68ed:	48 8b 07             	mov    (%rdi),%rax
    68f0:	48 03 47 10          	add    0x10(%rdi),%rax
    68f4:	0f 80 c2 00 00 00    	jo     69bc <fwp_owned_entry173+0xec>
    68fa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    68ff:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6904:	31 ff                	xor    %edi,%edi
    6906:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    690a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    690f:	e8 5c f2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6914:	48 8b 15 1d e2 01 00 	mov    0x1e21d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    691b:	48 89 c6             	mov    %rax,%rsi
    691e:	48 2b 05 eb e1 01 00 	sub    0x1e1eb(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6925:	48 c1 e2 10          	shl    $0x10,%rdx
    6929:	48 39 d0             	cmp    %rdx,%rax
    692c:	73 4f                	jae    697d <fwp_owned_entry173+0xad>
    692e:	48 89 c2             	mov    %rax,%rdx
    6931:	48 c1 ea 10          	shr    $0x10,%rdx
    6935:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6939:	48 8b 15 18 e2 01 00 	mov    0x1e218(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    6940:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6944:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6948:	48 85 d2             	test   %rdx,%rdx
    694b:	74 30                	je     697d <fwp_owned_entry173+0xad>
    694d:	0f b6 39             	movzbl (%rcx),%edi
    6950:	40 80 ff 02          	cmp    $0x2,%dil
    6954:	74 42                	je     6998 <fwp_owned_entry173+0xc8>
    6956:	40 80 ff 01          	cmp    $0x1,%dil
    695a:	75 21                	jne    697d <fwp_owned_entry173+0xad>
    695c:	8b 79 18             	mov    0x18(%rcx),%edi
    695f:	0f b7 c0             	movzwl %ax,%eax
    6962:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6965:	48 0f af c7          	imul   %rdi,%rax
    6969:	48 c1 e8 20          	shr    $0x20,%rax
    696d:	48 39 c8             	cmp    %rcx,%rax
    6970:	73 0b                	jae    697d <fwp_owned_entry173+0xad>
    6972:	48 01 c2             	add    %rax,%rdx
    6975:	80 3a ff             	cmpb   $0xff,(%rdx)
    6978:	74 26                	je     69a0 <fwp_owned_entry173+0xd0>
    697a:	c6 02 01             	movb   $0x1,(%rdx)
    697d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6982:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6989:	00 00 
    698b:	75 34                	jne    69c1 <fwp_owned_entry173+0xf1>
    698d:	48 89 f0             	mov    %rsi,%rax
    6990:	48 83 c4 38          	add    $0x38,%rsp
    6994:	c3                   	ret
    6995:	0f 1f 00             	nopl   (%rax)
    6998:	66 85 c0             	test   %ax,%ax
    699b:	75 e0                	jne    697d <fwp_owned_entry173+0xad>
    699d:	eb d6                	jmp    6975 <fwp_owned_entry173+0xa5>
    699f:	90                   	nop
    69a0:	48 89 d7             	mov    %rdx,%rdi
    69a3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    69a8:	48 89 14 24          	mov    %rdx,(%rsp)
    69ac:	e8 5f e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    69b1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    69b6:	48 8b 14 24          	mov    (%rsp),%rdx
    69ba:	eb be                	jmp    697a <fwp_owned_entry173+0xaa>
    69bc:	e8 3f cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    69c1:	e8 9a ca ff ff       	call   3460 <__stack_chk_fail@plt>
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 

00000000000069d0 <e173>:
    69d0:	f3 0f 1e fa          	endbr64
    69d4:	53                   	push   %rbx
    69d5:	48 83 ec 30          	sub    $0x30,%rsp
    69d9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    69de:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    69e5:	00 00 
    69e7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    69ec:	31 c0                	xor    %eax,%eax
    69ee:	48 8b 07             	mov    (%rdi),%rax
    69f1:	48 03 47 10          	add    0x10(%rdi),%rax
    69f5:	0f 80 c9 00 00 00    	jo     6ac4 <e173+0xf4>
    69fb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6a00:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6a05:	31 ff                	xor    %edi,%edi
    6a07:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6a0b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6a10:	e8 5b f1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    6a15:	48 8b 15 1c e1 01 00 	mov    0x1e11c(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6a1c:	48 89 c3             	mov    %rax,%rbx
    6a1f:	48 2b 05 ea e0 01 00 	sub    0x1e0ea(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6a26:	48 c1 e2 10          	shl    $0x10,%rdx
    6a2a:	48 39 d0             	cmp    %rdx,%rax
    6a2d:	73 4f                	jae    6a7e <e173+0xae>
    6a2f:	48 89 c2             	mov    %rax,%rdx
    6a32:	48 c1 ea 10          	shr    $0x10,%rdx
    6a36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a3a:	48 8b 15 17 e1 01 00 	mov    0x1e117(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    6a41:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a45:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a49:	48 85 d2             	test   %rdx,%rdx
    6a4c:	74 30                	je     6a7e <e173+0xae>
    6a4e:	0f b6 31             	movzbl (%rcx),%esi
    6a51:	40 80 fe 02          	cmp    $0x2,%sil
    6a55:	74 49                	je     6aa0 <e173+0xd0>
    6a57:	40 80 fe 01          	cmp    $0x1,%sil
    6a5b:	75 21                	jne    6a7e <e173+0xae>
    6a5d:	8b 71 18             	mov    0x18(%rcx),%esi
    6a60:	0f b7 c0             	movzwl %ax,%eax
    6a63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a66:	48 0f af c6          	imul   %rsi,%rax
    6a6a:	48 c1 e8 20          	shr    $0x20,%rax
    6a6e:	48 39 c8             	cmp    %rcx,%rax
    6a71:	73 0b                	jae    6a7e <e173+0xae>
    6a73:	48 01 c2             	add    %rax,%rdx
    6a76:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a79:	74 35                	je     6ab0 <e173+0xe0>
    6a7b:	c6 02 01             	movb   $0x1,(%rdx)
    6a7e:	48 89 df             	mov    %rbx,%rdi
    6a81:	e8 0a fc ff ff       	call   6690 <fwp_rc_share>
    6a86:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a8b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a92:	00 00 
    6a94:	75 33                	jne    6ac9 <e173+0xf9>
    6a96:	48 83 c4 30          	add    $0x30,%rsp
    6a9a:	48 89 d8             	mov    %rbx,%rax
    6a9d:	5b                   	pop    %rbx
    6a9e:	c3                   	ret
    6a9f:	90                   	nop
    6aa0:	66 85 c0             	test   %ax,%ax
    6aa3:	75 d9                	jne    6a7e <e173+0xae>
    6aa5:	eb cf                	jmp    6a76 <e173+0xa6>
    6aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6aae:	00 00 
    6ab0:	48 89 d7             	mov    %rdx,%rdi
    6ab3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ab8:	e8 53 e8 ff ff       	call   5310 <fwp_rc_forget_slot>
    6abd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6ac2:	eb b7                	jmp    6a7b <e173+0xab>
    6ac4:	e8 37 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6ac9:	e8 92 c9 ff ff       	call   3460 <__stack_chk_fail@plt>
    6ace:	66 90                	xchg   %ax,%ax

0000000000006ad0 <fwp_closure_drop>:
    6ad0:	48 8b 15 61 e0 01 00 	mov    0x1e061(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    6ad7:	48 89 f8             	mov    %rdi,%rax
    6ada:	48 2b 05 2f e0 01 00 	sub    0x1e02f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6ae1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ae5:	48 39 d0             	cmp    %rdx,%rax
    6ae8:	73 6b                	jae    6b55 <fwp_closure_drop+0x85>
    6aea:	48 89 c2             	mov    %rax,%rdx
    6aed:	48 c1 ea 10          	shr    $0x10,%rdx
    6af1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6af5:	48 8b 15 5c e0 01 00 	mov    0x1e05c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    6afc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b00:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b04:	48 85 d2             	test   %rdx,%rdx
    6b07:	74 4c                	je     6b55 <fwp_closure_drop+0x85>
    6b09:	0f b6 31             	movzbl (%rcx),%esi
    6b0c:	40 80 fe 02          	cmp    $0x2,%sil
    6b10:	74 3e                	je     6b50 <fwp_closure_drop+0x80>
    6b12:	40 80 fe 01          	cmp    $0x1,%sil
    6b16:	75 3d                	jne    6b55 <fwp_closure_drop+0x85>
    6b18:	8b 71 18             	mov    0x18(%rcx),%esi
    6b1b:	0f b7 c0             	movzwl %ax,%eax
    6b1e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6b21:	48 0f af c6          	imul   %rsi,%rax
    6b25:	48 c1 e8 20          	shr    $0x20,%rax
    6b29:	48 39 c8             	cmp    %rcx,%rax
    6b2c:	73 27                	jae    6b55 <fwp_closure_drop+0x85>
    6b2e:	48 01 c2             	add    %rax,%rdx
    6b31:	0f b6 02             	movzbl (%rdx),%eax
    6b34:	84 c0                	test   %al,%al
    6b36:	74 1d                	je     6b55 <fwp_closure_drop+0x85>
    6b38:	3c 01                	cmp    $0x1,%al
    6b3a:	74 24                	je     6b60 <fwp_closure_drop+0x90>
    6b3c:	3c ff                	cmp    $0xff,%al
    6b3e:	74 48                	je     6b88 <fwp_closure_drop+0xb8>
    6b40:	83 e8 01             	sub    $0x1,%eax
    6b43:	88 02                	mov    %al,(%rdx)
    6b45:	c3                   	ret
    6b46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b4d:	00 00 00 
    6b50:	66 85 c0             	test   %ax,%ax
    6b53:	74 dc                	je     6b31 <fwp_closure_drop+0x61>
    6b55:	c3                   	ret
    6b56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6b5d:	00 00 00 
    6b60:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6b67:	ff ff 
    6b69:	48 85 c0             	test   %rax,%rax
    6b6c:	74 12                	je     6b80 <fwp_closure_drop+0xb0>
    6b6e:	48 89 fe             	mov    %rdi,%rsi
    6b71:	48 89 c7             	mov    %rax,%rdi
    6b74:	e9 87 d6 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6b79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b80:	e9 2b d8 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6b85:	0f 1f 00             	nopl   (%rax)
    6b88:	48 89 d0             	mov    %rdx,%rax
    6b8b:	48 8d 35 ce cb 01 00 	lea    0x1cbce(%rip),%rsi        # 23760 <fwp_heap>
    6b92:	48 83 ec 18          	sub    $0x18,%rsp
    6b96:	48 c1 e8 11          	shr    $0x11,%rax
    6b9a:	48 31 d0             	xor    %rdx,%rax
    6b9d:	48 89 c1             	mov    %rax,%rcx
    6ba0:	48 c1 e9 09          	shr    $0x9,%rcx
    6ba4:	48 31 c8             	xor    %rcx,%rax
    6ba7:	0f b6 c8             	movzbl %al,%ecx
    6baa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6bb1:	00 
    6bb2:	48 85 c0             	test   %rax,%rax
    6bb5:	75 12                	jne    6bc9 <fwp_closure_drop+0xf9>
    6bb7:	eb 49                	jmp    6c02 <fwp_closure_drop+0x132>
    6bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6bc4:	48 85 c0             	test   %rax,%rax
    6bc7:	74 39                	je     6c02 <fwp_closure_drop+0x132>
    6bc9:	48 89 c1             	mov    %rax,%rcx
    6bcc:	48 39 10             	cmp    %rdx,(%rax)
    6bcf:	75 ef                	jne    6bc0 <fwp_closure_drop+0xf0>
    6bd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6bd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6bd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6bdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6be4:	74 05                	je     6beb <fwp_closure_drop+0x11b>
    6be6:	48 83 c4 18          	add    $0x18,%rsp
    6bea:	c3                   	ret
    6beb:	48 89 d7             	mov    %rdx,%rdi
    6bee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bf3:	e8 18 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bf8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bfd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6c00:	eb e4                	jmp    6be6 <fwp_closure_drop+0x116>
    6c02:	48 8d 3d 97 8b 00 00 	lea    0x8b97(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    6c09:	e8 92 d5 ff ff       	call   41a0 <fwp_trap>
    6c0e:	66 90                	xchg   %ax,%ax

0000000000006c10 <fwp_owned_tape_release>:
    6c10:	48 85 ff             	test   %rdi,%rdi
    6c13:	0f 84 f7 00 00 00    	je     6d10 <fwp_owned_tape_release+0x100>
    6c19:	41 54                	push   %r12
    6c1b:	55                   	push   %rbp
    6c1c:	53                   	push   %rbx
    6c1d:	48 8b 07             	mov    (%rdi),%rax
    6c20:	48 85 c0             	test   %rax,%rax
    6c23:	74 08                	je     6c2d <fwp_owned_tape_release+0x1d>
    6c25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6c31:	48 85 d2             	test   %rdx,%rdx
    6c34:	74 03                	je     6c39 <fwp_owned_tape_release+0x29>
    6c36:	48 89 02             	mov    %rax,(%rdx)
    6c39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6c3d:	48 89 fb             	mov    %rdi,%rbx
    6c40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6c44:	48 85 c0             	test   %rax,%rax
    6c47:	0f 84 89 00 00 00    	je     6cd6 <fwp_owned_tape_release+0xc6>
    6c4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6c51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6c55:	7e 47                	jle    6c9e <fwp_owned_tape_release+0x8e>
    6c57:	31 ed                	xor    %ebp,%ebp
    6c59:	eb 0d                	jmp    6c68 <fwp_owned_tape_release+0x58>
    6c5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6c68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6c6c:	49 89 ec             	mov    %rbp,%r12
    6c6f:	48 83 c5 01          	add    $0x1,%rbp
    6c73:	49 c1 e4 04          	shl    $0x4,%r12
    6c77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6c7b:	ff d0                	call   *%rax
    6c7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6c81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6c86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6c8a:	ff 50 68             	call   *0x68(%rax)
    6c8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6c91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6c95:	48 39 e8             	cmp    %rbp,%rax
    6c98:	7f c6                	jg     6c60 <fwp_owned_tape_release+0x50>
    6c9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6c9e:	31 ed                	xor    %ebp,%ebp
    6ca0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6ca5:	7e 28                	jle    6ccf <fwp_owned_tape_release+0xbf>
    6ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cae:	00 00 
    6cb0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6cb4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6cb8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6cbc:	74 07                	je     6cc5 <fwp_owned_tape_release+0xb5>
    6cbe:	ff 52 68             	call   *0x68(%rdx)
    6cc1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6cc5:	48 83 c5 01          	add    $0x1,%rbp
    6cc9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ccd:	7f e1                	jg     6cb0 <fwp_owned_tape_release+0xa0>
    6ccf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6cd3:	ff 52 68             	call   *0x68(%rdx)
    6cd6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6cda:	e8 f1 fd ff ff       	call   6ad0 <fwp_closure_drop>
    6cdf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ce3:	e8 e8 fd ff ff       	call   6ad0 <fwp_closure_drop>
    6ce8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6cec:	e8 df fd ff ff       	call   6ad0 <fwp_closure_drop>
    6cf1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6cf5:	e8 56 e8 ff ff       	call   5550 <fwp_mem_free>
    6cfa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6cfe:	e8 4d e8 ff ff       	call   5550 <fwp_mem_free>
    6d03:	48 89 df             	mov    %rbx,%rdi
    6d06:	5b                   	pop    %rbx
    6d07:	5d                   	pop    %rbp
    6d08:	41 5c                	pop    %r12
    6d0a:	e9 41 e8 ff ff       	jmp    5550 <fwp_mem_free>
    6d0f:	90                   	nop
    6d10:	c3                   	ret
    6d11:	0f 1f 40 00          	nopl   0x0(%rax)
    6d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d1c:	00 00 00 00 

0000000000006d20 <fwp_tape_finish>:
    6d20:	f3 0f 1e fa          	endbr64
    6d24:	41 56                	push   %r14
    6d26:	48 8d 3d 73 c3 01 00 	lea    0x1c373(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6d2d:	41 55                	push   %r13
    6d2f:	41 54                	push   %r12
    6d31:	55                   	push   %rbp
    6d32:	53                   	push   %rbx
    6d33:	e8 38 d2 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6d38:	48 83 3d a8 c3 01 00 	cmpq   $0x0,0x1c3a8(%rip)        # 230e8 <fwp_ntapes>
    6d3f:	00 
    6d40:	48 c7 05 3d c3 01 00 	movq   $0x0,0x1c33d(%rip)        # 23088 <fwp_tape_cached_bytes>
    6d47:	00 00 00 00 
    6d4b:	7e 68                	jle    6db5 <fwp_tape_finish+0x95>
    6d4d:	45 31 e4             	xor    %r12d,%r12d
    6d50:	31 ed                	xor    %ebp,%ebp
    6d52:	0f 1f 00             	nopl   (%rax)
    6d55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6d5c:	00 00 00 00 
    6d60:	48 8b 1d 89 c3 01 00 	mov    0x1c389(%rip),%rbx        # 230f0 <fwp_tapes>
    6d67:	48 83 c5 01          	add    $0x1,%rbp
    6d6b:	4c 01 e3             	add    %r12,%rbx
    6d6e:	49 83 c4 68          	add    $0x68,%r12
    6d72:	48 89 df             	mov    %rbx,%rdi
    6d75:	e8 86 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d7a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6d7e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6d82:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6d86:	e8 35 c6 ff ff       	call   33c0 <free@plt>
    6d8b:	4c 89 f7             	mov    %r14,%rdi
    6d8e:	e8 2d c6 ff ff       	call   33c0 <free@plt>
    6d93:	4c 89 ef             	mov    %r13,%rdi
    6d96:	e8 25 c6 ff ff       	call   33c0 <free@plt>
    6d9b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6d9f:	e8 6c fe ff ff       	call   6c10 <fwp_owned_tape_release>
    6da4:	48 39 2d 3d c3 01 00 	cmp    %rbp,0x1c33d(%rip)        # 230e8 <fwp_ntapes>
    6dab:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6db2:	00 
    6db3:	7f ab                	jg     6d60 <fwp_tape_finish+0x40>
    6db5:	48 8b 3d 34 c3 01 00 	mov    0x1c334(%rip),%rdi        # 230f0 <fwp_tapes>
    6dbc:	e8 ff c5 ff ff       	call   33c0 <free@plt>
    6dc1:	5b                   	pop    %rbx
    6dc2:	5d                   	pop    %rbp
    6dc3:	48 c7 05 22 c3 01 00 	movq   $0x0,0x1c322(%rip)        # 230f0 <fwp_tapes>
    6dca:	00 00 00 00 
    6dce:	48 c7 05 07 c3 01 00 	movq   $0x0,0x1c307(%rip)        # 230e0 <fwp_tapes_cap>
    6dd5:	00 00 00 00 
    6dd9:	41 5c                	pop    %r12
    6ddb:	48 c7 05 02 c3 01 00 	movq   $0x0,0x1c302(%rip)        # 230e8 <fwp_ntapes>
    6de2:	00 00 00 00 
    6de6:	41 5d                	pop    %r13
    6de8:	48 c7 05 e5 c2 01 00 	movq   $0x0,0x1c2e5(%rip)        # 230d8 <fwp_tape_next_slot>
    6def:	00 00 00 00 
    6df3:	41 5e                	pop    %r14
    6df5:	c3                   	ret
    6df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dfd:	00 00 00 

0000000000006e00 <fwp_tape_scope_release>:
    6e00:	f3 0f 1e fa          	endbr64
    6e04:	41 55                	push   %r13
    6e06:	41 54                	push   %r12
    6e08:	55                   	push   %rbp
    6e09:	53                   	push   %rbx
    6e0a:	48 83 ec 58          	sub    $0x58,%rsp
    6e0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e15:	00 00 
    6e17:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6e1c:	48 63 07             	movslq (%rdi),%rax
    6e1f:	85 c0                	test   %eax,%eax
    6e21:	0f 88 05 01 00 00    	js     6f2c <fwp_tape_scope_release+0x12c>
    6e27:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6e2e:	ec c4 4e 
    6e31:	48 89 fb             	mov    %rdi,%rbx
    6e34:	eb 3c                	jmp    6e72 <fwp_tape_scope_release+0x72>
    6e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e3d:	00 00 00 
    6e40:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6e45:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6e49:	e8 72 c5 ff ff       	call   33c0 <free@plt>
    6e4e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6e52:	e8 69 c5 ff ff       	call   33c0 <free@plt>
    6e57:	4c 89 ef             	mov    %r13,%rdi
    6e5a:	e8 61 c5 ff ff       	call   33c0 <free@plt>
    6e5f:	4c 89 e7             	mov    %r12,%rdi
    6e62:	e8 a9 fd ff ff       	call   6c10 <fwp_owned_tape_release>
    6e67:	48 63 03             	movslq (%rbx),%rax
    6e6a:	85 c0                	test   %eax,%eax
    6e6c:	0f 88 ba 00 00 00    	js     6f2c <fwp_tape_scope_release+0x12c>
    6e72:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6e76:	48 8b 35 73 c2 01 00 	mov    0x1c273(%rip),%rsi        # 230f0 <fwp_tapes>
    6e7d:	4c 01 c6             	add    %r8,%rsi
    6e80:	48 89 f7             	mov    %rsi,%rdi
    6e83:	e8 78 cd ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6e88:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6e8d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6e92:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6e99:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6e9d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6ea1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6ea8:	00 
    6ea9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6eae:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6eb2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6eb7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6ebb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6ec0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6ec7:	00 
    6ec8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6ecf:	00 
    6ed0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6ed7:	00 
    6ed8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6edd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6ee2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6ee6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6eea:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6eee:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6ef4:	77 18                	ja     6f0e <fwp_tape_scope_release+0x10e>
    6ef6:	49 c1 f8 03          	sar    $0x3,%r8
    6efa:	4c 0f af c5          	imul   %rbp,%r8
    6efe:	4c 3b 05 d3 c1 01 00 	cmp    0x1c1d3(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    6f05:	7d 07                	jge    6f0e <fwp_tape_scope_release+0x10e>
    6f07:	4c 89 05 ca c1 01 00 	mov    %r8,0x1c1ca(%rip)        # 230d8 <fwp_tape_next_slot>
    6f0e:	4d 85 e4             	test   %r12,%r12
    6f11:	0f 85 29 ff ff ff    	jne    6e40 <fwp_tape_scope_release+0x40>
    6f17:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6f1c:	e8 0f df ff ff       	call   4e30 <fwp_tape_buffers_release>
    6f21:	48 63 03             	movslq (%rbx),%rax
    6f24:	85 c0                	test   %eax,%eax
    6f26:	0f 89 46 ff ff ff    	jns    6e72 <fwp_tape_scope_release+0x72>
    6f2c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6f31:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f38:	00 00 
    6f3a:	75 0b                	jne    6f47 <fwp_tape_scope_release+0x147>
    6f3c:	48 83 c4 58          	add    $0x58,%rsp
    6f40:	5b                   	pop    %rbx
    6f41:	5d                   	pop    %rbp
    6f42:	41 5c                	pop    %r12
    6f44:	41 5d                	pop    %r13
    6f46:	c3                   	ret
    6f47:	e8 14 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006f50 <fwp_drop4>:
    6f50:	48 8b 0d e1 db 01 00 	mov    0x1dbe1(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    6f57:	48 89 f8             	mov    %rdi,%rax
    6f5a:	48 2b 05 af db 01 00 	sub    0x1dbaf(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    6f61:	48 c1 e1 10          	shl    $0x10,%rcx
    6f65:	48 39 c8             	cmp    %rcx,%rax
    6f68:	0f 83 42 01 00 00    	jae    70b0 <fwp_drop4+0x160>
    6f6e:	48 83 ec 18          	sub    $0x18,%rsp
    6f72:	48 89 fa             	mov    %rdi,%rdx
    6f75:	4c 8d 05 e4 c7 01 00 	lea    0x1c7e4(%rip),%r8        # 23760 <fwp_heap>
    6f7c:	48 89 c1             	mov    %rax,%rcx
    6f7f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6f86:	48 c1 e9 10          	shr    $0x10,%rcx
    6f8a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6f8e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6f92:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f96:	48 85 c9             	test   %rcx,%rcx
    6f99:	74 40                	je     6fdb <fwp_drop4+0x8b>
    6f9b:	0f b6 3e             	movzbl (%rsi),%edi
    6f9e:	40 80 ff 02          	cmp    $0x2,%dil
    6fa2:	74 3c                	je     6fe0 <fwp_drop4+0x90>
    6fa4:	40 80 ff 01          	cmp    $0x1,%dil
    6fa8:	75 31                	jne    6fdb <fwp_drop4+0x8b>
    6faa:	8b 7e 18             	mov    0x18(%rsi),%edi
    6fad:	0f b7 c0             	movzwl %ax,%eax
    6fb0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6fb3:	48 0f af c7          	imul   %rdi,%rax
    6fb7:	48 c1 e8 20          	shr    $0x20,%rax
    6fbb:	48 39 f0             	cmp    %rsi,%rax
    6fbe:	73 1b                	jae    6fdb <fwp_drop4+0x8b>
    6fc0:	48 01 c1             	add    %rax,%rcx
    6fc3:	0f b6 01             	movzbl (%rcx),%eax
    6fc6:	84 c0                	test   %al,%al
    6fc8:	74 11                	je     6fdb <fwp_drop4+0x8b>
    6fca:	3c 01                	cmp    $0x1,%al
    6fcc:	74 22                	je     6ff0 <fwp_drop4+0xa0>
    6fce:	3c ff                	cmp    $0xff,%al
    6fd0:	0f 84 0a 01 00 00    	je     70e0 <fwp_drop4+0x190>
    6fd6:	83 e8 01             	sub    $0x1,%eax
    6fd9:	88 01                	mov    %al,(%rcx)
    6fdb:	48 83 c4 18          	add    $0x18,%rsp
    6fdf:	c3                   	ret
    6fe0:	66 85 c0             	test   %ax,%ax
    6fe3:	74 de                	je     6fc3 <fwp_drop4+0x73>
    6fe5:	48 83 c4 18          	add    $0x18,%rsp
    6fe9:	c3                   	ret
    6fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ff0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6ff4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6ffb:	48 89 f8             	mov    %rdi,%rax
    6ffe:	48 c1 e1 10          	shl    $0x10,%rcx
    7002:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7009:	48 39 c8             	cmp    %rcx,%rax
    700c:	73 62                	jae    7070 <fwp_drop4+0x120>
    700e:	48 89 c1             	mov    %rax,%rcx
    7011:	48 c1 e9 10          	shr    $0x10,%rcx
    7015:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7019:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    701d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7021:	48 85 c9             	test   %rcx,%rcx
    7024:	74 4a                	je     7070 <fwp_drop4+0x120>
    7026:	44 0f b6 0e          	movzbl (%rsi),%r9d
    702a:	41 80 f9 02          	cmp    $0x2,%r9b
    702e:	0f 84 9c 00 00 00    	je     70d0 <fwp_drop4+0x180>
    7034:	41 80 f9 01          	cmp    $0x1,%r9b
    7038:	75 36                	jne    7070 <fwp_drop4+0x120>
    703a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    703e:	0f b7 c0             	movzwl %ax,%eax
    7041:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7044:	49 0f af c1          	imul   %r9,%rax
    7048:	48 c1 e8 20          	shr    $0x20,%rax
    704c:	48 39 f0             	cmp    %rsi,%rax
    704f:	73 1f                	jae    7070 <fwp_drop4+0x120>
    7051:	48 01 c1             	add    %rax,%rcx
    7054:	0f b6 01             	movzbl (%rcx),%eax
    7057:	84 c0                	test   %al,%al
    7059:	74 15                	je     7070 <fwp_drop4+0x120>
    705b:	3c 01                	cmp    $0x1,%al
    705d:	74 59                	je     70b8 <fwp_drop4+0x168>
    705f:	3c ff                	cmp    $0xff,%al
    7061:	0f 84 ff 00 00 00    	je     7166 <fwp_drop4+0x216>
    7067:	83 e8 01             	sub    $0x1,%eax
    706a:	88 01                	mov    %al,(%rcx)
    706c:	0f 1f 40 00          	nopl   0x0(%rax)
    7070:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7074:	48 89 d7             	mov    %rdx,%rdi
    7077:	48 89 0c 24          	mov    %rcx,(%rsp)
    707b:	e8 40 f7 ff ff       	call   67c0 <fwp_rc_free_obj>
    7080:	4c 8d 05 d9 c6 01 00 	lea    0x1c6d9(%rip),%r8        # 23760 <fwp_heap>
    7087:	48 8b 04 24          	mov    (%rsp),%rax
    708b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7092:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7099:	48 c1 e2 10          	shl    $0x10,%rdx
    709d:	48 39 d0             	cmp    %rdx,%rax
    70a0:	0f 83 35 ff ff ff    	jae    6fdb <fwp_drop4+0x8b>
    70a6:	48 8b 14 24          	mov    (%rsp),%rdx
    70aa:	e9 cd fe ff ff       	jmp    6f7c <fwp_drop4+0x2c>
    70af:	90                   	nop
    70b0:	c3                   	ret
    70b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70b8:	48 89 14 24          	mov    %rdx,(%rsp)
    70bc:	e8 ff f6 ff ff       	call   67c0 <fwp_rc_free_obj>
    70c1:	48 8b 14 24          	mov    (%rsp),%rdx
    70c5:	eb a9                	jmp    7070 <fwp_drop4+0x120>
    70c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70ce:	00 00 
    70d0:	66 85 c0             	test   %ax,%ax
    70d3:	75 9b                	jne    7070 <fwp_drop4+0x120>
    70d5:	e9 7a ff ff ff       	jmp    7054 <fwp_drop4+0x104>
    70da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70e0:	48 89 c8             	mov    %rcx,%rax
    70e3:	48 c1 e8 11          	shr    $0x11,%rax
    70e7:	48 31 c8             	xor    %rcx,%rax
    70ea:	48 89 c2             	mov    %rax,%rdx
    70ed:	48 c1 ea 09          	shr    $0x9,%rdx
    70f1:	48 31 d0             	xor    %rdx,%rax
    70f4:	0f b6 d0             	movzbl %al,%edx
    70f7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    70fe:	00 
    70ff:	48 85 c0             	test   %rax,%rax
    7102:	75 29                	jne    712d <fwp_drop4+0x1dd>
    7104:	e9 e3 00 00 00       	jmp    71ec <fwp_drop4+0x29c>
    7109:	90                   	nop
    710a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7111:	00 00 00 00 
    7115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    711c:	00 00 00 00 
    7120:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7124:	48 85 c0             	test   %rax,%rax
    7127:	0f 84 bf 00 00 00    	je     71ec <fwp_drop4+0x29c>
    712d:	48 89 c2             	mov    %rax,%rdx
    7130:	48 39 08             	cmp    %rcx,(%rax)
    7133:	75 eb                	jne    7120 <fwp_drop4+0x1d0>
    7135:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7139:	48 83 ea 01          	sub    $0x1,%rdx
    713d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7141:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7148:	0f 85 8d fe ff ff    	jne    6fdb <fwp_drop4+0x8b>
    714e:	48 89 cf             	mov    %rcx,%rdi
    7151:	48 89 0c 24          	mov    %rcx,(%rsp)
    7155:	e8 b6 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    715a:	48 8b 0c 24          	mov    (%rsp),%rcx
    715e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7161:	e9 75 fe ff ff       	jmp    6fdb <fwp_drop4+0x8b>
    7166:	48 89 ce             	mov    %rcx,%rsi
    7169:	48 c1 ee 11          	shr    $0x11,%rsi
    716d:	48 31 ce             	xor    %rcx,%rsi
    7170:	48 89 f0             	mov    %rsi,%rax
    7173:	48 c1 e8 09          	shr    $0x9,%rax
    7177:	48 31 c6             	xor    %rax,%rsi
    717a:	40 0f b6 f6          	movzbl %sil,%esi
    717e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7185:	00 
    7186:	48 85 c0             	test   %rax,%rax
    7189:	75 1e                	jne    71a9 <fwp_drop4+0x259>
    718b:	eb 5f                	jmp    71ec <fwp_drop4+0x29c>
    718d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7194:	00 
    7195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    719c:	00 00 00 00 
    71a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    71a4:	48 85 c0             	test   %rax,%rax
    71a7:	74 43                	je     71ec <fwp_drop4+0x29c>
    71a9:	48 89 c6             	mov    %rax,%rsi
    71ac:	48 39 08             	cmp    %rcx,(%rax)
    71af:	75 ef                	jne    71a0 <fwp_drop4+0x250>
    71b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71b5:	48 83 ee 01          	sub    $0x1,%rsi
    71b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    71bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    71c4:	0f 85 a6 fe ff ff    	jne    7070 <fwp_drop4+0x120>
    71ca:	48 89 cf             	mov    %rcx,%rdi
    71cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    71d6:	e8 35 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    71db:	48 8b 0c 24          	mov    (%rsp),%rcx
    71df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    71e7:	e9 84 fe ff ff       	jmp    7070 <fwp_drop4+0x120>
    71ec:	48 8d 3d ad 85 00 00 	lea    0x85ad(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    71f3:	e8 a8 cf ff ff       	call   41a0 <fwp_trap>
    71f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    71ff:	00 

0000000000007200 <fwp_arg_drop37>:
    7200:	f3 0f 1e fa          	endbr64
    7204:	85 f6                	test   %esi,%esi
    7206:	75 04                	jne    720c <fwp_arg_drop37+0xc>
    7208:	85 d2                	test   %edx,%edx
    720a:	75 04                	jne    7210 <fwp_arg_drop37+0x10>
    720c:	c3                   	ret
    720d:	0f 1f 00             	nopl   (%rax)
    7210:	48 8b 3f             	mov    (%rdi),%rdi
    7213:	e9 38 fd ff ff       	jmp    6f50 <fwp_drop4>
    7218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    721f:	00 

0000000000007220 <fwp_task_dispose>:
    7220:	53                   	push   %rbx
    7221:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7225:	0f 84 1b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    722b:	48 89 fb             	mov    %rdi,%rbx
    722e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7233:	0f 85 0d c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7239:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    723d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7244:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    724b:	00 
    724c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7250:	48 85 ff             	test   %rdi,%rdi
    7253:	74 07                	je     725c <fwp_task_dispose+0x3c>
    7255:	48 85 c0             	test   %rax,%rax
    7258:	74 02                	je     725c <fwp_task_dispose+0x3c>
    725a:	ff d0                	call   *%rax
    725c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7263:	e8 e8 e2 ff ff       	call   5550 <fwp_mem_free>
    7268:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    726f:	00 00 00 00 
    7273:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7277:	74 6f                	je     72e8 <fwp_task_dispose+0xc8>
    7279:	48 8b 15 b8 d8 01 00 	mov    0x1d8b8(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7280:	48 89 d8             	mov    %rbx,%rax
    7283:	48 2b 05 86 d8 01 00 	sub    0x1d886(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    728a:	48 c1 e2 10          	shl    $0x10,%rdx
    728e:	48 39 d0             	cmp    %rdx,%rax
    7291:	73 4c                	jae    72df <fwp_task_dispose+0xbf>
    7293:	48 89 c2             	mov    %rax,%rdx
    7296:	48 c1 ea 10          	shr    $0x10,%rdx
    729a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    729e:	48 8b 15 b3 d8 01 00 	mov    0x1d8b3(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    72a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    72a9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    72ad:	48 85 c9             	test   %rcx,%rcx
    72b0:	74 2d                	je     72df <fwp_task_dispose+0xbf>
    72b2:	0f b6 32             	movzbl (%rdx),%esi
    72b5:	40 80 fe 02          	cmp    $0x2,%sil
    72b9:	74 3d                	je     72f8 <fwp_task_dispose+0xd8>
    72bb:	40 80 fe 01          	cmp    $0x1,%sil
    72bf:	75 1e                	jne    72df <fwp_task_dispose+0xbf>
    72c1:	8b 72 18             	mov    0x18(%rdx),%esi
    72c4:	0f b7 c0             	movzwl %ax,%eax
    72c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    72ca:	48 0f af c6          	imul   %rsi,%rax
    72ce:	48 c1 e8 20          	shr    $0x20,%rax
    72d2:	48 39 d0             	cmp    %rdx,%rax
    72d5:	73 08                	jae    72df <fwp_task_dispose+0xbf>
    72d7:	48 01 c1             	add    %rax,%rcx
    72da:	80 39 01             	cmpb   $0x1,(%rcx)
    72dd:	74 09                	je     72e8 <fwp_task_dispose+0xc8>
    72df:	5b                   	pop    %rbx
    72e0:	c3                   	ret
    72e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72e8:	48 89 df             	mov    %rbx,%rdi
    72eb:	5b                   	pop    %rbx
    72ec:	e9 5f e2 ff ff       	jmp    5550 <fwp_mem_free>
    72f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f8:	66 85 c0             	test   %ax,%ax
    72fb:	74 dd                	je     72da <fwp_task_dispose+0xba>
    72fd:	5b                   	pop    %rbx
    72fe:	c3                   	ret
    72ff:	90                   	nop

0000000000007300 <fwp_free_zombie>:
    7300:	48 8b 15 29 c4 01 00 	mov    0x1c429(%rip),%rdx        # 23730 <fwp_zombie>
    7307:	48 85 d2             	test   %rdx,%rdx
    730a:	0f 84 98 00 00 00    	je     73a8 <fwp_free_zombie+0xa8>
    7310:	48 3b 15 29 c4 01 00 	cmp    0x1c429(%rip),%rdx        # 23740 <fwp_cur>
    7317:	0f 84 8b 00 00 00    	je     73a8 <fwp_free_zombie+0xa8>
    731d:	48 83 ec 18          	sub    $0x18,%rsp
    7321:	48 63 05 e4 bd 01 00 	movslq 0x1bde4(%rip),%rax        # 2310c <fwp_stack_pool_n>
    7328:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    732c:	83 f8 3f             	cmp    $0x3f,%eax
    732f:	7f 7f                	jg     73b0 <fwp_free_zombie+0xb0>
    7331:	8d 48 01             	lea    0x1(%rax),%ecx
    7334:	89 0d d2 bd 01 00    	mov    %ecx,0x1bdd2(%rip)        # 2310c <fwp_stack_pool_n>
    733a:	48 8d 0d df bd 01 00 	lea    0x1bddf(%rip),%rcx        # 23120 <fwp_stack_pool>
    7341:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7345:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    734c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7350:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7357:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    735b:	48 85 c9             	test   %rcx,%rcx
    735e:	0f 84 fc 00 00 00    	je     7460 <fwp_free_zombie+0x160>
    7364:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    736b:	48 85 c0             	test   %rax,%rax
    736e:	74 07                	je     7377 <fwp_free_zombie+0x77>
    7370:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7377:	8b 42 5c             	mov    0x5c(%rdx),%eax
    737a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    737e:	48 c7 05 a7 c3 01 00 	movq   $0x0,0x1c3a7(%rip)        # 23730 <fwp_zombie>
    7385:	00 00 00 00 
    7389:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7390:	85 c0                	test   %eax,%eax
    7392:	74 34                	je     73c8 <fwp_free_zombie+0xc8>
    7394:	83 f8 01             	cmp    $0x1,%eax
    7397:	0f 84 b3 00 00 00    	je     7450 <fwp_free_zombie+0x150>
    739d:	48 83 c4 18          	add    $0x18,%rsp
    73a1:	c3                   	ret
    73a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    73a8:	c3                   	ret
    73a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    73b0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    73b4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73b9:	e8 22 c2 ff ff       	call   35e0 <munmap@plt>
    73be:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73c3:	eb 80                	jmp    7345 <fwp_free_zombie+0x45>
    73c5:	0f 1f 00             	nopl   (%rax)
    73c8:	48 8b 0d 69 d7 01 00 	mov    0x1d769(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    73cf:	48 89 d0             	mov    %rdx,%rax
    73d2:	48 2b 05 37 d7 01 00 	sub    0x1d737(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    73d9:	48 c1 e1 10          	shl    $0x10,%rcx
    73dd:	48 39 c8             	cmp    %rcx,%rax
    73e0:	73 bb                	jae    739d <fwp_free_zombie+0x9d>
    73e2:	48 89 c1             	mov    %rax,%rcx
    73e5:	48 c1 e9 10          	shr    $0x10,%rcx
    73e9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    73ed:	48 8b 0d 64 d7 01 00 	mov    0x1d764(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    73f4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    73f8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    73fc:	48 85 c9             	test   %rcx,%rcx
    73ff:	74 9c                	je     739d <fwp_free_zombie+0x9d>
    7401:	0f b6 3e             	movzbl (%rsi),%edi
    7404:	40 80 ff 02          	cmp    $0x2,%dil
    7408:	74 66                	je     7470 <fwp_free_zombie+0x170>
    740a:	40 80 ff 01          	cmp    $0x1,%dil
    740e:	75 8d                	jne    739d <fwp_free_zombie+0x9d>
    7410:	8b 7e 18             	mov    0x18(%rsi),%edi
    7413:	0f b7 c0             	movzwl %ax,%eax
    7416:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7419:	48 0f af c7          	imul   %rdi,%rax
    741d:	48 c1 e8 20          	shr    $0x20,%rax
    7421:	48 39 f0             	cmp    %rsi,%rax
    7424:	0f 83 73 ff ff ff    	jae    739d <fwp_free_zombie+0x9d>
    742a:	48 01 c1             	add    %rax,%rcx
    742d:	0f b6 01             	movzbl (%rcx),%eax
    7430:	84 c0                	test   %al,%al
    7432:	0f 84 65 ff ff ff    	je     739d <fwp_free_zombie+0x9d>
    7438:	3c 01                	cmp    $0x1,%al
    743a:	74 14                	je     7450 <fwp_free_zombie+0x150>
    743c:	3c ff                	cmp    $0xff,%al
    743e:	74 3b                	je     747b <fwp_free_zombie+0x17b>
    7440:	83 e8 01             	sub    $0x1,%eax
    7443:	88 01                	mov    %al,(%rcx)
    7445:	e9 53 ff ff ff       	jmp    739d <fwp_free_zombie+0x9d>
    744a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7450:	48 89 d7             	mov    %rdx,%rdi
    7453:	48 83 c4 18          	add    $0x18,%rsp
    7457:	e9 c4 fd ff ff       	jmp    7220 <fwp_task_dispose>
    745c:	0f 1f 40 00          	nopl   0x0(%rax)
    7460:	48 89 05 a1 c2 01 00 	mov    %rax,0x1c2a1(%rip)        # 23708 <fwp_tasks_active>
    7467:	e9 ff fe ff ff       	jmp    736b <fwp_free_zombie+0x6b>
    746c:	0f 1f 40 00          	nopl   0x0(%rax)
    7470:	66 85 c0             	test   %ax,%ax
    7473:	0f 85 24 ff ff ff    	jne    739d <fwp_free_zombie+0x9d>
    7479:	eb b2                	jmp    742d <fwp_free_zombie+0x12d>
    747b:	48 89 ca             	mov    %rcx,%rdx
    747e:	48 8d 35 db c2 01 00 	lea    0x1c2db(%rip),%rsi        # 23760 <fwp_heap>
    7485:	48 c1 ea 11          	shr    $0x11,%rdx
    7489:	48 31 ca             	xor    %rcx,%rdx
    748c:	48 89 d0             	mov    %rdx,%rax
    748f:	48 c1 e8 09          	shr    $0x9,%rax
    7493:	48 31 c2             	xor    %rax,%rdx
    7496:	0f b6 d2             	movzbl %dl,%edx
    7499:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    74a0:	00 
    74a1:	48 85 c0             	test   %rax,%rax
    74a4:	75 23                	jne    74c9 <fwp_free_zombie+0x1c9>
    74a6:	eb 5c                	jmp    7504 <fwp_free_zombie+0x204>
    74a8:	66 90                	xchg   %ax,%ax
    74aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74b1:	00 00 00 00 
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 3b                	je     7504 <fwp_free_zombie+0x204>
    74c9:	48 89 c2             	mov    %rax,%rdx
    74cc:	48 39 08             	cmp    %rcx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_free_zombie+0x1c0>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    74d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    74dd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    74e4:	0f 85 b3 fe ff ff    	jne    739d <fwp_free_zombie+0x9d>
    74ea:	48 89 cf             	mov    %rcx,%rdi
    74ed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    74f2:	e8 19 de ff ff       	call   5310 <fwp_rc_forget_slot>
    74f7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    74fc:	c6 01 fe             	movb   $0xfe,(%rcx)
    74ff:	e9 99 fe ff ff       	jmp    739d <fwp_free_zombie+0x9d>
    7504:	48 8d 3d 95 82 00 00 	lea    0x8295(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    750b:	e8 90 cc ff ff       	call   41a0 <fwp_trap>

0000000000007510 <fwp_block>:
    7510:	48 83 ec 08          	sub    $0x8,%rsp
    7514:	48 8b 05 0d c2 01 00 	mov    0x1c20d(%rip),%rax        # 23728 <fwp_ready_head>
    751b:	48 85 c0             	test   %rax,%rax
    751e:	0f 84 1c 01 00 00    	je     7640 <fwp_block+0x130>
    7524:	90                   	nop
    7525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    752c:	00 00 00 00 
    7530:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7537:	48 89 15 ea c1 01 00 	mov    %rdx,0x1c1ea(%rip)        # 23728 <fwp_ready_head>
    753e:	48 85 d2             	test   %rdx,%rdx
    7541:	0f 84 19 01 00 00    	je     7660 <fwp_block+0x150>
    7547:	48 8b 15 f2 c1 01 00 	mov    0x1c1f2(%rip),%rdx        # 23740 <fwp_cur>
    754e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7552:	48 39 c2             	cmp    %rax,%rdx
    7555:	0f 84 d5 00 00 00    	je     7630 <fwp_block+0x120>
    755b:	48 8b 0d 66 de 01 00 	mov    0x1de66(%rip),%rcx        # 253c8 <fwp_state_owners>
    7562:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7566:	48 89 05 d3 c1 01 00 	mov    %rax,0x1c1d3(%rip)        # 23740 <fwp_cur>
    756d:	f3 0f 7e 05 7b de 01 	movq   0x1de7b(%rip),%xmm0        # 253f0 <fwp_foreign_callbacks>
    7574:	00 
    7575:	0f 16 05 64 de 01 00 	movhps 0x1de64(%rip),%xmm0        # 253e0 <fwp_state>
    757c:	f3 0f 7e 0d 64 de 01 	movq   0x1de64(%rip),%xmm1        # 253e8 <fwp_handlers>
    7583:	00 
    7584:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    758b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7592:	0f 16 0d 5f de 01 00 	movhps 0x1de5f(%rip),%xmm1        # 253f8 <fwp_cleanups>
    7599:	f3 0f 7e 05 37 de 01 	movq   0x1de37(%rip),%xmm0        # 253d8 <fwp_state_len>
    75a0:	00 
    75a1:	0f 16 05 28 de 01 00 	movhps 0x1de28(%rip),%xmm0        # 253d0 <fwp_state_cap>
    75a8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    75af:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    75b6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    75ba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    75c1:	48 89 0d 20 de 01 00 	mov    %rcx,0x1de20(%rip)        # 253e8 <fwp_handlers>
    75c8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    75cf:	48 89 0d 22 de 01 00 	mov    %rcx,0x1de22(%rip)        # 253f8 <fwp_cleanups>
    75d6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    75dd:	48 89 0d 0c de 01 00 	mov    %rcx,0x1de0c(%rip)        # 253f0 <fwp_foreign_callbacks>
    75e4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    75eb:	48 89 0d ee dd 01 00 	mov    %rcx,0x1ddee(%rip)        # 253e0 <fwp_state>
    75f2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    75f9:	48 89 0d d8 dd 01 00 	mov    %rcx,0x1ddd8(%rip)        # 253d8 <fwp_state_len>
    7600:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7607:	48 89 0d c2 dd 01 00 	mov    %rcx,0x1ddc2(%rip)        # 253d0 <fwp_state_cap>
    760e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7615:	48 89 0d ac dd 01 00 	mov    %rcx,0x1ddac(%rip)        # 253c8 <fwp_state_owners>
    761c:	e8 6f be ff ff       	call   3490 <swapcontext@plt>
    7621:	f3 0f 1e fa          	endbr64
    7625:	e8 d6 fc ff ff       	call   7300 <fwp_free_zombie>
    762a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7630:	8b 05 d2 ba 01 00    	mov    0x1bad2(%rip),%eax        # 23108 <fwp_slice>
    7636:	85 c0                	test   %eax,%eax
    7638:	74 36                	je     7670 <fwp_block+0x160>
    763a:	48 83 c4 08          	add    $0x8,%rsp
    763e:	c3                   	ret
    763f:	90                   	nop
    7640:	e8 1b d9 ff ff       	call   4f60 <fwp_poll_events>
    7645:	48 8b 05 dc c0 01 00 	mov    0x1c0dc(%rip),%rax        # 23728 <fwp_ready_head>
    764c:	48 85 c0             	test   %rax,%rax
    764f:	0f 85 db fe ff ff    	jne    7530 <fwp_block+0x20>
    7655:	eb e9                	jmp    7640 <fwp_block+0x130>
    7657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    765e:	00 00 
    7660:	48 c7 05 b5 c0 01 00 	movq   $0x0,0x1c0b5(%rip)        # 23720 <fwp_ready_tail>
    7667:	00 00 00 00 
    766b:	e9 d7 fe ff ff       	jmp    7547 <fwp_block+0x37>
    7670:	48 8d 3d aa 7a 00 00 	lea    0x7aaa(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    7677:	e8 24 bd ff ff       	call   33a0 <getenv@plt>
    767c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7681:	48 85 c0             	test   %rax,%rax
    7684:	74 05                	je     768b <fwp_block+0x17b>
    7686:	80 38 00             	cmpb   $0x0,(%rax)
    7689:	75 0b                	jne    7696 <fwp_block+0x186>
    768b:	89 15 77 ba 01 00    	mov    %edx,0x1ba77(%rip)        # 23108 <fwp_slice>
    7691:	48 83 c4 08          	add    $0x8,%rsp
    7695:	c3                   	ret
    7696:	ba 0a 00 00 00       	mov    $0xa,%edx
    769b:	31 f6                	xor    %esi,%esi
    769d:	48 89 c7             	mov    %rax,%rdi
    76a0:	e8 ab be ff ff       	call   3550 <strtoll@plt>
    76a5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    76a9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    76b0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    76b5:	0f 46 d0             	cmovbe %eax,%edx
    76b8:	eb d1                	jmp    768b <fwp_block+0x17b>
    76ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000076c0 <fwp_caps173>:
    76c0:	f3 0f 1e fa          	endbr64
    76c4:	85 f6                	test   %esi,%esi
    76c6:	74 08                	je     76d0 <fwp_caps173+0x10>
    76c8:	c3                   	ret
    76c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76d0:	48 8b 15 61 d4 01 00 	mov    0x1d461(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    76d7:	48 89 f8             	mov    %rdi,%rax
    76da:	48 2b 05 2f d4 01 00 	sub    0x1d42f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    76e1:	48 c1 e2 10          	shl    $0x10,%rdx
    76e5:	48 39 d0             	cmp    %rdx,%rax
    76e8:	73 de                	jae    76c8 <fwp_caps173+0x8>
    76ea:	48 89 c2             	mov    %rax,%rdx
    76ed:	48 c1 ea 10          	shr    $0x10,%rdx
    76f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76f5:	48 8b 15 5c d4 01 00 	mov    0x1d45c(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    76fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7700:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7704:	48 85 c9             	test   %rcx,%rcx
    7707:	74 bf                	je     76c8 <fwp_caps173+0x8>
    7709:	0f b6 32             	movzbl (%rdx),%esi
    770c:	40 80 fe 02          	cmp    $0x2,%sil
    7710:	74 2e                	je     7740 <fwp_caps173+0x80>
    7712:	40 80 fe 01          	cmp    $0x1,%sil
    7716:	75 b0                	jne    76c8 <fwp_caps173+0x8>
    7718:	8b 72 18             	mov    0x18(%rdx),%esi
    771b:	0f b7 c0             	movzwl %ax,%eax
    771e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7721:	48 0f af c6          	imul   %rsi,%rax
    7725:	48 c1 e8 20          	shr    $0x20,%rax
    7729:	48 39 d0             	cmp    %rdx,%rax
    772c:	73 9a                	jae    76c8 <fwp_caps173+0x8>
    772e:	48 01 c1             	add    %rax,%rcx
    7731:	80 39 01             	cmpb   $0x1,(%rcx)
    7734:	75 92                	jne    76c8 <fwp_caps173+0x8>
    7736:	e9 15 de ff ff       	jmp    5550 <fwp_mem_free>
    773b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7740:	66 85 c0             	test   %ax,%ax
    7743:	74 ec                	je     7731 <fwp_caps173+0x71>
    7745:	c3                   	ret
    7746:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    774d:	00 00 00 

0000000000007750 <fwp_args37>:
    7750:	f3 0f 1e fa          	endbr64
    7754:	85 d2                	test   %edx,%edx
    7756:	74 04                	je     775c <fwp_args37+0xc>
    7758:	85 f6                	test   %esi,%esi
    775a:	74 04                	je     7760 <fwp_args37+0x10>
    775c:	c3                   	ret
    775d:	0f 1f 00             	nopl   (%rax)
    7760:	48 8b 15 d1 d3 01 00 	mov    0x1d3d1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7767:	48 8b 07             	mov    (%rdi),%rax
    776a:	48 2b 05 9f d3 01 00 	sub    0x1d39f(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7771:	48 c1 e2 10          	shl    $0x10,%rdx
    7775:	48 39 d0             	cmp    %rdx,%rax
    7778:	73 e2                	jae    775c <fwp_args37+0xc>
    777a:	48 89 c2             	mov    %rax,%rdx
    777d:	48 c1 ea 10          	shr    $0x10,%rdx
    7781:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7785:	48 8b 15 cc d3 01 00 	mov    0x1d3cc(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    778c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7790:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7794:	48 85 ff             	test   %rdi,%rdi
    7797:	74 c3                	je     775c <fwp_args37+0xc>
    7799:	0f b6 0a             	movzbl (%rdx),%ecx
    779c:	80 f9 02             	cmp    $0x2,%cl
    779f:	74 2f                	je     77d0 <fwp_args37+0x80>
    77a1:	80 f9 01             	cmp    $0x1,%cl
    77a4:	75 b6                	jne    775c <fwp_args37+0xc>
    77a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77a9:	0f b7 c0             	movzwl %ax,%eax
    77ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77af:	48 0f af c1          	imul   %rcx,%rax
    77b3:	48 c1 e8 20          	shr    $0x20,%rax
    77b7:	48 39 d0             	cmp    %rdx,%rax
    77ba:	73 a0                	jae    775c <fwp_args37+0xc>
    77bc:	48 01 c7             	add    %rax,%rdi
    77bf:	0f b6 07             	movzbl (%rdi),%eax
    77c2:	84 c0                	test   %al,%al
    77c4:	74 96                	je     775c <fwp_args37+0xc>
    77c6:	3c fd                	cmp    $0xfd,%al
    77c8:	77 0c                	ja     77d6 <fwp_args37+0x86>
    77ca:	83 c0 01             	add    $0x1,%eax
    77cd:	88 07                	mov    %al,(%rdi)
    77cf:	c3                   	ret
    77d0:	66 85 c0             	test   %ax,%ax
    77d3:	74 ea                	je     77bf <fwp_args37+0x6f>
    77d5:	c3                   	ret
    77d6:	e9 15 da ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    77db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000077e0 <fwp_caps37>:
    77e0:	f3 0f 1e fa          	endbr64
    77e4:	48 83 ec 18          	sub    $0x18,%rsp
    77e8:	8b 57 04             	mov    0x4(%rdi),%edx
    77eb:	48 89 f8             	mov    %rdi,%rax
    77ee:	85 d2                	test   %edx,%edx
    77f0:	0f 84 9a 00 00 00    	je     7890 <fwp_caps37+0xb0>
    77f6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    77fa:	85 f6                	test   %esi,%esi
    77fc:	0f 85 9e 00 00 00    	jne    78a0 <fwp_caps37+0xc0>
    7802:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7807:	e8 44 f7 ff ff       	call   6f50 <fwp_drop4>
    780c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7811:	48 8b 0d 20 d3 01 00 	mov    0x1d320(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    7818:	48 89 c2             	mov    %rax,%rdx
    781b:	48 2b 15 ee d2 01 00 	sub    0x1d2ee(%rip),%rdx        # 24b10 <fwp_heap+0x13b0>
    7822:	48 c1 e1 10          	shl    $0x10,%rcx
    7826:	48 39 ca             	cmp    %rcx,%rdx
    7829:	73 6d                	jae    7898 <fwp_caps37+0xb8>
    782b:	48 89 d1             	mov    %rdx,%rcx
    782e:	48 c1 e9 10          	shr    $0x10,%rcx
    7832:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7836:	48 8b 0d 1b d3 01 00 	mov    0x1d31b(%rip),%rcx        # 24b58 <fwp_heap+0x13f8>
    783d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7841:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7845:	48 85 f6             	test   %rsi,%rsi
    7848:	74 4e                	je     7898 <fwp_caps37+0xb8>
    784a:	0f b6 39             	movzbl (%rcx),%edi
    784d:	40 80 ff 02          	cmp    $0x2,%dil
    7851:	0f 84 b9 00 00 00    	je     7910 <fwp_caps37+0x130>
    7857:	40 80 ff 01          	cmp    $0x1,%dil
    785b:	75 3b                	jne    7898 <fwp_caps37+0xb8>
    785d:	8b 79 18             	mov    0x18(%rcx),%edi
    7860:	0f b7 d2             	movzwl %dx,%edx
    7863:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7866:	48 0f af d7          	imul   %rdi,%rdx
    786a:	48 c1 ea 20          	shr    $0x20,%rdx
    786e:	48 39 ca             	cmp    %rcx,%rdx
    7871:	73 25                	jae    7898 <fwp_caps37+0xb8>
    7873:	48 01 d6             	add    %rdx,%rsi
    7876:	80 3e 01             	cmpb   $0x1,(%rsi)
    7879:	75 1d                	jne    7898 <fwp_caps37+0xb8>
    787b:	48 89 c7             	mov    %rax,%rdi
    787e:	48 83 c4 18          	add    $0x18,%rsp
    7882:	e9 c9 dc ff ff       	jmp    5550 <fwp_mem_free>
    7887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    788e:	00 00 
    7890:	85 f6                	test   %esi,%esi
    7892:	0f 84 79 ff ff ff    	je     7811 <fwp_caps37+0x31>
    7898:	48 83 c4 18          	add    $0x18,%rsp
    789c:	c3                   	ret
    789d:	0f 1f 00             	nopl   (%rax)
    78a0:	48 8b 05 91 d2 01 00 	mov    0x1d291(%rip),%rax        # 24b38 <fwp_heap+0x13d8>
    78a7:	48 2b 3d 62 d2 01 00 	sub    0x1d262(%rip),%rdi        # 24b10 <fwp_heap+0x13b0>
    78ae:	48 c1 e0 10          	shl    $0x10,%rax
    78b2:	48 39 c7             	cmp    %rax,%rdi
    78b5:	73 e1                	jae    7898 <fwp_caps37+0xb8>
    78b7:	48 89 f8             	mov    %rdi,%rax
    78ba:	48 c1 e8 10          	shr    $0x10,%rax
    78be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    78c2:	48 8b 05 8f d2 01 00 	mov    0x1d28f(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    78c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    78cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    78d1:	48 85 c0             	test   %rax,%rax
    78d4:	74 c2                	je     7898 <fwp_caps37+0xb8>
    78d6:	0f b6 0a             	movzbl (%rdx),%ecx
    78d9:	80 f9 02             	cmp    $0x2,%cl
    78dc:	74 42                	je     7920 <fwp_caps37+0x140>
    78de:	80 f9 01             	cmp    $0x1,%cl
    78e1:	75 b5                	jne    7898 <fwp_caps37+0xb8>
    78e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78e6:	0f b7 ff             	movzwl %di,%edi
    78e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78ec:	48 0f af f9          	imul   %rcx,%rdi
    78f0:	48 c1 ef 20          	shr    $0x20,%rdi
    78f4:	48 39 d7             	cmp    %rdx,%rdi
    78f7:	73 9f                	jae    7898 <fwp_caps37+0xb8>
    78f9:	48 01 f8             	add    %rdi,%rax
    78fc:	0f b6 10             	movzbl (%rax),%edx
    78ff:	84 d2                	test   %dl,%dl
    7901:	74 95                	je     7898 <fwp_caps37+0xb8>
    7903:	80 fa fd             	cmp    $0xfd,%dl
    7906:	77 23                	ja     792b <fwp_caps37+0x14b>
    7908:	83 c2 01             	add    $0x1,%edx
    790b:	88 10                	mov    %dl,(%rax)
    790d:	eb 89                	jmp    7898 <fwp_caps37+0xb8>
    790f:	90                   	nop
    7910:	66 85 d2             	test   %dx,%dx
    7913:	0f 85 7f ff ff ff    	jne    7898 <fwp_caps37+0xb8>
    7919:	e9 58 ff ff ff       	jmp    7876 <fwp_caps37+0x96>
    791e:	66 90                	xchg   %ax,%ax
    7920:	66 85 ff             	test   %di,%di
    7923:	0f 85 6f ff ff ff    	jne    7898 <fwp_caps37+0xb8>
    7929:	eb d1                	jmp    78fc <fwp_caps37+0x11c>
    792b:	48 89 c7             	mov    %rax,%rdi
    792e:	48 83 c4 18          	add    $0x18,%rsp
    7932:	e9 b9 d8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    793e:	00 00 

0000000000007940 <fwp_drop0>:
    7940:	f3 0f 1e fa          	endbr64
    7944:	48 8b 15 ed d1 01 00 	mov    0x1d1ed(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    794b:	48 89 f8             	mov    %rdi,%rax
    794e:	48 2b 05 bb d1 01 00 	sub    0x1d1bb(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7955:	48 c1 e2 10          	shl    $0x10,%rdx
    7959:	48 39 d0             	cmp    %rdx,%rax
    795c:	0f 83 36 01 00 00    	jae    7a98 <fwp_drop0+0x158>
    7962:	48 83 ec 18          	sub    $0x18,%rsp
    7966:	48 8d 35 f3 bd 01 00 	lea    0x1bdf3(%rip),%rsi        # 23760 <fwp_heap>
    796d:	48 89 c2             	mov    %rax,%rdx
    7970:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7977:	48 c1 ea 10          	shr    $0x10,%rdx
    797b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    797f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7983:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7987:	48 85 d2             	test   %rdx,%rdx
    798a:	74 42                	je     79ce <fwp_drop0+0x8e>
    798c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7990:	41 80 f8 02          	cmp    $0x2,%r8b
    7994:	74 42                	je     79d8 <fwp_drop0+0x98>
    7996:	41 80 f8 01          	cmp    $0x1,%r8b
    799a:	75 32                	jne    79ce <fwp_drop0+0x8e>
    799c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    79a0:	0f b7 c0             	movzwl %ax,%eax
    79a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    79a6:	49 0f af c0          	imul   %r8,%rax
    79aa:	48 c1 e8 20          	shr    $0x20,%rax
    79ae:	48 39 c8             	cmp    %rcx,%rax
    79b1:	73 1b                	jae    79ce <fwp_drop0+0x8e>
    79b3:	48 01 c2             	add    %rax,%rdx
    79b6:	0f b6 02             	movzbl (%rdx),%eax
    79b9:	84 c0                	test   %al,%al
    79bb:	74 11                	je     79ce <fwp_drop0+0x8e>
    79bd:	3c 01                	cmp    $0x1,%al
    79bf:	74 27                	je     79e8 <fwp_drop0+0xa8>
    79c1:	3c ff                	cmp    $0xff,%al
    79c3:	0f 84 e7 00 00 00    	je     7ab0 <fwp_drop0+0x170>
    79c9:	83 e8 01             	sub    $0x1,%eax
    79cc:	88 02                	mov    %al,(%rdx)
    79ce:	48 83 c4 18          	add    $0x18,%rsp
    79d2:	c3                   	ret
    79d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    79d8:	66 85 c0             	test   %ax,%ax
    79db:	74 d9                	je     79b6 <fwp_drop0+0x76>
    79dd:	48 83 c4 18          	add    $0x18,%rsp
    79e1:	c3                   	ret
    79e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79e8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    79ef:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    79f6:	48 89 f8             	mov    %rdi,%rax
    79f9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    79fd:	48 29 c8             	sub    %rcx,%rax
    7a00:	48 c1 e2 10          	shl    $0x10,%rdx
    7a04:	48 39 d0             	cmp    %rdx,%rax
    7a07:	73 71                	jae    7a7a <fwp_drop0+0x13a>
    7a09:	49 89 c2             	mov    %rax,%r10
    7a0c:	49 c1 ea 10          	shr    $0x10,%r10
    7a10:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7a14:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7a18:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7a1c:	4d 85 d2             	test   %r10,%r10
    7a1f:	74 59                	je     7a7a <fwp_drop0+0x13a>
    7a21:	45 0f b6 19          	movzbl (%r9),%r11d
    7a25:	41 80 fb 02          	cmp    $0x2,%r11b
    7a29:	74 75                	je     7aa0 <fwp_drop0+0x160>
    7a2b:	41 80 fb 01          	cmp    $0x1,%r11b
    7a2f:	75 49                	jne    7a7a <fwp_drop0+0x13a>
    7a31:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7a35:	0f b7 c0             	movzwl %ax,%eax
    7a38:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7a3c:	49 0f af c3          	imul   %r11,%rax
    7a40:	48 c1 e8 20          	shr    $0x20,%rax
    7a44:	4c 39 c8             	cmp    %r9,%rax
    7a47:	73 31                	jae    7a7a <fwp_drop0+0x13a>
    7a49:	49 01 c2             	add    %rax,%r10
    7a4c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7a50:	75 28                	jne    7a7a <fwp_drop0+0x13a>
    7a52:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7a57:	e8 f4 da ff ff       	call   5550 <fwp_mem_free>
    7a5c:	48 8d 35 fd bc 01 00 	lea    0x1bcfd(%rip),%rsi        # 23760 <fwp_heap>
    7a63:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7a68:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7a6f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7a76:	48 c1 e2 10          	shl    $0x10,%rdx
    7a7a:	4c 89 c0             	mov    %r8,%rax
    7a7d:	48 29 c8             	sub    %rcx,%rax
    7a80:	48 39 d0             	cmp    %rdx,%rax
    7a83:	0f 83 45 ff ff ff    	jae    79ce <fwp_drop0+0x8e>
    7a89:	4c 89 c7             	mov    %r8,%rdi
    7a8c:	e9 dc fe ff ff       	jmp    796d <fwp_drop0+0x2d>
    7a91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a98:	c3                   	ret
    7a99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7aa0:	66 85 c0             	test   %ax,%ax
    7aa3:	75 d5                	jne    7a7a <fwp_drop0+0x13a>
    7aa5:	eb a5                	jmp    7a4c <fwp_drop0+0x10c>
    7aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7aae:	00 00 
    7ab0:	48 89 d0             	mov    %rdx,%rax
    7ab3:	48 c1 e8 11          	shr    $0x11,%rax
    7ab7:	48 31 d0             	xor    %rdx,%rax
    7aba:	48 89 c1             	mov    %rax,%rcx
    7abd:	48 c1 e9 09          	shr    $0x9,%rcx
    7ac1:	48 31 c8             	xor    %rcx,%rax
    7ac4:	0f b6 c8             	movzbl %al,%ecx
    7ac7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7ace:	00 
    7acf:	48 85 c0             	test   %rax,%rax
    7ad2:	75 15                	jne    7ae9 <fwp_drop0+0x1a9>
    7ad4:	eb 4e                	jmp    7b24 <fwp_drop0+0x1e4>
    7ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7add:	00 00 00 
    7ae0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ae4:	48 85 c0             	test   %rax,%rax
    7ae7:	74 3b                	je     7b24 <fwp_drop0+0x1e4>
    7ae9:	48 89 c1             	mov    %rax,%rcx
    7aec:	48 39 10             	cmp    %rdx,(%rax)
    7aef:	75 ef                	jne    7ae0 <fwp_drop0+0x1a0>
    7af1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7af5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7af9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7afd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7b04:	0f 85 c4 fe ff ff    	jne    79ce <fwp_drop0+0x8e>
    7b0a:	48 89 d7             	mov    %rdx,%rdi
    7b0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b12:	e8 f9 d7 ff ff       	call   5310 <fwp_rc_forget_slot>
    7b17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7b1f:	e9 aa fe ff ff       	jmp    79ce <fwp_drop0+0x8e>
    7b24:	48 8d 3d 75 7c 00 00 	lea    0x7c75(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7b2b:	e8 70 c6 ff ff       	call   41a0 <fwp_trap>

0000000000007b30 <fwp_drop1>:
    7b30:	f3 0f 1e fa          	endbr64
    7b34:	48 8b 15 fd cf 01 00 	mov    0x1cffd(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7b3b:	48 89 f8             	mov    %rdi,%rax
    7b3e:	48 2b 05 cb cf 01 00 	sub    0x1cfcb(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7b45:	48 c1 e2 10          	shl    $0x10,%rdx
    7b49:	48 39 d0             	cmp    %rdx,%rax
    7b4c:	0f 83 36 01 00 00    	jae    7c88 <fwp_drop1+0x158>
    7b52:	48 83 ec 18          	sub    $0x18,%rsp
    7b56:	48 8d 35 03 bc 01 00 	lea    0x1bc03(%rip),%rsi        # 23760 <fwp_heap>
    7b5d:	48 89 c2             	mov    %rax,%rdx
    7b60:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7b67:	48 c1 ea 10          	shr    $0x10,%rdx
    7b6b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b6f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7b73:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b77:	48 85 d2             	test   %rdx,%rdx
    7b7a:	74 42                	je     7bbe <fwp_drop1+0x8e>
    7b7c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7b80:	41 80 f8 02          	cmp    $0x2,%r8b
    7b84:	74 42                	je     7bc8 <fwp_drop1+0x98>
    7b86:	41 80 f8 01          	cmp    $0x1,%r8b
    7b8a:	75 32                	jne    7bbe <fwp_drop1+0x8e>
    7b8c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7b90:	0f b7 c0             	movzwl %ax,%eax
    7b93:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7b96:	49 0f af c0          	imul   %r8,%rax
    7b9a:	48 c1 e8 20          	shr    $0x20,%rax
    7b9e:	48 39 c8             	cmp    %rcx,%rax
    7ba1:	73 1b                	jae    7bbe <fwp_drop1+0x8e>
    7ba3:	48 01 c2             	add    %rax,%rdx
    7ba6:	0f b6 02             	movzbl (%rdx),%eax
    7ba9:	84 c0                	test   %al,%al
    7bab:	74 11                	je     7bbe <fwp_drop1+0x8e>
    7bad:	3c 01                	cmp    $0x1,%al
    7baf:	74 27                	je     7bd8 <fwp_drop1+0xa8>
    7bb1:	3c ff                	cmp    $0xff,%al
    7bb3:	0f 84 e7 00 00 00    	je     7ca0 <fwp_drop1+0x170>
    7bb9:	83 e8 01             	sub    $0x1,%eax
    7bbc:	88 02                	mov    %al,(%rdx)
    7bbe:	48 83 c4 18          	add    $0x18,%rsp
    7bc2:	c3                   	ret
    7bc3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7bc8:	66 85 c0             	test   %ax,%ax
    7bcb:	74 d9                	je     7ba6 <fwp_drop1+0x76>
    7bcd:	48 83 c4 18          	add    $0x18,%rsp
    7bd1:	c3                   	ret
    7bd2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bd8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7bdf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7be6:	48 89 f8             	mov    %rdi,%rax
    7be9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7bed:	48 29 c8             	sub    %rcx,%rax
    7bf0:	48 c1 e2 10          	shl    $0x10,%rdx
    7bf4:	48 39 d0             	cmp    %rdx,%rax
    7bf7:	73 71                	jae    7c6a <fwp_drop1+0x13a>
    7bf9:	49 89 c2             	mov    %rax,%r10
    7bfc:	49 c1 ea 10          	shr    $0x10,%r10
    7c00:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c04:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7c08:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7c0c:	4d 85 d2             	test   %r10,%r10
    7c0f:	74 59                	je     7c6a <fwp_drop1+0x13a>
    7c11:	45 0f b6 19          	movzbl (%r9),%r11d
    7c15:	41 80 fb 02          	cmp    $0x2,%r11b
    7c19:	74 75                	je     7c90 <fwp_drop1+0x160>
    7c1b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c1f:	75 49                	jne    7c6a <fwp_drop1+0x13a>
    7c21:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c25:	0f b7 c0             	movzwl %ax,%eax
    7c28:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c2c:	49 0f af c3          	imul   %r11,%rax
    7c30:	48 c1 e8 20          	shr    $0x20,%rax
    7c34:	4c 39 c8             	cmp    %r9,%rax
    7c37:	73 31                	jae    7c6a <fwp_drop1+0x13a>
    7c39:	49 01 c2             	add    %rax,%r10
    7c3c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c40:	75 28                	jne    7c6a <fwp_drop1+0x13a>
    7c42:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7c47:	e8 04 d9 ff ff       	call   5550 <fwp_mem_free>
    7c4c:	48 8d 35 0d bb 01 00 	lea    0x1bb0d(%rip),%rsi        # 23760 <fwp_heap>
    7c53:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7c58:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c5f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c66:	48 c1 e2 10          	shl    $0x10,%rdx
    7c6a:	4c 89 c0             	mov    %r8,%rax
    7c6d:	48 29 c8             	sub    %rcx,%rax
    7c70:	48 39 d0             	cmp    %rdx,%rax
    7c73:	0f 83 45 ff ff ff    	jae    7bbe <fwp_drop1+0x8e>
    7c79:	4c 89 c7             	mov    %r8,%rdi
    7c7c:	e9 dc fe ff ff       	jmp    7b5d <fwp_drop1+0x2d>
    7c81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c88:	c3                   	ret
    7c89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c90:	66 85 c0             	test   %ax,%ax
    7c93:	75 d5                	jne    7c6a <fwp_drop1+0x13a>
    7c95:	eb a5                	jmp    7c3c <fwp_drop1+0x10c>
    7c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c9e:	00 00 
    7ca0:	48 89 d0             	mov    %rdx,%rax
    7ca3:	48 c1 e8 11          	shr    $0x11,%rax
    7ca7:	48 31 d0             	xor    %rdx,%rax
    7caa:	48 89 c1             	mov    %rax,%rcx
    7cad:	48 c1 e9 09          	shr    $0x9,%rcx
    7cb1:	48 31 c8             	xor    %rcx,%rax
    7cb4:	0f b6 c8             	movzbl %al,%ecx
    7cb7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7cbe:	00 
    7cbf:	48 85 c0             	test   %rax,%rax
    7cc2:	75 25                	jne    7ce9 <fwp_drop1+0x1b9>
    7cc4:	eb 5e                	jmp    7d24 <fwp_drop1+0x1f4>
    7cc6:	0f 1f 40 00          	nopl   0x0(%rax)
    7cca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cd1:	00 00 00 00 
    7cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7cdc:	00 00 00 00 
    7ce0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ce4:	48 85 c0             	test   %rax,%rax
    7ce7:	74 3b                	je     7d24 <fwp_drop1+0x1f4>
    7ce9:	48 89 c1             	mov    %rax,%rcx
    7cec:	48 39 10             	cmp    %rdx,(%rax)
    7cef:	75 ef                	jne    7ce0 <fwp_drop1+0x1b0>
    7cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7cf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7cfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d04:	0f 85 b4 fe ff ff    	jne    7bbe <fwp_drop1+0x8e>
    7d0a:	48 89 d7             	mov    %rdx,%rdi
    7d0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d12:	e8 f9 d5 ff ff       	call   5310 <fwp_rc_forget_slot>
    7d17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d1f:	e9 9a fe ff ff       	jmp    7bbe <fwp_drop1+0x8e>
    7d24:	48 8d 3d 75 7a 00 00 	lea    0x7a75(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7d2b:	e8 70 c4 ff ff       	call   41a0 <fwp_trap>

0000000000007d30 <fwp_drop10>:
    7d30:	48 8b 0d 01 ce 01 00 	mov    0x1ce01(%rip),%rcx        # 24b38 <fwp_heap+0x13d8>
    7d37:	48 89 f8             	mov    %rdi,%rax
    7d3a:	48 2b 05 cf cd 01 00 	sub    0x1cdcf(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    7d41:	48 c1 e1 10          	shl    $0x10,%rcx
    7d45:	48 39 c8             	cmp    %rcx,%rax
    7d48:	0f 83 c2 01 00 00    	jae    7f10 <fwp_drop10+0x1e0>
    7d4e:	48 83 ec 18          	sub    $0x18,%rsp
    7d52:	48 89 fa             	mov    %rdi,%rdx
    7d55:	48 8d 35 04 ba 01 00 	lea    0x1ba04(%rip),%rsi        # 23760 <fwp_heap>
    7d5c:	48 89 c1             	mov    %rax,%rcx
    7d5f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7d66:	48 c1 e9 10          	shr    $0x10,%rcx
    7d6a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7d6e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7d72:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7d76:	48 85 c9             	test   %rcx,%rcx
    7d79:	74 46                	je     7dc1 <fwp_drop10+0x91>
    7d7b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7d7f:	41 80 f9 02          	cmp    $0x2,%r9b
    7d83:	0f 84 d7 00 00 00    	je     7e60 <fwp_drop10+0x130>
    7d89:	41 80 f9 01          	cmp    $0x1,%r9b
    7d8d:	75 32                	jne    7dc1 <fwp_drop10+0x91>
    7d8f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7d93:	0f b7 c0             	movzwl %ax,%eax
    7d96:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7d99:	49 0f af c1          	imul   %r9,%rax
    7d9d:	48 c1 e8 20          	shr    $0x20,%rax
    7da1:	48 39 f8             	cmp    %rdi,%rax
    7da4:	73 1b                	jae    7dc1 <fwp_drop10+0x91>
    7da6:	48 01 c1             	add    %rax,%rcx
    7da9:	0f b6 01             	movzbl (%rcx),%eax
    7dac:	84 c0                	test   %al,%al
    7dae:	74 11                	je     7dc1 <fwp_drop10+0x91>
    7db0:	3c 01                	cmp    $0x1,%al
    7db2:	74 1c                	je     7dd0 <fwp_drop10+0xa0>
    7db4:	3c ff                	cmp    $0xff,%al
    7db6:	0f 84 5c 01 00 00    	je     7f18 <fwp_drop10+0x1e8>
    7dbc:	83 e8 01             	sub    $0x1,%eax
    7dbf:	88 01                	mov    %al,(%rcx)
    7dc1:	48 83 c4 18          	add    $0x18,%rsp
    7dc5:	c3                   	ret
    7dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7dcd:	00 00 00 
    7dd0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7dd7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7dde:	48 89 d0             	mov    %rdx,%rax
    7de1:	49 89 d1             	mov    %rdx,%r9
    7de4:	48 c1 e1 10          	shl    $0x10,%rcx
    7de8:	48 29 f8             	sub    %rdi,%rax
    7deb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7def:	78 7f                	js     7e70 <fwp_drop10+0x140>
    7df1:	48 39 c8             	cmp    %rcx,%rax
    7df4:	73 cb                	jae    7dc1 <fwp_drop10+0x91>
    7df6:	48 89 c1             	mov    %rax,%rcx
    7df9:	48 c1 e9 10          	shr    $0x10,%rcx
    7dfd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e01:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7e05:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e09:	48 85 f6             	test   %rsi,%rsi
    7e0c:	74 b3                	je     7dc1 <fwp_drop10+0x91>
    7e0e:	0f b6 39             	movzbl (%rcx),%edi
    7e11:	40 80 ff 02          	cmp    $0x2,%dil
    7e15:	74 39                	je     7e50 <fwp_drop10+0x120>
    7e17:	40 80 ff 01          	cmp    $0x1,%dil
    7e1b:	75 a4                	jne    7dc1 <fwp_drop10+0x91>
    7e1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7e20:	0f b7 c0             	movzwl %ax,%eax
    7e23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e26:	48 0f af c7          	imul   %rdi,%rax
    7e2a:	48 c1 e8 20          	shr    $0x20,%rax
    7e2e:	48 39 c8             	cmp    %rcx,%rax
    7e31:	73 8e                	jae    7dc1 <fwp_drop10+0x91>
    7e33:	48 01 c6             	add    %rax,%rsi
    7e36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7e39:	75 86                	jne    7dc1 <fwp_drop10+0x91>
    7e3b:	48 89 d7             	mov    %rdx,%rdi
    7e3e:	48 83 c4 18          	add    $0x18,%rsp
    7e42:	e9 09 d7 ff ff       	jmp    5550 <fwp_mem_free>
    7e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e4e:	00 00 
    7e50:	66 85 c0             	test   %ax,%ax
    7e53:	74 e1                	je     7e36 <fwp_drop10+0x106>
    7e55:	48 83 c4 18          	add    $0x18,%rsp
    7e59:	c3                   	ret
    7e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e60:	66 85 c0             	test   %ax,%ax
    7e63:	0f 84 40 ff ff ff    	je     7da9 <fwp_drop10+0x79>
    7e69:	48 83 c4 18          	add    $0x18,%rsp
    7e6d:	c3                   	ret
    7e6e:	66 90                	xchg   %ax,%ax
    7e70:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7e74:	48 39 c8             	cmp    %rcx,%rax
    7e77:	73 74                	jae    7eed <fwp_drop10+0x1bd>
    7e79:	49 89 c2             	mov    %rax,%r10
    7e7c:	49 c1 ea 10          	shr    $0x10,%r10
    7e80:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e84:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7e88:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7e8c:	4d 85 d2             	test   %r10,%r10
    7e8f:	74 5c                	je     7eed <fwp_drop10+0x1bd>
    7e91:	45 0f b6 18          	movzbl (%r8),%r11d
    7e95:	41 80 fb 02          	cmp    $0x2,%r11b
    7e99:	74 6d                	je     7f08 <fwp_drop10+0x1d8>
    7e9b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e9f:	75 4c                	jne    7eed <fwp_drop10+0x1bd>
    7ea1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7ea5:	0f b7 c0             	movzwl %ax,%eax
    7ea8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7eac:	49 0f af c3          	imul   %r11,%rax
    7eb0:	48 c1 e8 20          	shr    $0x20,%rax
    7eb4:	4c 39 c0             	cmp    %r8,%rax
    7eb7:	73 34                	jae    7eed <fwp_drop10+0x1bd>
    7eb9:	49 01 c2             	add    %rax,%r10
    7ebc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7ec0:	75 2b                	jne    7eed <fwp_drop10+0x1bd>
    7ec2:	4c 89 cf             	mov    %r9,%rdi
    7ec5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7eca:	e8 81 d6 ff ff       	call   5550 <fwp_mem_free>
    7ecf:	48 8d 35 8a b8 01 00 	lea    0x1b88a(%rip),%rsi        # 23760 <fwp_heap>
    7ed6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7edb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7ee2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7ee9:	48 c1 e1 10          	shl    $0x10,%rcx
    7eed:	48 89 d0             	mov    %rdx,%rax
    7ef0:	48 29 f8             	sub    %rdi,%rax
    7ef3:	48 39 c8             	cmp    %rcx,%rax
    7ef6:	0f 82 60 fe ff ff    	jb     7d5c <fwp_drop10+0x2c>
    7efc:	e9 c0 fe ff ff       	jmp    7dc1 <fwp_drop10+0x91>
    7f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f08:	66 85 c0             	test   %ax,%ax
    7f0b:	75 e0                	jne    7eed <fwp_drop10+0x1bd>
    7f0d:	eb ad                	jmp    7ebc <fwp_drop10+0x18c>
    7f0f:	90                   	nop
    7f10:	c3                   	ret
    7f11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f18:	48 89 c8             	mov    %rcx,%rax
    7f1b:	48 c1 e8 11          	shr    $0x11,%rax
    7f1f:	48 31 c8             	xor    %rcx,%rax
    7f22:	48 89 c2             	mov    %rax,%rdx
    7f25:	48 c1 ea 09          	shr    $0x9,%rdx
    7f29:	48 31 d0             	xor    %rdx,%rax
    7f2c:	0f b6 d0             	movzbl %al,%edx
    7f2f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7f36:	00 
    7f37:	48 85 c0             	test   %rax,%rax
    7f3a:	75 0d                	jne    7f49 <fwp_drop10+0x219>
    7f3c:	eb 46                	jmp    7f84 <fwp_drop10+0x254>
    7f3e:	66 90                	xchg   %ax,%ax
    7f40:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7f44:	48 85 c0             	test   %rax,%rax
    7f47:	74 3b                	je     7f84 <fwp_drop10+0x254>
    7f49:	48 89 c2             	mov    %rax,%rdx
    7f4c:	48 39 08             	cmp    %rcx,(%rax)
    7f4f:	75 ef                	jne    7f40 <fwp_drop10+0x210>
    7f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f55:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7f59:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7f5d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7f64:	0f 85 57 fe ff ff    	jne    7dc1 <fwp_drop10+0x91>
    7f6a:	48 89 cf             	mov    %rcx,%rdi
    7f6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7f72:	e8 99 d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7f77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7f7c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7f7f:	e9 3d fe ff ff       	jmp    7dc1 <fwp_drop10+0x91>
    7f84:	48 8d 3d 15 78 00 00 	lea    0x7815(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    7f8b:	e8 10 c2 ff ff       	call   41a0 <fwp_trap>

0000000000007f90 <f37>:
    7f90:	41 57                	push   %r15
    7f92:	41 56                	push   %r14
    7f94:	41 55                	push   %r13
    7f96:	41 54                	push   %r12
    7f98:	55                   	push   %rbp
    7f99:	53                   	push   %rbx
    7f9a:	48 83 ec 38          	sub    $0x38,%rsp
    7f9e:	48 8b 15 93 cb 01 00 	mov    0x1cb93(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    7fa5:	48 8b 0d 64 cb 01 00 	mov    0x1cb64(%rip),%rcx        # 24b10 <fwp_heap+0x13b0>
    7fac:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    7fb3:	00 00 
    7fb5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    7fba:	49 89 fd             	mov    %rdi,%r13
    7fbd:	48 c1 e2 10          	shl    $0x10,%rdx
    7fc1:	48 85 ff             	test   %rdi,%rdi
    7fc4:	0f 84 fc 02 00 00    	je     82c6 <f37+0x336>
    7fca:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    7fce:	48 89 d8             	mov    %rbx,%rax
    7fd1:	48 29 c8             	sub    %rcx,%rax
    7fd4:	48 39 d0             	cmp    %rdx,%rax
    7fd7:	0f 83 b3 03 00 00    	jae    8390 <f37+0x400>
    7fdd:	48 89 c2             	mov    %rax,%rdx
    7fe0:	48 c1 ea 10          	shr    $0x10,%rdx
    7fe4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fe8:	48 8b 15 69 cb 01 00 	mov    0x1cb69(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    7fef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ff3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ff7:	48 85 ff             	test   %rdi,%rdi
    7ffa:	0f 84 90 03 00 00    	je     8390 <f37+0x400>
    8000:	0f b6 0a             	movzbl (%rdx),%ecx
    8003:	80 f9 02             	cmp    $0x2,%cl
    8006:	0f 84 94 02 00 00    	je     82a0 <f37+0x310>
    800c:	80 f9 01             	cmp    $0x1,%cl
    800f:	75 24                	jne    8035 <f37+0xa5>
    8011:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8014:	0f b7 c0             	movzwl %ax,%eax
    8017:	8b 52 1c             	mov    0x1c(%rdx),%edx
    801a:	48 0f af c1          	imul   %rcx,%rax
    801e:	48 c1 e8 20          	shr    $0x20,%rax
    8022:	48 39 d0             	cmp    %rdx,%rax
    8025:	73 0e                	jae    8035 <f37+0xa5>
    8027:	48 01 c7             	add    %rax,%rdi
    802a:	0f b6 07             	movzbl (%rdi),%eax
    802d:	84 c0                	test   %al,%al
    802f:	0f 85 0b 03 00 00    	jne    8340 <f37+0x3b0>
    8035:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    803a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    803e:	ba 01 00 00 00       	mov    $0x1,%edx
    8043:	48 85 db             	test   %rbx,%rbx
    8046:	74 15                	je     805d <f37+0xcd>
    8048:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    804f:	00 
    8050:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8054:	48 83 c2 01          	add    $0x1,%rdx
    8058:	48 85 db             	test   %rbx,%rbx
    805b:	75 f3                	jne    8050 <f37+0xc0>
    805d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8062:	48 85 c0             	test   %rax,%rax
    8065:	0f 84 55 03 00 00    	je     83c0 <f37+0x430>
    806b:	31 db                	xor    %ebx,%ebx
    806d:	0f 1f 00             	nopl   (%rax)
    8070:	48 8b 40 10          	mov    0x10(%rax),%rax
    8074:	48 83 c3 01          	add    $0x1,%rbx
    8078:	48 85 c0             	test   %rax,%rax
    807b:	75 f3                	jne    8070 <f37+0xe0>
    807d:	48 39 d3             	cmp    %rdx,%rbx
    8080:	48 0f 47 da          	cmova  %rdx,%rbx
    8084:	48 89 d8             	mov    %rbx,%rax
    8087:	48 c1 e8 3c          	shr    $0x3c,%rax
    808b:	0f 85 d3 03 00 00    	jne    8464 <f37+0x4d4>
    8091:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8095:	be 02 00 00 00       	mov    $0x2,%esi
    809a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    80a1:	00 
    80a2:	e8 a9 d9 ff ff       	call   5a50 <fwp_heap_alloc>
    80a7:	48 89 28             	mov    %rbp,(%rax)
    80aa:	48 8b 15 87 ca 01 00 	mov    0x1ca87(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    80b1:	49 89 c4             	mov    %rax,%r12
    80b4:	48 2b 05 55 ca 01 00 	sub    0x1ca55(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    80bb:	48 c1 e2 10          	shl    $0x10,%rdx
    80bf:	48 39 d0             	cmp    %rdx,%rax
    80c2:	73 57                	jae    811b <f37+0x18b>
    80c4:	48 89 c2             	mov    %rax,%rdx
    80c7:	48 c1 ea 10          	shr    $0x10,%rdx
    80cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80cf:	48 8b 15 82 ca 01 00 	mov    0x1ca82(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    80d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80da:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    80de:	48 85 ed             	test   %rbp,%rbp
    80e1:	74 38                	je     811b <f37+0x18b>
    80e3:	0f b6 0a             	movzbl (%rdx),%ecx
    80e6:	80 f9 02             	cmp    $0x2,%cl
    80e9:	0f 84 91 02 00 00    	je     8380 <f37+0x3f0>
    80ef:	80 f9 01             	cmp    $0x1,%cl
    80f2:	75 27                	jne    811b <f37+0x18b>
    80f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80f7:	0f b7 c0             	movzwl %ax,%eax
    80fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80fd:	48 0f af c1          	imul   %rcx,%rax
    8101:	48 c1 e8 20          	shr    $0x20,%rax
    8105:	48 39 d0             	cmp    %rdx,%rax
    8108:	73 11                	jae    811b <f37+0x18b>
    810a:	48 01 c5             	add    %rax,%rbp
    810d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8111:	0f 84 19 03 00 00    	je     8430 <f37+0x4a0>
    8117:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    811b:	48 85 db             	test   %rbx,%rbx
    811e:	74 5d                	je     817d <f37+0x1ed>
    8120:	48 c1 e3 04          	shl    $0x4,%rbx
    8124:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8129:	4c 89 e5             	mov    %r12,%rbp
    812c:	4d 89 ee             	mov    %r13,%r14
    812f:	4c 01 e3             	add    %r12,%rbx
    8132:	0f 1f 00             	nopl   (%rax)
    8135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    813c:	00 00 00 00 
    8140:	49 8b 46 08          	mov    0x8(%r14),%rax
    8144:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8148:	48 83 c5 10          	add    $0x10,%rbp
    814c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8151:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8155:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8159:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    815e:	e8 2d df ff ff       	call   6090 <w120>
    8163:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8168:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    816c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8170:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8174:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8178:	48 39 eb             	cmp    %rbp,%rbx
    817b:	75 c3                	jne    8140 <f37+0x1b0>
    817d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8182:	31 db                	xor    %ebx,%ebx
    8184:	e8 c7 ed ff ff       	call   6f50 <fwp_drop4>
    8189:	4c 89 ef             	mov    %r13,%rdi
    818c:	e8 bf ed ff ff       	call   6f50 <fwp_drop4>
    8191:	4d 8b 2c 24          	mov    (%r12),%r13
    8195:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8199:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    81a0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    81a7:	4d 85 ed             	test   %r13,%r13
    81aa:	74 32                	je     81de <f37+0x24e>
    81ac:	0f 1f 40 00          	nopl   0x0(%rax)
    81b0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    81b7:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    81bc:	48 83 c3 02          	add    $0x2,%rbx
    81c0:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    81c6:	e8 45 dd ff ff       	call   5f10 <f141.constprop.0>
    81cb:	4c 39 eb             	cmp    %r13,%rbx
    81ce:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    81d4:	48 89 c7             	mov    %rax,%rdi
    81d7:	72 d7                	jb     81b0 <f37+0x220>
    81d9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    81de:	4c 89 e7             	mov    %r12,%rdi
    81e1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    81e6:	e8 45 fb ff ff       	call   7d30 <fwp_drop10>
    81eb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    81f0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    81f5:	31 ff                	xor    %edi,%edi
    81f7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    81fc:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8201:	e8 6a d9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    8206:	48 8b 15 2b c9 01 00 	mov    0x1c92b(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    820d:	48 89 c5             	mov    %rax,%rbp
    8210:	48 2b 05 f9 c8 01 00 	sub    0x1c8f9(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    8217:	48 c1 e2 10          	shl    $0x10,%rdx
    821b:	48 39 d0             	cmp    %rdx,%rax
    821e:	73 55                	jae    8275 <f37+0x2e5>
    8220:	48 89 c2             	mov    %rax,%rdx
    8223:	48 c1 ea 10          	shr    $0x10,%rdx
    8227:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    822b:	48 8b 15 26 c9 01 00 	mov    0x1c926(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    8232:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8236:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    823a:	48 85 db             	test   %rbx,%rbx
    823d:	74 36                	je     8275 <f37+0x2e5>
    823f:	0f b6 0a             	movzbl (%rdx),%ecx
    8242:	80 f9 02             	cmp    $0x2,%cl
    8245:	0f 84 1d 01 00 00    	je     8368 <f37+0x3d8>
    824b:	80 f9 01             	cmp    $0x1,%cl
    824e:	75 25                	jne    8275 <f37+0x2e5>
    8250:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8253:	0f b7 c0             	movzwl %ax,%eax
    8256:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8259:	48 0f af c1          	imul   %rcx,%rax
    825d:	48 c1 e8 20          	shr    $0x20,%rax
    8261:	48 39 d0             	cmp    %rdx,%rax
    8264:	73 0f                	jae    8275 <f37+0x2e5>
    8266:	48 01 c3             	add    %rax,%rbx
    8269:	80 3b ff             	cmpb   $0xff,(%rbx)
    826c:	0f 84 b1 01 00 00    	je     8423 <f37+0x493>
    8272:	c6 03 01             	movb   $0x1,(%rbx)
    8275:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    827a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8281:	00 00 
    8283:	0f 85 d6 01 00 00    	jne    845f <f37+0x4cf>
    8289:	48 83 c4 38          	add    $0x38,%rsp
    828d:	48 89 e8             	mov    %rbp,%rax
    8290:	5b                   	pop    %rbx
    8291:	5d                   	pop    %rbp
    8292:	41 5c                	pop    %r12
    8294:	41 5d                	pop    %r13
    8296:	41 5e                	pop    %r14
    8298:	41 5f                	pop    %r15
    829a:	c3                   	ret
    829b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82a0:	66 85 c0             	test   %ax,%ax
    82a3:	0f 85 8c fd ff ff    	jne    8035 <f37+0xa5>
    82a9:	0f b6 07             	movzbl (%rdi),%eax
    82ac:	84 c0                	test   %al,%al
    82ae:	0f 84 81 fd ff ff    	je     8035 <f37+0xa5>
    82b4:	3c fd                	cmp    $0xfd,%al
    82b6:	0f 87 99 01 00 00    	ja     8455 <f37+0x4c5>
    82bc:	83 c0 01             	add    $0x1,%eax
    82bf:	88 07                	mov    %al,(%rdi)
    82c1:	e9 6f fd ff ff       	jmp    8035 <f37+0xa5>
    82c6:	48 f7 d9             	neg    %rcx
    82c9:	48 39 d1             	cmp    %rdx,%rcx
    82cc:	0f 83 ee 00 00 00    	jae    83c0 <f37+0x430>
    82d2:	48 89 c8             	mov    %rcx,%rax
    82d5:	48 c1 e8 10          	shr    $0x10,%rax
    82d9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    82dd:	48 8b 05 74 c8 01 00 	mov    0x1c874(%rip),%rax        # 24b58 <fwp_heap+0x13f8>
    82e4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    82e8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    82ec:	48 85 ff             	test   %rdi,%rdi
    82ef:	0f 84 cb 00 00 00    	je     83c0 <f37+0x430>
    82f5:	0f b6 02             	movzbl (%rdx),%eax
    82f8:	3c 02                	cmp    $0x2,%al
    82fa:	0f 84 9a 00 00 00    	je     839a <f37+0x40a>
    8300:	3c 01                	cmp    $0x1,%al
    8302:	0f 85 b8 00 00 00    	jne    83c0 <f37+0x430>
    8308:	0f b7 c1             	movzwl %cx,%eax
    830b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    830e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8311:	48 0f af c1          	imul   %rcx,%rax
    8315:	48 c1 e8 20          	shr    $0x20,%rax
    8319:	48 39 d0             	cmp    %rdx,%rax
    831c:	0f 83 9e 00 00 00    	jae    83c0 <f37+0x430>
    8322:	48 01 c7             	add    %rax,%rdi
    8325:	0f b6 07             	movzbl (%rdi),%eax
    8328:	84 c0                	test   %al,%al
    832a:	0f 84 90 00 00 00    	je     83c0 <f37+0x430>
    8330:	31 db                	xor    %ebx,%ebx
    8332:	0f 1f 00             	nopl   (%rax)
    8335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    833c:	00 00 00 00 
    8340:	3c fd                	cmp    $0xfd,%al
    8342:	0f 87 f5 00 00 00    	ja     843d <f37+0x4ad>
    8348:	83 c0 01             	add    $0x1,%eax
    834b:	88 07                	mov    %al,(%rdi)
    834d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8352:	31 d2                	xor    %edx,%edx
    8354:	4d 85 ed             	test   %r13,%r13
    8357:	0f 85 dd fc ff ff    	jne    803a <f37+0xaa>
    835d:	e9 fb fc ff ff       	jmp    805d <f37+0xcd>
    8362:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8368:	66 85 c0             	test   %ax,%ax
    836b:	0f 85 04 ff ff ff    	jne    8275 <f37+0x2e5>
    8371:	e9 f3 fe ff ff       	jmp    8269 <f37+0x2d9>
    8376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    837d:	00 00 00 
    8380:	66 85 c0             	test   %ax,%ax
    8383:	0f 85 92 fd ff ff    	jne    811b <f37+0x18b>
    8389:	e9 7f fd ff ff       	jmp    810d <f37+0x17d>
    838e:	66 90                	xchg   %ax,%ax
    8390:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8395:	e9 a4 fc ff ff       	jmp    803e <f37+0xae>
    839a:	66 85 c9             	test   %cx,%cx
    839d:	75 21                	jne    83c0 <f37+0x430>
    839f:	0f b6 07             	movzbl (%rdi),%eax
    83a2:	84 c0                	test   %al,%al
    83a4:	74 1a                	je     83c0 <f37+0x430>
    83a6:	3c fd                	cmp    $0xfd,%al
    83a8:	0f 87 c2 00 00 00    	ja     8470 <f37+0x4e0>
    83ae:	83 c0 01             	add    $0x1,%eax
    83b1:	88 07                	mov    %al,(%rdi)
    83b3:	66 90                	xchg   %ax,%ax
    83b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83bc:	00 00 00 00 
    83c0:	be 02 00 00 00       	mov    $0x2,%esi
    83c5:	bf 08 00 00 00       	mov    $0x8,%edi
    83ca:	e8 81 d6 ff ff       	call   5a50 <fwp_heap_alloc>
    83cf:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    83d6:	48 8b 15 5b c7 01 00 	mov    0x1c75b(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    83dd:	49 89 c4             	mov    %rax,%r12
    83e0:	48 2b 05 29 c7 01 00 	sub    0x1c729(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    83e7:	48 c1 e2 10          	shl    $0x10,%rdx
    83eb:	48 39 d0             	cmp    %rdx,%rax
    83ee:	73 57                	jae    8447 <f37+0x4b7>
    83f0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83f7:	00 00 
    83f9:	48 89 c2             	mov    %rax,%rdx
    83fc:	48 c1 ea 10          	shr    $0x10,%rdx
    8400:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8404:	48 8b 15 4d c7 01 00 	mov    0x1c74d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    840b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    840f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8413:	48 85 ed             	test   %rbp,%rbp
    8416:	0f 84 61 fd ff ff    	je     817d <f37+0x1ed>
    841c:	31 db                	xor    %ebx,%ebx
    841e:	e9 c0 fc ff ff       	jmp    80e3 <f37+0x153>
    8423:	48 89 df             	mov    %rbx,%rdi
    8426:	e8 e5 ce ff ff       	call   5310 <fwp_rc_forget_slot>
    842b:	e9 42 fe ff ff       	jmp    8272 <f37+0x2e2>
    8430:	48 89 ef             	mov    %rbp,%rdi
    8433:	e8 d8 ce ff ff       	call   5310 <fwp_rc_forget_slot>
    8438:	e9 da fc ff ff       	jmp    8117 <f37+0x187>
    843d:	e8 ae cd ff ff       	call   51f0 <fwp_rc_wide_dup>
    8442:	e9 06 ff ff ff       	jmp    834d <f37+0x3bd>
    8447:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    844e:	00 00 
    8450:	e9 28 fd ff ff       	jmp    817d <f37+0x1ed>
    8455:	e8 96 cd ff ff       	call   51f0 <fwp_rc_wide_dup>
    845a:	e9 d6 fb ff ff       	jmp    8035 <f37+0xa5>
    845f:	e8 fc af ff ff       	call   3460 <__stack_chk_fail@plt>
    8464:	48 8d 3d c2 6c 00 00 	lea    0x6cc2(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    846b:	e8 30 bd ff ff       	call   41a0 <fwp_trap>
    8470:	e8 7b cd ff ff       	call   51f0 <fwp_rc_wide_dup>
    8475:	e9 46 ff ff ff       	jmp    83c0 <f37+0x430>
    847a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008480 <fwp_owned_entry37>:
    8480:	f3 0f 1e fa          	endbr64
    8484:	48 8b 3f             	mov    (%rdi),%rdi
    8487:	e9 04 fb ff ff       	jmp    7f90 <f37>
    848c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008490 <e37>:
    8490:	f3 0f 1e fa          	endbr64
    8494:	53                   	push   %rbx
    8495:	48 8b 1f             	mov    (%rdi),%rbx
    8498:	48 89 df             	mov    %rbx,%rdi
    849b:	e8 f0 e1 ff ff       	call   6690 <fwp_rc_share>
    84a0:	48 89 df             	mov    %rbx,%rdi
    84a3:	e8 e8 fa ff ff       	call   7f90 <f37>
    84a8:	48 89 c3             	mov    %rax,%rbx
    84ab:	48 89 c7             	mov    %rax,%rdi
    84ae:	e8 dd e1 ff ff       	call   6690 <fwp_rc_share>
    84b3:	48 89 d8             	mov    %rbx,%rax
    84b6:	5b                   	pop    %rbx
    84b7:	c3                   	ret
    84b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84bf:	00 

00000000000084c0 <fwp_write>:
    84c0:	41 57                	push   %r15
    84c2:	41 56                	push   %r14
    84c4:	41 55                	push   %r13
    84c6:	41 54                	push   %r12
    84c8:	55                   	push   %rbp
    84c9:	53                   	push   %rbx
    84ca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    84d1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    84d8:	00 00 
    84da:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    84e1:	00 
    84e2:	49 89 d4             	mov    %rdx,%r12
    84e5:	8b 12                	mov    (%rdx),%edx
    84e7:	83 fa 19             	cmp    $0x19,%edx
    84ea:	77 6a                	ja     8556 <fwp_write+0x96>
    84ec:	48 89 f5             	mov    %rsi,%rbp
    84ef:	89 d0                	mov    %edx,%eax
    84f1:	89 ce                	mov    %ecx,%esi
    84f3:	48 89 fb             	mov    %rdi,%rbx
    84f6:	48 8d 0d 13 75 00 00 	lea    0x7513(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    84fd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8501:	48 01 c8             	add    %rcx,%rax
    8504:	3e ff e0             	notrack jmp *%rax
    8507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    850e:	00 00 
    8510:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8514:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8518:	48 89 ca             	mov    %rcx,%rdx
    851b:	48 85 c9             	test   %rcx,%rcx
    851e:	0f 88 9c 0c 00 00    	js     91c0 <fwp_write+0xd00>
    8524:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    852b:	00 
    852c:	48 89 c6             	mov    %rax,%rsi
    852f:	4c 89 e7             	mov    %r12,%rdi
    8532:	e8 09 b5 ff ff       	call   3a40 <fwp_fmt_u128>
    8537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    853e:	00 00 
    8540:	4c 89 e7             	mov    %r12,%rdi
    8543:	e8 08 af ff ff       	call   3450 <strlen@plt>
    8548:	4c 89 e6             	mov    %r12,%rsi
    854b:	48 89 df             	mov    %rbx,%rdi
    854e:	48 89 c2             	mov    %rax,%rdx
    8551:	e8 1a bb ff ff       	call   4070 <buf_put>
    8556:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    855d:	00 
    855e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8565:	00 00 
    8567:	0f 85 28 04 00 00    	jne    8995 <fwp_write+0x4d5>
    856d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8574:	5b                   	pop    %rbx
    8575:	5d                   	pop    %rbp
    8576:	41 5c                	pop    %r12
    8578:	41 5d                	pop    %r13
    857a:	41 5e                	pop    %r14
    857c:	41 5f                	pop    %r15
    857e:	c3                   	ret
    857f:	90                   	nop
    8580:	49 89 e9             	mov    %rbp,%r9
    8583:	4c 8d 05 cd 6b 00 00 	lea    0x6bcd(%rip),%r8        # f157 <_IO_stdin_used+0x157>
    858a:	b9 00 02 00 00       	mov    $0x200,%ecx
    858f:	ba 02 00 00 00       	mov    $0x2,%edx
    8594:	be 00 02 00 00       	mov    $0x200,%esi
    8599:	31 c0                	xor    %eax,%eax
    859b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    85a2:	00 
    85a3:	e8 08 ae ff ff       	call   33b0 <__snprintf_chk@plt>
    85a8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    85af:	00 
    85b0:	e8 9b ae ff ff       	call   3450 <strlen@plt>
    85b5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    85bc:	00 
    85bd:	48 89 df             	mov    %rbx,%rdi
    85c0:	48 89 c2             	mov    %rax,%rdx
    85c3:	e8 a8 ba ff ff       	call   4070 <buf_put>
    85c8:	eb 8c                	jmp    8556 <fwp_write+0x96>
    85ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85d0:	49 89 e9             	mov    %rbp,%r9
    85d3:	4c 8d 05 78 6b 00 00 	lea    0x6b78(%rip),%r8        # f152 <_IO_stdin_used+0x152>
    85da:	eb ae                	jmp    858a <fwp_write+0xca>
    85dc:	0f 1f 40 00          	nopl   0x0(%rax)
    85e0:	83 fa 13             	cmp    $0x13,%edx
    85e3:	48 8d 05 5e 6b 00 00 	lea    0x6b5e(%rip),%rax        # f148 <_IO_stdin_used+0x148>
    85ea:	48 8d 35 5c 6b 00 00 	lea    0x6b5c(%rip),%rsi        # f14d <_IO_stdin_used+0x14d>
    85f1:	ba 04 00 00 00       	mov    $0x4,%edx
    85f6:	48 0f 44 f0          	cmove  %rax,%rsi
    85fa:	45 31 ed             	xor    %r13d,%r13d
    85fd:	e8 6e ba ff ff       	call   4070 <buf_put>
    8602:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8607:	0f 84 a3 08 00 00    	je     8eb0 <fwp_write+0x9f0>
    860d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8612:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8617:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    861c:	48 89 df             	mov    %rbx,%rdi
    861f:	49 0f 44 c5          	cmove  %r13,%rax
    8623:	31 c9                	xor    %ecx,%ecx
    8625:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    862a:	e8 91 fe ff ff       	call   84c0 <fwp_write>
    862f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8634:	0f 84 6e 09 00 00    	je     8fa8 <fwp_write+0xae8>
    863a:	49 83 c5 01          	add    $0x1,%r13
    863e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8642:	0f 83 68 08 00 00    	jae    8eb0 <fwp_write+0x9f0>
    8648:	ba 02 00 00 00       	mov    $0x2,%edx
    864d:	48 8d 35 43 6b 00 00 	lea    0x6b43(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8654:	48 89 df             	mov    %rbx,%rdi
    8657:	e8 14 ba ff ff       	call   4070 <buf_put>
    865c:	eb af                	jmp    860d <fwp_write+0x14d>
    865e:	66 90                	xchg   %ax,%ax
    8660:	ba 06 00 00 00       	mov    $0x6,%edx
    8665:	48 8d 35 04 6b 00 00 	lea    0x6b04(%rip),%rsi        # f170 <_IO_stdin_used+0x170>
    866c:	48 83 c5 10          	add    $0x10,%rbp
    8670:	e8 fb b9 ff ff       	call   4070 <buf_put>
    8675:	48 89 ef             	mov    %rbp,%rdi
    8678:	e8 d3 ad ff ff       	call   3450 <strlen@plt>
    867d:	48 89 ee             	mov    %rbp,%rsi
    8680:	48 89 df             	mov    %rbx,%rdi
    8683:	48 89 c2             	mov    %rax,%rdx
    8686:	e8 e5 b9 ff ff       	call   4070 <buf_put>
    868b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8690:	ba 01 00 00 00       	mov    $0x1,%edx
    8695:	48 89 df             	mov    %rbx,%rdi
    8698:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    869d:	e8 ce b9 ff ff       	call   4070 <buf_put>
    86a2:	e9 af fe ff ff       	jmp    8556 <fwp_write+0x96>
    86a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    86ae:	00 00 
    86b0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86b7:	00 
    86b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86bf:	00 00 
    86c1:	0f 85 ce 02 00 00    	jne    8995 <fwp_write+0x4d5>
    86c7:	ba 0a 00 00 00       	mov    $0xa,%edx
    86cc:	48 8d 35 89 6a 00 00 	lea    0x6a89(%rip),%rsi        # f15c <_IO_stdin_used+0x15c>
    86d3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    86da:	48 89 df             	mov    %rbx,%rdi
    86dd:	5b                   	pop    %rbx
    86de:	5d                   	pop    %rbp
    86df:	41 5c                	pop    %r12
    86e1:	41 5d                	pop    %r13
    86e3:	41 5e                	pop    %r14
    86e5:	41 5f                	pop    %r15
    86e7:	e9 84 b9 ff ff       	jmp    4070 <buf_put>
    86ec:	0f 1f 40 00          	nopl   0x0(%rax)
    86f0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    86f5:	4d 85 ed             	test   %r13,%r13
    86f8:	0f 84 02 0c 00 00    	je     9300 <fwp_write+0xe40>
    86fe:	48 8d 35 9f 6a 00 00 	lea    0x6a9f(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    8705:	4c 89 ef             	mov    %r13,%rdi
    8708:	e8 23 ae ff ff       	call   3530 <strcmp@plt>
    870d:	41 89 c1             	mov    %eax,%r9d
    8710:	85 c0                	test   %eax,%eax
    8712:	0f 84 6c 0c 00 00    	je     9384 <fwp_write+0xec4>
    8718:	4c 89 ef             	mov    %r13,%rdi
    871b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8720:	e8 2b ad ff ff       	call   3450 <strlen@plt>
    8725:	4c 89 ee             	mov    %r13,%rsi
    8728:	48 89 df             	mov    %rbx,%rdi
    872b:	48 89 c2             	mov    %rax,%rdx
    872e:	e8 3d b9 ff ff       	call   4070 <buf_put>
    8733:	ba 01 00 00 00       	mov    $0x1,%edx
    8738:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    873d:	48 89 df             	mov    %rbx,%rdi
    8740:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8745:	e8 26 b9 ff ff       	call   4070 <buf_put>
    874a:	ba 01 00 00 00       	mov    $0x1,%edx
    874f:	4c 89 fe             	mov    %r15,%rsi
    8752:	48 89 df             	mov    %rbx,%rdi
    8755:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    875a:	e8 11 b9 ff ff       	call   4070 <buf_put>
    875f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8764:	45 31 f6             	xor    %r14d,%r14d
    8767:	85 d2                	test   %edx,%edx
    8769:	0f 8e 81 0a 00 00    	jle    91f0 <fwp_write+0xd30>
    876f:	45 31 ed             	xor    %r13d,%r13d
    8772:	4d 85 ed             	test   %r13,%r13
    8775:	0f 85 75 07 00 00    	jne    8ef0 <fwp_write+0xa30>
    877b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8782:	00 
    8783:	45 85 f6             	test   %r14d,%r14d
    8786:	0f 84 84 07 00 00    	je     8f10 <fwp_write+0xa50>
    878c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8791:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8796:	48 89 df             	mov    %rbx,%rdi
    8799:	49 83 c5 01          	add    $0x1,%r13
    879d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    87a1:	31 c9                	xor    %ecx,%ecx
    87a3:	e8 18 fd ff ff       	call   84c0 <fwp_write>
    87a8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    87ad:	7f c3                	jg     8772 <fwp_write+0x2b2>
    87af:	45 85 f6             	test   %r14d,%r14d
    87b2:	0f 84 38 0a 00 00    	je     91f0 <fwp_write+0xd30>
    87b8:	b8 29 00 00 00       	mov    $0x29,%eax
    87bd:	ba 01 00 00 00       	mov    $0x1,%edx
    87c2:	4c 89 fe             	mov    %r15,%rsi
    87c5:	48 89 df             	mov    %rbx,%rdi
    87c8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    87cc:	e8 9f b8 ff ff       	call   4070 <buf_put>
    87d1:	e9 80 fd ff ff       	jmp    8556 <fwp_write+0x96>
    87d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    87dd:	00 00 00 
    87e0:	ba 01 00 00 00       	mov    $0x1,%edx
    87e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    87ea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    87ef:	e8 7c b8 ff ff       	call   4070 <buf_put>
    87f4:	48 85 ed             	test   %rbp,%rbp
    87f7:	0f 84 93 06 00 00    	je     8e90 <fwp_write+0x9d0>
    87fd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8801:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8806:	31 c9                	xor    %ecx,%ecx
    8808:	48 89 df             	mov    %rbx,%rdi
    880b:	e8 b0 fc ff ff       	call   84c0 <fwp_write>
    8810:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8814:	48 85 ed             	test   %rbp,%rbp
    8817:	0f 84 73 06 00 00    	je     8e90 <fwp_write+0x9d0>
    881d:	ba 02 00 00 00       	mov    $0x2,%edx
    8822:	48 8d 35 6e 69 00 00 	lea    0x696e(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8829:	48 89 df             	mov    %rbx,%rdi
    882c:	e8 3f b8 ff ff       	call   4070 <buf_put>
    8831:	eb ca                	jmp    87fd <fwp_write+0x33d>
    8833:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8838:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    883c:	85 f6                	test   %esi,%esi
    883e:	0f 84 fc 07 00 00    	je     9040 <fwp_write+0xb80>
    8844:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    884b:	00 
    884c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8853:	00 00 
    8855:	0f 85 3a 01 00 00    	jne    8995 <fwp_write+0x4d5>
    885b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    885f:	4c 89 ea             	mov    %r13,%rdx
    8862:	e9 6c fe ff ff       	jmp    86d3 <fwp_write+0x213>
    8867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    886e:	00 00 
    8870:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8875:	ba 01 00 00 00       	mov    $0x1,%edx
    887a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    887f:	48 89 ee             	mov    %rbp,%rsi
    8882:	e8 e9 b7 ff ff       	call   4070 <buf_put>
    8887:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    888c:	4c 89 e7             	mov    %r12,%rdi
    888f:	e8 bc ab ff ff       	call   3450 <strlen@plt>
    8894:	4c 89 e6             	mov    %r12,%rsi
    8897:	48 89 df             	mov    %rbx,%rdi
    889a:	48 89 c2             	mov    %rax,%rdx
    889d:	e8 ce b7 ff ff       	call   4070 <buf_put>
    88a2:	ba 01 00 00 00       	mov    $0x1,%edx
    88a7:	48 89 ee             	mov    %rbp,%rsi
    88aa:	48 89 df             	mov    %rbx,%rdi
    88ad:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    88b2:	e8 b9 b7 ff ff       	call   4070 <buf_put>
    88b7:	e9 9a fc ff ff       	jmp    8556 <fwp_write+0x96>
    88bc:	0f 1f 40 00          	nopl   0x0(%rax)
    88c0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    88c5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    88c9:	0f 8a 8e 0b 00 00    	jp     945d <fwp_write+0xf9d>
    88cf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    88d3:	66 0f 54 05 65 72 00 	andpd  0x7265(%rip),%xmm0        # fb40 <msg.4+0xc0>
    88da:	00 
    88db:	bd 01 00 00 00       	mov    $0x1,%ebp
    88e0:	66 0f 2e 05 d8 71 00 	ucomisd 0x71d8(%rip),%xmm0        # fac0 <msg.4+0x40>
    88e7:	00 
    88e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    88ef:	00 
    88f0:	0f 87 b2 09 00 00    	ja     92a8 <fwp_write+0xde8>
    88f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88fd:	00 00 00 
    8900:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8904:	89 ee                	mov    %ebp,%esi
    8906:	4c 89 e7             	mov    %r12,%rdi
    8909:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    890e:	e8 ad bb ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8913:	31 f6                	xor    %esi,%esi
    8915:	4c 89 e7             	mov    %r12,%rdi
    8918:	e8 f3 aa ff ff       	call   3410 <strtod@plt>
    891d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8922:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8926:	7a 06                	jp     892e <fwp_write+0x46e>
    8928:	0f 84 e9 01 00 00    	je     8b17 <fwp_write+0x657>
    892e:	83 c5 01             	add    $0x1,%ebp
    8931:	83 fd 12             	cmp    $0x12,%ebp
    8934:	75 ca                	jne    8900 <fwp_write+0x440>
    8936:	be 11 00 00 00       	mov    $0x11,%esi
    893b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    893f:	4c 89 e7             	mov    %r12,%rdi
    8942:	e8 79 bb ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8947:	e9 cb 01 00 00       	jmp    8b17 <fwp_write+0x657>
    894c:	0f 1f 40 00          	nopl   0x0(%rax)
    8950:	48 83 fd 01          	cmp    $0x1,%rbp
    8954:	0f 84 e6 08 00 00    	je     9240 <fwp_write+0xd80>
    895a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    895e:	b8 02 00 00 00       	mov    $0x2,%eax
    8963:	ba 01 00 00 00       	mov    $0x1,%edx
    8968:	48 0f 44 d0          	cmove  %rax,%rdx
    896c:	48 8d 35 cd 67 00 00 	lea    0x67cd(%rip),%rsi        # f140 <_IO_stdin_used+0x140>
    8973:	48 8d 05 cb 67 00 00 	lea    0x67cb(%rip),%rax        # f145 <_IO_stdin_used+0x145>
    897a:	48 0f 44 f0          	cmove  %rax,%rsi
    897e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8985:	00 
    8986:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    898d:	00 00 
    898f:	0f 84 3e fd ff ff    	je     86d3 <fwp_write+0x213>
    8995:	e8 c6 aa ff ff       	call   3460 <__stack_chk_fail@plt>
    899a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89a0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    89a5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    89aa:	e8 01 b6 ff ff       	call   3fb0 <buf_grow>
    89af:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    89b3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    89b9:	4c 03 0b             	add    (%rbx),%r9
    89bc:	66 45 89 11          	mov    %r10w,(%r9)
    89c0:	45 85 e4             	test   %r12d,%r12d
    89c3:	0f 8e 07 05 00 00    	jle    8ed0 <fwp_write+0xa10>
    89c9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    89d0:	55 55 55 
    89d3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    89d8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    89df:	aa aa aa 
    89e2:	49 83 c1 01          	add    $0x1,%r9
    89e6:	eb 45                	jmp    8a2d <fwp_write+0x56d>
    89e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89ef:	00 
    89f0:	be 01 00 00 00       	mov    $0x1,%esi
    89f5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    89fa:	88 07                	mov    %al,(%rdi)
    89fc:	48 89 e8             	mov    %rbp,%rax
    89ff:	49 f7 e8             	imul   %r8
    8a02:	48 89 e8             	mov    %rbp,%rax
    8a05:	48 c1 f8 3f          	sar    $0x3f,%rax
    8a09:	48 29 c2             	sub    %rax,%rdx
    8a0c:	48 85 c9             	test   %rcx,%rcx
    8a0f:	0f 95 c0             	setne  %al
    8a12:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8a16:	48 83 ef 01          	sub    $0x1,%rdi
    8a1a:	48 21 c5             	and    %rax,%rbp
    8a1d:	48 29 ea             	sub    %rbp,%rdx
    8a20:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8a24:	49 39 f9             	cmp    %rdi,%r9
    8a27:	0f 84 a3 04 00 00    	je     8ed0 <fwp_write+0xa10>
    8a2d:	48 89 e8             	mov    %rbp,%rax
    8a30:	49 f7 e8             	imul   %r8
    8a33:	48 89 e8             	mov    %rbp,%rax
    8a36:	48 c1 f8 3f          	sar    $0x3f,%rax
    8a3a:	48 89 d1             	mov    %rdx,%rcx
    8a3d:	48 29 c1             	sub    %rax,%rcx
    8a40:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8a44:	48 89 e9             	mov    %rbp,%rcx
    8a47:	48 29 c1             	sub    %rax,%rcx
    8a4a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8a4e:	49 f7 e2             	mul    %r10
    8a51:	b8 30 00 00 00       	mov    $0x30,%eax
    8a56:	48 89 d6             	mov    %rdx,%rsi
    8a59:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8a5d:	48 d1 ee             	shr    $1,%rsi
    8a60:	48 01 f2             	add    %rsi,%rdx
    8a63:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8a67:	48 29 d6             	sub    %rdx,%rsi
    8a6a:	74 8e                	je     89fa <fwp_write+0x53a>
    8a6c:	48 83 fe 01          	cmp    $0x1,%rsi
    8a70:	0f 85 7a ff ff ff    	jne    89f0 <fwp_write+0x530>
    8a76:	31 f6                	xor    %esi,%esi
    8a78:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8a7d:	e9 78 ff ff ff       	jmp    89fa <fwp_write+0x53a>
    8a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a88:	66 0f 6e cd          	movd   %ebp,%xmm1
    8a8c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8a8f:	0f 8a c8 09 00 00    	jp     945d <fwp_write+0xf9d>
    8a95:	0f 28 c1             	movaps %xmm1,%xmm0
    8a98:	0f 54 05 91 70 00 00 	andps  0x7091(%rip),%xmm0        # fb30 <msg.4+0xb0>
    8a9f:	0f 2e 05 5e 65 00 00 	ucomiss 0x655e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8aa6:	0f 87 24 08 00 00    	ja     92d0 <fwp_write+0xe10>
    8aac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8ab0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8ab6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8abd:	00 
    8abe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8ac2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8ac7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8ace:	00 00 
    8ad0:	44 89 ee             	mov    %r13d,%esi
    8ad3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8ad8:	4c 89 e7             	mov    %r12,%rdi
    8adb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8ae0:	e8 db b9 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8ae5:	31 f6                	xor    %esi,%esi
    8ae7:	4c 89 e7             	mov    %r12,%rdi
    8aea:	e8 c1 a9 ff ff       	call   34b0 <strtof@plt>
    8aef:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8af4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8af7:	7a 02                	jp     8afb <fwp_write+0x63b>
    8af9:	74 1c                	je     8b17 <fwp_write+0x657>
    8afb:	41 83 c5 01          	add    $0x1,%r13d
    8aff:	41 83 fd 0a          	cmp    $0xa,%r13d
    8b03:	75 cb                	jne    8ad0 <fwp_write+0x610>
    8b05:	be 09 00 00 00       	mov    $0x9,%esi
    8b0a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8b0f:	4c 89 e7             	mov    %r12,%rdi
    8b12:	e8 a9 b9 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8b17:	4c 89 e7             	mov    %r12,%rdi
    8b1a:	e8 11 b6 ff ff       	call   4130 <fwp_finish_float>
    8b1f:	e9 1c fa ff ff       	jmp    8540 <fwp_write+0x80>
    8b24:	0f 1f 40 00          	nopl   0x0(%rax)
    8b28:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8b2c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8b30:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8b37:	00 
    8b38:	48 89 ef             	mov    %rbp,%rdi
    8b3b:	e8 00 af ff ff       	call   3a40 <fwp_fmt_u128>
    8b40:	48 89 ef             	mov    %rbp,%rdi
    8b43:	e8 08 a9 ff ff       	call   3450 <strlen@plt>
    8b48:	48 89 ee             	mov    %rbp,%rsi
    8b4b:	48 89 df             	mov    %rbx,%rdi
    8b4e:	48 89 c2             	mov    %rax,%rdx
    8b51:	e8 1a b5 ff ff       	call   4070 <buf_put>
    8b56:	e9 fb f9 ff ff       	jmp    8556 <fwp_write+0x96>
    8b5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8b60:	ba 06 00 00 00       	mov    $0x6,%edx
    8b65:	48 8d 35 2e 66 00 00 	lea    0x662e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    8b6c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8b72:	e8 f9 b4 ff ff       	call   4070 <buf_put>
    8b77:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8b7e:	ff ff 7f 
    8b81:	48 23 55 00          	and    0x0(%rbp),%rdx
    8b85:	0f 84 86 02 00 00    	je     8e11 <fwp_write+0x951>
    8b8b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8b90:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8b94:	48 85 d2             	test   %rdx,%rdx
    8b97:	0f 84 ae 00 00 00    	je     8c4b <fwp_write+0x78b>
    8b9d:	8b 0a                	mov    (%rdx),%ecx
    8b9f:	83 f9 1c             	cmp    $0x1c,%ecx
    8ba2:	0f 84 58 06 00 00    	je     9200 <fwp_write+0xd40>
    8ba8:	83 f9 1b             	cmp    $0x1b,%ecx
    8bab:	0f 87 9a 00 00 00    	ja     8c4b <fwp_write+0x78b>
    8bb1:	be 01 00 00 00       	mov    $0x1,%esi
    8bb6:	48 d3 e6             	shl    %cl,%rsi
    8bb9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8bbf:	0f 85 4b 04 00 00    	jne    9010 <fwp_write+0xb50>
    8bc5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8bcb:	0f 85 0f 04 00 00    	jne    8fe0 <fwp_write+0xb20>
    8bd1:	83 e6 21             	and    $0x21,%esi
    8bd4:	74 75                	je     8c4b <fwp_write+0x78b>
    8bd6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8bdb:	48 85 ff             	test   %rdi,%rdi
    8bde:	79 07                	jns    8be7 <fwp_write+0x727>
    8be0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8be4:	4c 01 ee             	add    %r13,%rsi
    8be7:	48 0f be 3e          	movsbq (%rsi),%rdi
    8beb:	85 c9                	test   %ecx,%ecx
    8bed:	40 0f b6 f7          	movzbl %dil,%esi
    8bf1:	48 0f 44 f7          	cmove  %rdi,%rsi
    8bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bfc:	00 00 00 00 
    8c00:	31 c9                	xor    %ecx,%ecx
    8c02:	48 89 df             	mov    %rbx,%rdi
    8c05:	49 83 c5 01          	add    $0x1,%r13
    8c09:	e8 b2 f8 ff ff       	call   84c0 <fwp_write>
    8c0e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8c15:	ff ff 7f 
    8c18:	48 23 55 00          	and    0x0(%rbp),%rdx
    8c1c:	49 39 d5             	cmp    %rdx,%r13
    8c1f:	0f 83 ec 01 00 00    	jae    8e11 <fwp_write+0x951>
    8c25:	ba 02 00 00 00       	mov    $0x2,%edx
    8c2a:	48 89 df             	mov    %rbx,%rdi
    8c2d:	48 8d 35 63 65 00 00 	lea    0x6563(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8c34:	e8 37 b4 ff ff       	call   4070 <buf_put>
    8c39:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8c3e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8c42:	48 85 d2             	test   %rdx,%rdx
    8c45:	0f 85 52 ff ff ff    	jne    8b9d <fwp_write+0x6dd>
    8c4b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8c50:	48 85 ff             	test   %rdi,%rdi
    8c53:	0f 88 cf 05 00 00    	js     9228 <fwp_write+0xd68>
    8c59:	48 8b 31             	mov    (%rcx),%rsi
    8c5c:	eb a2                	jmp    8c00 <fwp_write+0x740>
    8c5e:	66 90                	xchg   %ax,%ax
    8c60:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c67:	00 
    8c68:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c6f:	00 00 
    8c71:	0f 85 1e fd ff ff    	jne    8995 <fwp_write+0x4d5>
    8c77:	ba 08 00 00 00       	mov    $0x8,%edx
    8c7c:	48 8d 35 e4 64 00 00 	lea    0x64e4(%rip),%rsi        # f167 <_IO_stdin_used+0x167>
    8c83:	e9 4b fa ff ff       	jmp    86d3 <fwp_write+0x213>
    8c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c8f:	00 
    8c90:	89 e8                	mov    %ebp,%eax
    8c92:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8c99:	76 03                	jbe    8c9e <fwp_write+0x7de>
    8c9b:	8b 45 00             	mov    0x0(%rbp),%eax
    8c9e:	41 89 c6             	mov    %eax,%r14d
    8ca1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8ca6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8cab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8caf:	4c 89 ef             	mov    %r13,%rdi
    8cb2:	e8 99 a7 ff ff       	call   3450 <strlen@plt>
    8cb7:	4c 89 ee             	mov    %r13,%rsi
    8cba:	48 89 df             	mov    %rbx,%rdi
    8cbd:	48 89 c2             	mov    %rax,%rdx
    8cc0:	e8 ab b3 ff ff       	call   4070 <buf_put>
    8cc5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8cca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8cce:	85 f6                	test   %esi,%esi
    8cd0:	0f 8e 80 f8 ff ff    	jle    8556 <fwp_write+0x96>
    8cd6:	45 31 ed             	xor    %r13d,%r13d
    8cd9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8cde:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8ce3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8ce8:	ba 01 00 00 00       	mov    $0x1,%edx
    8ced:	4c 89 fe             	mov    %r15,%rsi
    8cf0:	48 89 04 24          	mov    %rax,(%rsp)
    8cf4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8cf9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8cfd:	48 89 df             	mov    %rbx,%rdi
    8d00:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8d04:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8d09:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8d0e:	e8 5d b3 ff ff       	call   4070 <buf_put>
    8d13:	41 8b 06             	mov    (%r14),%eax
    8d16:	83 f8 0e             	cmp    $0xe,%eax
    8d19:	0f 84 71 02 00 00    	je     8f90 <fwp_write+0xad0>
    8d1f:	83 f8 10             	cmp    $0x10,%eax
    8d22:	0f 84 38 02 00 00    	je     8f60 <fwp_write+0xaa0>
    8d28:	83 f8 0a             	cmp    $0xa,%eax
    8d2b:	0f 84 7f 04 00 00    	je     91b0 <fwp_write+0xcf0>
    8d31:	0f 8f f9 00 00 00    	jg     8e30 <fwp_write+0x970>
    8d37:	83 f8 03             	cmp    $0x3,%eax
    8d3a:	0f 8f 50 04 00 00    	jg     9190 <fwp_write+0xcd0>
    8d40:	85 c0                	test   %eax,%eax
    8d42:	78 10                	js     8d54 <fwp_write+0x894>
    8d44:	48 8b 04 24          	mov    (%rsp),%rax
    8d48:	48 c1 e8 3f          	shr    $0x3f,%rax
    8d4c:	85 c0                	test   %eax,%eax
    8d4e:	0f 85 f9 00 00 00    	jne    8e4d <fwp_write+0x98d>
    8d54:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8d59:	48 8b 34 24          	mov    (%rsp),%rsi
    8d5d:	31 c9                	xor    %ecx,%ecx
    8d5f:	48 89 df             	mov    %rbx,%rdi
    8d62:	e8 59 f7 ff ff       	call   84c0 <fwp_write>
    8d67:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8d6c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8d71:	49 83 c5 01          	add    $0x1,%r13
    8d75:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8d79:	0f 8f 5f ff ff ff    	jg     8cde <fwp_write+0x81e>
    8d7f:	e9 d2 f7 ff ff       	jmp    8556 <fwp_write+0x96>
    8d84:	0f 1f 40 00          	nopl   0x0(%rax)
    8d88:	ba 06 00 00 00       	mov    $0x6,%edx
    8d8d:	48 8d 35 f9 63 00 00 	lea    0x63f9(%rip),%rsi        # f18d <_IO_stdin_used+0x18d>
    8d94:	45 31 ed             	xor    %r13d,%r13d
    8d97:	e8 d4 b2 ff ff       	call   4070 <buf_put>
    8d9c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8da1:	75 19                	jne    8dbc <fwp_write+0x8fc>
    8da3:	eb 6c                	jmp    8e11 <fwp_write+0x951>
    8da5:	0f 1f 00             	nopl   (%rax)
    8da8:	ba 02 00 00 00       	mov    $0x2,%edx
    8dad:	48 8d 35 e3 63 00 00 	lea    0x63e3(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8db4:	48 89 df             	mov    %rbx,%rdi
    8db7:	e8 b4 b2 ff ff       	call   4070 <buf_put>
    8dbc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8dc2:	b9 00 02 00 00       	mov    $0x200,%ecx
    8dc7:	31 c0                	xor    %eax,%eax
    8dc9:	49 83 c5 01          	add    $0x1,%r13
    8dcd:	4c 8d 05 c0 63 00 00 	lea    0x63c0(%rip),%r8        # f194 <_IO_stdin_used+0x194>
    8dd4:	ba 02 00 00 00       	mov    $0x2,%edx
    8dd9:	be 00 02 00 00       	mov    $0x200,%esi
    8dde:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8de5:	00 
    8de6:	e8 c5 a5 ff ff       	call   33b0 <__snprintf_chk@plt>
    8deb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8df2:	00 
    8df3:	e8 58 a6 ff ff       	call   3450 <strlen@plt>
    8df8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8dff:	00 
    8e00:	48 89 df             	mov    %rbx,%rdi
    8e03:	48 89 c2             	mov    %rax,%rdx
    8e06:	e8 65 b2 ff ff       	call   4070 <buf_put>
    8e0b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8e0f:	72 97                	jb     8da8 <fwp_write+0x8e8>
    8e11:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e16:	ba 01 00 00 00       	mov    $0x1,%edx
    8e1b:	48 89 df             	mov    %rbx,%rdi
    8e1e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8e23:	e8 48 b2 ff ff       	call   4070 <buf_put>
    8e28:	e9 29 f7 ff ff       	jmp    8556 <fwp_write+0x96>
    8e2d:	0f 1f 00             	nopl   (%rax)
    8e30:	83 f8 0b             	cmp    $0xb,%eax
    8e33:	0f 85 1b ff ff ff    	jne    8d54 <fwp_write+0x894>
    8e39:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8e3e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8e42:	83 e0 01             	and    $0x1,%eax
    8e45:	85 c0                	test   %eax,%eax
    8e47:	0f 84 07 ff ff ff    	je     8d54 <fwp_write+0x894>
    8e4d:	4c 89 fe             	mov    %r15,%rsi
    8e50:	48 89 df             	mov    %rbx,%rdi
    8e53:	ba 01 00 00 00       	mov    $0x1,%edx
    8e58:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8e5d:	e8 0e b2 ff ff       	call   4070 <buf_put>
    8e62:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8e67:	48 8b 34 24          	mov    (%rsp),%rsi
    8e6b:	31 c9                	xor    %ecx,%ecx
    8e6d:	48 89 df             	mov    %rbx,%rdi
    8e70:	e8 4b f6 ff ff       	call   84c0 <fwp_write>
    8e75:	ba 01 00 00 00       	mov    $0x1,%edx
    8e7a:	4c 89 fe             	mov    %r15,%rsi
    8e7d:	48 89 df             	mov    %rbx,%rdi
    8e80:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8e85:	e8 e6 b1 ff ff       	call   4070 <buf_put>
    8e8a:	e9 d8 fe ff ff       	jmp    8d67 <fwp_write+0x8a7>
    8e8f:	90                   	nop
    8e90:	ba 01 00 00 00       	mov    $0x1,%edx
    8e95:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e9a:	48 89 df             	mov    %rbx,%rdi
    8e9d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8ea2:	e8 c9 b1 ff ff       	call   4070 <buf_put>
    8ea7:	e9 aa f6 ff ff       	jmp    8556 <fwp_write+0x96>
    8eac:	0f 1f 40 00          	nopl   0x0(%rax)
    8eb0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8eb5:	ba 01 00 00 00       	mov    $0x1,%edx
    8eba:	48 89 df             	mov    %rbx,%rdi
    8ebd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8ec2:	e8 a9 b1 ff ff       	call   4070 <buf_put>
    8ec7:	e9 8a f6 ff ff       	jmp    8556 <fwp_write+0x96>
    8ecc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ed0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8ed4:	48 8b 13             	mov    (%rbx),%rdx
    8ed7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8edc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8ee0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8ee4:	e9 6d f6 ff ff       	jmp    8556 <fwp_write+0x96>
    8ee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ef0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ef5:	48 8d 35 9b 62 00 00 	lea    0x629b(%rip),%rsi        # f197 <_IO_stdin_used+0x197>
    8efc:	48 89 df             	mov    %rbx,%rdi
    8eff:	e8 6c b1 ff ff       	call   4070 <buf_put>
    8f04:	e9 72 f8 ff ff       	jmp    877b <fwp_write+0x2bb>
    8f09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f10:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8f15:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8f1a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8f1e:	48 89 f7             	mov    %rsi,%rdi
    8f21:	48 89 34 24          	mov    %rsi,(%rsp)
    8f25:	e8 26 a5 ff ff       	call   3450 <strlen@plt>
    8f2a:	48 8b 34 24          	mov    (%rsp),%rsi
    8f2e:	48 89 df             	mov    %rbx,%rdi
    8f31:	48 89 c2             	mov    %rax,%rdx
    8f34:	e8 37 b1 ff ff       	call   4070 <buf_put>
    8f39:	ba 03 00 00 00       	mov    $0x3,%edx
    8f3e:	48 8d 35 75 62 00 00 	lea    0x6275(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8f45:	48 89 df             	mov    %rbx,%rdi
    8f48:	e8 23 b1 ff ff       	call   4070 <buf_put>
    8f4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8f52:	e9 35 f8 ff ff       	jmp    878c <fwp_write+0x2cc>
    8f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f5e:	00 00 
    8f60:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8f65:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8f69:	48 85 ff             	test   %rdi,%rdi
    8f6c:	0f 84 e2 fd ff ff    	je     8d54 <fwp_write+0x894>
    8f72:	48 8d 35 2b 62 00 00 	lea    0x622b(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    8f79:	e8 b2 a5 ff ff       	call   3530 <strcmp@plt>
    8f7e:	85 c0                	test   %eax,%eax
    8f80:	0f 95 c0             	setne  %al
    8f83:	0f b6 c0             	movzbl %al,%eax
    8f86:	e9 c1 fd ff ff       	jmp    8d4c <fwp_write+0x88c>
    8f8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8f90:	31 c0                	xor    %eax,%eax
    8f92:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8f99:	00 
    8f9a:	0f 97 c0             	seta   %al
    8f9d:	e9 aa fd ff ff       	jmp    8d4c <fwp_write+0x88c>
    8fa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fa8:	48 89 df             	mov    %rbx,%rdi
    8fab:	ba 02 00 00 00       	mov    $0x2,%edx
    8fb0:	48 8d 35 ea 61 00 00 	lea    0x61ea(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    8fb7:	e8 b4 b0 ff ff       	call   4070 <buf_put>
    8fbc:	4c 89 e8             	mov    %r13,%rax
    8fbf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8fc4:	31 c9                	xor    %ecx,%ecx
    8fc6:	48 c1 e0 04          	shl    $0x4,%rax
    8fca:	48 89 df             	mov    %rbx,%rdi
    8fcd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8fd2:	e8 e9 f4 ff ff       	call   84c0 <fwp_write>
    8fd7:	e9 5e f6 ff ff       	jmp    863a <fwp_write+0x17a>
    8fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    8fe0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8fe5:	48 85 ff             	test   %rdi,%rdi
    8fe8:	79 0c                	jns    8ff6 <fwp_write+0xb36>
    8fea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8ff1:	00 
    8ff2:	48 03 75 10          	add    0x10(%rbp),%rsi
    8ff6:	48 63 3e             	movslq (%rsi),%rdi
    8ff9:	83 f9 02             	cmp    $0x2,%ecx
    8ffc:	89 fe                	mov    %edi,%esi
    8ffe:	48 0f 44 f7          	cmove  %rdi,%rsi
    9002:	e9 f9 fb ff ff       	jmp    8c00 <fwp_write+0x740>
    9007:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    900e:	00 00 
    9010:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9015:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    901a:	48 85 ff             	test   %rdi,%rdi
    901d:	0f 88 0f 03 00 00    	js     9332 <fwp_write+0xe72>
    9023:	49 0f bf 38          	movswq (%r8),%rdi
    9027:	83 f9 01             	cmp    $0x1,%ecx
    902a:	0f b7 f7             	movzwl %di,%esi
    902d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9031:	e9 ca fb ff ff       	jmp    8c00 <fwp_write+0x740>
    9036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    903d:	00 00 00 
    9040:	ba 01 00 00 00       	mov    $0x1,%edx
    9045:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    904a:	48 83 c5 08          	add    $0x8,%rbp
    904e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9053:	e8 18 b0 ff ff       	call   4070 <buf_put>
    9058:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    905d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9062:	4d 85 ed             	test   %r13,%r13
    9065:	75 46                	jne    90ad <fwp_write+0xbed>
    9067:	e9 04 01 00 00       	jmp    9170 <fwp_write+0xcb0>
    906c:	0f 1f 40 00          	nopl   0x0(%rax)
    9070:	41 80 f9 09          	cmp    $0x9,%r9b
    9074:	0f 84 d6 00 00 00    	je     9150 <fwp_write+0xc90>
    907a:	41 80 f9 0a          	cmp    $0xa,%r9b
    907e:	0f 85 9c 00 00 00    	jne    9120 <fwp_write+0xc60>
    9084:	ba 02 00 00 00       	mov    $0x2,%edx
    9089:	48 8d 35 ed 60 00 00 	lea    0x60ed(%rip),%rsi        # f17d <_IO_stdin_used+0x17d>
    9090:	48 89 df             	mov    %rbx,%rdi
    9093:	e8 d8 af ff ff       	call   4070 <buf_put>
    9098:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    909f:	00 
    90a0:	48 83 c5 01          	add    $0x1,%rbp
    90a4:	49 39 ec             	cmp    %rbp,%r12
    90a7:	0f 84 c3 00 00 00    	je     9170 <fwp_write+0xcb0>
    90ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    90b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    90b6:	74 28                	je     90e0 <fwp_write+0xc20>
    90b8:	7e b6                	jle    9070 <fwp_write+0xbb0>
    90ba:	41 80 f9 22          	cmp    $0x22,%r9b
    90be:	74 40                	je     9100 <fwp_write+0xc40>
    90c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    90c4:	75 5a                	jne    9120 <fwp_write+0xc60>
    90c6:	ba 02 00 00 00       	mov    $0x2,%edx
    90cb:	48 8d 35 a8 60 00 00 	lea    0x60a8(%rip),%rsi        # f17a <_IO_stdin_used+0x17a>
    90d2:	48 89 df             	mov    %rbx,%rdi
    90d5:	e8 96 af ff ff       	call   4070 <buf_put>
    90da:	eb c4                	jmp    90a0 <fwp_write+0xbe0>
    90dc:	0f 1f 40 00          	nopl   0x0(%rax)
    90e0:	ba 02 00 00 00       	mov    $0x2,%edx
    90e5:	48 8d 35 97 60 00 00 	lea    0x6097(%rip),%rsi        # f183 <_IO_stdin_used+0x183>
    90ec:	48 89 df             	mov    %rbx,%rdi
    90ef:	e8 7c af ff ff       	call   4070 <buf_put>
    90f4:	eb aa                	jmp    90a0 <fwp_write+0xbe0>
    90f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90fd:	00 00 00 
    9100:	ba 02 00 00 00       	mov    $0x2,%edx
    9105:	48 8d 35 6b 60 00 00 	lea    0x606b(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    910c:	48 89 df             	mov    %rbx,%rdi
    910f:	e8 5c af ff ff       	call   4070 <buf_put>
    9114:	eb 8a                	jmp    90a0 <fwp_write+0xbe0>
    9116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    911d:	00 00 00 
    9120:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9124:	0f 86 2e 01 00 00    	jbe    9258 <fwp_write+0xd98>
    912a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    912e:	0f 84 24 01 00 00    	je     9258 <fwp_write+0xd98>
    9134:	ba 01 00 00 00       	mov    $0x1,%edx
    9139:	4c 89 fe             	mov    %r15,%rsi
    913c:	48 89 df             	mov    %rbx,%rdi
    913f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9144:	e8 27 af ff ff       	call   4070 <buf_put>
    9149:	e9 52 ff ff ff       	jmp    90a0 <fwp_write+0xbe0>
    914e:	66 90                	xchg   %ax,%ax
    9150:	ba 02 00 00 00       	mov    $0x2,%edx
    9155:	48 8d 35 24 60 00 00 	lea    0x6024(%rip),%rsi        # f180 <_IO_stdin_used+0x180>
    915c:	48 89 df             	mov    %rbx,%rdi
    915f:	e8 0c af ff ff       	call   4070 <buf_put>
    9164:	e9 37 ff ff ff       	jmp    90a0 <fwp_write+0xbe0>
    9169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9170:	ba 01 00 00 00       	mov    $0x1,%edx
    9175:	4c 89 fe             	mov    %r15,%rsi
    9178:	48 89 df             	mov    %rbx,%rdi
    917b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9180:	e8 eb ae ff ff       	call   4070 <buf_put>
    9185:	e9 cc f3 ff ff       	jmp    8556 <fwp_write+0x96>
    918a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9190:	83 f8 04             	cmp    $0x4,%eax
    9193:	0f 85 bb fb ff ff    	jne    8d54 <fwp_write+0x894>
    9199:	48 8b 04 24          	mov    (%rsp),%rax
    919d:	48 8b 40 08          	mov    0x8(%rax),%rax
    91a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    91a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    91aa:	e9 96 fc ff ff       	jmp    8e45 <fwp_write+0x985>
    91af:	90                   	nop
    91b0:	8b 0c 24             	mov    (%rsp),%ecx
    91b3:	31 c0                	xor    %eax,%eax
    91b5:	85 c9                	test   %ecx,%ecx
    91b7:	0f 98 c0             	sets   %al
    91ba:	e9 86 fc ff ff       	jmp    8e45 <fwp_write+0x985>
    91bf:	90                   	nop
    91c0:	48 f7 d8             	neg    %rax
    91c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    91ca:	00 
    91cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    91d2:	2d 
    91d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    91da:	00 
    91db:	48 83 d2 00          	adc    $0x0,%rdx
    91df:	48 89 c6             	mov    %rax,%rsi
    91e2:	48 f7 da             	neg    %rdx
    91e5:	e8 56 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    91ea:	e9 51 f3 ff ff       	jmp    8540 <fwp_write+0x80>
    91ef:	90                   	nop
    91f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    91f5:	e9 c3 f5 ff ff       	jmp    87bd <fwp_write+0x2fd>
    91fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9200:	4c 89 e9             	mov    %r13,%rcx
    9203:	48 c1 e1 04          	shl    $0x4,%rcx
    9207:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    920c:	48 85 ff             	test   %rdi,%rdi
    920f:	0f 89 eb f9 ff ff    	jns    8c00 <fwp_write+0x740>
    9215:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9219:	48 89 ce             	mov    %rcx,%rsi
    921c:	e9 df f9 ff ff       	jmp    8c00 <fwp_write+0x740>
    9221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9228:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    922f:	00 
    9230:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9234:	e9 20 fa ff ff       	jmp    8c59 <fwp_write+0x799>
    9239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9240:	ba 02 00 00 00       	mov    $0x2,%edx
    9245:	48 8d 35 f6 5e 00 00 	lea    0x5ef6(%rip),%rsi        # f142 <_IO_stdin_used+0x142>
    924c:	e9 2d f7 ff ff       	jmp    897e <fwp_write+0x4be>
    9251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9258:	4c 8d 05 27 5f 00 00 	lea    0x5f27(%rip),%r8        # f186 <_IO_stdin_used+0x186>
    925f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9264:	31 c0                	xor    %eax,%eax
    9266:	ba 02 00 00 00       	mov    $0x2,%edx
    926b:	be 10 00 00 00       	mov    $0x10,%esi
    9270:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9277:	00 
    9278:	e8 33 a1 ff ff       	call   33b0 <__snprintf_chk@plt>
    927d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9284:	00 
    9285:	e8 c6 a1 ff ff       	call   3450 <strlen@plt>
    928a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9291:	00 
    9292:	48 89 df             	mov    %rbx,%rdi
    9295:	48 89 c2             	mov    %rax,%rdx
    9298:	e8 d3 ad ff ff       	call   4070 <buf_put>
    929d:	e9 fe fd ff ff       	jmp    90a0 <fwp_write+0xbe0>
    92a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    92ac:	48 8d 35 89 5e 00 00 	lea    0x5e89(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    92b3:	48 8d 05 81 5e 00 00 	lea    0x5e81(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    92ba:	4c 89 e7             	mov    %r12,%rdi
    92bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    92c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    92c5:	e8 26 a1 ff ff       	call   33f0 <strcpy@plt>
    92ca:	e9 71 f2 ff ff       	jmp    8540 <fwp_write+0x80>
    92cf:	90                   	nop
    92d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    92d4:	48 8d 35 61 5e 00 00 	lea    0x5e61(%rip),%rsi        # f13c <_IO_stdin_used+0x13c>
    92db:	48 8d 05 59 5e 00 00 	lea    0x5e59(%rip),%rax        # f13b <_IO_stdin_used+0x13b>
    92e2:	0f 2f c8             	comiss %xmm0,%xmm1
    92e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92ec:	00 
    92ed:	4c 89 e7             	mov    %r12,%rdi
    92f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    92f4:	e8 f7 a0 ff ff       	call   33f0 <strcpy@plt>
    92f9:	e9 42 f2 ff ff       	jmp    8540 <fwp_write+0x80>
    92fe:	66 90                	xchg   %ax,%ax
    9300:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9305:	45 85 c0             	test   %r8d,%r8d
    9308:	75 34                	jne    933e <fwp_write+0xe7e>
    930a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9311:	00 
    9312:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9319:	00 00 
    931b:	0f 85 74 f6 ff ff    	jne    8995 <fwp_write+0x4d5>
    9321:	ba 02 00 00 00       	mov    $0x2,%edx
    9326:	48 8d 35 8a 5e 00 00 	lea    0x5e8a(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    932d:	e9 a1 f3 ff ff       	jmp    86d3 <fwp_write+0x213>
    9332:	48 03 75 10          	add    0x10(%rbp),%rsi
    9336:	49 89 f0             	mov    %rsi,%r8
    9339:	e9 e5 fc ff ff       	jmp    9023 <fwp_write+0xb63>
    933e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9343:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9348:	85 ff                	test   %edi,%edi
    934a:	0f 84 fa f3 ff ff    	je     874a <fwp_write+0x28a>
    9350:	ba 01 00 00 00       	mov    $0x1,%edx
    9355:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    935a:	48 89 df             	mov    %rbx,%rdi
    935d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9362:	e8 09 ad ff ff       	call   4070 <buf_put>
    9367:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    936c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9371:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9377:	85 c0                	test   %eax,%eax
    9379:	0f 8f f0 f3 ff ff    	jg     876f <fwp_write+0x2af>
    937f:	e9 34 f4 ff ff       	jmp    87b8 <fwp_write+0x2f8>
    9384:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9388:	49 89 c5             	mov    %rax,%r13
    938b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9390:	49 89 c4             	mov    %rax,%r12
    9393:	49 c1 fd 3f          	sar    $0x3f,%r13
    9397:	4c 09 e8             	or     %r13,%rax
    939a:	0f 84 a7 00 00 00    	je     9447 <fwp_write+0xf87>
    93a0:	48 8d 2d 19 7f 00 00 	lea    0x7f19(%rip),%rbp        # 112c0 <units.0>
    93a7:	4d 89 e7             	mov    %r12,%r15
    93aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    93ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    93b3:	4c 89 ff             	mov    %r15,%rdi
    93b6:	4c 89 ee             	mov    %r13,%rsi
    93b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    93bd:	48 99                	cqto
    93bf:	48 89 d1             	mov    %rdx,%rcx
    93c2:	48 89 c2             	mov    %rax,%rdx
    93c5:	e8 26 4e 00 00       	call   e1f0 <__divmodti4>
    93ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    93ce:	48 89 c1             	mov    %rax,%rcx
    93d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    93d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    93db:	0f 84 94 00 00 00    	je     9475 <fwp_write+0xfb5>
    93e1:	41 83 c1 01          	add    $0x1,%r9d
    93e5:	48 83 c5 10          	add    $0x10,%rbp
    93e9:	41 83 f9 05          	cmp    $0x5,%r9d
    93ed:	75 bb                	jne    93aa <fwp_write+0xeea>
    93ef:	4d 85 ed             	test   %r13,%r13
    93f2:	79 53                	jns    9447 <fwp_write+0xf87>
    93f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    93f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    93fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9403:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9408:	48 99                	cqto
    940a:	48 f7 d8             	neg    %rax
    940d:	48 83 d2 00          	adc    $0x0,%rdx
    9411:	48 89 c6             	mov    %rax,%rsi
    9414:	48 f7 da             	neg    %rdx
    9417:	e8 24 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    941c:	49 89 e8             	mov    %rbp,%r8
    941f:	ba 00 02 00 00       	mov    $0x200,%edx
    9424:	be 02 00 00 00       	mov    $0x2,%esi
    9429:	31 c0                	xor    %eax,%eax
    942b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9432:	00 
    9433:	48 8d 0d 78 5d 00 00 	lea    0x5d78(%rip),%rcx        # f1b2 <_IO_stdin_used+0x1b2>
    943a:	4c 89 e7             	mov    %r12,%rdi
    943d:	e8 9e a2 ff ff       	call   36e0 <__sprintf_chk@plt>
    9442:	e9 f9 f0 ff ff       	jmp    8540 <fwp_write+0x80>
    9447:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    944c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9451:	31 d2                	xor    %edx,%edx
    9453:	48 89 ef             	mov    %rbp,%rdi
    9456:	e8 e5 a5 ff ff       	call   3a40 <fwp_fmt_u128>
    945b:	eb bf                	jmp    941c <fwp_write+0xf5c>
    945d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9464:	4e 61 4e 00 
    9468:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    946f:	00 
    9470:	e9 cb f0 ff ff       	jmp    8540 <fwp_write+0x80>
    9475:	44 89 0c 24          	mov    %r9d,(%rsp)
    9479:	48 89 c8             	mov    %rcx,%rax
    947c:	48 85 d2             	test   %rdx,%rdx
    947f:	78 51                	js     94d2 <fwp_write+0x1012>
    9481:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9486:	48 89 c6             	mov    %rax,%rsi
    9489:	48 89 ef             	mov    %rbp,%rdi
    948c:	e8 af a5 ff ff       	call   3a40 <fwp_fmt_u128>
    9491:	44 8b 0c 24          	mov    (%rsp),%r9d
    9495:	49 63 c1             	movslq %r9d,%rax
    9498:	49 89 e8             	mov    %rbp,%r8
    949b:	ba 00 02 00 00       	mov    $0x200,%edx
    94a0:	be 02 00 00 00       	mov    $0x2,%esi
    94a5:	48 c1 e0 04          	shl    $0x4,%rax
    94a9:	48 8d 3d 10 7e 00 00 	lea    0x7e10(%rip),%rdi        # 112c0 <units.0>
    94b0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    94b7:	00 
    94b8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    94bc:	48 8d 0d ea 5c 00 00 	lea    0x5cea(%rip),%rcx        # f1ad <_IO_stdin_used+0x1ad>
    94c3:	4c 89 e7             	mov    %r12,%rdi
    94c6:	31 c0                	xor    %eax,%eax
    94c8:	e8 13 a2 ff ff       	call   36e0 <__sprintf_chk@plt>
    94cd:	e9 6e f0 ff ff       	jmp    8540 <fwp_write+0x80>
    94d2:	48 f7 d8             	neg    %rax
    94d5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    94da:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    94df:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    94e4:	48 83 d2 00          	adc    $0x0,%rdx
    94e8:	48 89 c6             	mov    %rax,%rsi
    94eb:	48 f7 da             	neg    %rdx
    94ee:	e8 4d a5 ff ff       	call   3a40 <fwp_fmt_u128>
    94f3:	44 8b 0c 24          	mov    (%rsp),%r9d
    94f7:	eb 9c                	jmp    9495 <fwp_write+0xfd5>
    94f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009500 <fwp_hof0.constprop.0>:
    9500:	41 57                	push   %r15
    9502:	41 56                	push   %r14
    9504:	41 55                	push   %r13
    9506:	41 54                	push   %r12
    9508:	55                   	push   %rbp
    9509:	53                   	push   %rbx
    950a:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9511:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9518:	00 00 
    951a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9521:	00 
    9522:	31 c0                	xor    %eax,%eax
    9524:	48 85 f6             	test   %rsi,%rsi
    9527:	0f 84 ea 0e 00 00    	je     a417 <fwp_hof0.constprop.0+0xf17>
    952d:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
    9532:	48 8d 1d 27 a2 01 00 	lea    0x1a227(%rip),%rbx        # 23760 <fwp_heap>
    9539:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    953e:	66 90                	xchg   %ax,%ax
    9540:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9547:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    954c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9553:	48 c1 e2 10          	shl    $0x10,%rdx
    9557:	48 39 d0             	cmp    %rdx,%rax
    955a:	73 5d                	jae    95b9 <fwp_hof0.constprop.0+0xb9>
    955c:	48 89 c2             	mov    %rax,%rdx
    955f:	48 c1 ea 10          	shr    $0x10,%rdx
    9563:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9567:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    956e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9572:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9576:	48 85 ff             	test   %rdi,%rdi
    9579:	74 3e                	je     95b9 <fwp_hof0.constprop.0+0xb9>
    957b:	0f b6 0a             	movzbl (%rdx),%ecx
    957e:	80 f9 02             	cmp    $0x2,%cl
    9581:	0f 84 09 15 00 00    	je     aa90 <fwp_hof0.constprop.0+0x1590>
    9587:	80 f9 01             	cmp    $0x1,%cl
    958a:	75 2d                	jne    95b9 <fwp_hof0.constprop.0+0xb9>
    958c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    958f:	0f b7 c0             	movzwl %ax,%eax
    9592:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9595:	48 0f af c1          	imul   %rcx,%rax
    9599:	48 c1 e8 20          	shr    $0x20,%rax
    959d:	48 39 d0             	cmp    %rdx,%rax
    95a0:	73 17                	jae    95b9 <fwp_hof0.constprop.0+0xb9>
    95a2:	48 01 c7             	add    %rax,%rdi
    95a5:	0f b6 07             	movzbl (%rdi),%eax
    95a8:	84 c0                	test   %al,%al
    95aa:	74 0d                	je     95b9 <fwp_hof0.constprop.0+0xb9>
    95ac:	3c fd                	cmp    $0xfd,%al
    95ae:	0f 87 e8 16 00 00    	ja     ac9c <fwp_hof0.constprop.0+0x179c>
    95b4:	83 c0 01             	add    $0x1,%eax
    95b7:	88 07                	mov    %al,(%rdi)
    95b9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    95be:	45 31 c0             	xor    %r8d,%r8d
    95c1:	48 c7 44 24 20 c6 00 	movq   $0xc6,0x20(%rsp)
    95c8:	00 00 
    95ca:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    95cf:	4d 89 c7             	mov    %r8,%r15
    95d2:	4d 85 c0             	test   %r8,%r8
    95d5:	0f 85 75 a1 ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    95db:	48 8b 05 16 be 01 00 	mov    0x1be16(%rip),%rax        # 253f8 <fwp_cleanups>
    95e2:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    95e9:	4c 8d 35 10 d8 ff ff 	lea    -0x27f0(%rip),%r14        # 6e00 <fwp_tape_scope_release>
    95f0:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    95f7:	ff 
    95f8:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
    95ff:	00 
    9600:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9607:	00 
    9608:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    960d:	48 c1 e2 10          	shl    $0x10,%rdx
    9611:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9616:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    961d:	00 
    961e:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9625:	00 
    9626:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    962b:	48 89 05 c6 bd 01 00 	mov    %rax,0x1bdc6(%rip)        # 253f8 <fwp_cleanups>
    9632:	48 8d 05 d7 99 00 00 	lea    0x99d7(%rip),%rax        # 13010 <fc37>
    9639:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9640:	48 39 d0             	cmp    %rdx,%rax
    9643:	73 5d                	jae    96a2 <fwp_hof0.constprop.0+0x1a2>
    9645:	48 89 c2             	mov    %rax,%rdx
    9648:	48 c1 ea 10          	shr    $0x10,%rdx
    964c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9650:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9657:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    965b:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    965f:	48 85 ff             	test   %rdi,%rdi
    9662:	74 3e                	je     96a2 <fwp_hof0.constprop.0+0x1a2>
    9664:	0f b6 0a             	movzbl (%rdx),%ecx
    9667:	80 f9 02             	cmp    $0x2,%cl
    966a:	0f 84 90 12 00 00    	je     a900 <fwp_hof0.constprop.0+0x1400>
    9670:	80 f9 01             	cmp    $0x1,%cl
    9673:	75 2d                	jne    96a2 <fwp_hof0.constprop.0+0x1a2>
    9675:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9678:	0f b7 c0             	movzwl %ax,%eax
    967b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    967e:	48 0f af c1          	imul   %rcx,%rax
    9682:	48 c1 e8 20          	shr    $0x20,%rax
    9686:	48 39 d0             	cmp    %rdx,%rax
    9689:	73 17                	jae    96a2 <fwp_hof0.constprop.0+0x1a2>
    968b:	48 01 c7             	add    %rax,%rdi
    968e:	0f b6 07             	movzbl (%rdi),%eax
    9691:	84 c0                	test   %al,%al
    9693:	74 0d                	je     96a2 <fwp_hof0.constprop.0+0x1a2>
    9695:	3c fd                	cmp    $0xfd,%al
    9697:	0f 87 3f 15 00 00    	ja     abdc <fwp_hof0.constprop.0+0x16dc>
    969d:	83 c0 01             	add    $0x1,%eax
    96a0:	88 07                	mov    %al,(%rdi)
    96a2:	48 8d 3d 67 99 00 00 	lea    0x9967(%rip),%rdi        # 13010 <fc37>
    96a9:	e8 22 d4 ff ff       	call   6ad0 <fwp_closure_drop>
    96ae:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    96b3:	48 85 c0             	test   %rax,%rax
    96b6:	0f 84 35 14 00 00    	je     aaf1 <fwp_hof0.constprop.0+0x15f1>
    96bc:	31 d2                	xor    %edx,%edx
    96be:	66 90                	xchg   %ax,%ax
    96c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    96c4:	48 83 c2 01          	add    $0x1,%rdx
    96c8:	48 85 c0             	test   %rax,%rax
    96cb:	75 f3                	jne    96c0 <fwp_hof0.constprop.0+0x1c0>
    96cd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    96d4:	0f 87 00 16 00 00    	ja     acda <fwp_hof0.constprop.0+0x17da>
    96da:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    96df:	8b 35 7b 99 00 00    	mov    0x997b(%rip),%esi        # 13060 <registered_finish.1>
    96e5:	85 f6                	test   %esi,%esi
    96e7:	0f 84 d3 11 00 00    	je     a8c0 <fwp_hof0.constprop.0+0x13c0>
    96ed:	4c 8b 2d e4 99 01 00 	mov    0x199e4(%rip),%r13        # 230d8 <fwp_tape_next_slot>
    96f4:	4c 8b 25 ed 99 01 00 	mov    0x199ed(%rip),%r12        # 230e8 <fwp_ntapes>
    96fb:	4d 39 ec             	cmp    %r13,%r12
    96fe:	0f 8e ec 0d 00 00    	jle    a4f0 <fwp_hof0.constprop.0+0xff0>
    9704:	49 6b c5 68          	imul   $0x68,%r13,%rax
    9708:	48 03 05 e1 99 01 00 	add    0x199e1(%rip),%rax        # 230f0 <fwp_tapes>
    970f:	90                   	nop
    9710:	8b 48 04             	mov    0x4(%rax),%ecx
    9713:	85 c9                	test   %ecx,%ecx
    9715:	75 0c                	jne    9723 <fwp_hof0.constprop.0+0x223>
    9717:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    971d:	0f 86 cd 0d 00 00    	jbe    a4f0 <fwp_hof0.constprop.0+0xff0>
    9723:	49 83 c5 01          	add    $0x1,%r13
    9727:	48 83 c0 68          	add    $0x68,%rax
    972b:	4d 39 ec             	cmp    %r13,%r12
    972e:	75 e0                	jne    9710 <fwp_hof0.constprop.0+0x210>
    9730:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    9737:	0f 8f 1f 16 00 00    	jg     ad5c <fwp_hof0.constprop.0+0x185c>
    973d:	4c 39 25 9c 99 01 00 	cmp    %r12,0x1999c(%rip)        # 230e0 <fwp_tapes_cap>
    9744:	48 8b 2d a5 99 01 00 	mov    0x199a5(%rip),%rbp        # 230f0 <fwp_tapes>
    974b:	75 49                	jne    9796 <fwp_hof0.constprop.0+0x296>
    974d:	4d 85 e4             	test   %r12,%r12
    9750:	0f 84 00 14 00 00    	je     ab56 <fwp_hof0.constprop.0+0x1656>
    9756:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    975a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    975f:	49 39 c5             	cmp    %rax,%r13
    9762:	4c 0f 4f e8          	cmovg  %rax,%r13
    9766:	49 6b f5 68          	imul   $0x68,%r13,%rsi
    976a:	48 89 ef             	mov    %rbp,%rdi
    976d:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9772:	e8 59 9e ff ff       	call   35d0 <realloc@plt>
    9777:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    977c:	48 85 c0             	test   %rax,%rax
    977f:	48 89 c5             	mov    %rax,%rbp
    9782:	0f 84 e0 15 00 00    	je     ad68 <fwp_hof0.constprop.0+0x1868>
    9788:	48 89 05 61 99 01 00 	mov    %rax,0x19961(%rip)        # 230f0 <fwp_tapes>
    978f:	4c 89 2d 4a 99 01 00 	mov    %r13,0x1994a(%rip)        # 230e0 <fwp_tapes_cap>
    9796:	49 6b cc 68          	imul   $0x68,%r12,%rcx
    979a:	31 c0                	xor    %eax,%eax
    979c:	4d 89 e5             	mov    %r12,%r13
    979f:	48 01 e9             	add    %rbp,%rcx
    97a2:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    97a6:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    97ad:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    97b1:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    97b8:	00 
    97b9:	48 29 f9             	sub    %rdi,%rcx
    97bc:	83 c1 68             	add    $0x68,%ecx
    97bf:	c1 e9 03             	shr    $0x3,%ecx
    97c2:	f3 48 ab             	rep stos %rax,(%rdi)
    97c5:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    97ca:	48 89 05 17 99 01 00 	mov    %rax,0x19917(%rip)        # 230e8 <fwp_ntapes>
    97d1:	4d 6b e5 68          	imul   $0x68,%r13,%r12
    97d5:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    97d9:	48 8d 3d df 58 00 00 	lea    0x58df(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    97e0:	0f 29 04 24          	movaps %xmm0,(%rsp)
    97e4:	49 01 ec             	add    %rbp,%r12
    97e7:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    97ee:	00 00 
    97f0:	e8 ab 9b ff ff       	call   33a0 <getenv@plt>
    97f5:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    97fa:	48 85 c0             	test   %rax,%rax
    97fd:	0f 84 05 0d 00 00    	je     a508 <fwp_hof0.constprop.0+0x1008>
    9803:	80 38 30             	cmpb   $0x30,(%rax)
    9806:	0f 85 fc 0c 00 00    	jne    a508 <fwp_hof0.constprop.0+0x1008>
    980c:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9810:	0f 85 f2 0c 00 00    	jne    a508 <fwp_hof0.constprop.0+0x1008>
    9816:	41 8b 04 24          	mov    (%r12),%eax
    981a:	49 8d 75 01          	lea    0x1(%r13),%rsi
    981e:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    9825:	00 00 
    9827:	48 89 35 aa 98 01 00 	mov    %rsi,0x198aa(%rip)        # 230d8 <fwp_tape_next_slot>
    982e:	8d 48 01             	lea    0x1(%rax),%ecx
    9831:	48 8b 05 68 62 00 00 	mov    0x6268(%rip),%rax        # faa0 <msg.4+0x20>
    9838:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    983f:	00 00 
    9841:	41 89 0c 24          	mov    %ecx,(%r12)
    9845:	49 89 44 24 58       	mov    %rax,0x58(%r12)
    984a:	48 8b 05 a7 bb 01 00 	mov    0x1bba7(%rip),%rax        # 253f8 <fwp_cleanups>
    9851:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    9857:	48 85 c0             	test   %rax,%rax
    985a:	75 20                	jne    987c <fwp_hof0.constprop.0+0x37c>
    985c:	e9 9f 14 00 00       	jmp    ad00 <fwp_hof0.constprop.0+0x1800>
    9861:	0f 1f 40 00          	nopl   0x0(%rax)
    9865:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    986c:	00 00 00 00 
    9870:	48 8b 00             	mov    (%rax),%rax
    9873:	48 85 c0             	test   %rax,%rax
    9876:	0f 84 84 14 00 00    	je     ad00 <fwp_hof0.constprop.0+0x1800>
    987c:	4c 39 70 08          	cmp    %r14,0x8(%rax)
    9880:	75 ee                	jne    9870 <fwp_hof0.constprop.0+0x370>
    9882:	4c 8b 48 10          	mov    0x10(%rax),%r9
    9886:	44 89 ef             	mov    %r13d,%edi
    9889:	49 63 01             	movslq (%r9),%rax
    988c:	4d 89 4c 24 50       	mov    %r9,0x50(%r12)
    9891:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    9896:	85 c0                	test   %eax,%eax
    9898:	78 09                	js     98a3 <fwp_hof0.constprop.0+0x3a3>
    989a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    989e:	44 89 6c 05 58       	mov    %r13d,0x58(%rbp,%rax,1)
    98a3:	41 89 39             	mov    %edi,(%r9)
    98a6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    98ab:	45 31 e4             	xor    %r12d,%r12d
    98ae:	48 89 f8             	mov    %rdi,%rax
    98b1:	48 85 ff             	test   %rdi,%rdi
    98b4:	0f 84 b6 0d 00 00    	je     a670 <fwp_hof0.constprop.0+0x1170>
    98ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98c0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98c4:	49 83 c4 01          	add    $0x1,%r12
    98c8:	48 85 c0             	test   %rax,%rax
    98cb:	75 f3                	jne    98c0 <fwp_hof0.constprop.0+0x3c0>
    98cd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    98d2:	0f 1f 00             	nopl   (%rax)
    98d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98dc:	00 00 00 00 
    98e0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    98e4:	48 83 c0 01          	add    $0x1,%rax
    98e8:	48 85 d2             	test   %rdx,%rdx
    98eb:	75 f3                	jne    98e0 <fwp_hof0.constprop.0+0x3e0>
    98ed:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    98f4:	ff ff 1f 
    98f7:	48 39 c2             	cmp    %rax,%rdx
    98fa:	0f 82 f2 13 00 00    	jb     acf2 <fwp_hof0.constprop.0+0x17f2>
    9900:	4d 85 e4             	test   %r12,%r12
    9903:	0f 8e 67 0d 00 00    	jle    a670 <fwp_hof0.constprop.0+0x1170>
    9909:	49 39 c4             	cmp    %rax,%r12
    990c:	4c 0f 47 e0          	cmova  %rax,%r12
    9910:	4c 89 e0             	mov    %r12,%rax
    9913:	48 c1 e8 3c          	shr    $0x3c,%rax
    9917:	0f 85 d5 13 00 00    	jne    acf2 <fwp_hof0.constprop.0+0x17f2>
    991d:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    9921:	48 c1 e1 10          	shl    $0x10,%rcx
    9925:	48 09 f1             	or     %rsi,%rcx
    9928:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    992f:	00 
    9930:	be 02 00 00 00       	mov    $0x2,%esi
    9935:	48 89 0c 24          	mov    %rcx,(%rsp)
    9939:	e8 12 c1 ff ff       	call   5a50 <fwp_heap_alloc>
    993e:	4c 89 30             	mov    %r14,(%rax)
    9941:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9948:	49 89 c5             	mov    %rax,%r13
    994b:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9952:	48 c1 e2 10          	shl    $0x10,%rdx
    9956:	48 39 d0             	cmp    %rdx,%rax
    9959:	0f 83 f1 10 00 00    	jae    aa50 <fwp_hof0.constprop.0+0x1550>
    995f:	48 89 c2             	mov    %rax,%rdx
    9962:	48 c1 ea 10          	shr    $0x10,%rdx
    9966:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    996a:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9971:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9975:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9979:	4d 85 f6             	test   %r14,%r14
    997c:	74 38                	je     99b6 <fwp_hof0.constprop.0+0x4b6>
    997e:	0f b6 0a             	movzbl (%rdx),%ecx
    9981:	80 f9 02             	cmp    $0x2,%cl
    9984:	0f 84 57 0d 00 00    	je     a6e1 <fwp_hof0.constprop.0+0x11e1>
    998a:	80 f9 01             	cmp    $0x1,%cl
    998d:	75 27                	jne    99b6 <fwp_hof0.constprop.0+0x4b6>
    998f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9992:	0f b7 c0             	movzwl %ax,%eax
    9995:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9998:	48 0f af c1          	imul   %rcx,%rax
    999c:	48 c1 e8 20          	shr    $0x20,%rax
    99a0:	48 39 d0             	cmp    %rdx,%rax
    99a3:	73 11                	jae    99b6 <fwp_hof0.constprop.0+0x4b6>
    99a5:	49 01 c6             	add    %rax,%r14
    99a8:	41 80 3e ff          	cmpb   $0xff,(%r14)
    99ac:	0f 84 42 0d 00 00    	je     a6f4 <fwp_hof0.constprop.0+0x11f4>
    99b2:	41 c6 06 01          	movb   $0x1,(%r14)
    99b6:	4d 85 e4             	test   %r12,%r12
    99b9:	74 79                	je     9a34 <fwp_hof0.constprop.0+0x534>
    99bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    99bf:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    99c4:	31 c0                	xor    %eax,%eax
    99c6:	48 c1 e1 20          	shl    $0x20,%rcx
    99ca:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99d1:	00 00 00 
    99d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99db:	00 00 00 00 
    99df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99e6:	00 00 00 00 
    99ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99f1:	00 00 00 00 
    99f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99fc:	00 00 00 00 
    9a00:	48 89 c6             	mov    %rax,%rsi
    9a03:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9a08:	48 01 ce             	add    %rcx,%rsi
    9a0b:	0f 80 3f 9d ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9a11:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    9a16:	48 89 c6             	mov    %rax,%rsi
    9a19:	48 83 c0 01          	add    $0x1,%rax
    9a1d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9a21:	48 c1 e6 04          	shl    $0x4,%rsi
    9a25:	41 0f 11 44 35 08    	movups %xmm0,0x8(%r13,%rsi,1)
    9a2b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9a2f:	4c 39 e0             	cmp    %r12,%rax
    9a32:	72 cc                	jb     9a00 <fwp_hof0.constprop.0+0x500>
    9a34:	49 8b 45 00          	mov    0x0(%r13),%rax
    9a38:	48 d1 e8             	shr    $1,%rax
    9a3b:	0f 85 df 0c 00 00    	jne    a720 <fwp_hof0.constprop.0+0x1220>
    9a41:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
    9a48:	00 
    9a49:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    9a50:	4c 89 ef             	mov    %r13,%rdi
    9a53:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    9a58:	e8 d3 e2 ff ff       	call   7d30 <fwp_drop10>
    9a5d:	4c 63 24 24          	movslq (%rsp),%r12
    9a61:	4c 89 e7             	mov    %r12,%rdi
    9a64:	e8 17 aa ff ff       	call   4480 <fwp_tape_of>
    9a69:	48 89 c6             	mov    %rax,%rsi
    9a6c:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9a71:	0f 85 1f 13 00 00    	jne    ad96 <fwp_hof0.constprop.0+0x1896>
    9a77:	48 89 c7             	mov    %rax,%rdi
    9a7a:	e8 81 a1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9a7f:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    9a83:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    9a87:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9a8e:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9a93:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9a99:	66 49 0f 6e fe       	movq   %r14,%xmm7
    9a9e:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9aa2:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    9aa7:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9aac:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    9ab0:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9ab4:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9ab9:	77 19                	ja     9ad4 <fwp_hof0.constprop.0+0x5d4>
    9abb:	0f b7 04 24          	movzwl (%rsp),%eax
    9abf:	83 e8 01             	sub    $0x1,%eax
    9ac2:	48 98                	cltq
    9ac4:	48 3b 05 0d 96 01 00 	cmp    0x1960d(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9acb:	7d 07                	jge    9ad4 <fwp_hof0.constprop.0+0x5d4>
    9acd:	48 89 05 04 96 01 00 	mov    %rax,0x19604(%rip)        # 230d8 <fwp_tape_next_slot>
    9ad4:	48 8b 05 1d b9 01 00 	mov    0x1b91d(%rip),%rax        # 253f8 <fwp_cleanups>
    9adb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9adf:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9ae6:	00 
    9ae7:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9aeb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9af2:	00 
    9af3:	48 8d 05 36 b3 ff ff 	lea    -0x4cca(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    9afa:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9b01:	00 
    9b02:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    9b09:	00 
    9b0a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9b0f:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9b16:	00 
    9b17:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9b1e:	00 
    9b1f:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9b26:	00 
    9b27:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9b2e:	00 
    9b2f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9b33:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9b37:	48 89 05 ba b8 01 00 	mov    %rax,0x1b8ba(%rip)        # 253f8 <fwp_cleanups>
    9b3e:	4c 89 8c 24 e0 00 00 	mov    %r9,0xe0(%rsp)
    9b45:	00 
    9b46:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    9b4d:	00 
    9b4e:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    9b55:	00 
    9b56:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    9b5d:	00 
    9b5e:	48 85 c9             	test   %rcx,%rcx
    9b61:	0f 88 a9 0d 00 00    	js     a910 <fwp_hof0.constprop.0+0x1410>
    9b67:	48 89 c8             	mov    %rcx,%rax
    9b6a:	48 c1 f8 20          	sar    $0x20,%rax
    9b6e:	49 39 c4             	cmp    %rax,%r12
    9b71:	0f 85 37 11 00 00    	jne    acae <fwp_hof0.constprop.0+0x17ae>
    9b77:	41 89 cd             	mov    %ecx,%r13d
    9b7a:	4d 89 ec             	mov    %r13,%r12
    9b7d:	4c 39 ea             	cmp    %r13,%rdx
    9b80:	0f 8e 34 11 00 00    	jle    acba <fwp_hof0.constprop.0+0x17ba>
    9b86:	4c 39 ed             	cmp    %r13,%rbp
    9b89:	0f 8e 41 0c 00 00    	jle    a7d0 <fwp_hof0.constprop.0+0x12d0>
    9b8f:	4c 39 f5             	cmp    %r14,%rbp
    9b92:	0f 8f 78 0c 00 00    	jg     a810 <fwp_hof0.constprop.0+0x1310>
    9b98:	4d 85 c9             	test   %r9,%r9
    9b9b:	0f 84 74 11 00 00    	je     ad15 <fwp_hof0.constprop.0+0x1815>
    9ba1:	4c 89 cf             	mov    %r9,%rdi
    9ba4:	31 f6                	xor    %esi,%esi
    9ba6:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9bab:	4c 8d 65 ff          	lea    -0x1(%rbp),%r12
    9baf:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    9bb6:	00 
    9bb7:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9bbb:	e8 00 99 ff ff       	call   34c0 <memset@plt>
    9bc0:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    9bc5:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    9bcb:	49 89 c1             	mov    %rax,%r9
    9bce:	f2 0f 10 05 d2 5e 00 	movsd  0x5ed2(%rip),%xmm0        # faa8 <msg.4+0x28>
    9bd5:	00 
    9bd6:	f2 43 0f 58 04 e9    	addsd  (%r9,%r13,8),%xmm0
    9bdc:	f2 43 0f 11 04 e9    	movsd  %xmm0,(%r9,%r13,8)
    9be2:	4c 39 e5             	cmp    %r12,%rbp
    9be5:	0f 8f 8e 00 00 00    	jg     9c79 <fwp_hof0.constprop.0+0x779>
    9beb:	0f 12 fb             	movhlps %xmm3,%xmm7
    9bee:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    9bf3:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9bf8:	49 29 ec             	sub    %rbp,%r12
    9bfb:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    9c00:	0f 12 fa             	movhlps %xmm2,%xmm7
    9c03:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9c07:	66 49 0f 7e fb       	movq   %xmm7,%r11
    9c0c:	4a 8d 04 a6          	lea    (%rsi,%r12,4),%rax
    9c10:	48 29 f1             	sub    %rsi,%rcx
    9c13:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    9c17:	4d 8d 24 e9          	lea    (%r9,%rbp,8),%r12
    9c1b:	4c 29 df             	sub    %r11,%rdi
    9c1e:	4d 29 dc             	sub    %r11,%r12
    9c21:	eb 09                	jmp    9c2c <fwp_hof0.constprop.0+0x72c>
    9c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c28:	48 83 e8 04          	sub    $0x4,%rax
    9c2c:	f2 41 0f 10 04 14    	movsd  (%r12,%rdx,1),%xmm0
    9c32:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9c36:	7a 02                	jp     9c3a <fwp_hof0.constprop.0+0x73a>
    9c38:	74 36                	je     9c70 <fwp_hof0.constprop.0+0x770>
    9c3a:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    9c3e:	45 85 c0             	test   %r8d,%r8d
    9c41:	78 15                	js     9c58 <fwp_hof0.constprop.0+0x758>
    9c43:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    9c48:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9c4c:	f2 43 0f 58 0c c1    	addsd  (%r9,%r8,8),%xmm1
    9c52:	f2 43 0f 11 0c c1    	movsd  %xmm1,(%r9,%r8,8)
    9c58:	4c 63 00             	movslq (%rax),%r8
    9c5b:	45 85 c0             	test   %r8d,%r8d
    9c5e:	78 10                	js     9c70 <fwp_hof0.constprop.0+0x770>
    9c60:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9c64:	f2 43 0f 58 04 c1    	addsd  (%r9,%r8,8),%xmm0
    9c6a:	f2 43 0f 11 04 c1    	movsd  %xmm0,(%r9,%r8,8)
    9c70:	48 83 ea 08          	sub    $0x8,%rdx
    9c74:	48 39 c6             	cmp    %rax,%rsi
    9c77:	75 af                	jne    9c28 <fwp_hof0.constprop.0+0x728>
    9c79:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9c80:	ff ff 1f 
    9c83:	48 39 e8             	cmp    %rbp,%rax
    9c86:	0f 82 5a 10 00 00    	jb     ace6 <fwp_hof0.constprop.0+0x17e6>
    9c8c:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9c93:	00 
    9c94:	be 02 00 00 00       	mov    $0x2,%esi
    9c99:	4c 89 0c 24          	mov    %r9,(%rsp)
    9c9d:	e8 ae bd ff ff       	call   5a50 <fwp_heap_alloc>
    9ca2:	48 85 ed             	test   %rbp,%rbp
    9ca5:	4c 8b 0c 24          	mov    (%rsp),%r9
    9ca9:	48 89 28             	mov    %rbp,(%rax)
    9cac:	49 89 c6             	mov    %rax,%r14
    9caf:	74 21                	je     9cd2 <fwp_hof0.constprop.0+0x7d2>
    9cb1:	0f 1f 40 00          	nopl   0x0(%rax)
    9cb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9cbc:	00 00 00 00 
    9cc0:	4b 8b 04 f9          	mov    (%r9,%r15,8),%rax
    9cc4:	4b 89 44 fe 08       	mov    %rax,0x8(%r14,%r15,8)
    9cc9:	49 83 c7 01          	add    $0x1,%r15
    9ccd:	4c 39 fd             	cmp    %r15,%rbp
    9cd0:	75 ee                	jne    9cc0 <fwp_hof0.constprop.0+0x7c0>
    9cd2:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
    9cd9:	00 
    9cda:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9cdf:	4c 89 2d 12 b7 01 00 	mov    %r13,0x1b712(%rip)        # 253f8 <fwp_cleanups>
    9ce6:	e8 45 b1 ff ff       	call   4e30 <fwp_tape_buffers_release>
    9ceb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9cf2:	4c 89 f0             	mov    %r14,%rax
    9cf5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9cfc:	48 c1 e2 10          	shl    $0x10,%rdx
    9d00:	48 39 d0             	cmp    %rdx,%rax
    9d03:	73 59                	jae    9d5e <fwp_hof0.constprop.0+0x85e>
    9d05:	48 89 c2             	mov    %rax,%rdx
    9d08:	48 c1 ea 10          	shr    $0x10,%rdx
    9d0c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d10:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9d17:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d1b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9d1f:	4d 85 e4             	test   %r12,%r12
    9d22:	74 3a                	je     9d5e <fwp_hof0.constprop.0+0x85e>
    9d24:	0f b6 0a             	movzbl (%rdx),%ecx
    9d27:	80 f9 02             	cmp    $0x2,%cl
    9d2a:	0f 84 10 0c 00 00    	je     a940 <fwp_hof0.constprop.0+0x1440>
    9d30:	80 f9 01             	cmp    $0x1,%cl
    9d33:	75 29                	jne    9d5e <fwp_hof0.constprop.0+0x85e>
    9d35:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d38:	0f b7 c0             	movzwl %ax,%eax
    9d3b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d3e:	48 0f af c1          	imul   %rcx,%rax
    9d42:	48 c1 e8 20          	shr    $0x20,%rax
    9d46:	48 39 d0             	cmp    %rdx,%rax
    9d49:	73 13                	jae    9d5e <fwp_hof0.constprop.0+0x85e>
    9d4b:	49 01 c4             	add    %rax,%r12
    9d4e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9d53:	0f 84 fb 0b 00 00    	je     a954 <fwp_hof0.constprop.0+0x1454>
    9d59:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9d5e:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    9d63:	0f 85 e2 99 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9d69:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9d70:	00 
    9d71:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    9d76:	48 89 05 7b b6 01 00 	mov    %rax,0x1b67b(%rip)        # 253f8 <fwp_cleanups>
    9d7d:	e8 7e d0 ff ff       	call   6e00 <fwp_tape_scope_release>
    9d82:	49 8b 06             	mov    (%r14),%rax
    9d85:	49 89 c7             	mov    %rax,%r15
    9d88:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9d8d:	48 85 c0             	test   %rax,%rax
    9d90:	0f 88 0a 08 00 00    	js     a5a0 <fwp_hof0.constprop.0+0x10a0>
    9d96:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9d9d:	4c 89 f0             	mov    %r14,%rax
    9da0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9da7:	48 c1 e2 10          	shl    $0x10,%rdx
    9dab:	48 39 d0             	cmp    %rdx,%rax
    9dae:	0f 83 ec 07 00 00    	jae    a5a0 <fwp_hof0.constprop.0+0x10a0>
    9db4:	48 89 c2             	mov    %rax,%rdx
    9db7:	48 c1 ea 10          	shr    $0x10,%rdx
    9dbb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9dbf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9dc6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9dca:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9dce:	48 85 c9             	test   %rcx,%rcx
    9dd1:	0f 84 c9 07 00 00    	je     a5a0 <fwp_hof0.constprop.0+0x10a0>
    9dd7:	0f b6 32             	movzbl (%rdx),%esi
    9dda:	40 80 fe 02          	cmp    $0x2,%sil
    9dde:	0f 84 ac 07 00 00    	je     a590 <fwp_hof0.constprop.0+0x1090>
    9de4:	40 80 fe 01          	cmp    $0x1,%sil
    9de8:	0f 85 b2 07 00 00    	jne    a5a0 <fwp_hof0.constprop.0+0x10a0>
    9dee:	8b 72 18             	mov    0x18(%rdx),%esi
    9df1:	0f b7 c0             	movzwl %ax,%eax
    9df4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9df7:	48 0f af c6          	imul   %rsi,%rax
    9dfb:	48 c1 e8 20          	shr    $0x20,%rax
    9dff:	48 39 d0             	cmp    %rdx,%rax
    9e02:	0f 83 98 07 00 00    	jae    a5a0 <fwp_hof0.constprop.0+0x10a0>
    9e08:	48 01 c1             	add    %rax,%rcx
    9e0b:	80 39 01             	cmpb   $0x1,(%rcx)
    9e0e:	0f 85 8c 07 00 00    	jne    a5a0 <fwp_hof0.constprop.0+0x10a0>
    9e14:	4c 89 34 24          	mov    %r14,(%rsp)
    9e18:	4d 89 f4             	mov    %r14,%r12
    9e1b:	31 ff                	xor    %edi,%edi
    9e1d:	48 8b 04 24          	mov    (%rsp),%rax
    9e21:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9e25:	31 c0                	xor    %eax,%eax
    9e27:	4d 85 ff             	test   %r15,%r15
    9e2a:	75 2e                	jne    9e5a <fwp_hof0.constprop.0+0x95a>
    9e2c:	eb 42                	jmp    9e70 <fwp_hof0.constprop.0+0x970>
    9e2e:	66 90                	xchg   %ax,%ax
    9e30:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9e35:	0f 88 8b 0e 00 00    	js     acc6 <fwp_hof0.constprop.0+0x17c6>
    9e3b:	f2 0f 10 05 85 5c 00 	movsd  0x5c85(%rip),%xmm0        # fac8 <msg.4+0x48>
    9e42:	00 
    9e43:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    9e48:	48 83 c0 01          	add    $0x1,%rax
    9e4c:	48 83 c2 08          	add    $0x8,%rdx
    9e50:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9e55:	49 39 c7             	cmp    %rax,%r15
    9e58:	74 16                	je     9e70 <fwp_hof0.constprop.0+0x970>
    9e5a:	49 8d 4e 08          	lea    0x8(%r14),%rcx
    9e5e:	49 83 3e 00          	cmpq   $0x0,(%r14)
    9e62:	79 cc                	jns    9e30 <fwp_hof0.constprop.0+0x930>
    9e64:	49 8b 4e 10          	mov    0x10(%r14),%rcx
    9e68:	eb c6                	jmp    9e30 <fwp_hof0.constprop.0+0x930>
    9e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9e70:	e8 bb de ff ff       	call   7d30 <fwp_drop10>
    9e75:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    9e7a:	31 d2                	xor    %edx,%edx
    9e7c:	48 89 f8             	mov    %rdi,%rax
    9e7f:	48 85 ff             	test   %rdi,%rdi
    9e82:	0f 84 72 0c 00 00    	je     aafa <fwp_hof0.constprop.0+0x15fa>
    9e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e8f:	00 
    9e90:	48 8b 40 10          	mov    0x10(%rax),%rax
    9e94:	48 83 c2 01          	add    $0x1,%rdx
    9e98:	48 85 c0             	test   %rax,%rax
    9e9b:	75 f3                	jne    9e90 <fwp_hof0.constprop.0+0x990>
    9e9d:	49 8b 04 24          	mov    (%r12),%rax
    9ea1:	49 89 c7             	mov    %rax,%r15
    9ea4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9ea9:	48 85 c0             	test   %rax,%rax
    9eac:	0f 88 ab 05 00 00    	js     a45d <fwp_hof0.constprop.0+0xf5d>
    9eb2:	48 8b 83 d8 13 00 00 	mov    0x13d8(%rbx),%rax
    9eb9:	48 8b 0c 24          	mov    (%rsp),%rcx
    9ebd:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    9ec4:	48 c1 e0 10          	shl    $0x10,%rax
    9ec8:	48 39 c1             	cmp    %rax,%rcx
    9ecb:	0f 83 8c 05 00 00    	jae    a45d <fwp_hof0.constprop.0+0xf5d>
    9ed1:	48 89 c8             	mov    %rcx,%rax
    9ed4:	48 c1 e8 10          	shr    $0x10,%rax
    9ed8:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    9edc:	48 8b 83 f8 13 00 00 	mov    0x13f8(%rbx),%rax
    9ee3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9ee7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9eeb:	48 85 ff             	test   %rdi,%rdi
    9eee:	0f 84 69 05 00 00    	je     a45d <fwp_hof0.constprop.0+0xf5d>
    9ef4:	0f b6 06             	movzbl (%rsi),%eax
    9ef7:	3c 02                	cmp    $0x2,%al
    9ef9:	0f 84 49 05 00 00    	je     a448 <fwp_hof0.constprop.0+0xf48>
    9eff:	3c 01                	cmp    $0x1,%al
    9f01:	0f 85 4a 05 00 00    	jne    a451 <fwp_hof0.constprop.0+0xf51>
    9f07:	8b 46 18             	mov    0x18(%rsi),%eax
    9f0a:	0f b7 c9             	movzwl %cx,%ecx
    9f0d:	48 0f af c8          	imul   %rax,%rcx
    9f11:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9f14:	48 c1 e9 20          	shr    $0x20,%rcx
    9f18:	48 39 c1             	cmp    %rax,%rcx
    9f1b:	0f 83 30 05 00 00    	jae    a451 <fwp_hof0.constprop.0+0xf51>
    9f21:	48 01 cf             	add    %rcx,%rdi
    9f24:	80 3f 01             	cmpb   $0x1,(%rdi)
    9f27:	0f 85 24 05 00 00    	jne    a451 <fwp_hof0.constprop.0+0xf51>
    9f2d:	4c 39 fa             	cmp    %r15,%rdx
    9f30:	4c 89 f8             	mov    %r15,%rax
    9f33:	48 0f 46 c2          	cmovbe %rdx,%rax
    9f37:	48 85 c0             	test   %rax,%rax
    9f3a:	0f 84 92 0d 00 00    	je     acd2 <fwp_hof0.constprop.0+0x17d2>
    9f40:	c7 44 24 28 01 00 00 	movl   $0x1,0x28(%rsp)
    9f47:	00 
    9f48:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    9f4d:	4c 8b 04 24          	mov    (%rsp),%r8
    9f51:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9f56:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    9f5d:	00 
    9f5e:	31 d2                	xor    %edx,%edx
    9f60:	49 8d 78 08          	lea    0x8(%r8),%rdi
    9f64:	eb 38                	jmp    9f9e <fwp_hof0.constprop.0+0xa9e>
    9f66:	0f 1f 40 00          	nopl   0x0(%rax)
    9f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f71:	00 00 00 00 
    9f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f7c:	00 00 00 00 
    9f80:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9f85:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    9f8a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    9f91:	48 83 c2 08          	add    $0x8,%rdx
    9f95:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9f99:	49 39 d1             	cmp    %rdx,%r9
    9f9c:	74 12                	je     9fb0 <fwp_hof0.constprop.0+0xab0>
    9f9e:	48 89 fe             	mov    %rdi,%rsi
    9fa1:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9fa6:	79 d8                	jns    9f80 <fwp_hof0.constprop.0+0xa80>
    9fa8:	49 8b 70 10          	mov    0x10(%r8),%rsi
    9fac:	eb d2                	jmp    9f80 <fwp_hof0.constprop.0+0xa80>
    9fae:	66 90                	xchg   %ax,%ax
    9fb0:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9fb5:	48 85 c9             	test   %rcx,%rcx
    9fb8:	0f 84 e8 0c 00 00    	je     aca6 <fwp_hof0.constprop.0+0x17a6>
    9fbe:	4c 8b 8b d8 13 00 00 	mov    0x13d8(%rbx),%r9
    9fc5:	4c 8b 93 b0 13 00 00 	mov    0x13b0(%rbx),%r10
    9fcc:	45 31 ff             	xor    %r15d,%r15d
    9fcf:	4c 8b 9b f8 13 00 00 	mov    0x13f8(%rbx),%r11
    9fd6:	49 c1 e1 10          	shl    $0x10,%r9
    9fda:	eb 1a                	jmp    9ff6 <fwp_hof0.constprop.0+0xaf6>
    9fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    9fe0:	49 83 c7 01          	add    $0x1,%r15
    9fe4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9fe8:	49 39 c7             	cmp    %rax,%r15
    9feb:	0f 83 5f 01 00 00    	jae    a150 <fwp_hof0.constprop.0+0xc50>
    9ff1:	48 85 c9             	test   %rcx,%rcx
    9ff4:	74 56                	je     a04c <fwp_hof0.constprop.0+0xb4c>
    9ff6:	48 89 ca             	mov    %rcx,%rdx
    9ff9:	4c 29 d2             	sub    %r10,%rdx
    9ffc:	4c 39 ca             	cmp    %r9,%rdx
    9fff:	73 4b                	jae    a04c <fwp_hof0.constprop.0+0xb4c>
    a001:	48 89 d6             	mov    %rdx,%rsi
    a004:	48 c1 ee 10          	shr    $0x10,%rsi
    a008:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a00c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a010:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a014:	48 85 ff             	test   %rdi,%rdi
    a017:	74 33                	je     a04c <fwp_hof0.constprop.0+0xb4c>
    a019:	44 0f b6 06          	movzbl (%rsi),%r8d
    a01d:	41 80 f8 02          	cmp    $0x2,%r8b
    a021:	0f 84 11 01 00 00    	je     a138 <fwp_hof0.constprop.0+0xc38>
    a027:	41 80 f8 01          	cmp    $0x1,%r8b
    a02b:	75 1f                	jne    a04c <fwp_hof0.constprop.0+0xb4c>
    a02d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a031:	0f b7 d2             	movzwl %dx,%edx
    a034:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a037:	49 0f af d0          	imul   %r8,%rdx
    a03b:	48 c1 ea 20          	shr    $0x20,%rdx
    a03f:	48 39 f2             	cmp    %rsi,%rdx
    a042:	73 08                	jae    a04c <fwp_hof0.constprop.0+0xb4c>
    a044:	48 01 d7             	add    %rdx,%rdi
    a047:	80 3f 01             	cmpb   $0x1,(%rdi)
    a04a:	74 94                	je     9fe0 <fwp_hof0.constprop.0+0xae0>
    a04c:	49 39 c7             	cmp    %rax,%r15
    a04f:	0f 83 fb 00 00 00    	jae    a150 <fwp_hof0.constprop.0+0xc50>
    a055:	48 89 c5             	mov    %rax,%rbp
    a058:	45 31 f6             	xor    %r14d,%r14d
    a05b:	eb 37                	jmp    a094 <fwp_hof0.constprop.0+0xb94>
    a05d:	0f 1f 00             	nopl   (%rax)
    a060:	40 80 fe 01          	cmp    $0x1,%sil
    a064:	75 25                	jne    a08b <fwp_hof0.constprop.0+0xb8b>
    a066:	8b 71 18             	mov    0x18(%rcx),%esi
    a069:	0f b7 c0             	movzwl %ax,%eax
    a06c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a06f:	48 0f af c6          	imul   %rsi,%rax
    a073:	48 c1 e8 20          	shr    $0x20,%rax
    a077:	48 39 c8             	cmp    %rcx,%rax
    a07a:	73 0f                	jae    a08b <fwp_hof0.constprop.0+0xb8b>
    a07c:	48 01 c2             	add    %rax,%rdx
    a07f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a082:	0f 84 c8 05 00 00    	je     a650 <fwp_hof0.constprop.0+0x1150>
    a088:	c6 02 01             	movb   $0x1,(%rdx)
    a08b:	49 39 ef             	cmp    %rbp,%r15
    a08e:	0f 83 8c 00 00 00    	jae    a120 <fwp_hof0.constprop.0+0xc20>
    a094:	48 83 ed 01          	sub    $0x1,%rbp
    a098:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a09d:	bf 01 00 00 00       	mov    $0x1,%edi
    a0a2:	f3 41 0f 7e 44 ed 00 	movq   0x0(%r13,%rbp,8),%xmm0
    a0a9:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a0b0:	00 
    a0b1:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a0b5:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a0bc:	00 
    a0bd:	e8 ae ba ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    a0c2:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a0c9:	49 89 c6             	mov    %rax,%r14
    a0cc:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a0d3:	48 c1 e2 10          	shl    $0x10,%rdx
    a0d7:	48 39 d0             	cmp    %rdx,%rax
    a0da:	73 af                	jae    a08b <fwp_hof0.constprop.0+0xb8b>
    a0dc:	48 89 c2             	mov    %rax,%rdx
    a0df:	48 c1 ea 10          	shr    $0x10,%rdx
    a0e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0e7:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a0ee:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a0f2:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a0f6:	48 85 d2             	test   %rdx,%rdx
    a0f9:	74 90                	je     a08b <fwp_hof0.constprop.0+0xb8b>
    a0fb:	0f b6 31             	movzbl (%rcx),%esi
    a0fe:	40 80 fe 02          	cmp    $0x2,%sil
    a102:	0f 85 58 ff ff ff    	jne    a060 <fwp_hof0.constprop.0+0xb60>
    a108:	66 85 c0             	test   %ax,%ax
    a10b:	0f 84 6e ff ff ff    	je     a07f <fwp_hof0.constprop.0+0xb7f>
    a111:	49 39 ef             	cmp    %rbp,%r15
    a114:	0f 82 7a ff ff ff    	jb     a094 <fwp_hof0.constprop.0+0xb94>
    a11a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a120:	4d 85 ff             	test   %r15,%r15
    a123:	75 2e                	jne    a153 <fwp_hof0.constprop.0+0xc53>
    a125:	8b 44 24 28          	mov    0x28(%rsp),%eax
    a129:	85 c0                	test   %eax,%eax
    a12b:	4d 0f 45 ef          	cmovne %r15,%r13
    a12f:	eb 63                	jmp    a194 <fwp_hof0.constprop.0+0xc94>
    a131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a138:	66 85 d2             	test   %dx,%dx
    a13b:	0f 84 06 ff ff ff    	je     a047 <fwp_hof0.constprop.0+0xb47>
    a141:	49 39 c7             	cmp    %rax,%r15
    a144:	0f 82 0b ff ff ff    	jb     a055 <fwp_hof0.constprop.0+0xb55>
    a14a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a150:	45 31 f6             	xor    %r14d,%r14d
    a153:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a158:	4c 89 ea             	mov    %r13,%rdx
    a15b:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    a160:	48 8b 0a             	mov    (%rdx),%rcx
    a163:	48 83 c2 08          	add    $0x8,%rdx
    a167:	48 89 c7             	mov    %rax,%rdi
    a16a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a16e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a172:	4c 39 ca             	cmp    %r9,%rdx
    a175:	75 e9                	jne    a160 <fwp_hof0.constprop.0+0xc60>
    a177:	8b 54 24 28          	mov    0x28(%rsp),%edx
    a17b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a17f:	85 d2                	test   %edx,%edx
    a181:	0f 84 e1 07 00 00    	je     a968 <fwp_hof0.constprop.0+0x1468>
    a187:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    a18c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a191:	45 31 ed             	xor    %r13d,%r13d
    a194:	4c 89 ef             	mov    %r13,%rdi
    a197:	e8 b4 b3 ff ff       	call   5550 <fwp_mem_free>
    a19c:	48 8b 3c 24          	mov    (%rsp),%rdi
    a1a0:	e8 8b db ff ff       	call   7d30 <fwp_drop10>
    a1a5:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a1ac:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a1b1:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a1b8:	48 c1 e2 10          	shl    $0x10,%rdx
    a1bc:	48 39 d0             	cmp    %rdx,%rax
    a1bf:	73 6f                	jae    a230 <fwp_hof0.constprop.0+0xd30>
    a1c1:	48 89 c2             	mov    %rax,%rdx
    a1c4:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    a1cb:	48 c1 ea 10          	shr    $0x10,%rdx
    a1cf:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a1d3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a1d7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a1db:	4d 85 e4             	test   %r12,%r12
    a1de:	74 50                	je     a230 <fwp_hof0.constprop.0+0xd30>
    a1e0:	0f b6 0a             	movzbl (%rdx),%ecx
    a1e3:	80 f9 02             	cmp    $0x2,%cl
    a1e6:	0f 84 04 07 00 00    	je     a8f0 <fwp_hof0.constprop.0+0x13f0>
    a1ec:	80 f9 01             	cmp    $0x1,%cl
    a1ef:	75 3f                	jne    a230 <fwp_hof0.constprop.0+0xd30>
    a1f1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a1f4:	0f b7 c0             	movzwl %ax,%eax
    a1f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a1fa:	48 0f af c1          	imul   %rcx,%rax
    a1fe:	48 c1 e8 20          	shr    $0x20,%rax
    a202:	48 39 d0             	cmp    %rdx,%rax
    a205:	73 29                	jae    a230 <fwp_hof0.constprop.0+0xd30>
    a207:	49 01 c4             	add    %rax,%r12
    a20a:	41 0f b6 04 24       	movzbl (%r12),%eax
    a20f:	84 c0                	test   %al,%al
    a211:	74 1d                	je     a230 <fwp_hof0.constprop.0+0xd30>
    a213:	3c 01                	cmp    $0x1,%al
    a215:	0f 84 65 07 00 00    	je     a980 <fwp_hof0.constprop.0+0x1480>
    a21b:	3c ff                	cmp    $0xff,%al
    a21d:	0f 84 51 09 00 00    	je     ab74 <fwp_hof0.constprop.0+0x1674>
    a223:	83 e8 01             	sub    $0x1,%eax
    a226:	41 88 04 24          	mov    %al,(%r12)
    a22a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a230:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
    a236:	0f 85 74 05 00 00    	jne    a7b0 <fwp_hof0.constprop.0+0x12b0>
    a23c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a241:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a245:	4c 89 f6             	mov    %r14,%rsi
    a248:	4d 89 f4             	mov    %r14,%r12
    a24b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a250:	48 8d 15 49 89 00 00 	lea    0x8949(%rip),%rdx        # 12ba0 <d0>
    a257:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a25e:	00 00 00 00 00 
    a263:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a26a:	00 
    a26b:	e8 50 e2 ff ff       	call   84c0 <fwp_write>
    a270:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a277:	00 
    a278:	4c 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%r13
    a27f:	00 
    a280:	48 8d 05 a7 4d 00 00 	lea    0x4da7(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    a287:	48 85 c9             	test   %rcx,%rcx
    a28a:	48 0f 44 c8          	cmove  %rax,%rcx
    a28e:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    a292:	0f 87 0f 0b 00 00    	ja     ada7 <fwp_hof0.constprop.0+0x18a7>
    a298:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    a29c:	be 01 00 00 00       	mov    $0x1,%esi
    a2a1:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a2a6:	e8 a5 b7 ff ff       	call   5a50 <fwp_heap_alloc>
    a2ab:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a2b0:	4c 89 ea             	mov    %r13,%rdx
    a2b3:	4c 89 28             	mov    %r13,(%rax)
    a2b6:	4c 8d 78 08          	lea    0x8(%rax),%r15
    a2ba:	48 89 c5             	mov    %rax,%rbp
    a2bd:	4c 89 ff             	mov    %r15,%rdi
    a2c0:	e8 db 92 ff ff       	call   35a0 <memcpy@plt>
    a2c5:	42 c6 44 2d 08 00    	movb   $0x0,0x8(%rbp,%r13,1)
    a2cb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a2d2:	00 
    a2d3:	e8 e8 90 ff ff       	call   33c0 <free@plt>
    a2d8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a2df:	48 89 e8             	mov    %rbp,%rax
    a2e2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a2e9:	48 c1 e2 10          	shl    $0x10,%rdx
    a2ed:	48 39 d0             	cmp    %rdx,%rax
    a2f0:	73 59                	jae    a34b <fwp_hof0.constprop.0+0xe4b>
    a2f2:	48 89 c2             	mov    %rax,%rdx
    a2f5:	48 c1 ea 10          	shr    $0x10,%rdx
    a2f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2fd:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a304:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a308:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a30c:	4d 85 ed             	test   %r13,%r13
    a30f:	74 3a                	je     a34b <fwp_hof0.constprop.0+0xe4b>
    a311:	0f b6 0a             	movzbl (%rdx),%ecx
    a314:	80 f9 02             	cmp    $0x2,%cl
    a317:	0f 84 b3 07 00 00    	je     aad0 <fwp_hof0.constprop.0+0x15d0>
    a31d:	80 f9 01             	cmp    $0x1,%cl
    a320:	75 29                	jne    a34b <fwp_hof0.constprop.0+0xe4b>
    a322:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a325:	0f b7 c0             	movzwl %ax,%eax
    a328:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a32b:	48 0f af c1          	imul   %rcx,%rax
    a32f:	48 c1 e8 20          	shr    $0x20,%rax
    a333:	48 39 d0             	cmp    %rdx,%rax
    a336:	73 13                	jae    a34b <fwp_hof0.constprop.0+0xe4b>
    a338:	49 01 c5             	add    %rax,%r13
    a33b:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a340:	0f 84 9e 07 00 00    	je     aae4 <fwp_hof0.constprop.0+0x15e4>
    a346:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a34b:	4c 89 e7             	mov    %r12,%rdi
    a34e:	e8 ed d5 ff ff       	call   7940 <fwp_drop0>
    a353:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    a357:	be 01 00 00 00       	mov    $0x1,%esi
    a35c:	4c 89 ff             	mov    %r15,%rdi
    a35f:	48 8b 0d 5a b0 01 00 	mov    0x1b05a(%rip),%rcx        # 253c0 <fwp_prog_out>
    a366:	e8 15 93 ff ff       	call   3680 <fwrite@plt>
    a36b:	48 8b 35 4e b0 01 00 	mov    0x1b04e(%rip),%rsi        # 253c0 <fwp_prog_out>
    a372:	bf 0a 00 00 00       	mov    $0xa,%edi
    a377:	e8 64 91 ff ff       	call   34e0 <fputc@plt>
    a37c:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a383:	48 89 e8             	mov    %rbp,%rax
    a386:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a38d:	48 c1 e2 10          	shl    $0x10,%rdx
    a391:	48 39 d0             	cmp    %rdx,%rax
    a394:	73 6a                	jae    a400 <fwp_hof0.constprop.0+0xf00>
    a396:	48 89 c2             	mov    %rax,%rdx
    a399:	48 c1 ea 10          	shr    $0x10,%rdx
    a39d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3a1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a3a8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3ac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a3b0:	4d 85 e4             	test   %r12,%r12
    a3b3:	74 4b                	je     a400 <fwp_hof0.constprop.0+0xf00>
    a3b5:	0f b6 0a             	movzbl (%rdx),%ecx
    a3b8:	80 f9 02             	cmp    $0x2,%cl
    a3bb:	0f 84 df 06 00 00    	je     aaa0 <fwp_hof0.constprop.0+0x15a0>
    a3c1:	80 f9 01             	cmp    $0x1,%cl
    a3c4:	75 3a                	jne    a400 <fwp_hof0.constprop.0+0xf00>
    a3c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a3c9:	0f b7 c0             	movzwl %ax,%eax
    a3cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a3cf:	48 0f af c1          	imul   %rcx,%rax
    a3d3:	48 c1 e8 20          	shr    $0x20,%rax
    a3d7:	48 39 d0             	cmp    %rdx,%rax
    a3da:	73 24                	jae    a400 <fwp_hof0.constprop.0+0xf00>
    a3dc:	49 01 c4             	add    %rax,%r12
    a3df:	41 0f b6 04 24       	movzbl (%r12),%eax
    a3e4:	84 c0                	test   %al,%al
    a3e6:	74 18                	je     a400 <fwp_hof0.constprop.0+0xf00>
    a3e8:	3c 01                	cmp    $0x1,%al
    a3ea:	0f 84 ce 06 00 00    	je     aabe <fwp_hof0.constprop.0+0x15be>
    a3f0:	3c ff                	cmp    $0xff,%al
    a3f2:	0f 84 ee 07 00 00    	je     abe6 <fwp_hof0.constprop.0+0x16e6>
    a3f8:	83 e8 01             	sub    $0x1,%eax
    a3fb:	41 88 04 24          	mov    %al,(%r12)
    a3ff:	90                   	nop
    a400:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    a405:	48 8b 40 10          	mov    0x10(%rax),%rax
    a409:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a40e:	48 85 c0             	test   %rax,%rax
    a411:	0f 85 29 f1 ff ff    	jne    9540 <fwp_hof0.constprop.0+0x40>
    a417:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a41e:	00 
    a41f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a426:	00 00 
    a428:	0f 85 74 09 00 00    	jne    ada2 <fwp_hof0.constprop.0+0x18a2>
    a42e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a435:	31 c0                	xor    %eax,%eax
    a437:	5b                   	pop    %rbx
    a438:	5d                   	pop    %rbp
    a439:	41 5c                	pop    %r12
    a43b:	41 5d                	pop    %r13
    a43d:	41 5e                	pop    %r14
    a43f:	41 5f                	pop    %r15
    a441:	c3                   	ret
    a442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a448:	66 85 c9             	test   %cx,%cx
    a44b:	0f 84 d3 fa ff ff    	je     9f24 <fwp_hof0.constprop.0+0xa24>
    a451:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    a457:	0f 84 a4 02 00 00    	je     a701 <fwp_hof0.constprop.0+0x1201>
    a45d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a462:	45 31 f6             	xor    %r14d,%r14d
    a465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a46c:	00 00 00 00 
    a470:	48 8b 40 10          	mov    0x10(%rax),%rax
    a474:	4c 89 f2             	mov    %r14,%rdx
    a477:	49 83 c6 01          	add    $0x1,%r14
    a47b:	48 85 c0             	test   %rax,%rax
    a47e:	75 f0                	jne    a470 <fwp_hof0.constprop.0+0xf70>
    a480:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a487:	ff ff 1f 
    a48a:	4c 39 f0             	cmp    %r14,%rax
    a48d:	0f 82 5f 08 00 00    	jb     acf2 <fwp_hof0.constprop.0+0x17f2>
    a493:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a49a:	00 
    a49b:	be 02 00 00 00       	mov    $0x2,%esi
    a4a0:	e8 ab b5 ff ff       	call   5a50 <fwp_heap_alloc>
    a4a5:	4d 39 f7             	cmp    %r14,%r15
    a4a8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a4ad:	49 89 c5             	mov    %rax,%r13
    a4b0:	4c 89 f0             	mov    %r14,%rax
    a4b3:	49 0f 46 c7          	cmovbe %r15,%rax
    a4b7:	4c 89 e9             	mov    %r13,%rcx
    a4ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a4c4:	48 83 c1 08          	add    $0x8,%rcx
    a4c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a4cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a4d0:	48 85 d2             	test   %rdx,%rdx
    a4d3:	75 eb                	jne    a4c0 <fwp_hof0.constprop.0+0xfc0>
    a4d5:	48 85 c0             	test   %rax,%rax
    a4d8:	0f 84 35 02 00 00    	je     a713 <fwp_hof0.constprop.0+0x1213>
    a4de:	c7 44 24 28 00 00 00 	movl   $0x0,0x28(%rsp)
    a4e5:	00 
    a4e6:	e9 62 fa ff ff       	jmp    9f4d <fwp_hof0.constprop.0+0xa4d>
    a4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4f0:	4d 39 ec             	cmp    %r13,%r12
    a4f3:	0f 84 37 f2 ff ff    	je     9730 <fwp_hof0.constprop.0+0x230>
    a4f9:	48 8b 2d f0 8b 01 00 	mov    0x18bf0(%rip),%rbp        # 230f0 <fwp_tapes>
    a500:	e9 cc f2 ff ff       	jmp    97d1 <fwp_hof0.constprop.0+0x2d1>
    a505:	0f 1f 00             	nopl   (%rax)
    a508:	48 83 3d 78 8b 01 00 	cmpq   $0x0,0x18b78(%rip)        # 23088 <fwp_tape_cached_bytes>
    a50f:	00 
    a510:	0f 84 00 f3 ff ff    	je     9816 <fwp_hof0.constprop.0+0x316>
    a516:	66 0f 6f 0d 82 8b 01 	movdqa 0x18b82(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a51d:	00 
    a51e:	48 c7 05 5f 8b 01 00 	movq   $0x0,0x18b5f(%rip)        # 23088 <fwp_tape_cached_bytes>
    a525:	00 00 00 00 
    a529:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    a52f:	48 8b 05 8a 8b 01 00 	mov    0x18b8a(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a536:	66 0f 6f 0d 72 8b 01 	movdqa 0x18b72(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a53d:	00 
    a53e:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    a543:	48 8b 05 7e 8b 01 00 	mov    0x18b7e(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a54a:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    a550:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a554:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    a559:	48 8b 05 70 8b 01 00 	mov    0x18b70(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a560:	0f 29 0d 39 8b 01 00 	movaps %xmm1,0x18b39(%rip)        # 230a0 <fwp_tape_workspace>
    a567:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    a56c:	0f 29 0d 3d 8b 01 00 	movaps %xmm1,0x18b3d(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a573:	48 c7 05 52 8b 01 00 	movq   $0x0,0x18b52(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a57a:	00 00 00 00 
    a57e:	0f 29 0d 3b 8b 01 00 	movaps %xmm1,0x18b3b(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a585:	e9 8c f2 ff ff       	jmp    9816 <fwp_hof0.constprop.0+0x316>
    a58a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a590:	66 85 c0             	test   %ax,%ax
    a593:	0f 84 72 f8 ff ff    	je     9e0b <fwp_hof0.constprop.0+0x90b>
    a599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a5a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a5a7:	ff ff 1f 
    a5aa:	4c 39 f8             	cmp    %r15,%rax
    a5ad:	0f 82 33 07 00 00    	jb     ace6 <fwp_hof0.constprop.0+0x17e6>
    a5b3:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    a5ba:	00 
    a5bb:	be 01 00 00 00       	mov    $0x1,%esi
    a5c0:	e8 8b b4 ff ff       	call   5a50 <fwp_heap_alloc>
    a5c5:	4c 89 38             	mov    %r15,(%rax)
    a5c8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a5cf:	49 89 c4             	mov    %rax,%r12
    a5d2:	48 89 04 24          	mov    %rax,(%rsp)
    a5d6:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a5dd:	48 c1 e2 10          	shl    $0x10,%rdx
    a5e1:	48 39 d0             	cmp    %rdx,%rax
    a5e4:	73 59                	jae    a63f <fwp_hof0.constprop.0+0x113f>
    a5e6:	48 89 c2             	mov    %rax,%rdx
    a5e9:	48 c1 ea 10          	shr    $0x10,%rdx
    a5ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5f1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a5f8:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a5fc:	48 8b 69 20          	mov    0x20(%rcx),%rbp
    a600:	48 85 ed             	test   %rbp,%rbp
    a603:	74 3a                	je     a63f <fwp_hof0.constprop.0+0x113f>
    a605:	0f b6 31             	movzbl (%rcx),%esi
    a608:	40 80 fe 02          	cmp    $0x2,%sil
    a60c:	0f 84 16 04 00 00    	je     aa28 <fwp_hof0.constprop.0+0x1528>
    a612:	40 80 fe 01          	cmp    $0x1,%sil
    a616:	75 27                	jne    a63f <fwp_hof0.constprop.0+0x113f>
    a618:	8b 71 18             	mov    0x18(%rcx),%esi
    a61b:	0f b7 c0             	movzwl %ax,%eax
    a61e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a621:	48 0f af c6          	imul   %rsi,%rax
    a625:	48 c1 e8 20          	shr    $0x20,%rax
    a629:	48 39 c8             	cmp    %rcx,%rax
    a62c:	73 11                	jae    a63f <fwp_hof0.constprop.0+0x113f>
    a62e:	48 01 c5             	add    %rax,%rbp
    a631:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a635:	0f 84 00 04 00 00    	je     aa3b <fwp_hof0.constprop.0+0x153b>
    a63b:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a63f:	4c 89 f7             	mov    %r14,%rdi
    a642:	e9 d6 f7 ff ff       	jmp    9e1d <fwp_hof0.constprop.0+0x91d>
    a647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a64e:	00 00 
    a650:	48 89 d7             	mov    %rdx,%rdi
    a653:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a658:	e8 b3 ac ff ff       	call   5310 <fwp_rc_forget_slot>
    a65d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a662:	e9 21 fa ff ff       	jmp    a088 <fwp_hof0.constprop.0+0xb88>
    a667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a66e:	00 00 
    a670:	48 c1 e1 10          	shl    $0x10,%rcx
    a674:	bf 08 00 00 00       	mov    $0x8,%edi
    a679:	48 09 f1             	or     %rsi,%rcx
    a67c:	be 02 00 00 00       	mov    $0x2,%esi
    a681:	48 89 0c 24          	mov    %rcx,(%rsp)
    a685:	e8 c6 b3 ff ff       	call   5a50 <fwp_heap_alloc>
    a68a:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a691:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a698:	49 89 c5             	mov    %rax,%r13
    a69b:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a6a2:	48 c1 e2 10          	shl    $0x10,%rdx
    a6a6:	48 39 d0             	cmp    %rdx,%rax
    a6a9:	0f 83 92 f3 ff ff    	jae    9a41 <fwp_hof0.constprop.0+0x541>
    a6af:	48 89 c2             	mov    %rax,%rdx
    a6b2:	48 c1 ea 10          	shr    $0x10,%rdx
    a6b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a6ba:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a6c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a6c5:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a6c9:	4d 85 f6             	test   %r14,%r14
    a6cc:	0f 84 62 f3 ff ff    	je     9a34 <fwp_hof0.constprop.0+0x534>
    a6d2:	0f b6 0a             	movzbl (%rdx),%ecx
    a6d5:	45 31 e4             	xor    %r12d,%r12d
    a6d8:	80 f9 02             	cmp    $0x2,%cl
    a6db:	0f 85 a9 f2 ff ff    	jne    998a <fwp_hof0.constprop.0+0x48a>
    a6e1:	66 85 c0             	test   %ax,%ax
    a6e4:	0f 85 cc f2 ff ff    	jne    99b6 <fwp_hof0.constprop.0+0x4b6>
    a6ea:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a6ee:	0f 85 be f2 ff ff    	jne    99b2 <fwp_hof0.constprop.0+0x4b2>
    a6f4:	4c 89 f7             	mov    %r14,%rdi
    a6f7:	e8 14 ac ff ff       	call   5310 <fwp_rc_forget_slot>
    a6fc:	e9 b1 f2 ff ff       	jmp    99b2 <fwp_hof0.constprop.0+0x4b2>
    a701:	be 02 00 00 00       	mov    $0x2,%esi
    a706:	bf 08 00 00 00       	mov    $0x8,%edi
    a70b:	e8 40 b3 ff ff       	call   5a50 <fwp_heap_alloc>
    a710:	49 89 c5             	mov    %rax,%r13
    a713:	45 31 f6             	xor    %r14d,%r14d
    a716:	e9 79 fa ff ff       	jmp    a194 <fwp_hof0.constprop.0+0xc94>
    a71b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a720:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    a724:	4c 89 e7             	mov    %r12,%rdi
    a727:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a72b:	0f 85 c1 05 00 00    	jne    acf2 <fwp_hof0.constprop.0+0x17f2>
    a731:	4d 85 e4             	test   %r12,%r12
    a734:	0f 84 07 f3 ff ff    	je     9a41 <fwp_hof0.constprop.0+0x541>
    a73a:	48 c1 e0 04          	shl    $0x4,%rax
    a73e:	4d 01 e4             	add    %r12,%r12
    a741:	49 8d 6d 08          	lea    0x8(%r13),%rbp
    a745:	4d 8d 74 05 f8       	lea    -0x8(%r13,%rax,1),%r14
    a74a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a750:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    a755:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    a759:	48 83 c5 10          	add    $0x10,%rbp
    a75d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    a761:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    a766:	e8 25 b9 ff ff       	call   6090 <w120>
    a76b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a770:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a774:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    a778:	49 39 ee             	cmp    %rbp,%r14
    a77b:	75 d3                	jne    a750 <fwp_hof0.constprop.0+0x1250>
    a77d:	4d 89 65 00          	mov    %r12,0x0(%r13)
    a781:	45 31 f6             	xor    %r14d,%r14d
    a784:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    a78b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a790:	4b 8b 74 f5 10       	mov    0x10(%r13,%r14,8),%rsi
    a795:	49 83 c6 02          	add    $0x2,%r14
    a799:	e8 72 b7 ff ff       	call   5f10 <f141.constprop.0>
    a79e:	48 89 c7             	mov    %rax,%rdi
    a7a1:	4d 39 e6             	cmp    %r12,%r14
    a7a4:	72 ea                	jb     a790 <fwp_hof0.constprop.0+0x1290>
    a7a6:	48 89 c1             	mov    %rax,%rcx
    a7a9:	e9 a2 f2 ff ff       	jmp    9a50 <fwp_hof0.constprop.0+0x550>
    a7ae:	66 90                	xchg   %ax,%ax
    a7b0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a7b5:	45 31 c0             	xor    %r8d,%r8d
    a7b8:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a7bd:	48 83 e8 01          	sub    $0x1,%rax
    a7c1:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a7c6:	41 0f 90 c0          	seto   %r8b
    a7ca:	e9 00 ee ff ff       	jmp    95cf <fwp_hof0.constprop.0+0xcf>
    a7cf:	90                   	nop
    a7d0:	49 8d 55 01          	lea    0x1(%r13),%rdx
    a7d4:	49 39 d6             	cmp    %rdx,%r14
    a7d7:	7c 3a                	jl     a813 <fwp_hof0.constprop.0+0x1313>
    a7d9:	4d 85 c9             	test   %r9,%r9
    a7dc:	0f 84 33 05 00 00    	je     ad15 <fwp_hof0.constprop.0+0x1815>
    a7e2:	4c 89 cf             	mov    %r9,%rdi
    a7e5:	48 c1 e2 03          	shl    $0x3,%rdx
    a7e9:	31 f6                	xor    %esi,%esi
    a7eb:	0f 29 14 24          	movaps %xmm2,(%rsp)
    a7ef:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    a7f4:	e8 c7 8c ff ff       	call   34c0 <memset@plt>
    a7f9:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    a7fe:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    a804:	49 89 c1             	mov    %rax,%r9
    a807:	e9 c2 f3 ff ff       	jmp    9bce <fwp_hof0.constprop.0+0x6ce>
    a80c:	0f 1f 40 00          	nopl   0x0(%rax)
    a810:	48 89 ea             	mov    %rbp,%rdx
    a813:	4d 85 f6             	test   %r14,%r14
    a816:	4c 0f 44 f2          	cmove  %rdx,%r14
    a81a:	eb 19                	jmp    a835 <fwp_hof0.constprop.0+0x1335>
    a81c:	0f 1f 40 00          	nopl   0x0(%rax)
    a820:	4b 8d 34 36          	lea    (%r14,%r14,1),%rsi
    a824:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    a82b:	48 89 d0             	mov    %rdx,%rax
    a82e:	48 0f 4c c6          	cmovl  %rsi,%rax
    a832:	49 89 c6             	mov    %rax,%r14
    a835:	49 39 d6             	cmp    %rdx,%r14
    a838:	7c e6                	jl     a820 <fwp_hof0.constprop.0+0x1320>
    a83a:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
    a83f:	48 89 0c 24          	mov    %rcx,(%rsp)
    a843:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a848:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    a84d:	4d 85 c9             	test   %r9,%r9
    a850:	0f 84 0a 02 00 00    	je     aa60 <fwp_hof0.constprop.0+0x1560>
    a856:	4c 89 cf             	mov    %r9,%rdi
    a859:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    a860:	00 
    a861:	e8 6a 8d ff ff       	call   35d0 <realloc@plt>
    a866:	48 8b 0c 24          	mov    (%rsp),%rcx
    a86a:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    a870:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a876:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    a87b:	49 89 c1             	mov    %rax,%r9
    a87e:	4d 85 c9             	test   %r9,%r9
    a881:	0f 84 85 04 00 00    	je     ad0c <fwp_hof0.constprop.0+0x180c>
    a887:	4c 89 8c 24 e0 00 00 	mov    %r9,0xe0(%rsp)
    a88e:	00 
    a88f:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
    a896:	00 
    a897:	48 85 d2             	test   %rdx,%rdx
    a89a:	0f 85 79 03 00 00    	jne    ac19 <fwp_hof0.constprop.0+0x1719>
    a8a0:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    a8a7:	48 85 c9             	test   %rcx,%rcx
    a8aa:	0f 88 32 f3 ff ff    	js     9be2 <fwp_hof0.constprop.0+0x6e2>
    a8b0:	41 89 cd             	mov    %ecx,%r13d
    a8b3:	e9 16 f3 ff ff       	jmp    9bce <fwp_hof0.constprop.0+0x6ce>
    a8b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a8bf:	00 
    a8c0:	48 8d 3d 59 c4 ff ff 	lea    -0x3ba7(%rip),%rdi        # 6d20 <fwp_tape_finish>
    a8c7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    a8cc:	e8 2f 3b 00 00       	call   e400 <atexit>
    a8d1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    a8d6:	85 c0                	test   %eax,%eax
    a8d8:	0f 85 d5 04 00 00    	jne    adb3 <fwp_hof0.constprop.0+0x18b3>
    a8de:	c7 05 78 87 00 00 01 	movl   $0x1,0x8778(%rip)        # 13060 <registered_finish.1>
    a8e5:	00 00 00 
    a8e8:	e9 00 ee ff ff       	jmp    96ed <fwp_hof0.constprop.0+0x1ed>
    a8ed:	0f 1f 00             	nopl   (%rax)
    a8f0:	66 85 c0             	test   %ax,%ax
    a8f3:	0f 85 37 f9 ff ff    	jne    a230 <fwp_hof0.constprop.0+0xd30>
    a8f9:	e9 0c f9 ff ff       	jmp    a20a <fwp_hof0.constprop.0+0xd0a>
    a8fe:	66 90                	xchg   %ax,%ax
    a900:	66 85 c0             	test   %ax,%ax
    a903:	0f 85 99 ed ff ff    	jne    96a2 <fwp_hof0.constprop.0+0x1a2>
    a909:	e9 80 ed ff ff       	jmp    968e <fwp_hof0.constprop.0+0x18e>
    a90e:	66 90                	xchg   %ax,%ax
    a910:	4c 39 f5             	cmp    %r14,%rbp
    a913:	0f 8f f7 fe ff ff    	jg     a810 <fwp_hof0.constprop.0+0x1310>
    a919:	48 85 ed             	test   %rbp,%rbp
    a91c:	74 12                	je     a930 <fwp_hof0.constprop.0+0x1430>
    a91e:	4d 85 c9             	test   %r9,%r9
    a921:	0f 84 ee 03 00 00    	je     ad15 <fwp_hof0.constprop.0+0x1815>
    a927:	48 85 ed             	test   %rbp,%rbp
    a92a:	0f 85 e6 02 00 00    	jne    ac16 <fwp_hof0.constprop.0+0x1716>
    a930:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    a937:	e9 a6 f2 ff ff       	jmp    9be2 <fwp_hof0.constprop.0+0x6e2>
    a93c:	0f 1f 40 00          	nopl   0x0(%rax)
    a940:	66 85 c0             	test   %ax,%ax
    a943:	0f 85 15 f4 ff ff    	jne    9d5e <fwp_hof0.constprop.0+0x85e>
    a949:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    a94e:	0f 85 05 f4 ff ff    	jne    9d59 <fwp_hof0.constprop.0+0x859>
    a954:	4c 89 e7             	mov    %r12,%rdi
    a957:	e8 b4 a9 ff ff       	call   5310 <fwp_rc_forget_slot>
    a95c:	e9 f8 f3 ff ff       	jmp    9d59 <fwp_hof0.constprop.0+0x859>
    a961:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a968:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    a96d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    a972:	e9 1d f8 ff ff       	jmp    a194 <fwp_hof0.constprop.0+0xc94>
    a977:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a97e:	00 00 
    a980:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a985:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    a98c:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a993:	48 8b 68 10          	mov    0x10(%rax),%rbp
    a997:	48 29 c8             	sub    %rcx,%rax
    a99a:	48 c1 e2 10          	shl    $0x10,%rdx
    a99e:	48 39 d0             	cmp    %rdx,%rax
    a9a1:	73 67                	jae    aa0a <fwp_hof0.constprop.0+0x150a>
    a9a3:	48 89 c7             	mov    %rax,%rdi
    a9a6:	48 c1 ef 10          	shr    $0x10,%rdi
    a9aa:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    a9ae:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a9b2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a9b6:	48 85 ff             	test   %rdi,%rdi
    a9b9:	74 4f                	je     aa0a <fwp_hof0.constprop.0+0x150a>
    a9bb:	44 0f b6 06          	movzbl (%rsi),%r8d
    a9bf:	41 80 f8 02          	cmp    $0x2,%r8b
    a9c3:	0f 84 9d 01 00 00    	je     ab66 <fwp_hof0.constprop.0+0x1666>
    a9c9:	41 80 f8 01          	cmp    $0x1,%r8b
    a9cd:	75 3b                	jne    aa0a <fwp_hof0.constprop.0+0x150a>
    a9cf:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a9d3:	0f b7 c0             	movzwl %ax,%eax
    a9d6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a9d9:	49 0f af c0          	imul   %r8,%rax
    a9dd:	48 c1 e8 20          	shr    $0x20,%rax
    a9e1:	48 39 f0             	cmp    %rsi,%rax
    a9e4:	73 24                	jae    aa0a <fwp_hof0.constprop.0+0x150a>
    a9e6:	48 01 c7             	add    %rax,%rdi
    a9e9:	80 3f 01             	cmpb   $0x1,(%rdi)
    a9ec:	75 1c                	jne    aa0a <fwp_hof0.constprop.0+0x150a>
    a9ee:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a9f3:	e8 58 ab ff ff       	call   5550 <fwp_mem_free>
    a9f8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a9ff:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    aa06:	48 c1 e2 10          	shl    $0x10,%rdx
    aa0a:	48 89 e8             	mov    %rbp,%rax
    aa0d:	48 29 c8             	sub    %rcx,%rax
    aa10:	48 39 d0             	cmp    %rdx,%rax
    aa13:	0f 83 17 f8 ff ff    	jae    a230 <fwp_hof0.constprop.0+0xd30>
    aa19:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
    aa1e:	e9 9e f7 ff ff       	jmp    a1c1 <fwp_hof0.constprop.0+0xcc1>
    aa23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aa28:	66 85 c0             	test   %ax,%ax
    aa2b:	0f 85 0e fc ff ff    	jne    a63f <fwp_hof0.constprop.0+0x113f>
    aa31:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    aa35:	0f 85 00 fc ff ff    	jne    a63b <fwp_hof0.constprop.0+0x113b>
    aa3b:	48 89 ef             	mov    %rbp,%rdi
    aa3e:	e8 cd a8 ff ff       	call   5310 <fwp_rc_forget_slot>
    aa43:	e9 f3 fb ff ff       	jmp    a63b <fwp_hof0.constprop.0+0x113b>
    aa48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa4f:	00 
    aa50:	4d 85 e4             	test   %r12,%r12
    aa53:	0f 85 62 ef ff ff    	jne    99bb <fwp_hof0.constprop.0+0x4bb>
    aa59:	e9 e3 ef ff ff       	jmp    9a41 <fwp_hof0.constprop.0+0x541>
    aa5e:	66 90                	xchg   %ax,%ax
    aa60:	be 08 00 00 00       	mov    $0x8,%esi
    aa65:	4c 89 f7             	mov    %r14,%rdi
    aa68:	e8 b3 8a ff ff       	call   3520 <calloc@plt>
    aa6d:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
    aa72:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    aa78:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    aa7e:	48 8b 0c 24          	mov    (%rsp),%rcx
    aa82:	49 89 c1             	mov    %rax,%r9
    aa85:	e9 f4 fd ff ff       	jmp    a87e <fwp_hof0.constprop.0+0x137e>
    aa8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa90:	66 85 c0             	test   %ax,%ax
    aa93:	0f 85 20 eb ff ff    	jne    95b9 <fwp_hof0.constprop.0+0xb9>
    aa99:	e9 07 eb ff ff       	jmp    95a5 <fwp_hof0.constprop.0+0xa5>
    aa9e:	66 90                	xchg   %ax,%ax
    aaa0:	66 85 c0             	test   %ax,%ax
    aaa3:	0f 85 57 f9 ff ff    	jne    a400 <fwp_hof0.constprop.0+0xf00>
    aaa9:	41 0f b6 04 24       	movzbl (%r12),%eax
    aaae:	84 c0                	test   %al,%al
    aab0:	0f 84 4a f9 ff ff    	je     a400 <fwp_hof0.constprop.0+0xf00>
    aab6:	3c 01                	cmp    $0x1,%al
    aab8:	0f 85 32 f9 ff ff    	jne    a3f0 <fwp_hof0.constprop.0+0xef0>
    aabe:	48 89 ef             	mov    %rbp,%rdi
    aac1:	e8 8a aa ff ff       	call   5550 <fwp_mem_free>
    aac6:	e9 35 f9 ff ff       	jmp    a400 <fwp_hof0.constprop.0+0xf00>
    aacb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aad0:	66 85 c0             	test   %ax,%ax
    aad3:	0f 85 72 f8 ff ff    	jne    a34b <fwp_hof0.constprop.0+0xe4b>
    aad9:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aade:	0f 85 62 f8 ff ff    	jne    a346 <fwp_hof0.constprop.0+0xe46>
    aae4:	4c 89 ef             	mov    %r13,%rdi
    aae7:	e8 24 a8 ff ff       	call   5310 <fwp_rc_forget_slot>
    aaec:	e9 55 f8 ff ff       	jmp    a346 <fwp_hof0.constprop.0+0xe46>
    aaf1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aaf5:	e9 e5 eb ff ff       	jmp    96df <fwp_hof0.constprop.0+0x1df>
    aafa:	49 8b 04 24          	mov    (%r12),%rax
    aafe:	48 85 c0             	test   %rax,%rax
    ab01:	0f 88 fa fb ff ff    	js     a701 <fwp_hof0.constprop.0+0x1201>
    ab07:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    ab0e:	48 8b 0c 24          	mov    (%rsp),%rcx
    ab12:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    ab19:	48 c1 e6 10          	shl    $0x10,%rsi
    ab1d:	48 39 f1             	cmp    %rsi,%rcx
    ab20:	0f 83 db fb ff ff    	jae    a701 <fwp_hof0.constprop.0+0x1201>
    ab26:	48 89 ce             	mov    %rcx,%rsi
    ab29:	48 c1 ee 10          	shr    $0x10,%rsi
    ab2d:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    ab31:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    ab38:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ab3c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ab40:	48 85 ff             	test   %rdi,%rdi
    ab43:	0f 84 b8 fb ff ff    	je     a701 <fwp_hof0.constprop.0+0x1201>
    ab49:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ab4e:	49 89 c7             	mov    %rax,%r15
    ab51:	e9 9e f3 ff ff       	jmp    9ef4 <fwp_hof0.constprop.0+0x9f4>
    ab56:	be 68 00 00 00       	mov    $0x68,%esi
    ab5b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    ab61:	e9 04 ec ff ff       	jmp    976a <fwp_hof0.constprop.0+0x26a>
    ab66:	66 85 c0             	test   %ax,%ax
    ab69:	0f 85 9b fe ff ff    	jne    aa0a <fwp_hof0.constprop.0+0x150a>
    ab6f:	e9 75 fe ff ff       	jmp    a9e9 <fwp_hof0.constprop.0+0x14e9>
    ab74:	4c 89 e2             	mov    %r12,%rdx
    ab77:	48 c1 ea 11          	shr    $0x11,%rdx
    ab7b:	4c 31 e2             	xor    %r12,%rdx
    ab7e:	48 89 d0             	mov    %rdx,%rax
    ab81:	48 c1 e8 09          	shr    $0x9,%rax
    ab85:	48 31 c2             	xor    %rax,%rdx
    ab88:	0f b6 d2             	movzbl %dl,%edx
    ab8b:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    ab92:	00 
    ab93:	48 85 c0             	test   %rax,%rax
    ab96:	75 11                	jne    aba9 <fwp_hof0.constprop.0+0x16a9>
    ab98:	eb 70                	jmp    ac0a <fwp_hof0.constprop.0+0x170a>
    ab9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aba0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aba4:	48 85 c0             	test   %rax,%rax
    aba7:	74 61                	je     ac0a <fwp_hof0.constprop.0+0x170a>
    aba9:	48 89 c2             	mov    %rax,%rdx
    abac:	4c 39 20             	cmp    %r12,(%rax)
    abaf:	75 ef                	jne    aba0 <fwp_hof0.constprop.0+0x16a0>
    abb1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    abb5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    abb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    abbd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    abc4:	0f 85 66 f6 ff ff    	jne    a230 <fwp_hof0.constprop.0+0xd30>
    abca:	4c 89 e7             	mov    %r12,%rdi
    abcd:	e8 3e a7 ff ff       	call   5310 <fwp_rc_forget_slot>
    abd2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    abd7:	e9 54 f6 ff ff       	jmp    a230 <fwp_hof0.constprop.0+0xd30>
    abdc:	e8 0f a6 ff ff       	call   51f0 <fwp_rc_wide_dup>
    abe1:	e9 bc ea ff ff       	jmp    96a2 <fwp_hof0.constprop.0+0x1a2>
    abe6:	4c 89 e0             	mov    %r12,%rax
    abe9:	48 c1 e8 11          	shr    $0x11,%rax
    abed:	4c 31 e0             	xor    %r12,%rax
    abf0:	48 89 c2             	mov    %rax,%rdx
    abf3:	48 c1 ea 09          	shr    $0x9,%rdx
    abf7:	48 31 d0             	xor    %rdx,%rax
    abfa:	0f b6 d0             	movzbl %al,%edx
    abfd:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    ac04:	00 
    ac05:	48 85 c0             	test   %rax,%rax
    ac08:	75 5f                	jne    ac69 <fwp_hof0.constprop.0+0x1769>
    ac0a:	48 8d 3d 8f 4b 00 00 	lea    0x4b8f(%rip),%rdi        # f7a0 <_IO_stdin_used+0x7a0>
    ac11:	e8 8a 95 ff ff       	call   41a0 <fwp_trap>
    ac16:	48 89 ea             	mov    %rbp,%rdx
    ac19:	4c 89 cf             	mov    %r9,%rdi
    ac1c:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    ac20:	31 f6                	xor    %esi,%esi
    ac22:	48 c1 e2 03          	shl    $0x3,%rdx
    ac26:	48 89 0c 24          	mov    %rcx,(%rsp)
    ac2a:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    ac2f:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
    ac34:	e8 87 88 ff ff       	call   34c0 <memset@plt>
    ac39:	48 8b 0c 24          	mov    (%rsp),%rcx
    ac3d:	66 0f 6f 54 24 40    	movdqa 0x40(%rsp),%xmm2
    ac43:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    ac49:	49 89 c1             	mov    %rax,%r9
    ac4c:	e9 56 fc ff ff       	jmp    a8a7 <fwp_hof0.constprop.0+0x13a7>
    ac51:	0f 1f 40 00          	nopl   0x0(%rax)
    ac55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac5c:	00 00 00 00 
    ac60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ac64:	48 85 c0             	test   %rax,%rax
    ac67:	74 a1                	je     ac0a <fwp_hof0.constprop.0+0x170a>
    ac69:	48 89 c2             	mov    %rax,%rdx
    ac6c:	4c 3b 20             	cmp    (%rax),%r12
    ac6f:	75 ef                	jne    ac60 <fwp_hof0.constprop.0+0x1760>
    ac71:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ac75:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ac79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ac7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ac84:	0f 85 76 f7 ff ff    	jne    a400 <fwp_hof0.constprop.0+0xf00>
    ac8a:	4c 89 e7             	mov    %r12,%rdi
    ac8d:	e8 7e a6 ff ff       	call   5310 <fwp_rc_forget_slot>
    ac92:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    ac97:	e9 64 f7 ff ff       	jmp    a400 <fwp_hof0.constprop.0+0xf00>
    ac9c:	e8 4f a5 ff ff       	call   51f0 <fwp_rc_wide_dup>
    aca1:	e9 13 e9 ff ff       	jmp    95b9 <fwp_hof0.constprop.0+0xb9>
    aca6:	45 31 ff             	xor    %r15d,%r15d
    aca9:	e9 a7 f3 ff ff       	jmp    a055 <fwp_hof0.constprop.0+0xb55>
    acae:	48 8d 3d 13 4b 00 00 	lea    0x4b13(%rip),%rdi        # f7c8 <_IO_stdin_used+0x7c8>
    acb5:	e8 e6 94 ff ff       	call   41a0 <fwp_trap>
    acba:	48 8d 3d 43 44 00 00 	lea    0x4443(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    acc1:	e8 da 94 ff ff       	call   41a0 <fwp_trap>
    acc6:	48 8d 3d d3 4b 00 00 	lea    0x4bd3(%rip),%rdi        # f8a0 <_IO_stdin_used+0x8a0>
    accd:	e8 ce 94 ff ff       	call   41a0 <fwp_trap>
    acd2:	45 31 ed             	xor    %r13d,%r13d
    acd5:	e9 39 fa ff ff       	jmp    a713 <fwp_hof0.constprop.0+0x1213>
    acda:	48 8d 3d dd 44 00 00 	lea    0x44dd(%rip),%rdi        # f1be <_IO_stdin_used+0x1be>
    ace1:	e8 ba 94 ff ff       	call   41a0 <fwp_trap>
    ace6:	48 8d 3d eb 44 00 00 	lea    0x44eb(%rip),%rdi        # f1d8 <_IO_stdin_used+0x1d8>
    aced:	e8 ae 94 ff ff       	call   41a0 <fwp_trap>
    acf2:	48 8d 3d 34 44 00 00 	lea    0x4434(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    acf9:	e8 a2 94 ff ff       	call   41a0 <fwp_trap>
    acfe:	66 90                	xchg   %ax,%ax
    ad00:	48 8d 3d c1 4b 00 00 	lea    0x4bc1(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    ad07:	e8 94 94 ff ff       	call   41a0 <fwp_trap>
    ad0c:	48 85 d2             	test   %rdx,%rdx
    ad0f:	0f 84 8b fb ff ff    	je     a8a0 <fwp_hof0.constprop.0+0x13a0>
    ad15:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    ad1c:	00 
    ad1d:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    ad22:	48 89 05 cf a6 01 00 	mov    %rax,0x1a6cf(%rip)        # 253f8 <fwp_cleanups>
    ad29:	e8 02 a1 ff ff       	call   4e30 <fwp_tape_buffers_release>
    ad2e:	ba 13 00 00 00       	mov    $0x13,%edx
    ad33:	48 8b 0d 06 83 00 00 	mov    0x8306(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ad3a:	be 01 00 00 00       	mov    $0x1,%esi
    ad3f:	48 8d 3d c2 42 00 00 	lea    0x42c2(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ad46:	e8 35 89 ff ff       	call   3680 <fwrite@plt>
    ad4b:	31 ff                	xor    %edi,%edi
    ad4d:	e8 6e 88 ff ff       	call   35c0 <fflush@plt>
    ad52:	bf 66 00 00 00       	mov    $0x66,%edi
    ad57:	e8 44 89 ff ff       	call   36a0 <_Exit@plt>
    ad5c:	48 8d 3d 0d 4b 00 00 	lea    0x4b0d(%rip),%rdi        # f870 <_IO_stdin_used+0x870>
    ad63:	e8 38 94 ff ff       	call   41a0 <fwp_trap>
    ad68:	48 8b 0d d1 82 00 00 	mov    0x82d1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    ad6f:	ba 13 00 00 00       	mov    $0x13,%edx
    ad74:	be 01 00 00 00       	mov    $0x1,%esi
    ad79:	48 8d 3d 88 42 00 00 	lea    0x4288(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    ad80:	e8 fb 88 ff ff       	call   3680 <fwrite@plt>
    ad85:	31 ff                	xor    %edi,%edi
    ad87:	e8 34 88 ff ff       	call   35c0 <fflush@plt>
    ad8c:	bf 66 00 00 00       	mov    $0x66,%edi
    ad91:	e8 0a 89 ff ff       	call   36a0 <_Exit@plt>
    ad96:	48 8d 3d 73 4a 00 00 	lea    0x4a73(%rip),%rdi        # f810 <_IO_stdin_used+0x810>
    ad9d:	e8 fe 93 ff ff       	call   41a0 <fwp_trap>
    ada2:	e8 b9 86 ff ff       	call   3460 <__stack_chk_fail@plt>
    ada7:	48 8d 3d 3a 44 00 00 	lea    0x443a(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    adae:	e8 ed 93 ff ff       	call   41a0 <fwp_trap>
    adb3:	48 8b 0d 86 82 00 00 	mov    0x8286(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    adba:	ba 13 00 00 00       	mov    $0x13,%edx
    adbf:	be 01 00 00 00       	mov    $0x1,%esi
    adc4:	48 8d 3d 3d 42 00 00 	lea    0x423d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    adcb:	e8 b0 88 ff ff       	call   3680 <fwrite@plt>
    add0:	31 ff                	xor    %edi,%edi
    add2:	e8 e9 87 ff ff       	call   35c0 <fflush@plt>
    add7:	bf 66 00 00 00       	mov    $0x66,%edi
    addc:	e8 bf 88 ff ff       	call   36a0 <_Exit@plt>
    ade1:	0f 1f 40 00          	nopl   0x0(%rax)
    ade5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    adec:	00 00 00 00 

000000000000adf0 <f0>:
    adf0:	41 56                	push   %r14
    adf2:	4c 8d 35 67 89 01 00 	lea    0x18967(%rip),%r14        # 23760 <fwp_heap>
    adf9:	41 55                	push   %r13
    adfb:	41 54                	push   %r12
    adfd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    ae03:	55                   	push   %rbp
    ae04:	53                   	push   %rbx
    ae05:	31 db                	xor    %ebx,%ebx
    ae07:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    ae0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ae15:	00 00 
    ae17:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    ae1e:	00 
    ae1f:	31 c0                	xor    %eax,%eax
    ae21:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    ae28:	00 
    ae29:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    ae30:	00 00 
    ae32:	66 48 0f 6e c0       	movq   %rax,%xmm0
    ae37:	48 8d 05 f2 cc ff ff 	lea    -0x330e(%rip),%rax        # 7b30 <fwp_drop1>
    ae3e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    ae43:	48 8b 05 ae a5 01 00 	mov    0x1a5ae(%rip),%rax        # 253f8 <fwp_cleanups>
    ae4a:	48 89 25 a7 a5 01 00 	mov    %rsp,0x1a5a7(%rip)        # 253f8 <fwp_cleanups>
    ae51:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    ae55:	48 89 04 24          	mov    %rax,(%rsp)
    ae59:	48 8d 05 70 8d ff ff 	lea    -0x7290(%rip),%rax        # 3bd0 <fwp_range_release>
    ae60:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ae65:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    ae6a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ae6f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    ae74:	eb 47                	jmp    aebd <f0+0xcd>
    ae76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae7d:	00 00 00 
    ae80:	80 f9 01             	cmp    $0x1,%cl
    ae83:	75 29                	jne    aeae <f0+0xbe>
    ae85:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae88:	0f b7 c0             	movzwl %ax,%eax
    ae8b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae8e:	48 0f af c1          	imul   %rcx,%rax
    ae92:	48 c1 e8 20          	shr    $0x20,%rax
    ae96:	48 39 d0             	cmp    %rdx,%rax
    ae99:	73 13                	jae    aeae <f0+0xbe>
    ae9b:	49 01 c5             	add    %rax,%r13
    ae9e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    aea3:	0f 84 c7 27 00 00    	je     d670 <f0+0x2880>
    aea9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    aeae:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    aeb3:	49 83 ec 01          	sub    $0x1,%r12
    aeb7:	0f 82 83 00 00 00    	jb     af40 <f0+0x150>
    aebd:	48 89 ee             	mov    %rbp,%rsi
    aec0:	bf 01 00 00 00       	mov    $0x1,%edi
    aec5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    aecc:	00 
    aecd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    aed2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    aed9:	00 
    aeda:	e8 91 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    aedf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    aee6:	48 89 c3             	mov    %rax,%rbx
    aee9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    aef0:	48 c1 e2 10          	shl    $0x10,%rdx
    aef4:	48 39 d0             	cmp    %rdx,%rax
    aef7:	73 b5                	jae    aeae <f0+0xbe>
    aef9:	48 89 c2             	mov    %rax,%rdx
    aefc:	48 c1 ea 10          	shr    $0x10,%rdx
    af00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af04:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    af0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af0f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    af13:	4d 85 ed             	test   %r13,%r13
    af16:	74 96                	je     aeae <f0+0xbe>
    af18:	0f b6 0a             	movzbl (%rdx),%ecx
    af1b:	80 f9 02             	cmp    $0x2,%cl
    af1e:	0f 85 5c ff ff ff    	jne    ae80 <f0+0x90>
    af24:	66 85 c0             	test   %ax,%ax
    af27:	0f 84 71 ff ff ff    	je     ae9e <f0+0xae>
    af2d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    af32:	49 83 ec 01          	sub    $0x1,%r12
    af36:	73 85                	jae    aebd <f0+0xcd>
    af38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    af3f:	00 
    af40:	48 8b 04 24          	mov    (%rsp),%rax
    af44:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    af49:	bf 01 00 00 00       	mov    $0x1,%edi
    af4e:	66 0f 6f 05 fa 4b 00 	movdqa 0x4bfa(%rip),%xmm0        # fb50 <msg.4+0xd0>
    af55:	00 
    af56:	48 89 05 9b a4 01 00 	mov    %rax,0x1a49b(%rip)        # 253f8 <fwp_cleanups>
    af5d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    af62:	e8 09 ac ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    af67:	48 8b 15 ca 9b 01 00 	mov    0x19bca(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    af6e:	49 89 c5             	mov    %rax,%r13
    af71:	48 2b 05 98 9b 01 00 	sub    0x19b98(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    af78:	48 c1 e2 10          	shl    $0x10,%rdx
    af7c:	48 39 d0             	cmp    %rdx,%rax
    af7f:	73 59                	jae    afda <f0+0x1ea>
    af81:	48 89 c2             	mov    %rax,%rdx
    af84:	48 c1 ea 10          	shr    $0x10,%rdx
    af88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af8c:	48 8b 15 c5 9b 01 00 	mov    0x19bc5(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    af93:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af97:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    af9b:	4d 85 e4             	test   %r12,%r12
    af9e:	74 3a                	je     afda <f0+0x1ea>
    afa0:	0f b6 0a             	movzbl (%rdx),%ecx
    afa3:	80 f9 02             	cmp    $0x2,%cl
    afa6:	0f 84 74 27 00 00    	je     d720 <f0+0x2930>
    afac:	80 f9 01             	cmp    $0x1,%cl
    afaf:	75 29                	jne    afda <f0+0x1ea>
    afb1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    afb4:	0f b7 c0             	movzwl %ax,%eax
    afb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    afba:	48 0f af c1          	imul   %rcx,%rax
    afbe:	48 c1 e8 20          	shr    $0x20,%rax
    afc2:	48 39 d0             	cmp    %rdx,%rax
    afc5:	73 13                	jae    afda <f0+0x1ea>
    afc7:	49 01 c4             	add    %rax,%r12
    afca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    afcf:	0f 84 26 29 00 00    	je     d8fb <f0+0x2b0b>
    afd5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    afda:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    afdf:	bf 01 00 00 00       	mov    $0x1,%edi
    afe4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    afe9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    aff0:	00 f0 3f 
    aff3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    aff8:	e8 73 ab ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    affd:	48 8b 15 34 9b 01 00 	mov    0x19b34(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    b004:	49 89 c5             	mov    %rax,%r13
    b007:	48 2b 05 02 9b 01 00 	sub    0x19b02(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    b00e:	48 c1 e2 10          	shl    $0x10,%rdx
    b012:	48 39 d0             	cmp    %rdx,%rax
    b015:	73 59                	jae    b070 <f0+0x280>
    b017:	48 89 c2             	mov    %rax,%rdx
    b01a:	48 c1 ea 10          	shr    $0x10,%rdx
    b01e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b022:	48 8b 15 2f 9b 01 00 	mov    0x19b2f(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    b029:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b02d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b031:	4d 85 e4             	test   %r12,%r12
    b034:	74 3a                	je     b070 <f0+0x280>
    b036:	0f b6 0a             	movzbl (%rdx),%ecx
    b039:	80 f9 02             	cmp    $0x2,%cl
    b03c:	0f 84 ce 26 00 00    	je     d710 <f0+0x2920>
    b042:	80 f9 01             	cmp    $0x1,%cl
    b045:	75 29                	jne    b070 <f0+0x280>
    b047:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b04a:	0f b7 c0             	movzwl %ax,%eax
    b04d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b050:	48 0f af c1          	imul   %rcx,%rax
    b054:	48 c1 e8 20          	shr    $0x20,%rax
    b058:	48 39 d0             	cmp    %rdx,%rax
    b05b:	73 13                	jae    b070 <f0+0x280>
    b05d:	49 01 c4             	add    %rax,%r12
    b060:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b065:	0f 84 9d 28 00 00    	je     d908 <f0+0x2b18>
    b06b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b070:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b075:	bf 01 00 00 00       	mov    $0x1,%edi
    b07a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b07f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b086:	33 f3 bf 
    b089:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b08e:	e8 dd aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b093:	48 8b 15 9e 9a 01 00 	mov    0x19a9e(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    b09a:	49 89 c5             	mov    %rax,%r13
    b09d:	48 2b 05 6c 9a 01 00 	sub    0x19a6c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    b0a4:	48 c1 e2 10          	shl    $0x10,%rdx
    b0a8:	48 39 d0             	cmp    %rdx,%rax
    b0ab:	73 59                	jae    b106 <f0+0x316>
    b0ad:	48 89 c2             	mov    %rax,%rdx
    b0b0:	48 c1 ea 10          	shr    $0x10,%rdx
    b0b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0b8:	48 8b 15 99 9a 01 00 	mov    0x19a99(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    b0bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0c3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b0c7:	4d 85 e4             	test   %r12,%r12
    b0ca:	74 3a                	je     b106 <f0+0x316>
    b0cc:	0f b6 0a             	movzbl (%rdx),%ecx
    b0cf:	80 f9 02             	cmp    $0x2,%cl
    b0d2:	0f 84 28 26 00 00    	je     d700 <f0+0x2910>
    b0d8:	80 f9 01             	cmp    $0x1,%cl
    b0db:	75 29                	jne    b106 <f0+0x316>
    b0dd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0e0:	0f b7 c0             	movzwl %ax,%eax
    b0e3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0e6:	48 0f af c1          	imul   %rcx,%rax
    b0ea:	48 c1 e8 20          	shr    $0x20,%rax
    b0ee:	48 39 d0             	cmp    %rdx,%rax
    b0f1:	73 13                	jae    b106 <f0+0x316>
    b0f3:	49 01 c4             	add    %rax,%r12
    b0f6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0fb:	0f 84 14 28 00 00    	je     d915 <f0+0x2b25>
    b101:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b106:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b10b:	bf 01 00 00 00       	mov    $0x1,%edi
    b110:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b115:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b11c:	00 f0 3f 
    b11f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b124:	e8 47 aa ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b129:	48 8b 15 08 9a 01 00 	mov    0x19a08(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    b130:	49 89 c5             	mov    %rax,%r13
    b133:	48 2b 05 d6 99 01 00 	sub    0x199d6(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    b13a:	48 c1 e2 10          	shl    $0x10,%rdx
    b13e:	48 39 d0             	cmp    %rdx,%rax
    b141:	73 59                	jae    b19c <f0+0x3ac>
    b143:	48 89 c2             	mov    %rax,%rdx
    b146:	48 c1 ea 10          	shr    $0x10,%rdx
    b14a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b14e:	48 8b 15 03 9a 01 00 	mov    0x19a03(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    b155:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b159:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b15d:	4d 85 e4             	test   %r12,%r12
    b160:	74 3a                	je     b19c <f0+0x3ac>
    b162:	0f b6 0a             	movzbl (%rdx),%ecx
    b165:	80 f9 02             	cmp    $0x2,%cl
    b168:	0f 84 f2 25 00 00    	je     d760 <f0+0x2970>
    b16e:	80 f9 01             	cmp    $0x1,%cl
    b171:	75 29                	jne    b19c <f0+0x3ac>
    b173:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b176:	0f b7 c0             	movzwl %ax,%eax
    b179:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b17c:	48 0f af c1          	imul   %rcx,%rax
    b180:	48 c1 e8 20          	shr    $0x20,%rax
    b184:	48 39 d0             	cmp    %rdx,%rax
    b187:	73 13                	jae    b19c <f0+0x3ac>
    b189:	49 01 c4             	add    %rax,%r12
    b18c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b191:	0f 84 8b 27 00 00    	je     d922 <f0+0x2b32>
    b197:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b19c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b1a3:	33 f3 bf 
    b1a6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b1ad:	00 
    b1ae:	bf 01 00 00 00       	mov    $0x1,%edi
    b1b3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b1ba:	00 
    b1bb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b1c2:	00 
    b1c3:	e8 a8 a9 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b1c8:	48 8b 15 69 99 01 00 	mov    0x19969(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    b1cf:	49 89 c5             	mov    %rax,%r13
    b1d2:	48 2b 05 37 99 01 00 	sub    0x19937(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    b1d9:	48 c1 e2 10          	shl    $0x10,%rdx
    b1dd:	48 39 d0             	cmp    %rdx,%rax
    b1e0:	73 59                	jae    b23b <f0+0x44b>
    b1e2:	48 89 c2             	mov    %rax,%rdx
    b1e5:	48 c1 ea 10          	shr    $0x10,%rdx
    b1e9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1ed:	48 8b 15 64 99 01 00 	mov    0x19964(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    b1f4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1f8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b1fc:	4d 85 e4             	test   %r12,%r12
    b1ff:	74 3a                	je     b23b <f0+0x44b>
    b201:	0f b6 0a             	movzbl (%rdx),%ecx
    b204:	80 f9 02             	cmp    $0x2,%cl
    b207:	0f 84 43 25 00 00    	je     d750 <f0+0x2960>
    b20d:	80 f9 01             	cmp    $0x1,%cl
    b210:	75 29                	jne    b23b <f0+0x44b>
    b212:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b215:	0f b7 c0             	movzwl %ax,%eax
    b218:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b21b:	48 0f af c1          	imul   %rcx,%rax
    b21f:	48 c1 e8 20          	shr    $0x20,%rax
    b223:	48 39 d0             	cmp    %rdx,%rax
    b226:	73 13                	jae    b23b <f0+0x44b>
    b228:	49 01 c4             	add    %rax,%r12
    b22b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b230:	0f 84 f9 26 00 00    	je     d92f <f0+0x2b3f>
    b236:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b23b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b242:	00 f0 3f 
    b245:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b24c:	00 
    b24d:	bf 01 00 00 00       	mov    $0x1,%edi
    b252:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b259:	00 
    b25a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b261:	00 
    b262:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b269:	33 f3 bf 
    b26c:	e8 ff a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b271:	48 89 c7             	mov    %rax,%rdi
    b274:	e8 97 b4 ff ff       	call   6710 <fwp_rc_fresh>
    b279:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b280:	00 
    b281:	bf 01 00 00 00       	mov    $0x1,%edi
    b286:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b28d:	00 
    b28e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b295:	00 
    b296:	e8 d5 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b29b:	48 89 c7             	mov    %rax,%rdi
    b29e:	e8 6d b4 ff ff       	call   6710 <fwp_rc_fresh>
    b2a3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b2aa:	00 
    b2ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b2b0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b2b7:	00 
    b2b8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b2bf:	00 
    b2c0:	e8 ab a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2c5:	48 89 c7             	mov    %rax,%rdi
    b2c8:	e8 43 b4 ff ff       	call   6710 <fwp_rc_fresh>
    b2cd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b2d4:	00 
    b2d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b2da:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b2e1:	00 
    b2e2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b2e9:	00 
    b2ea:	e8 81 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b2ef:	48 89 c7             	mov    %rax,%rdi
    b2f2:	e8 19 b4 ff ff       	call   6710 <fwp_rc_fresh>
    b2f7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b2fe:	00 
    b2ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b304:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b30b:	00 
    b30c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b313:	00 
    b314:	e8 57 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b319:	48 89 c7             	mov    %rax,%rdi
    b31c:	e8 ef b3 ff ff       	call   6710 <fwp_rc_fresh>
    b321:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b328:	00 
    b329:	bf 01 00 00 00       	mov    $0x1,%edi
    b32e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b335:	00 
    b336:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b33d:	00 
    b33e:	e8 2d a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b343:	48 89 c7             	mov    %rax,%rdi
    b346:	e8 c5 b3 ff ff       	call   6710 <fwp_rc_fresh>
    b34b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b352:	00 
    b353:	bf 01 00 00 00       	mov    $0x1,%edi
    b358:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b35f:	00 
    b360:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b367:	00 
    b368:	e8 03 a8 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b36d:	48 89 c7             	mov    %rax,%rdi
    b370:	e8 9b b3 ff ff       	call   6710 <fwp_rc_fresh>
    b375:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b37c:	00 
    b37d:	bf 01 00 00 00       	mov    $0x1,%edi
    b382:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b389:	00 
    b38a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b391:	00 
    b392:	e8 d9 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b397:	48 89 c7             	mov    %rax,%rdi
    b39a:	e8 71 b3 ff ff       	call   6710 <fwp_rc_fresh>
    b39f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b3a6:	00 
    b3a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b3ac:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b3b3:	00 
    b3b4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b3bb:	00 
    b3bc:	e8 af a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3c1:	48 89 c7             	mov    %rax,%rdi
    b3c4:	e8 47 b3 ff ff       	call   6710 <fwp_rc_fresh>
    b3c9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b3d0:	00 
    b3d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b3d6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b3dd:	00 
    b3de:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b3e5:	00 
    b3e6:	e8 85 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b3eb:	48 89 c7             	mov    %rax,%rdi
    b3ee:	e8 1d b3 ff ff       	call   6710 <fwp_rc_fresh>
    b3f3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b3fa:	00 
    b3fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b400:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b407:	00 
    b408:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b40f:	00 
    b410:	e8 5b a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b415:	48 89 c7             	mov    %rax,%rdi
    b418:	e8 f3 b2 ff ff       	call   6710 <fwp_rc_fresh>
    b41d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b424:	00 
    b425:	bf 01 00 00 00       	mov    $0x1,%edi
    b42a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b431:	00 
    b432:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b439:	00 
    b43a:	e8 31 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b43f:	48 89 c7             	mov    %rax,%rdi
    b442:	e8 c9 b2 ff ff       	call   6710 <fwp_rc_fresh>
    b447:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b44e:	00 
    b44f:	bf 01 00 00 00       	mov    $0x1,%edi
    b454:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b45b:	00 
    b45c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b463:	00 
    b464:	e8 07 a7 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b469:	48 89 c7             	mov    %rax,%rdi
    b46c:	e8 9f b2 ff ff       	call   6710 <fwp_rc_fresh>
    b471:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b478:	00 
    b479:	bf 01 00 00 00       	mov    $0x1,%edi
    b47e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b485:	00 
    b486:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b48d:	00 
    b48e:	e8 dd a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b493:	48 89 c7             	mov    %rax,%rdi
    b496:	e8 75 b2 ff ff       	call   6710 <fwp_rc_fresh>
    b49b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b4a2:	00 
    b4a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b4a8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b4af:	00 
    b4b0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b4b7:	00 
    b4b8:	e8 b3 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4bd:	48 89 c7             	mov    %rax,%rdi
    b4c0:	e8 4b b2 ff ff       	call   6710 <fwp_rc_fresh>
    b4c5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b4cc:	00 
    b4cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b4d9:	00 
    b4da:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b4e1:	00 
    b4e2:	e8 89 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b4e7:	48 89 c7             	mov    %rax,%rdi
    b4ea:	e8 21 b2 ff ff       	call   6710 <fwp_rc_fresh>
    b4ef:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b4f6:	00 
    b4f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b4fc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b503:	00 
    b504:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b50b:	00 
    b50c:	e8 5f a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b511:	48 89 c7             	mov    %rax,%rdi
    b514:	e8 f7 b1 ff ff       	call   6710 <fwp_rc_fresh>
    b519:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b520:	00 
    b521:	bf 01 00 00 00       	mov    $0x1,%edi
    b526:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b52d:	00 
    b52e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b535:	00 
    b536:	e8 35 a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b53b:	48 89 c7             	mov    %rax,%rdi
    b53e:	e8 cd b1 ff ff       	call   6710 <fwp_rc_fresh>
    b543:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b54a:	00 
    b54b:	bf 01 00 00 00       	mov    $0x1,%edi
    b550:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b557:	00 
    b558:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b55f:	00 
    b560:	e8 0b a6 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b565:	48 89 c7             	mov    %rax,%rdi
    b568:	e8 a3 b1 ff ff       	call   6710 <fwp_rc_fresh>
    b56d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b574:	00 
    b575:	bf 01 00 00 00       	mov    $0x1,%edi
    b57a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b581:	00 
    b582:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b589:	00 
    b58a:	e8 e1 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b58f:	48 89 c7             	mov    %rax,%rdi
    b592:	e8 79 b1 ff ff       	call   6710 <fwp_rc_fresh>
    b597:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b59e:	00 
    b59f:	bf 01 00 00 00       	mov    $0x1,%edi
    b5a4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b5ab:	00 
    b5ac:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b5b3:	00 
    b5b4:	e8 b7 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5b9:	48 89 c7             	mov    %rax,%rdi
    b5bc:	e8 4f b1 ff ff       	call   6710 <fwp_rc_fresh>
    b5c1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b5c8:	00 
    b5c9:	bf 01 00 00 00       	mov    $0x1,%edi
    b5ce:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b5d5:	00 
    b5d6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b5dd:	00 
    b5de:	e8 8d a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b5e3:	48 89 c7             	mov    %rax,%rdi
    b5e6:	e8 25 b1 ff ff       	call   6710 <fwp_rc_fresh>
    b5eb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b5f2:	00 
    b5f3:	bf 01 00 00 00       	mov    $0x1,%edi
    b5f8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b5ff:	00 
    b600:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b607:	00 
    b608:	e8 63 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b60d:	48 89 c7             	mov    %rax,%rdi
    b610:	e8 fb b0 ff ff       	call   6710 <fwp_rc_fresh>
    b615:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b61c:	00 
    b61d:	bf 01 00 00 00       	mov    $0x1,%edi
    b622:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b629:	00 
    b62a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b631:	00 
    b632:	e8 39 a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b637:	48 89 c7             	mov    %rax,%rdi
    b63a:	e8 d1 b0 ff ff       	call   6710 <fwp_rc_fresh>
    b63f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b646:	00 
    b647:	bf 01 00 00 00       	mov    $0x1,%edi
    b64c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b653:	00 
    b654:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b65b:	00 
    b65c:	e8 0f a5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b661:	48 89 c7             	mov    %rax,%rdi
    b664:	e8 a7 b0 ff ff       	call   6710 <fwp_rc_fresh>
    b669:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b670:	00 
    b671:	bf 01 00 00 00       	mov    $0x1,%edi
    b676:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b67d:	00 
    b67e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b685:	00 
    b686:	e8 e5 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b68b:	48 89 c7             	mov    %rax,%rdi
    b68e:	e8 7d b0 ff ff       	call   6710 <fwp_rc_fresh>
    b693:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b69a:	00 
    b69b:	bf 01 00 00 00       	mov    $0x1,%edi
    b6a0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b6a7:	00 
    b6a8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b6af:	00 
    b6b0:	e8 bb a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6b5:	48 89 c7             	mov    %rax,%rdi
    b6b8:	e8 53 b0 ff ff       	call   6710 <fwp_rc_fresh>
    b6bd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b6c4:	00 
    b6c5:	bf 01 00 00 00       	mov    $0x1,%edi
    b6ca:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b6d1:	00 
    b6d2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b6d9:	00 
    b6da:	e8 91 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b6df:	48 89 c7             	mov    %rax,%rdi
    b6e2:	e8 29 b0 ff ff       	call   6710 <fwp_rc_fresh>
    b6e7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b6ee:	00 
    b6ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b6f4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b6fb:	00 
    b6fc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b703:	00 
    b704:	e8 67 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b709:	48 89 c7             	mov    %rax,%rdi
    b70c:	e8 ff af ff ff       	call   6710 <fwp_rc_fresh>
    b711:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b718:	00 
    b719:	bf 01 00 00 00       	mov    $0x1,%edi
    b71e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b725:	00 
    b726:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b72d:	00 
    b72e:	e8 3d a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b733:	48 89 c7             	mov    %rax,%rdi
    b736:	e8 d5 af ff ff       	call   6710 <fwp_rc_fresh>
    b73b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b742:	00 
    b743:	bf 01 00 00 00       	mov    $0x1,%edi
    b748:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b74f:	00 
    b750:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b757:	00 
    b758:	e8 13 a4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b75d:	48 89 c7             	mov    %rax,%rdi
    b760:	e8 ab af ff ff       	call   6710 <fwp_rc_fresh>
    b765:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b76c:	00 
    b76d:	bf 01 00 00 00       	mov    $0x1,%edi
    b772:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b779:	00 
    b77a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b781:	00 
    b782:	e8 e9 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b787:	48 89 c7             	mov    %rax,%rdi
    b78a:	e8 81 af ff ff       	call   6710 <fwp_rc_fresh>
    b78f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b796:	00 
    b797:	bf 01 00 00 00       	mov    $0x1,%edi
    b79c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    b7a3:	00 
    b7a4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    b7ab:	00 
    b7ac:	e8 bf a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7b1:	48 89 c7             	mov    %rax,%rdi
    b7b4:	e8 57 af ff ff       	call   6710 <fwp_rc_fresh>
    b7b9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    b7c0:	00 
    b7c1:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    b7cd:	00 
    b7ce:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    b7d5:	00 
    b7d6:	e8 95 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b7db:	48 89 c7             	mov    %rax,%rdi
    b7de:	e8 2d af ff ff       	call   6710 <fwp_rc_fresh>
    b7e3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    b7ea:	00 
    b7eb:	bf 01 00 00 00       	mov    $0x1,%edi
    b7f0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    b7f7:	00 
    b7f8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    b7ff:	00 
    b800:	e8 6b a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b805:	48 89 c7             	mov    %rax,%rdi
    b808:	e8 03 af ff ff       	call   6710 <fwp_rc_fresh>
    b80d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    b814:	00 
    b815:	bf 01 00 00 00       	mov    $0x1,%edi
    b81a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    b821:	00 
    b822:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    b829:	00 
    b82a:	e8 41 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b82f:	48 89 c7             	mov    %rax,%rdi
    b832:	e8 d9 ae ff ff       	call   6710 <fwp_rc_fresh>
    b837:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    b83e:	00 
    b83f:	bf 01 00 00 00       	mov    $0x1,%edi
    b844:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    b84b:	00 
    b84c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    b853:	00 
    b854:	e8 17 a3 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b859:	48 89 c7             	mov    %rax,%rdi
    b85c:	e8 af ae ff ff       	call   6710 <fwp_rc_fresh>
    b861:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    b868:	00 
    b869:	bf 01 00 00 00       	mov    $0x1,%edi
    b86e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    b875:	00 
    b876:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    b87d:	00 
    b87e:	e8 ed a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b883:	48 89 c7             	mov    %rax,%rdi
    b886:	e8 85 ae ff ff       	call   6710 <fwp_rc_fresh>
    b88b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    b892:	00 
    b893:	bf 01 00 00 00       	mov    $0x1,%edi
    b898:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    b89f:	00 
    b8a0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    b8a7:	00 
    b8a8:	e8 c3 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8ad:	48 89 c7             	mov    %rax,%rdi
    b8b0:	e8 5b ae ff ff       	call   6710 <fwp_rc_fresh>
    b8b5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    b8bc:	00 
    b8bd:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    b8c9:	00 
    b8ca:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    b8d1:	00 
    b8d2:	e8 99 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b8d7:	48 89 c7             	mov    %rax,%rdi
    b8da:	e8 31 ae ff ff       	call   6710 <fwp_rc_fresh>
    b8df:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    b8e6:	00 
    b8e7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ec:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    b8f3:	00 
    b8f4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    b8fb:	00 
    b8fc:	e8 6f a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b901:	48 89 c7             	mov    %rax,%rdi
    b904:	e8 07 ae ff ff       	call   6710 <fwp_rc_fresh>
    b909:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    b910:	00 
    b911:	bf 01 00 00 00       	mov    $0x1,%edi
    b916:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    b91d:	00 
    b91e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    b925:	00 
    b926:	e8 45 a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b92b:	48 89 c7             	mov    %rax,%rdi
    b92e:	e8 dd ad ff ff       	call   6710 <fwp_rc_fresh>
    b933:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    b93a:	00 
    b93b:	bf 01 00 00 00       	mov    $0x1,%edi
    b940:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    b947:	00 
    b948:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    b94f:	00 
    b950:	e8 1b a2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b955:	48 89 c7             	mov    %rax,%rdi
    b958:	e8 b3 ad ff ff       	call   6710 <fwp_rc_fresh>
    b95d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    b964:	00 
    b965:	bf 01 00 00 00       	mov    $0x1,%edi
    b96a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    b971:	00 
    b972:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    b979:	00 
    b97a:	e8 f1 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b97f:	48 89 c7             	mov    %rax,%rdi
    b982:	e8 89 ad ff ff       	call   6710 <fwp_rc_fresh>
    b987:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    b98e:	00 
    b98f:	bf 01 00 00 00       	mov    $0x1,%edi
    b994:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    b99b:	00 
    b99c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    b9a3:	00 
    b9a4:	e8 c7 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9a9:	48 89 c7             	mov    %rax,%rdi
    b9ac:	e8 5f ad ff ff       	call   6710 <fwp_rc_fresh>
    b9b1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    b9b8:	00 
    b9b9:	bf 01 00 00 00       	mov    $0x1,%edi
    b9be:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    b9c5:	00 
    b9c6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    b9cd:	00 
    b9ce:	e8 9d a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9d3:	48 89 c7             	mov    %rax,%rdi
    b9d6:	e8 35 ad ff ff       	call   6710 <fwp_rc_fresh>
    b9db:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    b9e2:	00 
    b9e3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    b9ef:	00 
    b9f0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    b9f7:	00 
    b9f8:	e8 73 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    b9fd:	48 89 c7             	mov    %rax,%rdi
    ba00:	e8 0b ad ff ff       	call   6710 <fwp_rc_fresh>
    ba05:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    ba0c:	00 
    ba0d:	bf 01 00 00 00       	mov    $0x1,%edi
    ba12:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    ba19:	00 
    ba1a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    ba21:	00 
    ba22:	e8 49 a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba27:	48 89 c7             	mov    %rax,%rdi
    ba2a:	e8 e1 ac ff ff       	call   6710 <fwp_rc_fresh>
    ba2f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    ba36:	00 
    ba37:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    ba43:	00 
    ba44:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    ba4b:	00 
    ba4c:	e8 1f a1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba51:	48 89 c7             	mov    %rax,%rdi
    ba54:	e8 b7 ac ff ff       	call   6710 <fwp_rc_fresh>
    ba59:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    ba60:	00 
    ba61:	bf 01 00 00 00       	mov    $0x1,%edi
    ba66:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    ba6d:	00 
    ba6e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    ba75:	00 
    ba76:	e8 f5 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ba7b:	48 89 c7             	mov    %rax,%rdi
    ba7e:	e8 8d ac ff ff       	call   6710 <fwp_rc_fresh>
    ba83:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    ba8a:	00 
    ba8b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba90:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    ba97:	00 
    ba98:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    ba9f:	00 
    baa0:	e8 cb a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    baa5:	48 89 c7             	mov    %rax,%rdi
    baa8:	e8 63 ac ff ff       	call   6710 <fwp_rc_fresh>
    baad:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bab4:	00 
    bab5:	bf 01 00 00 00       	mov    $0x1,%edi
    baba:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bac1:	00 
    bac2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bac9:	00 
    baca:	e8 a1 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bacf:	48 89 c7             	mov    %rax,%rdi
    bad2:	e8 39 ac ff ff       	call   6710 <fwp_rc_fresh>
    bad7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bade:	00 
    badf:	bf 01 00 00 00       	mov    $0x1,%edi
    bae4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    baeb:	00 
    baec:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    baf3:	00 
    baf4:	e8 77 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    baf9:	48 89 c7             	mov    %rax,%rdi
    bafc:	e8 0f ac ff ff       	call   6710 <fwp_rc_fresh>
    bb01:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bb08:	00 
    bb09:	bf 01 00 00 00       	mov    $0x1,%edi
    bb0e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bb15:	00 
    bb16:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bb1d:	00 
    bb1e:	e8 4d a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb23:	48 89 c7             	mov    %rax,%rdi
    bb26:	e8 e5 ab ff ff       	call   6710 <fwp_rc_fresh>
    bb2b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bb32:	00 
    bb33:	bf 01 00 00 00       	mov    $0x1,%edi
    bb38:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bb3f:	00 
    bb40:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bb47:	00 
    bb48:	e8 23 a0 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb4d:	48 89 c7             	mov    %rax,%rdi
    bb50:	e8 bb ab ff ff       	call   6710 <fwp_rc_fresh>
    bb55:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bb5c:	00 
    bb5d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb62:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bb69:	00 
    bb6a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bb71:	00 
    bb72:	e8 f9 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bb77:	48 89 c7             	mov    %rax,%rdi
    bb7a:	e8 91 ab ff ff       	call   6710 <fwp_rc_fresh>
    bb7f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bb86:	00 
    bb87:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bb93:	00 
    bb94:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bb9b:	00 
    bb9c:	e8 cf 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bba1:	48 89 c7             	mov    %rax,%rdi
    bba4:	e8 67 ab ff ff       	call   6710 <fwp_rc_fresh>
    bba9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    bbb0:	00 
    bbb1:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    bbbd:	00 
    bbbe:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    bbc5:	00 
    bbc6:	e8 a5 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbcb:	48 89 c7             	mov    %rax,%rdi
    bbce:	e8 3d ab ff ff       	call   6710 <fwp_rc_fresh>
    bbd3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    bbda:	00 
    bbdb:	bf 01 00 00 00       	mov    $0x1,%edi
    bbe0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    bbe7:	00 
    bbe8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    bbef:	00 
    bbf0:	e8 7b 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bbf5:	48 89 c7             	mov    %rax,%rdi
    bbf8:	e8 13 ab ff ff       	call   6710 <fwp_rc_fresh>
    bbfd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    bc04:	00 
    bc05:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    bc11:	00 
    bc12:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    bc19:	00 
    bc1a:	e8 51 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc1f:	48 89 c7             	mov    %rax,%rdi
    bc22:	e8 e9 aa ff ff       	call   6710 <fwp_rc_fresh>
    bc27:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    bc2e:	00 
    bc2f:	bf 01 00 00 00       	mov    $0x1,%edi
    bc34:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    bc3b:	00 
    bc3c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bc43:	00 
    bc44:	e8 27 9f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc49:	48 89 c7             	mov    %rax,%rdi
    bc4c:	e8 bf aa ff ff       	call   6710 <fwp_rc_fresh>
    bc51:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    bc58:	00 
    bc59:	bf 01 00 00 00       	mov    $0x1,%edi
    bc5e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bc65:	00 
    bc66:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    bc6d:	00 
    bc6e:	e8 fd 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc73:	48 89 c7             	mov    %rax,%rdi
    bc76:	e8 95 aa ff ff       	call   6710 <fwp_rc_fresh>
    bc7b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bc82:	00 
    bc83:	bf 01 00 00 00       	mov    $0x1,%edi
    bc88:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    bc8f:	00 
    bc90:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bc97:	00 
    bc98:	e8 d3 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bc9d:	48 89 c7             	mov    %rax,%rdi
    bca0:	e8 6b aa ff ff       	call   6710 <fwp_rc_fresh>
    bca5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bcac:	00 
    bcad:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bcb9:	00 
    bcba:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bcc1:	00 
    bcc2:	e8 a9 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bcc7:	48 89 c7             	mov    %rax,%rdi
    bcca:	e8 41 aa ff ff       	call   6710 <fwp_rc_fresh>
    bccf:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bcd6:	00 
    bcd7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcdc:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bce3:	00 
    bce4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bceb:	00 
    bcec:	e8 7f 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bcf1:	48 89 c7             	mov    %rax,%rdi
    bcf4:	e8 17 aa ff ff       	call   6710 <fwp_rc_fresh>
    bcf9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bd00:	00 
    bd01:	bf 01 00 00 00       	mov    $0x1,%edi
    bd06:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    bd0d:	00 
    bd0e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    bd15:	00 
    bd16:	e8 55 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd1b:	48 89 c7             	mov    %rax,%rdi
    bd1e:	e8 ed a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd23:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bd2a:	00 
    bd2b:	bf 01 00 00 00       	mov    $0x1,%edi
    bd30:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bd37:	00 
    bd38:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bd3f:	00 
    bd40:	e8 2b 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd45:	48 89 c7             	mov    %rax,%rdi
    bd48:	e8 c3 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd4d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bd54:	00 
    bd55:	bf 01 00 00 00       	mov    $0x1,%edi
    bd5a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bd61:	00 
    bd62:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bd69:	00 
    bd6a:	e8 01 9e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd6f:	48 89 c7             	mov    %rax,%rdi
    bd72:	e8 99 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bd77:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bd7e:	00 
    bd7f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd84:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    bd8b:	00 
    bd8c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    bd93:	00 
    bd94:	e8 d7 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bd99:	48 89 c7             	mov    %rax,%rdi
    bd9c:	e8 6f a9 ff ff       	call   6710 <fwp_rc_fresh>
    bda1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    bda8:	00 
    bda9:	bf 01 00 00 00       	mov    $0x1,%edi
    bdae:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    bdb5:	00 
    bdb6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    bdbd:	00 
    bdbe:	e8 ad 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bdc3:	48 89 c7             	mov    %rax,%rdi
    bdc6:	e8 45 a9 ff ff       	call   6710 <fwp_rc_fresh>
    bdcb:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    bdd2:	00 
    bdd3:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    bddf:	00 
    bde0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    bde7:	00 
    bde8:	e8 83 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bded:	48 89 c7             	mov    %rax,%rdi
    bdf0:	e8 1b a9 ff ff       	call   6710 <fwp_rc_fresh>
    bdf5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    bdfc:	00 
    bdfd:	bf 01 00 00 00       	mov    $0x1,%edi
    be02:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    be09:	00 
    be0a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    be11:	00 
    be12:	e8 59 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be17:	48 89 c7             	mov    %rax,%rdi
    be1a:	e8 f1 a8 ff ff       	call   6710 <fwp_rc_fresh>
    be1f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    be26:	00 
    be27:	bf 01 00 00 00       	mov    $0x1,%edi
    be2c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    be33:	00 
    be34:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    be3b:	00 
    be3c:	e8 2f 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be41:	48 89 c7             	mov    %rax,%rdi
    be44:	e8 c7 a8 ff ff       	call   6710 <fwp_rc_fresh>
    be49:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    be50:	00 
    be51:	bf 01 00 00 00       	mov    $0x1,%edi
    be56:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    be5d:	00 
    be5e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    be65:	00 
    be66:	e8 05 9d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be6b:	48 89 c7             	mov    %rax,%rdi
    be6e:	e8 9d a8 ff ff       	call   6710 <fwp_rc_fresh>
    be73:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    be7a:	00 
    be7b:	bf 01 00 00 00       	mov    $0x1,%edi
    be80:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    be87:	00 
    be88:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    be8f:	00 
    be90:	e8 db 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    be95:	48 89 c7             	mov    %rax,%rdi
    be98:	e8 73 a8 ff ff       	call   6710 <fwp_rc_fresh>
    be9d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    bea4:	00 
    bea5:	bf 01 00 00 00       	mov    $0x1,%edi
    beaa:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    beb1:	00 
    beb2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    beb9:	00 
    beba:	e8 b1 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bebf:	48 89 c7             	mov    %rax,%rdi
    bec2:	e8 49 a8 ff ff       	call   6710 <fwp_rc_fresh>
    bec7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    bece:	00 
    becf:	bf 01 00 00 00       	mov    $0x1,%edi
    bed4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    bedb:	00 
    bedc:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    bee3:	00 
    bee4:	e8 87 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bee9:	48 89 c7             	mov    %rax,%rdi
    beec:	e8 1f a8 ff ff       	call   6710 <fwp_rc_fresh>
    bef1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    bef8:	00 
    bef9:	bf 01 00 00 00       	mov    $0x1,%edi
    befe:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    bf05:	00 
    bf06:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    bf0d:	00 
    bf0e:	e8 5d 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf13:	48 89 c7             	mov    %rax,%rdi
    bf16:	e8 f5 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf1b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    bf22:	00 
    bf23:	bf 01 00 00 00       	mov    $0x1,%edi
    bf28:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    bf2f:	00 
    bf30:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    bf37:	00 
    bf38:	e8 33 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf3d:	48 89 c7             	mov    %rax,%rdi
    bf40:	e8 cb a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf45:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    bf4c:	00 
    bf4d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf52:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    bf59:	00 
    bf5a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    bf61:	00 
    bf62:	e8 09 9c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf67:	48 89 c7             	mov    %rax,%rdi
    bf6a:	e8 a1 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf6f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    bf76:	00 
    bf77:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    bf83:	00 
    bf84:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    bf8b:	00 
    bf8c:	e8 df 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bf91:	48 89 c7             	mov    %rax,%rdi
    bf94:	e8 77 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bf99:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    bfa0:	00 
    bfa1:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    bfad:	00 
    bfae:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    bfb5:	00 
    bfb6:	e8 b5 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bfbb:	48 89 c7             	mov    %rax,%rdi
    bfbe:	e8 4d a7 ff ff       	call   6710 <fwp_rc_fresh>
    bfc3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    bfca:	00 
    bfcb:	bf 01 00 00 00       	mov    $0x1,%edi
    bfd0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    bfd7:	00 
    bfd8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    bfdf:	00 
    bfe0:	e8 8b 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    bfe5:	48 89 c7             	mov    %rax,%rdi
    bfe8:	e8 23 a7 ff ff       	call   6710 <fwp_rc_fresh>
    bfed:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    bff4:	00 
    bff5:	bf 01 00 00 00       	mov    $0x1,%edi
    bffa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c001:	00 
    c002:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c009:	00 
    c00a:	e8 61 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c00f:	48 89 c7             	mov    %rax,%rdi
    c012:	e8 f9 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c017:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c01e:	00 
    c01f:	bf 01 00 00 00       	mov    $0x1,%edi
    c024:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c02b:	00 
    c02c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c033:	00 
    c034:	e8 37 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c039:	48 89 c7             	mov    %rax,%rdi
    c03c:	e8 cf a6 ff ff       	call   6710 <fwp_rc_fresh>
    c041:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c048:	00 
    c049:	bf 01 00 00 00       	mov    $0x1,%edi
    c04e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c055:	00 
    c056:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c05d:	00 
    c05e:	e8 0d 9b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c063:	48 89 c7             	mov    %rax,%rdi
    c066:	e8 a5 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c06b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c072:	00 
    c073:	bf 01 00 00 00       	mov    $0x1,%edi
    c078:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c07f:	00 
    c080:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c087:	00 
    c088:	e8 e3 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c08d:	48 89 c7             	mov    %rax,%rdi
    c090:	e8 7b a6 ff ff       	call   6710 <fwp_rc_fresh>
    c095:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c09c:	00 
    c09d:	bf 01 00 00 00       	mov    $0x1,%edi
    c0a2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c0a9:	00 
    c0aa:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c0b1:	00 
    c0b2:	e8 b9 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c0b7:	48 89 c7             	mov    %rax,%rdi
    c0ba:	e8 51 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c0bf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c0c6:	00 
    c0c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c0cc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c0d3:	00 
    c0d4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c0db:	00 
    c0dc:	e8 8f 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c0e1:	48 89 c7             	mov    %rax,%rdi
    c0e4:	e8 27 a6 ff ff       	call   6710 <fwp_rc_fresh>
    c0e9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c0f0:	00 
    c0f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c0fd:	00 
    c0fe:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c105:	00 
    c106:	e8 65 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c10b:	48 89 c7             	mov    %rax,%rdi
    c10e:	e8 fd a5 ff ff       	call   6710 <fwp_rc_fresh>
    c113:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c11a:	00 
    c11b:	bf 01 00 00 00       	mov    $0x1,%edi
    c120:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c127:	00 
    c128:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c12f:	00 
    c130:	e8 3b 9a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c135:	48 8b 15 fc 89 01 00 	mov    0x189fc(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c13c:	49 89 c5             	mov    %rax,%r13
    c13f:	48 2b 05 ca 89 01 00 	sub    0x189ca(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c146:	48 c1 e2 10          	shl    $0x10,%rdx
    c14a:	48 39 d0             	cmp    %rdx,%rax
    c14d:	73 59                	jae    c1a8 <f0+0x13b8>
    c14f:	48 89 c2             	mov    %rax,%rdx
    c152:	48 c1 ea 10          	shr    $0x10,%rdx
    c156:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c15a:	48 8b 15 f7 89 01 00 	mov    0x189f7(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c161:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c165:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c169:	4d 85 e4             	test   %r12,%r12
    c16c:	74 3a                	je     c1a8 <f0+0x13b8>
    c16e:	0f b6 0a             	movzbl (%rdx),%ecx
    c171:	80 f9 02             	cmp    $0x2,%cl
    c174:	0f 84 c6 15 00 00    	je     d740 <f0+0x2950>
    c17a:	80 f9 01             	cmp    $0x1,%cl
    c17d:	75 29                	jne    c1a8 <f0+0x13b8>
    c17f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c182:	0f b7 c0             	movzwl %ax,%eax
    c185:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c188:	48 0f af c1          	imul   %rcx,%rax
    c18c:	48 c1 e8 20          	shr    $0x20,%rax
    c190:	48 39 d0             	cmp    %rdx,%rax
    c193:	73 13                	jae    c1a8 <f0+0x13b8>
    c195:	49 01 c4             	add    %rax,%r12
    c198:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c19d:	0f 84 99 17 00 00    	je     d93c <f0+0x2b4c>
    c1a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c1a8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c1af:	33 f3 bf 
    c1b2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c1b9:	00 
    c1ba:	bf 01 00 00 00       	mov    $0x1,%edi
    c1bf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c1c6:	00 
    c1c7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c1ce:	00 
    c1cf:	e8 9c 99 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c1d4:	48 8b 15 5d 89 01 00 	mov    0x1895d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c1db:	49 89 c5             	mov    %rax,%r13
    c1de:	48 2b 05 2b 89 01 00 	sub    0x1892b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c1e5:	48 c1 e2 10          	shl    $0x10,%rdx
    c1e9:	48 39 d0             	cmp    %rdx,%rax
    c1ec:	73 59                	jae    c247 <f0+0x1457>
    c1ee:	48 89 c2             	mov    %rax,%rdx
    c1f1:	48 c1 ea 10          	shr    $0x10,%rdx
    c1f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1f9:	48 8b 15 58 89 01 00 	mov    0x18958(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c200:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c204:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c208:	4d 85 e4             	test   %r12,%r12
    c20b:	74 3a                	je     c247 <f0+0x1457>
    c20d:	0f b6 0a             	movzbl (%rdx),%ecx
    c210:	80 f9 02             	cmp    $0x2,%cl
    c213:	0f 84 17 15 00 00    	je     d730 <f0+0x2940>
    c219:	80 f9 01             	cmp    $0x1,%cl
    c21c:	75 29                	jne    c247 <f0+0x1457>
    c21e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c221:	0f b7 c0             	movzwl %ax,%eax
    c224:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c227:	48 0f af c1          	imul   %rcx,%rax
    c22b:	48 c1 e8 20          	shr    $0x20,%rax
    c22f:	48 39 d0             	cmp    %rdx,%rax
    c232:	73 13                	jae    c247 <f0+0x1457>
    c234:	49 01 c4             	add    %rax,%r12
    c237:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c23c:	0f 84 07 17 00 00    	je     d949 <f0+0x2b59>
    c242:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c247:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c24e:	00 f0 3f 
    c251:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c258:	00 
    c259:	bf 01 00 00 00       	mov    $0x1,%edi
    c25e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c265:	00 
    c266:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c26d:	00 
    c26e:	e8 fd 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c273:	48 8b 15 be 88 01 00 	mov    0x188be(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c27a:	49 89 c5             	mov    %rax,%r13
    c27d:	48 2b 05 8c 88 01 00 	sub    0x1888c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c284:	48 c1 e2 10          	shl    $0x10,%rdx
    c288:	48 39 d0             	cmp    %rdx,%rax
    c28b:	73 59                	jae    c2e6 <f0+0x14f6>
    c28d:	48 89 c2             	mov    %rax,%rdx
    c290:	48 c1 ea 10          	shr    $0x10,%rdx
    c294:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c298:	48 8b 15 b9 88 01 00 	mov    0x188b9(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c29f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2a3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c2a7:	4d 85 e4             	test   %r12,%r12
    c2aa:	74 3a                	je     c2e6 <f0+0x14f6>
    c2ac:	0f b6 0a             	movzbl (%rdx),%ecx
    c2af:	80 f9 02             	cmp    $0x2,%cl
    c2b2:	0f 84 28 15 00 00    	je     d7e0 <f0+0x29f0>
    c2b8:	80 f9 01             	cmp    $0x1,%cl
    c2bb:	75 29                	jne    c2e6 <f0+0x14f6>
    c2bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2c0:	0f b7 c0             	movzwl %ax,%eax
    c2c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2c6:	48 0f af c1          	imul   %rcx,%rax
    c2ca:	48 c1 e8 20          	shr    $0x20,%rax
    c2ce:	48 39 d0             	cmp    %rdx,%rax
    c2d1:	73 13                	jae    c2e6 <f0+0x14f6>
    c2d3:	49 01 c4             	add    %rax,%r12
    c2d6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2db:	0f 84 75 16 00 00    	je     d956 <f0+0x2b66>
    c2e1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2e6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c2ed:	33 f3 bf 
    c2f0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c2f7:	00 
    c2f8:	bf 01 00 00 00       	mov    $0x1,%edi
    c2fd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c304:	00 
    c305:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c30c:	00 
    c30d:	e8 5e 98 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c312:	48 8b 15 1f 88 01 00 	mov    0x1881f(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c319:	49 89 c5             	mov    %rax,%r13
    c31c:	48 2b 05 ed 87 01 00 	sub    0x187ed(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c323:	48 c1 e2 10          	shl    $0x10,%rdx
    c327:	48 39 d0             	cmp    %rdx,%rax
    c32a:	73 59                	jae    c385 <f0+0x1595>
    c32c:	48 89 c2             	mov    %rax,%rdx
    c32f:	48 c1 ea 10          	shr    $0x10,%rdx
    c333:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c337:	48 8b 15 1a 88 01 00 	mov    0x1881a(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c33e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c342:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c346:	4d 85 e4             	test   %r12,%r12
    c349:	74 3a                	je     c385 <f0+0x1595>
    c34b:	0f b6 0a             	movzbl (%rdx),%ecx
    c34e:	80 f9 02             	cmp    $0x2,%cl
    c351:	0f 84 79 14 00 00    	je     d7d0 <f0+0x29e0>
    c357:	80 f9 01             	cmp    $0x1,%cl
    c35a:	75 29                	jne    c385 <f0+0x1595>
    c35c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c35f:	0f b7 c0             	movzwl %ax,%eax
    c362:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c365:	48 0f af c1          	imul   %rcx,%rax
    c369:	48 c1 e8 20          	shr    $0x20,%rax
    c36d:	48 39 d0             	cmp    %rdx,%rax
    c370:	73 13                	jae    c385 <f0+0x1595>
    c372:	49 01 c4             	add    %rax,%r12
    c375:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c37a:	0f 84 e3 15 00 00    	je     d963 <f0+0x2b73>
    c380:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c385:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c38c:	00 f0 3f 
    c38f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c396:	00 
    c397:	bf 01 00 00 00       	mov    $0x1,%edi
    c39c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c3a3:	00 
    c3a4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c3ab:	00 
    c3ac:	e8 bf 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c3b1:	48 8b 15 80 87 01 00 	mov    0x18780(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c3b8:	49 89 c5             	mov    %rax,%r13
    c3bb:	48 2b 05 4e 87 01 00 	sub    0x1874e(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c3c2:	48 c1 e2 10          	shl    $0x10,%rdx
    c3c6:	48 39 d0             	cmp    %rdx,%rax
    c3c9:	73 59                	jae    c424 <f0+0x1634>
    c3cb:	48 89 c2             	mov    %rax,%rdx
    c3ce:	48 c1 ea 10          	shr    $0x10,%rdx
    c3d2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3d6:	48 8b 15 7b 87 01 00 	mov    0x1877b(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c3dd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3e1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3e5:	4d 85 e4             	test   %r12,%r12
    c3e8:	74 3a                	je     c424 <f0+0x1634>
    c3ea:	0f b6 0a             	movzbl (%rdx),%ecx
    c3ed:	80 f9 02             	cmp    $0x2,%cl
    c3f0:	0f 84 ca 13 00 00    	je     d7c0 <f0+0x29d0>
    c3f6:	80 f9 01             	cmp    $0x1,%cl
    c3f9:	75 29                	jne    c424 <f0+0x1634>
    c3fb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3fe:	0f b7 c0             	movzwl %ax,%eax
    c401:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c404:	48 0f af c1          	imul   %rcx,%rax
    c408:	48 c1 e8 20          	shr    $0x20,%rax
    c40c:	48 39 d0             	cmp    %rdx,%rax
    c40f:	73 13                	jae    c424 <f0+0x1634>
    c411:	49 01 c4             	add    %rax,%r12
    c414:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c419:	0f 84 51 15 00 00    	je     d970 <f0+0x2b80>
    c41f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c424:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c42b:	33 f3 bf 
    c42e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c435:	00 
    c436:	bf 01 00 00 00       	mov    $0x1,%edi
    c43b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c442:	00 
    c443:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c44a:	00 
    c44b:	e8 20 97 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c450:	48 8b 15 e1 86 01 00 	mov    0x186e1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c457:	49 89 c5             	mov    %rax,%r13
    c45a:	48 2b 05 af 86 01 00 	sub    0x186af(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c461:	48 c1 e2 10          	shl    $0x10,%rdx
    c465:	48 39 d0             	cmp    %rdx,%rax
    c468:	73 59                	jae    c4c3 <f0+0x16d3>
    c46a:	48 89 c2             	mov    %rax,%rdx
    c46d:	48 c1 ea 10          	shr    $0x10,%rdx
    c471:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c475:	48 8b 15 dc 86 01 00 	mov    0x186dc(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c47c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c480:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c484:	4d 85 e4             	test   %r12,%r12
    c487:	74 3a                	je     c4c3 <f0+0x16d3>
    c489:	0f b6 0a             	movzbl (%rdx),%ecx
    c48c:	80 f9 02             	cmp    $0x2,%cl
    c48f:	0f 84 1b 13 00 00    	je     d7b0 <f0+0x29c0>
    c495:	80 f9 01             	cmp    $0x1,%cl
    c498:	75 29                	jne    c4c3 <f0+0x16d3>
    c49a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c49d:	0f b7 c0             	movzwl %ax,%eax
    c4a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c4a3:	48 0f af c1          	imul   %rcx,%rax
    c4a7:	48 c1 e8 20          	shr    $0x20,%rax
    c4ab:	48 39 d0             	cmp    %rdx,%rax
    c4ae:	73 13                	jae    c4c3 <f0+0x16d3>
    c4b0:	49 01 c4             	add    %rax,%r12
    c4b3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c4b8:	0f 84 bf 14 00 00    	je     d97d <f0+0x2b8d>
    c4be:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4c3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4ca:	00 f0 3f 
    c4cd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c4d4:	00 
    c4d5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4da:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c4e1:	00 
    c4e2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c4e9:	00 
    c4ea:	e8 81 96 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c4ef:	48 8b 15 42 86 01 00 	mov    0x18642(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c4f6:	49 89 c5             	mov    %rax,%r13
    c4f9:	48 2b 05 10 86 01 00 	sub    0x18610(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c500:	48 c1 e2 10          	shl    $0x10,%rdx
    c504:	48 39 d0             	cmp    %rdx,%rax
    c507:	73 59                	jae    c562 <f0+0x1772>
    c509:	48 89 c2             	mov    %rax,%rdx
    c50c:	48 c1 ea 10          	shr    $0x10,%rdx
    c510:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c514:	48 8b 15 3d 86 01 00 	mov    0x1863d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c51b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c51f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c523:	4d 85 e4             	test   %r12,%r12
    c526:	74 3a                	je     c562 <f0+0x1772>
    c528:	0f b6 0a             	movzbl (%rdx),%ecx
    c52b:	80 f9 02             	cmp    $0x2,%cl
    c52e:	0f 84 6c 12 00 00    	je     d7a0 <f0+0x29b0>
    c534:	80 f9 01             	cmp    $0x1,%cl
    c537:	75 29                	jne    c562 <f0+0x1772>
    c539:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c53c:	0f b7 c0             	movzwl %ax,%eax
    c53f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c542:	48 0f af c1          	imul   %rcx,%rax
    c546:	48 c1 e8 20          	shr    $0x20,%rax
    c54a:	48 39 d0             	cmp    %rdx,%rax
    c54d:	73 13                	jae    c562 <f0+0x1772>
    c54f:	49 01 c4             	add    %rax,%r12
    c552:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c557:	0f 84 2d 14 00 00    	je     d98a <f0+0x2b9a>
    c55d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c562:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c569:	33 f3 bf 
    c56c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c573:	00 
    c574:	bf 01 00 00 00       	mov    $0x1,%edi
    c579:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c580:	00 
    c581:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c588:	00 
    c589:	e8 e2 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c58e:	48 8b 15 a3 85 01 00 	mov    0x185a3(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c595:	49 89 c5             	mov    %rax,%r13
    c598:	48 2b 05 71 85 01 00 	sub    0x18571(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c59f:	48 c1 e2 10          	shl    $0x10,%rdx
    c5a3:	48 39 d0             	cmp    %rdx,%rax
    c5a6:	73 59                	jae    c601 <f0+0x1811>
    c5a8:	48 89 c2             	mov    %rax,%rdx
    c5ab:	48 c1 ea 10          	shr    $0x10,%rdx
    c5af:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c5b3:	48 8b 15 9e 85 01 00 	mov    0x1859e(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c5ba:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5be:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5c2:	4d 85 e4             	test   %r12,%r12
    c5c5:	74 3a                	je     c601 <f0+0x1811>
    c5c7:	0f b6 0a             	movzbl (%rdx),%ecx
    c5ca:	80 f9 02             	cmp    $0x2,%cl
    c5cd:	0f 84 bd 11 00 00    	je     d790 <f0+0x29a0>
    c5d3:	80 f9 01             	cmp    $0x1,%cl
    c5d6:	75 29                	jne    c601 <f0+0x1811>
    c5d8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5db:	0f b7 c0             	movzwl %ax,%eax
    c5de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5e1:	48 0f af c1          	imul   %rcx,%rax
    c5e5:	48 c1 e8 20          	shr    $0x20,%rax
    c5e9:	48 39 d0             	cmp    %rdx,%rax
    c5ec:	73 13                	jae    c601 <f0+0x1811>
    c5ee:	49 01 c4             	add    %rax,%r12
    c5f1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5f6:	0f 84 9b 13 00 00    	je     d997 <f0+0x2ba7>
    c5fc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c601:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c608:	00 f0 3f 
    c60b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c612:	00 
    c613:	bf 01 00 00 00       	mov    $0x1,%edi
    c618:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c61f:	00 
    c620:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c627:	00 
    c628:	e8 43 95 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c62d:	48 8b 15 04 85 01 00 	mov    0x18504(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c634:	49 89 c5             	mov    %rax,%r13
    c637:	48 2b 05 d2 84 01 00 	sub    0x184d2(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c63e:	48 c1 e2 10          	shl    $0x10,%rdx
    c642:	48 39 d0             	cmp    %rdx,%rax
    c645:	73 59                	jae    c6a0 <f0+0x18b0>
    c647:	48 89 c2             	mov    %rax,%rdx
    c64a:	48 c1 ea 10          	shr    $0x10,%rdx
    c64e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c652:	48 8b 15 ff 84 01 00 	mov    0x184ff(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c659:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c65d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c661:	4d 85 e4             	test   %r12,%r12
    c664:	74 3a                	je     c6a0 <f0+0x18b0>
    c666:	0f b6 0a             	movzbl (%rdx),%ecx
    c669:	80 f9 02             	cmp    $0x2,%cl
    c66c:	0f 84 0e 11 00 00    	je     d780 <f0+0x2990>
    c672:	80 f9 01             	cmp    $0x1,%cl
    c675:	75 29                	jne    c6a0 <f0+0x18b0>
    c677:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c67a:	0f b7 c0             	movzwl %ax,%eax
    c67d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c680:	48 0f af c1          	imul   %rcx,%rax
    c684:	48 c1 e8 20          	shr    $0x20,%rax
    c688:	48 39 d0             	cmp    %rdx,%rax
    c68b:	73 13                	jae    c6a0 <f0+0x18b0>
    c68d:	49 01 c4             	add    %rax,%r12
    c690:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c695:	0f 84 09 13 00 00    	je     d9a4 <f0+0x2bb4>
    c69b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c6a0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c6a7:	33 f3 bf 
    c6aa:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c6b1:	00 
    c6b2:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c6be:	00 
    c6bf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c6c6:	00 
    c6c7:	e8 a4 94 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c6cc:	48 8b 15 65 84 01 00 	mov    0x18465(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c6d3:	49 89 c5             	mov    %rax,%r13
    c6d6:	48 2b 05 33 84 01 00 	sub    0x18433(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c6dd:	48 c1 e2 10          	shl    $0x10,%rdx
    c6e1:	48 39 d0             	cmp    %rdx,%rax
    c6e4:	73 59                	jae    c73f <f0+0x194f>
    c6e6:	48 89 c2             	mov    %rax,%rdx
    c6e9:	48 c1 ea 10          	shr    $0x10,%rdx
    c6ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6f1:	48 8b 15 60 84 01 00 	mov    0x18460(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c6f8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6fc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c700:	4d 85 e4             	test   %r12,%r12
    c703:	74 3a                	je     c73f <f0+0x194f>
    c705:	0f b6 0a             	movzbl (%rdx),%ecx
    c708:	80 f9 02             	cmp    $0x2,%cl
    c70b:	0f 84 5f 10 00 00    	je     d770 <f0+0x2980>
    c711:	80 f9 01             	cmp    $0x1,%cl
    c714:	75 29                	jne    c73f <f0+0x194f>
    c716:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c719:	0f b7 c0             	movzwl %ax,%eax
    c71c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c71f:	48 0f af c1          	imul   %rcx,%rax
    c723:	48 c1 e8 20          	shr    $0x20,%rax
    c727:	48 39 d0             	cmp    %rdx,%rax
    c72a:	73 13                	jae    c73f <f0+0x194f>
    c72c:	49 01 c4             	add    %rax,%r12
    c72f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c734:	0f 84 77 12 00 00    	je     d9b1 <f0+0x2bc1>
    c73a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c73f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c746:	00 f0 3f 
    c749:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c750:	00 
    c751:	bf 01 00 00 00       	mov    $0x1,%edi
    c756:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c75d:	00 
    c75e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c765:	00 
    c766:	e8 05 94 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c76b:	48 8b 15 c6 83 01 00 	mov    0x183c6(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c772:	49 89 c5             	mov    %rax,%r13
    c775:	48 2b 05 94 83 01 00 	sub    0x18394(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c77c:	48 c1 e2 10          	shl    $0x10,%rdx
    c780:	48 39 d0             	cmp    %rdx,%rax
    c783:	73 59                	jae    c7de <f0+0x19ee>
    c785:	48 89 c2             	mov    %rax,%rdx
    c788:	48 c1 ea 10          	shr    $0x10,%rdx
    c78c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c790:	48 8b 15 c1 83 01 00 	mov    0x183c1(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c797:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c79b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c79f:	4d 85 e4             	test   %r12,%r12
    c7a2:	74 3a                	je     c7de <f0+0x19ee>
    c7a4:	0f b6 0a             	movzbl (%rdx),%ecx
    c7a7:	80 f9 02             	cmp    $0x2,%cl
    c7aa:	0f 84 40 0f 00 00    	je     d6f0 <f0+0x2900>
    c7b0:	80 f9 01             	cmp    $0x1,%cl
    c7b3:	75 29                	jne    c7de <f0+0x19ee>
    c7b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c7b8:	0f b7 c0             	movzwl %ax,%eax
    c7bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7be:	48 0f af c1          	imul   %rcx,%rax
    c7c2:	48 c1 e8 20          	shr    $0x20,%rax
    c7c6:	48 39 d0             	cmp    %rdx,%rax
    c7c9:	73 13                	jae    c7de <f0+0x19ee>
    c7cb:	49 01 c4             	add    %rax,%r12
    c7ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7d3:	0f 84 e5 11 00 00    	je     d9be <f0+0x2bce>
    c7d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7de:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7e5:	33 f3 bf 
    c7e8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    c7ef:	00 
    c7f0:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    c7fc:	00 
    c7fd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    c804:	00 
    c805:	e8 66 93 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c80a:	48 8b 15 27 83 01 00 	mov    0x18327(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c811:	49 89 c5             	mov    %rax,%r13
    c814:	48 2b 05 f5 82 01 00 	sub    0x182f5(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c81b:	48 c1 e2 10          	shl    $0x10,%rdx
    c81f:	48 39 d0             	cmp    %rdx,%rax
    c822:	73 59                	jae    c87d <f0+0x1a8d>
    c824:	48 89 c2             	mov    %rax,%rdx
    c827:	48 c1 ea 10          	shr    $0x10,%rdx
    c82b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c82f:	48 8b 15 22 83 01 00 	mov    0x18322(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c836:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c83a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c83e:	4d 85 e4             	test   %r12,%r12
    c841:	74 3a                	je     c87d <f0+0x1a8d>
    c843:	0f b6 0a             	movzbl (%rdx),%ecx
    c846:	80 f9 02             	cmp    $0x2,%cl
    c849:	0f 84 91 0e 00 00    	je     d6e0 <f0+0x28f0>
    c84f:	80 f9 01             	cmp    $0x1,%cl
    c852:	75 29                	jne    c87d <f0+0x1a8d>
    c854:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c857:	0f b7 c0             	movzwl %ax,%eax
    c85a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c85d:	48 0f af c1          	imul   %rcx,%rax
    c861:	48 c1 e8 20          	shr    $0x20,%rax
    c865:	48 39 d0             	cmp    %rdx,%rax
    c868:	73 13                	jae    c87d <f0+0x1a8d>
    c86a:	49 01 c4             	add    %rax,%r12
    c86d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c872:	0f 84 53 11 00 00    	je     d9cb <f0+0x2bdb>
    c878:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c87d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c884:	00 f0 3f 
    c887:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    c88e:	00 
    c88f:	bf 01 00 00 00       	mov    $0x1,%edi
    c894:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    c89b:	00 
    c89c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    c8a3:	00 
    c8a4:	e8 c7 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c8a9:	48 8b 15 88 82 01 00 	mov    0x18288(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c8b0:	49 89 c5             	mov    %rax,%r13
    c8b3:	48 2b 05 56 82 01 00 	sub    0x18256(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c8ba:	48 c1 e2 10          	shl    $0x10,%rdx
    c8be:	48 39 d0             	cmp    %rdx,%rax
    c8c1:	73 59                	jae    c91c <f0+0x1b2c>
    c8c3:	48 89 c2             	mov    %rax,%rdx
    c8c6:	48 c1 ea 10          	shr    $0x10,%rdx
    c8ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8ce:	48 8b 15 83 82 01 00 	mov    0x18283(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c8d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8d9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8dd:	4d 85 e4             	test   %r12,%r12
    c8e0:	74 3a                	je     c91c <f0+0x1b2c>
    c8e2:	0f b6 0a             	movzbl (%rdx),%ecx
    c8e5:	80 f9 02             	cmp    $0x2,%cl
    c8e8:	0f 84 e2 0d 00 00    	je     d6d0 <f0+0x28e0>
    c8ee:	80 f9 01             	cmp    $0x1,%cl
    c8f1:	75 29                	jne    c91c <f0+0x1b2c>
    c8f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8f6:	0f b7 c0             	movzwl %ax,%eax
    c8f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8fc:	48 0f af c1          	imul   %rcx,%rax
    c900:	48 c1 e8 20          	shr    $0x20,%rax
    c904:	48 39 d0             	cmp    %rdx,%rax
    c907:	73 13                	jae    c91c <f0+0x1b2c>
    c909:	49 01 c4             	add    %rax,%r12
    c90c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c911:	0f 84 c1 10 00 00    	je     d9d8 <f0+0x2be8>
    c917:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c91c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c923:	33 f3 bf 
    c926:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    c92d:	00 
    c92e:	bf 01 00 00 00       	mov    $0x1,%edi
    c933:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    c93a:	00 
    c93b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    c942:	00 
    c943:	e8 28 92 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c948:	48 8b 15 e9 81 01 00 	mov    0x181e9(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c94f:	49 89 c5             	mov    %rax,%r13
    c952:	48 2b 05 b7 81 01 00 	sub    0x181b7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c959:	48 c1 e2 10          	shl    $0x10,%rdx
    c95d:	48 39 d0             	cmp    %rdx,%rax
    c960:	73 59                	jae    c9bb <f0+0x1bcb>
    c962:	48 89 c2             	mov    %rax,%rdx
    c965:	48 c1 ea 10          	shr    $0x10,%rdx
    c969:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c96d:	48 8b 15 e4 81 01 00 	mov    0x181e4(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    c974:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c978:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c97c:	4d 85 e4             	test   %r12,%r12
    c97f:	74 3a                	je     c9bb <f0+0x1bcb>
    c981:	0f b6 0a             	movzbl (%rdx),%ecx
    c984:	80 f9 02             	cmp    $0x2,%cl
    c987:	0f 84 33 0d 00 00    	je     d6c0 <f0+0x28d0>
    c98d:	80 f9 01             	cmp    $0x1,%cl
    c990:	75 29                	jne    c9bb <f0+0x1bcb>
    c992:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c995:	0f b7 c0             	movzwl %ax,%eax
    c998:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c99b:	48 0f af c1          	imul   %rcx,%rax
    c99f:	48 c1 e8 20          	shr    $0x20,%rax
    c9a3:	48 39 d0             	cmp    %rdx,%rax
    c9a6:	73 13                	jae    c9bb <f0+0x1bcb>
    c9a8:	49 01 c4             	add    %rax,%r12
    c9ab:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9b0:	0f 84 2f 10 00 00    	je     d9e5 <f0+0x2bf5>
    c9b6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9bb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9c2:	00 f0 3f 
    c9c5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    c9cc:	00 
    c9cd:	bf 01 00 00 00       	mov    $0x1,%edi
    c9d2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    c9d9:	00 
    c9da:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    c9e1:	00 
    c9e2:	e8 89 91 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    c9e7:	48 8b 15 4a 81 01 00 	mov    0x1814a(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    c9ee:	49 89 c5             	mov    %rax,%r13
    c9f1:	48 2b 05 18 81 01 00 	sub    0x18118(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    c9f8:	48 c1 e2 10          	shl    $0x10,%rdx
    c9fc:	48 39 d0             	cmp    %rdx,%rax
    c9ff:	73 59                	jae    ca5a <f0+0x1c6a>
    ca01:	48 89 c2             	mov    %rax,%rdx
    ca04:	48 c1 ea 10          	shr    $0x10,%rdx
    ca08:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca0c:	48 8b 15 45 81 01 00 	mov    0x18145(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ca13:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca17:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca1b:	4d 85 e4             	test   %r12,%r12
    ca1e:	74 3a                	je     ca5a <f0+0x1c6a>
    ca20:	0f b6 0a             	movzbl (%rdx),%ecx
    ca23:	80 f9 02             	cmp    $0x2,%cl
    ca26:	0f 84 84 0c 00 00    	je     d6b0 <f0+0x28c0>
    ca2c:	80 f9 01             	cmp    $0x1,%cl
    ca2f:	75 29                	jne    ca5a <f0+0x1c6a>
    ca31:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca34:	0f b7 c0             	movzwl %ax,%eax
    ca37:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca3a:	48 0f af c1          	imul   %rcx,%rax
    ca3e:	48 c1 e8 20          	shr    $0x20,%rax
    ca42:	48 39 d0             	cmp    %rdx,%rax
    ca45:	73 13                	jae    ca5a <f0+0x1c6a>
    ca47:	49 01 c4             	add    %rax,%r12
    ca4a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca4f:	0f 84 9d 0f 00 00    	je     d9f2 <f0+0x2c02>
    ca55:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca5a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca61:	33 f3 bf 
    ca64:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    ca6b:	00 
    ca6c:	bf 01 00 00 00       	mov    $0x1,%edi
    ca71:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    ca78:	00 
    ca79:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    ca80:	00 
    ca81:	e8 ea 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ca86:	48 8b 15 ab 80 01 00 	mov    0x180ab(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ca8d:	49 89 c5             	mov    %rax,%r13
    ca90:	48 2b 05 79 80 01 00 	sub    0x18079(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ca97:	48 c1 e2 10          	shl    $0x10,%rdx
    ca9b:	48 39 d0             	cmp    %rdx,%rax
    ca9e:	73 59                	jae    caf9 <f0+0x1d09>
    caa0:	48 89 c2             	mov    %rax,%rdx
    caa3:	48 c1 ea 10          	shr    $0x10,%rdx
    caa7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    caab:	48 8b 15 a6 80 01 00 	mov    0x180a6(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cab2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cab6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caba:	4d 85 e4             	test   %r12,%r12
    cabd:	74 3a                	je     caf9 <f0+0x1d09>
    cabf:	0f b6 0a             	movzbl (%rdx),%ecx
    cac2:	80 f9 02             	cmp    $0x2,%cl
    cac5:	0f 84 d5 0b 00 00    	je     d6a0 <f0+0x28b0>
    cacb:	80 f9 01             	cmp    $0x1,%cl
    cace:	75 29                	jne    caf9 <f0+0x1d09>
    cad0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cad3:	0f b7 c0             	movzwl %ax,%eax
    cad6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cad9:	48 0f af c1          	imul   %rcx,%rax
    cadd:	48 c1 e8 20          	shr    $0x20,%rax
    cae1:	48 39 d0             	cmp    %rdx,%rax
    cae4:	73 13                	jae    caf9 <f0+0x1d09>
    cae6:	49 01 c4             	add    %rax,%r12
    cae9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    caee:	0f 84 0b 0f 00 00    	je     d9ff <f0+0x2c0f>
    caf4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    caf9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb00:	00 f0 3f 
    cb03:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cb0a:	00 
    cb0b:	bf 01 00 00 00       	mov    $0x1,%edi
    cb10:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cb17:	00 
    cb18:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cb1f:	00 
    cb20:	e8 4b 90 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cb25:	48 8b 15 0c 80 01 00 	mov    0x1800c(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cb2c:	49 89 c5             	mov    %rax,%r13
    cb2f:	48 2b 05 da 7f 01 00 	sub    0x17fda(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cb36:	48 c1 e2 10          	shl    $0x10,%rdx
    cb3a:	48 39 d0             	cmp    %rdx,%rax
    cb3d:	73 59                	jae    cb98 <f0+0x1da8>
    cb3f:	48 89 c2             	mov    %rax,%rdx
    cb42:	48 c1 ea 10          	shr    $0x10,%rdx
    cb46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb4a:	48 8b 15 07 80 01 00 	mov    0x18007(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cb51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb59:	4d 85 e4             	test   %r12,%r12
    cb5c:	74 3a                	je     cb98 <f0+0x1da8>
    cb5e:	0f b6 0a             	movzbl (%rdx),%ecx
    cb61:	80 f9 02             	cmp    $0x2,%cl
    cb64:	0f 84 26 0b 00 00    	je     d690 <f0+0x28a0>
    cb6a:	80 f9 01             	cmp    $0x1,%cl
    cb6d:	75 29                	jne    cb98 <f0+0x1da8>
    cb6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb72:	0f b7 c0             	movzwl %ax,%eax
    cb75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb78:	48 0f af c1          	imul   %rcx,%rax
    cb7c:	48 c1 e8 20          	shr    $0x20,%rax
    cb80:	48 39 d0             	cmp    %rdx,%rax
    cb83:	73 13                	jae    cb98 <f0+0x1da8>
    cb85:	49 01 c4             	add    %rax,%r12
    cb88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb8d:	0f 84 79 0e 00 00    	je     da0c <f0+0x2c1c>
    cb93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb98:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb9f:	33 f3 bf 
    cba2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    cba9:	00 
    cbaa:	bf 01 00 00 00       	mov    $0x1,%edi
    cbaf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    cbb6:	00 
    cbb7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    cbbe:	00 
    cbbf:	e8 ac 8f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cbc4:	48 8b 15 6d 7f 01 00 	mov    0x17f6d(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cbcb:	49 89 c5             	mov    %rax,%r13
    cbce:	48 2b 05 3b 7f 01 00 	sub    0x17f3b(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cbd5:	48 c1 e2 10          	shl    $0x10,%rdx
    cbd9:	48 39 d0             	cmp    %rdx,%rax
    cbdc:	73 59                	jae    cc37 <f0+0x1e47>
    cbde:	48 89 c2             	mov    %rax,%rdx
    cbe1:	48 c1 ea 10          	shr    $0x10,%rdx
    cbe5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbe9:	48 8b 15 68 7f 01 00 	mov    0x17f68(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cbf0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbf4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbf8:	4d 85 e4             	test   %r12,%r12
    cbfb:	74 3a                	je     cc37 <f0+0x1e47>
    cbfd:	0f b6 0a             	movzbl (%rdx),%ecx
    cc00:	80 f9 02             	cmp    $0x2,%cl
    cc03:	0f 84 77 0a 00 00    	je     d680 <f0+0x2890>
    cc09:	80 f9 01             	cmp    $0x1,%cl
    cc0c:	75 29                	jne    cc37 <f0+0x1e47>
    cc0e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc11:	0f b7 c0             	movzwl %ax,%eax
    cc14:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc17:	48 0f af c1          	imul   %rcx,%rax
    cc1b:	48 c1 e8 20          	shr    $0x20,%rax
    cc1f:	48 39 d0             	cmp    %rdx,%rax
    cc22:	73 13                	jae    cc37 <f0+0x1e47>
    cc24:	49 01 c4             	add    %rax,%r12
    cc27:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc2c:	0f 84 e7 0d 00 00    	je     da19 <f0+0x2c29>
    cc32:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc37:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc3e:	00 f0 3f 
    cc41:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cc48:	00 
    cc49:	bf 01 00 00 00       	mov    $0x1,%edi
    cc4e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    cc55:	00 
    cc56:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cc5d:	00 
    cc5e:	e8 0d 8f ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cc63:	48 8b 15 ce 7e 01 00 	mov    0x17ece(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cc6a:	49 89 c5             	mov    %rax,%r13
    cc6d:	48 2b 05 9c 7e 01 00 	sub    0x17e9c(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cc74:	48 c1 e2 10          	shl    $0x10,%rdx
    cc78:	48 39 d0             	cmp    %rdx,%rax
    cc7b:	73 59                	jae    ccd6 <f0+0x1ee6>
    cc7d:	48 89 c2             	mov    %rax,%rdx
    cc80:	48 c1 ea 10          	shr    $0x10,%rdx
    cc84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc88:	48 8b 15 c9 7e 01 00 	mov    0x17ec9(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cc8f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc93:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc97:	4d 85 e4             	test   %r12,%r12
    cc9a:	74 3a                	je     ccd6 <f0+0x1ee6>
    cc9c:	0f b6 0a             	movzbl (%rdx),%ecx
    cc9f:	80 f9 02             	cmp    $0x2,%cl
    cca2:	0f 84 38 0c 00 00    	je     d8e0 <f0+0x2af0>
    cca8:	80 f9 01             	cmp    $0x1,%cl
    ccab:	75 29                	jne    ccd6 <f0+0x1ee6>
    ccad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccb0:	0f b7 c0             	movzwl %ax,%eax
    ccb3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccb6:	48 0f af c1          	imul   %rcx,%rax
    ccba:	48 c1 e8 20          	shr    $0x20,%rax
    ccbe:	48 39 d0             	cmp    %rdx,%rax
    ccc1:	73 13                	jae    ccd6 <f0+0x1ee6>
    ccc3:	49 01 c4             	add    %rax,%r12
    ccc6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cccb:	0f 84 55 0d 00 00    	je     da26 <f0+0x2c36>
    ccd1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccd6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccdd:	33 f3 bf 
    cce0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cce7:	00 
    cce8:	bf 01 00 00 00       	mov    $0x1,%edi
    cced:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    ccf4:	00 
    ccf5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    ccfc:	00 
    ccfd:	e8 6e 8e ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cd02:	48 8b 15 2f 7e 01 00 	mov    0x17e2f(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cd09:	49 89 c5             	mov    %rax,%r13
    cd0c:	48 2b 05 fd 7d 01 00 	sub    0x17dfd(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cd13:	48 c1 e2 10          	shl    $0x10,%rdx
    cd17:	48 39 d0             	cmp    %rdx,%rax
    cd1a:	73 59                	jae    cd75 <f0+0x1f85>
    cd1c:	48 89 c2             	mov    %rax,%rdx
    cd1f:	48 c1 ea 10          	shr    $0x10,%rdx
    cd23:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd27:	48 8b 15 2a 7e 01 00 	mov    0x17e2a(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cd2e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd32:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd36:	4d 85 e4             	test   %r12,%r12
    cd39:	74 3a                	je     cd75 <f0+0x1f85>
    cd3b:	0f b6 0a             	movzbl (%rdx),%ecx
    cd3e:	80 f9 02             	cmp    $0x2,%cl
    cd41:	0f 84 89 0b 00 00    	je     d8d0 <f0+0x2ae0>
    cd47:	80 f9 01             	cmp    $0x1,%cl
    cd4a:	75 29                	jne    cd75 <f0+0x1f85>
    cd4c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd4f:	0f b7 c0             	movzwl %ax,%eax
    cd52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd55:	48 0f af c1          	imul   %rcx,%rax
    cd59:	48 c1 e8 20          	shr    $0x20,%rax
    cd5d:	48 39 d0             	cmp    %rdx,%rax
    cd60:	73 13                	jae    cd75 <f0+0x1f85>
    cd62:	49 01 c4             	add    %rax,%r12
    cd65:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd6a:	0f 84 c3 0c 00 00    	je     da33 <f0+0x2c43>
    cd70:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd75:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd7c:	00 f0 3f 
    cd7f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cd86:	00 
    cd87:	bf 01 00 00 00       	mov    $0x1,%edi
    cd8c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    cd93:	00 
    cd94:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cd9b:	00 
    cd9c:	e8 cf 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cda1:	48 8b 15 90 7d 01 00 	mov    0x17d90(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cda8:	49 89 c5             	mov    %rax,%r13
    cdab:	48 2b 05 5e 7d 01 00 	sub    0x17d5e(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cdb2:	48 c1 e2 10          	shl    $0x10,%rdx
    cdb6:	48 39 d0             	cmp    %rdx,%rax
    cdb9:	73 59                	jae    ce14 <f0+0x2024>
    cdbb:	48 89 c2             	mov    %rax,%rdx
    cdbe:	48 c1 ea 10          	shr    $0x10,%rdx
    cdc2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdc6:	48 8b 15 8b 7d 01 00 	mov    0x17d8b(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cdcd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdd1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdd5:	4d 85 e4             	test   %r12,%r12
    cdd8:	74 3a                	je     ce14 <f0+0x2024>
    cdda:	0f b6 0a             	movzbl (%rdx),%ecx
    cddd:	80 f9 02             	cmp    $0x2,%cl
    cde0:	0f 84 da 0a 00 00    	je     d8c0 <f0+0x2ad0>
    cde6:	80 f9 01             	cmp    $0x1,%cl
    cde9:	75 29                	jne    ce14 <f0+0x2024>
    cdeb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdee:	0f b7 c0             	movzwl %ax,%eax
    cdf1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdf4:	48 0f af c1          	imul   %rcx,%rax
    cdf8:	48 c1 e8 20          	shr    $0x20,%rax
    cdfc:	48 39 d0             	cmp    %rdx,%rax
    cdff:	73 13                	jae    ce14 <f0+0x2024>
    ce01:	49 01 c4             	add    %rax,%r12
    ce04:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce09:	0f 84 31 0c 00 00    	je     da40 <f0+0x2c50>
    ce0f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce14:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce1b:	33 f3 bf 
    ce1e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    ce25:	00 
    ce26:	bf 01 00 00 00       	mov    $0x1,%edi
    ce2b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    ce32:	00 
    ce33:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    ce3a:	00 
    ce3b:	e8 30 8d ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    ce40:	48 8b 15 f1 7c 01 00 	mov    0x17cf1(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    ce47:	49 89 c5             	mov    %rax,%r13
    ce4a:	48 2b 05 bf 7c 01 00 	sub    0x17cbf(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    ce51:	48 c1 e2 10          	shl    $0x10,%rdx
    ce55:	48 39 d0             	cmp    %rdx,%rax
    ce58:	73 59                	jae    ceb3 <f0+0x20c3>
    ce5a:	48 89 c2             	mov    %rax,%rdx
    ce5d:	48 c1 ea 10          	shr    $0x10,%rdx
    ce61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce65:	48 8b 15 ec 7c 01 00 	mov    0x17cec(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    ce6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce70:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce74:	4d 85 e4             	test   %r12,%r12
    ce77:	74 3a                	je     ceb3 <f0+0x20c3>
    ce79:	0f b6 0a             	movzbl (%rdx),%ecx
    ce7c:	80 f9 02             	cmp    $0x2,%cl
    ce7f:	0f 84 2b 0a 00 00    	je     d8b0 <f0+0x2ac0>
    ce85:	80 f9 01             	cmp    $0x1,%cl
    ce88:	75 29                	jne    ceb3 <f0+0x20c3>
    ce8a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce8d:	0f b7 c0             	movzwl %ax,%eax
    ce90:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce93:	48 0f af c1          	imul   %rcx,%rax
    ce97:	48 c1 e8 20          	shr    $0x20,%rax
    ce9b:	48 39 d0             	cmp    %rdx,%rax
    ce9e:	73 13                	jae    ceb3 <f0+0x20c3>
    cea0:	49 01 c4             	add    %rax,%r12
    cea3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cea8:	0f 84 9f 0b 00 00    	je     da4d <f0+0x2c5d>
    ceae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceb3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ceba:	00 f0 3f 
    cebd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    cec4:	00 
    cec5:	bf 01 00 00 00       	mov    $0x1,%edi
    ceca:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    ced1:	00 
    ced2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    ced9:	00 
    ceda:	e8 91 8c ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cedf:	48 8b 15 52 7c 01 00 	mov    0x17c52(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cee6:	49 89 c5             	mov    %rax,%r13
    cee9:	48 2b 05 20 7c 01 00 	sub    0x17c20(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cef0:	48 c1 e2 10          	shl    $0x10,%rdx
    cef4:	48 39 d0             	cmp    %rdx,%rax
    cef7:	73 59                	jae    cf52 <f0+0x2162>
    cef9:	48 89 c2             	mov    %rax,%rdx
    cefc:	48 c1 ea 10          	shr    $0x10,%rdx
    cf00:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf04:	48 8b 15 4d 7c 01 00 	mov    0x17c4d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cf0b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf0f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf13:	4d 85 e4             	test   %r12,%r12
    cf16:	74 3a                	je     cf52 <f0+0x2162>
    cf18:	0f b6 0a             	movzbl (%rdx),%ecx
    cf1b:	80 f9 02             	cmp    $0x2,%cl
    cf1e:	0f 84 7c 09 00 00    	je     d8a0 <f0+0x2ab0>
    cf24:	80 f9 01             	cmp    $0x1,%cl
    cf27:	75 29                	jne    cf52 <f0+0x2162>
    cf29:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf2c:	0f b7 c0             	movzwl %ax,%eax
    cf2f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf32:	48 0f af c1          	imul   %rcx,%rax
    cf36:	48 c1 e8 20          	shr    $0x20,%rax
    cf3a:	48 39 d0             	cmp    %rdx,%rax
    cf3d:	73 13                	jae    cf52 <f0+0x2162>
    cf3f:	49 01 c4             	add    %rax,%r12
    cf42:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf47:	0f 84 0d 0b 00 00    	je     da5a <f0+0x2c6a>
    cf4d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf52:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf59:	33 f3 bf 
    cf5c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    cf63:	00 
    cf64:	bf 01 00 00 00       	mov    $0x1,%edi
    cf69:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    cf70:	00 
    cf71:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    cf78:	00 
    cf79:	e8 f2 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    cf7e:	48 8b 15 b3 7b 01 00 	mov    0x17bb3(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    cf85:	49 89 c5             	mov    %rax,%r13
    cf88:	48 2b 05 81 7b 01 00 	sub    0x17b81(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    cf8f:	48 c1 e2 10          	shl    $0x10,%rdx
    cf93:	48 39 d0             	cmp    %rdx,%rax
    cf96:	73 59                	jae    cff1 <f0+0x2201>
    cf98:	48 89 c2             	mov    %rax,%rdx
    cf9b:	48 c1 ea 10          	shr    $0x10,%rdx
    cf9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfa3:	48 8b 15 ae 7b 01 00 	mov    0x17bae(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    cfaa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfb2:	4d 85 e4             	test   %r12,%r12
    cfb5:	74 3a                	je     cff1 <f0+0x2201>
    cfb7:	0f b6 0a             	movzbl (%rdx),%ecx
    cfba:	80 f9 02             	cmp    $0x2,%cl
    cfbd:	0f 84 cd 08 00 00    	je     d890 <f0+0x2aa0>
    cfc3:	80 f9 01             	cmp    $0x1,%cl
    cfc6:	75 29                	jne    cff1 <f0+0x2201>
    cfc8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfcb:	0f b7 c0             	movzwl %ax,%eax
    cfce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfd1:	48 0f af c1          	imul   %rcx,%rax
    cfd5:	48 c1 e8 20          	shr    $0x20,%rax
    cfd9:	48 39 d0             	cmp    %rdx,%rax
    cfdc:	73 13                	jae    cff1 <f0+0x2201>
    cfde:	49 01 c4             	add    %rax,%r12
    cfe1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfe6:	0f 84 7b 0a 00 00    	je     da67 <f0+0x2c77>
    cfec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cff1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cff8:	00 f0 3f 
    cffb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d002:	00 
    d003:	bf 01 00 00 00       	mov    $0x1,%edi
    d008:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d00f:	00 
    d010:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d017:	00 
    d018:	e8 53 8b ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d01d:	48 8b 15 14 7b 01 00 	mov    0x17b14(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d024:	49 89 c5             	mov    %rax,%r13
    d027:	48 2b 05 e2 7a 01 00 	sub    0x17ae2(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d02e:	48 c1 e2 10          	shl    $0x10,%rdx
    d032:	48 39 d0             	cmp    %rdx,%rax
    d035:	73 59                	jae    d090 <f0+0x22a0>
    d037:	48 89 c2             	mov    %rax,%rdx
    d03a:	48 c1 ea 10          	shr    $0x10,%rdx
    d03e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d042:	48 8b 15 0f 7b 01 00 	mov    0x17b0f(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d049:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d04d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d051:	4d 85 e4             	test   %r12,%r12
    d054:	74 3a                	je     d090 <f0+0x22a0>
    d056:	0f b6 0a             	movzbl (%rdx),%ecx
    d059:	80 f9 02             	cmp    $0x2,%cl
    d05c:	0f 84 1e 08 00 00    	je     d880 <f0+0x2a90>
    d062:	80 f9 01             	cmp    $0x1,%cl
    d065:	75 29                	jne    d090 <f0+0x22a0>
    d067:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d06a:	0f b7 c0             	movzwl %ax,%eax
    d06d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d070:	48 0f af c1          	imul   %rcx,%rax
    d074:	48 c1 e8 20          	shr    $0x20,%rax
    d078:	48 39 d0             	cmp    %rdx,%rax
    d07b:	73 13                	jae    d090 <f0+0x22a0>
    d07d:	49 01 c4             	add    %rax,%r12
    d080:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d085:	0f 84 e9 09 00 00    	je     da74 <f0+0x2c84>
    d08b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d090:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d097:	33 f3 bf 
    d09a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d0a1:	00 
    d0a2:	bf 01 00 00 00       	mov    $0x1,%edi
    d0a7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d0ae:	00 
    d0af:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d0b6:	00 
    d0b7:	e8 b4 8a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d0bc:	48 8b 15 75 7a 01 00 	mov    0x17a75(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d0c3:	49 89 c5             	mov    %rax,%r13
    d0c6:	48 2b 05 43 7a 01 00 	sub    0x17a43(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d0cd:	48 c1 e2 10          	shl    $0x10,%rdx
    d0d1:	48 39 d0             	cmp    %rdx,%rax
    d0d4:	73 59                	jae    d12f <f0+0x233f>
    d0d6:	48 89 c2             	mov    %rax,%rdx
    d0d9:	48 c1 ea 10          	shr    $0x10,%rdx
    d0dd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0e1:	48 8b 15 70 7a 01 00 	mov    0x17a70(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d0e8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0ec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0f0:	4d 85 e4             	test   %r12,%r12
    d0f3:	74 3a                	je     d12f <f0+0x233f>
    d0f5:	0f b6 0a             	movzbl (%rdx),%ecx
    d0f8:	80 f9 02             	cmp    $0x2,%cl
    d0fb:	0f 84 6f 07 00 00    	je     d870 <f0+0x2a80>
    d101:	80 f9 01             	cmp    $0x1,%cl
    d104:	75 29                	jne    d12f <f0+0x233f>
    d106:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d109:	0f b7 c0             	movzwl %ax,%eax
    d10c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d10f:	48 0f af c1          	imul   %rcx,%rax
    d113:	48 c1 e8 20          	shr    $0x20,%rax
    d117:	48 39 d0             	cmp    %rdx,%rax
    d11a:	73 13                	jae    d12f <f0+0x233f>
    d11c:	49 01 c4             	add    %rax,%r12
    d11f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d124:	0f 84 57 09 00 00    	je     da81 <f0+0x2c91>
    d12a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d12f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d136:	00 f0 3f 
    d139:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d140:	00 
    d141:	bf 01 00 00 00       	mov    $0x1,%edi
    d146:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d14d:	00 
    d14e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d155:	00 
    d156:	e8 15 8a ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d15b:	48 8b 15 d6 79 01 00 	mov    0x179d6(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d162:	49 89 c5             	mov    %rax,%r13
    d165:	48 2b 05 a4 79 01 00 	sub    0x179a4(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d16c:	48 c1 e2 10          	shl    $0x10,%rdx
    d170:	48 39 d0             	cmp    %rdx,%rax
    d173:	73 59                	jae    d1ce <f0+0x23de>
    d175:	48 89 c2             	mov    %rax,%rdx
    d178:	48 c1 ea 10          	shr    $0x10,%rdx
    d17c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d180:	48 8b 15 d1 79 01 00 	mov    0x179d1(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d187:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d18b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d18f:	4d 85 e4             	test   %r12,%r12
    d192:	74 3a                	je     d1ce <f0+0x23de>
    d194:	0f b6 0a             	movzbl (%rdx),%ecx
    d197:	80 f9 02             	cmp    $0x2,%cl
    d19a:	0f 84 c0 06 00 00    	je     d860 <f0+0x2a70>
    d1a0:	80 f9 01             	cmp    $0x1,%cl
    d1a3:	75 29                	jne    d1ce <f0+0x23de>
    d1a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1a8:	0f b7 c0             	movzwl %ax,%eax
    d1ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1ae:	48 0f af c1          	imul   %rcx,%rax
    d1b2:	48 c1 e8 20          	shr    $0x20,%rax
    d1b6:	48 39 d0             	cmp    %rdx,%rax
    d1b9:	73 13                	jae    d1ce <f0+0x23de>
    d1bb:	49 01 c4             	add    %rax,%r12
    d1be:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1c3:	0f 84 c5 08 00 00    	je     da8e <f0+0x2c9e>
    d1c9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1ce:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1d5:	33 f3 bf 
    d1d8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d1df:	00 
    d1e0:	bf 01 00 00 00       	mov    $0x1,%edi
    d1e5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d1ec:	00 
    d1ed:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d1f4:	00 
    d1f5:	e8 76 89 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d1fa:	48 8b 15 37 79 01 00 	mov    0x17937(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d201:	49 89 c5             	mov    %rax,%r13
    d204:	48 2b 05 05 79 01 00 	sub    0x17905(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d20b:	48 c1 e2 10          	shl    $0x10,%rdx
    d20f:	48 39 d0             	cmp    %rdx,%rax
    d212:	73 59                	jae    d26d <f0+0x247d>
    d214:	48 89 c2             	mov    %rax,%rdx
    d217:	48 c1 ea 10          	shr    $0x10,%rdx
    d21b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d21f:	48 8b 15 32 79 01 00 	mov    0x17932(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d226:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d22a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d22e:	4d 85 e4             	test   %r12,%r12
    d231:	74 3a                	je     d26d <f0+0x247d>
    d233:	0f b6 0a             	movzbl (%rdx),%ecx
    d236:	80 f9 02             	cmp    $0x2,%cl
    d239:	0f 84 11 06 00 00    	je     d850 <f0+0x2a60>
    d23f:	80 f9 01             	cmp    $0x1,%cl
    d242:	75 29                	jne    d26d <f0+0x247d>
    d244:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d247:	0f b7 c0             	movzwl %ax,%eax
    d24a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d24d:	48 0f af c1          	imul   %rcx,%rax
    d251:	48 c1 e8 20          	shr    $0x20,%rax
    d255:	48 39 d0             	cmp    %rdx,%rax
    d258:	73 13                	jae    d26d <f0+0x247d>
    d25a:	49 01 c4             	add    %rax,%r12
    d25d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d262:	0f 84 33 08 00 00    	je     da9b <f0+0x2cab>
    d268:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d26d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d274:	00 f0 3f 
    d277:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d27e:	00 
    d27f:	bf 01 00 00 00       	mov    $0x1,%edi
    d284:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d28b:	00 
    d28c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d293:	00 
    d294:	e8 d7 88 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d299:	48 8b 15 98 78 01 00 	mov    0x17898(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d2a0:	49 89 c5             	mov    %rax,%r13
    d2a3:	48 2b 05 66 78 01 00 	sub    0x17866(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d2aa:	48 c1 e2 10          	shl    $0x10,%rdx
    d2ae:	48 39 d0             	cmp    %rdx,%rax
    d2b1:	73 59                	jae    d30c <f0+0x251c>
    d2b3:	48 89 c2             	mov    %rax,%rdx
    d2b6:	48 c1 ea 10          	shr    $0x10,%rdx
    d2ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2be:	48 8b 15 93 78 01 00 	mov    0x17893(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d2c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2cd:	4d 85 e4             	test   %r12,%r12
    d2d0:	74 3a                	je     d30c <f0+0x251c>
    d2d2:	0f b6 0a             	movzbl (%rdx),%ecx
    d2d5:	80 f9 02             	cmp    $0x2,%cl
    d2d8:	0f 84 62 05 00 00    	je     d840 <f0+0x2a50>
    d2de:	80 f9 01             	cmp    $0x1,%cl
    d2e1:	75 29                	jne    d30c <f0+0x251c>
    d2e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2e6:	0f b7 c0             	movzwl %ax,%eax
    d2e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2ec:	48 0f af c1          	imul   %rcx,%rax
    d2f0:	48 c1 e8 20          	shr    $0x20,%rax
    d2f4:	48 39 d0             	cmp    %rdx,%rax
    d2f7:	73 13                	jae    d30c <f0+0x251c>
    d2f9:	49 01 c4             	add    %rax,%r12
    d2fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d301:	0f 84 a1 07 00 00    	je     daa8 <f0+0x2cb8>
    d307:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d30c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d313:	33 f3 bf 
    d316:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d31d:	00 
    d31e:	bf 01 00 00 00       	mov    $0x1,%edi
    d323:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d32a:	00 
    d32b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d332:	00 
    d333:	e8 38 88 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d338:	48 8b 15 f9 77 01 00 	mov    0x177f9(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d33f:	49 89 c5             	mov    %rax,%r13
    d342:	48 2b 05 c7 77 01 00 	sub    0x177c7(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d349:	48 c1 e2 10          	shl    $0x10,%rdx
    d34d:	48 39 d0             	cmp    %rdx,%rax
    d350:	73 59                	jae    d3ab <f0+0x25bb>
    d352:	48 89 c2             	mov    %rax,%rdx
    d355:	48 c1 ea 10          	shr    $0x10,%rdx
    d359:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d35d:	48 8b 15 f4 77 01 00 	mov    0x177f4(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d364:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d368:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d36c:	4d 85 e4             	test   %r12,%r12
    d36f:	74 3a                	je     d3ab <f0+0x25bb>
    d371:	0f b6 0a             	movzbl (%rdx),%ecx
    d374:	80 f9 02             	cmp    $0x2,%cl
    d377:	0f 84 b3 04 00 00    	je     d830 <f0+0x2a40>
    d37d:	80 f9 01             	cmp    $0x1,%cl
    d380:	75 29                	jne    d3ab <f0+0x25bb>
    d382:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d385:	0f b7 c0             	movzwl %ax,%eax
    d388:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d38b:	48 0f af c1          	imul   %rcx,%rax
    d38f:	48 c1 e8 20          	shr    $0x20,%rax
    d393:	48 39 d0             	cmp    %rdx,%rax
    d396:	73 13                	jae    d3ab <f0+0x25bb>
    d398:	49 01 c4             	add    %rax,%r12
    d39b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3a0:	0f 84 0f 07 00 00    	je     dab5 <f0+0x2cc5>
    d3a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3b2:	00 f0 3f 
    d3b5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d3bc:	00 
    d3bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d3c2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d3c9:	00 
    d3ca:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d3d1:	00 
    d3d2:	e8 99 87 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d3d7:	48 8b 15 5a 77 01 00 	mov    0x1775a(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d3de:	49 89 c5             	mov    %rax,%r13
    d3e1:	48 2b 05 28 77 01 00 	sub    0x17728(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d3e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d3ec:	48 39 d0             	cmp    %rdx,%rax
    d3ef:	73 59                	jae    d44a <f0+0x265a>
    d3f1:	48 89 c2             	mov    %rax,%rdx
    d3f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d3f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3fc:	48 8b 15 55 77 01 00 	mov    0x17755(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d403:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d407:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d40b:	4d 85 e4             	test   %r12,%r12
    d40e:	74 3a                	je     d44a <f0+0x265a>
    d410:	0f b6 0a             	movzbl (%rdx),%ecx
    d413:	80 f9 02             	cmp    $0x2,%cl
    d416:	0f 84 04 04 00 00    	je     d820 <f0+0x2a30>
    d41c:	80 f9 01             	cmp    $0x1,%cl
    d41f:	75 29                	jne    d44a <f0+0x265a>
    d421:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d424:	0f b7 c0             	movzwl %ax,%eax
    d427:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d42a:	48 0f af c1          	imul   %rcx,%rax
    d42e:	48 c1 e8 20          	shr    $0x20,%rax
    d432:	48 39 d0             	cmp    %rdx,%rax
    d435:	73 13                	jae    d44a <f0+0x265a>
    d437:	49 01 c4             	add    %rax,%r12
    d43a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d43f:	0f 84 7d 06 00 00    	je     dac2 <f0+0x2cd2>
    d445:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d44a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d451:	33 f3 bf 
    d454:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d45b:	00 
    d45c:	bf 01 00 00 00       	mov    $0x1,%edi
    d461:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d468:	00 
    d469:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d470:	00 
    d471:	e8 fa 86 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d476:	48 8b 15 bb 76 01 00 	mov    0x176bb(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d47d:	49 89 c5             	mov    %rax,%r13
    d480:	48 2b 05 89 76 01 00 	sub    0x17689(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d487:	48 c1 e2 10          	shl    $0x10,%rdx
    d48b:	48 39 d0             	cmp    %rdx,%rax
    d48e:	73 59                	jae    d4e9 <f0+0x26f9>
    d490:	48 89 c2             	mov    %rax,%rdx
    d493:	48 c1 ea 10          	shr    $0x10,%rdx
    d497:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d49b:	48 8b 15 b6 76 01 00 	mov    0x176b6(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d4a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4a6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4aa:	4d 85 e4             	test   %r12,%r12
    d4ad:	74 3a                	je     d4e9 <f0+0x26f9>
    d4af:	0f b6 0a             	movzbl (%rdx),%ecx
    d4b2:	80 f9 02             	cmp    $0x2,%cl
    d4b5:	0f 84 55 03 00 00    	je     d810 <f0+0x2a20>
    d4bb:	80 f9 01             	cmp    $0x1,%cl
    d4be:	75 29                	jne    d4e9 <f0+0x26f9>
    d4c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4c3:	0f b7 c0             	movzwl %ax,%eax
    d4c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4c9:	48 0f af c1          	imul   %rcx,%rax
    d4cd:	48 c1 e8 20          	shr    $0x20,%rax
    d4d1:	48 39 d0             	cmp    %rdx,%rax
    d4d4:	73 13                	jae    d4e9 <f0+0x26f9>
    d4d6:	49 01 c4             	add    %rax,%r12
    d4d9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4de:	0f 84 eb 05 00 00    	je     dacf <f0+0x2cdf>
    d4e4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4e9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4f0:	00 f0 3f 
    d4f3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d4fa:	00 
    d4fb:	bf 01 00 00 00       	mov    $0x1,%edi
    d500:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d507:	00 
    d508:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d50f:	00 
    d510:	e8 5b 86 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d515:	48 8b 15 1c 76 01 00 	mov    0x1761c(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d51c:	49 89 c5             	mov    %rax,%r13
    d51f:	48 2b 05 ea 75 01 00 	sub    0x175ea(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d526:	48 c1 e2 10          	shl    $0x10,%rdx
    d52a:	48 39 d0             	cmp    %rdx,%rax
    d52d:	73 59                	jae    d588 <f0+0x2798>
    d52f:	48 89 c2             	mov    %rax,%rdx
    d532:	48 c1 ea 10          	shr    $0x10,%rdx
    d536:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d53a:	48 8b 15 17 76 01 00 	mov    0x17617(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d541:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d545:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d549:	4d 85 e4             	test   %r12,%r12
    d54c:	74 3a                	je     d588 <f0+0x2798>
    d54e:	0f b6 0a             	movzbl (%rdx),%ecx
    d551:	80 f9 02             	cmp    $0x2,%cl
    d554:	0f 84 a6 02 00 00    	je     d800 <f0+0x2a10>
    d55a:	80 f9 01             	cmp    $0x1,%cl
    d55d:	75 29                	jne    d588 <f0+0x2798>
    d55f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d562:	0f b7 c0             	movzwl %ax,%eax
    d565:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d568:	48 0f af c1          	imul   %rcx,%rax
    d56c:	48 c1 e8 20          	shr    $0x20,%rax
    d570:	48 39 d0             	cmp    %rdx,%rax
    d573:	73 13                	jae    d588 <f0+0x2798>
    d575:	49 01 c4             	add    %rax,%r12
    d578:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d57d:	0f 84 59 05 00 00    	je     dadc <f0+0x2cec>
    d583:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d588:	48 89 ee             	mov    %rbp,%rsi
    d58b:	bf 01 00 00 00       	mov    $0x1,%edi
    d590:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d597:	33 f3 bf 
    d59a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d5a1:	00 
    d5a2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d5a9:	00 
    d5aa:	e8 c1 85 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    d5af:	48 8b 15 82 75 01 00 	mov    0x17582(%rip),%rdx        # 24b38 <fwp_heap+0x13d8>
    d5b6:	48 89 c5             	mov    %rax,%rbp
    d5b9:	48 2b 05 50 75 01 00 	sub    0x17550(%rip),%rax        # 24b10 <fwp_heap+0x13b0>
    d5c0:	48 c1 e2 10          	shl    $0x10,%rdx
    d5c4:	48 39 d0             	cmp    %rdx,%rax
    d5c7:	73 59                	jae    d622 <f0+0x2832>
    d5c9:	48 89 c2             	mov    %rax,%rdx
    d5cc:	48 c1 ea 10          	shr    $0x10,%rdx
    d5d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5d4:	48 8b 15 7d 75 01 00 	mov    0x1757d(%rip),%rdx        # 24b58 <fwp_heap+0x13f8>
    d5db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5df:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5e3:	4d 85 e4             	test   %r12,%r12
    d5e6:	74 3a                	je     d622 <f0+0x2832>
    d5e8:	0f b6 0a             	movzbl (%rdx),%ecx
    d5eb:	80 f9 02             	cmp    $0x2,%cl
    d5ee:	0f 84 fc 01 00 00    	je     d7f0 <f0+0x2a00>
    d5f4:	80 f9 01             	cmp    $0x1,%cl
    d5f7:	75 29                	jne    d622 <f0+0x2832>
    d5f9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5fc:	0f b7 c0             	movzwl %ax,%eax
    d5ff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d602:	48 0f af c1          	imul   %rcx,%rax
    d606:	48 c1 e8 20          	shr    $0x20,%rax
    d60a:	48 39 d0             	cmp    %rdx,%rax
    d60d:	73 13                	jae    d622 <f0+0x2832>
    d60f:	49 01 c4             	add    %rax,%r12
    d612:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d617:	0f 84 d1 02 00 00    	je     d8ee <f0+0x2afe>
    d61d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d622:	48 89 de             	mov    %rbx,%rsi
    d625:	48 89 ef             	mov    %rbp,%rdi
    d628:	e8 d3 be ff ff       	call   9500 <fwp_hof0.constprop.0>
    d62d:	48 89 ef             	mov    %rbp,%rdi
    d630:	e8 0b a3 ff ff       	call   7940 <fwp_drop0>
    d635:	48 89 df             	mov    %rbx,%rdi
    d638:	e8 03 a3 ff ff       	call   7940 <fwp_drop0>
    d63d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d644:	00 
    d645:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d64c:	00 00 
    d64e:	0f 85 95 04 00 00    	jne    dae9 <f0+0x2cf9>
    d654:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d65b:	31 c0                	xor    %eax,%eax
    d65d:	5b                   	pop    %rbx
    d65e:	5d                   	pop    %rbp
    d65f:	41 5c                	pop    %r12
    d661:	41 5d                	pop    %r13
    d663:	41 5e                	pop    %r14
    d665:	c3                   	ret
    d666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d66d:	00 00 00 
    d670:	4c 89 ef             	mov    %r13,%rdi
    d673:	e8 98 7c ff ff       	call   5310 <fwp_rc_forget_slot>
    d678:	e9 2c d8 ff ff       	jmp    aea9 <f0+0xb9>
    d67d:	0f 1f 00             	nopl   (%rax)
    d680:	66 85 c0             	test   %ax,%ax
    d683:	0f 85 ae f5 ff ff    	jne    cc37 <f0+0x1e47>
    d689:	e9 99 f5 ff ff       	jmp    cc27 <f0+0x1e37>
    d68e:	66 90                	xchg   %ax,%ax
    d690:	66 85 c0             	test   %ax,%ax
    d693:	0f 85 ff f4 ff ff    	jne    cb98 <f0+0x1da8>
    d699:	e9 ea f4 ff ff       	jmp    cb88 <f0+0x1d98>
    d69e:	66 90                	xchg   %ax,%ax
    d6a0:	66 85 c0             	test   %ax,%ax
    d6a3:	0f 85 50 f4 ff ff    	jne    caf9 <f0+0x1d09>
    d6a9:	e9 3b f4 ff ff       	jmp    cae9 <f0+0x1cf9>
    d6ae:	66 90                	xchg   %ax,%ax
    d6b0:	66 85 c0             	test   %ax,%ax
    d6b3:	0f 85 a1 f3 ff ff    	jne    ca5a <f0+0x1c6a>
    d6b9:	e9 8c f3 ff ff       	jmp    ca4a <f0+0x1c5a>
    d6be:	66 90                	xchg   %ax,%ax
    d6c0:	66 85 c0             	test   %ax,%ax
    d6c3:	0f 85 f2 f2 ff ff    	jne    c9bb <f0+0x1bcb>
    d6c9:	e9 dd f2 ff ff       	jmp    c9ab <f0+0x1bbb>
    d6ce:	66 90                	xchg   %ax,%ax
    d6d0:	66 85 c0             	test   %ax,%ax
    d6d3:	0f 85 43 f2 ff ff    	jne    c91c <f0+0x1b2c>
    d6d9:	e9 2e f2 ff ff       	jmp    c90c <f0+0x1b1c>
    d6de:	66 90                	xchg   %ax,%ax
    d6e0:	66 85 c0             	test   %ax,%ax
    d6e3:	0f 85 94 f1 ff ff    	jne    c87d <f0+0x1a8d>
    d6e9:	e9 7f f1 ff ff       	jmp    c86d <f0+0x1a7d>
    d6ee:	66 90                	xchg   %ax,%ax
    d6f0:	66 85 c0             	test   %ax,%ax
    d6f3:	0f 85 e5 f0 ff ff    	jne    c7de <f0+0x19ee>
    d6f9:	e9 d0 f0 ff ff       	jmp    c7ce <f0+0x19de>
    d6fe:	66 90                	xchg   %ax,%ax
    d700:	66 85 c0             	test   %ax,%ax
    d703:	0f 85 fd d9 ff ff    	jne    b106 <f0+0x316>
    d709:	e9 e8 d9 ff ff       	jmp    b0f6 <f0+0x306>
    d70e:	66 90                	xchg   %ax,%ax
    d710:	66 85 c0             	test   %ax,%ax
    d713:	0f 85 57 d9 ff ff    	jne    b070 <f0+0x280>
    d719:	e9 42 d9 ff ff       	jmp    b060 <f0+0x270>
    d71e:	66 90                	xchg   %ax,%ax
    d720:	66 85 c0             	test   %ax,%ax
    d723:	0f 85 b1 d8 ff ff    	jne    afda <f0+0x1ea>
    d729:	e9 9c d8 ff ff       	jmp    afca <f0+0x1da>
    d72e:	66 90                	xchg   %ax,%ax
    d730:	66 85 c0             	test   %ax,%ax
    d733:	0f 85 0e eb ff ff    	jne    c247 <f0+0x1457>
    d739:	e9 f9 ea ff ff       	jmp    c237 <f0+0x1447>
    d73e:	66 90                	xchg   %ax,%ax
    d740:	66 85 c0             	test   %ax,%ax
    d743:	0f 85 5f ea ff ff    	jne    c1a8 <f0+0x13b8>
    d749:	e9 4a ea ff ff       	jmp    c198 <f0+0x13a8>
    d74e:	66 90                	xchg   %ax,%ax
    d750:	66 85 c0             	test   %ax,%ax
    d753:	0f 85 e2 da ff ff    	jne    b23b <f0+0x44b>
    d759:	e9 cd da ff ff       	jmp    b22b <f0+0x43b>
    d75e:	66 90                	xchg   %ax,%ax
    d760:	66 85 c0             	test   %ax,%ax
    d763:	0f 85 33 da ff ff    	jne    b19c <f0+0x3ac>
    d769:	e9 1e da ff ff       	jmp    b18c <f0+0x39c>
    d76e:	66 90                	xchg   %ax,%ax
    d770:	66 85 c0             	test   %ax,%ax
    d773:	0f 85 c6 ef ff ff    	jne    c73f <f0+0x194f>
    d779:	e9 b1 ef ff ff       	jmp    c72f <f0+0x193f>
    d77e:	66 90                	xchg   %ax,%ax
    d780:	66 85 c0             	test   %ax,%ax
    d783:	0f 85 17 ef ff ff    	jne    c6a0 <f0+0x18b0>
    d789:	e9 02 ef ff ff       	jmp    c690 <f0+0x18a0>
    d78e:	66 90                	xchg   %ax,%ax
    d790:	66 85 c0             	test   %ax,%ax
    d793:	0f 85 68 ee ff ff    	jne    c601 <f0+0x1811>
    d799:	e9 53 ee ff ff       	jmp    c5f1 <f0+0x1801>
    d79e:	66 90                	xchg   %ax,%ax
    d7a0:	66 85 c0             	test   %ax,%ax
    d7a3:	0f 85 b9 ed ff ff    	jne    c562 <f0+0x1772>
    d7a9:	e9 a4 ed ff ff       	jmp    c552 <f0+0x1762>
    d7ae:	66 90                	xchg   %ax,%ax
    d7b0:	66 85 c0             	test   %ax,%ax
    d7b3:	0f 85 0a ed ff ff    	jne    c4c3 <f0+0x16d3>
    d7b9:	e9 f5 ec ff ff       	jmp    c4b3 <f0+0x16c3>
    d7be:	66 90                	xchg   %ax,%ax
    d7c0:	66 85 c0             	test   %ax,%ax
    d7c3:	0f 85 5b ec ff ff    	jne    c424 <f0+0x1634>
    d7c9:	e9 46 ec ff ff       	jmp    c414 <f0+0x1624>
    d7ce:	66 90                	xchg   %ax,%ax
    d7d0:	66 85 c0             	test   %ax,%ax
    d7d3:	0f 85 ac eb ff ff    	jne    c385 <f0+0x1595>
    d7d9:	e9 97 eb ff ff       	jmp    c375 <f0+0x1585>
    d7de:	66 90                	xchg   %ax,%ax
    d7e0:	66 85 c0             	test   %ax,%ax
    d7e3:	0f 85 fd ea ff ff    	jne    c2e6 <f0+0x14f6>
    d7e9:	e9 e8 ea ff ff       	jmp    c2d6 <f0+0x14e6>
    d7ee:	66 90                	xchg   %ax,%ax
    d7f0:	66 85 c0             	test   %ax,%ax
    d7f3:	0f 85 29 fe ff ff    	jne    d622 <f0+0x2832>
    d7f9:	e9 14 fe ff ff       	jmp    d612 <f0+0x2822>
    d7fe:	66 90                	xchg   %ax,%ax
    d800:	66 85 c0             	test   %ax,%ax
    d803:	0f 85 7f fd ff ff    	jne    d588 <f0+0x2798>
    d809:	e9 6a fd ff ff       	jmp    d578 <f0+0x2788>
    d80e:	66 90                	xchg   %ax,%ax
    d810:	66 85 c0             	test   %ax,%ax
    d813:	0f 85 d0 fc ff ff    	jne    d4e9 <f0+0x26f9>
    d819:	e9 bb fc ff ff       	jmp    d4d9 <f0+0x26e9>
    d81e:	66 90                	xchg   %ax,%ax
    d820:	66 85 c0             	test   %ax,%ax
    d823:	0f 85 21 fc ff ff    	jne    d44a <f0+0x265a>
    d829:	e9 0c fc ff ff       	jmp    d43a <f0+0x264a>
    d82e:	66 90                	xchg   %ax,%ax
    d830:	66 85 c0             	test   %ax,%ax
    d833:	0f 85 72 fb ff ff    	jne    d3ab <f0+0x25bb>
    d839:	e9 5d fb ff ff       	jmp    d39b <f0+0x25ab>
    d83e:	66 90                	xchg   %ax,%ax
    d840:	66 85 c0             	test   %ax,%ax
    d843:	0f 85 c3 fa ff ff    	jne    d30c <f0+0x251c>
    d849:	e9 ae fa ff ff       	jmp    d2fc <f0+0x250c>
    d84e:	66 90                	xchg   %ax,%ax
    d850:	66 85 c0             	test   %ax,%ax
    d853:	0f 85 14 fa ff ff    	jne    d26d <f0+0x247d>
    d859:	e9 ff f9 ff ff       	jmp    d25d <f0+0x246d>
    d85e:	66 90                	xchg   %ax,%ax
    d860:	66 85 c0             	test   %ax,%ax
    d863:	0f 85 65 f9 ff ff    	jne    d1ce <f0+0x23de>
    d869:	e9 50 f9 ff ff       	jmp    d1be <f0+0x23ce>
    d86e:	66 90                	xchg   %ax,%ax
    d870:	66 85 c0             	test   %ax,%ax
    d873:	0f 85 b6 f8 ff ff    	jne    d12f <f0+0x233f>
    d879:	e9 a1 f8 ff ff       	jmp    d11f <f0+0x232f>
    d87e:	66 90                	xchg   %ax,%ax
    d880:	66 85 c0             	test   %ax,%ax
    d883:	0f 85 07 f8 ff ff    	jne    d090 <f0+0x22a0>
    d889:	e9 f2 f7 ff ff       	jmp    d080 <f0+0x2290>
    d88e:	66 90                	xchg   %ax,%ax
    d890:	66 85 c0             	test   %ax,%ax
    d893:	0f 85 58 f7 ff ff    	jne    cff1 <f0+0x2201>
    d899:	e9 43 f7 ff ff       	jmp    cfe1 <f0+0x21f1>
    d89e:	66 90                	xchg   %ax,%ax
    d8a0:	66 85 c0             	test   %ax,%ax
    d8a3:	0f 85 a9 f6 ff ff    	jne    cf52 <f0+0x2162>
    d8a9:	e9 94 f6 ff ff       	jmp    cf42 <f0+0x2152>
    d8ae:	66 90                	xchg   %ax,%ax
    d8b0:	66 85 c0             	test   %ax,%ax
    d8b3:	0f 85 fa f5 ff ff    	jne    ceb3 <f0+0x20c3>
    d8b9:	e9 e5 f5 ff ff       	jmp    cea3 <f0+0x20b3>
    d8be:	66 90                	xchg   %ax,%ax
    d8c0:	66 85 c0             	test   %ax,%ax
    d8c3:	0f 85 4b f5 ff ff    	jne    ce14 <f0+0x2024>
    d8c9:	e9 36 f5 ff ff       	jmp    ce04 <f0+0x2014>
    d8ce:	66 90                	xchg   %ax,%ax
    d8d0:	66 85 c0             	test   %ax,%ax
    d8d3:	0f 85 9c f4 ff ff    	jne    cd75 <f0+0x1f85>
    d8d9:	e9 87 f4 ff ff       	jmp    cd65 <f0+0x1f75>
    d8de:	66 90                	xchg   %ax,%ax
    d8e0:	66 85 c0             	test   %ax,%ax
    d8e3:	0f 85 ed f3 ff ff    	jne    ccd6 <f0+0x1ee6>
    d8e9:	e9 d8 f3 ff ff       	jmp    ccc6 <f0+0x1ed6>
    d8ee:	4c 89 e7             	mov    %r12,%rdi
    d8f1:	e8 1a 7a ff ff       	call   5310 <fwp_rc_forget_slot>
    d8f6:	e9 22 fd ff ff       	jmp    d61d <f0+0x282d>
    d8fb:	4c 89 e7             	mov    %r12,%rdi
    d8fe:	e8 0d 7a ff ff       	call   5310 <fwp_rc_forget_slot>
    d903:	e9 cd d6 ff ff       	jmp    afd5 <f0+0x1e5>
    d908:	4c 89 e7             	mov    %r12,%rdi
    d90b:	e8 00 7a ff ff       	call   5310 <fwp_rc_forget_slot>
    d910:	e9 56 d7 ff ff       	jmp    b06b <f0+0x27b>
    d915:	4c 89 e7             	mov    %r12,%rdi
    d918:	e8 f3 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d91d:	e9 df d7 ff ff       	jmp    b101 <f0+0x311>
    d922:	4c 89 e7             	mov    %r12,%rdi
    d925:	e8 e6 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d92a:	e9 68 d8 ff ff       	jmp    b197 <f0+0x3a7>
    d92f:	4c 89 e7             	mov    %r12,%rdi
    d932:	e8 d9 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d937:	e9 fa d8 ff ff       	jmp    b236 <f0+0x446>
    d93c:	4c 89 e7             	mov    %r12,%rdi
    d93f:	e8 cc 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d944:	e9 5a e8 ff ff       	jmp    c1a3 <f0+0x13b3>
    d949:	4c 89 e7             	mov    %r12,%rdi
    d94c:	e8 bf 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d951:	e9 ec e8 ff ff       	jmp    c242 <f0+0x1452>
    d956:	4c 89 e7             	mov    %r12,%rdi
    d959:	e8 b2 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d95e:	e9 7e e9 ff ff       	jmp    c2e1 <f0+0x14f1>
    d963:	4c 89 e7             	mov    %r12,%rdi
    d966:	e8 a5 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d96b:	e9 10 ea ff ff       	jmp    c380 <f0+0x1590>
    d970:	4c 89 e7             	mov    %r12,%rdi
    d973:	e8 98 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d978:	e9 a2 ea ff ff       	jmp    c41f <f0+0x162f>
    d97d:	4c 89 e7             	mov    %r12,%rdi
    d980:	e8 8b 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d985:	e9 34 eb ff ff       	jmp    c4be <f0+0x16ce>
    d98a:	4c 89 e7             	mov    %r12,%rdi
    d98d:	e8 7e 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d992:	e9 c6 eb ff ff       	jmp    c55d <f0+0x176d>
    d997:	4c 89 e7             	mov    %r12,%rdi
    d99a:	e8 71 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d99f:	e9 58 ec ff ff       	jmp    c5fc <f0+0x180c>
    d9a4:	4c 89 e7             	mov    %r12,%rdi
    d9a7:	e8 64 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9ac:	e9 ea ec ff ff       	jmp    c69b <f0+0x18ab>
    d9b1:	4c 89 e7             	mov    %r12,%rdi
    d9b4:	e8 57 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9b9:	e9 7c ed ff ff       	jmp    c73a <f0+0x194a>
    d9be:	4c 89 e7             	mov    %r12,%rdi
    d9c1:	e8 4a 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9c6:	e9 0e ee ff ff       	jmp    c7d9 <f0+0x19e9>
    d9cb:	4c 89 e7             	mov    %r12,%rdi
    d9ce:	e8 3d 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9d3:	e9 a0 ee ff ff       	jmp    c878 <f0+0x1a88>
    d9d8:	4c 89 e7             	mov    %r12,%rdi
    d9db:	e8 30 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9e0:	e9 32 ef ff ff       	jmp    c917 <f0+0x1b27>
    d9e5:	4c 89 e7             	mov    %r12,%rdi
    d9e8:	e8 23 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9ed:	e9 c4 ef ff ff       	jmp    c9b6 <f0+0x1bc6>
    d9f2:	4c 89 e7             	mov    %r12,%rdi
    d9f5:	e8 16 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    d9fa:	e9 56 f0 ff ff       	jmp    ca55 <f0+0x1c65>
    d9ff:	4c 89 e7             	mov    %r12,%rdi
    da02:	e8 09 79 ff ff       	call   5310 <fwp_rc_forget_slot>
    da07:	e9 e8 f0 ff ff       	jmp    caf4 <f0+0x1d04>
    da0c:	4c 89 e7             	mov    %r12,%rdi
    da0f:	e8 fc 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da14:	e9 7a f1 ff ff       	jmp    cb93 <f0+0x1da3>
    da19:	4c 89 e7             	mov    %r12,%rdi
    da1c:	e8 ef 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da21:	e9 0c f2 ff ff       	jmp    cc32 <f0+0x1e42>
    da26:	4c 89 e7             	mov    %r12,%rdi
    da29:	e8 e2 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da2e:	e9 9e f2 ff ff       	jmp    ccd1 <f0+0x1ee1>
    da33:	4c 89 e7             	mov    %r12,%rdi
    da36:	e8 d5 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da3b:	e9 30 f3 ff ff       	jmp    cd70 <f0+0x1f80>
    da40:	4c 89 e7             	mov    %r12,%rdi
    da43:	e8 c8 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da48:	e9 c2 f3 ff ff       	jmp    ce0f <f0+0x201f>
    da4d:	4c 89 e7             	mov    %r12,%rdi
    da50:	e8 bb 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da55:	e9 54 f4 ff ff       	jmp    ceae <f0+0x20be>
    da5a:	4c 89 e7             	mov    %r12,%rdi
    da5d:	e8 ae 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da62:	e9 e6 f4 ff ff       	jmp    cf4d <f0+0x215d>
    da67:	4c 89 e7             	mov    %r12,%rdi
    da6a:	e8 a1 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da6f:	e9 78 f5 ff ff       	jmp    cfec <f0+0x21fc>
    da74:	4c 89 e7             	mov    %r12,%rdi
    da77:	e8 94 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da7c:	e9 0a f6 ff ff       	jmp    d08b <f0+0x229b>
    da81:	4c 89 e7             	mov    %r12,%rdi
    da84:	e8 87 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da89:	e9 9c f6 ff ff       	jmp    d12a <f0+0x233a>
    da8e:	4c 89 e7             	mov    %r12,%rdi
    da91:	e8 7a 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    da96:	e9 2e f7 ff ff       	jmp    d1c9 <f0+0x23d9>
    da9b:	4c 89 e7             	mov    %r12,%rdi
    da9e:	e8 6d 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    daa3:	e9 c0 f7 ff ff       	jmp    d268 <f0+0x2478>
    daa8:	4c 89 e7             	mov    %r12,%rdi
    daab:	e8 60 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    dab0:	e9 52 f8 ff ff       	jmp    d307 <f0+0x2517>
    dab5:	4c 89 e7             	mov    %r12,%rdi
    dab8:	e8 53 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    dabd:	e9 e4 f8 ff ff       	jmp    d3a6 <f0+0x25b6>
    dac2:	4c 89 e7             	mov    %r12,%rdi
    dac5:	e8 46 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    daca:	e9 76 f9 ff ff       	jmp    d445 <f0+0x2655>
    dacf:	4c 89 e7             	mov    %r12,%rdi
    dad2:	e8 39 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    dad7:	e9 08 fa ff ff       	jmp    d4e4 <f0+0x26f4>
    dadc:	4c 89 e7             	mov    %r12,%rdi
    dadf:	e8 2c 78 ff ff       	call   5310 <fwp_rc_forget_slot>
    dae4:	e9 9a fa ff ff       	jmp    d583 <f0+0x2793>
    dae9:	e8 72 59 ff ff       	call   3460 <__stack_chk_fail@plt>
    daee:	66 90                	xchg   %ax,%ax

000000000000daf0 <fwp_main_thread>:
    daf0:	f3 0f 1e fa          	endbr64
    daf4:	41 54                	push   %r12
    daf6:	55                   	push   %rbp
    daf7:	53                   	push   %rbx
    daf8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    daff:	8b 0d ff 6f 01 00    	mov    0x16fff(%rip),%ecx        # 24b04 <fwp_heap+0x13a4>
    db05:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    db0c:	00 00 
    db0e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    db15:	00 
    db16:	31 c0                	xor    %eax,%eax
    db18:	85 c9                	test   %ecx,%ecx
    db1a:	0f 84 68 06 00 00    	je     e188 <fwp_main_thread+0x698>
    db20:	8b 15 e2 6f 01 00    	mov    0x16fe2(%rip),%edx        # 24b08 <fwp_heap+0x13a8>
    db26:	85 d2                	test   %edx,%edx
    db28:	0f 85 42 06 00 00    	jne    e170 <fwp_main_thread+0x680>
    db2e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    db33:	31 f6                	xor    %esi,%esi
    db35:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    db3a:	48 c7 05 b3 55 01 00 	movq   $0x40000000,0x155b3(%rip)        # 230f8 <fwp_main_stack_size>
    db41:	00 00 00 40 
    db45:	48 89 05 b4 55 01 00 	mov    %rax,0x155b4(%rip)        # 23100 <fwp_main_stack_top>
    db4c:	48 8d 05 2d 55 00 00 	lea    0x552d(%rip),%rax        # 13080 <alt.5>
    db53:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    db58:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    db5f:	01 00 
    db61:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    db68:	00 
    db69:	e8 52 5b ff ff       	call   36c0 <sigaltstack@plt>
    db6e:	85 c0                	test   %eax,%eax
    db70:	0f 85 4a 06 00 00    	jne    e1c0 <fwp_main_thread+0x6d0>
    db76:	31 c0                	xor    %eax,%eax
    db78:	b9 12 00 00 00       	mov    $0x12,%ecx
    db7d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    db82:	f3 48 ab             	rep stos %rax,(%rdi)
    db85:	48 8d 05 64 61 ff ff 	lea    -0x9e9c(%rip),%rax        # 3cf0 <fwp_segv>
    db8c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    db91:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    db98:	04 00 00 08 
    db9c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    dba1:	e8 da 59 ff ff       	call   3580 <sigemptyset@plt>
    dba6:	85 c0                	test   %eax,%eax
    dba8:	0f 85 12 06 00 00    	jne    e1c0 <fwp_main_thread+0x6d0>
    dbae:	31 d2                	xor    %edx,%edx
    dbb0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dbb5:	bf 0b 00 00 00       	mov    $0xb,%edi
    dbba:	e8 41 58 ff ff       	call   3400 <sigaction@plt>
    dbbf:	85 c0                	test   %eax,%eax
    dbc1:	0f 85 f9 05 00 00    	jne    e1c0 <fwp_main_thread+0x6d0>
    dbc7:	31 d2                	xor    %edx,%edx
    dbc9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    dbce:	bf 07 00 00 00       	mov    $0x7,%edi
    dbd3:	e8 28 58 ff ff       	call   3400 <sigaction@plt>
    dbd8:	85 c0                	test   %eax,%eax
    dbda:	0f 85 e0 05 00 00    	jne    e1c0 <fwp_main_thread+0x6d0>
    dbe0:	8b 05 8a 54 00 00    	mov    0x548a(%rip),%eax        # 13070 <st.3>
    dbe6:	85 c0                	test   %eax,%eax
    dbe8:	0f 84 62 05 00 00    	je     e150 <fwp_main_thread+0x660>
    dbee:	48 8b 2d 4b 5b 01 00 	mov    0x15b4b(%rip),%rbp        # 23740 <fwp_cur>
    dbf5:	48 85 ed             	test   %rbp,%rbp
    dbf8:	0f 84 72 03 00 00    	je     df70 <fwp_main_thread+0x480>
    dbfe:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    dc03:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    dc07:	48 89 eb             	mov    %rbp,%rbx
    dc0a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dc0f:	0f 84 41 01 00 00    	je     dd56 <fwp_main_thread+0x266>
    dc15:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    dc1a:	0f 84 80 02 00 00    	je     dea0 <fwp_main_thread+0x3b0>
    dc20:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dc24:	0f 84 66 02 00 00    	je     de90 <fwp_main_thread+0x3a0>
    dc2a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    dc2e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dc32:	0f 85 e8 02 00 00    	jne    df20 <fwp_main_thread+0x430>
    dc38:	48 8b 43 60          	mov    0x60(%rbx),%rax
    dc3c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dc43:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dc47:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    dc4e:	00 00 00 00 
    dc52:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dc59:	48 85 d2             	test   %rdx,%rdx
    dc5c:	74 07                	je     dc65 <fwp_main_thread+0x175>
    dc5e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    dc65:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    dc69:	48 85 c0             	test   %rax,%rax
    dc6c:	74 34                	je     dca2 <fwp_main_thread+0x1b2>
    dc6e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    dc72:	48 8b 05 9f 5a 01 00 	mov    0x15a9f(%rip),%rax        # 23718 <fwp_timers>
    dc79:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    dc7d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    dc84:	00 00 00 00 
    dc88:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    dc8f:	48 85 c0             	test   %rax,%rax
    dc92:	74 07                	je     dc9b <fwp_main_thread+0x1ab>
    dc94:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    dc9b:	48 89 1d 76 5a 01 00 	mov    %rbx,0x15a76(%rip)        # 23718 <fwp_timers>
    dca2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    dca6:	e8 65 98 ff ff       	call   7510 <fwp_block>
    dcab:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    dcb2:	48 85 c9             	test   %rcx,%rcx
    dcb5:	74 47                	je     dcfe <fwp_main_thread+0x20e>
    dcb7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    dcbe:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dcc5:	48 85 d2             	test   %rdx,%rdx
    dcc8:	0f 84 92 02 00 00    	je     df60 <fwp_main_thread+0x470>
    dcce:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    dcd5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    dcdc:	48 85 c0             	test   %rax,%rax
    dcdf:	74 07                	je     dce8 <fwp_main_thread+0x1f8>
    dce1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    dce8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    dcef:	00 00 00 00 
    dcf3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    dcf7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    dcfe:	48 8b 0d 3b 5a 01 00 	mov    0x15a3b(%rip),%rcx        # 23740 <fwp_cur>
    dd05:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    dd09:	0f 84 01 02 00 00    	je     df10 <fwp_main_thread+0x420>
    dd0f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    dd16:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    dd1d:	48 85 d2             	test   %rdx,%rdx
    dd20:	0f 84 fa 03 00 00    	je     e120 <fwp_main_thread+0x630>
    dd26:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    dd2d:	48 85 c0             	test   %rax,%rax
    dd30:	74 07                	je     dd39 <fwp_main_thread+0x249>
    dd32:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    dd39:	66 0f ef c9          	pxor   %xmm1,%xmm1
    dd3d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    dd41:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    dd48:	48 89 cb             	mov    %rcx,%rbx
    dd4b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dd50:	0f 85 bf fe ff ff    	jne    dc15 <fwp_main_thread+0x125>
    dd56:	48 83 3d 7a 76 01 00 	cmpq   $0x0,0x1767a(%rip)        # 253d8 <fwp_state_len>
    dd5d:	00 
    dd5e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    dd62:	0f 84 ba 00 00 00    	je     de22 <fwp_main_thread+0x332>
    dd68:	48 39 1d c9 59 01 00 	cmp    %rbx,0x159c9(%rip)        # 23738 <fwp_root>
    dd6f:	c7 05 07 53 01 00 00 	movl   $0x0,0x15307(%rip)        # 23080 <fwp_exit_code>
    dd76:	00 00 00 
    dd79:	0f 85 5f 04 00 00    	jne    e1de <fwp_main_thread+0x6ee>
    dd7f:	48 85 db             	test   %rbx,%rbx
    dd82:	0f 84 0e 02 00 00    	je     df96 <fwp_main_thread+0x4a6>
    dd88:	48 8b 15 79 59 01 00 	mov    0x15979(%rip),%rdx        # 23708 <fwp_tasks_active>
    dd8f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    dd93:	48 85 d2             	test   %rdx,%rdx
    dd96:	0f 84 fa 01 00 00    	je     df96 <fwp_main_thread+0x4a6>
    dd9c:	0f 1f 40 00          	nopl   0x0(%rax)
    dda0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    dda4:	75 08                	jne    ddae <fwp_main_thread+0x2be>
    dda6:	48 89 d7             	mov    %rdx,%rdi
    dda9:	e8 02 63 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    ddae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ddb5:	48 85 d2             	test   %rdx,%rdx
    ddb8:	75 e6                	jne    dda0 <fwp_main_thread+0x2b0>
    ddba:	eb 31                	jmp    dded <fwp_main_thread+0x2fd>
    ddbc:	0f 1f 40 00          	nopl   0x0(%rax)
    ddc0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    ddc7:	48 89 1d 52 59 01 00 	mov    %rbx,0x15952(%rip)        # 23720 <fwp_ready_tail>
    ddce:	e8 3d 97 ff ff       	call   7510 <fwp_block>
    ddd3:	e8 28 95 ff ff       	call   7300 <fwp_free_zombie>
    ddd8:	48 83 3d 28 59 01 00 	cmpq   $0x0,0x15928(%rip)        # 23708 <fwp_tasks_active>
    dddf:	00 
    dde0:	0f 84 b0 01 00 00    	je     df96 <fwp_main_thread+0x4a6>
    dde6:	48 8b 1d 4b 59 01 00 	mov    0x1594b(%rip),%rbx        # 23738 <fwp_root>
    dded:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ddf1:	75 db                	jne    ddce <fwp_main_thread+0x2de>
    ddf3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ddf7:	75 d5                	jne    ddce <fwp_main_thread+0x2de>
    ddf9:	48 8b 05 20 59 01 00 	mov    0x15920(%rip),%rax        # 23720 <fwp_ready_tail>
    de00:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    de04:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    de0b:	00 00 00 00 
    de0f:	48 85 c0             	test   %rax,%rax
    de12:	75 ac                	jne    ddc0 <fwp_main_thread+0x2d0>
    de14:	48 89 1d 0d 59 01 00 	mov    %rbx,0x1590d(%rip)        # 23728 <fwp_ready_head>
    de1b:	eb aa                	jmp    ddc7 <fwp_main_thread+0x2d7>
    de1d:	0f 1f 00             	nopl   (%rax)
    de20:	31 db                	xor    %ebx,%ebx
    de22:	48 83 3d 9e 75 01 00 	cmpq   $0x0,0x1759e(%rip)        # 253c8 <fwp_state_owners>
    de29:	00 
    de2a:	0f 85 38 ff ff ff    	jne    dd68 <fwp_main_thread+0x278>
    de30:	48 8b 3d a9 75 01 00 	mov    0x175a9(%rip),%rdi        # 253e0 <fwp_state>
    de37:	e8 14 77 ff ff       	call   5550 <fwp_mem_free>
    de3c:	48 c7 05 99 75 01 00 	movq   $0x0,0x17599(%rip)        # 253e0 <fwp_state>
    de43:	00 00 00 00 
    de47:	48 c7 05 7e 75 01 00 	movq   $0x0,0x1757e(%rip)        # 253d0 <fwp_state_cap>
    de4e:	00 00 00 00 
    de52:	48 85 db             	test   %rbx,%rbx
    de55:	0f 84 46 03 00 00    	je     e1a1 <fwp_main_thread+0x6b1>
    de5b:	48 39 1d d6 58 01 00 	cmp    %rbx,0x158d6(%rip)        # 23738 <fwp_root>
    de62:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    de69:	00 00 00 00 
    de6d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    de74:	00 00 00 00 
    de78:	c7 05 fe 51 01 00 00 	movl   $0x0,0x151fe(%rip)        # 23080 <fwp_exit_code>
    de7f:	00 00 00 
    de82:	0f 84 00 ff ff ff    	je     dd88 <fwp_main_thread+0x298>
    de88:	e9 c8 58 ff ff       	jmp    3755 <fwp_main_thread.cold>
    de8d:	0f 1f 00             	nopl   (%rax)
    de90:	e8 7b 64 ff ff       	call   4310 <fwp_now_ns>
    de95:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    de99:	0f 8d 91 02 00 00    	jge    e130 <fwp_main_thread+0x640>
    de9f:	90                   	nop
    dea0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    dea4:	0f 85 80 fd ff ff    	jne    dc2a <fwp_main_thread+0x13a>
    deaa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    deae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    deb2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    deb6:	0f 85 80 fd ff ff    	jne    dc3c <fwp_main_thread+0x14c>
    debc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    dec0:	48 85 c9             	test   %rcx,%rcx
    dec3:	0f 84 73 fd ff ff    	je     dc3c <fwp_main_thread+0x14c>
    dec9:	48 85 c0             	test   %rax,%rax
    decc:	0f 84 ff 02 00 00    	je     e1d1 <fwp_main_thread+0x6e1>
    ded2:	48 39 c8             	cmp    %rcx,%rax
    ded5:	48 0f 4f c1          	cmovg  %rcx,%rax
    ded9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    dee0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    dee4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    deeb:	00 00 00 00 
    deef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    def6:	48 85 d2             	test   %rdx,%rdx
    def9:	74 07                	je     df02 <fwp_main_thread+0x412>
    defb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    df02:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df06:	e9 63 fd ff ff       	jmp    dc6e <fwp_main_thread+0x17e>
    df0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    df10:	48 89 cb             	mov    %rcx,%rbx
    df13:	e9 f2 fc ff ff       	jmp    dc0a <fwp_main_thread+0x11a>
    df18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    df1f:	00 
    df20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    df24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    df2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    df32:	00 00 00 00 
    df36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    df3d:	48 85 c0             	test   %rax,%rax
    df40:	0f 84 52 02 00 00    	je     e198 <fwp_main_thread+0x6a8>
    df46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    df4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    df51:	e9 4c fd ff ff       	jmp    dca2 <fwp_main_thread+0x1b2>
    df56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df5d:	00 00 00 
    df60:	48 89 01             	mov    %rax,(%rcx)
    df63:	e9 74 fd ff ff       	jmp    dcdc <fwp_main_thread+0x1ec>
    df68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    df6f:	00 
    df70:	48 83 3d 60 74 01 00 	cmpq   $0x0,0x17460(%rip)        # 253d8 <fwp_state_len>
    df77:	00 
    df78:	0f 84 a2 fe ff ff    	je     de20 <fwp_main_thread+0x330>
    df7e:	48 83 3d b2 57 01 00 	cmpq   $0x0,0x157b2(%rip)        # 23738 <fwp_root>
    df85:	00 
    df86:	c7 05 f0 50 01 00 00 	movl   $0x0,0x150f0(%rip)        # 23080 <fwp_exit_code>
    df8d:	00 00 00 
    df90:	0f 85 43 02 00 00    	jne    e1d9 <fwp_main_thread+0x6e9>
    df96:	e8 65 93 ff ff       	call   7300 <fwp_free_zombie>
    df9b:	48 83 3d 85 57 01 00 	cmpq   $0x0,0x15785(%rip)        # 23728 <fwp_ready_head>
    dfa2:	00 
    dfa3:	0f 85 ac 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfa9:	48 83 3d 67 57 01 00 	cmpq   $0x0,0x15767(%rip)        # 23718 <fwp_timers>
    dfb0:	00 
    dfb1:	0f 85 9e 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    dfb7:	8b 1d 4f 51 01 00    	mov    0x1514f(%rip),%ebx        # 2310c <fwp_stack_pool_n>
    dfbd:	85 db                	test   %ebx,%ebx
    dfbf:	74 36                	je     dff7 <fwp_main_thread+0x507>
    dfc1:	83 eb 01             	sub    $0x1,%ebx
    dfc4:	48 8d 05 55 51 01 00 	lea    0x15155(%rip),%rax        # 23120 <fwp_stack_pool>
    dfcb:	48 63 d3             	movslq %ebx,%rdx
    dfce:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    dfd2:	eb 07                	jmp    dfdb <fwp_main_thread+0x4eb>
    dfd4:	0f 1f 40 00          	nopl   0x0(%rax)
    dfd8:	83 eb 01             	sub    $0x1,%ebx
    dfdb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    dfdf:	be 00 00 00 10       	mov    $0x10000000,%esi
    dfe4:	89 1d 22 51 01 00    	mov    %ebx,0x15122(%rip)        # 2310c <fwp_stack_pool_n>
    dfea:	48 83 ed 08          	sub    $0x8,%rbp
    dfee:	e8 ed 55 ff ff       	call   35e0 <munmap@plt>
    dff3:	85 db                	test   %ebx,%ebx
    dff5:	75 e1                	jne    dfd8 <fwp_main_thread+0x4e8>
    dff7:	8b 3d 1b 50 00 00    	mov    0x501b(%rip),%edi        # 13018 <fwp_epfd>
    dffd:	85 ff                	test   %edi,%edi
    dfff:	78 05                	js     e006 <fwp_main_thread+0x516>
    e001:	e8 ca 54 ff ff       	call   34d0 <close@plt>
    e006:	4c 8b 25 13 53 01 00 	mov    0x15313(%rip),%r12        # 23320 <fwp_nfdws>
    e00d:	48 8b 2d 14 53 01 00 	mov    0x15314(%rip),%rbp        # 23328 <fwp_fdws>
    e014:	31 db                	xor    %ebx,%ebx
    e016:	c7 05 f8 4f 00 00 ff 	movl   $0xffffffff,0x4ff8(%rip)        # 13018 <fwp_epfd>
    e01d:	ff ff ff 
    e020:	4d 85 e4             	test   %r12,%r12
    e023:	74 38                	je     e05d <fwp_main_thread+0x56d>
    e025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e02c:	00 00 00 00 
    e030:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e035:	48 85 ff             	test   %rdi,%rdi
    e038:	74 1a                	je     e054 <fwp_main_thread+0x564>
    e03a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e03e:	0f 85 11 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    e044:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e049:	0f 85 06 57 ff ff    	jne    3755 <fwp_main_thread.cold>
    e04f:	e8 fc 74 ff ff       	call   5550 <fwp_mem_free>
    e054:	48 83 c3 01          	add    $0x1,%rbx
    e058:	4c 39 e3             	cmp    %r12,%rbx
    e05b:	75 d3                	jne    e030 <fwp_main_thread+0x540>
    e05d:	48 89 ef             	mov    %rbp,%rdi
    e060:	e8 eb 74 ff ff       	call   5550 <fwp_mem_free>
    e065:	48 8b 15 cc 56 01 00 	mov    0x156cc(%rip),%rdx        # 23738 <fwp_root>
    e06c:	48 c7 05 b1 52 01 00 	movq   $0x0,0x152b1(%rip)        # 23328 <fwp_fdws>
    e073:	00 00 00 00 
    e077:	48 c7 05 9e 52 01 00 	movq   $0x0,0x1529e(%rip)        # 23320 <fwp_nfdws>
    e07e:	00 00 00 00 
    e082:	48 85 d2             	test   %rdx,%rdx
    e085:	74 4e                	je     e0d5 <fwp_main_thread+0x5e5>
    e087:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e08c:	0f 85 c3 56 ff ff    	jne    3755 <fwp_main_thread.cold>
    e092:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e099:	00 
    e09a:	0f 85 b5 56 ff ff    	jne    3755 <fwp_main_thread.cold>
    e0a0:	48 83 3d 30 73 01 00 	cmpq   $0x0,0x17330(%rip)        # 253d8 <fwp_state_len>
    e0a7:	00 
    e0a8:	0f 85 a7 56 ff ff    	jne    3755 <fwp_main_thread.cold>
    e0ae:	48 83 3d 12 73 01 00 	cmpq   $0x0,0x17312(%rip)        # 253c8 <fwp_state_owners>
    e0b5:	00 
    e0b6:	0f 85 99 56 ff ff    	jne    3755 <fwp_main_thread.cold>
    e0bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e0c1:	31 c0                	xor    %eax,%eax
    e0c3:	48 8d 3d 76 52 01 00 	lea    0x15276(%rip),%rdi        # 23340 <fwp_root_context>
    e0ca:	f3 48 ab             	rep stos %rax,(%rdi)
    e0cd:	48 89 d7             	mov    %rdx,%rdi
    e0d0:	e8 7b 74 ff ff       	call   5550 <fwp_mem_free>
    e0d5:	48 8b 3d 44 4f 00 00 	mov    0x4f44(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e0dc:	48 c7 05 59 56 01 00 	movq   $0x0,0x15659(%rip)        # 23740 <fwp_cur>
    e0e3:	00 00 00 00 
    e0e7:	48 c7 05 46 56 01 00 	movq   $0x0,0x15646(%rip)        # 23738 <fwp_root>
    e0ee:	00 00 00 00 
    e0f2:	e8 c9 54 ff ff       	call   35c0 <fflush@plt>
    e0f7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e0fe:	00 
    e0ff:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e106:	00 00 
    e108:	0f 85 be 00 00 00    	jne    e1cc <fwp_main_thread+0x6dc>
    e10e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e115:	31 c0                	xor    %eax,%eax
    e117:	5b                   	pop    %rbx
    e118:	5d                   	pop    %rbp
    e119:	41 5c                	pop    %r12
    e11b:	c3                   	ret
    e11c:	0f 1f 40 00          	nopl   0x0(%rax)
    e120:	48 89 05 f1 55 01 00 	mov    %rax,0x155f1(%rip)        # 23718 <fwp_timers>
    e127:	e9 01 fc ff ff       	jmp    dd2d <fwp_main_thread+0x23d>
    e12c:	0f 1f 40 00          	nopl   0x0(%rax)
    e130:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e134:	0f 85 66 fd ff ff    	jne    dea0 <fwp_main_thread+0x3b0>
    e13a:	48 89 ef             	mov    %rbp,%rdi
    e13d:	e8 6e 5f ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e142:	e9 59 fd ff ff       	jmp    dea0 <fwp_main_thread+0x3b0>
    e147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e14e:	00 00 
    e150:	e8 9b cc ff ff       	call   adf0 <f0>
    e155:	48 c7 05 08 4f 00 00 	movq   $0x0,0x4f08(%rip)        # 13068 <v.2>
    e15c:	00 00 00 00 
    e160:	c7 05 06 4f 00 00 01 	movl   $0x1,0x4f06(%rip)        # 13070 <st.3>
    e167:	00 00 00 
    e16a:	e9 7f fa ff ff       	jmp    dbee <fwp_main_thread+0xfe>
    e16f:	90                   	nop
    e170:	48 8d 3d a9 68 ff ff 	lea    -0x9757(%rip),%rdi        # 4a20 <fwp_heap_report>
    e177:	e8 84 02 00 00       	call   e400 <atexit>
    e17c:	e9 ad f9 ff ff       	jmp    db2e <fwp_main_thread+0x3e>
    e181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e188:	e8 a3 69 ff ff       	call   4b30 <fwp_heap_init>
    e18d:	e9 8e f9 ff ff       	jmp    db20 <fwp_main_thread+0x30>
    e192:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e198:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e19c:	e9 01 fb ff ff       	jmp    dca2 <fwp_main_thread+0x1b2>
    e1a1:	48 83 3d 8f 55 01 00 	cmpq   $0x0,0x1558f(%rip)        # 23738 <fwp_root>
    e1a8:	00 
    e1a9:	c7 05 cd 4e 01 00 00 	movl   $0x0,0x14ecd(%rip)        # 23080 <fwp_exit_code>
    e1b0:	00 00 00 
    e1b3:	0f 84 dd fd ff ff    	je     df96 <fwp_main_thread+0x4a6>
    e1b9:	e9 97 55 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e1be:	66 90                	xchg   %ax,%ax
    e1c0:	48 8d 3d 31 17 00 00 	lea    0x1731(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    e1c7:	e8 d4 5f ff ff       	call   41a0 <fwp_trap>
    e1cc:	e8 8f 52 ff ff       	call   3460 <__stack_chk_fail@plt>
    e1d1:	48 89 c8             	mov    %rcx,%rax
    e1d4:	e9 00 fd ff ff       	jmp    ded9 <fwp_main_thread+0x3e9>
    e1d9:	e9 77 55 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e1de:	e9 72 55 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e1e3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1ea:	00 00 00 
    e1ed:	0f 1f 00             	nopl   (%rax)

000000000000e1f0 <__divmodti4>:
    e1f0:	f3 0f 1e fa          	endbr64
    e1f4:	55                   	push   %rbp
    e1f5:	49 89 f1             	mov    %rsi,%r9
    e1f8:	49 89 d2             	mov    %rdx,%r10
    e1fb:	48 89 fe             	mov    %rdi,%rsi
    e1fe:	49 89 cb             	mov    %rcx,%r11
    e201:	48 89 e5             	mov    %rsp,%rbp
    e204:	41 57                	push   %r15
    e206:	41 56                	push   %r14
    e208:	41 55                	push   %r13
    e20a:	41 54                	push   %r12
    e20c:	53                   	push   %rbx
    e20d:	4c 89 c3             	mov    %r8,%rbx
    e210:	45 31 c0             	xor    %r8d,%r8d
    e213:	4d 85 c9             	test   %r9,%r9
    e216:	79 12                	jns    e22a <__divmodti4+0x3a>
    e218:	31 ff                	xor    %edi,%edi
    e21a:	48 f7 de             	neg    %rsi
    e21d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e224:	4c 19 cf             	sbb    %r9,%rdi
    e227:	49 89 f9             	mov    %rdi,%r9
    e22a:	4c 89 d8             	mov    %r11,%rax
    e22d:	4d 85 db             	test   %r11,%r11
    e230:	0f 88 1a 01 00 00    	js     e350 <__divmodti4+0x160>
    e236:	4c 89 d9             	mov    %r11,%rcx
    e239:	49 89 f3             	mov    %rsi,%r11
    e23c:	75 62                	jne    e2a0 <__divmodti4+0xb0>
    e23e:	4d 89 c4             	mov    %r8,%r12
    e241:	4d 39 d1             	cmp    %r10,%r9
    e244:	0f 83 46 01 00 00    	jae    e390 <__divmodti4+0x1a0>
    e24a:	4c 89 d8             	mov    %r11,%rax
    e24d:	4c 89 ca             	mov    %r9,%rdx
    e250:	49 f7 f2             	div    %r10
    e253:	49 89 c3             	mov    %rax,%r11
    e256:	31 c0                	xor    %eax,%eax
    e258:	48 89 d6             	mov    %rdx,%rsi
    e25b:	31 ff                	xor    %edi,%edi
    e25d:	4c 89 d9             	mov    %r11,%rcx
    e260:	48 89 c2             	mov    %rax,%rdx
    e263:	48 89 c8             	mov    %rcx,%rax
    e266:	4d 85 e4             	test   %r12,%r12
    e269:	74 0a                	je     e275 <__divmodti4+0x85>
    e26b:	48 f7 d8             	neg    %rax
    e26e:	48 83 d2 00          	adc    $0x0,%rdx
    e272:	48 f7 da             	neg    %rdx
    e275:	4d 85 c0             	test   %r8,%r8
    e278:	74 0a                	je     e284 <__divmodti4+0x94>
    e27a:	48 f7 de             	neg    %rsi
    e27d:	48 83 d7 00          	adc    $0x0,%rdi
    e281:	48 f7 df             	neg    %rdi
    e284:	48 89 33             	mov    %rsi,(%rbx)
    e287:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e28b:	5b                   	pop    %rbx
    e28c:	41 5c                	pop    %r12
    e28e:	41 5d                	pop    %r13
    e290:	41 5e                	pop    %r14
    e292:	41 5f                	pop    %r15
    e294:	5d                   	pop    %rbp
    e295:	c3                   	ret
    e296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e29d:	00 00 00 
    e2a0:	4d 89 c4             	mov    %r8,%r12
    e2a3:	49 39 c1             	cmp    %rax,%r9
    e2a6:	0f 82 ce 00 00 00    	jb     e37a <__divmodti4+0x18a>
    e2ac:	31 ff                	xor    %edi,%edi
    e2ae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e2b3:	48 63 c7             	movslq %edi,%rax
    e2b6:	be 40 00 00 00       	mov    $0x40,%esi
    e2bb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e2c0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e2c5:	48 29 c6             	sub    %rax,%rsi
    e2c8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e2cd:	48 09 c8             	or     %rcx,%rax
    e2d0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e2d5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e2da:	49 89 c6             	mov    %rax,%r14
    e2dd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e2e1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e2e6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e2eb:	49 09 c1             	or     %rax,%r9
    e2ee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e2f2:	4c 89 c8             	mov    %r9,%rax
    e2f5:	49 f7 f6             	div    %r14
    e2f8:	48 89 d1             	mov    %rdx,%rcx
    e2fb:	49 89 c3             	mov    %rax,%r11
    e2fe:	49 89 c1             	mov    %rax,%r9
    e301:	49 f7 e2             	mul    %r10
    e304:	49 89 c6             	mov    %rax,%r14
    e307:	49 89 d2             	mov    %rdx,%r10
    e30a:	48 39 d1             	cmp    %rdx,%rcx
    e30d:	72 07                	jb     e316 <__divmodti4+0x126>
    e30f:	75 17                	jne    e328 <__divmodti4+0x138>
    e311:	49 39 c7             	cmp    %rax,%r15
    e314:	73 12                	jae    e328 <__divmodti4+0x138>
    e316:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e31a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e31e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e322:	49 89 d2             	mov    %rdx,%r10
    e325:	49 89 c6             	mov    %rax,%r14
    e328:	4c 89 f8             	mov    %r15,%rax
    e32b:	4c 29 f0             	sub    %r14,%rax
    e32e:	4c 19 d1             	sbb    %r10,%rcx
    e331:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e336:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e33b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e340:	48 09 c6             	or     %rax,%rsi
    e343:	48 89 cf             	mov    %rcx,%rdi
    e346:	31 c0                	xor    %eax,%eax
    e348:	4c 89 c9             	mov    %r9,%rcx
    e34b:	e9 10 ff ff ff       	jmp    e260 <__divmodti4+0x70>
    e350:	4c 89 d0             	mov    %r10,%rax
    e353:	4c 89 da             	mov    %r11,%rdx
    e356:	4d 89 c4             	mov    %r8,%r12
    e359:	49 89 f3             	mov    %rsi,%r11
    e35c:	48 f7 d8             	neg    %rax
    e35f:	49 f7 d4             	not    %r12
    e362:	48 83 d2 00          	adc    $0x0,%rdx
    e366:	49 89 c2             	mov    %rax,%r10
    e369:	48 f7 da             	neg    %rdx
    e36c:	48 89 d1             	mov    %rdx,%rcx
    e36f:	0f 84 cc fe ff ff    	je     e241 <__divmodti4+0x51>
    e375:	49 39 d1             	cmp    %rdx,%r9
    e378:	73 46                	jae    e3c0 <__divmodti4+0x1d0>
    e37a:	4c 89 cf             	mov    %r9,%rdi
    e37d:	31 c0                	xor    %eax,%eax
    e37f:	31 c9                	xor    %ecx,%ecx
    e381:	e9 da fe ff ff       	jmp    e260 <__divmodti4+0x70>
    e386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e38d:	00 00 00 
    e390:	4d 85 d2             	test   %r10,%r10
    e393:	75 0d                	jne    e3a2 <__divmodti4+0x1b2>
    e395:	b8 01 00 00 00       	mov    $0x1,%eax
    e39a:	31 d2                	xor    %edx,%edx
    e39c:	49 f7 f2             	div    %r10
    e39f:	49 89 c2             	mov    %rax,%r10
    e3a2:	4c 89 c8             	mov    %r9,%rax
    e3a5:	31 d2                	xor    %edx,%edx
    e3a7:	49 f7 f2             	div    %r10
    e3aa:	49 89 c1             	mov    %rax,%r9
    e3ad:	4c 89 d8             	mov    %r11,%rax
    e3b0:	49 f7 f2             	div    %r10
    e3b3:	49 89 c3             	mov    %rax,%r11
    e3b6:	4c 89 c8             	mov    %r9,%rax
    e3b9:	e9 9a fe ff ff       	jmp    e258 <__divmodti4+0x68>
    e3be:	66 90                	xchg   %ax,%ax
    e3c0:	45 31 f6             	xor    %r14d,%r14d
    e3c3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e3c8:	44 89 f7             	mov    %r14d,%edi
    e3cb:	45 85 f6             	test   %r14d,%r14d
    e3ce:	0f 85 df fe ff ff    	jne    e2b3 <__divmodti4+0xc3>
    e3d4:	4c 39 ca             	cmp    %r9,%rdx
    e3d7:	72 17                	jb     e3f0 <__divmodti4+0x200>
    e3d9:	31 c9                	xor    %ecx,%ecx
    e3db:	48 39 c6             	cmp    %rax,%rsi
    e3de:	73 10                	jae    e3f0 <__divmodti4+0x200>
    e3e0:	4c 89 cf             	mov    %r9,%rdi
    e3e3:	31 c0                	xor    %eax,%eax
    e3e5:	e9 76 fe ff ff       	jmp    e260 <__divmodti4+0x70>
    e3ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e3f0:	4c 89 de             	mov    %r11,%rsi
    e3f3:	b9 01 00 00 00       	mov    $0x1,%ecx
    e3f8:	48 29 c6             	sub    %rax,%rsi
    e3fb:	49 19 d1             	sbb    %rdx,%r9
    e3fe:	eb e0                	jmp    e3e0 <__divmodti4+0x1f0>

000000000000e400 <atexit>:
    e400:	f3 0f 1e fa          	endbr64
    e404:	48 8b 15 fd 4b 00 00 	mov    0x4bfd(%rip),%rdx        # 13008 <__dso_handle>
    e40b:	31 f6                	xor    %esi,%esi
    e40d:	e9 4e 52 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e414 <_fini>:
    e414:	f3 0f 1e fa          	endbr64
    e418:	48 83 ec 08          	sub    $0x8,%rsp
    e41c:	48 83 c4 08          	add    $0x8,%rsp
    e420:	c3                   	ret
