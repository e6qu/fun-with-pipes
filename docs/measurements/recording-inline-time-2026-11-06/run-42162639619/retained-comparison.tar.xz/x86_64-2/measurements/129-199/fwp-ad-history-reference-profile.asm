
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 0f 01 00 	mov    0x10fd1(%rip),%rax        # 13fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 0d 01 00    	push   0x10df2(%rip)        # 13e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 0d 01 00    	jmp    *0x10df4(%rip)        # 13e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 0c 01 00    	jmp    *0x10c66(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e 0a 01 00    	jmp    *0x10a8e(%rip)        # 13e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 0a 01 00    	jmp    *0x10a86(%rip)        # 13e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e 0a 01 00    	jmp    *0x10a7e(%rip)        # 13e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 0a 01 00    	jmp    *0x10a76(%rip)        # 13e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e 0a 01 00    	jmp    *0x10a6e(%rip)        # 13e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 0a 01 00    	jmp    *0x10a66(%rip)        # 13e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e 0a 01 00    	jmp    *0x10a5e(%rip)        # 13e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 0a 01 00    	jmp    *0x10a56(%rip)        # 13e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e 0a 01 00    	jmp    *0x10a4e(%rip)        # 13e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 0a 01 00    	jmp    *0x10a46(%rip)        # 13e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e 0a 01 00    	jmp    *0x10a3e(%rip)        # 13e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 0a 01 00    	jmp    *0x10a36(%rip)        # 13e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e 0a 01 00    	jmp    *0x10a2e(%rip)        # 13e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 0a 01 00    	jmp    *0x10a26(%rip)        # 13e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e 0a 01 00    	jmp    *0x10a1e(%rip)        # 13e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 0a 01 00    	jmp    *0x10a16(%rip)        # 13ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e 0a 01 00    	jmp    *0x10a0e(%rip)        # 13ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 0a 01 00    	jmp    *0x10a06(%rip)        # 13eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe 09 01 00    	jmp    *0x109fe(%rip)        # 13eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 09 01 00    	jmp    *0x109f6(%rip)        # 13ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee 09 01 00    	jmp    *0x109ee(%rip)        # 13ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 09 01 00    	jmp    *0x109e6(%rip)        # 13ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de 09 01 00    	jmp    *0x109de(%rip)        # 13ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 09 01 00    	jmp    *0x109d6(%rip)        # 13ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce 09 01 00    	jmp    *0x109ce(%rip)        # 13ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 09 01 00    	jmp    *0x109c6(%rip)        # 13ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be 09 01 00    	jmp    *0x109be(%rip)        # 13ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 09 01 00    	jmp    *0x109b6(%rip)        # 13f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae 09 01 00    	jmp    *0x109ae(%rip)        # 13f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 09 01 00    	jmp    *0x109a6(%rip)        # 13f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e 09 01 00    	jmp    *0x1099e(%rip)        # 13f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 09 01 00    	jmp    *0x10996(%rip)        # 13f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e 09 01 00    	jmp    *0x1098e(%rip)        # 13f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 09 01 00    	jmp    *0x10986(%rip)        # 13f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e 09 01 00    	jmp    *0x1097e(%rip)        # 13f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 09 01 00    	jmp    *0x10976(%rip)        # 13f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e 09 01 00    	jmp    *0x1096e(%rip)        # 13f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 09 01 00    	jmp    *0x10966(%rip)        # 13f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e 09 01 00    	jmp    *0x1095e(%rip)        # 13f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 09 01 00    	jmp    *0x10956(%rip)        # 13f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e 09 01 00    	jmp    *0x1094e(%rip)        # 13f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 09 01 00    	jmp    *0x10946(%rip)        # 13f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e 09 01 00    	jmp    *0x1093e(%rip)        # 13f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 09 01 00    	jmp    *0x10936(%rip)        # 13f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e 09 01 00    	jmp    *0x1092e(%rip)        # 13f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 09 01 00    	jmp    *0x10926(%rip)        # 13f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e 09 01 00    	jmp    *0x1091e(%rip)        # 13f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 09 01 00    	jmp    *0x10916(%rip)        # 13fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e 09 01 00    	jmp    *0x1090e(%rip)        # 13fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 09 01 00    	jmp    *0x10906(%rip)        # 13fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe 08 01 00    	jmp    *0x108fe(%rip)        # 13fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 08 01 00    	jmp    *0x108f6(%rip)        # 13fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee 08 01 00    	jmp    *0x108ee(%rip)        # 13fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 c9 00 00 	lea    0xc9b8(%rip),%r9        # 100cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 c9 00 00 	lea    0xc9b5(%rip),%r8        # 100d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ed 00 00 	lea    0xed01(%rip),%rax        # 12480 <fwp_fn_table>
    377f:	48 89 05 12 ad 06 00 	mov    %rax,0x6ad12(%rip)        # 6e498 <fwp_fns>
    3786:	48 8b 05 b3 08 01 00 	mov    0x108b3(%rip),%rax        # 14040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c ad 06 00 	mov    %rax,0x6ad0c(%rip)        # 6e4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e cb 00 00 	lea    0xcb4e(%rip),%rdi        # 102ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 08 01 00 	mov    0x10838(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 7f b2 00 00 	lea    0xb27f(%rip),%rdx        # eae0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 07 01 00 	mov    0x107a3(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 07 02 00    	mov    0x207f8(%rip),%eax        # 240a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe c9 00 00 	lea    0xc9fe(%rip),%rdi        # 102f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 d3 00 00 	lea    0xd346(%rip),%rdi        # 10c50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 d3 00 00 	lea    0xd300(%rip),%rdi        # 10c28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 d2 00 00 	lea    0xd2c4(%rip),%rdi        # 10bf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 d2 00 00 	lea    0xd290(%rip),%rdi        # 10bd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b 06 01 00    	call   *0x1065b(%rip)        # 13fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 06 01 00 	lea    0x106a1(%rip),%rdi        # 14028 <__TMC_END__>
    3987:	48 8d 05 9a 06 01 00 	lea    0x1069a(%rip),%rax        # 14028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e 06 01 00 	mov    0x1063e(%rip),%rax        # 13fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 06 01 00 	lea    0x10671(%rip),%rdi        # 14028 <__TMC_END__>
    39b7:	48 8d 35 6a 06 01 00 	lea    0x1066a(%rip),%rsi        # 14028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d 06 01 00 	mov    0x1060d(%rip),%rax        # 13fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d 06 01 00 00 	cmpb   $0x0,0x1066d(%rip)        # 14068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea 05 01 00 	cmpq   $0x0,0x105ea(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 05 01 00 	mov    0x105f6(%rip),%rdi        # 14008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 06 01 00 01 	movb   $0x1,0x10645(%rip)        # 14068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 05 05 00 	lea    0x505b7(%rip),%r8        # 541c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b 05 05 00 	lea    0x5055b(%rip),%rcx        # 54180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f 05 05 00 	lea    0x5052f(%rip),%rcx        # 54160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 05 05 00 	lea    0x50561(%rip),%rcx        # 541a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 05 05 	movdqa 0x50570(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 05 05 	paddq  0x50558(%rip),%xmm0        # 541c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf 04 05 00 	cmp    %rax,0x504bf(%rip)        # 54140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 04 05 	movq   %xmm0,0x504b5(%rip)        # 54140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e 04 02 00 	add    0x2045e(%rip),%rdx        # 24110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c 04 02 00 	add    0x2044c(%rip),%rax        # 24110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 a7 06 00 	mov    0x6a799(%rip),%rdi        # 6e4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 03 01 00 	mov    0x10324(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 03 01 00 	mov    0x10311(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 8a 06 00 	mov    0x68ad1(%rip),%rax        # 6c820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 84 06 00 	mov    0x68419(%rip),%rax        # 6c1e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 84 06 00 	sub    0x68405(%rip),%rax        # 6c1e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d cf 00 00 	lea    0xcf1d(%rip),%rsi        # 10d30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 c1 00 00 	lea    0xc1c5(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 02 01 00 	mov    0x10212(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 9d 06 00 	mov    0x69dab(%rip),%rax        # 6dc30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 9d 06 00 	lea    0x69da4(%rip),%r8        # 6dc30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 9d 06 00 	mov    0x69d85(%rip),%rbx        # 6dc18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 9d 06 00 	mov    0x69d95(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 9d 06 00 	mov    0x69d31(%rip),%rdi        # 6dc20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 9d 06 00 	sub    %rsi,0x69d7a(%rip)        # 6dc70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 9d 06 00 	mov    0x69d0a(%rip),%rax        # 6dc10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 9c 06 00 	add    0x69cc0(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 9c 06 00 	mov    0x69cce(%rip),%rsi        # 6dc20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 9c 06 00 	mov    0x69cdc(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 9c 06 00 	mov    %r12,0x69c8b(%rip)        # 6dc20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 9c 06 00 	mov    %rbp,0x69c79(%rip)        # 6dc18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 9c 06 00 	cmp    %rdi,0x69c5e(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 9c 06 00 	mov    %rdi,0x69c55(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 9c 06 00 	sub    %rdi,0x69c99(%rip)        # 6dc70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 9c 06 00 	mov    0x69c41(%rip),%rax        # 6dc28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 9c 06 00 	lea    0x69c3a(%rip),%r8        # 6dc28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef c6 00 00 	lea    0xc6ef(%rip),%rdx        # 106f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 00 01 00 	mov    0x10042(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d ff 00 00 	mov    0xff9d(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 bf 00 00 	lea    0xbf34(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 86 06 00 	cmp    0x686e9(%rip),%rdi        # 6c820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 86 06 00 	mov    0x686af(%rip),%rax        # 6c800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 86 06 00 	mov    %rdi,0x6868d(%rip)        # 6c800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 86 06 00 	mov    %rdi,0x68669(%rip)        # 6c808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f c0 00 00 	lea    0xc05f(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 be 00 00 	lea    0xbe27(%rip),%rsi        # 1001c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 ff 04 	movdqa 0x4ff96(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e ff 04 	paddq  0x4ff7e(%rip),%xmm0        # 541c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 fe 01 00 	mov    0x1fea4(%rip),%r8        # 24118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be fe 04 00 	mov    0x4febe(%rip),%rcx        # 54140 <ad_raw_total_peak>
    4282:	48 8b 3d d7 fd 00 00 	mov    0xfdd7(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 c4 00 00 	lea    0xc4b5(%rip),%rdx        # 10748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 ff 04 00 	lea    0x4ff01(%rip),%r15        # 541a0 <ad_raw_peak>
    429f:	4c 8d 35 ba fe 04 00 	lea    0x4feba(%rip),%r14        # 54160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 bd 00 00 	lea    0xbd79(%rip),%rax        # 1002b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 f9 00 	movq   0xf956(%rip),%xmm0        # 13c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf fe 04 00 	lea    0x4febf(%rip),%r13        # 54180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f bd 00 00 	lea    0xbd6f(%rip),%rax        # 1003c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 f9 00 	movq   0xf936(%rip),%xmm0        # 13c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 fd 00 00 	mov    0xfd53(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c bd 00 00 	lea    0xbd0c(%rip),%rcx        # 10020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d c4 00 00 	lea    0xc48d(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 fd 00 00 	mov    0xfd24(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 bc 00 00 	lea    0xbcf8(%rip),%rdi        # 10045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 fd 01 00 	cmpq   $0x0,0x1fdc6(%rip)        # 24120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd fd 01 00 	mov    0x1fddd(%rip),%r8        # 24140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de fd 01 00 	mov    0x1fdde(%rip),%r9        # 24148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf fd 01 00 	lea    0x1fdcf(%rip),%rbx        # 24140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 bc 00 00 	lea    0xbcf4(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 fd 01 00 	mov    0x1fdd1(%rip),%rax        # 24150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a bc 00 00 	lea    0xbc9a(%rip),%r12        # 10020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 fc 00 00 	mov    0xfca9(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 c4 00 00 	lea    0xc429(%rip),%rdx        # 107e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 fd 01 00 	cmp    0x1fd53(%rip),%rbp        # 24120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 fc 00 00 	mov    0xfc78(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b bc 00 00 	lea    0xbc5b(%rip),%rdi        # 10059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 fc 00 00 	mov    0xfc43(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 c3 00 00 	lea    0xc384(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 bc 00 00 	lea    0xbc40(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da c2 00 00 	lea    0xc2da(%rip),%rdi        # 10720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 fb 00 00 	mov    0xfbe8(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df bb 00 00 	lea    0xbbdf(%rip),%rdx        # 1005e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 fb 00 00 	mov    0xfbd0(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 fa 00 00 	mov    0xfae1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 ba 00 00 	lea    0xba78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 ba 00 00 	lea    0xbac0(%rip),%rdi        # 1006d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 ba 00 00 	lea    0xba48(%rip),%rdi        # 10087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 c1 00 00 	lea    0xc1d8(%rip),%rdi        # 10828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 c6 00 	movdqa 0xc6e0(%rip),%xmm0        # 10d50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 9d 06 00 	add    0x69dca(%rip),%rax        # 6e498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c c1 00 00 	lea    0xc12c(%rip),%rdi        # 10850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 f9 01 00 	cmp    %rax,0x1f9c5(%rip)        # 24108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 f9 01 00 	add    0x1f9c0(%rip),%rax        # 24110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 c1 00 00 	lea    0xc115(%rip),%rdi        # 10880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 b9 00 00 	lea    0xb920(%rip),%r8        # 100a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 b7 00 00 	lea    0xb775(%rip),%r8        # 100b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 b6 00 00 	lea    0xb612(%rip),%r8        # 100a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea b3 00 00 	lea    0xb3ea(%rip),%rdi        # 100b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a b5 00 00 	lea    0xb59a(%rip),%rsi        # 10288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 8e 06 00 	mov    0x68ea5(%rip),%r9        # 6dc08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 8e 06 00 	mov    0x68efe(%rip),%r8        # 6dc68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f bb 00 00 	lea    0xbb5f(%rip),%rdx        # 108d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 8e 06 00 	mov    0x68ee6(%rip),%rcx        # 6dc60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 8e 06 	movsd  0x68ef4(%rip),%xmm1        # 6dc80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 8e 06 	movsd  0x68ee4(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 f2 00 00 	mov    0xf2c5(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 bf 00 	movdqa 0xbf88(%rip),%xmm0        # 10d60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 89 06 00 	lea    0x6899f(%rip),%rax        # 6d780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 bf 00 	movdqa 0xbfb1(%rip),%xmm2        # 10da0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 89 06 00 	movaps %xmm0,0x68945(%rip)        # 6d740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d bf 00 	movdqa 0xbf6d(%rip),%xmm0        # 10d70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 8d 06 00 01 	movl   $0x1,0x68dd3(%rip)        # 6dbe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 89 06 00 	movaps %xmm0,0x68933(%rip)        # 6d750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b bf 00 	movdqa 0xbf5b(%rip),%xmm0        # 10d80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 89 06 00 	movaps %xmm0,0x68934(%rip)        # 6d760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c bf 00 	movdqa 0xbf5c(%rip),%xmm0        # 10d90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 89 06 00 	movaps %xmm0,0x68935(%rip)        # 6d770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 79 06 00 	lea    0x679b5(%rip),%r8        # 6c840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 8c 06 00 	mov    %rax,0x68cd0(%rip)        # 6dbf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 8c 06 00 	mov    %r12,0x68cae(%rip)        # 6dc00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 8c 06 00 	mov    %rax,0x68c97(%rip)        # 6dbf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 8c 06 00 	mov    %rbx,0x68cb0(%rip)        # 6dc10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 8c 06 00 	mov    %rsi,0x68cd9(%rip)        # 6dc40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 b1 00 00 	lea    0xb174(%rip),%rdi        # 100ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 8c 06 00 	mov    %rax,0x68cb8(%rip)        # 6dc38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 8c 06 00    	mov    %eax,0x68c3c(%rip)        # 6dbe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 2c 78 06 00 	mov    0x6782c(%rip),%r8        # 6c800 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 5c 77 06 00 	mov    %rbx,0x6775c(%rip)        # 6c808 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 48 77 06 00 	mov    %r8,0x67748(%rip)        # 6c800 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d 09 f1 04 00 	lea    0x4f109(%rip),%rcx        # 541e0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d b8 f0 04 00 	lea    0x4f0b8(%rip),%rcx        # 541c0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 af 00 00 	lea    0xafc2(%rip),%rdi        # 100fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 36 f0 04 00 	lea    0x4f036(%rip),%r12        # 541e0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 ae 00 00 	lea    0xaee8(%rip),%rax        # 10112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc ae 00 00 	lea    0xaecc(%rip),%rdx        # 100fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 af 00 00 	lea    0xaf04(%rip),%rdi        # 10148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd ae 00 00 	lea    0xaedd(%rip),%rdi        # 1012d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa ae 00 00 	lea    0xaeaa(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ce ed 01 00 	lea    0x1edce(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 b6 ed 01 00 	movaps %xmm0,0x1edb6(%rip)        # 240c0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 92 ed 01 00 	mov    %rsi,0x1ed92(%rip)        # 240a8 <fwp_tape_cached_bytes>
    5316:	0f 29 05 b3 ed 01 00 	movaps %xmm0,0x1edb3(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 b7 ed 01 00 	movaps %xmm0,0x1edb7(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 b8 ed 01 00 	mov    %rax,0x1edb8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 ae 00 00 	lea    0xae09(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 3d ed 01 00 	mov    0x1ed3d(%rip),%rsi        # 240a8 <fwp_tape_cached_bytes>
    536b:	48 6b 15 8d ed 01 00 	imul   $0x68,0x1ed8d(%rip),%rdx        # 24100 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 46 ee 04 00 	cmp    0x4ee46(%rip),%rdx        # 541c0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 45 ee 04 00 	mov    0x4ee45(%rip),%rax        # 541c8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 3f ee 04 00 	add    0x4ee3f(%rip),%rax        # 541d0 <ad_raw_live+0x10>
    5391:	48 03 05 40 ee 04 00 	add    0x4ee40(%rip),%rax        # 541d8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 7c ed 01 00 	mov    0x1ed7c(%rip),%rcx        # 24120 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 65 ed 01 00 	mov    %rdi,0x1ed65(%rip)        # 24120 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 77 ed 01 00 	lea    0x1ed77(%rip),%rcx        # 24140 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 b5 00 00 	lea    0xb562(%rip),%rdi        # 10958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f ad 00 00 	lea    0xad6f(%rip),%rdi        # 10171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d c7 73 06 00 	mov    0x673c7(%rip),%rbx        # 6c7f8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 2a eb 00 00 	mov    0xeb2a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b b4 00 00 	lea    0xb44b(%rip),%rdi        # 10988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 8d 72 06 00 	mov    0x6728d(%rip),%rax        # 6c800 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 67 72 06 00 	mov    %rdx,0x67267(%rip)        # 6c800 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d b4 71 06 00 	mov    0x671b4(%rip),%rbx        # 6c7f8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 71 71 06 00 	mov    %rbx,0x67171(%rip)        # 6c7f8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 71 71 06 00 	mov    %rdx,0x67171(%rip)        # 6c808 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 86 71 06 00 	lea    0x67186(%rip),%rsi        # 6c840 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 05 8d 06 00 	addq   $0x1,0x68d05(%rip)        # 6e488 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f b2 00 00 	lea    0xb21f(%rip),%rdi        # 109b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 b2 00 00 	lea    0xb230(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 a9 00 00 	lea    0xa9d2(%rip),%rdi        # 1018e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 3e 70 06 00 	lea    0x6703e(%rip),%rcx        # 6c840 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 3f 8c 06 00 	subq   $0x1,0x68c3f(%rip)        # 6e488 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b b1 00 00 	lea    0xb18b(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 20 8c 06 00 	cmpq   $0x0,0x68c20(%rip)        # 6e488 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 75 8b 06 00 	sub    %rax,0x68b75(%rip)        # 6e490 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 53 8b 06 00 	add    %r12,0x68b53(%rip)        # 6e490 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 af 82 06 00 	mov    0x682af(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 ac 6e 06 00 	lea    0x66eac(%rip),%rax        # 6c840 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 03 82 06 00 	add    0x68203(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 d0 81 06 00 	mov    0x681d0(%rip),%rsi        # 6dbf0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 f1 81 06 00 	mov    0x681f1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 e5 81 06 00 	add    0x681e5(%rip),%r8        # 6dc38 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 ad 81 06 	addsd  0x681ad(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 62 6d 06 00 	lea    0x66d62(%rip),%rax        # 6c840 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 6c 81 06 00 	sub    %rdi,0x6816c(%rip)        # 6dc60 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 84 81 06 	movsd  %xmm0,0x68184(%rip)        # 6dc80 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 3e 81 06 00 	sub    %rdx,0x6813e(%rip)        # 6dc60 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 44 81 06 	addsd  0x68144(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 38 81 06 	movsd  %xmm0,0x68138(%rip)        # 6dc80 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 cf 80 06 00 	mov    0x680cf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d c9 80 06 00 	add    %rcx,0x680c9(%rip)        # 6dc70 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 82 80 06 00 	cmp    0x68082(%rip),%r9        # 6dc30 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 79 80 06 00 	mov    %r9,0x68079(%rip)        # 6dc30 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 6a 80 06 00 	cmp    0x6806a(%rip),%r9        # 6dc28 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 5d 80 06 00 	mov    %r9,0x6805d(%rip)        # 6dc28 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 73 7f 06 00 	add    0x67f73(%rip),%rdi        # 6dc38 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 50 6b 06 00 	lea    0x66b50(%rip),%r15        # 6c840 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 c0 7e 06 00 	add    0x67ec0(%rip),%r12        # 6dbf0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 19 7f 06 00 	add    0x67f19(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 18 7f 06 00 	cmp    %rax,0x67f18(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d50:	48 89 05 09 7f 06 00 	mov    %rax,0x67f09(%rip)        # 6dc60 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 08 7f 06 00 	mov    %rax,0x67f08(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 04 7f 06 	addsd  0x67f04(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 fc 7e 06 	movsd  %xmm0,0x67efc(%rip)        # 6dc78 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 43 7e 06 00    	mov    0x67e43(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 7f 6a 06 00 	lea    0x66a7f(%rip),%rdi        # 6c840 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 38 7e 06 00 	add    0x67e38(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 33 7e 06 00 	cmp    %rax,0x67e33(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e35:	48 89 05 24 7e 06 00 	mov    %rax,0x67e24(%rip)        # 6dc60 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 23 7e 06 00 	mov    %rax,0x67e23(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 1f 7e 06 	addsd  0x67e1f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 17 7e 06 	movsd  %xmm0,0x67e17(%rip)        # 6dc78 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ea 85 06 00    	mov    0x685ea(%rip),%ebx        # 6e508 <iteration_active>
    5f1e:	8b 05 c0 7c 06 00    	mov    0x67cc0(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 f4 68 06 00 	lea    0x668f4(%rip),%rax        # 6c840 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 ae 7c 06 00 	add    0x67cae(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 a9 7c 06 00 	cmp    %rax,0x67ca9(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fbf:	48 89 05 9a 7c 06 00 	mov    %rax,0x67c9a(%rip)        # 6dc60 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 99 7c 06 00 	mov    %rax,0x67c99(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 98 7c 06 	addsd  0x67c98(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 90 7c 06 	movsd  %xmm0,0x67c90(%rip)        # 6dc78 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 6d 7c 06 00 	mov    0x67c6d(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 db 84 06 	subsd  0x684db(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 cb 84 06 	comisd 0x684cb(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 c1 84 06 	movsd  %xmm0,0x684c1(%rip)        # 6e4e0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 c4 84 06 00 	addq   $0x1,0x684c4(%rip)        # 6e500 <iteration_requests>
    603b:	01 
    603c:	48 01 3d b5 84 06 00 	add    %rdi,0x684b5(%rip)        # 6e4f8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 5c 83 06 00 	add    0x6835c(%rip),%r9        # 6e498 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_p_ad_push>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	49 89 d5             	mov    %rdx,%r13
    6359:	41 54                	push   %r12
    635b:	49 89 fc             	mov    %rdi,%r12
    635e:	55                   	push   %rbp
    635f:	53                   	push   %rbx
    6360:	48 83 ec 48          	sub    $0x48,%rsp
    6364:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6369:	48 85 ff             	test   %rdi,%rdi
    636c:	79 09                	jns    6377 <fwp_p_ad_push+0x27>
    636e:	48 85 d2             	test   %rdx,%rdx
    6371:	0f 88 b9 02 00 00    	js     6630 <fwp_p_ad_push+0x2e0>
    6377:	48 89 f8             	mov    %rdi,%rax
    637a:	48 89 0c 24          	mov    %rcx,(%rsp)
    637e:	4c 89 c5             	mov    %r8,%rbp
    6381:	48 09 d0             	or     %rdx,%rax
    6384:	0f 89 86 02 00 00    	jns    6610 <fwp_p_ad_push+0x2c0>
    638a:	48 85 ff             	test   %rdi,%rdi
    638d:	0f 89 df 03 00 00    	jns    6772 <fwp_p_ad_push+0x422>
    6393:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6398:	49 89 d6             	mov    %rdx,%r14
    639b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    63a2:	00 
    63a3:	49 89 d4             	mov    %rdx,%r12
    63a6:	49 c1 fe 20          	sar    $0x20,%r14
    63aa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    63b1:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63b7:	48 85 ed             	test   %rbp,%rbp
    63ba:	0f 84 40 03 00 00    	je     6700 <fwp_p_ad_push+0x3b0>
    63c0:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    63c4:	0f 84 be 02 00 00    	je     6688 <fwp_p_ad_push+0x338>
    63ca:	4c 89 f7             	mov    %r14,%rdi
    63cd:	e8 5e e3 ff ff       	call   4730 <fwp_tape_of>
    63d2:	48 89 c3             	mov    %rax,%rbx
    63d5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63da:	0f 85 36 03 00 00    	jne    6716 <fwp_p_ad_push+0x3c6>
    63e0:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    63e4:	48 89 45 08          	mov    %rax,0x8(%rbp)
    63e8:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    63ec:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    63f3:	0f 8f bc 03 00 00    	jg     67b5 <fwp_p_ad_push+0x465>
    63f9:	44 89 e0             	mov    %r12d,%eax
    63fc:	4c 39 f8             	cmp    %r15,%rax
    63ff:	0f 8d a4 03 00 00    	jge    67a9 <fwp_p_ad_push+0x459>
    6405:	4d 85 ed             	test   %r13,%r13
    6408:	78 0c                	js     6416 <fwp_p_ad_push+0xc6>
    640a:	44 89 e8             	mov    %r13d,%eax
    640d:	4c 39 f8             	cmp    %r15,%rax
    6410:	0f 8d 93 03 00 00    	jge    67a9 <fwp_p_ad_push+0x459>
    6416:	4d 89 fe             	mov    %r15,%r14
    6419:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    641d:	49 8d 46 01          	lea    0x1(%r14),%rax
    6421:	4c 89 f1             	mov    %r14,%rcx
    6424:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    642a:	0f 87 85 03 00 00    	ja     67b5 <fwp_p_ad_push+0x465>
    6430:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    6434:	48 39 e8             	cmp    %rbp,%rax
    6437:	0f 8e 23 02 00 00    	jle    6660 <fwp_p_ad_push+0x310>
    643d:	48 85 ed             	test   %rbp,%rbp
    6440:	ba 40 00 00 00       	mov    $0x40,%edx
    6445:	48 0f 44 ea          	cmove  %rdx,%rbp
    6449:	48 39 e8             	cmp    %rbp,%rax
    644c:	7e 22                	jle    6470 <fwp_p_ad_push+0x120>
    644e:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    6455:	0f 8f f5 01 00 00    	jg     6650 <fwp_p_ad_push+0x300>
    645b:	48 01 ed             	add    %rbp,%rbp
    645e:	48 39 e8             	cmp    %rbp,%rax
    6461:	7f eb                	jg     644e <fwp_p_ad_push+0xfe>
    6463:	66 90                	xchg   %ax,%ax
    6465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    646c:	00 00 00 00 
    6470:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6477:	00 
    6478:	4c 8b 43 60          	mov    0x60(%rbx),%r8
    647c:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6480:	ba 01 00 00 00       	mov    $0x1,%edx
    6485:	48 89 c6             	mov    %rax,%rsi
    6488:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    648d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6492:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6497:	e8 f4 ec ff ff       	call   5190 <ad_raw_realloc>
    649c:	48 85 c0             	test   %rax,%rax
    649f:	0f 84 1c 03 00 00    	je     67c1 <fwp_p_ad_push+0x471>
    64a5:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    64a9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    64ae:	48 89 43 20          	mov    %rax,0x20(%rbx)
    64b2:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    64b7:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    64bb:	4d 85 c0             	test   %r8,%r8
    64be:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    64c2:	0f 84 d0 01 00 00    	je     6698 <fwp_p_ad_push+0x348>
    64c8:	49 8b 50 60          	mov    0x60(%r8),%rdx
    64cc:	48 39 ea             	cmp    %rbp,%rdx
    64cf:	0f 8d bb 00 00 00    	jge    6590 <fwp_p_ad_push+0x240>
    64d5:	49 8b 70 40          	mov    0x40(%r8),%rsi
    64d9:	48 89 ef             	mov    %rbp,%rdi
    64dc:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    64e1:	48 c1 e7 04          	shl    $0x4,%rdi
    64e5:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    64ea:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    64ef:	be 02 00 00 00       	mov    $0x2,%esi
    64f4:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    64f9:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    64fe:	e8 0d fa ff ff       	call   5f10 <fwp_heap_alloc>
    6503:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6508:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    650d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6512:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6517:	48 85 f6             	test   %rsi,%rsi
    651a:	74 31                	je     654d <fwp_p_ad_push+0x1fd>
    651c:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    6521:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    6526:	48 c1 e2 04          	shl    $0x4,%rdx
    652a:	48 39 fa             	cmp    %rdi,%rdx
    652d:	48 0f 47 d7          	cmova  %rdi,%rdx
    6531:	48 89 c7             	mov    %rax,%rdi
    6534:	e8 47 d0 ff ff       	call   3580 <memcpy@plt>
    6539:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    653e:	e8 cd f4 ff ff       	call   5a10 <fwp_mem_free>
    6543:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6548:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    654d:	49 8b 78 60          	mov    0x60(%r8),%rdi
    6551:	48 89 ea             	mov    %rbp,%rdx
    6554:	31 f6                	xor    %esi,%esi
    6556:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    655b:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6560:	48 29 fa             	sub    %rdi,%rdx
    6563:	48 c1 e7 04          	shl    $0x4,%rdi
    6567:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    656c:	48 c1 e2 04          	shl    $0x4,%rdx
    6570:	e8 3b cf ff ff       	call   34b0 <memset@plt>
    6575:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    657a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    657f:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6584:	49 89 68 60          	mov    %rbp,0x60(%r8)
    6588:	49 89 40 40          	mov    %rax,0x40(%r8)
    658c:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6590:	4d 85 f6             	test   %r14,%r14
    6593:	0f 85 8f 01 00 00    	jne    6728 <fwp_p_ad_push+0x3d8>
    6599:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    659d:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    65a1:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    65a8:	00 
    65a9:	31 d2                	xor    %edx,%edx
    65ab:	49 01 c6             	add    %rax,%r14
    65ae:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    65b2:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    65b6:	44 89 24 10          	mov    %r12d,(%rax,%rdx,1)
    65ba:	4d 85 ed             	test   %r13,%r13
    65bd:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65c3:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    65ca:	4c 0f 48 e8          	cmovs  %rax,%r13
    65ce:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    65d3:	49 8d 47 01          	lea    0x1(%r15),%rax
    65d7:	f2 0f 11 0c 0e       	movsd  %xmm1,(%rsi,%rcx,1)
    65dc:	45 89 2c 16          	mov    %r13d,(%r14,%rdx,1)
    65e0:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    65e5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65e9:	48 83 c4 48          	add    $0x48,%rsp
    65ed:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65f4:	ff ff ff 
    65f7:	4c 21 e0             	and    %r12,%rax
    65fa:	5b                   	pop    %rbx
    65fb:	5d                   	pop    %rbp
    65fc:	4c 09 f8             	or     %r15,%rax
    65ff:	41 5c                	pop    %r12
    6601:	41 5d                	pop    %r13
    6603:	41 5e                	pop    %r14
    6605:	41 5f                	pop    %r15
    6607:	c3                   	ret
    6608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    660f:	00 
    6610:	48 c1 fa 20          	sar    $0x20,%rdx
    6614:	48 c1 ff 20          	sar    $0x20,%rdi
    6618:	49 89 d6             	mov    %rdx,%r14
    661b:	48 39 d7             	cmp    %rdx,%rdi
    661e:	0f 84 93 fd ff ff    	je     63b7 <fwp_p_ad_push+0x67>
    6624:	48 8d 3d dd a3 00 00 	lea    0xa3dd(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    662b:	e8 20 de ff ff       	call   4450 <fwp_trap>
    6630:	48 83 c4 48          	add    $0x48,%rsp
    6634:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    663b:	5b                   	pop    %rbx
    663c:	5d                   	pop    %rbp
    663d:	41 5c                	pop    %r12
    663f:	41 5d                	pop    %r13
    6641:	41 5e                	pop    %r14
    6643:	41 5f                	pop    %r15
    6645:	c3                   	ret
    6646:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    664d:	00 00 00 
    6650:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    6655:	e9 16 fe ff ff       	jmp    6470 <fwp_p_ad_push+0x120>
    665a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6660:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    6667:	00 
    6668:	48 8b 43 20          	mov    0x20(%rbx),%rax
    666c:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    6670:	48 c1 e1 03          	shl    $0x3,%rcx
    6674:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6678:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    667c:	e9 35 ff ff ff       	jmp    65b6 <fwp_p_ad_push+0x266>
    6681:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6688:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    668c:	e9 57 fd ff ff       	jmp    63e8 <fwp_p_ad_push+0x98>
    6691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6698:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    669c:	48 89 ee             	mov    %rbp,%rsi
    669f:	ba 02 00 00 00       	mov    $0x2,%edx
    66a4:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    66a9:	48 c1 e6 04          	shl    $0x4,%rsi
    66ad:	e8 de ea ff ff       	call   5190 <ad_raw_realloc>
    66b2:	48 89 c6             	mov    %rax,%rsi
    66b5:	48 85 c0             	test   %rax,%rax
    66b8:	0f 84 03 01 00 00    	je     67c1 <fwp_p_ad_push+0x471>
    66be:	48 89 43 30          	mov    %rax,0x30(%rbx)
    66c2:	48 8b 43 18          	mov    0x18(%rbx),%rax
    66c6:	4d 85 f6             	test   %r14,%r14
    66c9:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    66ce:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    66d2:	48 8d 3c 0e          	lea    (%rsi,%rcx,1),%rdi
    66d6:	48 89 43 38          	mov    %rax,0x38(%rbx)
    66da:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    66df:	0f 85 99 00 00 00    	jne    677e <fwp_p_ad_push+0x42e>
    66e5:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    66e9:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66ed:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    66f4:	00 
    66f5:	31 d2                	xor    %edx,%edx
    66f7:	e9 af fe ff ff       	jmp    65ab <fwp_p_ad_push+0x25b>
    66fc:	0f 1f 40 00          	nopl   0x0(%rax)
    6700:	4c 89 f7             	mov    %r14,%rdi
    6703:	e8 28 e0 ff ff       	call   4730 <fwp_tape_of>
    6708:	48 89 c3             	mov    %rax,%rbx
    670b:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6710:	0f 84 d2 fc ff ff    	je     63e8 <fwp_p_ad_push+0x98>
    6716:	48 8d 3d 33 a3 00 00 	lea    0xa333(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    671d:	e8 2e dd ff ff       	call   4450 <fwp_trap>
    6722:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6728:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    672f:	00 
    6730:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    6735:	4a 8d 14 b5 00 00 00 	lea    0x0(,%r14,4),%rdx
    673c:	00 
    673d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6741:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6748:	00 
    6749:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    674d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    6752:	e8 99 ce ff ff       	call   35f0 <memmove@plt>
    6757:	48 8b 43 20          	mov    0x20(%rbx),%rax
    675b:	48 8b 73 30          	mov    0x30(%rbx),%rsi
    675f:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6763:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6768:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    676d:	e9 39 fe ff ff       	jmp    65ab <fwp_p_ad_push+0x25b>
    6772:	48 c1 ff 20          	sar    $0x20,%rdi
    6776:	49 89 fe             	mov    %rdi,%r14
    6779:	e9 39 fc ff ff       	jmp    63b7 <fwp_p_ad_push+0x67>
    677e:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    6785:	00 
    6786:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    678b:	48 89 f2             	mov    %rsi,%rdx
    678e:	48 89 c6             	mov    %rax,%rsi
    6791:	e8 5a ce ff ff       	call   35f0 <memmove@plt>
    6796:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    679b:	48 03 43 30          	add    0x30(%rbx),%rax
    679f:	48 89 43 38          	mov    %rax,0x38(%rbx)
    67a3:	48 8b 43 20          	mov    0x20(%rbx),%rax
    67a7:	eb 8c                	jmp    6735 <fwp_p_ad_push+0x3e5>
    67a9:	48 8d 3d 12 9a 00 00 	lea    0x9a12(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    67b0:	e8 9b dc ff ff       	call   4450 <fwp_trap>
    67b5:	48 8d 3d eb 99 00 00 	lea    0x99eb(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    67bc:	e8 8f dc ff ff       	call   4450 <fwp_trap>
    67c1:	48 89 df             	mov    %rbx,%rdi
    67c4:	e8 c7 d4 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    67c9:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    67cd:	48 85 ff             	test   %rdi,%rdi
    67d0:	74 05                	je     67d7 <fwp_p_ad_push+0x487>
    67d2:	e8 f9 e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67d7:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    67db:	48 85 ff             	test   %rdi,%rdi
    67de:	74 05                	je     67e5 <fwp_p_ad_push+0x495>
    67e0:	e8 eb e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67e5:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    67e9:	48 85 ff             	test   %rdi,%rdi
    67ec:	74 05                	je     67f3 <fwp_p_ad_push+0x4a3>
    67ee:	e8 dd e8 ff ff       	call   50d0 <ad_raw_free.part.0>
    67f3:	31 c9                	xor    %ecx,%ecx
    67f5:	31 c0                	xor    %eax,%eax
    67f7:	31 d2                	xor    %edx,%edx
    67f9:	be 01 00 00 00       	mov    $0x1,%esi
    67fe:	89 53 04             	mov    %edx,0x4(%rbx)
    6801:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6805:	ba 13 00 00 00       	mov    $0x13,%edx
    680a:	48 8d 3d f7 97 00 00 	lea    0x97f7(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    6811:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6815:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    6819:	48 8b 0d 40 d8 00 00 	mov    0xd840(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    6820:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6824:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    6828:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    682c:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6830:	e8 2b ce ff ff       	call   3660 <fwrite@plt>
    6835:	31 ff                	xor    %edi,%edi
    6837:	e8 64 cd ff ff       	call   35a0 <fflush@plt>
    683c:	bf 66 00 00 00       	mov    $0x66,%edi
    6841:	e8 3a ce ff ff       	call   3680 <_Exit@plt>
    6846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    684d:	00 00 00 

0000000000006850 <w107>:
    6850:	41 56                	push   %r14
    6852:	66 0f 28 e0          	movapd %xmm0,%xmm4
    6856:	48 89 fa             	mov    %rdi,%rdx
    6859:	41 55                	push   %r13
    685b:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    685f:	49 89 fd             	mov    %rdi,%r13
    6862:	41 54                	push   %r12
    6864:	55                   	push   %rbp
    6865:	53                   	push   %rbx
    6866:	48 83 ec 40          	sub    $0x40,%rsp
    686a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6870:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6875:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    687c:	00 00 
    687e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6883:	48 89 f5             	mov    %rsi,%rbp
    6886:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    688b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6891:	48 89 f1             	mov    %rsi,%rcx
    6894:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    689a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    68a1:	ff ff 
    68a3:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    68aa:	00 00 
    68ac:	e8 9f fa ff ff       	call   6350 <fwp_p_ad_push>
    68b1:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    68b7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    68bc:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    68c2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    68c9:	00 f0 3f 
    68cc:	48 89 c7             	mov    %rax,%rdi
    68cf:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    68d6:	00 f0 bf 
    68d9:	48 89 ea             	mov    %rbp,%rdx
    68dc:	66 49 0f 7e cc       	movq   %xmm1,%r12
    68e1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68e7:	e8 64 fa ff ff       	call   6350 <fwp_p_ad_push>
    68ec:	f2 0f 10 05 ec a4 00 	movsd  0xa4ec(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    68f3:	00 
    68f4:	4c 89 ef             	mov    %r13,%rdi
    68f7:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    68fd:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6902:	49 89 c6             	mov    %rax,%r14
    6905:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    690c:	00 f0 3f 
    690f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6916:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    691d:	00 f0 bf 
    6920:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6925:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    692b:	e8 20 fa ff ff       	call   6350 <fwp_p_ad_push>
    6930:	4c 89 e1             	mov    %r12,%rcx
    6933:	4c 89 e6             	mov    %r12,%rsi
    6936:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    693b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6941:	4c 89 f2             	mov    %r14,%rdx
    6944:	4c 89 f7             	mov    %r14,%rdi
    6947:	49 89 c5             	mov    %rax,%r13
    694a:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    694e:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6954:	e8 f7 f9 ff ff       	call   6350 <fwp_p_ad_push>
    6959:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    695f:	f2 0f 59 1d 81 a4 00 	mulsd  0xa481(%rip),%xmm3        # 10de8 <msg.4+0xb8>
    6966:	00 
    6967:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    696c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6971:	48 89 c2             	mov    %rax,%rdx
    6974:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    697b:	00 59 40 
    697e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6985:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    698b:	e8 c0 f9 ff ff       	call   6350 <fwp_p_ad_push>
    6990:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6995:	48 89 e9             	mov    %rbp,%rcx
    6998:	4c 89 ea             	mov    %r13,%rdx
    699b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    69a1:	48 89 ee             	mov    %rbp,%rsi
    69a4:	4c 89 ef             	mov    %r13,%rdi
    69a7:	49 89 c4             	mov    %rax,%r12
    69aa:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    69ae:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    69b4:	e8 97 f9 ff ff       	call   6350 <fwp_p_ad_push>
    69b9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    69bf:	45 31 c0             	xor    %r8d,%r8d
    69c2:	4c 89 e2             	mov    %r12,%rdx
    69c5:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    69cb:	48 89 c7             	mov    %rax,%rdi
    69ce:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    69d5:	00 f0 3f 
    69d8:	48 89 ce             	mov    %rcx,%rsi
    69db:	66 48 0f 7e db       	movq   %xmm3,%rbx
    69e0:	e8 6b f9 ff ff       	call   6350 <fwp_p_ad_push>
    69e5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    69ea:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    69f1:	00 00 
    69f3:	75 12                	jne    6a07 <w107+0x1b7>
    69f5:	48 83 c4 40          	add    $0x40,%rsp
    69f9:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    69fe:	5b                   	pop    %rbx
    69ff:	5d                   	pop    %rbp
    6a00:	41 5c                	pop    %r12
    6a02:	41 5d                	pop    %r13
    6a04:	41 5e                	pop    %r14
    6a06:	c3                   	ret
    6a07:	e8 44 ca ff ff       	call   3450 <__stack_chk_fail@plt>
    6a0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006a10 <w164.constprop.0>:
    6a10:	41 54                	push   %r12
    6a12:	55                   	push   %rbp
    6a13:	53                   	push   %rbx
    6a14:	48 83 ec 10          	sub    $0x10,%rsp
    6a18:	4c 8b 27             	mov    (%rdi),%r12
    6a1b:	4d 85 e4             	test   %r12,%r12
    6a1e:	74 58                	je     6a78 <w164.constprop.0+0x68>
    6a20:	48 89 fd             	mov    %rdi,%rbp
    6a23:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a27:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a2e:	31 db                	xor    %ebx,%ebx
    6a30:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6a36:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    6a3b:	45 31 c0             	xor    %r8d,%r8d
    6a3e:	48 83 c3 02          	add    $0x2,%rbx
    6a42:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6a49:	00 f0 3f 
    6a4c:	48 89 ce             	mov    %rcx,%rsi
    6a4f:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    6a55:	e8 f6 f8 ff ff       	call   6350 <fwp_p_ad_push>
    6a5a:	4c 39 e3             	cmp    %r12,%rbx
    6a5d:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6a63:	48 89 c7             	mov    %rax,%rdi
    6a66:	72 c8                	jb     6a30 <w164.constprop.0+0x20>
    6a68:	48 83 c4 10          	add    $0x10,%rsp
    6a6c:	48 89 f8             	mov    %rdi,%rax
    6a6f:	5b                   	pop    %rbx
    6a70:	5d                   	pop    %rbp
    6a71:	41 5c                	pop    %r12
    6a73:	c3                   	ret
    6a74:	0f 1f 40 00          	nopl   0x0(%rax)
    6a78:	48 83 c4 10          	add    $0x10,%rsp
    6a7c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6a83:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a87:	5b                   	pop    %rbx
    6a88:	48 89 f8             	mov    %rdi,%rax
    6a8b:	5d                   	pop    %rbp
    6a8c:	41 5c                	pop    %r12
    6a8e:	c3                   	ret
    6a8f:	90                   	nop

0000000000006a90 <fwp_data.part.0.constprop.0>:
    6a90:	41 56                	push   %r14
    6a92:	8b 05 4c 71 06 00    	mov    0x6714c(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    6a98:	41 89 fe             	mov    %edi,%r14d
    6a9b:	41 55                	push   %r13
    6a9d:	44 8b 2d 64 7a 06 00 	mov    0x67a64(%rip),%r13d        # 6e508 <iteration_active>
    6aa4:	41 54                	push   %r12
    6aa6:	49 89 f4             	mov    %rsi,%r12
    6aa9:	55                   	push   %rbp
    6aaa:	53                   	push   %rbx
    6aab:	45 85 ed             	test   %r13d,%r13d
    6aae:	0f 84 1c 01 00 00    	je     6bd0 <fwp_data.part.0.constprop.0+0x140>
    6ab4:	48 83 05 44 7a 06 00 	addq   $0x1,0x67a44(%rip)        # 6e500 <iteration_requests>
    6abb:	01 
    6abc:	48 83 05 34 7a 06 00 	addq   $0x18,0x67a34(%rip)        # 6e4f8 <iteration_bytes>
    6ac3:	18 
    6ac4:	85 c0                	test   %eax,%eax
    6ac6:	0f 84 8c 01 00 00    	je     6c58 <fwp_data.part.0.constprop.0+0x1c8>
    6acc:	0f b6 05 0f 6d 06 00 	movzbl 0x66d0f(%rip),%eax        # 6d7e2 <fwp_heap+0xfa2>
    6ad3:	48 8d 15 66 5d 06 00 	lea    0x65d66(%rip),%rdx        # 6c840 <fwp_heap>
    6ada:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6ae1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6ae5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6ae9:	48 8b 18             	mov    (%rax),%rbx
    6aec:	48 85 db             	test   %rbx,%rbx
    6aef:	0f 84 fb 00 00 00    	je     6bf0 <fwp_data.part.0.constprop.0+0x160>
    6af5:	48 8b 13             	mov    (%rbx),%rdx
    6af8:	48 f7 d2             	not    %rdx
    6afb:	48 89 10             	mov    %rdx,(%rax)
    6afe:	48 83 fd 18          	cmp    $0x18,%rbp
    6b02:	76 1b                	jbe    6b1f <fwp_data.part.0.constprop.0+0x8f>
    6b04:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6b08:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6b0c:	31 f6                	xor    %esi,%esi
    6b0e:	48 c1 e8 03          	shr    $0x3,%rax
    6b12:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6b19:	00 
    6b1a:	e8 91 c9 ff ff       	call   34b0 <memset@plt>
    6b1f:	48 89 e8             	mov    %rbp,%rax
    6b22:	48 03 05 37 71 06 00 	add    0x67137(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    6b29:	0f 82 3d 01 00 00    	jb     6c6c <fwp_data.part.0.constprop.0+0x1dc>
    6b2f:	48 39 05 32 71 06 00 	cmp    %rax,0x67132(%rip)        # 6dc68 <fwp_heap+0x1428>
    6b36:	48 89 05 23 71 06 00 	mov    %rax,0x67123(%rip)        # 6dc60 <fwp_heap+0x1420>
    6b3d:	73 07                	jae    6b46 <fwp_data.part.0.constprop.0+0xb6>
    6b3f:	48 89 05 22 71 06 00 	mov    %rax,0x67122(%rip)        # 6dc68 <fwp_heap+0x1428>
    6b46:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6b4a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6b4f:	f2 0f 58 05 21 71 06 	addsd  0x67121(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    6b56:	00 
    6b57:	f2 0f 11 05 19 71 06 	movsd  %xmm0,0x67119(%rip)        # 6dc78 <fwp_heap+0x1438>
    6b5e:	00 
    6b5f:	45 85 ed             	test   %r13d,%r13d
    6b62:	74 33                	je     6b97 <fwp_data.part.0.constprop.0+0x107>
    6b64:	48 8b 05 f5 70 06 00 	mov    0x670f5(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    6b6b:	48 85 c0             	test   %rax,%rax
    6b6e:	0f 88 a4 00 00 00    	js     6c18 <fwp_data.part.0.constprop.0+0x188>
    6b74:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6b78:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6b7d:	f2 0f 5c 05 63 79 06 	subsd  0x67963(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    6b84:	00 
    6b85:	66 0f 2f 05 53 79 06 	comisd 0x67953(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6b8c:	00 
    6b8d:	76 08                	jbe    6b97 <fwp_data.part.0.constprop.0+0x107>
    6b8f:	f2 0f 11 05 49 79 06 	movsd  %xmm0,0x67949(%rip)        # 6e4e0 <iteration_peak>
    6b96:	00 
    6b97:	b8 02 00 00 00       	mov    $0x2,%eax
    6b9c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6ba1:	66 0f 6e c8          	movd   %eax,%xmm1
    6ba5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6ba9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6bad:	49 8b 04 24          	mov    (%r12),%rax
    6bb1:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6bb5:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6bba:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6bbe:	48 89 d8             	mov    %rbx,%rax
    6bc1:	5b                   	pop    %rbx
    6bc2:	5d                   	pop    %rbp
    6bc3:	41 5c                	pop    %r12
    6bc5:	41 5d                	pop    %r13
    6bc7:	41 5e                	pop    %r14
    6bc9:	c3                   	ret
    6bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6bd0:	85 c0                	test   %eax,%eax
    6bd2:	0f 85 f4 fe ff ff    	jne    6acc <fwp_data.part.0.constprop.0+0x3c>
    6bd8:	31 f6                	xor    %esi,%esi
    6bda:	bf 18 00 00 00       	mov    $0x18,%edi
    6bdf:	e8 2c f3 ff ff       	call   5f10 <fwp_heap_alloc>
    6be4:	48 89 c3             	mov    %rax,%rbx
    6be7:	eb ae                	jmp    6b97 <fwp_data.part.0.constprop.0+0x107>
    6be9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bf0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6bf4:	48 85 db             	test   %rbx,%rbx
    6bf7:	74 47                	je     6c40 <fwp_data.part.0.constprop.0+0x1b0>
    6bf9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6bfd:	48 29 da             	sub    %rbx,%rdx
    6c00:	48 39 ea             	cmp    %rbp,%rdx
    6c03:	72 3b                	jb     6c40 <fwp_data.part.0.constprop.0+0x1b0>
    6c05:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6c09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6c0d:	e9 ec fe ff ff       	jmp    6afe <fwp_data.part.0.constprop.0+0x6e>
    6c12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c18:	48 89 c2             	mov    %rax,%rdx
    6c1b:	83 e0 01             	and    $0x1,%eax
    6c1e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6c22:	48 d1 ea             	shr    $1,%rdx
    6c25:	48 09 c2             	or     %rax,%rdx
    6c28:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6c2d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6c31:	e9 47 ff ff ff       	jmp    6b7d <fwp_data.part.0.constprop.0+0xed>
    6c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c3d:	00 00 00 
    6c40:	31 f6                	xor    %esi,%esi
    6c42:	bf 18 00 00 00       	mov    $0x18,%edi
    6c47:	e8 c4 f2 ff ff       	call   5f10 <fwp_heap_alloc>
    6c4c:	48 89 c3             	mov    %rax,%rbx
    6c4f:	e9 0b ff ff ff       	jmp    6b5f <fwp_data.part.0.constprop.0+0xcf>
    6c54:	0f 1f 40 00          	nopl   0x0(%rax)
    6c58:	31 f6                	xor    %esi,%esi
    6c5a:	bf 18 00 00 00       	mov    $0x18,%edi
    6c5f:	e8 ac f2 ff ff       	call   5f10 <fwp_heap_alloc>
    6c64:	48 89 c3             	mov    %rax,%rbx
    6c67:	e9 f8 fe ff ff       	jmp    6b64 <fwp_data.part.0.constprop.0+0xd4>
    6c6c:	e8 bf d1 ff ff       	call   3e30 <fwp_heap_oom>
    6c71:	0f 1f 40 00          	nopl   0x0(%rax)
    6c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c7c:	00 00 00 00 

0000000000006c80 <fwp_rc_share>:
    6c80:	48 8b 05 91 6f 06 00 	mov    0x66f91(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6c87:	48 2b 3d 62 6f 06 00 	sub    0x66f62(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6c8e:	48 c1 e0 10          	shl    $0x10,%rax
    6c92:	48 39 c7             	cmp    %rax,%rdi
    6c95:	73 4a                	jae    6ce1 <fwp_rc_share+0x61>
    6c97:	48 89 f8             	mov    %rdi,%rax
    6c9a:	48 c1 e8 10          	shr    $0x10,%rax
    6c9e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ca2:	48 8b 05 8f 6f 06 00 	mov    0x66f8f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6ca9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6cad:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6cb1:	48 85 d2             	test   %rdx,%rdx
    6cb4:	74 2b                	je     6ce1 <fwp_rc_share+0x61>
    6cb6:	0f b6 08             	movzbl (%rax),%ecx
    6cb9:	80 f9 02             	cmp    $0x2,%cl
    6cbc:	74 2a                	je     6ce8 <fwp_rc_share+0x68>
    6cbe:	80 f9 01             	cmp    $0x1,%cl
    6cc1:	75 1e                	jne    6ce1 <fwp_rc_share+0x61>
    6cc3:	8b 48 18             	mov    0x18(%rax),%ecx
    6cc6:	0f b7 ff             	movzwl %di,%edi
    6cc9:	8b 40 1c             	mov    0x1c(%rax),%eax
    6ccc:	48 0f af f9          	imul   %rcx,%rdi
    6cd0:	48 c1 ef 20          	shr    $0x20,%rdi
    6cd4:	48 39 c7             	cmp    %rax,%rdi
    6cd7:	73 08                	jae    6ce1 <fwp_rc_share+0x61>
    6cd9:	48 01 fa             	add    %rdi,%rdx
    6cdc:	80 3a 00             	cmpb   $0x0,(%rdx)
    6cdf:	75 0d                	jne    6cee <fwp_rc_share+0x6e>
    6ce1:	c3                   	ret
    6ce2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ce8:	66 85 ff             	test   %di,%di
    6ceb:	74 ef                	je     6cdc <fwp_rc_share+0x5c>
    6ced:	c3                   	ret
    6cee:	50                   	push   %rax
    6cef:	48 8d 3d 8a 9d 00 00 	lea    0x9d8a(%rip),%rdi        # 10a80 <_IO_stdin_used+0xa80>
    6cf6:	e8 55 d7 ff ff       	call   4450 <fwp_trap>
    6cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006d00 <fwp_rc_fresh>:
    6d00:	48 8b 15 11 6f 06 00 	mov    0x66f11(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6d07:	48 89 f8             	mov    %rdi,%rax
    6d0a:	48 89 fe             	mov    %rdi,%rsi
    6d0d:	48 2b 05 dc 6e 06 00 	sub    0x66edc(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6d14:	48 c1 e2 10          	shl    $0x10,%rdx
    6d18:	48 39 d0             	cmp    %rdx,%rax
    6d1b:	73 4f                	jae    6d6c <fwp_rc_fresh+0x6c>
    6d1d:	48 89 c2             	mov    %rax,%rdx
    6d20:	48 c1 ea 10          	shr    $0x10,%rdx
    6d24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d28:	48 8b 15 09 6f 06 00 	mov    0x66f09(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6d2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d37:	48 85 d2             	test   %rdx,%rdx
    6d3a:	74 30                	je     6d6c <fwp_rc_fresh+0x6c>
    6d3c:	0f b6 39             	movzbl (%rcx),%edi
    6d3f:	40 80 ff 02          	cmp    $0x2,%dil
    6d43:	74 2b                	je     6d70 <fwp_rc_fresh+0x70>
    6d45:	40 80 ff 01          	cmp    $0x1,%dil
    6d49:	75 21                	jne    6d6c <fwp_rc_fresh+0x6c>
    6d4b:	8b 79 18             	mov    0x18(%rcx),%edi
    6d4e:	0f b7 c0             	movzwl %ax,%eax
    6d51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d54:	48 0f af c7          	imul   %rdi,%rax
    6d58:	48 c1 e8 20          	shr    $0x20,%rax
    6d5c:	48 39 c8             	cmp    %rcx,%rax
    6d5f:	73 0b                	jae    6d6c <fwp_rc_fresh+0x6c>
    6d61:	48 01 c2             	add    %rax,%rdx
    6d64:	80 3a ff             	cmpb   $0xff,(%rdx)
    6d67:	74 17                	je     6d80 <fwp_rc_fresh+0x80>
    6d69:	c6 02 01             	movb   $0x1,(%rdx)
    6d6c:	48 89 f0             	mov    %rsi,%rax
    6d6f:	c3                   	ret
    6d70:	66 85 c0             	test   %ax,%ax
    6d73:	74 ef                	je     6d64 <fwp_rc_fresh+0x64>
    6d75:	48 89 f0             	mov    %rsi,%rax
    6d78:	c3                   	ret
    6d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d80:	48 83 ec 18          	sub    $0x18,%rsp
    6d84:	48 89 d7             	mov    %rdx,%rdi
    6d87:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6d8c:	48 89 14 24          	mov    %rdx,(%rsp)
    6d90:	e8 3b ea ff ff       	call   57d0 <fwp_rc_forget_slot>
    6d95:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6d9a:	48 8b 14 24          	mov    (%rsp),%rdx
    6d9e:	48 89 f0             	mov    %rsi,%rax
    6da1:	c6 02 01             	movb   $0x1,(%rdx)
    6da4:	48 83 c4 18          	add    $0x18,%rsp
    6da8:	c3                   	ret
    6da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006db0 <fwp_rc_free_arr>:
    6db0:	48 8b 15 61 6e 06 00 	mov    0x66e61(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6db7:	48 89 f8             	mov    %rdi,%rax
    6dba:	48 2b 05 2f 6e 06 00 	sub    0x66e2f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6dc1:	48 c1 e2 10          	shl    $0x10,%rdx
    6dc5:	48 39 d0             	cmp    %rdx,%rax
    6dc8:	73 5b                	jae    6e25 <fwp_rc_free_arr+0x75>
    6dca:	48 89 c2             	mov    %rax,%rdx
    6dcd:	48 c1 ea 10          	shr    $0x10,%rdx
    6dd1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6dd5:	48 8b 15 5c 6e 06 00 	mov    0x66e5c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6ddc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6de0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6de4:	48 85 c9             	test   %rcx,%rcx
    6de7:	74 3c                	je     6e25 <fwp_rc_free_arr+0x75>
    6de9:	0f b6 32             	movzbl (%rdx),%esi
    6dec:	40 80 fe 02          	cmp    $0x2,%sil
    6df0:	74 2e                	je     6e20 <fwp_rc_free_arr+0x70>
    6df2:	40 80 fe 01          	cmp    $0x1,%sil
    6df6:	75 2d                	jne    6e25 <fwp_rc_free_arr+0x75>
    6df8:	8b 72 18             	mov    0x18(%rdx),%esi
    6dfb:	0f b7 c0             	movzwl %ax,%eax
    6dfe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e01:	48 0f af c6          	imul   %rsi,%rax
    6e05:	48 c1 e8 20          	shr    $0x20,%rax
    6e09:	48 39 d0             	cmp    %rdx,%rax
    6e0c:	73 17                	jae    6e25 <fwp_rc_free_arr+0x75>
    6e0e:	48 01 c1             	add    %rax,%rcx
    6e11:	80 39 01             	cmpb   $0x1,(%rcx)
    6e14:	75 0f                	jne    6e25 <fwp_rc_free_arr+0x75>
    6e16:	e9 f5 eb ff ff       	jmp    5a10 <fwp_mem_free>
    6e1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e20:	66 85 c0             	test   %ax,%ax
    6e23:	74 ec                	je     6e11 <fwp_rc_free_arr+0x61>
    6e25:	c3                   	ret
    6e26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e2d:	00 00 00 

0000000000006e30 <fwp_rc_dup>:
    6e30:	f3 0f 1e fa          	endbr64
    6e34:	48 8b 05 dd 6d 06 00 	mov    0x66ddd(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6e3b:	48 2b 3d ae 6d 06 00 	sub    0x66dae(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6e42:	48 c1 e0 10          	shl    $0x10,%rax
    6e46:	48 39 c7             	cmp    %rax,%rdi
    6e49:	73 60                	jae    6eab <fwp_rc_dup+0x7b>
    6e4b:	48 89 f8             	mov    %rdi,%rax
    6e4e:	48 c1 e8 10          	shr    $0x10,%rax
    6e52:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6e56:	48 8b 05 db 6d 06 00 	mov    0x66ddb(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6e5d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6e61:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6e65:	48 85 c0             	test   %rax,%rax
    6e68:	74 41                	je     6eab <fwp_rc_dup+0x7b>
    6e6a:	0f b6 0a             	movzbl (%rdx),%ecx
    6e6d:	80 f9 02             	cmp    $0x2,%cl
    6e70:	74 3e                	je     6eb0 <fwp_rc_dup+0x80>
    6e72:	80 f9 01             	cmp    $0x1,%cl
    6e75:	75 34                	jne    6eab <fwp_rc_dup+0x7b>
    6e77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6e7a:	0f b7 ff             	movzwl %di,%edi
    6e7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e80:	48 0f af f9          	imul   %rcx,%rdi
    6e84:	48 c1 ef 20          	shr    $0x20,%rdi
    6e88:	48 39 d7             	cmp    %rdx,%rdi
    6e8b:	73 1e                	jae    6eab <fwp_rc_dup+0x7b>
    6e8d:	48 01 f8             	add    %rdi,%rax
    6e90:	0f b6 10             	movzbl (%rax),%edx
    6e93:	84 d2                	test   %dl,%dl
    6e95:	74 14                	je     6eab <fwp_rc_dup+0x7b>
    6e97:	8b 0d 6b 76 06 00    	mov    0x6766b(%rip),%ecx        # 6e508 <iteration_active>
    6e9d:	85 c9                	test   %ecx,%ecx
    6e9f:	75 1f                	jne    6ec0 <fwp_rc_dup+0x90>
    6ea1:	80 fa fd             	cmp    $0xfd,%dl
    6ea4:	77 2a                	ja     6ed0 <fwp_rc_dup+0xa0>
    6ea6:	83 c2 01             	add    $0x1,%edx
    6ea9:	88 10                	mov    %dl,(%rax)
    6eab:	c3                   	ret
    6eac:	0f 1f 40 00          	nopl   0x0(%rax)
    6eb0:	66 85 ff             	test   %di,%di
    6eb3:	74 db                	je     6e90 <fwp_rc_dup+0x60>
    6eb5:	c3                   	ret
    6eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ebd:	00 00 00 
    6ec0:	48 83 05 28 76 06 00 	addq   $0x1,0x67628(%rip)        # 6e4f0 <iteration_retains>
    6ec7:	01 
    6ec8:	eb d7                	jmp    6ea1 <fwp_rc_dup+0x71>
    6eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed0:	48 89 c7             	mov    %rax,%rdi
    6ed3:	e9 d8 e7 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6ed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6edf:	00 

0000000000006ee0 <fwp_owned_entry161>:
    6ee0:	f3 0f 1e fa          	endbr64
    6ee4:	48 83 ec 38          	sub    $0x38,%rsp
    6ee8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6eed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ef4:	00 00 
    6ef6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6efb:	31 c0                	xor    %eax,%eax
    6efd:	48 8b 07             	mov    (%rdi),%rax
    6f00:	48 03 47 10          	add    0x10(%rdi),%rax
    6f04:	0f 80 c2 00 00 00    	jo     6fcc <fwp_owned_entry161+0xec>
    6f0a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6f0f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6f14:	31 ff                	xor    %edi,%edi
    6f16:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6f1a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f1f:	e8 6c fb ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    6f24:	48 8b 15 ed 6c 06 00 	mov    0x66ced(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6f2b:	48 89 c6             	mov    %rax,%rsi
    6f2e:	48 2b 05 bb 6c 06 00 	sub    0x66cbb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6f35:	48 c1 e2 10          	shl    $0x10,%rdx
    6f39:	48 39 d0             	cmp    %rdx,%rax
    6f3c:	73 4f                	jae    6f8d <fwp_owned_entry161+0xad>
    6f3e:	48 89 c2             	mov    %rax,%rdx
    6f41:	48 c1 ea 10          	shr    $0x10,%rdx
    6f45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f49:	48 8b 15 e8 6c 06 00 	mov    0x66ce8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6f50:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f54:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f58:	48 85 d2             	test   %rdx,%rdx
    6f5b:	74 30                	je     6f8d <fwp_owned_entry161+0xad>
    6f5d:	0f b6 39             	movzbl (%rcx),%edi
    6f60:	40 80 ff 02          	cmp    $0x2,%dil
    6f64:	74 42                	je     6fa8 <fwp_owned_entry161+0xc8>
    6f66:	40 80 ff 01          	cmp    $0x1,%dil
    6f6a:	75 21                	jne    6f8d <fwp_owned_entry161+0xad>
    6f6c:	8b 79 18             	mov    0x18(%rcx),%edi
    6f6f:	0f b7 c0             	movzwl %ax,%eax
    6f72:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f75:	48 0f af c7          	imul   %rdi,%rax
    6f79:	48 c1 e8 20          	shr    $0x20,%rax
    6f7d:	48 39 c8             	cmp    %rcx,%rax
    6f80:	73 0b                	jae    6f8d <fwp_owned_entry161+0xad>
    6f82:	48 01 c2             	add    %rax,%rdx
    6f85:	80 3a ff             	cmpb   $0xff,(%rdx)
    6f88:	74 26                	je     6fb0 <fwp_owned_entry161+0xd0>
    6f8a:	c6 02 01             	movb   $0x1,(%rdx)
    6f8d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6f92:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f99:	00 00 
    6f9b:	75 34                	jne    6fd1 <fwp_owned_entry161+0xf1>
    6f9d:	48 89 f0             	mov    %rsi,%rax
    6fa0:	48 83 c4 38          	add    $0x38,%rsp
    6fa4:	c3                   	ret
    6fa5:	0f 1f 00             	nopl   (%rax)
    6fa8:	66 85 c0             	test   %ax,%ax
    6fab:	75 e0                	jne    6f8d <fwp_owned_entry161+0xad>
    6fad:	eb d6                	jmp    6f85 <fwp_owned_entry161+0xa5>
    6faf:	90                   	nop
    6fb0:	48 89 d7             	mov    %rdx,%rdi
    6fb3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6fb8:	48 89 14 24          	mov    %rdx,(%rsp)
    6fbc:	e8 0f e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6fc1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6fc6:	48 8b 14 24          	mov    (%rsp),%rdx
    6fca:	eb be                	jmp    6f8a <fwp_owned_entry161+0xaa>
    6fcc:	e8 2f c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6fd1:	e8 7a c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6fdd:	00 00 00 

0000000000006fe0 <e161>:
    6fe0:	f3 0f 1e fa          	endbr64
    6fe4:	53                   	push   %rbx
    6fe5:	48 83 ec 30          	sub    $0x30,%rsp
    6fe9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6fee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ff5:	00 00 
    6ff7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6ffc:	31 c0                	xor    %eax,%eax
    6ffe:	48 8b 07             	mov    (%rdi),%rax
    7001:	48 03 47 10          	add    0x10(%rdi),%rax
    7005:	0f 80 c9 00 00 00    	jo     70d4 <e161+0xf4>
    700b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7010:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7015:	31 ff                	xor    %edi,%edi
    7017:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    701b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7020:	e8 6b fa ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    7025:	48 8b 15 ec 6b 06 00 	mov    0x66bec(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    702c:	48 89 c3             	mov    %rax,%rbx
    702f:	48 2b 05 ba 6b 06 00 	sub    0x66bba(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7036:	48 c1 e2 10          	shl    $0x10,%rdx
    703a:	48 39 d0             	cmp    %rdx,%rax
    703d:	73 4f                	jae    708e <e161+0xae>
    703f:	48 89 c2             	mov    %rax,%rdx
    7042:	48 c1 ea 10          	shr    $0x10,%rdx
    7046:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    704a:	48 8b 15 e7 6b 06 00 	mov    0x66be7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7051:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7055:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7059:	48 85 d2             	test   %rdx,%rdx
    705c:	74 30                	je     708e <e161+0xae>
    705e:	0f b6 31             	movzbl (%rcx),%esi
    7061:	40 80 fe 02          	cmp    $0x2,%sil
    7065:	74 49                	je     70b0 <e161+0xd0>
    7067:	40 80 fe 01          	cmp    $0x1,%sil
    706b:	75 21                	jne    708e <e161+0xae>
    706d:	8b 71 18             	mov    0x18(%rcx),%esi
    7070:	0f b7 c0             	movzwl %ax,%eax
    7073:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7076:	48 0f af c6          	imul   %rsi,%rax
    707a:	48 c1 e8 20          	shr    $0x20,%rax
    707e:	48 39 c8             	cmp    %rcx,%rax
    7081:	73 0b                	jae    708e <e161+0xae>
    7083:	48 01 c2             	add    %rax,%rdx
    7086:	80 3a ff             	cmpb   $0xff,(%rdx)
    7089:	74 35                	je     70c0 <e161+0xe0>
    708b:	c6 02 01             	movb   $0x1,(%rdx)
    708e:	48 89 df             	mov    %rbx,%rdi
    7091:	e8 ea fb ff ff       	call   6c80 <fwp_rc_share>
    7096:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    709b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    70a2:	00 00 
    70a4:	75 33                	jne    70d9 <e161+0xf9>
    70a6:	48 83 c4 30          	add    $0x30,%rsp
    70aa:	48 89 d8             	mov    %rbx,%rax
    70ad:	5b                   	pop    %rbx
    70ae:	c3                   	ret
    70af:	90                   	nop
    70b0:	66 85 c0             	test   %ax,%ax
    70b3:	75 d9                	jne    708e <e161+0xae>
    70b5:	eb cf                	jmp    7086 <e161+0xa6>
    70b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    70be:	00 00 
    70c0:	48 89 d7             	mov    %rdx,%rdi
    70c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70c8:	e8 03 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    70cd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70d2:	eb b7                	jmp    708b <e161+0xab>
    70d4:	e8 27 c6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    70d9:	e8 72 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    70de:	66 90                	xchg   %ax,%ax

00000000000070e0 <fwp_drop0>:
    70e0:	f3 0f 1e fa          	endbr64
    70e4:	48 8b 15 2d 6b 06 00 	mov    0x66b2d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    70eb:	48 89 f8             	mov    %rdi,%rax
    70ee:	48 2b 05 fb 6a 06 00 	sub    0x66afb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    70f5:	48 c1 e2 10          	shl    $0x10,%rdx
    70f9:	48 39 d0             	cmp    %rdx,%rax
    70fc:	0f 83 be 00 00 00    	jae    71c0 <fwp_drop0+0xe0>
    7102:	48 83 ec 18          	sub    $0x18,%rsp
    7106:	4c 8d 05 33 57 06 00 	lea    0x65733(%rip),%r8        # 6c840 <fwp_heap>
    710d:	48 89 c2             	mov    %rax,%rdx
    7110:	48 c1 ea 10          	shr    $0x10,%rdx
    7114:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7118:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    711f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7123:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7127:	48 85 d2             	test   %rdx,%rdx
    712a:	74 3c                	je     7168 <fwp_drop0+0x88>
    712c:	0f b6 31             	movzbl (%rcx),%esi
    712f:	40 80 fe 02          	cmp    $0x2,%sil
    7133:	74 3b                	je     7170 <fwp_drop0+0x90>
    7135:	40 80 fe 01          	cmp    $0x1,%sil
    7139:	75 2d                	jne    7168 <fwp_drop0+0x88>
    713b:	8b 71 18             	mov    0x18(%rcx),%esi
    713e:	0f b7 c0             	movzwl %ax,%eax
    7141:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7144:	48 0f af c6          	imul   %rsi,%rax
    7148:	48 c1 e8 20          	shr    $0x20,%rax
    714c:	48 39 c8             	cmp    %rcx,%rax
    714f:	73 17                	jae    7168 <fwp_drop0+0x88>
    7151:	48 01 c2             	add    %rax,%rdx
    7154:	0f b6 02             	movzbl (%rdx),%eax
    7157:	84 c0                	test   %al,%al
    7159:	74 0d                	je     7168 <fwp_drop0+0x88>
    715b:	3c 01                	cmp    $0x1,%al
    715d:	74 21                	je     7180 <fwp_drop0+0xa0>
    715f:	3c ff                	cmp    $0xff,%al
    7161:	74 65                	je     71c8 <fwp_drop0+0xe8>
    7163:	83 e8 01             	sub    $0x1,%eax
    7166:	88 02                	mov    %al,(%rdx)
    7168:	48 83 c4 18          	add    $0x18,%rsp
    716c:	c3                   	ret
    716d:	0f 1f 00             	nopl   (%rax)
    7170:	66 85 c0             	test   %ax,%ax
    7173:	74 df                	je     7154 <fwp_drop0+0x74>
    7175:	48 83 c4 18          	add    $0x18,%rsp
    7179:	c3                   	ret
    717a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7180:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7184:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7189:	e8 22 fc ff ff       	call   6db0 <fwp_rc_free_arr>
    718e:	4c 8d 05 ab 56 06 00 	lea    0x656ab(%rip),%r8        # 6c840 <fwp_heap>
    7195:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    719a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    71a1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    71a8:	48 c1 e2 10          	shl    $0x10,%rdx
    71ac:	48 39 d0             	cmp    %rdx,%rax
    71af:	73 b7                	jae    7168 <fwp_drop0+0x88>
    71b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    71b6:	e9 52 ff ff ff       	jmp    710d <fwp_drop0+0x2d>
    71bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    71c0:	c3                   	ret
    71c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71c8:	48 89 d0             	mov    %rdx,%rax
    71cb:	48 c1 e8 11          	shr    $0x11,%rax
    71cf:	48 31 d0             	xor    %rdx,%rax
    71d2:	48 89 c1             	mov    %rax,%rcx
    71d5:	48 c1 e9 09          	shr    $0x9,%rcx
    71d9:	48 31 c8             	xor    %rcx,%rax
    71dc:	0f b6 c8             	movzbl %al,%ecx
    71df:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    71e6:	00 
    71e7:	48 85 c0             	test   %rax,%rax
    71ea:	75 1d                	jne    7209 <fwp_drop0+0x129>
    71ec:	eb 56                	jmp    7244 <fwp_drop0+0x164>
    71ee:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71fc:	00 00 00 00 
    7200:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	74 3b                	je     7244 <fwp_drop0+0x164>
    7209:	48 89 c1             	mov    %rax,%rcx
    720c:	48 39 10             	cmp    %rdx,(%rax)
    720f:	75 ef                	jne    7200 <fwp_drop0+0x120>
    7211:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7215:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7219:	48 89 48 08          	mov    %rcx,0x8(%rax)
    721d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7224:	0f 85 3e ff ff ff    	jne    7168 <fwp_drop0+0x88>
    722a:	48 89 d7             	mov    %rdx,%rdi
    722d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7232:	e8 99 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7237:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    723c:	c6 02 fe             	movb   $0xfe,(%rdx)
    723f:	e9 24 ff ff ff       	jmp    7168 <fwp_drop0+0x88>
    7244:	48 8d 3d 95 97 00 00 	lea    0x9795(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    724b:	e8 00 d2 ff ff       	call   4450 <fwp_trap>

0000000000007250 <fwp_arg_drop12>:
    7250:	f3 0f 1e fa          	endbr64
    7254:	85 f6                	test   %esi,%esi
    7256:	75 04                	jne    725c <fwp_arg_drop12+0xc>
    7258:	85 d2                	test   %edx,%edx
    725a:	75 04                	jne    7260 <fwp_arg_drop12+0x10>
    725c:	c3                   	ret
    725d:	0f 1f 00             	nopl   (%rax)
    7260:	48 8b 3f             	mov    (%rdi),%rdi
    7263:	e9 78 fe ff ff       	jmp    70e0 <fwp_drop0>
    7268:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    726f:	00 

0000000000007270 <fwp_drop1>:
    7270:	f3 0f 1e fa          	endbr64
    7274:	48 8b 15 9d 69 06 00 	mov    0x6699d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    727b:	48 89 f8             	mov    %rdi,%rax
    727e:	48 2b 05 6b 69 06 00 	sub    0x6696b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7285:	48 c1 e2 10          	shl    $0x10,%rdx
    7289:	48 39 d0             	cmp    %rdx,%rax
    728c:	0f 83 be 00 00 00    	jae    7350 <fwp_drop1+0xe0>
    7292:	48 83 ec 18          	sub    $0x18,%rsp
    7296:	4c 8d 05 a3 55 06 00 	lea    0x655a3(%rip),%r8        # 6c840 <fwp_heap>
    729d:	48 89 c2             	mov    %rax,%rdx
    72a0:	48 c1 ea 10          	shr    $0x10,%rdx
    72a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    72a8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    72af:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    72b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    72b7:	48 85 d2             	test   %rdx,%rdx
    72ba:	74 3c                	je     72f8 <fwp_drop1+0x88>
    72bc:	0f b6 31             	movzbl (%rcx),%esi
    72bf:	40 80 fe 02          	cmp    $0x2,%sil
    72c3:	74 3b                	je     7300 <fwp_drop1+0x90>
    72c5:	40 80 fe 01          	cmp    $0x1,%sil
    72c9:	75 2d                	jne    72f8 <fwp_drop1+0x88>
    72cb:	8b 71 18             	mov    0x18(%rcx),%esi
    72ce:	0f b7 c0             	movzwl %ax,%eax
    72d1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    72d4:	48 0f af c6          	imul   %rsi,%rax
    72d8:	48 c1 e8 20          	shr    $0x20,%rax
    72dc:	48 39 c8             	cmp    %rcx,%rax
    72df:	73 17                	jae    72f8 <fwp_drop1+0x88>
    72e1:	48 01 c2             	add    %rax,%rdx
    72e4:	0f b6 02             	movzbl (%rdx),%eax
    72e7:	84 c0                	test   %al,%al
    72e9:	74 0d                	je     72f8 <fwp_drop1+0x88>
    72eb:	3c 01                	cmp    $0x1,%al
    72ed:	74 21                	je     7310 <fwp_drop1+0xa0>
    72ef:	3c ff                	cmp    $0xff,%al
    72f1:	74 65                	je     7358 <fwp_drop1+0xe8>
    72f3:	83 e8 01             	sub    $0x1,%eax
    72f6:	88 02                	mov    %al,(%rdx)
    72f8:	48 83 c4 18          	add    $0x18,%rsp
    72fc:	c3                   	ret
    72fd:	0f 1f 00             	nopl   (%rax)
    7300:	66 85 c0             	test   %ax,%ax
    7303:	74 df                	je     72e4 <fwp_drop1+0x74>
    7305:	48 83 c4 18          	add    $0x18,%rsp
    7309:	c3                   	ret
    730a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7310:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7314:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7319:	e8 92 fa ff ff       	call   6db0 <fwp_rc_free_arr>
    731e:	4c 8d 05 1b 55 06 00 	lea    0x6551b(%rip),%r8        # 6c840 <fwp_heap>
    7325:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    732a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7331:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7338:	48 c1 e2 10          	shl    $0x10,%rdx
    733c:	48 39 d0             	cmp    %rdx,%rax
    733f:	73 b7                	jae    72f8 <fwp_drop1+0x88>
    7341:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7346:	e9 52 ff ff ff       	jmp    729d <fwp_drop1+0x2d>
    734b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7350:	c3                   	ret
    7351:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7358:	48 89 d0             	mov    %rdx,%rax
    735b:	48 c1 e8 11          	shr    $0x11,%rax
    735f:	48 31 d0             	xor    %rdx,%rax
    7362:	48 89 c1             	mov    %rax,%rcx
    7365:	48 c1 e9 09          	shr    $0x9,%rcx
    7369:	48 31 c8             	xor    %rcx,%rax
    736c:	0f b6 c8             	movzbl %al,%ecx
    736f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7376:	00 
    7377:	48 85 c0             	test   %rax,%rax
    737a:	75 0d                	jne    7389 <fwp_drop1+0x119>
    737c:	eb 46                	jmp    73c4 <fwp_drop1+0x154>
    737e:	66 90                	xchg   %ax,%ax
    7380:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7384:	48 85 c0             	test   %rax,%rax
    7387:	74 3b                	je     73c4 <fwp_drop1+0x154>
    7389:	48 89 c1             	mov    %rax,%rcx
    738c:	48 39 10             	cmp    %rdx,(%rax)
    738f:	75 ef                	jne    7380 <fwp_drop1+0x110>
    7391:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7395:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7399:	48 89 48 08          	mov    %rcx,0x8(%rax)
    739d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    73a4:	0f 85 4e ff ff ff    	jne    72f8 <fwp_drop1+0x88>
    73aa:	48 89 d7             	mov    %rdx,%rdi
    73ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    73b2:	e8 19 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    73b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    73bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    73bf:	e9 34 ff ff ff       	jmp    72f8 <fwp_drop1+0x88>
    73c4:	48 8d 3d 15 96 00 00 	lea    0x9615(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    73cb:	e8 80 d0 ff ff       	call   4450 <fwp_trap>

00000000000073d0 <fwp_closure_drop>:
    73d0:	48 8b 15 41 68 06 00 	mov    0x66841(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    73d7:	48 89 f8             	mov    %rdi,%rax
    73da:	48 2b 05 0f 68 06 00 	sub    0x6680f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    73e1:	48 c1 e2 10          	shl    $0x10,%rdx
    73e5:	48 39 d0             	cmp    %rdx,%rax
    73e8:	73 6b                	jae    7455 <fwp_closure_drop+0x85>
    73ea:	48 89 c2             	mov    %rax,%rdx
    73ed:	48 c1 ea 10          	shr    $0x10,%rdx
    73f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73f5:	48 8b 15 3c 68 06 00 	mov    0x6683c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    73fc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7400:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7404:	48 85 d2             	test   %rdx,%rdx
    7407:	74 4c                	je     7455 <fwp_closure_drop+0x85>
    7409:	0f b6 31             	movzbl (%rcx),%esi
    740c:	40 80 fe 02          	cmp    $0x2,%sil
    7410:	74 3e                	je     7450 <fwp_closure_drop+0x80>
    7412:	40 80 fe 01          	cmp    $0x1,%sil
    7416:	75 3d                	jne    7455 <fwp_closure_drop+0x85>
    7418:	8b 71 18             	mov    0x18(%rcx),%esi
    741b:	0f b7 c0             	movzwl %ax,%eax
    741e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7421:	48 0f af c6          	imul   %rsi,%rax
    7425:	48 c1 e8 20          	shr    $0x20,%rax
    7429:	48 39 c8             	cmp    %rcx,%rax
    742c:	73 27                	jae    7455 <fwp_closure_drop+0x85>
    742e:	48 01 c2             	add    %rax,%rdx
    7431:	0f b6 02             	movzbl (%rdx),%eax
    7434:	84 c0                	test   %al,%al
    7436:	74 1d                	je     7455 <fwp_closure_drop+0x85>
    7438:	3c 01                	cmp    $0x1,%al
    743a:	74 24                	je     7460 <fwp_closure_drop+0x90>
    743c:	3c ff                	cmp    $0xff,%al
    743e:	74 48                	je     7488 <fwp_closure_drop+0xb8>
    7440:	83 e8 01             	sub    $0x1,%eax
    7443:	88 02                	mov    %al,(%rdx)
    7445:	c3                   	ret
    7446:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    744d:	00 00 00 
    7450:	66 85 c0             	test   %ax,%ax
    7453:	74 dc                	je     7431 <fwp_closure_drop+0x61>
    7455:	c3                   	ret
    7456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    745d:	00 00 00 
    7460:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7467:	ff ff 
    7469:	48 85 c0             	test   %rax,%rax
    746c:	74 12                	je     7480 <fwp_closure_drop+0xb0>
    746e:	48 89 fe             	mov    %rdi,%rsi
    7471:	48 89 c7             	mov    %rax,%rdi
    7474:	e9 37 d0 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7480:	e9 db d1 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7485:	0f 1f 00             	nopl   (%rax)
    7488:	48 89 d0             	mov    %rdx,%rax
    748b:	48 8d 35 ae 53 06 00 	lea    0x653ae(%rip),%rsi        # 6c840 <fwp_heap>
    7492:	48 83 ec 18          	sub    $0x18,%rsp
    7496:	48 c1 e8 11          	shr    $0x11,%rax
    749a:	48 31 d0             	xor    %rdx,%rax
    749d:	48 89 c1             	mov    %rax,%rcx
    74a0:	48 c1 e9 09          	shr    $0x9,%rcx
    74a4:	48 31 c8             	xor    %rcx,%rax
    74a7:	0f b6 c8             	movzbl %al,%ecx
    74aa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    74b1:	00 
    74b2:	48 85 c0             	test   %rax,%rax
    74b5:	75 12                	jne    74c9 <fwp_closure_drop+0xf9>
    74b7:	eb 49                	jmp    7502 <fwp_closure_drop+0x132>
    74b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 39                	je     7502 <fwp_closure_drop+0x132>
    74c9:	48 89 c1             	mov    %rax,%rcx
    74cc:	48 39 10             	cmp    %rdx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_closure_drop+0xf0>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    74d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    74dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    74e4:	74 05                	je     74eb <fwp_closure_drop+0x11b>
    74e6:	48 83 c4 18          	add    $0x18,%rsp
    74ea:	c3                   	ret
    74eb:	48 89 d7             	mov    %rdx,%rdi
    74ee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    74f3:	e8 d8 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    74f8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    74fd:	c6 02 fe             	movb   $0xfe,(%rdx)
    7500:	eb e4                	jmp    74e6 <fwp_closure_drop+0x116>
    7502:	48 8d 3d d7 94 00 00 	lea    0x94d7(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7509:	e8 42 cf ff ff       	call   4450 <fwp_trap>
    750e:	66 90                	xchg   %ax,%ax

0000000000007510 <fwp_owned_tape_release>:
    7510:	48 85 ff             	test   %rdi,%rdi
    7513:	0f 84 f7 00 00 00    	je     7610 <fwp_owned_tape_release+0x100>
    7519:	41 54                	push   %r12
    751b:	55                   	push   %rbp
    751c:	53                   	push   %rbx
    751d:	48 8b 07             	mov    (%rdi),%rax
    7520:	48 85 c0             	test   %rax,%rax
    7523:	74 08                	je     752d <fwp_owned_tape_release+0x1d>
    7525:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7529:	48 89 50 08          	mov    %rdx,0x8(%rax)
    752d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7531:	48 85 d2             	test   %rdx,%rdx
    7534:	74 03                	je     7539 <fwp_owned_tape_release+0x29>
    7536:	48 89 02             	mov    %rax,(%rdx)
    7539:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    753d:	48 89 fb             	mov    %rdi,%rbx
    7540:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7544:	48 85 c0             	test   %rax,%rax
    7547:	0f 84 89 00 00 00    	je     75d6 <fwp_owned_tape_release+0xc6>
    754d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7551:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7555:	7e 47                	jle    759e <fwp_owned_tape_release+0x8e>
    7557:	31 ed                	xor    %ebp,%ebp
    7559:	eb 0d                	jmp    7568 <fwp_owned_tape_release+0x58>
    755b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7560:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7564:	48 8b 40 68          	mov    0x68(%rax),%rax
    7568:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    756c:	49 89 ec             	mov    %rbp,%r12
    756f:	48 83 c5 01          	add    $0x1,%rbp
    7573:	49 c1 e4 04          	shl    $0x4,%r12
    7577:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    757b:	ff d0                	call   *%rax
    757d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7581:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7586:	48 8b 43 10          	mov    0x10(%rbx),%rax
    758a:	ff 50 68             	call   *0x68(%rax)
    758d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7591:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7595:	48 39 e8             	cmp    %rbp,%rax
    7598:	7f c6                	jg     7560 <fwp_owned_tape_release+0x50>
    759a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    759e:	31 ed                	xor    %ebp,%ebp
    75a0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    75a5:	7e 28                	jle    75cf <fwp_owned_tape_release+0xbf>
    75a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75ae:	00 00 
    75b0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    75b4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    75b8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    75bc:	74 07                	je     75c5 <fwp_owned_tape_release+0xb5>
    75be:	ff 52 68             	call   *0x68(%rdx)
    75c1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    75c5:	48 83 c5 01          	add    $0x1,%rbp
    75c9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    75cd:	7f e1                	jg     75b0 <fwp_owned_tape_release+0xa0>
    75cf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    75d3:	ff 52 68             	call   *0x68(%rdx)
    75d6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    75da:	e8 f1 fd ff ff       	call   73d0 <fwp_closure_drop>
    75df:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    75e3:	e8 e8 fd ff ff       	call   73d0 <fwp_closure_drop>
    75e8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    75ec:	e8 df fd ff ff       	call   73d0 <fwp_closure_drop>
    75f1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    75f5:	e8 16 e4 ff ff       	call   5a10 <fwp_mem_free>
    75fa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    75fe:	e8 0d e4 ff ff       	call   5a10 <fwp_mem_free>
    7603:	48 89 df             	mov    %rbx,%rdi
    7606:	5b                   	pop    %rbx
    7607:	5d                   	pop    %rbp
    7608:	41 5c                	pop    %r12
    760a:	e9 01 e4 ff ff       	jmp    5a10 <fwp_mem_free>
    760f:	90                   	nop
    7610:	c3                   	ret
    7611:	0f 1f 40 00          	nopl   0x0(%rax)
    7615:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    761c:	00 00 00 00 

0000000000007620 <fwp_tape_finish>:
    7620:	f3 0f 1e fa          	endbr64
    7624:	41 55                	push   %r13
    7626:	41 54                	push   %r12
    7628:	55                   	push   %rbp
    7629:	53                   	push   %rbx
    762a:	48 83 ec 48          	sub    $0x48,%rsp
    762e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7635:	00 00 
    7637:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    763c:	48 8d 3d 7d ca 01 00 	lea    0x1ca7d(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    7643:	e8 f8 da ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7648:	48 83 3d b8 ca 01 00 	cmpq   $0x0,0x1cab8(%rip)        # 24108 <fwp_ntapes>
    764f:	00 
    7650:	48 c7 05 4d ca 01 00 	movq   $0x0,0x1ca4d(%rip)        # 240a8 <fwp_tape_cached_bytes>
    7657:	00 00 00 00 
    765b:	7e 79                	jle    76d6 <fwp_tape_finish+0xb6>
    765d:	45 31 e4             	xor    %r12d,%r12d
    7660:	31 ed                	xor    %ebp,%ebp
    7662:	0f 1f 00             	nopl   (%rax)
    7665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    766c:	00 00 00 00 
    7670:	48 8b 1d 99 ca 01 00 	mov    0x1ca99(%rip),%rbx        # 24110 <fwp_tapes>
    7677:	48 83 c5 01          	add    $0x1,%rbp
    767b:	4c 01 e3             	add    %r12,%rbx
    767e:	49 83 c4 68          	add    $0x68,%r12
    7682:	48 89 df             	mov    %rbx,%rdi
    7685:	e8 06 c6 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    768a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    768f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7694:	48 89 e7             	mov    %rsp,%rdi
    7697:	48 8b 43 40          	mov    0x40(%rbx),%rax
    769b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    769f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    76a4:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    76a9:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    76ae:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    76b2:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    76b7:	e8 84 da ff ff       	call   5140 <fwp_tape_buffers_dispose>
    76bc:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    76c0:	e8 4b fe ff ff       	call   7510 <fwp_owned_tape_release>
    76c5:	48 39 2d 3c ca 01 00 	cmp    %rbp,0x1ca3c(%rip)        # 24108 <fwp_ntapes>
    76cc:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    76d3:	00 
    76d4:	7f 9a                	jg     7670 <fwp_tape_finish+0x50>
    76d6:	48 8b 3d 33 ca 01 00 	mov    0x1ca33(%rip),%rdi        # 24110 <fwp_tapes>
    76dd:	48 85 ff             	test   %rdi,%rdi
    76e0:	74 05                	je     76e7 <fwp_tape_finish+0xc7>
    76e2:	e8 e9 d9 ff ff       	call   50d0 <ad_raw_free.part.0>
    76e7:	48 c7 05 1e ca 01 00 	movq   $0x0,0x1ca1e(%rip)        # 24110 <fwp_tapes>
    76ee:	00 00 00 00 
    76f2:	48 c7 05 03 ca 01 00 	movq   $0x0,0x1ca03(%rip)        # 24100 <fwp_tapes_cap>
    76f9:	00 00 00 00 
    76fd:	48 c7 05 00 ca 01 00 	movq   $0x0,0x1ca00(%rip)        # 24108 <fwp_ntapes>
    7704:	00 00 00 00 
    7708:	48 c7 05 e5 c9 01 00 	movq   $0x0,0x1c9e5(%rip)        # 240f8 <fwp_tape_next_slot>
    770f:	00 00 00 00 
    7713:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    771f:	00 00 
    7721:	75 0b                	jne    772e <fwp_tape_finish+0x10e>
    7723:	48 83 c4 48          	add    $0x48,%rsp
    7727:	5b                   	pop    %rbx
    7728:	5d                   	pop    %rbp
    7729:	41 5c                	pop    %r12
    772b:	41 5d                	pop    %r13
    772d:	c3                   	ret
    772e:	e8 1d bd ff ff       	call   3450 <__stack_chk_fail@plt>
    7733:	66 90                	xchg   %ax,%ax
    7735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    773c:	00 00 00 00 

0000000000007740 <fwp_tape_scope_release>:
    7740:	f3 0f 1e fa          	endbr64
    7744:	41 55                	push   %r13
    7746:	41 54                	push   %r12
    7748:	55                   	push   %rbp
    7749:	53                   	push   %rbx
    774a:	48 83 ec 48          	sub    $0x48,%rsp
    774e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7755:	00 00 
    7757:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    775c:	48 63 07             	movslq (%rdi),%rax
    775f:	85 c0                	test   %eax,%eax
    7761:	0f 88 e8 00 00 00    	js     784f <fwp_tape_scope_release+0x10f>
    7767:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    776e:	ec c4 4e 
    7771:	48 89 fb             	mov    %rdi,%rbx
    7774:	48 89 e5             	mov    %rsp,%rbp
    7777:	eb 1f                	jmp    7798 <fwp_tape_scope_release+0x58>
    7779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7780:	e8 bb d9 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7785:	4c 89 ef             	mov    %r13,%rdi
    7788:	e8 83 fd ff ff       	call   7510 <fwp_owned_tape_release>
    778d:	48 63 03             	movslq (%rbx),%rax
    7790:	85 c0                	test   %eax,%eax
    7792:	0f 88 b7 00 00 00    	js     784f <fwp_tape_scope_release+0x10f>
    7798:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    779c:	48 8b 35 6d c9 01 00 	mov    0x1c96d(%rip),%rsi        # 24110 <fwp_tapes>
    77a3:	4c 01 c6             	add    %r8,%rsi
    77a6:	48 89 f7             	mov    %rsi,%rdi
    77a9:	e8 e2 c4 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    77ae:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    77b3:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    77b8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    77bf:	48 8b 46 40          	mov    0x40(%rsi),%rax
    77c3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    77c7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    77ce:	00 
    77cf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    77d4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    77d9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    77dd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    77e2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    77eb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    77f2:	00 
    77f3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    77fa:	00 
    77fb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7802:	00 
    7803:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7807:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    780b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    780f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7813:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7819:	77 18                	ja     7833 <fwp_tape_scope_release+0xf3>
    781b:	49 c1 f8 03          	sar    $0x3,%r8
    781f:	4d 0f af c4          	imul   %r12,%r8
    7823:	4c 3b 05 ce c8 01 00 	cmp    0x1c8ce(%rip),%r8        # 240f8 <fwp_tape_next_slot>
    782a:	7d 07                	jge    7833 <fwp_tape_scope_release+0xf3>
    782c:	4c 89 05 c5 c8 01 00 	mov    %r8,0x1c8c5(%rip)        # 240f8 <fwp_tape_next_slot>
    7833:	48 89 ef             	mov    %rbp,%rdi
    7836:	4d 85 ed             	test   %r13,%r13
    7839:	0f 85 41 ff ff ff    	jne    7780 <fwp_tape_scope_release+0x40>
    783f:	e8 1c da ff ff       	call   5260 <fwp_tape_buffers_release>
    7844:	48 63 03             	movslq (%rbx),%rax
    7847:	85 c0                	test   %eax,%eax
    7849:	0f 89 49 ff ff ff    	jns    7798 <fwp_tape_scope_release+0x58>
    784f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7854:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    785b:	00 00 
    785d:	75 0b                	jne    786a <fwp_tape_scope_release+0x12a>
    785f:	48 83 c4 48          	add    $0x48,%rsp
    7863:	5b                   	pop    %rbx
    7864:	5d                   	pop    %rbp
    7865:	41 5c                	pop    %r12
    7867:	41 5d                	pop    %r13
    7869:	c3                   	ret
    786a:	e8 e1 bb ff ff       	call   3450 <__stack_chk_fail@plt>
    786f:	90                   	nop

0000000000007870 <fwp_task_dispose>:
    7870:	53                   	push   %rbx
    7871:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7875:	0f 84 cb be ff ff    	je     3746 <fwp_task_dispose.cold>
    787b:	48 89 fb             	mov    %rdi,%rbx
    787e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7883:	0f 85 bd be ff ff    	jne    3746 <fwp_task_dispose.cold>
    7889:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    788d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7894:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    789b:	00 
    789c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    78a0:	48 85 ff             	test   %rdi,%rdi
    78a3:	74 07                	je     78ac <fwp_task_dispose+0x3c>
    78a5:	48 85 c0             	test   %rax,%rax
    78a8:	74 02                	je     78ac <fwp_task_dispose+0x3c>
    78aa:	ff d0                	call   *%rax
    78ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    78b3:	e8 58 e1 ff ff       	call   5a10 <fwp_mem_free>
    78b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    78bf:	00 00 00 00 
    78c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    78c7:	74 6f                	je     7938 <fwp_task_dispose+0xc8>
    78c9:	48 8b 15 48 63 06 00 	mov    0x66348(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    78d0:	48 89 d8             	mov    %rbx,%rax
    78d3:	48 2b 05 16 63 06 00 	sub    0x66316(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    78da:	48 c1 e2 10          	shl    $0x10,%rdx
    78de:	48 39 d0             	cmp    %rdx,%rax
    78e1:	73 4c                	jae    792f <fwp_task_dispose+0xbf>
    78e3:	48 89 c2             	mov    %rax,%rdx
    78e6:	48 c1 ea 10          	shr    $0x10,%rdx
    78ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78ee:	48 8b 15 43 63 06 00 	mov    0x66343(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    78f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78fd:	48 85 c9             	test   %rcx,%rcx
    7900:	74 2d                	je     792f <fwp_task_dispose+0xbf>
    7902:	0f b6 32             	movzbl (%rdx),%esi
    7905:	40 80 fe 02          	cmp    $0x2,%sil
    7909:	74 3d                	je     7948 <fwp_task_dispose+0xd8>
    790b:	40 80 fe 01          	cmp    $0x1,%sil
    790f:	75 1e                	jne    792f <fwp_task_dispose+0xbf>
    7911:	8b 72 18             	mov    0x18(%rdx),%esi
    7914:	0f b7 c0             	movzwl %ax,%eax
    7917:	8b 52 1c             	mov    0x1c(%rdx),%edx
    791a:	48 0f af c6          	imul   %rsi,%rax
    791e:	48 c1 e8 20          	shr    $0x20,%rax
    7922:	48 39 d0             	cmp    %rdx,%rax
    7925:	73 08                	jae    792f <fwp_task_dispose+0xbf>
    7927:	48 01 c1             	add    %rax,%rcx
    792a:	80 39 01             	cmpb   $0x1,(%rcx)
    792d:	74 09                	je     7938 <fwp_task_dispose+0xc8>
    792f:	5b                   	pop    %rbx
    7930:	c3                   	ret
    7931:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7938:	48 89 df             	mov    %rbx,%rdi
    793b:	5b                   	pop    %rbx
    793c:	e9 cf e0 ff ff       	jmp    5a10 <fwp_mem_free>
    7941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7948:	66 85 c0             	test   %ax,%ax
    794b:	74 dd                	je     792a <fwp_task_dispose+0xba>
    794d:	5b                   	pop    %rbx
    794e:	c3                   	ret
    794f:	90                   	nop

0000000000007950 <fwp_free_zombie>:
    7950:	48 8b 15 b9 4e 06 00 	mov    0x64eb9(%rip),%rdx        # 6c810 <fwp_zombie>
    7957:	48 85 d2             	test   %rdx,%rdx
    795a:	0f 84 98 00 00 00    	je     79f8 <fwp_free_zombie+0xa8>
    7960:	48 3b 15 b9 4e 06 00 	cmp    0x64eb9(%rip),%rdx        # 6c820 <fwp_cur>
    7967:	0f 84 8b 00 00 00    	je     79f8 <fwp_free_zombie+0xa8>
    796d:	48 83 ec 18          	sub    $0x18,%rsp
    7971:	48 63 05 7c 48 06 00 	movslq 0x6487c(%rip),%rax        # 6c1f4 <fwp_stack_pool_n>
    7978:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    797c:	83 f8 3f             	cmp    $0x3f,%eax
    797f:	7f 7f                	jg     7a00 <fwp_free_zombie+0xb0>
    7981:	8d 48 01             	lea    0x1(%rax),%ecx
    7984:	89 0d 6a 48 06 00    	mov    %ecx,0x6486a(%rip)        # 6c1f4 <fwp_stack_pool_n>
    798a:	48 8d 0d 6f 48 06 00 	lea    0x6486f(%rip),%rcx        # 6c200 <fwp_stack_pool>
    7991:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7995:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    799c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    79a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    79a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    79ab:	48 85 c9             	test   %rcx,%rcx
    79ae:	0f 84 fc 00 00 00    	je     7ab0 <fwp_free_zombie+0x160>
    79b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    79bb:	48 85 c0             	test   %rax,%rax
    79be:	74 07                	je     79c7 <fwp_free_zombie+0x77>
    79c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    79c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    79ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    79ce:	48 c7 05 37 4e 06 00 	movq   $0x0,0x64e37(%rip)        # 6c810 <fwp_zombie>
    79d5:	00 00 00 00 
    79d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    79e0:	85 c0                	test   %eax,%eax
    79e2:	74 34                	je     7a18 <fwp_free_zombie+0xc8>
    79e4:	83 f8 01             	cmp    $0x1,%eax
    79e7:	0f 84 b3 00 00 00    	je     7aa0 <fwp_free_zombie+0x150>
    79ed:	48 83 c4 18          	add    $0x18,%rsp
    79f1:	c3                   	ret
    79f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79f8:	c3                   	ret
    79f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a00:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7a04:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a09:	e8 b2 bb ff ff       	call   35c0 <munmap@plt>
    7a0e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a13:	eb 80                	jmp    7995 <fwp_free_zombie+0x45>
    7a15:	0f 1f 00             	nopl   (%rax)
    7a18:	48 8b 0d f9 61 06 00 	mov    0x661f9(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    7a1f:	48 89 d0             	mov    %rdx,%rax
    7a22:	48 2b 05 c7 61 06 00 	sub    0x661c7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7a29:	48 c1 e1 10          	shl    $0x10,%rcx
    7a2d:	48 39 c8             	cmp    %rcx,%rax
    7a30:	73 bb                	jae    79ed <fwp_free_zombie+0x9d>
    7a32:	48 89 c1             	mov    %rax,%rcx
    7a35:	48 c1 e9 10          	shr    $0x10,%rcx
    7a39:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a3d:	48 8b 0d f4 61 06 00 	mov    0x661f4(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    7a44:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7a48:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7a4c:	48 85 c9             	test   %rcx,%rcx
    7a4f:	74 9c                	je     79ed <fwp_free_zombie+0x9d>
    7a51:	0f b6 3e             	movzbl (%rsi),%edi
    7a54:	40 80 ff 02          	cmp    $0x2,%dil
    7a58:	74 66                	je     7ac0 <fwp_free_zombie+0x170>
    7a5a:	40 80 ff 01          	cmp    $0x1,%dil
    7a5e:	75 8d                	jne    79ed <fwp_free_zombie+0x9d>
    7a60:	8b 7e 18             	mov    0x18(%rsi),%edi
    7a63:	0f b7 c0             	movzwl %ax,%eax
    7a66:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7a69:	48 0f af c7          	imul   %rdi,%rax
    7a6d:	48 c1 e8 20          	shr    $0x20,%rax
    7a71:	48 39 f0             	cmp    %rsi,%rax
    7a74:	0f 83 73 ff ff ff    	jae    79ed <fwp_free_zombie+0x9d>
    7a7a:	48 01 c1             	add    %rax,%rcx
    7a7d:	0f b6 01             	movzbl (%rcx),%eax
    7a80:	84 c0                	test   %al,%al
    7a82:	0f 84 65 ff ff ff    	je     79ed <fwp_free_zombie+0x9d>
    7a88:	3c 01                	cmp    $0x1,%al
    7a8a:	74 14                	je     7aa0 <fwp_free_zombie+0x150>
    7a8c:	3c ff                	cmp    $0xff,%al
    7a8e:	74 3b                	je     7acb <fwp_free_zombie+0x17b>
    7a90:	83 e8 01             	sub    $0x1,%eax
    7a93:	88 01                	mov    %al,(%rcx)
    7a95:	e9 53 ff ff ff       	jmp    79ed <fwp_free_zombie+0x9d>
    7a9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7aa0:	48 89 d7             	mov    %rdx,%rdi
    7aa3:	48 83 c4 18          	add    $0x18,%rsp
    7aa7:	e9 c4 fd ff ff       	jmp    7870 <fwp_task_dispose>
    7aac:	0f 1f 40 00          	nopl   0x0(%rax)
    7ab0:	48 89 05 31 4d 06 00 	mov    %rax,0x64d31(%rip)        # 6c7e8 <fwp_tasks_active>
    7ab7:	e9 ff fe ff ff       	jmp    79bb <fwp_free_zombie+0x6b>
    7abc:	0f 1f 40 00          	nopl   0x0(%rax)
    7ac0:	66 85 c0             	test   %ax,%ax
    7ac3:	0f 85 24 ff ff ff    	jne    79ed <fwp_free_zombie+0x9d>
    7ac9:	eb b2                	jmp    7a7d <fwp_free_zombie+0x12d>
    7acb:	48 89 ca             	mov    %rcx,%rdx
    7ace:	48 8d 35 6b 4d 06 00 	lea    0x64d6b(%rip),%rsi        # 6c840 <fwp_heap>
    7ad5:	48 c1 ea 11          	shr    $0x11,%rdx
    7ad9:	48 31 ca             	xor    %rcx,%rdx
    7adc:	48 89 d0             	mov    %rdx,%rax
    7adf:	48 c1 e8 09          	shr    $0x9,%rax
    7ae3:	48 31 c2             	xor    %rax,%rdx
    7ae6:	0f b6 d2             	movzbl %dl,%edx
    7ae9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7af0:	00 
    7af1:	48 85 c0             	test   %rax,%rax
    7af4:	75 13                	jne    7b09 <fwp_free_zombie+0x1b9>
    7af6:	eb 4c                	jmp    7b44 <fwp_free_zombie+0x1f4>
    7af8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7aff:	00 
    7b00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7b04:	48 85 c0             	test   %rax,%rax
    7b07:	74 3b                	je     7b44 <fwp_free_zombie+0x1f4>
    7b09:	48 89 c2             	mov    %rax,%rdx
    7b0c:	48 39 08             	cmp    %rcx,(%rax)
    7b0f:	75 ef                	jne    7b00 <fwp_free_zombie+0x1b0>
    7b11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b15:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7b19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7b1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7b24:	0f 85 c3 fe ff ff    	jne    79ed <fwp_free_zombie+0x9d>
    7b2a:	48 89 cf             	mov    %rcx,%rdi
    7b2d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b32:	e8 99 dc ff ff       	call   57d0 <fwp_rc_forget_slot>
    7b37:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7b3c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b3f:	e9 a9 fe ff ff       	jmp    79ed <fwp_free_zombie+0x9d>
    7b44:	48 8d 3d 95 8e 00 00 	lea    0x8e95(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7b4b:	e8 00 c9 ff ff       	call   4450 <fwp_trap>

0000000000007b50 <fwp_block>:
    7b50:	48 83 ec 08          	sub    $0x8,%rsp
    7b54:	48 8b 05 ad 4c 06 00 	mov    0x64cad(%rip),%rax        # 6c808 <fwp_ready_head>
    7b5b:	48 85 c0             	test   %rax,%rax
    7b5e:	0f 84 1c 01 00 00    	je     7c80 <fwp_block+0x130>
    7b64:	90                   	nop
    7b65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b6c:	00 00 00 00 
    7b70:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7b77:	48 89 15 8a 4c 06 00 	mov    %rdx,0x64c8a(%rip)        # 6c808 <fwp_ready_head>
    7b7e:	48 85 d2             	test   %rdx,%rdx
    7b81:	0f 84 19 01 00 00    	je     7ca0 <fwp_block+0x150>
    7b87:	48 8b 15 92 4c 06 00 	mov    0x64c92(%rip),%rdx        # 6c820 <fwp_cur>
    7b8e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7b92:	48 39 c2             	cmp    %rax,%rdx
    7b95:	0f 84 d5 00 00 00    	je     7c70 <fwp_block+0x120>
    7b9b:	48 8b 0d 06 69 06 00 	mov    0x66906(%rip),%rcx        # 6e4a8 <fwp_state_owners>
    7ba2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7ba6:	48 89 05 73 4c 06 00 	mov    %rax,0x64c73(%rip)        # 6c820 <fwp_cur>
    7bad:	f3 0f 7e 05 1b 69 06 	movq   0x6691b(%rip),%xmm0        # 6e4d0 <fwp_foreign_callbacks>
    7bb4:	00 
    7bb5:	0f 16 05 04 69 06 00 	movhps 0x66904(%rip),%xmm0        # 6e4c0 <fwp_state>
    7bbc:	f3 0f 7e 0d 04 69 06 	movq   0x66904(%rip),%xmm1        # 6e4c8 <fwp_handlers>
    7bc3:	00 
    7bc4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7bcb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7bd2:	0f 16 0d ff 68 06 00 	movhps 0x668ff(%rip),%xmm1        # 6e4d8 <fwp_cleanups>
    7bd9:	f3 0f 7e 05 d7 68 06 	movq   0x668d7(%rip),%xmm0        # 6e4b8 <fwp_state_len>
    7be0:	00 
    7be1:	0f 16 05 c8 68 06 00 	movhps 0x668c8(%rip),%xmm0        # 6e4b0 <fwp_state_cap>
    7be8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7bef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7bf6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bfa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7c01:	48 89 0d c0 68 06 00 	mov    %rcx,0x668c0(%rip)        # 6e4c8 <fwp_handlers>
    7c08:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7c0f:	48 89 0d c2 68 06 00 	mov    %rcx,0x668c2(%rip)        # 6e4d8 <fwp_cleanups>
    7c16:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7c1d:	48 89 0d ac 68 06 00 	mov    %rcx,0x668ac(%rip)        # 6e4d0 <fwp_foreign_callbacks>
    7c24:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7c2b:	48 89 0d 8e 68 06 00 	mov    %rcx,0x6688e(%rip)        # 6e4c0 <fwp_state>
    7c32:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7c39:	48 89 0d 78 68 06 00 	mov    %rcx,0x66878(%rip)        # 6e4b8 <fwp_state_len>
    7c40:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7c47:	48 89 0d 62 68 06 00 	mov    %rcx,0x66862(%rip)        # 6e4b0 <fwp_state_cap>
    7c4e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7c55:	48 89 0d 4c 68 06 00 	mov    %rcx,0x6684c(%rip)        # 6e4a8 <fwp_state_owners>
    7c5c:	e8 1f b8 ff ff       	call   3480 <swapcontext@plt>
    7c61:	f3 0f 1e fa          	endbr64
    7c65:	e8 e6 fc ff ff       	call   7950 <fwp_free_zombie>
    7c6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c70:	8b 05 7a 45 06 00    	mov    0x6457a(%rip),%eax        # 6c1f0 <fwp_slice>
    7c76:	85 c0                	test   %eax,%eax
    7c78:	74 36                	je     7cb0 <fwp_block+0x160>
    7c7a:	48 83 c4 08          	add    $0x8,%rsp
    7c7e:	c3                   	ret
    7c7f:	90                   	nop
    7c80:	e8 8b d7 ff ff       	call   5410 <fwp_poll_events>
    7c85:	48 8b 05 7c 4b 06 00 	mov    0x64b7c(%rip),%rax        # 6c808 <fwp_ready_head>
    7c8c:	48 85 c0             	test   %rax,%rax
    7c8f:	0f 85 db fe ff ff    	jne    7b70 <fwp_block+0x20>
    7c95:	eb e9                	jmp    7c80 <fwp_block+0x130>
    7c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c9e:	00 00 
    7ca0:	48 c7 05 55 4b 06 00 	movq   $0x0,0x64b55(%rip)        # 6c800 <fwp_ready_tail>
    7ca7:	00 00 00 00 
    7cab:	e9 d7 fe ff ff       	jmp    7b87 <fwp_block+0x37>
    7cb0:	48 8d 3d 28 85 00 00 	lea    0x8528(%rip),%rdi        # 101df <_IO_stdin_used+0x1df>
    7cb7:	e8 d4 b6 ff ff       	call   3390 <getenv@plt>
    7cbc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7cc1:	48 85 c0             	test   %rax,%rax
    7cc4:	74 05                	je     7ccb <fwp_block+0x17b>
    7cc6:	80 38 00             	cmpb   $0x0,(%rax)
    7cc9:	75 0b                	jne    7cd6 <fwp_block+0x186>
    7ccb:	89 15 1f 45 06 00    	mov    %edx,0x6451f(%rip)        # 6c1f0 <fwp_slice>
    7cd1:	48 83 c4 08          	add    $0x8,%rsp
    7cd5:	c3                   	ret
    7cd6:	ba 0a 00 00 00       	mov    $0xa,%edx
    7cdb:	31 f6                	xor    %esi,%esi
    7cdd:	48 89 c7             	mov    %rax,%rdi
    7ce0:	e8 5b b8 ff ff       	call   3540 <strtoll@plt>
    7ce5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ce9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7cf0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7cf5:	0f 46 d0             	cmovbe %eax,%edx
    7cf8:	eb d1                	jmp    7ccb <fwp_block+0x17b>
    7cfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007d00 <fwp_drop4>:
    7d00:	48 8b 15 11 5f 06 00 	mov    0x65f11(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7d07:	48 89 f8             	mov    %rdi,%rax
    7d0a:	48 2b 05 df 5e 06 00 	sub    0x65edf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7d11:	48 c1 e2 10          	shl    $0x10,%rdx
    7d15:	48 39 d0             	cmp    %rdx,%rax
    7d18:	0f 83 52 01 00 00    	jae    7e70 <fwp_drop4+0x170>
    7d1e:	48 83 ec 18          	sub    $0x18,%rsp
    7d22:	4c 8d 05 17 4b 06 00 	lea    0x64b17(%rip),%r8        # 6c840 <fwp_heap>
    7d29:	48 89 c2             	mov    %rax,%rdx
    7d2c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7d33:	48 c1 ea 10          	shr    $0x10,%rdx
    7d37:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d3b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7d3f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7d43:	48 85 d2             	test   %rdx,%rdx
    7d46:	74 46                	je     7d8e <fwp_drop4+0x8e>
    7d48:	44 0f b6 09          	movzbl (%rcx),%r9d
    7d4c:	41 80 f9 02          	cmp    $0x2,%r9b
    7d50:	0f 84 ca 00 00 00    	je     7e20 <fwp_drop4+0x120>
    7d56:	41 80 f9 01          	cmp    $0x1,%r9b
    7d5a:	75 32                	jne    7d8e <fwp_drop4+0x8e>
    7d5c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7d60:	0f b7 c0             	movzwl %ax,%eax
    7d63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d66:	49 0f af c1          	imul   %r9,%rax
    7d6a:	48 c1 e8 20          	shr    $0x20,%rax
    7d6e:	48 39 c8             	cmp    %rcx,%rax
    7d71:	73 1b                	jae    7d8e <fwp_drop4+0x8e>
    7d73:	48 01 c2             	add    %rax,%rdx
    7d76:	0f b6 02             	movzbl (%rdx),%eax
    7d79:	84 c0                	test   %al,%al
    7d7b:	74 11                	je     7d8e <fwp_drop4+0x8e>
    7d7d:	3c 01                	cmp    $0x1,%al
    7d7f:	74 17                	je     7d98 <fwp_drop4+0x98>
    7d81:	3c ff                	cmp    $0xff,%al
    7d83:	0f 84 ef 00 00 00    	je     7e78 <fwp_drop4+0x178>
    7d89:	83 e8 01             	sub    $0x1,%eax
    7d8c:	88 02                	mov    %al,(%rdx)
    7d8e:	48 83 c4 18          	add    $0x18,%rsp
    7d92:	c3                   	ret
    7d93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d98:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7d9c:	0f 88 8e 00 00 00    	js     7e30 <fwp_drop4+0x130>
    7da2:	48 8b 15 6f 5e 06 00 	mov    0x65e6f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7da9:	48 89 f8             	mov    %rdi,%rax
    7dac:	48 2b 05 3d 5e 06 00 	sub    0x65e3d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7db3:	48 c1 e2 10          	shl    $0x10,%rdx
    7db7:	48 39 d0             	cmp    %rdx,%rax
    7dba:	73 d2                	jae    7d8e <fwp_drop4+0x8e>
    7dbc:	48 89 c2             	mov    %rax,%rdx
    7dbf:	48 c1 ea 10          	shr    $0x10,%rdx
    7dc3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7dc7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7dcb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7dcf:	48 85 c9             	test   %rcx,%rcx
    7dd2:	74 ba                	je     7d8e <fwp_drop4+0x8e>
    7dd4:	0f b6 32             	movzbl (%rdx),%esi
    7dd7:	40 80 fe 02          	cmp    $0x2,%sil
    7ddb:	74 33                	je     7e10 <fwp_drop4+0x110>
    7ddd:	40 80 fe 01          	cmp    $0x1,%sil
    7de1:	75 ab                	jne    7d8e <fwp_drop4+0x8e>
    7de3:	8b 72 18             	mov    0x18(%rdx),%esi
    7de6:	0f b7 c0             	movzwl %ax,%eax
    7de9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dec:	48 0f af c6          	imul   %rsi,%rax
    7df0:	48 c1 e8 20          	shr    $0x20,%rax
    7df4:	48 39 d0             	cmp    %rdx,%rax
    7df7:	73 95                	jae    7d8e <fwp_drop4+0x8e>
    7df9:	48 01 c1             	add    %rax,%rcx
    7dfc:	80 39 01             	cmpb   $0x1,(%rcx)
    7dff:	75 8d                	jne    7d8e <fwp_drop4+0x8e>
    7e01:	48 83 c4 18          	add    $0x18,%rsp
    7e05:	e9 06 dc ff ff       	jmp    5a10 <fwp_mem_free>
    7e0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e10:	66 85 c0             	test   %ax,%ax
    7e13:	74 e7                	je     7dfc <fwp_drop4+0xfc>
    7e15:	48 83 c4 18          	add    $0x18,%rsp
    7e19:	c3                   	ret
    7e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e20:	66 85 c0             	test   %ax,%ax
    7e23:	0f 84 4d ff ff ff    	je     7d76 <fwp_drop4+0x76>
    7e29:	48 83 c4 18          	add    $0x18,%rsp
    7e2d:	c3                   	ret
    7e2e:	66 90                	xchg   %ax,%ax
    7e30:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7e34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7e39:	e8 72 ef ff ff       	call   6db0 <fwp_rc_free_arr>
    7e3e:	4c 8d 05 fb 49 06 00 	lea    0x649fb(%rip),%r8        # 6c840 <fwp_heap>
    7e45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7e51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7e58:	48 c1 e2 10          	shl    $0x10,%rdx
    7e5c:	48 39 d0             	cmp    %rdx,%rax
    7e5f:	0f 83 29 ff ff ff    	jae    7d8e <fwp_drop4+0x8e>
    7e65:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7e6a:	e9 ba fe ff ff       	jmp    7d29 <fwp_drop4+0x29>
    7e6f:	90                   	nop
    7e70:	c3                   	ret
    7e71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e78:	48 89 d0             	mov    %rdx,%rax
    7e7b:	48 c1 e8 11          	shr    $0x11,%rax
    7e7f:	48 31 d0             	xor    %rdx,%rax
    7e82:	48 89 c1             	mov    %rax,%rcx
    7e85:	48 c1 e9 09          	shr    $0x9,%rcx
    7e89:	48 31 c8             	xor    %rcx,%rax
    7e8c:	0f b6 c8             	movzbl %al,%ecx
    7e8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7e96:	00 
    7e97:	48 85 c0             	test   %rax,%rax
    7e9a:	75 0d                	jne    7ea9 <fwp_drop4+0x1a9>
    7e9c:	eb 46                	jmp    7ee4 <fwp_drop4+0x1e4>
    7e9e:	66 90                	xchg   %ax,%ax
    7ea0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ea4:	48 85 c0             	test   %rax,%rax
    7ea7:	74 3b                	je     7ee4 <fwp_drop4+0x1e4>
    7ea9:	48 89 c1             	mov    %rax,%rcx
    7eac:	48 39 10             	cmp    %rdx,(%rax)
    7eaf:	75 ef                	jne    7ea0 <fwp_drop4+0x1a0>
    7eb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7eb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7eb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7ebd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ec4:	0f 85 c4 fe ff ff    	jne    7d8e <fwp_drop4+0x8e>
    7eca:	48 89 d7             	mov    %rdx,%rdi
    7ecd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ed2:	e8 f9 d8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7ed7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7edc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7edf:	e9 aa fe ff ff       	jmp    7d8e <fwp_drop4+0x8e>
    7ee4:	48 8d 3d f5 8a 00 00 	lea    0x8af5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7eeb:	e8 60 c5 ff ff       	call   4450 <fwp_trap>

0000000000007ef0 <fwp_caps161>:
    7ef0:	f3 0f 1e fa          	endbr64
    7ef4:	85 f6                	test   %esi,%esi
    7ef6:	74 08                	je     7f00 <fwp_caps161+0x10>
    7ef8:	c3                   	ret
    7ef9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f00:	48 8b 15 11 5d 06 00 	mov    0x65d11(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7f07:	48 89 f8             	mov    %rdi,%rax
    7f0a:	48 2b 05 df 5c 06 00 	sub    0x65cdf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7f11:	48 c1 e2 10          	shl    $0x10,%rdx
    7f15:	48 39 d0             	cmp    %rdx,%rax
    7f18:	73 de                	jae    7ef8 <fwp_caps161+0x8>
    7f1a:	48 89 c2             	mov    %rax,%rdx
    7f1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7f21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f25:	48 8b 15 0c 5d 06 00 	mov    0x65d0c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7f2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7f34:	48 85 c9             	test   %rcx,%rcx
    7f37:	74 bf                	je     7ef8 <fwp_caps161+0x8>
    7f39:	0f b6 32             	movzbl (%rdx),%esi
    7f3c:	40 80 fe 02          	cmp    $0x2,%sil
    7f40:	74 2e                	je     7f70 <fwp_caps161+0x80>
    7f42:	40 80 fe 01          	cmp    $0x1,%sil
    7f46:	75 b0                	jne    7ef8 <fwp_caps161+0x8>
    7f48:	8b 72 18             	mov    0x18(%rdx),%esi
    7f4b:	0f b7 c0             	movzwl %ax,%eax
    7f4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f51:	48 0f af c6          	imul   %rsi,%rax
    7f55:	48 c1 e8 20          	shr    $0x20,%rax
    7f59:	48 39 d0             	cmp    %rdx,%rax
    7f5c:	73 9a                	jae    7ef8 <fwp_caps161+0x8>
    7f5e:	48 01 c1             	add    %rax,%rcx
    7f61:	80 39 01             	cmpb   $0x1,(%rcx)
    7f64:	75 92                	jne    7ef8 <fwp_caps161+0x8>
    7f66:	e9 a5 da ff ff       	jmp    5a10 <fwp_mem_free>
    7f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f70:	66 85 c0             	test   %ax,%ax
    7f73:	74 ec                	je     7f61 <fwp_caps161+0x71>
    7f75:	c3                   	ret
    7f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f7d:	00 00 00 

0000000000007f80 <fwp_drop2>:
    7f80:	48 8b 0d 91 5c 06 00 	mov    0x65c91(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    7f87:	48 89 f8             	mov    %rdi,%rax
    7f8a:	48 2b 05 5f 5c 06 00 	sub    0x65c5f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7f91:	48 c1 e1 10          	shl    $0x10,%rcx
    7f95:	48 39 c8             	cmp    %rcx,%rax
    7f98:	0f 83 42 01 00 00    	jae    80e0 <fwp_drop2+0x160>
    7f9e:	48 83 ec 18          	sub    $0x18,%rsp
    7fa2:	48 89 fa             	mov    %rdi,%rdx
    7fa5:	4c 8d 05 94 48 06 00 	lea    0x64894(%rip),%r8        # 6c840 <fwp_heap>
    7fac:	48 89 c1             	mov    %rax,%rcx
    7faf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7fb6:	48 c1 e9 10          	shr    $0x10,%rcx
    7fba:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fbe:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7fc2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7fc6:	48 85 c9             	test   %rcx,%rcx
    7fc9:	74 40                	je     800b <fwp_drop2+0x8b>
    7fcb:	0f b6 3e             	movzbl (%rsi),%edi
    7fce:	40 80 ff 02          	cmp    $0x2,%dil
    7fd2:	74 3c                	je     8010 <fwp_drop2+0x90>
    7fd4:	40 80 ff 01          	cmp    $0x1,%dil
    7fd8:	75 31                	jne    800b <fwp_drop2+0x8b>
    7fda:	8b 7e 18             	mov    0x18(%rsi),%edi
    7fdd:	0f b7 c0             	movzwl %ax,%eax
    7fe0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7fe3:	48 0f af c7          	imul   %rdi,%rax
    7fe7:	48 c1 e8 20          	shr    $0x20,%rax
    7feb:	48 39 f0             	cmp    %rsi,%rax
    7fee:	73 1b                	jae    800b <fwp_drop2+0x8b>
    7ff0:	48 01 c1             	add    %rax,%rcx
    7ff3:	0f b6 01             	movzbl (%rcx),%eax
    7ff6:	84 c0                	test   %al,%al
    7ff8:	74 11                	je     800b <fwp_drop2+0x8b>
    7ffa:	3c 01                	cmp    $0x1,%al
    7ffc:	74 22                	je     8020 <fwp_drop2+0xa0>
    7ffe:	3c ff                	cmp    $0xff,%al
    8000:	0f 84 0a 01 00 00    	je     8110 <fwp_drop2+0x190>
    8006:	83 e8 01             	sub    $0x1,%eax
    8009:	88 01                	mov    %al,(%rcx)
    800b:	48 83 c4 18          	add    $0x18,%rsp
    800f:	c3                   	ret
    8010:	66 85 c0             	test   %ax,%ax
    8013:	74 de                	je     7ff3 <fwp_drop2+0x73>
    8015:	48 83 c4 18          	add    $0x18,%rsp
    8019:	c3                   	ret
    801a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8020:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    8024:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    802b:	48 89 f8             	mov    %rdi,%rax
    802e:	48 c1 e1 10          	shl    $0x10,%rcx
    8032:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    8039:	48 39 c8             	cmp    %rcx,%rax
    803c:	73 62                	jae    80a0 <fwp_drop2+0x120>
    803e:	48 89 c1             	mov    %rax,%rcx
    8041:	48 c1 e9 10          	shr    $0x10,%rcx
    8045:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8049:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    804d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    8051:	48 85 c9             	test   %rcx,%rcx
    8054:	74 4a                	je     80a0 <fwp_drop2+0x120>
    8056:	44 0f b6 0e          	movzbl (%rsi),%r9d
    805a:	41 80 f9 02          	cmp    $0x2,%r9b
    805e:	0f 84 9c 00 00 00    	je     8100 <fwp_drop2+0x180>
    8064:	41 80 f9 01          	cmp    $0x1,%r9b
    8068:	75 36                	jne    80a0 <fwp_drop2+0x120>
    806a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    806e:	0f b7 c0             	movzwl %ax,%eax
    8071:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8074:	49 0f af c1          	imul   %r9,%rax
    8078:	48 c1 e8 20          	shr    $0x20,%rax
    807c:	48 39 f0             	cmp    %rsi,%rax
    807f:	73 1f                	jae    80a0 <fwp_drop2+0x120>
    8081:	48 01 c1             	add    %rax,%rcx
    8084:	0f b6 01             	movzbl (%rcx),%eax
    8087:	84 c0                	test   %al,%al
    8089:	74 15                	je     80a0 <fwp_drop2+0x120>
    808b:	3c 01                	cmp    $0x1,%al
    808d:	74 59                	je     80e8 <fwp_drop2+0x168>
    808f:	3c ff                	cmp    $0xff,%al
    8091:	0f 84 ef 00 00 00    	je     8186 <fwp_drop2+0x206>
    8097:	83 e8 01             	sub    $0x1,%eax
    809a:	88 01                	mov    %al,(%rcx)
    809c:	0f 1f 40 00          	nopl   0x0(%rax)
    80a0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    80a4:	48 89 d7             	mov    %rdx,%rdi
    80a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    80ab:	e8 00 ed ff ff       	call   6db0 <fwp_rc_free_arr>
    80b0:	4c 8d 05 89 47 06 00 	lea    0x64789(%rip),%r8        # 6c840 <fwp_heap>
    80b7:	48 8b 04 24          	mov    (%rsp),%rax
    80bb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    80c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    80c9:	48 c1 e2 10          	shl    $0x10,%rdx
    80cd:	48 39 d0             	cmp    %rdx,%rax
    80d0:	0f 83 35 ff ff ff    	jae    800b <fwp_drop2+0x8b>
    80d6:	48 8b 14 24          	mov    (%rsp),%rdx
    80da:	e9 cd fe ff ff       	jmp    7fac <fwp_drop2+0x2c>
    80df:	90                   	nop
    80e0:	c3                   	ret
    80e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80e8:	48 89 14 24          	mov    %rdx,(%rsp)
    80ec:	e8 bf ec ff ff       	call   6db0 <fwp_rc_free_arr>
    80f1:	48 8b 14 24          	mov    (%rsp),%rdx
    80f5:	eb a9                	jmp    80a0 <fwp_drop2+0x120>
    80f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80fe:	00 00 
    8100:	66 85 c0             	test   %ax,%ax
    8103:	75 9b                	jne    80a0 <fwp_drop2+0x120>
    8105:	e9 7a ff ff ff       	jmp    8084 <fwp_drop2+0x104>
    810a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8110:	48 89 c8             	mov    %rcx,%rax
    8113:	48 c1 e8 11          	shr    $0x11,%rax
    8117:	48 31 c8             	xor    %rcx,%rax
    811a:	48 89 c2             	mov    %rax,%rdx
    811d:	48 c1 ea 09          	shr    $0x9,%rdx
    8121:	48 31 d0             	xor    %rdx,%rax
    8124:	0f b6 d0             	movzbl %al,%edx
    8127:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    812e:	00 
    812f:	48 85 c0             	test   %rax,%rax
    8132:	75 19                	jne    814d <fwp_drop2+0x1cd>
    8134:	e9 d3 00 00 00       	jmp    820c <fwp_drop2+0x28c>
    8139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8140:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8144:	48 85 c0             	test   %rax,%rax
    8147:	0f 84 bf 00 00 00    	je     820c <fwp_drop2+0x28c>
    814d:	48 89 c2             	mov    %rax,%rdx
    8150:	48 39 08             	cmp    %rcx,(%rax)
    8153:	75 eb                	jne    8140 <fwp_drop2+0x1c0>
    8155:	48 8b 50 08          	mov    0x8(%rax),%rdx
    8159:	48 83 ea 01          	sub    $0x1,%rdx
    815d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8161:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8168:	0f 85 9d fe ff ff    	jne    800b <fwp_drop2+0x8b>
    816e:	48 89 cf             	mov    %rcx,%rdi
    8171:	48 89 0c 24          	mov    %rcx,(%rsp)
    8175:	e8 56 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    817a:	48 8b 0c 24          	mov    (%rsp),%rcx
    817e:	c6 01 fe             	movb   $0xfe,(%rcx)
    8181:	e9 85 fe ff ff       	jmp    800b <fwp_drop2+0x8b>
    8186:	48 89 ce             	mov    %rcx,%rsi
    8189:	48 c1 ee 11          	shr    $0x11,%rsi
    818d:	48 31 ce             	xor    %rcx,%rsi
    8190:	48 89 f0             	mov    %rsi,%rax
    8193:	48 c1 e8 09          	shr    $0x9,%rax
    8197:	48 31 c6             	xor    %rax,%rsi
    819a:	40 0f b6 f6          	movzbl %sil,%esi
    819e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    81a5:	00 
    81a6:	48 85 c0             	test   %rax,%rax
    81a9:	75 1e                	jne    81c9 <fwp_drop2+0x249>
    81ab:	eb 5f                	jmp    820c <fwp_drop2+0x28c>
    81ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    81b4:	00 
    81b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81bc:	00 00 00 00 
    81c0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    81c4:	48 85 c0             	test   %rax,%rax
    81c7:	74 43                	je     820c <fwp_drop2+0x28c>
    81c9:	48 89 c6             	mov    %rax,%rsi
    81cc:	48 39 08             	cmp    %rcx,(%rax)
    81cf:	75 ef                	jne    81c0 <fwp_drop2+0x240>
    81d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    81d5:	48 83 ee 01          	sub    $0x1,%rsi
    81d9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    81dd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    81e4:	0f 85 b6 fe ff ff    	jne    80a0 <fwp_drop2+0x120>
    81ea:	48 89 cf             	mov    %rcx,%rdi
    81ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    81f2:	48 89 0c 24          	mov    %rcx,(%rsp)
    81f6:	e8 d5 d5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    81fb:	48 8b 0c 24          	mov    (%rsp),%rcx
    81ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8204:	c6 01 fe             	movb   $0xfe,(%rcx)
    8207:	e9 94 fe ff ff       	jmp    80a0 <fwp_drop2+0x120>
    820c:	48 8d 3d cd 87 00 00 	lea    0x87cd(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    8213:	e8 38 c2 ff ff       	call   4450 <fwp_trap>
    8218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    821f:	00 

0000000000008220 <fwp_arg_drop23>:
    8220:	f3 0f 1e fa          	endbr64
    8224:	85 f6                	test   %esi,%esi
    8226:	75 04                	jne    822c <fwp_arg_drop23+0xc>
    8228:	85 d2                	test   %edx,%edx
    822a:	75 04                	jne    8230 <fwp_arg_drop23+0x10>
    822c:	c3                   	ret
    822d:	0f 1f 00             	nopl   (%rax)
    8230:	48 8b 3f             	mov    (%rdi),%rdi
    8233:	e9 48 fd ff ff       	jmp    7f80 <fwp_drop2>
    8238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    823f:	00 

0000000000008240 <fwp_args12>:
    8240:	f3 0f 1e fa          	endbr64
    8244:	85 d2                	test   %edx,%edx
    8246:	74 04                	je     824c <fwp_args12+0xc>
    8248:	85 f6                	test   %esi,%esi
    824a:	74 04                	je     8250 <fwp_args12+0x10>
    824c:	c3                   	ret
    824d:	0f 1f 00             	nopl   (%rax)
    8250:	48 8b 15 c1 59 06 00 	mov    0x659c1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8257:	48 8b 07             	mov    (%rdi),%rax
    825a:	48 2b 05 8f 59 06 00 	sub    0x6598f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8261:	48 c1 e2 10          	shl    $0x10,%rdx
    8265:	48 39 d0             	cmp    %rdx,%rax
    8268:	73 e2                	jae    824c <fwp_args12+0xc>
    826a:	48 89 c2             	mov    %rax,%rdx
    826d:	48 c1 ea 10          	shr    $0x10,%rdx
    8271:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8275:	48 8b 15 bc 59 06 00 	mov    0x659bc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    827c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8280:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8284:	48 85 ff             	test   %rdi,%rdi
    8287:	74 c3                	je     824c <fwp_args12+0xc>
    8289:	0f b6 0a             	movzbl (%rdx),%ecx
    828c:	80 f9 02             	cmp    $0x2,%cl
    828f:	74 4f                	je     82e0 <fwp_args12+0xa0>
    8291:	80 f9 01             	cmp    $0x1,%cl
    8294:	75 b6                	jne    824c <fwp_args12+0xc>
    8296:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8299:	0f b7 c0             	movzwl %ax,%eax
    829c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    829f:	48 0f af c1          	imul   %rcx,%rax
    82a3:	48 c1 e8 20          	shr    $0x20,%rax
    82a7:	48 39 d0             	cmp    %rdx,%rax
    82aa:	73 a0                	jae    824c <fwp_args12+0xc>
    82ac:	48 01 c7             	add    %rax,%rdi
    82af:	0f b6 07             	movzbl (%rdi),%eax
    82b2:	84 c0                	test   %al,%al
    82b4:	74 96                	je     824c <fwp_args12+0xc>
    82b6:	8b 15 4c 62 06 00    	mov    0x6624c(%rip),%edx        # 6e508 <iteration_active>
    82bc:	85 d2                	test   %edx,%edx
    82be:	75 10                	jne    82d0 <fwp_args12+0x90>
    82c0:	3c fd                	cmp    $0xfd,%al
    82c2:	77 22                	ja     82e6 <fwp_args12+0xa6>
    82c4:	83 c0 01             	add    $0x1,%eax
    82c7:	88 07                	mov    %al,(%rdi)
    82c9:	c3                   	ret
    82ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82d0:	48 83 05 18 62 06 00 	addq   $0x1,0x66218(%rip)        # 6e4f0 <iteration_retains>
    82d7:	01 
    82d8:	eb e6                	jmp    82c0 <fwp_args12+0x80>
    82da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82e0:	66 85 c0             	test   %ax,%ax
    82e3:	74 ca                	je     82af <fwp_args12+0x6f>
    82e5:	c3                   	ret
    82e6:	e9 c5 d3 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    82eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000082f0 <fwp_args23>:
    82f0:	f3 0f 1e fa          	endbr64
    82f4:	85 d2                	test   %edx,%edx
    82f6:	74 04                	je     82fc <fwp_args23+0xc>
    82f8:	85 f6                	test   %esi,%esi
    82fa:	74 04                	je     8300 <fwp_args23+0x10>
    82fc:	c3                   	ret
    82fd:	0f 1f 00             	nopl   (%rax)
    8300:	48 8b 15 11 59 06 00 	mov    0x65911(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8307:	48 8b 07             	mov    (%rdi),%rax
    830a:	48 2b 05 df 58 06 00 	sub    0x658df(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8311:	48 c1 e2 10          	shl    $0x10,%rdx
    8315:	48 39 d0             	cmp    %rdx,%rax
    8318:	73 e2                	jae    82fc <fwp_args23+0xc>
    831a:	48 89 c2             	mov    %rax,%rdx
    831d:	48 c1 ea 10          	shr    $0x10,%rdx
    8321:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8325:	48 8b 15 0c 59 06 00 	mov    0x6590c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    832c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8330:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8334:	48 85 ff             	test   %rdi,%rdi
    8337:	74 c3                	je     82fc <fwp_args23+0xc>
    8339:	0f b6 0a             	movzbl (%rdx),%ecx
    833c:	80 f9 02             	cmp    $0x2,%cl
    833f:	74 4f                	je     8390 <fwp_args23+0xa0>
    8341:	80 f9 01             	cmp    $0x1,%cl
    8344:	75 b6                	jne    82fc <fwp_args23+0xc>
    8346:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8349:	0f b7 c0             	movzwl %ax,%eax
    834c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    834f:	48 0f af c1          	imul   %rcx,%rax
    8353:	48 c1 e8 20          	shr    $0x20,%rax
    8357:	48 39 d0             	cmp    %rdx,%rax
    835a:	73 a0                	jae    82fc <fwp_args23+0xc>
    835c:	48 01 c7             	add    %rax,%rdi
    835f:	0f b6 07             	movzbl (%rdi),%eax
    8362:	84 c0                	test   %al,%al
    8364:	74 96                	je     82fc <fwp_args23+0xc>
    8366:	8b 15 9c 61 06 00    	mov    0x6619c(%rip),%edx        # 6e508 <iteration_active>
    836c:	85 d2                	test   %edx,%edx
    836e:	75 10                	jne    8380 <fwp_args23+0x90>
    8370:	3c fd                	cmp    $0xfd,%al
    8372:	77 22                	ja     8396 <fwp_args23+0xa6>
    8374:	83 c0 01             	add    $0x1,%eax
    8377:	88 07                	mov    %al,(%rdi)
    8379:	c3                   	ret
    837a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8380:	48 83 05 68 61 06 00 	addq   $0x1,0x66168(%rip)        # 6e4f0 <iteration_retains>
    8387:	01 
    8388:	eb e6                	jmp    8370 <fwp_args23+0x80>
    838a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8390:	66 85 c0             	test   %ax,%ax
    8393:	74 ca                	je     835f <fwp_args23+0x6f>
    8395:	c3                   	ret
    8396:	e9 15 d3 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    839b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000083a0 <fwp_caps12>:
    83a0:	f3 0f 1e fa          	endbr64
    83a4:	48 83 ec 18          	sub    $0x18,%rsp
    83a8:	48 89 f8             	mov    %rdi,%rax
    83ab:	8b 7f 04             	mov    0x4(%rdi),%edi
    83ae:	85 ff                	test   %edi,%edi
    83b0:	0f 84 9a 00 00 00    	je     8450 <fwp_caps12+0xb0>
    83b6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    83ba:	85 f6                	test   %esi,%esi
    83bc:	0f 85 9e 00 00 00    	jne    8460 <fwp_caps12+0xc0>
    83c2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    83c7:	e8 14 ed ff ff       	call   70e0 <fwp_drop0>
    83cc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    83d1:	48 8b 0d 40 58 06 00 	mov    0x65840(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    83d8:	48 89 c2             	mov    %rax,%rdx
    83db:	48 2b 15 0e 58 06 00 	sub    0x6580e(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    83e2:	48 c1 e1 10          	shl    $0x10,%rcx
    83e6:	48 39 ca             	cmp    %rcx,%rdx
    83e9:	73 6d                	jae    8458 <fwp_caps12+0xb8>
    83eb:	48 89 d1             	mov    %rdx,%rcx
    83ee:	48 c1 e9 10          	shr    $0x10,%rcx
    83f2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    83f6:	48 8b 0d 3b 58 06 00 	mov    0x6583b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    83fd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8401:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8405:	48 85 f6             	test   %rsi,%rsi
    8408:	74 4e                	je     8458 <fwp_caps12+0xb8>
    840a:	0f b6 39             	movzbl (%rcx),%edi
    840d:	40 80 ff 02          	cmp    $0x2,%dil
    8411:	0f 84 c9 00 00 00    	je     84e0 <fwp_caps12+0x140>
    8417:	40 80 ff 01          	cmp    $0x1,%dil
    841b:	75 3b                	jne    8458 <fwp_caps12+0xb8>
    841d:	8b 79 18             	mov    0x18(%rcx),%edi
    8420:	0f b7 d2             	movzwl %dx,%edx
    8423:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8426:	48 0f af d7          	imul   %rdi,%rdx
    842a:	48 c1 ea 20          	shr    $0x20,%rdx
    842e:	48 39 ca             	cmp    %rcx,%rdx
    8431:	73 25                	jae    8458 <fwp_caps12+0xb8>
    8433:	48 01 d6             	add    %rdx,%rsi
    8436:	80 3e 01             	cmpb   $0x1,(%rsi)
    8439:	75 1d                	jne    8458 <fwp_caps12+0xb8>
    843b:	48 89 c7             	mov    %rax,%rdi
    843e:	48 83 c4 18          	add    $0x18,%rsp
    8442:	e9 c9 d5 ff ff       	jmp    5a10 <fwp_mem_free>
    8447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    844e:	00 00 
    8450:	85 f6                	test   %esi,%esi
    8452:	0f 84 79 ff ff ff    	je     83d1 <fwp_caps12+0x31>
    8458:	48 83 c4 18          	add    $0x18,%rsp
    845c:	c3                   	ret
    845d:	0f 1f 00             	nopl   (%rax)
    8460:	48 8b 05 b1 57 06 00 	mov    0x657b1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8467:	48 2b 3d 82 57 06 00 	sub    0x65782(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    846e:	48 c1 e0 10          	shl    $0x10,%rax
    8472:	48 39 c7             	cmp    %rax,%rdi
    8475:	73 e1                	jae    8458 <fwp_caps12+0xb8>
    8477:	48 89 f8             	mov    %rdi,%rax
    847a:	48 c1 e8 10          	shr    $0x10,%rax
    847e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8482:	48 8b 05 af 57 06 00 	mov    0x657af(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8489:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    848d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8491:	48 85 c0             	test   %rax,%rax
    8494:	74 c2                	je     8458 <fwp_caps12+0xb8>
    8496:	0f b6 0a             	movzbl (%rdx),%ecx
    8499:	80 f9 02             	cmp    $0x2,%cl
    849c:	74 52                	je     84f0 <fwp_caps12+0x150>
    849e:	80 f9 01             	cmp    $0x1,%cl
    84a1:	75 b5                	jne    8458 <fwp_caps12+0xb8>
    84a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84a6:	0f b7 ff             	movzwl %di,%edi
    84a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84ac:	48 0f af f9          	imul   %rcx,%rdi
    84b0:	48 c1 ef 20          	shr    $0x20,%rdi
    84b4:	48 39 d7             	cmp    %rdx,%rdi
    84b7:	73 9f                	jae    8458 <fwp_caps12+0xb8>
    84b9:	48 01 f8             	add    %rdi,%rax
    84bc:	0f b6 10             	movzbl (%rax),%edx
    84bf:	84 d2                	test   %dl,%dl
    84c1:	74 95                	je     8458 <fwp_caps12+0xb8>
    84c3:	8b 0d 3f 60 06 00    	mov    0x6603f(%rip),%ecx        # 6e508 <iteration_active>
    84c9:	85 c9                	test   %ecx,%ecx
    84cb:	75 33                	jne    8500 <fwp_caps12+0x160>
    84cd:	80 fa fd             	cmp    $0xfd,%dl
    84d0:	77 38                	ja     850a <fwp_caps12+0x16a>
    84d2:	83 c2 01             	add    $0x1,%edx
    84d5:	88 10                	mov    %dl,(%rax)
    84d7:	e9 7c ff ff ff       	jmp    8458 <fwp_caps12+0xb8>
    84dc:	0f 1f 40 00          	nopl   0x0(%rax)
    84e0:	66 85 d2             	test   %dx,%dx
    84e3:	0f 85 6f ff ff ff    	jne    8458 <fwp_caps12+0xb8>
    84e9:	e9 48 ff ff ff       	jmp    8436 <fwp_caps12+0x96>
    84ee:	66 90                	xchg   %ax,%ax
    84f0:	66 85 ff             	test   %di,%di
    84f3:	0f 85 5f ff ff ff    	jne    8458 <fwp_caps12+0xb8>
    84f9:	eb c1                	jmp    84bc <fwp_caps12+0x11c>
    84fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8500:	48 83 05 e8 5f 06 00 	addq   $0x1,0x65fe8(%rip)        # 6e4f0 <iteration_retains>
    8507:	01 
    8508:	eb c3                	jmp    84cd <fwp_caps12+0x12d>
    850a:	48 89 c7             	mov    %rax,%rdi
    850d:	48 83 c4 18          	add    $0x18,%rsp
    8511:	e9 9a d1 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    851d:	00 00 00 

0000000000008520 <fwp_caps23>:
    8520:	f3 0f 1e fa          	endbr64
    8524:	48 83 ec 18          	sub    $0x18,%rsp
    8528:	48 89 f8             	mov    %rdi,%rax
    852b:	8b 7f 04             	mov    0x4(%rdi),%edi
    852e:	85 ff                	test   %edi,%edi
    8530:	0f 84 9a 00 00 00    	je     85d0 <fwp_caps23+0xb0>
    8536:	48 8b 78 08          	mov    0x8(%rax),%rdi
    853a:	85 f6                	test   %esi,%esi
    853c:	0f 85 9e 00 00 00    	jne    85e0 <fwp_caps23+0xc0>
    8542:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8547:	e8 34 fa ff ff       	call   7f80 <fwp_drop2>
    854c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8551:	48 8b 0d c0 56 06 00 	mov    0x656c0(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8558:	48 89 c2             	mov    %rax,%rdx
    855b:	48 2b 15 8e 56 06 00 	sub    0x6568e(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8562:	48 c1 e1 10          	shl    $0x10,%rcx
    8566:	48 39 ca             	cmp    %rcx,%rdx
    8569:	73 6d                	jae    85d8 <fwp_caps23+0xb8>
    856b:	48 89 d1             	mov    %rdx,%rcx
    856e:	48 c1 e9 10          	shr    $0x10,%rcx
    8572:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8576:	48 8b 0d bb 56 06 00 	mov    0x656bb(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    857d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8581:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8585:	48 85 f6             	test   %rsi,%rsi
    8588:	74 4e                	je     85d8 <fwp_caps23+0xb8>
    858a:	0f b6 39             	movzbl (%rcx),%edi
    858d:	40 80 ff 02          	cmp    $0x2,%dil
    8591:	0f 84 c9 00 00 00    	je     8660 <fwp_caps23+0x140>
    8597:	40 80 ff 01          	cmp    $0x1,%dil
    859b:	75 3b                	jne    85d8 <fwp_caps23+0xb8>
    859d:	8b 79 18             	mov    0x18(%rcx),%edi
    85a0:	0f b7 d2             	movzwl %dx,%edx
    85a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    85a6:	48 0f af d7          	imul   %rdi,%rdx
    85aa:	48 c1 ea 20          	shr    $0x20,%rdx
    85ae:	48 39 ca             	cmp    %rcx,%rdx
    85b1:	73 25                	jae    85d8 <fwp_caps23+0xb8>
    85b3:	48 01 d6             	add    %rdx,%rsi
    85b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    85b9:	75 1d                	jne    85d8 <fwp_caps23+0xb8>
    85bb:	48 89 c7             	mov    %rax,%rdi
    85be:	48 83 c4 18          	add    $0x18,%rsp
    85c2:	e9 49 d4 ff ff       	jmp    5a10 <fwp_mem_free>
    85c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ce:	00 00 
    85d0:	85 f6                	test   %esi,%esi
    85d2:	0f 84 79 ff ff ff    	je     8551 <fwp_caps23+0x31>
    85d8:	48 83 c4 18          	add    $0x18,%rsp
    85dc:	c3                   	ret
    85dd:	0f 1f 00             	nopl   (%rax)
    85e0:	48 8b 05 31 56 06 00 	mov    0x65631(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    85e7:	48 2b 3d 02 56 06 00 	sub    0x65602(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    85ee:	48 c1 e0 10          	shl    $0x10,%rax
    85f2:	48 39 c7             	cmp    %rax,%rdi
    85f5:	73 e1                	jae    85d8 <fwp_caps23+0xb8>
    85f7:	48 89 f8             	mov    %rdi,%rax
    85fa:	48 c1 e8 10          	shr    $0x10,%rax
    85fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8602:	48 8b 05 2f 56 06 00 	mov    0x6562f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8609:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    860d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8611:	48 85 c0             	test   %rax,%rax
    8614:	74 c2                	je     85d8 <fwp_caps23+0xb8>
    8616:	0f b6 0a             	movzbl (%rdx),%ecx
    8619:	80 f9 02             	cmp    $0x2,%cl
    861c:	74 52                	je     8670 <fwp_caps23+0x150>
    861e:	80 f9 01             	cmp    $0x1,%cl
    8621:	75 b5                	jne    85d8 <fwp_caps23+0xb8>
    8623:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8626:	0f b7 ff             	movzwl %di,%edi
    8629:	8b 52 1c             	mov    0x1c(%rdx),%edx
    862c:	48 0f af f9          	imul   %rcx,%rdi
    8630:	48 c1 ef 20          	shr    $0x20,%rdi
    8634:	48 39 d7             	cmp    %rdx,%rdi
    8637:	73 9f                	jae    85d8 <fwp_caps23+0xb8>
    8639:	48 01 f8             	add    %rdi,%rax
    863c:	0f b6 10             	movzbl (%rax),%edx
    863f:	84 d2                	test   %dl,%dl
    8641:	74 95                	je     85d8 <fwp_caps23+0xb8>
    8643:	8b 0d bf 5e 06 00    	mov    0x65ebf(%rip),%ecx        # 6e508 <iteration_active>
    8649:	85 c9                	test   %ecx,%ecx
    864b:	75 33                	jne    8680 <fwp_caps23+0x160>
    864d:	80 fa fd             	cmp    $0xfd,%dl
    8650:	77 38                	ja     868a <fwp_caps23+0x16a>
    8652:	83 c2 01             	add    $0x1,%edx
    8655:	88 10                	mov    %dl,(%rax)
    8657:	e9 7c ff ff ff       	jmp    85d8 <fwp_caps23+0xb8>
    865c:	0f 1f 40 00          	nopl   0x0(%rax)
    8660:	66 85 d2             	test   %dx,%dx
    8663:	0f 85 6f ff ff ff    	jne    85d8 <fwp_caps23+0xb8>
    8669:	e9 48 ff ff ff       	jmp    85b6 <fwp_caps23+0x96>
    866e:	66 90                	xchg   %ax,%ax
    8670:	66 85 ff             	test   %di,%di
    8673:	0f 85 5f ff ff ff    	jne    85d8 <fwp_caps23+0xb8>
    8679:	eb c1                	jmp    863c <fwp_caps23+0x11c>
    867b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8680:	48 83 05 68 5e 06 00 	addq   $0x1,0x65e68(%rip)        # 6e4f0 <iteration_retains>
    8687:	01 
    8688:	eb c3                	jmp    864d <fwp_caps23+0x12d>
    868a:	48 89 c7             	mov    %rax,%rdi
    868d:	48 83 c4 18          	add    $0x18,%rsp
    8691:	e9 1a d0 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8696:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    869d:	00 00 00 

00000000000086a0 <f23>:
    86a0:	41 57                	push   %r15
    86a2:	41 56                	push   %r14
    86a4:	41 55                	push   %r13
    86a6:	41 54                	push   %r12
    86a8:	55                   	push   %rbp
    86a9:	53                   	push   %rbx
    86aa:	48 83 ec 38          	sub    $0x38,%rsp
    86ae:	48 8b 15 63 55 06 00 	mov    0x65563(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    86b5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    86ba:	48 c1 e2 10          	shl    $0x10,%rdx
    86be:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    86c5:	00 00 
    86c7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    86cc:	48 8b 0d 1d 55 06 00 	mov    0x6551d(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    86d3:	48 85 ff             	test   %rdi,%rdi
    86d6:	0f 84 1e 03 00 00    	je     89fa <f23+0x35a>
    86dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    86e1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    86e5:	4c 89 e8             	mov    %r13,%rax
    86e8:	48 29 c8             	sub    %rcx,%rax
    86eb:	48 39 d0             	cmp    %rdx,%rax
    86ee:	0f 83 ec 02 00 00    	jae    89e0 <f23+0x340>
    86f4:	48 89 c2             	mov    %rax,%rdx
    86f7:	48 c1 ea 10          	shr    $0x10,%rdx
    86fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86ff:	48 8b 15 32 55 06 00 	mov    0x65532(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8706:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    870a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    870e:	48 85 ff             	test   %rdi,%rdi
    8711:	0f 84 c9 02 00 00    	je     89e0 <f23+0x340>
    8717:	0f b6 0a             	movzbl (%rdx),%ecx
    871a:	80 f9 02             	cmp    $0x2,%cl
    871d:	0f 84 4d 02 00 00    	je     8970 <f23+0x2d0>
    8723:	80 f9 01             	cmp    $0x1,%cl
    8726:	75 24                	jne    874c <f23+0xac>
    8728:	8b 4a 18             	mov    0x18(%rdx),%ecx
    872b:	0f b7 c0             	movzwl %ax,%eax
    872e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8731:	48 0f af c1          	imul   %rcx,%rax
    8735:	48 c1 e8 20          	shr    $0x20,%rax
    8739:	48 39 d0             	cmp    %rdx,%rax
    873c:	73 0e                	jae    874c <f23+0xac>
    873e:	48 01 c7             	add    %rax,%rdi
    8741:	0f b6 07             	movzbl (%rdi),%eax
    8744:	84 c0                	test   %al,%al
    8746:	0f 85 44 02 00 00    	jne    8990 <f23+0x2f0>
    874c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8751:	48 8b 40 10          	mov    0x10(%rax),%rax
    8755:	ba 01 00 00 00       	mov    $0x1,%edx
    875a:	48 85 c0             	test   %rax,%rax
    875d:	74 0e                	je     876d <f23+0xcd>
    875f:	90                   	nop
    8760:	48 8b 40 10          	mov    0x10(%rax),%rax
    8764:	48 83 c2 01          	add    $0x1,%rdx
    8768:	48 85 c0             	test   %rax,%rax
    876b:	75 f3                	jne    8760 <f23+0xc0>
    876d:	4d 85 ed             	test   %r13,%r13
    8770:	0f 84 9a 02 00 00    	je     8a10 <f23+0x370>
    8776:	4c 89 e8             	mov    %r13,%rax
    8779:	31 db                	xor    %ebx,%ebx
    877b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8780:	48 8b 40 10          	mov    0x10(%rax),%rax
    8784:	48 83 c3 01          	add    $0x1,%rbx
    8788:	48 85 c0             	test   %rax,%rax
    878b:	75 f3                	jne    8780 <f23+0xe0>
    878d:	48 39 d3             	cmp    %rdx,%rbx
    8790:	48 0f 47 da          	cmova  %rdx,%rbx
    8794:	48 89 d8             	mov    %rbx,%rax
    8797:	48 c1 e8 3c          	shr    $0x3c,%rax
    879b:	0f 85 7d 03 00 00    	jne    8b1e <f23+0x47e>
    87a1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    87a5:	be 02 00 00 00       	mov    $0x2,%esi
    87aa:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    87b1:	00 
    87b2:	e8 59 d7 ff ff       	call   5f10 <fwp_heap_alloc>
    87b7:	48 89 28             	mov    %rbp,(%rax)
    87ba:	48 8b 15 57 54 06 00 	mov    0x65457(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    87c1:	49 89 c4             	mov    %rax,%r12
    87c4:	48 2b 05 25 54 06 00 	sub    0x65425(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    87cb:	48 c1 e2 10          	shl    $0x10,%rdx
    87cf:	48 39 d0             	cmp    %rdx,%rax
    87d2:	73 57                	jae    882b <f23+0x18b>
    87d4:	48 89 c2             	mov    %rax,%rdx
    87d7:	48 c1 ea 10          	shr    $0x10,%rdx
    87db:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87df:	48 8b 15 52 54 06 00 	mov    0x65452(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    87e6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87ea:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    87ee:	48 85 ed             	test   %rbp,%rbp
    87f1:	74 38                	je     882b <f23+0x18b>
    87f3:	0f b6 0a             	movzbl (%rdx),%ecx
    87f6:	80 f9 02             	cmp    $0x2,%cl
    87f9:	0f 84 d1 01 00 00    	je     89d0 <f23+0x330>
    87ff:	80 f9 01             	cmp    $0x1,%cl
    8802:	75 27                	jne    882b <f23+0x18b>
    8804:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8807:	0f b7 c0             	movzwl %ax,%eax
    880a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    880d:	48 0f af c1          	imul   %rcx,%rax
    8811:	48 c1 e8 20          	shr    $0x20,%rax
    8815:	48 39 d0             	cmp    %rdx,%rax
    8818:	73 11                	jae    882b <f23+0x18b>
    881a:	48 01 c5             	add    %rax,%rbp
    881d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8821:	0f 84 57 02 00 00    	je     8a7e <f23+0x3de>
    8827:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    882b:	48 85 db             	test   %rbx,%rbx
    882e:	74 5d                	je     888d <f23+0x1ed>
    8830:	48 c1 e3 04          	shl    $0x4,%rbx
    8834:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8839:	4c 89 e5             	mov    %r12,%rbp
    883c:	4d 89 ef             	mov    %r13,%r15
    883f:	4c 01 e3             	add    %r12,%rbx
    8842:	0f 1f 00             	nopl   (%rax)
    8845:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    884c:	00 00 00 00 
    8850:	49 8b 46 08          	mov    0x8(%r14),%rax
    8854:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8858:	48 83 c5 10          	add    $0x10,%rbp
    885c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8861:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8865:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8869:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    886e:	e8 dd df ff ff       	call   6850 <w107>
    8873:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8878:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    887c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8880:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8884:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8888:	48 39 dd             	cmp    %rbx,%rbp
    888b:	75 c3                	jne    8850 <f23+0x1b0>
    888d:	4c 89 ef             	mov    %r13,%rdi
    8890:	e8 eb f6 ff ff       	call   7f80 <fwp_drop2>
    8895:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    889a:	e8 e1 f6 ff ff       	call   7f80 <fwp_drop2>
    889f:	4c 89 e7             	mov    %r12,%rdi
    88a2:	e8 69 e1 ff ff       	call   6a10 <w164.constprop.0>
    88a7:	4c 89 e7             	mov    %r12,%rdi
    88aa:	48 89 c3             	mov    %rax,%rbx
    88ad:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    88b3:	e8 48 f4 ff ff       	call   7d00 <fwp_drop4>
    88b8:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    88be:	66 48 0f 6e db       	movq   %rbx,%xmm3
    88c3:	31 ff                	xor    %edi,%edi
    88c5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    88ca:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    88ce:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    88d3:	e8 b8 e1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    88d8:	48 8b 15 39 53 06 00 	mov    0x65339(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    88df:	48 89 c5             	mov    %rax,%rbp
    88e2:	48 2b 05 07 53 06 00 	sub    0x65307(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    88e9:	48 c1 e2 10          	shl    $0x10,%rdx
    88ed:	48 39 d0             	cmp    %rdx,%rax
    88f0:	73 55                	jae    8947 <f23+0x2a7>
    88f2:	48 89 c2             	mov    %rax,%rdx
    88f5:	48 c1 ea 10          	shr    $0x10,%rdx
    88f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88fd:	48 8b 15 34 53 06 00 	mov    0x65334(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8904:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8908:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    890c:	48 85 db             	test   %rbx,%rbx
    890f:	74 36                	je     8947 <f23+0x2a7>
    8911:	0f b6 0a             	movzbl (%rdx),%ecx
    8914:	80 f9 02             	cmp    $0x2,%cl
    8917:	0f 84 a3 00 00 00    	je     89c0 <f23+0x320>
    891d:	80 f9 01             	cmp    $0x1,%cl
    8920:	75 25                	jne    8947 <f23+0x2a7>
    8922:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8925:	0f b7 c0             	movzwl %ax,%eax
    8928:	8b 52 1c             	mov    0x1c(%rdx),%edx
    892b:	48 0f af c1          	imul   %rcx,%rax
    892f:	48 c1 e8 20          	shr    $0x20,%rax
    8933:	48 39 d0             	cmp    %rdx,%rax
    8936:	73 0f                	jae    8947 <f23+0x2a7>
    8938:	48 01 c3             	add    %rax,%rbx
    893b:	80 3b ff             	cmpb   $0xff,(%rbx)
    893e:	0f 84 2d 01 00 00    	je     8a71 <f23+0x3d1>
    8944:	c6 03 01             	movb   $0x1,(%rbx)
    8947:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    894c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8953:	00 00 
    8955:	0f 85 cf 01 00 00    	jne    8b2a <f23+0x48a>
    895b:	48 83 c4 38          	add    $0x38,%rsp
    895f:	48 89 e8             	mov    %rbp,%rax
    8962:	5b                   	pop    %rbx
    8963:	5d                   	pop    %rbp
    8964:	41 5c                	pop    %r12
    8966:	41 5d                	pop    %r13
    8968:	41 5e                	pop    %r14
    896a:	41 5f                	pop    %r15
    896c:	c3                   	ret
    896d:	0f 1f 00             	nopl   (%rax)
    8970:	66 85 c0             	test   %ax,%ax
    8973:	0f 85 d3 fd ff ff    	jne    874c <f23+0xac>
    8979:	0f b6 07             	movzbl (%rdi),%eax
    897c:	84 c0                	test   %al,%al
    897e:	0f 84 c8 fd ff ff    	je     874c <f23+0xac>
    8984:	90                   	nop
    8985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    898c:	00 00 00 00 
    8990:	8b 15 72 5b 06 00    	mov    0x65b72(%rip),%edx        # 6e508 <iteration_active>
    8996:	85 d2                	test   %edx,%edx
    8998:	75 56                	jne    89f0 <f23+0x350>
    899a:	3c fd                	cmp    $0xfd,%al
    899c:	0f 87 4b 01 00 00    	ja     8aed <f23+0x44d>
    89a2:	83 c0 01             	add    $0x1,%eax
    89a5:	88 07                	mov    %al,(%rdi)
    89a7:	31 d2                	xor    %edx,%edx
    89a9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    89af:	0f 85 97 fd ff ff    	jne    874c <f23+0xac>
    89b5:	e9 b3 fd ff ff       	jmp    876d <f23+0xcd>
    89ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89c0:	66 85 c0             	test   %ax,%ax
    89c3:	0f 85 7e ff ff ff    	jne    8947 <f23+0x2a7>
    89c9:	e9 6d ff ff ff       	jmp    893b <f23+0x29b>
    89ce:	66 90                	xchg   %ax,%ax
    89d0:	66 85 c0             	test   %ax,%ax
    89d3:	0f 85 52 fe ff ff    	jne    882b <f23+0x18b>
    89d9:	e9 3f fe ff ff       	jmp    881d <f23+0x17d>
    89de:	66 90                	xchg   %ax,%ax
    89e0:	4c 89 e8             	mov    %r13,%rax
    89e3:	e9 6d fd ff ff       	jmp    8755 <f23+0xb5>
    89e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89ef:	00 
    89f0:	48 83 05 f8 5a 06 00 	addq   $0x1,0x65af8(%rip)        # 6e4f0 <iteration_retains>
    89f7:	01 
    89f8:	eb a0                	jmp    899a <f23+0x2fa>
    89fa:	48 f7 d9             	neg    %rcx
    89fd:	48 39 d1             	cmp    %rdx,%rcx
    8a00:	0f 82 85 00 00 00    	jb     8a8b <f23+0x3eb>
    8a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a0d:	00 00 00 
    8a10:	be 02 00 00 00       	mov    $0x2,%esi
    8a15:	bf 08 00 00 00       	mov    $0x8,%edi
    8a1a:	e8 f1 d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a1f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8a26:	48 8b 15 eb 51 06 00 	mov    0x651eb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8a2d:	49 89 c4             	mov    %rax,%r12
    8a30:	48 2b 05 b9 51 06 00 	sub    0x651b9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8a37:	48 c1 e2 10          	shl    $0x10,%rdx
    8a3b:	48 39 d0             	cmp    %rdx,%rax
    8a3e:	0f 83 b3 00 00 00    	jae    8af7 <f23+0x457>
    8a44:	48 89 c2             	mov    %rax,%rdx
    8a47:	48 c1 ea 10          	shr    $0x10,%rdx
    8a4b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a4f:	48 8b 15 e2 51 06 00 	mov    0x651e2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8a56:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a5a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8a5e:	48 85 ed             	test   %rbp,%rbp
    8a61:	0f 84 90 00 00 00    	je     8af7 <f23+0x457>
    8a67:	31 db                	xor    %ebx,%ebx
    8a69:	45 31 ed             	xor    %r13d,%r13d
    8a6c:	e9 82 fd ff ff       	jmp    87f3 <f23+0x153>
    8a71:	48 89 df             	mov    %rbx,%rdi
    8a74:	e8 57 cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    8a79:	e9 c6 fe ff ff       	jmp    8944 <f23+0x2a4>
    8a7e:	48 89 ef             	mov    %rbp,%rdi
    8a81:	e8 4a cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    8a86:	e9 9c fd ff ff       	jmp    8827 <f23+0x187>
    8a8b:	48 89 c8             	mov    %rcx,%rax
    8a8e:	48 c1 e8 10          	shr    $0x10,%rax
    8a92:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8a96:	48 8b 05 9b 51 06 00 	mov    0x6519b(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8a9d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8aa1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8aa5:	48 85 ff             	test   %rdi,%rdi
    8aa8:	0f 84 62 ff ff ff    	je     8a10 <f23+0x370>
    8aae:	0f b6 02             	movzbl (%rdx),%eax
    8ab1:	3c 02                	cmp    $0x2,%al
    8ab3:	74 4a                	je     8aff <f23+0x45f>
    8ab5:	3c 01                	cmp    $0x1,%al
    8ab7:	0f 85 53 ff ff ff    	jne    8a10 <f23+0x370>
    8abd:	0f b7 c1             	movzwl %cx,%eax
    8ac0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ac3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ac6:	48 0f af c1          	imul   %rcx,%rax
    8aca:	48 c1 e8 20          	shr    $0x20,%rax
    8ace:	48 39 d0             	cmp    %rdx,%rax
    8ad1:	0f 83 39 ff ff ff    	jae    8a10 <f23+0x370>
    8ad7:	48 01 c7             	add    %rax,%rdi
    8ada:	0f b6 07             	movzbl (%rdi),%eax
    8add:	84 c0                	test   %al,%al
    8adf:	0f 84 2b ff ff ff    	je     8a10 <f23+0x370>
    8ae5:	45 31 ed             	xor    %r13d,%r13d
    8ae8:	e9 a3 fe ff ff       	jmp    8990 <f23+0x2f0>
    8aed:	e8 be cb ff ff       	call   56b0 <fwp_rc_wide_dup>
    8af2:	e9 b0 fe ff ff       	jmp    89a7 <f23+0x307>
    8af7:	45 31 ed             	xor    %r13d,%r13d
    8afa:	e9 8e fd ff ff       	jmp    888d <f23+0x1ed>
    8aff:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8b05:	49 89 cd             	mov    %rcx,%r13
    8b08:	0f 85 02 ff ff ff    	jne    8a10 <f23+0x370>
    8b0e:	0f b6 07             	movzbl (%rdi),%eax
    8b11:	84 c0                	test   %al,%al
    8b13:	0f 85 77 fe ff ff    	jne    8990 <f23+0x2f0>
    8b19:	e9 f2 fe ff ff       	jmp    8a10 <f23+0x370>
    8b1e:	48 8d 3d c6 76 00 00 	lea    0x76c6(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    8b25:	e8 26 b9 ff ff       	call   4450 <fwp_trap>
    8b2a:	e8 21 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b2f:	90                   	nop

0000000000008b30 <fwp_owned_entry23>:
    8b30:	f3 0f 1e fa          	endbr64
    8b34:	48 8b 3f             	mov    (%rdi),%rdi
    8b37:	e9 64 fb ff ff       	jmp    86a0 <f23>
    8b3c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008b40 <e23>:
    8b40:	f3 0f 1e fa          	endbr64
    8b44:	53                   	push   %rbx
    8b45:	48 8b 1f             	mov    (%rdi),%rbx
    8b48:	48 89 df             	mov    %rbx,%rdi
    8b4b:	e8 30 e1 ff ff       	call   6c80 <fwp_rc_share>
    8b50:	48 89 df             	mov    %rbx,%rdi
    8b53:	e8 48 fb ff ff       	call   86a0 <f23>
    8b58:	48 89 c3             	mov    %rax,%rbx
    8b5b:	48 89 c7             	mov    %rax,%rdi
    8b5e:	e8 1d e1 ff ff       	call   6c80 <fwp_rc_share>
    8b63:	48 89 d8             	mov    %rbx,%rax
    8b66:	5b                   	pop    %rbx
    8b67:	c3                   	ret
    8b68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b6f:	00 

0000000000008b70 <f12>:
    8b70:	41 57                	push   %r15
    8b72:	41 56                	push   %r14
    8b74:	41 55                	push   %r13
    8b76:	4c 8d 2d c3 eb ff ff 	lea    -0x143d(%rip),%r13        # 7740 <fwp_tape_scope_release>
    8b7d:	41 54                	push   %r12
    8b7f:	55                   	push   %rbp
    8b80:	53                   	push   %rbx
    8b81:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8b88:	48 8b 05 49 59 06 00 	mov    0x65949(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8b8f:	48 8b 15 82 50 06 00 	mov    0x65082(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8b96:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    8b9d:	00 00 
    8b9f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8ba6:	00 
    8ba7:	48 89 fd             	mov    %rdi,%rbp
    8baa:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    8baf:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    8bb6:	ff 
    8bb7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    8bbc:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    8bc1:	48 c1 e2 10          	shl    $0x10,%rdx
    8bc5:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8bca:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    8bcf:	48 8d 05 3a b4 00 00 	lea    0xb43a(%rip),%rax        # 14010 <fc23>
    8bd6:	48 2b 05 13 50 06 00 	sub    0x65013(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8bdd:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    8be2:	4c 89 3d ef 58 06 00 	mov    %r15,0x658ef(%rip)        # 6e4d8 <fwp_cleanups>
    8be9:	48 39 d0             	cmp    %rdx,%rax
    8bec:	73 6d                	jae    8c5b <f12+0xeb>
    8bee:	48 89 c2             	mov    %rax,%rdx
    8bf1:	48 c1 ea 10          	shr    $0x10,%rdx
    8bf5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bf9:	48 8b 15 38 50 06 00 	mov    0x65038(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8c00:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c04:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8c08:	48 85 ff             	test   %rdi,%rdi
    8c0b:	74 4e                	je     8c5b <f12+0xeb>
    8c0d:	0f b6 0a             	movzbl (%rdx),%ecx
    8c10:	80 f9 02             	cmp    $0x2,%cl
    8c13:	0f 84 67 0f 00 00    	je     9b80 <f12+0x1010>
    8c19:	80 f9 01             	cmp    $0x1,%cl
    8c1c:	75 3d                	jne    8c5b <f12+0xeb>
    8c1e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c21:	0f b7 c0             	movzwl %ax,%eax
    8c24:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c27:	48 0f af c1          	imul   %rcx,%rax
    8c2b:	48 c1 e8 20          	shr    $0x20,%rax
    8c2f:	48 39 d0             	cmp    %rdx,%rax
    8c32:	73 27                	jae    8c5b <f12+0xeb>
    8c34:	48 01 c7             	add    %rax,%rdi
    8c37:	0f b6 07             	movzbl (%rdi),%eax
    8c3a:	84 c0                	test   %al,%al
    8c3c:	74 1d                	je     8c5b <f12+0xeb>
    8c3e:	44 8b 05 c3 58 06 00 	mov    0x658c3(%rip),%r8d        # 6e508 <iteration_active>
    8c45:	45 85 c0             	test   %r8d,%r8d
    8c48:	0f 85 62 10 00 00    	jne    9cb0 <f12+0x1140>
    8c4e:	3c fd                	cmp    $0xfd,%al
    8c50:	0f 87 16 12 00 00    	ja     9e6c <f12+0x12fc>
    8c56:	83 c0 01             	add    $0x1,%eax
    8c59:	88 07                	mov    %al,(%rdi)
    8c5b:	48 8d 3d ae b3 00 00 	lea    0xb3ae(%rip),%rdi        # 14010 <fc23>
    8c62:	e8 69 e7 ff ff       	call   73d0 <fwp_closure_drop>
    8c67:	48 85 ed             	test   %rbp,%rbp
    8c6a:	0f 84 51 11 00 00    	je     9dc1 <f12+0x1251>
    8c70:	48 89 e8             	mov    %rbp,%rax
    8c73:	31 d2                	xor    %edx,%edx
    8c75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c7c:	00 00 00 00 
    8c80:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c84:	48 83 c2 01          	add    $0x1,%rdx
    8c88:	48 85 c0             	test   %rax,%rax
    8c8b:	75 f3                	jne    8c80 <f12+0x110>
    8c8d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8c94:	0f 87 60 12 00 00    	ja     9efa <f12+0x138a>
    8c9a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    8c9f:	8b 35 db b3 00 00    	mov    0xb3db(%rip),%esi        # 14080 <registered_finish.0>
    8ca5:	85 f6                	test   %esi,%esi
    8ca7:	0f 84 a3 0e 00 00    	je     9b50 <f12+0xfe0>
    8cad:	48 8b 1d 44 b4 01 00 	mov    0x1b444(%rip),%rbx        # 240f8 <fwp_tape_next_slot>
    8cb4:	4c 8b 25 4d b4 01 00 	mov    0x1b44d(%rip),%r12        # 24108 <fwp_ntapes>
    8cbb:	4c 39 e3             	cmp    %r12,%rbx
    8cbe:	0f 8d d4 00 00 00    	jge    8d98 <f12+0x228>
    8cc4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8cc8:	48 03 05 41 b4 01 00 	add    0x1b441(%rip),%rax        # 24110 <fwp_tapes>
    8ccf:	90                   	nop
    8cd0:	8b 48 04             	mov    0x4(%rax),%ecx
    8cd3:	85 c9                	test   %ecx,%ecx
    8cd5:	75 0c                	jne    8ce3 <f12+0x173>
    8cd7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8cdd:	0f 86 b5 00 00 00    	jbe    8d98 <f12+0x228>
    8ce3:	48 83 c3 01          	add    $0x1,%rbx
    8ce7:	48 83 c0 68          	add    $0x68,%rax
    8ceb:	4c 39 e3             	cmp    %r12,%rbx
    8cee:	75 e0                	jne    8cd0 <f12+0x160>
    8cf0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8cf7:	0f 8f 72 12 00 00    	jg     9f6f <f12+0x13ff>
    8cfd:	4c 39 25 fc b3 01 00 	cmp    %r12,0x1b3fc(%rip)        # 24100 <fwp_tapes_cap>
    8d04:	4c 8b 35 05 b4 01 00 	mov    0x1b405(%rip),%r14        # 24110 <fwp_tapes>
    8d0b:	75 4b                	jne    8d58 <f12+0x1e8>
    8d0d:	4d 85 e4             	test   %r12,%r12
    8d10:	0f 84 10 11 00 00    	je     9e26 <f12+0x12b6>
    8d16:	4b 8d 1c 24          	lea    (%r12,%r12,1),%rbx
    8d1a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    8d1f:	48 39 c3             	cmp    %rax,%rbx
    8d22:	48 0f 4f d8          	cmovg  %rax,%rbx
    8d26:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    8d2a:	31 d2                	xor    %edx,%edx
    8d2c:	4c 89 f7             	mov    %r14,%rdi
    8d2f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8d34:	e8 57 c4 ff ff       	call   5190 <ad_raw_realloc>
    8d39:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8d3e:	48 85 c0             	test   %rax,%rax
    8d41:	49 89 c6             	mov    %rax,%r14
    8d44:	0f 84 eb 11 00 00    	je     9f35 <f12+0x13c5>
    8d4a:	48 89 05 bf b3 01 00 	mov    %rax,0x1b3bf(%rip)        # 24110 <fwp_tapes>
    8d51:	48 89 1d a8 b3 01 00 	mov    %rbx,0x1b3a8(%rip)        # 24100 <fwp_tapes_cap>
    8d58:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8d5c:	4c 89 e3             	mov    %r12,%rbx
    8d5f:	4c 01 f0             	add    %r14,%rax
    8d62:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8d66:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8d6d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8d71:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8d78:	00 
    8d79:	48 29 f8             	sub    %rdi,%rax
    8d7c:	8d 48 68             	lea    0x68(%rax),%ecx
    8d7f:	31 c0                	xor    %eax,%eax
    8d81:	c1 e9 03             	shr    $0x3,%ecx
    8d84:	f3 48 ab             	rep stos %rax,(%rdi)
    8d87:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    8d8c:	48 89 05 75 b3 01 00 	mov    %rax,0x1b375(%rip)        # 24108 <fwp_ntapes>
    8d93:	eb 13                	jmp    8da8 <f12+0x238>
    8d95:	0f 1f 00             	nopl   (%rax)
    8d98:	49 39 dc             	cmp    %rbx,%r12
    8d9b:	0f 84 4f ff ff ff    	je     8cf0 <f12+0x180>
    8da1:	4c 8b 35 68 b3 01 00 	mov    0x1b368(%rip),%r14        # 24110 <fwp_tapes>
    8da8:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    8dac:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8db0:	48 8d 3d a9 73 00 00 	lea    0x73a9(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    8db7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8dbb:	4d 01 f4             	add    %r14,%r12
    8dbe:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    8dc5:	00 00 
    8dc7:	e8 c4 a5 ff ff       	call   3390 <getenv@plt>
    8dcc:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8dd1:	48 85 c0             	test   %rax,%rax
    8dd4:	74 09                	je     8ddf <f12+0x26f>
    8dd6:	80 38 30             	cmpb   $0x30,(%rax)
    8dd9:	0f 84 21 07 00 00    	je     9500 <f12+0x990>
    8ddf:	48 83 3d c1 b2 01 00 	cmpq   $0x0,0x1b2c1(%rip)        # 240a8 <fwp_tape_cached_bytes>
    8de6:	00 
    8de7:	0f 85 f3 0d 00 00    	jne    9be0 <f12+0x1070>
    8ded:	41 8b 04 24          	mov    (%r12),%eax
    8df1:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    8df5:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8dfc:	00 00 
    8dfe:	48 89 3d f3 b2 01 00 	mov    %rdi,0x1b2f3(%rip)        # 240f8 <fwp_tape_next_slot>
    8e05:	8d 70 01             	lea    0x1(%rax),%esi
    8e08:	48 8b 05 c9 56 06 00 	mov    0x656c9(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8e0f:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    8e16:	00 00 
    8e18:	41 89 34 24          	mov    %esi,(%r12)
    8e1c:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    8e23:	ff ff 
    8e25:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8e2b:	48 85 c0             	test   %rax,%rax
    8e2e:	75 1c                	jne    8e4c <f12+0x2dc>
    8e30:	e9 57 11 00 00       	jmp    9f8c <f12+0x141c>
    8e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e3c:	00 00 00 00 
    8e40:	48 8b 00             	mov    (%rax),%rax
    8e43:	48 85 c0             	test   %rax,%rax
    8e46:	0f 84 40 11 00 00    	je     9f8c <f12+0x141c>
    8e4c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8e50:	75 ee                	jne    8e40 <f12+0x2d0>
    8e52:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8e56:	89 d9                	mov    %ebx,%ecx
    8e58:	48 63 02             	movslq (%rdx),%rax
    8e5b:	49 89 54 24 50       	mov    %rdx,0x50(%r12)
    8e60:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8e65:	85 c0                	test   %eax,%eax
    8e67:	78 09                	js     8e72 <f12+0x302>
    8e69:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8e6d:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8e72:	89 0a                	mov    %ecx,(%rdx)
    8e74:	48 89 e8             	mov    %rbp,%rax
    8e77:	31 c9                	xor    %ecx,%ecx
    8e79:	48 85 ed             	test   %rbp,%rbp
    8e7c:	0f 84 ae 0b 00 00    	je     9a30 <f12+0xec0>
    8e82:	0f 1f 00             	nopl   (%rax)
    8e85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e8c:	00 00 00 00 
    8e90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e94:	48 83 c1 01          	add    $0x1,%rcx
    8e98:	48 85 c0             	test   %rax,%rax
    8e9b:	75 f3                	jne    8e90 <f12+0x320>
    8e9d:	48 89 ea             	mov    %rbp,%rdx
    8ea0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8ea4:	48 83 c0 01          	add    $0x1,%rax
    8ea8:	48 85 d2             	test   %rdx,%rdx
    8eab:	75 f3                	jne    8ea0 <f12+0x330>
    8ead:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8eb4:	ff ff 1f 
    8eb7:	48 39 c2             	cmp    %rax,%rdx
    8eba:	0f 82 46 10 00 00    	jb     9f06 <f12+0x1396>
    8ec0:	48 85 c9             	test   %rcx,%rcx
    8ec3:	0f 8e 67 0b 00 00    	jle    9a30 <f12+0xec0>
    8ec9:	48 39 c1             	cmp    %rax,%rcx
    8ecc:	48 0f 46 c1          	cmovbe %rcx,%rax
    8ed0:	49 89 c5             	mov    %rax,%r13
    8ed3:	48 c1 e8 3c          	shr    $0x3c,%rax
    8ed7:	0f 85 29 10 00 00    	jne    9f06 <f12+0x1396>
    8edd:	48 c1 e6 10          	shl    $0x10,%rsi
    8ee1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    8ee6:	48 09 fe             	or     %rdi,%rsi
    8ee9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8ef0:	00 
    8ef1:	49 89 f4             	mov    %rsi,%r12
    8ef4:	be 02 00 00 00       	mov    $0x2,%esi
    8ef9:	e8 12 d0 ff ff       	call   5f10 <fwp_heap_alloc>
    8efe:	4c 89 30             	mov    %r14,(%rax)
    8f01:	48 8b 15 10 4d 06 00 	mov    0x64d10(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8f08:	48 89 c3             	mov    %rax,%rbx
    8f0b:	48 2b 05 de 4c 06 00 	sub    0x64cde(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8f12:	48 c1 e2 10          	shl    $0x10,%rdx
    8f16:	48 39 d0             	cmp    %rdx,%rax
    8f19:	0f 83 a9 0b 00 00    	jae    9ac8 <f12+0xf58>
    8f1f:	48 89 c2             	mov    %rax,%rdx
    8f22:	48 c1 ea 10          	shr    $0x10,%rdx
    8f26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f2a:	48 8b 15 07 4d 06 00 	mov    0x64d07(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8f31:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8f35:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8f39:	48 85 d2             	test   %rdx,%rdx
    8f3c:	74 38                	je     8f76 <f12+0x406>
    8f3e:	0f b6 31             	movzbl (%rcx),%esi
    8f41:	40 80 fe 02          	cmp    $0x2,%sil
    8f45:	0f 84 52 0b 00 00    	je     9a9d <f12+0xf2d>
    8f4b:	40 80 fe 01          	cmp    $0x1,%sil
    8f4f:	75 25                	jne    8f76 <f12+0x406>
    8f51:	8b 71 18             	mov    0x18(%rcx),%esi
    8f54:	0f b7 c0             	movzwl %ax,%eax
    8f57:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8f5a:	48 0f af c6          	imul   %rsi,%rax
    8f5e:	48 c1 e8 20          	shr    $0x20,%rax
    8f62:	48 39 c8             	cmp    %rcx,%rax
    8f65:	73 0f                	jae    8f76 <f12+0x406>
    8f67:	48 01 c2             	add    %rax,%rdx
    8f6a:	80 3a ff             	cmpb   $0xff,(%rdx)
    8f6d:	0f 84 c2 0e 00 00    	je     9e35 <f12+0x12c5>
    8f73:	c6 02 01             	movb   $0x1,(%rdx)
    8f76:	4d 85 ed             	test   %r13,%r13
    8f79:	74 78                	je     8ff3 <f12+0x483>
    8f7b:	4c 89 e1             	mov    %r12,%rcx
    8f7e:	48 89 ea             	mov    %rbp,%rdx
    8f81:	31 c0                	xor    %eax,%eax
    8f83:	48 c1 e1 20          	shl    $0x20,%rcx
    8f87:	66 90                	xchg   %ax,%ax
    8f89:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f90:	00 00 00 00 
    8f94:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8f9b:	00 00 00 00 
    8f9f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fa6:	00 00 00 00 
    8faa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fb1:	00 00 00 00 
    8fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8fbc:	00 00 00 00 
    8fc0:	48 89 c6             	mov    %rax,%rsi
    8fc3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8fc8:	48 01 ce             	add    %rcx,%rsi
    8fcb:	0f 80 1c 0f 00 00    	jo     9eed <f12+0x137d>
    8fd1:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8fd6:	48 89 c6             	mov    %rax,%rsi
    8fd9:	48 83 c0 01          	add    $0x1,%rax
    8fdd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8fe1:	48 c1 e6 04          	shl    $0x4,%rsi
    8fe5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8fea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8fee:	4c 39 e8             	cmp    %r13,%rax
    8ff1:	72 cd                	jb     8fc0 <f12+0x450>
    8ff3:	48 8b 03             	mov    (%rbx),%rax
    8ff6:	48 d1 e8             	shr    $1,%rax
    8ff9:	0f 84 e1 0a 00 00    	je     9ae0 <f12+0xf70>
    8fff:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    9003:	48 89 d1             	mov    %rdx,%rcx
    9006:	48 c1 e9 3c          	shr    $0x3c,%rcx
    900a:	0f 85 f6 0e 00 00    	jne    9f06 <f12+0x1396>
    9010:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    9014:	48 89 0c 24          	mov    %rcx,(%rsp)
    9018:	48 85 d2             	test   %rdx,%rdx
    901b:	74 41                	je     905e <f12+0x4ee>
    901d:	48 c1 e0 04          	shl    $0x4,%rax
    9021:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    9025:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    902a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9030:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    9035:	49 8b 76 18          	mov    0x18(%r14),%rsi
    9039:	49 83 c6 10          	add    $0x10,%r14
    903d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    9041:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    9046:	e8 05 d8 ff ff       	call   6850 <w107>
    904b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9050:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9054:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    9059:	4d 39 f5             	cmp    %r14,%r13
    905c:	75 d2                	jne    9030 <f12+0x4c0>
    905e:	48 8b 04 24          	mov    (%rsp),%rax
    9062:	48 89 df             	mov    %rbx,%rdi
    9065:	48 89 03             	mov    %rax,(%rbx)
    9068:	e8 a3 d9 ff ff       	call   6a10 <w164.constprop.0>
    906d:	48 89 df             	mov    %rbx,%rdi
    9070:	49 63 dc             	movslq %r12d,%rbx
    9073:	49 89 c5             	mov    %rax,%r13
    9076:	e8 85 ec ff ff       	call   7d00 <fwp_drop4>
    907b:	48 89 df             	mov    %rbx,%rdi
    907e:	e8 ad b6 ff ff       	call   4730 <fwp_tape_of>
    9083:	48 89 c6             	mov    %rax,%rsi
    9086:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    908b:	0f 85 ef 0e 00 00    	jne    9f80 <f12+0x1410>
    9091:	48 89 c7             	mov    %rax,%rdi
    9094:	e8 f7 ab ff ff       	call   3c90 <fwp_tape_unlink_scope>
    9099:	4c 8b 46 48          	mov    0x48(%rsi),%r8
    909d:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    90a2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    90a9:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    90ad:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    90b1:	66 49 0f 6e f8       	movq   %r8,%xmm7
    90b6:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    90bb:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    90c0:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    90c4:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    90c8:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    90ce:	77 19                	ja     90e9 <f12+0x579>
    90d0:	41 0f b7 c4          	movzwl %r12w,%eax
    90d4:	83 e8 01             	sub    $0x1,%eax
    90d7:	48 98                	cltq
    90d9:	48 3b 05 18 b0 01 00 	cmp    0x1b018(%rip),%rax        # 240f8 <fwp_tape_next_slot>
    90e0:	7d 07                	jge    90e9 <f12+0x579>
    90e2:	48 89 05 0f b0 01 00 	mov    %rax,0x1b00f(%rip)        # 240f8 <fwp_tape_next_slot>
    90e9:	48 8b 05 e8 53 06 00 	mov    0x653e8(%rip),%rax        # 6e4d8 <fwp_cleanups>
    90f0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    90f4:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    90fb:	00 
    90fc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9103:	00 
    9104:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9108:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    910f:	00 
    9110:	48 8d 05 49 c1 ff ff 	lea    -0x3eb7(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    9117:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    911e:	00 
    911f:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9126:	00 
    9127:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    912b:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    912f:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9136:	00 
    9137:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    913e:	00 
    913f:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    9146:	00 
    9147:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    914e:	00 
    914f:	48 89 05 82 53 06 00 	mov    %rax,0x65382(%rip)        # 6e4d8 <fwp_cleanups>
    9156:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    915d:	00 
    915e:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    9165:	00 
    9166:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    916d:	00 
    916e:	4d 85 ed             	test   %r13,%r13
    9171:	0f 88 19 0a 00 00    	js     9b90 <f12+0x1020>
    9177:	4c 89 e8             	mov    %r13,%rax
    917a:	48 c1 f8 20          	sar    $0x20,%rax
    917e:	48 39 c3             	cmp    %rax,%rbx
    9181:	0f 85 42 0d 00 00    	jne    9ec9 <f12+0x1359>
    9187:	44 89 e9             	mov    %r13d,%ecx
    918a:	48 39 ca             	cmp    %rcx,%rdx
    918d:	0f 8e 42 0d 00 00    	jle    9ed5 <f12+0x1365>
    9193:	49 39 ce             	cmp    %rcx,%r14
    9196:	0f 8e 54 09 00 00    	jle    9af0 <f12+0xf80>
    919c:	4d 39 c6             	cmp    %r8,%r14
    919f:	0f 8e b3 0a 00 00    	jle    9c58 <f12+0x10e8>
    91a5:	4c 89 f3             	mov    %r14,%rbx
    91a8:	4d 85 c0             	test   %r8,%r8
    91ab:	4c 0f 44 c3          	cmove  %rbx,%r8
    91af:	eb 24                	jmp    91d5 <f12+0x665>
    91b1:	0f 1f 40 00          	nopl   0x0(%rax)
    91b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91bc:	00 00 00 00 
    91c0:	4b 8d 14 00          	lea    (%r8,%r8,1),%rdx
    91c4:	49 81 f8 00 00 00 40 	cmp    $0x40000000,%r8
    91cb:	48 89 d8             	mov    %rbx,%rax
    91ce:	48 0f 4c c2          	cmovl  %rdx,%rax
    91d2:	49 89 c0             	mov    %rax,%r8
    91d5:	49 39 d8             	cmp    %rbx,%r8
    91d8:	7c e6                	jl     91c0 <f12+0x650>
    91da:	4d 85 c9             	test   %r9,%r9
    91dd:	0f 84 0d 0b 00 00    	je     9cf0 <f12+0x1180>
    91e3:	4a 8d 34 c5 00 00 00 	lea    0x0(,%r8,8),%rsi
    91ea:	00 
    91eb:	4c 89 cf             	mov    %r9,%rdi
    91ee:	ba 03 00 00 00       	mov    $0x3,%edx
    91f3:	4c 89 04 24          	mov    %r8,(%rsp)
    91f7:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    91fc:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9201:	e8 8a bf ff ff       	call   5190 <ad_raw_realloc>
    9206:	4c 8b 04 24          	mov    (%rsp),%r8
    920a:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9210:	48 85 c0             	test   %rax,%rax
    9213:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9219:	49 89 c1             	mov    %rax,%r9
    921c:	0f 84 8e 0b 00 00    	je     9db0 <f12+0x1240>
    9222:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
    9229:	00 
    922a:	4c 89 84 24 d0 00 00 	mov    %r8,0xd0(%rsp)
    9231:	00 
    9232:	48 85 db             	test   %rbx,%rbx
    9235:	0f 85 3e 0c 00 00    	jne    9e79 <f12+0x1309>
    923b:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    9242:	4d 85 ed             	test   %r13,%r13
    9245:	78 17                	js     925e <f12+0x6ee>
    9247:	44 89 e9             	mov    %r13d,%ecx
    924a:	f2 0f 10 05 8e 7b 00 	movsd  0x7b8e(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    9251:	00 
    9252:	f2 41 0f 58 04 c9    	addsd  (%r9,%rcx,8),%xmm0
    9258:	f2 41 0f 11 04 c9    	movsd  %xmm0,(%r9,%rcx,8)
    925e:	4d 39 de             	cmp    %r11,%r14
    9261:	0f 8f 8a 00 00 00    	jg     92f1 <f12+0x781>
    9267:	0f 12 fb             	movhlps %xmm3,%xmm7
    926a:	66 49 0f 7e d0       	movq   %xmm2,%r8
    926f:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    9274:	4d 29 f3             	sub    %r14,%r11
    9277:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    927c:	0f 12 fa             	movhlps %xmm2,%xmm7
    927f:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
    9283:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    9288:	4a 8d 04 9e          	lea    (%rsi,%r11,4),%rax
    928c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9290:	48 29 f1             	sub    %rsi,%rcx
    9293:	4a 8d 14 db          	lea    (%rbx,%r11,8),%rdx
    9297:	48 29 df             	sub    %rbx,%rdi
    929a:	49 29 d8             	sub    %rbx,%r8
    929d:	eb 05                	jmp    92a4 <f12+0x734>
    929f:	90                   	nop
    92a0:	48 83 e8 04          	sub    $0x4,%rax
    92a4:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    92a9:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    92ad:	7a 02                	jp     92b1 <f12+0x741>
    92af:	74 37                	je     92e8 <f12+0x778>
    92b1:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    92b5:	45 85 db             	test   %r11d,%r11d
    92b8:	78 16                	js     92d0 <f12+0x760>
    92ba:	f2 41 0f 10 0c 10    	movsd  (%r8,%rdx,1),%xmm1
    92c0:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    92c4:	f2 43 0f 58 0c d9    	addsd  (%r9,%r11,8),%xmm1
    92ca:	f2 43 0f 11 0c d9    	movsd  %xmm1,(%r9,%r11,8)
    92d0:	4c 63 18             	movslq (%rax),%r11
    92d3:	45 85 db             	test   %r11d,%r11d
    92d6:	78 10                	js     92e8 <f12+0x778>
    92d8:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    92dc:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    92e2:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    92e8:	48 83 ea 08          	sub    $0x8,%rdx
    92ec:	48 39 c6             	cmp    %rax,%rsi
    92ef:	75 af                	jne    92a0 <f12+0x730>
    92f1:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    92f8:	ff ff 1f 
    92fb:	4c 39 f0             	cmp    %r14,%rax
    92fe:	0f 82 0e 0c 00 00    	jb     9f12 <f12+0x13a2>
    9304:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    930b:	00 
    930c:	be 02 00 00 00       	mov    $0x2,%esi
    9311:	4c 89 0c 24          	mov    %r9,(%rsp)
    9315:	e8 f6 cb ff ff       	call   5f10 <fwp_heap_alloc>
    931a:	4c 8b 0c 24          	mov    (%rsp),%r9
    931e:	4c 89 30             	mov    %r14,(%rax)
    9321:	49 89 c5             	mov    %rax,%r13
    9324:	31 c0                	xor    %eax,%eax
    9326:	4d 85 f6             	test   %r14,%r14
    9329:	74 27                	je     9352 <f12+0x7e2>
    932b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9332:	00 00 00 
    9335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    933c:	00 00 00 00 
    9340:	49 8b 14 c1          	mov    (%r9,%rax,8),%rdx
    9344:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    9349:	48 83 c0 01          	add    $0x1,%rax
    934d:	49 39 c6             	cmp    %rax,%r14
    9350:	75 ee                	jne    9340 <f12+0x7d0>
    9352:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
    9359:	00 
    935a:	4c 89 e7             	mov    %r12,%rdi
    935d:	48 89 0d 74 51 06 00 	mov    %rcx,0x65174(%rip)        # 6e4d8 <fwp_cleanups>
    9364:	48 89 0c 24          	mov    %rcx,(%rsp)
    9368:	e8 f3 be ff ff       	call   5260 <fwp_tape_buffers_release>
    936d:	48 8b 15 a4 48 06 00 	mov    0x648a4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9374:	4c 89 e8             	mov    %r13,%rax
    9377:	48 8b 0c 24          	mov    (%rsp),%rcx
    937b:	48 2b 05 6e 48 06 00 	sub    0x6486e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9382:	48 c1 e2 10          	shl    $0x10,%rdx
    9386:	48 39 d0             	cmp    %rdx,%rax
    9389:	73 57                	jae    93e2 <f12+0x872>
    938b:	48 89 c2             	mov    %rax,%rdx
    938e:	48 c1 ea 10          	shr    $0x10,%rdx
    9392:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9396:	48 8b 15 9b 48 06 00 	mov    0x6489b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    939d:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    93a1:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    93a5:	48 85 db             	test   %rbx,%rbx
    93a8:	74 38                	je     93e2 <f12+0x872>
    93aa:	0f b6 32             	movzbl (%rdx),%esi
    93ad:	40 80 fe 02          	cmp    $0x2,%sil
    93b1:	0f 84 09 08 00 00    	je     9bc0 <f12+0x1050>
    93b7:	40 80 fe 01          	cmp    $0x1,%sil
    93bb:	75 25                	jne    93e2 <f12+0x872>
    93bd:	8b 72 18             	mov    0x18(%rdx),%esi
    93c0:	0f b7 c0             	movzwl %ax,%eax
    93c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93c6:	48 0f af c6          	imul   %rsi,%rax
    93ca:	48 c1 e8 20          	shr    $0x20,%rax
    93ce:	48 39 d0             	cmp    %rdx,%rax
    93d1:	73 0f                	jae    93e2 <f12+0x872>
    93d3:	48 01 c3             	add    %rax,%rbx
    93d6:	80 3b ff             	cmpb   $0xff,(%rbx)
    93d9:	0f 84 6b 0a 00 00    	je     9e4a <f12+0x12da>
    93df:	c6 03 01             	movb   $0x1,(%rbx)
    93e2:	4c 39 f9             	cmp    %r15,%rcx
    93e5:	0f 85 60 a3 ff ff    	jne    374b <f12.cold>
    93eb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    93f0:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    93f5:	48 89 05 dc 50 06 00 	mov    %rax,0x650dc(%rip)        # 6e4d8 <fwp_cleanups>
    93fc:	e8 3f e3 ff ff       	call   7740 <fwp_tape_scope_release>
    9401:	49 8b 45 00          	mov    0x0(%r13),%rax
    9405:	49 89 c4             	mov    %rax,%r12
    9408:	49 0f ba f4 3f       	btr    $0x3f,%r12
    940d:	48 85 c0             	test   %rax,%rax
    9410:	0f 88 6a 05 00 00    	js     9980 <f12+0xe10>
    9416:	48 8b 15 fb 47 06 00 	mov    0x647fb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    941d:	4c 89 e8             	mov    %r13,%rax
    9420:	48 2b 05 c9 47 06 00 	sub    0x647c9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9427:	48 c1 e2 10          	shl    $0x10,%rdx
    942b:	48 39 d0             	cmp    %rdx,%rax
    942e:	0f 83 4c 05 00 00    	jae    9980 <f12+0xe10>
    9434:	48 89 c2             	mov    %rax,%rdx
    9437:	48 c1 ea 10          	shr    $0x10,%rdx
    943b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    943f:	48 8b 15 f2 47 06 00 	mov    0x647f2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9446:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    944a:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    944e:	48 85 c9             	test   %rcx,%rcx
    9451:	0f 84 29 05 00 00    	je     9980 <f12+0xe10>
    9457:	0f b6 32             	movzbl (%rdx),%esi
    945a:	40 80 fe 02          	cmp    $0x2,%sil
    945e:	0f 84 0c 05 00 00    	je     9970 <f12+0xe00>
    9464:	40 80 fe 01          	cmp    $0x1,%sil
    9468:	0f 85 12 05 00 00    	jne    9980 <f12+0xe10>
    946e:	8b 72 18             	mov    0x18(%rdx),%esi
    9471:	0f b7 c0             	movzwl %ax,%eax
    9474:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9477:	48 0f af c6          	imul   %rsi,%rax
    947b:	48 c1 e8 20          	shr    $0x20,%rax
    947f:	48 39 d0             	cmp    %rdx,%rax
    9482:	0f 83 f8 04 00 00    	jae    9980 <f12+0xe10>
    9488:	48 01 c1             	add    %rax,%rcx
    948b:	80 39 01             	cmpb   $0x1,(%rcx)
    948e:	0f 85 ec 04 00 00    	jne    9980 <f12+0xe10>
    9494:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    9499:	4d 89 ef             	mov    %r13,%r15
    949c:	31 ff                	xor    %edi,%edi
    949e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    94a3:	f2 0f 10 0d 45 79 00 	movsd  0x7945(%rip),%xmm1        # 10df0 <msg.4+0xc0>
    94aa:	00 
    94ab:	48 8d 50 08          	lea    0x8(%rax),%rdx
    94af:	31 c0                	xor    %eax,%eax
    94b1:	4d 85 e4             	test   %r12,%r12
    94b4:	75 2f                	jne    94e5 <f12+0x975>
    94b6:	eb 58                	jmp    9510 <f12+0x9a0>
    94b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    94bf:	00 
    94c0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    94c4:	0f 88 17 0a 00 00    	js     9ee1 <f12+0x1371>
    94ca:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    94cf:	48 83 c0 01          	add    $0x1,%rax
    94d3:	48 83 c2 08          	add    $0x8,%rdx
    94d7:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    94db:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    94e0:	49 39 c4             	cmp    %rax,%r12
    94e3:	74 2b                	je     9510 <f12+0x9a0>
    94e5:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    94e9:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    94ee:	79 d0                	jns    94c0 <f12+0x950>
    94f0:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    94f4:	eb ca                	jmp    94c0 <f12+0x950>
    94f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94fd:	00 00 00 
    9500:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9504:	0f 84 e3 f8 ff ff    	je     8ded <f12+0x27d>
    950a:	e9 d0 f8 ff ff       	jmp    8ddf <f12+0x26f>
    950f:	90                   	nop
    9510:	e8 eb e7 ff ff       	call   7d00 <fwp_drop4>
    9515:	48 89 e8             	mov    %rbp,%rax
    9518:	31 d2                	xor    %edx,%edx
    951a:	48 85 ed             	test   %rbp,%rbp
    951d:	0f 84 a7 08 00 00    	je     9dca <f12+0x125a>
    9523:	66 90                	xchg   %ax,%ax
    9525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    952c:	00 00 00 00 
    9530:	48 8b 40 10          	mov    0x10(%rax),%rax
    9534:	48 83 c2 01          	add    $0x1,%rdx
    9538:	48 85 c0             	test   %rax,%rax
    953b:	75 f3                	jne    9530 <f12+0x9c0>
    953d:	49 8b 07             	mov    (%r15),%rax
    9540:	49 89 c5             	mov    %rax,%r13
    9543:	49 0f ba f5 3f       	btr    $0x3f,%r13
    9548:	48 85 c0             	test   %rax,%rax
    954b:	0f 88 81 03 00 00    	js     98d2 <f12+0xd62>
    9551:	48 8b 05 c0 46 06 00 	mov    0x646c0(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    9558:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    955d:	48 2b 0d 8c 46 06 00 	sub    0x6468c(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    9564:	48 c1 e0 10          	shl    $0x10,%rax
    9568:	48 39 c1             	cmp    %rax,%rcx
    956b:	0f 83 61 03 00 00    	jae    98d2 <f12+0xd62>
    9571:	48 89 c8             	mov    %rcx,%rax
    9574:	48 c1 e8 10          	shr    $0x10,%rax
    9578:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    957c:	48 8b 05 b5 46 06 00 	mov    0x646b5(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    9583:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    9587:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    958b:	48 85 ff             	test   %rdi,%rdi
    958e:	0f 84 3e 03 00 00    	je     98d2 <f12+0xd62>
    9594:	0f b6 06             	movzbl (%rsi),%eax
    9597:	3c 02                	cmp    $0x2,%al
    9599:	0f 84 21 03 00 00    	je     98c0 <f12+0xd50>
    959f:	3c 01                	cmp    $0x1,%al
    95a1:	0f 85 22 03 00 00    	jne    98c9 <f12+0xd59>
    95a7:	8b 46 18             	mov    0x18(%rsi),%eax
    95aa:	0f b7 c9             	movzwl %cx,%ecx
    95ad:	48 0f af c8          	imul   %rax,%rcx
    95b1:	8b 46 1c             	mov    0x1c(%rsi),%eax
    95b4:	48 c1 e9 20          	shr    $0x20,%rcx
    95b8:	48 39 c1             	cmp    %rax,%rcx
    95bb:	0f 83 08 03 00 00    	jae    98c9 <f12+0xd59>
    95c1:	48 01 cf             	add    %rcx,%rdi
    95c4:	80 3f 01             	cmpb   $0x1,(%rdi)
    95c7:	0f 85 fc 02 00 00    	jne    98c9 <f12+0xd59>
    95cd:	4c 39 ea             	cmp    %r13,%rdx
    95d0:	4c 89 e8             	mov    %r13,%rax
    95d3:	48 0f 46 c2          	cmovbe %rdx,%rax
    95d7:	48 85 c0             	test   %rax,%rax
    95da:	0f 84 12 09 00 00    	je     9ef2 <f12+0x1382>
    95e0:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    95e7:	00 
    95e8:	4d 8d 77 08          	lea    0x8(%r15),%r14
    95ec:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    95f1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    95f8:	00 
    95f9:	48 89 e9             	mov    %rbp,%rcx
    95fc:	31 d2                	xor    %edx,%edx
    95fe:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9602:	eb 59                	jmp    965d <f12+0xaed>
    9604:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9609:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9610:	00 00 00 00 
    9614:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    961b:	00 00 00 00 
    961f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9626:	00 00 00 00 
    962a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9631:	00 00 00 00 
    9635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    963c:	00 00 00 00 
    9640:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9645:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    964a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9650:	48 83 c2 08          	add    $0x8,%rdx
    9654:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9658:	49 39 d0             	cmp    %rdx,%r8
    965b:	74 1b                	je     9678 <f12+0xb08>
    965d:	48 89 fe             	mov    %rdi,%rsi
    9660:	49 83 3f 00          	cmpq   $0x0,(%r15)
    9664:	79 da                	jns    9640 <f12+0xad0>
    9666:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    966b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    966f:	eb cf                	jmp    9640 <f12+0xad0>
    9671:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9678:	48 85 ed             	test   %rbp,%rbp
    967b:	0f 84 40 08 00 00    	je     9ec1 <f12+0x1351>
    9681:	4c 8b 05 90 45 06 00 	mov    0x64590(%rip),%r8        # 6dc18 <fwp_heap+0x13d8>
    9688:	4c 8b 0d 61 45 06 00 	mov    0x64561(%rip),%r9        # 6dbf0 <fwp_heap+0x13b0>
    968f:	48 89 e9             	mov    %rbp,%rcx
    9692:	45 31 ed             	xor    %r13d,%r13d
    9695:	4c 8b 15 9c 45 06 00 	mov    0x6459c(%rip),%r10        # 6dc38 <fwp_heap+0x13f8>
    969c:	49 c1 e0 10          	shl    $0x10,%r8
    96a0:	eb 1c                	jmp    96be <f12+0xb4e>
    96a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96a8:	49 83 c5 01          	add    $0x1,%r13
    96ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    96b0:	49 39 c5             	cmp    %rax,%r13
    96b3:	0f 83 67 01 00 00    	jae    9820 <f12+0xcb0>
    96b9:	48 85 c9             	test   %rcx,%rcx
    96bc:	74 56                	je     9714 <f12+0xba4>
    96be:	48 89 ca             	mov    %rcx,%rdx
    96c1:	4c 29 ca             	sub    %r9,%rdx
    96c4:	4c 39 c2             	cmp    %r8,%rdx
    96c7:	73 4b                	jae    9714 <f12+0xba4>
    96c9:	48 89 d6             	mov    %rdx,%rsi
    96cc:	48 c1 ee 10          	shr    $0x10,%rsi
    96d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    96d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    96d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    96dc:	48 85 ff             	test   %rdi,%rdi
    96df:	74 33                	je     9714 <f12+0xba4>
    96e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    96e5:	41 80 fb 02          	cmp    $0x2,%r11b
    96e9:	0f 84 19 01 00 00    	je     9808 <f12+0xc98>
    96ef:	41 80 fb 01          	cmp    $0x1,%r11b
    96f3:	75 1f                	jne    9714 <f12+0xba4>
    96f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    96f9:	0f b7 d2             	movzwl %dx,%edx
    96fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    96ff:	49 0f af d3          	imul   %r11,%rdx
    9703:	48 c1 ea 20          	shr    $0x20,%rdx
    9707:	48 39 f2             	cmp    %rsi,%rdx
    970a:	73 08                	jae    9714 <f12+0xba4>
    970c:	48 01 d7             	add    %rdx,%rdi
    970f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9712:	74 94                	je     96a8 <f12+0xb38>
    9714:	49 39 c5             	cmp    %rax,%r13
    9717:	0f 83 03 01 00 00    	jae    9820 <f12+0xcb0>
    971d:	49 89 c7             	mov    %rax,%r15
    9720:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9727:	00 
    9728:	45 31 e4             	xor    %r12d,%r12d
    972b:	48 89 04 24          	mov    %rax,(%rsp)
    972f:	48 8d 1d 0a 31 06 00 	lea    0x6310a(%rip),%rbx        # 6c840 <fwp_heap>
    9736:	eb 3a                	jmp    9772 <f12+0xc02>
    9738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    973f:	00 
    9740:	41 80 f9 01          	cmp    $0x1,%r9b
    9744:	75 27                	jne    976d <f12+0xbfd>
    9746:	45 8b 48 18          	mov    0x18(%r8),%r9d
    974a:	0f b7 c0             	movzwl %ax,%eax
    974d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9751:	49 0f af c1          	imul   %r9,%rax
    9755:	48 c1 e8 20          	shr    $0x20,%rax
    9759:	4c 39 c0             	cmp    %r8,%rax
    975c:	73 0f                	jae    976d <f12+0xbfd>
    975e:	48 01 c7             	add    %rax,%rdi
    9761:	80 3f ff             	cmpb   $0xff,(%rdi)
    9764:	0f 84 46 03 00 00    	je     9ab0 <f12+0xf40>
    976a:	c6 07 01             	movb   $0x1,(%rdi)
    976d:	4d 39 fd             	cmp    %r15,%r13
    9770:	73 7e                	jae    97f0 <f12+0xc80>
    9772:	49 83 ef 01          	sub    $0x1,%r15
    9776:	66 49 0f 6e f4       	movq   %r12,%xmm6
    977b:	48 8b 34 24          	mov    (%rsp),%rsi
    977f:	bf 01 00 00 00       	mov    $0x1,%edi
    9784:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    978a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    978e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9795:	00 
    9796:	e8 f5 d2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    979b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    97a2:	49 89 c4             	mov    %rax,%r12
    97a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    97ac:	48 c1 e7 10          	shl    $0x10,%rdi
    97b0:	48 39 f8             	cmp    %rdi,%rax
    97b3:	73 b8                	jae    976d <f12+0xbfd>
    97b5:	48 89 c7             	mov    %rax,%rdi
    97b8:	48 c1 ef 10          	shr    $0x10,%rdi
    97bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    97c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    97c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    97cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    97cf:	48 85 ff             	test   %rdi,%rdi
    97d2:	74 99                	je     976d <f12+0xbfd>
    97d4:	45 0f b6 08          	movzbl (%r8),%r9d
    97d8:	41 80 f9 02          	cmp    $0x2,%r9b
    97dc:	0f 85 5e ff ff ff    	jne    9740 <f12+0xbd0>
    97e2:	66 85 c0             	test   %ax,%ax
    97e5:	0f 84 76 ff ff ff    	je     9761 <f12+0xbf1>
    97eb:	4d 39 fd             	cmp    %r15,%r13
    97ee:	72 82                	jb     9772 <f12+0xc02>
    97f0:	4d 85 ed             	test   %r13,%r13
    97f3:	75 2e                	jne    9823 <f12+0xcb3>
    97f5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    97f9:	85 c0                	test   %eax,%eax
    97fb:	4d 0f 45 f5          	cmovne %r13,%r14
    97ff:	eb 6f                	jmp    9870 <f12+0xd00>
    9801:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9808:	66 85 d2             	test   %dx,%dx
    980b:	0f 84 fe fe ff ff    	je     970f <f12+0xb9f>
    9811:	49 39 c5             	cmp    %rax,%r13
    9814:	0f 82 03 ff ff ff    	jb     971d <f12+0xbad>
    981a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9820:	45 31 e4             	xor    %r12d,%r12d
    9823:	4c 89 f2             	mov    %r14,%rdx
    9826:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    982a:	48 89 e8             	mov    %rbp,%rax
    982d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9834:	00 
    9835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    983c:	00 00 00 00 
    9840:	48 8b 0a             	mov    (%rdx),%rcx
    9843:	48 83 c2 08          	add    $0x8,%rdx
    9847:	48 89 c7             	mov    %rax,%rdi
    984a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    984e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9852:	49 39 d0             	cmp    %rdx,%r8
    9855:	75 e9                	jne    9840 <f12+0xcd0>
    9857:	8b 54 24 20          	mov    0x20(%rsp),%edx
    985b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    985f:	85 d2                	test   %edx,%edx
    9861:	0f 84 69 03 00 00    	je     9bd0 <f12+0x1060>
    9867:	49 89 ec             	mov    %rbp,%r12
    986a:	45 31 f6             	xor    %r14d,%r14d
    986d:	48 89 c5             	mov    %rax,%rbp
    9870:	4c 89 f7             	mov    %r14,%rdi
    9873:	e8 98 c1 ff ff       	call   5a10 <fwp_mem_free>
    9878:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    987d:	e8 7e e4 ff ff       	call   7d00 <fwp_drop4>
    9882:	48 89 ef             	mov    %rbp,%rdi
    9885:	e8 56 d8 ff ff       	call   70e0 <fwp_drop0>
    988a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9891:	00 
    9892:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9899:	00 00 
    989b:	0f 85 da 06 00 00    	jne    9f7b <f12+0x140b>
    98a1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    98a8:	4c 89 e0             	mov    %r12,%rax
    98ab:	5b                   	pop    %rbx
    98ac:	5d                   	pop    %rbp
    98ad:	41 5c                	pop    %r12
    98af:	41 5d                	pop    %r13
    98b1:	41 5e                	pop    %r14
    98b3:	41 5f                	pop    %r15
    98b5:	c3                   	ret
    98b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    98bd:	00 00 00 
    98c0:	66 85 c9             	test   %cx,%cx
    98c3:	0f 84 fb fc ff ff    	je     95c4 <f12+0xa54>
    98c9:	48 85 ed             	test   %rbp,%rbp
    98cc:	0f 84 eb 03 00 00    	je     9cbd <f12+0x114d>
    98d2:	48 89 e8             	mov    %rbp,%rax
    98d5:	45 31 e4             	xor    %r12d,%r12d
    98d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    98df:	00 
    98e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    98e4:	4c 89 e2             	mov    %r12,%rdx
    98e7:	49 83 c4 01          	add    $0x1,%r12
    98eb:	48 85 c0             	test   %rax,%rax
    98ee:	75 f0                	jne    98e0 <f12+0xd70>
    98f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    98f7:	ff ff 1f 
    98fa:	4c 39 e0             	cmp    %r12,%rax
    98fd:	0f 82 03 06 00 00    	jb     9f06 <f12+0x1396>
    9903:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    990a:	00 
    990b:	be 02 00 00 00       	mov    $0x2,%esi
    9910:	e8 fb c5 ff ff       	call   5f10 <fwp_heap_alloc>
    9915:	4d 39 e5             	cmp    %r12,%r13
    9918:	48 89 ea             	mov    %rbp,%rdx
    991b:	49 89 c6             	mov    %rax,%r14
    991e:	4c 89 e0             	mov    %r12,%rax
    9921:	49 0f 46 c5          	cmovbe %r13,%rax
    9925:	4c 89 f1             	mov    %r14,%rcx
    9928:	66 90                	xchg   %ax,%ax
    992a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9931:	00 00 00 00 
    9935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    993c:	00 00 00 00 
    9940:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9944:	48 83 c1 08          	add    $0x8,%rcx
    9948:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    994c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9950:	48 85 d2             	test   %rdx,%rdx
    9953:	75 eb                	jne    9940 <f12+0xdd0>
    9955:	48 85 c0             	test   %rax,%rax
    9958:	0f 84 71 03 00 00    	je     9ccf <f12+0x115f>
    995e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    9965:	00 
    9966:	e9 81 fc ff ff       	jmp    95ec <f12+0xa7c>
    996b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9970:	66 85 c0             	test   %ax,%ax
    9973:	0f 84 12 fb ff ff    	je     948b <f12+0x91b>
    9979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9980:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9987:	ff ff 1f 
    998a:	4c 39 e0             	cmp    %r12,%rax
    998d:	0f 82 7f 05 00 00    	jb     9f12 <f12+0x13a2>
    9993:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    999a:	00 
    999b:	be 01 00 00 00       	mov    $0x1,%esi
    99a0:	e8 6b c5 ff ff       	call   5f10 <fwp_heap_alloc>
    99a5:	4c 89 20             	mov    %r12,(%rax)
    99a8:	48 8b 15 69 42 06 00 	mov    0x64269(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    99af:	49 89 c7             	mov    %rax,%r15
    99b2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    99b7:	48 2b 05 32 42 06 00 	sub    0x64232(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    99be:	48 c1 e2 10          	shl    $0x10,%rdx
    99c2:	48 39 d0             	cmp    %rdx,%rax
    99c5:	73 57                	jae    9a1e <f12+0xeae>
    99c7:	48 89 c2             	mov    %rax,%rdx
    99ca:	48 c1 ea 10          	shr    $0x10,%rdx
    99ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99d2:	48 8b 15 5f 42 06 00 	mov    0x6425f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    99d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99dd:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    99e1:	4d 85 f6             	test   %r14,%r14
    99e4:	74 38                	je     9a1e <f12+0xeae>
    99e6:	0f b6 0a             	movzbl (%rdx),%ecx
    99e9:	80 f9 02             	cmp    $0x2,%cl
    99ec:	0f 84 ee 02 00 00    	je     9ce0 <f12+0x1170>
    99f2:	80 f9 01             	cmp    $0x1,%cl
    99f5:	75 27                	jne    9a1e <f12+0xeae>
    99f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99fa:	0f b7 c0             	movzwl %ax,%eax
    99fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a00:	48 0f af c1          	imul   %rcx,%rax
    9a04:	48 c1 e8 20          	shr    $0x20,%rax
    9a08:	48 39 d0             	cmp    %rdx,%rax
    9a0b:	73 11                	jae    9a1e <f12+0xeae>
    9a0d:	49 01 c6             	add    %rax,%r14
    9a10:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9a14:	0f 84 45 04 00 00    	je     9e5f <f12+0x12ef>
    9a1a:	41 c6 06 01          	movb   $0x1,(%r14)
    9a1e:	4c 89 ef             	mov    %r13,%rdi
    9a21:	e9 78 fa ff ff       	jmp    949e <f12+0x92e>
    9a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a2d:	00 00 00 
    9a30:	48 c1 e6 10          	shl    $0x10,%rsi
    9a34:	48 09 fe             	or     %rdi,%rsi
    9a37:	bf 08 00 00 00       	mov    $0x8,%edi
    9a3c:	49 89 f4             	mov    %rsi,%r12
    9a3f:	be 02 00 00 00       	mov    $0x2,%esi
    9a44:	e8 c7 c4 ff ff       	call   5f10 <fwp_heap_alloc>
    9a49:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9a50:	48 8b 15 c1 41 06 00 	mov    0x641c1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9a57:	48 89 c3             	mov    %rax,%rbx
    9a5a:	48 2b 05 8f 41 06 00 	sub    0x6418f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9a61:	48 c1 e2 10          	shl    $0x10,%rdx
    9a65:	48 39 d0             	cmp    %rdx,%rax
    9a68:	73 76                	jae    9ae0 <f12+0xf70>
    9a6a:	48 89 c2             	mov    %rax,%rdx
    9a6d:	48 c1 ea 10          	shr    $0x10,%rdx
    9a71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a75:	48 8b 15 bc 41 06 00 	mov    0x641bc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9a7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9a80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    9a84:	48 85 d2             	test   %rdx,%rdx
    9a87:	0f 84 66 f5 ff ff    	je     8ff3 <f12+0x483>
    9a8d:	0f b6 31             	movzbl (%rcx),%esi
    9a90:	45 31 ed             	xor    %r13d,%r13d
    9a93:	40 80 fe 02          	cmp    $0x2,%sil
    9a97:	0f 85 ae f4 ff ff    	jne    8f4b <f12+0x3db>
    9a9d:	66 85 c0             	test   %ax,%ax
    9aa0:	0f 85 d0 f4 ff ff    	jne    8f76 <f12+0x406>
    9aa6:	e9 bf f4 ff ff       	jmp    8f6a <f12+0x3fa>
    9aab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ab0:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    9ab5:	e8 16 bd ff ff       	call   57d0 <fwp_rc_forget_slot>
    9aba:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9abf:	e9 a6 fc ff ff       	jmp    976a <f12+0xbfa>
    9ac4:	0f 1f 40 00          	nopl   0x0(%rax)
    9ac8:	4d 85 ed             	test   %r13,%r13
    9acb:	0f 85 aa f4 ff ff    	jne    8f7b <f12+0x40b>
    9ad1:	0f 1f 40 00          	nopl   0x0(%rax)
    9ad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9adc:	00 00 00 00 
    9ae0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    9ae7:	00 
    9ae8:	e9 71 f5 ff ff       	jmp    905e <f12+0x4ee>
    9aed:	0f 1f 00             	nopl   (%rax)
    9af0:	48 8d 59 01          	lea    0x1(%rcx),%rbx
    9af4:	49 39 d8             	cmp    %rbx,%r8
    9af7:	0f 8c ab f6 ff ff    	jl     91a8 <f12+0x638>
    9afd:	4d 85 c9             	test   %r9,%r9
    9b00:	0f 84 18 04 00 00    	je     9f1e <f12+0x13ae>
    9b06:	4c 89 cf             	mov    %r9,%rdi
    9b09:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9b10:	00 
    9b11:	31 f6                	xor    %esi,%esi
    9b13:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9b17:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    9b1c:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    9b21:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    9b26:	e8 85 99 ff ff       	call   34b0 <memset@plt>
    9b2b:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    9b30:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    9b36:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9b3b:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
    9b40:	49 89 c1             	mov    %rax,%r9
    9b43:	e9 02 f7 ff ff       	jmp    924a <f12+0x6da>
    9b48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b4f:	00 
    9b50:	48 8d 3d c9 da ff ff 	lea    -0x2537(%rip),%rdi        # 7620 <fwp_tape_finish>
    9b57:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9b5c:	e8 af 59 00 00       	call   f510 <atexit>
    9b61:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9b66:	85 c0                	test   %eax,%eax
    9b68:	0f 85 c7 03 00 00    	jne    9f35 <f12+0x13c5>
    9b6e:	c7 05 08 a5 00 00 01 	movl   $0x1,0xa508(%rip)        # 14080 <registered_finish.0>
    9b75:	00 00 00 
    9b78:	e9 30 f1 ff ff       	jmp    8cad <f12+0x13d>
    9b7d:	0f 1f 00             	nopl   (%rax)
    9b80:	66 85 c0             	test   %ax,%ax
    9b83:	0f 85 d2 f0 ff ff    	jne    8c5b <f12+0xeb>
    9b89:	e9 a9 f0 ff ff       	jmp    8c37 <f12+0xc7>
    9b8e:	66 90                	xchg   %ax,%ax
    9b90:	4d 39 c6             	cmp    %r8,%r14
    9b93:	0f 8f 0c f6 ff ff    	jg     91a5 <f12+0x635>
    9b99:	4d 85 f6             	test   %r14,%r14
    9b9c:	74 12                	je     9bb0 <f12+0x1040>
    9b9e:	4d 85 c9             	test   %r9,%r9
    9ba1:	0f 84 77 03 00 00    	je     9f1e <f12+0x13ae>
    9ba7:	4d 85 f6             	test   %r14,%r14
    9baa:	0f 85 c6 02 00 00    	jne    9e76 <f12+0x1306>
    9bb0:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
    9bb7:	e9 a2 f6 ff ff       	jmp    925e <f12+0x6ee>
    9bbc:	0f 1f 40 00          	nopl   0x0(%rax)
    9bc0:	66 85 c0             	test   %ax,%ax
    9bc3:	0f 85 19 f8 ff ff    	jne    93e2 <f12+0x872>
    9bc9:	e9 08 f8 ff ff       	jmp    93d6 <f12+0x866>
    9bce:	66 90                	xchg   %ax,%ax
    9bd0:	49 89 ec             	mov    %rbp,%r12
    9bd3:	48 89 c5             	mov    %rax,%rbp
    9bd6:	e9 95 fc ff ff       	jmp    9870 <f12+0xd00>
    9bdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9be0:	66 0f 6f 0d d8 a4 01 	movdqa 0x1a4d8(%rip),%xmm1        # 240c0 <fwp_tape_workspace>
    9be7:	00 
    9be8:	48 c7 05 b5 a4 01 00 	movq   $0x0,0x1a4b5(%rip)        # 240a8 <fwp_tape_cached_bytes>
    9bef:	00 00 00 00 
    9bf3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9bf9:	48 8b 05 e0 a4 01 00 	mov    0x1a4e0(%rip),%rax        # 240e0 <fwp_tape_workspace+0x20>
    9c00:	66 0f 6f 0d c8 a4 01 	movdqa 0x1a4c8(%rip),%xmm1        # 240d0 <fwp_tape_workspace+0x10>
    9c07:	00 
    9c08:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    9c0d:	48 8b 05 d4 a4 01 00 	mov    0x1a4d4(%rip),%rax        # 240e8 <fwp_tape_workspace+0x28>
    9c14:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    9c1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9c1e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9c23:	48 8b 05 c6 a4 01 00 	mov    0x1a4c6(%rip),%rax        # 240f0 <fwp_tape_workspace+0x30>
    9c2a:	0f 29 0d 8f a4 01 00 	movaps %xmm1,0x1a48f(%rip)        # 240c0 <fwp_tape_workspace>
    9c31:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9c36:	0f 29 0d 93 a4 01 00 	movaps %xmm1,0x1a493(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    9c3d:	48 c7 05 a8 a4 01 00 	movq   $0x0,0x1a4a8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    9c44:	00 00 00 00 
    9c48:	0f 29 0d 91 a4 01 00 	movaps %xmm1,0x1a491(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    9c4f:	e9 99 f1 ff ff       	jmp    8ded <f12+0x27d>
    9c54:	0f 1f 40 00          	nopl   0x0(%rax)
    9c58:	4d 85 c9             	test   %r9,%r9
    9c5b:	0f 84 bd 02 00 00    	je     9f1e <f12+0x13ae>
    9c61:	4d 8d 5e ff          	lea    -0x1(%r14),%r11
    9c65:	4c 89 cf             	mov    %r9,%rdi
    9c68:	31 f6                	xor    %esi,%esi
    9c6a:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
    9c6f:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9c76:	00 
    9c77:	4c 89 1c 24          	mov    %r11,(%rsp)
    9c7b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9c80:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9c85:	e8 26 98 ff ff       	call   34b0 <memset@plt>
    9c8a:	4c 8b 1c 24          	mov    (%rsp),%r11
    9c8e:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9c94:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9c9a:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    9c9f:	49 89 c1             	mov    %rax,%r9
    9ca2:	e9 a3 f5 ff ff       	jmp    924a <f12+0x6da>
    9ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cae:	00 00 
    9cb0:	48 83 05 38 48 06 00 	addq   $0x1,0x64838(%rip)        # 6e4f0 <iteration_retains>
    9cb7:	01 
    9cb8:	e9 91 ef ff ff       	jmp    8c4e <f12+0xde>
    9cbd:	be 02 00 00 00       	mov    $0x2,%esi
    9cc2:	bf 08 00 00 00       	mov    $0x8,%edi
    9cc7:	e8 44 c2 ff ff       	call   5f10 <fwp_heap_alloc>
    9ccc:	49 89 c6             	mov    %rax,%r14
    9ccf:	45 31 e4             	xor    %r12d,%r12d
    9cd2:	e9 99 fb ff ff       	jmp    9870 <f12+0xd00>
    9cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9cde:	00 00 
    9ce0:	66 85 c0             	test   %ax,%ax
    9ce3:	0f 85 35 fd ff ff    	jne    9a1e <f12+0xeae>
    9ce9:	e9 22 fd ff ff       	jmp    9a10 <f12+0xea0>
    9cee:	66 90                	xchg   %ax,%ax
    9cf0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9cf7:	ff ff 1f 
    9cfa:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    9cfe:	48 39 c2             	cmp    %rax,%rdx
    9d01:	0f 82 5c 02 00 00    	jb     9f63 <f12+0x13f3>
    9d07:	48 8d 05 d2 a4 04 00 	lea    0x4a4d2(%rip),%rax        # 541e0 <ad_raw_blocks>
    9d0e:	31 d2                	xor    %edx,%edx
    9d10:	eb 23                	jmp    9d35 <f12+0x11c5>
    9d12:	0f 1f 00             	nopl   (%rax)
    9d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d1c:	00 00 00 00 
    9d20:	48 83 c2 01          	add    $0x1,%rdx
    9d24:	48 83 c0 18          	add    $0x18,%rax
    9d28:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
    9d2f:	0f 84 80 01 00 00    	je     9eb5 <f12+0x1345>
    9d35:	48 83 38 00          	cmpq   $0x0,(%rax)
    9d39:	75 e5                	jne    9d20 <f12+0x11b0>
    9d3b:	4c 89 c7             	mov    %r8,%rdi
    9d3e:	be 08 00 00 00       	mov    $0x8,%esi
    9d43:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    9d48:	4c 89 04 24          	mov    %r8,(%rsp)
    9d4c:	0f 29 5c 24 40       	movaps %xmm3,0x40(%rsp)
    9d51:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    9d56:	e8 b5 97 ff ff       	call   3510 <calloc@plt>
    9d5b:	4c 8b 04 24          	mov    (%rsp),%r8
    9d5f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    9d64:	48 8d 0d 75 a4 04 00 	lea    0x4a475(%rip),%rcx        # 541e0 <ad_raw_blocks>
    9d6b:	48 85 c0             	test   %rax,%rax
    9d6e:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    9d74:	66 0f 6f 5c 24 40    	movdqa 0x40(%rsp),%xmm3
    9d7a:	74 34                	je     9db0 <f12+0x1240>
    9d7c:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    9d80:	48 89 c6             	mov    %rax,%rsi
    9d83:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    9d88:	48 8d 3c d1          	lea    (%rcx,%rdx,8),%rdi
    9d8c:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    9d93:	00 
    9d94:	b9 03 00 00 00       	mov    $0x3,%ecx
    9d99:	48 89 04 24          	mov    %rax,(%rsp)
    9d9d:	e8 5e 9e ff ff       	call   3c00 <ad_raw_record>
    9da2:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9da7:	4c 8b 0c 24          	mov    (%rsp),%r9
    9dab:	e9 72 f4 ff ff       	jmp    9222 <f12+0x6b2>
    9db0:	48 85 db             	test   %rbx,%rbx
    9db3:	0f 85 65 01 00 00    	jne    9f1e <f12+0x13ae>
    9db9:	45 31 c9             	xor    %r9d,%r9d
    9dbc:	e9 7a f4 ff ff       	jmp    923b <f12+0x6cb>
    9dc1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9dc5:	e9 d5 ee ff ff       	jmp    8c9f <f12+0x12f>
    9dca:	49 8b 07             	mov    (%r15),%rax
    9dcd:	48 85 c0             	test   %rax,%rax
    9dd0:	0f 88 e7 fe ff ff    	js     9cbd <f12+0x114d>
    9dd6:	48 8b 35 3b 3e 06 00 	mov    0x63e3b(%rip),%rsi        # 6dc18 <fwp_heap+0x13d8>
    9ddd:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    9de2:	48 2b 0d 07 3e 06 00 	sub    0x63e07(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    9de9:	48 c1 e6 10          	shl    $0x10,%rsi
    9ded:	48 39 f1             	cmp    %rsi,%rcx
    9df0:	0f 83 c7 fe ff ff    	jae    9cbd <f12+0x114d>
    9df6:	48 89 ce             	mov    %rcx,%rsi
    9df9:	48 c1 ee 10          	shr    $0x10,%rsi
    9dfd:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9e01:	48 8b 35 30 3e 06 00 	mov    0x63e30(%rip),%rsi        # 6dc38 <fwp_heap+0x13f8>
    9e08:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9e0c:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9e10:	48 85 ff             	test   %rdi,%rdi
    9e13:	0f 84 a4 fe ff ff    	je     9cbd <f12+0x114d>
    9e19:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9e1e:	49 89 c5             	mov    %rax,%r13
    9e21:	e9 6e f7 ff ff       	jmp    9594 <f12+0xa24>
    9e26:	be 68 00 00 00       	mov    $0x68,%esi
    9e2b:	bb 01 00 00 00       	mov    $0x1,%ebx
    9e30:	e9 f5 ee ff ff       	jmp    8d2a <f12+0x1ba>
    9e35:	48 89 d7             	mov    %rdx,%rdi
    9e38:	48 89 14 24          	mov    %rdx,(%rsp)
    9e3c:	e8 8f b9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9e41:	48 8b 14 24          	mov    (%rsp),%rdx
    9e45:	e9 29 f1 ff ff       	jmp    8f73 <f12+0x403>
    9e4a:	48 89 df             	mov    %rbx,%rdi
    9e4d:	48 89 0c 24          	mov    %rcx,(%rsp)
    9e51:	e8 7a b9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9e56:	48 8b 0c 24          	mov    (%rsp),%rcx
    9e5a:	e9 80 f5 ff ff       	jmp    93df <f12+0x86f>
    9e5f:	4c 89 f7             	mov    %r14,%rdi
    9e62:	e8 69 b9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    9e67:	e9 ae fb ff ff       	jmp    9a1a <f12+0xeaa>
    9e6c:	e8 3f b8 ff ff       	call   56b0 <fwp_rc_wide_dup>
    9e71:	e9 e5 ed ff ff       	jmp    8c5b <f12+0xeb>
    9e76:	4c 89 f3             	mov    %r14,%rbx
    9e79:	4c 8d 5b ff          	lea    -0x1(%rbx),%r11
    9e7d:	4c 89 cf             	mov    %r9,%rdi
    9e80:	31 f6                	xor    %esi,%esi
    9e82:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9e87:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9e8e:	00 
    9e8f:	4c 89 1c 24          	mov    %r11,(%rsp)
    9e93:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9e98:	e8 13 96 ff ff       	call   34b0 <memset@plt>
    9e9d:	4c 8b 1c 24          	mov    (%rsp),%r11
    9ea1:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9ea7:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9ead:	49 89 c1             	mov    %rax,%r9
    9eb0:	e9 8d f3 ff ff       	jmp    9242 <f12+0x6d2>
    9eb5:	48 8d 3d 56 62 00 00 	lea    0x6256(%rip),%rdi        # 10112 <_IO_stdin_used+0x112>
    9ebc:	e8 3f a1 ff ff       	call   4000 <ad_raw_fail>
    9ec1:	45 31 ed             	xor    %r13d,%r13d
    9ec4:	e9 54 f8 ff ff       	jmp    971d <f12+0xbad>
    9ec9:	48 8d 3d 38 6b 00 00 	lea    0x6b38(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    9ed0:	e8 7b a5 ff ff       	call   4450 <fwp_trap>
    9ed5:	48 8d 3d e6 62 00 00 	lea    0x62e6(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    9edc:	e8 6f a5 ff ff       	call   4450 <fwp_trap>
    9ee1:	48 8d 3d 28 6c 00 00 	lea    0x6c28(%rip),%rdi        # 10b10 <_IO_stdin_used+0xb10>
    9ee8:	e8 63 a5 ff ff       	call   4450 <fwp_trap>
    9eed:	e8 0e 98 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9ef2:	45 31 f6             	xor    %r14d,%r14d
    9ef5:	e9 d5 fd ff ff       	jmp    9ccf <f12+0x115f>
    9efa:	48 8d 3d f8 62 00 00 	lea    0x62f8(%rip),%rdi        # 101f9 <_IO_stdin_used+0x1f9>
    9f01:	e8 4a a5 ff ff       	call   4450 <fwp_trap>
    9f06:	48 8d 3d de 62 00 00 	lea    0x62de(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    9f0d:	e8 3e a5 ff ff       	call   4450 <fwp_trap>
    9f12:	48 8d 3d 16 63 00 00 	lea    0x6316(%rip),%rdi        # 1022f <_IO_stdin_used+0x22f>
    9f19:	e8 32 a5 ff ff       	call   4450 <fwp_trap>
    9f1e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9f25:	00 
    9f26:	4c 89 e7             	mov    %r12,%rdi
    9f29:	48 89 05 a8 45 06 00 	mov    %rax,0x645a8(%rip)        # 6e4d8 <fwp_cleanups>
    9f30:	e8 2b b3 ff ff       	call   5260 <fwp_tape_buffers_release>
    9f35:	48 8b 0d 24 a1 00 00 	mov    0xa124(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    9f3c:	ba 13 00 00 00       	mov    $0x13,%edx
    9f41:	be 01 00 00 00       	mov    $0x1,%esi
    9f46:	48 8d 3d bb 60 00 00 	lea    0x60bb(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    9f4d:	e8 0e 97 ff ff       	call   3660 <fwrite@plt>
    9f52:	31 ff                	xor    %edi,%edi
    9f54:	e8 47 96 ff ff       	call   35a0 <fflush@plt>
    9f59:	bf 66 00 00 00       	mov    $0x66,%edi
    9f5e:	e8 1d 97 ff ff       	call   3680 <_Exit@plt>
    9f63:	48 8d 3d a9 62 00 00 	lea    0x62a9(%rip),%rdi        # 10213 <_IO_stdin_used+0x213>
    9f6a:	e8 91 a0 ff ff       	call   4000 <ad_raw_fail>
    9f6f:	48 8d 3d 3a 6b 00 00 	lea    0x6b3a(%rip),%rdi        # 10ab0 <_IO_stdin_used+0xab0>
    9f76:	e8 d5 a4 ff ff       	call   4450 <fwp_trap>
    9f7b:	e8 d0 94 ff ff       	call   3450 <__stack_chk_fail@plt>
    9f80:	48 8d 3d c9 6a 00 00 	lea    0x6ac9(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    9f87:	e8 c4 a4 ff ff       	call   4450 <fwp_trap>
    9f8c:	48 8d 3d 4d 6b 00 00 	lea    0x6b4d(%rip),%rdi        # 10ae0 <_IO_stdin_used+0xae0>
    9f93:	e8 b8 a4 ff ff       	call   4450 <fwp_trap>
    9f98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f9f:	00 

0000000000009fa0 <fwp_owned_entry12>:
    9fa0:	f3 0f 1e fa          	endbr64
    9fa4:	48 8b 3f             	mov    (%rdi),%rdi
    9fa7:	e9 c4 eb ff ff       	jmp    8b70 <f12>
    9fac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009fb0 <e12>:
    9fb0:	f3 0f 1e fa          	endbr64
    9fb4:	53                   	push   %rbx
    9fb5:	48 8b 1f             	mov    (%rdi),%rbx
    9fb8:	48 89 df             	mov    %rbx,%rdi
    9fbb:	e8 c0 cc ff ff       	call   6c80 <fwp_rc_share>
    9fc0:	48 89 df             	mov    %rbx,%rdi
    9fc3:	e8 a8 eb ff ff       	call   8b70 <f12>
    9fc8:	48 89 c3             	mov    %rax,%rbx
    9fcb:	48 89 c7             	mov    %rax,%rdi
    9fce:	e8 ad cc ff ff       	call   6c80 <fwp_rc_share>
    9fd3:	48 89 d8             	mov    %rbx,%rax
    9fd6:	5b                   	pop    %rbx
    9fd7:	c3                   	ret
    9fd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9fdf:	00 

0000000000009fe0 <fwp_write>:
    9fe0:	41 57                	push   %r15
    9fe2:	41 56                	push   %r14
    9fe4:	41 55                	push   %r13
    9fe6:	41 54                	push   %r12
    9fe8:	55                   	push   %rbp
    9fe9:	53                   	push   %rbx
    9fea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9ff1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9ff8:	00 00 
    9ffa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    a001:	00 
    a002:	49 89 d4             	mov    %rdx,%r12
    a005:	8b 12                	mov    (%rdx),%edx
    a007:	83 fa 19             	cmp    $0x19,%edx
    a00a:	77 6a                	ja     a076 <fwp_write+0x96>
    a00c:	48 89 f5             	mov    %rsi,%rbp
    a00f:	89 d0                	mov    %edx,%eax
    a011:	89 ce                	mov    %ecx,%esi
    a013:	48 89 fb             	mov    %rdi,%rbx
    a016:	48 8d 0d a3 6c 00 00 	lea    0x6ca3(%rip),%rcx        # 10cc0 <_IO_stdin_used+0xcc0>
    a01d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    a021:	48 01 c8             	add    %rcx,%rax
    a024:	3e ff e0             	notrack jmp *%rax
    a027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a02e:	00 00 
    a030:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    a034:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a038:	48 89 ca             	mov    %rcx,%rdx
    a03b:	48 85 c9             	test   %rcx,%rcx
    a03e:	0f 88 9c 0c 00 00    	js     ace0 <fwp_write+0xd00>
    a044:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a04b:	00 
    a04c:	48 89 c6             	mov    %rax,%rsi
    a04f:	4c 89 e7             	mov    %r12,%rdi
    a052:	e8 e9 99 ff ff       	call   3a40 <fwp_fmt_u128>
    a057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a05e:	00 00 
    a060:	4c 89 e7             	mov    %r12,%rdi
    a063:	e8 d8 93 ff ff       	call   3440 <strlen@plt>
    a068:	4c 89 e6             	mov    %r12,%rsi
    a06b:	48 89 df             	mov    %rbx,%rdi
    a06e:	48 89 c2             	mov    %rax,%rdx
    a071:	e8 7a a0 ff ff       	call   40f0 <buf_put>
    a076:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a07d:	00 
    a07e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a085:	00 00 
    a087:	0f 85 28 04 00 00    	jne    a4b5 <fwp_write+0x4d5>
    a08d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a094:	5b                   	pop    %rbx
    a095:	5d                   	pop    %rbp
    a096:	41 5c                	pop    %r12
    a098:	41 5d                	pop    %r13
    a09a:	41 5e                	pop    %r14
    a09c:	41 5f                	pop    %r15
    a09e:	c3                   	ret
    a09f:	90                   	nop
    a0a0:	49 89 e9             	mov    %rbp,%r9
    a0a3:	4c 8d 05 b1 61 00 00 	lea    0x61b1(%rip),%r8        # 1025b <_IO_stdin_used+0x25b>
    a0aa:	b9 00 02 00 00       	mov    $0x200,%ecx
    a0af:	ba 02 00 00 00       	mov    $0x2,%edx
    a0b4:	be 00 02 00 00       	mov    $0x200,%esi
    a0b9:	31 c0                	xor    %eax,%eax
    a0bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a0c2:	00 
    a0c3:	e8 d8 92 ff ff       	call   33a0 <__snprintf_chk@plt>
    a0c8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a0cf:	00 
    a0d0:	e8 6b 93 ff ff       	call   3440 <strlen@plt>
    a0d5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a0dc:	00 
    a0dd:	48 89 df             	mov    %rbx,%rdi
    a0e0:	48 89 c2             	mov    %rax,%rdx
    a0e3:	e8 08 a0 ff ff       	call   40f0 <buf_put>
    a0e8:	eb 8c                	jmp    a076 <fwp_write+0x96>
    a0ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a0f0:	49 89 e9             	mov    %rbp,%r9
    a0f3:	4c 8d 05 5c 61 00 00 	lea    0x615c(%rip),%r8        # 10256 <_IO_stdin_used+0x256>
    a0fa:	eb ae                	jmp    a0aa <fwp_write+0xca>
    a0fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a100:	83 fa 13             	cmp    $0x13,%edx
    a103:	48 8d 05 42 61 00 00 	lea    0x6142(%rip),%rax        # 1024c <_IO_stdin_used+0x24c>
    a10a:	48 8d 35 40 61 00 00 	lea    0x6140(%rip),%rsi        # 10251 <_IO_stdin_used+0x251>
    a111:	ba 04 00 00 00       	mov    $0x4,%edx
    a116:	48 0f 44 f0          	cmove  %rax,%rsi
    a11a:	45 31 ed             	xor    %r13d,%r13d
    a11d:	e8 ce 9f ff ff       	call   40f0 <buf_put>
    a122:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a127:	0f 84 a3 08 00 00    	je     a9d0 <fwp_write+0x9f0>
    a12d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a132:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a137:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a13c:	48 89 df             	mov    %rbx,%rdi
    a13f:	49 0f 44 c5          	cmove  %r13,%rax
    a143:	31 c9                	xor    %ecx,%ecx
    a145:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a14a:	e8 91 fe ff ff       	call   9fe0 <fwp_write>
    a14f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a154:	0f 84 6e 09 00 00    	je     aac8 <fwp_write+0xae8>
    a15a:	49 83 c5 01          	add    $0x1,%r13
    a15e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a162:	0f 83 68 08 00 00    	jae    a9d0 <fwp_write+0x9f0>
    a168:	ba 02 00 00 00       	mov    $0x2,%edx
    a16d:	48 8d 35 27 61 00 00 	lea    0x6127(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a174:	48 89 df             	mov    %rbx,%rdi
    a177:	e8 74 9f ff ff       	call   40f0 <buf_put>
    a17c:	eb af                	jmp    a12d <fwp_write+0x14d>
    a17e:	66 90                	xchg   %ax,%ax
    a180:	ba 06 00 00 00       	mov    $0x6,%edx
    a185:	48 8d 35 e8 60 00 00 	lea    0x60e8(%rip),%rsi        # 10274 <_IO_stdin_used+0x274>
    a18c:	48 83 c5 10          	add    $0x10,%rbp
    a190:	e8 5b 9f ff ff       	call   40f0 <buf_put>
    a195:	48 89 ef             	mov    %rbp,%rdi
    a198:	e8 a3 92 ff ff       	call   3440 <strlen@plt>
    a19d:	48 89 ee             	mov    %rbp,%rsi
    a1a0:	48 89 df             	mov    %rbx,%rdi
    a1a3:	48 89 c2             	mov    %rax,%rdx
    a1a6:	e8 45 9f ff ff       	call   40f0 <buf_put>
    a1ab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a1b5:	48 89 df             	mov    %rbx,%rdi
    a1b8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a1bd:	e8 2e 9f ff ff       	call   40f0 <buf_put>
    a1c2:	e9 af fe ff ff       	jmp    a076 <fwp_write+0x96>
    a1c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ce:	00 00 
    a1d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1d7:	00 
    a1d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1df:	00 00 
    a1e1:	0f 85 ce 02 00 00    	jne    a4b5 <fwp_write+0x4d5>
    a1e7:	ba 0a 00 00 00       	mov    $0xa,%edx
    a1ec:	48 8d 35 6d 60 00 00 	lea    0x606d(%rip),%rsi        # 10260 <_IO_stdin_used+0x260>
    a1f3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a1fa:	48 89 df             	mov    %rbx,%rdi
    a1fd:	5b                   	pop    %rbx
    a1fe:	5d                   	pop    %rbp
    a1ff:	41 5c                	pop    %r12
    a201:	41 5d                	pop    %r13
    a203:	41 5e                	pop    %r14
    a205:	41 5f                	pop    %r15
    a207:	e9 e4 9e ff ff       	jmp    40f0 <buf_put>
    a20c:	0f 1f 40 00          	nopl   0x0(%rax)
    a210:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a215:	4d 85 ed             	test   %r13,%r13
    a218:	0f 84 02 0c 00 00    	je     ae20 <fwp_write+0xe40>
    a21e:	48 8d 35 83 60 00 00 	lea    0x6083(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a225:	4c 89 ef             	mov    %r13,%rdi
    a228:	e8 f3 92 ff ff       	call   3520 <strcmp@plt>
    a22d:	41 89 c1             	mov    %eax,%r9d
    a230:	85 c0                	test   %eax,%eax
    a232:	0f 84 6c 0c 00 00    	je     aea4 <fwp_write+0xec4>
    a238:	4c 89 ef             	mov    %r13,%rdi
    a23b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a240:	e8 fb 91 ff ff       	call   3440 <strlen@plt>
    a245:	4c 89 ee             	mov    %r13,%rsi
    a248:	48 89 df             	mov    %rbx,%rdi
    a24b:	48 89 c2             	mov    %rax,%rdx
    a24e:	e8 9d 9e ff ff       	call   40f0 <buf_put>
    a253:	ba 01 00 00 00       	mov    $0x1,%edx
    a258:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a25d:	48 89 df             	mov    %rbx,%rdi
    a260:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a265:	e8 86 9e ff ff       	call   40f0 <buf_put>
    a26a:	ba 01 00 00 00       	mov    $0x1,%edx
    a26f:	4c 89 fe             	mov    %r15,%rsi
    a272:	48 89 df             	mov    %rbx,%rdi
    a275:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a27a:	e8 71 9e ff ff       	call   40f0 <buf_put>
    a27f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a284:	45 31 f6             	xor    %r14d,%r14d
    a287:	85 d2                	test   %edx,%edx
    a289:	0f 8e 81 0a 00 00    	jle    ad10 <fwp_write+0xd30>
    a28f:	45 31 ed             	xor    %r13d,%r13d
    a292:	4d 85 ed             	test   %r13,%r13
    a295:	0f 85 75 07 00 00    	jne    aa10 <fwp_write+0xa30>
    a29b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a2a2:	00 
    a2a3:	45 85 f6             	test   %r14d,%r14d
    a2a6:	0f 84 84 07 00 00    	je     aa30 <fwp_write+0xa50>
    a2ac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a2b1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a2b6:	48 89 df             	mov    %rbx,%rdi
    a2b9:	49 83 c5 01          	add    $0x1,%r13
    a2bd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a2c1:	31 c9                	xor    %ecx,%ecx
    a2c3:	e8 18 fd ff ff       	call   9fe0 <fwp_write>
    a2c8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a2cd:	7f c3                	jg     a292 <fwp_write+0x2b2>
    a2cf:	45 85 f6             	test   %r14d,%r14d
    a2d2:	0f 84 38 0a 00 00    	je     ad10 <fwp_write+0xd30>
    a2d8:	b8 29 00 00 00       	mov    $0x29,%eax
    a2dd:	ba 01 00 00 00       	mov    $0x1,%edx
    a2e2:	4c 89 fe             	mov    %r15,%rsi
    a2e5:	48 89 df             	mov    %rbx,%rdi
    a2e8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a2ec:	e8 ff 9d ff ff       	call   40f0 <buf_put>
    a2f1:	e9 80 fd ff ff       	jmp    a076 <fwp_write+0x96>
    a2f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2fd:	00 00 00 
    a300:	ba 01 00 00 00       	mov    $0x1,%edx
    a305:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a30a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a30f:	e8 dc 9d ff ff       	call   40f0 <buf_put>
    a314:	48 85 ed             	test   %rbp,%rbp
    a317:	0f 84 93 06 00 00    	je     a9b0 <fwp_write+0x9d0>
    a31d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a321:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a326:	31 c9                	xor    %ecx,%ecx
    a328:	48 89 df             	mov    %rbx,%rdi
    a32b:	e8 b0 fc ff ff       	call   9fe0 <fwp_write>
    a330:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a334:	48 85 ed             	test   %rbp,%rbp
    a337:	0f 84 73 06 00 00    	je     a9b0 <fwp_write+0x9d0>
    a33d:	ba 02 00 00 00       	mov    $0x2,%edx
    a342:	48 8d 35 52 5f 00 00 	lea    0x5f52(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a349:	48 89 df             	mov    %rbx,%rdi
    a34c:	e8 9f 9d ff ff       	call   40f0 <buf_put>
    a351:	eb ca                	jmp    a31d <fwp_write+0x33d>
    a353:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a358:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a35c:	85 f6                	test   %esi,%esi
    a35e:	0f 84 fc 07 00 00    	je     ab60 <fwp_write+0xb80>
    a364:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a36b:	00 
    a36c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a373:	00 00 
    a375:	0f 85 3a 01 00 00    	jne    a4b5 <fwp_write+0x4d5>
    a37b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a37f:	4c 89 ea             	mov    %r13,%rdx
    a382:	e9 6c fe ff ff       	jmp    a1f3 <fwp_write+0x213>
    a387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a38e:	00 00 
    a390:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a395:	ba 01 00 00 00       	mov    $0x1,%edx
    a39a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a39f:	48 89 ee             	mov    %rbp,%rsi
    a3a2:	e8 49 9d ff ff       	call   40f0 <buf_put>
    a3a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a3ac:	4c 89 e7             	mov    %r12,%rdi
    a3af:	e8 8c 90 ff ff       	call   3440 <strlen@plt>
    a3b4:	4c 89 e6             	mov    %r12,%rsi
    a3b7:	48 89 df             	mov    %rbx,%rdi
    a3ba:	48 89 c2             	mov    %rax,%rdx
    a3bd:	e8 2e 9d ff ff       	call   40f0 <buf_put>
    a3c2:	ba 01 00 00 00       	mov    $0x1,%edx
    a3c7:	48 89 ee             	mov    %rbp,%rsi
    a3ca:	48 89 df             	mov    %rbx,%rdi
    a3cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a3d2:	e8 19 9d ff ff       	call   40f0 <buf_put>
    a3d7:	e9 9a fc ff ff       	jmp    a076 <fwp_write+0x96>
    a3dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a3e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a3e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a3e9:	0f 8a 8e 0b 00 00    	jp     af7d <fwp_write+0xf9d>
    a3ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a3f3:	66 0f 54 05 c5 69 00 	andpd  0x69c5(%rip),%xmm0        # 10dc0 <msg.4+0x90>
    a3fa:	00 
    a3fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a400:	66 0f 2e 05 f0 69 00 	ucomisd 0x69f0(%rip),%xmm0        # 10df8 <msg.4+0xc8>
    a407:	00 
    a408:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a40f:	00 
    a410:	0f 87 b2 09 00 00    	ja     adc8 <fwp_write+0xde8>
    a416:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a41d:	00 00 00 
    a420:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a424:	89 ee                	mov    %ebp,%esi
    a426:	4c 89 e7             	mov    %r12,%rdi
    a429:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a42e:	e8 3d a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a433:	31 f6                	xor    %esi,%esi
    a435:	4c 89 e7             	mov    %r12,%rdi
    a438:	e8 c3 8f ff ff       	call   3400 <strtod@plt>
    a43d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a442:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a446:	7a 06                	jp     a44e <fwp_write+0x46e>
    a448:	0f 84 e9 01 00 00    	je     a637 <fwp_write+0x657>
    a44e:	83 c5 01             	add    $0x1,%ebp
    a451:	83 fd 12             	cmp    $0x12,%ebp
    a454:	75 ca                	jne    a420 <fwp_write+0x440>
    a456:	be 11 00 00 00       	mov    $0x11,%esi
    a45b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a45f:	4c 89 e7             	mov    %r12,%rdi
    a462:	e8 09 a3 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a467:	e9 cb 01 00 00       	jmp    a637 <fwp_write+0x657>
    a46c:	0f 1f 40 00          	nopl   0x0(%rax)
    a470:	48 83 fd 01          	cmp    $0x1,%rbp
    a474:	0f 84 e6 08 00 00    	je     ad60 <fwp_write+0xd80>
    a47a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a47e:	b8 02 00 00 00       	mov    $0x2,%eax
    a483:	ba 01 00 00 00       	mov    $0x1,%edx
    a488:	48 0f 44 d0          	cmove  %rax,%rdx
    a48c:	48 8d 35 b1 5d 00 00 	lea    0x5db1(%rip),%rsi        # 10244 <_IO_stdin_used+0x244>
    a493:	48 8d 05 af 5d 00 00 	lea    0x5daf(%rip),%rax        # 10249 <_IO_stdin_used+0x249>
    a49a:	48 0f 44 f0          	cmove  %rax,%rsi
    a49e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a4a5:	00 
    a4a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a4ad:	00 00 
    a4af:	0f 84 3e fd ff ff    	je     a1f3 <fwp_write+0x213>
    a4b5:	e8 96 8f ff ff       	call   3450 <__stack_chk_fail@plt>
    a4ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a4c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a4ca:	e8 61 9b ff ff       	call   4030 <buf_grow>
    a4cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a4d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a4d9:	4c 03 0b             	add    (%rbx),%r9
    a4dc:	66 45 89 11          	mov    %r10w,(%r9)
    a4e0:	45 85 e4             	test   %r12d,%r12d
    a4e3:	0f 8e 07 05 00 00    	jle    a9f0 <fwp_write+0xa10>
    a4e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a4f0:	55 55 55 
    a4f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a4f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a4ff:	aa aa aa 
    a502:	49 83 c1 01          	add    $0x1,%r9
    a506:	eb 45                	jmp    a54d <fwp_write+0x56d>
    a508:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a50f:	00 
    a510:	be 01 00 00 00       	mov    $0x1,%esi
    a515:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a51a:	88 07                	mov    %al,(%rdi)
    a51c:	48 89 e8             	mov    %rbp,%rax
    a51f:	49 f7 e8             	imul   %r8
    a522:	48 89 e8             	mov    %rbp,%rax
    a525:	48 c1 f8 3f          	sar    $0x3f,%rax
    a529:	48 29 c2             	sub    %rax,%rdx
    a52c:	48 85 c9             	test   %rcx,%rcx
    a52f:	0f 95 c0             	setne  %al
    a532:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a536:	48 83 ef 01          	sub    $0x1,%rdi
    a53a:	48 21 c5             	and    %rax,%rbp
    a53d:	48 29 ea             	sub    %rbp,%rdx
    a540:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a544:	49 39 f9             	cmp    %rdi,%r9
    a547:	0f 84 a3 04 00 00    	je     a9f0 <fwp_write+0xa10>
    a54d:	48 89 e8             	mov    %rbp,%rax
    a550:	49 f7 e8             	imul   %r8
    a553:	48 89 e8             	mov    %rbp,%rax
    a556:	48 c1 f8 3f          	sar    $0x3f,%rax
    a55a:	48 89 d1             	mov    %rdx,%rcx
    a55d:	48 29 c1             	sub    %rax,%rcx
    a560:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a564:	48 89 e9             	mov    %rbp,%rcx
    a567:	48 29 c1             	sub    %rax,%rcx
    a56a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a56e:	49 f7 e2             	mul    %r10
    a571:	b8 30 00 00 00       	mov    $0x30,%eax
    a576:	48 89 d6             	mov    %rdx,%rsi
    a579:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a57d:	48 d1 ee             	shr    $1,%rsi
    a580:	48 01 f2             	add    %rsi,%rdx
    a583:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a587:	48 29 d6             	sub    %rdx,%rsi
    a58a:	74 8e                	je     a51a <fwp_write+0x53a>
    a58c:	48 83 fe 01          	cmp    $0x1,%rsi
    a590:	0f 85 7a ff ff ff    	jne    a510 <fwp_write+0x530>
    a596:	31 f6                	xor    %esi,%esi
    a598:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a59d:	e9 78 ff ff ff       	jmp    a51a <fwp_write+0x53a>
    a5a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a5ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a5af:	0f 8a c8 09 00 00    	jp     af7d <fwp_write+0xf9d>
    a5b5:	0f 28 c1             	movaps %xmm1,%xmm0
    a5b8:	0f 54 05 f1 67 00 00 	andps  0x67f1(%rip),%xmm0        # 10db0 <msg.4+0x80>
    a5bf:	0f 2e 05 3e 5a 00 00 	ucomiss 0x5a3e(%rip),%xmm0        # 10004 <_IO_stdin_used+0x4>
    a5c6:	0f 87 24 08 00 00    	ja     adf0 <fwp_write+0xe10>
    a5cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a5d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a5d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a5dd:	00 
    a5de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a5e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a5e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a5ee:	00 00 
    a5f0:	44 89 ee             	mov    %r13d,%esi
    a5f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a5f8:	4c 89 e7             	mov    %r12,%rdi
    a5fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a600:	e8 6b a1 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a605:	31 f6                	xor    %esi,%esi
    a607:	4c 89 e7             	mov    %r12,%rdi
    a60a:	e8 91 8e ff ff       	call   34a0 <strtof@plt>
    a60f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a614:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a617:	7a 02                	jp     a61b <fwp_write+0x63b>
    a619:	74 1c                	je     a637 <fwp_write+0x657>
    a61b:	41 83 c5 01          	add    $0x1,%r13d
    a61f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a623:	75 cb                	jne    a5f0 <fwp_write+0x610>
    a625:	be 09 00 00 00       	mov    $0x9,%esi
    a62a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a62f:	4c 89 e7             	mov    %r12,%rdi
    a632:	e8 39 a1 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a637:	4c 89 e7             	mov    %r12,%rdi
    a63a:	e8 71 9b ff ff       	call   41b0 <fwp_finish_float>
    a63f:	e9 1c fa ff ff       	jmp    a060 <fwp_write+0x80>
    a644:	0f 1f 40 00          	nopl   0x0(%rax)
    a648:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a64c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a650:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a657:	00 
    a658:	48 89 ef             	mov    %rbp,%rdi
    a65b:	e8 e0 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a660:	48 89 ef             	mov    %rbp,%rdi
    a663:	e8 d8 8d ff ff       	call   3440 <strlen@plt>
    a668:	48 89 ee             	mov    %rbp,%rsi
    a66b:	48 89 df             	mov    %rbx,%rdi
    a66e:	48 89 c2             	mov    %rax,%rdx
    a671:	e8 7a 9a ff ff       	call   40f0 <buf_put>
    a676:	e9 fb f9 ff ff       	jmp    a076 <fwp_write+0x96>
    a67b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a680:	ba 06 00 00 00       	mov    $0x6,%edx
    a685:	48 8d 35 12 5c 00 00 	lea    0x5c12(%rip),%rsi        # 1029e <_IO_stdin_used+0x29e>
    a68c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a692:	e8 59 9a ff ff       	call   40f0 <buf_put>
    a697:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a69e:	ff ff 7f 
    a6a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a6a5:	0f 84 86 02 00 00    	je     a931 <fwp_write+0x951>
    a6ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a6b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a6b4:	48 85 d2             	test   %rdx,%rdx
    a6b7:	0f 84 ae 00 00 00    	je     a76b <fwp_write+0x78b>
    a6bd:	8b 0a                	mov    (%rdx),%ecx
    a6bf:	83 f9 1c             	cmp    $0x1c,%ecx
    a6c2:	0f 84 58 06 00 00    	je     ad20 <fwp_write+0xd40>
    a6c8:	83 f9 1b             	cmp    $0x1b,%ecx
    a6cb:	0f 87 9a 00 00 00    	ja     a76b <fwp_write+0x78b>
    a6d1:	be 01 00 00 00       	mov    $0x1,%esi
    a6d6:	48 d3 e6             	shl    %cl,%rsi
    a6d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a6df:	0f 85 4b 04 00 00    	jne    ab30 <fwp_write+0xb50>
    a6e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a6eb:	0f 85 0f 04 00 00    	jne    ab00 <fwp_write+0xb20>
    a6f1:	83 e6 21             	and    $0x21,%esi
    a6f4:	74 75                	je     a76b <fwp_write+0x78b>
    a6f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a6fb:	48 85 ff             	test   %rdi,%rdi
    a6fe:	79 07                	jns    a707 <fwp_write+0x727>
    a700:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a704:	4c 01 ee             	add    %r13,%rsi
    a707:	48 0f be 3e          	movsbq (%rsi),%rdi
    a70b:	85 c9                	test   %ecx,%ecx
    a70d:	40 0f b6 f7          	movzbl %dil,%esi
    a711:	48 0f 44 f7          	cmove  %rdi,%rsi
    a715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a71c:	00 00 00 00 
    a720:	31 c9                	xor    %ecx,%ecx
    a722:	48 89 df             	mov    %rbx,%rdi
    a725:	49 83 c5 01          	add    $0x1,%r13
    a729:	e8 b2 f8 ff ff       	call   9fe0 <fwp_write>
    a72e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a735:	ff ff 7f 
    a738:	48 23 55 00          	and    0x0(%rbp),%rdx
    a73c:	49 39 d5             	cmp    %rdx,%r13
    a73f:	0f 83 ec 01 00 00    	jae    a931 <fwp_write+0x951>
    a745:	ba 02 00 00 00       	mov    $0x2,%edx
    a74a:	48 89 df             	mov    %rbx,%rdi
    a74d:	48 8d 35 47 5b 00 00 	lea    0x5b47(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a754:	e8 97 99 ff ff       	call   40f0 <buf_put>
    a759:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a75e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a762:	48 85 d2             	test   %rdx,%rdx
    a765:	0f 85 52 ff ff ff    	jne    a6bd <fwp_write+0x6dd>
    a76b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a770:	48 85 ff             	test   %rdi,%rdi
    a773:	0f 88 cf 05 00 00    	js     ad48 <fwp_write+0xd68>
    a779:	48 8b 31             	mov    (%rcx),%rsi
    a77c:	eb a2                	jmp    a720 <fwp_write+0x740>
    a77e:	66 90                	xchg   %ax,%ax
    a780:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a787:	00 
    a788:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a78f:	00 00 
    a791:	0f 85 1e fd ff ff    	jne    a4b5 <fwp_write+0x4d5>
    a797:	ba 08 00 00 00       	mov    $0x8,%edx
    a79c:	48 8d 35 c8 5a 00 00 	lea    0x5ac8(%rip),%rsi        # 1026b <_IO_stdin_used+0x26b>
    a7a3:	e9 4b fa ff ff       	jmp    a1f3 <fwp_write+0x213>
    a7a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a7af:	00 
    a7b0:	89 e8                	mov    %ebp,%eax
    a7b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a7b9:	76 03                	jbe    a7be <fwp_write+0x7de>
    a7bb:	8b 45 00             	mov    0x0(%rbp),%eax
    a7be:	41 89 c6             	mov    %eax,%r14d
    a7c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a7c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a7cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a7cf:	4c 89 ef             	mov    %r13,%rdi
    a7d2:	e8 69 8c ff ff       	call   3440 <strlen@plt>
    a7d7:	4c 89 ee             	mov    %r13,%rsi
    a7da:	48 89 df             	mov    %rbx,%rdi
    a7dd:	48 89 c2             	mov    %rax,%rdx
    a7e0:	e8 0b 99 ff ff       	call   40f0 <buf_put>
    a7e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a7ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a7ee:	85 f6                	test   %esi,%esi
    a7f0:	0f 8e 80 f8 ff ff    	jle    a076 <fwp_write+0x96>
    a7f6:	45 31 ed             	xor    %r13d,%r13d
    a7f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a7fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a803:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a808:	ba 01 00 00 00       	mov    $0x1,%edx
    a80d:	4c 89 fe             	mov    %r15,%rsi
    a810:	48 89 04 24          	mov    %rax,(%rsp)
    a814:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a819:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a81d:	48 89 df             	mov    %rbx,%rdi
    a820:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a824:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a829:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a82e:	e8 bd 98 ff ff       	call   40f0 <buf_put>
    a833:	41 8b 06             	mov    (%r14),%eax
    a836:	83 f8 0e             	cmp    $0xe,%eax
    a839:	0f 84 71 02 00 00    	je     aab0 <fwp_write+0xad0>
    a83f:	83 f8 10             	cmp    $0x10,%eax
    a842:	0f 84 38 02 00 00    	je     aa80 <fwp_write+0xaa0>
    a848:	83 f8 0a             	cmp    $0xa,%eax
    a84b:	0f 84 7f 04 00 00    	je     acd0 <fwp_write+0xcf0>
    a851:	0f 8f f9 00 00 00    	jg     a950 <fwp_write+0x970>
    a857:	83 f8 03             	cmp    $0x3,%eax
    a85a:	0f 8f 50 04 00 00    	jg     acb0 <fwp_write+0xcd0>
    a860:	85 c0                	test   %eax,%eax
    a862:	78 10                	js     a874 <fwp_write+0x894>
    a864:	48 8b 04 24          	mov    (%rsp),%rax
    a868:	48 c1 e8 3f          	shr    $0x3f,%rax
    a86c:	85 c0                	test   %eax,%eax
    a86e:	0f 85 f9 00 00 00    	jne    a96d <fwp_write+0x98d>
    a874:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a879:	48 8b 34 24          	mov    (%rsp),%rsi
    a87d:	31 c9                	xor    %ecx,%ecx
    a87f:	48 89 df             	mov    %rbx,%rdi
    a882:	e8 59 f7 ff ff       	call   9fe0 <fwp_write>
    a887:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a88c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a891:	49 83 c5 01          	add    $0x1,%r13
    a895:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a899:	0f 8f 5f ff ff ff    	jg     a7fe <fwp_write+0x81e>
    a89f:	e9 d2 f7 ff ff       	jmp    a076 <fwp_write+0x96>
    a8a4:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a8:	ba 06 00 00 00       	mov    $0x6,%edx
    a8ad:	48 8d 35 dd 59 00 00 	lea    0x59dd(%rip),%rsi        # 10291 <_IO_stdin_used+0x291>
    a8b4:	45 31 ed             	xor    %r13d,%r13d
    a8b7:	e8 34 98 ff ff       	call   40f0 <buf_put>
    a8bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a8c1:	75 19                	jne    a8dc <fwp_write+0x8fc>
    a8c3:	eb 6c                	jmp    a931 <fwp_write+0x951>
    a8c5:	0f 1f 00             	nopl   (%rax)
    a8c8:	ba 02 00 00 00       	mov    $0x2,%edx
    a8cd:	48 8d 35 c7 59 00 00 	lea    0x59c7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a8d4:	48 89 df             	mov    %rbx,%rdi
    a8d7:	e8 14 98 ff ff       	call   40f0 <buf_put>
    a8dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a8e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a8e7:	31 c0                	xor    %eax,%eax
    a8e9:	49 83 c5 01          	add    $0x1,%r13
    a8ed:	4c 8d 05 a4 59 00 00 	lea    0x59a4(%rip),%r8        # 10298 <_IO_stdin_used+0x298>
    a8f4:	ba 02 00 00 00       	mov    $0x2,%edx
    a8f9:	be 00 02 00 00       	mov    $0x200,%esi
    a8fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a905:	00 
    a906:	e8 95 8a ff ff       	call   33a0 <__snprintf_chk@plt>
    a90b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a912:	00 
    a913:	e8 28 8b ff ff       	call   3440 <strlen@plt>
    a918:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a91f:	00 
    a920:	48 89 df             	mov    %rbx,%rdi
    a923:	48 89 c2             	mov    %rax,%rdx
    a926:	e8 c5 97 ff ff       	call   40f0 <buf_put>
    a92b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a92f:	72 97                	jb     a8c8 <fwp_write+0x8e8>
    a931:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a936:	ba 01 00 00 00       	mov    $0x1,%edx
    a93b:	48 89 df             	mov    %rbx,%rdi
    a93e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a943:	e8 a8 97 ff ff       	call   40f0 <buf_put>
    a948:	e9 29 f7 ff ff       	jmp    a076 <fwp_write+0x96>
    a94d:	0f 1f 00             	nopl   (%rax)
    a950:	83 f8 0b             	cmp    $0xb,%eax
    a953:	0f 85 1b ff ff ff    	jne    a874 <fwp_write+0x894>
    a959:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a95e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a962:	83 e0 01             	and    $0x1,%eax
    a965:	85 c0                	test   %eax,%eax
    a967:	0f 84 07 ff ff ff    	je     a874 <fwp_write+0x894>
    a96d:	4c 89 fe             	mov    %r15,%rsi
    a970:	48 89 df             	mov    %rbx,%rdi
    a973:	ba 01 00 00 00       	mov    $0x1,%edx
    a978:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a97d:	e8 6e 97 ff ff       	call   40f0 <buf_put>
    a982:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a987:	48 8b 34 24          	mov    (%rsp),%rsi
    a98b:	31 c9                	xor    %ecx,%ecx
    a98d:	48 89 df             	mov    %rbx,%rdi
    a990:	e8 4b f6 ff ff       	call   9fe0 <fwp_write>
    a995:	ba 01 00 00 00       	mov    $0x1,%edx
    a99a:	4c 89 fe             	mov    %r15,%rsi
    a99d:	48 89 df             	mov    %rbx,%rdi
    a9a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a9a5:	e8 46 97 ff ff       	call   40f0 <buf_put>
    a9aa:	e9 d8 fe ff ff       	jmp    a887 <fwp_write+0x8a7>
    a9af:	90                   	nop
    a9b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a9b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a9ba:	48 89 df             	mov    %rbx,%rdi
    a9bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a9c2:	e8 29 97 ff ff       	call   40f0 <buf_put>
    a9c7:	e9 aa f6 ff ff       	jmp    a076 <fwp_write+0x96>
    a9cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a9d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a9d5:	ba 01 00 00 00       	mov    $0x1,%edx
    a9da:	48 89 df             	mov    %rbx,%rdi
    a9dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a9e2:	e8 09 97 ff ff       	call   40f0 <buf_put>
    a9e7:	e9 8a f6 ff ff       	jmp    a076 <fwp_write+0x96>
    a9ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a9f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a9f4:	48 8b 13             	mov    (%rbx),%rdx
    a9f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a9fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    aa00:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    aa04:	e9 6d f6 ff ff       	jmp    a076 <fwp_write+0x96>
    aa09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa10:	ba 02 00 00 00       	mov    $0x2,%edx
    aa15:	48 8d 35 7f 58 00 00 	lea    0x587f(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    aa1c:	48 89 df             	mov    %rbx,%rdi
    aa1f:	e8 cc 96 ff ff       	call   40f0 <buf_put>
    aa24:	e9 72 f8 ff ff       	jmp    a29b <fwp_write+0x2bb>
    aa29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa30:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    aa35:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    aa3a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    aa3e:	48 89 f7             	mov    %rsi,%rdi
    aa41:	48 89 34 24          	mov    %rsi,(%rsp)
    aa45:	e8 f6 89 ff ff       	call   3440 <strlen@plt>
    aa4a:	48 8b 34 24          	mov    (%rsp),%rsi
    aa4e:	48 89 df             	mov    %rbx,%rdi
    aa51:	48 89 c2             	mov    %rax,%rdx
    aa54:	e8 97 96 ff ff       	call   40f0 <buf_put>
    aa59:	ba 03 00 00 00       	mov    $0x3,%edx
    aa5e:	48 8d 35 59 58 00 00 	lea    0x5859(%rip),%rsi        # 102be <_IO_stdin_used+0x2be>
    aa65:	48 89 df             	mov    %rbx,%rdi
    aa68:	e8 83 96 ff ff       	call   40f0 <buf_put>
    aa6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    aa72:	e9 35 f8 ff ff       	jmp    a2ac <fwp_write+0x2cc>
    aa77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aa7e:	00 00 
    aa80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    aa85:	48 8b 78 08          	mov    0x8(%rax),%rdi
    aa89:	48 85 ff             	test   %rdi,%rdi
    aa8c:	0f 84 e2 fd ff ff    	je     a874 <fwp_write+0x894>
    aa92:	48 8d 35 0f 58 00 00 	lea    0x580f(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    aa99:	e8 82 8a ff ff       	call   3520 <strcmp@plt>
    aa9e:	85 c0                	test   %eax,%eax
    aaa0:	0f 95 c0             	setne  %al
    aaa3:	0f b6 c0             	movzbl %al,%eax
    aaa6:	e9 c1 fd ff ff       	jmp    a86c <fwp_write+0x88c>
    aaab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aab0:	31 c0                	xor    %eax,%eax
    aab2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    aab9:	00 
    aaba:	0f 97 c0             	seta   %al
    aabd:	e9 aa fd ff ff       	jmp    a86c <fwp_write+0x88c>
    aac2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aac8:	48 89 df             	mov    %rbx,%rdi
    aacb:	ba 02 00 00 00       	mov    $0x2,%edx
    aad0:	48 8d 35 ce 57 00 00 	lea    0x57ce(%rip),%rsi        # 102a5 <_IO_stdin_used+0x2a5>
    aad7:	e8 14 96 ff ff       	call   40f0 <buf_put>
    aadc:	4c 89 e8             	mov    %r13,%rax
    aadf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    aae4:	31 c9                	xor    %ecx,%ecx
    aae6:	48 c1 e0 04          	shl    $0x4,%rax
    aaea:	48 89 df             	mov    %rbx,%rdi
    aaed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    aaf2:	e8 e9 f4 ff ff       	call   9fe0 <fwp_write>
    aaf7:	e9 5e f6 ff ff       	jmp    a15a <fwp_write+0x17a>
    aafc:	0f 1f 40 00          	nopl   0x0(%rax)
    ab00:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    ab05:	48 85 ff             	test   %rdi,%rdi
    ab08:	79 0c                	jns    ab16 <fwp_write+0xb36>
    ab0a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    ab11:	00 
    ab12:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab16:	48 63 3e             	movslq (%rsi),%rdi
    ab19:	83 f9 02             	cmp    $0x2,%ecx
    ab1c:	89 fe                	mov    %edi,%esi
    ab1e:	48 0f 44 f7          	cmove  %rdi,%rsi
    ab22:	e9 f9 fb ff ff       	jmp    a720 <fwp_write+0x740>
    ab27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab2e:	00 00 
    ab30:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    ab35:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    ab3a:	48 85 ff             	test   %rdi,%rdi
    ab3d:	0f 88 0f 03 00 00    	js     ae52 <fwp_write+0xe72>
    ab43:	49 0f bf 38          	movswq (%r8),%rdi
    ab47:	83 f9 01             	cmp    $0x1,%ecx
    ab4a:	0f b7 f7             	movzwl %di,%esi
    ab4d:	48 0f 44 f7          	cmove  %rdi,%rsi
    ab51:	e9 ca fb ff ff       	jmp    a720 <fwp_write+0x740>
    ab56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ab5d:	00 00 00 
    ab60:	ba 01 00 00 00       	mov    $0x1,%edx
    ab65:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab6a:	48 83 c5 08          	add    $0x8,%rbp
    ab6e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ab73:	e8 78 95 ff ff       	call   40f0 <buf_put>
    ab78:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab7d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    ab82:	4d 85 ed             	test   %r13,%r13
    ab85:	75 46                	jne    abcd <fwp_write+0xbed>
    ab87:	e9 04 01 00 00       	jmp    ac90 <fwp_write+0xcb0>
    ab8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab90:	41 80 f9 09          	cmp    $0x9,%r9b
    ab94:	0f 84 d6 00 00 00    	je     ac70 <fwp_write+0xc90>
    ab9a:	41 80 f9 0a          	cmp    $0xa,%r9b
    ab9e:	0f 85 9c 00 00 00    	jne    ac40 <fwp_write+0xc60>
    aba4:	ba 02 00 00 00       	mov    $0x2,%edx
    aba9:	48 8d 35 d1 56 00 00 	lea    0x56d1(%rip),%rsi        # 10281 <_IO_stdin_used+0x281>
    abb0:	48 89 df             	mov    %rbx,%rdi
    abb3:	e8 38 95 ff ff       	call   40f0 <buf_put>
    abb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    abbf:	00 
    abc0:	48 83 c5 01          	add    $0x1,%rbp
    abc4:	49 39 ec             	cmp    %rbp,%r12
    abc7:	0f 84 c3 00 00 00    	je     ac90 <fwp_write+0xcb0>
    abcd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    abd2:	41 80 f9 0d          	cmp    $0xd,%r9b
    abd6:	74 28                	je     ac00 <fwp_write+0xc20>
    abd8:	7e b6                	jle    ab90 <fwp_write+0xbb0>
    abda:	41 80 f9 22          	cmp    $0x22,%r9b
    abde:	74 40                	je     ac20 <fwp_write+0xc40>
    abe0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    abe4:	75 5a                	jne    ac40 <fwp_write+0xc60>
    abe6:	ba 02 00 00 00       	mov    $0x2,%edx
    abeb:	48 8d 35 8c 56 00 00 	lea    0x568c(%rip),%rsi        # 1027e <_IO_stdin_used+0x27e>
    abf2:	48 89 df             	mov    %rbx,%rdi
    abf5:	e8 f6 94 ff ff       	call   40f0 <buf_put>
    abfa:	eb c4                	jmp    abc0 <fwp_write+0xbe0>
    abfc:	0f 1f 40 00          	nopl   0x0(%rax)
    ac00:	ba 02 00 00 00       	mov    $0x2,%edx
    ac05:	48 8d 35 7b 56 00 00 	lea    0x567b(%rip),%rsi        # 10287 <_IO_stdin_used+0x287>
    ac0c:	48 89 df             	mov    %rbx,%rdi
    ac0f:	e8 dc 94 ff ff       	call   40f0 <buf_put>
    ac14:	eb aa                	jmp    abc0 <fwp_write+0xbe0>
    ac16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ac1d:	00 00 00 
    ac20:	ba 02 00 00 00       	mov    $0x2,%edx
    ac25:	48 8d 35 4f 56 00 00 	lea    0x564f(%rip),%rsi        # 1027b <_IO_stdin_used+0x27b>
    ac2c:	48 89 df             	mov    %rbx,%rdi
    ac2f:	e8 bc 94 ff ff       	call   40f0 <buf_put>
    ac34:	eb 8a                	jmp    abc0 <fwp_write+0xbe0>
    ac36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ac3d:	00 00 00 
    ac40:	41 80 f9 1f          	cmp    $0x1f,%r9b
    ac44:	0f 86 2e 01 00 00    	jbe    ad78 <fwp_write+0xd98>
    ac4a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    ac4e:	0f 84 24 01 00 00    	je     ad78 <fwp_write+0xd98>
    ac54:	ba 01 00 00 00       	mov    $0x1,%edx
    ac59:	4c 89 fe             	mov    %r15,%rsi
    ac5c:	48 89 df             	mov    %rbx,%rdi
    ac5f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    ac64:	e8 87 94 ff ff       	call   40f0 <buf_put>
    ac69:	e9 52 ff ff ff       	jmp    abc0 <fwp_write+0xbe0>
    ac6e:	66 90                	xchg   %ax,%ax
    ac70:	ba 02 00 00 00       	mov    $0x2,%edx
    ac75:	48 8d 35 08 56 00 00 	lea    0x5608(%rip),%rsi        # 10284 <_IO_stdin_used+0x284>
    ac7c:	48 89 df             	mov    %rbx,%rdi
    ac7f:	e8 6c 94 ff ff       	call   40f0 <buf_put>
    ac84:	e9 37 ff ff ff       	jmp    abc0 <fwp_write+0xbe0>
    ac89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac90:	ba 01 00 00 00       	mov    $0x1,%edx
    ac95:	4c 89 fe             	mov    %r15,%rsi
    ac98:	48 89 df             	mov    %rbx,%rdi
    ac9b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aca0:	e8 4b 94 ff ff       	call   40f0 <buf_put>
    aca5:	e9 cc f3 ff ff       	jmp    a076 <fwp_write+0x96>
    acaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    acb0:	83 f8 04             	cmp    $0x4,%eax
    acb3:	0f 85 bb fb ff ff    	jne    a874 <fwp_write+0x894>
    acb9:	48 8b 04 24          	mov    (%rsp),%rax
    acbd:	48 8b 40 08          	mov    0x8(%rax),%rax
    acc1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    acc6:	48 c1 e8 3f          	shr    $0x3f,%rax
    acca:	e9 96 fc ff ff       	jmp    a965 <fwp_write+0x985>
    accf:	90                   	nop
    acd0:	8b 0c 24             	mov    (%rsp),%ecx
    acd3:	31 c0                	xor    %eax,%eax
    acd5:	85 c9                	test   %ecx,%ecx
    acd7:	0f 98 c0             	sets   %al
    acda:	e9 86 fc ff ff       	jmp    a965 <fwp_write+0x985>
    acdf:	90                   	nop
    ace0:	48 f7 d8             	neg    %rax
    ace3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    acea:	00 
    aceb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    acf2:	2d 
    acf3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acfa:	00 
    acfb:	48 83 d2 00          	adc    $0x0,%rdx
    acff:	48 89 c6             	mov    %rax,%rsi
    ad02:	48 f7 da             	neg    %rdx
    ad05:	e8 36 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad0a:	e9 51 f3 ff ff       	jmp    a060 <fwp_write+0x80>
    ad0f:	90                   	nop
    ad10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    ad15:	e9 c3 f5 ff ff       	jmp    a2dd <fwp_write+0x2fd>
    ad1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad20:	4c 89 e9             	mov    %r13,%rcx
    ad23:	48 c1 e1 04          	shl    $0x4,%rcx
    ad27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    ad2c:	48 85 ff             	test   %rdi,%rdi
    ad2f:	0f 89 eb f9 ff ff    	jns    a720 <fwp_write+0x740>
    ad35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ad39:	48 89 ce             	mov    %rcx,%rsi
    ad3c:	e9 df f9 ff ff       	jmp    a720 <fwp_write+0x740>
    ad41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    ad4f:	00 
    ad50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ad54:	e9 20 fa ff ff       	jmp    a779 <fwp_write+0x799>
    ad59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad60:	ba 02 00 00 00       	mov    $0x2,%edx
    ad65:	48 8d 35 da 54 00 00 	lea    0x54da(%rip),%rsi        # 10246 <_IO_stdin_used+0x246>
    ad6c:	e9 2d f7 ff ff       	jmp    a49e <fwp_write+0x4be>
    ad71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad78:	4c 8d 05 0b 55 00 00 	lea    0x550b(%rip),%r8        # 1028a <_IO_stdin_used+0x28a>
    ad7f:	b9 10 00 00 00       	mov    $0x10,%ecx
    ad84:	31 c0                	xor    %eax,%eax
    ad86:	ba 02 00 00 00       	mov    $0x2,%edx
    ad8b:	be 10 00 00 00       	mov    $0x10,%esi
    ad90:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ad97:	00 
    ad98:	e8 03 86 ff ff       	call   33a0 <__snprintf_chk@plt>
    ad9d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ada4:	00 
    ada5:	e8 96 86 ff ff       	call   3440 <strlen@plt>
    adaa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    adb1:	00 
    adb2:	48 89 df             	mov    %rbx,%rdi
    adb5:	48 89 c2             	mov    %rax,%rdx
    adb8:	e8 33 93 ff ff       	call   40f0 <buf_put>
    adbd:	e9 fe fd ff ff       	jmp    abc0 <fwp_write+0xbe0>
    adc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    adc8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    adcc:	48 8d 35 6d 54 00 00 	lea    0x546d(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    add3:	48 8d 05 65 54 00 00 	lea    0x5465(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    adda:	4c 89 e7             	mov    %r12,%rdi
    addd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ade1:	48 0f 46 f0          	cmovbe %rax,%rsi
    ade5:	e8 f6 85 ff ff       	call   33e0 <strcpy@plt>
    adea:	e9 71 f2 ff ff       	jmp    a060 <fwp_write+0x80>
    adef:	90                   	nop
    adf0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    adf4:	48 8d 35 45 54 00 00 	lea    0x5445(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    adfb:	48 8d 05 3d 54 00 00 	lea    0x543d(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    ae02:	0f 2f c8             	comiss %xmm0,%xmm1
    ae05:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae0c:	00 
    ae0d:	4c 89 e7             	mov    %r12,%rdi
    ae10:	48 0f 46 f0          	cmovbe %rax,%rsi
    ae14:	e8 c7 85 ff ff       	call   33e0 <strcpy@plt>
    ae19:	e9 42 f2 ff ff       	jmp    a060 <fwp_write+0x80>
    ae1e:	66 90                	xchg   %ax,%ax
    ae20:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ae25:	45 85 c0             	test   %r8d,%r8d
    ae28:	75 34                	jne    ae5e <fwp_write+0xe7e>
    ae2a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ae31:	00 
    ae32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ae39:	00 00 
    ae3b:	0f 85 74 f6 ff ff    	jne    a4b5 <fwp_write+0x4d5>
    ae41:	ba 02 00 00 00       	mov    $0x2,%edx
    ae46:	48 8d 35 6e 54 00 00 	lea    0x546e(%rip),%rsi        # 102bb <_IO_stdin_used+0x2bb>
    ae4d:	e9 a1 f3 ff ff       	jmp    a1f3 <fwp_write+0x213>
    ae52:	48 03 75 10          	add    0x10(%rbp),%rsi
    ae56:	49 89 f0             	mov    %rsi,%r8
    ae59:	e9 e5 fc ff ff       	jmp    ab43 <fwp_write+0xb63>
    ae5e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ae63:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ae68:	85 ff                	test   %edi,%edi
    ae6a:	0f 84 fa f3 ff ff    	je     a26a <fwp_write+0x28a>
    ae70:	ba 01 00 00 00       	mov    $0x1,%edx
    ae75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ae7a:	48 89 df             	mov    %rbx,%rdi
    ae7d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ae82:	e8 69 92 ff ff       	call   40f0 <buf_put>
    ae87:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ae8c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ae91:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ae97:	85 c0                	test   %eax,%eax
    ae99:	0f 8f f0 f3 ff ff    	jg     a28f <fwp_write+0x2af>
    ae9f:	e9 34 f4 ff ff       	jmp    a2d8 <fwp_write+0x2f8>
    aea4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aea8:	49 89 c5             	mov    %rax,%r13
    aeab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    aeb0:	49 89 c4             	mov    %rax,%r12
    aeb3:	49 c1 fd 3f          	sar    $0x3f,%r13
    aeb7:	4c 09 e8             	or     %r13,%rax
    aeba:	0f 84 a7 00 00 00    	je     af67 <fwp_write+0xf87>
    aec0:	48 8d 2d 59 75 00 00 	lea    0x7559(%rip),%rbp        # 12420 <units.1>
    aec7:	4d 89 e7             	mov    %r12,%r15
    aeca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aece:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    aed3:	4c 89 ff             	mov    %r15,%rdi
    aed6:	4c 89 ee             	mov    %r13,%rsi
    aed9:	44 89 0c 24          	mov    %r9d,(%rsp)
    aedd:	48 99                	cqto
    aedf:	48 89 d1             	mov    %rdx,%rcx
    aee2:	48 89 c2             	mov    %rax,%rdx
    aee5:	e8 16 44 00 00       	call   f300 <__divmodti4>
    aeea:	44 8b 0c 24          	mov    (%rsp),%r9d
    aeee:	48 89 c1             	mov    %rax,%rcx
    aef1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    aef6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    aefb:	0f 84 94 00 00 00    	je     af95 <fwp_write+0xfb5>
    af01:	41 83 c1 01          	add    $0x1,%r9d
    af05:	48 83 c5 10          	add    $0x10,%rbp
    af09:	41 83 f9 05          	cmp    $0x5,%r9d
    af0d:	75 bb                	jne    aeca <fwp_write+0xeea>
    af0f:	4d 85 ed             	test   %r13,%r13
    af12:	79 53                	jns    af67 <fwp_write+0xf87>
    af14:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    af19:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    af1e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    af23:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    af28:	48 99                	cqto
    af2a:	48 f7 d8             	neg    %rax
    af2d:	48 83 d2 00          	adc    $0x0,%rdx
    af31:	48 89 c6             	mov    %rax,%rsi
    af34:	48 f7 da             	neg    %rdx
    af37:	e8 04 8b ff ff       	call   3a40 <fwp_fmt_u128>
    af3c:	49 89 e8             	mov    %rbp,%r8
    af3f:	ba 00 02 00 00       	mov    $0x200,%edx
    af44:	be 02 00 00 00       	mov    $0x2,%esi
    af49:	31 c0                	xor    %eax,%eax
    af4b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af52:	00 
    af53:	48 8d 0d 5c 53 00 00 	lea    0x535c(%rip),%rcx        # 102b6 <_IO_stdin_used+0x2b6>
    af5a:	4c 89 e7             	mov    %r12,%rdi
    af5d:	e8 5e 87 ff ff       	call   36c0 <__sprintf_chk@plt>
    af62:	e9 f9 f0 ff ff       	jmp    a060 <fwp_write+0x80>
    af67:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    af6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    af71:	31 d2                	xor    %edx,%edx
    af73:	48 89 ef             	mov    %rbp,%rdi
    af76:	e8 c5 8a ff ff       	call   3a40 <fwp_fmt_u128>
    af7b:	eb bf                	jmp    af3c <fwp_write+0xf5c>
    af7d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    af84:	4e 61 4e 00 
    af88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af8f:	00 
    af90:	e9 cb f0 ff ff       	jmp    a060 <fwp_write+0x80>
    af95:	44 89 0c 24          	mov    %r9d,(%rsp)
    af99:	48 89 c8             	mov    %rcx,%rax
    af9c:	48 85 d2             	test   %rdx,%rdx
    af9f:	78 51                	js     aff2 <fwp_write+0x1012>
    afa1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    afa6:	48 89 c6             	mov    %rax,%rsi
    afa9:	48 89 ef             	mov    %rbp,%rdi
    afac:	e8 8f 8a ff ff       	call   3a40 <fwp_fmt_u128>
    afb1:	44 8b 0c 24          	mov    (%rsp),%r9d
    afb5:	49 63 c1             	movslq %r9d,%rax
    afb8:	49 89 e8             	mov    %rbp,%r8
    afbb:	ba 00 02 00 00       	mov    $0x200,%edx
    afc0:	be 02 00 00 00       	mov    $0x2,%esi
    afc5:	48 c1 e0 04          	shl    $0x4,%rax
    afc9:	48 8d 3d 50 74 00 00 	lea    0x7450(%rip),%rdi        # 12420 <units.1>
    afd0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    afd7:	00 
    afd8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    afdc:	48 8d 0d ce 52 00 00 	lea    0x52ce(%rip),%rcx        # 102b1 <_IO_stdin_used+0x2b1>
    afe3:	4c 89 e7             	mov    %r12,%rdi
    afe6:	31 c0                	xor    %eax,%eax
    afe8:	e8 d3 86 ff ff       	call   36c0 <__sprintf_chk@plt>
    afed:	e9 6e f0 ff ff       	jmp    a060 <fwp_write+0x80>
    aff2:	48 f7 d8             	neg    %rax
    aff5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    affa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    afff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b004:	48 83 d2 00          	adc    $0x0,%rdx
    b008:	48 89 c6             	mov    %rax,%rsi
    b00b:	48 f7 da             	neg    %rdx
    b00e:	e8 2d 8a ff ff       	call   3a40 <fwp_fmt_u128>
    b013:	44 8b 0c 24          	mov    (%rsp),%r9d
    b017:	eb 9c                	jmp    afb5 <fwp_write+0xfd5>
    b019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000b020 <fwp_hof0.constprop.0>:
    b020:	55                   	push   %rbp
    b021:	48 89 e5             	mov    %rsp,%rbp
    b024:	41 57                	push   %r15
    b026:	41 56                	push   %r14
    b028:	41 55                	push   %r13
    b02a:	41 54                	push   %r12
    b02c:	53                   	push   %rbx
    b02d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    b034:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    b03b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b042:	00 00 
    b044:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b048:	31 c0                	xor    %eax,%eax
    b04a:	48 85 f6             	test   %rsi,%rsi
    b04d:	0f 84 cc 06 00 00    	je     b71f <fwp_hof0.constprop.0+0x6ff>
    b053:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    b057:	49 89 f7             	mov    %rsi,%r15
    b05a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    b061:	48 8d 35 d8 17 06 00 	lea    0x617d8(%rip),%rsi        # 6c840 <fwp_heap>
    b068:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    b06f:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b076:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b07d:	48 89 fa             	mov    %rdi,%rdx
    b080:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b084:	48 c1 e2 10          	shl    $0x10,%rdx
    b088:	48 39 d0             	cmp    %rdx,%rax
    b08b:	73 6b                	jae    b0f8 <fwp_hof0.constprop.0+0xd8>
    b08d:	48 89 c2             	mov    %rax,%rdx
    b090:	48 c1 ea 10          	shr    $0x10,%rdx
    b094:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b098:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b09f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0a3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b0a7:	48 85 ff             	test   %rdi,%rdi
    b0aa:	74 4c                	je     b0f8 <fwp_hof0.constprop.0+0xd8>
    b0ac:	0f b6 0a             	movzbl (%rdx),%ecx
    b0af:	80 f9 02             	cmp    $0x2,%cl
    b0b2:	0f 84 11 0c 00 00    	je     bcc9 <fwp_hof0.constprop.0+0xca9>
    b0b8:	80 f9 01             	cmp    $0x1,%cl
    b0bb:	75 3b                	jne    b0f8 <fwp_hof0.constprop.0+0xd8>
    b0bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0c0:	0f b7 c0             	movzwl %ax,%eax
    b0c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0c6:	48 0f af c1          	imul   %rcx,%rax
    b0ca:	48 c1 e8 20          	shr    $0x20,%rax
    b0ce:	48 39 d0             	cmp    %rdx,%rax
    b0d1:	73 25                	jae    b0f8 <fwp_hof0.constprop.0+0xd8>
    b0d3:	48 01 c7             	add    %rax,%rdi
    b0d6:	0f b6 07             	movzbl (%rdi),%eax
    b0d9:	84 c0                	test   %al,%al
    b0db:	74 1b                	je     b0f8 <fwp_hof0.constprop.0+0xd8>
    b0dd:	8b 35 25 34 06 00    	mov    0x63425(%rip),%esi        # 6e508 <iteration_active>
    b0e3:	85 f6                	test   %esi,%esi
    b0e5:	0f 85 ec 0b 00 00    	jne    bcd7 <fwp_hof0.constprop.0+0xcb7>
    b0eb:	3c fd                	cmp    $0xfd,%al
    b0ed:	0f 87 cd 0c 00 00    	ja     bdc0 <fwp_hof0.constprop.0+0xda0>
    b0f3:	83 c0 01             	add    $0x1,%eax
    b0f6:	88 07                	mov    %al,(%rdi)
    b0f8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    b0ff:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    b106:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    b10d:	c7 00 00 00 
    b111:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b115:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b119:	48 8b 15 78 33 06 00 	mov    0x63378(%rip),%rdx        # 6e498 <fwp_fns>
    b120:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    b124:	48 8d 05 ed 8e 00 00 	lea    0x8eed(%rip),%rax        # 14018 <fc12>
    b12b:	44 8b 20             	mov    (%rax),%r12d
    b12e:	49 c1 e4 05          	shl    $0x5,%r12
    b132:	49 01 d4             	add    %rdx,%r12
    b135:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    b13a:	48 85 c9             	test   %rcx,%rcx
    b13d:	0f 84 53 0b 00 00    	je     bc96 <fwp_hof0.constprop.0+0xc76>
    b143:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b148:	0f 84 2a 09 00 00    	je     ba78 <fwp_hof0.constprop.0+0xa58>
    b14e:	48 8d 1d eb 16 06 00 	lea    0x616eb(%rip),%rbx        # 6c840 <fwp_heap>
    b155:	48 8d 05 bc 8e 00 00 	lea    0x8ebc(%rip),%rax        # 14018 <fc12>
    b15c:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    b163:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b16a:	48 89 f1             	mov    %rsi,%rcx
    b16d:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    b171:	48 c1 e1 10          	shl    $0x10,%rcx
    b175:	48 39 c8             	cmp    %rcx,%rax
    b178:	73 71                	jae    b1eb <fwp_hof0.constprop.0+0x1cb>
    b17a:	48 89 c1             	mov    %rax,%rcx
    b17d:	48 c1 e9 10          	shr    $0x10,%rcx
    b181:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b185:	48 8b 8b f8 13 00 00 	mov    0x13f8(%rbx),%rcx
    b18c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b190:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b194:	48 85 ff             	test   %rdi,%rdi
    b197:	74 52                	je     b1eb <fwp_hof0.constprop.0+0x1cb>
    b199:	0f b6 31             	movzbl (%rcx),%esi
    b19c:	40 80 fe 02          	cmp    $0x2,%sil
    b1a0:	0f 84 ed 09 00 00    	je     bb93 <fwp_hof0.constprop.0+0xb73>
    b1a6:	40 80 fe 01          	cmp    $0x1,%sil
    b1aa:	75 3f                	jne    b1eb <fwp_hof0.constprop.0+0x1cb>
    b1ac:	8b 71 18             	mov    0x18(%rcx),%esi
    b1af:	0f b7 c0             	movzwl %ax,%eax
    b1b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b1b5:	48 0f af c6          	imul   %rsi,%rax
    b1b9:	48 c1 e8 20          	shr    $0x20,%rax
    b1bd:	48 39 c8             	cmp    %rcx,%rax
    b1c0:	73 29                	jae    b1eb <fwp_hof0.constprop.0+0x1cb>
    b1c2:	48 01 c7             	add    %rax,%rdi
    b1c5:	0f b6 07             	movzbl (%rdi),%eax
    b1c8:	84 c0                	test   %al,%al
    b1ca:	74 1f                	je     b1eb <fwp_hof0.constprop.0+0x1cb>
    b1cc:	8b 0d 36 33 06 00    	mov    0x63336(%rip),%ecx        # 6e508 <iteration_active>
    b1d2:	85 c9                	test   %ecx,%ecx
    b1d4:	74 08                	je     b1de <fwp_hof0.constprop.0+0x1be>
    b1d6:	48 83 05 12 33 06 00 	addq   $0x1,0x63312(%rip)        # 6e4f0 <iteration_retains>
    b1dd:	01 
    b1de:	3c fd                	cmp    $0xfd,%al
    b1e0:	0f 87 8a 0a 00 00    	ja     bc70 <fwp_hof0.constprop.0+0xc50>
    b1e6:	83 c0 01             	add    $0x1,%eax
    b1e9:	88 07                	mov    %al,(%rdi)
    b1eb:	48 8d 05 26 8e 00 00 	lea    0x8e26(%rip),%rax        # 14018 <fc12>
    b1f2:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b1f9:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b1fd:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b204:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b208:	48 8d 05 09 8e 00 00 	lea    0x8e09(%rip),%rax        # 14018 <fc12>
    b20f:	41 8b 0c 24          	mov    (%r12),%ecx
    b213:	2b 48 04             	sub    0x4(%rax),%ecx
    b216:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b21a:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    b21e:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    b221:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b225:	49 89 c1             	mov    %rax,%r9
    b228:	8b 00                	mov    (%rax),%eax
    b22a:	44 39 e9             	cmp    %r13d,%ecx
    b22d:	44 0f 46 e9          	cmovbe %ecx,%r13d
    b231:	4c 89 cb             	mov    %r9,%rbx
    b234:	48 c1 e0 05          	shl    $0x5,%rax
    b238:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b23c:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    b243:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b247:	4d 85 d2             	test   %r10,%r10
    b24a:	75 5c                	jne    b2a8 <fwp_hof0.constprop.0+0x288>
    b24c:	e9 12 02 00 00       	jmp    b463 <fwp_hof0.constprop.0+0x443>
    b251:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b258:	85 db                	test   %ebx,%ebx
    b25a:	74 6a                	je     b2c6 <fwp_hof0.constprop.0+0x2a6>
    b25c:	4c 89 e7             	mov    %r12,%rdi
    b25f:	41 ff 12             	call   *(%r10)
    b262:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b266:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    b26a:	e8 61 c1 ff ff       	call   73d0 <fwp_closure_drop>
    b26f:	45 39 ee             	cmp    %r13d,%r14d
    b272:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    b276:	0f 84 ec 07 00 00    	je     ba68 <fwp_hof0.constprop.0+0xa48>
    b27c:	44 8b 00             	mov    (%rax),%r8d
    b27f:	41 29 df             	sub    %ebx,%r15d
    b282:	4f 8d 24 f4          	lea    (%r12,%r14,8),%r12
    b286:	49 89 c1             	mov    %rax,%r9
    b289:	45 89 fd             	mov    %r15d,%r13d
    b28c:	49 c1 e0 05          	shl    $0x5,%r8
    b290:	4c 03 05 01 32 06 00 	add    0x63201(%rip),%r8        # 6e498 <fwp_fns>
    b297:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b29b:	4d 85 d2             	test   %r10,%r10
    b29e:	0f 84 bc 01 00 00    	je     b460 <fwp_hof0.constprop.0+0x440>
    b2a4:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2a8:	41 8b 49 04          	mov    0x4(%r9),%ecx
    b2ac:	41 8b 18             	mov    (%r8),%ebx
    b2af:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
    b2b3:	41 39 df             	cmp    %ebx,%r15d
    b2b6:	0f 82 8c 04 00 00    	jb     b748 <fwp_hof0.constprop.0+0x728>
    b2bc:	41 89 de             	mov    %ebx,%r14d
    b2bf:	41 29 ce             	sub    %ecx,%r14d
    b2c2:	85 c9                	test   %ecx,%ecx
    b2c4:	74 92                	je     b258 <fwp_hof0.constprop.0+0x238>
    b2c6:	85 db                	test   %ebx,%ebx
    b2c8:	b8 01 00 00 00       	mov    $0x1,%eax
    b2cd:	48 89 e6             	mov    %rsp,%rsi
    b2d0:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    b2d4:	0f 45 c3             	cmovne %ebx,%eax
    b2d7:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b2de:	00 
    b2df:	48 c1 e8 04          	shr    $0x4,%rax
    b2e3:	48 c1 e0 04          	shl    $0x4,%rax
    b2e7:	48 89 c7             	mov    %rax,%rdi
    b2ea:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b2f1:	48 29 fe             	sub    %rdi,%rsi
    b2f4:	48 39 f4             	cmp    %rsi,%rsp
    b2f7:	74 15                	je     b30e <fwp_hof0.constprop.0+0x2ee>
    b2f9:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b300:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b307:	00 00 
    b309:	48 39 f4             	cmp    %rsi,%rsp
    b30c:	75 eb                	jne    b2f9 <fwp_hof0.constprop.0+0x2d9>
    b30e:	25 ff 0f 00 00       	and    $0xfff,%eax
    b313:	48 29 c4             	sub    %rax,%rsp
    b316:	48 85 c0             	test   %rax,%rax
    b319:	74 06                	je     b321 <fwp_hof0.constprop.0+0x301>
    b31b:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b321:	89 cf                	mov    %ecx,%edi
    b323:	49 89 e3             	mov    %rsp,%r11
    b326:	31 c0                	xor    %eax,%eax
    b328:	48 c1 e7 03          	shl    $0x3,%rdi
    b32c:	85 c9                	test   %ecx,%ecx
    b32e:	74 22                	je     b352 <fwp_hof0.constprop.0+0x332>
    b330:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b33c:	00 00 00 00 
    b340:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b345:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b349:	48 83 c0 08          	add    $0x8,%rax
    b34d:	48 39 c7             	cmp    %rax,%rdi
    b350:	75 ee                	jne    b340 <fwp_hof0.constprop.0+0x320>
    b352:	45 85 f6             	test   %r14d,%r14d
    b355:	74 3e                	je     b395 <fwp_hof0.constprop.0+0x375>
    b357:	44 89 f6             	mov    %r14d,%esi
    b35a:	4c 89 e0             	mov    %r12,%rax
    b35d:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b361:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b368:	00 00 
    b36a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b371:	00 00 00 00 
    b375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b37c:	00 00 00 00 
    b380:	48 8b 30             	mov    (%rax),%rsi
    b383:	89 ca                	mov    %ecx,%edx
    b385:	48 83 c0 08          	add    $0x8,%rax
    b389:	83 c1 01             	add    $0x1,%ecx
    b38c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b390:	48 39 c7             	cmp    %rax,%rdi
    b393:	75 eb                	jne    b380 <fwp_hof0.constprop.0+0x360>
    b395:	48 8d 15 a4 14 06 00 	lea    0x614a4(%rip),%rdx        # 6c840 <fwp_heap>
    b39c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b3a0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b3a7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b3ae:	48 89 f1             	mov    %rsi,%rcx
    b3b1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b3b5:	48 c1 e1 10          	shl    $0x10,%rcx
    b3b9:	48 39 c8             	cmp    %rcx,%rax
    b3bc:	73 4c                	jae    b40a <fwp_hof0.constprop.0+0x3ea>
    b3be:	48 89 c1             	mov    %rax,%rcx
    b3c1:	48 c1 e9 10          	shr    $0x10,%rcx
    b3c5:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b3c9:	48 8b 0d 68 28 06 00 	mov    0x62868(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    b3d0:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b3d4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b3d8:	48 85 f6             	test   %rsi,%rsi
    b3db:	74 2d                	je     b40a <fwp_hof0.constprop.0+0x3ea>
    b3dd:	0f b6 39             	movzbl (%rcx),%edi
    b3e0:	40 80 ff 02          	cmp    $0x2,%dil
    b3e4:	74 6a                	je     b450 <fwp_hof0.constprop.0+0x430>
    b3e6:	40 80 ff 01          	cmp    $0x1,%dil
    b3ea:	75 1e                	jne    b40a <fwp_hof0.constprop.0+0x3ea>
    b3ec:	8b 79 18             	mov    0x18(%rcx),%edi
    b3ef:	0f b7 c0             	movzwl %ax,%eax
    b3f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b3f5:	48 0f af c7          	imul   %rdi,%rax
    b3f9:	48 c1 e8 20          	shr    $0x20,%rax
    b3fd:	48 39 c8             	cmp    %rcx,%rax
    b400:	73 08                	jae    b40a <fwp_hof0.constprop.0+0x3ea>
    b402:	48 01 c6             	add    %rax,%rsi
    b405:	80 3e 01             	cmpb   $0x1,(%rsi)
    b408:	74 36                	je     b440 <fwp_hof0.constprop.0+0x420>
    b40a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b40e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b412:	be 01 00 00 00       	mov    $0x1,%esi
    b417:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b41b:	41 ff 52 08          	call   *0x8(%r10)
    b41f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b423:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b427:	49 8b 40 18          	mov    0x18(%r8),%rax
    b42b:	4c 89 df             	mov    %r11,%rdi
    b42e:	ff 10                	call   *(%rax)
    b430:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b434:	e9 29 fe ff ff       	jmp    b262 <fwp_hof0.constprop.0+0x242>
    b439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b440:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b447:	00 
    b448:	eb dd                	jmp    b427 <fwp_hof0.constprop.0+0x407>
    b44a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b450:	66 85 c0             	test   %ax,%ax
    b453:	75 b5                	jne    b40a <fwp_hof0.constprop.0+0x3ea>
    b455:	eb ae                	jmp    b405 <fwp_hof0.constprop.0+0x3e5>
    b457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b45e:	00 00 
    b460:	48 89 c3             	mov    %rax,%rbx
    b463:	48 89 df             	mov    %rbx,%rdi
    b466:	e8 15 b8 ff ff       	call   6c80 <fwp_rc_share>
    b46b:	45 85 ed             	test   %r13d,%r13d
    b46e:	74 21                	je     b491 <fwp_hof0.constprop.0+0x471>
    b470:	44 89 ea             	mov    %r13d,%edx
    b473:	4d 89 e7             	mov    %r12,%r15
    b476:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b480:	49 8b 3f             	mov    (%r15),%rdi
    b483:	49 83 c7 08          	add    $0x8,%r15
    b487:	e8 f4 b7 ff ff       	call   6c80 <fwp_rc_share>
    b48c:	4d 39 f7             	cmp    %r14,%r15
    b48f:	75 ef                	jne    b480 <fwp_hof0.constprop.0+0x460>
    b491:	4c 89 e2             	mov    %r12,%rdx
    b494:	44 89 ee             	mov    %r13d,%esi
    b497:	48 89 df             	mov    %rbx,%rdi
    b49a:	e8 61 ac ff ff       	call   6100 <fwp_apply>
    b49f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b4a3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b4a6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b4a9:	0f 83 87 00 00 00    	jae    b536 <fwp_hof0.constprop.0+0x516>
    b4af:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b4b5:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b4b9:	48 89 c3             	mov    %rax,%rbx
    b4bc:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b4c0:	48 8b 15 d1 2f 06 00 	mov    0x62fd1(%rip),%rdx        # 6e498 <fwp_fns>
    b4c7:	29 de                	sub    %ebx,%esi
    b4c9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b4cd:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b4d0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b4d4:	44 8b 26             	mov    (%rsi),%r12d
    b4d7:	48 89 f0             	mov    %rsi,%rax
    b4da:	49 c1 e4 05          	shl    $0x5,%r12
    b4de:	49 01 d4             	add    %rdx,%r12
    b4e1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b4e7:	0f 85 22 fd ff ff    	jne    b20f <fwp_hof0.constprop.0+0x1ef>
    b4ed:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b4f1:	e8 8a b7 ff ff       	call   6c80 <fwp_rc_share>
    b4f6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b4fa:	45 85 f6             	test   %r14d,%r14d
    b4fd:	74 23                	je     b522 <fwp_hof0.constprop.0+0x502>
    b4ff:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b503:	31 db                	xor    %ebx,%ebx
    b505:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b50c:	00 00 00 00 
    b510:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b514:	48 83 c3 01          	add    $0x1,%rbx
    b518:	e8 63 b7 ff ff       	call   6c80 <fwp_rc_share>
    b51d:	44 39 f3             	cmp    %r14d,%ebx
    b520:	72 ee                	jb     b510 <fwp_hof0.constprop.0+0x4f0>
    b522:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b526:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b529:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b52d:	e8 ce ab ff ff       	call   6100 <fwp_apply>
    b532:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b536:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b53d:	01 
    b53e:	0f 85 d1 fb ff ff    	jne    b115 <fwp_hof0.constprop.0+0xf5>
    b544:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b548:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b54f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b553:	b9 01 00 00 00       	mov    $0x1,%ecx
    b558:	48 8d 15 41 86 00 00 	lea    0x8641(%rip),%rdx        # 13ba0 <d0>
    b55f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b566:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b56d:	00 
    b56e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b572:	e8 69 ea ff ff       	call   9fe0 <fwp_write>
    b577:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b57b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b57f:	48 8d 05 e6 4a 00 00 	lea    0x4ae6(%rip),%rax        # 1006c <_IO_stdin_used+0x6c>
    b586:	48 85 c9             	test   %rcx,%rcx
    b589:	48 0f 44 c8          	cmove  %rax,%rcx
    b58d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b591:	0f 87 15 08 00 00    	ja     bdac <fwp_hof0.constprop.0+0xd8c>
    b597:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b59b:	be 01 00 00 00       	mov    $0x1,%esi
    b5a0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b5a4:	e8 67 a9 ff ff       	call   5f10 <fwp_heap_alloc>
    b5a9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b5ad:	4c 89 f2             	mov    %r14,%rdx
    b5b0:	4c 89 30             	mov    %r14,(%rax)
    b5b3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b5b7:	48 89 c3             	mov    %rax,%rbx
    b5ba:	4c 89 e7             	mov    %r12,%rdi
    b5bd:	e8 be 7f ff ff       	call   3580 <memcpy@plt>
    b5c2:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b5c8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b5cc:	e8 df 7d ff ff       	call   33b0 <free@plt>
    b5d1:	48 8d 35 68 12 06 00 	lea    0x61268(%rip),%rsi        # 6c840 <fwp_heap>
    b5d8:	48 89 d8             	mov    %rbx,%rax
    b5db:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b5e2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b5e9:	48 89 fa             	mov    %rdi,%rdx
    b5ec:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
    b5f0:	48 c1 e2 10          	shl    $0x10,%rdx
    b5f4:	48 39 d0             	cmp    %rdx,%rax
    b5f7:	73 57                	jae    b650 <fwp_hof0.constprop.0+0x630>
    b5f9:	48 89 c2             	mov    %rax,%rdx
    b5fc:	48 c1 ea 10          	shr    $0x10,%rdx
    b600:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b604:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b60b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b60f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b613:	4d 85 f6             	test   %r14,%r14
    b616:	74 38                	je     b650 <fwp_hof0.constprop.0+0x630>
    b618:	0f b6 0a             	movzbl (%rdx),%ecx
    b61b:	80 f9 02             	cmp    $0x2,%cl
    b61e:	0f 84 da 06 00 00    	je     bcfe <fwp_hof0.constprop.0+0xcde>
    b624:	80 f9 01             	cmp    $0x1,%cl
    b627:	75 27                	jne    b650 <fwp_hof0.constprop.0+0x630>
    b629:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b62c:	0f b7 c0             	movzwl %ax,%eax
    b62f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b632:	48 0f af c1          	imul   %rcx,%rax
    b636:	48 c1 e8 20          	shr    $0x20,%rax
    b63a:	48 39 d0             	cmp    %rdx,%rax
    b63d:	73 11                	jae    b650 <fwp_hof0.constprop.0+0x630>
    b63f:	49 01 c6             	add    %rax,%r14
    b642:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b646:	0f 84 84 07 00 00    	je     bdd0 <fwp_hof0.constprop.0+0xdb0>
    b64c:	41 c6 06 01          	movb   $0x1,(%r14)
    b650:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b654:	e8 87 ba ff ff       	call   70e0 <fwp_drop0>
    b659:	48 8b 13             	mov    (%rbx),%rdx
    b65c:	be 01 00 00 00       	mov    $0x1,%esi
    b661:	4c 89 e7             	mov    %r12,%rdi
    b664:	48 8b 0d 35 2e 06 00 	mov    0x62e35(%rip),%rcx        # 6e4a0 <fwp_prog_out>
    b66b:	e8 f0 7f ff ff       	call   3660 <fwrite@plt>
    b670:	48 8b 35 29 2e 06 00 	mov    0x62e29(%rip),%rsi        # 6e4a0 <fwp_prog_out>
    b677:	bf 0a 00 00 00       	mov    $0xa,%edi
    b67c:	e8 4f 7e ff ff       	call   34d0 <fputc@plt>
    b681:	48 8d 35 b8 11 06 00 	lea    0x611b8(%rip),%rsi        # 6c840 <fwp_heap>
    b688:	48 89 d8             	mov    %rbx,%rax
    b68b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b692:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b699:	48 89 fa             	mov    %rdi,%rdx
    b69c:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b6a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b6a4:	48 39 d0             	cmp    %rdx,%rax
    b6a7:	73 69                	jae    b712 <fwp_hof0.constprop.0+0x6f2>
    b6a9:	48 89 c2             	mov    %rax,%rdx
    b6ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b6b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6b4:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b6bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b6c3:	4d 85 e4             	test   %r12,%r12
    b6c6:	74 4a                	je     b712 <fwp_hof0.constprop.0+0x6f2>
    b6c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b6cb:	80 f9 02             	cmp    $0x2,%cl
    b6ce:	0f 84 38 06 00 00    	je     bd0c <fwp_hof0.constprop.0+0xcec>
    b6d4:	80 f9 01             	cmp    $0x1,%cl
    b6d7:	75 39                	jne    b712 <fwp_hof0.constprop.0+0x6f2>
    b6d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6dc:	0f b7 c0             	movzwl %ax,%eax
    b6df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6e2:	48 0f af c1          	imul   %rcx,%rax
    b6e6:	48 c1 e8 20          	shr    $0x20,%rax
    b6ea:	48 39 d0             	cmp    %rdx,%rax
    b6ed:	73 23                	jae    b712 <fwp_hof0.constprop.0+0x6f2>
    b6ef:	49 01 c4             	add    %rax,%r12
    b6f2:	41 0f b6 04 24       	movzbl (%r12),%eax
    b6f7:	84 c0                	test   %al,%al
    b6f9:	74 17                	je     b712 <fwp_hof0.constprop.0+0x6f2>
    b6fb:	3c 01                	cmp    $0x1,%al
    b6fd:	0f 84 e1 05 00 00    	je     bce4 <fwp_hof0.constprop.0+0xcc4>
    b703:	3c ff                	cmp    $0xff,%al
    b705:	0f 84 0f 06 00 00    	je     bd1a <fwp_hof0.constprop.0+0xcfa>
    b70b:	83 e8 01             	sub    $0x1,%eax
    b70e:	41 88 04 24          	mov    %al,(%r12)
    b712:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b716:	4d 85 ff             	test   %r15,%r15
    b719:	0f 85 42 f9 ff ff    	jne    b061 <fwp_hof0.constprop.0+0x41>
    b71f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b723:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b72a:	00 00 
    b72c:	0f 85 98 06 00 00    	jne    bdca <fwp_hof0.constprop.0+0xdaa>
    b732:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b736:	31 c0                	xor    %eax,%eax
    b738:	5b                   	pop    %rbx
    b739:	41 5c                	pop    %r12
    b73b:	41 5d                	pop    %r13
    b73d:	41 5e                	pop    %r14
    b73f:	41 5f                	pop    %r15
    b741:	5d                   	pop    %rbp
    b742:	c3                   	ret
    b743:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b748:	44 8b 1d b9 2d 06 00 	mov    0x62db9(%rip),%r11d        # 6e508 <iteration_active>
    b74f:	41 8d 77 01          	lea    0x1(%r15),%esi
    b753:	8b 05 8b 24 06 00    	mov    0x6248b(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    b759:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b760:	00 
    b761:	45 85 db             	test   %r11d,%r11d
    b764:	0f 84 f3 03 00 00    	je     bb5d <fwp_hof0.constprop.0+0xb3d>
    b76a:	48 83 05 8e 2d 06 00 	addq   $0x1,0x62d8e(%rip)        # 6e500 <iteration_requests>
    b771:	01 
    b772:	48 01 3d 7f 2d 06 00 	add    %rdi,0x62d7f(%rip)        # 6e4f8 <iteration_bytes>
    b779:	85 c0                	test   %eax,%eax
    b77b:	0f 84 ca 04 00 00    	je     bc4b <fwp_hof0.constprop.0+0xc2b>
    b781:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b788:	0f 87 bd 04 00 00    	ja     bc4b <fwp_hof0.constprop.0+0xc2b>
    b78e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b792:	48 8d 1d a7 10 06 00 	lea    0x610a7(%rip),%rbx        # 6c840 <fwp_heap>
    b799:	48 c1 e8 04          	shr    $0x4,%rax
    b79d:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b7a4:	00 
    b7a5:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b7ac:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b7b0:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b7b4:	4c 8b 12             	mov    (%rdx),%r10
    b7b7:	4d 85 d2             	test   %r10,%r10
    b7ba:	0f 84 e1 03 00 00    	je     bba1 <fwp_hof0.constprop.0+0xb81>
    b7c0:	49 8b 1a             	mov    (%r10),%rbx
    b7c3:	48 f7 d3             	not    %rbx
    b7c6:	48 89 1a             	mov    %rbx,(%rdx)
    b7c9:	48 39 c7             	cmp    %rax,%rdi
    b7cc:	73 6c                	jae    b83a <fwp_hof0.constprop.0+0x81a>
    b7ce:	48 89 fa             	mov    %rdi,%rdx
    b7d1:	48 83 c7 08          	add    $0x8,%rdi
    b7d5:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b7dc:	00 
    b7dd:	48 f7 d2             	not    %rdx
    b7e0:	48 01 c2             	add    %rax,%rdx
    b7e3:	48 c1 ea 03          	shr    $0x3,%rdx
    b7e7:	48 39 c7             	cmp    %rax,%rdi
    b7ea:	73 4e                	jae    b83a <fwp_hof0.constprop.0+0x81a>
    b7ec:	83 e2 01             	and    $0x1,%edx
    b7ef:	74 2f                	je     b820 <fwp_hof0.constprop.0+0x800>
    b7f1:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b7f8:	00 
    b7f9:	48 83 c7 08          	add    $0x8,%rdi
    b7fd:	48 39 c7             	cmp    %rax,%rdi
    b800:	73 38                	jae    b83a <fwp_hof0.constprop.0+0x81a>
    b802:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b809:	00 
    b80a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b811:	00 00 00 00 
    b815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b81c:	00 00 00 00 
    b820:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b827:	00 
    b828:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b82f:	00 00 
    b831:	48 83 c7 10          	add    $0x10,%rdi
    b835:	48 39 c7             	cmp    %rax,%rdi
    b838:	72 e6                	jb     b820 <fwp_hof0.constprop.0+0x800>
    b83a:	48 8d 3d ff 0f 06 00 	lea    0x60fff(%rip),%rdi        # 6c840 <fwp_heap>
    b841:	48 89 c2             	mov    %rax,%rdx
    b844:	48 03 97 20 14 00 00 	add    0x1420(%rdi),%rdx
    b84b:	0f 82 4a 05 00 00    	jb     bd9b <fwp_hof0.constprop.0+0xd7b>
    b851:	48 89 97 20 14 00 00 	mov    %rdx,0x1420(%rdi)
    b858:	48 39 97 28 14 00 00 	cmp    %rdx,0x1428(%rdi)
    b85f:	73 07                	jae    b868 <fwp_hof0.constprop.0+0x848>
    b861:	48 89 15 00 24 06 00 	mov    %rdx,0x62400(%rip)        # 6dc68 <fwp_heap+0x1428>
    b868:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b86c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b871:	f2 0f 58 05 ff 23 06 	addsd  0x623ff(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    b878:	00 
    b879:	f2 0f 11 05 f7 23 06 	movsd  %xmm0,0x623f7(%rip)        # 6dc78 <fwp_heap+0x1438>
    b880:	00 
    b881:	45 85 db             	test   %r11d,%r11d
    b884:	74 33                	je     b8b9 <fwp_hof0.constprop.0+0x899>
    b886:	48 8b 05 d3 23 06 00 	mov    0x623d3(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    b88d:	48 85 c0             	test   %rax,%rax
    b890:	0f 88 64 03 00 00    	js     bbfa <fwp_hof0.constprop.0+0xbda>
    b896:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b89a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b89f:	f2 0f 5c 05 41 2c 06 	subsd  0x62c41(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    b8a6:	00 
    b8a7:	66 0f 2f 05 31 2c 06 	comisd 0x62c31(%rip),%xmm0        # 6e4e0 <iteration_peak>
    b8ae:	00 
    b8af:	76 08                	jbe    b8b9 <fwp_hof0.constprop.0+0x899>
    b8b1:	f2 0f 11 05 27 2c 06 	movsd  %xmm0,0x62c27(%rip)        # 6e4e0 <iteration_peak>
    b8b8:	00 
    b8b9:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b8be:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b8c3:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b8c7:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b8cc:	85 c9                	test   %ecx,%ecx
    b8ce:	74 37                	je     b907 <fwp_hof0.constprop.0+0x8e7>
    b8d0:	89 ca                	mov    %ecx,%edx
    b8d2:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b8d6:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b8da:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b8dd:	48 c1 e2 03          	shl    $0x3,%rdx
    b8e1:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b8e8:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b8ec:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b8f0:	e8 fb 7c ff ff       	call   35f0 <memmove@plt>
    b8f5:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b8f9:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b8fd:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b900:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b907:	45 85 ed             	test   %r13d,%r13d
    b90a:	74 2b                	je     b937 <fwp_hof0.constprop.0+0x917>
    b90c:	45 89 ed             	mov    %r13d,%r13d
    b90f:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b913:	66 90                	xchg   %ax,%ax
    b915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b91c:	00 00 00 00 
    b920:	49 8b 14 24          	mov    (%r12),%rdx
    b924:	89 c8                	mov    %ecx,%eax
    b926:	49 83 c4 08          	add    $0x8,%r12
    b92a:	83 c1 01             	add    $0x1,%ecx
    b92d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b932:	4c 39 e6             	cmp    %r12,%rsi
    b935:	75 e9                	jne    b920 <fwp_hof0.constprop.0+0x900>
    b937:	48 8d 15 02 0f 06 00 	lea    0x60f02(%rip),%rdx        # 6c840 <fwp_heap>
    b93e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b942:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b949:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b950:	48 89 f2             	mov    %rsi,%rdx
    b953:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    b957:	48 c1 e2 10          	shl    $0x10,%rdx
    b95b:	48 39 d0             	cmp    %rdx,%rax
    b95e:	73 54                	jae    b9b4 <fwp_hof0.constprop.0+0x994>
    b960:	48 89 c2             	mov    %rax,%rdx
    b963:	48 c1 ea 10          	shr    $0x10,%rdx
    b967:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b96b:	48 8b 15 c6 22 06 00 	mov    0x622c6(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    b972:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b976:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b97a:	48 85 c9             	test   %rcx,%rcx
    b97d:	74 35                	je     b9b4 <fwp_hof0.constprop.0+0x994>
    b97f:	0f b6 32             	movzbl (%rdx),%esi
    b982:	40 80 fe 02          	cmp    $0x2,%sil
    b986:	0f 84 37 02 00 00    	je     bbc3 <fwp_hof0.constprop.0+0xba3>
    b98c:	40 80 fe 01          	cmp    $0x1,%sil
    b990:	75 22                	jne    b9b4 <fwp_hof0.constprop.0+0x994>
    b992:	8b 72 18             	mov    0x18(%rdx),%esi
    b995:	0f b7 c0             	movzwl %ax,%eax
    b998:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b99b:	48 0f af c6          	imul   %rsi,%rax
    b99f:	48 c1 e8 20          	shr    $0x20,%rax
    b9a3:	48 39 d0             	cmp    %rdx,%rax
    b9a6:	73 0c                	jae    b9b4 <fwp_hof0.constprop.0+0x994>
    b9a8:	48 01 c1             	add    %rax,%rcx
    b9ab:	80 39 01             	cmpb   $0x1,(%rcx)
    b9ae:	0f 84 9c 01 00 00    	je     bb50 <fwp_hof0.constprop.0+0xb30>
    b9b4:	49 8b 40 18          	mov    0x18(%r8),%rax
    b9b8:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b9bc:	be 01 00 00 00       	mov    $0x1,%esi
    b9c1:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b9c5:	ff 50 08             	call   *0x8(%rax)
    b9c8:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b9cc:	48 8d 35 6d 0e 06 00 	lea    0x60e6d(%rip),%rsi        # 6c840 <fwp_heap>
    b9d3:	4c 89 d0             	mov    %r10,%rax
    b9d6:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b9dd:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b9e4:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b9e8:	48 c1 e2 10          	shl    $0x10,%rdx
    b9ec:	48 39 d0             	cmp    %rdx,%rax
    b9ef:	73 59                	jae    ba4a <fwp_hof0.constprop.0+0xa2a>
    b9f1:	48 89 c2             	mov    %rax,%rdx
    b9f4:	48 c1 ea 10          	shr    $0x10,%rdx
    b9f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b9fc:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ba03:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba07:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ba0b:	4d 85 e4             	test   %r12,%r12
    ba0e:	74 3a                	je     ba4a <fwp_hof0.constprop.0+0xa2a>
    ba10:	0f b6 0a             	movzbl (%rdx),%ecx
    ba13:	80 f9 02             	cmp    $0x2,%cl
    ba16:	0f 84 b5 01 00 00    	je     bbd1 <fwp_hof0.constprop.0+0xbb1>
    ba1c:	80 f9 01             	cmp    $0x1,%cl
    ba1f:	75 29                	jne    ba4a <fwp_hof0.constprop.0+0xa2a>
    ba21:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba24:	0f b7 c0             	movzwl %ax,%eax
    ba27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba2a:	48 0f af c1          	imul   %rcx,%rax
    ba2e:	48 c1 e8 20          	shr    $0x20,%rax
    ba32:	48 39 d0             	cmp    %rdx,%rax
    ba35:	73 13                	jae    ba4a <fwp_hof0.constprop.0+0xa2a>
    ba37:	49 01 c4             	add    %rax,%r12
    ba3a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ba3f:	0f 84 a0 01 00 00    	je     bbe5 <fwp_hof0.constprop.0+0xbc5>
    ba45:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ba4a:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ba4e:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    ba52:	e8 79 b9 ff ff       	call   73d0 <fwp_closure_drop>
    ba57:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    ba5b:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    ba5f:	e9 3f fa ff ff       	jmp    b4a3 <fwp_hof0.constprop.0+0x483>
    ba64:	0f 1f 40 00          	nopl   0x0(%rax)
    ba68:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ba6c:	e9 32 fa ff ff       	jmp    b4a3 <fwp_hof0.constprop.0+0x483>
    ba71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ba78:	41 8b 34 24          	mov    (%r12),%esi
    ba7c:	8b 05 9a 85 00 00    	mov    0x859a(%rip),%eax        # 1401c <fc12+0x4>
    ba82:	89 f7                	mov    %esi,%edi
    ba84:	29 c7                	sub    %eax,%edi
    ba86:	83 ff 01             	cmp    $0x1,%edi
    ba89:	0f 85 bf f6 ff ff    	jne    b14e <fwp_hof0.constprop.0+0x12e>
    ba8f:	48 89 e3             	mov    %rsp,%rbx
    ba92:	85 c0                	test   %eax,%eax
    ba94:	0f 84 e7 01 00 00    	je     bc81 <fwp_hof0.constprop.0+0xc61>
    ba9a:	89 f1                	mov    %esi,%ecx
    ba9c:	ba 08 00 00 00       	mov    $0x8,%edx
    baa1:	48 c1 e1 03          	shl    $0x3,%rcx
    baa5:	85 f6                	test   %esi,%esi
    baa7:	48 89 e6             	mov    %rsp,%rsi
    baaa:	48 0f 45 d1          	cmovne %rcx,%rdx
    baae:	49 89 d7             	mov    %rdx,%r15
    bab1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    bab5:	48 c1 ea 04          	shr    $0x4,%rdx
    bab9:	48 c1 e2 04          	shl    $0x4,%rdx
    babd:	48 89 d7             	mov    %rdx,%rdi
    bac0:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bac7:	48 29 fe             	sub    %rdi,%rsi
    baca:	48 39 f4             	cmp    %rsi,%rsp
    bacd:	74 15                	je     bae4 <fwp_hof0.constprop.0+0xac4>
    bacf:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    bad6:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    badd:	00 00 
    badf:	48 39 f4             	cmp    %rsi,%rsp
    bae2:	75 eb                	jne    bacf <fwp_hof0.constprop.0+0xaaf>
    bae4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    baea:	48 29 d4             	sub    %rdx,%rsp
    baed:	48 85 d2             	test   %rdx,%rdx
    baf0:	74 06                	je     baf8 <fwp_hof0.constprop.0+0xad8>
    baf2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    baf8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    baff:	00 
    bb00:	4c 89 f9             	mov    %r15,%rcx
    bb03:	48 8d 35 16 85 00 00 	lea    0x8516(%rip),%rsi        # 14020 <fwp_epfd>
    bb0a:	48 89 e7             	mov    %rsp,%rdi
    bb0d:	4c 89 f2             	mov    %r14,%rdx
    bb10:	e8 3b 7a ff ff       	call   3550 <__memcpy_chk@plt>
    bb15:	4d 39 f7             	cmp    %r14,%r15
    bb18:	4c 89 f9             	mov    %r15,%rcx
    bb1b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    bb1f:	49 0f 42 ce          	cmovb  %r14,%rcx
    bb23:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    bb2a:	ba 08 00 00 00       	mov    $0x8,%edx
    bb2f:	4c 29 f1             	sub    %r14,%rcx
    bb32:	e8 19 7a ff ff       	call   3550 <__memcpy_chk@plt>
    bb37:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    bb3c:	48 89 e7             	mov    %rsp,%rdi
    bb3f:	ff 10                	call   *(%rax)
    bb41:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bb45:	e9 44 01 00 00       	jmp    bc8e <fwp_hof0.constprop.0+0xc6e>
    bb4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bb50:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    bb57:	00 
    bb58:	e9 6f fe ff ff       	jmp    b9cc <fwp_hof0.constprop.0+0x9ac>
    bb5d:	85 c0                	test   %eax,%eax
    bb5f:	74 0d                	je     bb6e <fwp_hof0.constprop.0+0xb4e>
    bb61:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bb68:	0f 86 20 fc ff ff    	jbe    b78e <fwp_hof0.constprop.0+0x76e>
    bb6e:	31 f6                	xor    %esi,%esi
    bb70:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    bb73:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bb77:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    bb7b:	e8 90 a3 ff ff       	call   5f10 <fwp_heap_alloc>
    bb80:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bb84:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bb88:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bb8b:	49 89 c2             	mov    %rax,%r10
    bb8e:	e9 26 fd ff ff       	jmp    b8b9 <fwp_hof0.constprop.0+0x899>
    bb93:	66 85 c0             	test   %ax,%ax
    bb96:	0f 85 4f f6 ff ff    	jne    b1eb <fwp_hof0.constprop.0+0x1cb>
    bb9c:	e9 24 f6 ff ff       	jmp    b1c5 <fwp_hof0.constprop.0+0x1a5>
    bba1:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    bba5:	4d 85 d2             	test   %r10,%r10
    bba8:	74 6e                	je     bc18 <fwp_hof0.constprop.0+0xbf8>
    bbaa:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    bbae:	4c 29 d3             	sub    %r10,%rbx
    bbb1:	48 39 c3             	cmp    %rax,%rbx
    bbb4:	72 62                	jb     bc18 <fwp_hof0.constprop.0+0xbf8>
    bbb6:	49 8d 1c 02          	lea    (%r10,%rax,1),%rbx
    bbba:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
    bbbe:	e9 06 fc ff ff       	jmp    b7c9 <fwp_hof0.constprop.0+0x7a9>
    bbc3:	66 85 c0             	test   %ax,%ax
    bbc6:	0f 85 e8 fd ff ff    	jne    b9b4 <fwp_hof0.constprop.0+0x994>
    bbcc:	e9 da fd ff ff       	jmp    b9ab <fwp_hof0.constprop.0+0x98b>
    bbd1:	66 85 c0             	test   %ax,%ax
    bbd4:	0f 85 70 fe ff ff    	jne    ba4a <fwp_hof0.constprop.0+0xa2a>
    bbda:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bbdf:	0f 85 60 fe ff ff    	jne    ba45 <fwp_hof0.constprop.0+0xa25>
    bbe5:	4c 89 e7             	mov    %r12,%rdi
    bbe8:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    bbec:	e8 df 9b ff ff       	call   57d0 <fwp_rc_forget_slot>
    bbf1:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    bbf5:	e9 4b fe ff ff       	jmp    ba45 <fwp_hof0.constprop.0+0xa25>
    bbfa:	48 89 c2             	mov    %rax,%rdx
    bbfd:	83 e0 01             	and    $0x1,%eax
    bc00:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bc04:	48 d1 ea             	shr    $1,%rdx
    bc07:	48 09 c2             	or     %rax,%rdx
    bc0a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    bc0f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    bc13:	e9 87 fc ff ff       	jmp    b89f <fwp_hof0.constprop.0+0x87f>
    bc18:	31 f6                	xor    %esi,%esi
    bc1a:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    bc20:	44 89 5d 80          	mov    %r11d,-0x80(%rbp)
    bc24:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bc28:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    bc2c:	e8 df a2 ff ff       	call   5f10 <fwp_heap_alloc>
    bc31:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    bc37:	44 8b 5d 80          	mov    -0x80(%rbp),%r11d
    bc3b:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bc3f:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bc43:	49 89 c2             	mov    %rax,%r10
    bc46:	e9 36 fc ff ff       	jmp    b881 <fwp_hof0.constprop.0+0x861>
    bc4b:	31 f6                	xor    %esi,%esi
    bc4d:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    bc50:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bc54:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    bc58:	e8 b3 a2 ff ff       	call   5f10 <fwp_heap_alloc>
    bc5d:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bc61:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bc65:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bc68:	49 89 c2             	mov    %rax,%r10
    bc6b:	e9 16 fc ff ff       	jmp    b886 <fwp_hof0.constprop.0+0x866>
    bc70:	e8 3b 9a ff ff       	call   56b0 <fwp_rc_wide_dup>
    bc75:	48 8b 15 1c 28 06 00 	mov    0x6281c(%rip),%rdx        # 6e498 <fwp_fns>
    bc7c:	e9 6a f5 ff ff       	jmp    b1eb <fwp_hof0.constprop.0+0x1cb>
    bc81:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    bc88:	ff 11                	call   *(%rcx)
    bc8a:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bc8e:	48 89 dc             	mov    %rbx,%rsp
    bc91:	e9 a0 f8 ff ff       	jmp    b536 <fwp_hof0.constprop.0+0x516>
    bc96:	48 89 c7             	mov    %rax,%rdi
    bc99:	e8 e2 af ff ff       	call   6c80 <fwp_rc_share>
    bc9e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    bca2:	e8 d9 af ff ff       	call   6c80 <fwp_rc_share>
    bca7:	48 8d 05 6a 83 00 00 	lea    0x836a(%rip),%rax        # 14018 <fc12>
    bcae:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    bcb5:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bcb9:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    bcc0:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    bcc4:	e9 59 f8 ff ff       	jmp    b522 <fwp_hof0.constprop.0+0x502>
    bcc9:	66 85 c0             	test   %ax,%ax
    bccc:	0f 85 26 f4 ff ff    	jne    b0f8 <fwp_hof0.constprop.0+0xd8>
    bcd2:	e9 ff f3 ff ff       	jmp    b0d6 <fwp_hof0.constprop.0+0xb6>
    bcd7:	48 83 05 11 28 06 00 	addq   $0x1,0x62811(%rip)        # 6e4f0 <iteration_retains>
    bcde:	01 
    bcdf:	e9 07 f4 ff ff       	jmp    b0eb <fwp_hof0.constprop.0+0xcb>
    bce4:	48 89 df             	mov    %rbx,%rdi
    bce7:	e8 c4 b0 ff ff       	call   6db0 <fwp_rc_free_arr>
    bcec:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    bcf0:	4d 85 ff             	test   %r15,%r15
    bcf3:	0f 85 68 f3 ff ff    	jne    b061 <fwp_hof0.constprop.0+0x41>
    bcf9:	e9 21 fa ff ff       	jmp    b71f <fwp_hof0.constprop.0+0x6ff>
    bcfe:	66 85 c0             	test   %ax,%ax
    bd01:	0f 85 49 f9 ff ff    	jne    b650 <fwp_hof0.constprop.0+0x630>
    bd07:	e9 36 f9 ff ff       	jmp    b642 <fwp_hof0.constprop.0+0x622>
    bd0c:	66 85 c0             	test   %ax,%ax
    bd0f:	0f 85 fd f9 ff ff    	jne    b712 <fwp_hof0.constprop.0+0x6f2>
    bd15:	e9 d8 f9 ff ff       	jmp    b6f2 <fwp_hof0.constprop.0+0x6d2>
    bd1a:	4c 89 e0             	mov    %r12,%rax
    bd1d:	48 8d 35 1c 0b 06 00 	lea    0x60b1c(%rip),%rsi        # 6c840 <fwp_heap>
    bd24:	48 c1 e8 11          	shr    $0x11,%rax
    bd28:	4c 31 e0             	xor    %r12,%rax
    bd2b:	48 89 c2             	mov    %rax,%rdx
    bd2e:	48 c1 ea 09          	shr    $0x9,%rdx
    bd32:	48 31 d0             	xor    %rdx,%rax
    bd35:	0f b6 c0             	movzbl %al,%eax
    bd38:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    bd3f:	00 
    bd40:	48 85 d2             	test   %rdx,%rdx
    bd43:	75 24                	jne    bd69 <fwp_hof0.constprop.0+0xd49>
    bd45:	eb 59                	jmp    bda0 <fwp_hof0.constprop.0+0xd80>
    bd47:	0f 1f 00             	nopl   (%rax)
    bd4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bd51:	00 00 00 00 
    bd55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bd5c:	00 00 00 00 
    bd60:	48 8b 50 10          	mov    0x10(%rax),%rdx
    bd64:	48 85 d2             	test   %rdx,%rdx
    bd67:	74 37                	je     bda0 <fwp_hof0.constprop.0+0xd80>
    bd69:	48 89 d0             	mov    %rdx,%rax
    bd6c:	4c 3b 22             	cmp    (%rdx),%r12
    bd6f:	75 ef                	jne    bd60 <fwp_hof0.constprop.0+0xd40>
    bd71:	48 8b 42 08          	mov    0x8(%rdx),%rax
    bd75:	48 83 e8 01          	sub    $0x1,%rax
    bd79:	48 89 42 08          	mov    %rax,0x8(%rdx)
    bd7d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    bd83:	0f 85 89 f9 ff ff    	jne    b712 <fwp_hof0.constprop.0+0x6f2>
    bd89:	4c 89 e7             	mov    %r12,%rdi
    bd8c:	e8 3f 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd91:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    bd96:	e9 77 f9 ff ff       	jmp    b712 <fwp_hof0.constprop.0+0x6f2>
    bd9b:	e8 90 80 ff ff       	call   3e30 <fwp_heap_oom>
    bda0:	48 8d 3d 39 4c 00 00 	lea    0x4c39(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    bda7:	e8 a4 86 ff ff       	call   4450 <fwp_trap>
    bdac:	48 8d 3d 0f 45 00 00 	lea    0x450f(%rip),%rdi        # 102c2 <_IO_stdin_used+0x2c2>
    bdb3:	e8 98 86 ff ff       	call   4450 <fwp_trap>
    bdb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bdbf:	00 
    bdc0:	e8 eb 98 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bdc5:	e9 2e f3 ff ff       	jmp    b0f8 <fwp_hof0.constprop.0+0xd8>
    bdca:	e8 81 76 ff ff       	call   3450 <__stack_chk_fail@plt>
    bdcf:	90                   	nop
    bdd0:	4c 89 f7             	mov    %r14,%rdi
    bdd3:	e8 f8 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bdd8:	e9 6f f8 ff ff       	jmp    b64c <fwp_hof0.constprop.0+0x62c>
    bddd:	0f 1f 00             	nopl   (%rax)

000000000000bde0 <f0>:
    bde0:	41 56                	push   %r14
    bde2:	4c 8d 35 57 0a 06 00 	lea    0x60a57(%rip),%r14        # 6c840 <fwp_heap>
    bde9:	41 55                	push   %r13
    bdeb:	41 54                	push   %r12
    bded:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    bdf3:	55                   	push   %rbp
    bdf4:	53                   	push   %rbx
    bdf5:	31 db                	xor    %ebx,%ebx
    bdf7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    bdfe:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    be05:	00 00 
    be07:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    be0e:	00 
    be0f:	31 c0                	xor    %eax,%eax
    be11:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    be18:	00 
    be19:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    be20:	00 00 
    be22:	66 48 0f 6e c0       	movq   %rax,%xmm0
    be27:	48 8d 05 42 b4 ff ff 	lea    -0x4bbe(%rip),%rax        # 7270 <fwp_drop1>
    be2e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    be33:	48 8b 05 9e 26 06 00 	mov    0x6269e(%rip),%rax        # 6e4d8 <fwp_cleanups>
    be3a:	48 89 25 97 26 06 00 	mov    %rsp,0x62697(%rip)        # 6e4d8 <fwp_cleanups>
    be41:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    be45:	48 89 04 24          	mov    %rax,(%rsp)
    be49:	48 8d 05 80 7d ff ff 	lea    -0x8280(%rip),%rax        # 3bd0 <fwp_range_release>
    be50:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    be55:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    be5a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    be5f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    be64:	eb 47                	jmp    bead <f0+0xcd>
    be66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    be6d:	00 00 00 
    be70:	80 f9 01             	cmp    $0x1,%cl
    be73:	75 29                	jne    be9e <f0+0xbe>
    be75:	8b 4a 18             	mov    0x18(%rdx),%ecx
    be78:	0f b7 c0             	movzwl %ax,%eax
    be7b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    be7e:	48 0f af c1          	imul   %rcx,%rax
    be82:	48 c1 e8 20          	shr    $0x20,%rax
    be86:	48 39 d0             	cmp    %rdx,%rax
    be89:	73 13                	jae    be9e <f0+0xbe>
    be8b:	49 01 c5             	add    %rax,%r13
    be8e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    be93:	0f 84 c7 27 00 00    	je     e660 <f0+0x2880>
    be99:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    be9e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bea3:	49 83 ec 01          	sub    $0x1,%r12
    bea7:	0f 82 83 00 00 00    	jb     bf30 <f0+0x150>
    bead:	48 89 ee             	mov    %rbp,%rsi
    beb0:	bf 01 00 00 00       	mov    $0x1,%edi
    beb5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    bebc:	00 
    bebd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    bec2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    bec9:	00 
    beca:	e8 c1 ab ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    becf:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bed6:	48 89 c3             	mov    %rax,%rbx
    bed9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bee0:	48 c1 e2 10          	shl    $0x10,%rdx
    bee4:	48 39 d0             	cmp    %rdx,%rax
    bee7:	73 b5                	jae    be9e <f0+0xbe>
    bee9:	48 89 c2             	mov    %rax,%rdx
    beec:	48 c1 ea 10          	shr    $0x10,%rdx
    bef0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bef4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    befb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    beff:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bf03:	4d 85 ed             	test   %r13,%r13
    bf06:	74 96                	je     be9e <f0+0xbe>
    bf08:	0f b6 0a             	movzbl (%rdx),%ecx
    bf0b:	80 f9 02             	cmp    $0x2,%cl
    bf0e:	0f 85 5c ff ff ff    	jne    be70 <f0+0x90>
    bf14:	66 85 c0             	test   %ax,%ax
    bf17:	0f 84 71 ff ff ff    	je     be8e <f0+0xae>
    bf1d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bf22:	49 83 ec 01          	sub    $0x1,%r12
    bf26:	73 85                	jae    bead <f0+0xcd>
    bf28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bf2f:	00 
    bf30:	48 8b 04 24          	mov    (%rsp),%rax
    bf34:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    bf39:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3e:	66 0f 6f 05 8a 4e 00 	movdqa 0x4e8a(%rip),%xmm0        # 10dd0 <msg.4+0xa0>
    bf45:	00 
    bf46:	48 89 05 8b 25 06 00 	mov    %rax,0x6258b(%rip)        # 6e4d8 <fwp_cleanups>
    bf4d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    bf52:	e8 39 ab ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    bf57:	48 8b 15 ba 1c 06 00 	mov    0x61cba(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bf5e:	49 89 c5             	mov    %rax,%r13
    bf61:	48 2b 05 88 1c 06 00 	sub    0x61c88(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bf68:	48 c1 e2 10          	shl    $0x10,%rdx
    bf6c:	48 39 d0             	cmp    %rdx,%rax
    bf6f:	73 59                	jae    bfca <f0+0x1ea>
    bf71:	48 89 c2             	mov    %rax,%rdx
    bf74:	48 c1 ea 10          	shr    $0x10,%rdx
    bf78:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf7c:	48 8b 15 b5 1c 06 00 	mov    0x61cb5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bf83:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bf87:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bf8b:	4d 85 e4             	test   %r12,%r12
    bf8e:	74 3a                	je     bfca <f0+0x1ea>
    bf90:	0f b6 0a             	movzbl (%rdx),%ecx
    bf93:	80 f9 02             	cmp    $0x2,%cl
    bf96:	0f 84 74 27 00 00    	je     e710 <f0+0x2930>
    bf9c:	80 f9 01             	cmp    $0x1,%cl
    bf9f:	75 29                	jne    bfca <f0+0x1ea>
    bfa1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfa4:	0f b7 c0             	movzwl %ax,%eax
    bfa7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfaa:	48 0f af c1          	imul   %rcx,%rax
    bfae:	48 c1 e8 20          	shr    $0x20,%rax
    bfb2:	48 39 d0             	cmp    %rdx,%rax
    bfb5:	73 13                	jae    bfca <f0+0x1ea>
    bfb7:	49 01 c4             	add    %rax,%r12
    bfba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bfbf:	0f 84 26 29 00 00    	je     e8eb <f0+0x2b0b>
    bfc5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bfca:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    bfcf:	bf 01 00 00 00       	mov    $0x1,%edi
    bfd4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    bfd9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bfe0:	00 f0 3f 
    bfe3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    bfe8:	e8 a3 aa ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    bfed:	48 8b 15 24 1c 06 00 	mov    0x61c24(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    bff4:	49 89 c5             	mov    %rax,%r13
    bff7:	48 2b 05 f2 1b 06 00 	sub    0x61bf2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    bffe:	48 c1 e2 10          	shl    $0x10,%rdx
    c002:	48 39 d0             	cmp    %rdx,%rax
    c005:	73 59                	jae    c060 <f0+0x280>
    c007:	48 89 c2             	mov    %rax,%rdx
    c00a:	48 c1 ea 10          	shr    $0x10,%rdx
    c00e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c012:	48 8b 15 1f 1c 06 00 	mov    0x61c1f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c019:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c01d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c021:	4d 85 e4             	test   %r12,%r12
    c024:	74 3a                	je     c060 <f0+0x280>
    c026:	0f b6 0a             	movzbl (%rdx),%ecx
    c029:	80 f9 02             	cmp    $0x2,%cl
    c02c:	0f 84 ce 26 00 00    	je     e700 <f0+0x2920>
    c032:	80 f9 01             	cmp    $0x1,%cl
    c035:	75 29                	jne    c060 <f0+0x280>
    c037:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c03a:	0f b7 c0             	movzwl %ax,%eax
    c03d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c040:	48 0f af c1          	imul   %rcx,%rax
    c044:	48 c1 e8 20          	shr    $0x20,%rax
    c048:	48 39 d0             	cmp    %rdx,%rax
    c04b:	73 13                	jae    c060 <f0+0x280>
    c04d:	49 01 c4             	add    %rax,%r12
    c050:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c055:	0f 84 9d 28 00 00    	je     e8f8 <f0+0x2b18>
    c05b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c060:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    c065:	bf 01 00 00 00       	mov    $0x1,%edi
    c06a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    c06f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c076:	33 f3 bf 
    c079:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    c07e:	e8 0d aa ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c083:	48 8b 15 8e 1b 06 00 	mov    0x61b8e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c08a:	49 89 c5             	mov    %rax,%r13
    c08d:	48 2b 05 5c 1b 06 00 	sub    0x61b5c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c094:	48 c1 e2 10          	shl    $0x10,%rdx
    c098:	48 39 d0             	cmp    %rdx,%rax
    c09b:	73 59                	jae    c0f6 <f0+0x316>
    c09d:	48 89 c2             	mov    %rax,%rdx
    c0a0:	48 c1 ea 10          	shr    $0x10,%rdx
    c0a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c0a8:	48 8b 15 89 1b 06 00 	mov    0x61b89(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c0af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c0b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c0b7:	4d 85 e4             	test   %r12,%r12
    c0ba:	74 3a                	je     c0f6 <f0+0x316>
    c0bc:	0f b6 0a             	movzbl (%rdx),%ecx
    c0bf:	80 f9 02             	cmp    $0x2,%cl
    c0c2:	0f 84 28 26 00 00    	je     e6f0 <f0+0x2910>
    c0c8:	80 f9 01             	cmp    $0x1,%cl
    c0cb:	75 29                	jne    c0f6 <f0+0x316>
    c0cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0d0:	0f b7 c0             	movzwl %ax,%eax
    c0d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0d6:	48 0f af c1          	imul   %rcx,%rax
    c0da:	48 c1 e8 20          	shr    $0x20,%rax
    c0de:	48 39 d0             	cmp    %rdx,%rax
    c0e1:	73 13                	jae    c0f6 <f0+0x316>
    c0e3:	49 01 c4             	add    %rax,%r12
    c0e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c0eb:	0f 84 14 28 00 00    	je     e905 <f0+0x2b25>
    c0f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c0f6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    c0fb:	bf 01 00 00 00       	mov    $0x1,%edi
    c100:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    c105:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c10c:	00 f0 3f 
    c10f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    c114:	e8 77 a9 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c119:	48 8b 15 f8 1a 06 00 	mov    0x61af8(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c120:	49 89 c5             	mov    %rax,%r13
    c123:	48 2b 05 c6 1a 06 00 	sub    0x61ac6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c12a:	48 c1 e2 10          	shl    $0x10,%rdx
    c12e:	48 39 d0             	cmp    %rdx,%rax
    c131:	73 59                	jae    c18c <f0+0x3ac>
    c133:	48 89 c2             	mov    %rax,%rdx
    c136:	48 c1 ea 10          	shr    $0x10,%rdx
    c13a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c13e:	48 8b 15 f3 1a 06 00 	mov    0x61af3(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c145:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c149:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c14d:	4d 85 e4             	test   %r12,%r12
    c150:	74 3a                	je     c18c <f0+0x3ac>
    c152:	0f b6 0a             	movzbl (%rdx),%ecx
    c155:	80 f9 02             	cmp    $0x2,%cl
    c158:	0f 84 f2 25 00 00    	je     e750 <f0+0x2970>
    c15e:	80 f9 01             	cmp    $0x1,%cl
    c161:	75 29                	jne    c18c <f0+0x3ac>
    c163:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c166:	0f b7 c0             	movzwl %ax,%eax
    c169:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c16c:	48 0f af c1          	imul   %rcx,%rax
    c170:	48 c1 e8 20          	shr    $0x20,%rax
    c174:	48 39 d0             	cmp    %rdx,%rax
    c177:	73 13                	jae    c18c <f0+0x3ac>
    c179:	49 01 c4             	add    %rax,%r12
    c17c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c181:	0f 84 8b 27 00 00    	je     e912 <f0+0x2b32>
    c187:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c18c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c193:	33 f3 bf 
    c196:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    c19d:	00 
    c19e:	bf 01 00 00 00       	mov    $0x1,%edi
    c1a3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    c1aa:	00 
    c1ab:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    c1b2:	00 
    c1b3:	e8 d8 a8 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c1b8:	48 8b 15 59 1a 06 00 	mov    0x61a59(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c1bf:	49 89 c5             	mov    %rax,%r13
    c1c2:	48 2b 05 27 1a 06 00 	sub    0x61a27(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c1c9:	48 c1 e2 10          	shl    $0x10,%rdx
    c1cd:	48 39 d0             	cmp    %rdx,%rax
    c1d0:	73 59                	jae    c22b <f0+0x44b>
    c1d2:	48 89 c2             	mov    %rax,%rdx
    c1d5:	48 c1 ea 10          	shr    $0x10,%rdx
    c1d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1dd:	48 8b 15 54 1a 06 00 	mov    0x61a54(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c1e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c1e8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1ec:	4d 85 e4             	test   %r12,%r12
    c1ef:	74 3a                	je     c22b <f0+0x44b>
    c1f1:	0f b6 0a             	movzbl (%rdx),%ecx
    c1f4:	80 f9 02             	cmp    $0x2,%cl
    c1f7:	0f 84 43 25 00 00    	je     e740 <f0+0x2960>
    c1fd:	80 f9 01             	cmp    $0x1,%cl
    c200:	75 29                	jne    c22b <f0+0x44b>
    c202:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c205:	0f b7 c0             	movzwl %ax,%eax
    c208:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c20b:	48 0f af c1          	imul   %rcx,%rax
    c20f:	48 c1 e8 20          	shr    $0x20,%rax
    c213:	48 39 d0             	cmp    %rdx,%rax
    c216:	73 13                	jae    c22b <f0+0x44b>
    c218:	49 01 c4             	add    %rax,%r12
    c21b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c220:	0f 84 f9 26 00 00    	je     e91f <f0+0x2b3f>
    c226:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c22b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c232:	00 f0 3f 
    c235:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    c23c:	00 
    c23d:	bf 01 00 00 00       	mov    $0x1,%edi
    c242:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    c249:	00 
    c24a:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    c251:	00 
    c252:	e8 39 a8 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c257:	48 8b 15 ba 19 06 00 	mov    0x619ba(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c25e:	49 89 c5             	mov    %rax,%r13
    c261:	48 2b 05 88 19 06 00 	sub    0x61988(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c268:	48 c1 e2 10          	shl    $0x10,%rdx
    c26c:	48 39 d0             	cmp    %rdx,%rax
    c26f:	73 59                	jae    c2ca <f0+0x4ea>
    c271:	48 89 c2             	mov    %rax,%rdx
    c274:	48 c1 ea 10          	shr    $0x10,%rdx
    c278:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c27c:	48 8b 15 b5 19 06 00 	mov    0x619b5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c283:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c287:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c28b:	4d 85 e4             	test   %r12,%r12
    c28e:	74 3a                	je     c2ca <f0+0x4ea>
    c290:	0f b6 0a             	movzbl (%rdx),%ecx
    c293:	80 f9 02             	cmp    $0x2,%cl
    c296:	0f 84 94 24 00 00    	je     e730 <f0+0x2950>
    c29c:	80 f9 01             	cmp    $0x1,%cl
    c29f:	75 29                	jne    c2ca <f0+0x4ea>
    c2a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2a4:	0f b7 c0             	movzwl %ax,%eax
    c2a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2aa:	48 0f af c1          	imul   %rcx,%rax
    c2ae:	48 c1 e8 20          	shr    $0x20,%rax
    c2b2:	48 39 d0             	cmp    %rdx,%rax
    c2b5:	73 13                	jae    c2ca <f0+0x4ea>
    c2b7:	49 01 c4             	add    %rax,%r12
    c2ba:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2bf:	0f 84 67 26 00 00    	je     e92c <f0+0x2b4c>
    c2c5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2ca:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    c2d1:	33 f3 bf 
    c2d4:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    c2db:	00 
    c2dc:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e1:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    c2e8:	00 
    c2e9:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    c2f0:	00 
    c2f1:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    c2f8:	00 f0 3f 
    c2fb:	e8 90 a7 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c300:	48 89 c7             	mov    %rax,%rdi
    c303:	e8 f8 a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c308:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    c30f:	00 
    c310:	bf 01 00 00 00       	mov    $0x1,%edi
    c315:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    c31c:	00 
    c31d:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    c324:	00 
    c325:	e8 66 a7 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c32a:	48 89 c7             	mov    %rax,%rdi
    c32d:	e8 ce a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c332:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    c339:	00 
    c33a:	bf 01 00 00 00       	mov    $0x1,%edi
    c33f:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    c346:	00 
    c347:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    c34e:	00 
    c34f:	e8 3c a7 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c354:	48 89 c7             	mov    %rax,%rdi
    c357:	e8 a4 a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c35c:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    c363:	00 
    c364:	bf 01 00 00 00       	mov    $0x1,%edi
    c369:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    c370:	00 
    c371:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    c378:	00 
    c379:	e8 12 a7 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c37e:	48 89 c7             	mov    %rax,%rdi
    c381:	e8 7a a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c386:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    c38d:	00 
    c38e:	bf 01 00 00 00       	mov    $0x1,%edi
    c393:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    c39a:	00 
    c39b:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    c3a2:	00 
    c3a3:	e8 e8 a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c3a8:	48 89 c7             	mov    %rax,%rdi
    c3ab:	e8 50 a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c3b0:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    c3b7:	00 
    c3b8:	bf 01 00 00 00       	mov    $0x1,%edi
    c3bd:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    c3c4:	00 
    c3c5:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    c3cc:	00 
    c3cd:	e8 be a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c3d2:	48 89 c7             	mov    %rax,%rdi
    c3d5:	e8 26 a9 ff ff       	call   6d00 <fwp_rc_fresh>
    c3da:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    c3e1:	00 
    c3e2:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e7:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    c3ee:	00 
    c3ef:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    c3f6:	00 
    c3f7:	e8 94 a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c3fc:	48 89 c7             	mov    %rax,%rdi
    c3ff:	e8 fc a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c404:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    c40b:	00 
    c40c:	bf 01 00 00 00       	mov    $0x1,%edi
    c411:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    c418:	00 
    c419:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    c420:	00 
    c421:	e8 6a a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c426:	48 89 c7             	mov    %rax,%rdi
    c429:	e8 d2 a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c42e:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    c435:	00 
    c436:	bf 01 00 00 00       	mov    $0x1,%edi
    c43b:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    c442:	00 
    c443:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    c44a:	00 
    c44b:	e8 40 a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c450:	48 89 c7             	mov    %rax,%rdi
    c453:	e8 a8 a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c458:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    c45f:	00 
    c460:	bf 01 00 00 00       	mov    $0x1,%edi
    c465:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    c46c:	00 
    c46d:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    c474:	00 
    c475:	e8 16 a6 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c47a:	48 89 c7             	mov    %rax,%rdi
    c47d:	e8 7e a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c482:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    c489:	00 
    c48a:	bf 01 00 00 00       	mov    $0x1,%edi
    c48f:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    c496:	00 
    c497:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    c49e:	00 
    c49f:	e8 ec a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c4a4:	48 89 c7             	mov    %rax,%rdi
    c4a7:	e8 54 a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c4ac:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    c4b3:	00 
    c4b4:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b9:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    c4c0:	00 
    c4c1:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    c4c8:	00 
    c4c9:	e8 c2 a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c4ce:	48 89 c7             	mov    %rax,%rdi
    c4d1:	e8 2a a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c4d6:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c4dd:	00 
    c4de:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e3:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    c4ea:	00 
    c4eb:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c4f2:	00 
    c4f3:	e8 98 a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c4f8:	48 89 c7             	mov    %rax,%rdi
    c4fb:	e8 00 a8 ff ff       	call   6d00 <fwp_rc_fresh>
    c500:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c507:	00 
    c508:	bf 01 00 00 00       	mov    $0x1,%edi
    c50d:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    c514:	00 
    c515:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c51c:	00 
    c51d:	e8 6e a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c522:	48 89 c7             	mov    %rax,%rdi
    c525:	e8 d6 a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c52a:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c531:	00 
    c532:	bf 01 00 00 00       	mov    $0x1,%edi
    c537:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    c53e:	00 
    c53f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c546:	00 
    c547:	e8 44 a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c54c:	48 89 c7             	mov    %rax,%rdi
    c54f:	e8 ac a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c554:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c55b:	00 
    c55c:	bf 01 00 00 00       	mov    $0x1,%edi
    c561:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    c568:	00 
    c569:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c570:	00 
    c571:	e8 1a a5 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c576:	48 89 c7             	mov    %rax,%rdi
    c579:	e8 82 a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c57e:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c585:	00 
    c586:	bf 01 00 00 00       	mov    $0x1,%edi
    c58b:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    c592:	00 
    c593:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c59a:	00 
    c59b:	e8 f0 a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c5a0:	48 89 c7             	mov    %rax,%rdi
    c5a3:	e8 58 a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c5a8:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c5af:	00 
    c5b0:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b5:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    c5bc:	00 
    c5bd:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c5c4:	00 
    c5c5:	e8 c6 a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c5ca:	48 89 c7             	mov    %rax,%rdi
    c5cd:	e8 2e a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c5d2:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c5d9:	00 
    c5da:	bf 01 00 00 00       	mov    $0x1,%edi
    c5df:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    c5e6:	00 
    c5e7:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c5ee:	00 
    c5ef:	e8 9c a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c5f4:	48 89 c7             	mov    %rax,%rdi
    c5f7:	e8 04 a7 ff ff       	call   6d00 <fwp_rc_fresh>
    c5fc:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c603:	00 
    c604:	bf 01 00 00 00       	mov    $0x1,%edi
    c609:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    c610:	00 
    c611:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c618:	00 
    c619:	e8 72 a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c61e:	48 89 c7             	mov    %rax,%rdi
    c621:	e8 da a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c626:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c62d:	00 
    c62e:	bf 01 00 00 00       	mov    $0x1,%edi
    c633:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    c63a:	00 
    c63b:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c642:	00 
    c643:	e8 48 a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c648:	48 89 c7             	mov    %rax,%rdi
    c64b:	e8 b0 a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c650:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c657:	00 
    c658:	bf 01 00 00 00       	mov    $0x1,%edi
    c65d:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    c664:	00 
    c665:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c66c:	00 
    c66d:	e8 1e a4 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c672:	48 89 c7             	mov    %rax,%rdi
    c675:	e8 86 a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c67a:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c681:	00 
    c682:	bf 01 00 00 00       	mov    $0x1,%edi
    c687:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    c68e:	00 
    c68f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c696:	00 
    c697:	e8 f4 a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c69c:	48 89 c7             	mov    %rax,%rdi
    c69f:	e8 5c a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c6a4:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c6ab:	00 
    c6ac:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b1:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    c6b8:	00 
    c6b9:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c6c0:	00 
    c6c1:	e8 ca a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c6c6:	48 89 c7             	mov    %rax,%rdi
    c6c9:	e8 32 a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c6ce:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c6d5:	00 
    c6d6:	bf 01 00 00 00       	mov    $0x1,%edi
    c6db:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    c6e2:	00 
    c6e3:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c6ea:	00 
    c6eb:	e8 a0 a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c6f0:	48 89 c7             	mov    %rax,%rdi
    c6f3:	e8 08 a6 ff ff       	call   6d00 <fwp_rc_fresh>
    c6f8:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c6ff:	00 
    c700:	bf 01 00 00 00       	mov    $0x1,%edi
    c705:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    c70c:	00 
    c70d:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c714:	00 
    c715:	e8 76 a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c71a:	48 89 c7             	mov    %rax,%rdi
    c71d:	e8 de a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c722:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c729:	00 
    c72a:	bf 01 00 00 00       	mov    $0x1,%edi
    c72f:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    c736:	00 
    c737:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c73e:	00 
    c73f:	e8 4c a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c744:	48 89 c7             	mov    %rax,%rdi
    c747:	e8 b4 a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c74c:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c753:	00 
    c754:	bf 01 00 00 00       	mov    $0x1,%edi
    c759:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    c760:	00 
    c761:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c768:	00 
    c769:	e8 22 a3 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c76e:	48 89 c7             	mov    %rax,%rdi
    c771:	e8 8a a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c776:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c77d:	00 
    c77e:	bf 01 00 00 00       	mov    $0x1,%edi
    c783:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    c78a:	00 
    c78b:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c792:	00 
    c793:	e8 f8 a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c798:	48 89 c7             	mov    %rax,%rdi
    c79b:	e8 60 a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c7a0:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c7a7:	00 
    c7a8:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ad:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    c7b4:	00 
    c7b5:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c7bc:	00 
    c7bd:	e8 ce a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c7c2:	48 89 c7             	mov    %rax,%rdi
    c7c5:	e8 36 a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c7ca:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c7d1:	00 
    c7d2:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d7:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    c7de:	00 
    c7df:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c7e6:	00 
    c7e7:	e8 a4 a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c7ec:	48 89 c7             	mov    %rax,%rdi
    c7ef:	e8 0c a5 ff ff       	call   6d00 <fwp_rc_fresh>
    c7f4:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c7fb:	00 
    c7fc:	bf 01 00 00 00       	mov    $0x1,%edi
    c801:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    c808:	00 
    c809:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c810:	00 
    c811:	e8 7a a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c816:	48 89 c7             	mov    %rax,%rdi
    c819:	e8 e2 a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c81e:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c825:	00 
    c826:	bf 01 00 00 00       	mov    $0x1,%edi
    c82b:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    c832:	00 
    c833:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c83a:	00 
    c83b:	e8 50 a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c840:	48 89 c7             	mov    %rax,%rdi
    c843:	e8 b8 a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c848:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c84f:	00 
    c850:	bf 01 00 00 00       	mov    $0x1,%edi
    c855:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    c85c:	00 
    c85d:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c864:	00 
    c865:	e8 26 a2 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c86a:	48 89 c7             	mov    %rax,%rdi
    c86d:	e8 8e a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c872:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c879:	00 
    c87a:	bf 01 00 00 00       	mov    $0x1,%edi
    c87f:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    c886:	00 
    c887:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c88e:	00 
    c88f:	e8 fc a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c894:	48 89 c7             	mov    %rax,%rdi
    c897:	e8 64 a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c89c:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c8a3:	00 
    c8a4:	bf 01 00 00 00       	mov    $0x1,%edi
    c8a9:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    c8b0:	00 
    c8b1:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c8b8:	00 
    c8b9:	e8 d2 a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c8be:	48 89 c7             	mov    %rax,%rdi
    c8c1:	e8 3a a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c8c6:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c8cd:	00 
    c8ce:	bf 01 00 00 00       	mov    $0x1,%edi
    c8d3:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    c8da:	00 
    c8db:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c8e2:	00 
    c8e3:	e8 a8 a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c8e8:	48 89 c7             	mov    %rax,%rdi
    c8eb:	e8 10 a4 ff ff       	call   6d00 <fwp_rc_fresh>
    c8f0:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c8f7:	00 
    c8f8:	bf 01 00 00 00       	mov    $0x1,%edi
    c8fd:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    c904:	00 
    c905:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c90c:	00 
    c90d:	e8 7e a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c912:	48 89 c7             	mov    %rax,%rdi
    c915:	e8 e6 a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c91a:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c921:	00 
    c922:	bf 01 00 00 00       	mov    $0x1,%edi
    c927:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    c92e:	00 
    c92f:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c936:	00 
    c937:	e8 54 a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c93c:	48 89 c7             	mov    %rax,%rdi
    c93f:	e8 bc a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c944:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c94b:	00 
    c94c:	bf 01 00 00 00       	mov    $0x1,%edi
    c951:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    c958:	00 
    c959:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c960:	00 
    c961:	e8 2a a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c966:	48 89 c7             	mov    %rax,%rdi
    c969:	e8 92 a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c96e:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c975:	00 
    c976:	bf 01 00 00 00       	mov    $0x1,%edi
    c97b:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    c982:	00 
    c983:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c98a:	00 
    c98b:	e8 00 a1 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c990:	48 89 c7             	mov    %rax,%rdi
    c993:	e8 68 a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c998:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c99f:	00 
    c9a0:	bf 01 00 00 00       	mov    $0x1,%edi
    c9a5:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    c9ac:	00 
    c9ad:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c9b4:	00 
    c9b5:	e8 d6 a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c9ba:	48 89 c7             	mov    %rax,%rdi
    c9bd:	e8 3e a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c9c2:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c9c9:	00 
    c9ca:	bf 01 00 00 00       	mov    $0x1,%edi
    c9cf:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    c9d6:	00 
    c9d7:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c9de:	00 
    c9df:	e8 ac a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    c9e4:	48 89 c7             	mov    %rax,%rdi
    c9e7:	e8 14 a3 ff ff       	call   6d00 <fwp_rc_fresh>
    c9ec:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c9f3:	00 
    c9f4:	bf 01 00 00 00       	mov    $0x1,%edi
    c9f9:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    ca00:	00 
    ca01:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    ca08:	00 
    ca09:	e8 82 a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ca0e:	48 89 c7             	mov    %rax,%rdi
    ca11:	e8 ea a2 ff ff       	call   6d00 <fwp_rc_fresh>
    ca16:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    ca1d:	00 
    ca1e:	bf 01 00 00 00       	mov    $0x1,%edi
    ca23:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    ca2a:	00 
    ca2b:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    ca32:	00 
    ca33:	e8 58 a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ca38:	48 89 c7             	mov    %rax,%rdi
    ca3b:	e8 c0 a2 ff ff       	call   6d00 <fwp_rc_fresh>
    ca40:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    ca47:	00 
    ca48:	bf 01 00 00 00       	mov    $0x1,%edi
    ca4d:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    ca54:	00 
    ca55:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    ca5c:	00 
    ca5d:	e8 2e a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ca62:	48 89 c7             	mov    %rax,%rdi
    ca65:	e8 96 a2 ff ff       	call   6d00 <fwp_rc_fresh>
    ca6a:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    ca71:	00 
    ca72:	bf 01 00 00 00       	mov    $0x1,%edi
    ca77:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    ca7e:	00 
    ca7f:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    ca86:	00 
    ca87:	e8 04 a0 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ca8c:	48 89 c7             	mov    %rax,%rdi
    ca8f:	e8 6c a2 ff ff       	call   6d00 <fwp_rc_fresh>
    ca94:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    ca9b:	00 
    ca9c:	bf 01 00 00 00       	mov    $0x1,%edi
    caa1:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    caa8:	00 
    caa9:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    cab0:	00 
    cab1:	e8 da 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cab6:	48 89 c7             	mov    %rax,%rdi
    cab9:	e8 42 a2 ff ff       	call   6d00 <fwp_rc_fresh>
    cabe:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    cac5:	00 
    cac6:	bf 01 00 00 00       	mov    $0x1,%edi
    cacb:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    cad2:	00 
    cad3:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    cada:	00 
    cadb:	e8 b0 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cae0:	48 89 c7             	mov    %rax,%rdi
    cae3:	e8 18 a2 ff ff       	call   6d00 <fwp_rc_fresh>
    cae8:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    caef:	00 
    caf0:	bf 01 00 00 00       	mov    $0x1,%edi
    caf5:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    cafc:	00 
    cafd:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    cb04:	00 
    cb05:	e8 86 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cb0a:	48 89 c7             	mov    %rax,%rdi
    cb0d:	e8 ee a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cb12:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    cb19:	00 
    cb1a:	bf 01 00 00 00       	mov    $0x1,%edi
    cb1f:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    cb26:	00 
    cb27:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    cb2e:	00 
    cb2f:	e8 5c 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cb34:	48 89 c7             	mov    %rax,%rdi
    cb37:	e8 c4 a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cb3c:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    cb43:	00 
    cb44:	bf 01 00 00 00       	mov    $0x1,%edi
    cb49:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    cb50:	00 
    cb51:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    cb58:	00 
    cb59:	e8 32 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cb5e:	48 89 c7             	mov    %rax,%rdi
    cb61:	e8 9a a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cb66:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    cb6d:	00 
    cb6e:	bf 01 00 00 00       	mov    $0x1,%edi
    cb73:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    cb7a:	00 
    cb7b:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    cb82:	00 
    cb83:	e8 08 9f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cb88:	48 89 c7             	mov    %rax,%rdi
    cb8b:	e8 70 a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cb90:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    cb97:	00 
    cb98:	bf 01 00 00 00       	mov    $0x1,%edi
    cb9d:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    cba4:	00 
    cba5:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    cbac:	00 
    cbad:	e8 de 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cbb2:	48 89 c7             	mov    %rax,%rdi
    cbb5:	e8 46 a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cbba:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    cbc1:	00 
    cbc2:	bf 01 00 00 00       	mov    $0x1,%edi
    cbc7:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    cbce:	00 
    cbcf:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    cbd6:	00 
    cbd7:	e8 b4 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cbdc:	48 89 c7             	mov    %rax,%rdi
    cbdf:	e8 1c a1 ff ff       	call   6d00 <fwp_rc_fresh>
    cbe4:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    cbeb:	00 
    cbec:	bf 01 00 00 00       	mov    $0x1,%edi
    cbf1:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    cbf8:	00 
    cbf9:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    cc00:	00 
    cc01:	e8 8a 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cc06:	48 89 c7             	mov    %rax,%rdi
    cc09:	e8 f2 a0 ff ff       	call   6d00 <fwp_rc_fresh>
    cc0e:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    cc15:	00 
    cc16:	bf 01 00 00 00       	mov    $0x1,%edi
    cc1b:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    cc22:	00 
    cc23:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    cc2a:	00 
    cc2b:	e8 60 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cc30:	48 89 c7             	mov    %rax,%rdi
    cc33:	e8 c8 a0 ff ff       	call   6d00 <fwp_rc_fresh>
    cc38:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    cc3f:	00 
    cc40:	bf 01 00 00 00       	mov    $0x1,%edi
    cc45:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    cc4c:	00 
    cc4d:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    cc54:	00 
    cc55:	e8 36 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cc5a:	48 89 c7             	mov    %rax,%rdi
    cc5d:	e8 9e a0 ff ff       	call   6d00 <fwp_rc_fresh>
    cc62:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    cc69:	00 
    cc6a:	bf 01 00 00 00       	mov    $0x1,%edi
    cc6f:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    cc76:	00 
    cc77:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    cc7e:	00 
    cc7f:	e8 0c 9e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cc84:	48 89 c7             	mov    %rax,%rdi
    cc87:	e8 74 a0 ff ff       	call   6d00 <fwp_rc_fresh>
    cc8c:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    cc93:	00 
    cc94:	bf 01 00 00 00       	mov    $0x1,%edi
    cc99:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    cca0:	00 
    cca1:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    cca8:	00 
    cca9:	e8 e2 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ccae:	48 89 c7             	mov    %rax,%rdi
    ccb1:	e8 4a a0 ff ff       	call   6d00 <fwp_rc_fresh>
    ccb6:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    ccbd:	00 
    ccbe:	bf 01 00 00 00       	mov    $0x1,%edi
    ccc3:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    ccca:	00 
    cccb:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    ccd2:	00 
    ccd3:	e8 b8 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ccd8:	48 89 c7             	mov    %rax,%rdi
    ccdb:	e8 20 a0 ff ff       	call   6d00 <fwp_rc_fresh>
    cce0:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    cce7:	00 
    cce8:	bf 01 00 00 00       	mov    $0x1,%edi
    cced:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    ccf4:	00 
    ccf5:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    ccfc:	00 
    ccfd:	e8 8e 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cd02:	48 89 c7             	mov    %rax,%rdi
    cd05:	e8 f6 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cd0a:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    cd11:	00 
    cd12:	bf 01 00 00 00       	mov    $0x1,%edi
    cd17:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    cd1e:	00 
    cd1f:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    cd26:	00 
    cd27:	e8 64 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cd2c:	48 89 c7             	mov    %rax,%rdi
    cd2f:	e8 cc 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cd34:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    cd3b:	00 
    cd3c:	bf 01 00 00 00       	mov    $0x1,%edi
    cd41:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    cd48:	00 
    cd49:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    cd50:	00 
    cd51:	e8 3a 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cd56:	48 89 c7             	mov    %rax,%rdi
    cd59:	e8 a2 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cd5e:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    cd65:	00 
    cd66:	bf 01 00 00 00       	mov    $0x1,%edi
    cd6b:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    cd72:	00 
    cd73:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    cd7a:	00 
    cd7b:	e8 10 9d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cd80:	48 89 c7             	mov    %rax,%rdi
    cd83:	e8 78 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cd88:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    cd8f:	00 
    cd90:	bf 01 00 00 00       	mov    $0x1,%edi
    cd95:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    cd9c:	00 
    cd9d:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    cda4:	00 
    cda5:	e8 e6 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cdaa:	48 89 c7             	mov    %rax,%rdi
    cdad:	e8 4e 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cdb2:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    cdb9:	00 
    cdba:	bf 01 00 00 00       	mov    $0x1,%edi
    cdbf:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    cdc6:	00 
    cdc7:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    cdce:	00 
    cdcf:	e8 bc 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cdd4:	48 89 c7             	mov    %rax,%rdi
    cdd7:	e8 24 9f ff ff       	call   6d00 <fwp_rc_fresh>
    cddc:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    cde3:	00 
    cde4:	bf 01 00 00 00       	mov    $0x1,%edi
    cde9:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    cdf0:	00 
    cdf1:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    cdf8:	00 
    cdf9:	e8 92 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cdfe:	48 89 c7             	mov    %rax,%rdi
    ce01:	e8 fa 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ce06:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    ce0d:	00 
    ce0e:	bf 01 00 00 00       	mov    $0x1,%edi
    ce13:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    ce1a:	00 
    ce1b:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    ce22:	00 
    ce23:	e8 68 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ce28:	48 89 c7             	mov    %rax,%rdi
    ce2b:	e8 d0 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ce30:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    ce37:	00 
    ce38:	bf 01 00 00 00       	mov    $0x1,%edi
    ce3d:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    ce44:	00 
    ce45:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    ce4c:	00 
    ce4d:	e8 3e 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ce52:	48 89 c7             	mov    %rax,%rdi
    ce55:	e8 a6 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ce5a:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    ce61:	00 
    ce62:	bf 01 00 00 00       	mov    $0x1,%edi
    ce67:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    ce6e:	00 
    ce6f:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    ce76:	00 
    ce77:	e8 14 9c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ce7c:	48 89 c7             	mov    %rax,%rdi
    ce7f:	e8 7c 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ce84:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    ce8b:	00 
    ce8c:	bf 01 00 00 00       	mov    $0x1,%edi
    ce91:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    ce98:	00 
    ce99:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    cea0:	00 
    cea1:	e8 ea 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cea6:	48 89 c7             	mov    %rax,%rdi
    cea9:	e8 52 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ceae:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    ceb5:	00 
    ceb6:	bf 01 00 00 00       	mov    $0x1,%edi
    cebb:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    cec2:	00 
    cec3:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    ceca:	00 
    cecb:	e8 c0 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    ced0:	48 89 c7             	mov    %rax,%rdi
    ced3:	e8 28 9e ff ff       	call   6d00 <fwp_rc_fresh>
    ced8:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    cedf:	00 
    cee0:	bf 01 00 00 00       	mov    $0x1,%edi
    cee5:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    ceec:	00 
    ceed:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    cef4:	00 
    cef5:	e8 96 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cefa:	48 89 c7             	mov    %rax,%rdi
    cefd:	e8 fe 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cf02:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    cf09:	00 
    cf0a:	bf 01 00 00 00       	mov    $0x1,%edi
    cf0f:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    cf16:	00 
    cf17:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    cf1e:	00 
    cf1f:	e8 6c 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cf24:	48 89 c7             	mov    %rax,%rdi
    cf27:	e8 d4 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cf2c:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    cf33:	00 
    cf34:	bf 01 00 00 00       	mov    $0x1,%edi
    cf39:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    cf40:	00 
    cf41:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    cf48:	00 
    cf49:	e8 42 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cf4e:	48 89 c7             	mov    %rax,%rdi
    cf51:	e8 aa 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cf56:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    cf5d:	00 
    cf5e:	bf 01 00 00 00       	mov    $0x1,%edi
    cf63:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    cf6a:	00 
    cf6b:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    cf72:	00 
    cf73:	e8 18 9b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cf78:	48 89 c7             	mov    %rax,%rdi
    cf7b:	e8 80 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cf80:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    cf87:	00 
    cf88:	bf 01 00 00 00       	mov    $0x1,%edi
    cf8d:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    cf94:	00 
    cf95:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    cf9c:	00 
    cf9d:	e8 ee 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cfa2:	48 89 c7             	mov    %rax,%rdi
    cfa5:	e8 56 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cfaa:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    cfb1:	00 
    cfb2:	bf 01 00 00 00       	mov    $0x1,%edi
    cfb7:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    cfbe:	00 
    cfbf:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    cfc6:	00 
    cfc7:	e8 c4 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cfcc:	48 89 c7             	mov    %rax,%rdi
    cfcf:	e8 2c 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cfd4:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    cfdb:	00 
    cfdc:	bf 01 00 00 00       	mov    $0x1,%edi
    cfe1:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    cfe8:	00 
    cfe9:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    cff0:	00 
    cff1:	e8 9a 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    cff6:	48 89 c7             	mov    %rax,%rdi
    cff9:	e8 02 9d ff ff       	call   6d00 <fwp_rc_fresh>
    cffe:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    d005:	00 
    d006:	bf 01 00 00 00       	mov    $0x1,%edi
    d00b:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    d012:	00 
    d013:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    d01a:	00 
    d01b:	e8 70 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d020:	48 89 c7             	mov    %rax,%rdi
    d023:	e8 d8 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d028:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    d02f:	00 
    d030:	bf 01 00 00 00       	mov    $0x1,%edi
    d035:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    d03c:	00 
    d03d:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    d044:	00 
    d045:	e8 46 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d04a:	48 89 c7             	mov    %rax,%rdi
    d04d:	e8 ae 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d052:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    d059:	00 
    d05a:	bf 01 00 00 00       	mov    $0x1,%edi
    d05f:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    d066:	00 
    d067:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    d06e:	00 
    d06f:	e8 1c 9a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d074:	48 89 c7             	mov    %rax,%rdi
    d077:	e8 84 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d07c:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    d083:	00 
    d084:	bf 01 00 00 00       	mov    $0x1,%edi
    d089:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    d090:	00 
    d091:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    d098:	00 
    d099:	e8 f2 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d09e:	48 89 c7             	mov    %rax,%rdi
    d0a1:	e8 5a 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d0a6:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    d0ad:	00 
    d0ae:	bf 01 00 00 00       	mov    $0x1,%edi
    d0b3:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    d0ba:	00 
    d0bb:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    d0c2:	00 
    d0c3:	e8 c8 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d0c8:	48 89 c7             	mov    %rax,%rdi
    d0cb:	e8 30 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d0d0:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    d0d7:	00 
    d0d8:	bf 01 00 00 00       	mov    $0x1,%edi
    d0dd:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    d0e4:	00 
    d0e5:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    d0ec:	00 
    d0ed:	e8 9e 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d0f2:	48 89 c7             	mov    %rax,%rdi
    d0f5:	e8 06 9c ff ff       	call   6d00 <fwp_rc_fresh>
    d0fa:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    d101:	00 
    d102:	bf 01 00 00 00       	mov    $0x1,%edi
    d107:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    d10e:	00 
    d10f:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    d116:	00 
    d117:	e8 74 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d11c:	48 89 c7             	mov    %rax,%rdi
    d11f:	e8 dc 9b ff ff       	call   6d00 <fwp_rc_fresh>
    d124:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    d12b:	00 
    d12c:	bf 01 00 00 00       	mov    $0x1,%edi
    d131:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    d138:	00 
    d139:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    d140:	00 
    d141:	e8 4a 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d146:	48 89 c7             	mov    %rax,%rdi
    d149:	e8 b2 9b ff ff       	call   6d00 <fwp_rc_fresh>
    d14e:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    d155:	00 
    d156:	bf 01 00 00 00       	mov    $0x1,%edi
    d15b:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    d162:	00 
    d163:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    d16a:	00 
    d16b:	e8 20 99 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d170:	48 89 c7             	mov    %rax,%rdi
    d173:	e8 88 9b ff ff       	call   6d00 <fwp_rc_fresh>
    d178:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    d17f:	00 
    d180:	bf 01 00 00 00       	mov    $0x1,%edi
    d185:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    d18c:	00 
    d18d:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    d194:	00 
    d195:	e8 f6 98 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d19a:	48 89 c7             	mov    %rax,%rdi
    d19d:	e8 5e 9b ff ff       	call   6d00 <fwp_rc_fresh>
    d1a2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    d1a9:	00 
    d1aa:	bf 01 00 00 00       	mov    $0x1,%edi
    d1af:	4c 89 a4 24 40 06 00 	mov    %r12,0x640(%rsp)
    d1b6:	00 
    d1b7:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    d1be:	00 
    d1bf:	e8 cc 98 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d1c4:	48 8b 15 4d 0a 06 00 	mov    0x60a4d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d1cb:	49 89 c5             	mov    %rax,%r13
    d1ce:	48 2b 05 1b 0a 06 00 	sub    0x60a1b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d1d5:	48 c1 e2 10          	shl    $0x10,%rdx
    d1d9:	48 39 d0             	cmp    %rdx,%rax
    d1dc:	73 59                	jae    d237 <f0+0x1457>
    d1de:	48 89 c2             	mov    %rax,%rdx
    d1e1:	48 c1 ea 10          	shr    $0x10,%rdx
    d1e5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1e9:	48 8b 15 48 0a 06 00 	mov    0x60a48(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d1f0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1f4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1f8:	4d 85 e4             	test   %r12,%r12
    d1fb:	74 3a                	je     d237 <f0+0x1457>
    d1fd:	0f b6 0a             	movzbl (%rdx),%ecx
    d200:	80 f9 02             	cmp    $0x2,%cl
    d203:	0f 84 17 15 00 00    	je     e720 <f0+0x2940>
    d209:	80 f9 01             	cmp    $0x1,%cl
    d20c:	75 29                	jne    d237 <f0+0x1457>
    d20e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d211:	0f b7 c0             	movzwl %ax,%eax
    d214:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d217:	48 0f af c1          	imul   %rcx,%rax
    d21b:	48 c1 e8 20          	shr    $0x20,%rax
    d21f:	48 39 d0             	cmp    %rdx,%rax
    d222:	73 13                	jae    d237 <f0+0x1457>
    d224:	49 01 c4             	add    %rax,%r12
    d227:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d22c:	0f 84 07 17 00 00    	je     e939 <f0+0x2b59>
    d232:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d237:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d23e:	00 f0 3f 
    d241:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    d248:	00 
    d249:	bf 01 00 00 00       	mov    $0x1,%edi
    d24e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    d255:	00 
    d256:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    d25d:	00 
    d25e:	e8 2d 98 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d263:	48 8b 15 ae 09 06 00 	mov    0x609ae(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d26a:	49 89 c5             	mov    %rax,%r13
    d26d:	48 2b 05 7c 09 06 00 	sub    0x6097c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d274:	48 c1 e2 10          	shl    $0x10,%rdx
    d278:	48 39 d0             	cmp    %rdx,%rax
    d27b:	73 59                	jae    d2d6 <f0+0x14f6>
    d27d:	48 89 c2             	mov    %rax,%rdx
    d280:	48 c1 ea 10          	shr    $0x10,%rdx
    d284:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d288:	48 8b 15 a9 09 06 00 	mov    0x609a9(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d28f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d293:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d297:	4d 85 e4             	test   %r12,%r12
    d29a:	74 3a                	je     d2d6 <f0+0x14f6>
    d29c:	0f b6 0a             	movzbl (%rdx),%ecx
    d29f:	80 f9 02             	cmp    $0x2,%cl
    d2a2:	0f 84 28 15 00 00    	je     e7d0 <f0+0x29f0>
    d2a8:	80 f9 01             	cmp    $0x1,%cl
    d2ab:	75 29                	jne    d2d6 <f0+0x14f6>
    d2ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2b0:	0f b7 c0             	movzwl %ax,%eax
    d2b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2b6:	48 0f af c1          	imul   %rcx,%rax
    d2ba:	48 c1 e8 20          	shr    $0x20,%rax
    d2be:	48 39 d0             	cmp    %rdx,%rax
    d2c1:	73 13                	jae    d2d6 <f0+0x14f6>
    d2c3:	49 01 c4             	add    %rax,%r12
    d2c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2cb:	0f 84 75 16 00 00    	je     e946 <f0+0x2b66>
    d2d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2d6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2dd:	33 f3 bf 
    d2e0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    d2e7:	00 
    d2e8:	bf 01 00 00 00       	mov    $0x1,%edi
    d2ed:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    d2f4:	00 
    d2f5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    d2fc:	00 
    d2fd:	e8 8e 97 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d302:	48 8b 15 0f 09 06 00 	mov    0x6090f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d309:	49 89 c5             	mov    %rax,%r13
    d30c:	48 2b 05 dd 08 06 00 	sub    0x608dd(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d313:	48 c1 e2 10          	shl    $0x10,%rdx
    d317:	48 39 d0             	cmp    %rdx,%rax
    d31a:	73 59                	jae    d375 <f0+0x1595>
    d31c:	48 89 c2             	mov    %rax,%rdx
    d31f:	48 c1 ea 10          	shr    $0x10,%rdx
    d323:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d327:	48 8b 15 0a 09 06 00 	mov    0x6090a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d32e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d332:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d336:	4d 85 e4             	test   %r12,%r12
    d339:	74 3a                	je     d375 <f0+0x1595>
    d33b:	0f b6 0a             	movzbl (%rdx),%ecx
    d33e:	80 f9 02             	cmp    $0x2,%cl
    d341:	0f 84 79 14 00 00    	je     e7c0 <f0+0x29e0>
    d347:	80 f9 01             	cmp    $0x1,%cl
    d34a:	75 29                	jne    d375 <f0+0x1595>
    d34c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d34f:	0f b7 c0             	movzwl %ax,%eax
    d352:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d355:	48 0f af c1          	imul   %rcx,%rax
    d359:	48 c1 e8 20          	shr    $0x20,%rax
    d35d:	48 39 d0             	cmp    %rdx,%rax
    d360:	73 13                	jae    d375 <f0+0x1595>
    d362:	49 01 c4             	add    %rax,%r12
    d365:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d36a:	0f 84 e3 15 00 00    	je     e953 <f0+0x2b73>
    d370:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d375:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d37c:	00 f0 3f 
    d37f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    d386:	00 
    d387:	bf 01 00 00 00       	mov    $0x1,%edi
    d38c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    d393:	00 
    d394:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    d39b:	00 
    d39c:	e8 ef 96 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d3a1:	48 8b 15 70 08 06 00 	mov    0x60870(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d3a8:	49 89 c5             	mov    %rax,%r13
    d3ab:	48 2b 05 3e 08 06 00 	sub    0x6083e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d3b2:	48 c1 e2 10          	shl    $0x10,%rdx
    d3b6:	48 39 d0             	cmp    %rdx,%rax
    d3b9:	73 59                	jae    d414 <f0+0x1634>
    d3bb:	48 89 c2             	mov    %rax,%rdx
    d3be:	48 c1 ea 10          	shr    $0x10,%rdx
    d3c2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3c6:	48 8b 15 6b 08 06 00 	mov    0x6086b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d3cd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3d1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3d5:	4d 85 e4             	test   %r12,%r12
    d3d8:	74 3a                	je     d414 <f0+0x1634>
    d3da:	0f b6 0a             	movzbl (%rdx),%ecx
    d3dd:	80 f9 02             	cmp    $0x2,%cl
    d3e0:	0f 84 ca 13 00 00    	je     e7b0 <f0+0x29d0>
    d3e6:	80 f9 01             	cmp    $0x1,%cl
    d3e9:	75 29                	jne    d414 <f0+0x1634>
    d3eb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3ee:	0f b7 c0             	movzwl %ax,%eax
    d3f1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3f4:	48 0f af c1          	imul   %rcx,%rax
    d3f8:	48 c1 e8 20          	shr    $0x20,%rax
    d3fc:	48 39 d0             	cmp    %rdx,%rax
    d3ff:	73 13                	jae    d414 <f0+0x1634>
    d401:	49 01 c4             	add    %rax,%r12
    d404:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d409:	0f 84 51 15 00 00    	je     e960 <f0+0x2b80>
    d40f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d414:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d41b:	33 f3 bf 
    d41e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    d425:	00 
    d426:	bf 01 00 00 00       	mov    $0x1,%edi
    d42b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    d432:	00 
    d433:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    d43a:	00 
    d43b:	e8 50 96 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d440:	48 8b 15 d1 07 06 00 	mov    0x607d1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d447:	49 89 c5             	mov    %rax,%r13
    d44a:	48 2b 05 9f 07 06 00 	sub    0x6079f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d451:	48 c1 e2 10          	shl    $0x10,%rdx
    d455:	48 39 d0             	cmp    %rdx,%rax
    d458:	73 59                	jae    d4b3 <f0+0x16d3>
    d45a:	48 89 c2             	mov    %rax,%rdx
    d45d:	48 c1 ea 10          	shr    $0x10,%rdx
    d461:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d465:	48 8b 15 cc 07 06 00 	mov    0x607cc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d46c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d470:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d474:	4d 85 e4             	test   %r12,%r12
    d477:	74 3a                	je     d4b3 <f0+0x16d3>
    d479:	0f b6 0a             	movzbl (%rdx),%ecx
    d47c:	80 f9 02             	cmp    $0x2,%cl
    d47f:	0f 84 1b 13 00 00    	je     e7a0 <f0+0x29c0>
    d485:	80 f9 01             	cmp    $0x1,%cl
    d488:	75 29                	jne    d4b3 <f0+0x16d3>
    d48a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d48d:	0f b7 c0             	movzwl %ax,%eax
    d490:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d493:	48 0f af c1          	imul   %rcx,%rax
    d497:	48 c1 e8 20          	shr    $0x20,%rax
    d49b:	48 39 d0             	cmp    %rdx,%rax
    d49e:	73 13                	jae    d4b3 <f0+0x16d3>
    d4a0:	49 01 c4             	add    %rax,%r12
    d4a3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4a8:	0f 84 bf 14 00 00    	je     e96d <f0+0x2b8d>
    d4ae:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4b3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4ba:	00 f0 3f 
    d4bd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d4c4:	00 
    d4c5:	bf 01 00 00 00       	mov    $0x1,%edi
    d4ca:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d4d1:	00 
    d4d2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d4d9:	00 
    d4da:	e8 b1 95 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d4df:	48 8b 15 32 07 06 00 	mov    0x60732(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d4e6:	49 89 c5             	mov    %rax,%r13
    d4e9:	48 2b 05 00 07 06 00 	sub    0x60700(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d4f0:	48 c1 e2 10          	shl    $0x10,%rdx
    d4f4:	48 39 d0             	cmp    %rdx,%rax
    d4f7:	73 59                	jae    d552 <f0+0x1772>
    d4f9:	48 89 c2             	mov    %rax,%rdx
    d4fc:	48 c1 ea 10          	shr    $0x10,%rdx
    d500:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d504:	48 8b 15 2d 07 06 00 	mov    0x6072d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d50b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d50f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d513:	4d 85 e4             	test   %r12,%r12
    d516:	74 3a                	je     d552 <f0+0x1772>
    d518:	0f b6 0a             	movzbl (%rdx),%ecx
    d51b:	80 f9 02             	cmp    $0x2,%cl
    d51e:	0f 84 6c 12 00 00    	je     e790 <f0+0x29b0>
    d524:	80 f9 01             	cmp    $0x1,%cl
    d527:	75 29                	jne    d552 <f0+0x1772>
    d529:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d52c:	0f b7 c0             	movzwl %ax,%eax
    d52f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d532:	48 0f af c1          	imul   %rcx,%rax
    d536:	48 c1 e8 20          	shr    $0x20,%rax
    d53a:	48 39 d0             	cmp    %rdx,%rax
    d53d:	73 13                	jae    d552 <f0+0x1772>
    d53f:	49 01 c4             	add    %rax,%r12
    d542:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d547:	0f 84 2d 14 00 00    	je     e97a <f0+0x2b9a>
    d54d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d552:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d559:	33 f3 bf 
    d55c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d563:	00 
    d564:	bf 01 00 00 00       	mov    $0x1,%edi
    d569:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d570:	00 
    d571:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d578:	00 
    d579:	e8 12 95 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d57e:	48 8b 15 93 06 06 00 	mov    0x60693(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d585:	49 89 c5             	mov    %rax,%r13
    d588:	48 2b 05 61 06 06 00 	sub    0x60661(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d58f:	48 c1 e2 10          	shl    $0x10,%rdx
    d593:	48 39 d0             	cmp    %rdx,%rax
    d596:	73 59                	jae    d5f1 <f0+0x1811>
    d598:	48 89 c2             	mov    %rax,%rdx
    d59b:	48 c1 ea 10          	shr    $0x10,%rdx
    d59f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5a3:	48 8b 15 8e 06 06 00 	mov    0x6068e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d5aa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5ae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5b2:	4d 85 e4             	test   %r12,%r12
    d5b5:	74 3a                	je     d5f1 <f0+0x1811>
    d5b7:	0f b6 0a             	movzbl (%rdx),%ecx
    d5ba:	80 f9 02             	cmp    $0x2,%cl
    d5bd:	0f 84 bd 11 00 00    	je     e780 <f0+0x29a0>
    d5c3:	80 f9 01             	cmp    $0x1,%cl
    d5c6:	75 29                	jne    d5f1 <f0+0x1811>
    d5c8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5cb:	0f b7 c0             	movzwl %ax,%eax
    d5ce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5d1:	48 0f af c1          	imul   %rcx,%rax
    d5d5:	48 c1 e8 20          	shr    $0x20,%rax
    d5d9:	48 39 d0             	cmp    %rdx,%rax
    d5dc:	73 13                	jae    d5f1 <f0+0x1811>
    d5de:	49 01 c4             	add    %rax,%r12
    d5e1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5e6:	0f 84 9b 13 00 00    	je     e987 <f0+0x2ba7>
    d5ec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5f1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5f8:	00 f0 3f 
    d5fb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d602:	00 
    d603:	bf 01 00 00 00       	mov    $0x1,%edi
    d608:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d60f:	00 
    d610:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d617:	00 
    d618:	e8 73 94 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d61d:	48 8b 15 f4 05 06 00 	mov    0x605f4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d624:	49 89 c5             	mov    %rax,%r13
    d627:	48 2b 05 c2 05 06 00 	sub    0x605c2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d62e:	48 c1 e2 10          	shl    $0x10,%rdx
    d632:	48 39 d0             	cmp    %rdx,%rax
    d635:	73 59                	jae    d690 <f0+0x18b0>
    d637:	48 89 c2             	mov    %rax,%rdx
    d63a:	48 c1 ea 10          	shr    $0x10,%rdx
    d63e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d642:	48 8b 15 ef 05 06 00 	mov    0x605ef(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d649:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d64d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d651:	4d 85 e4             	test   %r12,%r12
    d654:	74 3a                	je     d690 <f0+0x18b0>
    d656:	0f b6 0a             	movzbl (%rdx),%ecx
    d659:	80 f9 02             	cmp    $0x2,%cl
    d65c:	0f 84 0e 11 00 00    	je     e770 <f0+0x2990>
    d662:	80 f9 01             	cmp    $0x1,%cl
    d665:	75 29                	jne    d690 <f0+0x18b0>
    d667:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d66a:	0f b7 c0             	movzwl %ax,%eax
    d66d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d670:	48 0f af c1          	imul   %rcx,%rax
    d674:	48 c1 e8 20          	shr    $0x20,%rax
    d678:	48 39 d0             	cmp    %rdx,%rax
    d67b:	73 13                	jae    d690 <f0+0x18b0>
    d67d:	49 01 c4             	add    %rax,%r12
    d680:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d685:	0f 84 09 13 00 00    	je     e994 <f0+0x2bb4>
    d68b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d690:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d697:	33 f3 bf 
    d69a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d6a1:	00 
    d6a2:	bf 01 00 00 00       	mov    $0x1,%edi
    d6a7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d6ae:	00 
    d6af:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d6b6:	00 
    d6b7:	e8 d4 93 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d6bc:	48 8b 15 55 05 06 00 	mov    0x60555(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d6c3:	49 89 c5             	mov    %rax,%r13
    d6c6:	48 2b 05 23 05 06 00 	sub    0x60523(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d6cd:	48 c1 e2 10          	shl    $0x10,%rdx
    d6d1:	48 39 d0             	cmp    %rdx,%rax
    d6d4:	73 59                	jae    d72f <f0+0x194f>
    d6d6:	48 89 c2             	mov    %rax,%rdx
    d6d9:	48 c1 ea 10          	shr    $0x10,%rdx
    d6dd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6e1:	48 8b 15 50 05 06 00 	mov    0x60550(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d6e8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6ec:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6f0:	4d 85 e4             	test   %r12,%r12
    d6f3:	74 3a                	je     d72f <f0+0x194f>
    d6f5:	0f b6 0a             	movzbl (%rdx),%ecx
    d6f8:	80 f9 02             	cmp    $0x2,%cl
    d6fb:	0f 84 5f 10 00 00    	je     e760 <f0+0x2980>
    d701:	80 f9 01             	cmp    $0x1,%cl
    d704:	75 29                	jne    d72f <f0+0x194f>
    d706:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d709:	0f b7 c0             	movzwl %ax,%eax
    d70c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d70f:	48 0f af c1          	imul   %rcx,%rax
    d713:	48 c1 e8 20          	shr    $0x20,%rax
    d717:	48 39 d0             	cmp    %rdx,%rax
    d71a:	73 13                	jae    d72f <f0+0x194f>
    d71c:	49 01 c4             	add    %rax,%r12
    d71f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d724:	0f 84 77 12 00 00    	je     e9a1 <f0+0x2bc1>
    d72a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d72f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d736:	00 f0 3f 
    d739:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d740:	00 
    d741:	bf 01 00 00 00       	mov    $0x1,%edi
    d746:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d74d:	00 
    d74e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d755:	00 
    d756:	e8 35 93 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d75b:	48 8b 15 b6 04 06 00 	mov    0x604b6(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d762:	49 89 c5             	mov    %rax,%r13
    d765:	48 2b 05 84 04 06 00 	sub    0x60484(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d76c:	48 c1 e2 10          	shl    $0x10,%rdx
    d770:	48 39 d0             	cmp    %rdx,%rax
    d773:	73 59                	jae    d7ce <f0+0x19ee>
    d775:	48 89 c2             	mov    %rax,%rdx
    d778:	48 c1 ea 10          	shr    $0x10,%rdx
    d77c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d780:	48 8b 15 b1 04 06 00 	mov    0x604b1(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d787:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d78b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d78f:	4d 85 e4             	test   %r12,%r12
    d792:	74 3a                	je     d7ce <f0+0x19ee>
    d794:	0f b6 0a             	movzbl (%rdx),%ecx
    d797:	80 f9 02             	cmp    $0x2,%cl
    d79a:	0f 84 40 0f 00 00    	je     e6e0 <f0+0x2900>
    d7a0:	80 f9 01             	cmp    $0x1,%cl
    d7a3:	75 29                	jne    d7ce <f0+0x19ee>
    d7a5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7a8:	0f b7 c0             	movzwl %ax,%eax
    d7ab:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7ae:	48 0f af c1          	imul   %rcx,%rax
    d7b2:	48 c1 e8 20          	shr    $0x20,%rax
    d7b6:	48 39 d0             	cmp    %rdx,%rax
    d7b9:	73 13                	jae    d7ce <f0+0x19ee>
    d7bb:	49 01 c4             	add    %rax,%r12
    d7be:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7c3:	0f 84 e5 11 00 00    	je     e9ae <f0+0x2bce>
    d7c9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7ce:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7d5:	33 f3 bf 
    d7d8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d7df:	00 
    d7e0:	bf 01 00 00 00       	mov    $0x1,%edi
    d7e5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d7ec:	00 
    d7ed:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d7f4:	00 
    d7f5:	e8 96 92 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d7fa:	48 8b 15 17 04 06 00 	mov    0x60417(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d801:	49 89 c5             	mov    %rax,%r13
    d804:	48 2b 05 e5 03 06 00 	sub    0x603e5(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d80b:	48 c1 e2 10          	shl    $0x10,%rdx
    d80f:	48 39 d0             	cmp    %rdx,%rax
    d812:	73 59                	jae    d86d <f0+0x1a8d>
    d814:	48 89 c2             	mov    %rax,%rdx
    d817:	48 c1 ea 10          	shr    $0x10,%rdx
    d81b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d81f:	48 8b 15 12 04 06 00 	mov    0x60412(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d826:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d82a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d82e:	4d 85 e4             	test   %r12,%r12
    d831:	74 3a                	je     d86d <f0+0x1a8d>
    d833:	0f b6 0a             	movzbl (%rdx),%ecx
    d836:	80 f9 02             	cmp    $0x2,%cl
    d839:	0f 84 91 0e 00 00    	je     e6d0 <f0+0x28f0>
    d83f:	80 f9 01             	cmp    $0x1,%cl
    d842:	75 29                	jne    d86d <f0+0x1a8d>
    d844:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d847:	0f b7 c0             	movzwl %ax,%eax
    d84a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d84d:	48 0f af c1          	imul   %rcx,%rax
    d851:	48 c1 e8 20          	shr    $0x20,%rax
    d855:	48 39 d0             	cmp    %rdx,%rax
    d858:	73 13                	jae    d86d <f0+0x1a8d>
    d85a:	49 01 c4             	add    %rax,%r12
    d85d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d862:	0f 84 53 11 00 00    	je     e9bb <f0+0x2bdb>
    d868:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d86d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d874:	00 f0 3f 
    d877:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d87e:	00 
    d87f:	bf 01 00 00 00       	mov    $0x1,%edi
    d884:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d88b:	00 
    d88c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d893:	00 
    d894:	e8 f7 91 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d899:	48 8b 15 78 03 06 00 	mov    0x60378(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d8a0:	49 89 c5             	mov    %rax,%r13
    d8a3:	48 2b 05 46 03 06 00 	sub    0x60346(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d8aa:	48 c1 e2 10          	shl    $0x10,%rdx
    d8ae:	48 39 d0             	cmp    %rdx,%rax
    d8b1:	73 59                	jae    d90c <f0+0x1b2c>
    d8b3:	48 89 c2             	mov    %rax,%rdx
    d8b6:	48 c1 ea 10          	shr    $0x10,%rdx
    d8ba:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8be:	48 8b 15 73 03 06 00 	mov    0x60373(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d8c5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8c9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8cd:	4d 85 e4             	test   %r12,%r12
    d8d0:	74 3a                	je     d90c <f0+0x1b2c>
    d8d2:	0f b6 0a             	movzbl (%rdx),%ecx
    d8d5:	80 f9 02             	cmp    $0x2,%cl
    d8d8:	0f 84 e2 0d 00 00    	je     e6c0 <f0+0x28e0>
    d8de:	80 f9 01             	cmp    $0x1,%cl
    d8e1:	75 29                	jne    d90c <f0+0x1b2c>
    d8e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8e6:	0f b7 c0             	movzwl %ax,%eax
    d8e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8ec:	48 0f af c1          	imul   %rcx,%rax
    d8f0:	48 c1 e8 20          	shr    $0x20,%rax
    d8f4:	48 39 d0             	cmp    %rdx,%rax
    d8f7:	73 13                	jae    d90c <f0+0x1b2c>
    d8f9:	49 01 c4             	add    %rax,%r12
    d8fc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d901:	0f 84 c1 10 00 00    	je     e9c8 <f0+0x2be8>
    d907:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d90c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d913:	33 f3 bf 
    d916:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d91d:	00 
    d91e:	bf 01 00 00 00       	mov    $0x1,%edi
    d923:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d92a:	00 
    d92b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d932:	00 
    d933:	e8 58 91 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d938:	48 8b 15 d9 02 06 00 	mov    0x602d9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d93f:	49 89 c5             	mov    %rax,%r13
    d942:	48 2b 05 a7 02 06 00 	sub    0x602a7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d949:	48 c1 e2 10          	shl    $0x10,%rdx
    d94d:	48 39 d0             	cmp    %rdx,%rax
    d950:	73 59                	jae    d9ab <f0+0x1bcb>
    d952:	48 89 c2             	mov    %rax,%rdx
    d955:	48 c1 ea 10          	shr    $0x10,%rdx
    d959:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d95d:	48 8b 15 d4 02 06 00 	mov    0x602d4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d964:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d968:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d96c:	4d 85 e4             	test   %r12,%r12
    d96f:	74 3a                	je     d9ab <f0+0x1bcb>
    d971:	0f b6 0a             	movzbl (%rdx),%ecx
    d974:	80 f9 02             	cmp    $0x2,%cl
    d977:	0f 84 33 0d 00 00    	je     e6b0 <f0+0x28d0>
    d97d:	80 f9 01             	cmp    $0x1,%cl
    d980:	75 29                	jne    d9ab <f0+0x1bcb>
    d982:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d985:	0f b7 c0             	movzwl %ax,%eax
    d988:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d98b:	48 0f af c1          	imul   %rcx,%rax
    d98f:	48 c1 e8 20          	shr    $0x20,%rax
    d993:	48 39 d0             	cmp    %rdx,%rax
    d996:	73 13                	jae    d9ab <f0+0x1bcb>
    d998:	49 01 c4             	add    %rax,%r12
    d99b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9a0:	0f 84 2f 10 00 00    	je     e9d5 <f0+0x2bf5>
    d9a6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9ab:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9b2:	00 f0 3f 
    d9b5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d9bc:	00 
    d9bd:	bf 01 00 00 00       	mov    $0x1,%edi
    d9c2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d9c9:	00 
    d9ca:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d9d1:	00 
    d9d2:	e8 b9 90 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    d9d7:	48 8b 15 3a 02 06 00 	mov    0x6023a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d9de:	49 89 c5             	mov    %rax,%r13
    d9e1:	48 2b 05 08 02 06 00 	sub    0x60208(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d9e8:	48 c1 e2 10          	shl    $0x10,%rdx
    d9ec:	48 39 d0             	cmp    %rdx,%rax
    d9ef:	73 59                	jae    da4a <f0+0x1c6a>
    d9f1:	48 89 c2             	mov    %rax,%rdx
    d9f4:	48 c1 ea 10          	shr    $0x10,%rdx
    d9f8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9fc:	48 8b 15 35 02 06 00 	mov    0x60235(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    da03:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da07:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da0b:	4d 85 e4             	test   %r12,%r12
    da0e:	74 3a                	je     da4a <f0+0x1c6a>
    da10:	0f b6 0a             	movzbl (%rdx),%ecx
    da13:	80 f9 02             	cmp    $0x2,%cl
    da16:	0f 84 84 0c 00 00    	je     e6a0 <f0+0x28c0>
    da1c:	80 f9 01             	cmp    $0x1,%cl
    da1f:	75 29                	jne    da4a <f0+0x1c6a>
    da21:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da24:	0f b7 c0             	movzwl %ax,%eax
    da27:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da2a:	48 0f af c1          	imul   %rcx,%rax
    da2e:	48 c1 e8 20          	shr    $0x20,%rax
    da32:	48 39 d0             	cmp    %rdx,%rax
    da35:	73 13                	jae    da4a <f0+0x1c6a>
    da37:	49 01 c4             	add    %rax,%r12
    da3a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da3f:	0f 84 9d 0f 00 00    	je     e9e2 <f0+0x2c02>
    da45:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da4a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da51:	33 f3 bf 
    da54:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    da5b:	00 
    da5c:	bf 01 00 00 00       	mov    $0x1,%edi
    da61:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    da68:	00 
    da69:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    da70:	00 
    da71:	e8 1a 90 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    da76:	48 8b 15 9b 01 06 00 	mov    0x6019b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    da7d:	49 89 c5             	mov    %rax,%r13
    da80:	48 2b 05 69 01 06 00 	sub    0x60169(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    da87:	48 c1 e2 10          	shl    $0x10,%rdx
    da8b:	48 39 d0             	cmp    %rdx,%rax
    da8e:	73 59                	jae    dae9 <f0+0x1d09>
    da90:	48 89 c2             	mov    %rax,%rdx
    da93:	48 c1 ea 10          	shr    $0x10,%rdx
    da97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da9b:	48 8b 15 96 01 06 00 	mov    0x60196(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    daa2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    daa6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daaa:	4d 85 e4             	test   %r12,%r12
    daad:	74 3a                	je     dae9 <f0+0x1d09>
    daaf:	0f b6 0a             	movzbl (%rdx),%ecx
    dab2:	80 f9 02             	cmp    $0x2,%cl
    dab5:	0f 84 d5 0b 00 00    	je     e690 <f0+0x28b0>
    dabb:	80 f9 01             	cmp    $0x1,%cl
    dabe:	75 29                	jne    dae9 <f0+0x1d09>
    dac0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dac3:	0f b7 c0             	movzwl %ax,%eax
    dac6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dac9:	48 0f af c1          	imul   %rcx,%rax
    dacd:	48 c1 e8 20          	shr    $0x20,%rax
    dad1:	48 39 d0             	cmp    %rdx,%rax
    dad4:	73 13                	jae    dae9 <f0+0x1d09>
    dad6:	49 01 c4             	add    %rax,%r12
    dad9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dade:	0f 84 0b 0f 00 00    	je     e9ef <f0+0x2c0f>
    dae4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dae9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    daf0:	00 f0 3f 
    daf3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    dafa:	00 
    dafb:	bf 01 00 00 00       	mov    $0x1,%edi
    db00:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    db07:	00 
    db08:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    db0f:	00 
    db10:	e8 7b 8f ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    db15:	48 8b 15 fc 00 06 00 	mov    0x600fc(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    db1c:	49 89 c5             	mov    %rax,%r13
    db1f:	48 2b 05 ca 00 06 00 	sub    0x600ca(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    db26:	48 c1 e2 10          	shl    $0x10,%rdx
    db2a:	48 39 d0             	cmp    %rdx,%rax
    db2d:	73 59                	jae    db88 <f0+0x1da8>
    db2f:	48 89 c2             	mov    %rax,%rdx
    db32:	48 c1 ea 10          	shr    $0x10,%rdx
    db36:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db3a:	48 8b 15 f7 00 06 00 	mov    0x600f7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    db41:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db45:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db49:	4d 85 e4             	test   %r12,%r12
    db4c:	74 3a                	je     db88 <f0+0x1da8>
    db4e:	0f b6 0a             	movzbl (%rdx),%ecx
    db51:	80 f9 02             	cmp    $0x2,%cl
    db54:	0f 84 26 0b 00 00    	je     e680 <f0+0x28a0>
    db5a:	80 f9 01             	cmp    $0x1,%cl
    db5d:	75 29                	jne    db88 <f0+0x1da8>
    db5f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db62:	0f b7 c0             	movzwl %ax,%eax
    db65:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db68:	48 0f af c1          	imul   %rcx,%rax
    db6c:	48 c1 e8 20          	shr    $0x20,%rax
    db70:	48 39 d0             	cmp    %rdx,%rax
    db73:	73 13                	jae    db88 <f0+0x1da8>
    db75:	49 01 c4             	add    %rax,%r12
    db78:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db7d:	0f 84 79 0e 00 00    	je     e9fc <f0+0x2c1c>
    db83:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db88:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    db8f:	33 f3 bf 
    db92:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    db99:	00 
    db9a:	bf 01 00 00 00       	mov    $0x1,%edi
    db9f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    dba6:	00 
    dba7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    dbae:	00 
    dbaf:	e8 dc 8e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    dbb4:	48 8b 15 5d 00 06 00 	mov    0x6005d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dbbb:	49 89 c5             	mov    %rax,%r13
    dbbe:	48 2b 05 2b 00 06 00 	sub    0x6002b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dbc5:	48 c1 e2 10          	shl    $0x10,%rdx
    dbc9:	48 39 d0             	cmp    %rdx,%rax
    dbcc:	73 59                	jae    dc27 <f0+0x1e47>
    dbce:	48 89 c2             	mov    %rax,%rdx
    dbd1:	48 c1 ea 10          	shr    $0x10,%rdx
    dbd5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbd9:	48 8b 15 58 00 06 00 	mov    0x60058(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dbe0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbe4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbe8:	4d 85 e4             	test   %r12,%r12
    dbeb:	74 3a                	je     dc27 <f0+0x1e47>
    dbed:	0f b6 0a             	movzbl (%rdx),%ecx
    dbf0:	80 f9 02             	cmp    $0x2,%cl
    dbf3:	0f 84 77 0a 00 00    	je     e670 <f0+0x2890>
    dbf9:	80 f9 01             	cmp    $0x1,%cl
    dbfc:	75 29                	jne    dc27 <f0+0x1e47>
    dbfe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc01:	0f b7 c0             	movzwl %ax,%eax
    dc04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc07:	48 0f af c1          	imul   %rcx,%rax
    dc0b:	48 c1 e8 20          	shr    $0x20,%rax
    dc0f:	48 39 d0             	cmp    %rdx,%rax
    dc12:	73 13                	jae    dc27 <f0+0x1e47>
    dc14:	49 01 c4             	add    %rax,%r12
    dc17:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc1c:	0f 84 e7 0d 00 00    	je     ea09 <f0+0x2c29>
    dc22:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc27:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc2e:	00 f0 3f 
    dc31:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    dc38:	00 
    dc39:	bf 01 00 00 00       	mov    $0x1,%edi
    dc3e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    dc45:	00 
    dc46:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    dc4d:	00 
    dc4e:	e8 3d 8e ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    dc53:	48 8b 15 be ff 05 00 	mov    0x5ffbe(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dc5a:	49 89 c5             	mov    %rax,%r13
    dc5d:	48 2b 05 8c ff 05 00 	sub    0x5ff8c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dc64:	48 c1 e2 10          	shl    $0x10,%rdx
    dc68:	48 39 d0             	cmp    %rdx,%rax
    dc6b:	73 59                	jae    dcc6 <f0+0x1ee6>
    dc6d:	48 89 c2             	mov    %rax,%rdx
    dc70:	48 c1 ea 10          	shr    $0x10,%rdx
    dc74:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc78:	48 8b 15 b9 ff 05 00 	mov    0x5ffb9(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dc7f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc83:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc87:	4d 85 e4             	test   %r12,%r12
    dc8a:	74 3a                	je     dcc6 <f0+0x1ee6>
    dc8c:	0f b6 0a             	movzbl (%rdx),%ecx
    dc8f:	80 f9 02             	cmp    $0x2,%cl
    dc92:	0f 84 38 0c 00 00    	je     e8d0 <f0+0x2af0>
    dc98:	80 f9 01             	cmp    $0x1,%cl
    dc9b:	75 29                	jne    dcc6 <f0+0x1ee6>
    dc9d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dca0:	0f b7 c0             	movzwl %ax,%eax
    dca3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dca6:	48 0f af c1          	imul   %rcx,%rax
    dcaa:	48 c1 e8 20          	shr    $0x20,%rax
    dcae:	48 39 d0             	cmp    %rdx,%rax
    dcb1:	73 13                	jae    dcc6 <f0+0x1ee6>
    dcb3:	49 01 c4             	add    %rax,%r12
    dcb6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dcbb:	0f 84 55 0d 00 00    	je     ea16 <f0+0x2c36>
    dcc1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcc6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dccd:	33 f3 bf 
    dcd0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    dcd7:	00 
    dcd8:	bf 01 00 00 00       	mov    $0x1,%edi
    dcdd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    dce4:	00 
    dce5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    dcec:	00 
    dced:	e8 9e 8d ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    dcf2:	48 8b 15 1f ff 05 00 	mov    0x5ff1f(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dcf9:	49 89 c5             	mov    %rax,%r13
    dcfc:	48 2b 05 ed fe 05 00 	sub    0x5feed(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dd03:	48 c1 e2 10          	shl    $0x10,%rdx
    dd07:	48 39 d0             	cmp    %rdx,%rax
    dd0a:	73 59                	jae    dd65 <f0+0x1f85>
    dd0c:	48 89 c2             	mov    %rax,%rdx
    dd0f:	48 c1 ea 10          	shr    $0x10,%rdx
    dd13:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd17:	48 8b 15 1a ff 05 00 	mov    0x5ff1a(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dd1e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd22:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd26:	4d 85 e4             	test   %r12,%r12
    dd29:	74 3a                	je     dd65 <f0+0x1f85>
    dd2b:	0f b6 0a             	movzbl (%rdx),%ecx
    dd2e:	80 f9 02             	cmp    $0x2,%cl
    dd31:	0f 84 89 0b 00 00    	je     e8c0 <f0+0x2ae0>
    dd37:	80 f9 01             	cmp    $0x1,%cl
    dd3a:	75 29                	jne    dd65 <f0+0x1f85>
    dd3c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd3f:	0f b7 c0             	movzwl %ax,%eax
    dd42:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd45:	48 0f af c1          	imul   %rcx,%rax
    dd49:	48 c1 e8 20          	shr    $0x20,%rax
    dd4d:	48 39 d0             	cmp    %rdx,%rax
    dd50:	73 13                	jae    dd65 <f0+0x1f85>
    dd52:	49 01 c4             	add    %rax,%r12
    dd55:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd5a:	0f 84 c3 0c 00 00    	je     ea23 <f0+0x2c43>
    dd60:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd65:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dd6c:	00 f0 3f 
    dd6f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    dd76:	00 
    dd77:	bf 01 00 00 00       	mov    $0x1,%edi
    dd7c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    dd83:	00 
    dd84:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    dd8b:	00 
    dd8c:	e8 ff 8c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    dd91:	48 8b 15 80 fe 05 00 	mov    0x5fe80(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dd98:	49 89 c5             	mov    %rax,%r13
    dd9b:	48 2b 05 4e fe 05 00 	sub    0x5fe4e(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dda2:	48 c1 e2 10          	shl    $0x10,%rdx
    dda6:	48 39 d0             	cmp    %rdx,%rax
    dda9:	73 59                	jae    de04 <f0+0x2024>
    ddab:	48 89 c2             	mov    %rax,%rdx
    ddae:	48 c1 ea 10          	shr    $0x10,%rdx
    ddb2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ddb6:	48 8b 15 7b fe 05 00 	mov    0x5fe7b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    ddbd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ddc1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ddc5:	4d 85 e4             	test   %r12,%r12
    ddc8:	74 3a                	je     de04 <f0+0x2024>
    ddca:	0f b6 0a             	movzbl (%rdx),%ecx
    ddcd:	80 f9 02             	cmp    $0x2,%cl
    ddd0:	0f 84 da 0a 00 00    	je     e8b0 <f0+0x2ad0>
    ddd6:	80 f9 01             	cmp    $0x1,%cl
    ddd9:	75 29                	jne    de04 <f0+0x2024>
    dddb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddde:	0f b7 c0             	movzwl %ax,%eax
    dde1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dde4:	48 0f af c1          	imul   %rcx,%rax
    dde8:	48 c1 e8 20          	shr    $0x20,%rax
    ddec:	48 39 d0             	cmp    %rdx,%rax
    ddef:	73 13                	jae    de04 <f0+0x2024>
    ddf1:	49 01 c4             	add    %rax,%r12
    ddf4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddf9:	0f 84 31 0c 00 00    	je     ea30 <f0+0x2c50>
    ddff:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de04:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de0b:	33 f3 bf 
    de0e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    de15:	00 
    de16:	bf 01 00 00 00       	mov    $0x1,%edi
    de1b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    de22:	00 
    de23:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    de2a:	00 
    de2b:	e8 60 8c ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    de30:	48 8b 15 e1 fd 05 00 	mov    0x5fde1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    de37:	49 89 c5             	mov    %rax,%r13
    de3a:	48 2b 05 af fd 05 00 	sub    0x5fdaf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    de41:	48 c1 e2 10          	shl    $0x10,%rdx
    de45:	48 39 d0             	cmp    %rdx,%rax
    de48:	73 59                	jae    dea3 <f0+0x20c3>
    de4a:	48 89 c2             	mov    %rax,%rdx
    de4d:	48 c1 ea 10          	shr    $0x10,%rdx
    de51:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de55:	48 8b 15 dc fd 05 00 	mov    0x5fddc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    de5c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de60:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de64:	4d 85 e4             	test   %r12,%r12
    de67:	74 3a                	je     dea3 <f0+0x20c3>
    de69:	0f b6 0a             	movzbl (%rdx),%ecx
    de6c:	80 f9 02             	cmp    $0x2,%cl
    de6f:	0f 84 2b 0a 00 00    	je     e8a0 <f0+0x2ac0>
    de75:	80 f9 01             	cmp    $0x1,%cl
    de78:	75 29                	jne    dea3 <f0+0x20c3>
    de7a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de7d:	0f b7 c0             	movzwl %ax,%eax
    de80:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de83:	48 0f af c1          	imul   %rcx,%rax
    de87:	48 c1 e8 20          	shr    $0x20,%rax
    de8b:	48 39 d0             	cmp    %rdx,%rax
    de8e:	73 13                	jae    dea3 <f0+0x20c3>
    de90:	49 01 c4             	add    %rax,%r12
    de93:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de98:	0f 84 9f 0b 00 00    	je     ea3d <f0+0x2c5d>
    de9e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dea3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    deaa:	00 f0 3f 
    dead:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    deb4:	00 
    deb5:	bf 01 00 00 00       	mov    $0x1,%edi
    deba:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    dec1:	00 
    dec2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    dec9:	00 
    deca:	e8 c1 8b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    decf:	48 8b 15 42 fd 05 00 	mov    0x5fd42(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    ded6:	49 89 c5             	mov    %rax,%r13
    ded9:	48 2b 05 10 fd 05 00 	sub    0x5fd10(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dee0:	48 c1 e2 10          	shl    $0x10,%rdx
    dee4:	48 39 d0             	cmp    %rdx,%rax
    dee7:	73 59                	jae    df42 <f0+0x2162>
    dee9:	48 89 c2             	mov    %rax,%rdx
    deec:	48 c1 ea 10          	shr    $0x10,%rdx
    def0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    def4:	48 8b 15 3d fd 05 00 	mov    0x5fd3d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    defb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    deff:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df03:	4d 85 e4             	test   %r12,%r12
    df06:	74 3a                	je     df42 <f0+0x2162>
    df08:	0f b6 0a             	movzbl (%rdx),%ecx
    df0b:	80 f9 02             	cmp    $0x2,%cl
    df0e:	0f 84 7c 09 00 00    	je     e890 <f0+0x2ab0>
    df14:	80 f9 01             	cmp    $0x1,%cl
    df17:	75 29                	jne    df42 <f0+0x2162>
    df19:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df1c:	0f b7 c0             	movzwl %ax,%eax
    df1f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df22:	48 0f af c1          	imul   %rcx,%rax
    df26:	48 c1 e8 20          	shr    $0x20,%rax
    df2a:	48 39 d0             	cmp    %rdx,%rax
    df2d:	73 13                	jae    df42 <f0+0x2162>
    df2f:	49 01 c4             	add    %rax,%r12
    df32:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df37:	0f 84 0d 0b 00 00    	je     ea4a <f0+0x2c6a>
    df3d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df42:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    df49:	33 f3 bf 
    df4c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    df53:	00 
    df54:	bf 01 00 00 00       	mov    $0x1,%edi
    df59:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    df60:	00 
    df61:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    df68:	00 
    df69:	e8 22 8b ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    df6e:	48 8b 15 a3 fc 05 00 	mov    0x5fca3(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    df75:	49 89 c5             	mov    %rax,%r13
    df78:	48 2b 05 71 fc 05 00 	sub    0x5fc71(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    df7f:	48 c1 e2 10          	shl    $0x10,%rdx
    df83:	48 39 d0             	cmp    %rdx,%rax
    df86:	73 59                	jae    dfe1 <f0+0x2201>
    df88:	48 89 c2             	mov    %rax,%rdx
    df8b:	48 c1 ea 10          	shr    $0x10,%rdx
    df8f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df93:	48 8b 15 9e fc 05 00 	mov    0x5fc9e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    df9a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df9e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dfa2:	4d 85 e4             	test   %r12,%r12
    dfa5:	74 3a                	je     dfe1 <f0+0x2201>
    dfa7:	0f b6 0a             	movzbl (%rdx),%ecx
    dfaa:	80 f9 02             	cmp    $0x2,%cl
    dfad:	0f 84 cd 08 00 00    	je     e880 <f0+0x2aa0>
    dfb3:	80 f9 01             	cmp    $0x1,%cl
    dfb6:	75 29                	jne    dfe1 <f0+0x2201>
    dfb8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dfbb:	0f b7 c0             	movzwl %ax,%eax
    dfbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dfc1:	48 0f af c1          	imul   %rcx,%rax
    dfc5:	48 c1 e8 20          	shr    $0x20,%rax
    dfc9:	48 39 d0             	cmp    %rdx,%rax
    dfcc:	73 13                	jae    dfe1 <f0+0x2201>
    dfce:	49 01 c4             	add    %rax,%r12
    dfd1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfd6:	0f 84 7b 0a 00 00    	je     ea57 <f0+0x2c77>
    dfdc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfe1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dfe8:	00 f0 3f 
    dfeb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    dff2:	00 
    dff3:	bf 01 00 00 00       	mov    $0x1,%edi
    dff8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    dfff:	00 
    e000:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    e007:	00 
    e008:	e8 83 8a ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e00d:	48 8b 15 04 fc 05 00 	mov    0x5fc04(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e014:	49 89 c5             	mov    %rax,%r13
    e017:	48 2b 05 d2 fb 05 00 	sub    0x5fbd2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e01e:	48 c1 e2 10          	shl    $0x10,%rdx
    e022:	48 39 d0             	cmp    %rdx,%rax
    e025:	73 59                	jae    e080 <f0+0x22a0>
    e027:	48 89 c2             	mov    %rax,%rdx
    e02a:	48 c1 ea 10          	shr    $0x10,%rdx
    e02e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e032:	48 8b 15 ff fb 05 00 	mov    0x5fbff(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e039:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e03d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e041:	4d 85 e4             	test   %r12,%r12
    e044:	74 3a                	je     e080 <f0+0x22a0>
    e046:	0f b6 0a             	movzbl (%rdx),%ecx
    e049:	80 f9 02             	cmp    $0x2,%cl
    e04c:	0f 84 1e 08 00 00    	je     e870 <f0+0x2a90>
    e052:	80 f9 01             	cmp    $0x1,%cl
    e055:	75 29                	jne    e080 <f0+0x22a0>
    e057:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e05a:	0f b7 c0             	movzwl %ax,%eax
    e05d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e060:	48 0f af c1          	imul   %rcx,%rax
    e064:	48 c1 e8 20          	shr    $0x20,%rax
    e068:	48 39 d0             	cmp    %rdx,%rax
    e06b:	73 13                	jae    e080 <f0+0x22a0>
    e06d:	49 01 c4             	add    %rax,%r12
    e070:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e075:	0f 84 e9 09 00 00    	je     ea64 <f0+0x2c84>
    e07b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e080:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e087:	33 f3 bf 
    e08a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    e091:	00 
    e092:	bf 01 00 00 00       	mov    $0x1,%edi
    e097:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    e09e:	00 
    e09f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    e0a6:	00 
    e0a7:	e8 e4 89 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e0ac:	48 8b 15 65 fb 05 00 	mov    0x5fb65(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e0b3:	49 89 c5             	mov    %rax,%r13
    e0b6:	48 2b 05 33 fb 05 00 	sub    0x5fb33(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e0bd:	48 c1 e2 10          	shl    $0x10,%rdx
    e0c1:	48 39 d0             	cmp    %rdx,%rax
    e0c4:	73 59                	jae    e11f <f0+0x233f>
    e0c6:	48 89 c2             	mov    %rax,%rdx
    e0c9:	48 c1 ea 10          	shr    $0x10,%rdx
    e0cd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0d1:	48 8b 15 60 fb 05 00 	mov    0x5fb60(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e0d8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0dc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0e0:	4d 85 e4             	test   %r12,%r12
    e0e3:	74 3a                	je     e11f <f0+0x233f>
    e0e5:	0f b6 0a             	movzbl (%rdx),%ecx
    e0e8:	80 f9 02             	cmp    $0x2,%cl
    e0eb:	0f 84 6f 07 00 00    	je     e860 <f0+0x2a80>
    e0f1:	80 f9 01             	cmp    $0x1,%cl
    e0f4:	75 29                	jne    e11f <f0+0x233f>
    e0f6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0f9:	0f b7 c0             	movzwl %ax,%eax
    e0fc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0ff:	48 0f af c1          	imul   %rcx,%rax
    e103:	48 c1 e8 20          	shr    $0x20,%rax
    e107:	48 39 d0             	cmp    %rdx,%rax
    e10a:	73 13                	jae    e11f <f0+0x233f>
    e10c:	49 01 c4             	add    %rax,%r12
    e10f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e114:	0f 84 57 09 00 00    	je     ea71 <f0+0x2c91>
    e11a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e11f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e126:	00 f0 3f 
    e129:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    e130:	00 
    e131:	bf 01 00 00 00       	mov    $0x1,%edi
    e136:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    e13d:	00 
    e13e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    e145:	00 
    e146:	e8 45 89 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e14b:	48 8b 15 c6 fa 05 00 	mov    0x5fac6(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e152:	49 89 c5             	mov    %rax,%r13
    e155:	48 2b 05 94 fa 05 00 	sub    0x5fa94(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e15c:	48 c1 e2 10          	shl    $0x10,%rdx
    e160:	48 39 d0             	cmp    %rdx,%rax
    e163:	73 59                	jae    e1be <f0+0x23de>
    e165:	48 89 c2             	mov    %rax,%rdx
    e168:	48 c1 ea 10          	shr    $0x10,%rdx
    e16c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e170:	48 8b 15 c1 fa 05 00 	mov    0x5fac1(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e177:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e17b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e17f:	4d 85 e4             	test   %r12,%r12
    e182:	74 3a                	je     e1be <f0+0x23de>
    e184:	0f b6 0a             	movzbl (%rdx),%ecx
    e187:	80 f9 02             	cmp    $0x2,%cl
    e18a:	0f 84 c0 06 00 00    	je     e850 <f0+0x2a70>
    e190:	80 f9 01             	cmp    $0x1,%cl
    e193:	75 29                	jne    e1be <f0+0x23de>
    e195:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e198:	0f b7 c0             	movzwl %ax,%eax
    e19b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e19e:	48 0f af c1          	imul   %rcx,%rax
    e1a2:	48 c1 e8 20          	shr    $0x20,%rax
    e1a6:	48 39 d0             	cmp    %rdx,%rax
    e1a9:	73 13                	jae    e1be <f0+0x23de>
    e1ab:	49 01 c4             	add    %rax,%r12
    e1ae:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e1b3:	0f 84 c5 08 00 00    	je     ea7e <f0+0x2c9e>
    e1b9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e1be:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e1c5:	33 f3 bf 
    e1c8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    e1cf:	00 
    e1d0:	bf 01 00 00 00       	mov    $0x1,%edi
    e1d5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    e1dc:	00 
    e1dd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    e1e4:	00 
    e1e5:	e8 a6 88 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e1ea:	48 8b 15 27 fa 05 00 	mov    0x5fa27(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e1f1:	49 89 c5             	mov    %rax,%r13
    e1f4:	48 2b 05 f5 f9 05 00 	sub    0x5f9f5(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e1fb:	48 c1 e2 10          	shl    $0x10,%rdx
    e1ff:	48 39 d0             	cmp    %rdx,%rax
    e202:	73 59                	jae    e25d <f0+0x247d>
    e204:	48 89 c2             	mov    %rax,%rdx
    e207:	48 c1 ea 10          	shr    $0x10,%rdx
    e20b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e20f:	48 8b 15 22 fa 05 00 	mov    0x5fa22(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e216:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e21a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e21e:	4d 85 e4             	test   %r12,%r12
    e221:	74 3a                	je     e25d <f0+0x247d>
    e223:	0f b6 0a             	movzbl (%rdx),%ecx
    e226:	80 f9 02             	cmp    $0x2,%cl
    e229:	0f 84 11 06 00 00    	je     e840 <f0+0x2a60>
    e22f:	80 f9 01             	cmp    $0x1,%cl
    e232:	75 29                	jne    e25d <f0+0x247d>
    e234:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e237:	0f b7 c0             	movzwl %ax,%eax
    e23a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e23d:	48 0f af c1          	imul   %rcx,%rax
    e241:	48 c1 e8 20          	shr    $0x20,%rax
    e245:	48 39 d0             	cmp    %rdx,%rax
    e248:	73 13                	jae    e25d <f0+0x247d>
    e24a:	49 01 c4             	add    %rax,%r12
    e24d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e252:	0f 84 33 08 00 00    	je     ea8b <f0+0x2cab>
    e258:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e25d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e264:	00 f0 3f 
    e267:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    e26e:	00 
    e26f:	bf 01 00 00 00       	mov    $0x1,%edi
    e274:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    e27b:	00 
    e27c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    e283:	00 
    e284:	e8 07 88 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e289:	48 8b 15 88 f9 05 00 	mov    0x5f988(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e290:	49 89 c5             	mov    %rax,%r13
    e293:	48 2b 05 56 f9 05 00 	sub    0x5f956(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e29a:	48 c1 e2 10          	shl    $0x10,%rdx
    e29e:	48 39 d0             	cmp    %rdx,%rax
    e2a1:	73 59                	jae    e2fc <f0+0x251c>
    e2a3:	48 89 c2             	mov    %rax,%rdx
    e2a6:	48 c1 ea 10          	shr    $0x10,%rdx
    e2aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e2ae:	48 8b 15 83 f9 05 00 	mov    0x5f983(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e2b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e2b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e2bd:	4d 85 e4             	test   %r12,%r12
    e2c0:	74 3a                	je     e2fc <f0+0x251c>
    e2c2:	0f b6 0a             	movzbl (%rdx),%ecx
    e2c5:	80 f9 02             	cmp    $0x2,%cl
    e2c8:	0f 84 62 05 00 00    	je     e830 <f0+0x2a50>
    e2ce:	80 f9 01             	cmp    $0x1,%cl
    e2d1:	75 29                	jne    e2fc <f0+0x251c>
    e2d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e2d6:	0f b7 c0             	movzwl %ax,%eax
    e2d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e2dc:	48 0f af c1          	imul   %rcx,%rax
    e2e0:	48 c1 e8 20          	shr    $0x20,%rax
    e2e4:	48 39 d0             	cmp    %rdx,%rax
    e2e7:	73 13                	jae    e2fc <f0+0x251c>
    e2e9:	49 01 c4             	add    %rax,%r12
    e2ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e2f1:	0f 84 a1 07 00 00    	je     ea98 <f0+0x2cb8>
    e2f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e2fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e303:	33 f3 bf 
    e306:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    e30d:	00 
    e30e:	bf 01 00 00 00       	mov    $0x1,%edi
    e313:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    e31a:	00 
    e31b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    e322:	00 
    e323:	e8 68 87 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e328:	48 8b 15 e9 f8 05 00 	mov    0x5f8e9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e32f:	49 89 c5             	mov    %rax,%r13
    e332:	48 2b 05 b7 f8 05 00 	sub    0x5f8b7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e339:	48 c1 e2 10          	shl    $0x10,%rdx
    e33d:	48 39 d0             	cmp    %rdx,%rax
    e340:	73 59                	jae    e39b <f0+0x25bb>
    e342:	48 89 c2             	mov    %rax,%rdx
    e345:	48 c1 ea 10          	shr    $0x10,%rdx
    e349:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e34d:	48 8b 15 e4 f8 05 00 	mov    0x5f8e4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e354:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e358:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e35c:	4d 85 e4             	test   %r12,%r12
    e35f:	74 3a                	je     e39b <f0+0x25bb>
    e361:	0f b6 0a             	movzbl (%rdx),%ecx
    e364:	80 f9 02             	cmp    $0x2,%cl
    e367:	0f 84 b3 04 00 00    	je     e820 <f0+0x2a40>
    e36d:	80 f9 01             	cmp    $0x1,%cl
    e370:	75 29                	jne    e39b <f0+0x25bb>
    e372:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e375:	0f b7 c0             	movzwl %ax,%eax
    e378:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e37b:	48 0f af c1          	imul   %rcx,%rax
    e37f:	48 c1 e8 20          	shr    $0x20,%rax
    e383:	48 39 d0             	cmp    %rdx,%rax
    e386:	73 13                	jae    e39b <f0+0x25bb>
    e388:	49 01 c4             	add    %rax,%r12
    e38b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e390:	0f 84 0f 07 00 00    	je     eaa5 <f0+0x2cc5>
    e396:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e39b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e3a2:	00 f0 3f 
    e3a5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    e3ac:	00 
    e3ad:	bf 01 00 00 00       	mov    $0x1,%edi
    e3b2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    e3b9:	00 
    e3ba:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    e3c1:	00 
    e3c2:	e8 c9 86 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e3c7:	48 8b 15 4a f8 05 00 	mov    0x5f84a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e3ce:	49 89 c5             	mov    %rax,%r13
    e3d1:	48 2b 05 18 f8 05 00 	sub    0x5f818(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e3d8:	48 c1 e2 10          	shl    $0x10,%rdx
    e3dc:	48 39 d0             	cmp    %rdx,%rax
    e3df:	73 59                	jae    e43a <f0+0x265a>
    e3e1:	48 89 c2             	mov    %rax,%rdx
    e3e4:	48 c1 ea 10          	shr    $0x10,%rdx
    e3e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e3ec:	48 8b 15 45 f8 05 00 	mov    0x5f845(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e3f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e3f7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e3fb:	4d 85 e4             	test   %r12,%r12
    e3fe:	74 3a                	je     e43a <f0+0x265a>
    e400:	0f b6 0a             	movzbl (%rdx),%ecx
    e403:	80 f9 02             	cmp    $0x2,%cl
    e406:	0f 84 04 04 00 00    	je     e810 <f0+0x2a30>
    e40c:	80 f9 01             	cmp    $0x1,%cl
    e40f:	75 29                	jne    e43a <f0+0x265a>
    e411:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e414:	0f b7 c0             	movzwl %ax,%eax
    e417:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e41a:	48 0f af c1          	imul   %rcx,%rax
    e41e:	48 c1 e8 20          	shr    $0x20,%rax
    e422:	48 39 d0             	cmp    %rdx,%rax
    e425:	73 13                	jae    e43a <f0+0x265a>
    e427:	49 01 c4             	add    %rax,%r12
    e42a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e42f:	0f 84 7d 06 00 00    	je     eab2 <f0+0x2cd2>
    e435:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e43a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e441:	33 f3 bf 
    e444:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    e44b:	00 
    e44c:	bf 01 00 00 00       	mov    $0x1,%edi
    e451:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    e458:	00 
    e459:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e460:	00 
    e461:	e8 2a 86 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e466:	48 8b 15 ab f7 05 00 	mov    0x5f7ab(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e46d:	49 89 c5             	mov    %rax,%r13
    e470:	48 2b 05 79 f7 05 00 	sub    0x5f779(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e477:	48 c1 e2 10          	shl    $0x10,%rdx
    e47b:	48 39 d0             	cmp    %rdx,%rax
    e47e:	73 59                	jae    e4d9 <f0+0x26f9>
    e480:	48 89 c2             	mov    %rax,%rdx
    e483:	48 c1 ea 10          	shr    $0x10,%rdx
    e487:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e48b:	48 8b 15 a6 f7 05 00 	mov    0x5f7a6(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e492:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e496:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e49a:	4d 85 e4             	test   %r12,%r12
    e49d:	74 3a                	je     e4d9 <f0+0x26f9>
    e49f:	0f b6 0a             	movzbl (%rdx),%ecx
    e4a2:	80 f9 02             	cmp    $0x2,%cl
    e4a5:	0f 84 55 03 00 00    	je     e800 <f0+0x2a20>
    e4ab:	80 f9 01             	cmp    $0x1,%cl
    e4ae:	75 29                	jne    e4d9 <f0+0x26f9>
    e4b0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e4b3:	0f b7 c0             	movzwl %ax,%eax
    e4b6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e4b9:	48 0f af c1          	imul   %rcx,%rax
    e4bd:	48 c1 e8 20          	shr    $0x20,%rax
    e4c1:	48 39 d0             	cmp    %rdx,%rax
    e4c4:	73 13                	jae    e4d9 <f0+0x26f9>
    e4c6:	49 01 c4             	add    %rax,%r12
    e4c9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e4ce:	0f 84 eb 05 00 00    	je     eabf <f0+0x2cdf>
    e4d4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e4d9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e4e0:	00 f0 3f 
    e4e3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e4ea:	00 
    e4eb:	bf 01 00 00 00       	mov    $0x1,%edi
    e4f0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e4f7:	00 
    e4f8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e4ff:	00 
    e500:	e8 8b 85 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e505:	48 8b 15 0c f7 05 00 	mov    0x5f70c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e50c:	49 89 c5             	mov    %rax,%r13
    e50f:	48 2b 05 da f6 05 00 	sub    0x5f6da(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e516:	48 c1 e2 10          	shl    $0x10,%rdx
    e51a:	48 39 d0             	cmp    %rdx,%rax
    e51d:	73 59                	jae    e578 <f0+0x2798>
    e51f:	48 89 c2             	mov    %rax,%rdx
    e522:	48 c1 ea 10          	shr    $0x10,%rdx
    e526:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e52a:	48 8b 15 07 f7 05 00 	mov    0x5f707(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e531:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e535:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e539:	4d 85 e4             	test   %r12,%r12
    e53c:	74 3a                	je     e578 <f0+0x2798>
    e53e:	0f b6 0a             	movzbl (%rdx),%ecx
    e541:	80 f9 02             	cmp    $0x2,%cl
    e544:	0f 84 a6 02 00 00    	je     e7f0 <f0+0x2a10>
    e54a:	80 f9 01             	cmp    $0x1,%cl
    e54d:	75 29                	jne    e578 <f0+0x2798>
    e54f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e552:	0f b7 c0             	movzwl %ax,%eax
    e555:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e558:	48 0f af c1          	imul   %rcx,%rax
    e55c:	48 c1 e8 20          	shr    $0x20,%rax
    e560:	48 39 d0             	cmp    %rdx,%rax
    e563:	73 13                	jae    e578 <f0+0x2798>
    e565:	49 01 c4             	add    %rax,%r12
    e568:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e56d:	0f 84 59 05 00 00    	je     eacc <f0+0x2cec>
    e573:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e578:	48 89 ee             	mov    %rbp,%rsi
    e57b:	bf 01 00 00 00       	mov    $0x1,%edi
    e580:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e587:	33 f3 bf 
    e58a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e591:	00 
    e592:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e599:	00 
    e59a:	e8 f1 84 ff ff       	call   6a90 <fwp_data.part.0.constprop.0>
    e59f:	48 8b 15 72 f6 05 00 	mov    0x5f672(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e5a6:	48 89 c5             	mov    %rax,%rbp
    e5a9:	48 2b 05 40 f6 05 00 	sub    0x5f640(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e5b0:	48 c1 e2 10          	shl    $0x10,%rdx
    e5b4:	48 39 d0             	cmp    %rdx,%rax
    e5b7:	73 59                	jae    e612 <f0+0x2832>
    e5b9:	48 89 c2             	mov    %rax,%rdx
    e5bc:	48 c1 ea 10          	shr    $0x10,%rdx
    e5c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e5c4:	48 8b 15 6d f6 05 00 	mov    0x5f66d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e5cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e5cf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e5d3:	4d 85 e4             	test   %r12,%r12
    e5d6:	74 3a                	je     e612 <f0+0x2832>
    e5d8:	0f b6 0a             	movzbl (%rdx),%ecx
    e5db:	80 f9 02             	cmp    $0x2,%cl
    e5de:	0f 84 fc 01 00 00    	je     e7e0 <f0+0x2a00>
    e5e4:	80 f9 01             	cmp    $0x1,%cl
    e5e7:	75 29                	jne    e612 <f0+0x2832>
    e5e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e5ec:	0f b7 c0             	movzwl %ax,%eax
    e5ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e5f2:	48 0f af c1          	imul   %rcx,%rax
    e5f6:	48 c1 e8 20          	shr    $0x20,%rax
    e5fa:	48 39 d0             	cmp    %rdx,%rax
    e5fd:	73 13                	jae    e612 <f0+0x2832>
    e5ff:	49 01 c4             	add    %rax,%r12
    e602:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e607:	0f 84 d1 02 00 00    	je     e8de <f0+0x2afe>
    e60d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e612:	48 89 de             	mov    %rbx,%rsi
    e615:	48 89 ef             	mov    %rbp,%rdi
    e618:	e8 03 ca ff ff       	call   b020 <fwp_hof0.constprop.0>
    e61d:	48 89 ef             	mov    %rbp,%rdi
    e620:	e8 bb 8a ff ff       	call   70e0 <fwp_drop0>
    e625:	48 89 df             	mov    %rbx,%rdi
    e628:	e8 b3 8a ff ff       	call   70e0 <fwp_drop0>
    e62d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e634:	00 
    e635:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e63c:	00 00 
    e63e:	0f 85 95 04 00 00    	jne    ead9 <f0+0x2cf9>
    e644:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e64b:	31 c0                	xor    %eax,%eax
    e64d:	5b                   	pop    %rbx
    e64e:	5d                   	pop    %rbp
    e64f:	41 5c                	pop    %r12
    e651:	41 5d                	pop    %r13
    e653:	41 5e                	pop    %r14
    e655:	c3                   	ret
    e656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e65d:	00 00 00 
    e660:	4c 89 ef             	mov    %r13,%rdi
    e663:	e8 68 71 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e668:	e9 2c d8 ff ff       	jmp    be99 <f0+0xb9>
    e66d:	0f 1f 00             	nopl   (%rax)
    e670:	66 85 c0             	test   %ax,%ax
    e673:	0f 85 ae f5 ff ff    	jne    dc27 <f0+0x1e47>
    e679:	e9 99 f5 ff ff       	jmp    dc17 <f0+0x1e37>
    e67e:	66 90                	xchg   %ax,%ax
    e680:	66 85 c0             	test   %ax,%ax
    e683:	0f 85 ff f4 ff ff    	jne    db88 <f0+0x1da8>
    e689:	e9 ea f4 ff ff       	jmp    db78 <f0+0x1d98>
    e68e:	66 90                	xchg   %ax,%ax
    e690:	66 85 c0             	test   %ax,%ax
    e693:	0f 85 50 f4 ff ff    	jne    dae9 <f0+0x1d09>
    e699:	e9 3b f4 ff ff       	jmp    dad9 <f0+0x1cf9>
    e69e:	66 90                	xchg   %ax,%ax
    e6a0:	66 85 c0             	test   %ax,%ax
    e6a3:	0f 85 a1 f3 ff ff    	jne    da4a <f0+0x1c6a>
    e6a9:	e9 8c f3 ff ff       	jmp    da3a <f0+0x1c5a>
    e6ae:	66 90                	xchg   %ax,%ax
    e6b0:	66 85 c0             	test   %ax,%ax
    e6b3:	0f 85 f2 f2 ff ff    	jne    d9ab <f0+0x1bcb>
    e6b9:	e9 dd f2 ff ff       	jmp    d99b <f0+0x1bbb>
    e6be:	66 90                	xchg   %ax,%ax
    e6c0:	66 85 c0             	test   %ax,%ax
    e6c3:	0f 85 43 f2 ff ff    	jne    d90c <f0+0x1b2c>
    e6c9:	e9 2e f2 ff ff       	jmp    d8fc <f0+0x1b1c>
    e6ce:	66 90                	xchg   %ax,%ax
    e6d0:	66 85 c0             	test   %ax,%ax
    e6d3:	0f 85 94 f1 ff ff    	jne    d86d <f0+0x1a8d>
    e6d9:	e9 7f f1 ff ff       	jmp    d85d <f0+0x1a7d>
    e6de:	66 90                	xchg   %ax,%ax
    e6e0:	66 85 c0             	test   %ax,%ax
    e6e3:	0f 85 e5 f0 ff ff    	jne    d7ce <f0+0x19ee>
    e6e9:	e9 d0 f0 ff ff       	jmp    d7be <f0+0x19de>
    e6ee:	66 90                	xchg   %ax,%ax
    e6f0:	66 85 c0             	test   %ax,%ax
    e6f3:	0f 85 fd d9 ff ff    	jne    c0f6 <f0+0x316>
    e6f9:	e9 e8 d9 ff ff       	jmp    c0e6 <f0+0x306>
    e6fe:	66 90                	xchg   %ax,%ax
    e700:	66 85 c0             	test   %ax,%ax
    e703:	0f 85 57 d9 ff ff    	jne    c060 <f0+0x280>
    e709:	e9 42 d9 ff ff       	jmp    c050 <f0+0x270>
    e70e:	66 90                	xchg   %ax,%ax
    e710:	66 85 c0             	test   %ax,%ax
    e713:	0f 85 b1 d8 ff ff    	jne    bfca <f0+0x1ea>
    e719:	e9 9c d8 ff ff       	jmp    bfba <f0+0x1da>
    e71e:	66 90                	xchg   %ax,%ax
    e720:	66 85 c0             	test   %ax,%ax
    e723:	0f 85 0e eb ff ff    	jne    d237 <f0+0x1457>
    e729:	e9 f9 ea ff ff       	jmp    d227 <f0+0x1447>
    e72e:	66 90                	xchg   %ax,%ax
    e730:	66 85 c0             	test   %ax,%ax
    e733:	0f 85 91 db ff ff    	jne    c2ca <f0+0x4ea>
    e739:	e9 7c db ff ff       	jmp    c2ba <f0+0x4da>
    e73e:	66 90                	xchg   %ax,%ax
    e740:	66 85 c0             	test   %ax,%ax
    e743:	0f 85 e2 da ff ff    	jne    c22b <f0+0x44b>
    e749:	e9 cd da ff ff       	jmp    c21b <f0+0x43b>
    e74e:	66 90                	xchg   %ax,%ax
    e750:	66 85 c0             	test   %ax,%ax
    e753:	0f 85 33 da ff ff    	jne    c18c <f0+0x3ac>
    e759:	e9 1e da ff ff       	jmp    c17c <f0+0x39c>
    e75e:	66 90                	xchg   %ax,%ax
    e760:	66 85 c0             	test   %ax,%ax
    e763:	0f 85 c6 ef ff ff    	jne    d72f <f0+0x194f>
    e769:	e9 b1 ef ff ff       	jmp    d71f <f0+0x193f>
    e76e:	66 90                	xchg   %ax,%ax
    e770:	66 85 c0             	test   %ax,%ax
    e773:	0f 85 17 ef ff ff    	jne    d690 <f0+0x18b0>
    e779:	e9 02 ef ff ff       	jmp    d680 <f0+0x18a0>
    e77e:	66 90                	xchg   %ax,%ax
    e780:	66 85 c0             	test   %ax,%ax
    e783:	0f 85 68 ee ff ff    	jne    d5f1 <f0+0x1811>
    e789:	e9 53 ee ff ff       	jmp    d5e1 <f0+0x1801>
    e78e:	66 90                	xchg   %ax,%ax
    e790:	66 85 c0             	test   %ax,%ax
    e793:	0f 85 b9 ed ff ff    	jne    d552 <f0+0x1772>
    e799:	e9 a4 ed ff ff       	jmp    d542 <f0+0x1762>
    e79e:	66 90                	xchg   %ax,%ax
    e7a0:	66 85 c0             	test   %ax,%ax
    e7a3:	0f 85 0a ed ff ff    	jne    d4b3 <f0+0x16d3>
    e7a9:	e9 f5 ec ff ff       	jmp    d4a3 <f0+0x16c3>
    e7ae:	66 90                	xchg   %ax,%ax
    e7b0:	66 85 c0             	test   %ax,%ax
    e7b3:	0f 85 5b ec ff ff    	jne    d414 <f0+0x1634>
    e7b9:	e9 46 ec ff ff       	jmp    d404 <f0+0x1624>
    e7be:	66 90                	xchg   %ax,%ax
    e7c0:	66 85 c0             	test   %ax,%ax
    e7c3:	0f 85 ac eb ff ff    	jne    d375 <f0+0x1595>
    e7c9:	e9 97 eb ff ff       	jmp    d365 <f0+0x1585>
    e7ce:	66 90                	xchg   %ax,%ax
    e7d0:	66 85 c0             	test   %ax,%ax
    e7d3:	0f 85 fd ea ff ff    	jne    d2d6 <f0+0x14f6>
    e7d9:	e9 e8 ea ff ff       	jmp    d2c6 <f0+0x14e6>
    e7de:	66 90                	xchg   %ax,%ax
    e7e0:	66 85 c0             	test   %ax,%ax
    e7e3:	0f 85 29 fe ff ff    	jne    e612 <f0+0x2832>
    e7e9:	e9 14 fe ff ff       	jmp    e602 <f0+0x2822>
    e7ee:	66 90                	xchg   %ax,%ax
    e7f0:	66 85 c0             	test   %ax,%ax
    e7f3:	0f 85 7f fd ff ff    	jne    e578 <f0+0x2798>
    e7f9:	e9 6a fd ff ff       	jmp    e568 <f0+0x2788>
    e7fe:	66 90                	xchg   %ax,%ax
    e800:	66 85 c0             	test   %ax,%ax
    e803:	0f 85 d0 fc ff ff    	jne    e4d9 <f0+0x26f9>
    e809:	e9 bb fc ff ff       	jmp    e4c9 <f0+0x26e9>
    e80e:	66 90                	xchg   %ax,%ax
    e810:	66 85 c0             	test   %ax,%ax
    e813:	0f 85 21 fc ff ff    	jne    e43a <f0+0x265a>
    e819:	e9 0c fc ff ff       	jmp    e42a <f0+0x264a>
    e81e:	66 90                	xchg   %ax,%ax
    e820:	66 85 c0             	test   %ax,%ax
    e823:	0f 85 72 fb ff ff    	jne    e39b <f0+0x25bb>
    e829:	e9 5d fb ff ff       	jmp    e38b <f0+0x25ab>
    e82e:	66 90                	xchg   %ax,%ax
    e830:	66 85 c0             	test   %ax,%ax
    e833:	0f 85 c3 fa ff ff    	jne    e2fc <f0+0x251c>
    e839:	e9 ae fa ff ff       	jmp    e2ec <f0+0x250c>
    e83e:	66 90                	xchg   %ax,%ax
    e840:	66 85 c0             	test   %ax,%ax
    e843:	0f 85 14 fa ff ff    	jne    e25d <f0+0x247d>
    e849:	e9 ff f9 ff ff       	jmp    e24d <f0+0x246d>
    e84e:	66 90                	xchg   %ax,%ax
    e850:	66 85 c0             	test   %ax,%ax
    e853:	0f 85 65 f9 ff ff    	jne    e1be <f0+0x23de>
    e859:	e9 50 f9 ff ff       	jmp    e1ae <f0+0x23ce>
    e85e:	66 90                	xchg   %ax,%ax
    e860:	66 85 c0             	test   %ax,%ax
    e863:	0f 85 b6 f8 ff ff    	jne    e11f <f0+0x233f>
    e869:	e9 a1 f8 ff ff       	jmp    e10f <f0+0x232f>
    e86e:	66 90                	xchg   %ax,%ax
    e870:	66 85 c0             	test   %ax,%ax
    e873:	0f 85 07 f8 ff ff    	jne    e080 <f0+0x22a0>
    e879:	e9 f2 f7 ff ff       	jmp    e070 <f0+0x2290>
    e87e:	66 90                	xchg   %ax,%ax
    e880:	66 85 c0             	test   %ax,%ax
    e883:	0f 85 58 f7 ff ff    	jne    dfe1 <f0+0x2201>
    e889:	e9 43 f7 ff ff       	jmp    dfd1 <f0+0x21f1>
    e88e:	66 90                	xchg   %ax,%ax
    e890:	66 85 c0             	test   %ax,%ax
    e893:	0f 85 a9 f6 ff ff    	jne    df42 <f0+0x2162>
    e899:	e9 94 f6 ff ff       	jmp    df32 <f0+0x2152>
    e89e:	66 90                	xchg   %ax,%ax
    e8a0:	66 85 c0             	test   %ax,%ax
    e8a3:	0f 85 fa f5 ff ff    	jne    dea3 <f0+0x20c3>
    e8a9:	e9 e5 f5 ff ff       	jmp    de93 <f0+0x20b3>
    e8ae:	66 90                	xchg   %ax,%ax
    e8b0:	66 85 c0             	test   %ax,%ax
    e8b3:	0f 85 4b f5 ff ff    	jne    de04 <f0+0x2024>
    e8b9:	e9 36 f5 ff ff       	jmp    ddf4 <f0+0x2014>
    e8be:	66 90                	xchg   %ax,%ax
    e8c0:	66 85 c0             	test   %ax,%ax
    e8c3:	0f 85 9c f4 ff ff    	jne    dd65 <f0+0x1f85>
    e8c9:	e9 87 f4 ff ff       	jmp    dd55 <f0+0x1f75>
    e8ce:	66 90                	xchg   %ax,%ax
    e8d0:	66 85 c0             	test   %ax,%ax
    e8d3:	0f 85 ed f3 ff ff    	jne    dcc6 <f0+0x1ee6>
    e8d9:	e9 d8 f3 ff ff       	jmp    dcb6 <f0+0x1ed6>
    e8de:	4c 89 e7             	mov    %r12,%rdi
    e8e1:	e8 ea 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8e6:	e9 22 fd ff ff       	jmp    e60d <f0+0x282d>
    e8eb:	4c 89 e7             	mov    %r12,%rdi
    e8ee:	e8 dd 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8f3:	e9 cd d6 ff ff       	jmp    bfc5 <f0+0x1e5>
    e8f8:	4c 89 e7             	mov    %r12,%rdi
    e8fb:	e8 d0 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e900:	e9 56 d7 ff ff       	jmp    c05b <f0+0x27b>
    e905:	4c 89 e7             	mov    %r12,%rdi
    e908:	e8 c3 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e90d:	e9 df d7 ff ff       	jmp    c0f1 <f0+0x311>
    e912:	4c 89 e7             	mov    %r12,%rdi
    e915:	e8 b6 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e91a:	e9 68 d8 ff ff       	jmp    c187 <f0+0x3a7>
    e91f:	4c 89 e7             	mov    %r12,%rdi
    e922:	e8 a9 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e927:	e9 fa d8 ff ff       	jmp    c226 <f0+0x446>
    e92c:	4c 89 e7             	mov    %r12,%rdi
    e92f:	e8 9c 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e934:	e9 8c d9 ff ff       	jmp    c2c5 <f0+0x4e5>
    e939:	4c 89 e7             	mov    %r12,%rdi
    e93c:	e8 8f 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e941:	e9 ec e8 ff ff       	jmp    d232 <f0+0x1452>
    e946:	4c 89 e7             	mov    %r12,%rdi
    e949:	e8 82 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e94e:	e9 7e e9 ff ff       	jmp    d2d1 <f0+0x14f1>
    e953:	4c 89 e7             	mov    %r12,%rdi
    e956:	e8 75 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e95b:	e9 10 ea ff ff       	jmp    d370 <f0+0x1590>
    e960:	4c 89 e7             	mov    %r12,%rdi
    e963:	e8 68 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e968:	e9 a2 ea ff ff       	jmp    d40f <f0+0x162f>
    e96d:	4c 89 e7             	mov    %r12,%rdi
    e970:	e8 5b 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e975:	e9 34 eb ff ff       	jmp    d4ae <f0+0x16ce>
    e97a:	4c 89 e7             	mov    %r12,%rdi
    e97d:	e8 4e 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e982:	e9 c6 eb ff ff       	jmp    d54d <f0+0x176d>
    e987:	4c 89 e7             	mov    %r12,%rdi
    e98a:	e8 41 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e98f:	e9 58 ec ff ff       	jmp    d5ec <f0+0x180c>
    e994:	4c 89 e7             	mov    %r12,%rdi
    e997:	e8 34 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e99c:	e9 ea ec ff ff       	jmp    d68b <f0+0x18ab>
    e9a1:	4c 89 e7             	mov    %r12,%rdi
    e9a4:	e8 27 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9a9:	e9 7c ed ff ff       	jmp    d72a <f0+0x194a>
    e9ae:	4c 89 e7             	mov    %r12,%rdi
    e9b1:	e8 1a 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9b6:	e9 0e ee ff ff       	jmp    d7c9 <f0+0x19e9>
    e9bb:	4c 89 e7             	mov    %r12,%rdi
    e9be:	e8 0d 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9c3:	e9 a0 ee ff ff       	jmp    d868 <f0+0x1a88>
    e9c8:	4c 89 e7             	mov    %r12,%rdi
    e9cb:	e8 00 6e ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9d0:	e9 32 ef ff ff       	jmp    d907 <f0+0x1b27>
    e9d5:	4c 89 e7             	mov    %r12,%rdi
    e9d8:	e8 f3 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9dd:	e9 c4 ef ff ff       	jmp    d9a6 <f0+0x1bc6>
    e9e2:	4c 89 e7             	mov    %r12,%rdi
    e9e5:	e8 e6 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9ea:	e9 56 f0 ff ff       	jmp    da45 <f0+0x1c65>
    e9ef:	4c 89 e7             	mov    %r12,%rdi
    e9f2:	e8 d9 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    e9f7:	e9 e8 f0 ff ff       	jmp    dae4 <f0+0x1d04>
    e9fc:	4c 89 e7             	mov    %r12,%rdi
    e9ff:	e8 cc 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea04:	e9 7a f1 ff ff       	jmp    db83 <f0+0x1da3>
    ea09:	4c 89 e7             	mov    %r12,%rdi
    ea0c:	e8 bf 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea11:	e9 0c f2 ff ff       	jmp    dc22 <f0+0x1e42>
    ea16:	4c 89 e7             	mov    %r12,%rdi
    ea19:	e8 b2 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea1e:	e9 9e f2 ff ff       	jmp    dcc1 <f0+0x1ee1>
    ea23:	4c 89 e7             	mov    %r12,%rdi
    ea26:	e8 a5 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea2b:	e9 30 f3 ff ff       	jmp    dd60 <f0+0x1f80>
    ea30:	4c 89 e7             	mov    %r12,%rdi
    ea33:	e8 98 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea38:	e9 c2 f3 ff ff       	jmp    ddff <f0+0x201f>
    ea3d:	4c 89 e7             	mov    %r12,%rdi
    ea40:	e8 8b 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea45:	e9 54 f4 ff ff       	jmp    de9e <f0+0x20be>
    ea4a:	4c 89 e7             	mov    %r12,%rdi
    ea4d:	e8 7e 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea52:	e9 e6 f4 ff ff       	jmp    df3d <f0+0x215d>
    ea57:	4c 89 e7             	mov    %r12,%rdi
    ea5a:	e8 71 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea5f:	e9 78 f5 ff ff       	jmp    dfdc <f0+0x21fc>
    ea64:	4c 89 e7             	mov    %r12,%rdi
    ea67:	e8 64 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea6c:	e9 0a f6 ff ff       	jmp    e07b <f0+0x229b>
    ea71:	4c 89 e7             	mov    %r12,%rdi
    ea74:	e8 57 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea79:	e9 9c f6 ff ff       	jmp    e11a <f0+0x233a>
    ea7e:	4c 89 e7             	mov    %r12,%rdi
    ea81:	e8 4a 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea86:	e9 2e f7 ff ff       	jmp    e1b9 <f0+0x23d9>
    ea8b:	4c 89 e7             	mov    %r12,%rdi
    ea8e:	e8 3d 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ea93:	e9 c0 f7 ff ff       	jmp    e258 <f0+0x2478>
    ea98:	4c 89 e7             	mov    %r12,%rdi
    ea9b:	e8 30 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    eaa0:	e9 52 f8 ff ff       	jmp    e2f7 <f0+0x2517>
    eaa5:	4c 89 e7             	mov    %r12,%rdi
    eaa8:	e8 23 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    eaad:	e9 e4 f8 ff ff       	jmp    e396 <f0+0x25b6>
    eab2:	4c 89 e7             	mov    %r12,%rdi
    eab5:	e8 16 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    eaba:	e9 76 f9 ff ff       	jmp    e435 <f0+0x2655>
    eabf:	4c 89 e7             	mov    %r12,%rdi
    eac2:	e8 09 6d ff ff       	call   57d0 <fwp_rc_forget_slot>
    eac7:	e9 08 fa ff ff       	jmp    e4d4 <f0+0x26f4>
    eacc:	4c 89 e7             	mov    %r12,%rdi
    eacf:	e8 fc 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    ead4:	e9 9a fa ff ff       	jmp    e573 <f0+0x2793>
    ead9:	e8 72 49 ff ff       	call   3450 <__stack_chk_fail@plt>
    eade:	66 90                	xchg   %ax,%ax

000000000000eae0 <fwp_main_thread>:
    eae0:	f3 0f 1e fa          	endbr64
    eae4:	41 54                	push   %r12
    eae6:	55                   	push   %rbp
    eae7:	53                   	push   %rbx
    eae8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    eaef:	8b 0d ef f0 05 00    	mov    0x5f0ef(%rip),%ecx        # 6dbe4 <fwp_heap+0x13a4>
    eaf5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    eafc:	00 00 
    eafe:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    eb05:	00 
    eb06:	31 c0                	xor    %eax,%eax
    eb08:	85 c9                	test   %ecx,%ecx
    eb0a:	0f 84 58 07 00 00    	je     f268 <fwp_main_thread+0x788>
    eb10:	8b 15 d2 f0 05 00    	mov    0x5f0d2(%rip),%edx        # 6dbe8 <fwp_heap+0x13a8>
    eb16:	85 d2                	test   %edx,%edx
    eb18:	0f 85 32 07 00 00    	jne    f250 <fwp_main_thread+0x770>
    eb1e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    eb23:	31 f6                	xor    %esi,%esi
    eb25:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    eb2a:	48 c7 05 ab d6 05 00 	movq   $0x40000000,0x5d6ab(%rip)        # 6c1e0 <fwp_main_stack_size>
    eb31:	00 00 00 40 
    eb35:	48 89 05 ac d6 05 00 	mov    %rax,0x5d6ac(%rip)        # 6c1e8 <fwp_main_stack_top>
    eb3c:	48 8d 05 5d 55 00 00 	lea    0x555d(%rip),%rax        # 140a0 <alt.5>
    eb43:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    eb48:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    eb4f:	01 00 
    eb51:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    eb58:	00 
    eb59:	e8 42 4b ff ff       	call   36a0 <sigaltstack@plt>
    eb5e:	85 c0                	test   %eax,%eax
    eb60:	0f 85 6a 07 00 00    	jne    f2d0 <fwp_main_thread+0x7f0>
    eb66:	31 c0                	xor    %eax,%eax
    eb68:	b9 12 00 00 00       	mov    $0x12,%ecx
    eb6d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    eb72:	f3 48 ab             	rep stos %rax,(%rdi)
    eb75:	48 8d 05 c4 51 ff ff 	lea    -0xae3c(%rip),%rax        # 3d40 <fwp_segv>
    eb7c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    eb81:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    eb88:	04 00 00 08 
    eb8c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    eb91:	e8 ca 49 ff ff       	call   3560 <sigemptyset@plt>
    eb96:	85 c0                	test   %eax,%eax
    eb98:	0f 85 32 07 00 00    	jne    f2d0 <fwp_main_thread+0x7f0>
    eb9e:	31 d2                	xor    %edx,%edx
    eba0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    eba5:	bf 0b 00 00 00       	mov    $0xb,%edi
    ebaa:	e8 41 48 ff ff       	call   33f0 <sigaction@plt>
    ebaf:	85 c0                	test   %eax,%eax
    ebb1:	0f 85 19 07 00 00    	jne    f2d0 <fwp_main_thread+0x7f0>
    ebb7:	31 d2                	xor    %edx,%edx
    ebb9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    ebbe:	bf 07 00 00 00       	mov    $0x7,%edi
    ebc3:	e8 28 48 ff ff       	call   33f0 <sigaction@plt>
    ebc8:	85 c0                	test   %eax,%eax
    ebca:	0f 85 00 07 00 00    	jne    f2d0 <fwp_main_thread+0x7f0>
    ebd0:	48 8b 05 89 f0 05 00 	mov    0x5f089(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    ebd7:	48 85 c0             	test   %rax,%rax
    ebda:	0f 88 50 06 00 00    	js     f230 <fwp_main_thread+0x750>
    ebe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ebe4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    ebe9:	48 8d 3d 30 56 ff ff 	lea    -0xa9d0(%rip),%rdi        # 4220 <ad_raw_report>
    ebf0:	f2 0f 11 05 f0 f8 05 	movsd  %xmm0,0x5f8f0(%rip)        # 6e4e8 <iteration_start_charge>
    ebf7:	00 
    ebf8:	c7 05 06 f9 05 00 01 	movl   $0x1,0x5f906(%rip)        # 6e508 <iteration_active>
    ebff:	00 00 00 
    ec02:	e8 09 09 00 00       	call   f510 <atexit>
    ec07:	85 c0                	test   %eax,%eax
    ec09:	0f 85 cd 06 00 00    	jne    f2dc <fwp_main_thread+0x7fc>
    ec0f:	8b 05 7b 54 00 00    	mov    0x547b(%rip),%eax        # 14090 <st.3>
    ec15:	85 c0                	test   %eax,%eax
    ec17:	0f 84 5b 06 00 00    	je     f278 <fwp_main_thread+0x798>
    ec1d:	48 8b 2d fc db 05 00 	mov    0x5dbfc(%rip),%rbp        # 6c820 <fwp_cur>
    ec24:	48 85 ed             	test   %rbp,%rbp
    ec27:	0f 84 03 03 00 00    	je     ef30 <fwp_main_thread+0x450>
    ec2d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ec32:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ec36:	48 89 eb             	mov    %rbp,%rbx
    ec39:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ec3e:	0f 84 41 01 00 00    	je     ed85 <fwp_main_thread+0x2a5>
    ec44:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    ec49:	0f 84 11 02 00 00    	je     ee60 <fwp_main_thread+0x380>
    ec4f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ec53:	0f 84 f7 01 00 00    	je     ee50 <fwp_main_thread+0x370>
    ec59:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ec5d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ec61:	0f 85 79 02 00 00    	jne    eee0 <fwp_main_thread+0x400>
    ec67:	48 8b 43 60          	mov    0x60(%rbx),%rax
    ec6b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ec72:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ec76:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ec7d:	00 00 00 00 
    ec81:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ec88:	48 85 d2             	test   %rdx,%rdx
    ec8b:	74 07                	je     ec94 <fwp_main_thread+0x1b4>
    ec8d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ec94:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ec98:	48 85 c0             	test   %rax,%rax
    ec9b:	74 34                	je     ecd1 <fwp_main_thread+0x1f1>
    ec9d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    eca1:	48 8b 05 50 db 05 00 	mov    0x5db50(%rip),%rax        # 6c7f8 <fwp_timers>
    eca8:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ecac:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ecb3:	00 00 00 00 
    ecb7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ecbe:	48 85 c0             	test   %rax,%rax
    ecc1:	74 07                	je     ecca <fwp_main_thread+0x1ea>
    ecc3:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ecca:	48 89 1d 27 db 05 00 	mov    %rbx,0x5db27(%rip)        # 6c7f8 <fwp_timers>
    ecd1:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ecd5:	e8 76 8e ff ff       	call   7b50 <fwp_block>
    ecda:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    ece1:	48 85 c9             	test   %rcx,%rcx
    ece4:	74 47                	je     ed2d <fwp_main_thread+0x24d>
    ece6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    eced:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ecf4:	48 85 d2             	test   %rdx,%rdx
    ecf7:	0f 84 23 02 00 00    	je     ef20 <fwp_main_thread+0x440>
    ecfd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ed04:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ed0b:	48 85 c0             	test   %rax,%rax
    ed0e:	74 07                	je     ed17 <fwp_main_thread+0x237>
    ed10:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ed17:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ed1e:	00 00 00 00 
    ed22:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ed26:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    ed2d:	48 8b 0d ec da 05 00 	mov    0x5daec(%rip),%rcx        # 6c820 <fwp_cur>
    ed34:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ed38:	0f 84 92 01 00 00    	je     eed0 <fwp_main_thread+0x3f0>
    ed3e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    ed45:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    ed4c:	48 85 d2             	test   %rdx,%rdx
    ed4f:	0f 84 1b 04 00 00    	je     f170 <fwp_main_thread+0x690>
    ed55:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    ed5c:	48 85 c0             	test   %rax,%rax
    ed5f:	74 07                	je     ed68 <fwp_main_thread+0x288>
    ed61:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    ed68:	66 0f ef db          	pxor   %xmm3,%xmm3
    ed6c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    ed70:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    ed77:	48 89 cb             	mov    %rcx,%rbx
    ed7a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ed7f:	0f 85 bf fe ff ff    	jne    ec44 <fwp_main_thread+0x164>
    ed85:	48 83 3d 2b f7 05 00 	cmpq   $0x0,0x5f72b(%rip)        # 6e4b8 <fwp_state_len>
    ed8c:	00 
    ed8d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    ed91:	0f 84 0b 04 00 00    	je     f1a2 <fwp_main_thread+0x6c2>
    ed97:	48 3b 1d 7a da 05 00 	cmp    0x5da7a(%rip),%rbx        # 6c818 <fwp_root>
    ed9e:	c7 05 f8 52 01 00 00 	movl   $0x0,0x152f8(%rip)        # 240a0 <fwp_exit_code>
    eda5:	00 00 00 
    eda8:	0f 85 4c 05 00 00    	jne    f2fa <fwp_main_thread+0x81a>
    edae:	48 85 db             	test   %rbx,%rbx
    edb1:	0f 84 9f 01 00 00    	je     ef56 <fwp_main_thread+0x476>
    edb7:	48 8b 15 2a da 05 00 	mov    0x5da2a(%rip),%rdx        # 6c7e8 <fwp_tasks_active>
    edbe:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    edc2:	48 85 d2             	test   %rdx,%rdx
    edc5:	0f 84 8b 01 00 00    	je     ef56 <fwp_main_thread+0x476>
    edcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    edd0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    edd4:	75 08                	jne    edde <fwp_main_thread+0x2fe>
    edd6:	48 89 d7             	mov    %rdx,%rdi
    edd9:	e8 52 53 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    edde:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    ede5:	48 85 d2             	test   %rdx,%rdx
    ede8:	75 e6                	jne    edd0 <fwp_main_thread+0x2f0>
    edea:	eb 31                	jmp    ee1d <fwp_main_thread+0x33d>
    edec:	0f 1f 40 00          	nopl   0x0(%rax)
    edf0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    edf7:	48 89 1d 02 da 05 00 	mov    %rbx,0x5da02(%rip)        # 6c800 <fwp_ready_tail>
    edfe:	e8 4d 8d ff ff       	call   7b50 <fwp_block>
    ee03:	e8 48 8b ff ff       	call   7950 <fwp_free_zombie>
    ee08:	48 83 3d d8 d9 05 00 	cmpq   $0x0,0x5d9d8(%rip)        # 6c7e8 <fwp_tasks_active>
    ee0f:	00 
    ee10:	0f 84 40 01 00 00    	je     ef56 <fwp_main_thread+0x476>
    ee16:	48 8b 1d fb d9 05 00 	mov    0x5d9fb(%rip),%rbx        # 6c818 <fwp_root>
    ee1d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    ee21:	75 db                	jne    edfe <fwp_main_thread+0x31e>
    ee23:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    ee27:	75 d5                	jne    edfe <fwp_main_thread+0x31e>
    ee29:	48 8b 05 d0 d9 05 00 	mov    0x5d9d0(%rip),%rax        # 6c800 <fwp_ready_tail>
    ee30:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    ee34:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    ee3b:	00 00 00 00 
    ee3f:	48 85 c0             	test   %rax,%rax
    ee42:	75 ac                	jne    edf0 <fwp_main_thread+0x310>
    ee44:	48 89 1d bd d9 05 00 	mov    %rbx,0x5d9bd(%rip)        # 6c808 <fwp_ready_head>
    ee4b:	eb aa                	jmp    edf7 <fwp_main_thread+0x317>
    ee4d:	0f 1f 00             	nopl   (%rax)
    ee50:	e8 6b 57 ff ff       	call   45c0 <fwp_now_ns>
    ee55:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ee59:	0f 8d 21 03 00 00    	jge    f180 <fwp_main_thread+0x6a0>
    ee5f:	90                   	nop
    ee60:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ee64:	0f 85 ef fd ff ff    	jne    ec59 <fwp_main_thread+0x179>
    ee6a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ee6e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ee72:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ee76:	0f 85 ef fd ff ff    	jne    ec6b <fwp_main_thread+0x18b>
    ee7c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ee80:	48 85 c9             	test   %rcx,%rcx
    ee83:	0f 84 e2 fd ff ff    	je     ec6b <fwp_main_thread+0x18b>
    ee89:	48 85 c0             	test   %rax,%rax
    ee8c:	0f 84 5b 04 00 00    	je     f2ed <fwp_main_thread+0x80d>
    ee92:	48 39 c8             	cmp    %rcx,%rax
    ee95:	48 0f 4f c1          	cmovg  %rcx,%rax
    ee99:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eea0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    eea4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    eeab:	00 00 00 00 
    eeaf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    eeb6:	48 85 d2             	test   %rdx,%rdx
    eeb9:	74 07                	je     eec2 <fwp_main_thread+0x3e2>
    eebb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    eec2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eec6:	e9 d2 fd ff ff       	jmp    ec9d <fwp_main_thread+0x1bd>
    eecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    eed0:	48 89 cb             	mov    %rcx,%rbx
    eed3:	e9 61 fd ff ff       	jmp    ec39 <fwp_main_thread+0x159>
    eed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    eedf:	00 
    eee0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    eee4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eeeb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    eef2:	00 00 00 00 
    eef6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    eefd:	48 85 c0             	test   %rax,%rax
    ef00:	0f 84 9a 03 00 00    	je     f2a0 <fwp_main_thread+0x7c0>
    ef06:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    ef0d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ef11:	e9 bb fd ff ff       	jmp    ecd1 <fwp_main_thread+0x1f1>
    ef16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ef1d:	00 00 00 
    ef20:	48 89 01             	mov    %rax,(%rcx)
    ef23:	e9 e3 fd ff ff       	jmp    ed0b <fwp_main_thread+0x22b>
    ef28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ef2f:	00 
    ef30:	48 83 3d 80 f5 05 00 	cmpq   $0x0,0x5f580(%rip)        # 6e4b8 <fwp_state_len>
    ef37:	00 
    ef38:	0f 84 62 02 00 00    	je     f1a0 <fwp_main_thread+0x6c0>
    ef3e:	48 83 3d d2 d8 05 00 	cmpq   $0x0,0x5d8d2(%rip)        # 6c818 <fwp_root>
    ef45:	00 
    ef46:	c7 05 50 51 01 00 00 	movl   $0x0,0x15150(%rip)        # 240a0 <fwp_exit_code>
    ef4d:	00 00 00 
    ef50:	0f 85 9f 03 00 00    	jne    f2f5 <fwp_main_thread+0x815>
    ef56:	e8 f5 89 ff ff       	call   7950 <fwp_free_zombie>
    ef5b:	48 83 3d a5 d8 05 00 	cmpq   $0x0,0x5d8a5(%rip)        # 6c808 <fwp_ready_head>
    ef62:	00 
    ef63:	0f 85 e7 47 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef69:	48 83 3d 87 d8 05 00 	cmpq   $0x0,0x5d887(%rip)        # 6c7f8 <fwp_timers>
    ef70:	00 
    ef71:	0f 85 d9 47 ff ff    	jne    3750 <fwp_main_thread.cold>
    ef77:	8b 1d 77 d2 05 00    	mov    0x5d277(%rip),%ebx        # 6c1f4 <fwp_stack_pool_n>
    ef7d:	85 db                	test   %ebx,%ebx
    ef7f:	74 36                	je     efb7 <fwp_main_thread+0x4d7>
    ef81:	83 eb 01             	sub    $0x1,%ebx
    ef84:	48 8d 05 75 d2 05 00 	lea    0x5d275(%rip),%rax        # 6c200 <fwp_stack_pool>
    ef8b:	48 63 d3             	movslq %ebx,%rdx
    ef8e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    ef92:	eb 07                	jmp    ef9b <fwp_main_thread+0x4bb>
    ef94:	0f 1f 40 00          	nopl   0x0(%rax)
    ef98:	83 eb 01             	sub    $0x1,%ebx
    ef9b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    ef9f:	be 00 00 00 10       	mov    $0x10000000,%esi
    efa4:	89 1d 4a d2 05 00    	mov    %ebx,0x5d24a(%rip)        # 6c1f4 <fwp_stack_pool_n>
    efaa:	48 83 ed 08          	sub    $0x8,%rbp
    efae:	e8 0d 46 ff ff       	call   35c0 <munmap@plt>
    efb3:	85 db                	test   %ebx,%ebx
    efb5:	75 e1                	jne    ef98 <fwp_main_thread+0x4b8>
    efb7:	8b 3d 63 50 00 00    	mov    0x5063(%rip),%edi        # 14020 <fwp_epfd>
    efbd:	85 ff                	test   %edi,%edi
    efbf:	78 05                	js     efc6 <fwp_main_thread+0x4e6>
    efc1:	e8 fa 44 ff ff       	call   34c0 <close@plt>
    efc6:	4c 8b 25 33 d4 05 00 	mov    0x5d433(%rip),%r12        # 6c400 <fwp_nfdws>
    efcd:	48 8b 2d 34 d4 05 00 	mov    0x5d434(%rip),%rbp        # 6c408 <fwp_fdws>
    efd4:	31 db                	xor    %ebx,%ebx
    efd6:	c7 05 40 50 00 00 ff 	movl   $0xffffffff,0x5040(%rip)        # 14020 <fwp_epfd>
    efdd:	ff ff ff 
    efe0:	4d 85 e4             	test   %r12,%r12
    efe3:	74 38                	je     f01d <fwp_main_thread+0x53d>
    efe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    efec:	00 00 00 00 
    eff0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    eff5:	48 85 ff             	test   %rdi,%rdi
    eff8:	74 1a                	je     f014 <fwp_main_thread+0x534>
    effa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    effe:	0f 85 4c 47 ff ff    	jne    3750 <fwp_main_thread.cold>
    f004:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    f009:	0f 85 41 47 ff ff    	jne    3750 <fwp_main_thread.cold>
    f00f:	e8 fc 69 ff ff       	call   5a10 <fwp_mem_free>
    f014:	48 83 c3 01          	add    $0x1,%rbx
    f018:	49 39 dc             	cmp    %rbx,%r12
    f01b:	75 d3                	jne    eff0 <fwp_main_thread+0x510>
    f01d:	48 89 ef             	mov    %rbp,%rdi
    f020:	e8 eb 69 ff ff       	call   5a10 <fwp_mem_free>
    f025:	48 8b 15 ec d7 05 00 	mov    0x5d7ec(%rip),%rdx        # 6c818 <fwp_root>
    f02c:	48 c7 05 d1 d3 05 00 	movq   $0x0,0x5d3d1(%rip)        # 6c408 <fwp_fdws>
    f033:	00 00 00 00 
    f037:	48 c7 05 be d3 05 00 	movq   $0x0,0x5d3be(%rip)        # 6c400 <fwp_nfdws>
    f03e:	00 00 00 00 
    f042:	48 85 d2             	test   %rdx,%rdx
    f045:	74 4e                	je     f095 <fwp_main_thread+0x5b5>
    f047:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    f04c:	0f 85 fe 46 ff ff    	jne    3750 <fwp_main_thread.cold>
    f052:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    f059:	00 
    f05a:	0f 85 f0 46 ff ff    	jne    3750 <fwp_main_thread.cold>
    f060:	48 83 3d 50 f4 05 00 	cmpq   $0x0,0x5f450(%rip)        # 6e4b8 <fwp_state_len>
    f067:	00 
    f068:	0f 85 e2 46 ff ff    	jne    3750 <fwp_main_thread.cold>
    f06e:	48 83 3d 32 f4 05 00 	cmpq   $0x0,0x5f432(%rip)        # 6e4a8 <fwp_state_owners>
    f075:	00 
    f076:	0f 85 d4 46 ff ff    	jne    3750 <fwp_main_thread.cold>
    f07c:	b9 79 00 00 00       	mov    $0x79,%ecx
    f081:	31 c0                	xor    %eax,%eax
    f083:	48 8d 3d 96 d3 05 00 	lea    0x5d396(%rip),%rdi        # 6c420 <fwp_root_context>
    f08a:	f3 48 ab             	rep stos %rax,(%rdi)
    f08d:	48 89 d7             	mov    %rdx,%rdi
    f090:	e8 7b 69 ff ff       	call   5a10 <fwp_mem_free>
    f095:	66 0f 6f 05 33 51 04 	movdqa 0x45133(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    f09c:	00 
    f09d:	66 0f d4 05 1b 51 04 	paddq  0x4511b(%rip),%xmm0        # 541c0 <ad_raw_live>
    f0a4:	00 
    f0a5:	48 c7 05 70 d7 05 00 	movq   $0x0,0x5d770(%rip)        # 6c820 <fwp_cur>
    f0ac:	00 00 00 00 
    f0b0:	48 8b 05 a9 eb 05 00 	mov    0x5eba9(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    f0b7:	48 c7 05 56 d7 05 00 	movq   $0x0,0x5d756(%rip)        # 6c818 <fwp_root>
    f0be:	00 00 00 00 
    f0c2:	c7 05 3c f4 05 00 00 	movl   $0x0,0x5f43c(%rip)        # 6e508 <iteration_active>
    f0c9:	00 00 00 
    f0cc:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    f0d0:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    f0d5:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    f0d9:	66 0f d6 05 37 50 01 	movq   %xmm0,0x15037(%rip)        # 24118 <ad_raw_before_shutdown>
    f0e0:	00 
    f0e1:	48 85 c0             	test   %rax,%rax
    f0e4:	0f 88 26 01 00 00    	js     f210 <fwp_main_thread+0x730>
    f0ea:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f0ee:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    f0f3:	f2 0f 5c 0d ed f3 05 	subsd  0x5f3ed(%rip),%xmm1        # 6e4e8 <iteration_start_charge>
    f0fa:	00 
    f0fb:	48 8b 3d 5e 4f 00 00 	mov    0x4f5e(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    f102:	48 8d 15 57 1a 00 00 	lea    0x1a57(%rip),%rdx        # 10b60 <_IO_stdin_used+0xb60>
    f109:	be 02 00 00 00       	mov    $0x2,%esi
    f10e:	f2 0f 10 05 ca f3 05 	movsd  0x5f3ca(%rip),%xmm0        # 6e4e0 <iteration_peak>
    f115:	00 
    f116:	4c 8b 0d d3 f3 05 00 	mov    0x5f3d3(%rip),%r9        # 6e4f0 <iteration_retains>
    f11d:	b8 02 00 00 00       	mov    $0x2,%eax
    f122:	4c 8b 05 cf f3 05 00 	mov    0x5f3cf(%rip),%r8        # 6e4f8 <iteration_bytes>
    f129:	48 8b 0d d0 f3 05 00 	mov    0x5f3d0(%rip),%rcx        # 6e500 <iteration_requests>
    f130:	e8 3b 45 ff ff       	call   3670 <__fprintf_chk@plt>
    f135:	48 8b 3d 04 4f 00 00 	mov    0x4f04(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    f13c:	e8 5f 44 ff ff       	call   35a0 <fflush@plt>
    f141:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    f148:	00 
    f149:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    f150:	00 00 
    f152:	0f 85 90 01 00 00    	jne    f2e8 <fwp_main_thread+0x808>
    f158:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    f15f:	31 c0                	xor    %eax,%eax
    f161:	5b                   	pop    %rbx
    f162:	5d                   	pop    %rbp
    f163:	41 5c                	pop    %r12
    f165:	c3                   	ret
    f166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f16d:	00 00 00 
    f170:	48 89 05 81 d6 05 00 	mov    %rax,0x5d681(%rip)        # 6c7f8 <fwp_timers>
    f177:	e9 e0 fb ff ff       	jmp    ed5c <fwp_main_thread+0x27c>
    f17c:	0f 1f 40 00          	nopl   0x0(%rax)
    f180:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    f184:	0f 85 d6 fc ff ff    	jne    ee60 <fwp_main_thread+0x380>
    f18a:	48 89 ef             	mov    %rbp,%rdi
    f18d:	e8 9e 4f ff ff       	call   4130 <fwp_cancel_tree.part.0>
    f192:	e9 c9 fc ff ff       	jmp    ee60 <fwp_main_thread+0x380>
    f197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f19e:	00 00 
    f1a0:	31 db                	xor    %ebx,%ebx
    f1a2:	48 83 3d fe f2 05 00 	cmpq   $0x0,0x5f2fe(%rip)        # 6e4a8 <fwp_state_owners>
    f1a9:	00 
    f1aa:	0f 85 e7 fb ff ff    	jne    ed97 <fwp_main_thread+0x2b7>
    f1b0:	48 8b 3d 09 f3 05 00 	mov    0x5f309(%rip),%rdi        # 6e4c0 <fwp_state>
    f1b7:	e8 54 68 ff ff       	call   5a10 <fwp_mem_free>
    f1bc:	48 c7 05 f9 f2 05 00 	movq   $0x0,0x5f2f9(%rip)        # 6e4c0 <fwp_state>
    f1c3:	00 00 00 00 
    f1c7:	48 c7 05 de f2 05 00 	movq   $0x0,0x5f2de(%rip)        # 6e4b0 <fwp_state_cap>
    f1ce:	00 00 00 00 
    f1d2:	48 85 db             	test   %rbx,%rbx
    f1d5:	0f 84 ce 00 00 00    	je     f2a9 <fwp_main_thread+0x7c9>
    f1db:	48 39 1d 36 d6 05 00 	cmp    %rbx,0x5d636(%rip)        # 6c818 <fwp_root>
    f1e2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    f1e9:	00 00 00 00 
    f1ed:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    f1f4:	00 00 00 00 
    f1f8:	c7 05 9e 4e 01 00 00 	movl   $0x0,0x14e9e(%rip)        # 240a0 <fwp_exit_code>
    f1ff:	00 00 00 
    f202:	0f 84 af fb ff ff    	je     edb7 <fwp_main_thread+0x2d7>
    f208:	e9 43 45 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f20d:	0f 1f 00             	nopl   (%rax)
    f210:	48 89 c2             	mov    %rax,%rdx
    f213:	83 e0 01             	and    $0x1,%eax
    f216:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f21a:	48 d1 ea             	shr    $1,%rdx
    f21d:	48 09 c2             	or     %rax,%rdx
    f220:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    f225:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    f229:	e9 c5 fe ff ff       	jmp    f0f3 <fwp_main_thread+0x613>
    f22e:	66 90                	xchg   %ax,%ax
    f230:	48 89 c2             	mov    %rax,%rdx
    f233:	83 e0 01             	and    $0x1,%eax
    f236:	66 0f ef c0          	pxor   %xmm0,%xmm0
    f23a:	48 d1 ea             	shr    $1,%rdx
    f23d:	48 09 c2             	or     %rax,%rdx
    f240:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    f245:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    f249:	e9 9b f9 ff ff       	jmp    ebe9 <fwp_main_thread+0x109>
    f24e:	66 90                	xchg   %ax,%ax
    f250:	48 8d 3d 69 5a ff ff 	lea    -0xa597(%rip),%rdi        # 4cc0 <fwp_heap_report>
    f257:	e8 b4 02 00 00       	call   f510 <atexit>
    f25c:	e9 bd f8 ff ff       	jmp    eb1e <fwp_main_thread+0x3e>
    f261:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    f268:	e8 63 5b ff ff       	call   4dd0 <fwp_heap_init>
    f26d:	e9 9e f8 ff ff       	jmp    eb10 <fwp_main_thread+0x30>
    f272:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f278:	e8 63 cb ff ff       	call   bde0 <f0>
    f27d:	48 c7 05 00 4e 00 00 	movq   $0x0,0x4e00(%rip)        # 14088 <v.2>
    f284:	00 00 00 00 
    f288:	c7 05 fe 4d 00 00 01 	movl   $0x1,0x4dfe(%rip)        # 14090 <st.3>
    f28f:	00 00 00 
    f292:	e9 86 f9 ff ff       	jmp    ec1d <fwp_main_thread+0x13d>
    f297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f29e:	00 00 
    f2a0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f2a4:	e9 28 fa ff ff       	jmp    ecd1 <fwp_main_thread+0x1f1>
    f2a9:	48 83 3d 67 d5 05 00 	cmpq   $0x0,0x5d567(%rip)        # 6c818 <fwp_root>
    f2b0:	00 
    f2b1:	c7 05 e5 4d 01 00 00 	movl   $0x0,0x14de5(%rip)        # 240a0 <fwp_exit_code>
    f2b8:	00 00 00 
    f2bb:	0f 84 95 fc ff ff    	je     ef56 <fwp_main_thread+0x476>
    f2c1:	e9 8a 44 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f2c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f2cd:	00 00 00 
    f2d0:	48 8d 3d 61 18 00 00 	lea    0x1861(%rip),%rdi        # 10b38 <_IO_stdin_used+0xb38>
    f2d7:	e8 74 51 ff ff       	call   4450 <fwp_trap>
    f2dc:	48 8d 3d f0 0f 00 00 	lea    0xff0(%rip),%rdi        # 102d3 <_IO_stdin_used+0x2d3>
    f2e3:	e8 18 4d ff ff       	call   4000 <ad_raw_fail>
    f2e8:	e8 63 41 ff ff       	call   3450 <__stack_chk_fail@plt>
    f2ed:	48 89 c8             	mov    %rcx,%rax
    f2f0:	e9 a4 fb ff ff       	jmp    ee99 <fwp_main_thread+0x3b9>
    f2f5:	e9 56 44 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f2fa:	e9 51 44 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f2ff:	90                   	nop

000000000000f300 <__divmodti4>:
    f300:	f3 0f 1e fa          	endbr64
    f304:	55                   	push   %rbp
    f305:	49 89 f1             	mov    %rsi,%r9
    f308:	49 89 d2             	mov    %rdx,%r10
    f30b:	48 89 fe             	mov    %rdi,%rsi
    f30e:	49 89 cb             	mov    %rcx,%r11
    f311:	48 89 e5             	mov    %rsp,%rbp
    f314:	41 57                	push   %r15
    f316:	41 56                	push   %r14
    f318:	41 55                	push   %r13
    f31a:	41 54                	push   %r12
    f31c:	53                   	push   %rbx
    f31d:	4c 89 c3             	mov    %r8,%rbx
    f320:	45 31 c0             	xor    %r8d,%r8d
    f323:	4d 85 c9             	test   %r9,%r9
    f326:	79 12                	jns    f33a <__divmodti4+0x3a>
    f328:	31 ff                	xor    %edi,%edi
    f32a:	48 f7 de             	neg    %rsi
    f32d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    f334:	4c 19 cf             	sbb    %r9,%rdi
    f337:	49 89 f9             	mov    %rdi,%r9
    f33a:	4c 89 d8             	mov    %r11,%rax
    f33d:	4d 85 db             	test   %r11,%r11
    f340:	0f 88 1a 01 00 00    	js     f460 <__divmodti4+0x160>
    f346:	4c 89 d9             	mov    %r11,%rcx
    f349:	49 89 f3             	mov    %rsi,%r11
    f34c:	75 62                	jne    f3b0 <__divmodti4+0xb0>
    f34e:	4d 89 c4             	mov    %r8,%r12
    f351:	4d 39 d1             	cmp    %r10,%r9
    f354:	0f 83 46 01 00 00    	jae    f4a0 <__divmodti4+0x1a0>
    f35a:	4c 89 d8             	mov    %r11,%rax
    f35d:	4c 89 ca             	mov    %r9,%rdx
    f360:	49 f7 f2             	div    %r10
    f363:	49 89 c3             	mov    %rax,%r11
    f366:	31 c0                	xor    %eax,%eax
    f368:	48 89 d6             	mov    %rdx,%rsi
    f36b:	31 ff                	xor    %edi,%edi
    f36d:	4c 89 d9             	mov    %r11,%rcx
    f370:	48 89 c2             	mov    %rax,%rdx
    f373:	48 89 c8             	mov    %rcx,%rax
    f376:	4d 85 e4             	test   %r12,%r12
    f379:	74 0a                	je     f385 <__divmodti4+0x85>
    f37b:	48 f7 d8             	neg    %rax
    f37e:	48 83 d2 00          	adc    $0x0,%rdx
    f382:	48 f7 da             	neg    %rdx
    f385:	4d 85 c0             	test   %r8,%r8
    f388:	74 0a                	je     f394 <__divmodti4+0x94>
    f38a:	48 f7 de             	neg    %rsi
    f38d:	48 83 d7 00          	adc    $0x0,%rdi
    f391:	48 f7 df             	neg    %rdi
    f394:	48 89 33             	mov    %rsi,(%rbx)
    f397:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    f39b:	5b                   	pop    %rbx
    f39c:	41 5c                	pop    %r12
    f39e:	41 5d                	pop    %r13
    f3a0:	41 5e                	pop    %r14
    f3a2:	41 5f                	pop    %r15
    f3a4:	5d                   	pop    %rbp
    f3a5:	c3                   	ret
    f3a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f3ad:	00 00 00 
    f3b0:	4d 89 c4             	mov    %r8,%r12
    f3b3:	49 39 c1             	cmp    %rax,%r9
    f3b6:	0f 82 ce 00 00 00    	jb     f48a <__divmodti4+0x18a>
    f3bc:	31 ff                	xor    %edi,%edi
    f3be:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    f3c3:	48 63 c7             	movslq %edi,%rax
    f3c6:	be 40 00 00 00       	mov    $0x40,%esi
    f3cb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    f3d0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    f3d5:	48 29 c6             	sub    %rax,%rsi
    f3d8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    f3dd:	48 09 c8             	or     %rcx,%rax
    f3e0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    f3e5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    f3ea:	49 89 c6             	mov    %rax,%r14
    f3ed:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    f3f1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    f3f6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    f3fb:	49 09 c1             	or     %rax,%r9
    f3fe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    f402:	4c 89 c8             	mov    %r9,%rax
    f405:	49 f7 f6             	div    %r14
    f408:	48 89 d1             	mov    %rdx,%rcx
    f40b:	49 89 c3             	mov    %rax,%r11
    f40e:	49 89 c1             	mov    %rax,%r9
    f411:	49 f7 e2             	mul    %r10
    f414:	49 89 c6             	mov    %rax,%r14
    f417:	49 89 d2             	mov    %rdx,%r10
    f41a:	48 39 d1             	cmp    %rdx,%rcx
    f41d:	72 07                	jb     f426 <__divmodti4+0x126>
    f41f:	75 17                	jne    f438 <__divmodti4+0x138>
    f421:	49 39 c7             	cmp    %rax,%r15
    f424:	73 12                	jae    f438 <__divmodti4+0x138>
    f426:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    f42a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    f42e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    f432:	49 89 d2             	mov    %rdx,%r10
    f435:	49 89 c6             	mov    %rax,%r14
    f438:	4c 89 f8             	mov    %r15,%rax
    f43b:	4c 29 f0             	sub    %r14,%rax
    f43e:	4c 19 d1             	sbb    %r10,%rcx
    f441:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    f446:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    f44b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    f450:	48 09 c6             	or     %rax,%rsi
    f453:	48 89 cf             	mov    %rcx,%rdi
    f456:	31 c0                	xor    %eax,%eax
    f458:	4c 89 c9             	mov    %r9,%rcx
    f45b:	e9 10 ff ff ff       	jmp    f370 <__divmodti4+0x70>
    f460:	4c 89 d0             	mov    %r10,%rax
    f463:	4c 89 da             	mov    %r11,%rdx
    f466:	4d 89 c4             	mov    %r8,%r12
    f469:	49 89 f3             	mov    %rsi,%r11
    f46c:	48 f7 d8             	neg    %rax
    f46f:	49 f7 d4             	not    %r12
    f472:	48 83 d2 00          	adc    $0x0,%rdx
    f476:	49 89 c2             	mov    %rax,%r10
    f479:	48 f7 da             	neg    %rdx
    f47c:	48 89 d1             	mov    %rdx,%rcx
    f47f:	0f 84 cc fe ff ff    	je     f351 <__divmodti4+0x51>
    f485:	49 39 d1             	cmp    %rdx,%r9
    f488:	73 46                	jae    f4d0 <__divmodti4+0x1d0>
    f48a:	4c 89 cf             	mov    %r9,%rdi
    f48d:	31 c0                	xor    %eax,%eax
    f48f:	31 c9                	xor    %ecx,%ecx
    f491:	e9 da fe ff ff       	jmp    f370 <__divmodti4+0x70>
    f496:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f49d:	00 00 00 
    f4a0:	4d 85 d2             	test   %r10,%r10
    f4a3:	75 0d                	jne    f4b2 <__divmodti4+0x1b2>
    f4a5:	b8 01 00 00 00       	mov    $0x1,%eax
    f4aa:	31 d2                	xor    %edx,%edx
    f4ac:	49 f7 f2             	div    %r10
    f4af:	49 89 c2             	mov    %rax,%r10
    f4b2:	4c 89 c8             	mov    %r9,%rax
    f4b5:	31 d2                	xor    %edx,%edx
    f4b7:	49 f7 f2             	div    %r10
    f4ba:	49 89 c1             	mov    %rax,%r9
    f4bd:	4c 89 d8             	mov    %r11,%rax
    f4c0:	49 f7 f2             	div    %r10
    f4c3:	49 89 c3             	mov    %rax,%r11
    f4c6:	4c 89 c8             	mov    %r9,%rax
    f4c9:	e9 9a fe ff ff       	jmp    f368 <__divmodti4+0x68>
    f4ce:	66 90                	xchg   %ax,%ax
    f4d0:	45 31 f6             	xor    %r14d,%r14d
    f4d3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    f4d8:	44 89 f7             	mov    %r14d,%edi
    f4db:	45 85 f6             	test   %r14d,%r14d
    f4de:	0f 85 df fe ff ff    	jne    f3c3 <__divmodti4+0xc3>
    f4e4:	4c 39 ca             	cmp    %r9,%rdx
    f4e7:	72 17                	jb     f500 <__divmodti4+0x200>
    f4e9:	31 c9                	xor    %ecx,%ecx
    f4eb:	48 39 c6             	cmp    %rax,%rsi
    f4ee:	73 10                	jae    f500 <__divmodti4+0x200>
    f4f0:	4c 89 cf             	mov    %r9,%rdi
    f4f3:	31 c0                	xor    %eax,%eax
    f4f5:	e9 76 fe ff ff       	jmp    f370 <__divmodti4+0x70>
    f4fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f500:	4c 89 de             	mov    %r11,%rsi
    f503:	b9 01 00 00 00       	mov    $0x1,%ecx
    f508:	48 29 c6             	sub    %rax,%rsi
    f50b:	49 19 d1             	sbb    %rdx,%r9
    f50e:	eb e0                	jmp    f4f0 <__divmodti4+0x1f0>

000000000000f510 <atexit>:
    f510:	f3 0f 1e fa          	endbr64
    f514:	48 8b 15 ed 4a 00 00 	mov    0x4aed(%rip),%rdx        # 14008 <__dso_handle>
    f51b:	31 f6                	xor    %esi,%esi
    f51d:	e9 1e 41 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000f524 <_fini>:
    f524:	f3 0f 1e fa          	endbr64
    f528:	48 83 ec 08          	sub    $0x8,%rsp
    f52c:	48 83 c4 08          	add    $0x8,%rsp
    f530:	c3                   	ret
