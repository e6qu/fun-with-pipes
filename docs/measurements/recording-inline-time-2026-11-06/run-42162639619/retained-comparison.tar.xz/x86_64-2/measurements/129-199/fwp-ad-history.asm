
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 dd 00 00 	lea    0xdd01(%rip),%rax        # 11480 <fwp_fn_table>
    377f:	48 89 05 52 1c 02 00 	mov    %rax,0x21c52(%rip)        # 253d8 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c 1c 02 00 	mov    %rax,0x21c4c(%rip)        # 253e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 5f ab 00 00 	lea    0xab5f(%rip),%rdx        # e3c0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e c0 00 00 	lea    0xc08e(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 c0 00 00 	lea    0xc048(%rip),%rdi        # f970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c c0 00 00 	lea    0xc00c(%rip),%rdi        # f940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 bf 00 00 	lea    0xbfd8(%rip),%rdi        # f918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 17 02 00 	mov    0x21769(%rip),%rdi        # 253e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 fa 01 00 	mov    0x1fa61(%rip),%rax        # 23760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 f3 01 00 	mov    0x1f3a1(%rip),%rax        # 23120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d f3 01 00 	sub    0x1f38d(%rip),%rax        # 23118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b 0d 02 00 	mov    0x20d7b(%rip),%rax        # 24b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 0d 02 00 	lea    0x20d74(%rip),%r8        # 24b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 0d 02 00 	mov    0x20d55(%rip),%rbx        # 24b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 0d 02 00 	mov    0x20d65(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 0d 02 00 	mov    0x20d01(%rip),%rdi        # 24b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a 0d 02 00 	sub    %rsi,0x20d4a(%rip)        # 24bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da 0c 02 00 	mov    0x20cda(%rip),%rax        # 24b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 0c 02 00 	add    0x20c90(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e 0c 02 00 	mov    0x20c9e(%rip),%rsi        # 24b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac 0c 02 00 	mov    0x20cac(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b 0c 02 00 	mov    %r12,0x20c5b(%rip)        # 24b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 0c 02 00 	mov    %rbp,0x20c49(%rip)        # 24b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e 0c 02 00 	cmp    %rdi,0x20c2e(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 0c 02 00 	mov    %rdi,0x20c25(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 0c 02 00 	sub    %rdi,0x20c69(%rip)        # 24bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 0c 02 00 	mov    0x20c11(%rip),%rax        # 24b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a 0c 02 00 	lea    0x20c0a(%rip),%r8        # 24b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d f0 00 00 	mov    0xf01d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 f6 01 00 	cmp    0x1f6a9(%rip),%rdi        # 23760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 23740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d f6 01 00 	mov    %rdi,0x1f64d(%rip)        # 23740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 f6 01 00 	mov    %rdi,0x1f629(%rip)        # 23748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 b0 00 00 	lea    0xb005(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ee 00 00 	mov    0xee98(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ee 00 00 	mov    0xee80(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 ed 00 00 	mov    0xed91(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 b2 00 00 	lea    0xb268(%rip),%rdi        # f608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 b6 00 	movdqa 0xb6e0(%rip),%xmm0        # faa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba 0f 02 00 	add    0x20fba(%rip),%rax        # 253d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 b1 00 00 	lea    0xb1c4(%rip),%rdi        # f638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 ec 01 00 	cmp    %rax,0x1ec75(%rip)        # 23108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 ec 01 00 	add    0x1ec70(%rip),%rax        # 23110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad b1 00 00 	lea    0xb1ad(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 a7 00 00 	lea    0xa760(%rip),%rsi        # f1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 00 02 00 	mov    0x20085(%rip),%r9        # 24b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de 00 02 00 	mov    0x200de(%rip),%r8        # 24ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 ab 00 00 	lea    0xabe7(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 00 02 00 	mov    0x200c6(%rip),%rcx        # 24ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 00 02 	movsd  0x200d4(%rip),%xmm1        # 24bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 00 02 	movsd  0x200c4(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 e5 00 00 	mov    0xe565(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 af 00 	movdqa 0xaf78(%rip),%xmm0        # fab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f fb 01 00 	lea    0x1fb7f(%rip),%rax        # 246c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 af 00 	movdqa 0xafa1(%rip),%xmm2        # faf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 fb 01 00 	movaps %xmm0,0x1fb25(%rip)        # 24680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d af 00 	movdqa 0xaf5d(%rip),%xmm0        # fac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 ff 01 00 01 	movl   $0x1,0x1ffb3(%rip)        # 24b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 fb 01 00 	movaps %xmm0,0x1fb13(%rip)        # 24690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b af 00 	movdqa 0xaf4b(%rip),%xmm0        # fad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 fb 01 00 	movaps %xmm0,0x1fb14(%rip)        # 246a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c af 00 	movdqa 0xaf4c(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 fb 01 00 	movaps %xmm0,0x1fb15(%rip)        # 246b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 eb 01 00 	lea    0x1eb95(%rip),%r8        # 23780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 fe 01 00 	mov    %rax,0x1feb0(%rip)        # 24b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e fe 01 00 	mov    %r12,0x1fe8e(%rip)        # 24b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 fe 01 00 	mov    %rax,0x1fe77(%rip)        # 24b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 fe 01 00 	mov    %rbx,0x1fe90(%rip)        # 24b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 fe 01 00 	mov    %rsi,0x1feb9(%rip)        # 24b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 fe 01 00 	mov    %rax,0x1fe98(%rip)        # 24b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c fe 01 00    	mov    %eax,0x1fe1c(%rip)        # 24b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 0c ea 01 00 	mov    0x1ea0c(%rip),%r8        # 23740 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 3c e9 01 00 	mov    %rbx,0x1e93c(%rip)        # 23748 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 28 e9 01 00 	mov    %r8,0x1e928(%rip)        # 23740 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d fd e1 01 00 	lea    0x1e1fd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 e5 e1 01 00 	movaps %xmm0,0x1e1e5(%rip)        # 230c0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 c1 e1 01 00 	mov    %rax,0x1e1c1(%rip)        # 230a8 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 e2 e1 01 00 	movaps %xmm0,0x1e1e2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 e6 e1 01 00 	movaps %xmm0,0x1e1e6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 e7 e1 01 00 	mov    %rdx,0x1e1e7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d b7 e7 01 00 	mov    0x1e7b7(%rip),%rbx        # 23738 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ea df 00 00 	mov    0xdfea(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 a6 00 00 	lea    0xa6c3(%rip),%rdi        # f740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 8d e6 01 00 	mov    0x1e68d(%rip),%rax        # 23740 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 67 e6 01 00 	mov    %rdx,0x1e667(%rip)        # 23740 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d b4 e5 01 00 	mov    0x1e5b4(%rip),%rbx        # 23738 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 71 e5 01 00 	mov    %rbx,0x1e571(%rip)        # 23738 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 71 e5 01 00 	mov    %rdx,0x1e571(%rip)        # 23748 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 86 e5 01 00 	lea    0x1e586(%rip),%rsi        # 23780 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 05 01 02 00 	addq   $0x1,0x20105(%rip)        # 253c8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 a4 00 00 	lea    0xa497(%rip),%rdi        # f770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 a4 00 00 	lea    0xa4a8(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 3e e4 01 00 	lea    0x1e43e(%rip),%rcx        # 23780 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 3f 00 02 00 	subq   $0x1,0x2003f(%rip)        # 253c8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 a4 00 00 	lea    0xa403(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 20 00 02 00 	cmpq   $0x0,0x20020(%rip)        # 253c8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 75 ff 01 00 	sub    %rax,0x1ff75(%rip)        # 253d0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 53 ff 01 00 	add    %r12,0x1ff53(%rip)        # 253d0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 af f6 01 00 	mov    0x1f6af(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 ac e2 01 00 	lea    0x1e2ac(%rip),%rax        # 23780 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 03 f6 01 00 	add    0x1f603(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 d0 f5 01 00 	mov    0x1f5d0(%rip),%rsi        # 24b30 <fwp_heap+0x13b0>
    5560:	48 8b 05 f1 f5 01 00 	mov    0x1f5f1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 e5 f5 01 00 	add    0x1f5e5(%rip),%r8        # 24b78 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 ad f5 01 	addsd  0x1f5ad(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 62 e1 01 00 	lea    0x1e162(%rip),%rax        # 23780 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 6c f5 01 00 	sub    %rdi,0x1f56c(%rip)        # 24ba0 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 84 f5 01 	movsd  %xmm0,0x1f584(%rip)        # 24bc0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 3e f5 01 00 	sub    %rdx,0x1f53e(%rip)        # 24ba0 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 44 f5 01 	addsd  0x1f544(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 38 f5 01 	movsd  %xmm0,0x1f538(%rip)        # 24bc0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 cf f4 01 00 	mov    0x1f4cf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d c9 f4 01 00 	add    %rcx,0x1f4c9(%rip)        # 24bb0 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 82 f4 01 00 	cmp    0x1f482(%rip),%r9        # 24b70 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 79 f4 01 00 	mov    %r9,0x1f479(%rip)        # 24b70 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 6a f4 01 00 	cmp    0x1f46a(%rip),%r9        # 24b68 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 5d f4 01 00 	mov    %r9,0x1f45d(%rip)        # 24b68 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 73 f3 01 00 	add    0x1f373(%rip),%rdi        # 24b78 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 50 df 01 00 	lea    0x1df50(%rip),%r15        # 23780 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 c0 f2 01 00 	add    0x1f2c0(%rip),%r12        # 24b30 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 19 f3 01 00 	add    0x1f319(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 18 f3 01 00 	cmp    %rax,0x1f318(%rip)        # 24ba8 <fwp_heap+0x1428>
    5890:	48 89 05 09 f3 01 00 	mov    %rax,0x1f309(%rip)        # 24ba0 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 08 f3 01 00 	mov    %rax,0x1f308(%rip)        # 24ba8 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 fc f2 01 	movsd  %xmm0,0x1f2fc(%rip)        # 24bb8 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 43 f2 01 00    	mov    0x1f243(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 7f de 01 00 	lea    0x1de7f(%rip),%rdi        # 23780 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 38 f2 01 00 	add    0x1f238(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 33 f2 01 00 	cmp    %rax,0x1f233(%rip)        # 24ba8 <fwp_heap+0x1428>
    5975:	48 89 05 24 f2 01 00 	mov    %rax,0x1f224(%rip)        # 24ba0 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 23 f2 01 00 	mov    %rax,0x1f223(%rip)        # 24ba8 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 1f f2 01 	addsd  0x1f21f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 17 f2 01 	movsd  %xmm0,0x1f217(%rip)        # 24bb8 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ce f0 01 00    	mov    0x1f0ce(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 05 dd 01 00 	lea    0x1dd05(%rip),%rax        # 23780 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 bb f0 01 00 	add    0x1f0bb(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 ba f0 01 00 	cmp    %rax,0x1f0ba(%rip)        # 24ba8 <fwp_heap+0x1428>
    5aee:	48 89 05 ab f0 01 00 	mov    %rax,0x1f0ab(%rip)        # 24ba0 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 aa f0 01 00 	mov    %rax,0x1f0aa(%rip)        # 24ba8 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 a6 f0 01 	addsd  0x1f0a6(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 9e f0 01 	movsd  %xmm0,0x1f09e(%rip)        # 24bb8 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 2c f8 01 00 	add    0x1f82c(%rip),%r9        # 253d8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_tape_reserve>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	41 54                	push   %r12
    5db8:	55                   	push   %rbp
    5db9:	53                   	push   %rbx
    5dba:	48 83 ec 18          	sub    $0x18,%rsp
    5dbe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5dc5:	0f 87 d3 01 00 00    	ja     5f9e <fwp_tape_reserve+0x1ee>
    5dcb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5dcf:	48 89 fd             	mov    %rdi,%rbp
    5dd2:	48 39 f3             	cmp    %rsi,%rbx
    5dd5:	0f 8d 13 01 00 00    	jge    5eee <fwp_tape_reserve+0x13e>
    5ddb:	48 85 db             	test   %rbx,%rbx
    5dde:	b8 40 00 00 00       	mov    $0x40,%eax
    5de3:	48 0f 44 d8          	cmove  %rax,%rbx
    5de7:	48 39 f3             	cmp    %rsi,%rbx
    5dea:	7d 24                	jge    5e10 <fwp_tape_reserve+0x60>
    5dec:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5df3:	0f 8f 07 01 00 00    	jg     5f00 <fwp_tape_reserve+0x150>
    5df9:	48 01 db             	add    %rbx,%rbx
    5dfc:	48 39 f3             	cmp    %rsi,%rbx
    5dff:	7c eb                	jl     5dec <fwp_tape_reserve+0x3c>
    5e01:	0f 1f 40 00          	nopl   0x0(%rax)
    5e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5e0c:	00 00 00 00 
    5e10:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5e17:	00 
    5e18:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5e1c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5e20:	4c 89 ee             	mov    %r13,%rsi
    5e23:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5e27:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5e2b:	e8 a0 d7 ff ff       	call   35d0 <realloc@plt>
    5e30:	48 85 c0             	test   %rax,%rax
    5e33:	0f 84 71 01 00 00    	je     5faa <fwp_tape_reserve+0x1fa>
    5e39:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5e3d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5e41:	4d 29 fc             	sub    %r15,%r12
    5e44:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5e48:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5e4c:	4d 85 f6             	test   %r14,%r14
    5e4f:	0f 84 03 01 00 00    	je     5f58 <fwp_tape_reserve+0x1a8>
    5e55:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5e59:	48 39 da             	cmp    %rbx,%rdx
    5e5c:	7d 78                	jge    5ed6 <fwp_tape_reserve+0x126>
    5e5e:	48 89 d9             	mov    %rbx,%rcx
    5e61:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5e65:	be 02 00 00 00       	mov    $0x2,%esi
    5e6a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5e6f:	48 c1 e1 04          	shl    $0x4,%rcx
    5e73:	48 89 cf             	mov    %rcx,%rdi
    5e76:	48 89 0c 24          	mov    %rcx,(%rsp)
    5e7a:	e8 d1 fb ff ff       	call   5a50 <fwp_heap_alloc>
    5e7f:	49 89 c5             	mov    %rax,%r13
    5e82:	4d 85 ff             	test   %r15,%r15
    5e85:	74 27                	je     5eae <fwp_tape_reserve+0xfe>
    5e87:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5e8c:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e90:	48 89 c7             	mov    %rax,%rdi
    5e93:	4c 89 fe             	mov    %r15,%rsi
    5e96:	48 c1 e2 04          	shl    $0x4,%rdx
    5e9a:	48 39 ca             	cmp    %rcx,%rdx
    5e9d:	48 0f 47 d1          	cmova  %rcx,%rdx
    5ea1:	e8 fa d6 ff ff       	call   35a0 <memcpy@plt>
    5ea6:	4c 89 ff             	mov    %r15,%rdi
    5ea9:	e8 a2 f6 ff ff       	call   5550 <fwp_mem_free>
    5eae:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5eb2:	48 89 da             	mov    %rbx,%rdx
    5eb5:	31 f6                	xor    %esi,%esi
    5eb7:	48 29 fa             	sub    %rdi,%rdx
    5eba:	48 c1 e7 04          	shl    $0x4,%rdi
    5ebe:	48 c1 e2 04          	shl    $0x4,%rdx
    5ec2:	4c 01 ef             	add    %r13,%rdi
    5ec5:	e8 f6 d5 ff ff       	call   34c0 <memset@plt>
    5eca:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5ece:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5ed2:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    5ed6:	4d 85 e4             	test   %r12,%r12
    5ed9:	75 55                	jne    5f30 <fwp_tape_reserve+0x180>
    5edb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5ee2:	00 
    5ee3:	4c 01 e8             	add    %r13,%rax
    5ee6:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5eea:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5eee:	48 83 c4 18          	add    $0x18,%rsp
    5ef2:	5b                   	pop    %rbx
    5ef3:	5d                   	pop    %rbp
    5ef4:	41 5c                	pop    %r12
    5ef6:	41 5d                	pop    %r13
    5ef8:	41 5e                	pop    %r14
    5efa:	41 5f                	pop    %r15
    5efc:	c3                   	ret
    5efd:	0f 1f 00             	nopl   (%rax)
    5f00:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5f05:	e9 06 ff ff ff       	jmp    5e10 <fwp_tape_reserve+0x60>
    5f0a:	4d 39 f5             	cmp    %r14,%r13
    5f0d:	4c 89 f1             	mov    %r14,%rcx
    5f10:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    5f17:	00 
    5f18:	49 0f 43 cd          	cmovae %r13,%rcx
    5f1c:	4c 29 e9             	sub    %r13,%rcx
    5f1f:	e8 3c d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f24:	4c 03 6d 30          	add    0x30(%rbp),%r13
    5f28:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f2c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    5f30:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    5f34:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5f3b:	00 
    5f3c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    5f43:	00 
    5f44:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5f48:	e8 c3 d6 ff ff       	call   3610 <memmove@plt>
    5f4d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f51:	eb 90                	jmp    5ee3 <fwp_tape_reserve+0x133>
    5f53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f58:	49 89 de             	mov    %rbx,%r14
    5f5b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5f5f:	49 c1 e6 04          	shl    $0x4,%r14
    5f63:	4c 89 f6             	mov    %r14,%rsi
    5f66:	e8 65 d6 ff ff       	call   35d0 <realloc@plt>
    5f6b:	48 85 c0             	test   %rax,%rax
    5f6e:	74 3a                	je     5faa <fwp_tape_reserve+0x1fa>
    5f70:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5f74:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5f78:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5f7c:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    5f80:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    5f84:	4d 85 e4             	test   %r12,%r12
    5f87:	75 81                	jne    5f0a <fwp_tape_reserve+0x15a>
    5f89:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    5f8d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f91:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5f98:	00 
    5f99:	e9 45 ff ff ff       	jmp    5ee3 <fwp_tape_reserve+0x133>
    5f9e:	48 8d 3d 44 91 00 00 	lea    0x9144(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    5fa5:	e8 f6 e1 ff ff       	call   41a0 <fwp_trap>
    5faa:	48 89 ef             	mov    %rbp,%rdi
    5fad:	e8 4e dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5fb2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5fb6:	e8 05 d4 ff ff       	call   33c0 <free@plt>
    5fbb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5fbf:	e8 fc d3 ff ff       	call   33c0 <free@plt>
    5fc4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    5fc8:	e8 f3 d3 ff ff       	call   33c0 <free@plt>
    5fcd:	31 c9                	xor    %ecx,%ecx
    5fcf:	31 c0                	xor    %eax,%eax
    5fd1:	31 d2                	xor    %edx,%edx
    5fd3:	89 55 04             	mov    %edx,0x4(%rbp)
    5fd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fda:	ba 13 00 00 00       	mov    $0x13,%edx
    5fdf:	be 01 00 00 00       	mov    $0x1,%esi
    5fe4:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    5fe8:	48 8d 3d 19 90 00 00 	lea    0x9019(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    5fef:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5ff3:	48 8b 0d 66 d0 00 00 	mov    0xd066(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5ffa:	48 89 45 40          	mov    %rax,0x40(%rbp)
    5ffe:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6002:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6006:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    600a:	e8 71 d6 ff ff       	call   3680 <fwrite@plt>
    600f:	31 ff                	xor    %edi,%edi
    6011:	e8 aa d5 ff ff       	call   35c0 <fflush@plt>
    6016:	bf 66 00 00 00       	mov    $0x66,%edi
    601b:	e8 80 d6 ff ff       	call   36a0 <_Exit@plt>

0000000000006020 <f128.constprop.0>:
    6020:	41 57                	push   %r15
    6022:	41 56                	push   %r14
    6024:	41 55                	push   %r13
    6026:	41 54                	push   %r12
    6028:	49 89 f4             	mov    %rsi,%r12
    602b:	55                   	push   %rbp
    602c:	48 89 fd             	mov    %rdi,%rbp
    602f:	53                   	push   %rbx
    6030:	48 83 ec 08          	sub    $0x8,%rsp
    6034:	48 85 ff             	test   %rdi,%rdi
    6037:	79 09                	jns    6042 <f128.constprop.0+0x22>
    6039:	48 85 f6             	test   %rsi,%rsi
    603c:	0f 88 fe 00 00 00    	js     6140 <f128.constprop.0+0x120>
    6042:	48 89 f8             	mov    %rdi,%rax
    6045:	48 09 f0             	or     %rsi,%rax
    6048:	0f 89 d2 00 00 00    	jns    6120 <f128.constprop.0+0x100>
    604e:	48 89 f8             	mov    %rdi,%rax
    6051:	48 c1 f8 20          	sar    $0x20,%rax
    6055:	48 85 ff             	test   %rdi,%rdi
    6058:	0f 88 02 01 00 00    	js     6160 <f128.constprop.0+0x140>
    605e:	4c 8b 3d cb 9a 00 00 	mov    0x9acb(%rip),%r15        # fb30 <msg.4+0xb0>
    6065:	48 89 c7             	mov    %rax,%rdi
    6068:	e8 13 e4 ff ff       	call   4480 <fwp_tape_of>
    606d:	48 89 c3             	mov    %rax,%rbx
    6070:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6075:	0f 85 16 01 00 00    	jne    6191 <f128.constprop.0+0x171>
    607b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    607f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6086:	0f 8f f9 00 00 00    	jg     6185 <f128.constprop.0+0x165>
    608c:	89 e8                	mov    %ebp,%eax
    608e:	49 39 c5             	cmp    %rax,%r13
    6091:	0f 8e e2 00 00 00    	jle    6179 <f128.constprop.0+0x159>
    6097:	4d 85 e4             	test   %r12,%r12
    609a:	78 0c                	js     60a8 <f128.constprop.0+0x88>
    609c:	44 89 e0             	mov    %r12d,%eax
    609f:	49 39 c5             	cmp    %rax,%r13
    60a2:	0f 8e d1 00 00 00    	jle    6179 <f128.constprop.0+0x159>
    60a8:	4d 89 ee             	mov    %r13,%r14
    60ab:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60af:	48 89 df             	mov    %rbx,%rdi
    60b2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    60b6:	e8 f5 fc ff ff       	call   5db0 <fwp_tape_reserve>
    60bb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60bf:	4d 85 e4             	test   %r12,%r12
    60c2:	48 8b 0d 67 9a 00 00 	mov    0x9a67(%rip),%rcx        # fb30 <msg.4+0xb0>
    60c9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60d0:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    60d4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60d8:	4c 0f 48 e2          	cmovs  %rdx,%r12
    60dc:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    60e0:	48 8b 43 28          	mov    0x28(%rbx),%rax
    60e4:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    60e8:	48 8b 43 38          	mov    0x38(%rbx),%rax
    60ec:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    60f0:	49 8d 45 01          	lea    0x1(%r13),%rax
    60f4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    60f8:	48 83 c4 08          	add    $0x8,%rsp
    60fc:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6103:	ff ff ff 
    6106:	48 21 e8             	and    %rbp,%rax
    6109:	5b                   	pop    %rbx
    610a:	5d                   	pop    %rbp
    610b:	4c 09 e8             	or     %r13,%rax
    610e:	41 5c                	pop    %r12
    6110:	41 5d                	pop    %r13
    6112:	41 5e                	pop    %r14
    6114:	41 5f                	pop    %r15
    6116:	c3                   	ret
    6117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    611e:	00 00 
    6120:	48 89 f0             	mov    %rsi,%rax
    6123:	48 c1 ff 20          	sar    $0x20,%rdi
    6127:	48 c1 f8 20          	sar    $0x20,%rax
    612b:	48 39 c7             	cmp    %rax,%rdi
    612e:	0f 84 2a ff ff ff    	je     605e <f128.constprop.0+0x3e>
    6134:	48 8d 3d 85 96 00 00 	lea    0x9685(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    613b:	e8 60 e0 ff ff       	call   41a0 <fwp_trap>
    6140:	48 83 c4 08          	add    $0x8,%rsp
    6144:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    614b:	5b                   	pop    %rbx
    614c:	5d                   	pop    %rbp
    614d:	41 5c                	pop    %r12
    614f:	41 5d                	pop    %r13
    6151:	41 5e                	pop    %r14
    6153:	41 5f                	pop    %r15
    6155:	c3                   	ret
    6156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    615d:	00 00 00 
    6160:	48 89 f0             	mov    %rsi,%rax
    6163:	48 89 f5             	mov    %rsi,%rbp
    6166:	45 31 ff             	xor    %r15d,%r15d
    6169:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6170:	48 c1 f8 20          	sar    $0x20,%rax
    6174:	e9 ec fe ff ff       	jmp    6065 <f128.constprop.0+0x45>
    6179:	48 8d 3d 84 8f 00 00 	lea    0x8f84(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6180:	e8 1b e0 ff ff       	call   41a0 <fwp_trap>
    6185:	48 8d 3d 5d 8f 00 00 	lea    0x8f5d(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    618c:	e8 0f e0 ff ff       	call   41a0 <fwp_trap>
    6191:	48 8d 3d 70 96 00 00 	lea    0x9670(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    6198:	e8 03 e0 ff ff       	call   41a0 <fwp_trap>
    619d:	0f 1f 00             	nopl   (%rax)

00000000000061a0 <w107>:
    61a0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    61a4:	41 57                	push   %r15
    61a6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    61aa:	41 56                	push   %r14
    61ac:	41 55                	push   %r13
    61ae:	41 54                	push   %r12
    61b0:	49 89 f4             	mov    %rsi,%r12
    61b3:	55                   	push   %rbp
    61b4:	48 89 fd             	mov    %rdi,%rbp
    61b7:	53                   	push   %rbx
    61b8:	48 83 ec 38          	sub    $0x38,%rsp
    61bc:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    61c1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    61c7:	48 85 ff             	test   %rdi,%rdi
    61ca:	0f 88 d0 04 00 00    	js     66a0 <w107+0x500>
    61d0:	49 89 ff             	mov    %rdi,%r15
    61d3:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    61d9:	49 c1 ff 20          	sar    $0x20,%r15
    61dd:	4c 89 ff             	mov    %r15,%rdi
    61e0:	e8 9b e2 ff ff       	call   4480 <fwp_tape_of>
    61e5:	48 89 c3             	mov    %rax,%rbx
    61e8:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61ed:	0f 85 45 05 00 00    	jne    6738 <w107+0x598>
    61f3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    61f7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    61fe:	0f 8f 28 05 00 00    	jg     672c <w107+0x58c>
    6204:	89 e8                	mov    %ebp,%eax
    6206:	49 39 c5             	cmp    %rax,%r13
    6209:	0f 8e 11 05 00 00    	jle    6720 <w107+0x580>
    620f:	4d 89 ee             	mov    %r13,%r14
    6212:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6216:	48 89 df             	mov    %rbx,%rdi
    6219:	49 8d 76 01          	lea    0x1(%r14),%rsi
    621d:	e8 8e fb ff ff       	call   5db0 <fwp_tape_reserve>
    6222:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6226:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    622b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6231:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6235:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6239:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    623f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6243:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6247:	48 8b 43 38          	mov    0x38(%rbx),%rax
    624b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6251:	49 8d 45 01          	lea    0x1(%r13),%rax
    6255:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    625c:	ff ff ff 
    625f:	49 21 ee             	and    %rbp,%r14
    6262:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6266:	4d 09 ee             	or     %r13,%r14
    6269:	4d 89 f5             	mov    %r14,%r13
    626c:	49 c1 fd 20          	sar    $0x20,%r13
    6270:	4d 85 e4             	test   %r12,%r12
    6273:	78 10                	js     6285 <w107+0xe5>
    6275:	4c 89 e0             	mov    %r12,%rax
    6278:	48 c1 f8 20          	sar    $0x20,%rax
    627c:	4c 39 e8             	cmp    %r13,%rax
    627f:	0f 85 87 04 00 00    	jne    670c <w107+0x56c>
    6285:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    628b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6291:	4d 39 ef             	cmp    %r13,%r15
    6294:	0f 84 d6 03 00 00    	je     6670 <w107+0x4d0>
    629a:	f2 0f 10 1d 8e 98 00 	movsd  0x988e(%rip),%xmm3        # fb30 <msg.4+0xb0>
    62a1:	00 
    62a2:	f2 0f 10 25 8e 98 00 	movsd  0x988e(%rip),%xmm4        # fb38 <msg.4+0xb8>
    62a9:	00 
    62aa:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    62b0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    62b6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    62bc:	4c 89 ef             	mov    %r13,%rdi
    62bf:	e8 bc e1 ff ff       	call   4480 <fwp_tape_of>
    62c4:	48 89 c3             	mov    %rax,%rbx
    62c7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62cc:	0f 85 66 04 00 00    	jne    6738 <w107+0x598>
    62d2:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    62d6:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    62dd:	0f 8f 49 04 00 00    	jg     672c <w107+0x58c>
    62e3:	44 89 f0             	mov    %r14d,%eax
    62e6:	49 39 c7             	cmp    %rax,%r15
    62e9:	0f 8e 31 04 00 00    	jle    6720 <w107+0x580>
    62ef:	4d 85 e4             	test   %r12,%r12
    62f2:	78 0c                	js     6300 <w107+0x160>
    62f4:	44 89 e0             	mov    %r12d,%eax
    62f7:	49 39 c7             	cmp    %rax,%r15
    62fa:	0f 8e 20 04 00 00    	jle    6720 <w107+0x580>
    6300:	4c 89 f9             	mov    %r15,%rcx
    6303:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6307:	48 89 df             	mov    %rbx,%rdi
    630a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    630e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6313:	e8 98 fa ff ff       	call   5db0 <fwp_tape_reserve>
    6318:	48 8b 43 20          	mov    0x20(%rbx),%rax
    631c:	4d 85 e4             	test   %r12,%r12
    631f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6323:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6328:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    632e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6334:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6338:	48 8b 43 30          	mov    0x30(%rbx),%rax
    633c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6341:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6348:	49 0f 49 c4          	cmovns %r12,%rax
    634c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6350:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6353:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6357:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    635c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6360:	48 85 ed             	test   %rbp,%rbp
    6363:	0f 88 0e 04 00 00    	js     6777 <w107+0x5d7>
    6369:	48 89 e8             	mov    %rbp,%rax
    636c:	48 c1 f8 20          	sar    $0x20,%rax
    6370:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6375:	49 39 c5             	cmp    %rax,%r13
    6378:	74 1a                	je     6394 <w107+0x1f4>
    637a:	48 89 c7             	mov    %rax,%rdi
    637d:	e8 fe e0 ff ff       	call   4480 <fwp_tape_of>
    6382:	48 89 c3             	mov    %rax,%rbx
    6385:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    638a:	0f 85 a8 03 00 00    	jne    6738 <w107+0x598>
    6390:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6394:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    639b:	0f 8f 8b 03 00 00    	jg     672c <w107+0x58c>
    63a1:	89 e8                	mov    %ebp,%eax
    63a3:	4c 39 e0             	cmp    %r12,%rax
    63a6:	0f 8d 74 03 00 00    	jge    6720 <w107+0x580>
    63ac:	4c 89 e0             	mov    %r12,%rax
    63af:	48 2b 43 08          	sub    0x8(%rbx),%rax
    63b3:	48 89 df             	mov    %rbx,%rdi
    63b6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    63ba:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    63bf:	e8 ec f9 ff ff       	call   5db0 <fwp_tape_reserve>
    63c4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    63c9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    63cd:	48 8b 0d 64 97 00 00 	mov    0x9764(%rip),%rcx        # fb38 <msg.4+0xb8>
    63d4:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    63da:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    63dd:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    63e1:	66 0f 28 ee          	movapd %xmm6,%xmm5
    63e5:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    63eb:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    63ef:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    63f3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    63f7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    63fe:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6402:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6407:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    640c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6410:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6417:	ff ff ff 
    641a:	48 21 c5             	and    %rax,%rbp
    641d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6423:	4c 09 e5             	or     %r12,%rbp
    6426:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    642d:	ff ff ff 
    6430:	49 21 c6             	and    %rax,%r14
    6433:	4d 09 fe             	or     %r15,%r14
    6436:	4d 89 f4             	mov    %r14,%r12
    6439:	49 c1 fc 20          	sar    $0x20,%r12
    643d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6442:	74 16                	je     645a <w107+0x2ba>
    6444:	4c 89 e7             	mov    %r12,%rdi
    6447:	e8 34 e0 ff ff       	call   4480 <fwp_tape_of>
    644c:	48 89 c3             	mov    %rax,%rbx
    644f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6454:	0f 85 de 02 00 00    	jne    6738 <w107+0x598>
    645a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    645e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6465:	0f 8f c1 02 00 00    	jg     672c <w107+0x58c>
    646b:	44 89 f0             	mov    %r14d,%eax
    646e:	49 39 c7             	cmp    %rax,%r15
    6471:	0f 8e a9 02 00 00    	jle    6720 <w107+0x580>
    6477:	4d 89 fd             	mov    %r15,%r13
    647a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    647e:	48 89 df             	mov    %rbx,%rdi
    6481:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6485:	e8 26 f9 ff ff       	call   5db0 <fwp_tape_reserve>
    648a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    648e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6494:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6498:	48 8b 43 30          	mov    0x30(%rbx),%rax
    649c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    64a2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    64a6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    64aa:	48 8b 43 38          	mov    0x38(%rbx),%rax
    64ae:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    64b4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    64b8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    64bf:	ff ff ff 
    64c2:	49 21 c6             	and    %rax,%r14
    64c5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    64c9:	4d 09 fe             	or     %r15,%r14
    64cc:	4d 89 f7             	mov    %r14,%r15
    64cf:	49 c1 ff 20          	sar    $0x20,%r15
    64d3:	4d 39 e7             	cmp    %r12,%r15
    64d6:	74 1d                	je     64f5 <w107+0x355>
    64d8:	4c 89 ff             	mov    %r15,%rdi
    64db:	e8 a0 df ff ff       	call   4480 <fwp_tape_of>
    64e0:	48 89 c3             	mov    %rax,%rbx
    64e3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64e8:	0f 85 4a 02 00 00    	jne    6738 <w107+0x598>
    64ee:	4c 8b 68 10          	mov    0x10(%rax),%r13
    64f2:	4d 89 fc             	mov    %r15,%r12
    64f5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    64fc:	0f 8f 2a 02 00 00    	jg     672c <w107+0x58c>
    6502:	44 89 f0             	mov    %r14d,%eax
    6505:	4c 39 e8             	cmp    %r13,%rax
    6508:	0f 8d 12 02 00 00    	jge    6720 <w107+0x580>
    650e:	f2 0f 10 3d 2a 96 00 	movsd  0x962a(%rip),%xmm7        # fb40 <msg.4+0xc0>
    6515:	00 
    6516:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    651c:	4d 89 ef             	mov    %r13,%r15
    651f:	48 89 df             	mov    %rbx,%rdi
    6522:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6528:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    652d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6531:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6535:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    653a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6540:	e8 6b f8 ff ff       	call   5db0 <fwp_tape_reserve>
    6545:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6549:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    654e:	48 8b 15 eb 95 00 00 	mov    0x95eb(%rip),%rdx        # fb40 <msg.4+0xc0>
    6555:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6559:	48 8b 43 30          	mov    0x30(%rbx),%rax
    655d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6561:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6565:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6569:	48 8b 43 28          	mov    0x28(%rbx),%rax
    656d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6574:	ff 
    6575:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6579:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6580:	00 
    6581:	49 8d 45 01          	lea    0x1(%r13),%rax
    6585:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6589:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6590:	ff ff ff 
    6593:	49 21 c6             	and    %rax,%r14
    6596:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    659c:	4d 09 ee             	or     %r13,%r14
    659f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    65a3:	0f 84 57 01 00 00    	je     6700 <w107+0x560>
    65a9:	48 89 ef             	mov    %rbp,%rdi
    65ac:	48 c1 ff 20          	sar    $0x20,%rdi
    65b0:	4c 39 e7             	cmp    %r12,%rdi
    65b3:	74 13                	je     65c8 <w107+0x428>
    65b5:	e8 c6 de ff ff       	call   4480 <fwp_tape_of>
    65ba:	48 89 c3             	mov    %rax,%rbx
    65bd:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65c2:	0f 85 70 01 00 00    	jne    6738 <w107+0x598>
    65c8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    65cc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    65d3:	0f 8f 53 01 00 00    	jg     672c <w107+0x58c>
    65d9:	89 e8                	mov    %ebp,%eax
    65db:	4c 39 e0             	cmp    %r12,%rax
    65de:	0f 8d 3c 01 00 00    	jge    6720 <w107+0x580>
    65e4:	4d 89 e5             	mov    %r12,%r13
    65e7:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    65eb:	48 89 df             	mov    %rbx,%rdi
    65ee:	49 8d 75 01          	lea    0x1(%r13),%rsi
    65f2:	e8 b9 f7 ff ff       	call   5db0 <fwp_tape_reserve>
    65f7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65fb:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6600:	48 89 ef             	mov    %rbp,%rdi
    6603:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6611:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6615:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6619:	48 8b 43 38          	mov    0x38(%rbx),%rax
    661d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6623:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6628:	48 89 43 10          	mov    %rax,0x10(%rbx)
    662c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6633:	ff ff ff 
    6636:	48 21 c7             	and    %rax,%rdi
    6639:	4c 09 e7             	or     %r12,%rdi
    663c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6642:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6648:	4c 89 f6             	mov    %r14,%rsi
    664b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6650:	e8 cb f9 ff ff       	call   6020 <f128.constprop.0>
    6655:	48 83 c4 38          	add    $0x38,%rsp
    6659:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    665e:	5b                   	pop    %rbx
    665f:	5d                   	pop    %rbp
    6660:	41 5c                	pop    %r12
    6662:	41 5d                	pop    %r13
    6664:	41 5e                	pop    %r14
    6666:	41 5f                	pop    %r15
    6668:	c3                   	ret
    6669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6670:	f2 0f 10 3d b8 94 00 	movsd  0x94b8(%rip),%xmm7        # fb30 <msg.4+0xb0>
    6677:	00 
    6678:	f2 0f 10 15 b8 94 00 	movsd  0x94b8(%rip),%xmm2        # fb38 <msg.4+0xb8>
    667f:	00 
    6680:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6686:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    668c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6692:	e9 3b fc ff ff       	jmp    62d2 <w107+0x132>
    6697:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    669e:	00 00 
    66a0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66a6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66ac:	48 85 f6             	test   %rsi,%rsi
    66af:	0f 89 8f 00 00 00    	jns    6744 <w107+0x5a4>
    66b5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    66bb:	f2 0f 10 05 6d 94 00 	movsd  0x946d(%rip),%xmm0        # fb30 <msg.4+0xb0>
    66c2:	00 
    66c3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    66ca:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66d1:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    66d6:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    66da:	f2 0f 59 0d 5e 94 00 	mulsd  0x945e(%rip),%xmm1        # fb40 <msg.4+0xc0>
    66e1:	00 
    66e2:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    66e6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66ec:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66f2:	e9 45 ff ff ff       	jmp    663c <w107+0x49c>
    66f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    66fe:	00 00 
    6700:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6707:	e9 30 ff ff ff       	jmp    663c <w107+0x49c>
    670c:	48 8d 3d ad 90 00 00 	lea    0x90ad(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    6713:	e8 88 da ff ff       	call   41a0 <fwp_trap>
    6718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    671f:	00 
    6720:	48 8d 3d dd 89 00 00 	lea    0x89dd(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6727:	e8 74 da ff ff       	call   41a0 <fwp_trap>
    672c:	48 8d 3d b6 89 00 00 	lea    0x89b6(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    6733:	e8 68 da ff ff       	call   41a0 <fwp_trap>
    6738:	48 8d 3d c9 90 00 00 	lea    0x90c9(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    673f:	e8 5c da ff ff       	call   41a0 <fwp_trap>
    6744:	f2 0f 10 35 e4 93 00 	movsd  0x93e4(%rip),%xmm6        # fb30 <msg.4+0xb0>
    674b:	00 
    674c:	49 89 f5             	mov    %rsi,%r13
    674f:	49 89 f6             	mov    %rsi,%r14
    6752:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6759:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6760:	00 00 
    6762:	49 c1 fd 20          	sar    $0x20,%r13
    6766:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    676c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6772:	e9 45 fb ff ff       	jmp    62bc <w107+0x11c>
    6777:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    677d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6782:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6789:	66 0f 28 f4          	movapd %xmm4,%xmm6
    678d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6791:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6797:	e9 8a fc ff ff       	jmp    6426 <w107+0x286>
    679c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000067a0 <fwp_data.part.0.constprop.0>:
    67a0:	41 56                	push   %r14
    67a2:	41 89 fe             	mov    %edi,%r14d
    67a5:	41 54                	push   %r12
    67a7:	49 89 f4             	mov    %rsi,%r12
    67aa:	55                   	push   %rbp
    67ab:	53                   	push   %rbx
    67ac:	48 83 ec 08          	sub    $0x8,%rsp
    67b0:	8b 05 6e e3 01 00    	mov    0x1e36e(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    67b6:	85 c0                	test   %eax,%eax
    67b8:	0f 84 fa 00 00 00    	je     68b8 <fwp_data.part.0.constprop.0+0x118>
    67be:	0f b6 05 5d df 01 00 	movzbl 0x1df5d(%rip),%eax        # 24722 <fwp_heap+0xfa2>
    67c5:	48 8d 15 b4 cf 01 00 	lea    0x1cfb4(%rip),%rdx        # 23780 <fwp_heap>
    67cc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    67d3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    67d7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    67db:	48 8b 18             	mov    (%rax),%rbx
    67de:	48 85 db             	test   %rbx,%rbx
    67e1:	0f 84 a9 00 00 00    	je     6890 <fwp_data.part.0.constprop.0+0xf0>
    67e7:	48 8b 13             	mov    (%rbx),%rdx
    67ea:	48 f7 d2             	not    %rdx
    67ed:	48 89 10             	mov    %rdx,(%rax)
    67f0:	48 83 fd 18          	cmp    $0x18,%rbp
    67f4:	76 1b                	jbe    6811 <fwp_data.part.0.constprop.0+0x71>
    67f6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    67fa:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    67fe:	31 f6                	xor    %esi,%esi
    6800:	48 c1 e8 03          	shr    $0x3,%rax
    6804:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    680b:	00 
    680c:	e8 af cc ff ff       	call   34c0 <memset@plt>
    6811:	48 89 e8             	mov    %rbp,%rax
    6814:	48 03 05 85 e3 01 00 	add    0x1e385(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    681b:	0f 82 a8 00 00 00    	jb     68c9 <fwp_data.part.0.constprop.0+0x129>
    6821:	48 39 05 80 e3 01 00 	cmp    %rax,0x1e380(%rip)        # 24ba8 <fwp_heap+0x1428>
    6828:	48 89 05 71 e3 01 00 	mov    %rax,0x1e371(%rip)        # 24ba0 <fwp_heap+0x1420>
    682f:	73 07                	jae    6838 <fwp_data.part.0.constprop.0+0x98>
    6831:	48 89 05 70 e3 01 00 	mov    %rax,0x1e370(%rip)        # 24ba8 <fwp_heap+0x1428>
    6838:	66 0f ef c0          	pxor   %xmm0,%xmm0
    683c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6841:	f2 0f 58 05 6f e3 01 	addsd  0x1e36f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    6848:	00 
    6849:	f2 0f 11 05 67 e3 01 	movsd  %xmm0,0x1e367(%rip)        # 24bb8 <fwp_heap+0x1438>
    6850:	00 
    6851:	b8 02 00 00 00       	mov    $0x2,%eax
    6856:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    685b:	66 0f 6e c8          	movd   %eax,%xmm1
    685f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6863:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6867:	49 8b 04 24          	mov    (%r12),%rax
    686b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    686f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6874:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6878:	48 83 c4 08          	add    $0x8,%rsp
    687c:	48 89 d8             	mov    %rbx,%rax
    687f:	5b                   	pop    %rbx
    6880:	5d                   	pop    %rbp
    6881:	41 5c                	pop    %r12
    6883:	41 5e                	pop    %r14
    6885:	c3                   	ret
    6886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    688d:	00 00 00 
    6890:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6894:	48 85 db             	test   %rbx,%rbx
    6897:	74 1f                	je     68b8 <fwp_data.part.0.constprop.0+0x118>
    6899:	48 8b 50 10          	mov    0x10(%rax),%rdx
    689d:	48 29 da             	sub    %rbx,%rdx
    68a0:	48 39 ea             	cmp    %rbp,%rdx
    68a3:	72 13                	jb     68b8 <fwp_data.part.0.constprop.0+0x118>
    68a5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    68a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    68ad:	e9 3e ff ff ff       	jmp    67f0 <fwp_data.part.0.constprop.0+0x50>
    68b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68b8:	31 f6                	xor    %esi,%esi
    68ba:	bf 18 00 00 00       	mov    $0x18,%edi
    68bf:	e8 8c f1 ff ff       	call   5a50 <fwp_heap_alloc>
    68c4:	48 89 c3             	mov    %rax,%rbx
    68c7:	eb 88                	jmp    6851 <fwp_data.part.0.constprop.0+0xb1>
    68c9:	e8 e2 d3 ff ff       	call   3cb0 <fwp_heap_oom>
    68ce:	66 90                	xchg   %ax,%ax

00000000000068d0 <fwp_rc_share>:
    68d0:	48 8b 05 81 e2 01 00 	mov    0x1e281(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    68d7:	48 2b 3d 52 e2 01 00 	sub    0x1e252(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    68de:	48 c1 e0 10          	shl    $0x10,%rax
    68e2:	48 39 c7             	cmp    %rax,%rdi
    68e5:	73 4a                	jae    6931 <fwp_rc_share+0x61>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 c1 e8 10          	shr    $0x10,%rax
    68ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f2:	48 8b 05 7f e2 01 00 	mov    0x1e27f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    68f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    68fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6901:	48 85 d2             	test   %rdx,%rdx
    6904:	74 2b                	je     6931 <fwp_rc_share+0x61>
    6906:	0f b6 08             	movzbl (%rax),%ecx
    6909:	80 f9 02             	cmp    $0x2,%cl
    690c:	74 2a                	je     6938 <fwp_rc_share+0x68>
    690e:	80 f9 01             	cmp    $0x1,%cl
    6911:	75 1e                	jne    6931 <fwp_rc_share+0x61>
    6913:	8b 48 18             	mov    0x18(%rax),%ecx
    6916:	0f b7 ff             	movzwl %di,%edi
    6919:	8b 40 1c             	mov    0x1c(%rax),%eax
    691c:	48 0f af f9          	imul   %rcx,%rdi
    6920:	48 c1 ef 20          	shr    $0x20,%rdi
    6924:	48 39 c7             	cmp    %rax,%rdi
    6927:	73 08                	jae    6931 <fwp_rc_share+0x61>
    6929:	48 01 fa             	add    %rdi,%rdx
    692c:	80 3a 00             	cmpb   $0x0,(%rdx)
    692f:	75 0d                	jne    693e <fwp_rc_share+0x6e>
    6931:	c3                   	ret
    6932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6938:	66 85 ff             	test   %di,%di
    693b:	74 ef                	je     692c <fwp_rc_share+0x5c>
    693d:	c3                   	ret
    693e:	50                   	push   %rax
    693f:	48 8d 3d f2 8e 00 00 	lea    0x8ef2(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    6946:	e8 55 d8 ff ff       	call   41a0 <fwp_trap>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006950 <fwp_rc_fresh>:
    6950:	48 8b 15 01 e2 01 00 	mov    0x1e201(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 89 fe             	mov    %rdi,%rsi
    695d:	48 2b 05 cc e1 01 00 	sub    0x1e1cc(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6964:	48 c1 e2 10          	shl    $0x10,%rdx
    6968:	48 39 d0             	cmp    %rdx,%rax
    696b:	73 4f                	jae    69bc <fwp_rc_fresh+0x6c>
    696d:	48 89 c2             	mov    %rax,%rdx
    6970:	48 c1 ea 10          	shr    $0x10,%rdx
    6974:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6978:	48 8b 15 f9 e1 01 00 	mov    0x1e1f9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    697f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6983:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6987:	48 85 d2             	test   %rdx,%rdx
    698a:	74 30                	je     69bc <fwp_rc_fresh+0x6c>
    698c:	0f b6 39             	movzbl (%rcx),%edi
    698f:	40 80 ff 02          	cmp    $0x2,%dil
    6993:	74 2b                	je     69c0 <fwp_rc_fresh+0x70>
    6995:	40 80 ff 01          	cmp    $0x1,%dil
    6999:	75 21                	jne    69bc <fwp_rc_fresh+0x6c>
    699b:	8b 79 18             	mov    0x18(%rcx),%edi
    699e:	0f b7 c0             	movzwl %ax,%eax
    69a1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69a4:	48 0f af c7          	imul   %rdi,%rax
    69a8:	48 c1 e8 20          	shr    $0x20,%rax
    69ac:	48 39 c8             	cmp    %rcx,%rax
    69af:	73 0b                	jae    69bc <fwp_rc_fresh+0x6c>
    69b1:	48 01 c2             	add    %rax,%rdx
    69b4:	80 3a ff             	cmpb   $0xff,(%rdx)
    69b7:	74 17                	je     69d0 <fwp_rc_fresh+0x80>
    69b9:	c6 02 01             	movb   $0x1,(%rdx)
    69bc:	48 89 f0             	mov    %rsi,%rax
    69bf:	c3                   	ret
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 ef                	je     69b4 <fwp_rc_fresh+0x64>
    69c5:	48 89 f0             	mov    %rsi,%rax
    69c8:	c3                   	ret
    69c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69d0:	48 83 ec 18          	sub    $0x18,%rsp
    69d4:	48 89 d7             	mov    %rdx,%rdi
    69d7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    69dc:	48 89 14 24          	mov    %rdx,(%rsp)
    69e0:	e8 2b e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    69e5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    69ea:	48 8b 14 24          	mov    (%rsp),%rdx
    69ee:	48 89 f0             	mov    %rsi,%rax
    69f1:	c6 02 01             	movb   $0x1,(%rdx)
    69f4:	48 83 c4 18          	add    $0x18,%rsp
    69f8:	c3                   	ret
    69f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006a00 <fwp_rc_free_arr>:
    6a00:	48 8b 15 51 e1 01 00 	mov    0x1e151(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6a07:	48 89 f8             	mov    %rdi,%rax
    6a0a:	48 2b 05 1f e1 01 00 	sub    0x1e11f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6a11:	48 c1 e2 10          	shl    $0x10,%rdx
    6a15:	48 39 d0             	cmp    %rdx,%rax
    6a18:	73 5b                	jae    6a75 <fwp_rc_free_arr+0x75>
    6a1a:	48 89 c2             	mov    %rax,%rdx
    6a1d:	48 c1 ea 10          	shr    $0x10,%rdx
    6a21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a25:	48 8b 15 4c e1 01 00 	mov    0x1e14c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6a2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6a30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6a34:	48 85 c9             	test   %rcx,%rcx
    6a37:	74 3c                	je     6a75 <fwp_rc_free_arr+0x75>
    6a39:	0f b6 32             	movzbl (%rdx),%esi
    6a3c:	40 80 fe 02          	cmp    $0x2,%sil
    6a40:	74 2e                	je     6a70 <fwp_rc_free_arr+0x70>
    6a42:	40 80 fe 01          	cmp    $0x1,%sil
    6a46:	75 2d                	jne    6a75 <fwp_rc_free_arr+0x75>
    6a48:	8b 72 18             	mov    0x18(%rdx),%esi
    6a4b:	0f b7 c0             	movzwl %ax,%eax
    6a4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a51:	48 0f af c6          	imul   %rsi,%rax
    6a55:	48 c1 e8 20          	shr    $0x20,%rax
    6a59:	48 39 d0             	cmp    %rdx,%rax
    6a5c:	73 17                	jae    6a75 <fwp_rc_free_arr+0x75>
    6a5e:	48 01 c1             	add    %rax,%rcx
    6a61:	80 39 01             	cmpb   $0x1,(%rcx)
    6a64:	75 0f                	jne    6a75 <fwp_rc_free_arr+0x75>
    6a66:	e9 e5 ea ff ff       	jmp    5550 <fwp_mem_free>
    6a6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a70:	66 85 c0             	test   %ax,%ax
    6a73:	74 ec                	je     6a61 <fwp_rc_free_arr+0x61>
    6a75:	c3                   	ret
    6a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a7d:	00 00 00 

0000000000006a80 <fwp_rc_dup>:
    6a80:	f3 0f 1e fa          	endbr64
    6a84:	48 8b 05 cd e0 01 00 	mov    0x1e0cd(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    6a8b:	48 2b 3d 9e e0 01 00 	sub    0x1e09e(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    6a92:	48 c1 e0 10          	shl    $0x10,%rax
    6a96:	48 39 c7             	cmp    %rax,%rdi
    6a99:	73 56                	jae    6af1 <fwp_rc_dup+0x71>
    6a9b:	48 89 f8             	mov    %rdi,%rax
    6a9e:	48 c1 e8 10          	shr    $0x10,%rax
    6aa2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6aa6:	48 8b 05 cb e0 01 00 	mov    0x1e0cb(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    6aad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6ab1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6ab5:	48 85 c0             	test   %rax,%rax
    6ab8:	74 37                	je     6af1 <fwp_rc_dup+0x71>
    6aba:	0f b6 0a             	movzbl (%rdx),%ecx
    6abd:	80 f9 02             	cmp    $0x2,%cl
    6ac0:	74 36                	je     6af8 <fwp_rc_dup+0x78>
    6ac2:	80 f9 01             	cmp    $0x1,%cl
    6ac5:	75 2a                	jne    6af1 <fwp_rc_dup+0x71>
    6ac7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6aca:	0f b7 ff             	movzwl %di,%edi
    6acd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ad0:	48 0f af f9          	imul   %rcx,%rdi
    6ad4:	48 c1 ef 20          	shr    $0x20,%rdi
    6ad8:	48 39 d7             	cmp    %rdx,%rdi
    6adb:	73 14                	jae    6af1 <fwp_rc_dup+0x71>
    6add:	48 01 f8             	add    %rdi,%rax
    6ae0:	0f b6 10             	movzbl (%rax),%edx
    6ae3:	84 d2                	test   %dl,%dl
    6ae5:	74 0a                	je     6af1 <fwp_rc_dup+0x71>
    6ae7:	80 fa fd             	cmp    $0xfd,%dl
    6aea:	77 14                	ja     6b00 <fwp_rc_dup+0x80>
    6aec:	83 c2 01             	add    $0x1,%edx
    6aef:	88 10                	mov    %dl,(%rax)
    6af1:	c3                   	ret
    6af2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af8:	66 85 ff             	test   %di,%di
    6afb:	74 e3                	je     6ae0 <fwp_rc_dup+0x60>
    6afd:	c3                   	ret
    6afe:	66 90                	xchg   %ax,%ax
    6b00:	48 89 c7             	mov    %rax,%rdi
    6b03:	e9 e8 e6 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b0f:	00 

0000000000006b10 <fwp_owned_entry161>:
    6b10:	f3 0f 1e fa          	endbr64
    6b14:	48 83 ec 38          	sub    $0x38,%rsp
    6b18:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b1d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b24:	00 00 
    6b26:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b2b:	31 c0                	xor    %eax,%eax
    6b2d:	48 8b 07             	mov    (%rdi),%rax
    6b30:	48 03 47 10          	add    0x10(%rdi),%rax
    6b34:	0f 80 c2 00 00 00    	jo     6bfc <fwp_owned_entry161+0xec>
    6b3a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b3f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b44:	31 ff                	xor    %edi,%edi
    6b46:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b4a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b4f:	e8 4c fc ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    6b54:	48 8b 15 fd df 01 00 	mov    0x1dffd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6b5b:	48 89 c6             	mov    %rax,%rsi
    6b5e:	48 2b 05 cb df 01 00 	sub    0x1dfcb(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6b65:	48 c1 e2 10          	shl    $0x10,%rdx
    6b69:	48 39 d0             	cmp    %rdx,%rax
    6b6c:	73 4f                	jae    6bbd <fwp_owned_entry161+0xad>
    6b6e:	48 89 c2             	mov    %rax,%rdx
    6b71:	48 c1 ea 10          	shr    $0x10,%rdx
    6b75:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b79:	48 8b 15 f8 df 01 00 	mov    0x1dff8(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6b80:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b84:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b88:	48 85 d2             	test   %rdx,%rdx
    6b8b:	74 30                	je     6bbd <fwp_owned_entry161+0xad>
    6b8d:	0f b6 39             	movzbl (%rcx),%edi
    6b90:	40 80 ff 02          	cmp    $0x2,%dil
    6b94:	74 42                	je     6bd8 <fwp_owned_entry161+0xc8>
    6b96:	40 80 ff 01          	cmp    $0x1,%dil
    6b9a:	75 21                	jne    6bbd <fwp_owned_entry161+0xad>
    6b9c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b9f:	0f b7 c0             	movzwl %ax,%eax
    6ba2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ba5:	48 0f af c7          	imul   %rdi,%rax
    6ba9:	48 c1 e8 20          	shr    $0x20,%rax
    6bad:	48 39 c8             	cmp    %rcx,%rax
    6bb0:	73 0b                	jae    6bbd <fwp_owned_entry161+0xad>
    6bb2:	48 01 c2             	add    %rax,%rdx
    6bb5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6bb8:	74 26                	je     6be0 <fwp_owned_entry161+0xd0>
    6bba:	c6 02 01             	movb   $0x1,(%rdx)
    6bbd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6bc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bc9:	00 00 
    6bcb:	75 34                	jne    6c01 <fwp_owned_entry161+0xf1>
    6bcd:	48 89 f0             	mov    %rsi,%rax
    6bd0:	48 83 c4 38          	add    $0x38,%rsp
    6bd4:	c3                   	ret
    6bd5:	0f 1f 00             	nopl   (%rax)
    6bd8:	66 85 c0             	test   %ax,%ax
    6bdb:	75 e0                	jne    6bbd <fwp_owned_entry161+0xad>
    6bdd:	eb d6                	jmp    6bb5 <fwp_owned_entry161+0xa5>
    6bdf:	90                   	nop
    6be0:	48 89 d7             	mov    %rdx,%rdi
    6be3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6be8:	48 89 14 24          	mov    %rdx,(%rsp)
    6bec:	e8 1f e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bf1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6bf6:	48 8b 14 24          	mov    (%rsp),%rdx
    6bfa:	eb be                	jmp    6bba <fwp_owned_entry161+0xaa>
    6bfc:	e8 ff ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c01:	e8 5a c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c0d:	00 00 00 

0000000000006c10 <e161>:
    6c10:	f3 0f 1e fa          	endbr64
    6c14:	53                   	push   %rbx
    6c15:	48 83 ec 30          	sub    $0x30,%rsp
    6c19:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c1e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c25:	00 00 
    6c27:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6c2c:	31 c0                	xor    %eax,%eax
    6c2e:	48 8b 07             	mov    (%rdi),%rax
    6c31:	48 03 47 10          	add    0x10(%rdi),%rax
    6c35:	0f 80 c9 00 00 00    	jo     6d04 <e161+0xf4>
    6c3b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c40:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c45:	31 ff                	xor    %edi,%edi
    6c47:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c4b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c50:	e8 4b fb ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    6c55:	48 8b 15 fc de 01 00 	mov    0x1defc(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6c5c:	48 89 c3             	mov    %rax,%rbx
    6c5f:	48 2b 05 ca de 01 00 	sub    0x1deca(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6c66:	48 c1 e2 10          	shl    $0x10,%rdx
    6c6a:	48 39 d0             	cmp    %rdx,%rax
    6c6d:	73 4f                	jae    6cbe <e161+0xae>
    6c6f:	48 89 c2             	mov    %rax,%rdx
    6c72:	48 c1 ea 10          	shr    $0x10,%rdx
    6c76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c7a:	48 8b 15 f7 de 01 00 	mov    0x1def7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6c81:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c85:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c89:	48 85 d2             	test   %rdx,%rdx
    6c8c:	74 30                	je     6cbe <e161+0xae>
    6c8e:	0f b6 31             	movzbl (%rcx),%esi
    6c91:	40 80 fe 02          	cmp    $0x2,%sil
    6c95:	74 49                	je     6ce0 <e161+0xd0>
    6c97:	40 80 fe 01          	cmp    $0x1,%sil
    6c9b:	75 21                	jne    6cbe <e161+0xae>
    6c9d:	8b 71 18             	mov    0x18(%rcx),%esi
    6ca0:	0f b7 c0             	movzwl %ax,%eax
    6ca3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ca6:	48 0f af c6          	imul   %rsi,%rax
    6caa:	48 c1 e8 20          	shr    $0x20,%rax
    6cae:	48 39 c8             	cmp    %rcx,%rax
    6cb1:	73 0b                	jae    6cbe <e161+0xae>
    6cb3:	48 01 c2             	add    %rax,%rdx
    6cb6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6cb9:	74 35                	je     6cf0 <e161+0xe0>
    6cbb:	c6 02 01             	movb   $0x1,(%rdx)
    6cbe:	48 89 df             	mov    %rbx,%rdi
    6cc1:	e8 0a fc ff ff       	call   68d0 <fwp_rc_share>
    6cc6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6ccb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cd2:	00 00 
    6cd4:	75 33                	jne    6d09 <e161+0xf9>
    6cd6:	48 83 c4 30          	add    $0x30,%rsp
    6cda:	48 89 d8             	mov    %rbx,%rax
    6cdd:	5b                   	pop    %rbx
    6cde:	c3                   	ret
    6cdf:	90                   	nop
    6ce0:	66 85 c0             	test   %ax,%ax
    6ce3:	75 d9                	jne    6cbe <e161+0xae>
    6ce5:	eb cf                	jmp    6cb6 <e161+0xa6>
    6ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cee:	00 00 
    6cf0:	48 89 d7             	mov    %rdx,%rdi
    6cf3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cf8:	e8 13 e6 ff ff       	call   5310 <fwp_rc_forget_slot>
    6cfd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d02:	eb b7                	jmp    6cbb <e161+0xab>
    6d04:	e8 f7 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d09:	e8 52 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6d0e:	66 90                	xchg   %ax,%ax

0000000000006d10 <fwp_drop0>:
    6d10:	f3 0f 1e fa          	endbr64
    6d14:	48 8b 15 3d de 01 00 	mov    0x1de3d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6d1b:	48 89 f8             	mov    %rdi,%rax
    6d1e:	48 2b 05 0b de 01 00 	sub    0x1de0b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6d25:	48 c1 e2 10          	shl    $0x10,%rdx
    6d29:	48 39 d0             	cmp    %rdx,%rax
    6d2c:	0f 83 be 00 00 00    	jae    6df0 <fwp_drop0+0xe0>
    6d32:	48 83 ec 18          	sub    $0x18,%rsp
    6d36:	4c 8d 05 43 ca 01 00 	lea    0x1ca43(%rip),%r8        # 23780 <fwp_heap>
    6d3d:	48 89 c2             	mov    %rax,%rdx
    6d40:	48 c1 ea 10          	shr    $0x10,%rdx
    6d44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d48:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6d4f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d57:	48 85 d2             	test   %rdx,%rdx
    6d5a:	74 3c                	je     6d98 <fwp_drop0+0x88>
    6d5c:	0f b6 31             	movzbl (%rcx),%esi
    6d5f:	40 80 fe 02          	cmp    $0x2,%sil
    6d63:	74 3b                	je     6da0 <fwp_drop0+0x90>
    6d65:	40 80 fe 01          	cmp    $0x1,%sil
    6d69:	75 2d                	jne    6d98 <fwp_drop0+0x88>
    6d6b:	8b 71 18             	mov    0x18(%rcx),%esi
    6d6e:	0f b7 c0             	movzwl %ax,%eax
    6d71:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d74:	48 0f af c6          	imul   %rsi,%rax
    6d78:	48 c1 e8 20          	shr    $0x20,%rax
    6d7c:	48 39 c8             	cmp    %rcx,%rax
    6d7f:	73 17                	jae    6d98 <fwp_drop0+0x88>
    6d81:	48 01 c2             	add    %rax,%rdx
    6d84:	0f b6 02             	movzbl (%rdx),%eax
    6d87:	84 c0                	test   %al,%al
    6d89:	74 0d                	je     6d98 <fwp_drop0+0x88>
    6d8b:	3c 01                	cmp    $0x1,%al
    6d8d:	74 21                	je     6db0 <fwp_drop0+0xa0>
    6d8f:	3c ff                	cmp    $0xff,%al
    6d91:	74 65                	je     6df8 <fwp_drop0+0xe8>
    6d93:	83 e8 01             	sub    $0x1,%eax
    6d96:	88 02                	mov    %al,(%rdx)
    6d98:	48 83 c4 18          	add    $0x18,%rsp
    6d9c:	c3                   	ret
    6d9d:	0f 1f 00             	nopl   (%rax)
    6da0:	66 85 c0             	test   %ax,%ax
    6da3:	74 df                	je     6d84 <fwp_drop0+0x74>
    6da5:	48 83 c4 18          	add    $0x18,%rsp
    6da9:	c3                   	ret
    6daa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6db0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6db4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6db9:	e8 42 fc ff ff       	call   6a00 <fwp_rc_free_arr>
    6dbe:	4c 8d 05 bb c9 01 00 	lea    0x1c9bb(%rip),%r8        # 23780 <fwp_heap>
    6dc5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6dca:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6dd1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6dd8:	48 c1 e2 10          	shl    $0x10,%rdx
    6ddc:	48 39 d0             	cmp    %rdx,%rax
    6ddf:	73 b7                	jae    6d98 <fwp_drop0+0x88>
    6de1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6de6:	e9 52 ff ff ff       	jmp    6d3d <fwp_drop0+0x2d>
    6deb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6df0:	c3                   	ret
    6df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6df8:	48 89 d0             	mov    %rdx,%rax
    6dfb:	48 c1 e8 11          	shr    $0x11,%rax
    6dff:	48 31 d0             	xor    %rdx,%rax
    6e02:	48 89 c1             	mov    %rax,%rcx
    6e05:	48 c1 e9 09          	shr    $0x9,%rcx
    6e09:	48 31 c8             	xor    %rcx,%rax
    6e0c:	0f b6 c8             	movzbl %al,%ecx
    6e0f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6e16:	00 
    6e17:	48 85 c0             	test   %rax,%rax
    6e1a:	75 0d                	jne    6e29 <fwp_drop0+0x119>
    6e1c:	eb 46                	jmp    6e64 <fwp_drop0+0x154>
    6e1e:	66 90                	xchg   %ax,%ax
    6e20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e24:	48 85 c0             	test   %rax,%rax
    6e27:	74 3b                	je     6e64 <fwp_drop0+0x154>
    6e29:	48 89 c1             	mov    %rax,%rcx
    6e2c:	48 39 10             	cmp    %rdx,(%rax)
    6e2f:	75 ef                	jne    6e20 <fwp_drop0+0x110>
    6e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e44:	0f 85 4e ff ff ff    	jne    6d98 <fwp_drop0+0x88>
    6e4a:	48 89 d7             	mov    %rdx,%rdi
    6e4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e52:	e8 b9 e4 ff ff       	call   5310 <fwp_rc_forget_slot>
    6e57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e5f:	e9 34 ff ff ff       	jmp    6d98 <fwp_drop0+0x88>
    6e64:	48 8d 3d 2d 89 00 00 	lea    0x892d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6e6b:	e8 30 d3 ff ff       	call   41a0 <fwp_trap>

0000000000006e70 <fwp_arg_drop12>:
    6e70:	f3 0f 1e fa          	endbr64
    6e74:	85 f6                	test   %esi,%esi
    6e76:	75 04                	jne    6e7c <fwp_arg_drop12+0xc>
    6e78:	85 d2                	test   %edx,%edx
    6e7a:	75 04                	jne    6e80 <fwp_arg_drop12+0x10>
    6e7c:	c3                   	ret
    6e7d:	0f 1f 00             	nopl   (%rax)
    6e80:	48 8b 3f             	mov    (%rdi),%rdi
    6e83:	e9 88 fe ff ff       	jmp    6d10 <fwp_drop0>
    6e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e8f:	00 

0000000000006e90 <fwp_drop1>:
    6e90:	f3 0f 1e fa          	endbr64
    6e94:	48 8b 15 bd dc 01 00 	mov    0x1dcbd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6e9b:	48 89 f8             	mov    %rdi,%rax
    6e9e:	48 2b 05 8b dc 01 00 	sub    0x1dc8b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6ea5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ea9:	48 39 d0             	cmp    %rdx,%rax
    6eac:	0f 83 be 00 00 00    	jae    6f70 <fwp_drop1+0xe0>
    6eb2:	48 83 ec 18          	sub    $0x18,%rsp
    6eb6:	4c 8d 05 c3 c8 01 00 	lea    0x1c8c3(%rip),%r8        # 23780 <fwp_heap>
    6ebd:	48 89 c2             	mov    %rax,%rdx
    6ec0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ec4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ec8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6ecf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ed3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ed7:	48 85 d2             	test   %rdx,%rdx
    6eda:	74 3c                	je     6f18 <fwp_drop1+0x88>
    6edc:	0f b6 31             	movzbl (%rcx),%esi
    6edf:	40 80 fe 02          	cmp    $0x2,%sil
    6ee3:	74 3b                	je     6f20 <fwp_drop1+0x90>
    6ee5:	40 80 fe 01          	cmp    $0x1,%sil
    6ee9:	75 2d                	jne    6f18 <fwp_drop1+0x88>
    6eeb:	8b 71 18             	mov    0x18(%rcx),%esi
    6eee:	0f b7 c0             	movzwl %ax,%eax
    6ef1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ef4:	48 0f af c6          	imul   %rsi,%rax
    6ef8:	48 c1 e8 20          	shr    $0x20,%rax
    6efc:	48 39 c8             	cmp    %rcx,%rax
    6eff:	73 17                	jae    6f18 <fwp_drop1+0x88>
    6f01:	48 01 c2             	add    %rax,%rdx
    6f04:	0f b6 02             	movzbl (%rdx),%eax
    6f07:	84 c0                	test   %al,%al
    6f09:	74 0d                	je     6f18 <fwp_drop1+0x88>
    6f0b:	3c 01                	cmp    $0x1,%al
    6f0d:	74 21                	je     6f30 <fwp_drop1+0xa0>
    6f0f:	3c ff                	cmp    $0xff,%al
    6f11:	74 65                	je     6f78 <fwp_drop1+0xe8>
    6f13:	83 e8 01             	sub    $0x1,%eax
    6f16:	88 02                	mov    %al,(%rdx)
    6f18:	48 83 c4 18          	add    $0x18,%rsp
    6f1c:	c3                   	ret
    6f1d:	0f 1f 00             	nopl   (%rax)
    6f20:	66 85 c0             	test   %ax,%ax
    6f23:	74 df                	je     6f04 <fwp_drop1+0x74>
    6f25:	48 83 c4 18          	add    $0x18,%rsp
    6f29:	c3                   	ret
    6f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f30:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6f34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6f39:	e8 c2 fa ff ff       	call   6a00 <fwp_rc_free_arr>
    6f3e:	4c 8d 05 3b c8 01 00 	lea    0x1c83b(%rip),%r8        # 23780 <fwp_heap>
    6f45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6f4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6f51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6f58:	48 c1 e2 10          	shl    $0x10,%rdx
    6f5c:	48 39 d0             	cmp    %rdx,%rax
    6f5f:	73 b7                	jae    6f18 <fwp_drop1+0x88>
    6f61:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f66:	e9 52 ff ff ff       	jmp    6ebd <fwp_drop1+0x2d>
    6f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f70:	c3                   	ret
    6f71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f78:	48 89 d0             	mov    %rdx,%rax
    6f7b:	48 c1 e8 11          	shr    $0x11,%rax
    6f7f:	48 31 d0             	xor    %rdx,%rax
    6f82:	48 89 c1             	mov    %rax,%rcx
    6f85:	48 c1 e9 09          	shr    $0x9,%rcx
    6f89:	48 31 c8             	xor    %rcx,%rax
    6f8c:	0f b6 c8             	movzbl %al,%ecx
    6f8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6f96:	00 
    6f97:	48 85 c0             	test   %rax,%rax
    6f9a:	75 0d                	jne    6fa9 <fwp_drop1+0x119>
    6f9c:	eb 46                	jmp    6fe4 <fwp_drop1+0x154>
    6f9e:	66 90                	xchg   %ax,%ax
    6fa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6fa4:	48 85 c0             	test   %rax,%rax
    6fa7:	74 3b                	je     6fe4 <fwp_drop1+0x154>
    6fa9:	48 89 c1             	mov    %rax,%rcx
    6fac:	48 39 10             	cmp    %rdx,(%rax)
    6faf:	75 ef                	jne    6fa0 <fwp_drop1+0x110>
    6fb1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6fb5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6fb9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6fbd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6fc4:	0f 85 4e ff ff ff    	jne    6f18 <fwp_drop1+0x88>
    6fca:	48 89 d7             	mov    %rdx,%rdi
    6fcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6fd2:	e8 39 e3 ff ff       	call   5310 <fwp_rc_forget_slot>
    6fd7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6fdc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6fdf:	e9 34 ff ff ff       	jmp    6f18 <fwp_drop1+0x88>
    6fe4:	48 8d 3d ad 87 00 00 	lea    0x87ad(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6feb:	e8 b0 d1 ff ff       	call   41a0 <fwp_trap>

0000000000006ff0 <fwp_closure_drop>:
    6ff0:	48 8b 15 61 db 01 00 	mov    0x1db61(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6ff7:	48 89 f8             	mov    %rdi,%rax
    6ffa:	48 2b 05 2f db 01 00 	sub    0x1db2f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7001:	48 c1 e2 10          	shl    $0x10,%rdx
    7005:	48 39 d0             	cmp    %rdx,%rax
    7008:	73 6b                	jae    7075 <fwp_closure_drop+0x85>
    700a:	48 89 c2             	mov    %rax,%rdx
    700d:	48 c1 ea 10          	shr    $0x10,%rdx
    7011:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7015:	48 8b 15 5c db 01 00 	mov    0x1db5c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    701c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7020:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7024:	48 85 d2             	test   %rdx,%rdx
    7027:	74 4c                	je     7075 <fwp_closure_drop+0x85>
    7029:	0f b6 31             	movzbl (%rcx),%esi
    702c:	40 80 fe 02          	cmp    $0x2,%sil
    7030:	74 3e                	je     7070 <fwp_closure_drop+0x80>
    7032:	40 80 fe 01          	cmp    $0x1,%sil
    7036:	75 3d                	jne    7075 <fwp_closure_drop+0x85>
    7038:	8b 71 18             	mov    0x18(%rcx),%esi
    703b:	0f b7 c0             	movzwl %ax,%eax
    703e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7041:	48 0f af c6          	imul   %rsi,%rax
    7045:	48 c1 e8 20          	shr    $0x20,%rax
    7049:	48 39 c8             	cmp    %rcx,%rax
    704c:	73 27                	jae    7075 <fwp_closure_drop+0x85>
    704e:	48 01 c2             	add    %rax,%rdx
    7051:	0f b6 02             	movzbl (%rdx),%eax
    7054:	84 c0                	test   %al,%al
    7056:	74 1d                	je     7075 <fwp_closure_drop+0x85>
    7058:	3c 01                	cmp    $0x1,%al
    705a:	74 24                	je     7080 <fwp_closure_drop+0x90>
    705c:	3c ff                	cmp    $0xff,%al
    705e:	74 48                	je     70a8 <fwp_closure_drop+0xb8>
    7060:	83 e8 01             	sub    $0x1,%eax
    7063:	88 02                	mov    %al,(%rdx)
    7065:	c3                   	ret
    7066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    706d:	00 00 00 
    7070:	66 85 c0             	test   %ax,%ax
    7073:	74 dc                	je     7051 <fwp_closure_drop+0x61>
    7075:	c3                   	ret
    7076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    707d:	00 00 00 
    7080:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7087:	ff ff 
    7089:	48 85 c0             	test   %rax,%rax
    708c:	74 12                	je     70a0 <fwp_closure_drop+0xb0>
    708e:	48 89 fe             	mov    %rdi,%rsi
    7091:	48 89 c7             	mov    %rax,%rdi
    7094:	e9 67 d1 ff ff       	jmp    4200 <fwp_closure_drop_push>
    7099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70a0:	e9 0b d3 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    70a5:	0f 1f 00             	nopl   (%rax)
    70a8:	48 89 d0             	mov    %rdx,%rax
    70ab:	48 8d 35 ce c6 01 00 	lea    0x1c6ce(%rip),%rsi        # 23780 <fwp_heap>
    70b2:	48 83 ec 18          	sub    $0x18,%rsp
    70b6:	48 c1 e8 11          	shr    $0x11,%rax
    70ba:	48 31 d0             	xor    %rdx,%rax
    70bd:	48 89 c1             	mov    %rax,%rcx
    70c0:	48 c1 e9 09          	shr    $0x9,%rcx
    70c4:	48 31 c8             	xor    %rcx,%rax
    70c7:	0f b6 c8             	movzbl %al,%ecx
    70ca:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    70d1:	00 
    70d2:	48 85 c0             	test   %rax,%rax
    70d5:	75 12                	jne    70e9 <fwp_closure_drop+0xf9>
    70d7:	eb 49                	jmp    7122 <fwp_closure_drop+0x132>
    70d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    70e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    70e4:	48 85 c0             	test   %rax,%rax
    70e7:	74 39                	je     7122 <fwp_closure_drop+0x132>
    70e9:	48 89 c1             	mov    %rax,%rcx
    70ec:	48 39 10             	cmp    %rdx,(%rax)
    70ef:	75 ef                	jne    70e0 <fwp_closure_drop+0xf0>
    70f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    70f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    70f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    70fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7104:	74 05                	je     710b <fwp_closure_drop+0x11b>
    7106:	48 83 c4 18          	add    $0x18,%rsp
    710a:	c3                   	ret
    710b:	48 89 d7             	mov    %rdx,%rdi
    710e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7113:	e8 f8 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    7118:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    711d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7120:	eb e4                	jmp    7106 <fwp_closure_drop+0x116>
    7122:	48 8d 3d 6f 86 00 00 	lea    0x866f(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7129:	e8 72 d0 ff ff       	call   41a0 <fwp_trap>
    712e:	66 90                	xchg   %ax,%ax

0000000000007130 <fwp_owned_tape_release>:
    7130:	48 85 ff             	test   %rdi,%rdi
    7133:	0f 84 f7 00 00 00    	je     7230 <fwp_owned_tape_release+0x100>
    7139:	41 54                	push   %r12
    713b:	55                   	push   %rbp
    713c:	53                   	push   %rbx
    713d:	48 8b 07             	mov    (%rdi),%rax
    7140:	48 85 c0             	test   %rax,%rax
    7143:	74 08                	je     714d <fwp_owned_tape_release+0x1d>
    7145:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7149:	48 89 50 08          	mov    %rdx,0x8(%rax)
    714d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7151:	48 85 d2             	test   %rdx,%rdx
    7154:	74 03                	je     7159 <fwp_owned_tape_release+0x29>
    7156:	48 89 02             	mov    %rax,(%rdx)
    7159:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    715d:	48 89 fb             	mov    %rdi,%rbx
    7160:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7164:	48 85 c0             	test   %rax,%rax
    7167:	0f 84 89 00 00 00    	je     71f6 <fwp_owned_tape_release+0xc6>
    716d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7171:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7175:	7e 47                	jle    71be <fwp_owned_tape_release+0x8e>
    7177:	31 ed                	xor    %ebp,%ebp
    7179:	eb 0d                	jmp    7188 <fwp_owned_tape_release+0x58>
    717b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7180:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7184:	48 8b 40 68          	mov    0x68(%rax),%rax
    7188:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    718c:	49 89 ec             	mov    %rbp,%r12
    718f:	48 83 c5 01          	add    $0x1,%rbp
    7193:	49 c1 e4 04          	shl    $0x4,%r12
    7197:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    719b:	ff d0                	call   *%rax
    719d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    71a1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    71a6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    71aa:	ff 50 68             	call   *0x68(%rax)
    71ad:	48 8b 43 58          	mov    0x58(%rbx),%rax
    71b1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    71b5:	48 39 e8             	cmp    %rbp,%rax
    71b8:	7f c6                	jg     7180 <fwp_owned_tape_release+0x50>
    71ba:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    71be:	31 ed                	xor    %ebp,%ebp
    71c0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    71c5:	7e 28                	jle    71ef <fwp_owned_tape_release+0xbf>
    71c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    71ce:	00 00 
    71d0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    71d4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    71d8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    71dc:	74 07                	je     71e5 <fwp_owned_tape_release+0xb5>
    71de:	ff 52 68             	call   *0x68(%rdx)
    71e1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    71e5:	48 83 c5 01          	add    $0x1,%rbp
    71e9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    71ed:	7f e1                	jg     71d0 <fwp_owned_tape_release+0xa0>
    71ef:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    71f3:	ff 52 68             	call   *0x68(%rdx)
    71f6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    71fa:	e8 f1 fd ff ff       	call   6ff0 <fwp_closure_drop>
    71ff:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7203:	e8 e8 fd ff ff       	call   6ff0 <fwp_closure_drop>
    7208:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    720c:	e8 df fd ff ff       	call   6ff0 <fwp_closure_drop>
    7211:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7215:	e8 36 e3 ff ff       	call   5550 <fwp_mem_free>
    721a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    721e:	e8 2d e3 ff ff       	call   5550 <fwp_mem_free>
    7223:	48 89 df             	mov    %rbx,%rdi
    7226:	5b                   	pop    %rbx
    7227:	5d                   	pop    %rbp
    7228:	41 5c                	pop    %r12
    722a:	e9 21 e3 ff ff       	jmp    5550 <fwp_mem_free>
    722f:	90                   	nop
    7230:	c3                   	ret
    7231:	0f 1f 40 00          	nopl   0x0(%rax)
    7235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    723c:	00 00 00 00 

0000000000007240 <fwp_tape_finish>:
    7240:	f3 0f 1e fa          	endbr64
    7244:	41 56                	push   %r14
    7246:	48 8d 3d 73 be 01 00 	lea    0x1be73(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    724d:	41 55                	push   %r13
    724f:	41 54                	push   %r12
    7251:	55                   	push   %rbp
    7252:	53                   	push   %rbx
    7253:	e8 18 cd ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    7258:	48 83 3d a8 be 01 00 	cmpq   $0x0,0x1bea8(%rip)        # 23108 <fwp_ntapes>
    725f:	00 
    7260:	48 c7 05 3d be 01 00 	movq   $0x0,0x1be3d(%rip)        # 230a8 <fwp_tape_cached_bytes>
    7267:	00 00 00 00 
    726b:	7e 68                	jle    72d5 <fwp_tape_finish+0x95>
    726d:	45 31 e4             	xor    %r12d,%r12d
    7270:	31 ed                	xor    %ebp,%ebp
    7272:	0f 1f 00             	nopl   (%rax)
    7275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    727c:	00 00 00 00 
    7280:	48 8b 1d 89 be 01 00 	mov    0x1be89(%rip),%rbx        # 23110 <fwp_tapes>
    7287:	48 83 c5 01          	add    $0x1,%rbp
    728b:	4c 01 e3             	add    %r12,%rbx
    728e:	49 83 c4 68          	add    $0x68,%r12
    7292:	48 89 df             	mov    %rbx,%rdi
    7295:	e8 66 c9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    729a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    729e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    72a2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    72a6:	e8 15 c1 ff ff       	call   33c0 <free@plt>
    72ab:	4c 89 f7             	mov    %r14,%rdi
    72ae:	e8 0d c1 ff ff       	call   33c0 <free@plt>
    72b3:	4c 89 ef             	mov    %r13,%rdi
    72b6:	e8 05 c1 ff ff       	call   33c0 <free@plt>
    72bb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    72bf:	e8 6c fe ff ff       	call   7130 <fwp_owned_tape_release>
    72c4:	48 39 2d 3d be 01 00 	cmp    %rbp,0x1be3d(%rip)        # 23108 <fwp_ntapes>
    72cb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    72d2:	00 
    72d3:	7f ab                	jg     7280 <fwp_tape_finish+0x40>
    72d5:	48 8b 3d 34 be 01 00 	mov    0x1be34(%rip),%rdi        # 23110 <fwp_tapes>
    72dc:	e8 df c0 ff ff       	call   33c0 <free@plt>
    72e1:	5b                   	pop    %rbx
    72e2:	5d                   	pop    %rbp
    72e3:	48 c7 05 22 be 01 00 	movq   $0x0,0x1be22(%rip)        # 23110 <fwp_tapes>
    72ea:	00 00 00 00 
    72ee:	48 c7 05 07 be 01 00 	movq   $0x0,0x1be07(%rip)        # 23100 <fwp_tapes_cap>
    72f5:	00 00 00 00 
    72f9:	41 5c                	pop    %r12
    72fb:	48 c7 05 02 be 01 00 	movq   $0x0,0x1be02(%rip)        # 23108 <fwp_ntapes>
    7302:	00 00 00 00 
    7306:	41 5d                	pop    %r13
    7308:	48 c7 05 e5 bd 01 00 	movq   $0x0,0x1bde5(%rip)        # 230f8 <fwp_tape_next_slot>
    730f:	00 00 00 00 
    7313:	41 5e                	pop    %r14
    7315:	c3                   	ret
    7316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    731d:	00 00 00 

0000000000007320 <fwp_tape_scope_release>:
    7320:	f3 0f 1e fa          	endbr64
    7324:	41 55                	push   %r13
    7326:	41 54                	push   %r12
    7328:	55                   	push   %rbp
    7329:	53                   	push   %rbx
    732a:	48 83 ec 58          	sub    $0x58,%rsp
    732e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7335:	00 00 
    7337:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    733c:	48 63 07             	movslq (%rdi),%rax
    733f:	85 c0                	test   %eax,%eax
    7341:	0f 88 05 01 00 00    	js     744c <fwp_tape_scope_release+0x12c>
    7347:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    734e:	ec c4 4e 
    7351:	48 89 fb             	mov    %rdi,%rbx
    7354:	eb 3c                	jmp    7392 <fwp_tape_scope_release+0x72>
    7356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    735d:	00 00 00 
    7360:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7365:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7369:	e8 52 c0 ff ff       	call   33c0 <free@plt>
    736e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7372:	e8 49 c0 ff ff       	call   33c0 <free@plt>
    7377:	4c 89 ef             	mov    %r13,%rdi
    737a:	e8 41 c0 ff ff       	call   33c0 <free@plt>
    737f:	4c 89 e7             	mov    %r12,%rdi
    7382:	e8 a9 fd ff ff       	call   7130 <fwp_owned_tape_release>
    7387:	48 63 03             	movslq (%rbx),%rax
    738a:	85 c0                	test   %eax,%eax
    738c:	0f 88 ba 00 00 00    	js     744c <fwp_tape_scope_release+0x12c>
    7392:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7396:	48 8b 35 73 bd 01 00 	mov    0x1bd73(%rip),%rsi        # 23110 <fwp_tapes>
    739d:	4c 01 c6             	add    %r8,%rsi
    73a0:	48 89 f7             	mov    %rsi,%rdi
    73a3:	e8 58 c8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    73a8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    73ad:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    73b2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    73b9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    73bd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    73c1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    73c8:	00 
    73c9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    73ce:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    73d2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    73d7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    73db:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    73e0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    73e7:	00 
    73e8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    73ef:	00 
    73f0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    73f7:	00 
    73f8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    73fd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7402:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7406:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    740a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    740e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7414:	77 18                	ja     742e <fwp_tape_scope_release+0x10e>
    7416:	49 c1 f8 03          	sar    $0x3,%r8
    741a:	4c 0f af c5          	imul   %rbp,%r8
    741e:	4c 3b 05 d3 bc 01 00 	cmp    0x1bcd3(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    7425:	7d 07                	jge    742e <fwp_tape_scope_release+0x10e>
    7427:	4c 89 05 ca bc 01 00 	mov    %r8,0x1bcca(%rip)        # 230f8 <fwp_tape_next_slot>
    742e:	4d 85 e4             	test   %r12,%r12
    7431:	0f 85 29 ff ff ff    	jne    7360 <fwp_tape_scope_release+0x40>
    7437:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    743c:	e8 ef d9 ff ff       	call   4e30 <fwp_tape_buffers_release>
    7441:	48 63 03             	movslq (%rbx),%rax
    7444:	85 c0                	test   %eax,%eax
    7446:	0f 89 46 ff ff ff    	jns    7392 <fwp_tape_scope_release+0x72>
    744c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7451:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7458:	00 00 
    745a:	75 0b                	jne    7467 <fwp_tape_scope_release+0x147>
    745c:	48 83 c4 58          	add    $0x58,%rsp
    7460:	5b                   	pop    %rbx
    7461:	5d                   	pop    %rbp
    7462:	41 5c                	pop    %r12
    7464:	41 5d                	pop    %r13
    7466:	c3                   	ret
    7467:	e8 f4 bf ff ff       	call   3460 <__stack_chk_fail@plt>
    746c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007470 <fwp_task_dispose>:
    7470:	53                   	push   %rbx
    7471:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7475:	0f 84 cb c2 ff ff    	je     3746 <fwp_task_dispose.cold>
    747b:	48 89 fb             	mov    %rdi,%rbx
    747e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7483:	0f 85 bd c2 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7489:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    748d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7494:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    749b:	00 
    749c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    74a0:	48 85 ff             	test   %rdi,%rdi
    74a3:	74 07                	je     74ac <fwp_task_dispose+0x3c>
    74a5:	48 85 c0             	test   %rax,%rax
    74a8:	74 02                	je     74ac <fwp_task_dispose+0x3c>
    74aa:	ff d0                	call   *%rax
    74ac:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    74b3:	e8 98 e0 ff ff       	call   5550 <fwp_mem_free>
    74b8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    74bf:	00 00 00 00 
    74c3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    74c7:	74 6f                	je     7538 <fwp_task_dispose+0xc8>
    74c9:	48 8b 15 88 d6 01 00 	mov    0x1d688(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    74d0:	48 89 d8             	mov    %rbx,%rax
    74d3:	48 2b 05 56 d6 01 00 	sub    0x1d656(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    74da:	48 c1 e2 10          	shl    $0x10,%rdx
    74de:	48 39 d0             	cmp    %rdx,%rax
    74e1:	73 4c                	jae    752f <fwp_task_dispose+0xbf>
    74e3:	48 89 c2             	mov    %rax,%rdx
    74e6:	48 c1 ea 10          	shr    $0x10,%rdx
    74ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74ee:	48 8b 15 83 d6 01 00 	mov    0x1d683(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    74f5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74f9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74fd:	48 85 c9             	test   %rcx,%rcx
    7500:	74 2d                	je     752f <fwp_task_dispose+0xbf>
    7502:	0f b6 32             	movzbl (%rdx),%esi
    7505:	40 80 fe 02          	cmp    $0x2,%sil
    7509:	74 3d                	je     7548 <fwp_task_dispose+0xd8>
    750b:	40 80 fe 01          	cmp    $0x1,%sil
    750f:	75 1e                	jne    752f <fwp_task_dispose+0xbf>
    7511:	8b 72 18             	mov    0x18(%rdx),%esi
    7514:	0f b7 c0             	movzwl %ax,%eax
    7517:	8b 52 1c             	mov    0x1c(%rdx),%edx
    751a:	48 0f af c6          	imul   %rsi,%rax
    751e:	48 c1 e8 20          	shr    $0x20,%rax
    7522:	48 39 d0             	cmp    %rdx,%rax
    7525:	73 08                	jae    752f <fwp_task_dispose+0xbf>
    7527:	48 01 c1             	add    %rax,%rcx
    752a:	80 39 01             	cmpb   $0x1,(%rcx)
    752d:	74 09                	je     7538 <fwp_task_dispose+0xc8>
    752f:	5b                   	pop    %rbx
    7530:	c3                   	ret
    7531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7538:	48 89 df             	mov    %rbx,%rdi
    753b:	5b                   	pop    %rbx
    753c:	e9 0f e0 ff ff       	jmp    5550 <fwp_mem_free>
    7541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7548:	66 85 c0             	test   %ax,%ax
    754b:	74 dd                	je     752a <fwp_task_dispose+0xba>
    754d:	5b                   	pop    %rbx
    754e:	c3                   	ret
    754f:	90                   	nop

0000000000007550 <fwp_free_zombie>:
    7550:	48 8b 15 f9 c1 01 00 	mov    0x1c1f9(%rip),%rdx        # 23750 <fwp_zombie>
    7557:	48 85 d2             	test   %rdx,%rdx
    755a:	0f 84 98 00 00 00    	je     75f8 <fwp_free_zombie+0xa8>
    7560:	48 3b 15 f9 c1 01 00 	cmp    0x1c1f9(%rip),%rdx        # 23760 <fwp_cur>
    7567:	0f 84 8b 00 00 00    	je     75f8 <fwp_free_zombie+0xa8>
    756d:	48 83 ec 18          	sub    $0x18,%rsp
    7571:	48 63 05 b4 bb 01 00 	movslq 0x1bbb4(%rip),%rax        # 2312c <fwp_stack_pool_n>
    7578:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    757c:	83 f8 3f             	cmp    $0x3f,%eax
    757f:	7f 7f                	jg     7600 <fwp_free_zombie+0xb0>
    7581:	8d 48 01             	lea    0x1(%rax),%ecx
    7584:	89 0d a2 bb 01 00    	mov    %ecx,0x1bba2(%rip)        # 2312c <fwp_stack_pool_n>
    758a:	48 8d 0d af bb 01 00 	lea    0x1bbaf(%rip),%rcx        # 23140 <fwp_stack_pool>
    7591:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7595:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    759c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    75a0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    75a7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    75ab:	48 85 c9             	test   %rcx,%rcx
    75ae:	0f 84 fc 00 00 00    	je     76b0 <fwp_free_zombie+0x160>
    75b4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    75bb:	48 85 c0             	test   %rax,%rax
    75be:	74 07                	je     75c7 <fwp_free_zombie+0x77>
    75c0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    75c7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    75ca:	66 0f ef c0          	pxor   %xmm0,%xmm0
    75ce:	48 c7 05 77 c1 01 00 	movq   $0x0,0x1c177(%rip)        # 23750 <fwp_zombie>
    75d5:	00 00 00 00 
    75d9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    75e0:	85 c0                	test   %eax,%eax
    75e2:	74 34                	je     7618 <fwp_free_zombie+0xc8>
    75e4:	83 f8 01             	cmp    $0x1,%eax
    75e7:	0f 84 b3 00 00 00    	je     76a0 <fwp_free_zombie+0x150>
    75ed:	48 83 c4 18          	add    $0x18,%rsp
    75f1:	c3                   	ret
    75f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75f8:	c3                   	ret
    75f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7600:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7604:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7609:	e8 d2 bf ff ff       	call   35e0 <munmap@plt>
    760e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7613:	eb 80                	jmp    7595 <fwp_free_zombie+0x45>
    7615:	0f 1f 00             	nopl   (%rax)
    7618:	48 8b 0d 39 d5 01 00 	mov    0x1d539(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    761f:	48 89 d0             	mov    %rdx,%rax
    7622:	48 2b 05 07 d5 01 00 	sub    0x1d507(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7629:	48 c1 e1 10          	shl    $0x10,%rcx
    762d:	48 39 c8             	cmp    %rcx,%rax
    7630:	73 bb                	jae    75ed <fwp_free_zombie+0x9d>
    7632:	48 89 c1             	mov    %rax,%rcx
    7635:	48 c1 e9 10          	shr    $0x10,%rcx
    7639:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    763d:	48 8b 0d 34 d5 01 00 	mov    0x1d534(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7644:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7648:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    764c:	48 85 c9             	test   %rcx,%rcx
    764f:	74 9c                	je     75ed <fwp_free_zombie+0x9d>
    7651:	0f b6 3e             	movzbl (%rsi),%edi
    7654:	40 80 ff 02          	cmp    $0x2,%dil
    7658:	74 66                	je     76c0 <fwp_free_zombie+0x170>
    765a:	40 80 ff 01          	cmp    $0x1,%dil
    765e:	75 8d                	jne    75ed <fwp_free_zombie+0x9d>
    7660:	8b 7e 18             	mov    0x18(%rsi),%edi
    7663:	0f b7 c0             	movzwl %ax,%eax
    7666:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7669:	48 0f af c7          	imul   %rdi,%rax
    766d:	48 c1 e8 20          	shr    $0x20,%rax
    7671:	48 39 f0             	cmp    %rsi,%rax
    7674:	0f 83 73 ff ff ff    	jae    75ed <fwp_free_zombie+0x9d>
    767a:	48 01 c1             	add    %rax,%rcx
    767d:	0f b6 01             	movzbl (%rcx),%eax
    7680:	84 c0                	test   %al,%al
    7682:	0f 84 65 ff ff ff    	je     75ed <fwp_free_zombie+0x9d>
    7688:	3c 01                	cmp    $0x1,%al
    768a:	74 14                	je     76a0 <fwp_free_zombie+0x150>
    768c:	3c ff                	cmp    $0xff,%al
    768e:	74 3b                	je     76cb <fwp_free_zombie+0x17b>
    7690:	83 e8 01             	sub    $0x1,%eax
    7693:	88 01                	mov    %al,(%rcx)
    7695:	e9 53 ff ff ff       	jmp    75ed <fwp_free_zombie+0x9d>
    769a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76a0:	48 89 d7             	mov    %rdx,%rdi
    76a3:	48 83 c4 18          	add    $0x18,%rsp
    76a7:	e9 c4 fd ff ff       	jmp    7470 <fwp_task_dispose>
    76ac:	0f 1f 40 00          	nopl   0x0(%rax)
    76b0:	48 89 05 71 c0 01 00 	mov    %rax,0x1c071(%rip)        # 23728 <fwp_tasks_active>
    76b7:	e9 ff fe ff ff       	jmp    75bb <fwp_free_zombie+0x6b>
    76bc:	0f 1f 40 00          	nopl   0x0(%rax)
    76c0:	66 85 c0             	test   %ax,%ax
    76c3:	0f 85 24 ff ff ff    	jne    75ed <fwp_free_zombie+0x9d>
    76c9:	eb b2                	jmp    767d <fwp_free_zombie+0x12d>
    76cb:	48 89 ca             	mov    %rcx,%rdx
    76ce:	48 8d 35 ab c0 01 00 	lea    0x1c0ab(%rip),%rsi        # 23780 <fwp_heap>
    76d5:	48 c1 ea 11          	shr    $0x11,%rdx
    76d9:	48 31 ca             	xor    %rcx,%rdx
    76dc:	48 89 d0             	mov    %rdx,%rax
    76df:	48 c1 e8 09          	shr    $0x9,%rax
    76e3:	48 31 c2             	xor    %rax,%rdx
    76e6:	0f b6 d2             	movzbl %dl,%edx
    76e9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    76f0:	00 
    76f1:	48 85 c0             	test   %rax,%rax
    76f4:	75 13                	jne    7709 <fwp_free_zombie+0x1b9>
    76f6:	eb 4c                	jmp    7744 <fwp_free_zombie+0x1f4>
    76f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    76ff:	00 
    7700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7704:	48 85 c0             	test   %rax,%rax
    7707:	74 3b                	je     7744 <fwp_free_zombie+0x1f4>
    7709:	48 89 c2             	mov    %rax,%rdx
    770c:	48 39 08             	cmp    %rcx,(%rax)
    770f:	75 ef                	jne    7700 <fwp_free_zombie+0x1b0>
    7711:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7715:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7719:	48 89 50 08          	mov    %rdx,0x8(%rax)
    771d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7724:	0f 85 c3 fe ff ff    	jne    75ed <fwp_free_zombie+0x9d>
    772a:	48 89 cf             	mov    %rcx,%rdi
    772d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7732:	e8 d9 db ff ff       	call   5310 <fwp_rc_forget_slot>
    7737:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    773c:	c6 01 fe             	movb   $0xfe,(%rcx)
    773f:	e9 a9 fe ff ff       	jmp    75ed <fwp_free_zombie+0x9d>
    7744:	48 8d 3d 4d 80 00 00 	lea    0x804d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    774b:	e8 50 ca ff ff       	call   41a0 <fwp_trap>

0000000000007750 <fwp_block>:
    7750:	48 83 ec 08          	sub    $0x8,%rsp
    7754:	48 8b 05 ed bf 01 00 	mov    0x1bfed(%rip),%rax        # 23748 <fwp_ready_head>
    775b:	48 85 c0             	test   %rax,%rax
    775e:	0f 84 1c 01 00 00    	je     7880 <fwp_block+0x130>
    7764:	90                   	nop
    7765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    776c:	00 00 00 00 
    7770:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7777:	48 89 15 ca bf 01 00 	mov    %rdx,0x1bfca(%rip)        # 23748 <fwp_ready_head>
    777e:	48 85 d2             	test   %rdx,%rdx
    7781:	0f 84 19 01 00 00    	je     78a0 <fwp_block+0x150>
    7787:	48 8b 15 d2 bf 01 00 	mov    0x1bfd2(%rip),%rdx        # 23760 <fwp_cur>
    778e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7792:	48 39 c2             	cmp    %rax,%rdx
    7795:	0f 84 d5 00 00 00    	je     7870 <fwp_block+0x120>
    779b:	48 8b 0d 46 dc 01 00 	mov    0x1dc46(%rip),%rcx        # 253e8 <fwp_state_owners>
    77a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    77a6:	48 89 05 b3 bf 01 00 	mov    %rax,0x1bfb3(%rip)        # 23760 <fwp_cur>
    77ad:	f3 0f 7e 05 5b dc 01 	movq   0x1dc5b(%rip),%xmm0        # 25410 <fwp_foreign_callbacks>
    77b4:	00 
    77b5:	0f 16 05 44 dc 01 00 	movhps 0x1dc44(%rip),%xmm0        # 25400 <fwp_state>
    77bc:	f3 0f 7e 0d 44 dc 01 	movq   0x1dc44(%rip),%xmm1        # 25408 <fwp_handlers>
    77c3:	00 
    77c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    77cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    77d2:	0f 16 0d 3f dc 01 00 	movhps 0x1dc3f(%rip),%xmm1        # 25418 <fwp_cleanups>
    77d9:	f3 0f 7e 05 17 dc 01 	movq   0x1dc17(%rip),%xmm0        # 253f8 <fwp_state_len>
    77e0:	00 
    77e1:	0f 16 05 08 dc 01 00 	movhps 0x1dc08(%rip),%xmm0        # 253f0 <fwp_state_cap>
    77e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    77ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    77f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7801:	48 89 0d 00 dc 01 00 	mov    %rcx,0x1dc00(%rip)        # 25408 <fwp_handlers>
    7808:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    780f:	48 89 0d 02 dc 01 00 	mov    %rcx,0x1dc02(%rip)        # 25418 <fwp_cleanups>
    7816:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    781d:	48 89 0d ec db 01 00 	mov    %rcx,0x1dbec(%rip)        # 25410 <fwp_foreign_callbacks>
    7824:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    782b:	48 89 0d ce db 01 00 	mov    %rcx,0x1dbce(%rip)        # 25400 <fwp_state>
    7832:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7839:	48 89 0d b8 db 01 00 	mov    %rcx,0x1dbb8(%rip)        # 253f8 <fwp_state_len>
    7840:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7847:	48 89 0d a2 db 01 00 	mov    %rcx,0x1dba2(%rip)        # 253f0 <fwp_state_cap>
    784e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7855:	48 89 0d 8c db 01 00 	mov    %rcx,0x1db8c(%rip)        # 253e8 <fwp_state_owners>
    785c:	e8 2f bc ff ff       	call   3490 <swapcontext@plt>
    7861:	f3 0f 1e fa          	endbr64
    7865:	e8 e6 fc ff ff       	call   7550 <fwp_free_zombie>
    786a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7870:	8b 05 b2 b8 01 00    	mov    0x1b8b2(%rip),%eax        # 23128 <fwp_slice>
    7876:	85 c0                	test   %eax,%eax
    7878:	74 36                	je     78b0 <fwp_block+0x160>
    787a:	48 83 c4 08          	add    $0x8,%rsp
    787e:	c3                   	ret
    787f:	90                   	nop
    7880:	e8 db d6 ff ff       	call   4f60 <fwp_poll_events>
    7885:	48 8b 05 bc be 01 00 	mov    0x1bebc(%rip),%rax        # 23748 <fwp_ready_head>
    788c:	48 85 c0             	test   %rax,%rax
    788f:	0f 85 db fe ff ff    	jne    7770 <fwp_block+0x20>
    7895:	eb e9                	jmp    7880 <fwp_block+0x130>
    7897:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    789e:	00 00 
    78a0:	48 c7 05 95 be 01 00 	movq   $0x0,0x1be95(%rip)        # 23740 <fwp_ready_tail>
    78a7:	00 00 00 00 
    78ab:	e9 d7 fe ff ff       	jmp    7787 <fwp_block+0x37>
    78b0:	48 8d 3d 6a 78 00 00 	lea    0x786a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    78b7:	e8 e4 ba ff ff       	call   33a0 <getenv@plt>
    78bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    78c1:	48 85 c0             	test   %rax,%rax
    78c4:	74 05                	je     78cb <fwp_block+0x17b>
    78c6:	80 38 00             	cmpb   $0x0,(%rax)
    78c9:	75 0b                	jne    78d6 <fwp_block+0x186>
    78cb:	89 15 57 b8 01 00    	mov    %edx,0x1b857(%rip)        # 23128 <fwp_slice>
    78d1:	48 83 c4 08          	add    $0x8,%rsp
    78d5:	c3                   	ret
    78d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    78db:	31 f6                	xor    %esi,%esi
    78dd:	48 89 c7             	mov    %rax,%rdi
    78e0:	e8 6b bc ff ff       	call   3550 <strtoll@plt>
    78e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    78e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    78f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    78f5:	0f 46 d0             	cmovbe %eax,%edx
    78f8:	eb d1                	jmp    78cb <fwp_block+0x17b>
    78fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007900 <fwp_drop4>:
    7900:	48 8b 15 51 d2 01 00 	mov    0x1d251(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7907:	48 89 f8             	mov    %rdi,%rax
    790a:	48 2b 05 1f d2 01 00 	sub    0x1d21f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7911:	48 c1 e2 10          	shl    $0x10,%rdx
    7915:	48 39 d0             	cmp    %rdx,%rax
    7918:	0f 83 52 01 00 00    	jae    7a70 <fwp_drop4+0x170>
    791e:	48 83 ec 18          	sub    $0x18,%rsp
    7922:	4c 8d 05 57 be 01 00 	lea    0x1be57(%rip),%r8        # 23780 <fwp_heap>
    7929:	48 89 c2             	mov    %rax,%rdx
    792c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7933:	48 c1 ea 10          	shr    $0x10,%rdx
    7937:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    793b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    793f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7943:	48 85 d2             	test   %rdx,%rdx
    7946:	74 46                	je     798e <fwp_drop4+0x8e>
    7948:	44 0f b6 09          	movzbl (%rcx),%r9d
    794c:	41 80 f9 02          	cmp    $0x2,%r9b
    7950:	0f 84 ca 00 00 00    	je     7a20 <fwp_drop4+0x120>
    7956:	41 80 f9 01          	cmp    $0x1,%r9b
    795a:	75 32                	jne    798e <fwp_drop4+0x8e>
    795c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7960:	0f b7 c0             	movzwl %ax,%eax
    7963:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7966:	49 0f af c1          	imul   %r9,%rax
    796a:	48 c1 e8 20          	shr    $0x20,%rax
    796e:	48 39 c8             	cmp    %rcx,%rax
    7971:	73 1b                	jae    798e <fwp_drop4+0x8e>
    7973:	48 01 c2             	add    %rax,%rdx
    7976:	0f b6 02             	movzbl (%rdx),%eax
    7979:	84 c0                	test   %al,%al
    797b:	74 11                	je     798e <fwp_drop4+0x8e>
    797d:	3c 01                	cmp    $0x1,%al
    797f:	74 17                	je     7998 <fwp_drop4+0x98>
    7981:	3c ff                	cmp    $0xff,%al
    7983:	0f 84 ef 00 00 00    	je     7a78 <fwp_drop4+0x178>
    7989:	83 e8 01             	sub    $0x1,%eax
    798c:	88 02                	mov    %al,(%rdx)
    798e:	48 83 c4 18          	add    $0x18,%rsp
    7992:	c3                   	ret
    7993:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7998:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    799c:	0f 88 8e 00 00 00    	js     7a30 <fwp_drop4+0x130>
    79a2:	48 8b 15 af d1 01 00 	mov    0x1d1af(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    79a9:	48 89 f8             	mov    %rdi,%rax
    79ac:	48 2b 05 7d d1 01 00 	sub    0x1d17d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    79b3:	48 c1 e2 10          	shl    $0x10,%rdx
    79b7:	48 39 d0             	cmp    %rdx,%rax
    79ba:	73 d2                	jae    798e <fwp_drop4+0x8e>
    79bc:	48 89 c2             	mov    %rax,%rdx
    79bf:	48 c1 ea 10          	shr    $0x10,%rdx
    79c3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    79c7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    79cb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    79cf:	48 85 c9             	test   %rcx,%rcx
    79d2:	74 ba                	je     798e <fwp_drop4+0x8e>
    79d4:	0f b6 32             	movzbl (%rdx),%esi
    79d7:	40 80 fe 02          	cmp    $0x2,%sil
    79db:	74 33                	je     7a10 <fwp_drop4+0x110>
    79dd:	40 80 fe 01          	cmp    $0x1,%sil
    79e1:	75 ab                	jne    798e <fwp_drop4+0x8e>
    79e3:	8b 72 18             	mov    0x18(%rdx),%esi
    79e6:	0f b7 c0             	movzwl %ax,%eax
    79e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79ec:	48 0f af c6          	imul   %rsi,%rax
    79f0:	48 c1 e8 20          	shr    $0x20,%rax
    79f4:	48 39 d0             	cmp    %rdx,%rax
    79f7:	73 95                	jae    798e <fwp_drop4+0x8e>
    79f9:	48 01 c1             	add    %rax,%rcx
    79fc:	80 39 01             	cmpb   $0x1,(%rcx)
    79ff:	75 8d                	jne    798e <fwp_drop4+0x8e>
    7a01:	48 83 c4 18          	add    $0x18,%rsp
    7a05:	e9 46 db ff ff       	jmp    5550 <fwp_mem_free>
    7a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a10:	66 85 c0             	test   %ax,%ax
    7a13:	74 e7                	je     79fc <fwp_drop4+0xfc>
    7a15:	48 83 c4 18          	add    $0x18,%rsp
    7a19:	c3                   	ret
    7a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a20:	66 85 c0             	test   %ax,%ax
    7a23:	0f 84 4d ff ff ff    	je     7976 <fwp_drop4+0x76>
    7a29:	48 83 c4 18          	add    $0x18,%rsp
    7a2d:	c3                   	ret
    7a2e:	66 90                	xchg   %ax,%ax
    7a30:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7a34:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7a39:	e8 c2 ef ff ff       	call   6a00 <fwp_rc_free_arr>
    7a3e:	4c 8d 05 3b bd 01 00 	lea    0x1bd3b(%rip),%r8        # 23780 <fwp_heap>
    7a45:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a4a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7a51:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7a58:	48 c1 e2 10          	shl    $0x10,%rdx
    7a5c:	48 39 d0             	cmp    %rdx,%rax
    7a5f:	0f 83 29 ff ff ff    	jae    798e <fwp_drop4+0x8e>
    7a65:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7a6a:	e9 ba fe ff ff       	jmp    7929 <fwp_drop4+0x29>
    7a6f:	90                   	nop
    7a70:	c3                   	ret
    7a71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a78:	48 89 d0             	mov    %rdx,%rax
    7a7b:	48 c1 e8 11          	shr    $0x11,%rax
    7a7f:	48 31 d0             	xor    %rdx,%rax
    7a82:	48 89 c1             	mov    %rax,%rcx
    7a85:	48 c1 e9 09          	shr    $0x9,%rcx
    7a89:	48 31 c8             	xor    %rcx,%rax
    7a8c:	0f b6 c8             	movzbl %al,%ecx
    7a8f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7a96:	00 
    7a97:	48 85 c0             	test   %rax,%rax
    7a9a:	75 0d                	jne    7aa9 <fwp_drop4+0x1a9>
    7a9c:	eb 46                	jmp    7ae4 <fwp_drop4+0x1e4>
    7a9e:	66 90                	xchg   %ax,%ax
    7aa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7aa4:	48 85 c0             	test   %rax,%rax
    7aa7:	74 3b                	je     7ae4 <fwp_drop4+0x1e4>
    7aa9:	48 89 c1             	mov    %rax,%rcx
    7aac:	48 39 10             	cmp    %rdx,(%rax)
    7aaf:	75 ef                	jne    7aa0 <fwp_drop4+0x1a0>
    7ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ab5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7ab9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7abd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7ac4:	0f 85 c4 fe ff ff    	jne    798e <fwp_drop4+0x8e>
    7aca:	48 89 d7             	mov    %rdx,%rdi
    7acd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7ad2:	e8 39 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ad7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7adc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7adf:	e9 aa fe ff ff       	jmp    798e <fwp_drop4+0x8e>
    7ae4:	48 8d 3d ad 7c 00 00 	lea    0x7cad(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7aeb:	e8 b0 c6 ff ff       	call   41a0 <fwp_trap>

0000000000007af0 <fwp_caps161>:
    7af0:	f3 0f 1e fa          	endbr64
    7af4:	85 f6                	test   %esi,%esi
    7af6:	74 08                	je     7b00 <fwp_caps161+0x10>
    7af8:	c3                   	ret
    7af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b00:	48 8b 15 51 d0 01 00 	mov    0x1d051(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7b07:	48 89 f8             	mov    %rdi,%rax
    7b0a:	48 2b 05 1f d0 01 00 	sub    0x1d01f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7b11:	48 c1 e2 10          	shl    $0x10,%rdx
    7b15:	48 39 d0             	cmp    %rdx,%rax
    7b18:	73 de                	jae    7af8 <fwp_caps161+0x8>
    7b1a:	48 89 c2             	mov    %rax,%rdx
    7b1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7b21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b25:	48 8b 15 4c d0 01 00 	mov    0x1d04c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7b2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7b34:	48 85 c9             	test   %rcx,%rcx
    7b37:	74 bf                	je     7af8 <fwp_caps161+0x8>
    7b39:	0f b6 32             	movzbl (%rdx),%esi
    7b3c:	40 80 fe 02          	cmp    $0x2,%sil
    7b40:	74 2e                	je     7b70 <fwp_caps161+0x80>
    7b42:	40 80 fe 01          	cmp    $0x1,%sil
    7b46:	75 b0                	jne    7af8 <fwp_caps161+0x8>
    7b48:	8b 72 18             	mov    0x18(%rdx),%esi
    7b4b:	0f b7 c0             	movzwl %ax,%eax
    7b4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b51:	48 0f af c6          	imul   %rsi,%rax
    7b55:	48 c1 e8 20          	shr    $0x20,%rax
    7b59:	48 39 d0             	cmp    %rdx,%rax
    7b5c:	73 9a                	jae    7af8 <fwp_caps161+0x8>
    7b5e:	48 01 c1             	add    %rax,%rcx
    7b61:	80 39 01             	cmpb   $0x1,(%rcx)
    7b64:	75 92                	jne    7af8 <fwp_caps161+0x8>
    7b66:	e9 e5 d9 ff ff       	jmp    5550 <fwp_mem_free>
    7b6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7b70:	66 85 c0             	test   %ax,%ax
    7b73:	74 ec                	je     7b61 <fwp_caps161+0x71>
    7b75:	c3                   	ret
    7b76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7b7d:	00 00 00 

0000000000007b80 <fwp_args12>:
    7b80:	f3 0f 1e fa          	endbr64
    7b84:	85 d2                	test   %edx,%edx
    7b86:	74 04                	je     7b8c <fwp_args12+0xc>
    7b88:	85 f6                	test   %esi,%esi
    7b8a:	74 04                	je     7b90 <fwp_args12+0x10>
    7b8c:	c3                   	ret
    7b8d:	0f 1f 00             	nopl   (%rax)
    7b90:	48 8b 15 c1 cf 01 00 	mov    0x1cfc1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7b97:	48 8b 07             	mov    (%rdi),%rax
    7b9a:	48 2b 05 8f cf 01 00 	sub    0x1cf8f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7ba1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ba5:	48 39 d0             	cmp    %rdx,%rax
    7ba8:	73 e2                	jae    7b8c <fwp_args12+0xc>
    7baa:	48 89 c2             	mov    %rax,%rdx
    7bad:	48 c1 ea 10          	shr    $0x10,%rdx
    7bb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7bb5:	48 8b 15 bc cf 01 00 	mov    0x1cfbc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7bbc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bc0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7bc4:	48 85 ff             	test   %rdi,%rdi
    7bc7:	74 c3                	je     7b8c <fwp_args12+0xc>
    7bc9:	0f b6 0a             	movzbl (%rdx),%ecx
    7bcc:	80 f9 02             	cmp    $0x2,%cl
    7bcf:	74 2f                	je     7c00 <fwp_args12+0x80>
    7bd1:	80 f9 01             	cmp    $0x1,%cl
    7bd4:	75 b6                	jne    7b8c <fwp_args12+0xc>
    7bd6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7bd9:	0f b7 c0             	movzwl %ax,%eax
    7bdc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bdf:	48 0f af c1          	imul   %rcx,%rax
    7be3:	48 c1 e8 20          	shr    $0x20,%rax
    7be7:	48 39 d0             	cmp    %rdx,%rax
    7bea:	73 a0                	jae    7b8c <fwp_args12+0xc>
    7bec:	48 01 c7             	add    %rax,%rdi
    7bef:	0f b6 07             	movzbl (%rdi),%eax
    7bf2:	84 c0                	test   %al,%al
    7bf4:	74 96                	je     7b8c <fwp_args12+0xc>
    7bf6:	3c fd                	cmp    $0xfd,%al
    7bf8:	77 0c                	ja     7c06 <fwp_args12+0x86>
    7bfa:	83 c0 01             	add    $0x1,%eax
    7bfd:	88 07                	mov    %al,(%rdi)
    7bff:	c3                   	ret
    7c00:	66 85 c0             	test   %ax,%ax
    7c03:	74 ea                	je     7bef <fwp_args12+0x6f>
    7c05:	c3                   	ret
    7c06:	e9 e5 d5 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007c10 <fwp_args23>:
    7c10:	f3 0f 1e fa          	endbr64
    7c14:	85 d2                	test   %edx,%edx
    7c16:	74 04                	je     7c1c <fwp_args23+0xc>
    7c18:	85 f6                	test   %esi,%esi
    7c1a:	74 04                	je     7c20 <fwp_args23+0x10>
    7c1c:	c3                   	ret
    7c1d:	0f 1f 00             	nopl   (%rax)
    7c20:	48 8b 15 31 cf 01 00 	mov    0x1cf31(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7c27:	48 8b 07             	mov    (%rdi),%rax
    7c2a:	48 2b 05 ff ce 01 00 	sub    0x1ceff(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7c31:	48 c1 e2 10          	shl    $0x10,%rdx
    7c35:	48 39 d0             	cmp    %rdx,%rax
    7c38:	73 e2                	jae    7c1c <fwp_args23+0xc>
    7c3a:	48 89 c2             	mov    %rax,%rdx
    7c3d:	48 c1 ea 10          	shr    $0x10,%rdx
    7c41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c45:	48 8b 15 2c cf 01 00 	mov    0x1cf2c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7c4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c50:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7c54:	48 85 ff             	test   %rdi,%rdi
    7c57:	74 c3                	je     7c1c <fwp_args23+0xc>
    7c59:	0f b6 0a             	movzbl (%rdx),%ecx
    7c5c:	80 f9 02             	cmp    $0x2,%cl
    7c5f:	74 2f                	je     7c90 <fwp_args23+0x80>
    7c61:	80 f9 01             	cmp    $0x1,%cl
    7c64:	75 b6                	jne    7c1c <fwp_args23+0xc>
    7c66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c69:	0f b7 c0             	movzwl %ax,%eax
    7c6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c6f:	48 0f af c1          	imul   %rcx,%rax
    7c73:	48 c1 e8 20          	shr    $0x20,%rax
    7c77:	48 39 d0             	cmp    %rdx,%rax
    7c7a:	73 a0                	jae    7c1c <fwp_args23+0xc>
    7c7c:	48 01 c7             	add    %rax,%rdi
    7c7f:	0f b6 07             	movzbl (%rdi),%eax
    7c82:	84 c0                	test   %al,%al
    7c84:	74 96                	je     7c1c <fwp_args23+0xc>
    7c86:	3c fd                	cmp    $0xfd,%al
    7c88:	77 0c                	ja     7c96 <fwp_args23+0x86>
    7c8a:	83 c0 01             	add    $0x1,%eax
    7c8d:	88 07                	mov    %al,(%rdi)
    7c8f:	c3                   	ret
    7c90:	66 85 c0             	test   %ax,%ax
    7c93:	74 ea                	je     7c7f <fwp_args23+0x6f>
    7c95:	c3                   	ret
    7c96:	e9 55 d5 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007ca0 <fwp_caps12>:
    7ca0:	f3 0f 1e fa          	endbr64
    7ca4:	48 83 ec 18          	sub    $0x18,%rsp
    7ca8:	8b 57 04             	mov    0x4(%rdi),%edx
    7cab:	48 89 f8             	mov    %rdi,%rax
    7cae:	85 d2                	test   %edx,%edx
    7cb0:	0f 84 9a 00 00 00    	je     7d50 <fwp_caps12+0xb0>
    7cb6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7cba:	85 f6                	test   %esi,%esi
    7cbc:	0f 85 9e 00 00 00    	jne    7d60 <fwp_caps12+0xc0>
    7cc2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7cc7:	e8 44 f0 ff ff       	call   6d10 <fwp_drop0>
    7ccc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7cd1:	48 8b 0d 80 ce 01 00 	mov    0x1ce80(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7cd8:	48 89 c2             	mov    %rax,%rdx
    7cdb:	48 2b 15 4e ce 01 00 	sub    0x1ce4e(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7ce2:	48 c1 e1 10          	shl    $0x10,%rcx
    7ce6:	48 39 ca             	cmp    %rcx,%rdx
    7ce9:	73 6d                	jae    7d58 <fwp_caps12+0xb8>
    7ceb:	48 89 d1             	mov    %rdx,%rcx
    7cee:	48 c1 e9 10          	shr    $0x10,%rcx
    7cf2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7cf6:	48 8b 0d 7b ce 01 00 	mov    0x1ce7b(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7cfd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7d01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7d05:	48 85 f6             	test   %rsi,%rsi
    7d08:	74 4e                	je     7d58 <fwp_caps12+0xb8>
    7d0a:	0f b6 39             	movzbl (%rcx),%edi
    7d0d:	40 80 ff 02          	cmp    $0x2,%dil
    7d11:	0f 84 b9 00 00 00    	je     7dd0 <fwp_caps12+0x130>
    7d17:	40 80 ff 01          	cmp    $0x1,%dil
    7d1b:	75 3b                	jne    7d58 <fwp_caps12+0xb8>
    7d1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7d20:	0f b7 d2             	movzwl %dx,%edx
    7d23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d26:	48 0f af d7          	imul   %rdi,%rdx
    7d2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7d2e:	48 39 ca             	cmp    %rcx,%rdx
    7d31:	73 25                	jae    7d58 <fwp_caps12+0xb8>
    7d33:	48 01 d6             	add    %rdx,%rsi
    7d36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7d39:	75 1d                	jne    7d58 <fwp_caps12+0xb8>
    7d3b:	48 89 c7             	mov    %rax,%rdi
    7d3e:	48 83 c4 18          	add    $0x18,%rsp
    7d42:	e9 09 d8 ff ff       	jmp    5550 <fwp_mem_free>
    7d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d4e:	00 00 
    7d50:	85 f6                	test   %esi,%esi
    7d52:	0f 84 79 ff ff ff    	je     7cd1 <fwp_caps12+0x31>
    7d58:	48 83 c4 18          	add    $0x18,%rsp
    7d5c:	c3                   	ret
    7d5d:	0f 1f 00             	nopl   (%rax)
    7d60:	48 8b 05 f1 cd 01 00 	mov    0x1cdf1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7d67:	48 2b 3d c2 cd 01 00 	sub    0x1cdc2(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    7d6e:	48 c1 e0 10          	shl    $0x10,%rax
    7d72:	48 39 c7             	cmp    %rax,%rdi
    7d75:	73 e1                	jae    7d58 <fwp_caps12+0xb8>
    7d77:	48 89 f8             	mov    %rdi,%rax
    7d7a:	48 c1 e8 10          	shr    $0x10,%rax
    7d7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7d82:	48 8b 05 ef cd 01 00 	mov    0x1cdef(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7d89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7d8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7d91:	48 85 c0             	test   %rax,%rax
    7d94:	74 c2                	je     7d58 <fwp_caps12+0xb8>
    7d96:	0f b6 0a             	movzbl (%rdx),%ecx
    7d99:	80 f9 02             	cmp    $0x2,%cl
    7d9c:	74 42                	je     7de0 <fwp_caps12+0x140>
    7d9e:	80 f9 01             	cmp    $0x1,%cl
    7da1:	75 b5                	jne    7d58 <fwp_caps12+0xb8>
    7da3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7da6:	0f b7 ff             	movzwl %di,%edi
    7da9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dac:	48 0f af f9          	imul   %rcx,%rdi
    7db0:	48 c1 ef 20          	shr    $0x20,%rdi
    7db4:	48 39 d7             	cmp    %rdx,%rdi
    7db7:	73 9f                	jae    7d58 <fwp_caps12+0xb8>
    7db9:	48 01 f8             	add    %rdi,%rax
    7dbc:	0f b6 10             	movzbl (%rax),%edx
    7dbf:	84 d2                	test   %dl,%dl
    7dc1:	74 95                	je     7d58 <fwp_caps12+0xb8>
    7dc3:	80 fa fd             	cmp    $0xfd,%dl
    7dc6:	77 23                	ja     7deb <fwp_caps12+0x14b>
    7dc8:	83 c2 01             	add    $0x1,%edx
    7dcb:	88 10                	mov    %dl,(%rax)
    7dcd:	eb 89                	jmp    7d58 <fwp_caps12+0xb8>
    7dcf:	90                   	nop
    7dd0:	66 85 d2             	test   %dx,%dx
    7dd3:	0f 85 7f ff ff ff    	jne    7d58 <fwp_caps12+0xb8>
    7dd9:	e9 58 ff ff ff       	jmp    7d36 <fwp_caps12+0x96>
    7dde:	66 90                	xchg   %ax,%ax
    7de0:	66 85 ff             	test   %di,%di
    7de3:	0f 85 6f ff ff ff    	jne    7d58 <fwp_caps12+0xb8>
    7de9:	eb d1                	jmp    7dbc <fwp_caps12+0x11c>
    7deb:	48 89 c7             	mov    %rax,%rdi
    7dee:	48 83 c4 18          	add    $0x18,%rsp
    7df2:	e9 f9 d3 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7df7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7dfe:	00 00 

0000000000007e00 <fwp_drop2>:
    7e00:	48 8b 0d 51 cd 01 00 	mov    0x1cd51(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7e07:	48 89 f8             	mov    %rdi,%rax
    7e0a:	48 2b 05 1f cd 01 00 	sub    0x1cd1f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7e11:	48 c1 e1 10          	shl    $0x10,%rcx
    7e15:	48 39 c8             	cmp    %rcx,%rax
    7e18:	0f 83 42 01 00 00    	jae    7f60 <fwp_drop2+0x160>
    7e1e:	48 83 ec 18          	sub    $0x18,%rsp
    7e22:	48 89 fa             	mov    %rdi,%rdx
    7e25:	4c 8d 05 54 b9 01 00 	lea    0x1b954(%rip),%r8        # 23780 <fwp_heap>
    7e2c:	48 89 c1             	mov    %rax,%rcx
    7e2f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7e36:	48 c1 e9 10          	shr    $0x10,%rcx
    7e3a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7e3e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7e42:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7e46:	48 85 c9             	test   %rcx,%rcx
    7e49:	74 40                	je     7e8b <fwp_drop2+0x8b>
    7e4b:	0f b6 3e             	movzbl (%rsi),%edi
    7e4e:	40 80 ff 02          	cmp    $0x2,%dil
    7e52:	74 3c                	je     7e90 <fwp_drop2+0x90>
    7e54:	40 80 ff 01          	cmp    $0x1,%dil
    7e58:	75 31                	jne    7e8b <fwp_drop2+0x8b>
    7e5a:	8b 7e 18             	mov    0x18(%rsi),%edi
    7e5d:	0f b7 c0             	movzwl %ax,%eax
    7e60:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7e63:	48 0f af c7          	imul   %rdi,%rax
    7e67:	48 c1 e8 20          	shr    $0x20,%rax
    7e6b:	48 39 f0             	cmp    %rsi,%rax
    7e6e:	73 1b                	jae    7e8b <fwp_drop2+0x8b>
    7e70:	48 01 c1             	add    %rax,%rcx
    7e73:	0f b6 01             	movzbl (%rcx),%eax
    7e76:	84 c0                	test   %al,%al
    7e78:	74 11                	je     7e8b <fwp_drop2+0x8b>
    7e7a:	3c 01                	cmp    $0x1,%al
    7e7c:	74 22                	je     7ea0 <fwp_drop2+0xa0>
    7e7e:	3c ff                	cmp    $0xff,%al
    7e80:	0f 84 0a 01 00 00    	je     7f90 <fwp_drop2+0x190>
    7e86:	83 e8 01             	sub    $0x1,%eax
    7e89:	88 01                	mov    %al,(%rcx)
    7e8b:	48 83 c4 18          	add    $0x18,%rsp
    7e8f:	c3                   	ret
    7e90:	66 85 c0             	test   %ax,%ax
    7e93:	74 de                	je     7e73 <fwp_drop2+0x73>
    7e95:	48 83 c4 18          	add    $0x18,%rsp
    7e99:	c3                   	ret
    7e9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ea0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7ea4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7eab:	48 89 f8             	mov    %rdi,%rax
    7eae:	48 c1 e1 10          	shl    $0x10,%rcx
    7eb2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7eb9:	48 39 c8             	cmp    %rcx,%rax
    7ebc:	73 62                	jae    7f20 <fwp_drop2+0x120>
    7ebe:	48 89 c1             	mov    %rax,%rcx
    7ec1:	48 c1 e9 10          	shr    $0x10,%rcx
    7ec5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ec9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7ecd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7ed1:	48 85 c9             	test   %rcx,%rcx
    7ed4:	74 4a                	je     7f20 <fwp_drop2+0x120>
    7ed6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7eda:	41 80 f9 02          	cmp    $0x2,%r9b
    7ede:	0f 84 9c 00 00 00    	je     7f80 <fwp_drop2+0x180>
    7ee4:	41 80 f9 01          	cmp    $0x1,%r9b
    7ee8:	75 36                	jne    7f20 <fwp_drop2+0x120>
    7eea:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7eee:	0f b7 c0             	movzwl %ax,%eax
    7ef1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7ef4:	49 0f af c1          	imul   %r9,%rax
    7ef8:	48 c1 e8 20          	shr    $0x20,%rax
    7efc:	48 39 f0             	cmp    %rsi,%rax
    7eff:	73 1f                	jae    7f20 <fwp_drop2+0x120>
    7f01:	48 01 c1             	add    %rax,%rcx
    7f04:	0f b6 01             	movzbl (%rcx),%eax
    7f07:	84 c0                	test   %al,%al
    7f09:	74 15                	je     7f20 <fwp_drop2+0x120>
    7f0b:	3c 01                	cmp    $0x1,%al
    7f0d:	74 59                	je     7f68 <fwp_drop2+0x168>
    7f0f:	3c ff                	cmp    $0xff,%al
    7f11:	0f 84 ef 00 00 00    	je     8006 <fwp_drop2+0x206>
    7f17:	83 e8 01             	sub    $0x1,%eax
    7f1a:	88 01                	mov    %al,(%rcx)
    7f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7f20:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7f24:	48 89 d7             	mov    %rdx,%rdi
    7f27:	48 89 0c 24          	mov    %rcx,(%rsp)
    7f2b:	e8 d0 ea ff ff       	call   6a00 <fwp_rc_free_arr>
    7f30:	4c 8d 05 49 b8 01 00 	lea    0x1b849(%rip),%r8        # 23780 <fwp_heap>
    7f37:	48 8b 04 24          	mov    (%rsp),%rax
    7f3b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7f42:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7f49:	48 c1 e2 10          	shl    $0x10,%rdx
    7f4d:	48 39 d0             	cmp    %rdx,%rax
    7f50:	0f 83 35 ff ff ff    	jae    7e8b <fwp_drop2+0x8b>
    7f56:	48 8b 14 24          	mov    (%rsp),%rdx
    7f5a:	e9 cd fe ff ff       	jmp    7e2c <fwp_drop2+0x2c>
    7f5f:	90                   	nop
    7f60:	c3                   	ret
    7f61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7f68:	48 89 14 24          	mov    %rdx,(%rsp)
    7f6c:	e8 8f ea ff ff       	call   6a00 <fwp_rc_free_arr>
    7f71:	48 8b 14 24          	mov    (%rsp),%rdx
    7f75:	eb a9                	jmp    7f20 <fwp_drop2+0x120>
    7f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f7e:	00 00 
    7f80:	66 85 c0             	test   %ax,%ax
    7f83:	75 9b                	jne    7f20 <fwp_drop2+0x120>
    7f85:	e9 7a ff ff ff       	jmp    7f04 <fwp_drop2+0x104>
    7f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f90:	48 89 c8             	mov    %rcx,%rax
    7f93:	48 c1 e8 11          	shr    $0x11,%rax
    7f97:	48 31 c8             	xor    %rcx,%rax
    7f9a:	48 89 c2             	mov    %rax,%rdx
    7f9d:	48 c1 ea 09          	shr    $0x9,%rdx
    7fa1:	48 31 d0             	xor    %rdx,%rax
    7fa4:	0f b6 d0             	movzbl %al,%edx
    7fa7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7fae:	00 
    7faf:	48 85 c0             	test   %rax,%rax
    7fb2:	75 19                	jne    7fcd <fwp_drop2+0x1cd>
    7fb4:	e9 d3 00 00 00       	jmp    808c <fwp_drop2+0x28c>
    7fb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7fc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7fc4:	48 85 c0             	test   %rax,%rax
    7fc7:	0f 84 bf 00 00 00    	je     808c <fwp_drop2+0x28c>
    7fcd:	48 89 c2             	mov    %rax,%rdx
    7fd0:	48 39 08             	cmp    %rcx,(%rax)
    7fd3:	75 eb                	jne    7fc0 <fwp_drop2+0x1c0>
    7fd5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7fd9:	48 83 ea 01          	sub    $0x1,%rdx
    7fdd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7fe1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7fe8:	0f 85 9d fe ff ff    	jne    7e8b <fwp_drop2+0x8b>
    7fee:	48 89 cf             	mov    %rcx,%rdi
    7ff1:	48 89 0c 24          	mov    %rcx,(%rsp)
    7ff5:	e8 16 d3 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ffa:	48 8b 0c 24          	mov    (%rsp),%rcx
    7ffe:	c6 01 fe             	movb   $0xfe,(%rcx)
    8001:	e9 85 fe ff ff       	jmp    7e8b <fwp_drop2+0x8b>
    8006:	48 89 ce             	mov    %rcx,%rsi
    8009:	48 c1 ee 11          	shr    $0x11,%rsi
    800d:	48 31 ce             	xor    %rcx,%rsi
    8010:	48 89 f0             	mov    %rsi,%rax
    8013:	48 c1 e8 09          	shr    $0x9,%rax
    8017:	48 31 c6             	xor    %rax,%rsi
    801a:	40 0f b6 f6          	movzbl %sil,%esi
    801e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    8025:	00 
    8026:	48 85 c0             	test   %rax,%rax
    8029:	75 1e                	jne    8049 <fwp_drop2+0x249>
    802b:	eb 5f                	jmp    808c <fwp_drop2+0x28c>
    802d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8034:	00 
    8035:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    803c:	00 00 00 00 
    8040:	48 8b 46 10          	mov    0x10(%rsi),%rax
    8044:	48 85 c0             	test   %rax,%rax
    8047:	74 43                	je     808c <fwp_drop2+0x28c>
    8049:	48 89 c6             	mov    %rax,%rsi
    804c:	48 39 08             	cmp    %rcx,(%rax)
    804f:	75 ef                	jne    8040 <fwp_drop2+0x240>
    8051:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8055:	48 83 ee 01          	sub    $0x1,%rsi
    8059:	48 89 70 08          	mov    %rsi,0x8(%rax)
    805d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    8064:	0f 85 b6 fe ff ff    	jne    7f20 <fwp_drop2+0x120>
    806a:	48 89 cf             	mov    %rcx,%rdi
    806d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8072:	48 89 0c 24          	mov    %rcx,(%rsp)
    8076:	e8 95 d2 ff ff       	call   5310 <fwp_rc_forget_slot>
    807b:	48 8b 0c 24          	mov    (%rsp),%rcx
    807f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8084:	c6 01 fe             	movb   $0xfe,(%rcx)
    8087:	e9 94 fe ff ff       	jmp    7f20 <fwp_drop2+0x120>
    808c:	48 8d 3d 05 77 00 00 	lea    0x7705(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    8093:	e8 08 c1 ff ff       	call   41a0 <fwp_trap>
    8098:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    809f:	00 

00000000000080a0 <fwp_arg_drop23>:
    80a0:	f3 0f 1e fa          	endbr64
    80a4:	85 f6                	test   %esi,%esi
    80a6:	75 04                	jne    80ac <fwp_arg_drop23+0xc>
    80a8:	85 d2                	test   %edx,%edx
    80aa:	75 04                	jne    80b0 <fwp_arg_drop23+0x10>
    80ac:	c3                   	ret
    80ad:	0f 1f 00             	nopl   (%rax)
    80b0:	48 8b 3f             	mov    (%rdi),%rdi
    80b3:	e9 48 fd ff ff       	jmp    7e00 <fwp_drop2>
    80b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    80bf:	00 

00000000000080c0 <fwp_caps23>:
    80c0:	f3 0f 1e fa          	endbr64
    80c4:	48 83 ec 18          	sub    $0x18,%rsp
    80c8:	8b 57 04             	mov    0x4(%rdi),%edx
    80cb:	48 89 f8             	mov    %rdi,%rax
    80ce:	85 d2                	test   %edx,%edx
    80d0:	0f 84 9a 00 00 00    	je     8170 <fwp_caps23+0xb0>
    80d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    80da:	85 f6                	test   %esi,%esi
    80dc:	0f 85 9e 00 00 00    	jne    8180 <fwp_caps23+0xc0>
    80e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    80e7:	e8 14 fd ff ff       	call   7e00 <fwp_drop2>
    80ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    80f1:	48 8b 0d 60 ca 01 00 	mov    0x1ca60(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    80f8:	48 89 c2             	mov    %rax,%rdx
    80fb:	48 2b 15 2e ca 01 00 	sub    0x1ca2e(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    8102:	48 c1 e1 10          	shl    $0x10,%rcx
    8106:	48 39 ca             	cmp    %rcx,%rdx
    8109:	73 6d                	jae    8178 <fwp_caps23+0xb8>
    810b:	48 89 d1             	mov    %rdx,%rcx
    810e:	48 c1 e9 10          	shr    $0x10,%rcx
    8112:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8116:	48 8b 0d 5b ca 01 00 	mov    0x1ca5b(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    811d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8121:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8125:	48 85 f6             	test   %rsi,%rsi
    8128:	74 4e                	je     8178 <fwp_caps23+0xb8>
    812a:	0f b6 39             	movzbl (%rcx),%edi
    812d:	40 80 ff 02          	cmp    $0x2,%dil
    8131:	0f 84 b9 00 00 00    	je     81f0 <fwp_caps23+0x130>
    8137:	40 80 ff 01          	cmp    $0x1,%dil
    813b:	75 3b                	jne    8178 <fwp_caps23+0xb8>
    813d:	8b 79 18             	mov    0x18(%rcx),%edi
    8140:	0f b7 d2             	movzwl %dx,%edx
    8143:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8146:	48 0f af d7          	imul   %rdi,%rdx
    814a:	48 c1 ea 20          	shr    $0x20,%rdx
    814e:	48 39 ca             	cmp    %rcx,%rdx
    8151:	73 25                	jae    8178 <fwp_caps23+0xb8>
    8153:	48 01 d6             	add    %rdx,%rsi
    8156:	80 3e 01             	cmpb   $0x1,(%rsi)
    8159:	75 1d                	jne    8178 <fwp_caps23+0xb8>
    815b:	48 89 c7             	mov    %rax,%rdi
    815e:	48 83 c4 18          	add    $0x18,%rsp
    8162:	e9 e9 d3 ff ff       	jmp    5550 <fwp_mem_free>
    8167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    816e:	00 00 
    8170:	85 f6                	test   %esi,%esi
    8172:	0f 84 79 ff ff ff    	je     80f1 <fwp_caps23+0x31>
    8178:	48 83 c4 18          	add    $0x18,%rsp
    817c:	c3                   	ret
    817d:	0f 1f 00             	nopl   (%rax)
    8180:	48 8b 05 d1 c9 01 00 	mov    0x1c9d1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    8187:	48 2b 3d a2 c9 01 00 	sub    0x1c9a2(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    818e:	48 c1 e0 10          	shl    $0x10,%rax
    8192:	48 39 c7             	cmp    %rax,%rdi
    8195:	73 e1                	jae    8178 <fwp_caps23+0xb8>
    8197:	48 89 f8             	mov    %rdi,%rax
    819a:	48 c1 e8 10          	shr    $0x10,%rax
    819e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    81a2:	48 8b 05 cf c9 01 00 	mov    0x1c9cf(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    81a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    81ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    81b1:	48 85 c0             	test   %rax,%rax
    81b4:	74 c2                	je     8178 <fwp_caps23+0xb8>
    81b6:	0f b6 0a             	movzbl (%rdx),%ecx
    81b9:	80 f9 02             	cmp    $0x2,%cl
    81bc:	74 42                	je     8200 <fwp_caps23+0x140>
    81be:	80 f9 01             	cmp    $0x1,%cl
    81c1:	75 b5                	jne    8178 <fwp_caps23+0xb8>
    81c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81c6:	0f b7 ff             	movzwl %di,%edi
    81c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81cc:	48 0f af f9          	imul   %rcx,%rdi
    81d0:	48 c1 ef 20          	shr    $0x20,%rdi
    81d4:	48 39 d7             	cmp    %rdx,%rdi
    81d7:	73 9f                	jae    8178 <fwp_caps23+0xb8>
    81d9:	48 01 f8             	add    %rdi,%rax
    81dc:	0f b6 10             	movzbl (%rax),%edx
    81df:	84 d2                	test   %dl,%dl
    81e1:	74 95                	je     8178 <fwp_caps23+0xb8>
    81e3:	80 fa fd             	cmp    $0xfd,%dl
    81e6:	77 23                	ja     820b <fwp_caps23+0x14b>
    81e8:	83 c2 01             	add    $0x1,%edx
    81eb:	88 10                	mov    %dl,(%rax)
    81ed:	eb 89                	jmp    8178 <fwp_caps23+0xb8>
    81ef:	90                   	nop
    81f0:	66 85 d2             	test   %dx,%dx
    81f3:	0f 85 7f ff ff ff    	jne    8178 <fwp_caps23+0xb8>
    81f9:	e9 58 ff ff ff       	jmp    8156 <fwp_caps23+0x96>
    81fe:	66 90                	xchg   %ax,%ax
    8200:	66 85 ff             	test   %di,%di
    8203:	0f 85 6f ff ff ff    	jne    8178 <fwp_caps23+0xb8>
    8209:	eb d1                	jmp    81dc <fwp_caps23+0x11c>
    820b:	48 89 c7             	mov    %rax,%rdi
    820e:	48 83 c4 18          	add    $0x18,%rsp
    8212:	e9 d9 cf ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    8217:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    821e:	00 00 

0000000000008220 <f23>:
    8220:	41 57                	push   %r15
    8222:	41 56                	push   %r14
    8224:	41 55                	push   %r13
    8226:	41 54                	push   %r12
    8228:	55                   	push   %rbp
    8229:	53                   	push   %rbx
    822a:	48 83 ec 38          	sub    $0x38,%rsp
    822e:	48 8b 15 23 c9 01 00 	mov    0x1c923(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8235:	48 8b 0d f4 c8 01 00 	mov    0x1c8f4(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    823c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    8243:	00 00 
    8245:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    824a:	49 89 fd             	mov    %rdi,%r13
    824d:	48 c1 e2 10          	shl    $0x10,%rdx
    8251:	48 85 ff             	test   %rdi,%rdi
    8254:	0f 84 fc 02 00 00    	je     8556 <f23+0x336>
    825a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    825e:	48 89 d8             	mov    %rbx,%rax
    8261:	48 29 c8             	sub    %rcx,%rax
    8264:	48 39 d0             	cmp    %rdx,%rax
    8267:	0f 83 b3 03 00 00    	jae    8620 <f23+0x400>
    826d:	48 89 c2             	mov    %rax,%rdx
    8270:	48 c1 ea 10          	shr    $0x10,%rdx
    8274:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8278:	48 8b 15 f9 c8 01 00 	mov    0x1c8f9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    827f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8283:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8287:	48 85 ff             	test   %rdi,%rdi
    828a:	0f 84 90 03 00 00    	je     8620 <f23+0x400>
    8290:	0f b6 0a             	movzbl (%rdx),%ecx
    8293:	80 f9 02             	cmp    $0x2,%cl
    8296:	0f 84 94 02 00 00    	je     8530 <f23+0x310>
    829c:	80 f9 01             	cmp    $0x1,%cl
    829f:	75 24                	jne    82c5 <f23+0xa5>
    82a1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82a4:	0f b7 c0             	movzwl %ax,%eax
    82a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82aa:	48 0f af c1          	imul   %rcx,%rax
    82ae:	48 c1 e8 20          	shr    $0x20,%rax
    82b2:	48 39 d0             	cmp    %rdx,%rax
    82b5:	73 0e                	jae    82c5 <f23+0xa5>
    82b7:	48 01 c7             	add    %rax,%rdi
    82ba:	0f b6 07             	movzbl (%rdi),%eax
    82bd:	84 c0                	test   %al,%al
    82bf:	0f 85 0b 03 00 00    	jne    85d0 <f23+0x3b0>
    82c5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    82ca:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    82ce:	ba 01 00 00 00       	mov    $0x1,%edx
    82d3:	48 85 db             	test   %rbx,%rbx
    82d6:	74 15                	je     82ed <f23+0xcd>
    82d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82df:	00 
    82e0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    82e4:	48 83 c2 01          	add    $0x1,%rdx
    82e8:	48 85 db             	test   %rbx,%rbx
    82eb:	75 f3                	jne    82e0 <f23+0xc0>
    82ed:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82f2:	48 85 c0             	test   %rax,%rax
    82f5:	0f 84 55 03 00 00    	je     8650 <f23+0x430>
    82fb:	31 db                	xor    %ebx,%ebx
    82fd:	0f 1f 00             	nopl   (%rax)
    8300:	48 8b 40 10          	mov    0x10(%rax),%rax
    8304:	48 83 c3 01          	add    $0x1,%rbx
    8308:	48 85 c0             	test   %rax,%rax
    830b:	75 f3                	jne    8300 <f23+0xe0>
    830d:	48 39 d3             	cmp    %rdx,%rbx
    8310:	48 0f 47 da          	cmova  %rdx,%rbx
    8314:	48 89 d8             	mov    %rbx,%rax
    8317:	48 c1 e8 3c          	shr    $0x3c,%rax
    831b:	0f 85 d3 03 00 00    	jne    86f4 <f23+0x4d4>
    8321:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8325:	be 02 00 00 00       	mov    $0x2,%esi
    832a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8331:	00 
    8332:	e8 19 d7 ff ff       	call   5a50 <fwp_heap_alloc>
    8337:	48 89 28             	mov    %rbp,(%rax)
    833a:	48 8b 15 17 c8 01 00 	mov    0x1c817(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8341:	49 89 c4             	mov    %rax,%r12
    8344:	48 2b 05 e5 c7 01 00 	sub    0x1c7e5(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    834b:	48 c1 e2 10          	shl    $0x10,%rdx
    834f:	48 39 d0             	cmp    %rdx,%rax
    8352:	73 57                	jae    83ab <f23+0x18b>
    8354:	48 89 c2             	mov    %rax,%rdx
    8357:	48 c1 ea 10          	shr    $0x10,%rdx
    835b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    835f:	48 8b 15 12 c8 01 00 	mov    0x1c812(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8366:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    836a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    836e:	48 85 ed             	test   %rbp,%rbp
    8371:	74 38                	je     83ab <f23+0x18b>
    8373:	0f b6 0a             	movzbl (%rdx),%ecx
    8376:	80 f9 02             	cmp    $0x2,%cl
    8379:	0f 84 91 02 00 00    	je     8610 <f23+0x3f0>
    837f:	80 f9 01             	cmp    $0x1,%cl
    8382:	75 27                	jne    83ab <f23+0x18b>
    8384:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8387:	0f b7 c0             	movzwl %ax,%eax
    838a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    838d:	48 0f af c1          	imul   %rcx,%rax
    8391:	48 c1 e8 20          	shr    $0x20,%rax
    8395:	48 39 d0             	cmp    %rdx,%rax
    8398:	73 11                	jae    83ab <f23+0x18b>
    839a:	48 01 c5             	add    %rax,%rbp
    839d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    83a1:	0f 84 19 03 00 00    	je     86c0 <f23+0x4a0>
    83a7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    83ab:	48 85 db             	test   %rbx,%rbx
    83ae:	74 5d                	je     840d <f23+0x1ed>
    83b0:	48 c1 e3 04          	shl    $0x4,%rbx
    83b4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    83b9:	4c 89 e5             	mov    %r12,%rbp
    83bc:	4d 89 ee             	mov    %r13,%r14
    83bf:	4c 01 e3             	add    %r12,%rbx
    83c2:	0f 1f 00             	nopl   (%rax)
    83c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83cc:	00 00 00 00 
    83d0:	49 8b 46 08          	mov    0x8(%r14),%rax
    83d4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    83d8:	48 83 c5 10          	add    $0x10,%rbp
    83dc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    83e1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    83e5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    83e9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    83ee:	e8 ad dd ff ff       	call   61a0 <w107>
    83f3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    83f8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    83fc:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8400:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8404:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8408:	48 39 eb             	cmp    %rbp,%rbx
    840b:	75 c3                	jne    83d0 <f23+0x1b0>
    840d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8412:	31 db                	xor    %ebx,%ebx
    8414:	e8 e7 f9 ff ff       	call   7e00 <fwp_drop2>
    8419:	4c 89 ef             	mov    %r13,%rdi
    841c:	e8 df f9 ff ff       	call   7e00 <fwp_drop2>
    8421:	4d 8b 2c 24          	mov    (%r12),%r13
    8425:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8429:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8430:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8437:	4d 85 ed             	test   %r13,%r13
    843a:	74 32                	je     846e <f23+0x24e>
    843c:	0f 1f 40 00          	nopl   0x0(%rax)
    8440:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8447:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    844c:	48 83 c3 02          	add    $0x2,%rbx
    8450:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8456:	e8 c5 db ff ff       	call   6020 <f128.constprop.0>
    845b:	4c 39 eb             	cmp    %r13,%rbx
    845e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8464:	48 89 c7             	mov    %rax,%rdi
    8467:	72 d7                	jb     8440 <f23+0x220>
    8469:	66 49 0f 7e c5       	movq   %xmm0,%r13
    846e:	4c 89 e7             	mov    %r12,%rdi
    8471:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8476:	e8 85 f4 ff ff       	call   7900 <fwp_drop4>
    847b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8480:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8485:	31 ff                	xor    %edi,%edi
    8487:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    848c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8491:	e8 0a e3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    8496:	48 8b 15 bb c6 01 00 	mov    0x1c6bb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    849d:	48 89 c5             	mov    %rax,%rbp
    84a0:	48 2b 05 89 c6 01 00 	sub    0x1c689(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    84a7:	48 c1 e2 10          	shl    $0x10,%rdx
    84ab:	48 39 d0             	cmp    %rdx,%rax
    84ae:	73 55                	jae    8505 <f23+0x2e5>
    84b0:	48 89 c2             	mov    %rax,%rdx
    84b3:	48 c1 ea 10          	shr    $0x10,%rdx
    84b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84bb:	48 8b 15 b6 c6 01 00 	mov    0x1c6b6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    84c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84c6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    84ca:	48 85 db             	test   %rbx,%rbx
    84cd:	74 36                	je     8505 <f23+0x2e5>
    84cf:	0f b6 0a             	movzbl (%rdx),%ecx
    84d2:	80 f9 02             	cmp    $0x2,%cl
    84d5:	0f 84 1d 01 00 00    	je     85f8 <f23+0x3d8>
    84db:	80 f9 01             	cmp    $0x1,%cl
    84de:	75 25                	jne    8505 <f23+0x2e5>
    84e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84e3:	0f b7 c0             	movzwl %ax,%eax
    84e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84e9:	48 0f af c1          	imul   %rcx,%rax
    84ed:	48 c1 e8 20          	shr    $0x20,%rax
    84f1:	48 39 d0             	cmp    %rdx,%rax
    84f4:	73 0f                	jae    8505 <f23+0x2e5>
    84f6:	48 01 c3             	add    %rax,%rbx
    84f9:	80 3b ff             	cmpb   $0xff,(%rbx)
    84fc:	0f 84 b1 01 00 00    	je     86b3 <f23+0x493>
    8502:	c6 03 01             	movb   $0x1,(%rbx)
    8505:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    850a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8511:	00 00 
    8513:	0f 85 d6 01 00 00    	jne    86ef <f23+0x4cf>
    8519:	48 83 c4 38          	add    $0x38,%rsp
    851d:	48 89 e8             	mov    %rbp,%rax
    8520:	5b                   	pop    %rbx
    8521:	5d                   	pop    %rbp
    8522:	41 5c                	pop    %r12
    8524:	41 5d                	pop    %r13
    8526:	41 5e                	pop    %r14
    8528:	41 5f                	pop    %r15
    852a:	c3                   	ret
    852b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8530:	66 85 c0             	test   %ax,%ax
    8533:	0f 85 8c fd ff ff    	jne    82c5 <f23+0xa5>
    8539:	0f b6 07             	movzbl (%rdi),%eax
    853c:	84 c0                	test   %al,%al
    853e:	0f 84 81 fd ff ff    	je     82c5 <f23+0xa5>
    8544:	3c fd                	cmp    $0xfd,%al
    8546:	0f 87 99 01 00 00    	ja     86e5 <f23+0x4c5>
    854c:	83 c0 01             	add    $0x1,%eax
    854f:	88 07                	mov    %al,(%rdi)
    8551:	e9 6f fd ff ff       	jmp    82c5 <f23+0xa5>
    8556:	48 f7 d9             	neg    %rcx
    8559:	48 39 d1             	cmp    %rdx,%rcx
    855c:	0f 83 ee 00 00 00    	jae    8650 <f23+0x430>
    8562:	48 89 c8             	mov    %rcx,%rax
    8565:	48 c1 e8 10          	shr    $0x10,%rax
    8569:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    856d:	48 8b 05 04 c6 01 00 	mov    0x1c604(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8574:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8578:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    857c:	48 85 ff             	test   %rdi,%rdi
    857f:	0f 84 cb 00 00 00    	je     8650 <f23+0x430>
    8585:	0f b6 02             	movzbl (%rdx),%eax
    8588:	3c 02                	cmp    $0x2,%al
    858a:	0f 84 9a 00 00 00    	je     862a <f23+0x40a>
    8590:	3c 01                	cmp    $0x1,%al
    8592:	0f 85 b8 00 00 00    	jne    8650 <f23+0x430>
    8598:	0f b7 c1             	movzwl %cx,%eax
    859b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    859e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85a1:	48 0f af c1          	imul   %rcx,%rax
    85a5:	48 c1 e8 20          	shr    $0x20,%rax
    85a9:	48 39 d0             	cmp    %rdx,%rax
    85ac:	0f 83 9e 00 00 00    	jae    8650 <f23+0x430>
    85b2:	48 01 c7             	add    %rax,%rdi
    85b5:	0f b6 07             	movzbl (%rdi),%eax
    85b8:	84 c0                	test   %al,%al
    85ba:	0f 84 90 00 00 00    	je     8650 <f23+0x430>
    85c0:	31 db                	xor    %ebx,%ebx
    85c2:	0f 1f 00             	nopl   (%rax)
    85c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85cc:	00 00 00 00 
    85d0:	3c fd                	cmp    $0xfd,%al
    85d2:	0f 87 f5 00 00 00    	ja     86cd <f23+0x4ad>
    85d8:	83 c0 01             	add    $0x1,%eax
    85db:	88 07                	mov    %al,(%rdi)
    85dd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    85e2:	31 d2                	xor    %edx,%edx
    85e4:	4d 85 ed             	test   %r13,%r13
    85e7:	0f 85 dd fc ff ff    	jne    82ca <f23+0xaa>
    85ed:	e9 fb fc ff ff       	jmp    82ed <f23+0xcd>
    85f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85f8:	66 85 c0             	test   %ax,%ax
    85fb:	0f 85 04 ff ff ff    	jne    8505 <f23+0x2e5>
    8601:	e9 f3 fe ff ff       	jmp    84f9 <f23+0x2d9>
    8606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    860d:	00 00 00 
    8610:	66 85 c0             	test   %ax,%ax
    8613:	0f 85 92 fd ff ff    	jne    83ab <f23+0x18b>
    8619:	e9 7f fd ff ff       	jmp    839d <f23+0x17d>
    861e:	66 90                	xchg   %ax,%ax
    8620:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8625:	e9 a4 fc ff ff       	jmp    82ce <f23+0xae>
    862a:	66 85 c9             	test   %cx,%cx
    862d:	75 21                	jne    8650 <f23+0x430>
    862f:	0f b6 07             	movzbl (%rdi),%eax
    8632:	84 c0                	test   %al,%al
    8634:	74 1a                	je     8650 <f23+0x430>
    8636:	3c fd                	cmp    $0xfd,%al
    8638:	0f 87 c2 00 00 00    	ja     8700 <f23+0x4e0>
    863e:	83 c0 01             	add    $0x1,%eax
    8641:	88 07                	mov    %al,(%rdi)
    8643:	66 90                	xchg   %ax,%ax
    8645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    864c:	00 00 00 00 
    8650:	be 02 00 00 00       	mov    $0x2,%esi
    8655:	bf 08 00 00 00       	mov    $0x8,%edi
    865a:	e8 f1 d3 ff ff       	call   5a50 <fwp_heap_alloc>
    865f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8666:	48 8b 15 eb c4 01 00 	mov    0x1c4eb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    866d:	49 89 c4             	mov    %rax,%r12
    8670:	48 2b 05 b9 c4 01 00 	sub    0x1c4b9(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8677:	48 c1 e2 10          	shl    $0x10,%rdx
    867b:	48 39 d0             	cmp    %rdx,%rax
    867e:	73 57                	jae    86d7 <f23+0x4b7>
    8680:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8687:	00 00 
    8689:	48 89 c2             	mov    %rax,%rdx
    868c:	48 c1 ea 10          	shr    $0x10,%rdx
    8690:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8694:	48 8b 15 dd c4 01 00 	mov    0x1c4dd(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    869b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    869f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    86a3:	48 85 ed             	test   %rbp,%rbp
    86a6:	0f 84 61 fd ff ff    	je     840d <f23+0x1ed>
    86ac:	31 db                	xor    %ebx,%ebx
    86ae:	e9 c0 fc ff ff       	jmp    8373 <f23+0x153>
    86b3:	48 89 df             	mov    %rbx,%rdi
    86b6:	e8 55 cc ff ff       	call   5310 <fwp_rc_forget_slot>
    86bb:	e9 42 fe ff ff       	jmp    8502 <f23+0x2e2>
    86c0:	48 89 ef             	mov    %rbp,%rdi
    86c3:	e8 48 cc ff ff       	call   5310 <fwp_rc_forget_slot>
    86c8:	e9 da fc ff ff       	jmp    83a7 <f23+0x187>
    86cd:	e8 1e cb ff ff       	call   51f0 <fwp_rc_wide_dup>
    86d2:	e9 06 ff ff ff       	jmp    85dd <f23+0x3bd>
    86d7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    86de:	00 00 
    86e0:	e9 28 fd ff ff       	jmp    840d <f23+0x1ed>
    86e5:	e8 06 cb ff ff       	call   51f0 <fwp_rc_wide_dup>
    86ea:	e9 d6 fb ff ff       	jmp    82c5 <f23+0xa5>
    86ef:	e8 6c ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86f4:	48 8d 3d 32 6a 00 00 	lea    0x6a32(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    86fb:	e8 a0 ba ff ff       	call   41a0 <fwp_trap>
    8700:	e8 eb ca ff ff       	call   51f0 <fwp_rc_wide_dup>
    8705:	e9 46 ff ff ff       	jmp    8650 <f23+0x430>
    870a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008710 <fwp_owned_entry23>:
    8710:	f3 0f 1e fa          	endbr64
    8714:	48 8b 3f             	mov    (%rdi),%rdi
    8717:	e9 04 fb ff ff       	jmp    8220 <f23>
    871c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008720 <e23>:
    8720:	f3 0f 1e fa          	endbr64
    8724:	53                   	push   %rbx
    8725:	48 8b 1f             	mov    (%rdi),%rbx
    8728:	48 89 df             	mov    %rbx,%rdi
    872b:	e8 a0 e1 ff ff       	call   68d0 <fwp_rc_share>
    8730:	48 89 df             	mov    %rbx,%rdi
    8733:	e8 e8 fa ff ff       	call   8220 <f23>
    8738:	48 89 c3             	mov    %rax,%rbx
    873b:	48 89 c7             	mov    %rax,%rdi
    873e:	e8 8d e1 ff ff       	call   68d0 <fwp_rc_share>
    8743:	48 89 d8             	mov    %rbx,%rax
    8746:	5b                   	pop    %rbx
    8747:	c3                   	ret
    8748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    874f:	00 

0000000000008750 <f12>:
    8750:	41 57                	push   %r15
    8752:	41 56                	push   %r14
    8754:	41 55                	push   %r13
    8756:	41 54                	push   %r12
    8758:	4c 8d 25 c1 eb ff ff 	lea    -0x143f(%rip),%r12        # 7320 <fwp_tape_scope_release>
    875f:	55                   	push   %rbp
    8760:	53                   	push   %rbx
    8761:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8768:	48 8b 05 a9 cc 01 00 	mov    0x1cca9(%rip),%rax        # 25418 <fwp_cleanups>
    876f:	48 8b 15 e2 c3 01 00 	mov    0x1c3e2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8776:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    877d:	00 00 
    877f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8786:	00 
    8787:	48 89 fd             	mov    %rdi,%rbp
    878a:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    8791:	ff 
    8792:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    8797:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    879c:	48 c1 e2 10          	shl    $0x10,%rdx
    87a0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    87a5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    87aa:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    87af:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    87b4:	48 89 05 5d cc 01 00 	mov    %rax,0x1cc5d(%rip)        # 25418 <fwp_cleanups>
    87bb:	48 8d 05 4e a8 00 00 	lea    0xa84e(%rip),%rax        # 13010 <fc23>
    87c2:	48 2b 05 67 c3 01 00 	sub    0x1c367(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    87c9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    87ce:	48 39 d0             	cmp    %rdx,%rax
    87d1:	73 5d                	jae    8830 <f12+0xe0>
    87d3:	48 89 c2             	mov    %rax,%rdx
    87d6:	48 c1 ea 10          	shr    $0x10,%rdx
    87da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87de:	48 8b 15 93 c3 01 00 	mov    0x1c393(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    87e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87e9:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    87ed:	48 85 ff             	test   %rdi,%rdi
    87f0:	74 3e                	je     8830 <f12+0xe0>
    87f2:	0f b6 0a             	movzbl (%rdx),%ecx
    87f5:	80 f9 02             	cmp    $0x2,%cl
    87f8:	0f 84 e2 0e 00 00    	je     96e0 <f12+0xf90>
    87fe:	80 f9 01             	cmp    $0x1,%cl
    8801:	75 2d                	jne    8830 <f12+0xe0>
    8803:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8806:	0f b7 c0             	movzwl %ax,%eax
    8809:	8b 52 1c             	mov    0x1c(%rdx),%edx
    880c:	48 0f af c1          	imul   %rcx,%rax
    8810:	48 c1 e8 20          	shr    $0x20,%rax
    8814:	48 39 d0             	cmp    %rdx,%rax
    8817:	73 17                	jae    8830 <f12+0xe0>
    8819:	48 01 c7             	add    %rax,%rdi
    881c:	0f b6 07             	movzbl (%rdi),%eax
    881f:	84 c0                	test   %al,%al
    8821:	74 0d                	je     8830 <f12+0xe0>
    8823:	3c fd                	cmp    $0xfd,%al
    8825:	0f 87 af 10 00 00    	ja     98da <f12+0x118a>
    882b:	83 c0 01             	add    $0x1,%eax
    882e:	88 07                	mov    %al,(%rdi)
    8830:	48 8d 3d d9 a7 00 00 	lea    0xa7d9(%rip),%rdi        # 13010 <fc23>
    8837:	e8 b4 e7 ff ff       	call   6ff0 <fwp_closure_drop>
    883c:	48 85 ed             	test   %rbp,%rbp
    883f:	0f 84 fc 0f 00 00    	je     9841 <f12+0x10f1>
    8845:	48 89 e8             	mov    %rbp,%rax
    8848:	31 d2                	xor    %edx,%edx
    884a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8850:	48 8b 40 10          	mov    0x10(%rax),%rax
    8854:	48 83 c2 01          	add    $0x1,%rdx
    8858:	48 85 c0             	test   %rax,%rax
    885b:	75 f3                	jne    8850 <f12+0x100>
    885d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8864:	0f 87 ea 10 00 00    	ja     9954 <f12+0x1204>
    886a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    886f:	8b 35 0b a8 00 00    	mov    0xa80b(%rip),%esi        # 13080 <registered_finish.0>
    8875:	85 f6                	test   %esi,%esi
    8877:	0f 84 33 0e 00 00    	je     96b0 <f12+0xf60>
    887d:	48 8b 1d 74 a8 01 00 	mov    0x1a874(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    8884:	4c 8b 2d 7d a8 01 00 	mov    0x1a87d(%rip),%r13        # 23108 <fwp_ntapes>
    888b:	4c 39 eb             	cmp    %r13,%rbx
    888e:	0f 8d cc 00 00 00    	jge    8960 <f12+0x210>
    8894:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8898:	48 03 05 71 a8 01 00 	add    0x1a871(%rip),%rax        # 23110 <fwp_tapes>
    889f:	90                   	nop
    88a0:	8b 48 04             	mov    0x4(%rax),%ecx
    88a3:	85 c9                	test   %ecx,%ecx
    88a5:	75 0c                	jne    88b3 <f12+0x163>
    88a7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    88ad:	0f 86 ad 00 00 00    	jbe    8960 <f12+0x210>
    88b3:	48 83 c3 01          	add    $0x1,%rbx
    88b7:	48 83 c0 68          	add    $0x68,%rax
    88bb:	4c 39 eb             	cmp    %r13,%rbx
    88be:	75 e0                	jne    88a0 <f12+0x150>
    88c0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    88c7:	0f 8f 06 11 00 00    	jg     99d3 <f12+0x1283>
    88cd:	4c 39 2d 2c a8 01 00 	cmp    %r13,0x1a82c(%rip)        # 23100 <fwp_tapes_cap>
    88d4:	4c 8b 3d 35 a8 01 00 	mov    0x1a835(%rip),%r15        # 23110 <fwp_tapes>
    88db:	75 4a                	jne    8927 <f12+0x1d7>
    88dd:	4d 85 ed             	test   %r13,%r13
    88e0:	0f 84 bd 0f 00 00    	je     98a3 <f12+0x1153>
    88e6:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    88eb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    88f0:	49 39 c6             	cmp    %rax,%r14
    88f3:	4c 0f 4f f0          	cmovg  %rax,%r14
    88f7:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    88fb:	4c 89 ff             	mov    %r15,%rdi
    88fe:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8903:	e8 c8 ac ff ff       	call   35d0 <realloc@plt>
    8908:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    890d:	48 85 c0             	test   %rax,%rax
    8910:	49 89 c7             	mov    %rax,%r15
    8913:	0f 84 80 10 00 00    	je     9999 <f12+0x1249>
    8919:	48 89 05 f0 a7 01 00 	mov    %rax,0x1a7f0(%rip)        # 23110 <fwp_tapes>
    8920:	4c 89 35 d9 a7 01 00 	mov    %r14,0x1a7d9(%rip)        # 23100 <fwp_tapes_cap>
    8927:	49 6b c5 68          	imul   $0x68,%r13,%rax
    892b:	49 83 c5 01          	add    $0x1,%r13
    892f:	4c 01 f8             	add    %r15,%rax
    8932:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8936:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    893d:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8941:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8948:	00 
    8949:	48 29 f8             	sub    %rdi,%rax
    894c:	8d 48 68             	lea    0x68(%rax),%ecx
    894f:	31 c0                	xor    %eax,%eax
    8951:	c1 e9 03             	shr    $0x3,%ecx
    8954:	f3 48 ab             	rep stos %rax,(%rdi)
    8957:	4c 89 2d aa a7 01 00 	mov    %r13,0x1a7aa(%rip)        # 23108 <fwp_ntapes>
    895e:	eb 10                	jmp    8970 <f12+0x220>
    8960:	4c 39 eb             	cmp    %r13,%rbx
    8963:	0f 84 57 ff ff ff    	je     88c0 <f12+0x170>
    8969:	4c 8b 3d a0 a7 01 00 	mov    0x1a7a0(%rip),%r15        # 23110 <fwp_tapes>
    8970:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    8974:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8978:	48 8d 3d 40 67 00 00 	lea    0x6740(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    897f:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8983:	4d 01 fe             	add    %r15,%r14
    8986:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    898d:	00 
    898e:	e8 0d aa ff ff       	call   33a0 <getenv@plt>
    8993:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8998:	48 85 c0             	test   %rax,%rax
    899b:	74 09                	je     89a6 <f12+0x256>
    899d:	80 38 30             	cmpb   $0x30,(%rax)
    89a0:	0f 84 72 06 00 00    	je     9018 <f12+0x8c8>
    89a6:	48 83 3d fa a6 01 00 	cmpq   $0x0,0x1a6fa(%rip)        # 230a8 <fwp_tape_cached_bytes>
    89ad:	00 
    89ae:	0f 85 8c 0d 00 00    	jne    9740 <f12+0xff0>
    89b4:	41 8b 06             	mov    (%r14),%eax
    89b7:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    89bb:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    89c2:	00 
    89c3:	4c 89 2d 2e a7 01 00 	mov    %r13,0x1a72e(%rip)        # 230f8 <fwp_tape_next_slot>
    89ca:	8d 70 01             	lea    0x1(%rax),%esi
    89cd:	48 8b 05 44 ca 01 00 	mov    0x1ca44(%rip),%rax        # 25418 <fwp_cleanups>
    89d4:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    89d9:	41 89 36             	mov    %esi,(%r14)
    89dc:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    89e3:	00 
    89e4:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    89eb:	ff 
    89ec:	48 85 c0             	test   %rax,%rax
    89ef:	75 1b                	jne    8a0c <f12+0x2bc>
    89f1:	e9 d1 0f 00 00       	jmp    99c7 <f12+0x1277>
    89f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    89fd:	00 00 00 
    8a00:	48 8b 00             	mov    (%rax),%rax
    8a03:	48 85 c0             	test   %rax,%rax
    8a06:	0f 84 bb 0f 00 00    	je     99c7 <f12+0x1277>
    8a0c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8a10:	75 ee                	jne    8a00 <f12+0x2b0>
    8a12:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8a16:	89 df                	mov    %ebx,%edi
    8a18:	48 63 01             	movslq (%rcx),%rax
    8a1b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    8a1f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8a23:	85 c0                	test   %eax,%eax
    8a25:	78 09                	js     8a30 <f12+0x2e0>
    8a27:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8a2b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8a30:	89 39                	mov    %edi,(%rcx)
    8a32:	48 89 e8             	mov    %rbp,%rax
    8a35:	31 c9                	xor    %ecx,%ecx
    8a37:	48 85 ed             	test   %rbp,%rbp
    8a3a:	0f 84 08 0b 00 00    	je     9548 <f12+0xdf8>
    8a40:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a44:	48 83 c1 01          	add    $0x1,%rcx
    8a48:	48 85 c0             	test   %rax,%rax
    8a4b:	75 f3                	jne    8a40 <f12+0x2f0>
    8a4d:	48 89 ea             	mov    %rbp,%rdx
    8a50:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8a54:	48 83 c0 01          	add    $0x1,%rax
    8a58:	48 85 d2             	test   %rdx,%rdx
    8a5b:	75 f3                	jne    8a50 <f12+0x300>
    8a5d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8a64:	ff ff 1f 
    8a67:	48 39 c2             	cmp    %rax,%rdx
    8a6a:	0f 82 f0 0e 00 00    	jb     9960 <f12+0x1210>
    8a70:	48 85 c9             	test   %rcx,%rcx
    8a73:	0f 8e cf 0a 00 00    	jle    9548 <f12+0xdf8>
    8a79:	48 39 c1             	cmp    %rax,%rcx
    8a7c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8a80:	49 89 c4             	mov    %rax,%r12
    8a83:	48 c1 e8 3c          	shr    $0x3c,%rax
    8a87:	0f 85 d3 0e 00 00    	jne    9960 <f12+0x1210>
    8a8d:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    8a91:	48 c1 e6 10          	shl    $0x10,%rsi
    8a95:	49 09 f5             	or     %rsi,%r13
    8a98:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8a9f:	00 
    8aa0:	be 02 00 00 00       	mov    $0x2,%esi
    8aa5:	e8 a6 cf ff ff       	call   5a50 <fwp_heap_alloc>
    8aaa:	4c 89 30             	mov    %r14,(%rax)
    8aad:	48 8b 15 a4 c0 01 00 	mov    0x1c0a4(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8ab4:	48 89 c3             	mov    %rax,%rbx
    8ab7:	48 2b 05 72 c0 01 00 	sub    0x1c072(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8abe:	48 c1 e2 10          	shl    $0x10,%rdx
    8ac2:	48 39 d0             	cmp    %rdx,%rax
    8ac5:	0f 83 45 0d 00 00    	jae    9810 <f12+0x10c0>
    8acb:	48 89 c2             	mov    %rax,%rdx
    8ace:	48 c1 ea 10          	shr    $0x10,%rdx
    8ad2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ad6:	48 8b 15 9b c0 01 00 	mov    0x1c09b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8add:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8ae1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8ae5:	4d 85 f6             	test   %r14,%r14
    8ae8:	74 38                	je     8b22 <f12+0x3d2>
    8aea:	0f b6 0a             	movzbl (%rdx),%ecx
    8aed:	80 f9 02             	cmp    $0x2,%cl
    8af0:	0f 84 bf 0a 00 00    	je     95b5 <f12+0xe65>
    8af6:	80 f9 01             	cmp    $0x1,%cl
    8af9:	75 27                	jne    8b22 <f12+0x3d2>
    8afb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8afe:	0f b7 c0             	movzwl %ax,%eax
    8b01:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b04:	48 0f af c1          	imul   %rcx,%rax
    8b08:	48 c1 e8 20          	shr    $0x20,%rax
    8b0c:	48 39 d0             	cmp    %rdx,%rax
    8b0f:	73 11                	jae    8b22 <f12+0x3d2>
    8b11:	49 01 c6             	add    %rax,%r14
    8b14:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8b18:	0f 84 95 0d 00 00    	je     98b3 <f12+0x1163>
    8b1e:	41 c6 06 01          	movb   $0x1,(%r14)
    8b22:	4d 85 e4             	test   %r12,%r12
    8b25:	74 4c                	je     8b73 <f12+0x423>
    8b27:	4c 89 e9             	mov    %r13,%rcx
    8b2a:	48 89 ea             	mov    %rbp,%rdx
    8b2d:	31 c0                	xor    %eax,%eax
    8b2f:	48 c1 e1 20          	shl    $0x20,%rcx
    8b33:	66 90                	xchg   %ax,%ax
    8b35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b3c:	00 00 00 00 
    8b40:	48 89 c6             	mov    %rax,%rsi
    8b43:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8b48:	48 01 ce             	add    %rcx,%rsi
    8b4b:	0f 80 ea 0d 00 00    	jo     993b <f12+0x11eb>
    8b51:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8b56:	48 89 c6             	mov    %rax,%rsi
    8b59:	48 83 c0 01          	add    $0x1,%rax
    8b5d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8b61:	48 c1 e6 04          	shl    $0x4,%rsi
    8b65:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8b6a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8b6e:	4c 39 e0             	cmp    %r12,%rax
    8b71:	72 cd                	jb     8b40 <f12+0x3f0>
    8b73:	48 8b 03             	mov    (%rbx),%rax
    8b76:	48 d1 e8             	shr    $1,%rax
    8b79:	0f 85 49 0a 00 00    	jne    95c8 <f12+0xe78>
    8b7f:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8b86:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8b8d:	0f 1f 00             	nopl   (%rax)
    8b90:	48 89 df             	mov    %rbx,%rdi
    8b93:	4d 63 e5             	movslq %r13d,%r12
    8b96:	e8 65 ed ff ff       	call   7900 <fwp_drop4>
    8b9b:	4c 89 e7             	mov    %r12,%rdi
    8b9e:	e8 dd b8 ff ff       	call   4480 <fwp_tape_of>
    8ba3:	48 89 c6             	mov    %rax,%rsi
    8ba6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8bab:	0f 85 33 0e 00 00    	jne    99e4 <f12+0x1294>
    8bb1:	48 89 c7             	mov    %rax,%rdi
    8bb4:	e8 47 b0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8bb9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    8bbd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8bc2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8bc9:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    8bcd:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8bd1:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8bd6:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    8bdb:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8be0:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8be4:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8be8:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8bee:	77 19                	ja     8c09 <f12+0x4b9>
    8bf0:	41 0f b7 c5          	movzwl %r13w,%eax
    8bf4:	83 e8 01             	sub    $0x1,%eax
    8bf7:	48 98                	cltq
    8bf9:	48 3b 05 f8 a4 01 00 	cmp    0x1a4f8(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    8c00:	7d 07                	jge    8c09 <f12+0x4b9>
    8c02:	48 89 05 ef a4 01 00 	mov    %rax,0x1a4ef(%rip)        # 230f8 <fwp_tape_next_slot>
    8c09:	48 8b 05 08 c8 01 00 	mov    0x1c808(%rip),%rax        # 25418 <fwp_cleanups>
    8c10:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8c14:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8c1b:	00 
    8c1c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8c20:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8c27:	00 
    8c28:	48 8d 05 01 c2 ff ff 	lea    -0x3dff(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    8c2f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8c36:	00 
    8c37:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    8c3e:	00 
    8c3f:	48 89 04 24          	mov    %rax,(%rsp)
    8c43:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    8c4a:	00 
    8c4b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    8c52:	00 
    8c53:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8c57:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8c5b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8c62:	00 
    8c63:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8c6a:	00 
    8c6b:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8c72:	00 
    8c73:	48 89 05 9e c7 01 00 	mov    %rax,0x1c79e(%rip)        # 25418 <fwp_cleanups>
    8c7a:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    8c81:	00 
    8c82:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    8c89:	00 
    8c8a:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8c91:	00 
    8c92:	4d 85 ff             	test   %r15,%r15
    8c95:	0f 88 55 0a 00 00    	js     96f0 <f12+0xfa0>
    8c9b:	4c 89 f8             	mov    %r15,%rax
    8c9e:	48 c1 f8 20          	sar    $0x20,%rax
    8ca2:	49 39 c4             	cmp    %rax,%r12
    8ca5:	0f 85 84 0c 00 00    	jne    992f <f12+0x11df>
    8cab:	45 89 fa             	mov    %r15d,%r10d
    8cae:	4d 89 d4             	mov    %r10,%r12
    8cb1:	4c 39 d2             	cmp    %r10,%rdx
    8cb4:	0f 8e 69 0c 00 00    	jle    9923 <f12+0x11d3>
    8cba:	4c 39 d3             	cmp    %r10,%rbx
    8cbd:	0f 8e 9d 09 00 00    	jle    9660 <f12+0xf10>
    8cc3:	4c 39 f3             	cmp    %r14,%rbx
    8cc6:	0f 8e e4 0a 00 00    	jle    97b0 <f12+0x1060>
    8ccc:	49 89 dd             	mov    %rbx,%r13
    8ccf:	4d 85 f6             	test   %r14,%r14
    8cd2:	4d 0f 44 f5          	cmove  %r13,%r14
    8cd6:	eb 1d                	jmp    8cf5 <f12+0x5a5>
    8cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8cdf:	00 
    8ce0:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8ce4:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    8ceb:	4c 89 e8             	mov    %r13,%rax
    8cee:	48 0f 4c c2          	cmovl  %rdx,%rax
    8cf2:	49 89 c6             	mov    %rax,%r14
    8cf5:	4d 39 ee             	cmp    %r13,%r14
    8cf8:	7c e6                	jl     8ce0 <f12+0x590>
    8cfa:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    8cff:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    8d04:	4d 85 c0             	test   %r8,%r8
    8d07:	0f 84 13 0b 00 00    	je     9820 <f12+0x10d0>
    8d0d:	4c 89 c7             	mov    %r8,%rdi
    8d10:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8d17:	00 
    8d18:	e8 b3 a8 ff ff       	call   35d0 <realloc@plt>
    8d1d:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    8d23:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    8d29:	49 89 c0             	mov    %rax,%r8
    8d2c:	4d 85 c0             	test   %r8,%r8
    8d2f:	0f 84 43 0c 00 00    	je     9978 <f12+0x1228>
    8d35:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    8d3c:	00 
    8d3d:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    8d44:	00 
    8d45:	4d 85 ed             	test   %r13,%r13
    8d48:	0f 85 99 0b 00 00    	jne    98e7 <f12+0x1197>
    8d4e:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    8d55:	4d 85 ff             	test   %r15,%r15
    8d58:	78 17                	js     8d71 <f12+0x621>
    8d5a:	45 89 fa             	mov    %r15d,%r10d
    8d5d:	f2 0f 10 05 cb 6d 00 	movsd  0x6dcb(%rip),%xmm0        # fb30 <msg.4+0xb0>
    8d64:	00 
    8d65:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    8d6b:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    8d71:	4c 39 e3             	cmp    %r12,%rbx
    8d74:	0f 8f 8f 00 00 00    	jg     8e09 <f12+0x6b9>
    8d7a:	0f 12 fb             	movhlps %xmm3,%xmm7
    8d7d:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8d82:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    8d87:	49 29 dc             	sub    %rbx,%r12
    8d8a:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    8d8f:	0f 12 fa             	movhlps %xmm2,%xmm7
    8d92:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    8d96:	66 49 0f 7e fb       	movq   %xmm7,%r11
    8d9b:	4a 8d 04 a6          	lea    (%rsi,%r12,4),%rax
    8d9f:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8da3:	48 29 f1             	sub    %rsi,%rcx
    8da6:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    8daa:	4c 29 df             	sub    %r11,%rdi
    8dad:	4d 29 da             	sub    %r11,%r10
    8db0:	eb 0a                	jmp    8dbc <f12+0x66c>
    8db2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8db8:	48 83 e8 04          	sub    $0x4,%rax
    8dbc:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    8dc1:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8dc5:	7a 02                	jp     8dc9 <f12+0x679>
    8dc7:	74 37                	je     8e00 <f12+0x6b0>
    8dc9:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8dcd:	45 85 db             	test   %r11d,%r11d
    8dd0:	78 16                	js     8de8 <f12+0x698>
    8dd2:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8dd8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8ddc:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    8de2:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    8de8:	4c 63 18             	movslq (%rax),%r11
    8deb:	45 85 db             	test   %r11d,%r11d
    8dee:	78 10                	js     8e00 <f12+0x6b0>
    8df0:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8df4:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    8dfa:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    8e00:	48 83 ea 08          	sub    $0x8,%rdx
    8e04:	48 39 c6             	cmp    %rax,%rsi
    8e07:	75 af                	jne    8db8 <f12+0x668>
    8e09:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e10:	ff ff 1f 
    8e13:	48 39 d8             	cmp    %rbx,%rax
    8e16:	0f 82 50 0b 00 00    	jb     996c <f12+0x121c>
    8e1c:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    8e23:	00 
    8e24:	be 02 00 00 00       	mov    $0x2,%esi
    8e29:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    8e2e:	e8 1d cc ff ff       	call   5a50 <fwp_heap_alloc>
    8e33:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    8e38:	48 89 18             	mov    %rbx,(%rax)
    8e3b:	49 89 c4             	mov    %rax,%r12
    8e3e:	31 c0                	xor    %eax,%eax
    8e40:	48 85 db             	test   %rbx,%rbx
    8e43:	74 2d                	je     8e72 <f12+0x722>
    8e45:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e51:	00 00 00 00 
    8e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e5c:	00 00 00 00 
    8e60:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    8e64:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    8e69:	48 83 c0 01          	add    $0x1,%rax
    8e6d:	48 39 c3             	cmp    %rax,%rbx
    8e70:	75 ee                	jne    8e60 <f12+0x710>
    8e72:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    8e79:	00 
    8e7a:	48 8b 3c 24          	mov    (%rsp),%rdi
    8e7e:	4c 89 2d 93 c5 01 00 	mov    %r13,0x1c593(%rip)        # 25418 <fwp_cleanups>
    8e85:	e8 a6 bf ff ff       	call   4e30 <fwp_tape_buffers_release>
    8e8a:	48 8b 15 c7 bc 01 00 	mov    0x1bcc7(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8e91:	4c 89 e0             	mov    %r12,%rax
    8e94:	48 2b 05 95 bc 01 00 	sub    0x1bc95(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8e9b:	48 c1 e2 10          	shl    $0x10,%rdx
    8e9f:	48 39 d0             	cmp    %rdx,%rax
    8ea2:	73 55                	jae    8ef9 <f12+0x7a9>
    8ea4:	48 89 c2             	mov    %rax,%rdx
    8ea7:	48 c1 ea 10          	shr    $0x10,%rdx
    8eab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8eaf:	48 8b 15 c2 bc 01 00 	mov    0x1bcc2(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8eb6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8eba:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8ebe:	48 85 db             	test   %rbx,%rbx
    8ec1:	74 36                	je     8ef9 <f12+0x7a9>
    8ec3:	0f b6 0a             	movzbl (%rdx),%ecx
    8ec6:	80 f9 02             	cmp    $0x2,%cl
    8ec9:	0f 84 51 08 00 00    	je     9720 <f12+0xfd0>
    8ecf:	80 f9 01             	cmp    $0x1,%cl
    8ed2:	75 25                	jne    8ef9 <f12+0x7a9>
    8ed4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ed7:	0f b7 c0             	movzwl %ax,%eax
    8eda:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8edd:	48 0f af c1          	imul   %rcx,%rax
    8ee1:	48 c1 e8 20          	shr    $0x20,%rax
    8ee5:	48 39 d0             	cmp    %rdx,%rax
    8ee8:	73 0f                	jae    8ef9 <f12+0x7a9>
    8eea:	48 01 c3             	add    %rax,%rbx
    8eed:	80 3b ff             	cmpb   $0xff,(%rbx)
    8ef0:	0f 84 ca 09 00 00    	je     98c0 <f12+0x1170>
    8ef6:	c6 03 01             	movb   $0x1,(%rbx)
    8ef9:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    8efe:	0f 85 47 a8 ff ff    	jne    374b <f12.cold>
    8f04:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8f09:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    8f0e:	48 89 05 03 c5 01 00 	mov    %rax,0x1c503(%rip)        # 25418 <fwp_cleanups>
    8f15:	e8 06 e4 ff ff       	call   7320 <fwp_tape_scope_release>
    8f1a:	49 8b 04 24          	mov    (%r12),%rax
    8f1e:	49 89 c6             	mov    %rax,%r14
    8f21:	49 0f ba f6 3f       	btr    $0x3f,%r14
    8f26:	48 85 c0             	test   %rax,%rax
    8f29:	0f 88 51 05 00 00    	js     9480 <f12+0xd30>
    8f2f:	48 8b 15 22 bc 01 00 	mov    0x1bc22(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8f36:	4c 89 e0             	mov    %r12,%rax
    8f39:	48 2b 05 f0 bb 01 00 	sub    0x1bbf0(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8f40:	48 c1 e2 10          	shl    $0x10,%rdx
    8f44:	48 39 d0             	cmp    %rdx,%rax
    8f47:	0f 83 33 05 00 00    	jae    9480 <f12+0xd30>
    8f4d:	48 89 c2             	mov    %rax,%rdx
    8f50:	48 c1 ea 10          	shr    $0x10,%rdx
    8f54:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f58:	48 8b 15 19 bc 01 00 	mov    0x1bc19(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8f5f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f63:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8f67:	48 85 c9             	test   %rcx,%rcx
    8f6a:	0f 84 10 05 00 00    	je     9480 <f12+0xd30>
    8f70:	0f b6 32             	movzbl (%rdx),%esi
    8f73:	40 80 fe 02          	cmp    $0x2,%sil
    8f77:	0f 84 f3 04 00 00    	je     9470 <f12+0xd20>
    8f7d:	40 80 fe 01          	cmp    $0x1,%sil
    8f81:	0f 85 f9 04 00 00    	jne    9480 <f12+0xd30>
    8f87:	8b 72 18             	mov    0x18(%rdx),%esi
    8f8a:	0f b7 c0             	movzwl %ax,%eax
    8f8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f90:	48 0f af c6          	imul   %rsi,%rax
    8f94:	48 c1 e8 20          	shr    $0x20,%rax
    8f98:	48 39 d0             	cmp    %rdx,%rax
    8f9b:	0f 83 df 04 00 00    	jae    9480 <f12+0xd30>
    8fa1:	48 01 c1             	add    %rax,%rcx
    8fa4:	80 39 01             	cmpb   $0x1,(%rcx)
    8fa7:	0f 85 d3 04 00 00    	jne    9480 <f12+0xd30>
    8fad:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    8fb2:	4d 89 e5             	mov    %r12,%r13
    8fb5:	31 ff                	xor    %edi,%edi
    8fb7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    8fbc:	f2 0f 10 0d 84 6b 00 	movsd  0x6b84(%rip),%xmm1        # fb48 <msg.4+0xc8>
    8fc3:	00 
    8fc4:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8fc8:	31 c0                	xor    %eax,%eax
    8fca:	4d 85 f6             	test   %r14,%r14
    8fcd:	75 2f                	jne    8ffe <f12+0x8ae>
    8fcf:	eb 5f                	jmp    9030 <f12+0x8e0>
    8fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fd8:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8fdd:	0f 88 5d 09 00 00    	js     9940 <f12+0x11f0>
    8fe3:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8fe8:	48 83 c0 01          	add    $0x1,%rax
    8fec:	48 83 c2 08          	add    $0x8,%rdx
    8ff0:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8ff4:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8ff9:	49 39 c6             	cmp    %rax,%r14
    8ffc:	74 32                	je     9030 <f12+0x8e0>
    8ffe:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    9003:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9008:	79 ce                	jns    8fd8 <f12+0x888>
    900a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    900f:	eb c7                	jmp    8fd8 <f12+0x888>
    9011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9018:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    901c:	0f 84 92 f9 ff ff    	je     89b4 <f12+0x264>
    9022:	e9 7f f9 ff ff       	jmp    89a6 <f12+0x256>
    9027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    902e:	00 00 
    9030:	e8 cb e8 ff ff       	call   7900 <fwp_drop4>
    9035:	48 89 e8             	mov    %rbp,%rax
    9038:	31 d2                	xor    %edx,%edx
    903a:	48 85 ed             	test   %rbp,%rbp
    903d:	0f 84 07 08 00 00    	je     984a <f12+0x10fa>
    9043:	66 90                	xchg   %ax,%ax
    9045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    904c:	00 00 00 00 
    9050:	48 8b 40 10          	mov    0x10(%rax),%rax
    9054:	48 83 c2 01          	add    $0x1,%rdx
    9058:	48 85 c0             	test   %rax,%rax
    905b:	75 f3                	jne    9050 <f12+0x900>
    905d:	49 8b 45 00          	mov    0x0(%r13),%rax
    9061:	49 89 c7             	mov    %rax,%r15
    9064:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9069:	48 85 c0             	test   %rax,%rax
    906c:	0f 88 60 03 00 00    	js     93d2 <f12+0xc82>
    9072:	48 8b 05 df ba 01 00 	mov    0x1badf(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    9079:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    907e:	48 2b 0d ab ba 01 00 	sub    0x1baab(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    9085:	48 c1 e0 10          	shl    $0x10,%rax
    9089:	48 39 c1             	cmp    %rax,%rcx
    908c:	0f 83 40 03 00 00    	jae    93d2 <f12+0xc82>
    9092:	48 89 c8             	mov    %rcx,%rax
    9095:	48 c1 e8 10          	shr    $0x10,%rax
    9099:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    909d:	48 8b 05 d4 ba 01 00 	mov    0x1bad4(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    90a4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    90a8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    90ac:	48 85 ff             	test   %rdi,%rdi
    90af:	0f 84 1d 03 00 00    	je     93d2 <f12+0xc82>
    90b5:	0f b6 06             	movzbl (%rsi),%eax
    90b8:	3c 02                	cmp    $0x2,%al
    90ba:	0f 84 00 03 00 00    	je     93c0 <f12+0xc70>
    90c0:	3c 01                	cmp    $0x1,%al
    90c2:	0f 85 01 03 00 00    	jne    93c9 <f12+0xc79>
    90c8:	8b 46 18             	mov    0x18(%rsi),%eax
    90cb:	0f b7 c9             	movzwl %cx,%ecx
    90ce:	48 0f af c8          	imul   %rax,%rcx
    90d2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    90d5:	48 c1 e9 20          	shr    $0x20,%rcx
    90d9:	48 39 c1             	cmp    %rax,%rcx
    90dc:	0f 83 e7 02 00 00    	jae    93c9 <f12+0xc79>
    90e2:	48 01 cf             	add    %rcx,%rdi
    90e5:	80 3f 01             	cmpb   $0x1,(%rdi)
    90e8:	0f 85 db 02 00 00    	jne    93c9 <f12+0xc79>
    90ee:	49 39 d7             	cmp    %rdx,%r15
    90f1:	48 89 d0             	mov    %rdx,%rax
    90f4:	49 0f 46 c7          	cmovbe %r15,%rax
    90f8:	48 85 c0             	test   %rax,%rax
    90fb:	0f 84 4b 08 00 00    	je     994c <f12+0x11fc>
    9101:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    9108:	00 
    9109:	4d 8d 75 08          	lea    0x8(%r13),%r14
    910d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    9112:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9119:	00 
    911a:	48 89 e9             	mov    %rbp,%rcx
    911d:	31 d2                	xor    %edx,%edx
    911f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9123:	eb 38                	jmp    915d <f12+0xa0d>
    9125:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    912a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9131:	00 00 00 00 
    9135:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    913c:	00 00 00 00 
    9140:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9145:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    914a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9150:	48 83 c2 08          	add    $0x8,%rdx
    9154:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9158:	49 39 d0             	cmp    %rdx,%r8
    915b:	74 1b                	je     9178 <f12+0xa28>
    915d:	48 89 fe             	mov    %rdi,%rsi
    9160:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    9165:	79 d9                	jns    9140 <f12+0x9f0>
    9167:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    916c:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    9170:	eb ce                	jmp    9140 <f12+0x9f0>
    9172:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9178:	48 85 ed             	test   %rbp,%rbp
    917b:	0f 84 9a 07 00 00    	je     991b <f12+0x11cb>
    9181:	4c 8b 05 d0 b9 01 00 	mov    0x1b9d0(%rip),%r8        # 24b58 <fwp_heap+0x13d8>
    9188:	4c 8b 0d a1 b9 01 00 	mov    0x1b9a1(%rip),%r9        # 24b30 <fwp_heap+0x13b0>
    918f:	48 89 e9             	mov    %rbp,%rcx
    9192:	45 31 ed             	xor    %r13d,%r13d
    9195:	4c 8b 15 dc b9 01 00 	mov    0x1b9dc(%rip),%r10        # 24b78 <fwp_heap+0x13f8>
    919c:	49 c1 e0 10          	shl    $0x10,%r8
    91a0:	eb 1c                	jmp    91be <f12+0xa6e>
    91a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91a8:	49 83 c5 01          	add    $0x1,%r13
    91ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    91b0:	49 39 c5             	cmp    %rax,%r13
    91b3:	0f 83 67 01 00 00    	jae    9320 <f12+0xbd0>
    91b9:	48 85 c9             	test   %rcx,%rcx
    91bc:	74 56                	je     9214 <f12+0xac4>
    91be:	48 89 ca             	mov    %rcx,%rdx
    91c1:	4c 29 ca             	sub    %r9,%rdx
    91c4:	4c 39 c2             	cmp    %r8,%rdx
    91c7:	73 4b                	jae    9214 <f12+0xac4>
    91c9:	48 89 d6             	mov    %rdx,%rsi
    91cc:	48 c1 ee 10          	shr    $0x10,%rsi
    91d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    91d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    91d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    91dc:	48 85 ff             	test   %rdi,%rdi
    91df:	74 33                	je     9214 <f12+0xac4>
    91e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    91e5:	41 80 fb 02          	cmp    $0x2,%r11b
    91e9:	0f 84 19 01 00 00    	je     9308 <f12+0xbb8>
    91ef:	41 80 fb 01          	cmp    $0x1,%r11b
    91f3:	75 1f                	jne    9214 <f12+0xac4>
    91f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    91f9:	0f b7 d2             	movzwl %dx,%edx
    91fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    91ff:	49 0f af d3          	imul   %r11,%rdx
    9203:	48 c1 ea 20          	shr    $0x20,%rdx
    9207:	48 39 f2             	cmp    %rsi,%rdx
    920a:	73 08                	jae    9214 <f12+0xac4>
    920c:	48 01 d7             	add    %rdx,%rdi
    920f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9212:	74 94                	je     91a8 <f12+0xa58>
    9214:	49 39 c5             	cmp    %rax,%r13
    9217:	0f 83 03 01 00 00    	jae    9320 <f12+0xbd0>
    921d:	49 89 c7             	mov    %rax,%r15
    9220:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9227:	00 
    9228:	45 31 e4             	xor    %r12d,%r12d
    922b:	48 89 04 24          	mov    %rax,(%rsp)
    922f:	48 8d 1d 4a a5 01 00 	lea    0x1a54a(%rip),%rbx        # 23780 <fwp_heap>
    9236:	eb 3a                	jmp    9272 <f12+0xb22>
    9238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    923f:	00 
    9240:	41 80 f9 01          	cmp    $0x1,%r9b
    9244:	75 27                	jne    926d <f12+0xb1d>
    9246:	45 8b 48 18          	mov    0x18(%r8),%r9d
    924a:	0f b7 c0             	movzwl %ax,%eax
    924d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9251:	49 0f af c1          	imul   %r9,%rax
    9255:	48 c1 e8 20          	shr    $0x20,%rax
    9259:	4c 39 c0             	cmp    %r8,%rax
    925c:	73 0f                	jae    926d <f12+0xb1d>
    925e:	48 01 c7             	add    %rax,%rdi
    9261:	80 3f ff             	cmpb   $0xff,(%rdi)
    9264:	0f 84 c6 02 00 00    	je     9530 <f12+0xde0>
    926a:	c6 07 01             	movb   $0x1,(%rdi)
    926d:	4d 39 fd             	cmp    %r15,%r13
    9270:	73 7e                	jae    92f0 <f12+0xba0>
    9272:	49 83 ef 01          	sub    $0x1,%r15
    9276:	66 49 0f 6e f4       	movq   %r12,%xmm6
    927b:	48 8b 34 24          	mov    (%rsp),%rsi
    927f:	bf 01 00 00 00       	mov    $0x1,%edi
    9284:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    928a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    928e:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9295:	00 
    9296:	e8 05 d5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    929b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    92a2:	49 89 c4             	mov    %rax,%r12
    92a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    92ac:	48 c1 e7 10          	shl    $0x10,%rdi
    92b0:	48 39 f8             	cmp    %rdi,%rax
    92b3:	73 b8                	jae    926d <f12+0xb1d>
    92b5:	48 89 c7             	mov    %rax,%rdi
    92b8:	48 c1 ef 10          	shr    $0x10,%rdi
    92bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    92c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    92c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    92cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    92cf:	48 85 ff             	test   %rdi,%rdi
    92d2:	74 99                	je     926d <f12+0xb1d>
    92d4:	45 0f b6 08          	movzbl (%r8),%r9d
    92d8:	41 80 f9 02          	cmp    $0x2,%r9b
    92dc:	0f 85 5e ff ff ff    	jne    9240 <f12+0xaf0>
    92e2:	66 85 c0             	test   %ax,%ax
    92e5:	0f 84 76 ff ff ff    	je     9261 <f12+0xb11>
    92eb:	4d 39 fd             	cmp    %r15,%r13
    92ee:	72 82                	jb     9272 <f12+0xb22>
    92f0:	4d 85 ed             	test   %r13,%r13
    92f3:	75 2e                	jne    9323 <f12+0xbd3>
    92f5:	8b 44 24 40          	mov    0x40(%rsp),%eax
    92f9:	85 c0                	test   %eax,%eax
    92fb:	4d 0f 45 f5          	cmovne %r13,%r14
    92ff:	eb 6f                	jmp    9370 <f12+0xc20>
    9301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9308:	66 85 d2             	test   %dx,%dx
    930b:	0f 84 fe fe ff ff    	je     920f <f12+0xabf>
    9311:	49 39 c5             	cmp    %rax,%r13
    9314:	0f 82 03 ff ff ff    	jb     921d <f12+0xacd>
    931a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9320:	45 31 e4             	xor    %r12d,%r12d
    9323:	4c 89 f2             	mov    %r14,%rdx
    9326:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    932a:	48 89 e8             	mov    %rbp,%rax
    932d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9334:	00 
    9335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    933c:	00 00 00 00 
    9340:	48 8b 0a             	mov    (%rdx),%rcx
    9343:	48 83 c2 08          	add    $0x8,%rdx
    9347:	48 89 c7             	mov    %rax,%rdi
    934a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    934e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9352:	4c 39 c2             	cmp    %r8,%rdx
    9355:	75 e9                	jne    9340 <f12+0xbf0>
    9357:	8b 54 24 40          	mov    0x40(%rsp),%edx
    935b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    935f:	85 d2                	test   %edx,%edx
    9361:	0f 84 c9 03 00 00    	je     9730 <f12+0xfe0>
    9367:	49 89 ec             	mov    %rbp,%r12
    936a:	45 31 f6             	xor    %r14d,%r14d
    936d:	48 89 c5             	mov    %rax,%rbp
    9370:	4c 89 f7             	mov    %r14,%rdi
    9373:	e8 d8 c1 ff ff       	call   5550 <fwp_mem_free>
    9378:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    937d:	e8 7e e5 ff ff       	call   7900 <fwp_drop4>
    9382:	48 89 ef             	mov    %rbp,%rdi
    9385:	e8 86 d9 ff ff       	call   6d10 <fwp_drop0>
    938a:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9391:	00 
    9392:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9399:	00 00 
    939b:	0f 85 3e 06 00 00    	jne    99df <f12+0x128f>
    93a1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    93a8:	4c 89 e0             	mov    %r12,%rax
    93ab:	5b                   	pop    %rbx
    93ac:	5d                   	pop    %rbp
    93ad:	41 5c                	pop    %r12
    93af:	41 5d                	pop    %r13
    93b1:	41 5e                	pop    %r14
    93b3:	41 5f                	pop    %r15
    93b5:	c3                   	ret
    93b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93bd:	00 00 00 
    93c0:	66 85 c9             	test   %cx,%cx
    93c3:	0f 84 1c fd ff ff    	je     90e5 <f12+0x995>
    93c9:	48 85 ed             	test   %rbp,%rbp
    93cc:	0f 84 0c 04 00 00    	je     97de <f12+0x108e>
    93d2:	48 89 e8             	mov    %rbp,%rax
    93d5:	45 31 e4             	xor    %r12d,%r12d
    93d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93df:	00 
    93e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    93e4:	4c 89 e2             	mov    %r12,%rdx
    93e7:	49 83 c4 01          	add    $0x1,%r12
    93eb:	48 85 c0             	test   %rax,%rax
    93ee:	75 f0                	jne    93e0 <f12+0xc90>
    93f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    93f7:	ff ff 1f 
    93fa:	4c 39 e0             	cmp    %r12,%rax
    93fd:	0f 82 5d 05 00 00    	jb     9960 <f12+0x1210>
    9403:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    940a:	00 
    940b:	be 02 00 00 00       	mov    $0x2,%esi
    9410:	e8 3b c6 ff ff       	call   5a50 <fwp_heap_alloc>
    9415:	4d 39 e7             	cmp    %r12,%r15
    9418:	48 89 ea             	mov    %rbp,%rdx
    941b:	49 89 c6             	mov    %rax,%r14
    941e:	4c 89 e0             	mov    %r12,%rax
    9421:	49 0f 46 c7          	cmovbe %r15,%rax
    9425:	4c 89 f1             	mov    %r14,%rcx
    9428:	66 90                	xchg   %ax,%ax
    942a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9431:	00 00 00 00 
    9435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    943c:	00 00 00 00 
    9440:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9444:	48 83 c1 08          	add    $0x8,%rcx
    9448:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    944c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9450:	48 85 d2             	test   %rdx,%rdx
    9453:	75 eb                	jne    9440 <f12+0xcf0>
    9455:	48 85 c0             	test   %rax,%rax
    9458:	0f 84 92 03 00 00    	je     97f0 <f12+0x10a0>
    945e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    9465:	00 
    9466:	e9 a2 fc ff ff       	jmp    910d <f12+0x9bd>
    946b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9470:	66 85 c0             	test   %ax,%ax
    9473:	0f 84 2b fb ff ff    	je     8fa4 <f12+0x854>
    9479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9480:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9487:	ff ff 1f 
    948a:	4c 39 f0             	cmp    %r14,%rax
    948d:	0f 82 d9 04 00 00    	jb     996c <f12+0x121c>
    9493:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    949a:	00 
    949b:	be 01 00 00 00       	mov    $0x1,%esi
    94a0:	e8 ab c5 ff ff       	call   5a50 <fwp_heap_alloc>
    94a5:	4c 89 30             	mov    %r14,(%rax)
    94a8:	48 8b 15 a9 b6 01 00 	mov    0x1b6a9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    94af:	49 89 c5             	mov    %rax,%r13
    94b2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    94b7:	48 2b 05 72 b6 01 00 	sub    0x1b672(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    94be:	48 c1 e2 10          	shl    $0x10,%rdx
    94c2:	48 39 d0             	cmp    %rdx,%rax
    94c5:	73 57                	jae    951e <f12+0xdce>
    94c7:	48 89 c2             	mov    %rax,%rdx
    94ca:	48 c1 ea 10          	shr    $0x10,%rdx
    94ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    94d2:	48 8b 15 9f b6 01 00 	mov    0x1b69f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    94d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    94dd:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    94e1:	4d 85 ff             	test   %r15,%r15
    94e4:	74 38                	je     951e <f12+0xdce>
    94e6:	0f b6 0a             	movzbl (%rdx),%ecx
    94e9:	80 f9 02             	cmp    $0x2,%cl
    94ec:	0f 84 0e 03 00 00    	je     9800 <f12+0x10b0>
    94f2:	80 f9 01             	cmp    $0x1,%cl
    94f5:	75 27                	jne    951e <f12+0xdce>
    94f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    94fa:	0f b7 c0             	movzwl %ax,%eax
    94fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9500:	48 0f af c1          	imul   %rcx,%rax
    9504:	48 c1 e8 20          	shr    $0x20,%rax
    9508:	48 39 d0             	cmp    %rdx,%rax
    950b:	73 11                	jae    951e <f12+0xdce>
    950d:	49 01 c7             	add    %rax,%r15
    9510:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9514:	0f 84 b3 03 00 00    	je     98cd <f12+0x117d>
    951a:	41 c6 07 01          	movb   $0x1,(%r15)
    951e:	4c 89 e7             	mov    %r12,%rdi
    9521:	e9 91 fa ff ff       	jmp    8fb7 <f12+0x867>
    9526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    952d:	00 00 00 
    9530:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    9535:	e8 d6 bd ff ff       	call   5310 <fwp_rc_forget_slot>
    953a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    953f:	e9 26 fd ff ff       	jmp    926a <f12+0xb1a>
    9544:	0f 1f 40 00          	nopl   0x0(%rax)
    9548:	48 c1 e6 10          	shl    $0x10,%rsi
    954c:	bf 08 00 00 00       	mov    $0x8,%edi
    9551:	49 09 f5             	or     %rsi,%r13
    9554:	be 02 00 00 00       	mov    $0x2,%esi
    9559:	e8 f2 c4 ff ff       	call   5a50 <fwp_heap_alloc>
    955e:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9565:	48 8b 15 ec b5 01 00 	mov    0x1b5ec(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    956c:	48 89 c3             	mov    %rax,%rbx
    956f:	48 2b 05 ba b5 01 00 	sub    0x1b5ba(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    9576:	48 c1 e2 10          	shl    $0x10,%rdx
    957a:	48 39 d0             	cmp    %rdx,%rax
    957d:	0f 83 fc f5 ff ff    	jae    8b7f <f12+0x42f>
    9583:	48 89 c2             	mov    %rax,%rdx
    9586:	48 c1 ea 10          	shr    $0x10,%rdx
    958a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    958e:	48 8b 15 e3 b5 01 00 	mov    0x1b5e3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9595:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9599:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    959d:	4d 85 f6             	test   %r14,%r14
    95a0:	0f 84 cd f5 ff ff    	je     8b73 <f12+0x423>
    95a6:	0f b6 0a             	movzbl (%rdx),%ecx
    95a9:	45 31 e4             	xor    %r12d,%r12d
    95ac:	80 f9 02             	cmp    $0x2,%cl
    95af:	0f 85 41 f5 ff ff    	jne    8af6 <f12+0x3a6>
    95b5:	66 85 c0             	test   %ax,%ax
    95b8:	0f 85 64 f5 ff ff    	jne    8b22 <f12+0x3d2>
    95be:	e9 51 f5 ff ff       	jmp    8b14 <f12+0x3c4>
    95c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95c8:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    95cc:	4c 89 e1             	mov    %r12,%rcx
    95cf:	48 c1 e9 3c          	shr    $0x3c,%rcx
    95d3:	0f 85 87 03 00 00    	jne    9960 <f12+0x1210>
    95d9:	4d 85 e4             	test   %r12,%r12
    95dc:	0f 84 9d f5 ff ff    	je     8b7f <f12+0x42f>
    95e2:	48 c1 e0 04          	shl    $0x4,%rax
    95e6:	4d 01 e4             	add    %r12,%r12
    95e9:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    95ed:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    95f2:	0f 1f 00             	nopl   (%rax)
    95f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    95fc:	00 00 00 00 
    9600:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9605:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9609:	49 83 c7 10          	add    $0x10,%r15
    960d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9611:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9616:	e8 85 cb ff ff       	call   61a0 <w107>
    961b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9620:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9624:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9629:	4d 39 fe             	cmp    %r15,%r14
    962c:	75 d2                	jne    9600 <f12+0xeb0>
    962e:	4c 89 23             	mov    %r12,(%rbx)
    9631:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    9638:	45 31 f6             	xor    %r14d,%r14d
    963b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9640:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    9645:	4c 89 ff             	mov    %r15,%rdi
    9648:	49 83 c6 02          	add    $0x2,%r14
    964c:	e8 cf c9 ff ff       	call   6020 <f128.constprop.0>
    9651:	49 89 c7             	mov    %rax,%r15
    9654:	4d 39 e6             	cmp    %r12,%r14
    9657:	72 e7                	jb     9640 <f12+0xef0>
    9659:	e9 32 f5 ff ff       	jmp    8b90 <f12+0x440>
    965e:	66 90                	xchg   %ax,%ax
    9660:	4d 8d 6a 01          	lea    0x1(%r10),%r13
    9664:	4d 39 ee             	cmp    %r13,%r14
    9667:	0f 8c 62 f6 ff ff    	jl     8ccf <f12+0x57f>
    966d:	4d 85 c0             	test   %r8,%r8
    9670:	0f 84 0b 03 00 00    	je     9981 <f12+0x1231>
    9676:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    967b:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    9682:	00 
    9683:	31 f6                	xor    %esi,%esi
    9685:	4c 89 c7             	mov    %r8,%rdi
    9688:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    968d:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9692:	e8 29 9e ff ff       	call   34c0 <memset@plt>
    9697:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    969d:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    96a3:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    96a8:	49 89 c0             	mov    %rax,%r8
    96ab:	e9 ad f6 ff ff       	jmp    8d5d <f12+0x60d>
    96b0:	48 8d 3d 89 db ff ff 	lea    -0x2477(%rip),%rdi        # 7240 <fwp_tape_finish>
    96b7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    96bc:	e8 0f 56 00 00       	call   ecd0 <atexit>
    96c1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    96c6:	85 c0                	test   %eax,%eax
    96c8:	0f 85 cb 02 00 00    	jne    9999 <f12+0x1249>
    96ce:	c7 05 a8 99 00 00 01 	movl   $0x1,0x99a8(%rip)        # 13080 <registered_finish.0>
    96d5:	00 00 00 
    96d8:	e9 a0 f1 ff ff       	jmp    887d <f12+0x12d>
    96dd:	0f 1f 00             	nopl   (%rax)
    96e0:	66 85 c0             	test   %ax,%ax
    96e3:	0f 85 47 f1 ff ff    	jne    8830 <f12+0xe0>
    96e9:	e9 2e f1 ff ff       	jmp    881c <f12+0xcc>
    96ee:	66 90                	xchg   %ax,%ax
    96f0:	4c 39 f3             	cmp    %r14,%rbx
    96f3:	0f 8f d3 f5 ff ff    	jg     8ccc <f12+0x57c>
    96f9:	48 85 db             	test   %rbx,%rbx
    96fc:	74 12                	je     9710 <f12+0xfc0>
    96fe:	4d 85 c0             	test   %r8,%r8
    9701:	0f 84 7a 02 00 00    	je     9981 <f12+0x1231>
    9707:	48 85 db             	test   %rbx,%rbx
    970a:	0f 85 d4 01 00 00    	jne    98e4 <f12+0x1194>
    9710:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    9717:	e9 55 f6 ff ff       	jmp    8d71 <f12+0x621>
    971c:	0f 1f 40 00          	nopl   0x0(%rax)
    9720:	66 85 c0             	test   %ax,%ax
    9723:	0f 85 d0 f7 ff ff    	jne    8ef9 <f12+0x7a9>
    9729:	e9 bf f7 ff ff       	jmp    8eed <f12+0x79d>
    972e:	66 90                	xchg   %ax,%ax
    9730:	49 89 ec             	mov    %rbp,%r12
    9733:	48 89 c5             	mov    %rax,%rbp
    9736:	e9 35 fc ff ff       	jmp    9370 <f12+0xc20>
    973b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9740:	66 0f 6f 0d 78 99 01 	movdqa 0x19978(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9747:	00 
    9748:	48 c7 05 55 99 01 00 	movq   $0x0,0x19955(%rip)        # 230a8 <fwp_tape_cached_bytes>
    974f:	00 00 00 00 
    9753:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    9758:	48 8b 05 81 99 01 00 	mov    0x19981(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    975f:	66 0f 6f 0d 69 99 01 	movdqa 0x19969(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9766:	00 
    9767:	49 89 46 40          	mov    %rax,0x40(%r14)
    976b:	48 8b 05 76 99 01 00 	mov    0x19976(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9772:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9777:	66 0f ef c9          	pxor   %xmm1,%xmm1
    977b:	49 89 46 18          	mov    %rax,0x18(%r14)
    977f:	48 8b 05 6a 99 01 00 	mov    0x1996a(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    9786:	0f 29 0d 33 99 01 00 	movaps %xmm1,0x19933(%rip)        # 230c0 <fwp_tape_workspace>
    978d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9791:	0f 29 0d 38 99 01 00 	movaps %xmm1,0x19938(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    9798:	48 c7 05 4d 99 01 00 	movq   $0x0,0x1994d(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    979f:	00 00 00 00 
    97a3:	0f 29 0d 36 99 01 00 	movaps %xmm1,0x19936(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    97aa:	e9 05 f2 ff ff       	jmp    89b4 <f12+0x264>
    97af:	90                   	nop
    97b0:	4d 85 c0             	test   %r8,%r8
    97b3:	0f 84 c8 01 00 00    	je     9981 <f12+0x1231>
    97b9:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    97be:	4c 8d 63 ff          	lea    -0x1(%rbx),%r12
    97c2:	31 f6                	xor    %esi,%esi
    97c4:	4c 89 c7             	mov    %r8,%rdi
    97c7:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    97cc:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    97d3:	00 
    97d4:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    97d9:	e9 b4 fe ff ff       	jmp    9692 <f12+0xf42>
    97de:	be 02 00 00 00       	mov    $0x2,%esi
    97e3:	bf 08 00 00 00       	mov    $0x8,%edi
    97e8:	e8 63 c2 ff ff       	call   5a50 <fwp_heap_alloc>
    97ed:	49 89 c6             	mov    %rax,%r14
    97f0:	45 31 e4             	xor    %r12d,%r12d
    97f3:	e9 78 fb ff ff       	jmp    9370 <f12+0xc20>
    97f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97ff:	00 
    9800:	66 85 c0             	test   %ax,%ax
    9803:	0f 85 15 fd ff ff    	jne    951e <f12+0xdce>
    9809:	e9 02 fd ff ff       	jmp    9510 <f12+0xdc0>
    980e:	66 90                	xchg   %ax,%ax
    9810:	4d 85 e4             	test   %r12,%r12
    9813:	0f 85 0e f3 ff ff    	jne    8b27 <f12+0x3d7>
    9819:	e9 61 f3 ff ff       	jmp    8b7f <f12+0x42f>
    981e:	66 90                	xchg   %ax,%ax
    9820:	be 08 00 00 00       	mov    $0x8,%esi
    9825:	4c 89 f7             	mov    %r14,%rdi
    9828:	e8 f3 9c ff ff       	call   3520 <calloc@plt>
    982d:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9833:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9839:	49 89 c0             	mov    %rax,%r8
    983c:	e9 eb f4 ff ff       	jmp    8d2c <f12+0x5dc>
    9841:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9845:	e9 25 f0 ff ff       	jmp    886f <f12+0x11f>
    984a:	49 8b 45 00          	mov    0x0(%r13),%rax
    984e:	48 85 c0             	test   %rax,%rax
    9851:	78 8b                	js     97de <f12+0x108e>
    9853:	48 8b 35 fe b2 01 00 	mov    0x1b2fe(%rip),%rsi        # 24b58 <fwp_heap+0x13d8>
    985a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    985f:	48 2b 0d ca b2 01 00 	sub    0x1b2ca(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    9866:	48 c1 e6 10          	shl    $0x10,%rsi
    986a:	48 39 f1             	cmp    %rsi,%rcx
    986d:	0f 83 6b ff ff ff    	jae    97de <f12+0x108e>
    9873:	48 89 ce             	mov    %rcx,%rsi
    9876:	48 c1 ee 10          	shr    $0x10,%rsi
    987a:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    987e:	48 8b 35 f3 b2 01 00 	mov    0x1b2f3(%rip),%rsi        # 24b78 <fwp_heap+0x13f8>
    9885:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9889:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    988d:	48 85 ff             	test   %rdi,%rdi
    9890:	0f 84 48 ff ff ff    	je     97de <f12+0x108e>
    9896:	48 0f ba f0 3f       	btr    $0x3f,%rax
    989b:	49 89 c7             	mov    %rax,%r15
    989e:	e9 12 f8 ff ff       	jmp    90b5 <f12+0x965>
    98a3:	be 68 00 00 00       	mov    $0x68,%esi
    98a8:	41 be 01 00 00 00    	mov    $0x1,%r14d
    98ae:	e9 48 f0 ff ff       	jmp    88fb <f12+0x1ab>
    98b3:	4c 89 f7             	mov    %r14,%rdi
    98b6:	e8 55 ba ff ff       	call   5310 <fwp_rc_forget_slot>
    98bb:	e9 5e f2 ff ff       	jmp    8b1e <f12+0x3ce>
    98c0:	48 89 df             	mov    %rbx,%rdi
    98c3:	e8 48 ba ff ff       	call   5310 <fwp_rc_forget_slot>
    98c8:	e9 29 f6 ff ff       	jmp    8ef6 <f12+0x7a6>
    98cd:	4c 89 ff             	mov    %r15,%rdi
    98d0:	e8 3b ba ff ff       	call   5310 <fwp_rc_forget_slot>
    98d5:	e9 40 fc ff ff       	jmp    951a <f12+0xdca>
    98da:	e8 11 b9 ff ff       	call   51f0 <fwp_rc_wide_dup>
    98df:	e9 4c ef ff ff       	jmp    8830 <f12+0xe0>
    98e4:	49 89 dd             	mov    %rbx,%r13
    98e7:	4c 89 c7             	mov    %r8,%rdi
    98ea:	31 f6                	xor    %esi,%esi
    98ec:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    98f1:	4d 8d 65 ff          	lea    -0x1(%r13),%r12
    98f5:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    98fc:	00 
    98fd:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9902:	e8 b9 9b ff ff       	call   34c0 <memset@plt>
    9907:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    990d:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9913:	49 89 c0             	mov    %rax,%r8
    9916:	e9 3a f4 ff ff       	jmp    8d55 <f12+0x605>
    991b:	45 31 ed             	xor    %r13d,%r13d
    991e:	e9 fa f8 ff ff       	jmp    921d <f12+0xacd>
    9923:	48 8d 3d da 57 00 00 	lea    0x57da(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    992a:	e8 71 a8 ff ff       	call   41a0 <fwp_trap>
    992f:	48 8d 3d 8a 5e 00 00 	lea    0x5e8a(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    9936:	e8 65 a8 ff ff       	call   41a0 <fwp_trap>
    993b:	e8 c0 9d ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9940:	48 8d 3d 81 5f 00 00 	lea    0x5f81(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    9947:	e8 54 a8 ff ff       	call   41a0 <fwp_trap>
    994c:	45 31 f6             	xor    %r14d,%r14d
    994f:	e9 9c fe ff ff       	jmp    97f0 <f12+0x10a0>
    9954:	48 8d 3d e0 57 00 00 	lea    0x57e0(%rip),%rdi        # f13b <_IO_stdin_used+0x13b>
    995b:	e8 40 a8 ff ff       	call   41a0 <fwp_trap>
    9960:	48 8d 3d c6 57 00 00 	lea    0x57c6(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    9967:	e8 34 a8 ff ff       	call   41a0 <fwp_trap>
    996c:	48 8d 3d e2 57 00 00 	lea    0x57e2(%rip),%rdi        # f155 <_IO_stdin_used+0x155>
    9973:	e8 28 a8 ff ff       	call   41a0 <fwp_trap>
    9978:	4d 85 ed             	test   %r13,%r13
    997b:	0f 84 cd f3 ff ff    	je     8d4e <f12+0x5fe>
    9981:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9988:	00 
    9989:	48 8b 3c 24          	mov    (%rsp),%rdi
    998d:	48 89 05 84 ba 01 00 	mov    %rax,0x1ba84(%rip)        # 25418 <fwp_cleanups>
    9994:	e8 97 b4 ff ff       	call   4e30 <fwp_tape_buffers_release>
    9999:	48 8b 0d c0 96 00 00 	mov    0x96c0(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    99a0:	ba 13 00 00 00       	mov    $0x13,%edx
    99a5:	be 01 00 00 00       	mov    $0x1,%esi
    99aa:	48 8d 3d 57 56 00 00 	lea    0x5657(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    99b1:	e8 ca 9c ff ff       	call   3680 <fwrite@plt>
    99b6:	31 ff                	xor    %edi,%edi
    99b8:	e8 03 9c ff ff       	call   35c0 <fflush@plt>
    99bd:	bf 66 00 00 00       	mov    $0x66,%edi
    99c2:	e8 d9 9c ff ff       	call   36a0 <_Exit@plt>
    99c7:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # f898 <_IO_stdin_used+0x898>
    99ce:	e8 cd a7 ff ff       	call   41a0 <fwp_trap>
    99d3:	48 8d 3d 8e 5e 00 00 	lea    0x5e8e(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    99da:	e8 c1 a7 ff ff       	call   41a0 <fwp_trap>
    99df:	e8 7c 9a ff ff       	call   3460 <__stack_chk_fail@plt>
    99e4:	48 8d 3d 1d 5e 00 00 	lea    0x5e1d(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    99eb:	e8 b0 a7 ff ff       	call   41a0 <fwp_trap>

00000000000099f0 <fwp_owned_entry12>:
    99f0:	f3 0f 1e fa          	endbr64
    99f4:	48 8b 3f             	mov    (%rdi),%rdi
    99f7:	e9 54 ed ff ff       	jmp    8750 <f12>
    99fc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009a00 <e12>:
    9a00:	f3 0f 1e fa          	endbr64
    9a04:	53                   	push   %rbx
    9a05:	48 8b 1f             	mov    (%rdi),%rbx
    9a08:	48 89 df             	mov    %rbx,%rdi
    9a0b:	e8 c0 ce ff ff       	call   68d0 <fwp_rc_share>
    9a10:	48 89 df             	mov    %rbx,%rdi
    9a13:	e8 38 ed ff ff       	call   8750 <f12>
    9a18:	48 89 c3             	mov    %rax,%rbx
    9a1b:	48 89 c7             	mov    %rax,%rdi
    9a1e:	e8 ad ce ff ff       	call   68d0 <fwp_rc_share>
    9a23:	48 89 d8             	mov    %rbx,%rax
    9a26:	5b                   	pop    %rbx
    9a27:	c3                   	ret
    9a28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a2f:	00 

0000000000009a30 <fwp_write>:
    9a30:	41 57                	push   %r15
    9a32:	41 56                	push   %r14
    9a34:	41 55                	push   %r13
    9a36:	41 54                	push   %r12
    9a38:	55                   	push   %rbp
    9a39:	53                   	push   %rbx
    9a3a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9a41:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9a48:	00 00 
    9a4a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9a51:	00 
    9a52:	49 89 d4             	mov    %rdx,%r12
    9a55:	8b 12                	mov    (%rdx),%edx
    9a57:	83 fa 19             	cmp    $0x19,%edx
    9a5a:	77 6a                	ja     9ac6 <fwp_write+0x96>
    9a5c:	48 89 f5             	mov    %rsi,%rbp
    9a5f:	89 d0                	mov    %edx,%eax
    9a61:	89 ce                	mov    %ecx,%esi
    9a63:	48 89 fb             	mov    %rdi,%rbx
    9a66:	48 8d 0d a3 5f 00 00 	lea    0x5fa3(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    9a6d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9a71:	48 01 c8             	add    %rcx,%rax
    9a74:	3e ff e0             	notrack jmp *%rax
    9a77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9a7e:	00 00 
    9a80:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9a84:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9a88:	48 89 ca             	mov    %rcx,%rdx
    9a8b:	48 85 c9             	test   %rcx,%rcx
    9a8e:	0f 88 9c 0c 00 00    	js     a730 <fwp_write+0xd00>
    9a94:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a9b:	00 
    9a9c:	48 89 c6             	mov    %rax,%rsi
    9a9f:	4c 89 e7             	mov    %r12,%rdi
    9aa2:	e8 99 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9aae:	00 00 
    9ab0:	4c 89 e7             	mov    %r12,%rdi
    9ab3:	e8 98 99 ff ff       	call   3450 <strlen@plt>
    9ab8:	4c 89 e6             	mov    %r12,%rsi
    9abb:	48 89 df             	mov    %rbx,%rdi
    9abe:	48 89 c2             	mov    %rax,%rdx
    9ac1:	e8 aa a5 ff ff       	call   4070 <buf_put>
    9ac6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9acd:	00 
    9ace:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ad5:	00 00 
    9ad7:	0f 85 28 04 00 00    	jne    9f05 <fwp_write+0x4d5>
    9add:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9ae4:	5b                   	pop    %rbx
    9ae5:	5d                   	pop    %rbp
    9ae6:	41 5c                	pop    %r12
    9ae8:	41 5d                	pop    %r13
    9aea:	41 5e                	pop    %r14
    9aec:	41 5f                	pop    %r15
    9aee:	c3                   	ret
    9aef:	90                   	nop
    9af0:	49 89 e9             	mov    %rbp,%r9
    9af3:	4c 8d 05 87 56 00 00 	lea    0x5687(%rip),%r8        # f181 <_IO_stdin_used+0x181>
    9afa:	b9 00 02 00 00       	mov    $0x200,%ecx
    9aff:	ba 02 00 00 00       	mov    $0x2,%edx
    9b04:	be 00 02 00 00       	mov    $0x200,%esi
    9b09:	31 c0                	xor    %eax,%eax
    9b0b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9b12:	00 
    9b13:	e8 98 98 ff ff       	call   33b0 <__snprintf_chk@plt>
    9b18:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9b1f:	00 
    9b20:	e8 2b 99 ff ff       	call   3450 <strlen@plt>
    9b25:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9b2c:	00 
    9b2d:	48 89 df             	mov    %rbx,%rdi
    9b30:	48 89 c2             	mov    %rax,%rdx
    9b33:	e8 38 a5 ff ff       	call   4070 <buf_put>
    9b38:	eb 8c                	jmp    9ac6 <fwp_write+0x96>
    9b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9b40:	49 89 e9             	mov    %rbp,%r9
    9b43:	4c 8d 05 32 56 00 00 	lea    0x5632(%rip),%r8        # f17c <_IO_stdin_used+0x17c>
    9b4a:	eb ae                	jmp    9afa <fwp_write+0xca>
    9b4c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b50:	83 fa 13             	cmp    $0x13,%edx
    9b53:	48 8d 05 18 56 00 00 	lea    0x5618(%rip),%rax        # f172 <_IO_stdin_used+0x172>
    9b5a:	48 8d 35 16 56 00 00 	lea    0x5616(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    9b61:	ba 04 00 00 00       	mov    $0x4,%edx
    9b66:	48 0f 44 f0          	cmove  %rax,%rsi
    9b6a:	45 31 ed             	xor    %r13d,%r13d
    9b6d:	e8 fe a4 ff ff       	call   4070 <buf_put>
    9b72:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9b77:	0f 84 a3 08 00 00    	je     a420 <fwp_write+0x9f0>
    9b7d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9b82:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9b87:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9b8c:	48 89 df             	mov    %rbx,%rdi
    9b8f:	49 0f 44 c5          	cmove  %r13,%rax
    9b93:	31 c9                	xor    %ecx,%ecx
    9b95:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9b9a:	e8 91 fe ff ff       	call   9a30 <fwp_write>
    9b9f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9ba4:	0f 84 6e 09 00 00    	je     a518 <fwp_write+0xae8>
    9baa:	49 83 c5 01          	add    $0x1,%r13
    9bae:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9bb2:	0f 83 68 08 00 00    	jae    a420 <fwp_write+0x9f0>
    9bb8:	ba 02 00 00 00       	mov    $0x2,%edx
    9bbd:	48 8d 35 fd 55 00 00 	lea    0x55fd(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9bc4:	48 89 df             	mov    %rbx,%rdi
    9bc7:	e8 a4 a4 ff ff       	call   4070 <buf_put>
    9bcc:	eb af                	jmp    9b7d <fwp_write+0x14d>
    9bce:	66 90                	xchg   %ax,%ax
    9bd0:	ba 06 00 00 00       	mov    $0x6,%edx
    9bd5:	48 8d 35 be 55 00 00 	lea    0x55be(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    9bdc:	48 83 c5 10          	add    $0x10,%rbp
    9be0:	e8 8b a4 ff ff       	call   4070 <buf_put>
    9be5:	48 89 ef             	mov    %rbp,%rdi
    9be8:	e8 63 98 ff ff       	call   3450 <strlen@plt>
    9bed:	48 89 ee             	mov    %rbp,%rsi
    9bf0:	48 89 df             	mov    %rbx,%rdi
    9bf3:	48 89 c2             	mov    %rax,%rdx
    9bf6:	e8 75 a4 ff ff       	call   4070 <buf_put>
    9bfb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9c00:	ba 01 00 00 00       	mov    $0x1,%edx
    9c05:	48 89 df             	mov    %rbx,%rdi
    9c08:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9c0d:	e8 5e a4 ff ff       	call   4070 <buf_put>
    9c12:	e9 af fe ff ff       	jmp    9ac6 <fwp_write+0x96>
    9c17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c1e:	00 00 
    9c20:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c27:	00 
    9c28:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c2f:	00 00 
    9c31:	0f 85 ce 02 00 00    	jne    9f05 <fwp_write+0x4d5>
    9c37:	ba 0a 00 00 00       	mov    $0xa,%edx
    9c3c:	48 8d 35 43 55 00 00 	lea    0x5543(%rip),%rsi        # f186 <_IO_stdin_used+0x186>
    9c43:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9c4a:	48 89 df             	mov    %rbx,%rdi
    9c4d:	5b                   	pop    %rbx
    9c4e:	5d                   	pop    %rbp
    9c4f:	41 5c                	pop    %r12
    9c51:	41 5d                	pop    %r13
    9c53:	41 5e                	pop    %r14
    9c55:	41 5f                	pop    %r15
    9c57:	e9 14 a4 ff ff       	jmp    4070 <buf_put>
    9c5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9c60:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9c65:	4d 85 ed             	test   %r13,%r13
    9c68:	0f 84 02 0c 00 00    	je     a870 <fwp_write+0xe40>
    9c6e:	48 8d 35 59 55 00 00 	lea    0x5559(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    9c75:	4c 89 ef             	mov    %r13,%rdi
    9c78:	e8 b3 98 ff ff       	call   3530 <strcmp@plt>
    9c7d:	41 89 c1             	mov    %eax,%r9d
    9c80:	85 c0                	test   %eax,%eax
    9c82:	0f 84 6c 0c 00 00    	je     a8f4 <fwp_write+0xec4>
    9c88:	4c 89 ef             	mov    %r13,%rdi
    9c8b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9c90:	e8 bb 97 ff ff       	call   3450 <strlen@plt>
    9c95:	4c 89 ee             	mov    %r13,%rsi
    9c98:	48 89 df             	mov    %rbx,%rdi
    9c9b:	48 89 c2             	mov    %rax,%rdx
    9c9e:	e8 cd a3 ff ff       	call   4070 <buf_put>
    9ca3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ca8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9cad:	48 89 df             	mov    %rbx,%rdi
    9cb0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9cb5:	e8 b6 a3 ff ff       	call   4070 <buf_put>
    9cba:	ba 01 00 00 00       	mov    $0x1,%edx
    9cbf:	4c 89 fe             	mov    %r15,%rsi
    9cc2:	48 89 df             	mov    %rbx,%rdi
    9cc5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9cca:	e8 a1 a3 ff ff       	call   4070 <buf_put>
    9ccf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9cd4:	45 31 f6             	xor    %r14d,%r14d
    9cd7:	85 d2                	test   %edx,%edx
    9cd9:	0f 8e 81 0a 00 00    	jle    a760 <fwp_write+0xd30>
    9cdf:	45 31 ed             	xor    %r13d,%r13d
    9ce2:	4d 85 ed             	test   %r13,%r13
    9ce5:	0f 85 75 07 00 00    	jne    a460 <fwp_write+0xa30>
    9ceb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9cf2:	00 
    9cf3:	45 85 f6             	test   %r14d,%r14d
    9cf6:	0f 84 84 07 00 00    	je     a480 <fwp_write+0xa50>
    9cfc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9d01:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9d06:	48 89 df             	mov    %rbx,%rdi
    9d09:	49 83 c5 01          	add    $0x1,%r13
    9d0d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9d11:	31 c9                	xor    %ecx,%ecx
    9d13:	e8 18 fd ff ff       	call   9a30 <fwp_write>
    9d18:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9d1d:	7f c3                	jg     9ce2 <fwp_write+0x2b2>
    9d1f:	45 85 f6             	test   %r14d,%r14d
    9d22:	0f 84 38 0a 00 00    	je     a760 <fwp_write+0xd30>
    9d28:	b8 29 00 00 00       	mov    $0x29,%eax
    9d2d:	ba 01 00 00 00       	mov    $0x1,%edx
    9d32:	4c 89 fe             	mov    %r15,%rsi
    9d35:	48 89 df             	mov    %rbx,%rdi
    9d38:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9d3c:	e8 2f a3 ff ff       	call   4070 <buf_put>
    9d41:	e9 80 fd ff ff       	jmp    9ac6 <fwp_write+0x96>
    9d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d4d:	00 00 00 
    9d50:	ba 01 00 00 00       	mov    $0x1,%edx
    9d55:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9d5a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9d5f:	e8 0c a3 ff ff       	call   4070 <buf_put>
    9d64:	48 85 ed             	test   %rbp,%rbp
    9d67:	0f 84 93 06 00 00    	je     a400 <fwp_write+0x9d0>
    9d6d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9d71:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9d76:	31 c9                	xor    %ecx,%ecx
    9d78:	48 89 df             	mov    %rbx,%rdi
    9d7b:	e8 b0 fc ff ff       	call   9a30 <fwp_write>
    9d80:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9d84:	48 85 ed             	test   %rbp,%rbp
    9d87:	0f 84 73 06 00 00    	je     a400 <fwp_write+0x9d0>
    9d8d:	ba 02 00 00 00       	mov    $0x2,%edx
    9d92:	48 8d 35 28 54 00 00 	lea    0x5428(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9d99:	48 89 df             	mov    %rbx,%rdi
    9d9c:	e8 cf a2 ff ff       	call   4070 <buf_put>
    9da1:	eb ca                	jmp    9d6d <fwp_write+0x33d>
    9da3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9da8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9dac:	85 f6                	test   %esi,%esi
    9dae:	0f 84 fc 07 00 00    	je     a5b0 <fwp_write+0xb80>
    9db4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9dbb:	00 
    9dbc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9dc3:	00 00 
    9dc5:	0f 85 3a 01 00 00    	jne    9f05 <fwp_write+0x4d5>
    9dcb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9dcf:	4c 89 ea             	mov    %r13,%rdx
    9dd2:	e9 6c fe ff ff       	jmp    9c43 <fwp_write+0x213>
    9dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9dde:	00 00 
    9de0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9de5:	ba 01 00 00 00       	mov    $0x1,%edx
    9dea:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9def:	48 89 ee             	mov    %rbp,%rsi
    9df2:	e8 79 a2 ff ff       	call   4070 <buf_put>
    9df7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9dfc:	4c 89 e7             	mov    %r12,%rdi
    9dff:	e8 4c 96 ff ff       	call   3450 <strlen@plt>
    9e04:	4c 89 e6             	mov    %r12,%rsi
    9e07:	48 89 df             	mov    %rbx,%rdi
    9e0a:	48 89 c2             	mov    %rax,%rdx
    9e0d:	e8 5e a2 ff ff       	call   4070 <buf_put>
    9e12:	ba 01 00 00 00       	mov    $0x1,%edx
    9e17:	48 89 ee             	mov    %rbp,%rsi
    9e1a:	48 89 df             	mov    %rbx,%rdi
    9e1d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9e22:	e8 49 a2 ff ff       	call   4070 <buf_put>
    9e27:	e9 9a fc ff ff       	jmp    9ac6 <fwp_write+0x96>
    9e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e30:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9e35:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9e39:	0f 8a 8e 0b 00 00    	jp     a9cd <fwp_write+0xf9d>
    9e3f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e43:	66 0f 54 05 c5 5c 00 	andpd  0x5cc5(%rip),%xmm0        # fb10 <msg.4+0x90>
    9e4a:	00 
    9e4b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9e50:	66 0f 2e 05 f8 5c 00 	ucomisd 0x5cf8(%rip),%xmm0        # fb50 <msg.4+0xd0>
    9e57:	00 
    9e58:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9e5f:	00 
    9e60:	0f 87 b2 09 00 00    	ja     a818 <fwp_write+0xde8>
    9e66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e6d:	00 00 00 
    9e70:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9e74:	89 ee                	mov    %ebp,%esi
    9e76:	4c 89 e7             	mov    %r12,%rdi
    9e79:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9e7e:	e8 3d a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9e83:	31 f6                	xor    %esi,%esi
    9e85:	4c 89 e7             	mov    %r12,%rdi
    9e88:	e8 83 95 ff ff       	call   3410 <strtod@plt>
    9e8d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9e92:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9e96:	7a 06                	jp     9e9e <fwp_write+0x46e>
    9e98:	0f 84 e9 01 00 00    	je     a087 <fwp_write+0x657>
    9e9e:	83 c5 01             	add    $0x1,%ebp
    9ea1:	83 fd 12             	cmp    $0x12,%ebp
    9ea4:	75 ca                	jne    9e70 <fwp_write+0x440>
    9ea6:	be 11 00 00 00       	mov    $0x11,%esi
    9eab:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9eaf:	4c 89 e7             	mov    %r12,%rdi
    9eb2:	e8 09 a6 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9eb7:	e9 cb 01 00 00       	jmp    a087 <fwp_write+0x657>
    9ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    9ec0:	48 83 fd 01          	cmp    $0x1,%rbp
    9ec4:	0f 84 e6 08 00 00    	je     a7b0 <fwp_write+0xd80>
    9eca:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9ece:	b8 02 00 00 00       	mov    $0x2,%eax
    9ed3:	ba 01 00 00 00       	mov    $0x1,%edx
    9ed8:	48 0f 44 d0          	cmove  %rax,%rdx
    9edc:	48 8d 35 87 52 00 00 	lea    0x5287(%rip),%rsi        # f16a <_IO_stdin_used+0x16a>
    9ee3:	48 8d 05 85 52 00 00 	lea    0x5285(%rip),%rax        # f16f <_IO_stdin_used+0x16f>
    9eea:	48 0f 44 f0          	cmove  %rax,%rsi
    9eee:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ef5:	00 
    9ef6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9efd:	00 00 
    9eff:	0f 84 3e fd ff ff    	je     9c43 <fwp_write+0x213>
    9f05:	e8 56 95 ff ff       	call   3460 <__stack_chk_fail@plt>
    9f0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f10:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9f15:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9f1a:	e8 91 a0 ff ff       	call   3fb0 <buf_grow>
    9f1f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9f23:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9f29:	4c 03 0b             	add    (%rbx),%r9
    9f2c:	66 45 89 11          	mov    %r10w,(%r9)
    9f30:	45 85 e4             	test   %r12d,%r12d
    9f33:	0f 8e 07 05 00 00    	jle    a440 <fwp_write+0xa10>
    9f39:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9f40:	55 55 55 
    9f43:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9f48:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9f4f:	aa aa aa 
    9f52:	49 83 c1 01          	add    $0x1,%r9
    9f56:	eb 45                	jmp    9f9d <fwp_write+0x56d>
    9f58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f5f:	00 
    9f60:	be 01 00 00 00       	mov    $0x1,%esi
    9f65:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9f6a:	88 07                	mov    %al,(%rdi)
    9f6c:	48 89 e8             	mov    %rbp,%rax
    9f6f:	49 f7 e8             	imul   %r8
    9f72:	48 89 e8             	mov    %rbp,%rax
    9f75:	48 c1 f8 3f          	sar    $0x3f,%rax
    9f79:	48 29 c2             	sub    %rax,%rdx
    9f7c:	48 85 c9             	test   %rcx,%rcx
    9f7f:	0f 95 c0             	setne  %al
    9f82:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9f86:	48 83 ef 01          	sub    $0x1,%rdi
    9f8a:	48 21 c5             	and    %rax,%rbp
    9f8d:	48 29 ea             	sub    %rbp,%rdx
    9f90:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9f94:	49 39 f9             	cmp    %rdi,%r9
    9f97:	0f 84 a3 04 00 00    	je     a440 <fwp_write+0xa10>
    9f9d:	48 89 e8             	mov    %rbp,%rax
    9fa0:	49 f7 e8             	imul   %r8
    9fa3:	48 89 e8             	mov    %rbp,%rax
    9fa6:	48 c1 f8 3f          	sar    $0x3f,%rax
    9faa:	48 89 d1             	mov    %rdx,%rcx
    9fad:	48 29 c1             	sub    %rax,%rcx
    9fb0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9fb4:	48 89 e9             	mov    %rbp,%rcx
    9fb7:	48 29 c1             	sub    %rax,%rcx
    9fba:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9fbe:	49 f7 e2             	mul    %r10
    9fc1:	b8 30 00 00 00       	mov    $0x30,%eax
    9fc6:	48 89 d6             	mov    %rdx,%rsi
    9fc9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9fcd:	48 d1 ee             	shr    $1,%rsi
    9fd0:	48 01 f2             	add    %rsi,%rdx
    9fd3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9fd7:	48 29 d6             	sub    %rdx,%rsi
    9fda:	74 8e                	je     9f6a <fwp_write+0x53a>
    9fdc:	48 83 fe 01          	cmp    $0x1,%rsi
    9fe0:	0f 85 7a ff ff ff    	jne    9f60 <fwp_write+0x530>
    9fe6:	31 f6                	xor    %esi,%esi
    9fe8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9fed:	e9 78 ff ff ff       	jmp    9f6a <fwp_write+0x53a>
    9ff2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ff8:	66 0f 6e cd          	movd   %ebp,%xmm1
    9ffc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9fff:	0f 8a c8 09 00 00    	jp     a9cd <fwp_write+0xf9d>
    a005:	0f 28 c1             	movaps %xmm1,%xmm0
    a008:	0f 54 05 f1 5a 00 00 	andps  0x5af1(%rip),%xmm0        # fb00 <msg.4+0x80>
    a00f:	0f 2e 05 ee 4f 00 00 	ucomiss 0x4fee(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    a016:	0f 87 24 08 00 00    	ja     a840 <fwp_write+0xe10>
    a01c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a020:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a026:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a02d:	00 
    a02e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a032:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a03e:	00 00 
    a040:	44 89 ee             	mov    %r13d,%esi
    a043:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a048:	4c 89 e7             	mov    %r12,%rdi
    a04b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a050:	e8 6b a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a055:	31 f6                	xor    %esi,%esi
    a057:	4c 89 e7             	mov    %r12,%rdi
    a05a:	e8 51 94 ff ff       	call   34b0 <strtof@plt>
    a05f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a064:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a067:	7a 02                	jp     a06b <fwp_write+0x63b>
    a069:	74 1c                	je     a087 <fwp_write+0x657>
    a06b:	41 83 c5 01          	add    $0x1,%r13d
    a06f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a073:	75 cb                	jne    a040 <fwp_write+0x610>
    a075:	be 09 00 00 00       	mov    $0x9,%esi
    a07a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a07f:	4c 89 e7             	mov    %r12,%rdi
    a082:	e8 39 a4 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a087:	4c 89 e7             	mov    %r12,%rdi
    a08a:	e8 a1 a0 ff ff       	call   4130 <fwp_finish_float>
    a08f:	e9 1c fa ff ff       	jmp    9ab0 <fwp_write+0x80>
    a094:	0f 1f 40 00          	nopl   0x0(%rax)
    a098:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a09c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a0a0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a0a7:	00 
    a0a8:	48 89 ef             	mov    %rbp,%rdi
    a0ab:	e8 90 99 ff ff       	call   3a40 <fwp_fmt_u128>
    a0b0:	48 89 ef             	mov    %rbp,%rdi
    a0b3:	e8 98 93 ff ff       	call   3450 <strlen@plt>
    a0b8:	48 89 ee             	mov    %rbp,%rsi
    a0bb:	48 89 df             	mov    %rbx,%rdi
    a0be:	48 89 c2             	mov    %rax,%rdx
    a0c1:	e8 aa 9f ff ff       	call   4070 <buf_put>
    a0c6:	e9 fb f9 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a0cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a0d0:	ba 06 00 00 00       	mov    $0x6,%edx
    a0d5:	48 8d 35 e8 50 00 00 	lea    0x50e8(%rip),%rsi        # f1c4 <_IO_stdin_used+0x1c4>
    a0dc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a0e2:	e8 89 9f ff ff       	call   4070 <buf_put>
    a0e7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a0ee:	ff ff 7f 
    a0f1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a0f5:	0f 84 86 02 00 00    	je     a381 <fwp_write+0x951>
    a0fb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a100:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a104:	48 85 d2             	test   %rdx,%rdx
    a107:	0f 84 ae 00 00 00    	je     a1bb <fwp_write+0x78b>
    a10d:	8b 0a                	mov    (%rdx),%ecx
    a10f:	83 f9 1c             	cmp    $0x1c,%ecx
    a112:	0f 84 58 06 00 00    	je     a770 <fwp_write+0xd40>
    a118:	83 f9 1b             	cmp    $0x1b,%ecx
    a11b:	0f 87 9a 00 00 00    	ja     a1bb <fwp_write+0x78b>
    a121:	be 01 00 00 00       	mov    $0x1,%esi
    a126:	48 d3 e6             	shl    %cl,%rsi
    a129:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a12f:	0f 85 4b 04 00 00    	jne    a580 <fwp_write+0xb50>
    a135:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a13b:	0f 85 0f 04 00 00    	jne    a550 <fwp_write+0xb20>
    a141:	83 e6 21             	and    $0x21,%esi
    a144:	74 75                	je     a1bb <fwp_write+0x78b>
    a146:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a14b:	48 85 ff             	test   %rdi,%rdi
    a14e:	79 07                	jns    a157 <fwp_write+0x727>
    a150:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a154:	4c 01 ee             	add    %r13,%rsi
    a157:	48 0f be 3e          	movsbq (%rsi),%rdi
    a15b:	85 c9                	test   %ecx,%ecx
    a15d:	40 0f b6 f7          	movzbl %dil,%esi
    a161:	48 0f 44 f7          	cmove  %rdi,%rsi
    a165:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a16c:	00 00 00 00 
    a170:	31 c9                	xor    %ecx,%ecx
    a172:	48 89 df             	mov    %rbx,%rdi
    a175:	49 83 c5 01          	add    $0x1,%r13
    a179:	e8 b2 f8 ff ff       	call   9a30 <fwp_write>
    a17e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a185:	ff ff 7f 
    a188:	48 23 55 00          	and    0x0(%rbp),%rdx
    a18c:	49 39 d5             	cmp    %rdx,%r13
    a18f:	0f 83 ec 01 00 00    	jae    a381 <fwp_write+0x951>
    a195:	ba 02 00 00 00       	mov    $0x2,%edx
    a19a:	48 89 df             	mov    %rbx,%rdi
    a19d:	48 8d 35 1d 50 00 00 	lea    0x501d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a1a4:	e8 c7 9e ff ff       	call   4070 <buf_put>
    a1a9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a1ae:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a1b2:	48 85 d2             	test   %rdx,%rdx
    a1b5:	0f 85 52 ff ff ff    	jne    a10d <fwp_write+0x6dd>
    a1bb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a1c0:	48 85 ff             	test   %rdi,%rdi
    a1c3:	0f 88 cf 05 00 00    	js     a798 <fwp_write+0xd68>
    a1c9:	48 8b 31             	mov    (%rcx),%rsi
    a1cc:	eb a2                	jmp    a170 <fwp_write+0x740>
    a1ce:	66 90                	xchg   %ax,%ax
    a1d0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1d7:	00 
    a1d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1df:	00 00 
    a1e1:	0f 85 1e fd ff ff    	jne    9f05 <fwp_write+0x4d5>
    a1e7:	ba 08 00 00 00       	mov    $0x8,%edx
    a1ec:	48 8d 35 9e 4f 00 00 	lea    0x4f9e(%rip),%rsi        # f191 <_IO_stdin_used+0x191>
    a1f3:	e9 4b fa ff ff       	jmp    9c43 <fwp_write+0x213>
    a1f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1ff:	00 
    a200:	89 e8                	mov    %ebp,%eax
    a202:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a209:	76 03                	jbe    a20e <fwp_write+0x7de>
    a20b:	8b 45 00             	mov    0x0(%rbp),%eax
    a20e:	41 89 c6             	mov    %eax,%r14d
    a211:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a216:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a21b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a21f:	4c 89 ef             	mov    %r13,%rdi
    a222:	e8 29 92 ff ff       	call   3450 <strlen@plt>
    a227:	4c 89 ee             	mov    %r13,%rsi
    a22a:	48 89 df             	mov    %rbx,%rdi
    a22d:	48 89 c2             	mov    %rax,%rdx
    a230:	e8 3b 9e ff ff       	call   4070 <buf_put>
    a235:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a23a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a23e:	85 f6                	test   %esi,%esi
    a240:	0f 8e 80 f8 ff ff    	jle    9ac6 <fwp_write+0x96>
    a246:	45 31 ed             	xor    %r13d,%r13d
    a249:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a24e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a253:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a258:	ba 01 00 00 00       	mov    $0x1,%edx
    a25d:	4c 89 fe             	mov    %r15,%rsi
    a260:	48 89 04 24          	mov    %rax,(%rsp)
    a264:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a269:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a26d:	48 89 df             	mov    %rbx,%rdi
    a270:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a274:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a279:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a27e:	e8 ed 9d ff ff       	call   4070 <buf_put>
    a283:	41 8b 06             	mov    (%r14),%eax
    a286:	83 f8 0e             	cmp    $0xe,%eax
    a289:	0f 84 71 02 00 00    	je     a500 <fwp_write+0xad0>
    a28f:	83 f8 10             	cmp    $0x10,%eax
    a292:	0f 84 38 02 00 00    	je     a4d0 <fwp_write+0xaa0>
    a298:	83 f8 0a             	cmp    $0xa,%eax
    a29b:	0f 84 7f 04 00 00    	je     a720 <fwp_write+0xcf0>
    a2a1:	0f 8f f9 00 00 00    	jg     a3a0 <fwp_write+0x970>
    a2a7:	83 f8 03             	cmp    $0x3,%eax
    a2aa:	0f 8f 50 04 00 00    	jg     a700 <fwp_write+0xcd0>
    a2b0:	85 c0                	test   %eax,%eax
    a2b2:	78 10                	js     a2c4 <fwp_write+0x894>
    a2b4:	48 8b 04 24          	mov    (%rsp),%rax
    a2b8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a2bc:	85 c0                	test   %eax,%eax
    a2be:	0f 85 f9 00 00 00    	jne    a3bd <fwp_write+0x98d>
    a2c4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a2c9:	48 8b 34 24          	mov    (%rsp),%rsi
    a2cd:	31 c9                	xor    %ecx,%ecx
    a2cf:	48 89 df             	mov    %rbx,%rdi
    a2d2:	e8 59 f7 ff ff       	call   9a30 <fwp_write>
    a2d7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a2dc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a2e1:	49 83 c5 01          	add    $0x1,%r13
    a2e5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a2e9:	0f 8f 5f ff ff ff    	jg     a24e <fwp_write+0x81e>
    a2ef:	e9 d2 f7 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a2f4:	0f 1f 40 00          	nopl   0x0(%rax)
    a2f8:	ba 06 00 00 00       	mov    $0x6,%edx
    a2fd:	48 8d 35 b3 4e 00 00 	lea    0x4eb3(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    a304:	45 31 ed             	xor    %r13d,%r13d
    a307:	e8 64 9d ff ff       	call   4070 <buf_put>
    a30c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a311:	75 19                	jne    a32c <fwp_write+0x8fc>
    a313:	eb 6c                	jmp    a381 <fwp_write+0x951>
    a315:	0f 1f 00             	nopl   (%rax)
    a318:	ba 02 00 00 00       	mov    $0x2,%edx
    a31d:	48 8d 35 9d 4e 00 00 	lea    0x4e9d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a324:	48 89 df             	mov    %rbx,%rdi
    a327:	e8 44 9d ff ff       	call   4070 <buf_put>
    a32c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a332:	b9 00 02 00 00       	mov    $0x200,%ecx
    a337:	31 c0                	xor    %eax,%eax
    a339:	49 83 c5 01          	add    $0x1,%r13
    a33d:	4c 8d 05 7a 4e 00 00 	lea    0x4e7a(%rip),%r8        # f1be <_IO_stdin_used+0x1be>
    a344:	ba 02 00 00 00       	mov    $0x2,%edx
    a349:	be 00 02 00 00       	mov    $0x200,%esi
    a34e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a355:	00 
    a356:	e8 55 90 ff ff       	call   33b0 <__snprintf_chk@plt>
    a35b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a362:	00 
    a363:	e8 e8 90 ff ff       	call   3450 <strlen@plt>
    a368:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a36f:	00 
    a370:	48 89 df             	mov    %rbx,%rdi
    a373:	48 89 c2             	mov    %rax,%rdx
    a376:	e8 f5 9c ff ff       	call   4070 <buf_put>
    a37b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a37f:	72 97                	jb     a318 <fwp_write+0x8e8>
    a381:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a386:	ba 01 00 00 00       	mov    $0x1,%edx
    a38b:	48 89 df             	mov    %rbx,%rdi
    a38e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a393:	e8 d8 9c ff ff       	call   4070 <buf_put>
    a398:	e9 29 f7 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a39d:	0f 1f 00             	nopl   (%rax)
    a3a0:	83 f8 0b             	cmp    $0xb,%eax
    a3a3:	0f 85 1b ff ff ff    	jne    a2c4 <fwp_write+0x894>
    a3a9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a3ae:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a3b2:	83 e0 01             	and    $0x1,%eax
    a3b5:	85 c0                	test   %eax,%eax
    a3b7:	0f 84 07 ff ff ff    	je     a2c4 <fwp_write+0x894>
    a3bd:	4c 89 fe             	mov    %r15,%rsi
    a3c0:	48 89 df             	mov    %rbx,%rdi
    a3c3:	ba 01 00 00 00       	mov    $0x1,%edx
    a3c8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a3cd:	e8 9e 9c ff ff       	call   4070 <buf_put>
    a3d2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a3d7:	48 8b 34 24          	mov    (%rsp),%rsi
    a3db:	31 c9                	xor    %ecx,%ecx
    a3dd:	48 89 df             	mov    %rbx,%rdi
    a3e0:	e8 4b f6 ff ff       	call   9a30 <fwp_write>
    a3e5:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ea:	4c 89 fe             	mov    %r15,%rsi
    a3ed:	48 89 df             	mov    %rbx,%rdi
    a3f0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a3f5:	e8 76 9c ff ff       	call   4070 <buf_put>
    a3fa:	e9 d8 fe ff ff       	jmp    a2d7 <fwp_write+0x8a7>
    a3ff:	90                   	nop
    a400:	ba 01 00 00 00       	mov    $0x1,%edx
    a405:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a40a:	48 89 df             	mov    %rbx,%rdi
    a40d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a412:	e8 59 9c ff ff       	call   4070 <buf_put>
    a417:	e9 aa f6 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a41c:	0f 1f 40 00          	nopl   0x0(%rax)
    a420:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a425:	ba 01 00 00 00       	mov    $0x1,%edx
    a42a:	48 89 df             	mov    %rbx,%rdi
    a42d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a432:	e8 39 9c ff ff       	call   4070 <buf_put>
    a437:	e9 8a f6 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a43c:	0f 1f 40 00          	nopl   0x0(%rax)
    a440:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a444:	48 8b 13             	mov    (%rbx),%rdx
    a447:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a44c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a450:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a454:	e9 6d f6 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a460:	ba 02 00 00 00       	mov    $0x2,%edx
    a465:	48 8d 35 55 4d 00 00 	lea    0x4d55(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a46c:	48 89 df             	mov    %rbx,%rdi
    a46f:	e8 fc 9b ff ff       	call   4070 <buf_put>
    a474:	e9 72 f8 ff ff       	jmp    9ceb <fwp_write+0x2bb>
    a479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a480:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a485:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a48a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a48e:	48 89 f7             	mov    %rsi,%rdi
    a491:	48 89 34 24          	mov    %rsi,(%rsp)
    a495:	e8 b6 8f ff ff       	call   3450 <strlen@plt>
    a49a:	48 8b 34 24          	mov    (%rsp),%rsi
    a49e:	48 89 df             	mov    %rbx,%rdi
    a4a1:	48 89 c2             	mov    %rax,%rdx
    a4a4:	e8 c7 9b ff ff       	call   4070 <buf_put>
    a4a9:	ba 03 00 00 00       	mov    $0x3,%edx
    a4ae:	48 8d 35 2f 4d 00 00 	lea    0x4d2f(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    a4b5:	48 89 df             	mov    %rbx,%rdi
    a4b8:	e8 b3 9b ff ff       	call   4070 <buf_put>
    a4bd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a4c2:	e9 35 f8 ff ff       	jmp    9cfc <fwp_write+0x2cc>
    a4c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a4ce:	00 00 
    a4d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a4d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a4d9:	48 85 ff             	test   %rdi,%rdi
    a4dc:	0f 84 e2 fd ff ff    	je     a2c4 <fwp_write+0x894>
    a4e2:	48 8d 35 e5 4c 00 00 	lea    0x4ce5(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    a4e9:	e8 42 90 ff ff       	call   3530 <strcmp@plt>
    a4ee:	85 c0                	test   %eax,%eax
    a4f0:	0f 95 c0             	setne  %al
    a4f3:	0f b6 c0             	movzbl %al,%eax
    a4f6:	e9 c1 fd ff ff       	jmp    a2bc <fwp_write+0x88c>
    a4fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a500:	31 c0                	xor    %eax,%eax
    a502:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a509:	00 
    a50a:	0f 97 c0             	seta   %al
    a50d:	e9 aa fd ff ff       	jmp    a2bc <fwp_write+0x88c>
    a512:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a518:	48 89 df             	mov    %rbx,%rdi
    a51b:	ba 02 00 00 00       	mov    $0x2,%edx
    a520:	48 8d 35 a4 4c 00 00 	lea    0x4ca4(%rip),%rsi        # f1cb <_IO_stdin_used+0x1cb>
    a527:	e8 44 9b ff ff       	call   4070 <buf_put>
    a52c:	4c 89 e8             	mov    %r13,%rax
    a52f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a534:	31 c9                	xor    %ecx,%ecx
    a536:	48 c1 e0 04          	shl    $0x4,%rax
    a53a:	48 89 df             	mov    %rbx,%rdi
    a53d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a542:	e8 e9 f4 ff ff       	call   9a30 <fwp_write>
    a547:	e9 5e f6 ff ff       	jmp    9baa <fwp_write+0x17a>
    a54c:	0f 1f 40 00          	nopl   0x0(%rax)
    a550:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a555:	48 85 ff             	test   %rdi,%rdi
    a558:	79 0c                	jns    a566 <fwp_write+0xb36>
    a55a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a561:	00 
    a562:	48 03 75 10          	add    0x10(%rbp),%rsi
    a566:	48 63 3e             	movslq (%rsi),%rdi
    a569:	83 f9 02             	cmp    $0x2,%ecx
    a56c:	89 fe                	mov    %edi,%esi
    a56e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a572:	e9 f9 fb ff ff       	jmp    a170 <fwp_write+0x740>
    a577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a57e:	00 00 
    a580:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a585:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a58a:	48 85 ff             	test   %rdi,%rdi
    a58d:	0f 88 0f 03 00 00    	js     a8a2 <fwp_write+0xe72>
    a593:	49 0f bf 38          	movswq (%r8),%rdi
    a597:	83 f9 01             	cmp    $0x1,%ecx
    a59a:	0f b7 f7             	movzwl %di,%esi
    a59d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a5a1:	e9 ca fb ff ff       	jmp    a170 <fwp_write+0x740>
    a5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5ad:	00 00 00 
    a5b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a5b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5ba:	48 83 c5 08          	add    $0x8,%rbp
    a5be:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a5c3:	e8 a8 9a ff ff       	call   4070 <buf_put>
    a5c8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a5cd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a5d2:	4d 85 ed             	test   %r13,%r13
    a5d5:	75 46                	jne    a61d <fwp_write+0xbed>
    a5d7:	e9 04 01 00 00       	jmp    a6e0 <fwp_write+0xcb0>
    a5dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a5e0:	41 80 f9 09          	cmp    $0x9,%r9b
    a5e4:	0f 84 d6 00 00 00    	je     a6c0 <fwp_write+0xc90>
    a5ea:	41 80 f9 0a          	cmp    $0xa,%r9b
    a5ee:	0f 85 9c 00 00 00    	jne    a690 <fwp_write+0xc60>
    a5f4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5f9:	48 8d 35 a7 4b 00 00 	lea    0x4ba7(%rip),%rsi        # f1a7 <_IO_stdin_used+0x1a7>
    a600:	48 89 df             	mov    %rbx,%rdi
    a603:	e8 68 9a ff ff       	call   4070 <buf_put>
    a608:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a60f:	00 
    a610:	48 83 c5 01          	add    $0x1,%rbp
    a614:	49 39 ec             	cmp    %rbp,%r12
    a617:	0f 84 c3 00 00 00    	je     a6e0 <fwp_write+0xcb0>
    a61d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a622:	41 80 f9 0d          	cmp    $0xd,%r9b
    a626:	74 28                	je     a650 <fwp_write+0xc20>
    a628:	7e b6                	jle    a5e0 <fwp_write+0xbb0>
    a62a:	41 80 f9 22          	cmp    $0x22,%r9b
    a62e:	74 40                	je     a670 <fwp_write+0xc40>
    a630:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a634:	75 5a                	jne    a690 <fwp_write+0xc60>
    a636:	ba 02 00 00 00       	mov    $0x2,%edx
    a63b:	48 8d 35 62 4b 00 00 	lea    0x4b62(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    a642:	48 89 df             	mov    %rbx,%rdi
    a645:	e8 26 9a ff ff       	call   4070 <buf_put>
    a64a:	eb c4                	jmp    a610 <fwp_write+0xbe0>
    a64c:	0f 1f 40 00          	nopl   0x0(%rax)
    a650:	ba 02 00 00 00       	mov    $0x2,%edx
    a655:	48 8d 35 51 4b 00 00 	lea    0x4b51(%rip),%rsi        # f1ad <_IO_stdin_used+0x1ad>
    a65c:	48 89 df             	mov    %rbx,%rdi
    a65f:	e8 0c 9a ff ff       	call   4070 <buf_put>
    a664:	eb aa                	jmp    a610 <fwp_write+0xbe0>
    a666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a66d:	00 00 00 
    a670:	ba 02 00 00 00       	mov    $0x2,%edx
    a675:	48 8d 35 25 4b 00 00 	lea    0x4b25(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    a67c:	48 89 df             	mov    %rbx,%rdi
    a67f:	e8 ec 99 ff ff       	call   4070 <buf_put>
    a684:	eb 8a                	jmp    a610 <fwp_write+0xbe0>
    a686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a68d:	00 00 00 
    a690:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a694:	0f 86 2e 01 00 00    	jbe    a7c8 <fwp_write+0xd98>
    a69a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a69e:	0f 84 24 01 00 00    	je     a7c8 <fwp_write+0xd98>
    a6a4:	ba 01 00 00 00       	mov    $0x1,%edx
    a6a9:	4c 89 fe             	mov    %r15,%rsi
    a6ac:	48 89 df             	mov    %rbx,%rdi
    a6af:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a6b4:	e8 b7 99 ff ff       	call   4070 <buf_put>
    a6b9:	e9 52 ff ff ff       	jmp    a610 <fwp_write+0xbe0>
    a6be:	66 90                	xchg   %ax,%ax
    a6c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a6c5:	48 8d 35 de 4a 00 00 	lea    0x4ade(%rip),%rsi        # f1aa <_IO_stdin_used+0x1aa>
    a6cc:	48 89 df             	mov    %rbx,%rdi
    a6cf:	e8 9c 99 ff ff       	call   4070 <buf_put>
    a6d4:	e9 37 ff ff ff       	jmp    a610 <fwp_write+0xbe0>
    a6d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a6e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6e5:	4c 89 fe             	mov    %r15,%rsi
    a6e8:	48 89 df             	mov    %rbx,%rdi
    a6eb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a6f0:	e8 7b 99 ff ff       	call   4070 <buf_put>
    a6f5:	e9 cc f3 ff ff       	jmp    9ac6 <fwp_write+0x96>
    a6fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a700:	83 f8 04             	cmp    $0x4,%eax
    a703:	0f 85 bb fb ff ff    	jne    a2c4 <fwp_write+0x894>
    a709:	48 8b 04 24          	mov    (%rsp),%rax
    a70d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a711:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a716:	48 c1 e8 3f          	shr    $0x3f,%rax
    a71a:	e9 96 fc ff ff       	jmp    a3b5 <fwp_write+0x985>
    a71f:	90                   	nop
    a720:	8b 0c 24             	mov    (%rsp),%ecx
    a723:	31 c0                	xor    %eax,%eax
    a725:	85 c9                	test   %ecx,%ecx
    a727:	0f 98 c0             	sets   %al
    a72a:	e9 86 fc ff ff       	jmp    a3b5 <fwp_write+0x985>
    a72f:	90                   	nop
    a730:	48 f7 d8             	neg    %rax
    a733:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a73a:	00 
    a73b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a742:	2d 
    a743:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a74a:	00 
    a74b:	48 83 d2 00          	adc    $0x0,%rdx
    a74f:	48 89 c6             	mov    %rax,%rsi
    a752:	48 f7 da             	neg    %rdx
    a755:	e8 e6 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a75a:	e9 51 f3 ff ff       	jmp    9ab0 <fwp_write+0x80>
    a75f:	90                   	nop
    a760:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a765:	e9 c3 f5 ff ff       	jmp    9d2d <fwp_write+0x2fd>
    a76a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a770:	4c 89 e9             	mov    %r13,%rcx
    a773:	48 c1 e1 04          	shl    $0x4,%rcx
    a777:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a77c:	48 85 ff             	test   %rdi,%rdi
    a77f:	0f 89 eb f9 ff ff    	jns    a170 <fwp_write+0x740>
    a785:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a789:	48 89 ce             	mov    %rcx,%rsi
    a78c:	e9 df f9 ff ff       	jmp    a170 <fwp_write+0x740>
    a791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a798:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a79f:	00 
    a7a0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a7a4:	e9 20 fa ff ff       	jmp    a1c9 <fwp_write+0x799>
    a7a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7b0:	ba 02 00 00 00       	mov    $0x2,%edx
    a7b5:	48 8d 35 b0 49 00 00 	lea    0x49b0(%rip),%rsi        # f16c <_IO_stdin_used+0x16c>
    a7bc:	e9 2d f7 ff ff       	jmp    9eee <fwp_write+0x4be>
    a7c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a7c8:	4c 8d 05 e1 49 00 00 	lea    0x49e1(%rip),%r8        # f1b0 <_IO_stdin_used+0x1b0>
    a7cf:	b9 10 00 00 00       	mov    $0x10,%ecx
    a7d4:	31 c0                	xor    %eax,%eax
    a7d6:	ba 02 00 00 00       	mov    $0x2,%edx
    a7db:	be 10 00 00 00       	mov    $0x10,%esi
    a7e0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7e7:	00 
    a7e8:	e8 c3 8b ff ff       	call   33b0 <__snprintf_chk@plt>
    a7ed:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7f4:	00 
    a7f5:	e8 56 8c ff ff       	call   3450 <strlen@plt>
    a7fa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a801:	00 
    a802:	48 89 df             	mov    %rbx,%rdi
    a805:	48 89 c2             	mov    %rax,%rdx
    a808:	e8 63 98 ff ff       	call   4070 <buf_put>
    a80d:	e9 fe fd ff ff       	jmp    a610 <fwp_write+0xbe0>
    a812:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a818:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a81c:	48 8d 35 43 49 00 00 	lea    0x4943(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a823:	48 8d 05 3b 49 00 00 	lea    0x493b(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a82a:	4c 89 e7             	mov    %r12,%rdi
    a82d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a831:	48 0f 46 f0          	cmovbe %rax,%rsi
    a835:	e8 b6 8b ff ff       	call   33f0 <strcpy@plt>
    a83a:	e9 71 f2 ff ff       	jmp    9ab0 <fwp_write+0x80>
    a83f:	90                   	nop
    a840:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a844:	48 8d 35 1b 49 00 00 	lea    0x491b(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a84b:	48 8d 05 13 49 00 00 	lea    0x4913(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a852:	0f 2f c8             	comiss %xmm0,%xmm1
    a855:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a85c:	00 
    a85d:	4c 89 e7             	mov    %r12,%rdi
    a860:	48 0f 46 f0          	cmovbe %rax,%rsi
    a864:	e8 87 8b ff ff       	call   33f0 <strcpy@plt>
    a869:	e9 42 f2 ff ff       	jmp    9ab0 <fwp_write+0x80>
    a86e:	66 90                	xchg   %ax,%ax
    a870:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a875:	45 85 c0             	test   %r8d,%r8d
    a878:	75 34                	jne    a8ae <fwp_write+0xe7e>
    a87a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a881:	00 
    a882:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a889:	00 00 
    a88b:	0f 85 74 f6 ff ff    	jne    9f05 <fwp_write+0x4d5>
    a891:	ba 02 00 00 00       	mov    $0x2,%edx
    a896:	48 8d 35 44 49 00 00 	lea    0x4944(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    a89d:	e9 a1 f3 ff ff       	jmp    9c43 <fwp_write+0x213>
    a8a2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a8a6:	49 89 f0             	mov    %rsi,%r8
    a8a9:	e9 e5 fc ff ff       	jmp    a593 <fwp_write+0xb63>
    a8ae:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a8b3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8b8:	85 ff                	test   %edi,%edi
    a8ba:	0f 84 fa f3 ff ff    	je     9cba <fwp_write+0x28a>
    a8c0:	ba 01 00 00 00       	mov    $0x1,%edx
    a8c5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a8ca:	48 89 df             	mov    %rbx,%rdi
    a8cd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a8d2:	e8 99 97 ff ff       	call   4070 <buf_put>
    a8d7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a8dc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a8e1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a8e7:	85 c0                	test   %eax,%eax
    a8e9:	0f 8f f0 f3 ff ff    	jg     9cdf <fwp_write+0x2af>
    a8ef:	e9 34 f4 ff ff       	jmp    9d28 <fwp_write+0x2f8>
    a8f4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a8f8:	49 89 c5             	mov    %rax,%r13
    a8fb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a900:	49 89 c4             	mov    %rax,%r12
    a903:	49 c1 fd 3f          	sar    $0x3f,%r13
    a907:	4c 09 e8             	or     %r13,%rax
    a90a:	0f 84 a7 00 00 00    	je     a9b7 <fwp_write+0xf87>
    a910:	48 8d 2d 09 6b 00 00 	lea    0x6b09(%rip),%rbp        # 11420 <units.1>
    a917:	4d 89 e7             	mov    %r12,%r15
    a91a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a91e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a923:	4c 89 ff             	mov    %r15,%rdi
    a926:	4c 89 ee             	mov    %r13,%rsi
    a929:	44 89 0c 24          	mov    %r9d,(%rsp)
    a92d:	48 99                	cqto
    a92f:	48 89 d1             	mov    %rdx,%rcx
    a932:	48 89 c2             	mov    %rax,%rdx
    a935:	e8 86 41 00 00       	call   eac0 <__divmodti4>
    a93a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a93e:	48 89 c1             	mov    %rax,%rcx
    a941:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a946:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a94b:	0f 84 94 00 00 00    	je     a9e5 <fwp_write+0xfb5>
    a951:	41 83 c1 01          	add    $0x1,%r9d
    a955:	48 83 c5 10          	add    $0x10,%rbp
    a959:	41 83 f9 05          	cmp    $0x5,%r9d
    a95d:	75 bb                	jne    a91a <fwp_write+0xeea>
    a95f:	4d 85 ed             	test   %r13,%r13
    a962:	79 53                	jns    a9b7 <fwp_write+0xf87>
    a964:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a969:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a96e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a973:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a978:	48 99                	cqto
    a97a:	48 f7 d8             	neg    %rax
    a97d:	48 83 d2 00          	adc    $0x0,%rdx
    a981:	48 89 c6             	mov    %rax,%rsi
    a984:	48 f7 da             	neg    %rdx
    a987:	e8 b4 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a98c:	49 89 e8             	mov    %rbp,%r8
    a98f:	ba 00 02 00 00       	mov    $0x200,%edx
    a994:	be 02 00 00 00       	mov    $0x2,%esi
    a999:	31 c0                	xor    %eax,%eax
    a99b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9a2:	00 
    a9a3:	48 8d 0d 32 48 00 00 	lea    0x4832(%rip),%rcx        # f1dc <_IO_stdin_used+0x1dc>
    a9aa:	4c 89 e7             	mov    %r12,%rdi
    a9ad:	e8 2e 8d ff ff       	call   36e0 <__sprintf_chk@plt>
    a9b2:	e9 f9 f0 ff ff       	jmp    9ab0 <fwp_write+0x80>
    a9b7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9bc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a9c1:	31 d2                	xor    %edx,%edx
    a9c3:	48 89 ef             	mov    %rbp,%rdi
    a9c6:	e8 75 90 ff ff       	call   3a40 <fwp_fmt_u128>
    a9cb:	eb bf                	jmp    a98c <fwp_write+0xf5c>
    a9cd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a9d4:	4e 61 4e 00 
    a9d8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9df:	00 
    a9e0:	e9 cb f0 ff ff       	jmp    9ab0 <fwp_write+0x80>
    a9e5:	44 89 0c 24          	mov    %r9d,(%rsp)
    a9e9:	48 89 c8             	mov    %rcx,%rax
    a9ec:	48 85 d2             	test   %rdx,%rdx
    a9ef:	78 51                	js     aa42 <fwp_write+0x1012>
    a9f1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a9f6:	48 89 c6             	mov    %rax,%rsi
    a9f9:	48 89 ef             	mov    %rbp,%rdi
    a9fc:	e8 3f 90 ff ff       	call   3a40 <fwp_fmt_u128>
    aa01:	44 8b 0c 24          	mov    (%rsp),%r9d
    aa05:	49 63 c1             	movslq %r9d,%rax
    aa08:	49 89 e8             	mov    %rbp,%r8
    aa0b:	ba 00 02 00 00       	mov    $0x200,%edx
    aa10:	be 02 00 00 00       	mov    $0x2,%esi
    aa15:	48 c1 e0 04          	shl    $0x4,%rax
    aa19:	48 8d 3d 00 6a 00 00 	lea    0x6a00(%rip),%rdi        # 11420 <units.1>
    aa20:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    aa27:	00 
    aa28:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    aa2c:	48 8d 0d a4 47 00 00 	lea    0x47a4(%rip),%rcx        # f1d7 <_IO_stdin_used+0x1d7>
    aa33:	4c 89 e7             	mov    %r12,%rdi
    aa36:	31 c0                	xor    %eax,%eax
    aa38:	e8 a3 8c ff ff       	call   36e0 <__sprintf_chk@plt>
    aa3d:	e9 6e f0 ff ff       	jmp    9ab0 <fwp_write+0x80>
    aa42:	48 f7 d8             	neg    %rax
    aa45:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aa4a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aa4f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aa54:	48 83 d2 00          	adc    $0x0,%rdx
    aa58:	48 89 c6             	mov    %rax,%rsi
    aa5b:	48 f7 da             	neg    %rdx
    aa5e:	e8 dd 8f ff ff       	call   3a40 <fwp_fmt_u128>
    aa63:	44 8b 0c 24          	mov    (%rsp),%r9d
    aa67:	eb 9c                	jmp    aa05 <fwp_write+0xfd5>
    aa69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aa70 <fwp_hof0.constprop.0>:
    aa70:	55                   	push   %rbp
    aa71:	48 89 e5             	mov    %rsp,%rbp
    aa74:	41 57                	push   %r15
    aa76:	41 56                	push   %r14
    aa78:	41 55                	push   %r13
    aa7a:	41 54                	push   %r12
    aa7c:	53                   	push   %rbx
    aa7d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    aa84:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    aa8b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aa92:	00 00 
    aa94:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aa98:	31 c0                	xor    %eax,%eax
    aa9a:	48 85 f6             	test   %rsi,%rsi
    aa9d:	0f 84 76 06 00 00    	je     b119 <fwp_hof0.constprop.0+0x6a9>
    aaa3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    aaa7:	49 89 f7             	mov    %rsi,%r15
    aaaa:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    aab1:	48 8d 35 c8 8c 01 00 	lea    0x18cc8(%rip),%rsi        # 23780 <fwp_heap>
    aab8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    aabf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    aac6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    aacd:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    aad1:	48 c1 e2 10          	shl    $0x10,%rdx
    aad5:	48 39 d0             	cmp    %rdx,%rax
    aad8:	73 5d                	jae    ab37 <fwp_hof0.constprop.0+0xc7>
    aada:	48 89 c2             	mov    %rax,%rdx
    aadd:	48 c1 ea 10          	shr    $0x10,%rdx
    aae1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aae5:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    aaec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aaf0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    aaf4:	48 85 ff             	test   %rdi,%rdi
    aaf7:	74 3e                	je     ab37 <fwp_hof0.constprop.0+0xc7>
    aaf9:	0f b6 0a             	movzbl (%rdx),%ecx
    aafc:	80 f9 02             	cmp    $0x2,%cl
    aaff:	0f 84 bd 0a 00 00    	je     b5c2 <fwp_hof0.constprop.0+0xb52>
    ab05:	80 f9 01             	cmp    $0x1,%cl
    ab08:	75 2d                	jne    ab37 <fwp_hof0.constprop.0+0xc7>
    ab0a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ab0d:	0f b7 c0             	movzwl %ax,%eax
    ab10:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab13:	48 0f af c1          	imul   %rcx,%rax
    ab17:	48 c1 e8 20          	shr    $0x20,%rax
    ab1b:	48 39 d0             	cmp    %rdx,%rax
    ab1e:	73 17                	jae    ab37 <fwp_hof0.constprop.0+0xc7>
    ab20:	48 01 c7             	add    %rax,%rdi
    ab23:	0f b6 07             	movzbl (%rdi),%eax
    ab26:	84 c0                	test   %al,%al
    ab28:	74 0d                	je     ab37 <fwp_hof0.constprop.0+0xc7>
    ab2a:	3c fd                	cmp    $0xfd,%al
    ab2c:	0f 87 6e 0b 00 00    	ja     b6a0 <fwp_hof0.constprop.0+0xc30>
    ab32:	83 c0 01             	add    $0x1,%eax
    ab35:	88 07                	mov    %al,(%rdi)
    ab37:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    ab3e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    ab45:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    ab4c:	c7 00 00 00 
    ab50:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ab54:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ab58:	48 8b 15 79 a8 01 00 	mov    0x1a879(%rip),%rdx        # 253d8 <fwp_fns>
    ab5f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    ab63:	48 8d 05 ae 84 00 00 	lea    0x84ae(%rip),%rax        # 13018 <fc12>
    ab6a:	44 8b 20             	mov    (%rax),%r12d
    ab6d:	49 c1 e4 05          	shl    $0x5,%r12
    ab71:	49 01 d4             	add    %rdx,%r12
    ab74:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    ab79:	48 85 c9             	test   %rcx,%rcx
    ab7c:	0f 84 0d 0a 00 00    	je     b58f <fwp_hof0.constprop.0+0xb1f>
    ab82:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    ab87:	0f 84 6b 08 00 00    	je     b3f8 <fwp_hof0.constprop.0+0x988>
    ab8d:	48 8d 3d ec 8b 01 00 	lea    0x18bec(%rip),%rdi        # 23780 <fwp_heap>
    ab94:	48 8d 05 7d 84 00 00 	lea    0x847d(%rip),%rax        # 13018 <fc12>
    ab9b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    aba2:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    aba9:	48 89 f1             	mov    %rsi,%rcx
    abac:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    abb0:	48 c1 e1 10          	shl    $0x10,%rcx
    abb4:	48 39 c8             	cmp    %rcx,%rax
    abb7:	73 5f                	jae    ac18 <fwp_hof0.constprop.0+0x1a8>
    abb9:	48 89 c1             	mov    %rax,%rcx
    abbc:	48 c1 e9 10          	shr    $0x10,%rcx
    abc0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    abc4:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    abcb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    abcf:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    abd3:	48 85 ff             	test   %rdi,%rdi
    abd6:	74 40                	je     ac18 <fwp_hof0.constprop.0+0x1a8>
    abd8:	0f b6 31             	movzbl (%rcx),%esi
    abdb:	40 80 fe 02          	cmp    $0x2,%sil
    abdf:	0f 84 f8 08 00 00    	je     b4dd <fwp_hof0.constprop.0+0xa6d>
    abe5:	40 80 fe 01          	cmp    $0x1,%sil
    abe9:	75 2d                	jne    ac18 <fwp_hof0.constprop.0+0x1a8>
    abeb:	8b 71 18             	mov    0x18(%rcx),%esi
    abee:	0f b7 c0             	movzwl %ax,%eax
    abf1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abf4:	48 0f af c6          	imul   %rsi,%rax
    abf8:	48 c1 e8 20          	shr    $0x20,%rax
    abfc:	48 39 c8             	cmp    %rcx,%rax
    abff:	73 17                	jae    ac18 <fwp_hof0.constprop.0+0x1a8>
    ac01:	48 01 c7             	add    %rax,%rdi
    ac04:	0f b6 07             	movzbl (%rdi),%eax
    ac07:	84 c0                	test   %al,%al
    ac09:	74 0d                	je     ac18 <fwp_hof0.constprop.0+0x1a8>
    ac0b:	3c fd                	cmp    $0xfd,%al
    ac0d:	0f 87 56 09 00 00    	ja     b569 <fwp_hof0.constprop.0+0xaf9>
    ac13:	83 c0 01             	add    $0x1,%eax
    ac16:	88 07                	mov    %al,(%rdi)
    ac18:	48 8d 05 f9 83 00 00 	lea    0x83f9(%rip),%rax        # 13018 <fc12>
    ac1f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    ac26:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ac2a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    ac31:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ac35:	48 8d 05 dc 83 00 00 	lea    0x83dc(%rip),%rax        # 13018 <fc12>
    ac3c:	41 8b 0c 24          	mov    (%r12),%ecx
    ac40:	2b 48 04             	sub    0x4(%rax),%ecx
    ac43:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ac47:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    ac4b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    ac4e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ac52:	49 89 c1             	mov    %rax,%r9
    ac55:	8b 00                	mov    (%rax),%eax
    ac57:	44 39 e9             	cmp    %r13d,%ecx
    ac5a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    ac5e:	4d 89 cf             	mov    %r9,%r15
    ac61:	48 c1 e0 05          	shl    $0x5,%rax
    ac65:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    ac69:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    ac70:	4d 8b 50 18          	mov    0x18(%r8),%r10
    ac74:	4d 85 d2             	test   %r10,%r10
    ac77:	75 58                	jne    acd1 <fwp_hof0.constprop.0+0x261>
    ac79:	e9 e5 01 00 00       	jmp    ae63 <fwp_hof0.constprop.0+0x3f3>
    ac7e:	66 90                	xchg   %ax,%ax
    ac80:	45 85 ff             	test   %r15d,%r15d
    ac83:	74 69                	je     acee <fwp_hof0.constprop.0+0x27e>
    ac85:	4c 89 e7             	mov    %r12,%rdi
    ac88:	41 ff 12             	call   *(%r10)
    ac8b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac8f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    ac93:	e8 58 c3 ff ff       	call   6ff0 <fwp_closure_drop>
    ac98:	44 39 eb             	cmp    %r13d,%ebx
    ac9b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    ac9f:	0f 84 43 07 00 00    	je     b3e8 <fwp_hof0.constprop.0+0x978>
    aca5:	44 8b 00             	mov    (%rax),%r8d
    aca8:	45 29 fe             	sub    %r15d,%r14d
    acab:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    acaf:	49 89 c1             	mov    %rax,%r9
    acb2:	45 89 f5             	mov    %r14d,%r13d
    acb5:	49 c1 e0 05          	shl    $0x5,%r8
    acb9:	4c 03 05 18 a7 01 00 	add    0x1a718(%rip),%r8        # 253d8 <fwp_fns>
    acc0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    acc4:	4d 85 d2             	test   %r10,%r10
    acc7:	0f 84 93 01 00 00    	je     ae60 <fwp_hof0.constprop.0+0x3f0>
    accd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    acd1:	41 8b 49 04          	mov    0x4(%r9),%ecx
    acd5:	45 8b 38             	mov    (%r8),%r15d
    acd8:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    acdc:	45 39 fe             	cmp    %r15d,%r14d
    acdf:	0f 82 5b 04 00 00    	jb     b140 <fwp_hof0.constprop.0+0x6d0>
    ace5:	44 89 fb             	mov    %r15d,%ebx
    ace8:	29 cb                	sub    %ecx,%ebx
    acea:	85 c9                	test   %ecx,%ecx
    acec:	74 92                	je     ac80 <fwp_hof0.constprop.0+0x210>
    acee:	45 85 ff             	test   %r15d,%r15d
    acf1:	b8 01 00 00 00       	mov    $0x1,%eax
    acf6:	48 89 e6             	mov    %rsp,%rsi
    acf9:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    acfd:	41 0f 45 c7          	cmovne %r15d,%eax
    ad01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    ad08:	00 
    ad09:	48 c1 e8 04          	shr    $0x4,%rax
    ad0d:	48 c1 e0 04          	shl    $0x4,%rax
    ad11:	48 89 c7             	mov    %rax,%rdi
    ad14:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    ad1b:	48 29 fe             	sub    %rdi,%rsi
    ad1e:	48 39 f4             	cmp    %rsi,%rsp
    ad21:	74 15                	je     ad38 <fwp_hof0.constprop.0+0x2c8>
    ad23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    ad2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    ad31:	00 00 
    ad33:	48 39 f4             	cmp    %rsi,%rsp
    ad36:	75 eb                	jne    ad23 <fwp_hof0.constprop.0+0x2b3>
    ad38:	25 ff 0f 00 00       	and    $0xfff,%eax
    ad3d:	48 29 c4             	sub    %rax,%rsp
    ad40:	48 85 c0             	test   %rax,%rax
    ad43:	74 06                	je     ad4b <fwp_hof0.constprop.0+0x2db>
    ad45:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    ad4b:	89 cf                	mov    %ecx,%edi
    ad4d:	49 89 e3             	mov    %rsp,%r11
    ad50:	31 c0                	xor    %eax,%eax
    ad52:	48 c1 e7 03          	shl    $0x3,%rdi
    ad56:	85 c9                	test   %ecx,%ecx
    ad58:	74 18                	je     ad72 <fwp_hof0.constprop.0+0x302>
    ad5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad60:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    ad65:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    ad69:	48 83 c0 08          	add    $0x8,%rax
    ad6d:	48 39 c7             	cmp    %rax,%rdi
    ad70:	75 ee                	jne    ad60 <fwp_hof0.constprop.0+0x2f0>
    ad72:	85 db                	test   %ebx,%ebx
    ad74:	74 1f                	je     ad95 <fwp_hof0.constprop.0+0x325>
    ad76:	89 de                	mov    %ebx,%esi
    ad78:	4c 89 e0             	mov    %r12,%rax
    ad7b:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    ad7f:	90                   	nop
    ad80:	48 8b 30             	mov    (%rax),%rsi
    ad83:	89 ca                	mov    %ecx,%edx
    ad85:	48 83 c0 08          	add    $0x8,%rax
    ad89:	83 c1 01             	add    $0x1,%ecx
    ad8c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    ad90:	48 39 c7             	cmp    %rax,%rdi
    ad93:	75 eb                	jne    ad80 <fwp_hof0.constprop.0+0x310>
    ad95:	48 8d 15 e4 89 01 00 	lea    0x189e4(%rip),%rdx        # 23780 <fwp_heap>
    ad9c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ada0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    ada7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    adae:	48 89 f1             	mov    %rsi,%rcx
    adb1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    adb5:	48 c1 e1 10          	shl    $0x10,%rcx
    adb9:	48 39 c8             	cmp    %rcx,%rax
    adbc:	73 4c                	jae    ae0a <fwp_hof0.constprop.0+0x39a>
    adbe:	48 89 c1             	mov    %rax,%rcx
    adc1:	48 c1 e9 10          	shr    $0x10,%rcx
    adc5:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    adc9:	48 8b 0d a8 9d 01 00 	mov    0x19da8(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    add0:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    add4:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    add8:	48 85 f6             	test   %rsi,%rsi
    addb:	74 2d                	je     ae0a <fwp_hof0.constprop.0+0x39a>
    addd:	0f b6 39             	movzbl (%rcx),%edi
    ade0:	40 80 ff 02          	cmp    $0x2,%dil
    ade4:	74 6a                	je     ae50 <fwp_hof0.constprop.0+0x3e0>
    ade6:	40 80 ff 01          	cmp    $0x1,%dil
    adea:	75 1e                	jne    ae0a <fwp_hof0.constprop.0+0x39a>
    adec:	8b 79 18             	mov    0x18(%rcx),%edi
    adef:	0f b7 c0             	movzwl %ax,%eax
    adf2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    adf5:	48 0f af c7          	imul   %rdi,%rax
    adf9:	48 c1 e8 20          	shr    $0x20,%rax
    adfd:	48 39 c8             	cmp    %rcx,%rax
    ae00:	73 08                	jae    ae0a <fwp_hof0.constprop.0+0x39a>
    ae02:	48 01 c6             	add    %rax,%rsi
    ae05:	80 3e 01             	cmpb   $0x1,(%rsi)
    ae08:	74 36                	je     ae40 <fwp_hof0.constprop.0+0x3d0>
    ae0a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    ae0e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ae12:	be 01 00 00 00       	mov    $0x1,%esi
    ae17:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    ae1b:	41 ff 52 08          	call   *0x8(%r10)
    ae1f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    ae23:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    ae27:	49 8b 40 18          	mov    0x18(%r8),%rax
    ae2b:	4c 89 df             	mov    %r11,%rdi
    ae2e:	ff 10                	call   *(%rax)
    ae30:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    ae34:	e9 52 fe ff ff       	jmp    ac8b <fwp_hof0.constprop.0+0x21b>
    ae39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae40:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ae47:	00 
    ae48:	eb dd                	jmp    ae27 <fwp_hof0.constprop.0+0x3b7>
    ae4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae50:	66 85 c0             	test   %ax,%ax
    ae53:	75 b5                	jne    ae0a <fwp_hof0.constprop.0+0x39a>
    ae55:	eb ae                	jmp    ae05 <fwp_hof0.constprop.0+0x395>
    ae57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ae5e:	00 00 
    ae60:	49 89 c7             	mov    %rax,%r15
    ae63:	4c 89 ff             	mov    %r15,%rdi
    ae66:	e8 65 ba ff ff       	call   68d0 <fwp_rc_share>
    ae6b:	45 85 ed             	test   %r13d,%r13d
    ae6e:	74 21                	je     ae91 <fwp_hof0.constprop.0+0x421>
    ae70:	44 89 ea             	mov    %r13d,%edx
    ae73:	4c 89 e3             	mov    %r12,%rbx
    ae76:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    ae7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae80:	48 8b 3b             	mov    (%rbx),%rdi
    ae83:	48 83 c3 08          	add    $0x8,%rbx
    ae87:	e8 44 ba ff ff       	call   68d0 <fwp_rc_share>
    ae8c:	4c 39 f3             	cmp    %r14,%rbx
    ae8f:	75 ef                	jne    ae80 <fwp_hof0.constprop.0+0x410>
    ae91:	4c 89 e2             	mov    %r12,%rdx
    ae94:	44 89 ee             	mov    %r13d,%esi
    ae97:	4c 89 ff             	mov    %r15,%rdi
    ae9a:	e8 d1 ac ff ff       	call   5b70 <fwp_apply>
    ae9f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aea3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    aea6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    aea9:	0f 83 87 00 00 00    	jae    af36 <fwp_hof0.constprop.0+0x4c6>
    aeaf:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    aeb5:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    aeb9:	48 89 c2             	mov    %rax,%rdx
    aebc:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    aec0:	29 d6                	sub    %edx,%esi
    aec2:	48 8b 15 0f a5 01 00 	mov    0x1a50f(%rip),%rdx        # 253d8 <fwp_fns>
    aec9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aecd:	89 75 94             	mov    %esi,-0x6c(%rbp)
    aed0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    aed4:	44 8b 26             	mov    (%rsi),%r12d
    aed7:	48 89 f0             	mov    %rsi,%rax
    aeda:	49 c1 e4 05          	shl    $0x5,%r12
    aede:	49 01 d4             	add    %rdx,%r12
    aee1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    aee7:	0f 85 4f fd ff ff    	jne    ac3c <fwp_hof0.constprop.0+0x1cc>
    aeed:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    aef1:	e8 da b9 ff ff       	call   68d0 <fwp_rc_share>
    aef6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    aefa:	45 85 f6             	test   %r14d,%r14d
    aefd:	74 23                	je     af22 <fwp_hof0.constprop.0+0x4b2>
    aeff:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    af03:	31 db                	xor    %ebx,%ebx
    af05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af0c:	00 00 00 00 
    af10:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    af14:	48 83 c3 01          	add    $0x1,%rbx
    af18:	e8 b3 b9 ff ff       	call   68d0 <fwp_rc_share>
    af1d:	44 39 f3             	cmp    %r14d,%ebx
    af20:	72 ee                	jb     af10 <fwp_hof0.constprop.0+0x4a0>
    af22:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    af26:	8b 75 94             	mov    -0x6c(%rbp),%esi
    af29:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af2d:	e8 3e ac ff ff       	call   5b70 <fwp_apply>
    af32:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af36:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    af3d:	01 
    af3e:	0f 85 10 fc ff ff    	jne    ab54 <fwp_hof0.constprop.0+0xe4>
    af44:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    af48:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    af4f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af53:	b9 01 00 00 00       	mov    $0x1,%ecx
    af58:	48 8d 15 41 7c 00 00 	lea    0x7c41(%rip),%rdx        # 12ba0 <d0>
    af5f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    af66:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    af6d:	00 
    af6e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    af72:	e8 b9 ea ff ff       	call   9a30 <fwp_write>
    af77:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    af7b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    af7f:	48 8d 05 a8 40 00 00 	lea    0x40a8(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    af86:	48 85 c9             	test   %rcx,%rcx
    af89:	48 0f 44 c8          	cmove  %rax,%rcx
    af8d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    af91:	0f 87 f5 06 00 00    	ja     b68c <fwp_hof0.constprop.0+0xc1c>
    af97:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    af9b:	be 01 00 00 00       	mov    $0x1,%esi
    afa0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    afa4:	e8 a7 aa ff ff       	call   5a50 <fwp_heap_alloc>
    afa9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    afad:	4c 89 f2             	mov    %r14,%rdx
    afb0:	4c 89 30             	mov    %r14,(%rax)
    afb3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    afb7:	48 89 c3             	mov    %rax,%rbx
    afba:	4c 89 e7             	mov    %r12,%rdi
    afbd:	e8 de 85 ff ff       	call   35a0 <memcpy@plt>
    afc2:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    afc8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    afcc:	e8 ef 83 ff ff       	call   33c0 <free@plt>
    afd1:	48 8d 35 a8 87 01 00 	lea    0x187a8(%rip),%rsi        # 23780 <fwp_heap>
    afd8:	48 89 d8             	mov    %rbx,%rax
    afdb:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    afe2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    afe9:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    afed:	48 c1 e2 10          	shl    $0x10,%rdx
    aff1:	48 39 d0             	cmp    %rdx,%rax
    aff4:	73 57                	jae    b04d <fwp_hof0.constprop.0+0x5dd>
    aff6:	48 89 c2             	mov    %rax,%rdx
    aff9:	48 c1 ea 10          	shr    $0x10,%rdx
    affd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b001:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b008:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b00c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b010:	4d 85 f6             	test   %r14,%r14
    b013:	74 38                	je     b04d <fwp_hof0.constprop.0+0x5dd>
    b015:	0f b6 0a             	movzbl (%rdx),%ecx
    b018:	80 f9 02             	cmp    $0x2,%cl
    b01b:	0f 84 c9 05 00 00    	je     b5ea <fwp_hof0.constprop.0+0xb7a>
    b021:	80 f9 01             	cmp    $0x1,%cl
    b024:	75 27                	jne    b04d <fwp_hof0.constprop.0+0x5dd>
    b026:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b029:	0f b7 c0             	movzwl %ax,%eax
    b02c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b02f:	48 0f af c1          	imul   %rcx,%rax
    b033:	48 c1 e8 20          	shr    $0x20,%rax
    b037:	48 39 d0             	cmp    %rdx,%rax
    b03a:	73 11                	jae    b04d <fwp_hof0.constprop.0+0x5dd>
    b03c:	49 01 c6             	add    %rax,%r14
    b03f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b043:	0f 84 67 06 00 00    	je     b6b0 <fwp_hof0.constprop.0+0xc40>
    b049:	41 c6 06 01          	movb   $0x1,(%r14)
    b04d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b051:	e8 ba bc ff ff       	call   6d10 <fwp_drop0>
    b056:	48 8b 13             	mov    (%rbx),%rdx
    b059:	be 01 00 00 00       	mov    $0x1,%esi
    b05e:	4c 89 e7             	mov    %r12,%rdi
    b061:	48 8b 0d 78 a3 01 00 	mov    0x1a378(%rip),%rcx        # 253e0 <fwp_prog_out>
    b068:	e8 13 86 ff ff       	call   3680 <fwrite@plt>
    b06d:	48 8b 35 6c a3 01 00 	mov    0x1a36c(%rip),%rsi        # 253e0 <fwp_prog_out>
    b074:	bf 0a 00 00 00       	mov    $0xa,%edi
    b079:	e8 62 84 ff ff       	call   34e0 <fputc@plt>
    b07e:	48 8d 35 fb 86 01 00 	lea    0x186fb(%rip),%rsi        # 23780 <fwp_heap>
    b085:	48 89 d8             	mov    %rbx,%rax
    b088:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b08f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b096:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    b09a:	48 c1 e2 10          	shl    $0x10,%rdx
    b09e:	48 39 d0             	cmp    %rdx,%rax
    b0a1:	73 69                	jae    b10c <fwp_hof0.constprop.0+0x69c>
    b0a3:	48 89 c2             	mov    %rax,%rdx
    b0a6:	48 c1 ea 10          	shr    $0x10,%rdx
    b0aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0ae:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b0b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b0bd:	4d 85 e4             	test   %r12,%r12
    b0c0:	74 4a                	je     b10c <fwp_hof0.constprop.0+0x69c>
    b0c2:	0f b6 0a             	movzbl (%rdx),%ecx
    b0c5:	80 f9 02             	cmp    $0x2,%cl
    b0c8:	0f 84 2a 05 00 00    	je     b5f8 <fwp_hof0.constprop.0+0xb88>
    b0ce:	80 f9 01             	cmp    $0x1,%cl
    b0d1:	75 39                	jne    b10c <fwp_hof0.constprop.0+0x69c>
    b0d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0d6:	0f b7 c0             	movzwl %ax,%eax
    b0d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0dc:	48 0f af c1          	imul   %rcx,%rax
    b0e0:	48 c1 e8 20          	shr    $0x20,%rax
    b0e4:	48 39 d0             	cmp    %rdx,%rax
    b0e7:	73 23                	jae    b10c <fwp_hof0.constprop.0+0x69c>
    b0e9:	49 01 c4             	add    %rax,%r12
    b0ec:	41 0f b6 04 24       	movzbl (%r12),%eax
    b0f1:	84 c0                	test   %al,%al
    b0f3:	74 17                	je     b10c <fwp_hof0.constprop.0+0x69c>
    b0f5:	3c 01                	cmp    $0x1,%al
    b0f7:	0f 84 d3 04 00 00    	je     b5d0 <fwp_hof0.constprop.0+0xb60>
    b0fd:	3c ff                	cmp    $0xff,%al
    b0ff:	0f 84 01 05 00 00    	je     b606 <fwp_hof0.constprop.0+0xb96>
    b105:	83 e8 01             	sub    $0x1,%eax
    b108:	41 88 04 24          	mov    %al,(%r12)
    b10c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b110:	4d 85 ff             	test   %r15,%r15
    b113:	0f 85 98 f9 ff ff    	jne    aab1 <fwp_hof0.constprop.0+0x41>
    b119:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b11d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b124:	00 00 
    b126:	0f 85 7e 05 00 00    	jne    b6aa <fwp_hof0.constprop.0+0xc3a>
    b12c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b130:	31 c0                	xor    %eax,%eax
    b132:	5b                   	pop    %rbx
    b133:	41 5c                	pop    %r12
    b135:	41 5d                	pop    %r13
    b137:	41 5e                	pop    %r14
    b139:	41 5f                	pop    %r15
    b13b:	5d                   	pop    %rbp
    b13c:	c3                   	ret
    b13d:	0f 1f 00             	nopl   (%rax)
    b140:	48 8d 1d 39 86 01 00 	lea    0x18639(%rip),%rbx        # 23780 <fwp_heap>
    b147:	41 8d 76 01          	lea    0x1(%r14),%esi
    b14b:	45 89 f7             	mov    %r14d,%r15d
    b14e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b154:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b15b:	00 
    b15c:	85 c0                	test   %eax,%eax
    b15e:	0f 84 a9 03 00 00    	je     b50d <fwp_hof0.constprop.0+0xa9d>
    b164:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b16b:	0f 87 9c 03 00 00    	ja     b50d <fwp_hof0.constprop.0+0xa9d>
    b171:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b175:	48 c1 e8 04          	shr    $0x4,%rax
    b179:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b180:	00 
    b181:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b188:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b18c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b190:	4c 8b 12             	mov    (%rdx),%r10
    b193:	4d 85 d2             	test   %r10,%r10
    b196:	0f 84 4f 03 00 00    	je     b4eb <fwp_hof0.constprop.0+0xa7b>
    b19c:	4d 8b 1a             	mov    (%r10),%r11
    b19f:	49 f7 d3             	not    %r11
    b1a2:	4c 89 1a             	mov    %r11,(%rdx)
    b1a5:	48 39 c7             	cmp    %rax,%rdi
    b1a8:	73 50                	jae    b1fa <fwp_hof0.constprop.0+0x78a>
    b1aa:	48 89 fa             	mov    %rdi,%rdx
    b1ad:	48 83 c7 08          	add    $0x8,%rdi
    b1b1:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b1b8:	00 
    b1b9:	48 f7 d2             	not    %rdx
    b1bc:	48 01 c2             	add    %rax,%rdx
    b1bf:	48 c1 ea 03          	shr    $0x3,%rdx
    b1c3:	48 39 c7             	cmp    %rax,%rdi
    b1c6:	73 32                	jae    b1fa <fwp_hof0.constprop.0+0x78a>
    b1c8:	83 e2 01             	and    $0x1,%edx
    b1cb:	74 13                	je     b1e0 <fwp_hof0.constprop.0+0x770>
    b1cd:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b1d4:	00 
    b1d5:	48 83 c7 08          	add    $0x8,%rdi
    b1d9:	48 39 c7             	cmp    %rax,%rdi
    b1dc:	73 1c                	jae    b1fa <fwp_hof0.constprop.0+0x78a>
    b1de:	66 90                	xchg   %ax,%ax
    b1e0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b1e7:	00 
    b1e8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b1ef:	00 00 
    b1f1:	48 83 c7 10          	add    $0x10,%rdi
    b1f5:	48 39 c7             	cmp    %rax,%rdi
    b1f8:	72 e6                	jb     b1e0 <fwp_hof0.constprop.0+0x770>
    b1fa:	48 8d 35 7f 85 01 00 	lea    0x1857f(%rip),%rsi        # 23780 <fwp_heap>
    b201:	48 89 c2             	mov    %rax,%rdx
    b204:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    b20b:	0f 82 6a 04 00 00    	jb     b67b <fwp_hof0.constprop.0+0xc0b>
    b211:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    b218:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    b21f:	73 07                	jae    b228 <fwp_hof0.constprop.0+0x7b8>
    b221:	48 89 15 80 99 01 00 	mov    %rdx,0x19980(%rip)        # 24ba8 <fwp_heap+0x1428>
    b228:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b22c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b231:	f2 0f 58 05 7f 99 01 	addsd  0x1997f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    b238:	00 
    b239:	f2 0f 11 05 77 99 01 	movsd  %xmm0,0x19977(%rip)        # 24bb8 <fwp_heap+0x1438>
    b240:	00 
    b241:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b246:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b24b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b24f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b254:	85 c9                	test   %ecx,%ecx
    b256:	74 37                	je     b28f <fwp_hof0.constprop.0+0x81f>
    b258:	89 ca                	mov    %ecx,%edx
    b25a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b25e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b262:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b265:	48 c1 e2 03          	shl    $0x3,%rdx
    b269:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b270:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b274:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b278:	e8 93 83 ff ff       	call   3610 <memmove@plt>
    b27d:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b281:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b285:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b288:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b28f:	45 85 ed             	test   %r13d,%r13d
    b292:	74 23                	je     b2b7 <fwp_hof0.constprop.0+0x847>
    b294:	45 89 ed             	mov    %r13d,%r13d
    b297:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b29b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b2a0:	49 8b 14 24          	mov    (%r12),%rdx
    b2a4:	89 c8                	mov    %ecx,%eax
    b2a6:	49 83 c4 08          	add    $0x8,%r12
    b2aa:	83 c1 01             	add    $0x1,%ecx
    b2ad:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b2b2:	4c 39 e6             	cmp    %r12,%rsi
    b2b5:	75 e9                	jne    b2a0 <fwp_hof0.constprop.0+0x830>
    b2b7:	48 8d 35 c2 84 01 00 	lea    0x184c2(%rip),%rsi        # 23780 <fwp_heap>
    b2be:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b2c2:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b2c9:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b2d0:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b2d4:	48 c1 e2 10          	shl    $0x10,%rdx
    b2d8:	48 39 d0             	cmp    %rdx,%rax
    b2db:	73 54                	jae    b331 <fwp_hof0.constprop.0+0x8c1>
    b2dd:	48 89 c2             	mov    %rax,%rdx
    b2e0:	48 c1 ea 10          	shr    $0x10,%rdx
    b2e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2e8:	48 8b 15 89 98 01 00 	mov    0x19889(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b2ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2f3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b2f7:	48 85 c9             	test   %rcx,%rcx
    b2fa:	74 35                	je     b331 <fwp_hof0.constprop.0+0x8c1>
    b2fc:	0f b6 32             	movzbl (%rdx),%esi
    b2ff:	40 80 fe 02          	cmp    $0x2,%sil
    b303:	0f 84 52 02 00 00    	je     b55b <fwp_hof0.constprop.0+0xaeb>
    b309:	40 80 fe 01          	cmp    $0x1,%sil
    b30d:	75 22                	jne    b331 <fwp_hof0.constprop.0+0x8c1>
    b30f:	8b 72 18             	mov    0x18(%rdx),%esi
    b312:	0f b7 c0             	movzwl %ax,%eax
    b315:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b318:	48 0f af c6          	imul   %rsi,%rax
    b31c:	48 c1 e8 20          	shr    $0x20,%rax
    b320:	48 39 d0             	cmp    %rdx,%rax
    b323:	73 0c                	jae    b331 <fwp_hof0.constprop.0+0x8c1>
    b325:	48 01 c1             	add    %rax,%rcx
    b328:	80 39 01             	cmpb   $0x1,(%rcx)
    b32b:	0f 84 9f 01 00 00    	je     b4d0 <fwp_hof0.constprop.0+0xa60>
    b331:	49 8b 40 18          	mov    0x18(%r8),%rax
    b335:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b339:	be 01 00 00 00       	mov    $0x1,%esi
    b33e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b342:	ff 50 08             	call   *0x8(%rax)
    b345:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b349:	48 8d 35 30 84 01 00 	lea    0x18430(%rip),%rsi        # 23780 <fwp_heap>
    b350:	4c 89 d0             	mov    %r10,%rax
    b353:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b35a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b361:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b365:	48 c1 e2 10          	shl    $0x10,%rdx
    b369:	48 39 d0             	cmp    %rdx,%rax
    b36c:	73 59                	jae    b3c7 <fwp_hof0.constprop.0+0x957>
    b36e:	48 89 c2             	mov    %rax,%rdx
    b371:	48 c1 ea 10          	shr    $0x10,%rdx
    b375:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b379:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b380:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b384:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b388:	4d 85 e4             	test   %r12,%r12
    b38b:	74 3a                	je     b3c7 <fwp_hof0.constprop.0+0x957>
    b38d:	0f b6 0a             	movzbl (%rdx),%ecx
    b390:	80 f9 02             	cmp    $0x2,%cl
    b393:	0f 84 99 01 00 00    	je     b532 <fwp_hof0.constprop.0+0xac2>
    b399:	80 f9 01             	cmp    $0x1,%cl
    b39c:	75 29                	jne    b3c7 <fwp_hof0.constprop.0+0x957>
    b39e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3a1:	0f b7 c0             	movzwl %ax,%eax
    b3a4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3a7:	48 0f af c1          	imul   %rcx,%rax
    b3ab:	48 c1 e8 20          	shr    $0x20,%rax
    b3af:	48 39 d0             	cmp    %rdx,%rax
    b3b2:	73 13                	jae    b3c7 <fwp_hof0.constprop.0+0x957>
    b3b4:	49 01 c4             	add    %rax,%r12
    b3b7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3bc:	0f 84 84 01 00 00    	je     b546 <fwp_hof0.constprop.0+0xad6>
    b3c2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3c7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b3cb:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b3cf:	e8 1c bc ff ff       	call   6ff0 <fwp_closure_drop>
    b3d4:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b3d8:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b3dc:	e9 c2 fa ff ff       	jmp    aea3 <fwp_hof0.constprop.0+0x433>
    b3e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b3e8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b3ec:	e9 b2 fa ff ff       	jmp    aea3 <fwp_hof0.constprop.0+0x433>
    b3f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b3f8:	41 8b 34 24          	mov    (%r12),%esi
    b3fc:	8b 05 1a 7c 00 00    	mov    0x7c1a(%rip),%eax        # 1301c <fc12+0x4>
    b402:	89 f7                	mov    %esi,%edi
    b404:	29 c7                	sub    %eax,%edi
    b406:	83 ff 01             	cmp    $0x1,%edi
    b409:	0f 85 7e f7 ff ff    	jne    ab8d <fwp_hof0.constprop.0+0x11d>
    b40f:	48 89 e3             	mov    %rsp,%rbx
    b412:	85 c0                	test   %eax,%eax
    b414:	0f 84 60 01 00 00    	je     b57a <fwp_hof0.constprop.0+0xb0a>
    b41a:	89 f1                	mov    %esi,%ecx
    b41c:	ba 08 00 00 00       	mov    $0x8,%edx
    b421:	48 c1 e1 03          	shl    $0x3,%rcx
    b425:	85 f6                	test   %esi,%esi
    b427:	48 89 e6             	mov    %rsp,%rsi
    b42a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b42e:	49 89 d7             	mov    %rdx,%r15
    b431:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b435:	48 c1 ea 04          	shr    $0x4,%rdx
    b439:	48 c1 e2 04          	shl    $0x4,%rdx
    b43d:	48 89 d7             	mov    %rdx,%rdi
    b440:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b447:	48 29 fe             	sub    %rdi,%rsi
    b44a:	48 39 f4             	cmp    %rsi,%rsp
    b44d:	74 15                	je     b464 <fwp_hof0.constprop.0+0x9f4>
    b44f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b456:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b45d:	00 00 
    b45f:	48 39 f4             	cmp    %rsi,%rsp
    b462:	75 eb                	jne    b44f <fwp_hof0.constprop.0+0x9df>
    b464:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b46a:	48 29 d4             	sub    %rdx,%rsp
    b46d:	48 85 d2             	test   %rdx,%rdx
    b470:	74 06                	je     b478 <fwp_hof0.constprop.0+0xa08>
    b472:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b478:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b47f:	00 
    b480:	4c 89 f9             	mov    %r15,%rcx
    b483:	48 8d 35 96 7b 00 00 	lea    0x7b96(%rip),%rsi        # 13020 <fwp_epfd>
    b48a:	48 89 e7             	mov    %rsp,%rdi
    b48d:	4c 89 f2             	mov    %r14,%rdx
    b490:	e8 db 80 ff ff       	call   3570 <__memcpy_chk@plt>
    b495:	4d 39 f7             	cmp    %r14,%r15
    b498:	4c 89 f9             	mov    %r15,%rcx
    b49b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b49f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b4a3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b4aa:	ba 08 00 00 00       	mov    $0x8,%edx
    b4af:	4c 29 f1             	sub    %r14,%rcx
    b4b2:	e8 b9 80 ff ff       	call   3570 <__memcpy_chk@plt>
    b4b7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b4bc:	48 89 e7             	mov    %rsp,%rdi
    b4bf:	ff 10                	call   *(%rax)
    b4c1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b4c5:	e9 bd 00 00 00       	jmp    b587 <fwp_hof0.constprop.0+0xb17>
    b4ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b4d0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b4d7:	00 
    b4d8:	e9 6c fe ff ff       	jmp    b349 <fwp_hof0.constprop.0+0x8d9>
    b4dd:	66 85 c0             	test   %ax,%ax
    b4e0:	0f 85 32 f7 ff ff    	jne    ac18 <fwp_hof0.constprop.0+0x1a8>
    b4e6:	e9 19 f7 ff ff       	jmp    ac04 <fwp_hof0.constprop.0+0x194>
    b4eb:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b4ef:	4d 85 d2             	test   %r10,%r10
    b4f2:	74 19                	je     b50d <fwp_hof0.constprop.0+0xa9d>
    b4f4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b4f8:	4d 29 d3             	sub    %r10,%r11
    b4fb:	49 39 c3             	cmp    %rax,%r11
    b4fe:	72 0d                	jb     b50d <fwp_hof0.constprop.0+0xa9d>
    b500:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b504:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b508:	e9 98 fc ff ff       	jmp    b1a5 <fwp_hof0.constprop.0+0x735>
    b50d:	31 f6                	xor    %esi,%esi
    b50f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b512:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b516:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b51a:	e8 31 a5 ff ff       	call   5a50 <fwp_heap_alloc>
    b51f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b522:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b526:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b52a:	49 89 c2             	mov    %rax,%r10
    b52d:	e9 0f fd ff ff       	jmp    b241 <fwp_hof0.constprop.0+0x7d1>
    b532:	66 85 c0             	test   %ax,%ax
    b535:	0f 85 8c fe ff ff    	jne    b3c7 <fwp_hof0.constprop.0+0x957>
    b53b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b540:	0f 85 7c fe ff ff    	jne    b3c2 <fwp_hof0.constprop.0+0x952>
    b546:	4c 89 e7             	mov    %r12,%rdi
    b549:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b54d:	e8 be 9d ff ff       	call   5310 <fwp_rc_forget_slot>
    b552:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b556:	e9 67 fe ff ff       	jmp    b3c2 <fwp_hof0.constprop.0+0x952>
    b55b:	66 85 c0             	test   %ax,%ax
    b55e:	0f 85 cd fd ff ff    	jne    b331 <fwp_hof0.constprop.0+0x8c1>
    b564:	e9 bf fd ff ff       	jmp    b328 <fwp_hof0.constprop.0+0x8b8>
    b569:	e8 82 9c ff ff       	call   51f0 <fwp_rc_wide_dup>
    b56e:	48 8b 15 63 9e 01 00 	mov    0x19e63(%rip),%rdx        # 253d8 <fwp_fns>
    b575:	e9 9e f6 ff ff       	jmp    ac18 <fwp_hof0.constprop.0+0x1a8>
    b57a:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b581:	ff 11                	call   *(%rcx)
    b583:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b587:	48 89 dc             	mov    %rbx,%rsp
    b58a:	e9 a7 f9 ff ff       	jmp    af36 <fwp_hof0.constprop.0+0x4c6>
    b58f:	48 89 c7             	mov    %rax,%rdi
    b592:	e8 39 b3 ff ff       	call   68d0 <fwp_rc_share>
    b597:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b59b:	e8 30 b3 ff ff       	call   68d0 <fwp_rc_share>
    b5a0:	48 8d 05 71 7a 00 00 	lea    0x7a71(%rip),%rax        # 13018 <fc12>
    b5a7:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b5ae:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b5b2:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b5b9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b5bd:	e9 60 f9 ff ff       	jmp    af22 <fwp_hof0.constprop.0+0x4b2>
    b5c2:	66 85 c0             	test   %ax,%ax
    b5c5:	0f 85 6c f5 ff ff    	jne    ab37 <fwp_hof0.constprop.0+0xc7>
    b5cb:	e9 53 f5 ff ff       	jmp    ab23 <fwp_hof0.constprop.0+0xb3>
    b5d0:	48 89 df             	mov    %rbx,%rdi
    b5d3:	e8 28 b4 ff ff       	call   6a00 <fwp_rc_free_arr>
    b5d8:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b5dc:	4d 85 ff             	test   %r15,%r15
    b5df:	0f 85 cc f4 ff ff    	jne    aab1 <fwp_hof0.constprop.0+0x41>
    b5e5:	e9 2f fb ff ff       	jmp    b119 <fwp_hof0.constprop.0+0x6a9>
    b5ea:	66 85 c0             	test   %ax,%ax
    b5ed:	0f 85 5a fa ff ff    	jne    b04d <fwp_hof0.constprop.0+0x5dd>
    b5f3:	e9 47 fa ff ff       	jmp    b03f <fwp_hof0.constprop.0+0x5cf>
    b5f8:	66 85 c0             	test   %ax,%ax
    b5fb:	0f 85 0b fb ff ff    	jne    b10c <fwp_hof0.constprop.0+0x69c>
    b601:	e9 e6 fa ff ff       	jmp    b0ec <fwp_hof0.constprop.0+0x67c>
    b606:	4c 89 e0             	mov    %r12,%rax
    b609:	48 8d 35 70 81 01 00 	lea    0x18170(%rip),%rsi        # 23780 <fwp_heap>
    b610:	48 c1 e8 11          	shr    $0x11,%rax
    b614:	4c 31 e0             	xor    %r12,%rax
    b617:	48 89 c2             	mov    %rax,%rdx
    b61a:	48 c1 ea 09          	shr    $0x9,%rdx
    b61e:	48 31 d0             	xor    %rdx,%rax
    b621:	0f b6 c0             	movzbl %al,%eax
    b624:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b62b:	00 
    b62c:	48 85 d2             	test   %rdx,%rdx
    b62f:	75 18                	jne    b649 <fwp_hof0.constprop.0+0xbd9>
    b631:	eb 4d                	jmp    b680 <fwp_hof0.constprop.0+0xc10>
    b633:	66 90                	xchg   %ax,%ax
    b635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b63c:	00 00 00 00 
    b640:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b644:	48 85 d2             	test   %rdx,%rdx
    b647:	74 37                	je     b680 <fwp_hof0.constprop.0+0xc10>
    b649:	48 89 d0             	mov    %rdx,%rax
    b64c:	4c 39 22             	cmp    %r12,(%rdx)
    b64f:	75 ef                	jne    b640 <fwp_hof0.constprop.0+0xbd0>
    b651:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b655:	48 83 e8 01          	sub    $0x1,%rax
    b659:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b65d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b663:	0f 85 a3 fa ff ff    	jne    b10c <fwp_hof0.constprop.0+0x69c>
    b669:	4c 89 e7             	mov    %r12,%rdi
    b66c:	e8 9f 9c ff ff       	call   5310 <fwp_rc_forget_slot>
    b671:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b676:	e9 91 fa ff ff       	jmp    b10c <fwp_hof0.constprop.0+0x69c>
    b67b:	e8 30 86 ff ff       	call   3cb0 <fwp_heap_oom>
    b680:	48 8d 3d 11 41 00 00 	lea    0x4111(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    b687:	e8 14 8b ff ff       	call   41a0 <fwp_trap>
    b68c:	48 8d 3d 55 3b 00 00 	lea    0x3b55(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    b693:	e8 08 8b ff ff       	call   41a0 <fwp_trap>
    b698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b69f:	00 
    b6a0:	e8 4b 9b ff ff       	call   51f0 <fwp_rc_wide_dup>
    b6a5:	e9 8d f4 ff ff       	jmp    ab37 <fwp_hof0.constprop.0+0xc7>
    b6aa:	e8 b1 7d ff ff       	call   3460 <__stack_chk_fail@plt>
    b6af:	90                   	nop
    b6b0:	4c 89 f7             	mov    %r14,%rdi
    b6b3:	e8 58 9c ff ff       	call   5310 <fwp_rc_forget_slot>
    b6b8:	e9 8c f9 ff ff       	jmp    b049 <fwp_hof0.constprop.0+0x5d9>
    b6bd:	0f 1f 00             	nopl   (%rax)

000000000000b6c0 <f0>:
    b6c0:	41 56                	push   %r14
    b6c2:	4c 8d 35 b7 80 01 00 	lea    0x180b7(%rip),%r14        # 23780 <fwp_heap>
    b6c9:	41 55                	push   %r13
    b6cb:	41 54                	push   %r12
    b6cd:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b6d3:	55                   	push   %rbp
    b6d4:	53                   	push   %rbx
    b6d5:	31 db                	xor    %ebx,%ebx
    b6d7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b6de:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b6e5:	00 00 
    b6e7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b6ee:	00 
    b6ef:	31 c0                	xor    %eax,%eax
    b6f1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b6f8:	00 
    b6f9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b700:	00 00 
    b702:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b707:	48 8d 05 82 b7 ff ff 	lea    -0x487e(%rip),%rax        # 6e90 <fwp_drop1>
    b70e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b713:	48 8b 05 fe 9c 01 00 	mov    0x19cfe(%rip),%rax        # 25418 <fwp_cleanups>
    b71a:	48 89 25 f7 9c 01 00 	mov    %rsp,0x19cf7(%rip)        # 25418 <fwp_cleanups>
    b721:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b725:	48 89 04 24          	mov    %rax,(%rsp)
    b729:	48 8d 05 a0 84 ff ff 	lea    -0x7b60(%rip),%rax        # 3bd0 <fwp_range_release>
    b730:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b735:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b73a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b73f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b744:	eb 47                	jmp    b78d <f0+0xcd>
    b746:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b74d:	00 00 00 
    b750:	80 f9 01             	cmp    $0x1,%cl
    b753:	75 29                	jne    b77e <f0+0xbe>
    b755:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b758:	0f b7 c0             	movzwl %ax,%eax
    b75b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b75e:	48 0f af c1          	imul   %rcx,%rax
    b762:	48 c1 e8 20          	shr    $0x20,%rax
    b766:	48 39 d0             	cmp    %rdx,%rax
    b769:	73 13                	jae    b77e <f0+0xbe>
    b76b:	49 01 c5             	add    %rax,%r13
    b76e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b773:	0f 84 c7 27 00 00    	je     df40 <f0+0x2880>
    b779:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b77e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b783:	49 83 ec 01          	sub    $0x1,%r12
    b787:	0f 82 83 00 00 00    	jb     b810 <f0+0x150>
    b78d:	48 89 ee             	mov    %rbp,%rsi
    b790:	bf 01 00 00 00       	mov    $0x1,%edi
    b795:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b79c:	00 
    b79d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b7a2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b7a9:	00 
    b7aa:	e8 f1 af ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b7af:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b7b6:	48 89 c3             	mov    %rax,%rbx
    b7b9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b7c0:	48 c1 e2 10          	shl    $0x10,%rdx
    b7c4:	48 39 d0             	cmp    %rdx,%rax
    b7c7:	73 b5                	jae    b77e <f0+0xbe>
    b7c9:	48 89 c2             	mov    %rax,%rdx
    b7cc:	48 c1 ea 10          	shr    $0x10,%rdx
    b7d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7d4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b7db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7df:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b7e3:	4d 85 ed             	test   %r13,%r13
    b7e6:	74 96                	je     b77e <f0+0xbe>
    b7e8:	0f b6 0a             	movzbl (%rdx),%ecx
    b7eb:	80 f9 02             	cmp    $0x2,%cl
    b7ee:	0f 85 5c ff ff ff    	jne    b750 <f0+0x90>
    b7f4:	66 85 c0             	test   %ax,%ax
    b7f7:	0f 84 71 ff ff ff    	je     b76e <f0+0xae>
    b7fd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b802:	49 83 ec 01          	sub    $0x1,%r12
    b806:	73 85                	jae    b78d <f0+0xcd>
    b808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b80f:	00 
    b810:	48 8b 04 24          	mov    (%rsp),%rax
    b814:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b819:	bf 01 00 00 00       	mov    $0x1,%edi
    b81e:	66 0f 6f 05 fa 42 00 	movdqa 0x42fa(%rip),%xmm0        # fb20 <msg.4+0xa0>
    b825:	00 
    b826:	48 89 05 eb 9b 01 00 	mov    %rax,0x19beb(%rip)        # 25418 <fwp_cleanups>
    b82d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b832:	e8 69 af ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b837:	48 8b 15 1a 93 01 00 	mov    0x1931a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b83e:	49 89 c5             	mov    %rax,%r13
    b841:	48 2b 05 e8 92 01 00 	sub    0x192e8(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b848:	48 c1 e2 10          	shl    $0x10,%rdx
    b84c:	48 39 d0             	cmp    %rdx,%rax
    b84f:	73 59                	jae    b8aa <f0+0x1ea>
    b851:	48 89 c2             	mov    %rax,%rdx
    b854:	48 c1 ea 10          	shr    $0x10,%rdx
    b858:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b85c:	48 8b 15 15 93 01 00 	mov    0x19315(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b863:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b867:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b86b:	4d 85 e4             	test   %r12,%r12
    b86e:	74 3a                	je     b8aa <f0+0x1ea>
    b870:	0f b6 0a             	movzbl (%rdx),%ecx
    b873:	80 f9 02             	cmp    $0x2,%cl
    b876:	0f 84 74 27 00 00    	je     dff0 <f0+0x2930>
    b87c:	80 f9 01             	cmp    $0x1,%cl
    b87f:	75 29                	jne    b8aa <f0+0x1ea>
    b881:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b884:	0f b7 c0             	movzwl %ax,%eax
    b887:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b88a:	48 0f af c1          	imul   %rcx,%rax
    b88e:	48 c1 e8 20          	shr    $0x20,%rax
    b892:	48 39 d0             	cmp    %rdx,%rax
    b895:	73 13                	jae    b8aa <f0+0x1ea>
    b897:	49 01 c4             	add    %rax,%r12
    b89a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b89f:	0f 84 26 29 00 00    	je     e1cb <f0+0x2b0b>
    b8a5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b8aa:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b8af:	bf 01 00 00 00       	mov    $0x1,%edi
    b8b4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b8b9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b8c0:	00 f0 3f 
    b8c3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b8c8:	e8 d3 ae ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b8cd:	48 8b 15 84 92 01 00 	mov    0x19284(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b8d4:	49 89 c5             	mov    %rax,%r13
    b8d7:	48 2b 05 52 92 01 00 	sub    0x19252(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b8de:	48 c1 e2 10          	shl    $0x10,%rdx
    b8e2:	48 39 d0             	cmp    %rdx,%rax
    b8e5:	73 59                	jae    b940 <f0+0x280>
    b8e7:	48 89 c2             	mov    %rax,%rdx
    b8ea:	48 c1 ea 10          	shr    $0x10,%rdx
    b8ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8f2:	48 8b 15 7f 92 01 00 	mov    0x1927f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b8f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b8fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b901:	4d 85 e4             	test   %r12,%r12
    b904:	74 3a                	je     b940 <f0+0x280>
    b906:	0f b6 0a             	movzbl (%rdx),%ecx
    b909:	80 f9 02             	cmp    $0x2,%cl
    b90c:	0f 84 ce 26 00 00    	je     dfe0 <f0+0x2920>
    b912:	80 f9 01             	cmp    $0x1,%cl
    b915:	75 29                	jne    b940 <f0+0x280>
    b917:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b91a:	0f b7 c0             	movzwl %ax,%eax
    b91d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b920:	48 0f af c1          	imul   %rcx,%rax
    b924:	48 c1 e8 20          	shr    $0x20,%rax
    b928:	48 39 d0             	cmp    %rdx,%rax
    b92b:	73 13                	jae    b940 <f0+0x280>
    b92d:	49 01 c4             	add    %rax,%r12
    b930:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b935:	0f 84 9d 28 00 00    	je     e1d8 <f0+0x2b18>
    b93b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b940:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b945:	bf 01 00 00 00       	mov    $0x1,%edi
    b94a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b94f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b956:	33 f3 bf 
    b959:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b95e:	e8 3d ae ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b963:	48 8b 15 ee 91 01 00 	mov    0x191ee(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b96a:	49 89 c5             	mov    %rax,%r13
    b96d:	48 2b 05 bc 91 01 00 	sub    0x191bc(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b974:	48 c1 e2 10          	shl    $0x10,%rdx
    b978:	48 39 d0             	cmp    %rdx,%rax
    b97b:	73 59                	jae    b9d6 <f0+0x316>
    b97d:	48 89 c2             	mov    %rax,%rdx
    b980:	48 c1 ea 10          	shr    $0x10,%rdx
    b984:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b988:	48 8b 15 e9 91 01 00 	mov    0x191e9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b98f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b993:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b997:	4d 85 e4             	test   %r12,%r12
    b99a:	74 3a                	je     b9d6 <f0+0x316>
    b99c:	0f b6 0a             	movzbl (%rdx),%ecx
    b99f:	80 f9 02             	cmp    $0x2,%cl
    b9a2:	0f 84 28 26 00 00    	je     dfd0 <f0+0x2910>
    b9a8:	80 f9 01             	cmp    $0x1,%cl
    b9ab:	75 29                	jne    b9d6 <f0+0x316>
    b9ad:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b9b0:	0f b7 c0             	movzwl %ax,%eax
    b9b3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b9b6:	48 0f af c1          	imul   %rcx,%rax
    b9ba:	48 c1 e8 20          	shr    $0x20,%rax
    b9be:	48 39 d0             	cmp    %rdx,%rax
    b9c1:	73 13                	jae    b9d6 <f0+0x316>
    b9c3:	49 01 c4             	add    %rax,%r12
    b9c6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b9cb:	0f 84 14 28 00 00    	je     e1e5 <f0+0x2b25>
    b9d1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b9d6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b9db:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b9e5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b9ec:	00 f0 3f 
    b9ef:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b9f4:	e8 a7 ad ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b9f9:	48 8b 15 58 91 01 00 	mov    0x19158(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ba00:	49 89 c5             	mov    %rax,%r13
    ba03:	48 2b 05 26 91 01 00 	sub    0x19126(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ba0a:	48 c1 e2 10          	shl    $0x10,%rdx
    ba0e:	48 39 d0             	cmp    %rdx,%rax
    ba11:	73 59                	jae    ba6c <f0+0x3ac>
    ba13:	48 89 c2             	mov    %rax,%rdx
    ba16:	48 c1 ea 10          	shr    $0x10,%rdx
    ba1a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba1e:	48 8b 15 53 91 01 00 	mov    0x19153(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ba25:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba29:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ba2d:	4d 85 e4             	test   %r12,%r12
    ba30:	74 3a                	je     ba6c <f0+0x3ac>
    ba32:	0f b6 0a             	movzbl (%rdx),%ecx
    ba35:	80 f9 02             	cmp    $0x2,%cl
    ba38:	0f 84 f2 25 00 00    	je     e030 <f0+0x2970>
    ba3e:	80 f9 01             	cmp    $0x1,%cl
    ba41:	75 29                	jne    ba6c <f0+0x3ac>
    ba43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba46:	0f b7 c0             	movzwl %ax,%eax
    ba49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba4c:	48 0f af c1          	imul   %rcx,%rax
    ba50:	48 c1 e8 20          	shr    $0x20,%rax
    ba54:	48 39 d0             	cmp    %rdx,%rax
    ba57:	73 13                	jae    ba6c <f0+0x3ac>
    ba59:	49 01 c4             	add    %rax,%r12
    ba5c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ba61:	0f 84 8b 27 00 00    	je     e1f2 <f0+0x2b32>
    ba67:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ba6c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ba73:	33 f3 bf 
    ba76:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ba7d:	00 
    ba7e:	bf 01 00 00 00       	mov    $0x1,%edi
    ba83:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    ba8a:	00 
    ba8b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    ba92:	00 
    ba93:	e8 08 ad ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    ba98:	48 8b 15 b9 90 01 00 	mov    0x190b9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ba9f:	49 89 c5             	mov    %rax,%r13
    baa2:	48 2b 05 87 90 01 00 	sub    0x19087(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    baa9:	48 c1 e2 10          	shl    $0x10,%rdx
    baad:	48 39 d0             	cmp    %rdx,%rax
    bab0:	73 59                	jae    bb0b <f0+0x44b>
    bab2:	48 89 c2             	mov    %rax,%rdx
    bab5:	48 c1 ea 10          	shr    $0x10,%rdx
    bab9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    babd:	48 8b 15 b4 90 01 00 	mov    0x190b4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    bac4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bac8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bacc:	4d 85 e4             	test   %r12,%r12
    bacf:	74 3a                	je     bb0b <f0+0x44b>
    bad1:	0f b6 0a             	movzbl (%rdx),%ecx
    bad4:	80 f9 02             	cmp    $0x2,%cl
    bad7:	0f 84 43 25 00 00    	je     e020 <f0+0x2960>
    badd:	80 f9 01             	cmp    $0x1,%cl
    bae0:	75 29                	jne    bb0b <f0+0x44b>
    bae2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bae5:	0f b7 c0             	movzwl %ax,%eax
    bae8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    baeb:	48 0f af c1          	imul   %rcx,%rax
    baef:	48 c1 e8 20          	shr    $0x20,%rax
    baf3:	48 39 d0             	cmp    %rdx,%rax
    baf6:	73 13                	jae    bb0b <f0+0x44b>
    baf8:	49 01 c4             	add    %rax,%r12
    bafb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bb00:	0f 84 f9 26 00 00    	je     e1ff <f0+0x2b3f>
    bb06:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bb0b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    bb12:	00 f0 3f 
    bb15:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    bb1c:	00 
    bb1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb22:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    bb29:	00 
    bb2a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    bb31:	00 
    bb32:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    bb39:	33 f3 bf 
    bb3c:	e8 5f ac ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bb41:	48 89 c7             	mov    %rax,%rdi
    bb44:	e8 07 ae ff ff       	call   6950 <fwp_rc_fresh>
    bb49:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    bb50:	00 
    bb51:	bf 01 00 00 00       	mov    $0x1,%edi
    bb56:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    bb5d:	00 
    bb5e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    bb65:	00 
    bb66:	e8 35 ac ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bb6b:	48 89 c7             	mov    %rax,%rdi
    bb6e:	e8 dd ad ff ff       	call   6950 <fwp_rc_fresh>
    bb73:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    bb7a:	00 
    bb7b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb80:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    bb87:	00 
    bb88:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    bb8f:	00 
    bb90:	e8 0b ac ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bb95:	48 89 c7             	mov    %rax,%rdi
    bb98:	e8 b3 ad ff ff       	call   6950 <fwp_rc_fresh>
    bb9d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    bba4:	00 
    bba5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbaa:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    bbb1:	00 
    bbb2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    bbb9:	00 
    bbba:	e8 e1 ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bbbf:	48 89 c7             	mov    %rax,%rdi
    bbc2:	e8 89 ad ff ff       	call   6950 <fwp_rc_fresh>
    bbc7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    bbce:	00 
    bbcf:	bf 01 00 00 00       	mov    $0x1,%edi
    bbd4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    bbdb:	00 
    bbdc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    bbe3:	00 
    bbe4:	e8 b7 ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bbe9:	48 89 c7             	mov    %rax,%rdi
    bbec:	e8 5f ad ff ff       	call   6950 <fwp_rc_fresh>
    bbf1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    bbf8:	00 
    bbf9:	bf 01 00 00 00       	mov    $0x1,%edi
    bbfe:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    bc05:	00 
    bc06:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    bc0d:	00 
    bc0e:	e8 8d ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bc13:	48 89 c7             	mov    %rax,%rdi
    bc16:	e8 35 ad ff ff       	call   6950 <fwp_rc_fresh>
    bc1b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    bc22:	00 
    bc23:	bf 01 00 00 00       	mov    $0x1,%edi
    bc28:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    bc2f:	00 
    bc30:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bc37:	00 
    bc38:	e8 63 ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bc3d:	48 89 c7             	mov    %rax,%rdi
    bc40:	e8 0b ad ff ff       	call   6950 <fwp_rc_fresh>
    bc45:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bc4c:	00 
    bc4d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc52:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bc59:	00 
    bc5a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bc61:	00 
    bc62:	e8 39 ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bc67:	48 89 c7             	mov    %rax,%rdi
    bc6a:	e8 e1 ac ff ff       	call   6950 <fwp_rc_fresh>
    bc6f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    bc76:	00 
    bc77:	bf 01 00 00 00       	mov    $0x1,%edi
    bc7c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bc83:	00 
    bc84:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bc8b:	00 
    bc8c:	e8 0f ab ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bc91:	48 89 c7             	mov    %rax,%rdi
    bc94:	e8 b7 ac ff ff       	call   6950 <fwp_rc_fresh>
    bc99:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bca0:	00 
    bca1:	bf 01 00 00 00       	mov    $0x1,%edi
    bca6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bcad:	00 
    bcae:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bcb5:	00 
    bcb6:	e8 e5 aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bcbb:	48 89 c7             	mov    %rax,%rdi
    bcbe:	e8 8d ac ff ff       	call   6950 <fwp_rc_fresh>
    bcc3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bcca:	00 
    bccb:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bcd7:	00 
    bcd8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bcdf:	00 
    bce0:	e8 bb aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bce5:	48 89 c7             	mov    %rax,%rdi
    bce8:	e8 63 ac ff ff       	call   6950 <fwp_rc_fresh>
    bced:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bcf4:	00 
    bcf5:	bf 01 00 00 00       	mov    $0x1,%edi
    bcfa:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bd01:	00 
    bd02:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bd09:	00 
    bd0a:	e8 91 aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bd0f:	48 89 c7             	mov    %rax,%rdi
    bd12:	e8 39 ac ff ff       	call   6950 <fwp_rc_fresh>
    bd17:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bd1e:	00 
    bd1f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd24:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bd2b:	00 
    bd2c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bd33:	00 
    bd34:	e8 67 aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bd39:	48 89 c7             	mov    %rax,%rdi
    bd3c:	e8 0f ac ff ff       	call   6950 <fwp_rc_fresh>
    bd41:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bd48:	00 
    bd49:	bf 01 00 00 00       	mov    $0x1,%edi
    bd4e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bd55:	00 
    bd56:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bd5d:	00 
    bd5e:	e8 3d aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bd63:	48 89 c7             	mov    %rax,%rdi
    bd66:	e8 e5 ab ff ff       	call   6950 <fwp_rc_fresh>
    bd6b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bd72:	00 
    bd73:	bf 01 00 00 00       	mov    $0x1,%edi
    bd78:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bd7f:	00 
    bd80:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bd87:	00 
    bd88:	e8 13 aa ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bd8d:	48 89 c7             	mov    %rax,%rdi
    bd90:	e8 bb ab ff ff       	call   6950 <fwp_rc_fresh>
    bd95:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bd9c:	00 
    bd9d:	bf 01 00 00 00       	mov    $0x1,%edi
    bda2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bda9:	00 
    bdaa:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bdb1:	00 
    bdb2:	e8 e9 a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bdb7:	48 89 c7             	mov    %rax,%rdi
    bdba:	e8 91 ab ff ff       	call   6950 <fwp_rc_fresh>
    bdbf:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bdc6:	00 
    bdc7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdcc:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bdd3:	00 
    bdd4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bddb:	00 
    bddc:	e8 bf a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bde1:	48 89 c7             	mov    %rax,%rdi
    bde4:	e8 67 ab ff ff       	call   6950 <fwp_rc_fresh>
    bde9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bdf0:	00 
    bdf1:	bf 01 00 00 00       	mov    $0x1,%edi
    bdf6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bdfd:	00 
    bdfe:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    be05:	00 
    be06:	e8 95 a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    be0b:	48 89 c7             	mov    %rax,%rdi
    be0e:	e8 3d ab ff ff       	call   6950 <fwp_rc_fresh>
    be13:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    be1a:	00 
    be1b:	bf 01 00 00 00       	mov    $0x1,%edi
    be20:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    be27:	00 
    be28:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    be2f:	00 
    be30:	e8 6b a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    be35:	48 89 c7             	mov    %rax,%rdi
    be38:	e8 13 ab ff ff       	call   6950 <fwp_rc_fresh>
    be3d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    be44:	00 
    be45:	bf 01 00 00 00       	mov    $0x1,%edi
    be4a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    be51:	00 
    be52:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    be59:	00 
    be5a:	e8 41 a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    be5f:	48 89 c7             	mov    %rax,%rdi
    be62:	e8 e9 aa ff ff       	call   6950 <fwp_rc_fresh>
    be67:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    be6e:	00 
    be6f:	bf 01 00 00 00       	mov    $0x1,%edi
    be74:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    be7b:	00 
    be7c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    be83:	00 
    be84:	e8 17 a9 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    be89:	48 89 c7             	mov    %rax,%rdi
    be8c:	e8 bf aa ff ff       	call   6950 <fwp_rc_fresh>
    be91:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    be98:	00 
    be99:	bf 01 00 00 00       	mov    $0x1,%edi
    be9e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bea5:	00 
    bea6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bead:	00 
    beae:	e8 ed a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    beb3:	48 89 c7             	mov    %rax,%rdi
    beb6:	e8 95 aa ff ff       	call   6950 <fwp_rc_fresh>
    bebb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bec2:	00 
    bec3:	bf 01 00 00 00       	mov    $0x1,%edi
    bec8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    becf:	00 
    bed0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bed7:	00 
    bed8:	e8 c3 a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bedd:	48 89 c7             	mov    %rax,%rdi
    bee0:	e8 6b aa ff ff       	call   6950 <fwp_rc_fresh>
    bee5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    beec:	00 
    beed:	bf 01 00 00 00       	mov    $0x1,%edi
    bef2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bef9:	00 
    befa:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bf01:	00 
    bf02:	e8 99 a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bf07:	48 89 c7             	mov    %rax,%rdi
    bf0a:	e8 41 aa ff ff       	call   6950 <fwp_rc_fresh>
    bf0f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bf16:	00 
    bf17:	bf 01 00 00 00       	mov    $0x1,%edi
    bf1c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bf23:	00 
    bf24:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bf2b:	00 
    bf2c:	e8 6f a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bf31:	48 89 c7             	mov    %rax,%rdi
    bf34:	e8 17 aa ff ff       	call   6950 <fwp_rc_fresh>
    bf39:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bf40:	00 
    bf41:	bf 01 00 00 00       	mov    $0x1,%edi
    bf46:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bf4d:	00 
    bf4e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bf55:	00 
    bf56:	e8 45 a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bf5b:	48 89 c7             	mov    %rax,%rdi
    bf5e:	e8 ed a9 ff ff       	call   6950 <fwp_rc_fresh>
    bf63:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bf6a:	00 
    bf6b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf70:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bf77:	00 
    bf78:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bf7f:	00 
    bf80:	e8 1b a8 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bf85:	48 89 c7             	mov    %rax,%rdi
    bf88:	e8 c3 a9 ff ff       	call   6950 <fwp_rc_fresh>
    bf8d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bf94:	00 
    bf95:	bf 01 00 00 00       	mov    $0x1,%edi
    bf9a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bfa1:	00 
    bfa2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bfa9:	00 
    bfaa:	e8 f1 a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bfaf:	48 89 c7             	mov    %rax,%rdi
    bfb2:	e8 99 a9 ff ff       	call   6950 <fwp_rc_fresh>
    bfb7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bfbe:	00 
    bfbf:	bf 01 00 00 00       	mov    $0x1,%edi
    bfc4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bfcb:	00 
    bfcc:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bfd3:	00 
    bfd4:	e8 c7 a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    bfd9:	48 89 c7             	mov    %rax,%rdi
    bfdc:	e8 6f a9 ff ff       	call   6950 <fwp_rc_fresh>
    bfe1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bfe8:	00 
    bfe9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfee:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bff5:	00 
    bff6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bffd:	00 
    bffe:	e8 9d a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c003:	48 89 c7             	mov    %rax,%rdi
    c006:	e8 45 a9 ff ff       	call   6950 <fwp_rc_fresh>
    c00b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c012:	00 
    c013:	bf 01 00 00 00       	mov    $0x1,%edi
    c018:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    c01f:	00 
    c020:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c027:	00 
    c028:	e8 73 a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c02d:	48 89 c7             	mov    %rax,%rdi
    c030:	e8 1b a9 ff ff       	call   6950 <fwp_rc_fresh>
    c035:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c03c:	00 
    c03d:	bf 01 00 00 00       	mov    $0x1,%edi
    c042:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    c049:	00 
    c04a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c051:	00 
    c052:	e8 49 a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c057:	48 89 c7             	mov    %rax,%rdi
    c05a:	e8 f1 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c05f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c066:	00 
    c067:	bf 01 00 00 00       	mov    $0x1,%edi
    c06c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    c073:	00 
    c074:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c07b:	00 
    c07c:	e8 1f a7 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c081:	48 89 c7             	mov    %rax,%rdi
    c084:	e8 c7 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c089:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c090:	00 
    c091:	bf 01 00 00 00       	mov    $0x1,%edi
    c096:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    c09d:	00 
    c09e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c0a5:	00 
    c0a6:	e8 f5 a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c0ab:	48 89 c7             	mov    %rax,%rdi
    c0ae:	e8 9d a8 ff ff       	call   6950 <fwp_rc_fresh>
    c0b3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c0ba:	00 
    c0bb:	bf 01 00 00 00       	mov    $0x1,%edi
    c0c0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    c0c7:	00 
    c0c8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c0cf:	00 
    c0d0:	e8 cb a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c0d5:	48 89 c7             	mov    %rax,%rdi
    c0d8:	e8 73 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c0dd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c0e4:	00 
    c0e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ea:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    c0f1:	00 
    c0f2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c0f9:	00 
    c0fa:	e8 a1 a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c0ff:	48 89 c7             	mov    %rax,%rdi
    c102:	e8 49 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c107:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c10e:	00 
    c10f:	bf 01 00 00 00       	mov    $0x1,%edi
    c114:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    c11b:	00 
    c11c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c123:	00 
    c124:	e8 77 a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c129:	48 89 c7             	mov    %rax,%rdi
    c12c:	e8 1f a8 ff ff       	call   6950 <fwp_rc_fresh>
    c131:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c138:	00 
    c139:	bf 01 00 00 00       	mov    $0x1,%edi
    c13e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    c145:	00 
    c146:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c14d:	00 
    c14e:	e8 4d a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c153:	48 89 c7             	mov    %rax,%rdi
    c156:	e8 f5 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c15b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c162:	00 
    c163:	bf 01 00 00 00       	mov    $0x1,%edi
    c168:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    c16f:	00 
    c170:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c177:	00 
    c178:	e8 23 a6 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c17d:	48 89 c7             	mov    %rax,%rdi
    c180:	e8 cb a7 ff ff       	call   6950 <fwp_rc_fresh>
    c185:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c18c:	00 
    c18d:	bf 01 00 00 00       	mov    $0x1,%edi
    c192:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c199:	00 
    c19a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c1a1:	00 
    c1a2:	e8 f9 a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c1a7:	48 89 c7             	mov    %rax,%rdi
    c1aa:	e8 a1 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c1af:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c1b6:	00 
    c1b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1bc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c1c3:	00 
    c1c4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c1cb:	00 
    c1cc:	e8 cf a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c1d1:	48 89 c7             	mov    %rax,%rdi
    c1d4:	e8 77 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c1d9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c1e0:	00 
    c1e1:	bf 01 00 00 00       	mov    $0x1,%edi
    c1e6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c1ed:	00 
    c1ee:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c1f5:	00 
    c1f6:	e8 a5 a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c1fb:	48 89 c7             	mov    %rax,%rdi
    c1fe:	e8 4d a7 ff ff       	call   6950 <fwp_rc_fresh>
    c203:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c20a:	00 
    c20b:	bf 01 00 00 00       	mov    $0x1,%edi
    c210:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c217:	00 
    c218:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c21f:	00 
    c220:	e8 7b a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c225:	48 89 c7             	mov    %rax,%rdi
    c228:	e8 23 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c22d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c234:	00 
    c235:	bf 01 00 00 00       	mov    $0x1,%edi
    c23a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c241:	00 
    c242:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c249:	00 
    c24a:	e8 51 a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c24f:	48 89 c7             	mov    %rax,%rdi
    c252:	e8 f9 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c257:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c25e:	00 
    c25f:	bf 01 00 00 00       	mov    $0x1,%edi
    c264:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c26b:	00 
    c26c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c273:	00 
    c274:	e8 27 a5 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c279:	48 89 c7             	mov    %rax,%rdi
    c27c:	e8 cf a6 ff ff       	call   6950 <fwp_rc_fresh>
    c281:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c288:	00 
    c289:	bf 01 00 00 00       	mov    $0x1,%edi
    c28e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c295:	00 
    c296:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c29d:	00 
    c29e:	e8 fd a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c2a3:	48 89 c7             	mov    %rax,%rdi
    c2a6:	e8 a5 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2ab:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c2b2:	00 
    c2b3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2b8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c2bf:	00 
    c2c0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c2c7:	00 
    c2c8:	e8 d3 a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c2cd:	48 89 c7             	mov    %rax,%rdi
    c2d0:	e8 7b a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2d5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c2dc:	00 
    c2dd:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c2e9:	00 
    c2ea:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c2f1:	00 
    c2f2:	e8 a9 a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c2f7:	48 89 c7             	mov    %rax,%rdi
    c2fa:	e8 51 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2ff:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c306:	00 
    c307:	bf 01 00 00 00       	mov    $0x1,%edi
    c30c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c313:	00 
    c314:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c31b:	00 
    c31c:	e8 7f a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c321:	48 89 c7             	mov    %rax,%rdi
    c324:	e8 27 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c329:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c330:	00 
    c331:	bf 01 00 00 00       	mov    $0x1,%edi
    c336:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c33d:	00 
    c33e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c345:	00 
    c346:	e8 55 a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c34b:	48 89 c7             	mov    %rax,%rdi
    c34e:	e8 fd a5 ff ff       	call   6950 <fwp_rc_fresh>
    c353:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c35a:	00 
    c35b:	bf 01 00 00 00       	mov    $0x1,%edi
    c360:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c367:	00 
    c368:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c36f:	00 
    c370:	e8 2b a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c375:	48 89 c7             	mov    %rax,%rdi
    c378:	e8 d3 a5 ff ff       	call   6950 <fwp_rc_fresh>
    c37d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c384:	00 
    c385:	bf 01 00 00 00       	mov    $0x1,%edi
    c38a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c391:	00 
    c392:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c399:	00 
    c39a:	e8 01 a4 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c39f:	48 89 c7             	mov    %rax,%rdi
    c3a2:	e8 a9 a5 ff ff       	call   6950 <fwp_rc_fresh>
    c3a7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c3ae:	00 
    c3af:	bf 01 00 00 00       	mov    $0x1,%edi
    c3b4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c3bb:	00 
    c3bc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c3c3:	00 
    c3c4:	e8 d7 a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c3c9:	48 89 c7             	mov    %rax,%rdi
    c3cc:	e8 7f a5 ff ff       	call   6950 <fwp_rc_fresh>
    c3d1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c3d8:	00 
    c3d9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3de:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c3e5:	00 
    c3e6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c3ed:	00 
    c3ee:	e8 ad a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c3f3:	48 89 c7             	mov    %rax,%rdi
    c3f6:	e8 55 a5 ff ff       	call   6950 <fwp_rc_fresh>
    c3fb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c402:	00 
    c403:	bf 01 00 00 00       	mov    $0x1,%edi
    c408:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c40f:	00 
    c410:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c417:	00 
    c418:	e8 83 a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c41d:	48 89 c7             	mov    %rax,%rdi
    c420:	e8 2b a5 ff ff       	call   6950 <fwp_rc_fresh>
    c425:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c42c:	00 
    c42d:	bf 01 00 00 00       	mov    $0x1,%edi
    c432:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c439:	00 
    c43a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c441:	00 
    c442:	e8 59 a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c447:	48 89 c7             	mov    %rax,%rdi
    c44a:	e8 01 a5 ff ff       	call   6950 <fwp_rc_fresh>
    c44f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c456:	00 
    c457:	bf 01 00 00 00       	mov    $0x1,%edi
    c45c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c463:	00 
    c464:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c46b:	00 
    c46c:	e8 2f a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c471:	48 89 c7             	mov    %rax,%rdi
    c474:	e8 d7 a4 ff ff       	call   6950 <fwp_rc_fresh>
    c479:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c480:	00 
    c481:	bf 01 00 00 00       	mov    $0x1,%edi
    c486:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c48d:	00 
    c48e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c495:	00 
    c496:	e8 05 a3 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c49b:	48 89 c7             	mov    %rax,%rdi
    c49e:	e8 ad a4 ff ff       	call   6950 <fwp_rc_fresh>
    c4a3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c4aa:	00 
    c4ab:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c4b7:	00 
    c4b8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c4bf:	00 
    c4c0:	e8 db a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c4c5:	48 89 c7             	mov    %rax,%rdi
    c4c8:	e8 83 a4 ff ff       	call   6950 <fwp_rc_fresh>
    c4cd:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c4d4:	00 
    c4d5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4da:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c4e1:	00 
    c4e2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c4e9:	00 
    c4ea:	e8 b1 a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c4ef:	48 89 c7             	mov    %rax,%rdi
    c4f2:	e8 59 a4 ff ff       	call   6950 <fwp_rc_fresh>
    c4f7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c4fe:	00 
    c4ff:	bf 01 00 00 00       	mov    $0x1,%edi
    c504:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c50b:	00 
    c50c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c513:	00 
    c514:	e8 87 a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c519:	48 89 c7             	mov    %rax,%rdi
    c51c:	e8 2f a4 ff ff       	call   6950 <fwp_rc_fresh>
    c521:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c528:	00 
    c529:	bf 01 00 00 00       	mov    $0x1,%edi
    c52e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c535:	00 
    c536:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c53d:	00 
    c53e:	e8 5d a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c543:	48 89 c7             	mov    %rax,%rdi
    c546:	e8 05 a4 ff ff       	call   6950 <fwp_rc_fresh>
    c54b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c552:	00 
    c553:	bf 01 00 00 00       	mov    $0x1,%edi
    c558:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c55f:	00 
    c560:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c567:	00 
    c568:	e8 33 a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c56d:	48 89 c7             	mov    %rax,%rdi
    c570:	e8 db a3 ff ff       	call   6950 <fwp_rc_fresh>
    c575:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c57c:	00 
    c57d:	bf 01 00 00 00       	mov    $0x1,%edi
    c582:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c589:	00 
    c58a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c591:	00 
    c592:	e8 09 a2 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c597:	48 89 c7             	mov    %rax,%rdi
    c59a:	e8 b1 a3 ff ff       	call   6950 <fwp_rc_fresh>
    c59f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c5a6:	00 
    c5a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5ac:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c5b3:	00 
    c5b4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c5bb:	00 
    c5bc:	e8 df a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c5c1:	48 89 c7             	mov    %rax,%rdi
    c5c4:	e8 87 a3 ff ff       	call   6950 <fwp_rc_fresh>
    c5c9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c5d0:	00 
    c5d1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5d6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c5dd:	00 
    c5de:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c5e5:	00 
    c5e6:	e8 b5 a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c5eb:	48 89 c7             	mov    %rax,%rdi
    c5ee:	e8 5d a3 ff ff       	call   6950 <fwp_rc_fresh>
    c5f3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c5fa:	00 
    c5fb:	bf 01 00 00 00       	mov    $0x1,%edi
    c600:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c607:	00 
    c608:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c60f:	00 
    c610:	e8 8b a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c615:	48 89 c7             	mov    %rax,%rdi
    c618:	e8 33 a3 ff ff       	call   6950 <fwp_rc_fresh>
    c61d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c624:	00 
    c625:	bf 01 00 00 00       	mov    $0x1,%edi
    c62a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c631:	00 
    c632:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c639:	00 
    c63a:	e8 61 a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c63f:	48 89 c7             	mov    %rax,%rdi
    c642:	e8 09 a3 ff ff       	call   6950 <fwp_rc_fresh>
    c647:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c64e:	00 
    c64f:	bf 01 00 00 00       	mov    $0x1,%edi
    c654:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c65b:	00 
    c65c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c663:	00 
    c664:	e8 37 a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c669:	48 89 c7             	mov    %rax,%rdi
    c66c:	e8 df a2 ff ff       	call   6950 <fwp_rc_fresh>
    c671:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c678:	00 
    c679:	bf 01 00 00 00       	mov    $0x1,%edi
    c67e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c685:	00 
    c686:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c68d:	00 
    c68e:	e8 0d a1 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c693:	48 89 c7             	mov    %rax,%rdi
    c696:	e8 b5 a2 ff ff       	call   6950 <fwp_rc_fresh>
    c69b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c6a2:	00 
    c6a3:	bf 01 00 00 00       	mov    $0x1,%edi
    c6a8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c6af:	00 
    c6b0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c6b7:	00 
    c6b8:	e8 e3 a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c6bd:	48 89 c7             	mov    %rax,%rdi
    c6c0:	e8 8b a2 ff ff       	call   6950 <fwp_rc_fresh>
    c6c5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c6cc:	00 
    c6cd:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c6d9:	00 
    c6da:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c6e1:	00 
    c6e2:	e8 b9 a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c6e7:	48 89 c7             	mov    %rax,%rdi
    c6ea:	e8 61 a2 ff ff       	call   6950 <fwp_rc_fresh>
    c6ef:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c6f6:	00 
    c6f7:	bf 01 00 00 00       	mov    $0x1,%edi
    c6fc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c703:	00 
    c704:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c70b:	00 
    c70c:	e8 8f a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c711:	48 89 c7             	mov    %rax,%rdi
    c714:	e8 37 a2 ff ff       	call   6950 <fwp_rc_fresh>
    c719:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c720:	00 
    c721:	bf 01 00 00 00       	mov    $0x1,%edi
    c726:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c72d:	00 
    c72e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c735:	00 
    c736:	e8 65 a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c73b:	48 89 c7             	mov    %rax,%rdi
    c73e:	e8 0d a2 ff ff       	call   6950 <fwp_rc_fresh>
    c743:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c74a:	00 
    c74b:	bf 01 00 00 00       	mov    $0x1,%edi
    c750:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c757:	00 
    c758:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c75f:	00 
    c760:	e8 3b a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c765:	48 89 c7             	mov    %rax,%rdi
    c768:	e8 e3 a1 ff ff       	call   6950 <fwp_rc_fresh>
    c76d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c774:	00 
    c775:	bf 01 00 00 00       	mov    $0x1,%edi
    c77a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c781:	00 
    c782:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c789:	00 
    c78a:	e8 11 a0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c78f:	48 89 c7             	mov    %rax,%rdi
    c792:	e8 b9 a1 ff ff       	call   6950 <fwp_rc_fresh>
    c797:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c79e:	00 
    c79f:	bf 01 00 00 00       	mov    $0x1,%edi
    c7a4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c7ab:	00 
    c7ac:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c7b3:	00 
    c7b4:	e8 e7 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c7b9:	48 89 c7             	mov    %rax,%rdi
    c7bc:	e8 8f a1 ff ff       	call   6950 <fwp_rc_fresh>
    c7c1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c7c8:	00 
    c7c9:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ce:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c7d5:	00 
    c7d6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c7dd:	00 
    c7de:	e8 bd 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c7e3:	48 89 c7             	mov    %rax,%rdi
    c7e6:	e8 65 a1 ff ff       	call   6950 <fwp_rc_fresh>
    c7eb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c7f2:	00 
    c7f3:	bf 01 00 00 00       	mov    $0x1,%edi
    c7f8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c7ff:	00 
    c800:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c807:	00 
    c808:	e8 93 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c80d:	48 89 c7             	mov    %rax,%rdi
    c810:	e8 3b a1 ff ff       	call   6950 <fwp_rc_fresh>
    c815:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c81c:	00 
    c81d:	bf 01 00 00 00       	mov    $0x1,%edi
    c822:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c829:	00 
    c82a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c831:	00 
    c832:	e8 69 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c837:	48 89 c7             	mov    %rax,%rdi
    c83a:	e8 11 a1 ff ff       	call   6950 <fwp_rc_fresh>
    c83f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c846:	00 
    c847:	bf 01 00 00 00       	mov    $0x1,%edi
    c84c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c853:	00 
    c854:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c85b:	00 
    c85c:	e8 3f 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c861:	48 89 c7             	mov    %rax,%rdi
    c864:	e8 e7 a0 ff ff       	call   6950 <fwp_rc_fresh>
    c869:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c870:	00 
    c871:	bf 01 00 00 00       	mov    $0x1,%edi
    c876:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c87d:	00 
    c87e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c885:	00 
    c886:	e8 15 9f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c88b:	48 89 c7             	mov    %rax,%rdi
    c88e:	e8 bd a0 ff ff       	call   6950 <fwp_rc_fresh>
    c893:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c89a:	00 
    c89b:	bf 01 00 00 00       	mov    $0x1,%edi
    c8a0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c8a7:	00 
    c8a8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c8af:	00 
    c8b0:	e8 eb 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c8b5:	48 89 c7             	mov    %rax,%rdi
    c8b8:	e8 93 a0 ff ff       	call   6950 <fwp_rc_fresh>
    c8bd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c8c4:	00 
    c8c5:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ca:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c8d1:	00 
    c8d2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c8d9:	00 
    c8da:	e8 c1 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c8df:	48 89 c7             	mov    %rax,%rdi
    c8e2:	e8 69 a0 ff ff       	call   6950 <fwp_rc_fresh>
    c8e7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c8ee:	00 
    c8ef:	bf 01 00 00 00       	mov    $0x1,%edi
    c8f4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c8fb:	00 
    c8fc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c903:	00 
    c904:	e8 97 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c909:	48 89 c7             	mov    %rax,%rdi
    c90c:	e8 3f a0 ff ff       	call   6950 <fwp_rc_fresh>
    c911:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c918:	00 
    c919:	bf 01 00 00 00       	mov    $0x1,%edi
    c91e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c925:	00 
    c926:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c92d:	00 
    c92e:	e8 6d 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c933:	48 89 c7             	mov    %rax,%rdi
    c936:	e8 15 a0 ff ff       	call   6950 <fwp_rc_fresh>
    c93b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c942:	00 
    c943:	bf 01 00 00 00       	mov    $0x1,%edi
    c948:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c94f:	00 
    c950:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c957:	00 
    c958:	e8 43 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c95d:	48 89 c7             	mov    %rax,%rdi
    c960:	e8 eb 9f ff ff       	call   6950 <fwp_rc_fresh>
    c965:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c96c:	00 
    c96d:	bf 01 00 00 00       	mov    $0x1,%edi
    c972:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c979:	00 
    c97a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c981:	00 
    c982:	e8 19 9e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c987:	48 89 c7             	mov    %rax,%rdi
    c98a:	e8 c1 9f ff ff       	call   6950 <fwp_rc_fresh>
    c98f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c996:	00 
    c997:	bf 01 00 00 00       	mov    $0x1,%edi
    c99c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c9a3:	00 
    c9a4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c9ab:	00 
    c9ac:	e8 ef 9d ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c9b1:	48 89 c7             	mov    %rax,%rdi
    c9b4:	e8 97 9f ff ff       	call   6950 <fwp_rc_fresh>
    c9b9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c9c0:	00 
    c9c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c9c6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c9cd:	00 
    c9ce:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c9d5:	00 
    c9d6:	e8 c5 9d ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    c9db:	48 89 c7             	mov    %rax,%rdi
    c9de:	e8 6d 9f ff ff       	call   6950 <fwp_rc_fresh>
    c9e3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c9ea:	00 
    c9eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c9f0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c9f7:	00 
    c9f8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c9ff:	00 
    ca00:	e8 9b 9d ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    ca05:	48 8b 15 4c 81 01 00 	mov    0x1814c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ca0c:	49 89 c5             	mov    %rax,%r13
    ca0f:	48 2b 05 1a 81 01 00 	sub    0x1811a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ca16:	48 c1 e2 10          	shl    $0x10,%rdx
    ca1a:	48 39 d0             	cmp    %rdx,%rax
    ca1d:	73 59                	jae    ca78 <f0+0x13b8>
    ca1f:	48 89 c2             	mov    %rax,%rdx
    ca22:	48 c1 ea 10          	shr    $0x10,%rdx
    ca26:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca2a:	48 8b 15 47 81 01 00 	mov    0x18147(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ca31:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca35:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca39:	4d 85 e4             	test   %r12,%r12
    ca3c:	74 3a                	je     ca78 <f0+0x13b8>
    ca3e:	0f b6 0a             	movzbl (%rdx),%ecx
    ca41:	80 f9 02             	cmp    $0x2,%cl
    ca44:	0f 84 c6 15 00 00    	je     e010 <f0+0x2950>
    ca4a:	80 f9 01             	cmp    $0x1,%cl
    ca4d:	75 29                	jne    ca78 <f0+0x13b8>
    ca4f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca52:	0f b7 c0             	movzwl %ax,%eax
    ca55:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca58:	48 0f af c1          	imul   %rcx,%rax
    ca5c:	48 c1 e8 20          	shr    $0x20,%rax
    ca60:	48 39 d0             	cmp    %rdx,%rax
    ca63:	73 13                	jae    ca78 <f0+0x13b8>
    ca65:	49 01 c4             	add    %rax,%r12
    ca68:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca6d:	0f 84 99 17 00 00    	je     e20c <f0+0x2b4c>
    ca73:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca78:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca7f:	33 f3 bf 
    ca82:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    ca89:	00 
    ca8a:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    ca96:	00 
    ca97:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    ca9e:	00 
    ca9f:	e8 fc 9c ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    caa4:	48 8b 15 ad 80 01 00 	mov    0x180ad(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    caab:	49 89 c5             	mov    %rax,%r13
    caae:	48 2b 05 7b 80 01 00 	sub    0x1807b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cab5:	48 c1 e2 10          	shl    $0x10,%rdx
    cab9:	48 39 d0             	cmp    %rdx,%rax
    cabc:	73 59                	jae    cb17 <f0+0x1457>
    cabe:	48 89 c2             	mov    %rax,%rdx
    cac1:	48 c1 ea 10          	shr    $0x10,%rdx
    cac5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cac9:	48 8b 15 a8 80 01 00 	mov    0x180a8(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cad0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cad4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cad8:	4d 85 e4             	test   %r12,%r12
    cadb:	74 3a                	je     cb17 <f0+0x1457>
    cadd:	0f b6 0a             	movzbl (%rdx),%ecx
    cae0:	80 f9 02             	cmp    $0x2,%cl
    cae3:	0f 84 17 15 00 00    	je     e000 <f0+0x2940>
    cae9:	80 f9 01             	cmp    $0x1,%cl
    caec:	75 29                	jne    cb17 <f0+0x1457>
    caee:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caf1:	0f b7 c0             	movzwl %ax,%eax
    caf4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    caf7:	48 0f af c1          	imul   %rcx,%rax
    cafb:	48 c1 e8 20          	shr    $0x20,%rax
    caff:	48 39 d0             	cmp    %rdx,%rax
    cb02:	73 13                	jae    cb17 <f0+0x1457>
    cb04:	49 01 c4             	add    %rax,%r12
    cb07:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb0c:	0f 84 07 17 00 00    	je     e219 <f0+0x2b59>
    cb12:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb17:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb1e:	00 f0 3f 
    cb21:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    cb28:	00 
    cb29:	bf 01 00 00 00       	mov    $0x1,%edi
    cb2e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    cb35:	00 
    cb36:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    cb3d:	00 
    cb3e:	e8 5d 9c ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cb43:	48 8b 15 0e 80 01 00 	mov    0x1800e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cb4a:	49 89 c5             	mov    %rax,%r13
    cb4d:	48 2b 05 dc 7f 01 00 	sub    0x17fdc(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cb54:	48 c1 e2 10          	shl    $0x10,%rdx
    cb58:	48 39 d0             	cmp    %rdx,%rax
    cb5b:	73 59                	jae    cbb6 <f0+0x14f6>
    cb5d:	48 89 c2             	mov    %rax,%rdx
    cb60:	48 c1 ea 10          	shr    $0x10,%rdx
    cb64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb68:	48 8b 15 09 80 01 00 	mov    0x18009(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cb6f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb73:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb77:	4d 85 e4             	test   %r12,%r12
    cb7a:	74 3a                	je     cbb6 <f0+0x14f6>
    cb7c:	0f b6 0a             	movzbl (%rdx),%ecx
    cb7f:	80 f9 02             	cmp    $0x2,%cl
    cb82:	0f 84 28 15 00 00    	je     e0b0 <f0+0x29f0>
    cb88:	80 f9 01             	cmp    $0x1,%cl
    cb8b:	75 29                	jne    cbb6 <f0+0x14f6>
    cb8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb90:	0f b7 c0             	movzwl %ax,%eax
    cb93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb96:	48 0f af c1          	imul   %rcx,%rax
    cb9a:	48 c1 e8 20          	shr    $0x20,%rax
    cb9e:	48 39 d0             	cmp    %rdx,%rax
    cba1:	73 13                	jae    cbb6 <f0+0x14f6>
    cba3:	49 01 c4             	add    %rax,%r12
    cba6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbab:	0f 84 75 16 00 00    	je     e226 <f0+0x2b66>
    cbb1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbb6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbbd:	33 f3 bf 
    cbc0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    cbc7:	00 
    cbc8:	bf 01 00 00 00       	mov    $0x1,%edi
    cbcd:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    cbd4:	00 
    cbd5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    cbdc:	00 
    cbdd:	e8 be 9b ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cbe2:	48 8b 15 6f 7f 01 00 	mov    0x17f6f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cbe9:	49 89 c5             	mov    %rax,%r13
    cbec:	48 2b 05 3d 7f 01 00 	sub    0x17f3d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cbf3:	48 c1 e2 10          	shl    $0x10,%rdx
    cbf7:	48 39 d0             	cmp    %rdx,%rax
    cbfa:	73 59                	jae    cc55 <f0+0x1595>
    cbfc:	48 89 c2             	mov    %rax,%rdx
    cbff:	48 c1 ea 10          	shr    $0x10,%rdx
    cc03:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc07:	48 8b 15 6a 7f 01 00 	mov    0x17f6a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cc0e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc12:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc16:	4d 85 e4             	test   %r12,%r12
    cc19:	74 3a                	je     cc55 <f0+0x1595>
    cc1b:	0f b6 0a             	movzbl (%rdx),%ecx
    cc1e:	80 f9 02             	cmp    $0x2,%cl
    cc21:	0f 84 79 14 00 00    	je     e0a0 <f0+0x29e0>
    cc27:	80 f9 01             	cmp    $0x1,%cl
    cc2a:	75 29                	jne    cc55 <f0+0x1595>
    cc2c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc2f:	0f b7 c0             	movzwl %ax,%eax
    cc32:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc35:	48 0f af c1          	imul   %rcx,%rax
    cc39:	48 c1 e8 20          	shr    $0x20,%rax
    cc3d:	48 39 d0             	cmp    %rdx,%rax
    cc40:	73 13                	jae    cc55 <f0+0x1595>
    cc42:	49 01 c4             	add    %rax,%r12
    cc45:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc4a:	0f 84 e3 15 00 00    	je     e233 <f0+0x2b73>
    cc50:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc55:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc5c:	00 f0 3f 
    cc5f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cc66:	00 
    cc67:	bf 01 00 00 00       	mov    $0x1,%edi
    cc6c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    cc73:	00 
    cc74:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cc7b:	00 
    cc7c:	e8 1f 9b ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cc81:	48 8b 15 d0 7e 01 00 	mov    0x17ed0(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cc88:	49 89 c5             	mov    %rax,%r13
    cc8b:	48 2b 05 9e 7e 01 00 	sub    0x17e9e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cc92:	48 c1 e2 10          	shl    $0x10,%rdx
    cc96:	48 39 d0             	cmp    %rdx,%rax
    cc99:	73 59                	jae    ccf4 <f0+0x1634>
    cc9b:	48 89 c2             	mov    %rax,%rdx
    cc9e:	48 c1 ea 10          	shr    $0x10,%rdx
    cca2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cca6:	48 8b 15 cb 7e 01 00 	mov    0x17ecb(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ccad:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccb1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccb5:	4d 85 e4             	test   %r12,%r12
    ccb8:	74 3a                	je     ccf4 <f0+0x1634>
    ccba:	0f b6 0a             	movzbl (%rdx),%ecx
    ccbd:	80 f9 02             	cmp    $0x2,%cl
    ccc0:	0f 84 ca 13 00 00    	je     e090 <f0+0x29d0>
    ccc6:	80 f9 01             	cmp    $0x1,%cl
    ccc9:	75 29                	jne    ccf4 <f0+0x1634>
    cccb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccce:	0f b7 c0             	movzwl %ax,%eax
    ccd1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccd4:	48 0f af c1          	imul   %rcx,%rax
    ccd8:	48 c1 e8 20          	shr    $0x20,%rax
    ccdc:	48 39 d0             	cmp    %rdx,%rax
    ccdf:	73 13                	jae    ccf4 <f0+0x1634>
    cce1:	49 01 c4             	add    %rax,%r12
    cce4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cce9:	0f 84 51 15 00 00    	je     e240 <f0+0x2b80>
    ccef:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccf4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccfb:	33 f3 bf 
    ccfe:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cd05:	00 
    cd06:	bf 01 00 00 00       	mov    $0x1,%edi
    cd0b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cd12:	00 
    cd13:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cd1a:	00 
    cd1b:	e8 80 9a ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cd20:	48 8b 15 31 7e 01 00 	mov    0x17e31(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cd27:	49 89 c5             	mov    %rax,%r13
    cd2a:	48 2b 05 ff 7d 01 00 	sub    0x17dff(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cd31:	48 c1 e2 10          	shl    $0x10,%rdx
    cd35:	48 39 d0             	cmp    %rdx,%rax
    cd38:	73 59                	jae    cd93 <f0+0x16d3>
    cd3a:	48 89 c2             	mov    %rax,%rdx
    cd3d:	48 c1 ea 10          	shr    $0x10,%rdx
    cd41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd45:	48 8b 15 2c 7e 01 00 	mov    0x17e2c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cd4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd50:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd54:	4d 85 e4             	test   %r12,%r12
    cd57:	74 3a                	je     cd93 <f0+0x16d3>
    cd59:	0f b6 0a             	movzbl (%rdx),%ecx
    cd5c:	80 f9 02             	cmp    $0x2,%cl
    cd5f:	0f 84 1b 13 00 00    	je     e080 <f0+0x29c0>
    cd65:	80 f9 01             	cmp    $0x1,%cl
    cd68:	75 29                	jne    cd93 <f0+0x16d3>
    cd6a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd6d:	0f b7 c0             	movzwl %ax,%eax
    cd70:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd73:	48 0f af c1          	imul   %rcx,%rax
    cd77:	48 c1 e8 20          	shr    $0x20,%rax
    cd7b:	48 39 d0             	cmp    %rdx,%rax
    cd7e:	73 13                	jae    cd93 <f0+0x16d3>
    cd80:	49 01 c4             	add    %rax,%r12
    cd83:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd88:	0f 84 bf 14 00 00    	je     e24d <f0+0x2b8d>
    cd8e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd93:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd9a:	00 f0 3f 
    cd9d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cda4:	00 
    cda5:	bf 01 00 00 00       	mov    $0x1,%edi
    cdaa:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cdb1:	00 
    cdb2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cdb9:	00 
    cdba:	e8 e1 99 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cdbf:	48 8b 15 92 7d 01 00 	mov    0x17d92(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cdc6:	49 89 c5             	mov    %rax,%r13
    cdc9:	48 2b 05 60 7d 01 00 	sub    0x17d60(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cdd0:	48 c1 e2 10          	shl    $0x10,%rdx
    cdd4:	48 39 d0             	cmp    %rdx,%rax
    cdd7:	73 59                	jae    ce32 <f0+0x1772>
    cdd9:	48 89 c2             	mov    %rax,%rdx
    cddc:	48 c1 ea 10          	shr    $0x10,%rdx
    cde0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cde4:	48 8b 15 8d 7d 01 00 	mov    0x17d8d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cdeb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdf3:	4d 85 e4             	test   %r12,%r12
    cdf6:	74 3a                	je     ce32 <f0+0x1772>
    cdf8:	0f b6 0a             	movzbl (%rdx),%ecx
    cdfb:	80 f9 02             	cmp    $0x2,%cl
    cdfe:	0f 84 6c 12 00 00    	je     e070 <f0+0x29b0>
    ce04:	80 f9 01             	cmp    $0x1,%cl
    ce07:	75 29                	jne    ce32 <f0+0x1772>
    ce09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce0c:	0f b7 c0             	movzwl %ax,%eax
    ce0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce12:	48 0f af c1          	imul   %rcx,%rax
    ce16:	48 c1 e8 20          	shr    $0x20,%rax
    ce1a:	48 39 d0             	cmp    %rdx,%rax
    ce1d:	73 13                	jae    ce32 <f0+0x1772>
    ce1f:	49 01 c4             	add    %rax,%r12
    ce22:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce27:	0f 84 2d 14 00 00    	je     e25a <f0+0x2b9a>
    ce2d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce32:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce39:	33 f3 bf 
    ce3c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    ce43:	00 
    ce44:	bf 01 00 00 00       	mov    $0x1,%edi
    ce49:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    ce50:	00 
    ce51:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    ce58:	00 
    ce59:	e8 42 99 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    ce5e:	48 8b 15 f3 7c 01 00 	mov    0x17cf3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ce65:	49 89 c5             	mov    %rax,%r13
    ce68:	48 2b 05 c1 7c 01 00 	sub    0x17cc1(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ce6f:	48 c1 e2 10          	shl    $0x10,%rdx
    ce73:	48 39 d0             	cmp    %rdx,%rax
    ce76:	73 59                	jae    ced1 <f0+0x1811>
    ce78:	48 89 c2             	mov    %rax,%rdx
    ce7b:	48 c1 ea 10          	shr    $0x10,%rdx
    ce7f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce83:	48 8b 15 ee 7c 01 00 	mov    0x17cee(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ce8a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce8e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce92:	4d 85 e4             	test   %r12,%r12
    ce95:	74 3a                	je     ced1 <f0+0x1811>
    ce97:	0f b6 0a             	movzbl (%rdx),%ecx
    ce9a:	80 f9 02             	cmp    $0x2,%cl
    ce9d:	0f 84 bd 11 00 00    	je     e060 <f0+0x29a0>
    cea3:	80 f9 01             	cmp    $0x1,%cl
    cea6:	75 29                	jne    ced1 <f0+0x1811>
    cea8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ceab:	0f b7 c0             	movzwl %ax,%eax
    ceae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ceb1:	48 0f af c1          	imul   %rcx,%rax
    ceb5:	48 c1 e8 20          	shr    $0x20,%rax
    ceb9:	48 39 d0             	cmp    %rdx,%rax
    cebc:	73 13                	jae    ced1 <f0+0x1811>
    cebe:	49 01 c4             	add    %rax,%r12
    cec1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cec6:	0f 84 9b 13 00 00    	je     e267 <f0+0x2ba7>
    cecc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ced1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ced8:	00 f0 3f 
    cedb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cee2:	00 
    cee3:	bf 01 00 00 00       	mov    $0x1,%edi
    cee8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    ceef:	00 
    cef0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cef7:	00 
    cef8:	e8 a3 98 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cefd:	48 8b 15 54 7c 01 00 	mov    0x17c54(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cf04:	49 89 c5             	mov    %rax,%r13
    cf07:	48 2b 05 22 7c 01 00 	sub    0x17c22(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cf0e:	48 c1 e2 10          	shl    $0x10,%rdx
    cf12:	48 39 d0             	cmp    %rdx,%rax
    cf15:	73 59                	jae    cf70 <f0+0x18b0>
    cf17:	48 89 c2             	mov    %rax,%rdx
    cf1a:	48 c1 ea 10          	shr    $0x10,%rdx
    cf1e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf22:	48 8b 15 4f 7c 01 00 	mov    0x17c4f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cf29:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf2d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf31:	4d 85 e4             	test   %r12,%r12
    cf34:	74 3a                	je     cf70 <f0+0x18b0>
    cf36:	0f b6 0a             	movzbl (%rdx),%ecx
    cf39:	80 f9 02             	cmp    $0x2,%cl
    cf3c:	0f 84 0e 11 00 00    	je     e050 <f0+0x2990>
    cf42:	80 f9 01             	cmp    $0x1,%cl
    cf45:	75 29                	jne    cf70 <f0+0x18b0>
    cf47:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf4a:	0f b7 c0             	movzwl %ax,%eax
    cf4d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf50:	48 0f af c1          	imul   %rcx,%rax
    cf54:	48 c1 e8 20          	shr    $0x20,%rax
    cf58:	48 39 d0             	cmp    %rdx,%rax
    cf5b:	73 13                	jae    cf70 <f0+0x18b0>
    cf5d:	49 01 c4             	add    %rax,%r12
    cf60:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf65:	0f 84 09 13 00 00    	je     e274 <f0+0x2bb4>
    cf6b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf70:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf77:	33 f3 bf 
    cf7a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    cf81:	00 
    cf82:	bf 01 00 00 00       	mov    $0x1,%edi
    cf87:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    cf8e:	00 
    cf8f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    cf96:	00 
    cf97:	e8 04 98 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    cf9c:	48 8b 15 b5 7b 01 00 	mov    0x17bb5(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cfa3:	49 89 c5             	mov    %rax,%r13
    cfa6:	48 2b 05 83 7b 01 00 	sub    0x17b83(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cfad:	48 c1 e2 10          	shl    $0x10,%rdx
    cfb1:	48 39 d0             	cmp    %rdx,%rax
    cfb4:	73 59                	jae    d00f <f0+0x194f>
    cfb6:	48 89 c2             	mov    %rax,%rdx
    cfb9:	48 c1 ea 10          	shr    $0x10,%rdx
    cfbd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfc1:	48 8b 15 b0 7b 01 00 	mov    0x17bb0(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cfc8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfcc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfd0:	4d 85 e4             	test   %r12,%r12
    cfd3:	74 3a                	je     d00f <f0+0x194f>
    cfd5:	0f b6 0a             	movzbl (%rdx),%ecx
    cfd8:	80 f9 02             	cmp    $0x2,%cl
    cfdb:	0f 84 5f 10 00 00    	je     e040 <f0+0x2980>
    cfe1:	80 f9 01             	cmp    $0x1,%cl
    cfe4:	75 29                	jne    d00f <f0+0x194f>
    cfe6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfe9:	0f b7 c0             	movzwl %ax,%eax
    cfec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfef:	48 0f af c1          	imul   %rcx,%rax
    cff3:	48 c1 e8 20          	shr    $0x20,%rax
    cff7:	48 39 d0             	cmp    %rdx,%rax
    cffa:	73 13                	jae    d00f <f0+0x194f>
    cffc:	49 01 c4             	add    %rax,%r12
    cfff:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d004:	0f 84 77 12 00 00    	je     e281 <f0+0x2bc1>
    d00a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d00f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d016:	00 f0 3f 
    d019:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d020:	00 
    d021:	bf 01 00 00 00       	mov    $0x1,%edi
    d026:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d02d:	00 
    d02e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d035:	00 
    d036:	e8 65 97 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d03b:	48 8b 15 16 7b 01 00 	mov    0x17b16(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d042:	49 89 c5             	mov    %rax,%r13
    d045:	48 2b 05 e4 7a 01 00 	sub    0x17ae4(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d04c:	48 c1 e2 10          	shl    $0x10,%rdx
    d050:	48 39 d0             	cmp    %rdx,%rax
    d053:	73 59                	jae    d0ae <f0+0x19ee>
    d055:	48 89 c2             	mov    %rax,%rdx
    d058:	48 c1 ea 10          	shr    $0x10,%rdx
    d05c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d060:	48 8b 15 11 7b 01 00 	mov    0x17b11(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d067:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d06b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d06f:	4d 85 e4             	test   %r12,%r12
    d072:	74 3a                	je     d0ae <f0+0x19ee>
    d074:	0f b6 0a             	movzbl (%rdx),%ecx
    d077:	80 f9 02             	cmp    $0x2,%cl
    d07a:	0f 84 40 0f 00 00    	je     dfc0 <f0+0x2900>
    d080:	80 f9 01             	cmp    $0x1,%cl
    d083:	75 29                	jne    d0ae <f0+0x19ee>
    d085:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d088:	0f b7 c0             	movzwl %ax,%eax
    d08b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d08e:	48 0f af c1          	imul   %rcx,%rax
    d092:	48 c1 e8 20          	shr    $0x20,%rax
    d096:	48 39 d0             	cmp    %rdx,%rax
    d099:	73 13                	jae    d0ae <f0+0x19ee>
    d09b:	49 01 c4             	add    %rax,%r12
    d09e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0a3:	0f 84 e5 11 00 00    	je     e28e <f0+0x2bce>
    d0a9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0ae:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0b5:	33 f3 bf 
    d0b8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d0bf:	00 
    d0c0:	bf 01 00 00 00       	mov    $0x1,%edi
    d0c5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d0cc:	00 
    d0cd:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d0d4:	00 
    d0d5:	e8 c6 96 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d0da:	48 8b 15 77 7a 01 00 	mov    0x17a77(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d0e1:	49 89 c5             	mov    %rax,%r13
    d0e4:	48 2b 05 45 7a 01 00 	sub    0x17a45(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d0eb:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ef:	48 39 d0             	cmp    %rdx,%rax
    d0f2:	73 59                	jae    d14d <f0+0x1a8d>
    d0f4:	48 89 c2             	mov    %rax,%rdx
    d0f7:	48 c1 ea 10          	shr    $0x10,%rdx
    d0fb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0ff:	48 8b 15 72 7a 01 00 	mov    0x17a72(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d106:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d10a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d10e:	4d 85 e4             	test   %r12,%r12
    d111:	74 3a                	je     d14d <f0+0x1a8d>
    d113:	0f b6 0a             	movzbl (%rdx),%ecx
    d116:	80 f9 02             	cmp    $0x2,%cl
    d119:	0f 84 91 0e 00 00    	je     dfb0 <f0+0x28f0>
    d11f:	80 f9 01             	cmp    $0x1,%cl
    d122:	75 29                	jne    d14d <f0+0x1a8d>
    d124:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d127:	0f b7 c0             	movzwl %ax,%eax
    d12a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d12d:	48 0f af c1          	imul   %rcx,%rax
    d131:	48 c1 e8 20          	shr    $0x20,%rax
    d135:	48 39 d0             	cmp    %rdx,%rax
    d138:	73 13                	jae    d14d <f0+0x1a8d>
    d13a:	49 01 c4             	add    %rax,%r12
    d13d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d142:	0f 84 53 11 00 00    	je     e29b <f0+0x2bdb>
    d148:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d14d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d154:	00 f0 3f 
    d157:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d15e:	00 
    d15f:	bf 01 00 00 00       	mov    $0x1,%edi
    d164:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d16b:	00 
    d16c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d173:	00 
    d174:	e8 27 96 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d179:	48 8b 15 d8 79 01 00 	mov    0x179d8(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d180:	49 89 c5             	mov    %rax,%r13
    d183:	48 2b 05 a6 79 01 00 	sub    0x179a6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d18a:	48 c1 e2 10          	shl    $0x10,%rdx
    d18e:	48 39 d0             	cmp    %rdx,%rax
    d191:	73 59                	jae    d1ec <f0+0x1b2c>
    d193:	48 89 c2             	mov    %rax,%rdx
    d196:	48 c1 ea 10          	shr    $0x10,%rdx
    d19a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d19e:	48 8b 15 d3 79 01 00 	mov    0x179d3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d1a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1ad:	4d 85 e4             	test   %r12,%r12
    d1b0:	74 3a                	je     d1ec <f0+0x1b2c>
    d1b2:	0f b6 0a             	movzbl (%rdx),%ecx
    d1b5:	80 f9 02             	cmp    $0x2,%cl
    d1b8:	0f 84 e2 0d 00 00    	je     dfa0 <f0+0x28e0>
    d1be:	80 f9 01             	cmp    $0x1,%cl
    d1c1:	75 29                	jne    d1ec <f0+0x1b2c>
    d1c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1c6:	0f b7 c0             	movzwl %ax,%eax
    d1c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1cc:	48 0f af c1          	imul   %rcx,%rax
    d1d0:	48 c1 e8 20          	shr    $0x20,%rax
    d1d4:	48 39 d0             	cmp    %rdx,%rax
    d1d7:	73 13                	jae    d1ec <f0+0x1b2c>
    d1d9:	49 01 c4             	add    %rax,%r12
    d1dc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1e1:	0f 84 c1 10 00 00    	je     e2a8 <f0+0x2be8>
    d1e7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1f3:	33 f3 bf 
    d1f6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d1fd:	00 
    d1fe:	bf 01 00 00 00       	mov    $0x1,%edi
    d203:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d20a:	00 
    d20b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d212:	00 
    d213:	e8 88 95 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d218:	48 8b 15 39 79 01 00 	mov    0x17939(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d21f:	49 89 c5             	mov    %rax,%r13
    d222:	48 2b 05 07 79 01 00 	sub    0x17907(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d229:	48 c1 e2 10          	shl    $0x10,%rdx
    d22d:	48 39 d0             	cmp    %rdx,%rax
    d230:	73 59                	jae    d28b <f0+0x1bcb>
    d232:	48 89 c2             	mov    %rax,%rdx
    d235:	48 c1 ea 10          	shr    $0x10,%rdx
    d239:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d23d:	48 8b 15 34 79 01 00 	mov    0x17934(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d244:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d248:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d24c:	4d 85 e4             	test   %r12,%r12
    d24f:	74 3a                	je     d28b <f0+0x1bcb>
    d251:	0f b6 0a             	movzbl (%rdx),%ecx
    d254:	80 f9 02             	cmp    $0x2,%cl
    d257:	0f 84 33 0d 00 00    	je     df90 <f0+0x28d0>
    d25d:	80 f9 01             	cmp    $0x1,%cl
    d260:	75 29                	jne    d28b <f0+0x1bcb>
    d262:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d265:	0f b7 c0             	movzwl %ax,%eax
    d268:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d26b:	48 0f af c1          	imul   %rcx,%rax
    d26f:	48 c1 e8 20          	shr    $0x20,%rax
    d273:	48 39 d0             	cmp    %rdx,%rax
    d276:	73 13                	jae    d28b <f0+0x1bcb>
    d278:	49 01 c4             	add    %rax,%r12
    d27b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d280:	0f 84 2f 10 00 00    	je     e2b5 <f0+0x2bf5>
    d286:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d28b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d292:	00 f0 3f 
    d295:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d29c:	00 
    d29d:	bf 01 00 00 00       	mov    $0x1,%edi
    d2a2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d2a9:	00 
    d2aa:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d2b1:	00 
    d2b2:	e8 e9 94 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d2b7:	48 8b 15 9a 78 01 00 	mov    0x1789a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d2be:	49 89 c5             	mov    %rax,%r13
    d2c1:	48 2b 05 68 78 01 00 	sub    0x17868(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d2c8:	48 c1 e2 10          	shl    $0x10,%rdx
    d2cc:	48 39 d0             	cmp    %rdx,%rax
    d2cf:	73 59                	jae    d32a <f0+0x1c6a>
    d2d1:	48 89 c2             	mov    %rax,%rdx
    d2d4:	48 c1 ea 10          	shr    $0x10,%rdx
    d2d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2dc:	48 8b 15 95 78 01 00 	mov    0x17895(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d2e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2eb:	4d 85 e4             	test   %r12,%r12
    d2ee:	74 3a                	je     d32a <f0+0x1c6a>
    d2f0:	0f b6 0a             	movzbl (%rdx),%ecx
    d2f3:	80 f9 02             	cmp    $0x2,%cl
    d2f6:	0f 84 84 0c 00 00    	je     df80 <f0+0x28c0>
    d2fc:	80 f9 01             	cmp    $0x1,%cl
    d2ff:	75 29                	jne    d32a <f0+0x1c6a>
    d301:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d304:	0f b7 c0             	movzwl %ax,%eax
    d307:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d30a:	48 0f af c1          	imul   %rcx,%rax
    d30e:	48 c1 e8 20          	shr    $0x20,%rax
    d312:	48 39 d0             	cmp    %rdx,%rax
    d315:	73 13                	jae    d32a <f0+0x1c6a>
    d317:	49 01 c4             	add    %rax,%r12
    d31a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d31f:	0f 84 9d 0f 00 00    	je     e2c2 <f0+0x2c02>
    d325:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d32a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d331:	33 f3 bf 
    d334:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d33b:	00 
    d33c:	bf 01 00 00 00       	mov    $0x1,%edi
    d341:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d348:	00 
    d349:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d350:	00 
    d351:	e8 4a 94 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d356:	48 8b 15 fb 77 01 00 	mov    0x177fb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d35d:	49 89 c5             	mov    %rax,%r13
    d360:	48 2b 05 c9 77 01 00 	sub    0x177c9(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d367:	48 c1 e2 10          	shl    $0x10,%rdx
    d36b:	48 39 d0             	cmp    %rdx,%rax
    d36e:	73 59                	jae    d3c9 <f0+0x1d09>
    d370:	48 89 c2             	mov    %rax,%rdx
    d373:	48 c1 ea 10          	shr    $0x10,%rdx
    d377:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d37b:	48 8b 15 f6 77 01 00 	mov    0x177f6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d382:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d386:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d38a:	4d 85 e4             	test   %r12,%r12
    d38d:	74 3a                	je     d3c9 <f0+0x1d09>
    d38f:	0f b6 0a             	movzbl (%rdx),%ecx
    d392:	80 f9 02             	cmp    $0x2,%cl
    d395:	0f 84 d5 0b 00 00    	je     df70 <f0+0x28b0>
    d39b:	80 f9 01             	cmp    $0x1,%cl
    d39e:	75 29                	jne    d3c9 <f0+0x1d09>
    d3a0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3a3:	0f b7 c0             	movzwl %ax,%eax
    d3a6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3a9:	48 0f af c1          	imul   %rcx,%rax
    d3ad:	48 c1 e8 20          	shr    $0x20,%rax
    d3b1:	48 39 d0             	cmp    %rdx,%rax
    d3b4:	73 13                	jae    d3c9 <f0+0x1d09>
    d3b6:	49 01 c4             	add    %rax,%r12
    d3b9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3be:	0f 84 0b 0f 00 00    	je     e2cf <f0+0x2c0f>
    d3c4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3c9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3d0:	00 f0 3f 
    d3d3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d3da:	00 
    d3db:	bf 01 00 00 00       	mov    $0x1,%edi
    d3e0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d3e7:	00 
    d3e8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d3ef:	00 
    d3f0:	e8 ab 93 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d3f5:	48 8b 15 5c 77 01 00 	mov    0x1775c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d3fc:	49 89 c5             	mov    %rax,%r13
    d3ff:	48 2b 05 2a 77 01 00 	sub    0x1772a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d406:	48 c1 e2 10          	shl    $0x10,%rdx
    d40a:	48 39 d0             	cmp    %rdx,%rax
    d40d:	73 59                	jae    d468 <f0+0x1da8>
    d40f:	48 89 c2             	mov    %rax,%rdx
    d412:	48 c1 ea 10          	shr    $0x10,%rdx
    d416:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d41a:	48 8b 15 57 77 01 00 	mov    0x17757(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d421:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d425:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d429:	4d 85 e4             	test   %r12,%r12
    d42c:	74 3a                	je     d468 <f0+0x1da8>
    d42e:	0f b6 0a             	movzbl (%rdx),%ecx
    d431:	80 f9 02             	cmp    $0x2,%cl
    d434:	0f 84 26 0b 00 00    	je     df60 <f0+0x28a0>
    d43a:	80 f9 01             	cmp    $0x1,%cl
    d43d:	75 29                	jne    d468 <f0+0x1da8>
    d43f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d442:	0f b7 c0             	movzwl %ax,%eax
    d445:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d448:	48 0f af c1          	imul   %rcx,%rax
    d44c:	48 c1 e8 20          	shr    $0x20,%rax
    d450:	48 39 d0             	cmp    %rdx,%rax
    d453:	73 13                	jae    d468 <f0+0x1da8>
    d455:	49 01 c4             	add    %rax,%r12
    d458:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d45d:	0f 84 79 0e 00 00    	je     e2dc <f0+0x2c1c>
    d463:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d468:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d46f:	33 f3 bf 
    d472:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d479:	00 
    d47a:	bf 01 00 00 00       	mov    $0x1,%edi
    d47f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d486:	00 
    d487:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d48e:	00 
    d48f:	e8 0c 93 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d494:	48 8b 15 bd 76 01 00 	mov    0x176bd(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d49b:	49 89 c5             	mov    %rax,%r13
    d49e:	48 2b 05 8b 76 01 00 	sub    0x1768b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d4a5:	48 c1 e2 10          	shl    $0x10,%rdx
    d4a9:	48 39 d0             	cmp    %rdx,%rax
    d4ac:	73 59                	jae    d507 <f0+0x1e47>
    d4ae:	48 89 c2             	mov    %rax,%rdx
    d4b1:	48 c1 ea 10          	shr    $0x10,%rdx
    d4b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4b9:	48 8b 15 b8 76 01 00 	mov    0x176b8(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d4c0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4c4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4c8:	4d 85 e4             	test   %r12,%r12
    d4cb:	74 3a                	je     d507 <f0+0x1e47>
    d4cd:	0f b6 0a             	movzbl (%rdx),%ecx
    d4d0:	80 f9 02             	cmp    $0x2,%cl
    d4d3:	0f 84 77 0a 00 00    	je     df50 <f0+0x2890>
    d4d9:	80 f9 01             	cmp    $0x1,%cl
    d4dc:	75 29                	jne    d507 <f0+0x1e47>
    d4de:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4e1:	0f b7 c0             	movzwl %ax,%eax
    d4e4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4e7:	48 0f af c1          	imul   %rcx,%rax
    d4eb:	48 c1 e8 20          	shr    $0x20,%rax
    d4ef:	48 39 d0             	cmp    %rdx,%rax
    d4f2:	73 13                	jae    d507 <f0+0x1e47>
    d4f4:	49 01 c4             	add    %rax,%r12
    d4f7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4fc:	0f 84 e7 0d 00 00    	je     e2e9 <f0+0x2c29>
    d502:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d507:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d50e:	00 f0 3f 
    d511:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d518:	00 
    d519:	bf 01 00 00 00       	mov    $0x1,%edi
    d51e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d525:	00 
    d526:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d52d:	00 
    d52e:	e8 6d 92 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d533:	48 8b 15 1e 76 01 00 	mov    0x1761e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d53a:	49 89 c5             	mov    %rax,%r13
    d53d:	48 2b 05 ec 75 01 00 	sub    0x175ec(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d544:	48 c1 e2 10          	shl    $0x10,%rdx
    d548:	48 39 d0             	cmp    %rdx,%rax
    d54b:	73 59                	jae    d5a6 <f0+0x1ee6>
    d54d:	48 89 c2             	mov    %rax,%rdx
    d550:	48 c1 ea 10          	shr    $0x10,%rdx
    d554:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d558:	48 8b 15 19 76 01 00 	mov    0x17619(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d55f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d563:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d567:	4d 85 e4             	test   %r12,%r12
    d56a:	74 3a                	je     d5a6 <f0+0x1ee6>
    d56c:	0f b6 0a             	movzbl (%rdx),%ecx
    d56f:	80 f9 02             	cmp    $0x2,%cl
    d572:	0f 84 38 0c 00 00    	je     e1b0 <f0+0x2af0>
    d578:	80 f9 01             	cmp    $0x1,%cl
    d57b:	75 29                	jne    d5a6 <f0+0x1ee6>
    d57d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d580:	0f b7 c0             	movzwl %ax,%eax
    d583:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d586:	48 0f af c1          	imul   %rcx,%rax
    d58a:	48 c1 e8 20          	shr    $0x20,%rax
    d58e:	48 39 d0             	cmp    %rdx,%rax
    d591:	73 13                	jae    d5a6 <f0+0x1ee6>
    d593:	49 01 c4             	add    %rax,%r12
    d596:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d59b:	0f 84 55 0d 00 00    	je     e2f6 <f0+0x2c36>
    d5a1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5a6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5ad:	33 f3 bf 
    d5b0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d5b7:	00 
    d5b8:	bf 01 00 00 00       	mov    $0x1,%edi
    d5bd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d5c4:	00 
    d5c5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d5cc:	00 
    d5cd:	e8 ce 91 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d5d2:	48 8b 15 7f 75 01 00 	mov    0x1757f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d5d9:	49 89 c5             	mov    %rax,%r13
    d5dc:	48 2b 05 4d 75 01 00 	sub    0x1754d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d5e3:	48 c1 e2 10          	shl    $0x10,%rdx
    d5e7:	48 39 d0             	cmp    %rdx,%rax
    d5ea:	73 59                	jae    d645 <f0+0x1f85>
    d5ec:	48 89 c2             	mov    %rax,%rdx
    d5ef:	48 c1 ea 10          	shr    $0x10,%rdx
    d5f3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5f7:	48 8b 15 7a 75 01 00 	mov    0x1757a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d5fe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d602:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d606:	4d 85 e4             	test   %r12,%r12
    d609:	74 3a                	je     d645 <f0+0x1f85>
    d60b:	0f b6 0a             	movzbl (%rdx),%ecx
    d60e:	80 f9 02             	cmp    $0x2,%cl
    d611:	0f 84 89 0b 00 00    	je     e1a0 <f0+0x2ae0>
    d617:	80 f9 01             	cmp    $0x1,%cl
    d61a:	75 29                	jne    d645 <f0+0x1f85>
    d61c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d61f:	0f b7 c0             	movzwl %ax,%eax
    d622:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d625:	48 0f af c1          	imul   %rcx,%rax
    d629:	48 c1 e8 20          	shr    $0x20,%rax
    d62d:	48 39 d0             	cmp    %rdx,%rax
    d630:	73 13                	jae    d645 <f0+0x1f85>
    d632:	49 01 c4             	add    %rax,%r12
    d635:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d63a:	0f 84 c3 0c 00 00    	je     e303 <f0+0x2c43>
    d640:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d645:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d64c:	00 f0 3f 
    d64f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d656:	00 
    d657:	bf 01 00 00 00       	mov    $0x1,%edi
    d65c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d663:	00 
    d664:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d66b:	00 
    d66c:	e8 2f 91 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d671:	48 8b 15 e0 74 01 00 	mov    0x174e0(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d678:	49 89 c5             	mov    %rax,%r13
    d67b:	48 2b 05 ae 74 01 00 	sub    0x174ae(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d682:	48 c1 e2 10          	shl    $0x10,%rdx
    d686:	48 39 d0             	cmp    %rdx,%rax
    d689:	73 59                	jae    d6e4 <f0+0x2024>
    d68b:	48 89 c2             	mov    %rax,%rdx
    d68e:	48 c1 ea 10          	shr    $0x10,%rdx
    d692:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d696:	48 8b 15 db 74 01 00 	mov    0x174db(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d69d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6a1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6a5:	4d 85 e4             	test   %r12,%r12
    d6a8:	74 3a                	je     d6e4 <f0+0x2024>
    d6aa:	0f b6 0a             	movzbl (%rdx),%ecx
    d6ad:	80 f9 02             	cmp    $0x2,%cl
    d6b0:	0f 84 da 0a 00 00    	je     e190 <f0+0x2ad0>
    d6b6:	80 f9 01             	cmp    $0x1,%cl
    d6b9:	75 29                	jne    d6e4 <f0+0x2024>
    d6bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6be:	0f b7 c0             	movzwl %ax,%eax
    d6c1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6c4:	48 0f af c1          	imul   %rcx,%rax
    d6c8:	48 c1 e8 20          	shr    $0x20,%rax
    d6cc:	48 39 d0             	cmp    %rdx,%rax
    d6cf:	73 13                	jae    d6e4 <f0+0x2024>
    d6d1:	49 01 c4             	add    %rax,%r12
    d6d4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6d9:	0f 84 31 0c 00 00    	je     e310 <f0+0x2c50>
    d6df:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6e4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6eb:	33 f3 bf 
    d6ee:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d6f5:	00 
    d6f6:	bf 01 00 00 00       	mov    $0x1,%edi
    d6fb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d702:	00 
    d703:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d70a:	00 
    d70b:	e8 90 90 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d710:	48 8b 15 41 74 01 00 	mov    0x17441(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d717:	49 89 c5             	mov    %rax,%r13
    d71a:	48 2b 05 0f 74 01 00 	sub    0x1740f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d721:	48 c1 e2 10          	shl    $0x10,%rdx
    d725:	48 39 d0             	cmp    %rdx,%rax
    d728:	73 59                	jae    d783 <f0+0x20c3>
    d72a:	48 89 c2             	mov    %rax,%rdx
    d72d:	48 c1 ea 10          	shr    $0x10,%rdx
    d731:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d735:	48 8b 15 3c 74 01 00 	mov    0x1743c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d73c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d740:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d744:	4d 85 e4             	test   %r12,%r12
    d747:	74 3a                	je     d783 <f0+0x20c3>
    d749:	0f b6 0a             	movzbl (%rdx),%ecx
    d74c:	80 f9 02             	cmp    $0x2,%cl
    d74f:	0f 84 2b 0a 00 00    	je     e180 <f0+0x2ac0>
    d755:	80 f9 01             	cmp    $0x1,%cl
    d758:	75 29                	jne    d783 <f0+0x20c3>
    d75a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d75d:	0f b7 c0             	movzwl %ax,%eax
    d760:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d763:	48 0f af c1          	imul   %rcx,%rax
    d767:	48 c1 e8 20          	shr    $0x20,%rax
    d76b:	48 39 d0             	cmp    %rdx,%rax
    d76e:	73 13                	jae    d783 <f0+0x20c3>
    d770:	49 01 c4             	add    %rax,%r12
    d773:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d778:	0f 84 9f 0b 00 00    	je     e31d <f0+0x2c5d>
    d77e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d783:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d78a:	00 f0 3f 
    d78d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d794:	00 
    d795:	bf 01 00 00 00       	mov    $0x1,%edi
    d79a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d7a1:	00 
    d7a2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d7a9:	00 
    d7aa:	e8 f1 8f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d7af:	48 8b 15 a2 73 01 00 	mov    0x173a2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d7b6:	49 89 c5             	mov    %rax,%r13
    d7b9:	48 2b 05 70 73 01 00 	sub    0x17370(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d7c0:	48 c1 e2 10          	shl    $0x10,%rdx
    d7c4:	48 39 d0             	cmp    %rdx,%rax
    d7c7:	73 59                	jae    d822 <f0+0x2162>
    d7c9:	48 89 c2             	mov    %rax,%rdx
    d7cc:	48 c1 ea 10          	shr    $0x10,%rdx
    d7d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7d4:	48 8b 15 9d 73 01 00 	mov    0x1739d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d7db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7df:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7e3:	4d 85 e4             	test   %r12,%r12
    d7e6:	74 3a                	je     d822 <f0+0x2162>
    d7e8:	0f b6 0a             	movzbl (%rdx),%ecx
    d7eb:	80 f9 02             	cmp    $0x2,%cl
    d7ee:	0f 84 7c 09 00 00    	je     e170 <f0+0x2ab0>
    d7f4:	80 f9 01             	cmp    $0x1,%cl
    d7f7:	75 29                	jne    d822 <f0+0x2162>
    d7f9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7fc:	0f b7 c0             	movzwl %ax,%eax
    d7ff:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d802:	48 0f af c1          	imul   %rcx,%rax
    d806:	48 c1 e8 20          	shr    $0x20,%rax
    d80a:	48 39 d0             	cmp    %rdx,%rax
    d80d:	73 13                	jae    d822 <f0+0x2162>
    d80f:	49 01 c4             	add    %rax,%r12
    d812:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d817:	0f 84 0d 0b 00 00    	je     e32a <f0+0x2c6a>
    d81d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d822:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d829:	33 f3 bf 
    d82c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d833:	00 
    d834:	bf 01 00 00 00       	mov    $0x1,%edi
    d839:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d840:	00 
    d841:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d848:	00 
    d849:	e8 52 8f ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d84e:	48 8b 15 03 73 01 00 	mov    0x17303(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d855:	49 89 c5             	mov    %rax,%r13
    d858:	48 2b 05 d1 72 01 00 	sub    0x172d1(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d85f:	48 c1 e2 10          	shl    $0x10,%rdx
    d863:	48 39 d0             	cmp    %rdx,%rax
    d866:	73 59                	jae    d8c1 <f0+0x2201>
    d868:	48 89 c2             	mov    %rax,%rdx
    d86b:	48 c1 ea 10          	shr    $0x10,%rdx
    d86f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d873:	48 8b 15 fe 72 01 00 	mov    0x172fe(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d87a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d87e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d882:	4d 85 e4             	test   %r12,%r12
    d885:	74 3a                	je     d8c1 <f0+0x2201>
    d887:	0f b6 0a             	movzbl (%rdx),%ecx
    d88a:	80 f9 02             	cmp    $0x2,%cl
    d88d:	0f 84 cd 08 00 00    	je     e160 <f0+0x2aa0>
    d893:	80 f9 01             	cmp    $0x1,%cl
    d896:	75 29                	jne    d8c1 <f0+0x2201>
    d898:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d89b:	0f b7 c0             	movzwl %ax,%eax
    d89e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8a1:	48 0f af c1          	imul   %rcx,%rax
    d8a5:	48 c1 e8 20          	shr    $0x20,%rax
    d8a9:	48 39 d0             	cmp    %rdx,%rax
    d8ac:	73 13                	jae    d8c1 <f0+0x2201>
    d8ae:	49 01 c4             	add    %rax,%r12
    d8b1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8b6:	0f 84 7b 0a 00 00    	je     e337 <f0+0x2c77>
    d8bc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8c1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8c8:	00 f0 3f 
    d8cb:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d8d2:	00 
    d8d3:	bf 01 00 00 00       	mov    $0x1,%edi
    d8d8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d8df:	00 
    d8e0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d8e7:	00 
    d8e8:	e8 b3 8e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d8ed:	48 8b 15 64 72 01 00 	mov    0x17264(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d8f4:	49 89 c5             	mov    %rax,%r13
    d8f7:	48 2b 05 32 72 01 00 	sub    0x17232(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d8fe:	48 c1 e2 10          	shl    $0x10,%rdx
    d902:	48 39 d0             	cmp    %rdx,%rax
    d905:	73 59                	jae    d960 <f0+0x22a0>
    d907:	48 89 c2             	mov    %rax,%rdx
    d90a:	48 c1 ea 10          	shr    $0x10,%rdx
    d90e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d912:	48 8b 15 5f 72 01 00 	mov    0x1725f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d919:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d91d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d921:	4d 85 e4             	test   %r12,%r12
    d924:	74 3a                	je     d960 <f0+0x22a0>
    d926:	0f b6 0a             	movzbl (%rdx),%ecx
    d929:	80 f9 02             	cmp    $0x2,%cl
    d92c:	0f 84 1e 08 00 00    	je     e150 <f0+0x2a90>
    d932:	80 f9 01             	cmp    $0x1,%cl
    d935:	75 29                	jne    d960 <f0+0x22a0>
    d937:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d93a:	0f b7 c0             	movzwl %ax,%eax
    d93d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d940:	48 0f af c1          	imul   %rcx,%rax
    d944:	48 c1 e8 20          	shr    $0x20,%rax
    d948:	48 39 d0             	cmp    %rdx,%rax
    d94b:	73 13                	jae    d960 <f0+0x22a0>
    d94d:	49 01 c4             	add    %rax,%r12
    d950:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d955:	0f 84 e9 09 00 00    	je     e344 <f0+0x2c84>
    d95b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d960:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d967:	33 f3 bf 
    d96a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d971:	00 
    d972:	bf 01 00 00 00       	mov    $0x1,%edi
    d977:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d97e:	00 
    d97f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d986:	00 
    d987:	e8 14 8e ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    d98c:	48 8b 15 c5 71 01 00 	mov    0x171c5(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d993:	49 89 c5             	mov    %rax,%r13
    d996:	48 2b 05 93 71 01 00 	sub    0x17193(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d99d:	48 c1 e2 10          	shl    $0x10,%rdx
    d9a1:	48 39 d0             	cmp    %rdx,%rax
    d9a4:	73 59                	jae    d9ff <f0+0x233f>
    d9a6:	48 89 c2             	mov    %rax,%rdx
    d9a9:	48 c1 ea 10          	shr    $0x10,%rdx
    d9ad:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9b1:	48 8b 15 c0 71 01 00 	mov    0x171c0(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d9b8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9bc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9c0:	4d 85 e4             	test   %r12,%r12
    d9c3:	74 3a                	je     d9ff <f0+0x233f>
    d9c5:	0f b6 0a             	movzbl (%rdx),%ecx
    d9c8:	80 f9 02             	cmp    $0x2,%cl
    d9cb:	0f 84 6f 07 00 00    	je     e140 <f0+0x2a80>
    d9d1:	80 f9 01             	cmp    $0x1,%cl
    d9d4:	75 29                	jne    d9ff <f0+0x233f>
    d9d6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9d9:	0f b7 c0             	movzwl %ax,%eax
    d9dc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9df:	48 0f af c1          	imul   %rcx,%rax
    d9e3:	48 c1 e8 20          	shr    $0x20,%rax
    d9e7:	48 39 d0             	cmp    %rdx,%rax
    d9ea:	73 13                	jae    d9ff <f0+0x233f>
    d9ec:	49 01 c4             	add    %rax,%r12
    d9ef:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9f4:	0f 84 57 09 00 00    	je     e351 <f0+0x2c91>
    d9fa:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9ff:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da06:	00 f0 3f 
    da09:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    da10:	00 
    da11:	bf 01 00 00 00       	mov    $0x1,%edi
    da16:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    da1d:	00 
    da1e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    da25:	00 
    da26:	e8 75 8d ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    da2b:	48 8b 15 26 71 01 00 	mov    0x17126(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    da32:	49 89 c5             	mov    %rax,%r13
    da35:	48 2b 05 f4 70 01 00 	sub    0x170f4(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    da3c:	48 c1 e2 10          	shl    $0x10,%rdx
    da40:	48 39 d0             	cmp    %rdx,%rax
    da43:	73 59                	jae    da9e <f0+0x23de>
    da45:	48 89 c2             	mov    %rax,%rdx
    da48:	48 c1 ea 10          	shr    $0x10,%rdx
    da4c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da50:	48 8b 15 21 71 01 00 	mov    0x17121(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    da57:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da5b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da5f:	4d 85 e4             	test   %r12,%r12
    da62:	74 3a                	je     da9e <f0+0x23de>
    da64:	0f b6 0a             	movzbl (%rdx),%ecx
    da67:	80 f9 02             	cmp    $0x2,%cl
    da6a:	0f 84 c0 06 00 00    	je     e130 <f0+0x2a70>
    da70:	80 f9 01             	cmp    $0x1,%cl
    da73:	75 29                	jne    da9e <f0+0x23de>
    da75:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da78:	0f b7 c0             	movzwl %ax,%eax
    da7b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da7e:	48 0f af c1          	imul   %rcx,%rax
    da82:	48 c1 e8 20          	shr    $0x20,%rax
    da86:	48 39 d0             	cmp    %rdx,%rax
    da89:	73 13                	jae    da9e <f0+0x23de>
    da8b:	49 01 c4             	add    %rax,%r12
    da8e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da93:	0f 84 c5 08 00 00    	je     e35e <f0+0x2c9e>
    da99:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da9e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    daa5:	33 f3 bf 
    daa8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    daaf:	00 
    dab0:	bf 01 00 00 00       	mov    $0x1,%edi
    dab5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    dabc:	00 
    dabd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    dac4:	00 
    dac5:	e8 d6 8c ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    daca:	48 8b 15 87 70 01 00 	mov    0x17087(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    dad1:	49 89 c5             	mov    %rax,%r13
    dad4:	48 2b 05 55 70 01 00 	sub    0x17055(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    dadb:	48 c1 e2 10          	shl    $0x10,%rdx
    dadf:	48 39 d0             	cmp    %rdx,%rax
    dae2:	73 59                	jae    db3d <f0+0x247d>
    dae4:	48 89 c2             	mov    %rax,%rdx
    dae7:	48 c1 ea 10          	shr    $0x10,%rdx
    daeb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    daef:	48 8b 15 82 70 01 00 	mov    0x17082(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    daf6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dafa:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dafe:	4d 85 e4             	test   %r12,%r12
    db01:	74 3a                	je     db3d <f0+0x247d>
    db03:	0f b6 0a             	movzbl (%rdx),%ecx
    db06:	80 f9 02             	cmp    $0x2,%cl
    db09:	0f 84 11 06 00 00    	je     e120 <f0+0x2a60>
    db0f:	80 f9 01             	cmp    $0x1,%cl
    db12:	75 29                	jne    db3d <f0+0x247d>
    db14:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db17:	0f b7 c0             	movzwl %ax,%eax
    db1a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db1d:	48 0f af c1          	imul   %rcx,%rax
    db21:	48 c1 e8 20          	shr    $0x20,%rax
    db25:	48 39 d0             	cmp    %rdx,%rax
    db28:	73 13                	jae    db3d <f0+0x247d>
    db2a:	49 01 c4             	add    %rax,%r12
    db2d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db32:	0f 84 33 08 00 00    	je     e36b <f0+0x2cab>
    db38:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db3d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db44:	00 f0 3f 
    db47:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    db4e:	00 
    db4f:	bf 01 00 00 00       	mov    $0x1,%edi
    db54:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    db5b:	00 
    db5c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    db63:	00 
    db64:	e8 37 8c ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    db69:	48 8b 15 e8 6f 01 00 	mov    0x16fe8(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    db70:	49 89 c5             	mov    %rax,%r13
    db73:	48 2b 05 b6 6f 01 00 	sub    0x16fb6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    db7a:	48 c1 e2 10          	shl    $0x10,%rdx
    db7e:	48 39 d0             	cmp    %rdx,%rax
    db81:	73 59                	jae    dbdc <f0+0x251c>
    db83:	48 89 c2             	mov    %rax,%rdx
    db86:	48 c1 ea 10          	shr    $0x10,%rdx
    db8a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db8e:	48 8b 15 e3 6f 01 00 	mov    0x16fe3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    db95:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db99:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db9d:	4d 85 e4             	test   %r12,%r12
    dba0:	74 3a                	je     dbdc <f0+0x251c>
    dba2:	0f b6 0a             	movzbl (%rdx),%ecx
    dba5:	80 f9 02             	cmp    $0x2,%cl
    dba8:	0f 84 62 05 00 00    	je     e110 <f0+0x2a50>
    dbae:	80 f9 01             	cmp    $0x1,%cl
    dbb1:	75 29                	jne    dbdc <f0+0x251c>
    dbb3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbb6:	0f b7 c0             	movzwl %ax,%eax
    dbb9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbbc:	48 0f af c1          	imul   %rcx,%rax
    dbc0:	48 c1 e8 20          	shr    $0x20,%rax
    dbc4:	48 39 d0             	cmp    %rdx,%rax
    dbc7:	73 13                	jae    dbdc <f0+0x251c>
    dbc9:	49 01 c4             	add    %rax,%r12
    dbcc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbd1:	0f 84 a1 07 00 00    	je     e378 <f0+0x2cb8>
    dbd7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dbdc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dbe3:	33 f3 bf 
    dbe6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    dbed:	00 
    dbee:	bf 01 00 00 00       	mov    $0x1,%edi
    dbf3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    dbfa:	00 
    dbfb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    dc02:	00 
    dc03:	e8 98 8b ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    dc08:	48 8b 15 49 6f 01 00 	mov    0x16f49(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    dc0f:	49 89 c5             	mov    %rax,%r13
    dc12:	48 2b 05 17 6f 01 00 	sub    0x16f17(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    dc19:	48 c1 e2 10          	shl    $0x10,%rdx
    dc1d:	48 39 d0             	cmp    %rdx,%rax
    dc20:	73 59                	jae    dc7b <f0+0x25bb>
    dc22:	48 89 c2             	mov    %rax,%rdx
    dc25:	48 c1 ea 10          	shr    $0x10,%rdx
    dc29:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc2d:	48 8b 15 44 6f 01 00 	mov    0x16f44(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    dc34:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc38:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc3c:	4d 85 e4             	test   %r12,%r12
    dc3f:	74 3a                	je     dc7b <f0+0x25bb>
    dc41:	0f b6 0a             	movzbl (%rdx),%ecx
    dc44:	80 f9 02             	cmp    $0x2,%cl
    dc47:	0f 84 b3 04 00 00    	je     e100 <f0+0x2a40>
    dc4d:	80 f9 01             	cmp    $0x1,%cl
    dc50:	75 29                	jne    dc7b <f0+0x25bb>
    dc52:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc55:	0f b7 c0             	movzwl %ax,%eax
    dc58:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc5b:	48 0f af c1          	imul   %rcx,%rax
    dc5f:	48 c1 e8 20          	shr    $0x20,%rax
    dc63:	48 39 d0             	cmp    %rdx,%rax
    dc66:	73 13                	jae    dc7b <f0+0x25bb>
    dc68:	49 01 c4             	add    %rax,%r12
    dc6b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc70:	0f 84 0f 07 00 00    	je     e385 <f0+0x2cc5>
    dc76:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc7b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc82:	00 f0 3f 
    dc85:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    dc8c:	00 
    dc8d:	bf 01 00 00 00       	mov    $0x1,%edi
    dc92:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    dc99:	00 
    dc9a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    dca1:	00 
    dca2:	e8 f9 8a ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    dca7:	48 8b 15 aa 6e 01 00 	mov    0x16eaa(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    dcae:	49 89 c5             	mov    %rax,%r13
    dcb1:	48 2b 05 78 6e 01 00 	sub    0x16e78(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    dcb8:	48 c1 e2 10          	shl    $0x10,%rdx
    dcbc:	48 39 d0             	cmp    %rdx,%rax
    dcbf:	73 59                	jae    dd1a <f0+0x265a>
    dcc1:	48 89 c2             	mov    %rax,%rdx
    dcc4:	48 c1 ea 10          	shr    $0x10,%rdx
    dcc8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dccc:	48 8b 15 a5 6e 01 00 	mov    0x16ea5(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    dcd3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dcd7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dcdb:	4d 85 e4             	test   %r12,%r12
    dcde:	74 3a                	je     dd1a <f0+0x265a>
    dce0:	0f b6 0a             	movzbl (%rdx),%ecx
    dce3:	80 f9 02             	cmp    $0x2,%cl
    dce6:	0f 84 04 04 00 00    	je     e0f0 <f0+0x2a30>
    dcec:	80 f9 01             	cmp    $0x1,%cl
    dcef:	75 29                	jne    dd1a <f0+0x265a>
    dcf1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dcf4:	0f b7 c0             	movzwl %ax,%eax
    dcf7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dcfa:	48 0f af c1          	imul   %rcx,%rax
    dcfe:	48 c1 e8 20          	shr    $0x20,%rax
    dd02:	48 39 d0             	cmp    %rdx,%rax
    dd05:	73 13                	jae    dd1a <f0+0x265a>
    dd07:	49 01 c4             	add    %rax,%r12
    dd0a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd0f:	0f 84 7d 06 00 00    	je     e392 <f0+0x2cd2>
    dd15:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd1a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd21:	33 f3 bf 
    dd24:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dd2b:	00 
    dd2c:	bf 01 00 00 00       	mov    $0x1,%edi
    dd31:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dd38:	00 
    dd39:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    dd40:	00 
    dd41:	e8 5a 8a ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    dd46:	48 8b 15 0b 6e 01 00 	mov    0x16e0b(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    dd4d:	49 89 c5             	mov    %rax,%r13
    dd50:	48 2b 05 d9 6d 01 00 	sub    0x16dd9(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    dd57:	48 c1 e2 10          	shl    $0x10,%rdx
    dd5b:	48 39 d0             	cmp    %rdx,%rax
    dd5e:	73 59                	jae    ddb9 <f0+0x26f9>
    dd60:	48 89 c2             	mov    %rax,%rdx
    dd63:	48 c1 ea 10          	shr    $0x10,%rdx
    dd67:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd6b:	48 8b 15 06 6e 01 00 	mov    0x16e06(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    dd72:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd76:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd7a:	4d 85 e4             	test   %r12,%r12
    dd7d:	74 3a                	je     ddb9 <f0+0x26f9>
    dd7f:	0f b6 0a             	movzbl (%rdx),%ecx
    dd82:	80 f9 02             	cmp    $0x2,%cl
    dd85:	0f 84 55 03 00 00    	je     e0e0 <f0+0x2a20>
    dd8b:	80 f9 01             	cmp    $0x1,%cl
    dd8e:	75 29                	jne    ddb9 <f0+0x26f9>
    dd90:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd93:	0f b7 c0             	movzwl %ax,%eax
    dd96:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd99:	48 0f af c1          	imul   %rcx,%rax
    dd9d:	48 c1 e8 20          	shr    $0x20,%rax
    dda1:	48 39 d0             	cmp    %rdx,%rax
    dda4:	73 13                	jae    ddb9 <f0+0x26f9>
    dda6:	49 01 c4             	add    %rax,%r12
    dda9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddae:	0f 84 eb 05 00 00    	je     e39f <f0+0x2cdf>
    ddb4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ddb9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ddc0:	00 f0 3f 
    ddc3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    ddca:	00 
    ddcb:	bf 01 00 00 00       	mov    $0x1,%edi
    ddd0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    ddd7:	00 
    ddd8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    dddf:	00 
    dde0:	e8 bb 89 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    dde5:	48 8b 15 6c 6d 01 00 	mov    0x16d6c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ddec:	49 89 c5             	mov    %rax,%r13
    ddef:	48 2b 05 3a 6d 01 00 	sub    0x16d3a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ddf6:	48 c1 e2 10          	shl    $0x10,%rdx
    ddfa:	48 39 d0             	cmp    %rdx,%rax
    ddfd:	73 59                	jae    de58 <f0+0x2798>
    ddff:	48 89 c2             	mov    %rax,%rdx
    de02:	48 c1 ea 10          	shr    $0x10,%rdx
    de06:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de0a:	48 8b 15 67 6d 01 00 	mov    0x16d67(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    de11:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de15:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de19:	4d 85 e4             	test   %r12,%r12
    de1c:	74 3a                	je     de58 <f0+0x2798>
    de1e:	0f b6 0a             	movzbl (%rdx),%ecx
    de21:	80 f9 02             	cmp    $0x2,%cl
    de24:	0f 84 a6 02 00 00    	je     e0d0 <f0+0x2a10>
    de2a:	80 f9 01             	cmp    $0x1,%cl
    de2d:	75 29                	jne    de58 <f0+0x2798>
    de2f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de32:	0f b7 c0             	movzwl %ax,%eax
    de35:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de38:	48 0f af c1          	imul   %rcx,%rax
    de3c:	48 c1 e8 20          	shr    $0x20,%rax
    de40:	48 39 d0             	cmp    %rdx,%rax
    de43:	73 13                	jae    de58 <f0+0x2798>
    de45:	49 01 c4             	add    %rax,%r12
    de48:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de4d:	0f 84 59 05 00 00    	je     e3ac <f0+0x2cec>
    de53:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de58:	48 89 ee             	mov    %rbp,%rsi
    de5b:	bf 01 00 00 00       	mov    $0x1,%edi
    de60:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    de67:	33 f3 bf 
    de6a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    de71:	00 
    de72:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    de79:	00 
    de7a:	e8 21 89 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    de7f:	48 8b 15 d2 6c 01 00 	mov    0x16cd2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    de86:	48 89 c5             	mov    %rax,%rbp
    de89:	48 2b 05 a0 6c 01 00 	sub    0x16ca0(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    de90:	48 c1 e2 10          	shl    $0x10,%rdx
    de94:	48 39 d0             	cmp    %rdx,%rax
    de97:	73 59                	jae    def2 <f0+0x2832>
    de99:	48 89 c2             	mov    %rax,%rdx
    de9c:	48 c1 ea 10          	shr    $0x10,%rdx
    dea0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dea4:	48 8b 15 cd 6c 01 00 	mov    0x16ccd(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    deab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    deaf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    deb3:	4d 85 e4             	test   %r12,%r12
    deb6:	74 3a                	je     def2 <f0+0x2832>
    deb8:	0f b6 0a             	movzbl (%rdx),%ecx
    debb:	80 f9 02             	cmp    $0x2,%cl
    debe:	0f 84 fc 01 00 00    	je     e0c0 <f0+0x2a00>
    dec4:	80 f9 01             	cmp    $0x1,%cl
    dec7:	75 29                	jne    def2 <f0+0x2832>
    dec9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    decc:	0f b7 c0             	movzwl %ax,%eax
    decf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ded2:	48 0f af c1          	imul   %rcx,%rax
    ded6:	48 c1 e8 20          	shr    $0x20,%rax
    deda:	48 39 d0             	cmp    %rdx,%rax
    dedd:	73 13                	jae    def2 <f0+0x2832>
    dedf:	49 01 c4             	add    %rax,%r12
    dee2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dee7:	0f 84 d1 02 00 00    	je     e1be <f0+0x2afe>
    deed:	41 c6 04 24 01       	movb   $0x1,(%r12)
    def2:	48 89 de             	mov    %rbx,%rsi
    def5:	48 89 ef             	mov    %rbp,%rdi
    def8:	e8 73 cb ff ff       	call   aa70 <fwp_hof0.constprop.0>
    defd:	48 89 ef             	mov    %rbp,%rdi
    df00:	e8 0b 8e ff ff       	call   6d10 <fwp_drop0>
    df05:	48 89 df             	mov    %rbx,%rdi
    df08:	e8 03 8e ff ff       	call   6d10 <fwp_drop0>
    df0d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    df14:	00 
    df15:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    df1c:	00 00 
    df1e:	0f 85 95 04 00 00    	jne    e3b9 <f0+0x2cf9>
    df24:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    df2b:	31 c0                	xor    %eax,%eax
    df2d:	5b                   	pop    %rbx
    df2e:	5d                   	pop    %rbp
    df2f:	41 5c                	pop    %r12
    df31:	41 5d                	pop    %r13
    df33:	41 5e                	pop    %r14
    df35:	c3                   	ret
    df36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    df3d:	00 00 00 
    df40:	4c 89 ef             	mov    %r13,%rdi
    df43:	e8 c8 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df48:	e9 2c d8 ff ff       	jmp    b779 <f0+0xb9>
    df4d:	0f 1f 00             	nopl   (%rax)
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 ae f5 ff ff    	jne    d507 <f0+0x1e47>
    df59:	e9 99 f5 ff ff       	jmp    d4f7 <f0+0x1e37>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 ff f4 ff ff    	jne    d468 <f0+0x1da8>
    df69:	e9 ea f4 ff ff       	jmp    d458 <f0+0x1d98>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 50 f4 ff ff    	jne    d3c9 <f0+0x1d09>
    df79:	e9 3b f4 ff ff       	jmp    d3b9 <f0+0x1cf9>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 a1 f3 ff ff    	jne    d32a <f0+0x1c6a>
    df89:	e9 8c f3 ff ff       	jmp    d31a <f0+0x1c5a>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 f2 f2 ff ff    	jne    d28b <f0+0x1bcb>
    df99:	e9 dd f2 ff ff       	jmp    d27b <f0+0x1bbb>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 43 f2 ff ff    	jne    d1ec <f0+0x1b2c>
    dfa9:	e9 2e f2 ff ff       	jmp    d1dc <f0+0x1b1c>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 94 f1 ff ff    	jne    d14d <f0+0x1a8d>
    dfb9:	e9 7f f1 ff ff       	jmp    d13d <f0+0x1a7d>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 e5 f0 ff ff    	jne    d0ae <f0+0x19ee>
    dfc9:	e9 d0 f0 ff ff       	jmp    d09e <f0+0x19de>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 fd d9 ff ff    	jne    b9d6 <f0+0x316>
    dfd9:	e9 e8 d9 ff ff       	jmp    b9c6 <f0+0x306>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	66 85 c0             	test   %ax,%ax
    dfe3:	0f 85 57 d9 ff ff    	jne    b940 <f0+0x280>
    dfe9:	e9 42 d9 ff ff       	jmp    b930 <f0+0x270>
    dfee:	66 90                	xchg   %ax,%ax
    dff0:	66 85 c0             	test   %ax,%ax
    dff3:	0f 85 b1 d8 ff ff    	jne    b8aa <f0+0x1ea>
    dff9:	e9 9c d8 ff ff       	jmp    b89a <f0+0x1da>
    dffe:	66 90                	xchg   %ax,%ax
    e000:	66 85 c0             	test   %ax,%ax
    e003:	0f 85 0e eb ff ff    	jne    cb17 <f0+0x1457>
    e009:	e9 f9 ea ff ff       	jmp    cb07 <f0+0x1447>
    e00e:	66 90                	xchg   %ax,%ax
    e010:	66 85 c0             	test   %ax,%ax
    e013:	0f 85 5f ea ff ff    	jne    ca78 <f0+0x13b8>
    e019:	e9 4a ea ff ff       	jmp    ca68 <f0+0x13a8>
    e01e:	66 90                	xchg   %ax,%ax
    e020:	66 85 c0             	test   %ax,%ax
    e023:	0f 85 e2 da ff ff    	jne    bb0b <f0+0x44b>
    e029:	e9 cd da ff ff       	jmp    bafb <f0+0x43b>
    e02e:	66 90                	xchg   %ax,%ax
    e030:	66 85 c0             	test   %ax,%ax
    e033:	0f 85 33 da ff ff    	jne    ba6c <f0+0x3ac>
    e039:	e9 1e da ff ff       	jmp    ba5c <f0+0x39c>
    e03e:	66 90                	xchg   %ax,%ax
    e040:	66 85 c0             	test   %ax,%ax
    e043:	0f 85 c6 ef ff ff    	jne    d00f <f0+0x194f>
    e049:	e9 b1 ef ff ff       	jmp    cfff <f0+0x193f>
    e04e:	66 90                	xchg   %ax,%ax
    e050:	66 85 c0             	test   %ax,%ax
    e053:	0f 85 17 ef ff ff    	jne    cf70 <f0+0x18b0>
    e059:	e9 02 ef ff ff       	jmp    cf60 <f0+0x18a0>
    e05e:	66 90                	xchg   %ax,%ax
    e060:	66 85 c0             	test   %ax,%ax
    e063:	0f 85 68 ee ff ff    	jne    ced1 <f0+0x1811>
    e069:	e9 53 ee ff ff       	jmp    cec1 <f0+0x1801>
    e06e:	66 90                	xchg   %ax,%ax
    e070:	66 85 c0             	test   %ax,%ax
    e073:	0f 85 b9 ed ff ff    	jne    ce32 <f0+0x1772>
    e079:	e9 a4 ed ff ff       	jmp    ce22 <f0+0x1762>
    e07e:	66 90                	xchg   %ax,%ax
    e080:	66 85 c0             	test   %ax,%ax
    e083:	0f 85 0a ed ff ff    	jne    cd93 <f0+0x16d3>
    e089:	e9 f5 ec ff ff       	jmp    cd83 <f0+0x16c3>
    e08e:	66 90                	xchg   %ax,%ax
    e090:	66 85 c0             	test   %ax,%ax
    e093:	0f 85 5b ec ff ff    	jne    ccf4 <f0+0x1634>
    e099:	e9 46 ec ff ff       	jmp    cce4 <f0+0x1624>
    e09e:	66 90                	xchg   %ax,%ax
    e0a0:	66 85 c0             	test   %ax,%ax
    e0a3:	0f 85 ac eb ff ff    	jne    cc55 <f0+0x1595>
    e0a9:	e9 97 eb ff ff       	jmp    cc45 <f0+0x1585>
    e0ae:	66 90                	xchg   %ax,%ax
    e0b0:	66 85 c0             	test   %ax,%ax
    e0b3:	0f 85 fd ea ff ff    	jne    cbb6 <f0+0x14f6>
    e0b9:	e9 e8 ea ff ff       	jmp    cba6 <f0+0x14e6>
    e0be:	66 90                	xchg   %ax,%ax
    e0c0:	66 85 c0             	test   %ax,%ax
    e0c3:	0f 85 29 fe ff ff    	jne    def2 <f0+0x2832>
    e0c9:	e9 14 fe ff ff       	jmp    dee2 <f0+0x2822>
    e0ce:	66 90                	xchg   %ax,%ax
    e0d0:	66 85 c0             	test   %ax,%ax
    e0d3:	0f 85 7f fd ff ff    	jne    de58 <f0+0x2798>
    e0d9:	e9 6a fd ff ff       	jmp    de48 <f0+0x2788>
    e0de:	66 90                	xchg   %ax,%ax
    e0e0:	66 85 c0             	test   %ax,%ax
    e0e3:	0f 85 d0 fc ff ff    	jne    ddb9 <f0+0x26f9>
    e0e9:	e9 bb fc ff ff       	jmp    dda9 <f0+0x26e9>
    e0ee:	66 90                	xchg   %ax,%ax
    e0f0:	66 85 c0             	test   %ax,%ax
    e0f3:	0f 85 21 fc ff ff    	jne    dd1a <f0+0x265a>
    e0f9:	e9 0c fc ff ff       	jmp    dd0a <f0+0x264a>
    e0fe:	66 90                	xchg   %ax,%ax
    e100:	66 85 c0             	test   %ax,%ax
    e103:	0f 85 72 fb ff ff    	jne    dc7b <f0+0x25bb>
    e109:	e9 5d fb ff ff       	jmp    dc6b <f0+0x25ab>
    e10e:	66 90                	xchg   %ax,%ax
    e110:	66 85 c0             	test   %ax,%ax
    e113:	0f 85 c3 fa ff ff    	jne    dbdc <f0+0x251c>
    e119:	e9 ae fa ff ff       	jmp    dbcc <f0+0x250c>
    e11e:	66 90                	xchg   %ax,%ax
    e120:	66 85 c0             	test   %ax,%ax
    e123:	0f 85 14 fa ff ff    	jne    db3d <f0+0x247d>
    e129:	e9 ff f9 ff ff       	jmp    db2d <f0+0x246d>
    e12e:	66 90                	xchg   %ax,%ax
    e130:	66 85 c0             	test   %ax,%ax
    e133:	0f 85 65 f9 ff ff    	jne    da9e <f0+0x23de>
    e139:	e9 50 f9 ff ff       	jmp    da8e <f0+0x23ce>
    e13e:	66 90                	xchg   %ax,%ax
    e140:	66 85 c0             	test   %ax,%ax
    e143:	0f 85 b6 f8 ff ff    	jne    d9ff <f0+0x233f>
    e149:	e9 a1 f8 ff ff       	jmp    d9ef <f0+0x232f>
    e14e:	66 90                	xchg   %ax,%ax
    e150:	66 85 c0             	test   %ax,%ax
    e153:	0f 85 07 f8 ff ff    	jne    d960 <f0+0x22a0>
    e159:	e9 f2 f7 ff ff       	jmp    d950 <f0+0x2290>
    e15e:	66 90                	xchg   %ax,%ax
    e160:	66 85 c0             	test   %ax,%ax
    e163:	0f 85 58 f7 ff ff    	jne    d8c1 <f0+0x2201>
    e169:	e9 43 f7 ff ff       	jmp    d8b1 <f0+0x21f1>
    e16e:	66 90                	xchg   %ax,%ax
    e170:	66 85 c0             	test   %ax,%ax
    e173:	0f 85 a9 f6 ff ff    	jne    d822 <f0+0x2162>
    e179:	e9 94 f6 ff ff       	jmp    d812 <f0+0x2152>
    e17e:	66 90                	xchg   %ax,%ax
    e180:	66 85 c0             	test   %ax,%ax
    e183:	0f 85 fa f5 ff ff    	jne    d783 <f0+0x20c3>
    e189:	e9 e5 f5 ff ff       	jmp    d773 <f0+0x20b3>
    e18e:	66 90                	xchg   %ax,%ax
    e190:	66 85 c0             	test   %ax,%ax
    e193:	0f 85 4b f5 ff ff    	jne    d6e4 <f0+0x2024>
    e199:	e9 36 f5 ff ff       	jmp    d6d4 <f0+0x2014>
    e19e:	66 90                	xchg   %ax,%ax
    e1a0:	66 85 c0             	test   %ax,%ax
    e1a3:	0f 85 9c f4 ff ff    	jne    d645 <f0+0x1f85>
    e1a9:	e9 87 f4 ff ff       	jmp    d635 <f0+0x1f75>
    e1ae:	66 90                	xchg   %ax,%ax
    e1b0:	66 85 c0             	test   %ax,%ax
    e1b3:	0f 85 ed f3 ff ff    	jne    d5a6 <f0+0x1ee6>
    e1b9:	e9 d8 f3 ff ff       	jmp    d596 <f0+0x1ed6>
    e1be:	4c 89 e7             	mov    %r12,%rdi
    e1c1:	e8 4a 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e1c6:	e9 22 fd ff ff       	jmp    deed <f0+0x282d>
    e1cb:	4c 89 e7             	mov    %r12,%rdi
    e1ce:	e8 3d 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e1d3:	e9 cd d6 ff ff       	jmp    b8a5 <f0+0x1e5>
    e1d8:	4c 89 e7             	mov    %r12,%rdi
    e1db:	e8 30 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e1e0:	e9 56 d7 ff ff       	jmp    b93b <f0+0x27b>
    e1e5:	4c 89 e7             	mov    %r12,%rdi
    e1e8:	e8 23 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e1ed:	e9 df d7 ff ff       	jmp    b9d1 <f0+0x311>
    e1f2:	4c 89 e7             	mov    %r12,%rdi
    e1f5:	e8 16 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e1fa:	e9 68 d8 ff ff       	jmp    ba67 <f0+0x3a7>
    e1ff:	4c 89 e7             	mov    %r12,%rdi
    e202:	e8 09 71 ff ff       	call   5310 <fwp_rc_forget_slot>
    e207:	e9 fa d8 ff ff       	jmp    bb06 <f0+0x446>
    e20c:	4c 89 e7             	mov    %r12,%rdi
    e20f:	e8 fc 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e214:	e9 5a e8 ff ff       	jmp    ca73 <f0+0x13b3>
    e219:	4c 89 e7             	mov    %r12,%rdi
    e21c:	e8 ef 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e221:	e9 ec e8 ff ff       	jmp    cb12 <f0+0x1452>
    e226:	4c 89 e7             	mov    %r12,%rdi
    e229:	e8 e2 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e22e:	e9 7e e9 ff ff       	jmp    cbb1 <f0+0x14f1>
    e233:	4c 89 e7             	mov    %r12,%rdi
    e236:	e8 d5 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e23b:	e9 10 ea ff ff       	jmp    cc50 <f0+0x1590>
    e240:	4c 89 e7             	mov    %r12,%rdi
    e243:	e8 c8 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e248:	e9 a2 ea ff ff       	jmp    ccef <f0+0x162f>
    e24d:	4c 89 e7             	mov    %r12,%rdi
    e250:	e8 bb 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e255:	e9 34 eb ff ff       	jmp    cd8e <f0+0x16ce>
    e25a:	4c 89 e7             	mov    %r12,%rdi
    e25d:	e8 ae 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e262:	e9 c6 eb ff ff       	jmp    ce2d <f0+0x176d>
    e267:	4c 89 e7             	mov    %r12,%rdi
    e26a:	e8 a1 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e26f:	e9 58 ec ff ff       	jmp    cecc <f0+0x180c>
    e274:	4c 89 e7             	mov    %r12,%rdi
    e277:	e8 94 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e27c:	e9 ea ec ff ff       	jmp    cf6b <f0+0x18ab>
    e281:	4c 89 e7             	mov    %r12,%rdi
    e284:	e8 87 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e289:	e9 7c ed ff ff       	jmp    d00a <f0+0x194a>
    e28e:	4c 89 e7             	mov    %r12,%rdi
    e291:	e8 7a 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e296:	e9 0e ee ff ff       	jmp    d0a9 <f0+0x19e9>
    e29b:	4c 89 e7             	mov    %r12,%rdi
    e29e:	e8 6d 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2a3:	e9 a0 ee ff ff       	jmp    d148 <f0+0x1a88>
    e2a8:	4c 89 e7             	mov    %r12,%rdi
    e2ab:	e8 60 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2b0:	e9 32 ef ff ff       	jmp    d1e7 <f0+0x1b27>
    e2b5:	4c 89 e7             	mov    %r12,%rdi
    e2b8:	e8 53 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2bd:	e9 c4 ef ff ff       	jmp    d286 <f0+0x1bc6>
    e2c2:	4c 89 e7             	mov    %r12,%rdi
    e2c5:	e8 46 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2ca:	e9 56 f0 ff ff       	jmp    d325 <f0+0x1c65>
    e2cf:	4c 89 e7             	mov    %r12,%rdi
    e2d2:	e8 39 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2d7:	e9 e8 f0 ff ff       	jmp    d3c4 <f0+0x1d04>
    e2dc:	4c 89 e7             	mov    %r12,%rdi
    e2df:	e8 2c 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2e4:	e9 7a f1 ff ff       	jmp    d463 <f0+0x1da3>
    e2e9:	4c 89 e7             	mov    %r12,%rdi
    e2ec:	e8 1f 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2f1:	e9 0c f2 ff ff       	jmp    d502 <f0+0x1e42>
    e2f6:	4c 89 e7             	mov    %r12,%rdi
    e2f9:	e8 12 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e2fe:	e9 9e f2 ff ff       	jmp    d5a1 <f0+0x1ee1>
    e303:	4c 89 e7             	mov    %r12,%rdi
    e306:	e8 05 70 ff ff       	call   5310 <fwp_rc_forget_slot>
    e30b:	e9 30 f3 ff ff       	jmp    d640 <f0+0x1f80>
    e310:	4c 89 e7             	mov    %r12,%rdi
    e313:	e8 f8 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e318:	e9 c2 f3 ff ff       	jmp    d6df <f0+0x201f>
    e31d:	4c 89 e7             	mov    %r12,%rdi
    e320:	e8 eb 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e325:	e9 54 f4 ff ff       	jmp    d77e <f0+0x20be>
    e32a:	4c 89 e7             	mov    %r12,%rdi
    e32d:	e8 de 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e332:	e9 e6 f4 ff ff       	jmp    d81d <f0+0x215d>
    e337:	4c 89 e7             	mov    %r12,%rdi
    e33a:	e8 d1 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e33f:	e9 78 f5 ff ff       	jmp    d8bc <f0+0x21fc>
    e344:	4c 89 e7             	mov    %r12,%rdi
    e347:	e8 c4 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e34c:	e9 0a f6 ff ff       	jmp    d95b <f0+0x229b>
    e351:	4c 89 e7             	mov    %r12,%rdi
    e354:	e8 b7 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e359:	e9 9c f6 ff ff       	jmp    d9fa <f0+0x233a>
    e35e:	4c 89 e7             	mov    %r12,%rdi
    e361:	e8 aa 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e366:	e9 2e f7 ff ff       	jmp    da99 <f0+0x23d9>
    e36b:	4c 89 e7             	mov    %r12,%rdi
    e36e:	e8 9d 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e373:	e9 c0 f7 ff ff       	jmp    db38 <f0+0x2478>
    e378:	4c 89 e7             	mov    %r12,%rdi
    e37b:	e8 90 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e380:	e9 52 f8 ff ff       	jmp    dbd7 <f0+0x2517>
    e385:	4c 89 e7             	mov    %r12,%rdi
    e388:	e8 83 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e38d:	e9 e4 f8 ff ff       	jmp    dc76 <f0+0x25b6>
    e392:	4c 89 e7             	mov    %r12,%rdi
    e395:	e8 76 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e39a:	e9 76 f9 ff ff       	jmp    dd15 <f0+0x2655>
    e39f:	4c 89 e7             	mov    %r12,%rdi
    e3a2:	e8 69 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e3a7:	e9 08 fa ff ff       	jmp    ddb4 <f0+0x26f4>
    e3ac:	4c 89 e7             	mov    %r12,%rdi
    e3af:	e8 5c 6f ff ff       	call   5310 <fwp_rc_forget_slot>
    e3b4:	e9 9a fa ff ff       	jmp    de53 <f0+0x2793>
    e3b9:	e8 a2 50 ff ff       	call   3460 <__stack_chk_fail@plt>
    e3be:	66 90                	xchg   %ax,%ax

000000000000e3c0 <fwp_main_thread>:
    e3c0:	f3 0f 1e fa          	endbr64
    e3c4:	41 54                	push   %r12
    e3c6:	55                   	push   %rbp
    e3c7:	53                   	push   %rbx
    e3c8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e3cf:	8b 0d 4f 67 01 00    	mov    0x1674f(%rip),%ecx        # 24b24 <fwp_heap+0x13a4>
    e3d5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e3dc:	00 00 
    e3de:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e3e5:	00 
    e3e6:	31 c0                	xor    %eax,%eax
    e3e8:	85 c9                	test   %ecx,%ecx
    e3ea:	0f 84 68 06 00 00    	je     ea58 <fwp_main_thread+0x698>
    e3f0:	8b 15 32 67 01 00    	mov    0x16732(%rip),%edx        # 24b28 <fwp_heap+0x13a8>
    e3f6:	85 d2                	test   %edx,%edx
    e3f8:	0f 85 42 06 00 00    	jne    ea40 <fwp_main_thread+0x680>
    e3fe:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e403:	31 f6                	xor    %esi,%esi
    e405:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e40a:	48 c7 05 03 4d 01 00 	movq   $0x40000000,0x14d03(%rip)        # 23118 <fwp_main_stack_size>
    e411:	00 00 00 40 
    e415:	48 89 05 04 4d 01 00 	mov    %rax,0x14d04(%rip)        # 23120 <fwp_main_stack_top>
    e41c:	48 8d 05 7d 4c 00 00 	lea    0x4c7d(%rip),%rax        # 130a0 <alt.5>
    e423:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e428:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e42f:	01 00 
    e431:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e438:	00 
    e439:	e8 82 52 ff ff       	call   36c0 <sigaltstack@plt>
    e43e:	85 c0                	test   %eax,%eax
    e440:	0f 85 4a 06 00 00    	jne    ea90 <fwp_main_thread+0x6d0>
    e446:	31 c0                	xor    %eax,%eax
    e448:	b9 12 00 00 00       	mov    $0x12,%ecx
    e44d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e452:	f3 48 ab             	rep stos %rax,(%rdi)
    e455:	48 8d 05 94 58 ff ff 	lea    -0xa76c(%rip),%rax        # 3cf0 <fwp_segv>
    e45c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e461:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e468:	04 00 00 08 
    e46c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e471:	e8 0a 51 ff ff       	call   3580 <sigemptyset@plt>
    e476:	85 c0                	test   %eax,%eax
    e478:	0f 85 12 06 00 00    	jne    ea90 <fwp_main_thread+0x6d0>
    e47e:	31 d2                	xor    %edx,%edx
    e480:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e485:	bf 0b 00 00 00       	mov    $0xb,%edi
    e48a:	e8 71 4f ff ff       	call   3400 <sigaction@plt>
    e48f:	85 c0                	test   %eax,%eax
    e491:	0f 85 f9 05 00 00    	jne    ea90 <fwp_main_thread+0x6d0>
    e497:	31 d2                	xor    %edx,%edx
    e499:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e49e:	bf 07 00 00 00       	mov    $0x7,%edi
    e4a3:	e8 58 4f ff ff       	call   3400 <sigaction@plt>
    e4a8:	85 c0                	test   %eax,%eax
    e4aa:	0f 85 e0 05 00 00    	jne    ea90 <fwp_main_thread+0x6d0>
    e4b0:	8b 05 da 4b 00 00    	mov    0x4bda(%rip),%eax        # 13090 <st.3>
    e4b6:	85 c0                	test   %eax,%eax
    e4b8:	0f 84 62 05 00 00    	je     ea20 <fwp_main_thread+0x660>
    e4be:	48 8b 2d 9b 52 01 00 	mov    0x1529b(%rip),%rbp        # 23760 <fwp_cur>
    e4c5:	48 85 ed             	test   %rbp,%rbp
    e4c8:	0f 84 72 03 00 00    	je     e840 <fwp_main_thread+0x480>
    e4ce:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e4d3:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e4d7:	48 89 eb             	mov    %rbp,%rbx
    e4da:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e4df:	0f 84 41 01 00 00    	je     e626 <fwp_main_thread+0x266>
    e4e5:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e4ea:	0f 84 80 02 00 00    	je     e770 <fwp_main_thread+0x3b0>
    e4f0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e4f4:	0f 84 66 02 00 00    	je     e760 <fwp_main_thread+0x3a0>
    e4fa:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e4fe:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e502:	0f 85 e8 02 00 00    	jne    e7f0 <fwp_main_thread+0x430>
    e508:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e50c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e513:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e517:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e51e:	00 00 00 00 
    e522:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e529:	48 85 d2             	test   %rdx,%rdx
    e52c:	74 07                	je     e535 <fwp_main_thread+0x175>
    e52e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e535:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e539:	48 85 c0             	test   %rax,%rax
    e53c:	74 34                	je     e572 <fwp_main_thread+0x1b2>
    e53e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e542:	48 8b 05 ef 51 01 00 	mov    0x151ef(%rip),%rax        # 23738 <fwp_timers>
    e549:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e54d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e554:	00 00 00 00 
    e558:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e55f:	48 85 c0             	test   %rax,%rax
    e562:	74 07                	je     e56b <fwp_main_thread+0x1ab>
    e564:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e56b:	48 89 1d c6 51 01 00 	mov    %rbx,0x151c6(%rip)        # 23738 <fwp_timers>
    e572:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e576:	e8 d5 91 ff ff       	call   7750 <fwp_block>
    e57b:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e582:	48 85 c9             	test   %rcx,%rcx
    e585:	74 47                	je     e5ce <fwp_main_thread+0x20e>
    e587:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e58e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e595:	48 85 d2             	test   %rdx,%rdx
    e598:	0f 84 92 02 00 00    	je     e830 <fwp_main_thread+0x470>
    e59e:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e5a5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e5ac:	48 85 c0             	test   %rax,%rax
    e5af:	74 07                	je     e5b8 <fwp_main_thread+0x1f8>
    e5b1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e5b8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e5bf:	00 00 00 00 
    e5c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e5c7:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e5ce:	48 8b 0d 8b 51 01 00 	mov    0x1518b(%rip),%rcx        # 23760 <fwp_cur>
    e5d5:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e5d9:	0f 84 01 02 00 00    	je     e7e0 <fwp_main_thread+0x420>
    e5df:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e5e6:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e5ed:	48 85 d2             	test   %rdx,%rdx
    e5f0:	0f 84 fa 03 00 00    	je     e9f0 <fwp_main_thread+0x630>
    e5f6:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e5fd:	48 85 c0             	test   %rax,%rax
    e600:	74 07                	je     e609 <fwp_main_thread+0x249>
    e602:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e609:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e60d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e611:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e618:	48 89 cb             	mov    %rcx,%rbx
    e61b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e620:	0f 85 bf fe ff ff    	jne    e4e5 <fwp_main_thread+0x125>
    e626:	48 83 3d ca 6d 01 00 	cmpq   $0x0,0x16dca(%rip)        # 253f8 <fwp_state_len>
    e62d:	00 
    e62e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e632:	0f 84 ba 00 00 00    	je     e6f2 <fwp_main_thread+0x332>
    e638:	48 39 1d 19 51 01 00 	cmp    %rbx,0x15119(%rip)        # 23758 <fwp_root>
    e63f:	c7 05 57 4a 01 00 00 	movl   $0x0,0x14a57(%rip)        # 230a0 <fwp_exit_code>
    e646:	00 00 00 
    e649:	0f 85 5f 04 00 00    	jne    eaae <fwp_main_thread+0x6ee>
    e64f:	48 85 db             	test   %rbx,%rbx
    e652:	0f 84 0e 02 00 00    	je     e866 <fwp_main_thread+0x4a6>
    e658:	48 8b 15 c9 50 01 00 	mov    0x150c9(%rip),%rdx        # 23728 <fwp_tasks_active>
    e65f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e663:	48 85 d2             	test   %rdx,%rdx
    e666:	0f 84 fa 01 00 00    	je     e866 <fwp_main_thread+0x4a6>
    e66c:	0f 1f 40 00          	nopl   0x0(%rax)
    e670:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e674:	75 08                	jne    e67e <fwp_main_thread+0x2be>
    e676:	48 89 d7             	mov    %rdx,%rdi
    e679:	e8 32 5a ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e67e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e685:	48 85 d2             	test   %rdx,%rdx
    e688:	75 e6                	jne    e670 <fwp_main_thread+0x2b0>
    e68a:	eb 31                	jmp    e6bd <fwp_main_thread+0x2fd>
    e68c:	0f 1f 40 00          	nopl   0x0(%rax)
    e690:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e697:	48 89 1d a2 50 01 00 	mov    %rbx,0x150a2(%rip)        # 23740 <fwp_ready_tail>
    e69e:	e8 ad 90 ff ff       	call   7750 <fwp_block>
    e6a3:	e8 a8 8e ff ff       	call   7550 <fwp_free_zombie>
    e6a8:	48 83 3d 78 50 01 00 	cmpq   $0x0,0x15078(%rip)        # 23728 <fwp_tasks_active>
    e6af:	00 
    e6b0:	0f 84 b0 01 00 00    	je     e866 <fwp_main_thread+0x4a6>
    e6b6:	48 8b 1d 9b 50 01 00 	mov    0x1509b(%rip),%rbx        # 23758 <fwp_root>
    e6bd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e6c1:	75 db                	jne    e69e <fwp_main_thread+0x2de>
    e6c3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e6c7:	75 d5                	jne    e69e <fwp_main_thread+0x2de>
    e6c9:	48 8b 05 70 50 01 00 	mov    0x15070(%rip),%rax        # 23740 <fwp_ready_tail>
    e6d0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e6d4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e6db:	00 00 00 00 
    e6df:	48 85 c0             	test   %rax,%rax
    e6e2:	75 ac                	jne    e690 <fwp_main_thread+0x2d0>
    e6e4:	48 89 1d 5d 50 01 00 	mov    %rbx,0x1505d(%rip)        # 23748 <fwp_ready_head>
    e6eb:	eb aa                	jmp    e697 <fwp_main_thread+0x2d7>
    e6ed:	0f 1f 00             	nopl   (%rax)
    e6f0:	31 db                	xor    %ebx,%ebx
    e6f2:	48 83 3d ee 6c 01 00 	cmpq   $0x0,0x16cee(%rip)        # 253e8 <fwp_state_owners>
    e6f9:	00 
    e6fa:	0f 85 38 ff ff ff    	jne    e638 <fwp_main_thread+0x278>
    e700:	48 8b 3d f9 6c 01 00 	mov    0x16cf9(%rip),%rdi        # 25400 <fwp_state>
    e707:	e8 44 6e ff ff       	call   5550 <fwp_mem_free>
    e70c:	48 c7 05 e9 6c 01 00 	movq   $0x0,0x16ce9(%rip)        # 25400 <fwp_state>
    e713:	00 00 00 00 
    e717:	48 c7 05 ce 6c 01 00 	movq   $0x0,0x16cce(%rip)        # 253f0 <fwp_state_cap>
    e71e:	00 00 00 00 
    e722:	48 85 db             	test   %rbx,%rbx
    e725:	0f 84 46 03 00 00    	je     ea71 <fwp_main_thread+0x6b1>
    e72b:	48 39 1d 26 50 01 00 	cmp    %rbx,0x15026(%rip)        # 23758 <fwp_root>
    e732:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e739:	00 00 00 00 
    e73d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e744:	00 00 00 00 
    e748:	c7 05 4e 49 01 00 00 	movl   $0x0,0x1494e(%rip)        # 230a0 <fwp_exit_code>
    e74f:	00 00 00 
    e752:	0f 84 00 ff ff ff    	je     e658 <fwp_main_thread+0x298>
    e758:	e9 f3 4f ff ff       	jmp    3750 <fwp_main_thread.cold>
    e75d:	0f 1f 00             	nopl   (%rax)
    e760:	e8 ab 5b ff ff       	call   4310 <fwp_now_ns>
    e765:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e769:	0f 8d 91 02 00 00    	jge    ea00 <fwp_main_thread+0x640>
    e76f:	90                   	nop
    e770:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e774:	0f 85 80 fd ff ff    	jne    e4fa <fwp_main_thread+0x13a>
    e77a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e77e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e782:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e786:	0f 85 80 fd ff ff    	jne    e50c <fwp_main_thread+0x14c>
    e78c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e790:	48 85 c9             	test   %rcx,%rcx
    e793:	0f 84 73 fd ff ff    	je     e50c <fwp_main_thread+0x14c>
    e799:	48 85 c0             	test   %rax,%rax
    e79c:	0f 84 ff 02 00 00    	je     eaa1 <fwp_main_thread+0x6e1>
    e7a2:	48 39 c8             	cmp    %rcx,%rax
    e7a5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e7a9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7b0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e7b4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7bb:	00 00 00 00 
    e7bf:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e7c6:	48 85 d2             	test   %rdx,%rdx
    e7c9:	74 07                	je     e7d2 <fwp_main_thread+0x412>
    e7cb:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e7d2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e7d6:	e9 63 fd ff ff       	jmp    e53e <fwp_main_thread+0x17e>
    e7db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e7e0:	48 89 cb             	mov    %rcx,%rbx
    e7e3:	e9 f2 fc ff ff       	jmp    e4da <fwp_main_thread+0x11a>
    e7e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e7ef:	00 
    e7f0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e7f4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7fb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e802:	00 00 00 00 
    e806:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e80d:	48 85 c0             	test   %rax,%rax
    e810:	0f 84 52 02 00 00    	je     ea68 <fwp_main_thread+0x6a8>
    e816:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e81d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e821:	e9 4c fd ff ff       	jmp    e572 <fwp_main_thread+0x1b2>
    e826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e82d:	00 00 00 
    e830:	48 89 01             	mov    %rax,(%rcx)
    e833:	e9 74 fd ff ff       	jmp    e5ac <fwp_main_thread+0x1ec>
    e838:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e83f:	00 
    e840:	48 83 3d b0 6b 01 00 	cmpq   $0x0,0x16bb0(%rip)        # 253f8 <fwp_state_len>
    e847:	00 
    e848:	0f 84 a2 fe ff ff    	je     e6f0 <fwp_main_thread+0x330>
    e84e:	48 83 3d 02 4f 01 00 	cmpq   $0x0,0x14f02(%rip)        # 23758 <fwp_root>
    e855:	00 
    e856:	c7 05 40 48 01 00 00 	movl   $0x0,0x14840(%rip)        # 230a0 <fwp_exit_code>
    e85d:	00 00 00 
    e860:	0f 85 43 02 00 00    	jne    eaa9 <fwp_main_thread+0x6e9>
    e866:	e8 e5 8c ff ff       	call   7550 <fwp_free_zombie>
    e86b:	48 83 3d d5 4e 01 00 	cmpq   $0x0,0x14ed5(%rip)        # 23748 <fwp_ready_head>
    e872:	00 
    e873:	0f 85 d7 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e879:	48 83 3d b7 4e 01 00 	cmpq   $0x0,0x14eb7(%rip)        # 23738 <fwp_timers>
    e880:	00 
    e881:	0f 85 c9 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e887:	8b 1d 9f 48 01 00    	mov    0x1489f(%rip),%ebx        # 2312c <fwp_stack_pool_n>
    e88d:	85 db                	test   %ebx,%ebx
    e88f:	74 36                	je     e8c7 <fwp_main_thread+0x507>
    e891:	83 eb 01             	sub    $0x1,%ebx
    e894:	48 8d 05 a5 48 01 00 	lea    0x148a5(%rip),%rax        # 23140 <fwp_stack_pool>
    e89b:	48 63 d3             	movslq %ebx,%rdx
    e89e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e8a2:	eb 07                	jmp    e8ab <fwp_main_thread+0x4eb>
    e8a4:	0f 1f 40 00          	nopl   0x0(%rax)
    e8a8:	83 eb 01             	sub    $0x1,%ebx
    e8ab:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e8af:	be 00 00 00 10       	mov    $0x10000000,%esi
    e8b4:	89 1d 72 48 01 00    	mov    %ebx,0x14872(%rip)        # 2312c <fwp_stack_pool_n>
    e8ba:	48 83 ed 08          	sub    $0x8,%rbp
    e8be:	e8 1d 4d ff ff       	call   35e0 <munmap@plt>
    e8c3:	85 db                	test   %ebx,%ebx
    e8c5:	75 e1                	jne    e8a8 <fwp_main_thread+0x4e8>
    e8c7:	8b 3d 53 47 00 00    	mov    0x4753(%rip),%edi        # 13020 <fwp_epfd>
    e8cd:	85 ff                	test   %edi,%edi
    e8cf:	78 05                	js     e8d6 <fwp_main_thread+0x516>
    e8d1:	e8 fa 4b ff ff       	call   34d0 <close@plt>
    e8d6:	4c 8b 25 63 4a 01 00 	mov    0x14a63(%rip),%r12        # 23340 <fwp_nfdws>
    e8dd:	48 8b 2d 64 4a 01 00 	mov    0x14a64(%rip),%rbp        # 23348 <fwp_fdws>
    e8e4:	31 db                	xor    %ebx,%ebx
    e8e6:	c7 05 30 47 00 00 ff 	movl   $0xffffffff,0x4730(%rip)        # 13020 <fwp_epfd>
    e8ed:	ff ff ff 
    e8f0:	4d 85 e4             	test   %r12,%r12
    e8f3:	74 38                	je     e92d <fwp_main_thread+0x56d>
    e8f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e8fc:	00 00 00 00 
    e900:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e905:	48 85 ff             	test   %rdi,%rdi
    e908:	74 1a                	je     e924 <fwp_main_thread+0x564>
    e90a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e90e:	0f 85 3c 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e914:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e919:	0f 85 31 4e ff ff    	jne    3750 <fwp_main_thread.cold>
    e91f:	e8 2c 6c ff ff       	call   5550 <fwp_mem_free>
    e924:	48 83 c3 01          	add    $0x1,%rbx
    e928:	4c 39 e3             	cmp    %r12,%rbx
    e92b:	75 d3                	jne    e900 <fwp_main_thread+0x540>
    e92d:	48 89 ef             	mov    %rbp,%rdi
    e930:	e8 1b 6c ff ff       	call   5550 <fwp_mem_free>
    e935:	48 8b 15 1c 4e 01 00 	mov    0x14e1c(%rip),%rdx        # 23758 <fwp_root>
    e93c:	48 c7 05 01 4a 01 00 	movq   $0x0,0x14a01(%rip)        # 23348 <fwp_fdws>
    e943:	00 00 00 00 
    e947:	48 c7 05 ee 49 01 00 	movq   $0x0,0x149ee(%rip)        # 23340 <fwp_nfdws>
    e94e:	00 00 00 00 
    e952:	48 85 d2             	test   %rdx,%rdx
    e955:	74 4e                	je     e9a5 <fwp_main_thread+0x5e5>
    e957:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e95c:	0f 85 ee 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e962:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e969:	00 
    e96a:	0f 85 e0 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e970:	48 83 3d 80 6a 01 00 	cmpq   $0x0,0x16a80(%rip)        # 253f8 <fwp_state_len>
    e977:	00 
    e978:	0f 85 d2 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e97e:	48 83 3d 62 6a 01 00 	cmpq   $0x0,0x16a62(%rip)        # 253e8 <fwp_state_owners>
    e985:	00 
    e986:	0f 85 c4 4d ff ff    	jne    3750 <fwp_main_thread.cold>
    e98c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e991:	31 c0                	xor    %eax,%eax
    e993:	48 8d 3d c6 49 01 00 	lea    0x149c6(%rip),%rdi        # 23360 <fwp_root_context>
    e99a:	f3 48 ab             	rep stos %rax,(%rdi)
    e99d:	48 89 d7             	mov    %rdx,%rdi
    e9a0:	e8 ab 6b ff ff       	call   5550 <fwp_mem_free>
    e9a5:	48 8b 3d 94 46 00 00 	mov    0x4694(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e9ac:	48 c7 05 a9 4d 01 00 	movq   $0x0,0x14da9(%rip)        # 23760 <fwp_cur>
    e9b3:	00 00 00 00 
    e9b7:	48 c7 05 96 4d 01 00 	movq   $0x0,0x14d96(%rip)        # 23758 <fwp_root>
    e9be:	00 00 00 00 
    e9c2:	e8 f9 4b ff ff       	call   35c0 <fflush@plt>
    e9c7:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e9ce:	00 
    e9cf:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e9d6:	00 00 
    e9d8:	0f 85 be 00 00 00    	jne    ea9c <fwp_main_thread+0x6dc>
    e9de:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e9e5:	31 c0                	xor    %eax,%eax
    e9e7:	5b                   	pop    %rbx
    e9e8:	5d                   	pop    %rbp
    e9e9:	41 5c                	pop    %r12
    e9eb:	c3                   	ret
    e9ec:	0f 1f 40 00          	nopl   0x0(%rax)
    e9f0:	48 89 05 41 4d 01 00 	mov    %rax,0x14d41(%rip)        # 23738 <fwp_timers>
    e9f7:	e9 01 fc ff ff       	jmp    e5fd <fwp_main_thread+0x23d>
    e9fc:	0f 1f 40 00          	nopl   0x0(%rax)
    ea00:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ea04:	0f 85 66 fd ff ff    	jne    e770 <fwp_main_thread+0x3b0>
    ea0a:	48 89 ef             	mov    %rbp,%rdi
    ea0d:	e8 9e 56 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    ea12:	e9 59 fd ff ff       	jmp    e770 <fwp_main_thread+0x3b0>
    ea17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ea1e:	00 00 
    ea20:	e8 9b cc ff ff       	call   b6c0 <f0>
    ea25:	48 c7 05 58 46 00 00 	movq   $0x0,0x4658(%rip)        # 13088 <v.2>
    ea2c:	00 00 00 00 
    ea30:	c7 05 56 46 00 00 01 	movl   $0x1,0x4656(%rip)        # 13090 <st.3>
    ea37:	00 00 00 
    ea3a:	e9 7f fa ff ff       	jmp    e4be <fwp_main_thread+0xfe>
    ea3f:	90                   	nop
    ea40:	48 8d 3d d9 5f ff ff 	lea    -0xa027(%rip),%rdi        # 4a20 <fwp_heap_report>
    ea47:	e8 84 02 00 00       	call   ecd0 <atexit>
    ea4c:	e9 ad f9 ff ff       	jmp    e3fe <fwp_main_thread+0x3e>
    ea51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ea58:	e8 d3 60 ff ff       	call   4b30 <fwp_heap_init>
    ea5d:	e9 8e f9 ff ff       	jmp    e3f0 <fwp_main_thread+0x30>
    ea62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ea68:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ea6c:	e9 01 fb ff ff       	jmp    e572 <fwp_main_thread+0x1b2>
    ea71:	48 83 3d df 4c 01 00 	cmpq   $0x0,0x14cdf(%rip)        # 23758 <fwp_root>
    ea78:	00 
    ea79:	c7 05 1d 46 01 00 00 	movl   $0x0,0x1461d(%rip)        # 230a0 <fwp_exit_code>
    ea80:	00 00 00 
    ea83:	0f 84 dd fd ff ff    	je     e866 <fwp_main_thread+0x4a6>
    ea89:	e9 c2 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    ea8e:	66 90                	xchg   %ax,%ax
    ea90:	48 8d 3d 59 0e 00 00 	lea    0xe59(%rip),%rdi        # f8f0 <_IO_stdin_used+0x8f0>
    ea97:	e8 04 57 ff ff       	call   41a0 <fwp_trap>
    ea9c:	e8 bf 49 ff ff       	call   3460 <__stack_chk_fail@plt>
    eaa1:	48 89 c8             	mov    %rcx,%rax
    eaa4:	e9 00 fd ff ff       	jmp    e7a9 <fwp_main_thread+0x3e9>
    eaa9:	e9 a2 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    eaae:	e9 9d 4c ff ff       	jmp    3750 <fwp_main_thread.cold>
    eab3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eaba:	00 00 00 
    eabd:	0f 1f 00             	nopl   (%rax)

000000000000eac0 <__divmodti4>:
    eac0:	f3 0f 1e fa          	endbr64
    eac4:	55                   	push   %rbp
    eac5:	49 89 f1             	mov    %rsi,%r9
    eac8:	49 89 d2             	mov    %rdx,%r10
    eacb:	48 89 fe             	mov    %rdi,%rsi
    eace:	49 89 cb             	mov    %rcx,%r11
    ead1:	48 89 e5             	mov    %rsp,%rbp
    ead4:	41 57                	push   %r15
    ead6:	41 56                	push   %r14
    ead8:	41 55                	push   %r13
    eada:	41 54                	push   %r12
    eadc:	53                   	push   %rbx
    eadd:	4c 89 c3             	mov    %r8,%rbx
    eae0:	45 31 c0             	xor    %r8d,%r8d
    eae3:	4d 85 c9             	test   %r9,%r9
    eae6:	79 12                	jns    eafa <__divmodti4+0x3a>
    eae8:	31 ff                	xor    %edi,%edi
    eaea:	48 f7 de             	neg    %rsi
    eaed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    eaf4:	4c 19 cf             	sbb    %r9,%rdi
    eaf7:	49 89 f9             	mov    %rdi,%r9
    eafa:	4c 89 d8             	mov    %r11,%rax
    eafd:	4d 85 db             	test   %r11,%r11
    eb00:	0f 88 1a 01 00 00    	js     ec20 <__divmodti4+0x160>
    eb06:	4c 89 d9             	mov    %r11,%rcx
    eb09:	49 89 f3             	mov    %rsi,%r11
    eb0c:	75 62                	jne    eb70 <__divmodti4+0xb0>
    eb0e:	4d 89 c4             	mov    %r8,%r12
    eb11:	4d 39 d1             	cmp    %r10,%r9
    eb14:	0f 83 46 01 00 00    	jae    ec60 <__divmodti4+0x1a0>
    eb1a:	4c 89 d8             	mov    %r11,%rax
    eb1d:	4c 89 ca             	mov    %r9,%rdx
    eb20:	49 f7 f2             	div    %r10
    eb23:	49 89 c3             	mov    %rax,%r11
    eb26:	31 c0                	xor    %eax,%eax
    eb28:	48 89 d6             	mov    %rdx,%rsi
    eb2b:	31 ff                	xor    %edi,%edi
    eb2d:	4c 89 d9             	mov    %r11,%rcx
    eb30:	48 89 c2             	mov    %rax,%rdx
    eb33:	48 89 c8             	mov    %rcx,%rax
    eb36:	4d 85 e4             	test   %r12,%r12
    eb39:	74 0a                	je     eb45 <__divmodti4+0x85>
    eb3b:	48 f7 d8             	neg    %rax
    eb3e:	48 83 d2 00          	adc    $0x0,%rdx
    eb42:	48 f7 da             	neg    %rdx
    eb45:	4d 85 c0             	test   %r8,%r8
    eb48:	74 0a                	je     eb54 <__divmodti4+0x94>
    eb4a:	48 f7 de             	neg    %rsi
    eb4d:	48 83 d7 00          	adc    $0x0,%rdi
    eb51:	48 f7 df             	neg    %rdi
    eb54:	48 89 33             	mov    %rsi,(%rbx)
    eb57:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    eb5b:	5b                   	pop    %rbx
    eb5c:	41 5c                	pop    %r12
    eb5e:	41 5d                	pop    %r13
    eb60:	41 5e                	pop    %r14
    eb62:	41 5f                	pop    %r15
    eb64:	5d                   	pop    %rbp
    eb65:	c3                   	ret
    eb66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eb6d:	00 00 00 
    eb70:	4d 89 c4             	mov    %r8,%r12
    eb73:	49 39 c1             	cmp    %rax,%r9
    eb76:	0f 82 ce 00 00 00    	jb     ec4a <__divmodti4+0x18a>
    eb7c:	31 ff                	xor    %edi,%edi
    eb7e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    eb83:	48 63 c7             	movslq %edi,%rax
    eb86:	be 40 00 00 00       	mov    $0x40,%esi
    eb8b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    eb90:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    eb95:	48 29 c6             	sub    %rax,%rsi
    eb98:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    eb9d:	48 09 c8             	or     %rcx,%rax
    eba0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    eba5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ebaa:	49 89 c6             	mov    %rax,%r14
    ebad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ebb1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ebb6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ebbb:	49 09 c1             	or     %rax,%r9
    ebbe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ebc2:	4c 89 c8             	mov    %r9,%rax
    ebc5:	49 f7 f6             	div    %r14
    ebc8:	48 89 d1             	mov    %rdx,%rcx
    ebcb:	49 89 c3             	mov    %rax,%r11
    ebce:	49 89 c1             	mov    %rax,%r9
    ebd1:	49 f7 e2             	mul    %r10
    ebd4:	49 89 c6             	mov    %rax,%r14
    ebd7:	49 89 d2             	mov    %rdx,%r10
    ebda:	48 39 d1             	cmp    %rdx,%rcx
    ebdd:	72 07                	jb     ebe6 <__divmodti4+0x126>
    ebdf:	75 17                	jne    ebf8 <__divmodti4+0x138>
    ebe1:	49 39 c7             	cmp    %rax,%r15
    ebe4:	73 12                	jae    ebf8 <__divmodti4+0x138>
    ebe6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ebea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ebee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ebf2:	49 89 d2             	mov    %rdx,%r10
    ebf5:	49 89 c6             	mov    %rax,%r14
    ebf8:	4c 89 f8             	mov    %r15,%rax
    ebfb:	4c 29 f0             	sub    %r14,%rax
    ebfe:	4c 19 d1             	sbb    %r10,%rcx
    ec01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ec06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ec0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ec10:	48 09 c6             	or     %rax,%rsi
    ec13:	48 89 cf             	mov    %rcx,%rdi
    ec16:	31 c0                	xor    %eax,%eax
    ec18:	4c 89 c9             	mov    %r9,%rcx
    ec1b:	e9 10 ff ff ff       	jmp    eb30 <__divmodti4+0x70>
    ec20:	4c 89 d0             	mov    %r10,%rax
    ec23:	4c 89 da             	mov    %r11,%rdx
    ec26:	4d 89 c4             	mov    %r8,%r12
    ec29:	49 89 f3             	mov    %rsi,%r11
    ec2c:	48 f7 d8             	neg    %rax
    ec2f:	49 f7 d4             	not    %r12
    ec32:	48 83 d2 00          	adc    $0x0,%rdx
    ec36:	49 89 c2             	mov    %rax,%r10
    ec39:	48 f7 da             	neg    %rdx
    ec3c:	48 89 d1             	mov    %rdx,%rcx
    ec3f:	0f 84 cc fe ff ff    	je     eb11 <__divmodti4+0x51>
    ec45:	49 39 d1             	cmp    %rdx,%r9
    ec48:	73 46                	jae    ec90 <__divmodti4+0x1d0>
    ec4a:	4c 89 cf             	mov    %r9,%rdi
    ec4d:	31 c0                	xor    %eax,%eax
    ec4f:	31 c9                	xor    %ecx,%ecx
    ec51:	e9 da fe ff ff       	jmp    eb30 <__divmodti4+0x70>
    ec56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ec5d:	00 00 00 
    ec60:	4d 85 d2             	test   %r10,%r10
    ec63:	75 0d                	jne    ec72 <__divmodti4+0x1b2>
    ec65:	b8 01 00 00 00       	mov    $0x1,%eax
    ec6a:	31 d2                	xor    %edx,%edx
    ec6c:	49 f7 f2             	div    %r10
    ec6f:	49 89 c2             	mov    %rax,%r10
    ec72:	4c 89 c8             	mov    %r9,%rax
    ec75:	31 d2                	xor    %edx,%edx
    ec77:	49 f7 f2             	div    %r10
    ec7a:	49 89 c1             	mov    %rax,%r9
    ec7d:	4c 89 d8             	mov    %r11,%rax
    ec80:	49 f7 f2             	div    %r10
    ec83:	49 89 c3             	mov    %rax,%r11
    ec86:	4c 89 c8             	mov    %r9,%rax
    ec89:	e9 9a fe ff ff       	jmp    eb28 <__divmodti4+0x68>
    ec8e:	66 90                	xchg   %ax,%ax
    ec90:	45 31 f6             	xor    %r14d,%r14d
    ec93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ec98:	44 89 f7             	mov    %r14d,%edi
    ec9b:	45 85 f6             	test   %r14d,%r14d
    ec9e:	0f 85 df fe ff ff    	jne    eb83 <__divmodti4+0xc3>
    eca4:	4c 39 ca             	cmp    %r9,%rdx
    eca7:	72 17                	jb     ecc0 <__divmodti4+0x200>
    eca9:	31 c9                	xor    %ecx,%ecx
    ecab:	48 39 c6             	cmp    %rax,%rsi
    ecae:	73 10                	jae    ecc0 <__divmodti4+0x200>
    ecb0:	4c 89 cf             	mov    %r9,%rdi
    ecb3:	31 c0                	xor    %eax,%eax
    ecb5:	e9 76 fe ff ff       	jmp    eb30 <__divmodti4+0x70>
    ecba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ecc0:	4c 89 de             	mov    %r11,%rsi
    ecc3:	b9 01 00 00 00       	mov    $0x1,%ecx
    ecc8:	48 29 c6             	sub    %rax,%rsi
    eccb:	49 19 d1             	sbb    %rdx,%r9
    ecce:	eb e0                	jmp    ecb0 <__divmodti4+0x1f0>

000000000000ecd0 <atexit>:
    ecd0:	f3 0f 1e fa          	endbr64
    ecd4:	48 8b 15 2d 43 00 00 	mov    0x432d(%rip),%rdx        # 13008 <__dso_handle>
    ecdb:	31 f6                	xor    %esi,%esi
    ecdd:	e9 7e 49 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ece4 <_fini>:
    ece4:	f3 0f 1e fa          	endbr64
    ece8:	48 83 ec 08          	sub    $0x8,%rsp
    ecec:	48 83 c4 08          	add    $0x8,%rsp
    ecf0:	c3                   	ret
