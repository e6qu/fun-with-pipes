
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 dc 00 00 	lea    0xdce1(%rip),%rax        # 11460 <fwp_fn_table>
    377f:	48 89 05 b2 1c 02 00 	mov    %rax,0x21cb2(%rip)        # 25438 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac 1c 02 00 	mov    %rax,0x21cac(%rip)        # 25440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 1f ae 00 00 	lea    0xae1f(%rip),%rdx        # e680 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e c1 00 00 	lea    0xc17e(%rip),%rdi        # fa88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 c1 00 00 	lea    0xc138(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc c0 00 00 	lea    0xc0fc(%rip),%rdi        # fa30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 c0 00 00 	lea    0xc0c8(%rip),%rdi        # fa08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 17 02 00 	mov    0x217c9(%rip),%rdi        # 25440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 fa 01 00 	mov    0x1fac1(%rip),%rax        # 237c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 f3 01 00 	mov    0x1f3f9(%rip),%rax        # 23178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 f3 01 00 	sub    0x1f3e5(%rip),%rax        # 23170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f b8 00 00 	lea    0xb87f(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 f2 00 00 	mov    0xf262(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed f1 00 00 ff 	cmpl   $0xffffffff,0xf1ed(%rip)        # 13020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 f2 01 00 	mov    0x1f2e1(%rip),%r9        # 23128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc f2 01 00 	mov    0x1f2bc(%rip),%r8        # 23120 <descent_inputs>
    3e64:	48 8b 0d c5 f2 01 00 	mov    0x1f2c5(%rip),%rcx        # 23130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 f1 00 00 	mov    0xf1e2(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 b8 00 00 	lea    0xb818(%rip),%rdx        # f6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 f2 01 00 	lea    0x1f291(%rip),%r12        # 23140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b f1 00 00 	mov    0xf17b(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 f1 00 00 	mov    0xf140(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 f1 00 00 	mov    0xf119(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b 0c 02 00 	mov    0x20c3b(%rip),%rax        # 24bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 0c 02 00 	lea    0x20c34(%rip),%r8        # 24bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 0c 02 00 	mov    0x20c15(%rip),%rbx        # 24bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 0c 02 00 	mov    0x20c25(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 0b 02 00 	mov    0x20bc1(%rip),%rdi        # 24bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a 0c 02 00 	sub    %rsi,0x20c0a(%rip)        # 24c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a 0b 02 00 	mov    0x20b9a(%rip),%rax        # 24bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 0b 02 00 	add    0x20b50(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e 0b 02 00 	mov    0x20b5e(%rip),%rsi        # 24bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c 0b 02 00 	mov    0x20b6c(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b 0b 02 00 	mov    %r12,0x20b1b(%rip)        # 24bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 0b 02 00 	mov    %rbp,0x20b09(%rip)        # 24bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee 0a 02 00 	cmp    %rdi,0x20aee(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 0a 02 00 	mov    %rdi,0x20ae5(%rip)        # 24ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 0b 02 00 	sub    %rdi,0x20b29(%rip)        # 24c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 0a 02 00 	mov    0x20ad1(%rip),%rax        # 24bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca 0a 02 00 	lea    0x20aca(%rip),%r8        # 24bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ee 00 00 	mov    0xee7d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 ed 00 00 	movslq 0xedb5(%rip),%rbp        # 13020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ee 01 00 	mov    0x1ee9a(%rip),%rsi        # 23138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ee 01 00 	lea    0x1ee96(%rip),%rcx        # 23140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ee 01 00 	addq   $0x1,0x1ee6b(%rip)        # 23130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 ed 00 00    	mov    %ebx,0xed50(%rip)        # 13020 <descent_active_phase>
    42d0:	48 89 05 61 ee 01 00 	mov    %rax,0x1ee61(%rip)        # 23138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 f4 01 00 	cmp    0x1f4b9(%rip),%rdi        # 237c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f f4 01 00 	mov    0x1f47f(%rip),%rax        # 237a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d f4 01 00 	mov    %rdi,0x1f45d(%rip)        # 237a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 f4 01 00 	mov    %rdi,0x1f439(%rip)        # 237a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 ae 00 00 	lea    0xae18(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 ec 00 00 	mov    0xec48(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 ec 00 00 	mov    0xec30(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 eb 00 00 	mov    0xeb41(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 b1 00 00 	lea    0xb110(%rip),%rdi        # f700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 b5 00 	movdqa 0xb580(%rip),%xmm0        # fb90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca 0d 02 00 	add    0x20dca(%rip),%rax        # 25438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 b0 00 00 	lea    0xb064(%rip),%rdi        # f728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ea 01 00 	cmp    %rax,0x1ea25(%rip)        # 23108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ea 01 00 	add    0x1ea20(%rip),%rax        # 23110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d b0 00 00 	lea    0xb04d(%rip),%rdi        # f758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e a5 00 00 	lea    0xa57e(%rip),%rsi        # f20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 fe 01 00 	mov    0x1fea5(%rip),%r9        # 24ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe fe 01 00 	mov    0x1fefe(%rip),%r8        # 24c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 aa 00 00 	lea    0xaa97(%rip),%rdx        # f7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 fe 01 00 	mov    0x1fee6(%rip),%rcx        # 24c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 fe 01 	movsd  0x1fef4(%rip),%xmm1        # 24c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 fe 01 	movsd  0x1fee4(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 e3 00 00 	mov    0xe325(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 ae 00 	movdqa 0xae28(%rip),%xmm0        # fba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f f9 01 00 	lea    0x1f99f(%rip),%rax        # 24720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 ae 00 	movdqa 0xae51(%rip),%xmm2        # fbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 f9 01 00 	movaps %xmm0,0x1f945(%rip)        # 246e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d ae 00 	movdqa 0xae0d(%rip),%xmm0        # fbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 fd 01 00 01 	movl   $0x1,0x1fdd3(%rip)        # 24b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 f9 01 00 	movaps %xmm0,0x1f933(%rip)        # 246f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb ad 00 	movdqa 0xadfb(%rip),%xmm0        # fbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 f9 01 00 	movaps %xmm0,0x1f934(%rip)        # 24700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc ad 00 	movdqa 0xadfc(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 f9 01 00 	movaps %xmm0,0x1f935(%rip)        # 24710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 e9 01 00 	lea    0x1e9b5(%rip),%r8        # 237e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 fc 01 00 	mov    %rax,0x1fcd0(%rip)        # 24b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae fc 01 00 	mov    %r12,0x1fcae(%rip)        # 24ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 fc 01 00 	mov    %rax,0x1fc97(%rip)        # 24b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 fc 01 00 	mov    %rbx,0x1fcb0(%rip)        # 24bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 fc 01 00 	mov    %rsi,0x1fcd9(%rip)        # 24be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 fc 01 00 	mov    %rax,0x1fcb8(%rip)        # 24bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c fc 01 00    	mov    %eax,0x1fc3c(%rip)        # 24b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c e8 01 00 	mov    0x1e82c(%rip),%r8        # 237a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c e7 01 00 	mov    %rbx,0x1e75c(%rip)        # 237a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 e7 01 00 	mov    %r8,0x1e748(%rip)        # 237a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd df 01 00 	lea    0x1dfbd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 df 01 00 	movaps %xmm0,0x1dfa5(%rip)        # 230c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 df 01 00 	mov    %rax,0x1df81(%rip)        # 230a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 df 01 00 	movaps %xmm0,0x1dfa2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 df 01 00 	movaps %xmm0,0x1dfa6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 df 01 00 	mov    %rdx,0x1dfa7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 e5 01 00 	mov    0x1e5d7(%rip),%rbx        # 23798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa dd 00 00 	mov    0xddaa(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 a5 00 00 	lea    0xa573(%rip),%rdi        # f830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad e4 01 00 	mov    0x1e4ad(%rip),%rax        # 237a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 e4 01 00 	mov    %rdx,0x1e487(%rip)        # 237a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 e3 01 00 	mov    0x1e3d4(%rip),%rbx        # 23798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 e3 01 00 	mov    %rbx,0x1e391(%rip)        # 23798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 e3 01 00 	mov    %rdx,0x1e391(%rip)        # 237a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 e3 01 00 	lea    0x1e3a6(%rip),%rsi        # 237e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 ff 01 00 	addq   $0x1,0x1ff25(%rip)        # 25428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 a3 00 00 	lea    0xa347(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 a3 00 00 	lea    0xa358(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e e2 01 00 	lea    0x1e25e(%rip),%rcx        # 237e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f fe 01 00 	subq   $0x1,0x1fe5f(%rip)        # 25428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 a2 00 00 	lea    0xa2b3(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 fe 01 00 	cmpq   $0x0,0x1fe40(%rip)        # 25428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 fd 01 00 	sub    %rax,0x1fd95(%rip)        # 25430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 fd 01 00 	add    %r12,0x1fd73(%rip)        # 25430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf f4 01 00 	mov    0x1f4cf(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc e0 01 00 	lea    0x1e0cc(%rip),%rax        # 237e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 f4 01 00 	add    0x1f423(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 f3 01 00 	mov    0x1f3f0(%rip),%rsi        # 24b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 f4 01 00 	mov    0x1f411(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 f4 01 00 	add    0x1f405(%rip),%r8        # 24bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd f3 01 	addsd  0x1f3cd(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 df 01 00 	lea    0x1df82(%rip),%rax        # 237e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c f3 01 00 	sub    %rdi,0x1f38c(%rip)        # 24c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 f3 01 	movsd  %xmm0,0x1f3a4(%rip)        # 24c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e f3 01 00 	sub    %rdx,0x1f35e(%rip)        # 24c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 f3 01 	addsd  0x1f364(%rip),%xmm0        # 24c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 f3 01 	movsd  %xmm0,0x1f358(%rip)        # 24c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef f2 01 00 	mov    0x1f2ef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 f2 01 00 	add    %rcx,0x1f2e9(%rip)        # 24c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 f2 01 00 	cmp    0x1f2a2(%rip),%r9        # 24bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 f2 01 00 	mov    %r9,0x1f299(%rip)        # 24bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a f2 01 00 	cmp    0x1f28a(%rip),%r9        # 24bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d f2 01 00 	mov    %r9,0x1f27d(%rip)        # 24bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 f1 01 00 	add    0x1f193(%rip),%rdi        # 24bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 dd 01 00 	lea    0x1dd70(%rip),%r15        # 237e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 f0 01 00 	add    0x1f0e0(%rip),%r12        # 24b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 f1 01 00 	add    0x1f139(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 f1 01 00 	cmp    %rax,0x1f138(%rip)        # 24c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 f1 01 00 	mov    %rax,0x1f129(%rip)        # 24c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 f1 01 00 	mov    %rax,0x1f128(%rip)        # 24c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 f1 01 	addsd  0x1f124(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c f1 01 	movsd  %xmm0,0x1f11c(%rip)        # 24c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 f0 01 00    	mov    0x1f063(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f dc 01 00 	lea    0x1dc9f(%rip),%rdi        # 237e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 f0 01 00 	add    0x1f058(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 f0 01 00 	cmp    %rax,0x1f053(%rip)        # 24c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 f0 01 00 	mov    %rax,0x1f044(%rip)        # 24c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 f0 01 00 	mov    %rax,0x1f043(%rip)        # 24c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f f0 01 	addsd  0x1f03f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 f0 01 	movsd  %xmm0,0x1f037(%rip)        # 24c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ee 01 00    	mov    0x1eeee(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 db 01 00 	lea    0x1db25(%rip),%rax        # 237e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ee 01 00 	add    0x1eedb(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ee 01 00 	cmp    %rax,0x1eeda(%rip)        # 24c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ee 01 00 	mov    %rax,0x1eecb(%rip)        # 24c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ee 01 00 	mov    %rax,0x1eeca(%rip)        # 24c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ee 01 	addsd  0x1eec6(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ee 01 	movsd  %xmm0,0x1eebe(%rip)        # 24c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c f6 01 00 	add    0x1f64c(%rip),%r9        # 25438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_tape_reserve>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	41 54                	push   %r12
    5ff8:	55                   	push   %rbp
    5ff9:	53                   	push   %rbx
    5ffa:	48 83 ec 18          	sub    $0x18,%rsp
    5ffe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6005:	0f 87 d3 01 00 00    	ja     61de <fwp_tape_reserve+0x1ee>
    600b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    600f:	48 89 fd             	mov    %rdi,%rbp
    6012:	48 39 f3             	cmp    %rsi,%rbx
    6015:	0f 8d 13 01 00 00    	jge    612e <fwp_tape_reserve+0x13e>
    601b:	48 85 db             	test   %rbx,%rbx
    601e:	b8 40 00 00 00       	mov    $0x40,%eax
    6023:	48 0f 44 d8          	cmove  %rax,%rbx
    6027:	48 39 f3             	cmp    %rsi,%rbx
    602a:	7d 24                	jge    6050 <fwp_tape_reserve+0x60>
    602c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6033:	0f 8f 07 01 00 00    	jg     6140 <fwp_tape_reserve+0x150>
    6039:	48 01 db             	add    %rbx,%rbx
    603c:	48 39 f3             	cmp    %rsi,%rbx
    603f:	7c eb                	jl     602c <fwp_tape_reserve+0x3c>
    6041:	0f 1f 40 00          	nopl   0x0(%rax)
    6045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    604c:	00 00 00 00 
    6050:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    6057:	00 
    6058:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    605c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    6060:	4c 89 ee             	mov    %r13,%rsi
    6063:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    6067:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    606b:	e8 60 d5 ff ff       	call   35d0 <realloc@plt>
    6070:	48 85 c0             	test   %rax,%rax
    6073:	0f 84 71 01 00 00    	je     61ea <fwp_tape_reserve+0x1fa>
    6079:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    607d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    6081:	4d 29 fc             	sub    %r15,%r12
    6084:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6088:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    608c:	4d 85 f6             	test   %r14,%r14
    608f:	0f 84 03 01 00 00    	je     6198 <fwp_tape_reserve+0x1a8>
    6095:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6099:	48 39 da             	cmp    %rbx,%rdx
    609c:	7d 78                	jge    6116 <fwp_tape_reserve+0x126>
    609e:	48 89 d9             	mov    %rbx,%rcx
    60a1:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    60a5:	be 02 00 00 00       	mov    $0x2,%esi
    60aa:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    60af:	48 c1 e1 04          	shl    $0x4,%rcx
    60b3:	48 89 cf             	mov    %rcx,%rdi
    60b6:	48 89 0c 24          	mov    %rcx,(%rsp)
    60ba:	e8 d1 fb ff ff       	call   5c90 <fwp_heap_alloc>
    60bf:	49 89 c5             	mov    %rax,%r13
    60c2:	4d 85 ff             	test   %r15,%r15
    60c5:	74 27                	je     60ee <fwp_tape_reserve+0xfe>
    60c7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    60cc:	48 8b 0c 24          	mov    (%rsp),%rcx
    60d0:	48 89 c7             	mov    %rax,%rdi
    60d3:	4c 89 fe             	mov    %r15,%rsi
    60d6:	48 c1 e2 04          	shl    $0x4,%rdx
    60da:	48 39 ca             	cmp    %rcx,%rdx
    60dd:	48 0f 47 d1          	cmova  %rcx,%rdx
    60e1:	e8 ba d4 ff ff       	call   35a0 <memcpy@plt>
    60e6:	4c 89 ff             	mov    %r15,%rdi
    60e9:	e8 a2 f6 ff ff       	call   5790 <fwp_mem_free>
    60ee:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    60f2:	48 89 da             	mov    %rbx,%rdx
    60f5:	31 f6                	xor    %esi,%esi
    60f7:	48 29 fa             	sub    %rdi,%rdx
    60fa:	48 c1 e7 04          	shl    $0x4,%rdi
    60fe:	48 c1 e2 04          	shl    $0x4,%rdx
    6102:	4c 01 ef             	add    %r13,%rdi
    6105:	e8 b6 d3 ff ff       	call   34c0 <memset@plt>
    610a:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    610e:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6112:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    6116:	4d 85 e4             	test   %r12,%r12
    6119:	75 55                	jne    6170 <fwp_tape_reserve+0x180>
    611b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6122:	00 
    6123:	4c 01 e8             	add    %r13,%rax
    6126:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    612a:	48 89 45 28          	mov    %rax,0x28(%rbp)
    612e:	48 83 c4 18          	add    $0x18,%rsp
    6132:	5b                   	pop    %rbx
    6133:	5d                   	pop    %rbp
    6134:	41 5c                	pop    %r12
    6136:	41 5d                	pop    %r13
    6138:	41 5e                	pop    %r14
    613a:	41 5f                	pop    %r15
    613c:	c3                   	ret
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    6145:	e9 06 ff ff ff       	jmp    6050 <fwp_tape_reserve+0x60>
    614a:	4d 39 f5             	cmp    %r14,%r13
    614d:	4c 89 f1             	mov    %r14,%rcx
    6150:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6157:	00 
    6158:	49 0f 43 cd          	cmovae %r13,%rcx
    615c:	4c 29 e9             	sub    %r13,%rcx
    615f:	e8 fc d3 ff ff       	call   3560 <__memmove_chk@plt>
    6164:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6168:	48 8b 45 20          	mov    0x20(%rbp),%rax
    616c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    6170:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    6174:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    617b:	00 
    617c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    6183:	00 
    6184:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6188:	e8 83 d4 ff ff       	call   3610 <memmove@plt>
    618d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6191:	eb 90                	jmp    6123 <fwp_tape_reserve+0x133>
    6193:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6198:	49 89 de             	mov    %rbx,%r14
    619b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    619f:	49 c1 e6 04          	shl    $0x4,%r14
    61a3:	4c 89 f6             	mov    %r14,%rsi
    61a6:	e8 25 d4 ff ff       	call   35d0 <realloc@plt>
    61ab:	48 85 c0             	test   %rax,%rax
    61ae:	74 3a                	je     61ea <fwp_tape_reserve+0x1fa>
    61b0:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    61b4:	48 89 45 30          	mov    %rax,0x30(%rbp)
    61b8:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    61bc:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    61c0:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    61c4:	4d 85 e4             	test   %r12,%r12
    61c7:	75 81                	jne    614a <fwp_tape_reserve+0x15a>
    61c9:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    61cd:	48 8b 45 20          	mov    0x20(%rbp),%rax
    61d1:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    61d8:	00 
    61d9:	e9 45 ff ff ff       	jmp    6123 <fwp_tape_reserve+0x133>
    61de:	48 8d 3d 67 8f 00 00 	lea    0x8f67(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    61e5:	e8 06 e2 ff ff       	call   43f0 <fwp_trap>
    61ea:	48 89 ef             	mov    %rbp,%rdi
    61ed:	e8 0e da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61f2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    61f6:	e8 c5 d1 ff ff       	call   33c0 <free@plt>
    61fb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    61ff:	e8 bc d1 ff ff       	call   33c0 <free@plt>
    6204:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    6208:	e8 b3 d1 ff ff       	call   33c0 <free@plt>
    620d:	31 c9                	xor    %ecx,%ecx
    620f:	31 c0                	xor    %eax,%eax
    6211:	31 d2                	xor    %edx,%edx
    6213:	89 55 04             	mov    %edx,0x4(%rbp)
    6216:	66 0f ef c0          	pxor   %xmm0,%xmm0
    621a:	ba 13 00 00 00       	mov    $0x13,%edx
    621f:	be 01 00 00 00       	mov    $0x1,%esi
    6224:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6228:	48 8d 3d d9 8d 00 00 	lea    0x8dd9(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    622f:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6233:	48 8b 0d 26 ce 00 00 	mov    0xce26(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    623a:	48 89 45 40          	mov    %rax,0x40(%rbp)
    623e:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6242:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6246:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    624a:	e8 31 d4 ff ff       	call   3680 <fwrite@plt>
    624f:	31 ff                	xor    %edi,%edi
    6251:	e8 6a d3 ff ff       	call   35c0 <fflush@plt>
    6256:	bf 66 00 00 00       	mov    $0x66,%edi
    625b:	e8 40 d4 ff ff       	call   36a0 <_Exit@plt>

0000000000006260 <f128.constprop.0>:
    6260:	41 57                	push   %r15
    6262:	41 56                	push   %r14
    6264:	41 55                	push   %r13
    6266:	41 54                	push   %r12
    6268:	49 89 f4             	mov    %rsi,%r12
    626b:	55                   	push   %rbp
    626c:	48 89 fd             	mov    %rdi,%rbp
    626f:	53                   	push   %rbx
    6270:	48 83 ec 08          	sub    $0x8,%rsp
    6274:	48 85 ff             	test   %rdi,%rdi
    6277:	79 09                	jns    6282 <f128.constprop.0+0x22>
    6279:	48 85 f6             	test   %rsi,%rsi
    627c:	0f 88 fe 00 00 00    	js     6380 <f128.constprop.0+0x120>
    6282:	48 89 f8             	mov    %rdi,%rax
    6285:	48 09 f0             	or     %rsi,%rax
    6288:	0f 89 d2 00 00 00    	jns    6360 <f128.constprop.0+0x100>
    628e:	48 89 f8             	mov    %rdi,%rax
    6291:	48 c1 f8 20          	sar    $0x20,%rax
    6295:	48 85 ff             	test   %rdi,%rdi
    6298:	0f 88 02 01 00 00    	js     63a0 <f128.constprop.0+0x140>
    629e:	4c 8b 3d 7b 99 00 00 	mov    0x997b(%rip),%r15        # fc20 <msg.4+0xb0>
    62a5:	48 89 c7             	mov    %rax,%rdi
    62a8:	e8 23 e4 ff ff       	call   46d0 <fwp_tape_of>
    62ad:	48 89 c3             	mov    %rax,%rbx
    62b0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62b5:	0f 85 16 01 00 00    	jne    63d1 <f128.constprop.0+0x171>
    62bb:	4c 8b 68 10          	mov    0x10(%rax),%r13
    62bf:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    62c6:	0f 8f f9 00 00 00    	jg     63c5 <f128.constprop.0+0x165>
    62cc:	89 e8                	mov    %ebp,%eax
    62ce:	49 39 c5             	cmp    %rax,%r13
    62d1:	0f 8e e2 00 00 00    	jle    63b9 <f128.constprop.0+0x159>
    62d7:	4d 85 e4             	test   %r12,%r12
    62da:	78 0c                	js     62e8 <f128.constprop.0+0x88>
    62dc:	44 89 e0             	mov    %r12d,%eax
    62df:	49 39 c5             	cmp    %rax,%r13
    62e2:	0f 8e d1 00 00 00    	jle    63b9 <f128.constprop.0+0x159>
    62e8:	4d 89 ee             	mov    %r13,%r14
    62eb:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    62ef:	48 89 df             	mov    %rbx,%rdi
    62f2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    62f6:	e8 f5 fc ff ff       	call   5ff0 <fwp_tape_reserve>
    62fb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    62ff:	4d 85 e4             	test   %r12,%r12
    6302:	48 8b 0d 17 99 00 00 	mov    0x9917(%rip),%rcx        # fc20 <msg.4+0xb0>
    6309:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6310:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6314:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6318:	4c 0f 48 e2          	cmovs  %rdx,%r12
    631c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6320:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6324:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6328:	48 8b 43 38          	mov    0x38(%rbx),%rax
    632c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6330:	49 8d 45 01          	lea    0x1(%r13),%rax
    6334:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6338:	48 83 c4 08          	add    $0x8,%rsp
    633c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6343:	ff ff ff 
    6346:	48 21 e8             	and    %rbp,%rax
    6349:	5b                   	pop    %rbx
    634a:	5d                   	pop    %rbp
    634b:	4c 09 e8             	or     %r13,%rax
    634e:	41 5c                	pop    %r12
    6350:	41 5d                	pop    %r13
    6352:	41 5e                	pop    %r14
    6354:	41 5f                	pop    %r15
    6356:	c3                   	ret
    6357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    635e:	00 00 
    6360:	48 89 f0             	mov    %rsi,%rax
    6363:	48 c1 ff 20          	sar    $0x20,%rdi
    6367:	48 c1 f8 20          	sar    $0x20,%rax
    636b:	48 39 c7             	cmp    %rax,%rdi
    636e:	0f 84 2a ff ff ff    	je     629e <f128.constprop.0+0x3e>
    6374:	48 8d 3d 35 95 00 00 	lea    0x9535(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    637b:	e8 70 e0 ff ff       	call   43f0 <fwp_trap>
    6380:	48 83 c4 08          	add    $0x8,%rsp
    6384:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    638b:	5b                   	pop    %rbx
    638c:	5d                   	pop    %rbp
    638d:	41 5c                	pop    %r12
    638f:	41 5d                	pop    %r13
    6391:	41 5e                	pop    %r14
    6393:	41 5f                	pop    %r15
    6395:	c3                   	ret
    6396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    639d:	00 00 00 
    63a0:	48 89 f0             	mov    %rsi,%rax
    63a3:	48 89 f5             	mov    %rsi,%rbp
    63a6:	45 31 ff             	xor    %r15d,%r15d
    63a9:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    63b0:	48 c1 f8 20          	sar    $0x20,%rax
    63b4:	e9 ec fe ff ff       	jmp    62a5 <f128.constprop.0+0x45>
    63b9:	48 8d 3d a7 8d 00 00 	lea    0x8da7(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    63c0:	e8 2b e0 ff ff       	call   43f0 <fwp_trap>
    63c5:	48 8d 3d 80 8d 00 00 	lea    0x8d80(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    63cc:	e8 1f e0 ff ff       	call   43f0 <fwp_trap>
    63d1:	48 8d 3d 20 95 00 00 	lea    0x9520(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    63d8:	e8 13 e0 ff ff       	call   43f0 <fwp_trap>
    63dd:	0f 1f 00             	nopl   (%rax)

00000000000063e0 <w107>:
    63e0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    63e4:	41 57                	push   %r15
    63e6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    63ea:	41 56                	push   %r14
    63ec:	41 55                	push   %r13
    63ee:	41 54                	push   %r12
    63f0:	49 89 f4             	mov    %rsi,%r12
    63f3:	55                   	push   %rbp
    63f4:	48 89 fd             	mov    %rdi,%rbp
    63f7:	53                   	push   %rbx
    63f8:	48 83 ec 38          	sub    $0x38,%rsp
    63fc:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6401:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6407:	48 85 ff             	test   %rdi,%rdi
    640a:	0f 88 d0 04 00 00    	js     68e0 <w107+0x500>
    6410:	49 89 ff             	mov    %rdi,%r15
    6413:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6419:	49 c1 ff 20          	sar    $0x20,%r15
    641d:	4c 89 ff             	mov    %r15,%rdi
    6420:	e8 ab e2 ff ff       	call   46d0 <fwp_tape_of>
    6425:	48 89 c3             	mov    %rax,%rbx
    6428:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    642d:	0f 85 45 05 00 00    	jne    6978 <w107+0x598>
    6433:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6437:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    643e:	0f 8f 28 05 00 00    	jg     696c <w107+0x58c>
    6444:	89 e8                	mov    %ebp,%eax
    6446:	49 39 c5             	cmp    %rax,%r13
    6449:	0f 8e 11 05 00 00    	jle    6960 <w107+0x580>
    644f:	4d 89 ee             	mov    %r13,%r14
    6452:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6456:	48 89 df             	mov    %rbx,%rdi
    6459:	49 8d 76 01          	lea    0x1(%r14),%rsi
    645d:	e8 8e fb ff ff       	call   5ff0 <fwp_tape_reserve>
    6462:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6466:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    646b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6471:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6475:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6479:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    647f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6483:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6487:	48 8b 43 38          	mov    0x38(%rbx),%rax
    648b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6491:	49 8d 45 01          	lea    0x1(%r13),%rax
    6495:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    649c:	ff ff ff 
    649f:	49 21 ee             	and    %rbp,%r14
    64a2:	48 89 43 10          	mov    %rax,0x10(%rbx)
    64a6:	4d 09 ee             	or     %r13,%r14
    64a9:	4d 89 f5             	mov    %r14,%r13
    64ac:	49 c1 fd 20          	sar    $0x20,%r13
    64b0:	4d 85 e4             	test   %r12,%r12
    64b3:	78 10                	js     64c5 <w107+0xe5>
    64b5:	4c 89 e0             	mov    %r12,%rax
    64b8:	48 c1 f8 20          	sar    $0x20,%rax
    64bc:	4c 39 e8             	cmp    %r13,%rax
    64bf:	0f 85 87 04 00 00    	jne    694c <w107+0x56c>
    64c5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    64cb:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64d1:	4d 39 ef             	cmp    %r13,%r15
    64d4:	0f 84 d6 03 00 00    	je     68b0 <w107+0x4d0>
    64da:	f2 0f 10 1d 3e 97 00 	movsd  0x973e(%rip),%xmm3        # fc20 <msg.4+0xb0>
    64e1:	00 
    64e2:	f2 0f 10 25 3e 97 00 	movsd  0x973e(%rip),%xmm4        # fc28 <msg.4+0xb8>
    64e9:	00 
    64ea:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    64f0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    64f6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    64fc:	4c 89 ef             	mov    %r13,%rdi
    64ff:	e8 cc e1 ff ff       	call   46d0 <fwp_tape_of>
    6504:	48 89 c3             	mov    %rax,%rbx
    6507:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    650c:	0f 85 66 04 00 00    	jne    6978 <w107+0x598>
    6512:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6516:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    651d:	0f 8f 49 04 00 00    	jg     696c <w107+0x58c>
    6523:	44 89 f0             	mov    %r14d,%eax
    6526:	49 39 c7             	cmp    %rax,%r15
    6529:	0f 8e 31 04 00 00    	jle    6960 <w107+0x580>
    652f:	4d 85 e4             	test   %r12,%r12
    6532:	78 0c                	js     6540 <w107+0x160>
    6534:	44 89 e0             	mov    %r12d,%eax
    6537:	49 39 c7             	cmp    %rax,%r15
    653a:	0f 8e 20 04 00 00    	jle    6960 <w107+0x580>
    6540:	4c 89 f9             	mov    %r15,%rcx
    6543:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6547:	48 89 df             	mov    %rbx,%rdi
    654a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    654e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6553:	e8 98 fa ff ff       	call   5ff0 <fwp_tape_reserve>
    6558:	48 8b 43 20          	mov    0x20(%rbx),%rax
    655c:	4d 85 e4             	test   %r12,%r12
    655f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6563:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6568:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    656e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6574:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6578:	48 8b 43 30          	mov    0x30(%rbx),%rax
    657c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6581:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6588:	49 0f 49 c4          	cmovns %r12,%rax
    658c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6590:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6593:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6597:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    659c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    65a0:	48 85 ed             	test   %rbp,%rbp
    65a3:	0f 88 0e 04 00 00    	js     69b7 <w107+0x5d7>
    65a9:	48 89 e8             	mov    %rbp,%rax
    65ac:	48 c1 f8 20          	sar    $0x20,%rax
    65b0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    65b5:	49 39 c5             	cmp    %rax,%r13
    65b8:	74 1a                	je     65d4 <w107+0x1f4>
    65ba:	48 89 c7             	mov    %rax,%rdi
    65bd:	e8 0e e1 ff ff       	call   46d0 <fwp_tape_of>
    65c2:	48 89 c3             	mov    %rax,%rbx
    65c5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65ca:	0f 85 a8 03 00 00    	jne    6978 <w107+0x598>
    65d0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    65d4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    65db:	0f 8f 8b 03 00 00    	jg     696c <w107+0x58c>
    65e1:	89 e8                	mov    %ebp,%eax
    65e3:	4c 39 e0             	cmp    %r12,%rax
    65e6:	0f 8d 74 03 00 00    	jge    6960 <w107+0x580>
    65ec:	4c 89 e0             	mov    %r12,%rax
    65ef:	48 2b 43 08          	sub    0x8(%rbx),%rax
    65f3:	48 89 df             	mov    %rbx,%rdi
    65f6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    65fa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    65ff:	e8 ec f9 ff ff       	call   5ff0 <fwp_tape_reserve>
    6604:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6609:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    660d:	48 8b 0d 14 96 00 00 	mov    0x9614(%rip),%rcx        # fc28 <msg.4+0xb8>
    6614:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    661a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    661d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6621:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6625:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    662b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    662f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6633:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6637:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    663e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6642:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6647:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    664c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6650:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6657:	ff ff ff 
    665a:	48 21 c5             	and    %rax,%rbp
    665d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6663:	4c 09 e5             	or     %r12,%rbp
    6666:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    666d:	ff ff ff 
    6670:	49 21 c6             	and    %rax,%r14
    6673:	4d 09 fe             	or     %r15,%r14
    6676:	4d 89 f4             	mov    %r14,%r12
    6679:	49 c1 fc 20          	sar    $0x20,%r12
    667d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6682:	74 16                	je     669a <w107+0x2ba>
    6684:	4c 89 e7             	mov    %r12,%rdi
    6687:	e8 44 e0 ff ff       	call   46d0 <fwp_tape_of>
    668c:	48 89 c3             	mov    %rax,%rbx
    668f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6694:	0f 85 de 02 00 00    	jne    6978 <w107+0x598>
    669a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    669e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    66a5:	0f 8f c1 02 00 00    	jg     696c <w107+0x58c>
    66ab:	44 89 f0             	mov    %r14d,%eax
    66ae:	49 39 c7             	cmp    %rax,%r15
    66b1:	0f 8e a9 02 00 00    	jle    6960 <w107+0x580>
    66b7:	4d 89 fd             	mov    %r15,%r13
    66ba:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    66be:	48 89 df             	mov    %rbx,%rdi
    66c1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    66c5:	e8 26 f9 ff ff       	call   5ff0 <fwp_tape_reserve>
    66ca:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66ce:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    66d4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    66d8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    66dc:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    66e2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    66e6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    66ea:	48 8b 43 38          	mov    0x38(%rbx),%rax
    66ee:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    66f4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    66f8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66ff:	ff ff ff 
    6702:	49 21 c6             	and    %rax,%r14
    6705:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6709:	4d 09 fe             	or     %r15,%r14
    670c:	4d 89 f7             	mov    %r14,%r15
    670f:	49 c1 ff 20          	sar    $0x20,%r15
    6713:	4d 39 e7             	cmp    %r12,%r15
    6716:	74 1d                	je     6735 <w107+0x355>
    6718:	4c 89 ff             	mov    %r15,%rdi
    671b:	e8 b0 df ff ff       	call   46d0 <fwp_tape_of>
    6720:	48 89 c3             	mov    %rax,%rbx
    6723:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6728:	0f 85 4a 02 00 00    	jne    6978 <w107+0x598>
    672e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6732:	4d 89 fc             	mov    %r15,%r12
    6735:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    673c:	0f 8f 2a 02 00 00    	jg     696c <w107+0x58c>
    6742:	44 89 f0             	mov    %r14d,%eax
    6745:	4c 39 e8             	cmp    %r13,%rax
    6748:	0f 8d 12 02 00 00    	jge    6960 <w107+0x580>
    674e:	f2 0f 10 3d da 94 00 	movsd  0x94da(%rip),%xmm7        # fc30 <msg.4+0xc0>
    6755:	00 
    6756:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    675c:	4d 89 ef             	mov    %r13,%r15
    675f:	48 89 df             	mov    %rbx,%rdi
    6762:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6768:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    676d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6771:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6775:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    677a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6780:	e8 6b f8 ff ff       	call   5ff0 <fwp_tape_reserve>
    6785:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6789:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    678e:	48 8b 15 9b 94 00 00 	mov    0x949b(%rip),%rdx        # fc30 <msg.4+0xc0>
    6795:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6799:	48 8b 43 30          	mov    0x30(%rbx),%rax
    679d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    67a1:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    67a5:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    67a9:	48 8b 43 28          	mov    0x28(%rbx),%rax
    67ad:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    67b4:	ff 
    67b5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    67b9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    67c0:	00 
    67c1:	49 8d 45 01          	lea    0x1(%r13),%rax
    67c5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    67c9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    67d0:	ff ff ff 
    67d3:	49 21 c6             	and    %rax,%r14
    67d6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    67dc:	4d 09 ee             	or     %r13,%r14
    67df:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    67e3:	0f 84 57 01 00 00    	je     6940 <w107+0x560>
    67e9:	48 89 ef             	mov    %rbp,%rdi
    67ec:	48 c1 ff 20          	sar    $0x20,%rdi
    67f0:	4c 39 e7             	cmp    %r12,%rdi
    67f3:	74 13                	je     6808 <w107+0x428>
    67f5:	e8 d6 de ff ff       	call   46d0 <fwp_tape_of>
    67fa:	48 89 c3             	mov    %rax,%rbx
    67fd:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6802:	0f 85 70 01 00 00    	jne    6978 <w107+0x598>
    6808:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    680c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6813:	0f 8f 53 01 00 00    	jg     696c <w107+0x58c>
    6819:	89 e8                	mov    %ebp,%eax
    681b:	4c 39 e0             	cmp    %r12,%rax
    681e:	0f 8d 3c 01 00 00    	jge    6960 <w107+0x580>
    6824:	4d 89 e5             	mov    %r12,%r13
    6827:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    682b:	48 89 df             	mov    %rbx,%rdi
    682e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6832:	e8 b9 f7 ff ff       	call   5ff0 <fwp_tape_reserve>
    6837:	48 8b 43 20          	mov    0x20(%rbx),%rax
    683b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6840:	48 89 ef             	mov    %rbp,%rdi
    6843:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6847:	48 8b 43 30          	mov    0x30(%rbx),%rax
    684b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6851:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6855:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6859:	48 8b 43 38          	mov    0x38(%rbx),%rax
    685d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6863:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6868:	48 89 43 10          	mov    %rax,0x10(%rbx)
    686c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6873:	ff ff ff 
    6876:	48 21 c7             	and    %rax,%rdi
    6879:	4c 09 e7             	or     %r12,%rdi
    687c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6882:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6888:	4c 89 f6             	mov    %r14,%rsi
    688b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6890:	e8 cb f9 ff ff       	call   6260 <f128.constprop.0>
    6895:	48 83 c4 38          	add    $0x38,%rsp
    6899:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    689e:	5b                   	pop    %rbx
    689f:	5d                   	pop    %rbp
    68a0:	41 5c                	pop    %r12
    68a2:	41 5d                	pop    %r13
    68a4:	41 5e                	pop    %r14
    68a6:	41 5f                	pop    %r15
    68a8:	c3                   	ret
    68a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b0:	f2 0f 10 3d 68 93 00 	movsd  0x9368(%rip),%xmm7        # fc20 <msg.4+0xb0>
    68b7:	00 
    68b8:	f2 0f 10 15 68 93 00 	movsd  0x9368(%rip),%xmm2        # fc28 <msg.4+0xb8>
    68bf:	00 
    68c0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    68c6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    68cc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    68d2:	e9 3b fc ff ff       	jmp    6512 <w107+0x132>
    68d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68de:	00 00 
    68e0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    68e6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68ec:	48 85 f6             	test   %rsi,%rsi
    68ef:	0f 89 8f 00 00 00    	jns    6984 <w107+0x5a4>
    68f5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    68fb:	f2 0f 10 05 1d 93 00 	movsd  0x931d(%rip),%xmm0        # fc20 <msg.4+0xb0>
    6902:	00 
    6903:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    690a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6911:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6916:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    691a:	f2 0f 59 0d 0e 93 00 	mulsd  0x930e(%rip),%xmm1        # fc30 <msg.4+0xc0>
    6921:	00 
    6922:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6926:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    692c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6932:	e9 45 ff ff ff       	jmp    687c <w107+0x49c>
    6937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    693e:	00 00 
    6940:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6947:	e9 30 ff ff ff       	jmp    687c <w107+0x49c>
    694c:	48 8d 3d 5d 8f 00 00 	lea    0x8f5d(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    6953:	e8 98 da ff ff       	call   43f0 <fwp_trap>
    6958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    695f:	00 
    6960:	48 8d 3d 00 88 00 00 	lea    0x8800(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6967:	e8 84 da ff ff       	call   43f0 <fwp_trap>
    696c:	48 8d 3d d9 87 00 00 	lea    0x87d9(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    6973:	e8 78 da ff ff       	call   43f0 <fwp_trap>
    6978:	48 8d 3d 79 8f 00 00 	lea    0x8f79(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    697f:	e8 6c da ff ff       	call   43f0 <fwp_trap>
    6984:	f2 0f 10 35 94 92 00 	movsd  0x9294(%rip),%xmm6        # fc20 <msg.4+0xb0>
    698b:	00 
    698c:	49 89 f5             	mov    %rsi,%r13
    698f:	49 89 f6             	mov    %rsi,%r14
    6992:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6999:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    69a0:	00 00 
    69a2:	49 c1 fd 20          	sar    $0x20,%r13
    69a6:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    69ac:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    69b2:	e9 45 fb ff ff       	jmp    64fc <w107+0x11c>
    69b7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    69bd:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    69c2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    69c9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    69cd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    69d1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    69d7:	e9 8a fc ff ff       	jmp    6666 <w107+0x286>
    69dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000069e0 <fwp_data.part.0.constprop.0>:
    69e0:	41 56                	push   %r14
    69e2:	41 89 fe             	mov    %edi,%r14d
    69e5:	41 54                	push   %r12
    69e7:	49 89 f4             	mov    %rsi,%r12
    69ea:	55                   	push   %rbp
    69eb:	53                   	push   %rbx
    69ec:	48 83 ec 08          	sub    $0x8,%rsp
    69f0:	8b 05 8e e1 01 00    	mov    0x1e18e(%rip),%eax        # 24b84 <fwp_heap+0x13a4>
    69f6:	85 c0                	test   %eax,%eax
    69f8:	0f 84 fa 00 00 00    	je     6af8 <fwp_data.part.0.constprop.0+0x118>
    69fe:	0f b6 05 7d dd 01 00 	movzbl 0x1dd7d(%rip),%eax        # 24782 <fwp_heap+0xfa2>
    6a05:	48 8d 15 d4 cd 01 00 	lea    0x1cdd4(%rip),%rdx        # 237e0 <fwp_heap>
    6a0c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6a13:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6a17:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6a1b:	48 8b 18             	mov    (%rax),%rbx
    6a1e:	48 85 db             	test   %rbx,%rbx
    6a21:	0f 84 a9 00 00 00    	je     6ad0 <fwp_data.part.0.constprop.0+0xf0>
    6a27:	48 8b 13             	mov    (%rbx),%rdx
    6a2a:	48 f7 d2             	not    %rdx
    6a2d:	48 89 10             	mov    %rdx,(%rax)
    6a30:	48 83 fd 18          	cmp    $0x18,%rbp
    6a34:	76 1b                	jbe    6a51 <fwp_data.part.0.constprop.0+0x71>
    6a36:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6a3a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6a3e:	31 f6                	xor    %esi,%esi
    6a40:	48 c1 e8 03          	shr    $0x3,%rax
    6a44:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6a4b:	00 
    6a4c:	e8 6f ca ff ff       	call   34c0 <memset@plt>
    6a51:	48 89 e8             	mov    %rbp,%rax
    6a54:	48 03 05 a5 e1 01 00 	add    0x1e1a5(%rip),%rax        # 24c00 <fwp_heap+0x1420>
    6a5b:	0f 82 a8 00 00 00    	jb     6b09 <fwp_data.part.0.constprop.0+0x129>
    6a61:	48 39 05 a0 e1 01 00 	cmp    %rax,0x1e1a0(%rip)        # 24c08 <fwp_heap+0x1428>
    6a68:	48 89 05 91 e1 01 00 	mov    %rax,0x1e191(%rip)        # 24c00 <fwp_heap+0x1420>
    6a6f:	73 07                	jae    6a78 <fwp_data.part.0.constprop.0+0x98>
    6a71:	48 89 05 90 e1 01 00 	mov    %rax,0x1e190(%rip)        # 24c08 <fwp_heap+0x1428>
    6a78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a7c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6a81:	f2 0f 58 05 8f e1 01 	addsd  0x1e18f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    6a88:	00 
    6a89:	f2 0f 11 05 87 e1 01 	movsd  %xmm0,0x1e187(%rip)        # 24c18 <fwp_heap+0x1438>
    6a90:	00 
    6a91:	b8 02 00 00 00       	mov    $0x2,%eax
    6a96:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6a9b:	66 0f 6e c8          	movd   %eax,%xmm1
    6a9f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6aa3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6aa7:	49 8b 04 24          	mov    (%r12),%rax
    6aab:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6aaf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6ab4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6ab8:	48 83 c4 08          	add    $0x8,%rsp
    6abc:	48 89 d8             	mov    %rbx,%rax
    6abf:	5b                   	pop    %rbx
    6ac0:	5d                   	pop    %rbp
    6ac1:	41 5c                	pop    %r12
    6ac3:	41 5e                	pop    %r14
    6ac5:	c3                   	ret
    6ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6acd:	00 00 00 
    6ad0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6ad4:	48 85 db             	test   %rbx,%rbx
    6ad7:	74 1f                	je     6af8 <fwp_data.part.0.constprop.0+0x118>
    6ad9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6add:	48 29 da             	sub    %rbx,%rdx
    6ae0:	48 39 ea             	cmp    %rbp,%rdx
    6ae3:	72 13                	jb     6af8 <fwp_data.part.0.constprop.0+0x118>
    6ae5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ae9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6aed:	e9 3e ff ff ff       	jmp    6a30 <fwp_data.part.0.constprop.0+0x50>
    6af2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af8:	31 f6                	xor    %esi,%esi
    6afa:	bf 18 00 00 00       	mov    $0x18,%edi
    6aff:	e8 8c f1 ff ff       	call   5c90 <fwp_heap_alloc>
    6b04:	48 89 c3             	mov    %rax,%rbx
    6b07:	eb 88                	jmp    6a91 <fwp_data.part.0.constprop.0+0xb1>
    6b09:	e8 a2 d1 ff ff       	call   3cb0 <fwp_heap_oom>
    6b0e:	66 90                	xchg   %ax,%ax

0000000000006b10 <fwp_rc_share>:
    6b10:	48 8b 05 a1 e0 01 00 	mov    0x1e0a1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6b17:	48 2b 3d 72 e0 01 00 	sub    0x1e072(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    6b1e:	48 c1 e0 10          	shl    $0x10,%rax
    6b22:	48 39 c7             	cmp    %rax,%rdi
    6b25:	73 4a                	jae    6b71 <fwp_rc_share+0x61>
    6b27:	48 89 f8             	mov    %rdi,%rax
    6b2a:	48 c1 e8 10          	shr    $0x10,%rax
    6b2e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b32:	48 8b 05 9f e0 01 00 	mov    0x1e09f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6b39:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6b3d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6b41:	48 85 d2             	test   %rdx,%rdx
    6b44:	74 2b                	je     6b71 <fwp_rc_share+0x61>
    6b46:	0f b6 08             	movzbl (%rax),%ecx
    6b49:	80 f9 02             	cmp    $0x2,%cl
    6b4c:	74 2a                	je     6b78 <fwp_rc_share+0x68>
    6b4e:	80 f9 01             	cmp    $0x1,%cl
    6b51:	75 1e                	jne    6b71 <fwp_rc_share+0x61>
    6b53:	8b 48 18             	mov    0x18(%rax),%ecx
    6b56:	0f b7 ff             	movzwl %di,%edi
    6b59:	8b 40 1c             	mov    0x1c(%rax),%eax
    6b5c:	48 0f af f9          	imul   %rcx,%rdi
    6b60:	48 c1 ef 20          	shr    $0x20,%rdi
    6b64:	48 39 c7             	cmp    %rax,%rdi
    6b67:	73 08                	jae    6b71 <fwp_rc_share+0x61>
    6b69:	48 01 fa             	add    %rdi,%rdx
    6b6c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b6f:	75 0d                	jne    6b7e <fwp_rc_share+0x6e>
    6b71:	c3                   	ret
    6b72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b78:	66 85 ff             	test   %di,%di
    6b7b:	74 ef                	je     6b6c <fwp_rc_share+0x5c>
    6b7d:	c3                   	ret
    6b7e:	50                   	push   %rax
    6b7f:	48 8d 3d a2 8d 00 00 	lea    0x8da2(%rip),%rdi        # f928 <_IO_stdin_used+0x928>
    6b86:	e8 65 d8 ff ff       	call   43f0 <fwp_trap>
    6b8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006b90 <fwp_rc_fresh>:
    6b90:	48 8b 15 21 e0 01 00 	mov    0x1e021(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6b97:	48 89 f8             	mov    %rdi,%rax
    6b9a:	48 89 fe             	mov    %rdi,%rsi
    6b9d:	48 2b 05 ec df 01 00 	sub    0x1dfec(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6ba4:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba8:	48 39 d0             	cmp    %rdx,%rax
    6bab:	73 4f                	jae    6bfc <fwp_rc_fresh+0x6c>
    6bad:	48 89 c2             	mov    %rax,%rdx
    6bb0:	48 c1 ea 10          	shr    $0x10,%rdx
    6bb4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bb8:	48 8b 15 19 e0 01 00 	mov    0x1e019(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6bbf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bc3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bc7:	48 85 d2             	test   %rdx,%rdx
    6bca:	74 30                	je     6bfc <fwp_rc_fresh+0x6c>
    6bcc:	0f b6 39             	movzbl (%rcx),%edi
    6bcf:	40 80 ff 02          	cmp    $0x2,%dil
    6bd3:	74 2b                	je     6c00 <fwp_rc_fresh+0x70>
    6bd5:	40 80 ff 01          	cmp    $0x1,%dil
    6bd9:	75 21                	jne    6bfc <fwp_rc_fresh+0x6c>
    6bdb:	8b 79 18             	mov    0x18(%rcx),%edi
    6bde:	0f b7 c0             	movzwl %ax,%eax
    6be1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6be4:	48 0f af c7          	imul   %rdi,%rax
    6be8:	48 c1 e8 20          	shr    $0x20,%rax
    6bec:	48 39 c8             	cmp    %rcx,%rax
    6bef:	73 0b                	jae    6bfc <fwp_rc_fresh+0x6c>
    6bf1:	48 01 c2             	add    %rax,%rdx
    6bf4:	80 3a ff             	cmpb   $0xff,(%rdx)
    6bf7:	74 17                	je     6c10 <fwp_rc_fresh+0x80>
    6bf9:	c6 02 01             	movb   $0x1,(%rdx)
    6bfc:	48 89 f0             	mov    %rsi,%rax
    6bff:	c3                   	ret
    6c00:	66 85 c0             	test   %ax,%ax
    6c03:	74 ef                	je     6bf4 <fwp_rc_fresh+0x64>
    6c05:	48 89 f0             	mov    %rsi,%rax
    6c08:	c3                   	ret
    6c09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c10:	48 83 ec 18          	sub    $0x18,%rsp
    6c14:	48 89 d7             	mov    %rdx,%rdi
    6c17:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6c1c:	48 89 14 24          	mov    %rdx,(%rsp)
    6c20:	e8 2b e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6c25:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6c2a:	48 8b 14 24          	mov    (%rsp),%rdx
    6c2e:	48 89 f0             	mov    %rsi,%rax
    6c31:	c6 02 01             	movb   $0x1,(%rdx)
    6c34:	48 83 c4 18          	add    $0x18,%rsp
    6c38:	c3                   	ret
    6c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006c40 <fwp_rc_free_arr>:
    6c40:	48 8b 15 71 df 01 00 	mov    0x1df71(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6c47:	48 89 f8             	mov    %rdi,%rax
    6c4a:	48 2b 05 3f df 01 00 	sub    0x1df3f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6c51:	48 c1 e2 10          	shl    $0x10,%rdx
    6c55:	48 39 d0             	cmp    %rdx,%rax
    6c58:	73 5b                	jae    6cb5 <fwp_rc_free_arr+0x75>
    6c5a:	48 89 c2             	mov    %rax,%rdx
    6c5d:	48 c1 ea 10          	shr    $0x10,%rdx
    6c61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c65:	48 8b 15 6c df 01 00 	mov    0x1df6c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6c6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6c70:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6c74:	48 85 c9             	test   %rcx,%rcx
    6c77:	74 3c                	je     6cb5 <fwp_rc_free_arr+0x75>
    6c79:	0f b6 32             	movzbl (%rdx),%esi
    6c7c:	40 80 fe 02          	cmp    $0x2,%sil
    6c80:	74 2e                	je     6cb0 <fwp_rc_free_arr+0x70>
    6c82:	40 80 fe 01          	cmp    $0x1,%sil
    6c86:	75 2d                	jne    6cb5 <fwp_rc_free_arr+0x75>
    6c88:	8b 72 18             	mov    0x18(%rdx),%esi
    6c8b:	0f b7 c0             	movzwl %ax,%eax
    6c8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c91:	48 0f af c6          	imul   %rsi,%rax
    6c95:	48 c1 e8 20          	shr    $0x20,%rax
    6c99:	48 39 d0             	cmp    %rdx,%rax
    6c9c:	73 17                	jae    6cb5 <fwp_rc_free_arr+0x75>
    6c9e:	48 01 c1             	add    %rax,%rcx
    6ca1:	80 39 01             	cmpb   $0x1,(%rcx)
    6ca4:	75 0f                	jne    6cb5 <fwp_rc_free_arr+0x75>
    6ca6:	e9 e5 ea ff ff       	jmp    5790 <fwp_mem_free>
    6cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6cb0:	66 85 c0             	test   %ax,%ax
    6cb3:	74 ec                	je     6ca1 <fwp_rc_free_arr+0x61>
    6cb5:	c3                   	ret
    6cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cbd:	00 00 00 

0000000000006cc0 <fwp_rc_dup>:
    6cc0:	f3 0f 1e fa          	endbr64
    6cc4:	48 8b 05 ed de 01 00 	mov    0x1deed(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    6ccb:	48 2b 3d be de 01 00 	sub    0x1debe(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    6cd2:	48 c1 e0 10          	shl    $0x10,%rax
    6cd6:	48 39 c7             	cmp    %rax,%rdi
    6cd9:	73 56                	jae    6d31 <fwp_rc_dup+0x71>
    6cdb:	48 89 f8             	mov    %rdi,%rax
    6cde:	48 c1 e8 10          	shr    $0x10,%rax
    6ce2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ce6:	48 8b 05 eb de 01 00 	mov    0x1deeb(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    6ced:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6cf1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6cf5:	48 85 c0             	test   %rax,%rax
    6cf8:	74 37                	je     6d31 <fwp_rc_dup+0x71>
    6cfa:	0f b6 0a             	movzbl (%rdx),%ecx
    6cfd:	80 f9 02             	cmp    $0x2,%cl
    6d00:	74 36                	je     6d38 <fwp_rc_dup+0x78>
    6d02:	80 f9 01             	cmp    $0x1,%cl
    6d05:	75 2a                	jne    6d31 <fwp_rc_dup+0x71>
    6d07:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6d0a:	0f b7 ff             	movzwl %di,%edi
    6d0d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6d10:	48 0f af f9          	imul   %rcx,%rdi
    6d14:	48 c1 ef 20          	shr    $0x20,%rdi
    6d18:	48 39 d7             	cmp    %rdx,%rdi
    6d1b:	73 14                	jae    6d31 <fwp_rc_dup+0x71>
    6d1d:	48 01 f8             	add    %rdi,%rax
    6d20:	0f b6 10             	movzbl (%rax),%edx
    6d23:	84 d2                	test   %dl,%dl
    6d25:	74 0a                	je     6d31 <fwp_rc_dup+0x71>
    6d27:	80 fa fd             	cmp    $0xfd,%dl
    6d2a:	77 14                	ja     6d40 <fwp_rc_dup+0x80>
    6d2c:	83 c2 01             	add    $0x1,%edx
    6d2f:	88 10                	mov    %dl,(%rax)
    6d31:	c3                   	ret
    6d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d38:	66 85 ff             	test   %di,%di
    6d3b:	74 e3                	je     6d20 <fwp_rc_dup+0x60>
    6d3d:	c3                   	ret
    6d3e:	66 90                	xchg   %ax,%ax
    6d40:	48 89 c7             	mov    %rax,%rdi
    6d43:	e9 e8 e6 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6d48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6d4f:	00 

0000000000006d50 <fwp_owned_entry161>:
    6d50:	f3 0f 1e fa          	endbr64
    6d54:	48 83 ec 38          	sub    $0x38,%rsp
    6d58:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6d5d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6d64:	00 00 
    6d66:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6d6b:	31 c0                	xor    %eax,%eax
    6d6d:	48 8b 07             	mov    (%rdi),%rax
    6d70:	48 03 47 10          	add    0x10(%rdi),%rax
    6d74:	0f 80 c2 00 00 00    	jo     6e3c <fwp_owned_entry161+0xec>
    6d7a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6d7f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6d84:	31 ff                	xor    %edi,%edi
    6d86:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6d8a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6d8f:	e8 4c fc ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    6d94:	48 8b 15 1d de 01 00 	mov    0x1de1d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6d9b:	48 89 c6             	mov    %rax,%rsi
    6d9e:	48 2b 05 eb dd 01 00 	sub    0x1ddeb(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6da5:	48 c1 e2 10          	shl    $0x10,%rdx
    6da9:	48 39 d0             	cmp    %rdx,%rax
    6dac:	73 4f                	jae    6dfd <fwp_owned_entry161+0xad>
    6dae:	48 89 c2             	mov    %rax,%rdx
    6db1:	48 c1 ea 10          	shr    $0x10,%rdx
    6db5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6db9:	48 8b 15 18 de 01 00 	mov    0x1de18(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6dc0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6dc4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6dc8:	48 85 d2             	test   %rdx,%rdx
    6dcb:	74 30                	je     6dfd <fwp_owned_entry161+0xad>
    6dcd:	0f b6 39             	movzbl (%rcx),%edi
    6dd0:	40 80 ff 02          	cmp    $0x2,%dil
    6dd4:	74 42                	je     6e18 <fwp_owned_entry161+0xc8>
    6dd6:	40 80 ff 01          	cmp    $0x1,%dil
    6dda:	75 21                	jne    6dfd <fwp_owned_entry161+0xad>
    6ddc:	8b 79 18             	mov    0x18(%rcx),%edi
    6ddf:	0f b7 c0             	movzwl %ax,%eax
    6de2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6de5:	48 0f af c7          	imul   %rdi,%rax
    6de9:	48 c1 e8 20          	shr    $0x20,%rax
    6ded:	48 39 c8             	cmp    %rcx,%rax
    6df0:	73 0b                	jae    6dfd <fwp_owned_entry161+0xad>
    6df2:	48 01 c2             	add    %rax,%rdx
    6df5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6df8:	74 26                	je     6e20 <fwp_owned_entry161+0xd0>
    6dfa:	c6 02 01             	movb   $0x1,(%rdx)
    6dfd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6e02:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e09:	00 00 
    6e0b:	75 34                	jne    6e41 <fwp_owned_entry161+0xf1>
    6e0d:	48 89 f0             	mov    %rsi,%rax
    6e10:	48 83 c4 38          	add    $0x38,%rsp
    6e14:	c3                   	ret
    6e15:	0f 1f 00             	nopl   (%rax)
    6e18:	66 85 c0             	test   %ax,%ax
    6e1b:	75 e0                	jne    6dfd <fwp_owned_entry161+0xad>
    6e1d:	eb d6                	jmp    6df5 <fwp_owned_entry161+0xa5>
    6e1f:	90                   	nop
    6e20:	48 89 d7             	mov    %rdx,%rdi
    6e23:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6e28:	48 89 14 24          	mov    %rdx,(%rsp)
    6e2c:	e8 1f e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e31:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6e36:	48 8b 14 24          	mov    (%rsp),%rdx
    6e3a:	eb be                	jmp    6dfa <fwp_owned_entry161+0xaa>
    6e3c:	e8 bf c8 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6e41:	e8 1a c6 ff ff       	call   3460 <__stack_chk_fail@plt>
    6e46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e4d:	00 00 00 

0000000000006e50 <e161>:
    6e50:	f3 0f 1e fa          	endbr64
    6e54:	53                   	push   %rbx
    6e55:	48 83 ec 30          	sub    $0x30,%rsp
    6e59:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6e5e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e65:	00 00 
    6e67:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6e6c:	31 c0                	xor    %eax,%eax
    6e6e:	48 8b 07             	mov    (%rdi),%rax
    6e71:	48 03 47 10          	add    0x10(%rdi),%rax
    6e75:	0f 80 c9 00 00 00    	jo     6f44 <e161+0xf4>
    6e7b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6e80:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6e85:	31 ff                	xor    %edi,%edi
    6e87:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6e8b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6e90:	e8 4b fb ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    6e95:	48 8b 15 1c dd 01 00 	mov    0x1dd1c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6e9c:	48 89 c3             	mov    %rax,%rbx
    6e9f:	48 2b 05 ea dc 01 00 	sub    0x1dcea(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6ea6:	48 c1 e2 10          	shl    $0x10,%rdx
    6eaa:	48 39 d0             	cmp    %rdx,%rax
    6ead:	73 4f                	jae    6efe <e161+0xae>
    6eaf:	48 89 c2             	mov    %rax,%rdx
    6eb2:	48 c1 ea 10          	shr    $0x10,%rdx
    6eb6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6eba:	48 8b 15 17 dd 01 00 	mov    0x1dd17(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    6ec1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ec5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ec9:	48 85 d2             	test   %rdx,%rdx
    6ecc:	74 30                	je     6efe <e161+0xae>
    6ece:	0f b6 31             	movzbl (%rcx),%esi
    6ed1:	40 80 fe 02          	cmp    $0x2,%sil
    6ed5:	74 49                	je     6f20 <e161+0xd0>
    6ed7:	40 80 fe 01          	cmp    $0x1,%sil
    6edb:	75 21                	jne    6efe <e161+0xae>
    6edd:	8b 71 18             	mov    0x18(%rcx),%esi
    6ee0:	0f b7 c0             	movzwl %ax,%eax
    6ee3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ee6:	48 0f af c6          	imul   %rsi,%rax
    6eea:	48 c1 e8 20          	shr    $0x20,%rax
    6eee:	48 39 c8             	cmp    %rcx,%rax
    6ef1:	73 0b                	jae    6efe <e161+0xae>
    6ef3:	48 01 c2             	add    %rax,%rdx
    6ef6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ef9:	74 35                	je     6f30 <e161+0xe0>
    6efb:	c6 02 01             	movb   $0x1,(%rdx)
    6efe:	48 89 df             	mov    %rbx,%rdi
    6f01:	e8 0a fc ff ff       	call   6b10 <fwp_rc_share>
    6f06:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6f0b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f12:	00 00 
    6f14:	75 33                	jne    6f49 <e161+0xf9>
    6f16:	48 83 c4 30          	add    $0x30,%rsp
    6f1a:	48 89 d8             	mov    %rbx,%rax
    6f1d:	5b                   	pop    %rbx
    6f1e:	c3                   	ret
    6f1f:	90                   	nop
    6f20:	66 85 c0             	test   %ax,%ax
    6f23:	75 d9                	jne    6efe <e161+0xae>
    6f25:	eb cf                	jmp    6ef6 <e161+0xa6>
    6f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f2e:	00 00 
    6f30:	48 89 d7             	mov    %rdx,%rdi
    6f33:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f38:	e8 13 e6 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f3d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f42:	eb b7                	jmp    6efb <e161+0xab>
    6f44:	e8 b7 c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6f49:	e8 12 c5 ff ff       	call   3460 <__stack_chk_fail@plt>
    6f4e:	66 90                	xchg   %ax,%ax

0000000000006f50 <fwp_drop0>:
    6f50:	f3 0f 1e fa          	endbr64
    6f54:	48 8b 15 5d dc 01 00 	mov    0x1dc5d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    6f5b:	48 89 f8             	mov    %rdi,%rax
    6f5e:	48 2b 05 2b dc 01 00 	sub    0x1dc2b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    6f65:	48 c1 e2 10          	shl    $0x10,%rdx
    6f69:	48 39 d0             	cmp    %rdx,%rax
    6f6c:	0f 83 be 00 00 00    	jae    7030 <fwp_drop0+0xe0>
    6f72:	48 83 ec 18          	sub    $0x18,%rsp
    6f76:	4c 8d 05 63 c8 01 00 	lea    0x1c863(%rip),%r8        # 237e0 <fwp_heap>
    6f7d:	48 89 c2             	mov    %rax,%rdx
    6f80:	48 c1 ea 10          	shr    $0x10,%rdx
    6f84:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f88:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6f8f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f93:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f97:	48 85 d2             	test   %rdx,%rdx
    6f9a:	74 3c                	je     6fd8 <fwp_drop0+0x88>
    6f9c:	0f b6 31             	movzbl (%rcx),%esi
    6f9f:	40 80 fe 02          	cmp    $0x2,%sil
    6fa3:	74 3b                	je     6fe0 <fwp_drop0+0x90>
    6fa5:	40 80 fe 01          	cmp    $0x1,%sil
    6fa9:	75 2d                	jne    6fd8 <fwp_drop0+0x88>
    6fab:	8b 71 18             	mov    0x18(%rcx),%esi
    6fae:	0f b7 c0             	movzwl %ax,%eax
    6fb1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fb4:	48 0f af c6          	imul   %rsi,%rax
    6fb8:	48 c1 e8 20          	shr    $0x20,%rax
    6fbc:	48 39 c8             	cmp    %rcx,%rax
    6fbf:	73 17                	jae    6fd8 <fwp_drop0+0x88>
    6fc1:	48 01 c2             	add    %rax,%rdx
    6fc4:	0f b6 02             	movzbl (%rdx),%eax
    6fc7:	84 c0                	test   %al,%al
    6fc9:	74 0d                	je     6fd8 <fwp_drop0+0x88>
    6fcb:	3c 01                	cmp    $0x1,%al
    6fcd:	74 21                	je     6ff0 <fwp_drop0+0xa0>
    6fcf:	3c ff                	cmp    $0xff,%al
    6fd1:	74 65                	je     7038 <fwp_drop0+0xe8>
    6fd3:	83 e8 01             	sub    $0x1,%eax
    6fd6:	88 02                	mov    %al,(%rdx)
    6fd8:	48 83 c4 18          	add    $0x18,%rsp
    6fdc:	c3                   	ret
    6fdd:	0f 1f 00             	nopl   (%rax)
    6fe0:	66 85 c0             	test   %ax,%ax
    6fe3:	74 df                	je     6fc4 <fwp_drop0+0x74>
    6fe5:	48 83 c4 18          	add    $0x18,%rsp
    6fe9:	c3                   	ret
    6fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ff0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6ff4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ff9:	e8 42 fc ff ff       	call   6c40 <fwp_rc_free_arr>
    6ffe:	4c 8d 05 db c7 01 00 	lea    0x1c7db(%rip),%r8        # 237e0 <fwp_heap>
    7005:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    700a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7011:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7018:	48 c1 e2 10          	shl    $0x10,%rdx
    701c:	48 39 d0             	cmp    %rdx,%rax
    701f:	73 b7                	jae    6fd8 <fwp_drop0+0x88>
    7021:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7026:	e9 52 ff ff ff       	jmp    6f7d <fwp_drop0+0x2d>
    702b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7030:	c3                   	ret
    7031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7038:	48 89 d0             	mov    %rdx,%rax
    703b:	48 c1 e8 11          	shr    $0x11,%rax
    703f:	48 31 d0             	xor    %rdx,%rax
    7042:	48 89 c1             	mov    %rax,%rcx
    7045:	48 c1 e9 09          	shr    $0x9,%rcx
    7049:	48 31 c8             	xor    %rcx,%rax
    704c:	0f b6 c8             	movzbl %al,%ecx
    704f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7056:	00 
    7057:	48 85 c0             	test   %rax,%rax
    705a:	75 0d                	jne    7069 <fwp_drop0+0x119>
    705c:	eb 46                	jmp    70a4 <fwp_drop0+0x154>
    705e:	66 90                	xchg   %ax,%ax
    7060:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7064:	48 85 c0             	test   %rax,%rax
    7067:	74 3b                	je     70a4 <fwp_drop0+0x154>
    7069:	48 89 c1             	mov    %rax,%rcx
    706c:	48 39 10             	cmp    %rdx,(%rax)
    706f:	75 ef                	jne    7060 <fwp_drop0+0x110>
    7071:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7075:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7079:	48 89 48 08          	mov    %rcx,0x8(%rax)
    707d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7084:	0f 85 4e ff ff ff    	jne    6fd8 <fwp_drop0+0x88>
    708a:	48 89 d7             	mov    %rdx,%rdi
    708d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7092:	e8 b9 e4 ff ff       	call   5550 <fwp_rc_forget_slot>
    7097:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    709c:	c6 02 fe             	movb   $0xfe,(%rdx)
    709f:	e9 34 ff ff ff       	jmp    6fd8 <fwp_drop0+0x88>
    70a4:	48 8d 3d dd 87 00 00 	lea    0x87dd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    70ab:	e8 40 d3 ff ff       	call   43f0 <fwp_trap>

00000000000070b0 <fwp_arg_drop12>:
    70b0:	f3 0f 1e fa          	endbr64
    70b4:	85 f6                	test   %esi,%esi
    70b6:	75 04                	jne    70bc <fwp_arg_drop12+0xc>
    70b8:	85 d2                	test   %edx,%edx
    70ba:	75 04                	jne    70c0 <fwp_arg_drop12+0x10>
    70bc:	c3                   	ret
    70bd:	0f 1f 00             	nopl   (%rax)
    70c0:	48 8b 3f             	mov    (%rdi),%rdi
    70c3:	e9 88 fe ff ff       	jmp    6f50 <fwp_drop0>
    70c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70cf:	00 

00000000000070d0 <fwp_drop1>:
    70d0:	f3 0f 1e fa          	endbr64
    70d4:	48 8b 15 dd da 01 00 	mov    0x1dadd(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    70db:	48 89 f8             	mov    %rdi,%rax
    70de:	48 2b 05 ab da 01 00 	sub    0x1daab(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    70e5:	48 c1 e2 10          	shl    $0x10,%rdx
    70e9:	48 39 d0             	cmp    %rdx,%rax
    70ec:	0f 83 be 00 00 00    	jae    71b0 <fwp_drop1+0xe0>
    70f2:	48 83 ec 18          	sub    $0x18,%rsp
    70f6:	4c 8d 05 e3 c6 01 00 	lea    0x1c6e3(%rip),%r8        # 237e0 <fwp_heap>
    70fd:	48 89 c2             	mov    %rax,%rdx
    7100:	48 c1 ea 10          	shr    $0x10,%rdx
    7104:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7108:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    710f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7113:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7117:	48 85 d2             	test   %rdx,%rdx
    711a:	74 3c                	je     7158 <fwp_drop1+0x88>
    711c:	0f b6 31             	movzbl (%rcx),%esi
    711f:	40 80 fe 02          	cmp    $0x2,%sil
    7123:	74 3b                	je     7160 <fwp_drop1+0x90>
    7125:	40 80 fe 01          	cmp    $0x1,%sil
    7129:	75 2d                	jne    7158 <fwp_drop1+0x88>
    712b:	8b 71 18             	mov    0x18(%rcx),%esi
    712e:	0f b7 c0             	movzwl %ax,%eax
    7131:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7134:	48 0f af c6          	imul   %rsi,%rax
    7138:	48 c1 e8 20          	shr    $0x20,%rax
    713c:	48 39 c8             	cmp    %rcx,%rax
    713f:	73 17                	jae    7158 <fwp_drop1+0x88>
    7141:	48 01 c2             	add    %rax,%rdx
    7144:	0f b6 02             	movzbl (%rdx),%eax
    7147:	84 c0                	test   %al,%al
    7149:	74 0d                	je     7158 <fwp_drop1+0x88>
    714b:	3c 01                	cmp    $0x1,%al
    714d:	74 21                	je     7170 <fwp_drop1+0xa0>
    714f:	3c ff                	cmp    $0xff,%al
    7151:	74 65                	je     71b8 <fwp_drop1+0xe8>
    7153:	83 e8 01             	sub    $0x1,%eax
    7156:	88 02                	mov    %al,(%rdx)
    7158:	48 83 c4 18          	add    $0x18,%rsp
    715c:	c3                   	ret
    715d:	0f 1f 00             	nopl   (%rax)
    7160:	66 85 c0             	test   %ax,%ax
    7163:	74 df                	je     7144 <fwp_drop1+0x74>
    7165:	48 83 c4 18          	add    $0x18,%rsp
    7169:	c3                   	ret
    716a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7170:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7174:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7179:	e8 c2 fa ff ff       	call   6c40 <fwp_rc_free_arr>
    717e:	4c 8d 05 5b c6 01 00 	lea    0x1c65b(%rip),%r8        # 237e0 <fwp_heap>
    7185:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    718a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7191:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7198:	48 c1 e2 10          	shl    $0x10,%rdx
    719c:	48 39 d0             	cmp    %rdx,%rax
    719f:	73 b7                	jae    7158 <fwp_drop1+0x88>
    71a1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    71a6:	e9 52 ff ff ff       	jmp    70fd <fwp_drop1+0x2d>
    71ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    71b0:	c3                   	ret
    71b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71b8:	48 89 d0             	mov    %rdx,%rax
    71bb:	48 c1 e8 11          	shr    $0x11,%rax
    71bf:	48 31 d0             	xor    %rdx,%rax
    71c2:	48 89 c1             	mov    %rax,%rcx
    71c5:	48 c1 e9 09          	shr    $0x9,%rcx
    71c9:	48 31 c8             	xor    %rcx,%rax
    71cc:	0f b6 c8             	movzbl %al,%ecx
    71cf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    71d6:	00 
    71d7:	48 85 c0             	test   %rax,%rax
    71da:	75 0d                	jne    71e9 <fwp_drop1+0x119>
    71dc:	eb 46                	jmp    7224 <fwp_drop1+0x154>
    71de:	66 90                	xchg   %ax,%ax
    71e0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    71e4:	48 85 c0             	test   %rax,%rax
    71e7:	74 3b                	je     7224 <fwp_drop1+0x154>
    71e9:	48 89 c1             	mov    %rax,%rcx
    71ec:	48 39 10             	cmp    %rdx,(%rax)
    71ef:	75 ef                	jne    71e0 <fwp_drop1+0x110>
    71f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71f5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    71f9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    71fd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7204:	0f 85 4e ff ff ff    	jne    7158 <fwp_drop1+0x88>
    720a:	48 89 d7             	mov    %rdx,%rdi
    720d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7212:	e8 39 e3 ff ff       	call   5550 <fwp_rc_forget_slot>
    7217:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    721c:	c6 02 fe             	movb   $0xfe,(%rdx)
    721f:	e9 34 ff ff ff       	jmp    7158 <fwp_drop1+0x88>
    7224:	48 8d 3d 5d 86 00 00 	lea    0x865d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    722b:	e8 c0 d1 ff ff       	call   43f0 <fwp_trap>

0000000000007230 <fwp_closure_drop>:
    7230:	48 8b 15 81 d9 01 00 	mov    0x1d981(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7237:	48 89 f8             	mov    %rdi,%rax
    723a:	48 2b 05 4f d9 01 00 	sub    0x1d94f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7241:	48 c1 e2 10          	shl    $0x10,%rdx
    7245:	48 39 d0             	cmp    %rdx,%rax
    7248:	73 6b                	jae    72b5 <fwp_closure_drop+0x85>
    724a:	48 89 c2             	mov    %rax,%rdx
    724d:	48 c1 ea 10          	shr    $0x10,%rdx
    7251:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7255:	48 8b 15 7c d9 01 00 	mov    0x1d97c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    725c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7260:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7264:	48 85 d2             	test   %rdx,%rdx
    7267:	74 4c                	je     72b5 <fwp_closure_drop+0x85>
    7269:	0f b6 31             	movzbl (%rcx),%esi
    726c:	40 80 fe 02          	cmp    $0x2,%sil
    7270:	74 3e                	je     72b0 <fwp_closure_drop+0x80>
    7272:	40 80 fe 01          	cmp    $0x1,%sil
    7276:	75 3d                	jne    72b5 <fwp_closure_drop+0x85>
    7278:	8b 71 18             	mov    0x18(%rcx),%esi
    727b:	0f b7 c0             	movzwl %ax,%eax
    727e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7281:	48 0f af c6          	imul   %rsi,%rax
    7285:	48 c1 e8 20          	shr    $0x20,%rax
    7289:	48 39 c8             	cmp    %rcx,%rax
    728c:	73 27                	jae    72b5 <fwp_closure_drop+0x85>
    728e:	48 01 c2             	add    %rax,%rdx
    7291:	0f b6 02             	movzbl (%rdx),%eax
    7294:	84 c0                	test   %al,%al
    7296:	74 1d                	je     72b5 <fwp_closure_drop+0x85>
    7298:	3c 01                	cmp    $0x1,%al
    729a:	74 24                	je     72c0 <fwp_closure_drop+0x90>
    729c:	3c ff                	cmp    $0xff,%al
    729e:	74 48                	je     72e8 <fwp_closure_drop+0xb8>
    72a0:	83 e8 01             	sub    $0x1,%eax
    72a3:	88 02                	mov    %al,(%rdx)
    72a5:	c3                   	ret
    72a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72ad:	00 00 00 
    72b0:	66 85 c0             	test   %ax,%ax
    72b3:	74 dc                	je     7291 <fwp_closure_drop+0x61>
    72b5:	c3                   	ret
    72b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72bd:	00 00 00 
    72c0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    72c7:	ff ff 
    72c9:	48 85 c0             	test   %rax,%rax
    72cc:	74 12                	je     72e0 <fwp_closure_drop+0xb0>
    72ce:	48 89 fe             	mov    %rdi,%rsi
    72d1:	48 89 c7             	mov    %rax,%rdi
    72d4:	e9 77 d1 ff ff       	jmp    4450 <fwp_closure_drop_push>
    72d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72e0:	e9 1b d3 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    72e5:	0f 1f 00             	nopl   (%rax)
    72e8:	48 89 d0             	mov    %rdx,%rax
    72eb:	48 8d 35 ee c4 01 00 	lea    0x1c4ee(%rip),%rsi        # 237e0 <fwp_heap>
    72f2:	48 83 ec 18          	sub    $0x18,%rsp
    72f6:	48 c1 e8 11          	shr    $0x11,%rax
    72fa:	48 31 d0             	xor    %rdx,%rax
    72fd:	48 89 c1             	mov    %rax,%rcx
    7300:	48 c1 e9 09          	shr    $0x9,%rcx
    7304:	48 31 c8             	xor    %rcx,%rax
    7307:	0f b6 c8             	movzbl %al,%ecx
    730a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7311:	00 
    7312:	48 85 c0             	test   %rax,%rax
    7315:	75 12                	jne    7329 <fwp_closure_drop+0xf9>
    7317:	eb 49                	jmp    7362 <fwp_closure_drop+0x132>
    7319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7320:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7324:	48 85 c0             	test   %rax,%rax
    7327:	74 39                	je     7362 <fwp_closure_drop+0x132>
    7329:	48 89 c1             	mov    %rax,%rcx
    732c:	48 39 10             	cmp    %rdx,(%rax)
    732f:	75 ef                	jne    7320 <fwp_closure_drop+0xf0>
    7331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7335:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7339:	48 89 48 08          	mov    %rcx,0x8(%rax)
    733d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7344:	74 05                	je     734b <fwp_closure_drop+0x11b>
    7346:	48 83 c4 18          	add    $0x18,%rsp
    734a:	c3                   	ret
    734b:	48 89 d7             	mov    %rdx,%rdi
    734e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7353:	e8 f8 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    7358:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    735d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7360:	eb e4                	jmp    7346 <fwp_closure_drop+0x116>
    7362:	48 8d 3d 1f 85 00 00 	lea    0x851f(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7369:	e8 82 d0 ff ff       	call   43f0 <fwp_trap>
    736e:	66 90                	xchg   %ax,%ax

0000000000007370 <fwp_owned_tape_release>:
    7370:	48 85 ff             	test   %rdi,%rdi
    7373:	0f 84 f7 00 00 00    	je     7470 <fwp_owned_tape_release+0x100>
    7379:	41 54                	push   %r12
    737b:	55                   	push   %rbp
    737c:	53                   	push   %rbx
    737d:	48 8b 07             	mov    (%rdi),%rax
    7380:	48 85 c0             	test   %rax,%rax
    7383:	74 08                	je     738d <fwp_owned_tape_release+0x1d>
    7385:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7389:	48 89 50 08          	mov    %rdx,0x8(%rax)
    738d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7391:	48 85 d2             	test   %rdx,%rdx
    7394:	74 03                	je     7399 <fwp_owned_tape_release+0x29>
    7396:	48 89 02             	mov    %rax,(%rdx)
    7399:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    739d:	48 89 fb             	mov    %rdi,%rbx
    73a0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    73a4:	48 85 c0             	test   %rax,%rax
    73a7:	0f 84 89 00 00 00    	je     7436 <fwp_owned_tape_release+0xc6>
    73ad:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    73b1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    73b5:	7e 47                	jle    73fe <fwp_owned_tape_release+0x8e>
    73b7:	31 ed                	xor    %ebp,%ebp
    73b9:	eb 0d                	jmp    73c8 <fwp_owned_tape_release+0x58>
    73bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    73c0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    73c4:	48 8b 40 68          	mov    0x68(%rax),%rax
    73c8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    73cc:	49 89 ec             	mov    %rbp,%r12
    73cf:	48 83 c5 01          	add    $0x1,%rbp
    73d3:	49 c1 e4 04          	shl    $0x4,%r12
    73d7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    73db:	ff d0                	call   *%rax
    73dd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    73e1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    73e6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    73ea:	ff 50 68             	call   *0x68(%rax)
    73ed:	48 8b 43 58          	mov    0x58(%rbx),%rax
    73f1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    73f5:	48 39 e8             	cmp    %rbp,%rax
    73f8:	7f c6                	jg     73c0 <fwp_owned_tape_release+0x50>
    73fa:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    73fe:	31 ed                	xor    %ebp,%ebp
    7400:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7405:	7e 28                	jle    742f <fwp_owned_tape_release+0xbf>
    7407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    740e:	00 00 
    7410:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7414:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7418:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    741c:	74 07                	je     7425 <fwp_owned_tape_release+0xb5>
    741e:	ff 52 68             	call   *0x68(%rdx)
    7421:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7425:	48 83 c5 01          	add    $0x1,%rbp
    7429:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    742d:	7f e1                	jg     7410 <fwp_owned_tape_release+0xa0>
    742f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7433:	ff 52 68             	call   *0x68(%rdx)
    7436:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    743a:	e8 f1 fd ff ff       	call   7230 <fwp_closure_drop>
    743f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7443:	e8 e8 fd ff ff       	call   7230 <fwp_closure_drop>
    7448:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    744c:	e8 df fd ff ff       	call   7230 <fwp_closure_drop>
    7451:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7455:	e8 36 e3 ff ff       	call   5790 <fwp_mem_free>
    745a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    745e:	e8 2d e3 ff ff       	call   5790 <fwp_mem_free>
    7463:	48 89 df             	mov    %rbx,%rdi
    7466:	5b                   	pop    %rbx
    7467:	5d                   	pop    %rbp
    7468:	41 5c                	pop    %r12
    746a:	e9 21 e3 ff ff       	jmp    5790 <fwp_mem_free>
    746f:	90                   	nop
    7470:	c3                   	ret
    7471:	0f 1f 40 00          	nopl   0x0(%rax)
    7475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    747c:	00 00 00 00 

0000000000007480 <fwp_tape_finish>:
    7480:	f3 0f 1e fa          	endbr64
    7484:	41 56                	push   %r14
    7486:	48 8d 3d 33 bc 01 00 	lea    0x1bc33(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    748d:	41 55                	push   %r13
    748f:	41 54                	push   %r12
    7491:	55                   	push   %rbp
    7492:	53                   	push   %rbx
    7493:	e8 78 cc ff ff       	call   4110 <fwp_tape_buffers_dispose>
    7498:	48 83 3d 68 bc 01 00 	cmpq   $0x0,0x1bc68(%rip)        # 23108 <fwp_ntapes>
    749f:	00 
    74a0:	48 c7 05 fd bb 01 00 	movq   $0x0,0x1bbfd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    74a7:	00 00 00 00 
    74ab:	7e 68                	jle    7515 <fwp_tape_finish+0x95>
    74ad:	45 31 e4             	xor    %r12d,%r12d
    74b0:	31 ed                	xor    %ebp,%ebp
    74b2:	0f 1f 00             	nopl   (%rax)
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 1d 49 bc 01 00 	mov    0x1bc49(%rip),%rbx        # 23110 <fwp_tapes>
    74c7:	48 83 c5 01          	add    $0x1,%rbp
    74cb:	4c 01 e3             	add    %r12,%rbx
    74ce:	49 83 c4 68          	add    $0x68,%r12
    74d2:	48 89 df             	mov    %rbx,%rdi
    74d5:	e8 26 c7 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    74da:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    74de:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    74e2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    74e6:	e8 d5 be ff ff       	call   33c0 <free@plt>
    74eb:	4c 89 f7             	mov    %r14,%rdi
    74ee:	e8 cd be ff ff       	call   33c0 <free@plt>
    74f3:	4c 89 ef             	mov    %r13,%rdi
    74f6:	e8 c5 be ff ff       	call   33c0 <free@plt>
    74fb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    74ff:	e8 6c fe ff ff       	call   7370 <fwp_owned_tape_release>
    7504:	48 39 2d fd bb 01 00 	cmp    %rbp,0x1bbfd(%rip)        # 23108 <fwp_ntapes>
    750b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7512:	00 
    7513:	7f ab                	jg     74c0 <fwp_tape_finish+0x40>
    7515:	48 8b 3d f4 bb 01 00 	mov    0x1bbf4(%rip),%rdi        # 23110 <fwp_tapes>
    751c:	e8 9f be ff ff       	call   33c0 <free@plt>
    7521:	5b                   	pop    %rbx
    7522:	5d                   	pop    %rbp
    7523:	48 c7 05 e2 bb 01 00 	movq   $0x0,0x1bbe2(%rip)        # 23110 <fwp_tapes>
    752a:	00 00 00 00 
    752e:	48 c7 05 c7 bb 01 00 	movq   $0x0,0x1bbc7(%rip)        # 23100 <fwp_tapes_cap>
    7535:	00 00 00 00 
    7539:	41 5c                	pop    %r12
    753b:	48 c7 05 c2 bb 01 00 	movq   $0x0,0x1bbc2(%rip)        # 23108 <fwp_ntapes>
    7542:	00 00 00 00 
    7546:	41 5d                	pop    %r13
    7548:	48 c7 05 a5 bb 01 00 	movq   $0x0,0x1bba5(%rip)        # 230f8 <fwp_tape_next_slot>
    754f:	00 00 00 00 
    7553:	41 5e                	pop    %r14
    7555:	c3                   	ret
    7556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    755d:	00 00 00 

0000000000007560 <fwp_tape_scope_release>:
    7560:	f3 0f 1e fa          	endbr64
    7564:	41 55                	push   %r13
    7566:	41 54                	push   %r12
    7568:	55                   	push   %rbp
    7569:	53                   	push   %rbx
    756a:	48 83 ec 58          	sub    $0x58,%rsp
    756e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7575:	00 00 
    7577:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    757c:	48 63 07             	movslq (%rdi),%rax
    757f:	85 c0                	test   %eax,%eax
    7581:	0f 88 05 01 00 00    	js     768c <fwp_tape_scope_release+0x12c>
    7587:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    758e:	ec c4 4e 
    7591:	48 89 fb             	mov    %rdi,%rbx
    7594:	eb 3c                	jmp    75d2 <fwp_tape_scope_release+0x72>
    7596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    759d:	00 00 00 
    75a0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    75a5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    75a9:	e8 12 be ff ff       	call   33c0 <free@plt>
    75ae:	48 8b 3c 24          	mov    (%rsp),%rdi
    75b2:	e8 09 be ff ff       	call   33c0 <free@plt>
    75b7:	4c 89 ef             	mov    %r13,%rdi
    75ba:	e8 01 be ff ff       	call   33c0 <free@plt>
    75bf:	4c 89 e7             	mov    %r12,%rdi
    75c2:	e8 a9 fd ff ff       	call   7370 <fwp_owned_tape_release>
    75c7:	48 63 03             	movslq (%rbx),%rax
    75ca:	85 c0                	test   %eax,%eax
    75cc:	0f 88 ba 00 00 00    	js     768c <fwp_tape_scope_release+0x12c>
    75d2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    75d6:	48 8b 35 33 bb 01 00 	mov    0x1bb33(%rip),%rsi        # 23110 <fwp_tapes>
    75dd:	4c 01 c6             	add    %r8,%rsi
    75e0:	48 89 f7             	mov    %rsi,%rdi
    75e3:	e8 18 c6 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    75e8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    75ed:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    75f2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    75f9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    75fd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7601:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7608:	00 
    7609:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    760e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7612:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7617:	66 0f ef d2          	pxor   %xmm2,%xmm2
    761b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7620:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7627:	00 
    7628:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    762f:	00 
    7630:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7637:	00 
    7638:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    763d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7642:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7646:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    764a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    764e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7654:	77 18                	ja     766e <fwp_tape_scope_release+0x10e>
    7656:	49 c1 f8 03          	sar    $0x3,%r8
    765a:	4c 0f af c5          	imul   %rbp,%r8
    765e:	4c 3b 05 93 ba 01 00 	cmp    0x1ba93(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    7665:	7d 07                	jge    766e <fwp_tape_scope_release+0x10e>
    7667:	4c 89 05 8a ba 01 00 	mov    %r8,0x1ba8a(%rip)        # 230f8 <fwp_tape_next_slot>
    766e:	4d 85 e4             	test   %r12,%r12
    7671:	0f 85 29 ff ff ff    	jne    75a0 <fwp_tape_scope_release+0x40>
    7677:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    767c:	e8 ef d9 ff ff       	call   5070 <fwp_tape_buffers_release>
    7681:	48 63 03             	movslq (%rbx),%rax
    7684:	85 c0                	test   %eax,%eax
    7686:	0f 89 46 ff ff ff    	jns    75d2 <fwp_tape_scope_release+0x72>
    768c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7691:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7698:	00 00 
    769a:	75 0b                	jne    76a7 <fwp_tape_scope_release+0x147>
    769c:	48 83 c4 58          	add    $0x58,%rsp
    76a0:	5b                   	pop    %rbx
    76a1:	5d                   	pop    %rbp
    76a2:	41 5c                	pop    %r12
    76a4:	41 5d                	pop    %r13
    76a6:	c3                   	ret
    76a7:	e8 b4 bd ff ff       	call   3460 <__stack_chk_fail@plt>
    76ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000076b0 <fwp_task_dispose>:
    76b0:	53                   	push   %rbx
    76b1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    76b5:	0f 84 8b c0 ff ff    	je     3746 <fwp_task_dispose.cold>
    76bb:	48 89 fb             	mov    %rdi,%rbx
    76be:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    76c3:	0f 85 7d c0 ff ff    	jne    3746 <fwp_task_dispose.cold>
    76c9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    76cd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    76d4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    76db:	00 
    76dc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    76e0:	48 85 ff             	test   %rdi,%rdi
    76e3:	74 07                	je     76ec <fwp_task_dispose+0x3c>
    76e5:	48 85 c0             	test   %rax,%rax
    76e8:	74 02                	je     76ec <fwp_task_dispose+0x3c>
    76ea:	ff d0                	call   *%rax
    76ec:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    76f3:	e8 98 e0 ff ff       	call   5790 <fwp_mem_free>
    76f8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    76ff:	00 00 00 00 
    7703:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7707:	74 6f                	je     7778 <fwp_task_dispose+0xc8>
    7709:	48 8b 15 a8 d4 01 00 	mov    0x1d4a8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7710:	48 89 d8             	mov    %rbx,%rax
    7713:	48 2b 05 76 d4 01 00 	sub    0x1d476(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    771a:	48 c1 e2 10          	shl    $0x10,%rdx
    771e:	48 39 d0             	cmp    %rdx,%rax
    7721:	73 4c                	jae    776f <fwp_task_dispose+0xbf>
    7723:	48 89 c2             	mov    %rax,%rdx
    7726:	48 c1 ea 10          	shr    $0x10,%rdx
    772a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    772e:	48 8b 15 a3 d4 01 00 	mov    0x1d4a3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7735:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7739:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    773d:	48 85 c9             	test   %rcx,%rcx
    7740:	74 2d                	je     776f <fwp_task_dispose+0xbf>
    7742:	0f b6 32             	movzbl (%rdx),%esi
    7745:	40 80 fe 02          	cmp    $0x2,%sil
    7749:	74 3d                	je     7788 <fwp_task_dispose+0xd8>
    774b:	40 80 fe 01          	cmp    $0x1,%sil
    774f:	75 1e                	jne    776f <fwp_task_dispose+0xbf>
    7751:	8b 72 18             	mov    0x18(%rdx),%esi
    7754:	0f b7 c0             	movzwl %ax,%eax
    7757:	8b 52 1c             	mov    0x1c(%rdx),%edx
    775a:	48 0f af c6          	imul   %rsi,%rax
    775e:	48 c1 e8 20          	shr    $0x20,%rax
    7762:	48 39 d0             	cmp    %rdx,%rax
    7765:	73 08                	jae    776f <fwp_task_dispose+0xbf>
    7767:	48 01 c1             	add    %rax,%rcx
    776a:	80 39 01             	cmpb   $0x1,(%rcx)
    776d:	74 09                	je     7778 <fwp_task_dispose+0xc8>
    776f:	5b                   	pop    %rbx
    7770:	c3                   	ret
    7771:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7778:	48 89 df             	mov    %rbx,%rdi
    777b:	5b                   	pop    %rbx
    777c:	e9 0f e0 ff ff       	jmp    5790 <fwp_mem_free>
    7781:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7788:	66 85 c0             	test   %ax,%ax
    778b:	74 dd                	je     776a <fwp_task_dispose+0xba>
    778d:	5b                   	pop    %rbx
    778e:	c3                   	ret
    778f:	90                   	nop

0000000000007790 <fwp_free_zombie>:
    7790:	48 8b 15 19 c0 01 00 	mov    0x1c019(%rip),%rdx        # 237b0 <fwp_zombie>
    7797:	48 85 d2             	test   %rdx,%rdx
    779a:	0f 84 98 00 00 00    	je     7838 <fwp_free_zombie+0xa8>
    77a0:	48 3b 15 19 c0 01 00 	cmp    0x1c019(%rip),%rdx        # 237c0 <fwp_cur>
    77a7:	0f 84 8b 00 00 00    	je     7838 <fwp_free_zombie+0xa8>
    77ad:	48 83 ec 18          	sub    $0x18,%rsp
    77b1:	48 63 05 cc b9 01 00 	movslq 0x1b9cc(%rip),%rax        # 23184 <fwp_stack_pool_n>
    77b8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    77bc:	83 f8 3f             	cmp    $0x3f,%eax
    77bf:	7f 7f                	jg     7840 <fwp_free_zombie+0xb0>
    77c1:	8d 48 01             	lea    0x1(%rax),%ecx
    77c4:	89 0d ba b9 01 00    	mov    %ecx,0x1b9ba(%rip)        # 23184 <fwp_stack_pool_n>
    77ca:	48 8d 0d cf b9 01 00 	lea    0x1b9cf(%rip),%rcx        # 231a0 <fwp_stack_pool>
    77d1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    77d5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    77dc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    77e0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    77e7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    77eb:	48 85 c9             	test   %rcx,%rcx
    77ee:	0f 84 fc 00 00 00    	je     78f0 <fwp_free_zombie+0x160>
    77f4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    77fb:	48 85 c0             	test   %rax,%rax
    77fe:	74 07                	je     7807 <fwp_free_zombie+0x77>
    7800:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7807:	8b 42 5c             	mov    0x5c(%rdx),%eax
    780a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    780e:	48 c7 05 97 bf 01 00 	movq   $0x0,0x1bf97(%rip)        # 237b0 <fwp_zombie>
    7815:	00 00 00 00 
    7819:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7820:	85 c0                	test   %eax,%eax
    7822:	74 34                	je     7858 <fwp_free_zombie+0xc8>
    7824:	83 f8 01             	cmp    $0x1,%eax
    7827:	0f 84 b3 00 00 00    	je     78e0 <fwp_free_zombie+0x150>
    782d:	48 83 c4 18          	add    $0x18,%rsp
    7831:	c3                   	ret
    7832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7838:	c3                   	ret
    7839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7840:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7844:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7849:	e8 92 bd ff ff       	call   35e0 <munmap@plt>
    784e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7853:	eb 80                	jmp    77d5 <fwp_free_zombie+0x45>
    7855:	0f 1f 00             	nopl   (%rax)
    7858:	48 8b 0d 59 d3 01 00 	mov    0x1d359(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    785f:	48 89 d0             	mov    %rdx,%rax
    7862:	48 2b 05 27 d3 01 00 	sub    0x1d327(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7869:	48 c1 e1 10          	shl    $0x10,%rcx
    786d:	48 39 c8             	cmp    %rcx,%rax
    7870:	73 bb                	jae    782d <fwp_free_zombie+0x9d>
    7872:	48 89 c1             	mov    %rax,%rcx
    7875:	48 c1 e9 10          	shr    $0x10,%rcx
    7879:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    787d:	48 8b 0d 54 d3 01 00 	mov    0x1d354(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7884:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7888:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    788c:	48 85 c9             	test   %rcx,%rcx
    788f:	74 9c                	je     782d <fwp_free_zombie+0x9d>
    7891:	0f b6 3e             	movzbl (%rsi),%edi
    7894:	40 80 ff 02          	cmp    $0x2,%dil
    7898:	74 66                	je     7900 <fwp_free_zombie+0x170>
    789a:	40 80 ff 01          	cmp    $0x1,%dil
    789e:	75 8d                	jne    782d <fwp_free_zombie+0x9d>
    78a0:	8b 7e 18             	mov    0x18(%rsi),%edi
    78a3:	0f b7 c0             	movzwl %ax,%eax
    78a6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    78a9:	48 0f af c7          	imul   %rdi,%rax
    78ad:	48 c1 e8 20          	shr    $0x20,%rax
    78b1:	48 39 f0             	cmp    %rsi,%rax
    78b4:	0f 83 73 ff ff ff    	jae    782d <fwp_free_zombie+0x9d>
    78ba:	48 01 c1             	add    %rax,%rcx
    78bd:	0f b6 01             	movzbl (%rcx),%eax
    78c0:	84 c0                	test   %al,%al
    78c2:	0f 84 65 ff ff ff    	je     782d <fwp_free_zombie+0x9d>
    78c8:	3c 01                	cmp    $0x1,%al
    78ca:	74 14                	je     78e0 <fwp_free_zombie+0x150>
    78cc:	3c ff                	cmp    $0xff,%al
    78ce:	74 3b                	je     790b <fwp_free_zombie+0x17b>
    78d0:	83 e8 01             	sub    $0x1,%eax
    78d3:	88 01                	mov    %al,(%rcx)
    78d5:	e9 53 ff ff ff       	jmp    782d <fwp_free_zombie+0x9d>
    78da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78e0:	48 89 d7             	mov    %rdx,%rdi
    78e3:	48 83 c4 18          	add    $0x18,%rsp
    78e7:	e9 c4 fd ff ff       	jmp    76b0 <fwp_task_dispose>
    78ec:	0f 1f 40 00          	nopl   0x0(%rax)
    78f0:	48 89 05 91 be 01 00 	mov    %rax,0x1be91(%rip)        # 23788 <fwp_tasks_active>
    78f7:	e9 ff fe ff ff       	jmp    77fb <fwp_free_zombie+0x6b>
    78fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7900:	66 85 c0             	test   %ax,%ax
    7903:	0f 85 24 ff ff ff    	jne    782d <fwp_free_zombie+0x9d>
    7909:	eb b2                	jmp    78bd <fwp_free_zombie+0x12d>
    790b:	48 89 ca             	mov    %rcx,%rdx
    790e:	48 8d 35 cb be 01 00 	lea    0x1becb(%rip),%rsi        # 237e0 <fwp_heap>
    7915:	48 c1 ea 11          	shr    $0x11,%rdx
    7919:	48 31 ca             	xor    %rcx,%rdx
    791c:	48 89 d0             	mov    %rdx,%rax
    791f:	48 c1 e8 09          	shr    $0x9,%rax
    7923:	48 31 c2             	xor    %rax,%rdx
    7926:	0f b6 d2             	movzbl %dl,%edx
    7929:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7930:	00 
    7931:	48 85 c0             	test   %rax,%rax
    7934:	75 13                	jne    7949 <fwp_free_zombie+0x1b9>
    7936:	eb 4c                	jmp    7984 <fwp_free_zombie+0x1f4>
    7938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    793f:	00 
    7940:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7944:	48 85 c0             	test   %rax,%rax
    7947:	74 3b                	je     7984 <fwp_free_zombie+0x1f4>
    7949:	48 89 c2             	mov    %rax,%rdx
    794c:	48 39 08             	cmp    %rcx,(%rax)
    794f:	75 ef                	jne    7940 <fwp_free_zombie+0x1b0>
    7951:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7955:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7959:	48 89 50 08          	mov    %rdx,0x8(%rax)
    795d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7964:	0f 85 c3 fe ff ff    	jne    782d <fwp_free_zombie+0x9d>
    796a:	48 89 cf             	mov    %rcx,%rdi
    796d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7972:	e8 d9 db ff ff       	call   5550 <fwp_rc_forget_slot>
    7977:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    797c:	c6 01 fe             	movb   $0xfe,(%rcx)
    797f:	e9 a9 fe ff ff       	jmp    782d <fwp_free_zombie+0x9d>
    7984:	48 8d 3d fd 7e 00 00 	lea    0x7efd(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    798b:	e8 60 ca ff ff       	call   43f0 <fwp_trap>

0000000000007990 <fwp_block>:
    7990:	48 83 ec 08          	sub    $0x8,%rsp
    7994:	48 8b 05 0d be 01 00 	mov    0x1be0d(%rip),%rax        # 237a8 <fwp_ready_head>
    799b:	48 85 c0             	test   %rax,%rax
    799e:	0f 84 1c 01 00 00    	je     7ac0 <fwp_block+0x130>
    79a4:	90                   	nop
    79a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    79ac:	00 00 00 00 
    79b0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    79b7:	48 89 15 ea bd 01 00 	mov    %rdx,0x1bdea(%rip)        # 237a8 <fwp_ready_head>
    79be:	48 85 d2             	test   %rdx,%rdx
    79c1:	0f 84 19 01 00 00    	je     7ae0 <fwp_block+0x150>
    79c7:	48 8b 15 f2 bd 01 00 	mov    0x1bdf2(%rip),%rdx        # 237c0 <fwp_cur>
    79ce:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    79d2:	48 39 c2             	cmp    %rax,%rdx
    79d5:	0f 84 d5 00 00 00    	je     7ab0 <fwp_block+0x120>
    79db:	48 8b 0d 66 da 01 00 	mov    0x1da66(%rip),%rcx        # 25448 <fwp_state_owners>
    79e2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    79e6:	48 89 05 d3 bd 01 00 	mov    %rax,0x1bdd3(%rip)        # 237c0 <fwp_cur>
    79ed:	f3 0f 7e 05 7b da 01 	movq   0x1da7b(%rip),%xmm0        # 25470 <fwp_foreign_callbacks>
    79f4:	00 
    79f5:	0f 16 05 64 da 01 00 	movhps 0x1da64(%rip),%xmm0        # 25460 <fwp_state>
    79fc:	f3 0f 7e 0d 64 da 01 	movq   0x1da64(%rip),%xmm1        # 25468 <fwp_handlers>
    7a03:	00 
    7a04:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7a0b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7a12:	0f 16 0d 5f da 01 00 	movhps 0x1da5f(%rip),%xmm1        # 25478 <fwp_cleanups>
    7a19:	f3 0f 7e 05 37 da 01 	movq   0x1da37(%rip),%xmm0        # 25458 <fwp_state_len>
    7a20:	00 
    7a21:	0f 16 05 28 da 01 00 	movhps 0x1da28(%rip),%xmm0        # 25450 <fwp_state_cap>
    7a28:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7a2f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7a36:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7a3a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7a41:	48 89 0d 20 da 01 00 	mov    %rcx,0x1da20(%rip)        # 25468 <fwp_handlers>
    7a48:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7a4f:	48 89 0d 22 da 01 00 	mov    %rcx,0x1da22(%rip)        # 25478 <fwp_cleanups>
    7a56:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7a5d:	48 89 0d 0c da 01 00 	mov    %rcx,0x1da0c(%rip)        # 25470 <fwp_foreign_callbacks>
    7a64:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7a6b:	48 89 0d ee d9 01 00 	mov    %rcx,0x1d9ee(%rip)        # 25460 <fwp_state>
    7a72:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7a79:	48 89 0d d8 d9 01 00 	mov    %rcx,0x1d9d8(%rip)        # 25458 <fwp_state_len>
    7a80:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7a87:	48 89 0d c2 d9 01 00 	mov    %rcx,0x1d9c2(%rip)        # 25450 <fwp_state_cap>
    7a8e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7a95:	48 89 0d ac d9 01 00 	mov    %rcx,0x1d9ac(%rip)        # 25448 <fwp_state_owners>
    7a9c:	e8 ef b9 ff ff       	call   3490 <swapcontext@plt>
    7aa1:	f3 0f 1e fa          	endbr64
    7aa5:	e8 e6 fc ff ff       	call   7790 <fwp_free_zombie>
    7aaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ab0:	8b 05 ca b6 01 00    	mov    0x1b6ca(%rip),%eax        # 23180 <fwp_slice>
    7ab6:	85 c0                	test   %eax,%eax
    7ab8:	74 36                	je     7af0 <fwp_block+0x160>
    7aba:	48 83 c4 08          	add    $0x8,%rsp
    7abe:	c3                   	ret
    7abf:	90                   	nop
    7ac0:	e8 db d6 ff ff       	call   51a0 <fwp_poll_events>
    7ac5:	48 8b 05 dc bc 01 00 	mov    0x1bcdc(%rip),%rax        # 237a8 <fwp_ready_head>
    7acc:	48 85 c0             	test   %rax,%rax
    7acf:	0f 85 db fe ff ff    	jne    79b0 <fwp_block+0x20>
    7ad5:	eb e9                	jmp    7ac0 <fwp_block+0x130>
    7ad7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ade:	00 00 
    7ae0:	48 c7 05 b5 bc 01 00 	movq   $0x0,0x1bcb5(%rip)        # 237a0 <fwp_ready_tail>
    7ae7:	00 00 00 00 
    7aeb:	e9 d7 fe ff ff       	jmp    79c7 <fwp_block+0x37>
    7af0:	48 8d 3d 8d 76 00 00 	lea    0x768d(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    7af7:	e8 a4 b8 ff ff       	call   33a0 <getenv@plt>
    7afc:	ba 10 27 00 00       	mov    $0x2710,%edx
    7b01:	48 85 c0             	test   %rax,%rax
    7b04:	74 05                	je     7b0b <fwp_block+0x17b>
    7b06:	80 38 00             	cmpb   $0x0,(%rax)
    7b09:	75 0b                	jne    7b16 <fwp_block+0x186>
    7b0b:	89 15 6f b6 01 00    	mov    %edx,0x1b66f(%rip)        # 23180 <fwp_slice>
    7b11:	48 83 c4 08          	add    $0x8,%rsp
    7b15:	c3                   	ret
    7b16:	ba 0a 00 00 00       	mov    $0xa,%edx
    7b1b:	31 f6                	xor    %esi,%esi
    7b1d:	48 89 c7             	mov    %rax,%rdi
    7b20:	e8 2b ba ff ff       	call   3550 <strtoll@plt>
    7b25:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7b29:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7b30:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7b35:	0f 46 d0             	cmovbe %eax,%edx
    7b38:	eb d1                	jmp    7b0b <fwp_block+0x17b>
    7b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007b40 <fwp_drop4>:
    7b40:	48 8b 15 71 d0 01 00 	mov    0x1d071(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7b47:	48 89 f8             	mov    %rdi,%rax
    7b4a:	48 2b 05 3f d0 01 00 	sub    0x1d03f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7b51:	48 c1 e2 10          	shl    $0x10,%rdx
    7b55:	48 39 d0             	cmp    %rdx,%rax
    7b58:	0f 83 52 01 00 00    	jae    7cb0 <fwp_drop4+0x170>
    7b5e:	48 83 ec 18          	sub    $0x18,%rsp
    7b62:	4c 8d 05 77 bc 01 00 	lea    0x1bc77(%rip),%r8        # 237e0 <fwp_heap>
    7b69:	48 89 c2             	mov    %rax,%rdx
    7b6c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7b73:	48 c1 ea 10          	shr    $0x10,%rdx
    7b77:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7b7b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7b7f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7b83:	48 85 d2             	test   %rdx,%rdx
    7b86:	74 46                	je     7bce <fwp_drop4+0x8e>
    7b88:	44 0f b6 09          	movzbl (%rcx),%r9d
    7b8c:	41 80 f9 02          	cmp    $0x2,%r9b
    7b90:	0f 84 ca 00 00 00    	je     7c60 <fwp_drop4+0x120>
    7b96:	41 80 f9 01          	cmp    $0x1,%r9b
    7b9a:	75 32                	jne    7bce <fwp_drop4+0x8e>
    7b9c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7ba0:	0f b7 c0             	movzwl %ax,%eax
    7ba3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ba6:	49 0f af c1          	imul   %r9,%rax
    7baa:	48 c1 e8 20          	shr    $0x20,%rax
    7bae:	48 39 c8             	cmp    %rcx,%rax
    7bb1:	73 1b                	jae    7bce <fwp_drop4+0x8e>
    7bb3:	48 01 c2             	add    %rax,%rdx
    7bb6:	0f b6 02             	movzbl (%rdx),%eax
    7bb9:	84 c0                	test   %al,%al
    7bbb:	74 11                	je     7bce <fwp_drop4+0x8e>
    7bbd:	3c 01                	cmp    $0x1,%al
    7bbf:	74 17                	je     7bd8 <fwp_drop4+0x98>
    7bc1:	3c ff                	cmp    $0xff,%al
    7bc3:	0f 84 ef 00 00 00    	je     7cb8 <fwp_drop4+0x178>
    7bc9:	83 e8 01             	sub    $0x1,%eax
    7bcc:	88 02                	mov    %al,(%rdx)
    7bce:	48 83 c4 18          	add    $0x18,%rsp
    7bd2:	c3                   	ret
    7bd3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7bd8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7bdc:	0f 88 8e 00 00 00    	js     7c70 <fwp_drop4+0x130>
    7be2:	48 8b 15 cf cf 01 00 	mov    0x1cfcf(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7be9:	48 89 f8             	mov    %rdi,%rax
    7bec:	48 2b 05 9d cf 01 00 	sub    0x1cf9d(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7bf3:	48 c1 e2 10          	shl    $0x10,%rdx
    7bf7:	48 39 d0             	cmp    %rdx,%rax
    7bfa:	73 d2                	jae    7bce <fwp_drop4+0x8e>
    7bfc:	48 89 c2             	mov    %rax,%rdx
    7bff:	48 c1 ea 10          	shr    $0x10,%rdx
    7c03:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7c07:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7c0b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7c0f:	48 85 c9             	test   %rcx,%rcx
    7c12:	74 ba                	je     7bce <fwp_drop4+0x8e>
    7c14:	0f b6 32             	movzbl (%rdx),%esi
    7c17:	40 80 fe 02          	cmp    $0x2,%sil
    7c1b:	74 33                	je     7c50 <fwp_drop4+0x110>
    7c1d:	40 80 fe 01          	cmp    $0x1,%sil
    7c21:	75 ab                	jne    7bce <fwp_drop4+0x8e>
    7c23:	8b 72 18             	mov    0x18(%rdx),%esi
    7c26:	0f b7 c0             	movzwl %ax,%eax
    7c29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c2c:	48 0f af c6          	imul   %rsi,%rax
    7c30:	48 c1 e8 20          	shr    $0x20,%rax
    7c34:	48 39 d0             	cmp    %rdx,%rax
    7c37:	73 95                	jae    7bce <fwp_drop4+0x8e>
    7c39:	48 01 c1             	add    %rax,%rcx
    7c3c:	80 39 01             	cmpb   $0x1,(%rcx)
    7c3f:	75 8d                	jne    7bce <fwp_drop4+0x8e>
    7c41:	48 83 c4 18          	add    $0x18,%rsp
    7c45:	e9 46 db ff ff       	jmp    5790 <fwp_mem_free>
    7c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c50:	66 85 c0             	test   %ax,%ax
    7c53:	74 e7                	je     7c3c <fwp_drop4+0xfc>
    7c55:	48 83 c4 18          	add    $0x18,%rsp
    7c59:	c3                   	ret
    7c5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c60:	66 85 c0             	test   %ax,%ax
    7c63:	0f 84 4d ff ff ff    	je     7bb6 <fwp_drop4+0x76>
    7c69:	48 83 c4 18          	add    $0x18,%rsp
    7c6d:	c3                   	ret
    7c6e:	66 90                	xchg   %ax,%ax
    7c70:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7c74:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c79:	e8 c2 ef ff ff       	call   6c40 <fwp_rc_free_arr>
    7c7e:	4c 8d 05 5b bb 01 00 	lea    0x1bb5b(%rip),%r8        # 237e0 <fwp_heap>
    7c85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7c8a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7c91:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c98:	48 c1 e2 10          	shl    $0x10,%rdx
    7c9c:	48 39 d0             	cmp    %rdx,%rax
    7c9f:	0f 83 29 ff ff ff    	jae    7bce <fwp_drop4+0x8e>
    7ca5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7caa:	e9 ba fe ff ff       	jmp    7b69 <fwp_drop4+0x29>
    7caf:	90                   	nop
    7cb0:	c3                   	ret
    7cb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cb8:	48 89 d0             	mov    %rdx,%rax
    7cbb:	48 c1 e8 11          	shr    $0x11,%rax
    7cbf:	48 31 d0             	xor    %rdx,%rax
    7cc2:	48 89 c1             	mov    %rax,%rcx
    7cc5:	48 c1 e9 09          	shr    $0x9,%rcx
    7cc9:	48 31 c8             	xor    %rcx,%rax
    7ccc:	0f b6 c8             	movzbl %al,%ecx
    7ccf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7cd6:	00 
    7cd7:	48 85 c0             	test   %rax,%rax
    7cda:	75 0d                	jne    7ce9 <fwp_drop4+0x1a9>
    7cdc:	eb 46                	jmp    7d24 <fwp_drop4+0x1e4>
    7cde:	66 90                	xchg   %ax,%ax
    7ce0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7ce4:	48 85 c0             	test   %rax,%rax
    7ce7:	74 3b                	je     7d24 <fwp_drop4+0x1e4>
    7ce9:	48 89 c1             	mov    %rax,%rcx
    7cec:	48 39 10             	cmp    %rdx,(%rax)
    7cef:	75 ef                	jne    7ce0 <fwp_drop4+0x1a0>
    7cf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7cf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7cf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7cfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d04:	0f 85 c4 fe ff ff    	jne    7bce <fwp_drop4+0x8e>
    7d0a:	48 89 d7             	mov    %rdx,%rdi
    7d0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d12:	e8 39 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7d17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d1f:	e9 aa fe ff ff       	jmp    7bce <fwp_drop4+0x8e>
    7d24:	48 8d 3d 5d 7b 00 00 	lea    0x7b5d(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    7d2b:	e8 c0 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007d30 <fwp_caps161>:
    7d30:	f3 0f 1e fa          	endbr64
    7d34:	85 f6                	test   %esi,%esi
    7d36:	74 08                	je     7d40 <fwp_caps161+0x10>
    7d38:	c3                   	ret
    7d39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d40:	48 8b 15 71 ce 01 00 	mov    0x1ce71(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7d47:	48 89 f8             	mov    %rdi,%rax
    7d4a:	48 2b 05 3f ce 01 00 	sub    0x1ce3f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7d51:	48 c1 e2 10          	shl    $0x10,%rdx
    7d55:	48 39 d0             	cmp    %rdx,%rax
    7d58:	73 de                	jae    7d38 <fwp_caps161+0x8>
    7d5a:	48 89 c2             	mov    %rax,%rdx
    7d5d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d65:	48 8b 15 6c ce 01 00 	mov    0x1ce6c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7d6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d70:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d74:	48 85 c9             	test   %rcx,%rcx
    7d77:	74 bf                	je     7d38 <fwp_caps161+0x8>
    7d79:	0f b6 32             	movzbl (%rdx),%esi
    7d7c:	40 80 fe 02          	cmp    $0x2,%sil
    7d80:	74 2e                	je     7db0 <fwp_caps161+0x80>
    7d82:	40 80 fe 01          	cmp    $0x1,%sil
    7d86:	75 b0                	jne    7d38 <fwp_caps161+0x8>
    7d88:	8b 72 18             	mov    0x18(%rdx),%esi
    7d8b:	0f b7 c0             	movzwl %ax,%eax
    7d8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d91:	48 0f af c6          	imul   %rsi,%rax
    7d95:	48 c1 e8 20          	shr    $0x20,%rax
    7d99:	48 39 d0             	cmp    %rdx,%rax
    7d9c:	73 9a                	jae    7d38 <fwp_caps161+0x8>
    7d9e:	48 01 c1             	add    %rax,%rcx
    7da1:	80 39 01             	cmpb   $0x1,(%rcx)
    7da4:	75 92                	jne    7d38 <fwp_caps161+0x8>
    7da6:	e9 e5 d9 ff ff       	jmp    5790 <fwp_mem_free>
    7dab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7db0:	66 85 c0             	test   %ax,%ax
    7db3:	74 ec                	je     7da1 <fwp_caps161+0x71>
    7db5:	c3                   	ret
    7db6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7dbd:	00 00 00 

0000000000007dc0 <fwp_args12>:
    7dc0:	f3 0f 1e fa          	endbr64
    7dc4:	85 d2                	test   %edx,%edx
    7dc6:	74 04                	je     7dcc <fwp_args12+0xc>
    7dc8:	85 f6                	test   %esi,%esi
    7dca:	74 04                	je     7dd0 <fwp_args12+0x10>
    7dcc:	c3                   	ret
    7dcd:	0f 1f 00             	nopl   (%rax)
    7dd0:	48 8b 15 e1 cd 01 00 	mov    0x1cde1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7dd7:	48 8b 07             	mov    (%rdi),%rax
    7dda:	48 2b 05 af cd 01 00 	sub    0x1cdaf(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7de1:	48 c1 e2 10          	shl    $0x10,%rdx
    7de5:	48 39 d0             	cmp    %rdx,%rax
    7de8:	73 e2                	jae    7dcc <fwp_args12+0xc>
    7dea:	48 89 c2             	mov    %rax,%rdx
    7ded:	48 c1 ea 10          	shr    $0x10,%rdx
    7df1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7df5:	48 8b 15 dc cd 01 00 	mov    0x1cddc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7dfc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e00:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e04:	48 85 ff             	test   %rdi,%rdi
    7e07:	74 c3                	je     7dcc <fwp_args12+0xc>
    7e09:	0f b6 0a             	movzbl (%rdx),%ecx
    7e0c:	80 f9 02             	cmp    $0x2,%cl
    7e0f:	74 2f                	je     7e40 <fwp_args12+0x80>
    7e11:	80 f9 01             	cmp    $0x1,%cl
    7e14:	75 b6                	jne    7dcc <fwp_args12+0xc>
    7e16:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e19:	0f b7 c0             	movzwl %ax,%eax
    7e1c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e1f:	48 0f af c1          	imul   %rcx,%rax
    7e23:	48 c1 e8 20          	shr    $0x20,%rax
    7e27:	48 39 d0             	cmp    %rdx,%rax
    7e2a:	73 a0                	jae    7dcc <fwp_args12+0xc>
    7e2c:	48 01 c7             	add    %rax,%rdi
    7e2f:	0f b6 07             	movzbl (%rdi),%eax
    7e32:	84 c0                	test   %al,%al
    7e34:	74 96                	je     7dcc <fwp_args12+0xc>
    7e36:	3c fd                	cmp    $0xfd,%al
    7e38:	77 0c                	ja     7e46 <fwp_args12+0x86>
    7e3a:	83 c0 01             	add    $0x1,%eax
    7e3d:	88 07                	mov    %al,(%rdi)
    7e3f:	c3                   	ret
    7e40:	66 85 c0             	test   %ax,%ax
    7e43:	74 ea                	je     7e2f <fwp_args12+0x6f>
    7e45:	c3                   	ret
    7e46:	e9 e5 d5 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7e4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007e50 <fwp_args23>:
    7e50:	f3 0f 1e fa          	endbr64
    7e54:	85 d2                	test   %edx,%edx
    7e56:	74 04                	je     7e5c <fwp_args23+0xc>
    7e58:	85 f6                	test   %esi,%esi
    7e5a:	74 04                	je     7e60 <fwp_args23+0x10>
    7e5c:	c3                   	ret
    7e5d:	0f 1f 00             	nopl   (%rax)
    7e60:	48 8b 15 51 cd 01 00 	mov    0x1cd51(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    7e67:	48 8b 07             	mov    (%rdi),%rax
    7e6a:	48 2b 05 1f cd 01 00 	sub    0x1cd1f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    7e71:	48 c1 e2 10          	shl    $0x10,%rdx
    7e75:	48 39 d0             	cmp    %rdx,%rax
    7e78:	73 e2                	jae    7e5c <fwp_args23+0xc>
    7e7a:	48 89 c2             	mov    %rax,%rdx
    7e7d:	48 c1 ea 10          	shr    $0x10,%rdx
    7e81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e85:	48 8b 15 4c cd 01 00 	mov    0x1cd4c(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    7e8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e90:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e94:	48 85 ff             	test   %rdi,%rdi
    7e97:	74 c3                	je     7e5c <fwp_args23+0xc>
    7e99:	0f b6 0a             	movzbl (%rdx),%ecx
    7e9c:	80 f9 02             	cmp    $0x2,%cl
    7e9f:	74 2f                	je     7ed0 <fwp_args23+0x80>
    7ea1:	80 f9 01             	cmp    $0x1,%cl
    7ea4:	75 b6                	jne    7e5c <fwp_args23+0xc>
    7ea6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ea9:	0f b7 c0             	movzwl %ax,%eax
    7eac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7eaf:	48 0f af c1          	imul   %rcx,%rax
    7eb3:	48 c1 e8 20          	shr    $0x20,%rax
    7eb7:	48 39 d0             	cmp    %rdx,%rax
    7eba:	73 a0                	jae    7e5c <fwp_args23+0xc>
    7ebc:	48 01 c7             	add    %rax,%rdi
    7ebf:	0f b6 07             	movzbl (%rdi),%eax
    7ec2:	84 c0                	test   %al,%al
    7ec4:	74 96                	je     7e5c <fwp_args23+0xc>
    7ec6:	3c fd                	cmp    $0xfd,%al
    7ec8:	77 0c                	ja     7ed6 <fwp_args23+0x86>
    7eca:	83 c0 01             	add    $0x1,%eax
    7ecd:	88 07                	mov    %al,(%rdi)
    7ecf:	c3                   	ret
    7ed0:	66 85 c0             	test   %ax,%ax
    7ed3:	74 ea                	je     7ebf <fwp_args23+0x6f>
    7ed5:	c3                   	ret
    7ed6:	e9 55 d5 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007ee0 <fwp_caps12>:
    7ee0:	f3 0f 1e fa          	endbr64
    7ee4:	48 83 ec 18          	sub    $0x18,%rsp
    7ee8:	8b 57 04             	mov    0x4(%rdi),%edx
    7eeb:	48 89 f8             	mov    %rdi,%rax
    7eee:	85 d2                	test   %edx,%edx
    7ef0:	0f 84 9a 00 00 00    	je     7f90 <fwp_caps12+0xb0>
    7ef6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7efa:	85 f6                	test   %esi,%esi
    7efc:	0f 85 9e 00 00 00    	jne    7fa0 <fwp_caps12+0xc0>
    7f02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7f07:	e8 44 f0 ff ff       	call   6f50 <fwp_drop0>
    7f0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f11:	48 8b 0d a0 cc 01 00 	mov    0x1cca0(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    7f18:	48 89 c2             	mov    %rax,%rdx
    7f1b:	48 2b 15 6e cc 01 00 	sub    0x1cc6e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    7f22:	48 c1 e1 10          	shl    $0x10,%rcx
    7f26:	48 39 ca             	cmp    %rcx,%rdx
    7f29:	73 6d                	jae    7f98 <fwp_caps12+0xb8>
    7f2b:	48 89 d1             	mov    %rdx,%rcx
    7f2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7f32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7f36:	48 8b 0d 9b cc 01 00 	mov    0x1cc9b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    7f3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7f41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f45:	48 85 f6             	test   %rsi,%rsi
    7f48:	74 4e                	je     7f98 <fwp_caps12+0xb8>
    7f4a:	0f b6 39             	movzbl (%rcx),%edi
    7f4d:	40 80 ff 02          	cmp    $0x2,%dil
    7f51:	0f 84 b9 00 00 00    	je     8010 <fwp_caps12+0x130>
    7f57:	40 80 ff 01          	cmp    $0x1,%dil
    7f5b:	75 3b                	jne    7f98 <fwp_caps12+0xb8>
    7f5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7f60:	0f b7 d2             	movzwl %dx,%edx
    7f63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f66:	48 0f af d7          	imul   %rdi,%rdx
    7f6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7f6e:	48 39 ca             	cmp    %rcx,%rdx
    7f71:	73 25                	jae    7f98 <fwp_caps12+0xb8>
    7f73:	48 01 d6             	add    %rdx,%rsi
    7f76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f79:	75 1d                	jne    7f98 <fwp_caps12+0xb8>
    7f7b:	48 89 c7             	mov    %rax,%rdi
    7f7e:	48 83 c4 18          	add    $0x18,%rsp
    7f82:	e9 09 d8 ff ff       	jmp    5790 <fwp_mem_free>
    7f87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f8e:	00 00 
    7f90:	85 f6                	test   %esi,%esi
    7f92:	0f 84 79 ff ff ff    	je     7f11 <fwp_caps12+0x31>
    7f98:	48 83 c4 18          	add    $0x18,%rsp
    7f9c:	c3                   	ret
    7f9d:	0f 1f 00             	nopl   (%rax)
    7fa0:	48 8b 05 11 cc 01 00 	mov    0x1cc11(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    7fa7:	48 2b 3d e2 cb 01 00 	sub    0x1cbe2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    7fae:	48 c1 e0 10          	shl    $0x10,%rax
    7fb2:	48 39 c7             	cmp    %rax,%rdi
    7fb5:	73 e1                	jae    7f98 <fwp_caps12+0xb8>
    7fb7:	48 89 f8             	mov    %rdi,%rax
    7fba:	48 c1 e8 10          	shr    $0x10,%rax
    7fbe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7fc2:	48 8b 05 0f cc 01 00 	mov    0x1cc0f(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    7fc9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7fcd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7fd1:	48 85 c0             	test   %rax,%rax
    7fd4:	74 c2                	je     7f98 <fwp_caps12+0xb8>
    7fd6:	0f b6 0a             	movzbl (%rdx),%ecx
    7fd9:	80 f9 02             	cmp    $0x2,%cl
    7fdc:	74 42                	je     8020 <fwp_caps12+0x140>
    7fde:	80 f9 01             	cmp    $0x1,%cl
    7fe1:	75 b5                	jne    7f98 <fwp_caps12+0xb8>
    7fe3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fe6:	0f b7 ff             	movzwl %di,%edi
    7fe9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fec:	48 0f af f9          	imul   %rcx,%rdi
    7ff0:	48 c1 ef 20          	shr    $0x20,%rdi
    7ff4:	48 39 d7             	cmp    %rdx,%rdi
    7ff7:	73 9f                	jae    7f98 <fwp_caps12+0xb8>
    7ff9:	48 01 f8             	add    %rdi,%rax
    7ffc:	0f b6 10             	movzbl (%rax),%edx
    7fff:	84 d2                	test   %dl,%dl
    8001:	74 95                	je     7f98 <fwp_caps12+0xb8>
    8003:	80 fa fd             	cmp    $0xfd,%dl
    8006:	77 23                	ja     802b <fwp_caps12+0x14b>
    8008:	83 c2 01             	add    $0x1,%edx
    800b:	88 10                	mov    %dl,(%rax)
    800d:	eb 89                	jmp    7f98 <fwp_caps12+0xb8>
    800f:	90                   	nop
    8010:	66 85 d2             	test   %dx,%dx
    8013:	0f 85 7f ff ff ff    	jne    7f98 <fwp_caps12+0xb8>
    8019:	e9 58 ff ff ff       	jmp    7f76 <fwp_caps12+0x96>
    801e:	66 90                	xchg   %ax,%ax
    8020:	66 85 ff             	test   %di,%di
    8023:	0f 85 6f ff ff ff    	jne    7f98 <fwp_caps12+0xb8>
    8029:	eb d1                	jmp    7ffc <fwp_caps12+0x11c>
    802b:	48 89 c7             	mov    %rax,%rdi
    802e:	48 83 c4 18          	add    $0x18,%rsp
    8032:	e9 f9 d3 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    8037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    803e:	00 00 

0000000000008040 <fwp_drop2>:
    8040:	48 8b 0d 71 cb 01 00 	mov    0x1cb71(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    8047:	48 89 f8             	mov    %rdi,%rax
    804a:	48 2b 05 3f cb 01 00 	sub    0x1cb3f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8051:	48 c1 e1 10          	shl    $0x10,%rcx
    8055:	48 39 c8             	cmp    %rcx,%rax
    8058:	0f 83 42 01 00 00    	jae    81a0 <fwp_drop2+0x160>
    805e:	48 83 ec 18          	sub    $0x18,%rsp
    8062:	48 89 fa             	mov    %rdi,%rdx
    8065:	4c 8d 05 74 b7 01 00 	lea    0x1b774(%rip),%r8        # 237e0 <fwp_heap>
    806c:	48 89 c1             	mov    %rax,%rcx
    806f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    8076:	48 c1 e9 10          	shr    $0x10,%rcx
    807a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    807e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    8082:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    8086:	48 85 c9             	test   %rcx,%rcx
    8089:	74 40                	je     80cb <fwp_drop2+0x8b>
    808b:	0f b6 3e             	movzbl (%rsi),%edi
    808e:	40 80 ff 02          	cmp    $0x2,%dil
    8092:	74 3c                	je     80d0 <fwp_drop2+0x90>
    8094:	40 80 ff 01          	cmp    $0x1,%dil
    8098:	75 31                	jne    80cb <fwp_drop2+0x8b>
    809a:	8b 7e 18             	mov    0x18(%rsi),%edi
    809d:	0f b7 c0             	movzwl %ax,%eax
    80a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    80a3:	48 0f af c7          	imul   %rdi,%rax
    80a7:	48 c1 e8 20          	shr    $0x20,%rax
    80ab:	48 39 f0             	cmp    %rsi,%rax
    80ae:	73 1b                	jae    80cb <fwp_drop2+0x8b>
    80b0:	48 01 c1             	add    %rax,%rcx
    80b3:	0f b6 01             	movzbl (%rcx),%eax
    80b6:	84 c0                	test   %al,%al
    80b8:	74 11                	je     80cb <fwp_drop2+0x8b>
    80ba:	3c 01                	cmp    $0x1,%al
    80bc:	74 22                	je     80e0 <fwp_drop2+0xa0>
    80be:	3c ff                	cmp    $0xff,%al
    80c0:	0f 84 0a 01 00 00    	je     81d0 <fwp_drop2+0x190>
    80c6:	83 e8 01             	sub    $0x1,%eax
    80c9:	88 01                	mov    %al,(%rcx)
    80cb:	48 83 c4 18          	add    $0x18,%rsp
    80cf:	c3                   	ret
    80d0:	66 85 c0             	test   %ax,%ax
    80d3:	74 de                	je     80b3 <fwp_drop2+0x73>
    80d5:	48 83 c4 18          	add    $0x18,%rsp
    80d9:	c3                   	ret
    80da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    80e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    80eb:	48 89 f8             	mov    %rdi,%rax
    80ee:	48 c1 e1 10          	shl    $0x10,%rcx
    80f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    80f9:	48 39 c8             	cmp    %rcx,%rax
    80fc:	73 62                	jae    8160 <fwp_drop2+0x120>
    80fe:	48 89 c1             	mov    %rax,%rcx
    8101:	48 c1 e9 10          	shr    $0x10,%rcx
    8105:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8109:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    810d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    8111:	48 85 c9             	test   %rcx,%rcx
    8114:	74 4a                	je     8160 <fwp_drop2+0x120>
    8116:	44 0f b6 0e          	movzbl (%rsi),%r9d
    811a:	41 80 f9 02          	cmp    $0x2,%r9b
    811e:	0f 84 9c 00 00 00    	je     81c0 <fwp_drop2+0x180>
    8124:	41 80 f9 01          	cmp    $0x1,%r9b
    8128:	75 36                	jne    8160 <fwp_drop2+0x120>
    812a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    812e:	0f b7 c0             	movzwl %ax,%eax
    8131:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8134:	49 0f af c1          	imul   %r9,%rax
    8138:	48 c1 e8 20          	shr    $0x20,%rax
    813c:	48 39 f0             	cmp    %rsi,%rax
    813f:	73 1f                	jae    8160 <fwp_drop2+0x120>
    8141:	48 01 c1             	add    %rax,%rcx
    8144:	0f b6 01             	movzbl (%rcx),%eax
    8147:	84 c0                	test   %al,%al
    8149:	74 15                	je     8160 <fwp_drop2+0x120>
    814b:	3c 01                	cmp    $0x1,%al
    814d:	74 59                	je     81a8 <fwp_drop2+0x168>
    814f:	3c ff                	cmp    $0xff,%al
    8151:	0f 84 ef 00 00 00    	je     8246 <fwp_drop2+0x206>
    8157:	83 e8 01             	sub    $0x1,%eax
    815a:	88 01                	mov    %al,(%rcx)
    815c:	0f 1f 40 00          	nopl   0x0(%rax)
    8160:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    8164:	48 89 d7             	mov    %rdx,%rdi
    8167:	48 89 0c 24          	mov    %rcx,(%rsp)
    816b:	e8 d0 ea ff ff       	call   6c40 <fwp_rc_free_arr>
    8170:	4c 8d 05 69 b6 01 00 	lea    0x1b669(%rip),%r8        # 237e0 <fwp_heap>
    8177:	48 8b 04 24          	mov    (%rsp),%rax
    817b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    8182:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    8189:	48 c1 e2 10          	shl    $0x10,%rdx
    818d:	48 39 d0             	cmp    %rdx,%rax
    8190:	0f 83 35 ff ff ff    	jae    80cb <fwp_drop2+0x8b>
    8196:	48 8b 14 24          	mov    (%rsp),%rdx
    819a:	e9 cd fe ff ff       	jmp    806c <fwp_drop2+0x2c>
    819f:	90                   	nop
    81a0:	c3                   	ret
    81a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    81a8:	48 89 14 24          	mov    %rdx,(%rsp)
    81ac:	e8 8f ea ff ff       	call   6c40 <fwp_rc_free_arr>
    81b1:	48 8b 14 24          	mov    (%rsp),%rdx
    81b5:	eb a9                	jmp    8160 <fwp_drop2+0x120>
    81b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    81be:	00 00 
    81c0:	66 85 c0             	test   %ax,%ax
    81c3:	75 9b                	jne    8160 <fwp_drop2+0x120>
    81c5:	e9 7a ff ff ff       	jmp    8144 <fwp_drop2+0x104>
    81ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81d0:	48 89 c8             	mov    %rcx,%rax
    81d3:	48 c1 e8 11          	shr    $0x11,%rax
    81d7:	48 31 c8             	xor    %rcx,%rax
    81da:	48 89 c2             	mov    %rax,%rdx
    81dd:	48 c1 ea 09          	shr    $0x9,%rdx
    81e1:	48 31 d0             	xor    %rdx,%rax
    81e4:	0f b6 d0             	movzbl %al,%edx
    81e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    81ee:	00 
    81ef:	48 85 c0             	test   %rax,%rax
    81f2:	75 19                	jne    820d <fwp_drop2+0x1cd>
    81f4:	e9 d3 00 00 00       	jmp    82cc <fwp_drop2+0x28c>
    81f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8200:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8204:	48 85 c0             	test   %rax,%rax
    8207:	0f 84 bf 00 00 00    	je     82cc <fwp_drop2+0x28c>
    820d:	48 89 c2             	mov    %rax,%rdx
    8210:	48 39 08             	cmp    %rcx,(%rax)
    8213:	75 eb                	jne    8200 <fwp_drop2+0x1c0>
    8215:	48 8b 50 08          	mov    0x8(%rax),%rdx
    8219:	48 83 ea 01          	sub    $0x1,%rdx
    821d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8221:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8228:	0f 85 9d fe ff ff    	jne    80cb <fwp_drop2+0x8b>
    822e:	48 89 cf             	mov    %rcx,%rdi
    8231:	48 89 0c 24          	mov    %rcx,(%rsp)
    8235:	e8 16 d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    823a:	48 8b 0c 24          	mov    (%rsp),%rcx
    823e:	c6 01 fe             	movb   $0xfe,(%rcx)
    8241:	e9 85 fe ff ff       	jmp    80cb <fwp_drop2+0x8b>
    8246:	48 89 ce             	mov    %rcx,%rsi
    8249:	48 c1 ee 11          	shr    $0x11,%rsi
    824d:	48 31 ce             	xor    %rcx,%rsi
    8250:	48 89 f0             	mov    %rsi,%rax
    8253:	48 c1 e8 09          	shr    $0x9,%rax
    8257:	48 31 c6             	xor    %rax,%rsi
    825a:	40 0f b6 f6          	movzbl %sil,%esi
    825e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    8265:	00 
    8266:	48 85 c0             	test   %rax,%rax
    8269:	75 1e                	jne    8289 <fwp_drop2+0x249>
    826b:	eb 5f                	jmp    82cc <fwp_drop2+0x28c>
    826d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8274:	00 
    8275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    827c:	00 00 00 00 
    8280:	48 8b 46 10          	mov    0x10(%rsi),%rax
    8284:	48 85 c0             	test   %rax,%rax
    8287:	74 43                	je     82cc <fwp_drop2+0x28c>
    8289:	48 89 c6             	mov    %rax,%rsi
    828c:	48 39 08             	cmp    %rcx,(%rax)
    828f:	75 ef                	jne    8280 <fwp_drop2+0x240>
    8291:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8295:	48 83 ee 01          	sub    $0x1,%rsi
    8299:	48 89 70 08          	mov    %rsi,0x8(%rax)
    829d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    82a4:	0f 85 b6 fe ff ff    	jne    8160 <fwp_drop2+0x120>
    82aa:	48 89 cf             	mov    %rcx,%rdi
    82ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    82b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    82b6:	e8 95 d2 ff ff       	call   5550 <fwp_rc_forget_slot>
    82bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    82bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    82c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    82c7:	e9 94 fe ff ff       	jmp    8160 <fwp_drop2+0x120>
    82cc:	48 8d 3d b5 75 00 00 	lea    0x75b5(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    82d3:	e8 18 c1 ff ff       	call   43f0 <fwp_trap>
    82d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82df:	00 

00000000000082e0 <fwp_arg_drop23>:
    82e0:	f3 0f 1e fa          	endbr64
    82e4:	85 f6                	test   %esi,%esi
    82e6:	75 04                	jne    82ec <fwp_arg_drop23+0xc>
    82e8:	85 d2                	test   %edx,%edx
    82ea:	75 04                	jne    82f0 <fwp_arg_drop23+0x10>
    82ec:	c3                   	ret
    82ed:	0f 1f 00             	nopl   (%rax)
    82f0:	48 8b 3f             	mov    (%rdi),%rdi
    82f3:	e9 48 fd ff ff       	jmp    8040 <fwp_drop2>
    82f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82ff:	00 

0000000000008300 <fwp_caps23>:
    8300:	f3 0f 1e fa          	endbr64
    8304:	48 83 ec 18          	sub    $0x18,%rsp
    8308:	8b 57 04             	mov    0x4(%rdi),%edx
    830b:	48 89 f8             	mov    %rdi,%rax
    830e:	85 d2                	test   %edx,%edx
    8310:	0f 84 9a 00 00 00    	je     83b0 <fwp_caps23+0xb0>
    8316:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    831a:	85 f6                	test   %esi,%esi
    831c:	0f 85 9e 00 00 00    	jne    83c0 <fwp_caps23+0xc0>
    8322:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8327:	e8 14 fd ff ff       	call   8040 <fwp_drop2>
    832c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8331:	48 8b 0d 80 c8 01 00 	mov    0x1c880(%rip),%rcx        # 24bb8 <fwp_heap+0x13d8>
    8338:	48 89 c2             	mov    %rax,%rdx
    833b:	48 2b 15 4e c8 01 00 	sub    0x1c84e(%rip),%rdx        # 24b90 <fwp_heap+0x13b0>
    8342:	48 c1 e1 10          	shl    $0x10,%rcx
    8346:	48 39 ca             	cmp    %rcx,%rdx
    8349:	73 6d                	jae    83b8 <fwp_caps23+0xb8>
    834b:	48 89 d1             	mov    %rdx,%rcx
    834e:	48 c1 e9 10          	shr    $0x10,%rcx
    8352:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8356:	48 8b 0d 7b c8 01 00 	mov    0x1c87b(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    835d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8361:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8365:	48 85 f6             	test   %rsi,%rsi
    8368:	74 4e                	je     83b8 <fwp_caps23+0xb8>
    836a:	0f b6 39             	movzbl (%rcx),%edi
    836d:	40 80 ff 02          	cmp    $0x2,%dil
    8371:	0f 84 b9 00 00 00    	je     8430 <fwp_caps23+0x130>
    8377:	40 80 ff 01          	cmp    $0x1,%dil
    837b:	75 3b                	jne    83b8 <fwp_caps23+0xb8>
    837d:	8b 79 18             	mov    0x18(%rcx),%edi
    8380:	0f b7 d2             	movzwl %dx,%edx
    8383:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8386:	48 0f af d7          	imul   %rdi,%rdx
    838a:	48 c1 ea 20          	shr    $0x20,%rdx
    838e:	48 39 ca             	cmp    %rcx,%rdx
    8391:	73 25                	jae    83b8 <fwp_caps23+0xb8>
    8393:	48 01 d6             	add    %rdx,%rsi
    8396:	80 3e 01             	cmpb   $0x1,(%rsi)
    8399:	75 1d                	jne    83b8 <fwp_caps23+0xb8>
    839b:	48 89 c7             	mov    %rax,%rdi
    839e:	48 83 c4 18          	add    $0x18,%rsp
    83a2:	e9 e9 d3 ff ff       	jmp    5790 <fwp_mem_free>
    83a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ae:	00 00 
    83b0:	85 f6                	test   %esi,%esi
    83b2:	0f 84 79 ff ff ff    	je     8331 <fwp_caps23+0x31>
    83b8:	48 83 c4 18          	add    $0x18,%rsp
    83bc:	c3                   	ret
    83bd:	0f 1f 00             	nopl   (%rax)
    83c0:	48 8b 05 f1 c7 01 00 	mov    0x1c7f1(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    83c7:	48 2b 3d c2 c7 01 00 	sub    0x1c7c2(%rip),%rdi        # 24b90 <fwp_heap+0x13b0>
    83ce:	48 c1 e0 10          	shl    $0x10,%rax
    83d2:	48 39 c7             	cmp    %rax,%rdi
    83d5:	73 e1                	jae    83b8 <fwp_caps23+0xb8>
    83d7:	48 89 f8             	mov    %rdi,%rax
    83da:	48 c1 e8 10          	shr    $0x10,%rax
    83de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    83e2:	48 8b 05 ef c7 01 00 	mov    0x1c7ef(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    83e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    83ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    83f1:	48 85 c0             	test   %rax,%rax
    83f4:	74 c2                	je     83b8 <fwp_caps23+0xb8>
    83f6:	0f b6 0a             	movzbl (%rdx),%ecx
    83f9:	80 f9 02             	cmp    $0x2,%cl
    83fc:	74 42                	je     8440 <fwp_caps23+0x140>
    83fe:	80 f9 01             	cmp    $0x1,%cl
    8401:	75 b5                	jne    83b8 <fwp_caps23+0xb8>
    8403:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8406:	0f b7 ff             	movzwl %di,%edi
    8409:	8b 52 1c             	mov    0x1c(%rdx),%edx
    840c:	48 0f af f9          	imul   %rcx,%rdi
    8410:	48 c1 ef 20          	shr    $0x20,%rdi
    8414:	48 39 d7             	cmp    %rdx,%rdi
    8417:	73 9f                	jae    83b8 <fwp_caps23+0xb8>
    8419:	48 01 f8             	add    %rdi,%rax
    841c:	0f b6 10             	movzbl (%rax),%edx
    841f:	84 d2                	test   %dl,%dl
    8421:	74 95                	je     83b8 <fwp_caps23+0xb8>
    8423:	80 fa fd             	cmp    $0xfd,%dl
    8426:	77 23                	ja     844b <fwp_caps23+0x14b>
    8428:	83 c2 01             	add    $0x1,%edx
    842b:	88 10                	mov    %dl,(%rax)
    842d:	eb 89                	jmp    83b8 <fwp_caps23+0xb8>
    842f:	90                   	nop
    8430:	66 85 d2             	test   %dx,%dx
    8433:	0f 85 7f ff ff ff    	jne    83b8 <fwp_caps23+0xb8>
    8439:	e9 58 ff ff ff       	jmp    8396 <fwp_caps23+0x96>
    843e:	66 90                	xchg   %ax,%ax
    8440:	66 85 ff             	test   %di,%di
    8443:	0f 85 6f ff ff ff    	jne    83b8 <fwp_caps23+0xb8>
    8449:	eb d1                	jmp    841c <fwp_caps23+0x11c>
    844b:	48 89 c7             	mov    %rax,%rdi
    844e:	48 83 c4 18          	add    $0x18,%rsp
    8452:	e9 d9 cf ff ff       	jmp    5430 <fwp_rc_wide_dup>
    8457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    845e:	00 00 

0000000000008460 <f23>:
    8460:	41 57                	push   %r15
    8462:	41 56                	push   %r14
    8464:	41 55                	push   %r13
    8466:	41 54                	push   %r12
    8468:	55                   	push   %rbp
    8469:	53                   	push   %rbx
    846a:	48 83 ec 38          	sub    $0x38,%rsp
    846e:	48 8b 15 43 c7 01 00 	mov    0x1c743(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8475:	48 8b 0d 14 c7 01 00 	mov    0x1c714(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    847c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    8483:	00 00 
    8485:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    848a:	49 89 fd             	mov    %rdi,%r13
    848d:	48 c1 e2 10          	shl    $0x10,%rdx
    8491:	48 85 ff             	test   %rdi,%rdi
    8494:	0f 84 fc 02 00 00    	je     8796 <f23+0x336>
    849a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    849e:	48 89 d8             	mov    %rbx,%rax
    84a1:	48 29 c8             	sub    %rcx,%rax
    84a4:	48 39 d0             	cmp    %rdx,%rax
    84a7:	0f 83 b3 03 00 00    	jae    8860 <f23+0x400>
    84ad:	48 89 c2             	mov    %rax,%rdx
    84b0:	48 c1 ea 10          	shr    $0x10,%rdx
    84b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84b8:	48 8b 15 19 c7 01 00 	mov    0x1c719(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    84bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    84c3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    84c7:	48 85 ff             	test   %rdi,%rdi
    84ca:	0f 84 90 03 00 00    	je     8860 <f23+0x400>
    84d0:	0f b6 0a             	movzbl (%rdx),%ecx
    84d3:	80 f9 02             	cmp    $0x2,%cl
    84d6:	0f 84 94 02 00 00    	je     8770 <f23+0x310>
    84dc:	80 f9 01             	cmp    $0x1,%cl
    84df:	75 24                	jne    8505 <f23+0xa5>
    84e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    84e4:	0f b7 c0             	movzwl %ax,%eax
    84e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    84ea:	48 0f af c1          	imul   %rcx,%rax
    84ee:	48 c1 e8 20          	shr    $0x20,%rax
    84f2:	48 39 d0             	cmp    %rdx,%rax
    84f5:	73 0e                	jae    8505 <f23+0xa5>
    84f7:	48 01 c7             	add    %rax,%rdi
    84fa:	0f b6 07             	movzbl (%rdi),%eax
    84fd:	84 c0                	test   %al,%al
    84ff:	0f 85 0b 03 00 00    	jne    8810 <f23+0x3b0>
    8505:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    850a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    850e:	ba 01 00 00 00       	mov    $0x1,%edx
    8513:	48 85 db             	test   %rbx,%rbx
    8516:	74 15                	je     852d <f23+0xcd>
    8518:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    851f:	00 
    8520:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8524:	48 83 c2 01          	add    $0x1,%rdx
    8528:	48 85 db             	test   %rbx,%rbx
    852b:	75 f3                	jne    8520 <f23+0xc0>
    852d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8532:	48 85 c0             	test   %rax,%rax
    8535:	0f 84 55 03 00 00    	je     8890 <f23+0x430>
    853b:	31 db                	xor    %ebx,%ebx
    853d:	0f 1f 00             	nopl   (%rax)
    8540:	48 8b 40 10          	mov    0x10(%rax),%rax
    8544:	48 83 c3 01          	add    $0x1,%rbx
    8548:	48 85 c0             	test   %rax,%rax
    854b:	75 f3                	jne    8540 <f23+0xe0>
    854d:	48 39 d3             	cmp    %rdx,%rbx
    8550:	48 0f 47 da          	cmova  %rdx,%rbx
    8554:	48 89 d8             	mov    %rbx,%rax
    8557:	48 c1 e8 3c          	shr    $0x3c,%rax
    855b:	0f 85 d3 03 00 00    	jne    8934 <f23+0x4d4>
    8561:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8565:	be 02 00 00 00       	mov    $0x2,%esi
    856a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8571:	00 
    8572:	e8 19 d7 ff ff       	call   5c90 <fwp_heap_alloc>
    8577:	48 89 28             	mov    %rbp,(%rax)
    857a:	48 8b 15 37 c6 01 00 	mov    0x1c637(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8581:	49 89 c4             	mov    %rax,%r12
    8584:	48 2b 05 05 c6 01 00 	sub    0x1c605(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    858b:	48 c1 e2 10          	shl    $0x10,%rdx
    858f:	48 39 d0             	cmp    %rdx,%rax
    8592:	73 57                	jae    85eb <f23+0x18b>
    8594:	48 89 c2             	mov    %rax,%rdx
    8597:	48 c1 ea 10          	shr    $0x10,%rdx
    859b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    859f:	48 8b 15 32 c6 01 00 	mov    0x1c632(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    85a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85aa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    85ae:	48 85 ed             	test   %rbp,%rbp
    85b1:	74 38                	je     85eb <f23+0x18b>
    85b3:	0f b6 0a             	movzbl (%rdx),%ecx
    85b6:	80 f9 02             	cmp    $0x2,%cl
    85b9:	0f 84 91 02 00 00    	je     8850 <f23+0x3f0>
    85bf:	80 f9 01             	cmp    $0x1,%cl
    85c2:	75 27                	jne    85eb <f23+0x18b>
    85c4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    85c7:	0f b7 c0             	movzwl %ax,%eax
    85ca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    85cd:	48 0f af c1          	imul   %rcx,%rax
    85d1:	48 c1 e8 20          	shr    $0x20,%rax
    85d5:	48 39 d0             	cmp    %rdx,%rax
    85d8:	73 11                	jae    85eb <f23+0x18b>
    85da:	48 01 c5             	add    %rax,%rbp
    85dd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    85e1:	0f 84 19 03 00 00    	je     8900 <f23+0x4a0>
    85e7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    85eb:	48 85 db             	test   %rbx,%rbx
    85ee:	74 5d                	je     864d <f23+0x1ed>
    85f0:	48 c1 e3 04          	shl    $0x4,%rbx
    85f4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    85f9:	4c 89 e5             	mov    %r12,%rbp
    85fc:	4d 89 ee             	mov    %r13,%r14
    85ff:	4c 01 e3             	add    %r12,%rbx
    8602:	0f 1f 00             	nopl   (%rax)
    8605:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    860c:	00 00 00 00 
    8610:	49 8b 46 08          	mov    0x8(%r14),%rax
    8614:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8618:	48 83 c5 10          	add    $0x10,%rbp
    861c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8621:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8625:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8629:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    862e:	e8 ad dd ff ff       	call   63e0 <w107>
    8633:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8638:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    863c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8640:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8644:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8648:	48 39 eb             	cmp    %rbp,%rbx
    864b:	75 c3                	jne    8610 <f23+0x1b0>
    864d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8652:	31 db                	xor    %ebx,%ebx
    8654:	e8 e7 f9 ff ff       	call   8040 <fwp_drop2>
    8659:	4c 89 ef             	mov    %r13,%rdi
    865c:	e8 df f9 ff ff       	call   8040 <fwp_drop2>
    8661:	4d 8b 2c 24          	mov    (%r12),%r13
    8665:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8669:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8670:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8677:	4d 85 ed             	test   %r13,%r13
    867a:	74 32                	je     86ae <f23+0x24e>
    867c:	0f 1f 40 00          	nopl   0x0(%rax)
    8680:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8687:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    868c:	48 83 c3 02          	add    $0x2,%rbx
    8690:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8696:	e8 c5 db ff ff       	call   6260 <f128.constprop.0>
    869b:	4c 39 eb             	cmp    %r13,%rbx
    869e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    86a4:	48 89 c7             	mov    %rax,%rdi
    86a7:	72 d7                	jb     8680 <f23+0x220>
    86a9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    86ae:	4c 89 e7             	mov    %r12,%rdi
    86b1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    86b6:	e8 85 f4 ff ff       	call   7b40 <fwp_drop4>
    86bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    86c0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    86c5:	31 ff                	xor    %edi,%edi
    86c7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    86cc:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    86d1:	e8 0a e3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    86d6:	48 8b 15 db c4 01 00 	mov    0x1c4db(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    86dd:	48 89 c5             	mov    %rax,%rbp
    86e0:	48 2b 05 a9 c4 01 00 	sub    0x1c4a9(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    86e7:	48 c1 e2 10          	shl    $0x10,%rdx
    86eb:	48 39 d0             	cmp    %rdx,%rax
    86ee:	73 55                	jae    8745 <f23+0x2e5>
    86f0:	48 89 c2             	mov    %rax,%rdx
    86f3:	48 c1 ea 10          	shr    $0x10,%rdx
    86f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86fb:	48 8b 15 d6 c4 01 00 	mov    0x1c4d6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8702:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8706:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    870a:	48 85 db             	test   %rbx,%rbx
    870d:	74 36                	je     8745 <f23+0x2e5>
    870f:	0f b6 0a             	movzbl (%rdx),%ecx
    8712:	80 f9 02             	cmp    $0x2,%cl
    8715:	0f 84 1d 01 00 00    	je     8838 <f23+0x3d8>
    871b:	80 f9 01             	cmp    $0x1,%cl
    871e:	75 25                	jne    8745 <f23+0x2e5>
    8720:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8723:	0f b7 c0             	movzwl %ax,%eax
    8726:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8729:	48 0f af c1          	imul   %rcx,%rax
    872d:	48 c1 e8 20          	shr    $0x20,%rax
    8731:	48 39 d0             	cmp    %rdx,%rax
    8734:	73 0f                	jae    8745 <f23+0x2e5>
    8736:	48 01 c3             	add    %rax,%rbx
    8739:	80 3b ff             	cmpb   $0xff,(%rbx)
    873c:	0f 84 b1 01 00 00    	je     88f3 <f23+0x493>
    8742:	c6 03 01             	movb   $0x1,(%rbx)
    8745:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    874a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8751:	00 00 
    8753:	0f 85 d6 01 00 00    	jne    892f <f23+0x4cf>
    8759:	48 83 c4 38          	add    $0x38,%rsp
    875d:	48 89 e8             	mov    %rbp,%rax
    8760:	5b                   	pop    %rbx
    8761:	5d                   	pop    %rbp
    8762:	41 5c                	pop    %r12
    8764:	41 5d                	pop    %r13
    8766:	41 5e                	pop    %r14
    8768:	41 5f                	pop    %r15
    876a:	c3                   	ret
    876b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8770:	66 85 c0             	test   %ax,%ax
    8773:	0f 85 8c fd ff ff    	jne    8505 <f23+0xa5>
    8779:	0f b6 07             	movzbl (%rdi),%eax
    877c:	84 c0                	test   %al,%al
    877e:	0f 84 81 fd ff ff    	je     8505 <f23+0xa5>
    8784:	3c fd                	cmp    $0xfd,%al
    8786:	0f 87 99 01 00 00    	ja     8925 <f23+0x4c5>
    878c:	83 c0 01             	add    $0x1,%eax
    878f:	88 07                	mov    %al,(%rdi)
    8791:	e9 6f fd ff ff       	jmp    8505 <f23+0xa5>
    8796:	48 f7 d9             	neg    %rcx
    8799:	48 39 d1             	cmp    %rdx,%rcx
    879c:	0f 83 ee 00 00 00    	jae    8890 <f23+0x430>
    87a2:	48 89 c8             	mov    %rcx,%rax
    87a5:	48 c1 e8 10          	shr    $0x10,%rax
    87a9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    87ad:	48 8b 05 24 c4 01 00 	mov    0x1c424(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    87b4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    87b8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    87bc:	48 85 ff             	test   %rdi,%rdi
    87bf:	0f 84 cb 00 00 00    	je     8890 <f23+0x430>
    87c5:	0f b6 02             	movzbl (%rdx),%eax
    87c8:	3c 02                	cmp    $0x2,%al
    87ca:	0f 84 9a 00 00 00    	je     886a <f23+0x40a>
    87d0:	3c 01                	cmp    $0x1,%al
    87d2:	0f 85 b8 00 00 00    	jne    8890 <f23+0x430>
    87d8:	0f b7 c1             	movzwl %cx,%eax
    87db:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87e1:	48 0f af c1          	imul   %rcx,%rax
    87e5:	48 c1 e8 20          	shr    $0x20,%rax
    87e9:	48 39 d0             	cmp    %rdx,%rax
    87ec:	0f 83 9e 00 00 00    	jae    8890 <f23+0x430>
    87f2:	48 01 c7             	add    %rax,%rdi
    87f5:	0f b6 07             	movzbl (%rdi),%eax
    87f8:	84 c0                	test   %al,%al
    87fa:	0f 84 90 00 00 00    	je     8890 <f23+0x430>
    8800:	31 db                	xor    %ebx,%ebx
    8802:	0f 1f 00             	nopl   (%rax)
    8805:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    880c:	00 00 00 00 
    8810:	3c fd                	cmp    $0xfd,%al
    8812:	0f 87 f5 00 00 00    	ja     890d <f23+0x4ad>
    8818:	83 c0 01             	add    $0x1,%eax
    881b:	88 07                	mov    %al,(%rdi)
    881d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8822:	31 d2                	xor    %edx,%edx
    8824:	4d 85 ed             	test   %r13,%r13
    8827:	0f 85 dd fc ff ff    	jne    850a <f23+0xaa>
    882d:	e9 fb fc ff ff       	jmp    852d <f23+0xcd>
    8832:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8838:	66 85 c0             	test   %ax,%ax
    883b:	0f 85 04 ff ff ff    	jne    8745 <f23+0x2e5>
    8841:	e9 f3 fe ff ff       	jmp    8739 <f23+0x2d9>
    8846:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    884d:	00 00 00 
    8850:	66 85 c0             	test   %ax,%ax
    8853:	0f 85 92 fd ff ff    	jne    85eb <f23+0x18b>
    8859:	e9 7f fd ff ff       	jmp    85dd <f23+0x17d>
    885e:	66 90                	xchg   %ax,%ax
    8860:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8865:	e9 a4 fc ff ff       	jmp    850e <f23+0xae>
    886a:	66 85 c9             	test   %cx,%cx
    886d:	75 21                	jne    8890 <f23+0x430>
    886f:	0f b6 07             	movzbl (%rdi),%eax
    8872:	84 c0                	test   %al,%al
    8874:	74 1a                	je     8890 <f23+0x430>
    8876:	3c fd                	cmp    $0xfd,%al
    8878:	0f 87 c2 00 00 00    	ja     8940 <f23+0x4e0>
    887e:	83 c0 01             	add    $0x1,%eax
    8881:	88 07                	mov    %al,(%rdi)
    8883:	66 90                	xchg   %ax,%ax
    8885:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    888c:	00 00 00 00 
    8890:	be 02 00 00 00       	mov    $0x2,%esi
    8895:	bf 08 00 00 00       	mov    $0x8,%edi
    889a:	e8 f1 d3 ff ff       	call   5c90 <fwp_heap_alloc>
    889f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    88a6:	48 8b 15 0b c3 01 00 	mov    0x1c30b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    88ad:	49 89 c4             	mov    %rax,%r12
    88b0:	48 2b 05 d9 c2 01 00 	sub    0x1c2d9(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    88b7:	48 c1 e2 10          	shl    $0x10,%rdx
    88bb:	48 39 d0             	cmp    %rdx,%rax
    88be:	73 57                	jae    8917 <f23+0x4b7>
    88c0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    88c7:	00 00 
    88c9:	48 89 c2             	mov    %rax,%rdx
    88cc:	48 c1 ea 10          	shr    $0x10,%rdx
    88d0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88d4:	48 8b 15 fd c2 01 00 	mov    0x1c2fd(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    88db:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88df:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    88e3:	48 85 ed             	test   %rbp,%rbp
    88e6:	0f 84 61 fd ff ff    	je     864d <f23+0x1ed>
    88ec:	31 db                	xor    %ebx,%ebx
    88ee:	e9 c0 fc ff ff       	jmp    85b3 <f23+0x153>
    88f3:	48 89 df             	mov    %rbx,%rdi
    88f6:	e8 55 cc ff ff       	call   5550 <fwp_rc_forget_slot>
    88fb:	e9 42 fe ff ff       	jmp    8742 <f23+0x2e2>
    8900:	48 89 ef             	mov    %rbp,%rdi
    8903:	e8 48 cc ff ff       	call   5550 <fwp_rc_forget_slot>
    8908:	e9 da fc ff ff       	jmp    85e7 <f23+0x187>
    890d:	e8 1e cb ff ff       	call   5430 <fwp_rc_wide_dup>
    8912:	e9 06 ff ff ff       	jmp    881d <f23+0x3bd>
    8917:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    891e:	00 00 
    8920:	e9 28 fd ff ff       	jmp    864d <f23+0x1ed>
    8925:	e8 06 cb ff ff       	call   5430 <fwp_rc_wide_dup>
    892a:	e9 d6 fb ff ff       	jmp    8505 <f23+0xa5>
    892f:	e8 2c ab ff ff       	call   3460 <__stack_chk_fail@plt>
    8934:	48 8d 3d 55 68 00 00 	lea    0x6855(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    893b:	e8 b0 ba ff ff       	call   43f0 <fwp_trap>
    8940:	e8 eb ca ff ff       	call   5430 <fwp_rc_wide_dup>
    8945:	e9 46 ff ff ff       	jmp    8890 <f23+0x430>
    894a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000008950 <fwp_owned_entry23>:
    8950:	f3 0f 1e fa          	endbr64
    8954:	48 8b 3f             	mov    (%rdi),%rdi
    8957:	e9 04 fb ff ff       	jmp    8460 <f23>
    895c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008960 <e23>:
    8960:	f3 0f 1e fa          	endbr64
    8964:	53                   	push   %rbx
    8965:	48 8b 1f             	mov    (%rdi),%rbx
    8968:	48 89 df             	mov    %rbx,%rdi
    896b:	e8 a0 e1 ff ff       	call   6b10 <fwp_rc_share>
    8970:	48 89 df             	mov    %rbx,%rdi
    8973:	e8 e8 fa ff ff       	call   8460 <f23>
    8978:	48 89 c3             	mov    %rax,%rbx
    897b:	48 89 c7             	mov    %rax,%rdi
    897e:	e8 8d e1 ff ff       	call   6b10 <fwp_rc_share>
    8983:	48 89 d8             	mov    %rbx,%rax
    8986:	5b                   	pop    %rbx
    8987:	c3                   	ret
    8988:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    898f:	00 

0000000000008990 <f12>:
    8990:	41 57                	push   %r15
    8992:	41 56                	push   %r14
    8994:	41 55                	push   %r13
    8996:	41 54                	push   %r12
    8998:	4c 8d 25 c1 eb ff ff 	lea    -0x143f(%rip),%r12        # 7560 <fwp_tape_scope_release>
    899f:	55                   	push   %rbp
    89a0:	53                   	push   %rbx
    89a1:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    89a8:	48 8b 05 c9 ca 01 00 	mov    0x1cac9(%rip),%rax        # 25478 <fwp_cleanups>
    89af:	48 8b 15 02 c2 01 00 	mov    0x1c202(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    89b6:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    89bd:	00 00 
    89bf:	48 89 ac 24 e8 00 00 	mov    %rbp,0xe8(%rsp)
    89c6:	00 
    89c7:	48 89 fd             	mov    %rdi,%rbp
    89ca:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    89d1:	ff 
    89d2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    89d7:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    89dc:	48 c1 e2 10          	shl    $0x10,%rdx
    89e0:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    89e5:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    89ea:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    89ef:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    89f4:	48 89 05 7d ca 01 00 	mov    %rax,0x1ca7d(%rip)        # 25478 <fwp_cleanups>
    89fb:	48 8d 05 0e a6 00 00 	lea    0xa60e(%rip),%rax        # 13010 <fc23>
    8a02:	48 2b 05 87 c1 01 00 	sub    0x1c187(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8a09:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
    8a0e:	48 39 d0             	cmp    %rdx,%rax
    8a11:	73 5d                	jae    8a70 <f12+0xe0>
    8a13:	48 89 c2             	mov    %rax,%rdx
    8a16:	48 c1 ea 10          	shr    $0x10,%rdx
    8a1a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a1e:	48 8b 15 b3 c1 01 00 	mov    0x1c1b3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8a25:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a29:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8a2d:	48 85 ff             	test   %rdi,%rdi
    8a30:	74 3e                	je     8a70 <f12+0xe0>
    8a32:	0f b6 0a             	movzbl (%rdx),%ecx
    8a35:	80 f9 02             	cmp    $0x2,%cl
    8a38:	0f 84 3a 0f 00 00    	je     9978 <f12+0xfe8>
    8a3e:	80 f9 01             	cmp    $0x1,%cl
    8a41:	75 2d                	jne    8a70 <f12+0xe0>
    8a43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a46:	0f b7 c0             	movzwl %ax,%eax
    8a49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a4c:	48 0f af c1          	imul   %rcx,%rax
    8a50:	48 c1 e8 20          	shr    $0x20,%rax
    8a54:	48 39 d0             	cmp    %rdx,%rax
    8a57:	73 17                	jae    8a70 <f12+0xe0>
    8a59:	48 01 c7             	add    %rax,%rdi
    8a5c:	0f b6 07             	movzbl (%rdi),%eax
    8a5f:	84 c0                	test   %al,%al
    8a61:	74 0d                	je     8a70 <f12+0xe0>
    8a63:	3c fd                	cmp    $0xfd,%al
    8a65:	0f 87 6f 11 00 00    	ja     9bda <f12+0x124a>
    8a6b:	83 c0 01             	add    $0x1,%eax
    8a6e:	88 07                	mov    %al,(%rdi)
    8a70:	48 8d 3d 99 a5 00 00 	lea    0xa599(%rip),%rdi        # 13010 <fc23>
    8a77:	e8 b4 e7 ff ff       	call   7230 <fwp_closure_drop>
    8a7c:	48 85 ed             	test   %rbp,%rbp
    8a7f:	0f 84 c5 10 00 00    	je     9b4a <f12+0x11ba>
    8a85:	48 89 e8             	mov    %rbp,%rax
    8a88:	31 db                	xor    %ebx,%ebx
    8a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a94:	48 83 c3 01          	add    $0x1,%rbx
    8a98:	48 85 c0             	test   %rax,%rax
    8a9b:	75 f3                	jne    8a90 <f12+0x100>
    8a9d:	31 ff                	xor    %edi,%edi
    8a9f:	e8 ac b7 ff ff       	call   4250 <descent_phase_step>
    8aa4:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    8aab:	0f 87 a4 11 00 00    	ja     9c55 <f12+0x12c5>
    8ab1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    8ab6:	8b 35 c4 a5 00 00    	mov    0xa5c4(%rip),%esi        # 13080 <registered_finish.0>
    8abc:	85 f6                	test   %esi,%esi
    8abe:	0f 84 84 0e 00 00    	je     9948 <f12+0xfb8>
    8ac4:	48 8b 1d 2d a6 01 00 	mov    0x1a62d(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    8acb:	4c 8b 2d 36 a6 01 00 	mov    0x1a636(%rip),%r13        # 23108 <fwp_ntapes>
    8ad2:	4c 39 eb             	cmp    %r13,%rbx
    8ad5:	0f 8d f5 05 00 00    	jge    90d0 <f12+0x740>
    8adb:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8adf:	48 03 05 2a a6 01 00 	add    0x1a62a(%rip),%rax        # 23110 <fwp_tapes>
    8ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8aed:	00 00 00 
    8af0:	8b 48 04             	mov    0x4(%rax),%ecx
    8af3:	85 c9                	test   %ecx,%ecx
    8af5:	75 0c                	jne    8b03 <f12+0x173>
    8af7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8afd:	0f 86 cd 05 00 00    	jbe    90d0 <f12+0x740>
    8b03:	48 83 c3 01          	add    $0x1,%rbx
    8b07:	48 83 c0 68          	add    $0x68,%rax
    8b0b:	4c 39 eb             	cmp    %r13,%rbx
    8b0e:	75 e0                	jne    8af0 <f12+0x160>
    8b10:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    8b17:	0f 8f 5c 11 00 00    	jg     9c79 <f12+0x12e9>
    8b1d:	4c 39 2d dc a5 01 00 	cmp    %r13,0x1a5dc(%rip)        # 23100 <fwp_tapes_cap>
    8b24:	4c 8b 3d e5 a5 01 00 	mov    0x1a5e5(%rip),%r15        # 23110 <fwp_tapes>
    8b2b:	75 40                	jne    8b6d <f12+0x1dd>
    8b2d:	4d 85 ed             	test   %r13,%r13
    8b30:	0f 85 9a 0f 00 00    	jne    9ad0 <f12+0x1140>
    8b36:	be 68 00 00 00       	mov    $0x68,%esi
    8b3b:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8b41:	4c 89 ff             	mov    %r15,%rdi
    8b44:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8b49:	e8 82 aa ff ff       	call   35d0 <realloc@plt>
    8b4e:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8b53:	48 85 c0             	test   %rax,%rax
    8b56:	49 89 c7             	mov    %rax,%r15
    8b59:	0f 84 65 0e 00 00    	je     99c4 <f12+0x1034>
    8b5f:	48 89 05 aa a5 01 00 	mov    %rax,0x1a5aa(%rip)        # 23110 <fwp_tapes>
    8b66:	4c 89 35 93 a5 01 00 	mov    %r14,0x1a593(%rip)        # 23100 <fwp_tapes_cap>
    8b6d:	49 6b c5 68          	imul   $0x68,%r13,%rax
    8b71:	49 83 c5 01          	add    $0x1,%r13
    8b75:	4c 01 f8             	add    %r15,%rax
    8b78:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8b7c:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8b83:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8b87:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8b8e:	00 
    8b8f:	48 29 f8             	sub    %rdi,%rax
    8b92:	8d 48 68             	lea    0x68(%rax),%ecx
    8b95:	31 c0                	xor    %eax,%eax
    8b97:	c1 e9 03             	shr    $0x3,%ecx
    8b9a:	f3 48 ab             	rep stos %rax,(%rdi)
    8b9d:	4c 89 2d 64 a5 01 00 	mov    %r13,0x1a564(%rip)        # 23108 <fwp_ntapes>
    8ba4:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    8ba8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8bac:	48 8d 3d 6f 65 00 00 	lea    0x656f(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    8bb3:	0f 29 04 24          	movaps %xmm0,(%rsp)
    8bb7:	4d 01 fe             	add    %r15,%r14
    8bba:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    8bc1:	00 
    8bc2:	e8 d9 a7 ff ff       	call   33a0 <getenv@plt>
    8bc7:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    8bcc:	48 85 c0             	test   %rax,%rax
    8bcf:	74 09                	je     8bda <f12+0x24a>
    8bd1:	80 38 30             	cmpb   $0x30,(%rax)
    8bd4:	0f 84 ce 03 00 00    	je     8fa8 <f12+0x618>
    8bda:	48 83 3d c6 a4 01 00 	cmpq   $0x0,0x1a4c6(%rip)        # 230a8 <fwp_tape_cached_bytes>
    8be1:	00 
    8be2:	0f 85 38 0e 00 00    	jne    9a20 <f12+0x1090>
    8be8:	41 8b 06             	mov    (%r14),%eax
    8beb:	48 8d 73 01          	lea    0x1(%rbx),%rsi
    8bef:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    8bf6:	00 
    8bf7:	48 89 35 fa a4 01 00 	mov    %rsi,0x1a4fa(%rip)        # 230f8 <fwp_tape_next_slot>
    8bfe:	44 8d 68 01          	lea    0x1(%rax),%r13d
    8c02:	48 8b 05 6f c8 01 00 	mov    0x1c86f(%rip),%rax        # 25478 <fwp_cleanups>
    8c09:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    8c0e:	45 89 2e             	mov    %r13d,(%r14)
    8c11:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    8c18:	00 
    8c19:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    8c20:	ff 
    8c21:	48 85 c0             	test   %rax,%rax
    8c24:	75 16                	jne    8c3c <f12+0x2ac>
    8c26:	e9 42 10 00 00       	jmp    9c6d <f12+0x12dd>
    8c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c30:	48 8b 00             	mov    (%rax),%rax
    8c33:	48 85 c0             	test   %rax,%rax
    8c36:	0f 84 31 10 00 00    	je     9c6d <f12+0x12dd>
    8c3c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8c40:	75 ee                	jne    8c30 <f12+0x2a0>
    8c42:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8c46:	89 df                	mov    %ebx,%edi
    8c48:	48 63 01             	movslq (%rcx),%rax
    8c4b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    8c4f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8c53:	85 c0                	test   %eax,%eax
    8c55:	78 09                	js     8c60 <f12+0x2d0>
    8c57:	48 6b c0 68          	imul   $0x68,%rax,%rax
    8c5b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    8c60:	89 39                	mov    %edi,(%rcx)
    8c62:	bf 01 00 00 00       	mov    $0x1,%edi
    8c67:	48 89 34 24          	mov    %rsi,(%rsp)
    8c6b:	e8 e0 b5 ff ff       	call   4250 <descent_phase_step>
    8c70:	31 c9                	xor    %ecx,%ecx
    8c72:	48 85 ed             	test   %rbp,%rbp
    8c75:	48 8b 34 24          	mov    (%rsp),%rsi
    8c79:	48 89 e8             	mov    %rbp,%rax
    8c7c:	0f 84 3e 03 00 00    	je     8fc0 <f12+0x630>
    8c82:	0f 1f 00             	nopl   (%rax)
    8c85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c8c:	00 00 00 00 
    8c90:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c94:	48 83 c1 01          	add    $0x1,%rcx
    8c98:	48 85 c0             	test   %rax,%rax
    8c9b:	75 f3                	jne    8c90 <f12+0x300>
    8c9d:	48 89 ea             	mov    %rbp,%rdx
    8ca0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8ca4:	48 83 c0 01          	add    $0x1,%rax
    8ca8:	48 85 d2             	test   %rdx,%rdx
    8cab:	75 f3                	jne    8ca0 <f12+0x310>
    8cad:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8cb4:	ff ff 1f 
    8cb7:	48 39 c2             	cmp    %rax,%rdx
    8cba:	0f 82 89 0f 00 00    	jb     9c49 <f12+0x12b9>
    8cc0:	48 85 c9             	test   %rcx,%rcx
    8cc3:	0f 8e f7 02 00 00    	jle    8fc0 <f12+0x630>
    8cc9:	48 39 c1             	cmp    %rax,%rcx
    8ccc:	48 0f 46 c1          	cmovbe %rcx,%rax
    8cd0:	49 89 c4             	mov    %rax,%r12
    8cd3:	48 c1 e8 3c          	shr    $0x3c,%rax
    8cd7:	0f 85 6c 0f 00 00    	jne    9c49 <f12+0x12b9>
    8cdd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    8ce1:	49 c1 e5 10          	shl    $0x10,%r13
    8ce5:	49 09 f5             	or     %rsi,%r13
    8ce8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8cef:	00 
    8cf0:	be 02 00 00 00       	mov    $0x2,%esi
    8cf5:	e8 96 cf ff ff       	call   5c90 <fwp_heap_alloc>
    8cfa:	4c 89 30             	mov    %r14,(%rax)
    8cfd:	48 8b 15 b4 be 01 00 	mov    0x1beb4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8d04:	48 89 c3             	mov    %rax,%rbx
    8d07:	48 2b 05 82 be 01 00 	sub    0x1be82(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8d0e:	48 c1 e2 10          	shl    $0x10,%rdx
    8d12:	48 39 d0             	cmp    %rdx,%rax
    8d15:	0f 83 05 0e 00 00    	jae    9b20 <f12+0x1190>
    8d1b:	48 89 c2             	mov    %rax,%rdx
    8d1e:	48 c1 ea 10          	shr    $0x10,%rdx
    8d22:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d26:	48 8b 15 ab be 01 00 	mov    0x1beab(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    8d2d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d31:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8d35:	4d 85 f6             	test   %r14,%r14
    8d38:	74 38                	je     8d72 <f12+0x3e2>
    8d3a:	0f b6 0a             	movzbl (%rdx),%ecx
    8d3d:	80 f9 02             	cmp    $0x2,%cl
    8d40:	0f 84 e7 02 00 00    	je     902d <f12+0x69d>
    8d46:	80 f9 01             	cmp    $0x1,%cl
    8d49:	75 27                	jne    8d72 <f12+0x3e2>
    8d4b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8d4e:	0f b7 c0             	movzwl %ax,%eax
    8d51:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d54:	48 0f af c1          	imul   %rcx,%rax
    8d58:	48 c1 e8 20          	shr    $0x20,%rax
    8d5c:	48 39 d0             	cmp    %rdx,%rax
    8d5f:	73 11                	jae    8d72 <f12+0x3e2>
    8d61:	49 01 c6             	add    %rax,%r14
    8d64:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8d68:	0f 84 45 0e 00 00    	je     9bb3 <f12+0x1223>
    8d6e:	41 c6 06 01          	movb   $0x1,(%r14)
    8d72:	4d 85 e4             	test   %r12,%r12
    8d75:	74 7c                	je     8df3 <f12+0x463>
    8d77:	4c 89 e9             	mov    %r13,%rcx
    8d7a:	48 89 ea             	mov    %rbp,%rdx
    8d7d:	31 c0                	xor    %eax,%eax
    8d7f:	48 c1 e1 20          	shl    $0x20,%rcx
    8d83:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8d89:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d90:	00 00 00 00 
    8d94:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d9b:	00 00 00 00 
    8d9f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8da6:	00 00 00 00 
    8daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8db1:	00 00 00 00 
    8db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dbc:	00 00 00 00 
    8dc0:	48 89 c6             	mov    %rax,%rsi
    8dc3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8dc8:	48 01 ce             	add    %rcx,%rsi
    8dcb:	0f 80 5f 0e 00 00    	jo     9c30 <f12+0x12a0>
    8dd1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8dd6:	48 89 c6             	mov    %rax,%rsi
    8dd9:	48 83 c0 01          	add    $0x1,%rax
    8ddd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8de1:	48 c1 e6 04          	shl    $0x4,%rsi
    8de5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    8dea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8dee:	4c 39 e0             	cmp    %r12,%rax
    8df1:	72 cd                	jb     8dc0 <f12+0x430>
    8df3:	48 8b 03             	mov    (%rbx),%rax
    8df6:	48 d1 e8             	shr    $1,%rax
    8df9:	0f 85 41 02 00 00    	jne    9040 <f12+0x6b0>
    8dff:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8e06:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    8e0d:	0f 1f 00             	nopl   (%rax)
    8e10:	48 89 df             	mov    %rbx,%rdi
    8e13:	48 89 0c 24          	mov    %rcx,(%rsp)
    8e17:	4d 63 e5             	movslq %r13d,%r12
    8e1a:	e8 21 ed ff ff       	call   7b40 <fwp_drop4>
    8e1f:	bf 02 00 00 00       	mov    $0x2,%edi
    8e24:	e8 27 b4 ff ff       	call   4250 <descent_phase_step>
    8e29:	4c 89 e7             	mov    %r12,%rdi
    8e2c:	e8 9f b8 ff ff       	call   46d0 <fwp_tape_of>
    8e31:	48 8b 0c 24          	mov    (%rsp),%rcx
    8e35:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8e3a:	48 89 c6             	mov    %rax,%rsi
    8e3d:	0f 85 47 0e 00 00    	jne    9c8a <f12+0x12fa>
    8e43:	48 89 c7             	mov    %rax,%rdi
    8e46:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    8e4b:	e8 b0 ad ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8e50:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    8e55:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    8e59:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8e60:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8e65:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8e6a:	0f 29 74 24 10       	movaps %xmm6,0x10(%rsp)
    8e6f:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8e75:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8e7a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    8e7e:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8e82:	4c 8b 7e 40          	mov    0x40(%rsi),%r15
    8e86:	0f 29 3c 24          	movaps %xmm7,(%rsp)
    8e8a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8e8e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    8e93:	77 19                	ja     8eae <f12+0x51e>
    8e95:	41 0f b7 c5          	movzwl %r13w,%eax
    8e99:	83 e8 01             	sub    $0x1,%eax
    8e9c:	48 98                	cltq
    8e9e:	48 3b 05 53 a2 01 00 	cmp    0x1a253(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    8ea5:	7d 07                	jge    8eae <f12+0x51e>
    8ea7:	48 89 05 4a a2 01 00 	mov    %rax,0x1a24a(%rip)        # 230f8 <fwp_tape_next_slot>
    8eae:	48 8b 05 c3 c5 01 00 	mov    0x1c5c3(%rip),%rax        # 25478 <fwp_cleanups>
    8eb5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8eb9:	66 0f 6f 7c 24 10    	movdqa 0x10(%rsp),%xmm7
    8ebf:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8ec6:	00 
    8ec7:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8ecb:	66 0f 6f 34 24       	movdqa (%rsp),%xmm6
    8ed0:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    8ed5:	48 8d 05 94 c1 ff ff 	lea    -0x3e6c(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    8edc:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    8ee1:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    8ee8:	00 
    8ee9:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8eee:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8ef5:	00 
    8ef6:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    8efb:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8eff:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8f03:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8f0a:	00 
    8f0b:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8f12:	00 
    8f13:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
    8f1a:	00 
    8f1b:	48 89 05 56 c5 01 00 	mov    %rax,0x1c556(%rip)        # 25478 <fwp_cleanups>
    8f22:	0f 29 bc 24 90 00 00 	movaps %xmm7,0x90(%rsp)
    8f29:	00 
    8f2a:	0f 29 b4 24 a0 00 00 	movaps %xmm6,0xa0(%rsp)
    8f31:	00 
    8f32:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    8f39:	00 
    8f3a:	48 85 c9             	test   %rcx,%rcx
    8f3d:	0f 88 4d 0a 00 00    	js     9990 <f12+0x1000>
    8f43:	48 89 c8             	mov    %rcx,%rax
    8f46:	48 c1 f8 20          	sar    $0x20,%rax
    8f4a:	49 39 c4             	cmp    %rax,%r12
    8f4d:	0f 85 d1 0c 00 00    	jne    9c24 <f12+0x1294>
    8f53:	41 89 ca             	mov    %ecx,%r10d
    8f56:	4d 89 d5             	mov    %r10,%r13
    8f59:	4c 39 d2             	cmp    %r10,%rdx
    8f5c:	0f 8e b6 0c 00 00    	jle    9c18 <f12+0x1288>
    8f62:	4c 39 d3             	cmp    %r10,%rbx
    8f65:	0f 8e 7d 01 00 00    	jle    90e8 <f12+0x758>
    8f6b:	4c 39 f3             	cmp    %r14,%rbx
    8f6e:	0f 8f 4c 0b 00 00    	jg     9ac0 <f12+0x1130>
    8f74:	4d 85 ff             	test   %r15,%r15
    8f77:	0f 84 31 0a 00 00    	je     99ae <f12+0x101e>
    8f7d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    8f84:	00 
    8f85:	31 f6                	xor    %esi,%esi
    8f87:	4c 89 ff             	mov    %r15,%rdi
    8f8a:	45 31 f6             	xor    %r14d,%r14d
    8f8d:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    8f92:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    8f96:	e8 25 a5 ff ff       	call   34c0 <memset@plt>
    8f9b:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    8fa0:	e9 d2 01 00 00       	jmp    9177 <f12+0x7e7>
    8fa5:	0f 1f 00             	nopl   (%rax)
    8fa8:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8fac:	0f 84 36 fc ff ff    	je     8be8 <f12+0x258>
    8fb2:	e9 23 fc ff ff       	jmp    8bda <f12+0x24a>
    8fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8fbe:	00 00 
    8fc0:	49 c1 e5 10          	shl    $0x10,%r13
    8fc4:	bf 08 00 00 00       	mov    $0x8,%edi
    8fc9:	49 09 f5             	or     %rsi,%r13
    8fcc:	be 02 00 00 00       	mov    $0x2,%esi
    8fd1:	e8 ba cc ff ff       	call   5c90 <fwp_heap_alloc>
    8fd6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8fdd:	48 8b 15 d4 bb 01 00 	mov    0x1bbd4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    8fe4:	48 89 c3             	mov    %rax,%rbx
    8fe7:	48 2b 05 a2 bb 01 00 	sub    0x1bba2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    8fee:	48 c1 e2 10          	shl    $0x10,%rdx
    8ff2:	48 39 d0             	cmp    %rdx,%rax
    8ff5:	0f 83 04 fe ff ff    	jae    8dff <f12+0x46f>
    8ffb:	48 89 c2             	mov    %rax,%rdx
    8ffe:	48 c1 ea 10          	shr    $0x10,%rdx
    9002:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9006:	48 8b 15 cb bb 01 00 	mov    0x1bbcb(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    900d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9011:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9015:	4d 85 f6             	test   %r14,%r14
    9018:	0f 84 d5 fd ff ff    	je     8df3 <f12+0x463>
    901e:	0f b6 0a             	movzbl (%rdx),%ecx
    9021:	45 31 e4             	xor    %r12d,%r12d
    9024:	80 f9 02             	cmp    $0x2,%cl
    9027:	0f 85 19 fd ff ff    	jne    8d46 <f12+0x3b6>
    902d:	66 85 c0             	test   %ax,%ax
    9030:	0f 85 3c fd ff ff    	jne    8d72 <f12+0x3e2>
    9036:	e9 29 fd ff ff       	jmp    8d64 <f12+0x3d4>
    903b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9040:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    9044:	4c 89 e1             	mov    %r12,%rcx
    9047:	48 c1 e9 3c          	shr    $0x3c,%rcx
    904b:	0f 85 f8 0b 00 00    	jne    9c49 <f12+0x12b9>
    9051:	4d 85 e4             	test   %r12,%r12
    9054:	0f 84 a5 fd ff ff    	je     8dff <f12+0x46f>
    905a:	48 c1 e0 04          	shl    $0x4,%rax
    905e:	4d 01 e4             	add    %r12,%r12
    9061:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    9065:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    906a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9070:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9075:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9079:	49 83 c7 10          	add    $0x10,%r15
    907d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9081:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9086:	e8 55 d3 ff ff       	call   63e0 <w107>
    908b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    9090:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9094:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9099:	4d 39 fe             	cmp    %r15,%r14
    909c:	75 d2                	jne    9070 <f12+0x6e0>
    909e:	4c 89 23             	mov    %r12,(%rbx)
    90a1:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    90a8:	45 31 f6             	xor    %r14d,%r14d
    90ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    90b0:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    90b5:	48 89 cf             	mov    %rcx,%rdi
    90b8:	49 83 c6 02          	add    $0x2,%r14
    90bc:	e8 9f d1 ff ff       	call   6260 <f128.constprop.0>
    90c1:	48 89 c1             	mov    %rax,%rcx
    90c4:	4d 39 e6             	cmp    %r12,%r14
    90c7:	72 e7                	jb     90b0 <f12+0x720>
    90c9:	e9 42 fd ff ff       	jmp    8e10 <f12+0x480>
    90ce:	66 90                	xchg   %ax,%ax
    90d0:	4c 39 eb             	cmp    %r13,%rbx
    90d3:	0f 84 37 fa ff ff    	je     8b10 <f12+0x180>
    90d9:	4c 8b 3d 30 a0 01 00 	mov    0x1a030(%rip),%r15        # 23110 <fwp_tapes>
    90e0:	e9 bf fa ff ff       	jmp    8ba4 <f12+0x214>
    90e5:	0f 1f 00             	nopl   (%rax)
    90e8:	4d 8d 62 01          	lea    0x1(%r10),%r12
    90ec:	4d 39 e6             	cmp    %r12,%r14
    90ef:	0f 8d 9b 09 00 00    	jge    9a90 <f12+0x1100>
    90f5:	4d 85 f6             	test   %r14,%r14
    90f8:	4d 0f 44 f4          	cmove  %r12,%r14
    90fc:	eb 17                	jmp    9115 <f12+0x785>
    90fe:	66 90                	xchg   %ax,%ax
    9100:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    9104:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    910b:	4c 89 e0             	mov    %r12,%rax
    910e:	48 0f 4c c2          	cmovl  %rdx,%rax
    9112:	49 89 c6             	mov    %rax,%r14
    9115:	4d 39 e6             	cmp    %r12,%r14
    9118:	7c e6                	jl     9100 <f12+0x770>
    911a:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    911f:	4d 85 ff             	test   %r15,%r15
    9122:	0f 84 08 0a 00 00    	je     9b30 <f12+0x11a0>
    9128:	4c 89 ff             	mov    %r15,%rdi
    912b:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    9132:	00 
    9133:	e8 98 a4 ff ff       	call   35d0 <realloc@plt>
    9138:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    913d:	49 89 c7             	mov    %rax,%r15
    9140:	4d 85 ff             	test   %r15,%r15
    9143:	0f 84 53 08 00 00    	je     999c <f12+0x100c>
    9149:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
    9150:	00 
    9151:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    9158:	00 
    9159:	4d 85 e4             	test   %r12,%r12
    915c:	0f 85 82 0a 00 00    	jne    9be4 <f12+0x1254>
    9162:	49 89 de             	mov    %rbx,%r14
    9165:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    916c:	49 f7 de             	neg    %r14
    916f:	48 85 c9             	test   %rcx,%rcx
    9172:	78 17                	js     918b <f12+0x7fb>
    9174:	41 89 ca             	mov    %ecx,%r10d
    9177:	f2 0f 10 05 a1 6a 00 	movsd  0x6aa1(%rip),%xmm0        # fc20 <msg.4+0xb0>
    917e:	00 
    917f:	f2 43 0f 58 04 d7    	addsd  (%r15,%r10,8),%xmm0
    9185:	f2 43 0f 11 04 d7    	movsd  %xmm0,(%r15,%r10,8)
    918b:	bf 03 00 00 00       	mov    $0x3,%edi
    9190:	48 01 1d 89 9f 01 00 	add    %rbx,0x19f89(%rip)        # 23120 <descent_inputs>
    9197:	4c 01 35 8a 9f 01 00 	add    %r14,0x19f8a(%rip)        # 23128 <descent_nodes>
    919e:	e8 ad b0 ff ff       	call   4250 <descent_phase_step>
    91a3:	49 39 dd             	cmp    %rbx,%r13
    91a6:	0f 8c 85 00 00 00    	jl     9231 <f12+0x8a1>
    91ac:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    91b1:	4c 8b 14 24          	mov    (%rsp),%r10
    91b5:	49 29 dd             	sub    %rbx,%r13
    91b8:	49 8d 3c df          	lea    (%r15,%rbx,8),%rdi
    91bc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
    91c1:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    91c6:	66 0f ef d2          	pxor   %xmm2,%xmm2
    91ca:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    91ce:	4c 29 df             	sub    %r11,%rdi
    91d1:	4d 29 da             	sub    %r11,%r10
    91d4:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    91d8:	48 29 f1             	sub    %rsi,%rcx
    91db:	eb 07                	jmp    91e4 <f12+0x854>
    91dd:	0f 1f 00             	nopl   (%rax)
    91e0:	48 83 e8 04          	sub    $0x4,%rax
    91e4:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    91e9:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    91ed:	7a 02                	jp     91f1 <f12+0x861>
    91ef:	74 37                	je     9228 <f12+0x898>
    91f1:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    91f5:	45 85 db             	test   %r11d,%r11d
    91f8:	78 16                	js     9210 <f12+0x880>
    91fa:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9200:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9204:	f2 43 0f 58 0c df    	addsd  (%r15,%r11,8),%xmm1
    920a:	f2 43 0f 11 0c df    	movsd  %xmm1,(%r15,%r11,8)
    9210:	4c 63 18             	movslq (%rax),%r11
    9213:	45 85 db             	test   %r11d,%r11d
    9216:	78 10                	js     9228 <f12+0x898>
    9218:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    921c:	f2 43 0f 58 04 df    	addsd  (%r15,%r11,8),%xmm0
    9222:	f2 43 0f 11 04 df    	movsd  %xmm0,(%r15,%r11,8)
    9228:	48 83 ea 08          	sub    $0x8,%rdx
    922c:	48 39 c6             	cmp    %rax,%rsi
    922f:	75 af                	jne    91e0 <f12+0x850>
    9231:	bf 04 00 00 00       	mov    $0x4,%edi
    9236:	e8 15 b0 ff ff       	call   4250 <descent_phase_step>
    923b:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9242:	ff ff 1f 
    9245:	48 39 d8             	cmp    %rbx,%rax
    9248:	0f 82 13 0a 00 00    	jb     9c61 <f12+0x12d1>
    924e:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    9255:	00 
    9256:	be 02 00 00 00       	mov    $0x2,%esi
    925b:	e8 30 ca ff ff       	call   5c90 <fwp_heap_alloc>
    9260:	48 89 18             	mov    %rbx,(%rax)
    9263:	49 89 c4             	mov    %rax,%r12
    9266:	31 c0                	xor    %eax,%eax
    9268:	48 85 db             	test   %rbx,%rbx
    926b:	74 25                	je     9292 <f12+0x902>
    926d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9274:	00 
    9275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    927c:	00 00 00 00 
    9280:	49 8b 14 c7          	mov    (%r15,%rax,8),%rdx
    9284:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    9289:	48 83 c0 01          	add    $0x1,%rax
    928d:	48 39 c3             	cmp    %rax,%rbx
    9290:	75 ee                	jne    9280 <f12+0x8f0>
    9292:	bf 05 00 00 00       	mov    $0x5,%edi
    9297:	e8 b4 af ff ff       	call   4250 <descent_phase_step>
    929c:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
    92a1:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    92a6:	4c 89 2d cb c1 01 00 	mov    %r13,0x1c1cb(%rip)        # 25478 <fwp_cleanups>
    92ad:	e8 be bd ff ff       	call   5070 <fwp_tape_buffers_release>
    92b2:	bf 06 00 00 00       	mov    $0x6,%edi
    92b7:	e8 94 af ff ff       	call   4250 <descent_phase_step>
    92bc:	48 8b 15 f5 b8 01 00 	mov    0x1b8f5(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    92c3:	4c 89 e0             	mov    %r12,%rax
    92c6:	48 2b 05 c3 b8 01 00 	sub    0x1b8c3(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    92cd:	48 c1 e2 10          	shl    $0x10,%rdx
    92d1:	48 39 d0             	cmp    %rdx,%rax
    92d4:	73 55                	jae    932b <f12+0x99b>
    92d6:	48 89 c2             	mov    %rax,%rdx
    92d9:	48 c1 ea 10          	shr    $0x10,%rdx
    92dd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    92e1:	48 8b 15 f0 b8 01 00 	mov    0x1b8f0(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    92e8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    92ec:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    92f0:	48 85 db             	test   %rbx,%rbx
    92f3:	74 36                	je     932b <f12+0x99b>
    92f5:	0f b6 0a             	movzbl (%rdx),%ecx
    92f8:	80 f9 02             	cmp    $0x2,%cl
    92fb:	0f 84 f7 06 00 00    	je     99f8 <f12+0x1068>
    9301:	80 f9 01             	cmp    $0x1,%cl
    9304:	75 25                	jne    932b <f12+0x99b>
    9306:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9309:	0f b7 c0             	movzwl %ax,%eax
    930c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    930f:	48 0f af c1          	imul   %rcx,%rax
    9313:	48 c1 e8 20          	shr    $0x20,%rax
    9317:	48 39 d0             	cmp    %rdx,%rax
    931a:	73 0f                	jae    932b <f12+0x99b>
    931c:	48 01 c3             	add    %rax,%rbx
    931f:	80 3b ff             	cmpb   $0xff,(%rbx)
    9322:	0f 84 98 08 00 00    	je     9bc0 <f12+0x1230>
    9328:	c6 03 01             	movb   $0x1,(%rbx)
    932b:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    9330:	0f 85 15 a4 ff ff    	jne    374b <f12.cold>
    9336:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    933b:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    9340:	48 89 05 31 c1 01 00 	mov    %rax,0x1c131(%rip)        # 25478 <fwp_cleanups>
    9347:	e8 14 e2 ff ff       	call   7560 <fwp_tape_scope_release>
    934c:	49 8b 04 24          	mov    (%r12),%rax
    9350:	49 89 c6             	mov    %rax,%r14
    9353:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9358:	48 85 c0             	test   %rax,%rax
    935b:	0f 88 1f 05 00 00    	js     9880 <f12+0xef0>
    9361:	48 8b 15 50 b8 01 00 	mov    0x1b850(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    9368:	4c 89 e0             	mov    %r12,%rax
    936b:	48 2b 05 1e b8 01 00 	sub    0x1b81e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    9372:	48 c1 e2 10          	shl    $0x10,%rdx
    9376:	48 39 d0             	cmp    %rdx,%rax
    9379:	0f 83 01 05 00 00    	jae    9880 <f12+0xef0>
    937f:	48 89 c2             	mov    %rax,%rdx
    9382:	48 c1 ea 10          	shr    $0x10,%rdx
    9386:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    938a:	48 8b 15 47 b8 01 00 	mov    0x1b847(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    9391:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9395:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    9399:	48 85 c9             	test   %rcx,%rcx
    939c:	0f 84 de 04 00 00    	je     9880 <f12+0xef0>
    93a2:	0f b6 32             	movzbl (%rdx),%esi
    93a5:	40 80 fe 02          	cmp    $0x2,%sil
    93a9:	0f 84 c1 04 00 00    	je     9870 <f12+0xee0>
    93af:	40 80 fe 01          	cmp    $0x1,%sil
    93b3:	0f 85 c7 04 00 00    	jne    9880 <f12+0xef0>
    93b9:	8b 72 18             	mov    0x18(%rdx),%esi
    93bc:	0f b7 c0             	movzwl %ax,%eax
    93bf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93c2:	48 0f af c6          	imul   %rsi,%rax
    93c6:	48 c1 e8 20          	shr    $0x20,%rax
    93ca:	48 39 d0             	cmp    %rdx,%rax
    93cd:	0f 83 ad 04 00 00    	jae    9880 <f12+0xef0>
    93d3:	48 01 c1             	add    %rax,%rcx
    93d6:	80 39 01             	cmpb   $0x1,(%rcx)
    93d9:	0f 85 a1 04 00 00    	jne    9880 <f12+0xef0>
    93df:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    93e4:	4d 89 e5             	mov    %r12,%r13
    93e7:	31 ff                	xor    %edi,%edi
    93e9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    93ee:	f2 0f 10 0d 42 68 00 	movsd  0x6842(%rip),%xmm1        # fc38 <msg.4+0xc8>
    93f5:	00 
    93f6:	48 8d 50 08          	lea    0x8(%rax),%rdx
    93fa:	31 c0                	xor    %eax,%eax
    93fc:	4d 85 f6             	test   %r14,%r14
    93ff:	75 2d                	jne    942e <f12+0xa9e>
    9401:	eb 45                	jmp    9448 <f12+0xab8>
    9403:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9408:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    940d:	0f 88 22 08 00 00    	js     9c35 <f12+0x12a5>
    9413:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    9418:	48 83 c0 01          	add    $0x1,%rax
    941c:	48 83 c2 08          	add    $0x8,%rdx
    9420:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    9424:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9429:	49 39 c6             	cmp    %rax,%r14
    942c:	74 1a                	je     9448 <f12+0xab8>
    942e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    9433:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9438:	79 ce                	jns    9408 <f12+0xa78>
    943a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    943f:	eb c7                	jmp    9408 <f12+0xa78>
    9441:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9448:	e8 f3 e6 ff ff       	call   7b40 <fwp_drop4>
    944d:	48 89 e8             	mov    %rbp,%rax
    9450:	31 d2                	xor    %edx,%edx
    9452:	48 85 ed             	test   %rbp,%rbp
    9455:	0f 84 ff 06 00 00    	je     9b5a <f12+0x11ca>
    945b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9460:	48 8b 40 10          	mov    0x10(%rax),%rax
    9464:	48 83 c2 01          	add    $0x1,%rdx
    9468:	48 85 c0             	test   %rax,%rax
    946b:	75 f3                	jne    9460 <f12+0xad0>
    946d:	49 8b 45 00          	mov    0x0(%r13),%rax
    9471:	49 89 c7             	mov    %rax,%r15
    9474:	49 0f ba f7 3f       	btr    $0x3f,%r15
    9479:	48 85 c0             	test   %rax,%rax
    947c:	0f 88 50 03 00 00    	js     97d2 <f12+0xe42>
    9482:	48 8b 05 2f b7 01 00 	mov    0x1b72f(%rip),%rax        # 24bb8 <fwp_heap+0x13d8>
    9489:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    948e:	48 2b 0d fb b6 01 00 	sub    0x1b6fb(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    9495:	48 c1 e0 10          	shl    $0x10,%rax
    9499:	48 39 c1             	cmp    %rax,%rcx
    949c:	0f 83 30 03 00 00    	jae    97d2 <f12+0xe42>
    94a2:	48 89 c8             	mov    %rcx,%rax
    94a5:	48 c1 e8 10          	shr    $0x10,%rax
    94a9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    94ad:	48 8b 05 24 b7 01 00 	mov    0x1b724(%rip),%rax        # 24bd8 <fwp_heap+0x13f8>
    94b4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    94b8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    94bc:	48 85 ff             	test   %rdi,%rdi
    94bf:	0f 84 0d 03 00 00    	je     97d2 <f12+0xe42>
    94c5:	0f b6 06             	movzbl (%rsi),%eax
    94c8:	3c 02                	cmp    $0x2,%al
    94ca:	0f 84 f0 02 00 00    	je     97c0 <f12+0xe30>
    94d0:	3c 01                	cmp    $0x1,%al
    94d2:	0f 85 f1 02 00 00    	jne    97c9 <f12+0xe39>
    94d8:	8b 46 18             	mov    0x18(%rsi),%eax
    94db:	0f b7 c9             	movzwl %cx,%ecx
    94de:	48 0f af c8          	imul   %rax,%rcx
    94e2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    94e5:	48 c1 e9 20          	shr    $0x20,%rcx
    94e9:	48 39 c1             	cmp    %rax,%rcx
    94ec:	0f 83 d7 02 00 00    	jae    97c9 <f12+0xe39>
    94f2:	48 01 cf             	add    %rcx,%rdi
    94f5:	80 3f 01             	cmpb   $0x1,(%rdi)
    94f8:	0f 85 cb 02 00 00    	jne    97c9 <f12+0xe39>
    94fe:	49 39 d7             	cmp    %rdx,%r15
    9501:	48 89 d0             	mov    %rdx,%rax
    9504:	49 0f 46 c7          	cmovbe %r15,%rax
    9508:	48 85 c0             	test   %rax,%rax
    950b:	0f 84 30 07 00 00    	je     9c41 <f12+0x12b1>
    9511:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    9518:	00 
    9519:	4d 8d 75 08          	lea    0x8(%r13),%r14
    951d:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    9522:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9529:	00 
    952a:	48 89 e9             	mov    %rbp,%rcx
    952d:	31 d2                	xor    %edx,%edx
    952f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9533:	eb 28                	jmp    955d <f12+0xbcd>
    9535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    953c:	00 00 00 00 
    9540:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9545:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    954a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9550:	48 83 c2 08          	add    $0x8,%rdx
    9554:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9558:	49 39 d0             	cmp    %rdx,%r8
    955b:	74 1b                	je     9578 <f12+0xbe8>
    955d:	48 89 fe             	mov    %rdi,%rsi
    9560:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    9565:	79 d9                	jns    9540 <f12+0xbb0>
    9567:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    956c:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    9570:	eb ce                	jmp    9540 <f12+0xbb0>
    9572:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9578:	48 85 ed             	test   %rbp,%rbp
    957b:	0f 84 8f 06 00 00    	je     9c10 <f12+0x1280>
    9581:	4c 8b 05 30 b6 01 00 	mov    0x1b630(%rip),%r8        # 24bb8 <fwp_heap+0x13d8>
    9588:	4c 8b 0d 01 b6 01 00 	mov    0x1b601(%rip),%r9        # 24b90 <fwp_heap+0x13b0>
    958f:	48 89 e9             	mov    %rbp,%rcx
    9592:	45 31 ed             	xor    %r13d,%r13d
    9595:	4c 8b 15 3c b6 01 00 	mov    0x1b63c(%rip),%r10        # 24bd8 <fwp_heap+0x13f8>
    959c:	49 c1 e0 10          	shl    $0x10,%r8
    95a0:	eb 1c                	jmp    95be <f12+0xc2e>
    95a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95a8:	49 83 c5 01          	add    $0x1,%r13
    95ac:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    95b0:	49 39 c5             	cmp    %rax,%r13
    95b3:	0f 83 67 01 00 00    	jae    9720 <f12+0xd90>
    95b9:	48 85 c9             	test   %rcx,%rcx
    95bc:	74 56                	je     9614 <f12+0xc84>
    95be:	48 89 ca             	mov    %rcx,%rdx
    95c1:	4c 29 ca             	sub    %r9,%rdx
    95c4:	4c 39 c2             	cmp    %r8,%rdx
    95c7:	73 4b                	jae    9614 <f12+0xc84>
    95c9:	48 89 d6             	mov    %rdx,%rsi
    95cc:	48 c1 ee 10          	shr    $0x10,%rsi
    95d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    95d4:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    95d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    95dc:	48 85 ff             	test   %rdi,%rdi
    95df:	74 33                	je     9614 <f12+0xc84>
    95e1:	44 0f b6 1e          	movzbl (%rsi),%r11d
    95e5:	41 80 fb 02          	cmp    $0x2,%r11b
    95e9:	0f 84 19 01 00 00    	je     9708 <f12+0xd78>
    95ef:	41 80 fb 01          	cmp    $0x1,%r11b
    95f3:	75 1f                	jne    9614 <f12+0xc84>
    95f5:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    95f9:	0f b7 d2             	movzwl %dx,%edx
    95fc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    95ff:	49 0f af d3          	imul   %r11,%rdx
    9603:	48 c1 ea 20          	shr    $0x20,%rdx
    9607:	48 39 f2             	cmp    %rsi,%rdx
    960a:	73 08                	jae    9614 <f12+0xc84>
    960c:	48 01 d7             	add    %rdx,%rdi
    960f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9612:	74 94                	je     95a8 <f12+0xc18>
    9614:	49 39 c5             	cmp    %rax,%r13
    9617:	0f 83 03 01 00 00    	jae    9720 <f12+0xd90>
    961d:	49 89 c7             	mov    %rax,%r15
    9620:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    9627:	00 
    9628:	45 31 e4             	xor    %r12d,%r12d
    962b:	48 89 04 24          	mov    %rax,(%rsp)
    962f:	48 8d 1d aa a1 01 00 	lea    0x1a1aa(%rip),%rbx        # 237e0 <fwp_heap>
    9636:	eb 3a                	jmp    9672 <f12+0xce2>
    9638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    963f:	00 
    9640:	41 80 f9 01          	cmp    $0x1,%r9b
    9644:	75 27                	jne    966d <f12+0xcdd>
    9646:	45 8b 48 18          	mov    0x18(%r8),%r9d
    964a:	0f b7 c0             	movzwl %ax,%eax
    964d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9651:	49 0f af c1          	imul   %r9,%rax
    9655:	48 c1 e8 20          	shr    $0x20,%rax
    9659:	4c 39 c0             	cmp    %r8,%rax
    965c:	73 0f                	jae    966d <f12+0xcdd>
    965e:	48 01 c7             	add    %rax,%rdi
    9661:	80 3f ff             	cmpb   $0xff,(%rdi)
    9664:	0f 84 c6 02 00 00    	je     9930 <f12+0xfa0>
    966a:	c6 07 01             	movb   $0x1,(%rdi)
    966d:	4d 39 fd             	cmp    %r15,%r13
    9670:	73 7e                	jae    96f0 <f12+0xd60>
    9672:	49 83 ef 01          	sub    $0x1,%r15
    9676:	66 49 0f 6e ec       	movq   %r12,%xmm5
    967b:	48 8b 34 24          	mov    (%rsp),%rsi
    967f:	bf 01 00 00 00       	mov    $0x1,%edi
    9684:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    968a:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    968e:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9695:	00 
    9696:	e8 45 d3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    969b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    96a2:	49 89 c4             	mov    %rax,%r12
    96a5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    96ac:	48 c1 e7 10          	shl    $0x10,%rdi
    96b0:	48 39 f8             	cmp    %rdi,%rax
    96b3:	73 b8                	jae    966d <f12+0xcdd>
    96b5:	48 89 c7             	mov    %rax,%rdi
    96b8:	48 c1 ef 10          	shr    $0x10,%rdi
    96bc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    96c0:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    96c7:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    96cb:	49 8b 78 20          	mov    0x20(%r8),%rdi
    96cf:	48 85 ff             	test   %rdi,%rdi
    96d2:	74 99                	je     966d <f12+0xcdd>
    96d4:	45 0f b6 08          	movzbl (%r8),%r9d
    96d8:	41 80 f9 02          	cmp    $0x2,%r9b
    96dc:	0f 85 5e ff ff ff    	jne    9640 <f12+0xcb0>
    96e2:	66 85 c0             	test   %ax,%ax
    96e5:	0f 84 76 ff ff ff    	je     9661 <f12+0xcd1>
    96eb:	4d 39 fd             	cmp    %r15,%r13
    96ee:	72 82                	jb     9672 <f12+0xce2>
    96f0:	4d 85 ed             	test   %r13,%r13
    96f3:	75 2e                	jne    9723 <f12+0xd93>
    96f5:	8b 44 24 20          	mov    0x20(%rsp),%eax
    96f9:	85 c0                	test   %eax,%eax
    96fb:	4d 0f 45 f5          	cmovne %r13,%r14
    96ff:	eb 6f                	jmp    9770 <f12+0xde0>
    9701:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9708:	66 85 d2             	test   %dx,%dx
    970b:	0f 84 fe fe ff ff    	je     960f <f12+0xc7f>
    9711:	49 39 c5             	cmp    %rax,%r13
    9714:	0f 82 03 ff ff ff    	jb     961d <f12+0xc8d>
    971a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9720:	45 31 e4             	xor    %r12d,%r12d
    9723:	4c 89 f2             	mov    %r14,%rdx
    9726:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    972a:	48 89 e8             	mov    %rbp,%rax
    972d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9734:	00 
    9735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    973c:	00 00 00 00 
    9740:	48 8b 0a             	mov    (%rdx),%rcx
    9743:	48 83 c2 08          	add    $0x8,%rdx
    9747:	48 89 c7             	mov    %rax,%rdi
    974a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    974e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9752:	4c 39 c2             	cmp    %r8,%rdx
    9755:	75 e9                	jne    9740 <f12+0xdb0>
    9757:	8b 54 24 20          	mov    0x20(%rsp),%edx
    975b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    975f:	85 d2                	test   %edx,%edx
    9761:	0f 84 a9 02 00 00    	je     9a10 <f12+0x1080>
    9767:	49 89 ec             	mov    %rbp,%r12
    976a:	45 31 f6             	xor    %r14d,%r14d
    976d:	48 89 c5             	mov    %rax,%rbp
    9770:	4c 89 f7             	mov    %r14,%rdi
    9773:	e8 18 c0 ff ff       	call   5790 <fwp_mem_free>
    9778:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    977d:	e8 be e3 ff ff       	call   7b40 <fwp_drop4>
    9782:	48 89 ef             	mov    %rbp,%rdi
    9785:	e8 c6 d7 ff ff       	call   6f50 <fwp_drop0>
    978a:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    9791:	00 
    9792:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9799:	00 00 
    979b:	0f 85 e4 04 00 00    	jne    9c85 <f12+0x12f5>
    97a1:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    97a8:	4c 89 e0             	mov    %r12,%rax
    97ab:	5b                   	pop    %rbx
    97ac:	5d                   	pop    %rbp
    97ad:	41 5c                	pop    %r12
    97af:	41 5d                	pop    %r13
    97b1:	41 5e                	pop    %r14
    97b3:	41 5f                	pop    %r15
    97b5:	c3                   	ret
    97b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    97bd:	00 00 00 
    97c0:	66 85 c9             	test   %cx,%cx
    97c3:	0f 84 2c fd ff ff    	je     94f5 <f12+0xb65>
    97c9:	48 85 ed             	test   %rbp,%rbp
    97cc:	0f 84 18 03 00 00    	je     9aea <f12+0x115a>
    97d2:	48 89 e8             	mov    %rbp,%rax
    97d5:	45 31 e4             	xor    %r12d,%r12d
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 
    97e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    97e4:	4c 89 e2             	mov    %r12,%rdx
    97e7:	49 83 c4 01          	add    $0x1,%r12
    97eb:	48 85 c0             	test   %rax,%rax
    97ee:	75 f0                	jne    97e0 <f12+0xe50>
    97f0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    97f7:	ff ff 1f 
    97fa:	4c 39 e0             	cmp    %r12,%rax
    97fd:	0f 82 46 04 00 00    	jb     9c49 <f12+0x12b9>
    9803:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    980a:	00 
    980b:	be 02 00 00 00       	mov    $0x2,%esi
    9810:	e8 7b c4 ff ff       	call   5c90 <fwp_heap_alloc>
    9815:	4d 39 e7             	cmp    %r12,%r15
    9818:	48 89 ea             	mov    %rbp,%rdx
    981b:	49 89 c6             	mov    %rax,%r14
    981e:	4c 89 e0             	mov    %r12,%rax
    9821:	49 0f 46 c7          	cmovbe %r15,%rax
    9825:	4c 89 f1             	mov    %r14,%rcx
    9828:	66 90                	xchg   %ax,%ax
    982a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9831:	00 00 00 00 
    9835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    983c:	00 00 00 00 
    9840:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9844:	48 83 c1 08          	add    $0x8,%rcx
    9848:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    984c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9850:	48 85 d2             	test   %rdx,%rdx
    9853:	75 eb                	jne    9840 <f12+0xeb0>
    9855:	48 85 c0             	test   %rax,%rax
    9858:	0f 84 9e 02 00 00    	je     9afc <f12+0x116c>
    985e:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    9865:	00 
    9866:	e9 b2 fc ff ff       	jmp    951d <f12+0xb8d>
    986b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9870:	66 85 c0             	test   %ax,%ax
    9873:	0f 84 5d fb ff ff    	je     93d6 <f12+0xa46>
    9879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9880:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9887:	ff ff 1f 
    988a:	4c 39 f0             	cmp    %r14,%rax
    988d:	0f 82 ce 03 00 00    	jb     9c61 <f12+0x12d1>
    9893:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    989a:	00 
    989b:	be 01 00 00 00       	mov    $0x1,%esi
    98a0:	e8 eb c3 ff ff       	call   5c90 <fwp_heap_alloc>
    98a5:	4c 89 30             	mov    %r14,(%rax)
    98a8:	48 8b 15 09 b3 01 00 	mov    0x1b309(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    98af:	49 89 c5             	mov    %rax,%r13
    98b2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    98b7:	48 2b 05 d2 b2 01 00 	sub    0x1b2d2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    98be:	48 c1 e2 10          	shl    $0x10,%rdx
    98c2:	48 39 d0             	cmp    %rdx,%rax
    98c5:	73 57                	jae    991e <f12+0xf8e>
    98c7:	48 89 c2             	mov    %rax,%rdx
    98ca:	48 c1 ea 10          	shr    $0x10,%rdx
    98ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98d2:	48 8b 15 ff b2 01 00 	mov    0x1b2ff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    98d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98dd:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    98e1:	4d 85 ff             	test   %r15,%r15
    98e4:	74 38                	je     991e <f12+0xf8e>
    98e6:	0f b6 0a             	movzbl (%rdx),%ecx
    98e9:	80 f9 02             	cmp    $0x2,%cl
    98ec:	0f 84 16 02 00 00    	je     9b08 <f12+0x1178>
    98f2:	80 f9 01             	cmp    $0x1,%cl
    98f5:	75 27                	jne    991e <f12+0xf8e>
    98f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98fa:	0f b7 c0             	movzwl %ax,%eax
    98fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9900:	48 0f af c1          	imul   %rcx,%rax
    9904:	48 c1 e8 20          	shr    $0x20,%rax
    9908:	48 39 d0             	cmp    %rdx,%rax
    990b:	73 11                	jae    991e <f12+0xf8e>
    990d:	49 01 c7             	add    %rax,%r15
    9910:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9914:	0f 84 b3 02 00 00    	je     9bcd <f12+0x123d>
    991a:	41 c6 07 01          	movb   $0x1,(%r15)
    991e:	4c 89 e7             	mov    %r12,%rdi
    9921:	e9 c3 fa ff ff       	jmp    93e9 <f12+0xa59>
    9926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    992d:	00 00 00 
    9930:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
    9935:	e8 16 bc ff ff       	call   5550 <fwp_rc_forget_slot>
    993a:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    993f:	e9 26 fd ff ff       	jmp    966a <f12+0xcda>
    9944:	0f 1f 40 00          	nopl   0x0(%rax)
    9948:	48 8d 3d 31 db ff ff 	lea    -0x24cf(%rip),%rdi        # 7480 <fwp_tape_finish>
    994f:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9954:	e8 77 56 00 00       	call   efd0 <atexit>
    9959:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    995e:	85 c0                	test   %eax,%eax
    9960:	75 62                	jne    99c4 <f12+0x1034>
    9962:	c7 05 14 97 00 00 01 	movl   $0x1,0x9714(%rip)        # 13080 <registered_finish.0>
    9969:	00 00 00 
    996c:	e9 53 f1 ff ff       	jmp    8ac4 <f12+0x134>
    9971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9978:	66 85 c0             	test   %ax,%ax
    997b:	0f 85 ef f0 ff ff    	jne    8a70 <f12+0xe0>
    9981:	e9 d6 f0 ff ff       	jmp    8a5c <f12+0xcc>
    9986:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    998d:	00 00 00 
    9990:	49 89 dc             	mov    %rbx,%r12
    9993:	4c 39 f3             	cmp    %r14,%rbx
    9996:	0f 8f 59 f7 ff ff    	jg     90f5 <f12+0x765>
    999c:	4d 85 e4             	test   %r12,%r12
    999f:	0f 84 bd f7 ff ff    	je     9162 <f12+0x7d2>
    99a5:	4d 85 ff             	test   %r15,%r15
    99a8:	0f 85 ab f7 ff ff    	jne    9159 <f12+0x7c9>
    99ae:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    99b3:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    99b8:	48 89 05 b9 ba 01 00 	mov    %rax,0x1bab9(%rip)        # 25478 <fwp_cleanups>
    99bf:	e8 ac b6 ff ff       	call   5070 <fwp_tape_buffers_release>
    99c4:	48 8b 0d 95 96 00 00 	mov    0x9695(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    99cb:	ba 13 00 00 00       	mov    $0x13,%edx
    99d0:	be 01 00 00 00       	mov    $0x1,%esi
    99d5:	48 8d 3d 2c 56 00 00 	lea    0x562c(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    99dc:	e8 9f 9c ff ff       	call   3680 <fwrite@plt>
    99e1:	31 ff                	xor    %edi,%edi
    99e3:	e8 d8 9b ff ff       	call   35c0 <fflush@plt>
    99e8:	bf 66 00 00 00       	mov    $0x66,%edi
    99ed:	e8 ae 9c ff ff       	call   36a0 <_Exit@plt>
    99f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99f8:	66 85 c0             	test   %ax,%ax
    99fb:	0f 85 2a f9 ff ff    	jne    932b <f12+0x99b>
    9a01:	e9 19 f9 ff ff       	jmp    931f <f12+0x98f>
    9a06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a0d:	00 00 00 
    9a10:	49 89 ec             	mov    %rbp,%r12
    9a13:	48 89 c5             	mov    %rax,%rbp
    9a16:	e9 55 fd ff ff       	jmp    9770 <f12+0xde0>
    9a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9a20:	66 0f 6f 0d 98 96 01 	movdqa 0x19698(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9a27:	00 
    9a28:	48 c7 05 75 96 01 00 	movq   $0x0,0x19675(%rip)        # 230a8 <fwp_tape_cached_bytes>
    9a2f:	00 00 00 00 
    9a33:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    9a38:	48 8b 05 a1 96 01 00 	mov    0x196a1(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    9a3f:	66 0f 6f 0d 89 96 01 	movdqa 0x19689(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9a46:	00 
    9a47:	49 89 46 40          	mov    %rax,0x40(%r14)
    9a4b:	48 8b 05 96 96 01 00 	mov    0x19696(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9a52:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9a57:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9a5b:	49 89 46 18          	mov    %rax,0x18(%r14)
    9a5f:	48 8b 05 8a 96 01 00 	mov    0x1968a(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    9a66:	0f 29 0d 53 96 01 00 	movaps %xmm1,0x19653(%rip)        # 230c0 <fwp_tape_workspace>
    9a6d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9a71:	0f 29 0d 58 96 01 00 	movaps %xmm1,0x19658(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    9a78:	48 c7 05 6d 96 01 00 	movq   $0x0,0x1966d(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    9a7f:	00 00 00 00 
    9a83:	0f 29 0d 56 96 01 00 	movaps %xmm1,0x19656(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    9a8a:	e9 59 f1 ff ff       	jmp    8be8 <f12+0x258>
    9a8f:	90                   	nop
    9a90:	4d 85 ff             	test   %r15,%r15
    9a93:	0f 84 15 ff ff ff    	je     99ae <f12+0x101e>
    9a99:	4d 89 e6             	mov    %r12,%r14
    9a9c:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9aa3:	00 
    9aa4:	31 f6                	xor    %esi,%esi
    9aa6:	4c 89 ff             	mov    %r15,%rdi
    9aa9:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    9aae:	49 29 de             	sub    %rbx,%r14
    9ab1:	e8 0a 9a ff ff       	call   34c0 <memset@plt>
    9ab6:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    9abb:	e9 b7 f6 ff ff       	jmp    9177 <f12+0x7e7>
    9ac0:	49 89 dc             	mov    %rbx,%r12
    9ac3:	e9 2d f6 ff ff       	jmp    90f5 <f12+0x765>
    9ac8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9acf:	00 
    9ad0:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    9ad5:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9ada:	49 39 c6             	cmp    %rax,%r14
    9add:	4c 0f 4f f0          	cmovg  %rax,%r14
    9ae1:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    9ae5:	e9 57 f0 ff ff       	jmp    8b41 <f12+0x1b1>
    9aea:	be 02 00 00 00       	mov    $0x2,%esi
    9aef:	bf 08 00 00 00       	mov    $0x8,%edi
    9af4:	e8 97 c1 ff ff       	call   5c90 <fwp_heap_alloc>
    9af9:	49 89 c6             	mov    %rax,%r14
    9afc:	45 31 e4             	xor    %r12d,%r12d
    9aff:	e9 6c fc ff ff       	jmp    9770 <f12+0xde0>
    9b04:	0f 1f 40 00          	nopl   0x0(%rax)
    9b08:	66 85 c0             	test   %ax,%ax
    9b0b:	0f 85 0d fe ff ff    	jne    991e <f12+0xf8e>
    9b11:	e9 fa fd ff ff       	jmp    9910 <f12+0xf80>
    9b16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b1d:	00 00 00 
    9b20:	4d 85 e4             	test   %r12,%r12
    9b23:	0f 85 4e f2 ff ff    	jne    8d77 <f12+0x3e7>
    9b29:	e9 d1 f2 ff ff       	jmp    8dff <f12+0x46f>
    9b2e:	66 90                	xchg   %ax,%ax
    9b30:	be 08 00 00 00       	mov    $0x8,%esi
    9b35:	4c 89 f7             	mov    %r14,%rdi
    9b38:	e8 e3 99 ff ff       	call   3520 <calloc@plt>
    9b3d:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    9b42:	49 89 c7             	mov    %rax,%r15
    9b45:	e9 f6 f5 ff ff       	jmp    9140 <f12+0x7b0>
    9b4a:	31 ff                	xor    %edi,%edi
    9b4c:	e8 ff a6 ff ff       	call   4250 <descent_phase_step>
    9b51:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9b55:	e9 5c ef ff ff       	jmp    8ab6 <f12+0x126>
    9b5a:	49 8b 45 00          	mov    0x0(%r13),%rax
    9b5e:	48 85 c0             	test   %rax,%rax
    9b61:	78 87                	js     9aea <f12+0x115a>
    9b63:	48 8b 35 4e b0 01 00 	mov    0x1b04e(%rip),%rsi        # 24bb8 <fwp_heap+0x13d8>
    9b6a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9b6f:	48 2b 0d 1a b0 01 00 	sub    0x1b01a(%rip),%rcx        # 24b90 <fwp_heap+0x13b0>
    9b76:	48 c1 e6 10          	shl    $0x10,%rsi
    9b7a:	48 39 f1             	cmp    %rsi,%rcx
    9b7d:	0f 83 67 ff ff ff    	jae    9aea <f12+0x115a>
    9b83:	48 89 ce             	mov    %rcx,%rsi
    9b86:	48 c1 ee 10          	shr    $0x10,%rsi
    9b8a:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9b8e:	48 8b 35 43 b0 01 00 	mov    0x1b043(%rip),%rsi        # 24bd8 <fwp_heap+0x13f8>
    9b95:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9b99:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9b9d:	48 85 ff             	test   %rdi,%rdi
    9ba0:	0f 84 44 ff ff ff    	je     9aea <f12+0x115a>
    9ba6:	48 0f ba f0 3f       	btr    $0x3f,%rax
    9bab:	49 89 c7             	mov    %rax,%r15
    9bae:	e9 12 f9 ff ff       	jmp    94c5 <f12+0xb35>
    9bb3:	4c 89 f7             	mov    %r14,%rdi
    9bb6:	e8 95 b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9bbb:	e9 ae f1 ff ff       	jmp    8d6e <f12+0x3de>
    9bc0:	48 89 df             	mov    %rbx,%rdi
    9bc3:	e8 88 b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9bc8:	e9 5b f7 ff ff       	jmp    9328 <f12+0x998>
    9bcd:	4c 89 ff             	mov    %r15,%rdi
    9bd0:	e8 7b b9 ff ff       	call   5550 <fwp_rc_forget_slot>
    9bd5:	e9 40 fd ff ff       	jmp    991a <f12+0xf8a>
    9bda:	e8 51 b8 ff ff       	call   5430 <fwp_rc_wide_dup>
    9bdf:	e9 8c ee ff ff       	jmp    8a70 <f12+0xe0>
    9be4:	4d 89 e6             	mov    %r12,%r14
    9be7:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9bee:	00 
    9bef:	31 f6                	xor    %esi,%esi
    9bf1:	4c 89 ff             	mov    %r15,%rdi
    9bf4:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
    9bf9:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    9bfe:	49 29 de             	sub    %rbx,%r14
    9c01:	e8 ba 98 ff ff       	call   34c0 <memset@plt>
    9c06:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    9c0b:	e9 5f f5 ff ff       	jmp    916f <f12+0x7df>
    9c10:	45 31 ed             	xor    %r13d,%r13d
    9c13:	e9 05 fa ff ff       	jmp    961d <f12+0xc8d>
    9c18:	48 8d 3d 48 55 00 00 	lea    0x5548(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    9c1f:	e8 cc a7 ff ff       	call   43f0 <fwp_trap>
    9c24:	48 8d 3d 85 5c 00 00 	lea    0x5c85(%rip),%rdi        # f8b0 <_IO_stdin_used+0x8b0>
    9c2b:	e8 c0 a7 ff ff       	call   43f0 <fwp_trap>
    9c30:	e8 cb 9a ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9c35:	48 8d 3d 7c 5d 00 00 	lea    0x5d7c(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    9c3c:	e8 af a7 ff ff       	call   43f0 <fwp_trap>
    9c41:	45 31 f6             	xor    %r14d,%r14d
    9c44:	e9 b3 fe ff ff       	jmp    9afc <f12+0x116c>
    9c49:	48 8d 3d 40 55 00 00 	lea    0x5540(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    9c50:	e8 9b a7 ff ff       	call   43f0 <fwp_trap>
    9c55:	48 8d 3d 42 55 00 00 	lea    0x5542(%rip),%rdi        # f19e <_IO_stdin_used+0x19e>
    9c5c:	e8 8f a7 ff ff       	call   43f0 <fwp_trap>
    9c61:	48 8d 3d 50 55 00 00 	lea    0x5550(%rip),%rdi        # f1b8 <_IO_stdin_used+0x1b8>
    9c68:	e8 83 a7 ff ff       	call   43f0 <fwp_trap>
    9c6d:	48 8d 3d 14 5d 00 00 	lea    0x5d14(%rip),%rdi        # f988 <_IO_stdin_used+0x988>
    9c74:	e8 77 a7 ff ff       	call   43f0 <fwp_trap>
    9c79:	48 8d 3d d8 5c 00 00 	lea    0x5cd8(%rip),%rdi        # f958 <_IO_stdin_used+0x958>
    9c80:	e8 6b a7 ff ff       	call   43f0 <fwp_trap>
    9c85:	e8 d6 97 ff ff       	call   3460 <__stack_chk_fail@plt>
    9c8a:	48 8d 3d 67 5c 00 00 	lea    0x5c67(%rip),%rdi        # f8f8 <_IO_stdin_used+0x8f8>
    9c91:	e8 5a a7 ff ff       	call   43f0 <fwp_trap>
    9c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c9d:	00 00 00 

0000000000009ca0 <fwp_owned_entry12>:
    9ca0:	f3 0f 1e fa          	endbr64
    9ca4:	48 8b 3f             	mov    (%rdi),%rdi
    9ca7:	e9 e4 ec ff ff       	jmp    8990 <f12>
    9cac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009cb0 <e12>:
    9cb0:	f3 0f 1e fa          	endbr64
    9cb4:	53                   	push   %rbx
    9cb5:	48 8b 1f             	mov    (%rdi),%rbx
    9cb8:	48 89 df             	mov    %rbx,%rdi
    9cbb:	e8 50 ce ff ff       	call   6b10 <fwp_rc_share>
    9cc0:	48 89 df             	mov    %rbx,%rdi
    9cc3:	e8 c8 ec ff ff       	call   8990 <f12>
    9cc8:	48 89 c3             	mov    %rax,%rbx
    9ccb:	48 89 c7             	mov    %rax,%rdi
    9cce:	e8 3d ce ff ff       	call   6b10 <fwp_rc_share>
    9cd3:	48 89 d8             	mov    %rbx,%rax
    9cd6:	5b                   	pop    %rbx
    9cd7:	c3                   	ret
    9cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9cdf:	00 

0000000000009ce0 <fwp_write>:
    9ce0:	41 57                	push   %r15
    9ce2:	41 56                	push   %r14
    9ce4:	41 55                	push   %r13
    9ce6:	41 54                	push   %r12
    9ce8:	55                   	push   %rbp
    9ce9:	53                   	push   %rbx
    9cea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9cf1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9cf8:	00 00 
    9cfa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9d01:	00 
    9d02:	49 89 d4             	mov    %rdx,%r12
    9d05:	8b 12                	mov    (%rdx),%edx
    9d07:	83 fa 19             	cmp    $0x19,%edx
    9d0a:	77 6a                	ja     9d76 <fwp_write+0x96>
    9d0c:	48 89 f5             	mov    %rsi,%rbp
    9d0f:	89 d0                	mov    %edx,%eax
    9d11:	89 ce                	mov    %ecx,%esi
    9d13:	48 89 fb             	mov    %rdi,%rbx
    9d16:	48 8d 0d e3 5d 00 00 	lea    0x5de3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    9d1d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9d21:	48 01 c8             	add    %rcx,%rax
    9d24:	3e ff e0             	notrack jmp *%rax
    9d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d2e:	00 00 
    9d30:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9d34:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9d38:	48 89 ca             	mov    %rcx,%rdx
    9d3b:	48 85 c9             	test   %rcx,%rcx
    9d3e:	0f 88 9c 0c 00 00    	js     a9e0 <fwp_write+0xd00>
    9d44:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9d4b:	00 
    9d4c:	48 89 c6             	mov    %rax,%rsi
    9d4f:	4c 89 e7             	mov    %r12,%rdi
    9d52:	e8 e9 9c ff ff       	call   3a40 <fwp_fmt_u128>
    9d57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d5e:	00 00 
    9d60:	4c 89 e7             	mov    %r12,%rdi
    9d63:	e8 e8 96 ff ff       	call   3450 <strlen@plt>
    9d68:	4c 89 e6             	mov    %r12,%rsi
    9d6b:	48 89 df             	mov    %rbx,%rdi
    9d6e:	48 89 c2             	mov    %rax,%rdx
    9d71:	e8 9a a4 ff ff       	call   4210 <buf_put>
    9d76:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9d7d:	00 
    9d7e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9d85:	00 00 
    9d87:	0f 85 28 04 00 00    	jne    a1b5 <fwp_write+0x4d5>
    9d8d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9d94:	5b                   	pop    %rbx
    9d95:	5d                   	pop    %rbp
    9d96:	41 5c                	pop    %r12
    9d98:	41 5d                	pop    %r13
    9d9a:	41 5e                	pop    %r14
    9d9c:	41 5f                	pop    %r15
    9d9e:	c3                   	ret
    9d9f:	90                   	nop
    9da0:	49 89 e9             	mov    %rbp,%r9
    9da3:	4c 8d 05 cb 52 00 00 	lea    0x52cb(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    9daa:	b9 00 02 00 00       	mov    $0x200,%ecx
    9daf:	ba 02 00 00 00       	mov    $0x2,%edx
    9db4:	be 00 02 00 00       	mov    $0x200,%esi
    9db9:	31 c0                	xor    %eax,%eax
    9dbb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9dc2:	00 
    9dc3:	e8 e8 95 ff ff       	call   33b0 <__snprintf_chk@plt>
    9dc8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9dcf:	00 
    9dd0:	e8 7b 96 ff ff       	call   3450 <strlen@plt>
    9dd5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9ddc:	00 
    9ddd:	48 89 df             	mov    %rbx,%rdi
    9de0:	48 89 c2             	mov    %rax,%rdx
    9de3:	e8 28 a4 ff ff       	call   4210 <buf_put>
    9de8:	eb 8c                	jmp    9d76 <fwp_write+0x96>
    9dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9df0:	49 89 e9             	mov    %rbp,%r9
    9df3:	4c 8d 05 e5 53 00 00 	lea    0x53e5(%rip),%r8        # f1df <_IO_stdin_used+0x1df>
    9dfa:	eb ae                	jmp    9daa <fwp_write+0xca>
    9dfc:	0f 1f 40 00          	nopl   0x0(%rax)
    9e00:	83 fa 13             	cmp    $0x13,%edx
    9e03:	48 8d 05 cb 53 00 00 	lea    0x53cb(%rip),%rax        # f1d5 <_IO_stdin_used+0x1d5>
    9e0a:	48 8d 35 c9 53 00 00 	lea    0x53c9(%rip),%rsi        # f1da <_IO_stdin_used+0x1da>
    9e11:	ba 04 00 00 00       	mov    $0x4,%edx
    9e16:	48 0f 44 f0          	cmove  %rax,%rsi
    9e1a:	45 31 ed             	xor    %r13d,%r13d
    9e1d:	e8 ee a3 ff ff       	call   4210 <buf_put>
    9e22:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9e27:	0f 84 a3 08 00 00    	je     a6d0 <fwp_write+0x9f0>
    9e2d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9e32:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9e37:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9e3c:	48 89 df             	mov    %rbx,%rdi
    9e3f:	49 0f 44 c5          	cmove  %r13,%rax
    9e43:	31 c9                	xor    %ecx,%ecx
    9e45:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9e4a:	e8 91 fe ff ff       	call   9ce0 <fwp_write>
    9e4f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9e54:	0f 84 6e 09 00 00    	je     a7c8 <fwp_write+0xae8>
    9e5a:	49 83 c5 01          	add    $0x1,%r13
    9e5e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9e62:	0f 83 68 08 00 00    	jae    a6d0 <fwp_write+0x9f0>
    9e68:	ba 02 00 00 00       	mov    $0x2,%edx
    9e6d:	48 8d 35 ab 53 00 00 	lea    0x53ab(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    9e74:	48 89 df             	mov    %rbx,%rdi
    9e77:	e8 94 a3 ff ff       	call   4210 <buf_put>
    9e7c:	eb af                	jmp    9e2d <fwp_write+0x14d>
    9e7e:	66 90                	xchg   %ax,%ax
    9e80:	ba 06 00 00 00       	mov    $0x6,%edx
    9e85:	48 8d 35 6c 53 00 00 	lea    0x536c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    9e8c:	48 83 c5 10          	add    $0x10,%rbp
    9e90:	e8 7b a3 ff ff       	call   4210 <buf_put>
    9e95:	48 89 ef             	mov    %rbp,%rdi
    9e98:	e8 b3 95 ff ff       	call   3450 <strlen@plt>
    9e9d:	48 89 ee             	mov    %rbp,%rsi
    9ea0:	48 89 df             	mov    %rbx,%rdi
    9ea3:	48 89 c2             	mov    %rax,%rdx
    9ea6:	e8 65 a3 ff ff       	call   4210 <buf_put>
    9eab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9eb0:	ba 01 00 00 00       	mov    $0x1,%edx
    9eb5:	48 89 df             	mov    %rbx,%rdi
    9eb8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9ebd:	e8 4e a3 ff ff       	call   4210 <buf_put>
    9ec2:	e9 af fe ff ff       	jmp    9d76 <fwp_write+0x96>
    9ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ece:	00 00 
    9ed0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9ed7:	00 
    9ed8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9edf:	00 00 
    9ee1:	0f 85 ce 02 00 00    	jne    a1b5 <fwp_write+0x4d5>
    9ee7:	ba 0a 00 00 00       	mov    $0xa,%edx
    9eec:	48 8d 35 f1 52 00 00 	lea    0x52f1(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    9ef3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9efa:	48 89 df             	mov    %rbx,%rdi
    9efd:	5b                   	pop    %rbx
    9efe:	5d                   	pop    %rbp
    9eff:	41 5c                	pop    %r12
    9f01:	41 5d                	pop    %r13
    9f03:	41 5e                	pop    %r14
    9f05:	41 5f                	pop    %r15
    9f07:	e9 04 a3 ff ff       	jmp    4210 <buf_put>
    9f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f10:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9f15:	4d 85 ed             	test   %r13,%r13
    9f18:	0f 84 02 0c 00 00    	je     ab20 <fwp_write+0xe40>
    9f1e:	48 8d 35 07 53 00 00 	lea    0x5307(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    9f25:	4c 89 ef             	mov    %r13,%rdi
    9f28:	e8 03 96 ff ff       	call   3530 <strcmp@plt>
    9f2d:	41 89 c1             	mov    %eax,%r9d
    9f30:	85 c0                	test   %eax,%eax
    9f32:	0f 84 6c 0c 00 00    	je     aba4 <fwp_write+0xec4>
    9f38:	4c 89 ef             	mov    %r13,%rdi
    9f3b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9f40:	e8 0b 95 ff ff       	call   3450 <strlen@plt>
    9f45:	4c 89 ee             	mov    %r13,%rsi
    9f48:	48 89 df             	mov    %rbx,%rdi
    9f4b:	48 89 c2             	mov    %rax,%rdx
    9f4e:	e8 bd a2 ff ff       	call   4210 <buf_put>
    9f53:	ba 01 00 00 00       	mov    $0x1,%edx
    9f58:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9f5d:	48 89 df             	mov    %rbx,%rdi
    9f60:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9f65:	e8 a6 a2 ff ff       	call   4210 <buf_put>
    9f6a:	ba 01 00 00 00       	mov    $0x1,%edx
    9f6f:	4c 89 fe             	mov    %r15,%rsi
    9f72:	48 89 df             	mov    %rbx,%rdi
    9f75:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    9f7a:	e8 91 a2 ff ff       	call   4210 <buf_put>
    9f7f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9f84:	45 31 f6             	xor    %r14d,%r14d
    9f87:	85 d2                	test   %edx,%edx
    9f89:	0f 8e 81 0a 00 00    	jle    aa10 <fwp_write+0xd30>
    9f8f:	45 31 ed             	xor    %r13d,%r13d
    9f92:	4d 85 ed             	test   %r13,%r13
    9f95:	0f 85 75 07 00 00    	jne    a710 <fwp_write+0xa30>
    9f9b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9fa2:	00 
    9fa3:	45 85 f6             	test   %r14d,%r14d
    9fa6:	0f 84 84 07 00 00    	je     a730 <fwp_write+0xa50>
    9fac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9fb1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9fb6:	48 89 df             	mov    %rbx,%rdi
    9fb9:	49 83 c5 01          	add    $0x1,%r13
    9fbd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9fc1:	31 c9                	xor    %ecx,%ecx
    9fc3:	e8 18 fd ff ff       	call   9ce0 <fwp_write>
    9fc8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9fcd:	7f c3                	jg     9f92 <fwp_write+0x2b2>
    9fcf:	45 85 f6             	test   %r14d,%r14d
    9fd2:	0f 84 38 0a 00 00    	je     aa10 <fwp_write+0xd30>
    9fd8:	b8 29 00 00 00       	mov    $0x29,%eax
    9fdd:	ba 01 00 00 00       	mov    $0x1,%edx
    9fe2:	4c 89 fe             	mov    %r15,%rsi
    9fe5:	48 89 df             	mov    %rbx,%rdi
    9fe8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9fec:	e8 1f a2 ff ff       	call   4210 <buf_put>
    9ff1:	e9 80 fd ff ff       	jmp    9d76 <fwp_write+0x96>
    9ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9ffd:	00 00 00 
    a000:	ba 01 00 00 00       	mov    $0x1,%edx
    a005:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a00a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a00f:	e8 fc a1 ff ff       	call   4210 <buf_put>
    a014:	48 85 ed             	test   %rbp,%rbp
    a017:	0f 84 93 06 00 00    	je     a6b0 <fwp_write+0x9d0>
    a01d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a021:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a026:	31 c9                	xor    %ecx,%ecx
    a028:	48 89 df             	mov    %rbx,%rdi
    a02b:	e8 b0 fc ff ff       	call   9ce0 <fwp_write>
    a030:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a034:	48 85 ed             	test   %rbp,%rbp
    a037:	0f 84 73 06 00 00    	je     a6b0 <fwp_write+0x9d0>
    a03d:	ba 02 00 00 00       	mov    $0x2,%edx
    a042:	48 8d 35 d6 51 00 00 	lea    0x51d6(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a049:	48 89 df             	mov    %rbx,%rdi
    a04c:	e8 bf a1 ff ff       	call   4210 <buf_put>
    a051:	eb ca                	jmp    a01d <fwp_write+0x33d>
    a053:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a058:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a05c:	85 f6                	test   %esi,%esi
    a05e:	0f 84 fc 07 00 00    	je     a860 <fwp_write+0xb80>
    a064:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a06b:	00 
    a06c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a073:	00 00 
    a075:	0f 85 3a 01 00 00    	jne    a1b5 <fwp_write+0x4d5>
    a07b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a07f:	4c 89 ea             	mov    %r13,%rdx
    a082:	e9 6c fe ff ff       	jmp    9ef3 <fwp_write+0x213>
    a087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a08e:	00 00 
    a090:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a095:	ba 01 00 00 00       	mov    $0x1,%edx
    a09a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a09f:	48 89 ee             	mov    %rbp,%rsi
    a0a2:	e8 69 a1 ff ff       	call   4210 <buf_put>
    a0a7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a0ac:	4c 89 e7             	mov    %r12,%rdi
    a0af:	e8 9c 93 ff ff       	call   3450 <strlen@plt>
    a0b4:	4c 89 e6             	mov    %r12,%rsi
    a0b7:	48 89 df             	mov    %rbx,%rdi
    a0ba:	48 89 c2             	mov    %rax,%rdx
    a0bd:	e8 4e a1 ff ff       	call   4210 <buf_put>
    a0c2:	ba 01 00 00 00       	mov    $0x1,%edx
    a0c7:	48 89 ee             	mov    %rbp,%rsi
    a0ca:	48 89 df             	mov    %rbx,%rdi
    a0cd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a0d2:	e8 39 a1 ff ff       	call   4210 <buf_put>
    a0d7:	e9 9a fc ff ff       	jmp    9d76 <fwp_write+0x96>
    a0dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a0e0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a0e5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a0e9:	0f 8a 8e 0b 00 00    	jp     ac7d <fwp_write+0xf9d>
    a0ef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a0f3:	66 0f 54 05 05 5b 00 	andpd  0x5b05(%rip),%xmm0        # fc00 <msg.4+0x90>
    a0fa:	00 
    a0fb:	bd 01 00 00 00       	mov    $0x1,%ebp
    a100:	66 0f 2e 05 38 5b 00 	ucomisd 0x5b38(%rip),%xmm0        # fc40 <msg.4+0xd0>
    a107:	00 
    a108:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a10f:	00 
    a110:	0f 87 b2 09 00 00    	ja     aac8 <fwp_write+0xde8>
    a116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a11d:	00 00 00 
    a120:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a124:	89 ee                	mov    %ebp,%esi
    a126:	4c 89 e7             	mov    %r12,%rdi
    a129:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a12e:	e8 dd a5 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a133:	31 f6                	xor    %esi,%esi
    a135:	4c 89 e7             	mov    %r12,%rdi
    a138:	e8 d3 92 ff ff       	call   3410 <strtod@plt>
    a13d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a142:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a146:	7a 06                	jp     a14e <fwp_write+0x46e>
    a148:	0f 84 e9 01 00 00    	je     a337 <fwp_write+0x657>
    a14e:	83 c5 01             	add    $0x1,%ebp
    a151:	83 fd 12             	cmp    $0x12,%ebp
    a154:	75 ca                	jne    a120 <fwp_write+0x440>
    a156:	be 11 00 00 00       	mov    $0x11,%esi
    a15b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a15f:	4c 89 e7             	mov    %r12,%rdi
    a162:	e8 a9 a5 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a167:	e9 cb 01 00 00       	jmp    a337 <fwp_write+0x657>
    a16c:	0f 1f 40 00          	nopl   0x0(%rax)
    a170:	48 83 fd 01          	cmp    $0x1,%rbp
    a174:	0f 84 e6 08 00 00    	je     aa60 <fwp_write+0xd80>
    a17a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a17e:	b8 02 00 00 00       	mov    $0x2,%eax
    a183:	ba 01 00 00 00       	mov    $0x1,%edx
    a188:	48 0f 44 d0          	cmove  %rax,%rdx
    a18c:	48 8d 35 3a 50 00 00 	lea    0x503a(%rip),%rsi        # f1cd <_IO_stdin_used+0x1cd>
    a193:	48 8d 05 38 50 00 00 	lea    0x5038(%rip),%rax        # f1d2 <_IO_stdin_used+0x1d2>
    a19a:	48 0f 44 f0          	cmove  %rax,%rsi
    a19e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1a5:	00 
    a1a6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1ad:	00 00 
    a1af:	0f 84 3e fd ff ff    	je     9ef3 <fwp_write+0x213>
    a1b5:	e8 a6 92 ff ff       	call   3460 <__stack_chk_fail@plt>
    a1ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a1c0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a1c5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a1ca:	e8 81 9f ff ff       	call   4150 <buf_grow>
    a1cf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a1d3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a1d9:	4c 03 0b             	add    (%rbx),%r9
    a1dc:	66 45 89 11          	mov    %r10w,(%r9)
    a1e0:	45 85 e4             	test   %r12d,%r12d
    a1e3:	0f 8e 07 05 00 00    	jle    a6f0 <fwp_write+0xa10>
    a1e9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a1f0:	55 55 55 
    a1f3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a1f8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a1ff:	aa aa aa 
    a202:	49 83 c1 01          	add    $0x1,%r9
    a206:	eb 45                	jmp    a24d <fwp_write+0x56d>
    a208:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a20f:	00 
    a210:	be 01 00 00 00       	mov    $0x1,%esi
    a215:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a21a:	88 07                	mov    %al,(%rdi)
    a21c:	48 89 e8             	mov    %rbp,%rax
    a21f:	49 f7 e8             	imul   %r8
    a222:	48 89 e8             	mov    %rbp,%rax
    a225:	48 c1 f8 3f          	sar    $0x3f,%rax
    a229:	48 29 c2             	sub    %rax,%rdx
    a22c:	48 85 c9             	test   %rcx,%rcx
    a22f:	0f 95 c0             	setne  %al
    a232:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a236:	48 83 ef 01          	sub    $0x1,%rdi
    a23a:	48 21 c5             	and    %rax,%rbp
    a23d:	48 29 ea             	sub    %rbp,%rdx
    a240:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a244:	49 39 f9             	cmp    %rdi,%r9
    a247:	0f 84 a3 04 00 00    	je     a6f0 <fwp_write+0xa10>
    a24d:	48 89 e8             	mov    %rbp,%rax
    a250:	49 f7 e8             	imul   %r8
    a253:	48 89 e8             	mov    %rbp,%rax
    a256:	48 c1 f8 3f          	sar    $0x3f,%rax
    a25a:	48 89 d1             	mov    %rdx,%rcx
    a25d:	48 29 c1             	sub    %rax,%rcx
    a260:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a264:	48 89 e9             	mov    %rbp,%rcx
    a267:	48 29 c1             	sub    %rax,%rcx
    a26a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a26e:	49 f7 e2             	mul    %r10
    a271:	b8 30 00 00 00       	mov    $0x30,%eax
    a276:	48 89 d6             	mov    %rdx,%rsi
    a279:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a27d:	48 d1 ee             	shr    $1,%rsi
    a280:	48 01 f2             	add    %rsi,%rdx
    a283:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a287:	48 29 d6             	sub    %rdx,%rsi
    a28a:	74 8e                	je     a21a <fwp_write+0x53a>
    a28c:	48 83 fe 01          	cmp    $0x1,%rsi
    a290:	0f 85 7a ff ff ff    	jne    a210 <fwp_write+0x530>
    a296:	31 f6                	xor    %esi,%esi
    a298:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a29d:	e9 78 ff ff ff       	jmp    a21a <fwp_write+0x53a>
    a2a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    a2ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a2af:	0f 8a c8 09 00 00    	jp     ac7d <fwp_write+0xf9d>
    a2b5:	0f 28 c1             	movaps %xmm1,%xmm0
    a2b8:	0f 54 05 31 59 00 00 	andps  0x5931(%rip),%xmm0        # fbf0 <msg.4+0x80>
    a2bf:	0f 2e 05 3e 4d 00 00 	ucomiss 0x4d3e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    a2c6:	0f 87 24 08 00 00    	ja     aaf0 <fwp_write+0xe10>
    a2cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a2d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a2d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2dd:	00 
    a2de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a2e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a2e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2ee:	00 00 
    a2f0:	44 89 ee             	mov    %r13d,%esi
    a2f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a2f8:	4c 89 e7             	mov    %r12,%rdi
    a2fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a300:	e8 0b a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a305:	31 f6                	xor    %esi,%esi
    a307:	4c 89 e7             	mov    %r12,%rdi
    a30a:	e8 a1 91 ff ff       	call   34b0 <strtof@plt>
    a30f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a314:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a317:	7a 02                	jp     a31b <fwp_write+0x63b>
    a319:	74 1c                	je     a337 <fwp_write+0x657>
    a31b:	41 83 c5 01          	add    $0x1,%r13d
    a31f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a323:	75 cb                	jne    a2f0 <fwp_write+0x610>
    a325:	be 09 00 00 00       	mov    $0x9,%esi
    a32a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a32f:	4c 89 e7             	mov    %r12,%rdi
    a332:	e8 d9 a3 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a337:	4c 89 e7             	mov    %r12,%rdi
    a33a:	e8 41 a0 ff ff       	call   4380 <fwp_finish_float>
    a33f:	e9 1c fa ff ff       	jmp    9d60 <fwp_write+0x80>
    a344:	0f 1f 40 00          	nopl   0x0(%rax)
    a348:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a34c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a350:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a357:	00 
    a358:	48 89 ef             	mov    %rbp,%rdi
    a35b:	e8 e0 96 ff ff       	call   3a40 <fwp_fmt_u128>
    a360:	48 89 ef             	mov    %rbp,%rdi
    a363:	e8 e8 90 ff ff       	call   3450 <strlen@plt>
    a368:	48 89 ee             	mov    %rbp,%rsi
    a36b:	48 89 df             	mov    %rbx,%rdi
    a36e:	48 89 c2             	mov    %rax,%rdx
    a371:	e8 9a 9e ff ff       	call   4210 <buf_put>
    a376:	e9 fb f9 ff ff       	jmp    9d76 <fwp_write+0x96>
    a37b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a380:	ba 06 00 00 00       	mov    $0x6,%edx
    a385:	48 8d 35 96 4e 00 00 	lea    0x4e96(%rip),%rsi        # f222 <_IO_stdin_used+0x222>
    a38c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a392:	e8 79 9e ff ff       	call   4210 <buf_put>
    a397:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a39e:	ff ff 7f 
    a3a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    a3a5:	0f 84 86 02 00 00    	je     a631 <fwp_write+0x951>
    a3ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a3b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a3b4:	48 85 d2             	test   %rdx,%rdx
    a3b7:	0f 84 ae 00 00 00    	je     a46b <fwp_write+0x78b>
    a3bd:	8b 0a                	mov    (%rdx),%ecx
    a3bf:	83 f9 1c             	cmp    $0x1c,%ecx
    a3c2:	0f 84 58 06 00 00    	je     aa20 <fwp_write+0xd40>
    a3c8:	83 f9 1b             	cmp    $0x1b,%ecx
    a3cb:	0f 87 9a 00 00 00    	ja     a46b <fwp_write+0x78b>
    a3d1:	be 01 00 00 00       	mov    $0x1,%esi
    a3d6:	48 d3 e6             	shl    %cl,%rsi
    a3d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a3df:	0f 85 4b 04 00 00    	jne    a830 <fwp_write+0xb50>
    a3e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a3eb:	0f 85 0f 04 00 00    	jne    a800 <fwp_write+0xb20>
    a3f1:	83 e6 21             	and    $0x21,%esi
    a3f4:	74 75                	je     a46b <fwp_write+0x78b>
    a3f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a3fb:	48 85 ff             	test   %rdi,%rdi
    a3fe:	79 07                	jns    a407 <fwp_write+0x727>
    a400:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a404:	4c 01 ee             	add    %r13,%rsi
    a407:	48 0f be 3e          	movsbq (%rsi),%rdi
    a40b:	85 c9                	test   %ecx,%ecx
    a40d:	40 0f b6 f7          	movzbl %dil,%esi
    a411:	48 0f 44 f7          	cmove  %rdi,%rsi
    a415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a41c:	00 00 00 00 
    a420:	31 c9                	xor    %ecx,%ecx
    a422:	48 89 df             	mov    %rbx,%rdi
    a425:	49 83 c5 01          	add    $0x1,%r13
    a429:	e8 b2 f8 ff ff       	call   9ce0 <fwp_write>
    a42e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a435:	ff ff 7f 
    a438:	48 23 55 00          	and    0x0(%rbp),%rdx
    a43c:	49 39 d5             	cmp    %rdx,%r13
    a43f:	0f 83 ec 01 00 00    	jae    a631 <fwp_write+0x951>
    a445:	ba 02 00 00 00       	mov    $0x2,%edx
    a44a:	48 89 df             	mov    %rbx,%rdi
    a44d:	48 8d 35 cb 4d 00 00 	lea    0x4dcb(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a454:	e8 b7 9d ff ff       	call   4210 <buf_put>
    a459:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a45e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a462:	48 85 d2             	test   %rdx,%rdx
    a465:	0f 85 52 ff ff ff    	jne    a3bd <fwp_write+0x6dd>
    a46b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a470:	48 85 ff             	test   %rdi,%rdi
    a473:	0f 88 cf 05 00 00    	js     aa48 <fwp_write+0xd68>
    a479:	48 8b 31             	mov    (%rcx),%rsi
    a47c:	eb a2                	jmp    a420 <fwp_write+0x740>
    a47e:	66 90                	xchg   %ax,%ax
    a480:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a487:	00 
    a488:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a48f:	00 00 
    a491:	0f 85 1e fd ff ff    	jne    a1b5 <fwp_write+0x4d5>
    a497:	ba 08 00 00 00       	mov    $0x8,%edx
    a49c:	48 8d 35 4c 4d 00 00 	lea    0x4d4c(%rip),%rsi        # f1ef <_IO_stdin_used+0x1ef>
    a4a3:	e9 4b fa ff ff       	jmp    9ef3 <fwp_write+0x213>
    a4a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a4af:	00 
    a4b0:	89 e8                	mov    %ebp,%eax
    a4b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a4b9:	76 03                	jbe    a4be <fwp_write+0x7de>
    a4bb:	8b 45 00             	mov    0x0(%rbp),%eax
    a4be:	41 89 c6             	mov    %eax,%r14d
    a4c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a4c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a4cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a4cf:	4c 89 ef             	mov    %r13,%rdi
    a4d2:	e8 79 8f ff ff       	call   3450 <strlen@plt>
    a4d7:	4c 89 ee             	mov    %r13,%rsi
    a4da:	48 89 df             	mov    %rbx,%rdi
    a4dd:	48 89 c2             	mov    %rax,%rdx
    a4e0:	e8 2b 9d ff ff       	call   4210 <buf_put>
    a4e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a4ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a4ee:	85 f6                	test   %esi,%esi
    a4f0:	0f 8e 80 f8 ff ff    	jle    9d76 <fwp_write+0x96>
    a4f6:	45 31 ed             	xor    %r13d,%r13d
    a4f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a503:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a508:	ba 01 00 00 00       	mov    $0x1,%edx
    a50d:	4c 89 fe             	mov    %r15,%rsi
    a510:	48 89 04 24          	mov    %rax,(%rsp)
    a514:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a519:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a51d:	48 89 df             	mov    %rbx,%rdi
    a520:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a524:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a529:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a52e:	e8 dd 9c ff ff       	call   4210 <buf_put>
    a533:	41 8b 06             	mov    (%r14),%eax
    a536:	83 f8 0e             	cmp    $0xe,%eax
    a539:	0f 84 71 02 00 00    	je     a7b0 <fwp_write+0xad0>
    a53f:	83 f8 10             	cmp    $0x10,%eax
    a542:	0f 84 38 02 00 00    	je     a780 <fwp_write+0xaa0>
    a548:	83 f8 0a             	cmp    $0xa,%eax
    a54b:	0f 84 7f 04 00 00    	je     a9d0 <fwp_write+0xcf0>
    a551:	0f 8f f9 00 00 00    	jg     a650 <fwp_write+0x970>
    a557:	83 f8 03             	cmp    $0x3,%eax
    a55a:	0f 8f 50 04 00 00    	jg     a9b0 <fwp_write+0xcd0>
    a560:	85 c0                	test   %eax,%eax
    a562:	78 10                	js     a574 <fwp_write+0x894>
    a564:	48 8b 04 24          	mov    (%rsp),%rax
    a568:	48 c1 e8 3f          	shr    $0x3f,%rax
    a56c:	85 c0                	test   %eax,%eax
    a56e:	0f 85 f9 00 00 00    	jne    a66d <fwp_write+0x98d>
    a574:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a579:	48 8b 34 24          	mov    (%rsp),%rsi
    a57d:	31 c9                	xor    %ecx,%ecx
    a57f:	48 89 df             	mov    %rbx,%rdi
    a582:	e8 59 f7 ff ff       	call   9ce0 <fwp_write>
    a587:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a58c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a591:	49 83 c5 01          	add    $0x1,%r13
    a595:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a599:	0f 8f 5f ff ff ff    	jg     a4fe <fwp_write+0x81e>
    a59f:	e9 d2 f7 ff ff       	jmp    9d76 <fwp_write+0x96>
    a5a4:	0f 1f 40 00          	nopl   0x0(%rax)
    a5a8:	ba 06 00 00 00       	mov    $0x6,%edx
    a5ad:	48 8d 35 61 4c 00 00 	lea    0x4c61(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    a5b4:	45 31 ed             	xor    %r13d,%r13d
    a5b7:	e8 54 9c ff ff       	call   4210 <buf_put>
    a5bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a5c1:	75 19                	jne    a5dc <fwp_write+0x8fc>
    a5c3:	eb 6c                	jmp    a631 <fwp_write+0x951>
    a5c5:	0f 1f 00             	nopl   (%rax)
    a5c8:	ba 02 00 00 00       	mov    $0x2,%edx
    a5cd:	48 8d 35 4b 4c 00 00 	lea    0x4c4b(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a5d4:	48 89 df             	mov    %rbx,%rdi
    a5d7:	e8 34 9c ff ff       	call   4210 <buf_put>
    a5dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a5e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    a5e7:	31 c0                	xor    %eax,%eax
    a5e9:	49 83 c5 01          	add    $0x1,%r13
    a5ed:	4c 8d 05 28 4c 00 00 	lea    0x4c28(%rip),%r8        # f21c <_IO_stdin_used+0x21c>
    a5f4:	ba 02 00 00 00       	mov    $0x2,%edx
    a5f9:	be 00 02 00 00       	mov    $0x200,%esi
    a5fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a605:	00 
    a606:	e8 a5 8d ff ff       	call   33b0 <__snprintf_chk@plt>
    a60b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a612:	00 
    a613:	e8 38 8e ff ff       	call   3450 <strlen@plt>
    a618:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a61f:	00 
    a620:	48 89 df             	mov    %rbx,%rdi
    a623:	48 89 c2             	mov    %rax,%rdx
    a626:	e8 e5 9b ff ff       	call   4210 <buf_put>
    a62b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a62f:	72 97                	jb     a5c8 <fwp_write+0x8e8>
    a631:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a636:	ba 01 00 00 00       	mov    $0x1,%edx
    a63b:	48 89 df             	mov    %rbx,%rdi
    a63e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a643:	e8 c8 9b ff ff       	call   4210 <buf_put>
    a648:	e9 29 f7 ff ff       	jmp    9d76 <fwp_write+0x96>
    a64d:	0f 1f 00             	nopl   (%rax)
    a650:	83 f8 0b             	cmp    $0xb,%eax
    a653:	0f 85 1b ff ff ff    	jne    a574 <fwp_write+0x894>
    a659:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a65e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a662:	83 e0 01             	and    $0x1,%eax
    a665:	85 c0                	test   %eax,%eax
    a667:	0f 84 07 ff ff ff    	je     a574 <fwp_write+0x894>
    a66d:	4c 89 fe             	mov    %r15,%rsi
    a670:	48 89 df             	mov    %rbx,%rdi
    a673:	ba 01 00 00 00       	mov    $0x1,%edx
    a678:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a67d:	e8 8e 9b ff ff       	call   4210 <buf_put>
    a682:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a687:	48 8b 34 24          	mov    (%rsp),%rsi
    a68b:	31 c9                	xor    %ecx,%ecx
    a68d:	48 89 df             	mov    %rbx,%rdi
    a690:	e8 4b f6 ff ff       	call   9ce0 <fwp_write>
    a695:	ba 01 00 00 00       	mov    $0x1,%edx
    a69a:	4c 89 fe             	mov    %r15,%rsi
    a69d:	48 89 df             	mov    %rbx,%rdi
    a6a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a6a5:	e8 66 9b ff ff       	call   4210 <buf_put>
    a6aa:	e9 d8 fe ff ff       	jmp    a587 <fwp_write+0x8a7>
    a6af:	90                   	nop
    a6b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a6b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6ba:	48 89 df             	mov    %rbx,%rdi
    a6bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a6c2:	e8 49 9b ff ff       	call   4210 <buf_put>
    a6c7:	e9 aa f6 ff ff       	jmp    9d76 <fwp_write+0x96>
    a6cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a6d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a6d5:	ba 01 00 00 00       	mov    $0x1,%edx
    a6da:	48 89 df             	mov    %rbx,%rdi
    a6dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a6e2:	e8 29 9b ff ff       	call   4210 <buf_put>
    a6e7:	e9 8a f6 ff ff       	jmp    9d76 <fwp_write+0x96>
    a6ec:	0f 1f 40 00          	nopl   0x0(%rax)
    a6f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a6f4:	48 8b 13             	mov    (%rbx),%rdx
    a6f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a6fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a700:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a704:	e9 6d f6 ff ff       	jmp    9d76 <fwp_write+0x96>
    a709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a710:	ba 02 00 00 00       	mov    $0x2,%edx
    a715:	48 8d 35 03 4b 00 00 	lea    0x4b03(%rip),%rsi        # f21f <_IO_stdin_used+0x21f>
    a71c:	48 89 df             	mov    %rbx,%rdi
    a71f:	e8 ec 9a ff ff       	call   4210 <buf_put>
    a724:	e9 72 f8 ff ff       	jmp    9f9b <fwp_write+0x2bb>
    a729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a730:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a735:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a73a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a73e:	48 89 f7             	mov    %rsi,%rdi
    a741:	48 89 34 24          	mov    %rsi,(%rsp)
    a745:	e8 06 8d ff ff       	call   3450 <strlen@plt>
    a74a:	48 8b 34 24          	mov    (%rsp),%rsi
    a74e:	48 89 df             	mov    %rbx,%rdi
    a751:	48 89 c2             	mov    %rax,%rdx
    a754:	e8 b7 9a ff ff       	call   4210 <buf_put>
    a759:	ba 03 00 00 00       	mov    $0x3,%edx
    a75e:	48 8d 35 dd 4a 00 00 	lea    0x4add(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    a765:	48 89 df             	mov    %rbx,%rdi
    a768:	e8 a3 9a ff ff       	call   4210 <buf_put>
    a76d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a772:	e9 35 f8 ff ff       	jmp    9fac <fwp_write+0x2cc>
    a777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a77e:	00 00 
    a780:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a785:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a789:	48 85 ff             	test   %rdi,%rdi
    a78c:	0f 84 e2 fd ff ff    	je     a574 <fwp_write+0x894>
    a792:	48 8d 35 93 4a 00 00 	lea    0x4a93(%rip),%rsi        # f22c <_IO_stdin_used+0x22c>
    a799:	e8 92 8d ff ff       	call   3530 <strcmp@plt>
    a79e:	85 c0                	test   %eax,%eax
    a7a0:	0f 95 c0             	setne  %al
    a7a3:	0f b6 c0             	movzbl %al,%eax
    a7a6:	e9 c1 fd ff ff       	jmp    a56c <fwp_write+0x88c>
    a7ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a7b0:	31 c0                	xor    %eax,%eax
    a7b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a7b9:	00 
    a7ba:	0f 97 c0             	seta   %al
    a7bd:	e9 aa fd ff ff       	jmp    a56c <fwp_write+0x88c>
    a7c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a7c8:	48 89 df             	mov    %rbx,%rdi
    a7cb:	ba 02 00 00 00       	mov    $0x2,%edx
    a7d0:	48 8d 35 52 4a 00 00 	lea    0x4a52(%rip),%rsi        # f229 <_IO_stdin_used+0x229>
    a7d7:	e8 34 9a ff ff       	call   4210 <buf_put>
    a7dc:	4c 89 e8             	mov    %r13,%rax
    a7df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a7e4:	31 c9                	xor    %ecx,%ecx
    a7e6:	48 c1 e0 04          	shl    $0x4,%rax
    a7ea:	48 89 df             	mov    %rbx,%rdi
    a7ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a7f2:	e8 e9 f4 ff ff       	call   9ce0 <fwp_write>
    a7f7:	e9 5e f6 ff ff       	jmp    9e5a <fwp_write+0x17a>
    a7fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a800:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a805:	48 85 ff             	test   %rdi,%rdi
    a808:	79 0c                	jns    a816 <fwp_write+0xb36>
    a80a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a811:	00 
    a812:	48 03 75 10          	add    0x10(%rbp),%rsi
    a816:	48 63 3e             	movslq (%rsi),%rdi
    a819:	83 f9 02             	cmp    $0x2,%ecx
    a81c:	89 fe                	mov    %edi,%esi
    a81e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a822:	e9 f9 fb ff ff       	jmp    a420 <fwp_write+0x740>
    a827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a82e:	00 00 
    a830:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a835:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a83a:	48 85 ff             	test   %rdi,%rdi
    a83d:	0f 88 0f 03 00 00    	js     ab52 <fwp_write+0xe72>
    a843:	49 0f bf 38          	movswq (%r8),%rdi
    a847:	83 f9 01             	cmp    $0x1,%ecx
    a84a:	0f b7 f7             	movzwl %di,%esi
    a84d:	48 0f 44 f7          	cmove  %rdi,%rsi
    a851:	e9 ca fb ff ff       	jmp    a420 <fwp_write+0x740>
    a856:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a85d:	00 00 00 
    a860:	ba 01 00 00 00       	mov    $0x1,%edx
    a865:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a86a:	48 83 c5 08          	add    $0x8,%rbp
    a86e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a873:	e8 98 99 ff ff       	call   4210 <buf_put>
    a878:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a87d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a882:	4d 85 ed             	test   %r13,%r13
    a885:	75 46                	jne    a8cd <fwp_write+0xbed>
    a887:	e9 04 01 00 00       	jmp    a990 <fwp_write+0xcb0>
    a88c:	0f 1f 40 00          	nopl   0x0(%rax)
    a890:	41 80 f9 09          	cmp    $0x9,%r9b
    a894:	0f 84 d6 00 00 00    	je     a970 <fwp_write+0xc90>
    a89a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a89e:	0f 85 9c 00 00 00    	jne    a940 <fwp_write+0xc60>
    a8a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a8a9:	48 8d 35 55 49 00 00 	lea    0x4955(%rip),%rsi        # f205 <_IO_stdin_used+0x205>
    a8b0:	48 89 df             	mov    %rbx,%rdi
    a8b3:	e8 58 99 ff ff       	call   4210 <buf_put>
    a8b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a8bf:	00 
    a8c0:	48 83 c5 01          	add    $0x1,%rbp
    a8c4:	49 39 ec             	cmp    %rbp,%r12
    a8c7:	0f 84 c3 00 00 00    	je     a990 <fwp_write+0xcb0>
    a8cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a8d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    a8d6:	74 28                	je     a900 <fwp_write+0xc20>
    a8d8:	7e b6                	jle    a890 <fwp_write+0xbb0>
    a8da:	41 80 f9 22          	cmp    $0x22,%r9b
    a8de:	74 40                	je     a920 <fwp_write+0xc40>
    a8e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a8e4:	75 5a                	jne    a940 <fwp_write+0xc60>
    a8e6:	ba 02 00 00 00       	mov    $0x2,%edx
    a8eb:	48 8d 35 10 49 00 00 	lea    0x4910(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    a8f2:	48 89 df             	mov    %rbx,%rdi
    a8f5:	e8 16 99 ff ff       	call   4210 <buf_put>
    a8fa:	eb c4                	jmp    a8c0 <fwp_write+0xbe0>
    a8fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a900:	ba 02 00 00 00       	mov    $0x2,%edx
    a905:	48 8d 35 ff 48 00 00 	lea    0x48ff(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    a90c:	48 89 df             	mov    %rbx,%rdi
    a90f:	e8 fc 98 ff ff       	call   4210 <buf_put>
    a914:	eb aa                	jmp    a8c0 <fwp_write+0xbe0>
    a916:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a91d:	00 00 00 
    a920:	ba 02 00 00 00       	mov    $0x2,%edx
    a925:	48 8d 35 d3 48 00 00 	lea    0x48d3(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    a92c:	48 89 df             	mov    %rbx,%rdi
    a92f:	e8 dc 98 ff ff       	call   4210 <buf_put>
    a934:	eb 8a                	jmp    a8c0 <fwp_write+0xbe0>
    a936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a93d:	00 00 00 
    a940:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a944:	0f 86 2e 01 00 00    	jbe    aa78 <fwp_write+0xd98>
    a94a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a94e:	0f 84 24 01 00 00    	je     aa78 <fwp_write+0xd98>
    a954:	ba 01 00 00 00       	mov    $0x1,%edx
    a959:	4c 89 fe             	mov    %r15,%rsi
    a95c:	48 89 df             	mov    %rbx,%rdi
    a95f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a964:	e8 a7 98 ff ff       	call   4210 <buf_put>
    a969:	e9 52 ff ff ff       	jmp    a8c0 <fwp_write+0xbe0>
    a96e:	66 90                	xchg   %ax,%ax
    a970:	ba 02 00 00 00       	mov    $0x2,%edx
    a975:	48 8d 35 8c 48 00 00 	lea    0x488c(%rip),%rsi        # f208 <_IO_stdin_used+0x208>
    a97c:	48 89 df             	mov    %rbx,%rdi
    a97f:	e8 8c 98 ff ff       	call   4210 <buf_put>
    a984:	e9 37 ff ff ff       	jmp    a8c0 <fwp_write+0xbe0>
    a989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a990:	ba 01 00 00 00       	mov    $0x1,%edx
    a995:	4c 89 fe             	mov    %r15,%rsi
    a998:	48 89 df             	mov    %rbx,%rdi
    a99b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a9a0:	e8 6b 98 ff ff       	call   4210 <buf_put>
    a9a5:	e9 cc f3 ff ff       	jmp    9d76 <fwp_write+0x96>
    a9aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9b0:	83 f8 04             	cmp    $0x4,%eax
    a9b3:	0f 85 bb fb ff ff    	jne    a574 <fwp_write+0x894>
    a9b9:	48 8b 04 24          	mov    (%rsp),%rax
    a9bd:	48 8b 40 08          	mov    0x8(%rax),%rax
    a9c1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a9c6:	48 c1 e8 3f          	shr    $0x3f,%rax
    a9ca:	e9 96 fc ff ff       	jmp    a665 <fwp_write+0x985>
    a9cf:	90                   	nop
    a9d0:	8b 0c 24             	mov    (%rsp),%ecx
    a9d3:	31 c0                	xor    %eax,%eax
    a9d5:	85 c9                	test   %ecx,%ecx
    a9d7:	0f 98 c0             	sets   %al
    a9da:	e9 86 fc ff ff       	jmp    a665 <fwp_write+0x985>
    a9df:	90                   	nop
    a9e0:	48 f7 d8             	neg    %rax
    a9e3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a9ea:	00 
    a9eb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a9f2:	2d 
    a9f3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a9fa:	00 
    a9fb:	48 83 d2 00          	adc    $0x0,%rdx
    a9ff:	48 89 c6             	mov    %rax,%rsi
    aa02:	48 f7 da             	neg    %rdx
    aa05:	e8 36 90 ff ff       	call   3a40 <fwp_fmt_u128>
    aa0a:	e9 51 f3 ff ff       	jmp    9d60 <fwp_write+0x80>
    aa0f:	90                   	nop
    aa10:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aa15:	e9 c3 f5 ff ff       	jmp    9fdd <fwp_write+0x2fd>
    aa1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aa20:	4c 89 e9             	mov    %r13,%rcx
    aa23:	48 c1 e1 04          	shl    $0x4,%rcx
    aa27:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aa2c:	48 85 ff             	test   %rdi,%rdi
    aa2f:	0f 89 eb f9 ff ff    	jns    a420 <fwp_write+0x740>
    aa35:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa39:	48 89 ce             	mov    %rcx,%rsi
    aa3c:	e9 df f9 ff ff       	jmp    a420 <fwp_write+0x740>
    aa41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa48:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aa4f:	00 
    aa50:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aa54:	e9 20 fa ff ff       	jmp    a479 <fwp_write+0x799>
    aa59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa60:	ba 02 00 00 00       	mov    $0x2,%edx
    aa65:	48 8d 35 63 47 00 00 	lea    0x4763(%rip),%rsi        # f1cf <_IO_stdin_used+0x1cf>
    aa6c:	e9 2d f7 ff ff       	jmp    a19e <fwp_write+0x4be>
    aa71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aa78:	4c 8d 05 8f 47 00 00 	lea    0x478f(%rip),%r8        # f20e <_IO_stdin_used+0x20e>
    aa7f:	b9 10 00 00 00       	mov    $0x10,%ecx
    aa84:	31 c0                	xor    %eax,%eax
    aa86:	ba 02 00 00 00       	mov    $0x2,%edx
    aa8b:	be 10 00 00 00       	mov    $0x10,%esi
    aa90:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa97:	00 
    aa98:	e8 13 89 ff ff       	call   33b0 <__snprintf_chk@plt>
    aa9d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aaa4:	00 
    aaa5:	e8 a6 89 ff ff       	call   3450 <strlen@plt>
    aaaa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aab1:	00 
    aab2:	48 89 df             	mov    %rbx,%rdi
    aab5:	48 89 c2             	mov    %rax,%rdx
    aab8:	e8 53 97 ff ff       	call   4210 <buf_put>
    aabd:	e9 fe fd ff ff       	jmp    a8c0 <fwp_write+0xbe0>
    aac2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aac8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aacc:	48 8d 35 f6 46 00 00 	lea    0x46f6(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    aad3:	48 8d 05 ee 46 00 00 	lea    0x46ee(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    aada:	4c 89 e7             	mov    %r12,%rdi
    aadd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    aae1:	48 0f 46 f0          	cmovbe %rax,%rsi
    aae5:	e8 06 89 ff ff       	call   33f0 <strcpy@plt>
    aaea:	e9 71 f2 ff ff       	jmp    9d60 <fwp_write+0x80>
    aaef:	90                   	nop
    aaf0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aaf4:	48 8d 35 ce 46 00 00 	lea    0x46ce(%rip),%rsi        # f1c9 <_IO_stdin_used+0x1c9>
    aafb:	48 8d 05 c6 46 00 00 	lea    0x46c6(%rip),%rax        # f1c8 <_IO_stdin_used+0x1c8>
    ab02:	0f 2f c8             	comiss %xmm0,%xmm1
    ab05:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab0c:	00 
    ab0d:	4c 89 e7             	mov    %r12,%rdi
    ab10:	48 0f 46 f0          	cmovbe %rax,%rsi
    ab14:	e8 d7 88 ff ff       	call   33f0 <strcpy@plt>
    ab19:	e9 42 f2 ff ff       	jmp    9d60 <fwp_write+0x80>
    ab1e:	66 90                	xchg   %ax,%ax
    ab20:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ab25:	45 85 c0             	test   %r8d,%r8d
    ab28:	75 34                	jne    ab5e <fwp_write+0xe7e>
    ab2a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ab31:	00 
    ab32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ab39:	00 00 
    ab3b:	0f 85 74 f6 ff ff    	jne    a1b5 <fwp_write+0x4d5>
    ab41:	ba 02 00 00 00       	mov    $0x2,%edx
    ab46:	48 8d 35 f2 46 00 00 	lea    0x46f2(%rip),%rsi        # f23f <_IO_stdin_used+0x23f>
    ab4d:	e9 a1 f3 ff ff       	jmp    9ef3 <fwp_write+0x213>
    ab52:	48 03 75 10          	add    0x10(%rbp),%rsi
    ab56:	49 89 f0             	mov    %rsi,%r8
    ab59:	e9 e5 fc ff ff       	jmp    a843 <fwp_write+0xb63>
    ab5e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ab63:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab68:	85 ff                	test   %edi,%edi
    ab6a:	0f 84 fa f3 ff ff    	je     9f6a <fwp_write+0x28a>
    ab70:	ba 01 00 00 00       	mov    $0x1,%edx
    ab75:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab7a:	48 89 df             	mov    %rbx,%rdi
    ab7d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab82:	e8 89 96 ff ff       	call   4210 <buf_put>
    ab87:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ab8c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ab91:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ab97:	85 c0                	test   %eax,%eax
    ab99:	0f 8f f0 f3 ff ff    	jg     9f8f <fwp_write+0x2af>
    ab9f:	e9 34 f4 ff ff       	jmp    9fd8 <fwp_write+0x2f8>
    aba4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    aba8:	49 89 c5             	mov    %rax,%r13
    abab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    abb0:	49 89 c4             	mov    %rax,%r12
    abb3:	49 c1 fd 3f          	sar    $0x3f,%r13
    abb7:	4c 09 e8             	or     %r13,%rax
    abba:	0f 84 a7 00 00 00    	je     ac67 <fwp_write+0xf87>
    abc0:	48 8d 2d 39 68 00 00 	lea    0x6839(%rip),%rbp        # 11400 <units.1>
    abc7:	4d 89 e7             	mov    %r12,%r15
    abca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    abce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    abd3:	4c 89 ff             	mov    %r15,%rdi
    abd6:	4c 89 ee             	mov    %r13,%rsi
    abd9:	44 89 0c 24          	mov    %r9d,(%rsp)
    abdd:	48 99                	cqto
    abdf:	48 89 d1             	mov    %rdx,%rcx
    abe2:	48 89 c2             	mov    %rax,%rdx
    abe5:	e8 d6 41 00 00       	call   edc0 <__divmodti4>
    abea:	44 8b 0c 24          	mov    (%rsp),%r9d
    abee:	48 89 c1             	mov    %rax,%rcx
    abf1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    abf6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    abfb:	0f 84 94 00 00 00    	je     ac95 <fwp_write+0xfb5>
    ac01:	41 83 c1 01          	add    $0x1,%r9d
    ac05:	48 83 c5 10          	add    $0x10,%rbp
    ac09:	41 83 f9 05          	cmp    $0x5,%r9d
    ac0d:	75 bb                	jne    abca <fwp_write+0xeea>
    ac0f:	4d 85 ed             	test   %r13,%r13
    ac12:	79 53                	jns    ac67 <fwp_write+0xf87>
    ac14:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ac19:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ac1e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ac23:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac28:	48 99                	cqto
    ac2a:	48 f7 d8             	neg    %rax
    ac2d:	48 83 d2 00          	adc    $0x0,%rdx
    ac31:	48 89 c6             	mov    %rax,%rsi
    ac34:	48 f7 da             	neg    %rdx
    ac37:	e8 04 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ac3c:	49 89 e8             	mov    %rbp,%r8
    ac3f:	ba 00 02 00 00       	mov    $0x200,%edx
    ac44:	be 02 00 00 00       	mov    $0x2,%esi
    ac49:	31 c0                	xor    %eax,%eax
    ac4b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac52:	00 
    ac53:	48 8d 0d e0 45 00 00 	lea    0x45e0(%rip),%rcx        # f23a <_IO_stdin_used+0x23a>
    ac5a:	4c 89 e7             	mov    %r12,%rdi
    ac5d:	e8 7e 8a ff ff       	call   36e0 <__sprintf_chk@plt>
    ac62:	e9 f9 f0 ff ff       	jmp    9d60 <fwp_write+0x80>
    ac67:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ac6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ac71:	31 d2                	xor    %edx,%edx
    ac73:	48 89 ef             	mov    %rbp,%rdi
    ac76:	e8 c5 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ac7b:	eb bf                	jmp    ac3c <fwp_write+0xf5c>
    ac7d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ac84:	4e 61 4e 00 
    ac88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac8f:	00 
    ac90:	e9 cb f0 ff ff       	jmp    9d60 <fwp_write+0x80>
    ac95:	44 89 0c 24          	mov    %r9d,(%rsp)
    ac99:	48 89 c8             	mov    %rcx,%rax
    ac9c:	48 85 d2             	test   %rdx,%rdx
    ac9f:	78 51                	js     acf2 <fwp_write+0x1012>
    aca1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aca6:	48 89 c6             	mov    %rax,%rsi
    aca9:	48 89 ef             	mov    %rbp,%rdi
    acac:	e8 8f 8d ff ff       	call   3a40 <fwp_fmt_u128>
    acb1:	44 8b 0c 24          	mov    (%rsp),%r9d
    acb5:	49 63 c1             	movslq %r9d,%rax
    acb8:	49 89 e8             	mov    %rbp,%r8
    acbb:	ba 00 02 00 00       	mov    $0x200,%edx
    acc0:	be 02 00 00 00       	mov    $0x2,%esi
    acc5:	48 c1 e0 04          	shl    $0x4,%rax
    acc9:	48 8d 3d 30 67 00 00 	lea    0x6730(%rip),%rdi        # 11400 <units.1>
    acd0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acd7:	00 
    acd8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    acdc:	48 8d 0d 52 45 00 00 	lea    0x4552(%rip),%rcx        # f235 <_IO_stdin_used+0x235>
    ace3:	4c 89 e7             	mov    %r12,%rdi
    ace6:	31 c0                	xor    %eax,%eax
    ace8:	e8 f3 89 ff ff       	call   36e0 <__sprintf_chk@plt>
    aced:	e9 6e f0 ff ff       	jmp    9d60 <fwp_write+0x80>
    acf2:	48 f7 d8             	neg    %rax
    acf5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    acfa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    acff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad04:	48 83 d2 00          	adc    $0x0,%rdx
    ad08:	48 89 c6             	mov    %rax,%rsi
    ad0b:	48 f7 da             	neg    %rdx
    ad0e:	e8 2d 8d ff ff       	call   3a40 <fwp_fmt_u128>
    ad13:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad17:	eb 9c                	jmp    acb5 <fwp_write+0xfd5>
    ad19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ad20 <fwp_hof0.constprop.0>:
    ad20:	55                   	push   %rbp
    ad21:	48 89 e5             	mov    %rsp,%rbp
    ad24:	41 57                	push   %r15
    ad26:	41 56                	push   %r14
    ad28:	41 55                	push   %r13
    ad2a:	41 54                	push   %r12
    ad2c:	53                   	push   %rbx
    ad2d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    ad34:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    ad3b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ad42:	00 00 
    ad44:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ad48:	31 c0                	xor    %eax,%eax
    ad4a:	48 85 f6             	test   %rsi,%rsi
    ad4d:	0f 84 86 06 00 00    	je     b3d9 <fwp_hof0.constprop.0+0x6b9>
    ad53:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    ad57:	49 89 f7             	mov    %rsi,%r15
    ad5a:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    ad61:	48 8d 35 78 8a 01 00 	lea    0x18a78(%rip),%rsi        # 237e0 <fwp_heap>
    ad68:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    ad6f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ad76:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ad7d:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    ad81:	48 c1 e2 10          	shl    $0x10,%rdx
    ad85:	48 39 d0             	cmp    %rdx,%rax
    ad88:	73 5d                	jae    ade7 <fwp_hof0.constprop.0+0xc7>
    ad8a:	48 89 c2             	mov    %rax,%rdx
    ad8d:	48 c1 ea 10          	shr    $0x10,%rdx
    ad91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad95:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ad9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ada0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    ada4:	48 85 ff             	test   %rdi,%rdi
    ada7:	74 3e                	je     ade7 <fwp_hof0.constprop.0+0xc7>
    ada9:	0f b6 0a             	movzbl (%rdx),%ecx
    adac:	80 f9 02             	cmp    $0x2,%cl
    adaf:	0f 84 cd 0a 00 00    	je     b882 <fwp_hof0.constprop.0+0xb62>
    adb5:	80 f9 01             	cmp    $0x1,%cl
    adb8:	75 2d                	jne    ade7 <fwp_hof0.constprop.0+0xc7>
    adba:	8b 4a 18             	mov    0x18(%rdx),%ecx
    adbd:	0f b7 c0             	movzwl %ax,%eax
    adc0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    adc3:	48 0f af c1          	imul   %rcx,%rax
    adc7:	48 c1 e8 20          	shr    $0x20,%rax
    adcb:	48 39 d0             	cmp    %rdx,%rax
    adce:	73 17                	jae    ade7 <fwp_hof0.constprop.0+0xc7>
    add0:	48 01 c7             	add    %rax,%rdi
    add3:	0f b6 07             	movzbl (%rdi),%eax
    add6:	84 c0                	test   %al,%al
    add8:	74 0d                	je     ade7 <fwp_hof0.constprop.0+0xc7>
    adda:	3c fd                	cmp    $0xfd,%al
    addc:	0f 87 7e 0b 00 00    	ja     b960 <fwp_hof0.constprop.0+0xc40>
    ade2:	83 c0 01             	add    $0x1,%eax
    ade5:	88 07                	mov    %al,(%rdi)
    ade7:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    adee:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    adf5:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    adfc:	c7 00 00 00 
    ae00:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ae04:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    ae08:	48 8b 15 29 a6 01 00 	mov    0x1a629(%rip),%rdx        # 25438 <fwp_fns>
    ae0f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    ae13:	48 8d 05 fe 81 00 00 	lea    0x81fe(%rip),%rax        # 13018 <fc12>
    ae1a:	44 8b 20             	mov    (%rax),%r12d
    ae1d:	49 c1 e4 05          	shl    $0x5,%r12
    ae21:	49 01 d4             	add    %rdx,%r12
    ae24:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    ae29:	48 85 c9             	test   %rcx,%rcx
    ae2c:	0f 84 1d 0a 00 00    	je     b84f <fwp_hof0.constprop.0+0xb2f>
    ae32:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    ae37:	0f 84 7b 08 00 00    	je     b6b8 <fwp_hof0.constprop.0+0x998>
    ae3d:	48 8d 3d 9c 89 01 00 	lea    0x1899c(%rip),%rdi        # 237e0 <fwp_heap>
    ae44:	48 8d 05 cd 81 00 00 	lea    0x81cd(%rip),%rax        # 13018 <fc12>
    ae4b:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    ae52:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    ae59:	48 89 f1             	mov    %rsi,%rcx
    ae5c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    ae60:	48 c1 e1 10          	shl    $0x10,%rcx
    ae64:	48 39 c8             	cmp    %rcx,%rax
    ae67:	73 5f                	jae    aec8 <fwp_hof0.constprop.0+0x1a8>
    ae69:	48 89 c1             	mov    %rax,%rcx
    ae6c:	48 c1 e9 10          	shr    $0x10,%rcx
    ae70:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ae74:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    ae7b:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ae7f:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    ae83:	48 85 ff             	test   %rdi,%rdi
    ae86:	74 40                	je     aec8 <fwp_hof0.constprop.0+0x1a8>
    ae88:	0f b6 31             	movzbl (%rcx),%esi
    ae8b:	40 80 fe 02          	cmp    $0x2,%sil
    ae8f:	0f 84 08 09 00 00    	je     b79d <fwp_hof0.constprop.0+0xa7d>
    ae95:	40 80 fe 01          	cmp    $0x1,%sil
    ae99:	75 2d                	jne    aec8 <fwp_hof0.constprop.0+0x1a8>
    ae9b:	8b 71 18             	mov    0x18(%rcx),%esi
    ae9e:	0f b7 c0             	movzwl %ax,%eax
    aea1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aea4:	48 0f af c6          	imul   %rsi,%rax
    aea8:	48 c1 e8 20          	shr    $0x20,%rax
    aeac:	48 39 c8             	cmp    %rcx,%rax
    aeaf:	73 17                	jae    aec8 <fwp_hof0.constprop.0+0x1a8>
    aeb1:	48 01 c7             	add    %rax,%rdi
    aeb4:	0f b6 07             	movzbl (%rdi),%eax
    aeb7:	84 c0                	test   %al,%al
    aeb9:	74 0d                	je     aec8 <fwp_hof0.constprop.0+0x1a8>
    aebb:	3c fd                	cmp    $0xfd,%al
    aebd:	0f 87 66 09 00 00    	ja     b829 <fwp_hof0.constprop.0+0xb09>
    aec3:	83 c0 01             	add    $0x1,%eax
    aec6:	88 07                	mov    %al,(%rdi)
    aec8:	48 8d 05 49 81 00 00 	lea    0x8149(%rip),%rax        # 13018 <fc12>
    aecf:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    aed6:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aeda:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    aee1:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    aee5:	48 8d 05 2c 81 00 00 	lea    0x812c(%rip),%rax        # 13018 <fc12>
    aeec:	41 8b 0c 24          	mov    (%r12),%ecx
    aef0:	2b 48 04             	sub    0x4(%rax),%ecx
    aef3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    aef7:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    aefb:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    aefe:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    af02:	49 89 c1             	mov    %rax,%r9
    af05:	8b 00                	mov    (%rax),%eax
    af07:	44 39 e9             	cmp    %r13d,%ecx
    af0a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    af0e:	4d 89 cf             	mov    %r9,%r15
    af11:	48 c1 e0 05          	shl    $0x5,%rax
    af15:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    af19:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    af20:	4d 8b 50 18          	mov    0x18(%r8),%r10
    af24:	4d 85 d2             	test   %r10,%r10
    af27:	75 58                	jne    af81 <fwp_hof0.constprop.0+0x261>
    af29:	e9 f5 01 00 00       	jmp    b123 <fwp_hof0.constprop.0+0x403>
    af2e:	66 90                	xchg   %ax,%ax
    af30:	45 85 ff             	test   %r15d,%r15d
    af33:	74 69                	je     af9e <fwp_hof0.constprop.0+0x27e>
    af35:	4c 89 e7             	mov    %r12,%rdi
    af38:	41 ff 12             	call   *(%r10)
    af3b:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    af3f:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    af43:	e8 e8 c2 ff ff       	call   7230 <fwp_closure_drop>
    af48:	44 39 eb             	cmp    %r13d,%ebx
    af4b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    af4f:	0f 84 53 07 00 00    	je     b6a8 <fwp_hof0.constprop.0+0x988>
    af55:	44 8b 00             	mov    (%rax),%r8d
    af58:	45 29 fe             	sub    %r15d,%r14d
    af5b:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    af5f:	49 89 c1             	mov    %rax,%r9
    af62:	45 89 f5             	mov    %r14d,%r13d
    af65:	49 c1 e0 05          	shl    $0x5,%r8
    af69:	4c 03 05 c8 a4 01 00 	add    0x1a4c8(%rip),%r8        # 25438 <fwp_fns>
    af70:	4d 8b 50 18          	mov    0x18(%r8),%r10
    af74:	4d 85 d2             	test   %r10,%r10
    af77:	0f 84 a3 01 00 00    	je     b120 <fwp_hof0.constprop.0+0x400>
    af7d:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    af81:	41 8b 49 04          	mov    0x4(%r9),%ecx
    af85:	45 8b 38             	mov    (%r8),%r15d
    af88:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    af8c:	45 39 fe             	cmp    %r15d,%r14d
    af8f:	0f 82 6b 04 00 00    	jb     b400 <fwp_hof0.constprop.0+0x6e0>
    af95:	44 89 fb             	mov    %r15d,%ebx
    af98:	29 cb                	sub    %ecx,%ebx
    af9a:	85 c9                	test   %ecx,%ecx
    af9c:	74 92                	je     af30 <fwp_hof0.constprop.0+0x210>
    af9e:	45 85 ff             	test   %r15d,%r15d
    afa1:	b8 01 00 00 00       	mov    $0x1,%eax
    afa6:	48 89 e6             	mov    %rsp,%rsi
    afa9:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    afad:	41 0f 45 c7          	cmovne %r15d,%eax
    afb1:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    afb8:	00 
    afb9:	48 c1 e8 04          	shr    $0x4,%rax
    afbd:	48 c1 e0 04          	shl    $0x4,%rax
    afc1:	48 89 c7             	mov    %rax,%rdi
    afc4:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    afcb:	48 29 fe             	sub    %rdi,%rsi
    afce:	48 39 f4             	cmp    %rsi,%rsp
    afd1:	74 15                	je     afe8 <fwp_hof0.constprop.0+0x2c8>
    afd3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    afda:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    afe1:	00 00 
    afe3:	48 39 f4             	cmp    %rsi,%rsp
    afe6:	75 eb                	jne    afd3 <fwp_hof0.constprop.0+0x2b3>
    afe8:	25 ff 0f 00 00       	and    $0xfff,%eax
    afed:	48 29 c4             	sub    %rax,%rsp
    aff0:	48 85 c0             	test   %rax,%rax
    aff3:	74 06                	je     affb <fwp_hof0.constprop.0+0x2db>
    aff5:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    affb:	89 cf                	mov    %ecx,%edi
    affd:	49 89 e3             	mov    %rsp,%r11
    b000:	31 c0                	xor    %eax,%eax
    b002:	48 c1 e7 03          	shl    $0x3,%rdi
    b006:	85 c9                	test   %ecx,%ecx
    b008:	74 28                	je     b032 <fwp_hof0.constprop.0+0x312>
    b00a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b011:	00 00 00 00 
    b015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b01c:	00 00 00 00 
    b020:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b025:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b029:	48 83 c0 08          	add    $0x8,%rax
    b02d:	48 39 c7             	cmp    %rax,%rdi
    b030:	75 ee                	jne    b020 <fwp_hof0.constprop.0+0x300>
    b032:	85 db                	test   %ebx,%ebx
    b034:	74 1f                	je     b055 <fwp_hof0.constprop.0+0x335>
    b036:	89 de                	mov    %ebx,%esi
    b038:	4c 89 e0             	mov    %r12,%rax
    b03b:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b03f:	90                   	nop
    b040:	48 8b 30             	mov    (%rax),%rsi
    b043:	89 ca                	mov    %ecx,%edx
    b045:	48 83 c0 08          	add    $0x8,%rax
    b049:	83 c1 01             	add    $0x1,%ecx
    b04c:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b050:	48 39 c7             	cmp    %rax,%rdi
    b053:	75 eb                	jne    b040 <fwp_hof0.constprop.0+0x320>
    b055:	48 8d 15 84 87 01 00 	lea    0x18784(%rip),%rdx        # 237e0 <fwp_heap>
    b05c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b060:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b067:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b06e:	48 89 f1             	mov    %rsi,%rcx
    b071:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b075:	48 c1 e1 10          	shl    $0x10,%rcx
    b079:	48 39 c8             	cmp    %rcx,%rax
    b07c:	73 4c                	jae    b0ca <fwp_hof0.constprop.0+0x3aa>
    b07e:	48 89 c1             	mov    %rax,%rcx
    b081:	48 c1 e9 10          	shr    $0x10,%rcx
    b085:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b089:	48 8b 0d 48 9b 01 00 	mov    0x19b48(%rip),%rcx        # 24bd8 <fwp_heap+0x13f8>
    b090:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b094:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b098:	48 85 f6             	test   %rsi,%rsi
    b09b:	74 2d                	je     b0ca <fwp_hof0.constprop.0+0x3aa>
    b09d:	0f b6 39             	movzbl (%rcx),%edi
    b0a0:	40 80 ff 02          	cmp    $0x2,%dil
    b0a4:	74 6a                	je     b110 <fwp_hof0.constprop.0+0x3f0>
    b0a6:	40 80 ff 01          	cmp    $0x1,%dil
    b0aa:	75 1e                	jne    b0ca <fwp_hof0.constprop.0+0x3aa>
    b0ac:	8b 79 18             	mov    0x18(%rcx),%edi
    b0af:	0f b7 c0             	movzwl %ax,%eax
    b0b2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b0b5:	48 0f af c7          	imul   %rdi,%rax
    b0b9:	48 c1 e8 20          	shr    $0x20,%rax
    b0bd:	48 39 c8             	cmp    %rcx,%rax
    b0c0:	73 08                	jae    b0ca <fwp_hof0.constprop.0+0x3aa>
    b0c2:	48 01 c6             	add    %rax,%rsi
    b0c5:	80 3e 01             	cmpb   $0x1,(%rsi)
    b0c8:	74 36                	je     b100 <fwp_hof0.constprop.0+0x3e0>
    b0ca:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b0ce:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b0d2:	be 01 00 00 00       	mov    $0x1,%esi
    b0d7:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b0db:	41 ff 52 08          	call   *0x8(%r10)
    b0df:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b0e3:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b0e7:	49 8b 40 18          	mov    0x18(%r8),%rax
    b0eb:	4c 89 df             	mov    %r11,%rdi
    b0ee:	ff 10                	call   *(%rax)
    b0f0:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b0f4:	e9 42 fe ff ff       	jmp    af3b <fwp_hof0.constprop.0+0x21b>
    b0f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b100:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b107:	00 
    b108:	eb dd                	jmp    b0e7 <fwp_hof0.constprop.0+0x3c7>
    b10a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b110:	66 85 c0             	test   %ax,%ax
    b113:	75 b5                	jne    b0ca <fwp_hof0.constprop.0+0x3aa>
    b115:	eb ae                	jmp    b0c5 <fwp_hof0.constprop.0+0x3a5>
    b117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b11e:	00 00 
    b120:	49 89 c7             	mov    %rax,%r15
    b123:	4c 89 ff             	mov    %r15,%rdi
    b126:	e8 e5 b9 ff ff       	call   6b10 <fwp_rc_share>
    b12b:	45 85 ed             	test   %r13d,%r13d
    b12e:	74 21                	je     b151 <fwp_hof0.constprop.0+0x431>
    b130:	44 89 ea             	mov    %r13d,%edx
    b133:	4c 89 e3             	mov    %r12,%rbx
    b136:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b13a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b140:	48 8b 3b             	mov    (%rbx),%rdi
    b143:	48 83 c3 08          	add    $0x8,%rbx
    b147:	e8 c4 b9 ff ff       	call   6b10 <fwp_rc_share>
    b14c:	4c 39 f3             	cmp    %r14,%rbx
    b14f:	75 ef                	jne    b140 <fwp_hof0.constprop.0+0x420>
    b151:	4c 89 e2             	mov    %r12,%rdx
    b154:	44 89 ee             	mov    %r13d,%esi
    b157:	4c 89 ff             	mov    %r15,%rdi
    b15a:	e8 51 ac ff ff       	call   5db0 <fwp_apply>
    b15f:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b163:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b166:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b169:	0f 83 87 00 00 00    	jae    b1f6 <fwp_hof0.constprop.0+0x4d6>
    b16f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b175:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    b179:	48 89 c2             	mov    %rax,%rdx
    b17c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    b180:	29 d6                	sub    %edx,%esi
    b182:	48 8b 15 af a2 01 00 	mov    0x1a2af(%rip),%rdx        # 25438 <fwp_fns>
    b189:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b18d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b190:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b194:	44 8b 26             	mov    (%rsi),%r12d
    b197:	48 89 f0             	mov    %rsi,%rax
    b19a:	49 c1 e4 05          	shl    $0x5,%r12
    b19e:	49 01 d4             	add    %rdx,%r12
    b1a1:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b1a7:	0f 85 3f fd ff ff    	jne    aeec <fwp_hof0.constprop.0+0x1cc>
    b1ad:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b1b1:	e8 5a b9 ff ff       	call   6b10 <fwp_rc_share>
    b1b6:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b1ba:	45 85 f6             	test   %r14d,%r14d
    b1bd:	74 23                	je     b1e2 <fwp_hof0.constprop.0+0x4c2>
    b1bf:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b1c3:	31 db                	xor    %ebx,%ebx
    b1c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b1cc:	00 00 00 00 
    b1d0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b1d4:	48 83 c3 01          	add    $0x1,%rbx
    b1d8:	e8 33 b9 ff ff       	call   6b10 <fwp_rc_share>
    b1dd:	44 39 f3             	cmp    %r14d,%ebx
    b1e0:	72 ee                	jb     b1d0 <fwp_hof0.constprop.0+0x4b0>
    b1e2:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b1e6:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b1e9:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b1ed:	e8 be ab ff ff       	call   5db0 <fwp_apply>
    b1f2:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b1f6:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b1fd:	01 
    b1fe:	0f 85 00 fc ff ff    	jne    ae04 <fwp_hof0.constprop.0+0xe4>
    b204:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b208:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b20f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b213:	b9 01 00 00 00       	mov    $0x1,%ecx
    b218:	48 8d 15 61 79 00 00 	lea    0x7961(%rip),%rdx        # 12b80 <d0>
    b21f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b226:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b22d:	00 
    b22e:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b232:	e8 a9 ea ff ff       	call   9ce0 <fwp_write>
    b237:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b23b:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b23f:	48 8d 05 4b 3e 00 00 	lea    0x3e4b(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    b246:	48 85 c9             	test   %rcx,%rcx
    b249:	48 0f 44 c8          	cmove  %rax,%rcx
    b24d:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b251:	0f 87 f5 06 00 00    	ja     b94c <fwp_hof0.constprop.0+0xc2c>
    b257:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b25b:	be 01 00 00 00       	mov    $0x1,%esi
    b260:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b264:	e8 27 aa ff ff       	call   5c90 <fwp_heap_alloc>
    b269:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b26d:	4c 89 f2             	mov    %r14,%rdx
    b270:	4c 89 30             	mov    %r14,(%rax)
    b273:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b277:	48 89 c3             	mov    %rax,%rbx
    b27a:	4c 89 e7             	mov    %r12,%rdi
    b27d:	e8 1e 83 ff ff       	call   35a0 <memcpy@plt>
    b282:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b288:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b28c:	e8 2f 81 ff ff       	call   33c0 <free@plt>
    b291:	48 8d 35 48 85 01 00 	lea    0x18548(%rip),%rsi        # 237e0 <fwp_heap>
    b298:	48 89 d8             	mov    %rbx,%rax
    b29b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b2a2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b2a9:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b2ad:	48 c1 e2 10          	shl    $0x10,%rdx
    b2b1:	48 39 d0             	cmp    %rdx,%rax
    b2b4:	73 57                	jae    b30d <fwp_hof0.constprop.0+0x5ed>
    b2b6:	48 89 c2             	mov    %rax,%rdx
    b2b9:	48 c1 ea 10          	shr    $0x10,%rdx
    b2bd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2c1:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b2c8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b2cc:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b2d0:	4d 85 f6             	test   %r14,%r14
    b2d3:	74 38                	je     b30d <fwp_hof0.constprop.0+0x5ed>
    b2d5:	0f b6 0a             	movzbl (%rdx),%ecx
    b2d8:	80 f9 02             	cmp    $0x2,%cl
    b2db:	0f 84 c9 05 00 00    	je     b8aa <fwp_hof0.constprop.0+0xb8a>
    b2e1:	80 f9 01             	cmp    $0x1,%cl
    b2e4:	75 27                	jne    b30d <fwp_hof0.constprop.0+0x5ed>
    b2e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2e9:	0f b7 c0             	movzwl %ax,%eax
    b2ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2ef:	48 0f af c1          	imul   %rcx,%rax
    b2f3:	48 c1 e8 20          	shr    $0x20,%rax
    b2f7:	48 39 d0             	cmp    %rdx,%rax
    b2fa:	73 11                	jae    b30d <fwp_hof0.constprop.0+0x5ed>
    b2fc:	49 01 c6             	add    %rax,%r14
    b2ff:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b303:	0f 84 67 06 00 00    	je     b970 <fwp_hof0.constprop.0+0xc50>
    b309:	41 c6 06 01          	movb   $0x1,(%r14)
    b30d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b311:	e8 3a bc ff ff       	call   6f50 <fwp_drop0>
    b316:	48 8b 13             	mov    (%rbx),%rdx
    b319:	be 01 00 00 00       	mov    $0x1,%esi
    b31e:	4c 89 e7             	mov    %r12,%rdi
    b321:	48 8b 0d 18 a1 01 00 	mov    0x1a118(%rip),%rcx        # 25440 <fwp_prog_out>
    b328:	e8 53 83 ff ff       	call   3680 <fwrite@plt>
    b32d:	48 8b 35 0c a1 01 00 	mov    0x1a10c(%rip),%rsi        # 25440 <fwp_prog_out>
    b334:	bf 0a 00 00 00       	mov    $0xa,%edi
    b339:	e8 a2 81 ff ff       	call   34e0 <fputc@plt>
    b33e:	48 8d 35 9b 84 01 00 	lea    0x1849b(%rip),%rsi        # 237e0 <fwp_heap>
    b345:	48 89 d8             	mov    %rbx,%rax
    b348:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b34f:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b356:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    b35a:	48 c1 e2 10          	shl    $0x10,%rdx
    b35e:	48 39 d0             	cmp    %rdx,%rax
    b361:	73 69                	jae    b3cc <fwp_hof0.constprop.0+0x6ac>
    b363:	48 89 c2             	mov    %rax,%rdx
    b366:	48 c1 ea 10          	shr    $0x10,%rdx
    b36a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b36e:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b375:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b379:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b37d:	4d 85 e4             	test   %r12,%r12
    b380:	74 4a                	je     b3cc <fwp_hof0.constprop.0+0x6ac>
    b382:	0f b6 0a             	movzbl (%rdx),%ecx
    b385:	80 f9 02             	cmp    $0x2,%cl
    b388:	0f 84 2a 05 00 00    	je     b8b8 <fwp_hof0.constprop.0+0xb98>
    b38e:	80 f9 01             	cmp    $0x1,%cl
    b391:	75 39                	jne    b3cc <fwp_hof0.constprop.0+0x6ac>
    b393:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b396:	0f b7 c0             	movzwl %ax,%eax
    b399:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b39c:	48 0f af c1          	imul   %rcx,%rax
    b3a0:	48 c1 e8 20          	shr    $0x20,%rax
    b3a4:	48 39 d0             	cmp    %rdx,%rax
    b3a7:	73 23                	jae    b3cc <fwp_hof0.constprop.0+0x6ac>
    b3a9:	49 01 c4             	add    %rax,%r12
    b3ac:	41 0f b6 04 24       	movzbl (%r12),%eax
    b3b1:	84 c0                	test   %al,%al
    b3b3:	74 17                	je     b3cc <fwp_hof0.constprop.0+0x6ac>
    b3b5:	3c 01                	cmp    $0x1,%al
    b3b7:	0f 84 d3 04 00 00    	je     b890 <fwp_hof0.constprop.0+0xb70>
    b3bd:	3c ff                	cmp    $0xff,%al
    b3bf:	0f 84 01 05 00 00    	je     b8c6 <fwp_hof0.constprop.0+0xba6>
    b3c5:	83 e8 01             	sub    $0x1,%eax
    b3c8:	41 88 04 24          	mov    %al,(%r12)
    b3cc:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b3d0:	4d 85 ff             	test   %r15,%r15
    b3d3:	0f 85 88 f9 ff ff    	jne    ad61 <fwp_hof0.constprop.0+0x41>
    b3d9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b3dd:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b3e4:	00 00 
    b3e6:	0f 85 7e 05 00 00    	jne    b96a <fwp_hof0.constprop.0+0xc4a>
    b3ec:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b3f0:	31 c0                	xor    %eax,%eax
    b3f2:	5b                   	pop    %rbx
    b3f3:	41 5c                	pop    %r12
    b3f5:	41 5d                	pop    %r13
    b3f7:	41 5e                	pop    %r14
    b3f9:	41 5f                	pop    %r15
    b3fb:	5d                   	pop    %rbp
    b3fc:	c3                   	ret
    b3fd:	0f 1f 00             	nopl   (%rax)
    b400:	48 8d 1d d9 83 01 00 	lea    0x183d9(%rip),%rbx        # 237e0 <fwp_heap>
    b407:	41 8d 76 01          	lea    0x1(%r14),%esi
    b40b:	45 89 f7             	mov    %r14d,%r15d
    b40e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b414:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b41b:	00 
    b41c:	85 c0                	test   %eax,%eax
    b41e:	0f 84 a9 03 00 00    	je     b7cd <fwp_hof0.constprop.0+0xaad>
    b424:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b42b:	0f 87 9c 03 00 00    	ja     b7cd <fwp_hof0.constprop.0+0xaad>
    b431:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b435:	48 c1 e8 04          	shr    $0x4,%rax
    b439:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    b440:	00 
    b441:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    b448:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    b44c:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    b450:	4c 8b 12             	mov    (%rdx),%r10
    b453:	4d 85 d2             	test   %r10,%r10
    b456:	0f 84 4f 03 00 00    	je     b7ab <fwp_hof0.constprop.0+0xa8b>
    b45c:	4d 8b 1a             	mov    (%r10),%r11
    b45f:	49 f7 d3             	not    %r11
    b462:	4c 89 1a             	mov    %r11,(%rdx)
    b465:	48 39 c7             	cmp    %rax,%rdi
    b468:	73 50                	jae    b4ba <fwp_hof0.constprop.0+0x79a>
    b46a:	48 89 fa             	mov    %rdi,%rdx
    b46d:	48 83 c7 08          	add    $0x8,%rdi
    b471:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    b478:	00 
    b479:	48 f7 d2             	not    %rdx
    b47c:	48 01 c2             	add    %rax,%rdx
    b47f:	48 c1 ea 03          	shr    $0x3,%rdx
    b483:	48 39 c7             	cmp    %rax,%rdi
    b486:	73 32                	jae    b4ba <fwp_hof0.constprop.0+0x79a>
    b488:	83 e2 01             	and    $0x1,%edx
    b48b:	74 13                	je     b4a0 <fwp_hof0.constprop.0+0x780>
    b48d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b494:	00 
    b495:	48 83 c7 08          	add    $0x8,%rdi
    b499:	48 39 c7             	cmp    %rax,%rdi
    b49c:	73 1c                	jae    b4ba <fwp_hof0.constprop.0+0x79a>
    b49e:	66 90                	xchg   %ax,%ax
    b4a0:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    b4a7:	00 
    b4a8:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    b4af:	00 00 
    b4b1:	48 83 c7 10          	add    $0x10,%rdi
    b4b5:	48 39 c7             	cmp    %rax,%rdi
    b4b8:	72 e6                	jb     b4a0 <fwp_hof0.constprop.0+0x780>
    b4ba:	48 8d 35 1f 83 01 00 	lea    0x1831f(%rip),%rsi        # 237e0 <fwp_heap>
    b4c1:	48 89 c2             	mov    %rax,%rdx
    b4c4:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    b4cb:	0f 82 6a 04 00 00    	jb     b93b <fwp_hof0.constprop.0+0xc1b>
    b4d1:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    b4d8:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    b4df:	73 07                	jae    b4e8 <fwp_hof0.constprop.0+0x7c8>
    b4e1:	48 89 15 20 97 01 00 	mov    %rdx,0x19720(%rip)        # 24c08 <fwp_heap+0x1428>
    b4e8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b4ec:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    b4f1:	f2 0f 58 05 1f 97 01 	addsd  0x1971f(%rip),%xmm0        # 24c18 <fwp_heap+0x1438>
    b4f8:	00 
    b4f9:	f2 0f 11 05 17 97 01 	movsd  %xmm0,0x19717(%rip)        # 24c18 <fwp_heap+0x1438>
    b500:	00 
    b501:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    b506:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    b50b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    b50f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    b514:	85 c9                	test   %ecx,%ecx
    b516:	74 37                	je     b54f <fwp_hof0.constprop.0+0x82f>
    b518:	89 ca                	mov    %ecx,%edx
    b51a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    b51e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    b522:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b525:	48 c1 e2 03          	shl    $0x3,%rdx
    b529:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    b530:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    b534:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b538:	e8 d3 80 ff ff       	call   3610 <memmove@plt>
    b53d:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b541:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    b545:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b548:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    b54f:	45 85 ed             	test   %r13d,%r13d
    b552:	74 23                	je     b577 <fwp_hof0.constprop.0+0x857>
    b554:	45 89 ed             	mov    %r13d,%r13d
    b557:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    b55b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b560:	49 8b 14 24          	mov    (%r12),%rdx
    b564:	89 c8                	mov    %ecx,%eax
    b566:	49 83 c4 08          	add    $0x8,%r12
    b56a:	83 c1 01             	add    $0x1,%ecx
    b56d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    b572:	4c 39 e6             	cmp    %r12,%rsi
    b575:	75 e9                	jne    b560 <fwp_hof0.constprop.0+0x840>
    b577:	48 8d 35 62 82 01 00 	lea    0x18262(%rip),%rsi        # 237e0 <fwp_heap>
    b57e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b582:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b589:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b590:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b594:	48 c1 e2 10          	shl    $0x10,%rdx
    b598:	48 39 d0             	cmp    %rdx,%rax
    b59b:	73 54                	jae    b5f1 <fwp_hof0.constprop.0+0x8d1>
    b59d:	48 89 c2             	mov    %rax,%rdx
    b5a0:	48 c1 ea 10          	shr    $0x10,%rdx
    b5a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b5a8:	48 8b 15 29 96 01 00 	mov    0x19629(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    b5af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5b3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b5b7:	48 85 c9             	test   %rcx,%rcx
    b5ba:	74 35                	je     b5f1 <fwp_hof0.constprop.0+0x8d1>
    b5bc:	0f b6 32             	movzbl (%rdx),%esi
    b5bf:	40 80 fe 02          	cmp    $0x2,%sil
    b5c3:	0f 84 52 02 00 00    	je     b81b <fwp_hof0.constprop.0+0xafb>
    b5c9:	40 80 fe 01          	cmp    $0x1,%sil
    b5cd:	75 22                	jne    b5f1 <fwp_hof0.constprop.0+0x8d1>
    b5cf:	8b 72 18             	mov    0x18(%rdx),%esi
    b5d2:	0f b7 c0             	movzwl %ax,%eax
    b5d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5d8:	48 0f af c6          	imul   %rsi,%rax
    b5dc:	48 c1 e8 20          	shr    $0x20,%rax
    b5e0:	48 39 d0             	cmp    %rdx,%rax
    b5e3:	73 0c                	jae    b5f1 <fwp_hof0.constprop.0+0x8d1>
    b5e5:	48 01 c1             	add    %rax,%rcx
    b5e8:	80 39 01             	cmpb   $0x1,(%rcx)
    b5eb:	0f 84 9f 01 00 00    	je     b790 <fwp_hof0.constprop.0+0xa70>
    b5f1:	49 8b 40 18          	mov    0x18(%r8),%rax
    b5f5:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b5f9:	be 01 00 00 00       	mov    $0x1,%esi
    b5fe:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b602:	ff 50 08             	call   *0x8(%rax)
    b605:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b609:	48 8d 35 d0 81 01 00 	lea    0x181d0(%rip),%rsi        # 237e0 <fwp_heap>
    b610:	4c 89 d0             	mov    %r10,%rax
    b613:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b61a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b621:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b625:	48 c1 e2 10          	shl    $0x10,%rdx
    b629:	48 39 d0             	cmp    %rdx,%rax
    b62c:	73 59                	jae    b687 <fwp_hof0.constprop.0+0x967>
    b62e:	48 89 c2             	mov    %rax,%rdx
    b631:	48 c1 ea 10          	shr    $0x10,%rdx
    b635:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b639:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b640:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b644:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b648:	4d 85 e4             	test   %r12,%r12
    b64b:	74 3a                	je     b687 <fwp_hof0.constprop.0+0x967>
    b64d:	0f b6 0a             	movzbl (%rdx),%ecx
    b650:	80 f9 02             	cmp    $0x2,%cl
    b653:	0f 84 99 01 00 00    	je     b7f2 <fwp_hof0.constprop.0+0xad2>
    b659:	80 f9 01             	cmp    $0x1,%cl
    b65c:	75 29                	jne    b687 <fwp_hof0.constprop.0+0x967>
    b65e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b661:	0f b7 c0             	movzwl %ax,%eax
    b664:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b667:	48 0f af c1          	imul   %rcx,%rax
    b66b:	48 c1 e8 20          	shr    $0x20,%rax
    b66f:	48 39 d0             	cmp    %rdx,%rax
    b672:	73 13                	jae    b687 <fwp_hof0.constprop.0+0x967>
    b674:	49 01 c4             	add    %rax,%r12
    b677:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b67c:	0f 84 84 01 00 00    	je     b806 <fwp_hof0.constprop.0+0xae6>
    b682:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b687:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b68b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b68f:	e8 9c bb ff ff       	call   7230 <fwp_closure_drop>
    b694:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b698:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b69c:	e9 c2 fa ff ff       	jmp    b163 <fwp_hof0.constprop.0+0x443>
    b6a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6a8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b6ac:	e9 b2 fa ff ff       	jmp    b163 <fwp_hof0.constprop.0+0x443>
    b6b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6b8:	41 8b 34 24          	mov    (%r12),%esi
    b6bc:	8b 05 5a 79 00 00    	mov    0x795a(%rip),%eax        # 1301c <fc12+0x4>
    b6c2:	89 f7                	mov    %esi,%edi
    b6c4:	29 c7                	sub    %eax,%edi
    b6c6:	83 ff 01             	cmp    $0x1,%edi
    b6c9:	0f 85 6e f7 ff ff    	jne    ae3d <fwp_hof0.constprop.0+0x11d>
    b6cf:	48 89 e3             	mov    %rsp,%rbx
    b6d2:	85 c0                	test   %eax,%eax
    b6d4:	0f 84 60 01 00 00    	je     b83a <fwp_hof0.constprop.0+0xb1a>
    b6da:	89 f1                	mov    %esi,%ecx
    b6dc:	ba 08 00 00 00       	mov    $0x8,%edx
    b6e1:	48 c1 e1 03          	shl    $0x3,%rcx
    b6e5:	85 f6                	test   %esi,%esi
    b6e7:	48 89 e6             	mov    %rsp,%rsi
    b6ea:	48 0f 45 d1          	cmovne %rcx,%rdx
    b6ee:	49 89 d7             	mov    %rdx,%r15
    b6f1:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b6f5:	48 c1 ea 04          	shr    $0x4,%rdx
    b6f9:	48 c1 e2 04          	shl    $0x4,%rdx
    b6fd:	48 89 d7             	mov    %rdx,%rdi
    b700:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b707:	48 29 fe             	sub    %rdi,%rsi
    b70a:	48 39 f4             	cmp    %rsi,%rsp
    b70d:	74 15                	je     b724 <fwp_hof0.constprop.0+0xa04>
    b70f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b716:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b71d:	00 00 
    b71f:	48 39 f4             	cmp    %rsi,%rsp
    b722:	75 eb                	jne    b70f <fwp_hof0.constprop.0+0x9ef>
    b724:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b72a:	48 29 d4             	sub    %rdx,%rsp
    b72d:	48 85 d2             	test   %rdx,%rdx
    b730:	74 06                	je     b738 <fwp_hof0.constprop.0+0xa18>
    b732:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b738:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b73f:	00 
    b740:	4c 89 f9             	mov    %r15,%rcx
    b743:	48 8d 35 d6 78 00 00 	lea    0x78d6(%rip),%rsi        # 13020 <descent_active_phase>
    b74a:	48 89 e7             	mov    %rsp,%rdi
    b74d:	4c 89 f2             	mov    %r14,%rdx
    b750:	e8 1b 7e ff ff       	call   3570 <__memcpy_chk@plt>
    b755:	4d 39 f7             	cmp    %r14,%r15
    b758:	4c 89 f9             	mov    %r15,%rcx
    b75b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b75f:	49 0f 42 ce          	cmovb  %r14,%rcx
    b763:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b76a:	ba 08 00 00 00       	mov    $0x8,%edx
    b76f:	4c 29 f1             	sub    %r14,%rcx
    b772:	e8 f9 7d ff ff       	call   3570 <__memcpy_chk@plt>
    b777:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b77c:	48 89 e7             	mov    %rsp,%rdi
    b77f:	ff 10                	call   *(%rax)
    b781:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b785:	e9 bd 00 00 00       	jmp    b847 <fwp_hof0.constprop.0+0xb27>
    b78a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b790:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b797:	00 
    b798:	e9 6c fe ff ff       	jmp    b609 <fwp_hof0.constprop.0+0x8e9>
    b79d:	66 85 c0             	test   %ax,%ax
    b7a0:	0f 85 22 f7 ff ff    	jne    aec8 <fwp_hof0.constprop.0+0x1a8>
    b7a6:	e9 09 f7 ff ff       	jmp    aeb4 <fwp_hof0.constprop.0+0x194>
    b7ab:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b7af:	4d 85 d2             	test   %r10,%r10
    b7b2:	74 19                	je     b7cd <fwp_hof0.constprop.0+0xaad>
    b7b4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b7b8:	4d 29 d3             	sub    %r10,%r11
    b7bb:	49 39 c3             	cmp    %rax,%r11
    b7be:	72 0d                	jb     b7cd <fwp_hof0.constprop.0+0xaad>
    b7c0:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b7c4:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b7c8:	e9 98 fc ff ff       	jmp    b465 <fwp_hof0.constprop.0+0x745>
    b7cd:	31 f6                	xor    %esi,%esi
    b7cf:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b7d2:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b7d6:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b7da:	e8 b1 a4 ff ff       	call   5c90 <fwp_heap_alloc>
    b7df:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b7e2:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b7e6:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b7ea:	49 89 c2             	mov    %rax,%r10
    b7ed:	e9 0f fd ff ff       	jmp    b501 <fwp_hof0.constprop.0+0x7e1>
    b7f2:	66 85 c0             	test   %ax,%ax
    b7f5:	0f 85 8c fe ff ff    	jne    b687 <fwp_hof0.constprop.0+0x967>
    b7fb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b800:	0f 85 7c fe ff ff    	jne    b682 <fwp_hof0.constprop.0+0x962>
    b806:	4c 89 e7             	mov    %r12,%rdi
    b809:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b80d:	e8 3e 9d ff ff       	call   5550 <fwp_rc_forget_slot>
    b812:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b816:	e9 67 fe ff ff       	jmp    b682 <fwp_hof0.constprop.0+0x962>
    b81b:	66 85 c0             	test   %ax,%ax
    b81e:	0f 85 cd fd ff ff    	jne    b5f1 <fwp_hof0.constprop.0+0x8d1>
    b824:	e9 bf fd ff ff       	jmp    b5e8 <fwp_hof0.constprop.0+0x8c8>
    b829:	e8 02 9c ff ff       	call   5430 <fwp_rc_wide_dup>
    b82e:	48 8b 15 03 9c 01 00 	mov    0x19c03(%rip),%rdx        # 25438 <fwp_fns>
    b835:	e9 8e f6 ff ff       	jmp    aec8 <fwp_hof0.constprop.0+0x1a8>
    b83a:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b841:	ff 11                	call   *(%rcx)
    b843:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b847:	48 89 dc             	mov    %rbx,%rsp
    b84a:	e9 a7 f9 ff ff       	jmp    b1f6 <fwp_hof0.constprop.0+0x4d6>
    b84f:	48 89 c7             	mov    %rax,%rdi
    b852:	e8 b9 b2 ff ff       	call   6b10 <fwp_rc_share>
    b857:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b85b:	e8 b0 b2 ff ff       	call   6b10 <fwp_rc_share>
    b860:	48 8d 05 b1 77 00 00 	lea    0x77b1(%rip),%rax        # 13018 <fc12>
    b867:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b86e:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b872:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b879:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b87d:	e9 60 f9 ff ff       	jmp    b1e2 <fwp_hof0.constprop.0+0x4c2>
    b882:	66 85 c0             	test   %ax,%ax
    b885:	0f 85 5c f5 ff ff    	jne    ade7 <fwp_hof0.constprop.0+0xc7>
    b88b:	e9 43 f5 ff ff       	jmp    add3 <fwp_hof0.constprop.0+0xb3>
    b890:	48 89 df             	mov    %rbx,%rdi
    b893:	e8 a8 b3 ff ff       	call   6c40 <fwp_rc_free_arr>
    b898:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b89c:	4d 85 ff             	test   %r15,%r15
    b89f:	0f 85 bc f4 ff ff    	jne    ad61 <fwp_hof0.constprop.0+0x41>
    b8a5:	e9 2f fb ff ff       	jmp    b3d9 <fwp_hof0.constprop.0+0x6b9>
    b8aa:	66 85 c0             	test   %ax,%ax
    b8ad:	0f 85 5a fa ff ff    	jne    b30d <fwp_hof0.constprop.0+0x5ed>
    b8b3:	e9 47 fa ff ff       	jmp    b2ff <fwp_hof0.constprop.0+0x5df>
    b8b8:	66 85 c0             	test   %ax,%ax
    b8bb:	0f 85 0b fb ff ff    	jne    b3cc <fwp_hof0.constprop.0+0x6ac>
    b8c1:	e9 e6 fa ff ff       	jmp    b3ac <fwp_hof0.constprop.0+0x68c>
    b8c6:	4c 89 e0             	mov    %r12,%rax
    b8c9:	48 8d 35 10 7f 01 00 	lea    0x17f10(%rip),%rsi        # 237e0 <fwp_heap>
    b8d0:	48 c1 e8 11          	shr    $0x11,%rax
    b8d4:	4c 31 e0             	xor    %r12,%rax
    b8d7:	48 89 c2             	mov    %rax,%rdx
    b8da:	48 c1 ea 09          	shr    $0x9,%rdx
    b8de:	48 31 d0             	xor    %rdx,%rax
    b8e1:	0f b6 c0             	movzbl %al,%eax
    b8e4:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b8eb:	00 
    b8ec:	48 85 d2             	test   %rdx,%rdx
    b8ef:	75 18                	jne    b909 <fwp_hof0.constprop.0+0xbe9>
    b8f1:	eb 4d                	jmp    b940 <fwp_hof0.constprop.0+0xc20>
    b8f3:	66 90                	xchg   %ax,%ax
    b8f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b8fc:	00 00 00 00 
    b900:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b904:	48 85 d2             	test   %rdx,%rdx
    b907:	74 37                	je     b940 <fwp_hof0.constprop.0+0xc20>
    b909:	48 89 d0             	mov    %rdx,%rax
    b90c:	4c 39 22             	cmp    %r12,(%rdx)
    b90f:	75 ef                	jne    b900 <fwp_hof0.constprop.0+0xbe0>
    b911:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b915:	48 83 e8 01          	sub    $0x1,%rax
    b919:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b91d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b923:	0f 85 a3 fa ff ff    	jne    b3cc <fwp_hof0.constprop.0+0x6ac>
    b929:	4c 89 e7             	mov    %r12,%rdi
    b92c:	e8 1f 9c ff ff       	call   5550 <fwp_rc_forget_slot>
    b931:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b936:	e9 91 fa ff ff       	jmp    b3cc <fwp_hof0.constprop.0+0x6ac>
    b93b:	e8 70 83 ff ff       	call   3cb0 <fwp_heap_oom>
    b940:	48 8d 3d 41 3f 00 00 	lea    0x3f41(%rip),%rdi        # f888 <_IO_stdin_used+0x888>
    b947:	e8 a4 8a ff ff       	call   43f0 <fwp_trap>
    b94c:	48 8d 3d f3 38 00 00 	lea    0x38f3(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b953:	e8 98 8a ff ff       	call   43f0 <fwp_trap>
    b958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b95f:	00 
    b960:	e8 cb 9a ff ff       	call   5430 <fwp_rc_wide_dup>
    b965:	e9 7d f4 ff ff       	jmp    ade7 <fwp_hof0.constprop.0+0xc7>
    b96a:	e8 f1 7a ff ff       	call   3460 <__stack_chk_fail@plt>
    b96f:	90                   	nop
    b970:	4c 89 f7             	mov    %r14,%rdi
    b973:	e8 d8 9b ff ff       	call   5550 <fwp_rc_forget_slot>
    b978:	e9 8c f9 ff ff       	jmp    b309 <fwp_hof0.constprop.0+0x5e9>
    b97d:	0f 1f 00             	nopl   (%rax)

000000000000b980 <f0>:
    b980:	41 56                	push   %r14
    b982:	4c 8d 35 57 7e 01 00 	lea    0x17e57(%rip),%r14        # 237e0 <fwp_heap>
    b989:	41 55                	push   %r13
    b98b:	41 54                	push   %r12
    b98d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b993:	55                   	push   %rbp
    b994:	53                   	push   %rbx
    b995:	31 db                	xor    %ebx,%ebx
    b997:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b99e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b9a5:	00 00 
    b9a7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b9ae:	00 
    b9af:	31 c0                	xor    %eax,%eax
    b9b1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b9b8:	00 
    b9b9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b9c0:	00 00 
    b9c2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b9c7:	48 8d 05 02 b7 ff ff 	lea    -0x48fe(%rip),%rax        # 70d0 <fwp_drop1>
    b9ce:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b9d3:	48 8b 05 9e 9a 01 00 	mov    0x19a9e(%rip),%rax        # 25478 <fwp_cleanups>
    b9da:	48 89 25 97 9a 01 00 	mov    %rsp,0x19a97(%rip)        # 25478 <fwp_cleanups>
    b9e1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b9e5:	48 89 04 24          	mov    %rax,(%rsp)
    b9e9:	48 8d 05 e0 81 ff ff 	lea    -0x7e20(%rip),%rax        # 3bd0 <fwp_range_release>
    b9f0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b9f5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b9fa:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b9ff:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    ba04:	eb 47                	jmp    ba4d <f0+0xcd>
    ba06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ba0d:	00 00 00 
    ba10:	80 f9 01             	cmp    $0x1,%cl
    ba13:	75 29                	jne    ba3e <f0+0xbe>
    ba15:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba18:	0f b7 c0             	movzwl %ax,%eax
    ba1b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba1e:	48 0f af c1          	imul   %rcx,%rax
    ba22:	48 c1 e8 20          	shr    $0x20,%rax
    ba26:	48 39 d0             	cmp    %rdx,%rax
    ba29:	73 13                	jae    ba3e <f0+0xbe>
    ba2b:	49 01 c5             	add    %rax,%r13
    ba2e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ba33:	0f 84 c7 27 00 00    	je     e200 <f0+0x2880>
    ba39:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    ba3e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    ba43:	49 83 ec 01          	sub    $0x1,%r12
    ba47:	0f 82 83 00 00 00    	jb     bad0 <f0+0x150>
    ba4d:	48 89 ee             	mov    %rbp,%rsi
    ba50:	bf 01 00 00 00       	mov    $0x1,%edi
    ba55:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    ba5c:	00 
    ba5d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    ba62:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    ba69:	00 
    ba6a:	e8 71 af ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ba6f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    ba76:	48 89 c3             	mov    %rax,%rbx
    ba79:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ba80:	48 c1 e2 10          	shl    $0x10,%rdx
    ba84:	48 39 d0             	cmp    %rdx,%rax
    ba87:	73 b5                	jae    ba3e <f0+0xbe>
    ba89:	48 89 c2             	mov    %rax,%rdx
    ba8c:	48 c1 ea 10          	shr    $0x10,%rdx
    ba90:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba94:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    ba9b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba9f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    baa3:	4d 85 ed             	test   %r13,%r13
    baa6:	74 96                	je     ba3e <f0+0xbe>
    baa8:	0f b6 0a             	movzbl (%rdx),%ecx
    baab:	80 f9 02             	cmp    $0x2,%cl
    baae:	0f 85 5c ff ff ff    	jne    ba10 <f0+0x90>
    bab4:	66 85 c0             	test   %ax,%ax
    bab7:	0f 84 71 ff ff ff    	je     ba2e <f0+0xae>
    babd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    bac2:	49 83 ec 01          	sub    $0x1,%r12
    bac6:	73 85                	jae    ba4d <f0+0xcd>
    bac8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    bacf:	00 
    bad0:	48 8b 04 24          	mov    (%rsp),%rax
    bad4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    bad9:	bf 01 00 00 00       	mov    $0x1,%edi
    bade:	66 0f 6f 05 2a 41 00 	movdqa 0x412a(%rip),%xmm0        # fc10 <msg.4+0xa0>
    bae5:	00 
    bae6:	48 89 05 8b 99 01 00 	mov    %rax,0x1998b(%rip)        # 25478 <fwp_cleanups>
    baed:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    baf2:	e8 e9 ae ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    baf7:	48 8b 15 ba 90 01 00 	mov    0x190ba(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bafe:	49 89 c5             	mov    %rax,%r13
    bb01:	48 2b 05 88 90 01 00 	sub    0x19088(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bb08:	48 c1 e2 10          	shl    $0x10,%rdx
    bb0c:	48 39 d0             	cmp    %rdx,%rax
    bb0f:	73 59                	jae    bb6a <f0+0x1ea>
    bb11:	48 89 c2             	mov    %rax,%rdx
    bb14:	48 c1 ea 10          	shr    $0x10,%rdx
    bb18:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb1c:	48 8b 15 b5 90 01 00 	mov    0x190b5(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bb23:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb27:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bb2b:	4d 85 e4             	test   %r12,%r12
    bb2e:	74 3a                	je     bb6a <f0+0x1ea>
    bb30:	0f b6 0a             	movzbl (%rdx),%ecx
    bb33:	80 f9 02             	cmp    $0x2,%cl
    bb36:	0f 84 74 27 00 00    	je     e2b0 <f0+0x2930>
    bb3c:	80 f9 01             	cmp    $0x1,%cl
    bb3f:	75 29                	jne    bb6a <f0+0x1ea>
    bb41:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb44:	0f b7 c0             	movzwl %ax,%eax
    bb47:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb4a:	48 0f af c1          	imul   %rcx,%rax
    bb4e:	48 c1 e8 20          	shr    $0x20,%rax
    bb52:	48 39 d0             	cmp    %rdx,%rax
    bb55:	73 13                	jae    bb6a <f0+0x1ea>
    bb57:	49 01 c4             	add    %rax,%r12
    bb5a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bb5f:	0f 84 26 29 00 00    	je     e48b <f0+0x2b0b>
    bb65:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bb6a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    bb6f:	bf 01 00 00 00       	mov    $0x1,%edi
    bb74:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    bb79:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bb80:	00 f0 3f 
    bb83:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    bb88:	e8 53 ae ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bb8d:	48 8b 15 24 90 01 00 	mov    0x19024(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bb94:	49 89 c5             	mov    %rax,%r13
    bb97:	48 2b 05 f2 8f 01 00 	sub    0x18ff2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bb9e:	48 c1 e2 10          	shl    $0x10,%rdx
    bba2:	48 39 d0             	cmp    %rdx,%rax
    bba5:	73 59                	jae    bc00 <f0+0x280>
    bba7:	48 89 c2             	mov    %rax,%rdx
    bbaa:	48 c1 ea 10          	shr    $0x10,%rdx
    bbae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bbb2:	48 8b 15 1f 90 01 00 	mov    0x1901f(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bbb9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bbbd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bbc1:	4d 85 e4             	test   %r12,%r12
    bbc4:	74 3a                	je     bc00 <f0+0x280>
    bbc6:	0f b6 0a             	movzbl (%rdx),%ecx
    bbc9:	80 f9 02             	cmp    $0x2,%cl
    bbcc:	0f 84 ce 26 00 00    	je     e2a0 <f0+0x2920>
    bbd2:	80 f9 01             	cmp    $0x1,%cl
    bbd5:	75 29                	jne    bc00 <f0+0x280>
    bbd7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bbda:	0f b7 c0             	movzwl %ax,%eax
    bbdd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bbe0:	48 0f af c1          	imul   %rcx,%rax
    bbe4:	48 c1 e8 20          	shr    $0x20,%rax
    bbe8:	48 39 d0             	cmp    %rdx,%rax
    bbeb:	73 13                	jae    bc00 <f0+0x280>
    bbed:	49 01 c4             	add    %rax,%r12
    bbf0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bbf5:	0f 84 9d 28 00 00    	je     e498 <f0+0x2b18>
    bbfb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bc00:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    bc05:	bf 01 00 00 00       	mov    $0x1,%edi
    bc0a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    bc0f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bc16:	33 f3 bf 
    bc19:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    bc1e:	e8 bd ad ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bc23:	48 8b 15 8e 8f 01 00 	mov    0x18f8e(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bc2a:	49 89 c5             	mov    %rax,%r13
    bc2d:	48 2b 05 5c 8f 01 00 	sub    0x18f5c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bc34:	48 c1 e2 10          	shl    $0x10,%rdx
    bc38:	48 39 d0             	cmp    %rdx,%rax
    bc3b:	73 59                	jae    bc96 <f0+0x316>
    bc3d:	48 89 c2             	mov    %rax,%rdx
    bc40:	48 c1 ea 10          	shr    $0x10,%rdx
    bc44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc48:	48 8b 15 89 8f 01 00 	mov    0x18f89(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bc4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc53:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bc57:	4d 85 e4             	test   %r12,%r12
    bc5a:	74 3a                	je     bc96 <f0+0x316>
    bc5c:	0f b6 0a             	movzbl (%rdx),%ecx
    bc5f:	80 f9 02             	cmp    $0x2,%cl
    bc62:	0f 84 28 26 00 00    	je     e290 <f0+0x2910>
    bc68:	80 f9 01             	cmp    $0x1,%cl
    bc6b:	75 29                	jne    bc96 <f0+0x316>
    bc6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bc70:	0f b7 c0             	movzwl %ax,%eax
    bc73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bc76:	48 0f af c1          	imul   %rcx,%rax
    bc7a:	48 c1 e8 20          	shr    $0x20,%rax
    bc7e:	48 39 d0             	cmp    %rdx,%rax
    bc81:	73 13                	jae    bc96 <f0+0x316>
    bc83:	49 01 c4             	add    %rax,%r12
    bc86:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bc8b:	0f 84 14 28 00 00    	je     e4a5 <f0+0x2b25>
    bc91:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bc96:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    bc9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bca0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    bca5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bcac:	00 f0 3f 
    bcaf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    bcb4:	e8 27 ad ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bcb9:	48 8b 15 f8 8e 01 00 	mov    0x18ef8(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bcc0:	49 89 c5             	mov    %rax,%r13
    bcc3:	48 2b 05 c6 8e 01 00 	sub    0x18ec6(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bcca:	48 c1 e2 10          	shl    $0x10,%rdx
    bcce:	48 39 d0             	cmp    %rdx,%rax
    bcd1:	73 59                	jae    bd2c <f0+0x3ac>
    bcd3:	48 89 c2             	mov    %rax,%rdx
    bcd6:	48 c1 ea 10          	shr    $0x10,%rdx
    bcda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bcde:	48 8b 15 f3 8e 01 00 	mov    0x18ef3(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bce5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bce9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bced:	4d 85 e4             	test   %r12,%r12
    bcf0:	74 3a                	je     bd2c <f0+0x3ac>
    bcf2:	0f b6 0a             	movzbl (%rdx),%ecx
    bcf5:	80 f9 02             	cmp    $0x2,%cl
    bcf8:	0f 84 f2 25 00 00    	je     e2f0 <f0+0x2970>
    bcfe:	80 f9 01             	cmp    $0x1,%cl
    bd01:	75 29                	jne    bd2c <f0+0x3ac>
    bd03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bd06:	0f b7 c0             	movzwl %ax,%eax
    bd09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bd0c:	48 0f af c1          	imul   %rcx,%rax
    bd10:	48 c1 e8 20          	shr    $0x20,%rax
    bd14:	48 39 d0             	cmp    %rdx,%rax
    bd17:	73 13                	jae    bd2c <f0+0x3ac>
    bd19:	49 01 c4             	add    %rax,%r12
    bd1c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bd21:	0f 84 8b 27 00 00    	je     e4b2 <f0+0x2b32>
    bd27:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bd2c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bd33:	33 f3 bf 
    bd36:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    bd3d:	00 
    bd3e:	bf 01 00 00 00       	mov    $0x1,%edi
    bd43:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    bd4a:	00 
    bd4b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    bd52:	00 
    bd53:	e8 88 ac ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bd58:	48 8b 15 59 8e 01 00 	mov    0x18e59(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    bd5f:	49 89 c5             	mov    %rax,%r13
    bd62:	48 2b 05 27 8e 01 00 	sub    0x18e27(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    bd69:	48 c1 e2 10          	shl    $0x10,%rdx
    bd6d:	48 39 d0             	cmp    %rdx,%rax
    bd70:	73 59                	jae    bdcb <f0+0x44b>
    bd72:	48 89 c2             	mov    %rax,%rdx
    bd75:	48 c1 ea 10          	shr    $0x10,%rdx
    bd79:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bd7d:	48 8b 15 54 8e 01 00 	mov    0x18e54(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    bd84:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bd88:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bd8c:	4d 85 e4             	test   %r12,%r12
    bd8f:	74 3a                	je     bdcb <f0+0x44b>
    bd91:	0f b6 0a             	movzbl (%rdx),%ecx
    bd94:	80 f9 02             	cmp    $0x2,%cl
    bd97:	0f 84 43 25 00 00    	je     e2e0 <f0+0x2960>
    bd9d:	80 f9 01             	cmp    $0x1,%cl
    bda0:	75 29                	jne    bdcb <f0+0x44b>
    bda2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bda5:	0f b7 c0             	movzwl %ax,%eax
    bda8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bdab:	48 0f af c1          	imul   %rcx,%rax
    bdaf:	48 c1 e8 20          	shr    $0x20,%rax
    bdb3:	48 39 d0             	cmp    %rdx,%rax
    bdb6:	73 13                	jae    bdcb <f0+0x44b>
    bdb8:	49 01 c4             	add    %rax,%r12
    bdbb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bdc0:	0f 84 f9 26 00 00    	je     e4bf <f0+0x2b3f>
    bdc6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bdcb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    bdd2:	00 f0 3f 
    bdd5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    bddc:	00 
    bddd:	bf 01 00 00 00       	mov    $0x1,%edi
    bde2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    bde9:	00 
    bdea:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    bdf1:	00 
    bdf2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    bdf9:	33 f3 bf 
    bdfc:	e8 df ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    be01:	48 89 c7             	mov    %rax,%rdi
    be04:	e8 87 ad ff ff       	call   6b90 <fwp_rc_fresh>
    be09:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    be10:	00 
    be11:	bf 01 00 00 00       	mov    $0x1,%edi
    be16:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    be1d:	00 
    be1e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    be25:	00 
    be26:	e8 b5 ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    be2b:	48 89 c7             	mov    %rax,%rdi
    be2e:	e8 5d ad ff ff       	call   6b90 <fwp_rc_fresh>
    be33:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    be3a:	00 
    be3b:	bf 01 00 00 00       	mov    $0x1,%edi
    be40:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    be47:	00 
    be48:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    be4f:	00 
    be50:	e8 8b ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    be55:	48 89 c7             	mov    %rax,%rdi
    be58:	e8 33 ad ff ff       	call   6b90 <fwp_rc_fresh>
    be5d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    be64:	00 
    be65:	bf 01 00 00 00       	mov    $0x1,%edi
    be6a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    be71:	00 
    be72:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    be79:	00 
    be7a:	e8 61 ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    be7f:	48 89 c7             	mov    %rax,%rdi
    be82:	e8 09 ad ff ff       	call   6b90 <fwp_rc_fresh>
    be87:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    be8e:	00 
    be8f:	bf 01 00 00 00       	mov    $0x1,%edi
    be94:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    be9b:	00 
    be9c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    bea3:	00 
    bea4:	e8 37 ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bea9:	48 89 c7             	mov    %rax,%rdi
    beac:	e8 df ac ff ff       	call   6b90 <fwp_rc_fresh>
    beb1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    beb8:	00 
    beb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bebe:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    bec5:	00 
    bec6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    becd:	00 
    bece:	e8 0d ab ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bed3:	48 89 c7             	mov    %rax,%rdi
    bed6:	e8 b5 ac ff ff       	call   6b90 <fwp_rc_fresh>
    bedb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    bee2:	00 
    bee3:	bf 01 00 00 00       	mov    $0x1,%edi
    bee8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    beef:	00 
    bef0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bef7:	00 
    bef8:	e8 e3 aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    befd:	48 89 c7             	mov    %rax,%rdi
    bf00:	e8 8b ac ff ff       	call   6b90 <fwp_rc_fresh>
    bf05:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bf0c:	00 
    bf0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf12:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bf19:	00 
    bf1a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bf21:	00 
    bf22:	e8 b9 aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bf27:	48 89 c7             	mov    %rax,%rdi
    bf2a:	e8 61 ac ff ff       	call   6b90 <fwp_rc_fresh>
    bf2f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    bf36:	00 
    bf37:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bf43:	00 
    bf44:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bf4b:	00 
    bf4c:	e8 8f aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bf51:	48 89 c7             	mov    %rax,%rdi
    bf54:	e8 37 ac ff ff       	call   6b90 <fwp_rc_fresh>
    bf59:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bf60:	00 
    bf61:	bf 01 00 00 00       	mov    $0x1,%edi
    bf66:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bf6d:	00 
    bf6e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bf75:	00 
    bf76:	e8 65 aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bf7b:	48 89 c7             	mov    %rax,%rdi
    bf7e:	e8 0d ac ff ff       	call   6b90 <fwp_rc_fresh>
    bf83:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bf8a:	00 
    bf8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf90:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bf97:	00 
    bf98:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bf9f:	00 
    bfa0:	e8 3b aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bfa5:	48 89 c7             	mov    %rax,%rdi
    bfa8:	e8 e3 ab ff ff       	call   6b90 <fwp_rc_fresh>
    bfad:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bfb4:	00 
    bfb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfba:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bfc1:	00 
    bfc2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bfc9:	00 
    bfca:	e8 11 aa ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bfcf:	48 89 c7             	mov    %rax,%rdi
    bfd2:	e8 b9 ab ff ff       	call   6b90 <fwp_rc_fresh>
    bfd7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bfde:	00 
    bfdf:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bfeb:	00 
    bfec:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bff3:	00 
    bff4:	e8 e7 a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bff9:	48 89 c7             	mov    %rax,%rdi
    bffc:	e8 8f ab ff ff       	call   6b90 <fwp_rc_fresh>
    c001:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c008:	00 
    c009:	bf 01 00 00 00       	mov    $0x1,%edi
    c00e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    c015:	00 
    c016:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c01d:	00 
    c01e:	e8 bd a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c023:	48 89 c7             	mov    %rax,%rdi
    c026:	e8 65 ab ff ff       	call   6b90 <fwp_rc_fresh>
    c02b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c032:	00 
    c033:	bf 01 00 00 00       	mov    $0x1,%edi
    c038:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    c03f:	00 
    c040:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c047:	00 
    c048:	e8 93 a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c04d:	48 89 c7             	mov    %rax,%rdi
    c050:	e8 3b ab ff ff       	call   6b90 <fwp_rc_fresh>
    c055:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c05c:	00 
    c05d:	bf 01 00 00 00       	mov    $0x1,%edi
    c062:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    c069:	00 
    c06a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c071:	00 
    c072:	e8 69 a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c077:	48 89 c7             	mov    %rax,%rdi
    c07a:	e8 11 ab ff ff       	call   6b90 <fwp_rc_fresh>
    c07f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c086:	00 
    c087:	bf 01 00 00 00       	mov    $0x1,%edi
    c08c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    c093:	00 
    c094:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c09b:	00 
    c09c:	e8 3f a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c0a1:	48 89 c7             	mov    %rax,%rdi
    c0a4:	e8 e7 aa ff ff       	call   6b90 <fwp_rc_fresh>
    c0a9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c0b0:	00 
    c0b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    c0bd:	00 
    c0be:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c0c5:	00 
    c0c6:	e8 15 a9 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c0cb:	48 89 c7             	mov    %rax,%rdi
    c0ce:	e8 bd aa ff ff       	call   6b90 <fwp_rc_fresh>
    c0d3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c0da:	00 
    c0db:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    c0e7:	00 
    c0e8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c0ef:	00 
    c0f0:	e8 eb a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c0f5:	48 89 c7             	mov    %rax,%rdi
    c0f8:	e8 93 aa ff ff       	call   6b90 <fwp_rc_fresh>
    c0fd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c104:	00 
    c105:	bf 01 00 00 00       	mov    $0x1,%edi
    c10a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    c111:	00 
    c112:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c119:	00 
    c11a:	e8 c1 a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c11f:	48 89 c7             	mov    %rax,%rdi
    c122:	e8 69 aa ff ff       	call   6b90 <fwp_rc_fresh>
    c127:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c12e:	00 
    c12f:	bf 01 00 00 00       	mov    $0x1,%edi
    c134:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    c13b:	00 
    c13c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c143:	00 
    c144:	e8 97 a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c149:	48 89 c7             	mov    %rax,%rdi
    c14c:	e8 3f aa ff ff       	call   6b90 <fwp_rc_fresh>
    c151:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c158:	00 
    c159:	bf 01 00 00 00       	mov    $0x1,%edi
    c15e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    c165:	00 
    c166:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c16d:	00 
    c16e:	e8 6d a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c173:	48 89 c7             	mov    %rax,%rdi
    c176:	e8 15 aa ff ff       	call   6b90 <fwp_rc_fresh>
    c17b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c182:	00 
    c183:	bf 01 00 00 00       	mov    $0x1,%edi
    c188:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    c18f:	00 
    c190:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c197:	00 
    c198:	e8 43 a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c19d:	48 89 c7             	mov    %rax,%rdi
    c1a0:	e8 eb a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c1a5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c1ac:	00 
    c1ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    c1b9:	00 
    c1ba:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c1c1:	00 
    c1c2:	e8 19 a8 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c1c7:	48 89 c7             	mov    %rax,%rdi
    c1ca:	e8 c1 a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c1cf:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c1d6:	00 
    c1d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1dc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    c1e3:	00 
    c1e4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c1eb:	00 
    c1ec:	e8 ef a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c1f1:	48 89 c7             	mov    %rax,%rdi
    c1f4:	e8 97 a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c1f9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c200:	00 
    c201:	bf 01 00 00 00       	mov    $0x1,%edi
    c206:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    c20d:	00 
    c20e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c215:	00 
    c216:	e8 c5 a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c21b:	48 89 c7             	mov    %rax,%rdi
    c21e:	e8 6d a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c223:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c22a:	00 
    c22b:	bf 01 00 00 00       	mov    $0x1,%edi
    c230:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    c237:	00 
    c238:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c23f:	00 
    c240:	e8 9b a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c245:	48 89 c7             	mov    %rax,%rdi
    c248:	e8 43 a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c24d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c254:	00 
    c255:	bf 01 00 00 00       	mov    $0x1,%edi
    c25a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    c261:	00 
    c262:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c269:	00 
    c26a:	e8 71 a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c26f:	48 89 c7             	mov    %rax,%rdi
    c272:	e8 19 a9 ff ff       	call   6b90 <fwp_rc_fresh>
    c277:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c27e:	00 
    c27f:	bf 01 00 00 00       	mov    $0x1,%edi
    c284:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    c28b:	00 
    c28c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c293:	00 
    c294:	e8 47 a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c299:	48 89 c7             	mov    %rax,%rdi
    c29c:	e8 ef a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c2a1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c2a8:	00 
    c2a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ae:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    c2b5:	00 
    c2b6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c2bd:	00 
    c2be:	e8 1d a7 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c2c3:	48 89 c7             	mov    %rax,%rdi
    c2c6:	e8 c5 a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c2cb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    c2d2:	00 
    c2d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    c2df:	00 
    c2e0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    c2e7:	00 
    c2e8:	e8 f3 a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c2ed:	48 89 c7             	mov    %rax,%rdi
    c2f0:	e8 9b a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c2f5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    c2fc:	00 
    c2fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c302:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    c309:	00 
    c30a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    c311:	00 
    c312:	e8 c9 a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c317:	48 89 c7             	mov    %rax,%rdi
    c31a:	e8 71 a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c31f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    c326:	00 
    c327:	bf 01 00 00 00       	mov    $0x1,%edi
    c32c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    c333:	00 
    c334:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    c33b:	00 
    c33c:	e8 9f a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c341:	48 89 c7             	mov    %rax,%rdi
    c344:	e8 47 a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c349:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    c350:	00 
    c351:	bf 01 00 00 00       	mov    $0x1,%edi
    c356:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    c35d:	00 
    c35e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    c365:	00 
    c366:	e8 75 a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c36b:	48 89 c7             	mov    %rax,%rdi
    c36e:	e8 1d a8 ff ff       	call   6b90 <fwp_rc_fresh>
    c373:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    c37a:	00 
    c37b:	bf 01 00 00 00       	mov    $0x1,%edi
    c380:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    c387:	00 
    c388:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    c38f:	00 
    c390:	e8 4b a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c395:	48 89 c7             	mov    %rax,%rdi
    c398:	e8 f3 a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c39d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    c3a4:	00 
    c3a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3aa:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    c3b1:	00 
    c3b2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    c3b9:	00 
    c3ba:	e8 21 a6 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c3bf:	48 89 c7             	mov    %rax,%rdi
    c3c2:	e8 c9 a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c3c7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    c3ce:	00 
    c3cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c3d4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    c3db:	00 
    c3dc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c3e3:	00 
    c3e4:	e8 f7 a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c3e9:	48 89 c7             	mov    %rax,%rdi
    c3ec:	e8 9f a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c3f1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c3f8:	00 
    c3f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3fe:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    c405:	00 
    c406:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c40d:	00 
    c40e:	e8 cd a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c413:	48 89 c7             	mov    %rax,%rdi
    c416:	e8 75 a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c41b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c422:	00 
    c423:	bf 01 00 00 00       	mov    $0x1,%edi
    c428:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    c42f:	00 
    c430:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c437:	00 
    c438:	e8 a3 a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c43d:	48 89 c7             	mov    %rax,%rdi
    c440:	e8 4b a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c445:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c44c:	00 
    c44d:	bf 01 00 00 00       	mov    $0x1,%edi
    c452:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c459:	00 
    c45a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c461:	00 
    c462:	e8 79 a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c467:	48 89 c7             	mov    %rax,%rdi
    c46a:	e8 21 a7 ff ff       	call   6b90 <fwp_rc_fresh>
    c46f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c476:	00 
    c477:	bf 01 00 00 00       	mov    $0x1,%edi
    c47c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c483:	00 
    c484:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c48b:	00 
    c48c:	e8 4f a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c491:	48 89 c7             	mov    %rax,%rdi
    c494:	e8 f7 a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c499:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c4a0:	00 
    c4a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4a6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c4ad:	00 
    c4ae:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c4b5:	00 
    c4b6:	e8 25 a5 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c4bb:	48 89 c7             	mov    %rax,%rdi
    c4be:	e8 cd a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c4c3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c4ca:	00 
    c4cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c4d0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c4d7:	00 
    c4d8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c4df:	00 
    c4e0:	e8 fb a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c4e5:	48 89 c7             	mov    %rax,%rdi
    c4e8:	e8 a3 a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c4ed:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c4f4:	00 
    c4f5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4fa:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c501:	00 
    c502:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c509:	00 
    c50a:	e8 d1 a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c50f:	48 89 c7             	mov    %rax,%rdi
    c512:	e8 79 a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c517:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c51e:	00 
    c51f:	bf 01 00 00 00       	mov    $0x1,%edi
    c524:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c52b:	00 
    c52c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c533:	00 
    c534:	e8 a7 a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c539:	48 89 c7             	mov    %rax,%rdi
    c53c:	e8 4f a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c541:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c548:	00 
    c549:	bf 01 00 00 00       	mov    $0x1,%edi
    c54e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c555:	00 
    c556:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c55d:	00 
    c55e:	e8 7d a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c563:	48 89 c7             	mov    %rax,%rdi
    c566:	e8 25 a6 ff ff       	call   6b90 <fwp_rc_fresh>
    c56b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c572:	00 
    c573:	bf 01 00 00 00       	mov    $0x1,%edi
    c578:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c57f:	00 
    c580:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c587:	00 
    c588:	e8 53 a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c58d:	48 89 c7             	mov    %rax,%rdi
    c590:	e8 fb a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c595:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c59c:	00 
    c59d:	bf 01 00 00 00       	mov    $0x1,%edi
    c5a2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c5a9:	00 
    c5aa:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c5b1:	00 
    c5b2:	e8 29 a4 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c5b7:	48 89 c7             	mov    %rax,%rdi
    c5ba:	e8 d1 a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c5bf:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c5c6:	00 
    c5c7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5cc:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c5d3:	00 
    c5d4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c5db:	00 
    c5dc:	e8 ff a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c5e1:	48 89 c7             	mov    %rax,%rdi
    c5e4:	e8 a7 a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c5e9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c5f0:	00 
    c5f1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5f6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c5fd:	00 
    c5fe:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c605:	00 
    c606:	e8 d5 a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c60b:	48 89 c7             	mov    %rax,%rdi
    c60e:	e8 7d a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c613:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c61a:	00 
    c61b:	bf 01 00 00 00       	mov    $0x1,%edi
    c620:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c627:	00 
    c628:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c62f:	00 
    c630:	e8 ab a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c635:	48 89 c7             	mov    %rax,%rdi
    c638:	e8 53 a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c63d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c644:	00 
    c645:	bf 01 00 00 00       	mov    $0x1,%edi
    c64a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c651:	00 
    c652:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c659:	00 
    c65a:	e8 81 a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c65f:	48 89 c7             	mov    %rax,%rdi
    c662:	e8 29 a5 ff ff       	call   6b90 <fwp_rc_fresh>
    c667:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c66e:	00 
    c66f:	bf 01 00 00 00       	mov    $0x1,%edi
    c674:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c67b:	00 
    c67c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c683:	00 
    c684:	e8 57 a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c689:	48 89 c7             	mov    %rax,%rdi
    c68c:	e8 ff a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c691:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c698:	00 
    c699:	bf 01 00 00 00       	mov    $0x1,%edi
    c69e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c6a5:	00 
    c6a6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c6ad:	00 
    c6ae:	e8 2d a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c6b3:	48 89 c7             	mov    %rax,%rdi
    c6b6:	e8 d5 a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c6bb:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c6c2:	00 
    c6c3:	bf 01 00 00 00       	mov    $0x1,%edi
    c6c8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c6cf:	00 
    c6d0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c6d7:	00 
    c6d8:	e8 03 a3 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c6dd:	48 89 c7             	mov    %rax,%rdi
    c6e0:	e8 ab a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c6e5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c6ec:	00 
    c6ed:	bf 01 00 00 00       	mov    $0x1,%edi
    c6f2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c6f9:	00 
    c6fa:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c701:	00 
    c702:	e8 d9 a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c707:	48 89 c7             	mov    %rax,%rdi
    c70a:	e8 81 a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c70f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c716:	00 
    c717:	bf 01 00 00 00       	mov    $0x1,%edi
    c71c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c723:	00 
    c724:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c72b:	00 
    c72c:	e8 af a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c731:	48 89 c7             	mov    %rax,%rdi
    c734:	e8 57 a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c739:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c740:	00 
    c741:	bf 01 00 00 00       	mov    $0x1,%edi
    c746:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c74d:	00 
    c74e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c755:	00 
    c756:	e8 85 a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c75b:	48 89 c7             	mov    %rax,%rdi
    c75e:	e8 2d a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c763:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c76a:	00 
    c76b:	bf 01 00 00 00       	mov    $0x1,%edi
    c770:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c777:	00 
    c778:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c77f:	00 
    c780:	e8 5b a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c785:	48 89 c7             	mov    %rax,%rdi
    c788:	e8 03 a4 ff ff       	call   6b90 <fwp_rc_fresh>
    c78d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c794:	00 
    c795:	bf 01 00 00 00       	mov    $0x1,%edi
    c79a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c7a1:	00 
    c7a2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c7a9:	00 
    c7aa:	e8 31 a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c7af:	48 89 c7             	mov    %rax,%rdi
    c7b2:	e8 d9 a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c7b7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c7be:	00 
    c7bf:	bf 01 00 00 00       	mov    $0x1,%edi
    c7c4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c7cb:	00 
    c7cc:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c7d3:	00 
    c7d4:	e8 07 a2 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c7d9:	48 89 c7             	mov    %rax,%rdi
    c7dc:	e8 af a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c7e1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c7e8:	00 
    c7e9:	bf 01 00 00 00       	mov    $0x1,%edi
    c7ee:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c7f5:	00 
    c7f6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c7fd:	00 
    c7fe:	e8 dd a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c803:	48 89 c7             	mov    %rax,%rdi
    c806:	e8 85 a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c80b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c812:	00 
    c813:	bf 01 00 00 00       	mov    $0x1,%edi
    c818:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c81f:	00 
    c820:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c827:	00 
    c828:	e8 b3 a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c82d:	48 89 c7             	mov    %rax,%rdi
    c830:	e8 5b a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c835:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c83c:	00 
    c83d:	bf 01 00 00 00       	mov    $0x1,%edi
    c842:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c849:	00 
    c84a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c851:	00 
    c852:	e8 89 a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c857:	48 89 c7             	mov    %rax,%rdi
    c85a:	e8 31 a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c85f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c866:	00 
    c867:	bf 01 00 00 00       	mov    $0x1,%edi
    c86c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c873:	00 
    c874:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c87b:	00 
    c87c:	e8 5f a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c881:	48 89 c7             	mov    %rax,%rdi
    c884:	e8 07 a3 ff ff       	call   6b90 <fwp_rc_fresh>
    c889:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c890:	00 
    c891:	bf 01 00 00 00       	mov    $0x1,%edi
    c896:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c89d:	00 
    c89e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c8a5:	00 
    c8a6:	e8 35 a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c8ab:	48 89 c7             	mov    %rax,%rdi
    c8ae:	e8 dd a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c8b3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c8ba:	00 
    c8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    c8c0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c8c7:	00 
    c8c8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c8cf:	00 
    c8d0:	e8 0b a1 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c8d5:	48 89 c7             	mov    %rax,%rdi
    c8d8:	e8 b3 a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c8dd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c8e4:	00 
    c8e5:	bf 01 00 00 00       	mov    $0x1,%edi
    c8ea:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c8f1:	00 
    c8f2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c8f9:	00 
    c8fa:	e8 e1 a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c8ff:	48 89 c7             	mov    %rax,%rdi
    c902:	e8 89 a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c907:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c90e:	00 
    c90f:	bf 01 00 00 00       	mov    $0x1,%edi
    c914:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c91b:	00 
    c91c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c923:	00 
    c924:	e8 b7 a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c929:	48 89 c7             	mov    %rax,%rdi
    c92c:	e8 5f a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c931:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c938:	00 
    c939:	bf 01 00 00 00       	mov    $0x1,%edi
    c93e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c945:	00 
    c946:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c94d:	00 
    c94e:	e8 8d a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c953:	48 89 c7             	mov    %rax,%rdi
    c956:	e8 35 a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c95b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c962:	00 
    c963:	bf 01 00 00 00       	mov    $0x1,%edi
    c968:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c96f:	00 
    c970:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c977:	00 
    c978:	e8 63 a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c97d:	48 89 c7             	mov    %rax,%rdi
    c980:	e8 0b a2 ff ff       	call   6b90 <fwp_rc_fresh>
    c985:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c98c:	00 
    c98d:	bf 01 00 00 00       	mov    $0x1,%edi
    c992:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c999:	00 
    c99a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c9a1:	00 
    c9a2:	e8 39 a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c9a7:	48 89 c7             	mov    %rax,%rdi
    c9aa:	e8 e1 a1 ff ff       	call   6b90 <fwp_rc_fresh>
    c9af:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c9b6:	00 
    c9b7:	bf 01 00 00 00       	mov    $0x1,%edi
    c9bc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c9c3:	00 
    c9c4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c9cb:	00 
    c9cc:	e8 0f a0 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c9d1:	48 89 c7             	mov    %rax,%rdi
    c9d4:	e8 b7 a1 ff ff       	call   6b90 <fwp_rc_fresh>
    c9d9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c9e0:	00 
    c9e1:	bf 01 00 00 00       	mov    $0x1,%edi
    c9e6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c9ed:	00 
    c9ee:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c9f5:	00 
    c9f6:	e8 e5 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    c9fb:	48 89 c7             	mov    %rax,%rdi
    c9fe:	e8 8d a1 ff ff       	call   6b90 <fwp_rc_fresh>
    ca03:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    ca0a:	00 
    ca0b:	bf 01 00 00 00       	mov    $0x1,%edi
    ca10:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    ca17:	00 
    ca18:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    ca1f:	00 
    ca20:	e8 bb 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ca25:	48 89 c7             	mov    %rax,%rdi
    ca28:	e8 63 a1 ff ff       	call   6b90 <fwp_rc_fresh>
    ca2d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    ca34:	00 
    ca35:	bf 01 00 00 00       	mov    $0x1,%edi
    ca3a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    ca41:	00 
    ca42:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    ca49:	00 
    ca4a:	e8 91 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ca4f:	48 89 c7             	mov    %rax,%rdi
    ca52:	e8 39 a1 ff ff       	call   6b90 <fwp_rc_fresh>
    ca57:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    ca5e:	00 
    ca5f:	bf 01 00 00 00       	mov    $0x1,%edi
    ca64:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    ca6b:	00 
    ca6c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    ca73:	00 
    ca74:	e8 67 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ca79:	48 89 c7             	mov    %rax,%rdi
    ca7c:	e8 0f a1 ff ff       	call   6b90 <fwp_rc_fresh>
    ca81:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    ca88:	00 
    ca89:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    ca95:	00 
    ca96:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    ca9d:	00 
    ca9e:	e8 3d 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    caa3:	48 89 c7             	mov    %rax,%rdi
    caa6:	e8 e5 a0 ff ff       	call   6b90 <fwp_rc_fresh>
    caab:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    cab2:	00 
    cab3:	bf 01 00 00 00       	mov    $0x1,%edi
    cab8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    cabf:	00 
    cac0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    cac7:	00 
    cac8:	e8 13 9f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cacd:	48 89 c7             	mov    %rax,%rdi
    cad0:	e8 bb a0 ff ff       	call   6b90 <fwp_rc_fresh>
    cad5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    cadc:	00 
    cadd:	bf 01 00 00 00       	mov    $0x1,%edi
    cae2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    cae9:	00 
    caea:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    caf1:	00 
    caf2:	e8 e9 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    caf7:	48 89 c7             	mov    %rax,%rdi
    cafa:	e8 91 a0 ff ff       	call   6b90 <fwp_rc_fresh>
    caff:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    cb06:	00 
    cb07:	bf 01 00 00 00       	mov    $0x1,%edi
    cb0c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    cb13:	00 
    cb14:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    cb1b:	00 
    cb1c:	e8 bf 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cb21:	48 89 c7             	mov    %rax,%rdi
    cb24:	e8 67 a0 ff ff       	call   6b90 <fwp_rc_fresh>
    cb29:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    cb30:	00 
    cb31:	bf 01 00 00 00       	mov    $0x1,%edi
    cb36:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    cb3d:	00 
    cb3e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    cb45:	00 
    cb46:	e8 95 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cb4b:	48 89 c7             	mov    %rax,%rdi
    cb4e:	e8 3d a0 ff ff       	call   6b90 <fwp_rc_fresh>
    cb53:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    cb5a:	00 
    cb5b:	bf 01 00 00 00       	mov    $0x1,%edi
    cb60:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    cb67:	00 
    cb68:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    cb6f:	00 
    cb70:	e8 6b 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cb75:	48 89 c7             	mov    %rax,%rdi
    cb78:	e8 13 a0 ff ff       	call   6b90 <fwp_rc_fresh>
    cb7d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    cb84:	00 
    cb85:	bf 01 00 00 00       	mov    $0x1,%edi
    cb8a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    cb91:	00 
    cb92:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    cb99:	00 
    cb9a:	e8 41 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cb9f:	48 89 c7             	mov    %rax,%rdi
    cba2:	e8 e9 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cba7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    cbae:	00 
    cbaf:	bf 01 00 00 00       	mov    $0x1,%edi
    cbb4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    cbbb:	00 
    cbbc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    cbc3:	00 
    cbc4:	e8 17 9e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cbc9:	48 89 c7             	mov    %rax,%rdi
    cbcc:	e8 bf 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cbd1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    cbd8:	00 
    cbd9:	bf 01 00 00 00       	mov    $0x1,%edi
    cbde:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    cbe5:	00 
    cbe6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    cbed:	00 
    cbee:	e8 ed 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cbf3:	48 89 c7             	mov    %rax,%rdi
    cbf6:	e8 95 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cbfb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    cc02:	00 
    cc03:	bf 01 00 00 00       	mov    $0x1,%edi
    cc08:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    cc0f:	00 
    cc10:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    cc17:	00 
    cc18:	e8 c3 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cc1d:	48 89 c7             	mov    %rax,%rdi
    cc20:	e8 6b 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cc25:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    cc2c:	00 
    cc2d:	bf 01 00 00 00       	mov    $0x1,%edi
    cc32:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    cc39:	00 
    cc3a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    cc41:	00 
    cc42:	e8 99 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cc47:	48 89 c7             	mov    %rax,%rdi
    cc4a:	e8 41 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cc4f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    cc56:	00 
    cc57:	bf 01 00 00 00       	mov    $0x1,%edi
    cc5c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    cc63:	00 
    cc64:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    cc6b:	00 
    cc6c:	e8 6f 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cc71:	48 89 c7             	mov    %rax,%rdi
    cc74:	e8 17 9f ff ff       	call   6b90 <fwp_rc_fresh>
    cc79:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    cc80:	00 
    cc81:	bf 01 00 00 00       	mov    $0x1,%edi
    cc86:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    cc8d:	00 
    cc8e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    cc95:	00 
    cc96:	e8 45 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cc9b:	48 89 c7             	mov    %rax,%rdi
    cc9e:	e8 ed 9e ff ff       	call   6b90 <fwp_rc_fresh>
    cca3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    ccaa:	00 
    ccab:	bf 01 00 00 00       	mov    $0x1,%edi
    ccb0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    ccb7:	00 
    ccb8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    ccbf:	00 
    ccc0:	e8 1b 9d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ccc5:	48 8b 15 ec 7e 01 00 	mov    0x17eec(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cccc:	49 89 c5             	mov    %rax,%r13
    cccf:	48 2b 05 ba 7e 01 00 	sub    0x17eba(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ccd6:	48 c1 e2 10          	shl    $0x10,%rdx
    ccda:	48 39 d0             	cmp    %rdx,%rax
    ccdd:	73 59                	jae    cd38 <f0+0x13b8>
    ccdf:	48 89 c2             	mov    %rax,%rdx
    cce2:	48 c1 ea 10          	shr    $0x10,%rdx
    cce6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccea:	48 8b 15 e7 7e 01 00 	mov    0x17ee7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ccf1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ccf5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccf9:	4d 85 e4             	test   %r12,%r12
    ccfc:	74 3a                	je     cd38 <f0+0x13b8>
    ccfe:	0f b6 0a             	movzbl (%rdx),%ecx
    cd01:	80 f9 02             	cmp    $0x2,%cl
    cd04:	0f 84 c6 15 00 00    	je     e2d0 <f0+0x2950>
    cd0a:	80 f9 01             	cmp    $0x1,%cl
    cd0d:	75 29                	jne    cd38 <f0+0x13b8>
    cd0f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd12:	0f b7 c0             	movzwl %ax,%eax
    cd15:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd18:	48 0f af c1          	imul   %rcx,%rax
    cd1c:	48 c1 e8 20          	shr    $0x20,%rax
    cd20:	48 39 d0             	cmp    %rdx,%rax
    cd23:	73 13                	jae    cd38 <f0+0x13b8>
    cd25:	49 01 c4             	add    %rax,%r12
    cd28:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd2d:	0f 84 99 17 00 00    	je     e4cc <f0+0x2b4c>
    cd33:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd38:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd3f:	33 f3 bf 
    cd42:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    cd49:	00 
    cd4a:	bf 01 00 00 00       	mov    $0x1,%edi
    cd4f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    cd56:	00 
    cd57:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    cd5e:	00 
    cd5f:	e8 7c 9c ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cd64:	48 8b 15 4d 7e 01 00 	mov    0x17e4d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cd6b:	49 89 c5             	mov    %rax,%r13
    cd6e:	48 2b 05 1b 7e 01 00 	sub    0x17e1b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cd75:	48 c1 e2 10          	shl    $0x10,%rdx
    cd79:	48 39 d0             	cmp    %rdx,%rax
    cd7c:	73 59                	jae    cdd7 <f0+0x1457>
    cd7e:	48 89 c2             	mov    %rax,%rdx
    cd81:	48 c1 ea 10          	shr    $0x10,%rdx
    cd85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd89:	48 8b 15 48 7e 01 00 	mov    0x17e48(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cd90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd94:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd98:	4d 85 e4             	test   %r12,%r12
    cd9b:	74 3a                	je     cdd7 <f0+0x1457>
    cd9d:	0f b6 0a             	movzbl (%rdx),%ecx
    cda0:	80 f9 02             	cmp    $0x2,%cl
    cda3:	0f 84 17 15 00 00    	je     e2c0 <f0+0x2940>
    cda9:	80 f9 01             	cmp    $0x1,%cl
    cdac:	75 29                	jne    cdd7 <f0+0x1457>
    cdae:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdb1:	0f b7 c0             	movzwl %ax,%eax
    cdb4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdb7:	48 0f af c1          	imul   %rcx,%rax
    cdbb:	48 c1 e8 20          	shr    $0x20,%rax
    cdbf:	48 39 d0             	cmp    %rdx,%rax
    cdc2:	73 13                	jae    cdd7 <f0+0x1457>
    cdc4:	49 01 c4             	add    %rax,%r12
    cdc7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cdcc:	0f 84 07 17 00 00    	je     e4d9 <f0+0x2b59>
    cdd2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdd7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdde:	00 f0 3f 
    cde1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    cde8:	00 
    cde9:	bf 01 00 00 00       	mov    $0x1,%edi
    cdee:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    cdf5:	00 
    cdf6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    cdfd:	00 
    cdfe:	e8 dd 9b ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ce03:	48 8b 15 ae 7d 01 00 	mov    0x17dae(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    ce0a:	49 89 c5             	mov    %rax,%r13
    ce0d:	48 2b 05 7c 7d 01 00 	sub    0x17d7c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ce14:	48 c1 e2 10          	shl    $0x10,%rdx
    ce18:	48 39 d0             	cmp    %rdx,%rax
    ce1b:	73 59                	jae    ce76 <f0+0x14f6>
    ce1d:	48 89 c2             	mov    %rax,%rdx
    ce20:	48 c1 ea 10          	shr    $0x10,%rdx
    ce24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce28:	48 8b 15 a9 7d 01 00 	mov    0x17da9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ce2f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce33:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce37:	4d 85 e4             	test   %r12,%r12
    ce3a:	74 3a                	je     ce76 <f0+0x14f6>
    ce3c:	0f b6 0a             	movzbl (%rdx),%ecx
    ce3f:	80 f9 02             	cmp    $0x2,%cl
    ce42:	0f 84 28 15 00 00    	je     e370 <f0+0x29f0>
    ce48:	80 f9 01             	cmp    $0x1,%cl
    ce4b:	75 29                	jne    ce76 <f0+0x14f6>
    ce4d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce50:	0f b7 c0             	movzwl %ax,%eax
    ce53:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce56:	48 0f af c1          	imul   %rcx,%rax
    ce5a:	48 c1 e8 20          	shr    $0x20,%rax
    ce5e:	48 39 d0             	cmp    %rdx,%rax
    ce61:	73 13                	jae    ce76 <f0+0x14f6>
    ce63:	49 01 c4             	add    %rax,%r12
    ce66:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce6b:	0f 84 75 16 00 00    	je     e4e6 <f0+0x2b66>
    ce71:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce76:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce7d:	33 f3 bf 
    ce80:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    ce87:	00 
    ce88:	bf 01 00 00 00       	mov    $0x1,%edi
    ce8d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    ce94:	00 
    ce95:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    ce9c:	00 
    ce9d:	e8 3e 9b ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cea2:	48 8b 15 0f 7d 01 00 	mov    0x17d0f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cea9:	49 89 c5             	mov    %rax,%r13
    ceac:	48 2b 05 dd 7c 01 00 	sub    0x17cdd(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ceb3:	48 c1 e2 10          	shl    $0x10,%rdx
    ceb7:	48 39 d0             	cmp    %rdx,%rax
    ceba:	73 59                	jae    cf15 <f0+0x1595>
    cebc:	48 89 c2             	mov    %rax,%rdx
    cebf:	48 c1 ea 10          	shr    $0x10,%rdx
    cec3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cec7:	48 8b 15 0a 7d 01 00 	mov    0x17d0a(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cece:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ced2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ced6:	4d 85 e4             	test   %r12,%r12
    ced9:	74 3a                	je     cf15 <f0+0x1595>
    cedb:	0f b6 0a             	movzbl (%rdx),%ecx
    cede:	80 f9 02             	cmp    $0x2,%cl
    cee1:	0f 84 79 14 00 00    	je     e360 <f0+0x29e0>
    cee7:	80 f9 01             	cmp    $0x1,%cl
    ceea:	75 29                	jne    cf15 <f0+0x1595>
    ceec:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ceef:	0f b7 c0             	movzwl %ax,%eax
    cef2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cef5:	48 0f af c1          	imul   %rcx,%rax
    cef9:	48 c1 e8 20          	shr    $0x20,%rax
    cefd:	48 39 d0             	cmp    %rdx,%rax
    cf00:	73 13                	jae    cf15 <f0+0x1595>
    cf02:	49 01 c4             	add    %rax,%r12
    cf05:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf0a:	0f 84 e3 15 00 00    	je     e4f3 <f0+0x2b73>
    cf10:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf15:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cf1c:	00 f0 3f 
    cf1f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cf26:	00 
    cf27:	bf 01 00 00 00       	mov    $0x1,%edi
    cf2c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    cf33:	00 
    cf34:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cf3b:	00 
    cf3c:	e8 9f 9a ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cf41:	48 8b 15 70 7c 01 00 	mov    0x17c70(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cf48:	49 89 c5             	mov    %rax,%r13
    cf4b:	48 2b 05 3e 7c 01 00 	sub    0x17c3e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cf52:	48 c1 e2 10          	shl    $0x10,%rdx
    cf56:	48 39 d0             	cmp    %rdx,%rax
    cf59:	73 59                	jae    cfb4 <f0+0x1634>
    cf5b:	48 89 c2             	mov    %rax,%rdx
    cf5e:	48 c1 ea 10          	shr    $0x10,%rdx
    cf62:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf66:	48 8b 15 6b 7c 01 00 	mov    0x17c6b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    cf6d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf71:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf75:	4d 85 e4             	test   %r12,%r12
    cf78:	74 3a                	je     cfb4 <f0+0x1634>
    cf7a:	0f b6 0a             	movzbl (%rdx),%ecx
    cf7d:	80 f9 02             	cmp    $0x2,%cl
    cf80:	0f 84 ca 13 00 00    	je     e350 <f0+0x29d0>
    cf86:	80 f9 01             	cmp    $0x1,%cl
    cf89:	75 29                	jne    cfb4 <f0+0x1634>
    cf8b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf8e:	0f b7 c0             	movzwl %ax,%eax
    cf91:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf94:	48 0f af c1          	imul   %rcx,%rax
    cf98:	48 c1 e8 20          	shr    $0x20,%rax
    cf9c:	48 39 d0             	cmp    %rdx,%rax
    cf9f:	73 13                	jae    cfb4 <f0+0x1634>
    cfa1:	49 01 c4             	add    %rax,%r12
    cfa4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfa9:	0f 84 51 15 00 00    	je     e500 <f0+0x2b80>
    cfaf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfb4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cfbb:	33 f3 bf 
    cfbe:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cfc5:	00 
    cfc6:	bf 01 00 00 00       	mov    $0x1,%edi
    cfcb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cfd2:	00 
    cfd3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cfda:	00 
    cfdb:	e8 00 9a ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    cfe0:	48 8b 15 d1 7b 01 00 	mov    0x17bd1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    cfe7:	49 89 c5             	mov    %rax,%r13
    cfea:	48 2b 05 9f 7b 01 00 	sub    0x17b9f(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    cff1:	48 c1 e2 10          	shl    $0x10,%rdx
    cff5:	48 39 d0             	cmp    %rdx,%rax
    cff8:	73 59                	jae    d053 <f0+0x16d3>
    cffa:	48 89 c2             	mov    %rax,%rdx
    cffd:	48 c1 ea 10          	shr    $0x10,%rdx
    d001:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d005:	48 8b 15 cc 7b 01 00 	mov    0x17bcc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d00c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d010:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d014:	4d 85 e4             	test   %r12,%r12
    d017:	74 3a                	je     d053 <f0+0x16d3>
    d019:	0f b6 0a             	movzbl (%rdx),%ecx
    d01c:	80 f9 02             	cmp    $0x2,%cl
    d01f:	0f 84 1b 13 00 00    	je     e340 <f0+0x29c0>
    d025:	80 f9 01             	cmp    $0x1,%cl
    d028:	75 29                	jne    d053 <f0+0x16d3>
    d02a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d02d:	0f b7 c0             	movzwl %ax,%eax
    d030:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d033:	48 0f af c1          	imul   %rcx,%rax
    d037:	48 c1 e8 20          	shr    $0x20,%rax
    d03b:	48 39 d0             	cmp    %rdx,%rax
    d03e:	73 13                	jae    d053 <f0+0x16d3>
    d040:	49 01 c4             	add    %rax,%r12
    d043:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d048:	0f 84 bf 14 00 00    	je     e50d <f0+0x2b8d>
    d04e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d053:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d05a:	00 f0 3f 
    d05d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d064:	00 
    d065:	bf 01 00 00 00       	mov    $0x1,%edi
    d06a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d071:	00 
    d072:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d079:	00 
    d07a:	e8 61 99 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d07f:	48 8b 15 32 7b 01 00 	mov    0x17b32(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d086:	49 89 c5             	mov    %rax,%r13
    d089:	48 2b 05 00 7b 01 00 	sub    0x17b00(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d090:	48 c1 e2 10          	shl    $0x10,%rdx
    d094:	48 39 d0             	cmp    %rdx,%rax
    d097:	73 59                	jae    d0f2 <f0+0x1772>
    d099:	48 89 c2             	mov    %rax,%rdx
    d09c:	48 c1 ea 10          	shr    $0x10,%rdx
    d0a0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0a4:	48 8b 15 2d 7b 01 00 	mov    0x17b2d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d0ab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0af:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0b3:	4d 85 e4             	test   %r12,%r12
    d0b6:	74 3a                	je     d0f2 <f0+0x1772>
    d0b8:	0f b6 0a             	movzbl (%rdx),%ecx
    d0bb:	80 f9 02             	cmp    $0x2,%cl
    d0be:	0f 84 6c 12 00 00    	je     e330 <f0+0x29b0>
    d0c4:	80 f9 01             	cmp    $0x1,%cl
    d0c7:	75 29                	jne    d0f2 <f0+0x1772>
    d0c9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0cc:	0f b7 c0             	movzwl %ax,%eax
    d0cf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0d2:	48 0f af c1          	imul   %rcx,%rax
    d0d6:	48 c1 e8 20          	shr    $0x20,%rax
    d0da:	48 39 d0             	cmp    %rdx,%rax
    d0dd:	73 13                	jae    d0f2 <f0+0x1772>
    d0df:	49 01 c4             	add    %rax,%r12
    d0e2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0e7:	0f 84 2d 14 00 00    	je     e51a <f0+0x2b9a>
    d0ed:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0f2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0f9:	33 f3 bf 
    d0fc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d103:	00 
    d104:	bf 01 00 00 00       	mov    $0x1,%edi
    d109:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d110:	00 
    d111:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d118:	00 
    d119:	e8 c2 98 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d11e:	48 8b 15 93 7a 01 00 	mov    0x17a93(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d125:	49 89 c5             	mov    %rax,%r13
    d128:	48 2b 05 61 7a 01 00 	sub    0x17a61(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d12f:	48 c1 e2 10          	shl    $0x10,%rdx
    d133:	48 39 d0             	cmp    %rdx,%rax
    d136:	73 59                	jae    d191 <f0+0x1811>
    d138:	48 89 c2             	mov    %rax,%rdx
    d13b:	48 c1 ea 10          	shr    $0x10,%rdx
    d13f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d143:	48 8b 15 8e 7a 01 00 	mov    0x17a8e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d14a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d14e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d152:	4d 85 e4             	test   %r12,%r12
    d155:	74 3a                	je     d191 <f0+0x1811>
    d157:	0f b6 0a             	movzbl (%rdx),%ecx
    d15a:	80 f9 02             	cmp    $0x2,%cl
    d15d:	0f 84 bd 11 00 00    	je     e320 <f0+0x29a0>
    d163:	80 f9 01             	cmp    $0x1,%cl
    d166:	75 29                	jne    d191 <f0+0x1811>
    d168:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d16b:	0f b7 c0             	movzwl %ax,%eax
    d16e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d171:	48 0f af c1          	imul   %rcx,%rax
    d175:	48 c1 e8 20          	shr    $0x20,%rax
    d179:	48 39 d0             	cmp    %rdx,%rax
    d17c:	73 13                	jae    d191 <f0+0x1811>
    d17e:	49 01 c4             	add    %rax,%r12
    d181:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d186:	0f 84 9b 13 00 00    	je     e527 <f0+0x2ba7>
    d18c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d191:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d198:	00 f0 3f 
    d19b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d1a2:	00 
    d1a3:	bf 01 00 00 00       	mov    $0x1,%edi
    d1a8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d1af:	00 
    d1b0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d1b7:	00 
    d1b8:	e8 23 98 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d1bd:	48 8b 15 f4 79 01 00 	mov    0x179f4(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d1c4:	49 89 c5             	mov    %rax,%r13
    d1c7:	48 2b 05 c2 79 01 00 	sub    0x179c2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d1ce:	48 c1 e2 10          	shl    $0x10,%rdx
    d1d2:	48 39 d0             	cmp    %rdx,%rax
    d1d5:	73 59                	jae    d230 <f0+0x18b0>
    d1d7:	48 89 c2             	mov    %rax,%rdx
    d1da:	48 c1 ea 10          	shr    $0x10,%rdx
    d1de:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1e2:	48 8b 15 ef 79 01 00 	mov    0x179ef(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d1e9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1ed:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1f1:	4d 85 e4             	test   %r12,%r12
    d1f4:	74 3a                	je     d230 <f0+0x18b0>
    d1f6:	0f b6 0a             	movzbl (%rdx),%ecx
    d1f9:	80 f9 02             	cmp    $0x2,%cl
    d1fc:	0f 84 0e 11 00 00    	je     e310 <f0+0x2990>
    d202:	80 f9 01             	cmp    $0x1,%cl
    d205:	75 29                	jne    d230 <f0+0x18b0>
    d207:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d20a:	0f b7 c0             	movzwl %ax,%eax
    d20d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d210:	48 0f af c1          	imul   %rcx,%rax
    d214:	48 c1 e8 20          	shr    $0x20,%rax
    d218:	48 39 d0             	cmp    %rdx,%rax
    d21b:	73 13                	jae    d230 <f0+0x18b0>
    d21d:	49 01 c4             	add    %rax,%r12
    d220:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d225:	0f 84 09 13 00 00    	je     e534 <f0+0x2bb4>
    d22b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d230:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d237:	33 f3 bf 
    d23a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d241:	00 
    d242:	bf 01 00 00 00       	mov    $0x1,%edi
    d247:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d24e:	00 
    d24f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d256:	00 
    d257:	e8 84 97 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d25c:	48 8b 15 55 79 01 00 	mov    0x17955(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d263:	49 89 c5             	mov    %rax,%r13
    d266:	48 2b 05 23 79 01 00 	sub    0x17923(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d26d:	48 c1 e2 10          	shl    $0x10,%rdx
    d271:	48 39 d0             	cmp    %rdx,%rax
    d274:	73 59                	jae    d2cf <f0+0x194f>
    d276:	48 89 c2             	mov    %rax,%rdx
    d279:	48 c1 ea 10          	shr    $0x10,%rdx
    d27d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d281:	48 8b 15 50 79 01 00 	mov    0x17950(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d288:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d28c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d290:	4d 85 e4             	test   %r12,%r12
    d293:	74 3a                	je     d2cf <f0+0x194f>
    d295:	0f b6 0a             	movzbl (%rdx),%ecx
    d298:	80 f9 02             	cmp    $0x2,%cl
    d29b:	0f 84 5f 10 00 00    	je     e300 <f0+0x2980>
    d2a1:	80 f9 01             	cmp    $0x1,%cl
    d2a4:	75 29                	jne    d2cf <f0+0x194f>
    d2a6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2a9:	0f b7 c0             	movzwl %ax,%eax
    d2ac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2af:	48 0f af c1          	imul   %rcx,%rax
    d2b3:	48 c1 e8 20          	shr    $0x20,%rax
    d2b7:	48 39 d0             	cmp    %rdx,%rax
    d2ba:	73 13                	jae    d2cf <f0+0x194f>
    d2bc:	49 01 c4             	add    %rax,%r12
    d2bf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2c4:	0f 84 77 12 00 00    	je     e541 <f0+0x2bc1>
    d2ca:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2cf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2d6:	00 f0 3f 
    d2d9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d2e0:	00 
    d2e1:	bf 01 00 00 00       	mov    $0x1,%edi
    d2e6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d2ed:	00 
    d2ee:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d2f5:	00 
    d2f6:	e8 e5 96 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d2fb:	48 8b 15 b6 78 01 00 	mov    0x178b6(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d302:	49 89 c5             	mov    %rax,%r13
    d305:	48 2b 05 84 78 01 00 	sub    0x17884(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d30c:	48 c1 e2 10          	shl    $0x10,%rdx
    d310:	48 39 d0             	cmp    %rdx,%rax
    d313:	73 59                	jae    d36e <f0+0x19ee>
    d315:	48 89 c2             	mov    %rax,%rdx
    d318:	48 c1 ea 10          	shr    $0x10,%rdx
    d31c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d320:	48 8b 15 b1 78 01 00 	mov    0x178b1(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d327:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d32b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d32f:	4d 85 e4             	test   %r12,%r12
    d332:	74 3a                	je     d36e <f0+0x19ee>
    d334:	0f b6 0a             	movzbl (%rdx),%ecx
    d337:	80 f9 02             	cmp    $0x2,%cl
    d33a:	0f 84 40 0f 00 00    	je     e280 <f0+0x2900>
    d340:	80 f9 01             	cmp    $0x1,%cl
    d343:	75 29                	jne    d36e <f0+0x19ee>
    d345:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d348:	0f b7 c0             	movzwl %ax,%eax
    d34b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d34e:	48 0f af c1          	imul   %rcx,%rax
    d352:	48 c1 e8 20          	shr    $0x20,%rax
    d356:	48 39 d0             	cmp    %rdx,%rax
    d359:	73 13                	jae    d36e <f0+0x19ee>
    d35b:	49 01 c4             	add    %rax,%r12
    d35e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d363:	0f 84 e5 11 00 00    	je     e54e <f0+0x2bce>
    d369:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d36e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d375:	33 f3 bf 
    d378:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    d37f:	00 
    d380:	bf 01 00 00 00       	mov    $0x1,%edi
    d385:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    d38c:	00 
    d38d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    d394:	00 
    d395:	e8 46 96 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d39a:	48 8b 15 17 78 01 00 	mov    0x17817(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d3a1:	49 89 c5             	mov    %rax,%r13
    d3a4:	48 2b 05 e5 77 01 00 	sub    0x177e5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d3ab:	48 c1 e2 10          	shl    $0x10,%rdx
    d3af:	48 39 d0             	cmp    %rdx,%rax
    d3b2:	73 59                	jae    d40d <f0+0x1a8d>
    d3b4:	48 89 c2             	mov    %rax,%rdx
    d3b7:	48 c1 ea 10          	shr    $0x10,%rdx
    d3bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3bf:	48 8b 15 12 78 01 00 	mov    0x17812(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d3c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3ca:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3ce:	4d 85 e4             	test   %r12,%r12
    d3d1:	74 3a                	je     d40d <f0+0x1a8d>
    d3d3:	0f b6 0a             	movzbl (%rdx),%ecx
    d3d6:	80 f9 02             	cmp    $0x2,%cl
    d3d9:	0f 84 91 0e 00 00    	je     e270 <f0+0x28f0>
    d3df:	80 f9 01             	cmp    $0x1,%cl
    d3e2:	75 29                	jne    d40d <f0+0x1a8d>
    d3e4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3e7:	0f b7 c0             	movzwl %ax,%eax
    d3ea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3ed:	48 0f af c1          	imul   %rcx,%rax
    d3f1:	48 c1 e8 20          	shr    $0x20,%rax
    d3f5:	48 39 d0             	cmp    %rdx,%rax
    d3f8:	73 13                	jae    d40d <f0+0x1a8d>
    d3fa:	49 01 c4             	add    %rax,%r12
    d3fd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d402:	0f 84 53 11 00 00    	je     e55b <f0+0x2bdb>
    d408:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d40d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d414:	00 f0 3f 
    d417:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d41e:	00 
    d41f:	bf 01 00 00 00       	mov    $0x1,%edi
    d424:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d42b:	00 
    d42c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d433:	00 
    d434:	e8 a7 95 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d439:	48 8b 15 78 77 01 00 	mov    0x17778(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d440:	49 89 c5             	mov    %rax,%r13
    d443:	48 2b 05 46 77 01 00 	sub    0x17746(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d44a:	48 c1 e2 10          	shl    $0x10,%rdx
    d44e:	48 39 d0             	cmp    %rdx,%rax
    d451:	73 59                	jae    d4ac <f0+0x1b2c>
    d453:	48 89 c2             	mov    %rax,%rdx
    d456:	48 c1 ea 10          	shr    $0x10,%rdx
    d45a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d45e:	48 8b 15 73 77 01 00 	mov    0x17773(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d465:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d469:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d46d:	4d 85 e4             	test   %r12,%r12
    d470:	74 3a                	je     d4ac <f0+0x1b2c>
    d472:	0f b6 0a             	movzbl (%rdx),%ecx
    d475:	80 f9 02             	cmp    $0x2,%cl
    d478:	0f 84 e2 0d 00 00    	je     e260 <f0+0x28e0>
    d47e:	80 f9 01             	cmp    $0x1,%cl
    d481:	75 29                	jne    d4ac <f0+0x1b2c>
    d483:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d486:	0f b7 c0             	movzwl %ax,%eax
    d489:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d48c:	48 0f af c1          	imul   %rcx,%rax
    d490:	48 c1 e8 20          	shr    $0x20,%rax
    d494:	48 39 d0             	cmp    %rdx,%rax
    d497:	73 13                	jae    d4ac <f0+0x1b2c>
    d499:	49 01 c4             	add    %rax,%r12
    d49c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4a1:	0f 84 c1 10 00 00    	je     e568 <f0+0x2be8>
    d4a7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4ac:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d4b3:	33 f3 bf 
    d4b6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d4bd:	00 
    d4be:	bf 01 00 00 00       	mov    $0x1,%edi
    d4c3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d4ca:	00 
    d4cb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d4d2:	00 
    d4d3:	e8 08 95 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d4d8:	48 8b 15 d9 76 01 00 	mov    0x176d9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d4df:	49 89 c5             	mov    %rax,%r13
    d4e2:	48 2b 05 a7 76 01 00 	sub    0x176a7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d4e9:	48 c1 e2 10          	shl    $0x10,%rdx
    d4ed:	48 39 d0             	cmp    %rdx,%rax
    d4f0:	73 59                	jae    d54b <f0+0x1bcb>
    d4f2:	48 89 c2             	mov    %rax,%rdx
    d4f5:	48 c1 ea 10          	shr    $0x10,%rdx
    d4f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4fd:	48 8b 15 d4 76 01 00 	mov    0x176d4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d504:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d508:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d50c:	4d 85 e4             	test   %r12,%r12
    d50f:	74 3a                	je     d54b <f0+0x1bcb>
    d511:	0f b6 0a             	movzbl (%rdx),%ecx
    d514:	80 f9 02             	cmp    $0x2,%cl
    d517:	0f 84 33 0d 00 00    	je     e250 <f0+0x28d0>
    d51d:	80 f9 01             	cmp    $0x1,%cl
    d520:	75 29                	jne    d54b <f0+0x1bcb>
    d522:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d525:	0f b7 c0             	movzwl %ax,%eax
    d528:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d52b:	48 0f af c1          	imul   %rcx,%rax
    d52f:	48 c1 e8 20          	shr    $0x20,%rax
    d533:	48 39 d0             	cmp    %rdx,%rax
    d536:	73 13                	jae    d54b <f0+0x1bcb>
    d538:	49 01 c4             	add    %rax,%r12
    d53b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d540:	0f 84 2f 10 00 00    	je     e575 <f0+0x2bf5>
    d546:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d54b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d552:	00 f0 3f 
    d555:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d55c:	00 
    d55d:	bf 01 00 00 00       	mov    $0x1,%edi
    d562:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d569:	00 
    d56a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d571:	00 
    d572:	e8 69 94 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d577:	48 8b 15 3a 76 01 00 	mov    0x1763a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d57e:	49 89 c5             	mov    %rax,%r13
    d581:	48 2b 05 08 76 01 00 	sub    0x17608(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d588:	48 c1 e2 10          	shl    $0x10,%rdx
    d58c:	48 39 d0             	cmp    %rdx,%rax
    d58f:	73 59                	jae    d5ea <f0+0x1c6a>
    d591:	48 89 c2             	mov    %rax,%rdx
    d594:	48 c1 ea 10          	shr    $0x10,%rdx
    d598:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d59c:	48 8b 15 35 76 01 00 	mov    0x17635(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d5a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5a7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5ab:	4d 85 e4             	test   %r12,%r12
    d5ae:	74 3a                	je     d5ea <f0+0x1c6a>
    d5b0:	0f b6 0a             	movzbl (%rdx),%ecx
    d5b3:	80 f9 02             	cmp    $0x2,%cl
    d5b6:	0f 84 84 0c 00 00    	je     e240 <f0+0x28c0>
    d5bc:	80 f9 01             	cmp    $0x1,%cl
    d5bf:	75 29                	jne    d5ea <f0+0x1c6a>
    d5c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5c4:	0f b7 c0             	movzwl %ax,%eax
    d5c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5ca:	48 0f af c1          	imul   %rcx,%rax
    d5ce:	48 c1 e8 20          	shr    $0x20,%rax
    d5d2:	48 39 d0             	cmp    %rdx,%rax
    d5d5:	73 13                	jae    d5ea <f0+0x1c6a>
    d5d7:	49 01 c4             	add    %rax,%r12
    d5da:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5df:	0f 84 9d 0f 00 00    	je     e582 <f0+0x2c02>
    d5e5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5ea:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5f1:	33 f3 bf 
    d5f4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d5fb:	00 
    d5fc:	bf 01 00 00 00       	mov    $0x1,%edi
    d601:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d608:	00 
    d609:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d610:	00 
    d611:	e8 ca 93 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d616:	48 8b 15 9b 75 01 00 	mov    0x1759b(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d61d:	49 89 c5             	mov    %rax,%r13
    d620:	48 2b 05 69 75 01 00 	sub    0x17569(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d627:	48 c1 e2 10          	shl    $0x10,%rdx
    d62b:	48 39 d0             	cmp    %rdx,%rax
    d62e:	73 59                	jae    d689 <f0+0x1d09>
    d630:	48 89 c2             	mov    %rax,%rdx
    d633:	48 c1 ea 10          	shr    $0x10,%rdx
    d637:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d63b:	48 8b 15 96 75 01 00 	mov    0x17596(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d642:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d646:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d64a:	4d 85 e4             	test   %r12,%r12
    d64d:	74 3a                	je     d689 <f0+0x1d09>
    d64f:	0f b6 0a             	movzbl (%rdx),%ecx
    d652:	80 f9 02             	cmp    $0x2,%cl
    d655:	0f 84 d5 0b 00 00    	je     e230 <f0+0x28b0>
    d65b:	80 f9 01             	cmp    $0x1,%cl
    d65e:	75 29                	jne    d689 <f0+0x1d09>
    d660:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d663:	0f b7 c0             	movzwl %ax,%eax
    d666:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d669:	48 0f af c1          	imul   %rcx,%rax
    d66d:	48 c1 e8 20          	shr    $0x20,%rax
    d671:	48 39 d0             	cmp    %rdx,%rax
    d674:	73 13                	jae    d689 <f0+0x1d09>
    d676:	49 01 c4             	add    %rax,%r12
    d679:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d67e:	0f 84 0b 0f 00 00    	je     e58f <f0+0x2c0f>
    d684:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d689:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d690:	00 f0 3f 
    d693:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d69a:	00 
    d69b:	bf 01 00 00 00       	mov    $0x1,%edi
    d6a0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d6a7:	00 
    d6a8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d6af:	00 
    d6b0:	e8 2b 93 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d6b5:	48 8b 15 fc 74 01 00 	mov    0x174fc(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d6bc:	49 89 c5             	mov    %rax,%r13
    d6bf:	48 2b 05 ca 74 01 00 	sub    0x174ca(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d6c6:	48 c1 e2 10          	shl    $0x10,%rdx
    d6ca:	48 39 d0             	cmp    %rdx,%rax
    d6cd:	73 59                	jae    d728 <f0+0x1da8>
    d6cf:	48 89 c2             	mov    %rax,%rdx
    d6d2:	48 c1 ea 10          	shr    $0x10,%rdx
    d6d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6da:	48 8b 15 f7 74 01 00 	mov    0x174f7(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d6e1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6e5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6e9:	4d 85 e4             	test   %r12,%r12
    d6ec:	74 3a                	je     d728 <f0+0x1da8>
    d6ee:	0f b6 0a             	movzbl (%rdx),%ecx
    d6f1:	80 f9 02             	cmp    $0x2,%cl
    d6f4:	0f 84 26 0b 00 00    	je     e220 <f0+0x28a0>
    d6fa:	80 f9 01             	cmp    $0x1,%cl
    d6fd:	75 29                	jne    d728 <f0+0x1da8>
    d6ff:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d702:	0f b7 c0             	movzwl %ax,%eax
    d705:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d708:	48 0f af c1          	imul   %rcx,%rax
    d70c:	48 c1 e8 20          	shr    $0x20,%rax
    d710:	48 39 d0             	cmp    %rdx,%rax
    d713:	73 13                	jae    d728 <f0+0x1da8>
    d715:	49 01 c4             	add    %rax,%r12
    d718:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d71d:	0f 84 79 0e 00 00    	je     e59c <f0+0x2c1c>
    d723:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d728:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d72f:	33 f3 bf 
    d732:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d739:	00 
    d73a:	bf 01 00 00 00       	mov    $0x1,%edi
    d73f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d746:	00 
    d747:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d74e:	00 
    d74f:	e8 8c 92 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d754:	48 8b 15 5d 74 01 00 	mov    0x1745d(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d75b:	49 89 c5             	mov    %rax,%r13
    d75e:	48 2b 05 2b 74 01 00 	sub    0x1742b(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d765:	48 c1 e2 10          	shl    $0x10,%rdx
    d769:	48 39 d0             	cmp    %rdx,%rax
    d76c:	73 59                	jae    d7c7 <f0+0x1e47>
    d76e:	48 89 c2             	mov    %rax,%rdx
    d771:	48 c1 ea 10          	shr    $0x10,%rdx
    d775:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d779:	48 8b 15 58 74 01 00 	mov    0x17458(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d780:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d784:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d788:	4d 85 e4             	test   %r12,%r12
    d78b:	74 3a                	je     d7c7 <f0+0x1e47>
    d78d:	0f b6 0a             	movzbl (%rdx),%ecx
    d790:	80 f9 02             	cmp    $0x2,%cl
    d793:	0f 84 77 0a 00 00    	je     e210 <f0+0x2890>
    d799:	80 f9 01             	cmp    $0x1,%cl
    d79c:	75 29                	jne    d7c7 <f0+0x1e47>
    d79e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7a1:	0f b7 c0             	movzwl %ax,%eax
    d7a4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7a7:	48 0f af c1          	imul   %rcx,%rax
    d7ab:	48 c1 e8 20          	shr    $0x20,%rax
    d7af:	48 39 d0             	cmp    %rdx,%rax
    d7b2:	73 13                	jae    d7c7 <f0+0x1e47>
    d7b4:	49 01 c4             	add    %rax,%r12
    d7b7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7bc:	0f 84 e7 0d 00 00    	je     e5a9 <f0+0x2c29>
    d7c2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7c7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7ce:	00 f0 3f 
    d7d1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d7d8:	00 
    d7d9:	bf 01 00 00 00       	mov    $0x1,%edi
    d7de:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d7e5:	00 
    d7e6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d7ed:	00 
    d7ee:	e8 ed 91 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d7f3:	48 8b 15 be 73 01 00 	mov    0x173be(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d7fa:	49 89 c5             	mov    %rax,%r13
    d7fd:	48 2b 05 8c 73 01 00 	sub    0x1738c(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d804:	48 c1 e2 10          	shl    $0x10,%rdx
    d808:	48 39 d0             	cmp    %rdx,%rax
    d80b:	73 59                	jae    d866 <f0+0x1ee6>
    d80d:	48 89 c2             	mov    %rax,%rdx
    d810:	48 c1 ea 10          	shr    $0x10,%rdx
    d814:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d818:	48 8b 15 b9 73 01 00 	mov    0x173b9(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d81f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d823:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d827:	4d 85 e4             	test   %r12,%r12
    d82a:	74 3a                	je     d866 <f0+0x1ee6>
    d82c:	0f b6 0a             	movzbl (%rdx),%ecx
    d82f:	80 f9 02             	cmp    $0x2,%cl
    d832:	0f 84 38 0c 00 00    	je     e470 <f0+0x2af0>
    d838:	80 f9 01             	cmp    $0x1,%cl
    d83b:	75 29                	jne    d866 <f0+0x1ee6>
    d83d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d840:	0f b7 c0             	movzwl %ax,%eax
    d843:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d846:	48 0f af c1          	imul   %rcx,%rax
    d84a:	48 c1 e8 20          	shr    $0x20,%rax
    d84e:	48 39 d0             	cmp    %rdx,%rax
    d851:	73 13                	jae    d866 <f0+0x1ee6>
    d853:	49 01 c4             	add    %rax,%r12
    d856:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d85b:	0f 84 55 0d 00 00    	je     e5b6 <f0+0x2c36>
    d861:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d866:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d86d:	33 f3 bf 
    d870:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d877:	00 
    d878:	bf 01 00 00 00       	mov    $0x1,%edi
    d87d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d884:	00 
    d885:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d88c:	00 
    d88d:	e8 4e 91 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d892:	48 8b 15 1f 73 01 00 	mov    0x1731f(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d899:	49 89 c5             	mov    %rax,%r13
    d89c:	48 2b 05 ed 72 01 00 	sub    0x172ed(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d8a3:	48 c1 e2 10          	shl    $0x10,%rdx
    d8a7:	48 39 d0             	cmp    %rdx,%rax
    d8aa:	73 59                	jae    d905 <f0+0x1f85>
    d8ac:	48 89 c2             	mov    %rax,%rdx
    d8af:	48 c1 ea 10          	shr    $0x10,%rdx
    d8b3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8b7:	48 8b 15 1a 73 01 00 	mov    0x1731a(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d8be:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8c2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8c6:	4d 85 e4             	test   %r12,%r12
    d8c9:	74 3a                	je     d905 <f0+0x1f85>
    d8cb:	0f b6 0a             	movzbl (%rdx),%ecx
    d8ce:	80 f9 02             	cmp    $0x2,%cl
    d8d1:	0f 84 89 0b 00 00    	je     e460 <f0+0x2ae0>
    d8d7:	80 f9 01             	cmp    $0x1,%cl
    d8da:	75 29                	jne    d905 <f0+0x1f85>
    d8dc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8df:	0f b7 c0             	movzwl %ax,%eax
    d8e2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8e5:	48 0f af c1          	imul   %rcx,%rax
    d8e9:	48 c1 e8 20          	shr    $0x20,%rax
    d8ed:	48 39 d0             	cmp    %rdx,%rax
    d8f0:	73 13                	jae    d905 <f0+0x1f85>
    d8f2:	49 01 c4             	add    %rax,%r12
    d8f5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8fa:	0f 84 c3 0c 00 00    	je     e5c3 <f0+0x2c43>
    d900:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d905:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d90c:	00 f0 3f 
    d90f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d916:	00 
    d917:	bf 01 00 00 00       	mov    $0x1,%edi
    d91c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d923:	00 
    d924:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d92b:	00 
    d92c:	e8 af 90 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d931:	48 8b 15 80 72 01 00 	mov    0x17280(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d938:	49 89 c5             	mov    %rax,%r13
    d93b:	48 2b 05 4e 72 01 00 	sub    0x1724e(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d942:	48 c1 e2 10          	shl    $0x10,%rdx
    d946:	48 39 d0             	cmp    %rdx,%rax
    d949:	73 59                	jae    d9a4 <f0+0x2024>
    d94b:	48 89 c2             	mov    %rax,%rdx
    d94e:	48 c1 ea 10          	shr    $0x10,%rdx
    d952:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d956:	48 8b 15 7b 72 01 00 	mov    0x1727b(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d95d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d961:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d965:	4d 85 e4             	test   %r12,%r12
    d968:	74 3a                	je     d9a4 <f0+0x2024>
    d96a:	0f b6 0a             	movzbl (%rdx),%ecx
    d96d:	80 f9 02             	cmp    $0x2,%cl
    d970:	0f 84 da 0a 00 00    	je     e450 <f0+0x2ad0>
    d976:	80 f9 01             	cmp    $0x1,%cl
    d979:	75 29                	jne    d9a4 <f0+0x2024>
    d97b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d97e:	0f b7 c0             	movzwl %ax,%eax
    d981:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d984:	48 0f af c1          	imul   %rcx,%rax
    d988:	48 c1 e8 20          	shr    $0x20,%rax
    d98c:	48 39 d0             	cmp    %rdx,%rax
    d98f:	73 13                	jae    d9a4 <f0+0x2024>
    d991:	49 01 c4             	add    %rax,%r12
    d994:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d999:	0f 84 31 0c 00 00    	je     e5d0 <f0+0x2c50>
    d99f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9a4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d9ab:	33 f3 bf 
    d9ae:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d9b5:	00 
    d9b6:	bf 01 00 00 00       	mov    $0x1,%edi
    d9bb:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d9c2:	00 
    d9c3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d9ca:	00 
    d9cb:	e8 10 90 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    d9d0:	48 8b 15 e1 71 01 00 	mov    0x171e1(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    d9d7:	49 89 c5             	mov    %rax,%r13
    d9da:	48 2b 05 af 71 01 00 	sub    0x171af(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    d9e1:	48 c1 e2 10          	shl    $0x10,%rdx
    d9e5:	48 39 d0             	cmp    %rdx,%rax
    d9e8:	73 59                	jae    da43 <f0+0x20c3>
    d9ea:	48 89 c2             	mov    %rax,%rdx
    d9ed:	48 c1 ea 10          	shr    $0x10,%rdx
    d9f1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9f5:	48 8b 15 dc 71 01 00 	mov    0x171dc(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    d9fc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da00:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da04:	4d 85 e4             	test   %r12,%r12
    da07:	74 3a                	je     da43 <f0+0x20c3>
    da09:	0f b6 0a             	movzbl (%rdx),%ecx
    da0c:	80 f9 02             	cmp    $0x2,%cl
    da0f:	0f 84 2b 0a 00 00    	je     e440 <f0+0x2ac0>
    da15:	80 f9 01             	cmp    $0x1,%cl
    da18:	75 29                	jne    da43 <f0+0x20c3>
    da1a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da1d:	0f b7 c0             	movzwl %ax,%eax
    da20:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da23:	48 0f af c1          	imul   %rcx,%rax
    da27:	48 c1 e8 20          	shr    $0x20,%rax
    da2b:	48 39 d0             	cmp    %rdx,%rax
    da2e:	73 13                	jae    da43 <f0+0x20c3>
    da30:	49 01 c4             	add    %rax,%r12
    da33:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da38:	0f 84 9f 0b 00 00    	je     e5dd <f0+0x2c5d>
    da3e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da43:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da4a:	00 f0 3f 
    da4d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    da54:	00 
    da55:	bf 01 00 00 00       	mov    $0x1,%edi
    da5a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    da61:	00 
    da62:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    da69:	00 
    da6a:	e8 71 8f ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    da6f:	48 8b 15 42 71 01 00 	mov    0x17142(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    da76:	49 89 c5             	mov    %rax,%r13
    da79:	48 2b 05 10 71 01 00 	sub    0x17110(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    da80:	48 c1 e2 10          	shl    $0x10,%rdx
    da84:	48 39 d0             	cmp    %rdx,%rax
    da87:	73 59                	jae    dae2 <f0+0x2162>
    da89:	48 89 c2             	mov    %rax,%rdx
    da8c:	48 c1 ea 10          	shr    $0x10,%rdx
    da90:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da94:	48 8b 15 3d 71 01 00 	mov    0x1713d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    da9b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da9f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daa3:	4d 85 e4             	test   %r12,%r12
    daa6:	74 3a                	je     dae2 <f0+0x2162>
    daa8:	0f b6 0a             	movzbl (%rdx),%ecx
    daab:	80 f9 02             	cmp    $0x2,%cl
    daae:	0f 84 7c 09 00 00    	je     e430 <f0+0x2ab0>
    dab4:	80 f9 01             	cmp    $0x1,%cl
    dab7:	75 29                	jne    dae2 <f0+0x2162>
    dab9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dabc:	0f b7 c0             	movzwl %ax,%eax
    dabf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dac2:	48 0f af c1          	imul   %rcx,%rax
    dac6:	48 c1 e8 20          	shr    $0x20,%rax
    daca:	48 39 d0             	cmp    %rdx,%rax
    dacd:	73 13                	jae    dae2 <f0+0x2162>
    dacf:	49 01 c4             	add    %rax,%r12
    dad2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dad7:	0f 84 0d 0b 00 00    	je     e5ea <f0+0x2c6a>
    dadd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dae2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dae9:	33 f3 bf 
    daec:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    daf3:	00 
    daf4:	bf 01 00 00 00       	mov    $0x1,%edi
    daf9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    db00:	00 
    db01:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    db08:	00 
    db09:	e8 d2 8e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    db0e:	48 8b 15 a3 70 01 00 	mov    0x170a3(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    db15:	49 89 c5             	mov    %rax,%r13
    db18:	48 2b 05 71 70 01 00 	sub    0x17071(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    db1f:	48 c1 e2 10          	shl    $0x10,%rdx
    db23:	48 39 d0             	cmp    %rdx,%rax
    db26:	73 59                	jae    db81 <f0+0x2201>
    db28:	48 89 c2             	mov    %rax,%rdx
    db2b:	48 c1 ea 10          	shr    $0x10,%rdx
    db2f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db33:	48 8b 15 9e 70 01 00 	mov    0x1709e(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    db3a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db3e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db42:	4d 85 e4             	test   %r12,%r12
    db45:	74 3a                	je     db81 <f0+0x2201>
    db47:	0f b6 0a             	movzbl (%rdx),%ecx
    db4a:	80 f9 02             	cmp    $0x2,%cl
    db4d:	0f 84 cd 08 00 00    	je     e420 <f0+0x2aa0>
    db53:	80 f9 01             	cmp    $0x1,%cl
    db56:	75 29                	jne    db81 <f0+0x2201>
    db58:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db5b:	0f b7 c0             	movzwl %ax,%eax
    db5e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db61:	48 0f af c1          	imul   %rcx,%rax
    db65:	48 c1 e8 20          	shr    $0x20,%rax
    db69:	48 39 d0             	cmp    %rdx,%rax
    db6c:	73 13                	jae    db81 <f0+0x2201>
    db6e:	49 01 c4             	add    %rax,%r12
    db71:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db76:	0f 84 7b 0a 00 00    	je     e5f7 <f0+0x2c77>
    db7c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db81:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db88:	00 f0 3f 
    db8b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    db92:	00 
    db93:	bf 01 00 00 00       	mov    $0x1,%edi
    db98:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    db9f:	00 
    dba0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    dba7:	00 
    dba8:	e8 33 8e ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    dbad:	48 8b 15 04 70 01 00 	mov    0x17004(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dbb4:	49 89 c5             	mov    %rax,%r13
    dbb7:	48 2b 05 d2 6f 01 00 	sub    0x16fd2(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dbbe:	48 c1 e2 10          	shl    $0x10,%rdx
    dbc2:	48 39 d0             	cmp    %rdx,%rax
    dbc5:	73 59                	jae    dc20 <f0+0x22a0>
    dbc7:	48 89 c2             	mov    %rax,%rdx
    dbca:	48 c1 ea 10          	shr    $0x10,%rdx
    dbce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbd2:	48 8b 15 ff 6f 01 00 	mov    0x16fff(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dbd9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbdd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbe1:	4d 85 e4             	test   %r12,%r12
    dbe4:	74 3a                	je     dc20 <f0+0x22a0>
    dbe6:	0f b6 0a             	movzbl (%rdx),%ecx
    dbe9:	80 f9 02             	cmp    $0x2,%cl
    dbec:	0f 84 1e 08 00 00    	je     e410 <f0+0x2a90>
    dbf2:	80 f9 01             	cmp    $0x1,%cl
    dbf5:	75 29                	jne    dc20 <f0+0x22a0>
    dbf7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbfa:	0f b7 c0             	movzwl %ax,%eax
    dbfd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc00:	48 0f af c1          	imul   %rcx,%rax
    dc04:	48 c1 e8 20          	shr    $0x20,%rax
    dc08:	48 39 d0             	cmp    %rdx,%rax
    dc0b:	73 13                	jae    dc20 <f0+0x22a0>
    dc0d:	49 01 c4             	add    %rax,%r12
    dc10:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc15:	0f 84 e9 09 00 00    	je     e604 <f0+0x2c84>
    dc1b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc20:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc27:	33 f3 bf 
    dc2a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    dc31:	00 
    dc32:	bf 01 00 00 00       	mov    $0x1,%edi
    dc37:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    dc3e:	00 
    dc3f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    dc46:	00 
    dc47:	e8 94 8d ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    dc4c:	48 8b 15 65 6f 01 00 	mov    0x16f65(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dc53:	49 89 c5             	mov    %rax,%r13
    dc56:	48 2b 05 33 6f 01 00 	sub    0x16f33(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dc5d:	48 c1 e2 10          	shl    $0x10,%rdx
    dc61:	48 39 d0             	cmp    %rdx,%rax
    dc64:	73 59                	jae    dcbf <f0+0x233f>
    dc66:	48 89 c2             	mov    %rax,%rdx
    dc69:	48 c1 ea 10          	shr    $0x10,%rdx
    dc6d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc71:	48 8b 15 60 6f 01 00 	mov    0x16f60(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dc78:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc7c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc80:	4d 85 e4             	test   %r12,%r12
    dc83:	74 3a                	je     dcbf <f0+0x233f>
    dc85:	0f b6 0a             	movzbl (%rdx),%ecx
    dc88:	80 f9 02             	cmp    $0x2,%cl
    dc8b:	0f 84 6f 07 00 00    	je     e400 <f0+0x2a80>
    dc91:	80 f9 01             	cmp    $0x1,%cl
    dc94:	75 29                	jne    dcbf <f0+0x233f>
    dc96:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc99:	0f b7 c0             	movzwl %ax,%eax
    dc9c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc9f:	48 0f af c1          	imul   %rcx,%rax
    dca3:	48 c1 e8 20          	shr    $0x20,%rax
    dca7:	48 39 d0             	cmp    %rdx,%rax
    dcaa:	73 13                	jae    dcbf <f0+0x233f>
    dcac:	49 01 c4             	add    %rax,%r12
    dcaf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dcb4:	0f 84 57 09 00 00    	je     e611 <f0+0x2c91>
    dcba:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcbf:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dcc6:	00 f0 3f 
    dcc9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    dcd0:	00 
    dcd1:	bf 01 00 00 00       	mov    $0x1,%edi
    dcd6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    dcdd:	00 
    dcde:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    dce5:	00 
    dce6:	e8 f5 8c ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    dceb:	48 8b 15 c6 6e 01 00 	mov    0x16ec6(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dcf2:	49 89 c5             	mov    %rax,%r13
    dcf5:	48 2b 05 94 6e 01 00 	sub    0x16e94(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dcfc:	48 c1 e2 10          	shl    $0x10,%rdx
    dd00:	48 39 d0             	cmp    %rdx,%rax
    dd03:	73 59                	jae    dd5e <f0+0x23de>
    dd05:	48 89 c2             	mov    %rax,%rdx
    dd08:	48 c1 ea 10          	shr    $0x10,%rdx
    dd0c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd10:	48 8b 15 c1 6e 01 00 	mov    0x16ec1(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    dd17:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd1b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd1f:	4d 85 e4             	test   %r12,%r12
    dd22:	74 3a                	je     dd5e <f0+0x23de>
    dd24:	0f b6 0a             	movzbl (%rdx),%ecx
    dd27:	80 f9 02             	cmp    $0x2,%cl
    dd2a:	0f 84 c0 06 00 00    	je     e3f0 <f0+0x2a70>
    dd30:	80 f9 01             	cmp    $0x1,%cl
    dd33:	75 29                	jne    dd5e <f0+0x23de>
    dd35:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd38:	0f b7 c0             	movzwl %ax,%eax
    dd3b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd3e:	48 0f af c1          	imul   %rcx,%rax
    dd42:	48 c1 e8 20          	shr    $0x20,%rax
    dd46:	48 39 d0             	cmp    %rdx,%rax
    dd49:	73 13                	jae    dd5e <f0+0x23de>
    dd4b:	49 01 c4             	add    %rax,%r12
    dd4e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd53:	0f 84 c5 08 00 00    	je     e61e <f0+0x2c9e>
    dd59:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd5e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd65:	33 f3 bf 
    dd68:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    dd6f:	00 
    dd70:	bf 01 00 00 00       	mov    $0x1,%edi
    dd75:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    dd7c:	00 
    dd7d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    dd84:	00 
    dd85:	e8 56 8c ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    dd8a:	48 8b 15 27 6e 01 00 	mov    0x16e27(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    dd91:	49 89 c5             	mov    %rax,%r13
    dd94:	48 2b 05 f5 6d 01 00 	sub    0x16df5(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    dd9b:	48 c1 e2 10          	shl    $0x10,%rdx
    dd9f:	48 39 d0             	cmp    %rdx,%rax
    dda2:	73 59                	jae    ddfd <f0+0x247d>
    dda4:	48 89 c2             	mov    %rax,%rdx
    dda7:	48 c1 ea 10          	shr    $0x10,%rdx
    ddab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ddaf:	48 8b 15 22 6e 01 00 	mov    0x16e22(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    ddb6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ddba:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ddbe:	4d 85 e4             	test   %r12,%r12
    ddc1:	74 3a                	je     ddfd <f0+0x247d>
    ddc3:	0f b6 0a             	movzbl (%rdx),%ecx
    ddc6:	80 f9 02             	cmp    $0x2,%cl
    ddc9:	0f 84 11 06 00 00    	je     e3e0 <f0+0x2a60>
    ddcf:	80 f9 01             	cmp    $0x1,%cl
    ddd2:	75 29                	jne    ddfd <f0+0x247d>
    ddd4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddd7:	0f b7 c0             	movzwl %ax,%eax
    ddda:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dddd:	48 0f af c1          	imul   %rcx,%rax
    dde1:	48 c1 e8 20          	shr    $0x20,%rax
    dde5:	48 39 d0             	cmp    %rdx,%rax
    dde8:	73 13                	jae    ddfd <f0+0x247d>
    ddea:	49 01 c4             	add    %rax,%r12
    dded:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddf2:	0f 84 33 08 00 00    	je     e62b <f0+0x2cab>
    ddf8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ddfd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    de04:	00 f0 3f 
    de07:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    de0e:	00 
    de0f:	bf 01 00 00 00       	mov    $0x1,%edi
    de14:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    de1b:	00 
    de1c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    de23:	00 
    de24:	e8 b7 8b ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    de29:	48 8b 15 88 6d 01 00 	mov    0x16d88(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    de30:	49 89 c5             	mov    %rax,%r13
    de33:	48 2b 05 56 6d 01 00 	sub    0x16d56(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    de3a:	48 c1 e2 10          	shl    $0x10,%rdx
    de3e:	48 39 d0             	cmp    %rdx,%rax
    de41:	73 59                	jae    de9c <f0+0x251c>
    de43:	48 89 c2             	mov    %rax,%rdx
    de46:	48 c1 ea 10          	shr    $0x10,%rdx
    de4a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de4e:	48 8b 15 83 6d 01 00 	mov    0x16d83(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    de55:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de59:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de5d:	4d 85 e4             	test   %r12,%r12
    de60:	74 3a                	je     de9c <f0+0x251c>
    de62:	0f b6 0a             	movzbl (%rdx),%ecx
    de65:	80 f9 02             	cmp    $0x2,%cl
    de68:	0f 84 62 05 00 00    	je     e3d0 <f0+0x2a50>
    de6e:	80 f9 01             	cmp    $0x1,%cl
    de71:	75 29                	jne    de9c <f0+0x251c>
    de73:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de76:	0f b7 c0             	movzwl %ax,%eax
    de79:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de7c:	48 0f af c1          	imul   %rcx,%rax
    de80:	48 c1 e8 20          	shr    $0x20,%rax
    de84:	48 39 d0             	cmp    %rdx,%rax
    de87:	73 13                	jae    de9c <f0+0x251c>
    de89:	49 01 c4             	add    %rax,%r12
    de8c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de91:	0f 84 a1 07 00 00    	je     e638 <f0+0x2cb8>
    de97:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de9c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dea3:	33 f3 bf 
    dea6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    dead:	00 
    deae:	bf 01 00 00 00       	mov    $0x1,%edi
    deb3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    deba:	00 
    debb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    dec2:	00 
    dec3:	e8 18 8b ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    dec8:	48 8b 15 e9 6c 01 00 	mov    0x16ce9(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    decf:	49 89 c5             	mov    %rax,%r13
    ded2:	48 2b 05 b7 6c 01 00 	sub    0x16cb7(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    ded9:	48 c1 e2 10          	shl    $0x10,%rdx
    dedd:	48 39 d0             	cmp    %rdx,%rax
    dee0:	73 59                	jae    df3b <f0+0x25bb>
    dee2:	48 89 c2             	mov    %rax,%rdx
    dee5:	48 c1 ea 10          	shr    $0x10,%rdx
    dee9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    deed:	48 8b 15 e4 6c 01 00 	mov    0x16ce4(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    def4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    def8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    defc:	4d 85 e4             	test   %r12,%r12
    deff:	74 3a                	je     df3b <f0+0x25bb>
    df01:	0f b6 0a             	movzbl (%rdx),%ecx
    df04:	80 f9 02             	cmp    $0x2,%cl
    df07:	0f 84 b3 04 00 00    	je     e3c0 <f0+0x2a40>
    df0d:	80 f9 01             	cmp    $0x1,%cl
    df10:	75 29                	jne    df3b <f0+0x25bb>
    df12:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df15:	0f b7 c0             	movzwl %ax,%eax
    df18:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df1b:	48 0f af c1          	imul   %rcx,%rax
    df1f:	48 c1 e8 20          	shr    $0x20,%rax
    df23:	48 39 d0             	cmp    %rdx,%rax
    df26:	73 13                	jae    df3b <f0+0x25bb>
    df28:	49 01 c4             	add    %rax,%r12
    df2b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df30:	0f 84 0f 07 00 00    	je     e645 <f0+0x2cc5>
    df36:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df3b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    df42:	00 f0 3f 
    df45:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    df4c:	00 
    df4d:	bf 01 00 00 00       	mov    $0x1,%edi
    df52:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    df59:	00 
    df5a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    df61:	00 
    df62:	e8 79 8a ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    df67:	48 8b 15 4a 6c 01 00 	mov    0x16c4a(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    df6e:	49 89 c5             	mov    %rax,%r13
    df71:	48 2b 05 18 6c 01 00 	sub    0x16c18(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    df78:	48 c1 e2 10          	shl    $0x10,%rdx
    df7c:	48 39 d0             	cmp    %rdx,%rax
    df7f:	73 59                	jae    dfda <f0+0x265a>
    df81:	48 89 c2             	mov    %rax,%rdx
    df84:	48 c1 ea 10          	shr    $0x10,%rdx
    df88:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df8c:	48 8b 15 45 6c 01 00 	mov    0x16c45(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    df93:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df97:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df9b:	4d 85 e4             	test   %r12,%r12
    df9e:	74 3a                	je     dfda <f0+0x265a>
    dfa0:	0f b6 0a             	movzbl (%rdx),%ecx
    dfa3:	80 f9 02             	cmp    $0x2,%cl
    dfa6:	0f 84 04 04 00 00    	je     e3b0 <f0+0x2a30>
    dfac:	80 f9 01             	cmp    $0x1,%cl
    dfaf:	75 29                	jne    dfda <f0+0x265a>
    dfb1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dfb4:	0f b7 c0             	movzwl %ax,%eax
    dfb7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dfba:	48 0f af c1          	imul   %rcx,%rax
    dfbe:	48 c1 e8 20          	shr    $0x20,%rax
    dfc2:	48 39 d0             	cmp    %rdx,%rax
    dfc5:	73 13                	jae    dfda <f0+0x265a>
    dfc7:	49 01 c4             	add    %rax,%r12
    dfca:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfcf:	0f 84 7d 06 00 00    	je     e652 <f0+0x2cd2>
    dfd5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfda:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dfe1:	33 f3 bf 
    dfe4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dfeb:	00 
    dfec:	bf 01 00 00 00       	mov    $0x1,%edi
    dff1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dff8:	00 
    dff9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e000:	00 
    e001:	e8 da 89 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    e006:	48 8b 15 ab 6b 01 00 	mov    0x16bab(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    e00d:	49 89 c5             	mov    %rax,%r13
    e010:	48 2b 05 79 6b 01 00 	sub    0x16b79(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    e017:	48 c1 e2 10          	shl    $0x10,%rdx
    e01b:	48 39 d0             	cmp    %rdx,%rax
    e01e:	73 59                	jae    e079 <f0+0x26f9>
    e020:	48 89 c2             	mov    %rax,%rdx
    e023:	48 c1 ea 10          	shr    $0x10,%rdx
    e027:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e02b:	48 8b 15 a6 6b 01 00 	mov    0x16ba6(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    e032:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e036:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e03a:	4d 85 e4             	test   %r12,%r12
    e03d:	74 3a                	je     e079 <f0+0x26f9>
    e03f:	0f b6 0a             	movzbl (%rdx),%ecx
    e042:	80 f9 02             	cmp    $0x2,%cl
    e045:	0f 84 55 03 00 00    	je     e3a0 <f0+0x2a20>
    e04b:	80 f9 01             	cmp    $0x1,%cl
    e04e:	75 29                	jne    e079 <f0+0x26f9>
    e050:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e053:	0f b7 c0             	movzwl %ax,%eax
    e056:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e059:	48 0f af c1          	imul   %rcx,%rax
    e05d:	48 c1 e8 20          	shr    $0x20,%rax
    e061:	48 39 d0             	cmp    %rdx,%rax
    e064:	73 13                	jae    e079 <f0+0x26f9>
    e066:	49 01 c4             	add    %rax,%r12
    e069:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e06e:	0f 84 eb 05 00 00    	je     e65f <f0+0x2cdf>
    e074:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e079:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e080:	00 f0 3f 
    e083:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e08a:	00 
    e08b:	bf 01 00 00 00       	mov    $0x1,%edi
    e090:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e097:	00 
    e098:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e09f:	00 
    e0a0:	e8 3b 89 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    e0a5:	48 8b 15 0c 6b 01 00 	mov    0x16b0c(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    e0ac:	49 89 c5             	mov    %rax,%r13
    e0af:	48 2b 05 da 6a 01 00 	sub    0x16ada(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    e0b6:	48 c1 e2 10          	shl    $0x10,%rdx
    e0ba:	48 39 d0             	cmp    %rdx,%rax
    e0bd:	73 59                	jae    e118 <f0+0x2798>
    e0bf:	48 89 c2             	mov    %rax,%rdx
    e0c2:	48 c1 ea 10          	shr    $0x10,%rdx
    e0c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0ca:	48 8b 15 07 6b 01 00 	mov    0x16b07(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    e0d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0d5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0d9:	4d 85 e4             	test   %r12,%r12
    e0dc:	74 3a                	je     e118 <f0+0x2798>
    e0de:	0f b6 0a             	movzbl (%rdx),%ecx
    e0e1:	80 f9 02             	cmp    $0x2,%cl
    e0e4:	0f 84 a6 02 00 00    	je     e390 <f0+0x2a10>
    e0ea:	80 f9 01             	cmp    $0x1,%cl
    e0ed:	75 29                	jne    e118 <f0+0x2798>
    e0ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0f2:	0f b7 c0             	movzwl %ax,%eax
    e0f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0f8:	48 0f af c1          	imul   %rcx,%rax
    e0fc:	48 c1 e8 20          	shr    $0x20,%rax
    e100:	48 39 d0             	cmp    %rdx,%rax
    e103:	73 13                	jae    e118 <f0+0x2798>
    e105:	49 01 c4             	add    %rax,%r12
    e108:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e10d:	0f 84 59 05 00 00    	je     e66c <f0+0x2cec>
    e113:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e118:	48 89 ee             	mov    %rbp,%rsi
    e11b:	bf 01 00 00 00       	mov    $0x1,%edi
    e120:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e127:	33 f3 bf 
    e12a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e131:	00 
    e132:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e139:	00 
    e13a:	e8 a1 88 ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    e13f:	48 8b 15 72 6a 01 00 	mov    0x16a72(%rip),%rdx        # 24bb8 <fwp_heap+0x13d8>
    e146:	48 89 c5             	mov    %rax,%rbp
    e149:	48 2b 05 40 6a 01 00 	sub    0x16a40(%rip),%rax        # 24b90 <fwp_heap+0x13b0>
    e150:	48 c1 e2 10          	shl    $0x10,%rdx
    e154:	48 39 d0             	cmp    %rdx,%rax
    e157:	73 59                	jae    e1b2 <f0+0x2832>
    e159:	48 89 c2             	mov    %rax,%rdx
    e15c:	48 c1 ea 10          	shr    $0x10,%rdx
    e160:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e164:	48 8b 15 6d 6a 01 00 	mov    0x16a6d(%rip),%rdx        # 24bd8 <fwp_heap+0x13f8>
    e16b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e16f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e173:	4d 85 e4             	test   %r12,%r12
    e176:	74 3a                	je     e1b2 <f0+0x2832>
    e178:	0f b6 0a             	movzbl (%rdx),%ecx
    e17b:	80 f9 02             	cmp    $0x2,%cl
    e17e:	0f 84 fc 01 00 00    	je     e380 <f0+0x2a00>
    e184:	80 f9 01             	cmp    $0x1,%cl
    e187:	75 29                	jne    e1b2 <f0+0x2832>
    e189:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e18c:	0f b7 c0             	movzwl %ax,%eax
    e18f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e192:	48 0f af c1          	imul   %rcx,%rax
    e196:	48 c1 e8 20          	shr    $0x20,%rax
    e19a:	48 39 d0             	cmp    %rdx,%rax
    e19d:	73 13                	jae    e1b2 <f0+0x2832>
    e19f:	49 01 c4             	add    %rax,%r12
    e1a2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e1a7:	0f 84 d1 02 00 00    	je     e47e <f0+0x2afe>
    e1ad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e1b2:	48 89 de             	mov    %rbx,%rsi
    e1b5:	48 89 ef             	mov    %rbp,%rdi
    e1b8:	e8 63 cb ff ff       	call   ad20 <fwp_hof0.constprop.0>
    e1bd:	48 89 ef             	mov    %rbp,%rdi
    e1c0:	e8 8b 8d ff ff       	call   6f50 <fwp_drop0>
    e1c5:	48 89 df             	mov    %rbx,%rdi
    e1c8:	e8 83 8d ff ff       	call   6f50 <fwp_drop0>
    e1cd:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e1d4:	00 
    e1d5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e1dc:	00 00 
    e1de:	0f 85 95 04 00 00    	jne    e679 <f0+0x2cf9>
    e1e4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e1eb:	31 c0                	xor    %eax,%eax
    e1ed:	5b                   	pop    %rbx
    e1ee:	5d                   	pop    %rbp
    e1ef:	41 5c                	pop    %r12
    e1f1:	41 5d                	pop    %r13
    e1f3:	41 5e                	pop    %r14
    e1f5:	c3                   	ret
    e1f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1fd:	00 00 00 
    e200:	4c 89 ef             	mov    %r13,%rdi
    e203:	e8 48 73 ff ff       	call   5550 <fwp_rc_forget_slot>
    e208:	e9 2c d8 ff ff       	jmp    ba39 <f0+0xb9>
    e20d:	0f 1f 00             	nopl   (%rax)
    e210:	66 85 c0             	test   %ax,%ax
    e213:	0f 85 ae f5 ff ff    	jne    d7c7 <f0+0x1e47>
    e219:	e9 99 f5 ff ff       	jmp    d7b7 <f0+0x1e37>
    e21e:	66 90                	xchg   %ax,%ax
    e220:	66 85 c0             	test   %ax,%ax
    e223:	0f 85 ff f4 ff ff    	jne    d728 <f0+0x1da8>
    e229:	e9 ea f4 ff ff       	jmp    d718 <f0+0x1d98>
    e22e:	66 90                	xchg   %ax,%ax
    e230:	66 85 c0             	test   %ax,%ax
    e233:	0f 85 50 f4 ff ff    	jne    d689 <f0+0x1d09>
    e239:	e9 3b f4 ff ff       	jmp    d679 <f0+0x1cf9>
    e23e:	66 90                	xchg   %ax,%ax
    e240:	66 85 c0             	test   %ax,%ax
    e243:	0f 85 a1 f3 ff ff    	jne    d5ea <f0+0x1c6a>
    e249:	e9 8c f3 ff ff       	jmp    d5da <f0+0x1c5a>
    e24e:	66 90                	xchg   %ax,%ax
    e250:	66 85 c0             	test   %ax,%ax
    e253:	0f 85 f2 f2 ff ff    	jne    d54b <f0+0x1bcb>
    e259:	e9 dd f2 ff ff       	jmp    d53b <f0+0x1bbb>
    e25e:	66 90                	xchg   %ax,%ax
    e260:	66 85 c0             	test   %ax,%ax
    e263:	0f 85 43 f2 ff ff    	jne    d4ac <f0+0x1b2c>
    e269:	e9 2e f2 ff ff       	jmp    d49c <f0+0x1b1c>
    e26e:	66 90                	xchg   %ax,%ax
    e270:	66 85 c0             	test   %ax,%ax
    e273:	0f 85 94 f1 ff ff    	jne    d40d <f0+0x1a8d>
    e279:	e9 7f f1 ff ff       	jmp    d3fd <f0+0x1a7d>
    e27e:	66 90                	xchg   %ax,%ax
    e280:	66 85 c0             	test   %ax,%ax
    e283:	0f 85 e5 f0 ff ff    	jne    d36e <f0+0x19ee>
    e289:	e9 d0 f0 ff ff       	jmp    d35e <f0+0x19de>
    e28e:	66 90                	xchg   %ax,%ax
    e290:	66 85 c0             	test   %ax,%ax
    e293:	0f 85 fd d9 ff ff    	jne    bc96 <f0+0x316>
    e299:	e9 e8 d9 ff ff       	jmp    bc86 <f0+0x306>
    e29e:	66 90                	xchg   %ax,%ax
    e2a0:	66 85 c0             	test   %ax,%ax
    e2a3:	0f 85 57 d9 ff ff    	jne    bc00 <f0+0x280>
    e2a9:	e9 42 d9 ff ff       	jmp    bbf0 <f0+0x270>
    e2ae:	66 90                	xchg   %ax,%ax
    e2b0:	66 85 c0             	test   %ax,%ax
    e2b3:	0f 85 b1 d8 ff ff    	jne    bb6a <f0+0x1ea>
    e2b9:	e9 9c d8 ff ff       	jmp    bb5a <f0+0x1da>
    e2be:	66 90                	xchg   %ax,%ax
    e2c0:	66 85 c0             	test   %ax,%ax
    e2c3:	0f 85 0e eb ff ff    	jne    cdd7 <f0+0x1457>
    e2c9:	e9 f9 ea ff ff       	jmp    cdc7 <f0+0x1447>
    e2ce:	66 90                	xchg   %ax,%ax
    e2d0:	66 85 c0             	test   %ax,%ax
    e2d3:	0f 85 5f ea ff ff    	jne    cd38 <f0+0x13b8>
    e2d9:	e9 4a ea ff ff       	jmp    cd28 <f0+0x13a8>
    e2de:	66 90                	xchg   %ax,%ax
    e2e0:	66 85 c0             	test   %ax,%ax
    e2e3:	0f 85 e2 da ff ff    	jne    bdcb <f0+0x44b>
    e2e9:	e9 cd da ff ff       	jmp    bdbb <f0+0x43b>
    e2ee:	66 90                	xchg   %ax,%ax
    e2f0:	66 85 c0             	test   %ax,%ax
    e2f3:	0f 85 33 da ff ff    	jne    bd2c <f0+0x3ac>
    e2f9:	e9 1e da ff ff       	jmp    bd1c <f0+0x39c>
    e2fe:	66 90                	xchg   %ax,%ax
    e300:	66 85 c0             	test   %ax,%ax
    e303:	0f 85 c6 ef ff ff    	jne    d2cf <f0+0x194f>
    e309:	e9 b1 ef ff ff       	jmp    d2bf <f0+0x193f>
    e30e:	66 90                	xchg   %ax,%ax
    e310:	66 85 c0             	test   %ax,%ax
    e313:	0f 85 17 ef ff ff    	jne    d230 <f0+0x18b0>
    e319:	e9 02 ef ff ff       	jmp    d220 <f0+0x18a0>
    e31e:	66 90                	xchg   %ax,%ax
    e320:	66 85 c0             	test   %ax,%ax
    e323:	0f 85 68 ee ff ff    	jne    d191 <f0+0x1811>
    e329:	e9 53 ee ff ff       	jmp    d181 <f0+0x1801>
    e32e:	66 90                	xchg   %ax,%ax
    e330:	66 85 c0             	test   %ax,%ax
    e333:	0f 85 b9 ed ff ff    	jne    d0f2 <f0+0x1772>
    e339:	e9 a4 ed ff ff       	jmp    d0e2 <f0+0x1762>
    e33e:	66 90                	xchg   %ax,%ax
    e340:	66 85 c0             	test   %ax,%ax
    e343:	0f 85 0a ed ff ff    	jne    d053 <f0+0x16d3>
    e349:	e9 f5 ec ff ff       	jmp    d043 <f0+0x16c3>
    e34e:	66 90                	xchg   %ax,%ax
    e350:	66 85 c0             	test   %ax,%ax
    e353:	0f 85 5b ec ff ff    	jne    cfb4 <f0+0x1634>
    e359:	e9 46 ec ff ff       	jmp    cfa4 <f0+0x1624>
    e35e:	66 90                	xchg   %ax,%ax
    e360:	66 85 c0             	test   %ax,%ax
    e363:	0f 85 ac eb ff ff    	jne    cf15 <f0+0x1595>
    e369:	e9 97 eb ff ff       	jmp    cf05 <f0+0x1585>
    e36e:	66 90                	xchg   %ax,%ax
    e370:	66 85 c0             	test   %ax,%ax
    e373:	0f 85 fd ea ff ff    	jne    ce76 <f0+0x14f6>
    e379:	e9 e8 ea ff ff       	jmp    ce66 <f0+0x14e6>
    e37e:	66 90                	xchg   %ax,%ax
    e380:	66 85 c0             	test   %ax,%ax
    e383:	0f 85 29 fe ff ff    	jne    e1b2 <f0+0x2832>
    e389:	e9 14 fe ff ff       	jmp    e1a2 <f0+0x2822>
    e38e:	66 90                	xchg   %ax,%ax
    e390:	66 85 c0             	test   %ax,%ax
    e393:	0f 85 7f fd ff ff    	jne    e118 <f0+0x2798>
    e399:	e9 6a fd ff ff       	jmp    e108 <f0+0x2788>
    e39e:	66 90                	xchg   %ax,%ax
    e3a0:	66 85 c0             	test   %ax,%ax
    e3a3:	0f 85 d0 fc ff ff    	jne    e079 <f0+0x26f9>
    e3a9:	e9 bb fc ff ff       	jmp    e069 <f0+0x26e9>
    e3ae:	66 90                	xchg   %ax,%ax
    e3b0:	66 85 c0             	test   %ax,%ax
    e3b3:	0f 85 21 fc ff ff    	jne    dfda <f0+0x265a>
    e3b9:	e9 0c fc ff ff       	jmp    dfca <f0+0x264a>
    e3be:	66 90                	xchg   %ax,%ax
    e3c0:	66 85 c0             	test   %ax,%ax
    e3c3:	0f 85 72 fb ff ff    	jne    df3b <f0+0x25bb>
    e3c9:	e9 5d fb ff ff       	jmp    df2b <f0+0x25ab>
    e3ce:	66 90                	xchg   %ax,%ax
    e3d0:	66 85 c0             	test   %ax,%ax
    e3d3:	0f 85 c3 fa ff ff    	jne    de9c <f0+0x251c>
    e3d9:	e9 ae fa ff ff       	jmp    de8c <f0+0x250c>
    e3de:	66 90                	xchg   %ax,%ax
    e3e0:	66 85 c0             	test   %ax,%ax
    e3e3:	0f 85 14 fa ff ff    	jne    ddfd <f0+0x247d>
    e3e9:	e9 ff f9 ff ff       	jmp    dded <f0+0x246d>
    e3ee:	66 90                	xchg   %ax,%ax
    e3f0:	66 85 c0             	test   %ax,%ax
    e3f3:	0f 85 65 f9 ff ff    	jne    dd5e <f0+0x23de>
    e3f9:	e9 50 f9 ff ff       	jmp    dd4e <f0+0x23ce>
    e3fe:	66 90                	xchg   %ax,%ax
    e400:	66 85 c0             	test   %ax,%ax
    e403:	0f 85 b6 f8 ff ff    	jne    dcbf <f0+0x233f>
    e409:	e9 a1 f8 ff ff       	jmp    dcaf <f0+0x232f>
    e40e:	66 90                	xchg   %ax,%ax
    e410:	66 85 c0             	test   %ax,%ax
    e413:	0f 85 07 f8 ff ff    	jne    dc20 <f0+0x22a0>
    e419:	e9 f2 f7 ff ff       	jmp    dc10 <f0+0x2290>
    e41e:	66 90                	xchg   %ax,%ax
    e420:	66 85 c0             	test   %ax,%ax
    e423:	0f 85 58 f7 ff ff    	jne    db81 <f0+0x2201>
    e429:	e9 43 f7 ff ff       	jmp    db71 <f0+0x21f1>
    e42e:	66 90                	xchg   %ax,%ax
    e430:	66 85 c0             	test   %ax,%ax
    e433:	0f 85 a9 f6 ff ff    	jne    dae2 <f0+0x2162>
    e439:	e9 94 f6 ff ff       	jmp    dad2 <f0+0x2152>
    e43e:	66 90                	xchg   %ax,%ax
    e440:	66 85 c0             	test   %ax,%ax
    e443:	0f 85 fa f5 ff ff    	jne    da43 <f0+0x20c3>
    e449:	e9 e5 f5 ff ff       	jmp    da33 <f0+0x20b3>
    e44e:	66 90                	xchg   %ax,%ax
    e450:	66 85 c0             	test   %ax,%ax
    e453:	0f 85 4b f5 ff ff    	jne    d9a4 <f0+0x2024>
    e459:	e9 36 f5 ff ff       	jmp    d994 <f0+0x2014>
    e45e:	66 90                	xchg   %ax,%ax
    e460:	66 85 c0             	test   %ax,%ax
    e463:	0f 85 9c f4 ff ff    	jne    d905 <f0+0x1f85>
    e469:	e9 87 f4 ff ff       	jmp    d8f5 <f0+0x1f75>
    e46e:	66 90                	xchg   %ax,%ax
    e470:	66 85 c0             	test   %ax,%ax
    e473:	0f 85 ed f3 ff ff    	jne    d866 <f0+0x1ee6>
    e479:	e9 d8 f3 ff ff       	jmp    d856 <f0+0x1ed6>
    e47e:	4c 89 e7             	mov    %r12,%rdi
    e481:	e8 ca 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e486:	e9 22 fd ff ff       	jmp    e1ad <f0+0x282d>
    e48b:	4c 89 e7             	mov    %r12,%rdi
    e48e:	e8 bd 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e493:	e9 cd d6 ff ff       	jmp    bb65 <f0+0x1e5>
    e498:	4c 89 e7             	mov    %r12,%rdi
    e49b:	e8 b0 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4a0:	e9 56 d7 ff ff       	jmp    bbfb <f0+0x27b>
    e4a5:	4c 89 e7             	mov    %r12,%rdi
    e4a8:	e8 a3 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4ad:	e9 df d7 ff ff       	jmp    bc91 <f0+0x311>
    e4b2:	4c 89 e7             	mov    %r12,%rdi
    e4b5:	e8 96 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4ba:	e9 68 d8 ff ff       	jmp    bd27 <f0+0x3a7>
    e4bf:	4c 89 e7             	mov    %r12,%rdi
    e4c2:	e8 89 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4c7:	e9 fa d8 ff ff       	jmp    bdc6 <f0+0x446>
    e4cc:	4c 89 e7             	mov    %r12,%rdi
    e4cf:	e8 7c 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4d4:	e9 5a e8 ff ff       	jmp    cd33 <f0+0x13b3>
    e4d9:	4c 89 e7             	mov    %r12,%rdi
    e4dc:	e8 6f 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4e1:	e9 ec e8 ff ff       	jmp    cdd2 <f0+0x1452>
    e4e6:	4c 89 e7             	mov    %r12,%rdi
    e4e9:	e8 62 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4ee:	e9 7e e9 ff ff       	jmp    ce71 <f0+0x14f1>
    e4f3:	4c 89 e7             	mov    %r12,%rdi
    e4f6:	e8 55 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e4fb:	e9 10 ea ff ff       	jmp    cf10 <f0+0x1590>
    e500:	4c 89 e7             	mov    %r12,%rdi
    e503:	e8 48 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e508:	e9 a2 ea ff ff       	jmp    cfaf <f0+0x162f>
    e50d:	4c 89 e7             	mov    %r12,%rdi
    e510:	e8 3b 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e515:	e9 34 eb ff ff       	jmp    d04e <f0+0x16ce>
    e51a:	4c 89 e7             	mov    %r12,%rdi
    e51d:	e8 2e 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e522:	e9 c6 eb ff ff       	jmp    d0ed <f0+0x176d>
    e527:	4c 89 e7             	mov    %r12,%rdi
    e52a:	e8 21 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e52f:	e9 58 ec ff ff       	jmp    d18c <f0+0x180c>
    e534:	4c 89 e7             	mov    %r12,%rdi
    e537:	e8 14 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e53c:	e9 ea ec ff ff       	jmp    d22b <f0+0x18ab>
    e541:	4c 89 e7             	mov    %r12,%rdi
    e544:	e8 07 70 ff ff       	call   5550 <fwp_rc_forget_slot>
    e549:	e9 7c ed ff ff       	jmp    d2ca <f0+0x194a>
    e54e:	4c 89 e7             	mov    %r12,%rdi
    e551:	e8 fa 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e556:	e9 0e ee ff ff       	jmp    d369 <f0+0x19e9>
    e55b:	4c 89 e7             	mov    %r12,%rdi
    e55e:	e8 ed 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e563:	e9 a0 ee ff ff       	jmp    d408 <f0+0x1a88>
    e568:	4c 89 e7             	mov    %r12,%rdi
    e56b:	e8 e0 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e570:	e9 32 ef ff ff       	jmp    d4a7 <f0+0x1b27>
    e575:	4c 89 e7             	mov    %r12,%rdi
    e578:	e8 d3 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e57d:	e9 c4 ef ff ff       	jmp    d546 <f0+0x1bc6>
    e582:	4c 89 e7             	mov    %r12,%rdi
    e585:	e8 c6 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e58a:	e9 56 f0 ff ff       	jmp    d5e5 <f0+0x1c65>
    e58f:	4c 89 e7             	mov    %r12,%rdi
    e592:	e8 b9 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e597:	e9 e8 f0 ff ff       	jmp    d684 <f0+0x1d04>
    e59c:	4c 89 e7             	mov    %r12,%rdi
    e59f:	e8 ac 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5a4:	e9 7a f1 ff ff       	jmp    d723 <f0+0x1da3>
    e5a9:	4c 89 e7             	mov    %r12,%rdi
    e5ac:	e8 9f 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5b1:	e9 0c f2 ff ff       	jmp    d7c2 <f0+0x1e42>
    e5b6:	4c 89 e7             	mov    %r12,%rdi
    e5b9:	e8 92 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5be:	e9 9e f2 ff ff       	jmp    d861 <f0+0x1ee1>
    e5c3:	4c 89 e7             	mov    %r12,%rdi
    e5c6:	e8 85 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5cb:	e9 30 f3 ff ff       	jmp    d900 <f0+0x1f80>
    e5d0:	4c 89 e7             	mov    %r12,%rdi
    e5d3:	e8 78 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5d8:	e9 c2 f3 ff ff       	jmp    d99f <f0+0x201f>
    e5dd:	4c 89 e7             	mov    %r12,%rdi
    e5e0:	e8 6b 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5e5:	e9 54 f4 ff ff       	jmp    da3e <f0+0x20be>
    e5ea:	4c 89 e7             	mov    %r12,%rdi
    e5ed:	e8 5e 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5f2:	e9 e6 f4 ff ff       	jmp    dadd <f0+0x215d>
    e5f7:	4c 89 e7             	mov    %r12,%rdi
    e5fa:	e8 51 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e5ff:	e9 78 f5 ff ff       	jmp    db7c <f0+0x21fc>
    e604:	4c 89 e7             	mov    %r12,%rdi
    e607:	e8 44 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e60c:	e9 0a f6 ff ff       	jmp    dc1b <f0+0x229b>
    e611:	4c 89 e7             	mov    %r12,%rdi
    e614:	e8 37 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e619:	e9 9c f6 ff ff       	jmp    dcba <f0+0x233a>
    e61e:	4c 89 e7             	mov    %r12,%rdi
    e621:	e8 2a 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e626:	e9 2e f7 ff ff       	jmp    dd59 <f0+0x23d9>
    e62b:	4c 89 e7             	mov    %r12,%rdi
    e62e:	e8 1d 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e633:	e9 c0 f7 ff ff       	jmp    ddf8 <f0+0x2478>
    e638:	4c 89 e7             	mov    %r12,%rdi
    e63b:	e8 10 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e640:	e9 52 f8 ff ff       	jmp    de97 <f0+0x2517>
    e645:	4c 89 e7             	mov    %r12,%rdi
    e648:	e8 03 6f ff ff       	call   5550 <fwp_rc_forget_slot>
    e64d:	e9 e4 f8 ff ff       	jmp    df36 <f0+0x25b6>
    e652:	4c 89 e7             	mov    %r12,%rdi
    e655:	e8 f6 6e ff ff       	call   5550 <fwp_rc_forget_slot>
    e65a:	e9 76 f9 ff ff       	jmp    dfd5 <f0+0x2655>
    e65f:	4c 89 e7             	mov    %r12,%rdi
    e662:	e8 e9 6e ff ff       	call   5550 <fwp_rc_forget_slot>
    e667:	e9 08 fa ff ff       	jmp    e074 <f0+0x26f4>
    e66c:	4c 89 e7             	mov    %r12,%rdi
    e66f:	e8 dc 6e ff ff       	call   5550 <fwp_rc_forget_slot>
    e674:	e9 9a fa ff ff       	jmp    e113 <f0+0x2793>
    e679:	e8 e2 4d ff ff       	call   3460 <__stack_chk_fail@plt>
    e67e:	66 90                	xchg   %ax,%ax

000000000000e680 <fwp_main_thread>:
    e680:	f3 0f 1e fa          	endbr64
    e684:	41 54                	push   %r12
    e686:	55                   	push   %rbp
    e687:	53                   	push   %rbx
    e688:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e68f:	8b 35 ef 64 01 00    	mov    0x164ef(%rip),%esi        # 24b84 <fwp_heap+0x13a4>
    e695:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e69c:	00 00 
    e69e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e6a5:	00 
    e6a6:	31 c0                	xor    %eax,%eax
    e6a8:	85 f6                	test   %esi,%esi
    e6aa:	0f 84 a8 06 00 00    	je     ed58 <fwp_main_thread+0x6d8>
    e6b0:	8b 0d d2 64 01 00    	mov    0x164d2(%rip),%ecx        # 24b88 <fwp_heap+0x13a8>
    e6b6:	85 c9                	test   %ecx,%ecx
    e6b8:	0f 85 82 06 00 00    	jne    ed40 <fwp_main_thread+0x6c0>
    e6be:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e6c3:	31 f6                	xor    %esi,%esi
    e6c5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e6ca:	48 c7 05 9b 4a 01 00 	movq   $0x40000000,0x14a9b(%rip)        # 23170 <fwp_main_stack_size>
    e6d1:	00 00 00 40 
    e6d5:	48 89 05 9c 4a 01 00 	mov    %rax,0x14a9c(%rip)        # 23178 <fwp_main_stack_top>
    e6dc:	48 8d 05 bd 49 00 00 	lea    0x49bd(%rip),%rax        # 130a0 <alt.5>
    e6e3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e6e8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e6ef:	01 00 
    e6f1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e6f8:	00 
    e6f9:	e8 c2 4f ff ff       	call   36c0 <sigaltstack@plt>
    e6fe:	85 c0                	test   %eax,%eax
    e700:	0f 85 8a 06 00 00    	jne    ed90 <fwp_main_thread+0x710>
    e706:	31 c0                	xor    %eax,%eax
    e708:	b9 12 00 00 00       	mov    $0x12,%ecx
    e70d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e712:	f3 48 ab             	rep stos %rax,(%rdi)
    e715:	48 8d 05 d4 55 ff ff 	lea    -0xaa2c(%rip),%rax        # 3cf0 <fwp_segv>
    e71c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e721:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e728:	04 00 00 08 
    e72c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e731:	e8 4a 4e ff ff       	call   3580 <sigemptyset@plt>
    e736:	85 c0                	test   %eax,%eax
    e738:	0f 85 52 06 00 00    	jne    ed90 <fwp_main_thread+0x710>
    e73e:	31 d2                	xor    %edx,%edx
    e740:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e745:	bf 0b 00 00 00       	mov    $0xb,%edi
    e74a:	e8 b1 4c ff ff       	call   3400 <sigaction@plt>
    e74f:	85 c0                	test   %eax,%eax
    e751:	0f 85 39 06 00 00    	jne    ed90 <fwp_main_thread+0x710>
    e757:	31 d2                	xor    %edx,%edx
    e759:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e75e:	bf 07 00 00 00       	mov    $0x7,%edi
    e763:	e8 98 4c ff ff       	call   3400 <sigaction@plt>
    e768:	85 c0                	test   %eax,%eax
    e76a:	0f 85 20 06 00 00    	jne    ed90 <fwp_main_thread+0x710>
    e770:	8b 15 a2 49 01 00    	mov    0x149a2(%rip),%edx        # 23118 <descent_registered>
    e776:	85 d2                	test   %edx,%edx
    e778:	0f 84 72 05 00 00    	je     ecf0 <fwp_main_thread+0x670>
    e77e:	8b 05 0c 49 00 00    	mov    0x490c(%rip),%eax        # 13090 <st.3>
    e784:	85 c0                	test   %eax,%eax
    e786:	0f 84 90 05 00 00    	je     ed1c <fwp_main_thread+0x69c>
    e78c:	48 8b 2d 2d 50 01 00 	mov    0x1502d(%rip),%rbp        # 237c0 <fwp_cur>
    e793:	48 85 ed             	test   %rbp,%rbp
    e796:	0f 84 74 03 00 00    	je     eb10 <fwp_main_thread+0x490>
    e79c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e7a1:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e7a5:	48 89 eb             	mov    %rbp,%rbx
    e7a8:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e7ad:	0f 84 41 01 00 00    	je     e8f4 <fwp_main_thread+0x274>
    e7b3:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e7b8:	0f 84 82 02 00 00    	je     ea40 <fwp_main_thread+0x3c0>
    e7be:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e7c2:	0f 84 68 02 00 00    	je     ea30 <fwp_main_thread+0x3b0>
    e7c8:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e7cc:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e7d0:	0f 85 ea 02 00 00    	jne    eac0 <fwp_main_thread+0x440>
    e7d6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e7da:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e7e1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e7e5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e7ec:	00 00 00 00 
    e7f0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e7f7:	48 85 d2             	test   %rdx,%rdx
    e7fa:	74 07                	je     e803 <fwp_main_thread+0x183>
    e7fc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e803:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e807:	48 85 c0             	test   %rax,%rax
    e80a:	74 34                	je     e840 <fwp_main_thread+0x1c0>
    e80c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e810:	48 8b 05 81 4f 01 00 	mov    0x14f81(%rip),%rax        # 23798 <fwp_timers>
    e817:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e81b:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e822:	00 00 00 00 
    e826:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e82d:	48 85 c0             	test   %rax,%rax
    e830:	74 07                	je     e839 <fwp_main_thread+0x1b9>
    e832:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e839:	48 89 1d 58 4f 01 00 	mov    %rbx,0x14f58(%rip)        # 23798 <fwp_timers>
    e840:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e844:	e8 47 91 ff ff       	call   7990 <fwp_block>
    e849:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e850:	48 85 c9             	test   %rcx,%rcx
    e853:	74 47                	je     e89c <fwp_main_thread+0x21c>
    e855:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e85c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e863:	48 85 d2             	test   %rdx,%rdx
    e866:	0f 84 94 02 00 00    	je     eb00 <fwp_main_thread+0x480>
    e86c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e873:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e87a:	48 85 c0             	test   %rax,%rax
    e87d:	74 07                	je     e886 <fwp_main_thread+0x206>
    e87f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e886:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e88d:	00 00 00 00 
    e891:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e895:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e89c:	48 8b 0d 1d 4f 01 00 	mov    0x14f1d(%rip),%rcx        # 237c0 <fwp_cur>
    e8a3:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e8a7:	0f 84 03 02 00 00    	je     eab0 <fwp_main_thread+0x430>
    e8ad:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e8b4:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e8bb:	48 85 d2             	test   %rdx,%rdx
    e8be:	0f 84 fc 03 00 00    	je     ecc0 <fwp_main_thread+0x640>
    e8c4:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e8cb:	48 85 c0             	test   %rax,%rax
    e8ce:	74 07                	je     e8d7 <fwp_main_thread+0x257>
    e8d0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e8d7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e8db:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e8df:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e8e6:	48 89 cb             	mov    %rcx,%rbx
    e8e9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e8ee:	0f 85 bf fe ff ff    	jne    e7b3 <fwp_main_thread+0x133>
    e8f4:	48 83 3d 5c 6b 01 00 	cmpq   $0x0,0x16b5c(%rip)        # 25458 <fwp_state_len>
    e8fb:	00 
    e8fc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e900:	0f 84 bc 00 00 00    	je     e9c2 <fwp_main_thread+0x342>
    e906:	48 39 1d ab 4e 01 00 	cmp    %rbx,0x14eab(%rip)        # 237b8 <fwp_root>
    e90d:	c7 05 89 47 01 00 00 	movl   $0x0,0x14789(%rip)        # 230a0 <fwp_exit_code>
    e914:	00 00 00 
    e917:	0f 85 91 04 00 00    	jne    edae <fwp_main_thread+0x72e>
    e91d:	48 85 db             	test   %rbx,%rbx
    e920:	0f 84 10 02 00 00    	je     eb36 <fwp_main_thread+0x4b6>
    e926:	48 8b 15 5b 4e 01 00 	mov    0x14e5b(%rip),%rdx        # 23788 <fwp_tasks_active>
    e92d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e931:	48 85 d2             	test   %rdx,%rdx
    e934:	0f 84 fc 01 00 00    	je     eb36 <fwp_main_thread+0x4b6>
    e93a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e940:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e944:	75 08                	jne    e94e <fwp_main_thread+0x2ce>
    e946:	48 89 d7             	mov    %rdx,%rdi
    e949:	e8 b2 59 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e94e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e955:	48 85 d2             	test   %rdx,%rdx
    e958:	75 e6                	jne    e940 <fwp_main_thread+0x2c0>
    e95a:	eb 31                	jmp    e98d <fwp_main_thread+0x30d>
    e95c:	0f 1f 40 00          	nopl   0x0(%rax)
    e960:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e967:	48 89 1d 32 4e 01 00 	mov    %rbx,0x14e32(%rip)        # 237a0 <fwp_ready_tail>
    e96e:	e8 1d 90 ff ff       	call   7990 <fwp_block>
    e973:	e8 18 8e ff ff       	call   7790 <fwp_free_zombie>
    e978:	48 83 3d 08 4e 01 00 	cmpq   $0x0,0x14e08(%rip)        # 23788 <fwp_tasks_active>
    e97f:	00 
    e980:	0f 84 b0 01 00 00    	je     eb36 <fwp_main_thread+0x4b6>
    e986:	48 8b 1d 2b 4e 01 00 	mov    0x14e2b(%rip),%rbx        # 237b8 <fwp_root>
    e98d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e991:	75 db                	jne    e96e <fwp_main_thread+0x2ee>
    e993:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e997:	75 d5                	jne    e96e <fwp_main_thread+0x2ee>
    e999:	48 8b 05 00 4e 01 00 	mov    0x14e00(%rip),%rax        # 237a0 <fwp_ready_tail>
    e9a0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e9a4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e9ab:	00 00 00 00 
    e9af:	48 85 c0             	test   %rax,%rax
    e9b2:	75 ac                	jne    e960 <fwp_main_thread+0x2e0>
    e9b4:	48 89 1d ed 4d 01 00 	mov    %rbx,0x14ded(%rip)        # 237a8 <fwp_ready_head>
    e9bb:	eb aa                	jmp    e967 <fwp_main_thread+0x2e7>
    e9bd:	0f 1f 00             	nopl   (%rax)
    e9c0:	31 db                	xor    %ebx,%ebx
    e9c2:	48 83 3d 7e 6a 01 00 	cmpq   $0x0,0x16a7e(%rip)        # 25448 <fwp_state_owners>
    e9c9:	00 
    e9ca:	0f 85 36 ff ff ff    	jne    e906 <fwp_main_thread+0x286>
    e9d0:	48 8b 3d 89 6a 01 00 	mov    0x16a89(%rip),%rdi        # 25460 <fwp_state>
    e9d7:	e8 b4 6d ff ff       	call   5790 <fwp_mem_free>
    e9dc:	48 c7 05 79 6a 01 00 	movq   $0x0,0x16a79(%rip)        # 25460 <fwp_state>
    e9e3:	00 00 00 00 
    e9e7:	48 c7 05 5e 6a 01 00 	movq   $0x0,0x16a5e(%rip)        # 25450 <fwp_state_cap>
    e9ee:	00 00 00 00 
    e9f2:	48 85 db             	test   %rbx,%rbx
    e9f5:	0f 84 76 03 00 00    	je     ed71 <fwp_main_thread+0x6f1>
    e9fb:	48 39 1d b6 4d 01 00 	cmp    %rbx,0x14db6(%rip)        # 237b8 <fwp_root>
    ea02:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    ea09:	00 00 00 00 
    ea0d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    ea14:	00 00 00 00 
    ea18:	c7 05 7e 46 01 00 00 	movl   $0x0,0x1467e(%rip)        # 230a0 <fwp_exit_code>
    ea1f:	00 00 00 
    ea22:	0f 84 fe fe ff ff    	je     e926 <fwp_main_thread+0x2a6>
    ea28:	e9 23 4d ff ff       	jmp    3750 <fwp_main_thread.cold>
    ea2d:	0f 1f 00             	nopl   (%rax)
    ea30:	e8 2b 5b ff ff       	call   4560 <fwp_now_ns>
    ea35:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    ea39:	0f 8d 91 02 00 00    	jge    ecd0 <fwp_main_thread+0x650>
    ea3f:	90                   	nop
    ea40:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    ea44:	0f 85 7e fd ff ff    	jne    e7c8 <fwp_main_thread+0x148>
    ea4a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    ea4e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    ea52:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    ea56:	0f 85 7e fd ff ff    	jne    e7da <fwp_main_thread+0x15a>
    ea5c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    ea60:	48 85 c9             	test   %rcx,%rcx
    ea63:	0f 84 71 fd ff ff    	je     e7da <fwp_main_thread+0x15a>
    ea69:	48 85 c0             	test   %rax,%rax
    ea6c:	0f 84 2f 03 00 00    	je     eda1 <fwp_main_thread+0x721>
    ea72:	48 39 c8             	cmp    %rcx,%rax
    ea75:	48 0f 4f c1          	cmovg  %rcx,%rax
    ea79:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    ea80:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    ea84:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ea8b:	00 00 00 00 
    ea8f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    ea96:	48 85 d2             	test   %rdx,%rdx
    ea99:	74 07                	je     eaa2 <fwp_main_thread+0x422>
    ea9b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    eaa2:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eaa6:	e9 61 fd ff ff       	jmp    e80c <fwp_main_thread+0x18c>
    eaab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    eab0:	48 89 cb             	mov    %rcx,%rbx
    eab3:	e9 f0 fc ff ff       	jmp    e7a8 <fwp_main_thread+0x128>
    eab8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    eabf:	00 
    eac0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    eac4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eacb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    ead2:	00 00 00 00 
    ead6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    eadd:	48 85 c0             	test   %rax,%rax
    eae0:	0f 84 82 02 00 00    	je     ed68 <fwp_main_thread+0x6e8>
    eae6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    eaed:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eaf1:	e9 4a fd ff ff       	jmp    e840 <fwp_main_thread+0x1c0>
    eaf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eafd:	00 00 00 
    eb00:	48 89 01             	mov    %rax,(%rcx)
    eb03:	e9 72 fd ff ff       	jmp    e87a <fwp_main_thread+0x1fa>
    eb08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    eb0f:	00 
    eb10:	48 83 3d 40 69 01 00 	cmpq   $0x0,0x16940(%rip)        # 25458 <fwp_state_len>
    eb17:	00 
    eb18:	0f 84 a2 fe ff ff    	je     e9c0 <fwp_main_thread+0x340>
    eb1e:	48 83 3d 92 4c 01 00 	cmpq   $0x0,0x14c92(%rip)        # 237b8 <fwp_root>
    eb25:	00 
    eb26:	c7 05 70 45 01 00 00 	movl   $0x0,0x14570(%rip)        # 230a0 <fwp_exit_code>
    eb2d:	00 00 00 
    eb30:	0f 85 7d 02 00 00    	jne    edb3 <fwp_main_thread+0x733>
    eb36:	e8 55 8c ff ff       	call   7790 <fwp_free_zombie>
    eb3b:	48 83 3d 65 4c 01 00 	cmpq   $0x0,0x14c65(%rip)        # 237a8 <fwp_ready_head>
    eb42:	00 
    eb43:	0f 85 07 4c ff ff    	jne    3750 <fwp_main_thread.cold>
    eb49:	48 83 3d 47 4c 01 00 	cmpq   $0x0,0x14c47(%rip)        # 23798 <fwp_timers>
    eb50:	00 
    eb51:	0f 85 f9 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    eb57:	8b 1d 27 46 01 00    	mov    0x14627(%rip),%ebx        # 23184 <fwp_stack_pool_n>
    eb5d:	85 db                	test   %ebx,%ebx
    eb5f:	74 36                	je     eb97 <fwp_main_thread+0x517>
    eb61:	83 eb 01             	sub    $0x1,%ebx
    eb64:	48 8d 05 35 46 01 00 	lea    0x14635(%rip),%rax        # 231a0 <fwp_stack_pool>
    eb6b:	48 63 d3             	movslq %ebx,%rdx
    eb6e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    eb72:	eb 07                	jmp    eb7b <fwp_main_thread+0x4fb>
    eb74:	0f 1f 40 00          	nopl   0x0(%rax)
    eb78:	83 eb 01             	sub    $0x1,%ebx
    eb7b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    eb7f:	be 00 00 00 10       	mov    $0x10000000,%esi
    eb84:	89 1d fa 45 01 00    	mov    %ebx,0x145fa(%rip)        # 23184 <fwp_stack_pool_n>
    eb8a:	48 83 ed 08          	sub    $0x8,%rbp
    eb8e:	e8 4d 4a ff ff       	call   35e0 <munmap@plt>
    eb93:	85 db                	test   %ebx,%ebx
    eb95:	75 e1                	jne    eb78 <fwp_main_thread+0x4f8>
    eb97:	8b 3d 87 44 00 00    	mov    0x4487(%rip),%edi        # 13024 <fwp_epfd>
    eb9d:	85 ff                	test   %edi,%edi
    eb9f:	78 05                	js     eba6 <fwp_main_thread+0x526>
    eba1:	e8 2a 49 ff ff       	call   34d0 <close@plt>
    eba6:	4c 8b 25 f3 47 01 00 	mov    0x147f3(%rip),%r12        # 233a0 <fwp_nfdws>
    ebad:	48 8b 2d f4 47 01 00 	mov    0x147f4(%rip),%rbp        # 233a8 <fwp_fdws>
    ebb4:	31 db                	xor    %ebx,%ebx
    ebb6:	c7 05 64 44 00 00 ff 	movl   $0xffffffff,0x4464(%rip)        # 13024 <fwp_epfd>
    ebbd:	ff ff ff 
    ebc0:	4d 85 e4             	test   %r12,%r12
    ebc3:	74 38                	je     ebfd <fwp_main_thread+0x57d>
    ebc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ebcc:	00 00 00 00 
    ebd0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    ebd5:	48 85 ff             	test   %rdi,%rdi
    ebd8:	74 1a                	je     ebf4 <fwp_main_thread+0x574>
    ebda:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    ebde:	0f 85 6c 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    ebe4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    ebe9:	0f 85 61 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    ebef:	e8 9c 6b ff ff       	call   5790 <fwp_mem_free>
    ebf4:	48 83 c3 01          	add    $0x1,%rbx
    ebf8:	4c 39 e3             	cmp    %r12,%rbx
    ebfb:	75 d3                	jne    ebd0 <fwp_main_thread+0x550>
    ebfd:	48 89 ef             	mov    %rbp,%rdi
    ec00:	e8 8b 6b ff ff       	call   5790 <fwp_mem_free>
    ec05:	48 8b 15 ac 4b 01 00 	mov    0x14bac(%rip),%rdx        # 237b8 <fwp_root>
    ec0c:	48 c7 05 91 47 01 00 	movq   $0x0,0x14791(%rip)        # 233a8 <fwp_fdws>
    ec13:	00 00 00 00 
    ec17:	48 c7 05 7e 47 01 00 	movq   $0x0,0x1477e(%rip)        # 233a0 <fwp_nfdws>
    ec1e:	00 00 00 00 
    ec22:	48 85 d2             	test   %rdx,%rdx
    ec25:	74 4e                	je     ec75 <fwp_main_thread+0x5f5>
    ec27:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    ec2c:	0f 85 1e 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    ec32:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    ec39:	00 
    ec3a:	0f 85 10 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    ec40:	48 83 3d 10 68 01 00 	cmpq   $0x0,0x16810(%rip)        # 25458 <fwp_state_len>
    ec47:	00 
    ec48:	0f 85 02 4b ff ff    	jne    3750 <fwp_main_thread.cold>
    ec4e:	48 83 3d f2 67 01 00 	cmpq   $0x0,0x167f2(%rip)        # 25448 <fwp_state_owners>
    ec55:	00 
    ec56:	0f 85 f4 4a ff ff    	jne    3750 <fwp_main_thread.cold>
    ec5c:	b9 79 00 00 00       	mov    $0x79,%ecx
    ec61:	31 c0                	xor    %eax,%eax
    ec63:	48 8d 3d 56 47 01 00 	lea    0x14756(%rip),%rdi        # 233c0 <fwp_root_context>
    ec6a:	f3 48 ab             	rep stos %rax,(%rdi)
    ec6d:	48 89 d7             	mov    %rdx,%rdi
    ec70:	e8 1b 6b ff ff       	call   5790 <fwp_mem_free>
    ec75:	48 8b 3d c4 43 00 00 	mov    0x43c4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    ec7c:	48 c7 05 39 4b 01 00 	movq   $0x0,0x14b39(%rip)        # 237c0 <fwp_cur>
    ec83:	00 00 00 00 
    ec87:	48 c7 05 26 4b 01 00 	movq   $0x0,0x14b26(%rip)        # 237b8 <fwp_root>
    ec8e:	00 00 00 00 
    ec92:	e8 29 49 ff ff       	call   35c0 <fflush@plt>
    ec97:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    ec9e:	00 
    ec9f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    eca6:	00 00 
    eca8:	0f 85 fb 00 00 00    	jne    eda9 <fwp_main_thread+0x729>
    ecae:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    ecb5:	31 c0                	xor    %eax,%eax
    ecb7:	5b                   	pop    %rbx
    ecb8:	5d                   	pop    %rbp
    ecb9:	41 5c                	pop    %r12
    ecbb:	c3                   	ret
    ecbc:	0f 1f 40 00          	nopl   0x0(%rax)
    ecc0:	48 89 05 d1 4a 01 00 	mov    %rax,0x14ad1(%rip)        # 23798 <fwp_timers>
    ecc7:	e9 ff fb ff ff       	jmp    e8cb <fwp_main_thread+0x24b>
    eccc:	0f 1f 40 00          	nopl   0x0(%rax)
    ecd0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    ecd4:	0f 85 66 fd ff ff    	jne    ea40 <fwp_main_thread+0x3c0>
    ecda:	48 89 ef             	mov    %rbp,%rdi
    ecdd:	e8 1e 56 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    ece2:	e9 59 fd ff ff       	jmp    ea40 <fwp_main_thread+0x3c0>
    ece7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ecee:	00 00 
    ecf0:	48 8d 3d 19 51 ff ff 	lea    -0xaee7(%rip),%rdi        # 3e10 <descent_phase_report>
    ecf7:	e8 d4 02 00 00       	call   efd0 <atexit>
    ecfc:	85 c0                	test   %eax,%eax
    ecfe:	0f 85 98 00 00 00    	jne    ed9c <fwp_main_thread+0x71c>
    ed04:	c7 05 0a 44 01 00 01 	movl   $0x1,0x1440a(%rip)        # 23118 <descent_registered>
    ed0b:	00 00 00 
    ed0e:	8b 05 7c 43 00 00    	mov    0x437c(%rip),%eax        # 13090 <st.3>
    ed14:	85 c0                	test   %eax,%eax
    ed16:	0f 85 70 fa ff ff    	jne    e78c <fwp_main_thread+0x10c>
    ed1c:	e8 5f cc ff ff       	call   b980 <f0>
    ed21:	48 c7 05 5c 43 00 00 	movq   $0x0,0x435c(%rip)        # 13088 <v.2>
    ed28:	00 00 00 00 
    ed2c:	c7 05 5a 43 00 00 01 	movl   $0x1,0x435a(%rip)        # 13090 <st.3>
    ed33:	00 00 00 
    ed36:	e9 51 fa ff ff       	jmp    e78c <fwp_main_thread+0x10c>
    ed3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ed40:	48 8d 3d 19 5f ff ff 	lea    -0xa0e7(%rip),%rdi        # 4c60 <fwp_heap_report>
    ed47:	e8 84 02 00 00       	call   efd0 <atexit>
    ed4c:	e9 6d f9 ff ff       	jmp    e6be <fwp_main_thread+0x3e>
    ed51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ed58:	e8 13 60 ff ff       	call   4d70 <fwp_heap_init>
    ed5d:	e9 4e f9 ff ff       	jmp    e6b0 <fwp_main_thread+0x30>
    ed62:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ed68:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ed6c:	e9 cf fa ff ff       	jmp    e840 <fwp_main_thread+0x1c0>
    ed71:	48 83 3d 3f 4a 01 00 	cmpq   $0x0,0x14a3f(%rip)        # 237b8 <fwp_root>
    ed78:	00 
    ed79:	c7 05 1d 43 01 00 00 	movl   $0x0,0x1431d(%rip)        # 230a0 <fwp_exit_code>
    ed80:	00 00 00 
    ed83:	0f 84 ad fd ff ff    	je     eb36 <fwp_main_thread+0x4b6>
    ed89:	e9 c2 49 ff ff       	jmp    3750 <fwp_main_thread.cold>
    ed8e:	66 90                	xchg   %ax,%ax
    ed90:	48 8d 3d 49 0c 00 00 	lea    0xc49(%rip),%rdi        # f9e0 <_IO_stdin_used+0x9e0>
    ed97:	e8 54 56 ff ff       	call   43f0 <fwp_trap>
    ed9c:	e8 3f 50 ff ff       	call   3de0 <descent_phase_fail>
    eda1:	48 89 c8             	mov    %rcx,%rax
    eda4:	e9 d0 fc ff ff       	jmp    ea79 <fwp_main_thread+0x3f9>
    eda9:	e8 b2 46 ff ff       	call   3460 <__stack_chk_fail@plt>
    edae:	e9 9d 49 ff ff       	jmp    3750 <fwp_main_thread.cold>
    edb3:	e9 98 49 ff ff       	jmp    3750 <fwp_main_thread.cold>
    edb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    edbf:	00 

000000000000edc0 <__divmodti4>:
    edc0:	f3 0f 1e fa          	endbr64
    edc4:	55                   	push   %rbp
    edc5:	49 89 f1             	mov    %rsi,%r9
    edc8:	49 89 d2             	mov    %rdx,%r10
    edcb:	48 89 fe             	mov    %rdi,%rsi
    edce:	49 89 cb             	mov    %rcx,%r11
    edd1:	48 89 e5             	mov    %rsp,%rbp
    edd4:	41 57                	push   %r15
    edd6:	41 56                	push   %r14
    edd8:	41 55                	push   %r13
    edda:	41 54                	push   %r12
    eddc:	53                   	push   %rbx
    eddd:	4c 89 c3             	mov    %r8,%rbx
    ede0:	45 31 c0             	xor    %r8d,%r8d
    ede3:	4d 85 c9             	test   %r9,%r9
    ede6:	79 12                	jns    edfa <__divmodti4+0x3a>
    ede8:	31 ff                	xor    %edi,%edi
    edea:	48 f7 de             	neg    %rsi
    eded:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    edf4:	4c 19 cf             	sbb    %r9,%rdi
    edf7:	49 89 f9             	mov    %rdi,%r9
    edfa:	4c 89 d8             	mov    %r11,%rax
    edfd:	4d 85 db             	test   %r11,%r11
    ee00:	0f 88 1a 01 00 00    	js     ef20 <__divmodti4+0x160>
    ee06:	4c 89 d9             	mov    %r11,%rcx
    ee09:	49 89 f3             	mov    %rsi,%r11
    ee0c:	75 62                	jne    ee70 <__divmodti4+0xb0>
    ee0e:	4d 89 c4             	mov    %r8,%r12
    ee11:	4d 39 d1             	cmp    %r10,%r9
    ee14:	0f 83 46 01 00 00    	jae    ef60 <__divmodti4+0x1a0>
    ee1a:	4c 89 d8             	mov    %r11,%rax
    ee1d:	4c 89 ca             	mov    %r9,%rdx
    ee20:	49 f7 f2             	div    %r10
    ee23:	49 89 c3             	mov    %rax,%r11
    ee26:	31 c0                	xor    %eax,%eax
    ee28:	48 89 d6             	mov    %rdx,%rsi
    ee2b:	31 ff                	xor    %edi,%edi
    ee2d:	4c 89 d9             	mov    %r11,%rcx
    ee30:	48 89 c2             	mov    %rax,%rdx
    ee33:	48 89 c8             	mov    %rcx,%rax
    ee36:	4d 85 e4             	test   %r12,%r12
    ee39:	74 0a                	je     ee45 <__divmodti4+0x85>
    ee3b:	48 f7 d8             	neg    %rax
    ee3e:	48 83 d2 00          	adc    $0x0,%rdx
    ee42:	48 f7 da             	neg    %rdx
    ee45:	4d 85 c0             	test   %r8,%r8
    ee48:	74 0a                	je     ee54 <__divmodti4+0x94>
    ee4a:	48 f7 de             	neg    %rsi
    ee4d:	48 83 d7 00          	adc    $0x0,%rdi
    ee51:	48 f7 df             	neg    %rdi
    ee54:	48 89 33             	mov    %rsi,(%rbx)
    ee57:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    ee5b:	5b                   	pop    %rbx
    ee5c:	41 5c                	pop    %r12
    ee5e:	41 5d                	pop    %r13
    ee60:	41 5e                	pop    %r14
    ee62:	41 5f                	pop    %r15
    ee64:	5d                   	pop    %rbp
    ee65:	c3                   	ret
    ee66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ee6d:	00 00 00 
    ee70:	4d 89 c4             	mov    %r8,%r12
    ee73:	49 39 c1             	cmp    %rax,%r9
    ee76:	0f 82 ce 00 00 00    	jb     ef4a <__divmodti4+0x18a>
    ee7c:	31 ff                	xor    %edi,%edi
    ee7e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    ee83:	48 63 c7             	movslq %edi,%rax
    ee86:	be 40 00 00 00       	mov    $0x40,%esi
    ee8b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    ee90:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    ee95:	48 29 c6             	sub    %rax,%rsi
    ee98:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    ee9d:	48 09 c8             	or     %rcx,%rax
    eea0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    eea5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    eeaa:	49 89 c6             	mov    %rax,%r14
    eead:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    eeb1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    eeb6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    eebb:	49 09 c1             	or     %rax,%r9
    eebe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    eec2:	4c 89 c8             	mov    %r9,%rax
    eec5:	49 f7 f6             	div    %r14
    eec8:	48 89 d1             	mov    %rdx,%rcx
    eecb:	49 89 c3             	mov    %rax,%r11
    eece:	49 89 c1             	mov    %rax,%r9
    eed1:	49 f7 e2             	mul    %r10
    eed4:	49 89 c6             	mov    %rax,%r14
    eed7:	49 89 d2             	mov    %rdx,%r10
    eeda:	48 39 d1             	cmp    %rdx,%rcx
    eedd:	72 07                	jb     eee6 <__divmodti4+0x126>
    eedf:	75 17                	jne    eef8 <__divmodti4+0x138>
    eee1:	49 39 c7             	cmp    %rax,%r15
    eee4:	73 12                	jae    eef8 <__divmodti4+0x138>
    eee6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    eeea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    eeee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    eef2:	49 89 d2             	mov    %rdx,%r10
    eef5:	49 89 c6             	mov    %rax,%r14
    eef8:	4c 89 f8             	mov    %r15,%rax
    eefb:	4c 29 f0             	sub    %r14,%rax
    eefe:	4c 19 d1             	sbb    %r10,%rcx
    ef01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ef06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ef0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ef10:	48 09 c6             	or     %rax,%rsi
    ef13:	48 89 cf             	mov    %rcx,%rdi
    ef16:	31 c0                	xor    %eax,%eax
    ef18:	4c 89 c9             	mov    %r9,%rcx
    ef1b:	e9 10 ff ff ff       	jmp    ee30 <__divmodti4+0x70>
    ef20:	4c 89 d0             	mov    %r10,%rax
    ef23:	4c 89 da             	mov    %r11,%rdx
    ef26:	4d 89 c4             	mov    %r8,%r12
    ef29:	49 89 f3             	mov    %rsi,%r11
    ef2c:	48 f7 d8             	neg    %rax
    ef2f:	49 f7 d4             	not    %r12
    ef32:	48 83 d2 00          	adc    $0x0,%rdx
    ef36:	49 89 c2             	mov    %rax,%r10
    ef39:	48 f7 da             	neg    %rdx
    ef3c:	48 89 d1             	mov    %rdx,%rcx
    ef3f:	0f 84 cc fe ff ff    	je     ee11 <__divmodti4+0x51>
    ef45:	49 39 d1             	cmp    %rdx,%r9
    ef48:	73 46                	jae    ef90 <__divmodti4+0x1d0>
    ef4a:	4c 89 cf             	mov    %r9,%rdi
    ef4d:	31 c0                	xor    %eax,%eax
    ef4f:	31 c9                	xor    %ecx,%ecx
    ef51:	e9 da fe ff ff       	jmp    ee30 <__divmodti4+0x70>
    ef56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ef5d:	00 00 00 
    ef60:	4d 85 d2             	test   %r10,%r10
    ef63:	75 0d                	jne    ef72 <__divmodti4+0x1b2>
    ef65:	b8 01 00 00 00       	mov    $0x1,%eax
    ef6a:	31 d2                	xor    %edx,%edx
    ef6c:	49 f7 f2             	div    %r10
    ef6f:	49 89 c2             	mov    %rax,%r10
    ef72:	4c 89 c8             	mov    %r9,%rax
    ef75:	31 d2                	xor    %edx,%edx
    ef77:	49 f7 f2             	div    %r10
    ef7a:	49 89 c1             	mov    %rax,%r9
    ef7d:	4c 89 d8             	mov    %r11,%rax
    ef80:	49 f7 f2             	div    %r10
    ef83:	49 89 c3             	mov    %rax,%r11
    ef86:	4c 89 c8             	mov    %r9,%rax
    ef89:	e9 9a fe ff ff       	jmp    ee28 <__divmodti4+0x68>
    ef8e:	66 90                	xchg   %ax,%ax
    ef90:	45 31 f6             	xor    %r14d,%r14d
    ef93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ef98:	44 89 f7             	mov    %r14d,%edi
    ef9b:	45 85 f6             	test   %r14d,%r14d
    ef9e:	0f 85 df fe ff ff    	jne    ee83 <__divmodti4+0xc3>
    efa4:	4c 39 ca             	cmp    %r9,%rdx
    efa7:	72 17                	jb     efc0 <__divmodti4+0x200>
    efa9:	31 c9                	xor    %ecx,%ecx
    efab:	48 39 c6             	cmp    %rax,%rsi
    efae:	73 10                	jae    efc0 <__divmodti4+0x200>
    efb0:	4c 89 cf             	mov    %r9,%rdi
    efb3:	31 c0                	xor    %eax,%eax
    efb5:	e9 76 fe ff ff       	jmp    ee30 <__divmodti4+0x70>
    efba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    efc0:	4c 89 de             	mov    %r11,%rsi
    efc3:	b9 01 00 00 00       	mov    $0x1,%ecx
    efc8:	48 29 c6             	sub    %rax,%rsi
    efcb:	49 19 d1             	sbb    %rdx,%r9
    efce:	eb e0                	jmp    efb0 <__divmodti4+0x1f0>

000000000000efd0 <atexit>:
    efd0:	f3 0f 1e fa          	endbr64
    efd4:	48 8b 15 2d 40 00 00 	mov    0x402d(%rip),%rdx        # 13008 <__dso_handle>
    efdb:	31 f6                	xor    %esi,%esi
    efdd:	e9 7e 46 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000efe4 <_fini>:
    efe4:	f3 0f 1e fa          	endbr64
    efe8:	48 83 ec 08          	sub    $0x8,%rsp
    efec:	48 83 c4 08          	add    $0x8,%rsp
    eff0:	c3                   	ret
