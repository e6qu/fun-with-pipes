
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 0f 01 00 	mov    0x10fd1(%rip),%rax        # 13fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 0d 01 00    	push   0x10df2(%rip)        # 13e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 0d 01 00    	jmp    *0x10df4(%rip)        # 13e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 0c 01 00    	jmp    *0x10c66(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e 0a 01 00    	jmp    *0x10a8e(%rip)        # 13e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 0a 01 00    	jmp    *0x10a86(%rip)        # 13e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e 0a 01 00    	jmp    *0x10a7e(%rip)        # 13e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 0a 01 00    	jmp    *0x10a76(%rip)        # 13e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e 0a 01 00    	jmp    *0x10a6e(%rip)        # 13e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 0a 01 00    	jmp    *0x10a66(%rip)        # 13e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e 0a 01 00    	jmp    *0x10a5e(%rip)        # 13e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 0a 01 00    	jmp    *0x10a56(%rip)        # 13e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e 0a 01 00    	jmp    *0x10a4e(%rip)        # 13e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 0a 01 00    	jmp    *0x10a46(%rip)        # 13e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e 0a 01 00    	jmp    *0x10a3e(%rip)        # 13e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 0a 01 00    	jmp    *0x10a36(%rip)        # 13e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e 0a 01 00    	jmp    *0x10a2e(%rip)        # 13e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 0a 01 00    	jmp    *0x10a26(%rip)        # 13e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e 0a 01 00    	jmp    *0x10a1e(%rip)        # 13e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 0a 01 00    	jmp    *0x10a16(%rip)        # 13ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e 0a 01 00    	jmp    *0x10a0e(%rip)        # 13ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 0a 01 00    	jmp    *0x10a06(%rip)        # 13eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe 09 01 00    	jmp    *0x109fe(%rip)        # 13eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 09 01 00    	jmp    *0x109f6(%rip)        # 13ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee 09 01 00    	jmp    *0x109ee(%rip)        # 13ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 09 01 00    	jmp    *0x109e6(%rip)        # 13ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de 09 01 00    	jmp    *0x109de(%rip)        # 13ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 09 01 00    	jmp    *0x109d6(%rip)        # 13ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce 09 01 00    	jmp    *0x109ce(%rip)        # 13ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 09 01 00    	jmp    *0x109c6(%rip)        # 13ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be 09 01 00    	jmp    *0x109be(%rip)        # 13ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 09 01 00    	jmp    *0x109b6(%rip)        # 13f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae 09 01 00    	jmp    *0x109ae(%rip)        # 13f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 09 01 00    	jmp    *0x109a6(%rip)        # 13f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e 09 01 00    	jmp    *0x1099e(%rip)        # 13f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 09 01 00    	jmp    *0x10996(%rip)        # 13f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e 09 01 00    	jmp    *0x1098e(%rip)        # 13f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 09 01 00    	jmp    *0x10986(%rip)        # 13f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e 09 01 00    	jmp    *0x1097e(%rip)        # 13f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 09 01 00    	jmp    *0x10976(%rip)        # 13f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e 09 01 00    	jmp    *0x1096e(%rip)        # 13f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 09 01 00    	jmp    *0x10966(%rip)        # 13f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e 09 01 00    	jmp    *0x1095e(%rip)        # 13f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 09 01 00    	jmp    *0x10956(%rip)        # 13f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e 09 01 00    	jmp    *0x1094e(%rip)        # 13f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 09 01 00    	jmp    *0x10946(%rip)        # 13f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e 09 01 00    	jmp    *0x1093e(%rip)        # 13f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 09 01 00    	jmp    *0x10936(%rip)        # 13f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e 09 01 00    	jmp    *0x1092e(%rip)        # 13f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 09 01 00    	jmp    *0x10926(%rip)        # 13f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e 09 01 00    	jmp    *0x1091e(%rip)        # 13f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 09 01 00    	jmp    *0x10916(%rip)        # 13fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e 09 01 00    	jmp    *0x1090e(%rip)        # 13fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 09 01 00    	jmp    *0x10906(%rip)        # 13fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe 08 01 00    	jmp    *0x108fe(%rip)        # 13fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 08 01 00    	jmp    *0x108f6(%rip)        # 13fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee 08 01 00    	jmp    *0x108ee(%rip)        # 13fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 c9 00 00 	lea    0xc9b8(%rip),%r9        # 100cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 c9 00 00 	lea    0xc9b5(%rip),%r8        # 100d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ed 00 00 	lea    0xed01(%rip),%rax        # 12480 <fwp_fn_table>
    377f:	48 89 05 12 ad 06 00 	mov    %rax,0x6ad12(%rip)        # 6e498 <fwp_fns>
    3786:	48 8b 05 b3 08 01 00 	mov    0x108b3(%rip),%rax        # 14040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 0c ad 06 00 	mov    %rax,0x6ad0c(%rip)        # 6e4a0 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e cb 00 00 	lea    0xcb4e(%rip),%rdi        # 102ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 08 01 00 	mov    0x10838(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 df b4 00 00 	lea    0xb4df(%rip),%rdx        # ed40 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 07 01 00 	mov    0x107a3(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 f8 07 02 00    	mov    0x207f8(%rip),%eax        # 240a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe c9 00 00 	lea    0xc9fe(%rip),%rdi        # 102f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 46 d3 00 00 	lea    0xd346(%rip),%rdi        # 10c50 <_IO_stdin_used+0xc50>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 00 d3 00 00 	lea    0xd300(%rip),%rdi        # 10c28 <_IO_stdin_used+0xc28>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d c4 d2 00 00 	lea    0xd2c4(%rip),%rdi        # 10bf8 <_IO_stdin_used+0xbf8>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d 90 d2 00 00 	lea    0xd290(%rip),%rdi        # 10bd0 <_IO_stdin_used+0xbd0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b 06 01 00    	call   *0x1065b(%rip)        # 13fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 06 01 00 	lea    0x106a1(%rip),%rdi        # 14028 <__TMC_END__>
    3987:	48 8d 05 9a 06 01 00 	lea    0x1069a(%rip),%rax        # 14028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e 06 01 00 	mov    0x1063e(%rip),%rax        # 13fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 06 01 00 	lea    0x10671(%rip),%rdi        # 14028 <__TMC_END__>
    39b7:	48 8d 35 6a 06 01 00 	lea    0x1066a(%rip),%rsi        # 14028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d 06 01 00 	mov    0x1060d(%rip),%rax        # 13fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d 06 01 00 00 	cmpb   $0x0,0x1066d(%rip)        # 14068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea 05 01 00 	cmpq   $0x0,0x105ea(%rip)        # 13ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 05 01 00 	mov    0x105f6(%rip),%rdi        # 14008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 06 01 00 01 	movb   $0x1,0x10645(%rip)        # 14068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 b7 05 05 00 	lea    0x505b7(%rip),%r8        # 541c0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 5b 05 05 00 	lea    0x5055b(%rip),%rcx        # 54180 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 2f 05 05 00 	lea    0x5052f(%rip),%rcx        # 54160 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 61 05 05 00 	lea    0x50561(%rip),%rcx        # 541a0 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 70 05 05 	movdqa 0x50570(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 58 05 05 	paddq  0x50558(%rip),%xmm0        # 541c0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 bf 04 05 00 	cmp    %rax,0x504bf(%rip)        # 54140 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 b5 04 05 	movq   %xmm0,0x504b5(%rip)        # 54140 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 5e 04 02 00 	add    0x2045e(%rip),%rdx        # 24110 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 4c 04 02 00 	add    0x2044c(%rip),%rax        # 24110 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args161>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 99 a7 06 00 	mov    0x6a799(%rip),%rdi        # 6e4a0 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 24 03 01 00 	mov    0x10324(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d 11 03 01 00 	mov    0x10311(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 d1 8a 06 00 	mov    0x68ad1(%rip),%rax        # 6c820 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 19 84 06 00 	mov    0x68419(%rip),%rax        # 6c1e8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 05 84 06 00 	sub    0x68405(%rip),%rax        # 6c1e0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 1d cf 00 00 	lea    0xcf1d(%rip),%rsi        # 10d30 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 c1 00 00 	lea    0xc1c5(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d 12 02 01 00 	mov    0x10212(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 ab 9d 06 00 	mov    0x69dab(%rip),%rax        # 6dc30 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 a4 9d 06 00 	lea    0x69da4(%rip),%r8        # 6dc30 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 85 9d 06 00 	mov    0x69d85(%rip),%rbx        # 6dc18 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 95 9d 06 00 	mov    0x69d95(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 31 9d 06 00 	mov    0x69d31(%rip),%rdi        # 6dc20 <fwp_heap+0x13e0>
    3eef:	48 29 35 7a 9d 06 00 	sub    %rsi,0x69d7a(%rip)        # 6dc70 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 0a 9d 06 00 	mov    0x69d0a(%rip),%rax        # 6dc10 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d c0 9c 06 00 	add    0x69cc0(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ce 9c 06 00 	mov    0x69cce(%rip),%rsi        # 6dc20 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 dc 9c 06 00 	mov    0x69cdc(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 8b 9c 06 00 	mov    %r12,0x69c8b(%rip)        # 6dc20 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 79 9c 06 00 	mov    %rbp,0x69c79(%rip)        # 6dc18 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 5e 9c 06 00 	cmp    %rdi,0x69c5e(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 55 9c 06 00 	mov    %rdi,0x69c55(%rip)        # 6dc08 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 99 9c 06 00 	sub    %rdi,0x69c99(%rip)        # 6dc70 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 41 9c 06 00 	mov    0x69c41(%rip),%rax        # 6dc28 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 3a 9c 06 00 	lea    0x69c3a(%rip),%r8        # 6dc28 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ef c6 00 00 	lea    0xc6ef(%rip),%rdx        # 106f8 <_IO_stdin_used+0x6f8>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 42 00 01 00 	mov    0x10042(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 9d ff 00 00 	mov    0xff9d(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 bf 00 00 	lea    0xbf34(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d e9 86 06 00 	cmp    0x686e9(%rip),%rdi        # 6c820 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 af 86 06 00 	mov    0x686af(%rip),%rax        # 6c800 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 8d 86 06 00 	mov    %rdi,0x6868d(%rip)        # 6c800 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 69 86 06 00 	mov    %rdi,0x68669(%rip)        # 6c808 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 5f c0 00 00 	lea    0xc05f(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 be 00 00 	lea    0xbe27(%rip),%rsi        # 1001c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 96 ff 04 	movdqa 0x4ff96(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 7e ff 04 	paddq  0x4ff7e(%rip),%xmm0        # 541c0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 a4 fe 01 00 	mov    0x1fea4(%rip),%r8        # 24118 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d be fe 04 00 	mov    0x4febe(%rip),%rcx        # 54140 <ad_raw_total_peak>
    4282:	48 8b 3d d7 fd 00 00 	mov    0xfdd7(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 b5 c4 00 00 	lea    0xc4b5(%rip),%rdx        # 10748 <_IO_stdin_used+0x748>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d 01 ff 04 00 	lea    0x4ff01(%rip),%r15        # 541a0 <ad_raw_peak>
    429f:	4c 8d 35 ba fe 04 00 	lea    0x4feba(%rip),%r14        # 54160 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 bd 00 00 	lea    0xbd79(%rip),%rax        # 1002b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 f9 00 	movq   0xf956(%rip),%xmm0        # 13c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d bf fe 04 00 	lea    0x4febf(%rip),%r13        # 54180 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f bd 00 00 	lea    0xbd6f(%rip),%rax        # 1003c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 f9 00 	movq   0xf936(%rip),%xmm0        # 13c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 53 fd 00 00 	mov    0xfd53(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c bd 00 00 	lea    0xbd0c(%rip),%rcx        # 10020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 8d c4 00 00 	lea    0xc48d(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 24 fd 00 00 	mov    0xfd24(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 bc 00 00 	lea    0xbcf8(%rip),%rdi        # 10045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d c6 fd 01 00 	cmpq   $0x0,0x1fdc6(%rip)        # 24120 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 dd fd 01 00 	mov    0x1fddd(%rip),%r8        # 24140 <ad_raw_checkpoints>
    4363:	4c 8b 0d de fd 01 00 	mov    0x1fdde(%rip),%r9        # 24148 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d cf fd 01 00 	lea    0x1fdcf(%rip),%rbx        # 24140 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 bc 00 00 	lea    0xbcf4(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 d1 fd 01 00 	mov    0x1fdd1(%rip),%rax        # 24150 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a bc 00 00 	lea    0xbc9a(%rip),%r12        # 10020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d a9 fc 00 00 	mov    0xfca9(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 29 c4 00 00 	lea    0xc429(%rip),%rdx        # 107e8 <_IO_stdin_used+0x7e8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 53 fd 01 00 	cmp    0x1fd53(%rip),%rbp        # 24120 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 78 fc 00 00 	mov    0xfc78(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b bc 00 00 	lea    0xbc5b(%rip),%rdi        # 10059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 43 fc 00 00 	mov    0xfc43(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 84 c3 00 00 	lea    0xc384(%rip),%rdx        # 107a8 <_IO_stdin_used+0x7a8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 bc 00 00 	lea    0xbc40(%rip),%rcx        # 1006c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d da c2 00 00 	lea    0xc2da(%rip),%rdi        # 10720 <_IO_stdin_used+0x720>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d e8 fb 00 00 	mov    0xfbe8(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df bb 00 00 	lea    0xbbdf(%rip),%rdx        # 1005e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d d0 fb 00 00 	mov    0xfbd0(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d e1 fa 00 00 	mov    0xfae1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 ba 00 00 	lea    0xba78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 ba 00 00 	lea    0xbac0(%rip),%rdi        # 1006d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 ba 00 00 	lea    0xba48(%rip),%rdi        # 10087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d d8 c1 00 00 	lea    0xc1d8(%rip),%rdi        # 10828 <_IO_stdin_used+0x828>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 e0 c6 00 	movdqa 0xc6e0(%rip),%xmm0        # 10d50 <msg.4+0x20>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 ca 9d 06 00 	add    0x69dca(%rip),%rax        # 6e498 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 2c c1 00 00 	lea    0xc12c(%rip),%rdi        # 10850 <_IO_stdin_used+0x850>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 c5 f9 01 00 	cmp    %rax,0x1f9c5(%rip)        # 24108 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 c0 f9 01 00 	add    0x1f9c0(%rip),%rax        # 24110 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 15 c1 00 00 	lea    0xc115(%rip),%rdi        # 10880 <_IO_stdin_used+0x880>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 b9 00 00 	lea    0xb920(%rip),%r8        # 100a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 b7 00 00 	lea    0xb775(%rip),%r8        # 100b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 b6 00 00 	lea    0xb612(%rip),%r8        # 100a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea b3 00 00 	lea    0xb3ea(%rip),%rdi        # 100b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 9a b5 00 00 	lea    0xb59a(%rip),%rsi        # 10288 <_IO_stdin_used+0x288>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d a5 8e 06 00 	mov    0x68ea5(%rip),%r9        # 6dc08 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 fe 8e 06 00 	mov    0x68efe(%rip),%r8        # 6dc68 <fwp_heap+0x1428>
    4d6a:	48 8d 15 5f bb 00 00 	lea    0xbb5f(%rip),%rdx        # 108d0 <_IO_stdin_used+0x8d0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d e6 8e 06 00 	mov    0x68ee6(%rip),%rcx        # 6dc60 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d f4 8e 06 	movsd  0x68ef4(%rip),%xmm1        # 6dc80 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 e4 8e 06 	movsd  0x68ee4(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d c5 f2 00 00 	mov    0xf2c5(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 88 bf 00 	movdqa 0xbf88(%rip),%xmm0        # 10d60 <msg.4+0x30>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 9f 89 06 00 	lea    0x6899f(%rip),%rax        # 6d780 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 b1 bf 00 	movdqa 0xbfb1(%rip),%xmm2        # 10da0 <msg.4+0x70>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 45 89 06 00 	movaps %xmm0,0x68945(%rip)        # 6d740 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 6d bf 00 	movdqa 0xbf6d(%rip),%xmm0        # 10d70 <msg.4+0x40>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 d3 8d 06 00 01 	movl   $0x1,0x68dd3(%rip)        # 6dbe4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 33 89 06 00 	movaps %xmm0,0x68933(%rip)        # 6d750 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 5b bf 00 	movdqa 0xbf5b(%rip),%xmm0        # 10d80 <msg.4+0x50>
    4e24:	00 
    4e25:	0f 29 05 34 89 06 00 	movaps %xmm0,0x68934(%rip)        # 6d760 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 5c bf 00 	movdqa 0xbf5c(%rip),%xmm0        # 10d90 <msg.4+0x60>
    4e33:	00 
    4e34:	0f 29 05 35 89 06 00 	movaps %xmm0,0x68935(%rip)        # 6d770 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 b5 79 06 00 	lea    0x679b5(%rip),%r8        # 6c840 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 d0 8c 06 00 	mov    %rax,0x68cd0(%rip)        # 6dbf8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 ae 8c 06 00 	mov    %r12,0x68cae(%rip)        # 6dc00 <fwp_heap+0x13c0>
    4f52:	48 89 05 97 8c 06 00 	mov    %rax,0x68c97(%rip)        # 6dbf0 <fwp_heap+0x13b0>
    4f59:	48 89 1d b0 8c 06 00 	mov    %rbx,0x68cb0(%rip)        # 6dc10 <fwp_heap+0x13d0>
    4f60:	48 89 35 d9 8c 06 00 	mov    %rsi,0x68cd9(%rip)        # 6dc40 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 b1 00 00 	lea    0xb174(%rip),%rdi        # 100ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 b8 8c 06 00 	mov    %rax,0x68cb8(%rip)        # 6dc38 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 3c 8c 06 00    	mov    %eax,0x68c3c(%rip)        # 6dbe8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 2c 78 06 00 	mov    0x6782c(%rip),%r8        # 6c800 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 5c 77 06 00 	mov    %rbx,0x6775c(%rip)        # 6c808 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 48 77 06 00 	mov    %r8,0x67748(%rip)        # 6c800 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d 09 f1 04 00 	lea    0x4f109(%rip),%rcx        # 541e0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d b8 f0 04 00 	lea    0x4f0b8(%rip),%rcx        # 541c0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 af 00 00 	lea    0xafc2(%rip),%rdi        # 100fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 36 f0 04 00 	lea    0x4f036(%rip),%r12        # 541e0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 ae 00 00 	lea    0xaee8(%rip),%rax        # 10112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc ae 00 00 	lea    0xaecc(%rip),%rdx        # 100fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 af 00 00 	lea    0xaf04(%rip),%rdi        # 10148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd ae 00 00 	lea    0xaedd(%rip),%rdi        # 1012d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa ae 00 00 	lea    0xaeaa(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ce ed 01 00 	lea    0x1edce(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 b6 ed 01 00 	movaps %xmm0,0x1edb6(%rip)        # 240c0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 92 ed 01 00 	mov    %rsi,0x1ed92(%rip)        # 240a8 <fwp_tape_cached_bytes>
    5316:	0f 29 05 b3 ed 01 00 	movaps %xmm0,0x1edb3(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 b7 ed 01 00 	movaps %xmm0,0x1edb7(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 b8 ed 01 00 	mov    %rax,0x1edb8(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 ae 00 00 	lea    0xae09(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 3d ed 01 00 	mov    0x1ed3d(%rip),%rsi        # 240a8 <fwp_tape_cached_bytes>
    536b:	48 6b 15 8d ed 01 00 	imul   $0x68,0x1ed8d(%rip),%rdx        # 24100 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 46 ee 04 00 	cmp    0x4ee46(%rip),%rdx        # 541c0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 45 ee 04 00 	mov    0x4ee45(%rip),%rax        # 541c8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 3f ee 04 00 	add    0x4ee3f(%rip),%rax        # 541d0 <ad_raw_live+0x10>
    5391:	48 03 05 40 ee 04 00 	add    0x4ee40(%rip),%rax        # 541d8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 7c ed 01 00 	mov    0x1ed7c(%rip),%rcx        # 24120 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 65 ed 01 00 	mov    %rdi,0x1ed65(%rip)        # 24120 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 77 ed 01 00 	lea    0x1ed77(%rip),%rcx        # 24140 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 62 b5 00 00 	lea    0xb562(%rip),%rdi        # 10958 <_IO_stdin_used+0x958>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f ad 00 00 	lea    0xad6f(%rip),%rdi        # 10171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d c7 73 06 00 	mov    0x673c7(%rip),%rbx        # 6c7f8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 2a eb 00 00 	mov    0xeb2a(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 4b b4 00 00 	lea    0xb44b(%rip),%rdi        # 10988 <_IO_stdin_used+0x988>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 8d 72 06 00 	mov    0x6728d(%rip),%rax        # 6c800 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 67 72 06 00 	mov    %rdx,0x67267(%rip)        # 6c800 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d b4 71 06 00 	mov    0x671b4(%rip),%rbx        # 6c7f8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 71 71 06 00 	mov    %rbx,0x67171(%rip)        # 6c7f8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 71 71 06 00 	mov    %rdx,0x67171(%rip)        # 6c808 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 86 71 06 00 	lea    0x67186(%rip),%rsi        # 6c840 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 05 8d 06 00 	addq   $0x1,0x68d05(%rip)        # 6e488 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 1f b2 00 00 	lea    0xb21f(%rip),%rdi        # 109b8 <_IO_stdin_used+0x9b8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 30 b2 00 00 	lea    0xb230(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 a9 00 00 	lea    0xa9d2(%rip),%rdi        # 1018e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 3e 70 06 00 	lea    0x6703e(%rip),%rcx        # 6c840 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 3f 8c 06 00 	subq   $0x1,0x68c3f(%rip)        # 6e488 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 8b b1 00 00 	lea    0xb18b(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 20 8c 06 00 	cmpq   $0x0,0x68c20(%rip)        # 6e488 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 75 8b 06 00 	sub    %rax,0x68b75(%rip)        # 6e490 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 53 8b 06 00 	add    %r12,0x68b53(%rip)        # 6e490 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 af 82 06 00 	mov    0x682af(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 ac 6e 06 00 	lea    0x66eac(%rip),%rax        # 6c840 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 03 82 06 00 	add    0x68203(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 d0 81 06 00 	mov    0x681d0(%rip),%rsi        # 6dbf0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 f1 81 06 00 	mov    0x681f1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 e5 81 06 00 	add    0x681e5(%rip),%r8        # 6dc38 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 ad 81 06 	addsd  0x681ad(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 62 6d 06 00 	lea    0x66d62(%rip),%rax        # 6c840 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 6c 81 06 00 	sub    %rdi,0x6816c(%rip)        # 6dc60 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 84 81 06 	movsd  %xmm0,0x68184(%rip)        # 6dc80 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 3e 81 06 00 	sub    %rdx,0x6813e(%rip)        # 6dc60 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 44 81 06 	addsd  0x68144(%rip),%xmm0        # 6dc80 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 38 81 06 	movsd  %xmm0,0x68138(%rip)        # 6dc80 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 cf 80 06 00 	mov    0x680cf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d c9 80 06 00 	add    %rcx,0x680c9(%rip)        # 6dc70 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 82 80 06 00 	cmp    0x68082(%rip),%r9        # 6dc30 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 79 80 06 00 	mov    %r9,0x68079(%rip)        # 6dc30 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 6a 80 06 00 	cmp    0x6806a(%rip),%r9        # 6dc28 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 5d 80 06 00 	mov    %r9,0x6805d(%rip)        # 6dc28 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 73 7f 06 00 	add    0x67f73(%rip),%rdi        # 6dc38 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 50 6b 06 00 	lea    0x66b50(%rip),%r15        # 6c840 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 c0 7e 06 00 	add    0x67ec0(%rip),%r12        # 6dbf0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 19 7f 06 00 	add    0x67f19(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 18 7f 06 00 	cmp    %rax,0x67f18(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d50:	48 89 05 09 7f 06 00 	mov    %rax,0x67f09(%rip)        # 6dc60 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 08 7f 06 00 	mov    %rax,0x67f08(%rip)        # 6dc68 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 04 7f 06 	addsd  0x67f04(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 fc 7e 06 	movsd  %xmm0,0x67efc(%rip)        # 6dc78 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 43 7e 06 00    	mov    0x67e43(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 7f 6a 06 00 	lea    0x66a7f(%rip),%rdi        # 6c840 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 38 7e 06 00 	add    0x67e38(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 33 7e 06 00 	cmp    %rax,0x67e33(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e35:	48 89 05 24 7e 06 00 	mov    %rax,0x67e24(%rip)        # 6dc60 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 23 7e 06 00 	mov    %rax,0x67e23(%rip)        # 6dc68 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 1f 7e 06 	addsd  0x67e1f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 17 7e 06 	movsd  %xmm0,0x67e17(%rip)        # 6dc78 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ea 85 06 00    	mov    0x685ea(%rip),%ebx        # 6e508 <iteration_active>
    5f1e:	8b 05 c0 7c 06 00    	mov    0x67cc0(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 f4 68 06 00 	lea    0x668f4(%rip),%rax        # 6c840 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 ae 7c 06 00 	add    0x67cae(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 a9 7c 06 00 	cmp    %rax,0x67ca9(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fbf:	48 89 05 9a 7c 06 00 	mov    %rax,0x67c9a(%rip)        # 6dc60 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 99 7c 06 00 	mov    %rax,0x67c99(%rip)        # 6dc68 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 98 7c 06 	addsd  0x67c98(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 90 7c 06 	movsd  %xmm0,0x67c90(%rip)        # 6dc78 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 6d 7c 06 00 	mov    0x67c6d(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 db 84 06 	subsd  0x684db(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 cb 84 06 	comisd 0x684cb(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 c1 84 06 	movsd  %xmm0,0x684c1(%rip)        # 6e4e0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 c4 84 06 00 	addq   $0x1,0x684c4(%rip)        # 6e500 <iteration_requests>
    603b:	01 
    603c:	48 01 3d b5 84 06 00 	add    %rdi,0x684b5(%rip)        # 6e4f8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_apply>:
    6100:	55                   	push   %rbp
    6101:	48 89 f9             	mov    %rdi,%rcx
    6104:	48 89 e5             	mov    %rsp,%rbp
    6107:	41 57                	push   %r15
    6109:	41 56                	push   %r14
    610b:	41 55                	push   %r13
    610d:	41 89 f5             	mov    %esi,%r13d
    6110:	41 54                	push   %r12
    6112:	53                   	push   %rbx
    6113:	48 83 ec 28          	sub    $0x28,%rsp
    6117:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    611e:	00 00 
    6120:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    6124:	49 89 d6             	mov    %rdx,%r14
    6127:	44 8b 09             	mov    (%rcx),%r9d
    612a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    612e:	49 89 e0             	mov    %rsp,%r8
    6131:	49 c1 e1 05          	shl    $0x5,%r9
    6135:	4c 03 0d 5c 83 06 00 	add    0x6835c(%rip),%r9        # 6e498 <fwp_fns>
    613c:	41 8b 19             	mov    (%r9),%ebx
    613f:	45 85 e4             	test   %r12d,%r12d
    6142:	75 2c                	jne    6170 <fwp_apply+0x70>
    6144:	41 39 dd             	cmp    %ebx,%r13d
    6147:	72 27                	jb     6170 <fwp_apply+0x70>
    6149:	85 db                	test   %ebx,%ebx
    614b:	0f 84 b7 01 00 00    	je     6308 <fwp_apply+0x208>
    6151:	4c 89 f7             	mov    %r14,%rdi
    6154:	41 ff 51 08          	call   *0x8(%r9)
    6158:	48 89 c1             	mov    %rax,%rcx
    615b:	41 39 dd             	cmp    %ebx,%r13d
    615e:	0f 84 7c 01 00 00    	je     62e0 <fwp_apply+0x1e0>
    6164:	89 d8                	mov    %ebx,%eax
    6166:	41 29 dd             	sub    %ebx,%r13d
    6169:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    616d:	eb b8                	jmp    6127 <fwp_apply+0x27>
    616f:	90                   	nop
    6170:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    6175:	41 39 df             	cmp    %ebx,%r15d
    6178:	0f 82 dc 00 00 00    	jb     625a <fwp_apply+0x15a>
    617e:	41 89 df             	mov    %ebx,%r15d
    6181:	b8 01 00 00 00       	mov    $0x1,%eax
    6186:	48 89 e2             	mov    %rsp,%rdx
    6189:	45 29 e7             	sub    %r12d,%r15d
    618c:	85 db                	test   %ebx,%ebx
    618e:	0f 45 c3             	cmovne %ebx,%eax
    6191:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    6198:	00 
    6199:	48 c1 e8 04          	shr    $0x4,%rax
    619d:	48 c1 e0 04          	shl    $0x4,%rax
    61a1:	48 89 c6             	mov    %rax,%rsi
    61a4:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    61ab:	48 29 f2             	sub    %rsi,%rdx
    61ae:	48 39 d4             	cmp    %rdx,%rsp
    61b1:	74 15                	je     61c8 <fwp_apply+0xc8>
    61b3:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    61ba:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    61c1:	00 00 
    61c3:	48 39 d4             	cmp    %rdx,%rsp
    61c6:	75 eb                	jne    61b3 <fwp_apply+0xb3>
    61c8:	25 ff 0f 00 00       	and    $0xfff,%eax
    61cd:	48 29 c4             	sub    %rax,%rsp
    61d0:	48 85 c0             	test   %rax,%rax
    61d3:	0f 85 59 01 00 00    	jne    6332 <fwp_apply+0x232>
    61d9:	45 89 e2             	mov    %r12d,%r10d
    61dc:	48 89 e6             	mov    %rsp,%rsi
    61df:	48 89 e7             	mov    %rsp,%rdi
    61e2:	31 c0                	xor    %eax,%eax
    61e4:	49 c1 e2 03          	shl    $0x3,%r10
    61e8:	45 85 e4             	test   %r12d,%r12d
    61eb:	74 25                	je     6212 <fwp_apply+0x112>
    61ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61f4:	00 
    61f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    61fc:	00 00 00 00 
    6200:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    6205:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    6209:	48 83 c0 08          	add    $0x8,%rax
    620d:	4c 39 d0             	cmp    %r10,%rax
    6210:	75 ee                	jne    6200 <fwp_apply+0x100>
    6212:	45 85 ff             	test   %r15d,%r15d
    6215:	0f 84 f4 00 00 00    	je     630f <fwp_apply+0x20f>
    621b:	44 89 fa             	mov    %r15d,%edx
    621e:	4c 89 f0             	mov    %r14,%rax
    6221:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    6225:	44 89 e2             	mov    %r12d,%edx
    6228:	66 90                	xchg   %ax,%ax
    622a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6231:	00 00 00 00 
    6235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    623c:	00 00 00 00 
    6240:	4c 8b 10             	mov    (%rax),%r10
    6243:	89 d1                	mov    %edx,%ecx
    6245:	48 83 c0 08          	add    $0x8,%rax
    6249:	83 c2 01             	add    $0x1,%edx
    624c:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    6250:	4c 39 d8             	cmp    %r11,%rax
    6253:	75 eb                	jne    6240 <fwp_apply+0x140>
    6255:	e9 b5 00 00 00       	jmp    630f <fwp_apply+0x20f>
    625a:	41 8d 7f 01          	lea    0x1(%r15),%edi
    625e:	be 02 00 00 00       	mov    $0x2,%esi
    6263:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    6267:	48 c1 e7 03          	shl    $0x3,%rdi
    626b:	e8 a0 fc ff ff       	call   5f10 <fwp_heap_alloc>
    6270:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    6274:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    6279:	48 89 c3             	mov    %rax,%rbx
    627c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    6280:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6284:	66 0f d6 00          	movq   %xmm0,(%rax)
    6288:	45 85 e4             	test   %r12d,%r12d
    628b:	74 14                	je     62a1 <fwp_apply+0x1a1>
    628d:	44 89 e2             	mov    %r12d,%edx
    6290:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    6294:	48 8d 78 08          	lea    0x8(%rax),%rdi
    6298:	48 c1 e2 03          	shl    $0x3,%rdx
    629c:	e8 4f d3 ff ff       	call   35f0 <memmove@plt>
    62a1:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    62a5:	45 85 ed             	test   %r13d,%r13d
    62a8:	74 2e                	je     62d8 <fwp_apply+0x1d8>
    62aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62b1:	00 00 00 00 
    62b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62bc:	00 00 00 00 
    62c0:	49 8b 16             	mov    (%r14),%rdx
    62c3:	44 89 e0             	mov    %r12d,%eax
    62c6:	49 83 c6 08          	add    $0x8,%r14
    62ca:	41 83 c4 01          	add    $0x1,%r12d
    62ce:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    62d3:	49 39 ce             	cmp    %rcx,%r14
    62d6:	75 e8                	jne    62c0 <fwp_apply+0x1c0>
    62d8:	48 89 d9             	mov    %rbx,%rcx
    62db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    62e0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    62e4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    62eb:	00 00 
    62ed:	75 4e                	jne    633d <fwp_apply+0x23d>
    62ef:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    62f3:	48 89 c8             	mov    %rcx,%rax
    62f6:	5b                   	pop    %rbx
    62f7:	41 5c                	pop    %r12
    62f9:	41 5d                	pop    %r13
    62fb:	41 5e                	pop    %r14
    62fd:	41 5f                	pop    %r15
    62ff:	5d                   	pop    %rbp
    6300:	c3                   	ret
    6301:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6308:	45 31 ff             	xor    %r15d,%r15d
    630b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    630f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    6313:	41 ff 51 08          	call   *0x8(%r9)
    6317:	48 89 c1             	mov    %rax,%rcx
    631a:	45 39 fd             	cmp    %r15d,%r13d
    631d:	74 c1                	je     62e0 <fwp_apply+0x1e0>
    631f:	45 01 e5             	add    %r12d,%r13d
    6322:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    6326:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    632a:	41 29 dd             	sub    %ebx,%r13d
    632d:	e9 f5 fd ff ff       	jmp    6127 <fwp_apply+0x27>
    6332:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    6338:	e9 9c fe ff ff       	jmp    61d9 <fwp_apply+0xd9>
    633d:	e8 0e d1 ff ff       	call   3450 <__stack_chk_fail@plt>
    6342:	0f 1f 00             	nopl   (%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 

0000000000006350 <fwp_tape_reserve>:
    6350:	41 57                	push   %r15
    6352:	41 56                	push   %r14
    6354:	41 55                	push   %r13
    6356:	41 54                	push   %r12
    6358:	55                   	push   %rbp
    6359:	53                   	push   %rbx
    635a:	48 83 ec 18          	sub    $0x18,%rsp
    635e:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6365:	0f 87 cd 01 00 00    	ja     6538 <fwp_tape_reserve+0x1e8>
    636b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    636f:	48 89 fd             	mov    %rdi,%rbp
    6372:	48 39 f3             	cmp    %rsi,%rbx
    6375:	0f 8d 18 01 00 00    	jge    6493 <fwp_tape_reserve+0x143>
    637b:	48 85 db             	test   %rbx,%rbx
    637e:	b8 40 00 00 00       	mov    $0x40,%eax
    6383:	48 0f 44 d8          	cmove  %rax,%rbx
    6387:	48 39 f3             	cmp    %rsi,%rbx
    638a:	7d 24                	jge    63b0 <fwp_tape_reserve+0x60>
    638c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6393:	0f 8f 0f 01 00 00    	jg     64a8 <fwp_tape_reserve+0x158>
    6399:	48 01 db             	add    %rbx,%rbx
    639c:	48 39 f3             	cmp    %rsi,%rbx
    639f:	7c eb                	jl     638c <fwp_tape_reserve+0x3c>
    63a1:	0f 1f 40 00          	nopl   0x0(%rax)
    63a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    63ac:	00 00 00 00 
    63b0:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    63b7:	00 
    63b8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    63bc:	ba 01 00 00 00       	mov    $0x1,%edx
    63c1:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    63c5:	4c 89 ee             	mov    %r13,%rsi
    63c8:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    63cc:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    63d0:	e8 bb ed ff ff       	call   5190 <ad_raw_realloc>
    63d5:	48 85 c0             	test   %rax,%rax
    63d8:	0f 84 66 01 00 00    	je     6544 <fwp_tape_reserve+0x1f4>
    63de:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    63e2:	48 89 45 20          	mov    %rax,0x20(%rbp)
    63e6:	4d 29 fc             	sub    %r15,%r12
    63e9:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    63ed:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    63f1:	4d 85 f6             	test   %r14,%r14
    63f4:	0f 84 f6 00 00 00    	je     64f0 <fwp_tape_reserve+0x1a0>
    63fa:	49 8b 56 60          	mov    0x60(%r14),%rdx
    63fe:	48 39 da             	cmp    %rbx,%rdx
    6401:	7d 78                	jge    647b <fwp_tape_reserve+0x12b>
    6403:	48 89 d9             	mov    %rbx,%rcx
    6406:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    640a:	be 02 00 00 00       	mov    $0x2,%esi
    640f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6414:	48 c1 e1 04          	shl    $0x4,%rcx
    6418:	48 89 cf             	mov    %rcx,%rdi
    641b:	48 89 0c 24          	mov    %rcx,(%rsp)
    641f:	e8 ec fa ff ff       	call   5f10 <fwp_heap_alloc>
    6424:	49 89 c5             	mov    %rax,%r13
    6427:	4d 85 ff             	test   %r15,%r15
    642a:	74 27                	je     6453 <fwp_tape_reserve+0x103>
    642c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6431:	48 8b 0c 24          	mov    (%rsp),%rcx
    6435:	48 89 c7             	mov    %rax,%rdi
    6438:	4c 89 fe             	mov    %r15,%rsi
    643b:	48 c1 e2 04          	shl    $0x4,%rdx
    643f:	48 39 ca             	cmp    %rcx,%rdx
    6442:	48 0f 47 d1          	cmova  %rcx,%rdx
    6446:	e8 35 d1 ff ff       	call   3580 <memcpy@plt>
    644b:	4c 89 ff             	mov    %r15,%rdi
    644e:	e8 bd f5 ff ff       	call   5a10 <fwp_mem_free>
    6453:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    6457:	48 89 da             	mov    %rbx,%rdx
    645a:	31 f6                	xor    %esi,%esi
    645c:	48 29 fa             	sub    %rdi,%rdx
    645f:	48 c1 e7 04          	shl    $0x4,%rdi
    6463:	48 c1 e2 04          	shl    $0x4,%rdx
    6467:	4c 01 ef             	add    %r13,%rdi
    646a:	e8 41 d0 ff ff       	call   34b0 <memset@plt>
    646f:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    6473:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6477:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    647b:	4d 85 e4             	test   %r12,%r12
    647e:	75 4b                	jne    64cb <fwp_tape_reserve+0x17b>
    6480:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6487:	00 
    6488:	4c 01 e8             	add    %r13,%rax
    648b:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    648f:	48 89 45 28          	mov    %rax,0x28(%rbp)
    6493:	48 83 c4 18          	add    $0x18,%rsp
    6497:	5b                   	pop    %rbx
    6498:	5d                   	pop    %rbp
    6499:	41 5c                	pop    %r12
    649b:	41 5d                	pop    %r13
    649d:	41 5e                	pop    %r14
    649f:	41 5f                	pop    %r15
    64a1:	c3                   	ret
    64a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    64a8:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    64ad:	e9 fe fe ff ff       	jmp    63b0 <fwp_tape_reserve+0x60>
    64b2:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    64b9:	00 
    64ba:	e8 31 d1 ff ff       	call   35f0 <memmove@plt>
    64bf:	4c 03 6d 30          	add    0x30(%rbp),%r13
    64c3:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64c7:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    64cb:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    64cf:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    64d6:	00 
    64d7:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    64de:	00 
    64df:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    64e3:	e8 08 d1 ff ff       	call   35f0 <memmove@plt>
    64e8:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64ec:	eb 9a                	jmp    6488 <fwp_tape_reserve+0x138>
    64ee:	66 90                	xchg   %ax,%ax
    64f0:	48 89 de             	mov    %rbx,%rsi
    64f3:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    64f7:	ba 02 00 00 00       	mov    $0x2,%edx
    64fc:	48 c1 e6 04          	shl    $0x4,%rsi
    6500:	e8 8b ec ff ff       	call   5190 <ad_raw_realloc>
    6505:	48 85 c0             	test   %rax,%rax
    6508:	74 3a                	je     6544 <fwp_tape_reserve+0x1f4>
    650a:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    650e:	48 89 45 30          	mov    %rax,0x30(%rbp)
    6512:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6516:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    651a:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    651e:	4d 85 e4             	test   %r12,%r12
    6521:	75 8f                	jne    64b2 <fwp_tape_reserve+0x162>
    6523:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    6527:	48 8b 45 20          	mov    0x20(%rbp),%rax
    652b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6532:	00 
    6533:	e9 50 ff ff ff       	jmp    6488 <fwp_tape_reserve+0x138>
    6538:	48 8d 3d 68 9c 00 00 	lea    0x9c68(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    653f:	e8 0c df ff ff       	call   4450 <fwp_trap>
    6544:	48 89 ef             	mov    %rbp,%rdi
    6547:	e8 44 d7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    654c:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    6550:	48 85 ff             	test   %rdi,%rdi
    6553:	74 05                	je     655a <fwp_tape_reserve+0x20a>
    6555:	e8 76 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    655a:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    655e:	48 85 ff             	test   %rdi,%rdi
    6561:	74 05                	je     6568 <fwp_tape_reserve+0x218>
    6563:	e8 68 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6568:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    656c:	48 85 ff             	test   %rdi,%rdi
    656f:	74 05                	je     6576 <fwp_tape_reserve+0x226>
    6571:	e8 5a eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6576:	31 c9                	xor    %ecx,%ecx
    6578:	31 c0                	xor    %eax,%eax
    657a:	31 d2                	xor    %edx,%edx
    657c:	be 01 00 00 00       	mov    $0x1,%esi
    6581:	89 55 04             	mov    %edx,0x4(%rbp)
    6584:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6588:	ba 13 00 00 00       	mov    $0x13,%edx
    658d:	48 8d 3d 74 9a 00 00 	lea    0x9a74(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    6594:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6598:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    659c:	48 8b 0d bd da 00 00 	mov    0xdabd(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    65a3:	48 89 45 40          	mov    %rax,0x40(%rbp)
    65a7:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    65ab:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    65af:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    65b3:	e8 a8 d0 ff ff       	call   3660 <fwrite@plt>
    65b8:	31 ff                	xor    %edi,%edi
    65ba:	e8 e1 cf ff ff       	call   35a0 <fflush@plt>
    65bf:	bf 66 00 00 00       	mov    $0x66,%edi
    65c4:	e8 b7 d0 ff ff       	call   3680 <_Exit@plt>
    65c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000065d0 <f128.constprop.0>:
    65d0:	41 57                	push   %r15
    65d2:	41 56                	push   %r14
    65d4:	41 55                	push   %r13
    65d6:	41 54                	push   %r12
    65d8:	49 89 f4             	mov    %rsi,%r12
    65db:	55                   	push   %rbp
    65dc:	48 89 fd             	mov    %rdi,%rbp
    65df:	53                   	push   %rbx
    65e0:	48 83 ec 08          	sub    $0x8,%rsp
    65e4:	48 85 ff             	test   %rdi,%rdi
    65e7:	79 09                	jns    65f2 <f128.constprop.0+0x22>
    65e9:	48 85 f6             	test   %rsi,%rsi
    65ec:	0f 88 fe 00 00 00    	js     66f0 <f128.constprop.0+0x120>
    65f2:	48 89 f8             	mov    %rdi,%rax
    65f5:	48 09 f0             	or     %rsi,%rax
    65f8:	0f 89 d2 00 00 00    	jns    66d0 <f128.constprop.0+0x100>
    65fe:	48 89 f8             	mov    %rdi,%rax
    6601:	48 c1 f8 20          	sar    $0x20,%rax
    6605:	48 85 ff             	test   %rdi,%rdi
    6608:	0f 88 02 01 00 00    	js     6710 <f128.constprop.0+0x140>
    660e:	4c 8b 3d cb a7 00 00 	mov    0xa7cb(%rip),%r15        # 10de0 <msg.4+0xb0>
    6615:	48 89 c7             	mov    %rax,%rdi
    6618:	e8 13 e1 ff ff       	call   4730 <fwp_tape_of>
    661d:	48 89 c3             	mov    %rax,%rbx
    6620:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6625:	0f 85 16 01 00 00    	jne    6741 <f128.constprop.0+0x171>
    662b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    662f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6636:	0f 8f f9 00 00 00    	jg     6735 <f128.constprop.0+0x165>
    663c:	89 e8                	mov    %ebp,%eax
    663e:	49 39 c5             	cmp    %rax,%r13
    6641:	0f 8e e2 00 00 00    	jle    6729 <f128.constprop.0+0x159>
    6647:	4d 85 e4             	test   %r12,%r12
    664a:	78 0c                	js     6658 <f128.constprop.0+0x88>
    664c:	44 89 e0             	mov    %r12d,%eax
    664f:	49 39 c5             	cmp    %rax,%r13
    6652:	0f 8e d1 00 00 00    	jle    6729 <f128.constprop.0+0x159>
    6658:	4d 89 ee             	mov    %r13,%r14
    665b:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    665f:	48 89 df             	mov    %rbx,%rdi
    6662:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6666:	e8 e5 fc ff ff       	call   6350 <fwp_tape_reserve>
    666b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    666f:	4d 85 e4             	test   %r12,%r12
    6672:	48 8b 0d 67 a7 00 00 	mov    0xa767(%rip),%rcx        # 10de0 <msg.4+0xb0>
    6679:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6680:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6684:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6688:	4c 0f 48 e2          	cmovs  %rdx,%r12
    668c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6690:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6694:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6698:	48 8b 43 38          	mov    0x38(%rbx),%rax
    669c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    66a0:	49 8d 45 01          	lea    0x1(%r13),%rax
    66a4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66a8:	48 83 c4 08          	add    $0x8,%rsp
    66ac:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66b3:	ff ff ff 
    66b6:	48 21 e8             	and    %rbp,%rax
    66b9:	5b                   	pop    %rbx
    66ba:	5d                   	pop    %rbp
    66bb:	4c 09 e8             	or     %r13,%rax
    66be:	41 5c                	pop    %r12
    66c0:	41 5d                	pop    %r13
    66c2:	41 5e                	pop    %r14
    66c4:	41 5f                	pop    %r15
    66c6:	c3                   	ret
    66c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    66ce:	00 00 
    66d0:	48 89 f0             	mov    %rsi,%rax
    66d3:	48 c1 ff 20          	sar    $0x20,%rdi
    66d7:	48 c1 f8 20          	sar    $0x20,%rax
    66db:	48 39 c7             	cmp    %rax,%rdi
    66de:	0f 84 2a ff ff ff    	je     660e <f128.constprop.0+0x3e>
    66e4:	48 8d 3d 1d a3 00 00 	lea    0xa31d(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    66eb:	e8 60 dd ff ff       	call   4450 <fwp_trap>
    66f0:	48 83 c4 08          	add    $0x8,%rsp
    66f4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    66fb:	5b                   	pop    %rbx
    66fc:	5d                   	pop    %rbp
    66fd:	41 5c                	pop    %r12
    66ff:	41 5d                	pop    %r13
    6701:	41 5e                	pop    %r14
    6703:	41 5f                	pop    %r15
    6705:	c3                   	ret
    6706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    670d:	00 00 00 
    6710:	48 89 f0             	mov    %rsi,%rax
    6713:	48 89 f5             	mov    %rsi,%rbp
    6716:	45 31 ff             	xor    %r15d,%r15d
    6719:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6720:	48 c1 f8 20          	sar    $0x20,%rax
    6724:	e9 ec fe ff ff       	jmp    6615 <f128.constprop.0+0x45>
    6729:	48 8d 3d 92 9a 00 00 	lea    0x9a92(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    6730:	e8 1b dd ff ff       	call   4450 <fwp_trap>
    6735:	48 8d 3d 6b 9a 00 00 	lea    0x9a6b(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    673c:	e8 0f dd ff ff       	call   4450 <fwp_trap>
    6741:	48 8d 3d 08 a3 00 00 	lea    0xa308(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    6748:	e8 03 dd ff ff       	call   4450 <fwp_trap>
    674d:	0f 1f 00             	nopl   (%rax)

0000000000006750 <w107>:
    6750:	66 0f 28 d0          	movapd %xmm0,%xmm2
    6754:	41 57                	push   %r15
    6756:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    675a:	41 56                	push   %r14
    675c:	41 55                	push   %r13
    675e:	41 54                	push   %r12
    6760:	49 89 f4             	mov    %rsi,%r12
    6763:	55                   	push   %rbp
    6764:	48 89 fd             	mov    %rdi,%rbp
    6767:	53                   	push   %rbx
    6768:	48 83 ec 38          	sub    $0x38,%rsp
    676c:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6771:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6777:	48 85 ff             	test   %rdi,%rdi
    677a:	0f 88 d0 04 00 00    	js     6c50 <w107+0x500>
    6780:	49 89 ff             	mov    %rdi,%r15
    6783:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6789:	49 c1 ff 20          	sar    $0x20,%r15
    678d:	4c 89 ff             	mov    %r15,%rdi
    6790:	e8 9b df ff ff       	call   4730 <fwp_tape_of>
    6795:	48 89 c3             	mov    %rax,%rbx
    6798:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    679d:	0f 85 45 05 00 00    	jne    6ce8 <w107+0x598>
    67a3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    67a7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    67ae:	0f 8f 28 05 00 00    	jg     6cdc <w107+0x58c>
    67b4:	89 e8                	mov    %ebp,%eax
    67b6:	49 39 c5             	cmp    %rax,%r13
    67b9:	0f 8e 11 05 00 00    	jle    6cd0 <w107+0x580>
    67bf:	4d 89 ee             	mov    %r13,%r14
    67c2:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    67c6:	48 89 df             	mov    %rbx,%rdi
    67c9:	49 8d 76 01          	lea    0x1(%r14),%rsi
    67cd:	e8 7e fb ff ff       	call   6350 <fwp_tape_reserve>
    67d2:	48 8b 43 20          	mov    0x20(%rbx),%rax
    67d6:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    67db:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    67e1:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    67e5:	48 8b 43 30          	mov    0x30(%rbx),%rax
    67e9:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    67ef:	48 8b 43 28          	mov    0x28(%rbx),%rax
    67f3:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    67f7:	48 8b 43 38          	mov    0x38(%rbx),%rax
    67fb:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6801:	49 8d 45 01          	lea    0x1(%r13),%rax
    6805:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    680c:	ff ff ff 
    680f:	49 21 ee             	and    %rbp,%r14
    6812:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6816:	4d 09 ee             	or     %r13,%r14
    6819:	4d 89 f5             	mov    %r14,%r13
    681c:	49 c1 fd 20          	sar    $0x20,%r13
    6820:	4d 85 e4             	test   %r12,%r12
    6823:	78 10                	js     6835 <w107+0xe5>
    6825:	4c 89 e0             	mov    %r12,%rax
    6828:	48 c1 f8 20          	sar    $0x20,%rax
    682c:	4c 39 e8             	cmp    %r13,%rax
    682f:	0f 85 87 04 00 00    	jne    6cbc <w107+0x56c>
    6835:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    683b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6841:	4d 39 ef             	cmp    %r13,%r15
    6844:	0f 84 d6 03 00 00    	je     6c20 <w107+0x4d0>
    684a:	f2 0f 10 1d 8e a5 00 	movsd  0xa58e(%rip),%xmm3        # 10de0 <msg.4+0xb0>
    6851:	00 
    6852:	f2 0f 10 25 8e a5 00 	movsd  0xa58e(%rip),%xmm4        # 10de8 <msg.4+0xb8>
    6859:	00 
    685a:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    6860:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    6866:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    686c:	4c 89 ef             	mov    %r13,%rdi
    686f:	e8 bc de ff ff       	call   4730 <fwp_tape_of>
    6874:	48 89 c3             	mov    %rax,%rbx
    6877:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    687c:	0f 85 66 04 00 00    	jne    6ce8 <w107+0x598>
    6882:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6886:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    688d:	0f 8f 49 04 00 00    	jg     6cdc <w107+0x58c>
    6893:	44 89 f0             	mov    %r14d,%eax
    6896:	49 39 c7             	cmp    %rax,%r15
    6899:	0f 8e 31 04 00 00    	jle    6cd0 <w107+0x580>
    689f:	4d 85 e4             	test   %r12,%r12
    68a2:	78 0c                	js     68b0 <w107+0x160>
    68a4:	44 89 e0             	mov    %r12d,%eax
    68a7:	49 39 c7             	cmp    %rax,%r15
    68aa:	0f 8e 20 04 00 00    	jle    6cd0 <w107+0x580>
    68b0:	4c 89 f9             	mov    %r15,%rcx
    68b3:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    68b7:	48 89 df             	mov    %rbx,%rdi
    68ba:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    68be:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    68c3:	e8 88 fa ff ff       	call   6350 <fwp_tape_reserve>
    68c8:	48 8b 43 20          	mov    0x20(%rbx),%rax
    68cc:	4d 85 e4             	test   %r12,%r12
    68cf:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    68d3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    68d8:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    68de:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    68e4:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    68e8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    68ec:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    68f1:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    68f8:	49 0f 49 c4          	cmovns %r12,%rax
    68fc:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6900:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6903:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6907:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    690c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6910:	48 85 ed             	test   %rbp,%rbp
    6913:	0f 88 0e 04 00 00    	js     6d27 <w107+0x5d7>
    6919:	48 89 e8             	mov    %rbp,%rax
    691c:	48 c1 f8 20          	sar    $0x20,%rax
    6920:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6925:	49 39 c5             	cmp    %rax,%r13
    6928:	74 1a                	je     6944 <w107+0x1f4>
    692a:	48 89 c7             	mov    %rax,%rdi
    692d:	e8 fe dd ff ff       	call   4730 <fwp_tape_of>
    6932:	48 89 c3             	mov    %rax,%rbx
    6935:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    693a:	0f 85 a8 03 00 00    	jne    6ce8 <w107+0x598>
    6940:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6944:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    694b:	0f 8f 8b 03 00 00    	jg     6cdc <w107+0x58c>
    6951:	89 e8                	mov    %ebp,%eax
    6953:	4c 39 e0             	cmp    %r12,%rax
    6956:	0f 8d 74 03 00 00    	jge    6cd0 <w107+0x580>
    695c:	4c 89 e0             	mov    %r12,%rax
    695f:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6963:	48 89 df             	mov    %rbx,%rdi
    6966:	48 8d 70 01          	lea    0x1(%rax),%rsi
    696a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    696f:	e8 dc f9 ff ff       	call   6350 <fwp_tape_reserve>
    6974:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6979:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    697d:	48 8b 0d 64 a4 00 00 	mov    0xa464(%rip),%rcx        # 10de8 <msg.4+0xb8>
    6984:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    698a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    698d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6991:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6995:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    699b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    699f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    69a3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    69a7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    69ae:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    69b2:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    69b7:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    69bc:	48 89 43 10          	mov    %rax,0x10(%rbx)
    69c0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69c7:	ff ff ff 
    69ca:	48 21 c5             	and    %rax,%rbp
    69cd:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    69d3:	4c 09 e5             	or     %r12,%rbp
    69d6:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69dd:	ff ff ff 
    69e0:	49 21 c6             	and    %rax,%r14
    69e3:	4d 09 fe             	or     %r15,%r14
    69e6:	4d 89 f4             	mov    %r14,%r12
    69e9:	49 c1 fc 20          	sar    $0x20,%r12
    69ed:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    69f2:	74 16                	je     6a0a <w107+0x2ba>
    69f4:	4c 89 e7             	mov    %r12,%rdi
    69f7:	e8 34 dd ff ff       	call   4730 <fwp_tape_of>
    69fc:	48 89 c3             	mov    %rax,%rbx
    69ff:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a04:	0f 85 de 02 00 00    	jne    6ce8 <w107+0x598>
    6a0a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6a0e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6a15:	0f 8f c1 02 00 00    	jg     6cdc <w107+0x58c>
    6a1b:	44 89 f0             	mov    %r14d,%eax
    6a1e:	49 39 c7             	cmp    %rax,%r15
    6a21:	0f 8e a9 02 00 00    	jle    6cd0 <w107+0x580>
    6a27:	4d 89 fd             	mov    %r15,%r13
    6a2a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6a2e:	48 89 df             	mov    %rbx,%rdi
    6a31:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6a35:	e8 16 f9 ff ff       	call   6350 <fwp_tape_reserve>
    6a3a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6a3e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6a44:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6a48:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6a4c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a52:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6a56:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6a5a:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6a5e:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a64:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    6a68:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a6f:	ff ff ff 
    6a72:	49 21 c6             	and    %rax,%r14
    6a75:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6a79:	4d 09 fe             	or     %r15,%r14
    6a7c:	4d 89 f7             	mov    %r14,%r15
    6a7f:	49 c1 ff 20          	sar    $0x20,%r15
    6a83:	4d 39 e7             	cmp    %r12,%r15
    6a86:	74 1d                	je     6aa5 <w107+0x355>
    6a88:	4c 89 ff             	mov    %r15,%rdi
    6a8b:	e8 a0 dc ff ff       	call   4730 <fwp_tape_of>
    6a90:	48 89 c3             	mov    %rax,%rbx
    6a93:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a98:	0f 85 4a 02 00 00    	jne    6ce8 <w107+0x598>
    6a9e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6aa2:	4d 89 fc             	mov    %r15,%r12
    6aa5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6aac:	0f 8f 2a 02 00 00    	jg     6cdc <w107+0x58c>
    6ab2:	44 89 f0             	mov    %r14d,%eax
    6ab5:	4c 39 e8             	cmp    %r13,%rax
    6ab8:	0f 8d 12 02 00 00    	jge    6cd0 <w107+0x580>
    6abe:	f2 0f 10 3d 2a a3 00 	movsd  0xa32a(%rip),%xmm7        # 10df0 <msg.4+0xc0>
    6ac5:	00 
    6ac6:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    6acc:	4d 89 ef             	mov    %r13,%r15
    6acf:	48 89 df             	mov    %rbx,%rdi
    6ad2:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6ad8:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    6add:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6ae1:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6ae5:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    6aea:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6af0:	e8 5b f8 ff ff       	call   6350 <fwp_tape_reserve>
    6af5:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6af9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6afe:	48 8b 15 eb a2 00 00 	mov    0xa2eb(%rip),%rdx        # 10df0 <msg.4+0xc0>
    6b05:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6b09:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6b0d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6b11:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6b15:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6b19:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6b1d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6b24:	ff 
    6b25:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6b29:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6b30:	00 
    6b31:	49 8d 45 01          	lea    0x1(%r13),%rax
    6b35:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6b39:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6b40:	ff ff ff 
    6b43:	49 21 c6             	and    %rax,%r14
    6b46:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    6b4c:	4d 09 ee             	or     %r13,%r14
    6b4f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6b53:	0f 84 57 01 00 00    	je     6cb0 <w107+0x560>
    6b59:	48 89 ef             	mov    %rbp,%rdi
    6b5c:	48 c1 ff 20          	sar    $0x20,%rdi
    6b60:	4c 39 e7             	cmp    %r12,%rdi
    6b63:	74 13                	je     6b78 <w107+0x428>
    6b65:	e8 c6 db ff ff       	call   4730 <fwp_tape_of>
    6b6a:	48 89 c3             	mov    %rax,%rbx
    6b6d:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6b72:	0f 85 70 01 00 00    	jne    6ce8 <w107+0x598>
    6b78:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6b7c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6b83:	0f 8f 53 01 00 00    	jg     6cdc <w107+0x58c>
    6b89:	89 e8                	mov    %ebp,%eax
    6b8b:	4c 39 e0             	cmp    %r12,%rax
    6b8e:	0f 8d 3c 01 00 00    	jge    6cd0 <w107+0x580>
    6b94:	4d 89 e5             	mov    %r12,%r13
    6b97:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6b9b:	48 89 df             	mov    %rbx,%rdi
    6b9e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6ba2:	e8 a9 f7 ff ff       	call   6350 <fwp_tape_reserve>
    6ba7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6bab:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6bb0:	48 89 ef             	mov    %rbp,%rdi
    6bb3:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6bb7:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6bbb:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6bc1:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6bc5:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6bc9:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6bcd:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6bd3:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6bd8:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6bdc:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6be3:	ff ff ff 
    6be6:	48 21 c7             	and    %rax,%rdi
    6be9:	4c 09 e7             	or     %r12,%rdi
    6bec:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6bf2:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6bf8:	4c 89 f6             	mov    %r14,%rsi
    6bfb:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6c00:	e8 cb f9 ff ff       	call   65d0 <f128.constprop.0>
    6c05:	48 83 c4 38          	add    $0x38,%rsp
    6c09:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6c0e:	5b                   	pop    %rbx
    6c0f:	5d                   	pop    %rbp
    6c10:	41 5c                	pop    %r12
    6c12:	41 5d                	pop    %r13
    6c14:	41 5e                	pop    %r14
    6c16:	41 5f                	pop    %r15
    6c18:	c3                   	ret
    6c19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c20:	f2 0f 10 3d b8 a1 00 	movsd  0xa1b8(%rip),%xmm7        # 10de0 <msg.4+0xb0>
    6c27:	00 
    6c28:	f2 0f 10 15 b8 a1 00 	movsd  0xa1b8(%rip),%xmm2        # 10de8 <msg.4+0xb8>
    6c2f:	00 
    6c30:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6c36:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    6c3c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6c42:	e9 3b fc ff ff       	jmp    6882 <w107+0x132>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6c56:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c5c:	48 85 f6             	test   %rsi,%rsi
    6c5f:	0f 89 8f 00 00 00    	jns    6cf4 <w107+0x5a4>
    6c65:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6c6b:	f2 0f 10 05 6d a1 00 	movsd  0xa16d(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    6c72:	00 
    6c73:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    6c7a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c81:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6c86:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6c8a:	f2 0f 59 0d 5e a1 00 	mulsd  0xa15e(%rip),%xmm1        # 10df0 <msg.4+0xc0>
    6c91:	00 
    6c92:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6c96:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c9c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6ca2:	e9 45 ff ff ff       	jmp    6bec <w107+0x49c>
    6ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cae:	00 00 
    6cb0:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6cb7:	e9 30 ff ff ff       	jmp    6bec <w107+0x49c>
    6cbc:	48 8d 3d 45 9d 00 00 	lea    0x9d45(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    6cc3:	e8 88 d7 ff ff       	call   4450 <fwp_trap>
    6cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ccf:	00 
    6cd0:	48 8d 3d eb 94 00 00 	lea    0x94eb(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    6cd7:	e8 74 d7 ff ff       	call   4450 <fwp_trap>
    6cdc:	48 8d 3d c4 94 00 00 	lea    0x94c4(%rip),%rdi        # 101a7 <_IO_stdin_used+0x1a7>
    6ce3:	e8 68 d7 ff ff       	call   4450 <fwp_trap>
    6ce8:	48 8d 3d 61 9d 00 00 	lea    0x9d61(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    6cef:	e8 5c d7 ff ff       	call   4450 <fwp_trap>
    6cf4:	f2 0f 10 35 e4 a0 00 	movsd  0xa0e4(%rip),%xmm6        # 10de0 <msg.4+0xb0>
    6cfb:	00 
    6cfc:	49 89 f5             	mov    %rsi,%r13
    6cff:	49 89 f6             	mov    %rsi,%r14
    6d02:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6d09:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6d10:	00 00 
    6d12:	49 c1 fd 20          	sar    $0x20,%r13
    6d16:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    6d1c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6d22:	e9 45 fb ff ff       	jmp    686c <w107+0x11c>
    6d27:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    6d2d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6d32:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6d39:	66 0f 28 f4          	movapd %xmm4,%xmm6
    6d3d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6d41:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6d47:	e9 8a fc ff ff       	jmp    69d6 <w107+0x286>
    6d4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006d50 <fwp_data.part.0.constprop.0>:
    6d50:	41 56                	push   %r14
    6d52:	8b 05 8c 6e 06 00    	mov    0x66e8c(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    6d58:	41 89 fe             	mov    %edi,%r14d
    6d5b:	41 55                	push   %r13
    6d5d:	44 8b 2d a4 77 06 00 	mov    0x677a4(%rip),%r13d        # 6e508 <iteration_active>
    6d64:	41 54                	push   %r12
    6d66:	49 89 f4             	mov    %rsi,%r12
    6d69:	55                   	push   %rbp
    6d6a:	53                   	push   %rbx
    6d6b:	45 85 ed             	test   %r13d,%r13d
    6d6e:	0f 84 1c 01 00 00    	je     6e90 <fwp_data.part.0.constprop.0+0x140>
    6d74:	48 83 05 84 77 06 00 	addq   $0x1,0x67784(%rip)        # 6e500 <iteration_requests>
    6d7b:	01 
    6d7c:	48 83 05 74 77 06 00 	addq   $0x18,0x67774(%rip)        # 6e4f8 <iteration_bytes>
    6d83:	18 
    6d84:	85 c0                	test   %eax,%eax
    6d86:	0f 84 8c 01 00 00    	je     6f18 <fwp_data.part.0.constprop.0+0x1c8>
    6d8c:	0f b6 05 4f 6a 06 00 	movzbl 0x66a4f(%rip),%eax        # 6d7e2 <fwp_heap+0xfa2>
    6d93:	48 8d 15 a6 5a 06 00 	lea    0x65aa6(%rip),%rdx        # 6c840 <fwp_heap>
    6d9a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6da1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6da5:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6da9:	48 8b 18             	mov    (%rax),%rbx
    6dac:	48 85 db             	test   %rbx,%rbx
    6daf:	0f 84 fb 00 00 00    	je     6eb0 <fwp_data.part.0.constprop.0+0x160>
    6db5:	48 8b 13             	mov    (%rbx),%rdx
    6db8:	48 f7 d2             	not    %rdx
    6dbb:	48 89 10             	mov    %rdx,(%rax)
    6dbe:	48 83 fd 18          	cmp    $0x18,%rbp
    6dc2:	76 1b                	jbe    6ddf <fwp_data.part.0.constprop.0+0x8f>
    6dc4:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6dc8:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6dcc:	31 f6                	xor    %esi,%esi
    6dce:	48 c1 e8 03          	shr    $0x3,%rax
    6dd2:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6dd9:	00 
    6dda:	e8 d1 c6 ff ff       	call   34b0 <memset@plt>
    6ddf:	48 89 e8             	mov    %rbp,%rax
    6de2:	48 03 05 77 6e 06 00 	add    0x66e77(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    6de9:	0f 82 3d 01 00 00    	jb     6f2c <fwp_data.part.0.constprop.0+0x1dc>
    6def:	48 39 05 72 6e 06 00 	cmp    %rax,0x66e72(%rip)        # 6dc68 <fwp_heap+0x1428>
    6df6:	48 89 05 63 6e 06 00 	mov    %rax,0x66e63(%rip)        # 6dc60 <fwp_heap+0x1420>
    6dfd:	73 07                	jae    6e06 <fwp_data.part.0.constprop.0+0xb6>
    6dff:	48 89 05 62 6e 06 00 	mov    %rax,0x66e62(%rip)        # 6dc68 <fwp_heap+0x1428>
    6e06:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e0a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6e0f:	f2 0f 58 05 61 6e 06 	addsd  0x66e61(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    6e16:	00 
    6e17:	f2 0f 11 05 59 6e 06 	movsd  %xmm0,0x66e59(%rip)        # 6dc78 <fwp_heap+0x1438>
    6e1e:	00 
    6e1f:	45 85 ed             	test   %r13d,%r13d
    6e22:	74 33                	je     6e57 <fwp_data.part.0.constprop.0+0x107>
    6e24:	48 8b 05 35 6e 06 00 	mov    0x66e35(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    6e2b:	48 85 c0             	test   %rax,%rax
    6e2e:	0f 88 a4 00 00 00    	js     6ed8 <fwp_data.part.0.constprop.0+0x188>
    6e34:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6e38:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6e3d:	f2 0f 5c 05 a3 76 06 	subsd  0x676a3(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    6e44:	00 
    6e45:	66 0f 2f 05 93 76 06 	comisd 0x67693(%rip),%xmm0        # 6e4e0 <iteration_peak>
    6e4c:	00 
    6e4d:	76 08                	jbe    6e57 <fwp_data.part.0.constprop.0+0x107>
    6e4f:	f2 0f 11 05 89 76 06 	movsd  %xmm0,0x67689(%rip)        # 6e4e0 <iteration_peak>
    6e56:	00 
    6e57:	b8 02 00 00 00       	mov    $0x2,%eax
    6e5c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6e61:	66 0f 6e c8          	movd   %eax,%xmm1
    6e65:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6e69:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6e6d:	49 8b 04 24          	mov    (%r12),%rax
    6e71:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6e75:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6e7a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6e7e:	48 89 d8             	mov    %rbx,%rax
    6e81:	5b                   	pop    %rbx
    6e82:	5d                   	pop    %rbp
    6e83:	41 5c                	pop    %r12
    6e85:	41 5d                	pop    %r13
    6e87:	41 5e                	pop    %r14
    6e89:	c3                   	ret
    6e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e90:	85 c0                	test   %eax,%eax
    6e92:	0f 85 f4 fe ff ff    	jne    6d8c <fwp_data.part.0.constprop.0+0x3c>
    6e98:	31 f6                	xor    %esi,%esi
    6e9a:	bf 18 00 00 00       	mov    $0x18,%edi
    6e9f:	e8 6c f0 ff ff       	call   5f10 <fwp_heap_alloc>
    6ea4:	48 89 c3             	mov    %rax,%rbx
    6ea7:	eb ae                	jmp    6e57 <fwp_data.part.0.constprop.0+0x107>
    6ea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6eb0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6eb4:	48 85 db             	test   %rbx,%rbx
    6eb7:	74 47                	je     6f00 <fwp_data.part.0.constprop.0+0x1b0>
    6eb9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6ebd:	48 29 da             	sub    %rbx,%rdx
    6ec0:	48 39 ea             	cmp    %rbp,%rdx
    6ec3:	72 3b                	jb     6f00 <fwp_data.part.0.constprop.0+0x1b0>
    6ec5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ec9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ecd:	e9 ec fe ff ff       	jmp    6dbe <fwp_data.part.0.constprop.0+0x6e>
    6ed2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed8:	48 89 c2             	mov    %rax,%rdx
    6edb:	83 e0 01             	and    $0x1,%eax
    6ede:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ee2:	48 d1 ea             	shr    $1,%rdx
    6ee5:	48 09 c2             	or     %rax,%rdx
    6ee8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    6eed:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6ef1:	e9 47 ff ff ff       	jmp    6e3d <fwp_data.part.0.constprop.0+0xed>
    6ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6efd:	00 00 00 
    6f00:	31 f6                	xor    %esi,%esi
    6f02:	bf 18 00 00 00       	mov    $0x18,%edi
    6f07:	e8 04 f0 ff ff       	call   5f10 <fwp_heap_alloc>
    6f0c:	48 89 c3             	mov    %rax,%rbx
    6f0f:	e9 0b ff ff ff       	jmp    6e1f <fwp_data.part.0.constprop.0+0xcf>
    6f14:	0f 1f 40 00          	nopl   0x0(%rax)
    6f18:	31 f6                	xor    %esi,%esi
    6f1a:	bf 18 00 00 00       	mov    $0x18,%edi
    6f1f:	e8 ec ef ff ff       	call   5f10 <fwp_heap_alloc>
    6f24:	48 89 c3             	mov    %rax,%rbx
    6f27:	e9 f8 fe ff ff       	jmp    6e24 <fwp_data.part.0.constprop.0+0xd4>
    6f2c:	e8 ff ce ff ff       	call   3e30 <fwp_heap_oom>
    6f31:	0f 1f 40 00          	nopl   0x0(%rax)
    6f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f3c:	00 00 00 00 

0000000000006f40 <fwp_rc_share>:
    6f40:	48 8b 05 d1 6c 06 00 	mov    0x66cd1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    6f47:	48 2b 3d a2 6c 06 00 	sub    0x66ca2(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    6f4e:	48 c1 e0 10          	shl    $0x10,%rax
    6f52:	48 39 c7             	cmp    %rax,%rdi
    6f55:	73 4a                	jae    6fa1 <fwp_rc_share+0x61>
    6f57:	48 89 f8             	mov    %rdi,%rax
    6f5a:	48 c1 e8 10          	shr    $0x10,%rax
    6f5e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6f62:	48 8b 05 cf 6c 06 00 	mov    0x66ccf(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    6f69:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6f6d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6f71:	48 85 d2             	test   %rdx,%rdx
    6f74:	74 2b                	je     6fa1 <fwp_rc_share+0x61>
    6f76:	0f b6 08             	movzbl (%rax),%ecx
    6f79:	80 f9 02             	cmp    $0x2,%cl
    6f7c:	74 2a                	je     6fa8 <fwp_rc_share+0x68>
    6f7e:	80 f9 01             	cmp    $0x1,%cl
    6f81:	75 1e                	jne    6fa1 <fwp_rc_share+0x61>
    6f83:	8b 48 18             	mov    0x18(%rax),%ecx
    6f86:	0f b7 ff             	movzwl %di,%edi
    6f89:	8b 40 1c             	mov    0x1c(%rax),%eax
    6f8c:	48 0f af f9          	imul   %rcx,%rdi
    6f90:	48 c1 ef 20          	shr    $0x20,%rdi
    6f94:	48 39 c7             	cmp    %rax,%rdi
    6f97:	73 08                	jae    6fa1 <fwp_rc_share+0x61>
    6f99:	48 01 fa             	add    %rdi,%rdx
    6f9c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6f9f:	75 0d                	jne    6fae <fwp_rc_share+0x6e>
    6fa1:	c3                   	ret
    6fa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fa8:	66 85 ff             	test   %di,%di
    6fab:	74 ef                	je     6f9c <fwp_rc_share+0x5c>
    6fad:	c3                   	ret
    6fae:	50                   	push   %rax
    6faf:	48 8d 3d ca 9a 00 00 	lea    0x9aca(%rip),%rdi        # 10a80 <_IO_stdin_used+0xa80>
    6fb6:	e8 95 d4 ff ff       	call   4450 <fwp_trap>
    6fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006fc0 <fwp_rc_fresh>:
    6fc0:	48 8b 15 51 6c 06 00 	mov    0x66c51(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    6fc7:	48 89 f8             	mov    %rdi,%rax
    6fca:	48 89 fe             	mov    %rdi,%rsi
    6fcd:	48 2b 05 1c 6c 06 00 	sub    0x66c1c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    6fd4:	48 c1 e2 10          	shl    $0x10,%rdx
    6fd8:	48 39 d0             	cmp    %rdx,%rax
    6fdb:	73 4f                	jae    702c <fwp_rc_fresh+0x6c>
    6fdd:	48 89 c2             	mov    %rax,%rdx
    6fe0:	48 c1 ea 10          	shr    $0x10,%rdx
    6fe4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fe8:	48 8b 15 49 6c 06 00 	mov    0x66c49(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    6fef:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ff3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ff7:	48 85 d2             	test   %rdx,%rdx
    6ffa:	74 30                	je     702c <fwp_rc_fresh+0x6c>
    6ffc:	0f b6 39             	movzbl (%rcx),%edi
    6fff:	40 80 ff 02          	cmp    $0x2,%dil
    7003:	74 2b                	je     7030 <fwp_rc_fresh+0x70>
    7005:	40 80 ff 01          	cmp    $0x1,%dil
    7009:	75 21                	jne    702c <fwp_rc_fresh+0x6c>
    700b:	8b 79 18             	mov    0x18(%rcx),%edi
    700e:	0f b7 c0             	movzwl %ax,%eax
    7011:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7014:	48 0f af c7          	imul   %rdi,%rax
    7018:	48 c1 e8 20          	shr    $0x20,%rax
    701c:	48 39 c8             	cmp    %rcx,%rax
    701f:	73 0b                	jae    702c <fwp_rc_fresh+0x6c>
    7021:	48 01 c2             	add    %rax,%rdx
    7024:	80 3a ff             	cmpb   $0xff,(%rdx)
    7027:	74 17                	je     7040 <fwp_rc_fresh+0x80>
    7029:	c6 02 01             	movb   $0x1,(%rdx)
    702c:	48 89 f0             	mov    %rsi,%rax
    702f:	c3                   	ret
    7030:	66 85 c0             	test   %ax,%ax
    7033:	74 ef                	je     7024 <fwp_rc_fresh+0x64>
    7035:	48 89 f0             	mov    %rsi,%rax
    7038:	c3                   	ret
    7039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7040:	48 83 ec 18          	sub    $0x18,%rsp
    7044:	48 89 d7             	mov    %rdx,%rdi
    7047:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    704c:	48 89 14 24          	mov    %rdx,(%rsp)
    7050:	e8 7b e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7055:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    705a:	48 8b 14 24          	mov    (%rsp),%rdx
    705e:	48 89 f0             	mov    %rsi,%rax
    7061:	c6 02 01             	movb   $0x1,(%rdx)
    7064:	48 83 c4 18          	add    $0x18,%rsp
    7068:	c3                   	ret
    7069:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000007070 <fwp_rc_free_arr>:
    7070:	48 8b 15 a1 6b 06 00 	mov    0x66ba1(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7077:	48 89 f8             	mov    %rdi,%rax
    707a:	48 2b 05 6f 6b 06 00 	sub    0x66b6f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7081:	48 c1 e2 10          	shl    $0x10,%rdx
    7085:	48 39 d0             	cmp    %rdx,%rax
    7088:	73 5b                	jae    70e5 <fwp_rc_free_arr+0x75>
    708a:	48 89 c2             	mov    %rax,%rdx
    708d:	48 c1 ea 10          	shr    $0x10,%rdx
    7091:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7095:	48 8b 15 9c 6b 06 00 	mov    0x66b9c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    709c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    70a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    70a4:	48 85 c9             	test   %rcx,%rcx
    70a7:	74 3c                	je     70e5 <fwp_rc_free_arr+0x75>
    70a9:	0f b6 32             	movzbl (%rdx),%esi
    70ac:	40 80 fe 02          	cmp    $0x2,%sil
    70b0:	74 2e                	je     70e0 <fwp_rc_free_arr+0x70>
    70b2:	40 80 fe 01          	cmp    $0x1,%sil
    70b6:	75 2d                	jne    70e5 <fwp_rc_free_arr+0x75>
    70b8:	8b 72 18             	mov    0x18(%rdx),%esi
    70bb:	0f b7 c0             	movzwl %ax,%eax
    70be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    70c1:	48 0f af c6          	imul   %rsi,%rax
    70c5:	48 c1 e8 20          	shr    $0x20,%rax
    70c9:	48 39 d0             	cmp    %rdx,%rax
    70cc:	73 17                	jae    70e5 <fwp_rc_free_arr+0x75>
    70ce:	48 01 c1             	add    %rax,%rcx
    70d1:	80 39 01             	cmpb   $0x1,(%rcx)
    70d4:	75 0f                	jne    70e5 <fwp_rc_free_arr+0x75>
    70d6:	e9 35 e9 ff ff       	jmp    5a10 <fwp_mem_free>
    70db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    70e0:	66 85 c0             	test   %ax,%ax
    70e3:	74 ec                	je     70d1 <fwp_rc_free_arr+0x61>
    70e5:	c3                   	ret
    70e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70ed:	00 00 00 

00000000000070f0 <fwp_rc_dup>:
    70f0:	f3 0f 1e fa          	endbr64
    70f4:	48 8b 05 1d 6b 06 00 	mov    0x66b1d(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    70fb:	48 2b 3d ee 6a 06 00 	sub    0x66aee(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    7102:	48 c1 e0 10          	shl    $0x10,%rax
    7106:	48 39 c7             	cmp    %rax,%rdi
    7109:	73 60                	jae    716b <fwp_rc_dup+0x7b>
    710b:	48 89 f8             	mov    %rdi,%rax
    710e:	48 c1 e8 10          	shr    $0x10,%rax
    7112:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7116:	48 8b 05 1b 6b 06 00 	mov    0x66b1b(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    711d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7121:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7125:	48 85 c0             	test   %rax,%rax
    7128:	74 41                	je     716b <fwp_rc_dup+0x7b>
    712a:	0f b6 0a             	movzbl (%rdx),%ecx
    712d:	80 f9 02             	cmp    $0x2,%cl
    7130:	74 3e                	je     7170 <fwp_rc_dup+0x80>
    7132:	80 f9 01             	cmp    $0x1,%cl
    7135:	75 34                	jne    716b <fwp_rc_dup+0x7b>
    7137:	8b 4a 18             	mov    0x18(%rdx),%ecx
    713a:	0f b7 ff             	movzwl %di,%edi
    713d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7140:	48 0f af f9          	imul   %rcx,%rdi
    7144:	48 c1 ef 20          	shr    $0x20,%rdi
    7148:	48 39 d7             	cmp    %rdx,%rdi
    714b:	73 1e                	jae    716b <fwp_rc_dup+0x7b>
    714d:	48 01 f8             	add    %rdi,%rax
    7150:	0f b6 10             	movzbl (%rax),%edx
    7153:	84 d2                	test   %dl,%dl
    7155:	74 14                	je     716b <fwp_rc_dup+0x7b>
    7157:	8b 0d ab 73 06 00    	mov    0x673ab(%rip),%ecx        # 6e508 <iteration_active>
    715d:	85 c9                	test   %ecx,%ecx
    715f:	75 1f                	jne    7180 <fwp_rc_dup+0x90>
    7161:	80 fa fd             	cmp    $0xfd,%dl
    7164:	77 2a                	ja     7190 <fwp_rc_dup+0xa0>
    7166:	83 c2 01             	add    $0x1,%edx
    7169:	88 10                	mov    %dl,(%rax)
    716b:	c3                   	ret
    716c:	0f 1f 40 00          	nopl   0x0(%rax)
    7170:	66 85 ff             	test   %di,%di
    7173:	74 db                	je     7150 <fwp_rc_dup+0x60>
    7175:	c3                   	ret
    7176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    717d:	00 00 00 
    7180:	48 83 05 68 73 06 00 	addq   $0x1,0x67368(%rip)        # 6e4f0 <iteration_retains>
    7187:	01 
    7188:	eb d7                	jmp    7161 <fwp_rc_dup+0x71>
    718a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7190:	48 89 c7             	mov    %rax,%rdi
    7193:	e9 18 e5 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    719f:	00 

00000000000071a0 <fwp_owned_entry161>:
    71a0:	f3 0f 1e fa          	endbr64
    71a4:	48 83 ec 38          	sub    $0x38,%rsp
    71a8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    71ad:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    71b4:	00 00 
    71b6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    71bb:	31 c0                	xor    %eax,%eax
    71bd:	48 8b 07             	mov    (%rdi),%rax
    71c0:	48 03 47 10          	add    0x10(%rdi),%rax
    71c4:	0f 80 c2 00 00 00    	jo     728c <fwp_owned_entry161+0xec>
    71ca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    71cf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    71d4:	31 ff                	xor    %edi,%edi
    71d6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    71da:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    71df:	e8 6c fb ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    71e4:	48 8b 15 2d 6a 06 00 	mov    0x66a2d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    71eb:	48 89 c6             	mov    %rax,%rsi
    71ee:	48 2b 05 fb 69 06 00 	sub    0x669fb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    71f5:	48 c1 e2 10          	shl    $0x10,%rdx
    71f9:	48 39 d0             	cmp    %rdx,%rax
    71fc:	73 4f                	jae    724d <fwp_owned_entry161+0xad>
    71fe:	48 89 c2             	mov    %rax,%rdx
    7201:	48 c1 ea 10          	shr    $0x10,%rdx
    7205:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7209:	48 8b 15 28 6a 06 00 	mov    0x66a28(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7210:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7214:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7218:	48 85 d2             	test   %rdx,%rdx
    721b:	74 30                	je     724d <fwp_owned_entry161+0xad>
    721d:	0f b6 39             	movzbl (%rcx),%edi
    7220:	40 80 ff 02          	cmp    $0x2,%dil
    7224:	74 42                	je     7268 <fwp_owned_entry161+0xc8>
    7226:	40 80 ff 01          	cmp    $0x1,%dil
    722a:	75 21                	jne    724d <fwp_owned_entry161+0xad>
    722c:	8b 79 18             	mov    0x18(%rcx),%edi
    722f:	0f b7 c0             	movzwl %ax,%eax
    7232:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7235:	48 0f af c7          	imul   %rdi,%rax
    7239:	48 c1 e8 20          	shr    $0x20,%rax
    723d:	48 39 c8             	cmp    %rcx,%rax
    7240:	73 0b                	jae    724d <fwp_owned_entry161+0xad>
    7242:	48 01 c2             	add    %rax,%rdx
    7245:	80 3a ff             	cmpb   $0xff,(%rdx)
    7248:	74 26                	je     7270 <fwp_owned_entry161+0xd0>
    724a:	c6 02 01             	movb   $0x1,(%rdx)
    724d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7252:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7259:	00 00 
    725b:	75 34                	jne    7291 <fwp_owned_entry161+0xf1>
    725d:	48 89 f0             	mov    %rsi,%rax
    7260:	48 83 c4 38          	add    $0x38,%rsp
    7264:	c3                   	ret
    7265:	0f 1f 00             	nopl   (%rax)
    7268:	66 85 c0             	test   %ax,%ax
    726b:	75 e0                	jne    724d <fwp_owned_entry161+0xad>
    726d:	eb d6                	jmp    7245 <fwp_owned_entry161+0xa5>
    726f:	90                   	nop
    7270:	48 89 d7             	mov    %rdx,%rdi
    7273:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    7278:	48 89 14 24          	mov    %rdx,(%rsp)
    727c:	e8 4f e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7281:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7286:	48 8b 14 24          	mov    (%rsp),%rdx
    728a:	eb be                	jmp    724a <fwp_owned_entry161+0xaa>
    728c:	e8 6f c4 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7291:	e8 ba c1 ff ff       	call   3450 <__stack_chk_fail@plt>
    7296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    729d:	00 00 00 

00000000000072a0 <e161>:
    72a0:	f3 0f 1e fa          	endbr64
    72a4:	53                   	push   %rbx
    72a5:	48 83 ec 30          	sub    $0x30,%rsp
    72a9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    72ae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    72b5:	00 00 
    72b7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    72bc:	31 c0                	xor    %eax,%eax
    72be:	48 8b 07             	mov    (%rdi),%rax
    72c1:	48 03 47 10          	add    0x10(%rdi),%rax
    72c5:	0f 80 c9 00 00 00    	jo     7394 <e161+0xf4>
    72cb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    72d0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    72d5:	31 ff                	xor    %edi,%edi
    72d7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    72db:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    72e0:	e8 6b fa ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    72e5:	48 8b 15 2c 69 06 00 	mov    0x6692c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    72ec:	48 89 c3             	mov    %rax,%rbx
    72ef:	48 2b 05 fa 68 06 00 	sub    0x668fa(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    72f6:	48 c1 e2 10          	shl    $0x10,%rdx
    72fa:	48 39 d0             	cmp    %rdx,%rax
    72fd:	73 4f                	jae    734e <e161+0xae>
    72ff:	48 89 c2             	mov    %rax,%rdx
    7302:	48 c1 ea 10          	shr    $0x10,%rdx
    7306:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    730a:	48 8b 15 27 69 06 00 	mov    0x66927(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7311:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7315:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7319:	48 85 d2             	test   %rdx,%rdx
    731c:	74 30                	je     734e <e161+0xae>
    731e:	0f b6 31             	movzbl (%rcx),%esi
    7321:	40 80 fe 02          	cmp    $0x2,%sil
    7325:	74 49                	je     7370 <e161+0xd0>
    7327:	40 80 fe 01          	cmp    $0x1,%sil
    732b:	75 21                	jne    734e <e161+0xae>
    732d:	8b 71 18             	mov    0x18(%rcx),%esi
    7330:	0f b7 c0             	movzwl %ax,%eax
    7333:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7336:	48 0f af c6          	imul   %rsi,%rax
    733a:	48 c1 e8 20          	shr    $0x20,%rax
    733e:	48 39 c8             	cmp    %rcx,%rax
    7341:	73 0b                	jae    734e <e161+0xae>
    7343:	48 01 c2             	add    %rax,%rdx
    7346:	80 3a ff             	cmpb   $0xff,(%rdx)
    7349:	74 35                	je     7380 <e161+0xe0>
    734b:	c6 02 01             	movb   $0x1,(%rdx)
    734e:	48 89 df             	mov    %rbx,%rdi
    7351:	e8 ea fb ff ff       	call   6f40 <fwp_rc_share>
    7356:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    735b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7362:	00 00 
    7364:	75 33                	jne    7399 <e161+0xf9>
    7366:	48 83 c4 30          	add    $0x30,%rsp
    736a:	48 89 d8             	mov    %rbx,%rax
    736d:	5b                   	pop    %rbx
    736e:	c3                   	ret
    736f:	90                   	nop
    7370:	66 85 c0             	test   %ax,%ax
    7373:	75 d9                	jne    734e <e161+0xae>
    7375:	eb cf                	jmp    7346 <e161+0xa6>
    7377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    737e:	00 00 
    7380:	48 89 d7             	mov    %rdx,%rdi
    7383:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7388:	e8 43 e4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    738d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7392:	eb b7                	jmp    734b <e161+0xab>
    7394:	e8 67 c3 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7399:	e8 b2 c0 ff ff       	call   3450 <__stack_chk_fail@plt>
    739e:	66 90                	xchg   %ax,%ax

00000000000073a0 <fwp_drop0>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	48 8b 15 6d 68 06 00 	mov    0x6686d(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    73ab:	48 89 f8             	mov    %rdi,%rax
    73ae:	48 2b 05 3b 68 06 00 	sub    0x6683b(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    73b5:	48 c1 e2 10          	shl    $0x10,%rdx
    73b9:	48 39 d0             	cmp    %rdx,%rax
    73bc:	0f 83 be 00 00 00    	jae    7480 <fwp_drop0+0xe0>
    73c2:	48 83 ec 18          	sub    $0x18,%rsp
    73c6:	4c 8d 05 73 54 06 00 	lea    0x65473(%rip),%r8        # 6c840 <fwp_heap>
    73cd:	48 89 c2             	mov    %rax,%rdx
    73d0:	48 c1 ea 10          	shr    $0x10,%rdx
    73d4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    73d8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    73df:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    73e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    73e7:	48 85 d2             	test   %rdx,%rdx
    73ea:	74 3c                	je     7428 <fwp_drop0+0x88>
    73ec:	0f b6 31             	movzbl (%rcx),%esi
    73ef:	40 80 fe 02          	cmp    $0x2,%sil
    73f3:	74 3b                	je     7430 <fwp_drop0+0x90>
    73f5:	40 80 fe 01          	cmp    $0x1,%sil
    73f9:	75 2d                	jne    7428 <fwp_drop0+0x88>
    73fb:	8b 71 18             	mov    0x18(%rcx),%esi
    73fe:	0f b7 c0             	movzwl %ax,%eax
    7401:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7404:	48 0f af c6          	imul   %rsi,%rax
    7408:	48 c1 e8 20          	shr    $0x20,%rax
    740c:	48 39 c8             	cmp    %rcx,%rax
    740f:	73 17                	jae    7428 <fwp_drop0+0x88>
    7411:	48 01 c2             	add    %rax,%rdx
    7414:	0f b6 02             	movzbl (%rdx),%eax
    7417:	84 c0                	test   %al,%al
    7419:	74 0d                	je     7428 <fwp_drop0+0x88>
    741b:	3c 01                	cmp    $0x1,%al
    741d:	74 21                	je     7440 <fwp_drop0+0xa0>
    741f:	3c ff                	cmp    $0xff,%al
    7421:	74 65                	je     7488 <fwp_drop0+0xe8>
    7423:	83 e8 01             	sub    $0x1,%eax
    7426:	88 02                	mov    %al,(%rdx)
    7428:	48 83 c4 18          	add    $0x18,%rsp
    742c:	c3                   	ret
    742d:	0f 1f 00             	nopl   (%rax)
    7430:	66 85 c0             	test   %ax,%ax
    7433:	74 df                	je     7414 <fwp_drop0+0x74>
    7435:	48 83 c4 18          	add    $0x18,%rsp
    7439:	c3                   	ret
    743a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7440:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    7444:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7449:	e8 22 fc ff ff       	call   7070 <fwp_rc_free_arr>
    744e:	4c 8d 05 eb 53 06 00 	lea    0x653eb(%rip),%r8        # 6c840 <fwp_heap>
    7455:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    745a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7461:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7468:	48 c1 e2 10          	shl    $0x10,%rdx
    746c:	48 39 d0             	cmp    %rdx,%rax
    746f:	73 b7                	jae    7428 <fwp_drop0+0x88>
    7471:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7476:	e9 52 ff ff ff       	jmp    73cd <fwp_drop0+0x2d>
    747b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7480:	c3                   	ret
    7481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7488:	48 89 d0             	mov    %rdx,%rax
    748b:	48 c1 e8 11          	shr    $0x11,%rax
    748f:	48 31 d0             	xor    %rdx,%rax
    7492:	48 89 c1             	mov    %rax,%rcx
    7495:	48 c1 e9 09          	shr    $0x9,%rcx
    7499:	48 31 c8             	xor    %rcx,%rax
    749c:	0f b6 c8             	movzbl %al,%ecx
    749f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    74a6:	00 
    74a7:	48 85 c0             	test   %rax,%rax
    74aa:	75 1d                	jne    74c9 <fwp_drop0+0x129>
    74ac:	eb 56                	jmp    7504 <fwp_drop0+0x164>
    74ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 
    74c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    74c4:	48 85 c0             	test   %rax,%rax
    74c7:	74 3b                	je     7504 <fwp_drop0+0x164>
    74c9:	48 89 c1             	mov    %rax,%rcx
    74cc:	48 39 10             	cmp    %rdx,(%rax)
    74cf:	75 ef                	jne    74c0 <fwp_drop0+0x120>
    74d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    74d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    74dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    74e4:	0f 85 3e ff ff ff    	jne    7428 <fwp_drop0+0x88>
    74ea:	48 89 d7             	mov    %rdx,%rdi
    74ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    74f2:	e8 d9 e2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    74f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    74fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    74ff:	e9 24 ff ff ff       	jmp    7428 <fwp_drop0+0x88>
    7504:	48 8d 3d d5 94 00 00 	lea    0x94d5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    750b:	e8 40 cf ff ff       	call   4450 <fwp_trap>

0000000000007510 <fwp_arg_drop12>:
    7510:	f3 0f 1e fa          	endbr64
    7514:	85 f6                	test   %esi,%esi
    7516:	75 04                	jne    751c <fwp_arg_drop12+0xc>
    7518:	85 d2                	test   %edx,%edx
    751a:	75 04                	jne    7520 <fwp_arg_drop12+0x10>
    751c:	c3                   	ret
    751d:	0f 1f 00             	nopl   (%rax)
    7520:	48 8b 3f             	mov    (%rdi),%rdi
    7523:	e9 78 fe ff ff       	jmp    73a0 <fwp_drop0>
    7528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    752f:	00 

0000000000007530 <fwp_drop1>:
    7530:	f3 0f 1e fa          	endbr64
    7534:	48 8b 15 dd 66 06 00 	mov    0x666dd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    753b:	48 89 f8             	mov    %rdi,%rax
    753e:	48 2b 05 ab 66 06 00 	sub    0x666ab(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7545:	48 c1 e2 10          	shl    $0x10,%rdx
    7549:	48 39 d0             	cmp    %rdx,%rax
    754c:	0f 83 be 00 00 00    	jae    7610 <fwp_drop1+0xe0>
    7552:	48 83 ec 18          	sub    $0x18,%rsp
    7556:	4c 8d 05 e3 52 06 00 	lea    0x652e3(%rip),%r8        # 6c840 <fwp_heap>
    755d:	48 89 c2             	mov    %rax,%rdx
    7560:	48 c1 ea 10          	shr    $0x10,%rdx
    7564:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7568:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    756f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7573:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7577:	48 85 d2             	test   %rdx,%rdx
    757a:	74 3c                	je     75b8 <fwp_drop1+0x88>
    757c:	0f b6 31             	movzbl (%rcx),%esi
    757f:	40 80 fe 02          	cmp    $0x2,%sil
    7583:	74 3b                	je     75c0 <fwp_drop1+0x90>
    7585:	40 80 fe 01          	cmp    $0x1,%sil
    7589:	75 2d                	jne    75b8 <fwp_drop1+0x88>
    758b:	8b 71 18             	mov    0x18(%rcx),%esi
    758e:	0f b7 c0             	movzwl %ax,%eax
    7591:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7594:	48 0f af c6          	imul   %rsi,%rax
    7598:	48 c1 e8 20          	shr    $0x20,%rax
    759c:	48 39 c8             	cmp    %rcx,%rax
    759f:	73 17                	jae    75b8 <fwp_drop1+0x88>
    75a1:	48 01 c2             	add    %rax,%rdx
    75a4:	0f b6 02             	movzbl (%rdx),%eax
    75a7:	84 c0                	test   %al,%al
    75a9:	74 0d                	je     75b8 <fwp_drop1+0x88>
    75ab:	3c 01                	cmp    $0x1,%al
    75ad:	74 21                	je     75d0 <fwp_drop1+0xa0>
    75af:	3c ff                	cmp    $0xff,%al
    75b1:	74 65                	je     7618 <fwp_drop1+0xe8>
    75b3:	83 e8 01             	sub    $0x1,%eax
    75b6:	88 02                	mov    %al,(%rdx)
    75b8:	48 83 c4 18          	add    $0x18,%rsp
    75bc:	c3                   	ret
    75bd:	0f 1f 00             	nopl   (%rax)
    75c0:	66 85 c0             	test   %ax,%ax
    75c3:	74 df                	je     75a4 <fwp_drop1+0x74>
    75c5:	48 83 c4 18          	add    $0x18,%rsp
    75c9:	c3                   	ret
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    75d4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    75d9:	e8 92 fa ff ff       	call   7070 <fwp_rc_free_arr>
    75de:	4c 8d 05 5b 52 06 00 	lea    0x6525b(%rip),%r8        # 6c840 <fwp_heap>
    75e5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    75ea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    75f1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    75f8:	48 c1 e2 10          	shl    $0x10,%rdx
    75fc:	48 39 d0             	cmp    %rdx,%rax
    75ff:	73 b7                	jae    75b8 <fwp_drop1+0x88>
    7601:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7606:	e9 52 ff ff ff       	jmp    755d <fwp_drop1+0x2d>
    760b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7610:	c3                   	ret
    7611:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7618:	48 89 d0             	mov    %rdx,%rax
    761b:	48 c1 e8 11          	shr    $0x11,%rax
    761f:	48 31 d0             	xor    %rdx,%rax
    7622:	48 89 c1             	mov    %rax,%rcx
    7625:	48 c1 e9 09          	shr    $0x9,%rcx
    7629:	48 31 c8             	xor    %rcx,%rax
    762c:	0f b6 c8             	movzbl %al,%ecx
    762f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7636:	00 
    7637:	48 85 c0             	test   %rax,%rax
    763a:	75 0d                	jne    7649 <fwp_drop1+0x119>
    763c:	eb 46                	jmp    7684 <fwp_drop1+0x154>
    763e:	66 90                	xchg   %ax,%ax
    7640:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7644:	48 85 c0             	test   %rax,%rax
    7647:	74 3b                	je     7684 <fwp_drop1+0x154>
    7649:	48 89 c1             	mov    %rax,%rcx
    764c:	48 39 10             	cmp    %rdx,(%rax)
    764f:	75 ef                	jne    7640 <fwp_drop1+0x110>
    7651:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7655:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7659:	48 89 48 08          	mov    %rcx,0x8(%rax)
    765d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7664:	0f 85 4e ff ff ff    	jne    75b8 <fwp_drop1+0x88>
    766a:	48 89 d7             	mov    %rdx,%rdi
    766d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7672:	e8 59 e1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7677:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    767c:	c6 02 fe             	movb   $0xfe,(%rdx)
    767f:	e9 34 ff ff ff       	jmp    75b8 <fwp_drop1+0x88>
    7684:	48 8d 3d 55 93 00 00 	lea    0x9355(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    768b:	e8 c0 cd ff ff       	call   4450 <fwp_trap>

0000000000007690 <fwp_closure_drop>:
    7690:	48 8b 15 81 65 06 00 	mov    0x66581(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7697:	48 89 f8             	mov    %rdi,%rax
    769a:	48 2b 05 4f 65 06 00 	sub    0x6654f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    76a1:	48 c1 e2 10          	shl    $0x10,%rdx
    76a5:	48 39 d0             	cmp    %rdx,%rax
    76a8:	73 6b                	jae    7715 <fwp_closure_drop+0x85>
    76aa:	48 89 c2             	mov    %rax,%rdx
    76ad:	48 c1 ea 10          	shr    $0x10,%rdx
    76b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76b5:	48 8b 15 7c 65 06 00 	mov    0x6657c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    76bc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    76c0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76c4:	48 85 d2             	test   %rdx,%rdx
    76c7:	74 4c                	je     7715 <fwp_closure_drop+0x85>
    76c9:	0f b6 31             	movzbl (%rcx),%esi
    76cc:	40 80 fe 02          	cmp    $0x2,%sil
    76d0:	74 3e                	je     7710 <fwp_closure_drop+0x80>
    76d2:	40 80 fe 01          	cmp    $0x1,%sil
    76d6:	75 3d                	jne    7715 <fwp_closure_drop+0x85>
    76d8:	8b 71 18             	mov    0x18(%rcx),%esi
    76db:	0f b7 c0             	movzwl %ax,%eax
    76de:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76e1:	48 0f af c6          	imul   %rsi,%rax
    76e5:	48 c1 e8 20          	shr    $0x20,%rax
    76e9:	48 39 c8             	cmp    %rcx,%rax
    76ec:	73 27                	jae    7715 <fwp_closure_drop+0x85>
    76ee:	48 01 c2             	add    %rax,%rdx
    76f1:	0f b6 02             	movzbl (%rdx),%eax
    76f4:	84 c0                	test   %al,%al
    76f6:	74 1d                	je     7715 <fwp_closure_drop+0x85>
    76f8:	3c 01                	cmp    $0x1,%al
    76fa:	74 24                	je     7720 <fwp_closure_drop+0x90>
    76fc:	3c ff                	cmp    $0xff,%al
    76fe:	74 48                	je     7748 <fwp_closure_drop+0xb8>
    7700:	83 e8 01             	sub    $0x1,%eax
    7703:	88 02                	mov    %al,(%rdx)
    7705:	c3                   	ret
    7706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    770d:	00 00 00 
    7710:	66 85 c0             	test   %ax,%ax
    7713:	74 dc                	je     76f1 <fwp_closure_drop+0x61>
    7715:	c3                   	ret
    7716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    771d:	00 00 00 
    7720:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7727:	ff ff 
    7729:	48 85 c0             	test   %rax,%rax
    772c:	74 12                	je     7740 <fwp_closure_drop+0xb0>
    772e:	48 89 fe             	mov    %rdi,%rsi
    7731:	48 89 c7             	mov    %rax,%rdi
    7734:	e9 77 cd ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7740:	e9 1b cf ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7745:	0f 1f 00             	nopl   (%rax)
    7748:	48 89 d0             	mov    %rdx,%rax
    774b:	48 8d 35 ee 50 06 00 	lea    0x650ee(%rip),%rsi        # 6c840 <fwp_heap>
    7752:	48 83 ec 18          	sub    $0x18,%rsp
    7756:	48 c1 e8 11          	shr    $0x11,%rax
    775a:	48 31 d0             	xor    %rdx,%rax
    775d:	48 89 c1             	mov    %rax,%rcx
    7760:	48 c1 e9 09          	shr    $0x9,%rcx
    7764:	48 31 c8             	xor    %rcx,%rax
    7767:	0f b6 c8             	movzbl %al,%ecx
    776a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7771:	00 
    7772:	48 85 c0             	test   %rax,%rax
    7775:	75 12                	jne    7789 <fwp_closure_drop+0xf9>
    7777:	eb 49                	jmp    77c2 <fwp_closure_drop+0x132>
    7779:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7780:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7784:	48 85 c0             	test   %rax,%rax
    7787:	74 39                	je     77c2 <fwp_closure_drop+0x132>
    7789:	48 89 c1             	mov    %rax,%rcx
    778c:	48 39 10             	cmp    %rdx,(%rax)
    778f:	75 ef                	jne    7780 <fwp_closure_drop+0xf0>
    7791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7795:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7799:	48 89 48 08          	mov    %rcx,0x8(%rax)
    779d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    77a4:	74 05                	je     77ab <fwp_closure_drop+0x11b>
    77a6:	48 83 c4 18          	add    $0x18,%rsp
    77aa:	c3                   	ret
    77ab:	48 89 d7             	mov    %rdx,%rdi
    77ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77b3:	e8 18 e0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    77b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    77c0:	eb e4                	jmp    77a6 <fwp_closure_drop+0x116>
    77c2:	48 8d 3d 17 92 00 00 	lea    0x9217(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    77c9:	e8 82 cc ff ff       	call   4450 <fwp_trap>
    77ce:	66 90                	xchg   %ax,%ax

00000000000077d0 <fwp_owned_tape_release>:
    77d0:	48 85 ff             	test   %rdi,%rdi
    77d3:	0f 84 f7 00 00 00    	je     78d0 <fwp_owned_tape_release+0x100>
    77d9:	41 54                	push   %r12
    77db:	55                   	push   %rbp
    77dc:	53                   	push   %rbx
    77dd:	48 8b 07             	mov    (%rdi),%rax
    77e0:	48 85 c0             	test   %rax,%rax
    77e3:	74 08                	je     77ed <fwp_owned_tape_release+0x1d>
    77e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    77e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    77ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    77f1:	48 85 d2             	test   %rdx,%rdx
    77f4:	74 03                	je     77f9 <fwp_owned_tape_release+0x29>
    77f6:	48 89 02             	mov    %rax,(%rdx)
    77f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    77fd:	48 89 fb             	mov    %rdi,%rbx
    7800:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	0f 84 89 00 00 00    	je     7896 <fwp_owned_tape_release+0xc6>
    780d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7811:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7815:	7e 47                	jle    785e <fwp_owned_tape_release+0x8e>
    7817:	31 ed                	xor    %ebp,%ebp
    7819:	eb 0d                	jmp    7828 <fwp_owned_tape_release+0x58>
    781b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7820:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7824:	48 8b 40 68          	mov    0x68(%rax),%rax
    7828:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    782c:	49 89 ec             	mov    %rbp,%r12
    782f:	48 83 c5 01          	add    $0x1,%rbp
    7833:	49 c1 e4 04          	shl    $0x4,%r12
    7837:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    783b:	ff d0                	call   *%rax
    783d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7841:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7846:	48 8b 43 10          	mov    0x10(%rbx),%rax
    784a:	ff 50 68             	call   *0x68(%rax)
    784d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7851:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7855:	48 39 e8             	cmp    %rbp,%rax
    7858:	7f c6                	jg     7820 <fwp_owned_tape_release+0x50>
    785a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    785e:	31 ed                	xor    %ebp,%ebp
    7860:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7865:	7e 28                	jle    788f <fwp_owned_tape_release+0xbf>
    7867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    786e:	00 00 
    7870:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7874:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7878:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    787c:	74 07                	je     7885 <fwp_owned_tape_release+0xb5>
    787e:	ff 52 68             	call   *0x68(%rdx)
    7881:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7885:	48 83 c5 01          	add    $0x1,%rbp
    7889:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    788d:	7f e1                	jg     7870 <fwp_owned_tape_release+0xa0>
    788f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7893:	ff 52 68             	call   *0x68(%rdx)
    7896:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    789a:	e8 f1 fd ff ff       	call   7690 <fwp_closure_drop>
    789f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    78a3:	e8 e8 fd ff ff       	call   7690 <fwp_closure_drop>
    78a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    78ac:	e8 df fd ff ff       	call   7690 <fwp_closure_drop>
    78b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    78b5:	e8 56 e1 ff ff       	call   5a10 <fwp_mem_free>
    78ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    78be:	e8 4d e1 ff ff       	call   5a10 <fwp_mem_free>
    78c3:	48 89 df             	mov    %rbx,%rdi
    78c6:	5b                   	pop    %rbx
    78c7:	5d                   	pop    %rbp
    78c8:	41 5c                	pop    %r12
    78ca:	e9 41 e1 ff ff       	jmp    5a10 <fwp_mem_free>
    78cf:	90                   	nop
    78d0:	c3                   	ret
    78d1:	0f 1f 40 00          	nopl   0x0(%rax)
    78d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    78dc:	00 00 00 00 

00000000000078e0 <fwp_tape_finish>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	41 55                	push   %r13
    78e6:	41 54                	push   %r12
    78e8:	55                   	push   %rbp
    78e9:	53                   	push   %rbx
    78ea:	48 83 ec 48          	sub    $0x48,%rsp
    78ee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    78f5:	00 00 
    78f7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    78fc:	48 8d 3d bd c7 01 00 	lea    0x1c7bd(%rip),%rdi        # 240c0 <fwp_tape_workspace>
    7903:	e8 38 d8 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7908:	48 83 3d f8 c7 01 00 	cmpq   $0x0,0x1c7f8(%rip)        # 24108 <fwp_ntapes>
    790f:	00 
    7910:	48 c7 05 8d c7 01 00 	movq   $0x0,0x1c78d(%rip)        # 240a8 <fwp_tape_cached_bytes>
    7917:	00 00 00 00 
    791b:	7e 79                	jle    7996 <fwp_tape_finish+0xb6>
    791d:	45 31 e4             	xor    %r12d,%r12d
    7920:	31 ed                	xor    %ebp,%ebp
    7922:	0f 1f 00             	nopl   (%rax)
    7925:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    792c:	00 00 00 00 
    7930:	48 8b 1d d9 c7 01 00 	mov    0x1c7d9(%rip),%rbx        # 24110 <fwp_tapes>
    7937:	48 83 c5 01          	add    $0x1,%rbp
    793b:	4c 01 e3             	add    %r12,%rbx
    793e:	49 83 c4 68          	add    $0x68,%r12
    7942:	48 89 df             	mov    %rbx,%rdi
    7945:	e8 46 c3 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    794a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    794f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7954:	48 89 e7             	mov    %rsp,%rdi
    7957:	48 8b 43 40          	mov    0x40(%rbx),%rax
    795b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    795f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7964:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7969:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    796e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7972:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7977:	e8 c4 d7 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    797c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7980:	e8 4b fe ff ff       	call   77d0 <fwp_owned_tape_release>
    7985:	48 39 2d 7c c7 01 00 	cmp    %rbp,0x1c77c(%rip)        # 24108 <fwp_ntapes>
    798c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7993:	00 
    7994:	7f 9a                	jg     7930 <fwp_tape_finish+0x50>
    7996:	48 8b 3d 73 c7 01 00 	mov    0x1c773(%rip),%rdi        # 24110 <fwp_tapes>
    799d:	48 85 ff             	test   %rdi,%rdi
    79a0:	74 05                	je     79a7 <fwp_tape_finish+0xc7>
    79a2:	e8 29 d7 ff ff       	call   50d0 <ad_raw_free.part.0>
    79a7:	48 c7 05 5e c7 01 00 	movq   $0x0,0x1c75e(%rip)        # 24110 <fwp_tapes>
    79ae:	00 00 00 00 
    79b2:	48 c7 05 43 c7 01 00 	movq   $0x0,0x1c743(%rip)        # 24100 <fwp_tapes_cap>
    79b9:	00 00 00 00 
    79bd:	48 c7 05 40 c7 01 00 	movq   $0x0,0x1c740(%rip)        # 24108 <fwp_ntapes>
    79c4:	00 00 00 00 
    79c8:	48 c7 05 25 c7 01 00 	movq   $0x0,0x1c725(%rip)        # 240f8 <fwp_tape_next_slot>
    79cf:	00 00 00 00 
    79d3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    79d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    79df:	00 00 
    79e1:	75 0b                	jne    79ee <fwp_tape_finish+0x10e>
    79e3:	48 83 c4 48          	add    $0x48,%rsp
    79e7:	5b                   	pop    %rbx
    79e8:	5d                   	pop    %rbp
    79e9:	41 5c                	pop    %r12
    79eb:	41 5d                	pop    %r13
    79ed:	c3                   	ret
    79ee:	e8 5d ba ff ff       	call   3450 <__stack_chk_fail@plt>
    79f3:	66 90                	xchg   %ax,%ax
    79f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    79fc:	00 00 00 00 

0000000000007a00 <fwp_tape_scope_release>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	41 55                	push   %r13
    7a06:	41 54                	push   %r12
    7a08:	55                   	push   %rbp
    7a09:	53                   	push   %rbx
    7a0a:	48 83 ec 48          	sub    $0x48,%rsp
    7a0e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7a15:	00 00 
    7a17:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    7a1c:	48 63 07             	movslq (%rdi),%rax
    7a1f:	85 c0                	test   %eax,%eax
    7a21:	0f 88 e8 00 00 00    	js     7b0f <fwp_tape_scope_release+0x10f>
    7a27:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    7a2e:	ec c4 4e 
    7a31:	48 89 fb             	mov    %rdi,%rbx
    7a34:	48 89 e5             	mov    %rsp,%rbp
    7a37:	eb 1f                	jmp    7a58 <fwp_tape_scope_release+0x58>
    7a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a40:	e8 fb d6 ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7a45:	4c 89 ef             	mov    %r13,%rdi
    7a48:	e8 83 fd ff ff       	call   77d0 <fwp_owned_tape_release>
    7a4d:	48 63 03             	movslq (%rbx),%rax
    7a50:	85 c0                	test   %eax,%eax
    7a52:	0f 88 b7 00 00 00    	js     7b0f <fwp_tape_scope_release+0x10f>
    7a58:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7a5c:	48 8b 35 ad c6 01 00 	mov    0x1c6ad(%rip),%rsi        # 24110 <fwp_tapes>
    7a63:	4c 01 c6             	add    %r8,%rsi
    7a66:	48 89 f7             	mov    %rsi,%rdi
    7a69:	e8 22 c2 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    7a6e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7a73:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7a78:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7a7f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7a83:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7a87:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7a8e:	00 
    7a8f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7a94:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7a99:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    7a9d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7aa2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7aa6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7aab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7ab2:	00 
    7ab3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    7aba:	00 
    7abb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7ac2:	00 
    7ac3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7ac7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    7acb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    7acf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7ad3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7ad9:	77 18                	ja     7af3 <fwp_tape_scope_release+0xf3>
    7adb:	49 c1 f8 03          	sar    $0x3,%r8
    7adf:	4d 0f af c4          	imul   %r12,%r8
    7ae3:	4c 3b 05 0e c6 01 00 	cmp    0x1c60e(%rip),%r8        # 240f8 <fwp_tape_next_slot>
    7aea:	7d 07                	jge    7af3 <fwp_tape_scope_release+0xf3>
    7aec:	4c 89 05 05 c6 01 00 	mov    %r8,0x1c605(%rip)        # 240f8 <fwp_tape_next_slot>
    7af3:	48 89 ef             	mov    %rbp,%rdi
    7af6:	4d 85 ed             	test   %r13,%r13
    7af9:	0f 85 41 ff ff ff    	jne    7a40 <fwp_tape_scope_release+0x40>
    7aff:	e8 5c d7 ff ff       	call   5260 <fwp_tape_buffers_release>
    7b04:	48 63 03             	movslq (%rbx),%rax
    7b07:	85 c0                	test   %eax,%eax
    7b09:	0f 89 49 ff ff ff    	jns    7a58 <fwp_tape_scope_release+0x58>
    7b0f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7b14:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7b1b:	00 00 
    7b1d:	75 0b                	jne    7b2a <fwp_tape_scope_release+0x12a>
    7b1f:	48 83 c4 48          	add    $0x48,%rsp
    7b23:	5b                   	pop    %rbx
    7b24:	5d                   	pop    %rbp
    7b25:	41 5c                	pop    %r12
    7b27:	41 5d                	pop    %r13
    7b29:	c3                   	ret
    7b2a:	e8 21 b9 ff ff       	call   3450 <__stack_chk_fail@plt>
    7b2f:	90                   	nop

0000000000007b30 <fwp_task_dispose>:
    7b30:	53                   	push   %rbx
    7b31:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7b35:	0f 84 0b bc ff ff    	je     3746 <fwp_task_dispose.cold>
    7b3b:	48 89 fb             	mov    %rdi,%rbx
    7b3e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7b43:	0f 85 fd bb ff ff    	jne    3746 <fwp_task_dispose.cold>
    7b49:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    7b4d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7b54:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    7b5b:	00 
    7b5c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7b60:	48 85 ff             	test   %rdi,%rdi
    7b63:	74 07                	je     7b6c <fwp_task_dispose+0x3c>
    7b65:	48 85 c0             	test   %rax,%rax
    7b68:	74 02                	je     7b6c <fwp_task_dispose+0x3c>
    7b6a:	ff d0                	call   *%rax
    7b6c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7b73:	e8 98 de ff ff       	call   5a10 <fwp_mem_free>
    7b78:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    7b7f:	00 00 00 00 
    7b83:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7b87:	74 6f                	je     7bf8 <fwp_task_dispose+0xc8>
    7b89:	48 8b 15 88 60 06 00 	mov    0x66088(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7b90:	48 89 d8             	mov    %rbx,%rax
    7b93:	48 2b 05 56 60 06 00 	sub    0x66056(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7b9a:	48 c1 e2 10          	shl    $0x10,%rdx
    7b9e:	48 39 d0             	cmp    %rdx,%rax
    7ba1:	73 4c                	jae    7bef <fwp_task_dispose+0xbf>
    7ba3:	48 89 c2             	mov    %rax,%rdx
    7ba6:	48 c1 ea 10          	shr    $0x10,%rdx
    7baa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7bae:	48 8b 15 83 60 06 00 	mov    0x66083(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    7bb5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bb9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7bbd:	48 85 c9             	test   %rcx,%rcx
    7bc0:	74 2d                	je     7bef <fwp_task_dispose+0xbf>
    7bc2:	0f b6 32             	movzbl (%rdx),%esi
    7bc5:	40 80 fe 02          	cmp    $0x2,%sil
    7bc9:	74 3d                	je     7c08 <fwp_task_dispose+0xd8>
    7bcb:	40 80 fe 01          	cmp    $0x1,%sil
    7bcf:	75 1e                	jne    7bef <fwp_task_dispose+0xbf>
    7bd1:	8b 72 18             	mov    0x18(%rdx),%esi
    7bd4:	0f b7 c0             	movzwl %ax,%eax
    7bd7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bda:	48 0f af c6          	imul   %rsi,%rax
    7bde:	48 c1 e8 20          	shr    $0x20,%rax
    7be2:	48 39 d0             	cmp    %rdx,%rax
    7be5:	73 08                	jae    7bef <fwp_task_dispose+0xbf>
    7be7:	48 01 c1             	add    %rax,%rcx
    7bea:	80 39 01             	cmpb   $0x1,(%rcx)
    7bed:	74 09                	je     7bf8 <fwp_task_dispose+0xc8>
    7bef:	5b                   	pop    %rbx
    7bf0:	c3                   	ret
    7bf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bf8:	48 89 df             	mov    %rbx,%rdi
    7bfb:	5b                   	pop    %rbx
    7bfc:	e9 0f de ff ff       	jmp    5a10 <fwp_mem_free>
    7c01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c08:	66 85 c0             	test   %ax,%ax
    7c0b:	74 dd                	je     7bea <fwp_task_dispose+0xba>
    7c0d:	5b                   	pop    %rbx
    7c0e:	c3                   	ret
    7c0f:	90                   	nop

0000000000007c10 <fwp_free_zombie>:
    7c10:	48 8b 15 f9 4b 06 00 	mov    0x64bf9(%rip),%rdx        # 6c810 <fwp_zombie>
    7c17:	48 85 d2             	test   %rdx,%rdx
    7c1a:	0f 84 98 00 00 00    	je     7cb8 <fwp_free_zombie+0xa8>
    7c20:	48 3b 15 f9 4b 06 00 	cmp    0x64bf9(%rip),%rdx        # 6c820 <fwp_cur>
    7c27:	0f 84 8b 00 00 00    	je     7cb8 <fwp_free_zombie+0xa8>
    7c2d:	48 83 ec 18          	sub    $0x18,%rsp
    7c31:	48 63 05 bc 45 06 00 	movslq 0x645bc(%rip),%rax        # 6c1f4 <fwp_stack_pool_n>
    7c38:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    7c3c:	83 f8 3f             	cmp    $0x3f,%eax
    7c3f:	7f 7f                	jg     7cc0 <fwp_free_zombie+0xb0>
    7c41:	8d 48 01             	lea    0x1(%rax),%ecx
    7c44:	89 0d aa 45 06 00    	mov    %ecx,0x645aa(%rip)        # 6c1f4 <fwp_stack_pool_n>
    7c4a:	48 8d 0d af 45 06 00 	lea    0x645af(%rip),%rcx        # 6c200 <fwp_stack_pool>
    7c51:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7c55:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    7c5c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7c60:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7c67:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    7c6b:	48 85 c9             	test   %rcx,%rcx
    7c6e:	0f 84 fc 00 00 00    	je     7d70 <fwp_free_zombie+0x160>
    7c74:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    7c7b:	48 85 c0             	test   %rax,%rax
    7c7e:	74 07                	je     7c87 <fwp_free_zombie+0x77>
    7c80:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7c87:	8b 42 5c             	mov    0x5c(%rdx),%eax
    7c8a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7c8e:	48 c7 05 77 4b 06 00 	movq   $0x0,0x64b77(%rip)        # 6c810 <fwp_zombie>
    7c95:	00 00 00 00 
    7c99:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7ca0:	85 c0                	test   %eax,%eax
    7ca2:	74 34                	je     7cd8 <fwp_free_zombie+0xc8>
    7ca4:	83 f8 01             	cmp    $0x1,%eax
    7ca7:	0f 84 b3 00 00 00    	je     7d60 <fwp_free_zombie+0x150>
    7cad:	48 83 c4 18          	add    $0x18,%rsp
    7cb1:	c3                   	ret
    7cb2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cb8:	c3                   	ret
    7cb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cc0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7cc4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7cc9:	e8 f2 b8 ff ff       	call   35c0 <munmap@plt>
    7cce:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7cd3:	eb 80                	jmp    7c55 <fwp_free_zombie+0x45>
    7cd5:	0f 1f 00             	nopl   (%rax)
    7cd8:	48 8b 0d 39 5f 06 00 	mov    0x65f39(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    7cdf:	48 89 d0             	mov    %rdx,%rax
    7ce2:	48 2b 05 07 5f 06 00 	sub    0x65f07(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7ce9:	48 c1 e1 10          	shl    $0x10,%rcx
    7ced:	48 39 c8             	cmp    %rcx,%rax
    7cf0:	73 bb                	jae    7cad <fwp_free_zombie+0x9d>
    7cf2:	48 89 c1             	mov    %rax,%rcx
    7cf5:	48 c1 e9 10          	shr    $0x10,%rcx
    7cf9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7cfd:	48 8b 0d 34 5f 06 00 	mov    0x65f34(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    7d04:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7d08:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7d0c:	48 85 c9             	test   %rcx,%rcx
    7d0f:	74 9c                	je     7cad <fwp_free_zombie+0x9d>
    7d11:	0f b6 3e             	movzbl (%rsi),%edi
    7d14:	40 80 ff 02          	cmp    $0x2,%dil
    7d18:	74 66                	je     7d80 <fwp_free_zombie+0x170>
    7d1a:	40 80 ff 01          	cmp    $0x1,%dil
    7d1e:	75 8d                	jne    7cad <fwp_free_zombie+0x9d>
    7d20:	8b 7e 18             	mov    0x18(%rsi),%edi
    7d23:	0f b7 c0             	movzwl %ax,%eax
    7d26:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7d29:	48 0f af c7          	imul   %rdi,%rax
    7d2d:	48 c1 e8 20          	shr    $0x20,%rax
    7d31:	48 39 f0             	cmp    %rsi,%rax
    7d34:	0f 83 73 ff ff ff    	jae    7cad <fwp_free_zombie+0x9d>
    7d3a:	48 01 c1             	add    %rax,%rcx
    7d3d:	0f b6 01             	movzbl (%rcx),%eax
    7d40:	84 c0                	test   %al,%al
    7d42:	0f 84 65 ff ff ff    	je     7cad <fwp_free_zombie+0x9d>
    7d48:	3c 01                	cmp    $0x1,%al
    7d4a:	74 14                	je     7d60 <fwp_free_zombie+0x150>
    7d4c:	3c ff                	cmp    $0xff,%al
    7d4e:	74 3b                	je     7d8b <fwp_free_zombie+0x17b>
    7d50:	83 e8 01             	sub    $0x1,%eax
    7d53:	88 01                	mov    %al,(%rcx)
    7d55:	e9 53 ff ff ff       	jmp    7cad <fwp_free_zombie+0x9d>
    7d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d60:	48 89 d7             	mov    %rdx,%rdi
    7d63:	48 83 c4 18          	add    $0x18,%rsp
    7d67:	e9 c4 fd ff ff       	jmp    7b30 <fwp_task_dispose>
    7d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    7d70:	48 89 05 71 4a 06 00 	mov    %rax,0x64a71(%rip)        # 6c7e8 <fwp_tasks_active>
    7d77:	e9 ff fe ff ff       	jmp    7c7b <fwp_free_zombie+0x6b>
    7d7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7d80:	66 85 c0             	test   %ax,%ax
    7d83:	0f 85 24 ff ff ff    	jne    7cad <fwp_free_zombie+0x9d>
    7d89:	eb b2                	jmp    7d3d <fwp_free_zombie+0x12d>
    7d8b:	48 89 ca             	mov    %rcx,%rdx
    7d8e:	48 8d 35 ab 4a 06 00 	lea    0x64aab(%rip),%rsi        # 6c840 <fwp_heap>
    7d95:	48 c1 ea 11          	shr    $0x11,%rdx
    7d99:	48 31 ca             	xor    %rcx,%rdx
    7d9c:	48 89 d0             	mov    %rdx,%rax
    7d9f:	48 c1 e8 09          	shr    $0x9,%rax
    7da3:	48 31 c2             	xor    %rax,%rdx
    7da6:	0f b6 d2             	movzbl %dl,%edx
    7da9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7db0:	00 
    7db1:	48 85 c0             	test   %rax,%rax
    7db4:	75 13                	jne    7dc9 <fwp_free_zombie+0x1b9>
    7db6:	eb 4c                	jmp    7e04 <fwp_free_zombie+0x1f4>
    7db8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7dbf:	00 
    7dc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7dc4:	48 85 c0             	test   %rax,%rax
    7dc7:	74 3b                	je     7e04 <fwp_free_zombie+0x1f4>
    7dc9:	48 89 c2             	mov    %rax,%rdx
    7dcc:	48 39 08             	cmp    %rcx,(%rax)
    7dcf:	75 ef                	jne    7dc0 <fwp_free_zombie+0x1b0>
    7dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7dd5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7dd9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7ddd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7de4:	0f 85 c3 fe ff ff    	jne    7cad <fwp_free_zombie+0x9d>
    7dea:	48 89 cf             	mov    %rcx,%rdi
    7ded:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7df2:	e8 d9 d9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7df7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7dfc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7dff:	e9 a9 fe ff ff       	jmp    7cad <fwp_free_zombie+0x9d>
    7e04:	48 8d 3d d5 8b 00 00 	lea    0x8bd5(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    7e0b:	e8 40 c6 ff ff       	call   4450 <fwp_trap>

0000000000007e10 <fwp_block>:
    7e10:	48 83 ec 08          	sub    $0x8,%rsp
    7e14:	48 8b 05 ed 49 06 00 	mov    0x649ed(%rip),%rax        # 6c808 <fwp_ready_head>
    7e1b:	48 85 c0             	test   %rax,%rax
    7e1e:	0f 84 1c 01 00 00    	je     7f40 <fwp_block+0x130>
    7e24:	90                   	nop
    7e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e2c:	00 00 00 00 
    7e30:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7e37:	48 89 15 ca 49 06 00 	mov    %rdx,0x649ca(%rip)        # 6c808 <fwp_ready_head>
    7e3e:	48 85 d2             	test   %rdx,%rdx
    7e41:	0f 84 19 01 00 00    	je     7f60 <fwp_block+0x150>
    7e47:	48 8b 15 d2 49 06 00 	mov    0x649d2(%rip),%rdx        # 6c820 <fwp_cur>
    7e4e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7e52:	48 39 c2             	cmp    %rax,%rdx
    7e55:	0f 84 d5 00 00 00    	je     7f30 <fwp_block+0x120>
    7e5b:	48 8b 0d 46 66 06 00 	mov    0x66646(%rip),%rcx        # 6e4a8 <fwp_state_owners>
    7e62:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7e66:	48 89 05 b3 49 06 00 	mov    %rax,0x649b3(%rip)        # 6c820 <fwp_cur>
    7e6d:	f3 0f 7e 05 5b 66 06 	movq   0x6665b(%rip),%xmm0        # 6e4d0 <fwp_foreign_callbacks>
    7e74:	00 
    7e75:	0f 16 05 44 66 06 00 	movhps 0x66644(%rip),%xmm0        # 6e4c0 <fwp_state>
    7e7c:	f3 0f 7e 0d 44 66 06 	movq   0x66644(%rip),%xmm1        # 6e4c8 <fwp_handlers>
    7e83:	00 
    7e84:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7e8b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7e92:	0f 16 0d 3f 66 06 00 	movhps 0x6663f(%rip),%xmm1        # 6e4d8 <fwp_cleanups>
    7e99:	f3 0f 7e 05 17 66 06 	movq   0x66617(%rip),%xmm0        # 6e4b8 <fwp_state_len>
    7ea0:	00 
    7ea1:	0f 16 05 08 66 06 00 	movhps 0x66608(%rip),%xmm0        # 6e4b0 <fwp_state_cap>
    7ea8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7eaf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7eb6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7eba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7ec1:	48 89 0d 00 66 06 00 	mov    %rcx,0x66600(%rip)        # 6e4c8 <fwp_handlers>
    7ec8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7ecf:	48 89 0d 02 66 06 00 	mov    %rcx,0x66602(%rip)        # 6e4d8 <fwp_cleanups>
    7ed6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7edd:	48 89 0d ec 65 06 00 	mov    %rcx,0x665ec(%rip)        # 6e4d0 <fwp_foreign_callbacks>
    7ee4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7eeb:	48 89 0d ce 65 06 00 	mov    %rcx,0x665ce(%rip)        # 6e4c0 <fwp_state>
    7ef2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7ef9:	48 89 0d b8 65 06 00 	mov    %rcx,0x665b8(%rip)        # 6e4b8 <fwp_state_len>
    7f00:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7f07:	48 89 0d a2 65 06 00 	mov    %rcx,0x665a2(%rip)        # 6e4b0 <fwp_state_cap>
    7f0e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7f15:	48 89 0d 8c 65 06 00 	mov    %rcx,0x6658c(%rip)        # 6e4a8 <fwp_state_owners>
    7f1c:	e8 5f b5 ff ff       	call   3480 <swapcontext@plt>
    7f21:	f3 0f 1e fa          	endbr64
    7f25:	e8 e6 fc ff ff       	call   7c10 <fwp_free_zombie>
    7f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f30:	8b 05 ba 42 06 00    	mov    0x642ba(%rip),%eax        # 6c1f0 <fwp_slice>
    7f36:	85 c0                	test   %eax,%eax
    7f38:	74 36                	je     7f70 <fwp_block+0x160>
    7f3a:	48 83 c4 08          	add    $0x8,%rsp
    7f3e:	c3                   	ret
    7f3f:	90                   	nop
    7f40:	e8 cb d4 ff ff       	call   5410 <fwp_poll_events>
    7f45:	48 8b 05 bc 48 06 00 	mov    0x648bc(%rip),%rax        # 6c808 <fwp_ready_head>
    7f4c:	48 85 c0             	test   %rax,%rax
    7f4f:	0f 85 db fe ff ff    	jne    7e30 <fwp_block+0x20>
    7f55:	eb e9                	jmp    7f40 <fwp_block+0x130>
    7f57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f5e:	00 00 
    7f60:	48 c7 05 95 48 06 00 	movq   $0x0,0x64895(%rip)        # 6c800 <fwp_ready_tail>
    7f67:	00 00 00 00 
    7f6b:	e9 d7 fe ff ff       	jmp    7e47 <fwp_block+0x37>
    7f70:	48 8d 3d 68 82 00 00 	lea    0x8268(%rip),%rdi        # 101df <_IO_stdin_used+0x1df>
    7f77:	e8 14 b4 ff ff       	call   3390 <getenv@plt>
    7f7c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7f81:	48 85 c0             	test   %rax,%rax
    7f84:	74 05                	je     7f8b <fwp_block+0x17b>
    7f86:	80 38 00             	cmpb   $0x0,(%rax)
    7f89:	75 0b                	jne    7f96 <fwp_block+0x186>
    7f8b:	89 15 5f 42 06 00    	mov    %edx,0x6425f(%rip)        # 6c1f0 <fwp_slice>
    7f91:	48 83 c4 08          	add    $0x8,%rsp
    7f95:	c3                   	ret
    7f96:	ba 0a 00 00 00       	mov    $0xa,%edx
    7f9b:	31 f6                	xor    %esi,%esi
    7f9d:	48 89 c7             	mov    %rax,%rdi
    7fa0:	e8 9b b5 ff ff       	call   3540 <strtoll@plt>
    7fa5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7fa9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7fb0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7fb5:	0f 46 d0             	cmovbe %eax,%edx
    7fb8:	eb d1                	jmp    7f8b <fwp_block+0x17b>
    7fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007fc0 <fwp_drop4>:
    7fc0:	48 8b 15 51 5c 06 00 	mov    0x65c51(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    7fc7:	48 89 f8             	mov    %rdi,%rax
    7fca:	48 2b 05 1f 5c 06 00 	sub    0x65c1f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    7fd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7fd5:	48 39 d0             	cmp    %rdx,%rax
    7fd8:	0f 83 52 01 00 00    	jae    8130 <fwp_drop4+0x170>
    7fde:	48 83 ec 18          	sub    $0x18,%rsp
    7fe2:	4c 8d 05 57 48 06 00 	lea    0x64857(%rip),%r8        # 6c840 <fwp_heap>
    7fe9:	48 89 c2             	mov    %rax,%rdx
    7fec:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7ff3:	48 c1 ea 10          	shr    $0x10,%rdx
    7ff7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7ffb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7fff:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8003:	48 85 d2             	test   %rdx,%rdx
    8006:	74 46                	je     804e <fwp_drop4+0x8e>
    8008:	44 0f b6 09          	movzbl (%rcx),%r9d
    800c:	41 80 f9 02          	cmp    $0x2,%r9b
    8010:	0f 84 ca 00 00 00    	je     80e0 <fwp_drop4+0x120>
    8016:	41 80 f9 01          	cmp    $0x1,%r9b
    801a:	75 32                	jne    804e <fwp_drop4+0x8e>
    801c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    8020:	0f b7 c0             	movzwl %ax,%eax
    8023:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8026:	49 0f af c1          	imul   %r9,%rax
    802a:	48 c1 e8 20          	shr    $0x20,%rax
    802e:	48 39 c8             	cmp    %rcx,%rax
    8031:	73 1b                	jae    804e <fwp_drop4+0x8e>
    8033:	48 01 c2             	add    %rax,%rdx
    8036:	0f b6 02             	movzbl (%rdx),%eax
    8039:	84 c0                	test   %al,%al
    803b:	74 11                	je     804e <fwp_drop4+0x8e>
    803d:	3c 01                	cmp    $0x1,%al
    803f:	74 17                	je     8058 <fwp_drop4+0x98>
    8041:	3c ff                	cmp    $0xff,%al
    8043:	0f 84 ef 00 00 00    	je     8138 <fwp_drop4+0x178>
    8049:	83 e8 01             	sub    $0x1,%eax
    804c:	88 02                	mov    %al,(%rdx)
    804e:	48 83 c4 18          	add    $0x18,%rsp
    8052:	c3                   	ret
    8053:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8058:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    805c:	0f 88 8e 00 00 00    	js     80f0 <fwp_drop4+0x130>
    8062:	48 8b 15 af 5b 06 00 	mov    0x65baf(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8069:	48 89 f8             	mov    %rdi,%rax
    806c:	48 2b 05 7d 5b 06 00 	sub    0x65b7d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8073:	48 c1 e2 10          	shl    $0x10,%rdx
    8077:	48 39 d0             	cmp    %rdx,%rax
    807a:	73 d2                	jae    804e <fwp_drop4+0x8e>
    807c:	48 89 c2             	mov    %rax,%rdx
    807f:	48 c1 ea 10          	shr    $0x10,%rdx
    8083:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    8087:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    808b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    808f:	48 85 c9             	test   %rcx,%rcx
    8092:	74 ba                	je     804e <fwp_drop4+0x8e>
    8094:	0f b6 32             	movzbl (%rdx),%esi
    8097:	40 80 fe 02          	cmp    $0x2,%sil
    809b:	74 33                	je     80d0 <fwp_drop4+0x110>
    809d:	40 80 fe 01          	cmp    $0x1,%sil
    80a1:	75 ab                	jne    804e <fwp_drop4+0x8e>
    80a3:	8b 72 18             	mov    0x18(%rdx),%esi
    80a6:	0f b7 c0             	movzwl %ax,%eax
    80a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80ac:	48 0f af c6          	imul   %rsi,%rax
    80b0:	48 c1 e8 20          	shr    $0x20,%rax
    80b4:	48 39 d0             	cmp    %rdx,%rax
    80b7:	73 95                	jae    804e <fwp_drop4+0x8e>
    80b9:	48 01 c1             	add    %rax,%rcx
    80bc:	80 39 01             	cmpb   $0x1,(%rcx)
    80bf:	75 8d                	jne    804e <fwp_drop4+0x8e>
    80c1:	48 83 c4 18          	add    $0x18,%rsp
    80c5:	e9 46 d9 ff ff       	jmp    5a10 <fwp_mem_free>
    80ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80d0:	66 85 c0             	test   %ax,%ax
    80d3:	74 e7                	je     80bc <fwp_drop4+0xfc>
    80d5:	48 83 c4 18          	add    $0x18,%rsp
    80d9:	c3                   	ret
    80da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80e0:	66 85 c0             	test   %ax,%ax
    80e3:	0f 84 4d ff ff ff    	je     8036 <fwp_drop4+0x76>
    80e9:	48 83 c4 18          	add    $0x18,%rsp
    80ed:	c3                   	ret
    80ee:	66 90                	xchg   %ax,%ax
    80f0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    80f4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    80f9:	e8 72 ef ff ff       	call   7070 <fwp_rc_free_arr>
    80fe:	4c 8d 05 3b 47 06 00 	lea    0x6473b(%rip),%r8        # 6c840 <fwp_heap>
    8105:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    810a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    8111:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    8118:	48 c1 e2 10          	shl    $0x10,%rdx
    811c:	48 39 d0             	cmp    %rdx,%rax
    811f:	0f 83 29 ff ff ff    	jae    804e <fwp_drop4+0x8e>
    8125:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    812a:	e9 ba fe ff ff       	jmp    7fe9 <fwp_drop4+0x29>
    812f:	90                   	nop
    8130:	c3                   	ret
    8131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8138:	48 89 d0             	mov    %rdx,%rax
    813b:	48 c1 e8 11          	shr    $0x11,%rax
    813f:	48 31 d0             	xor    %rdx,%rax
    8142:	48 89 c1             	mov    %rax,%rcx
    8145:	48 c1 e9 09          	shr    $0x9,%rcx
    8149:	48 31 c8             	xor    %rcx,%rax
    814c:	0f b6 c8             	movzbl %al,%ecx
    814f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    8156:	00 
    8157:	48 85 c0             	test   %rax,%rax
    815a:	75 0d                	jne    8169 <fwp_drop4+0x1a9>
    815c:	eb 46                	jmp    81a4 <fwp_drop4+0x1e4>
    815e:	66 90                	xchg   %ax,%ax
    8160:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8164:	48 85 c0             	test   %rax,%rax
    8167:	74 3b                	je     81a4 <fwp_drop4+0x1e4>
    8169:	48 89 c1             	mov    %rax,%rcx
    816c:	48 39 10             	cmp    %rdx,(%rax)
    816f:	75 ef                	jne    8160 <fwp_drop4+0x1a0>
    8171:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8175:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8179:	48 89 48 08          	mov    %rcx,0x8(%rax)
    817d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8184:	0f 85 c4 fe ff ff    	jne    804e <fwp_drop4+0x8e>
    818a:	48 89 d7             	mov    %rdx,%rdi
    818d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8192:	e8 39 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8197:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    819c:	c6 02 fe             	movb   $0xfe,(%rdx)
    819f:	e9 aa fe ff ff       	jmp    804e <fwp_drop4+0x8e>
    81a4:	48 8d 3d 35 88 00 00 	lea    0x8835(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    81ab:	e8 a0 c2 ff ff       	call   4450 <fwp_trap>

00000000000081b0 <fwp_caps161>:
    81b0:	f3 0f 1e fa          	endbr64
    81b4:	85 f6                	test   %esi,%esi
    81b6:	74 08                	je     81c0 <fwp_caps161+0x10>
    81b8:	c3                   	ret
    81b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    81c0:	48 8b 15 51 5a 06 00 	mov    0x65a51(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    81c7:	48 89 f8             	mov    %rdi,%rax
    81ca:	48 2b 05 1f 5a 06 00 	sub    0x65a1f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    81d1:	48 c1 e2 10          	shl    $0x10,%rdx
    81d5:	48 39 d0             	cmp    %rdx,%rax
    81d8:	73 de                	jae    81b8 <fwp_caps161+0x8>
    81da:	48 89 c2             	mov    %rax,%rdx
    81dd:	48 c1 ea 10          	shr    $0x10,%rdx
    81e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81e5:	48 8b 15 4c 5a 06 00 	mov    0x65a4c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    81ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81f0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    81f4:	48 85 c9             	test   %rcx,%rcx
    81f7:	74 bf                	je     81b8 <fwp_caps161+0x8>
    81f9:	0f b6 32             	movzbl (%rdx),%esi
    81fc:	40 80 fe 02          	cmp    $0x2,%sil
    8200:	74 2e                	je     8230 <fwp_caps161+0x80>
    8202:	40 80 fe 01          	cmp    $0x1,%sil
    8206:	75 b0                	jne    81b8 <fwp_caps161+0x8>
    8208:	8b 72 18             	mov    0x18(%rdx),%esi
    820b:	0f b7 c0             	movzwl %ax,%eax
    820e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8211:	48 0f af c6          	imul   %rsi,%rax
    8215:	48 c1 e8 20          	shr    $0x20,%rax
    8219:	48 39 d0             	cmp    %rdx,%rax
    821c:	73 9a                	jae    81b8 <fwp_caps161+0x8>
    821e:	48 01 c1             	add    %rax,%rcx
    8221:	80 39 01             	cmpb   $0x1,(%rcx)
    8224:	75 92                	jne    81b8 <fwp_caps161+0x8>
    8226:	e9 e5 d7 ff ff       	jmp    5a10 <fwp_mem_free>
    822b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8230:	66 85 c0             	test   %ax,%ax
    8233:	74 ec                	je     8221 <fwp_caps161+0x71>
    8235:	c3                   	ret
    8236:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    823d:	00 00 00 

0000000000008240 <fwp_drop2>:
    8240:	48 8b 0d d1 59 06 00 	mov    0x659d1(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8247:	48 89 f8             	mov    %rdi,%rax
    824a:	48 2b 05 9f 59 06 00 	sub    0x6599f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8251:	48 c1 e1 10          	shl    $0x10,%rcx
    8255:	48 39 c8             	cmp    %rcx,%rax
    8258:	0f 83 42 01 00 00    	jae    83a0 <fwp_drop2+0x160>
    825e:	48 83 ec 18          	sub    $0x18,%rsp
    8262:	48 89 fa             	mov    %rdi,%rdx
    8265:	4c 8d 05 d4 45 06 00 	lea    0x645d4(%rip),%r8        # 6c840 <fwp_heap>
    826c:	48 89 c1             	mov    %rax,%rcx
    826f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    8276:	48 c1 e9 10          	shr    $0x10,%rcx
    827a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    827e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    8282:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    8286:	48 85 c9             	test   %rcx,%rcx
    8289:	74 40                	je     82cb <fwp_drop2+0x8b>
    828b:	0f b6 3e             	movzbl (%rsi),%edi
    828e:	40 80 ff 02          	cmp    $0x2,%dil
    8292:	74 3c                	je     82d0 <fwp_drop2+0x90>
    8294:	40 80 ff 01          	cmp    $0x1,%dil
    8298:	75 31                	jne    82cb <fwp_drop2+0x8b>
    829a:	8b 7e 18             	mov    0x18(%rsi),%edi
    829d:	0f b7 c0             	movzwl %ax,%eax
    82a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    82a3:	48 0f af c7          	imul   %rdi,%rax
    82a7:	48 c1 e8 20          	shr    $0x20,%rax
    82ab:	48 39 f0             	cmp    %rsi,%rax
    82ae:	73 1b                	jae    82cb <fwp_drop2+0x8b>
    82b0:	48 01 c1             	add    %rax,%rcx
    82b3:	0f b6 01             	movzbl (%rcx),%eax
    82b6:	84 c0                	test   %al,%al
    82b8:	74 11                	je     82cb <fwp_drop2+0x8b>
    82ba:	3c 01                	cmp    $0x1,%al
    82bc:	74 22                	je     82e0 <fwp_drop2+0xa0>
    82be:	3c ff                	cmp    $0xff,%al
    82c0:	0f 84 0a 01 00 00    	je     83d0 <fwp_drop2+0x190>
    82c6:	83 e8 01             	sub    $0x1,%eax
    82c9:	88 01                	mov    %al,(%rcx)
    82cb:	48 83 c4 18          	add    $0x18,%rsp
    82cf:	c3                   	ret
    82d0:	66 85 c0             	test   %ax,%ax
    82d3:	74 de                	je     82b3 <fwp_drop2+0x73>
    82d5:	48 83 c4 18          	add    $0x18,%rsp
    82d9:	c3                   	ret
    82da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    82e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    82eb:	48 89 f8             	mov    %rdi,%rax
    82ee:	48 c1 e1 10          	shl    $0x10,%rcx
    82f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    82f9:	48 39 c8             	cmp    %rcx,%rax
    82fc:	73 62                	jae    8360 <fwp_drop2+0x120>
    82fe:	48 89 c1             	mov    %rax,%rcx
    8301:	48 c1 e9 10          	shr    $0x10,%rcx
    8305:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8309:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    830d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    8311:	48 85 c9             	test   %rcx,%rcx
    8314:	74 4a                	je     8360 <fwp_drop2+0x120>
    8316:	44 0f b6 0e          	movzbl (%rsi),%r9d
    831a:	41 80 f9 02          	cmp    $0x2,%r9b
    831e:	0f 84 9c 00 00 00    	je     83c0 <fwp_drop2+0x180>
    8324:	41 80 f9 01          	cmp    $0x1,%r9b
    8328:	75 36                	jne    8360 <fwp_drop2+0x120>
    832a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    832e:	0f b7 c0             	movzwl %ax,%eax
    8331:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8334:	49 0f af c1          	imul   %r9,%rax
    8338:	48 c1 e8 20          	shr    $0x20,%rax
    833c:	48 39 f0             	cmp    %rsi,%rax
    833f:	73 1f                	jae    8360 <fwp_drop2+0x120>
    8341:	48 01 c1             	add    %rax,%rcx
    8344:	0f b6 01             	movzbl (%rcx),%eax
    8347:	84 c0                	test   %al,%al
    8349:	74 15                	je     8360 <fwp_drop2+0x120>
    834b:	3c 01                	cmp    $0x1,%al
    834d:	74 59                	je     83a8 <fwp_drop2+0x168>
    834f:	3c ff                	cmp    $0xff,%al
    8351:	0f 84 ef 00 00 00    	je     8446 <fwp_drop2+0x206>
    8357:	83 e8 01             	sub    $0x1,%eax
    835a:	88 01                	mov    %al,(%rcx)
    835c:	0f 1f 40 00          	nopl   0x0(%rax)
    8360:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    8364:	48 89 d7             	mov    %rdx,%rdi
    8367:	48 89 0c 24          	mov    %rcx,(%rsp)
    836b:	e8 00 ed ff ff       	call   7070 <fwp_rc_free_arr>
    8370:	4c 8d 05 c9 44 06 00 	lea    0x644c9(%rip),%r8        # 6c840 <fwp_heap>
    8377:	48 8b 04 24          	mov    (%rsp),%rax
    837b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    8382:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    8389:	48 c1 e2 10          	shl    $0x10,%rdx
    838d:	48 39 d0             	cmp    %rdx,%rax
    8390:	0f 83 35 ff ff ff    	jae    82cb <fwp_drop2+0x8b>
    8396:	48 8b 14 24          	mov    (%rsp),%rdx
    839a:	e9 cd fe ff ff       	jmp    826c <fwp_drop2+0x2c>
    839f:	90                   	nop
    83a0:	c3                   	ret
    83a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    83a8:	48 89 14 24          	mov    %rdx,(%rsp)
    83ac:	e8 bf ec ff ff       	call   7070 <fwp_rc_free_arr>
    83b1:	48 8b 14 24          	mov    (%rsp),%rdx
    83b5:	eb a9                	jmp    8360 <fwp_drop2+0x120>
    83b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83be:	00 00 
    83c0:	66 85 c0             	test   %ax,%ax
    83c3:	75 9b                	jne    8360 <fwp_drop2+0x120>
    83c5:	e9 7a ff ff ff       	jmp    8344 <fwp_drop2+0x104>
    83ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    83d0:	48 89 c8             	mov    %rcx,%rax
    83d3:	48 c1 e8 11          	shr    $0x11,%rax
    83d7:	48 31 c8             	xor    %rcx,%rax
    83da:	48 89 c2             	mov    %rax,%rdx
    83dd:	48 c1 ea 09          	shr    $0x9,%rdx
    83e1:	48 31 d0             	xor    %rdx,%rax
    83e4:	0f b6 d0             	movzbl %al,%edx
    83e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    83ee:	00 
    83ef:	48 85 c0             	test   %rax,%rax
    83f2:	75 19                	jne    840d <fwp_drop2+0x1cd>
    83f4:	e9 d3 00 00 00       	jmp    84cc <fwp_drop2+0x28c>
    83f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8400:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8404:	48 85 c0             	test   %rax,%rax
    8407:	0f 84 bf 00 00 00    	je     84cc <fwp_drop2+0x28c>
    840d:	48 89 c2             	mov    %rax,%rdx
    8410:	48 39 08             	cmp    %rcx,(%rax)
    8413:	75 eb                	jne    8400 <fwp_drop2+0x1c0>
    8415:	48 8b 50 08          	mov    0x8(%rax),%rdx
    8419:	48 83 ea 01          	sub    $0x1,%rdx
    841d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8421:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8428:	0f 85 9d fe ff ff    	jne    82cb <fwp_drop2+0x8b>
    842e:	48 89 cf             	mov    %rcx,%rdi
    8431:	48 89 0c 24          	mov    %rcx,(%rsp)
    8435:	e8 96 d3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    843a:	48 8b 0c 24          	mov    (%rsp),%rcx
    843e:	c6 01 fe             	movb   $0xfe,(%rcx)
    8441:	e9 85 fe ff ff       	jmp    82cb <fwp_drop2+0x8b>
    8446:	48 89 ce             	mov    %rcx,%rsi
    8449:	48 c1 ee 11          	shr    $0x11,%rsi
    844d:	48 31 ce             	xor    %rcx,%rsi
    8450:	48 89 f0             	mov    %rsi,%rax
    8453:	48 c1 e8 09          	shr    $0x9,%rax
    8457:	48 31 c6             	xor    %rax,%rsi
    845a:	40 0f b6 f6          	movzbl %sil,%esi
    845e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    8465:	00 
    8466:	48 85 c0             	test   %rax,%rax
    8469:	75 1e                	jne    8489 <fwp_drop2+0x249>
    846b:	eb 5f                	jmp    84cc <fwp_drop2+0x28c>
    846d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8474:	00 
    8475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    847c:	00 00 00 00 
    8480:	48 8b 46 10          	mov    0x10(%rsi),%rax
    8484:	48 85 c0             	test   %rax,%rax
    8487:	74 43                	je     84cc <fwp_drop2+0x28c>
    8489:	48 89 c6             	mov    %rax,%rsi
    848c:	48 39 08             	cmp    %rcx,(%rax)
    848f:	75 ef                	jne    8480 <fwp_drop2+0x240>
    8491:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8495:	48 83 ee 01          	sub    $0x1,%rsi
    8499:	48 89 70 08          	mov    %rsi,0x8(%rax)
    849d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    84a4:	0f 85 b6 fe ff ff    	jne    8360 <fwp_drop2+0x120>
    84aa:	48 89 cf             	mov    %rcx,%rdi
    84ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    84b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    84b6:	e8 15 d3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    84bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    84bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    84c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    84c7:	e9 94 fe ff ff       	jmp    8360 <fwp_drop2+0x120>
    84cc:	48 8d 3d 0d 85 00 00 	lea    0x850d(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    84d3:	e8 78 bf ff ff       	call   4450 <fwp_trap>
    84d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84df:	00 

00000000000084e0 <fwp_arg_drop23>:
    84e0:	f3 0f 1e fa          	endbr64
    84e4:	85 f6                	test   %esi,%esi
    84e6:	75 04                	jne    84ec <fwp_arg_drop23+0xc>
    84e8:	85 d2                	test   %edx,%edx
    84ea:	75 04                	jne    84f0 <fwp_arg_drop23+0x10>
    84ec:	c3                   	ret
    84ed:	0f 1f 00             	nopl   (%rax)
    84f0:	48 8b 3f             	mov    (%rdi),%rdi
    84f3:	e9 48 fd ff ff       	jmp    8240 <fwp_drop2>
    84f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    84ff:	00 

0000000000008500 <fwp_args12>:
    8500:	f3 0f 1e fa          	endbr64
    8504:	85 d2                	test   %edx,%edx
    8506:	74 04                	je     850c <fwp_args12+0xc>
    8508:	85 f6                	test   %esi,%esi
    850a:	74 04                	je     8510 <fwp_args12+0x10>
    850c:	c3                   	ret
    850d:	0f 1f 00             	nopl   (%rax)
    8510:	48 8b 15 01 57 06 00 	mov    0x65701(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8517:	48 8b 07             	mov    (%rdi),%rax
    851a:	48 2b 05 cf 56 06 00 	sub    0x656cf(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8521:	48 c1 e2 10          	shl    $0x10,%rdx
    8525:	48 39 d0             	cmp    %rdx,%rax
    8528:	73 e2                	jae    850c <fwp_args12+0xc>
    852a:	48 89 c2             	mov    %rax,%rdx
    852d:	48 c1 ea 10          	shr    $0x10,%rdx
    8531:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8535:	48 8b 15 fc 56 06 00 	mov    0x656fc(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    853c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8540:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8544:	48 85 ff             	test   %rdi,%rdi
    8547:	74 c3                	je     850c <fwp_args12+0xc>
    8549:	0f b6 0a             	movzbl (%rdx),%ecx
    854c:	80 f9 02             	cmp    $0x2,%cl
    854f:	74 4f                	je     85a0 <fwp_args12+0xa0>
    8551:	80 f9 01             	cmp    $0x1,%cl
    8554:	75 b6                	jne    850c <fwp_args12+0xc>
    8556:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8559:	0f b7 c0             	movzwl %ax,%eax
    855c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    855f:	48 0f af c1          	imul   %rcx,%rax
    8563:	48 c1 e8 20          	shr    $0x20,%rax
    8567:	48 39 d0             	cmp    %rdx,%rax
    856a:	73 a0                	jae    850c <fwp_args12+0xc>
    856c:	48 01 c7             	add    %rax,%rdi
    856f:	0f b6 07             	movzbl (%rdi),%eax
    8572:	84 c0                	test   %al,%al
    8574:	74 96                	je     850c <fwp_args12+0xc>
    8576:	8b 15 8c 5f 06 00    	mov    0x65f8c(%rip),%edx        # 6e508 <iteration_active>
    857c:	85 d2                	test   %edx,%edx
    857e:	75 10                	jne    8590 <fwp_args12+0x90>
    8580:	3c fd                	cmp    $0xfd,%al
    8582:	77 22                	ja     85a6 <fwp_args12+0xa6>
    8584:	83 c0 01             	add    $0x1,%eax
    8587:	88 07                	mov    %al,(%rdi)
    8589:	c3                   	ret
    858a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8590:	48 83 05 58 5f 06 00 	addq   $0x1,0x65f58(%rip)        # 6e4f0 <iteration_retains>
    8597:	01 
    8598:	eb e6                	jmp    8580 <fwp_args12+0x80>
    859a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85a0:	66 85 c0             	test   %ax,%ax
    85a3:	74 ca                	je     856f <fwp_args12+0x6f>
    85a5:	c3                   	ret
    85a6:	e9 05 d1 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    85ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000085b0 <fwp_args23>:
    85b0:	f3 0f 1e fa          	endbr64
    85b4:	85 d2                	test   %edx,%edx
    85b6:	74 04                	je     85bc <fwp_args23+0xc>
    85b8:	85 f6                	test   %esi,%esi
    85ba:	74 04                	je     85c0 <fwp_args23+0x10>
    85bc:	c3                   	ret
    85bd:	0f 1f 00             	nopl   (%rax)
    85c0:	48 8b 15 51 56 06 00 	mov    0x65651(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    85c7:	48 8b 07             	mov    (%rdi),%rax
    85ca:	48 2b 05 1f 56 06 00 	sub    0x6561f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    85d1:	48 c1 e2 10          	shl    $0x10,%rdx
    85d5:	48 39 d0             	cmp    %rdx,%rax
    85d8:	73 e2                	jae    85bc <fwp_args23+0xc>
    85da:	48 89 c2             	mov    %rax,%rdx
    85dd:	48 c1 ea 10          	shr    $0x10,%rdx
    85e1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    85e5:	48 8b 15 4c 56 06 00 	mov    0x6564c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    85ec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    85f0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    85f4:	48 85 ff             	test   %rdi,%rdi
    85f7:	74 c3                	je     85bc <fwp_args23+0xc>
    85f9:	0f b6 0a             	movzbl (%rdx),%ecx
    85fc:	80 f9 02             	cmp    $0x2,%cl
    85ff:	74 4f                	je     8650 <fwp_args23+0xa0>
    8601:	80 f9 01             	cmp    $0x1,%cl
    8604:	75 b6                	jne    85bc <fwp_args23+0xc>
    8606:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8609:	0f b7 c0             	movzwl %ax,%eax
    860c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    860f:	48 0f af c1          	imul   %rcx,%rax
    8613:	48 c1 e8 20          	shr    $0x20,%rax
    8617:	48 39 d0             	cmp    %rdx,%rax
    861a:	73 a0                	jae    85bc <fwp_args23+0xc>
    861c:	48 01 c7             	add    %rax,%rdi
    861f:	0f b6 07             	movzbl (%rdi),%eax
    8622:	84 c0                	test   %al,%al
    8624:	74 96                	je     85bc <fwp_args23+0xc>
    8626:	8b 15 dc 5e 06 00    	mov    0x65edc(%rip),%edx        # 6e508 <iteration_active>
    862c:	85 d2                	test   %edx,%edx
    862e:	75 10                	jne    8640 <fwp_args23+0x90>
    8630:	3c fd                	cmp    $0xfd,%al
    8632:	77 22                	ja     8656 <fwp_args23+0xa6>
    8634:	83 c0 01             	add    $0x1,%eax
    8637:	88 07                	mov    %al,(%rdi)
    8639:	c3                   	ret
    863a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8640:	48 83 05 a8 5e 06 00 	addq   $0x1,0x65ea8(%rip)        # 6e4f0 <iteration_retains>
    8647:	01 
    8648:	eb e6                	jmp    8630 <fwp_args23+0x80>
    864a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8650:	66 85 c0             	test   %ax,%ax
    8653:	74 ca                	je     861f <fwp_args23+0x6f>
    8655:	c3                   	ret
    8656:	e9 55 d0 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    865b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008660 <fwp_caps12>:
    8660:	f3 0f 1e fa          	endbr64
    8664:	48 83 ec 18          	sub    $0x18,%rsp
    8668:	48 89 f8             	mov    %rdi,%rax
    866b:	8b 7f 04             	mov    0x4(%rdi),%edi
    866e:	85 ff                	test   %edi,%edi
    8670:	0f 84 9a 00 00 00    	je     8710 <fwp_caps12+0xb0>
    8676:	48 8b 78 08          	mov    0x8(%rax),%rdi
    867a:	85 f6                	test   %esi,%esi
    867c:	0f 85 9e 00 00 00    	jne    8720 <fwp_caps12+0xc0>
    8682:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8687:	e8 14 ed ff ff       	call   73a0 <fwp_drop0>
    868c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8691:	48 8b 0d 80 55 06 00 	mov    0x65580(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8698:	48 89 c2             	mov    %rax,%rdx
    869b:	48 2b 15 4e 55 06 00 	sub    0x6554e(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    86a2:	48 c1 e1 10          	shl    $0x10,%rcx
    86a6:	48 39 ca             	cmp    %rcx,%rdx
    86a9:	73 6d                	jae    8718 <fwp_caps12+0xb8>
    86ab:	48 89 d1             	mov    %rdx,%rcx
    86ae:	48 c1 e9 10          	shr    $0x10,%rcx
    86b2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    86b6:	48 8b 0d 7b 55 06 00 	mov    0x6557b(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    86bd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    86c1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    86c5:	48 85 f6             	test   %rsi,%rsi
    86c8:	74 4e                	je     8718 <fwp_caps12+0xb8>
    86ca:	0f b6 39             	movzbl (%rcx),%edi
    86cd:	40 80 ff 02          	cmp    $0x2,%dil
    86d1:	0f 84 c9 00 00 00    	je     87a0 <fwp_caps12+0x140>
    86d7:	40 80 ff 01          	cmp    $0x1,%dil
    86db:	75 3b                	jne    8718 <fwp_caps12+0xb8>
    86dd:	8b 79 18             	mov    0x18(%rcx),%edi
    86e0:	0f b7 d2             	movzwl %dx,%edx
    86e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    86e6:	48 0f af d7          	imul   %rdi,%rdx
    86ea:	48 c1 ea 20          	shr    $0x20,%rdx
    86ee:	48 39 ca             	cmp    %rcx,%rdx
    86f1:	73 25                	jae    8718 <fwp_caps12+0xb8>
    86f3:	48 01 d6             	add    %rdx,%rsi
    86f6:	80 3e 01             	cmpb   $0x1,(%rsi)
    86f9:	75 1d                	jne    8718 <fwp_caps12+0xb8>
    86fb:	48 89 c7             	mov    %rax,%rdi
    86fe:	48 83 c4 18          	add    $0x18,%rsp
    8702:	e9 09 d3 ff ff       	jmp    5a10 <fwp_mem_free>
    8707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    870e:	00 00 
    8710:	85 f6                	test   %esi,%esi
    8712:	0f 84 79 ff ff ff    	je     8691 <fwp_caps12+0x31>
    8718:	48 83 c4 18          	add    $0x18,%rsp
    871c:	c3                   	ret
    871d:	0f 1f 00             	nopl   (%rax)
    8720:	48 8b 05 f1 54 06 00 	mov    0x654f1(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    8727:	48 2b 3d c2 54 06 00 	sub    0x654c2(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    872e:	48 c1 e0 10          	shl    $0x10,%rax
    8732:	48 39 c7             	cmp    %rax,%rdi
    8735:	73 e1                	jae    8718 <fwp_caps12+0xb8>
    8737:	48 89 f8             	mov    %rdi,%rax
    873a:	48 c1 e8 10          	shr    $0x10,%rax
    873e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8742:	48 8b 05 ef 54 06 00 	mov    0x654ef(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8749:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    874d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8751:	48 85 c0             	test   %rax,%rax
    8754:	74 c2                	je     8718 <fwp_caps12+0xb8>
    8756:	0f b6 0a             	movzbl (%rdx),%ecx
    8759:	80 f9 02             	cmp    $0x2,%cl
    875c:	74 52                	je     87b0 <fwp_caps12+0x150>
    875e:	80 f9 01             	cmp    $0x1,%cl
    8761:	75 b5                	jne    8718 <fwp_caps12+0xb8>
    8763:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8766:	0f b7 ff             	movzwl %di,%edi
    8769:	8b 52 1c             	mov    0x1c(%rdx),%edx
    876c:	48 0f af f9          	imul   %rcx,%rdi
    8770:	48 c1 ef 20          	shr    $0x20,%rdi
    8774:	48 39 d7             	cmp    %rdx,%rdi
    8777:	73 9f                	jae    8718 <fwp_caps12+0xb8>
    8779:	48 01 f8             	add    %rdi,%rax
    877c:	0f b6 10             	movzbl (%rax),%edx
    877f:	84 d2                	test   %dl,%dl
    8781:	74 95                	je     8718 <fwp_caps12+0xb8>
    8783:	8b 0d 7f 5d 06 00    	mov    0x65d7f(%rip),%ecx        # 6e508 <iteration_active>
    8789:	85 c9                	test   %ecx,%ecx
    878b:	75 33                	jne    87c0 <fwp_caps12+0x160>
    878d:	80 fa fd             	cmp    $0xfd,%dl
    8790:	77 38                	ja     87ca <fwp_caps12+0x16a>
    8792:	83 c2 01             	add    $0x1,%edx
    8795:	88 10                	mov    %dl,(%rax)
    8797:	e9 7c ff ff ff       	jmp    8718 <fwp_caps12+0xb8>
    879c:	0f 1f 40 00          	nopl   0x0(%rax)
    87a0:	66 85 d2             	test   %dx,%dx
    87a3:	0f 85 6f ff ff ff    	jne    8718 <fwp_caps12+0xb8>
    87a9:	e9 48 ff ff ff       	jmp    86f6 <fwp_caps12+0x96>
    87ae:	66 90                	xchg   %ax,%ax
    87b0:	66 85 ff             	test   %di,%di
    87b3:	0f 85 5f ff ff ff    	jne    8718 <fwp_caps12+0xb8>
    87b9:	eb c1                	jmp    877c <fwp_caps12+0x11c>
    87bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    87c0:	48 83 05 28 5d 06 00 	addq   $0x1,0x65d28(%rip)        # 6e4f0 <iteration_retains>
    87c7:	01 
    87c8:	eb c3                	jmp    878d <fwp_caps12+0x12d>
    87ca:	48 89 c7             	mov    %rax,%rdi
    87cd:	48 83 c4 18          	add    $0x18,%rsp
    87d1:	e9 da ce ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    87d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    87dd:	00 00 00 

00000000000087e0 <fwp_caps23>:
    87e0:	f3 0f 1e fa          	endbr64
    87e4:	48 83 ec 18          	sub    $0x18,%rsp
    87e8:	48 89 f8             	mov    %rdi,%rax
    87eb:	8b 7f 04             	mov    0x4(%rdi),%edi
    87ee:	85 ff                	test   %edi,%edi
    87f0:	0f 84 9a 00 00 00    	je     8890 <fwp_caps23+0xb0>
    87f6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    87fa:	85 f6                	test   %esi,%esi
    87fc:	0f 85 9e 00 00 00    	jne    88a0 <fwp_caps23+0xc0>
    8802:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8807:	e8 34 fa ff ff       	call   8240 <fwp_drop2>
    880c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8811:	48 8b 0d 00 54 06 00 	mov    0x65400(%rip),%rcx        # 6dc18 <fwp_heap+0x13d8>
    8818:	48 89 c2             	mov    %rax,%rdx
    881b:	48 2b 15 ce 53 06 00 	sub    0x653ce(%rip),%rdx        # 6dbf0 <fwp_heap+0x13b0>
    8822:	48 c1 e1 10          	shl    $0x10,%rcx
    8826:	48 39 ca             	cmp    %rcx,%rdx
    8829:	73 6d                	jae    8898 <fwp_caps23+0xb8>
    882b:	48 89 d1             	mov    %rdx,%rcx
    882e:	48 c1 e9 10          	shr    $0x10,%rcx
    8832:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8836:	48 8b 0d fb 53 06 00 	mov    0x653fb(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    883d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8841:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8845:	48 85 f6             	test   %rsi,%rsi
    8848:	74 4e                	je     8898 <fwp_caps23+0xb8>
    884a:	0f b6 39             	movzbl (%rcx),%edi
    884d:	40 80 ff 02          	cmp    $0x2,%dil
    8851:	0f 84 c9 00 00 00    	je     8920 <fwp_caps23+0x140>
    8857:	40 80 ff 01          	cmp    $0x1,%dil
    885b:	75 3b                	jne    8898 <fwp_caps23+0xb8>
    885d:	8b 79 18             	mov    0x18(%rcx),%edi
    8860:	0f b7 d2             	movzwl %dx,%edx
    8863:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8866:	48 0f af d7          	imul   %rdi,%rdx
    886a:	48 c1 ea 20          	shr    $0x20,%rdx
    886e:	48 39 ca             	cmp    %rcx,%rdx
    8871:	73 25                	jae    8898 <fwp_caps23+0xb8>
    8873:	48 01 d6             	add    %rdx,%rsi
    8876:	80 3e 01             	cmpb   $0x1,(%rsi)
    8879:	75 1d                	jne    8898 <fwp_caps23+0xb8>
    887b:	48 89 c7             	mov    %rax,%rdi
    887e:	48 83 c4 18          	add    $0x18,%rsp
    8882:	e9 89 d1 ff ff       	jmp    5a10 <fwp_mem_free>
    8887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    888e:	00 00 
    8890:	85 f6                	test   %esi,%esi
    8892:	0f 84 79 ff ff ff    	je     8811 <fwp_caps23+0x31>
    8898:	48 83 c4 18          	add    $0x18,%rsp
    889c:	c3                   	ret
    889d:	0f 1f 00             	nopl   (%rax)
    88a0:	48 8b 05 71 53 06 00 	mov    0x65371(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    88a7:	48 2b 3d 42 53 06 00 	sub    0x65342(%rip),%rdi        # 6dbf0 <fwp_heap+0x13b0>
    88ae:	48 c1 e0 10          	shl    $0x10,%rax
    88b2:	48 39 c7             	cmp    %rax,%rdi
    88b5:	73 e1                	jae    8898 <fwp_caps23+0xb8>
    88b7:	48 89 f8             	mov    %rdi,%rax
    88ba:	48 c1 e8 10          	shr    $0x10,%rax
    88be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    88c2:	48 8b 05 6f 53 06 00 	mov    0x6536f(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    88c9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    88cd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    88d1:	48 85 c0             	test   %rax,%rax
    88d4:	74 c2                	je     8898 <fwp_caps23+0xb8>
    88d6:	0f b6 0a             	movzbl (%rdx),%ecx
    88d9:	80 f9 02             	cmp    $0x2,%cl
    88dc:	74 52                	je     8930 <fwp_caps23+0x150>
    88de:	80 f9 01             	cmp    $0x1,%cl
    88e1:	75 b5                	jne    8898 <fwp_caps23+0xb8>
    88e3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    88e6:	0f b7 ff             	movzwl %di,%edi
    88e9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88ec:	48 0f af f9          	imul   %rcx,%rdi
    88f0:	48 c1 ef 20          	shr    $0x20,%rdi
    88f4:	48 39 d7             	cmp    %rdx,%rdi
    88f7:	73 9f                	jae    8898 <fwp_caps23+0xb8>
    88f9:	48 01 f8             	add    %rdi,%rax
    88fc:	0f b6 10             	movzbl (%rax),%edx
    88ff:	84 d2                	test   %dl,%dl
    8901:	74 95                	je     8898 <fwp_caps23+0xb8>
    8903:	8b 0d ff 5b 06 00    	mov    0x65bff(%rip),%ecx        # 6e508 <iteration_active>
    8909:	85 c9                	test   %ecx,%ecx
    890b:	75 33                	jne    8940 <fwp_caps23+0x160>
    890d:	80 fa fd             	cmp    $0xfd,%dl
    8910:	77 38                	ja     894a <fwp_caps23+0x16a>
    8912:	83 c2 01             	add    $0x1,%edx
    8915:	88 10                	mov    %dl,(%rax)
    8917:	e9 7c ff ff ff       	jmp    8898 <fwp_caps23+0xb8>
    891c:	0f 1f 40 00          	nopl   0x0(%rax)
    8920:	66 85 d2             	test   %dx,%dx
    8923:	0f 85 6f ff ff ff    	jne    8898 <fwp_caps23+0xb8>
    8929:	e9 48 ff ff ff       	jmp    8876 <fwp_caps23+0x96>
    892e:	66 90                	xchg   %ax,%ax
    8930:	66 85 ff             	test   %di,%di
    8933:	0f 85 5f ff ff ff    	jne    8898 <fwp_caps23+0xb8>
    8939:	eb c1                	jmp    88fc <fwp_caps23+0x11c>
    893b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8940:	48 83 05 a8 5b 06 00 	addq   $0x1,0x65ba8(%rip)        # 6e4f0 <iteration_retains>
    8947:	01 
    8948:	eb c3                	jmp    890d <fwp_caps23+0x12d>
    894a:	48 89 c7             	mov    %rax,%rdi
    894d:	48 83 c4 18          	add    $0x18,%rsp
    8951:	e9 5a cd ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    895d:	00 00 00 

0000000000008960 <f23>:
    8960:	41 57                	push   %r15
    8962:	41 56                	push   %r14
    8964:	41 55                	push   %r13
    8966:	41 54                	push   %r12
    8968:	55                   	push   %rbp
    8969:	53                   	push   %rbx
    896a:	48 83 ec 38          	sub    $0x38,%rsp
    896e:	48 8b 15 a3 52 06 00 	mov    0x652a3(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8975:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    897a:	48 c1 e2 10          	shl    $0x10,%rdx
    897e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8985:	00 00 
    8987:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    898c:	48 8b 0d 5d 52 06 00 	mov    0x6525d(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    8993:	48 85 ff             	test   %rdi,%rdi
    8996:	0f 84 5e 03 00 00    	je     8cfa <f23+0x39a>
    899c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    89a1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    89a5:	4c 89 e8             	mov    %r13,%rax
    89a8:	48 29 c8             	sub    %rcx,%rax
    89ab:	48 39 d0             	cmp    %rdx,%rax
    89ae:	0f 83 2c 03 00 00    	jae    8ce0 <f23+0x380>
    89b4:	48 89 c2             	mov    %rax,%rdx
    89b7:	48 c1 ea 10          	shr    $0x10,%rdx
    89bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89bf:	48 8b 15 72 52 06 00 	mov    0x65272(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    89c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89ca:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    89ce:	48 85 ff             	test   %rdi,%rdi
    89d1:	0f 84 09 03 00 00    	je     8ce0 <f23+0x380>
    89d7:	0f b6 0a             	movzbl (%rdx),%ecx
    89da:	80 f9 02             	cmp    $0x2,%cl
    89dd:	0f 84 8d 02 00 00    	je     8c70 <f23+0x310>
    89e3:	80 f9 01             	cmp    $0x1,%cl
    89e6:	75 24                	jne    8a0c <f23+0xac>
    89e8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    89eb:	0f b7 c0             	movzwl %ax,%eax
    89ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    89f1:	48 0f af c1          	imul   %rcx,%rax
    89f5:	48 c1 e8 20          	shr    $0x20,%rax
    89f9:	48 39 d0             	cmp    %rdx,%rax
    89fc:	73 0e                	jae    8a0c <f23+0xac>
    89fe:	48 01 c7             	add    %rax,%rdi
    8a01:	0f b6 07             	movzbl (%rdi),%eax
    8a04:	84 c0                	test   %al,%al
    8a06:	0f 85 84 02 00 00    	jne    8c90 <f23+0x330>
    8a0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8a11:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a15:	ba 01 00 00 00       	mov    $0x1,%edx
    8a1a:	48 85 c0             	test   %rax,%rax
    8a1d:	74 0e                	je     8a2d <f23+0xcd>
    8a1f:	90                   	nop
    8a20:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a24:	48 83 c2 01          	add    $0x1,%rdx
    8a28:	48 85 c0             	test   %rax,%rax
    8a2b:	75 f3                	jne    8a20 <f23+0xc0>
    8a2d:	4d 85 ed             	test   %r13,%r13
    8a30:	0f 84 da 02 00 00    	je     8d10 <f23+0x3b0>
    8a36:	4c 89 e8             	mov    %r13,%rax
    8a39:	31 db                	xor    %ebx,%ebx
    8a3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a40:	48 8b 40 10          	mov    0x10(%rax),%rax
    8a44:	48 83 c3 01          	add    $0x1,%rbx
    8a48:	48 85 c0             	test   %rax,%rax
    8a4b:	75 f3                	jne    8a40 <f23+0xe0>
    8a4d:	48 39 d3             	cmp    %rdx,%rbx
    8a50:	48 0f 47 da          	cmova  %rdx,%rbx
    8a54:	48 89 d8             	mov    %rbx,%rax
    8a57:	48 c1 e8 3c          	shr    $0x3c,%rax
    8a5b:	0f 85 bd 03 00 00    	jne    8e1e <f23+0x4be>
    8a61:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8a65:	be 02 00 00 00       	mov    $0x2,%esi
    8a6a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8a71:	00 
    8a72:	e8 99 d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a77:	48 89 28             	mov    %rbp,(%rax)
    8a7a:	48 8b 15 97 51 06 00 	mov    0x65197(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8a81:	49 89 c4             	mov    %rax,%r12
    8a84:	48 2b 05 65 51 06 00 	sub    0x65165(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8a8b:	48 c1 e2 10          	shl    $0x10,%rdx
    8a8f:	48 39 d0             	cmp    %rdx,%rax
    8a92:	73 57                	jae    8aeb <f23+0x18b>
    8a94:	48 89 c2             	mov    %rax,%rdx
    8a97:	48 c1 ea 10          	shr    $0x10,%rdx
    8a9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a9f:	48 8b 15 92 51 06 00 	mov    0x65192(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8aa6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8aaa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8aae:	48 85 ed             	test   %rbp,%rbp
    8ab1:	74 38                	je     8aeb <f23+0x18b>
    8ab3:	0f b6 0a             	movzbl (%rdx),%ecx
    8ab6:	80 f9 02             	cmp    $0x2,%cl
    8ab9:	0f 84 11 02 00 00    	je     8cd0 <f23+0x370>
    8abf:	80 f9 01             	cmp    $0x1,%cl
    8ac2:	75 27                	jne    8aeb <f23+0x18b>
    8ac4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ac7:	0f b7 c0             	movzwl %ax,%eax
    8aca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8acd:	48 0f af c1          	imul   %rcx,%rax
    8ad1:	48 c1 e8 20          	shr    $0x20,%rax
    8ad5:	48 39 d0             	cmp    %rdx,%rax
    8ad8:	73 11                	jae    8aeb <f23+0x18b>
    8ada:	48 01 c5             	add    %rax,%rbp
    8add:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8ae1:	0f 84 97 02 00 00    	je     8d7e <f23+0x41e>
    8ae7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    8aeb:	48 85 db             	test   %rbx,%rbx
    8aee:	74 5d                	je     8b4d <f23+0x1ed>
    8af0:	48 c1 e3 04          	shl    $0x4,%rbx
    8af4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8af9:	4c 89 e5             	mov    %r12,%rbp
    8afc:	4d 89 ef             	mov    %r13,%r15
    8aff:	4c 01 e3             	add    %r12,%rbx
    8b02:	0f 1f 00             	nopl   (%rax)
    8b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8b0c:	00 00 00 00 
    8b10:	49 8b 46 08          	mov    0x8(%r14),%rax
    8b14:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8b18:	48 83 c5 10          	add    $0x10,%rbp
    8b1c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8b21:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8b25:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8b29:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    8b2e:	e8 1d dc ff ff       	call   6750 <w107>
    8b33:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8b38:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8b3c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8b40:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8b44:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8b48:	48 39 eb             	cmp    %rbp,%rbx
    8b4b:	75 c3                	jne    8b10 <f23+0x1b0>
    8b4d:	4c 89 ef             	mov    %r13,%rdi
    8b50:	31 db                	xor    %ebx,%ebx
    8b52:	e8 e9 f6 ff ff       	call   8240 <fwp_drop2>
    8b57:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8b5c:	e8 df f6 ff ff       	call   8240 <fwp_drop2>
    8b61:	4d 8b 2c 24          	mov    (%r12),%r13
    8b65:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8b69:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8b70:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8b77:	4d 85 ed             	test   %r13,%r13
    8b7a:	74 32                	je     8bae <f23+0x24e>
    8b7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b80:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8b87:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    8b8c:	48 83 c3 02          	add    $0x2,%rbx
    8b90:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8b96:	e8 35 da ff ff       	call   65d0 <f128.constprop.0>
    8b9b:	4c 39 eb             	cmp    %r13,%rbx
    8b9e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8ba4:	48 89 c7             	mov    %rax,%rdi
    8ba7:	72 d7                	jb     8b80 <f23+0x220>
    8ba9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    8bae:	4c 89 e7             	mov    %r12,%rdi
    8bb1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8bb6:	e8 05 f4 ff ff       	call   7fc0 <fwp_drop4>
    8bbb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8bc0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8bc5:	31 ff                	xor    %edi,%edi
    8bc7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    8bcc:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8bd1:	e8 7a e1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    8bd6:	48 8b 15 3b 50 06 00 	mov    0x6503b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8bdd:	48 89 c5             	mov    %rax,%rbp
    8be0:	48 2b 05 09 50 06 00 	sub    0x65009(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8be7:	48 c1 e2 10          	shl    $0x10,%rdx
    8beb:	48 39 d0             	cmp    %rdx,%rax
    8bee:	73 55                	jae    8c45 <f23+0x2e5>
    8bf0:	48 89 c2             	mov    %rax,%rdx
    8bf3:	48 c1 ea 10          	shr    $0x10,%rdx
    8bf7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8bfb:	48 8b 15 36 50 06 00 	mov    0x65036(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8c02:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8c06:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8c0a:	48 85 db             	test   %rbx,%rbx
    8c0d:	74 36                	je     8c45 <f23+0x2e5>
    8c0f:	0f b6 0a             	movzbl (%rdx),%ecx
    8c12:	80 f9 02             	cmp    $0x2,%cl
    8c15:	0f 84 a5 00 00 00    	je     8cc0 <f23+0x360>
    8c1b:	80 f9 01             	cmp    $0x1,%cl
    8c1e:	75 25                	jne    8c45 <f23+0x2e5>
    8c20:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8c23:	0f b7 c0             	movzwl %ax,%eax
    8c26:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c29:	48 0f af c1          	imul   %rcx,%rax
    8c2d:	48 c1 e8 20          	shr    $0x20,%rax
    8c31:	48 39 d0             	cmp    %rdx,%rax
    8c34:	73 0f                	jae    8c45 <f23+0x2e5>
    8c36:	48 01 c3             	add    %rax,%rbx
    8c39:	80 3b ff             	cmpb   $0xff,(%rbx)
    8c3c:	0f 84 2f 01 00 00    	je     8d71 <f23+0x411>
    8c42:	c6 03 01             	movb   $0x1,(%rbx)
    8c45:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    8c4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c51:	00 00 
    8c53:	0f 85 d1 01 00 00    	jne    8e2a <f23+0x4ca>
    8c59:	48 83 c4 38          	add    $0x38,%rsp
    8c5d:	48 89 e8             	mov    %rbp,%rax
    8c60:	5b                   	pop    %rbx
    8c61:	5d                   	pop    %rbp
    8c62:	41 5c                	pop    %r12
    8c64:	41 5d                	pop    %r13
    8c66:	41 5e                	pop    %r14
    8c68:	41 5f                	pop    %r15
    8c6a:	c3                   	ret
    8c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8c70:	66 85 c0             	test   %ax,%ax
    8c73:	0f 85 93 fd ff ff    	jne    8a0c <f23+0xac>
    8c79:	0f b6 07             	movzbl (%rdi),%eax
    8c7c:	84 c0                	test   %al,%al
    8c7e:	0f 84 88 fd ff ff    	je     8a0c <f23+0xac>
    8c84:	90                   	nop
    8c85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c8c:	00 00 00 00 
    8c90:	8b 15 72 58 06 00    	mov    0x65872(%rip),%edx        # 6e508 <iteration_active>
    8c96:	85 d2                	test   %edx,%edx
    8c98:	75 56                	jne    8cf0 <f23+0x390>
    8c9a:	3c fd                	cmp    $0xfd,%al
    8c9c:	0f 87 4b 01 00 00    	ja     8ded <f23+0x48d>
    8ca2:	83 c0 01             	add    $0x1,%eax
    8ca5:	88 07                	mov    %al,(%rdi)
    8ca7:	31 d2                	xor    %edx,%edx
    8ca9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8caf:	0f 85 57 fd ff ff    	jne    8a0c <f23+0xac>
    8cb5:	e9 73 fd ff ff       	jmp    8a2d <f23+0xcd>
    8cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cc0:	66 85 c0             	test   %ax,%ax
    8cc3:	0f 85 7c ff ff ff    	jne    8c45 <f23+0x2e5>
    8cc9:	e9 6b ff ff ff       	jmp    8c39 <f23+0x2d9>
    8cce:	66 90                	xchg   %ax,%ax
    8cd0:	66 85 c0             	test   %ax,%ax
    8cd3:	0f 85 12 fe ff ff    	jne    8aeb <f23+0x18b>
    8cd9:	e9 ff fd ff ff       	jmp    8add <f23+0x17d>
    8cde:	66 90                	xchg   %ax,%ax
    8ce0:	4c 89 e8             	mov    %r13,%rax
    8ce3:	e9 2d fd ff ff       	jmp    8a15 <f23+0xb5>
    8ce8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8cef:	00 
    8cf0:	48 83 05 f8 57 06 00 	addq   $0x1,0x657f8(%rip)        # 6e4f0 <iteration_retains>
    8cf7:	01 
    8cf8:	eb a0                	jmp    8c9a <f23+0x33a>
    8cfa:	48 f7 d9             	neg    %rcx
    8cfd:	48 39 d1             	cmp    %rdx,%rcx
    8d00:	0f 82 85 00 00 00    	jb     8d8b <f23+0x42b>
    8d06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d0d:	00 00 00 
    8d10:	be 02 00 00 00       	mov    $0x2,%esi
    8d15:	bf 08 00 00 00       	mov    $0x8,%edi
    8d1a:	e8 f1 d1 ff ff       	call   5f10 <fwp_heap_alloc>
    8d1f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8d26:	48 8b 15 eb 4e 06 00 	mov    0x64eeb(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8d2d:	49 89 c4             	mov    %rax,%r12
    8d30:	48 2b 05 b9 4e 06 00 	sub    0x64eb9(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8d37:	48 c1 e2 10          	shl    $0x10,%rdx
    8d3b:	48 39 d0             	cmp    %rdx,%rax
    8d3e:	0f 83 b3 00 00 00    	jae    8df7 <f23+0x497>
    8d44:	48 89 c2             	mov    %rax,%rdx
    8d47:	45 31 ed             	xor    %r13d,%r13d
    8d4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8d4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8d52:	48 8b 15 df 4e 06 00 	mov    0x64edf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8d59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d5d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8d61:	48 85 ed             	test   %rbp,%rbp
    8d64:	0f 84 e3 fd ff ff    	je     8b4d <f23+0x1ed>
    8d6a:	31 db                	xor    %ebx,%ebx
    8d6c:	e9 42 fd ff ff       	jmp    8ab3 <f23+0x153>
    8d71:	48 89 df             	mov    %rbx,%rdi
    8d74:	e8 57 ca ff ff       	call   57d0 <fwp_rc_forget_slot>
    8d79:	e9 c4 fe ff ff       	jmp    8c42 <f23+0x2e2>
    8d7e:	48 89 ef             	mov    %rbp,%rdi
    8d81:	e8 4a ca ff ff       	call   57d0 <fwp_rc_forget_slot>
    8d86:	e9 5c fd ff ff       	jmp    8ae7 <f23+0x187>
    8d8b:	48 89 c8             	mov    %rcx,%rax
    8d8e:	48 c1 e8 10          	shr    $0x10,%rax
    8d92:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8d96:	48 8b 05 9b 4e 06 00 	mov    0x64e9b(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    8d9d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8da1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8da5:	48 85 ff             	test   %rdi,%rdi
    8da8:	0f 84 62 ff ff ff    	je     8d10 <f23+0x3b0>
    8dae:	0f b6 02             	movzbl (%rdx),%eax
    8db1:	3c 02                	cmp    $0x2,%al
    8db3:	74 4a                	je     8dff <f23+0x49f>
    8db5:	3c 01                	cmp    $0x1,%al
    8db7:	0f 85 53 ff ff ff    	jne    8d10 <f23+0x3b0>
    8dbd:	0f b7 c1             	movzwl %cx,%eax
    8dc0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8dc3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8dc6:	48 0f af c1          	imul   %rcx,%rax
    8dca:	48 c1 e8 20          	shr    $0x20,%rax
    8dce:	48 39 d0             	cmp    %rdx,%rax
    8dd1:	0f 83 39 ff ff ff    	jae    8d10 <f23+0x3b0>
    8dd7:	48 01 c7             	add    %rax,%rdi
    8dda:	0f b6 07             	movzbl (%rdi),%eax
    8ddd:	84 c0                	test   %al,%al
    8ddf:	0f 84 2b ff ff ff    	je     8d10 <f23+0x3b0>
    8de5:	45 31 ed             	xor    %r13d,%r13d
    8de8:	e9 a3 fe ff ff       	jmp    8c90 <f23+0x330>
    8ded:	e8 be c8 ff ff       	call   56b0 <fwp_rc_wide_dup>
    8df2:	e9 b0 fe ff ff       	jmp    8ca7 <f23+0x347>
    8df7:	45 31 ed             	xor    %r13d,%r13d
    8dfa:	e9 4e fd ff ff       	jmp    8b4d <f23+0x1ed>
    8dff:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8e05:	49 89 cd             	mov    %rcx,%r13
    8e08:	0f 85 02 ff ff ff    	jne    8d10 <f23+0x3b0>
    8e0e:	0f b6 07             	movzbl (%rdi),%eax
    8e11:	84 c0                	test   %al,%al
    8e13:	0f 85 77 fe ff ff    	jne    8c90 <f23+0x330>
    8e19:	e9 f2 fe ff ff       	jmp    8d10 <f23+0x3b0>
    8e1e:	48 8d 3d c6 73 00 00 	lea    0x73c6(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    8e25:	e8 26 b6 ff ff       	call   4450 <fwp_trap>
    8e2a:	e8 21 a6 ff ff       	call   3450 <__stack_chk_fail@plt>
    8e2f:	90                   	nop

0000000000008e30 <fwp_owned_entry23>:
    8e30:	f3 0f 1e fa          	endbr64
    8e34:	48 8b 3f             	mov    (%rdi),%rdi
    8e37:	e9 24 fb ff ff       	jmp    8960 <f23>
    8e3c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008e40 <e23>:
    8e40:	f3 0f 1e fa          	endbr64
    8e44:	53                   	push   %rbx
    8e45:	48 8b 1f             	mov    (%rdi),%rbx
    8e48:	48 89 df             	mov    %rbx,%rdi
    8e4b:	e8 f0 e0 ff ff       	call   6f40 <fwp_rc_share>
    8e50:	48 89 df             	mov    %rbx,%rdi
    8e53:	e8 08 fb ff ff       	call   8960 <f23>
    8e58:	48 89 c3             	mov    %rax,%rbx
    8e5b:	48 89 c7             	mov    %rax,%rdi
    8e5e:	e8 dd e0 ff ff       	call   6f40 <fwp_rc_share>
    8e63:	48 89 d8             	mov    %rbx,%rax
    8e66:	5b                   	pop    %rbx
    8e67:	c3                   	ret
    8e68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8e6f:	00 

0000000000008e70 <f12>:
    8e70:	41 57                	push   %r15
    8e72:	41 56                	push   %r14
    8e74:	41 55                	push   %r13
    8e76:	41 54                	push   %r12
    8e78:	4c 8d 25 81 eb ff ff 	lea    -0x147f(%rip),%r12        # 7a00 <fwp_tape_scope_release>
    8e7f:	55                   	push   %rbp
    8e80:	53                   	push   %rbx
    8e81:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
    8e88:	48 8b 05 49 56 06 00 	mov    0x65649(%rip),%rax        # 6e4d8 <fwp_cleanups>
    8e8f:	48 8b 15 82 4d 06 00 	mov    0x64d82(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    8e96:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    8e9d:	00 00 
    8e9f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
    8ea6:	00 
    8ea7:	48 89 fd             	mov    %rdi,%rbp
    8eaa:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    8eb1:	ff 
    8eb2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    8eb7:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    8ebc:	48 c1 e2 10          	shl    $0x10,%rdx
    8ec0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8ec5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    8eca:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    8ecf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    8ed4:	48 89 05 fd 55 06 00 	mov    %rax,0x655fd(%rip)        # 6e4d8 <fwp_cleanups>
    8edb:	48 8d 05 2e b1 00 00 	lea    0xb12e(%rip),%rax        # 14010 <fc23>
    8ee2:	48 2b 05 07 4d 06 00 	sub    0x64d07(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    8ee9:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    8eee:	48 39 d0             	cmp    %rdx,%rax
    8ef1:	73 6d                	jae    8f60 <f12+0xf0>
    8ef3:	48 89 c2             	mov    %rax,%rdx
    8ef6:	48 c1 ea 10          	shr    $0x10,%rdx
    8efa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8efe:	48 8b 15 33 4d 06 00 	mov    0x64d33(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    8f05:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f09:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8f0d:	48 85 ff             	test   %rdi,%rdi
    8f10:	74 4e                	je     8f60 <f12+0xf0>
    8f12:	0f b6 0a             	movzbl (%rdx),%ecx
    8f15:	80 f9 02             	cmp    $0x2,%cl
    8f18:	0f 84 02 0f 00 00    	je     9e20 <f12+0xfb0>
    8f1e:	80 f9 01             	cmp    $0x1,%cl
    8f21:	75 3d                	jne    8f60 <f12+0xf0>
    8f23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f26:	0f b7 c0             	movzwl %ax,%eax
    8f29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f2c:	48 0f af c1          	imul   %rcx,%rax
    8f30:	48 c1 e8 20          	shr    $0x20,%rax
    8f34:	48 39 d0             	cmp    %rdx,%rax
    8f37:	73 27                	jae    8f60 <f12+0xf0>
    8f39:	48 01 c7             	add    %rax,%rdi
    8f3c:	0f b6 07             	movzbl (%rdi),%eax
    8f3f:	84 c0                	test   %al,%al
    8f41:	74 1d                	je     8f60 <f12+0xf0>
    8f43:	44 8b 05 be 55 06 00 	mov    0x655be(%rip),%r8d        # 6e508 <iteration_active>
    8f4a:	45 85 c0             	test   %r8d,%r8d
    8f4d:	0f 85 cd 0f 00 00    	jne    9f20 <f12+0x10b0>
    8f53:	3c fd                	cmp    $0xfd,%al
    8f55:	0f 87 72 11 00 00    	ja     a0cd <f12+0x125d>
    8f5b:	83 c0 01             	add    $0x1,%eax
    8f5e:	88 07                	mov    %al,(%rdi)
    8f60:	48 8d 3d a9 b0 00 00 	lea    0xb0a9(%rip),%rdi        # 14010 <fc23>
    8f67:	e8 24 e7 ff ff       	call   7690 <fwp_closure_drop>
    8f6c:	48 85 ed             	test   %rbp,%rbp
    8f6f:	0f 84 bc 10 00 00    	je     a031 <f12+0x11c1>
    8f75:	48 89 e8             	mov    %rbp,%rax
    8f78:	31 d2                	xor    %edx,%edx
    8f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f80:	48 8b 40 10          	mov    0x10(%rax),%rax
    8f84:	48 83 c2 01          	add    $0x1,%rdx
    8f88:	48 85 c0             	test   %rax,%rax
    8f8b:	75 f3                	jne    8f80 <f12+0x110>
    8f8d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8f94:	0f 87 ba 11 00 00    	ja     a154 <f12+0x12e4>
    8f9a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    8f9f:	8b 35 db b0 00 00    	mov    0xb0db(%rip),%esi        # 14080 <registered_finish.0>
    8fa5:	85 f6                	test   %esi,%esi
    8fa7:	0f 84 43 0e 00 00    	je     9df0 <f12+0xf80>
    8fad:	48 8b 1d 44 b1 01 00 	mov    0x1b144(%rip),%rbx        # 240f8 <fwp_tape_next_slot>
    8fb4:	4c 8b 2d 4d b1 01 00 	mov    0x1b14d(%rip),%r13        # 24108 <fwp_ntapes>
    8fbb:	4c 39 eb             	cmp    %r13,%rbx
    8fbe:	0f 8d d4 00 00 00    	jge    9098 <f12+0x228>
    8fc4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8fc8:	48 03 05 41 b1 01 00 	add    0x1b141(%rip),%rax        # 24110 <fwp_tapes>
    8fcf:	90                   	nop
    8fd0:	8b 48 04             	mov    0x4(%rax),%ecx
    8fd3:	85 c9                	test   %ecx,%ecx
    8fd5:	75 0c                	jne    8fe3 <f12+0x173>
    8fd7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    8fdd:	0f 86 b5 00 00 00    	jbe    9098 <f12+0x228>
    8fe3:	48 83 c3 01          	add    $0x1,%rbx
    8fe7:	48 83 c0 68          	add    $0x68,%rax
    8feb:	4c 39 eb             	cmp    %r13,%rbx
    8fee:	75 e0                	jne    8fd0 <f12+0x160>
    8ff0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    8ff7:	0f 8f d9 11 00 00    	jg     a1d6 <f12+0x1366>
    8ffd:	4c 39 2d fc b0 01 00 	cmp    %r13,0x1b0fc(%rip)        # 24100 <fwp_tapes_cap>
    9004:	4c 8b 3d 05 b1 01 00 	mov    0x1b105(%rip),%r15        # 24110 <fwp_tapes>
    900b:	75 4c                	jne    9059 <f12+0x1e9>
    900d:	4d 85 ed             	test   %r13,%r13
    9010:	0f 84 81 10 00 00    	je     a097 <f12+0x1227>
    9016:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    901b:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9020:	48 39 c3             	cmp    %rax,%rbx
    9023:	48 0f 4f d8          	cmovg  %rax,%rbx
    9027:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    902b:	31 d2                	xor    %edx,%edx
    902d:	4c 89 ff             	mov    %r15,%rdi
    9030:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9035:	e8 56 c1 ff ff       	call   5190 <ad_raw_realloc>
    903a:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    903f:	48 85 c0             	test   %rax,%rax
    9042:	49 89 c7             	mov    %rax,%r15
    9045:	0f 84 2d 11 00 00    	je     a178 <f12+0x1308>
    904b:	48 89 05 be b0 01 00 	mov    %rax,0x1b0be(%rip)        # 24110 <fwp_tapes>
    9052:	48 89 1d a7 b0 01 00 	mov    %rbx,0x1b0a7(%rip)        # 24100 <fwp_tapes_cap>
    9059:	49 6b c5 68          	imul   $0x68,%r13,%rax
    905d:	4c 89 eb             	mov    %r13,%rbx
    9060:	4c 01 f8             	add    %r15,%rax
    9063:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9067:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    906e:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9072:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    9079:	00 
    907a:	48 29 f8             	sub    %rdi,%rax
    907d:	8d 48 68             	lea    0x68(%rax),%ecx
    9080:	31 c0                	xor    %eax,%eax
    9082:	c1 e9 03             	shr    $0x3,%ecx
    9085:	f3 48 ab             	rep stos %rax,(%rdi)
    9088:	49 8d 45 01          	lea    0x1(%r13),%rax
    908c:	48 89 05 75 b0 01 00 	mov    %rax,0x1b075(%rip)        # 24108 <fwp_ntapes>
    9093:	eb 13                	jmp    90a8 <f12+0x238>
    9095:	0f 1f 00             	nopl   (%rax)
    9098:	49 39 dd             	cmp    %rbx,%r13
    909b:	0f 84 4f ff ff ff    	je     8ff0 <f12+0x180>
    90a1:	4c 8b 3d 68 b0 01 00 	mov    0x1b068(%rip),%r15        # 24110 <fwp_tapes>
    90a8:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    90ac:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    90b0:	48 8d 3d a9 70 00 00 	lea    0x70a9(%rip),%rdi        # 10160 <_IO_stdin_used+0x160>
    90b7:	0f 29 04 24          	movaps %xmm0,(%rsp)
    90bb:	4d 01 fe             	add    %r15,%r14
    90be:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    90c5:	00 
    90c6:	e8 c5 a2 ff ff       	call   3390 <getenv@plt>
    90cb:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    90d0:	48 85 c0             	test   %rax,%rax
    90d3:	74 09                	je     90de <f12+0x26e>
    90d5:	80 38 30             	cmpb   $0x30,(%rax)
    90d8:	0f 84 7a 06 00 00    	je     9758 <f12+0x8e8>
    90de:	48 83 3d c2 af 01 00 	cmpq   $0x0,0x1afc2(%rip)        # 240a8 <fwp_tape_cached_bytes>
    90e5:	00 
    90e6:	0f 85 94 0d 00 00    	jne    9e80 <f12+0x1010>
    90ec:	41 8b 06             	mov    (%r14),%eax
    90ef:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    90f3:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    90fa:	00 
    90fb:	4c 89 2d f6 af 01 00 	mov    %r13,0x1aff6(%rip)        # 240f8 <fwp_tape_next_slot>
    9102:	8d 70 01             	lea    0x1(%rax),%esi
    9105:	48 8b 05 cc 53 06 00 	mov    0x653cc(%rip),%rax        # 6e4d8 <fwp_cleanups>
    910c:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    9111:	41 89 36             	mov    %esi,(%r14)
    9114:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    911b:	00 
    911c:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    9123:	ff 
    9124:	48 85 c0             	test   %rax,%rax
    9127:	75 13                	jne    913c <f12+0x2cc>
    9129:	e9 b9 10 00 00       	jmp    a1e7 <f12+0x1377>
    912e:	66 90                	xchg   %ax,%ax
    9130:	48 8b 00             	mov    (%rax),%rax
    9133:	48 85 c0             	test   %rax,%rax
    9136:	0f 84 ab 10 00 00    	je     a1e7 <f12+0x1377>
    913c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    9140:	75 ee                	jne    9130 <f12+0x2c0>
    9142:	48 8b 50 10          	mov    0x10(%rax),%rdx
    9146:	89 d9                	mov    %ebx,%ecx
    9148:	48 63 02             	movslq (%rdx),%rax
    914b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    914f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    9153:	85 c0                	test   %eax,%eax
    9155:	78 09                	js     9160 <f12+0x2f0>
    9157:	48 6b c0 68          	imul   $0x68,%rax,%rax
    915b:	41 89 5c 07 58       	mov    %ebx,0x58(%r15,%rax,1)
    9160:	89 0a                	mov    %ecx,(%rdx)
    9162:	48 89 e8             	mov    %rbp,%rax
    9165:	31 c9                	xor    %ecx,%ecx
    9167:	48 85 ed             	test   %rbp,%rbp
    916a:	0f 84 00 0b 00 00    	je     9c70 <f12+0xe00>
    9170:	48 8b 40 10          	mov    0x10(%rax),%rax
    9174:	48 83 c1 01          	add    $0x1,%rcx
    9178:	48 85 c0             	test   %rax,%rax
    917b:	75 f3                	jne    9170 <f12+0x300>
    917d:	48 89 ea             	mov    %rbp,%rdx
    9180:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9184:	48 83 c0 01          	add    $0x1,%rax
    9188:	48 85 d2             	test   %rdx,%rdx
    918b:	75 f3                	jne    9180 <f12+0x310>
    918d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9194:	ff ff 1f 
    9197:	48 39 c2             	cmp    %rax,%rdx
    919a:	0f 82 06 10 00 00    	jb     a1a6 <f12+0x1336>
    91a0:	48 85 c9             	test   %rcx,%rcx
    91a3:	0f 8e c7 0a 00 00    	jle    9c70 <f12+0xe00>
    91a9:	48 39 c1             	cmp    %rax,%rcx
    91ac:	48 0f 46 c1          	cmovbe %rcx,%rax
    91b0:	49 89 c4             	mov    %rax,%r12
    91b3:	48 c1 e8 3c          	shr    $0x3c,%rax
    91b7:	0f 85 e9 0f 00 00    	jne    a1a6 <f12+0x1336>
    91bd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    91c1:	48 c1 e6 10          	shl    $0x10,%rsi
    91c5:	49 09 f5             	or     %rsi,%r13
    91c8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    91cf:	00 
    91d0:	be 02 00 00 00       	mov    $0x2,%esi
    91d5:	e8 36 cd ff ff       	call   5f10 <fwp_heap_alloc>
    91da:	4c 89 30             	mov    %r14,(%rax)
    91dd:	48 8b 15 34 4a 06 00 	mov    0x64a34(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    91e4:	48 89 c3             	mov    %rax,%rbx
    91e7:	48 2b 05 02 4a 06 00 	sub    0x64a02(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    91ee:	48 c1 e2 10          	shl    $0x10,%rdx
    91f2:	48 39 d0             	cmp    %rdx,%rax
    91f5:	0f 83 65 0d 00 00    	jae    9f60 <f12+0x10f0>
    91fb:	48 89 c2             	mov    %rax,%rdx
    91fe:	48 c1 ea 10          	shr    $0x10,%rdx
    9202:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9206:	48 8b 15 2b 4a 06 00 	mov    0x64a2b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    920d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9211:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9215:	4d 85 f6             	test   %r14,%r14
    9218:	74 38                	je     9252 <f12+0x3e2>
    921a:	0f b6 0a             	movzbl (%rdx),%ecx
    921d:	80 f9 02             	cmp    $0x2,%cl
    9220:	0f 84 b7 0a 00 00    	je     9cdd <f12+0xe6d>
    9226:	80 f9 01             	cmp    $0x1,%cl
    9229:	75 27                	jne    9252 <f12+0x3e2>
    922b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    922e:	0f b7 c0             	movzwl %ax,%eax
    9231:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9234:	48 0f af c1          	imul   %rcx,%rax
    9238:	48 c1 e8 20          	shr    $0x20,%rax
    923c:	48 39 d0             	cmp    %rdx,%rax
    923f:	73 11                	jae    9252 <f12+0x3e2>
    9241:	49 01 c6             	add    %rax,%r14
    9244:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9248:	0f 84 58 0e 00 00    	je     a0a6 <f12+0x1236>
    924e:	41 c6 06 01          	movb   $0x1,(%r14)
    9252:	4d 85 e4             	test   %r12,%r12
    9255:	74 5c                	je     92b3 <f12+0x443>
    9257:	4c 89 e9             	mov    %r13,%rcx
    925a:	48 89 ea             	mov    %rbp,%rdx
    925d:	31 c0                	xor    %eax,%eax
    925f:	48 c1 e1 20          	shl    $0x20,%rcx
    9263:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    926a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9271:	00 00 00 00 
    9275:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    927c:	00 00 00 00 
    9280:	48 89 c6             	mov    %rax,%rsi
    9283:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9288:	48 01 ce             	add    %rcx,%rsi
    928b:	0f 80 aa 0e 00 00    	jo     a13b <f12+0x12cb>
    9291:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    9296:	48 89 c6             	mov    %rax,%rsi
    9299:	48 83 c0 01          	add    $0x1,%rax
    929d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    92a1:	48 c1 e6 04          	shl    $0x4,%rsi
    92a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    92aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    92ae:	4c 39 e0             	cmp    %r12,%rax
    92b1:	72 cd                	jb     9280 <f12+0x410>
    92b3:	48 8b 03             	mov    (%rbx),%rax
    92b6:	48 d1 e8             	shr    $1,%rax
    92b9:	0f 85 49 0a 00 00    	jne    9d08 <f12+0xe98>
    92bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    92c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    92cd:	0f 1f 00             	nopl   (%rax)
    92d0:	48 89 df             	mov    %rbx,%rdi
    92d3:	4d 63 e5             	movslq %r13d,%r12
    92d6:	e8 e5 ec ff ff       	call   7fc0 <fwp_drop4>
    92db:	4c 89 e7             	mov    %r12,%rdi
    92de:	e8 4d b4 ff ff       	call   4730 <fwp_tape_of>
    92e3:	48 89 c6             	mov    %rax,%rsi
    92e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    92eb:	0f 85 d9 0e 00 00    	jne    a1ca <f12+0x135a>
    92f1:	48 89 c7             	mov    %rax,%rdi
    92f4:	e8 97 a9 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    92f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    92fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9302:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9309:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
    930d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9311:	66 49 0f 6e fe       	movq   %r14,%xmm7
    9316:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    931b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    9320:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    9324:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    9328:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    932e:	77 19                	ja     9349 <f12+0x4d9>
    9330:	41 0f b7 c5          	movzwl %r13w,%eax
    9334:	83 e8 01             	sub    $0x1,%eax
    9337:	48 98                	cltq
    9339:	48 3b 05 b8 ad 01 00 	cmp    0x1adb8(%rip),%rax        # 240f8 <fwp_tape_next_slot>
    9340:	7d 07                	jge    9349 <f12+0x4d9>
    9342:	48 89 05 af ad 01 00 	mov    %rax,0x1adaf(%rip)        # 240f8 <fwp_tape_next_slot>
    9349:	48 8b 05 88 51 06 00 	mov    0x65188(%rip),%rax        # 6e4d8 <fwp_cleanups>
    9350:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9354:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    935b:	00 
    935c:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9360:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9367:	00 
    9368:	48 8d 05 f1 be ff ff 	lea    -0x410f(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    936f:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    9376:	00 
    9377:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    937e:	00 
    937f:	48 89 04 24          	mov    %rax,(%rsp)
    9383:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    938a:	00 
    938b:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9392:	00 
    9393:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9397:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    939b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    93a2:	00 
    93a3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    93aa:	00 
    93ab:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    93b2:	00 
    93b3:	48 89 05 1e 51 06 00 	mov    %rax,0x6511e(%rip)        # 6e4d8 <fwp_cleanups>
    93ba:	0f 29 9c 24 a0 00 00 	movaps %xmm3,0xa0(%rsp)
    93c1:	00 
    93c2:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    93c9:	00 
    93ca:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    93d1:	00 
    93d2:	4d 85 ff             	test   %r15,%r15
    93d5:	0f 88 55 0a 00 00    	js     9e30 <f12+0xfc0>
    93db:	4c 89 f8             	mov    %r15,%rax
    93de:	48 c1 f8 20          	sar    $0x20,%rax
    93e2:	49 39 c4             	cmp    %rax,%r12
    93e5:	0f 85 44 0d 00 00    	jne    a12f <f12+0x12bf>
    93eb:	44 89 f9             	mov    %r15d,%ecx
    93ee:	49 89 cd             	mov    %rcx,%r13
    93f1:	48 39 ca             	cmp    %rcx,%rdx
    93f4:	0f 8e 29 0d 00 00    	jle    a123 <f12+0x12b3>
    93fa:	48 39 cb             	cmp    %rcx,%rbx
    93fd:	0f 8e 9d 09 00 00    	jle    9da0 <f12+0xf30>
    9403:	4c 39 f3             	cmp    %r14,%rbx
    9406:	0f 8e e4 0a 00 00    	jle    9ef0 <f12+0x1080>
    940c:	49 89 dc             	mov    %rbx,%r12
    940f:	4d 85 f6             	test   %r14,%r14
    9412:	4d 0f 44 f4          	cmove  %r12,%r14
    9416:	eb 1d                	jmp    9435 <f12+0x5c5>
    9418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    941f:	00 
    9420:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    9424:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    942b:	4c 89 e0             	mov    %r12,%rax
    942e:	48 0f 4c c2          	cmovl  %rdx,%rax
    9432:	49 89 c6             	mov    %rax,%r14
    9435:	4d 39 f4             	cmp    %r14,%r12
    9438:	7f e6                	jg     9420 <f12+0x5b0>
    943a:	4d 85 c0             	test   %r8,%r8
    943d:	0f 84 2d 0b 00 00    	je     9f70 <f12+0x1100>
    9443:	4c 89 c7             	mov    %r8,%rdi
    9446:	ba 03 00 00 00       	mov    $0x3,%edx
    944b:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9450:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    9457:	00 
    9458:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    945d:	e8 2e bd ff ff       	call   5190 <ad_raw_realloc>
    9462:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9468:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    946e:	48 85 c0             	test   %rax,%rax
    9471:	49 89 c0             	mov    %rax,%r8
    9474:	0f 84 a6 0b 00 00    	je     a020 <f12+0x11b0>
    947a:	4c 89 84 24 c0 00 00 	mov    %r8,0xc0(%rsp)
    9481:	00 
    9482:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9489:	00 
    948a:	4d 85 e4             	test   %r12,%r12
    948d:	0f 85 47 0c 00 00    	jne    a0da <f12+0x126a>
    9493:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    949a:	4d 85 ff             	test   %r15,%r15
    949d:	78 17                	js     94b6 <f12+0x646>
    949f:	44 89 f9             	mov    %r15d,%ecx
    94a2:	f2 0f 10 05 36 79 00 	movsd  0x7936(%rip),%xmm0        # 10de0 <msg.4+0xb0>
    94a9:	00 
    94aa:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    94b0:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    94b6:	4c 39 eb             	cmp    %r13,%rbx
    94b9:	0f 8f 92 00 00 00    	jg     9551 <f12+0x6e1>
    94bf:	0f 12 fb             	movhlps %xmm3,%xmm7
    94c2:	66 49 0f 7e d2       	movq   %xmm2,%r10
    94c7:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    94cc:	49 29 dd             	sub    %rbx,%r13
    94cf:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    94d4:	0f 12 fa             	movhlps %xmm2,%xmm7
    94d7:	49 8d 3c d8          	lea    (%r8,%rbx,8),%rdi
    94db:	66 49 0f 7e fb       	movq   %xmm7,%r11
    94e0:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    94e4:	66 0f ef d2          	pxor   %xmm2,%xmm2
    94e8:	48 29 f1             	sub    %rsi,%rcx
    94eb:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    94ef:	4c 29 df             	sub    %r11,%rdi
    94f2:	4d 29 da             	sub    %r11,%r10
    94f5:	eb 0d                	jmp    9504 <f12+0x694>
    94f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    94fe:	00 00 
    9500:	48 83 e8 04          	sub    $0x4,%rax
    9504:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    9509:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    950d:	7a 02                	jp     9511 <f12+0x6a1>
    950f:	74 37                	je     9548 <f12+0x6d8>
    9511:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    9515:	45 85 db             	test   %r11d,%r11d
    9518:	78 16                	js     9530 <f12+0x6c0>
    951a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    9520:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9524:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    952a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    9530:	4c 63 18             	movslq (%rax),%r11
    9533:	45 85 db             	test   %r11d,%r11d
    9536:	78 10                	js     9548 <f12+0x6d8>
    9538:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    953c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    9542:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    9548:	48 83 ea 08          	sub    $0x8,%rdx
    954c:	48 39 c6             	cmp    %rax,%rsi
    954f:	75 af                	jne    9500 <f12+0x690>
    9551:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9558:	ff ff 1f 
    955b:	48 39 d8             	cmp    %rbx,%rax
    955e:	0f 82 4e 0c 00 00    	jb     a1b2 <f12+0x1342>
    9564:	48 8d 3c dd 08 00 00 	lea    0x8(,%rbx,8),%rdi
    956b:	00 
    956c:	be 02 00 00 00       	mov    $0x2,%esi
    9571:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    9576:	e8 95 c9 ff ff       	call   5f10 <fwp_heap_alloc>
    957b:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    9580:	48 89 18             	mov    %rbx,(%rax)
    9583:	49 89 c4             	mov    %rax,%r12
    9586:	31 c0                	xor    %eax,%eax
    9588:	48 85 db             	test   %rbx,%rbx
    958b:	74 25                	je     95b2 <f12+0x742>
    958d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9594:	00 
    9595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    959c:	00 00 00 00 
    95a0:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    95a4:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    95a9:	48 83 c0 01          	add    $0x1,%rax
    95ad:	48 39 c3             	cmp    %rax,%rbx
    95b0:	75 ee                	jne    95a0 <f12+0x730>
    95b2:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    95b9:	00 
    95ba:	48 8b 3c 24          	mov    (%rsp),%rdi
    95be:	4c 89 2d 13 4f 06 00 	mov    %r13,0x64f13(%rip)        # 6e4d8 <fwp_cleanups>
    95c5:	e8 96 bc ff ff       	call   5260 <fwp_tape_buffers_release>
    95ca:	48 8b 15 47 46 06 00 	mov    0x64647(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    95d1:	4c 89 e0             	mov    %r12,%rax
    95d4:	48 2b 05 15 46 06 00 	sub    0x64615(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    95db:	48 c1 e2 10          	shl    $0x10,%rdx
    95df:	48 39 d0             	cmp    %rdx,%rax
    95e2:	73 55                	jae    9639 <f12+0x7c9>
    95e4:	48 89 c2             	mov    %rax,%rdx
    95e7:	48 c1 ea 10          	shr    $0x10,%rdx
    95eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    95ef:	48 8b 15 42 46 06 00 	mov    0x64642(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    95f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    95fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    95fe:	48 85 db             	test   %rbx,%rbx
    9601:	74 36                	je     9639 <f12+0x7c9>
    9603:	0f b6 0a             	movzbl (%rdx),%ecx
    9606:	80 f9 02             	cmp    $0x2,%cl
    9609:	0f 84 51 08 00 00    	je     9e60 <f12+0xff0>
    960f:	80 f9 01             	cmp    $0x1,%cl
    9612:	75 25                	jne    9639 <f12+0x7c9>
    9614:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9617:	0f b7 c0             	movzwl %ax,%eax
    961a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    961d:	48 0f af c1          	imul   %rcx,%rax
    9621:	48 c1 e8 20          	shr    $0x20,%rax
    9625:	48 39 d0             	cmp    %rdx,%rax
    9628:	73 0f                	jae    9639 <f12+0x7c9>
    962a:	48 01 c3             	add    %rax,%rbx
    962d:	80 3b ff             	cmpb   $0xff,(%rbx)
    9630:	0f 84 7d 0a 00 00    	je     a0b3 <f12+0x1243>
    9636:	c6 03 01             	movb   $0x1,(%rbx)
    9639:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    963e:	0f 85 07 a1 ff ff    	jne    374b <f12.cold>
    9644:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9649:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    964e:	48 89 05 83 4e 06 00 	mov    %rax,0x64e83(%rip)        # 6e4d8 <fwp_cleanups>
    9655:	e8 a6 e3 ff ff       	call   7a00 <fwp_tape_scope_release>
    965a:	49 8b 04 24          	mov    (%r12),%rax
    965e:	49 89 c6             	mov    %rax,%r14
    9661:	49 0f ba f6 3f       	btr    $0x3f,%r14
    9666:	48 85 c0             	test   %rax,%rax
    9669:	0f 88 51 05 00 00    	js     9bc0 <f12+0xd50>
    966f:	48 8b 15 a2 45 06 00 	mov    0x645a2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9676:	4c 89 e0             	mov    %r12,%rax
    9679:	48 2b 05 70 45 06 00 	sub    0x64570(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9680:	48 c1 e2 10          	shl    $0x10,%rdx
    9684:	48 39 d0             	cmp    %rdx,%rax
    9687:	0f 83 33 05 00 00    	jae    9bc0 <f12+0xd50>
    968d:	48 89 c2             	mov    %rax,%rdx
    9690:	48 c1 ea 10          	shr    $0x10,%rdx
    9694:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9698:	48 8b 15 99 45 06 00 	mov    0x64599(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    969f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    96a3:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    96a7:	48 85 c9             	test   %rcx,%rcx
    96aa:	0f 84 10 05 00 00    	je     9bc0 <f12+0xd50>
    96b0:	0f b6 32             	movzbl (%rdx),%esi
    96b3:	40 80 fe 02          	cmp    $0x2,%sil
    96b7:	0f 84 f3 04 00 00    	je     9bb0 <f12+0xd40>
    96bd:	40 80 fe 01          	cmp    $0x1,%sil
    96c1:	0f 85 f9 04 00 00    	jne    9bc0 <f12+0xd50>
    96c7:	8b 72 18             	mov    0x18(%rdx),%esi
    96ca:	0f b7 c0             	movzwl %ax,%eax
    96cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    96d0:	48 0f af c6          	imul   %rsi,%rax
    96d4:	48 c1 e8 20          	shr    $0x20,%rax
    96d8:	48 39 d0             	cmp    %rdx,%rax
    96db:	0f 83 df 04 00 00    	jae    9bc0 <f12+0xd50>
    96e1:	48 01 c1             	add    %rax,%rcx
    96e4:	80 39 01             	cmpb   $0x1,(%rcx)
    96e7:	0f 85 d3 04 00 00    	jne    9bc0 <f12+0xd50>
    96ed:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
    96f2:	4d 89 e5             	mov    %r12,%r13
    96f5:	31 ff                	xor    %edi,%edi
    96f7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    96fc:	f2 0f 10 0d f4 76 00 	movsd  0x76f4(%rip),%xmm1        # 10df8 <msg.4+0xc8>
    9703:	00 
    9704:	48 8d 50 08          	lea    0x8(%rax),%rdx
    9708:	31 c0                	xor    %eax,%eax
    970a:	4d 85 f6             	test   %r14,%r14
    970d:	75 2f                	jne    973e <f12+0x8ce>
    970f:	eb 5f                	jmp    9770 <f12+0x900>
    9711:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9718:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    971d:	0f 88 1d 0a 00 00    	js     a140 <f12+0x12d0>
    9723:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    9728:	48 83 c0 01          	add    $0x1,%rax
    972c:	48 83 c2 08          	add    $0x8,%rdx
    9730:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    9734:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    9739:	49 39 c6             	cmp    %rax,%r14
    973c:	74 32                	je     9770 <f12+0x900>
    973e:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    9743:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    9748:	79 ce                	jns    9718 <f12+0x8a8>
    974a:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    974f:	eb c7                	jmp    9718 <f12+0x8a8>
    9751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9758:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    975c:	0f 84 8a f9 ff ff    	je     90ec <f12+0x27c>
    9762:	e9 77 f9 ff ff       	jmp    90de <f12+0x26e>
    9767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    976e:	00 00 
    9770:	e8 4b e8 ff ff       	call   7fc0 <fwp_drop4>
    9775:	48 89 e8             	mov    %rbp,%rax
    9778:	31 d2                	xor    %edx,%edx
    977a:	48 85 ed             	test   %rbp,%rbp
    977d:	0f 84 b7 08 00 00    	je     a03a <f12+0x11ca>
    9783:	66 90                	xchg   %ax,%ax
    9785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    978c:	00 00 00 00 
    9790:	48 8b 40 10          	mov    0x10(%rax),%rax
    9794:	48 83 c2 01          	add    $0x1,%rdx
    9798:	48 85 c0             	test   %rax,%rax
    979b:	75 f3                	jne    9790 <f12+0x920>
    979d:	49 8b 45 00          	mov    0x0(%r13),%rax
    97a1:	49 89 c7             	mov    %rax,%r15
    97a4:	49 0f ba f7 3f       	btr    $0x3f,%r15
    97a9:	48 85 c0             	test   %rax,%rax
    97ac:	0f 88 60 03 00 00    	js     9b12 <f12+0xca2>
    97b2:	48 8b 05 5f 44 06 00 	mov    0x6445f(%rip),%rax        # 6dc18 <fwp_heap+0x13d8>
    97b9:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    97be:	48 2b 0d 2b 44 06 00 	sub    0x6442b(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    97c5:	48 c1 e0 10          	shl    $0x10,%rax
    97c9:	48 39 c1             	cmp    %rax,%rcx
    97cc:	0f 83 40 03 00 00    	jae    9b12 <f12+0xca2>
    97d2:	48 89 c8             	mov    %rcx,%rax
    97d5:	48 c1 e8 10          	shr    $0x10,%rax
    97d9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    97dd:	48 8b 05 54 44 06 00 	mov    0x64454(%rip),%rax        # 6dc38 <fwp_heap+0x13f8>
    97e4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    97e8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    97ec:	48 85 ff             	test   %rdi,%rdi
    97ef:	0f 84 1d 03 00 00    	je     9b12 <f12+0xca2>
    97f5:	0f b6 06             	movzbl (%rsi),%eax
    97f8:	3c 02                	cmp    $0x2,%al
    97fa:	0f 84 00 03 00 00    	je     9b00 <f12+0xc90>
    9800:	3c 01                	cmp    $0x1,%al
    9802:	0f 85 01 03 00 00    	jne    9b09 <f12+0xc99>
    9808:	8b 46 18             	mov    0x18(%rsi),%eax
    980b:	0f b7 c9             	movzwl %cx,%ecx
    980e:	48 0f af c8          	imul   %rax,%rcx
    9812:	8b 46 1c             	mov    0x1c(%rsi),%eax
    9815:	48 c1 e9 20          	shr    $0x20,%rcx
    9819:	48 39 c1             	cmp    %rax,%rcx
    981c:	0f 83 e7 02 00 00    	jae    9b09 <f12+0xc99>
    9822:	48 01 cf             	add    %rcx,%rdi
    9825:	80 3f 01             	cmpb   $0x1,(%rdi)
    9828:	0f 85 db 02 00 00    	jne    9b09 <f12+0xc99>
    982e:	49 39 d7             	cmp    %rdx,%r15
    9831:	48 89 d0             	mov    %rdx,%rax
    9834:	49 0f 46 c7          	cmovbe %r15,%rax
    9838:	48 85 c0             	test   %rax,%rax
    983b:	0f 84 0b 09 00 00    	je     a14c <f12+0x12dc>
    9841:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    9848:	00 
    9849:	4d 8d 75 08          	lea    0x8(%r13),%r14
    984d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    9852:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    9859:	00 
    985a:	48 89 e9             	mov    %rbp,%rcx
    985d:	31 d2                	xor    %edx,%edx
    985f:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    9863:	eb 38                	jmp    989d <f12+0xa2d>
    9865:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    986a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9871:	00 00 00 00 
    9875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    987c:	00 00 00 00 
    9880:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    9885:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    988a:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    9890:	48 83 c2 08          	add    $0x8,%rdx
    9894:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9898:	49 39 d0             	cmp    %rdx,%r8
    989b:	74 1b                	je     98b8 <f12+0xa48>
    989d:	48 89 fe             	mov    %rdi,%rsi
    98a0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    98a5:	79 d9                	jns    9880 <f12+0xa10>
    98a7:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
    98ac:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    98b0:	eb ce                	jmp    9880 <f12+0xa10>
    98b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98b8:	48 85 ed             	test   %rbp,%rbp
    98bb:	0f 84 5a 08 00 00    	je     a11b <f12+0x12ab>
    98c1:	4c 8b 05 50 43 06 00 	mov    0x64350(%rip),%r8        # 6dc18 <fwp_heap+0x13d8>
    98c8:	4c 8b 0d 21 43 06 00 	mov    0x64321(%rip),%r9        # 6dbf0 <fwp_heap+0x13b0>
    98cf:	48 89 e9             	mov    %rbp,%rcx
    98d2:	45 31 ed             	xor    %r13d,%r13d
    98d5:	4c 8b 15 5c 43 06 00 	mov    0x6435c(%rip),%r10        # 6dc38 <fwp_heap+0x13f8>
    98dc:	49 c1 e0 10          	shl    $0x10,%r8
    98e0:	eb 1c                	jmp    98fe <f12+0xa8e>
    98e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98e8:	49 83 c5 01          	add    $0x1,%r13
    98ec:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    98f0:	49 39 c5             	cmp    %rax,%r13
    98f3:	0f 83 67 01 00 00    	jae    9a60 <f12+0xbf0>
    98f9:	48 85 c9             	test   %rcx,%rcx
    98fc:	74 56                	je     9954 <f12+0xae4>
    98fe:	48 89 ca             	mov    %rcx,%rdx
    9901:	4c 29 ca             	sub    %r9,%rdx
    9904:	4c 39 c2             	cmp    %r8,%rdx
    9907:	73 4b                	jae    9954 <f12+0xae4>
    9909:	48 89 d6             	mov    %rdx,%rsi
    990c:	48 c1 ee 10          	shr    $0x10,%rsi
    9910:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    9914:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    9918:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    991c:	48 85 ff             	test   %rdi,%rdi
    991f:	74 33                	je     9954 <f12+0xae4>
    9921:	44 0f b6 1e          	movzbl (%rsi),%r11d
    9925:	41 80 fb 02          	cmp    $0x2,%r11b
    9929:	0f 84 19 01 00 00    	je     9a48 <f12+0xbd8>
    992f:	41 80 fb 01          	cmp    $0x1,%r11b
    9933:	75 1f                	jne    9954 <f12+0xae4>
    9935:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    9939:	0f b7 d2             	movzwl %dx,%edx
    993c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    993f:	49 0f af d3          	imul   %r11,%rdx
    9943:	48 c1 ea 20          	shr    $0x20,%rdx
    9947:	48 39 f2             	cmp    %rsi,%rdx
    994a:	73 08                	jae    9954 <f12+0xae4>
    994c:	48 01 d7             	add    %rdx,%rdi
    994f:	80 3f 01             	cmpb   $0x1,(%rdi)
    9952:	74 94                	je     98e8 <f12+0xa78>
    9954:	49 39 c5             	cmp    %rax,%r13
    9957:	0f 83 03 01 00 00    	jae    9a60 <f12+0xbf0>
    995d:	49 89 c7             	mov    %rax,%r15
    9960:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    9967:	00 
    9968:	45 31 e4             	xor    %r12d,%r12d
    996b:	48 89 04 24          	mov    %rax,(%rsp)
    996f:	48 8d 1d ca 2e 06 00 	lea    0x62eca(%rip),%rbx        # 6c840 <fwp_heap>
    9976:	eb 3a                	jmp    99b2 <f12+0xb42>
    9978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    997f:	00 
    9980:	41 80 f9 01          	cmp    $0x1,%r9b
    9984:	75 27                	jne    99ad <f12+0xb3d>
    9986:	45 8b 48 18          	mov    0x18(%r8),%r9d
    998a:	0f b7 c0             	movzwl %ax,%eax
    998d:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    9991:	49 0f af c1          	imul   %r9,%rax
    9995:	48 c1 e8 20          	shr    $0x20,%rax
    9999:	4c 39 c0             	cmp    %r8,%rax
    999c:	73 0f                	jae    99ad <f12+0xb3d>
    999e:	48 01 c7             	add    %rax,%rdi
    99a1:	80 3f ff             	cmpb   $0xff,(%rdi)
    99a4:	0f 84 46 03 00 00    	je     9cf0 <f12+0xe80>
    99aa:	c6 07 01             	movb   $0x1,(%rdi)
    99ad:	4d 39 fd             	cmp    %r15,%r13
    99b0:	73 7e                	jae    9a30 <f12+0xbc0>
    99b2:	49 83 ef 01          	sub    $0x1,%r15
    99b6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    99bb:	48 8b 34 24          	mov    (%rsp),%rsi
    99bf:	bf 01 00 00 00       	mov    $0x1,%edi
    99c4:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    99ca:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    99ce:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    99d5:	00 
    99d6:	e8 75 d3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    99db:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    99e2:	49 89 c4             	mov    %rax,%r12
    99e5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    99ec:	48 c1 e7 10          	shl    $0x10,%rdi
    99f0:	48 39 f8             	cmp    %rdi,%rax
    99f3:	73 b8                	jae    99ad <f12+0xb3d>
    99f5:	48 89 c7             	mov    %rax,%rdi
    99f8:	48 c1 ef 10          	shr    $0x10,%rdi
    99fc:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9a00:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9a07:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    9a0b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    9a0f:	48 85 ff             	test   %rdi,%rdi
    9a12:	74 99                	je     99ad <f12+0xb3d>
    9a14:	45 0f b6 08          	movzbl (%r8),%r9d
    9a18:	41 80 f9 02          	cmp    $0x2,%r9b
    9a1c:	0f 85 5e ff ff ff    	jne    9980 <f12+0xb10>
    9a22:	66 85 c0             	test   %ax,%ax
    9a25:	0f 84 76 ff ff ff    	je     99a1 <f12+0xb31>
    9a2b:	4d 39 fd             	cmp    %r15,%r13
    9a2e:	72 82                	jb     99b2 <f12+0xb42>
    9a30:	4d 85 ed             	test   %r13,%r13
    9a33:	75 2e                	jne    9a63 <f12+0xbf3>
    9a35:	8b 44 24 40          	mov    0x40(%rsp),%eax
    9a39:	85 c0                	test   %eax,%eax
    9a3b:	4d 0f 45 f5          	cmovne %r13,%r14
    9a3f:	eb 6f                	jmp    9ab0 <f12+0xc40>
    9a41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a48:	66 85 d2             	test   %dx,%dx
    9a4b:	0f 84 fe fe ff ff    	je     994f <f12+0xadf>
    9a51:	49 39 c5             	cmp    %rax,%r13
    9a54:	0f 82 03 ff ff ff    	jb     995d <f12+0xaed>
    9a5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a60:	45 31 e4             	xor    %r12d,%r12d
    9a63:	4c 89 f2             	mov    %r14,%rdx
    9a66:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    9a6a:	48 89 e8             	mov    %rbp,%rax
    9a6d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a74:	00 
    9a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a7c:	00 00 00 00 
    9a80:	48 8b 0a             	mov    (%rdx),%rcx
    9a83:	48 83 c2 08          	add    $0x8,%rdx
    9a87:	48 89 c7             	mov    %rax,%rdi
    9a8a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    9a8e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a92:	49 39 d0             	cmp    %rdx,%r8
    9a95:	75 e9                	jne    9a80 <f12+0xc10>
    9a97:	8b 54 24 40          	mov    0x40(%rsp),%edx
    9a9b:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    9a9f:	85 d2                	test   %edx,%edx
    9aa1:	0f 84 c9 03 00 00    	je     9e70 <f12+0x1000>
    9aa7:	49 89 ec             	mov    %rbp,%r12
    9aaa:	45 31 f6             	xor    %r14d,%r14d
    9aad:	48 89 c5             	mov    %rax,%rbp
    9ab0:	4c 89 f7             	mov    %r14,%rdi
    9ab3:	e8 58 bf ff ff       	call   5a10 <fwp_mem_free>
    9ab8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    9abd:	e8 fe e4 ff ff       	call   7fc0 <fwp_drop4>
    9ac2:	48 89 ef             	mov    %rbp,%rdi
    9ac5:	e8 d6 d8 ff ff       	call   73a0 <fwp_drop0>
    9aca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
    9ad1:	00 
    9ad2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ad9:	00 00 
    9adb:	0f 85 01 07 00 00    	jne    a1e2 <f12+0x1372>
    9ae1:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
    9ae8:	4c 89 e0             	mov    %r12,%rax
    9aeb:	5b                   	pop    %rbx
    9aec:	5d                   	pop    %rbp
    9aed:	41 5c                	pop    %r12
    9aef:	41 5d                	pop    %r13
    9af1:	41 5e                	pop    %r14
    9af3:	41 5f                	pop    %r15
    9af5:	c3                   	ret
    9af6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9afd:	00 00 00 
    9b00:	66 85 c9             	test   %cx,%cx
    9b03:	0f 84 1c fd ff ff    	je     9825 <f12+0x9b5>
    9b09:	48 85 ed             	test   %rbp,%rbp
    9b0c:	0f 84 1b 04 00 00    	je     9f2d <f12+0x10bd>
    9b12:	48 89 e8             	mov    %rbp,%rax
    9b15:	45 31 e4             	xor    %r12d,%r12d
    9b18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9b1f:	00 
    9b20:	48 8b 40 10          	mov    0x10(%rax),%rax
    9b24:	4c 89 e2             	mov    %r12,%rdx
    9b27:	49 83 c4 01          	add    $0x1,%r12
    9b2b:	48 85 c0             	test   %rax,%rax
    9b2e:	75 f0                	jne    9b20 <f12+0xcb0>
    9b30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9b37:	ff ff 1f 
    9b3a:	4c 39 e0             	cmp    %r12,%rax
    9b3d:	0f 82 63 06 00 00    	jb     a1a6 <f12+0x1336>
    9b43:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    9b4a:	00 
    9b4b:	be 02 00 00 00       	mov    $0x2,%esi
    9b50:	e8 bb c3 ff ff       	call   5f10 <fwp_heap_alloc>
    9b55:	4d 39 e7             	cmp    %r12,%r15
    9b58:	48 89 ea             	mov    %rbp,%rdx
    9b5b:	49 89 c6             	mov    %rax,%r14
    9b5e:	4c 89 e0             	mov    %r12,%rax
    9b61:	49 0f 46 c7          	cmovbe %r15,%rax
    9b65:	4c 89 f1             	mov    %r14,%rcx
    9b68:	66 90                	xchg   %ax,%ax
    9b6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b71:	00 00 00 00 
    9b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b7c:	00 00 00 00 
    9b80:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    9b84:	48 83 c1 08          	add    $0x8,%rcx
    9b88:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    9b8c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9b90:	48 85 d2             	test   %rdx,%rdx
    9b93:	75 eb                	jne    9b80 <f12+0xd10>
    9b95:	48 85 c0             	test   %rax,%rax
    9b98:	0f 84 a1 03 00 00    	je     9f3f <f12+0x10cf>
    9b9e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    9ba5:	00 
    9ba6:	e9 a2 fc ff ff       	jmp    984d <f12+0x9dd>
    9bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9bb0:	66 85 c0             	test   %ax,%ax
    9bb3:	0f 84 2b fb ff ff    	je     96e4 <f12+0x874>
    9bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9bc0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9bc7:	ff ff 1f 
    9bca:	4c 39 f0             	cmp    %r14,%rax
    9bcd:	0f 82 df 05 00 00    	jb     a1b2 <f12+0x1342>
    9bd3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9bda:	00 
    9bdb:	be 01 00 00 00       	mov    $0x1,%esi
    9be0:	e8 2b c3 ff ff       	call   5f10 <fwp_heap_alloc>
    9be5:	4c 89 30             	mov    %r14,(%rax)
    9be8:	48 8b 15 29 40 06 00 	mov    0x64029(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9bef:	49 89 c5             	mov    %rax,%r13
    9bf2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9bf7:	48 2b 05 f2 3f 06 00 	sub    0x63ff2(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9bfe:	48 c1 e2 10          	shl    $0x10,%rdx
    9c02:	48 39 d0             	cmp    %rdx,%rax
    9c05:	73 57                	jae    9c5e <f12+0xdee>
    9c07:	48 89 c2             	mov    %rax,%rdx
    9c0a:	48 c1 ea 10          	shr    $0x10,%rdx
    9c0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c12:	48 8b 15 1f 40 06 00 	mov    0x6401f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9c19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c1d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9c21:	4d 85 ff             	test   %r15,%r15
    9c24:	74 38                	je     9c5e <f12+0xdee>
    9c26:	0f b6 0a             	movzbl (%rdx),%ecx
    9c29:	80 f9 02             	cmp    $0x2,%cl
    9c2c:	0f 84 1e 03 00 00    	je     9f50 <f12+0x10e0>
    9c32:	80 f9 01             	cmp    $0x1,%cl
    9c35:	75 27                	jne    9c5e <f12+0xdee>
    9c37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c3a:	0f b7 c0             	movzwl %ax,%eax
    9c3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c40:	48 0f af c1          	imul   %rcx,%rax
    9c44:	48 c1 e8 20          	shr    $0x20,%rax
    9c48:	48 39 d0             	cmp    %rdx,%rax
    9c4b:	73 11                	jae    9c5e <f12+0xdee>
    9c4d:	49 01 c7             	add    %rax,%r15
    9c50:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9c54:	0f 84 66 04 00 00    	je     a0c0 <f12+0x1250>
    9c5a:	41 c6 07 01          	movb   $0x1,(%r15)
    9c5e:	4c 89 e7             	mov    %r12,%rdi
    9c61:	e9 91 fa ff ff       	jmp    96f7 <f12+0x887>
    9c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9c6d:	00 00 00 
    9c70:	48 c1 e6 10          	shl    $0x10,%rsi
    9c74:	bf 08 00 00 00       	mov    $0x8,%edi
    9c79:	49 09 f5             	or     %rsi,%r13
    9c7c:	be 02 00 00 00       	mov    $0x2,%esi
    9c81:	e8 8a c2 ff ff       	call   5f10 <fwp_heap_alloc>
    9c86:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9c8d:	48 8b 15 84 3f 06 00 	mov    0x63f84(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    9c94:	48 89 c3             	mov    %rax,%rbx
    9c97:	48 2b 05 52 3f 06 00 	sub    0x63f52(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    9c9e:	48 c1 e2 10          	shl    $0x10,%rdx
    9ca2:	48 39 d0             	cmp    %rdx,%rax
    9ca5:	0f 83 14 f6 ff ff    	jae    92bf <f12+0x44f>
    9cab:	48 89 c2             	mov    %rax,%rdx
    9cae:	48 c1 ea 10          	shr    $0x10,%rdx
    9cb2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9cb6:	48 8b 15 7b 3f 06 00 	mov    0x63f7b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    9cbd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9cc1:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9cc5:	4d 85 f6             	test   %r14,%r14
    9cc8:	0f 84 e5 f5 ff ff    	je     92b3 <f12+0x443>
    9cce:	0f b6 0a             	movzbl (%rdx),%ecx
    9cd1:	45 31 e4             	xor    %r12d,%r12d
    9cd4:	80 f9 02             	cmp    $0x2,%cl
    9cd7:	0f 85 49 f5 ff ff    	jne    9226 <f12+0x3b6>
    9cdd:	66 85 c0             	test   %ax,%ax
    9ce0:	0f 85 6c f5 ff ff    	jne    9252 <f12+0x3e2>
    9ce6:	e9 59 f5 ff ff       	jmp    9244 <f12+0x3d4>
    9ceb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9cf0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    9cf5:	e8 d6 ba ff ff       	call   57d0 <fwp_rc_forget_slot>
    9cfa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    9cff:	e9 a6 fc ff ff       	jmp    99aa <f12+0xb3a>
    9d04:	0f 1f 40 00          	nopl   0x0(%rax)
    9d08:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    9d0c:	4c 89 e1             	mov    %r12,%rcx
    9d0f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    9d13:	0f 85 8d 04 00 00    	jne    a1a6 <f12+0x1336>
    9d19:	4d 85 e4             	test   %r12,%r12
    9d1c:	0f 84 9d f5 ff ff    	je     92bf <f12+0x44f>
    9d22:	48 c1 e0 04          	shl    $0x4,%rax
    9d26:	4d 01 e4             	add    %r12,%r12
    9d29:	4c 8d 7b 08          	lea    0x8(%rbx),%r15
    9d2d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    9d32:	0f 1f 00             	nopl   (%rax)
    9d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d3c:	00 00 00 00 
    9d40:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    9d45:	49 8b 77 18          	mov    0x18(%r15),%rsi
    9d49:	49 83 c7 10          	add    $0x10,%r15
    9d4d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    9d51:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    9d56:	e8 f5 c9 ff ff       	call   6750 <w107>
    9d5b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    9d60:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    9d64:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    9d69:	4d 39 fe             	cmp    %r15,%r14
    9d6c:	75 d2                	jne    9d40 <f12+0xed0>
    9d6e:	4c 89 23             	mov    %r12,(%rbx)
    9d71:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    9d78:	45 31 f6             	xor    %r14d,%r14d
    9d7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d80:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    9d85:	4c 89 ff             	mov    %r15,%rdi
    9d88:	49 83 c6 02          	add    $0x2,%r14
    9d8c:	e8 3f c8 ff ff       	call   65d0 <f128.constprop.0>
    9d91:	49 89 c7             	mov    %rax,%r15
    9d94:	4d 39 e6             	cmp    %r12,%r14
    9d97:	72 e7                	jb     9d80 <f12+0xf10>
    9d99:	e9 32 f5 ff ff       	jmp    92d0 <f12+0x460>
    9d9e:	66 90                	xchg   %ax,%ax
    9da0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    9da4:	4d 39 e6             	cmp    %r12,%r14
    9da7:	0f 8c 62 f6 ff ff    	jl     940f <f12+0x59f>
    9dad:	4d 85 c0             	test   %r8,%r8
    9db0:	0f 84 aa 03 00 00    	je     a160 <f12+0x12f0>
    9db6:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    9dbb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9dc2:	00 
    9dc3:	31 f6                	xor    %esi,%esi
    9dc5:	4c 89 c7             	mov    %r8,%rdi
    9dc8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9dcd:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9dd2:	e8 d9 96 ff ff       	call   34b0 <memset@plt>
    9dd7:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9ddd:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9de3:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
    9de8:	49 89 c0             	mov    %rax,%r8
    9deb:	e9 b2 f6 ff ff       	jmp    94a2 <f12+0x632>
    9df0:	48 8d 3d e9 da ff ff 	lea    -0x2517(%rip),%rdi        # 78e0 <fwp_tape_finish>
    9df7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    9dfc:	e8 6f 59 00 00       	call   f770 <atexit>
    9e01:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9e06:	85 c0                	test   %eax,%eax
    9e08:	0f 85 6a 03 00 00    	jne    a178 <f12+0x1308>
    9e0e:	c7 05 68 a2 00 00 01 	movl   $0x1,0xa268(%rip)        # 14080 <registered_finish.0>
    9e15:	00 00 00 
    9e18:	e9 90 f1 ff ff       	jmp    8fad <f12+0x13d>
    9e1d:	0f 1f 00             	nopl   (%rax)
    9e20:	66 85 c0             	test   %ax,%ax
    9e23:	0f 85 37 f1 ff ff    	jne    8f60 <f12+0xf0>
    9e29:	e9 0e f1 ff ff       	jmp    8f3c <f12+0xcc>
    9e2e:	66 90                	xchg   %ax,%ax
    9e30:	4c 39 f3             	cmp    %r14,%rbx
    9e33:	0f 8f d3 f5 ff ff    	jg     940c <f12+0x59c>
    9e39:	48 85 db             	test   %rbx,%rbx
    9e3c:	74 12                	je     9e50 <f12+0xfe0>
    9e3e:	4d 85 c0             	test   %r8,%r8
    9e41:	0f 84 19 03 00 00    	je     a160 <f12+0x12f0>
    9e47:	48 85 db             	test   %rbx,%rbx
    9e4a:	0f 85 87 02 00 00    	jne    a0d7 <f12+0x1267>
    9e50:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    9e57:	e9 5a f6 ff ff       	jmp    94b6 <f12+0x646>
    9e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e60:	66 85 c0             	test   %ax,%ax
    9e63:	0f 85 d0 f7 ff ff    	jne    9639 <f12+0x7c9>
    9e69:	e9 bf f7 ff ff       	jmp    962d <f12+0x7bd>
    9e6e:	66 90                	xchg   %ax,%ax
    9e70:	49 89 ec             	mov    %rbp,%r12
    9e73:	48 89 c5             	mov    %rax,%rbp
    9e76:	e9 35 fc ff ff       	jmp    9ab0 <f12+0xc40>
    9e7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e80:	66 0f 6f 0d 38 a2 01 	movdqa 0x1a238(%rip),%xmm1        # 240c0 <fwp_tape_workspace>
    9e87:	00 
    9e88:	48 c7 05 15 a2 01 00 	movq   $0x0,0x1a215(%rip)        # 240a8 <fwp_tape_cached_bytes>
    9e8f:	00 00 00 00 
    9e93:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    9e98:	48 8b 05 41 a2 01 00 	mov    0x1a241(%rip),%rax        # 240e0 <fwp_tape_workspace+0x20>
    9e9f:	66 0f 6f 0d 29 a2 01 	movdqa 0x1a229(%rip),%xmm1        # 240d0 <fwp_tape_workspace+0x10>
    9ea6:	00 
    9ea7:	49 89 46 40          	mov    %rax,0x40(%r14)
    9eab:	48 8b 05 36 a2 01 00 	mov    0x1a236(%rip),%rax        # 240e8 <fwp_tape_workspace+0x28>
    9eb2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9eb7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9ebb:	49 89 46 18          	mov    %rax,0x18(%r14)
    9ebf:	48 8b 05 2a a2 01 00 	mov    0x1a22a(%rip),%rax        # 240f0 <fwp_tape_workspace+0x30>
    9ec6:	0f 29 0d f3 a1 01 00 	movaps %xmm1,0x1a1f3(%rip)        # 240c0 <fwp_tape_workspace>
    9ecd:	49 89 46 48          	mov    %rax,0x48(%r14)
    9ed1:	0f 29 0d f8 a1 01 00 	movaps %xmm1,0x1a1f8(%rip)        # 240d0 <fwp_tape_workspace+0x10>
    9ed8:	48 c7 05 0d a2 01 00 	movq   $0x0,0x1a20d(%rip)        # 240f0 <fwp_tape_workspace+0x30>
    9edf:	00 00 00 00 
    9ee3:	0f 29 0d f6 a1 01 00 	movaps %xmm1,0x1a1f6(%rip)        # 240e0 <fwp_tape_workspace+0x20>
    9eea:	e9 fd f1 ff ff       	jmp    90ec <f12+0x27c>
    9eef:	90                   	nop
    9ef0:	4d 85 c0             	test   %r8,%r8
    9ef3:	0f 84 67 02 00 00    	je     a160 <f12+0x12f0>
    9ef9:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
    9efe:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    9f02:	31 f6                	xor    %esi,%esi
    9f04:	4c 89 c7             	mov    %r8,%rdi
    9f07:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9f0c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9f13:	00 
    9f14:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9f19:	e9 b4 fe ff ff       	jmp    9dd2 <f12+0xf62>
    9f1e:	66 90                	xchg   %ax,%ax
    9f20:	48 83 05 c8 45 06 00 	addq   $0x1,0x645c8(%rip)        # 6e4f0 <iteration_retains>
    9f27:	01 
    9f28:	e9 26 f0 ff ff       	jmp    8f53 <f12+0xe3>
    9f2d:	be 02 00 00 00       	mov    $0x2,%esi
    9f32:	bf 08 00 00 00       	mov    $0x8,%edi
    9f37:	e8 d4 bf ff ff       	call   5f10 <fwp_heap_alloc>
    9f3c:	49 89 c6             	mov    %rax,%r14
    9f3f:	45 31 e4             	xor    %r12d,%r12d
    9f42:	e9 69 fb ff ff       	jmp    9ab0 <f12+0xc40>
    9f47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f4e:	00 00 
    9f50:	66 85 c0             	test   %ax,%ax
    9f53:	0f 85 05 fd ff ff    	jne    9c5e <f12+0xdee>
    9f59:	e9 f2 fc ff ff       	jmp    9c50 <f12+0xde0>
    9f5e:	66 90                	xchg   %ax,%ax
    9f60:	4d 85 e4             	test   %r12,%r12
    9f63:	0f 85 ee f2 ff ff    	jne    9257 <f12+0x3e7>
    9f69:	e9 51 f3 ff ff       	jmp    92bf <f12+0x44f>
    9f6e:	66 90                	xchg   %ax,%ax
    9f70:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9f77:	ff ff 1f 
    9f7a:	49 8d 46 ff          	lea    -0x1(%r14),%rax
    9f7e:	48 39 c2             	cmp    %rax,%rdx
    9f81:	0f 82 37 02 00 00    	jb     a1be <f12+0x134e>
    9f87:	48 8d 05 52 a2 04 00 	lea    0x4a252(%rip),%rax        # 541e0 <ad_raw_blocks>
    9f8e:	45 31 ed             	xor    %r13d,%r13d
    9f91:	eb 22                	jmp    9fb5 <f12+0x1145>
    9f93:	66 90                	xchg   %ax,%ax
    9f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f9c:	00 00 00 00 
    9fa0:	49 83 c5 01          	add    $0x1,%r13
    9fa4:	48 83 c0 18          	add    $0x18,%rax
    9fa8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    9faf:	0f 84 5a 01 00 00    	je     a10f <f12+0x129f>
    9fb5:	48 83 38 00          	cmpq   $0x0,(%rax)
    9fb9:	75 e5                	jne    9fa0 <f12+0x1130>
    9fbb:	be 08 00 00 00       	mov    $0x8,%esi
    9fc0:	4c 89 f7             	mov    %r14,%rdi
    9fc3:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    9fc8:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    9fcd:	e8 3e 95 ff ff       	call   3510 <calloc@plt>
    9fd2:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    9fd8:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    9fde:	48 8d 15 fb a1 04 00 	lea    0x4a1fb(%rip),%rdx        # 541e0 <ad_raw_blocks>
    9fe5:	48 85 c0             	test   %rax,%rax
    9fe8:	74 36                	je     a020 <f12+0x11b0>
    9fea:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    9fef:	48 89 c6             	mov    %rax,%rsi
    9ff2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    9ff7:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    9ffb:	b9 03 00 00 00       	mov    $0x3,%ecx
    a000:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    a007:	00 
    a008:	e8 f3 9b ff ff       	call   3c00 <ad_raw_record>
    a00d:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    a012:	e9 63 f4 ff ff       	jmp    947a <f12+0x60a>
    a017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a01e:	00 00 
    a020:	4d 85 e4             	test   %r12,%r12
    a023:	0f 85 37 01 00 00    	jne    a160 <f12+0x12f0>
    a029:	45 31 c0             	xor    %r8d,%r8d
    a02c:	e9 62 f4 ff ff       	jmp    9493 <f12+0x623>
    a031:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a035:	e9 65 ef ff ff       	jmp    8f9f <f12+0x12f>
    a03a:	49 8b 45 00          	mov    0x0(%r13),%rax
    a03e:	48 85 c0             	test   %rax,%rax
    a041:	0f 88 e6 fe ff ff    	js     9f2d <f12+0x10bd>
    a047:	48 8b 35 ca 3b 06 00 	mov    0x63bca(%rip),%rsi        # 6dc18 <fwp_heap+0x13d8>
    a04e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    a053:	48 2b 0d 96 3b 06 00 	sub    0x63b96(%rip),%rcx        # 6dbf0 <fwp_heap+0x13b0>
    a05a:	48 c1 e6 10          	shl    $0x10,%rsi
    a05e:	48 39 f1             	cmp    %rsi,%rcx
    a061:	0f 83 c6 fe ff ff    	jae    9f2d <f12+0x10bd>
    a067:	48 89 ce             	mov    %rcx,%rsi
    a06a:	48 c1 ee 10          	shr    $0x10,%rsi
    a06e:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a072:	48 8b 35 bf 3b 06 00 	mov    0x63bbf(%rip),%rsi        # 6dc38 <fwp_heap+0x13f8>
    a079:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a07d:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a081:	48 85 ff             	test   %rdi,%rdi
    a084:	0f 84 a3 fe ff ff    	je     9f2d <f12+0x10bd>
    a08a:	48 0f ba f0 3f       	btr    $0x3f,%rax
    a08f:	49 89 c7             	mov    %rax,%r15
    a092:	e9 5e f7 ff ff       	jmp    97f5 <f12+0x985>
    a097:	be 68 00 00 00       	mov    $0x68,%esi
    a09c:	bb 01 00 00 00       	mov    $0x1,%ebx
    a0a1:	e9 85 ef ff ff       	jmp    902b <f12+0x1bb>
    a0a6:	4c 89 f7             	mov    %r14,%rdi
    a0a9:	e8 22 b7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    a0ae:	e9 9b f1 ff ff       	jmp    924e <f12+0x3de>
    a0b3:	48 89 df             	mov    %rbx,%rdi
    a0b6:	e8 15 b7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    a0bb:	e9 76 f5 ff ff       	jmp    9636 <f12+0x7c6>
    a0c0:	4c 89 ff             	mov    %r15,%rdi
    a0c3:	e8 08 b7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    a0c8:	e9 8d fb ff ff       	jmp    9c5a <f12+0xdea>
    a0cd:	e8 de b5 ff ff       	call   56b0 <fwp_rc_wide_dup>
    a0d2:	e9 89 ee ff ff       	jmp    8f60 <f12+0xf0>
    a0d7:	49 89 dc             	mov    %rbx,%r12
    a0da:	4c 89 c7             	mov    %r8,%rdi
    a0dd:	31 f6                	xor    %esi,%esi
    a0df:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
    a0e4:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    a0e9:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a0f0:	00 
    a0f1:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
    a0f6:	e8 b5 93 ff ff       	call   34b0 <memset@plt>
    a0fb:	66 0f 6f 54 24 20    	movdqa 0x20(%rsp),%xmm2
    a101:	66 0f 6f 5c 24 30    	movdqa 0x30(%rsp),%xmm3
    a107:	49 89 c0             	mov    %rax,%r8
    a10a:	e9 8b f3 ff ff       	jmp    949a <f12+0x62a>
    a10f:	48 8d 3d fc 5f 00 00 	lea    0x5ffc(%rip),%rdi        # 10112 <_IO_stdin_used+0x112>
    a116:	e8 e5 9e ff ff       	call   4000 <ad_raw_fail>
    a11b:	45 31 ed             	xor    %r13d,%r13d
    a11e:	e9 3a f8 ff ff       	jmp    995d <f12+0xaed>
    a123:	48 8d 3d 98 60 00 00 	lea    0x6098(%rip),%rdi        # 101c2 <_IO_stdin_used+0x1c2>
    a12a:	e8 21 a3 ff ff       	call   4450 <fwp_trap>
    a12f:	48 8d 3d d2 68 00 00 	lea    0x68d2(%rip),%rdi        # 10a08 <_IO_stdin_used+0xa08>
    a136:	e8 15 a3 ff ff       	call   4450 <fwp_trap>
    a13b:	e8 c0 95 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    a140:	48 8d 3d c9 69 00 00 	lea    0x69c9(%rip),%rdi        # 10b10 <_IO_stdin_used+0xb10>
    a147:	e8 04 a3 ff ff       	call   4450 <fwp_trap>
    a14c:	45 31 f6             	xor    %r14d,%r14d
    a14f:	e9 eb fd ff ff       	jmp    9f3f <f12+0x10cf>
    a154:	48 8d 3d 9e 60 00 00 	lea    0x609e(%rip),%rdi        # 101f9 <_IO_stdin_used+0x1f9>
    a15b:	e8 f0 a2 ff ff       	call   4450 <fwp_trap>
    a160:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    a167:	00 
    a168:	48 8b 3c 24          	mov    (%rsp),%rdi
    a16c:	48 89 05 65 43 06 00 	mov    %rax,0x64365(%rip)        # 6e4d8 <fwp_cleanups>
    a173:	e8 e8 b0 ff ff       	call   5260 <fwp_tape_buffers_release>
    a178:	48 8b 0d e1 9e 00 00 	mov    0x9ee1(%rip),%rcx        # 14060 <stderr@GLIBC_2.2.5>
    a17f:	ba 13 00 00 00       	mov    $0x13,%edx
    a184:	be 01 00 00 00       	mov    $0x1,%esi
    a189:	48 8d 3d 78 5e 00 00 	lea    0x5e78(%rip),%rdi        # 10008 <_IO_stdin_used+0x8>
    a190:	e8 cb 94 ff ff       	call   3660 <fwrite@plt>
    a195:	31 ff                	xor    %edi,%edi
    a197:	e8 04 94 ff ff       	call   35a0 <fflush@plt>
    a19c:	bf 66 00 00 00       	mov    $0x66,%edi
    a1a1:	e8 da 94 ff ff       	call   3680 <_Exit@plt>
    a1a6:	48 8d 3d 3e 60 00 00 	lea    0x603e(%rip),%rdi        # 101eb <_IO_stdin_used+0x1eb>
    a1ad:	e8 9e a2 ff ff       	call   4450 <fwp_trap>
    a1b2:	48 8d 3d 76 60 00 00 	lea    0x6076(%rip),%rdi        # 1022f <_IO_stdin_used+0x22f>
    a1b9:	e8 92 a2 ff ff       	call   4450 <fwp_trap>
    a1be:	48 8d 3d 4e 60 00 00 	lea    0x604e(%rip),%rdi        # 10213 <_IO_stdin_used+0x213>
    a1c5:	e8 36 9e ff ff       	call   4000 <ad_raw_fail>
    a1ca:	48 8d 3d 7f 68 00 00 	lea    0x687f(%rip),%rdi        # 10a50 <_IO_stdin_used+0xa50>
    a1d1:	e8 7a a2 ff ff       	call   4450 <fwp_trap>
    a1d6:	48 8d 3d d3 68 00 00 	lea    0x68d3(%rip),%rdi        # 10ab0 <_IO_stdin_used+0xab0>
    a1dd:	e8 6e a2 ff ff       	call   4450 <fwp_trap>
    a1e2:	e8 69 92 ff ff       	call   3450 <__stack_chk_fail@plt>
    a1e7:	48 8d 3d f2 68 00 00 	lea    0x68f2(%rip),%rdi        # 10ae0 <_IO_stdin_used+0xae0>
    a1ee:	e8 5d a2 ff ff       	call   4450 <fwp_trap>
    a1f3:	66 90                	xchg   %ax,%ax
    a1f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1fc:	00 00 00 00 

000000000000a200 <fwp_owned_entry12>:
    a200:	f3 0f 1e fa          	endbr64
    a204:	48 8b 3f             	mov    (%rdi),%rdi
    a207:	e9 64 ec ff ff       	jmp    8e70 <f12>
    a20c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000000a210 <e12>:
    a210:	f3 0f 1e fa          	endbr64
    a214:	53                   	push   %rbx
    a215:	48 8b 1f             	mov    (%rdi),%rbx
    a218:	48 89 df             	mov    %rbx,%rdi
    a21b:	e8 20 cd ff ff       	call   6f40 <fwp_rc_share>
    a220:	48 89 df             	mov    %rbx,%rdi
    a223:	e8 48 ec ff ff       	call   8e70 <f12>
    a228:	48 89 c3             	mov    %rax,%rbx
    a22b:	48 89 c7             	mov    %rax,%rdi
    a22e:	e8 0d cd ff ff       	call   6f40 <fwp_rc_share>
    a233:	48 89 d8             	mov    %rbx,%rax
    a236:	5b                   	pop    %rbx
    a237:	c3                   	ret
    a238:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a23f:	00 

000000000000a240 <fwp_write>:
    a240:	41 57                	push   %r15
    a242:	41 56                	push   %r14
    a244:	41 55                	push   %r13
    a246:	41 54                	push   %r12
    a248:	55                   	push   %rbp
    a249:	53                   	push   %rbx
    a24a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    a251:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    a258:	00 00 
    a25a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    a261:	00 
    a262:	49 89 d4             	mov    %rdx,%r12
    a265:	8b 12                	mov    (%rdx),%edx
    a267:	83 fa 19             	cmp    $0x19,%edx
    a26a:	77 6a                	ja     a2d6 <fwp_write+0x96>
    a26c:	48 89 f5             	mov    %rsi,%rbp
    a26f:	89 d0                	mov    %edx,%eax
    a271:	89 ce                	mov    %ecx,%esi
    a273:	48 89 fb             	mov    %rdi,%rbx
    a276:	48 8d 0d 43 6a 00 00 	lea    0x6a43(%rip),%rcx        # 10cc0 <_IO_stdin_used+0xcc0>
    a27d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    a281:	48 01 c8             	add    %rcx,%rax
    a284:	3e ff e0             	notrack jmp *%rax
    a287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a28e:	00 00 
    a290:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    a294:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a298:	48 89 ca             	mov    %rcx,%rdx
    a29b:	48 85 c9             	test   %rcx,%rcx
    a29e:	0f 88 9c 0c 00 00    	js     af40 <fwp_write+0xd00>
    a2a4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2ab:	00 
    a2ac:	48 89 c6             	mov    %rax,%rsi
    a2af:	4c 89 e7             	mov    %r12,%rdi
    a2b2:	e8 89 97 ff ff       	call   3a40 <fwp_fmt_u128>
    a2b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2be:	00 00 
    a2c0:	4c 89 e7             	mov    %r12,%rdi
    a2c3:	e8 78 91 ff ff       	call   3440 <strlen@plt>
    a2c8:	4c 89 e6             	mov    %r12,%rsi
    a2cb:	48 89 df             	mov    %rbx,%rdi
    a2ce:	48 89 c2             	mov    %rax,%rdx
    a2d1:	e8 1a 9e ff ff       	call   40f0 <buf_put>
    a2d6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a2dd:	00 
    a2de:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a2e5:	00 00 
    a2e7:	0f 85 28 04 00 00    	jne    a715 <fwp_write+0x4d5>
    a2ed:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a2f4:	5b                   	pop    %rbx
    a2f5:	5d                   	pop    %rbp
    a2f6:	41 5c                	pop    %r12
    a2f8:	41 5d                	pop    %r13
    a2fa:	41 5e                	pop    %r14
    a2fc:	41 5f                	pop    %r15
    a2fe:	c3                   	ret
    a2ff:	90                   	nop
    a300:	49 89 e9             	mov    %rbp,%r9
    a303:	4c 8d 05 51 5f 00 00 	lea    0x5f51(%rip),%r8        # 1025b <_IO_stdin_used+0x25b>
    a30a:	b9 00 02 00 00       	mov    $0x200,%ecx
    a30f:	ba 02 00 00 00       	mov    $0x2,%edx
    a314:	be 00 02 00 00       	mov    $0x200,%esi
    a319:	31 c0                	xor    %eax,%eax
    a31b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a322:	00 
    a323:	e8 78 90 ff ff       	call   33a0 <__snprintf_chk@plt>
    a328:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a32f:	00 
    a330:	e8 0b 91 ff ff       	call   3440 <strlen@plt>
    a335:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a33c:	00 
    a33d:	48 89 df             	mov    %rbx,%rdi
    a340:	48 89 c2             	mov    %rax,%rdx
    a343:	e8 a8 9d ff ff       	call   40f0 <buf_put>
    a348:	eb 8c                	jmp    a2d6 <fwp_write+0x96>
    a34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a350:	49 89 e9             	mov    %rbp,%r9
    a353:	4c 8d 05 fc 5e 00 00 	lea    0x5efc(%rip),%r8        # 10256 <_IO_stdin_used+0x256>
    a35a:	eb ae                	jmp    a30a <fwp_write+0xca>
    a35c:	0f 1f 40 00          	nopl   0x0(%rax)
    a360:	83 fa 13             	cmp    $0x13,%edx
    a363:	48 8d 05 e2 5e 00 00 	lea    0x5ee2(%rip),%rax        # 1024c <_IO_stdin_used+0x24c>
    a36a:	48 8d 35 e0 5e 00 00 	lea    0x5ee0(%rip),%rsi        # 10251 <_IO_stdin_used+0x251>
    a371:	ba 04 00 00 00       	mov    $0x4,%edx
    a376:	48 0f 44 f0          	cmove  %rax,%rsi
    a37a:	45 31 ed             	xor    %r13d,%r13d
    a37d:	e8 6e 9d ff ff       	call   40f0 <buf_put>
    a382:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a387:	0f 84 a3 08 00 00    	je     ac30 <fwp_write+0x9f0>
    a38d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a392:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a397:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a39c:	48 89 df             	mov    %rbx,%rdi
    a39f:	49 0f 44 c5          	cmove  %r13,%rax
    a3a3:	31 c9                	xor    %ecx,%ecx
    a3a5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a3aa:	e8 91 fe ff ff       	call   a240 <fwp_write>
    a3af:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a3b4:	0f 84 6e 09 00 00    	je     ad28 <fwp_write+0xae8>
    a3ba:	49 83 c5 01          	add    $0x1,%r13
    a3be:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a3c2:	0f 83 68 08 00 00    	jae    ac30 <fwp_write+0x9f0>
    a3c8:	ba 02 00 00 00       	mov    $0x2,%edx
    a3cd:	48 8d 35 c7 5e 00 00 	lea    0x5ec7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a3d4:	48 89 df             	mov    %rbx,%rdi
    a3d7:	e8 14 9d ff ff       	call   40f0 <buf_put>
    a3dc:	eb af                	jmp    a38d <fwp_write+0x14d>
    a3de:	66 90                	xchg   %ax,%ax
    a3e0:	ba 06 00 00 00       	mov    $0x6,%edx
    a3e5:	48 8d 35 88 5e 00 00 	lea    0x5e88(%rip),%rsi        # 10274 <_IO_stdin_used+0x274>
    a3ec:	48 83 c5 10          	add    $0x10,%rbp
    a3f0:	e8 fb 9c ff ff       	call   40f0 <buf_put>
    a3f5:	48 89 ef             	mov    %rbp,%rdi
    a3f8:	e8 43 90 ff ff       	call   3440 <strlen@plt>
    a3fd:	48 89 ee             	mov    %rbp,%rsi
    a400:	48 89 df             	mov    %rbx,%rdi
    a403:	48 89 c2             	mov    %rax,%rdx
    a406:	e8 e5 9c ff ff       	call   40f0 <buf_put>
    a40b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a410:	ba 01 00 00 00       	mov    $0x1,%edx
    a415:	48 89 df             	mov    %rbx,%rdi
    a418:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a41d:	e8 ce 9c ff ff       	call   40f0 <buf_put>
    a422:	e9 af fe ff ff       	jmp    a2d6 <fwp_write+0x96>
    a427:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a42e:	00 00 
    a430:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a437:	00 
    a438:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a43f:	00 00 
    a441:	0f 85 ce 02 00 00    	jne    a715 <fwp_write+0x4d5>
    a447:	ba 0a 00 00 00       	mov    $0xa,%edx
    a44c:	48 8d 35 0d 5e 00 00 	lea    0x5e0d(%rip),%rsi        # 10260 <_IO_stdin_used+0x260>
    a453:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a45a:	48 89 df             	mov    %rbx,%rdi
    a45d:	5b                   	pop    %rbx
    a45e:	5d                   	pop    %rbp
    a45f:	41 5c                	pop    %r12
    a461:	41 5d                	pop    %r13
    a463:	41 5e                	pop    %r14
    a465:	41 5f                	pop    %r15
    a467:	e9 84 9c ff ff       	jmp    40f0 <buf_put>
    a46c:	0f 1f 40 00          	nopl   0x0(%rax)
    a470:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a475:	4d 85 ed             	test   %r13,%r13
    a478:	0f 84 02 0c 00 00    	je     b080 <fwp_write+0xe40>
    a47e:	48 8d 35 23 5e 00 00 	lea    0x5e23(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    a485:	4c 89 ef             	mov    %r13,%rdi
    a488:	e8 93 90 ff ff       	call   3520 <strcmp@plt>
    a48d:	41 89 c1             	mov    %eax,%r9d
    a490:	85 c0                	test   %eax,%eax
    a492:	0f 84 6c 0c 00 00    	je     b104 <fwp_write+0xec4>
    a498:	4c 89 ef             	mov    %r13,%rdi
    a49b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a4a0:	e8 9b 8f ff ff       	call   3440 <strlen@plt>
    a4a5:	4c 89 ee             	mov    %r13,%rsi
    a4a8:	48 89 df             	mov    %rbx,%rdi
    a4ab:	48 89 c2             	mov    %rax,%rdx
    a4ae:	e8 3d 9c ff ff       	call   40f0 <buf_put>
    a4b3:	ba 01 00 00 00       	mov    $0x1,%edx
    a4b8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a4bd:	48 89 df             	mov    %rbx,%rdi
    a4c0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a4c5:	e8 26 9c ff ff       	call   40f0 <buf_put>
    a4ca:	ba 01 00 00 00       	mov    $0x1,%edx
    a4cf:	4c 89 fe             	mov    %r15,%rsi
    a4d2:	48 89 df             	mov    %rbx,%rdi
    a4d5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a4da:	e8 11 9c ff ff       	call   40f0 <buf_put>
    a4df:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a4e4:	45 31 f6             	xor    %r14d,%r14d
    a4e7:	85 d2                	test   %edx,%edx
    a4e9:	0f 8e 81 0a 00 00    	jle    af70 <fwp_write+0xd30>
    a4ef:	45 31 ed             	xor    %r13d,%r13d
    a4f2:	4d 85 ed             	test   %r13,%r13
    a4f5:	0f 85 75 07 00 00    	jne    ac70 <fwp_write+0xa30>
    a4fb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a502:	00 
    a503:	45 85 f6             	test   %r14d,%r14d
    a506:	0f 84 84 07 00 00    	je     ac90 <fwp_write+0xa50>
    a50c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a511:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a516:	48 89 df             	mov    %rbx,%rdi
    a519:	49 83 c5 01          	add    $0x1,%r13
    a51d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a521:	31 c9                	xor    %ecx,%ecx
    a523:	e8 18 fd ff ff       	call   a240 <fwp_write>
    a528:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a52d:	7f c3                	jg     a4f2 <fwp_write+0x2b2>
    a52f:	45 85 f6             	test   %r14d,%r14d
    a532:	0f 84 38 0a 00 00    	je     af70 <fwp_write+0xd30>
    a538:	b8 29 00 00 00       	mov    $0x29,%eax
    a53d:	ba 01 00 00 00       	mov    $0x1,%edx
    a542:	4c 89 fe             	mov    %r15,%rsi
    a545:	48 89 df             	mov    %rbx,%rdi
    a548:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a54c:	e8 9f 9b ff ff       	call   40f0 <buf_put>
    a551:	e9 80 fd ff ff       	jmp    a2d6 <fwp_write+0x96>
    a556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a55d:	00 00 00 
    a560:	ba 01 00 00 00       	mov    $0x1,%edx
    a565:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a56a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a56f:	e8 7c 9b ff ff       	call   40f0 <buf_put>
    a574:	48 85 ed             	test   %rbp,%rbp
    a577:	0f 84 93 06 00 00    	je     ac10 <fwp_write+0x9d0>
    a57d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a581:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a586:	31 c9                	xor    %ecx,%ecx
    a588:	48 89 df             	mov    %rbx,%rdi
    a58b:	e8 b0 fc ff ff       	call   a240 <fwp_write>
    a590:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a594:	48 85 ed             	test   %rbp,%rbp
    a597:	0f 84 73 06 00 00    	je     ac10 <fwp_write+0x9d0>
    a59d:	ba 02 00 00 00       	mov    $0x2,%edx
    a5a2:	48 8d 35 f2 5c 00 00 	lea    0x5cf2(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a5a9:	48 89 df             	mov    %rbx,%rdi
    a5ac:	e8 3f 9b ff ff       	call   40f0 <buf_put>
    a5b1:	eb ca                	jmp    a57d <fwp_write+0x33d>
    a5b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a5b8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a5bc:	85 f6                	test   %esi,%esi
    a5be:	0f 84 fc 07 00 00    	je     adc0 <fwp_write+0xb80>
    a5c4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a5cb:	00 
    a5cc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a5d3:	00 00 
    a5d5:	0f 85 3a 01 00 00    	jne    a715 <fwp_write+0x4d5>
    a5db:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a5df:	4c 89 ea             	mov    %r13,%rdx
    a5e2:	e9 6c fe ff ff       	jmp    a453 <fwp_write+0x213>
    a5e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a5ee:	00 00 
    a5f0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a5f5:	ba 01 00 00 00       	mov    $0x1,%edx
    a5fa:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a5ff:	48 89 ee             	mov    %rbp,%rsi
    a602:	e8 e9 9a ff ff       	call   40f0 <buf_put>
    a607:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a60c:	4c 89 e7             	mov    %r12,%rdi
    a60f:	e8 2c 8e ff ff       	call   3440 <strlen@plt>
    a614:	4c 89 e6             	mov    %r12,%rsi
    a617:	48 89 df             	mov    %rbx,%rdi
    a61a:	48 89 c2             	mov    %rax,%rdx
    a61d:	e8 ce 9a ff ff       	call   40f0 <buf_put>
    a622:	ba 01 00 00 00       	mov    $0x1,%edx
    a627:	48 89 ee             	mov    %rbp,%rsi
    a62a:	48 89 df             	mov    %rbx,%rdi
    a62d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a632:	e8 b9 9a ff ff       	call   40f0 <buf_put>
    a637:	e9 9a fc ff ff       	jmp    a2d6 <fwp_write+0x96>
    a63c:	0f 1f 40 00          	nopl   0x0(%rax)
    a640:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a645:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a649:	0f 8a 8e 0b 00 00    	jp     b1dd <fwp_write+0xf9d>
    a64f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a653:	66 0f 54 05 65 67 00 	andpd  0x6765(%rip),%xmm0        # 10dc0 <msg.4+0x90>
    a65a:	00 
    a65b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a660:	66 0f 2e 05 98 67 00 	ucomisd 0x6798(%rip),%xmm0        # 10e00 <msg.4+0xd0>
    a667:	00 
    a668:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a66f:	00 
    a670:	0f 87 b2 09 00 00    	ja     b028 <fwp_write+0xde8>
    a676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a67d:	00 00 00 
    a680:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a684:	89 ee                	mov    %ebp,%esi
    a686:	4c 89 e7             	mov    %r12,%rdi
    a689:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a68e:	e8 dd a0 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a693:	31 f6                	xor    %esi,%esi
    a695:	4c 89 e7             	mov    %r12,%rdi
    a698:	e8 63 8d ff ff       	call   3400 <strtod@plt>
    a69d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a6a2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a6a6:	7a 06                	jp     a6ae <fwp_write+0x46e>
    a6a8:	0f 84 e9 01 00 00    	je     a897 <fwp_write+0x657>
    a6ae:	83 c5 01             	add    $0x1,%ebp
    a6b1:	83 fd 12             	cmp    $0x12,%ebp
    a6b4:	75 ca                	jne    a680 <fwp_write+0x440>
    a6b6:	be 11 00 00 00       	mov    $0x11,%esi
    a6bb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a6bf:	4c 89 e7             	mov    %r12,%rdi
    a6c2:	e8 a9 a0 ff ff       	call   4770 <fwp_format_g.constprop.0>
    a6c7:	e9 cb 01 00 00       	jmp    a897 <fwp_write+0x657>
    a6cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a6d0:	48 83 fd 01          	cmp    $0x1,%rbp
    a6d4:	0f 84 e6 08 00 00    	je     afc0 <fwp_write+0xd80>
    a6da:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a6de:	b8 02 00 00 00       	mov    $0x2,%eax
    a6e3:	ba 01 00 00 00       	mov    $0x1,%edx
    a6e8:	48 0f 44 d0          	cmove  %rax,%rdx
    a6ec:	48 8d 35 51 5b 00 00 	lea    0x5b51(%rip),%rsi        # 10244 <_IO_stdin_used+0x244>
    a6f3:	48 8d 05 4f 5b 00 00 	lea    0x5b4f(%rip),%rax        # 10249 <_IO_stdin_used+0x249>
    a6fa:	48 0f 44 f0          	cmove  %rax,%rsi
    a6fe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a705:	00 
    a706:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a70d:	00 00 
    a70f:	0f 84 3e fd ff ff    	je     a453 <fwp_write+0x213>
    a715:	e8 36 8d ff ff       	call   3450 <__stack_chk_fail@plt>
    a71a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a720:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a725:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a72a:	e8 01 99 ff ff       	call   4030 <buf_grow>
    a72f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a733:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a739:	4c 03 0b             	add    (%rbx),%r9
    a73c:	66 45 89 11          	mov    %r10w,(%r9)
    a740:	45 85 e4             	test   %r12d,%r12d
    a743:	0f 8e 07 05 00 00    	jle    ac50 <fwp_write+0xa10>
    a749:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a750:	55 55 55 
    a753:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a758:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a75f:	aa aa aa 
    a762:	49 83 c1 01          	add    $0x1,%r9
    a766:	eb 45                	jmp    a7ad <fwp_write+0x56d>
    a768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a76f:	00 
    a770:	be 01 00 00 00       	mov    $0x1,%esi
    a775:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a77a:	88 07                	mov    %al,(%rdi)
    a77c:	48 89 e8             	mov    %rbp,%rax
    a77f:	49 f7 e8             	imul   %r8
    a782:	48 89 e8             	mov    %rbp,%rax
    a785:	48 c1 f8 3f          	sar    $0x3f,%rax
    a789:	48 29 c2             	sub    %rax,%rdx
    a78c:	48 85 c9             	test   %rcx,%rcx
    a78f:	0f 95 c0             	setne  %al
    a792:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a796:	48 83 ef 01          	sub    $0x1,%rdi
    a79a:	48 21 c5             	and    %rax,%rbp
    a79d:	48 29 ea             	sub    %rbp,%rdx
    a7a0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a7a4:	49 39 f9             	cmp    %rdi,%r9
    a7a7:	0f 84 a3 04 00 00    	je     ac50 <fwp_write+0xa10>
    a7ad:	48 89 e8             	mov    %rbp,%rax
    a7b0:	49 f7 e8             	imul   %r8
    a7b3:	48 89 e8             	mov    %rbp,%rax
    a7b6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a7ba:	48 89 d1             	mov    %rdx,%rcx
    a7bd:	48 29 c1             	sub    %rax,%rcx
    a7c0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a7c4:	48 89 e9             	mov    %rbp,%rcx
    a7c7:	48 29 c1             	sub    %rax,%rcx
    a7ca:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a7ce:	49 f7 e2             	mul    %r10
    a7d1:	b8 30 00 00 00       	mov    $0x30,%eax
    a7d6:	48 89 d6             	mov    %rdx,%rsi
    a7d9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a7dd:	48 d1 ee             	shr    $1,%rsi
    a7e0:	48 01 f2             	add    %rsi,%rdx
    a7e3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a7e7:	48 29 d6             	sub    %rdx,%rsi
    a7ea:	74 8e                	je     a77a <fwp_write+0x53a>
    a7ec:	48 83 fe 01          	cmp    $0x1,%rsi
    a7f0:	0f 85 7a ff ff ff    	jne    a770 <fwp_write+0x530>
    a7f6:	31 f6                	xor    %esi,%esi
    a7f8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a7fd:	e9 78 ff ff ff       	jmp    a77a <fwp_write+0x53a>
    a802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a808:	66 0f 6e cd          	movd   %ebp,%xmm1
    a80c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a80f:	0f 8a c8 09 00 00    	jp     b1dd <fwp_write+0xf9d>
    a815:	0f 28 c1             	movaps %xmm1,%xmm0
    a818:	0f 54 05 91 65 00 00 	andps  0x6591(%rip),%xmm0        # 10db0 <msg.4+0x80>
    a81f:	0f 2e 05 de 57 00 00 	ucomiss 0x57de(%rip),%xmm0        # 10004 <_IO_stdin_used+0x4>
    a826:	0f 87 24 08 00 00    	ja     b050 <fwp_write+0xe10>
    a82c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a830:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a836:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a83d:	00 
    a83e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a842:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a84e:	00 00 
    a850:	44 89 ee             	mov    %r13d,%esi
    a853:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a858:	4c 89 e7             	mov    %r12,%rdi
    a85b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a860:	e8 0b 9f ff ff       	call   4770 <fwp_format_g.constprop.0>
    a865:	31 f6                	xor    %esi,%esi
    a867:	4c 89 e7             	mov    %r12,%rdi
    a86a:	e8 31 8c ff ff       	call   34a0 <strtof@plt>
    a86f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a874:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a877:	7a 02                	jp     a87b <fwp_write+0x63b>
    a879:	74 1c                	je     a897 <fwp_write+0x657>
    a87b:	41 83 c5 01          	add    $0x1,%r13d
    a87f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a883:	75 cb                	jne    a850 <fwp_write+0x610>
    a885:	be 09 00 00 00       	mov    $0x9,%esi
    a88a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a88f:	4c 89 e7             	mov    %r12,%rdi
    a892:	e8 d9 9e ff ff       	call   4770 <fwp_format_g.constprop.0>
    a897:	4c 89 e7             	mov    %r12,%rdi
    a89a:	e8 11 99 ff ff       	call   41b0 <fwp_finish_float>
    a89f:	e9 1c fa ff ff       	jmp    a2c0 <fwp_write+0x80>
    a8a4:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a8ac:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a8b0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a8b7:	00 
    a8b8:	48 89 ef             	mov    %rbp,%rdi
    a8bb:	e8 80 91 ff ff       	call   3a40 <fwp_fmt_u128>
    a8c0:	48 89 ef             	mov    %rbp,%rdi
    a8c3:	e8 78 8b ff ff       	call   3440 <strlen@plt>
    a8c8:	48 89 ee             	mov    %rbp,%rsi
    a8cb:	48 89 df             	mov    %rbx,%rdi
    a8ce:	48 89 c2             	mov    %rax,%rdx
    a8d1:	e8 1a 98 ff ff       	call   40f0 <buf_put>
    a8d6:	e9 fb f9 ff ff       	jmp    a2d6 <fwp_write+0x96>
    a8db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a8e0:	ba 06 00 00 00       	mov    $0x6,%edx
    a8e5:	48 8d 35 b2 59 00 00 	lea    0x59b2(%rip),%rsi        # 1029e <_IO_stdin_used+0x29e>
    a8ec:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a8f2:	e8 f9 97 ff ff       	call   40f0 <buf_put>
    a8f7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a8fe:	ff ff 7f 
    a901:	48 23 55 00          	and    0x0(%rbp),%rdx
    a905:	0f 84 86 02 00 00    	je     ab91 <fwp_write+0x951>
    a90b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a910:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a914:	48 85 d2             	test   %rdx,%rdx
    a917:	0f 84 ae 00 00 00    	je     a9cb <fwp_write+0x78b>
    a91d:	8b 0a                	mov    (%rdx),%ecx
    a91f:	83 f9 1c             	cmp    $0x1c,%ecx
    a922:	0f 84 58 06 00 00    	je     af80 <fwp_write+0xd40>
    a928:	83 f9 1b             	cmp    $0x1b,%ecx
    a92b:	0f 87 9a 00 00 00    	ja     a9cb <fwp_write+0x78b>
    a931:	be 01 00 00 00       	mov    $0x1,%esi
    a936:	48 d3 e6             	shl    %cl,%rsi
    a939:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a93f:	0f 85 4b 04 00 00    	jne    ad90 <fwp_write+0xb50>
    a945:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a94b:	0f 85 0f 04 00 00    	jne    ad60 <fwp_write+0xb20>
    a951:	83 e6 21             	and    $0x21,%esi
    a954:	74 75                	je     a9cb <fwp_write+0x78b>
    a956:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a95b:	48 85 ff             	test   %rdi,%rdi
    a95e:	79 07                	jns    a967 <fwp_write+0x727>
    a960:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a964:	4c 01 ee             	add    %r13,%rsi
    a967:	48 0f be 3e          	movsbq (%rsi),%rdi
    a96b:	85 c9                	test   %ecx,%ecx
    a96d:	40 0f b6 f7          	movzbl %dil,%esi
    a971:	48 0f 44 f7          	cmove  %rdi,%rsi
    a975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a97c:	00 00 00 00 
    a980:	31 c9                	xor    %ecx,%ecx
    a982:	48 89 df             	mov    %rbx,%rdi
    a985:	49 83 c5 01          	add    $0x1,%r13
    a989:	e8 b2 f8 ff ff       	call   a240 <fwp_write>
    a98e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a995:	ff ff 7f 
    a998:	48 23 55 00          	and    0x0(%rbp),%rdx
    a99c:	49 39 d5             	cmp    %rdx,%r13
    a99f:	0f 83 ec 01 00 00    	jae    ab91 <fwp_write+0x951>
    a9a5:	ba 02 00 00 00       	mov    $0x2,%edx
    a9aa:	48 89 df             	mov    %rbx,%rdi
    a9ad:	48 8d 35 e7 58 00 00 	lea    0x58e7(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    a9b4:	e8 37 97 ff ff       	call   40f0 <buf_put>
    a9b9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a9be:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a9c2:	48 85 d2             	test   %rdx,%rdx
    a9c5:	0f 85 52 ff ff ff    	jne    a91d <fwp_write+0x6dd>
    a9cb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a9d0:	48 85 ff             	test   %rdi,%rdi
    a9d3:	0f 88 cf 05 00 00    	js     afa8 <fwp_write+0xd68>
    a9d9:	48 8b 31             	mov    (%rcx),%rsi
    a9dc:	eb a2                	jmp    a980 <fwp_write+0x740>
    a9de:	66 90                	xchg   %ax,%ax
    a9e0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a9e7:	00 
    a9e8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a9ef:	00 00 
    a9f1:	0f 85 1e fd ff ff    	jne    a715 <fwp_write+0x4d5>
    a9f7:	ba 08 00 00 00       	mov    $0x8,%edx
    a9fc:	48 8d 35 68 58 00 00 	lea    0x5868(%rip),%rsi        # 1026b <_IO_stdin_used+0x26b>
    aa03:	e9 4b fa ff ff       	jmp    a453 <fwp_write+0x213>
    aa08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa0f:	00 
    aa10:	89 e8                	mov    %ebp,%eax
    aa12:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    aa19:	76 03                	jbe    aa1e <fwp_write+0x7de>
    aa1b:	8b 45 00             	mov    0x0(%rbp),%eax
    aa1e:	41 89 c6             	mov    %eax,%r14d
    aa21:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    aa26:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    aa2b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    aa2f:	4c 89 ef             	mov    %r13,%rdi
    aa32:	e8 09 8a ff ff       	call   3440 <strlen@plt>
    aa37:	4c 89 ee             	mov    %r13,%rsi
    aa3a:	48 89 df             	mov    %rbx,%rdi
    aa3d:	48 89 c2             	mov    %rax,%rdx
    aa40:	e8 ab 96 ff ff       	call   40f0 <buf_put>
    aa45:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    aa4a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    aa4e:	85 f6                	test   %esi,%esi
    aa50:	0f 8e 80 f8 ff ff    	jle    a2d6 <fwp_write+0x96>
    aa56:	45 31 ed             	xor    %r13d,%r13d
    aa59:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aa5e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    aa63:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    aa68:	ba 01 00 00 00       	mov    $0x1,%edx
    aa6d:	4c 89 fe             	mov    %r15,%rsi
    aa70:	48 89 04 24          	mov    %rax,(%rsp)
    aa74:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    aa79:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    aa7d:	48 89 df             	mov    %rbx,%rdi
    aa80:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    aa84:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    aa89:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    aa8e:	e8 5d 96 ff ff       	call   40f0 <buf_put>
    aa93:	41 8b 06             	mov    (%r14),%eax
    aa96:	83 f8 0e             	cmp    $0xe,%eax
    aa99:	0f 84 71 02 00 00    	je     ad10 <fwp_write+0xad0>
    aa9f:	83 f8 10             	cmp    $0x10,%eax
    aaa2:	0f 84 38 02 00 00    	je     ace0 <fwp_write+0xaa0>
    aaa8:	83 f8 0a             	cmp    $0xa,%eax
    aaab:	0f 84 7f 04 00 00    	je     af30 <fwp_write+0xcf0>
    aab1:	0f 8f f9 00 00 00    	jg     abb0 <fwp_write+0x970>
    aab7:	83 f8 03             	cmp    $0x3,%eax
    aaba:	0f 8f 50 04 00 00    	jg     af10 <fwp_write+0xcd0>
    aac0:	85 c0                	test   %eax,%eax
    aac2:	78 10                	js     aad4 <fwp_write+0x894>
    aac4:	48 8b 04 24          	mov    (%rsp),%rax
    aac8:	48 c1 e8 3f          	shr    $0x3f,%rax
    aacc:	85 c0                	test   %eax,%eax
    aace:	0f 85 f9 00 00 00    	jne    abcd <fwp_write+0x98d>
    aad4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    aad9:	48 8b 34 24          	mov    (%rsp),%rsi
    aadd:	31 c9                	xor    %ecx,%ecx
    aadf:	48 89 df             	mov    %rbx,%rdi
    aae2:	e8 59 f7 ff ff       	call   a240 <fwp_write>
    aae7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    aaec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    aaf1:	49 83 c5 01          	add    $0x1,%r13
    aaf5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    aaf9:	0f 8f 5f ff ff ff    	jg     aa5e <fwp_write+0x81e>
    aaff:	e9 d2 f7 ff ff       	jmp    a2d6 <fwp_write+0x96>
    ab04:	0f 1f 40 00          	nopl   0x0(%rax)
    ab08:	ba 06 00 00 00       	mov    $0x6,%edx
    ab0d:	48 8d 35 7d 57 00 00 	lea    0x577d(%rip),%rsi        # 10291 <_IO_stdin_used+0x291>
    ab14:	45 31 ed             	xor    %r13d,%r13d
    ab17:	e8 d4 95 ff ff       	call   40f0 <buf_put>
    ab1c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    ab21:	75 19                	jne    ab3c <fwp_write+0x8fc>
    ab23:	eb 6c                	jmp    ab91 <fwp_write+0x951>
    ab25:	0f 1f 00             	nopl   (%rax)
    ab28:	ba 02 00 00 00       	mov    $0x2,%edx
    ab2d:	48 8d 35 67 57 00 00 	lea    0x5767(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    ab34:	48 89 df             	mov    %rbx,%rdi
    ab37:	e8 b4 95 ff ff       	call   40f0 <buf_put>
    ab3c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    ab42:	b9 00 02 00 00       	mov    $0x200,%ecx
    ab47:	31 c0                	xor    %eax,%eax
    ab49:	49 83 c5 01          	add    $0x1,%r13
    ab4d:	4c 8d 05 44 57 00 00 	lea    0x5744(%rip),%r8        # 10298 <_IO_stdin_used+0x298>
    ab54:	ba 02 00 00 00       	mov    $0x2,%edx
    ab59:	be 00 02 00 00       	mov    $0x200,%esi
    ab5e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab65:	00 
    ab66:	e8 35 88 ff ff       	call   33a0 <__snprintf_chk@plt>
    ab6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ab72:	00 
    ab73:	e8 c8 88 ff ff       	call   3440 <strlen@plt>
    ab78:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ab7f:	00 
    ab80:	48 89 df             	mov    %rbx,%rdi
    ab83:	48 89 c2             	mov    %rax,%rdx
    ab86:	e8 65 95 ff ff       	call   40f0 <buf_put>
    ab8b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    ab8f:	72 97                	jb     ab28 <fwp_write+0x8e8>
    ab91:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab96:	ba 01 00 00 00       	mov    $0x1,%edx
    ab9b:	48 89 df             	mov    %rbx,%rdi
    ab9e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    aba3:	e8 48 95 ff ff       	call   40f0 <buf_put>
    aba8:	e9 29 f7 ff ff       	jmp    a2d6 <fwp_write+0x96>
    abad:	0f 1f 00             	nopl   (%rax)
    abb0:	83 f8 0b             	cmp    $0xb,%eax
    abb3:	0f 85 1b ff ff ff    	jne    aad4 <fwp_write+0x894>
    abb9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    abbe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    abc2:	83 e0 01             	and    $0x1,%eax
    abc5:	85 c0                	test   %eax,%eax
    abc7:	0f 84 07 ff ff ff    	je     aad4 <fwp_write+0x894>
    abcd:	4c 89 fe             	mov    %r15,%rsi
    abd0:	48 89 df             	mov    %rbx,%rdi
    abd3:	ba 01 00 00 00       	mov    $0x1,%edx
    abd8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    abdd:	e8 0e 95 ff ff       	call   40f0 <buf_put>
    abe2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    abe7:	48 8b 34 24          	mov    (%rsp),%rsi
    abeb:	31 c9                	xor    %ecx,%ecx
    abed:	48 89 df             	mov    %rbx,%rdi
    abf0:	e8 4b f6 ff ff       	call   a240 <fwp_write>
    abf5:	ba 01 00 00 00       	mov    $0x1,%edx
    abfa:	4c 89 fe             	mov    %r15,%rsi
    abfd:	48 89 df             	mov    %rbx,%rdi
    ac00:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    ac05:	e8 e6 94 ff ff       	call   40f0 <buf_put>
    ac0a:	e9 d8 fe ff ff       	jmp    aae7 <fwp_write+0x8a7>
    ac0f:	90                   	nop
    ac10:	ba 01 00 00 00       	mov    $0x1,%edx
    ac15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ac1a:	48 89 df             	mov    %rbx,%rdi
    ac1d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    ac22:	e8 c9 94 ff ff       	call   40f0 <buf_put>
    ac27:	e9 aa f6 ff ff       	jmp    a2d6 <fwp_write+0x96>
    ac2c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac30:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ac35:	ba 01 00 00 00       	mov    $0x1,%edx
    ac3a:	48 89 df             	mov    %rbx,%rdi
    ac3d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    ac42:	e8 a9 94 ff ff       	call   40f0 <buf_put>
    ac47:	e9 8a f6 ff ff       	jmp    a2d6 <fwp_write+0x96>
    ac4c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac50:	48 8b 43 08          	mov    0x8(%rbx),%rax
    ac54:	48 8b 13             	mov    (%rbx),%rdx
    ac57:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    ac5c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    ac60:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    ac64:	e9 6d f6 ff ff       	jmp    a2d6 <fwp_write+0x96>
    ac69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac70:	ba 02 00 00 00       	mov    $0x2,%edx
    ac75:	48 8d 35 1f 56 00 00 	lea    0x561f(%rip),%rsi        # 1029b <_IO_stdin_used+0x29b>
    ac7c:	48 89 df             	mov    %rbx,%rdi
    ac7f:	e8 6c 94 ff ff       	call   40f0 <buf_put>
    ac84:	e9 72 f8 ff ff       	jmp    a4fb <fwp_write+0x2bb>
    ac89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac90:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    ac95:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    ac9a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    ac9e:	48 89 f7             	mov    %rsi,%rdi
    aca1:	48 89 34 24          	mov    %rsi,(%rsp)
    aca5:	e8 96 87 ff ff       	call   3440 <strlen@plt>
    acaa:	48 8b 34 24          	mov    (%rsp),%rsi
    acae:	48 89 df             	mov    %rbx,%rdi
    acb1:	48 89 c2             	mov    %rax,%rdx
    acb4:	e8 37 94 ff ff       	call   40f0 <buf_put>
    acb9:	ba 03 00 00 00       	mov    $0x3,%edx
    acbe:	48 8d 35 f9 55 00 00 	lea    0x55f9(%rip),%rsi        # 102be <_IO_stdin_used+0x2be>
    acc5:	48 89 df             	mov    %rbx,%rdi
    acc8:	e8 23 94 ff ff       	call   40f0 <buf_put>
    accd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    acd2:	e9 35 f8 ff ff       	jmp    a50c <fwp_write+0x2cc>
    acd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acde:	00 00 
    ace0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ace5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ace9:	48 85 ff             	test   %rdi,%rdi
    acec:	0f 84 e2 fd ff ff    	je     aad4 <fwp_write+0x894>
    acf2:	48 8d 35 af 55 00 00 	lea    0x55af(%rip),%rsi        # 102a8 <_IO_stdin_used+0x2a8>
    acf9:	e8 22 88 ff ff       	call   3520 <strcmp@plt>
    acfe:	85 c0                	test   %eax,%eax
    ad00:	0f 95 c0             	setne  %al
    ad03:	0f b6 c0             	movzbl %al,%eax
    ad06:	e9 c1 fd ff ff       	jmp    aacc <fwp_write+0x88c>
    ad0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad10:	31 c0                	xor    %eax,%eax
    ad12:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    ad19:	00 
    ad1a:	0f 97 c0             	seta   %al
    ad1d:	e9 aa fd ff ff       	jmp    aacc <fwp_write+0x88c>
    ad22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad28:	48 89 df             	mov    %rbx,%rdi
    ad2b:	ba 02 00 00 00       	mov    $0x2,%edx
    ad30:	48 8d 35 6e 55 00 00 	lea    0x556e(%rip),%rsi        # 102a5 <_IO_stdin_used+0x2a5>
    ad37:	e8 b4 93 ff ff       	call   40f0 <buf_put>
    ad3c:	4c 89 e8             	mov    %r13,%rax
    ad3f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ad44:	31 c9                	xor    %ecx,%ecx
    ad46:	48 c1 e0 04          	shl    $0x4,%rax
    ad4a:	48 89 df             	mov    %rbx,%rdi
    ad4d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    ad52:	e8 e9 f4 ff ff       	call   a240 <fwp_write>
    ad57:	e9 5e f6 ff ff       	jmp    a3ba <fwp_write+0x17a>
    ad5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad60:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    ad65:	48 85 ff             	test   %rdi,%rdi
    ad68:	79 0c                	jns    ad76 <fwp_write+0xb36>
    ad6a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    ad71:	00 
    ad72:	48 03 75 10          	add    0x10(%rbp),%rsi
    ad76:	48 63 3e             	movslq (%rsi),%rdi
    ad79:	83 f9 02             	cmp    $0x2,%ecx
    ad7c:	89 fe                	mov    %edi,%esi
    ad7e:	48 0f 44 f7          	cmove  %rdi,%rsi
    ad82:	e9 f9 fb ff ff       	jmp    a980 <fwp_write+0x740>
    ad87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ad8e:	00 00 
    ad90:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    ad95:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    ad9a:	48 85 ff             	test   %rdi,%rdi
    ad9d:	0f 88 0f 03 00 00    	js     b0b2 <fwp_write+0xe72>
    ada3:	49 0f bf 38          	movswq (%r8),%rdi
    ada7:	83 f9 01             	cmp    $0x1,%ecx
    adaa:	0f b7 f7             	movzwl %di,%esi
    adad:	48 0f 44 f7          	cmove  %rdi,%rsi
    adb1:	e9 ca fb ff ff       	jmp    a980 <fwp_write+0x740>
    adb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adbd:	00 00 00 
    adc0:	ba 01 00 00 00       	mov    $0x1,%edx
    adc5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    adca:	48 83 c5 08          	add    $0x8,%rbp
    adce:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    add3:	e8 18 93 ff ff       	call   40f0 <buf_put>
    add8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    addd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    ade2:	4d 85 ed             	test   %r13,%r13
    ade5:	75 46                	jne    ae2d <fwp_write+0xbed>
    ade7:	e9 04 01 00 00       	jmp    aef0 <fwp_write+0xcb0>
    adec:	0f 1f 40 00          	nopl   0x0(%rax)
    adf0:	41 80 f9 09          	cmp    $0x9,%r9b
    adf4:	0f 84 d6 00 00 00    	je     aed0 <fwp_write+0xc90>
    adfa:	41 80 f9 0a          	cmp    $0xa,%r9b
    adfe:	0f 85 9c 00 00 00    	jne    aea0 <fwp_write+0xc60>
    ae04:	ba 02 00 00 00       	mov    $0x2,%edx
    ae09:	48 8d 35 71 54 00 00 	lea    0x5471(%rip),%rsi        # 10281 <_IO_stdin_used+0x281>
    ae10:	48 89 df             	mov    %rbx,%rdi
    ae13:	e8 d8 92 ff ff       	call   40f0 <buf_put>
    ae18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ae1f:	00 
    ae20:	48 83 c5 01          	add    $0x1,%rbp
    ae24:	49 39 ec             	cmp    %rbp,%r12
    ae27:	0f 84 c3 00 00 00    	je     aef0 <fwp_write+0xcb0>
    ae2d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    ae32:	41 80 f9 0d          	cmp    $0xd,%r9b
    ae36:	74 28                	je     ae60 <fwp_write+0xc20>
    ae38:	7e b6                	jle    adf0 <fwp_write+0xbb0>
    ae3a:	41 80 f9 22          	cmp    $0x22,%r9b
    ae3e:	74 40                	je     ae80 <fwp_write+0xc40>
    ae40:	41 80 f9 5c          	cmp    $0x5c,%r9b
    ae44:	75 5a                	jne    aea0 <fwp_write+0xc60>
    ae46:	ba 02 00 00 00       	mov    $0x2,%edx
    ae4b:	48 8d 35 2c 54 00 00 	lea    0x542c(%rip),%rsi        # 1027e <_IO_stdin_used+0x27e>
    ae52:	48 89 df             	mov    %rbx,%rdi
    ae55:	e8 96 92 ff ff       	call   40f0 <buf_put>
    ae5a:	eb c4                	jmp    ae20 <fwp_write+0xbe0>
    ae5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ae60:	ba 02 00 00 00       	mov    $0x2,%edx
    ae65:	48 8d 35 1b 54 00 00 	lea    0x541b(%rip),%rsi        # 10287 <_IO_stdin_used+0x287>
    ae6c:	48 89 df             	mov    %rbx,%rdi
    ae6f:	e8 7c 92 ff ff       	call   40f0 <buf_put>
    ae74:	eb aa                	jmp    ae20 <fwp_write+0xbe0>
    ae76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae7d:	00 00 00 
    ae80:	ba 02 00 00 00       	mov    $0x2,%edx
    ae85:	48 8d 35 ef 53 00 00 	lea    0x53ef(%rip),%rsi        # 1027b <_IO_stdin_used+0x27b>
    ae8c:	48 89 df             	mov    %rbx,%rdi
    ae8f:	e8 5c 92 ff ff       	call   40f0 <buf_put>
    ae94:	eb 8a                	jmp    ae20 <fwp_write+0xbe0>
    ae96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ae9d:	00 00 00 
    aea0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    aea4:	0f 86 2e 01 00 00    	jbe    afd8 <fwp_write+0xd98>
    aeaa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    aeae:	0f 84 24 01 00 00    	je     afd8 <fwp_write+0xd98>
    aeb4:	ba 01 00 00 00       	mov    $0x1,%edx
    aeb9:	4c 89 fe             	mov    %r15,%rsi
    aebc:	48 89 df             	mov    %rbx,%rdi
    aebf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    aec4:	e8 27 92 ff ff       	call   40f0 <buf_put>
    aec9:	e9 52 ff ff ff       	jmp    ae20 <fwp_write+0xbe0>
    aece:	66 90                	xchg   %ax,%ax
    aed0:	ba 02 00 00 00       	mov    $0x2,%edx
    aed5:	48 8d 35 a8 53 00 00 	lea    0x53a8(%rip),%rsi        # 10284 <_IO_stdin_used+0x284>
    aedc:	48 89 df             	mov    %rbx,%rdi
    aedf:	e8 0c 92 ff ff       	call   40f0 <buf_put>
    aee4:	e9 37 ff ff ff       	jmp    ae20 <fwp_write+0xbe0>
    aee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aef0:	ba 01 00 00 00       	mov    $0x1,%edx
    aef5:	4c 89 fe             	mov    %r15,%rsi
    aef8:	48 89 df             	mov    %rbx,%rdi
    aefb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    af00:	e8 eb 91 ff ff       	call   40f0 <buf_put>
    af05:	e9 cc f3 ff ff       	jmp    a2d6 <fwp_write+0x96>
    af0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af10:	83 f8 04             	cmp    $0x4,%eax
    af13:	0f 85 bb fb ff ff    	jne    aad4 <fwp_write+0x894>
    af19:	48 8b 04 24          	mov    (%rsp),%rax
    af1d:	48 8b 40 08          	mov    0x8(%rax),%rax
    af21:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    af26:	48 c1 e8 3f          	shr    $0x3f,%rax
    af2a:	e9 96 fc ff ff       	jmp    abc5 <fwp_write+0x985>
    af2f:	90                   	nop
    af30:	8b 0c 24             	mov    (%rsp),%ecx
    af33:	31 c0                	xor    %eax,%eax
    af35:	85 c9                	test   %ecx,%ecx
    af37:	0f 98 c0             	sets   %al
    af3a:	e9 86 fc ff ff       	jmp    abc5 <fwp_write+0x985>
    af3f:	90                   	nop
    af40:	48 f7 d8             	neg    %rax
    af43:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    af4a:	00 
    af4b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    af52:	2d 
    af53:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af5a:	00 
    af5b:	48 83 d2 00          	adc    $0x0,%rdx
    af5f:	48 89 c6             	mov    %rax,%rsi
    af62:	48 f7 da             	neg    %rdx
    af65:	e8 d6 8a ff ff       	call   3a40 <fwp_fmt_u128>
    af6a:	e9 51 f3 ff ff       	jmp    a2c0 <fwp_write+0x80>
    af6f:	90                   	nop
    af70:	b8 7d 00 00 00       	mov    $0x7d,%eax
    af75:	e9 c3 f5 ff ff       	jmp    a53d <fwp_write+0x2fd>
    af7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af80:	4c 89 e9             	mov    %r13,%rcx
    af83:	48 c1 e1 04          	shl    $0x4,%rcx
    af87:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    af8c:	48 85 ff             	test   %rdi,%rdi
    af8f:	0f 89 eb f9 ff ff    	jns    a980 <fwp_write+0x740>
    af95:	48 03 4d 10          	add    0x10(%rbp),%rcx
    af99:	48 89 ce             	mov    %rcx,%rsi
    af9c:	e9 df f9 ff ff       	jmp    a980 <fwp_write+0x740>
    afa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afa8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    afaf:	00 
    afb0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    afb4:	e9 20 fa ff ff       	jmp    a9d9 <fwp_write+0x799>
    afb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afc0:	ba 02 00 00 00       	mov    $0x2,%edx
    afc5:	48 8d 35 7a 52 00 00 	lea    0x527a(%rip),%rsi        # 10246 <_IO_stdin_used+0x246>
    afcc:	e9 2d f7 ff ff       	jmp    a6fe <fwp_write+0x4be>
    afd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    afd8:	4c 8d 05 ab 52 00 00 	lea    0x52ab(%rip),%r8        # 1028a <_IO_stdin_used+0x28a>
    afdf:	b9 10 00 00 00       	mov    $0x10,%ecx
    afe4:	31 c0                	xor    %eax,%eax
    afe6:	ba 02 00 00 00       	mov    $0x2,%edx
    afeb:	be 10 00 00 00       	mov    $0x10,%esi
    aff0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aff7:	00 
    aff8:	e8 a3 83 ff ff       	call   33a0 <__snprintf_chk@plt>
    affd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    b004:	00 
    b005:	e8 36 84 ff ff       	call   3440 <strlen@plt>
    b00a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b011:	00 
    b012:	48 89 df             	mov    %rbx,%rdi
    b015:	48 89 c2             	mov    %rax,%rdx
    b018:	e8 d3 90 ff ff       	call   40f0 <buf_put>
    b01d:	e9 fe fd ff ff       	jmp    ae20 <fwp_write+0xbe0>
    b022:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b028:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b02c:	48 8d 35 0d 52 00 00 	lea    0x520d(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    b033:	48 8d 05 05 52 00 00 	lea    0x5205(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    b03a:	4c 89 e7             	mov    %r12,%rdi
    b03d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    b041:	48 0f 46 f0          	cmovbe %rax,%rsi
    b045:	e8 96 83 ff ff       	call   33e0 <strcpy@plt>
    b04a:	e9 71 f2 ff ff       	jmp    a2c0 <fwp_write+0x80>
    b04f:	90                   	nop
    b050:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b054:	48 8d 35 e5 51 00 00 	lea    0x51e5(%rip),%rsi        # 10240 <_IO_stdin_used+0x240>
    b05b:	48 8d 05 dd 51 00 00 	lea    0x51dd(%rip),%rax        # 1023f <_IO_stdin_used+0x23f>
    b062:	0f 2f c8             	comiss %xmm0,%xmm1
    b065:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b06c:	00 
    b06d:	4c 89 e7             	mov    %r12,%rdi
    b070:	48 0f 46 f0          	cmovbe %rax,%rsi
    b074:	e8 67 83 ff ff       	call   33e0 <strcpy@plt>
    b079:	e9 42 f2 ff ff       	jmp    a2c0 <fwp_write+0x80>
    b07e:	66 90                	xchg   %ax,%ax
    b080:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    b085:	45 85 c0             	test   %r8d,%r8d
    b088:	75 34                	jne    b0be <fwp_write+0xe7e>
    b08a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    b091:	00 
    b092:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b099:	00 00 
    b09b:	0f 85 74 f6 ff ff    	jne    a715 <fwp_write+0x4d5>
    b0a1:	ba 02 00 00 00       	mov    $0x2,%edx
    b0a6:	48 8d 35 0e 52 00 00 	lea    0x520e(%rip),%rsi        # 102bb <_IO_stdin_used+0x2bb>
    b0ad:	e9 a1 f3 ff ff       	jmp    a453 <fwp_write+0x213>
    b0b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    b0b6:	49 89 f0             	mov    %rsi,%r8
    b0b9:	e9 e5 fc ff ff       	jmp    ada3 <fwp_write+0xb63>
    b0be:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    b0c3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    b0c8:	85 ff                	test   %edi,%edi
    b0ca:	0f 84 fa f3 ff ff    	je     a4ca <fwp_write+0x28a>
    b0d0:	ba 01 00 00 00       	mov    $0x1,%edx
    b0d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    b0da:	48 89 df             	mov    %rbx,%rdi
    b0dd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    b0e2:	e8 09 90 ff ff       	call   40f0 <buf_put>
    b0e7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    b0ec:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    b0f1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    b0f7:	85 c0                	test   %eax,%eax
    b0f9:	0f 8f f0 f3 ff ff    	jg     a4ef <fwp_write+0x2af>
    b0ff:	e9 34 f4 ff ff       	jmp    a538 <fwp_write+0x2f8>
    b104:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b108:	49 89 c5             	mov    %rax,%r13
    b10b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b110:	49 89 c4             	mov    %rax,%r12
    b113:	49 c1 fd 3f          	sar    $0x3f,%r13
    b117:	4c 09 e8             	or     %r13,%rax
    b11a:	0f 84 a7 00 00 00    	je     b1c7 <fwp_write+0xf87>
    b120:	48 8d 2d f9 72 00 00 	lea    0x72f9(%rip),%rbp        # 12420 <units.1>
    b127:	4d 89 e7             	mov    %r12,%r15
    b12a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b12e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    b133:	4c 89 ff             	mov    %r15,%rdi
    b136:	4c 89 ee             	mov    %r13,%rsi
    b139:	44 89 0c 24          	mov    %r9d,(%rsp)
    b13d:	48 99                	cqto
    b13f:	48 89 d1             	mov    %rdx,%rcx
    b142:	48 89 c2             	mov    %rax,%rdx
    b145:	e8 16 44 00 00       	call   f560 <__divmodti4>
    b14a:	44 8b 0c 24          	mov    (%rsp),%r9d
    b14e:	48 89 c1             	mov    %rax,%rcx
    b151:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b156:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    b15b:	0f 84 94 00 00 00    	je     b1f5 <fwp_write+0xfb5>
    b161:	41 83 c1 01          	add    $0x1,%r9d
    b165:	48 83 c5 10          	add    $0x10,%rbp
    b169:	41 83 f9 05          	cmp    $0x5,%r9d
    b16d:	75 bb                	jne    b12a <fwp_write+0xeea>
    b16f:	4d 85 ed             	test   %r13,%r13
    b172:	79 53                	jns    b1c7 <fwp_write+0xf87>
    b174:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b179:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b17e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b183:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b188:	48 99                	cqto
    b18a:	48 f7 d8             	neg    %rax
    b18d:	48 83 d2 00          	adc    $0x0,%rdx
    b191:	48 89 c6             	mov    %rax,%rsi
    b194:	48 f7 da             	neg    %rdx
    b197:	e8 a4 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b19c:	49 89 e8             	mov    %rbp,%r8
    b19f:	ba 00 02 00 00       	mov    $0x200,%edx
    b1a4:	be 02 00 00 00       	mov    $0x2,%esi
    b1a9:	31 c0                	xor    %eax,%eax
    b1ab:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b1b2:	00 
    b1b3:	48 8d 0d fc 50 00 00 	lea    0x50fc(%rip),%rcx        # 102b6 <_IO_stdin_used+0x2b6>
    b1ba:	4c 89 e7             	mov    %r12,%rdi
    b1bd:	e8 fe 84 ff ff       	call   36c0 <__sprintf_chk@plt>
    b1c2:	e9 f9 f0 ff ff       	jmp    a2c0 <fwp_write+0x80>
    b1c7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b1cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    b1d1:	31 d2                	xor    %edx,%edx
    b1d3:	48 89 ef             	mov    %rbp,%rdi
    b1d6:	e8 65 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b1db:	eb bf                	jmp    b19c <fwp_write+0xf5c>
    b1dd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    b1e4:	4e 61 4e 00 
    b1e8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b1ef:	00 
    b1f0:	e9 cb f0 ff ff       	jmp    a2c0 <fwp_write+0x80>
    b1f5:	44 89 0c 24          	mov    %r9d,(%rsp)
    b1f9:	48 89 c8             	mov    %rcx,%rax
    b1fc:	48 85 d2             	test   %rdx,%rdx
    b1ff:	78 51                	js     b252 <fwp_write+0x1012>
    b201:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b206:	48 89 c6             	mov    %rax,%rsi
    b209:	48 89 ef             	mov    %rbp,%rdi
    b20c:	e8 2f 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b211:	44 8b 0c 24          	mov    (%rsp),%r9d
    b215:	49 63 c1             	movslq %r9d,%rax
    b218:	49 89 e8             	mov    %rbp,%r8
    b21b:	ba 00 02 00 00       	mov    $0x200,%edx
    b220:	be 02 00 00 00       	mov    $0x2,%esi
    b225:	48 c1 e0 04          	shl    $0x4,%rax
    b229:	48 8d 3d f0 71 00 00 	lea    0x71f0(%rip),%rdi        # 12420 <units.1>
    b230:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b237:	00 
    b238:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    b23c:	48 8d 0d 6e 50 00 00 	lea    0x506e(%rip),%rcx        # 102b1 <_IO_stdin_used+0x2b1>
    b243:	4c 89 e7             	mov    %r12,%rdi
    b246:	31 c0                	xor    %eax,%eax
    b248:	e8 73 84 ff ff       	call   36c0 <__sprintf_chk@plt>
    b24d:	e9 6e f0 ff ff       	jmp    a2c0 <fwp_write+0x80>
    b252:	48 f7 d8             	neg    %rax
    b255:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b25a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b25f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b264:	48 83 d2 00          	adc    $0x0,%rdx
    b268:	48 89 c6             	mov    %rax,%rsi
    b26b:	48 f7 da             	neg    %rdx
    b26e:	e8 cd 87 ff ff       	call   3a40 <fwp_fmt_u128>
    b273:	44 8b 0c 24          	mov    (%rsp),%r9d
    b277:	eb 9c                	jmp    b215 <fwp_write+0xfd5>
    b279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000b280 <fwp_hof0.constprop.0>:
    b280:	55                   	push   %rbp
    b281:	48 89 e5             	mov    %rsp,%rbp
    b284:	41 57                	push   %r15
    b286:	41 56                	push   %r14
    b288:	41 55                	push   %r13
    b28a:	41 54                	push   %r12
    b28c:	53                   	push   %rbx
    b28d:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    b294:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    b29b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b2a2:	00 00 
    b2a4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b2a8:	31 c0                	xor    %eax,%eax
    b2aa:	48 85 f6             	test   %rsi,%rsi
    b2ad:	0f 84 cc 06 00 00    	je     b97f <fwp_hof0.constprop.0+0x6ff>
    b2b3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    b2b7:	49 89 f7             	mov    %rsi,%r15
    b2ba:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    b2c1:	48 8d 35 78 15 06 00 	lea    0x61578(%rip),%rsi        # 6c840 <fwp_heap>
    b2c8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    b2cf:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b2d6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b2dd:	48 89 fa             	mov    %rdi,%rdx
    b2e0:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b2e4:	48 c1 e2 10          	shl    $0x10,%rdx
    b2e8:	48 39 d0             	cmp    %rdx,%rax
    b2eb:	73 6b                	jae    b358 <fwp_hof0.constprop.0+0xd8>
    b2ed:	48 89 c2             	mov    %rax,%rdx
    b2f0:	48 c1 ea 10          	shr    $0x10,%rdx
    b2f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b2f8:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b2ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b303:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b307:	48 85 ff             	test   %rdi,%rdi
    b30a:	74 4c                	je     b358 <fwp_hof0.constprop.0+0xd8>
    b30c:	0f b6 0a             	movzbl (%rdx),%ecx
    b30f:	80 f9 02             	cmp    $0x2,%cl
    b312:	0f 84 11 0c 00 00    	je     bf29 <fwp_hof0.constprop.0+0xca9>
    b318:	80 f9 01             	cmp    $0x1,%cl
    b31b:	75 3b                	jne    b358 <fwp_hof0.constprop.0+0xd8>
    b31d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b320:	0f b7 c0             	movzwl %ax,%eax
    b323:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b326:	48 0f af c1          	imul   %rcx,%rax
    b32a:	48 c1 e8 20          	shr    $0x20,%rax
    b32e:	48 39 d0             	cmp    %rdx,%rax
    b331:	73 25                	jae    b358 <fwp_hof0.constprop.0+0xd8>
    b333:	48 01 c7             	add    %rax,%rdi
    b336:	0f b6 07             	movzbl (%rdi),%eax
    b339:	84 c0                	test   %al,%al
    b33b:	74 1b                	je     b358 <fwp_hof0.constprop.0+0xd8>
    b33d:	8b 35 c5 31 06 00    	mov    0x631c5(%rip),%esi        # 6e508 <iteration_active>
    b343:	85 f6                	test   %esi,%esi
    b345:	0f 85 ec 0b 00 00    	jne    bf37 <fwp_hof0.constprop.0+0xcb7>
    b34b:	3c fd                	cmp    $0xfd,%al
    b34d:	0f 87 cd 0c 00 00    	ja     c020 <fwp_hof0.constprop.0+0xda0>
    b353:	83 c0 01             	add    $0x1,%eax
    b356:	88 07                	mov    %al,(%rdi)
    b358:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    b35f:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    b366:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    b36d:	c7 00 00 00 
    b371:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b375:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b379:	48 8b 15 18 31 06 00 	mov    0x63118(%rip),%rdx        # 6e498 <fwp_fns>
    b380:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    b384:	48 8d 05 8d 8c 00 00 	lea    0x8c8d(%rip),%rax        # 14018 <fc12>
    b38b:	44 8b 20             	mov    (%rax),%r12d
    b38e:	49 c1 e4 05          	shl    $0x5,%r12
    b392:	49 01 d4             	add    %rdx,%r12
    b395:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    b39a:	48 85 c9             	test   %rcx,%rcx
    b39d:	0f 84 53 0b 00 00    	je     bef6 <fwp_hof0.constprop.0+0xc76>
    b3a3:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b3a8:	0f 84 2a 09 00 00    	je     bcd8 <fwp_hof0.constprop.0+0xa58>
    b3ae:	48 8d 1d 8b 14 06 00 	lea    0x6148b(%rip),%rbx        # 6c840 <fwp_heap>
    b3b5:	48 8d 05 5c 8c 00 00 	lea    0x8c5c(%rip),%rax        # 14018 <fc12>
    b3bc:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    b3c3:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b3ca:	48 89 f1             	mov    %rsi,%rcx
    b3cd:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    b3d1:	48 c1 e1 10          	shl    $0x10,%rcx
    b3d5:	48 39 c8             	cmp    %rcx,%rax
    b3d8:	73 71                	jae    b44b <fwp_hof0.constprop.0+0x1cb>
    b3da:	48 89 c1             	mov    %rax,%rcx
    b3dd:	48 c1 e9 10          	shr    $0x10,%rcx
    b3e1:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b3e5:	48 8b 8b f8 13 00 00 	mov    0x13f8(%rbx),%rcx
    b3ec:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b3f0:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    b3f4:	48 85 ff             	test   %rdi,%rdi
    b3f7:	74 52                	je     b44b <fwp_hof0.constprop.0+0x1cb>
    b3f9:	0f b6 31             	movzbl (%rcx),%esi
    b3fc:	40 80 fe 02          	cmp    $0x2,%sil
    b400:	0f 84 ed 09 00 00    	je     bdf3 <fwp_hof0.constprop.0+0xb73>
    b406:	40 80 fe 01          	cmp    $0x1,%sil
    b40a:	75 3f                	jne    b44b <fwp_hof0.constprop.0+0x1cb>
    b40c:	8b 71 18             	mov    0x18(%rcx),%esi
    b40f:	0f b7 c0             	movzwl %ax,%eax
    b412:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b415:	48 0f af c6          	imul   %rsi,%rax
    b419:	48 c1 e8 20          	shr    $0x20,%rax
    b41d:	48 39 c8             	cmp    %rcx,%rax
    b420:	73 29                	jae    b44b <fwp_hof0.constprop.0+0x1cb>
    b422:	48 01 c7             	add    %rax,%rdi
    b425:	0f b6 07             	movzbl (%rdi),%eax
    b428:	84 c0                	test   %al,%al
    b42a:	74 1f                	je     b44b <fwp_hof0.constprop.0+0x1cb>
    b42c:	8b 0d d6 30 06 00    	mov    0x630d6(%rip),%ecx        # 6e508 <iteration_active>
    b432:	85 c9                	test   %ecx,%ecx
    b434:	74 08                	je     b43e <fwp_hof0.constprop.0+0x1be>
    b436:	48 83 05 b2 30 06 00 	addq   $0x1,0x630b2(%rip)        # 6e4f0 <iteration_retains>
    b43d:	01 
    b43e:	3c fd                	cmp    $0xfd,%al
    b440:	0f 87 8a 0a 00 00    	ja     bed0 <fwp_hof0.constprop.0+0xc50>
    b446:	83 c0 01             	add    $0x1,%eax
    b449:	88 07                	mov    %al,(%rdi)
    b44b:	48 8d 05 c6 8b 00 00 	lea    0x8bc6(%rip),%rax        # 14018 <fc12>
    b452:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b459:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b45d:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b464:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b468:	48 8d 05 a9 8b 00 00 	lea    0x8ba9(%rip),%rax        # 14018 <fc12>
    b46f:	41 8b 0c 24          	mov    (%r12),%ecx
    b473:	2b 48 04             	sub    0x4(%rax),%ecx
    b476:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b47a:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    b47e:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    b481:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b485:	49 89 c1             	mov    %rax,%r9
    b488:	8b 00                	mov    (%rax),%eax
    b48a:	44 39 e9             	cmp    %r13d,%ecx
    b48d:	44 0f 46 e9          	cmovbe %ecx,%r13d
    b491:	4c 89 cb             	mov    %r9,%rbx
    b494:	48 c1 e0 05          	shl    $0x5,%rax
    b498:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    b49c:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    b4a3:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b4a7:	4d 85 d2             	test   %r10,%r10
    b4aa:	75 5c                	jne    b508 <fwp_hof0.constprop.0+0x288>
    b4ac:	e9 12 02 00 00       	jmp    b6c3 <fwp_hof0.constprop.0+0x443>
    b4b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b4b8:	85 db                	test   %ebx,%ebx
    b4ba:	74 6a                	je     b526 <fwp_hof0.constprop.0+0x2a6>
    b4bc:	4c 89 e7             	mov    %r12,%rdi
    b4bf:	41 ff 12             	call   *(%r10)
    b4c2:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b4c6:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    b4ca:	e8 c1 c1 ff ff       	call   7690 <fwp_closure_drop>
    b4cf:	45 39 ee             	cmp    %r13d,%r14d
    b4d2:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    b4d6:	0f 84 ec 07 00 00    	je     bcc8 <fwp_hof0.constprop.0+0xa48>
    b4dc:	44 8b 00             	mov    (%rax),%r8d
    b4df:	41 29 df             	sub    %ebx,%r15d
    b4e2:	4f 8d 24 f4          	lea    (%r12,%r14,8),%r12
    b4e6:	49 89 c1             	mov    %rax,%r9
    b4e9:	45 89 fd             	mov    %r15d,%r13d
    b4ec:	49 c1 e0 05          	shl    $0x5,%r8
    b4f0:	4c 03 05 a1 2f 06 00 	add    0x62fa1(%rip),%r8        # 6e498 <fwp_fns>
    b4f7:	4d 8b 50 18          	mov    0x18(%r8),%r10
    b4fb:	4d 85 d2             	test   %r10,%r10
    b4fe:	0f 84 bc 01 00 00    	je     b6c0 <fwp_hof0.constprop.0+0x440>
    b504:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b508:	41 8b 49 04          	mov    0x4(%r9),%ecx
    b50c:	41 8b 18             	mov    (%r8),%ebx
    b50f:	46 8d 3c 29          	lea    (%rcx,%r13,1),%r15d
    b513:	41 39 df             	cmp    %ebx,%r15d
    b516:	0f 82 8c 04 00 00    	jb     b9a8 <fwp_hof0.constprop.0+0x728>
    b51c:	41 89 de             	mov    %ebx,%r14d
    b51f:	41 29 ce             	sub    %ecx,%r14d
    b522:	85 c9                	test   %ecx,%ecx
    b524:	74 92                	je     b4b8 <fwp_hof0.constprop.0+0x238>
    b526:	85 db                	test   %ebx,%ebx
    b528:	b8 01 00 00 00       	mov    $0x1,%eax
    b52d:	48 89 e6             	mov    %rsp,%rsi
    b530:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    b534:	0f 45 c3             	cmovne %ebx,%eax
    b537:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    b53e:	00 
    b53f:	48 c1 e8 04          	shr    $0x4,%rax
    b543:	48 c1 e0 04          	shl    $0x4,%rax
    b547:	48 89 c7             	mov    %rax,%rdi
    b54a:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b551:	48 29 fe             	sub    %rdi,%rsi
    b554:	48 39 f4             	cmp    %rsi,%rsp
    b557:	74 15                	je     b56e <fwp_hof0.constprop.0+0x2ee>
    b559:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b560:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b567:	00 00 
    b569:	48 39 f4             	cmp    %rsi,%rsp
    b56c:	75 eb                	jne    b559 <fwp_hof0.constprop.0+0x2d9>
    b56e:	25 ff 0f 00 00       	and    $0xfff,%eax
    b573:	48 29 c4             	sub    %rax,%rsp
    b576:	48 85 c0             	test   %rax,%rax
    b579:	74 06                	je     b581 <fwp_hof0.constprop.0+0x301>
    b57b:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    b581:	89 cf                	mov    %ecx,%edi
    b583:	49 89 e3             	mov    %rsp,%r11
    b586:	31 c0                	xor    %eax,%eax
    b588:	48 c1 e7 03          	shl    $0x3,%rdi
    b58c:	85 c9                	test   %ecx,%ecx
    b58e:	74 22                	je     b5b2 <fwp_hof0.constprop.0+0x332>
    b590:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b59c:	00 00 00 00 
    b5a0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    b5a5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    b5a9:	48 83 c0 08          	add    $0x8,%rax
    b5ad:	48 39 c7             	cmp    %rax,%rdi
    b5b0:	75 ee                	jne    b5a0 <fwp_hof0.constprop.0+0x320>
    b5b2:	45 85 f6             	test   %r14d,%r14d
    b5b5:	74 3e                	je     b5f5 <fwp_hof0.constprop.0+0x375>
    b5b7:	44 89 f6             	mov    %r14d,%esi
    b5ba:	4c 89 e0             	mov    %r12,%rax
    b5bd:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    b5c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b5c8:	00 00 
    b5ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5d1:	00 00 00 00 
    b5d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b5dc:	00 00 00 00 
    b5e0:	48 8b 30             	mov    (%rax),%rsi
    b5e3:	89 ca                	mov    %ecx,%edx
    b5e5:	48 83 c0 08          	add    $0x8,%rax
    b5e9:	83 c1 01             	add    $0x1,%ecx
    b5ec:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    b5f0:	48 39 c7             	cmp    %rax,%rdi
    b5f3:	75 eb                	jne    b5e0 <fwp_hof0.constprop.0+0x360>
    b5f5:	48 8d 15 44 12 06 00 	lea    0x61244(%rip),%rdx        # 6c840 <fwp_heap>
    b5fc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b600:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    b607:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    b60e:	48 89 f1             	mov    %rsi,%rcx
    b611:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    b615:	48 c1 e1 10          	shl    $0x10,%rcx
    b619:	48 39 c8             	cmp    %rcx,%rax
    b61c:	73 4c                	jae    b66a <fwp_hof0.constprop.0+0x3ea>
    b61e:	48 89 c1             	mov    %rax,%rcx
    b621:	48 c1 e9 10          	shr    $0x10,%rcx
    b625:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b629:	48 8b 0d 08 26 06 00 	mov    0x62608(%rip),%rcx        # 6dc38 <fwp_heap+0x13f8>
    b630:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b634:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    b638:	48 85 f6             	test   %rsi,%rsi
    b63b:	74 2d                	je     b66a <fwp_hof0.constprop.0+0x3ea>
    b63d:	0f b6 39             	movzbl (%rcx),%edi
    b640:	40 80 ff 02          	cmp    $0x2,%dil
    b644:	74 6a                	je     b6b0 <fwp_hof0.constprop.0+0x430>
    b646:	40 80 ff 01          	cmp    $0x1,%dil
    b64a:	75 1e                	jne    b66a <fwp_hof0.constprop.0+0x3ea>
    b64c:	8b 79 18             	mov    0x18(%rcx),%edi
    b64f:	0f b7 c0             	movzwl %ax,%eax
    b652:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b655:	48 0f af c7          	imul   %rdi,%rax
    b659:	48 c1 e8 20          	shr    $0x20,%rax
    b65d:	48 39 c8             	cmp    %rcx,%rax
    b660:	73 08                	jae    b66a <fwp_hof0.constprop.0+0x3ea>
    b662:	48 01 c6             	add    %rax,%rsi
    b665:	80 3e 01             	cmpb   $0x1,(%rsi)
    b668:	74 36                	je     b6a0 <fwp_hof0.constprop.0+0x420>
    b66a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    b66e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b672:	be 01 00 00 00       	mov    $0x1,%esi
    b677:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    b67b:	41 ff 52 08          	call   *0x8(%r10)
    b67f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    b683:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    b687:	49 8b 40 18          	mov    0x18(%r8),%rax
    b68b:	4c 89 df             	mov    %r11,%rdi
    b68e:	ff 10                	call   *(%rax)
    b690:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    b694:	e9 29 fe ff ff       	jmp    b4c2 <fwp_hof0.constprop.0+0x242>
    b699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6a0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b6a7:	00 
    b6a8:	eb dd                	jmp    b687 <fwp_hof0.constprop.0+0x407>
    b6aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b6b0:	66 85 c0             	test   %ax,%ax
    b6b3:	75 b5                	jne    b66a <fwp_hof0.constprop.0+0x3ea>
    b6b5:	eb ae                	jmp    b665 <fwp_hof0.constprop.0+0x3e5>
    b6b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b6be:	00 00 
    b6c0:	48 89 c3             	mov    %rax,%rbx
    b6c3:	48 89 df             	mov    %rbx,%rdi
    b6c6:	e8 75 b8 ff ff       	call   6f40 <fwp_rc_share>
    b6cb:	45 85 ed             	test   %r13d,%r13d
    b6ce:	74 21                	je     b6f1 <fwp_hof0.constprop.0+0x471>
    b6d0:	44 89 ea             	mov    %r13d,%edx
    b6d3:	4d 89 e7             	mov    %r12,%r15
    b6d6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    b6da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b6e0:	49 8b 3f             	mov    (%r15),%rdi
    b6e3:	49 83 c7 08          	add    $0x8,%r15
    b6e7:	e8 54 b8 ff ff       	call   6f40 <fwp_rc_share>
    b6ec:	4d 39 f7             	cmp    %r14,%r15
    b6ef:	75 ef                	jne    b6e0 <fwp_hof0.constprop.0+0x460>
    b6f1:	4c 89 e2             	mov    %r12,%rdx
    b6f4:	44 89 ee             	mov    %r13d,%esi
    b6f7:	48 89 df             	mov    %rbx,%rdi
    b6fa:	e8 01 aa ff ff       	call   6100 <fwp_apply>
    b6ff:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b703:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b706:	39 75 90             	cmp    %esi,-0x70(%rbp)
    b709:	0f 83 87 00 00 00    	jae    b796 <fwp_hof0.constprop.0+0x516>
    b70f:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    b715:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b719:	48 89 c3             	mov    %rax,%rbx
    b71c:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    b720:	48 8b 15 71 2d 06 00 	mov    0x62d71(%rip),%rdx        # 6e498 <fwp_fns>
    b727:	29 de                	sub    %ebx,%esi
    b729:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b72d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    b730:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b734:	44 8b 26             	mov    (%rsi),%r12d
    b737:	48 89 f0             	mov    %rsi,%rax
    b73a:	49 c1 e4 05          	shl    $0x5,%r12
    b73e:	49 01 d4             	add    %rdx,%r12
    b741:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    b747:	0f 85 22 fd ff ff    	jne    b46f <fwp_hof0.constprop.0+0x1ef>
    b74d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b751:	e8 ea b7 ff ff       	call   6f40 <fwp_rc_share>
    b756:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    b75a:	45 85 f6             	test   %r14d,%r14d
    b75d:	74 23                	je     b782 <fwp_hof0.constprop.0+0x502>
    b75f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    b763:	31 db                	xor    %ebx,%ebx
    b765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b76c:	00 00 00 00 
    b770:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b774:	48 83 c3 01          	add    $0x1,%rbx
    b778:	e8 c3 b7 ff ff       	call   6f40 <fwp_rc_share>
    b77d:	44 39 f3             	cmp    %r14d,%ebx
    b780:	72 ee                	jb     b770 <fwp_hof0.constprop.0+0x4f0>
    b782:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    b786:	8b 75 94             	mov    -0x6c(%rbp),%esi
    b789:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b78d:	e8 6e a9 ff ff       	call   6100 <fwp_apply>
    b792:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b796:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    b79d:	01 
    b79e:	0f 85 d1 fb ff ff    	jne    b375 <fwp_hof0.constprop.0+0xf5>
    b7a4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    b7a8:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b7af:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b7b3:	b9 01 00 00 00       	mov    $0x1,%ecx
    b7b8:	48 8d 15 e1 83 00 00 	lea    0x83e1(%rip),%rdx        # 13ba0 <d0>
    b7bf:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    b7c6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    b7cd:	00 
    b7ce:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    b7d2:	e8 69 ea ff ff       	call   a240 <fwp_write>
    b7d7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    b7db:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    b7df:	48 8d 05 86 48 00 00 	lea    0x4886(%rip),%rax        # 1006c <_IO_stdin_used+0x6c>
    b7e6:	48 85 c9             	test   %rcx,%rcx
    b7e9:	48 0f 44 c8          	cmove  %rax,%rcx
    b7ed:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    b7f1:	0f 87 15 08 00 00    	ja     c00c <fwp_hof0.constprop.0+0xd8c>
    b7f7:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    b7fb:	be 01 00 00 00       	mov    $0x1,%esi
    b800:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    b804:	e8 07 a7 ff ff       	call   5f10 <fwp_heap_alloc>
    b809:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    b80d:	4c 89 f2             	mov    %r14,%rdx
    b810:	4c 89 30             	mov    %r14,(%rax)
    b813:	4c 8d 60 08          	lea    0x8(%rax),%r12
    b817:	48 89 c3             	mov    %rax,%rbx
    b81a:	4c 89 e7             	mov    %r12,%rdi
    b81d:	e8 5e 7d ff ff       	call   3580 <memcpy@plt>
    b822:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    b828:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    b82c:	e8 7f 7b ff ff       	call   33b0 <free@plt>
    b831:	48 8d 35 08 10 06 00 	lea    0x61008(%rip),%rsi        # 6c840 <fwp_heap>
    b838:	48 89 d8             	mov    %rbx,%rax
    b83b:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b842:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b849:	48 89 fa             	mov    %rdi,%rdx
    b84c:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
    b850:	48 c1 e2 10          	shl    $0x10,%rdx
    b854:	48 39 d0             	cmp    %rdx,%rax
    b857:	73 57                	jae    b8b0 <fwp_hof0.constprop.0+0x630>
    b859:	48 89 c2             	mov    %rax,%rdx
    b85c:	48 c1 ea 10          	shr    $0x10,%rdx
    b860:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b864:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b86b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b86f:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b873:	4d 85 f6             	test   %r14,%r14
    b876:	74 38                	je     b8b0 <fwp_hof0.constprop.0+0x630>
    b878:	0f b6 0a             	movzbl (%rdx),%ecx
    b87b:	80 f9 02             	cmp    $0x2,%cl
    b87e:	0f 84 da 06 00 00    	je     bf5e <fwp_hof0.constprop.0+0xcde>
    b884:	80 f9 01             	cmp    $0x1,%cl
    b887:	75 27                	jne    b8b0 <fwp_hof0.constprop.0+0x630>
    b889:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b88c:	0f b7 c0             	movzwl %ax,%eax
    b88f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b892:	48 0f af c1          	imul   %rcx,%rax
    b896:	48 c1 e8 20          	shr    $0x20,%rax
    b89a:	48 39 d0             	cmp    %rdx,%rax
    b89d:	73 11                	jae    b8b0 <fwp_hof0.constprop.0+0x630>
    b89f:	49 01 c6             	add    %rax,%r14
    b8a2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b8a6:	0f 84 84 07 00 00    	je     c030 <fwp_hof0.constprop.0+0xdb0>
    b8ac:	41 c6 06 01          	movb   $0x1,(%r14)
    b8b0:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b8b4:	e8 e7 ba ff ff       	call   73a0 <fwp_drop0>
    b8b9:	48 8b 13             	mov    (%rbx),%rdx
    b8bc:	be 01 00 00 00       	mov    $0x1,%esi
    b8c1:	4c 89 e7             	mov    %r12,%rdi
    b8c4:	48 8b 0d d5 2b 06 00 	mov    0x62bd5(%rip),%rcx        # 6e4a0 <fwp_prog_out>
    b8cb:	e8 90 7d ff ff       	call   3660 <fwrite@plt>
    b8d0:	48 8b 35 c9 2b 06 00 	mov    0x62bc9(%rip),%rsi        # 6e4a0 <fwp_prog_out>
    b8d7:	bf 0a 00 00 00       	mov    $0xa,%edi
    b8dc:	e8 ef 7b ff ff       	call   34d0 <fputc@plt>
    b8e1:	48 8d 35 58 0f 06 00 	lea    0x60f58(%rip),%rsi        # 6c840 <fwp_heap>
    b8e8:	48 89 d8             	mov    %rbx,%rax
    b8eb:	48 8b be d8 13 00 00 	mov    0x13d8(%rsi),%rdi
    b8f2:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b8f9:	48 89 fa             	mov    %rdi,%rdx
    b8fc:	48 89 7d a8          	mov    %rdi,-0x58(%rbp)
    b900:	48 c1 e2 10          	shl    $0x10,%rdx
    b904:	48 39 d0             	cmp    %rdx,%rax
    b907:	73 69                	jae    b972 <fwp_hof0.constprop.0+0x6f2>
    b909:	48 89 c2             	mov    %rax,%rdx
    b90c:	48 c1 ea 10          	shr    $0x10,%rdx
    b910:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b914:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b91b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b91f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b923:	4d 85 e4             	test   %r12,%r12
    b926:	74 4a                	je     b972 <fwp_hof0.constprop.0+0x6f2>
    b928:	0f b6 0a             	movzbl (%rdx),%ecx
    b92b:	80 f9 02             	cmp    $0x2,%cl
    b92e:	0f 84 38 06 00 00    	je     bf6c <fwp_hof0.constprop.0+0xcec>
    b934:	80 f9 01             	cmp    $0x1,%cl
    b937:	75 39                	jne    b972 <fwp_hof0.constprop.0+0x6f2>
    b939:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b93c:	0f b7 c0             	movzwl %ax,%eax
    b93f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b942:	48 0f af c1          	imul   %rcx,%rax
    b946:	48 c1 e8 20          	shr    $0x20,%rax
    b94a:	48 39 d0             	cmp    %rdx,%rax
    b94d:	73 23                	jae    b972 <fwp_hof0.constprop.0+0x6f2>
    b94f:	49 01 c4             	add    %rax,%r12
    b952:	41 0f b6 04 24       	movzbl (%r12),%eax
    b957:	84 c0                	test   %al,%al
    b959:	74 17                	je     b972 <fwp_hof0.constprop.0+0x6f2>
    b95b:	3c 01                	cmp    $0x1,%al
    b95d:	0f 84 e1 05 00 00    	je     bf44 <fwp_hof0.constprop.0+0xcc4>
    b963:	3c ff                	cmp    $0xff,%al
    b965:	0f 84 0f 06 00 00    	je     bf7a <fwp_hof0.constprop.0+0xcfa>
    b96b:	83 e8 01             	sub    $0x1,%eax
    b96e:	41 88 04 24          	mov    %al,(%r12)
    b972:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b976:	4d 85 ff             	test   %r15,%r15
    b979:	0f 85 42 f9 ff ff    	jne    b2c1 <fwp_hof0.constprop.0+0x41>
    b97f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b983:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b98a:	00 00 
    b98c:	0f 85 98 06 00 00    	jne    c02a <fwp_hof0.constprop.0+0xdaa>
    b992:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b996:	31 c0                	xor    %eax,%eax
    b998:	5b                   	pop    %rbx
    b999:	41 5c                	pop    %r12
    b99b:	41 5d                	pop    %r13
    b99d:	41 5e                	pop    %r14
    b99f:	41 5f                	pop    %r15
    b9a1:	5d                   	pop    %rbp
    b9a2:	c3                   	ret
    b9a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b9a8:	44 8b 1d 59 2b 06 00 	mov    0x62b59(%rip),%r11d        # 6e508 <iteration_active>
    b9af:	41 8d 77 01          	lea    0x1(%r15),%esi
    b9b3:	8b 05 2b 22 06 00    	mov    0x6222b(%rip),%eax        # 6dbe4 <fwp_heap+0x13a4>
    b9b9:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    b9c0:	00 
    b9c1:	45 85 db             	test   %r11d,%r11d
    b9c4:	0f 84 f3 03 00 00    	je     bdbd <fwp_hof0.constprop.0+0xb3d>
    b9ca:	48 83 05 2e 2b 06 00 	addq   $0x1,0x62b2e(%rip)        # 6e500 <iteration_requests>
    b9d1:	01 
    b9d2:	48 01 3d 1f 2b 06 00 	add    %rdi,0x62b1f(%rip)        # 6e4f8 <iteration_bytes>
    b9d9:	85 c0                	test   %eax,%eax
    b9db:	0f 84 ca 04 00 00    	je     beab <fwp_hof0.constprop.0+0xc2b>
    b9e1:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    b9e8:	0f 87 bd 04 00 00    	ja     beab <fwp_hof0.constprop.0+0xc2b>
    b9ee:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    b9f2:	48 8d 1d 47 0e 06 00 	lea    0x60e47(%rip),%rbx        # 6c840 <fwp_heap>
    b9f9:	48 c1 e8 04          	shr    $0x4,%rax
    b9fd:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    ba04:	00 
    ba05:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    ba0c:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    ba10:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    ba14:	4c 8b 12             	mov    (%rdx),%r10
    ba17:	4d 85 d2             	test   %r10,%r10
    ba1a:	0f 84 e1 03 00 00    	je     be01 <fwp_hof0.constprop.0+0xb81>
    ba20:	49 8b 1a             	mov    (%r10),%rbx
    ba23:	48 f7 d3             	not    %rbx
    ba26:	48 89 1a             	mov    %rbx,(%rdx)
    ba29:	48 39 c7             	cmp    %rax,%rdi
    ba2c:	73 6c                	jae    ba9a <fwp_hof0.constprop.0+0x81a>
    ba2e:	48 89 fa             	mov    %rdi,%rdx
    ba31:	48 83 c7 08          	add    $0x8,%rdi
    ba35:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    ba3c:	00 
    ba3d:	48 f7 d2             	not    %rdx
    ba40:	48 01 c2             	add    %rax,%rdx
    ba43:	48 c1 ea 03          	shr    $0x3,%rdx
    ba47:	48 39 c7             	cmp    %rax,%rdi
    ba4a:	73 4e                	jae    ba9a <fwp_hof0.constprop.0+0x81a>
    ba4c:	83 e2 01             	and    $0x1,%edx
    ba4f:	74 2f                	je     ba80 <fwp_hof0.constprop.0+0x800>
    ba51:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ba58:	00 
    ba59:	48 83 c7 08          	add    $0x8,%rdi
    ba5d:	48 39 c7             	cmp    %rax,%rdi
    ba60:	73 38                	jae    ba9a <fwp_hof0.constprop.0+0x81a>
    ba62:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ba69:	00 
    ba6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba71:	00 00 00 00 
    ba75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ba7c:	00 00 00 00 
    ba80:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    ba87:	00 
    ba88:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    ba8f:	00 00 
    ba91:	48 83 c7 10          	add    $0x10,%rdi
    ba95:	48 39 c7             	cmp    %rax,%rdi
    ba98:	72 e6                	jb     ba80 <fwp_hof0.constprop.0+0x800>
    ba9a:	48 8d 3d 9f 0d 06 00 	lea    0x60d9f(%rip),%rdi        # 6c840 <fwp_heap>
    baa1:	48 89 c2             	mov    %rax,%rdx
    baa4:	48 03 97 20 14 00 00 	add    0x1420(%rdi),%rdx
    baab:	0f 82 4a 05 00 00    	jb     bffb <fwp_hof0.constprop.0+0xd7b>
    bab1:	48 89 97 20 14 00 00 	mov    %rdx,0x1420(%rdi)
    bab8:	48 39 97 28 14 00 00 	cmp    %rdx,0x1428(%rdi)
    babf:	73 07                	jae    bac8 <fwp_hof0.constprop.0+0x848>
    bac1:	48 89 15 a0 21 06 00 	mov    %rdx,0x621a0(%rip)        # 6dc68 <fwp_heap+0x1428>
    bac8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bacc:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    bad1:	f2 0f 58 05 9f 21 06 	addsd  0x6219f(%rip),%xmm0        # 6dc78 <fwp_heap+0x1438>
    bad8:	00 
    bad9:	f2 0f 11 05 97 21 06 	movsd  %xmm0,0x62197(%rip)        # 6dc78 <fwp_heap+0x1438>
    bae0:	00 
    bae1:	45 85 db             	test   %r11d,%r11d
    bae4:	74 33                	je     bb19 <fwp_hof0.constprop.0+0x899>
    bae6:	48 8b 05 73 21 06 00 	mov    0x62173(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    baed:	48 85 c0             	test   %rax,%rax
    baf0:	0f 88 64 03 00 00    	js     be5a <fwp_hof0.constprop.0+0xbda>
    baf6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    bafa:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    baff:	f2 0f 5c 05 e1 29 06 	subsd  0x629e1(%rip),%xmm0        # 6e4e8 <iteration_start_charge>
    bb06:	00 
    bb07:	66 0f 2f 05 d1 29 06 	comisd 0x629d1(%rip),%xmm0        # 6e4e0 <iteration_peak>
    bb0e:	00 
    bb0f:	76 08                	jbe    bb19 <fwp_hof0.constprop.0+0x899>
    bb11:	f2 0f 11 05 c7 29 06 	movsd  %xmm0,0x629c7(%rip)        # 6e4e0 <iteration_peak>
    bb18:	00 
    bb19:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    bb1e:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    bb23:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    bb27:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    bb2c:	85 c9                	test   %ecx,%ecx
    bb2e:	74 37                	je     bb67 <fwp_hof0.constprop.0+0x8e7>
    bb30:	89 ca                	mov    %ecx,%edx
    bb32:	49 8d 71 08          	lea    0x8(%r9),%rsi
    bb36:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    bb3a:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    bb3d:	48 c1 e2 03          	shl    $0x3,%rdx
    bb41:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    bb48:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    bb4c:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    bb50:	e8 9b 7a ff ff       	call   35f0 <memmove@plt>
    bb55:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    bb59:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    bb5d:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bb60:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    bb67:	45 85 ed             	test   %r13d,%r13d
    bb6a:	74 2b                	je     bb97 <fwp_hof0.constprop.0+0x917>
    bb6c:	45 89 ed             	mov    %r13d,%r13d
    bb6f:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    bb73:	66 90                	xchg   %ax,%ax
    bb75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bb7c:	00 00 00 00 
    bb80:	49 8b 14 24          	mov    (%r12),%rdx
    bb84:	89 c8                	mov    %ecx,%eax
    bb86:	49 83 c4 08          	add    $0x8,%r12
    bb8a:	83 c1 01             	add    $0x1,%ecx
    bb8d:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    bb92:	4c 39 e6             	cmp    %r12,%rsi
    bb95:	75 e9                	jne    bb80 <fwp_hof0.constprop.0+0x900>
    bb97:	48 8d 15 a2 0c 06 00 	lea    0x60ca2(%rip),%rdx        # 6c840 <fwp_heap>
    bb9e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    bba2:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    bba9:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    bbb0:	48 89 f2             	mov    %rsi,%rdx
    bbb3:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
    bbb7:	48 c1 e2 10          	shl    $0x10,%rdx
    bbbb:	48 39 d0             	cmp    %rdx,%rax
    bbbe:	73 54                	jae    bc14 <fwp_hof0.constprop.0+0x994>
    bbc0:	48 89 c2             	mov    %rax,%rdx
    bbc3:	48 c1 ea 10          	shr    $0x10,%rdx
    bbc7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bbcb:	48 8b 15 66 20 06 00 	mov    0x62066(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    bbd2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bbd6:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    bbda:	48 85 c9             	test   %rcx,%rcx
    bbdd:	74 35                	je     bc14 <fwp_hof0.constprop.0+0x994>
    bbdf:	0f b6 32             	movzbl (%rdx),%esi
    bbe2:	40 80 fe 02          	cmp    $0x2,%sil
    bbe6:	0f 84 37 02 00 00    	je     be23 <fwp_hof0.constprop.0+0xba3>
    bbec:	40 80 fe 01          	cmp    $0x1,%sil
    bbf0:	75 22                	jne    bc14 <fwp_hof0.constprop.0+0x994>
    bbf2:	8b 72 18             	mov    0x18(%rdx),%esi
    bbf5:	0f b7 c0             	movzwl %ax,%eax
    bbf8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bbfb:	48 0f af c6          	imul   %rsi,%rax
    bbff:	48 c1 e8 20          	shr    $0x20,%rax
    bc03:	48 39 d0             	cmp    %rdx,%rax
    bc06:	73 0c                	jae    bc14 <fwp_hof0.constprop.0+0x994>
    bc08:	48 01 c1             	add    %rax,%rcx
    bc0b:	80 39 01             	cmpb   $0x1,(%rcx)
    bc0e:	0f 84 9c 01 00 00    	je     bdb0 <fwp_hof0.constprop.0+0xb30>
    bc14:	49 8b 40 18          	mov    0x18(%r8),%rax
    bc18:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    bc1c:	be 01 00 00 00       	mov    $0x1,%esi
    bc21:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    bc25:	ff 50 08             	call   *0x8(%rax)
    bc28:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    bc2c:	48 8d 35 0d 0c 06 00 	lea    0x60c0d(%rip),%rsi        # 6c840 <fwp_heap>
    bc33:	4c 89 d0             	mov    %r10,%rax
    bc36:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    bc3d:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    bc44:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    bc48:	48 c1 e2 10          	shl    $0x10,%rdx
    bc4c:	48 39 d0             	cmp    %rdx,%rax
    bc4f:	73 59                	jae    bcaa <fwp_hof0.constprop.0+0xa2a>
    bc51:	48 89 c2             	mov    %rax,%rdx
    bc54:	48 c1 ea 10          	shr    $0x10,%rdx
    bc58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc5c:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    bc63:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc67:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    bc6b:	4d 85 e4             	test   %r12,%r12
    bc6e:	74 3a                	je     bcaa <fwp_hof0.constprop.0+0xa2a>
    bc70:	0f b6 0a             	movzbl (%rdx),%ecx
    bc73:	80 f9 02             	cmp    $0x2,%cl
    bc76:	0f 84 b5 01 00 00    	je     be31 <fwp_hof0.constprop.0+0xbb1>
    bc7c:	80 f9 01             	cmp    $0x1,%cl
    bc7f:	75 29                	jne    bcaa <fwp_hof0.constprop.0+0xa2a>
    bc81:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bc84:	0f b7 c0             	movzwl %ax,%eax
    bc87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bc8a:	48 0f af c1          	imul   %rcx,%rax
    bc8e:	48 c1 e8 20          	shr    $0x20,%rax
    bc92:	48 39 d0             	cmp    %rdx,%rax
    bc95:	73 13                	jae    bcaa <fwp_hof0.constprop.0+0xa2a>
    bc97:	49 01 c4             	add    %rax,%r12
    bc9a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    bc9f:	0f 84 a0 01 00 00    	je     be45 <fwp_hof0.constprop.0+0xbc5>
    bca5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    bcaa:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    bcae:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    bcb2:	e8 d9 b9 ff ff       	call   7690 <fwp_closure_drop>
    bcb7:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    bcbb:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    bcbf:	e9 3f fa ff ff       	jmp    b703 <fwp_hof0.constprop.0+0x483>
    bcc4:	0f 1f 40 00          	nopl   0x0(%rax)
    bcc8:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bccc:	e9 32 fa ff ff       	jmp    b703 <fwp_hof0.constprop.0+0x483>
    bcd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bcd8:	41 8b 34 24          	mov    (%r12),%esi
    bcdc:	8b 05 3a 83 00 00    	mov    0x833a(%rip),%eax        # 1401c <fc12+0x4>
    bce2:	89 f7                	mov    %esi,%edi
    bce4:	29 c7                	sub    %eax,%edi
    bce6:	83 ff 01             	cmp    $0x1,%edi
    bce9:	0f 85 bf f6 ff ff    	jne    b3ae <fwp_hof0.constprop.0+0x12e>
    bcef:	48 89 e3             	mov    %rsp,%rbx
    bcf2:	85 c0                	test   %eax,%eax
    bcf4:	0f 84 e7 01 00 00    	je     bee1 <fwp_hof0.constprop.0+0xc61>
    bcfa:	89 f1                	mov    %esi,%ecx
    bcfc:	ba 08 00 00 00       	mov    $0x8,%edx
    bd01:	48 c1 e1 03          	shl    $0x3,%rcx
    bd05:	85 f6                	test   %esi,%esi
    bd07:	48 89 e6             	mov    %rsp,%rsi
    bd0a:	48 0f 45 d1          	cmovne %rcx,%rdx
    bd0e:	49 89 d7             	mov    %rdx,%r15
    bd11:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    bd15:	48 c1 ea 04          	shr    $0x4,%rdx
    bd19:	48 c1 e2 04          	shl    $0x4,%rdx
    bd1d:	48 89 d7             	mov    %rdx,%rdi
    bd20:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bd27:	48 29 fe             	sub    %rdi,%rsi
    bd2a:	48 39 f4             	cmp    %rsi,%rsp
    bd2d:	74 15                	je     bd44 <fwp_hof0.constprop.0+0xac4>
    bd2f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    bd36:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    bd3d:	00 00 
    bd3f:	48 39 f4             	cmp    %rsi,%rsp
    bd42:	75 eb                	jne    bd2f <fwp_hof0.constprop.0+0xaaf>
    bd44:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    bd4a:	48 29 d4             	sub    %rdx,%rsp
    bd4d:	48 85 d2             	test   %rdx,%rdx
    bd50:	74 06                	je     bd58 <fwp_hof0.constprop.0+0xad8>
    bd52:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    bd58:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    bd5f:	00 
    bd60:	4c 89 f9             	mov    %r15,%rcx
    bd63:	48 8d 35 b6 82 00 00 	lea    0x82b6(%rip),%rsi        # 14020 <fwp_epfd>
    bd6a:	48 89 e7             	mov    %rsp,%rdi
    bd6d:	4c 89 f2             	mov    %r14,%rdx
    bd70:	e8 db 77 ff ff       	call   3550 <__memcpy_chk@plt>
    bd75:	4d 39 f7             	cmp    %r14,%r15
    bd78:	4c 89 f9             	mov    %r15,%rcx
    bd7b:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    bd7f:	49 0f 42 ce          	cmovb  %r14,%rcx
    bd83:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    bd8a:	ba 08 00 00 00       	mov    $0x8,%edx
    bd8f:	4c 29 f1             	sub    %r14,%rcx
    bd92:	e8 b9 77 ff ff       	call   3550 <__memcpy_chk@plt>
    bd97:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    bd9c:	48 89 e7             	mov    %rsp,%rdi
    bd9f:	ff 10                	call   *(%rax)
    bda1:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bda5:	e9 44 01 00 00       	jmp    beee <fwp_hof0.constprop.0+0xc6e>
    bdaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bdb0:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    bdb7:	00 
    bdb8:	e9 6f fe ff ff       	jmp    bc2c <fwp_hof0.constprop.0+0x9ac>
    bdbd:	85 c0                	test   %eax,%eax
    bdbf:	74 0d                	je     bdce <fwp_hof0.constprop.0+0xb4e>
    bdc1:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    bdc8:	0f 86 20 fc ff ff    	jbe    b9ee <fwp_hof0.constprop.0+0x76e>
    bdce:	31 f6                	xor    %esi,%esi
    bdd0:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    bdd3:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    bdd7:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    bddb:	e8 30 a1 ff ff       	call   5f10 <fwp_heap_alloc>
    bde0:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bde4:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bde8:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bdeb:	49 89 c2             	mov    %rax,%r10
    bdee:	e9 26 fd ff ff       	jmp    bb19 <fwp_hof0.constprop.0+0x899>
    bdf3:	66 85 c0             	test   %ax,%ax
    bdf6:	0f 85 4f f6 ff ff    	jne    b44b <fwp_hof0.constprop.0+0x1cb>
    bdfc:	e9 24 f6 ff ff       	jmp    b425 <fwp_hof0.constprop.0+0x1a5>
    be01:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    be05:	4d 85 d2             	test   %r10,%r10
    be08:	74 6e                	je     be78 <fwp_hof0.constprop.0+0xbf8>
    be0a:	48 8b 5a 10          	mov    0x10(%rdx),%rbx
    be0e:	4c 29 d3             	sub    %r10,%rbx
    be11:	48 39 c3             	cmp    %rax,%rbx
    be14:	72 62                	jb     be78 <fwp_hof0.constprop.0+0xbf8>
    be16:	49 8d 1c 02          	lea    (%r10,%rax,1),%rbx
    be1a:	48 89 5a 08          	mov    %rbx,0x8(%rdx)
    be1e:	e9 06 fc ff ff       	jmp    ba29 <fwp_hof0.constprop.0+0x7a9>
    be23:	66 85 c0             	test   %ax,%ax
    be26:	0f 85 e8 fd ff ff    	jne    bc14 <fwp_hof0.constprop.0+0x994>
    be2c:	e9 da fd ff ff       	jmp    bc0b <fwp_hof0.constprop.0+0x98b>
    be31:	66 85 c0             	test   %ax,%ax
    be34:	0f 85 70 fe ff ff    	jne    bcaa <fwp_hof0.constprop.0+0xa2a>
    be3a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    be3f:	0f 85 60 fe ff ff    	jne    bca5 <fwp_hof0.constprop.0+0xa25>
    be45:	4c 89 e7             	mov    %r12,%rdi
    be48:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    be4c:	e8 7f 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    be51:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    be55:	e9 4b fe ff ff       	jmp    bca5 <fwp_hof0.constprop.0+0xa25>
    be5a:	48 89 c2             	mov    %rax,%rdx
    be5d:	83 e0 01             	and    $0x1,%eax
    be60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    be64:	48 d1 ea             	shr    $1,%rdx
    be67:	48 09 c2             	or     %rax,%rdx
    be6a:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    be6f:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    be73:	e9 87 fc ff ff       	jmp    baff <fwp_hof0.constprop.0+0x87f>
    be78:	31 f6                	xor    %esi,%esi
    be7a:	89 8d 68 ff ff ff    	mov    %ecx,-0x98(%rbp)
    be80:	44 89 5d 80          	mov    %r11d,-0x80(%rbp)
    be84:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    be88:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    be8c:	e8 7f a0 ff ff       	call   5f10 <fwp_heap_alloc>
    be91:	8b 8d 68 ff ff ff    	mov    -0x98(%rbp),%ecx
    be97:	44 8b 5d 80          	mov    -0x80(%rbp),%r11d
    be9b:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    be9f:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bea3:	49 89 c2             	mov    %rax,%r10
    bea6:	e9 36 fc ff ff       	jmp    bae1 <fwp_hof0.constprop.0+0x861>
    beab:	31 f6                	xor    %esi,%esi
    bead:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    beb0:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    beb4:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    beb8:	e8 53 a0 ff ff       	call   5f10 <fwp_heap_alloc>
    bebd:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    bec1:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    bec5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    bec8:	49 89 c2             	mov    %rax,%r10
    becb:	e9 16 fc ff ff       	jmp    bae6 <fwp_hof0.constprop.0+0x866>
    bed0:	e8 db 97 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bed5:	48 8b 15 bc 25 06 00 	mov    0x625bc(%rip),%rdx        # 6e498 <fwp_fns>
    bedc:	e9 6a f5 ff ff       	jmp    b44b <fwp_hof0.constprop.0+0x1cb>
    bee1:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    bee8:	ff 11                	call   *(%rcx)
    beea:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    beee:	48 89 dc             	mov    %rbx,%rsp
    bef1:	e9 a0 f8 ff ff       	jmp    b796 <fwp_hof0.constprop.0+0x516>
    bef6:	48 89 c7             	mov    %rax,%rdi
    bef9:	e8 42 b0 ff ff       	call   6f40 <fwp_rc_share>
    befe:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    bf02:	e8 39 b0 ff ff       	call   6f40 <fwp_rc_share>
    bf07:	48 8d 05 0a 81 00 00 	lea    0x810a(%rip),%rax        # 14018 <fc12>
    bf0e:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    bf15:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    bf19:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    bf20:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    bf24:	e9 59 f8 ff ff       	jmp    b782 <fwp_hof0.constprop.0+0x502>
    bf29:	66 85 c0             	test   %ax,%ax
    bf2c:	0f 85 26 f4 ff ff    	jne    b358 <fwp_hof0.constprop.0+0xd8>
    bf32:	e9 ff f3 ff ff       	jmp    b336 <fwp_hof0.constprop.0+0xb6>
    bf37:	48 83 05 b1 25 06 00 	addq   $0x1,0x625b1(%rip)        # 6e4f0 <iteration_retains>
    bf3e:	01 
    bf3f:	e9 07 f4 ff ff       	jmp    b34b <fwp_hof0.constprop.0+0xcb>
    bf44:	48 89 df             	mov    %rbx,%rdi
    bf47:	e8 24 b1 ff ff       	call   7070 <fwp_rc_free_arr>
    bf4c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    bf50:	4d 85 ff             	test   %r15,%r15
    bf53:	0f 85 68 f3 ff ff    	jne    b2c1 <fwp_hof0.constprop.0+0x41>
    bf59:	e9 21 fa ff ff       	jmp    b97f <fwp_hof0.constprop.0+0x6ff>
    bf5e:	66 85 c0             	test   %ax,%ax
    bf61:	0f 85 49 f9 ff ff    	jne    b8b0 <fwp_hof0.constprop.0+0x630>
    bf67:	e9 36 f9 ff ff       	jmp    b8a2 <fwp_hof0.constprop.0+0x622>
    bf6c:	66 85 c0             	test   %ax,%ax
    bf6f:	0f 85 fd f9 ff ff    	jne    b972 <fwp_hof0.constprop.0+0x6f2>
    bf75:	e9 d8 f9 ff ff       	jmp    b952 <fwp_hof0.constprop.0+0x6d2>
    bf7a:	4c 89 e0             	mov    %r12,%rax
    bf7d:	48 8d 35 bc 08 06 00 	lea    0x608bc(%rip),%rsi        # 6c840 <fwp_heap>
    bf84:	48 c1 e8 11          	shr    $0x11,%rax
    bf88:	4c 31 e0             	xor    %r12,%rax
    bf8b:	48 89 c2             	mov    %rax,%rdx
    bf8e:	48 c1 ea 09          	shr    $0x9,%rdx
    bf92:	48 31 d0             	xor    %rdx,%rax
    bf95:	0f b6 c0             	movzbl %al,%eax
    bf98:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    bf9f:	00 
    bfa0:	48 85 d2             	test   %rdx,%rdx
    bfa3:	75 24                	jne    bfc9 <fwp_hof0.constprop.0+0xd49>
    bfa5:	eb 59                	jmp    c000 <fwp_hof0.constprop.0+0xd80>
    bfa7:	0f 1f 00             	nopl   (%rax)
    bfaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bfb1:	00 00 00 00 
    bfb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bfbc:	00 00 00 00 
    bfc0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    bfc4:	48 85 d2             	test   %rdx,%rdx
    bfc7:	74 37                	je     c000 <fwp_hof0.constprop.0+0xd80>
    bfc9:	48 89 d0             	mov    %rdx,%rax
    bfcc:	4c 3b 22             	cmp    (%rdx),%r12
    bfcf:	75 ef                	jne    bfc0 <fwp_hof0.constprop.0+0xd40>
    bfd1:	48 8b 42 08          	mov    0x8(%rdx),%rax
    bfd5:	48 83 e8 01          	sub    $0x1,%rax
    bfd9:	48 89 42 08          	mov    %rax,0x8(%rdx)
    bfdd:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    bfe3:	0f 85 89 f9 ff ff    	jne    b972 <fwp_hof0.constprop.0+0x6f2>
    bfe9:	4c 89 e7             	mov    %r12,%rdi
    bfec:	e8 df 97 ff ff       	call   57d0 <fwp_rc_forget_slot>
    bff1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    bff6:	e9 77 f9 ff ff       	jmp    b972 <fwp_hof0.constprop.0+0x6f2>
    bffb:	e8 30 7e ff ff       	call   3e30 <fwp_heap_oom>
    c000:	48 8d 3d d9 49 00 00 	lea    0x49d9(%rip),%rdi        # 109e0 <_IO_stdin_used+0x9e0>
    c007:	e8 44 84 ff ff       	call   4450 <fwp_trap>
    c00c:	48 8d 3d af 42 00 00 	lea    0x42af(%rip),%rdi        # 102c2 <_IO_stdin_used+0x2c2>
    c013:	e8 38 84 ff ff       	call   4450 <fwp_trap>
    c018:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c01f:	00 
    c020:	e8 8b 96 ff ff       	call   56b0 <fwp_rc_wide_dup>
    c025:	e9 2e f3 ff ff       	jmp    b358 <fwp_hof0.constprop.0+0xd8>
    c02a:	e8 21 74 ff ff       	call   3450 <__stack_chk_fail@plt>
    c02f:	90                   	nop
    c030:	4c 89 f7             	mov    %r14,%rdi
    c033:	e8 98 97 ff ff       	call   57d0 <fwp_rc_forget_slot>
    c038:	e9 6f f8 ff ff       	jmp    b8ac <fwp_hof0.constprop.0+0x62c>
    c03d:	0f 1f 00             	nopl   (%rax)

000000000000c040 <f0>:
    c040:	41 56                	push   %r14
    c042:	4c 8d 35 f7 07 06 00 	lea    0x607f7(%rip),%r14        # 6c840 <fwp_heap>
    c049:	41 55                	push   %r13
    c04b:	41 54                	push   %r12
    c04d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    c053:	55                   	push   %rbp
    c054:	53                   	push   %rbx
    c055:	31 db                	xor    %ebx,%ebx
    c057:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    c05e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    c065:	00 00 
    c067:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    c06e:	00 
    c06f:	31 c0                	xor    %eax,%eax
    c071:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    c078:	00 
    c079:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    c080:	00 00 
    c082:	66 48 0f 6e c0       	movq   %rax,%xmm0
    c087:	48 8d 05 a2 b4 ff ff 	lea    -0x4b5e(%rip),%rax        # 7530 <fwp_drop1>
    c08e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    c093:	48 8b 05 3e 24 06 00 	mov    0x6243e(%rip),%rax        # 6e4d8 <fwp_cleanups>
    c09a:	48 89 25 37 24 06 00 	mov    %rsp,0x62437(%rip)        # 6e4d8 <fwp_cleanups>
    c0a1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    c0a5:	48 89 04 24          	mov    %rax,(%rsp)
    c0a9:	48 8d 05 20 7b ff ff 	lea    -0x84e0(%rip),%rax        # 3bd0 <fwp_range_release>
    c0b0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    c0b5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    c0ba:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    c0bf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    c0c4:	eb 47                	jmp    c10d <f0+0xcd>
    c0c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c0cd:	00 00 00 
    c0d0:	80 f9 01             	cmp    $0x1,%cl
    c0d3:	75 29                	jne    c0fe <f0+0xbe>
    c0d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c0d8:	0f b7 c0             	movzwl %ax,%eax
    c0db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c0de:	48 0f af c1          	imul   %rcx,%rax
    c0e2:	48 c1 e8 20          	shr    $0x20,%rax
    c0e6:	48 39 d0             	cmp    %rdx,%rax
    c0e9:	73 13                	jae    c0fe <f0+0xbe>
    c0eb:	49 01 c5             	add    %rax,%r13
    c0ee:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c0f3:	0f 84 c7 27 00 00    	je     e8c0 <f0+0x2880>
    c0f9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    c0fe:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    c103:	49 83 ec 01          	sub    $0x1,%r12
    c107:	0f 82 83 00 00 00    	jb     c190 <f0+0x150>
    c10d:	48 89 ee             	mov    %rbp,%rsi
    c110:	bf 01 00 00 00       	mov    $0x1,%edi
    c115:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    c11c:	00 
    c11d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    c122:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    c129:	00 
    c12a:	e8 21 ac ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c12f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c136:	48 89 c3             	mov    %rax,%rbx
    c139:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c140:	48 c1 e2 10          	shl    $0x10,%rdx
    c144:	48 39 d0             	cmp    %rdx,%rax
    c147:	73 b5                	jae    c0fe <f0+0xbe>
    c149:	48 89 c2             	mov    %rax,%rdx
    c14c:	48 c1 ea 10          	shr    $0x10,%rdx
    c150:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c154:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c15b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c15f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    c163:	4d 85 ed             	test   %r13,%r13
    c166:	74 96                	je     c0fe <f0+0xbe>
    c168:	0f b6 0a             	movzbl (%rdx),%ecx
    c16b:	80 f9 02             	cmp    $0x2,%cl
    c16e:	0f 85 5c ff ff ff    	jne    c0d0 <f0+0x90>
    c174:	66 85 c0             	test   %ax,%ax
    c177:	0f 84 71 ff ff ff    	je     c0ee <f0+0xae>
    c17d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    c182:	49 83 ec 01          	sub    $0x1,%r12
    c186:	73 85                	jae    c10d <f0+0xcd>
    c188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c18f:	00 
    c190:	48 8b 04 24          	mov    (%rsp),%rax
    c194:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    c199:	bf 01 00 00 00       	mov    $0x1,%edi
    c19e:	66 0f 6f 05 2a 4c 00 	movdqa 0x4c2a(%rip),%xmm0        # 10dd0 <msg.4+0xa0>
    c1a5:	00 
    c1a6:	48 89 05 2b 23 06 00 	mov    %rax,0x6232b(%rip)        # 6e4d8 <fwp_cleanups>
    c1ad:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    c1b2:	e8 99 ab ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c1b7:	48 8b 15 5a 1a 06 00 	mov    0x61a5a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c1be:	49 89 c5             	mov    %rax,%r13
    c1c1:	48 2b 05 28 1a 06 00 	sub    0x61a28(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c1c8:	48 c1 e2 10          	shl    $0x10,%rdx
    c1cc:	48 39 d0             	cmp    %rdx,%rax
    c1cf:	73 59                	jae    c22a <f0+0x1ea>
    c1d1:	48 89 c2             	mov    %rax,%rdx
    c1d4:	48 c1 ea 10          	shr    $0x10,%rdx
    c1d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1dc:	48 8b 15 55 1a 06 00 	mov    0x61a55(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c1e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c1e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c1eb:	4d 85 e4             	test   %r12,%r12
    c1ee:	74 3a                	je     c22a <f0+0x1ea>
    c1f0:	0f b6 0a             	movzbl (%rdx),%ecx
    c1f3:	80 f9 02             	cmp    $0x2,%cl
    c1f6:	0f 84 74 27 00 00    	je     e970 <f0+0x2930>
    c1fc:	80 f9 01             	cmp    $0x1,%cl
    c1ff:	75 29                	jne    c22a <f0+0x1ea>
    c201:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c204:	0f b7 c0             	movzwl %ax,%eax
    c207:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c20a:	48 0f af c1          	imul   %rcx,%rax
    c20e:	48 c1 e8 20          	shr    $0x20,%rax
    c212:	48 39 d0             	cmp    %rdx,%rax
    c215:	73 13                	jae    c22a <f0+0x1ea>
    c217:	49 01 c4             	add    %rax,%r12
    c21a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c21f:	0f 84 26 29 00 00    	je     eb4b <f0+0x2b0b>
    c225:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c22a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    c22f:	bf 01 00 00 00       	mov    $0x1,%edi
    c234:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    c239:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c240:	00 f0 3f 
    c243:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    c248:	e8 03 ab ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c24d:	48 8b 15 c4 19 06 00 	mov    0x619c4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c254:	49 89 c5             	mov    %rax,%r13
    c257:	48 2b 05 92 19 06 00 	sub    0x61992(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c25e:	48 c1 e2 10          	shl    $0x10,%rdx
    c262:	48 39 d0             	cmp    %rdx,%rax
    c265:	73 59                	jae    c2c0 <f0+0x280>
    c267:	48 89 c2             	mov    %rax,%rdx
    c26a:	48 c1 ea 10          	shr    $0x10,%rdx
    c26e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c272:	48 8b 15 bf 19 06 00 	mov    0x619bf(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c279:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c27d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c281:	4d 85 e4             	test   %r12,%r12
    c284:	74 3a                	je     c2c0 <f0+0x280>
    c286:	0f b6 0a             	movzbl (%rdx),%ecx
    c289:	80 f9 02             	cmp    $0x2,%cl
    c28c:	0f 84 ce 26 00 00    	je     e960 <f0+0x2920>
    c292:	80 f9 01             	cmp    $0x1,%cl
    c295:	75 29                	jne    c2c0 <f0+0x280>
    c297:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c29a:	0f b7 c0             	movzwl %ax,%eax
    c29d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2a0:	48 0f af c1          	imul   %rcx,%rax
    c2a4:	48 c1 e8 20          	shr    $0x20,%rax
    c2a8:	48 39 d0             	cmp    %rdx,%rax
    c2ab:	73 13                	jae    c2c0 <f0+0x280>
    c2ad:	49 01 c4             	add    %rax,%r12
    c2b0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c2b5:	0f 84 9d 28 00 00    	je     eb58 <f0+0x2b18>
    c2bb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c2c0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    c2c5:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ca:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    c2cf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c2d6:	33 f3 bf 
    c2d9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    c2de:	e8 6d aa ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c2e3:	48 8b 15 2e 19 06 00 	mov    0x6192e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c2ea:	49 89 c5             	mov    %rax,%r13
    c2ed:	48 2b 05 fc 18 06 00 	sub    0x618fc(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c2f4:	48 c1 e2 10          	shl    $0x10,%rdx
    c2f8:	48 39 d0             	cmp    %rdx,%rax
    c2fb:	73 59                	jae    c356 <f0+0x316>
    c2fd:	48 89 c2             	mov    %rax,%rdx
    c300:	48 c1 ea 10          	shr    $0x10,%rdx
    c304:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c308:	48 8b 15 29 19 06 00 	mov    0x61929(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c30f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c313:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c317:	4d 85 e4             	test   %r12,%r12
    c31a:	74 3a                	je     c356 <f0+0x316>
    c31c:	0f b6 0a             	movzbl (%rdx),%ecx
    c31f:	80 f9 02             	cmp    $0x2,%cl
    c322:	0f 84 28 26 00 00    	je     e950 <f0+0x2910>
    c328:	80 f9 01             	cmp    $0x1,%cl
    c32b:	75 29                	jne    c356 <f0+0x316>
    c32d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c330:	0f b7 c0             	movzwl %ax,%eax
    c333:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c336:	48 0f af c1          	imul   %rcx,%rax
    c33a:	48 c1 e8 20          	shr    $0x20,%rax
    c33e:	48 39 d0             	cmp    %rdx,%rax
    c341:	73 13                	jae    c356 <f0+0x316>
    c343:	49 01 c4             	add    %rax,%r12
    c346:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c34b:	0f 84 14 28 00 00    	je     eb65 <f0+0x2b25>
    c351:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c356:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    c35b:	bf 01 00 00 00       	mov    $0x1,%edi
    c360:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    c365:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c36c:	00 f0 3f 
    c36f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    c374:	e8 d7 a9 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c379:	48 8b 15 98 18 06 00 	mov    0x61898(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c380:	49 89 c5             	mov    %rax,%r13
    c383:	48 2b 05 66 18 06 00 	sub    0x61866(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c38a:	48 c1 e2 10          	shl    $0x10,%rdx
    c38e:	48 39 d0             	cmp    %rdx,%rax
    c391:	73 59                	jae    c3ec <f0+0x3ac>
    c393:	48 89 c2             	mov    %rax,%rdx
    c396:	48 c1 ea 10          	shr    $0x10,%rdx
    c39a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c39e:	48 8b 15 93 18 06 00 	mov    0x61893(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c3a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3a9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3ad:	4d 85 e4             	test   %r12,%r12
    c3b0:	74 3a                	je     c3ec <f0+0x3ac>
    c3b2:	0f b6 0a             	movzbl (%rdx),%ecx
    c3b5:	80 f9 02             	cmp    $0x2,%cl
    c3b8:	0f 84 f2 25 00 00    	je     e9b0 <f0+0x2970>
    c3be:	80 f9 01             	cmp    $0x1,%cl
    c3c1:	75 29                	jne    c3ec <f0+0x3ac>
    c3c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3c6:	0f b7 c0             	movzwl %ax,%eax
    c3c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3cc:	48 0f af c1          	imul   %rcx,%rax
    c3d0:	48 c1 e8 20          	shr    $0x20,%rax
    c3d4:	48 39 d0             	cmp    %rdx,%rax
    c3d7:	73 13                	jae    c3ec <f0+0x3ac>
    c3d9:	49 01 c4             	add    %rax,%r12
    c3dc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3e1:	0f 84 8b 27 00 00    	je     eb72 <f0+0x2b32>
    c3e7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c3ec:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c3f3:	33 f3 bf 
    c3f6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    c3fd:	00 
    c3fe:	bf 01 00 00 00       	mov    $0x1,%edi
    c403:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    c40a:	00 
    c40b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    c412:	00 
    c413:	e8 38 a9 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c418:	48 8b 15 f9 17 06 00 	mov    0x617f9(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c41f:	49 89 c5             	mov    %rax,%r13
    c422:	48 2b 05 c7 17 06 00 	sub    0x617c7(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c429:	48 c1 e2 10          	shl    $0x10,%rdx
    c42d:	48 39 d0             	cmp    %rdx,%rax
    c430:	73 59                	jae    c48b <f0+0x44b>
    c432:	48 89 c2             	mov    %rax,%rdx
    c435:	48 c1 ea 10          	shr    $0x10,%rdx
    c439:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c43d:	48 8b 15 f4 17 06 00 	mov    0x617f4(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c444:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c448:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c44c:	4d 85 e4             	test   %r12,%r12
    c44f:	74 3a                	je     c48b <f0+0x44b>
    c451:	0f b6 0a             	movzbl (%rdx),%ecx
    c454:	80 f9 02             	cmp    $0x2,%cl
    c457:	0f 84 43 25 00 00    	je     e9a0 <f0+0x2960>
    c45d:	80 f9 01             	cmp    $0x1,%cl
    c460:	75 29                	jne    c48b <f0+0x44b>
    c462:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c465:	0f b7 c0             	movzwl %ax,%eax
    c468:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c46b:	48 0f af c1          	imul   %rcx,%rax
    c46f:	48 c1 e8 20          	shr    $0x20,%rax
    c473:	48 39 d0             	cmp    %rdx,%rax
    c476:	73 13                	jae    c48b <f0+0x44b>
    c478:	49 01 c4             	add    %rax,%r12
    c47b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c480:	0f 84 f9 26 00 00    	je     eb7f <f0+0x2b3f>
    c486:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c48b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c492:	00 f0 3f 
    c495:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    c49c:	00 
    c49d:	bf 01 00 00 00       	mov    $0x1,%edi
    c4a2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    c4a9:	00 
    c4aa:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    c4b1:	00 
    c4b2:	e8 99 a8 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c4b7:	48 8b 15 5a 17 06 00 	mov    0x6175a(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    c4be:	49 89 c5             	mov    %rax,%r13
    c4c1:	48 2b 05 28 17 06 00 	sub    0x61728(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    c4c8:	48 c1 e2 10          	shl    $0x10,%rdx
    c4cc:	48 39 d0             	cmp    %rdx,%rax
    c4cf:	73 59                	jae    c52a <f0+0x4ea>
    c4d1:	48 89 c2             	mov    %rax,%rdx
    c4d4:	48 c1 ea 10          	shr    $0x10,%rdx
    c4d8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4dc:	48 8b 15 55 17 06 00 	mov    0x61755(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    c4e3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c4e7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c4eb:	4d 85 e4             	test   %r12,%r12
    c4ee:	74 3a                	je     c52a <f0+0x4ea>
    c4f0:	0f b6 0a             	movzbl (%rdx),%ecx
    c4f3:	80 f9 02             	cmp    $0x2,%cl
    c4f6:	0f 84 94 24 00 00    	je     e990 <f0+0x2950>
    c4fc:	80 f9 01             	cmp    $0x1,%cl
    c4ff:	75 29                	jne    c52a <f0+0x4ea>
    c501:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c504:	0f b7 c0             	movzwl %ax,%eax
    c507:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c50a:	48 0f af c1          	imul   %rcx,%rax
    c50e:	48 c1 e8 20          	shr    $0x20,%rax
    c512:	48 39 d0             	cmp    %rdx,%rax
    c515:	73 13                	jae    c52a <f0+0x4ea>
    c517:	49 01 c4             	add    %rax,%r12
    c51a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c51f:	0f 84 67 26 00 00    	je     eb8c <f0+0x2b4c>
    c525:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c52a:	49 bc 33 33 33 33 33 	movabs $0xbff3333333333333,%r12
    c531:	33 f3 bf 
    c534:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    c53b:	00 
    c53c:	bf 01 00 00 00       	mov    $0x1,%edi
    c541:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
    c548:	00 
    c549:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
    c550:	00 
    c551:	49 bd 00 00 00 00 00 	movabs $0x3ff0000000000000,%r13
    c558:	00 f0 3f 
    c55b:	e8 f0 a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c560:	48 89 c7             	mov    %rax,%rdi
    c563:	e8 58 aa ff ff       	call   6fc0 <fwp_rc_fresh>
    c568:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    c56f:	00 
    c570:	bf 01 00 00 00       	mov    $0x1,%edi
    c575:	4c 89 ac 24 b0 00 00 	mov    %r13,0xb0(%rsp)
    c57c:	00 
    c57d:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    c584:	00 
    c585:	e8 c6 a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c58a:	48 89 c7             	mov    %rax,%rdi
    c58d:	e8 2e aa ff ff       	call   6fc0 <fwp_rc_fresh>
    c592:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    c599:	00 
    c59a:	bf 01 00 00 00       	mov    $0x1,%edi
    c59f:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
    c5a6:	00 
    c5a7:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    c5ae:	00 
    c5af:	e8 9c a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c5b4:	48 89 c7             	mov    %rax,%rdi
    c5b7:	e8 04 aa ff ff       	call   6fc0 <fwp_rc_fresh>
    c5bc:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    c5c3:	00 
    c5c4:	bf 01 00 00 00       	mov    $0x1,%edi
    c5c9:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
    c5d0:	00 
    c5d1:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    c5d8:	00 
    c5d9:	e8 72 a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c5de:	48 89 c7             	mov    %rax,%rdi
    c5e1:	e8 da a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c5e6:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    c5ed:	00 
    c5ee:	bf 01 00 00 00       	mov    $0x1,%edi
    c5f3:	4c 89 a4 24 e0 00 00 	mov    %r12,0xe0(%rsp)
    c5fa:	00 
    c5fb:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    c602:	00 
    c603:	e8 48 a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c608:	48 89 c7             	mov    %rax,%rdi
    c60b:	e8 b0 a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c610:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    c617:	00 
    c618:	bf 01 00 00 00       	mov    $0x1,%edi
    c61d:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
    c624:	00 
    c625:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    c62c:	00 
    c62d:	e8 1e a7 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c632:	48 89 c7             	mov    %rax,%rdi
    c635:	e8 86 a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c63a:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    c641:	00 
    c642:	bf 01 00 00 00       	mov    $0x1,%edi
    c647:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
    c64e:	00 
    c64f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    c656:	00 
    c657:	e8 f4 a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c65c:	48 89 c7             	mov    %rax,%rdi
    c65f:	e8 5c a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c664:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    c66b:	00 
    c66c:	bf 01 00 00 00       	mov    $0x1,%edi
    c671:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
    c678:	00 
    c679:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    c680:	00 
    c681:	e8 ca a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c686:	48 89 c7             	mov    %rax,%rdi
    c689:	e8 32 a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c68e:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    c695:	00 
    c696:	bf 01 00 00 00       	mov    $0x1,%edi
    c69b:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
    c6a2:	00 
    c6a3:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    c6aa:	00 
    c6ab:	e8 a0 a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c6b0:	48 89 c7             	mov    %rax,%rdi
    c6b3:	e8 08 a9 ff ff       	call   6fc0 <fwp_rc_fresh>
    c6b8:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    c6bf:	00 
    c6c0:	bf 01 00 00 00       	mov    $0x1,%edi
    c6c5:	4c 89 ac 24 30 01 00 	mov    %r13,0x130(%rsp)
    c6cc:	00 
    c6cd:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    c6d4:	00 
    c6d5:	e8 76 a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c6da:	48 89 c7             	mov    %rax,%rdi
    c6dd:	e8 de a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c6e2:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    c6e9:	00 
    c6ea:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ef:	4c 89 a4 24 40 01 00 	mov    %r12,0x140(%rsp)
    c6f6:	00 
    c6f7:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    c6fe:	00 
    c6ff:	e8 4c a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c704:	48 89 c7             	mov    %rax,%rdi
    c707:	e8 b4 a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c70c:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    c713:	00 
    c714:	bf 01 00 00 00       	mov    $0x1,%edi
    c719:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
    c720:	00 
    c721:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    c728:	00 
    c729:	e8 22 a6 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c72e:	48 89 c7             	mov    %rax,%rdi
    c731:	e8 8a a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c736:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    c73d:	00 
    c73e:	bf 01 00 00 00       	mov    $0x1,%edi
    c743:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
    c74a:	00 
    c74b:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    c752:	00 
    c753:	e8 f8 a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c758:	48 89 c7             	mov    %rax,%rdi
    c75b:	e8 60 a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c760:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    c767:	00 
    c768:	bf 01 00 00 00       	mov    $0x1,%edi
    c76d:	4c 89 ac 24 70 01 00 	mov    %r13,0x170(%rsp)
    c774:	00 
    c775:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    c77c:	00 
    c77d:	e8 ce a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c782:	48 89 c7             	mov    %rax,%rdi
    c785:	e8 36 a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c78a:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    c791:	00 
    c792:	bf 01 00 00 00       	mov    $0x1,%edi
    c797:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
    c79e:	00 
    c79f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    c7a6:	00 
    c7a7:	e8 a4 a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c7ac:	48 89 c7             	mov    %rax,%rdi
    c7af:	e8 0c a8 ff ff       	call   6fc0 <fwp_rc_fresh>
    c7b4:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    c7bb:	00 
    c7bc:	bf 01 00 00 00       	mov    $0x1,%edi
    c7c1:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
    c7c8:	00 
    c7c9:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    c7d0:	00 
    c7d1:	e8 7a a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c7d6:	48 89 c7             	mov    %rax,%rdi
    c7d9:	e8 e2 a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c7de:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    c7e5:	00 
    c7e6:	bf 01 00 00 00       	mov    $0x1,%edi
    c7eb:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
    c7f2:	00 
    c7f3:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    c7fa:	00 
    c7fb:	e8 50 a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c800:	48 89 c7             	mov    %rax,%rdi
    c803:	e8 b8 a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c808:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    c80f:	00 
    c810:	bf 01 00 00 00       	mov    $0x1,%edi
    c815:	4c 89 ac 24 b0 01 00 	mov    %r13,0x1b0(%rsp)
    c81c:	00 
    c81d:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    c824:	00 
    c825:	e8 26 a5 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c82a:	48 89 c7             	mov    %rax,%rdi
    c82d:	e8 8e a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c832:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    c839:	00 
    c83a:	bf 01 00 00 00       	mov    $0x1,%edi
    c83f:	4c 89 a4 24 c0 01 00 	mov    %r12,0x1c0(%rsp)
    c846:	00 
    c847:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    c84e:	00 
    c84f:	e8 fc a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c854:	48 89 c7             	mov    %rax,%rdi
    c857:	e8 64 a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c85c:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    c863:	00 
    c864:	bf 01 00 00 00       	mov    $0x1,%edi
    c869:	4c 89 ac 24 d0 01 00 	mov    %r13,0x1d0(%rsp)
    c870:	00 
    c871:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    c878:	00 
    c879:	e8 d2 a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c87e:	48 89 c7             	mov    %rax,%rdi
    c881:	e8 3a a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c886:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    c88d:	00 
    c88e:	bf 01 00 00 00       	mov    $0x1,%edi
    c893:	4c 89 a4 24 e0 01 00 	mov    %r12,0x1e0(%rsp)
    c89a:	00 
    c89b:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    c8a2:	00 
    c8a3:	e8 a8 a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c8a8:	48 89 c7             	mov    %rax,%rdi
    c8ab:	e8 10 a7 ff ff       	call   6fc0 <fwp_rc_fresh>
    c8b0:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    c8b7:	00 
    c8b8:	bf 01 00 00 00       	mov    $0x1,%edi
    c8bd:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
    c8c4:	00 
    c8c5:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    c8cc:	00 
    c8cd:	e8 7e a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c8d2:	48 89 c7             	mov    %rax,%rdi
    c8d5:	e8 e6 a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c8da:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    c8e1:	00 
    c8e2:	bf 01 00 00 00       	mov    $0x1,%edi
    c8e7:	4c 89 a4 24 00 02 00 	mov    %r12,0x200(%rsp)
    c8ee:	00 
    c8ef:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    c8f6:	00 
    c8f7:	e8 54 a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c8fc:	48 89 c7             	mov    %rax,%rdi
    c8ff:	e8 bc a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c904:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    c90b:	00 
    c90c:	bf 01 00 00 00       	mov    $0x1,%edi
    c911:	4c 89 ac 24 10 02 00 	mov    %r13,0x210(%rsp)
    c918:	00 
    c919:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    c920:	00 
    c921:	e8 2a a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c926:	48 89 c7             	mov    %rax,%rdi
    c929:	e8 92 a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c92e:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    c935:	00 
    c936:	bf 01 00 00 00       	mov    $0x1,%edi
    c93b:	4c 89 a4 24 20 02 00 	mov    %r12,0x220(%rsp)
    c942:	00 
    c943:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    c94a:	00 
    c94b:	e8 00 a4 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c950:	48 89 c7             	mov    %rax,%rdi
    c953:	e8 68 a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c958:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    c95f:	00 
    c960:	bf 01 00 00 00       	mov    $0x1,%edi
    c965:	4c 89 ac 24 30 02 00 	mov    %r13,0x230(%rsp)
    c96c:	00 
    c96d:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    c974:	00 
    c975:	e8 d6 a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c97a:	48 89 c7             	mov    %rax,%rdi
    c97d:	e8 3e a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c982:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    c989:	00 
    c98a:	bf 01 00 00 00       	mov    $0x1,%edi
    c98f:	4c 89 a4 24 40 02 00 	mov    %r12,0x240(%rsp)
    c996:	00 
    c997:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    c99e:	00 
    c99f:	e8 ac a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c9a4:	48 89 c7             	mov    %rax,%rdi
    c9a7:	e8 14 a6 ff ff       	call   6fc0 <fwp_rc_fresh>
    c9ac:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    c9b3:	00 
    c9b4:	bf 01 00 00 00       	mov    $0x1,%edi
    c9b9:	4c 89 ac 24 50 02 00 	mov    %r13,0x250(%rsp)
    c9c0:	00 
    c9c1:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    c9c8:	00 
    c9c9:	e8 82 a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c9ce:	48 89 c7             	mov    %rax,%rdi
    c9d1:	e8 ea a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    c9d6:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    c9dd:	00 
    c9de:	bf 01 00 00 00       	mov    $0x1,%edi
    c9e3:	4c 89 a4 24 60 02 00 	mov    %r12,0x260(%rsp)
    c9ea:	00 
    c9eb:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    c9f2:	00 
    c9f3:	e8 58 a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    c9f8:	48 89 c7             	mov    %rax,%rdi
    c9fb:	e8 c0 a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    ca00:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    ca07:	00 
    ca08:	bf 01 00 00 00       	mov    $0x1,%edi
    ca0d:	4c 89 ac 24 70 02 00 	mov    %r13,0x270(%rsp)
    ca14:	00 
    ca15:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    ca1c:	00 
    ca1d:	e8 2e a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ca22:	48 89 c7             	mov    %rax,%rdi
    ca25:	e8 96 a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    ca2a:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    ca31:	00 
    ca32:	bf 01 00 00 00       	mov    $0x1,%edi
    ca37:	4c 89 a4 24 80 02 00 	mov    %r12,0x280(%rsp)
    ca3e:	00 
    ca3f:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    ca46:	00 
    ca47:	e8 04 a3 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ca4c:	48 89 c7             	mov    %rax,%rdi
    ca4f:	e8 6c a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    ca54:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    ca5b:	00 
    ca5c:	bf 01 00 00 00       	mov    $0x1,%edi
    ca61:	4c 89 ac 24 90 02 00 	mov    %r13,0x290(%rsp)
    ca68:	00 
    ca69:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    ca70:	00 
    ca71:	e8 da a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ca76:	48 89 c7             	mov    %rax,%rdi
    ca79:	e8 42 a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    ca7e:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    ca85:	00 
    ca86:	bf 01 00 00 00       	mov    $0x1,%edi
    ca8b:	4c 89 a4 24 a0 02 00 	mov    %r12,0x2a0(%rsp)
    ca92:	00 
    ca93:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    ca9a:	00 
    ca9b:	e8 b0 a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    caa0:	48 89 c7             	mov    %rax,%rdi
    caa3:	e8 18 a5 ff ff       	call   6fc0 <fwp_rc_fresh>
    caa8:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    caaf:	00 
    cab0:	bf 01 00 00 00       	mov    $0x1,%edi
    cab5:	4c 89 ac 24 b0 02 00 	mov    %r13,0x2b0(%rsp)
    cabc:	00 
    cabd:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    cac4:	00 
    cac5:	e8 86 a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    caca:	48 89 c7             	mov    %rax,%rdi
    cacd:	e8 ee a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cad2:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    cad9:	00 
    cada:	bf 01 00 00 00       	mov    $0x1,%edi
    cadf:	4c 89 a4 24 c0 02 00 	mov    %r12,0x2c0(%rsp)
    cae6:	00 
    cae7:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    caee:	00 
    caef:	e8 5c a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    caf4:	48 89 c7             	mov    %rax,%rdi
    caf7:	e8 c4 a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cafc:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    cb03:	00 
    cb04:	bf 01 00 00 00       	mov    $0x1,%edi
    cb09:	4c 89 ac 24 d0 02 00 	mov    %r13,0x2d0(%rsp)
    cb10:	00 
    cb11:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    cb18:	00 
    cb19:	e8 32 a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cb1e:	48 89 c7             	mov    %rax,%rdi
    cb21:	e8 9a a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cb26:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    cb2d:	00 
    cb2e:	bf 01 00 00 00       	mov    $0x1,%edi
    cb33:	4c 89 a4 24 e0 02 00 	mov    %r12,0x2e0(%rsp)
    cb3a:	00 
    cb3b:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    cb42:	00 
    cb43:	e8 08 a2 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cb48:	48 89 c7             	mov    %rax,%rdi
    cb4b:	e8 70 a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cb50:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    cb57:	00 
    cb58:	bf 01 00 00 00       	mov    $0x1,%edi
    cb5d:	4c 89 ac 24 f0 02 00 	mov    %r13,0x2f0(%rsp)
    cb64:	00 
    cb65:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    cb6c:	00 
    cb6d:	e8 de a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cb72:	48 89 c7             	mov    %rax,%rdi
    cb75:	e8 46 a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cb7a:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    cb81:	00 
    cb82:	bf 01 00 00 00       	mov    $0x1,%edi
    cb87:	4c 89 a4 24 00 03 00 	mov    %r12,0x300(%rsp)
    cb8e:	00 
    cb8f:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    cb96:	00 
    cb97:	e8 b4 a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cb9c:	48 89 c7             	mov    %rax,%rdi
    cb9f:	e8 1c a4 ff ff       	call   6fc0 <fwp_rc_fresh>
    cba4:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    cbab:	00 
    cbac:	bf 01 00 00 00       	mov    $0x1,%edi
    cbb1:	4c 89 ac 24 10 03 00 	mov    %r13,0x310(%rsp)
    cbb8:	00 
    cbb9:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    cbc0:	00 
    cbc1:	e8 8a a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cbc6:	48 89 c7             	mov    %rax,%rdi
    cbc9:	e8 f2 a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cbce:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    cbd5:	00 
    cbd6:	bf 01 00 00 00       	mov    $0x1,%edi
    cbdb:	4c 89 a4 24 20 03 00 	mov    %r12,0x320(%rsp)
    cbe2:	00 
    cbe3:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    cbea:	00 
    cbeb:	e8 60 a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cbf0:	48 89 c7             	mov    %rax,%rdi
    cbf3:	e8 c8 a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cbf8:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    cbff:	00 
    cc00:	bf 01 00 00 00       	mov    $0x1,%edi
    cc05:	4c 89 ac 24 30 03 00 	mov    %r13,0x330(%rsp)
    cc0c:	00 
    cc0d:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    cc14:	00 
    cc15:	e8 36 a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cc1a:	48 89 c7             	mov    %rax,%rdi
    cc1d:	e8 9e a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cc22:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    cc29:	00 
    cc2a:	bf 01 00 00 00       	mov    $0x1,%edi
    cc2f:	4c 89 a4 24 40 03 00 	mov    %r12,0x340(%rsp)
    cc36:	00 
    cc37:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    cc3e:	00 
    cc3f:	e8 0c a1 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cc44:	48 89 c7             	mov    %rax,%rdi
    cc47:	e8 74 a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cc4c:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    cc53:	00 
    cc54:	bf 01 00 00 00       	mov    $0x1,%edi
    cc59:	4c 89 ac 24 50 03 00 	mov    %r13,0x350(%rsp)
    cc60:	00 
    cc61:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    cc68:	00 
    cc69:	e8 e2 a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cc6e:	48 89 c7             	mov    %rax,%rdi
    cc71:	e8 4a a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cc76:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    cc7d:	00 
    cc7e:	bf 01 00 00 00       	mov    $0x1,%edi
    cc83:	4c 89 a4 24 60 03 00 	mov    %r12,0x360(%rsp)
    cc8a:	00 
    cc8b:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    cc92:	00 
    cc93:	e8 b8 a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cc98:	48 89 c7             	mov    %rax,%rdi
    cc9b:	e8 20 a3 ff ff       	call   6fc0 <fwp_rc_fresh>
    cca0:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    cca7:	00 
    cca8:	bf 01 00 00 00       	mov    $0x1,%edi
    ccad:	4c 89 ac 24 70 03 00 	mov    %r13,0x370(%rsp)
    ccb4:	00 
    ccb5:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    ccbc:	00 
    ccbd:	e8 8e a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ccc2:	48 89 c7             	mov    %rax,%rdi
    ccc5:	e8 f6 a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    ccca:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    ccd1:	00 
    ccd2:	bf 01 00 00 00       	mov    $0x1,%edi
    ccd7:	4c 89 a4 24 80 03 00 	mov    %r12,0x380(%rsp)
    ccde:	00 
    ccdf:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    cce6:	00 
    cce7:	e8 64 a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ccec:	48 89 c7             	mov    %rax,%rdi
    ccef:	e8 cc a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    ccf4:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    ccfb:	00 
    ccfc:	bf 01 00 00 00       	mov    $0x1,%edi
    cd01:	4c 89 ac 24 90 03 00 	mov    %r13,0x390(%rsp)
    cd08:	00 
    cd09:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    cd10:	00 
    cd11:	e8 3a a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cd16:	48 89 c7             	mov    %rax,%rdi
    cd19:	e8 a2 a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    cd1e:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    cd25:	00 
    cd26:	bf 01 00 00 00       	mov    $0x1,%edi
    cd2b:	4c 89 a4 24 a0 03 00 	mov    %r12,0x3a0(%rsp)
    cd32:	00 
    cd33:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    cd3a:	00 
    cd3b:	e8 10 a0 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cd40:	48 89 c7             	mov    %rax,%rdi
    cd43:	e8 78 a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    cd48:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    cd4f:	00 
    cd50:	bf 01 00 00 00       	mov    $0x1,%edi
    cd55:	4c 89 ac 24 b0 03 00 	mov    %r13,0x3b0(%rsp)
    cd5c:	00 
    cd5d:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    cd64:	00 
    cd65:	e8 e6 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cd6a:	48 89 c7             	mov    %rax,%rdi
    cd6d:	e8 4e a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    cd72:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    cd79:	00 
    cd7a:	bf 01 00 00 00       	mov    $0x1,%edi
    cd7f:	4c 89 a4 24 c0 03 00 	mov    %r12,0x3c0(%rsp)
    cd86:	00 
    cd87:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    cd8e:	00 
    cd8f:	e8 bc 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cd94:	48 89 c7             	mov    %rax,%rdi
    cd97:	e8 24 a2 ff ff       	call   6fc0 <fwp_rc_fresh>
    cd9c:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    cda3:	00 
    cda4:	bf 01 00 00 00       	mov    $0x1,%edi
    cda9:	4c 89 ac 24 d0 03 00 	mov    %r13,0x3d0(%rsp)
    cdb0:	00 
    cdb1:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    cdb8:	00 
    cdb9:	e8 92 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cdbe:	48 89 c7             	mov    %rax,%rdi
    cdc1:	e8 fa a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    cdc6:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    cdcd:	00 
    cdce:	bf 01 00 00 00       	mov    $0x1,%edi
    cdd3:	4c 89 a4 24 e0 03 00 	mov    %r12,0x3e0(%rsp)
    cdda:	00 
    cddb:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    cde2:	00 
    cde3:	e8 68 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cde8:	48 89 c7             	mov    %rax,%rdi
    cdeb:	e8 d0 a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    cdf0:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    cdf7:	00 
    cdf8:	bf 01 00 00 00       	mov    $0x1,%edi
    cdfd:	4c 89 ac 24 f0 03 00 	mov    %r13,0x3f0(%rsp)
    ce04:	00 
    ce05:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    ce0c:	00 
    ce0d:	e8 3e 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ce12:	48 89 c7             	mov    %rax,%rdi
    ce15:	e8 a6 a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    ce1a:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    ce21:	00 
    ce22:	bf 01 00 00 00       	mov    $0x1,%edi
    ce27:	4c 89 a4 24 00 04 00 	mov    %r12,0x400(%rsp)
    ce2e:	00 
    ce2f:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    ce36:	00 
    ce37:	e8 14 9f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ce3c:	48 89 c7             	mov    %rax,%rdi
    ce3f:	e8 7c a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    ce44:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    ce4b:	00 
    ce4c:	bf 01 00 00 00       	mov    $0x1,%edi
    ce51:	4c 89 ac 24 10 04 00 	mov    %r13,0x410(%rsp)
    ce58:	00 
    ce59:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    ce60:	00 
    ce61:	e8 ea 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ce66:	48 89 c7             	mov    %rax,%rdi
    ce69:	e8 52 a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    ce6e:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    ce75:	00 
    ce76:	bf 01 00 00 00       	mov    $0x1,%edi
    ce7b:	4c 89 a4 24 20 04 00 	mov    %r12,0x420(%rsp)
    ce82:	00 
    ce83:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    ce8a:	00 
    ce8b:	e8 c0 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ce90:	48 89 c7             	mov    %rax,%rdi
    ce93:	e8 28 a1 ff ff       	call   6fc0 <fwp_rc_fresh>
    ce98:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    ce9f:	00 
    cea0:	bf 01 00 00 00       	mov    $0x1,%edi
    cea5:	4c 89 ac 24 30 04 00 	mov    %r13,0x430(%rsp)
    ceac:	00 
    cead:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    ceb4:	00 
    ceb5:	e8 96 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    ceba:	48 89 c7             	mov    %rax,%rdi
    cebd:	e8 fe a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cec2:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    cec9:	00 
    ceca:	bf 01 00 00 00       	mov    $0x1,%edi
    cecf:	4c 89 a4 24 40 04 00 	mov    %r12,0x440(%rsp)
    ced6:	00 
    ced7:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    cede:	00 
    cedf:	e8 6c 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cee4:	48 89 c7             	mov    %rax,%rdi
    cee7:	e8 d4 a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    ceec:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    cef3:	00 
    cef4:	bf 01 00 00 00       	mov    $0x1,%edi
    cef9:	4c 89 ac 24 50 04 00 	mov    %r13,0x450(%rsp)
    cf00:	00 
    cf01:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    cf08:	00 
    cf09:	e8 42 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cf0e:	48 89 c7             	mov    %rax,%rdi
    cf11:	e8 aa a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cf16:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    cf1d:	00 
    cf1e:	bf 01 00 00 00       	mov    $0x1,%edi
    cf23:	4c 89 a4 24 60 04 00 	mov    %r12,0x460(%rsp)
    cf2a:	00 
    cf2b:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    cf32:	00 
    cf33:	e8 18 9e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cf38:	48 89 c7             	mov    %rax,%rdi
    cf3b:	e8 80 a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cf40:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    cf47:	00 
    cf48:	bf 01 00 00 00       	mov    $0x1,%edi
    cf4d:	4c 89 ac 24 70 04 00 	mov    %r13,0x470(%rsp)
    cf54:	00 
    cf55:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    cf5c:	00 
    cf5d:	e8 ee 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cf62:	48 89 c7             	mov    %rax,%rdi
    cf65:	e8 56 a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cf6a:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    cf71:	00 
    cf72:	bf 01 00 00 00       	mov    $0x1,%edi
    cf77:	4c 89 a4 24 80 04 00 	mov    %r12,0x480(%rsp)
    cf7e:	00 
    cf7f:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    cf86:	00 
    cf87:	e8 c4 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cf8c:	48 89 c7             	mov    %rax,%rdi
    cf8f:	e8 2c a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cf94:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    cf9b:	00 
    cf9c:	bf 01 00 00 00       	mov    $0x1,%edi
    cfa1:	4c 89 ac 24 90 04 00 	mov    %r13,0x490(%rsp)
    cfa8:	00 
    cfa9:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    cfb0:	00 
    cfb1:	e8 9a 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cfb6:	48 89 c7             	mov    %rax,%rdi
    cfb9:	e8 02 a0 ff ff       	call   6fc0 <fwp_rc_fresh>
    cfbe:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    cfc5:	00 
    cfc6:	bf 01 00 00 00       	mov    $0x1,%edi
    cfcb:	4c 89 a4 24 a0 04 00 	mov    %r12,0x4a0(%rsp)
    cfd2:	00 
    cfd3:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    cfda:	00 
    cfdb:	e8 70 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    cfe0:	48 89 c7             	mov    %rax,%rdi
    cfe3:	e8 d8 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    cfe8:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    cfef:	00 
    cff0:	bf 01 00 00 00       	mov    $0x1,%edi
    cff5:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
    cffc:	00 
    cffd:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    d004:	00 
    d005:	e8 46 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d00a:	48 89 c7             	mov    %rax,%rdi
    d00d:	e8 ae 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    d012:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    d019:	00 
    d01a:	bf 01 00 00 00       	mov    $0x1,%edi
    d01f:	4c 89 a4 24 c0 04 00 	mov    %r12,0x4c0(%rsp)
    d026:	00 
    d027:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    d02e:	00 
    d02f:	e8 1c 9d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d034:	48 89 c7             	mov    %rax,%rdi
    d037:	e8 84 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    d03c:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    d043:	00 
    d044:	bf 01 00 00 00       	mov    $0x1,%edi
    d049:	4c 89 ac 24 d0 04 00 	mov    %r13,0x4d0(%rsp)
    d050:	00 
    d051:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    d058:	00 
    d059:	e8 f2 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d05e:	48 89 c7             	mov    %rax,%rdi
    d061:	e8 5a 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    d066:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    d06d:	00 
    d06e:	bf 01 00 00 00       	mov    $0x1,%edi
    d073:	4c 89 a4 24 e0 04 00 	mov    %r12,0x4e0(%rsp)
    d07a:	00 
    d07b:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    d082:	00 
    d083:	e8 c8 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d088:	48 89 c7             	mov    %rax,%rdi
    d08b:	e8 30 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    d090:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    d097:	00 
    d098:	bf 01 00 00 00       	mov    $0x1,%edi
    d09d:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
    d0a4:	00 
    d0a5:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    d0ac:	00 
    d0ad:	e8 9e 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d0b2:	48 89 c7             	mov    %rax,%rdi
    d0b5:	e8 06 9f ff ff       	call   6fc0 <fwp_rc_fresh>
    d0ba:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    d0c1:	00 
    d0c2:	bf 01 00 00 00       	mov    $0x1,%edi
    d0c7:	4c 89 a4 24 00 05 00 	mov    %r12,0x500(%rsp)
    d0ce:	00 
    d0cf:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    d0d6:	00 
    d0d7:	e8 74 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d0dc:	48 89 c7             	mov    %rax,%rdi
    d0df:	e8 dc 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d0e4:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    d0eb:	00 
    d0ec:	bf 01 00 00 00       	mov    $0x1,%edi
    d0f1:	4c 89 ac 24 10 05 00 	mov    %r13,0x510(%rsp)
    d0f8:	00 
    d0f9:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    d100:	00 
    d101:	e8 4a 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d106:	48 89 c7             	mov    %rax,%rdi
    d109:	e8 b2 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d10e:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    d115:	00 
    d116:	bf 01 00 00 00       	mov    $0x1,%edi
    d11b:	4c 89 a4 24 20 05 00 	mov    %r12,0x520(%rsp)
    d122:	00 
    d123:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    d12a:	00 
    d12b:	e8 20 9c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d130:	48 89 c7             	mov    %rax,%rdi
    d133:	e8 88 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d138:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    d13f:	00 
    d140:	bf 01 00 00 00       	mov    $0x1,%edi
    d145:	4c 89 ac 24 30 05 00 	mov    %r13,0x530(%rsp)
    d14c:	00 
    d14d:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    d154:	00 
    d155:	e8 f6 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d15a:	48 89 c7             	mov    %rax,%rdi
    d15d:	e8 5e 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d162:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    d169:	00 
    d16a:	bf 01 00 00 00       	mov    $0x1,%edi
    d16f:	4c 89 a4 24 40 05 00 	mov    %r12,0x540(%rsp)
    d176:	00 
    d177:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    d17e:	00 
    d17f:	e8 cc 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d184:	48 89 c7             	mov    %rax,%rdi
    d187:	e8 34 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d18c:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    d193:	00 
    d194:	bf 01 00 00 00       	mov    $0x1,%edi
    d199:	4c 89 ac 24 50 05 00 	mov    %r13,0x550(%rsp)
    d1a0:	00 
    d1a1:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    d1a8:	00 
    d1a9:	e8 a2 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d1ae:	48 89 c7             	mov    %rax,%rdi
    d1b1:	e8 0a 9e ff ff       	call   6fc0 <fwp_rc_fresh>
    d1b6:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    d1bd:	00 
    d1be:	bf 01 00 00 00       	mov    $0x1,%edi
    d1c3:	4c 89 a4 24 60 05 00 	mov    %r12,0x560(%rsp)
    d1ca:	00 
    d1cb:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    d1d2:	00 
    d1d3:	e8 78 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d1d8:	48 89 c7             	mov    %rax,%rdi
    d1db:	e8 e0 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d1e0:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    d1e7:	00 
    d1e8:	bf 01 00 00 00       	mov    $0x1,%edi
    d1ed:	4c 89 ac 24 70 05 00 	mov    %r13,0x570(%rsp)
    d1f4:	00 
    d1f5:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    d1fc:	00 
    d1fd:	e8 4e 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d202:	48 89 c7             	mov    %rax,%rdi
    d205:	e8 b6 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d20a:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    d211:	00 
    d212:	bf 01 00 00 00       	mov    $0x1,%edi
    d217:	4c 89 a4 24 80 05 00 	mov    %r12,0x580(%rsp)
    d21e:	00 
    d21f:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    d226:	00 
    d227:	e8 24 9b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d22c:	48 89 c7             	mov    %rax,%rdi
    d22f:	e8 8c 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d234:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    d23b:	00 
    d23c:	bf 01 00 00 00       	mov    $0x1,%edi
    d241:	4c 89 ac 24 90 05 00 	mov    %r13,0x590(%rsp)
    d248:	00 
    d249:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    d250:	00 
    d251:	e8 fa 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d256:	48 89 c7             	mov    %rax,%rdi
    d259:	e8 62 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d25e:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    d265:	00 
    d266:	bf 01 00 00 00       	mov    $0x1,%edi
    d26b:	4c 89 a4 24 a0 05 00 	mov    %r12,0x5a0(%rsp)
    d272:	00 
    d273:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    d27a:	00 
    d27b:	e8 d0 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d280:	48 89 c7             	mov    %rax,%rdi
    d283:	e8 38 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d288:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    d28f:	00 
    d290:	bf 01 00 00 00       	mov    $0x1,%edi
    d295:	4c 89 ac 24 b0 05 00 	mov    %r13,0x5b0(%rsp)
    d29c:	00 
    d29d:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    d2a4:	00 
    d2a5:	e8 a6 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d2aa:	48 89 c7             	mov    %rax,%rdi
    d2ad:	e8 0e 9d ff ff       	call   6fc0 <fwp_rc_fresh>
    d2b2:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    d2b9:	00 
    d2ba:	bf 01 00 00 00       	mov    $0x1,%edi
    d2bf:	4c 89 a4 24 c0 05 00 	mov    %r12,0x5c0(%rsp)
    d2c6:	00 
    d2c7:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    d2ce:	00 
    d2cf:	e8 7c 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d2d4:	48 89 c7             	mov    %rax,%rdi
    d2d7:	e8 e4 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d2dc:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    d2e3:	00 
    d2e4:	bf 01 00 00 00       	mov    $0x1,%edi
    d2e9:	4c 89 ac 24 d0 05 00 	mov    %r13,0x5d0(%rsp)
    d2f0:	00 
    d2f1:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    d2f8:	00 
    d2f9:	e8 52 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d2fe:	48 89 c7             	mov    %rax,%rdi
    d301:	e8 ba 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d306:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    d30d:	00 
    d30e:	bf 01 00 00 00       	mov    $0x1,%edi
    d313:	4c 89 a4 24 e0 05 00 	mov    %r12,0x5e0(%rsp)
    d31a:	00 
    d31b:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    d322:	00 
    d323:	e8 28 9a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d328:	48 89 c7             	mov    %rax,%rdi
    d32b:	e8 90 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d330:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    d337:	00 
    d338:	bf 01 00 00 00       	mov    $0x1,%edi
    d33d:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
    d344:	00 
    d345:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    d34c:	00 
    d34d:	e8 fe 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d352:	48 89 c7             	mov    %rax,%rdi
    d355:	e8 66 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d35a:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    d361:	00 
    d362:	bf 01 00 00 00       	mov    $0x1,%edi
    d367:	4c 89 a4 24 00 06 00 	mov    %r12,0x600(%rsp)
    d36e:	00 
    d36f:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    d376:	00 
    d377:	e8 d4 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d37c:	48 89 c7             	mov    %rax,%rdi
    d37f:	e8 3c 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d384:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    d38b:	00 
    d38c:	bf 01 00 00 00       	mov    $0x1,%edi
    d391:	4c 89 ac 24 10 06 00 	mov    %r13,0x610(%rsp)
    d398:	00 
    d399:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    d3a0:	00 
    d3a1:	e8 aa 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d3a6:	48 89 c7             	mov    %rax,%rdi
    d3a9:	e8 12 9c ff ff       	call   6fc0 <fwp_rc_fresh>
    d3ae:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    d3b5:	00 
    d3b6:	bf 01 00 00 00       	mov    $0x1,%edi
    d3bb:	4c 89 a4 24 20 06 00 	mov    %r12,0x620(%rsp)
    d3c2:	00 
    d3c3:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    d3ca:	00 
    d3cb:	e8 80 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d3d0:	48 89 c7             	mov    %rax,%rdi
    d3d3:	e8 e8 9b ff ff       	call   6fc0 <fwp_rc_fresh>
    d3d8:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    d3df:	00 
    d3e0:	bf 01 00 00 00       	mov    $0x1,%edi
    d3e5:	4c 89 ac 24 30 06 00 	mov    %r13,0x630(%rsp)
    d3ec:	00 
    d3ed:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    d3f4:	00 
    d3f5:	e8 56 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d3fa:	48 89 c7             	mov    %rax,%rdi
    d3fd:	e8 be 9b ff ff       	call   6fc0 <fwp_rc_fresh>
    d402:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    d409:	00 
    d40a:	bf 01 00 00 00       	mov    $0x1,%edi
    d40f:	4c 89 a4 24 40 06 00 	mov    %r12,0x640(%rsp)
    d416:	00 
    d417:	48 89 84 24 48 06 00 	mov    %rax,0x648(%rsp)
    d41e:	00 
    d41f:	e8 2c 99 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d424:	48 8b 15 ed 07 06 00 	mov    0x607ed(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d42b:	49 89 c5             	mov    %rax,%r13
    d42e:	48 2b 05 bb 07 06 00 	sub    0x607bb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d435:	48 c1 e2 10          	shl    $0x10,%rdx
    d439:	48 39 d0             	cmp    %rdx,%rax
    d43c:	73 59                	jae    d497 <f0+0x1457>
    d43e:	48 89 c2             	mov    %rax,%rdx
    d441:	48 c1 ea 10          	shr    $0x10,%rdx
    d445:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d449:	48 8b 15 e8 07 06 00 	mov    0x607e8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d450:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d454:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d458:	4d 85 e4             	test   %r12,%r12
    d45b:	74 3a                	je     d497 <f0+0x1457>
    d45d:	0f b6 0a             	movzbl (%rdx),%ecx
    d460:	80 f9 02             	cmp    $0x2,%cl
    d463:	0f 84 17 15 00 00    	je     e980 <f0+0x2940>
    d469:	80 f9 01             	cmp    $0x1,%cl
    d46c:	75 29                	jne    d497 <f0+0x1457>
    d46e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d471:	0f b7 c0             	movzwl %ax,%eax
    d474:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d477:	48 0f af c1          	imul   %rcx,%rax
    d47b:	48 c1 e8 20          	shr    $0x20,%rax
    d47f:	48 39 d0             	cmp    %rdx,%rax
    d482:	73 13                	jae    d497 <f0+0x1457>
    d484:	49 01 c4             	add    %rax,%r12
    d487:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d48c:	0f 84 07 17 00 00    	je     eb99 <f0+0x2b59>
    d492:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d497:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d49e:	00 f0 3f 
    d4a1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    d4a8:	00 
    d4a9:	bf 01 00 00 00       	mov    $0x1,%edi
    d4ae:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    d4b5:	00 
    d4b6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    d4bd:	00 
    d4be:	e8 8d 98 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d4c3:	48 8b 15 4e 07 06 00 	mov    0x6074e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d4ca:	49 89 c5             	mov    %rax,%r13
    d4cd:	48 2b 05 1c 07 06 00 	sub    0x6071c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d4d4:	48 c1 e2 10          	shl    $0x10,%rdx
    d4d8:	48 39 d0             	cmp    %rdx,%rax
    d4db:	73 59                	jae    d536 <f0+0x14f6>
    d4dd:	48 89 c2             	mov    %rax,%rdx
    d4e0:	48 c1 ea 10          	shr    $0x10,%rdx
    d4e4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4e8:	48 8b 15 49 07 06 00 	mov    0x60749(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d4ef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4f3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4f7:	4d 85 e4             	test   %r12,%r12
    d4fa:	74 3a                	je     d536 <f0+0x14f6>
    d4fc:	0f b6 0a             	movzbl (%rdx),%ecx
    d4ff:	80 f9 02             	cmp    $0x2,%cl
    d502:	0f 84 28 15 00 00    	je     ea30 <f0+0x29f0>
    d508:	80 f9 01             	cmp    $0x1,%cl
    d50b:	75 29                	jne    d536 <f0+0x14f6>
    d50d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d510:	0f b7 c0             	movzwl %ax,%eax
    d513:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d516:	48 0f af c1          	imul   %rcx,%rax
    d51a:	48 c1 e8 20          	shr    $0x20,%rax
    d51e:	48 39 d0             	cmp    %rdx,%rax
    d521:	73 13                	jae    d536 <f0+0x14f6>
    d523:	49 01 c4             	add    %rax,%r12
    d526:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d52b:	0f 84 75 16 00 00    	je     eba6 <f0+0x2b66>
    d531:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d536:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d53d:	33 f3 bf 
    d540:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    d547:	00 
    d548:	bf 01 00 00 00       	mov    $0x1,%edi
    d54d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    d554:	00 
    d555:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    d55c:	00 
    d55d:	e8 ee 97 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d562:	48 8b 15 af 06 06 00 	mov    0x606af(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d569:	49 89 c5             	mov    %rax,%r13
    d56c:	48 2b 05 7d 06 06 00 	sub    0x6067d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d573:	48 c1 e2 10          	shl    $0x10,%rdx
    d577:	48 39 d0             	cmp    %rdx,%rax
    d57a:	73 59                	jae    d5d5 <f0+0x1595>
    d57c:	48 89 c2             	mov    %rax,%rdx
    d57f:	48 c1 ea 10          	shr    $0x10,%rdx
    d583:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d587:	48 8b 15 aa 06 06 00 	mov    0x606aa(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d58e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d592:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d596:	4d 85 e4             	test   %r12,%r12
    d599:	74 3a                	je     d5d5 <f0+0x1595>
    d59b:	0f b6 0a             	movzbl (%rdx),%ecx
    d59e:	80 f9 02             	cmp    $0x2,%cl
    d5a1:	0f 84 79 14 00 00    	je     ea20 <f0+0x29e0>
    d5a7:	80 f9 01             	cmp    $0x1,%cl
    d5aa:	75 29                	jne    d5d5 <f0+0x1595>
    d5ac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5af:	0f b7 c0             	movzwl %ax,%eax
    d5b2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5b5:	48 0f af c1          	imul   %rcx,%rax
    d5b9:	48 c1 e8 20          	shr    $0x20,%rax
    d5bd:	48 39 d0             	cmp    %rdx,%rax
    d5c0:	73 13                	jae    d5d5 <f0+0x1595>
    d5c2:	49 01 c4             	add    %rax,%r12
    d5c5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5ca:	0f 84 e3 15 00 00    	je     ebb3 <f0+0x2b73>
    d5d0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5d5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d5dc:	00 f0 3f 
    d5df:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    d5e6:	00 
    d5e7:	bf 01 00 00 00       	mov    $0x1,%edi
    d5ec:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    d5f3:	00 
    d5f4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    d5fb:	00 
    d5fc:	e8 4f 97 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d601:	48 8b 15 10 06 06 00 	mov    0x60610(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d608:	49 89 c5             	mov    %rax,%r13
    d60b:	48 2b 05 de 05 06 00 	sub    0x605de(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d612:	48 c1 e2 10          	shl    $0x10,%rdx
    d616:	48 39 d0             	cmp    %rdx,%rax
    d619:	73 59                	jae    d674 <f0+0x1634>
    d61b:	48 89 c2             	mov    %rax,%rdx
    d61e:	48 c1 ea 10          	shr    $0x10,%rdx
    d622:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d626:	48 8b 15 0b 06 06 00 	mov    0x6060b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d62d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d631:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d635:	4d 85 e4             	test   %r12,%r12
    d638:	74 3a                	je     d674 <f0+0x1634>
    d63a:	0f b6 0a             	movzbl (%rdx),%ecx
    d63d:	80 f9 02             	cmp    $0x2,%cl
    d640:	0f 84 ca 13 00 00    	je     ea10 <f0+0x29d0>
    d646:	80 f9 01             	cmp    $0x1,%cl
    d649:	75 29                	jne    d674 <f0+0x1634>
    d64b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d64e:	0f b7 c0             	movzwl %ax,%eax
    d651:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d654:	48 0f af c1          	imul   %rcx,%rax
    d658:	48 c1 e8 20          	shr    $0x20,%rax
    d65c:	48 39 d0             	cmp    %rdx,%rax
    d65f:	73 13                	jae    d674 <f0+0x1634>
    d661:	49 01 c4             	add    %rax,%r12
    d664:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d669:	0f 84 51 15 00 00    	je     ebc0 <f0+0x2b80>
    d66f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d674:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d67b:	33 f3 bf 
    d67e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    d685:	00 
    d686:	bf 01 00 00 00       	mov    $0x1,%edi
    d68b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    d692:	00 
    d693:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    d69a:	00 
    d69b:	e8 b0 96 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d6a0:	48 8b 15 71 05 06 00 	mov    0x60571(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d6a7:	49 89 c5             	mov    %rax,%r13
    d6aa:	48 2b 05 3f 05 06 00 	sub    0x6053f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d6b1:	48 c1 e2 10          	shl    $0x10,%rdx
    d6b5:	48 39 d0             	cmp    %rdx,%rax
    d6b8:	73 59                	jae    d713 <f0+0x16d3>
    d6ba:	48 89 c2             	mov    %rax,%rdx
    d6bd:	48 c1 ea 10          	shr    $0x10,%rdx
    d6c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6c5:	48 8b 15 6c 05 06 00 	mov    0x6056c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d6cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6d0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6d4:	4d 85 e4             	test   %r12,%r12
    d6d7:	74 3a                	je     d713 <f0+0x16d3>
    d6d9:	0f b6 0a             	movzbl (%rdx),%ecx
    d6dc:	80 f9 02             	cmp    $0x2,%cl
    d6df:	0f 84 1b 13 00 00    	je     ea00 <f0+0x29c0>
    d6e5:	80 f9 01             	cmp    $0x1,%cl
    d6e8:	75 29                	jne    d713 <f0+0x16d3>
    d6ea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6ed:	0f b7 c0             	movzwl %ax,%eax
    d6f0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6f3:	48 0f af c1          	imul   %rcx,%rax
    d6f7:	48 c1 e8 20          	shr    $0x20,%rax
    d6fb:	48 39 d0             	cmp    %rdx,%rax
    d6fe:	73 13                	jae    d713 <f0+0x16d3>
    d700:	49 01 c4             	add    %rax,%r12
    d703:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d708:	0f 84 bf 14 00 00    	je     ebcd <f0+0x2b8d>
    d70e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d713:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d71a:	00 f0 3f 
    d71d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    d724:	00 
    d725:	bf 01 00 00 00       	mov    $0x1,%edi
    d72a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    d731:	00 
    d732:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    d739:	00 
    d73a:	e8 11 96 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d73f:	48 8b 15 d2 04 06 00 	mov    0x604d2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d746:	49 89 c5             	mov    %rax,%r13
    d749:	48 2b 05 a0 04 06 00 	sub    0x604a0(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d750:	48 c1 e2 10          	shl    $0x10,%rdx
    d754:	48 39 d0             	cmp    %rdx,%rax
    d757:	73 59                	jae    d7b2 <f0+0x1772>
    d759:	48 89 c2             	mov    %rax,%rdx
    d75c:	48 c1 ea 10          	shr    $0x10,%rdx
    d760:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d764:	48 8b 15 cd 04 06 00 	mov    0x604cd(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d76b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d76f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d773:	4d 85 e4             	test   %r12,%r12
    d776:	74 3a                	je     d7b2 <f0+0x1772>
    d778:	0f b6 0a             	movzbl (%rdx),%ecx
    d77b:	80 f9 02             	cmp    $0x2,%cl
    d77e:	0f 84 6c 12 00 00    	je     e9f0 <f0+0x29b0>
    d784:	80 f9 01             	cmp    $0x1,%cl
    d787:	75 29                	jne    d7b2 <f0+0x1772>
    d789:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d78c:	0f b7 c0             	movzwl %ax,%eax
    d78f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d792:	48 0f af c1          	imul   %rcx,%rax
    d796:	48 c1 e8 20          	shr    $0x20,%rax
    d79a:	48 39 d0             	cmp    %rdx,%rax
    d79d:	73 13                	jae    d7b2 <f0+0x1772>
    d79f:	49 01 c4             	add    %rax,%r12
    d7a2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7a7:	0f 84 2d 14 00 00    	je     ebda <f0+0x2b9a>
    d7ad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7b2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7b9:	33 f3 bf 
    d7bc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    d7c3:	00 
    d7c4:	bf 01 00 00 00       	mov    $0x1,%edi
    d7c9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    d7d0:	00 
    d7d1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    d7d8:	00 
    d7d9:	e8 72 95 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d7de:	48 8b 15 33 04 06 00 	mov    0x60433(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d7e5:	49 89 c5             	mov    %rax,%r13
    d7e8:	48 2b 05 01 04 06 00 	sub    0x60401(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d7ef:	48 c1 e2 10          	shl    $0x10,%rdx
    d7f3:	48 39 d0             	cmp    %rdx,%rax
    d7f6:	73 59                	jae    d851 <f0+0x1811>
    d7f8:	48 89 c2             	mov    %rax,%rdx
    d7fb:	48 c1 ea 10          	shr    $0x10,%rdx
    d7ff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d803:	48 8b 15 2e 04 06 00 	mov    0x6042e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d80a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d80e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d812:	4d 85 e4             	test   %r12,%r12
    d815:	74 3a                	je     d851 <f0+0x1811>
    d817:	0f b6 0a             	movzbl (%rdx),%ecx
    d81a:	80 f9 02             	cmp    $0x2,%cl
    d81d:	0f 84 bd 11 00 00    	je     e9e0 <f0+0x29a0>
    d823:	80 f9 01             	cmp    $0x1,%cl
    d826:	75 29                	jne    d851 <f0+0x1811>
    d828:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d82b:	0f b7 c0             	movzwl %ax,%eax
    d82e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d831:	48 0f af c1          	imul   %rcx,%rax
    d835:	48 c1 e8 20          	shr    $0x20,%rax
    d839:	48 39 d0             	cmp    %rdx,%rax
    d83c:	73 13                	jae    d851 <f0+0x1811>
    d83e:	49 01 c4             	add    %rax,%r12
    d841:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d846:	0f 84 9b 13 00 00    	je     ebe7 <f0+0x2ba7>
    d84c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d851:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d858:	00 f0 3f 
    d85b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    d862:	00 
    d863:	bf 01 00 00 00       	mov    $0x1,%edi
    d868:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    d86f:	00 
    d870:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    d877:	00 
    d878:	e8 d3 94 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d87d:	48 8b 15 94 03 06 00 	mov    0x60394(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d884:	49 89 c5             	mov    %rax,%r13
    d887:	48 2b 05 62 03 06 00 	sub    0x60362(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d88e:	48 c1 e2 10          	shl    $0x10,%rdx
    d892:	48 39 d0             	cmp    %rdx,%rax
    d895:	73 59                	jae    d8f0 <f0+0x18b0>
    d897:	48 89 c2             	mov    %rax,%rdx
    d89a:	48 c1 ea 10          	shr    $0x10,%rdx
    d89e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8a2:	48 8b 15 8f 03 06 00 	mov    0x6038f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d8a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8ad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8b1:	4d 85 e4             	test   %r12,%r12
    d8b4:	74 3a                	je     d8f0 <f0+0x18b0>
    d8b6:	0f b6 0a             	movzbl (%rdx),%ecx
    d8b9:	80 f9 02             	cmp    $0x2,%cl
    d8bc:	0f 84 0e 11 00 00    	je     e9d0 <f0+0x2990>
    d8c2:	80 f9 01             	cmp    $0x1,%cl
    d8c5:	75 29                	jne    d8f0 <f0+0x18b0>
    d8c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8ca:	0f b7 c0             	movzwl %ax,%eax
    d8cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8d0:	48 0f af c1          	imul   %rcx,%rax
    d8d4:	48 c1 e8 20          	shr    $0x20,%rax
    d8d8:	48 39 d0             	cmp    %rdx,%rax
    d8db:	73 13                	jae    d8f0 <f0+0x18b0>
    d8dd:	49 01 c4             	add    %rax,%r12
    d8e0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8e5:	0f 84 09 13 00 00    	je     ebf4 <f0+0x2bb4>
    d8eb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d8f7:	33 f3 bf 
    d8fa:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    d901:	00 
    d902:	bf 01 00 00 00       	mov    $0x1,%edi
    d907:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    d90e:	00 
    d90f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    d916:	00 
    d917:	e8 34 94 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d91c:	48 8b 15 f5 02 06 00 	mov    0x602f5(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d923:	49 89 c5             	mov    %rax,%r13
    d926:	48 2b 05 c3 02 06 00 	sub    0x602c3(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d92d:	48 c1 e2 10          	shl    $0x10,%rdx
    d931:	48 39 d0             	cmp    %rdx,%rax
    d934:	73 59                	jae    d98f <f0+0x194f>
    d936:	48 89 c2             	mov    %rax,%rdx
    d939:	48 c1 ea 10          	shr    $0x10,%rdx
    d93d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d941:	48 8b 15 f0 02 06 00 	mov    0x602f0(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d948:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d94c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d950:	4d 85 e4             	test   %r12,%r12
    d953:	74 3a                	je     d98f <f0+0x194f>
    d955:	0f b6 0a             	movzbl (%rdx),%ecx
    d958:	80 f9 02             	cmp    $0x2,%cl
    d95b:	0f 84 5f 10 00 00    	je     e9c0 <f0+0x2980>
    d961:	80 f9 01             	cmp    $0x1,%cl
    d964:	75 29                	jne    d98f <f0+0x194f>
    d966:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d969:	0f b7 c0             	movzwl %ax,%eax
    d96c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d96f:	48 0f af c1          	imul   %rcx,%rax
    d973:	48 c1 e8 20          	shr    $0x20,%rax
    d977:	48 39 d0             	cmp    %rdx,%rax
    d97a:	73 13                	jae    d98f <f0+0x194f>
    d97c:	49 01 c4             	add    %rax,%r12
    d97f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d984:	0f 84 77 12 00 00    	je     ec01 <f0+0x2bc1>
    d98a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d98f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d996:	00 f0 3f 
    d999:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    d9a0:	00 
    d9a1:	bf 01 00 00 00       	mov    $0x1,%edi
    d9a6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    d9ad:	00 
    d9ae:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    d9b5:	00 
    d9b6:	e8 95 93 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    d9bb:	48 8b 15 56 02 06 00 	mov    0x60256(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    d9c2:	49 89 c5             	mov    %rax,%r13
    d9c5:	48 2b 05 24 02 06 00 	sub    0x60224(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    d9cc:	48 c1 e2 10          	shl    $0x10,%rdx
    d9d0:	48 39 d0             	cmp    %rdx,%rax
    d9d3:	73 59                	jae    da2e <f0+0x19ee>
    d9d5:	48 89 c2             	mov    %rax,%rdx
    d9d8:	48 c1 ea 10          	shr    $0x10,%rdx
    d9dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9e0:	48 8b 15 51 02 06 00 	mov    0x60251(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    d9e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9eb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9ef:	4d 85 e4             	test   %r12,%r12
    d9f2:	74 3a                	je     da2e <f0+0x19ee>
    d9f4:	0f b6 0a             	movzbl (%rdx),%ecx
    d9f7:	80 f9 02             	cmp    $0x2,%cl
    d9fa:	0f 84 40 0f 00 00    	je     e940 <f0+0x2900>
    da00:	80 f9 01             	cmp    $0x1,%cl
    da03:	75 29                	jne    da2e <f0+0x19ee>
    da05:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da08:	0f b7 c0             	movzwl %ax,%eax
    da0b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da0e:	48 0f af c1          	imul   %rcx,%rax
    da12:	48 c1 e8 20          	shr    $0x20,%rax
    da16:	48 39 d0             	cmp    %rdx,%rax
    da19:	73 13                	jae    da2e <f0+0x19ee>
    da1b:	49 01 c4             	add    %rax,%r12
    da1e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da23:	0f 84 e5 11 00 00    	je     ec0e <f0+0x2bce>
    da29:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da2e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da35:	33 f3 bf 
    da38:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    da3f:	00 
    da40:	bf 01 00 00 00       	mov    $0x1,%edi
    da45:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    da4c:	00 
    da4d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    da54:	00 
    da55:	e8 f6 92 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    da5a:	48 8b 15 b7 01 06 00 	mov    0x601b7(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    da61:	49 89 c5             	mov    %rax,%r13
    da64:	48 2b 05 85 01 06 00 	sub    0x60185(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    da6b:	48 c1 e2 10          	shl    $0x10,%rdx
    da6f:	48 39 d0             	cmp    %rdx,%rax
    da72:	73 59                	jae    dacd <f0+0x1a8d>
    da74:	48 89 c2             	mov    %rax,%rdx
    da77:	48 c1 ea 10          	shr    $0x10,%rdx
    da7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da7f:	48 8b 15 b2 01 06 00 	mov    0x601b2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    da86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da8a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da8e:	4d 85 e4             	test   %r12,%r12
    da91:	74 3a                	je     dacd <f0+0x1a8d>
    da93:	0f b6 0a             	movzbl (%rdx),%ecx
    da96:	80 f9 02             	cmp    $0x2,%cl
    da99:	0f 84 91 0e 00 00    	je     e930 <f0+0x28f0>
    da9f:	80 f9 01             	cmp    $0x1,%cl
    daa2:	75 29                	jne    dacd <f0+0x1a8d>
    daa4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    daa7:	0f b7 c0             	movzwl %ax,%eax
    daaa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    daad:	48 0f af c1          	imul   %rcx,%rax
    dab1:	48 c1 e8 20          	shr    $0x20,%rax
    dab5:	48 39 d0             	cmp    %rdx,%rax
    dab8:	73 13                	jae    dacd <f0+0x1a8d>
    daba:	49 01 c4             	add    %rax,%r12
    dabd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dac2:	0f 84 53 11 00 00    	je     ec1b <f0+0x2bdb>
    dac8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dacd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dad4:	00 f0 3f 
    dad7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    dade:	00 
    dadf:	bf 01 00 00 00       	mov    $0x1,%edi
    dae4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    daeb:	00 
    daec:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    daf3:	00 
    daf4:	e8 57 92 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    daf9:	48 8b 15 18 01 06 00 	mov    0x60118(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    db00:	49 89 c5             	mov    %rax,%r13
    db03:	48 2b 05 e6 00 06 00 	sub    0x600e6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    db0a:	48 c1 e2 10          	shl    $0x10,%rdx
    db0e:	48 39 d0             	cmp    %rdx,%rax
    db11:	73 59                	jae    db6c <f0+0x1b2c>
    db13:	48 89 c2             	mov    %rax,%rdx
    db16:	48 c1 ea 10          	shr    $0x10,%rdx
    db1a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db1e:	48 8b 15 13 01 06 00 	mov    0x60113(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    db25:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db29:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db2d:	4d 85 e4             	test   %r12,%r12
    db30:	74 3a                	je     db6c <f0+0x1b2c>
    db32:	0f b6 0a             	movzbl (%rdx),%ecx
    db35:	80 f9 02             	cmp    $0x2,%cl
    db38:	0f 84 e2 0d 00 00    	je     e920 <f0+0x28e0>
    db3e:	80 f9 01             	cmp    $0x1,%cl
    db41:	75 29                	jne    db6c <f0+0x1b2c>
    db43:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db46:	0f b7 c0             	movzwl %ax,%eax
    db49:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db4c:	48 0f af c1          	imul   %rcx,%rax
    db50:	48 c1 e8 20          	shr    $0x20,%rax
    db54:	48 39 d0             	cmp    %rdx,%rax
    db57:	73 13                	jae    db6c <f0+0x1b2c>
    db59:	49 01 c4             	add    %rax,%r12
    db5c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db61:	0f 84 c1 10 00 00    	je     ec28 <f0+0x2be8>
    db67:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db6c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    db73:	33 f3 bf 
    db76:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    db7d:	00 
    db7e:	bf 01 00 00 00       	mov    $0x1,%edi
    db83:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    db8a:	00 
    db8b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    db92:	00 
    db93:	e8 b8 91 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    db98:	48 8b 15 79 00 06 00 	mov    0x60079(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    db9f:	49 89 c5             	mov    %rax,%r13
    dba2:	48 2b 05 47 00 06 00 	sub    0x60047(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dba9:	48 c1 e2 10          	shl    $0x10,%rdx
    dbad:	48 39 d0             	cmp    %rdx,%rax
    dbb0:	73 59                	jae    dc0b <f0+0x1bcb>
    dbb2:	48 89 c2             	mov    %rax,%rdx
    dbb5:	48 c1 ea 10          	shr    $0x10,%rdx
    dbb9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbbd:	48 8b 15 74 00 06 00 	mov    0x60074(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dbc4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbc8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbcc:	4d 85 e4             	test   %r12,%r12
    dbcf:	74 3a                	je     dc0b <f0+0x1bcb>
    dbd1:	0f b6 0a             	movzbl (%rdx),%ecx
    dbd4:	80 f9 02             	cmp    $0x2,%cl
    dbd7:	0f 84 33 0d 00 00    	je     e910 <f0+0x28d0>
    dbdd:	80 f9 01             	cmp    $0x1,%cl
    dbe0:	75 29                	jne    dc0b <f0+0x1bcb>
    dbe2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbe5:	0f b7 c0             	movzwl %ax,%eax
    dbe8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbeb:	48 0f af c1          	imul   %rcx,%rax
    dbef:	48 c1 e8 20          	shr    $0x20,%rax
    dbf3:	48 39 d0             	cmp    %rdx,%rax
    dbf6:	73 13                	jae    dc0b <f0+0x1bcb>
    dbf8:	49 01 c4             	add    %rax,%r12
    dbfb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc00:	0f 84 2f 10 00 00    	je     ec35 <f0+0x2bf5>
    dc06:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc0b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dc12:	00 f0 3f 
    dc15:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    dc1c:	00 
    dc1d:	bf 01 00 00 00       	mov    $0x1,%edi
    dc22:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    dc29:	00 
    dc2a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    dc31:	00 
    dc32:	e8 19 91 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    dc37:	48 8b 15 da ff 05 00 	mov    0x5ffda(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dc3e:	49 89 c5             	mov    %rax,%r13
    dc41:	48 2b 05 a8 ff 05 00 	sub    0x5ffa8(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dc48:	48 c1 e2 10          	shl    $0x10,%rdx
    dc4c:	48 39 d0             	cmp    %rdx,%rax
    dc4f:	73 59                	jae    dcaa <f0+0x1c6a>
    dc51:	48 89 c2             	mov    %rax,%rdx
    dc54:	48 c1 ea 10          	shr    $0x10,%rdx
    dc58:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc5c:	48 8b 15 d5 ff 05 00 	mov    0x5ffd5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dc63:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc67:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc6b:	4d 85 e4             	test   %r12,%r12
    dc6e:	74 3a                	je     dcaa <f0+0x1c6a>
    dc70:	0f b6 0a             	movzbl (%rdx),%ecx
    dc73:	80 f9 02             	cmp    $0x2,%cl
    dc76:	0f 84 84 0c 00 00    	je     e900 <f0+0x28c0>
    dc7c:	80 f9 01             	cmp    $0x1,%cl
    dc7f:	75 29                	jne    dcaa <f0+0x1c6a>
    dc81:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc84:	0f b7 c0             	movzwl %ax,%eax
    dc87:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc8a:	48 0f af c1          	imul   %rcx,%rax
    dc8e:	48 c1 e8 20          	shr    $0x20,%rax
    dc92:	48 39 d0             	cmp    %rdx,%rax
    dc95:	73 13                	jae    dcaa <f0+0x1c6a>
    dc97:	49 01 c4             	add    %rax,%r12
    dc9a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc9f:	0f 84 9d 0f 00 00    	je     ec42 <f0+0x2c02>
    dca5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dcaa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dcb1:	33 f3 bf 
    dcb4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    dcbb:	00 
    dcbc:	bf 01 00 00 00       	mov    $0x1,%edi
    dcc1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    dcc8:	00 
    dcc9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    dcd0:	00 
    dcd1:	e8 7a 90 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    dcd6:	48 8b 15 3b ff 05 00 	mov    0x5ff3b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dcdd:	49 89 c5             	mov    %rax,%r13
    dce0:	48 2b 05 09 ff 05 00 	sub    0x5ff09(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dce7:	48 c1 e2 10          	shl    $0x10,%rdx
    dceb:	48 39 d0             	cmp    %rdx,%rax
    dcee:	73 59                	jae    dd49 <f0+0x1d09>
    dcf0:	48 89 c2             	mov    %rax,%rdx
    dcf3:	48 c1 ea 10          	shr    $0x10,%rdx
    dcf7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcfb:	48 8b 15 36 ff 05 00 	mov    0x5ff36(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dd02:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd06:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd0a:	4d 85 e4             	test   %r12,%r12
    dd0d:	74 3a                	je     dd49 <f0+0x1d09>
    dd0f:	0f b6 0a             	movzbl (%rdx),%ecx
    dd12:	80 f9 02             	cmp    $0x2,%cl
    dd15:	0f 84 d5 0b 00 00    	je     e8f0 <f0+0x28b0>
    dd1b:	80 f9 01             	cmp    $0x1,%cl
    dd1e:	75 29                	jne    dd49 <f0+0x1d09>
    dd20:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd23:	0f b7 c0             	movzwl %ax,%eax
    dd26:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd29:	48 0f af c1          	imul   %rcx,%rax
    dd2d:	48 c1 e8 20          	shr    $0x20,%rax
    dd31:	48 39 d0             	cmp    %rdx,%rax
    dd34:	73 13                	jae    dd49 <f0+0x1d09>
    dd36:	49 01 c4             	add    %rax,%r12
    dd39:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd3e:	0f 84 0b 0f 00 00    	je     ec4f <f0+0x2c0f>
    dd44:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd49:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dd50:	00 f0 3f 
    dd53:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    dd5a:	00 
    dd5b:	bf 01 00 00 00       	mov    $0x1,%edi
    dd60:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    dd67:	00 
    dd68:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    dd6f:	00 
    dd70:	e8 db 8f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    dd75:	48 8b 15 9c fe 05 00 	mov    0x5fe9c(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dd7c:	49 89 c5             	mov    %rax,%r13
    dd7f:	48 2b 05 6a fe 05 00 	sub    0x5fe6a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dd86:	48 c1 e2 10          	shl    $0x10,%rdx
    dd8a:	48 39 d0             	cmp    %rdx,%rax
    dd8d:	73 59                	jae    dde8 <f0+0x1da8>
    dd8f:	48 89 c2             	mov    %rax,%rdx
    dd92:	48 c1 ea 10          	shr    $0x10,%rdx
    dd96:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd9a:	48 8b 15 97 fe 05 00 	mov    0x5fe97(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dda1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dda5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dda9:	4d 85 e4             	test   %r12,%r12
    ddac:	74 3a                	je     dde8 <f0+0x1da8>
    ddae:	0f b6 0a             	movzbl (%rdx),%ecx
    ddb1:	80 f9 02             	cmp    $0x2,%cl
    ddb4:	0f 84 26 0b 00 00    	je     e8e0 <f0+0x28a0>
    ddba:	80 f9 01             	cmp    $0x1,%cl
    ddbd:	75 29                	jne    dde8 <f0+0x1da8>
    ddbf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddc2:	0f b7 c0             	movzwl %ax,%eax
    ddc5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ddc8:	48 0f af c1          	imul   %rcx,%rax
    ddcc:	48 c1 e8 20          	shr    $0x20,%rax
    ddd0:	48 39 d0             	cmp    %rdx,%rax
    ddd3:	73 13                	jae    dde8 <f0+0x1da8>
    ddd5:	49 01 c4             	add    %rax,%r12
    ddd8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dddd:	0f 84 79 0e 00 00    	je     ec5c <f0+0x2c1c>
    dde3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dde8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ddef:	33 f3 bf 
    ddf2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ddf9:	00 
    ddfa:	bf 01 00 00 00       	mov    $0x1,%edi
    ddff:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    de06:	00 
    de07:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    de0e:	00 
    de0f:	e8 3c 8f ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    de14:	48 8b 15 fd fd 05 00 	mov    0x5fdfd(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    de1b:	49 89 c5             	mov    %rax,%r13
    de1e:	48 2b 05 cb fd 05 00 	sub    0x5fdcb(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    de25:	48 c1 e2 10          	shl    $0x10,%rdx
    de29:	48 39 d0             	cmp    %rdx,%rax
    de2c:	73 59                	jae    de87 <f0+0x1e47>
    de2e:	48 89 c2             	mov    %rax,%rdx
    de31:	48 c1 ea 10          	shr    $0x10,%rdx
    de35:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    de39:	48 8b 15 f8 fd 05 00 	mov    0x5fdf8(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    de40:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    de44:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    de48:	4d 85 e4             	test   %r12,%r12
    de4b:	74 3a                	je     de87 <f0+0x1e47>
    de4d:	0f b6 0a             	movzbl (%rdx),%ecx
    de50:	80 f9 02             	cmp    $0x2,%cl
    de53:	0f 84 77 0a 00 00    	je     e8d0 <f0+0x2890>
    de59:	80 f9 01             	cmp    $0x1,%cl
    de5c:	75 29                	jne    de87 <f0+0x1e47>
    de5e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    de61:	0f b7 c0             	movzwl %ax,%eax
    de64:	8b 52 1c             	mov    0x1c(%rdx),%edx
    de67:	48 0f af c1          	imul   %rcx,%rax
    de6b:	48 c1 e8 20          	shr    $0x20,%rax
    de6f:	48 39 d0             	cmp    %rdx,%rax
    de72:	73 13                	jae    de87 <f0+0x1e47>
    de74:	49 01 c4             	add    %rax,%r12
    de77:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    de7c:	0f 84 e7 0d 00 00    	je     ec69 <f0+0x2c29>
    de82:	41 c6 04 24 01       	movb   $0x1,(%r12)
    de87:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    de8e:	00 f0 3f 
    de91:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    de98:	00 
    de99:	bf 01 00 00 00       	mov    $0x1,%edi
    de9e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    dea5:	00 
    dea6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    dead:	00 
    deae:	e8 9d 8e ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    deb3:	48 8b 15 5e fd 05 00 	mov    0x5fd5e(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    deba:	49 89 c5             	mov    %rax,%r13
    debd:	48 2b 05 2c fd 05 00 	sub    0x5fd2c(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    dec4:	48 c1 e2 10          	shl    $0x10,%rdx
    dec8:	48 39 d0             	cmp    %rdx,%rax
    decb:	73 59                	jae    df26 <f0+0x1ee6>
    decd:	48 89 c2             	mov    %rax,%rdx
    ded0:	48 c1 ea 10          	shr    $0x10,%rdx
    ded4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ded8:	48 8b 15 59 fd 05 00 	mov    0x5fd59(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    dedf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dee3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dee7:	4d 85 e4             	test   %r12,%r12
    deea:	74 3a                	je     df26 <f0+0x1ee6>
    deec:	0f b6 0a             	movzbl (%rdx),%ecx
    deef:	80 f9 02             	cmp    $0x2,%cl
    def2:	0f 84 38 0c 00 00    	je     eb30 <f0+0x2af0>
    def8:	80 f9 01             	cmp    $0x1,%cl
    defb:	75 29                	jne    df26 <f0+0x1ee6>
    defd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df00:	0f b7 c0             	movzwl %ax,%eax
    df03:	8b 52 1c             	mov    0x1c(%rdx),%edx
    df06:	48 0f af c1          	imul   %rcx,%rax
    df0a:	48 c1 e8 20          	shr    $0x20,%rax
    df0e:	48 39 d0             	cmp    %rdx,%rax
    df11:	73 13                	jae    df26 <f0+0x1ee6>
    df13:	49 01 c4             	add    %rax,%r12
    df16:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    df1b:	0f 84 55 0d 00 00    	je     ec76 <f0+0x2c36>
    df21:	41 c6 04 24 01       	movb   $0x1,(%r12)
    df26:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    df2d:	33 f3 bf 
    df30:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    df37:	00 
    df38:	bf 01 00 00 00       	mov    $0x1,%edi
    df3d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    df44:	00 
    df45:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    df4c:	00 
    df4d:	e8 fe 8d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    df52:	48 8b 15 bf fc 05 00 	mov    0x5fcbf(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    df59:	49 89 c5             	mov    %rax,%r13
    df5c:	48 2b 05 8d fc 05 00 	sub    0x5fc8d(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    df63:	48 c1 e2 10          	shl    $0x10,%rdx
    df67:	48 39 d0             	cmp    %rdx,%rax
    df6a:	73 59                	jae    dfc5 <f0+0x1f85>
    df6c:	48 89 c2             	mov    %rax,%rdx
    df6f:	48 c1 ea 10          	shr    $0x10,%rdx
    df73:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    df77:	48 8b 15 ba fc 05 00 	mov    0x5fcba(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    df7e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    df82:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    df86:	4d 85 e4             	test   %r12,%r12
    df89:	74 3a                	je     dfc5 <f0+0x1f85>
    df8b:	0f b6 0a             	movzbl (%rdx),%ecx
    df8e:	80 f9 02             	cmp    $0x2,%cl
    df91:	0f 84 89 0b 00 00    	je     eb20 <f0+0x2ae0>
    df97:	80 f9 01             	cmp    $0x1,%cl
    df9a:	75 29                	jne    dfc5 <f0+0x1f85>
    df9c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    df9f:	0f b7 c0             	movzwl %ax,%eax
    dfa2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dfa5:	48 0f af c1          	imul   %rcx,%rax
    dfa9:	48 c1 e8 20          	shr    $0x20,%rax
    dfad:	48 39 d0             	cmp    %rdx,%rax
    dfb0:	73 13                	jae    dfc5 <f0+0x1f85>
    dfb2:	49 01 c4             	add    %rax,%r12
    dfb5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dfba:	0f 84 c3 0c 00 00    	je     ec83 <f0+0x2c43>
    dfc0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dfc5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dfcc:	00 f0 3f 
    dfcf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    dfd6:	00 
    dfd7:	bf 01 00 00 00       	mov    $0x1,%edi
    dfdc:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    dfe3:	00 
    dfe4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    dfeb:	00 
    dfec:	e8 5f 8d ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    dff1:	48 8b 15 20 fc 05 00 	mov    0x5fc20(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    dff8:	49 89 c5             	mov    %rax,%r13
    dffb:	48 2b 05 ee fb 05 00 	sub    0x5fbee(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e002:	48 c1 e2 10          	shl    $0x10,%rdx
    e006:	48 39 d0             	cmp    %rdx,%rax
    e009:	73 59                	jae    e064 <f0+0x2024>
    e00b:	48 89 c2             	mov    %rax,%rdx
    e00e:	48 c1 ea 10          	shr    $0x10,%rdx
    e012:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e016:	48 8b 15 1b fc 05 00 	mov    0x5fc1b(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e01d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e021:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e025:	4d 85 e4             	test   %r12,%r12
    e028:	74 3a                	je     e064 <f0+0x2024>
    e02a:	0f b6 0a             	movzbl (%rdx),%ecx
    e02d:	80 f9 02             	cmp    $0x2,%cl
    e030:	0f 84 da 0a 00 00    	je     eb10 <f0+0x2ad0>
    e036:	80 f9 01             	cmp    $0x1,%cl
    e039:	75 29                	jne    e064 <f0+0x2024>
    e03b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e03e:	0f b7 c0             	movzwl %ax,%eax
    e041:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e044:	48 0f af c1          	imul   %rcx,%rax
    e048:	48 c1 e8 20          	shr    $0x20,%rax
    e04c:	48 39 d0             	cmp    %rdx,%rax
    e04f:	73 13                	jae    e064 <f0+0x2024>
    e051:	49 01 c4             	add    %rax,%r12
    e054:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e059:	0f 84 31 0c 00 00    	je     ec90 <f0+0x2c50>
    e05f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e064:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e06b:	33 f3 bf 
    e06e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    e075:	00 
    e076:	bf 01 00 00 00       	mov    $0x1,%edi
    e07b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    e082:	00 
    e083:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    e08a:	00 
    e08b:	e8 c0 8c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e090:	48 8b 15 81 fb 05 00 	mov    0x5fb81(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e097:	49 89 c5             	mov    %rax,%r13
    e09a:	48 2b 05 4f fb 05 00 	sub    0x5fb4f(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e0a1:	48 c1 e2 10          	shl    $0x10,%rdx
    e0a5:	48 39 d0             	cmp    %rdx,%rax
    e0a8:	73 59                	jae    e103 <f0+0x20c3>
    e0aa:	48 89 c2             	mov    %rax,%rdx
    e0ad:	48 c1 ea 10          	shr    $0x10,%rdx
    e0b1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e0b5:	48 8b 15 7c fb 05 00 	mov    0x5fb7c(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e0bc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e0c0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e0c4:	4d 85 e4             	test   %r12,%r12
    e0c7:	74 3a                	je     e103 <f0+0x20c3>
    e0c9:	0f b6 0a             	movzbl (%rdx),%ecx
    e0cc:	80 f9 02             	cmp    $0x2,%cl
    e0cf:	0f 84 2b 0a 00 00    	je     eb00 <f0+0x2ac0>
    e0d5:	80 f9 01             	cmp    $0x1,%cl
    e0d8:	75 29                	jne    e103 <f0+0x20c3>
    e0da:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e0dd:	0f b7 c0             	movzwl %ax,%eax
    e0e0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e0e3:	48 0f af c1          	imul   %rcx,%rax
    e0e7:	48 c1 e8 20          	shr    $0x20,%rax
    e0eb:	48 39 d0             	cmp    %rdx,%rax
    e0ee:	73 13                	jae    e103 <f0+0x20c3>
    e0f0:	49 01 c4             	add    %rax,%r12
    e0f3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e0f8:	0f 84 9f 0b 00 00    	je     ec9d <f0+0x2c5d>
    e0fe:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e103:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e10a:	00 f0 3f 
    e10d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    e114:	00 
    e115:	bf 01 00 00 00       	mov    $0x1,%edi
    e11a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    e121:	00 
    e122:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    e129:	00 
    e12a:	e8 21 8c ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e12f:	48 8b 15 e2 fa 05 00 	mov    0x5fae2(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e136:	49 89 c5             	mov    %rax,%r13
    e139:	48 2b 05 b0 fa 05 00 	sub    0x5fab0(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e140:	48 c1 e2 10          	shl    $0x10,%rdx
    e144:	48 39 d0             	cmp    %rdx,%rax
    e147:	73 59                	jae    e1a2 <f0+0x2162>
    e149:	48 89 c2             	mov    %rax,%rdx
    e14c:	48 c1 ea 10          	shr    $0x10,%rdx
    e150:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e154:	48 8b 15 dd fa 05 00 	mov    0x5fadd(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e15b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e15f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e163:	4d 85 e4             	test   %r12,%r12
    e166:	74 3a                	je     e1a2 <f0+0x2162>
    e168:	0f b6 0a             	movzbl (%rdx),%ecx
    e16b:	80 f9 02             	cmp    $0x2,%cl
    e16e:	0f 84 7c 09 00 00    	je     eaf0 <f0+0x2ab0>
    e174:	80 f9 01             	cmp    $0x1,%cl
    e177:	75 29                	jne    e1a2 <f0+0x2162>
    e179:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e17c:	0f b7 c0             	movzwl %ax,%eax
    e17f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e182:	48 0f af c1          	imul   %rcx,%rax
    e186:	48 c1 e8 20          	shr    $0x20,%rax
    e18a:	48 39 d0             	cmp    %rdx,%rax
    e18d:	73 13                	jae    e1a2 <f0+0x2162>
    e18f:	49 01 c4             	add    %rax,%r12
    e192:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e197:	0f 84 0d 0b 00 00    	je     ecaa <f0+0x2c6a>
    e19d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e1a2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e1a9:	33 f3 bf 
    e1ac:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    e1b3:	00 
    e1b4:	bf 01 00 00 00       	mov    $0x1,%edi
    e1b9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    e1c0:	00 
    e1c1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    e1c8:	00 
    e1c9:	e8 82 8b ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e1ce:	48 8b 15 43 fa 05 00 	mov    0x5fa43(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e1d5:	49 89 c5             	mov    %rax,%r13
    e1d8:	48 2b 05 11 fa 05 00 	sub    0x5fa11(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e1df:	48 c1 e2 10          	shl    $0x10,%rdx
    e1e3:	48 39 d0             	cmp    %rdx,%rax
    e1e6:	73 59                	jae    e241 <f0+0x2201>
    e1e8:	48 89 c2             	mov    %rax,%rdx
    e1eb:	48 c1 ea 10          	shr    $0x10,%rdx
    e1ef:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e1f3:	48 8b 15 3e fa 05 00 	mov    0x5fa3e(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e1fa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e1fe:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e202:	4d 85 e4             	test   %r12,%r12
    e205:	74 3a                	je     e241 <f0+0x2201>
    e207:	0f b6 0a             	movzbl (%rdx),%ecx
    e20a:	80 f9 02             	cmp    $0x2,%cl
    e20d:	0f 84 cd 08 00 00    	je     eae0 <f0+0x2aa0>
    e213:	80 f9 01             	cmp    $0x1,%cl
    e216:	75 29                	jne    e241 <f0+0x2201>
    e218:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e21b:	0f b7 c0             	movzwl %ax,%eax
    e21e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e221:	48 0f af c1          	imul   %rcx,%rax
    e225:	48 c1 e8 20          	shr    $0x20,%rax
    e229:	48 39 d0             	cmp    %rdx,%rax
    e22c:	73 13                	jae    e241 <f0+0x2201>
    e22e:	49 01 c4             	add    %rax,%r12
    e231:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e236:	0f 84 7b 0a 00 00    	je     ecb7 <f0+0x2c77>
    e23c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e241:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e248:	00 f0 3f 
    e24b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    e252:	00 
    e253:	bf 01 00 00 00       	mov    $0x1,%edi
    e258:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    e25f:	00 
    e260:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    e267:	00 
    e268:	e8 e3 8a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e26d:	48 8b 15 a4 f9 05 00 	mov    0x5f9a4(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e274:	49 89 c5             	mov    %rax,%r13
    e277:	48 2b 05 72 f9 05 00 	sub    0x5f972(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e27e:	48 c1 e2 10          	shl    $0x10,%rdx
    e282:	48 39 d0             	cmp    %rdx,%rax
    e285:	73 59                	jae    e2e0 <f0+0x22a0>
    e287:	48 89 c2             	mov    %rax,%rdx
    e28a:	48 c1 ea 10          	shr    $0x10,%rdx
    e28e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e292:	48 8b 15 9f f9 05 00 	mov    0x5f99f(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e299:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e29d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e2a1:	4d 85 e4             	test   %r12,%r12
    e2a4:	74 3a                	je     e2e0 <f0+0x22a0>
    e2a6:	0f b6 0a             	movzbl (%rdx),%ecx
    e2a9:	80 f9 02             	cmp    $0x2,%cl
    e2ac:	0f 84 1e 08 00 00    	je     ead0 <f0+0x2a90>
    e2b2:	80 f9 01             	cmp    $0x1,%cl
    e2b5:	75 29                	jne    e2e0 <f0+0x22a0>
    e2b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e2ba:	0f b7 c0             	movzwl %ax,%eax
    e2bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e2c0:	48 0f af c1          	imul   %rcx,%rax
    e2c4:	48 c1 e8 20          	shr    $0x20,%rax
    e2c8:	48 39 d0             	cmp    %rdx,%rax
    e2cb:	73 13                	jae    e2e0 <f0+0x22a0>
    e2cd:	49 01 c4             	add    %rax,%r12
    e2d0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e2d5:	0f 84 e9 09 00 00    	je     ecc4 <f0+0x2c84>
    e2db:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e2e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e2e7:	33 f3 bf 
    e2ea:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    e2f1:	00 
    e2f2:	bf 01 00 00 00       	mov    $0x1,%edi
    e2f7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    e2fe:	00 
    e2ff:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    e306:	00 
    e307:	e8 44 8a ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e30c:	48 8b 15 05 f9 05 00 	mov    0x5f905(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e313:	49 89 c5             	mov    %rax,%r13
    e316:	48 2b 05 d3 f8 05 00 	sub    0x5f8d3(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e31d:	48 c1 e2 10          	shl    $0x10,%rdx
    e321:	48 39 d0             	cmp    %rdx,%rax
    e324:	73 59                	jae    e37f <f0+0x233f>
    e326:	48 89 c2             	mov    %rax,%rdx
    e329:	48 c1 ea 10          	shr    $0x10,%rdx
    e32d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e331:	48 8b 15 00 f9 05 00 	mov    0x5f900(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e338:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e33c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e340:	4d 85 e4             	test   %r12,%r12
    e343:	74 3a                	je     e37f <f0+0x233f>
    e345:	0f b6 0a             	movzbl (%rdx),%ecx
    e348:	80 f9 02             	cmp    $0x2,%cl
    e34b:	0f 84 6f 07 00 00    	je     eac0 <f0+0x2a80>
    e351:	80 f9 01             	cmp    $0x1,%cl
    e354:	75 29                	jne    e37f <f0+0x233f>
    e356:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e359:	0f b7 c0             	movzwl %ax,%eax
    e35c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e35f:	48 0f af c1          	imul   %rcx,%rax
    e363:	48 c1 e8 20          	shr    $0x20,%rax
    e367:	48 39 d0             	cmp    %rdx,%rax
    e36a:	73 13                	jae    e37f <f0+0x233f>
    e36c:	49 01 c4             	add    %rax,%r12
    e36f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e374:	0f 84 57 09 00 00    	je     ecd1 <f0+0x2c91>
    e37a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e37f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e386:	00 f0 3f 
    e389:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    e390:	00 
    e391:	bf 01 00 00 00       	mov    $0x1,%edi
    e396:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    e39d:	00 
    e39e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    e3a5:	00 
    e3a6:	e8 a5 89 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e3ab:	48 8b 15 66 f8 05 00 	mov    0x5f866(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e3b2:	49 89 c5             	mov    %rax,%r13
    e3b5:	48 2b 05 34 f8 05 00 	sub    0x5f834(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e3bc:	48 c1 e2 10          	shl    $0x10,%rdx
    e3c0:	48 39 d0             	cmp    %rdx,%rax
    e3c3:	73 59                	jae    e41e <f0+0x23de>
    e3c5:	48 89 c2             	mov    %rax,%rdx
    e3c8:	48 c1 ea 10          	shr    $0x10,%rdx
    e3cc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e3d0:	48 8b 15 61 f8 05 00 	mov    0x5f861(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e3d7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e3db:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e3df:	4d 85 e4             	test   %r12,%r12
    e3e2:	74 3a                	je     e41e <f0+0x23de>
    e3e4:	0f b6 0a             	movzbl (%rdx),%ecx
    e3e7:	80 f9 02             	cmp    $0x2,%cl
    e3ea:	0f 84 c0 06 00 00    	je     eab0 <f0+0x2a70>
    e3f0:	80 f9 01             	cmp    $0x1,%cl
    e3f3:	75 29                	jne    e41e <f0+0x23de>
    e3f5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e3f8:	0f b7 c0             	movzwl %ax,%eax
    e3fb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e3fe:	48 0f af c1          	imul   %rcx,%rax
    e402:	48 c1 e8 20          	shr    $0x20,%rax
    e406:	48 39 d0             	cmp    %rdx,%rax
    e409:	73 13                	jae    e41e <f0+0x23de>
    e40b:	49 01 c4             	add    %rax,%r12
    e40e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e413:	0f 84 c5 08 00 00    	je     ecde <f0+0x2c9e>
    e419:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e41e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e425:	33 f3 bf 
    e428:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    e42f:	00 
    e430:	bf 01 00 00 00       	mov    $0x1,%edi
    e435:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    e43c:	00 
    e43d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    e444:	00 
    e445:	e8 06 89 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e44a:	48 8b 15 c7 f7 05 00 	mov    0x5f7c7(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e451:	49 89 c5             	mov    %rax,%r13
    e454:	48 2b 05 95 f7 05 00 	sub    0x5f795(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e45b:	48 c1 e2 10          	shl    $0x10,%rdx
    e45f:	48 39 d0             	cmp    %rdx,%rax
    e462:	73 59                	jae    e4bd <f0+0x247d>
    e464:	48 89 c2             	mov    %rax,%rdx
    e467:	48 c1 ea 10          	shr    $0x10,%rdx
    e46b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e46f:	48 8b 15 c2 f7 05 00 	mov    0x5f7c2(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e476:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e47a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e47e:	4d 85 e4             	test   %r12,%r12
    e481:	74 3a                	je     e4bd <f0+0x247d>
    e483:	0f b6 0a             	movzbl (%rdx),%ecx
    e486:	80 f9 02             	cmp    $0x2,%cl
    e489:	0f 84 11 06 00 00    	je     eaa0 <f0+0x2a60>
    e48f:	80 f9 01             	cmp    $0x1,%cl
    e492:	75 29                	jne    e4bd <f0+0x247d>
    e494:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e497:	0f b7 c0             	movzwl %ax,%eax
    e49a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e49d:	48 0f af c1          	imul   %rcx,%rax
    e4a1:	48 c1 e8 20          	shr    $0x20,%rax
    e4a5:	48 39 d0             	cmp    %rdx,%rax
    e4a8:	73 13                	jae    e4bd <f0+0x247d>
    e4aa:	49 01 c4             	add    %rax,%r12
    e4ad:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e4b2:	0f 84 33 08 00 00    	je     eceb <f0+0x2cab>
    e4b8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e4bd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e4c4:	00 f0 3f 
    e4c7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    e4ce:	00 
    e4cf:	bf 01 00 00 00       	mov    $0x1,%edi
    e4d4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    e4db:	00 
    e4dc:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    e4e3:	00 
    e4e4:	e8 67 88 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e4e9:	48 8b 15 28 f7 05 00 	mov    0x5f728(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e4f0:	49 89 c5             	mov    %rax,%r13
    e4f3:	48 2b 05 f6 f6 05 00 	sub    0x5f6f6(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e4fa:	48 c1 e2 10          	shl    $0x10,%rdx
    e4fe:	48 39 d0             	cmp    %rdx,%rax
    e501:	73 59                	jae    e55c <f0+0x251c>
    e503:	48 89 c2             	mov    %rax,%rdx
    e506:	48 c1 ea 10          	shr    $0x10,%rdx
    e50a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e50e:	48 8b 15 23 f7 05 00 	mov    0x5f723(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e515:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e519:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e51d:	4d 85 e4             	test   %r12,%r12
    e520:	74 3a                	je     e55c <f0+0x251c>
    e522:	0f b6 0a             	movzbl (%rdx),%ecx
    e525:	80 f9 02             	cmp    $0x2,%cl
    e528:	0f 84 62 05 00 00    	je     ea90 <f0+0x2a50>
    e52e:	80 f9 01             	cmp    $0x1,%cl
    e531:	75 29                	jne    e55c <f0+0x251c>
    e533:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e536:	0f b7 c0             	movzwl %ax,%eax
    e539:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e53c:	48 0f af c1          	imul   %rcx,%rax
    e540:	48 c1 e8 20          	shr    $0x20,%rax
    e544:	48 39 d0             	cmp    %rdx,%rax
    e547:	73 13                	jae    e55c <f0+0x251c>
    e549:	49 01 c4             	add    %rax,%r12
    e54c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e551:	0f 84 a1 07 00 00    	je     ecf8 <f0+0x2cb8>
    e557:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e55c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e563:	33 f3 bf 
    e566:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    e56d:	00 
    e56e:	bf 01 00 00 00       	mov    $0x1,%edi
    e573:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    e57a:	00 
    e57b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    e582:	00 
    e583:	e8 c8 87 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e588:	48 8b 15 89 f6 05 00 	mov    0x5f689(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e58f:	49 89 c5             	mov    %rax,%r13
    e592:	48 2b 05 57 f6 05 00 	sub    0x5f657(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e599:	48 c1 e2 10          	shl    $0x10,%rdx
    e59d:	48 39 d0             	cmp    %rdx,%rax
    e5a0:	73 59                	jae    e5fb <f0+0x25bb>
    e5a2:	48 89 c2             	mov    %rax,%rdx
    e5a5:	48 c1 ea 10          	shr    $0x10,%rdx
    e5a9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e5ad:	48 8b 15 84 f6 05 00 	mov    0x5f684(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e5b4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e5b8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e5bc:	4d 85 e4             	test   %r12,%r12
    e5bf:	74 3a                	je     e5fb <f0+0x25bb>
    e5c1:	0f b6 0a             	movzbl (%rdx),%ecx
    e5c4:	80 f9 02             	cmp    $0x2,%cl
    e5c7:	0f 84 b3 04 00 00    	je     ea80 <f0+0x2a40>
    e5cd:	80 f9 01             	cmp    $0x1,%cl
    e5d0:	75 29                	jne    e5fb <f0+0x25bb>
    e5d2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e5d5:	0f b7 c0             	movzwl %ax,%eax
    e5d8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e5db:	48 0f af c1          	imul   %rcx,%rax
    e5df:	48 c1 e8 20          	shr    $0x20,%rax
    e5e3:	48 39 d0             	cmp    %rdx,%rax
    e5e6:	73 13                	jae    e5fb <f0+0x25bb>
    e5e8:	49 01 c4             	add    %rax,%r12
    e5eb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e5f0:	0f 84 0f 07 00 00    	je     ed05 <f0+0x2cc5>
    e5f6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e5fb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e602:	00 f0 3f 
    e605:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    e60c:	00 
    e60d:	bf 01 00 00 00       	mov    $0x1,%edi
    e612:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    e619:	00 
    e61a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    e621:	00 
    e622:	e8 29 87 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e627:	48 8b 15 ea f5 05 00 	mov    0x5f5ea(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e62e:	49 89 c5             	mov    %rax,%r13
    e631:	48 2b 05 b8 f5 05 00 	sub    0x5f5b8(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e638:	48 c1 e2 10          	shl    $0x10,%rdx
    e63c:	48 39 d0             	cmp    %rdx,%rax
    e63f:	73 59                	jae    e69a <f0+0x265a>
    e641:	48 89 c2             	mov    %rax,%rdx
    e644:	48 c1 ea 10          	shr    $0x10,%rdx
    e648:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e64c:	48 8b 15 e5 f5 05 00 	mov    0x5f5e5(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e653:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e657:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e65b:	4d 85 e4             	test   %r12,%r12
    e65e:	74 3a                	je     e69a <f0+0x265a>
    e660:	0f b6 0a             	movzbl (%rdx),%ecx
    e663:	80 f9 02             	cmp    $0x2,%cl
    e666:	0f 84 04 04 00 00    	je     ea70 <f0+0x2a30>
    e66c:	80 f9 01             	cmp    $0x1,%cl
    e66f:	75 29                	jne    e69a <f0+0x265a>
    e671:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e674:	0f b7 c0             	movzwl %ax,%eax
    e677:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e67a:	48 0f af c1          	imul   %rcx,%rax
    e67e:	48 c1 e8 20          	shr    $0x20,%rax
    e682:	48 39 d0             	cmp    %rdx,%rax
    e685:	73 13                	jae    e69a <f0+0x265a>
    e687:	49 01 c4             	add    %rax,%r12
    e68a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e68f:	0f 84 7d 06 00 00    	je     ed12 <f0+0x2cd2>
    e695:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e69a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e6a1:	33 f3 bf 
    e6a4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    e6ab:	00 
    e6ac:	bf 01 00 00 00       	mov    $0x1,%edi
    e6b1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    e6b8:	00 
    e6b9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    e6c0:	00 
    e6c1:	e8 8a 86 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e6c6:	48 8b 15 4b f5 05 00 	mov    0x5f54b(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e6cd:	49 89 c5             	mov    %rax,%r13
    e6d0:	48 2b 05 19 f5 05 00 	sub    0x5f519(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e6d7:	48 c1 e2 10          	shl    $0x10,%rdx
    e6db:	48 39 d0             	cmp    %rdx,%rax
    e6de:	73 59                	jae    e739 <f0+0x26f9>
    e6e0:	48 89 c2             	mov    %rax,%rdx
    e6e3:	48 c1 ea 10          	shr    $0x10,%rdx
    e6e7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e6eb:	48 8b 15 46 f5 05 00 	mov    0x5f546(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e6f2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e6f6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e6fa:	4d 85 e4             	test   %r12,%r12
    e6fd:	74 3a                	je     e739 <f0+0x26f9>
    e6ff:	0f b6 0a             	movzbl (%rdx),%ecx
    e702:	80 f9 02             	cmp    $0x2,%cl
    e705:	0f 84 55 03 00 00    	je     ea60 <f0+0x2a20>
    e70b:	80 f9 01             	cmp    $0x1,%cl
    e70e:	75 29                	jne    e739 <f0+0x26f9>
    e710:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e713:	0f b7 c0             	movzwl %ax,%eax
    e716:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e719:	48 0f af c1          	imul   %rcx,%rax
    e71d:	48 c1 e8 20          	shr    $0x20,%rax
    e721:	48 39 d0             	cmp    %rdx,%rax
    e724:	73 13                	jae    e739 <f0+0x26f9>
    e726:	49 01 c4             	add    %rax,%r12
    e729:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e72e:	0f 84 eb 05 00 00    	je     ed1f <f0+0x2cdf>
    e734:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e739:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    e740:	00 f0 3f 
    e743:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    e74a:	00 
    e74b:	bf 01 00 00 00       	mov    $0x1,%edi
    e750:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    e757:	00 
    e758:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    e75f:	00 
    e760:	e8 eb 85 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e765:	48 8b 15 ac f4 05 00 	mov    0x5f4ac(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e76c:	49 89 c5             	mov    %rax,%r13
    e76f:	48 2b 05 7a f4 05 00 	sub    0x5f47a(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e776:	48 c1 e2 10          	shl    $0x10,%rdx
    e77a:	48 39 d0             	cmp    %rdx,%rax
    e77d:	73 59                	jae    e7d8 <f0+0x2798>
    e77f:	48 89 c2             	mov    %rax,%rdx
    e782:	48 c1 ea 10          	shr    $0x10,%rdx
    e786:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e78a:	48 8b 15 a7 f4 05 00 	mov    0x5f4a7(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e791:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e795:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e799:	4d 85 e4             	test   %r12,%r12
    e79c:	74 3a                	je     e7d8 <f0+0x2798>
    e79e:	0f b6 0a             	movzbl (%rdx),%ecx
    e7a1:	80 f9 02             	cmp    $0x2,%cl
    e7a4:	0f 84 a6 02 00 00    	je     ea50 <f0+0x2a10>
    e7aa:	80 f9 01             	cmp    $0x1,%cl
    e7ad:	75 29                	jne    e7d8 <f0+0x2798>
    e7af:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e7b2:	0f b7 c0             	movzwl %ax,%eax
    e7b5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e7b8:	48 0f af c1          	imul   %rcx,%rax
    e7bc:	48 c1 e8 20          	shr    $0x20,%rax
    e7c0:	48 39 d0             	cmp    %rdx,%rax
    e7c3:	73 13                	jae    e7d8 <f0+0x2798>
    e7c5:	49 01 c4             	add    %rax,%r12
    e7c8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e7cd:	0f 84 59 05 00 00    	je     ed2c <f0+0x2cec>
    e7d3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e7d8:	48 89 ee             	mov    %rbp,%rsi
    e7db:	bf 01 00 00 00       	mov    $0x1,%edi
    e7e0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    e7e7:	33 f3 bf 
    e7ea:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    e7f1:	00 
    e7f2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    e7f9:	00 
    e7fa:	e8 51 85 ff ff       	call   6d50 <fwp_data.part.0.constprop.0>
    e7ff:	48 8b 15 12 f4 05 00 	mov    0x5f412(%rip),%rdx        # 6dc18 <fwp_heap+0x13d8>
    e806:	48 89 c5             	mov    %rax,%rbp
    e809:	48 2b 05 e0 f3 05 00 	sub    0x5f3e0(%rip),%rax        # 6dbf0 <fwp_heap+0x13b0>
    e810:	48 c1 e2 10          	shl    $0x10,%rdx
    e814:	48 39 d0             	cmp    %rdx,%rax
    e817:	73 59                	jae    e872 <f0+0x2832>
    e819:	48 89 c2             	mov    %rax,%rdx
    e81c:	48 c1 ea 10          	shr    $0x10,%rdx
    e820:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    e824:	48 8b 15 0d f4 05 00 	mov    0x5f40d(%rip),%rdx        # 6dc38 <fwp_heap+0x13f8>
    e82b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    e82f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    e833:	4d 85 e4             	test   %r12,%r12
    e836:	74 3a                	je     e872 <f0+0x2832>
    e838:	0f b6 0a             	movzbl (%rdx),%ecx
    e83b:	80 f9 02             	cmp    $0x2,%cl
    e83e:	0f 84 fc 01 00 00    	je     ea40 <f0+0x2a00>
    e844:	80 f9 01             	cmp    $0x1,%cl
    e847:	75 29                	jne    e872 <f0+0x2832>
    e849:	8b 4a 18             	mov    0x18(%rdx),%ecx
    e84c:	0f b7 c0             	movzwl %ax,%eax
    e84f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    e852:	48 0f af c1          	imul   %rcx,%rax
    e856:	48 c1 e8 20          	shr    $0x20,%rax
    e85a:	48 39 d0             	cmp    %rdx,%rax
    e85d:	73 13                	jae    e872 <f0+0x2832>
    e85f:	49 01 c4             	add    %rax,%r12
    e862:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    e867:	0f 84 d1 02 00 00    	je     eb3e <f0+0x2afe>
    e86d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    e872:	48 89 de             	mov    %rbx,%rsi
    e875:	48 89 ef             	mov    %rbp,%rdi
    e878:	e8 03 ca ff ff       	call   b280 <fwp_hof0.constprop.0>
    e87d:	48 89 ef             	mov    %rbp,%rdi
    e880:	e8 1b 8b ff ff       	call   73a0 <fwp_drop0>
    e885:	48 89 df             	mov    %rbx,%rdi
    e888:	e8 13 8b ff ff       	call   73a0 <fwp_drop0>
    e88d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    e894:	00 
    e895:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e89c:	00 00 
    e89e:	0f 85 95 04 00 00    	jne    ed39 <f0+0x2cf9>
    e8a4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    e8ab:	31 c0                	xor    %eax,%eax
    e8ad:	5b                   	pop    %rbx
    e8ae:	5d                   	pop    %rbp
    e8af:	41 5c                	pop    %r12
    e8b1:	41 5d                	pop    %r13
    e8b3:	41 5e                	pop    %r14
    e8b5:	c3                   	ret
    e8b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e8bd:	00 00 00 
    e8c0:	4c 89 ef             	mov    %r13,%rdi
    e8c3:	e8 08 6f ff ff       	call   57d0 <fwp_rc_forget_slot>
    e8c8:	e9 2c d8 ff ff       	jmp    c0f9 <f0+0xb9>
    e8cd:	0f 1f 00             	nopl   (%rax)
    e8d0:	66 85 c0             	test   %ax,%ax
    e8d3:	0f 85 ae f5 ff ff    	jne    de87 <f0+0x1e47>
    e8d9:	e9 99 f5 ff ff       	jmp    de77 <f0+0x1e37>
    e8de:	66 90                	xchg   %ax,%ax
    e8e0:	66 85 c0             	test   %ax,%ax
    e8e3:	0f 85 ff f4 ff ff    	jne    dde8 <f0+0x1da8>
    e8e9:	e9 ea f4 ff ff       	jmp    ddd8 <f0+0x1d98>
    e8ee:	66 90                	xchg   %ax,%ax
    e8f0:	66 85 c0             	test   %ax,%ax
    e8f3:	0f 85 50 f4 ff ff    	jne    dd49 <f0+0x1d09>
    e8f9:	e9 3b f4 ff ff       	jmp    dd39 <f0+0x1cf9>
    e8fe:	66 90                	xchg   %ax,%ax
    e900:	66 85 c0             	test   %ax,%ax
    e903:	0f 85 a1 f3 ff ff    	jne    dcaa <f0+0x1c6a>
    e909:	e9 8c f3 ff ff       	jmp    dc9a <f0+0x1c5a>
    e90e:	66 90                	xchg   %ax,%ax
    e910:	66 85 c0             	test   %ax,%ax
    e913:	0f 85 f2 f2 ff ff    	jne    dc0b <f0+0x1bcb>
    e919:	e9 dd f2 ff ff       	jmp    dbfb <f0+0x1bbb>
    e91e:	66 90                	xchg   %ax,%ax
    e920:	66 85 c0             	test   %ax,%ax
    e923:	0f 85 43 f2 ff ff    	jne    db6c <f0+0x1b2c>
    e929:	e9 2e f2 ff ff       	jmp    db5c <f0+0x1b1c>
    e92e:	66 90                	xchg   %ax,%ax
    e930:	66 85 c0             	test   %ax,%ax
    e933:	0f 85 94 f1 ff ff    	jne    dacd <f0+0x1a8d>
    e939:	e9 7f f1 ff ff       	jmp    dabd <f0+0x1a7d>
    e93e:	66 90                	xchg   %ax,%ax
    e940:	66 85 c0             	test   %ax,%ax
    e943:	0f 85 e5 f0 ff ff    	jne    da2e <f0+0x19ee>
    e949:	e9 d0 f0 ff ff       	jmp    da1e <f0+0x19de>
    e94e:	66 90                	xchg   %ax,%ax
    e950:	66 85 c0             	test   %ax,%ax
    e953:	0f 85 fd d9 ff ff    	jne    c356 <f0+0x316>
    e959:	e9 e8 d9 ff ff       	jmp    c346 <f0+0x306>
    e95e:	66 90                	xchg   %ax,%ax
    e960:	66 85 c0             	test   %ax,%ax
    e963:	0f 85 57 d9 ff ff    	jne    c2c0 <f0+0x280>
    e969:	e9 42 d9 ff ff       	jmp    c2b0 <f0+0x270>
    e96e:	66 90                	xchg   %ax,%ax
    e970:	66 85 c0             	test   %ax,%ax
    e973:	0f 85 b1 d8 ff ff    	jne    c22a <f0+0x1ea>
    e979:	e9 9c d8 ff ff       	jmp    c21a <f0+0x1da>
    e97e:	66 90                	xchg   %ax,%ax
    e980:	66 85 c0             	test   %ax,%ax
    e983:	0f 85 0e eb ff ff    	jne    d497 <f0+0x1457>
    e989:	e9 f9 ea ff ff       	jmp    d487 <f0+0x1447>
    e98e:	66 90                	xchg   %ax,%ax
    e990:	66 85 c0             	test   %ax,%ax
    e993:	0f 85 91 db ff ff    	jne    c52a <f0+0x4ea>
    e999:	e9 7c db ff ff       	jmp    c51a <f0+0x4da>
    e99e:	66 90                	xchg   %ax,%ax
    e9a0:	66 85 c0             	test   %ax,%ax
    e9a3:	0f 85 e2 da ff ff    	jne    c48b <f0+0x44b>
    e9a9:	e9 cd da ff ff       	jmp    c47b <f0+0x43b>
    e9ae:	66 90                	xchg   %ax,%ax
    e9b0:	66 85 c0             	test   %ax,%ax
    e9b3:	0f 85 33 da ff ff    	jne    c3ec <f0+0x3ac>
    e9b9:	e9 1e da ff ff       	jmp    c3dc <f0+0x39c>
    e9be:	66 90                	xchg   %ax,%ax
    e9c0:	66 85 c0             	test   %ax,%ax
    e9c3:	0f 85 c6 ef ff ff    	jne    d98f <f0+0x194f>
    e9c9:	e9 b1 ef ff ff       	jmp    d97f <f0+0x193f>
    e9ce:	66 90                	xchg   %ax,%ax
    e9d0:	66 85 c0             	test   %ax,%ax
    e9d3:	0f 85 17 ef ff ff    	jne    d8f0 <f0+0x18b0>
    e9d9:	e9 02 ef ff ff       	jmp    d8e0 <f0+0x18a0>
    e9de:	66 90                	xchg   %ax,%ax
    e9e0:	66 85 c0             	test   %ax,%ax
    e9e3:	0f 85 68 ee ff ff    	jne    d851 <f0+0x1811>
    e9e9:	e9 53 ee ff ff       	jmp    d841 <f0+0x1801>
    e9ee:	66 90                	xchg   %ax,%ax
    e9f0:	66 85 c0             	test   %ax,%ax
    e9f3:	0f 85 b9 ed ff ff    	jne    d7b2 <f0+0x1772>
    e9f9:	e9 a4 ed ff ff       	jmp    d7a2 <f0+0x1762>
    e9fe:	66 90                	xchg   %ax,%ax
    ea00:	66 85 c0             	test   %ax,%ax
    ea03:	0f 85 0a ed ff ff    	jne    d713 <f0+0x16d3>
    ea09:	e9 f5 ec ff ff       	jmp    d703 <f0+0x16c3>
    ea0e:	66 90                	xchg   %ax,%ax
    ea10:	66 85 c0             	test   %ax,%ax
    ea13:	0f 85 5b ec ff ff    	jne    d674 <f0+0x1634>
    ea19:	e9 46 ec ff ff       	jmp    d664 <f0+0x1624>
    ea1e:	66 90                	xchg   %ax,%ax
    ea20:	66 85 c0             	test   %ax,%ax
    ea23:	0f 85 ac eb ff ff    	jne    d5d5 <f0+0x1595>
    ea29:	e9 97 eb ff ff       	jmp    d5c5 <f0+0x1585>
    ea2e:	66 90                	xchg   %ax,%ax
    ea30:	66 85 c0             	test   %ax,%ax
    ea33:	0f 85 fd ea ff ff    	jne    d536 <f0+0x14f6>
    ea39:	e9 e8 ea ff ff       	jmp    d526 <f0+0x14e6>
    ea3e:	66 90                	xchg   %ax,%ax
    ea40:	66 85 c0             	test   %ax,%ax
    ea43:	0f 85 29 fe ff ff    	jne    e872 <f0+0x2832>
    ea49:	e9 14 fe ff ff       	jmp    e862 <f0+0x2822>
    ea4e:	66 90                	xchg   %ax,%ax
    ea50:	66 85 c0             	test   %ax,%ax
    ea53:	0f 85 7f fd ff ff    	jne    e7d8 <f0+0x2798>
    ea59:	e9 6a fd ff ff       	jmp    e7c8 <f0+0x2788>
    ea5e:	66 90                	xchg   %ax,%ax
    ea60:	66 85 c0             	test   %ax,%ax
    ea63:	0f 85 d0 fc ff ff    	jne    e739 <f0+0x26f9>
    ea69:	e9 bb fc ff ff       	jmp    e729 <f0+0x26e9>
    ea6e:	66 90                	xchg   %ax,%ax
    ea70:	66 85 c0             	test   %ax,%ax
    ea73:	0f 85 21 fc ff ff    	jne    e69a <f0+0x265a>
    ea79:	e9 0c fc ff ff       	jmp    e68a <f0+0x264a>
    ea7e:	66 90                	xchg   %ax,%ax
    ea80:	66 85 c0             	test   %ax,%ax
    ea83:	0f 85 72 fb ff ff    	jne    e5fb <f0+0x25bb>
    ea89:	e9 5d fb ff ff       	jmp    e5eb <f0+0x25ab>
    ea8e:	66 90                	xchg   %ax,%ax
    ea90:	66 85 c0             	test   %ax,%ax
    ea93:	0f 85 c3 fa ff ff    	jne    e55c <f0+0x251c>
    ea99:	e9 ae fa ff ff       	jmp    e54c <f0+0x250c>
    ea9e:	66 90                	xchg   %ax,%ax
    eaa0:	66 85 c0             	test   %ax,%ax
    eaa3:	0f 85 14 fa ff ff    	jne    e4bd <f0+0x247d>
    eaa9:	e9 ff f9 ff ff       	jmp    e4ad <f0+0x246d>
    eaae:	66 90                	xchg   %ax,%ax
    eab0:	66 85 c0             	test   %ax,%ax
    eab3:	0f 85 65 f9 ff ff    	jne    e41e <f0+0x23de>
    eab9:	e9 50 f9 ff ff       	jmp    e40e <f0+0x23ce>
    eabe:	66 90                	xchg   %ax,%ax
    eac0:	66 85 c0             	test   %ax,%ax
    eac3:	0f 85 b6 f8 ff ff    	jne    e37f <f0+0x233f>
    eac9:	e9 a1 f8 ff ff       	jmp    e36f <f0+0x232f>
    eace:	66 90                	xchg   %ax,%ax
    ead0:	66 85 c0             	test   %ax,%ax
    ead3:	0f 85 07 f8 ff ff    	jne    e2e0 <f0+0x22a0>
    ead9:	e9 f2 f7 ff ff       	jmp    e2d0 <f0+0x2290>
    eade:	66 90                	xchg   %ax,%ax
    eae0:	66 85 c0             	test   %ax,%ax
    eae3:	0f 85 58 f7 ff ff    	jne    e241 <f0+0x2201>
    eae9:	e9 43 f7 ff ff       	jmp    e231 <f0+0x21f1>
    eaee:	66 90                	xchg   %ax,%ax
    eaf0:	66 85 c0             	test   %ax,%ax
    eaf3:	0f 85 a9 f6 ff ff    	jne    e1a2 <f0+0x2162>
    eaf9:	e9 94 f6 ff ff       	jmp    e192 <f0+0x2152>
    eafe:	66 90                	xchg   %ax,%ax
    eb00:	66 85 c0             	test   %ax,%ax
    eb03:	0f 85 fa f5 ff ff    	jne    e103 <f0+0x20c3>
    eb09:	e9 e5 f5 ff ff       	jmp    e0f3 <f0+0x20b3>
    eb0e:	66 90                	xchg   %ax,%ax
    eb10:	66 85 c0             	test   %ax,%ax
    eb13:	0f 85 4b f5 ff ff    	jne    e064 <f0+0x2024>
    eb19:	e9 36 f5 ff ff       	jmp    e054 <f0+0x2014>
    eb1e:	66 90                	xchg   %ax,%ax
    eb20:	66 85 c0             	test   %ax,%ax
    eb23:	0f 85 9c f4 ff ff    	jne    dfc5 <f0+0x1f85>
    eb29:	e9 87 f4 ff ff       	jmp    dfb5 <f0+0x1f75>
    eb2e:	66 90                	xchg   %ax,%ax
    eb30:	66 85 c0             	test   %ax,%ax
    eb33:	0f 85 ed f3 ff ff    	jne    df26 <f0+0x1ee6>
    eb39:	e9 d8 f3 ff ff       	jmp    df16 <f0+0x1ed6>
    eb3e:	4c 89 e7             	mov    %r12,%rdi
    eb41:	e8 8a 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb46:	e9 22 fd ff ff       	jmp    e86d <f0+0x282d>
    eb4b:	4c 89 e7             	mov    %r12,%rdi
    eb4e:	e8 7d 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb53:	e9 cd d6 ff ff       	jmp    c225 <f0+0x1e5>
    eb58:	4c 89 e7             	mov    %r12,%rdi
    eb5b:	e8 70 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb60:	e9 56 d7 ff ff       	jmp    c2bb <f0+0x27b>
    eb65:	4c 89 e7             	mov    %r12,%rdi
    eb68:	e8 63 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb6d:	e9 df d7 ff ff       	jmp    c351 <f0+0x311>
    eb72:	4c 89 e7             	mov    %r12,%rdi
    eb75:	e8 56 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb7a:	e9 68 d8 ff ff       	jmp    c3e7 <f0+0x3a7>
    eb7f:	4c 89 e7             	mov    %r12,%rdi
    eb82:	e8 49 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb87:	e9 fa d8 ff ff       	jmp    c486 <f0+0x446>
    eb8c:	4c 89 e7             	mov    %r12,%rdi
    eb8f:	e8 3c 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eb94:	e9 8c d9 ff ff       	jmp    c525 <f0+0x4e5>
    eb99:	4c 89 e7             	mov    %r12,%rdi
    eb9c:	e8 2f 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    eba1:	e9 ec e8 ff ff       	jmp    d492 <f0+0x1452>
    eba6:	4c 89 e7             	mov    %r12,%rdi
    eba9:	e8 22 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebae:	e9 7e e9 ff ff       	jmp    d531 <f0+0x14f1>
    ebb3:	4c 89 e7             	mov    %r12,%rdi
    ebb6:	e8 15 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebbb:	e9 10 ea ff ff       	jmp    d5d0 <f0+0x1590>
    ebc0:	4c 89 e7             	mov    %r12,%rdi
    ebc3:	e8 08 6c ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebc8:	e9 a2 ea ff ff       	jmp    d66f <f0+0x162f>
    ebcd:	4c 89 e7             	mov    %r12,%rdi
    ebd0:	e8 fb 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebd5:	e9 34 eb ff ff       	jmp    d70e <f0+0x16ce>
    ebda:	4c 89 e7             	mov    %r12,%rdi
    ebdd:	e8 ee 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebe2:	e9 c6 eb ff ff       	jmp    d7ad <f0+0x176d>
    ebe7:	4c 89 e7             	mov    %r12,%rdi
    ebea:	e8 e1 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebef:	e9 58 ec ff ff       	jmp    d84c <f0+0x180c>
    ebf4:	4c 89 e7             	mov    %r12,%rdi
    ebf7:	e8 d4 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ebfc:	e9 ea ec ff ff       	jmp    d8eb <f0+0x18ab>
    ec01:	4c 89 e7             	mov    %r12,%rdi
    ec04:	e8 c7 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec09:	e9 7c ed ff ff       	jmp    d98a <f0+0x194a>
    ec0e:	4c 89 e7             	mov    %r12,%rdi
    ec11:	e8 ba 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec16:	e9 0e ee ff ff       	jmp    da29 <f0+0x19e9>
    ec1b:	4c 89 e7             	mov    %r12,%rdi
    ec1e:	e8 ad 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec23:	e9 a0 ee ff ff       	jmp    dac8 <f0+0x1a88>
    ec28:	4c 89 e7             	mov    %r12,%rdi
    ec2b:	e8 a0 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec30:	e9 32 ef ff ff       	jmp    db67 <f0+0x1b27>
    ec35:	4c 89 e7             	mov    %r12,%rdi
    ec38:	e8 93 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec3d:	e9 c4 ef ff ff       	jmp    dc06 <f0+0x1bc6>
    ec42:	4c 89 e7             	mov    %r12,%rdi
    ec45:	e8 86 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec4a:	e9 56 f0 ff ff       	jmp    dca5 <f0+0x1c65>
    ec4f:	4c 89 e7             	mov    %r12,%rdi
    ec52:	e8 79 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec57:	e9 e8 f0 ff ff       	jmp    dd44 <f0+0x1d04>
    ec5c:	4c 89 e7             	mov    %r12,%rdi
    ec5f:	e8 6c 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec64:	e9 7a f1 ff ff       	jmp    dde3 <f0+0x1da3>
    ec69:	4c 89 e7             	mov    %r12,%rdi
    ec6c:	e8 5f 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec71:	e9 0c f2 ff ff       	jmp    de82 <f0+0x1e42>
    ec76:	4c 89 e7             	mov    %r12,%rdi
    ec79:	e8 52 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec7e:	e9 9e f2 ff ff       	jmp    df21 <f0+0x1ee1>
    ec83:	4c 89 e7             	mov    %r12,%rdi
    ec86:	e8 45 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec8b:	e9 30 f3 ff ff       	jmp    dfc0 <f0+0x1f80>
    ec90:	4c 89 e7             	mov    %r12,%rdi
    ec93:	e8 38 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ec98:	e9 c2 f3 ff ff       	jmp    e05f <f0+0x201f>
    ec9d:	4c 89 e7             	mov    %r12,%rdi
    eca0:	e8 2b 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    eca5:	e9 54 f4 ff ff       	jmp    e0fe <f0+0x20be>
    ecaa:	4c 89 e7             	mov    %r12,%rdi
    ecad:	e8 1e 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ecb2:	e9 e6 f4 ff ff       	jmp    e19d <f0+0x215d>
    ecb7:	4c 89 e7             	mov    %r12,%rdi
    ecba:	e8 11 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    ecbf:	e9 78 f5 ff ff       	jmp    e23c <f0+0x21fc>
    ecc4:	4c 89 e7             	mov    %r12,%rdi
    ecc7:	e8 04 6b ff ff       	call   57d0 <fwp_rc_forget_slot>
    eccc:	e9 0a f6 ff ff       	jmp    e2db <f0+0x229b>
    ecd1:	4c 89 e7             	mov    %r12,%rdi
    ecd4:	e8 f7 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ecd9:	e9 9c f6 ff ff       	jmp    e37a <f0+0x233a>
    ecde:	4c 89 e7             	mov    %r12,%rdi
    ece1:	e8 ea 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ece6:	e9 2e f7 ff ff       	jmp    e419 <f0+0x23d9>
    eceb:	4c 89 e7             	mov    %r12,%rdi
    ecee:	e8 dd 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ecf3:	e9 c0 f7 ff ff       	jmp    e4b8 <f0+0x2478>
    ecf8:	4c 89 e7             	mov    %r12,%rdi
    ecfb:	e8 d0 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ed00:	e9 52 f8 ff ff       	jmp    e557 <f0+0x2517>
    ed05:	4c 89 e7             	mov    %r12,%rdi
    ed08:	e8 c3 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ed0d:	e9 e4 f8 ff ff       	jmp    e5f6 <f0+0x25b6>
    ed12:	4c 89 e7             	mov    %r12,%rdi
    ed15:	e8 b6 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ed1a:	e9 76 f9 ff ff       	jmp    e695 <f0+0x2655>
    ed1f:	4c 89 e7             	mov    %r12,%rdi
    ed22:	e8 a9 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ed27:	e9 08 fa ff ff       	jmp    e734 <f0+0x26f4>
    ed2c:	4c 89 e7             	mov    %r12,%rdi
    ed2f:	e8 9c 6a ff ff       	call   57d0 <fwp_rc_forget_slot>
    ed34:	e9 9a fa ff ff       	jmp    e7d3 <f0+0x2793>
    ed39:	e8 12 47 ff ff       	call   3450 <__stack_chk_fail@plt>
    ed3e:	66 90                	xchg   %ax,%ax

000000000000ed40 <fwp_main_thread>:
    ed40:	f3 0f 1e fa          	endbr64
    ed44:	41 54                	push   %r12
    ed46:	55                   	push   %rbp
    ed47:	53                   	push   %rbx
    ed48:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    ed4f:	8b 0d 8f ee 05 00    	mov    0x5ee8f(%rip),%ecx        # 6dbe4 <fwp_heap+0x13a4>
    ed55:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    ed5c:	00 00 
    ed5e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ed65:	00 
    ed66:	31 c0                	xor    %eax,%eax
    ed68:	85 c9                	test   %ecx,%ecx
    ed6a:	0f 84 58 07 00 00    	je     f4c8 <fwp_main_thread+0x788>
    ed70:	8b 15 72 ee 05 00    	mov    0x5ee72(%rip),%edx        # 6dbe8 <fwp_heap+0x13a8>
    ed76:	85 d2                	test   %edx,%edx
    ed78:	0f 85 32 07 00 00    	jne    f4b0 <fwp_main_thread+0x770>
    ed7e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    ed83:	31 f6                	xor    %esi,%esi
    ed85:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    ed8a:	48 c7 05 4b d4 05 00 	movq   $0x40000000,0x5d44b(%rip)        # 6c1e0 <fwp_main_stack_size>
    ed91:	00 00 00 40 
    ed95:	48 89 05 4c d4 05 00 	mov    %rax,0x5d44c(%rip)        # 6c1e8 <fwp_main_stack_top>
    ed9c:	48 8d 05 fd 52 00 00 	lea    0x52fd(%rip),%rax        # 140a0 <alt.5>
    eda3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    eda8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    edaf:	01 00 
    edb1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    edb8:	00 
    edb9:	e8 e2 48 ff ff       	call   36a0 <sigaltstack@plt>
    edbe:	85 c0                	test   %eax,%eax
    edc0:	0f 85 6a 07 00 00    	jne    f530 <fwp_main_thread+0x7f0>
    edc6:	31 c0                	xor    %eax,%eax
    edc8:	b9 12 00 00 00       	mov    $0x12,%ecx
    edcd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    edd2:	f3 48 ab             	rep stos %rax,(%rdi)
    edd5:	48 8d 05 64 4f ff ff 	lea    -0xb09c(%rip),%rax        # 3d40 <fwp_segv>
    eddc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    ede1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    ede8:	04 00 00 08 
    edec:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    edf1:	e8 6a 47 ff ff       	call   3560 <sigemptyset@plt>
    edf6:	85 c0                	test   %eax,%eax
    edf8:	0f 85 32 07 00 00    	jne    f530 <fwp_main_thread+0x7f0>
    edfe:	31 d2                	xor    %edx,%edx
    ee00:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    ee05:	bf 0b 00 00 00       	mov    $0xb,%edi
    ee0a:	e8 e1 45 ff ff       	call   33f0 <sigaction@plt>
    ee0f:	85 c0                	test   %eax,%eax
    ee11:	0f 85 19 07 00 00    	jne    f530 <fwp_main_thread+0x7f0>
    ee17:	31 d2                	xor    %edx,%edx
    ee19:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    ee1e:	bf 07 00 00 00       	mov    $0x7,%edi
    ee23:	e8 c8 45 ff ff       	call   33f0 <sigaction@plt>
    ee28:	85 c0                	test   %eax,%eax
    ee2a:	0f 85 00 07 00 00    	jne    f530 <fwp_main_thread+0x7f0>
    ee30:	48 8b 05 29 ee 05 00 	mov    0x5ee29(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    ee37:	48 85 c0             	test   %rax,%rax
    ee3a:	0f 88 50 06 00 00    	js     f490 <fwp_main_thread+0x750>
    ee40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ee44:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    ee49:	48 8d 3d d0 53 ff ff 	lea    -0xac30(%rip),%rdi        # 4220 <ad_raw_report>
    ee50:	f2 0f 11 05 90 f6 05 	movsd  %xmm0,0x5f690(%rip)        # 6e4e8 <iteration_start_charge>
    ee57:	00 
    ee58:	c7 05 a6 f6 05 00 01 	movl   $0x1,0x5f6a6(%rip)        # 6e508 <iteration_active>
    ee5f:	00 00 00 
    ee62:	e8 09 09 00 00       	call   f770 <atexit>
    ee67:	85 c0                	test   %eax,%eax
    ee69:	0f 85 cd 06 00 00    	jne    f53c <fwp_main_thread+0x7fc>
    ee6f:	8b 05 1b 52 00 00    	mov    0x521b(%rip),%eax        # 14090 <st.3>
    ee75:	85 c0                	test   %eax,%eax
    ee77:	0f 84 5b 06 00 00    	je     f4d8 <fwp_main_thread+0x798>
    ee7d:	48 8b 2d 9c d9 05 00 	mov    0x5d99c(%rip),%rbp        # 6c820 <fwp_cur>
    ee84:	48 85 ed             	test   %rbp,%rbp
    ee87:	0f 84 03 03 00 00    	je     f190 <fwp_main_thread+0x450>
    ee8d:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    ee92:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    ee96:	48 89 eb             	mov    %rbp,%rbx
    ee99:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    ee9e:	0f 84 41 01 00 00    	je     efe5 <fwp_main_thread+0x2a5>
    eea4:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    eea9:	0f 84 11 02 00 00    	je     f0c0 <fwp_main_thread+0x380>
    eeaf:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    eeb3:	0f 84 f7 01 00 00    	je     f0b0 <fwp_main_thread+0x370>
    eeb9:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    eebd:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    eec1:	0f 85 79 02 00 00    	jne    f140 <fwp_main_thread+0x400>
    eec7:	48 8b 43 60          	mov    0x60(%rbx),%rax
    eecb:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    eed2:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    eed6:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    eedd:	00 00 00 00 
    eee1:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    eee8:	48 85 d2             	test   %rdx,%rdx
    eeeb:	74 07                	je     eef4 <fwp_main_thread+0x1b4>
    eeed:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    eef4:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    eef8:	48 85 c0             	test   %rax,%rax
    eefb:	74 34                	je     ef31 <fwp_main_thread+0x1f1>
    eefd:	48 89 43 68          	mov    %rax,0x68(%rbx)
    ef01:	48 8b 05 f0 d8 05 00 	mov    0x5d8f0(%rip),%rax        # 6c7f8 <fwp_timers>
    ef08:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    ef0c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    ef13:	00 00 00 00 
    ef17:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    ef1e:	48 85 c0             	test   %rax,%rax
    ef21:	74 07                	je     ef2a <fwp_main_thread+0x1ea>
    ef23:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    ef2a:	48 89 1d c7 d8 05 00 	mov    %rbx,0x5d8c7(%rip)        # 6c7f8 <fwp_timers>
    ef31:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    ef35:	e8 d6 8e ff ff       	call   7e10 <fwp_block>
    ef3a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    ef41:	48 85 c9             	test   %rcx,%rcx
    ef44:	74 47                	je     ef8d <fwp_main_thread+0x24d>
    ef46:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    ef4d:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ef54:	48 85 d2             	test   %rdx,%rdx
    ef57:	0f 84 23 02 00 00    	je     f180 <fwp_main_thread+0x440>
    ef5d:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    ef64:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    ef6b:	48 85 c0             	test   %rax,%rax
    ef6e:	74 07                	je     ef77 <fwp_main_thread+0x237>
    ef70:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    ef77:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    ef7e:	00 00 00 00 
    ef82:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ef86:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    ef8d:	48 8b 0d 8c d8 05 00 	mov    0x5d88c(%rip),%rcx        # 6c820 <fwp_cur>
    ef94:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    ef98:	0f 84 92 01 00 00    	je     f130 <fwp_main_thread+0x3f0>
    ef9e:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    efa5:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    efac:	48 85 d2             	test   %rdx,%rdx
    efaf:	0f 84 1b 04 00 00    	je     f3d0 <fwp_main_thread+0x690>
    efb5:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    efbc:	48 85 c0             	test   %rax,%rax
    efbf:	74 07                	je     efc8 <fwp_main_thread+0x288>
    efc1:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    efc8:	66 0f ef db          	pxor   %xmm3,%xmm3
    efcc:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    efd0:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    efd7:	48 89 cb             	mov    %rcx,%rbx
    efda:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    efdf:	0f 85 bf fe ff ff    	jne    eea4 <fwp_main_thread+0x164>
    efe5:	48 83 3d cb f4 05 00 	cmpq   $0x0,0x5f4cb(%rip)        # 6e4b8 <fwp_state_len>
    efec:	00 
    efed:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    eff1:	0f 84 0b 04 00 00    	je     f402 <fwp_main_thread+0x6c2>
    eff7:	48 3b 1d 1a d8 05 00 	cmp    0x5d81a(%rip),%rbx        # 6c818 <fwp_root>
    effe:	c7 05 98 50 01 00 00 	movl   $0x0,0x15098(%rip)        # 240a0 <fwp_exit_code>
    f005:	00 00 00 
    f008:	0f 85 4c 05 00 00    	jne    f55a <fwp_main_thread+0x81a>
    f00e:	48 85 db             	test   %rbx,%rbx
    f011:	0f 84 9f 01 00 00    	je     f1b6 <fwp_main_thread+0x476>
    f017:	48 8b 15 ca d7 05 00 	mov    0x5d7ca(%rip),%rdx        # 6c7e8 <fwp_tasks_active>
    f01e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    f022:	48 85 d2             	test   %rdx,%rdx
    f025:	0f 84 8b 01 00 00    	je     f1b6 <fwp_main_thread+0x476>
    f02b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    f030:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    f034:	75 08                	jne    f03e <fwp_main_thread+0x2fe>
    f036:	48 89 d7             	mov    %rdx,%rdi
    f039:	e8 f2 50 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    f03e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    f045:	48 85 d2             	test   %rdx,%rdx
    f048:	75 e6                	jne    f030 <fwp_main_thread+0x2f0>
    f04a:	eb 31                	jmp    f07d <fwp_main_thread+0x33d>
    f04c:	0f 1f 40 00          	nopl   0x0(%rax)
    f050:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    f057:	48 89 1d a2 d7 05 00 	mov    %rbx,0x5d7a2(%rip)        # 6c800 <fwp_ready_tail>
    f05e:	e8 ad 8d ff ff       	call   7e10 <fwp_block>
    f063:	e8 a8 8b ff ff       	call   7c10 <fwp_free_zombie>
    f068:	48 83 3d 78 d7 05 00 	cmpq   $0x0,0x5d778(%rip)        # 6c7e8 <fwp_tasks_active>
    f06f:	00 
    f070:	0f 84 40 01 00 00    	je     f1b6 <fwp_main_thread+0x476>
    f076:	48 8b 1d 9b d7 05 00 	mov    0x5d79b(%rip),%rbx        # 6c818 <fwp_root>
    f07d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    f081:	75 db                	jne    f05e <fwp_main_thread+0x31e>
    f083:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    f087:	75 d5                	jne    f05e <fwp_main_thread+0x31e>
    f089:	48 8b 05 70 d7 05 00 	mov    0x5d770(%rip),%rax        # 6c800 <fwp_ready_tail>
    f090:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    f094:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    f09b:	00 00 00 00 
    f09f:	48 85 c0             	test   %rax,%rax
    f0a2:	75 ac                	jne    f050 <fwp_main_thread+0x310>
    f0a4:	48 89 1d 5d d7 05 00 	mov    %rbx,0x5d75d(%rip)        # 6c808 <fwp_ready_head>
    f0ab:	eb aa                	jmp    f057 <fwp_main_thread+0x317>
    f0ad:	0f 1f 00             	nopl   (%rax)
    f0b0:	e8 0b 55 ff ff       	call   45c0 <fwp_now_ns>
    f0b5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    f0b9:	0f 8d 21 03 00 00    	jge    f3e0 <fwp_main_thread+0x6a0>
    f0bf:	90                   	nop
    f0c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    f0c4:	0f 85 ef fd ff ff    	jne    eeb9 <fwp_main_thread+0x179>
    f0ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    f0ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    f0d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    f0d6:	0f 85 ef fd ff ff    	jne    eecb <fwp_main_thread+0x18b>
    f0dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    f0e0:	48 85 c9             	test   %rcx,%rcx
    f0e3:	0f 84 e2 fd ff ff    	je     eecb <fwp_main_thread+0x18b>
    f0e9:	48 85 c0             	test   %rax,%rax
    f0ec:	0f 84 5b 04 00 00    	je     f54d <fwp_main_thread+0x80d>
    f0f2:	48 39 c8             	cmp    %rcx,%rax
    f0f5:	48 0f 4f c1          	cmovg  %rcx,%rax
    f0f9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    f100:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    f104:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    f10b:	00 00 00 00 
    f10f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    f116:	48 85 d2             	test   %rdx,%rdx
    f119:	74 07                	je     f122 <fwp_main_thread+0x3e2>
    f11b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    f122:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f126:	e9 d2 fd ff ff       	jmp    eefd <fwp_main_thread+0x1bd>
    f12b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    f130:	48 89 cb             	mov    %rcx,%rbx
    f133:	e9 61 fd ff ff       	jmp    ee99 <fwp_main_thread+0x159>
    f138:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    f13f:	00 
    f140:	48 8b 45 40          	mov    0x40(%rbp),%rax
    f144:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    f14b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    f152:	00 00 00 00 
    f156:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    f15d:	48 85 c0             	test   %rax,%rax
    f160:	0f 84 9a 03 00 00    	je     f500 <fwp_main_thread+0x7c0>
    f166:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    f16d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f171:	e9 bb fd ff ff       	jmp    ef31 <fwp_main_thread+0x1f1>
    f176:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f17d:	00 00 00 
    f180:	48 89 01             	mov    %rax,(%rcx)
    f183:	e9 e3 fd ff ff       	jmp    ef6b <fwp_main_thread+0x22b>
    f188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    f18f:	00 
    f190:	48 83 3d 20 f3 05 00 	cmpq   $0x0,0x5f320(%rip)        # 6e4b8 <fwp_state_len>
    f197:	00 
    f198:	0f 84 62 02 00 00    	je     f400 <fwp_main_thread+0x6c0>
    f19e:	48 83 3d 72 d6 05 00 	cmpq   $0x0,0x5d672(%rip)        # 6c818 <fwp_root>
    f1a5:	00 
    f1a6:	c7 05 f0 4e 01 00 00 	movl   $0x0,0x14ef0(%rip)        # 240a0 <fwp_exit_code>
    f1ad:	00 00 00 
    f1b0:	0f 85 9f 03 00 00    	jne    f555 <fwp_main_thread+0x815>
    f1b6:	e8 55 8a ff ff       	call   7c10 <fwp_free_zombie>
    f1bb:	48 83 3d 45 d6 05 00 	cmpq   $0x0,0x5d645(%rip)        # 6c808 <fwp_ready_head>
    f1c2:	00 
    f1c3:	0f 85 87 45 ff ff    	jne    3750 <fwp_main_thread.cold>
    f1c9:	48 83 3d 27 d6 05 00 	cmpq   $0x0,0x5d627(%rip)        # 6c7f8 <fwp_timers>
    f1d0:	00 
    f1d1:	0f 85 79 45 ff ff    	jne    3750 <fwp_main_thread.cold>
    f1d7:	8b 1d 17 d0 05 00    	mov    0x5d017(%rip),%ebx        # 6c1f4 <fwp_stack_pool_n>
    f1dd:	85 db                	test   %ebx,%ebx
    f1df:	74 36                	je     f217 <fwp_main_thread+0x4d7>
    f1e1:	83 eb 01             	sub    $0x1,%ebx
    f1e4:	48 8d 05 15 d0 05 00 	lea    0x5d015(%rip),%rax        # 6c200 <fwp_stack_pool>
    f1eb:	48 63 d3             	movslq %ebx,%rdx
    f1ee:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    f1f2:	eb 07                	jmp    f1fb <fwp_main_thread+0x4bb>
    f1f4:	0f 1f 40 00          	nopl   0x0(%rax)
    f1f8:	83 eb 01             	sub    $0x1,%ebx
    f1fb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    f1ff:	be 00 00 00 10       	mov    $0x10000000,%esi
    f204:	89 1d ea cf 05 00    	mov    %ebx,0x5cfea(%rip)        # 6c1f4 <fwp_stack_pool_n>
    f20a:	48 83 ed 08          	sub    $0x8,%rbp
    f20e:	e8 ad 43 ff ff       	call   35c0 <munmap@plt>
    f213:	85 db                	test   %ebx,%ebx
    f215:	75 e1                	jne    f1f8 <fwp_main_thread+0x4b8>
    f217:	8b 3d 03 4e 00 00    	mov    0x4e03(%rip),%edi        # 14020 <fwp_epfd>
    f21d:	85 ff                	test   %edi,%edi
    f21f:	78 05                	js     f226 <fwp_main_thread+0x4e6>
    f221:	e8 9a 42 ff ff       	call   34c0 <close@plt>
    f226:	4c 8b 25 d3 d1 05 00 	mov    0x5d1d3(%rip),%r12        # 6c400 <fwp_nfdws>
    f22d:	48 8b 2d d4 d1 05 00 	mov    0x5d1d4(%rip),%rbp        # 6c408 <fwp_fdws>
    f234:	31 db                	xor    %ebx,%ebx
    f236:	c7 05 e0 4d 00 00 ff 	movl   $0xffffffff,0x4de0(%rip)        # 14020 <fwp_epfd>
    f23d:	ff ff ff 
    f240:	4d 85 e4             	test   %r12,%r12
    f243:	74 38                	je     f27d <fwp_main_thread+0x53d>
    f245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    f24c:	00 00 00 00 
    f250:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    f255:	48 85 ff             	test   %rdi,%rdi
    f258:	74 1a                	je     f274 <fwp_main_thread+0x534>
    f25a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    f25e:	0f 85 ec 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f264:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    f269:	0f 85 e1 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f26f:	e8 9c 67 ff ff       	call   5a10 <fwp_mem_free>
    f274:	48 83 c3 01          	add    $0x1,%rbx
    f278:	49 39 dc             	cmp    %rbx,%r12
    f27b:	75 d3                	jne    f250 <fwp_main_thread+0x510>
    f27d:	48 89 ef             	mov    %rbp,%rdi
    f280:	e8 8b 67 ff ff       	call   5a10 <fwp_mem_free>
    f285:	48 8b 15 8c d5 05 00 	mov    0x5d58c(%rip),%rdx        # 6c818 <fwp_root>
    f28c:	48 c7 05 71 d1 05 00 	movq   $0x0,0x5d171(%rip)        # 6c408 <fwp_fdws>
    f293:	00 00 00 00 
    f297:	48 c7 05 5e d1 05 00 	movq   $0x0,0x5d15e(%rip)        # 6c400 <fwp_nfdws>
    f29e:	00 00 00 00 
    f2a2:	48 85 d2             	test   %rdx,%rdx
    f2a5:	74 4e                	je     f2f5 <fwp_main_thread+0x5b5>
    f2a7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    f2ac:	0f 85 9e 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f2b2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    f2b9:	00 
    f2ba:	0f 85 90 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f2c0:	48 83 3d f0 f1 05 00 	cmpq   $0x0,0x5f1f0(%rip)        # 6e4b8 <fwp_state_len>
    f2c7:	00 
    f2c8:	0f 85 82 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f2ce:	48 83 3d d2 f1 05 00 	cmpq   $0x0,0x5f1d2(%rip)        # 6e4a8 <fwp_state_owners>
    f2d5:	00 
    f2d6:	0f 85 74 44 ff ff    	jne    3750 <fwp_main_thread.cold>
    f2dc:	b9 79 00 00 00       	mov    $0x79,%ecx
    f2e1:	31 c0                	xor    %eax,%eax
    f2e3:	48 8d 3d 36 d1 05 00 	lea    0x5d136(%rip),%rdi        # 6c420 <fwp_root_context>
    f2ea:	f3 48 ab             	rep stos %rax,(%rdi)
    f2ed:	48 89 d7             	mov    %rdx,%rdi
    f2f0:	e8 1b 67 ff ff       	call   5a10 <fwp_mem_free>
    f2f5:	66 0f 6f 05 d3 4e 04 	movdqa 0x44ed3(%rip),%xmm0        # 541d0 <ad_raw_live+0x10>
    f2fc:	00 
    f2fd:	66 0f d4 05 bb 4e 04 	paddq  0x44ebb(%rip),%xmm0        # 541c0 <ad_raw_live>
    f304:	00 
    f305:	48 c7 05 10 d5 05 00 	movq   $0x0,0x5d510(%rip)        # 6c820 <fwp_cur>
    f30c:	00 00 00 00 
    f310:	48 8b 05 49 e9 05 00 	mov    0x5e949(%rip),%rax        # 6dc60 <fwp_heap+0x1420>
    f317:	48 c7 05 f6 d4 05 00 	movq   $0x0,0x5d4f6(%rip)        # 6c818 <fwp_root>
    f31e:	00 00 00 00 
    f322:	c7 05 dc f1 05 00 00 	movl   $0x0,0x5f1dc(%rip)        # 6e508 <iteration_active>
    f329:	00 00 00 
    f32c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    f330:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    f335:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    f339:	66 0f d6 05 d7 4d 01 	movq   %xmm0,0x14dd7(%rip)        # 24118 <ad_raw_before_shutdown>
    f340:	00 
    f341:	48 85 c0             	test   %rax,%rax
    f344:	0f 88 26 01 00 00    	js     f470 <fwp_main_thread+0x730>
    f34a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f34e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    f353:	f2 0f 5c 0d 8d f1 05 	subsd  0x5f18d(%rip),%xmm1        # 6e4e8 <iteration_start_charge>
    f35a:	00 
    f35b:	48 8b 3d fe 4c 00 00 	mov    0x4cfe(%rip),%rdi        # 14060 <stderr@GLIBC_2.2.5>
    f362:	48 8d 15 f7 17 00 00 	lea    0x17f7(%rip),%rdx        # 10b60 <_IO_stdin_used+0xb60>
    f369:	be 02 00 00 00       	mov    $0x2,%esi
    f36e:	f2 0f 10 05 6a f1 05 	movsd  0x5f16a(%rip),%xmm0        # 6e4e0 <iteration_peak>
    f375:	00 
    f376:	4c 8b 0d 73 f1 05 00 	mov    0x5f173(%rip),%r9        # 6e4f0 <iteration_retains>
    f37d:	b8 02 00 00 00       	mov    $0x2,%eax
    f382:	4c 8b 05 6f f1 05 00 	mov    0x5f16f(%rip),%r8        # 6e4f8 <iteration_bytes>
    f389:	48 8b 0d 70 f1 05 00 	mov    0x5f170(%rip),%rcx        # 6e500 <iteration_requests>
    f390:	e8 db 42 ff ff       	call   3670 <__fprintf_chk@plt>
    f395:	48 8b 3d a4 4c 00 00 	mov    0x4ca4(%rip),%rdi        # 14040 <stdout@GLIBC_2.2.5>
    f39c:	e8 ff 41 ff ff       	call   35a0 <fflush@plt>
    f3a1:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    f3a8:	00 
    f3a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    f3b0:	00 00 
    f3b2:	0f 85 90 01 00 00    	jne    f548 <fwp_main_thread+0x808>
    f3b8:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    f3bf:	31 c0                	xor    %eax,%eax
    f3c1:	5b                   	pop    %rbx
    f3c2:	5d                   	pop    %rbp
    f3c3:	41 5c                	pop    %r12
    f3c5:	c3                   	ret
    f3c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f3cd:	00 00 00 
    f3d0:	48 89 05 21 d4 05 00 	mov    %rax,0x5d421(%rip)        # 6c7f8 <fwp_timers>
    f3d7:	e9 e0 fb ff ff       	jmp    efbc <fwp_main_thread+0x27c>
    f3dc:	0f 1f 40 00          	nopl   0x0(%rax)
    f3e0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    f3e4:	0f 85 d6 fc ff ff    	jne    f0c0 <fwp_main_thread+0x380>
    f3ea:	48 89 ef             	mov    %rbp,%rdi
    f3ed:	e8 3e 4d ff ff       	call   4130 <fwp_cancel_tree.part.0>
    f3f2:	e9 c9 fc ff ff       	jmp    f0c0 <fwp_main_thread+0x380>
    f3f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f3fe:	00 00 
    f400:	31 db                	xor    %ebx,%ebx
    f402:	48 83 3d 9e f0 05 00 	cmpq   $0x0,0x5f09e(%rip)        # 6e4a8 <fwp_state_owners>
    f409:	00 
    f40a:	0f 85 e7 fb ff ff    	jne    eff7 <fwp_main_thread+0x2b7>
    f410:	48 8b 3d a9 f0 05 00 	mov    0x5f0a9(%rip),%rdi        # 6e4c0 <fwp_state>
    f417:	e8 f4 65 ff ff       	call   5a10 <fwp_mem_free>
    f41c:	48 c7 05 99 f0 05 00 	movq   $0x0,0x5f099(%rip)        # 6e4c0 <fwp_state>
    f423:	00 00 00 00 
    f427:	48 c7 05 7e f0 05 00 	movq   $0x0,0x5f07e(%rip)        # 6e4b0 <fwp_state_cap>
    f42e:	00 00 00 00 
    f432:	48 85 db             	test   %rbx,%rbx
    f435:	0f 84 ce 00 00 00    	je     f509 <fwp_main_thread+0x7c9>
    f43b:	48 39 1d d6 d3 05 00 	cmp    %rbx,0x5d3d6(%rip)        # 6c818 <fwp_root>
    f442:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    f449:	00 00 00 00 
    f44d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    f454:	00 00 00 00 
    f458:	c7 05 3e 4c 01 00 00 	movl   $0x0,0x14c3e(%rip)        # 240a0 <fwp_exit_code>
    f45f:	00 00 00 
    f462:	0f 84 af fb ff ff    	je     f017 <fwp_main_thread+0x2d7>
    f468:	e9 e3 42 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f46d:	0f 1f 00             	nopl   (%rax)
    f470:	48 89 c2             	mov    %rax,%rdx
    f473:	83 e0 01             	and    $0x1,%eax
    f476:	66 0f ef c9          	pxor   %xmm1,%xmm1
    f47a:	48 d1 ea             	shr    $1,%rdx
    f47d:	48 09 c2             	or     %rax,%rdx
    f480:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    f485:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    f489:	e9 c5 fe ff ff       	jmp    f353 <fwp_main_thread+0x613>
    f48e:	66 90                	xchg   %ax,%ax
    f490:	48 89 c2             	mov    %rax,%rdx
    f493:	83 e0 01             	and    $0x1,%eax
    f496:	66 0f ef c0          	pxor   %xmm0,%xmm0
    f49a:	48 d1 ea             	shr    $1,%rdx
    f49d:	48 09 c2             	or     %rax,%rdx
    f4a0:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    f4a5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    f4a9:	e9 9b f9 ff ff       	jmp    ee49 <fwp_main_thread+0x109>
    f4ae:	66 90                	xchg   %ax,%ax
    f4b0:	48 8d 3d 09 58 ff ff 	lea    -0xa7f7(%rip),%rdi        # 4cc0 <fwp_heap_report>
    f4b7:	e8 b4 02 00 00       	call   f770 <atexit>
    f4bc:	e9 bd f8 ff ff       	jmp    ed7e <fwp_main_thread+0x3e>
    f4c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    f4c8:	e8 03 59 ff ff       	call   4dd0 <fwp_heap_init>
    f4cd:	e9 9e f8 ff ff       	jmp    ed70 <fwp_main_thread+0x30>
    f4d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f4d8:	e8 63 cb ff ff       	call   c040 <f0>
    f4dd:	48 c7 05 a0 4b 00 00 	movq   $0x0,0x4ba0(%rip)        # 14088 <v.2>
    f4e4:	00 00 00 00 
    f4e8:	c7 05 9e 4b 00 00 01 	movl   $0x1,0x4b9e(%rip)        # 14090 <st.3>
    f4ef:	00 00 00 
    f4f2:	e9 86 f9 ff ff       	jmp    ee7d <fwp_main_thread+0x13d>
    f4f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    f4fe:	00 00 
    f500:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    f504:	e9 28 fa ff ff       	jmp    ef31 <fwp_main_thread+0x1f1>
    f509:	48 83 3d 07 d3 05 00 	cmpq   $0x0,0x5d307(%rip)        # 6c818 <fwp_root>
    f510:	00 
    f511:	c7 05 85 4b 01 00 00 	movl   $0x0,0x14b85(%rip)        # 240a0 <fwp_exit_code>
    f518:	00 00 00 
    f51b:	0f 84 95 fc ff ff    	je     f1b6 <fwp_main_thread+0x476>
    f521:	e9 2a 42 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f526:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f52d:	00 00 00 
    f530:	48 8d 3d 01 16 00 00 	lea    0x1601(%rip),%rdi        # 10b38 <_IO_stdin_used+0xb38>
    f537:	e8 14 4f ff ff       	call   4450 <fwp_trap>
    f53c:	48 8d 3d 90 0d 00 00 	lea    0xd90(%rip),%rdi        # 102d3 <_IO_stdin_used+0x2d3>
    f543:	e8 b8 4a ff ff       	call   4000 <ad_raw_fail>
    f548:	e8 03 3f ff ff       	call   3450 <__stack_chk_fail@plt>
    f54d:	48 89 c8             	mov    %rcx,%rax
    f550:	e9 a4 fb ff ff       	jmp    f0f9 <fwp_main_thread+0x3b9>
    f555:	e9 f6 41 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f55a:	e9 f1 41 ff ff       	jmp    3750 <fwp_main_thread.cold>
    f55f:	90                   	nop

000000000000f560 <__divmodti4>:
    f560:	f3 0f 1e fa          	endbr64
    f564:	55                   	push   %rbp
    f565:	49 89 f1             	mov    %rsi,%r9
    f568:	49 89 d2             	mov    %rdx,%r10
    f56b:	48 89 fe             	mov    %rdi,%rsi
    f56e:	49 89 cb             	mov    %rcx,%r11
    f571:	48 89 e5             	mov    %rsp,%rbp
    f574:	41 57                	push   %r15
    f576:	41 56                	push   %r14
    f578:	41 55                	push   %r13
    f57a:	41 54                	push   %r12
    f57c:	53                   	push   %rbx
    f57d:	4c 89 c3             	mov    %r8,%rbx
    f580:	45 31 c0             	xor    %r8d,%r8d
    f583:	4d 85 c9             	test   %r9,%r9
    f586:	79 12                	jns    f59a <__divmodti4+0x3a>
    f588:	31 ff                	xor    %edi,%edi
    f58a:	48 f7 de             	neg    %rsi
    f58d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    f594:	4c 19 cf             	sbb    %r9,%rdi
    f597:	49 89 f9             	mov    %rdi,%r9
    f59a:	4c 89 d8             	mov    %r11,%rax
    f59d:	4d 85 db             	test   %r11,%r11
    f5a0:	0f 88 1a 01 00 00    	js     f6c0 <__divmodti4+0x160>
    f5a6:	4c 89 d9             	mov    %r11,%rcx
    f5a9:	49 89 f3             	mov    %rsi,%r11
    f5ac:	75 62                	jne    f610 <__divmodti4+0xb0>
    f5ae:	4d 89 c4             	mov    %r8,%r12
    f5b1:	4d 39 d1             	cmp    %r10,%r9
    f5b4:	0f 83 46 01 00 00    	jae    f700 <__divmodti4+0x1a0>
    f5ba:	4c 89 d8             	mov    %r11,%rax
    f5bd:	4c 89 ca             	mov    %r9,%rdx
    f5c0:	49 f7 f2             	div    %r10
    f5c3:	49 89 c3             	mov    %rax,%r11
    f5c6:	31 c0                	xor    %eax,%eax
    f5c8:	48 89 d6             	mov    %rdx,%rsi
    f5cb:	31 ff                	xor    %edi,%edi
    f5cd:	4c 89 d9             	mov    %r11,%rcx
    f5d0:	48 89 c2             	mov    %rax,%rdx
    f5d3:	48 89 c8             	mov    %rcx,%rax
    f5d6:	4d 85 e4             	test   %r12,%r12
    f5d9:	74 0a                	je     f5e5 <__divmodti4+0x85>
    f5db:	48 f7 d8             	neg    %rax
    f5de:	48 83 d2 00          	adc    $0x0,%rdx
    f5e2:	48 f7 da             	neg    %rdx
    f5e5:	4d 85 c0             	test   %r8,%r8
    f5e8:	74 0a                	je     f5f4 <__divmodti4+0x94>
    f5ea:	48 f7 de             	neg    %rsi
    f5ed:	48 83 d7 00          	adc    $0x0,%rdi
    f5f1:	48 f7 df             	neg    %rdi
    f5f4:	48 89 33             	mov    %rsi,(%rbx)
    f5f7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    f5fb:	5b                   	pop    %rbx
    f5fc:	41 5c                	pop    %r12
    f5fe:	41 5d                	pop    %r13
    f600:	41 5e                	pop    %r14
    f602:	41 5f                	pop    %r15
    f604:	5d                   	pop    %rbp
    f605:	c3                   	ret
    f606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f60d:	00 00 00 
    f610:	4d 89 c4             	mov    %r8,%r12
    f613:	49 39 c1             	cmp    %rax,%r9
    f616:	0f 82 ce 00 00 00    	jb     f6ea <__divmodti4+0x18a>
    f61c:	31 ff                	xor    %edi,%edi
    f61e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    f623:	48 63 c7             	movslq %edi,%rax
    f626:	be 40 00 00 00       	mov    $0x40,%esi
    f62b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    f630:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    f635:	48 29 c6             	sub    %rax,%rsi
    f638:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    f63d:	48 09 c8             	or     %rcx,%rax
    f640:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    f645:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    f64a:	49 89 c6             	mov    %rax,%r14
    f64d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    f651:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    f656:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    f65b:	49 09 c1             	or     %rax,%r9
    f65e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    f662:	4c 89 c8             	mov    %r9,%rax
    f665:	49 f7 f6             	div    %r14
    f668:	48 89 d1             	mov    %rdx,%rcx
    f66b:	49 89 c3             	mov    %rax,%r11
    f66e:	49 89 c1             	mov    %rax,%r9
    f671:	49 f7 e2             	mul    %r10
    f674:	49 89 c6             	mov    %rax,%r14
    f677:	49 89 d2             	mov    %rdx,%r10
    f67a:	48 39 d1             	cmp    %rdx,%rcx
    f67d:	72 07                	jb     f686 <__divmodti4+0x126>
    f67f:	75 17                	jne    f698 <__divmodti4+0x138>
    f681:	49 39 c7             	cmp    %rax,%r15
    f684:	73 12                	jae    f698 <__divmodti4+0x138>
    f686:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    f68a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    f68e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    f692:	49 89 d2             	mov    %rdx,%r10
    f695:	49 89 c6             	mov    %rax,%r14
    f698:	4c 89 f8             	mov    %r15,%rax
    f69b:	4c 29 f0             	sub    %r14,%rax
    f69e:	4c 19 d1             	sbb    %r10,%rcx
    f6a1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    f6a6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    f6ab:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    f6b0:	48 09 c6             	or     %rax,%rsi
    f6b3:	48 89 cf             	mov    %rcx,%rdi
    f6b6:	31 c0                	xor    %eax,%eax
    f6b8:	4c 89 c9             	mov    %r9,%rcx
    f6bb:	e9 10 ff ff ff       	jmp    f5d0 <__divmodti4+0x70>
    f6c0:	4c 89 d0             	mov    %r10,%rax
    f6c3:	4c 89 da             	mov    %r11,%rdx
    f6c6:	4d 89 c4             	mov    %r8,%r12
    f6c9:	49 89 f3             	mov    %rsi,%r11
    f6cc:	48 f7 d8             	neg    %rax
    f6cf:	49 f7 d4             	not    %r12
    f6d2:	48 83 d2 00          	adc    $0x0,%rdx
    f6d6:	49 89 c2             	mov    %rax,%r10
    f6d9:	48 f7 da             	neg    %rdx
    f6dc:	48 89 d1             	mov    %rdx,%rcx
    f6df:	0f 84 cc fe ff ff    	je     f5b1 <__divmodti4+0x51>
    f6e5:	49 39 d1             	cmp    %rdx,%r9
    f6e8:	73 46                	jae    f730 <__divmodti4+0x1d0>
    f6ea:	4c 89 cf             	mov    %r9,%rdi
    f6ed:	31 c0                	xor    %eax,%eax
    f6ef:	31 c9                	xor    %ecx,%ecx
    f6f1:	e9 da fe ff ff       	jmp    f5d0 <__divmodti4+0x70>
    f6f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    f6fd:	00 00 00 
    f700:	4d 85 d2             	test   %r10,%r10
    f703:	75 0d                	jne    f712 <__divmodti4+0x1b2>
    f705:	b8 01 00 00 00       	mov    $0x1,%eax
    f70a:	31 d2                	xor    %edx,%edx
    f70c:	49 f7 f2             	div    %r10
    f70f:	49 89 c2             	mov    %rax,%r10
    f712:	4c 89 c8             	mov    %r9,%rax
    f715:	31 d2                	xor    %edx,%edx
    f717:	49 f7 f2             	div    %r10
    f71a:	49 89 c1             	mov    %rax,%r9
    f71d:	4c 89 d8             	mov    %r11,%rax
    f720:	49 f7 f2             	div    %r10
    f723:	49 89 c3             	mov    %rax,%r11
    f726:	4c 89 c8             	mov    %r9,%rax
    f729:	e9 9a fe ff ff       	jmp    f5c8 <__divmodti4+0x68>
    f72e:	66 90                	xchg   %ax,%ax
    f730:	45 31 f6             	xor    %r14d,%r14d
    f733:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    f738:	44 89 f7             	mov    %r14d,%edi
    f73b:	45 85 f6             	test   %r14d,%r14d
    f73e:	0f 85 df fe ff ff    	jne    f623 <__divmodti4+0xc3>
    f744:	4c 39 ca             	cmp    %r9,%rdx
    f747:	72 17                	jb     f760 <__divmodti4+0x200>
    f749:	31 c9                	xor    %ecx,%ecx
    f74b:	48 39 c6             	cmp    %rax,%rsi
    f74e:	73 10                	jae    f760 <__divmodti4+0x200>
    f750:	4c 89 cf             	mov    %r9,%rdi
    f753:	31 c0                	xor    %eax,%eax
    f755:	e9 76 fe ff ff       	jmp    f5d0 <__divmodti4+0x70>
    f75a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    f760:	4c 89 de             	mov    %r11,%rsi
    f763:	b9 01 00 00 00       	mov    $0x1,%ecx
    f768:	48 29 c6             	sub    %rax,%rsi
    f76b:	49 19 d1             	sbb    %rdx,%r9
    f76e:	eb e0                	jmp    f750 <__divmodti4+0x1f0>

000000000000f770 <atexit>:
    f770:	f3 0f 1e fa          	endbr64
    f774:	48 8b 15 8d 48 00 00 	mov    0x488d(%rip),%rdx        # 14008 <__dso_handle>
    f77b:	31 f6                	xor    %esi,%esi
    f77d:	e9 be 3e ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000f784 <_fini>:
    f784:	f3 0f 1e fa          	endbr64
    f788:	48 83 ec 08          	sub    $0x8,%rsp
    f78c:	48 83 c4 08          	add    $0x8,%rsp
    f790:	c3                   	ret
