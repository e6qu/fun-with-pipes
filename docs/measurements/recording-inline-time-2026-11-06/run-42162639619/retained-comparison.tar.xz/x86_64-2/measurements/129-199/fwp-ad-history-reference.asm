
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-history-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 ff 00 00 	mov    0xffc9(%rip),%rax        # 12fd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 fd 00 00    	push   0xfde2(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 fd 00 00    	jmp    *0xfde4(%rip)        # 12e10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e fc 00 00    	jmp    *0xfc4e(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12eb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12eb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12fa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12fa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a b9 00 00 	lea    0xb97a(%rip),%r9        # f091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 b9 00 00 	lea    0xb977(%rip),%r8        # f095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 dd 00 00 	lea    0xdd01(%rip),%rax        # 11480 <fwp_fn_table>
    377f:	48 89 05 52 1c 02 00 	mov    %rax,0x21c52(%rip)        # 253d8 <fwp_fns>
    3786:	48 8b 05 b3 f8 00 00 	mov    0xf8b3(%rip),%rax        # 13040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 4c 1c 02 00 	mov    %rax,0x21c4c(%rip)        # 253e0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 ba 00 00 	lea    0xba59(%rip),%rdi        # f1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 f8 00 00 	mov    0xf838(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 9f a8 00 00 	lea    0xa89f(%rip),%rdx        # e100 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 f7 00 00 	mov    0xf7a3(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 f7 01 00    	mov    0x1f7f8(%rip),%eax        # 230a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 b9 00 00 	lea    0xb909(%rip),%rdi        # f202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e c0 00 00 	lea    0xc08e(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 c0 00 00 	lea    0xc048(%rip),%rdi        # f970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c c0 00 00 	lea    0xc00c(%rip),%rdi        # f940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 bf 00 00 	lea    0xbfd8(%rip),%rdi        # f918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 f6 00 00    	call   *0xf653(%rip)        # 12fc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 f6 00 00 	lea    0xf6a1(%rip),%rdi        # 13028 <__TMC_END__>
    3987:	48 8d 05 9a f6 00 00 	lea    0xf69a(%rip),%rax        # 13028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 f6 00 00 	mov    0xf636(%rip),%rax        # 12fd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 f6 00 00 	lea    0xf671(%rip),%rdi        # 13028 <__TMC_END__>
    39b7:	48 8d 35 6a f6 00 00 	lea    0xf66a(%rip),%rsi        # 13028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 f6 00 00 	mov    0xf605(%rip),%rax        # 12fe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d f6 00 00 00 	cmpb   $0x0,0xf66d(%rip)        # 13068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 f5 00 00 	cmpq   $0x0,0xf5e2(%rip)        # 12fe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 f6 00 00 01 	movb   $0x1,0xf645(%rip)        # 13068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee f4 01 00 	add    0x1f4ee(%rip),%rdx        # 23110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc f4 01 00 	add    0x1f4dc(%rip),%rax        # 23110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 69 17 02 00 	mov    0x21769(%rip),%rdi        # 253e0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 f3 00 00 	mov    0xf3b4(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 f3 00 00 	mov    0xf3a1(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 f3 00 00 	mov    0xf392(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 61 fa 01 00 	mov    0x1fa61(%rip),%rax        # 23760 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 a1 f3 01 00 	mov    0x1f3a1(%rip),%rax        # 23120 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 8d f3 01 00 	sub    0x1f38d(%rip),%rax        # 23118 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd bc 00 00 	lea    0xbcbd(%rip),%rsi        # fa80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 7b 0d 02 00 	mov    0x20d7b(%rip),%rax        # 24b70 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 74 0d 02 00 	lea    0x20d74(%rip),%r8        # 24b70 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 55 0d 02 00 	mov    0x20d55(%rip),%rbx        # 24b58 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 65 0d 02 00 	mov    0x20d65(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d 01 0d 02 00 	mov    0x20d01(%rip),%rdi        # 24b60 <fwp_heap+0x13e0>
    3e5f:	48 29 35 4a 0d 02 00 	sub    %rsi,0x20d4a(%rip)        # 24bb0 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 da 0c 02 00 	mov    0x20cda(%rip),%rax        # 24b50 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 90 0c 02 00 	add    0x20c90(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 9e 0c 02 00 	mov    0x20c9e(%rip),%rsi        # 24b60 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 ac 0c 02 00 	mov    0x20cac(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 5b 0c 02 00 	mov    %r12,0x20c5b(%rip)        # 24b60 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 49 0c 02 00 	mov    %rbp,0x20c49(%rip)        # 24b58 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 2e 0c 02 00 	cmp    %rdi,0x20c2e(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 25 0c 02 00 	mov    %rdi,0x20c25(%rip)        # 24b48 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 69 0c 02 00 	sub    %rdi,0x20c69(%rip)        # 24bb0 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 11 0c 02 00 	mov    0x20c11(%rip),%rax        # 24b68 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 0a 0c 02 00 	lea    0x20c0a(%rip),%r8        # 24b68 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d 1d f0 00 00 	mov    0xf01d(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 af 00 00 	lea    0xafb4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d a9 f6 01 00 	cmp    0x1f6a9(%rip),%rdi        # 23760 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 6f f6 01 00 	mov    0x1f66f(%rip),%rax        # 23740 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 4d f6 01 00 	mov    %rdi,0x1f64d(%rip)        # 23740 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 29 f6 01 00 	mov    %rdi,0x1f629(%rip)        # 23748 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 b0 00 00 	lea    0xb005(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 ae 00 00 	lea    0xaea7(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 98 ee 00 00 	mov    0xee98(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 ae 00 00 	lea    0xae51(%rip),%rdx        # f020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 80 ee 00 00 	mov    0xee80(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 91 ed 00 00 	mov    0xed91(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 ad 00 00 	lea    0xad28(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 ad 00 00 	lea    0xad32(%rip),%rdi        # f02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba ac 00 00 	lea    0xacba(%rip),%rdi        # f049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 b2 00 00 	lea    0xb268(%rip),%rdi        # f608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 b6 00 	movdqa 0xb6e0(%rip),%xmm0        # faa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 ba 0f 02 00 	add    0x20fba(%rip),%rax        # 253d8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 b1 00 00 	lea    0xb1c4(%rip),%rdi        # f638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 75 ec 01 00 	cmp    %rax,0x1ec75(%rip)        # 23108 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 70 ec 01 00 	add    0x1ec70(%rip),%rax        # 23110 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad b1 00 00 	lea    0xb1ad(%rip),%rdi        # f668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 ab 00 00 	lea    0xab92(%rip),%r8        # f065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 a9 00 00 	lea    0xa9e7(%rip),%r8        # f074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 a8 00 00 	lea    0xa874(%rip),%r8        # f06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c a6 00 00 	lea    0xa64c(%rip),%rdi        # f079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 a7 00 00 	lea    0xa760(%rip),%rsi        # f1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 85 00 02 00 	mov    0x20085(%rip),%r9        # 24b48 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 de 00 02 00 	mov    0x200de(%rip),%r8        # 24ba8 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 ab 00 00 	lea    0xabe7(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d c6 00 02 00 	mov    0x200c6(%rip),%rcx        # 24ba0 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d d4 00 02 	movsd  0x200d4(%rip),%xmm1        # 24bc0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 c4 00 02 	movsd  0x200c4(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 65 e5 00 00 	mov    0xe565(%rip),%rdi        # 13060 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 af 00 	movdqa 0xaf78(%rip),%xmm0        # fab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 7f fb 01 00 	lea    0x1fb7f(%rip),%rax        # 246c0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 af 00 	movdqa 0xafa1(%rip),%xmm2        # faf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 25 fb 01 00 	movaps %xmm0,0x1fb25(%rip)        # 24680 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d af 00 	movdqa 0xaf5d(%rip),%xmm0        # fac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 b3 ff 01 00 01 	movl   $0x1,0x1ffb3(%rip)        # 24b24 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 13 fb 01 00 	movaps %xmm0,0x1fb13(%rip)        # 24690 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b af 00 	movdqa 0xaf4b(%rip),%xmm0        # fad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 14 fb 01 00 	movaps %xmm0,0x1fb14(%rip)        # 246a0 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c af 00 	movdqa 0xaf4c(%rip),%xmm0        # fae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 15 fb 01 00 	movaps %xmm0,0x1fb15(%rip)        # 246b0 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 95 eb 01 00 	lea    0x1eb95(%rip),%r8        # 23780 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 b0 fe 01 00 	mov    %rax,0x1feb0(%rip)        # 24b38 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 8e fe 01 00 	mov    %r12,0x1fe8e(%rip)        # 24b40 <fwp_heap+0x13c0>
    4cb2:	48 89 05 77 fe 01 00 	mov    %rax,0x1fe77(%rip)        # 24b30 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 90 fe 01 00 	mov    %rbx,0x1fe90(%rip)        # 24b50 <fwp_heap+0x13d0>
    4cc0:	48 89 35 b9 fe 01 00 	mov    %rsi,0x1feb9(%rip)        # 24b80 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 a3 00 00 	lea    0xa3d6(%rip),%rdi        # f0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 98 fe 01 00 	mov    %rax,0x1fe98(%rip)        # 24b78 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 1c fe 01 00    	mov    %eax,0x1fe1c(%rip)        # 24b28 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 0c ea 01 00 	mov    0x1ea0c(%rip),%r8        # 23740 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 3c e9 01 00 	mov    %rbx,0x1e93c(%rip)        # 23748 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 28 e9 01 00 	mov    %r8,0x1e928(%rip)        # 23740 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 a2 00 00 	lea    0xa239(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d fd e1 01 00 	lea    0x1e1fd(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 e5 e1 01 00 	movaps %xmm0,0x1e1e5(%rip)        # 230c0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 c1 e1 01 00 	mov    %rax,0x1e1c1(%rip)        # 230a8 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 e2 e1 01 00 	movaps %xmm0,0x1e1e2(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 e6 e1 01 00 	movaps %xmm0,0x1e1e6(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 e7 e1 01 00 	mov    %rdx,0x1e1e7(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 a1 00 00 	lea    0xa190(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d b7 e7 01 00 	mov    0x1e7b7(%rip),%rbx        # 23738 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ea df 00 00 	mov    0xdfea(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 a6 00 00 	lea    0xa6c3(%rip),%rdi        # f740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 8d e6 01 00 	mov    0x1e68d(%rip),%rax        # 23740 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 67 e6 01 00 	mov    %rdx,0x1e667(%rip)        # 23740 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d b4 e5 01 00 	mov    0x1e5b4(%rip),%rbx        # 23738 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 71 e5 01 00 	mov    %rbx,0x1e571(%rip)        # 23738 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 71 e5 01 00 	mov    %rdx,0x1e571(%rip)        # 23748 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 86 e5 01 00 	lea    0x1e586(%rip),%rsi        # 23780 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 05 01 02 00 	addq   $0x1,0x20105(%rip)        # 253c8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 a4 00 00 	lea    0xa497(%rip),%rdi        # f770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 a4 00 00 	lea    0xa4a8(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 9d 00 00 	lea    0x9dd4(%rip),%rdi        # f0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 3e e4 01 00 	lea    0x1e43e(%rip),%rcx        # 23780 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 3f 00 02 00 	subq   $0x1,0x2003f(%rip)        # 253c8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 a4 00 00 	lea    0xa403(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 20 00 02 00 	cmpq   $0x0,0x20020(%rip)        # 253c8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 75 ff 01 00 	sub    %rax,0x1ff75(%rip)        # 253d0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 53 ff 01 00 	add    %r12,0x1ff53(%rip)        # 253d0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 af f6 01 00 	mov    0x1f6af(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 ac e2 01 00 	lea    0x1e2ac(%rip),%rax        # 23780 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 03 f6 01 00 	add    0x1f603(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 d0 f5 01 00 	mov    0x1f5d0(%rip),%rsi        # 24b30 <fwp_heap+0x13b0>
    5560:	48 8b 05 f1 f5 01 00 	mov    0x1f5f1(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 e5 f5 01 00 	add    0x1f5e5(%rip),%r8        # 24b78 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 ad f5 01 	addsd  0x1f5ad(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 62 e1 01 00 	lea    0x1e162(%rip),%rax        # 23780 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 6c f5 01 00 	sub    %rdi,0x1f56c(%rip)        # 24ba0 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 84 f5 01 	movsd  %xmm0,0x1f584(%rip)        # 24bc0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 3e f5 01 00 	sub    %rdx,0x1f53e(%rip)        # 24ba0 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 44 f5 01 	addsd  0x1f544(%rip),%xmm0        # 24bc0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 38 f5 01 	movsd  %xmm0,0x1f538(%rip)        # 24bc0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 cf f4 01 00 	mov    0x1f4cf(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d c9 f4 01 00 	add    %rcx,0x1f4c9(%rip)        # 24bb0 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 82 f4 01 00 	cmp    0x1f482(%rip),%r9        # 24b70 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 79 f4 01 00 	mov    %r9,0x1f479(%rip)        # 24b70 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 6a f4 01 00 	cmp    0x1f46a(%rip),%r9        # 24b68 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 5d f4 01 00 	mov    %r9,0x1f45d(%rip)        # 24b68 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 73 f3 01 00 	add    0x1f373(%rip),%rdi        # 24b78 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 50 df 01 00 	lea    0x1df50(%rip),%r15        # 23780 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 c0 f2 01 00 	add    0x1f2c0(%rip),%r12        # 24b30 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 19 f3 01 00 	add    0x1f319(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 18 f3 01 00 	cmp    %rax,0x1f318(%rip)        # 24ba8 <fwp_heap+0x1428>
    5890:	48 89 05 09 f3 01 00 	mov    %rax,0x1f309(%rip)        # 24ba0 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 08 f3 01 00 	mov    %rax,0x1f308(%rip)        # 24ba8 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 04 f3 01 	addsd  0x1f304(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 fc f2 01 	movsd  %xmm0,0x1f2fc(%rip)        # 24bb8 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 43 f2 01 00    	mov    0x1f243(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 7f de 01 00 	lea    0x1de7f(%rip),%rdi        # 23780 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 38 f2 01 00 	add    0x1f238(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 33 f2 01 00 	cmp    %rax,0x1f233(%rip)        # 24ba8 <fwp_heap+0x1428>
    5975:	48 89 05 24 f2 01 00 	mov    %rax,0x1f224(%rip)        # 24ba0 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 23 f2 01 00 	mov    %rax,0x1f223(%rip)        # 24ba8 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 1f f2 01 	addsd  0x1f21f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 17 f2 01 	movsd  %xmm0,0x1f217(%rip)        # 24bb8 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ce f0 01 00    	mov    0x1f0ce(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 05 dd 01 00 	lea    0x1dd05(%rip),%rax        # 23780 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 bb f0 01 00 	add    0x1f0bb(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 ba f0 01 00 	cmp    %rax,0x1f0ba(%rip)        # 24ba8 <fwp_heap+0x1428>
    5aee:	48 89 05 ab f0 01 00 	mov    %rax,0x1f0ab(%rip)        # 24ba0 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 aa f0 01 00 	mov    %rax,0x1f0aa(%rip)        # 24ba8 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 a6 f0 01 	addsd  0x1f0a6(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 9e f0 01 	movsd  %xmm0,0x1f09e(%rip)        # 24bb8 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 2c f8 01 00 	add    0x1f82c(%rip),%r9        # 253d8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_p_ad_push>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	49 89 d5             	mov    %rdx,%r13
    5db9:	41 54                	push   %r12
    5dbb:	49 89 fc             	mov    %rdi,%r12
    5dbe:	55                   	push   %rbp
    5dbf:	53                   	push   %rbx
    5dc0:	48 83 ec 48          	sub    $0x48,%rsp
    5dc4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5dc9:	48 85 ff             	test   %rdi,%rdi
    5dcc:	79 09                	jns    5dd7 <fwp_p_ad_push+0x27>
    5dce:	48 85 d2             	test   %rdx,%rdx
    5dd1:	0f 88 b9 02 00 00    	js     6090 <fwp_p_ad_push+0x2e0>
    5dd7:	48 89 f8             	mov    %rdi,%rax
    5dda:	48 89 0c 24          	mov    %rcx,(%rsp)
    5dde:	4c 89 c5             	mov    %r8,%rbp
    5de1:	48 09 d0             	or     %rdx,%rax
    5de4:	0f 89 7e 02 00 00    	jns    6068 <fwp_p_ad_push+0x2b8>
    5dea:	48 85 ff             	test   %rdi,%rdi
    5ded:	0f 89 e6 03 00 00    	jns    61d9 <fwp_p_ad_push+0x429>
    5df3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5df8:	49 89 d6             	mov    %rdx,%r14
    5dfb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5e02:	00 
    5e03:	49 89 d4             	mov    %rdx,%r12
    5e06:	49 c1 fe 20          	sar    $0x20,%r14
    5e0a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5e11:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5e17:	48 85 ed             	test   %rbp,%rbp
    5e1a:	0f 84 48 03 00 00    	je     6168 <fwp_p_ad_push+0x3b8>
    5e20:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5e24:	0f 84 be 02 00 00    	je     60e8 <fwp_p_ad_push+0x338>
    5e2a:	4c 89 f7             	mov    %r14,%rdi
    5e2d:	e8 4e e6 ff ff       	call   4480 <fwp_tape_of>
    5e32:	48 89 c3             	mov    %rax,%rbx
    5e35:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5e3a:	0f 85 3e 03 00 00    	jne    617e <fwp_p_ad_push+0x3ce>
    5e40:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5e44:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5e48:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5e4c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5e53:	0f 8f cd 03 00 00    	jg     6226 <fwp_p_ad_push+0x476>
    5e59:	44 89 e0             	mov    %r12d,%eax
    5e5c:	4c 39 c0             	cmp    %r8,%rax
    5e5f:	0f 8d b5 03 00 00    	jge    621a <fwp_p_ad_push+0x46a>
    5e65:	4d 85 ed             	test   %r13,%r13
    5e68:	78 0c                	js     5e76 <fwp_p_ad_push+0xc6>
    5e6a:	44 89 e8             	mov    %r13d,%eax
    5e6d:	4c 39 c0             	cmp    %r8,%rax
    5e70:	0f 8d a4 03 00 00    	jge    621a <fwp_p_ad_push+0x46a>
    5e76:	4d 89 c7             	mov    %r8,%r15
    5e79:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5e7d:	49 8d 47 01          	lea    0x1(%r15),%rax
    5e81:	4c 89 f9             	mov    %r15,%rcx
    5e84:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5e8a:	0f 87 96 03 00 00    	ja     6226 <fwp_p_ad_push+0x476>
    5e90:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5e94:	48 39 e8             	cmp    %rbp,%rax
    5e97:	0f 8e 23 02 00 00    	jle    60c0 <fwp_p_ad_push+0x310>
    5e9d:	48 85 ed             	test   %rbp,%rbp
    5ea0:	ba 40 00 00 00       	mov    $0x40,%edx
    5ea5:	48 0f 44 ea          	cmove  %rdx,%rbp
    5ea9:	48 39 e8             	cmp    %rbp,%rax
    5eac:	7e 22                	jle    5ed0 <fwp_p_ad_push+0x120>
    5eae:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5eb5:	0f 8f f5 01 00 00    	jg     60b0 <fwp_p_ad_push+0x300>
    5ebb:	48 01 ed             	add    %rbp,%rbp
    5ebe:	48 39 e8             	cmp    %rbp,%rax
    5ec1:	7f eb                	jg     5eae <fwp_p_ad_push+0xfe>
    5ec3:	66 90                	xchg   %ax,%ax
    5ec5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ecc:	00 00 00 00 
    5ed0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5ed7:	00 
    5ed8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5edc:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ee1:	48 89 c6             	mov    %rax,%rsi
    5ee4:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5ee9:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    5eed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5ef2:	e8 d9 d6 ff ff       	call   35d0 <realloc@plt>
    5ef7:	48 85 c0             	test   %rax,%rax
    5efa:	0f 84 32 03 00 00    	je     6232 <fwp_p_ad_push+0x482>
    5f00:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    5f04:	4d 85 f6             	test   %r14,%r14
    5f07:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5f0c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5f10:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5f15:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5f19:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    5f1d:	0f 84 d5 01 00 00    	je     60f8 <fwp_p_ad_push+0x348>
    5f23:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5f27:	48 39 ea             	cmp    %rbp,%rdx
    5f2a:	0f 8d bb 00 00 00    	jge    5feb <fwp_p_ad_push+0x23b>
    5f30:	49 8b 76 40          	mov    0x40(%r14),%rsi
    5f34:	48 89 ef             	mov    %rbp,%rdi
    5f37:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5f3c:	48 c1 e7 04          	shl    $0x4,%rdi
    5f40:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5f45:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    5f4a:	be 02 00 00 00       	mov    $0x2,%esi
    5f4f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    5f54:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    5f59:	e8 f2 fa ff ff       	call   5a50 <fwp_heap_alloc>
    5f5e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    5f63:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5f68:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5f6d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5f72:	48 85 f6             	test   %rsi,%rsi
    5f75:	74 31                	je     5fa8 <fwp_p_ad_push+0x1f8>
    5f77:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    5f7c:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    5f81:	48 c1 e2 04          	shl    $0x4,%rdx
    5f85:	48 39 fa             	cmp    %rdi,%rdx
    5f88:	48 0f 47 d7          	cmova  %rdi,%rdx
    5f8c:	48 89 c7             	mov    %rax,%rdi
    5f8f:	e8 0c d6 ff ff       	call   35a0 <memcpy@plt>
    5f94:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    5f99:	e8 b2 f5 ff ff       	call   5550 <fwp_mem_free>
    5f9e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5fa3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5fa8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5fac:	48 89 ea             	mov    %rbp,%rdx
    5faf:	31 f6                	xor    %esi,%esi
    5fb1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    5fb6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5fbb:	48 29 fa             	sub    %rdi,%rdx
    5fbe:	48 c1 e7 04          	shl    $0x4,%rdi
    5fc2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    5fc7:	48 c1 e2 04          	shl    $0x4,%rdx
    5fcb:	e8 f0 d4 ff ff       	call   34c0 <memset@plt>
    5fd0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5fd5:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    5fd9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5fde:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    5fe3:	49 89 46 40          	mov    %rax,0x40(%r14)
    5fe7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5feb:	4d 85 ff             	test   %r15,%r15
    5fee:	0f 85 9c 01 00 00    	jne    6190 <fwp_p_ad_push+0x3e0>
    5ff4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5ff8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5ffc:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6003:	00 
    6004:	49 01 c6             	add    %rax,%r14
    6007:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    600b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    600f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6013:	4d 85 ed             	test   %r13,%r13
    6016:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    601c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6023:	4c 0f 48 e8          	cmovs  %rax,%r13
    6027:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    602c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6030:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6035:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6039:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    603e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6042:	48 83 c4 48          	add    $0x48,%rsp
    6046:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    604d:	ff ff ff 
    6050:	4c 21 e0             	and    %r12,%rax
    6053:	5b                   	pop    %rbx
    6054:	5d                   	pop    %rbp
    6055:	4c 09 c0             	or     %r8,%rax
    6058:	41 5c                	pop    %r12
    605a:	41 5d                	pop    %r13
    605c:	41 5e                	pop    %r14
    605e:	41 5f                	pop    %r15
    6060:	c3                   	ret
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	48 c1 fa 20          	sar    $0x20,%rdx
    606c:	48 c1 ff 20          	sar    $0x20,%rdi
    6070:	49 89 d6             	mov    %rdx,%r14
    6073:	48 39 d7             	cmp    %rdx,%rdi
    6076:	0f 84 9b fd ff ff    	je     5e17 <fwp_p_ad_push+0x67>
    607c:	48 8d 3d 3d 97 00 00 	lea    0x973d(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    6083:	e8 18 e1 ff ff       	call   41a0 <fwp_trap>
    6088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    608f:	00 
    6090:	48 83 c4 48          	add    $0x48,%rsp
    6094:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    609b:	5b                   	pop    %rbx
    609c:	5d                   	pop    %rbp
    609d:	41 5c                	pop    %r12
    609f:	41 5d                	pop    %r13
    60a1:	41 5e                	pop    %r14
    60a3:	41 5f                	pop    %r15
    60a5:	c3                   	ret
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    60b5:	e9 16 fe ff ff       	jmp    5ed0 <fwp_p_ad_push+0x120>
    60ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    60c0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60c4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    60c8:	48 c1 e1 03          	shl    $0x3,%rcx
    60cc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    60d3:	00 
    60d4:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    60d8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60dc:	e9 2e ff ff ff       	jmp    600f <fwp_p_ad_push+0x25f>
    60e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60e8:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    60ec:	e9 57 fd ff ff       	jmp    5e48 <fwp_p_ad_push+0x98>
    60f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    60f8:	49 89 ee             	mov    %rbp,%r14
    60fb:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    60ff:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6104:	49 c1 e6 04          	shl    $0x4,%r14
    6108:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    610d:	4c 89 f6             	mov    %r14,%rsi
    6110:	e8 bb d4 ff ff       	call   35d0 <realloc@plt>
    6115:	48 89 c2             	mov    %rax,%rdx
    6118:	48 85 c0             	test   %rax,%rax
    611b:	0f 84 11 01 00 00    	je     6232 <fwp_p_ad_push+0x482>
    6121:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6125:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6129:	4d 85 ff             	test   %r15,%r15
    612c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6131:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6136:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    613a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    613f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6143:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6147:	0f 85 98 00 00 00    	jne    61e5 <fwp_p_ad_push+0x435>
    614d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6151:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6155:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    615c:	00 
    615d:	45 31 ff             	xor    %r15d,%r15d
    6160:	e9 9f fe ff ff       	jmp    6004 <fwp_p_ad_push+0x254>
    6165:	0f 1f 00             	nopl   (%rax)
    6168:	4c 89 f7             	mov    %r14,%rdi
    616b:	e8 10 e3 ff ff       	call   4480 <fwp_tape_of>
    6170:	48 89 c3             	mov    %rax,%rbx
    6173:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6178:	0f 84 ca fc ff ff    	je     5e48 <fwp_p_ad_push+0x98>
    617e:	48 8d 3d 83 96 00 00 	lea    0x9683(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    6185:	e8 16 e0 ff ff       	call   41a0 <fwp_trap>
    618a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6190:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    6197:	00 
    6198:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    619d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    61a1:	49 c1 e7 02          	shl    $0x2,%r15
    61a5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    61aa:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    61b1:	00 
    61b2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    61b6:	4c 89 fa             	mov    %r15,%rdx
    61b9:	e8 52 d4 ff ff       	call   3610 <memmove@plt>
    61be:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61c2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    61c6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    61ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    61cf:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    61d4:	e9 2b fe ff ff       	jmp    6004 <fwp_p_ad_push+0x254>
    61d9:	48 c1 ff 20          	sar    $0x20,%rdi
    61dd:	49 89 fe             	mov    %rdi,%r14
    61e0:	e9 32 fc ff ff       	jmp    5e17 <fwp_p_ad_push+0x67>
    61e5:	4c 39 f0             	cmp    %r14,%rax
    61e8:	4c 89 f1             	mov    %r14,%rcx
    61eb:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    61f2:	00 
    61f3:	49 89 c6             	mov    %rax,%r14
    61f6:	48 0f 43 c8          	cmovae %rax,%rcx
    61fa:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    61ff:	48 29 c1             	sub    %rax,%rcx
    6202:	e8 59 d3 ff ff       	call   3560 <__memmove_chk@plt>
    6207:	4c 03 73 30          	add    0x30(%rbx),%r14
    620b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    620f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6213:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6218:	eb 83                	jmp    619d <fwp_p_ad_push+0x3ed>
    621a:	48 8d 3d e3 8e 00 00 	lea    0x8ee3(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    6221:	e8 7a df ff ff       	call   41a0 <fwp_trap>
    6226:	48 8d 3d bc 8e 00 00 	lea    0x8ebc(%rip),%rdi        # f0e9 <_IO_stdin_used+0xe9>
    622d:	e8 6e df ff ff       	call   41a0 <fwp_trap>
    6232:	48 89 df             	mov    %rbx,%rdi
    6235:	e8 c6 d9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    623a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    623e:	e8 7d d1 ff ff       	call   33c0 <free@plt>
    6243:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6247:	e8 74 d1 ff ff       	call   33c0 <free@plt>
    624c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6250:	e8 6b d1 ff ff       	call   33c0 <free@plt>
    6255:	31 c9                	xor    %ecx,%ecx
    6257:	31 c0                	xor    %eax,%eax
    6259:	31 d2                	xor    %edx,%edx
    625b:	89 53 04             	mov    %edx,0x4(%rbx)
    625e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6262:	ba 13 00 00 00       	mov    $0x13,%edx
    6267:	be 01 00 00 00       	mov    $0x1,%esi
    626c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6270:	48 8d 3d 91 8d 00 00 	lea    0x8d91(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6277:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    627b:	48 8b 0d de cd 00 00 	mov    0xcdde(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    6282:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6286:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    628a:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    628e:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6292:	e8 e9 d3 ff ff       	call   3680 <fwrite@plt>
    6297:	31 ff                	xor    %edi,%edi
    6299:	e8 22 d3 ff ff       	call   35c0 <fflush@plt>
    629e:	bf 66 00 00 00       	mov    $0x66,%edi
    62a3:	e8 f8 d3 ff ff       	call   36a0 <_Exit@plt>
    62a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    62af:	00 

00000000000062b0 <w107>:
    62b0:	41 56                	push   %r14
    62b2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    62b6:	48 89 fa             	mov    %rdi,%rdx
    62b9:	41 55                	push   %r13
    62bb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    62bf:	49 89 fd             	mov    %rdi,%r13
    62c2:	41 54                	push   %r12
    62c4:	55                   	push   %rbp
    62c5:	53                   	push   %rbx
    62c6:	48 83 ec 40          	sub    $0x40,%rsp
    62ca:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    62d0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62d5:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    62dc:	00 00 
    62de:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    62e3:	48 89 f5             	mov    %rsi,%rbp
    62e6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    62eb:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    62f1:	48 89 f1             	mov    %rsi,%rcx
    62f4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    62fa:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6301:	ff ff 
    6303:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    630a:	00 00 
    630c:	e8 9f fa ff ff       	call   5db0 <fwp_p_ad_push>
    6311:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6317:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    631c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6322:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6329:	00 f0 3f 
    632c:	48 89 c7             	mov    %rax,%rdi
    632f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6336:	00 f0 bf 
    6339:	48 89 ea             	mov    %rbp,%rdx
    633c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6341:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6347:	e8 64 fa ff ff       	call   5db0 <fwp_p_ad_push>
    634c:	f2 0f 10 05 dc 97 00 	movsd  0x97dc(%rip),%xmm0        # fb30 <msg.4+0xb0>
    6353:	00 
    6354:	4c 89 ef             	mov    %r13,%rdi
    6357:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    635d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6362:	49 89 c6             	mov    %rax,%r14
    6365:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    636c:	00 f0 3f 
    636f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6376:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    637d:	00 f0 bf 
    6380:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6385:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    638b:	e8 20 fa ff ff       	call   5db0 <fwp_p_ad_push>
    6390:	4c 89 e1             	mov    %r12,%rcx
    6393:	4c 89 e6             	mov    %r12,%rsi
    6396:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    639b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    63a1:	4c 89 f2             	mov    %r14,%rdx
    63a4:	4c 89 f7             	mov    %r14,%rdi
    63a7:	49 89 c5             	mov    %rax,%r13
    63aa:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    63ae:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63b4:	e8 f7 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    63b9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    63bf:	f2 0f 59 1d 71 97 00 	mulsd  0x9771(%rip),%xmm3        # fb38 <msg.4+0xb8>
    63c6:	00 
    63c7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    63cc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    63d1:	48 89 c2             	mov    %rax,%rdx
    63d4:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    63db:	00 59 40 
    63de:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63e5:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    63eb:	e8 c0 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    63f0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    63f5:	48 89 e9             	mov    %rbp,%rcx
    63f8:	4c 89 ea             	mov    %r13,%rdx
    63fb:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6401:	48 89 ee             	mov    %rbp,%rsi
    6404:	4c 89 ef             	mov    %r13,%rdi
    6407:	49 89 c4             	mov    %rax,%r12
    640a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    640e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6414:	e8 97 f9 ff ff       	call   5db0 <fwp_p_ad_push>
    6419:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    641f:	45 31 c0             	xor    %r8d,%r8d
    6422:	4c 89 e2             	mov    %r12,%rdx
    6425:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    642b:	48 89 c7             	mov    %rax,%rdi
    642e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6435:	00 f0 3f 
    6438:	48 89 ce             	mov    %rcx,%rsi
    643b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6440:	e8 6b f9 ff ff       	call   5db0 <fwp_p_ad_push>
    6445:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    644a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6451:	00 00 
    6453:	75 12                	jne    6467 <w107+0x1b7>
    6455:	48 83 c4 40          	add    $0x40,%rsp
    6459:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    645e:	5b                   	pop    %rbx
    645f:	5d                   	pop    %rbp
    6460:	41 5c                	pop    %r12
    6462:	41 5d                	pop    %r13
    6464:	41 5e                	pop    %r14
    6466:	c3                   	ret
    6467:	e8 f4 cf ff ff       	call   3460 <__stack_chk_fail@plt>
    646c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006470 <w164.constprop.0>:
    6470:	41 54                	push   %r12
    6472:	55                   	push   %rbp
    6473:	53                   	push   %rbx
    6474:	48 83 ec 10          	sub    $0x10,%rsp
    6478:	4c 8b 27             	mov    (%rdi),%r12
    647b:	4d 85 e4             	test   %r12,%r12
    647e:	74 58                	je     64d8 <w164.constprop.0+0x68>
    6480:	48 89 fd             	mov    %rdi,%rbp
    6483:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6487:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    648e:	31 db                	xor    %ebx,%ebx
    6490:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6496:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    649b:	45 31 c0             	xor    %r8d,%r8d
    649e:	48 83 c3 02          	add    $0x2,%rbx
    64a2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    64a9:	00 f0 3f 
    64ac:	48 89 ce             	mov    %rcx,%rsi
    64af:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    64b5:	e8 f6 f8 ff ff       	call   5db0 <fwp_p_ad_push>
    64ba:	4c 39 e3             	cmp    %r12,%rbx
    64bd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    64c3:	48 89 c7             	mov    %rax,%rdi
    64c6:	72 c8                	jb     6490 <w164.constprop.0+0x20>
    64c8:	48 83 c4 10          	add    $0x10,%rsp
    64cc:	48 89 f8             	mov    %rdi,%rax
    64cf:	5b                   	pop    %rbx
    64d0:	5d                   	pop    %rbp
    64d1:	41 5c                	pop    %r12
    64d3:	c3                   	ret
    64d4:	0f 1f 40 00          	nopl   0x0(%rax)
    64d8:	48 83 c4 10          	add    $0x10,%rsp
    64dc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    64e3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64e7:	5b                   	pop    %rbx
    64e8:	48 89 f8             	mov    %rdi,%rax
    64eb:	5d                   	pop    %rbp
    64ec:	41 5c                	pop    %r12
    64ee:	c3                   	ret
    64ef:	90                   	nop

00000000000064f0 <fwp_data.part.0.constprop.0>:
    64f0:	41 56                	push   %r14
    64f2:	41 89 fe             	mov    %edi,%r14d
    64f5:	41 54                	push   %r12
    64f7:	49 89 f4             	mov    %rsi,%r12
    64fa:	55                   	push   %rbp
    64fb:	53                   	push   %rbx
    64fc:	48 83 ec 08          	sub    $0x8,%rsp
    6500:	8b 05 1e e6 01 00    	mov    0x1e61e(%rip),%eax        # 24b24 <fwp_heap+0x13a4>
    6506:	85 c0                	test   %eax,%eax
    6508:	0f 84 fa 00 00 00    	je     6608 <fwp_data.part.0.constprop.0+0x118>
    650e:	0f b6 05 0d e2 01 00 	movzbl 0x1e20d(%rip),%eax        # 24722 <fwp_heap+0xfa2>
    6515:	48 8d 15 64 d2 01 00 	lea    0x1d264(%rip),%rdx        # 23780 <fwp_heap>
    651c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6523:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6527:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    652b:	48 8b 18             	mov    (%rax),%rbx
    652e:	48 85 db             	test   %rbx,%rbx
    6531:	0f 84 a9 00 00 00    	je     65e0 <fwp_data.part.0.constprop.0+0xf0>
    6537:	48 8b 13             	mov    (%rbx),%rdx
    653a:	48 f7 d2             	not    %rdx
    653d:	48 89 10             	mov    %rdx,(%rax)
    6540:	48 83 fd 18          	cmp    $0x18,%rbp
    6544:	76 1b                	jbe    6561 <fwp_data.part.0.constprop.0+0x71>
    6546:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    654a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    654e:	31 f6                	xor    %esi,%esi
    6550:	48 c1 e8 03          	shr    $0x3,%rax
    6554:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    655b:	00 
    655c:	e8 5f cf ff ff       	call   34c0 <memset@plt>
    6561:	48 89 e8             	mov    %rbp,%rax
    6564:	48 03 05 35 e6 01 00 	add    0x1e635(%rip),%rax        # 24ba0 <fwp_heap+0x1420>
    656b:	0f 82 a8 00 00 00    	jb     6619 <fwp_data.part.0.constprop.0+0x129>
    6571:	48 39 05 30 e6 01 00 	cmp    %rax,0x1e630(%rip)        # 24ba8 <fwp_heap+0x1428>
    6578:	48 89 05 21 e6 01 00 	mov    %rax,0x1e621(%rip)        # 24ba0 <fwp_heap+0x1420>
    657f:	73 07                	jae    6588 <fwp_data.part.0.constprop.0+0x98>
    6581:	48 89 05 20 e6 01 00 	mov    %rax,0x1e620(%rip)        # 24ba8 <fwp_heap+0x1428>
    6588:	66 0f ef c0          	pxor   %xmm0,%xmm0
    658c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6591:	f2 0f 58 05 1f e6 01 	addsd  0x1e61f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    6598:	00 
    6599:	f2 0f 11 05 17 e6 01 	movsd  %xmm0,0x1e617(%rip)        # 24bb8 <fwp_heap+0x1438>
    65a0:	00 
    65a1:	b8 02 00 00 00       	mov    $0x2,%eax
    65a6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    65ab:	66 0f 6e c8          	movd   %eax,%xmm1
    65af:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    65b3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    65b7:	49 8b 04 24          	mov    (%r12),%rax
    65bb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    65bf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    65c4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    65c8:	48 83 c4 08          	add    $0x8,%rsp
    65cc:	48 89 d8             	mov    %rbx,%rax
    65cf:	5b                   	pop    %rbx
    65d0:	5d                   	pop    %rbp
    65d1:	41 5c                	pop    %r12
    65d3:	41 5e                	pop    %r14
    65d5:	c3                   	ret
    65d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    65dd:	00 00 00 
    65e0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    65e4:	48 85 db             	test   %rbx,%rbx
    65e7:	74 1f                	je     6608 <fwp_data.part.0.constprop.0+0x118>
    65e9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    65ed:	48 29 da             	sub    %rbx,%rdx
    65f0:	48 39 ea             	cmp    %rbp,%rdx
    65f3:	72 13                	jb     6608 <fwp_data.part.0.constprop.0+0x118>
    65f5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    65f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    65fd:	e9 3e ff ff ff       	jmp    6540 <fwp_data.part.0.constprop.0+0x50>
    6602:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6608:	31 f6                	xor    %esi,%esi
    660a:	bf 18 00 00 00       	mov    $0x18,%edi
    660f:	e8 3c f4 ff ff       	call   5a50 <fwp_heap_alloc>
    6614:	48 89 c3             	mov    %rax,%rbx
    6617:	eb 88                	jmp    65a1 <fwp_data.part.0.constprop.0+0xb1>
    6619:	e8 92 d6 ff ff       	call   3cb0 <fwp_heap_oom>
    661e:	66 90                	xchg   %ax,%ax

0000000000006620 <fwp_rc_share>:
    6620:	48 8b 05 31 e5 01 00 	mov    0x1e531(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    6627:	48 2b 3d 02 e5 01 00 	sub    0x1e502(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    662e:	48 c1 e0 10          	shl    $0x10,%rax
    6632:	48 39 c7             	cmp    %rax,%rdi
    6635:	73 4a                	jae    6681 <fwp_rc_share+0x61>
    6637:	48 89 f8             	mov    %rdi,%rax
    663a:	48 c1 e8 10          	shr    $0x10,%rax
    663e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6642:	48 8b 05 2f e5 01 00 	mov    0x1e52f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    6649:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    664d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6651:	48 85 d2             	test   %rdx,%rdx
    6654:	74 2b                	je     6681 <fwp_rc_share+0x61>
    6656:	0f b6 08             	movzbl (%rax),%ecx
    6659:	80 f9 02             	cmp    $0x2,%cl
    665c:	74 2a                	je     6688 <fwp_rc_share+0x68>
    665e:	80 f9 01             	cmp    $0x1,%cl
    6661:	75 1e                	jne    6681 <fwp_rc_share+0x61>
    6663:	8b 48 18             	mov    0x18(%rax),%ecx
    6666:	0f b7 ff             	movzwl %di,%edi
    6669:	8b 40 1c             	mov    0x1c(%rax),%eax
    666c:	48 0f af f9          	imul   %rcx,%rdi
    6670:	48 c1 ef 20          	shr    $0x20,%rdi
    6674:	48 39 c7             	cmp    %rax,%rdi
    6677:	73 08                	jae    6681 <fwp_rc_share+0x61>
    6679:	48 01 fa             	add    %rdi,%rdx
    667c:	80 3a 00             	cmpb   $0x0,(%rdx)
    667f:	75 0d                	jne    668e <fwp_rc_share+0x6e>
    6681:	c3                   	ret
    6682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6688:	66 85 ff             	test   %di,%di
    668b:	74 ef                	je     667c <fwp_rc_share+0x5c>
    668d:	c3                   	ret
    668e:	50                   	push   %rax
    668f:	48 8d 3d a2 91 00 00 	lea    0x91a2(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    6696:	e8 05 db ff ff       	call   41a0 <fwp_trap>
    669b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000066a0 <fwp_rc_fresh>:
    66a0:	48 8b 15 b1 e4 01 00 	mov    0x1e4b1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 89 fe             	mov    %rdi,%rsi
    66ad:	48 2b 05 7c e4 01 00 	sub    0x1e47c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    66b4:	48 c1 e2 10          	shl    $0x10,%rdx
    66b8:	48 39 d0             	cmp    %rdx,%rax
    66bb:	73 4f                	jae    670c <fwp_rc_fresh+0x6c>
    66bd:	48 89 c2             	mov    %rax,%rdx
    66c0:	48 c1 ea 10          	shr    $0x10,%rdx
    66c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66c8:	48 8b 15 a9 e4 01 00 	mov    0x1e4a9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    66cf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66d3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66d7:	48 85 d2             	test   %rdx,%rdx
    66da:	74 30                	je     670c <fwp_rc_fresh+0x6c>
    66dc:	0f b6 39             	movzbl (%rcx),%edi
    66df:	40 80 ff 02          	cmp    $0x2,%dil
    66e3:	74 2b                	je     6710 <fwp_rc_fresh+0x70>
    66e5:	40 80 ff 01          	cmp    $0x1,%dil
    66e9:	75 21                	jne    670c <fwp_rc_fresh+0x6c>
    66eb:	8b 79 18             	mov    0x18(%rcx),%edi
    66ee:	0f b7 c0             	movzwl %ax,%eax
    66f1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    66f4:	48 0f af c7          	imul   %rdi,%rax
    66f8:	48 c1 e8 20          	shr    $0x20,%rax
    66fc:	48 39 c8             	cmp    %rcx,%rax
    66ff:	73 0b                	jae    670c <fwp_rc_fresh+0x6c>
    6701:	48 01 c2             	add    %rax,%rdx
    6704:	80 3a ff             	cmpb   $0xff,(%rdx)
    6707:	74 17                	je     6720 <fwp_rc_fresh+0x80>
    6709:	c6 02 01             	movb   $0x1,(%rdx)
    670c:	48 89 f0             	mov    %rsi,%rax
    670f:	c3                   	ret
    6710:	66 85 c0             	test   %ax,%ax
    6713:	74 ef                	je     6704 <fwp_rc_fresh+0x64>
    6715:	48 89 f0             	mov    %rsi,%rax
    6718:	c3                   	ret
    6719:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6720:	48 83 ec 18          	sub    $0x18,%rsp
    6724:	48 89 d7             	mov    %rdx,%rdi
    6727:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    672c:	48 89 14 24          	mov    %rdx,(%rsp)
    6730:	e8 db eb ff ff       	call   5310 <fwp_rc_forget_slot>
    6735:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    673a:	48 8b 14 24          	mov    (%rsp),%rdx
    673e:	48 89 f0             	mov    %rsi,%rax
    6741:	c6 02 01             	movb   $0x1,(%rdx)
    6744:	48 83 c4 18          	add    $0x18,%rsp
    6748:	c3                   	ret
    6749:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006750 <fwp_rc_free_arr>:
    6750:	48 8b 15 01 e4 01 00 	mov    0x1e401(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6757:	48 89 f8             	mov    %rdi,%rax
    675a:	48 2b 05 cf e3 01 00 	sub    0x1e3cf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6761:	48 c1 e2 10          	shl    $0x10,%rdx
    6765:	48 39 d0             	cmp    %rdx,%rax
    6768:	73 5b                	jae    67c5 <fwp_rc_free_arr+0x75>
    676a:	48 89 c2             	mov    %rax,%rdx
    676d:	48 c1 ea 10          	shr    $0x10,%rdx
    6771:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6775:	48 8b 15 fc e3 01 00 	mov    0x1e3fc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    677c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6780:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6784:	48 85 c9             	test   %rcx,%rcx
    6787:	74 3c                	je     67c5 <fwp_rc_free_arr+0x75>
    6789:	0f b6 32             	movzbl (%rdx),%esi
    678c:	40 80 fe 02          	cmp    $0x2,%sil
    6790:	74 2e                	je     67c0 <fwp_rc_free_arr+0x70>
    6792:	40 80 fe 01          	cmp    $0x1,%sil
    6796:	75 2d                	jne    67c5 <fwp_rc_free_arr+0x75>
    6798:	8b 72 18             	mov    0x18(%rdx),%esi
    679b:	0f b7 c0             	movzwl %ax,%eax
    679e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    67a1:	48 0f af c6          	imul   %rsi,%rax
    67a5:	48 c1 e8 20          	shr    $0x20,%rax
    67a9:	48 39 d0             	cmp    %rdx,%rax
    67ac:	73 17                	jae    67c5 <fwp_rc_free_arr+0x75>
    67ae:	48 01 c1             	add    %rax,%rcx
    67b1:	80 39 01             	cmpb   $0x1,(%rcx)
    67b4:	75 0f                	jne    67c5 <fwp_rc_free_arr+0x75>
    67b6:	e9 95 ed ff ff       	jmp    5550 <fwp_mem_free>
    67bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    67c0:	66 85 c0             	test   %ax,%ax
    67c3:	74 ec                	je     67b1 <fwp_rc_free_arr+0x61>
    67c5:	c3                   	ret
    67c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67cd:	00 00 00 

00000000000067d0 <fwp_rc_dup>:
    67d0:	f3 0f 1e fa          	endbr64
    67d4:	48 8b 05 7d e3 01 00 	mov    0x1e37d(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    67db:	48 2b 3d 4e e3 01 00 	sub    0x1e34e(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    67e2:	48 c1 e0 10          	shl    $0x10,%rax
    67e6:	48 39 c7             	cmp    %rax,%rdi
    67e9:	73 56                	jae    6841 <fwp_rc_dup+0x71>
    67eb:	48 89 f8             	mov    %rdi,%rax
    67ee:	48 c1 e8 10          	shr    $0x10,%rax
    67f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    67f6:	48 8b 05 7b e3 01 00 	mov    0x1e37b(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    67fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6801:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6805:	48 85 c0             	test   %rax,%rax
    6808:	74 37                	je     6841 <fwp_rc_dup+0x71>
    680a:	0f b6 0a             	movzbl (%rdx),%ecx
    680d:	80 f9 02             	cmp    $0x2,%cl
    6810:	74 36                	je     6848 <fwp_rc_dup+0x78>
    6812:	80 f9 01             	cmp    $0x1,%cl
    6815:	75 2a                	jne    6841 <fwp_rc_dup+0x71>
    6817:	8b 4a 18             	mov    0x18(%rdx),%ecx
    681a:	0f b7 ff             	movzwl %di,%edi
    681d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6820:	48 0f af f9          	imul   %rcx,%rdi
    6824:	48 c1 ef 20          	shr    $0x20,%rdi
    6828:	48 39 d7             	cmp    %rdx,%rdi
    682b:	73 14                	jae    6841 <fwp_rc_dup+0x71>
    682d:	48 01 f8             	add    %rdi,%rax
    6830:	0f b6 10             	movzbl (%rax),%edx
    6833:	84 d2                	test   %dl,%dl
    6835:	74 0a                	je     6841 <fwp_rc_dup+0x71>
    6837:	80 fa fd             	cmp    $0xfd,%dl
    683a:	77 14                	ja     6850 <fwp_rc_dup+0x80>
    683c:	83 c2 01             	add    $0x1,%edx
    683f:	88 10                	mov    %dl,(%rax)
    6841:	c3                   	ret
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	66 85 ff             	test   %di,%di
    684b:	74 e3                	je     6830 <fwp_rc_dup+0x60>
    684d:	c3                   	ret
    684e:	66 90                	xchg   %ax,%ax
    6850:	48 89 c7             	mov    %rax,%rdi
    6853:	e9 98 e9 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    685f:	00 

0000000000006860 <fwp_owned_entry161>:
    6860:	f3 0f 1e fa          	endbr64
    6864:	48 83 ec 38          	sub    $0x38,%rsp
    6868:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    686d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6874:	00 00 
    6876:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    687b:	31 c0                	xor    %eax,%eax
    687d:	48 8b 07             	mov    (%rdi),%rax
    6880:	48 03 47 10          	add    0x10(%rdi),%rax
    6884:	0f 80 c2 00 00 00    	jo     694c <fwp_owned_entry161+0xec>
    688a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    688f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6894:	31 ff                	xor    %edi,%edi
    6896:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    689a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    689f:	e8 4c fc ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    68a4:	48 8b 15 ad e2 01 00 	mov    0x1e2ad(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    68ab:	48 89 c6             	mov    %rax,%rsi
    68ae:	48 2b 05 7b e2 01 00 	sub    0x1e27b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    68b5:	48 c1 e2 10          	shl    $0x10,%rdx
    68b9:	48 39 d0             	cmp    %rdx,%rax
    68bc:	73 4f                	jae    690d <fwp_owned_entry161+0xad>
    68be:	48 89 c2             	mov    %rax,%rdx
    68c1:	48 c1 ea 10          	shr    $0x10,%rdx
    68c5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    68c9:	48 8b 15 a8 e2 01 00 	mov    0x1e2a8(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    68d0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    68d4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    68d8:	48 85 d2             	test   %rdx,%rdx
    68db:	74 30                	je     690d <fwp_owned_entry161+0xad>
    68dd:	0f b6 39             	movzbl (%rcx),%edi
    68e0:	40 80 ff 02          	cmp    $0x2,%dil
    68e4:	74 42                	je     6928 <fwp_owned_entry161+0xc8>
    68e6:	40 80 ff 01          	cmp    $0x1,%dil
    68ea:	75 21                	jne    690d <fwp_owned_entry161+0xad>
    68ec:	8b 79 18             	mov    0x18(%rcx),%edi
    68ef:	0f b7 c0             	movzwl %ax,%eax
    68f2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    68f5:	48 0f af c7          	imul   %rdi,%rax
    68f9:	48 c1 e8 20          	shr    $0x20,%rax
    68fd:	48 39 c8             	cmp    %rcx,%rax
    6900:	73 0b                	jae    690d <fwp_owned_entry161+0xad>
    6902:	48 01 c2             	add    %rax,%rdx
    6905:	80 3a ff             	cmpb   $0xff,(%rdx)
    6908:	74 26                	je     6930 <fwp_owned_entry161+0xd0>
    690a:	c6 02 01             	movb   $0x1,(%rdx)
    690d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6912:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6919:	00 00 
    691b:	75 34                	jne    6951 <fwp_owned_entry161+0xf1>
    691d:	48 89 f0             	mov    %rsi,%rax
    6920:	48 83 c4 38          	add    $0x38,%rsp
    6924:	c3                   	ret
    6925:	0f 1f 00             	nopl   (%rax)
    6928:	66 85 c0             	test   %ax,%ax
    692b:	75 e0                	jne    690d <fwp_owned_entry161+0xad>
    692d:	eb d6                	jmp    6905 <fwp_owned_entry161+0xa5>
    692f:	90                   	nop
    6930:	48 89 d7             	mov    %rdx,%rdi
    6933:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6938:	48 89 14 24          	mov    %rdx,(%rsp)
    693c:	e8 cf e9 ff ff       	call   5310 <fwp_rc_forget_slot>
    6941:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6946:	48 8b 14 24          	mov    (%rsp),%rdx
    694a:	eb be                	jmp    690a <fwp_owned_entry161+0xaa>
    694c:	e8 af cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6951:	e8 0a cb ff ff       	call   3460 <__stack_chk_fail@plt>
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 

0000000000006960 <e161>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	53                   	push   %rbx
    6965:	48 83 ec 30          	sub    $0x30,%rsp
    6969:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    696e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6975:	00 00 
    6977:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    697c:	31 c0                	xor    %eax,%eax
    697e:	48 8b 07             	mov    (%rdi),%rax
    6981:	48 03 47 10          	add    0x10(%rdi),%rax
    6985:	0f 80 c9 00 00 00    	jo     6a54 <e161+0xf4>
    698b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6990:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6995:	31 ff                	xor    %edi,%edi
    6997:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    699b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    69a0:	e8 4b fb ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    69a5:	48 8b 15 ac e1 01 00 	mov    0x1e1ac(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    69ac:	48 89 c3             	mov    %rax,%rbx
    69af:	48 2b 05 7a e1 01 00 	sub    0x1e17a(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    69b6:	48 c1 e2 10          	shl    $0x10,%rdx
    69ba:	48 39 d0             	cmp    %rdx,%rax
    69bd:	73 4f                	jae    6a0e <e161+0xae>
    69bf:	48 89 c2             	mov    %rax,%rdx
    69c2:	48 c1 ea 10          	shr    $0x10,%rdx
    69c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69ca:	48 8b 15 a7 e1 01 00 	mov    0x1e1a7(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    69d1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69d5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69d9:	48 85 d2             	test   %rdx,%rdx
    69dc:	74 30                	je     6a0e <e161+0xae>
    69de:	0f b6 31             	movzbl (%rcx),%esi
    69e1:	40 80 fe 02          	cmp    $0x2,%sil
    69e5:	74 49                	je     6a30 <e161+0xd0>
    69e7:	40 80 fe 01          	cmp    $0x1,%sil
    69eb:	75 21                	jne    6a0e <e161+0xae>
    69ed:	8b 71 18             	mov    0x18(%rcx),%esi
    69f0:	0f b7 c0             	movzwl %ax,%eax
    69f3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69f6:	48 0f af c6          	imul   %rsi,%rax
    69fa:	48 c1 e8 20          	shr    $0x20,%rax
    69fe:	48 39 c8             	cmp    %rcx,%rax
    6a01:	73 0b                	jae    6a0e <e161+0xae>
    6a03:	48 01 c2             	add    %rax,%rdx
    6a06:	80 3a ff             	cmpb   $0xff,(%rdx)
    6a09:	74 35                	je     6a40 <e161+0xe0>
    6a0b:	c6 02 01             	movb   $0x1,(%rdx)
    6a0e:	48 89 df             	mov    %rbx,%rdi
    6a11:	e8 0a fc ff ff       	call   6620 <fwp_rc_share>
    6a16:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6a1b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6a22:	00 00 
    6a24:	75 33                	jne    6a59 <e161+0xf9>
    6a26:	48 83 c4 30          	add    $0x30,%rsp
    6a2a:	48 89 d8             	mov    %rbx,%rax
    6a2d:	5b                   	pop    %rbx
    6a2e:	c3                   	ret
    6a2f:	90                   	nop
    6a30:	66 85 c0             	test   %ax,%ax
    6a33:	75 d9                	jne    6a0e <e161+0xae>
    6a35:	eb cf                	jmp    6a06 <e161+0xa6>
    6a37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6a3e:	00 00 
    6a40:	48 89 d7             	mov    %rdx,%rdi
    6a43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6a48:	e8 c3 e8 ff ff       	call   5310 <fwp_rc_forget_slot>
    6a4d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6a52:	eb b7                	jmp    6a0b <e161+0xab>
    6a54:	e8 a7 cc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6a59:	e8 02 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    6a5e:	66 90                	xchg   %ax,%ax

0000000000006a60 <fwp_drop0>:
    6a60:	f3 0f 1e fa          	endbr64
    6a64:	48 8b 15 ed e0 01 00 	mov    0x1e0ed(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6a6b:	48 89 f8             	mov    %rdi,%rax
    6a6e:	48 2b 05 bb e0 01 00 	sub    0x1e0bb(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6a75:	48 c1 e2 10          	shl    $0x10,%rdx
    6a79:	48 39 d0             	cmp    %rdx,%rax
    6a7c:	0f 83 be 00 00 00    	jae    6b40 <fwp_drop0+0xe0>
    6a82:	48 83 ec 18          	sub    $0x18,%rsp
    6a86:	4c 8d 05 f3 cc 01 00 	lea    0x1ccf3(%rip),%r8        # 23780 <fwp_heap>
    6a8d:	48 89 c2             	mov    %rax,%rdx
    6a90:	48 c1 ea 10          	shr    $0x10,%rdx
    6a94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a98:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a9f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6aa3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6aa7:	48 85 d2             	test   %rdx,%rdx
    6aaa:	74 3c                	je     6ae8 <fwp_drop0+0x88>
    6aac:	0f b6 31             	movzbl (%rcx),%esi
    6aaf:	40 80 fe 02          	cmp    $0x2,%sil
    6ab3:	74 3b                	je     6af0 <fwp_drop0+0x90>
    6ab5:	40 80 fe 01          	cmp    $0x1,%sil
    6ab9:	75 2d                	jne    6ae8 <fwp_drop0+0x88>
    6abb:	8b 71 18             	mov    0x18(%rcx),%esi
    6abe:	0f b7 c0             	movzwl %ax,%eax
    6ac1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ac4:	48 0f af c6          	imul   %rsi,%rax
    6ac8:	48 c1 e8 20          	shr    $0x20,%rax
    6acc:	48 39 c8             	cmp    %rcx,%rax
    6acf:	73 17                	jae    6ae8 <fwp_drop0+0x88>
    6ad1:	48 01 c2             	add    %rax,%rdx
    6ad4:	0f b6 02             	movzbl (%rdx),%eax
    6ad7:	84 c0                	test   %al,%al
    6ad9:	74 0d                	je     6ae8 <fwp_drop0+0x88>
    6adb:	3c 01                	cmp    $0x1,%al
    6add:	74 21                	je     6b00 <fwp_drop0+0xa0>
    6adf:	3c ff                	cmp    $0xff,%al
    6ae1:	74 65                	je     6b48 <fwp_drop0+0xe8>
    6ae3:	83 e8 01             	sub    $0x1,%eax
    6ae6:	88 02                	mov    %al,(%rdx)
    6ae8:	48 83 c4 18          	add    $0x18,%rsp
    6aec:	c3                   	ret
    6aed:	0f 1f 00             	nopl   (%rax)
    6af0:	66 85 c0             	test   %ax,%ax
    6af3:	74 df                	je     6ad4 <fwp_drop0+0x74>
    6af5:	48 83 c4 18          	add    $0x18,%rsp
    6af9:	c3                   	ret
    6afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b00:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6b04:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6b09:	e8 42 fc ff ff       	call   6750 <fwp_rc_free_arr>
    6b0e:	4c 8d 05 6b cc 01 00 	lea    0x1cc6b(%rip),%r8        # 23780 <fwp_heap>
    6b15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6b1a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b21:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b28:	48 c1 e2 10          	shl    $0x10,%rdx
    6b2c:	48 39 d0             	cmp    %rdx,%rax
    6b2f:	73 b7                	jae    6ae8 <fwp_drop0+0x88>
    6b31:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b36:	e9 52 ff ff ff       	jmp    6a8d <fwp_drop0+0x2d>
    6b3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b40:	c3                   	ret
    6b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b48:	48 89 d0             	mov    %rdx,%rax
    6b4b:	48 c1 e8 11          	shr    $0x11,%rax
    6b4f:	48 31 d0             	xor    %rdx,%rax
    6b52:	48 89 c1             	mov    %rax,%rcx
    6b55:	48 c1 e9 09          	shr    $0x9,%rcx
    6b59:	48 31 c8             	xor    %rcx,%rax
    6b5c:	0f b6 c8             	movzbl %al,%ecx
    6b5f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6b66:	00 
    6b67:	48 85 c0             	test   %rax,%rax
    6b6a:	75 1d                	jne    6b89 <fwp_drop0+0x129>
    6b6c:	eb 56                	jmp    6bc4 <fwp_drop0+0x164>
    6b6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b7c:	00 00 00 00 
    6b80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b84:	48 85 c0             	test   %rax,%rax
    6b87:	74 3b                	je     6bc4 <fwp_drop0+0x164>
    6b89:	48 89 c1             	mov    %rax,%rcx
    6b8c:	48 39 10             	cmp    %rdx,(%rax)
    6b8f:	75 ef                	jne    6b80 <fwp_drop0+0x120>
    6b91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ba4:	0f 85 3e ff ff ff    	jne    6ae8 <fwp_drop0+0x88>
    6baa:	48 89 d7             	mov    %rdx,%rdi
    6bad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bb2:	e8 59 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6bbf:	e9 24 ff ff ff       	jmp    6ae8 <fwp_drop0+0x88>
    6bc4:	48 8d 3d cd 8b 00 00 	lea    0x8bcd(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6bcb:	e8 d0 d5 ff ff       	call   41a0 <fwp_trap>

0000000000006bd0 <fwp_arg_drop12>:
    6bd0:	f3 0f 1e fa          	endbr64
    6bd4:	85 f6                	test   %esi,%esi
    6bd6:	75 04                	jne    6bdc <fwp_arg_drop12+0xc>
    6bd8:	85 d2                	test   %edx,%edx
    6bda:	75 04                	jne    6be0 <fwp_arg_drop12+0x10>
    6bdc:	c3                   	ret
    6bdd:	0f 1f 00             	nopl   (%rax)
    6be0:	48 8b 3f             	mov    (%rdi),%rdi
    6be3:	e9 78 fe ff ff       	jmp    6a60 <fwp_drop0>
    6be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bef:	00 

0000000000006bf0 <fwp_drop1>:
    6bf0:	f3 0f 1e fa          	endbr64
    6bf4:	48 8b 15 5d df 01 00 	mov    0x1df5d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6bfb:	48 89 f8             	mov    %rdi,%rax
    6bfe:	48 2b 05 2b df 01 00 	sub    0x1df2b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6c05:	48 c1 e2 10          	shl    $0x10,%rdx
    6c09:	48 39 d0             	cmp    %rdx,%rax
    6c0c:	0f 83 be 00 00 00    	jae    6cd0 <fwp_drop1+0xe0>
    6c12:	48 83 ec 18          	sub    $0x18,%rsp
    6c16:	4c 8d 05 63 cb 01 00 	lea    0x1cb63(%rip),%r8        # 23780 <fwp_heap>
    6c1d:	48 89 c2             	mov    %rax,%rdx
    6c20:	48 c1 ea 10          	shr    $0x10,%rdx
    6c24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6c2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c37:	48 85 d2             	test   %rdx,%rdx
    6c3a:	74 3c                	je     6c78 <fwp_drop1+0x88>
    6c3c:	0f b6 31             	movzbl (%rcx),%esi
    6c3f:	40 80 fe 02          	cmp    $0x2,%sil
    6c43:	74 3b                	je     6c80 <fwp_drop1+0x90>
    6c45:	40 80 fe 01          	cmp    $0x1,%sil
    6c49:	75 2d                	jne    6c78 <fwp_drop1+0x88>
    6c4b:	8b 71 18             	mov    0x18(%rcx),%esi
    6c4e:	0f b7 c0             	movzwl %ax,%eax
    6c51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c54:	48 0f af c6          	imul   %rsi,%rax
    6c58:	48 c1 e8 20          	shr    $0x20,%rax
    6c5c:	48 39 c8             	cmp    %rcx,%rax
    6c5f:	73 17                	jae    6c78 <fwp_drop1+0x88>
    6c61:	48 01 c2             	add    %rax,%rdx
    6c64:	0f b6 02             	movzbl (%rdx),%eax
    6c67:	84 c0                	test   %al,%al
    6c69:	74 0d                	je     6c78 <fwp_drop1+0x88>
    6c6b:	3c 01                	cmp    $0x1,%al
    6c6d:	74 21                	je     6c90 <fwp_drop1+0xa0>
    6c6f:	3c ff                	cmp    $0xff,%al
    6c71:	74 65                	je     6cd8 <fwp_drop1+0xe8>
    6c73:	83 e8 01             	sub    $0x1,%eax
    6c76:	88 02                	mov    %al,(%rdx)
    6c78:	48 83 c4 18          	add    $0x18,%rsp
    6c7c:	c3                   	ret
    6c7d:	0f 1f 00             	nopl   (%rax)
    6c80:	66 85 c0             	test   %ax,%ax
    6c83:	74 df                	je     6c64 <fwp_drop1+0x74>
    6c85:	48 83 c4 18          	add    $0x18,%rsp
    6c89:	c3                   	ret
    6c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6c94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c99:	e8 b2 fa ff ff       	call   6750 <fwp_rc_free_arr>
    6c9e:	4c 8d 05 db ca 01 00 	lea    0x1cadb(%rip),%r8        # 23780 <fwp_heap>
    6ca5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6caa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6cb1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6cb8:	48 c1 e2 10          	shl    $0x10,%rdx
    6cbc:	48 39 d0             	cmp    %rdx,%rax
    6cbf:	73 b7                	jae    6c78 <fwp_drop1+0x88>
    6cc1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6cc6:	e9 52 ff ff ff       	jmp    6c1d <fwp_drop1+0x2d>
    6ccb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6cd0:	c3                   	ret
    6cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cd8:	48 89 d0             	mov    %rdx,%rax
    6cdb:	48 c1 e8 11          	shr    $0x11,%rax
    6cdf:	48 31 d0             	xor    %rdx,%rax
    6ce2:	48 89 c1             	mov    %rax,%rcx
    6ce5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ce9:	48 31 c8             	xor    %rcx,%rax
    6cec:	0f b6 c8             	movzbl %al,%ecx
    6cef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6cf6:	00 
    6cf7:	48 85 c0             	test   %rax,%rax
    6cfa:	75 0d                	jne    6d09 <fwp_drop1+0x119>
    6cfc:	eb 46                	jmp    6d44 <fwp_drop1+0x154>
    6cfe:	66 90                	xchg   %ax,%ax
    6d00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	74 3b                	je     6d44 <fwp_drop1+0x154>
    6d09:	48 89 c1             	mov    %rax,%rcx
    6d0c:	48 39 10             	cmp    %rdx,(%rax)
    6d0f:	75 ef                	jne    6d00 <fwp_drop1+0x110>
    6d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d24:	0f 85 4e ff ff ff    	jne    6c78 <fwp_drop1+0x88>
    6d2a:	48 89 d7             	mov    %rdx,%rdi
    6d2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d32:	e8 d9 e5 ff ff       	call   5310 <fwp_rc_forget_slot>
    6d37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d3f:	e9 34 ff ff ff       	jmp    6c78 <fwp_drop1+0x88>
    6d44:	48 8d 3d 4d 8a 00 00 	lea    0x8a4d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6d4b:	e8 50 d4 ff ff       	call   41a0 <fwp_trap>

0000000000006d50 <fwp_closure_drop>:
    6d50:	48 8b 15 01 de 01 00 	mov    0x1de01(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    6d57:	48 89 f8             	mov    %rdi,%rax
    6d5a:	48 2b 05 cf dd 01 00 	sub    0x1ddcf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    6d61:	48 c1 e2 10          	shl    $0x10,%rdx
    6d65:	48 39 d0             	cmp    %rdx,%rax
    6d68:	73 6b                	jae    6dd5 <fwp_closure_drop+0x85>
    6d6a:	48 89 c2             	mov    %rax,%rdx
    6d6d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d75:	48 8b 15 fc dd 01 00 	mov    0x1ddfc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    6d7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d84:	48 85 d2             	test   %rdx,%rdx
    6d87:	74 4c                	je     6dd5 <fwp_closure_drop+0x85>
    6d89:	0f b6 31             	movzbl (%rcx),%esi
    6d8c:	40 80 fe 02          	cmp    $0x2,%sil
    6d90:	74 3e                	je     6dd0 <fwp_closure_drop+0x80>
    6d92:	40 80 fe 01          	cmp    $0x1,%sil
    6d96:	75 3d                	jne    6dd5 <fwp_closure_drop+0x85>
    6d98:	8b 71 18             	mov    0x18(%rcx),%esi
    6d9b:	0f b7 c0             	movzwl %ax,%eax
    6d9e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6da1:	48 0f af c6          	imul   %rsi,%rax
    6da5:	48 c1 e8 20          	shr    $0x20,%rax
    6da9:	48 39 c8             	cmp    %rcx,%rax
    6dac:	73 27                	jae    6dd5 <fwp_closure_drop+0x85>
    6dae:	48 01 c2             	add    %rax,%rdx
    6db1:	0f b6 02             	movzbl (%rdx),%eax
    6db4:	84 c0                	test   %al,%al
    6db6:	74 1d                	je     6dd5 <fwp_closure_drop+0x85>
    6db8:	3c 01                	cmp    $0x1,%al
    6dba:	74 24                	je     6de0 <fwp_closure_drop+0x90>
    6dbc:	3c ff                	cmp    $0xff,%al
    6dbe:	74 48                	je     6e08 <fwp_closure_drop+0xb8>
    6dc0:	83 e8 01             	sub    $0x1,%eax
    6dc3:	88 02                	mov    %al,(%rdx)
    6dc5:	c3                   	ret
    6dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dcd:	00 00 00 
    6dd0:	66 85 c0             	test   %ax,%ax
    6dd3:	74 dc                	je     6db1 <fwp_closure_drop+0x61>
    6dd5:	c3                   	ret
    6dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ddd:	00 00 00 
    6de0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6de7:	ff ff 
    6de9:	48 85 c0             	test   %rax,%rax
    6dec:	74 12                	je     6e00 <fwp_closure_drop+0xb0>
    6dee:	48 89 fe             	mov    %rdi,%rsi
    6df1:	48 89 c7             	mov    %rax,%rdi
    6df4:	e9 07 d4 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e00:	e9 ab d5 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6e05:	0f 1f 00             	nopl   (%rax)
    6e08:	48 89 d0             	mov    %rdx,%rax
    6e0b:	48 8d 35 6e c9 01 00 	lea    0x1c96e(%rip),%rsi        # 23780 <fwp_heap>
    6e12:	48 83 ec 18          	sub    $0x18,%rsp
    6e16:	48 c1 e8 11          	shr    $0x11,%rax
    6e1a:	48 31 d0             	xor    %rdx,%rax
    6e1d:	48 89 c1             	mov    %rax,%rcx
    6e20:	48 c1 e9 09          	shr    $0x9,%rcx
    6e24:	48 31 c8             	xor    %rcx,%rax
    6e27:	0f b6 c8             	movzbl %al,%ecx
    6e2a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6e31:	00 
    6e32:	48 85 c0             	test   %rax,%rax
    6e35:	75 12                	jne    6e49 <fwp_closure_drop+0xf9>
    6e37:	eb 49                	jmp    6e82 <fwp_closure_drop+0x132>
    6e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	74 39                	je     6e82 <fwp_closure_drop+0x132>
    6e49:	48 89 c1             	mov    %rax,%rcx
    6e4c:	48 39 10             	cmp    %rdx,(%rax)
    6e4f:	75 ef                	jne    6e40 <fwp_closure_drop+0xf0>
    6e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e64:	74 05                	je     6e6b <fwp_closure_drop+0x11b>
    6e66:	48 83 c4 18          	add    $0x18,%rsp
    6e6a:	c3                   	ret
    6e6b:	48 89 d7             	mov    %rdx,%rdi
    6e6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e73:	e8 98 e4 ff ff       	call   5310 <fwp_rc_forget_slot>
    6e78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e80:	eb e4                	jmp    6e66 <fwp_closure_drop+0x116>
    6e82:	48 8d 3d 0f 89 00 00 	lea    0x890f(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    6e89:	e8 12 d3 ff ff       	call   41a0 <fwp_trap>
    6e8e:	66 90                	xchg   %ax,%ax

0000000000006e90 <fwp_owned_tape_release>:
    6e90:	48 85 ff             	test   %rdi,%rdi
    6e93:	0f 84 f7 00 00 00    	je     6f90 <fwp_owned_tape_release+0x100>
    6e99:	41 54                	push   %r12
    6e9b:	55                   	push   %rbp
    6e9c:	53                   	push   %rbx
    6e9d:	48 8b 07             	mov    (%rdi),%rax
    6ea0:	48 85 c0             	test   %rax,%rax
    6ea3:	74 08                	je     6ead <fwp_owned_tape_release+0x1d>
    6ea5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ea9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ead:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6eb1:	48 85 d2             	test   %rdx,%rdx
    6eb4:	74 03                	je     6eb9 <fwp_owned_tape_release+0x29>
    6eb6:	48 89 02             	mov    %rax,(%rdx)
    6eb9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ebd:	48 89 fb             	mov    %rdi,%rbx
    6ec0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	0f 84 89 00 00 00    	je     6f56 <fwp_owned_tape_release+0xc6>
    6ecd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6ed1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6ed5:	7e 47                	jle    6f1e <fwp_owned_tape_release+0x8e>
    6ed7:	31 ed                	xor    %ebp,%ebp
    6ed9:	eb 0d                	jmp    6ee8 <fwp_owned_tape_release+0x58>
    6edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ee0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ee4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ee8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6eec:	49 89 ec             	mov    %rbp,%r12
    6eef:	48 83 c5 01          	add    $0x1,%rbp
    6ef3:	49 c1 e4 04          	shl    $0x4,%r12
    6ef7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6efb:	ff d0                	call   *%rax
    6efd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6f06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f0a:	ff 50 68             	call   *0x68(%rax)
    6f0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6f11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6f15:	48 39 e8             	cmp    %rbp,%rax
    6f18:	7f c6                	jg     6ee0 <fwp_owned_tape_release+0x50>
    6f1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f1e:	31 ed                	xor    %ebp,%ebp
    6f20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6f25:	7e 28                	jle    6f4f <fwp_owned_tape_release+0xbf>
    6f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f2e:	00 00 
    6f30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6f34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6f38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6f3c:	74 07                	je     6f45 <fwp_owned_tape_release+0xb5>
    6f3e:	ff 52 68             	call   *0x68(%rdx)
    6f41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f45:	48 83 c5 01          	add    $0x1,%rbp
    6f49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6f4d:	7f e1                	jg     6f30 <fwp_owned_tape_release+0xa0>
    6f4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f53:	ff 52 68             	call   *0x68(%rdx)
    6f56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6f5a:	e8 f1 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6f63:	e8 e8 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6f6c:	e8 df fd ff ff       	call   6d50 <fwp_closure_drop>
    6f71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6f75:	e8 d6 e5 ff ff       	call   5550 <fwp_mem_free>
    6f7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6f7e:	e8 cd e5 ff ff       	call   5550 <fwp_mem_free>
    6f83:	48 89 df             	mov    %rbx,%rdi
    6f86:	5b                   	pop    %rbx
    6f87:	5d                   	pop    %rbp
    6f88:	41 5c                	pop    %r12
    6f8a:	e9 c1 e5 ff ff       	jmp    5550 <fwp_mem_free>
    6f8f:	90                   	nop
    6f90:	c3                   	ret
    6f91:	0f 1f 40 00          	nopl   0x0(%rax)
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 

0000000000006fa0 <fwp_tape_finish>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	41 56                	push   %r14
    6fa6:	48 8d 3d 13 c1 01 00 	lea    0x1c113(%rip),%rdi        # 230c0 <fwp_tape_workspace>
    6fad:	41 55                	push   %r13
    6faf:	41 54                	push   %r12
    6fb1:	55                   	push   %rbp
    6fb2:	53                   	push   %rbx
    6fb3:	e8 b8 cf ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6fb8:	48 83 3d 48 c1 01 00 	cmpq   $0x0,0x1c148(%rip)        # 23108 <fwp_ntapes>
    6fbf:	00 
    6fc0:	48 c7 05 dd c0 01 00 	movq   $0x0,0x1c0dd(%rip)        # 230a8 <fwp_tape_cached_bytes>
    6fc7:	00 00 00 00 
    6fcb:	7e 68                	jle    7035 <fwp_tape_finish+0x95>
    6fcd:	45 31 e4             	xor    %r12d,%r12d
    6fd0:	31 ed                	xor    %ebp,%ebp
    6fd2:	0f 1f 00             	nopl   (%rax)
    6fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fdc:	00 00 00 00 
    6fe0:	48 8b 1d 29 c1 01 00 	mov    0x1c129(%rip),%rbx        # 23110 <fwp_tapes>
    6fe7:	48 83 c5 01          	add    $0x1,%rbp
    6feb:	4c 01 e3             	add    %r12,%rbx
    6fee:	49 83 c4 68          	add    $0x68,%r12
    6ff2:	48 89 df             	mov    %rbx,%rdi
    6ff5:	e8 06 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ffa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6ffe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7002:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7006:	e8 b5 c3 ff ff       	call   33c0 <free@plt>
    700b:	4c 89 f7             	mov    %r14,%rdi
    700e:	e8 ad c3 ff ff       	call   33c0 <free@plt>
    7013:	4c 89 ef             	mov    %r13,%rdi
    7016:	e8 a5 c3 ff ff       	call   33c0 <free@plt>
    701b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    701f:	e8 6c fe ff ff       	call   6e90 <fwp_owned_tape_release>
    7024:	48 39 2d dd c0 01 00 	cmp    %rbp,0x1c0dd(%rip)        # 23108 <fwp_ntapes>
    702b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7032:	00 
    7033:	7f ab                	jg     6fe0 <fwp_tape_finish+0x40>
    7035:	48 8b 3d d4 c0 01 00 	mov    0x1c0d4(%rip),%rdi        # 23110 <fwp_tapes>
    703c:	e8 7f c3 ff ff       	call   33c0 <free@plt>
    7041:	5b                   	pop    %rbx
    7042:	5d                   	pop    %rbp
    7043:	48 c7 05 c2 c0 01 00 	movq   $0x0,0x1c0c2(%rip)        # 23110 <fwp_tapes>
    704a:	00 00 00 00 
    704e:	48 c7 05 a7 c0 01 00 	movq   $0x0,0x1c0a7(%rip)        # 23100 <fwp_tapes_cap>
    7055:	00 00 00 00 
    7059:	41 5c                	pop    %r12
    705b:	48 c7 05 a2 c0 01 00 	movq   $0x0,0x1c0a2(%rip)        # 23108 <fwp_ntapes>
    7062:	00 00 00 00 
    7066:	41 5d                	pop    %r13
    7068:	48 c7 05 85 c0 01 00 	movq   $0x0,0x1c085(%rip)        # 230f8 <fwp_tape_next_slot>
    706f:	00 00 00 00 
    7073:	41 5e                	pop    %r14
    7075:	c3                   	ret
    7076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    707d:	00 00 00 

0000000000007080 <fwp_tape_scope_release>:
    7080:	f3 0f 1e fa          	endbr64
    7084:	41 55                	push   %r13
    7086:	41 54                	push   %r12
    7088:	55                   	push   %rbp
    7089:	53                   	push   %rbx
    708a:	48 83 ec 58          	sub    $0x58,%rsp
    708e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7095:	00 00 
    7097:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    709c:	48 63 07             	movslq (%rdi),%rax
    709f:	85 c0                	test   %eax,%eax
    70a1:	0f 88 05 01 00 00    	js     71ac <fwp_tape_scope_release+0x12c>
    70a7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    70ae:	ec c4 4e 
    70b1:	48 89 fb             	mov    %rdi,%rbx
    70b4:	eb 3c                	jmp    70f2 <fwp_tape_scope_release+0x72>
    70b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70bd:	00 00 00 
    70c0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    70c5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    70c9:	e8 f2 c2 ff ff       	call   33c0 <free@plt>
    70ce:	48 8b 3c 24          	mov    (%rsp),%rdi
    70d2:	e8 e9 c2 ff ff       	call   33c0 <free@plt>
    70d7:	4c 89 ef             	mov    %r13,%rdi
    70da:	e8 e1 c2 ff ff       	call   33c0 <free@plt>
    70df:	4c 89 e7             	mov    %r12,%rdi
    70e2:	e8 a9 fd ff ff       	call   6e90 <fwp_owned_tape_release>
    70e7:	48 63 03             	movslq (%rbx),%rax
    70ea:	85 c0                	test   %eax,%eax
    70ec:	0f 88 ba 00 00 00    	js     71ac <fwp_tape_scope_release+0x12c>
    70f2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    70f6:	48 8b 35 13 c0 01 00 	mov    0x1c013(%rip),%rsi        # 23110 <fwp_tapes>
    70fd:	4c 01 c6             	add    %r8,%rsi
    7100:	48 89 f7             	mov    %rsi,%rdi
    7103:	e8 f8 ca ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7108:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    710d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7112:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7119:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    711d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7121:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7128:	00 
    7129:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    712e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7132:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7137:	66 0f ef d2          	pxor   %xmm2,%xmm2
    713b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7140:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7147:	00 
    7148:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    714f:	00 
    7150:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7157:	00 
    7158:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    715d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7162:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7166:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    716a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    716e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7174:	77 18                	ja     718e <fwp_tape_scope_release+0x10e>
    7176:	49 c1 f8 03          	sar    $0x3,%r8
    717a:	4c 0f af c5          	imul   %rbp,%r8
    717e:	4c 3b 05 73 bf 01 00 	cmp    0x1bf73(%rip),%r8        # 230f8 <fwp_tape_next_slot>
    7185:	7d 07                	jge    718e <fwp_tape_scope_release+0x10e>
    7187:	4c 89 05 6a bf 01 00 	mov    %r8,0x1bf6a(%rip)        # 230f8 <fwp_tape_next_slot>
    718e:	4d 85 e4             	test   %r12,%r12
    7191:	0f 85 29 ff ff ff    	jne    70c0 <fwp_tape_scope_release+0x40>
    7197:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    719c:	e8 8f dc ff ff       	call   4e30 <fwp_tape_buffers_release>
    71a1:	48 63 03             	movslq (%rbx),%rax
    71a4:	85 c0                	test   %eax,%eax
    71a6:	0f 89 46 ff ff ff    	jns    70f2 <fwp_tape_scope_release+0x72>
    71ac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    71b1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71b8:	00 00 
    71ba:	75 0b                	jne    71c7 <fwp_tape_scope_release+0x147>
    71bc:	48 83 c4 58          	add    $0x58,%rsp
    71c0:	5b                   	pop    %rbx
    71c1:	5d                   	pop    %rbp
    71c2:	41 5c                	pop    %r12
    71c4:	41 5d                	pop    %r13
    71c6:	c3                   	ret
    71c7:	e8 94 c2 ff ff       	call   3460 <__stack_chk_fail@plt>
    71cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000071d0 <fwp_task_dispose>:
    71d0:	53                   	push   %rbx
    71d1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    71d5:	0f 84 6b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    71db:	48 89 fb             	mov    %rdi,%rbx
    71de:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    71e3:	0f 85 5d c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    71e9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    71ed:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    71f4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    71fb:	00 
    71fc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7200:	48 85 ff             	test   %rdi,%rdi
    7203:	74 07                	je     720c <fwp_task_dispose+0x3c>
    7205:	48 85 c0             	test   %rax,%rax
    7208:	74 02                	je     720c <fwp_task_dispose+0x3c>
    720a:	ff d0                	call   *%rax
    720c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7213:	e8 38 e3 ff ff       	call   5550 <fwp_mem_free>
    7218:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    721f:	00 00 00 00 
    7223:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7227:	74 6f                	je     7298 <fwp_task_dispose+0xc8>
    7229:	48 8b 15 28 d9 01 00 	mov    0x1d928(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7230:	48 89 d8             	mov    %rbx,%rax
    7233:	48 2b 05 f6 d8 01 00 	sub    0x1d8f6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    723a:	48 c1 e2 10          	shl    $0x10,%rdx
    723e:	48 39 d0             	cmp    %rdx,%rax
    7241:	73 4c                	jae    728f <fwp_task_dispose+0xbf>
    7243:	48 89 c2             	mov    %rax,%rdx
    7246:	48 c1 ea 10          	shr    $0x10,%rdx
    724a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    724e:	48 8b 15 23 d9 01 00 	mov    0x1d923(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7255:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7259:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    725d:	48 85 c9             	test   %rcx,%rcx
    7260:	74 2d                	je     728f <fwp_task_dispose+0xbf>
    7262:	0f b6 32             	movzbl (%rdx),%esi
    7265:	40 80 fe 02          	cmp    $0x2,%sil
    7269:	74 3d                	je     72a8 <fwp_task_dispose+0xd8>
    726b:	40 80 fe 01          	cmp    $0x1,%sil
    726f:	75 1e                	jne    728f <fwp_task_dispose+0xbf>
    7271:	8b 72 18             	mov    0x18(%rdx),%esi
    7274:	0f b7 c0             	movzwl %ax,%eax
    7277:	8b 52 1c             	mov    0x1c(%rdx),%edx
    727a:	48 0f af c6          	imul   %rsi,%rax
    727e:	48 c1 e8 20          	shr    $0x20,%rax
    7282:	48 39 d0             	cmp    %rdx,%rax
    7285:	73 08                	jae    728f <fwp_task_dispose+0xbf>
    7287:	48 01 c1             	add    %rax,%rcx
    728a:	80 39 01             	cmpb   $0x1,(%rcx)
    728d:	74 09                	je     7298 <fwp_task_dispose+0xc8>
    728f:	5b                   	pop    %rbx
    7290:	c3                   	ret
    7291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7298:	48 89 df             	mov    %rbx,%rdi
    729b:	5b                   	pop    %rbx
    729c:	e9 af e2 ff ff       	jmp    5550 <fwp_mem_free>
    72a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72a8:	66 85 c0             	test   %ax,%ax
    72ab:	74 dd                	je     728a <fwp_task_dispose+0xba>
    72ad:	5b                   	pop    %rbx
    72ae:	c3                   	ret
    72af:	90                   	nop

00000000000072b0 <fwp_free_zombie>:
    72b0:	48 8b 15 99 c4 01 00 	mov    0x1c499(%rip),%rdx        # 23750 <fwp_zombie>
    72b7:	48 85 d2             	test   %rdx,%rdx
    72ba:	0f 84 98 00 00 00    	je     7358 <fwp_free_zombie+0xa8>
    72c0:	48 3b 15 99 c4 01 00 	cmp    0x1c499(%rip),%rdx        # 23760 <fwp_cur>
    72c7:	0f 84 8b 00 00 00    	je     7358 <fwp_free_zombie+0xa8>
    72cd:	48 83 ec 18          	sub    $0x18,%rsp
    72d1:	48 63 05 54 be 01 00 	movslq 0x1be54(%rip),%rax        # 2312c <fwp_stack_pool_n>
    72d8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    72dc:	83 f8 3f             	cmp    $0x3f,%eax
    72df:	7f 7f                	jg     7360 <fwp_free_zombie+0xb0>
    72e1:	8d 48 01             	lea    0x1(%rax),%ecx
    72e4:	89 0d 42 be 01 00    	mov    %ecx,0x1be42(%rip)        # 2312c <fwp_stack_pool_n>
    72ea:	48 8d 0d 4f be 01 00 	lea    0x1be4f(%rip),%rcx        # 23140 <fwp_stack_pool>
    72f1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    72f5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    72fc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7300:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7307:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    730b:	48 85 c9             	test   %rcx,%rcx
    730e:	0f 84 fc 00 00 00    	je     7410 <fwp_free_zombie+0x160>
    7314:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    731b:	48 85 c0             	test   %rax,%rax
    731e:	74 07                	je     7327 <fwp_free_zombie+0x77>
    7320:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7327:	8b 42 5c             	mov    0x5c(%rdx),%eax
    732a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    732e:	48 c7 05 17 c4 01 00 	movq   $0x0,0x1c417(%rip)        # 23750 <fwp_zombie>
    7335:	00 00 00 00 
    7339:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7340:	85 c0                	test   %eax,%eax
    7342:	74 34                	je     7378 <fwp_free_zombie+0xc8>
    7344:	83 f8 01             	cmp    $0x1,%eax
    7347:	0f 84 b3 00 00 00    	je     7400 <fwp_free_zombie+0x150>
    734d:	48 83 c4 18          	add    $0x18,%rsp
    7351:	c3                   	ret
    7352:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7358:	c3                   	ret
    7359:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7360:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7364:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7369:	e8 72 c2 ff ff       	call   35e0 <munmap@plt>
    736e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7373:	eb 80                	jmp    72f5 <fwp_free_zombie+0x45>
    7375:	0f 1f 00             	nopl   (%rax)
    7378:	48 8b 0d d9 d7 01 00 	mov    0x1d7d9(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    737f:	48 89 d0             	mov    %rdx,%rax
    7382:	48 2b 05 a7 d7 01 00 	sub    0x1d7a7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7389:	48 c1 e1 10          	shl    $0x10,%rcx
    738d:	48 39 c8             	cmp    %rcx,%rax
    7390:	73 bb                	jae    734d <fwp_free_zombie+0x9d>
    7392:	48 89 c1             	mov    %rax,%rcx
    7395:	48 c1 e9 10          	shr    $0x10,%rcx
    7399:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    739d:	48 8b 0d d4 d7 01 00 	mov    0x1d7d4(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    73a4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    73a8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    73ac:	48 85 c9             	test   %rcx,%rcx
    73af:	74 9c                	je     734d <fwp_free_zombie+0x9d>
    73b1:	0f b6 3e             	movzbl (%rsi),%edi
    73b4:	40 80 ff 02          	cmp    $0x2,%dil
    73b8:	74 66                	je     7420 <fwp_free_zombie+0x170>
    73ba:	40 80 ff 01          	cmp    $0x1,%dil
    73be:	75 8d                	jne    734d <fwp_free_zombie+0x9d>
    73c0:	8b 7e 18             	mov    0x18(%rsi),%edi
    73c3:	0f b7 c0             	movzwl %ax,%eax
    73c6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    73c9:	48 0f af c7          	imul   %rdi,%rax
    73cd:	48 c1 e8 20          	shr    $0x20,%rax
    73d1:	48 39 f0             	cmp    %rsi,%rax
    73d4:	0f 83 73 ff ff ff    	jae    734d <fwp_free_zombie+0x9d>
    73da:	48 01 c1             	add    %rax,%rcx
    73dd:	0f b6 01             	movzbl (%rcx),%eax
    73e0:	84 c0                	test   %al,%al
    73e2:	0f 84 65 ff ff ff    	je     734d <fwp_free_zombie+0x9d>
    73e8:	3c 01                	cmp    $0x1,%al
    73ea:	74 14                	je     7400 <fwp_free_zombie+0x150>
    73ec:	3c ff                	cmp    $0xff,%al
    73ee:	74 3b                	je     742b <fwp_free_zombie+0x17b>
    73f0:	83 e8 01             	sub    $0x1,%eax
    73f3:	88 01                	mov    %al,(%rcx)
    73f5:	e9 53 ff ff ff       	jmp    734d <fwp_free_zombie+0x9d>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7400:	48 89 d7             	mov    %rdx,%rdi
    7403:	48 83 c4 18          	add    $0x18,%rsp
    7407:	e9 c4 fd ff ff       	jmp    71d0 <fwp_task_dispose>
    740c:	0f 1f 40 00          	nopl   0x0(%rax)
    7410:	48 89 05 11 c3 01 00 	mov    %rax,0x1c311(%rip)        # 23728 <fwp_tasks_active>
    7417:	e9 ff fe ff ff       	jmp    731b <fwp_free_zombie+0x6b>
    741c:	0f 1f 40 00          	nopl   0x0(%rax)
    7420:	66 85 c0             	test   %ax,%ax
    7423:	0f 85 24 ff ff ff    	jne    734d <fwp_free_zombie+0x9d>
    7429:	eb b2                	jmp    73dd <fwp_free_zombie+0x12d>
    742b:	48 89 ca             	mov    %rcx,%rdx
    742e:	48 8d 35 4b c3 01 00 	lea    0x1c34b(%rip),%rsi        # 23780 <fwp_heap>
    7435:	48 c1 ea 11          	shr    $0x11,%rdx
    7439:	48 31 ca             	xor    %rcx,%rdx
    743c:	48 89 d0             	mov    %rdx,%rax
    743f:	48 c1 e8 09          	shr    $0x9,%rax
    7443:	48 31 c2             	xor    %rax,%rdx
    7446:	0f b6 d2             	movzbl %dl,%edx
    7449:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7450:	00 
    7451:	48 85 c0             	test   %rax,%rax
    7454:	75 13                	jne    7469 <fwp_free_zombie+0x1b9>
    7456:	eb 4c                	jmp    74a4 <fwp_free_zombie+0x1f4>
    7458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    745f:	00 
    7460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7464:	48 85 c0             	test   %rax,%rax
    7467:	74 3b                	je     74a4 <fwp_free_zombie+0x1f4>
    7469:	48 89 c2             	mov    %rax,%rdx
    746c:	48 39 08             	cmp    %rcx,(%rax)
    746f:	75 ef                	jne    7460 <fwp_free_zombie+0x1b0>
    7471:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7475:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7479:	48 89 50 08          	mov    %rdx,0x8(%rax)
    747d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7484:	0f 85 c3 fe ff ff    	jne    734d <fwp_free_zombie+0x9d>
    748a:	48 89 cf             	mov    %rcx,%rdi
    748d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7492:	e8 79 de ff ff       	call   5310 <fwp_rc_forget_slot>
    7497:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    749c:	c6 01 fe             	movb   $0xfe,(%rcx)
    749f:	e9 a9 fe ff ff       	jmp    734d <fwp_free_zombie+0x9d>
    74a4:	48 8d 3d ed 82 00 00 	lea    0x82ed(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    74ab:	e8 f0 cc ff ff       	call   41a0 <fwp_trap>

00000000000074b0 <fwp_block>:
    74b0:	48 83 ec 08          	sub    $0x8,%rsp
    74b4:	48 8b 05 8d c2 01 00 	mov    0x1c28d(%rip),%rax        # 23748 <fwp_ready_head>
    74bb:	48 85 c0             	test   %rax,%rax
    74be:	0f 84 1c 01 00 00    	je     75e0 <fwp_block+0x130>
    74c4:	90                   	nop
    74c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74cc:	00 00 00 00 
    74d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    74d7:	48 89 15 6a c2 01 00 	mov    %rdx,0x1c26a(%rip)        # 23748 <fwp_ready_head>
    74de:	48 85 d2             	test   %rdx,%rdx
    74e1:	0f 84 19 01 00 00    	je     7600 <fwp_block+0x150>
    74e7:	48 8b 15 72 c2 01 00 	mov    0x1c272(%rip),%rdx        # 23760 <fwp_cur>
    74ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    74f2:	48 39 c2             	cmp    %rax,%rdx
    74f5:	0f 84 d5 00 00 00    	je     75d0 <fwp_block+0x120>
    74fb:	48 8b 0d e6 de 01 00 	mov    0x1dee6(%rip),%rcx        # 253e8 <fwp_state_owners>
    7502:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7506:	48 89 05 53 c2 01 00 	mov    %rax,0x1c253(%rip)        # 23760 <fwp_cur>
    750d:	f3 0f 7e 05 fb de 01 	movq   0x1defb(%rip),%xmm0        # 25410 <fwp_foreign_callbacks>
    7514:	00 
    7515:	0f 16 05 e4 de 01 00 	movhps 0x1dee4(%rip),%xmm0        # 25400 <fwp_state>
    751c:	f3 0f 7e 0d e4 de 01 	movq   0x1dee4(%rip),%xmm1        # 25408 <fwp_handlers>
    7523:	00 
    7524:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    752b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7532:	0f 16 0d df de 01 00 	movhps 0x1dedf(%rip),%xmm1        # 25418 <fwp_cleanups>
    7539:	f3 0f 7e 05 b7 de 01 	movq   0x1deb7(%rip),%xmm0        # 253f8 <fwp_state_len>
    7540:	00 
    7541:	0f 16 05 a8 de 01 00 	movhps 0x1dea8(%rip),%xmm0        # 253f0 <fwp_state_cap>
    7548:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    754f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7556:	48 8b 70 08          	mov    0x8(%rax),%rsi
    755a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7561:	48 89 0d a0 de 01 00 	mov    %rcx,0x1dea0(%rip)        # 25408 <fwp_handlers>
    7568:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    756f:	48 89 0d a2 de 01 00 	mov    %rcx,0x1dea2(%rip)        # 25418 <fwp_cleanups>
    7576:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    757d:	48 89 0d 8c de 01 00 	mov    %rcx,0x1de8c(%rip)        # 25410 <fwp_foreign_callbacks>
    7584:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    758b:	48 89 0d 6e de 01 00 	mov    %rcx,0x1de6e(%rip)        # 25400 <fwp_state>
    7592:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7599:	48 89 0d 58 de 01 00 	mov    %rcx,0x1de58(%rip)        # 253f8 <fwp_state_len>
    75a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    75a7:	48 89 0d 42 de 01 00 	mov    %rcx,0x1de42(%rip)        # 253f0 <fwp_state_cap>
    75ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    75b5:	48 89 0d 2c de 01 00 	mov    %rcx,0x1de2c(%rip)        # 253e8 <fwp_state_owners>
    75bc:	e8 cf be ff ff       	call   3490 <swapcontext@plt>
    75c1:	f3 0f 1e fa          	endbr64
    75c5:	e8 e6 fc ff ff       	call   72b0 <fwp_free_zombie>
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	8b 05 52 bb 01 00    	mov    0x1bb52(%rip),%eax        # 23128 <fwp_slice>
    75d6:	85 c0                	test   %eax,%eax
    75d8:	74 36                	je     7610 <fwp_block+0x160>
    75da:	48 83 c4 08          	add    $0x8,%rsp
    75de:	c3                   	ret
    75df:	90                   	nop
    75e0:	e8 7b d9 ff ff       	call   4f60 <fwp_poll_events>
    75e5:	48 8b 05 5c c1 01 00 	mov    0x1c15c(%rip),%rax        # 23748 <fwp_ready_head>
    75ec:	48 85 c0             	test   %rax,%rax
    75ef:	0f 85 db fe ff ff    	jne    74d0 <fwp_block+0x20>
    75f5:	eb e9                	jmp    75e0 <fwp_block+0x130>
    75f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75fe:	00 00 
    7600:	48 c7 05 35 c1 01 00 	movq   $0x0,0x1c135(%rip)        # 23740 <fwp_ready_tail>
    7607:	00 00 00 00 
    760b:	e9 d7 fe ff ff       	jmp    74e7 <fwp_block+0x37>
    7610:	48 8d 3d 0a 7b 00 00 	lea    0x7b0a(%rip),%rdi        # f121 <_IO_stdin_used+0x121>
    7617:	e8 84 bd ff ff       	call   33a0 <getenv@plt>
    761c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7621:	48 85 c0             	test   %rax,%rax
    7624:	74 05                	je     762b <fwp_block+0x17b>
    7626:	80 38 00             	cmpb   $0x0,(%rax)
    7629:	75 0b                	jne    7636 <fwp_block+0x186>
    762b:	89 15 f7 ba 01 00    	mov    %edx,0x1baf7(%rip)        # 23128 <fwp_slice>
    7631:	48 83 c4 08          	add    $0x8,%rsp
    7635:	c3                   	ret
    7636:	ba 0a 00 00 00       	mov    $0xa,%edx
    763b:	31 f6                	xor    %esi,%esi
    763d:	48 89 c7             	mov    %rax,%rdi
    7640:	e8 0b bf ff ff       	call   3550 <strtoll@plt>
    7645:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7649:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7650:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7655:	0f 46 d0             	cmovbe %eax,%edx
    7658:	eb d1                	jmp    762b <fwp_block+0x17b>
    765a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007660 <fwp_drop4>:
    7660:	48 8b 15 f1 d4 01 00 	mov    0x1d4f1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7667:	48 89 f8             	mov    %rdi,%rax
    766a:	48 2b 05 bf d4 01 00 	sub    0x1d4bf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7671:	48 c1 e2 10          	shl    $0x10,%rdx
    7675:	48 39 d0             	cmp    %rdx,%rax
    7678:	0f 83 52 01 00 00    	jae    77d0 <fwp_drop4+0x170>
    767e:	48 83 ec 18          	sub    $0x18,%rsp
    7682:	4c 8d 05 f7 c0 01 00 	lea    0x1c0f7(%rip),%r8        # 23780 <fwp_heap>
    7689:	48 89 c2             	mov    %rax,%rdx
    768c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7693:	48 c1 ea 10          	shr    $0x10,%rdx
    7697:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    769b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    769f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    76a3:	48 85 d2             	test   %rdx,%rdx
    76a6:	74 46                	je     76ee <fwp_drop4+0x8e>
    76a8:	44 0f b6 09          	movzbl (%rcx),%r9d
    76ac:	41 80 f9 02          	cmp    $0x2,%r9b
    76b0:	0f 84 ca 00 00 00    	je     7780 <fwp_drop4+0x120>
    76b6:	41 80 f9 01          	cmp    $0x1,%r9b
    76ba:	75 32                	jne    76ee <fwp_drop4+0x8e>
    76bc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    76c0:	0f b7 c0             	movzwl %ax,%eax
    76c3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    76c6:	49 0f af c1          	imul   %r9,%rax
    76ca:	48 c1 e8 20          	shr    $0x20,%rax
    76ce:	48 39 c8             	cmp    %rcx,%rax
    76d1:	73 1b                	jae    76ee <fwp_drop4+0x8e>
    76d3:	48 01 c2             	add    %rax,%rdx
    76d6:	0f b6 02             	movzbl (%rdx),%eax
    76d9:	84 c0                	test   %al,%al
    76db:	74 11                	je     76ee <fwp_drop4+0x8e>
    76dd:	3c 01                	cmp    $0x1,%al
    76df:	74 17                	je     76f8 <fwp_drop4+0x98>
    76e1:	3c ff                	cmp    $0xff,%al
    76e3:	0f 84 ef 00 00 00    	je     77d8 <fwp_drop4+0x178>
    76e9:	83 e8 01             	sub    $0x1,%eax
    76ec:	88 02                	mov    %al,(%rdx)
    76ee:	48 83 c4 18          	add    $0x18,%rsp
    76f2:	c3                   	ret
    76f3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    76f8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    76fc:	0f 88 8e 00 00 00    	js     7790 <fwp_drop4+0x130>
    7702:	48 8b 15 4f d4 01 00 	mov    0x1d44f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7709:	48 89 f8             	mov    %rdi,%rax
    770c:	48 2b 05 1d d4 01 00 	sub    0x1d41d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7713:	48 c1 e2 10          	shl    $0x10,%rdx
    7717:	48 39 d0             	cmp    %rdx,%rax
    771a:	73 d2                	jae    76ee <fwp_drop4+0x8e>
    771c:	48 89 c2             	mov    %rax,%rdx
    771f:	48 c1 ea 10          	shr    $0x10,%rdx
    7723:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7727:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    772b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    772f:	48 85 c9             	test   %rcx,%rcx
    7732:	74 ba                	je     76ee <fwp_drop4+0x8e>
    7734:	0f b6 32             	movzbl (%rdx),%esi
    7737:	40 80 fe 02          	cmp    $0x2,%sil
    773b:	74 33                	je     7770 <fwp_drop4+0x110>
    773d:	40 80 fe 01          	cmp    $0x1,%sil
    7741:	75 ab                	jne    76ee <fwp_drop4+0x8e>
    7743:	8b 72 18             	mov    0x18(%rdx),%esi
    7746:	0f b7 c0             	movzwl %ax,%eax
    7749:	8b 52 1c             	mov    0x1c(%rdx),%edx
    774c:	48 0f af c6          	imul   %rsi,%rax
    7750:	48 c1 e8 20          	shr    $0x20,%rax
    7754:	48 39 d0             	cmp    %rdx,%rax
    7757:	73 95                	jae    76ee <fwp_drop4+0x8e>
    7759:	48 01 c1             	add    %rax,%rcx
    775c:	80 39 01             	cmpb   $0x1,(%rcx)
    775f:	75 8d                	jne    76ee <fwp_drop4+0x8e>
    7761:	48 83 c4 18          	add    $0x18,%rsp
    7765:	e9 e6 dd ff ff       	jmp    5550 <fwp_mem_free>
    776a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7770:	66 85 c0             	test   %ax,%ax
    7773:	74 e7                	je     775c <fwp_drop4+0xfc>
    7775:	48 83 c4 18          	add    $0x18,%rsp
    7779:	c3                   	ret
    777a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7780:	66 85 c0             	test   %ax,%ax
    7783:	0f 84 4d ff ff ff    	je     76d6 <fwp_drop4+0x76>
    7789:	48 83 c4 18          	add    $0x18,%rsp
    778d:	c3                   	ret
    778e:	66 90                	xchg   %ax,%ax
    7790:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7794:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7799:	e8 b2 ef ff ff       	call   6750 <fwp_rc_free_arr>
    779e:	4c 8d 05 db bf 01 00 	lea    0x1bfdb(%rip),%r8        # 23780 <fwp_heap>
    77a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    77aa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    77b1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    77b8:	48 c1 e2 10          	shl    $0x10,%rdx
    77bc:	48 39 d0             	cmp    %rdx,%rax
    77bf:	0f 83 29 ff ff ff    	jae    76ee <fwp_drop4+0x8e>
    77c5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    77ca:	e9 ba fe ff ff       	jmp    7689 <fwp_drop4+0x29>
    77cf:	90                   	nop
    77d0:	c3                   	ret
    77d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77d8:	48 89 d0             	mov    %rdx,%rax
    77db:	48 c1 e8 11          	shr    $0x11,%rax
    77df:	48 31 d0             	xor    %rdx,%rax
    77e2:	48 89 c1             	mov    %rax,%rcx
    77e5:	48 c1 e9 09          	shr    $0x9,%rcx
    77e9:	48 31 c8             	xor    %rcx,%rax
    77ec:	0f b6 c8             	movzbl %al,%ecx
    77ef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    77f6:	00 
    77f7:	48 85 c0             	test   %rax,%rax
    77fa:	75 0d                	jne    7809 <fwp_drop4+0x1a9>
    77fc:	eb 46                	jmp    7844 <fwp_drop4+0x1e4>
    77fe:	66 90                	xchg   %ax,%ax
    7800:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7804:	48 85 c0             	test   %rax,%rax
    7807:	74 3b                	je     7844 <fwp_drop4+0x1e4>
    7809:	48 89 c1             	mov    %rax,%rcx
    780c:	48 39 10             	cmp    %rdx,(%rax)
    780f:	75 ef                	jne    7800 <fwp_drop4+0x1a0>
    7811:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7815:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7819:	48 89 48 08          	mov    %rcx,0x8(%rax)
    781d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7824:	0f 85 c4 fe ff ff    	jne    76ee <fwp_drop4+0x8e>
    782a:	48 89 d7             	mov    %rdx,%rdi
    782d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7832:	e8 d9 da ff ff       	call   5310 <fwp_rc_forget_slot>
    7837:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    783c:	c6 02 fe             	movb   $0xfe,(%rdx)
    783f:	e9 aa fe ff ff       	jmp    76ee <fwp_drop4+0x8e>
    7844:	48 8d 3d 4d 7f 00 00 	lea    0x7f4d(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    784b:	e8 50 c9 ff ff       	call   41a0 <fwp_trap>

0000000000007850 <fwp_caps161>:
    7850:	f3 0f 1e fa          	endbr64
    7854:	85 f6                	test   %esi,%esi
    7856:	74 08                	je     7860 <fwp_caps161+0x10>
    7858:	c3                   	ret
    7859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7860:	48 8b 15 f1 d2 01 00 	mov    0x1d2f1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7867:	48 89 f8             	mov    %rdi,%rax
    786a:	48 2b 05 bf d2 01 00 	sub    0x1d2bf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7871:	48 c1 e2 10          	shl    $0x10,%rdx
    7875:	48 39 d0             	cmp    %rdx,%rax
    7878:	73 de                	jae    7858 <fwp_caps161+0x8>
    787a:	48 89 c2             	mov    %rax,%rdx
    787d:	48 c1 ea 10          	shr    $0x10,%rdx
    7881:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7885:	48 8b 15 ec d2 01 00 	mov    0x1d2ec(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    788c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7890:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7894:	48 85 c9             	test   %rcx,%rcx
    7897:	74 bf                	je     7858 <fwp_caps161+0x8>
    7899:	0f b6 32             	movzbl (%rdx),%esi
    789c:	40 80 fe 02          	cmp    $0x2,%sil
    78a0:	74 2e                	je     78d0 <fwp_caps161+0x80>
    78a2:	40 80 fe 01          	cmp    $0x1,%sil
    78a6:	75 b0                	jne    7858 <fwp_caps161+0x8>
    78a8:	8b 72 18             	mov    0x18(%rdx),%esi
    78ab:	0f b7 c0             	movzwl %ax,%eax
    78ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78b1:	48 0f af c6          	imul   %rsi,%rax
    78b5:	48 c1 e8 20          	shr    $0x20,%rax
    78b9:	48 39 d0             	cmp    %rdx,%rax
    78bc:	73 9a                	jae    7858 <fwp_caps161+0x8>
    78be:	48 01 c1             	add    %rax,%rcx
    78c1:	80 39 01             	cmpb   $0x1,(%rcx)
    78c4:	75 92                	jne    7858 <fwp_caps161+0x8>
    78c6:	e9 85 dc ff ff       	jmp    5550 <fwp_mem_free>
    78cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78d0:	66 85 c0             	test   %ax,%ax
    78d3:	74 ec                	je     78c1 <fwp_caps161+0x71>
    78d5:	c3                   	ret
    78d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    78dd:	00 00 00 

00000000000078e0 <fwp_args12>:
    78e0:	f3 0f 1e fa          	endbr64
    78e4:	85 d2                	test   %edx,%edx
    78e6:	74 04                	je     78ec <fwp_args12+0xc>
    78e8:	85 f6                	test   %esi,%esi
    78ea:	74 04                	je     78f0 <fwp_args12+0x10>
    78ec:	c3                   	ret
    78ed:	0f 1f 00             	nopl   (%rax)
    78f0:	48 8b 15 61 d2 01 00 	mov    0x1d261(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    78f7:	48 8b 07             	mov    (%rdi),%rax
    78fa:	48 2b 05 2f d2 01 00 	sub    0x1d22f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7901:	48 c1 e2 10          	shl    $0x10,%rdx
    7905:	48 39 d0             	cmp    %rdx,%rax
    7908:	73 e2                	jae    78ec <fwp_args12+0xc>
    790a:	48 89 c2             	mov    %rax,%rdx
    790d:	48 c1 ea 10          	shr    $0x10,%rdx
    7911:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7915:	48 8b 15 5c d2 01 00 	mov    0x1d25c(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    791c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7920:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7924:	48 85 ff             	test   %rdi,%rdi
    7927:	74 c3                	je     78ec <fwp_args12+0xc>
    7929:	0f b6 0a             	movzbl (%rdx),%ecx
    792c:	80 f9 02             	cmp    $0x2,%cl
    792f:	74 2f                	je     7960 <fwp_args12+0x80>
    7931:	80 f9 01             	cmp    $0x1,%cl
    7934:	75 b6                	jne    78ec <fwp_args12+0xc>
    7936:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7939:	0f b7 c0             	movzwl %ax,%eax
    793c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    793f:	48 0f af c1          	imul   %rcx,%rax
    7943:	48 c1 e8 20          	shr    $0x20,%rax
    7947:	48 39 d0             	cmp    %rdx,%rax
    794a:	73 a0                	jae    78ec <fwp_args12+0xc>
    794c:	48 01 c7             	add    %rax,%rdi
    794f:	0f b6 07             	movzbl (%rdi),%eax
    7952:	84 c0                	test   %al,%al
    7954:	74 96                	je     78ec <fwp_args12+0xc>
    7956:	3c fd                	cmp    $0xfd,%al
    7958:	77 0c                	ja     7966 <fwp_args12+0x86>
    795a:	83 c0 01             	add    $0x1,%eax
    795d:	88 07                	mov    %al,(%rdi)
    795f:	c3                   	ret
    7960:	66 85 c0             	test   %ax,%ax
    7963:	74 ea                	je     794f <fwp_args12+0x6f>
    7965:	c3                   	ret
    7966:	e9 85 d8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    796b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007970 <fwp_args23>:
    7970:	f3 0f 1e fa          	endbr64
    7974:	85 d2                	test   %edx,%edx
    7976:	74 04                	je     797c <fwp_args23+0xc>
    7978:	85 f6                	test   %esi,%esi
    797a:	74 04                	je     7980 <fwp_args23+0x10>
    797c:	c3                   	ret
    797d:	0f 1f 00             	nopl   (%rax)
    7980:	48 8b 15 d1 d1 01 00 	mov    0x1d1d1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7987:	48 8b 07             	mov    (%rdi),%rax
    798a:	48 2b 05 9f d1 01 00 	sub    0x1d19f(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7991:	48 c1 e2 10          	shl    $0x10,%rdx
    7995:	48 39 d0             	cmp    %rdx,%rax
    7998:	73 e2                	jae    797c <fwp_args23+0xc>
    799a:	48 89 c2             	mov    %rax,%rdx
    799d:	48 c1 ea 10          	shr    $0x10,%rdx
    79a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79a5:	48 8b 15 cc d1 01 00 	mov    0x1d1cc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    79ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79b0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    79b4:	48 85 ff             	test   %rdi,%rdi
    79b7:	74 c3                	je     797c <fwp_args23+0xc>
    79b9:	0f b6 0a             	movzbl (%rdx),%ecx
    79bc:	80 f9 02             	cmp    $0x2,%cl
    79bf:	74 2f                	je     79f0 <fwp_args23+0x80>
    79c1:	80 f9 01             	cmp    $0x1,%cl
    79c4:	75 b6                	jne    797c <fwp_args23+0xc>
    79c6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79c9:	0f b7 c0             	movzwl %ax,%eax
    79cc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79cf:	48 0f af c1          	imul   %rcx,%rax
    79d3:	48 c1 e8 20          	shr    $0x20,%rax
    79d7:	48 39 d0             	cmp    %rdx,%rax
    79da:	73 a0                	jae    797c <fwp_args23+0xc>
    79dc:	48 01 c7             	add    %rax,%rdi
    79df:	0f b6 07             	movzbl (%rdi),%eax
    79e2:	84 c0                	test   %al,%al
    79e4:	74 96                	je     797c <fwp_args23+0xc>
    79e6:	3c fd                	cmp    $0xfd,%al
    79e8:	77 0c                	ja     79f6 <fwp_args23+0x86>
    79ea:	83 c0 01             	add    $0x1,%eax
    79ed:	88 07                	mov    %al,(%rdi)
    79ef:	c3                   	ret
    79f0:	66 85 c0             	test   %ax,%ax
    79f3:	74 ea                	je     79df <fwp_args23+0x6f>
    79f5:	c3                   	ret
    79f6:	e9 f5 d7 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    79fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a00 <fwp_caps12>:
    7a00:	f3 0f 1e fa          	endbr64
    7a04:	48 83 ec 18          	sub    $0x18,%rsp
    7a08:	8b 57 04             	mov    0x4(%rdi),%edx
    7a0b:	48 89 f8             	mov    %rdi,%rax
    7a0e:	85 d2                	test   %edx,%edx
    7a10:	0f 84 9a 00 00 00    	je     7ab0 <fwp_caps12+0xb0>
    7a16:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7a1a:	85 f6                	test   %esi,%esi
    7a1c:	0f 85 9e 00 00 00    	jne    7ac0 <fwp_caps12+0xc0>
    7a22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a27:	e8 34 f0 ff ff       	call   6a60 <fwp_drop0>
    7a2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a31:	48 8b 0d 20 d1 01 00 	mov    0x1d120(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7a38:	48 89 c2             	mov    %rax,%rdx
    7a3b:	48 2b 15 ee d0 01 00 	sub    0x1d0ee(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7a42:	48 c1 e1 10          	shl    $0x10,%rcx
    7a46:	48 39 ca             	cmp    %rcx,%rdx
    7a49:	73 6d                	jae    7ab8 <fwp_caps12+0xb8>
    7a4b:	48 89 d1             	mov    %rdx,%rcx
    7a4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a56:	48 8b 0d 1b d1 01 00 	mov    0x1d11b(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7a5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a65:	48 85 f6             	test   %rsi,%rsi
    7a68:	74 4e                	je     7ab8 <fwp_caps12+0xb8>
    7a6a:	0f b6 39             	movzbl (%rcx),%edi
    7a6d:	40 80 ff 02          	cmp    $0x2,%dil
    7a71:	0f 84 b9 00 00 00    	je     7b30 <fwp_caps12+0x130>
    7a77:	40 80 ff 01          	cmp    $0x1,%dil
    7a7b:	75 3b                	jne    7ab8 <fwp_caps12+0xb8>
    7a7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7a80:	0f b7 d2             	movzwl %dx,%edx
    7a83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a86:	48 0f af d7          	imul   %rdi,%rdx
    7a8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7a8e:	48 39 ca             	cmp    %rcx,%rdx
    7a91:	73 25                	jae    7ab8 <fwp_caps12+0xb8>
    7a93:	48 01 d6             	add    %rdx,%rsi
    7a96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7a99:	75 1d                	jne    7ab8 <fwp_caps12+0xb8>
    7a9b:	48 89 c7             	mov    %rax,%rdi
    7a9e:	48 83 c4 18          	add    $0x18,%rsp
    7aa2:	e9 a9 da ff ff       	jmp    5550 <fwp_mem_free>
    7aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7aae:	00 00 
    7ab0:	85 f6                	test   %esi,%esi
    7ab2:	0f 84 79 ff ff ff    	je     7a31 <fwp_caps12+0x31>
    7ab8:	48 83 c4 18          	add    $0x18,%rsp
    7abc:	c3                   	ret
    7abd:	0f 1f 00             	nopl   (%rax)
    7ac0:	48 8b 05 91 d0 01 00 	mov    0x1d091(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7ac7:	48 2b 3d 62 d0 01 00 	sub    0x1d062(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    7ace:	48 c1 e0 10          	shl    $0x10,%rax
    7ad2:	48 39 c7             	cmp    %rax,%rdi
    7ad5:	73 e1                	jae    7ab8 <fwp_caps12+0xb8>
    7ad7:	48 89 f8             	mov    %rdi,%rax
    7ada:	48 c1 e8 10          	shr    $0x10,%rax
    7ade:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ae2:	48 8b 05 8f d0 01 00 	mov    0x1d08f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7ae9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7aed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7af1:	48 85 c0             	test   %rax,%rax
    7af4:	74 c2                	je     7ab8 <fwp_caps12+0xb8>
    7af6:	0f b6 0a             	movzbl (%rdx),%ecx
    7af9:	80 f9 02             	cmp    $0x2,%cl
    7afc:	74 42                	je     7b40 <fwp_caps12+0x140>
    7afe:	80 f9 01             	cmp    $0x1,%cl
    7b01:	75 b5                	jne    7ab8 <fwp_caps12+0xb8>
    7b03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b06:	0f b7 ff             	movzwl %di,%edi
    7b09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b0c:	48 0f af f9          	imul   %rcx,%rdi
    7b10:	48 c1 ef 20          	shr    $0x20,%rdi
    7b14:	48 39 d7             	cmp    %rdx,%rdi
    7b17:	73 9f                	jae    7ab8 <fwp_caps12+0xb8>
    7b19:	48 01 f8             	add    %rdi,%rax
    7b1c:	0f b6 10             	movzbl (%rax),%edx
    7b1f:	84 d2                	test   %dl,%dl
    7b21:	74 95                	je     7ab8 <fwp_caps12+0xb8>
    7b23:	80 fa fd             	cmp    $0xfd,%dl
    7b26:	77 23                	ja     7b4b <fwp_caps12+0x14b>
    7b28:	83 c2 01             	add    $0x1,%edx
    7b2b:	88 10                	mov    %dl,(%rax)
    7b2d:	eb 89                	jmp    7ab8 <fwp_caps12+0xb8>
    7b2f:	90                   	nop
    7b30:	66 85 d2             	test   %dx,%dx
    7b33:	0f 85 7f ff ff ff    	jne    7ab8 <fwp_caps12+0xb8>
    7b39:	e9 58 ff ff ff       	jmp    7a96 <fwp_caps12+0x96>
    7b3e:	66 90                	xchg   %ax,%ax
    7b40:	66 85 ff             	test   %di,%di
    7b43:	0f 85 6f ff ff ff    	jne    7ab8 <fwp_caps12+0xb8>
    7b49:	eb d1                	jmp    7b1c <fwp_caps12+0x11c>
    7b4b:	48 89 c7             	mov    %rax,%rdi
    7b4e:	48 83 c4 18          	add    $0x18,%rsp
    7b52:	e9 99 d6 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b5e:	00 00 

0000000000007b60 <fwp_drop2>:
    7b60:	48 8b 0d f1 cf 01 00 	mov    0x1cff1(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7b67:	48 89 f8             	mov    %rdi,%rax
    7b6a:	48 2b 05 bf cf 01 00 	sub    0x1cfbf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    7b71:	48 c1 e1 10          	shl    $0x10,%rcx
    7b75:	48 39 c8             	cmp    %rcx,%rax
    7b78:	0f 83 42 01 00 00    	jae    7cc0 <fwp_drop2+0x160>
    7b7e:	48 83 ec 18          	sub    $0x18,%rsp
    7b82:	48 89 fa             	mov    %rdi,%rdx
    7b85:	4c 8d 05 f4 bb 01 00 	lea    0x1bbf4(%rip),%r8        # 23780 <fwp_heap>
    7b8c:	48 89 c1             	mov    %rax,%rcx
    7b8f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7b96:	48 c1 e9 10          	shr    $0x10,%rcx
    7b9a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7b9e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7ba2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7ba6:	48 85 c9             	test   %rcx,%rcx
    7ba9:	74 40                	je     7beb <fwp_drop2+0x8b>
    7bab:	0f b6 3e             	movzbl (%rsi),%edi
    7bae:	40 80 ff 02          	cmp    $0x2,%dil
    7bb2:	74 3c                	je     7bf0 <fwp_drop2+0x90>
    7bb4:	40 80 ff 01          	cmp    $0x1,%dil
    7bb8:	75 31                	jne    7beb <fwp_drop2+0x8b>
    7bba:	8b 7e 18             	mov    0x18(%rsi),%edi
    7bbd:	0f b7 c0             	movzwl %ax,%eax
    7bc0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7bc3:	48 0f af c7          	imul   %rdi,%rax
    7bc7:	48 c1 e8 20          	shr    $0x20,%rax
    7bcb:	48 39 f0             	cmp    %rsi,%rax
    7bce:	73 1b                	jae    7beb <fwp_drop2+0x8b>
    7bd0:	48 01 c1             	add    %rax,%rcx
    7bd3:	0f b6 01             	movzbl (%rcx),%eax
    7bd6:	84 c0                	test   %al,%al
    7bd8:	74 11                	je     7beb <fwp_drop2+0x8b>
    7bda:	3c 01                	cmp    $0x1,%al
    7bdc:	74 22                	je     7c00 <fwp_drop2+0xa0>
    7bde:	3c ff                	cmp    $0xff,%al
    7be0:	0f 84 0a 01 00 00    	je     7cf0 <fwp_drop2+0x190>
    7be6:	83 e8 01             	sub    $0x1,%eax
    7be9:	88 01                	mov    %al,(%rcx)
    7beb:	48 83 c4 18          	add    $0x18,%rsp
    7bef:	c3                   	ret
    7bf0:	66 85 c0             	test   %ax,%ax
    7bf3:	74 de                	je     7bd3 <fwp_drop2+0x73>
    7bf5:	48 83 c4 18          	add    $0x18,%rsp
    7bf9:	c3                   	ret
    7bfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c00:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7c04:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    7c0b:	48 89 f8             	mov    %rdi,%rax
    7c0e:	48 c1 e1 10          	shl    $0x10,%rcx
    7c12:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7c19:	48 39 c8             	cmp    %rcx,%rax
    7c1c:	73 62                	jae    7c80 <fwp_drop2+0x120>
    7c1e:	48 89 c1             	mov    %rax,%rcx
    7c21:	48 c1 e9 10          	shr    $0x10,%rcx
    7c25:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c29:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7c2d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7c31:	48 85 c9             	test   %rcx,%rcx
    7c34:	74 4a                	je     7c80 <fwp_drop2+0x120>
    7c36:	44 0f b6 0e          	movzbl (%rsi),%r9d
    7c3a:	41 80 f9 02          	cmp    $0x2,%r9b
    7c3e:	0f 84 9c 00 00 00    	je     7ce0 <fwp_drop2+0x180>
    7c44:	41 80 f9 01          	cmp    $0x1,%r9b
    7c48:	75 36                	jne    7c80 <fwp_drop2+0x120>
    7c4a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    7c4e:	0f b7 c0             	movzwl %ax,%eax
    7c51:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7c54:	49 0f af c1          	imul   %r9,%rax
    7c58:	48 c1 e8 20          	shr    $0x20,%rax
    7c5c:	48 39 f0             	cmp    %rsi,%rax
    7c5f:	73 1f                	jae    7c80 <fwp_drop2+0x120>
    7c61:	48 01 c1             	add    %rax,%rcx
    7c64:	0f b6 01             	movzbl (%rcx),%eax
    7c67:	84 c0                	test   %al,%al
    7c69:	74 15                	je     7c80 <fwp_drop2+0x120>
    7c6b:	3c 01                	cmp    $0x1,%al
    7c6d:	74 59                	je     7cc8 <fwp_drop2+0x168>
    7c6f:	3c ff                	cmp    $0xff,%al
    7c71:	0f 84 ef 00 00 00    	je     7d66 <fwp_drop2+0x206>
    7c77:	83 e8 01             	sub    $0x1,%eax
    7c7a:	88 01                	mov    %al,(%rcx)
    7c7c:	0f 1f 40 00          	nopl   0x0(%rax)
    7c80:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7c84:	48 89 d7             	mov    %rdx,%rdi
    7c87:	48 89 0c 24          	mov    %rcx,(%rsp)
    7c8b:	e8 c0 ea ff ff       	call   6750 <fwp_rc_free_arr>
    7c90:	4c 8d 05 e9 ba 01 00 	lea    0x1bae9(%rip),%r8        # 23780 <fwp_heap>
    7c97:	48 8b 04 24          	mov    (%rsp),%rax
    7c9b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7ca2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7ca9:	48 c1 e2 10          	shl    $0x10,%rdx
    7cad:	48 39 d0             	cmp    %rdx,%rax
    7cb0:	0f 83 35 ff ff ff    	jae    7beb <fwp_drop2+0x8b>
    7cb6:	48 8b 14 24          	mov    (%rsp),%rdx
    7cba:	e9 cd fe ff ff       	jmp    7b8c <fwp_drop2+0x2c>
    7cbf:	90                   	nop
    7cc0:	c3                   	ret
    7cc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cc8:	48 89 14 24          	mov    %rdx,(%rsp)
    7ccc:	e8 7f ea ff ff       	call   6750 <fwp_rc_free_arr>
    7cd1:	48 8b 14 24          	mov    (%rsp),%rdx
    7cd5:	eb a9                	jmp    7c80 <fwp_drop2+0x120>
    7cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cde:	00 00 
    7ce0:	66 85 c0             	test   %ax,%ax
    7ce3:	75 9b                	jne    7c80 <fwp_drop2+0x120>
    7ce5:	e9 7a ff ff ff       	jmp    7c64 <fwp_drop2+0x104>
    7cea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cf0:	48 89 c8             	mov    %rcx,%rax
    7cf3:	48 c1 e8 11          	shr    $0x11,%rax
    7cf7:	48 31 c8             	xor    %rcx,%rax
    7cfa:	48 89 c2             	mov    %rax,%rdx
    7cfd:	48 c1 ea 09          	shr    $0x9,%rdx
    7d01:	48 31 d0             	xor    %rdx,%rax
    7d04:	0f b6 d0             	movzbl %al,%edx
    7d07:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    7d0e:	00 
    7d0f:	48 85 c0             	test   %rax,%rax
    7d12:	75 19                	jne    7d2d <fwp_drop2+0x1cd>
    7d14:	e9 d3 00 00 00       	jmp    7dec <fwp_drop2+0x28c>
    7d19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7d24:	48 85 c0             	test   %rax,%rax
    7d27:	0f 84 bf 00 00 00    	je     7dec <fwp_drop2+0x28c>
    7d2d:	48 89 c2             	mov    %rax,%rdx
    7d30:	48 39 08             	cmp    %rcx,(%rax)
    7d33:	75 eb                	jne    7d20 <fwp_drop2+0x1c0>
    7d35:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7d39:	48 83 ea 01          	sub    $0x1,%rdx
    7d3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7d41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7d48:	0f 85 9d fe ff ff    	jne    7beb <fwp_drop2+0x8b>
    7d4e:	48 89 cf             	mov    %rcx,%rdi
    7d51:	48 89 0c 24          	mov    %rcx,(%rsp)
    7d55:	e8 b6 d5 ff ff       	call   5310 <fwp_rc_forget_slot>
    7d5a:	48 8b 0c 24          	mov    (%rsp),%rcx
    7d5e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7d61:	e9 85 fe ff ff       	jmp    7beb <fwp_drop2+0x8b>
    7d66:	48 89 ce             	mov    %rcx,%rsi
    7d69:	48 c1 ee 11          	shr    $0x11,%rsi
    7d6d:	48 31 ce             	xor    %rcx,%rsi
    7d70:	48 89 f0             	mov    %rsi,%rax
    7d73:	48 c1 e8 09          	shr    $0x9,%rax
    7d77:	48 31 c6             	xor    %rax,%rsi
    7d7a:	40 0f b6 f6          	movzbl %sil,%esi
    7d7e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7d85:	00 
    7d86:	48 85 c0             	test   %rax,%rax
    7d89:	75 1e                	jne    7da9 <fwp_drop2+0x249>
    7d8b:	eb 5f                	jmp    7dec <fwp_drop2+0x28c>
    7d8d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7d94:	00 
    7d95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7d9c:	00 00 00 00 
    7da0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7da4:	48 85 c0             	test   %rax,%rax
    7da7:	74 43                	je     7dec <fwp_drop2+0x28c>
    7da9:	48 89 c6             	mov    %rax,%rsi
    7dac:	48 39 08             	cmp    %rcx,(%rax)
    7daf:	75 ef                	jne    7da0 <fwp_drop2+0x240>
    7db1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7db5:	48 83 ee 01          	sub    $0x1,%rsi
    7db9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    7dbd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7dc4:	0f 85 b6 fe ff ff    	jne    7c80 <fwp_drop2+0x120>
    7dca:	48 89 cf             	mov    %rcx,%rdi
    7dcd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7dd2:	48 89 0c 24          	mov    %rcx,(%rsp)
    7dd6:	e8 35 d5 ff ff       	call   5310 <fwp_rc_forget_slot>
    7ddb:	48 8b 0c 24          	mov    (%rsp),%rcx
    7ddf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7de4:	c6 01 fe             	movb   $0xfe,(%rcx)
    7de7:	e9 94 fe ff ff       	jmp    7c80 <fwp_drop2+0x120>
    7dec:	48 8d 3d a5 79 00 00 	lea    0x79a5(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    7df3:	e8 a8 c3 ff ff       	call   41a0 <fwp_trap>
    7df8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7dff:	00 

0000000000007e00 <fwp_arg_drop23>:
    7e00:	f3 0f 1e fa          	endbr64
    7e04:	85 f6                	test   %esi,%esi
    7e06:	75 04                	jne    7e0c <fwp_arg_drop23+0xc>
    7e08:	85 d2                	test   %edx,%edx
    7e0a:	75 04                	jne    7e10 <fwp_arg_drop23+0x10>
    7e0c:	c3                   	ret
    7e0d:	0f 1f 00             	nopl   (%rax)
    7e10:	48 8b 3f             	mov    (%rdi),%rdi
    7e13:	e9 48 fd ff ff       	jmp    7b60 <fwp_drop2>
    7e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7e1f:	00 

0000000000007e20 <fwp_caps23>:
    7e20:	f3 0f 1e fa          	endbr64
    7e24:	48 83 ec 18          	sub    $0x18,%rsp
    7e28:	8b 57 04             	mov    0x4(%rdi),%edx
    7e2b:	48 89 f8             	mov    %rdi,%rax
    7e2e:	85 d2                	test   %edx,%edx
    7e30:	0f 84 9a 00 00 00    	je     7ed0 <fwp_caps23+0xb0>
    7e36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7e3a:	85 f6                	test   %esi,%esi
    7e3c:	0f 85 9e 00 00 00    	jne    7ee0 <fwp_caps23+0xc0>
    7e42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e47:	e8 14 fd ff ff       	call   7b60 <fwp_drop2>
    7e4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e51:	48 8b 0d 00 cd 01 00 	mov    0x1cd00(%rip),%rcx        # 24b58 <fwp_heap+0x13d8>
    7e58:	48 89 c2             	mov    %rax,%rdx
    7e5b:	48 2b 15 ce cc 01 00 	sub    0x1ccce(%rip),%rdx        # 24b30 <fwp_heap+0x13b0>
    7e62:	48 c1 e1 10          	shl    $0x10,%rcx
    7e66:	48 39 ca             	cmp    %rcx,%rdx
    7e69:	73 6d                	jae    7ed8 <fwp_caps23+0xb8>
    7e6b:	48 89 d1             	mov    %rdx,%rcx
    7e6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7e72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e76:	48 8b 0d fb cc 01 00 	mov    0x1ccfb(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    7e7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e85:	48 85 f6             	test   %rsi,%rsi
    7e88:	74 4e                	je     7ed8 <fwp_caps23+0xb8>
    7e8a:	0f b6 39             	movzbl (%rcx),%edi
    7e8d:	40 80 ff 02          	cmp    $0x2,%dil
    7e91:	0f 84 b9 00 00 00    	je     7f50 <fwp_caps23+0x130>
    7e97:	40 80 ff 01          	cmp    $0x1,%dil
    7e9b:	75 3b                	jne    7ed8 <fwp_caps23+0xb8>
    7e9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7ea0:	0f b7 d2             	movzwl %dx,%edx
    7ea3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ea6:	48 0f af d7          	imul   %rdi,%rdx
    7eaa:	48 c1 ea 20          	shr    $0x20,%rdx
    7eae:	48 39 ca             	cmp    %rcx,%rdx
    7eb1:	73 25                	jae    7ed8 <fwp_caps23+0xb8>
    7eb3:	48 01 d6             	add    %rdx,%rsi
    7eb6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7eb9:	75 1d                	jne    7ed8 <fwp_caps23+0xb8>
    7ebb:	48 89 c7             	mov    %rax,%rdi
    7ebe:	48 83 c4 18          	add    $0x18,%rsp
    7ec2:	e9 89 d6 ff ff       	jmp    5550 <fwp_mem_free>
    7ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ece:	00 00 
    7ed0:	85 f6                	test   %esi,%esi
    7ed2:	0f 84 79 ff ff ff    	je     7e51 <fwp_caps23+0x31>
    7ed8:	48 83 c4 18          	add    $0x18,%rsp
    7edc:	c3                   	ret
    7edd:	0f 1f 00             	nopl   (%rax)
    7ee0:	48 8b 05 71 cc 01 00 	mov    0x1cc71(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    7ee7:	48 2b 3d 42 cc 01 00 	sub    0x1cc42(%rip),%rdi        # 24b30 <fwp_heap+0x13b0>
    7eee:	48 c1 e0 10          	shl    $0x10,%rax
    7ef2:	48 39 c7             	cmp    %rax,%rdi
    7ef5:	73 e1                	jae    7ed8 <fwp_caps23+0xb8>
    7ef7:	48 89 f8             	mov    %rdi,%rax
    7efa:	48 c1 e8 10          	shr    $0x10,%rax
    7efe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7f02:	48 8b 05 6f cc 01 00 	mov    0x1cc6f(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    7f09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7f0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7f11:	48 85 c0             	test   %rax,%rax
    7f14:	74 c2                	je     7ed8 <fwp_caps23+0xb8>
    7f16:	0f b6 0a             	movzbl (%rdx),%ecx
    7f19:	80 f9 02             	cmp    $0x2,%cl
    7f1c:	74 42                	je     7f60 <fwp_caps23+0x140>
    7f1e:	80 f9 01             	cmp    $0x1,%cl
    7f21:	75 b5                	jne    7ed8 <fwp_caps23+0xb8>
    7f23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f26:	0f b7 ff             	movzwl %di,%edi
    7f29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f2c:	48 0f af f9          	imul   %rcx,%rdi
    7f30:	48 c1 ef 20          	shr    $0x20,%rdi
    7f34:	48 39 d7             	cmp    %rdx,%rdi
    7f37:	73 9f                	jae    7ed8 <fwp_caps23+0xb8>
    7f39:	48 01 f8             	add    %rdi,%rax
    7f3c:	0f b6 10             	movzbl (%rax),%edx
    7f3f:	84 d2                	test   %dl,%dl
    7f41:	74 95                	je     7ed8 <fwp_caps23+0xb8>
    7f43:	80 fa fd             	cmp    $0xfd,%dl
    7f46:	77 23                	ja     7f6b <fwp_caps23+0x14b>
    7f48:	83 c2 01             	add    $0x1,%edx
    7f4b:	88 10                	mov    %dl,(%rax)
    7f4d:	eb 89                	jmp    7ed8 <fwp_caps23+0xb8>
    7f4f:	90                   	nop
    7f50:	66 85 d2             	test   %dx,%dx
    7f53:	0f 85 7f ff ff ff    	jne    7ed8 <fwp_caps23+0xb8>
    7f59:	e9 58 ff ff ff       	jmp    7eb6 <fwp_caps23+0x96>
    7f5e:	66 90                	xchg   %ax,%ax
    7f60:	66 85 ff             	test   %di,%di
    7f63:	0f 85 6f ff ff ff    	jne    7ed8 <fwp_caps23+0xb8>
    7f69:	eb d1                	jmp    7f3c <fwp_caps23+0x11c>
    7f6b:	48 89 c7             	mov    %rax,%rdi
    7f6e:	48 83 c4 18          	add    $0x18,%rsp
    7f72:	e9 79 d2 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7f77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f7e:	00 00 

0000000000007f80 <f23>:
    7f80:	41 57                	push   %r15
    7f82:	41 56                	push   %r14
    7f84:	41 55                	push   %r13
    7f86:	41 54                	push   %r12
    7f88:	55                   	push   %rbp
    7f89:	53                   	push   %rbx
    7f8a:	48 83 ec 38          	sub    $0x38,%rsp
    7f8e:	48 8b 15 c3 cb 01 00 	mov    0x1cbc3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    7f95:	48 8b 0d 94 cb 01 00 	mov    0x1cb94(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    7f9c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7fa3:	00 00 
    7fa5:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7faa:	49 89 fc             	mov    %rdi,%r12
    7fad:	48 c1 e2 10          	shl    $0x10,%rdx
    7fb1:	48 85 ff             	test   %rdi,%rdi
    7fb4:	0f 84 bc 02 00 00    	je     8276 <f23+0x2f6>
    7fba:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7fbf:	48 89 d8             	mov    %rbx,%rax
    7fc2:	48 29 c8             	sub    %rcx,%rax
    7fc5:	48 39 d0             	cmp    %rdx,%rax
    7fc8:	0f 83 72 03 00 00    	jae    8340 <f23+0x3c0>
    7fce:	48 89 c2             	mov    %rax,%rdx
    7fd1:	48 c1 ea 10          	shr    $0x10,%rdx
    7fd5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fd9:	48 8b 15 98 cb 01 00 	mov    0x1cb98(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    7fe0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fe4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7fe8:	48 85 ff             	test   %rdi,%rdi
    7feb:	0f 84 4f 03 00 00    	je     8340 <f23+0x3c0>
    7ff1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ff4:	80 f9 02             	cmp    $0x2,%cl
    7ff7:	0f 84 53 02 00 00    	je     8250 <f23+0x2d0>
    7ffd:	80 f9 01             	cmp    $0x1,%cl
    8000:	75 24                	jne    8026 <f23+0xa6>
    8002:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8005:	0f b7 c0             	movzwl %ax,%eax
    8008:	8b 52 1c             	mov    0x1c(%rdx),%edx
    800b:	48 0f af c1          	imul   %rcx,%rax
    800f:	48 c1 e8 20          	shr    $0x20,%rax
    8013:	48 39 d0             	cmp    %rdx,%rax
    8016:	73 0e                	jae    8026 <f23+0xa6>
    8018:	48 01 c7             	add    %rax,%rdi
    801b:	0f b6 07             	movzbl (%rdi),%eax
    801e:	84 c0                	test   %al,%al
    8020:	0f 85 ca 02 00 00    	jne    82f0 <f23+0x370>
    8026:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    802b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    8030:	ba 01 00 00 00       	mov    $0x1,%edx
    8035:	48 85 db             	test   %rbx,%rbx
    8038:	74 13                	je     804d <f23+0xcd>
    803a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8040:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8044:	48 83 c2 01          	add    $0x1,%rdx
    8048:	48 85 db             	test   %rbx,%rbx
    804b:	75 f3                	jne    8040 <f23+0xc0>
    804d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8052:	48 85 c0             	test   %rax,%rax
    8055:	0f 84 15 03 00 00    	je     8370 <f23+0x3f0>
    805b:	31 db                	xor    %ebx,%ebx
    805d:	0f 1f 00             	nopl   (%rax)
    8060:	48 8b 40 10          	mov    0x10(%rax),%rax
    8064:	48 83 c3 01          	add    $0x1,%rbx
    8068:	48 85 c0             	test   %rax,%rax
    806b:	75 f3                	jne    8060 <f23+0xe0>
    806d:	48 39 d3             	cmp    %rdx,%rbx
    8070:	48 0f 47 da          	cmova  %rdx,%rbx
    8074:	48 89 d8             	mov    %rbx,%rax
    8077:	48 c1 e8 3c          	shr    $0x3c,%rax
    807b:	0f 85 8f 03 00 00    	jne    8410 <f23+0x490>
    8081:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8085:	be 02 00 00 00       	mov    $0x2,%esi
    808a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8091:	00 
    8092:	e8 b9 d9 ff ff       	call   5a50 <fwp_heap_alloc>
    8097:	48 89 28             	mov    %rbp,(%rax)
    809a:	48 8b 15 b7 ca 01 00 	mov    0x1cab7(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    80a1:	49 89 c6             	mov    %rax,%r14
    80a4:	48 2b 05 85 ca 01 00 	sub    0x1ca85(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    80ab:	48 c1 e2 10          	shl    $0x10,%rdx
    80af:	48 39 d0             	cmp    %rdx,%rax
    80b2:	73 57                	jae    810b <f23+0x18b>
    80b4:	48 89 c2             	mov    %rax,%rdx
    80b7:	48 c1 ea 10          	shr    $0x10,%rdx
    80bb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80bf:	48 8b 15 b2 ca 01 00 	mov    0x1cab2(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    80c6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80ca:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    80ce:	48 85 ed             	test   %rbp,%rbp
    80d1:	74 38                	je     810b <f23+0x18b>
    80d3:	0f b6 0a             	movzbl (%rdx),%ecx
    80d6:	80 f9 02             	cmp    $0x2,%cl
    80d9:	0f 84 51 02 00 00    	je     8330 <f23+0x3b0>
    80df:	80 f9 01             	cmp    $0x1,%cl
    80e2:	75 27                	jne    810b <f23+0x18b>
    80e4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80e7:	0f b7 c0             	movzwl %ax,%eax
    80ea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80ed:	48 0f af c1          	imul   %rcx,%rax
    80f1:	48 c1 e8 20          	shr    $0x20,%rax
    80f5:	48 39 d0             	cmp    %rdx,%rax
    80f8:	73 11                	jae    810b <f23+0x18b>
    80fa:	48 01 c5             	add    %rax,%rbp
    80fd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8101:	0f 84 d5 02 00 00    	je     83dc <f23+0x45c>
    8107:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    810b:	48 85 db             	test   %rbx,%rbx
    810e:	74 5d                	je     816d <f23+0x1ed>
    8110:	48 c1 e3 04          	shl    $0x4,%rbx
    8114:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8119:	4c 89 f5             	mov    %r14,%rbp
    811c:	4d 89 e5             	mov    %r12,%r13
    811f:	4c 01 f3             	add    %r14,%rbx
    8122:	0f 1f 00             	nopl   (%rax)
    8125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    812c:	00 00 00 00 
    8130:	49 8b 45 08          	mov    0x8(%r13),%rax
    8134:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8138:	48 83 c5 10          	add    $0x10,%rbp
    813c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8141:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8145:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8149:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    814e:	e8 5d e1 ff ff       	call   62b0 <w107>
    8153:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8158:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    815c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8160:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8164:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    8168:	48 39 dd             	cmp    %rbx,%rbp
    816b:	75 c3                	jne    8130 <f23+0x1b0>
    816d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8172:	e8 e9 f9 ff ff       	call   7b60 <fwp_drop2>
    8177:	4c 89 e7             	mov    %r12,%rdi
    817a:	e8 e1 f9 ff ff       	call   7b60 <fwp_drop2>
    817f:	4c 89 f7             	mov    %r14,%rdi
    8182:	e8 e9 e2 ff ff       	call   6470 <w164.constprop.0>
    8187:	4c 89 f7             	mov    %r14,%rdi
    818a:	48 89 c3             	mov    %rax,%rbx
    818d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8193:	e8 c8 f4 ff ff       	call   7660 <fwp_drop4>
    8198:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    819e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    81a3:	31 ff                	xor    %edi,%edi
    81a5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    81aa:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    81ae:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    81b3:	e8 38 e3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    81b8:	48 8b 15 99 c9 01 00 	mov    0x1c999(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    81bf:	48 89 c5             	mov    %rax,%rbp
    81c2:	48 2b 05 67 c9 01 00 	sub    0x1c967(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    81c9:	48 c1 e2 10          	shl    $0x10,%rdx
    81cd:	48 39 d0             	cmp    %rdx,%rax
    81d0:	73 55                	jae    8227 <f23+0x2a7>
    81d2:	48 89 c2             	mov    %rax,%rdx
    81d5:	48 c1 ea 10          	shr    $0x10,%rdx
    81d9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    81dd:	48 8b 15 94 c9 01 00 	mov    0x1c994(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    81e4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    81e8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    81ec:	48 85 db             	test   %rbx,%rbx
    81ef:	74 36                	je     8227 <f23+0x2a7>
    81f1:	0f b6 0a             	movzbl (%rdx),%ecx
    81f4:	80 f9 02             	cmp    $0x2,%cl
    81f7:	0f 84 1b 01 00 00    	je     8318 <f23+0x398>
    81fd:	80 f9 01             	cmp    $0x1,%cl
    8200:	75 25                	jne    8227 <f23+0x2a7>
    8202:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8205:	0f b7 c0             	movzwl %ax,%eax
    8208:	8b 52 1c             	mov    0x1c(%rdx),%edx
    820b:	48 0f af c1          	imul   %rcx,%rax
    820f:	48 c1 e8 20          	shr    $0x20,%rax
    8213:	48 39 d0             	cmp    %rdx,%rax
    8216:	73 0f                	jae    8227 <f23+0x2a7>
    8218:	48 01 c3             	add    %rax,%rbx
    821b:	80 3b ff             	cmpb   $0xff,(%rbx)
    821e:	0f 84 ab 01 00 00    	je     83cf <f23+0x44f>
    8224:	c6 03 01             	movb   $0x1,(%rbx)
    8227:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    822c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8233:	00 00 
    8235:	0f 85 d0 01 00 00    	jne    840b <f23+0x48b>
    823b:	48 83 c4 38          	add    $0x38,%rsp
    823f:	48 89 e8             	mov    %rbp,%rax
    8242:	5b                   	pop    %rbx
    8243:	5d                   	pop    %rbp
    8244:	41 5c                	pop    %r12
    8246:	41 5d                	pop    %r13
    8248:	41 5e                	pop    %r14
    824a:	41 5f                	pop    %r15
    824c:	c3                   	ret
    824d:	0f 1f 00             	nopl   (%rax)
    8250:	66 85 c0             	test   %ax,%ax
    8253:	0f 85 cd fd ff ff    	jne    8026 <f23+0xa6>
    8259:	0f b6 07             	movzbl (%rdi),%eax
    825c:	84 c0                	test   %al,%al
    825e:	0f 84 c2 fd ff ff    	je     8026 <f23+0xa6>
    8264:	3c fd                	cmp    $0xfd,%al
    8266:	0f 87 95 01 00 00    	ja     8401 <f23+0x481>
    826c:	83 c0 01             	add    $0x1,%eax
    826f:	88 07                	mov    %al,(%rdi)
    8271:	e9 b0 fd ff ff       	jmp    8026 <f23+0xa6>
    8276:	48 f7 d9             	neg    %rcx
    8279:	48 39 d1             	cmp    %rdx,%rcx
    827c:	0f 83 ee 00 00 00    	jae    8370 <f23+0x3f0>
    8282:	48 89 c8             	mov    %rcx,%rax
    8285:	48 c1 e8 10          	shr    $0x10,%rax
    8289:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    828d:	48 8b 05 e4 c8 01 00 	mov    0x1c8e4(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8294:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8298:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    829c:	48 85 ff             	test   %rdi,%rdi
    829f:	0f 84 cb 00 00 00    	je     8370 <f23+0x3f0>
    82a5:	0f b6 02             	movzbl (%rdx),%eax
    82a8:	3c 02                	cmp    $0x2,%al
    82aa:	0f 84 9a 00 00 00    	je     834a <f23+0x3ca>
    82b0:	3c 01                	cmp    $0x1,%al
    82b2:	0f 85 b8 00 00 00    	jne    8370 <f23+0x3f0>
    82b8:	0f b7 c1             	movzwl %cx,%eax
    82bb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    82be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    82c1:	48 0f af c1          	imul   %rcx,%rax
    82c5:	48 c1 e8 20          	shr    $0x20,%rax
    82c9:	48 39 d0             	cmp    %rdx,%rax
    82cc:	0f 83 9e 00 00 00    	jae    8370 <f23+0x3f0>
    82d2:	48 01 c7             	add    %rax,%rdi
    82d5:	0f b6 07             	movzbl (%rdi),%eax
    82d8:	84 c0                	test   %al,%al
    82da:	0f 84 90 00 00 00    	je     8370 <f23+0x3f0>
    82e0:	31 db                	xor    %ebx,%ebx
    82e2:	0f 1f 00             	nopl   (%rax)
    82e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82ec:	00 00 00 00 
    82f0:	3c fd                	cmp    $0xfd,%al
    82f2:	0f 87 f1 00 00 00    	ja     83e9 <f23+0x469>
    82f8:	83 c0 01             	add    $0x1,%eax
    82fb:	88 07                	mov    %al,(%rdi)
    82fd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8302:	31 d2                	xor    %edx,%edx
    8304:	4d 85 e4             	test   %r12,%r12
    8307:	0f 85 1e fd ff ff    	jne    802b <f23+0xab>
    830d:	e9 3b fd ff ff       	jmp    804d <f23+0xcd>
    8312:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8318:	66 85 c0             	test   %ax,%ax
    831b:	0f 85 06 ff ff ff    	jne    8227 <f23+0x2a7>
    8321:	e9 f5 fe ff ff       	jmp    821b <f23+0x29b>
    8326:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    832d:	00 00 00 
    8330:	66 85 c0             	test   %ax,%ax
    8333:	0f 85 d2 fd ff ff    	jne    810b <f23+0x18b>
    8339:	e9 bf fd ff ff       	jmp    80fd <f23+0x17d>
    833e:	66 90                	xchg   %ax,%ax
    8340:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8345:	e9 e6 fc ff ff       	jmp    8030 <f23+0xb0>
    834a:	66 85 c9             	test   %cx,%cx
    834d:	75 21                	jne    8370 <f23+0x3f0>
    834f:	0f b6 07             	movzbl (%rdi),%eax
    8352:	84 c0                	test   %al,%al
    8354:	74 1a                	je     8370 <f23+0x3f0>
    8356:	3c fd                	cmp    $0xfd,%al
    8358:	0f 87 be 00 00 00    	ja     841c <f23+0x49c>
    835e:	83 c0 01             	add    $0x1,%eax
    8361:	88 07                	mov    %al,(%rdi)
    8363:	66 90                	xchg   %ax,%ax
    8365:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    836c:	00 00 00 00 
    8370:	be 02 00 00 00       	mov    $0x2,%esi
    8375:	bf 08 00 00 00       	mov    $0x8,%edi
    837a:	e8 d1 d6 ff ff       	call   5a50 <fwp_heap_alloc>
    837f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8386:	48 8b 15 cb c7 01 00 	mov    0x1c7cb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    838d:	49 89 c6             	mov    %rax,%r14
    8390:	48 2b 05 99 c7 01 00 	sub    0x1c799(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8397:	48 c1 e2 10          	shl    $0x10,%rdx
    839b:	48 39 d0             	cmp    %rdx,%rax
    839e:	73 53                	jae    83f3 <f23+0x473>
    83a0:	48 89 c2             	mov    %rax,%rdx
    83a3:	48 c1 ea 10          	shr    $0x10,%rdx
    83a7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    83ab:	48 8b 15 c6 c7 01 00 	mov    0x1c7c6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    83b2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    83b6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    83ba:	48 85 ed             	test   %rbp,%rbp
    83bd:	74 34                	je     83f3 <f23+0x473>
    83bf:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83c6:	00 00 
    83c8:	31 db                	xor    %ebx,%ebx
    83ca:	e9 04 fd ff ff       	jmp    80d3 <f23+0x153>
    83cf:	48 89 df             	mov    %rbx,%rdi
    83d2:	e8 39 cf ff ff       	call   5310 <fwp_rc_forget_slot>
    83d7:	e9 48 fe ff ff       	jmp    8224 <f23+0x2a4>
    83dc:	48 89 ef             	mov    %rbp,%rdi
    83df:	e8 2c cf ff ff       	call   5310 <fwp_rc_forget_slot>
    83e4:	e9 1e fd ff ff       	jmp    8107 <f23+0x187>
    83e9:	e8 02 ce ff ff       	call   51f0 <fwp_rc_wide_dup>
    83ee:	e9 0a ff ff ff       	jmp    82fd <f23+0x37d>
    83f3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    83fa:	00 00 
    83fc:	e9 6c fd ff ff       	jmp    816d <f23+0x1ed>
    8401:	e8 ea cd ff ff       	call   51f0 <fwp_rc_wide_dup>
    8406:	e9 1b fc ff ff       	jmp    8026 <f23+0xa6>
    840b:	e8 50 b0 ff ff       	call   3460 <__stack_chk_fail@plt>
    8410:	48 8d 3d 16 6d 00 00 	lea    0x6d16(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    8417:	e8 84 bd ff ff       	call   41a0 <fwp_trap>
    841c:	e8 cf cd ff ff       	call   51f0 <fwp_rc_wide_dup>
    8421:	e9 4a ff ff ff       	jmp    8370 <f23+0x3f0>
    8426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    842d:	00 00 00 

0000000000008430 <fwp_owned_entry23>:
    8430:	f3 0f 1e fa          	endbr64
    8434:	48 8b 3f             	mov    (%rdi),%rdi
    8437:	e9 44 fb ff ff       	jmp    7f80 <f23>
    843c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008440 <e23>:
    8440:	f3 0f 1e fa          	endbr64
    8444:	53                   	push   %rbx
    8445:	48 8b 1f             	mov    (%rdi),%rbx
    8448:	48 89 df             	mov    %rbx,%rdi
    844b:	e8 d0 e1 ff ff       	call   6620 <fwp_rc_share>
    8450:	48 89 df             	mov    %rbx,%rdi
    8453:	e8 28 fb ff ff       	call   7f80 <f23>
    8458:	48 89 c3             	mov    %rax,%rbx
    845b:	48 89 c7             	mov    %rax,%rdi
    845e:	e8 bd e1 ff ff       	call   6620 <fwp_rc_share>
    8463:	48 89 d8             	mov    %rbx,%rax
    8466:	5b                   	pop    %rbx
    8467:	c3                   	ret
    8468:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    846f:	00 

0000000000008470 <f12>:
    8470:	41 57                	push   %r15
    8472:	41 56                	push   %r14
    8474:	41 55                	push   %r13
    8476:	4c 8d 2d 03 ec ff ff 	lea    -0x13fd(%rip),%r13        # 7080 <fwp_tape_scope_release>
    847d:	41 54                	push   %r12
    847f:	55                   	push   %rbp
    8480:	53                   	push   %rbx
    8481:	48 81 ec f8 00 00 00 	sub    $0xf8,%rsp
    8488:	48 8b 05 89 cf 01 00 	mov    0x1cf89(%rip),%rax        # 25418 <fwp_cleanups>
    848f:	48 8b 15 c2 c6 01 00 	mov    0x1c6c2(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8496:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    849d:	00 00 
    849f:	48 89 ac 24 e8 00 00 	mov    %rbp,0xe8(%rsp)
    84a6:	00 
    84a7:	48 89 fd             	mov    %rdi,%rbp
    84aa:	4c 8d 7c 24 50       	lea    0x50(%rsp),%r15
    84af:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    84b6:	ff 
    84b7:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    84bc:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    84c1:	48 c1 e2 10          	shl    $0x10,%rdx
    84c5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    84ca:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    84cf:	48 8d 05 3a ab 00 00 	lea    0xab3a(%rip),%rax        # 13010 <fc23>
    84d6:	48 2b 05 53 c6 01 00 	sub    0x1c653(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    84dd:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    84e2:	4c 89 3d 2f cf 01 00 	mov    %r15,0x1cf2f(%rip)        # 25418 <fwp_cleanups>
    84e9:	48 39 d0             	cmp    %rdx,%rax
    84ec:	73 5d                	jae    854b <f12+0xdb>
    84ee:	48 89 c2             	mov    %rax,%rdx
    84f1:	48 c1 ea 10          	shr    $0x10,%rdx
    84f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    84f9:	48 8b 15 78 c6 01 00 	mov    0x1c678(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8500:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8504:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8508:	48 85 ff             	test   %rdi,%rdi
    850b:	74 3e                	je     854b <f12+0xdb>
    850d:	0f b6 0a             	movzbl (%rdx),%ecx
    8510:	80 f9 02             	cmp    $0x2,%cl
    8513:	0f 84 c7 0e 00 00    	je     93e0 <f12+0xf70>
    8519:	80 f9 01             	cmp    $0x1,%cl
    851c:	75 2d                	jne    854b <f12+0xdb>
    851e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8521:	0f b7 c0             	movzwl %ax,%eax
    8524:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8527:	48 0f af c1          	imul   %rcx,%rax
    852b:	48 c1 e8 20          	shr    $0x20,%rax
    852f:	48 39 d0             	cmp    %rdx,%rax
    8532:	73 17                	jae    854b <f12+0xdb>
    8534:	48 01 c7             	add    %rax,%rdi
    8537:	0f b6 07             	movzbl (%rdi),%eax
    853a:	84 c0                	test   %al,%al
    853c:	74 0d                	je     854b <f12+0xdb>
    853e:	3c fd                	cmp    $0xfd,%al
    8540:	0f 87 bf 10 00 00    	ja     9605 <f12+0x1195>
    8546:	83 c0 01             	add    $0x1,%eax
    8549:	88 07                	mov    %al,(%rdi)
    854b:	48 8d 3d be aa 00 00 	lea    0xaabe(%rip),%rdi        # 13010 <fc23>
    8552:	e8 f9 e7 ff ff       	call   6d50 <fwp_closure_drop>
    8557:	48 85 ed             	test   %rbp,%rbp
    855a:	0f 84 fe 0f 00 00    	je     955e <f12+0x10ee>
    8560:	48 89 e8             	mov    %rbp,%rax
    8563:	31 d2                	xor    %edx,%edx
    8565:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    856c:	00 00 00 00 
    8570:	48 8b 40 10          	mov    0x10(%rax),%rax
    8574:	48 83 c2 01          	add    $0x1,%rdx
    8578:	48 85 c0             	test   %rax,%rax
    857b:	75 f3                	jne    8570 <f12+0x100>
    857d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8584:	0f 87 56 11 00 00    	ja     96e0 <f12+0x1270>
    858a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    858f:	8b 35 eb aa 00 00    	mov    0xaaeb(%rip),%esi        # 13080 <registered_finish.0>
    8595:	85 f6                	test   %esi,%esi
    8597:	0f 84 13 0e 00 00    	je     93b0 <f12+0xf40>
    859d:	48 8b 1d 54 ab 01 00 	mov    0x1ab54(%rip),%rbx        # 230f8 <fwp_tape_next_slot>
    85a4:	4c 8b 25 5d ab 01 00 	mov    0x1ab5d(%rip),%r12        # 23108 <fwp_ntapes>
    85ab:	4c 39 e3             	cmp    %r12,%rbx
    85ae:	0f 8d dc 00 00 00    	jge    8690 <f12+0x220>
    85b4:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    85b8:	48 03 05 51 ab 01 00 	add    0x1ab51(%rip),%rax        # 23110 <fwp_tapes>
    85bf:	90                   	nop
    85c0:	8b 48 04             	mov    0x4(%rax),%ecx
    85c3:	85 c9                	test   %ecx,%ecx
    85c5:	75 0c                	jne    85d3 <f12+0x163>
    85c7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    85cd:	0f 86 bd 00 00 00    	jbe    8690 <f12+0x220>
    85d3:	48 83 c3 01          	add    $0x1,%rbx
    85d7:	48 83 c0 68          	add    $0x68,%rax
    85db:	4c 39 e3             	cmp    %r12,%rbx
    85de:	75 e0                	jne    85c0 <f12+0x150>
    85e0:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    85e7:	0f 8f 1c 11 00 00    	jg     9709 <f12+0x1299>
    85ed:	4c 39 25 0c ab 01 00 	cmp    %r12,0x1ab0c(%rip)        # 23100 <fwp_tapes_cap>
    85f4:	4c 8b 35 15 ab 01 00 	mov    0x1ab15(%rip),%r14        # 23110 <fwp_tapes>
    85fb:	75 53                	jne    8650 <f12+0x1e0>
    85fd:	4d 85 e4             	test   %r12,%r12
    8600:	0f 84 b9 0f 00 00    	je     95bf <f12+0x114f>
    8606:	4b 8d 0c 24          	lea    (%r12,%r12,1),%rcx
    860a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    860f:	48 39 c1             	cmp    %rax,%rcx
    8612:	48 0f 4f c8          	cmovg  %rax,%rcx
    8616:	48 6b f1 68          	imul   $0x68,%rcx,%rsi
    861a:	4c 89 f7             	mov    %r14,%rdi
    861d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    8622:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8627:	e8 a4 af ff ff       	call   35d0 <realloc@plt>
    862c:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8631:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    8636:	48 85 c0             	test   %rax,%rax
    8639:	49 89 c6             	mov    %rax,%r14
    863c:	0f 84 58 10 00 00    	je     969a <f12+0x122a>
    8642:	48 89 05 c7 aa 01 00 	mov    %rax,0x1aac7(%rip)        # 23110 <fwp_tapes>
    8649:	48 89 0d b0 aa 01 00 	mov    %rcx,0x1aab0(%rip)        # 23100 <fwp_tapes_cap>
    8650:	49 6b c4 68          	imul   $0x68,%r12,%rax
    8654:	49 83 c4 01          	add    $0x1,%r12
    8658:	4c 01 f0             	add    %r14,%rax
    865b:	48 8d 78 08          	lea    0x8(%rax),%rdi
    865f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8666:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    866a:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8671:	00 
    8672:	48 29 f8             	sub    %rdi,%rax
    8675:	8d 48 68             	lea    0x68(%rax),%ecx
    8678:	31 c0                	xor    %eax,%eax
    867a:	c1 e9 03             	shr    $0x3,%ecx
    867d:	f3 48 ab             	rep stos %rax,(%rdi)
    8680:	4c 89 25 81 aa 01 00 	mov    %r12,0x1aa81(%rip)        # 23108 <fwp_ntapes>
    8687:	eb 17                	jmp    86a0 <f12+0x230>
    8689:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8690:	4c 39 e3             	cmp    %r12,%rbx
    8693:	0f 84 47 ff ff ff    	je     85e0 <f12+0x170>
    8699:	4c 8b 35 70 aa 01 00 	mov    0x1aa70(%rip),%r14        # 23110 <fwp_tapes>
    86a0:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    86a4:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    86a8:	48 8d 3d 10 6a 00 00 	lea    0x6a10(%rip),%rdi        # f0bf <_IO_stdin_used+0xbf>
    86af:	0f 29 04 24          	movaps %xmm0,(%rsp)
    86b3:	4d 01 f4             	add    %r14,%r12
    86b6:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    86bd:	00 00 
    86bf:	e8 dc ac ff ff       	call   33a0 <getenv@plt>
    86c4:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    86c9:	48 85 c0             	test   %rax,%rax
    86cc:	74 09                	je     86d7 <f12+0x267>
    86ce:	80 38 30             	cmpb   $0x30,(%rax)
    86d1:	0f 84 d9 06 00 00    	je     8db0 <f12+0x940>
    86d7:	48 83 3d c9 a9 01 00 	cmpq   $0x0,0x1a9c9(%rip)        # 230a8 <fwp_tape_cached_bytes>
    86de:	00 
    86df:	0f 85 5b 0d 00 00    	jne    9440 <f12+0xfd0>
    86e5:	41 8b 04 24          	mov    (%r12),%eax
    86e9:	48 8d 7b 01          	lea    0x1(%rbx),%rdi
    86ed:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    86f4:	00 00 
    86f6:	48 89 3d fb a9 01 00 	mov    %rdi,0x1a9fb(%rip)        # 230f8 <fwp_tape_next_slot>
    86fd:	8d 70 01             	lea    0x1(%rax),%esi
    8700:	48 8b 05 11 cd 01 00 	mov    0x1cd11(%rip),%rax        # 25418 <fwp_cleanups>
    8707:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    870e:	00 00 
    8710:	41 89 34 24          	mov    %esi,(%r12)
    8714:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    871b:	ff ff 
    871d:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8723:	48 85 c0             	test   %rax,%rax
    8726:	75 14                	jne    873c <f12+0x2cc>
    8728:	e9 d0 0f 00 00       	jmp    96fd <f12+0x128d>
    872d:	0f 1f 00             	nopl   (%rax)
    8730:	48 8b 00             	mov    (%rax),%rax
    8733:	48 85 c0             	test   %rax,%rax
    8736:	0f 84 c1 0f 00 00    	je     96fd <f12+0x128d>
    873c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8740:	75 ee                	jne    8730 <f12+0x2c0>
    8742:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8746:	41 89 d8             	mov    %ebx,%r8d
    8749:	48 63 01             	movslq (%rcx),%rax
    874c:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8751:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8756:	85 c0                	test   %eax,%eax
    8758:	78 09                	js     8763 <f12+0x2f3>
    875a:	48 6b c0 68          	imul   $0x68,%rax,%rax
    875e:	41 89 5c 06 58       	mov    %ebx,0x58(%r14,%rax,1)
    8763:	44 89 01             	mov    %r8d,(%rcx)
    8766:	48 89 e8             	mov    %rbp,%rax
    8769:	31 c9                	xor    %ecx,%ecx
    876b:	48 85 ed             	test   %rbp,%rbp
    876e:	0f 84 54 0b 00 00    	je     92c8 <f12+0xe58>
    8774:	90                   	nop
    8775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    877c:	00 00 00 00 
    8780:	48 8b 40 10          	mov    0x10(%rax),%rax
    8784:	48 83 c1 01          	add    $0x1,%rcx
    8788:	48 85 c0             	test   %rax,%rax
    878b:	75 f3                	jne    8780 <f12+0x310>
    878d:	48 89 ea             	mov    %rbp,%rdx
    8790:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8794:	48 83 c0 01          	add    $0x1,%rax
    8798:	48 85 d2             	test   %rdx,%rdx
    879b:	75 f3                	jne    8790 <f12+0x320>
    879d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    87a4:	ff ff 1f 
    87a7:	48 39 c2             	cmp    %rax,%rdx
    87aa:	0f 82 24 0f 00 00    	jb     96d4 <f12+0x1264>
    87b0:	48 85 c9             	test   %rcx,%rcx
    87b3:	0f 8e 0f 0b 00 00    	jle    92c8 <f12+0xe58>
    87b9:	48 39 c1             	cmp    %rax,%rcx
    87bc:	48 0f 46 c1          	cmovbe %rcx,%rax
    87c0:	49 89 c5             	mov    %rax,%r13
    87c3:	48 c1 e8 3c          	shr    $0x3c,%rax
    87c7:	0f 85 07 0f 00 00    	jne    96d4 <f12+0x1264>
    87cd:	48 c1 e6 10          	shl    $0x10,%rsi
    87d1:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    87d6:	48 09 fe             	or     %rdi,%rsi
    87d9:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    87e0:	00 
    87e1:	49 89 f4             	mov    %rsi,%r12
    87e4:	be 02 00 00 00       	mov    $0x2,%esi
    87e9:	e8 62 d2 ff ff       	call   5a50 <fwp_heap_alloc>
    87ee:	4c 89 30             	mov    %r14,(%rax)
    87f1:	48 8b 15 60 c3 01 00 	mov    0x1c360(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    87f8:	48 89 c3             	mov    %rax,%rbx
    87fb:	48 2b 05 2e c3 01 00 	sub    0x1c32e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8802:	48 c1 e2 10          	shl    $0x10,%rdx
    8806:	48 39 d0             	cmp    %rdx,%rax
    8809:	0f 83 39 0b 00 00    	jae    9348 <f12+0xed8>
    880f:	48 89 c2             	mov    %rax,%rdx
    8812:	48 c1 ea 10          	shr    $0x10,%rdx
    8816:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    881a:	48 8b 15 57 c3 01 00 	mov    0x1c357(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8821:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8825:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8829:	48 85 d2             	test   %rdx,%rdx
    882c:	74 38                	je     8866 <f12+0x3f6>
    882e:	0f b6 31             	movzbl (%rcx),%esi
    8831:	40 80 fe 02          	cmp    $0x2,%sil
    8835:	0f 84 fa 0a 00 00    	je     9335 <f12+0xec5>
    883b:	40 80 fe 01          	cmp    $0x1,%sil
    883f:	75 25                	jne    8866 <f12+0x3f6>
    8841:	8b 71 18             	mov    0x18(%rcx),%esi
    8844:	0f b7 c0             	movzwl %ax,%eax
    8847:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    884a:	48 0f af c6          	imul   %rsi,%rax
    884e:	48 c1 e8 20          	shr    $0x20,%rax
    8852:	48 39 c8             	cmp    %rcx,%rax
    8855:	73 0f                	jae    8866 <f12+0x3f6>
    8857:	48 01 c2             	add    %rax,%rdx
    885a:	80 3a ff             	cmpb   $0xff,(%rdx)
    885d:	0f 84 6b 0d 00 00    	je     95ce <f12+0x115e>
    8863:	c6 02 01             	movb   $0x1,(%rdx)
    8866:	4d 85 ed             	test   %r13,%r13
    8869:	74 48                	je     88b3 <f12+0x443>
    886b:	4c 89 e1             	mov    %r12,%rcx
    886e:	48 89 ea             	mov    %rbp,%rdx
    8871:	31 c0                	xor    %eax,%eax
    8873:	48 c1 e1 20          	shl    $0x20,%rcx
    8877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    887e:	00 00 
    8880:	48 89 c6             	mov    %rax,%rsi
    8883:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8888:	48 01 ce             	add    %rcx,%rsi
    888b:	0f 80 df 0d 00 00    	jo     9670 <f12+0x1200>
    8891:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8896:	48 89 c6             	mov    %rax,%rsi
    8899:	48 83 c0 01          	add    $0x1,%rax
    889d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    88a1:	48 c1 e6 04          	shl    $0x4,%rsi
    88a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    88aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    88ae:	4c 39 e8             	cmp    %r13,%rax
    88b1:	72 cd                	jb     8880 <f12+0x410>
    88b3:	48 8b 03             	mov    (%rbx),%rax
    88b6:	48 d1 e8             	shr    $1,%rax
    88b9:	0f 84 a1 0a 00 00    	je     9360 <f12+0xef0>
    88bf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    88c3:	48 89 d1             	mov    %rdx,%rcx
    88c6:	48 c1 e9 3c          	shr    $0x3c,%rcx
    88ca:	0f 85 04 0e 00 00    	jne    96d4 <f12+0x1264>
    88d0:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
    88d4:	48 89 0c 24          	mov    %rcx,(%rsp)
    88d8:	48 85 d2             	test   %rdx,%rdx
    88db:	74 41                	je     891e <f12+0x4ae>
    88dd:	48 c1 e0 04          	shl    $0x4,%rax
    88e1:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    88e5:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    88ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88f0:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    88f5:	49 8b 76 18          	mov    0x18(%r14),%rsi
    88f9:	49 83 c6 10          	add    $0x10,%r14
    88fd:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8901:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8906:	e8 a5 d9 ff ff       	call   62b0 <w107>
    890b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    8910:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8914:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8919:	4d 39 f5             	cmp    %r14,%r13
    891c:	75 d2                	jne    88f0 <f12+0x480>
    891e:	48 8b 04 24          	mov    (%rsp),%rax
    8922:	48 89 df             	mov    %rbx,%rdi
    8925:	48 89 03             	mov    %rax,(%rbx)
    8928:	e8 43 db ff ff       	call   6470 <w164.constprop.0>
    892d:	48 89 df             	mov    %rbx,%rdi
    8930:	49 63 dc             	movslq %r12d,%rbx
    8933:	49 89 c5             	mov    %rax,%r13
    8936:	e8 25 ed ff ff       	call   7660 <fwp_drop4>
    893b:	48 89 df             	mov    %rbx,%rdi
    893e:	e8 3d bb ff ff       	call   4480 <fwp_tape_of>
    8943:	48 89 c6             	mov    %rax,%rsi
    8946:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    894b:	0f 85 9b 0d 00 00    	jne    96ec <f12+0x127c>
    8951:	48 89 c7             	mov    %rax,%rdi
    8954:	e8 a7 b2 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8959:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    895d:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8962:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8969:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    896d:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    8971:	66 48 0f 6e fa       	movq   %rdx,%xmm7
    8976:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    897b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8980:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    8984:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8988:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    898e:	77 19                	ja     89a9 <f12+0x539>
    8990:	41 0f b7 c4          	movzwl %r12w,%eax
    8994:	83 e8 01             	sub    $0x1,%eax
    8997:	48 98                	cltq
    8999:	48 3b 05 58 a7 01 00 	cmp    0x1a758(%rip),%rax        # 230f8 <fwp_tape_next_slot>
    89a0:	7d 07                	jge    89a9 <f12+0x539>
    89a2:	48 89 05 4f a7 01 00 	mov    %rax,0x1a74f(%rip)        # 230f8 <fwp_tape_next_slot>
    89a9:	48 8b 05 68 ca 01 00 	mov    0x1ca68(%rip),%rax        # 25418 <fwp_cleanups>
    89b0:	66 0f ef c9          	pxor   %xmm1,%xmm1
    89b4:	4c 8d a4 24 90 00 00 	lea    0x90(%rsp),%r12
    89bb:	00 
    89bc:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    89c3:	00 
    89c4:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    89c8:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    89cd:	48 8d 05 5c c4 ff ff 	lea    -0x3ba4(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    89d4:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    89d9:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    89de:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    89e2:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    89e6:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    89ed:	00 
    89ee:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    89f5:	00 
    89f6:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    89fd:	00 
    89fe:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    8a05:	00 
    8a06:	48 89 05 0b ca 01 00 	mov    %rax,0x1ca0b(%rip)        # 25418 <fwp_cleanups>
    8a0d:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
    8a14:	00 
    8a15:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
    8a1c:	00 
    8a1d:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    8a24:	00 
    8a25:	4d 85 ed             	test   %r13,%r13
    8a28:	0f 88 c2 09 00 00    	js     93f0 <f12+0xf80>
    8a2e:	4c 89 e8             	mov    %r13,%rax
    8a31:	48 c1 f8 20          	sar    $0x20,%rax
    8a35:	48 39 c3             	cmp    %rax,%rbx
    8a38:	0f 85 1a 0c 00 00    	jne    9658 <f12+0x11e8>
    8a3e:	45 89 ea             	mov    %r13d,%r10d
    8a41:	4c 89 d3             	mov    %r10,%rbx
    8a44:	4c 39 d7             	cmp    %r10,%rdi
    8a47:	0f 8e ff 0b 00 00    	jle    964c <f12+0x11dc>
    8a4d:	4d 39 d6             	cmp    %r10,%r14
    8a50:	0f 8e 1a 09 00 00    	jle    9370 <f12+0xf00>
    8a56:	49 39 d6             	cmp    %rdx,%r14
    8a59:	0f 8e 59 0a 00 00    	jle    94b8 <f12+0x1048>
    8a5f:	4d 89 f1             	mov    %r14,%r9
    8a62:	48 85 d2             	test   %rdx,%rdx
    8a65:	49 0f 44 d1          	cmove  %r9,%rdx
    8a69:	eb 2a                	jmp    8a95 <f12+0x625>
    8a6b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a72:	00 00 00 
    8a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a7c:	00 00 00 00 
    8a80:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8a84:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    8a8b:	4c 89 c8             	mov    %r9,%rax
    8a8e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8a92:	48 89 c2             	mov    %rax,%rdx
    8a95:	4c 39 ca             	cmp    %r9,%rdx
    8a98:	7c e6                	jl     8a80 <f12+0x610>
    8a9a:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8a9f:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    8aa4:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    8aa9:	48 85 c9             	test   %rcx,%rcx
    8aac:	0f 84 7e 0a 00 00    	je     9530 <f12+0x10c0>
    8ab2:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    8ab9:	00 
    8aba:	48 89 cf             	mov    %rcx,%rdi
    8abd:	48 89 14 24          	mov    %rdx,(%rsp)
    8ac1:	e8 0a ab ff ff       	call   35d0 <realloc@plt>
    8ac6:	48 8b 14 24          	mov    (%rsp),%rdx
    8aca:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    8ad0:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8ad6:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    8adb:	48 89 c1             	mov    %rax,%rcx
    8ade:	48 85 c9             	test   %rcx,%rcx
    8ae1:	0f 84 96 0b 00 00    	je     967d <f12+0x120d>
    8ae7:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
    8aee:	00 
    8aef:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
    8af6:	00 
    8af7:	4d 85 c9             	test   %r9,%r9
    8afa:	0f 85 12 0b 00 00    	jne    9612 <f12+0x11a2>
    8b00:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    8b07:	4d 85 ed             	test   %r13,%r13
    8b0a:	78 17                	js     8b23 <f12+0x6b3>
    8b0c:	45 89 ea             	mov    %r13d,%r10d
    8b0f:	f2 0f 10 05 19 70 00 	movsd  0x7019(%rip),%xmm0        # fb30 <msg.4+0xb0>
    8b16:	00 
    8b17:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    8b1d:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    8b23:	4c 39 f3             	cmp    %r14,%rbx
    8b26:	0f 8c 8e 00 00 00    	jl     8bba <f12+0x74a>
    8b2c:	0f 12 fb             	movhlps %xmm3,%xmm7
    8b2f:	66 49 0f 7e d2       	movq   %xmm2,%r10
    8b34:	66 48 0f 7e de       	movq   %xmm3,%rsi
    8b39:	4c 29 f3             	sub    %r14,%rbx
    8b3c:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    8b41:	0f 12 fa             	movhlps %xmm2,%xmm7
    8b44:	4e 8d 0c f1          	lea    (%rcx,%r14,8),%r9
    8b48:	66 49 0f 7e fb       	movq   %xmm7,%r11
    8b4d:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    8b51:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8b55:	48 29 fe             	sub    %rdi,%rsi
    8b58:	49 8d 14 db          	lea    (%r11,%rbx,8),%rdx
    8b5c:	4d 29 d9             	sub    %r11,%r9
    8b5f:	4d 29 da             	sub    %r11,%r10
    8b62:	eb 08                	jmp    8b6c <f12+0x6fc>
    8b64:	0f 1f 40 00          	nopl   0x0(%rax)
    8b68:	48 83 e8 04          	sub    $0x4,%rax
    8b6c:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    8b72:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    8b76:	7a 02                	jp     8b7a <f12+0x70a>
    8b78:	74 37                	je     8bb1 <f12+0x741>
    8b7a:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8b7e:	45 85 db             	test   %r11d,%r11d
    8b81:	78 16                	js     8b99 <f12+0x729>
    8b83:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8b89:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8b8d:	f2 42 0f 58 0c d9    	addsd  (%rcx,%r11,8),%xmm1
    8b93:	f2 42 0f 11 0c d9    	movsd  %xmm1,(%rcx,%r11,8)
    8b99:	4c 63 18             	movslq (%rax),%r11
    8b9c:	45 85 db             	test   %r11d,%r11d
    8b9f:	78 10                	js     8bb1 <f12+0x741>
    8ba1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8ba5:	f2 42 0f 58 04 d9    	addsd  (%rcx,%r11,8),%xmm0
    8bab:	f2 42 0f 11 04 d9    	movsd  %xmm0,(%rcx,%r11,8)
    8bb1:	48 83 ea 08          	sub    $0x8,%rdx
    8bb5:	48 39 c7             	cmp    %rax,%rdi
    8bb8:	75 ae                	jne    8b68 <f12+0x6f8>
    8bba:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8bc1:	ff ff 1f 
    8bc4:	4c 39 f0             	cmp    %r14,%rax
    8bc7:	0f 82 fb 0a 00 00    	jb     96c8 <f12+0x1258>
    8bcd:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    8bd4:	00 
    8bd5:	be 02 00 00 00       	mov    $0x2,%esi
    8bda:	48 89 0c 24          	mov    %rcx,(%rsp)
    8bde:	e8 6d ce ff ff       	call   5a50 <fwp_heap_alloc>
    8be3:	48 8b 0c 24          	mov    (%rsp),%rcx
    8be7:	4c 89 30             	mov    %r14,(%rax)
    8bea:	49 89 c5             	mov    %rax,%r13
    8bed:	31 c0                	xor    %eax,%eax
    8bef:	4d 85 f6             	test   %r14,%r14
    8bf2:	74 1e                	je     8c12 <f12+0x7a2>
    8bf4:	90                   	nop
    8bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bfc:	00 00 00 00 
    8c00:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    8c04:	49 89 54 c5 08       	mov    %rdx,0x8(%r13,%rax,8)
    8c09:	48 83 c0 01          	add    $0x1,%rax
    8c0d:	49 39 c6             	cmp    %rax,%r14
    8c10:	75 ee                	jne    8c00 <f12+0x790>
    8c12:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    8c17:	4c 89 e7             	mov    %r12,%rdi
    8c1a:	48 89 0d f7 c7 01 00 	mov    %rcx,0x1c7f7(%rip)        # 25418 <fwp_cleanups>
    8c21:	48 89 0c 24          	mov    %rcx,(%rsp)
    8c25:	e8 06 c2 ff ff       	call   4e30 <fwp_tape_buffers_release>
    8c2a:	48 8b 15 27 bf 01 00 	mov    0x1bf27(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8c31:	4c 89 e8             	mov    %r13,%rax
    8c34:	48 8b 0c 24          	mov    (%rsp),%rcx
    8c38:	48 2b 05 f1 be 01 00 	sub    0x1bef1(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8c3f:	48 c1 e2 10          	shl    $0x10,%rdx
    8c43:	48 39 d0             	cmp    %rdx,%rax
    8c46:	73 57                	jae    8c9f <f12+0x82f>
    8c48:	48 89 c2             	mov    %rax,%rdx
    8c4b:	48 c1 ea 10          	shr    $0x10,%rdx
    8c4f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8c53:	48 8b 15 1e bf 01 00 	mov    0x1bf1e(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8c5a:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8c5e:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8c62:	48 85 db             	test   %rbx,%rbx
    8c65:	74 38                	je     8c9f <f12+0x82f>
    8c67:	0f b6 32             	movzbl (%rdx),%esi
    8c6a:	40 80 fe 02          	cmp    $0x2,%sil
    8c6e:	0f 84 ac 07 00 00    	je     9420 <f12+0xfb0>
    8c74:	40 80 fe 01          	cmp    $0x1,%sil
    8c78:	75 25                	jne    8c9f <f12+0x82f>
    8c7a:	8b 72 18             	mov    0x18(%rdx),%esi
    8c7d:	0f b7 c0             	movzwl %ax,%eax
    8c80:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8c83:	48 0f af c6          	imul   %rsi,%rax
    8c87:	48 c1 e8 20          	shr    $0x20,%rax
    8c8b:	48 39 d0             	cmp    %rdx,%rax
    8c8e:	73 0f                	jae    8c9f <f12+0x82f>
    8c90:	48 01 c3             	add    %rax,%rbx
    8c93:	80 3b ff             	cmpb   $0xff,(%rbx)
    8c96:	0f 84 47 09 00 00    	je     95e3 <f12+0x1173>
    8c9c:	c6 03 01             	movb   $0x1,(%rbx)
    8c9f:	4c 39 f9             	cmp    %r15,%rcx
    8ca2:	0f 85 a3 aa ff ff    	jne    374b <f12.cold>
    8ca8:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    8cad:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8cb2:	48 89 05 5f c7 01 00 	mov    %rax,0x1c75f(%rip)        # 25418 <fwp_cleanups>
    8cb9:	e8 c2 e3 ff ff       	call   7080 <fwp_tape_scope_release>
    8cbe:	49 8b 45 00          	mov    0x0(%r13),%rax
    8cc2:	49 89 c4             	mov    %rax,%r12
    8cc5:	49 0f ba f4 3f       	btr    $0x3f,%r12
    8cca:	48 85 c0             	test   %rax,%rax
    8ccd:	0f 88 2d 05 00 00    	js     9200 <f12+0xd90>
    8cd3:	48 8b 15 7e be 01 00 	mov    0x1be7e(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    8cda:	4c 89 e8             	mov    %r13,%rax
    8cdd:	48 2b 05 4c be 01 00 	sub    0x1be4c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    8ce4:	48 c1 e2 10          	shl    $0x10,%rdx
    8ce8:	48 39 d0             	cmp    %rdx,%rax
    8ceb:	0f 83 0f 05 00 00    	jae    9200 <f12+0xd90>
    8cf1:	48 89 c2             	mov    %rax,%rdx
    8cf4:	48 c1 ea 10          	shr    $0x10,%rdx
    8cf8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8cfc:	48 8b 15 75 be 01 00 	mov    0x1be75(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    8d03:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8d07:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8d0b:	48 85 c9             	test   %rcx,%rcx
    8d0e:	0f 84 ec 04 00 00    	je     9200 <f12+0xd90>
    8d14:	0f b6 32             	movzbl (%rdx),%esi
    8d17:	40 80 fe 02          	cmp    $0x2,%sil
    8d1b:	0f 84 cf 04 00 00    	je     91f0 <f12+0xd80>
    8d21:	40 80 fe 01          	cmp    $0x1,%sil
    8d25:	0f 85 d5 04 00 00    	jne    9200 <f12+0xd90>
    8d2b:	8b 72 18             	mov    0x18(%rdx),%esi
    8d2e:	0f b7 c0             	movzwl %ax,%eax
    8d31:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8d34:	48 0f af c6          	imul   %rsi,%rax
    8d38:	48 c1 e8 20          	shr    $0x20,%rax
    8d3c:	48 39 d0             	cmp    %rdx,%rax
    8d3f:	0f 83 bb 04 00 00    	jae    9200 <f12+0xd90>
    8d45:	48 01 c1             	add    %rax,%rcx
    8d48:	80 39 01             	cmpb   $0x1,(%rcx)
    8d4b:	0f 85 af 04 00 00    	jne    9200 <f12+0xd90>
    8d51:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    8d56:	4d 89 ef             	mov    %r13,%r15
    8d59:	31 ff                	xor    %edi,%edi
    8d5b:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
    8d60:	f2 0f 10 0d d8 6d 00 	movsd  0x6dd8(%rip),%xmm1        # fb40 <msg.4+0xc0>
    8d67:	00 
    8d68:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8d6c:	31 c0                	xor    %eax,%eax
    8d6e:	4d 85 e4             	test   %r12,%r12
    8d71:	75 2a                	jne    8d9d <f12+0x92d>
    8d73:	eb 4b                	jmp    8dc0 <f12+0x950>
    8d75:	0f 1f 00             	nopl   (%rax)
    8d78:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8d7c:	0f 88 e2 08 00 00    	js     9664 <f12+0x11f4>
    8d82:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8d87:	48 83 c0 01          	add    $0x1,%rax
    8d8b:	48 83 c2 08          	add    $0x8,%rdx
    8d8f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8d93:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8d98:	49 39 c4             	cmp    %rax,%r12
    8d9b:	74 23                	je     8dc0 <f12+0x950>
    8d9d:	49 8d 4d 08          	lea    0x8(%r13),%rcx
    8da1:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8da6:	79 d0                	jns    8d78 <f12+0x908>
    8da8:	49 8b 4d 10          	mov    0x10(%r13),%rcx
    8dac:	eb ca                	jmp    8d78 <f12+0x908>
    8dae:	66 90                	xchg   %ax,%ax
    8db0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8db4:	0f 84 2b f9 ff ff    	je     86e5 <f12+0x275>
    8dba:	e9 18 f9 ff ff       	jmp    86d7 <f12+0x267>
    8dbf:	90                   	nop
    8dc0:	e8 9b e8 ff ff       	call   7660 <fwp_drop4>
    8dc5:	48 89 e8             	mov    %rbp,%rax
    8dc8:	31 d2                	xor    %edx,%edx
    8dca:	48 85 ed             	test   %rbp,%rbp
    8dcd:	0f 84 94 07 00 00    	je     9567 <f12+0x10f7>
    8dd3:	66 90                	xchg   %ax,%ax
    8dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ddc:	00 00 00 00 
    8de0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8de4:	48 83 c2 01          	add    $0x1,%rdx
    8de8:	48 85 c0             	test   %rax,%rax
    8deb:	75 f3                	jne    8de0 <f12+0x970>
    8ded:	49 8b 07             	mov    (%r15),%rax
    8df0:	49 89 c5             	mov    %rax,%r13
    8df3:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8df8:	48 85 c0             	test   %rax,%rax
    8dfb:	0f 88 51 03 00 00    	js     9152 <f12+0xce2>
    8e01:	48 8b 05 50 bd 01 00 	mov    0x1bd50(%rip),%rax        # 24b58 <fwp_heap+0x13d8>
    8e08:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    8e0d:	48 2b 0d 1c bd 01 00 	sub    0x1bd1c(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    8e14:	48 c1 e0 10          	shl    $0x10,%rax
    8e18:	48 39 c1             	cmp    %rax,%rcx
    8e1b:	0f 83 31 03 00 00    	jae    9152 <f12+0xce2>
    8e21:	48 89 c8             	mov    %rcx,%rax
    8e24:	48 c1 e8 10          	shr    $0x10,%rax
    8e28:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    8e2c:	48 8b 05 45 bd 01 00 	mov    0x1bd45(%rip),%rax        # 24b78 <fwp_heap+0x13f8>
    8e33:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    8e37:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8e3b:	48 85 ff             	test   %rdi,%rdi
    8e3e:	0f 84 0e 03 00 00    	je     9152 <f12+0xce2>
    8e44:	0f b6 06             	movzbl (%rsi),%eax
    8e47:	3c 02                	cmp    $0x2,%al
    8e49:	0f 84 f1 02 00 00    	je     9140 <f12+0xcd0>
    8e4f:	3c 01                	cmp    $0x1,%al
    8e51:	0f 85 f2 02 00 00    	jne    9149 <f12+0xcd9>
    8e57:	8b 46 18             	mov    0x18(%rsi),%eax
    8e5a:	0f b7 c9             	movzwl %cx,%ecx
    8e5d:	48 0f af c8          	imul   %rax,%rcx
    8e61:	8b 46 1c             	mov    0x1c(%rsi),%eax
    8e64:	48 c1 e9 20          	shr    $0x20,%rcx
    8e68:	48 39 c1             	cmp    %rax,%rcx
    8e6b:	0f 83 d8 02 00 00    	jae    9149 <f12+0xcd9>
    8e71:	48 01 cf             	add    %rcx,%rdi
    8e74:	80 3f 01             	cmpb   $0x1,(%rdi)
    8e77:	0f 85 cc 02 00 00    	jne    9149 <f12+0xcd9>
    8e7d:	4c 39 ea             	cmp    %r13,%rdx
    8e80:	4c 89 e8             	mov    %r13,%rax
    8e83:	48 0f 46 c2          	cmovbe %rdx,%rax
    8e87:	48 85 c0             	test   %rax,%rax
    8e8a:	0f 84 e5 07 00 00    	je     9675 <f12+0x1205>
    8e90:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    8e97:	00 
    8e98:	4d 8d 77 08          	lea    0x8(%r15),%r14
    8e9c:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    8ea1:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    8ea8:	00 
    8ea9:	48 89 e9             	mov    %rbp,%rcx
    8eac:	31 d2                	xor    %edx,%edx
    8eae:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    8eb2:	eb 29                	jmp    8edd <f12+0xa6d>
    8eb4:	90                   	nop
    8eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ebc:	00 00 00 00 
    8ec0:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    8ec5:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    8eca:	f2 41 0f 11 04 16    	movsd  %xmm0,(%r14,%rdx,1)
    8ed0:	48 83 c2 08          	add    $0x8,%rdx
    8ed4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8ed8:	49 39 d0             	cmp    %rdx,%r8
    8edb:	74 1b                	je     8ef8 <f12+0xa88>
    8edd:	48 89 fe             	mov    %rdi,%rsi
    8ee0:	49 83 3f 00          	cmpq   $0x0,(%r15)
    8ee4:	79 da                	jns    8ec0 <f12+0xa50>
    8ee6:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
    8eeb:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    8eef:	eb cf                	jmp    8ec0 <f12+0xa50>
    8ef1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ef8:	48 85 ed             	test   %rbp,%rbp
    8efb:	0f 84 43 07 00 00    	je     9644 <f12+0x11d4>
    8f01:	4c 8b 05 50 bc 01 00 	mov    0x1bc50(%rip),%r8        # 24b58 <fwp_heap+0x13d8>
    8f08:	4c 8b 0d 21 bc 01 00 	mov    0x1bc21(%rip),%r9        # 24b30 <fwp_heap+0x13b0>
    8f0f:	48 89 e9             	mov    %rbp,%rcx
    8f12:	45 31 ed             	xor    %r13d,%r13d
    8f15:	4c 8b 15 5c bc 01 00 	mov    0x1bc5c(%rip),%r10        # 24b78 <fwp_heap+0x13f8>
    8f1c:	49 c1 e0 10          	shl    $0x10,%r8
    8f20:	eb 1c                	jmp    8f3e <f12+0xace>
    8f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f28:	49 83 c5 01          	add    $0x1,%r13
    8f2c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    8f30:	49 39 c5             	cmp    %rax,%r13
    8f33:	0f 83 67 01 00 00    	jae    90a0 <f12+0xc30>
    8f39:	48 85 c9             	test   %rcx,%rcx
    8f3c:	74 56                	je     8f94 <f12+0xb24>
    8f3e:	48 89 ca             	mov    %rcx,%rdx
    8f41:	4c 29 ca             	sub    %r9,%rdx
    8f44:	4c 39 c2             	cmp    %r8,%rdx
    8f47:	73 4b                	jae    8f94 <f12+0xb24>
    8f49:	48 89 d6             	mov    %rdx,%rsi
    8f4c:	48 c1 ee 10          	shr    $0x10,%rsi
    8f50:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8f54:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    8f58:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8f5c:	48 85 ff             	test   %rdi,%rdi
    8f5f:	74 33                	je     8f94 <f12+0xb24>
    8f61:	44 0f b6 1e          	movzbl (%rsi),%r11d
    8f65:	41 80 fb 02          	cmp    $0x2,%r11b
    8f69:	0f 84 19 01 00 00    	je     9088 <f12+0xc18>
    8f6f:	41 80 fb 01          	cmp    $0x1,%r11b
    8f73:	75 1f                	jne    8f94 <f12+0xb24>
    8f75:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    8f79:	0f b7 d2             	movzwl %dx,%edx
    8f7c:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8f7f:	49 0f af d3          	imul   %r11,%rdx
    8f83:	48 c1 ea 20          	shr    $0x20,%rdx
    8f87:	48 39 f2             	cmp    %rsi,%rdx
    8f8a:	73 08                	jae    8f94 <f12+0xb24>
    8f8c:	48 01 d7             	add    %rdx,%rdi
    8f8f:	80 3f 01             	cmpb   $0x1,(%rdi)
    8f92:	74 94                	je     8f28 <f12+0xab8>
    8f94:	49 39 c5             	cmp    %rax,%r13
    8f97:	0f 83 03 01 00 00    	jae    90a0 <f12+0xc30>
    8f9d:	49 89 c7             	mov    %rax,%r15
    8fa0:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    8fa7:	00 
    8fa8:	45 31 e4             	xor    %r12d,%r12d
    8fab:	48 89 04 24          	mov    %rax,(%rsp)
    8faf:	48 8d 1d ca a7 01 00 	lea    0x1a7ca(%rip),%rbx        # 23780 <fwp_heap>
    8fb6:	eb 3a                	jmp    8ff2 <f12+0xb82>
    8fb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8fbf:	00 
    8fc0:	41 80 f9 01          	cmp    $0x1,%r9b
    8fc4:	75 27                	jne    8fed <f12+0xb7d>
    8fc6:	45 8b 48 18          	mov    0x18(%r8),%r9d
    8fca:	0f b7 c0             	movzwl %ax,%eax
    8fcd:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    8fd1:	49 0f af c1          	imul   %r9,%rax
    8fd5:	48 c1 e8 20          	shr    $0x20,%rax
    8fd9:	4c 39 c0             	cmp    %r8,%rax
    8fdc:	73 0f                	jae    8fed <f12+0xb7d>
    8fde:	48 01 c7             	add    %rax,%rdi
    8fe1:	80 3f ff             	cmpb   $0xff,(%rdi)
    8fe4:	0f 84 c6 02 00 00    	je     92b0 <f12+0xe40>
    8fea:	c6 07 01             	movb   $0x1,(%rdi)
    8fed:	4d 39 fd             	cmp    %r15,%r13
    8ff0:	73 7e                	jae    9070 <f12+0xc00>
    8ff2:	49 83 ef 01          	sub    $0x1,%r15
    8ff6:	66 49 0f 6e f4       	movq   %r12,%xmm6
    8ffb:	48 8b 34 24          	mov    (%rsp),%rsi
    8fff:	bf 01 00 00 00       	mov    $0x1,%edi
    9004:	f3 43 0f 7e 04 fe    	movq   (%r14,%r15,8),%xmm0
    900a:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    900e:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    9015:	00 
    9016:	e8 d5 d4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    901b:	48 8b bb d8 13 00 00 	mov    0x13d8(%rbx),%rdi
    9022:	49 89 c4             	mov    %rax,%r12
    9025:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    902c:	48 c1 e7 10          	shl    $0x10,%rdi
    9030:	48 39 f8             	cmp    %rdi,%rax
    9033:	73 b8                	jae    8fed <f12+0xb7d>
    9035:	48 89 c7             	mov    %rax,%rdi
    9038:	48 c1 ef 10          	shr    $0x10,%rdi
    903c:	4c 8d 04 bf          	lea    (%rdi,%rdi,4),%r8
    9040:	48 8b bb f8 13 00 00 	mov    0x13f8(%rbx),%rdi
    9047:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
    904b:	49 8b 78 20          	mov    0x20(%r8),%rdi
    904f:	48 85 ff             	test   %rdi,%rdi
    9052:	74 99                	je     8fed <f12+0xb7d>
    9054:	45 0f b6 08          	movzbl (%r8),%r9d
    9058:	41 80 f9 02          	cmp    $0x2,%r9b
    905c:	0f 85 5e ff ff ff    	jne    8fc0 <f12+0xb50>
    9062:	66 85 c0             	test   %ax,%ax
    9065:	0f 84 76 ff ff ff    	je     8fe1 <f12+0xb71>
    906b:	4d 39 fd             	cmp    %r15,%r13
    906e:	72 82                	jb     8ff2 <f12+0xb82>
    9070:	4d 85 ed             	test   %r13,%r13
    9073:	75 2e                	jne    90a3 <f12+0xc33>
    9075:	8b 44 24 10          	mov    0x10(%rsp),%eax
    9079:	85 c0                	test   %eax,%eax
    907b:	4d 0f 45 f5          	cmovne %r13,%r14
    907f:	eb 6f                	jmp    90f0 <f12+0xc80>
    9081:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9088:	66 85 d2             	test   %dx,%dx
    908b:	0f 84 fe fe ff ff    	je     8f8f <f12+0xb1f>
    9091:	49 39 c5             	cmp    %rax,%r13
    9094:	0f 82 03 ff ff ff    	jb     8f9d <f12+0xb2d>
    909a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90a0:	45 31 e4             	xor    %r12d,%r12d
    90a3:	4c 89 f2             	mov    %r14,%rdx
    90a6:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
    90aa:	48 89 e8             	mov    %rbp,%rax
    90ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    90b4:	00 
    90b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90bc:	00 00 00 00 
    90c0:	48 8b 0a             	mov    (%rdx),%rcx
    90c3:	48 83 c2 08          	add    $0x8,%rdx
    90c7:	48 89 c7             	mov    %rax,%rdi
    90ca:	48 89 48 08          	mov    %rcx,0x8(%rax)
    90ce:	48 8b 40 10          	mov    0x10(%rax),%rax
    90d2:	4c 39 c2             	cmp    %r8,%rdx
    90d5:	75 e9                	jne    90c0 <f12+0xc50>
    90d7:	8b 54 24 10          	mov    0x10(%rsp),%edx
    90db:	4c 89 67 10          	mov    %r12,0x10(%rdi)
    90df:	85 d2                	test   %edx,%edx
    90e1:	0f 84 49 03 00 00    	je     9430 <f12+0xfc0>
    90e7:	49 89 ec             	mov    %rbp,%r12
    90ea:	45 31 f6             	xor    %r14d,%r14d
    90ed:	48 89 c5             	mov    %rax,%rbp
    90f0:	4c 89 f7             	mov    %r14,%rdi
    90f3:	e8 58 c4 ff ff       	call   5550 <fwp_mem_free>
    90f8:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    90fd:	e8 5e e5 ff ff       	call   7660 <fwp_drop4>
    9102:	48 89 ef             	mov    %rbp,%rdi
    9105:	e8 56 d9 ff ff       	call   6a60 <fwp_drop0>
    910a:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
    9111:	00 
    9112:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9119:	00 00 
    911b:	0f 85 d7 05 00 00    	jne    96f8 <f12+0x1288>
    9121:	48 81 c4 f8 00 00 00 	add    $0xf8,%rsp
    9128:	4c 89 e0             	mov    %r12,%rax
    912b:	5b                   	pop    %rbx
    912c:	5d                   	pop    %rbp
    912d:	41 5c                	pop    %r12
    912f:	41 5d                	pop    %r13
    9131:	41 5e                	pop    %r14
    9133:	41 5f                	pop    %r15
    9135:	c3                   	ret
    9136:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    913d:	00 00 00 
    9140:	66 85 c9             	test   %cx,%cx
    9143:	0f 84 2b fd ff ff    	je     8e74 <f12+0xa04>
    9149:	48 85 ed             	test   %rbp,%rbp
    914c:	0f 84 ab 03 00 00    	je     94fd <f12+0x108d>
    9152:	48 89 e8             	mov    %rbp,%rax
    9155:	45 31 e4             	xor    %r12d,%r12d
    9158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    915f:	00 
    9160:	48 8b 40 10          	mov    0x10(%rax),%rax
    9164:	4c 89 e2             	mov    %r12,%rdx
    9167:	49 83 c4 01          	add    $0x1,%r12
    916b:	48 85 c0             	test   %rax,%rax
    916e:	75 f0                	jne    9160 <f12+0xcf0>
    9170:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9177:	ff ff 1f 
    917a:	4c 39 e0             	cmp    %r12,%rax
    917d:	0f 82 51 05 00 00    	jb     96d4 <f12+0x1264>
    9183:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    918a:	00 
    918b:	be 02 00 00 00       	mov    $0x2,%esi
    9190:	e8 bb c8 ff ff       	call   5a50 <fwp_heap_alloc>
    9195:	4d 39 e5             	cmp    %r12,%r13
    9198:	48 89 ea             	mov    %rbp,%rdx
    919b:	49 89 c6             	mov    %rax,%r14
    919e:	4c 89 e0             	mov    %r12,%rax
    91a1:	49 0f 46 c5          	cmovbe %r13,%rax
    91a5:	4c 89 f1             	mov    %r14,%rcx
    91a8:	66 90                	xchg   %ax,%ax
    91aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91b1:	00 00 00 00 
    91b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91bc:	00 00 00 00 
    91c0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    91c4:	48 83 c1 08          	add    $0x8,%rcx
    91c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    91cc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    91d0:	48 85 d2             	test   %rdx,%rdx
    91d3:	75 eb                	jne    91c0 <f12+0xd50>
    91d5:	48 85 c0             	test   %rax,%rax
    91d8:	0f 84 31 03 00 00    	je     950f <f12+0x109f>
    91de:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    91e5:	00 
    91e6:	e9 b1 fc ff ff       	jmp    8e9c <f12+0xa2c>
    91eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    91f0:	66 85 c0             	test   %ax,%ax
    91f3:	0f 84 4f fb ff ff    	je     8d48 <f12+0x8d8>
    91f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9200:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9207:	ff ff 1f 
    920a:	4c 39 e0             	cmp    %r12,%rax
    920d:	0f 82 b5 04 00 00    	jb     96c8 <f12+0x1258>
    9213:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    921a:	00 
    921b:	be 01 00 00 00       	mov    $0x1,%esi
    9220:	e8 2b c8 ff ff       	call   5a50 <fwp_heap_alloc>
    9225:	4c 89 20             	mov    %r12,(%rax)
    9228:	48 8b 15 29 b9 01 00 	mov    0x1b929(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    922f:	49 89 c7             	mov    %rax,%r15
    9232:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9237:	48 2b 05 f2 b8 01 00 	sub    0x1b8f2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    923e:	48 c1 e2 10          	shl    $0x10,%rdx
    9242:	48 39 d0             	cmp    %rdx,%rax
    9245:	73 57                	jae    929e <f12+0xe2e>
    9247:	48 89 c2             	mov    %rax,%rdx
    924a:	48 c1 ea 10          	shr    $0x10,%rdx
    924e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9252:	48 8b 15 1f b9 01 00 	mov    0x1b91f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9259:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    925d:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9261:	4d 85 f6             	test   %r14,%r14
    9264:	74 38                	je     929e <f12+0xe2e>
    9266:	0f b6 0a             	movzbl (%rdx),%ecx
    9269:	80 f9 02             	cmp    $0x2,%cl
    926c:	0f 84 ae 02 00 00    	je     9520 <f12+0x10b0>
    9272:	80 f9 01             	cmp    $0x1,%cl
    9275:	75 27                	jne    929e <f12+0xe2e>
    9277:	8b 4a 18             	mov    0x18(%rdx),%ecx
    927a:	0f b7 c0             	movzwl %ax,%eax
    927d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9280:	48 0f af c1          	imul   %rcx,%rax
    9284:	48 c1 e8 20          	shr    $0x20,%rax
    9288:	48 39 d0             	cmp    %rdx,%rax
    928b:	73 11                	jae    929e <f12+0xe2e>
    928d:	49 01 c6             	add    %rax,%r14
    9290:	41 80 3e ff          	cmpb   $0xff,(%r14)
    9294:	0f 84 5e 03 00 00    	je     95f8 <f12+0x1188>
    929a:	41 c6 06 01          	movb   $0x1,(%r14)
    929e:	4c 89 ef             	mov    %r13,%rdi
    92a1:	e9 b5 fa ff ff       	jmp    8d5b <f12+0x8eb>
    92a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92ad:	00 00 00 
    92b0:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
    92b5:	e8 56 c0 ff ff       	call   5310 <fwp_rc_forget_slot>
    92ba:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    92bf:	e9 26 fd ff ff       	jmp    8fea <f12+0xb7a>
    92c4:	0f 1f 40 00          	nopl   0x0(%rax)
    92c8:	48 c1 e6 10          	shl    $0x10,%rsi
    92cc:	48 09 fe             	or     %rdi,%rsi
    92cf:	bf 08 00 00 00       	mov    $0x8,%edi
    92d4:	49 89 f4             	mov    %rsi,%r12
    92d7:	be 02 00 00 00       	mov    $0x2,%esi
    92dc:	e8 6f c7 ff ff       	call   5a50 <fwp_heap_alloc>
    92e1:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    92e8:	48 8b 15 69 b8 01 00 	mov    0x1b869(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    92ef:	48 89 c3             	mov    %rax,%rbx
    92f2:	48 2b 05 37 b8 01 00 	sub    0x1b837(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    92f9:	48 c1 e2 10          	shl    $0x10,%rdx
    92fd:	48 39 d0             	cmp    %rdx,%rax
    9300:	73 5e                	jae    9360 <f12+0xef0>
    9302:	48 89 c2             	mov    %rax,%rdx
    9305:	48 c1 ea 10          	shr    $0x10,%rdx
    9309:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    930d:	48 8b 15 64 b8 01 00 	mov    0x1b864(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    9314:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    9318:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    931c:	48 85 d2             	test   %rdx,%rdx
    931f:	0f 84 8e f5 ff ff    	je     88b3 <f12+0x443>
    9325:	0f b6 31             	movzbl (%rcx),%esi
    9328:	45 31 ed             	xor    %r13d,%r13d
    932b:	40 80 fe 02          	cmp    $0x2,%sil
    932f:	0f 85 06 f5 ff ff    	jne    883b <f12+0x3cb>
    9335:	66 85 c0             	test   %ax,%ax
    9338:	0f 85 28 f5 ff ff    	jne    8866 <f12+0x3f6>
    933e:	e9 17 f5 ff ff       	jmp    885a <f12+0x3ea>
    9343:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9348:	4d 85 ed             	test   %r13,%r13
    934b:	0f 85 1a f5 ff ff    	jne    886b <f12+0x3fb>
    9351:	0f 1f 40 00          	nopl   0x0(%rax)
    9355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    935c:	00 00 00 00 
    9360:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    9367:	00 
    9368:	e9 b1 f5 ff ff       	jmp    891e <f12+0x4ae>
    936d:	0f 1f 00             	nopl   (%rax)
    9370:	4d 8d 4a 01          	lea    0x1(%r10),%r9
    9374:	4c 39 ca             	cmp    %r9,%rdx
    9377:	0f 8c e5 f6 ff ff    	jl     8a62 <f12+0x5f2>
    937d:	48 85 c9             	test   %rcx,%rcx
    9380:	0f 84 00 03 00 00    	je     9686 <f12+0x1216>
    9386:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    938b:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    9392:	00 
    9393:	31 f6                	xor    %esi,%esi
    9395:	48 89 cf             	mov    %rcx,%rdi
    9398:	0f 29 14 24          	movaps %xmm2,(%rsp)
    939c:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    93a1:	e9 3a 01 00 00       	jmp    94e0 <f12+0x1070>
    93a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93ad:	00 00 00 
    93b0:	48 8d 3d e9 db ff ff 	lea    -0x2417(%rip),%rdi        # 6fa0 <fwp_tape_finish>
    93b7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    93bc:	e8 4f 56 00 00       	call   ea10 <atexit>
    93c1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    93c6:	85 c0                	test   %eax,%eax
    93c8:	0f 85 cc 02 00 00    	jne    969a <f12+0x122a>
    93ce:	c7 05 a8 9c 00 00 01 	movl   $0x1,0x9ca8(%rip)        # 13080 <registered_finish.0>
    93d5:	00 00 00 
    93d8:	e9 c0 f1 ff ff       	jmp    859d <f12+0x12d>
    93dd:	0f 1f 00             	nopl   (%rax)
    93e0:	66 85 c0             	test   %ax,%ax
    93e3:	0f 85 62 f1 ff ff    	jne    854b <f12+0xdb>
    93e9:	e9 49 f1 ff ff       	jmp    8537 <f12+0xc7>
    93ee:	66 90                	xchg   %ax,%ax
    93f0:	49 39 d6             	cmp    %rdx,%r14
    93f3:	0f 8f 66 f6 ff ff    	jg     8a5f <f12+0x5ef>
    93f9:	4d 85 f6             	test   %r14,%r14
    93fc:	74 12                	je     9410 <f12+0xfa0>
    93fe:	48 85 c9             	test   %rcx,%rcx
    9401:	0f 84 7f 02 00 00    	je     9686 <f12+0x1216>
    9407:	4d 85 f6             	test   %r14,%r14
    940a:	0f 85 ff 01 00 00    	jne    960f <f12+0x119f>
    9410:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    9417:	e9 07 f7 ff ff       	jmp    8b23 <f12+0x6b3>
    941c:	0f 1f 40 00          	nopl   0x0(%rax)
    9420:	66 85 c0             	test   %ax,%ax
    9423:	0f 85 76 f8 ff ff    	jne    8c9f <f12+0x82f>
    9429:	e9 65 f8 ff ff       	jmp    8c93 <f12+0x823>
    942e:	66 90                	xchg   %ax,%ax
    9430:	49 89 ec             	mov    %rbp,%r12
    9433:	48 89 c5             	mov    %rax,%rbp
    9436:	e9 b5 fc ff ff       	jmp    90f0 <f12+0xc80>
    943b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9440:	66 0f 6f 0d 78 9c 01 	movdqa 0x19c78(%rip),%xmm1        # 230c0 <fwp_tape_workspace>
    9447:	00 
    9448:	48 c7 05 55 9c 01 00 	movq   $0x0,0x19c55(%rip)        # 230a8 <fwp_tape_cached_bytes>
    944f:	00 00 00 00 
    9453:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    9459:	48 8b 05 80 9c 01 00 	mov    0x19c80(%rip),%rax        # 230e0 <fwp_tape_workspace+0x20>
    9460:	66 0f 6f 0d 68 9c 01 	movdqa 0x19c68(%rip),%xmm1        # 230d0 <fwp_tape_workspace+0x10>
    9467:	00 
    9468:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    946d:	48 8b 05 74 9c 01 00 	mov    0x19c74(%rip),%rax        # 230e8 <fwp_tape_workspace+0x28>
    9474:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    947a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    947e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9483:	48 8b 05 66 9c 01 00 	mov    0x19c66(%rip),%rax        # 230f0 <fwp_tape_workspace+0x30>
    948a:	0f 29 0d 2f 9c 01 00 	movaps %xmm1,0x19c2f(%rip)        # 230c0 <fwp_tape_workspace>
    9491:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9496:	0f 29 0d 33 9c 01 00 	movaps %xmm1,0x19c33(%rip)        # 230d0 <fwp_tape_workspace+0x10>
    949d:	48 c7 05 48 9c 01 00 	movq   $0x0,0x19c48(%rip)        # 230f0 <fwp_tape_workspace+0x30>
    94a4:	00 00 00 00 
    94a8:	0f 29 0d 31 9c 01 00 	movaps %xmm1,0x19c31(%rip)        # 230e0 <fwp_tape_workspace+0x20>
    94af:	e9 31 f2 ff ff       	jmp    86e5 <f12+0x275>
    94b4:	0f 1f 40 00          	nopl   0x0(%rax)
    94b8:	48 85 c9             	test   %rcx,%rcx
    94bb:	0f 84 c5 01 00 00    	je     9686 <f12+0x1216>
    94c1:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
    94c6:	49 8d 5e ff          	lea    -0x1(%r14),%rbx
    94ca:	31 f6                	xor    %esi,%esi
    94cc:	48 89 cf             	mov    %rcx,%rdi
    94cf:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    94d4:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    94db:	00 
    94dc:	0f 29 14 24          	movaps %xmm2,(%rsp)
    94e0:	e8 db 9f ff ff       	call   34c0 <memset@plt>
    94e5:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    94ea:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    94f0:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
    94f5:	48 89 c1             	mov    %rax,%rcx
    94f8:	e9 12 f6 ff ff       	jmp    8b0f <f12+0x69f>
    94fd:	be 02 00 00 00       	mov    $0x2,%esi
    9502:	bf 08 00 00 00       	mov    $0x8,%edi
    9507:	e8 44 c5 ff ff       	call   5a50 <fwp_heap_alloc>
    950c:	49 89 c6             	mov    %rax,%r14
    950f:	45 31 e4             	xor    %r12d,%r12d
    9512:	e9 d9 fb ff ff       	jmp    90f0 <f12+0xc80>
    9517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    951e:	00 00 
    9520:	66 85 c0             	test   %ax,%ax
    9523:	0f 85 75 fd ff ff    	jne    929e <f12+0xe2e>
    9529:	e9 62 fd ff ff       	jmp    9290 <f12+0xe20>
    952e:	66 90                	xchg   %ax,%ax
    9530:	48 89 d7             	mov    %rdx,%rdi
    9533:	be 08 00 00 00       	mov    $0x8,%esi
    9538:	48 89 14 24          	mov    %rdx,(%rsp)
    953c:	e8 df 9f ff ff       	call   3520 <calloc@plt>
    9541:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    9546:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    954c:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    9552:	48 8b 14 24          	mov    (%rsp),%rdx
    9556:	48 89 c1             	mov    %rax,%rcx
    9559:	e9 80 f5 ff ff       	jmp    8ade <f12+0x66e>
    955e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9562:	e9 28 f0 ff ff       	jmp    858f <f12+0x11f>
    9567:	49 8b 07             	mov    (%r15),%rax
    956a:	48 85 c0             	test   %rax,%rax
    956d:	78 8e                	js     94fd <f12+0x108d>
    956f:	48 8b 35 e2 b5 01 00 	mov    0x1b5e2(%rip),%rsi        # 24b58 <fwp_heap+0x13d8>
    9576:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    957b:	48 2b 0d ae b5 01 00 	sub    0x1b5ae(%rip),%rcx        # 24b30 <fwp_heap+0x13b0>
    9582:	48 c1 e6 10          	shl    $0x10,%rsi
    9586:	48 39 f1             	cmp    %rsi,%rcx
    9589:	0f 83 6e ff ff ff    	jae    94fd <f12+0x108d>
    958f:	48 89 ce             	mov    %rcx,%rsi
    9592:	48 c1 ee 10          	shr    $0x10,%rsi
    9596:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    959a:	48 8b 35 d7 b5 01 00 	mov    0x1b5d7(%rip),%rsi        # 24b78 <fwp_heap+0x13f8>
    95a1:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    95a5:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    95a9:	48 85 ff             	test   %rdi,%rdi
    95ac:	0f 84 4b ff ff ff    	je     94fd <f12+0x108d>
    95b2:	48 0f ba f0 3f       	btr    $0x3f,%rax
    95b7:	49 89 c5             	mov    %rax,%r13
    95ba:	e9 85 f8 ff ff       	jmp    8e44 <f12+0x9d4>
    95bf:	be 68 00 00 00       	mov    $0x68,%esi
    95c4:	b9 01 00 00 00       	mov    $0x1,%ecx
    95c9:	e9 4c f0 ff ff       	jmp    861a <f12+0x1aa>
    95ce:	48 89 d7             	mov    %rdx,%rdi
    95d1:	48 89 14 24          	mov    %rdx,(%rsp)
    95d5:	e8 36 bd ff ff       	call   5310 <fwp_rc_forget_slot>
    95da:	48 8b 14 24          	mov    (%rsp),%rdx
    95de:	e9 80 f2 ff ff       	jmp    8863 <f12+0x3f3>
    95e3:	48 89 df             	mov    %rbx,%rdi
    95e6:	48 89 0c 24          	mov    %rcx,(%rsp)
    95ea:	e8 21 bd ff ff       	call   5310 <fwp_rc_forget_slot>
    95ef:	48 8b 0c 24          	mov    (%rsp),%rcx
    95f3:	e9 a4 f6 ff ff       	jmp    8c9c <f12+0x82c>
    95f8:	4c 89 f7             	mov    %r14,%rdi
    95fb:	e8 10 bd ff ff       	call   5310 <fwp_rc_forget_slot>
    9600:	e9 95 fc ff ff       	jmp    929a <f12+0xe2a>
    9605:	e8 e6 bb ff ff       	call   51f0 <fwp_rc_wide_dup>
    960a:	e9 3c ef ff ff       	jmp    854b <f12+0xdb>
    960f:	4d 89 f1             	mov    %r14,%r9
    9612:	48 89 cf             	mov    %rcx,%rdi
    9615:	31 f6                	xor    %esi,%esi
    9617:	0f 29 5c 24 10       	movaps %xmm3,0x10(%rsp)
    961c:	49 8d 59 ff          	lea    -0x1(%r9),%rbx
    9620:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    9627:	00 
    9628:	0f 29 14 24          	movaps %xmm2,(%rsp)
    962c:	e8 8f 9e ff ff       	call   34c0 <memset@plt>
    9631:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    9636:	66 0f 6f 5c 24 10    	movdqa 0x10(%rsp),%xmm3
    963c:	48 89 c1             	mov    %rax,%rcx
    963f:	e9 c3 f4 ff ff       	jmp    8b07 <f12+0x697>
    9644:	45 31 ed             	xor    %r13d,%r13d
    9647:	e9 51 f9 ff ff       	jmp    8f9d <f12+0xb2d>
    964c:	48 8d 3d b1 5a 00 00 	lea    0x5ab1(%rip),%rdi        # f104 <_IO_stdin_used+0x104>
    9653:	e8 48 ab ff ff       	call   41a0 <fwp_trap>
    9658:	48 8d 3d 61 61 00 00 	lea    0x6161(%rip),%rdi        # f7c0 <_IO_stdin_used+0x7c0>
    965f:	e8 3c ab ff ff       	call   41a0 <fwp_trap>
    9664:	48 8d 3d 5d 62 00 00 	lea    0x625d(%rip),%rdi        # f8c8 <_IO_stdin_used+0x8c8>
    966b:	e8 30 ab ff ff       	call   41a0 <fwp_trap>
    9670:	e8 8b a0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9675:	45 31 f6             	xor    %r14d,%r14d
    9678:	e9 92 fe ff ff       	jmp    950f <f12+0x109f>
    967d:	4d 85 c9             	test   %r9,%r9
    9680:	0f 84 7a f4 ff ff    	je     8b00 <f12+0x690>
    9686:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    968b:	4c 89 e7             	mov    %r12,%rdi
    968e:	48 89 05 83 bd 01 00 	mov    %rax,0x1bd83(%rip)        # 25418 <fwp_cleanups>
    9695:	e8 96 b7 ff ff       	call   4e30 <fwp_tape_buffers_release>
    969a:	48 8b 0d bf 99 00 00 	mov    0x99bf(%rip),%rcx        # 13060 <stderr@GLIBC_2.2.5>
    96a1:	ba 13 00 00 00       	mov    $0x13,%edx
    96a6:	be 01 00 00 00       	mov    $0x1,%esi
    96ab:	48 8d 3d 56 59 00 00 	lea    0x5956(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    96b2:	e8 c9 9f ff ff       	call   3680 <fwrite@plt>
    96b7:	31 ff                	xor    %edi,%edi
    96b9:	e8 02 9f ff ff       	call   35c0 <fflush@plt>
    96be:	bf 66 00 00 00       	mov    $0x66,%edi
    96c3:	e8 d8 9f ff ff       	call   36a0 <_Exit@plt>
    96c8:	48 8d 3d 86 5a 00 00 	lea    0x5a86(%rip),%rdi        # f155 <_IO_stdin_used+0x155>
    96cf:	e8 cc aa ff ff       	call   41a0 <fwp_trap>
    96d4:	48 8d 3d 52 5a 00 00 	lea    0x5a52(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    96db:	e8 c0 aa ff ff       	call   41a0 <fwp_trap>
    96e0:	48 8d 3d 54 5a 00 00 	lea    0x5a54(%rip),%rdi        # f13b <_IO_stdin_used+0x13b>
    96e7:	e8 b4 aa ff ff       	call   41a0 <fwp_trap>
    96ec:	48 8d 3d 15 61 00 00 	lea    0x6115(%rip),%rdi        # f808 <_IO_stdin_used+0x808>
    96f3:	e8 a8 aa ff ff       	call   41a0 <fwp_trap>
    96f8:	e8 63 9d ff ff       	call   3460 <__stack_chk_fail@plt>
    96fd:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # f898 <_IO_stdin_used+0x898>
    9704:	e8 97 aa ff ff       	call   41a0 <fwp_trap>
    9709:	48 8d 3d 58 61 00 00 	lea    0x6158(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    9710:	e8 8b aa ff ff       	call   41a0 <fwp_trap>
    9715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    971c:	00 00 00 00 

0000000000009720 <fwp_owned_entry12>:
    9720:	f3 0f 1e fa          	endbr64
    9724:	48 8b 3f             	mov    (%rdi),%rdi
    9727:	e9 44 ed ff ff       	jmp    8470 <f12>
    972c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009730 <e12>:
    9730:	f3 0f 1e fa          	endbr64
    9734:	53                   	push   %rbx
    9735:	48 8b 1f             	mov    (%rdi),%rbx
    9738:	48 89 df             	mov    %rbx,%rdi
    973b:	e8 e0 ce ff ff       	call   6620 <fwp_rc_share>
    9740:	48 89 df             	mov    %rbx,%rdi
    9743:	e8 28 ed ff ff       	call   8470 <f12>
    9748:	48 89 c3             	mov    %rax,%rbx
    974b:	48 89 c7             	mov    %rax,%rdi
    974e:	e8 cd ce ff ff       	call   6620 <fwp_rc_share>
    9753:	48 89 d8             	mov    %rbx,%rax
    9756:	5b                   	pop    %rbx
    9757:	c3                   	ret
    9758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    975f:	00 

0000000000009760 <fwp_write>:
    9760:	41 57                	push   %r15
    9762:	41 56                	push   %r14
    9764:	41 55                	push   %r13
    9766:	41 54                	push   %r12
    9768:	55                   	push   %rbp
    9769:	53                   	push   %rbx
    976a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9771:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9778:	00 00 
    977a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9781:	00 
    9782:	49 89 d4             	mov    %rdx,%r12
    9785:	8b 12                	mov    (%rdx),%edx
    9787:	83 fa 19             	cmp    $0x19,%edx
    978a:	77 6a                	ja     97f6 <fwp_write+0x96>
    978c:	48 89 f5             	mov    %rsi,%rbp
    978f:	89 d0                	mov    %edx,%eax
    9791:	89 ce                	mov    %ecx,%esi
    9793:	48 89 fb             	mov    %rdi,%rbx
    9796:	48 8d 0d 73 62 00 00 	lea    0x6273(%rip),%rcx        # fa10 <_IO_stdin_used+0xa10>
    979d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    97a1:	48 01 c8             	add    %rcx,%rax
    97a4:	3e ff e0             	notrack jmp *%rax
    97a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    97ae:	00 00 
    97b0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    97b4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    97b8:	48 89 ca             	mov    %rcx,%rdx
    97bb:	48 85 c9             	test   %rcx,%rcx
    97be:	0f 88 9c 0c 00 00    	js     a460 <fwp_write+0xd00>
    97c4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97cb:	00 
    97cc:	48 89 c6             	mov    %rax,%rsi
    97cf:	4c 89 e7             	mov    %r12,%rdi
    97d2:	e8 69 a2 ff ff       	call   3a40 <fwp_fmt_u128>
    97d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    97de:	00 00 
    97e0:	4c 89 e7             	mov    %r12,%rdi
    97e3:	e8 68 9c ff ff       	call   3450 <strlen@plt>
    97e8:	4c 89 e6             	mov    %r12,%rsi
    97eb:	48 89 df             	mov    %rbx,%rdi
    97ee:	48 89 c2             	mov    %rax,%rdx
    97f1:	e8 7a a8 ff ff       	call   4070 <buf_put>
    97f6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    97fd:	00 
    97fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9805:	00 00 
    9807:	0f 85 28 04 00 00    	jne    9c35 <fwp_write+0x4d5>
    980d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9814:	5b                   	pop    %rbx
    9815:	5d                   	pop    %rbp
    9816:	41 5c                	pop    %r12
    9818:	41 5d                	pop    %r13
    981a:	41 5e                	pop    %r14
    981c:	41 5f                	pop    %r15
    981e:	c3                   	ret
    981f:	90                   	nop
    9820:	49 89 e9             	mov    %rbp,%r9
    9823:	4c 8d 05 57 59 00 00 	lea    0x5957(%rip),%r8        # f181 <_IO_stdin_used+0x181>
    982a:	b9 00 02 00 00       	mov    $0x200,%ecx
    982f:	ba 02 00 00 00       	mov    $0x2,%edx
    9834:	be 00 02 00 00       	mov    $0x200,%esi
    9839:	31 c0                	xor    %eax,%eax
    983b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9842:	00 
    9843:	e8 68 9b ff ff       	call   33b0 <__snprintf_chk@plt>
    9848:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    984f:	00 
    9850:	e8 fb 9b ff ff       	call   3450 <strlen@plt>
    9855:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    985c:	00 
    985d:	48 89 df             	mov    %rbx,%rdi
    9860:	48 89 c2             	mov    %rax,%rdx
    9863:	e8 08 a8 ff ff       	call   4070 <buf_put>
    9868:	eb 8c                	jmp    97f6 <fwp_write+0x96>
    986a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9870:	49 89 e9             	mov    %rbp,%r9
    9873:	4c 8d 05 02 59 00 00 	lea    0x5902(%rip),%r8        # f17c <_IO_stdin_used+0x17c>
    987a:	eb ae                	jmp    982a <fwp_write+0xca>
    987c:	0f 1f 40 00          	nopl   0x0(%rax)
    9880:	83 fa 13             	cmp    $0x13,%edx
    9883:	48 8d 05 e8 58 00 00 	lea    0x58e8(%rip),%rax        # f172 <_IO_stdin_used+0x172>
    988a:	48 8d 35 e6 58 00 00 	lea    0x58e6(%rip),%rsi        # f177 <_IO_stdin_used+0x177>
    9891:	ba 04 00 00 00       	mov    $0x4,%edx
    9896:	48 0f 44 f0          	cmove  %rax,%rsi
    989a:	45 31 ed             	xor    %r13d,%r13d
    989d:	e8 ce a7 ff ff       	call   4070 <buf_put>
    98a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    98a7:	0f 84 a3 08 00 00    	je     a150 <fwp_write+0x9f0>
    98ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    98b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    98b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    98bc:	48 89 df             	mov    %rbx,%rdi
    98bf:	49 0f 44 c5          	cmove  %r13,%rax
    98c3:	31 c9                	xor    %ecx,%ecx
    98c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    98ca:	e8 91 fe ff ff       	call   9760 <fwp_write>
    98cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    98d4:	0f 84 6e 09 00 00    	je     a248 <fwp_write+0xae8>
    98da:	49 83 c5 01          	add    $0x1,%r13
    98de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    98e2:	0f 83 68 08 00 00    	jae    a150 <fwp_write+0x9f0>
    98e8:	ba 02 00 00 00       	mov    $0x2,%edx
    98ed:	48 8d 35 cd 58 00 00 	lea    0x58cd(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    98f4:	48 89 df             	mov    %rbx,%rdi
    98f7:	e8 74 a7 ff ff       	call   4070 <buf_put>
    98fc:	eb af                	jmp    98ad <fwp_write+0x14d>
    98fe:	66 90                	xchg   %ax,%ax
    9900:	ba 06 00 00 00       	mov    $0x6,%edx
    9905:	48 8d 35 8e 58 00 00 	lea    0x588e(%rip),%rsi        # f19a <_IO_stdin_used+0x19a>
    990c:	48 83 c5 10          	add    $0x10,%rbp
    9910:	e8 5b a7 ff ff       	call   4070 <buf_put>
    9915:	48 89 ef             	mov    %rbp,%rdi
    9918:	e8 33 9b ff ff       	call   3450 <strlen@plt>
    991d:	48 89 ee             	mov    %rbp,%rsi
    9920:	48 89 df             	mov    %rbx,%rdi
    9923:	48 89 c2             	mov    %rax,%rdx
    9926:	e8 45 a7 ff ff       	call   4070 <buf_put>
    992b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9930:	ba 01 00 00 00       	mov    $0x1,%edx
    9935:	48 89 df             	mov    %rbx,%rdi
    9938:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    993d:	e8 2e a7 ff ff       	call   4070 <buf_put>
    9942:	e9 af fe ff ff       	jmp    97f6 <fwp_write+0x96>
    9947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    994e:	00 00 
    9950:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9957:	00 
    9958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    995f:	00 00 
    9961:	0f 85 ce 02 00 00    	jne    9c35 <fwp_write+0x4d5>
    9967:	ba 0a 00 00 00       	mov    $0xa,%edx
    996c:	48 8d 35 13 58 00 00 	lea    0x5813(%rip),%rsi        # f186 <_IO_stdin_used+0x186>
    9973:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    997a:	48 89 df             	mov    %rbx,%rdi
    997d:	5b                   	pop    %rbx
    997e:	5d                   	pop    %rbp
    997f:	41 5c                	pop    %r12
    9981:	41 5d                	pop    %r13
    9983:	41 5e                	pop    %r14
    9985:	41 5f                	pop    %r15
    9987:	e9 e4 a6 ff ff       	jmp    4070 <buf_put>
    998c:	0f 1f 40 00          	nopl   0x0(%rax)
    9990:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    9995:	4d 85 ed             	test   %r13,%r13
    9998:	0f 84 02 0c 00 00    	je     a5a0 <fwp_write+0xe40>
    999e:	48 8d 35 29 58 00 00 	lea    0x5829(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    99a5:	4c 89 ef             	mov    %r13,%rdi
    99a8:	e8 83 9b ff ff       	call   3530 <strcmp@plt>
    99ad:	41 89 c1             	mov    %eax,%r9d
    99b0:	85 c0                	test   %eax,%eax
    99b2:	0f 84 6c 0c 00 00    	je     a624 <fwp_write+0xec4>
    99b8:	4c 89 ef             	mov    %r13,%rdi
    99bb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    99c0:	e8 8b 9a ff ff       	call   3450 <strlen@plt>
    99c5:	4c 89 ee             	mov    %r13,%rsi
    99c8:	48 89 df             	mov    %rbx,%rdi
    99cb:	48 89 c2             	mov    %rax,%rdx
    99ce:	e8 9d a6 ff ff       	call   4070 <buf_put>
    99d3:	ba 01 00 00 00       	mov    $0x1,%edx
    99d8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    99dd:	48 89 df             	mov    %rbx,%rdi
    99e0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    99e5:	e8 86 a6 ff ff       	call   4070 <buf_put>
    99ea:	ba 01 00 00 00       	mov    $0x1,%edx
    99ef:	4c 89 fe             	mov    %r15,%rsi
    99f2:	48 89 df             	mov    %rbx,%rdi
    99f5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    99fa:	e8 71 a6 ff ff       	call   4070 <buf_put>
    99ff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    9a04:	45 31 f6             	xor    %r14d,%r14d
    9a07:	85 d2                	test   %edx,%edx
    9a09:	0f 8e 81 0a 00 00    	jle    a490 <fwp_write+0xd30>
    9a0f:	45 31 ed             	xor    %r13d,%r13d
    9a12:	4d 85 ed             	test   %r13,%r13
    9a15:	0f 85 75 07 00 00    	jne    a190 <fwp_write+0xa30>
    9a1b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    9a22:	00 
    9a23:	45 85 f6             	test   %r14d,%r14d
    9a26:	0f 84 84 07 00 00    	je     a1b0 <fwp_write+0xa50>
    9a2c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    9a31:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    9a36:	48 89 df             	mov    %rbx,%rdi
    9a39:	49 83 c5 01          	add    $0x1,%r13
    9a3d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    9a41:	31 c9                	xor    %ecx,%ecx
    9a43:	e8 18 fd ff ff       	call   9760 <fwp_write>
    9a48:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    9a4d:	7f c3                	jg     9a12 <fwp_write+0x2b2>
    9a4f:	45 85 f6             	test   %r14d,%r14d
    9a52:	0f 84 38 0a 00 00    	je     a490 <fwp_write+0xd30>
    9a58:	b8 29 00 00 00       	mov    $0x29,%eax
    9a5d:	ba 01 00 00 00       	mov    $0x1,%edx
    9a62:	4c 89 fe             	mov    %r15,%rsi
    9a65:	48 89 df             	mov    %rbx,%rdi
    9a68:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    9a6c:	e8 ff a5 ff ff       	call   4070 <buf_put>
    9a71:	e9 80 fd ff ff       	jmp    97f6 <fwp_write+0x96>
    9a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9a7d:	00 00 00 
    9a80:	ba 01 00 00 00       	mov    $0x1,%edx
    9a85:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9a8a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    9a8f:	e8 dc a5 ff ff       	call   4070 <buf_put>
    9a94:	48 85 ed             	test   %rbp,%rbp
    9a97:	0f 84 93 06 00 00    	je     a130 <fwp_write+0x9d0>
    9a9d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    9aa1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9aa6:	31 c9                	xor    %ecx,%ecx
    9aa8:	48 89 df             	mov    %rbx,%rdi
    9aab:	e8 b0 fc ff ff       	call   9760 <fwp_write>
    9ab0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    9ab4:	48 85 ed             	test   %rbp,%rbp
    9ab7:	0f 84 73 06 00 00    	je     a130 <fwp_write+0x9d0>
    9abd:	ba 02 00 00 00       	mov    $0x2,%edx
    9ac2:	48 8d 35 f8 56 00 00 	lea    0x56f8(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9ac9:	48 89 df             	mov    %rbx,%rdi
    9acc:	e8 9f a5 ff ff       	call   4070 <buf_put>
    9ad1:	eb ca                	jmp    9a9d <fwp_write+0x33d>
    9ad3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ad8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    9adc:	85 f6                	test   %esi,%esi
    9ade:	0f 84 fc 07 00 00    	je     a2e0 <fwp_write+0xb80>
    9ae4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9aeb:	00 
    9aec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9af3:	00 00 
    9af5:	0f 85 3a 01 00 00    	jne    9c35 <fwp_write+0x4d5>
    9afb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    9aff:	4c 89 ea             	mov    %r13,%rdx
    9b02:	e9 6c fe ff ff       	jmp    9973 <fwp_write+0x213>
    9b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b0e:	00 00 
    9b10:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    9b15:	ba 01 00 00 00       	mov    $0x1,%edx
    9b1a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    9b1f:	48 89 ee             	mov    %rbp,%rsi
    9b22:	e8 49 a5 ff ff       	call   4070 <buf_put>
    9b27:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    9b2c:	4c 89 e7             	mov    %r12,%rdi
    9b2f:	e8 1c 99 ff ff       	call   3450 <strlen@plt>
    9b34:	4c 89 e6             	mov    %r12,%rsi
    9b37:	48 89 df             	mov    %rbx,%rdi
    9b3a:	48 89 c2             	mov    %rax,%rdx
    9b3d:	e8 2e a5 ff ff       	call   4070 <buf_put>
    9b42:	ba 01 00 00 00       	mov    $0x1,%edx
    9b47:	48 89 ee             	mov    %rbp,%rsi
    9b4a:	48 89 df             	mov    %rbx,%rdi
    9b4d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    9b52:	e8 19 a5 ff ff       	call   4070 <buf_put>
    9b57:	e9 9a fc ff ff       	jmp    97f6 <fwp_write+0x96>
    9b5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b60:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    9b65:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    9b69:	0f 8a 8e 0b 00 00    	jp     a6fd <fwp_write+0xf9d>
    9b6f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9b73:	66 0f 54 05 95 5f 00 	andpd  0x5f95(%rip),%xmm0        # fb10 <msg.4+0x90>
    9b7a:	00 
    9b7b:	bd 01 00 00 00       	mov    $0x1,%ebp
    9b80:	66 0f 2e 05 c0 5f 00 	ucomisd 0x5fc0(%rip),%xmm0        # fb48 <msg.4+0xc8>
    9b87:	00 
    9b88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9b8f:	00 
    9b90:	0f 87 b2 09 00 00    	ja     a548 <fwp_write+0xde8>
    9b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9b9d:	00 00 00 
    9ba0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9ba4:	89 ee                	mov    %ebp,%esi
    9ba6:	4c 89 e7             	mov    %r12,%rdi
    9ba9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    9bae:	e8 0d a9 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9bb3:	31 f6                	xor    %esi,%esi
    9bb5:	4c 89 e7             	mov    %r12,%rdi
    9bb8:	e8 53 98 ff ff       	call   3410 <strtod@plt>
    9bbd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    9bc2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    9bc6:	7a 06                	jp     9bce <fwp_write+0x46e>
    9bc8:	0f 84 e9 01 00 00    	je     9db7 <fwp_write+0x657>
    9bce:	83 c5 01             	add    $0x1,%ebp
    9bd1:	83 fd 12             	cmp    $0x12,%ebp
    9bd4:	75 ca                	jne    9ba0 <fwp_write+0x440>
    9bd6:	be 11 00 00 00       	mov    $0x11,%esi
    9bdb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    9bdf:	4c 89 e7             	mov    %r12,%rdi
    9be2:	e8 d9 a8 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9be7:	e9 cb 01 00 00       	jmp    9db7 <fwp_write+0x657>
    9bec:	0f 1f 40 00          	nopl   0x0(%rax)
    9bf0:	48 83 fd 01          	cmp    $0x1,%rbp
    9bf4:	0f 84 e6 08 00 00    	je     a4e0 <fwp_write+0xd80>
    9bfa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    9bfe:	b8 02 00 00 00       	mov    $0x2,%eax
    9c03:	ba 01 00 00 00       	mov    $0x1,%edx
    9c08:	48 0f 44 d0          	cmove  %rax,%rdx
    9c0c:	48 8d 35 57 55 00 00 	lea    0x5557(%rip),%rsi        # f16a <_IO_stdin_used+0x16a>
    9c13:	48 8d 05 55 55 00 00 	lea    0x5555(%rip),%rax        # f16f <_IO_stdin_used+0x16f>
    9c1a:	48 0f 44 f0          	cmove  %rax,%rsi
    9c1e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9c25:	00 
    9c26:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c2d:	00 00 
    9c2f:	0f 84 3e fd ff ff    	je     9973 <fwp_write+0x213>
    9c35:	e8 26 98 ff ff       	call   3460 <__stack_chk_fail@plt>
    9c3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9c40:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9c45:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    9c4a:	e8 61 a3 ff ff       	call   3fb0 <buf_grow>
    9c4f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9c53:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9c59:	4c 03 0b             	add    (%rbx),%r9
    9c5c:	66 45 89 11          	mov    %r10w,(%r9)
    9c60:	45 85 e4             	test   %r12d,%r12d
    9c63:	0f 8e 07 05 00 00    	jle    a170 <fwp_write+0xa10>
    9c69:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9c70:	55 55 55 
    9c73:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9c78:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    9c7f:	aa aa aa 
    9c82:	49 83 c1 01          	add    $0x1,%r9
    9c86:	eb 45                	jmp    9ccd <fwp_write+0x56d>
    9c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9c8f:	00 
    9c90:	be 01 00 00 00       	mov    $0x1,%esi
    9c95:	b8 2d 00 00 00       	mov    $0x2d,%eax
    9c9a:	88 07                	mov    %al,(%rdi)
    9c9c:	48 89 e8             	mov    %rbp,%rax
    9c9f:	49 f7 e8             	imul   %r8
    9ca2:	48 89 e8             	mov    %rbp,%rax
    9ca5:	48 c1 f8 3f          	sar    $0x3f,%rax
    9ca9:	48 29 c2             	sub    %rax,%rdx
    9cac:	48 85 c9             	test   %rcx,%rcx
    9caf:	0f 95 c0             	setne  %al
    9cb2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9cb6:	48 83 ef 01          	sub    $0x1,%rdi
    9cba:	48 21 c5             	and    %rax,%rbp
    9cbd:	48 29 ea             	sub    %rbp,%rdx
    9cc0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9cc4:	49 39 f9             	cmp    %rdi,%r9
    9cc7:	0f 84 a3 04 00 00    	je     a170 <fwp_write+0xa10>
    9ccd:	48 89 e8             	mov    %rbp,%rax
    9cd0:	49 f7 e8             	imul   %r8
    9cd3:	48 89 e8             	mov    %rbp,%rax
    9cd6:	48 c1 f8 3f          	sar    $0x3f,%rax
    9cda:	48 89 d1             	mov    %rdx,%rcx
    9cdd:	48 29 c1             	sub    %rax,%rcx
    9ce0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9ce4:	48 89 e9             	mov    %rbp,%rcx
    9ce7:	48 29 c1             	sub    %rax,%rcx
    9cea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    9cee:	49 f7 e2             	mul    %r10
    9cf1:	b8 30 00 00 00       	mov    $0x30,%eax
    9cf6:	48 89 d6             	mov    %rdx,%rsi
    9cf9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    9cfd:	48 d1 ee             	shr    $1,%rsi
    9d00:	48 01 f2             	add    %rsi,%rdx
    9d03:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9d07:	48 29 d6             	sub    %rdx,%rsi
    9d0a:	74 8e                	je     9c9a <fwp_write+0x53a>
    9d0c:	48 83 fe 01          	cmp    $0x1,%rsi
    9d10:	0f 85 7a ff ff ff    	jne    9c90 <fwp_write+0x530>
    9d16:	31 f6                	xor    %esi,%esi
    9d18:	b8 2b 00 00 00       	mov    $0x2b,%eax
    9d1d:	e9 78 ff ff ff       	jmp    9c9a <fwp_write+0x53a>
    9d22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d28:	66 0f 6e cd          	movd   %ebp,%xmm1
    9d2c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    9d2f:	0f 8a c8 09 00 00    	jp     a6fd <fwp_write+0xf9d>
    9d35:	0f 28 c1             	movaps %xmm1,%xmm0
    9d38:	0f 54 05 c1 5d 00 00 	andps  0x5dc1(%rip),%xmm0        # fb00 <msg.4+0x80>
    9d3f:	0f 2e 05 be 52 00 00 	ucomiss 0x52be(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9d46:	0f 87 24 08 00 00    	ja     a570 <fwp_write+0xe10>
    9d4c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9d50:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9d56:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9d5d:	00 
    9d5e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9d62:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9d6e:	00 00 
    9d70:	44 89 ee             	mov    %r13d,%esi
    9d73:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9d78:	4c 89 e7             	mov    %r12,%rdi
    9d7b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9d80:	e8 3b a7 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9d85:	31 f6                	xor    %esi,%esi
    9d87:	4c 89 e7             	mov    %r12,%rdi
    9d8a:	e8 21 97 ff ff       	call   34b0 <strtof@plt>
    9d8f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9d94:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9d97:	7a 02                	jp     9d9b <fwp_write+0x63b>
    9d99:	74 1c                	je     9db7 <fwp_write+0x657>
    9d9b:	41 83 c5 01          	add    $0x1,%r13d
    9d9f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9da3:	75 cb                	jne    9d70 <fwp_write+0x610>
    9da5:	be 09 00 00 00       	mov    $0x9,%esi
    9daa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9daf:	4c 89 e7             	mov    %r12,%rdi
    9db2:	e8 09 a7 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    9db7:	4c 89 e7             	mov    %r12,%rdi
    9dba:	e8 71 a3 ff ff       	call   4130 <fwp_finish_float>
    9dbf:	e9 1c fa ff ff       	jmp    97e0 <fwp_write+0x80>
    9dc4:	0f 1f 40 00          	nopl   0x0(%rax)
    9dc8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    9dcc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9dd0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9dd7:	00 
    9dd8:	48 89 ef             	mov    %rbp,%rdi
    9ddb:	e8 60 9c ff ff       	call   3a40 <fwp_fmt_u128>
    9de0:	48 89 ef             	mov    %rbp,%rdi
    9de3:	e8 68 96 ff ff       	call   3450 <strlen@plt>
    9de8:	48 89 ee             	mov    %rbp,%rsi
    9deb:	48 89 df             	mov    %rbx,%rdi
    9dee:	48 89 c2             	mov    %rax,%rdx
    9df1:	e8 7a a2 ff ff       	call   4070 <buf_put>
    9df6:	e9 fb f9 ff ff       	jmp    97f6 <fwp_write+0x96>
    9dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9e00:	ba 06 00 00 00       	mov    $0x6,%edx
    9e05:	48 8d 35 b8 53 00 00 	lea    0x53b8(%rip),%rsi        # f1c4 <_IO_stdin_used+0x1c4>
    9e0c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9e12:	e8 59 a2 ff ff       	call   4070 <buf_put>
    9e17:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9e1e:	ff ff 7f 
    9e21:	48 23 55 00          	and    0x0(%rbp),%rdx
    9e25:	0f 84 86 02 00 00    	je     a0b1 <fwp_write+0x951>
    9e2b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9e30:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9e34:	48 85 d2             	test   %rdx,%rdx
    9e37:	0f 84 ae 00 00 00    	je     9eeb <fwp_write+0x78b>
    9e3d:	8b 0a                	mov    (%rdx),%ecx
    9e3f:	83 f9 1c             	cmp    $0x1c,%ecx
    9e42:	0f 84 58 06 00 00    	je     a4a0 <fwp_write+0xd40>
    9e48:	83 f9 1b             	cmp    $0x1b,%ecx
    9e4b:	0f 87 9a 00 00 00    	ja     9eeb <fwp_write+0x78b>
    9e51:	be 01 00 00 00       	mov    $0x1,%esi
    9e56:	48 d3 e6             	shl    %cl,%rsi
    9e59:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    9e5f:	0f 85 4b 04 00 00    	jne    a2b0 <fwp_write+0xb50>
    9e65:	f7 c6 84 04 00 00    	test   $0x484,%esi
    9e6b:	0f 85 0f 04 00 00    	jne    a280 <fwp_write+0xb20>
    9e71:	83 e6 21             	and    $0x21,%esi
    9e74:	74 75                	je     9eeb <fwp_write+0x78b>
    9e76:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    9e7b:	48 85 ff             	test   %rdi,%rdi
    9e7e:	79 07                	jns    9e87 <fwp_write+0x727>
    9e80:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9e84:	4c 01 ee             	add    %r13,%rsi
    9e87:	48 0f be 3e          	movsbq (%rsi),%rdi
    9e8b:	85 c9                	test   %ecx,%ecx
    9e8d:	40 0f b6 f7          	movzbl %dil,%esi
    9e91:	48 0f 44 f7          	cmove  %rdi,%rsi
    9e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e9c:	00 00 00 00 
    9ea0:	31 c9                	xor    %ecx,%ecx
    9ea2:	48 89 df             	mov    %rbx,%rdi
    9ea5:	49 83 c5 01          	add    $0x1,%r13
    9ea9:	e8 b2 f8 ff ff       	call   9760 <fwp_write>
    9eae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9eb5:	ff ff 7f 
    9eb8:	48 23 55 00          	and    0x0(%rbp),%rdx
    9ebc:	49 39 d5             	cmp    %rdx,%r13
    9ebf:	0f 83 ec 01 00 00    	jae    a0b1 <fwp_write+0x951>
    9ec5:	ba 02 00 00 00       	mov    $0x2,%edx
    9eca:	48 89 df             	mov    %rbx,%rdi
    9ecd:	48 8d 35 ed 52 00 00 	lea    0x52ed(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    9ed4:	e8 97 a1 ff ff       	call   4070 <buf_put>
    9ed9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9ede:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9ee2:	48 85 d2             	test   %rdx,%rdx
    9ee5:	0f 85 52 ff ff ff    	jne    9e3d <fwp_write+0x6dd>
    9eeb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9ef0:	48 85 ff             	test   %rdi,%rdi
    9ef3:	0f 88 cf 05 00 00    	js     a4c8 <fwp_write+0xd68>
    9ef9:	48 8b 31             	mov    (%rcx),%rsi
    9efc:	eb a2                	jmp    9ea0 <fwp_write+0x740>
    9efe:	66 90                	xchg   %ax,%ax
    9f00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f07:	00 
    9f08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f0f:	00 00 
    9f11:	0f 85 1e fd ff ff    	jne    9c35 <fwp_write+0x4d5>
    9f17:	ba 08 00 00 00       	mov    $0x8,%edx
    9f1c:	48 8d 35 6e 52 00 00 	lea    0x526e(%rip),%rsi        # f191 <_IO_stdin_used+0x191>
    9f23:	e9 4b fa ff ff       	jmp    9973 <fwp_write+0x213>
    9f28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f2f:	00 
    9f30:	89 e8                	mov    %ebp,%eax
    9f32:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9f39:	76 03                	jbe    9f3e <fwp_write+0x7de>
    9f3b:	8b 45 00             	mov    0x0(%rbp),%eax
    9f3e:	41 89 c6             	mov    %eax,%r14d
    9f41:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9f46:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    9f4b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    9f4f:	4c 89 ef             	mov    %r13,%rdi
    9f52:	e8 f9 94 ff ff       	call   3450 <strlen@plt>
    9f57:	4c 89 ee             	mov    %r13,%rsi
    9f5a:	48 89 df             	mov    %rbx,%rdi
    9f5d:	48 89 c2             	mov    %rax,%rdx
    9f60:	e8 0b a1 ff ff       	call   4070 <buf_put>
    9f65:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    9f6a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    9f6e:	85 f6                	test   %esi,%esi
    9f70:	0f 8e 80 f8 ff ff    	jle    97f6 <fwp_write+0x96>
    9f76:	45 31 ed             	xor    %r13d,%r13d
    9f79:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9f7e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9f83:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9f88:	ba 01 00 00 00       	mov    $0x1,%edx
    9f8d:	4c 89 fe             	mov    %r15,%rsi
    9f90:	48 89 04 24          	mov    %rax,(%rsp)
    9f94:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9f99:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    9f9d:	48 89 df             	mov    %rbx,%rdi
    9fa0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9fa4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9fa9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    9fae:	e8 bd a0 ff ff       	call   4070 <buf_put>
    9fb3:	41 8b 06             	mov    (%r14),%eax
    9fb6:	83 f8 0e             	cmp    $0xe,%eax
    9fb9:	0f 84 71 02 00 00    	je     a230 <fwp_write+0xad0>
    9fbf:	83 f8 10             	cmp    $0x10,%eax
    9fc2:	0f 84 38 02 00 00    	je     a200 <fwp_write+0xaa0>
    9fc8:	83 f8 0a             	cmp    $0xa,%eax
    9fcb:	0f 84 7f 04 00 00    	je     a450 <fwp_write+0xcf0>
    9fd1:	0f 8f f9 00 00 00    	jg     a0d0 <fwp_write+0x970>
    9fd7:	83 f8 03             	cmp    $0x3,%eax
    9fda:	0f 8f 50 04 00 00    	jg     a430 <fwp_write+0xcd0>
    9fe0:	85 c0                	test   %eax,%eax
    9fe2:	78 10                	js     9ff4 <fwp_write+0x894>
    9fe4:	48 8b 04 24          	mov    (%rsp),%rax
    9fe8:	48 c1 e8 3f          	shr    $0x3f,%rax
    9fec:	85 c0                	test   %eax,%eax
    9fee:	0f 85 f9 00 00 00    	jne    a0ed <fwp_write+0x98d>
    9ff4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9ff9:	48 8b 34 24          	mov    (%rsp),%rsi
    9ffd:	31 c9                	xor    %ecx,%ecx
    9fff:	48 89 df             	mov    %rbx,%rdi
    a002:	e8 59 f7 ff ff       	call   9760 <fwp_write>
    a007:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a00c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a011:	49 83 c5 01          	add    $0x1,%r13
    a015:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a019:	0f 8f 5f ff ff ff    	jg     9f7e <fwp_write+0x81e>
    a01f:	e9 d2 f7 ff ff       	jmp    97f6 <fwp_write+0x96>
    a024:	0f 1f 40 00          	nopl   0x0(%rax)
    a028:	ba 06 00 00 00       	mov    $0x6,%edx
    a02d:	48 8d 35 83 51 00 00 	lea    0x5183(%rip),%rsi        # f1b7 <_IO_stdin_used+0x1b7>
    a034:	45 31 ed             	xor    %r13d,%r13d
    a037:	e8 34 a0 ff ff       	call   4070 <buf_put>
    a03c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a041:	75 19                	jne    a05c <fwp_write+0x8fc>
    a043:	eb 6c                	jmp    a0b1 <fwp_write+0x951>
    a045:	0f 1f 00             	nopl   (%rax)
    a048:	ba 02 00 00 00       	mov    $0x2,%edx
    a04d:	48 8d 35 6d 51 00 00 	lea    0x516d(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a054:	48 89 df             	mov    %rbx,%rdi
    a057:	e8 14 a0 ff ff       	call   4070 <buf_put>
    a05c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a062:	b9 00 02 00 00       	mov    $0x200,%ecx
    a067:	31 c0                	xor    %eax,%eax
    a069:	49 83 c5 01          	add    $0x1,%r13
    a06d:	4c 8d 05 4a 51 00 00 	lea    0x514a(%rip),%r8        # f1be <_IO_stdin_used+0x1be>
    a074:	ba 02 00 00 00       	mov    $0x2,%edx
    a079:	be 00 02 00 00       	mov    $0x200,%esi
    a07e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a085:	00 
    a086:	e8 25 93 ff ff       	call   33b0 <__snprintf_chk@plt>
    a08b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a092:	00 
    a093:	e8 b8 93 ff ff       	call   3450 <strlen@plt>
    a098:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a09f:	00 
    a0a0:	48 89 df             	mov    %rbx,%rdi
    a0a3:	48 89 c2             	mov    %rax,%rdx
    a0a6:	e8 c5 9f ff ff       	call   4070 <buf_put>
    a0ab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a0af:	72 97                	jb     a048 <fwp_write+0x8e8>
    a0b1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a0b6:	ba 01 00 00 00       	mov    $0x1,%edx
    a0bb:	48 89 df             	mov    %rbx,%rdi
    a0be:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a0c3:	e8 a8 9f ff ff       	call   4070 <buf_put>
    a0c8:	e9 29 f7 ff ff       	jmp    97f6 <fwp_write+0x96>
    a0cd:	0f 1f 00             	nopl   (%rax)
    a0d0:	83 f8 0b             	cmp    $0xb,%eax
    a0d3:	0f 85 1b ff ff ff    	jne    9ff4 <fwp_write+0x894>
    a0d9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a0de:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a0e2:	83 e0 01             	and    $0x1,%eax
    a0e5:	85 c0                	test   %eax,%eax
    a0e7:	0f 84 07 ff ff ff    	je     9ff4 <fwp_write+0x894>
    a0ed:	4c 89 fe             	mov    %r15,%rsi
    a0f0:	48 89 df             	mov    %rbx,%rdi
    a0f3:	ba 01 00 00 00       	mov    $0x1,%edx
    a0f8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a0fd:	e8 6e 9f ff ff       	call   4070 <buf_put>
    a102:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a107:	48 8b 34 24          	mov    (%rsp),%rsi
    a10b:	31 c9                	xor    %ecx,%ecx
    a10d:	48 89 df             	mov    %rbx,%rdi
    a110:	e8 4b f6 ff ff       	call   9760 <fwp_write>
    a115:	ba 01 00 00 00       	mov    $0x1,%edx
    a11a:	4c 89 fe             	mov    %r15,%rsi
    a11d:	48 89 df             	mov    %rbx,%rdi
    a120:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a125:	e8 46 9f ff ff       	call   4070 <buf_put>
    a12a:	e9 d8 fe ff ff       	jmp    a007 <fwp_write+0x8a7>
    a12f:	90                   	nop
    a130:	ba 01 00 00 00       	mov    $0x1,%edx
    a135:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a13a:	48 89 df             	mov    %rbx,%rdi
    a13d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a142:	e8 29 9f ff ff       	call   4070 <buf_put>
    a147:	e9 aa f6 ff ff       	jmp    97f6 <fwp_write+0x96>
    a14c:	0f 1f 40 00          	nopl   0x0(%rax)
    a150:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a155:	ba 01 00 00 00       	mov    $0x1,%edx
    a15a:	48 89 df             	mov    %rbx,%rdi
    a15d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a162:	e8 09 9f ff ff       	call   4070 <buf_put>
    a167:	e9 8a f6 ff ff       	jmp    97f6 <fwp_write+0x96>
    a16c:	0f 1f 40 00          	nopl   0x0(%rax)
    a170:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a174:	48 8b 13             	mov    (%rbx),%rdx
    a177:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a17c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a180:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a184:	e9 6d f6 ff ff       	jmp    97f6 <fwp_write+0x96>
    a189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a190:	ba 02 00 00 00       	mov    $0x2,%edx
    a195:	48 8d 35 25 50 00 00 	lea    0x5025(%rip),%rsi        # f1c1 <_IO_stdin_used+0x1c1>
    a19c:	48 89 df             	mov    %rbx,%rdi
    a19f:	e8 cc 9e ff ff       	call   4070 <buf_put>
    a1a4:	e9 72 f8 ff ff       	jmp    9a1b <fwp_write+0x2bb>
    a1a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a1b0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a1b5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a1ba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a1be:	48 89 f7             	mov    %rsi,%rdi
    a1c1:	48 89 34 24          	mov    %rsi,(%rsp)
    a1c5:	e8 86 92 ff ff       	call   3450 <strlen@plt>
    a1ca:	48 8b 34 24          	mov    (%rsp),%rsi
    a1ce:	48 89 df             	mov    %rbx,%rdi
    a1d1:	48 89 c2             	mov    %rax,%rdx
    a1d4:	e8 97 9e ff ff       	call   4070 <buf_put>
    a1d9:	ba 03 00 00 00       	mov    $0x3,%edx
    a1de:	48 8d 35 ff 4f 00 00 	lea    0x4fff(%rip),%rsi        # f1e4 <_IO_stdin_used+0x1e4>
    a1e5:	48 89 df             	mov    %rbx,%rdi
    a1e8:	e8 83 9e ff ff       	call   4070 <buf_put>
    a1ed:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a1f2:	e9 35 f8 ff ff       	jmp    9a2c <fwp_write+0x2cc>
    a1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1fe:	00 00 
    a200:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a205:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a209:	48 85 ff             	test   %rdi,%rdi
    a20c:	0f 84 e2 fd ff ff    	je     9ff4 <fwp_write+0x894>
    a212:	48 8d 35 b5 4f 00 00 	lea    0x4fb5(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    a219:	e8 12 93 ff ff       	call   3530 <strcmp@plt>
    a21e:	85 c0                	test   %eax,%eax
    a220:	0f 95 c0             	setne  %al
    a223:	0f b6 c0             	movzbl %al,%eax
    a226:	e9 c1 fd ff ff       	jmp    9fec <fwp_write+0x88c>
    a22b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a230:	31 c0                	xor    %eax,%eax
    a232:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a239:	00 
    a23a:	0f 97 c0             	seta   %al
    a23d:	e9 aa fd ff ff       	jmp    9fec <fwp_write+0x88c>
    a242:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a248:	48 89 df             	mov    %rbx,%rdi
    a24b:	ba 02 00 00 00       	mov    $0x2,%edx
    a250:	48 8d 35 74 4f 00 00 	lea    0x4f74(%rip),%rsi        # f1cb <_IO_stdin_used+0x1cb>
    a257:	e8 14 9e ff ff       	call   4070 <buf_put>
    a25c:	4c 89 e8             	mov    %r13,%rax
    a25f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a264:	31 c9                	xor    %ecx,%ecx
    a266:	48 c1 e0 04          	shl    $0x4,%rax
    a26a:	48 89 df             	mov    %rbx,%rdi
    a26d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a272:	e8 e9 f4 ff ff       	call   9760 <fwp_write>
    a277:	e9 5e f6 ff ff       	jmp    98da <fwp_write+0x17a>
    a27c:	0f 1f 40 00          	nopl   0x0(%rax)
    a280:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a285:	48 85 ff             	test   %rdi,%rdi
    a288:	79 0c                	jns    a296 <fwp_write+0xb36>
    a28a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a291:	00 
    a292:	48 03 75 10          	add    0x10(%rbp),%rsi
    a296:	48 63 3e             	movslq (%rsi),%rdi
    a299:	83 f9 02             	cmp    $0x2,%ecx
    a29c:	89 fe                	mov    %edi,%esi
    a29e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a2a2:	e9 f9 fb ff ff       	jmp    9ea0 <fwp_write+0x740>
    a2a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a2ae:	00 00 
    a2b0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a2b5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a2ba:	48 85 ff             	test   %rdi,%rdi
    a2bd:	0f 88 0f 03 00 00    	js     a5d2 <fwp_write+0xe72>
    a2c3:	49 0f bf 38          	movswq (%r8),%rdi
    a2c7:	83 f9 01             	cmp    $0x1,%ecx
    a2ca:	0f b7 f7             	movzwl %di,%esi
    a2cd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a2d1:	e9 ca fb ff ff       	jmp    9ea0 <fwp_write+0x740>
    a2d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2dd:	00 00 00 
    a2e0:	ba 01 00 00 00       	mov    $0x1,%edx
    a2e5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a2ea:	48 83 c5 08          	add    $0x8,%rbp
    a2ee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a2f3:	e8 78 9d ff ff       	call   4070 <buf_put>
    a2f8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a2fd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a302:	4d 85 ed             	test   %r13,%r13
    a305:	75 46                	jne    a34d <fwp_write+0xbed>
    a307:	e9 04 01 00 00       	jmp    a410 <fwp_write+0xcb0>
    a30c:	0f 1f 40 00          	nopl   0x0(%rax)
    a310:	41 80 f9 09          	cmp    $0x9,%r9b
    a314:	0f 84 d6 00 00 00    	je     a3f0 <fwp_write+0xc90>
    a31a:	41 80 f9 0a          	cmp    $0xa,%r9b
    a31e:	0f 85 9c 00 00 00    	jne    a3c0 <fwp_write+0xc60>
    a324:	ba 02 00 00 00       	mov    $0x2,%edx
    a329:	48 8d 35 77 4e 00 00 	lea    0x4e77(%rip),%rsi        # f1a7 <_IO_stdin_used+0x1a7>
    a330:	48 89 df             	mov    %rbx,%rdi
    a333:	e8 38 9d ff ff       	call   4070 <buf_put>
    a338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a33f:	00 
    a340:	48 83 c5 01          	add    $0x1,%rbp
    a344:	49 39 ec             	cmp    %rbp,%r12
    a347:	0f 84 c3 00 00 00    	je     a410 <fwp_write+0xcb0>
    a34d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    a352:	41 80 f9 0d          	cmp    $0xd,%r9b
    a356:	74 28                	je     a380 <fwp_write+0xc20>
    a358:	7e b6                	jle    a310 <fwp_write+0xbb0>
    a35a:	41 80 f9 22          	cmp    $0x22,%r9b
    a35e:	74 40                	je     a3a0 <fwp_write+0xc40>
    a360:	41 80 f9 5c          	cmp    $0x5c,%r9b
    a364:	75 5a                	jne    a3c0 <fwp_write+0xc60>
    a366:	ba 02 00 00 00       	mov    $0x2,%edx
    a36b:	48 8d 35 32 4e 00 00 	lea    0x4e32(%rip),%rsi        # f1a4 <_IO_stdin_used+0x1a4>
    a372:	48 89 df             	mov    %rbx,%rdi
    a375:	e8 f6 9c ff ff       	call   4070 <buf_put>
    a37a:	eb c4                	jmp    a340 <fwp_write+0xbe0>
    a37c:	0f 1f 40 00          	nopl   0x0(%rax)
    a380:	ba 02 00 00 00       	mov    $0x2,%edx
    a385:	48 8d 35 21 4e 00 00 	lea    0x4e21(%rip),%rsi        # f1ad <_IO_stdin_used+0x1ad>
    a38c:	48 89 df             	mov    %rbx,%rdi
    a38f:	e8 dc 9c ff ff       	call   4070 <buf_put>
    a394:	eb aa                	jmp    a340 <fwp_write+0xbe0>
    a396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a39d:	00 00 00 
    a3a0:	ba 02 00 00 00       	mov    $0x2,%edx
    a3a5:	48 8d 35 f5 4d 00 00 	lea    0x4df5(%rip),%rsi        # f1a1 <_IO_stdin_used+0x1a1>
    a3ac:	48 89 df             	mov    %rbx,%rdi
    a3af:	e8 bc 9c ff ff       	call   4070 <buf_put>
    a3b4:	eb 8a                	jmp    a340 <fwp_write+0xbe0>
    a3b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a3bd:	00 00 00 
    a3c0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    a3c4:	0f 86 2e 01 00 00    	jbe    a4f8 <fwp_write+0xd98>
    a3ca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    a3ce:	0f 84 24 01 00 00    	je     a4f8 <fwp_write+0xd98>
    a3d4:	ba 01 00 00 00       	mov    $0x1,%edx
    a3d9:	4c 89 fe             	mov    %r15,%rsi
    a3dc:	48 89 df             	mov    %rbx,%rdi
    a3df:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    a3e4:	e8 87 9c ff ff       	call   4070 <buf_put>
    a3e9:	e9 52 ff ff ff       	jmp    a340 <fwp_write+0xbe0>
    a3ee:	66 90                	xchg   %ax,%ax
    a3f0:	ba 02 00 00 00       	mov    $0x2,%edx
    a3f5:	48 8d 35 ae 4d 00 00 	lea    0x4dae(%rip),%rsi        # f1aa <_IO_stdin_used+0x1aa>
    a3fc:	48 89 df             	mov    %rbx,%rdi
    a3ff:	e8 6c 9c ff ff       	call   4070 <buf_put>
    a404:	e9 37 ff ff ff       	jmp    a340 <fwp_write+0xbe0>
    a409:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a410:	ba 01 00 00 00       	mov    $0x1,%edx
    a415:	4c 89 fe             	mov    %r15,%rsi
    a418:	48 89 df             	mov    %rbx,%rdi
    a41b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a420:	e8 4b 9c ff ff       	call   4070 <buf_put>
    a425:	e9 cc f3 ff ff       	jmp    97f6 <fwp_write+0x96>
    a42a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a430:	83 f8 04             	cmp    $0x4,%eax
    a433:	0f 85 bb fb ff ff    	jne    9ff4 <fwp_write+0x894>
    a439:	48 8b 04 24          	mov    (%rsp),%rax
    a43d:	48 8b 40 08          	mov    0x8(%rax),%rax
    a441:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    a446:	48 c1 e8 3f          	shr    $0x3f,%rax
    a44a:	e9 96 fc ff ff       	jmp    a0e5 <fwp_write+0x985>
    a44f:	90                   	nop
    a450:	8b 0c 24             	mov    (%rsp),%ecx
    a453:	31 c0                	xor    %eax,%eax
    a455:	85 c9                	test   %ecx,%ecx
    a457:	0f 98 c0             	sets   %al
    a45a:	e9 86 fc ff ff       	jmp    a0e5 <fwp_write+0x985>
    a45f:	90                   	nop
    a460:	48 f7 d8             	neg    %rax
    a463:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    a46a:	00 
    a46b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    a472:	2d 
    a473:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a47a:	00 
    a47b:	48 83 d2 00          	adc    $0x0,%rdx
    a47f:	48 89 c6             	mov    %rax,%rsi
    a482:	48 f7 da             	neg    %rdx
    a485:	e8 b6 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a48a:	e9 51 f3 ff ff       	jmp    97e0 <fwp_write+0x80>
    a48f:	90                   	nop
    a490:	b8 7d 00 00 00       	mov    $0x7d,%eax
    a495:	e9 c3 f5 ff ff       	jmp    9a5d <fwp_write+0x2fd>
    a49a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a4a0:	4c 89 e9             	mov    %r13,%rcx
    a4a3:	48 c1 e1 04          	shl    $0x4,%rcx
    a4a7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    a4ac:	48 85 ff             	test   %rdi,%rdi
    a4af:	0f 89 eb f9 ff ff    	jns    9ea0 <fwp_write+0x740>
    a4b5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a4b9:	48 89 ce             	mov    %rcx,%rsi
    a4bc:	e9 df f9 ff ff       	jmp    9ea0 <fwp_write+0x740>
    a4c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4c8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a4cf:	00 
    a4d0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    a4d4:	e9 20 fa ff ff       	jmp    9ef9 <fwp_write+0x799>
    a4d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4e0:	ba 02 00 00 00       	mov    $0x2,%edx
    a4e5:	48 8d 35 80 4c 00 00 	lea    0x4c80(%rip),%rsi        # f16c <_IO_stdin_used+0x16c>
    a4ec:	e9 2d f7 ff ff       	jmp    9c1e <fwp_write+0x4be>
    a4f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4f8:	4c 8d 05 b1 4c 00 00 	lea    0x4cb1(%rip),%r8        # f1b0 <_IO_stdin_used+0x1b0>
    a4ff:	b9 10 00 00 00       	mov    $0x10,%ecx
    a504:	31 c0                	xor    %eax,%eax
    a506:	ba 02 00 00 00       	mov    $0x2,%edx
    a50b:	be 10 00 00 00       	mov    $0x10,%esi
    a510:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a517:	00 
    a518:	e8 93 8e ff ff       	call   33b0 <__snprintf_chk@plt>
    a51d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a524:	00 
    a525:	e8 26 8f ff ff       	call   3450 <strlen@plt>
    a52a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a531:	00 
    a532:	48 89 df             	mov    %rbx,%rdi
    a535:	48 89 c2             	mov    %rax,%rdx
    a538:	e8 33 9b ff ff       	call   4070 <buf_put>
    a53d:	e9 fe fd ff ff       	jmp    a340 <fwp_write+0xbe0>
    a542:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a548:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a54c:	48 8d 35 13 4c 00 00 	lea    0x4c13(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a553:	48 8d 05 0b 4c 00 00 	lea    0x4c0b(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a55a:	4c 89 e7             	mov    %r12,%rdi
    a55d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    a561:	48 0f 46 f0          	cmovbe %rax,%rsi
    a565:	e8 86 8e ff ff       	call   33f0 <strcpy@plt>
    a56a:	e9 71 f2 ff ff       	jmp    97e0 <fwp_write+0x80>
    a56f:	90                   	nop
    a570:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a574:	48 8d 35 eb 4b 00 00 	lea    0x4beb(%rip),%rsi        # f166 <_IO_stdin_used+0x166>
    a57b:	48 8d 05 e3 4b 00 00 	lea    0x4be3(%rip),%rax        # f165 <_IO_stdin_used+0x165>
    a582:	0f 2f c8             	comiss %xmm0,%xmm1
    a585:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a58c:	00 
    a58d:	4c 89 e7             	mov    %r12,%rdi
    a590:	48 0f 46 f0          	cmovbe %rax,%rsi
    a594:	e8 57 8e ff ff       	call   33f0 <strcpy@plt>
    a599:	e9 42 f2 ff ff       	jmp    97e0 <fwp_write+0x80>
    a59e:	66 90                	xchg   %ax,%ax
    a5a0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    a5a5:	45 85 c0             	test   %r8d,%r8d
    a5a8:	75 34                	jne    a5de <fwp_write+0xe7e>
    a5aa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a5b1:	00 
    a5b2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a5b9:	00 00 
    a5bb:	0f 85 74 f6 ff ff    	jne    9c35 <fwp_write+0x4d5>
    a5c1:	ba 02 00 00 00       	mov    $0x2,%edx
    a5c6:	48 8d 35 14 4c 00 00 	lea    0x4c14(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    a5cd:	e9 a1 f3 ff ff       	jmp    9973 <fwp_write+0x213>
    a5d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a5d6:	49 89 f0             	mov    %rsi,%r8
    a5d9:	e9 e5 fc ff ff       	jmp    a2c3 <fwp_write+0xb63>
    a5de:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    a5e3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a5e8:	85 ff                	test   %edi,%edi
    a5ea:	0f 84 fa f3 ff ff    	je     99ea <fwp_write+0x28a>
    a5f0:	ba 01 00 00 00       	mov    $0x1,%edx
    a5f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a5fa:	48 89 df             	mov    %rbx,%rdi
    a5fd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a602:	e8 69 9a ff ff       	call   4070 <buf_put>
    a607:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    a60c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a611:	41 be 01 00 00 00    	mov    $0x1,%r14d
    a617:	85 c0                	test   %eax,%eax
    a619:	0f 8f f0 f3 ff ff    	jg     9a0f <fwp_write+0x2af>
    a61f:	e9 34 f4 ff ff       	jmp    9a58 <fwp_write+0x2f8>
    a624:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a628:	49 89 c5             	mov    %rax,%r13
    a62b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a630:	49 89 c4             	mov    %rax,%r12
    a633:	49 c1 fd 3f          	sar    $0x3f,%r13
    a637:	4c 09 e8             	or     %r13,%rax
    a63a:	0f 84 a7 00 00 00    	je     a6e7 <fwp_write+0xf87>
    a640:	48 8d 2d d9 6d 00 00 	lea    0x6dd9(%rip),%rbp        # 11420 <units.1>
    a647:	4d 89 e7             	mov    %r12,%r15
    a64a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    a64e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    a653:	4c 89 ff             	mov    %r15,%rdi
    a656:	4c 89 ee             	mov    %r13,%rsi
    a659:	44 89 0c 24          	mov    %r9d,(%rsp)
    a65d:	48 99                	cqto
    a65f:	48 89 d1             	mov    %rdx,%rcx
    a662:	48 89 c2             	mov    %rax,%rdx
    a665:	e8 96 41 00 00       	call   e800 <__divmodti4>
    a66a:	44 8b 0c 24          	mov    (%rsp),%r9d
    a66e:	48 89 c1             	mov    %rax,%rcx
    a671:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a676:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    a67b:	0f 84 94 00 00 00    	je     a715 <fwp_write+0xfb5>
    a681:	41 83 c1 01          	add    $0x1,%r9d
    a685:	48 83 c5 10          	add    $0x10,%rbp
    a689:	41 83 f9 05          	cmp    $0x5,%r9d
    a68d:	75 bb                	jne    a64a <fwp_write+0xeea>
    a68f:	4d 85 ed             	test   %r13,%r13
    a692:	79 53                	jns    a6e7 <fwp_write+0xf87>
    a694:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a699:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a69e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a6a3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a6a8:	48 99                	cqto
    a6aa:	48 f7 d8             	neg    %rax
    a6ad:	48 83 d2 00          	adc    $0x0,%rdx
    a6b1:	48 89 c6             	mov    %rax,%rsi
    a6b4:	48 f7 da             	neg    %rdx
    a6b7:	e8 84 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a6bc:	49 89 e8             	mov    %rbp,%r8
    a6bf:	ba 00 02 00 00       	mov    $0x200,%edx
    a6c4:	be 02 00 00 00       	mov    $0x2,%esi
    a6c9:	31 c0                	xor    %eax,%eax
    a6cb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a6d2:	00 
    a6d3:	48 8d 0d 02 4b 00 00 	lea    0x4b02(%rip),%rcx        # f1dc <_IO_stdin_used+0x1dc>
    a6da:	4c 89 e7             	mov    %r12,%rdi
    a6dd:	e8 fe 8f ff ff       	call   36e0 <__sprintf_chk@plt>
    a6e2:	e9 f9 f0 ff ff       	jmp    97e0 <fwp_write+0x80>
    a6e7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a6ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a6f1:	31 d2                	xor    %edx,%edx
    a6f3:	48 89 ef             	mov    %rbp,%rdi
    a6f6:	e8 45 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a6fb:	eb bf                	jmp    a6bc <fwp_write+0xf5c>
    a6fd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    a704:	4e 61 4e 00 
    a708:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a70f:	00 
    a710:	e9 cb f0 ff ff       	jmp    97e0 <fwp_write+0x80>
    a715:	44 89 0c 24          	mov    %r9d,(%rsp)
    a719:	48 89 c8             	mov    %rcx,%rax
    a71c:	48 85 d2             	test   %rdx,%rdx
    a71f:	78 51                	js     a772 <fwp_write+0x1012>
    a721:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a726:	48 89 c6             	mov    %rax,%rsi
    a729:	48 89 ef             	mov    %rbp,%rdi
    a72c:	e8 0f 93 ff ff       	call   3a40 <fwp_fmt_u128>
    a731:	44 8b 0c 24          	mov    (%rsp),%r9d
    a735:	49 63 c1             	movslq %r9d,%rax
    a738:	49 89 e8             	mov    %rbp,%r8
    a73b:	ba 00 02 00 00       	mov    $0x200,%edx
    a740:	be 02 00 00 00       	mov    $0x2,%esi
    a745:	48 c1 e0 04          	shl    $0x4,%rax
    a749:	48 8d 3d d0 6c 00 00 	lea    0x6cd0(%rip),%rdi        # 11420 <units.1>
    a750:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a757:	00 
    a758:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    a75c:	48 8d 0d 74 4a 00 00 	lea    0x4a74(%rip),%rcx        # f1d7 <_IO_stdin_used+0x1d7>
    a763:	4c 89 e7             	mov    %r12,%rdi
    a766:	31 c0                	xor    %eax,%eax
    a768:	e8 73 8f ff ff       	call   36e0 <__sprintf_chk@plt>
    a76d:	e9 6e f0 ff ff       	jmp    97e0 <fwp_write+0x80>
    a772:	48 f7 d8             	neg    %rax
    a775:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    a77a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    a77f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    a784:	48 83 d2 00          	adc    $0x0,%rdx
    a788:	48 89 c6             	mov    %rax,%rsi
    a78b:	48 f7 da             	neg    %rdx
    a78e:	e8 ad 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a793:	44 8b 0c 24          	mov    (%rsp),%r9d
    a797:	eb 9c                	jmp    a735 <fwp_write+0xfd5>
    a799:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000a7a0 <fwp_hof0.constprop.0>:
    a7a0:	55                   	push   %rbp
    a7a1:	48 89 e5             	mov    %rsp,%rbp
    a7a4:	41 57                	push   %r15
    a7a6:	41 56                	push   %r14
    a7a8:	41 55                	push   %r13
    a7aa:	41 54                	push   %r12
    a7ac:	53                   	push   %rbx
    a7ad:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
    a7b4:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
    a7bb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    a7c2:	00 00 
    a7c4:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    a7c8:	31 c0                	xor    %eax,%eax
    a7ca:	48 85 f6             	test   %rsi,%rsi
    a7cd:	0f 84 86 06 00 00    	je     ae59 <fwp_hof0.constprop.0+0x6b9>
    a7d3:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
    a7d7:	49 89 f7             	mov    %rsi,%r15
    a7da:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
    a7e1:	48 8d 35 98 8f 01 00 	lea    0x18f98(%rip),%rsi        # 23780 <fwp_heap>
    a7e8:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a7ef:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    a7f6:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    a7fd:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    a801:	48 c1 e2 10          	shl    $0x10,%rdx
    a805:	48 39 d0             	cmp    %rdx,%rax
    a808:	73 5d                	jae    a867 <fwp_hof0.constprop.0+0xc7>
    a80a:	48 89 c2             	mov    %rax,%rdx
    a80d:	48 c1 ea 10          	shr    $0x10,%rdx
    a811:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a815:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    a81c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a820:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a824:	48 85 ff             	test   %rdi,%rdi
    a827:	74 3e                	je     a867 <fwp_hof0.constprop.0+0xc7>
    a829:	0f b6 0a             	movzbl (%rdx),%ecx
    a82c:	80 f9 02             	cmp    $0x2,%cl
    a82f:	0f 84 cd 0a 00 00    	je     b302 <fwp_hof0.constprop.0+0xb62>
    a835:	80 f9 01             	cmp    $0x1,%cl
    a838:	75 2d                	jne    a867 <fwp_hof0.constprop.0+0xc7>
    a83a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a83d:	0f b7 c0             	movzwl %ax,%eax
    a840:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a843:	48 0f af c1          	imul   %rcx,%rax
    a847:	48 c1 e8 20          	shr    $0x20,%rax
    a84b:	48 39 d0             	cmp    %rdx,%rax
    a84e:	73 17                	jae    a867 <fwp_hof0.constprop.0+0xc7>
    a850:	48 01 c7             	add    %rax,%rdi
    a853:	0f b6 07             	movzbl (%rdi),%eax
    a856:	84 c0                	test   %al,%al
    a858:	74 0d                	je     a867 <fwp_hof0.constprop.0+0xc7>
    a85a:	3c fd                	cmp    $0xfd,%al
    a85c:	0f 87 7e 0b 00 00    	ja     b3e0 <fwp_hof0.constprop.0+0xc40>
    a862:	83 c0 01             	add    $0x1,%eax
    a865:	88 07                	mov    %al,(%rdi)
    a867:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
    a86e:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
    a875:	48 c7 85 60 ff ff ff 	movq   $0xc7,-0xa0(%rbp)
    a87c:	c7 00 00 00 
    a880:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a884:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a888:	48 8b 15 49 ab 01 00 	mov    0x1ab49(%rip),%rdx        # 253d8 <fwp_fns>
    a88f:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
    a893:	48 8d 05 7e 87 00 00 	lea    0x877e(%rip),%rax        # 13018 <fc12>
    a89a:	44 8b 20             	mov    (%rax),%r12d
    a89d:	49 c1 e4 05          	shl    $0x5,%r12
    a8a1:	49 01 d4             	add    %rdx,%r12
    a8a4:	49 8b 4c 24 18       	mov    0x18(%r12),%rcx
    a8a9:	48 85 c9             	test   %rcx,%rcx
    a8ac:	0f 84 1d 0a 00 00    	je     b2cf <fwp_hof0.constprop.0+0xb2f>
    a8b2:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    a8b7:	0f 84 7b 08 00 00    	je     b138 <fwp_hof0.constprop.0+0x998>
    a8bd:	48 8d 3d bc 8e 01 00 	lea    0x18ebc(%rip),%rdi        # 23780 <fwp_heap>
    a8c4:	48 8d 05 4d 87 00 00 	lea    0x874d(%rip),%rax        # 13018 <fc12>
    a8cb:	48 8b b7 d8 13 00 00 	mov    0x13d8(%rdi),%rsi
    a8d2:	48 2b 87 b0 13 00 00 	sub    0x13b0(%rdi),%rax
    a8d9:	48 89 f1             	mov    %rsi,%rcx
    a8dc:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
    a8e0:	48 c1 e1 10          	shl    $0x10,%rcx
    a8e4:	48 39 c8             	cmp    %rcx,%rax
    a8e7:	73 5f                	jae    a948 <fwp_hof0.constprop.0+0x1a8>
    a8e9:	48 89 c1             	mov    %rax,%rcx
    a8ec:	48 c1 e9 10          	shr    $0x10,%rcx
    a8f0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a8f4:	48 8b 8f f8 13 00 00 	mov    0x13f8(%rdi),%rcx
    a8fb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a8ff:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    a903:	48 85 ff             	test   %rdi,%rdi
    a906:	74 40                	je     a948 <fwp_hof0.constprop.0+0x1a8>
    a908:	0f b6 31             	movzbl (%rcx),%esi
    a90b:	40 80 fe 02          	cmp    $0x2,%sil
    a90f:	0f 84 08 09 00 00    	je     b21d <fwp_hof0.constprop.0+0xa7d>
    a915:	40 80 fe 01          	cmp    $0x1,%sil
    a919:	75 2d                	jne    a948 <fwp_hof0.constprop.0+0x1a8>
    a91b:	8b 71 18             	mov    0x18(%rcx),%esi
    a91e:	0f b7 c0             	movzwl %ax,%eax
    a921:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a924:	48 0f af c6          	imul   %rsi,%rax
    a928:	48 c1 e8 20          	shr    $0x20,%rax
    a92c:	48 39 c8             	cmp    %rcx,%rax
    a92f:	73 17                	jae    a948 <fwp_hof0.constprop.0+0x1a8>
    a931:	48 01 c7             	add    %rax,%rdi
    a934:	0f b6 07             	movzbl (%rdi),%eax
    a937:	84 c0                	test   %al,%al
    a939:	74 0d                	je     a948 <fwp_hof0.constprop.0+0x1a8>
    a93b:	3c fd                	cmp    $0xfd,%al
    a93d:	0f 87 66 09 00 00    	ja     b2a9 <fwp_hof0.constprop.0+0xb09>
    a943:	83 c0 01             	add    $0x1,%eax
    a946:	88 07                	mov    %al,(%rdi)
    a948:	48 8d 05 c9 86 00 00 	lea    0x86c9(%rip),%rax        # 13018 <fc12>
    a94f:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    a956:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    a95a:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    a961:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    a965:	48 8d 05 ac 86 00 00 	lea    0x86ac(%rip),%rax        # 13018 <fc12>
    a96c:	41 8b 0c 24          	mov    (%r12),%ecx
    a970:	2b 48 04             	sub    0x4(%rax),%ecx
    a973:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    a977:	44 8b 6d 94          	mov    -0x6c(%rbp),%r13d
    a97b:	89 4d 90             	mov    %ecx,-0x70(%rbp)
    a97e:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    a982:	49 89 c1             	mov    %rax,%r9
    a985:	8b 00                	mov    (%rax),%eax
    a987:	44 39 e9             	cmp    %r13d,%ecx
    a98a:	44 0f 46 e9          	cmovbe %ecx,%r13d
    a98e:	4d 89 cf             	mov    %r9,%r15
    a991:	48 c1 e0 05          	shl    $0x5,%rax
    a995:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    a999:	44 89 ad 7c ff ff ff 	mov    %r13d,-0x84(%rbp)
    a9a0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a9a4:	4d 85 d2             	test   %r10,%r10
    a9a7:	75 58                	jne    aa01 <fwp_hof0.constprop.0+0x261>
    a9a9:	e9 f5 01 00 00       	jmp    aba3 <fwp_hof0.constprop.0+0x403>
    a9ae:	66 90                	xchg   %ax,%ax
    a9b0:	45 85 ff             	test   %r15d,%r15d
    a9b3:	74 69                	je     aa1e <fwp_hof0.constprop.0+0x27e>
    a9b5:	4c 89 e7             	mov    %r12,%rdi
    a9b8:	41 ff 12             	call   *(%r10)
    a9bb:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    a9bf:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
    a9c3:	e8 88 c3 ff ff       	call   6d50 <fwp_closure_drop>
    a9c8:	44 39 eb             	cmp    %r13d,%ebx
    a9cb:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
    a9cf:	0f 84 53 07 00 00    	je     b128 <fwp_hof0.constprop.0+0x988>
    a9d5:	44 8b 00             	mov    (%rax),%r8d
    a9d8:	45 29 fe             	sub    %r15d,%r14d
    a9db:	4d 8d 24 dc          	lea    (%r12,%rbx,8),%r12
    a9df:	49 89 c1             	mov    %rax,%r9
    a9e2:	45 89 f5             	mov    %r14d,%r13d
    a9e5:	49 c1 e0 05          	shl    $0x5,%r8
    a9e9:	4c 03 05 e8 a9 01 00 	add    0x1a9e8(%rip),%r8        # 253d8 <fwp_fns>
    a9f0:	4d 8b 50 18          	mov    0x18(%r8),%r10
    a9f4:	4d 85 d2             	test   %r10,%r10
    a9f7:	0f 84 a3 01 00 00    	je     aba0 <fwp_hof0.constprop.0+0x400>
    a9fd:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    aa01:	41 8b 49 04          	mov    0x4(%r9),%ecx
    aa05:	45 8b 38             	mov    (%r8),%r15d
    aa08:	46 8d 34 29          	lea    (%rcx,%r13,1),%r14d
    aa0c:	45 39 fe             	cmp    %r15d,%r14d
    aa0f:	0f 82 6b 04 00 00    	jb     ae80 <fwp_hof0.constprop.0+0x6e0>
    aa15:	44 89 fb             	mov    %r15d,%ebx
    aa18:	29 cb                	sub    %ecx,%ebx
    aa1a:	85 c9                	test   %ecx,%ecx
    aa1c:	74 92                	je     a9b0 <fwp_hof0.constprop.0+0x210>
    aa1e:	45 85 ff             	test   %r15d,%r15d
    aa21:	b8 01 00 00 00       	mov    $0x1,%eax
    aa26:	48 89 e6             	mov    %rsp,%rsi
    aa29:	48 89 65 a0          	mov    %rsp,-0x60(%rbp)
    aa2d:	41 0f 45 c7          	cmovne %r15d,%eax
    aa31:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    aa38:	00 
    aa39:	48 c1 e8 04          	shr    $0x4,%rax
    aa3d:	48 c1 e0 04          	shl    $0x4,%rax
    aa41:	48 89 c7             	mov    %rax,%rdi
    aa44:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    aa4b:	48 29 fe             	sub    %rdi,%rsi
    aa4e:	48 39 f4             	cmp    %rsi,%rsp
    aa51:	74 15                	je     aa68 <fwp_hof0.constprop.0+0x2c8>
    aa53:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    aa5a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    aa61:	00 00 
    aa63:	48 39 f4             	cmp    %rsi,%rsp
    aa66:	75 eb                	jne    aa53 <fwp_hof0.constprop.0+0x2b3>
    aa68:	25 ff 0f 00 00       	and    $0xfff,%eax
    aa6d:	48 29 c4             	sub    %rax,%rsp
    aa70:	48 85 c0             	test   %rax,%rax
    aa73:	74 06                	je     aa7b <fwp_hof0.constprop.0+0x2db>
    aa75:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    aa7b:	89 cf                	mov    %ecx,%edi
    aa7d:	49 89 e3             	mov    %rsp,%r11
    aa80:	31 c0                	xor    %eax,%eax
    aa82:	48 c1 e7 03          	shl    $0x3,%rdi
    aa86:	85 c9                	test   %ecx,%ecx
    aa88:	74 28                	je     aab2 <fwp_hof0.constprop.0+0x312>
    aa8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa91:	00 00 00 00 
    aa95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa9c:	00 00 00 00 
    aaa0:	49 8b 54 01 08       	mov    0x8(%r9,%rax,1),%rdx
    aaa5:	49 89 14 03          	mov    %rdx,(%r11,%rax,1)
    aaa9:	48 83 c0 08          	add    $0x8,%rax
    aaad:	48 39 c7             	cmp    %rax,%rdi
    aab0:	75 ee                	jne    aaa0 <fwp_hof0.constprop.0+0x300>
    aab2:	85 db                	test   %ebx,%ebx
    aab4:	74 1f                	je     aad5 <fwp_hof0.constprop.0+0x335>
    aab6:	89 de                	mov    %ebx,%esi
    aab8:	4c 89 e0             	mov    %r12,%rax
    aabb:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
    aabf:	90                   	nop
    aac0:	48 8b 30             	mov    (%rax),%rsi
    aac3:	89 ca                	mov    %ecx,%edx
    aac5:	48 83 c0 08          	add    $0x8,%rax
    aac9:	83 c1 01             	add    $0x1,%ecx
    aacc:	49 89 34 d3          	mov    %rsi,(%r11,%rdx,8)
    aad0:	48 39 c7             	cmp    %rax,%rdi
    aad3:	75 eb                	jne    aac0 <fwp_hof0.constprop.0+0x320>
    aad5:	48 8d 15 a4 8c 01 00 	lea    0x18ca4(%rip),%rdx        # 23780 <fwp_heap>
    aadc:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    aae0:	48 8b b2 d8 13 00 00 	mov    0x13d8(%rdx),%rsi
    aae7:	48 2b 82 b0 13 00 00 	sub    0x13b0(%rdx),%rax
    aaee:	48 89 f1             	mov    %rsi,%rcx
    aaf1:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
    aaf5:	48 c1 e1 10          	shl    $0x10,%rcx
    aaf9:	48 39 c8             	cmp    %rcx,%rax
    aafc:	73 4c                	jae    ab4a <fwp_hof0.constprop.0+0x3aa>
    aafe:	48 89 c1             	mov    %rax,%rcx
    ab01:	48 c1 e9 10          	shr    $0x10,%rcx
    ab05:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ab09:	48 8b 0d 68 a0 01 00 	mov    0x1a068(%rip),%rcx        # 24b78 <fwp_heap+0x13f8>
    ab10:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ab14:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    ab18:	48 85 f6             	test   %rsi,%rsi
    ab1b:	74 2d                	je     ab4a <fwp_hof0.constprop.0+0x3aa>
    ab1d:	0f b6 39             	movzbl (%rcx),%edi
    ab20:	40 80 ff 02          	cmp    $0x2,%dil
    ab24:	74 6a                	je     ab90 <fwp_hof0.constprop.0+0x3f0>
    ab26:	40 80 ff 01          	cmp    $0x1,%dil
    ab2a:	75 1e                	jne    ab4a <fwp_hof0.constprop.0+0x3aa>
    ab2c:	8b 79 18             	mov    0x18(%rcx),%edi
    ab2f:	0f b7 c0             	movzwl %ax,%eax
    ab32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ab35:	48 0f af c7          	imul   %rdi,%rax
    ab39:	48 c1 e8 20          	shr    $0x20,%rax
    ab3d:	48 39 c8             	cmp    %rcx,%rax
    ab40:	73 08                	jae    ab4a <fwp_hof0.constprop.0+0x3aa>
    ab42:	48 01 c6             	add    %rax,%rsi
    ab45:	80 3e 01             	cmpb   $0x1,(%rsi)
    ab48:	74 36                	je     ab80 <fwp_hof0.constprop.0+0x3e0>
    ab4a:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
    ab4e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ab52:	be 01 00 00 00       	mov    $0x1,%esi
    ab57:	4c 89 5d 98          	mov    %r11,-0x68(%rbp)
    ab5b:	41 ff 52 08          	call   *0x8(%r10)
    ab5f:	4c 8b 5d 98          	mov    -0x68(%rbp),%r11
    ab63:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
    ab67:	49 8b 40 18          	mov    0x18(%r8),%rax
    ab6b:	4c 89 df             	mov    %r11,%rdi
    ab6e:	ff 10                	call   *(%rax)
    ab70:	48 8b 65 a0          	mov    -0x60(%rbp),%rsp
    ab74:	e9 42 fe ff ff       	jmp    a9bb <fwp_hof0.constprop.0+0x21b>
    ab79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab80:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    ab87:	00 
    ab88:	eb dd                	jmp    ab67 <fwp_hof0.constprop.0+0x3c7>
    ab8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab90:	66 85 c0             	test   %ax,%ax
    ab93:	75 b5                	jne    ab4a <fwp_hof0.constprop.0+0x3aa>
    ab95:	eb ae                	jmp    ab45 <fwp_hof0.constprop.0+0x3a5>
    ab97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab9e:	00 00 
    aba0:	49 89 c7             	mov    %rax,%r15
    aba3:	4c 89 ff             	mov    %r15,%rdi
    aba6:	e8 75 ba ff ff       	call   6620 <fwp_rc_share>
    abab:	45 85 ed             	test   %r13d,%r13d
    abae:	74 21                	je     abd1 <fwp_hof0.constprop.0+0x431>
    abb0:	44 89 ea             	mov    %r13d,%edx
    abb3:	4c 89 e3             	mov    %r12,%rbx
    abb6:	4d 8d 34 d4          	lea    (%r12,%rdx,8),%r14
    abba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abc0:	48 8b 3b             	mov    (%rbx),%rdi
    abc3:	48 83 c3 08          	add    $0x8,%rbx
    abc7:	e8 54 ba ff ff       	call   6620 <fwp_rc_share>
    abcc:	4c 39 f3             	cmp    %r14,%rbx
    abcf:	75 ef                	jne    abc0 <fwp_hof0.constprop.0+0x420>
    abd1:	4c 89 e2             	mov    %r12,%rdx
    abd4:	44 89 ee             	mov    %r13d,%esi
    abd7:	4c 89 ff             	mov    %r15,%rdi
    abda:	e8 91 af ff ff       	call   5b70 <fwp_apply>
    abdf:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    abe3:	8b 75 94             	mov    -0x6c(%rbp),%esi
    abe6:	39 75 90             	cmp    %esi,-0x70(%rbp)
    abe9:	0f 83 87 00 00 00    	jae    ac76 <fwp_hof0.constprop.0+0x4d6>
    abef:	8b 85 7c ff ff ff    	mov    -0x84(%rbp),%eax
    abf5:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
    abf9:	48 89 c2             	mov    %rax,%rdx
    abfc:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
    ac00:	29 d6                	sub    %edx,%esi
    ac02:	48 8b 15 cf a7 01 00 	mov    0x1a7cf(%rip),%rdx        # 253d8 <fwp_fns>
    ac09:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    ac0d:	89 75 94             	mov    %esi,-0x6c(%rbp)
    ac10:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ac14:	44 8b 26             	mov    (%rsi),%r12d
    ac17:	48 89 f0             	mov    %rsi,%rax
    ac1a:	49 c1 e4 05          	shl    $0x5,%r12
    ac1e:	49 01 d4             	add    %rdx,%r12
    ac21:	49 83 7c 24 18 00    	cmpq   $0x0,0x18(%r12)
    ac27:	0f 85 3f fd ff ff    	jne    a96c <fwp_hof0.constprop.0+0x1cc>
    ac2d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac31:	e8 ea b9 ff ff       	call   6620 <fwp_rc_share>
    ac36:	44 8b 75 94          	mov    -0x6c(%rbp),%r14d
    ac3a:	45 85 f6             	test   %r14d,%r14d
    ac3d:	74 23                	je     ac62 <fwp_hof0.constprop.0+0x4c2>
    ac3f:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
    ac43:	31 db                	xor    %ebx,%ebx
    ac45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac4c:	00 00 00 00 
    ac50:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    ac54:	48 83 c3 01          	add    $0x1,%rbx
    ac58:	e8 c3 b9 ff ff       	call   6620 <fwp_rc_share>
    ac5d:	44 39 f3             	cmp    %r14d,%ebx
    ac60:	72 ee                	jb     ac50 <fwp_hof0.constprop.0+0x4b0>
    ac62:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
    ac66:	8b 75 94             	mov    -0x6c(%rbp),%esi
    ac69:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ac6d:	e8 fe ae ff ff       	call   5b70 <fwp_apply>
    ac72:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    ac76:	48 83 ad 60 ff ff ff 	subq   $0x1,-0xa0(%rbp)
    ac7d:	01 
    ac7e:	0f 85 00 fc ff ff    	jne    a884 <fwp_hof0.constprop.0+0xe4>
    ac84:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
    ac88:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    ac8f:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac93:	b9 01 00 00 00       	mov    $0x1,%ecx
    ac98:	48 8d 15 01 7f 00 00 	lea    0x7f01(%rip),%rdx        # 12ba0 <d0>
    ac9f:	4c 8b bd 50 ff ff ff 	mov    -0xb0(%rbp),%r15
    aca6:	48 c7 45 c0 00 00 00 	movq   $0x0,-0x40(%rbp)
    acad:	00 
    acae:	0f 29 45 b0          	movaps %xmm0,-0x50(%rbp)
    acb2:	e8 a9 ea ff ff       	call   9760 <fwp_write>
    acb7:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
    acbb:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
    acbf:	48 8d 05 68 43 00 00 	lea    0x4368(%rip),%rax        # f02e <_IO_stdin_used+0x2e>
    acc6:	48 85 c9             	test   %rcx,%rcx
    acc9:	48 0f 44 c8          	cmove  %rax,%rcx
    accd:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    acd1:	0f 87 f5 06 00 00    	ja     b3cc <fwp_hof0.constprop.0+0xc2c>
    acd7:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    acdb:	be 01 00 00 00       	mov    $0x1,%esi
    ace0:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
    ace4:	e8 67 ad ff ff       	call   5a50 <fwp_heap_alloc>
    ace9:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
    aced:	4c 89 f2             	mov    %r14,%rdx
    acf0:	4c 89 30             	mov    %r14,(%rax)
    acf3:	4c 8d 60 08          	lea    0x8(%rax),%r12
    acf7:	48 89 c3             	mov    %rax,%rbx
    acfa:	4c 89 e7             	mov    %r12,%rdi
    acfd:	e8 9e 88 ff ff       	call   35a0 <memcpy@plt>
    ad02:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    ad08:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
    ad0c:	e8 af 86 ff ff       	call   33c0 <free@plt>
    ad11:	48 8d 35 68 8a 01 00 	lea    0x18a68(%rip),%rsi        # 23780 <fwp_heap>
    ad18:	48 89 d8             	mov    %rbx,%rax
    ad1b:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    ad22:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    ad29:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    ad2d:	48 c1 e2 10          	shl    $0x10,%rdx
    ad31:	48 39 d0             	cmp    %rdx,%rax
    ad34:	73 57                	jae    ad8d <fwp_hof0.constprop.0+0x5ed>
    ad36:	48 89 c2             	mov    %rax,%rdx
    ad39:	48 c1 ea 10          	shr    $0x10,%rdx
    ad3d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad41:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    ad48:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad4c:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ad50:	4d 85 f6             	test   %r14,%r14
    ad53:	74 38                	je     ad8d <fwp_hof0.constprop.0+0x5ed>
    ad55:	0f b6 0a             	movzbl (%rdx),%ecx
    ad58:	80 f9 02             	cmp    $0x2,%cl
    ad5b:	0f 84 c9 05 00 00    	je     b32a <fwp_hof0.constprop.0+0xb8a>
    ad61:	80 f9 01             	cmp    $0x1,%cl
    ad64:	75 27                	jne    ad8d <fwp_hof0.constprop.0+0x5ed>
    ad66:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad69:	0f b7 c0             	movzwl %ax,%eax
    ad6c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ad6f:	48 0f af c1          	imul   %rcx,%rax
    ad73:	48 c1 e8 20          	shr    $0x20,%rax
    ad77:	48 39 d0             	cmp    %rdx,%rax
    ad7a:	73 11                	jae    ad8d <fwp_hof0.constprop.0+0x5ed>
    ad7c:	49 01 c6             	add    %rax,%r14
    ad7f:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ad83:	0f 84 67 06 00 00    	je     b3f0 <fwp_hof0.constprop.0+0xc50>
    ad89:	41 c6 06 01          	movb   $0x1,(%r14)
    ad8d:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    ad91:	e8 ca bc ff ff       	call   6a60 <fwp_drop0>
    ad96:	48 8b 13             	mov    (%rbx),%rdx
    ad99:	be 01 00 00 00       	mov    $0x1,%esi
    ad9e:	4c 89 e7             	mov    %r12,%rdi
    ada1:	48 8b 0d 38 a6 01 00 	mov    0x1a638(%rip),%rcx        # 253e0 <fwp_prog_out>
    ada8:	e8 d3 88 ff ff       	call   3680 <fwrite@plt>
    adad:	48 8b 35 2c a6 01 00 	mov    0x1a62c(%rip),%rsi        # 253e0 <fwp_prog_out>
    adb4:	bf 0a 00 00 00       	mov    $0xa,%edi
    adb9:	e8 22 87 ff ff       	call   34e0 <fputc@plt>
    adbe:	48 8d 35 bb 89 01 00 	lea    0x189bb(%rip),%rsi        # 23780 <fwp_heap>
    adc5:	48 89 d8             	mov    %rbx,%rax
    adc8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    adcf:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    add6:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
    adda:	48 c1 e2 10          	shl    $0x10,%rdx
    adde:	48 39 d0             	cmp    %rdx,%rax
    ade1:	73 69                	jae    ae4c <fwp_hof0.constprop.0+0x6ac>
    ade3:	48 89 c2             	mov    %rax,%rdx
    ade6:	48 c1 ea 10          	shr    $0x10,%rdx
    adea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    adee:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    adf5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    adf9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    adfd:	4d 85 e4             	test   %r12,%r12
    ae00:	74 4a                	je     ae4c <fwp_hof0.constprop.0+0x6ac>
    ae02:	0f b6 0a             	movzbl (%rdx),%ecx
    ae05:	80 f9 02             	cmp    $0x2,%cl
    ae08:	0f 84 2a 05 00 00    	je     b338 <fwp_hof0.constprop.0+0xb98>
    ae0e:	80 f9 01             	cmp    $0x1,%cl
    ae11:	75 39                	jne    ae4c <fwp_hof0.constprop.0+0x6ac>
    ae13:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ae16:	0f b7 c0             	movzwl %ax,%eax
    ae19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae1c:	48 0f af c1          	imul   %rcx,%rax
    ae20:	48 c1 e8 20          	shr    $0x20,%rax
    ae24:	48 39 d0             	cmp    %rdx,%rax
    ae27:	73 23                	jae    ae4c <fwp_hof0.constprop.0+0x6ac>
    ae29:	49 01 c4             	add    %rax,%r12
    ae2c:	41 0f b6 04 24       	movzbl (%r12),%eax
    ae31:	84 c0                	test   %al,%al
    ae33:	74 17                	je     ae4c <fwp_hof0.constprop.0+0x6ac>
    ae35:	3c 01                	cmp    $0x1,%al
    ae37:	0f 84 d3 04 00 00    	je     b310 <fwp_hof0.constprop.0+0xb70>
    ae3d:	3c ff                	cmp    $0xff,%al
    ae3f:	0f 84 01 05 00 00    	je     b346 <fwp_hof0.constprop.0+0xba6>
    ae45:	83 e8 01             	sub    $0x1,%eax
    ae48:	41 88 04 24          	mov    %al,(%r12)
    ae4c:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    ae50:	4d 85 ff             	test   %r15,%r15
    ae53:	0f 85 88 f9 ff ff    	jne    a7e1 <fwp_hof0.constprop.0+0x41>
    ae59:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    ae5d:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ae64:	00 00 
    ae66:	0f 85 7e 05 00 00    	jne    b3ea <fwp_hof0.constprop.0+0xc4a>
    ae6c:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    ae70:	31 c0                	xor    %eax,%eax
    ae72:	5b                   	pop    %rbx
    ae73:	41 5c                	pop    %r12
    ae75:	41 5d                	pop    %r13
    ae77:	41 5e                	pop    %r14
    ae79:	41 5f                	pop    %r15
    ae7b:	5d                   	pop    %rbp
    ae7c:	c3                   	ret
    ae7d:	0f 1f 00             	nopl   (%rax)
    ae80:	48 8d 1d f9 88 01 00 	lea    0x188f9(%rip),%rbx        # 23780 <fwp_heap>
    ae87:	41 8d 76 01          	lea    0x1(%r14),%esi
    ae8b:	45 89 f7             	mov    %r14d,%r15d
    ae8e:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    ae94:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    ae9b:	00 
    ae9c:	85 c0                	test   %eax,%eax
    ae9e:	0f 84 a9 03 00 00    	je     b24d <fwp_hof0.constprop.0+0xaad>
    aea4:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    aeab:	0f 87 9c 03 00 00    	ja     b24d <fwp_hof0.constprop.0+0xaad>
    aeb1:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    aeb5:	48 c1 e8 04          	shr    $0x4,%rax
    aeb9:	0f b6 94 03 a0 0f 00 	movzbl 0xfa0(%rbx,%rax,1),%edx
    aec0:	00 
    aec1:	8b 84 93 00 0f 00 00 	mov    0xf00(%rbx,%rdx,4),%eax
    aec8:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    aecc:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
    aed0:	4c 8b 12             	mov    (%rdx),%r10
    aed3:	4d 85 d2             	test   %r10,%r10
    aed6:	0f 84 4f 03 00 00    	je     b22b <fwp_hof0.constprop.0+0xa8b>
    aedc:	4d 8b 1a             	mov    (%r10),%r11
    aedf:	49 f7 d3             	not    %r11
    aee2:	4c 89 1a             	mov    %r11,(%rdx)
    aee5:	48 39 c7             	cmp    %rax,%rdi
    aee8:	73 50                	jae    af3a <fwp_hof0.constprop.0+0x79a>
    aeea:	48 89 fa             	mov    %rdi,%rdx
    aeed:	48 83 c7 08          	add    $0x8,%rdi
    aef1:	49 c7 04 f2 00 00 00 	movq   $0x0,(%r10,%rsi,8)
    aef8:	00 
    aef9:	48 f7 d2             	not    %rdx
    aefc:	48 01 c2             	add    %rax,%rdx
    aeff:	48 c1 ea 03          	shr    $0x3,%rdx
    af03:	48 39 c7             	cmp    %rax,%rdi
    af06:	73 32                	jae    af3a <fwp_hof0.constprop.0+0x79a>
    af08:	83 e2 01             	and    $0x1,%edx
    af0b:	74 13                	je     af20 <fwp_hof0.constprop.0+0x780>
    af0d:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    af14:	00 
    af15:	48 83 c7 08          	add    $0x8,%rdi
    af19:	48 39 c7             	cmp    %rax,%rdi
    af1c:	73 1c                	jae    af3a <fwp_hof0.constprop.0+0x79a>
    af1e:	66 90                	xchg   %ax,%ax
    af20:	49 c7 04 3a 00 00 00 	movq   $0x0,(%r10,%rdi,1)
    af27:	00 
    af28:	49 c7 44 3a 08 00 00 	movq   $0x0,0x8(%r10,%rdi,1)
    af2f:	00 00 
    af31:	48 83 c7 10          	add    $0x10,%rdi
    af35:	48 39 c7             	cmp    %rax,%rdi
    af38:	72 e6                	jb     af20 <fwp_hof0.constprop.0+0x780>
    af3a:	48 8d 35 3f 88 01 00 	lea    0x1883f(%rip),%rsi        # 23780 <fwp_heap>
    af41:	48 89 c2             	mov    %rax,%rdx
    af44:	48 03 96 20 14 00 00 	add    0x1420(%rsi),%rdx
    af4b:	0f 82 6a 04 00 00    	jb     b3bb <fwp_hof0.constprop.0+0xc1b>
    af51:	48 89 96 20 14 00 00 	mov    %rdx,0x1420(%rsi)
    af58:	48 39 96 28 14 00 00 	cmp    %rdx,0x1428(%rsi)
    af5f:	73 07                	jae    af68 <fwp_hof0.constprop.0+0x7c8>
    af61:	48 89 15 40 9c 01 00 	mov    %rdx,0x19c40(%rip)        # 24ba8 <fwp_heap+0x1428>
    af68:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af6c:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    af71:	f2 0f 58 05 3f 9c 01 	addsd  0x19c3f(%rip),%xmm0        # 24bb8 <fwp_heap+0x1438>
    af78:	00 
    af79:	f2 0f 11 05 37 9c 01 	movsd  %xmm0,0x19c37(%rip)        # 24bb8 <fwp_heap+0x1438>
    af80:	00 
    af81:	66 41 0f 6e 01       	movd   (%r9),%xmm0
    af86:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    af8b:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    af8f:	66 41 0f d6 02       	movq   %xmm0,(%r10)
    af94:	85 c9                	test   %ecx,%ecx
    af96:	74 37                	je     afcf <fwp_hof0.constprop.0+0x82f>
    af98:	89 ca                	mov    %ecx,%edx
    af9a:	49 8d 71 08          	lea    0x8(%r9),%rsi
    af9e:	49 8d 7a 08          	lea    0x8(%r10),%rdi
    afa2:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    afa5:	48 c1 e2 03          	shl    $0x3,%rdx
    afa9:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
    afb0:	4c 89 4d 98          	mov    %r9,-0x68(%rbp)
    afb4:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    afb8:	e8 53 86 ff ff       	call   3610 <memmove@plt>
    afbd:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    afc1:	4c 8b 4d 98          	mov    -0x68(%rbp),%r9
    afc5:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    afc8:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
    afcf:	45 85 ed             	test   %r13d,%r13d
    afd2:	74 23                	je     aff7 <fwp_hof0.constprop.0+0x857>
    afd4:	45 89 ed             	mov    %r13d,%r13d
    afd7:	4b 8d 34 ec          	lea    (%r12,%r13,8),%rsi
    afdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    afe0:	49 8b 14 24          	mov    (%r12),%rdx
    afe4:	89 c8                	mov    %ecx,%eax
    afe6:	49 83 c4 08          	add    $0x8,%r12
    afea:	83 c1 01             	add    $0x1,%ecx
    afed:	49 89 54 c2 08       	mov    %rdx,0x8(%r10,%rax,8)
    aff2:	4c 39 e6             	cmp    %r12,%rsi
    aff5:	75 e9                	jne    afe0 <fwp_hof0.constprop.0+0x840>
    aff7:	48 8d 35 82 87 01 00 	lea    0x18782(%rip),%rsi        # 23780 <fwp_heap>
    affe:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
    b002:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b009:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b010:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b014:	48 c1 e2 10          	shl    $0x10,%rdx
    b018:	48 39 d0             	cmp    %rdx,%rax
    b01b:	73 54                	jae    b071 <fwp_hof0.constprop.0+0x8d1>
    b01d:	48 89 c2             	mov    %rax,%rdx
    b020:	48 c1 ea 10          	shr    $0x10,%rdx
    b024:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b028:	48 8b 15 49 9b 01 00 	mov    0x19b49(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b02f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b033:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    b037:	48 85 c9             	test   %rcx,%rcx
    b03a:	74 35                	je     b071 <fwp_hof0.constprop.0+0x8d1>
    b03c:	0f b6 32             	movzbl (%rdx),%esi
    b03f:	40 80 fe 02          	cmp    $0x2,%sil
    b043:	0f 84 52 02 00 00    	je     b29b <fwp_hof0.constprop.0+0xafb>
    b049:	40 80 fe 01          	cmp    $0x1,%sil
    b04d:	75 22                	jne    b071 <fwp_hof0.constprop.0+0x8d1>
    b04f:	8b 72 18             	mov    0x18(%rdx),%esi
    b052:	0f b7 c0             	movzwl %ax,%eax
    b055:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b058:	48 0f af c6          	imul   %rsi,%rax
    b05c:	48 c1 e8 20          	shr    $0x20,%rax
    b060:	48 39 d0             	cmp    %rdx,%rax
    b063:	73 0c                	jae    b071 <fwp_hof0.constprop.0+0x8d1>
    b065:	48 01 c1             	add    %rax,%rcx
    b068:	80 39 01             	cmpb   $0x1,(%rcx)
    b06b:	0f 84 9f 01 00 00    	je     b210 <fwp_hof0.constprop.0+0xa70>
    b071:	49 8b 40 18          	mov    0x18(%r8),%rax
    b075:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b079:	be 01 00 00 00       	mov    $0x1,%esi
    b07e:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b082:	ff 50 08             	call   *0x8(%rax)
    b085:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b089:	48 8d 35 f0 86 01 00 	lea    0x186f0(%rip),%rsi        # 23780 <fwp_heap>
    b090:	4c 89 d0             	mov    %r10,%rax
    b093:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    b09a:	48 2b 86 b0 13 00 00 	sub    0x13b0(%rsi),%rax
    b0a1:	48 89 55 a0          	mov    %rdx,-0x60(%rbp)
    b0a5:	48 c1 e2 10          	shl    $0x10,%rdx
    b0a9:	48 39 d0             	cmp    %rdx,%rax
    b0ac:	73 59                	jae    b107 <fwp_hof0.constprop.0+0x967>
    b0ae:	48 89 c2             	mov    %rax,%rdx
    b0b1:	48 c1 ea 10          	shr    $0x10,%rdx
    b0b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b0b9:	48 8b 96 f8 13 00 00 	mov    0x13f8(%rsi),%rdx
    b0c0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b0c4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b0c8:	4d 85 e4             	test   %r12,%r12
    b0cb:	74 3a                	je     b107 <fwp_hof0.constprop.0+0x967>
    b0cd:	0f b6 0a             	movzbl (%rdx),%ecx
    b0d0:	80 f9 02             	cmp    $0x2,%cl
    b0d3:	0f 84 99 01 00 00    	je     b272 <fwp_hof0.constprop.0+0xad2>
    b0d9:	80 f9 01             	cmp    $0x1,%cl
    b0dc:	75 29                	jne    b107 <fwp_hof0.constprop.0+0x967>
    b0de:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0e1:	0f b7 c0             	movzwl %ax,%eax
    b0e4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0e7:	48 0f af c1          	imul   %rcx,%rax
    b0eb:	48 c1 e8 20          	shr    $0x20,%rax
    b0ef:	48 39 d0             	cmp    %rdx,%rax
    b0f2:	73 13                	jae    b107 <fwp_hof0.constprop.0+0x967>
    b0f4:	49 01 c4             	add    %rax,%r12
    b0f7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b0fc:	0f 84 84 01 00 00    	je     b286 <fwp_hof0.constprop.0+0xae6>
    b102:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b107:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b10b:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b10f:	e8 3c bc ff ff       	call   6d50 <fwp_closure_drop>
    b114:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b118:	4c 89 55 a8          	mov    %r10,-0x58(%rbp)
    b11c:	e9 c2 fa ff ff       	jmp    abe3 <fwp_hof0.constprop.0+0x443>
    b121:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b128:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b12c:	e9 b2 fa ff ff       	jmp    abe3 <fwp_hof0.constprop.0+0x443>
    b131:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b138:	41 8b 34 24          	mov    (%r12),%esi
    b13c:	8b 05 da 7e 00 00    	mov    0x7eda(%rip),%eax        # 1301c <fc12+0x4>
    b142:	89 f7                	mov    %esi,%edi
    b144:	29 c7                	sub    %eax,%edi
    b146:	83 ff 01             	cmp    $0x1,%edi
    b149:	0f 85 6e f7 ff ff    	jne    a8bd <fwp_hof0.constprop.0+0x11d>
    b14f:	48 89 e3             	mov    %rsp,%rbx
    b152:	85 c0                	test   %eax,%eax
    b154:	0f 84 60 01 00 00    	je     b2ba <fwp_hof0.constprop.0+0xb1a>
    b15a:	89 f1                	mov    %esi,%ecx
    b15c:	ba 08 00 00 00       	mov    $0x8,%edx
    b161:	48 c1 e1 03          	shl    $0x3,%rcx
    b165:	85 f6                	test   %esi,%esi
    b167:	48 89 e6             	mov    %rsp,%rsi
    b16a:	48 0f 45 d1          	cmovne %rcx,%rdx
    b16e:	49 89 d7             	mov    %rdx,%r15
    b171:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    b175:	48 c1 ea 04          	shr    $0x4,%rdx
    b179:	48 c1 e2 04          	shl    $0x4,%rdx
    b17d:	48 89 d7             	mov    %rdx,%rdi
    b180:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    b187:	48 29 fe             	sub    %rdi,%rsi
    b18a:	48 39 f4             	cmp    %rsi,%rsp
    b18d:	74 15                	je     b1a4 <fwp_hof0.constprop.0+0xa04>
    b18f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    b196:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    b19d:	00 00 
    b19f:	48 39 f4             	cmp    %rsi,%rsp
    b1a2:	75 eb                	jne    b18f <fwp_hof0.constprop.0+0x9ef>
    b1a4:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    b1aa:	48 29 d4             	sub    %rdx,%rsp
    b1ad:	48 85 d2             	test   %rdx,%rdx
    b1b0:	74 06                	je     b1b8 <fwp_hof0.constprop.0+0xa18>
    b1b2:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    b1b8:	4c 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%r14
    b1bf:	00 
    b1c0:	4c 89 f9             	mov    %r15,%rcx
    b1c3:	48 8d 35 56 7e 00 00 	lea    0x7e56(%rip),%rsi        # 13020 <fwp_epfd>
    b1ca:	48 89 e7             	mov    %rsp,%rdi
    b1cd:	4c 89 f2             	mov    %r14,%rdx
    b1d0:	e8 9b 83 ff ff       	call   3570 <__memcpy_chk@plt>
    b1d5:	4d 39 f7             	cmp    %r14,%r15
    b1d8:	4c 89 f9             	mov    %r15,%rcx
    b1db:	4a 8d 3c 34          	lea    (%rsp,%r14,1),%rdi
    b1df:	49 0f 42 ce          	cmovb  %r14,%rcx
    b1e3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
    b1ea:	ba 08 00 00 00       	mov    $0x8,%edx
    b1ef:	4c 29 f1             	sub    %r14,%rcx
    b1f2:	e8 79 83 ff ff       	call   3570 <__memcpy_chk@plt>
    b1f7:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    b1fc:	48 89 e7             	mov    %rsp,%rdi
    b1ff:	ff 10                	call   *(%rax)
    b201:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b205:	e9 bd 00 00 00       	jmp    b2c7 <fwp_hof0.constprop.0+0xb27>
    b20a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b210:	41 c7 41 04 00 00 00 	movl   $0x0,0x4(%r9)
    b217:	00 
    b218:	e9 6c fe ff ff       	jmp    b089 <fwp_hof0.constprop.0+0x8e9>
    b21d:	66 85 c0             	test   %ax,%ax
    b220:	0f 85 22 f7 ff ff    	jne    a948 <fwp_hof0.constprop.0+0x1a8>
    b226:	e9 09 f7 ff ff       	jmp    a934 <fwp_hof0.constprop.0+0x194>
    b22b:	4c 8b 52 08          	mov    0x8(%rdx),%r10
    b22f:	4d 85 d2             	test   %r10,%r10
    b232:	74 19                	je     b24d <fwp_hof0.constprop.0+0xaad>
    b234:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    b238:	4d 29 d3             	sub    %r10,%r11
    b23b:	49 39 c3             	cmp    %rax,%r11
    b23e:	72 0d                	jb     b24d <fwp_hof0.constprop.0+0xaad>
    b240:	4d 8d 1c 02          	lea    (%r10,%rax,1),%r11
    b244:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    b248:	e9 98 fc ff ff       	jmp    aee5 <fwp_hof0.constprop.0+0x745>
    b24d:	31 f6                	xor    %esi,%esi
    b24f:	89 4d 80             	mov    %ecx,-0x80(%rbp)
    b252:	4c 89 45 98          	mov    %r8,-0x68(%rbp)
    b256:	4c 89 4d a0          	mov    %r9,-0x60(%rbp)
    b25a:	e8 f1 a7 ff ff       	call   5a50 <fwp_heap_alloc>
    b25f:	8b 4d 80             	mov    -0x80(%rbp),%ecx
    b262:	4c 8b 45 98          	mov    -0x68(%rbp),%r8
    b266:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
    b26a:	49 89 c2             	mov    %rax,%r10
    b26d:	e9 0f fd ff ff       	jmp    af81 <fwp_hof0.constprop.0+0x7e1>
    b272:	66 85 c0             	test   %ax,%ax
    b275:	0f 85 8c fe ff ff    	jne    b107 <fwp_hof0.constprop.0+0x967>
    b27b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b280:	0f 85 7c fe ff ff    	jne    b102 <fwp_hof0.constprop.0+0x962>
    b286:	4c 89 e7             	mov    %r12,%rdi
    b289:	4c 89 55 a0          	mov    %r10,-0x60(%rbp)
    b28d:	e8 7e a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b292:	4c 8b 55 a0          	mov    -0x60(%rbp),%r10
    b296:	e9 67 fe ff ff       	jmp    b102 <fwp_hof0.constprop.0+0x962>
    b29b:	66 85 c0             	test   %ax,%ax
    b29e:	0f 85 cd fd ff ff    	jne    b071 <fwp_hof0.constprop.0+0x8d1>
    b2a4:	e9 bf fd ff ff       	jmp    b068 <fwp_hof0.constprop.0+0x8c8>
    b2a9:	e8 42 9f ff ff       	call   51f0 <fwp_rc_wide_dup>
    b2ae:	48 8b 15 23 a1 01 00 	mov    0x1a123(%rip),%rdx        # 253d8 <fwp_fns>
    b2b5:	e9 8e f6 ff ff       	jmp    a948 <fwp_hof0.constprop.0+0x1a8>
    b2ba:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
    b2c1:	ff 11                	call   *(%rcx)
    b2c3:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2c7:	48 89 dc             	mov    %rbx,%rsp
    b2ca:	e9 a7 f9 ff ff       	jmp    ac76 <fwp_hof0.constprop.0+0x4d6>
    b2cf:	48 89 c7             	mov    %rax,%rdi
    b2d2:	e8 49 b3 ff ff       	call   6620 <fwp_rc_share>
    b2d7:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
    b2db:	e8 40 b3 ff ff       	call   6620 <fwp_rc_share>
    b2e0:	48 8d 05 31 7d 00 00 	lea    0x7d31(%rip),%rax        # 13018 <fc12>
    b2e7:	c7 45 94 01 00 00 00 	movl   $0x1,-0x6c(%rbp)
    b2ee:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
    b2f2:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
    b2f9:	48 89 45 88          	mov    %rax,-0x78(%rbp)
    b2fd:	e9 60 f9 ff ff       	jmp    ac62 <fwp_hof0.constprop.0+0x4c2>
    b302:	66 85 c0             	test   %ax,%ax
    b305:	0f 85 5c f5 ff ff    	jne    a867 <fwp_hof0.constprop.0+0xc7>
    b30b:	e9 43 f5 ff ff       	jmp    a853 <fwp_hof0.constprop.0+0xb3>
    b310:	48 89 df             	mov    %rbx,%rdi
    b313:	e8 38 b4 ff ff       	call   6750 <fwp_rc_free_arr>
    b318:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    b31c:	4d 85 ff             	test   %r15,%r15
    b31f:	0f 85 bc f4 ff ff    	jne    a7e1 <fwp_hof0.constprop.0+0x41>
    b325:	e9 2f fb ff ff       	jmp    ae59 <fwp_hof0.constprop.0+0x6b9>
    b32a:	66 85 c0             	test   %ax,%ax
    b32d:	0f 85 5a fa ff ff    	jne    ad8d <fwp_hof0.constprop.0+0x5ed>
    b333:	e9 47 fa ff ff       	jmp    ad7f <fwp_hof0.constprop.0+0x5df>
    b338:	66 85 c0             	test   %ax,%ax
    b33b:	0f 85 0b fb ff ff    	jne    ae4c <fwp_hof0.constprop.0+0x6ac>
    b341:	e9 e6 fa ff ff       	jmp    ae2c <fwp_hof0.constprop.0+0x68c>
    b346:	4c 89 e0             	mov    %r12,%rax
    b349:	48 8d 35 30 84 01 00 	lea    0x18430(%rip),%rsi        # 23780 <fwp_heap>
    b350:	48 c1 e8 11          	shr    $0x11,%rax
    b354:	4c 31 e0             	xor    %r12,%rax
    b357:	48 89 c2             	mov    %rax,%rdx
    b35a:	48 c1 ea 09          	shr    $0x9,%rdx
    b35e:	48 31 d0             	xor    %rdx,%rax
    b361:	0f b6 c0             	movzbl %al,%eax
    b364:	48 8b 94 c6 48 14 00 	mov    0x1448(%rsi,%rax,8),%rdx
    b36b:	00 
    b36c:	48 85 d2             	test   %rdx,%rdx
    b36f:	75 18                	jne    b389 <fwp_hof0.constprop.0+0xbe9>
    b371:	eb 4d                	jmp    b3c0 <fwp_hof0.constprop.0+0xc20>
    b373:	66 90                	xchg   %ax,%ax
    b375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b37c:	00 00 00 00 
    b380:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b384:	48 85 d2             	test   %rdx,%rdx
    b387:	74 37                	je     b3c0 <fwp_hof0.constprop.0+0xc20>
    b389:	48 89 d0             	mov    %rdx,%rax
    b38c:	4c 39 22             	cmp    %r12,(%rdx)
    b38f:	75 ef                	jne    b380 <fwp_hof0.constprop.0+0xbe0>
    b391:	48 8b 42 08          	mov    0x8(%rdx),%rax
    b395:	48 83 e8 01          	sub    $0x1,%rax
    b399:	48 89 42 08          	mov    %rax,0x8(%rdx)
    b39d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    b3a3:	0f 85 a3 fa ff ff    	jne    ae4c <fwp_hof0.constprop.0+0x6ac>
    b3a9:	4c 89 e7             	mov    %r12,%rdi
    b3ac:	e8 5f 9f ff ff       	call   5310 <fwp_rc_forget_slot>
    b3b1:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b3b6:	e9 91 fa ff ff       	jmp    ae4c <fwp_hof0.constprop.0+0x6ac>
    b3bb:	e8 f0 88 ff ff       	call   3cb0 <fwp_heap_oom>
    b3c0:	48 8d 3d d1 43 00 00 	lea    0x43d1(%rip),%rdi        # f798 <_IO_stdin_used+0x798>
    b3c7:	e8 d4 8d ff ff       	call   41a0 <fwp_trap>
    b3cc:	48 8d 3d 15 3e 00 00 	lea    0x3e15(%rip),%rdi        # f1e8 <_IO_stdin_used+0x1e8>
    b3d3:	e8 c8 8d ff ff       	call   41a0 <fwp_trap>
    b3d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b3df:	00 
    b3e0:	e8 0b 9e ff ff       	call   51f0 <fwp_rc_wide_dup>
    b3e5:	e9 7d f4 ff ff       	jmp    a867 <fwp_hof0.constprop.0+0xc7>
    b3ea:	e8 71 80 ff ff       	call   3460 <__stack_chk_fail@plt>
    b3ef:	90                   	nop
    b3f0:	4c 89 f7             	mov    %r14,%rdi
    b3f3:	e8 18 9f ff ff       	call   5310 <fwp_rc_forget_slot>
    b3f8:	e9 8c f9 ff ff       	jmp    ad89 <fwp_hof0.constprop.0+0x5e9>
    b3fd:	0f 1f 00             	nopl   (%rax)

000000000000b400 <f0>:
    b400:	41 56                	push   %r14
    b402:	4c 8d 35 77 83 01 00 	lea    0x18377(%rip),%r14        # 23780 <fwp_heap>
    b409:	41 55                	push   %r13
    b40b:	41 54                	push   %r12
    b40d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b413:	55                   	push   %rbp
    b414:	53                   	push   %rbx
    b415:	31 db                	xor    %ebx,%ebx
    b417:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b41e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b425:	00 00 
    b427:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b42e:	00 
    b42f:	31 c0                	xor    %eax,%eax
    b431:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b438:	00 
    b439:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b440:	00 00 
    b442:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b447:	48 8d 05 a2 b7 ff ff 	lea    -0x485e(%rip),%rax        # 6bf0 <fwp_drop1>
    b44e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b453:	48 8b 05 be 9f 01 00 	mov    0x19fbe(%rip),%rax        # 25418 <fwp_cleanups>
    b45a:	48 89 25 b7 9f 01 00 	mov    %rsp,0x19fb7(%rip)        # 25418 <fwp_cleanups>
    b461:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b465:	48 89 04 24          	mov    %rax,(%rsp)
    b469:	48 8d 05 60 87 ff ff 	lea    -0x78a0(%rip),%rax        # 3bd0 <fwp_range_release>
    b470:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b475:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b47a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b47f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b484:	eb 47                	jmp    b4cd <f0+0xcd>
    b486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b48d:	00 00 00 
    b490:	80 f9 01             	cmp    $0x1,%cl
    b493:	75 29                	jne    b4be <f0+0xbe>
    b495:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b498:	0f b7 c0             	movzwl %ax,%eax
    b49b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b49e:	48 0f af c1          	imul   %rcx,%rax
    b4a2:	48 c1 e8 20          	shr    $0x20,%rax
    b4a6:	48 39 d0             	cmp    %rdx,%rax
    b4a9:	73 13                	jae    b4be <f0+0xbe>
    b4ab:	49 01 c5             	add    %rax,%r13
    b4ae:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b4b3:	0f 84 c7 27 00 00    	je     dc80 <f0+0x2880>
    b4b9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b4be:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b4c3:	49 83 ec 01          	sub    $0x1,%r12
    b4c7:	0f 82 83 00 00 00    	jb     b550 <f0+0x150>
    b4cd:	48 89 ee             	mov    %rbp,%rsi
    b4d0:	bf 01 00 00 00       	mov    $0x1,%edi
    b4d5:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b4dc:	00 
    b4dd:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b4e2:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b4e9:	00 
    b4ea:	e8 01 b0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b4ef:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b4f6:	48 89 c3             	mov    %rax,%rbx
    b4f9:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b500:	48 c1 e2 10          	shl    $0x10,%rdx
    b504:	48 39 d0             	cmp    %rdx,%rax
    b507:	73 b5                	jae    b4be <f0+0xbe>
    b509:	48 89 c2             	mov    %rax,%rdx
    b50c:	48 c1 ea 10          	shr    $0x10,%rdx
    b510:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b514:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b51b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b51f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b523:	4d 85 ed             	test   %r13,%r13
    b526:	74 96                	je     b4be <f0+0xbe>
    b528:	0f b6 0a             	movzbl (%rdx),%ecx
    b52b:	80 f9 02             	cmp    $0x2,%cl
    b52e:	0f 85 5c ff ff ff    	jne    b490 <f0+0x90>
    b534:	66 85 c0             	test   %ax,%ax
    b537:	0f 84 71 ff ff ff    	je     b4ae <f0+0xae>
    b53d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b542:	49 83 ec 01          	sub    $0x1,%r12
    b546:	73 85                	jae    b4cd <f0+0xcd>
    b548:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b54f:	00 
    b550:	48 8b 04 24          	mov    (%rsp),%rax
    b554:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b559:	bf 01 00 00 00       	mov    $0x1,%edi
    b55e:	66 0f 6f 05 ba 45 00 	movdqa 0x45ba(%rip),%xmm0        # fb20 <msg.4+0xa0>
    b565:	00 
    b566:	48 89 05 ab 9e 01 00 	mov    %rax,0x19eab(%rip)        # 25418 <fwp_cleanups>
    b56d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b572:	e8 79 af ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b577:	48 8b 15 da 95 01 00 	mov    0x195da(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b57e:	49 89 c5             	mov    %rax,%r13
    b581:	48 2b 05 a8 95 01 00 	sub    0x195a8(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b588:	48 c1 e2 10          	shl    $0x10,%rdx
    b58c:	48 39 d0             	cmp    %rdx,%rax
    b58f:	73 59                	jae    b5ea <f0+0x1ea>
    b591:	48 89 c2             	mov    %rax,%rdx
    b594:	48 c1 ea 10          	shr    $0x10,%rdx
    b598:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b59c:	48 8b 15 d5 95 01 00 	mov    0x195d5(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b5a3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b5a7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b5ab:	4d 85 e4             	test   %r12,%r12
    b5ae:	74 3a                	je     b5ea <f0+0x1ea>
    b5b0:	0f b6 0a             	movzbl (%rdx),%ecx
    b5b3:	80 f9 02             	cmp    $0x2,%cl
    b5b6:	0f 84 74 27 00 00    	je     dd30 <f0+0x2930>
    b5bc:	80 f9 01             	cmp    $0x1,%cl
    b5bf:	75 29                	jne    b5ea <f0+0x1ea>
    b5c1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b5c4:	0f b7 c0             	movzwl %ax,%eax
    b5c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b5ca:	48 0f af c1          	imul   %rcx,%rax
    b5ce:	48 c1 e8 20          	shr    $0x20,%rax
    b5d2:	48 39 d0             	cmp    %rdx,%rax
    b5d5:	73 13                	jae    b5ea <f0+0x1ea>
    b5d7:	49 01 c4             	add    %rax,%r12
    b5da:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b5df:	0f 84 26 29 00 00    	je     df0b <f0+0x2b0b>
    b5e5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b5ea:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b5ef:	bf 01 00 00 00       	mov    $0x1,%edi
    b5f4:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b5f9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b600:	00 f0 3f 
    b603:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b608:	e8 e3 ae ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b60d:	48 8b 15 44 95 01 00 	mov    0x19544(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b614:	49 89 c5             	mov    %rax,%r13
    b617:	48 2b 05 12 95 01 00 	sub    0x19512(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b61e:	48 c1 e2 10          	shl    $0x10,%rdx
    b622:	48 39 d0             	cmp    %rdx,%rax
    b625:	73 59                	jae    b680 <f0+0x280>
    b627:	48 89 c2             	mov    %rax,%rdx
    b62a:	48 c1 ea 10          	shr    $0x10,%rdx
    b62e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b632:	48 8b 15 3f 95 01 00 	mov    0x1953f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b639:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b63d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b641:	4d 85 e4             	test   %r12,%r12
    b644:	74 3a                	je     b680 <f0+0x280>
    b646:	0f b6 0a             	movzbl (%rdx),%ecx
    b649:	80 f9 02             	cmp    $0x2,%cl
    b64c:	0f 84 ce 26 00 00    	je     dd20 <f0+0x2920>
    b652:	80 f9 01             	cmp    $0x1,%cl
    b655:	75 29                	jne    b680 <f0+0x280>
    b657:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b65a:	0f b7 c0             	movzwl %ax,%eax
    b65d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b660:	48 0f af c1          	imul   %rcx,%rax
    b664:	48 c1 e8 20          	shr    $0x20,%rax
    b668:	48 39 d0             	cmp    %rdx,%rax
    b66b:	73 13                	jae    b680 <f0+0x280>
    b66d:	49 01 c4             	add    %rax,%r12
    b670:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b675:	0f 84 9d 28 00 00    	je     df18 <f0+0x2b18>
    b67b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b680:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b685:	bf 01 00 00 00       	mov    $0x1,%edi
    b68a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b68f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b696:	33 f3 bf 
    b699:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b69e:	e8 4d ae ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b6a3:	48 8b 15 ae 94 01 00 	mov    0x194ae(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b6aa:	49 89 c5             	mov    %rax,%r13
    b6ad:	48 2b 05 7c 94 01 00 	sub    0x1947c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b6b4:	48 c1 e2 10          	shl    $0x10,%rdx
    b6b8:	48 39 d0             	cmp    %rdx,%rax
    b6bb:	73 59                	jae    b716 <f0+0x316>
    b6bd:	48 89 c2             	mov    %rax,%rdx
    b6c0:	48 c1 ea 10          	shr    $0x10,%rdx
    b6c4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6c8:	48 8b 15 a9 94 01 00 	mov    0x194a9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b6cf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6d3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b6d7:	4d 85 e4             	test   %r12,%r12
    b6da:	74 3a                	je     b716 <f0+0x316>
    b6dc:	0f b6 0a             	movzbl (%rdx),%ecx
    b6df:	80 f9 02             	cmp    $0x2,%cl
    b6e2:	0f 84 28 26 00 00    	je     dd10 <f0+0x2910>
    b6e8:	80 f9 01             	cmp    $0x1,%cl
    b6eb:	75 29                	jne    b716 <f0+0x316>
    b6ed:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b6f0:	0f b7 c0             	movzwl %ax,%eax
    b6f3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b6f6:	48 0f af c1          	imul   %rcx,%rax
    b6fa:	48 c1 e8 20          	shr    $0x20,%rax
    b6fe:	48 39 d0             	cmp    %rdx,%rax
    b701:	73 13                	jae    b716 <f0+0x316>
    b703:	49 01 c4             	add    %rax,%r12
    b706:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b70b:	0f 84 14 28 00 00    	je     df25 <f0+0x2b25>
    b711:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b716:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b71b:	bf 01 00 00 00       	mov    $0x1,%edi
    b720:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b725:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b72c:	00 f0 3f 
    b72f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b734:	e8 b7 ad ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b739:	48 8b 15 18 94 01 00 	mov    0x19418(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b740:	49 89 c5             	mov    %rax,%r13
    b743:	48 2b 05 e6 93 01 00 	sub    0x193e6(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b74a:	48 c1 e2 10          	shl    $0x10,%rdx
    b74e:	48 39 d0             	cmp    %rdx,%rax
    b751:	73 59                	jae    b7ac <f0+0x3ac>
    b753:	48 89 c2             	mov    %rax,%rdx
    b756:	48 c1 ea 10          	shr    $0x10,%rdx
    b75a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b75e:	48 8b 15 13 94 01 00 	mov    0x19413(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b765:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b769:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b76d:	4d 85 e4             	test   %r12,%r12
    b770:	74 3a                	je     b7ac <f0+0x3ac>
    b772:	0f b6 0a             	movzbl (%rdx),%ecx
    b775:	80 f9 02             	cmp    $0x2,%cl
    b778:	0f 84 f2 25 00 00    	je     dd70 <f0+0x2970>
    b77e:	80 f9 01             	cmp    $0x1,%cl
    b781:	75 29                	jne    b7ac <f0+0x3ac>
    b783:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b786:	0f b7 c0             	movzwl %ax,%eax
    b789:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b78c:	48 0f af c1          	imul   %rcx,%rax
    b790:	48 c1 e8 20          	shr    $0x20,%rax
    b794:	48 39 d0             	cmp    %rdx,%rax
    b797:	73 13                	jae    b7ac <f0+0x3ac>
    b799:	49 01 c4             	add    %rax,%r12
    b79c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b7a1:	0f 84 8b 27 00 00    	je     df32 <f0+0x2b32>
    b7a7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b7ac:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b7b3:	33 f3 bf 
    b7b6:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b7bd:	00 
    b7be:	bf 01 00 00 00       	mov    $0x1,%edi
    b7c3:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b7ca:	00 
    b7cb:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b7d2:	00 
    b7d3:	e8 18 ad ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b7d8:	48 8b 15 79 93 01 00 	mov    0x19379(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    b7df:	49 89 c5             	mov    %rax,%r13
    b7e2:	48 2b 05 47 93 01 00 	sub    0x19347(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    b7e9:	48 c1 e2 10          	shl    $0x10,%rdx
    b7ed:	48 39 d0             	cmp    %rdx,%rax
    b7f0:	73 59                	jae    b84b <f0+0x44b>
    b7f2:	48 89 c2             	mov    %rax,%rdx
    b7f5:	48 c1 ea 10          	shr    $0x10,%rdx
    b7f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7fd:	48 8b 15 74 93 01 00 	mov    0x19374(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    b804:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b808:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b80c:	4d 85 e4             	test   %r12,%r12
    b80f:	74 3a                	je     b84b <f0+0x44b>
    b811:	0f b6 0a             	movzbl (%rdx),%ecx
    b814:	80 f9 02             	cmp    $0x2,%cl
    b817:	0f 84 43 25 00 00    	je     dd60 <f0+0x2960>
    b81d:	80 f9 01             	cmp    $0x1,%cl
    b820:	75 29                	jne    b84b <f0+0x44b>
    b822:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b825:	0f b7 c0             	movzwl %ax,%eax
    b828:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b82b:	48 0f af c1          	imul   %rcx,%rax
    b82f:	48 c1 e8 20          	shr    $0x20,%rax
    b833:	48 39 d0             	cmp    %rdx,%rax
    b836:	73 13                	jae    b84b <f0+0x44b>
    b838:	49 01 c4             	add    %rax,%r12
    b83b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b840:	0f 84 f9 26 00 00    	je     df3f <f0+0x2b3f>
    b846:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b84b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b852:	00 f0 3f 
    b855:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b85c:	00 
    b85d:	bf 01 00 00 00       	mov    $0x1,%edi
    b862:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b869:	00 
    b86a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b871:	00 
    b872:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b879:	33 f3 bf 
    b87c:	e8 6f ac ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b881:	48 89 c7             	mov    %rax,%rdi
    b884:	e8 17 ae ff ff       	call   66a0 <fwp_rc_fresh>
    b889:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b890:	00 
    b891:	bf 01 00 00 00       	mov    $0x1,%edi
    b896:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b89d:	00 
    b89e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b8a5:	00 
    b8a6:	e8 45 ac ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b8ab:	48 89 c7             	mov    %rax,%rdi
    b8ae:	e8 ed ad ff ff       	call   66a0 <fwp_rc_fresh>
    b8b3:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b8ba:	00 
    b8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c0:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b8c7:	00 
    b8c8:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b8cf:	00 
    b8d0:	e8 1b ac ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b8d5:	48 89 c7             	mov    %rax,%rdi
    b8d8:	e8 c3 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b8dd:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b8e4:	00 
    b8e5:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ea:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b8f1:	00 
    b8f2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b8f9:	00 
    b8fa:	e8 f1 ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b8ff:	48 89 c7             	mov    %rax,%rdi
    b902:	e8 99 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b907:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b90e:	00 
    b90f:	bf 01 00 00 00       	mov    $0x1,%edi
    b914:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b91b:	00 
    b91c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b923:	00 
    b924:	e8 c7 ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b929:	48 89 c7             	mov    %rax,%rdi
    b92c:	e8 6f ad ff ff       	call   66a0 <fwp_rc_fresh>
    b931:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b938:	00 
    b939:	bf 01 00 00 00       	mov    $0x1,%edi
    b93e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b945:	00 
    b946:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b94d:	00 
    b94e:	e8 9d ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b953:	48 89 c7             	mov    %rax,%rdi
    b956:	e8 45 ad ff ff       	call   66a0 <fwp_rc_fresh>
    b95b:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b962:	00 
    b963:	bf 01 00 00 00       	mov    $0x1,%edi
    b968:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b96f:	00 
    b970:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b977:	00 
    b978:	e8 73 ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b97d:	48 89 c7             	mov    %rax,%rdi
    b980:	e8 1b ad ff ff       	call   66a0 <fwp_rc_fresh>
    b985:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b98c:	00 
    b98d:	bf 01 00 00 00       	mov    $0x1,%edi
    b992:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b999:	00 
    b99a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b9a1:	00 
    b9a2:	e8 49 ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b9a7:	48 89 c7             	mov    %rax,%rdi
    b9aa:	e8 f1 ac ff ff       	call   66a0 <fwp_rc_fresh>
    b9af:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b9b6:	00 
    b9b7:	bf 01 00 00 00       	mov    $0x1,%edi
    b9bc:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b9c3:	00 
    b9c4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b9cb:	00 
    b9cc:	e8 1f ab ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b9d1:	48 89 c7             	mov    %rax,%rdi
    b9d4:	e8 c7 ac ff ff       	call   66a0 <fwp_rc_fresh>
    b9d9:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b9e0:	00 
    b9e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b9e6:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b9ed:	00 
    b9ee:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b9f5:	00 
    b9f6:	e8 f5 aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    b9fb:	48 89 c7             	mov    %rax,%rdi
    b9fe:	e8 9d ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba03:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    ba0a:	00 
    ba0b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba10:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    ba17:	00 
    ba18:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    ba1f:	00 
    ba20:	e8 cb aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ba25:	48 89 c7             	mov    %rax,%rdi
    ba28:	e8 73 ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba2d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    ba34:	00 
    ba35:	bf 01 00 00 00       	mov    $0x1,%edi
    ba3a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    ba41:	00 
    ba42:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    ba49:	00 
    ba4a:	e8 a1 aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ba4f:	48 89 c7             	mov    %rax,%rdi
    ba52:	e8 49 ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba57:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    ba5e:	00 
    ba5f:	bf 01 00 00 00       	mov    $0x1,%edi
    ba64:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    ba6b:	00 
    ba6c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    ba73:	00 
    ba74:	e8 77 aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ba79:	48 89 c7             	mov    %rax,%rdi
    ba7c:	e8 1f ac ff ff       	call   66a0 <fwp_rc_fresh>
    ba81:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    ba88:	00 
    ba89:	bf 01 00 00 00       	mov    $0x1,%edi
    ba8e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    ba95:	00 
    ba96:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    ba9d:	00 
    ba9e:	e8 4d aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    baa3:	48 89 c7             	mov    %rax,%rdi
    baa6:	e8 f5 ab ff ff       	call   66a0 <fwp_rc_fresh>
    baab:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bab2:	00 
    bab3:	bf 01 00 00 00       	mov    $0x1,%edi
    bab8:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    babf:	00 
    bac0:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bac7:	00 
    bac8:	e8 23 aa ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bacd:	48 89 c7             	mov    %rax,%rdi
    bad0:	e8 cb ab ff ff       	call   66a0 <fwp_rc_fresh>
    bad5:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    badc:	00 
    badd:	bf 01 00 00 00       	mov    $0x1,%edi
    bae2:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bae9:	00 
    baea:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    baf1:	00 
    baf2:	e8 f9 a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    baf7:	48 89 c7             	mov    %rax,%rdi
    bafa:	e8 a1 ab ff ff       	call   66a0 <fwp_rc_fresh>
    baff:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bb06:	00 
    bb07:	bf 01 00 00 00       	mov    $0x1,%edi
    bb0c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bb13:	00 
    bb14:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bb1b:	00 
    bb1c:	e8 cf a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bb21:	48 89 c7             	mov    %rax,%rdi
    bb24:	e8 77 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb29:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bb30:	00 
    bb31:	bf 01 00 00 00       	mov    $0x1,%edi
    bb36:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bb3d:	00 
    bb3e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bb45:	00 
    bb46:	e8 a5 a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bb4b:	48 89 c7             	mov    %rax,%rdi
    bb4e:	e8 4d ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb53:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bb5a:	00 
    bb5b:	bf 01 00 00 00       	mov    $0x1,%edi
    bb60:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    bb67:	00 
    bb68:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    bb6f:	00 
    bb70:	e8 7b a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bb75:	48 89 c7             	mov    %rax,%rdi
    bb78:	e8 23 ab ff ff       	call   66a0 <fwp_rc_fresh>
    bb7d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    bb84:	00 
    bb85:	bf 01 00 00 00       	mov    $0x1,%edi
    bb8a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    bb91:	00 
    bb92:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    bb99:	00 
    bb9a:	e8 51 a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bb9f:	48 89 c7             	mov    %rax,%rdi
    bba2:	e8 f9 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bba7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    bbae:	00 
    bbaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb4:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    bbbb:	00 
    bbbc:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bbc3:	00 
    bbc4:	e8 27 a9 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bbc9:	48 89 c7             	mov    %rax,%rdi
    bbcc:	e8 cf aa ff ff       	call   66a0 <fwp_rc_fresh>
    bbd1:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bbd8:	00 
    bbd9:	bf 01 00 00 00       	mov    $0x1,%edi
    bbde:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bbe5:	00 
    bbe6:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bbed:	00 
    bbee:	e8 fd a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bbf3:	48 89 c7             	mov    %rax,%rdi
    bbf6:	e8 a5 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bbfb:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bc02:	00 
    bc03:	bf 01 00 00 00       	mov    $0x1,%edi
    bc08:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bc0f:	00 
    bc10:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bc17:	00 
    bc18:	e8 d3 a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bc1d:	48 89 c7             	mov    %rax,%rdi
    bc20:	e8 7b aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc25:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bc2c:	00 
    bc2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc32:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bc39:	00 
    bc3a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bc41:	00 
    bc42:	e8 a9 a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bc47:	48 89 c7             	mov    %rax,%rdi
    bc4a:	e8 51 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc4f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bc56:	00 
    bc57:	bf 01 00 00 00       	mov    $0x1,%edi
    bc5c:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    bc63:	00 
    bc64:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    bc6b:	00 
    bc6c:	e8 7f a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bc71:	48 89 c7             	mov    %rax,%rdi
    bc74:	e8 27 aa ff ff       	call   66a0 <fwp_rc_fresh>
    bc79:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    bc80:	00 
    bc81:	bf 01 00 00 00       	mov    $0x1,%edi
    bc86:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    bc8d:	00 
    bc8e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    bc95:	00 
    bc96:	e8 55 a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bc9b:	48 89 c7             	mov    %rax,%rdi
    bc9e:	e8 fd a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bca3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    bcaa:	00 
    bcab:	bf 01 00 00 00       	mov    $0x1,%edi
    bcb0:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    bcb7:	00 
    bcb8:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    bcbf:	00 
    bcc0:	e8 2b a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bcc5:	48 89 c7             	mov    %rax,%rdi
    bcc8:	e8 d3 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bccd:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    bcd4:	00 
    bcd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bcda:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    bce1:	00 
    bce2:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    bce9:	00 
    bcea:	e8 01 a8 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bcef:	48 89 c7             	mov    %rax,%rdi
    bcf2:	e8 a9 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bcf7:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    bcfe:	00 
    bcff:	bf 01 00 00 00       	mov    $0x1,%edi
    bd04:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    bd0b:	00 
    bd0c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    bd13:	00 
    bd14:	e8 d7 a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bd19:	48 89 c7             	mov    %rax,%rdi
    bd1c:	e8 7f a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd21:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bd28:	00 
    bd29:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bd35:	00 
    bd36:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bd3d:	00 
    bd3e:	e8 ad a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bd43:	48 89 c7             	mov    %rax,%rdi
    bd46:	e8 55 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd4b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bd52:	00 
    bd53:	bf 01 00 00 00       	mov    $0x1,%edi
    bd58:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    bd5f:	00 
    bd60:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bd67:	00 
    bd68:	e8 83 a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bd6d:	48 89 c7             	mov    %rax,%rdi
    bd70:	e8 2b a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd75:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bd7c:	00 
    bd7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bd82:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bd89:	00 
    bd8a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bd91:	00 
    bd92:	e8 59 a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bd97:	48 89 c7             	mov    %rax,%rdi
    bd9a:	e8 01 a9 ff ff       	call   66a0 <fwp_rc_fresh>
    bd9f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bda6:	00 
    bda7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdac:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bdb3:	00 
    bdb4:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bdbb:	00 
    bdbc:	e8 2f a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bdc1:	48 89 c7             	mov    %rax,%rdi
    bdc4:	e8 d7 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    bdc9:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bdd0:	00 
    bdd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd6:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bddd:	00 
    bdde:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bde5:	00 
    bde6:	e8 05 a7 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bdeb:	48 89 c7             	mov    %rax,%rdi
    bdee:	e8 ad a8 ff ff       	call   66a0 <fwp_rc_fresh>
    bdf3:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bdfa:	00 
    bdfb:	bf 01 00 00 00       	mov    $0x1,%edi
    be00:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    be07:	00 
    be08:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    be0f:	00 
    be10:	e8 db a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    be15:	48 89 c7             	mov    %rax,%rdi
    be18:	e8 83 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be1d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    be24:	00 
    be25:	bf 01 00 00 00       	mov    $0x1,%edi
    be2a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    be31:	00 
    be32:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    be39:	00 
    be3a:	e8 b1 a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    be3f:	48 89 c7             	mov    %rax,%rdi
    be42:	e8 59 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be47:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    be4e:	00 
    be4f:	bf 01 00 00 00       	mov    $0x1,%edi
    be54:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    be5b:	00 
    be5c:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    be63:	00 
    be64:	e8 87 a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    be69:	48 89 c7             	mov    %rax,%rdi
    be6c:	e8 2f a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be71:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    be78:	00 
    be79:	bf 01 00 00 00       	mov    $0x1,%edi
    be7e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    be85:	00 
    be86:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    be8d:	00 
    be8e:	e8 5d a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    be93:	48 89 c7             	mov    %rax,%rdi
    be96:	e8 05 a8 ff ff       	call   66a0 <fwp_rc_fresh>
    be9b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    bea2:	00 
    bea3:	bf 01 00 00 00       	mov    $0x1,%edi
    bea8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    beaf:	00 
    beb0:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    beb7:	00 
    beb8:	e8 33 a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bebd:	48 89 c7             	mov    %rax,%rdi
    bec0:	e8 db a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bec5:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    becc:	00 
    becd:	bf 01 00 00 00       	mov    $0x1,%edi
    bed2:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bed9:	00 
    beda:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bee1:	00 
    bee2:	e8 09 a6 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bee7:	48 89 c7             	mov    %rax,%rdi
    beea:	e8 b1 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    beef:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bef6:	00 
    bef7:	bf 01 00 00 00       	mov    $0x1,%edi
    befc:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bf03:	00 
    bf04:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bf0b:	00 
    bf0c:	e8 df a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bf11:	48 89 c7             	mov    %rax,%rdi
    bf14:	e8 87 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf19:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bf20:	00 
    bf21:	bf 01 00 00 00       	mov    $0x1,%edi
    bf26:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bf2d:	00 
    bf2e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bf35:	00 
    bf36:	e8 b5 a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bf3b:	48 89 c7             	mov    %rax,%rdi
    bf3e:	e8 5d a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf43:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bf4a:	00 
    bf4b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf50:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bf57:	00 
    bf58:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bf5f:	00 
    bf60:	e8 8b a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bf65:	48 89 c7             	mov    %rax,%rdi
    bf68:	e8 33 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf6d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bf74:	00 
    bf75:	bf 01 00 00 00       	mov    $0x1,%edi
    bf7a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bf81:	00 
    bf82:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bf89:	00 
    bf8a:	e8 61 a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bf8f:	48 89 c7             	mov    %rax,%rdi
    bf92:	e8 09 a7 ff ff       	call   66a0 <fwp_rc_fresh>
    bf97:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bf9e:	00 
    bf9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bfab:	00 
    bfac:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bfb3:	00 
    bfb4:	e8 37 a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bfb9:	48 89 c7             	mov    %rax,%rdi
    bfbc:	e8 df a6 ff ff       	call   66a0 <fwp_rc_fresh>
    bfc1:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bfc8:	00 
    bfc9:	bf 01 00 00 00       	mov    $0x1,%edi
    bfce:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bfd5:	00 
    bfd6:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bfdd:	00 
    bfde:	e8 0d a5 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    bfe3:	48 89 c7             	mov    %rax,%rdi
    bfe6:	e8 b5 a6 ff ff       	call   66a0 <fwp_rc_fresh>
    bfeb:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bff2:	00 
    bff3:	bf 01 00 00 00       	mov    $0x1,%edi
    bff8:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bfff:	00 
    c000:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c007:	00 
    c008:	e8 e3 a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c00d:	48 89 c7             	mov    %rax,%rdi
    c010:	e8 8b a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c015:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c01c:	00 
    c01d:	bf 01 00 00 00       	mov    $0x1,%edi
    c022:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c029:	00 
    c02a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c031:	00 
    c032:	e8 b9 a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c037:	48 89 c7             	mov    %rax,%rdi
    c03a:	e8 61 a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c03f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c046:	00 
    c047:	bf 01 00 00 00       	mov    $0x1,%edi
    c04c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c053:	00 
    c054:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c05b:	00 
    c05c:	e8 8f a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c061:	48 89 c7             	mov    %rax,%rdi
    c064:	e8 37 a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c069:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c070:	00 
    c071:	bf 01 00 00 00       	mov    $0x1,%edi
    c076:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c07d:	00 
    c07e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c085:	00 
    c086:	e8 65 a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c08b:	48 89 c7             	mov    %rax,%rdi
    c08e:	e8 0d a6 ff ff       	call   66a0 <fwp_rc_fresh>
    c093:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c09a:	00 
    c09b:	bf 01 00 00 00       	mov    $0x1,%edi
    c0a0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c0a7:	00 
    c0a8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c0af:	00 
    c0b0:	e8 3b a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c0b5:	48 89 c7             	mov    %rax,%rdi
    c0b8:	e8 e3 a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c0bd:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c0c4:	00 
    c0c5:	bf 01 00 00 00       	mov    $0x1,%edi
    c0ca:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c0d1:	00 
    c0d2:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c0d9:	00 
    c0da:	e8 11 a4 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c0df:	48 89 c7             	mov    %rax,%rdi
    c0e2:	e8 b9 a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c0e7:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c0ee:	00 
    c0ef:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f4:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c0fb:	00 
    c0fc:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c103:	00 
    c104:	e8 e7 a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c109:	48 89 c7             	mov    %rax,%rdi
    c10c:	e8 8f a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c111:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c118:	00 
    c119:	bf 01 00 00 00       	mov    $0x1,%edi
    c11e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c125:	00 
    c126:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c12d:	00 
    c12e:	e8 bd a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c133:	48 89 c7             	mov    %rax,%rdi
    c136:	e8 65 a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c13b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c142:	00 
    c143:	bf 01 00 00 00       	mov    $0x1,%edi
    c148:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c14f:	00 
    c150:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c157:	00 
    c158:	e8 93 a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c15d:	48 89 c7             	mov    %rax,%rdi
    c160:	e8 3b a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c165:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c16c:	00 
    c16d:	bf 01 00 00 00       	mov    $0x1,%edi
    c172:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c179:	00 
    c17a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c181:	00 
    c182:	e8 69 a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c187:	48 89 c7             	mov    %rax,%rdi
    c18a:	e8 11 a5 ff ff       	call   66a0 <fwp_rc_fresh>
    c18f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c196:	00 
    c197:	bf 01 00 00 00       	mov    $0x1,%edi
    c19c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c1a3:	00 
    c1a4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c1ab:	00 
    c1ac:	e8 3f a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c1b1:	48 89 c7             	mov    %rax,%rdi
    c1b4:	e8 e7 a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c1b9:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c1c0:	00 
    c1c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c6:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c1cd:	00 
    c1ce:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c1d5:	00 
    c1d6:	e8 15 a3 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c1db:	48 89 c7             	mov    %rax,%rdi
    c1de:	e8 bd a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c1e3:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c1ea:	00 
    c1eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c1f0:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c1f7:	00 
    c1f8:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c1ff:	00 
    c200:	e8 eb a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c205:	48 89 c7             	mov    %rax,%rdi
    c208:	e8 93 a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c20d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c214:	00 
    c215:	bf 01 00 00 00       	mov    $0x1,%edi
    c21a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c221:	00 
    c222:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c229:	00 
    c22a:	e8 c1 a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c22f:	48 89 c7             	mov    %rax,%rdi
    c232:	e8 69 a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c237:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c23e:	00 
    c23f:	bf 01 00 00 00       	mov    $0x1,%edi
    c244:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c24b:	00 
    c24c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c253:	00 
    c254:	e8 97 a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c259:	48 89 c7             	mov    %rax,%rdi
    c25c:	e8 3f a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c261:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c268:	00 
    c269:	bf 01 00 00 00       	mov    $0x1,%edi
    c26e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c275:	00 
    c276:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c27d:	00 
    c27e:	e8 6d a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c283:	48 89 c7             	mov    %rax,%rdi
    c286:	e8 15 a4 ff ff       	call   66a0 <fwp_rc_fresh>
    c28b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c292:	00 
    c293:	bf 01 00 00 00       	mov    $0x1,%edi
    c298:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c29f:	00 
    c2a0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c2a7:	00 
    c2a8:	e8 43 a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c2ad:	48 89 c7             	mov    %rax,%rdi
    c2b0:	e8 eb a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c2b5:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c2bc:	00 
    c2bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c2c2:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c2c9:	00 
    c2ca:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c2d1:	00 
    c2d2:	e8 19 a2 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c2d7:	48 89 c7             	mov    %rax,%rdi
    c2da:	e8 c1 a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c2df:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c2e6:	00 
    c2e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ec:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c2f3:	00 
    c2f4:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c2fb:	00 
    c2fc:	e8 ef a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c301:	48 89 c7             	mov    %rax,%rdi
    c304:	e8 97 a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c309:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c310:	00 
    c311:	bf 01 00 00 00       	mov    $0x1,%edi
    c316:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c31d:	00 
    c31e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c325:	00 
    c326:	e8 c5 a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c32b:	48 89 c7             	mov    %rax,%rdi
    c32e:	e8 6d a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c333:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c33a:	00 
    c33b:	bf 01 00 00 00       	mov    $0x1,%edi
    c340:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c347:	00 
    c348:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c34f:	00 
    c350:	e8 9b a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c355:	48 89 c7             	mov    %rax,%rdi
    c358:	e8 43 a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c35d:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c364:	00 
    c365:	bf 01 00 00 00       	mov    $0x1,%edi
    c36a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c371:	00 
    c372:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c379:	00 
    c37a:	e8 71 a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c37f:	48 89 c7             	mov    %rax,%rdi
    c382:	e8 19 a3 ff ff       	call   66a0 <fwp_rc_fresh>
    c387:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c38e:	00 
    c38f:	bf 01 00 00 00       	mov    $0x1,%edi
    c394:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c39b:	00 
    c39c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c3a3:	00 
    c3a4:	e8 47 a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c3a9:	48 89 c7             	mov    %rax,%rdi
    c3ac:	e8 ef a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c3b1:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c3b8:	00 
    c3b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c3be:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c3c5:	00 
    c3c6:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c3cd:	00 
    c3ce:	e8 1d a1 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c3d3:	48 89 c7             	mov    %rax,%rdi
    c3d6:	e8 c5 a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c3db:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c3e2:	00 
    c3e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e8:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c3ef:	00 
    c3f0:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c3f7:	00 
    c3f8:	e8 f3 a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c3fd:	48 89 c7             	mov    %rax,%rdi
    c400:	e8 9b a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c405:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c40c:	00 
    c40d:	bf 01 00 00 00       	mov    $0x1,%edi
    c412:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c419:	00 
    c41a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c421:	00 
    c422:	e8 c9 a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c427:	48 89 c7             	mov    %rax,%rdi
    c42a:	e8 71 a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c42f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c436:	00 
    c437:	bf 01 00 00 00       	mov    $0x1,%edi
    c43c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c443:	00 
    c444:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c44b:	00 
    c44c:	e8 9f a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c451:	48 89 c7             	mov    %rax,%rdi
    c454:	e8 47 a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c459:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c460:	00 
    c461:	bf 01 00 00 00       	mov    $0x1,%edi
    c466:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c46d:	00 
    c46e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c475:	00 
    c476:	e8 75 a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c47b:	48 89 c7             	mov    %rax,%rdi
    c47e:	e8 1d a2 ff ff       	call   66a0 <fwp_rc_fresh>
    c483:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c48a:	00 
    c48b:	bf 01 00 00 00       	mov    $0x1,%edi
    c490:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c497:	00 
    c498:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c49f:	00 
    c4a0:	e8 4b a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c4a5:	48 89 c7             	mov    %rax,%rdi
    c4a8:	e8 f3 a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c4ad:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c4b4:	00 
    c4b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c4ba:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c4c1:	00 
    c4c2:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c4c9:	00 
    c4ca:	e8 21 a0 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c4cf:	48 89 c7             	mov    %rax,%rdi
    c4d2:	e8 c9 a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c4d7:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c4de:	00 
    c4df:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e4:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c4eb:	00 
    c4ec:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c4f3:	00 
    c4f4:	e8 f7 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c4f9:	48 89 c7             	mov    %rax,%rdi
    c4fc:	e8 9f a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c501:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c508:	00 
    c509:	bf 01 00 00 00       	mov    $0x1,%edi
    c50e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c515:	00 
    c516:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c51d:	00 
    c51e:	e8 cd 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c523:	48 89 c7             	mov    %rax,%rdi
    c526:	e8 75 a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c52b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c532:	00 
    c533:	bf 01 00 00 00       	mov    $0x1,%edi
    c538:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c53f:	00 
    c540:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c547:	00 
    c548:	e8 a3 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c54d:	48 89 c7             	mov    %rax,%rdi
    c550:	e8 4b a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c555:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c55c:	00 
    c55d:	bf 01 00 00 00       	mov    $0x1,%edi
    c562:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c569:	00 
    c56a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c571:	00 
    c572:	e8 79 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c577:	48 89 c7             	mov    %rax,%rdi
    c57a:	e8 21 a1 ff ff       	call   66a0 <fwp_rc_fresh>
    c57f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c586:	00 
    c587:	bf 01 00 00 00       	mov    $0x1,%edi
    c58c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c593:	00 
    c594:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c59b:	00 
    c59c:	e8 4f 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c5a1:	48 89 c7             	mov    %rax,%rdi
    c5a4:	e8 f7 a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c5a9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c5b0:	00 
    c5b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b6:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c5bd:	00 
    c5be:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c5c5:	00 
    c5c6:	e8 25 9f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c5cb:	48 89 c7             	mov    %rax,%rdi
    c5ce:	e8 cd a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c5d3:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c5da:	00 
    c5db:	bf 01 00 00 00       	mov    $0x1,%edi
    c5e0:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c5e7:	00 
    c5e8:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c5ef:	00 
    c5f0:	e8 fb 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c5f5:	48 89 c7             	mov    %rax,%rdi
    c5f8:	e8 a3 a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c5fd:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c604:	00 
    c605:	bf 01 00 00 00       	mov    $0x1,%edi
    c60a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c611:	00 
    c612:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c619:	00 
    c61a:	e8 d1 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c61f:	48 89 c7             	mov    %rax,%rdi
    c622:	e8 79 a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c627:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c62e:	00 
    c62f:	bf 01 00 00 00       	mov    $0x1,%edi
    c634:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c63b:	00 
    c63c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c643:	00 
    c644:	e8 a7 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c649:	48 89 c7             	mov    %rax,%rdi
    c64c:	e8 4f a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c651:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c658:	00 
    c659:	bf 01 00 00 00       	mov    $0x1,%edi
    c65e:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c665:	00 
    c666:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c66d:	00 
    c66e:	e8 7d 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c673:	48 89 c7             	mov    %rax,%rdi
    c676:	e8 25 a0 ff ff       	call   66a0 <fwp_rc_fresh>
    c67b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c682:	00 
    c683:	bf 01 00 00 00       	mov    $0x1,%edi
    c688:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c68f:	00 
    c690:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c697:	00 
    c698:	e8 53 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c69d:	48 89 c7             	mov    %rax,%rdi
    c6a0:	e8 fb 9f ff ff       	call   66a0 <fwp_rc_fresh>
    c6a5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c6ac:	00 
    c6ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c6b2:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c6b9:	00 
    c6ba:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c6c1:	00 
    c6c2:	e8 29 9e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c6c7:	48 89 c7             	mov    %rax,%rdi
    c6ca:	e8 d1 9f ff ff       	call   66a0 <fwp_rc_fresh>
    c6cf:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c6d6:	00 
    c6d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c6dc:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c6e3:	00 
    c6e4:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c6eb:	00 
    c6ec:	e8 ff 9d ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c6f1:	48 89 c7             	mov    %rax,%rdi
    c6f4:	e8 a7 9f ff ff       	call   66a0 <fwp_rc_fresh>
    c6f9:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c700:	00 
    c701:	bf 01 00 00 00       	mov    $0x1,%edi
    c706:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c70d:	00 
    c70e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c715:	00 
    c716:	e8 d5 9d ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c71b:	48 89 c7             	mov    %rax,%rdi
    c71e:	e8 7d 9f ff ff       	call   66a0 <fwp_rc_fresh>
    c723:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c72a:	00 
    c72b:	bf 01 00 00 00       	mov    $0x1,%edi
    c730:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c737:	00 
    c738:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c73f:	00 
    c740:	e8 ab 9d ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c745:	48 8b 15 0c 84 01 00 	mov    0x1840c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c74c:	49 89 c5             	mov    %rax,%r13
    c74f:	48 2b 05 da 83 01 00 	sub    0x183da(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c756:	48 c1 e2 10          	shl    $0x10,%rdx
    c75a:	48 39 d0             	cmp    %rdx,%rax
    c75d:	73 59                	jae    c7b8 <f0+0x13b8>
    c75f:	48 89 c2             	mov    %rax,%rdx
    c762:	48 c1 ea 10          	shr    $0x10,%rdx
    c766:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c76a:	48 8b 15 07 84 01 00 	mov    0x18407(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c771:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c775:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c779:	4d 85 e4             	test   %r12,%r12
    c77c:	74 3a                	je     c7b8 <f0+0x13b8>
    c77e:	0f b6 0a             	movzbl (%rdx),%ecx
    c781:	80 f9 02             	cmp    $0x2,%cl
    c784:	0f 84 c6 15 00 00    	je     dd50 <f0+0x2950>
    c78a:	80 f9 01             	cmp    $0x1,%cl
    c78d:	75 29                	jne    c7b8 <f0+0x13b8>
    c78f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c792:	0f b7 c0             	movzwl %ax,%eax
    c795:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c798:	48 0f af c1          	imul   %rcx,%rax
    c79c:	48 c1 e8 20          	shr    $0x20,%rax
    c7a0:	48 39 d0             	cmp    %rdx,%rax
    c7a3:	73 13                	jae    c7b8 <f0+0x13b8>
    c7a5:	49 01 c4             	add    %rax,%r12
    c7a8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7ad:	0f 84 99 17 00 00    	je     df4c <f0+0x2b4c>
    c7b3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7b8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7bf:	33 f3 bf 
    c7c2:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c7c9:	00 
    c7ca:	bf 01 00 00 00       	mov    $0x1,%edi
    c7cf:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c7d6:	00 
    c7d7:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c7de:	00 
    c7df:	e8 0c 9d ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c7e4:	48 8b 15 6d 83 01 00 	mov    0x1836d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c7eb:	49 89 c5             	mov    %rax,%r13
    c7ee:	48 2b 05 3b 83 01 00 	sub    0x1833b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c7f5:	48 c1 e2 10          	shl    $0x10,%rdx
    c7f9:	48 39 d0             	cmp    %rdx,%rax
    c7fc:	73 59                	jae    c857 <f0+0x1457>
    c7fe:	48 89 c2             	mov    %rax,%rdx
    c801:	48 c1 ea 10          	shr    $0x10,%rdx
    c805:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c809:	48 8b 15 68 83 01 00 	mov    0x18368(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c810:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c814:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c818:	4d 85 e4             	test   %r12,%r12
    c81b:	74 3a                	je     c857 <f0+0x1457>
    c81d:	0f b6 0a             	movzbl (%rdx),%ecx
    c820:	80 f9 02             	cmp    $0x2,%cl
    c823:	0f 84 17 15 00 00    	je     dd40 <f0+0x2940>
    c829:	80 f9 01             	cmp    $0x1,%cl
    c82c:	75 29                	jne    c857 <f0+0x1457>
    c82e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c831:	0f b7 c0             	movzwl %ax,%eax
    c834:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c837:	48 0f af c1          	imul   %rcx,%rax
    c83b:	48 c1 e8 20          	shr    $0x20,%rax
    c83f:	48 39 d0             	cmp    %rdx,%rax
    c842:	73 13                	jae    c857 <f0+0x1457>
    c844:	49 01 c4             	add    %rax,%r12
    c847:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c84c:	0f 84 07 17 00 00    	je     df59 <f0+0x2b59>
    c852:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c857:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c85e:	00 f0 3f 
    c861:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c868:	00 
    c869:	bf 01 00 00 00       	mov    $0x1,%edi
    c86e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c875:	00 
    c876:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c87d:	00 
    c87e:	e8 6d 9c ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c883:	48 8b 15 ce 82 01 00 	mov    0x182ce(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c88a:	49 89 c5             	mov    %rax,%r13
    c88d:	48 2b 05 9c 82 01 00 	sub    0x1829c(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c894:	48 c1 e2 10          	shl    $0x10,%rdx
    c898:	48 39 d0             	cmp    %rdx,%rax
    c89b:	73 59                	jae    c8f6 <f0+0x14f6>
    c89d:	48 89 c2             	mov    %rax,%rdx
    c8a0:	48 c1 ea 10          	shr    $0x10,%rdx
    c8a4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8a8:	48 8b 15 c9 82 01 00 	mov    0x182c9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c8af:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8b3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8b7:	4d 85 e4             	test   %r12,%r12
    c8ba:	74 3a                	je     c8f6 <f0+0x14f6>
    c8bc:	0f b6 0a             	movzbl (%rdx),%ecx
    c8bf:	80 f9 02             	cmp    $0x2,%cl
    c8c2:	0f 84 28 15 00 00    	je     ddf0 <f0+0x29f0>
    c8c8:	80 f9 01             	cmp    $0x1,%cl
    c8cb:	75 29                	jne    c8f6 <f0+0x14f6>
    c8cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8d0:	0f b7 c0             	movzwl %ax,%eax
    c8d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8d6:	48 0f af c1          	imul   %rcx,%rax
    c8da:	48 c1 e8 20          	shr    $0x20,%rax
    c8de:	48 39 d0             	cmp    %rdx,%rax
    c8e1:	73 13                	jae    c8f6 <f0+0x14f6>
    c8e3:	49 01 c4             	add    %rax,%r12
    c8e6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8eb:	0f 84 75 16 00 00    	je     df66 <f0+0x2b66>
    c8f1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c8f6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c8fd:	33 f3 bf 
    c900:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c907:	00 
    c908:	bf 01 00 00 00       	mov    $0x1,%edi
    c90d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c914:	00 
    c915:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c91c:	00 
    c91d:	e8 ce 9b ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c922:	48 8b 15 2f 82 01 00 	mov    0x1822f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c929:	49 89 c5             	mov    %rax,%r13
    c92c:	48 2b 05 fd 81 01 00 	sub    0x181fd(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c933:	48 c1 e2 10          	shl    $0x10,%rdx
    c937:	48 39 d0             	cmp    %rdx,%rax
    c93a:	73 59                	jae    c995 <f0+0x1595>
    c93c:	48 89 c2             	mov    %rax,%rdx
    c93f:	48 c1 ea 10          	shr    $0x10,%rdx
    c943:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c947:	48 8b 15 2a 82 01 00 	mov    0x1822a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c94e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c952:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c956:	4d 85 e4             	test   %r12,%r12
    c959:	74 3a                	je     c995 <f0+0x1595>
    c95b:	0f b6 0a             	movzbl (%rdx),%ecx
    c95e:	80 f9 02             	cmp    $0x2,%cl
    c961:	0f 84 79 14 00 00    	je     dde0 <f0+0x29e0>
    c967:	80 f9 01             	cmp    $0x1,%cl
    c96a:	75 29                	jne    c995 <f0+0x1595>
    c96c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c96f:	0f b7 c0             	movzwl %ax,%eax
    c972:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c975:	48 0f af c1          	imul   %rcx,%rax
    c979:	48 c1 e8 20          	shr    $0x20,%rax
    c97d:	48 39 d0             	cmp    %rdx,%rax
    c980:	73 13                	jae    c995 <f0+0x1595>
    c982:	49 01 c4             	add    %rax,%r12
    c985:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c98a:	0f 84 e3 15 00 00    	je     df73 <f0+0x2b73>
    c990:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c995:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c99c:	00 f0 3f 
    c99f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c9a6:	00 
    c9a7:	bf 01 00 00 00       	mov    $0x1,%edi
    c9ac:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c9b3:	00 
    c9b4:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c9bb:	00 
    c9bc:	e8 2f 9b ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    c9c1:	48 8b 15 90 81 01 00 	mov    0x18190(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    c9c8:	49 89 c5             	mov    %rax,%r13
    c9cb:	48 2b 05 5e 81 01 00 	sub    0x1815e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    c9d2:	48 c1 e2 10          	shl    $0x10,%rdx
    c9d6:	48 39 d0             	cmp    %rdx,%rax
    c9d9:	73 59                	jae    ca34 <f0+0x1634>
    c9db:	48 89 c2             	mov    %rax,%rdx
    c9de:	48 c1 ea 10          	shr    $0x10,%rdx
    c9e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9e6:	48 8b 15 8b 81 01 00 	mov    0x1818b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    c9ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9f1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9f5:	4d 85 e4             	test   %r12,%r12
    c9f8:	74 3a                	je     ca34 <f0+0x1634>
    c9fa:	0f b6 0a             	movzbl (%rdx),%ecx
    c9fd:	80 f9 02             	cmp    $0x2,%cl
    ca00:	0f 84 ca 13 00 00    	je     ddd0 <f0+0x29d0>
    ca06:	80 f9 01             	cmp    $0x1,%cl
    ca09:	75 29                	jne    ca34 <f0+0x1634>
    ca0b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca0e:	0f b7 c0             	movzwl %ax,%eax
    ca11:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca14:	48 0f af c1          	imul   %rcx,%rax
    ca18:	48 c1 e8 20          	shr    $0x20,%rax
    ca1c:	48 39 d0             	cmp    %rdx,%rax
    ca1f:	73 13                	jae    ca34 <f0+0x1634>
    ca21:	49 01 c4             	add    %rax,%r12
    ca24:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca29:	0f 84 51 15 00 00    	je     df80 <f0+0x2b80>
    ca2f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca34:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca3b:	33 f3 bf 
    ca3e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    ca45:	00 
    ca46:	bf 01 00 00 00       	mov    $0x1,%edi
    ca4b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    ca52:	00 
    ca53:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    ca5a:	00 
    ca5b:	e8 90 9a ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ca60:	48 8b 15 f1 80 01 00 	mov    0x180f1(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ca67:	49 89 c5             	mov    %rax,%r13
    ca6a:	48 2b 05 bf 80 01 00 	sub    0x180bf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ca71:	48 c1 e2 10          	shl    $0x10,%rdx
    ca75:	48 39 d0             	cmp    %rdx,%rax
    ca78:	73 59                	jae    cad3 <f0+0x16d3>
    ca7a:	48 89 c2             	mov    %rax,%rdx
    ca7d:	48 c1 ea 10          	shr    $0x10,%rdx
    ca81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca85:	48 8b 15 ec 80 01 00 	mov    0x180ec(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ca8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca90:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca94:	4d 85 e4             	test   %r12,%r12
    ca97:	74 3a                	je     cad3 <f0+0x16d3>
    ca99:	0f b6 0a             	movzbl (%rdx),%ecx
    ca9c:	80 f9 02             	cmp    $0x2,%cl
    ca9f:	0f 84 1b 13 00 00    	je     ddc0 <f0+0x29c0>
    caa5:	80 f9 01             	cmp    $0x1,%cl
    caa8:	75 29                	jne    cad3 <f0+0x16d3>
    caaa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    caad:	0f b7 c0             	movzwl %ax,%eax
    cab0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cab3:	48 0f af c1          	imul   %rcx,%rax
    cab7:	48 c1 e8 20          	shr    $0x20,%rax
    cabb:	48 39 d0             	cmp    %rdx,%rax
    cabe:	73 13                	jae    cad3 <f0+0x16d3>
    cac0:	49 01 c4             	add    %rax,%r12
    cac3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cac8:	0f 84 bf 14 00 00    	je     df8d <f0+0x2b8d>
    cace:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cad3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cada:	00 f0 3f 
    cadd:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cae4:	00 
    cae5:	bf 01 00 00 00       	mov    $0x1,%edi
    caea:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    caf1:	00 
    caf2:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    caf9:	00 
    cafa:	e8 f1 99 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    caff:	48 8b 15 52 80 01 00 	mov    0x18052(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cb06:	49 89 c5             	mov    %rax,%r13
    cb09:	48 2b 05 20 80 01 00 	sub    0x18020(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cb10:	48 c1 e2 10          	shl    $0x10,%rdx
    cb14:	48 39 d0             	cmp    %rdx,%rax
    cb17:	73 59                	jae    cb72 <f0+0x1772>
    cb19:	48 89 c2             	mov    %rax,%rdx
    cb1c:	48 c1 ea 10          	shr    $0x10,%rdx
    cb20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb24:	48 8b 15 4d 80 01 00 	mov    0x1804d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cb2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb2f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb33:	4d 85 e4             	test   %r12,%r12
    cb36:	74 3a                	je     cb72 <f0+0x1772>
    cb38:	0f b6 0a             	movzbl (%rdx),%ecx
    cb3b:	80 f9 02             	cmp    $0x2,%cl
    cb3e:	0f 84 6c 12 00 00    	je     ddb0 <f0+0x29b0>
    cb44:	80 f9 01             	cmp    $0x1,%cl
    cb47:	75 29                	jne    cb72 <f0+0x1772>
    cb49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb4c:	0f b7 c0             	movzwl %ax,%eax
    cb4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb52:	48 0f af c1          	imul   %rcx,%rax
    cb56:	48 c1 e8 20          	shr    $0x20,%rax
    cb5a:	48 39 d0             	cmp    %rdx,%rax
    cb5d:	73 13                	jae    cb72 <f0+0x1772>
    cb5f:	49 01 c4             	add    %rax,%r12
    cb62:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb67:	0f 84 2d 14 00 00    	je     df9a <f0+0x2b9a>
    cb6d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb72:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb79:	33 f3 bf 
    cb7c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    cb83:	00 
    cb84:	bf 01 00 00 00       	mov    $0x1,%edi
    cb89:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    cb90:	00 
    cb91:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    cb98:	00 
    cb99:	e8 52 99 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    cb9e:	48 8b 15 b3 7f 01 00 	mov    0x17fb3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cba5:	49 89 c5             	mov    %rax,%r13
    cba8:	48 2b 05 81 7f 01 00 	sub    0x17f81(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cbaf:	48 c1 e2 10          	shl    $0x10,%rdx
    cbb3:	48 39 d0             	cmp    %rdx,%rax
    cbb6:	73 59                	jae    cc11 <f0+0x1811>
    cbb8:	48 89 c2             	mov    %rax,%rdx
    cbbb:	48 c1 ea 10          	shr    $0x10,%rdx
    cbbf:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbc3:	48 8b 15 ae 7f 01 00 	mov    0x17fae(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cbca:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbce:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbd2:	4d 85 e4             	test   %r12,%r12
    cbd5:	74 3a                	je     cc11 <f0+0x1811>
    cbd7:	0f b6 0a             	movzbl (%rdx),%ecx
    cbda:	80 f9 02             	cmp    $0x2,%cl
    cbdd:	0f 84 bd 11 00 00    	je     dda0 <f0+0x29a0>
    cbe3:	80 f9 01             	cmp    $0x1,%cl
    cbe6:	75 29                	jne    cc11 <f0+0x1811>
    cbe8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbeb:	0f b7 c0             	movzwl %ax,%eax
    cbee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbf1:	48 0f af c1          	imul   %rcx,%rax
    cbf5:	48 c1 e8 20          	shr    $0x20,%rax
    cbf9:	48 39 d0             	cmp    %rdx,%rax
    cbfc:	73 13                	jae    cc11 <f0+0x1811>
    cbfe:	49 01 c4             	add    %rax,%r12
    cc01:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc06:	0f 84 9b 13 00 00    	je     dfa7 <f0+0x2ba7>
    cc0c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc11:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc18:	00 f0 3f 
    cc1b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cc22:	00 
    cc23:	bf 01 00 00 00       	mov    $0x1,%edi
    cc28:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cc2f:	00 
    cc30:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cc37:	00 
    cc38:	e8 b3 98 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    cc3d:	48 8b 15 14 7f 01 00 	mov    0x17f14(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cc44:	49 89 c5             	mov    %rax,%r13
    cc47:	48 2b 05 e2 7e 01 00 	sub    0x17ee2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cc4e:	48 c1 e2 10          	shl    $0x10,%rdx
    cc52:	48 39 d0             	cmp    %rdx,%rax
    cc55:	73 59                	jae    ccb0 <f0+0x18b0>
    cc57:	48 89 c2             	mov    %rax,%rdx
    cc5a:	48 c1 ea 10          	shr    $0x10,%rdx
    cc5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc62:	48 8b 15 0f 7f 01 00 	mov    0x17f0f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cc69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc6d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc71:	4d 85 e4             	test   %r12,%r12
    cc74:	74 3a                	je     ccb0 <f0+0x18b0>
    cc76:	0f b6 0a             	movzbl (%rdx),%ecx
    cc79:	80 f9 02             	cmp    $0x2,%cl
    cc7c:	0f 84 0e 11 00 00    	je     dd90 <f0+0x2990>
    cc82:	80 f9 01             	cmp    $0x1,%cl
    cc85:	75 29                	jne    ccb0 <f0+0x18b0>
    cc87:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc8a:	0f b7 c0             	movzwl %ax,%eax
    cc8d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc90:	48 0f af c1          	imul   %rcx,%rax
    cc94:	48 c1 e8 20          	shr    $0x20,%rax
    cc98:	48 39 d0             	cmp    %rdx,%rax
    cc9b:	73 13                	jae    ccb0 <f0+0x18b0>
    cc9d:	49 01 c4             	add    %rax,%r12
    cca0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cca5:	0f 84 09 13 00 00    	je     dfb4 <f0+0x2bb4>
    ccab:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccb0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccb7:	33 f3 bf 
    ccba:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    ccc1:	00 
    ccc2:	bf 01 00 00 00       	mov    $0x1,%edi
    ccc7:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    ccce:	00 
    cccf:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    ccd6:	00 
    ccd7:	e8 14 98 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ccdc:	48 8b 15 75 7e 01 00 	mov    0x17e75(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cce3:	49 89 c5             	mov    %rax,%r13
    cce6:	48 2b 05 43 7e 01 00 	sub    0x17e43(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cced:	48 c1 e2 10          	shl    $0x10,%rdx
    ccf1:	48 39 d0             	cmp    %rdx,%rax
    ccf4:	73 59                	jae    cd4f <f0+0x194f>
    ccf6:	48 89 c2             	mov    %rax,%rdx
    ccf9:	48 c1 ea 10          	shr    $0x10,%rdx
    ccfd:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd01:	48 8b 15 70 7e 01 00 	mov    0x17e70(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cd08:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd0c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd10:	4d 85 e4             	test   %r12,%r12
    cd13:	74 3a                	je     cd4f <f0+0x194f>
    cd15:	0f b6 0a             	movzbl (%rdx),%ecx
    cd18:	80 f9 02             	cmp    $0x2,%cl
    cd1b:	0f 84 5f 10 00 00    	je     dd80 <f0+0x2980>
    cd21:	80 f9 01             	cmp    $0x1,%cl
    cd24:	75 29                	jne    cd4f <f0+0x194f>
    cd26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd29:	0f b7 c0             	movzwl %ax,%eax
    cd2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd2f:	48 0f af c1          	imul   %rcx,%rax
    cd33:	48 c1 e8 20          	shr    $0x20,%rax
    cd37:	48 39 d0             	cmp    %rdx,%rax
    cd3a:	73 13                	jae    cd4f <f0+0x194f>
    cd3c:	49 01 c4             	add    %rax,%r12
    cd3f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd44:	0f 84 77 12 00 00    	je     dfc1 <f0+0x2bc1>
    cd4a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd4f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd56:	00 f0 3f 
    cd59:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cd60:	00 
    cd61:	bf 01 00 00 00       	mov    $0x1,%edi
    cd66:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cd6d:	00 
    cd6e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cd75:	00 
    cd76:	e8 75 97 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    cd7b:	48 8b 15 d6 7d 01 00 	mov    0x17dd6(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cd82:	49 89 c5             	mov    %rax,%r13
    cd85:	48 2b 05 a4 7d 01 00 	sub    0x17da4(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cd8c:	48 c1 e2 10          	shl    $0x10,%rdx
    cd90:	48 39 d0             	cmp    %rdx,%rax
    cd93:	73 59                	jae    cdee <f0+0x19ee>
    cd95:	48 89 c2             	mov    %rax,%rdx
    cd98:	48 c1 ea 10          	shr    $0x10,%rdx
    cd9c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cda0:	48 8b 15 d1 7d 01 00 	mov    0x17dd1(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cda7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdab:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdaf:	4d 85 e4             	test   %r12,%r12
    cdb2:	74 3a                	je     cdee <f0+0x19ee>
    cdb4:	0f b6 0a             	movzbl (%rdx),%ecx
    cdb7:	80 f9 02             	cmp    $0x2,%cl
    cdba:	0f 84 40 0f 00 00    	je     dd00 <f0+0x2900>
    cdc0:	80 f9 01             	cmp    $0x1,%cl
    cdc3:	75 29                	jne    cdee <f0+0x19ee>
    cdc5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdc8:	0f b7 c0             	movzwl %ax,%eax
    cdcb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdce:	48 0f af c1          	imul   %rcx,%rax
    cdd2:	48 c1 e8 20          	shr    $0x20,%rax
    cdd6:	48 39 d0             	cmp    %rdx,%rax
    cdd9:	73 13                	jae    cdee <f0+0x19ee>
    cddb:	49 01 c4             	add    %rax,%r12
    cdde:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cde3:	0f 84 e5 11 00 00    	je     dfce <f0+0x2bce>
    cde9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdee:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cdf5:	33 f3 bf 
    cdf8:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cdff:	00 
    ce00:	bf 01 00 00 00       	mov    $0x1,%edi
    ce05:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    ce0c:	00 
    ce0d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    ce14:	00 
    ce15:	e8 d6 96 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ce1a:	48 8b 15 37 7d 01 00 	mov    0x17d37(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    ce21:	49 89 c5             	mov    %rax,%r13
    ce24:	48 2b 05 05 7d 01 00 	sub    0x17d05(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ce2b:	48 c1 e2 10          	shl    $0x10,%rdx
    ce2f:	48 39 d0             	cmp    %rdx,%rax
    ce32:	73 59                	jae    ce8d <f0+0x1a8d>
    ce34:	48 89 c2             	mov    %rax,%rdx
    ce37:	48 c1 ea 10          	shr    $0x10,%rdx
    ce3b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce3f:	48 8b 15 32 7d 01 00 	mov    0x17d32(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    ce46:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce4a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce4e:	4d 85 e4             	test   %r12,%r12
    ce51:	74 3a                	je     ce8d <f0+0x1a8d>
    ce53:	0f b6 0a             	movzbl (%rdx),%ecx
    ce56:	80 f9 02             	cmp    $0x2,%cl
    ce59:	0f 84 91 0e 00 00    	je     dcf0 <f0+0x28f0>
    ce5f:	80 f9 01             	cmp    $0x1,%cl
    ce62:	75 29                	jne    ce8d <f0+0x1a8d>
    ce64:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce67:	0f b7 c0             	movzwl %ax,%eax
    ce6a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce6d:	48 0f af c1          	imul   %rcx,%rax
    ce71:	48 c1 e8 20          	shr    $0x20,%rax
    ce75:	48 39 d0             	cmp    %rdx,%rax
    ce78:	73 13                	jae    ce8d <f0+0x1a8d>
    ce7a:	49 01 c4             	add    %rax,%r12
    ce7d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce82:	0f 84 53 11 00 00    	je     dfdb <f0+0x2bdb>
    ce88:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce8d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce94:	00 f0 3f 
    ce97:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    ce9e:	00 
    ce9f:	bf 01 00 00 00       	mov    $0x1,%edi
    cea4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    ceab:	00 
    ceac:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    ceb3:	00 
    ceb4:	e8 37 96 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    ceb9:	48 8b 15 98 7c 01 00 	mov    0x17c98(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cec0:	49 89 c5             	mov    %rax,%r13
    cec3:	48 2b 05 66 7c 01 00 	sub    0x17c66(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    ceca:	48 c1 e2 10          	shl    $0x10,%rdx
    cece:	48 39 d0             	cmp    %rdx,%rax
    ced1:	73 59                	jae    cf2c <f0+0x1b2c>
    ced3:	48 89 c2             	mov    %rax,%rdx
    ced6:	48 c1 ea 10          	shr    $0x10,%rdx
    ceda:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cede:	48 8b 15 93 7c 01 00 	mov    0x17c93(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cee5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cee9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceed:	4d 85 e4             	test   %r12,%r12
    cef0:	74 3a                	je     cf2c <f0+0x1b2c>
    cef2:	0f b6 0a             	movzbl (%rdx),%ecx
    cef5:	80 f9 02             	cmp    $0x2,%cl
    cef8:	0f 84 e2 0d 00 00    	je     dce0 <f0+0x28e0>
    cefe:	80 f9 01             	cmp    $0x1,%cl
    cf01:	75 29                	jne    cf2c <f0+0x1b2c>
    cf03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf06:	0f b7 c0             	movzwl %ax,%eax
    cf09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf0c:	48 0f af c1          	imul   %rcx,%rax
    cf10:	48 c1 e8 20          	shr    $0x20,%rax
    cf14:	48 39 d0             	cmp    %rdx,%rax
    cf17:	73 13                	jae    cf2c <f0+0x1b2c>
    cf19:	49 01 c4             	add    %rax,%r12
    cf1c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf21:	0f 84 c1 10 00 00    	je     dfe8 <f0+0x2be8>
    cf27:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf2c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf33:	33 f3 bf 
    cf36:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cf3d:	00 
    cf3e:	bf 01 00 00 00       	mov    $0x1,%edi
    cf43:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cf4a:	00 
    cf4b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cf52:	00 
    cf53:	e8 98 95 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    cf58:	48 8b 15 f9 7b 01 00 	mov    0x17bf9(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cf5f:	49 89 c5             	mov    %rax,%r13
    cf62:	48 2b 05 c7 7b 01 00 	sub    0x17bc7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    cf69:	48 c1 e2 10          	shl    $0x10,%rdx
    cf6d:	48 39 d0             	cmp    %rdx,%rax
    cf70:	73 59                	jae    cfcb <f0+0x1bcb>
    cf72:	48 89 c2             	mov    %rax,%rdx
    cf75:	48 c1 ea 10          	shr    $0x10,%rdx
    cf79:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf7d:	48 8b 15 f4 7b 01 00 	mov    0x17bf4(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    cf84:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf88:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf8c:	4d 85 e4             	test   %r12,%r12
    cf8f:	74 3a                	je     cfcb <f0+0x1bcb>
    cf91:	0f b6 0a             	movzbl (%rdx),%ecx
    cf94:	80 f9 02             	cmp    $0x2,%cl
    cf97:	0f 84 33 0d 00 00    	je     dcd0 <f0+0x28d0>
    cf9d:	80 f9 01             	cmp    $0x1,%cl
    cfa0:	75 29                	jne    cfcb <f0+0x1bcb>
    cfa2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfa5:	0f b7 c0             	movzwl %ax,%eax
    cfa8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfab:	48 0f af c1          	imul   %rcx,%rax
    cfaf:	48 c1 e8 20          	shr    $0x20,%rax
    cfb3:	48 39 d0             	cmp    %rdx,%rax
    cfb6:	73 13                	jae    cfcb <f0+0x1bcb>
    cfb8:	49 01 c4             	add    %rax,%r12
    cfbb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfc0:	0f 84 2f 10 00 00    	je     dff5 <f0+0x2bf5>
    cfc6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfcb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfd2:	00 f0 3f 
    cfd5:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cfdc:	00 
    cfdd:	bf 01 00 00 00       	mov    $0x1,%edi
    cfe2:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cfe9:	00 
    cfea:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cff1:	00 
    cff2:	e8 f9 94 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    cff7:	48 8b 15 5a 7b 01 00 	mov    0x17b5a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    cffe:	49 89 c5             	mov    %rax,%r13
    d001:	48 2b 05 28 7b 01 00 	sub    0x17b28(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d008:	48 c1 e2 10          	shl    $0x10,%rdx
    d00c:	48 39 d0             	cmp    %rdx,%rax
    d00f:	73 59                	jae    d06a <f0+0x1c6a>
    d011:	48 89 c2             	mov    %rax,%rdx
    d014:	48 c1 ea 10          	shr    $0x10,%rdx
    d018:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d01c:	48 8b 15 55 7b 01 00 	mov    0x17b55(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d023:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d027:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d02b:	4d 85 e4             	test   %r12,%r12
    d02e:	74 3a                	je     d06a <f0+0x1c6a>
    d030:	0f b6 0a             	movzbl (%rdx),%ecx
    d033:	80 f9 02             	cmp    $0x2,%cl
    d036:	0f 84 84 0c 00 00    	je     dcc0 <f0+0x28c0>
    d03c:	80 f9 01             	cmp    $0x1,%cl
    d03f:	75 29                	jne    d06a <f0+0x1c6a>
    d041:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d044:	0f b7 c0             	movzwl %ax,%eax
    d047:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d04a:	48 0f af c1          	imul   %rcx,%rax
    d04e:	48 c1 e8 20          	shr    $0x20,%rax
    d052:	48 39 d0             	cmp    %rdx,%rax
    d055:	73 13                	jae    d06a <f0+0x1c6a>
    d057:	49 01 c4             	add    %rax,%r12
    d05a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d05f:	0f 84 9d 0f 00 00    	je     e002 <f0+0x2c02>
    d065:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d06a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d071:	33 f3 bf 
    d074:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d07b:	00 
    d07c:	bf 01 00 00 00       	mov    $0x1,%edi
    d081:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d088:	00 
    d089:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d090:	00 
    d091:	e8 5a 94 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d096:	48 8b 15 bb 7a 01 00 	mov    0x17abb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d09d:	49 89 c5             	mov    %rax,%r13
    d0a0:	48 2b 05 89 7a 01 00 	sub    0x17a89(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d0a7:	48 c1 e2 10          	shl    $0x10,%rdx
    d0ab:	48 39 d0             	cmp    %rdx,%rax
    d0ae:	73 59                	jae    d109 <f0+0x1d09>
    d0b0:	48 89 c2             	mov    %rax,%rdx
    d0b3:	48 c1 ea 10          	shr    $0x10,%rdx
    d0b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0bb:	48 8b 15 b6 7a 01 00 	mov    0x17ab6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d0c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0c6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0ca:	4d 85 e4             	test   %r12,%r12
    d0cd:	74 3a                	je     d109 <f0+0x1d09>
    d0cf:	0f b6 0a             	movzbl (%rdx),%ecx
    d0d2:	80 f9 02             	cmp    $0x2,%cl
    d0d5:	0f 84 d5 0b 00 00    	je     dcb0 <f0+0x28b0>
    d0db:	80 f9 01             	cmp    $0x1,%cl
    d0de:	75 29                	jne    d109 <f0+0x1d09>
    d0e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0e3:	0f b7 c0             	movzwl %ax,%eax
    d0e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0e9:	48 0f af c1          	imul   %rcx,%rax
    d0ed:	48 c1 e8 20          	shr    $0x20,%rax
    d0f1:	48 39 d0             	cmp    %rdx,%rax
    d0f4:	73 13                	jae    d109 <f0+0x1d09>
    d0f6:	49 01 c4             	add    %rax,%r12
    d0f9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0fe:	0f 84 0b 0f 00 00    	je     e00f <f0+0x2c0f>
    d104:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d109:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d110:	00 f0 3f 
    d113:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d11a:	00 
    d11b:	bf 01 00 00 00       	mov    $0x1,%edi
    d120:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d127:	00 
    d128:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d12f:	00 
    d130:	e8 bb 93 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d135:	48 8b 15 1c 7a 01 00 	mov    0x17a1c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d13c:	49 89 c5             	mov    %rax,%r13
    d13f:	48 2b 05 ea 79 01 00 	sub    0x179ea(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d146:	48 c1 e2 10          	shl    $0x10,%rdx
    d14a:	48 39 d0             	cmp    %rdx,%rax
    d14d:	73 59                	jae    d1a8 <f0+0x1da8>
    d14f:	48 89 c2             	mov    %rax,%rdx
    d152:	48 c1 ea 10          	shr    $0x10,%rdx
    d156:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d15a:	48 8b 15 17 7a 01 00 	mov    0x17a17(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d161:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d165:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d169:	4d 85 e4             	test   %r12,%r12
    d16c:	74 3a                	je     d1a8 <f0+0x1da8>
    d16e:	0f b6 0a             	movzbl (%rdx),%ecx
    d171:	80 f9 02             	cmp    $0x2,%cl
    d174:	0f 84 26 0b 00 00    	je     dca0 <f0+0x28a0>
    d17a:	80 f9 01             	cmp    $0x1,%cl
    d17d:	75 29                	jne    d1a8 <f0+0x1da8>
    d17f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d182:	0f b7 c0             	movzwl %ax,%eax
    d185:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d188:	48 0f af c1          	imul   %rcx,%rax
    d18c:	48 c1 e8 20          	shr    $0x20,%rax
    d190:	48 39 d0             	cmp    %rdx,%rax
    d193:	73 13                	jae    d1a8 <f0+0x1da8>
    d195:	49 01 c4             	add    %rax,%r12
    d198:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d19d:	0f 84 79 0e 00 00    	je     e01c <f0+0x2c1c>
    d1a3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1a8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1af:	33 f3 bf 
    d1b2:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d1b9:	00 
    d1ba:	bf 01 00 00 00       	mov    $0x1,%edi
    d1bf:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d1c6:	00 
    d1c7:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d1ce:	00 
    d1cf:	e8 1c 93 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d1d4:	48 8b 15 7d 79 01 00 	mov    0x1797d(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d1db:	49 89 c5             	mov    %rax,%r13
    d1de:	48 2b 05 4b 79 01 00 	sub    0x1794b(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d1e5:	48 c1 e2 10          	shl    $0x10,%rdx
    d1e9:	48 39 d0             	cmp    %rdx,%rax
    d1ec:	73 59                	jae    d247 <f0+0x1e47>
    d1ee:	48 89 c2             	mov    %rax,%rdx
    d1f1:	48 c1 ea 10          	shr    $0x10,%rdx
    d1f5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1f9:	48 8b 15 78 79 01 00 	mov    0x17978(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d200:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d204:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d208:	4d 85 e4             	test   %r12,%r12
    d20b:	74 3a                	je     d247 <f0+0x1e47>
    d20d:	0f b6 0a             	movzbl (%rdx),%ecx
    d210:	80 f9 02             	cmp    $0x2,%cl
    d213:	0f 84 77 0a 00 00    	je     dc90 <f0+0x2890>
    d219:	80 f9 01             	cmp    $0x1,%cl
    d21c:	75 29                	jne    d247 <f0+0x1e47>
    d21e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d221:	0f b7 c0             	movzwl %ax,%eax
    d224:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d227:	48 0f af c1          	imul   %rcx,%rax
    d22b:	48 c1 e8 20          	shr    $0x20,%rax
    d22f:	48 39 d0             	cmp    %rdx,%rax
    d232:	73 13                	jae    d247 <f0+0x1e47>
    d234:	49 01 c4             	add    %rax,%r12
    d237:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d23c:	0f 84 e7 0d 00 00    	je     e029 <f0+0x2c29>
    d242:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d247:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d24e:	00 f0 3f 
    d251:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d258:	00 
    d259:	bf 01 00 00 00       	mov    $0x1,%edi
    d25e:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d265:	00 
    d266:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d26d:	00 
    d26e:	e8 7d 92 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d273:	48 8b 15 de 78 01 00 	mov    0x178de(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d27a:	49 89 c5             	mov    %rax,%r13
    d27d:	48 2b 05 ac 78 01 00 	sub    0x178ac(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d284:	48 c1 e2 10          	shl    $0x10,%rdx
    d288:	48 39 d0             	cmp    %rdx,%rax
    d28b:	73 59                	jae    d2e6 <f0+0x1ee6>
    d28d:	48 89 c2             	mov    %rax,%rdx
    d290:	48 c1 ea 10          	shr    $0x10,%rdx
    d294:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d298:	48 8b 15 d9 78 01 00 	mov    0x178d9(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d29f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2a3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2a7:	4d 85 e4             	test   %r12,%r12
    d2aa:	74 3a                	je     d2e6 <f0+0x1ee6>
    d2ac:	0f b6 0a             	movzbl (%rdx),%ecx
    d2af:	80 f9 02             	cmp    $0x2,%cl
    d2b2:	0f 84 38 0c 00 00    	je     def0 <f0+0x2af0>
    d2b8:	80 f9 01             	cmp    $0x1,%cl
    d2bb:	75 29                	jne    d2e6 <f0+0x1ee6>
    d2bd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2c0:	0f b7 c0             	movzwl %ax,%eax
    d2c3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2c6:	48 0f af c1          	imul   %rcx,%rax
    d2ca:	48 c1 e8 20          	shr    $0x20,%rax
    d2ce:	48 39 d0             	cmp    %rdx,%rax
    d2d1:	73 13                	jae    d2e6 <f0+0x1ee6>
    d2d3:	49 01 c4             	add    %rax,%r12
    d2d6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2db:	0f 84 55 0d 00 00    	je     e036 <f0+0x2c36>
    d2e1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2e6:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2ed:	33 f3 bf 
    d2f0:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d2f7:	00 
    d2f8:	bf 01 00 00 00       	mov    $0x1,%edi
    d2fd:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d304:	00 
    d305:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d30c:	00 
    d30d:	e8 de 91 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d312:	48 8b 15 3f 78 01 00 	mov    0x1783f(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d319:	49 89 c5             	mov    %rax,%r13
    d31c:	48 2b 05 0d 78 01 00 	sub    0x1780d(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d323:	48 c1 e2 10          	shl    $0x10,%rdx
    d327:	48 39 d0             	cmp    %rdx,%rax
    d32a:	73 59                	jae    d385 <f0+0x1f85>
    d32c:	48 89 c2             	mov    %rax,%rdx
    d32f:	48 c1 ea 10          	shr    $0x10,%rdx
    d333:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d337:	48 8b 15 3a 78 01 00 	mov    0x1783a(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d33e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d342:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d346:	4d 85 e4             	test   %r12,%r12
    d349:	74 3a                	je     d385 <f0+0x1f85>
    d34b:	0f b6 0a             	movzbl (%rdx),%ecx
    d34e:	80 f9 02             	cmp    $0x2,%cl
    d351:	0f 84 89 0b 00 00    	je     dee0 <f0+0x2ae0>
    d357:	80 f9 01             	cmp    $0x1,%cl
    d35a:	75 29                	jne    d385 <f0+0x1f85>
    d35c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d35f:	0f b7 c0             	movzwl %ax,%eax
    d362:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d365:	48 0f af c1          	imul   %rcx,%rax
    d369:	48 c1 e8 20          	shr    $0x20,%rax
    d36d:	48 39 d0             	cmp    %rdx,%rax
    d370:	73 13                	jae    d385 <f0+0x1f85>
    d372:	49 01 c4             	add    %rax,%r12
    d375:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d37a:	0f 84 c3 0c 00 00    	je     e043 <f0+0x2c43>
    d380:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d385:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d38c:	00 f0 3f 
    d38f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d396:	00 
    d397:	bf 01 00 00 00       	mov    $0x1,%edi
    d39c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d3a3:	00 
    d3a4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d3ab:	00 
    d3ac:	e8 3f 91 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d3b1:	48 8b 15 a0 77 01 00 	mov    0x177a0(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d3b8:	49 89 c5             	mov    %rax,%r13
    d3bb:	48 2b 05 6e 77 01 00 	sub    0x1776e(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d3c2:	48 c1 e2 10          	shl    $0x10,%rdx
    d3c6:	48 39 d0             	cmp    %rdx,%rax
    d3c9:	73 59                	jae    d424 <f0+0x2024>
    d3cb:	48 89 c2             	mov    %rax,%rdx
    d3ce:	48 c1 ea 10          	shr    $0x10,%rdx
    d3d2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3d6:	48 8b 15 9b 77 01 00 	mov    0x1779b(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d3dd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3e1:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3e5:	4d 85 e4             	test   %r12,%r12
    d3e8:	74 3a                	je     d424 <f0+0x2024>
    d3ea:	0f b6 0a             	movzbl (%rdx),%ecx
    d3ed:	80 f9 02             	cmp    $0x2,%cl
    d3f0:	0f 84 da 0a 00 00    	je     ded0 <f0+0x2ad0>
    d3f6:	80 f9 01             	cmp    $0x1,%cl
    d3f9:	75 29                	jne    d424 <f0+0x2024>
    d3fb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3fe:	0f b7 c0             	movzwl %ax,%eax
    d401:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d404:	48 0f af c1          	imul   %rcx,%rax
    d408:	48 c1 e8 20          	shr    $0x20,%rax
    d40c:	48 39 d0             	cmp    %rdx,%rax
    d40f:	73 13                	jae    d424 <f0+0x2024>
    d411:	49 01 c4             	add    %rax,%r12
    d414:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d419:	0f 84 31 0c 00 00    	je     e050 <f0+0x2c50>
    d41f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d424:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d42b:	33 f3 bf 
    d42e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d435:	00 
    d436:	bf 01 00 00 00       	mov    $0x1,%edi
    d43b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d442:	00 
    d443:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d44a:	00 
    d44b:	e8 a0 90 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d450:	48 8b 15 01 77 01 00 	mov    0x17701(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d457:	49 89 c5             	mov    %rax,%r13
    d45a:	48 2b 05 cf 76 01 00 	sub    0x176cf(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d461:	48 c1 e2 10          	shl    $0x10,%rdx
    d465:	48 39 d0             	cmp    %rdx,%rax
    d468:	73 59                	jae    d4c3 <f0+0x20c3>
    d46a:	48 89 c2             	mov    %rax,%rdx
    d46d:	48 c1 ea 10          	shr    $0x10,%rdx
    d471:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d475:	48 8b 15 fc 76 01 00 	mov    0x176fc(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d47c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d480:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d484:	4d 85 e4             	test   %r12,%r12
    d487:	74 3a                	je     d4c3 <f0+0x20c3>
    d489:	0f b6 0a             	movzbl (%rdx),%ecx
    d48c:	80 f9 02             	cmp    $0x2,%cl
    d48f:	0f 84 2b 0a 00 00    	je     dec0 <f0+0x2ac0>
    d495:	80 f9 01             	cmp    $0x1,%cl
    d498:	75 29                	jne    d4c3 <f0+0x20c3>
    d49a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d49d:	0f b7 c0             	movzwl %ax,%eax
    d4a0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4a3:	48 0f af c1          	imul   %rcx,%rax
    d4a7:	48 c1 e8 20          	shr    $0x20,%rax
    d4ab:	48 39 d0             	cmp    %rdx,%rax
    d4ae:	73 13                	jae    d4c3 <f0+0x20c3>
    d4b0:	49 01 c4             	add    %rax,%r12
    d4b3:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4b8:	0f 84 9f 0b 00 00    	je     e05d <f0+0x2c5d>
    d4be:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4c3:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4ca:	00 f0 3f 
    d4cd:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d4d4:	00 
    d4d5:	bf 01 00 00 00       	mov    $0x1,%edi
    d4da:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d4e1:	00 
    d4e2:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d4e9:	00 
    d4ea:	e8 01 90 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d4ef:	48 8b 15 62 76 01 00 	mov    0x17662(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d4f6:	49 89 c5             	mov    %rax,%r13
    d4f9:	48 2b 05 30 76 01 00 	sub    0x17630(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d500:	48 c1 e2 10          	shl    $0x10,%rdx
    d504:	48 39 d0             	cmp    %rdx,%rax
    d507:	73 59                	jae    d562 <f0+0x2162>
    d509:	48 89 c2             	mov    %rax,%rdx
    d50c:	48 c1 ea 10          	shr    $0x10,%rdx
    d510:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d514:	48 8b 15 5d 76 01 00 	mov    0x1765d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d51b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d51f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d523:	4d 85 e4             	test   %r12,%r12
    d526:	74 3a                	je     d562 <f0+0x2162>
    d528:	0f b6 0a             	movzbl (%rdx),%ecx
    d52b:	80 f9 02             	cmp    $0x2,%cl
    d52e:	0f 84 7c 09 00 00    	je     deb0 <f0+0x2ab0>
    d534:	80 f9 01             	cmp    $0x1,%cl
    d537:	75 29                	jne    d562 <f0+0x2162>
    d539:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d53c:	0f b7 c0             	movzwl %ax,%eax
    d53f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d542:	48 0f af c1          	imul   %rcx,%rax
    d546:	48 c1 e8 20          	shr    $0x20,%rax
    d54a:	48 39 d0             	cmp    %rdx,%rax
    d54d:	73 13                	jae    d562 <f0+0x2162>
    d54f:	49 01 c4             	add    %rax,%r12
    d552:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d557:	0f 84 0d 0b 00 00    	je     e06a <f0+0x2c6a>
    d55d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d562:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d569:	33 f3 bf 
    d56c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d573:	00 
    d574:	bf 01 00 00 00       	mov    $0x1,%edi
    d579:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d580:	00 
    d581:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d588:	00 
    d589:	e8 62 8f ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d58e:	48 8b 15 c3 75 01 00 	mov    0x175c3(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d595:	49 89 c5             	mov    %rax,%r13
    d598:	48 2b 05 91 75 01 00 	sub    0x17591(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d59f:	48 c1 e2 10          	shl    $0x10,%rdx
    d5a3:	48 39 d0             	cmp    %rdx,%rax
    d5a6:	73 59                	jae    d601 <f0+0x2201>
    d5a8:	48 89 c2             	mov    %rax,%rdx
    d5ab:	48 c1 ea 10          	shr    $0x10,%rdx
    d5af:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5b3:	48 8b 15 be 75 01 00 	mov    0x175be(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d5ba:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5be:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5c2:	4d 85 e4             	test   %r12,%r12
    d5c5:	74 3a                	je     d601 <f0+0x2201>
    d5c7:	0f b6 0a             	movzbl (%rdx),%ecx
    d5ca:	80 f9 02             	cmp    $0x2,%cl
    d5cd:	0f 84 cd 08 00 00    	je     dea0 <f0+0x2aa0>
    d5d3:	80 f9 01             	cmp    $0x1,%cl
    d5d6:	75 29                	jne    d601 <f0+0x2201>
    d5d8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5db:	0f b7 c0             	movzwl %ax,%eax
    d5de:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5e1:	48 0f af c1          	imul   %rcx,%rax
    d5e5:	48 c1 e8 20          	shr    $0x20,%rax
    d5e9:	48 39 d0             	cmp    %rdx,%rax
    d5ec:	73 13                	jae    d601 <f0+0x2201>
    d5ee:	49 01 c4             	add    %rax,%r12
    d5f1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5f6:	0f 84 7b 0a 00 00    	je     e077 <f0+0x2c77>
    d5fc:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d601:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d608:	00 f0 3f 
    d60b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d612:	00 
    d613:	bf 01 00 00 00       	mov    $0x1,%edi
    d618:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d61f:	00 
    d620:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d627:	00 
    d628:	e8 c3 8e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d62d:	48 8b 15 24 75 01 00 	mov    0x17524(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d634:	49 89 c5             	mov    %rax,%r13
    d637:	48 2b 05 f2 74 01 00 	sub    0x174f2(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d63e:	48 c1 e2 10          	shl    $0x10,%rdx
    d642:	48 39 d0             	cmp    %rdx,%rax
    d645:	73 59                	jae    d6a0 <f0+0x22a0>
    d647:	48 89 c2             	mov    %rax,%rdx
    d64a:	48 c1 ea 10          	shr    $0x10,%rdx
    d64e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d652:	48 8b 15 1f 75 01 00 	mov    0x1751f(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d659:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d65d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d661:	4d 85 e4             	test   %r12,%r12
    d664:	74 3a                	je     d6a0 <f0+0x22a0>
    d666:	0f b6 0a             	movzbl (%rdx),%ecx
    d669:	80 f9 02             	cmp    $0x2,%cl
    d66c:	0f 84 1e 08 00 00    	je     de90 <f0+0x2a90>
    d672:	80 f9 01             	cmp    $0x1,%cl
    d675:	75 29                	jne    d6a0 <f0+0x22a0>
    d677:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d67a:	0f b7 c0             	movzwl %ax,%eax
    d67d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d680:	48 0f af c1          	imul   %rcx,%rax
    d684:	48 c1 e8 20          	shr    $0x20,%rax
    d688:	48 39 d0             	cmp    %rdx,%rax
    d68b:	73 13                	jae    d6a0 <f0+0x22a0>
    d68d:	49 01 c4             	add    %rax,%r12
    d690:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d695:	0f 84 e9 09 00 00    	je     e084 <f0+0x2c84>
    d69b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6a0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6a7:	33 f3 bf 
    d6aa:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d6b1:	00 
    d6b2:	bf 01 00 00 00       	mov    $0x1,%edi
    d6b7:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d6be:	00 
    d6bf:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d6c6:	00 
    d6c7:	e8 24 8e ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d6cc:	48 8b 15 85 74 01 00 	mov    0x17485(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d6d3:	49 89 c5             	mov    %rax,%r13
    d6d6:	48 2b 05 53 74 01 00 	sub    0x17453(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d6dd:	48 c1 e2 10          	shl    $0x10,%rdx
    d6e1:	48 39 d0             	cmp    %rdx,%rax
    d6e4:	73 59                	jae    d73f <f0+0x233f>
    d6e6:	48 89 c2             	mov    %rax,%rdx
    d6e9:	48 c1 ea 10          	shr    $0x10,%rdx
    d6ed:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6f1:	48 8b 15 80 74 01 00 	mov    0x17480(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d6f8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6fc:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d700:	4d 85 e4             	test   %r12,%r12
    d703:	74 3a                	je     d73f <f0+0x233f>
    d705:	0f b6 0a             	movzbl (%rdx),%ecx
    d708:	80 f9 02             	cmp    $0x2,%cl
    d70b:	0f 84 6f 07 00 00    	je     de80 <f0+0x2a80>
    d711:	80 f9 01             	cmp    $0x1,%cl
    d714:	75 29                	jne    d73f <f0+0x233f>
    d716:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d719:	0f b7 c0             	movzwl %ax,%eax
    d71c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d71f:	48 0f af c1          	imul   %rcx,%rax
    d723:	48 c1 e8 20          	shr    $0x20,%rax
    d727:	48 39 d0             	cmp    %rdx,%rax
    d72a:	73 13                	jae    d73f <f0+0x233f>
    d72c:	49 01 c4             	add    %rax,%r12
    d72f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d734:	0f 84 57 09 00 00    	je     e091 <f0+0x2c91>
    d73a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d73f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d746:	00 f0 3f 
    d749:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d750:	00 
    d751:	bf 01 00 00 00       	mov    $0x1,%edi
    d756:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d75d:	00 
    d75e:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d765:	00 
    d766:	e8 85 8d ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d76b:	48 8b 15 e6 73 01 00 	mov    0x173e6(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d772:	49 89 c5             	mov    %rax,%r13
    d775:	48 2b 05 b4 73 01 00 	sub    0x173b4(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d77c:	48 c1 e2 10          	shl    $0x10,%rdx
    d780:	48 39 d0             	cmp    %rdx,%rax
    d783:	73 59                	jae    d7de <f0+0x23de>
    d785:	48 89 c2             	mov    %rax,%rdx
    d788:	48 c1 ea 10          	shr    $0x10,%rdx
    d78c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d790:	48 8b 15 e1 73 01 00 	mov    0x173e1(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d797:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d79b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d79f:	4d 85 e4             	test   %r12,%r12
    d7a2:	74 3a                	je     d7de <f0+0x23de>
    d7a4:	0f b6 0a             	movzbl (%rdx),%ecx
    d7a7:	80 f9 02             	cmp    $0x2,%cl
    d7aa:	0f 84 c0 06 00 00    	je     de70 <f0+0x2a70>
    d7b0:	80 f9 01             	cmp    $0x1,%cl
    d7b3:	75 29                	jne    d7de <f0+0x23de>
    d7b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7b8:	0f b7 c0             	movzwl %ax,%eax
    d7bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7be:	48 0f af c1          	imul   %rcx,%rax
    d7c2:	48 c1 e8 20          	shr    $0x20,%rax
    d7c6:	48 39 d0             	cmp    %rdx,%rax
    d7c9:	73 13                	jae    d7de <f0+0x23de>
    d7cb:	49 01 c4             	add    %rax,%r12
    d7ce:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7d3:	0f 84 c5 08 00 00    	je     e09e <f0+0x2c9e>
    d7d9:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7de:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7e5:	33 f3 bf 
    d7e8:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d7ef:	00 
    d7f0:	bf 01 00 00 00       	mov    $0x1,%edi
    d7f5:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d7fc:	00 
    d7fd:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d804:	00 
    d805:	e8 e6 8c ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d80a:	48 8b 15 47 73 01 00 	mov    0x17347(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d811:	49 89 c5             	mov    %rax,%r13
    d814:	48 2b 05 15 73 01 00 	sub    0x17315(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d81b:	48 c1 e2 10          	shl    $0x10,%rdx
    d81f:	48 39 d0             	cmp    %rdx,%rax
    d822:	73 59                	jae    d87d <f0+0x247d>
    d824:	48 89 c2             	mov    %rax,%rdx
    d827:	48 c1 ea 10          	shr    $0x10,%rdx
    d82b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d82f:	48 8b 15 42 73 01 00 	mov    0x17342(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d836:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d83a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d83e:	4d 85 e4             	test   %r12,%r12
    d841:	74 3a                	je     d87d <f0+0x247d>
    d843:	0f b6 0a             	movzbl (%rdx),%ecx
    d846:	80 f9 02             	cmp    $0x2,%cl
    d849:	0f 84 11 06 00 00    	je     de60 <f0+0x2a60>
    d84f:	80 f9 01             	cmp    $0x1,%cl
    d852:	75 29                	jne    d87d <f0+0x247d>
    d854:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d857:	0f b7 c0             	movzwl %ax,%eax
    d85a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d85d:	48 0f af c1          	imul   %rcx,%rax
    d861:	48 c1 e8 20          	shr    $0x20,%rax
    d865:	48 39 d0             	cmp    %rdx,%rax
    d868:	73 13                	jae    d87d <f0+0x247d>
    d86a:	49 01 c4             	add    %rax,%r12
    d86d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d872:	0f 84 33 08 00 00    	je     e0ab <f0+0x2cab>
    d878:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d87d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d884:	00 f0 3f 
    d887:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d88e:	00 
    d88f:	bf 01 00 00 00       	mov    $0x1,%edi
    d894:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d89b:	00 
    d89c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d8a3:	00 
    d8a4:	e8 47 8c ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d8a9:	48 8b 15 a8 72 01 00 	mov    0x172a8(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d8b0:	49 89 c5             	mov    %rax,%r13
    d8b3:	48 2b 05 76 72 01 00 	sub    0x17276(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d8ba:	48 c1 e2 10          	shl    $0x10,%rdx
    d8be:	48 39 d0             	cmp    %rdx,%rax
    d8c1:	73 59                	jae    d91c <f0+0x251c>
    d8c3:	48 89 c2             	mov    %rax,%rdx
    d8c6:	48 c1 ea 10          	shr    $0x10,%rdx
    d8ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d8ce:	48 8b 15 a3 72 01 00 	mov    0x172a3(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d8d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d8d9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8dd:	4d 85 e4             	test   %r12,%r12
    d8e0:	74 3a                	je     d91c <f0+0x251c>
    d8e2:	0f b6 0a             	movzbl (%rdx),%ecx
    d8e5:	80 f9 02             	cmp    $0x2,%cl
    d8e8:	0f 84 62 05 00 00    	je     de50 <f0+0x2a50>
    d8ee:	80 f9 01             	cmp    $0x1,%cl
    d8f1:	75 29                	jne    d91c <f0+0x251c>
    d8f3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8f6:	0f b7 c0             	movzwl %ax,%eax
    d8f9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8fc:	48 0f af c1          	imul   %rcx,%rax
    d900:	48 c1 e8 20          	shr    $0x20,%rax
    d904:	48 39 d0             	cmp    %rdx,%rax
    d907:	73 13                	jae    d91c <f0+0x251c>
    d909:	49 01 c4             	add    %rax,%r12
    d90c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d911:	0f 84 a1 07 00 00    	je     e0b8 <f0+0x2cb8>
    d917:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d91c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d923:	33 f3 bf 
    d926:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d92d:	00 
    d92e:	bf 01 00 00 00       	mov    $0x1,%edi
    d933:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d93a:	00 
    d93b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d942:	00 
    d943:	e8 a8 8b ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d948:	48 8b 15 09 72 01 00 	mov    0x17209(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d94f:	49 89 c5             	mov    %rax,%r13
    d952:	48 2b 05 d7 71 01 00 	sub    0x171d7(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d959:	48 c1 e2 10          	shl    $0x10,%rdx
    d95d:	48 39 d0             	cmp    %rdx,%rax
    d960:	73 59                	jae    d9bb <f0+0x25bb>
    d962:	48 89 c2             	mov    %rax,%rdx
    d965:	48 c1 ea 10          	shr    $0x10,%rdx
    d969:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d96d:	48 8b 15 04 72 01 00 	mov    0x17204(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    d974:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d978:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d97c:	4d 85 e4             	test   %r12,%r12
    d97f:	74 3a                	je     d9bb <f0+0x25bb>
    d981:	0f b6 0a             	movzbl (%rdx),%ecx
    d984:	80 f9 02             	cmp    $0x2,%cl
    d987:	0f 84 b3 04 00 00    	je     de40 <f0+0x2a40>
    d98d:	80 f9 01             	cmp    $0x1,%cl
    d990:	75 29                	jne    d9bb <f0+0x25bb>
    d992:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d995:	0f b7 c0             	movzwl %ax,%eax
    d998:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d99b:	48 0f af c1          	imul   %rcx,%rax
    d99f:	48 c1 e8 20          	shr    $0x20,%rax
    d9a3:	48 39 d0             	cmp    %rdx,%rax
    d9a6:	73 13                	jae    d9bb <f0+0x25bb>
    d9a8:	49 01 c4             	add    %rax,%r12
    d9ab:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d9b0:	0f 84 0f 07 00 00    	je     e0c5 <f0+0x2cc5>
    d9b6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d9bb:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d9c2:	00 f0 3f 
    d9c5:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d9cc:	00 
    d9cd:	bf 01 00 00 00       	mov    $0x1,%edi
    d9d2:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d9d9:	00 
    d9da:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d9e1:	00 
    d9e2:	e8 09 8b ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    d9e7:	48 8b 15 6a 71 01 00 	mov    0x1716a(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    d9ee:	49 89 c5             	mov    %rax,%r13
    d9f1:	48 2b 05 38 71 01 00 	sub    0x17138(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    d9f8:	48 c1 e2 10          	shl    $0x10,%rdx
    d9fc:	48 39 d0             	cmp    %rdx,%rax
    d9ff:	73 59                	jae    da5a <f0+0x265a>
    da01:	48 89 c2             	mov    %rax,%rdx
    da04:	48 c1 ea 10          	shr    $0x10,%rdx
    da08:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da0c:	48 8b 15 65 71 01 00 	mov    0x17165(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    da13:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da17:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da1b:	4d 85 e4             	test   %r12,%r12
    da1e:	74 3a                	je     da5a <f0+0x265a>
    da20:	0f b6 0a             	movzbl (%rdx),%ecx
    da23:	80 f9 02             	cmp    $0x2,%cl
    da26:	0f 84 04 04 00 00    	je     de30 <f0+0x2a30>
    da2c:	80 f9 01             	cmp    $0x1,%cl
    da2f:	75 29                	jne    da5a <f0+0x265a>
    da31:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da34:	0f b7 c0             	movzwl %ax,%eax
    da37:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da3a:	48 0f af c1          	imul   %rcx,%rax
    da3e:	48 c1 e8 20          	shr    $0x20,%rax
    da42:	48 39 d0             	cmp    %rdx,%rax
    da45:	73 13                	jae    da5a <f0+0x265a>
    da47:	49 01 c4             	add    %rax,%r12
    da4a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da4f:	0f 84 7d 06 00 00    	je     e0d2 <f0+0x2cd2>
    da55:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da5a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    da61:	33 f3 bf 
    da64:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    da6b:	00 
    da6c:	bf 01 00 00 00       	mov    $0x1,%edi
    da71:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    da78:	00 
    da79:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    da80:	00 
    da81:	e8 6a 8a ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    da86:	48 8b 15 cb 70 01 00 	mov    0x170cb(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    da8d:	49 89 c5             	mov    %rax,%r13
    da90:	48 2b 05 99 70 01 00 	sub    0x17099(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    da97:	48 c1 e2 10          	shl    $0x10,%rdx
    da9b:	48 39 d0             	cmp    %rdx,%rax
    da9e:	73 59                	jae    daf9 <f0+0x26f9>
    daa0:	48 89 c2             	mov    %rax,%rdx
    daa3:	48 c1 ea 10          	shr    $0x10,%rdx
    daa7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    daab:	48 8b 15 c6 70 01 00 	mov    0x170c6(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    dab2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dab6:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    daba:	4d 85 e4             	test   %r12,%r12
    dabd:	74 3a                	je     daf9 <f0+0x26f9>
    dabf:	0f b6 0a             	movzbl (%rdx),%ecx
    dac2:	80 f9 02             	cmp    $0x2,%cl
    dac5:	0f 84 55 03 00 00    	je     de20 <f0+0x2a20>
    dacb:	80 f9 01             	cmp    $0x1,%cl
    dace:	75 29                	jne    daf9 <f0+0x26f9>
    dad0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dad3:	0f b7 c0             	movzwl %ax,%eax
    dad6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dad9:	48 0f af c1          	imul   %rcx,%rax
    dadd:	48 c1 e8 20          	shr    $0x20,%rax
    dae1:	48 39 d0             	cmp    %rdx,%rax
    dae4:	73 13                	jae    daf9 <f0+0x26f9>
    dae6:	49 01 c4             	add    %rax,%r12
    dae9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    daee:	0f 84 eb 05 00 00    	je     e0df <f0+0x2cdf>
    daf4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    daf9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db00:	00 f0 3f 
    db03:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    db0a:	00 
    db0b:	bf 01 00 00 00       	mov    $0x1,%edi
    db10:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    db17:	00 
    db18:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    db1f:	00 
    db20:	e8 cb 89 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    db25:	48 8b 15 2c 70 01 00 	mov    0x1702c(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    db2c:	49 89 c5             	mov    %rax,%r13
    db2f:	48 2b 05 fa 6f 01 00 	sub    0x16ffa(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    db36:	48 c1 e2 10          	shl    $0x10,%rdx
    db3a:	48 39 d0             	cmp    %rdx,%rax
    db3d:	73 59                	jae    db98 <f0+0x2798>
    db3f:	48 89 c2             	mov    %rax,%rdx
    db42:	48 c1 ea 10          	shr    $0x10,%rdx
    db46:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db4a:	48 8b 15 27 70 01 00 	mov    0x17027(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    db51:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db55:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db59:	4d 85 e4             	test   %r12,%r12
    db5c:	74 3a                	je     db98 <f0+0x2798>
    db5e:	0f b6 0a             	movzbl (%rdx),%ecx
    db61:	80 f9 02             	cmp    $0x2,%cl
    db64:	0f 84 a6 02 00 00    	je     de10 <f0+0x2a10>
    db6a:	80 f9 01             	cmp    $0x1,%cl
    db6d:	75 29                	jne    db98 <f0+0x2798>
    db6f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db72:	0f b7 c0             	movzwl %ax,%eax
    db75:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db78:	48 0f af c1          	imul   %rcx,%rax
    db7c:	48 c1 e8 20          	shr    $0x20,%rax
    db80:	48 39 d0             	cmp    %rdx,%rax
    db83:	73 13                	jae    db98 <f0+0x2798>
    db85:	49 01 c4             	add    %rax,%r12
    db88:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db8d:	0f 84 59 05 00 00    	je     e0ec <f0+0x2cec>
    db93:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db98:	48 89 ee             	mov    %rbp,%rsi
    db9b:	bf 01 00 00 00       	mov    $0x1,%edi
    dba0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dba7:	33 f3 bf 
    dbaa:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dbb1:	00 
    dbb2:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dbb9:	00 
    dbba:	e8 31 89 ff ff       	call   64f0 <fwp_data.part.0.constprop.0>
    dbbf:	48 8b 15 92 6f 01 00 	mov    0x16f92(%rip),%rdx        # 24b58 <fwp_heap+0x13d8>
    dbc6:	48 89 c5             	mov    %rax,%rbp
    dbc9:	48 2b 05 60 6f 01 00 	sub    0x16f60(%rip),%rax        # 24b30 <fwp_heap+0x13b0>
    dbd0:	48 c1 e2 10          	shl    $0x10,%rdx
    dbd4:	48 39 d0             	cmp    %rdx,%rax
    dbd7:	73 59                	jae    dc32 <f0+0x2832>
    dbd9:	48 89 c2             	mov    %rax,%rdx
    dbdc:	48 c1 ea 10          	shr    $0x10,%rdx
    dbe0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbe4:	48 8b 15 8d 6f 01 00 	mov    0x16f8d(%rip),%rdx        # 24b78 <fwp_heap+0x13f8>
    dbeb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbef:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbf3:	4d 85 e4             	test   %r12,%r12
    dbf6:	74 3a                	je     dc32 <f0+0x2832>
    dbf8:	0f b6 0a             	movzbl (%rdx),%ecx
    dbfb:	80 f9 02             	cmp    $0x2,%cl
    dbfe:	0f 84 fc 01 00 00    	je     de00 <f0+0x2a00>
    dc04:	80 f9 01             	cmp    $0x1,%cl
    dc07:	75 29                	jne    dc32 <f0+0x2832>
    dc09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc0c:	0f b7 c0             	movzwl %ax,%eax
    dc0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc12:	48 0f af c1          	imul   %rcx,%rax
    dc16:	48 c1 e8 20          	shr    $0x20,%rax
    dc1a:	48 39 d0             	cmp    %rdx,%rax
    dc1d:	73 13                	jae    dc32 <f0+0x2832>
    dc1f:	49 01 c4             	add    %rax,%r12
    dc22:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc27:	0f 84 d1 02 00 00    	je     defe <f0+0x2afe>
    dc2d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc32:	48 89 de             	mov    %rbx,%rsi
    dc35:	48 89 ef             	mov    %rbp,%rdi
    dc38:	e8 63 cb ff ff       	call   a7a0 <fwp_hof0.constprop.0>
    dc3d:	48 89 ef             	mov    %rbp,%rdi
    dc40:	e8 1b 8e ff ff       	call   6a60 <fwp_drop0>
    dc45:	48 89 df             	mov    %rbx,%rdi
    dc48:	e8 13 8e ff ff       	call   6a60 <fwp_drop0>
    dc4d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    dc54:	00 
    dc55:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    dc5c:	00 00 
    dc5e:	0f 85 95 04 00 00    	jne    e0f9 <f0+0x2cf9>
    dc64:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    dc6b:	31 c0                	xor    %eax,%eax
    dc6d:	5b                   	pop    %rbx
    dc6e:	5d                   	pop    %rbp
    dc6f:	41 5c                	pop    %r12
    dc71:	41 5d                	pop    %r13
    dc73:	41 5e                	pop    %r14
    dc75:	c3                   	ret
    dc76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    dc7d:	00 00 00 
    dc80:	4c 89 ef             	mov    %r13,%rdi
    dc83:	e8 88 76 ff ff       	call   5310 <fwp_rc_forget_slot>
    dc88:	e9 2c d8 ff ff       	jmp    b4b9 <f0+0xb9>
    dc8d:	0f 1f 00             	nopl   (%rax)
    dc90:	66 85 c0             	test   %ax,%ax
    dc93:	0f 85 ae f5 ff ff    	jne    d247 <f0+0x1e47>
    dc99:	e9 99 f5 ff ff       	jmp    d237 <f0+0x1e37>
    dc9e:	66 90                	xchg   %ax,%ax
    dca0:	66 85 c0             	test   %ax,%ax
    dca3:	0f 85 ff f4 ff ff    	jne    d1a8 <f0+0x1da8>
    dca9:	e9 ea f4 ff ff       	jmp    d198 <f0+0x1d98>
    dcae:	66 90                	xchg   %ax,%ax
    dcb0:	66 85 c0             	test   %ax,%ax
    dcb3:	0f 85 50 f4 ff ff    	jne    d109 <f0+0x1d09>
    dcb9:	e9 3b f4 ff ff       	jmp    d0f9 <f0+0x1cf9>
    dcbe:	66 90                	xchg   %ax,%ax
    dcc0:	66 85 c0             	test   %ax,%ax
    dcc3:	0f 85 a1 f3 ff ff    	jne    d06a <f0+0x1c6a>
    dcc9:	e9 8c f3 ff ff       	jmp    d05a <f0+0x1c5a>
    dcce:	66 90                	xchg   %ax,%ax
    dcd0:	66 85 c0             	test   %ax,%ax
    dcd3:	0f 85 f2 f2 ff ff    	jne    cfcb <f0+0x1bcb>
    dcd9:	e9 dd f2 ff ff       	jmp    cfbb <f0+0x1bbb>
    dcde:	66 90                	xchg   %ax,%ax
    dce0:	66 85 c0             	test   %ax,%ax
    dce3:	0f 85 43 f2 ff ff    	jne    cf2c <f0+0x1b2c>
    dce9:	e9 2e f2 ff ff       	jmp    cf1c <f0+0x1b1c>
    dcee:	66 90                	xchg   %ax,%ax
    dcf0:	66 85 c0             	test   %ax,%ax
    dcf3:	0f 85 94 f1 ff ff    	jne    ce8d <f0+0x1a8d>
    dcf9:	e9 7f f1 ff ff       	jmp    ce7d <f0+0x1a7d>
    dcfe:	66 90                	xchg   %ax,%ax
    dd00:	66 85 c0             	test   %ax,%ax
    dd03:	0f 85 e5 f0 ff ff    	jne    cdee <f0+0x19ee>
    dd09:	e9 d0 f0 ff ff       	jmp    cdde <f0+0x19de>
    dd0e:	66 90                	xchg   %ax,%ax
    dd10:	66 85 c0             	test   %ax,%ax
    dd13:	0f 85 fd d9 ff ff    	jne    b716 <f0+0x316>
    dd19:	e9 e8 d9 ff ff       	jmp    b706 <f0+0x306>
    dd1e:	66 90                	xchg   %ax,%ax
    dd20:	66 85 c0             	test   %ax,%ax
    dd23:	0f 85 57 d9 ff ff    	jne    b680 <f0+0x280>
    dd29:	e9 42 d9 ff ff       	jmp    b670 <f0+0x270>
    dd2e:	66 90                	xchg   %ax,%ax
    dd30:	66 85 c0             	test   %ax,%ax
    dd33:	0f 85 b1 d8 ff ff    	jne    b5ea <f0+0x1ea>
    dd39:	e9 9c d8 ff ff       	jmp    b5da <f0+0x1da>
    dd3e:	66 90                	xchg   %ax,%ax
    dd40:	66 85 c0             	test   %ax,%ax
    dd43:	0f 85 0e eb ff ff    	jne    c857 <f0+0x1457>
    dd49:	e9 f9 ea ff ff       	jmp    c847 <f0+0x1447>
    dd4e:	66 90                	xchg   %ax,%ax
    dd50:	66 85 c0             	test   %ax,%ax
    dd53:	0f 85 5f ea ff ff    	jne    c7b8 <f0+0x13b8>
    dd59:	e9 4a ea ff ff       	jmp    c7a8 <f0+0x13a8>
    dd5e:	66 90                	xchg   %ax,%ax
    dd60:	66 85 c0             	test   %ax,%ax
    dd63:	0f 85 e2 da ff ff    	jne    b84b <f0+0x44b>
    dd69:	e9 cd da ff ff       	jmp    b83b <f0+0x43b>
    dd6e:	66 90                	xchg   %ax,%ax
    dd70:	66 85 c0             	test   %ax,%ax
    dd73:	0f 85 33 da ff ff    	jne    b7ac <f0+0x3ac>
    dd79:	e9 1e da ff ff       	jmp    b79c <f0+0x39c>
    dd7e:	66 90                	xchg   %ax,%ax
    dd80:	66 85 c0             	test   %ax,%ax
    dd83:	0f 85 c6 ef ff ff    	jne    cd4f <f0+0x194f>
    dd89:	e9 b1 ef ff ff       	jmp    cd3f <f0+0x193f>
    dd8e:	66 90                	xchg   %ax,%ax
    dd90:	66 85 c0             	test   %ax,%ax
    dd93:	0f 85 17 ef ff ff    	jne    ccb0 <f0+0x18b0>
    dd99:	e9 02 ef ff ff       	jmp    cca0 <f0+0x18a0>
    dd9e:	66 90                	xchg   %ax,%ax
    dda0:	66 85 c0             	test   %ax,%ax
    dda3:	0f 85 68 ee ff ff    	jne    cc11 <f0+0x1811>
    dda9:	e9 53 ee ff ff       	jmp    cc01 <f0+0x1801>
    ddae:	66 90                	xchg   %ax,%ax
    ddb0:	66 85 c0             	test   %ax,%ax
    ddb3:	0f 85 b9 ed ff ff    	jne    cb72 <f0+0x1772>
    ddb9:	e9 a4 ed ff ff       	jmp    cb62 <f0+0x1762>
    ddbe:	66 90                	xchg   %ax,%ax
    ddc0:	66 85 c0             	test   %ax,%ax
    ddc3:	0f 85 0a ed ff ff    	jne    cad3 <f0+0x16d3>
    ddc9:	e9 f5 ec ff ff       	jmp    cac3 <f0+0x16c3>
    ddce:	66 90                	xchg   %ax,%ax
    ddd0:	66 85 c0             	test   %ax,%ax
    ddd3:	0f 85 5b ec ff ff    	jne    ca34 <f0+0x1634>
    ddd9:	e9 46 ec ff ff       	jmp    ca24 <f0+0x1624>
    ddde:	66 90                	xchg   %ax,%ax
    dde0:	66 85 c0             	test   %ax,%ax
    dde3:	0f 85 ac eb ff ff    	jne    c995 <f0+0x1595>
    dde9:	e9 97 eb ff ff       	jmp    c985 <f0+0x1585>
    ddee:	66 90                	xchg   %ax,%ax
    ddf0:	66 85 c0             	test   %ax,%ax
    ddf3:	0f 85 fd ea ff ff    	jne    c8f6 <f0+0x14f6>
    ddf9:	e9 e8 ea ff ff       	jmp    c8e6 <f0+0x14e6>
    ddfe:	66 90                	xchg   %ax,%ax
    de00:	66 85 c0             	test   %ax,%ax
    de03:	0f 85 29 fe ff ff    	jne    dc32 <f0+0x2832>
    de09:	e9 14 fe ff ff       	jmp    dc22 <f0+0x2822>
    de0e:	66 90                	xchg   %ax,%ax
    de10:	66 85 c0             	test   %ax,%ax
    de13:	0f 85 7f fd ff ff    	jne    db98 <f0+0x2798>
    de19:	e9 6a fd ff ff       	jmp    db88 <f0+0x2788>
    de1e:	66 90                	xchg   %ax,%ax
    de20:	66 85 c0             	test   %ax,%ax
    de23:	0f 85 d0 fc ff ff    	jne    daf9 <f0+0x26f9>
    de29:	e9 bb fc ff ff       	jmp    dae9 <f0+0x26e9>
    de2e:	66 90                	xchg   %ax,%ax
    de30:	66 85 c0             	test   %ax,%ax
    de33:	0f 85 21 fc ff ff    	jne    da5a <f0+0x265a>
    de39:	e9 0c fc ff ff       	jmp    da4a <f0+0x264a>
    de3e:	66 90                	xchg   %ax,%ax
    de40:	66 85 c0             	test   %ax,%ax
    de43:	0f 85 72 fb ff ff    	jne    d9bb <f0+0x25bb>
    de49:	e9 5d fb ff ff       	jmp    d9ab <f0+0x25ab>
    de4e:	66 90                	xchg   %ax,%ax
    de50:	66 85 c0             	test   %ax,%ax
    de53:	0f 85 c3 fa ff ff    	jne    d91c <f0+0x251c>
    de59:	e9 ae fa ff ff       	jmp    d90c <f0+0x250c>
    de5e:	66 90                	xchg   %ax,%ax
    de60:	66 85 c0             	test   %ax,%ax
    de63:	0f 85 14 fa ff ff    	jne    d87d <f0+0x247d>
    de69:	e9 ff f9 ff ff       	jmp    d86d <f0+0x246d>
    de6e:	66 90                	xchg   %ax,%ax
    de70:	66 85 c0             	test   %ax,%ax
    de73:	0f 85 65 f9 ff ff    	jne    d7de <f0+0x23de>
    de79:	e9 50 f9 ff ff       	jmp    d7ce <f0+0x23ce>
    de7e:	66 90                	xchg   %ax,%ax
    de80:	66 85 c0             	test   %ax,%ax
    de83:	0f 85 b6 f8 ff ff    	jne    d73f <f0+0x233f>
    de89:	e9 a1 f8 ff ff       	jmp    d72f <f0+0x232f>
    de8e:	66 90                	xchg   %ax,%ax
    de90:	66 85 c0             	test   %ax,%ax
    de93:	0f 85 07 f8 ff ff    	jne    d6a0 <f0+0x22a0>
    de99:	e9 f2 f7 ff ff       	jmp    d690 <f0+0x2290>
    de9e:	66 90                	xchg   %ax,%ax
    dea0:	66 85 c0             	test   %ax,%ax
    dea3:	0f 85 58 f7 ff ff    	jne    d601 <f0+0x2201>
    dea9:	e9 43 f7 ff ff       	jmp    d5f1 <f0+0x21f1>
    deae:	66 90                	xchg   %ax,%ax
    deb0:	66 85 c0             	test   %ax,%ax
    deb3:	0f 85 a9 f6 ff ff    	jne    d562 <f0+0x2162>
    deb9:	e9 94 f6 ff ff       	jmp    d552 <f0+0x2152>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	66 85 c0             	test   %ax,%ax
    dec3:	0f 85 fa f5 ff ff    	jne    d4c3 <f0+0x20c3>
    dec9:	e9 e5 f5 ff ff       	jmp    d4b3 <f0+0x20b3>
    dece:	66 90                	xchg   %ax,%ax
    ded0:	66 85 c0             	test   %ax,%ax
    ded3:	0f 85 4b f5 ff ff    	jne    d424 <f0+0x2024>
    ded9:	e9 36 f5 ff ff       	jmp    d414 <f0+0x2014>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	66 85 c0             	test   %ax,%ax
    dee3:	0f 85 9c f4 ff ff    	jne    d385 <f0+0x1f85>
    dee9:	e9 87 f4 ff ff       	jmp    d375 <f0+0x1f75>
    deee:	66 90                	xchg   %ax,%ax
    def0:	66 85 c0             	test   %ax,%ax
    def3:	0f 85 ed f3 ff ff    	jne    d2e6 <f0+0x1ee6>
    def9:	e9 d8 f3 ff ff       	jmp    d2d6 <f0+0x1ed6>
    defe:	4c 89 e7             	mov    %r12,%rdi
    df01:	e8 0a 74 ff ff       	call   5310 <fwp_rc_forget_slot>
    df06:	e9 22 fd ff ff       	jmp    dc2d <f0+0x282d>
    df0b:	4c 89 e7             	mov    %r12,%rdi
    df0e:	e8 fd 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df13:	e9 cd d6 ff ff       	jmp    b5e5 <f0+0x1e5>
    df18:	4c 89 e7             	mov    %r12,%rdi
    df1b:	e8 f0 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df20:	e9 56 d7 ff ff       	jmp    b67b <f0+0x27b>
    df25:	4c 89 e7             	mov    %r12,%rdi
    df28:	e8 e3 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df2d:	e9 df d7 ff ff       	jmp    b711 <f0+0x311>
    df32:	4c 89 e7             	mov    %r12,%rdi
    df35:	e8 d6 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df3a:	e9 68 d8 ff ff       	jmp    b7a7 <f0+0x3a7>
    df3f:	4c 89 e7             	mov    %r12,%rdi
    df42:	e8 c9 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df47:	e9 fa d8 ff ff       	jmp    b846 <f0+0x446>
    df4c:	4c 89 e7             	mov    %r12,%rdi
    df4f:	e8 bc 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df54:	e9 5a e8 ff ff       	jmp    c7b3 <f0+0x13b3>
    df59:	4c 89 e7             	mov    %r12,%rdi
    df5c:	e8 af 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df61:	e9 ec e8 ff ff       	jmp    c852 <f0+0x1452>
    df66:	4c 89 e7             	mov    %r12,%rdi
    df69:	e8 a2 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df6e:	e9 7e e9 ff ff       	jmp    c8f1 <f0+0x14f1>
    df73:	4c 89 e7             	mov    %r12,%rdi
    df76:	e8 95 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df7b:	e9 10 ea ff ff       	jmp    c990 <f0+0x1590>
    df80:	4c 89 e7             	mov    %r12,%rdi
    df83:	e8 88 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df88:	e9 a2 ea ff ff       	jmp    ca2f <f0+0x162f>
    df8d:	4c 89 e7             	mov    %r12,%rdi
    df90:	e8 7b 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    df95:	e9 34 eb ff ff       	jmp    cace <f0+0x16ce>
    df9a:	4c 89 e7             	mov    %r12,%rdi
    df9d:	e8 6e 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfa2:	e9 c6 eb ff ff       	jmp    cb6d <f0+0x176d>
    dfa7:	4c 89 e7             	mov    %r12,%rdi
    dfaa:	e8 61 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfaf:	e9 58 ec ff ff       	jmp    cc0c <f0+0x180c>
    dfb4:	4c 89 e7             	mov    %r12,%rdi
    dfb7:	e8 54 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfbc:	e9 ea ec ff ff       	jmp    ccab <f0+0x18ab>
    dfc1:	4c 89 e7             	mov    %r12,%rdi
    dfc4:	e8 47 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfc9:	e9 7c ed ff ff       	jmp    cd4a <f0+0x194a>
    dfce:	4c 89 e7             	mov    %r12,%rdi
    dfd1:	e8 3a 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfd6:	e9 0e ee ff ff       	jmp    cde9 <f0+0x19e9>
    dfdb:	4c 89 e7             	mov    %r12,%rdi
    dfde:	e8 2d 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dfe3:	e9 a0 ee ff ff       	jmp    ce88 <f0+0x1a88>
    dfe8:	4c 89 e7             	mov    %r12,%rdi
    dfeb:	e8 20 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dff0:	e9 32 ef ff ff       	jmp    cf27 <f0+0x1b27>
    dff5:	4c 89 e7             	mov    %r12,%rdi
    dff8:	e8 13 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    dffd:	e9 c4 ef ff ff       	jmp    cfc6 <f0+0x1bc6>
    e002:	4c 89 e7             	mov    %r12,%rdi
    e005:	e8 06 73 ff ff       	call   5310 <fwp_rc_forget_slot>
    e00a:	e9 56 f0 ff ff       	jmp    d065 <f0+0x1c65>
    e00f:	4c 89 e7             	mov    %r12,%rdi
    e012:	e8 f9 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e017:	e9 e8 f0 ff ff       	jmp    d104 <f0+0x1d04>
    e01c:	4c 89 e7             	mov    %r12,%rdi
    e01f:	e8 ec 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e024:	e9 7a f1 ff ff       	jmp    d1a3 <f0+0x1da3>
    e029:	4c 89 e7             	mov    %r12,%rdi
    e02c:	e8 df 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e031:	e9 0c f2 ff ff       	jmp    d242 <f0+0x1e42>
    e036:	4c 89 e7             	mov    %r12,%rdi
    e039:	e8 d2 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e03e:	e9 9e f2 ff ff       	jmp    d2e1 <f0+0x1ee1>
    e043:	4c 89 e7             	mov    %r12,%rdi
    e046:	e8 c5 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e04b:	e9 30 f3 ff ff       	jmp    d380 <f0+0x1f80>
    e050:	4c 89 e7             	mov    %r12,%rdi
    e053:	e8 b8 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e058:	e9 c2 f3 ff ff       	jmp    d41f <f0+0x201f>
    e05d:	4c 89 e7             	mov    %r12,%rdi
    e060:	e8 ab 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e065:	e9 54 f4 ff ff       	jmp    d4be <f0+0x20be>
    e06a:	4c 89 e7             	mov    %r12,%rdi
    e06d:	e8 9e 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e072:	e9 e6 f4 ff ff       	jmp    d55d <f0+0x215d>
    e077:	4c 89 e7             	mov    %r12,%rdi
    e07a:	e8 91 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e07f:	e9 78 f5 ff ff       	jmp    d5fc <f0+0x21fc>
    e084:	4c 89 e7             	mov    %r12,%rdi
    e087:	e8 84 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e08c:	e9 0a f6 ff ff       	jmp    d69b <f0+0x229b>
    e091:	4c 89 e7             	mov    %r12,%rdi
    e094:	e8 77 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e099:	e9 9c f6 ff ff       	jmp    d73a <f0+0x233a>
    e09e:	4c 89 e7             	mov    %r12,%rdi
    e0a1:	e8 6a 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0a6:	e9 2e f7 ff ff       	jmp    d7d9 <f0+0x23d9>
    e0ab:	4c 89 e7             	mov    %r12,%rdi
    e0ae:	e8 5d 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0b3:	e9 c0 f7 ff ff       	jmp    d878 <f0+0x2478>
    e0b8:	4c 89 e7             	mov    %r12,%rdi
    e0bb:	e8 50 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0c0:	e9 52 f8 ff ff       	jmp    d917 <f0+0x2517>
    e0c5:	4c 89 e7             	mov    %r12,%rdi
    e0c8:	e8 43 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0cd:	e9 e4 f8 ff ff       	jmp    d9b6 <f0+0x25b6>
    e0d2:	4c 89 e7             	mov    %r12,%rdi
    e0d5:	e8 36 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0da:	e9 76 f9 ff ff       	jmp    da55 <f0+0x2655>
    e0df:	4c 89 e7             	mov    %r12,%rdi
    e0e2:	e8 29 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0e7:	e9 08 fa ff ff       	jmp    daf4 <f0+0x26f4>
    e0ec:	4c 89 e7             	mov    %r12,%rdi
    e0ef:	e8 1c 72 ff ff       	call   5310 <fwp_rc_forget_slot>
    e0f4:	e9 9a fa ff ff       	jmp    db93 <f0+0x2793>
    e0f9:	e8 62 53 ff ff       	call   3460 <__stack_chk_fail@plt>
    e0fe:	66 90                	xchg   %ax,%ax

000000000000e100 <fwp_main_thread>:
    e100:	f3 0f 1e fa          	endbr64
    e104:	41 54                	push   %r12
    e106:	55                   	push   %rbp
    e107:	53                   	push   %rbx
    e108:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e10f:	8b 0d 0f 6a 01 00    	mov    0x16a0f(%rip),%ecx        # 24b24 <fwp_heap+0x13a4>
    e115:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e11c:	00 00 
    e11e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e125:	00 
    e126:	31 c0                	xor    %eax,%eax
    e128:	85 c9                	test   %ecx,%ecx
    e12a:	0f 84 68 06 00 00    	je     e798 <fwp_main_thread+0x698>
    e130:	8b 15 f2 69 01 00    	mov    0x169f2(%rip),%edx        # 24b28 <fwp_heap+0x13a8>
    e136:	85 d2                	test   %edx,%edx
    e138:	0f 85 42 06 00 00    	jne    e780 <fwp_main_thread+0x680>
    e13e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e143:	31 f6                	xor    %esi,%esi
    e145:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e14a:	48 c7 05 c3 4f 01 00 	movq   $0x40000000,0x14fc3(%rip)        # 23118 <fwp_main_stack_size>
    e151:	00 00 00 40 
    e155:	48 89 05 c4 4f 01 00 	mov    %rax,0x14fc4(%rip)        # 23120 <fwp_main_stack_top>
    e15c:	48 8d 05 3d 4f 00 00 	lea    0x4f3d(%rip),%rax        # 130a0 <alt.5>
    e163:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e168:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e16f:	01 00 
    e171:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e178:	00 
    e179:	e8 42 55 ff ff       	call   36c0 <sigaltstack@plt>
    e17e:	85 c0                	test   %eax,%eax
    e180:	0f 85 4a 06 00 00    	jne    e7d0 <fwp_main_thread+0x6d0>
    e186:	31 c0                	xor    %eax,%eax
    e188:	b9 12 00 00 00       	mov    $0x12,%ecx
    e18d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e192:	f3 48 ab             	rep stos %rax,(%rdi)
    e195:	48 8d 05 54 5b ff ff 	lea    -0xa4ac(%rip),%rax        # 3cf0 <fwp_segv>
    e19c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e1a1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e1a8:	04 00 00 08 
    e1ac:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e1b1:	e8 ca 53 ff ff       	call   3580 <sigemptyset@plt>
    e1b6:	85 c0                	test   %eax,%eax
    e1b8:	0f 85 12 06 00 00    	jne    e7d0 <fwp_main_thread+0x6d0>
    e1be:	31 d2                	xor    %edx,%edx
    e1c0:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e1c5:	bf 0b 00 00 00       	mov    $0xb,%edi
    e1ca:	e8 31 52 ff ff       	call   3400 <sigaction@plt>
    e1cf:	85 c0                	test   %eax,%eax
    e1d1:	0f 85 f9 05 00 00    	jne    e7d0 <fwp_main_thread+0x6d0>
    e1d7:	31 d2                	xor    %edx,%edx
    e1d9:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e1de:	bf 07 00 00 00       	mov    $0x7,%edi
    e1e3:	e8 18 52 ff ff       	call   3400 <sigaction@plt>
    e1e8:	85 c0                	test   %eax,%eax
    e1ea:	0f 85 e0 05 00 00    	jne    e7d0 <fwp_main_thread+0x6d0>
    e1f0:	8b 05 9a 4e 00 00    	mov    0x4e9a(%rip),%eax        # 13090 <st.3>
    e1f6:	85 c0                	test   %eax,%eax
    e1f8:	0f 84 62 05 00 00    	je     e760 <fwp_main_thread+0x660>
    e1fe:	48 8b 2d 5b 55 01 00 	mov    0x1555b(%rip),%rbp        # 23760 <fwp_cur>
    e205:	48 85 ed             	test   %rbp,%rbp
    e208:	0f 84 72 03 00 00    	je     e580 <fwp_main_thread+0x480>
    e20e:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e213:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e217:	48 89 eb             	mov    %rbp,%rbx
    e21a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e21f:	0f 84 41 01 00 00    	je     e366 <fwp_main_thread+0x266>
    e225:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e22a:	0f 84 80 02 00 00    	je     e4b0 <fwp_main_thread+0x3b0>
    e230:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e234:	0f 84 66 02 00 00    	je     e4a0 <fwp_main_thread+0x3a0>
    e23a:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e23e:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e242:	0f 85 e8 02 00 00    	jne    e530 <fwp_main_thread+0x430>
    e248:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e24c:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e253:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e257:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e25e:	00 00 00 00 
    e262:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e269:	48 85 d2             	test   %rdx,%rdx
    e26c:	74 07                	je     e275 <fwp_main_thread+0x175>
    e26e:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e275:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e279:	48 85 c0             	test   %rax,%rax
    e27c:	74 34                	je     e2b2 <fwp_main_thread+0x1b2>
    e27e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e282:	48 8b 05 af 54 01 00 	mov    0x154af(%rip),%rax        # 23738 <fwp_timers>
    e289:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e28d:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e294:	00 00 00 00 
    e298:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e29f:	48 85 c0             	test   %rax,%rax
    e2a2:	74 07                	je     e2ab <fwp_main_thread+0x1ab>
    e2a4:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e2ab:	48 89 1d 86 54 01 00 	mov    %rbx,0x15486(%rip)        # 23738 <fwp_timers>
    e2b2:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e2b6:	e8 f5 91 ff ff       	call   74b0 <fwp_block>
    e2bb:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e2c2:	48 85 c9             	test   %rcx,%rcx
    e2c5:	74 47                	je     e30e <fwp_main_thread+0x20e>
    e2c7:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e2ce:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e2d5:	48 85 d2             	test   %rdx,%rdx
    e2d8:	0f 84 92 02 00 00    	je     e570 <fwp_main_thread+0x470>
    e2de:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e2e5:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e2ec:	48 85 c0             	test   %rax,%rax
    e2ef:	74 07                	je     e2f8 <fwp_main_thread+0x1f8>
    e2f1:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e2f8:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e2ff:	00 00 00 00 
    e303:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e307:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    e30e:	48 8b 0d 4b 54 01 00 	mov    0x1544b(%rip),%rcx        # 23760 <fwp_cur>
    e315:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e319:	0f 84 01 02 00 00    	je     e520 <fwp_main_thread+0x420>
    e31f:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e326:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e32d:	48 85 d2             	test   %rdx,%rdx
    e330:	0f 84 fa 03 00 00    	je     e730 <fwp_main_thread+0x630>
    e336:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e33d:	48 85 c0             	test   %rax,%rax
    e340:	74 07                	je     e349 <fwp_main_thread+0x249>
    e342:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e349:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e34d:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e351:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    e358:	48 89 cb             	mov    %rcx,%rbx
    e35b:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e360:	0f 85 bf fe ff ff    	jne    e225 <fwp_main_thread+0x125>
    e366:	48 83 3d 8a 70 01 00 	cmpq   $0x0,0x1708a(%rip)        # 253f8 <fwp_state_len>
    e36d:	00 
    e36e:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e372:	0f 84 ba 00 00 00    	je     e432 <fwp_main_thread+0x332>
    e378:	48 39 1d d9 53 01 00 	cmp    %rbx,0x153d9(%rip)        # 23758 <fwp_root>
    e37f:	c7 05 17 4d 01 00 00 	movl   $0x0,0x14d17(%rip)        # 230a0 <fwp_exit_code>
    e386:	00 00 00 
    e389:	0f 85 5f 04 00 00    	jne    e7ee <fwp_main_thread+0x6ee>
    e38f:	48 85 db             	test   %rbx,%rbx
    e392:	0f 84 0e 02 00 00    	je     e5a6 <fwp_main_thread+0x4a6>
    e398:	48 8b 15 89 53 01 00 	mov    0x15389(%rip),%rdx        # 23728 <fwp_tasks_active>
    e39f:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e3a3:	48 85 d2             	test   %rdx,%rdx
    e3a6:	0f 84 fa 01 00 00    	je     e5a6 <fwp_main_thread+0x4a6>
    e3ac:	0f 1f 40 00          	nopl   0x0(%rax)
    e3b0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e3b4:	75 08                	jne    e3be <fwp_main_thread+0x2be>
    e3b6:	48 89 d7             	mov    %rdx,%rdi
    e3b9:	e8 f2 5c ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e3be:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e3c5:	48 85 d2             	test   %rdx,%rdx
    e3c8:	75 e6                	jne    e3b0 <fwp_main_thread+0x2b0>
    e3ca:	eb 31                	jmp    e3fd <fwp_main_thread+0x2fd>
    e3cc:	0f 1f 40 00          	nopl   0x0(%rax)
    e3d0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e3d7:	48 89 1d 62 53 01 00 	mov    %rbx,0x15362(%rip)        # 23740 <fwp_ready_tail>
    e3de:	e8 cd 90 ff ff       	call   74b0 <fwp_block>
    e3e3:	e8 c8 8e ff ff       	call   72b0 <fwp_free_zombie>
    e3e8:	48 83 3d 38 53 01 00 	cmpq   $0x0,0x15338(%rip)        # 23728 <fwp_tasks_active>
    e3ef:	00 
    e3f0:	0f 84 b0 01 00 00    	je     e5a6 <fwp_main_thread+0x4a6>
    e3f6:	48 8b 1d 5b 53 01 00 	mov    0x1535b(%rip),%rbx        # 23758 <fwp_root>
    e3fd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e401:	75 db                	jne    e3de <fwp_main_thread+0x2de>
    e403:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e407:	75 d5                	jne    e3de <fwp_main_thread+0x2de>
    e409:	48 8b 05 30 53 01 00 	mov    0x15330(%rip),%rax        # 23740 <fwp_ready_tail>
    e410:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e414:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e41b:	00 00 00 00 
    e41f:	48 85 c0             	test   %rax,%rax
    e422:	75 ac                	jne    e3d0 <fwp_main_thread+0x2d0>
    e424:	48 89 1d 1d 53 01 00 	mov    %rbx,0x1531d(%rip)        # 23748 <fwp_ready_head>
    e42b:	eb aa                	jmp    e3d7 <fwp_main_thread+0x2d7>
    e42d:	0f 1f 00             	nopl   (%rax)
    e430:	31 db                	xor    %ebx,%ebx
    e432:	48 83 3d ae 6f 01 00 	cmpq   $0x0,0x16fae(%rip)        # 253e8 <fwp_state_owners>
    e439:	00 
    e43a:	0f 85 38 ff ff ff    	jne    e378 <fwp_main_thread+0x278>
    e440:	48 8b 3d b9 6f 01 00 	mov    0x16fb9(%rip),%rdi        # 25400 <fwp_state>
    e447:	e8 04 71 ff ff       	call   5550 <fwp_mem_free>
    e44c:	48 c7 05 a9 6f 01 00 	movq   $0x0,0x16fa9(%rip)        # 25400 <fwp_state>
    e453:	00 00 00 00 
    e457:	48 c7 05 8e 6f 01 00 	movq   $0x0,0x16f8e(%rip)        # 253f0 <fwp_state_cap>
    e45e:	00 00 00 00 
    e462:	48 85 db             	test   %rbx,%rbx
    e465:	0f 84 46 03 00 00    	je     e7b1 <fwp_main_thread+0x6b1>
    e46b:	48 39 1d e6 52 01 00 	cmp    %rbx,0x152e6(%rip)        # 23758 <fwp_root>
    e472:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e479:	00 00 00 00 
    e47d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e484:	00 00 00 00 
    e488:	c7 05 0e 4c 01 00 00 	movl   $0x0,0x14c0e(%rip)        # 230a0 <fwp_exit_code>
    e48f:	00 00 00 
    e492:	0f 84 00 ff ff ff    	je     e398 <fwp_main_thread+0x298>
    e498:	e9 b3 52 ff ff       	jmp    3750 <fwp_main_thread.cold>
    e49d:	0f 1f 00             	nopl   (%rax)
    e4a0:	e8 6b 5e ff ff       	call   4310 <fwp_now_ns>
    e4a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e4a9:	0f 8d 91 02 00 00    	jge    e740 <fwp_main_thread+0x640>
    e4af:	90                   	nop
    e4b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e4b4:	0f 85 80 fd ff ff    	jne    e23a <fwp_main_thread+0x13a>
    e4ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e4be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e4c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e4c6:	0f 85 80 fd ff ff    	jne    e24c <fwp_main_thread+0x14c>
    e4cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e4d0:	48 85 c9             	test   %rcx,%rcx
    e4d3:	0f 84 73 fd ff ff    	je     e24c <fwp_main_thread+0x14c>
    e4d9:	48 85 c0             	test   %rax,%rax
    e4dc:	0f 84 ff 02 00 00    	je     e7e1 <fwp_main_thread+0x6e1>
    e4e2:	48 39 c8             	cmp    %rcx,%rax
    e4e5:	48 0f 4f c1          	cmovg  %rcx,%rax
    e4e9:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e4f0:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e4f4:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e4fb:	00 00 00 00 
    e4ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e506:	48 85 d2             	test   %rdx,%rdx
    e509:	74 07                	je     e512 <fwp_main_thread+0x412>
    e50b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e512:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e516:	e9 63 fd ff ff       	jmp    e27e <fwp_main_thread+0x17e>
    e51b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e520:	48 89 cb             	mov    %rcx,%rbx
    e523:	e9 f2 fc ff ff       	jmp    e21a <fwp_main_thread+0x11a>
    e528:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e52f:	00 
    e530:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e534:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e53b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e542:	00 00 00 00 
    e546:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e54d:	48 85 c0             	test   %rax,%rax
    e550:	0f 84 52 02 00 00    	je     e7a8 <fwp_main_thread+0x6a8>
    e556:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e55d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e561:	e9 4c fd ff ff       	jmp    e2b2 <fwp_main_thread+0x1b2>
    e566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e56d:	00 00 00 
    e570:	48 89 01             	mov    %rax,(%rcx)
    e573:	e9 74 fd ff ff       	jmp    e2ec <fwp_main_thread+0x1ec>
    e578:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e57f:	00 
    e580:	48 83 3d 70 6e 01 00 	cmpq   $0x0,0x16e70(%rip)        # 253f8 <fwp_state_len>
    e587:	00 
    e588:	0f 84 a2 fe ff ff    	je     e430 <fwp_main_thread+0x330>
    e58e:	48 83 3d c2 51 01 00 	cmpq   $0x0,0x151c2(%rip)        # 23758 <fwp_root>
    e595:	00 
    e596:	c7 05 00 4b 01 00 00 	movl   $0x0,0x14b00(%rip)        # 230a0 <fwp_exit_code>
    e59d:	00 00 00 
    e5a0:	0f 85 43 02 00 00    	jne    e7e9 <fwp_main_thread+0x6e9>
    e5a6:	e8 05 8d ff ff       	call   72b0 <fwp_free_zombie>
    e5ab:	48 83 3d 95 51 01 00 	cmpq   $0x0,0x15195(%rip)        # 23748 <fwp_ready_head>
    e5b2:	00 
    e5b3:	0f 85 97 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5b9:	48 83 3d 77 51 01 00 	cmpq   $0x0,0x15177(%rip)        # 23738 <fwp_timers>
    e5c0:	00 
    e5c1:	0f 85 89 51 ff ff    	jne    3750 <fwp_main_thread.cold>
    e5c7:	8b 1d 5f 4b 01 00    	mov    0x14b5f(%rip),%ebx        # 2312c <fwp_stack_pool_n>
    e5cd:	85 db                	test   %ebx,%ebx
    e5cf:	74 36                	je     e607 <fwp_main_thread+0x507>
    e5d1:	83 eb 01             	sub    $0x1,%ebx
    e5d4:	48 8d 05 65 4b 01 00 	lea    0x14b65(%rip),%rax        # 23140 <fwp_stack_pool>
    e5db:	48 63 d3             	movslq %ebx,%rdx
    e5de:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e5e2:	eb 07                	jmp    e5eb <fwp_main_thread+0x4eb>
    e5e4:	0f 1f 40 00          	nopl   0x0(%rax)
    e5e8:	83 eb 01             	sub    $0x1,%ebx
    e5eb:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e5ef:	be 00 00 00 10       	mov    $0x10000000,%esi
    e5f4:	89 1d 32 4b 01 00    	mov    %ebx,0x14b32(%rip)        # 2312c <fwp_stack_pool_n>
    e5fa:	48 83 ed 08          	sub    $0x8,%rbp
    e5fe:	e8 dd 4f ff ff       	call   35e0 <munmap@plt>
    e603:	85 db                	test   %ebx,%ebx
    e605:	75 e1                	jne    e5e8 <fwp_main_thread+0x4e8>
    e607:	8b 3d 13 4a 00 00    	mov    0x4a13(%rip),%edi        # 13020 <fwp_epfd>
    e60d:	85 ff                	test   %edi,%edi
    e60f:	78 05                	js     e616 <fwp_main_thread+0x516>
    e611:	e8 ba 4e ff ff       	call   34d0 <close@plt>
    e616:	4c 8b 25 23 4d 01 00 	mov    0x14d23(%rip),%r12        # 23340 <fwp_nfdws>
    e61d:	48 8b 2d 24 4d 01 00 	mov    0x14d24(%rip),%rbp        # 23348 <fwp_fdws>
    e624:	31 db                	xor    %ebx,%ebx
    e626:	c7 05 f0 49 00 00 ff 	movl   $0xffffffff,0x49f0(%rip)        # 13020 <fwp_epfd>
    e62d:	ff ff ff 
    e630:	4d 85 e4             	test   %r12,%r12
    e633:	74 38                	je     e66d <fwp_main_thread+0x56d>
    e635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e63c:	00 00 00 00 
    e640:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e645:	48 85 ff             	test   %rdi,%rdi
    e648:	74 1a                	je     e664 <fwp_main_thread+0x564>
    e64a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e64e:	0f 85 fc 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e654:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e659:	0f 85 f1 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e65f:	e8 ec 6e ff ff       	call   5550 <fwp_mem_free>
    e664:	48 83 c3 01          	add    $0x1,%rbx
    e668:	4c 39 e3             	cmp    %r12,%rbx
    e66b:	75 d3                	jne    e640 <fwp_main_thread+0x540>
    e66d:	48 89 ef             	mov    %rbp,%rdi
    e670:	e8 db 6e ff ff       	call   5550 <fwp_mem_free>
    e675:	48 8b 15 dc 50 01 00 	mov    0x150dc(%rip),%rdx        # 23758 <fwp_root>
    e67c:	48 c7 05 c1 4c 01 00 	movq   $0x0,0x14cc1(%rip)        # 23348 <fwp_fdws>
    e683:	00 00 00 00 
    e687:	48 c7 05 ae 4c 01 00 	movq   $0x0,0x14cae(%rip)        # 23340 <fwp_nfdws>
    e68e:	00 00 00 00 
    e692:	48 85 d2             	test   %rdx,%rdx
    e695:	74 4e                	je     e6e5 <fwp_main_thread+0x5e5>
    e697:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e69c:	0f 85 ae 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e6a9:	00 
    e6aa:	0f 85 a0 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6b0:	48 83 3d 40 6d 01 00 	cmpq   $0x0,0x16d40(%rip)        # 253f8 <fwp_state_len>
    e6b7:	00 
    e6b8:	0f 85 92 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6be:	48 83 3d 22 6d 01 00 	cmpq   $0x0,0x16d22(%rip)        # 253e8 <fwp_state_owners>
    e6c5:	00 
    e6c6:	0f 85 84 50 ff ff    	jne    3750 <fwp_main_thread.cold>
    e6cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    e6d1:	31 c0                	xor    %eax,%eax
    e6d3:	48 8d 3d 86 4c 01 00 	lea    0x14c86(%rip),%rdi        # 23360 <fwp_root_context>
    e6da:	f3 48 ab             	rep stos %rax,(%rdi)
    e6dd:	48 89 d7             	mov    %rdx,%rdi
    e6e0:	e8 6b 6e ff ff       	call   5550 <fwp_mem_free>
    e6e5:	48 8b 3d 54 49 00 00 	mov    0x4954(%rip),%rdi        # 13040 <stdout@GLIBC_2.2.5>
    e6ec:	48 c7 05 69 50 01 00 	movq   $0x0,0x15069(%rip)        # 23760 <fwp_cur>
    e6f3:	00 00 00 00 
    e6f7:	48 c7 05 56 50 01 00 	movq   $0x0,0x15056(%rip)        # 23758 <fwp_root>
    e6fe:	00 00 00 00 
    e702:	e8 b9 4e ff ff       	call   35c0 <fflush@plt>
    e707:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e70e:	00 
    e70f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e716:	00 00 
    e718:	0f 85 be 00 00 00    	jne    e7dc <fwp_main_thread+0x6dc>
    e71e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e725:	31 c0                	xor    %eax,%eax
    e727:	5b                   	pop    %rbx
    e728:	5d                   	pop    %rbp
    e729:	41 5c                	pop    %r12
    e72b:	c3                   	ret
    e72c:	0f 1f 40 00          	nopl   0x0(%rax)
    e730:	48 89 05 01 50 01 00 	mov    %rax,0x15001(%rip)        # 23738 <fwp_timers>
    e737:	e9 01 fc ff ff       	jmp    e33d <fwp_main_thread+0x23d>
    e73c:	0f 1f 40 00          	nopl   0x0(%rax)
    e740:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e744:	0f 85 66 fd ff ff    	jne    e4b0 <fwp_main_thread+0x3b0>
    e74a:	48 89 ef             	mov    %rbp,%rdi
    e74d:	e8 5e 59 ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    e752:	e9 59 fd ff ff       	jmp    e4b0 <fwp_main_thread+0x3b0>
    e757:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e75e:	00 00 
    e760:	e8 9b cc ff ff       	call   b400 <f0>
    e765:	48 c7 05 18 49 00 00 	movq   $0x0,0x4918(%rip)        # 13088 <v.2>
    e76c:	00 00 00 00 
    e770:	c7 05 16 49 00 00 01 	movl   $0x1,0x4916(%rip)        # 13090 <st.3>
    e777:	00 00 00 
    e77a:	e9 7f fa ff ff       	jmp    e1fe <fwp_main_thread+0xfe>
    e77f:	90                   	nop
    e780:	48 8d 3d 99 62 ff ff 	lea    -0x9d67(%rip),%rdi        # 4a20 <fwp_heap_report>
    e787:	e8 84 02 00 00       	call   ea10 <atexit>
    e78c:	e9 ad f9 ff ff       	jmp    e13e <fwp_main_thread+0x3e>
    e791:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e798:	e8 93 63 ff ff       	call   4b30 <fwp_heap_init>
    e79d:	e9 8e f9 ff ff       	jmp    e130 <fwp_main_thread+0x30>
    e7a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e7a8:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e7ac:	e9 01 fb ff ff       	jmp    e2b2 <fwp_main_thread+0x1b2>
    e7b1:	48 83 3d 9f 4f 01 00 	cmpq   $0x0,0x14f9f(%rip)        # 23758 <fwp_root>
    e7b8:	00 
    e7b9:	c7 05 dd 48 01 00 00 	movl   $0x0,0x148dd(%rip)        # 230a0 <fwp_exit_code>
    e7c0:	00 00 00 
    e7c3:	0f 84 dd fd ff ff    	je     e5a6 <fwp_main_thread+0x4a6>
    e7c9:	e9 82 4f ff ff       	jmp    3750 <fwp_main_thread.cold>
    e7ce:	66 90                	xchg   %ax,%ax
    e7d0:	48 8d 3d 19 11 00 00 	lea    0x1119(%rip),%rdi        # f8f0 <_IO_stdin_used+0x8f0>
    e7d7:	e8 c4 59 ff ff       	call   41a0 <fwp_trap>
    e7dc:	e8 7f 4c ff ff       	call   3460 <__stack_chk_fail@plt>
    e7e1:	48 89 c8             	mov    %rcx,%rax
    e7e4:	e9 00 fd ff ff       	jmp    e4e9 <fwp_main_thread+0x3e9>
    e7e9:	e9 62 4f ff ff       	jmp    3750 <fwp_main_thread.cold>
    e7ee:	e9 5d 4f ff ff       	jmp    3750 <fwp_main_thread.cold>
    e7f3:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e7fa:	00 00 00 
    e7fd:	0f 1f 00             	nopl   (%rax)

000000000000e800 <__divmodti4>:
    e800:	f3 0f 1e fa          	endbr64
    e804:	55                   	push   %rbp
    e805:	49 89 f1             	mov    %rsi,%r9
    e808:	49 89 d2             	mov    %rdx,%r10
    e80b:	48 89 fe             	mov    %rdi,%rsi
    e80e:	49 89 cb             	mov    %rcx,%r11
    e811:	48 89 e5             	mov    %rsp,%rbp
    e814:	41 57                	push   %r15
    e816:	41 56                	push   %r14
    e818:	41 55                	push   %r13
    e81a:	41 54                	push   %r12
    e81c:	53                   	push   %rbx
    e81d:	4c 89 c3             	mov    %r8,%rbx
    e820:	45 31 c0             	xor    %r8d,%r8d
    e823:	4d 85 c9             	test   %r9,%r9
    e826:	79 12                	jns    e83a <__divmodti4+0x3a>
    e828:	31 ff                	xor    %edi,%edi
    e82a:	48 f7 de             	neg    %rsi
    e82d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e834:	4c 19 cf             	sbb    %r9,%rdi
    e837:	49 89 f9             	mov    %rdi,%r9
    e83a:	4c 89 d8             	mov    %r11,%rax
    e83d:	4d 85 db             	test   %r11,%r11
    e840:	0f 88 1a 01 00 00    	js     e960 <__divmodti4+0x160>
    e846:	4c 89 d9             	mov    %r11,%rcx
    e849:	49 89 f3             	mov    %rsi,%r11
    e84c:	75 62                	jne    e8b0 <__divmodti4+0xb0>
    e84e:	4d 89 c4             	mov    %r8,%r12
    e851:	4d 39 d1             	cmp    %r10,%r9
    e854:	0f 83 46 01 00 00    	jae    e9a0 <__divmodti4+0x1a0>
    e85a:	4c 89 d8             	mov    %r11,%rax
    e85d:	4c 89 ca             	mov    %r9,%rdx
    e860:	49 f7 f2             	div    %r10
    e863:	49 89 c3             	mov    %rax,%r11
    e866:	31 c0                	xor    %eax,%eax
    e868:	48 89 d6             	mov    %rdx,%rsi
    e86b:	31 ff                	xor    %edi,%edi
    e86d:	4c 89 d9             	mov    %r11,%rcx
    e870:	48 89 c2             	mov    %rax,%rdx
    e873:	48 89 c8             	mov    %rcx,%rax
    e876:	4d 85 e4             	test   %r12,%r12
    e879:	74 0a                	je     e885 <__divmodti4+0x85>
    e87b:	48 f7 d8             	neg    %rax
    e87e:	48 83 d2 00          	adc    $0x0,%rdx
    e882:	48 f7 da             	neg    %rdx
    e885:	4d 85 c0             	test   %r8,%r8
    e888:	74 0a                	je     e894 <__divmodti4+0x94>
    e88a:	48 f7 de             	neg    %rsi
    e88d:	48 83 d7 00          	adc    $0x0,%rdi
    e891:	48 f7 df             	neg    %rdi
    e894:	48 89 33             	mov    %rsi,(%rbx)
    e897:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e89b:	5b                   	pop    %rbx
    e89c:	41 5c                	pop    %r12
    e89e:	41 5d                	pop    %r13
    e8a0:	41 5e                	pop    %r14
    e8a2:	41 5f                	pop    %r15
    e8a4:	5d                   	pop    %rbp
    e8a5:	c3                   	ret
    e8a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e8ad:	00 00 00 
    e8b0:	4d 89 c4             	mov    %r8,%r12
    e8b3:	49 39 c1             	cmp    %rax,%r9
    e8b6:	0f 82 ce 00 00 00    	jb     e98a <__divmodti4+0x18a>
    e8bc:	31 ff                	xor    %edi,%edi
    e8be:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e8c3:	48 63 c7             	movslq %edi,%rax
    e8c6:	be 40 00 00 00       	mov    $0x40,%esi
    e8cb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e8d0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e8d5:	48 29 c6             	sub    %rax,%rsi
    e8d8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e8dd:	48 09 c8             	or     %rcx,%rax
    e8e0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e8e5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e8ea:	49 89 c6             	mov    %rax,%r14
    e8ed:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e8f1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e8f6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e8fb:	49 09 c1             	or     %rax,%r9
    e8fe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e902:	4c 89 c8             	mov    %r9,%rax
    e905:	49 f7 f6             	div    %r14
    e908:	48 89 d1             	mov    %rdx,%rcx
    e90b:	49 89 c3             	mov    %rax,%r11
    e90e:	49 89 c1             	mov    %rax,%r9
    e911:	49 f7 e2             	mul    %r10
    e914:	49 89 c6             	mov    %rax,%r14
    e917:	49 89 d2             	mov    %rdx,%r10
    e91a:	48 39 d1             	cmp    %rdx,%rcx
    e91d:	72 07                	jb     e926 <__divmodti4+0x126>
    e91f:	75 17                	jne    e938 <__divmodti4+0x138>
    e921:	49 39 c7             	cmp    %rax,%r15
    e924:	73 12                	jae    e938 <__divmodti4+0x138>
    e926:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e92a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e92e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e932:	49 89 d2             	mov    %rdx,%r10
    e935:	49 89 c6             	mov    %rax,%r14
    e938:	4c 89 f8             	mov    %r15,%rax
    e93b:	4c 29 f0             	sub    %r14,%rax
    e93e:	4c 19 d1             	sbb    %r10,%rcx
    e941:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e946:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e94b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e950:	48 09 c6             	or     %rax,%rsi
    e953:	48 89 cf             	mov    %rcx,%rdi
    e956:	31 c0                	xor    %eax,%eax
    e958:	4c 89 c9             	mov    %r9,%rcx
    e95b:	e9 10 ff ff ff       	jmp    e870 <__divmodti4+0x70>
    e960:	4c 89 d0             	mov    %r10,%rax
    e963:	4c 89 da             	mov    %r11,%rdx
    e966:	4d 89 c4             	mov    %r8,%r12
    e969:	49 89 f3             	mov    %rsi,%r11
    e96c:	48 f7 d8             	neg    %rax
    e96f:	49 f7 d4             	not    %r12
    e972:	48 83 d2 00          	adc    $0x0,%rdx
    e976:	49 89 c2             	mov    %rax,%r10
    e979:	48 f7 da             	neg    %rdx
    e97c:	48 89 d1             	mov    %rdx,%rcx
    e97f:	0f 84 cc fe ff ff    	je     e851 <__divmodti4+0x51>
    e985:	49 39 d1             	cmp    %rdx,%r9
    e988:	73 46                	jae    e9d0 <__divmodti4+0x1d0>
    e98a:	4c 89 cf             	mov    %r9,%rdi
    e98d:	31 c0                	xor    %eax,%eax
    e98f:	31 c9                	xor    %ecx,%ecx
    e991:	e9 da fe ff ff       	jmp    e870 <__divmodti4+0x70>
    e996:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e99d:	00 00 00 
    e9a0:	4d 85 d2             	test   %r10,%r10
    e9a3:	75 0d                	jne    e9b2 <__divmodti4+0x1b2>
    e9a5:	b8 01 00 00 00       	mov    $0x1,%eax
    e9aa:	31 d2                	xor    %edx,%edx
    e9ac:	49 f7 f2             	div    %r10
    e9af:	49 89 c2             	mov    %rax,%r10
    e9b2:	4c 89 c8             	mov    %r9,%rax
    e9b5:	31 d2                	xor    %edx,%edx
    e9b7:	49 f7 f2             	div    %r10
    e9ba:	49 89 c1             	mov    %rax,%r9
    e9bd:	4c 89 d8             	mov    %r11,%rax
    e9c0:	49 f7 f2             	div    %r10
    e9c3:	49 89 c3             	mov    %rax,%r11
    e9c6:	4c 89 c8             	mov    %r9,%rax
    e9c9:	e9 9a fe ff ff       	jmp    e868 <__divmodti4+0x68>
    e9ce:	66 90                	xchg   %ax,%ax
    e9d0:	45 31 f6             	xor    %r14d,%r14d
    e9d3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e9d8:	44 89 f7             	mov    %r14d,%edi
    e9db:	45 85 f6             	test   %r14d,%r14d
    e9de:	0f 85 df fe ff ff    	jne    e8c3 <__divmodti4+0xc3>
    e9e4:	4c 39 ca             	cmp    %r9,%rdx
    e9e7:	72 17                	jb     ea00 <__divmodti4+0x200>
    e9e9:	31 c9                	xor    %ecx,%ecx
    e9eb:	48 39 c6             	cmp    %rax,%rsi
    e9ee:	73 10                	jae    ea00 <__divmodti4+0x200>
    e9f0:	4c 89 cf             	mov    %r9,%rdi
    e9f3:	31 c0                	xor    %eax,%eax
    e9f5:	e9 76 fe ff ff       	jmp    e870 <__divmodti4+0x70>
    e9fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ea00:	4c 89 de             	mov    %r11,%rsi
    ea03:	b9 01 00 00 00       	mov    $0x1,%ecx
    ea08:	48 29 c6             	sub    %rax,%rsi
    ea0b:	49 19 d1             	sbb    %rdx,%r9
    ea0e:	eb e0                	jmp    e9f0 <__divmodti4+0x1f0>

000000000000ea10 <atexit>:
    ea10:	f3 0f 1e fa          	endbr64
    ea14:	48 8b 15 ed 45 00 00 	mov    0x45ed(%rip),%rdx        # 13008 <__dso_handle>
    ea1b:	31 f6                	xor    %esi,%esi
    ea1d:	e9 3e 4c ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ea24 <_fini>:
    ea24:	f3 0f 1e fa          	endbr64
    ea28:	48 83 ec 08          	sub    $0x8,%rsp
    ea2c:	48 83 c4 08          	add    $0x8,%rsp
    ea30:	c3                   	ret
