
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 ff 00 00 	mov    0xffc1(%rip),%rax        # 12fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da fd 00 00    	push   0xfdda(%rip)        # 12e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc fd 00 00    	jmp    *0xfddc(%rip)        # 12e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 fc 00 00    	jmp    *0xfc46(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 f8 00 00    	jmp    *0xf8e6(%rip)        # 12f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de f8 00 00    	jmp    *0xf8de(%rip)        # 12f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 f8 00 00    	jmp    *0xf8d6(%rip)        # 12fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce f8 00 00    	jmp    *0xf8ce(%rip)        # 12fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 f8 00 00    	jmp    *0xf8c6(%rip)        # 12fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be f8 00 00    	jmp    *0xf8be(%rip)        # 12fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd b9 00 00 	lea    0xb9dd(%rip),%r9        # f0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da b9 00 00 	lea    0xb9da(%rip),%r8        # f0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 71 fc ff ff       	call   33d0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 db 00 00 	lea    0xdb81(%rip),%rax        # 11300 <fwp_fn_table>
    377f:	48 89 05 92 1c 02 00 	mov    %rax,0x21c92(%rip)        # 25418 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c 1c 02 00 	mov    %rax,0x21c8c(%rip)        # 25420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 ba 00 00 	lea    0xbab7(%rip),%rdi        # f257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ef a4 00 00 	lea    0xa4ef(%rip),%rdx        # dd50 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 b9 00 00 	lea    0xb967(%rip),%rdi        # f260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 c1 00 00 	lea    0xc186(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 40 c1 00 00 	lea    0xc140(%rip),%rdi        # fa68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 c1 00 00 	lea    0xc104(%rip),%rdi        # fa38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 c0 00 00 	lea    0xc0d0(%rip),%rdi        # fa10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b f6 00 00    	call   *0xf64b(%rip)        # 12fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e f6 00 00 	mov    0xf62e(%rip),%rax        # 12fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd f5 00 00 	mov    0xf5fd(%rip),%rax        # 12fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da f5 00 00 	cmpq   $0x0,0xf5da(%rip)        # 12fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce f4 01 00 	add    0x1f4ce(%rip),%rdx        # 230f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc f4 01 00 	add    0x1f4bc(%rip),%rax        # 230f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 17 02 00 	mov    0x217a9(%rip),%rdi        # 25420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 f3 00 00 	mov    0xf394(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 f3 00 00 	mov    0xf381(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 b3 00 00 	lea    0xb345(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 f3 00 00 	mov    0xf372(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 fa 01 00 	mov    0x1faa1(%rip),%rax        # 237a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 f3 01 00 	mov    0x1f3d9(%rip),%rax        # 23158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 f3 01 00 	sub    0x1f3c5(%rip),%rax        # 23150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad bd 00 00 	lea    0xbdad(%rip),%rsi        # fb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 b8 00 00 	lea    0xb887(%rip),%rdi        # f670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 f2 00 00 	mov    0xf242(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 f1 00 00 ff 	cmpl   $0xffffffff,0xf1e5(%rip)        # 13018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 b1 00 00 	lea    0xb1e2(%rip),%rax        # f022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 f2 01 00 	mov    0x1f2c1(%rip),%r9        # 23108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f ed 00 	movq   0xed9f(%rip),%xmm0        # 12bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 b1 00 00 	lea    0xb1e7(%rip),%rax        # f044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c f2 01 00 	mov    0x1f29c(%rip),%r8        # 23100 <descent_inputs>
    3e64:	48 8b 0d a5 f2 01 00 	mov    0x1f2a5(%rip),%rcx        # 23110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 f1 00 00 	mov    0xf1c2(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 b1 00 00 	lea    0xb1d8(%rip),%rax        # f061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 ed 00 	movq   0xed67(%rip),%xmm0        # 12bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 b8 00 00 	lea    0xb820(%rip),%rdx        # f6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 f2 01 00 	lea    0x1f271(%rip),%r12        # 23120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 ed 00 	movq   0xed44(%rip),%xmm0        # 12c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b f1 00 00 	mov    0xf15b(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 b1 00 00 	lea    0xb175(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 b1 00 00 	lea    0xb170(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 f1 00 00 	mov    0xf120(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 b1 00 00 	lea    0xb144(%rip),%rdi        # f07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 f0 00 00 	mov    0xf0f9(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 b1 00 00 	lea    0xb143(%rip),%rcx        # f091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 b1 00 00 	lea    0xb119(%rip),%rdx        # f06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b 0c 02 00 	mov    0x20c1b(%rip),%rax        # 24bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 0c 02 00 	lea    0x20c14(%rip),%r8        # 24bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 0b 02 00 	mov    0x20bf5(%rip),%rbx        # 24b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 0c 02 00 	mov    0x20c05(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 0b 02 00 	mov    0x20ba1(%rip),%rdi        # 24ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea 0b 02 00 	sub    %rsi,0x20bea(%rip)        # 24bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a 0b 02 00 	mov    0x20b7a(%rip),%rax        # 24b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 0b 02 00 	add    0x20b30(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e 0b 02 00 	mov    0x20b3e(%rip),%rsi        # 24ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c 0b 02 00 	mov    0x20b4c(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb 0a 02 00 	mov    %r12,0x20afb(%rip)        # 24ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 0a 02 00 	mov    %rbp,0x20ae9(%rip)        # 24b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce 0a 02 00 	cmp    %rdi,0x20ace(%rip)        # 24b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 0a 02 00 	mov    %rdi,0x20ac5(%rip)        # 24b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 0b 02 00 	sub    %rdi,0x20b09(%rip)        # 24bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 0a 02 00 	mov    0x20ab1(%rip),%rax        # 24ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa 0a 02 00 	lea    0x20aaa(%rip),%r8        # 24ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d ee 00 00 	mov    0xee5d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 ae 00 00 	lea    0xae14(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad ed 00 00 	movslq 0xedad(%rip),%rbp        # 13018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a ee 01 00 	mov    0x1ee7a(%rip),%rsi        # 23118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 ee 01 00 	lea    0x1ee76(%rip),%rcx        # 23120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b ee 01 00 	addq   $0x1,0x1ee4b(%rip)        # 23110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 ed 00 00    	mov    %ebx,0xed48(%rip)        # 13018 <descent_active_phase>
    42d0:	48 89 05 41 ee 01 00 	mov    %rax,0x1ee41(%rip)        # 23118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 f4 01 00 	cmp    0x1f499(%rip),%rdi        # 237a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f f4 01 00 	mov    0x1f45f(%rip),%rax        # 23780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d f4 01 00 	mov    %rdi,0x1f43d(%rip)        # 23780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 f4 01 00 	mov    %rdi,0x1f419(%rip)        # 23788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee ad 00 00 	lea    0xadee(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba ac 00 00 	lea    0xacba(%rip),%rsi        # f07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 ec 00 00 	mov    0xec28(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 ac 00 00 	lea    0xac64(%rip),%rdx        # f083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 ec 00 00 	mov    0xec10(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 eb 00 00 	mov    0xeb21(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 aa 00 00 	lea    0xaad8(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 ab 00 00 	lea    0xab45(%rip),%rdi        # f092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd aa 00 00 	lea    0xaacd(%rip),%rdi        # f0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 b1 00 00 	lea    0xb118(%rip),%rdi        # f708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 b5 00 	movdqa 0xb5b0(%rip),%xmm0        # fbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa 0d 02 00 	add    0x20daa(%rip),%rax        # 25418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c b0 00 00 	lea    0xb06c(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ea 01 00 	cmp    %rax,0x1ea05(%rip)        # 230e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ea 01 00 	add    0x1ea00(%rip),%rax        # 230f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 b0 00 00 	lea    0xb055(%rip),%rdi        # f760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 a9 00 00 	lea    0xa9a5(%rip),%r8        # f0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa a7 00 00 	lea    0xa7fa(%rip),%r8        # f0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 a6 00 00 	lea    0xa697(%rip),%r8        # f0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f a4 00 00 	lea    0xa46f(%rip),%rdi        # f0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 fe 01 00 	mov    0x1fe85(%rip),%r9        # 24b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de fe 01 00 	mov    0x1fede(%rip),%r8        # 24be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f aa 00 00 	lea    0xaa9f(%rip),%rdx        # f7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 fe 01 00 	mov    0x1fec6(%rip),%rcx        # 24be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 fe 01 	movsd  0x1fed4(%rip),%xmm1        # 24c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 fe 01 	movsd  0x1fec4(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 e3 00 00 	mov    0xe305(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 ae 00 	movdqa 0xae58(%rip),%xmm0        # fbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f f9 01 00 	lea    0x1f97f(%rip),%rax        # 24700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 ae 00 	movdqa 0xae81(%rip),%xmm2        # fc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 f9 01 00 	movaps %xmm0,0x1f925(%rip)        # 246c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d ae 00 	movdqa 0xae3d(%rip),%xmm0        # fbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 fd 01 00 01 	movl   $0x1,0x1fdb3(%rip)        # 24b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 f9 01 00 	movaps %xmm0,0x1f913(%rip)        # 246d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b ae 00 	movdqa 0xae2b(%rip),%xmm0        # fbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 f9 01 00 	movaps %xmm0,0x1f914(%rip)        # 246e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c ae 00 	movdqa 0xae2c(%rip),%xmm0        # fc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 f9 01 00 	movaps %xmm0,0x1f915(%rip)        # 246f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 e9 01 00 	lea    0x1e995(%rip),%r8        # 237c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 fc 01 00 	mov    %rax,0x1fcb0(%rip)        # 24b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e fc 01 00 	mov    %r12,0x1fc8e(%rip)        # 24b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 fc 01 00 	mov    %rax,0x1fc77(%rip)        # 24b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 fc 01 00 	mov    %rbx,0x1fc90(%rip)        # 24b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 fc 01 00 	mov    %rsi,0x1fcb9(%rip)        # 24bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 a1 00 00 	lea    0xa1f9(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 fc 01 00 	mov    %rax,0x1fc98(%rip)        # 24bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c fc 01 00    	mov    %eax,0x1fc1c(%rip)        # 24b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c e8 01 00 	mov    0x1e80c(%rip),%r8        # 23780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c e7 01 00 	mov    %rbx,0x1e73c(%rip)        # 23788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 e7 01 00 	mov    %r8,0x1e728(%rip)        # 23780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c a0 00 00 	lea    0xa05c(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d df 01 00 	lea    0x1df9d(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 df 01 00 	movaps %xmm0,0x1df85(%rip)        # 230a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 df 01 00 	mov    %rax,0x1df61(%rip)        # 23088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 df 01 00 	movaps %xmm0,0x1df82(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 df 01 00 	movaps %xmm0,0x1df86(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 df 01 00 	mov    %rdx,0x1df87(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 9f 00 00 	lea    0x9fb3(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 e5 01 00 	mov    0x1e5b7(%rip),%rbx        # 23778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a dd 00 00 	mov    0xdd8a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b a5 00 00 	lea    0xa57b(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d e4 01 00 	mov    0x1e48d(%rip),%rax        # 23780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 e4 01 00 	mov    %rdx,0x1e467(%rip)        # 23780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 e3 01 00 	mov    0x1e3b4(%rip),%rbx        # 23778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 e3 01 00 	mov    %rbx,0x1e371(%rip)        # 23778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 e3 01 00 	mov    %rdx,0x1e371(%rip)        # 23788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 e3 01 00 	lea    0x1e386(%rip),%rsi        # 237c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 ff 01 00 	addq   $0x1,0x1ff05(%rip)        # 25408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f a3 00 00 	lea    0xa34f(%rip),%rdi        # f868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 a3 00 00 	lea    0xa360(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 9b 00 00 	lea    0x9bf7(%rip),%rdi        # f133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e e2 01 00 	lea    0x1e23e(%rip),%rcx        # 237c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f fe 01 00 	subq   $0x1,0x1fe3f(%rip)        # 25408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb a2 00 00 	lea    0xa2bb(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 fe 01 00 	cmpq   $0x0,0x1fe20(%rip)        # 25408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 fd 01 00 	sub    %rax,0x1fd75(%rip)        # 25410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 fd 01 00 	add    %r12,0x1fd53(%rip)        # 25410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af f4 01 00 	mov    0x1f4af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac e0 01 00 	lea    0x1e0ac(%rip),%rax        # 237c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 f4 01 00 	add    0x1f403(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 f3 01 00 	mov    0x1f3d0(%rip),%rsi        # 24b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 f3 01 00 	mov    0x1f3f1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 f3 01 00 	add    0x1f3e5(%rip),%r8        # 24bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad f3 01 	addsd  0x1f3ad(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 df 01 00 	lea    0x1df62(%rip),%rax        # 237c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c f3 01 00 	sub    %rdi,0x1f36c(%rip)        # 24be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 f3 01 	movsd  %xmm0,0x1f384(%rip)        # 24c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e f3 01 00 	sub    %rdx,0x1f33e(%rip)        # 24be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 f3 01 	addsd  0x1f344(%rip),%xmm0        # 24c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 f3 01 	movsd  %xmm0,0x1f338(%rip)        # 24c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf f2 01 00 	mov    0x1f2cf(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 f2 01 00 	add    %rcx,0x1f2c9(%rip)        # 24bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 f2 01 00 	cmp    0x1f282(%rip),%r9        # 24bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 f2 01 00 	mov    %r9,0x1f279(%rip)        # 24bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a f2 01 00 	cmp    0x1f26a(%rip),%r9        # 24ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d f2 01 00 	mov    %r9,0x1f25d(%rip)        # 24ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 f1 01 00 	add    0x1f173(%rip),%rdi        # 24bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 dd 01 00 	lea    0x1dd50(%rip),%r15        # 237c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 f0 01 00 	add    0x1f0c0(%rip),%r12        # 24b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 f1 01 00 	add    0x1f119(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 f1 01 00 	cmp    %rax,0x1f118(%rip)        # 24be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 f1 01 00 	mov    %rax,0x1f109(%rip)        # 24be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 f1 01 00 	mov    %rax,0x1f108(%rip)        # 24be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 f1 01 	addsd  0x1f104(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc f0 01 	movsd  %xmm0,0x1f0fc(%rip)        # 24bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 f0 01 00    	mov    0x1f043(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f dc 01 00 	lea    0x1dc7f(%rip),%rdi        # 237c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 f0 01 00 	add    0x1f038(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 f0 01 00 	cmp    %rax,0x1f033(%rip)        # 24be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 f0 01 00 	mov    %rax,0x1f024(%rip)        # 24be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 f0 01 00 	mov    %rax,0x1f023(%rip)        # 24be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f f0 01 	addsd  0x1f01f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 f0 01 	movsd  %xmm0,0x1f017(%rip)        # 24bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce ee 01 00    	mov    0x1eece(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 db 01 00 	lea    0x1db05(%rip),%rax        # 237c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb ee 01 00 	add    0x1eebb(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba ee 01 00 	cmp    %rax,0x1eeba(%rip)        # 24be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab ee 01 00 	mov    %rax,0x1eeab(%rip)        # 24be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa ee 01 00 	mov    %rax,0x1eeaa(%rip)        # 24be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 ee 01 	addsd  0x1eea6(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e ee 01 	movsd  %xmm0,0x1ee9e(%rip)        # 24bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e ed 01 00    	mov    0x1ed9e(%rip),%eax        # 24b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d e9 01 00 	movzbl 0x1e98d(%rip),%eax        # 24762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 d9 01 00 	lea    0x1d9e4(%rip),%rdx        # 237c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 ed 01 00 	add    0x1edb5(%rip),%rax        # 24be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 ed 01 00 	cmp    %rax,0x1edb0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 ed 01 00 	mov    %rax,0x1eda1(%rip)        # 24be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 ed 01 00 	mov    %rax,0x1eda0(%rip)        # 24be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f ed 01 	addsd  0x1ed9f(%rip),%xmm0        # 24bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 ed 01 	movsd  %xmm0,0x1ed97(%rip)        # 24bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_tape_reserve>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	41 54                	push   %r12
    5ee8:	55                   	push   %rbp
    5ee9:	53                   	push   %rbx
    5eea:	48 83 ec 18          	sub    $0x18,%rsp
    5eee:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5ef5:	0f 87 d3 01 00 00    	ja     60ce <fwp_tape_reserve+0x1ee>
    5efb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5eff:	48 89 fd             	mov    %rdi,%rbp
    5f02:	48 39 f3             	cmp    %rsi,%rbx
    5f05:	0f 8d 13 01 00 00    	jge    601e <fwp_tape_reserve+0x13e>
    5f0b:	48 85 db             	test   %rbx,%rbx
    5f0e:	b8 40 00 00 00       	mov    $0x40,%eax
    5f13:	48 0f 44 d8          	cmove  %rax,%rbx
    5f17:	48 39 f3             	cmp    %rsi,%rbx
    5f1a:	7d 24                	jge    5f40 <fwp_tape_reserve+0x60>
    5f1c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5f23:	0f 8f 07 01 00 00    	jg     6030 <fwp_tape_reserve+0x150>
    5f29:	48 01 db             	add    %rbx,%rbx
    5f2c:	48 39 f3             	cmp    %rsi,%rbx
    5f2f:	7c eb                	jl     5f1c <fwp_tape_reserve+0x3c>
    5f31:	0f 1f 40 00          	nopl   0x0(%rax)
    5f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f3c:	00 00 00 00 
    5f40:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5f47:	00 
    5f48:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5f4c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5f50:	4c 89 ee             	mov    %r13,%rsi
    5f53:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5f57:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5f5b:	e8 70 d6 ff ff       	call   35d0 <realloc@plt>
    5f60:	48 85 c0             	test   %rax,%rax
    5f63:	0f 84 71 01 00 00    	je     60da <fwp_tape_reserve+0x1fa>
    5f69:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5f6d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5f71:	4d 29 fc             	sub    %r15,%r12
    5f74:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5f78:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5f7c:	4d 85 f6             	test   %r14,%r14
    5f7f:	0f 84 03 01 00 00    	je     6088 <fwp_tape_reserve+0x1a8>
    5f85:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5f89:	48 39 da             	cmp    %rbx,%rdx
    5f8c:	7d 78                	jge    6006 <fwp_tape_reserve+0x126>
    5f8e:	48 89 d9             	mov    %rbx,%rcx
    5f91:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5f95:	be 02 00 00 00       	mov    $0x2,%esi
    5f9a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5f9f:	48 c1 e1 04          	shl    $0x4,%rcx
    5fa3:	48 89 cf             	mov    %rcx,%rdi
    5fa6:	48 89 0c 24          	mov    %rcx,(%rsp)
    5faa:	e8 e1 fc ff ff       	call   5c90 <fwp_heap_alloc>
    5faf:	49 89 c5             	mov    %rax,%r13
    5fb2:	4d 85 ff             	test   %r15,%r15
    5fb5:	74 27                	je     5fde <fwp_tape_reserve+0xfe>
    5fb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5fbc:	48 8b 0c 24          	mov    (%rsp),%rcx
    5fc0:	48 89 c7             	mov    %rax,%rdi
    5fc3:	4c 89 fe             	mov    %r15,%rsi
    5fc6:	48 c1 e2 04          	shl    $0x4,%rdx
    5fca:	48 39 ca             	cmp    %rcx,%rdx
    5fcd:	48 0f 47 d1          	cmova  %rcx,%rdx
    5fd1:	e8 ca d5 ff ff       	call   35a0 <memcpy@plt>
    5fd6:	4c 89 ff             	mov    %r15,%rdi
    5fd9:	e8 b2 f7 ff ff       	call   5790 <fwp_mem_free>
    5fde:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5fe2:	48 89 da             	mov    %rbx,%rdx
    5fe5:	31 f6                	xor    %esi,%esi
    5fe7:	48 29 fa             	sub    %rdi,%rdx
    5fea:	48 c1 e7 04          	shl    $0x4,%rdi
    5fee:	48 c1 e2 04          	shl    $0x4,%rdx
    5ff2:	4c 01 ef             	add    %r13,%rdi
    5ff5:	e8 c6 d4 ff ff       	call   34c0 <memset@plt>
    5ffa:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5ffe:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6002:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    6006:	4d 85 e4             	test   %r12,%r12
    6009:	75 55                	jne    6060 <fwp_tape_reserve+0x180>
    600b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6012:	00 
    6013:	4c 01 e8             	add    %r13,%rax
    6016:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    601a:	48 89 45 28          	mov    %rax,0x28(%rbp)
    601e:	48 83 c4 18          	add    $0x18,%rsp
    6022:	5b                   	pop    %rbx
    6023:	5d                   	pop    %rbp
    6024:	41 5c                	pop    %r12
    6026:	41 5d                	pop    %r13
    6028:	41 5e                	pop    %r14
    602a:	41 5f                	pop    %r15
    602c:	c3                   	ret
    602d:	0f 1f 00             	nopl   (%rax)
    6030:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    6035:	e9 06 ff ff ff       	jmp    5f40 <fwp_tape_reserve+0x60>
    603a:	4d 39 f5             	cmp    %r14,%r13
    603d:	4c 89 f1             	mov    %r14,%rcx
    6040:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6047:	00 
    6048:	49 0f 43 cd          	cmovae %r13,%rcx
    604c:	4c 29 e9             	sub    %r13,%rcx
    604f:	e8 0c d5 ff ff       	call   3560 <__memmove_chk@plt>
    6054:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6058:	48 8b 45 20          	mov    0x20(%rbp),%rax
    605c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    6060:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    6064:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    606b:	00 
    606c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    6073:	00 
    6074:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6078:	e8 93 d5 ff ff       	call   3610 <memmove@plt>
    607d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6081:	eb 90                	jmp    6013 <fwp_tape_reserve+0x133>
    6083:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6088:	49 89 de             	mov    %rbx,%r14
    608b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    608f:	49 c1 e6 04          	shl    $0x4,%r14
    6093:	4c 89 f6             	mov    %r14,%rsi
    6096:	e8 35 d5 ff ff       	call   35d0 <realloc@plt>
    609b:	48 85 c0             	test   %rax,%rax
    609e:	74 3a                	je     60da <fwp_tape_reserve+0x1fa>
    60a0:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    60a4:	48 89 45 30          	mov    %rax,0x30(%rbp)
    60a8:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    60ac:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    60b0:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    60b4:	4d 85 e4             	test   %r12,%r12
    60b7:	75 81                	jne    603a <fwp_tape_reserve+0x15a>
    60b9:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    60bd:	48 8b 45 20          	mov    0x20(%rbp),%rax
    60c1:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    60c8:	00 
    60c9:	e9 45 ff ff ff       	jmp    6013 <fwp_tape_reserve+0x133>
    60ce:	48 8d 3d 77 90 00 00 	lea    0x9077(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    60d5:	e8 16 e3 ff ff       	call   43f0 <fwp_trap>
    60da:	48 89 ef             	mov    %rbp,%rdi
    60dd:	e8 1e db ff ff       	call   3c00 <fwp_tape_unlink_scope>
    60e2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    60e6:	e8 d5 d2 ff ff       	call   33c0 <free@plt>
    60eb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    60ef:	e8 cc d2 ff ff       	call   33c0 <free@plt>
    60f4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    60f8:	e8 c3 d2 ff ff       	call   33c0 <free@plt>
    60fd:	31 c9                	xor    %ecx,%ecx
    60ff:	31 c0                	xor    %eax,%eax
    6101:	31 d2                	xor    %edx,%edx
    6103:	89 55 04             	mov    %edx,0x4(%rbp)
    6106:	66 0f ef c0          	pxor   %xmm0,%xmm0
    610a:	ba 13 00 00 00       	mov    $0x13,%edx
    610f:	be 01 00 00 00       	mov    $0x1,%esi
    6114:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6118:	48 8d 3d e9 8e 00 00 	lea    0x8ee9(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    611f:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6123:	48 8b 0d 16 cf 00 00 	mov    0xcf16(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    612a:	48 89 45 40          	mov    %rax,0x40(%rbp)
    612e:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6132:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6136:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    613a:	e8 41 d5 ff ff       	call   3680 <fwrite@plt>
    613f:	31 ff                	xor    %edi,%edi
    6141:	e8 7a d4 ff ff       	call   35c0 <fflush@plt>
    6146:	bf 66 00 00 00       	mov    $0x66,%edi
    614b:	e8 50 d5 ff ff       	call   36a0 <_Exit@plt>

0000000000006150 <f141.constprop.0>:
    6150:	41 57                	push   %r15
    6152:	41 56                	push   %r14
    6154:	41 55                	push   %r13
    6156:	41 54                	push   %r12
    6158:	49 89 f4             	mov    %rsi,%r12
    615b:	55                   	push   %rbp
    615c:	48 89 fd             	mov    %rdi,%rbp
    615f:	53                   	push   %rbx
    6160:	48 83 ec 08          	sub    $0x8,%rsp
    6164:	48 85 ff             	test   %rdi,%rdi
    6167:	79 09                	jns    6172 <f141.constprop.0+0x22>
    6169:	48 85 f6             	test   %rsi,%rsi
    616c:	0f 88 fe 00 00 00    	js     6270 <f141.constprop.0+0x120>
    6172:	48 89 f8             	mov    %rdi,%rax
    6175:	48 09 f0             	or     %rsi,%rax
    6178:	0f 89 d2 00 00 00    	jns    6250 <f141.constprop.0+0x100>
    617e:	48 89 f8             	mov    %rdi,%rax
    6181:	48 c1 f8 20          	sar    $0x20,%rax
    6185:	48 85 ff             	test   %rdi,%rdi
    6188:	0f 88 02 01 00 00    	js     6290 <f141.constprop.0+0x140>
    618e:	4c 8b 3d 03 9a 00 00 	mov    0x9a03(%rip),%r15        # fb98 <msg.4+0x28>
    6195:	48 89 c7             	mov    %rax,%rdi
    6198:	e8 33 e5 ff ff       	call   46d0 <fwp_tape_of>
    619d:	48 89 c3             	mov    %rax,%rbx
    61a0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61a5:	0f 85 16 01 00 00    	jne    62c1 <f141.constprop.0+0x171>
    61ab:	4c 8b 68 10          	mov    0x10(%rax),%r13
    61af:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    61b6:	0f 8f f9 00 00 00    	jg     62b5 <f141.constprop.0+0x165>
    61bc:	89 e8                	mov    %ebp,%eax
    61be:	49 39 c5             	cmp    %rax,%r13
    61c1:	0f 8e e2 00 00 00    	jle    62a9 <f141.constprop.0+0x159>
    61c7:	4d 85 e4             	test   %r12,%r12
    61ca:	78 0c                	js     61d8 <f141.constprop.0+0x88>
    61cc:	44 89 e0             	mov    %r12d,%eax
    61cf:	49 39 c5             	cmp    %rax,%r13
    61d2:	0f 8e d1 00 00 00    	jle    62a9 <f141.constprop.0+0x159>
    61d8:	4d 89 ee             	mov    %r13,%r14
    61db:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    61df:	48 89 df             	mov    %rbx,%rdi
    61e2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    61e6:	e8 f5 fc ff ff       	call   5ee0 <fwp_tape_reserve>
    61eb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61ef:	4d 85 e4             	test   %r12,%r12
    61f2:	48 8b 0d 9f 99 00 00 	mov    0x999f(%rip),%rcx        # fb98 <msg.4+0x28>
    61f9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6200:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6204:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6208:	4c 0f 48 e2          	cmovs  %rdx,%r12
    620c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6210:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6214:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6218:	48 8b 43 38          	mov    0x38(%rbx),%rax
    621c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6220:	49 8d 45 01          	lea    0x1(%r13),%rax
    6224:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6228:	48 83 c4 08          	add    $0x8,%rsp
    622c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6233:	ff ff ff 
    6236:	48 21 e8             	and    %rbp,%rax
    6239:	5b                   	pop    %rbx
    623a:	5d                   	pop    %rbp
    623b:	4c 09 e8             	or     %r13,%rax
    623e:	41 5c                	pop    %r12
    6240:	41 5d                	pop    %r13
    6242:	41 5e                	pop    %r14
    6244:	41 5f                	pop    %r15
    6246:	c3                   	ret
    6247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    624e:	00 00 
    6250:	48 89 f0             	mov    %rsi,%rax
    6253:	48 c1 ff 20          	sar    $0x20,%rdi
    6257:	48 c1 f8 20          	sar    $0x20,%rax
    625b:	48 39 c7             	cmp    %rax,%rdi
    625e:	0f 84 2a ff ff ff    	je     618e <f141.constprop.0+0x3e>
    6264:	48 8d 3d 4d 96 00 00 	lea    0x964d(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    626b:	e8 80 e1 ff ff       	call   43f0 <fwp_trap>
    6270:	48 83 c4 08          	add    $0x8,%rsp
    6274:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    627b:	5b                   	pop    %rbx
    627c:	5d                   	pop    %rbp
    627d:	41 5c                	pop    %r12
    627f:	41 5d                	pop    %r13
    6281:	41 5e                	pop    %r14
    6283:	41 5f                	pop    %r15
    6285:	c3                   	ret
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	48 89 f0             	mov    %rsi,%rax
    6293:	48 89 f5             	mov    %rsi,%rbp
    6296:	45 31 ff             	xor    %r15d,%r15d
    6299:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    62a0:	48 c1 f8 20          	sar    $0x20,%rax
    62a4:	e9 ec fe ff ff       	jmp    6195 <f141.constprop.0+0x45>
    62a9:	48 8d 3d b7 8e 00 00 	lea    0x8eb7(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    62b0:	e8 3b e1 ff ff       	call   43f0 <fwp_trap>
    62b5:	48 8d 3d 90 8e 00 00 	lea    0x8e90(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    62bc:	e8 2f e1 ff ff       	call   43f0 <fwp_trap>
    62c1:	48 8d 3d 38 96 00 00 	lea    0x9638(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    62c8:	e8 23 e1 ff ff       	call   43f0 <fwp_trap>
    62cd:	0f 1f 00             	nopl   (%rax)

00000000000062d0 <w120>:
    62d0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    62d4:	41 57                	push   %r15
    62d6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    62da:	41 56                	push   %r14
    62dc:	41 55                	push   %r13
    62de:	41 54                	push   %r12
    62e0:	49 89 f4             	mov    %rsi,%r12
    62e3:	55                   	push   %rbp
    62e4:	48 89 fd             	mov    %rdi,%rbp
    62e7:	53                   	push   %rbx
    62e8:	48 83 ec 38          	sub    $0x38,%rsp
    62ec:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    62f1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    62f7:	48 85 ff             	test   %rdi,%rdi
    62fa:	0f 88 d0 04 00 00    	js     67d0 <w120+0x500>
    6300:	49 89 ff             	mov    %rdi,%r15
    6303:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6309:	49 c1 ff 20          	sar    $0x20,%r15
    630d:	4c 89 ff             	mov    %r15,%rdi
    6310:	e8 bb e3 ff ff       	call   46d0 <fwp_tape_of>
    6315:	48 89 c3             	mov    %rax,%rbx
    6318:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    631d:	0f 85 45 05 00 00    	jne    6868 <w120+0x598>
    6323:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6327:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    632e:	0f 8f 28 05 00 00    	jg     685c <w120+0x58c>
    6334:	89 e8                	mov    %ebp,%eax
    6336:	49 39 c5             	cmp    %rax,%r13
    6339:	0f 8e 11 05 00 00    	jle    6850 <w120+0x580>
    633f:	4d 89 ee             	mov    %r13,%r14
    6342:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6346:	48 89 df             	mov    %rbx,%rdi
    6349:	49 8d 76 01          	lea    0x1(%r14),%rsi
    634d:	e8 8e fb ff ff       	call   5ee0 <fwp_tape_reserve>
    6352:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6356:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    635b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6361:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6365:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6369:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    636f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6373:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6377:	48 8b 43 38          	mov    0x38(%rbx),%rax
    637b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6381:	49 8d 45 01          	lea    0x1(%r13),%rax
    6385:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    638c:	ff ff ff 
    638f:	49 21 ee             	and    %rbp,%r14
    6392:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6396:	4d 09 ee             	or     %r13,%r14
    6399:	4d 89 f5             	mov    %r14,%r13
    639c:	49 c1 fd 20          	sar    $0x20,%r13
    63a0:	4d 85 e4             	test   %r12,%r12
    63a3:	78 10                	js     63b5 <w120+0xe5>
    63a5:	4c 89 e0             	mov    %r12,%rax
    63a8:	48 c1 f8 20          	sar    $0x20,%rax
    63ac:	4c 39 e8             	cmp    %r13,%rax
    63af:	0f 85 87 04 00 00    	jne    683c <w120+0x56c>
    63b5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    63bb:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    63c1:	4d 39 ef             	cmp    %r13,%r15
    63c4:	0f 84 d6 03 00 00    	je     67a0 <w120+0x4d0>
    63ca:	f2 0f 10 1d c6 97 00 	movsd  0x97c6(%rip),%xmm3        # fb98 <msg.4+0x28>
    63d1:	00 
    63d2:	f2 0f 10 25 c6 97 00 	movsd  0x97c6(%rip),%xmm4        # fba0 <msg.4+0x30>
    63d9:	00 
    63da:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    63e0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    63e6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    63ec:	4c 89 ef             	mov    %r13,%rdi
    63ef:	e8 dc e2 ff ff       	call   46d0 <fwp_tape_of>
    63f4:	48 89 c3             	mov    %rax,%rbx
    63f7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63fc:	0f 85 66 04 00 00    	jne    6868 <w120+0x598>
    6402:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6406:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    640d:	0f 8f 49 04 00 00    	jg     685c <w120+0x58c>
    6413:	44 89 f0             	mov    %r14d,%eax
    6416:	49 39 c7             	cmp    %rax,%r15
    6419:	0f 8e 31 04 00 00    	jle    6850 <w120+0x580>
    641f:	4d 85 e4             	test   %r12,%r12
    6422:	78 0c                	js     6430 <w120+0x160>
    6424:	44 89 e0             	mov    %r12d,%eax
    6427:	49 39 c7             	cmp    %rax,%r15
    642a:	0f 8e 20 04 00 00    	jle    6850 <w120+0x580>
    6430:	4c 89 f9             	mov    %r15,%rcx
    6433:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6437:	48 89 df             	mov    %rbx,%rdi
    643a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    643e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6443:	e8 98 fa ff ff       	call   5ee0 <fwp_tape_reserve>
    6448:	48 8b 43 20          	mov    0x20(%rbx),%rax
    644c:	4d 85 e4             	test   %r12,%r12
    644f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6453:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6458:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    645e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6464:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6468:	48 8b 43 30          	mov    0x30(%rbx),%rax
    646c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6471:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6478:	49 0f 49 c4          	cmovns %r12,%rax
    647c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6480:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6483:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6487:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    648c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6490:	48 85 ed             	test   %rbp,%rbp
    6493:	0f 88 0e 04 00 00    	js     68a7 <w120+0x5d7>
    6499:	48 89 e8             	mov    %rbp,%rax
    649c:	48 c1 f8 20          	sar    $0x20,%rax
    64a0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    64a5:	49 39 c5             	cmp    %rax,%r13
    64a8:	74 1a                	je     64c4 <w120+0x1f4>
    64aa:	48 89 c7             	mov    %rax,%rdi
    64ad:	e8 1e e2 ff ff       	call   46d0 <fwp_tape_of>
    64b2:	48 89 c3             	mov    %rax,%rbx
    64b5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64ba:	0f 85 a8 03 00 00    	jne    6868 <w120+0x598>
    64c0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    64c4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    64cb:	0f 8f 8b 03 00 00    	jg     685c <w120+0x58c>
    64d1:	89 e8                	mov    %ebp,%eax
    64d3:	4c 39 e0             	cmp    %r12,%rax
    64d6:	0f 8d 74 03 00 00    	jge    6850 <w120+0x580>
    64dc:	4c 89 e0             	mov    %r12,%rax
    64df:	48 2b 43 08          	sub    0x8(%rbx),%rax
    64e3:	48 89 df             	mov    %rbx,%rdi
    64e6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    64ea:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    64ef:	e8 ec f9 ff ff       	call   5ee0 <fwp_tape_reserve>
    64f4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    64f9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    64fd:	48 8b 0d 9c 96 00 00 	mov    0x969c(%rip),%rcx        # fba0 <msg.4+0x30>
    6504:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    650a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    650d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6511:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6515:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    651b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    651f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6523:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6527:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    652e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6532:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6537:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    653c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6540:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6547:	ff ff ff 
    654a:	48 21 c5             	and    %rax,%rbp
    654d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6553:	4c 09 e5             	or     %r12,%rbp
    6556:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    655d:	ff ff ff 
    6560:	49 21 c6             	and    %rax,%r14
    6563:	4d 09 fe             	or     %r15,%r14
    6566:	4d 89 f4             	mov    %r14,%r12
    6569:	49 c1 fc 20          	sar    $0x20,%r12
    656d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6572:	74 16                	je     658a <w120+0x2ba>
    6574:	4c 89 e7             	mov    %r12,%rdi
    6577:	e8 54 e1 ff ff       	call   46d0 <fwp_tape_of>
    657c:	48 89 c3             	mov    %rax,%rbx
    657f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6584:	0f 85 de 02 00 00    	jne    6868 <w120+0x598>
    658a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    658e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6595:	0f 8f c1 02 00 00    	jg     685c <w120+0x58c>
    659b:	44 89 f0             	mov    %r14d,%eax
    659e:	49 39 c7             	cmp    %rax,%r15
    65a1:	0f 8e a9 02 00 00    	jle    6850 <w120+0x580>
    65a7:	4d 89 fd             	mov    %r15,%r13
    65aa:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    65ae:	48 89 df             	mov    %rbx,%rdi
    65b1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    65b5:	e8 26 f9 ff ff       	call   5ee0 <fwp_tape_reserve>
    65ba:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65be:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    65c4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    65c8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    65cc:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    65d2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    65d6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    65da:	48 8b 43 38          	mov    0x38(%rbx),%rax
    65de:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    65e4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    65e8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    65ef:	ff ff ff 
    65f2:	49 21 c6             	and    %rax,%r14
    65f5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    65f9:	4d 09 fe             	or     %r15,%r14
    65fc:	4d 89 f7             	mov    %r14,%r15
    65ff:	49 c1 ff 20          	sar    $0x20,%r15
    6603:	4d 39 e7             	cmp    %r12,%r15
    6606:	74 1d                	je     6625 <w120+0x355>
    6608:	4c 89 ff             	mov    %r15,%rdi
    660b:	e8 c0 e0 ff ff       	call   46d0 <fwp_tape_of>
    6610:	48 89 c3             	mov    %rax,%rbx
    6613:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6618:	0f 85 4a 02 00 00    	jne    6868 <w120+0x598>
    661e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6622:	4d 89 fc             	mov    %r15,%r12
    6625:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    662c:	0f 8f 2a 02 00 00    	jg     685c <w120+0x58c>
    6632:	44 89 f0             	mov    %r14d,%eax
    6635:	4c 39 e8             	cmp    %r13,%rax
    6638:	0f 8d 12 02 00 00    	jge    6850 <w120+0x580>
    663e:	f2 0f 10 3d 62 95 00 	movsd  0x9562(%rip),%xmm7        # fba8 <msg.4+0x38>
    6645:	00 
    6646:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    664c:	4d 89 ef             	mov    %r13,%r15
    664f:	48 89 df             	mov    %rbx,%rdi
    6652:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6658:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    665d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6661:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6665:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    666a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6670:	e8 6b f8 ff ff       	call   5ee0 <fwp_tape_reserve>
    6675:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6679:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    667e:	48 8b 15 23 95 00 00 	mov    0x9523(%rip),%rdx        # fba8 <msg.4+0x38>
    6685:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6689:	48 8b 43 30          	mov    0x30(%rbx),%rax
    668d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6691:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6695:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6699:	48 8b 43 28          	mov    0x28(%rbx),%rax
    669d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    66a4:	ff 
    66a5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    66a9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    66b0:	00 
    66b1:	49 8d 45 01          	lea    0x1(%r13),%rax
    66b5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    66b9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66c0:	ff ff ff 
    66c3:	49 21 c6             	and    %rax,%r14
    66c6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    66cc:	4d 09 ee             	or     %r13,%r14
    66cf:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    66d3:	0f 84 57 01 00 00    	je     6830 <w120+0x560>
    66d9:	48 89 ef             	mov    %rbp,%rdi
    66dc:	48 c1 ff 20          	sar    $0x20,%rdi
    66e0:	4c 39 e7             	cmp    %r12,%rdi
    66e3:	74 13                	je     66f8 <w120+0x428>
    66e5:	e8 e6 df ff ff       	call   46d0 <fwp_tape_of>
    66ea:	48 89 c3             	mov    %rax,%rbx
    66ed:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    66f2:	0f 85 70 01 00 00    	jne    6868 <w120+0x598>
    66f8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    66fc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6703:	0f 8f 53 01 00 00    	jg     685c <w120+0x58c>
    6709:	89 e8                	mov    %ebp,%eax
    670b:	4c 39 e0             	cmp    %r12,%rax
    670e:	0f 8d 3c 01 00 00    	jge    6850 <w120+0x580>
    6714:	4d 89 e5             	mov    %r12,%r13
    6717:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    671b:	48 89 df             	mov    %rbx,%rdi
    671e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6722:	e8 b9 f7 ff ff       	call   5ee0 <fwp_tape_reserve>
    6727:	48 8b 43 20          	mov    0x20(%rbx),%rax
    672b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6730:	48 89 ef             	mov    %rbp,%rdi
    6733:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6737:	48 8b 43 30          	mov    0x30(%rbx),%rax
    673b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6741:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6745:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6749:	48 8b 43 38          	mov    0x38(%rbx),%rax
    674d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6753:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6758:	48 89 43 10          	mov    %rax,0x10(%rbx)
    675c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6763:	ff ff ff 
    6766:	48 21 c7             	and    %rax,%rdi
    6769:	4c 09 e7             	or     %r12,%rdi
    676c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6772:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6778:	4c 89 f6             	mov    %r14,%rsi
    677b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6780:	e8 cb f9 ff ff       	call   6150 <f141.constprop.0>
    6785:	48 83 c4 38          	add    $0x38,%rsp
    6789:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    678e:	5b                   	pop    %rbx
    678f:	5d                   	pop    %rbp
    6790:	41 5c                	pop    %r12
    6792:	41 5d                	pop    %r13
    6794:	41 5e                	pop    %r14
    6796:	41 5f                	pop    %r15
    6798:	c3                   	ret
    6799:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    67a0:	f2 0f 10 3d f0 93 00 	movsd  0x93f0(%rip),%xmm7        # fb98 <msg.4+0x28>
    67a7:	00 
    67a8:	f2 0f 10 15 f0 93 00 	movsd  0x93f0(%rip),%xmm2        # fba0 <msg.4+0x30>
    67af:	00 
    67b0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    67b6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    67bc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    67c2:	e9 3b fc ff ff       	jmp    6402 <w120+0x132>
    67c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    67ce:	00 00 
    67d0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    67d6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67dc:	48 85 f6             	test   %rsi,%rsi
    67df:	0f 89 8f 00 00 00    	jns    6874 <w120+0x5a4>
    67e5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    67eb:	f2 0f 10 05 a5 93 00 	movsd  0x93a5(%rip),%xmm0        # fb98 <msg.4+0x28>
    67f2:	00 
    67f3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    67fa:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6801:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6806:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    680a:	f2 0f 59 0d 96 93 00 	mulsd  0x9396(%rip),%xmm1        # fba8 <msg.4+0x38>
    6811:	00 
    6812:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6816:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    681c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6822:	e9 45 ff ff ff       	jmp    676c <w120+0x49c>
    6827:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    682e:	00 00 
    6830:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6837:	e9 30 ff ff ff       	jmp    676c <w120+0x49c>
    683c:	48 8d 3d 75 90 00 00 	lea    0x9075(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    6843:	e8 a8 db ff ff       	call   43f0 <fwp_trap>
    6848:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    684f:	00 
    6850:	48 8d 3d 10 89 00 00 	lea    0x8910(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    6857:	e8 94 db ff ff       	call   43f0 <fwp_trap>
    685c:	48 8d 3d e9 88 00 00 	lea    0x88e9(%rip),%rdi        # f14c <_IO_stdin_used+0x14c>
    6863:	e8 88 db ff ff       	call   43f0 <fwp_trap>
    6868:	48 8d 3d 91 90 00 00 	lea    0x9091(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    686f:	e8 7c db ff ff       	call   43f0 <fwp_trap>
    6874:	f2 0f 10 35 1c 93 00 	movsd  0x931c(%rip),%xmm6        # fb98 <msg.4+0x28>
    687b:	00 
    687c:	49 89 f5             	mov    %rsi,%r13
    687f:	49 89 f6             	mov    %rsi,%r14
    6882:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6889:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6890:	00 00 
    6892:	49 c1 fd 20          	sar    $0x20,%r13
    6896:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    689c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    68a2:	e9 45 fb ff ff       	jmp    63ec <w120+0x11c>
    68a7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    68ad:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    68b2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    68b9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    68bd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    68c1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    68c7:	e9 8a fc ff ff       	jmp    6556 <w120+0x286>
    68cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000068d0 <fwp_rc_share>:
    68d0:	48 8b 05 c1 e2 01 00 	mov    0x1e2c1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    68d7:	48 2b 3d 92 e2 01 00 	sub    0x1e292(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    68de:	48 c1 e0 10          	shl    $0x10,%rax
    68e2:	48 39 c7             	cmp    %rax,%rdi
    68e5:	73 4a                	jae    6931 <fwp_rc_share+0x61>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 c1 e8 10          	shr    $0x10,%rax
    68ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f2:	48 8b 05 bf e2 01 00 	mov    0x1e2bf(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    68f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    68fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6901:	48 85 d2             	test   %rdx,%rdx
    6904:	74 2b                	je     6931 <fwp_rc_share+0x61>
    6906:	0f b6 08             	movzbl (%rax),%ecx
    6909:	80 f9 02             	cmp    $0x2,%cl
    690c:	74 2a                	je     6938 <fwp_rc_share+0x68>
    690e:	80 f9 01             	cmp    $0x1,%cl
    6911:	75 1e                	jne    6931 <fwp_rc_share+0x61>
    6913:	8b 48 18             	mov    0x18(%rax),%ecx
    6916:	0f b7 ff             	movzwl %di,%edi
    6919:	8b 40 1c             	mov    0x1c(%rax),%eax
    691c:	48 0f af f9          	imul   %rcx,%rdi
    6920:	48 c1 ef 20          	shr    $0x20,%rdi
    6924:	48 39 c7             	cmp    %rax,%rdi
    6927:	73 08                	jae    6931 <fwp_rc_share+0x61>
    6929:	48 01 fa             	add    %rdi,%rdx
    692c:	80 3a 00             	cmpb   $0x0,(%rdx)
    692f:	75 0d                	jne    693e <fwp_rc_share+0x6e>
    6931:	c3                   	ret
    6932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6938:	66 85 ff             	test   %di,%di
    693b:	74 ef                	je     692c <fwp_rc_share+0x5c>
    693d:	c3                   	ret
    693e:	50                   	push   %rax
    693f:	48 8d 3d ea 8f 00 00 	lea    0x8fea(%rip),%rdi        # f930 <_IO_stdin_used+0x930>
    6946:	e8 a5 da ff ff       	call   43f0 <fwp_trap>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006950 <fwp_rc_fresh>:
    6950:	48 8b 15 41 e2 01 00 	mov    0x1e241(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 89 fe             	mov    %rdi,%rsi
    695d:	48 2b 05 0c e2 01 00 	sub    0x1e20c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6964:	48 c1 e2 10          	shl    $0x10,%rdx
    6968:	48 39 d0             	cmp    %rdx,%rax
    696b:	73 4f                	jae    69bc <fwp_rc_fresh+0x6c>
    696d:	48 89 c2             	mov    %rax,%rdx
    6970:	48 c1 ea 10          	shr    $0x10,%rdx
    6974:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6978:	48 8b 15 39 e2 01 00 	mov    0x1e239(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    697f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6983:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6987:	48 85 d2             	test   %rdx,%rdx
    698a:	74 30                	je     69bc <fwp_rc_fresh+0x6c>
    698c:	0f b6 39             	movzbl (%rcx),%edi
    698f:	40 80 ff 02          	cmp    $0x2,%dil
    6993:	74 2b                	je     69c0 <fwp_rc_fresh+0x70>
    6995:	40 80 ff 01          	cmp    $0x1,%dil
    6999:	75 21                	jne    69bc <fwp_rc_fresh+0x6c>
    699b:	8b 79 18             	mov    0x18(%rcx),%edi
    699e:	0f b7 c0             	movzwl %ax,%eax
    69a1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    69a4:	48 0f af c7          	imul   %rdi,%rax
    69a8:	48 c1 e8 20          	shr    $0x20,%rax
    69ac:	48 39 c8             	cmp    %rcx,%rax
    69af:	73 0b                	jae    69bc <fwp_rc_fresh+0x6c>
    69b1:	48 01 c2             	add    %rax,%rdx
    69b4:	80 3a ff             	cmpb   $0xff,(%rdx)
    69b7:	74 17                	je     69d0 <fwp_rc_fresh+0x80>
    69b9:	c6 02 01             	movb   $0x1,(%rdx)
    69bc:	48 89 f0             	mov    %rsi,%rax
    69bf:	c3                   	ret
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 ef                	je     69b4 <fwp_rc_fresh+0x64>
    69c5:	48 89 f0             	mov    %rsi,%rax
    69c8:	c3                   	ret
    69c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    69d0:	48 83 ec 18          	sub    $0x18,%rsp
    69d4:	48 89 d7             	mov    %rdx,%rdi
    69d7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    69dc:	48 89 14 24          	mov    %rdx,(%rsp)
    69e0:	e8 6b eb ff ff       	call   5550 <fwp_rc_forget_slot>
    69e5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    69ea:	48 8b 14 24          	mov    (%rsp),%rdx
    69ee:	48 89 f0             	mov    %rsi,%rax
    69f1:	c6 02 01             	movb   $0x1,(%rdx)
    69f4:	48 83 c4 18          	add    $0x18,%rsp
    69f8:	c3                   	ret
    69f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006a00 <fwp_rc_free_obj>:
    6a00:	48 8b 15 91 e1 01 00 	mov    0x1e191(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6a07:	48 89 f8             	mov    %rdi,%rax
    6a0a:	48 2b 05 5f e1 01 00 	sub    0x1e15f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6a11:	48 c1 e2 10          	shl    $0x10,%rdx
    6a15:	48 39 d0             	cmp    %rdx,%rax
    6a18:	73 5b                	jae    6a75 <fwp_rc_free_obj+0x75>
    6a1a:	48 89 c2             	mov    %rax,%rdx
    6a1d:	48 c1 ea 10          	shr    $0x10,%rdx
    6a21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a25:	48 8b 15 8c e1 01 00 	mov    0x1e18c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6a2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6a30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6a34:	48 85 c9             	test   %rcx,%rcx
    6a37:	74 3c                	je     6a75 <fwp_rc_free_obj+0x75>
    6a39:	0f b6 32             	movzbl (%rdx),%esi
    6a3c:	40 80 fe 02          	cmp    $0x2,%sil
    6a40:	74 2e                	je     6a70 <fwp_rc_free_obj+0x70>
    6a42:	40 80 fe 01          	cmp    $0x1,%sil
    6a46:	75 2d                	jne    6a75 <fwp_rc_free_obj+0x75>
    6a48:	8b 72 18             	mov    0x18(%rdx),%esi
    6a4b:	0f b7 c0             	movzwl %ax,%eax
    6a4e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a51:	48 0f af c6          	imul   %rsi,%rax
    6a55:	48 c1 e8 20          	shr    $0x20,%rax
    6a59:	48 39 d0             	cmp    %rdx,%rax
    6a5c:	73 17                	jae    6a75 <fwp_rc_free_obj+0x75>
    6a5e:	48 01 c1             	add    %rax,%rcx
    6a61:	80 39 01             	cmpb   $0x1,(%rcx)
    6a64:	75 0f                	jne    6a75 <fwp_rc_free_obj+0x75>
    6a66:	e9 25 ed ff ff       	jmp    5790 <fwp_mem_free>
    6a6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6a70:	66 85 c0             	test   %ax,%ax
    6a73:	74 ec                	je     6a61 <fwp_rc_free_obj+0x61>
    6a75:	c3                   	ret
    6a76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a7d:	00 00 00 

0000000000006a80 <fwp_rc_dup>:
    6a80:	f3 0f 1e fa          	endbr64
    6a84:	48 8b 05 0d e1 01 00 	mov    0x1e10d(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    6a8b:	48 2b 3d de e0 01 00 	sub    0x1e0de(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    6a92:	48 c1 e0 10          	shl    $0x10,%rax
    6a96:	48 39 c7             	cmp    %rax,%rdi
    6a99:	73 56                	jae    6af1 <fwp_rc_dup+0x71>
    6a9b:	48 89 f8             	mov    %rdi,%rax
    6a9e:	48 c1 e8 10          	shr    $0x10,%rax
    6aa2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6aa6:	48 8b 05 0b e1 01 00 	mov    0x1e10b(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    6aad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6ab1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6ab5:	48 85 c0             	test   %rax,%rax
    6ab8:	74 37                	je     6af1 <fwp_rc_dup+0x71>
    6aba:	0f b6 0a             	movzbl (%rdx),%ecx
    6abd:	80 f9 02             	cmp    $0x2,%cl
    6ac0:	74 36                	je     6af8 <fwp_rc_dup+0x78>
    6ac2:	80 f9 01             	cmp    $0x1,%cl
    6ac5:	75 2a                	jne    6af1 <fwp_rc_dup+0x71>
    6ac7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6aca:	0f b7 ff             	movzwl %di,%edi
    6acd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ad0:	48 0f af f9          	imul   %rcx,%rdi
    6ad4:	48 c1 ef 20          	shr    $0x20,%rdi
    6ad8:	48 39 d7             	cmp    %rdx,%rdi
    6adb:	73 14                	jae    6af1 <fwp_rc_dup+0x71>
    6add:	48 01 f8             	add    %rdi,%rax
    6ae0:	0f b6 10             	movzbl (%rax),%edx
    6ae3:	84 d2                	test   %dl,%dl
    6ae5:	74 0a                	je     6af1 <fwp_rc_dup+0x71>
    6ae7:	80 fa fd             	cmp    $0xfd,%dl
    6aea:	77 14                	ja     6b00 <fwp_rc_dup+0x80>
    6aec:	83 c2 01             	add    $0x1,%edx
    6aef:	88 10                	mov    %dl,(%rax)
    6af1:	c3                   	ret
    6af2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af8:	66 85 ff             	test   %di,%di
    6afb:	74 e3                	je     6ae0 <fwp_rc_dup+0x60>
    6afd:	c3                   	ret
    6afe:	66 90                	xchg   %ax,%ax
    6b00:	48 89 c7             	mov    %rax,%rdi
    6b03:	e9 28 e9 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b0f:	00 

0000000000006b10 <fwp_owned_entry173>:
    6b10:	f3 0f 1e fa          	endbr64
    6b14:	48 83 ec 38          	sub    $0x38,%rsp
    6b18:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6b1d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6b24:	00 00 
    6b26:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6b2b:	31 c0                	xor    %eax,%eax
    6b2d:	48 8b 07             	mov    (%rdi),%rax
    6b30:	48 03 47 10          	add    0x10(%rdi),%rax
    6b34:	0f 80 c2 00 00 00    	jo     6bfc <fwp_owned_entry173+0xec>
    6b3a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6b3f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6b44:	31 ff                	xor    %edi,%edi
    6b46:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6b4a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6b4f:	e8 5c f2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6b54:	48 8b 15 3d e0 01 00 	mov    0x1e03d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6b5b:	48 89 c6             	mov    %rax,%rsi
    6b5e:	48 2b 05 0b e0 01 00 	sub    0x1e00b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6b65:	48 c1 e2 10          	shl    $0x10,%rdx
    6b69:	48 39 d0             	cmp    %rdx,%rax
    6b6c:	73 4f                	jae    6bbd <fwp_owned_entry173+0xad>
    6b6e:	48 89 c2             	mov    %rax,%rdx
    6b71:	48 c1 ea 10          	shr    $0x10,%rdx
    6b75:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6b79:	48 8b 15 38 e0 01 00 	mov    0x1e038(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6b80:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6b84:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6b88:	48 85 d2             	test   %rdx,%rdx
    6b8b:	74 30                	je     6bbd <fwp_owned_entry173+0xad>
    6b8d:	0f b6 39             	movzbl (%rcx),%edi
    6b90:	40 80 ff 02          	cmp    $0x2,%dil
    6b94:	74 42                	je     6bd8 <fwp_owned_entry173+0xc8>
    6b96:	40 80 ff 01          	cmp    $0x1,%dil
    6b9a:	75 21                	jne    6bbd <fwp_owned_entry173+0xad>
    6b9c:	8b 79 18             	mov    0x18(%rcx),%edi
    6b9f:	0f b7 c0             	movzwl %ax,%eax
    6ba2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ba5:	48 0f af c7          	imul   %rdi,%rax
    6ba9:	48 c1 e8 20          	shr    $0x20,%rax
    6bad:	48 39 c8             	cmp    %rcx,%rax
    6bb0:	73 0b                	jae    6bbd <fwp_owned_entry173+0xad>
    6bb2:	48 01 c2             	add    %rax,%rdx
    6bb5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6bb8:	74 26                	je     6be0 <fwp_owned_entry173+0xd0>
    6bba:	c6 02 01             	movb   $0x1,(%rdx)
    6bbd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6bc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bc9:	00 00 
    6bcb:	75 34                	jne    6c01 <fwp_owned_entry173+0xf1>
    6bcd:	48 89 f0             	mov    %rsi,%rax
    6bd0:	48 83 c4 38          	add    $0x38,%rsp
    6bd4:	c3                   	ret
    6bd5:	0f 1f 00             	nopl   (%rax)
    6bd8:	66 85 c0             	test   %ax,%ax
    6bdb:	75 e0                	jne    6bbd <fwp_owned_entry173+0xad>
    6bdd:	eb d6                	jmp    6bb5 <fwp_owned_entry173+0xa5>
    6bdf:	90                   	nop
    6be0:	48 89 d7             	mov    %rdx,%rdi
    6be3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6be8:	48 89 14 24          	mov    %rdx,(%rsp)
    6bec:	e8 5f e9 ff ff       	call   5550 <fwp_rc_forget_slot>
    6bf1:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6bf6:	48 8b 14 24          	mov    (%rsp),%rdx
    6bfa:	eb be                	jmp    6bba <fwp_owned_entry173+0xaa>
    6bfc:	e8 ff ca ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6c01:	e8 5a c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c0d:	00 00 00 

0000000000006c10 <e173>:
    6c10:	f3 0f 1e fa          	endbr64
    6c14:	53                   	push   %rbx
    6c15:	48 83 ec 30          	sub    $0x30,%rsp
    6c19:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6c1e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6c25:	00 00 
    6c27:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6c2c:	31 c0                	xor    %eax,%eax
    6c2e:	48 8b 07             	mov    (%rdi),%rax
    6c31:	48 03 47 10          	add    0x10(%rdi),%rax
    6c35:	0f 80 c9 00 00 00    	jo     6d04 <e173+0xf4>
    6c3b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6c40:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6c45:	31 ff                	xor    %edi,%edi
    6c47:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6c4b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6c50:	e8 5b f1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    6c55:	48 8b 15 3c df 01 00 	mov    0x1df3c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6c5c:	48 89 c3             	mov    %rax,%rbx
    6c5f:	48 2b 05 0a df 01 00 	sub    0x1df0a(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6c66:	48 c1 e2 10          	shl    $0x10,%rdx
    6c6a:	48 39 d0             	cmp    %rdx,%rax
    6c6d:	73 4f                	jae    6cbe <e173+0xae>
    6c6f:	48 89 c2             	mov    %rax,%rdx
    6c72:	48 c1 ea 10          	shr    $0x10,%rdx
    6c76:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c7a:	48 8b 15 37 df 01 00 	mov    0x1df37(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6c81:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c85:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c89:	48 85 d2             	test   %rdx,%rdx
    6c8c:	74 30                	je     6cbe <e173+0xae>
    6c8e:	0f b6 31             	movzbl (%rcx),%esi
    6c91:	40 80 fe 02          	cmp    $0x2,%sil
    6c95:	74 49                	je     6ce0 <e173+0xd0>
    6c97:	40 80 fe 01          	cmp    $0x1,%sil
    6c9b:	75 21                	jne    6cbe <e173+0xae>
    6c9d:	8b 71 18             	mov    0x18(%rcx),%esi
    6ca0:	0f b7 c0             	movzwl %ax,%eax
    6ca3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ca6:	48 0f af c6          	imul   %rsi,%rax
    6caa:	48 c1 e8 20          	shr    $0x20,%rax
    6cae:	48 39 c8             	cmp    %rcx,%rax
    6cb1:	73 0b                	jae    6cbe <e173+0xae>
    6cb3:	48 01 c2             	add    %rax,%rdx
    6cb6:	80 3a ff             	cmpb   $0xff,(%rdx)
    6cb9:	74 35                	je     6cf0 <e173+0xe0>
    6cbb:	c6 02 01             	movb   $0x1,(%rdx)
    6cbe:	48 89 df             	mov    %rbx,%rdi
    6cc1:	e8 0a fc ff ff       	call   68d0 <fwp_rc_share>
    6cc6:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6ccb:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6cd2:	00 00 
    6cd4:	75 33                	jne    6d09 <e173+0xf9>
    6cd6:	48 83 c4 30          	add    $0x30,%rsp
    6cda:	48 89 d8             	mov    %rbx,%rax
    6cdd:	5b                   	pop    %rbx
    6cde:	c3                   	ret
    6cdf:	90                   	nop
    6ce0:	66 85 c0             	test   %ax,%ax
    6ce3:	75 d9                	jne    6cbe <e173+0xae>
    6ce5:	eb cf                	jmp    6cb6 <e173+0xa6>
    6ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6cee:	00 00 
    6cf0:	48 89 d7             	mov    %rdx,%rdi
    6cf3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cf8:	e8 53 e8 ff ff       	call   5550 <fwp_rc_forget_slot>
    6cfd:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d02:	eb b7                	jmp    6cbb <e173+0xab>
    6d04:	e8 f7 c9 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6d09:	e8 52 c7 ff ff       	call   3460 <__stack_chk_fail@plt>
    6d0e:	66 90                	xchg   %ax,%ax

0000000000006d10 <fwp_closure_drop>:
    6d10:	48 8b 15 81 de 01 00 	mov    0x1de81(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    6d17:	48 89 f8             	mov    %rdi,%rax
    6d1a:	48 2b 05 4f de 01 00 	sub    0x1de4f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    6d21:	48 c1 e2 10          	shl    $0x10,%rdx
    6d25:	48 39 d0             	cmp    %rdx,%rax
    6d28:	73 6b                	jae    6d95 <fwp_closure_drop+0x85>
    6d2a:	48 89 c2             	mov    %rax,%rdx
    6d2d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d35:	48 8b 15 7c de 01 00 	mov    0x1de7c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    6d3c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d40:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d44:	48 85 d2             	test   %rdx,%rdx
    6d47:	74 4c                	je     6d95 <fwp_closure_drop+0x85>
    6d49:	0f b6 31             	movzbl (%rcx),%esi
    6d4c:	40 80 fe 02          	cmp    $0x2,%sil
    6d50:	74 3e                	je     6d90 <fwp_closure_drop+0x80>
    6d52:	40 80 fe 01          	cmp    $0x1,%sil
    6d56:	75 3d                	jne    6d95 <fwp_closure_drop+0x85>
    6d58:	8b 71 18             	mov    0x18(%rcx),%esi
    6d5b:	0f b7 c0             	movzwl %ax,%eax
    6d5e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d61:	48 0f af c6          	imul   %rsi,%rax
    6d65:	48 c1 e8 20          	shr    $0x20,%rax
    6d69:	48 39 c8             	cmp    %rcx,%rax
    6d6c:	73 27                	jae    6d95 <fwp_closure_drop+0x85>
    6d6e:	48 01 c2             	add    %rax,%rdx
    6d71:	0f b6 02             	movzbl (%rdx),%eax
    6d74:	84 c0                	test   %al,%al
    6d76:	74 1d                	je     6d95 <fwp_closure_drop+0x85>
    6d78:	3c 01                	cmp    $0x1,%al
    6d7a:	74 24                	je     6da0 <fwp_closure_drop+0x90>
    6d7c:	3c ff                	cmp    $0xff,%al
    6d7e:	74 48                	je     6dc8 <fwp_closure_drop+0xb8>
    6d80:	83 e8 01             	sub    $0x1,%eax
    6d83:	88 02                	mov    %al,(%rdx)
    6d85:	c3                   	ret
    6d86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d8d:	00 00 00 
    6d90:	66 85 c0             	test   %ax,%ax
    6d93:	74 dc                	je     6d71 <fwp_closure_drop+0x61>
    6d95:	c3                   	ret
    6d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d9d:	00 00 00 
    6da0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6da7:	ff ff 
    6da9:	48 85 c0             	test   %rax,%rax
    6dac:	74 12                	je     6dc0 <fwp_closure_drop+0xb0>
    6dae:	48 89 fe             	mov    %rdi,%rsi
    6db1:	48 89 c7             	mov    %rax,%rdi
    6db4:	e9 97 d6 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dc0:	e9 3b d8 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6dc5:	0f 1f 00             	nopl   (%rax)
    6dc8:	48 89 d0             	mov    %rdx,%rax
    6dcb:	48 8d 35 ee c9 01 00 	lea    0x1c9ee(%rip),%rsi        # 237c0 <fwp_heap>
    6dd2:	48 83 ec 18          	sub    $0x18,%rsp
    6dd6:	48 c1 e8 11          	shr    $0x11,%rax
    6dda:	48 31 d0             	xor    %rdx,%rax
    6ddd:	48 89 c1             	mov    %rax,%rcx
    6de0:	48 c1 e9 09          	shr    $0x9,%rcx
    6de4:	48 31 c8             	xor    %rcx,%rax
    6de7:	0f b6 c8             	movzbl %al,%ecx
    6dea:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6df1:	00 
    6df2:	48 85 c0             	test   %rax,%rax
    6df5:	75 12                	jne    6e09 <fwp_closure_drop+0xf9>
    6df7:	eb 49                	jmp    6e42 <fwp_closure_drop+0x132>
    6df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e04:	48 85 c0             	test   %rax,%rax
    6e07:	74 39                	je     6e42 <fwp_closure_drop+0x132>
    6e09:	48 89 c1             	mov    %rax,%rcx
    6e0c:	48 39 10             	cmp    %rdx,(%rax)
    6e0f:	75 ef                	jne    6e00 <fwp_closure_drop+0xf0>
    6e11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e24:	74 05                	je     6e2b <fwp_closure_drop+0x11b>
    6e26:	48 83 c4 18          	add    $0x18,%rsp
    6e2a:	c3                   	ret
    6e2b:	48 89 d7             	mov    %rdx,%rdi
    6e2e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e33:	e8 18 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6e38:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e3d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e40:	eb e4                	jmp    6e26 <fwp_closure_drop+0x116>
    6e42:	48 8d 3d 47 8a 00 00 	lea    0x8a47(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    6e49:	e8 a2 d5 ff ff       	call   43f0 <fwp_trap>
    6e4e:	66 90                	xchg   %ax,%ax

0000000000006e50 <fwp_owned_tape_release>:
    6e50:	48 85 ff             	test   %rdi,%rdi
    6e53:	0f 84 f7 00 00 00    	je     6f50 <fwp_owned_tape_release+0x100>
    6e59:	41 54                	push   %r12
    6e5b:	55                   	push   %rbp
    6e5c:	53                   	push   %rbx
    6e5d:	48 8b 07             	mov    (%rdi),%rax
    6e60:	48 85 c0             	test   %rax,%rax
    6e63:	74 08                	je     6e6d <fwp_owned_tape_release+0x1d>
    6e65:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e69:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e6d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e71:	48 85 d2             	test   %rdx,%rdx
    6e74:	74 03                	je     6e79 <fwp_owned_tape_release+0x29>
    6e76:	48 89 02             	mov    %rax,(%rdx)
    6e79:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6e7d:	48 89 fb             	mov    %rdi,%rbx
    6e80:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6e84:	48 85 c0             	test   %rax,%rax
    6e87:	0f 84 89 00 00 00    	je     6f16 <fwp_owned_tape_release+0xc6>
    6e8d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6e91:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6e95:	7e 47                	jle    6ede <fwp_owned_tape_release+0x8e>
    6e97:	31 ed                	xor    %ebp,%ebp
    6e99:	eb 0d                	jmp    6ea8 <fwp_owned_tape_release+0x58>
    6e9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ea0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ea4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ea8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6eac:	49 89 ec             	mov    %rbp,%r12
    6eaf:	48 83 c5 01          	add    $0x1,%rbp
    6eb3:	49 c1 e4 04          	shl    $0x4,%r12
    6eb7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6ebb:	ff d0                	call   *%rax
    6ebd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6ec1:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6ec6:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6eca:	ff 50 68             	call   *0x68(%rax)
    6ecd:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6ed1:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6ed5:	48 39 e8             	cmp    %rbp,%rax
    6ed8:	7f c6                	jg     6ea0 <fwp_owned_tape_release+0x50>
    6eda:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ede:	31 ed                	xor    %ebp,%ebp
    6ee0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6ee5:	7e 28                	jle    6f0f <fwp_owned_tape_release+0xbf>
    6ee7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6eee:	00 00 
    6ef0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6ef4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6ef8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6efc:	74 07                	je     6f05 <fwp_owned_tape_release+0xb5>
    6efe:	ff 52 68             	call   *0x68(%rdx)
    6f01:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f05:	48 83 c5 01          	add    $0x1,%rbp
    6f09:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6f0d:	7f e1                	jg     6ef0 <fwp_owned_tape_release+0xa0>
    6f0f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f13:	ff 52 68             	call   *0x68(%rdx)
    6f16:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6f1a:	e8 f1 fd ff ff       	call   6d10 <fwp_closure_drop>
    6f1f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6f23:	e8 e8 fd ff ff       	call   6d10 <fwp_closure_drop>
    6f28:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6f2c:	e8 df fd ff ff       	call   6d10 <fwp_closure_drop>
    6f31:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6f35:	e8 56 e8 ff ff       	call   5790 <fwp_mem_free>
    6f3a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6f3e:	e8 4d e8 ff ff       	call   5790 <fwp_mem_free>
    6f43:	48 89 df             	mov    %rbx,%rdi
    6f46:	5b                   	pop    %rbx
    6f47:	5d                   	pop    %rbp
    6f48:	41 5c                	pop    %r12
    6f4a:	e9 41 e8 ff ff       	jmp    5790 <fwp_mem_free>
    6f4f:	90                   	nop
    6f50:	c3                   	ret
    6f51:	0f 1f 40 00          	nopl   0x0(%rax)
    6f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f5c:	00 00 00 00 

0000000000006f60 <fwp_tape_finish>:
    6f60:	f3 0f 1e fa          	endbr64
    6f64:	41 56                	push   %r14
    6f66:	48 8d 3d 33 c1 01 00 	lea    0x1c133(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    6f6d:	41 55                	push   %r13
    6f6f:	41 54                	push   %r12
    6f71:	55                   	push   %rbp
    6f72:	53                   	push   %rbx
    6f73:	e8 98 d1 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6f78:	48 83 3d 68 c1 01 00 	cmpq   $0x0,0x1c168(%rip)        # 230e8 <fwp_ntapes>
    6f7f:	00 
    6f80:	48 c7 05 fd c0 01 00 	movq   $0x0,0x1c0fd(%rip)        # 23088 <fwp_tape_cached_bytes>
    6f87:	00 00 00 00 
    6f8b:	7e 68                	jle    6ff5 <fwp_tape_finish+0x95>
    6f8d:	45 31 e4             	xor    %r12d,%r12d
    6f90:	31 ed                	xor    %ebp,%ebp
    6f92:	0f 1f 00             	nopl   (%rax)
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 
    6fa0:	48 8b 1d 49 c1 01 00 	mov    0x1c149(%rip),%rbx        # 230f0 <fwp_tapes>
    6fa7:	48 83 c5 01          	add    $0x1,%rbp
    6fab:	4c 01 e3             	add    %r12,%rbx
    6fae:	49 83 c4 68          	add    $0x68,%r12
    6fb2:	48 89 df             	mov    %rbx,%rdi
    6fb5:	e8 46 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6fba:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6fbe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6fc2:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6fc6:	e8 f5 c3 ff ff       	call   33c0 <free@plt>
    6fcb:	4c 89 f7             	mov    %r14,%rdi
    6fce:	e8 ed c3 ff ff       	call   33c0 <free@plt>
    6fd3:	4c 89 ef             	mov    %r13,%rdi
    6fd6:	e8 e5 c3 ff ff       	call   33c0 <free@plt>
    6fdb:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6fdf:	e8 6c fe ff ff       	call   6e50 <fwp_owned_tape_release>
    6fe4:	48 39 2d fd c0 01 00 	cmp    %rbp,0x1c0fd(%rip)        # 230e8 <fwp_ntapes>
    6feb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6ff2:	00 
    6ff3:	7f ab                	jg     6fa0 <fwp_tape_finish+0x40>
    6ff5:	48 8b 3d f4 c0 01 00 	mov    0x1c0f4(%rip),%rdi        # 230f0 <fwp_tapes>
    6ffc:	e8 bf c3 ff ff       	call   33c0 <free@plt>
    7001:	5b                   	pop    %rbx
    7002:	5d                   	pop    %rbp
    7003:	48 c7 05 e2 c0 01 00 	movq   $0x0,0x1c0e2(%rip)        # 230f0 <fwp_tapes>
    700a:	00 00 00 00 
    700e:	48 c7 05 c7 c0 01 00 	movq   $0x0,0x1c0c7(%rip)        # 230e0 <fwp_tapes_cap>
    7015:	00 00 00 00 
    7019:	41 5c                	pop    %r12
    701b:	48 c7 05 c2 c0 01 00 	movq   $0x0,0x1c0c2(%rip)        # 230e8 <fwp_ntapes>
    7022:	00 00 00 00 
    7026:	41 5d                	pop    %r13
    7028:	48 c7 05 a5 c0 01 00 	movq   $0x0,0x1c0a5(%rip)        # 230d8 <fwp_tape_next_slot>
    702f:	00 00 00 00 
    7033:	41 5e                	pop    %r14
    7035:	c3                   	ret
    7036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    703d:	00 00 00 

0000000000007040 <fwp_tape_scope_release>:
    7040:	f3 0f 1e fa          	endbr64
    7044:	41 55                	push   %r13
    7046:	41 54                	push   %r12
    7048:	55                   	push   %rbp
    7049:	53                   	push   %rbx
    704a:	48 83 ec 58          	sub    $0x58,%rsp
    704e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7055:	00 00 
    7057:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    705c:	48 63 07             	movslq (%rdi),%rax
    705f:	85 c0                	test   %eax,%eax
    7061:	0f 88 05 01 00 00    	js     716c <fwp_tape_scope_release+0x12c>
    7067:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    706e:	ec c4 4e 
    7071:	48 89 fb             	mov    %rdi,%rbx
    7074:	eb 3c                	jmp    70b2 <fwp_tape_scope_release+0x72>
    7076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    707d:	00 00 00 
    7080:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7085:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7089:	e8 32 c3 ff ff       	call   33c0 <free@plt>
    708e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7092:	e8 29 c3 ff ff       	call   33c0 <free@plt>
    7097:	4c 89 ef             	mov    %r13,%rdi
    709a:	e8 21 c3 ff ff       	call   33c0 <free@plt>
    709f:	4c 89 e7             	mov    %r12,%rdi
    70a2:	e8 a9 fd ff ff       	call   6e50 <fwp_owned_tape_release>
    70a7:	48 63 03             	movslq (%rbx),%rax
    70aa:	85 c0                	test   %eax,%eax
    70ac:	0f 88 ba 00 00 00    	js     716c <fwp_tape_scope_release+0x12c>
    70b2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    70b6:	48 8b 35 33 c0 01 00 	mov    0x1c033(%rip),%rsi        # 230f0 <fwp_tapes>
    70bd:	4c 01 c6             	add    %r8,%rsi
    70c0:	48 89 f7             	mov    %rsi,%rdi
    70c3:	e8 38 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    70c8:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    70cd:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    70d2:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    70d9:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    70dd:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    70e1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    70e8:	00 
    70e9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    70ee:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    70f2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    70f7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    70fb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7100:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7107:	00 
    7108:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    710f:	00 
    7110:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7117:	00 
    7118:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    711d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7122:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7126:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    712a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    712e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7134:	77 18                	ja     714e <fwp_tape_scope_release+0x10e>
    7136:	49 c1 f8 03          	sar    $0x3,%r8
    713a:	4c 0f af c5          	imul   %rbp,%r8
    713e:	4c 3b 05 93 bf 01 00 	cmp    0x1bf93(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    7145:	7d 07                	jge    714e <fwp_tape_scope_release+0x10e>
    7147:	4c 89 05 8a bf 01 00 	mov    %r8,0x1bf8a(%rip)        # 230d8 <fwp_tape_next_slot>
    714e:	4d 85 e4             	test   %r12,%r12
    7151:	0f 85 29 ff ff ff    	jne    7080 <fwp_tape_scope_release+0x40>
    7157:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    715c:	e8 0f df ff ff       	call   5070 <fwp_tape_buffers_release>
    7161:	48 63 03             	movslq (%rbx),%rax
    7164:	85 c0                	test   %eax,%eax
    7166:	0f 89 46 ff ff ff    	jns    70b2 <fwp_tape_scope_release+0x72>
    716c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7171:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7178:	00 00 
    717a:	75 0b                	jne    7187 <fwp_tape_scope_release+0x147>
    717c:	48 83 c4 58          	add    $0x58,%rsp
    7180:	5b                   	pop    %rbx
    7181:	5d                   	pop    %rbp
    7182:	41 5c                	pop    %r12
    7184:	41 5d                	pop    %r13
    7186:	c3                   	ret
    7187:	e8 d4 c2 ff ff       	call   3460 <__stack_chk_fail@plt>
    718c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007190 <fwp_drop4>:
    7190:	48 8b 0d 01 da 01 00 	mov    0x1da01(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7197:	48 89 f8             	mov    %rdi,%rax
    719a:	48 2b 05 cf d9 01 00 	sub    0x1d9cf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    71a1:	48 c1 e1 10          	shl    $0x10,%rcx
    71a5:	48 39 c8             	cmp    %rcx,%rax
    71a8:	0f 83 42 01 00 00    	jae    72f0 <fwp_drop4+0x160>
    71ae:	48 83 ec 18          	sub    $0x18,%rsp
    71b2:	48 89 fa             	mov    %rdi,%rdx
    71b5:	4c 8d 05 04 c6 01 00 	lea    0x1c604(%rip),%r8        # 237c0 <fwp_heap>
    71bc:	48 89 c1             	mov    %rax,%rcx
    71bf:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    71c6:	48 c1 e9 10          	shr    $0x10,%rcx
    71ca:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    71ce:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    71d2:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    71d6:	48 85 c9             	test   %rcx,%rcx
    71d9:	74 40                	je     721b <fwp_drop4+0x8b>
    71db:	0f b6 3e             	movzbl (%rsi),%edi
    71de:	40 80 ff 02          	cmp    $0x2,%dil
    71e2:	74 3c                	je     7220 <fwp_drop4+0x90>
    71e4:	40 80 ff 01          	cmp    $0x1,%dil
    71e8:	75 31                	jne    721b <fwp_drop4+0x8b>
    71ea:	8b 7e 18             	mov    0x18(%rsi),%edi
    71ed:	0f b7 c0             	movzwl %ax,%eax
    71f0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    71f3:	48 0f af c7          	imul   %rdi,%rax
    71f7:	48 c1 e8 20          	shr    $0x20,%rax
    71fb:	48 39 f0             	cmp    %rsi,%rax
    71fe:	73 1b                	jae    721b <fwp_drop4+0x8b>
    7200:	48 01 c1             	add    %rax,%rcx
    7203:	0f b6 01             	movzbl (%rcx),%eax
    7206:	84 c0                	test   %al,%al
    7208:	74 11                	je     721b <fwp_drop4+0x8b>
    720a:	3c 01                	cmp    $0x1,%al
    720c:	74 22                	je     7230 <fwp_drop4+0xa0>
    720e:	3c ff                	cmp    $0xff,%al
    7210:	0f 84 0a 01 00 00    	je     7320 <fwp_drop4+0x190>
    7216:	83 e8 01             	sub    $0x1,%eax
    7219:	88 01                	mov    %al,(%rcx)
    721b:	48 83 c4 18          	add    $0x18,%rsp
    721f:	c3                   	ret
    7220:	66 85 c0             	test   %ax,%ax
    7223:	74 de                	je     7203 <fwp_drop4+0x73>
    7225:	48 83 c4 18          	add    $0x18,%rsp
    7229:	c3                   	ret
    722a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7230:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7234:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    723b:	48 89 f8             	mov    %rdi,%rax
    723e:	48 c1 e1 10          	shl    $0x10,%rcx
    7242:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7249:	48 39 c8             	cmp    %rcx,%rax
    724c:	73 62                	jae    72b0 <fwp_drop4+0x120>
    724e:	48 89 c1             	mov    %rax,%rcx
    7251:	48 c1 e9 10          	shr    $0x10,%rcx
    7255:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7259:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    725d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7261:	48 85 c9             	test   %rcx,%rcx
    7264:	74 4a                	je     72b0 <fwp_drop4+0x120>
    7266:	44 0f b6 0e          	movzbl (%rsi),%r9d
    726a:	41 80 f9 02          	cmp    $0x2,%r9b
    726e:	0f 84 9c 00 00 00    	je     7310 <fwp_drop4+0x180>
    7274:	41 80 f9 01          	cmp    $0x1,%r9b
    7278:	75 36                	jne    72b0 <fwp_drop4+0x120>
    727a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    727e:	0f b7 c0             	movzwl %ax,%eax
    7281:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7284:	49 0f af c1          	imul   %r9,%rax
    7288:	48 c1 e8 20          	shr    $0x20,%rax
    728c:	48 39 f0             	cmp    %rsi,%rax
    728f:	73 1f                	jae    72b0 <fwp_drop4+0x120>
    7291:	48 01 c1             	add    %rax,%rcx
    7294:	0f b6 01             	movzbl (%rcx),%eax
    7297:	84 c0                	test   %al,%al
    7299:	74 15                	je     72b0 <fwp_drop4+0x120>
    729b:	3c 01                	cmp    $0x1,%al
    729d:	74 59                	je     72f8 <fwp_drop4+0x168>
    729f:	3c ff                	cmp    $0xff,%al
    72a1:	0f 84 ff 00 00 00    	je     73a6 <fwp_drop4+0x216>
    72a7:	83 e8 01             	sub    $0x1,%eax
    72aa:	88 01                	mov    %al,(%rcx)
    72ac:	0f 1f 40 00          	nopl   0x0(%rax)
    72b0:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    72b4:	48 89 d7             	mov    %rdx,%rdi
    72b7:	48 89 0c 24          	mov    %rcx,(%rsp)
    72bb:	e8 40 f7 ff ff       	call   6a00 <fwp_rc_free_obj>
    72c0:	4c 8d 05 f9 c4 01 00 	lea    0x1c4f9(%rip),%r8        # 237c0 <fwp_heap>
    72c7:	48 8b 04 24          	mov    (%rsp),%rax
    72cb:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    72d2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    72d9:	48 c1 e2 10          	shl    $0x10,%rdx
    72dd:	48 39 d0             	cmp    %rdx,%rax
    72e0:	0f 83 35 ff ff ff    	jae    721b <fwp_drop4+0x8b>
    72e6:	48 8b 14 24          	mov    (%rsp),%rdx
    72ea:	e9 cd fe ff ff       	jmp    71bc <fwp_drop4+0x2c>
    72ef:	90                   	nop
    72f0:	c3                   	ret
    72f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72f8:	48 89 14 24          	mov    %rdx,(%rsp)
    72fc:	e8 ff f6 ff ff       	call   6a00 <fwp_rc_free_obj>
    7301:	48 8b 14 24          	mov    (%rsp),%rdx
    7305:	eb a9                	jmp    72b0 <fwp_drop4+0x120>
    7307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    730e:	00 00 
    7310:	66 85 c0             	test   %ax,%ax
    7313:	75 9b                	jne    72b0 <fwp_drop4+0x120>
    7315:	e9 7a ff ff ff       	jmp    7294 <fwp_drop4+0x104>
    731a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7320:	48 89 c8             	mov    %rcx,%rax
    7323:	48 c1 e8 11          	shr    $0x11,%rax
    7327:	48 31 c8             	xor    %rcx,%rax
    732a:	48 89 c2             	mov    %rax,%rdx
    732d:	48 c1 ea 09          	shr    $0x9,%rdx
    7331:	48 31 d0             	xor    %rdx,%rax
    7334:	0f b6 d0             	movzbl %al,%edx
    7337:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    733e:	00 
    733f:	48 85 c0             	test   %rax,%rax
    7342:	75 29                	jne    736d <fwp_drop4+0x1dd>
    7344:	e9 e3 00 00 00       	jmp    742c <fwp_drop4+0x29c>
    7349:	90                   	nop
    734a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7351:	00 00 00 00 
    7355:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    735c:	00 00 00 00 
    7360:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7364:	48 85 c0             	test   %rax,%rax
    7367:	0f 84 bf 00 00 00    	je     742c <fwp_drop4+0x29c>
    736d:	48 89 c2             	mov    %rax,%rdx
    7370:	48 39 08             	cmp    %rcx,(%rax)
    7373:	75 eb                	jne    7360 <fwp_drop4+0x1d0>
    7375:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7379:	48 83 ea 01          	sub    $0x1,%rdx
    737d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7381:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7388:	0f 85 8d fe ff ff    	jne    721b <fwp_drop4+0x8b>
    738e:	48 89 cf             	mov    %rcx,%rdi
    7391:	48 89 0c 24          	mov    %rcx,(%rsp)
    7395:	e8 b6 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    739a:	48 8b 0c 24          	mov    (%rsp),%rcx
    739e:	c6 01 fe             	movb   $0xfe,(%rcx)
    73a1:	e9 75 fe ff ff       	jmp    721b <fwp_drop4+0x8b>
    73a6:	48 89 ce             	mov    %rcx,%rsi
    73a9:	48 c1 ee 11          	shr    $0x11,%rsi
    73ad:	48 31 ce             	xor    %rcx,%rsi
    73b0:	48 89 f0             	mov    %rsi,%rax
    73b3:	48 c1 e8 09          	shr    $0x9,%rax
    73b7:	48 31 c6             	xor    %rax,%rsi
    73ba:	40 0f b6 f6          	movzbl %sil,%esi
    73be:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    73c5:	00 
    73c6:	48 85 c0             	test   %rax,%rax
    73c9:	75 1e                	jne    73e9 <fwp_drop4+0x259>
    73cb:	eb 5f                	jmp    742c <fwp_drop4+0x29c>
    73cd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73d4:	00 
    73d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73dc:	00 00 00 00 
    73e0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    73e4:	48 85 c0             	test   %rax,%rax
    73e7:	74 43                	je     742c <fwp_drop4+0x29c>
    73e9:	48 89 c6             	mov    %rax,%rsi
    73ec:	48 39 08             	cmp    %rcx,(%rax)
    73ef:	75 ef                	jne    73e0 <fwp_drop4+0x250>
    73f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73f5:	48 83 ee 01          	sub    $0x1,%rsi
    73f9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    73fd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7404:	0f 85 a6 fe ff ff    	jne    72b0 <fwp_drop4+0x120>
    740a:	48 89 cf             	mov    %rcx,%rdi
    740d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7412:	48 89 0c 24          	mov    %rcx,(%rsp)
    7416:	e8 35 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    741b:	48 8b 0c 24          	mov    (%rsp),%rcx
    741f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7424:	c6 01 fe             	movb   $0xfe,(%rcx)
    7427:	e9 84 fe ff ff       	jmp    72b0 <fwp_drop4+0x120>
    742c:	48 8d 3d 5d 84 00 00 	lea    0x845d(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7433:	e8 b8 cf ff ff       	call   43f0 <fwp_trap>
    7438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    743f:	00 

0000000000007440 <fwp_arg_drop37>:
    7440:	f3 0f 1e fa          	endbr64
    7444:	85 f6                	test   %esi,%esi
    7446:	75 04                	jne    744c <fwp_arg_drop37+0xc>
    7448:	85 d2                	test   %edx,%edx
    744a:	75 04                	jne    7450 <fwp_arg_drop37+0x10>
    744c:	c3                   	ret
    744d:	0f 1f 00             	nopl   (%rax)
    7450:	48 8b 3f             	mov    (%rdi),%rdi
    7453:	e9 38 fd ff ff       	jmp    7190 <fwp_drop4>
    7458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    745f:	00 

0000000000007460 <fwp_task_dispose>:
    7460:	53                   	push   %rbx
    7461:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7465:	0f 84 db c2 ff ff    	je     3746 <fwp_task_dispose.cold>
    746b:	48 89 fb             	mov    %rdi,%rbx
    746e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7473:	0f 85 cd c2 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7479:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    747d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7484:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    748b:	00 
    748c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7490:	48 85 ff             	test   %rdi,%rdi
    7493:	74 07                	je     749c <fwp_task_dispose+0x3c>
    7495:	48 85 c0             	test   %rax,%rax
    7498:	74 02                	je     749c <fwp_task_dispose+0x3c>
    749a:	ff d0                	call   *%rax
    749c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    74a3:	e8 e8 e2 ff ff       	call   5790 <fwp_mem_free>
    74a8:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    74af:	00 00 00 00 
    74b3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    74b7:	74 6f                	je     7528 <fwp_task_dispose+0xc8>
    74b9:	48 8b 15 d8 d6 01 00 	mov    0x1d6d8(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    74c0:	48 89 d8             	mov    %rbx,%rax
    74c3:	48 2b 05 a6 d6 01 00 	sub    0x1d6a6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    74ca:	48 c1 e2 10          	shl    $0x10,%rdx
    74ce:	48 39 d0             	cmp    %rdx,%rax
    74d1:	73 4c                	jae    751f <fwp_task_dispose+0xbf>
    74d3:	48 89 c2             	mov    %rax,%rdx
    74d6:	48 c1 ea 10          	shr    $0x10,%rdx
    74da:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    74de:	48 8b 15 d3 d6 01 00 	mov    0x1d6d3(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    74e5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    74e9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    74ed:	48 85 c9             	test   %rcx,%rcx
    74f0:	74 2d                	je     751f <fwp_task_dispose+0xbf>
    74f2:	0f b6 32             	movzbl (%rdx),%esi
    74f5:	40 80 fe 02          	cmp    $0x2,%sil
    74f9:	74 3d                	je     7538 <fwp_task_dispose+0xd8>
    74fb:	40 80 fe 01          	cmp    $0x1,%sil
    74ff:	75 1e                	jne    751f <fwp_task_dispose+0xbf>
    7501:	8b 72 18             	mov    0x18(%rdx),%esi
    7504:	0f b7 c0             	movzwl %ax,%eax
    7507:	8b 52 1c             	mov    0x1c(%rdx),%edx
    750a:	48 0f af c6          	imul   %rsi,%rax
    750e:	48 c1 e8 20          	shr    $0x20,%rax
    7512:	48 39 d0             	cmp    %rdx,%rax
    7515:	73 08                	jae    751f <fwp_task_dispose+0xbf>
    7517:	48 01 c1             	add    %rax,%rcx
    751a:	80 39 01             	cmpb   $0x1,(%rcx)
    751d:	74 09                	je     7528 <fwp_task_dispose+0xc8>
    751f:	5b                   	pop    %rbx
    7520:	c3                   	ret
    7521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7528:	48 89 df             	mov    %rbx,%rdi
    752b:	5b                   	pop    %rbx
    752c:	e9 5f e2 ff ff       	jmp    5790 <fwp_mem_free>
    7531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7538:	66 85 c0             	test   %ax,%ax
    753b:	74 dd                	je     751a <fwp_task_dispose+0xba>
    753d:	5b                   	pop    %rbx
    753e:	c3                   	ret
    753f:	90                   	nop

0000000000007540 <fwp_free_zombie>:
    7540:	48 8b 15 49 c2 01 00 	mov    0x1c249(%rip),%rdx        # 23790 <fwp_zombie>
    7547:	48 85 d2             	test   %rdx,%rdx
    754a:	0f 84 98 00 00 00    	je     75e8 <fwp_free_zombie+0xa8>
    7550:	48 3b 15 49 c2 01 00 	cmp    0x1c249(%rip),%rdx        # 237a0 <fwp_cur>
    7557:	0f 84 8b 00 00 00    	je     75e8 <fwp_free_zombie+0xa8>
    755d:	48 83 ec 18          	sub    $0x18,%rsp
    7561:	48 63 05 fc bb 01 00 	movslq 0x1bbfc(%rip),%rax        # 23164 <fwp_stack_pool_n>
    7568:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    756c:	83 f8 3f             	cmp    $0x3f,%eax
    756f:	7f 7f                	jg     75f0 <fwp_free_zombie+0xb0>
    7571:	8d 48 01             	lea    0x1(%rax),%ecx
    7574:	89 0d ea bb 01 00    	mov    %ecx,0x1bbea(%rip)        # 23164 <fwp_stack_pool_n>
    757a:	48 8d 0d ff bb 01 00 	lea    0x1bbff(%rip),%rcx        # 23180 <fwp_stack_pool>
    7581:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7585:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    758c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7590:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7597:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    759b:	48 85 c9             	test   %rcx,%rcx
    759e:	0f 84 fc 00 00 00    	je     76a0 <fwp_free_zombie+0x160>
    75a4:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    75ab:	48 85 c0             	test   %rax,%rax
    75ae:	74 07                	je     75b7 <fwp_free_zombie+0x77>
    75b0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    75b7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    75ba:	66 0f ef c0          	pxor   %xmm0,%xmm0
    75be:	48 c7 05 c7 c1 01 00 	movq   $0x0,0x1c1c7(%rip)        # 23790 <fwp_zombie>
    75c5:	00 00 00 00 
    75c9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    75d0:	85 c0                	test   %eax,%eax
    75d2:	74 34                	je     7608 <fwp_free_zombie+0xc8>
    75d4:	83 f8 01             	cmp    $0x1,%eax
    75d7:	0f 84 b3 00 00 00    	je     7690 <fwp_free_zombie+0x150>
    75dd:	48 83 c4 18          	add    $0x18,%rsp
    75e1:	c3                   	ret
    75e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75e8:	c3                   	ret
    75e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75f0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    75f4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75f9:	e8 e2 bf ff ff       	call   35e0 <munmap@plt>
    75fe:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7603:	eb 80                	jmp    7585 <fwp_free_zombie+0x45>
    7605:	0f 1f 00             	nopl   (%rax)
    7608:	48 8b 0d 89 d5 01 00 	mov    0x1d589(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    760f:	48 89 d0             	mov    %rdx,%rax
    7612:	48 2b 05 57 d5 01 00 	sub    0x1d557(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7619:	48 c1 e1 10          	shl    $0x10,%rcx
    761d:	48 39 c8             	cmp    %rcx,%rax
    7620:	73 bb                	jae    75dd <fwp_free_zombie+0x9d>
    7622:	48 89 c1             	mov    %rax,%rcx
    7625:	48 c1 e9 10          	shr    $0x10,%rcx
    7629:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    762d:	48 8b 0d 84 d5 01 00 	mov    0x1d584(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    7634:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7638:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    763c:	48 85 c9             	test   %rcx,%rcx
    763f:	74 9c                	je     75dd <fwp_free_zombie+0x9d>
    7641:	0f b6 3e             	movzbl (%rsi),%edi
    7644:	40 80 ff 02          	cmp    $0x2,%dil
    7648:	74 66                	je     76b0 <fwp_free_zombie+0x170>
    764a:	40 80 ff 01          	cmp    $0x1,%dil
    764e:	75 8d                	jne    75dd <fwp_free_zombie+0x9d>
    7650:	8b 7e 18             	mov    0x18(%rsi),%edi
    7653:	0f b7 c0             	movzwl %ax,%eax
    7656:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7659:	48 0f af c7          	imul   %rdi,%rax
    765d:	48 c1 e8 20          	shr    $0x20,%rax
    7661:	48 39 f0             	cmp    %rsi,%rax
    7664:	0f 83 73 ff ff ff    	jae    75dd <fwp_free_zombie+0x9d>
    766a:	48 01 c1             	add    %rax,%rcx
    766d:	0f b6 01             	movzbl (%rcx),%eax
    7670:	84 c0                	test   %al,%al
    7672:	0f 84 65 ff ff ff    	je     75dd <fwp_free_zombie+0x9d>
    7678:	3c 01                	cmp    $0x1,%al
    767a:	74 14                	je     7690 <fwp_free_zombie+0x150>
    767c:	3c ff                	cmp    $0xff,%al
    767e:	74 3b                	je     76bb <fwp_free_zombie+0x17b>
    7680:	83 e8 01             	sub    $0x1,%eax
    7683:	88 01                	mov    %al,(%rcx)
    7685:	e9 53 ff ff ff       	jmp    75dd <fwp_free_zombie+0x9d>
    768a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7690:	48 89 d7             	mov    %rdx,%rdi
    7693:	48 83 c4 18          	add    $0x18,%rsp
    7697:	e9 c4 fd ff ff       	jmp    7460 <fwp_task_dispose>
    769c:	0f 1f 40 00          	nopl   0x0(%rax)
    76a0:	48 89 05 c1 c0 01 00 	mov    %rax,0x1c0c1(%rip)        # 23768 <fwp_tasks_active>
    76a7:	e9 ff fe ff ff       	jmp    75ab <fwp_free_zombie+0x6b>
    76ac:	0f 1f 40 00          	nopl   0x0(%rax)
    76b0:	66 85 c0             	test   %ax,%ax
    76b3:	0f 85 24 ff ff ff    	jne    75dd <fwp_free_zombie+0x9d>
    76b9:	eb b2                	jmp    766d <fwp_free_zombie+0x12d>
    76bb:	48 89 ca             	mov    %rcx,%rdx
    76be:	48 8d 35 fb c0 01 00 	lea    0x1c0fb(%rip),%rsi        # 237c0 <fwp_heap>
    76c5:	48 c1 ea 11          	shr    $0x11,%rdx
    76c9:	48 31 ca             	xor    %rcx,%rdx
    76cc:	48 89 d0             	mov    %rdx,%rax
    76cf:	48 c1 e8 09          	shr    $0x9,%rax
    76d3:	48 31 c2             	xor    %rax,%rdx
    76d6:	0f b6 d2             	movzbl %dl,%edx
    76d9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    76e0:	00 
    76e1:	48 85 c0             	test   %rax,%rax
    76e4:	75 23                	jne    7709 <fwp_free_zombie+0x1c9>
    76e6:	eb 5c                	jmp    7744 <fwp_free_zombie+0x204>
    76e8:	66 90                	xchg   %ax,%ax
    76ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76f1:	00 00 00 00 
    76f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76fc:	00 00 00 00 
    7700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7704:	48 85 c0             	test   %rax,%rax
    7707:	74 3b                	je     7744 <fwp_free_zombie+0x204>
    7709:	48 89 c2             	mov    %rax,%rdx
    770c:	48 39 08             	cmp    %rcx,(%rax)
    770f:	75 ef                	jne    7700 <fwp_free_zombie+0x1c0>
    7711:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7715:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7719:	48 89 50 08          	mov    %rdx,0x8(%rax)
    771d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7724:	0f 85 b3 fe ff ff    	jne    75dd <fwp_free_zombie+0x9d>
    772a:	48 89 cf             	mov    %rcx,%rdi
    772d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7732:	e8 19 de ff ff       	call   5550 <fwp_rc_forget_slot>
    7737:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    773c:	c6 01 fe             	movb   $0xfe,(%rcx)
    773f:	e9 99 fe ff ff       	jmp    75dd <fwp_free_zombie+0x9d>
    7744:	48 8d 3d 45 81 00 00 	lea    0x8145(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    774b:	e8 a0 cc ff ff       	call   43f0 <fwp_trap>

0000000000007750 <fwp_block>:
    7750:	48 83 ec 08          	sub    $0x8,%rsp
    7754:	48 8b 05 2d c0 01 00 	mov    0x1c02d(%rip),%rax        # 23788 <fwp_ready_head>
    775b:	48 85 c0             	test   %rax,%rax
    775e:	0f 84 1c 01 00 00    	je     7880 <fwp_block+0x130>
    7764:	90                   	nop
    7765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    776c:	00 00 00 00 
    7770:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7777:	48 89 15 0a c0 01 00 	mov    %rdx,0x1c00a(%rip)        # 23788 <fwp_ready_head>
    777e:	48 85 d2             	test   %rdx,%rdx
    7781:	0f 84 19 01 00 00    	je     78a0 <fwp_block+0x150>
    7787:	48 8b 15 12 c0 01 00 	mov    0x1c012(%rip),%rdx        # 237a0 <fwp_cur>
    778e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7792:	48 39 c2             	cmp    %rax,%rdx
    7795:	0f 84 d5 00 00 00    	je     7870 <fwp_block+0x120>
    779b:	48 8b 0d 86 dc 01 00 	mov    0x1dc86(%rip),%rcx        # 25428 <fwp_state_owners>
    77a2:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    77a6:	48 89 05 f3 bf 01 00 	mov    %rax,0x1bff3(%rip)        # 237a0 <fwp_cur>
    77ad:	f3 0f 7e 05 9b dc 01 	movq   0x1dc9b(%rip),%xmm0        # 25450 <fwp_foreign_callbacks>
    77b4:	00 
    77b5:	0f 16 05 84 dc 01 00 	movhps 0x1dc84(%rip),%xmm0        # 25440 <fwp_state>
    77bc:	f3 0f 7e 0d 84 dc 01 	movq   0x1dc84(%rip),%xmm1        # 25448 <fwp_handlers>
    77c3:	00 
    77c4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    77cb:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    77d2:	0f 16 0d 7f dc 01 00 	movhps 0x1dc7f(%rip),%xmm1        # 25458 <fwp_cleanups>
    77d9:	f3 0f 7e 05 57 dc 01 	movq   0x1dc57(%rip),%xmm0        # 25438 <fwp_state_len>
    77e0:	00 
    77e1:	0f 16 05 48 dc 01 00 	movhps 0x1dc48(%rip),%xmm0        # 25430 <fwp_state_cap>
    77e8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    77ef:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    77f6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77fa:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7801:	48 89 0d 40 dc 01 00 	mov    %rcx,0x1dc40(%rip)        # 25448 <fwp_handlers>
    7808:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    780f:	48 89 0d 42 dc 01 00 	mov    %rcx,0x1dc42(%rip)        # 25458 <fwp_cleanups>
    7816:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    781d:	48 89 0d 2c dc 01 00 	mov    %rcx,0x1dc2c(%rip)        # 25450 <fwp_foreign_callbacks>
    7824:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    782b:	48 89 0d 0e dc 01 00 	mov    %rcx,0x1dc0e(%rip)        # 25440 <fwp_state>
    7832:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7839:	48 89 0d f8 db 01 00 	mov    %rcx,0x1dbf8(%rip)        # 25438 <fwp_state_len>
    7840:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7847:	48 89 0d e2 db 01 00 	mov    %rcx,0x1dbe2(%rip)        # 25430 <fwp_state_cap>
    784e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7855:	48 89 0d cc db 01 00 	mov    %rcx,0x1dbcc(%rip)        # 25428 <fwp_state_owners>
    785c:	e8 2f bc ff ff       	call   3490 <swapcontext@plt>
    7861:	f3 0f 1e fa          	endbr64
    7865:	e8 d6 fc ff ff       	call   7540 <fwp_free_zombie>
    786a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7870:	8b 05 ea b8 01 00    	mov    0x1b8ea(%rip),%eax        # 23160 <fwp_slice>
    7876:	85 c0                	test   %eax,%eax
    7878:	74 36                	je     78b0 <fwp_block+0x160>
    787a:	48 83 c4 08          	add    $0x8,%rsp
    787e:	c3                   	ret
    787f:	90                   	nop
    7880:	e8 1b d9 ff ff       	call   51a0 <fwp_poll_events>
    7885:	48 8b 05 fc be 01 00 	mov    0x1befc(%rip),%rax        # 23788 <fwp_ready_head>
    788c:	48 85 c0             	test   %rax,%rax
    788f:	0f 85 db fe ff ff    	jne    7770 <fwp_block+0x20>
    7895:	eb e9                	jmp    7880 <fwp_block+0x130>
    7897:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    789e:	00 00 
    78a0:	48 c7 05 d5 be 01 00 	movq   $0x0,0x1bed5(%rip)        # 23780 <fwp_ready_tail>
    78a7:	00 00 00 00 
    78ab:	e9 d7 fe ff ff       	jmp    7787 <fwp_block+0x37>
    78b0:	48 8d 3d cd 78 00 00 	lea    0x78cd(%rip),%rdi        # f184 <_IO_stdin_used+0x184>
    78b7:	e8 e4 ba ff ff       	call   33a0 <getenv@plt>
    78bc:	ba 10 27 00 00       	mov    $0x2710,%edx
    78c1:	48 85 c0             	test   %rax,%rax
    78c4:	74 05                	je     78cb <fwp_block+0x17b>
    78c6:	80 38 00             	cmpb   $0x0,(%rax)
    78c9:	75 0b                	jne    78d6 <fwp_block+0x186>
    78cb:	89 15 8f b8 01 00    	mov    %edx,0x1b88f(%rip)        # 23160 <fwp_slice>
    78d1:	48 83 c4 08          	add    $0x8,%rsp
    78d5:	c3                   	ret
    78d6:	ba 0a 00 00 00       	mov    $0xa,%edx
    78db:	31 f6                	xor    %esi,%esi
    78dd:	48 89 c7             	mov    %rax,%rdi
    78e0:	e8 6b bc ff ff       	call   3550 <strtoll@plt>
    78e5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    78e9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    78f0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    78f5:	0f 46 d0             	cmovbe %eax,%edx
    78f8:	eb d1                	jmp    78cb <fwp_block+0x17b>
    78fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007900 <fwp_caps173>:
    7900:	f3 0f 1e fa          	endbr64
    7904:	85 f6                	test   %esi,%esi
    7906:	74 08                	je     7910 <fwp_caps173+0x10>
    7908:	c3                   	ret
    7909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7910:	48 8b 15 81 d2 01 00 	mov    0x1d281(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7917:	48 89 f8             	mov    %rdi,%rax
    791a:	48 2b 05 4f d2 01 00 	sub    0x1d24f(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7921:	48 c1 e2 10          	shl    $0x10,%rdx
    7925:	48 39 d0             	cmp    %rdx,%rax
    7928:	73 de                	jae    7908 <fwp_caps173+0x8>
    792a:	48 89 c2             	mov    %rax,%rdx
    792d:	48 c1 ea 10          	shr    $0x10,%rdx
    7931:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7935:	48 8b 15 7c d2 01 00 	mov    0x1d27c(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    793c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7940:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7944:	48 85 c9             	test   %rcx,%rcx
    7947:	74 bf                	je     7908 <fwp_caps173+0x8>
    7949:	0f b6 32             	movzbl (%rdx),%esi
    794c:	40 80 fe 02          	cmp    $0x2,%sil
    7950:	74 2e                	je     7980 <fwp_caps173+0x80>
    7952:	40 80 fe 01          	cmp    $0x1,%sil
    7956:	75 b0                	jne    7908 <fwp_caps173+0x8>
    7958:	8b 72 18             	mov    0x18(%rdx),%esi
    795b:	0f b7 c0             	movzwl %ax,%eax
    795e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7961:	48 0f af c6          	imul   %rsi,%rax
    7965:	48 c1 e8 20          	shr    $0x20,%rax
    7969:	48 39 d0             	cmp    %rdx,%rax
    796c:	73 9a                	jae    7908 <fwp_caps173+0x8>
    796e:	48 01 c1             	add    %rax,%rcx
    7971:	80 39 01             	cmpb   $0x1,(%rcx)
    7974:	75 92                	jne    7908 <fwp_caps173+0x8>
    7976:	e9 15 de ff ff       	jmp    5790 <fwp_mem_free>
    797b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7980:	66 85 c0             	test   %ax,%ax
    7983:	74 ec                	je     7971 <fwp_caps173+0x71>
    7985:	c3                   	ret
    7986:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    798d:	00 00 00 

0000000000007990 <fwp_args37>:
    7990:	f3 0f 1e fa          	endbr64
    7994:	85 d2                	test   %edx,%edx
    7996:	74 04                	je     799c <fwp_args37+0xc>
    7998:	85 f6                	test   %esi,%esi
    799a:	74 04                	je     79a0 <fwp_args37+0x10>
    799c:	c3                   	ret
    799d:	0f 1f 00             	nopl   (%rax)
    79a0:	48 8b 15 f1 d1 01 00 	mov    0x1d1f1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    79a7:	48 8b 07             	mov    (%rdi),%rax
    79aa:	48 2b 05 bf d1 01 00 	sub    0x1d1bf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    79b1:	48 c1 e2 10          	shl    $0x10,%rdx
    79b5:	48 39 d0             	cmp    %rdx,%rax
    79b8:	73 e2                	jae    799c <fwp_args37+0xc>
    79ba:	48 89 c2             	mov    %rax,%rdx
    79bd:	48 c1 ea 10          	shr    $0x10,%rdx
    79c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79c5:	48 8b 15 ec d1 01 00 	mov    0x1d1ec(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    79cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79d0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    79d4:	48 85 ff             	test   %rdi,%rdi
    79d7:	74 c3                	je     799c <fwp_args37+0xc>
    79d9:	0f b6 0a             	movzbl (%rdx),%ecx
    79dc:	80 f9 02             	cmp    $0x2,%cl
    79df:	74 2f                	je     7a10 <fwp_args37+0x80>
    79e1:	80 f9 01             	cmp    $0x1,%cl
    79e4:	75 b6                	jne    799c <fwp_args37+0xc>
    79e6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79e9:	0f b7 c0             	movzwl %ax,%eax
    79ec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79ef:	48 0f af c1          	imul   %rcx,%rax
    79f3:	48 c1 e8 20          	shr    $0x20,%rax
    79f7:	48 39 d0             	cmp    %rdx,%rax
    79fa:	73 a0                	jae    799c <fwp_args37+0xc>
    79fc:	48 01 c7             	add    %rax,%rdi
    79ff:	0f b6 07             	movzbl (%rdi),%eax
    7a02:	84 c0                	test   %al,%al
    7a04:	74 96                	je     799c <fwp_args37+0xc>
    7a06:	3c fd                	cmp    $0xfd,%al
    7a08:	77 0c                	ja     7a16 <fwp_args37+0x86>
    7a0a:	83 c0 01             	add    $0x1,%eax
    7a0d:	88 07                	mov    %al,(%rdi)
    7a0f:	c3                   	ret
    7a10:	66 85 c0             	test   %ax,%ax
    7a13:	74 ea                	je     79ff <fwp_args37+0x6f>
    7a15:	c3                   	ret
    7a16:	e9 15 da ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7a1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007a20 <fwp_caps37>:
    7a20:	f3 0f 1e fa          	endbr64
    7a24:	48 83 ec 18          	sub    $0x18,%rsp
    7a28:	8b 57 04             	mov    0x4(%rdi),%edx
    7a2b:	48 89 f8             	mov    %rdi,%rax
    7a2e:	85 d2                	test   %edx,%edx
    7a30:	0f 84 9a 00 00 00    	je     7ad0 <fwp_caps37+0xb0>
    7a36:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7a3a:	85 f6                	test   %esi,%esi
    7a3c:	0f 85 9e 00 00 00    	jne    7ae0 <fwp_caps37+0xc0>
    7a42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7a47:	e8 44 f7 ff ff       	call   7190 <fwp_drop4>
    7a4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7a51:	48 8b 0d 40 d1 01 00 	mov    0x1d140(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7a58:	48 89 c2             	mov    %rax,%rdx
    7a5b:	48 2b 15 0e d1 01 00 	sub    0x1d10e(%rip),%rdx        # 24b70 <fwp_heap+0x13b0>
    7a62:	48 c1 e1 10          	shl    $0x10,%rcx
    7a66:	48 39 ca             	cmp    %rcx,%rdx
    7a69:	73 6d                	jae    7ad8 <fwp_caps37+0xb8>
    7a6b:	48 89 d1             	mov    %rdx,%rcx
    7a6e:	48 c1 e9 10          	shr    $0x10,%rcx
    7a72:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a76:	48 8b 0d 3b d1 01 00 	mov    0x1d13b(%rip),%rcx        # 24bb8 <fwp_heap+0x13f8>
    7a7d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7a81:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7a85:	48 85 f6             	test   %rsi,%rsi
    7a88:	74 4e                	je     7ad8 <fwp_caps37+0xb8>
    7a8a:	0f b6 39             	movzbl (%rcx),%edi
    7a8d:	40 80 ff 02          	cmp    $0x2,%dil
    7a91:	0f 84 b9 00 00 00    	je     7b50 <fwp_caps37+0x130>
    7a97:	40 80 ff 01          	cmp    $0x1,%dil
    7a9b:	75 3b                	jne    7ad8 <fwp_caps37+0xb8>
    7a9d:	8b 79 18             	mov    0x18(%rcx),%edi
    7aa0:	0f b7 d2             	movzwl %dx,%edx
    7aa3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7aa6:	48 0f af d7          	imul   %rdi,%rdx
    7aaa:	48 c1 ea 20          	shr    $0x20,%rdx
    7aae:	48 39 ca             	cmp    %rcx,%rdx
    7ab1:	73 25                	jae    7ad8 <fwp_caps37+0xb8>
    7ab3:	48 01 d6             	add    %rdx,%rsi
    7ab6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7ab9:	75 1d                	jne    7ad8 <fwp_caps37+0xb8>
    7abb:	48 89 c7             	mov    %rax,%rdi
    7abe:	48 83 c4 18          	add    $0x18,%rsp
    7ac2:	e9 c9 dc ff ff       	jmp    5790 <fwp_mem_free>
    7ac7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ace:	00 00 
    7ad0:	85 f6                	test   %esi,%esi
    7ad2:	0f 84 79 ff ff ff    	je     7a51 <fwp_caps37+0x31>
    7ad8:	48 83 c4 18          	add    $0x18,%rsp
    7adc:	c3                   	ret
    7add:	0f 1f 00             	nopl   (%rax)
    7ae0:	48 8b 05 b1 d0 01 00 	mov    0x1d0b1(%rip),%rax        # 24b98 <fwp_heap+0x13d8>
    7ae7:	48 2b 3d 82 d0 01 00 	sub    0x1d082(%rip),%rdi        # 24b70 <fwp_heap+0x13b0>
    7aee:	48 c1 e0 10          	shl    $0x10,%rax
    7af2:	48 39 c7             	cmp    %rax,%rdi
    7af5:	73 e1                	jae    7ad8 <fwp_caps37+0xb8>
    7af7:	48 89 f8             	mov    %rdi,%rax
    7afa:	48 c1 e8 10          	shr    $0x10,%rax
    7afe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7b02:	48 8b 05 af d0 01 00 	mov    0x1d0af(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    7b09:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7b0d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7b11:	48 85 c0             	test   %rax,%rax
    7b14:	74 c2                	je     7ad8 <fwp_caps37+0xb8>
    7b16:	0f b6 0a             	movzbl (%rdx),%ecx
    7b19:	80 f9 02             	cmp    $0x2,%cl
    7b1c:	74 42                	je     7b60 <fwp_caps37+0x140>
    7b1e:	80 f9 01             	cmp    $0x1,%cl
    7b21:	75 b5                	jne    7ad8 <fwp_caps37+0xb8>
    7b23:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7b26:	0f b7 ff             	movzwl %di,%edi
    7b29:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b2c:	48 0f af f9          	imul   %rcx,%rdi
    7b30:	48 c1 ef 20          	shr    $0x20,%rdi
    7b34:	48 39 d7             	cmp    %rdx,%rdi
    7b37:	73 9f                	jae    7ad8 <fwp_caps37+0xb8>
    7b39:	48 01 f8             	add    %rdi,%rax
    7b3c:	0f b6 10             	movzbl (%rax),%edx
    7b3f:	84 d2                	test   %dl,%dl
    7b41:	74 95                	je     7ad8 <fwp_caps37+0xb8>
    7b43:	80 fa fd             	cmp    $0xfd,%dl
    7b46:	77 23                	ja     7b6b <fwp_caps37+0x14b>
    7b48:	83 c2 01             	add    $0x1,%edx
    7b4b:	88 10                	mov    %dl,(%rax)
    7b4d:	eb 89                	jmp    7ad8 <fwp_caps37+0xb8>
    7b4f:	90                   	nop
    7b50:	66 85 d2             	test   %dx,%dx
    7b53:	0f 85 7f ff ff ff    	jne    7ad8 <fwp_caps37+0xb8>
    7b59:	e9 58 ff ff ff       	jmp    7ab6 <fwp_caps37+0x96>
    7b5e:	66 90                	xchg   %ax,%ax
    7b60:	66 85 ff             	test   %di,%di
    7b63:	0f 85 6f ff ff ff    	jne    7ad8 <fwp_caps37+0xb8>
    7b69:	eb d1                	jmp    7b3c <fwp_caps37+0x11c>
    7b6b:	48 89 c7             	mov    %rax,%rdi
    7b6e:	48 83 c4 18          	add    $0x18,%rsp
    7b72:	e9 b9 d8 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7b77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b7e:	00 00 

0000000000007b80 <fwp_drop0>:
    7b80:	f3 0f 1e fa          	endbr64
    7b84:	48 8b 15 0d d0 01 00 	mov    0x1d00d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7b8b:	48 89 f8             	mov    %rdi,%rax
    7b8e:	48 2b 05 db cf 01 00 	sub    0x1cfdb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7b95:	48 c1 e2 10          	shl    $0x10,%rdx
    7b99:	48 39 d0             	cmp    %rdx,%rax
    7b9c:	0f 83 36 01 00 00    	jae    7cd8 <fwp_drop0+0x158>
    7ba2:	48 83 ec 18          	sub    $0x18,%rsp
    7ba6:	48 8d 35 13 bc 01 00 	lea    0x1bc13(%rip),%rsi        # 237c0 <fwp_heap>
    7bad:	48 89 c2             	mov    %rax,%rdx
    7bb0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7bb7:	48 c1 ea 10          	shr    $0x10,%rdx
    7bbb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7bbf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7bc3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7bc7:	48 85 d2             	test   %rdx,%rdx
    7bca:	74 42                	je     7c0e <fwp_drop0+0x8e>
    7bcc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7bd0:	41 80 f8 02          	cmp    $0x2,%r8b
    7bd4:	74 42                	je     7c18 <fwp_drop0+0x98>
    7bd6:	41 80 f8 01          	cmp    $0x1,%r8b
    7bda:	75 32                	jne    7c0e <fwp_drop0+0x8e>
    7bdc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7be0:	0f b7 c0             	movzwl %ax,%eax
    7be3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7be6:	49 0f af c0          	imul   %r8,%rax
    7bea:	48 c1 e8 20          	shr    $0x20,%rax
    7bee:	48 39 c8             	cmp    %rcx,%rax
    7bf1:	73 1b                	jae    7c0e <fwp_drop0+0x8e>
    7bf3:	48 01 c2             	add    %rax,%rdx
    7bf6:	0f b6 02             	movzbl (%rdx),%eax
    7bf9:	84 c0                	test   %al,%al
    7bfb:	74 11                	je     7c0e <fwp_drop0+0x8e>
    7bfd:	3c 01                	cmp    $0x1,%al
    7bff:	74 27                	je     7c28 <fwp_drop0+0xa8>
    7c01:	3c ff                	cmp    $0xff,%al
    7c03:	0f 84 e7 00 00 00    	je     7cf0 <fwp_drop0+0x170>
    7c09:	83 e8 01             	sub    $0x1,%eax
    7c0c:	88 02                	mov    %al,(%rdx)
    7c0e:	48 83 c4 18          	add    $0x18,%rsp
    7c12:	c3                   	ret
    7c13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c18:	66 85 c0             	test   %ax,%ax
    7c1b:	74 d9                	je     7bf6 <fwp_drop0+0x76>
    7c1d:	48 83 c4 18          	add    $0x18,%rsp
    7c21:	c3                   	ret
    7c22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c28:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7c2f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7c36:	48 89 f8             	mov    %rdi,%rax
    7c39:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7c3d:	48 29 c8             	sub    %rcx,%rax
    7c40:	48 c1 e2 10          	shl    $0x10,%rdx
    7c44:	48 39 d0             	cmp    %rdx,%rax
    7c47:	73 71                	jae    7cba <fwp_drop0+0x13a>
    7c49:	49 89 c2             	mov    %rax,%r10
    7c4c:	49 c1 ea 10          	shr    $0x10,%r10
    7c50:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7c54:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7c58:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7c5c:	4d 85 d2             	test   %r10,%r10
    7c5f:	74 59                	je     7cba <fwp_drop0+0x13a>
    7c61:	45 0f b6 19          	movzbl (%r9),%r11d
    7c65:	41 80 fb 02          	cmp    $0x2,%r11b
    7c69:	74 75                	je     7ce0 <fwp_drop0+0x160>
    7c6b:	41 80 fb 01          	cmp    $0x1,%r11b
    7c6f:	75 49                	jne    7cba <fwp_drop0+0x13a>
    7c71:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7c75:	0f b7 c0             	movzwl %ax,%eax
    7c78:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7c7c:	49 0f af c3          	imul   %r11,%rax
    7c80:	48 c1 e8 20          	shr    $0x20,%rax
    7c84:	4c 39 c8             	cmp    %r9,%rax
    7c87:	73 31                	jae    7cba <fwp_drop0+0x13a>
    7c89:	49 01 c2             	add    %rax,%r10
    7c8c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7c90:	75 28                	jne    7cba <fwp_drop0+0x13a>
    7c92:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7c97:	e8 f4 da ff ff       	call   5790 <fwp_mem_free>
    7c9c:	48 8d 35 1d bb 01 00 	lea    0x1bb1d(%rip),%rsi        # 237c0 <fwp_heap>
    7ca3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7ca8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7caf:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7cb6:	48 c1 e2 10          	shl    $0x10,%rdx
    7cba:	4c 89 c0             	mov    %r8,%rax
    7cbd:	48 29 c8             	sub    %rcx,%rax
    7cc0:	48 39 d0             	cmp    %rdx,%rax
    7cc3:	0f 83 45 ff ff ff    	jae    7c0e <fwp_drop0+0x8e>
    7cc9:	4c 89 c7             	mov    %r8,%rdi
    7ccc:	e9 dc fe ff ff       	jmp    7bad <fwp_drop0+0x2d>
    7cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cd8:	c3                   	ret
    7cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ce0:	66 85 c0             	test   %ax,%ax
    7ce3:	75 d5                	jne    7cba <fwp_drop0+0x13a>
    7ce5:	eb a5                	jmp    7c8c <fwp_drop0+0x10c>
    7ce7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cee:	00 00 
    7cf0:	48 89 d0             	mov    %rdx,%rax
    7cf3:	48 c1 e8 11          	shr    $0x11,%rax
    7cf7:	48 31 d0             	xor    %rdx,%rax
    7cfa:	48 89 c1             	mov    %rax,%rcx
    7cfd:	48 c1 e9 09          	shr    $0x9,%rcx
    7d01:	48 31 c8             	xor    %rcx,%rax
    7d04:	0f b6 c8             	movzbl %al,%ecx
    7d07:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7d0e:	00 
    7d0f:	48 85 c0             	test   %rax,%rax
    7d12:	75 15                	jne    7d29 <fwp_drop0+0x1a9>
    7d14:	eb 4e                	jmp    7d64 <fwp_drop0+0x1e4>
    7d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d1d:	00 00 00 
    7d20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7d24:	48 85 c0             	test   %rax,%rax
    7d27:	74 3b                	je     7d64 <fwp_drop0+0x1e4>
    7d29:	48 89 c1             	mov    %rax,%rcx
    7d2c:	48 39 10             	cmp    %rdx,(%rax)
    7d2f:	75 ef                	jne    7d20 <fwp_drop0+0x1a0>
    7d31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7d35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7d39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7d3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7d44:	0f 85 c4 fe ff ff    	jne    7c0e <fwp_drop0+0x8e>
    7d4a:	48 89 d7             	mov    %rdx,%rdi
    7d4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7d52:	e8 f9 d7 ff ff       	call   5550 <fwp_rc_forget_slot>
    7d57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7d5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7d5f:	e9 aa fe ff ff       	jmp    7c0e <fwp_drop0+0x8e>
    7d64:	48 8d 3d 25 7b 00 00 	lea    0x7b25(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7d6b:	e8 80 c6 ff ff       	call   43f0 <fwp_trap>

0000000000007d70 <fwp_drop1>:
    7d70:	f3 0f 1e fa          	endbr64
    7d74:	48 8b 15 1d ce 01 00 	mov    0x1ce1d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    7d7b:	48 89 f8             	mov    %rdi,%rax
    7d7e:	48 2b 05 eb cd 01 00 	sub    0x1cdeb(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7d85:	48 c1 e2 10          	shl    $0x10,%rdx
    7d89:	48 39 d0             	cmp    %rdx,%rax
    7d8c:	0f 83 36 01 00 00    	jae    7ec8 <fwp_drop1+0x158>
    7d92:	48 83 ec 18          	sub    $0x18,%rsp
    7d96:	48 8d 35 23 ba 01 00 	lea    0x1ba23(%rip),%rsi        # 237c0 <fwp_heap>
    7d9d:	48 89 c2             	mov    %rax,%rdx
    7da0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7da7:	48 c1 ea 10          	shr    $0x10,%rdx
    7dab:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7daf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7db3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7db7:	48 85 d2             	test   %rdx,%rdx
    7dba:	74 42                	je     7dfe <fwp_drop1+0x8e>
    7dbc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7dc0:	41 80 f8 02          	cmp    $0x2,%r8b
    7dc4:	74 42                	je     7e08 <fwp_drop1+0x98>
    7dc6:	41 80 f8 01          	cmp    $0x1,%r8b
    7dca:	75 32                	jne    7dfe <fwp_drop1+0x8e>
    7dcc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7dd0:	0f b7 c0             	movzwl %ax,%eax
    7dd3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7dd6:	49 0f af c0          	imul   %r8,%rax
    7dda:	48 c1 e8 20          	shr    $0x20,%rax
    7dde:	48 39 c8             	cmp    %rcx,%rax
    7de1:	73 1b                	jae    7dfe <fwp_drop1+0x8e>
    7de3:	48 01 c2             	add    %rax,%rdx
    7de6:	0f b6 02             	movzbl (%rdx),%eax
    7de9:	84 c0                	test   %al,%al
    7deb:	74 11                	je     7dfe <fwp_drop1+0x8e>
    7ded:	3c 01                	cmp    $0x1,%al
    7def:	74 27                	je     7e18 <fwp_drop1+0xa8>
    7df1:	3c ff                	cmp    $0xff,%al
    7df3:	0f 84 e7 00 00 00    	je     7ee0 <fwp_drop1+0x170>
    7df9:	83 e8 01             	sub    $0x1,%eax
    7dfc:	88 02                	mov    %al,(%rdx)
    7dfe:	48 83 c4 18          	add    $0x18,%rsp
    7e02:	c3                   	ret
    7e03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7e08:	66 85 c0             	test   %ax,%ax
    7e0b:	74 d9                	je     7de6 <fwp_drop1+0x76>
    7e0d:	48 83 c4 18          	add    $0x18,%rsp
    7e11:	c3                   	ret
    7e12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e18:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7e1f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e26:	48 89 f8             	mov    %rdi,%rax
    7e29:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7e2d:	48 29 c8             	sub    %rcx,%rax
    7e30:	48 c1 e2 10          	shl    $0x10,%rdx
    7e34:	48 39 d0             	cmp    %rdx,%rax
    7e37:	73 71                	jae    7eaa <fwp_drop1+0x13a>
    7e39:	49 89 c2             	mov    %rax,%r10
    7e3c:	49 c1 ea 10          	shr    $0x10,%r10
    7e40:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7e44:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7e48:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7e4c:	4d 85 d2             	test   %r10,%r10
    7e4f:	74 59                	je     7eaa <fwp_drop1+0x13a>
    7e51:	45 0f b6 19          	movzbl (%r9),%r11d
    7e55:	41 80 fb 02          	cmp    $0x2,%r11b
    7e59:	74 75                	je     7ed0 <fwp_drop1+0x160>
    7e5b:	41 80 fb 01          	cmp    $0x1,%r11b
    7e5f:	75 49                	jne    7eaa <fwp_drop1+0x13a>
    7e61:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7e65:	0f b7 c0             	movzwl %ax,%eax
    7e68:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7e6c:	49 0f af c3          	imul   %r11,%rax
    7e70:	48 c1 e8 20          	shr    $0x20,%rax
    7e74:	4c 39 c8             	cmp    %r9,%rax
    7e77:	73 31                	jae    7eaa <fwp_drop1+0x13a>
    7e79:	49 01 c2             	add    %rax,%r10
    7e7c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7e80:	75 28                	jne    7eaa <fwp_drop1+0x13a>
    7e82:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7e87:	e8 04 d9 ff ff       	call   5790 <fwp_mem_free>
    7e8c:	48 8d 35 2d b9 01 00 	lea    0x1b92d(%rip),%rsi        # 237c0 <fwp_heap>
    7e93:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7e98:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7e9f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7ea6:	48 c1 e2 10          	shl    $0x10,%rdx
    7eaa:	4c 89 c0             	mov    %r8,%rax
    7ead:	48 29 c8             	sub    %rcx,%rax
    7eb0:	48 39 d0             	cmp    %rdx,%rax
    7eb3:	0f 83 45 ff ff ff    	jae    7dfe <fwp_drop1+0x8e>
    7eb9:	4c 89 c7             	mov    %r8,%rdi
    7ebc:	e9 dc fe ff ff       	jmp    7d9d <fwp_drop1+0x2d>
    7ec1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ec8:	c3                   	ret
    7ec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ed0:	66 85 c0             	test   %ax,%ax
    7ed3:	75 d5                	jne    7eaa <fwp_drop1+0x13a>
    7ed5:	eb a5                	jmp    7e7c <fwp_drop1+0x10c>
    7ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ede:	00 00 
    7ee0:	48 89 d0             	mov    %rdx,%rax
    7ee3:	48 c1 e8 11          	shr    $0x11,%rax
    7ee7:	48 31 d0             	xor    %rdx,%rax
    7eea:	48 89 c1             	mov    %rax,%rcx
    7eed:	48 c1 e9 09          	shr    $0x9,%rcx
    7ef1:	48 31 c8             	xor    %rcx,%rax
    7ef4:	0f b6 c8             	movzbl %al,%ecx
    7ef7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7efe:	00 
    7eff:	48 85 c0             	test   %rax,%rax
    7f02:	75 25                	jne    7f29 <fwp_drop1+0x1b9>
    7f04:	eb 5e                	jmp    7f64 <fwp_drop1+0x1f4>
    7f06:	0f 1f 40 00          	nopl   0x0(%rax)
    7f0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f11:	00 00 00 00 
    7f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f1c:	00 00 00 00 
    7f20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7f24:	48 85 c0             	test   %rax,%rax
    7f27:	74 3b                	je     7f64 <fwp_drop1+0x1f4>
    7f29:	48 89 c1             	mov    %rax,%rcx
    7f2c:	48 39 10             	cmp    %rdx,(%rax)
    7f2f:	75 ef                	jne    7f20 <fwp_drop1+0x1b0>
    7f31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7f35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7f39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7f3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7f44:	0f 85 b4 fe ff ff    	jne    7dfe <fwp_drop1+0x8e>
    7f4a:	48 89 d7             	mov    %rdx,%rdi
    7f4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7f52:	e8 f9 d5 ff ff       	call   5550 <fwp_rc_forget_slot>
    7f57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7f5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7f5f:	e9 9a fe ff ff       	jmp    7dfe <fwp_drop1+0x8e>
    7f64:	48 8d 3d 25 79 00 00 	lea    0x7925(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    7f6b:	e8 80 c4 ff ff       	call   43f0 <fwp_trap>

0000000000007f70 <fwp_drop10>:
    7f70:	48 8b 0d 21 cc 01 00 	mov    0x1cc21(%rip),%rcx        # 24b98 <fwp_heap+0x13d8>
    7f77:	48 89 f8             	mov    %rdi,%rax
    7f7a:	48 2b 05 ef cb 01 00 	sub    0x1cbef(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    7f81:	48 c1 e1 10          	shl    $0x10,%rcx
    7f85:	48 39 c8             	cmp    %rcx,%rax
    7f88:	0f 83 c2 01 00 00    	jae    8150 <fwp_drop10+0x1e0>
    7f8e:	48 83 ec 18          	sub    $0x18,%rsp
    7f92:	48 89 fa             	mov    %rdi,%rdx
    7f95:	48 8d 35 24 b8 01 00 	lea    0x1b824(%rip),%rsi        # 237c0 <fwp_heap>
    7f9c:	48 89 c1             	mov    %rax,%rcx
    7f9f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7fa6:	48 c1 e9 10          	shr    $0x10,%rcx
    7faa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7fae:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7fb2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7fb6:	48 85 c9             	test   %rcx,%rcx
    7fb9:	74 46                	je     8001 <fwp_drop10+0x91>
    7fbb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7fbf:	41 80 f9 02          	cmp    $0x2,%r9b
    7fc3:	0f 84 d7 00 00 00    	je     80a0 <fwp_drop10+0x130>
    7fc9:	41 80 f9 01          	cmp    $0x1,%r9b
    7fcd:	75 32                	jne    8001 <fwp_drop10+0x91>
    7fcf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7fd3:	0f b7 c0             	movzwl %ax,%eax
    7fd6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7fd9:	49 0f af c1          	imul   %r9,%rax
    7fdd:	48 c1 e8 20          	shr    $0x20,%rax
    7fe1:	48 39 f8             	cmp    %rdi,%rax
    7fe4:	73 1b                	jae    8001 <fwp_drop10+0x91>
    7fe6:	48 01 c1             	add    %rax,%rcx
    7fe9:	0f b6 01             	movzbl (%rcx),%eax
    7fec:	84 c0                	test   %al,%al
    7fee:	74 11                	je     8001 <fwp_drop10+0x91>
    7ff0:	3c 01                	cmp    $0x1,%al
    7ff2:	74 1c                	je     8010 <fwp_drop10+0xa0>
    7ff4:	3c ff                	cmp    $0xff,%al
    7ff6:	0f 84 5c 01 00 00    	je     8158 <fwp_drop10+0x1e8>
    7ffc:	83 e8 01             	sub    $0x1,%eax
    7fff:	88 01                	mov    %al,(%rcx)
    8001:	48 83 c4 18          	add    $0x18,%rsp
    8005:	c3                   	ret
    8006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    800d:	00 00 00 
    8010:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8017:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    801e:	48 89 d0             	mov    %rdx,%rax
    8021:	49 89 d1             	mov    %rdx,%r9
    8024:	48 c1 e1 10          	shl    $0x10,%rcx
    8028:	48 29 f8             	sub    %rdi,%rax
    802b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    802f:	78 7f                	js     80b0 <fwp_drop10+0x140>
    8031:	48 39 c8             	cmp    %rcx,%rax
    8034:	73 cb                	jae    8001 <fwp_drop10+0x91>
    8036:	48 89 c1             	mov    %rax,%rcx
    8039:	48 c1 e9 10          	shr    $0x10,%rcx
    803d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8041:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8045:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8049:	48 85 f6             	test   %rsi,%rsi
    804c:	74 b3                	je     8001 <fwp_drop10+0x91>
    804e:	0f b6 39             	movzbl (%rcx),%edi
    8051:	40 80 ff 02          	cmp    $0x2,%dil
    8055:	74 39                	je     8090 <fwp_drop10+0x120>
    8057:	40 80 ff 01          	cmp    $0x1,%dil
    805b:	75 a4                	jne    8001 <fwp_drop10+0x91>
    805d:	8b 79 18             	mov    0x18(%rcx),%edi
    8060:	0f b7 c0             	movzwl %ax,%eax
    8063:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8066:	48 0f af c7          	imul   %rdi,%rax
    806a:	48 c1 e8 20          	shr    $0x20,%rax
    806e:	48 39 c8             	cmp    %rcx,%rax
    8071:	73 8e                	jae    8001 <fwp_drop10+0x91>
    8073:	48 01 c6             	add    %rax,%rsi
    8076:	80 3e 01             	cmpb   $0x1,(%rsi)
    8079:	75 86                	jne    8001 <fwp_drop10+0x91>
    807b:	48 89 d7             	mov    %rdx,%rdi
    807e:	48 83 c4 18          	add    $0x18,%rsp
    8082:	e9 09 d7 ff ff       	jmp    5790 <fwp_mem_free>
    8087:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    808e:	00 00 
    8090:	66 85 c0             	test   %ax,%ax
    8093:	74 e1                	je     8076 <fwp_drop10+0x106>
    8095:	48 83 c4 18          	add    $0x18,%rsp
    8099:	c3                   	ret
    809a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80a0:	66 85 c0             	test   %ax,%ax
    80a3:	0f 84 40 ff ff ff    	je     7fe9 <fwp_drop10+0x79>
    80a9:	48 83 c4 18          	add    $0x18,%rsp
    80ad:	c3                   	ret
    80ae:	66 90                	xchg   %ax,%ax
    80b0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    80b4:	48 39 c8             	cmp    %rcx,%rax
    80b7:	73 74                	jae    812d <fwp_drop10+0x1bd>
    80b9:	49 89 c2             	mov    %rax,%r10
    80bc:	49 c1 ea 10          	shr    $0x10,%r10
    80c0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    80c4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    80c8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    80cc:	4d 85 d2             	test   %r10,%r10
    80cf:	74 5c                	je     812d <fwp_drop10+0x1bd>
    80d1:	45 0f b6 18          	movzbl (%r8),%r11d
    80d5:	41 80 fb 02          	cmp    $0x2,%r11b
    80d9:	74 6d                	je     8148 <fwp_drop10+0x1d8>
    80db:	41 80 fb 01          	cmp    $0x1,%r11b
    80df:	75 4c                	jne    812d <fwp_drop10+0x1bd>
    80e1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    80e5:	0f b7 c0             	movzwl %ax,%eax
    80e8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    80ec:	49 0f af c3          	imul   %r11,%rax
    80f0:	48 c1 e8 20          	shr    $0x20,%rax
    80f4:	4c 39 c0             	cmp    %r8,%rax
    80f7:	73 34                	jae    812d <fwp_drop10+0x1bd>
    80f9:	49 01 c2             	add    %rax,%r10
    80fc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8100:	75 2b                	jne    812d <fwp_drop10+0x1bd>
    8102:	4c 89 cf             	mov    %r9,%rdi
    8105:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    810a:	e8 81 d6 ff ff       	call   5790 <fwp_mem_free>
    810f:	48 8d 35 aa b6 01 00 	lea    0x1b6aa(%rip),%rsi        # 237c0 <fwp_heap>
    8116:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    811b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8122:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8129:	48 c1 e1 10          	shl    $0x10,%rcx
    812d:	48 89 d0             	mov    %rdx,%rax
    8130:	48 29 f8             	sub    %rdi,%rax
    8133:	48 39 c8             	cmp    %rcx,%rax
    8136:	0f 82 60 fe ff ff    	jb     7f9c <fwp_drop10+0x2c>
    813c:	e9 c0 fe ff ff       	jmp    8001 <fwp_drop10+0x91>
    8141:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8148:	66 85 c0             	test   %ax,%ax
    814b:	75 e0                	jne    812d <fwp_drop10+0x1bd>
    814d:	eb ad                	jmp    80fc <fwp_drop10+0x18c>
    814f:	90                   	nop
    8150:	c3                   	ret
    8151:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8158:	48 89 c8             	mov    %rcx,%rax
    815b:	48 c1 e8 11          	shr    $0x11,%rax
    815f:	48 31 c8             	xor    %rcx,%rax
    8162:	48 89 c2             	mov    %rax,%rdx
    8165:	48 c1 ea 09          	shr    $0x9,%rdx
    8169:	48 31 d0             	xor    %rdx,%rax
    816c:	0f b6 d0             	movzbl %al,%edx
    816f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8176:	00 
    8177:	48 85 c0             	test   %rax,%rax
    817a:	75 0d                	jne    8189 <fwp_drop10+0x219>
    817c:	eb 46                	jmp    81c4 <fwp_drop10+0x254>
    817e:	66 90                	xchg   %ax,%ax
    8180:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8184:	48 85 c0             	test   %rax,%rax
    8187:	74 3b                	je     81c4 <fwp_drop10+0x254>
    8189:	48 89 c2             	mov    %rax,%rdx
    818c:	48 39 08             	cmp    %rcx,(%rax)
    818f:	75 ef                	jne    8180 <fwp_drop10+0x210>
    8191:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8195:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8199:	48 89 50 08          	mov    %rdx,0x8(%rax)
    819d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    81a4:	0f 85 57 fe ff ff    	jne    8001 <fwp_drop10+0x91>
    81aa:	48 89 cf             	mov    %rcx,%rdi
    81ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    81b2:	e8 99 d3 ff ff       	call   5550 <fwp_rc_forget_slot>
    81b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    81bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    81bf:	e9 3d fe ff ff       	jmp    8001 <fwp_drop10+0x91>
    81c4:	48 8d 3d c5 76 00 00 	lea    0x76c5(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    81cb:	e8 20 c2 ff ff       	call   43f0 <fwp_trap>

00000000000081d0 <f37>:
    81d0:	41 57                	push   %r15
    81d2:	41 56                	push   %r14
    81d4:	41 55                	push   %r13
    81d6:	41 54                	push   %r12
    81d8:	55                   	push   %rbp
    81d9:	53                   	push   %rbx
    81da:	48 83 ec 38          	sub    $0x38,%rsp
    81de:	48 8b 15 b3 c9 01 00 	mov    0x1c9b3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    81e5:	48 8b 0d 84 c9 01 00 	mov    0x1c984(%rip),%rcx        # 24b70 <fwp_heap+0x13b0>
    81ec:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    81f3:	00 00 
    81f5:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    81fa:	49 89 fd             	mov    %rdi,%r13
    81fd:	48 c1 e2 10          	shl    $0x10,%rdx
    8201:	48 85 ff             	test   %rdi,%rdi
    8204:	0f 84 fc 02 00 00    	je     8506 <f37+0x336>
    820a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    820e:	48 89 d8             	mov    %rbx,%rax
    8211:	48 29 c8             	sub    %rcx,%rax
    8214:	48 39 d0             	cmp    %rdx,%rax
    8217:	0f 83 b3 03 00 00    	jae    85d0 <f37+0x400>
    821d:	48 89 c2             	mov    %rax,%rdx
    8220:	48 c1 ea 10          	shr    $0x10,%rdx
    8224:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8228:	48 8b 15 89 c9 01 00 	mov    0x1c989(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    822f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8233:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8237:	48 85 ff             	test   %rdi,%rdi
    823a:	0f 84 90 03 00 00    	je     85d0 <f37+0x400>
    8240:	0f b6 0a             	movzbl (%rdx),%ecx
    8243:	80 f9 02             	cmp    $0x2,%cl
    8246:	0f 84 94 02 00 00    	je     84e0 <f37+0x310>
    824c:	80 f9 01             	cmp    $0x1,%cl
    824f:	75 24                	jne    8275 <f37+0xa5>
    8251:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8254:	0f b7 c0             	movzwl %ax,%eax
    8257:	8b 52 1c             	mov    0x1c(%rdx),%edx
    825a:	48 0f af c1          	imul   %rcx,%rax
    825e:	48 c1 e8 20          	shr    $0x20,%rax
    8262:	48 39 d0             	cmp    %rdx,%rax
    8265:	73 0e                	jae    8275 <f37+0xa5>
    8267:	48 01 c7             	add    %rax,%rdi
    826a:	0f b6 07             	movzbl (%rdi),%eax
    826d:	84 c0                	test   %al,%al
    826f:	0f 85 0b 03 00 00    	jne    8580 <f37+0x3b0>
    8275:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    827a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    827e:	ba 01 00 00 00       	mov    $0x1,%edx
    8283:	48 85 db             	test   %rbx,%rbx
    8286:	74 15                	je     829d <f37+0xcd>
    8288:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    828f:	00 
    8290:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    8294:	48 83 c2 01          	add    $0x1,%rdx
    8298:	48 85 db             	test   %rbx,%rbx
    829b:	75 f3                	jne    8290 <f37+0xc0>
    829d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    82a2:	48 85 c0             	test   %rax,%rax
    82a5:	0f 84 55 03 00 00    	je     8600 <f37+0x430>
    82ab:	31 db                	xor    %ebx,%ebx
    82ad:	0f 1f 00             	nopl   (%rax)
    82b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    82b4:	48 83 c3 01          	add    $0x1,%rbx
    82b8:	48 85 c0             	test   %rax,%rax
    82bb:	75 f3                	jne    82b0 <f37+0xe0>
    82bd:	48 39 d3             	cmp    %rdx,%rbx
    82c0:	48 0f 47 da          	cmova  %rdx,%rbx
    82c4:	48 89 d8             	mov    %rbx,%rax
    82c7:	48 c1 e8 3c          	shr    $0x3c,%rax
    82cb:	0f 85 d3 03 00 00    	jne    86a4 <f37+0x4d4>
    82d1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    82d5:	be 02 00 00 00       	mov    $0x2,%esi
    82da:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    82e1:	00 
    82e2:	e8 a9 d9 ff ff       	call   5c90 <fwp_heap_alloc>
    82e7:	48 89 28             	mov    %rbp,(%rax)
    82ea:	48 8b 15 a7 c8 01 00 	mov    0x1c8a7(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    82f1:	49 89 c4             	mov    %rax,%r12
    82f4:	48 2b 05 75 c8 01 00 	sub    0x1c875(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    82fb:	48 c1 e2 10          	shl    $0x10,%rdx
    82ff:	48 39 d0             	cmp    %rdx,%rax
    8302:	73 57                	jae    835b <f37+0x18b>
    8304:	48 89 c2             	mov    %rax,%rdx
    8307:	48 c1 ea 10          	shr    $0x10,%rdx
    830b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    830f:	48 8b 15 a2 c8 01 00 	mov    0x1c8a2(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8316:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    831a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    831e:	48 85 ed             	test   %rbp,%rbp
    8321:	74 38                	je     835b <f37+0x18b>
    8323:	0f b6 0a             	movzbl (%rdx),%ecx
    8326:	80 f9 02             	cmp    $0x2,%cl
    8329:	0f 84 91 02 00 00    	je     85c0 <f37+0x3f0>
    832f:	80 f9 01             	cmp    $0x1,%cl
    8332:	75 27                	jne    835b <f37+0x18b>
    8334:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8337:	0f b7 c0             	movzwl %ax,%eax
    833a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    833d:	48 0f af c1          	imul   %rcx,%rax
    8341:	48 c1 e8 20          	shr    $0x20,%rax
    8345:	48 39 d0             	cmp    %rdx,%rax
    8348:	73 11                	jae    835b <f37+0x18b>
    834a:	48 01 c5             	add    %rax,%rbp
    834d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8351:	0f 84 19 03 00 00    	je     8670 <f37+0x4a0>
    8357:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    835b:	48 85 db             	test   %rbx,%rbx
    835e:	74 5d                	je     83bd <f37+0x1ed>
    8360:	48 c1 e3 04          	shl    $0x4,%rbx
    8364:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8369:	4c 89 e5             	mov    %r12,%rbp
    836c:	4d 89 ee             	mov    %r13,%r14
    836f:	4c 01 e3             	add    %r12,%rbx
    8372:	0f 1f 00             	nopl   (%rax)
    8375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    837c:	00 00 00 00 
    8380:	49 8b 46 08          	mov    0x8(%r14),%rax
    8384:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8388:	48 83 c5 10          	add    $0x10,%rbp
    838c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8391:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8395:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8399:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    839e:	e8 2d df ff ff       	call   62d0 <w120>
    83a3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    83a8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    83ac:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    83b0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    83b4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    83b8:	48 39 eb             	cmp    %rbp,%rbx
    83bb:	75 c3                	jne    8380 <f37+0x1b0>
    83bd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    83c2:	31 db                	xor    %ebx,%ebx
    83c4:	e8 c7 ed ff ff       	call   7190 <fwp_drop4>
    83c9:	4c 89 ef             	mov    %r13,%rdi
    83cc:	e8 bf ed ff ff       	call   7190 <fwp_drop4>
    83d1:	4d 8b 2c 24          	mov    (%r12),%r13
    83d5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    83d9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    83e0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    83e7:	4d 85 ed             	test   %r13,%r13
    83ea:	74 32                	je     841e <f37+0x24e>
    83ec:	0f 1f 40 00          	nopl   0x0(%rax)
    83f0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    83f7:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    83fc:	48 83 c3 02          	add    $0x2,%rbx
    8400:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8406:	e8 45 dd ff ff       	call   6150 <f141.constprop.0>
    840b:	4c 39 eb             	cmp    %r13,%rbx
    840e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8414:	48 89 c7             	mov    %rax,%rdi
    8417:	72 d7                	jb     83f0 <f37+0x220>
    8419:	66 49 0f 7e c5       	movq   %xmm0,%r13
    841e:	4c 89 e7             	mov    %r12,%rdi
    8421:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8426:	e8 45 fb ff ff       	call   7f70 <fwp_drop10>
    842b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8430:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8435:	31 ff                	xor    %edi,%edi
    8437:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    843c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8441:	e8 6a d9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    8446:	48 8b 15 4b c7 01 00 	mov    0x1c74b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    844d:	48 89 c5             	mov    %rax,%rbp
    8450:	48 2b 05 19 c7 01 00 	sub    0x1c719(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8457:	48 c1 e2 10          	shl    $0x10,%rdx
    845b:	48 39 d0             	cmp    %rdx,%rax
    845e:	73 55                	jae    84b5 <f37+0x2e5>
    8460:	48 89 c2             	mov    %rax,%rdx
    8463:	48 c1 ea 10          	shr    $0x10,%rdx
    8467:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    846b:	48 8b 15 46 c7 01 00 	mov    0x1c746(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    8472:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8476:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    847a:	48 85 db             	test   %rbx,%rbx
    847d:	74 36                	je     84b5 <f37+0x2e5>
    847f:	0f b6 0a             	movzbl (%rdx),%ecx
    8482:	80 f9 02             	cmp    $0x2,%cl
    8485:	0f 84 1d 01 00 00    	je     85a8 <f37+0x3d8>
    848b:	80 f9 01             	cmp    $0x1,%cl
    848e:	75 25                	jne    84b5 <f37+0x2e5>
    8490:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8493:	0f b7 c0             	movzwl %ax,%eax
    8496:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8499:	48 0f af c1          	imul   %rcx,%rax
    849d:	48 c1 e8 20          	shr    $0x20,%rax
    84a1:	48 39 d0             	cmp    %rdx,%rax
    84a4:	73 0f                	jae    84b5 <f37+0x2e5>
    84a6:	48 01 c3             	add    %rax,%rbx
    84a9:	80 3b ff             	cmpb   $0xff,(%rbx)
    84ac:	0f 84 b1 01 00 00    	je     8663 <f37+0x493>
    84b2:	c6 03 01             	movb   $0x1,(%rbx)
    84b5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    84ba:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84c1:	00 00 
    84c3:	0f 85 d6 01 00 00    	jne    869f <f37+0x4cf>
    84c9:	48 83 c4 38          	add    $0x38,%rsp
    84cd:	48 89 e8             	mov    %rbp,%rax
    84d0:	5b                   	pop    %rbx
    84d1:	5d                   	pop    %rbp
    84d2:	41 5c                	pop    %r12
    84d4:	41 5d                	pop    %r13
    84d6:	41 5e                	pop    %r14
    84d8:	41 5f                	pop    %r15
    84da:	c3                   	ret
    84db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    84e0:	66 85 c0             	test   %ax,%ax
    84e3:	0f 85 8c fd ff ff    	jne    8275 <f37+0xa5>
    84e9:	0f b6 07             	movzbl (%rdi),%eax
    84ec:	84 c0                	test   %al,%al
    84ee:	0f 84 81 fd ff ff    	je     8275 <f37+0xa5>
    84f4:	3c fd                	cmp    $0xfd,%al
    84f6:	0f 87 99 01 00 00    	ja     8695 <f37+0x4c5>
    84fc:	83 c0 01             	add    $0x1,%eax
    84ff:	88 07                	mov    %al,(%rdi)
    8501:	e9 6f fd ff ff       	jmp    8275 <f37+0xa5>
    8506:	48 f7 d9             	neg    %rcx
    8509:	48 39 d1             	cmp    %rdx,%rcx
    850c:	0f 83 ee 00 00 00    	jae    8600 <f37+0x430>
    8512:	48 89 c8             	mov    %rcx,%rax
    8515:	48 c1 e8 10          	shr    $0x10,%rax
    8519:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    851d:	48 8b 05 94 c6 01 00 	mov    0x1c694(%rip),%rax        # 24bb8 <fwp_heap+0x13f8>
    8524:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8528:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    852c:	48 85 ff             	test   %rdi,%rdi
    852f:	0f 84 cb 00 00 00    	je     8600 <f37+0x430>
    8535:	0f b6 02             	movzbl (%rdx),%eax
    8538:	3c 02                	cmp    $0x2,%al
    853a:	0f 84 9a 00 00 00    	je     85da <f37+0x40a>
    8540:	3c 01                	cmp    $0x1,%al
    8542:	0f 85 b8 00 00 00    	jne    8600 <f37+0x430>
    8548:	0f b7 c1             	movzwl %cx,%eax
    854b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    854e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8551:	48 0f af c1          	imul   %rcx,%rax
    8555:	48 c1 e8 20          	shr    $0x20,%rax
    8559:	48 39 d0             	cmp    %rdx,%rax
    855c:	0f 83 9e 00 00 00    	jae    8600 <f37+0x430>
    8562:	48 01 c7             	add    %rax,%rdi
    8565:	0f b6 07             	movzbl (%rdi),%eax
    8568:	84 c0                	test   %al,%al
    856a:	0f 84 90 00 00 00    	je     8600 <f37+0x430>
    8570:	31 db                	xor    %ebx,%ebx
    8572:	0f 1f 00             	nopl   (%rax)
    8575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    857c:	00 00 00 00 
    8580:	3c fd                	cmp    $0xfd,%al
    8582:	0f 87 f5 00 00 00    	ja     867d <f37+0x4ad>
    8588:	83 c0 01             	add    $0x1,%eax
    858b:	88 07                	mov    %al,(%rdi)
    858d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8592:	31 d2                	xor    %edx,%edx
    8594:	4d 85 ed             	test   %r13,%r13
    8597:	0f 85 dd fc ff ff    	jne    827a <f37+0xaa>
    859d:	e9 fb fc ff ff       	jmp    829d <f37+0xcd>
    85a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    85a8:	66 85 c0             	test   %ax,%ax
    85ab:	0f 85 04 ff ff ff    	jne    84b5 <f37+0x2e5>
    85b1:	e9 f3 fe ff ff       	jmp    84a9 <f37+0x2d9>
    85b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    85bd:	00 00 00 
    85c0:	66 85 c0             	test   %ax,%ax
    85c3:	0f 85 92 fd ff ff    	jne    835b <f37+0x18b>
    85c9:	e9 7f fd ff ff       	jmp    834d <f37+0x17d>
    85ce:	66 90                	xchg   %ax,%ax
    85d0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    85d5:	e9 a4 fc ff ff       	jmp    827e <f37+0xae>
    85da:	66 85 c9             	test   %cx,%cx
    85dd:	75 21                	jne    8600 <f37+0x430>
    85df:	0f b6 07             	movzbl (%rdi),%eax
    85e2:	84 c0                	test   %al,%al
    85e4:	74 1a                	je     8600 <f37+0x430>
    85e6:	3c fd                	cmp    $0xfd,%al
    85e8:	0f 87 c2 00 00 00    	ja     86b0 <f37+0x4e0>
    85ee:	83 c0 01             	add    $0x1,%eax
    85f1:	88 07                	mov    %al,(%rdi)
    85f3:	66 90                	xchg   %ax,%ax
    85f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85fc:	00 00 00 00 
    8600:	be 02 00 00 00       	mov    $0x2,%esi
    8605:	bf 08 00 00 00       	mov    $0x8,%edi
    860a:	e8 81 d6 ff ff       	call   5c90 <fwp_heap_alloc>
    860f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8616:	48 8b 15 7b c5 01 00 	mov    0x1c57b(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    861d:	49 89 c4             	mov    %rax,%r12
    8620:	48 2b 05 49 c5 01 00 	sub    0x1c549(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    8627:	48 c1 e2 10          	shl    $0x10,%rdx
    862b:	48 39 d0             	cmp    %rdx,%rax
    862e:	73 57                	jae    8687 <f37+0x4b7>
    8630:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8637:	00 00 
    8639:	48 89 c2             	mov    %rax,%rdx
    863c:	48 c1 ea 10          	shr    $0x10,%rdx
    8640:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8644:	48 8b 15 6d c5 01 00 	mov    0x1c56d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    864b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    864f:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8653:	48 85 ed             	test   %rbp,%rbp
    8656:	0f 84 61 fd ff ff    	je     83bd <f37+0x1ed>
    865c:	31 db                	xor    %ebx,%ebx
    865e:	e9 c0 fc ff ff       	jmp    8323 <f37+0x153>
    8663:	48 89 df             	mov    %rbx,%rdi
    8666:	e8 e5 ce ff ff       	call   5550 <fwp_rc_forget_slot>
    866b:	e9 42 fe ff ff       	jmp    84b2 <f37+0x2e2>
    8670:	48 89 ef             	mov    %rbp,%rdi
    8673:	e8 d8 ce ff ff       	call   5550 <fwp_rc_forget_slot>
    8678:	e9 da fc ff ff       	jmp    8357 <f37+0x187>
    867d:	e8 ae cd ff ff       	call   5430 <fwp_rc_wide_dup>
    8682:	e9 06 ff ff ff       	jmp    858d <f37+0x3bd>
    8687:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    868e:	00 00 
    8690:	e9 28 fd ff ff       	jmp    83bd <f37+0x1ed>
    8695:	e8 96 cd ff ff       	call   5430 <fwp_rc_wide_dup>
    869a:	e9 d6 fb ff ff       	jmp    8275 <f37+0xa5>
    869f:	e8 bc ad ff ff       	call   3460 <__stack_chk_fail@plt>
    86a4:	48 8d 3d e5 6a 00 00 	lea    0x6ae5(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    86ab:	e8 40 bd ff ff       	call   43f0 <fwp_trap>
    86b0:	e8 7b cd ff ff       	call   5430 <fwp_rc_wide_dup>
    86b5:	e9 46 ff ff ff       	jmp    8600 <f37+0x430>
    86ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000086c0 <fwp_owned_entry37>:
    86c0:	f3 0f 1e fa          	endbr64
    86c4:	48 8b 3f             	mov    (%rdi),%rdi
    86c7:	e9 04 fb ff ff       	jmp    81d0 <f37>
    86cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000086d0 <e37>:
    86d0:	f3 0f 1e fa          	endbr64
    86d4:	53                   	push   %rbx
    86d5:	48 8b 1f             	mov    (%rdi),%rbx
    86d8:	48 89 df             	mov    %rbx,%rdi
    86db:	e8 f0 e1 ff ff       	call   68d0 <fwp_rc_share>
    86e0:	48 89 df             	mov    %rbx,%rdi
    86e3:	e8 e8 fa ff ff       	call   81d0 <f37>
    86e8:	48 89 c3             	mov    %rax,%rbx
    86eb:	48 89 c7             	mov    %rax,%rdi
    86ee:	e8 dd e1 ff ff       	call   68d0 <fwp_rc_share>
    86f3:	48 89 d8             	mov    %rbx,%rax
    86f6:	5b                   	pop    %rbx
    86f7:	c3                   	ret
    86f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    86ff:	00 

0000000000008700 <fwp_write>:
    8700:	41 57                	push   %r15
    8702:	41 56                	push   %r14
    8704:	41 55                	push   %r13
    8706:	41 54                	push   %r12
    8708:	55                   	push   %rbp
    8709:	53                   	push   %rbx
    870a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8711:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8718:	00 00 
    871a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8721:	00 
    8722:	49 89 d4             	mov    %rdx,%r12
    8725:	8b 12                	mov    (%rdx),%edx
    8727:	83 fa 19             	cmp    $0x19,%edx
    872a:	77 6a                	ja     8796 <fwp_write+0x96>
    872c:	48 89 f5             	mov    %rsi,%rbp
    872f:	89 d0                	mov    %edx,%eax
    8731:	89 ce                	mov    %ecx,%esi
    8733:	48 89 fb             	mov    %rdi,%rbx
    8736:	48 8d 0d c3 73 00 00 	lea    0x73c3(%rip),%rcx        # fb00 <_IO_stdin_used+0xb00>
    873d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8741:	48 01 c8             	add    %rcx,%rax
    8744:	3e ff e0             	notrack jmp *%rax
    8747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    874e:	00 00 
    8750:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8754:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8758:	48 89 ca             	mov    %rcx,%rdx
    875b:	48 85 c9             	test   %rcx,%rcx
    875e:	0f 88 9c 0c 00 00    	js     9400 <fwp_write+0xd00>
    8764:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    876b:	00 
    876c:	48 89 c6             	mov    %rax,%rsi
    876f:	4c 89 e7             	mov    %r12,%rdi
    8772:	e8 c9 b2 ff ff       	call   3a40 <fwp_fmt_u128>
    8777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    877e:	00 00 
    8780:	4c 89 e7             	mov    %r12,%rdi
    8783:	e8 c8 ac ff ff       	call   3450 <strlen@plt>
    8788:	4c 89 e6             	mov    %r12,%rsi
    878b:	48 89 df             	mov    %rbx,%rdi
    878e:	48 89 c2             	mov    %rax,%rdx
    8791:	e8 7a ba ff ff       	call   4210 <buf_put>
    8796:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    879d:	00 
    879e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    87a5:	00 00 
    87a7:	0f 85 28 04 00 00    	jne    8bd5 <fwp_write+0x4d5>
    87ad:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    87b4:	5b                   	pop    %rbx
    87b5:	5d                   	pop    %rbp
    87b6:	41 5c                	pop    %r12
    87b8:	41 5d                	pop    %r13
    87ba:	41 5e                	pop    %r14
    87bc:	41 5f                	pop    %r15
    87be:	c3                   	ret
    87bf:	90                   	nop
    87c0:	49 89 e9             	mov    %rbp,%r9
    87c3:	4c 8d 05 ab 68 00 00 	lea    0x68ab(%rip),%r8        # f075 <_IO_stdin_used+0x75>
    87ca:	b9 00 02 00 00       	mov    $0x200,%ecx
    87cf:	ba 02 00 00 00       	mov    $0x2,%edx
    87d4:	be 00 02 00 00       	mov    $0x200,%esi
    87d9:	31 c0                	xor    %eax,%eax
    87db:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    87e2:	00 
    87e3:	e8 c8 ab ff ff       	call   33b0 <__snprintf_chk@plt>
    87e8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    87ef:	00 
    87f0:	e8 5b ac ff ff       	call   3450 <strlen@plt>
    87f5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    87fc:	00 
    87fd:	48 89 df             	mov    %rbx,%rdi
    8800:	48 89 c2             	mov    %rax,%rdx
    8803:	e8 08 ba ff ff       	call   4210 <buf_put>
    8808:	eb 8c                	jmp    8796 <fwp_write+0x96>
    880a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8810:	49 89 e9             	mov    %rbp,%r9
    8813:	4c 8d 05 9b 69 00 00 	lea    0x699b(%rip),%r8        # f1b5 <_IO_stdin_used+0x1b5>
    881a:	eb ae                	jmp    87ca <fwp_write+0xca>
    881c:	0f 1f 40 00          	nopl   0x0(%rax)
    8820:	83 fa 13             	cmp    $0x13,%edx
    8823:	48 8d 05 81 69 00 00 	lea    0x6981(%rip),%rax        # f1ab <_IO_stdin_used+0x1ab>
    882a:	48 8d 35 7f 69 00 00 	lea    0x697f(%rip),%rsi        # f1b0 <_IO_stdin_used+0x1b0>
    8831:	ba 04 00 00 00       	mov    $0x4,%edx
    8836:	48 0f 44 f0          	cmove  %rax,%rsi
    883a:	45 31 ed             	xor    %r13d,%r13d
    883d:	e8 ce b9 ff ff       	call   4210 <buf_put>
    8842:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8847:	0f 84 a3 08 00 00    	je     90f0 <fwp_write+0x9f0>
    884d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8852:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8857:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    885c:	48 89 df             	mov    %rbx,%rdi
    885f:	49 0f 44 c5          	cmove  %r13,%rax
    8863:	31 c9                	xor    %ecx,%ecx
    8865:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    886a:	e8 91 fe ff ff       	call   8700 <fwp_write>
    886f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8874:	0f 84 6e 09 00 00    	je     91e8 <fwp_write+0xae8>
    887a:	49 83 c5 01          	add    $0x1,%r13
    887e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8882:	0f 83 68 08 00 00    	jae    90f0 <fwp_write+0x9f0>
    8888:	ba 02 00 00 00       	mov    $0x2,%edx
    888d:	48 8d 35 61 69 00 00 	lea    0x6961(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8894:	48 89 df             	mov    %rbx,%rdi
    8897:	e8 74 b9 ff ff       	call   4210 <buf_put>
    889c:	eb af                	jmp    884d <fwp_write+0x14d>
    889e:	66 90                	xchg   %ax,%ax
    88a0:	ba 06 00 00 00       	mov    $0x6,%edx
    88a5:	48 8d 35 22 69 00 00 	lea    0x6922(%rip),%rsi        # f1ce <_IO_stdin_used+0x1ce>
    88ac:	48 83 c5 10          	add    $0x10,%rbp
    88b0:	e8 5b b9 ff ff       	call   4210 <buf_put>
    88b5:	48 89 ef             	mov    %rbp,%rdi
    88b8:	e8 93 ab ff ff       	call   3450 <strlen@plt>
    88bd:	48 89 ee             	mov    %rbp,%rsi
    88c0:	48 89 df             	mov    %rbx,%rdi
    88c3:	48 89 c2             	mov    %rax,%rdx
    88c6:	e8 45 b9 ff ff       	call   4210 <buf_put>
    88cb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    88d0:	ba 01 00 00 00       	mov    $0x1,%edx
    88d5:	48 89 df             	mov    %rbx,%rdi
    88d8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    88dd:	e8 2e b9 ff ff       	call   4210 <buf_put>
    88e2:	e9 af fe ff ff       	jmp    8796 <fwp_write+0x96>
    88e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    88ee:	00 00 
    88f0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88f7:	00 
    88f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88ff:	00 00 
    8901:	0f 85 ce 02 00 00    	jne    8bd5 <fwp_write+0x4d5>
    8907:	ba 0a 00 00 00       	mov    $0xa,%edx
    890c:	48 8d 35 a7 68 00 00 	lea    0x68a7(%rip),%rsi        # f1ba <_IO_stdin_used+0x1ba>
    8913:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    891a:	48 89 df             	mov    %rbx,%rdi
    891d:	5b                   	pop    %rbx
    891e:	5d                   	pop    %rbp
    891f:	41 5c                	pop    %r12
    8921:	41 5d                	pop    %r13
    8923:	41 5e                	pop    %r14
    8925:	41 5f                	pop    %r15
    8927:	e9 e4 b8 ff ff       	jmp    4210 <buf_put>
    892c:	0f 1f 40 00          	nopl   0x0(%rax)
    8930:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8935:	4d 85 ed             	test   %r13,%r13
    8938:	0f 84 02 0c 00 00    	je     9540 <fwp_write+0xe40>
    893e:	48 8d 35 bd 68 00 00 	lea    0x68bd(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    8945:	4c 89 ef             	mov    %r13,%rdi
    8948:	e8 e3 ab ff ff       	call   3530 <strcmp@plt>
    894d:	41 89 c1             	mov    %eax,%r9d
    8950:	85 c0                	test   %eax,%eax
    8952:	0f 84 6c 0c 00 00    	je     95c4 <fwp_write+0xec4>
    8958:	4c 89 ef             	mov    %r13,%rdi
    895b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8960:	e8 eb aa ff ff       	call   3450 <strlen@plt>
    8965:	4c 89 ee             	mov    %r13,%rsi
    8968:	48 89 df             	mov    %rbx,%rdi
    896b:	48 89 c2             	mov    %rax,%rdx
    896e:	e8 9d b8 ff ff       	call   4210 <buf_put>
    8973:	ba 01 00 00 00       	mov    $0x1,%edx
    8978:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    897d:	48 89 df             	mov    %rbx,%rdi
    8980:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8985:	e8 86 b8 ff ff       	call   4210 <buf_put>
    898a:	ba 01 00 00 00       	mov    $0x1,%edx
    898f:	4c 89 fe             	mov    %r15,%rsi
    8992:	48 89 df             	mov    %rbx,%rdi
    8995:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    899a:	e8 71 b8 ff ff       	call   4210 <buf_put>
    899f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    89a4:	45 31 f6             	xor    %r14d,%r14d
    89a7:	85 d2                	test   %edx,%edx
    89a9:	0f 8e 81 0a 00 00    	jle    9430 <fwp_write+0xd30>
    89af:	45 31 ed             	xor    %r13d,%r13d
    89b2:	4d 85 ed             	test   %r13,%r13
    89b5:	0f 85 75 07 00 00    	jne    9130 <fwp_write+0xa30>
    89bb:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    89c2:	00 
    89c3:	45 85 f6             	test   %r14d,%r14d
    89c6:	0f 84 84 07 00 00    	je     9150 <fwp_write+0xa50>
    89cc:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    89d1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    89d6:	48 89 df             	mov    %rbx,%rdi
    89d9:	49 83 c5 01          	add    $0x1,%r13
    89dd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    89e1:	31 c9                	xor    %ecx,%ecx
    89e3:	e8 18 fd ff ff       	call   8700 <fwp_write>
    89e8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    89ed:	7f c3                	jg     89b2 <fwp_write+0x2b2>
    89ef:	45 85 f6             	test   %r14d,%r14d
    89f2:	0f 84 38 0a 00 00    	je     9430 <fwp_write+0xd30>
    89f8:	b8 29 00 00 00       	mov    $0x29,%eax
    89fd:	ba 01 00 00 00       	mov    $0x1,%edx
    8a02:	4c 89 fe             	mov    %r15,%rsi
    8a05:	48 89 df             	mov    %rbx,%rdi
    8a08:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8a0c:	e8 ff b7 ff ff       	call   4210 <buf_put>
    8a11:	e9 80 fd ff ff       	jmp    8796 <fwp_write+0x96>
    8a16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a1d:	00 00 00 
    8a20:	ba 01 00 00 00       	mov    $0x1,%edx
    8a25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a2a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8a2f:	e8 dc b7 ff ff       	call   4210 <buf_put>
    8a34:	48 85 ed             	test   %rbp,%rbp
    8a37:	0f 84 93 06 00 00    	je     90d0 <fwp_write+0x9d0>
    8a3d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8a41:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8a46:	31 c9                	xor    %ecx,%ecx
    8a48:	48 89 df             	mov    %rbx,%rdi
    8a4b:	e8 b0 fc ff ff       	call   8700 <fwp_write>
    8a50:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8a54:	48 85 ed             	test   %rbp,%rbp
    8a57:	0f 84 73 06 00 00    	je     90d0 <fwp_write+0x9d0>
    8a5d:	ba 02 00 00 00       	mov    $0x2,%edx
    8a62:	48 8d 35 8c 67 00 00 	lea    0x678c(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8a69:	48 89 df             	mov    %rbx,%rdi
    8a6c:	e8 9f b7 ff ff       	call   4210 <buf_put>
    8a71:	eb ca                	jmp    8a3d <fwp_write+0x33d>
    8a73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a78:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8a7c:	85 f6                	test   %esi,%esi
    8a7e:	0f 84 fc 07 00 00    	je     9280 <fwp_write+0xb80>
    8a84:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8a8b:	00 
    8a8c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8a93:	00 00 
    8a95:	0f 85 3a 01 00 00    	jne    8bd5 <fwp_write+0x4d5>
    8a9b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8a9f:	4c 89 ea             	mov    %r13,%rdx
    8aa2:	e9 6c fe ff ff       	jmp    8913 <fwp_write+0x213>
    8aa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8aae:	00 00 
    8ab0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8ab5:	ba 01 00 00 00       	mov    $0x1,%edx
    8aba:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8abf:	48 89 ee             	mov    %rbp,%rsi
    8ac2:	e8 49 b7 ff ff       	call   4210 <buf_put>
    8ac7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8acc:	4c 89 e7             	mov    %r12,%rdi
    8acf:	e8 7c a9 ff ff       	call   3450 <strlen@plt>
    8ad4:	4c 89 e6             	mov    %r12,%rsi
    8ad7:	48 89 df             	mov    %rbx,%rdi
    8ada:	48 89 c2             	mov    %rax,%rdx
    8add:	e8 2e b7 ff ff       	call   4210 <buf_put>
    8ae2:	ba 01 00 00 00       	mov    $0x1,%edx
    8ae7:	48 89 ee             	mov    %rbp,%rsi
    8aea:	48 89 df             	mov    %rbx,%rdi
    8aed:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8af2:	e8 19 b7 ff ff       	call   4210 <buf_put>
    8af7:	e9 9a fc ff ff       	jmp    8796 <fwp_write+0x96>
    8afc:	0f 1f 40 00          	nopl   0x0(%rax)
    8b00:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8b05:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8b09:	0f 8a 8e 0b 00 00    	jp     969d <fwp_write+0xf9d>
    8b0f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b13:	66 0f 54 05 15 71 00 	andpd  0x7115(%rip),%xmm0        # fc30 <msg.4+0xc0>
    8b1a:	00 
    8b1b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8b20:	66 0f 2e 05 88 70 00 	ucomisd 0x7088(%rip),%xmm0        # fbb0 <msg.4+0x40>
    8b27:	00 
    8b28:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8b2f:	00 
    8b30:	0f 87 b2 09 00 00    	ja     94e8 <fwp_write+0xde8>
    8b36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8b3d:	00 00 00 
    8b40:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b44:	89 ee                	mov    %ebp,%esi
    8b46:	4c 89 e7             	mov    %r12,%rdi
    8b49:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8b4e:	e8 bd bb ff ff       	call   4710 <fwp_format_g.constprop.0>
    8b53:	31 f6                	xor    %esi,%esi
    8b55:	4c 89 e7             	mov    %r12,%rdi
    8b58:	e8 b3 a8 ff ff       	call   3410 <strtod@plt>
    8b5d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8b62:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8b66:	7a 06                	jp     8b6e <fwp_write+0x46e>
    8b68:	0f 84 e9 01 00 00    	je     8d57 <fwp_write+0x657>
    8b6e:	83 c5 01             	add    $0x1,%ebp
    8b71:	83 fd 12             	cmp    $0x12,%ebp
    8b74:	75 ca                	jne    8b40 <fwp_write+0x440>
    8b76:	be 11 00 00 00       	mov    $0x11,%esi
    8b7b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8b7f:	4c 89 e7             	mov    %r12,%rdi
    8b82:	e8 89 bb ff ff       	call   4710 <fwp_format_g.constprop.0>
    8b87:	e9 cb 01 00 00       	jmp    8d57 <fwp_write+0x657>
    8b8c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b90:	48 83 fd 01          	cmp    $0x1,%rbp
    8b94:	0f 84 e6 08 00 00    	je     9480 <fwp_write+0xd80>
    8b9a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8b9e:	b8 02 00 00 00       	mov    $0x2,%eax
    8ba3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ba8:	48 0f 44 d0          	cmove  %rax,%rdx
    8bac:	48 8d 35 f0 65 00 00 	lea    0x65f0(%rip),%rsi        # f1a3 <_IO_stdin_used+0x1a3>
    8bb3:	48 8d 05 ee 65 00 00 	lea    0x65ee(%rip),%rax        # f1a8 <_IO_stdin_used+0x1a8>
    8bba:	48 0f 44 f0          	cmove  %rax,%rsi
    8bbe:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8bc5:	00 
    8bc6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8bcd:	00 00 
    8bcf:	0f 84 3e fd ff ff    	je     8913 <fwp_write+0x213>
    8bd5:	e8 86 a8 ff ff       	call   3460 <__stack_chk_fail@plt>
    8bda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8be0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8be5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8bea:	e8 61 b5 ff ff       	call   4150 <buf_grow>
    8bef:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8bf3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8bf9:	4c 03 0b             	add    (%rbx),%r9
    8bfc:	66 45 89 11          	mov    %r10w,(%r9)
    8c00:	45 85 e4             	test   %r12d,%r12d
    8c03:	0f 8e 07 05 00 00    	jle    9110 <fwp_write+0xa10>
    8c09:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8c10:	55 55 55 
    8c13:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8c18:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8c1f:	aa aa aa 
    8c22:	49 83 c1 01          	add    $0x1,%r9
    8c26:	eb 45                	jmp    8c6d <fwp_write+0x56d>
    8c28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c2f:	00 
    8c30:	be 01 00 00 00       	mov    $0x1,%esi
    8c35:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8c3a:	88 07                	mov    %al,(%rdi)
    8c3c:	48 89 e8             	mov    %rbp,%rax
    8c3f:	49 f7 e8             	imul   %r8
    8c42:	48 89 e8             	mov    %rbp,%rax
    8c45:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c49:	48 29 c2             	sub    %rax,%rdx
    8c4c:	48 85 c9             	test   %rcx,%rcx
    8c4f:	0f 95 c0             	setne  %al
    8c52:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8c56:	48 83 ef 01          	sub    $0x1,%rdi
    8c5a:	48 21 c5             	and    %rax,%rbp
    8c5d:	48 29 ea             	sub    %rbp,%rdx
    8c60:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8c64:	49 39 f9             	cmp    %rdi,%r9
    8c67:	0f 84 a3 04 00 00    	je     9110 <fwp_write+0xa10>
    8c6d:	48 89 e8             	mov    %rbp,%rax
    8c70:	49 f7 e8             	imul   %r8
    8c73:	48 89 e8             	mov    %rbp,%rax
    8c76:	48 c1 f8 3f          	sar    $0x3f,%rax
    8c7a:	48 89 d1             	mov    %rdx,%rcx
    8c7d:	48 29 c1             	sub    %rax,%rcx
    8c80:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    8c84:	48 89 e9             	mov    %rbp,%rcx
    8c87:	48 29 c1             	sub    %rax,%rcx
    8c8a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    8c8e:	49 f7 e2             	mul    %r10
    8c91:	b8 30 00 00 00       	mov    $0x30,%eax
    8c96:	48 89 d6             	mov    %rdx,%rsi
    8c99:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    8c9d:	48 d1 ee             	shr    $1,%rsi
    8ca0:	48 01 f2             	add    %rsi,%rdx
    8ca3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8ca7:	48 29 d6             	sub    %rdx,%rsi
    8caa:	74 8e                	je     8c3a <fwp_write+0x53a>
    8cac:	48 83 fe 01          	cmp    $0x1,%rsi
    8cb0:	0f 85 7a ff ff ff    	jne    8c30 <fwp_write+0x530>
    8cb6:	31 f6                	xor    %esi,%esi
    8cb8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    8cbd:	e9 78 ff ff ff       	jmp    8c3a <fwp_write+0x53a>
    8cc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8cc8:	66 0f 6e cd          	movd   %ebp,%xmm1
    8ccc:	0f 2e c9             	ucomiss %xmm1,%xmm1
    8ccf:	0f 8a c8 09 00 00    	jp     969d <fwp_write+0xf9d>
    8cd5:	0f 28 c1             	movaps %xmm1,%xmm0
    8cd8:	0f 54 05 41 6f 00 00 	andps  0x6f41(%rip),%xmm0        # fc20 <msg.4+0xb0>
    8cdf:	0f 2e 05 1e 63 00 00 	ucomiss 0x631e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    8ce6:	0f 87 24 08 00 00    	ja     9510 <fwp_write+0xe10>
    8cec:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8cf0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8cf6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8cfd:	00 
    8cfe:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8d02:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d0e:	00 00 
    8d10:	44 89 ee             	mov    %r13d,%esi
    8d13:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8d18:	4c 89 e7             	mov    %r12,%rdi
    8d1b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8d20:	e8 eb b9 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8d25:	31 f6                	xor    %esi,%esi
    8d27:	4c 89 e7             	mov    %r12,%rdi
    8d2a:	e8 81 a7 ff ff       	call   34b0 <strtof@plt>
    8d2f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8d34:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8d37:	7a 02                	jp     8d3b <fwp_write+0x63b>
    8d39:	74 1c                	je     8d57 <fwp_write+0x657>
    8d3b:	41 83 c5 01          	add    $0x1,%r13d
    8d3f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8d43:	75 cb                	jne    8d10 <fwp_write+0x610>
    8d45:	be 09 00 00 00       	mov    $0x9,%esi
    8d4a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8d4f:	4c 89 e7             	mov    %r12,%rdi
    8d52:	e8 b9 b9 ff ff       	call   4710 <fwp_format_g.constprop.0>
    8d57:	4c 89 e7             	mov    %r12,%rdi
    8d5a:	e8 21 b6 ff ff       	call   4380 <fwp_finish_float>
    8d5f:	e9 1c fa ff ff       	jmp    8780 <fwp_write+0x80>
    8d64:	0f 1f 40 00          	nopl   0x0(%rax)
    8d68:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    8d6c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8d70:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8d77:	00 
    8d78:	48 89 ef             	mov    %rbp,%rdi
    8d7b:	e8 c0 ac ff ff       	call   3a40 <fwp_fmt_u128>
    8d80:	48 89 ef             	mov    %rbp,%rdi
    8d83:	e8 c8 a6 ff ff       	call   3450 <strlen@plt>
    8d88:	48 89 ee             	mov    %rbp,%rsi
    8d8b:	48 89 df             	mov    %rbx,%rdi
    8d8e:	48 89 c2             	mov    %rax,%rdx
    8d91:	e8 7a b4 ff ff       	call   4210 <buf_put>
    8d96:	e9 fb f9 ff ff       	jmp    8796 <fwp_write+0x96>
    8d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8da0:	ba 06 00 00 00       	mov    $0x6,%edx
    8da5:	48 8d 35 4c 64 00 00 	lea    0x644c(%rip),%rsi        # f1f8 <_IO_stdin_used+0x1f8>
    8dac:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8db2:	e8 59 b4 ff ff       	call   4210 <buf_put>
    8db7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8dbe:	ff ff 7f 
    8dc1:	48 23 55 00          	and    0x0(%rbp),%rdx
    8dc5:	0f 84 86 02 00 00    	je     9051 <fwp_write+0x951>
    8dcb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8dd0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8dd4:	48 85 d2             	test   %rdx,%rdx
    8dd7:	0f 84 ae 00 00 00    	je     8e8b <fwp_write+0x78b>
    8ddd:	8b 0a                	mov    (%rdx),%ecx
    8ddf:	83 f9 1c             	cmp    $0x1c,%ecx
    8de2:	0f 84 58 06 00 00    	je     9440 <fwp_write+0xd40>
    8de8:	83 f9 1b             	cmp    $0x1b,%ecx
    8deb:	0f 87 9a 00 00 00    	ja     8e8b <fwp_write+0x78b>
    8df1:	be 01 00 00 00       	mov    $0x1,%esi
    8df6:	48 d3 e6             	shl    %cl,%rsi
    8df9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8dff:	0f 85 4b 04 00 00    	jne    9250 <fwp_write+0xb50>
    8e05:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8e0b:	0f 85 0f 04 00 00    	jne    9220 <fwp_write+0xb20>
    8e11:	83 e6 21             	and    $0x21,%esi
    8e14:	74 75                	je     8e8b <fwp_write+0x78b>
    8e16:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8e1b:	48 85 ff             	test   %rdi,%rdi
    8e1e:	79 07                	jns    8e27 <fwp_write+0x727>
    8e20:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8e24:	4c 01 ee             	add    %r13,%rsi
    8e27:	48 0f be 3e          	movsbq (%rsi),%rdi
    8e2b:	85 c9                	test   %ecx,%ecx
    8e2d:	40 0f b6 f7          	movzbl %dil,%esi
    8e31:	48 0f 44 f7          	cmove  %rdi,%rsi
    8e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e3c:	00 00 00 00 
    8e40:	31 c9                	xor    %ecx,%ecx
    8e42:	48 89 df             	mov    %rbx,%rdi
    8e45:	49 83 c5 01          	add    $0x1,%r13
    8e49:	e8 b2 f8 ff ff       	call   8700 <fwp_write>
    8e4e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8e55:	ff ff 7f 
    8e58:	48 23 55 00          	and    0x0(%rbp),%rdx
    8e5c:	49 39 d5             	cmp    %rdx,%r13
    8e5f:	0f 83 ec 01 00 00    	jae    9051 <fwp_write+0x951>
    8e65:	ba 02 00 00 00       	mov    $0x2,%edx
    8e6a:	48 89 df             	mov    %rbx,%rdi
    8e6d:	48 8d 35 81 63 00 00 	lea    0x6381(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8e74:	e8 97 b3 ff ff       	call   4210 <buf_put>
    8e79:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e7e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8e82:	48 85 d2             	test   %rdx,%rdx
    8e85:	0f 85 52 ff ff ff    	jne    8ddd <fwp_write+0x6dd>
    8e8b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8e90:	48 85 ff             	test   %rdi,%rdi
    8e93:	0f 88 cf 05 00 00    	js     9468 <fwp_write+0xd68>
    8e99:	48 8b 31             	mov    (%rcx),%rsi
    8e9c:	eb a2                	jmp    8e40 <fwp_write+0x740>
    8e9e:	66 90                	xchg   %ax,%ax
    8ea0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8ea7:	00 
    8ea8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8eaf:	00 00 
    8eb1:	0f 85 1e fd ff ff    	jne    8bd5 <fwp_write+0x4d5>
    8eb7:	ba 08 00 00 00       	mov    $0x8,%edx
    8ebc:	48 8d 35 02 63 00 00 	lea    0x6302(%rip),%rsi        # f1c5 <_IO_stdin_used+0x1c5>
    8ec3:	e9 4b fa ff ff       	jmp    8913 <fwp_write+0x213>
    8ec8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8ecf:	00 
    8ed0:	89 e8                	mov    %ebp,%eax
    8ed2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8ed9:	76 03                	jbe    8ede <fwp_write+0x7de>
    8edb:	8b 45 00             	mov    0x0(%rbp),%eax
    8ede:	41 89 c6             	mov    %eax,%r14d
    8ee1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8ee6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8eeb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8eef:	4c 89 ef             	mov    %r13,%rdi
    8ef2:	e8 59 a5 ff ff       	call   3450 <strlen@plt>
    8ef7:	4c 89 ee             	mov    %r13,%rsi
    8efa:	48 89 df             	mov    %rbx,%rdi
    8efd:	48 89 c2             	mov    %rax,%rdx
    8f00:	e8 0b b3 ff ff       	call   4210 <buf_put>
    8f05:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8f0a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8f0e:	85 f6                	test   %esi,%esi
    8f10:	0f 8e 80 f8 ff ff    	jle    8796 <fwp_write+0x96>
    8f16:	45 31 ed             	xor    %r13d,%r13d
    8f19:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8f1e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8f23:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8f28:	ba 01 00 00 00       	mov    $0x1,%edx
    8f2d:	4c 89 fe             	mov    %r15,%rsi
    8f30:	48 89 04 24          	mov    %rax,(%rsp)
    8f34:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8f39:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8f3d:	48 89 df             	mov    %rbx,%rdi
    8f40:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8f44:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8f49:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8f4e:	e8 bd b2 ff ff       	call   4210 <buf_put>
    8f53:	41 8b 06             	mov    (%r14),%eax
    8f56:	83 f8 0e             	cmp    $0xe,%eax
    8f59:	0f 84 71 02 00 00    	je     91d0 <fwp_write+0xad0>
    8f5f:	83 f8 10             	cmp    $0x10,%eax
    8f62:	0f 84 38 02 00 00    	je     91a0 <fwp_write+0xaa0>
    8f68:	83 f8 0a             	cmp    $0xa,%eax
    8f6b:	0f 84 7f 04 00 00    	je     93f0 <fwp_write+0xcf0>
    8f71:	0f 8f f9 00 00 00    	jg     9070 <fwp_write+0x970>
    8f77:	83 f8 03             	cmp    $0x3,%eax
    8f7a:	0f 8f 50 04 00 00    	jg     93d0 <fwp_write+0xcd0>
    8f80:	85 c0                	test   %eax,%eax
    8f82:	78 10                	js     8f94 <fwp_write+0x894>
    8f84:	48 8b 04 24          	mov    (%rsp),%rax
    8f88:	48 c1 e8 3f          	shr    $0x3f,%rax
    8f8c:	85 c0                	test   %eax,%eax
    8f8e:	0f 85 f9 00 00 00    	jne    908d <fwp_write+0x98d>
    8f94:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8f99:	48 8b 34 24          	mov    (%rsp),%rsi
    8f9d:	31 c9                	xor    %ecx,%ecx
    8f9f:	48 89 df             	mov    %rbx,%rdi
    8fa2:	e8 59 f7 ff ff       	call   8700 <fwp_write>
    8fa7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8fac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8fb1:	49 83 c5 01          	add    $0x1,%r13
    8fb5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8fb9:	0f 8f 5f ff ff ff    	jg     8f1e <fwp_write+0x81e>
    8fbf:	e9 d2 f7 ff ff       	jmp    8796 <fwp_write+0x96>
    8fc4:	0f 1f 40 00          	nopl   0x0(%rax)
    8fc8:	ba 06 00 00 00       	mov    $0x6,%edx
    8fcd:	48 8d 35 17 62 00 00 	lea    0x6217(%rip),%rsi        # f1eb <_IO_stdin_used+0x1eb>
    8fd4:	45 31 ed             	xor    %r13d,%r13d
    8fd7:	e8 34 b2 ff ff       	call   4210 <buf_put>
    8fdc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8fe1:	75 19                	jne    8ffc <fwp_write+0x8fc>
    8fe3:	eb 6c                	jmp    9051 <fwp_write+0x951>
    8fe5:	0f 1f 00             	nopl   (%rax)
    8fe8:	ba 02 00 00 00       	mov    $0x2,%edx
    8fed:	48 8d 35 01 62 00 00 	lea    0x6201(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    8ff4:	48 89 df             	mov    %rbx,%rdi
    8ff7:	e8 14 b2 ff ff       	call   4210 <buf_put>
    8ffc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9002:	b9 00 02 00 00       	mov    $0x200,%ecx
    9007:	31 c0                	xor    %eax,%eax
    9009:	49 83 c5 01          	add    $0x1,%r13
    900d:	4c 8d 05 de 61 00 00 	lea    0x61de(%rip),%r8        # f1f2 <_IO_stdin_used+0x1f2>
    9014:	ba 02 00 00 00       	mov    $0x2,%edx
    9019:	be 00 02 00 00       	mov    $0x200,%esi
    901e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9025:	00 
    9026:	e8 85 a3 ff ff       	call   33b0 <__snprintf_chk@plt>
    902b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9032:	00 
    9033:	e8 18 a4 ff ff       	call   3450 <strlen@plt>
    9038:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    903f:	00 
    9040:	48 89 df             	mov    %rbx,%rdi
    9043:	48 89 c2             	mov    %rax,%rdx
    9046:	e8 c5 b1 ff ff       	call   4210 <buf_put>
    904b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    904f:	72 97                	jb     8fe8 <fwp_write+0x8e8>
    9051:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9056:	ba 01 00 00 00       	mov    $0x1,%edx
    905b:	48 89 df             	mov    %rbx,%rdi
    905e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9063:	e8 a8 b1 ff ff       	call   4210 <buf_put>
    9068:	e9 29 f7 ff ff       	jmp    8796 <fwp_write+0x96>
    906d:	0f 1f 00             	nopl   (%rax)
    9070:	83 f8 0b             	cmp    $0xb,%eax
    9073:	0f 85 1b ff ff ff    	jne    8f94 <fwp_write+0x894>
    9079:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    907e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9082:	83 e0 01             	and    $0x1,%eax
    9085:	85 c0                	test   %eax,%eax
    9087:	0f 84 07 ff ff ff    	je     8f94 <fwp_write+0x894>
    908d:	4c 89 fe             	mov    %r15,%rsi
    9090:	48 89 df             	mov    %rbx,%rdi
    9093:	ba 01 00 00 00       	mov    $0x1,%edx
    9098:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    909d:	e8 6e b1 ff ff       	call   4210 <buf_put>
    90a2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    90a7:	48 8b 34 24          	mov    (%rsp),%rsi
    90ab:	31 c9                	xor    %ecx,%ecx
    90ad:	48 89 df             	mov    %rbx,%rdi
    90b0:	e8 4b f6 ff ff       	call   8700 <fwp_write>
    90b5:	ba 01 00 00 00       	mov    $0x1,%edx
    90ba:	4c 89 fe             	mov    %r15,%rsi
    90bd:	48 89 df             	mov    %rbx,%rdi
    90c0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    90c5:	e8 46 b1 ff ff       	call   4210 <buf_put>
    90ca:	e9 d8 fe ff ff       	jmp    8fa7 <fwp_write+0x8a7>
    90cf:	90                   	nop
    90d0:	ba 01 00 00 00       	mov    $0x1,%edx
    90d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90da:	48 89 df             	mov    %rbx,%rdi
    90dd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    90e2:	e8 29 b1 ff ff       	call   4210 <buf_put>
    90e7:	e9 aa f6 ff ff       	jmp    8796 <fwp_write+0x96>
    90ec:	0f 1f 40 00          	nopl   0x0(%rax)
    90f0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    90f5:	ba 01 00 00 00       	mov    $0x1,%edx
    90fa:	48 89 df             	mov    %rbx,%rdi
    90fd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9102:	e8 09 b1 ff ff       	call   4210 <buf_put>
    9107:	e9 8a f6 ff ff       	jmp    8796 <fwp_write+0x96>
    910c:	0f 1f 40 00          	nopl   0x0(%rax)
    9110:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9114:	48 8b 13             	mov    (%rbx),%rdx
    9117:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    911c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9120:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9124:	e9 6d f6 ff ff       	jmp    8796 <fwp_write+0x96>
    9129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9130:	ba 02 00 00 00       	mov    $0x2,%edx
    9135:	48 8d 35 b9 60 00 00 	lea    0x60b9(%rip),%rsi        # f1f5 <_IO_stdin_used+0x1f5>
    913c:	48 89 df             	mov    %rbx,%rdi
    913f:	e8 cc b0 ff ff       	call   4210 <buf_put>
    9144:	e9 72 f8 ff ff       	jmp    89bb <fwp_write+0x2bb>
    9149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9150:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9155:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    915a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    915e:	48 89 f7             	mov    %rsi,%rdi
    9161:	48 89 34 24          	mov    %rsi,(%rsp)
    9165:	e8 e6 a2 ff ff       	call   3450 <strlen@plt>
    916a:	48 8b 34 24          	mov    (%rsp),%rsi
    916e:	48 89 df             	mov    %rbx,%rdi
    9171:	48 89 c2             	mov    %rax,%rdx
    9174:	e8 97 b0 ff ff       	call   4210 <buf_put>
    9179:	ba 03 00 00 00       	mov    $0x3,%edx
    917e:	48 8d 35 93 60 00 00 	lea    0x6093(%rip),%rsi        # f218 <_IO_stdin_used+0x218>
    9185:	48 89 df             	mov    %rbx,%rdi
    9188:	e8 83 b0 ff ff       	call   4210 <buf_put>
    918d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9192:	e9 35 f8 ff ff       	jmp    89cc <fwp_write+0x2cc>
    9197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    919e:	00 00 
    91a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    91a5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    91a9:	48 85 ff             	test   %rdi,%rdi
    91ac:	0f 84 e2 fd ff ff    	je     8f94 <fwp_write+0x894>
    91b2:	48 8d 35 49 60 00 00 	lea    0x6049(%rip),%rsi        # f202 <_IO_stdin_used+0x202>
    91b9:	e8 72 a3 ff ff       	call   3530 <strcmp@plt>
    91be:	85 c0                	test   %eax,%eax
    91c0:	0f 95 c0             	setne  %al
    91c3:	0f b6 c0             	movzbl %al,%eax
    91c6:	e9 c1 fd ff ff       	jmp    8f8c <fwp_write+0x88c>
    91cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    91d0:	31 c0                	xor    %eax,%eax
    91d2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    91d9:	00 
    91da:	0f 97 c0             	seta   %al
    91dd:	e9 aa fd ff ff       	jmp    8f8c <fwp_write+0x88c>
    91e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    91e8:	48 89 df             	mov    %rbx,%rdi
    91eb:	ba 02 00 00 00       	mov    $0x2,%edx
    91f0:	48 8d 35 08 60 00 00 	lea    0x6008(%rip),%rsi        # f1ff <_IO_stdin_used+0x1ff>
    91f7:	e8 14 b0 ff ff       	call   4210 <buf_put>
    91fc:	4c 89 e8             	mov    %r13,%rax
    91ff:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9204:	31 c9                	xor    %ecx,%ecx
    9206:	48 c1 e0 04          	shl    $0x4,%rax
    920a:	48 89 df             	mov    %rbx,%rdi
    920d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9212:	e8 e9 f4 ff ff       	call   8700 <fwp_write>
    9217:	e9 5e f6 ff ff       	jmp    887a <fwp_write+0x17a>
    921c:	0f 1f 40 00          	nopl   0x0(%rax)
    9220:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9225:	48 85 ff             	test   %rdi,%rdi
    9228:	79 0c                	jns    9236 <fwp_write+0xb36>
    922a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9231:	00 
    9232:	48 03 75 10          	add    0x10(%rbp),%rsi
    9236:	48 63 3e             	movslq (%rsi),%rdi
    9239:	83 f9 02             	cmp    $0x2,%ecx
    923c:	89 fe                	mov    %edi,%esi
    923e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9242:	e9 f9 fb ff ff       	jmp    8e40 <fwp_write+0x740>
    9247:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    924e:	00 00 
    9250:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9255:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    925a:	48 85 ff             	test   %rdi,%rdi
    925d:	0f 88 0f 03 00 00    	js     9572 <fwp_write+0xe72>
    9263:	49 0f bf 38          	movswq (%r8),%rdi
    9267:	83 f9 01             	cmp    $0x1,%ecx
    926a:	0f b7 f7             	movzwl %di,%esi
    926d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9271:	e9 ca fb ff ff       	jmp    8e40 <fwp_write+0x740>
    9276:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    927d:	00 00 00 
    9280:	ba 01 00 00 00       	mov    $0x1,%edx
    9285:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    928a:	48 83 c5 08          	add    $0x8,%rbp
    928e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9293:	e8 78 af ff ff       	call   4210 <buf_put>
    9298:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    929d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    92a2:	4d 85 ed             	test   %r13,%r13
    92a5:	75 46                	jne    92ed <fwp_write+0xbed>
    92a7:	e9 04 01 00 00       	jmp    93b0 <fwp_write+0xcb0>
    92ac:	0f 1f 40 00          	nopl   0x0(%rax)
    92b0:	41 80 f9 09          	cmp    $0x9,%r9b
    92b4:	0f 84 d6 00 00 00    	je     9390 <fwp_write+0xc90>
    92ba:	41 80 f9 0a          	cmp    $0xa,%r9b
    92be:	0f 85 9c 00 00 00    	jne    9360 <fwp_write+0xc60>
    92c4:	ba 02 00 00 00       	mov    $0x2,%edx
    92c9:	48 8d 35 0b 5f 00 00 	lea    0x5f0b(%rip),%rsi        # f1db <_IO_stdin_used+0x1db>
    92d0:	48 89 df             	mov    %rbx,%rdi
    92d3:	e8 38 af ff ff       	call   4210 <buf_put>
    92d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92df:	00 
    92e0:	48 83 c5 01          	add    $0x1,%rbp
    92e4:	49 39 ec             	cmp    %rbp,%r12
    92e7:	0f 84 c3 00 00 00    	je     93b0 <fwp_write+0xcb0>
    92ed:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    92f2:	41 80 f9 0d          	cmp    $0xd,%r9b
    92f6:	74 28                	je     9320 <fwp_write+0xc20>
    92f8:	7e b6                	jle    92b0 <fwp_write+0xbb0>
    92fa:	41 80 f9 22          	cmp    $0x22,%r9b
    92fe:	74 40                	je     9340 <fwp_write+0xc40>
    9300:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9304:	75 5a                	jne    9360 <fwp_write+0xc60>
    9306:	ba 02 00 00 00       	mov    $0x2,%edx
    930b:	48 8d 35 c6 5e 00 00 	lea    0x5ec6(%rip),%rsi        # f1d8 <_IO_stdin_used+0x1d8>
    9312:	48 89 df             	mov    %rbx,%rdi
    9315:	e8 f6 ae ff ff       	call   4210 <buf_put>
    931a:	eb c4                	jmp    92e0 <fwp_write+0xbe0>
    931c:	0f 1f 40 00          	nopl   0x0(%rax)
    9320:	ba 02 00 00 00       	mov    $0x2,%edx
    9325:	48 8d 35 b5 5e 00 00 	lea    0x5eb5(%rip),%rsi        # f1e1 <_IO_stdin_used+0x1e1>
    932c:	48 89 df             	mov    %rbx,%rdi
    932f:	e8 dc ae ff ff       	call   4210 <buf_put>
    9334:	eb aa                	jmp    92e0 <fwp_write+0xbe0>
    9336:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    933d:	00 00 00 
    9340:	ba 02 00 00 00       	mov    $0x2,%edx
    9345:	48 8d 35 89 5e 00 00 	lea    0x5e89(%rip),%rsi        # f1d5 <_IO_stdin_used+0x1d5>
    934c:	48 89 df             	mov    %rbx,%rdi
    934f:	e8 bc ae ff ff       	call   4210 <buf_put>
    9354:	eb 8a                	jmp    92e0 <fwp_write+0xbe0>
    9356:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    935d:	00 00 00 
    9360:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9364:	0f 86 2e 01 00 00    	jbe    9498 <fwp_write+0xd98>
    936a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    936e:	0f 84 24 01 00 00    	je     9498 <fwp_write+0xd98>
    9374:	ba 01 00 00 00       	mov    $0x1,%edx
    9379:	4c 89 fe             	mov    %r15,%rsi
    937c:	48 89 df             	mov    %rbx,%rdi
    937f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9384:	e8 87 ae ff ff       	call   4210 <buf_put>
    9389:	e9 52 ff ff ff       	jmp    92e0 <fwp_write+0xbe0>
    938e:	66 90                	xchg   %ax,%ax
    9390:	ba 02 00 00 00       	mov    $0x2,%edx
    9395:	48 8d 35 42 5e 00 00 	lea    0x5e42(%rip),%rsi        # f1de <_IO_stdin_used+0x1de>
    939c:	48 89 df             	mov    %rbx,%rdi
    939f:	e8 6c ae ff ff       	call   4210 <buf_put>
    93a4:	e9 37 ff ff ff       	jmp    92e0 <fwp_write+0xbe0>
    93a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    93b0:	ba 01 00 00 00       	mov    $0x1,%edx
    93b5:	4c 89 fe             	mov    %r15,%rsi
    93b8:	48 89 df             	mov    %rbx,%rdi
    93bb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    93c0:	e8 4b ae ff ff       	call   4210 <buf_put>
    93c5:	e9 cc f3 ff ff       	jmp    8796 <fwp_write+0x96>
    93ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93d0:	83 f8 04             	cmp    $0x4,%eax
    93d3:	0f 85 bb fb ff ff    	jne    8f94 <fwp_write+0x894>
    93d9:	48 8b 04 24          	mov    (%rsp),%rax
    93dd:	48 8b 40 08          	mov    0x8(%rax),%rax
    93e1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    93e6:	48 c1 e8 3f          	shr    $0x3f,%rax
    93ea:	e9 96 fc ff ff       	jmp    9085 <fwp_write+0x985>
    93ef:	90                   	nop
    93f0:	8b 0c 24             	mov    (%rsp),%ecx
    93f3:	31 c0                	xor    %eax,%eax
    93f5:	85 c9                	test   %ecx,%ecx
    93f7:	0f 98 c0             	sets   %al
    93fa:	e9 86 fc ff ff       	jmp    9085 <fwp_write+0x985>
    93ff:	90                   	nop
    9400:	48 f7 d8             	neg    %rax
    9403:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    940a:	00 
    940b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9412:	2d 
    9413:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    941a:	00 
    941b:	48 83 d2 00          	adc    $0x0,%rdx
    941f:	48 89 c6             	mov    %rax,%rsi
    9422:	48 f7 da             	neg    %rdx
    9425:	e8 16 a6 ff ff       	call   3a40 <fwp_fmt_u128>
    942a:	e9 51 f3 ff ff       	jmp    8780 <fwp_write+0x80>
    942f:	90                   	nop
    9430:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9435:	e9 c3 f5 ff ff       	jmp    89fd <fwp_write+0x2fd>
    943a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9440:	4c 89 e9             	mov    %r13,%rcx
    9443:	48 c1 e1 04          	shl    $0x4,%rcx
    9447:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    944c:	48 85 ff             	test   %rdi,%rdi
    944f:	0f 89 eb f9 ff ff    	jns    8e40 <fwp_write+0x740>
    9455:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9459:	48 89 ce             	mov    %rcx,%rsi
    945c:	e9 df f9 ff ff       	jmp    8e40 <fwp_write+0x740>
    9461:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9468:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    946f:	00 
    9470:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9474:	e9 20 fa ff ff       	jmp    8e99 <fwp_write+0x799>
    9479:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9480:	ba 02 00 00 00       	mov    $0x2,%edx
    9485:	48 8d 35 19 5d 00 00 	lea    0x5d19(%rip),%rsi        # f1a5 <_IO_stdin_used+0x1a5>
    948c:	e9 2d f7 ff ff       	jmp    8bbe <fwp_write+0x4be>
    9491:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9498:	4c 8d 05 45 5d 00 00 	lea    0x5d45(%rip),%r8        # f1e4 <_IO_stdin_used+0x1e4>
    949f:	b9 10 00 00 00       	mov    $0x10,%ecx
    94a4:	31 c0                	xor    %eax,%eax
    94a6:	ba 02 00 00 00       	mov    $0x2,%edx
    94ab:	be 10 00 00 00       	mov    $0x10,%esi
    94b0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    94b7:	00 
    94b8:	e8 f3 9e ff ff       	call   33b0 <__snprintf_chk@plt>
    94bd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    94c4:	00 
    94c5:	e8 86 9f ff ff       	call   3450 <strlen@plt>
    94ca:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    94d1:	00 
    94d2:	48 89 df             	mov    %rbx,%rdi
    94d5:	48 89 c2             	mov    %rax,%rdx
    94d8:	e8 33 ad ff ff       	call   4210 <buf_put>
    94dd:	e9 fe fd ff ff       	jmp    92e0 <fwp_write+0xbe0>
    94e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    94e8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    94ec:	48 8d 35 ac 5c 00 00 	lea    0x5cac(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    94f3:	48 8d 05 a4 5c 00 00 	lea    0x5ca4(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    94fa:	4c 89 e7             	mov    %r12,%rdi
    94fd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9501:	48 0f 46 f0          	cmovbe %rax,%rsi
    9505:	e8 e6 9e ff ff       	call   33f0 <strcpy@plt>
    950a:	e9 71 f2 ff ff       	jmp    8780 <fwp_write+0x80>
    950f:	90                   	nop
    9510:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9514:	48 8d 35 84 5c 00 00 	lea    0x5c84(%rip),%rsi        # f19f <_IO_stdin_used+0x19f>
    951b:	48 8d 05 7c 5c 00 00 	lea    0x5c7c(%rip),%rax        # f19e <_IO_stdin_used+0x19e>
    9522:	0f 2f c8             	comiss %xmm0,%xmm1
    9525:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    952c:	00 
    952d:	4c 89 e7             	mov    %r12,%rdi
    9530:	48 0f 46 f0          	cmovbe %rax,%rsi
    9534:	e8 b7 9e ff ff       	call   33f0 <strcpy@plt>
    9539:	e9 42 f2 ff ff       	jmp    8780 <fwp_write+0x80>
    953e:	66 90                	xchg   %ax,%ax
    9540:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9545:	45 85 c0             	test   %r8d,%r8d
    9548:	75 34                	jne    957e <fwp_write+0xe7e>
    954a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9551:	00 
    9552:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9559:	00 00 
    955b:	0f 85 74 f6 ff ff    	jne    8bd5 <fwp_write+0x4d5>
    9561:	ba 02 00 00 00       	mov    $0x2,%edx
    9566:	48 8d 35 a8 5c 00 00 	lea    0x5ca8(%rip),%rsi        # f215 <_IO_stdin_used+0x215>
    956d:	e9 a1 f3 ff ff       	jmp    8913 <fwp_write+0x213>
    9572:	48 03 75 10          	add    0x10(%rbp),%rsi
    9576:	49 89 f0             	mov    %rsi,%r8
    9579:	e9 e5 fc ff ff       	jmp    9263 <fwp_write+0xb63>
    957e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9583:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9588:	85 ff                	test   %edi,%edi
    958a:	0f 84 fa f3 ff ff    	je     898a <fwp_write+0x28a>
    9590:	ba 01 00 00 00       	mov    $0x1,%edx
    9595:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    959a:	48 89 df             	mov    %rbx,%rdi
    959d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    95a2:	e8 69 ac ff ff       	call   4210 <buf_put>
    95a7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    95ac:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    95b1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    95b7:	85 c0                	test   %eax,%eax
    95b9:	0f 8f f0 f3 ff ff    	jg     89af <fwp_write+0x2af>
    95bf:	e9 34 f4 ff ff       	jmp    89f8 <fwp_write+0x2f8>
    95c4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    95c8:	49 89 c5             	mov    %rax,%r13
    95cb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    95d0:	49 89 c4             	mov    %rax,%r12
    95d3:	49 c1 fd 3f          	sar    $0x3f,%r13
    95d7:	4c 09 e8             	or     %r13,%rax
    95da:	0f 84 a7 00 00 00    	je     9687 <fwp_write+0xf87>
    95e0:	48 8d 2d b9 7c 00 00 	lea    0x7cb9(%rip),%rbp        # 112a0 <units.0>
    95e7:	4d 89 e7             	mov    %r12,%r15
    95ea:	48 8b 45 08          	mov    0x8(%rbp),%rax
    95ee:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    95f3:	4c 89 ff             	mov    %r15,%rdi
    95f6:	4c 89 ee             	mov    %r13,%rsi
    95f9:	44 89 0c 24          	mov    %r9d,(%rsp)
    95fd:	48 99                	cqto
    95ff:	48 89 d1             	mov    %rdx,%rcx
    9602:	48 89 c2             	mov    %rax,%rdx
    9605:	e8 86 4e 00 00       	call   e490 <__divmodti4>
    960a:	44 8b 0c 24          	mov    (%rsp),%r9d
    960e:	48 89 c1             	mov    %rax,%rcx
    9611:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9616:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    961b:	0f 84 94 00 00 00    	je     96b5 <fwp_write+0xfb5>
    9621:	41 83 c1 01          	add    $0x1,%r9d
    9625:	48 83 c5 10          	add    $0x10,%rbp
    9629:	41 83 f9 05          	cmp    $0x5,%r9d
    962d:	75 bb                	jne    95ea <fwp_write+0xeea>
    962f:	4d 85 ed             	test   %r13,%r13
    9632:	79 53                	jns    9687 <fwp_write+0xf87>
    9634:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9639:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    963e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9643:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9648:	48 99                	cqto
    964a:	48 f7 d8             	neg    %rax
    964d:	48 83 d2 00          	adc    $0x0,%rdx
    9651:	48 89 c6             	mov    %rax,%rsi
    9654:	48 f7 da             	neg    %rdx
    9657:	e8 e4 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    965c:	49 89 e8             	mov    %rbp,%r8
    965f:	ba 00 02 00 00       	mov    $0x200,%edx
    9664:	be 02 00 00 00       	mov    $0x2,%esi
    9669:	31 c0                	xor    %eax,%eax
    966b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9672:	00 
    9673:	48 8d 0d 96 5b 00 00 	lea    0x5b96(%rip),%rcx        # f210 <_IO_stdin_used+0x210>
    967a:	4c 89 e7             	mov    %r12,%rdi
    967d:	e8 5e a0 ff ff       	call   36e0 <__sprintf_chk@plt>
    9682:	e9 f9 f0 ff ff       	jmp    8780 <fwp_write+0x80>
    9687:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    968c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9691:	31 d2                	xor    %edx,%edx
    9693:	48 89 ef             	mov    %rbp,%rdi
    9696:	e8 a5 a3 ff ff       	call   3a40 <fwp_fmt_u128>
    969b:	eb bf                	jmp    965c <fwp_write+0xf5c>
    969d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    96a4:	4e 61 4e 00 
    96a8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96af:	00 
    96b0:	e9 cb f0 ff ff       	jmp    8780 <fwp_write+0x80>
    96b5:	44 89 0c 24          	mov    %r9d,(%rsp)
    96b9:	48 89 c8             	mov    %rcx,%rax
    96bc:	48 85 d2             	test   %rdx,%rdx
    96bf:	78 51                	js     9712 <fwp_write+0x1012>
    96c1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    96c6:	48 89 c6             	mov    %rax,%rsi
    96c9:	48 89 ef             	mov    %rbp,%rdi
    96cc:	e8 6f a3 ff ff       	call   3a40 <fwp_fmt_u128>
    96d1:	44 8b 0c 24          	mov    (%rsp),%r9d
    96d5:	49 63 c1             	movslq %r9d,%rax
    96d8:	49 89 e8             	mov    %rbp,%r8
    96db:	ba 00 02 00 00       	mov    $0x200,%edx
    96e0:	be 02 00 00 00       	mov    $0x2,%esi
    96e5:	48 c1 e0 04          	shl    $0x4,%rax
    96e9:	48 8d 3d b0 7b 00 00 	lea    0x7bb0(%rip),%rdi        # 112a0 <units.0>
    96f0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    96f7:	00 
    96f8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    96fc:	48 8d 0d 08 5b 00 00 	lea    0x5b08(%rip),%rcx        # f20b <_IO_stdin_used+0x20b>
    9703:	4c 89 e7             	mov    %r12,%rdi
    9706:	31 c0                	xor    %eax,%eax
    9708:	e8 d3 9f ff ff       	call   36e0 <__sprintf_chk@plt>
    970d:	e9 6e f0 ff ff       	jmp    8780 <fwp_write+0x80>
    9712:	48 f7 d8             	neg    %rax
    9715:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    971a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    971f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9724:	48 83 d2 00          	adc    $0x0,%rdx
    9728:	48 89 c6             	mov    %rax,%rsi
    972b:	48 f7 da             	neg    %rdx
    972e:	e8 0d a3 ff ff       	call   3a40 <fwp_fmt_u128>
    9733:	44 8b 0c 24          	mov    (%rsp),%r9d
    9737:	eb 9c                	jmp    96d5 <fwp_write+0xfd5>
    9739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009740 <fwp_hof0.constprop.0>:
    9740:	41 57                	push   %r15
    9742:	41 56                	push   %r14
    9744:	41 55                	push   %r13
    9746:	41 54                	push   %r12
    9748:	55                   	push   %rbp
    9749:	53                   	push   %rbx
    974a:	48 81 ec 18 01 00 00 	sub    $0x118,%rsp
    9751:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9758:	00 00 
    975a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    9761:	00 
    9762:	31 c0                	xor    %eax,%eax
    9764:	48 85 f6             	test   %rsi,%rsi
    9767:	0f 84 2a 0f 00 00    	je     a697 <fwp_hof0.constprop.0+0xf57>
    976d:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
    9772:	48 8d 1d 47 a0 01 00 	lea    0x1a047(%rip),%rbx        # 237c0 <fwp_heap>
    9779:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
    977e:	66 90                	xchg   %ax,%ax
    9780:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9787:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    978c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9793:	48 c1 e2 10          	shl    $0x10,%rdx
    9797:	48 39 d0             	cmp    %rdx,%rax
    979a:	73 5d                	jae    97f9 <fwp_hof0.constprop.0+0xb9>
    979c:	48 89 c2             	mov    %rax,%rdx
    979f:	48 c1 ea 10          	shr    $0x10,%rdx
    97a3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    97a7:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    97ae:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    97b2:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    97b6:	48 85 ff             	test   %rdi,%rdi
    97b9:	74 3e                	je     97f9 <fwp_hof0.constprop.0+0xb9>
    97bb:	0f b6 0a             	movzbl (%rdx),%ecx
    97be:	80 f9 02             	cmp    $0x2,%cl
    97c1:	0f 84 09 15 00 00    	je     acd0 <fwp_hof0.constprop.0+0x1590>
    97c7:	80 f9 01             	cmp    $0x1,%cl
    97ca:	75 2d                	jne    97f9 <fwp_hof0.constprop.0+0xb9>
    97cc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    97cf:	0f b7 c0             	movzwl %ax,%eax
    97d2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    97d5:	48 0f af c1          	imul   %rcx,%rax
    97d9:	48 c1 e8 20          	shr    $0x20,%rax
    97dd:	48 39 d0             	cmp    %rdx,%rax
    97e0:	73 17                	jae    97f9 <fwp_hof0.constprop.0+0xb9>
    97e2:	48 01 c7             	add    %rax,%rdi
    97e5:	0f b6 07             	movzbl (%rdi),%eax
    97e8:	84 c0                	test   %al,%al
    97ea:	74 0d                	je     97f9 <fwp_hof0.constprop.0+0xb9>
    97ec:	3c fd                	cmp    $0xfd,%al
    97ee:	0f 87 08 17 00 00    	ja     aefc <fwp_hof0.constprop.0+0x17bc>
    97f4:	83 c0 01             	add    $0x1,%eax
    97f7:	88 07                	mov    %al,(%rdi)
    97f9:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    97fe:	45 31 c0             	xor    %r8d,%r8d
    9801:	48 c7 44 24 38 c6 00 	movq   $0xc6,0x38(%rsp)
    9808:	00 00 
    980a:	48 89 04 24          	mov    %rax,(%rsp)
    980e:	4d 89 c5             	mov    %r8,%r13
    9811:	4d 85 c0             	test   %r8,%r8
    9814:	0f 85 36 9f ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    981a:	48 8b 05 37 bc 01 00 	mov    0x1bc37(%rip),%rax        # 25458 <fwp_cleanups>
    9821:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9828:	4c 8d 3d 11 d8 ff ff 	lea    -0x27ef(%rip),%r15        # 7040 <fwp_tape_scope_release>
    982f:	c7 44 24 6c ff ff ff 	movl   $0xffffffff,0x6c(%rsp)
    9836:	ff 
    9837:	4c 89 7c 24 78       	mov    %r15,0x78(%rsp)
    983c:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    9841:	48 8d 44 24 6c       	lea    0x6c(%rsp),%rax
    9846:	48 c1 e2 10          	shl    $0x10,%rdx
    984a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    984f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9856:	00 
    9857:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    985c:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9861:	48 89 05 f0 bb 01 00 	mov    %rax,0x1bbf0(%rip)        # 25458 <fwp_cleanups>
    9868:	48 8d 05 a1 97 00 00 	lea    0x97a1(%rip),%rax        # 13010 <fc37>
    986f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9876:	48 39 d0             	cmp    %rdx,%rax
    9879:	73 5d                	jae    98d8 <fwp_hof0.constprop.0+0x198>
    987b:	48 89 c2             	mov    %rax,%rdx
    987e:	48 c1 ea 10          	shr    $0x10,%rdx
    9882:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9886:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    988d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9891:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9895:	48 85 ff             	test   %rdi,%rdi
    9898:	74 3e                	je     98d8 <fwp_hof0.constprop.0+0x198>
    989a:	0f b6 0a             	movzbl (%rdx),%ecx
    989d:	80 f9 02             	cmp    $0x2,%cl
    98a0:	0f 84 ca 12 00 00    	je     ab70 <fwp_hof0.constprop.0+0x1430>
    98a6:	80 f9 01             	cmp    $0x1,%cl
    98a9:	75 2d                	jne    98d8 <fwp_hof0.constprop.0+0x198>
    98ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    98ae:	0f b7 c0             	movzwl %ax,%eax
    98b1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    98b4:	48 0f af c1          	imul   %rcx,%rax
    98b8:	48 c1 e8 20          	shr    $0x20,%rax
    98bc:	48 39 d0             	cmp    %rdx,%rax
    98bf:	73 17                	jae    98d8 <fwp_hof0.constprop.0+0x198>
    98c1:	48 01 c7             	add    %rax,%rdi
    98c4:	0f b6 07             	movzbl (%rdi),%eax
    98c7:	84 c0                	test   %al,%al
    98c9:	74 0d                	je     98d8 <fwp_hof0.constprop.0+0x198>
    98cb:	3c fd                	cmp    $0xfd,%al
    98cd:	0f 87 68 15 00 00    	ja     ae3b <fwp_hof0.constprop.0+0x16fb>
    98d3:	83 c0 01             	add    $0x1,%eax
    98d6:	88 07                	mov    %al,(%rdi)
    98d8:	48 8d 3d 31 97 00 00 	lea    0x9731(%rip),%rdi        # 13010 <fc37>
    98df:	e8 2c d4 ff ff       	call   6d10 <fwp_closure_drop>
    98e4:	48 8b 04 24          	mov    (%rsp),%rax
    98e8:	48 85 c0             	test   %rax,%rax
    98eb:	0f 84 4f 14 00 00    	je     ad40 <fwp_hof0.constprop.0+0x1600>
    98f1:	31 ed                	xor    %ebp,%ebp
    98f3:	66 90                	xchg   %ax,%ax
    98f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98fc:	00 00 00 00 
    9900:	48 8b 40 10          	mov    0x10(%rax),%rax
    9904:	48 83 c5 01          	add    $0x1,%rbp
    9908:	48 85 c0             	test   %rax,%rax
    990b:	75 f3                	jne    9900 <fwp_hof0.constprop.0+0x1c0>
    990d:	31 ff                	xor    %edi,%edi
    990f:	e8 3c a9 ff ff       	call   4250 <descent_phase_step>
    9914:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    991b:	0f 87 19 16 00 00    	ja     af3a <fwp_hof0.constprop.0+0x17fa>
    9921:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    9926:	8b 35 34 97 00 00    	mov    0x9734(%rip),%esi        # 13060 <registered_finish.1>
    992c:	85 f6                	test   %esi,%esi
    992e:	0f 84 f4 11 00 00    	je     ab28 <fwp_hof0.constprop.0+0x13e8>
    9934:	48 8b 15 9d 97 01 00 	mov    0x1979d(%rip),%rdx        # 230d8 <fwp_tape_next_slot>
    993b:	48 8b 2d a6 97 01 00 	mov    0x197a6(%rip),%rbp        # 230e8 <fwp_ntapes>
    9942:	48 39 d5             	cmp    %rdx,%rbp
    9945:	0f 8e c5 10 00 00    	jle    aa10 <fwp_hof0.constprop.0+0x12d0>
    994b:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    994f:	48 03 05 9a 97 01 00 	add    0x1979a(%rip),%rax        # 230f0 <fwp_tapes>
    9956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    995d:	00 00 00 
    9960:	8b 48 04             	mov    0x4(%rax),%ecx
    9963:	85 c9                	test   %ecx,%ecx
    9965:	75 0c                	jne    9973 <fwp_hof0.constprop.0+0x233>
    9967:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    996d:	0f 86 9d 10 00 00    	jbe    aa10 <fwp_hof0.constprop.0+0x12d0>
    9973:	48 83 c2 01          	add    $0x1,%rdx
    9977:	48 83 c0 68          	add    $0x68,%rax
    997b:	48 39 d5             	cmp    %rdx,%rbp
    997e:	75 e0                	jne    9960 <fwp_hof0.constprop.0+0x220>
    9980:	48 81 fd fe ff 00 00 	cmp    $0xfffe,%rbp
    9987:	0f 8f 2f 16 00 00    	jg     afbc <fwp_hof0.constprop.0+0x187c>
    998d:	48 39 2d 4c 97 01 00 	cmp    %rbp,0x1974c(%rip)        # 230e0 <fwp_tapes_cap>
    9994:	4c 8b 0d 55 97 01 00 	mov    0x19755(%rip),%r9        # 230f0 <fwp_tapes>
    999b:	75 4c                	jne    99e9 <fwp_hof0.constprop.0+0x2a9>
    999d:	48 85 ed             	test   %rbp,%rbp
    99a0:	0f 84 8a 13 00 00    	je     ad30 <fwp_hof0.constprop.0+0x15f0>
    99a6:	4c 8d 64 2d 00       	lea    0x0(%rbp,%rbp,1),%r12
    99ab:	b8 ff ff 00 00       	mov    $0xffff,%eax
    99b0:	49 39 c4             	cmp    %rax,%r12
    99b3:	4c 0f 4f e0          	cmovg  %rax,%r12
    99b7:	49 6b f4 68          	imul   $0x68,%r12,%rsi
    99bb:	4c 89 cf             	mov    %r9,%rdi
    99be:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    99c4:	e8 07 9c ff ff       	call   35d0 <realloc@plt>
    99c9:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    99cf:	48 85 c0             	test   %rax,%rax
    99d2:	49 89 c1             	mov    %rax,%r9
    99d5:	0f 84 ed 15 00 00    	je     afc8 <fwp_hof0.constprop.0+0x1888>
    99db:	48 89 05 0e 97 01 00 	mov    %rax,0x1970e(%rip)        # 230f0 <fwp_tapes>
    99e2:	4c 89 25 f7 96 01 00 	mov    %r12,0x196f7(%rip)        # 230e0 <fwp_tapes_cap>
    99e9:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    99ed:	31 c0                	xor    %eax,%eax
    99ef:	4c 8d 65 01          	lea    0x1(%rbp),%r12
    99f3:	4c 01 c9             	add    %r9,%rcx
    99f6:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    99fa:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9a01:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9a05:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9a0c:	00 
    9a0d:	48 29 f9             	sub    %rdi,%rcx
    9a10:	83 c1 68             	add    $0x68,%ecx
    9a13:	c1 e9 03             	shr    $0x3,%ecx
    9a16:	f3 48 ab             	rep stos %rax,(%rdi)
    9a19:	4c 89 25 c8 96 01 00 	mov    %r12,0x196c8(%rip)        # 230e8 <fwp_ntapes>
    9a20:	48 6b cd 68          	imul   $0x68,%rbp,%rcx
    9a24:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9a28:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    9a2d:	48 8d 3d ee 56 00 00 	lea    0x56ee(%rip),%rdi        # f122 <_IO_stdin_used+0x122>
    9a34:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9a39:	4c 01 c9             	add    %r9,%rcx
    9a3c:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9a43:	00 
    9a44:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    9a49:	e8 52 99 ff ff       	call   33a0 <getenv@plt>
    9a4e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9a53:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    9a58:	48 85 c0             	test   %rax,%rax
    9a5b:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    9a61:	0f 84 09 0d 00 00    	je     a770 <fwp_hof0.constprop.0+0x1030>
    9a67:	80 38 30             	cmpb   $0x30,(%rax)
    9a6a:	0f 85 00 0d 00 00    	jne    a770 <fwp_hof0.constprop.0+0x1030>
    9a70:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9a74:	0f 85 f6 0c 00 00    	jne    a770 <fwp_hof0.constprop.0+0x1030>
    9a7a:	8b 01                	mov    (%rcx),%eax
    9a7c:	c7 41 04 01 00 00 00 	movl   $0x1,0x4(%rcx)
    9a83:	4c 89 25 4e 96 01 00 	mov    %r12,0x1964e(%rip)        # 230d8 <fwp_tape_next_slot>
    9a8a:	44 8d 70 01          	lea    0x1(%rax),%r14d
    9a8e:	48 8b 05 fb 60 00 00 	mov    0x60fb(%rip),%rax        # fb90 <msg.4+0x20>
    9a95:	48 c7 41 50 00 00 00 	movq   $0x0,0x50(%rcx)
    9a9c:	00 
    9a9d:	44 89 31             	mov    %r14d,(%rcx)
    9aa0:	48 89 41 58          	mov    %rax,0x58(%rcx)
    9aa4:	48 8b 05 ad b9 01 00 	mov    0x1b9ad(%rip),%rax        # 25458 <fwp_cleanups>
    9aab:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
    9aaf:	48 85 c0             	test   %rax,%rax
    9ab2:	75 18                	jne    9acc <fwp_hof0.constprop.0+0x38c>
    9ab4:	e9 a7 14 00 00       	jmp    af60 <fwp_hof0.constprop.0+0x1820>
    9ab9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9ac0:	48 8b 00             	mov    (%rax),%rax
    9ac3:	48 85 c0             	test   %rax,%rax
    9ac6:	0f 84 94 14 00 00    	je     af60 <fwp_hof0.constprop.0+0x1820>
    9acc:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    9ad0:	75 ee                	jne    9ac0 <fwp_hof0.constprop.0+0x380>
    9ad2:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9ad6:	89 ee                	mov    %ebp,%esi
    9ad8:	48 63 07             	movslq (%rdi),%rax
    9adb:	48 89 79 50          	mov    %rdi,0x50(%rcx)
    9adf:	89 41 5c             	mov    %eax,0x5c(%rcx)
    9ae2:	85 c0                	test   %eax,%eax
    9ae4:	78 09                	js     9aef <fwp_hof0.constprop.0+0x3af>
    9ae6:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9aea:	41 89 6c 01 58       	mov    %ebp,0x58(%r9,%rax,1)
    9aef:	89 37                	mov    %esi,(%rdi)
    9af1:	bf 01 00 00 00       	mov    $0x1,%edi
    9af6:	31 ed                	xor    %ebp,%ebp
    9af8:	e8 53 a7 ff ff       	call   4250 <descent_phase_step>
    9afd:	48 8b 3c 24          	mov    (%rsp),%rdi
    9b01:	48 89 f8             	mov    %rdi,%rax
    9b04:	48 85 ff             	test   %rdi,%rdi
    9b07:	0f 84 c3 0d 00 00    	je     a8d0 <fwp_hof0.constprop.0+0x1190>
    9b0d:	0f 1f 00             	nopl   (%rax)
    9b10:	48 8b 40 10          	mov    0x10(%rax),%rax
    9b14:	48 83 c5 01          	add    $0x1,%rbp
    9b18:	48 85 c0             	test   %rax,%rax
    9b1b:	75 f3                	jne    9b10 <fwp_hof0.constprop.0+0x3d0>
    9b1d:	48 8b 0c 24          	mov    (%rsp),%rcx
    9b21:	0f 1f 40 00          	nopl   0x0(%rax)
    9b25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b2c:	00 00 00 00 
    9b30:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    9b34:	48 83 c0 01          	add    $0x1,%rax
    9b38:	48 85 c9             	test   %rcx,%rcx
    9b3b:	75 f3                	jne    9b30 <fwp_hof0.constprop.0+0x3f0>
    9b3d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9b44:	ff ff 1f 
    9b47:	48 39 c1             	cmp    %rax,%rcx
    9b4a:	0f 82 02 14 00 00    	jb     af52 <fwp_hof0.constprop.0+0x1812>
    9b50:	48 85 ed             	test   %rbp,%rbp
    9b53:	0f 8e 77 0d 00 00    	jle    a8d0 <fwp_hof0.constprop.0+0x1190>
    9b59:	48 39 c5             	cmp    %rax,%rbp
    9b5c:	48 0f 47 e8          	cmova  %rax,%rbp
    9b60:	48 89 e8             	mov    %rbp,%rax
    9b63:	48 c1 e8 3c          	shr    $0x3c,%rax
    9b67:	0f 85 e5 13 00 00    	jne    af52 <fwp_hof0.constprop.0+0x1812>
    9b6d:	44 89 f2             	mov    %r14d,%edx
    9b70:	4c 8d 7c 2d 00       	lea    0x0(%rbp,%rbp,1),%r15
    9b75:	be 02 00 00 00       	mov    $0x2,%esi
    9b7a:	48 c1 e2 10          	shl    $0x10,%rdx
    9b7e:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    9b85:	00 
    9b86:	4c 09 e2             	or     %r12,%rdx
    9b89:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9b8e:	e8 fd c0 ff ff       	call   5c90 <fwp_heap_alloc>
    9b93:	4c 89 38             	mov    %r15,(%rax)
    9b96:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9b9d:	49 89 c6             	mov    %rax,%r14
    9ba0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9ba7:	48 c1 e2 10          	shl    $0x10,%rdx
    9bab:	48 39 d0             	cmp    %rdx,%rax
    9bae:	0f 83 ec 10 00 00    	jae    aca0 <fwp_hof0.constprop.0+0x1560>
    9bb4:	48 89 c2             	mov    %rax,%rdx
    9bb7:	48 c1 ea 10          	shr    $0x10,%rdx
    9bbb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bbf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9bc6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bca:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9bce:	4d 85 ff             	test   %r15,%r15
    9bd1:	74 38                	je     9c0b <fwp_hof0.constprop.0+0x4cb>
    9bd3:	0f b6 0a             	movzbl (%rdx),%ecx
    9bd6:	80 f9 02             	cmp    $0x2,%cl
    9bd9:	0f 84 65 0d 00 00    	je     a944 <fwp_hof0.constprop.0+0x1204>
    9bdf:	80 f9 01             	cmp    $0x1,%cl
    9be2:	75 27                	jne    9c0b <fwp_hof0.constprop.0+0x4cb>
    9be4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9be7:	0f b7 c0             	movzwl %ax,%eax
    9bea:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bed:	48 0f af c1          	imul   %rcx,%rax
    9bf1:	48 c1 e8 20          	shr    $0x20,%rax
    9bf5:	48 39 d0             	cmp    %rdx,%rax
    9bf8:	73 11                	jae    9c0b <fwp_hof0.constprop.0+0x4cb>
    9bfa:	49 01 c7             	add    %rax,%r15
    9bfd:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9c01:	0f 84 50 0d 00 00    	je     a957 <fwp_hof0.constprop.0+0x1217>
    9c07:	41 c6 07 01          	movb   $0x1,(%r15)
    9c0b:	48 85 ed             	test   %rbp,%rbp
    9c0e:	74 64                	je     9c74 <fwp_hof0.constprop.0+0x534>
    9c10:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9c15:	48 8b 14 24          	mov    (%rsp),%rdx
    9c19:	31 c0                	xor    %eax,%eax
    9c1b:	48 c1 e1 20          	shl    $0x20,%rcx
    9c1f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c26:	00 00 00 00 
    9c2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c31:	00 00 00 00 
    9c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9c3c:	00 00 00 00 
    9c40:	48 89 c6             	mov    %rax,%rsi
    9c43:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9c48:	48 01 ce             	add    %rcx,%rsi
    9c4b:	0f 80 ff 9a ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    9c51:	66 48 0f 6e de       	movq   %rsi,%xmm3
    9c56:	48 89 c6             	mov    %rax,%rsi
    9c59:	48 83 c0 01          	add    $0x1,%rax
    9c5d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9c61:	48 c1 e6 04          	shl    $0x4,%rsi
    9c65:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    9c6b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9c6f:	48 39 e8             	cmp    %rbp,%rax
    9c72:	72 cc                	jb     9c40 <fwp_hof0.constprop.0+0x500>
    9c74:	49 8b 06             	mov    (%r14),%rax
    9c77:	48 d1 e8             	shr    $1,%rax
    9c7a:	0f 85 00 0d 00 00    	jne    a980 <fwp_hof0.constprop.0+0x1240>
    9c80:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
    9c87:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    9c8e:	66 90                	xchg   %ax,%ax
    9c90:	4c 89 f7             	mov    %r14,%rdi
    9c93:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    9c98:	e8 d3 e2 ff ff       	call   7f70 <fwp_drop10>
    9c9d:	bf 02 00 00 00       	mov    $0x2,%edi
    9ca2:	e8 a9 a5 ff ff       	call   4250 <descent_phase_step>
    9ca7:	4c 63 7c 24 08       	movslq 0x8(%rsp),%r15
    9cac:	4c 89 ff             	mov    %r15,%rdi
    9caf:	e8 1c aa ff ff       	call   46d0 <fwp_tape_of>
    9cb4:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    9cb9:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    9cbe:	48 89 c6             	mov    %rax,%rsi
    9cc1:	0f 85 2f 13 00 00    	jne    aff6 <fwp_hof0.constprop.0+0x18b6>
    9cc7:	48 89 c7             	mov    %rax,%rdi
    9cca:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    9ccf:	e8 2c 9f ff ff       	call   3c00 <fwp_tape_unlink_scope>
    9cd4:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    9cd9:	48 8b 6e 48          	mov    0x48(%rsi),%rbp
    9cdd:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    9ce4:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    9ce9:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    9cee:	0f 29 74 24 20       	movaps %xmm6,0x20(%rsp)
    9cf3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    9cf9:	66 48 0f 6e f5       	movq   %rbp,%xmm6
    9cfe:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    9d02:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    9d06:	4c 8b 4e 40          	mov    0x40(%rsi),%r9
    9d0a:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    9d0f:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9d13:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    9d18:	77 1a                	ja     9d34 <fwp_hof0.constprop.0+0x5f4>
    9d1a:	0f b7 44 24 08       	movzwl 0x8(%rsp),%eax
    9d1f:	83 e8 01             	sub    $0x1,%eax
    9d22:	48 98                	cltq
    9d24:	48 3b 05 ad 93 01 00 	cmp    0x193ad(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    9d2b:	7d 07                	jge    9d34 <fwp_hof0.constprop.0+0x5f4>
    9d2d:	48 89 05 a4 93 01 00 	mov    %rax,0x193a4(%rip)        # 230d8 <fwp_tape_next_slot>
    9d34:	66 0f ef c9          	pxor   %xmm1,%xmm1
    9d38:	48 8b 05 19 b7 01 00 	mov    0x1b719(%rip),%rax        # 25458 <fwp_cleanups>
    9d3f:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    9d45:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    9d4c:	00 
    9d4d:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    9d51:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    9d57:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9d5e:	00 
    9d5f:	48 8d 05 0a b3 ff ff 	lea    -0x4cf6(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    9d66:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    9d6d:	00 
    9d6e:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    9d75:	00 
    9d76:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9d7b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9d82:	00 
    9d83:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    9d8a:	00 
    9d8b:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    9d92:	00 
    9d93:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    9d9a:	00 
    9d9b:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    9d9f:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    9da3:	48 89 05 ae b6 01 00 	mov    %rax,0x1b6ae(%rip)        # 25458 <fwp_cleanups>
    9daa:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    9db1:	00 
    9db2:	0f 29 bc 24 b0 00 00 	movaps %xmm7,0xb0(%rsp)
    9db9:	00 
    9dba:	0f 29 b4 24 c0 00 00 	movaps %xmm6,0xc0(%rsp)
    9dc1:	00 
    9dc2:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
    9dc9:	00 
    9dca:	48 85 c9             	test   %rcx,%rcx
    9dcd:	0f 88 ad 0d 00 00    	js     ab80 <fwp_hof0.constprop.0+0x1440>
    9dd3:	48 89 c8             	mov    %rcx,%rax
    9dd6:	48 c1 f8 20          	sar    $0x20,%rax
    9dda:	49 39 c7             	cmp    %rax,%r15
    9ddd:	0f 85 2b 11 00 00    	jne    af0e <fwp_hof0.constprop.0+0x17ce>
    9de3:	41 89 cb             	mov    %ecx,%r11d
    9de6:	4d 89 df             	mov    %r11,%r15
    9de9:	4c 39 da             	cmp    %r11,%rdx
    9dec:	0f 8e 28 11 00 00    	jle    af1a <fwp_hof0.constprop.0+0x17da>
    9df2:	4d 39 de             	cmp    %r11,%r14
    9df5:	0f 8e 55 0c 00 00    	jle    aa50 <fwp_hof0.constprop.0+0x1310>
    9dfb:	49 39 ee             	cmp    %rbp,%r14
    9dfe:	0f 8f 8c 0c 00 00    	jg     aa90 <fwp_hof0.constprop.0+0x1350>
    9e04:	4d 85 c9             	test   %r9,%r9
    9e07:	0f 84 68 11 00 00    	je     af75 <fwp_hof0.constprop.0+0x1835>
    9e0d:	4c 89 cf             	mov    %r9,%rdi
    9e10:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    9e17:	00 
    9e18:	31 f6                	xor    %esi,%esi
    9e1a:	31 ed                	xor    %ebp,%ebp
    9e1c:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    9e21:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    9e25:	e8 96 96 ff ff       	call   34c0 <memset@plt>
    9e2a:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    9e2f:	49 89 c1             	mov    %rax,%r9
    9e32:	f2 0f 10 05 5e 5d 00 	movsd  0x5d5e(%rip),%xmm0        # fb98 <msg.4+0x28>
    9e39:	00 
    9e3a:	f2 43 0f 58 04 d9    	addsd  (%r9,%r11,8),%xmm0
    9e40:	f2 43 0f 11 04 d9    	movsd  %xmm0,(%r9,%r11,8)
    9e46:	bf 03 00 00 00       	mov    $0x3,%edi
    9e4b:	4c 01 35 ae 92 01 00 	add    %r14,0x192ae(%rip)        # 23100 <descent_inputs>
    9e52:	48 01 2d af 92 01 00 	add    %rbp,0x192af(%rip)        # 23108 <descent_nodes>
    9e59:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    9e5e:	e8 ed a3 ff ff       	call   4250 <descent_phase_step>
    9e63:	4d 39 f7             	cmp    %r14,%r15
    9e66:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    9e6b:	0f 8c 88 00 00 00    	jl     9ef9 <fwp_hof0.constprop.0+0x7b9>
    9e71:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    9e76:	4d 29 f7             	sub    %r14,%r15
    9e79:	4b 8d 2c f1          	lea    (%r9,%r14,8),%rbp
    9e7d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9e81:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
    9e86:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    9e8b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    9e90:	4b 8d 14 fb          	lea    (%r11,%r15,8),%rdx
    9e94:	4c 29 dd             	sub    %r11,%rbp
    9e97:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    9e9b:	48 29 f1             	sub    %rsi,%rcx
    9e9e:	4c 29 df             	sub    %r11,%rdi
    9ea1:	eb 09                	jmp    9eac <fwp_hof0.constprop.0+0x76c>
    9ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ea8:	48 83 e8 04          	sub    $0x4,%rax
    9eac:	f2 0f 10 44 15 00    	movsd  0x0(%rbp,%rdx,1),%xmm0
    9eb2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    9eb6:	7a 02                	jp     9eba <fwp_hof0.constprop.0+0x77a>
    9eb8:	74 36                	je     9ef0 <fwp_hof0.constprop.0+0x7b0>
    9eba:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    9ebe:	45 85 c0             	test   %r8d,%r8d
    9ec1:	78 15                	js     9ed8 <fwp_hof0.constprop.0+0x798>
    9ec3:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    9ec8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    9ecc:	f2 43 0f 58 0c c1    	addsd  (%r9,%r8,8),%xmm1
    9ed2:	f2 43 0f 11 0c c1    	movsd  %xmm1,(%r9,%r8,8)
    9ed8:	4c 63 00             	movslq (%rax),%r8
    9edb:	45 85 c0             	test   %r8d,%r8d
    9ede:	78 10                	js     9ef0 <fwp_hof0.constprop.0+0x7b0>
    9ee0:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    9ee4:	f2 43 0f 58 04 c1    	addsd  (%r9,%r8,8),%xmm0
    9eea:	f2 43 0f 11 04 c1    	movsd  %xmm0,(%r9,%r8,8)
    9ef0:	48 83 ea 08          	sub    $0x8,%rdx
    9ef4:	48 39 c6             	cmp    %rax,%rsi
    9ef7:	75 af                	jne    9ea8 <fwp_hof0.constprop.0+0x768>
    9ef9:	bf 04 00 00 00       	mov    $0x4,%edi
    9efe:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    9f03:	e8 48 a3 ff ff       	call   4250 <descent_phase_step>
    9f08:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9f0f:	ff ff 1f 
    9f12:	4c 39 f0             	cmp    %r14,%rax
    9f15:	0f 82 2b 10 00 00    	jb     af46 <fwp_hof0.constprop.0+0x1806>
    9f1b:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    9f22:	00 
    9f23:	be 02 00 00 00       	mov    $0x2,%esi
    9f28:	e8 63 bd ff ff       	call   5c90 <fwp_heap_alloc>
    9f2d:	4d 85 f6             	test   %r14,%r14
    9f30:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    9f35:	4c 89 30             	mov    %r14,(%rax)
    9f38:	49 89 c7             	mov    %rax,%r15
    9f3b:	74 15                	je     9f52 <fwp_hof0.constprop.0+0x812>
    9f3d:	0f 1f 00             	nopl   (%rax)
    9f40:	4b 8b 04 e9          	mov    (%r9,%r13,8),%rax
    9f44:	4b 89 44 ef 08       	mov    %rax,0x8(%r15,%r13,8)
    9f49:	49 83 c5 01          	add    $0x1,%r13
    9f4d:	4d 39 ee             	cmp    %r13,%r14
    9f50:	75 ee                	jne    9f40 <fwp_hof0.constprop.0+0x800>
    9f52:	bf 05 00 00 00       	mov    $0x5,%edi
    9f57:	e8 f4 a2 ff ff       	call   4250 <descent_phase_step>
    9f5c:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
    9f63:	00 
    9f64:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    9f69:	4c 89 25 e8 b4 01 00 	mov    %r12,0x1b4e8(%rip)        # 25458 <fwp_cleanups>
    9f70:	e8 fb b0 ff ff       	call   5070 <fwp_tape_buffers_release>
    9f75:	bf 06 00 00 00       	mov    $0x6,%edi
    9f7a:	e8 d1 a2 ff ff       	call   4250 <descent_phase_step>
    9f7f:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    9f86:	4c 89 f8             	mov    %r15,%rax
    9f89:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    9f90:	48 c1 e2 10          	shl    $0x10,%rdx
    9f94:	48 39 d0             	cmp    %rdx,%rax
    9f97:	73 57                	jae    9ff0 <fwp_hof0.constprop.0+0x8b0>
    9f99:	48 89 c2             	mov    %rax,%rdx
    9f9c:	48 c1 ea 10          	shr    $0x10,%rdx
    9fa0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9fa4:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9fab:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9faf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9fb3:	48 85 ed             	test   %rbp,%rbp
    9fb6:	74 38                	je     9ff0 <fwp_hof0.constprop.0+0x8b0>
    9fb8:	0f b6 0a             	movzbl (%rdx),%ecx
    9fbb:	80 f9 02             	cmp    $0x2,%cl
    9fbe:	0f 84 ec 0b 00 00    	je     abb0 <fwp_hof0.constprop.0+0x1470>
    9fc4:	80 f9 01             	cmp    $0x1,%cl
    9fc7:	75 27                	jne    9ff0 <fwp_hof0.constprop.0+0x8b0>
    9fc9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fcc:	0f b7 c0             	movzwl %ax,%eax
    9fcf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fd2:	48 0f af c1          	imul   %rcx,%rax
    9fd6:	48 c1 e8 20          	shr    $0x20,%rax
    9fda:	48 39 d0             	cmp    %rdx,%rax
    9fdd:	73 11                	jae    9ff0 <fwp_hof0.constprop.0+0x8b0>
    9fdf:	48 01 c5             	add    %rax,%rbp
    9fe2:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9fe6:	0f 84 d7 0b 00 00    	je     abc3 <fwp_hof0.constprop.0+0x1483>
    9fec:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9ff0:	4c 3b 64 24 48       	cmp    0x48(%rsp),%r12
    9ff5:	0f 85 50 97 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    9ffb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    a000:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a005:	48 89 05 4c b4 01 00 	mov    %rax,0x1b44c(%rip)        # 25458 <fwp_cleanups>
    a00c:	e8 2f d0 ff ff       	call   7040 <fwp_tape_scope_release>
    a011:	49 8b 07             	mov    (%r15),%rax
    a014:	49 89 c6             	mov    %rax,%r14
    a017:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a01c:	48 85 c0             	test   %rax,%rax
    a01f:	0f 88 db 07 00 00    	js     a800 <fwp_hof0.constprop.0+0x10c0>
    a025:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a02c:	4c 89 f8             	mov    %r15,%rax
    a02f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a036:	48 c1 e2 10          	shl    $0x10,%rdx
    a03a:	48 39 d0             	cmp    %rdx,%rax
    a03d:	0f 83 bd 07 00 00    	jae    a800 <fwp_hof0.constprop.0+0x10c0>
    a043:	48 89 c2             	mov    %rax,%rdx
    a046:	48 c1 ea 10          	shr    $0x10,%rdx
    a04a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a04e:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a055:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a059:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a05d:	48 85 c9             	test   %rcx,%rcx
    a060:	0f 84 9a 07 00 00    	je     a800 <fwp_hof0.constprop.0+0x10c0>
    a066:	0f b6 32             	movzbl (%rdx),%esi
    a069:	40 80 fe 02          	cmp    $0x2,%sil
    a06d:	0f 84 7d 07 00 00    	je     a7f0 <fwp_hof0.constprop.0+0x10b0>
    a073:	40 80 fe 01          	cmp    $0x1,%sil
    a077:	0f 85 83 07 00 00    	jne    a800 <fwp_hof0.constprop.0+0x10c0>
    a07d:	8b 72 18             	mov    0x18(%rdx),%esi
    a080:	0f b7 c0             	movzwl %ax,%eax
    a083:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a086:	48 0f af c6          	imul   %rsi,%rax
    a08a:	48 c1 e8 20          	shr    $0x20,%rax
    a08e:	48 39 d0             	cmp    %rdx,%rax
    a091:	0f 83 69 07 00 00    	jae    a800 <fwp_hof0.constprop.0+0x10c0>
    a097:	48 01 c1             	add    %rax,%rcx
    a09a:	80 39 01             	cmpb   $0x1,(%rcx)
    a09d:	0f 85 5d 07 00 00    	jne    a800 <fwp_hof0.constprop.0+0x10c0>
    a0a3:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
    a0a8:	4d 89 fc             	mov    %r15,%r12
    a0ab:	31 ff                	xor    %edi,%edi
    a0ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a0b2:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a0b6:	31 c0                	xor    %eax,%eax
    a0b8:	4d 85 f6             	test   %r14,%r14
    a0bb:	75 2d                	jne    a0ea <fwp_hof0.constprop.0+0x9aa>
    a0bd:	eb 41                	jmp    a100 <fwp_hof0.constprop.0+0x9c0>
    a0bf:	90                   	nop
    a0c0:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a0c5:	0f 88 5b 0e 00 00    	js     af26 <fwp_hof0.constprop.0+0x17e6>
    a0cb:	f2 0f 10 05 e5 5a 00 	movsd  0x5ae5(%rip),%xmm0        # fbb8 <msg.4+0x48>
    a0d2:	00 
    a0d3:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a0d8:	48 83 c0 01          	add    $0x1,%rax
    a0dc:	48 83 c2 08          	add    $0x8,%rdx
    a0e0:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a0e5:	49 39 c6             	cmp    %rax,%r14
    a0e8:	74 16                	je     a100 <fwp_hof0.constprop.0+0x9c0>
    a0ea:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a0ee:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a0f2:	79 cc                	jns    a0c0 <fwp_hof0.constprop.0+0x980>
    a0f4:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a0f8:	eb c6                	jmp    a0c0 <fwp_hof0.constprop.0+0x980>
    a0fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a100:	e8 6b de ff ff       	call   7f70 <fwp_drop10>
    a105:	48 8b 3c 24          	mov    (%rsp),%rdi
    a109:	31 d2                	xor    %edx,%edx
    a10b:	48 89 f8             	mov    %rdi,%rax
    a10e:	48 85 ff             	test   %rdi,%rdi
    a111:	0f 84 39 0c 00 00    	je     ad50 <fwp_hof0.constprop.0+0x1610>
    a117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a11e:	00 00 
    a120:	48 8b 40 10          	mov    0x10(%rax),%rax
    a124:	48 83 c2 01          	add    $0x1,%rdx
    a128:	48 85 c0             	test   %rax,%rax
    a12b:	75 f3                	jne    a120 <fwp_hof0.constprop.0+0x9e0>
    a12d:	49 8b 04 24          	mov    (%r12),%rax
    a131:	49 89 c7             	mov    %rax,%r15
    a134:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a139:	48 85 c0             	test   %rax,%rax
    a13c:	0f 88 9a 05 00 00    	js     a6dc <fwp_hof0.constprop.0+0xf9c>
    a142:	48 8b 83 d8 13 00 00 	mov    0x13d8(%rbx),%rax
    a149:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a14e:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    a155:	48 c1 e0 10          	shl    $0x10,%rax
    a159:	48 39 c1             	cmp    %rax,%rcx
    a15c:	0f 83 7a 05 00 00    	jae    a6dc <fwp_hof0.constprop.0+0xf9c>
    a162:	48 89 c8             	mov    %rcx,%rax
    a165:	48 c1 e8 10          	shr    $0x10,%rax
    a169:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a16d:	48 8b 83 f8 13 00 00 	mov    0x13f8(%rbx),%rax
    a174:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a178:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a17c:	48 85 ff             	test   %rdi,%rdi
    a17f:	0f 84 57 05 00 00    	je     a6dc <fwp_hof0.constprop.0+0xf9c>
    a185:	0f b6 06             	movzbl (%rsi),%eax
    a188:	3c 02                	cmp    $0x2,%al
    a18a:	0f 84 38 05 00 00    	je     a6c8 <fwp_hof0.constprop.0+0xf88>
    a190:	3c 01                	cmp    $0x1,%al
    a192:	0f 85 39 05 00 00    	jne    a6d1 <fwp_hof0.constprop.0+0xf91>
    a198:	8b 46 18             	mov    0x18(%rsi),%eax
    a19b:	0f b7 c9             	movzwl %cx,%ecx
    a19e:	48 0f af c8          	imul   %rax,%rcx
    a1a2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a1a5:	48 c1 e9 20          	shr    $0x20,%rcx
    a1a9:	48 39 c1             	cmp    %rax,%rcx
    a1ac:	0f 83 1f 05 00 00    	jae    a6d1 <fwp_hof0.constprop.0+0xf91>
    a1b2:	48 01 cf             	add    %rcx,%rdi
    a1b5:	80 3f 01             	cmpb   $0x1,(%rdi)
    a1b8:	0f 85 13 05 00 00    	jne    a6d1 <fwp_hof0.constprop.0+0xf91>
    a1be:	49 39 d7             	cmp    %rdx,%r15
    a1c1:	48 89 d0             	mov    %rdx,%rax
    a1c4:	49 0f 46 c7          	cmovbe %r15,%rax
    a1c8:	48 85 c0             	test   %rax,%rax
    a1cb:	0f 84 61 0d 00 00    	je     af32 <fwp_hof0.constprop.0+0x17f2>
    a1d1:	c7 44 24 10 01 00 00 	movl   $0x1,0x10(%rsp)
    a1d8:	00 
    a1d9:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    a1de:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    a1e3:	48 8b 0c 24          	mov    (%rsp),%rcx
    a1e7:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a1ee:	00 
    a1ef:	31 d2                	xor    %edx,%edx
    a1f1:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a1f5:	eb 27                	jmp    a21e <fwp_hof0.constprop.0+0xade>
    a1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1fe:	00 00 
    a200:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a205:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a20a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    a211:	48 83 c2 08          	add    $0x8,%rdx
    a215:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a219:	49 39 d1             	cmp    %rdx,%r9
    a21c:	74 12                	je     a230 <fwp_hof0.constprop.0+0xaf0>
    a21e:	48 89 fe             	mov    %rdi,%rsi
    a221:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a226:	79 d8                	jns    a200 <fwp_hof0.constprop.0+0xac0>
    a228:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a22c:	eb d2                	jmp    a200 <fwp_hof0.constprop.0+0xac0>
    a22e:	66 90                	xchg   %ax,%ax
    a230:	48 8b 0c 24          	mov    (%rsp),%rcx
    a234:	48 85 c9             	test   %rcx,%rcx
    a237:	0f 84 c9 0c 00 00    	je     af06 <fwp_hof0.constprop.0+0x17c6>
    a23d:	4c 8b 8b d8 13 00 00 	mov    0x13d8(%rbx),%r9
    a244:	4c 8b 93 b0 13 00 00 	mov    0x13b0(%rbx),%r10
    a24b:	45 31 ff             	xor    %r15d,%r15d
    a24e:	4c 8b 9b f8 13 00 00 	mov    0x13f8(%rbx),%r11
    a255:	49 c1 e1 10          	shl    $0x10,%r9
    a259:	eb 1b                	jmp    a276 <fwp_hof0.constprop.0+0xb36>
    a25b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a260:	49 83 c7 01          	add    $0x1,%r15
    a264:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a268:	49 39 c7             	cmp    %rax,%r15
    a26b:	0f 83 5f 01 00 00    	jae    a3d0 <fwp_hof0.constprop.0+0xc90>
    a271:	48 85 c9             	test   %rcx,%rcx
    a274:	74 56                	je     a2cc <fwp_hof0.constprop.0+0xb8c>
    a276:	48 89 ca             	mov    %rcx,%rdx
    a279:	4c 29 d2             	sub    %r10,%rdx
    a27c:	4c 39 ca             	cmp    %r9,%rdx
    a27f:	73 4b                	jae    a2cc <fwp_hof0.constprop.0+0xb8c>
    a281:	48 89 d6             	mov    %rdx,%rsi
    a284:	48 c1 ee 10          	shr    $0x10,%rsi
    a288:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a28c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a290:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a294:	48 85 ff             	test   %rdi,%rdi
    a297:	74 33                	je     a2cc <fwp_hof0.constprop.0+0xb8c>
    a299:	44 0f b6 06          	movzbl (%rsi),%r8d
    a29d:	41 80 f8 02          	cmp    $0x2,%r8b
    a2a1:	0f 84 11 01 00 00    	je     a3b8 <fwp_hof0.constprop.0+0xc78>
    a2a7:	41 80 f8 01          	cmp    $0x1,%r8b
    a2ab:	75 1f                	jne    a2cc <fwp_hof0.constprop.0+0xb8c>
    a2ad:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a2b1:	0f b7 d2             	movzwl %dx,%edx
    a2b4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a2b7:	49 0f af d0          	imul   %r8,%rdx
    a2bb:	48 c1 ea 20          	shr    $0x20,%rdx
    a2bf:	48 39 f2             	cmp    %rsi,%rdx
    a2c2:	73 08                	jae    a2cc <fwp_hof0.constprop.0+0xb8c>
    a2c4:	48 01 d7             	add    %rdx,%rdi
    a2c7:	80 3f 01             	cmpb   $0x1,(%rdi)
    a2ca:	74 94                	je     a260 <fwp_hof0.constprop.0+0xb20>
    a2cc:	49 39 c7             	cmp    %rax,%r15
    a2cf:	0f 83 fb 00 00 00    	jae    a3d0 <fwp_hof0.constprop.0+0xc90>
    a2d5:	48 89 c5             	mov    %rax,%rbp
    a2d8:	45 31 f6             	xor    %r14d,%r14d
    a2db:	eb 37                	jmp    a314 <fwp_hof0.constprop.0+0xbd4>
    a2dd:	0f 1f 00             	nopl   (%rax)
    a2e0:	40 80 fe 01          	cmp    $0x1,%sil
    a2e4:	75 25                	jne    a30b <fwp_hof0.constprop.0+0xbcb>
    a2e6:	8b 71 18             	mov    0x18(%rcx),%esi
    a2e9:	0f b7 c0             	movzwl %ax,%eax
    a2ec:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a2ef:	48 0f af c6          	imul   %rsi,%rax
    a2f3:	48 c1 e8 20          	shr    $0x20,%rax
    a2f7:	48 39 c8             	cmp    %rcx,%rax
    a2fa:	73 0f                	jae    a30b <fwp_hof0.constprop.0+0xbcb>
    a2fc:	48 01 c2             	add    %rax,%rdx
    a2ff:	80 3a ff             	cmpb   $0xff,(%rdx)
    a302:	0f 84 a8 05 00 00    	je     a8b0 <fwp_hof0.constprop.0+0x1170>
    a308:	c6 02 01             	movb   $0x1,(%rdx)
    a30b:	49 39 ef             	cmp    %rbp,%r15
    a30e:	0f 83 8c 00 00 00    	jae    a3a0 <fwp_hof0.constprop.0+0xc60>
    a314:	48 83 ed 01          	sub    $0x1,%rbp
    a318:	66 49 0f 6e ee       	movq   %r14,%xmm5
    a31d:	bf 01 00 00 00       	mov    $0x1,%edi
    a322:	f3 41 0f 7e 44 ed 00 	movq   0x0(%r13,%rbp,8),%xmm0
    a329:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    a330:	00 
    a331:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a335:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    a33c:	00 
    a33d:	e8 6e ba ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    a342:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a349:	49 89 c6             	mov    %rax,%r14
    a34c:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a353:	48 c1 e2 10          	shl    $0x10,%rdx
    a357:	48 39 d0             	cmp    %rdx,%rax
    a35a:	73 af                	jae    a30b <fwp_hof0.constprop.0+0xbcb>
    a35c:	48 89 c2             	mov    %rax,%rdx
    a35f:	48 c1 ea 10          	shr    $0x10,%rdx
    a363:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a367:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a36e:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a372:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a376:	48 85 d2             	test   %rdx,%rdx
    a379:	74 90                	je     a30b <fwp_hof0.constprop.0+0xbcb>
    a37b:	0f b6 31             	movzbl (%rcx),%esi
    a37e:	40 80 fe 02          	cmp    $0x2,%sil
    a382:	0f 85 58 ff ff ff    	jne    a2e0 <fwp_hof0.constprop.0+0xba0>
    a388:	66 85 c0             	test   %ax,%ax
    a38b:	0f 84 6e ff ff ff    	je     a2ff <fwp_hof0.constprop.0+0xbbf>
    a391:	49 39 ef             	cmp    %rbp,%r15
    a394:	0f 82 7a ff ff ff    	jb     a314 <fwp_hof0.constprop.0+0xbd4>
    a39a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3a0:	4d 85 ff             	test   %r15,%r15
    a3a3:	75 2e                	jne    a3d3 <fwp_hof0.constprop.0+0xc93>
    a3a5:	8b 44 24 10          	mov    0x10(%rsp),%eax
    a3a9:	85 c0                	test   %eax,%eax
    a3ab:	4d 0f 45 ef          	cmovne %r15,%r13
    a3af:	eb 61                	jmp    a412 <fwp_hof0.constprop.0+0xcd2>
    a3b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a3b8:	66 85 d2             	test   %dx,%dx
    a3bb:	0f 84 06 ff ff ff    	je     a2c7 <fwp_hof0.constprop.0+0xb87>
    a3c1:	49 39 c7             	cmp    %rax,%r15
    a3c4:	0f 82 0b ff ff ff    	jb     a2d5 <fwp_hof0.constprop.0+0xb95>
    a3ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a3d0:	45 31 f6             	xor    %r14d,%r14d
    a3d3:	48 8b 04 24          	mov    (%rsp),%rax
    a3d7:	4c 89 ea             	mov    %r13,%rdx
    a3da:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    a3df:	90                   	nop
    a3e0:	48 8b 0a             	mov    (%rdx),%rcx
    a3e3:	48 83 c2 08          	add    $0x8,%rdx
    a3e7:	48 89 c7             	mov    %rax,%rdi
    a3ea:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a3ee:	48 8b 40 10          	mov    0x10(%rax),%rax
    a3f2:	4c 39 ca             	cmp    %r9,%rdx
    a3f5:	75 e9                	jne    a3e0 <fwp_hof0.constprop.0+0xca0>
    a3f7:	8b 54 24 10          	mov    0x10(%rsp),%edx
    a3fb:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a3ff:	85 d2                	test   %edx,%edx
    a401:	0f 84 c9 07 00 00    	je     abd0 <fwp_hof0.constprop.0+0x1490>
    a407:	4c 8b 34 24          	mov    (%rsp),%r14
    a40b:	48 89 04 24          	mov    %rax,(%rsp)
    a40f:	45 31 ed             	xor    %r13d,%r13d
    a412:	4c 89 ef             	mov    %r13,%rdi
    a415:	e8 76 b3 ff ff       	call   5790 <fwp_mem_free>
    a41a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a41f:	e8 4c db ff ff       	call   7f70 <fwp_drop10>
    a424:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a42b:	48 8b 04 24          	mov    (%rsp),%rax
    a42f:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a436:	48 c1 e2 10          	shl    $0x10,%rdx
    a43a:	48 39 d0             	cmp    %rdx,%rax
    a43d:	73 71                	jae    a4b0 <fwp_hof0.constprop.0+0xd70>
    a43f:	48 89 c2             	mov    %rax,%rdx
    a442:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    a449:	48 c1 ea 10          	shr    $0x10,%rdx
    a44d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a451:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a455:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a459:	48 85 ed             	test   %rbp,%rbp
    a45c:	74 52                	je     a4b0 <fwp_hof0.constprop.0+0xd70>
    a45e:	0f b6 0a             	movzbl (%rdx),%ecx
    a461:	80 f9 02             	cmp    $0x2,%cl
    a464:	0f 84 f6 06 00 00    	je     ab60 <fwp_hof0.constprop.0+0x1420>
    a46a:	80 f9 01             	cmp    $0x1,%cl
    a46d:	75 41                	jne    a4b0 <fwp_hof0.constprop.0+0xd70>
    a46f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a472:	0f b7 c0             	movzwl %ax,%eax
    a475:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a478:	48 0f af c1          	imul   %rcx,%rax
    a47c:	48 c1 e8 20          	shr    $0x20,%rax
    a480:	48 39 d0             	cmp    %rdx,%rax
    a483:	73 2b                	jae    a4b0 <fwp_hof0.constprop.0+0xd70>
    a485:	48 01 c5             	add    %rax,%rbp
    a488:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    a48c:	84 c0                	test   %al,%al
    a48e:	74 20                	je     a4b0 <fwp_hof0.constprop.0+0xd70>
    a490:	3c 01                	cmp    $0x1,%al
    a492:	0f 84 48 07 00 00    	je     abe0 <fwp_hof0.constprop.0+0x14a0>
    a498:	3c ff                	cmp    $0xff,%al
    a49a:	0f 84 1b 09 00 00    	je     adbb <fwp_hof0.constprop.0+0x167b>
    a4a0:	83 e8 01             	sub    $0x1,%eax
    a4a3:	88 45 00             	mov    %al,0x0(%rbp)
    a4a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a4ad:	00 00 00 
    a4b0:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
    a4b6:	0f 85 74 05 00 00    	jne    aa30 <fwp_hof0.constprop.0+0x12f0>
    a4bc:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a4c1:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a4c5:	4c 89 f6             	mov    %r14,%rsi
    a4c8:	4d 89 f4             	mov    %r14,%r12
    a4cb:	b9 01 00 00 00       	mov    $0x1,%ecx
    a4d0:	48 8d 15 a9 86 00 00 	lea    0x86a9(%rip),%rdx        # 12b80 <d0>
    a4d7:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
    a4de:	00 00 00 00 00 
    a4e3:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
    a4ea:	00 
    a4eb:	e8 10 e2 ff ff       	call   8700 <fwp_write>
    a4f0:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
    a4f7:	00 
    a4f8:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
    a4ff:	00 
    a500:	48 8d 05 8a 4b 00 00 	lea    0x4b8a(%rip),%rax        # f091 <_IO_stdin_used+0x91>
    a507:	48 85 c9             	test   %rcx,%rcx
    a50a:	48 0f 44 c8          	cmove  %rax,%rcx
    a50e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a512:	0f 87 ef 0a 00 00    	ja     b007 <fwp_hof0.constprop.0+0x18c7>
    a518:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a51c:	be 01 00 00 00       	mov    $0x1,%esi
    a521:	48 89 0c 24          	mov    %rcx,(%rsp)
    a525:	e8 66 b7 ff ff       	call   5c90 <fwp_heap_alloc>
    a52a:	48 8b 34 24          	mov    (%rsp),%rsi
    a52e:	4c 89 fa             	mov    %r15,%rdx
    a531:	4c 89 38             	mov    %r15,(%rax)
    a534:	4c 8d 70 08          	lea    0x8(%rax),%r14
    a538:	48 89 c5             	mov    %rax,%rbp
    a53b:	4c 89 f7             	mov    %r14,%rdi
    a53e:	e8 5d 90 ff ff       	call   35a0 <memcpy@plt>
    a543:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    a549:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
    a550:	00 
    a551:	e8 6a 8e ff ff       	call   33c0 <free@plt>
    a556:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a55d:	48 89 e8             	mov    %rbp,%rax
    a560:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a567:	48 c1 e2 10          	shl    $0x10,%rdx
    a56b:	48 39 d0             	cmp    %rdx,%rax
    a56e:	73 57                	jae    a5c7 <fwp_hof0.constprop.0+0xe87>
    a570:	48 89 c2             	mov    %rax,%rdx
    a573:	48 c1 ea 10          	shr    $0x10,%rdx
    a577:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a57b:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a582:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a586:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a58a:	4d 85 ff             	test   %r15,%r15
    a58d:	74 38                	je     a5c7 <fwp_hof0.constprop.0+0xe87>
    a58f:	0f b6 0a             	movzbl (%rdx),%ecx
    a592:	80 f9 02             	cmp    $0x2,%cl
    a595:	0f 84 45 07 00 00    	je     ace0 <fwp_hof0.constprop.0+0x15a0>
    a59b:	80 f9 01             	cmp    $0x1,%cl
    a59e:	75 27                	jne    a5c7 <fwp_hof0.constprop.0+0xe87>
    a5a0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5a3:	0f b7 c0             	movzwl %ax,%eax
    a5a6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5a9:	48 0f af c1          	imul   %rcx,%rax
    a5ad:	48 c1 e8 20          	shr    $0x20,%rax
    a5b1:	48 39 d0             	cmp    %rdx,%rax
    a5b4:	73 11                	jae    a5c7 <fwp_hof0.constprop.0+0xe87>
    a5b6:	49 01 c7             	add    %rax,%r15
    a5b9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a5bd:	0f 84 30 07 00 00    	je     acf3 <fwp_hof0.constprop.0+0x15b3>
    a5c3:	41 c6 07 01          	movb   $0x1,(%r15)
    a5c7:	4c 89 e7             	mov    %r12,%rdi
    a5ca:	e8 b1 d5 ff ff       	call   7b80 <fwp_drop0>
    a5cf:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    a5d3:	be 01 00 00 00       	mov    $0x1,%esi
    a5d8:	4c 89 f7             	mov    %r14,%rdi
    a5db:	48 8b 0d 3e ae 01 00 	mov    0x1ae3e(%rip),%rcx        # 25420 <fwp_prog_out>
    a5e2:	e8 99 90 ff ff       	call   3680 <fwrite@plt>
    a5e7:	48 8b 35 32 ae 01 00 	mov    0x1ae32(%rip),%rsi        # 25420 <fwp_prog_out>
    a5ee:	bf 0a 00 00 00       	mov    $0xa,%edi
    a5f3:	e8 e8 8e ff ff       	call   34e0 <fputc@plt>
    a5f8:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a5ff:	48 89 e8             	mov    %rbp,%rax
    a602:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a609:	48 c1 e2 10          	shl    $0x10,%rdx
    a60d:	48 39 d0             	cmp    %rdx,%rax
    a610:	73 6e                	jae    a680 <fwp_hof0.constprop.0+0xf40>
    a612:	48 89 c2             	mov    %rax,%rdx
    a615:	48 c1 ea 10          	shr    $0x10,%rdx
    a619:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a61d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a624:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a628:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a62c:	4d 85 e4             	test   %r12,%r12
    a62f:	74 4f                	je     a680 <fwp_hof0.constprop.0+0xf40>
    a631:	0f b6 0a             	movzbl (%rdx),%ecx
    a634:	80 f9 02             	cmp    $0x2,%cl
    a637:	0f 84 c3 06 00 00    	je     ad00 <fwp_hof0.constprop.0+0x15c0>
    a63d:	80 f9 01             	cmp    $0x1,%cl
    a640:	75 3e                	jne    a680 <fwp_hof0.constprop.0+0xf40>
    a642:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a645:	0f b7 c0             	movzwl %ax,%eax
    a648:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a64b:	48 0f af c1          	imul   %rcx,%rax
    a64f:	48 c1 e8 20          	shr    $0x20,%rax
    a653:	48 39 d0             	cmp    %rdx,%rax
    a656:	73 28                	jae    a680 <fwp_hof0.constprop.0+0xf40>
    a658:	49 01 c4             	add    %rax,%r12
    a65b:	41 0f b6 04 24       	movzbl (%r12),%eax
    a660:	84 c0                	test   %al,%al
    a662:	74 1c                	je     a680 <fwp_hof0.constprop.0+0xf40>
    a664:	3c 01                	cmp    $0x1,%al
    a666:	0f 84 b2 06 00 00    	je     ad1e <fwp_hof0.constprop.0+0x15de>
    a66c:	3c ff                	cmp    $0xff,%al
    a66e:	0f 84 d1 07 00 00    	je     ae45 <fwp_hof0.constprop.0+0x1705>
    a674:	83 e8 01             	sub    $0x1,%eax
    a677:	41 88 04 24          	mov    %al,(%r12)
    a67b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a680:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    a685:	48 8b 40 10          	mov    0x10(%rax),%rax
    a689:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    a68e:	48 85 c0             	test   %rax,%rax
    a691:	0f 85 e9 f0 ff ff    	jne    9780 <fwp_hof0.constprop.0+0x40>
    a697:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    a69e:	00 
    a69f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a6a6:	00 00 
    a6a8:	0f 85 54 09 00 00    	jne    b002 <fwp_hof0.constprop.0+0x18c2>
    a6ae:	48 81 c4 18 01 00 00 	add    $0x118,%rsp
    a6b5:	31 c0                	xor    %eax,%eax
    a6b7:	5b                   	pop    %rbx
    a6b8:	5d                   	pop    %rbp
    a6b9:	41 5c                	pop    %r12
    a6bb:	41 5d                	pop    %r13
    a6bd:	41 5e                	pop    %r14
    a6bf:	41 5f                	pop    %r15
    a6c1:	c3                   	ret
    a6c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a6c8:	66 85 c9             	test   %cx,%cx
    a6cb:	0f 84 e4 fa ff ff    	je     a1b5 <fwp_hof0.constprop.0+0xa75>
    a6d1:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
    a6d6:	0f 84 88 02 00 00    	je     a964 <fwp_hof0.constprop.0+0x1224>
    a6dc:	48 8b 04 24          	mov    (%rsp),%rax
    a6e0:	45 31 f6             	xor    %r14d,%r14d
    a6e3:	66 90                	xchg   %ax,%ax
    a6e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a6ec:	00 00 00 00 
    a6f0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a6f4:	4c 89 f2             	mov    %r14,%rdx
    a6f7:	49 83 c6 01          	add    $0x1,%r14
    a6fb:	48 85 c0             	test   %rax,%rax
    a6fe:	75 f0                	jne    a6f0 <fwp_hof0.constprop.0+0xfb0>
    a700:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a707:	ff ff 1f 
    a70a:	4c 39 f0             	cmp    %r14,%rax
    a70d:	0f 82 3f 08 00 00    	jb     af52 <fwp_hof0.constprop.0+0x1812>
    a713:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    a71a:	00 
    a71b:	be 02 00 00 00       	mov    $0x2,%esi
    a720:	e8 6b b5 ff ff       	call   5c90 <fwp_heap_alloc>
    a725:	4d 39 f7             	cmp    %r14,%r15
    a728:	48 8b 14 24          	mov    (%rsp),%rdx
    a72c:	49 89 c5             	mov    %rax,%r13
    a72f:	4c 89 f0             	mov    %r14,%rax
    a732:	49 0f 46 c7          	cmovbe %r15,%rax
    a736:	4c 89 e9             	mov    %r13,%rcx
    a739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a740:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    a744:	48 83 c1 08          	add    $0x8,%rcx
    a748:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    a74c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a750:	48 85 d2             	test   %rdx,%rdx
    a753:	75 eb                	jne    a740 <fwp_hof0.constprop.0+0x1000>
    a755:	48 85 c0             	test   %rax,%rax
    a758:	0f 84 18 02 00 00    	je     a976 <fwp_hof0.constprop.0+0x1236>
    a75e:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
    a765:	00 
    a766:	e9 73 fa ff ff       	jmp    a1de <fwp_hof0.constprop.0+0xa9e>
    a76b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a770:	48 83 3d 10 89 01 00 	cmpq   $0x0,0x18910(%rip)        # 23088 <fwp_tape_cached_bytes>
    a777:	00 
    a778:	0f 84 fc f2 ff ff    	je     9a7a <fwp_hof0.constprop.0+0x33a>
    a77e:	66 0f 6f 0d 1a 89 01 	movdqa 0x1891a(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    a785:	00 
    a786:	48 c7 05 f7 88 01 00 	movq   $0x0,0x188f7(%rip)        # 23088 <fwp_tape_cached_bytes>
    a78d:	00 00 00 00 
    a791:	0f 11 49 20          	movups %xmm1,0x20(%rcx)
    a795:	48 8b 05 24 89 01 00 	mov    0x18924(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    a79c:	66 0f 6f 0d 0c 89 01 	movdqa 0x1890c(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    a7a3:	00 
    a7a4:	48 89 41 40          	mov    %rax,0x40(%rcx)
    a7a8:	48 8b 05 19 89 01 00 	mov    0x18919(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    a7af:	0f 11 49 30          	movups %xmm1,0x30(%rcx)
    a7b3:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a7b7:	48 89 41 18          	mov    %rax,0x18(%rcx)
    a7bb:	48 8b 05 0e 89 01 00 	mov    0x1890e(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    a7c2:	0f 29 0d d7 88 01 00 	movaps %xmm1,0x188d7(%rip)        # 230a0 <fwp_tape_workspace>
    a7c9:	48 89 41 48          	mov    %rax,0x48(%rcx)
    a7cd:	0f 29 0d dc 88 01 00 	movaps %xmm1,0x188dc(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    a7d4:	48 c7 05 f1 88 01 00 	movq   $0x0,0x188f1(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    a7db:	00 00 00 00 
    a7df:	0f 29 0d da 88 01 00 	movaps %xmm1,0x188da(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    a7e6:	e9 8f f2 ff ff       	jmp    9a7a <fwp_hof0.constprop.0+0x33a>
    a7eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a7f0:	66 85 c0             	test   %ax,%ax
    a7f3:	0f 84 a1 f8 ff ff    	je     a09a <fwp_hof0.constprop.0+0x95a>
    a7f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a800:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a807:	ff ff 1f 
    a80a:	4c 39 f0             	cmp    %r14,%rax
    a80d:	0f 82 33 07 00 00    	jb     af46 <fwp_hof0.constprop.0+0x1806>
    a813:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a81a:	00 
    a81b:	be 01 00 00 00       	mov    $0x1,%esi
    a820:	e8 6b b4 ff ff       	call   5c90 <fwp_heap_alloc>
    a825:	4c 89 30             	mov    %r14,(%rax)
    a828:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a82f:	49 89 c4             	mov    %rax,%r12
    a832:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a837:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a83e:	48 c1 e2 10          	shl    $0x10,%rdx
    a842:	48 39 d0             	cmp    %rdx,%rax
    a845:	73 59                	jae    a8a0 <fwp_hof0.constprop.0+0x1160>
    a847:	48 89 c2             	mov    %rax,%rdx
    a84a:	48 c1 ea 10          	shr    $0x10,%rdx
    a84e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a852:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a859:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a85d:	48 8b 69 20          	mov    0x20(%rcx),%rbp
    a861:	48 85 ed             	test   %rbp,%rbp
    a864:	74 3a                	je     a8a0 <fwp_hof0.constprop.0+0x1160>
    a866:	0f b6 31             	movzbl (%rcx),%esi
    a869:	40 80 fe 02          	cmp    $0x2,%sil
    a86d:	0f 84 0d 04 00 00    	je     ac80 <fwp_hof0.constprop.0+0x1540>
    a873:	40 80 fe 01          	cmp    $0x1,%sil
    a877:	75 27                	jne    a8a0 <fwp_hof0.constprop.0+0x1160>
    a879:	8b 71 18             	mov    0x18(%rcx),%esi
    a87c:	0f b7 c0             	movzwl %ax,%eax
    a87f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a882:	48 0f af c6          	imul   %rsi,%rax
    a886:	48 c1 e8 20          	shr    $0x20,%rax
    a88a:	48 39 c8             	cmp    %rcx,%rax
    a88d:	73 11                	jae    a8a0 <fwp_hof0.constprop.0+0x1160>
    a88f:	48 01 c5             	add    %rax,%rbp
    a892:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a896:	0f 84 f7 03 00 00    	je     ac93 <fwp_hof0.constprop.0+0x1553>
    a89c:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a8a0:	4c 89 ff             	mov    %r15,%rdi
    a8a3:	e9 05 f8 ff ff       	jmp    a0ad <fwp_hof0.constprop.0+0x96d>
    a8a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a8af:	00 
    a8b0:	48 89 d7             	mov    %rdx,%rdi
    a8b3:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a8b8:	e8 93 ac ff ff       	call   5550 <fwp_rc_forget_slot>
    a8bd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    a8c2:	e9 41 fa ff ff       	jmp    a308 <fwp_hof0.constprop.0+0xbc8>
    a8c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8ce:	00 00 
    a8d0:	44 89 f2             	mov    %r14d,%edx
    a8d3:	be 02 00 00 00       	mov    $0x2,%esi
    a8d8:	bf 08 00 00 00       	mov    $0x8,%edi
    a8dd:	48 c1 e2 10          	shl    $0x10,%rdx
    a8e1:	4c 09 e2             	or     %r12,%rdx
    a8e4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    a8e9:	e8 a2 b3 ff ff       	call   5c90 <fwp_heap_alloc>
    a8ee:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a8f5:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    a8fc:	49 89 c6             	mov    %rax,%r14
    a8ff:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    a906:	48 c1 e2 10          	shl    $0x10,%rdx
    a90a:	48 39 d0             	cmp    %rdx,%rax
    a90d:	0f 83 6d f3 ff ff    	jae    9c80 <fwp_hof0.constprop.0+0x540>
    a913:	48 89 c2             	mov    %rax,%rdx
    a916:	48 c1 ea 10          	shr    $0x10,%rdx
    a91a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a91e:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    a925:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a929:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a92d:	4d 85 ff             	test   %r15,%r15
    a930:	0f 84 3e f3 ff ff    	je     9c74 <fwp_hof0.constprop.0+0x534>
    a936:	0f b6 0a             	movzbl (%rdx),%ecx
    a939:	31 ed                	xor    %ebp,%ebp
    a93b:	80 f9 02             	cmp    $0x2,%cl
    a93e:	0f 85 9b f2 ff ff    	jne    9bdf <fwp_hof0.constprop.0+0x49f>
    a944:	66 85 c0             	test   %ax,%ax
    a947:	0f 85 be f2 ff ff    	jne    9c0b <fwp_hof0.constprop.0+0x4cb>
    a94d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a951:	0f 85 b0 f2 ff ff    	jne    9c07 <fwp_hof0.constprop.0+0x4c7>
    a957:	4c 89 ff             	mov    %r15,%rdi
    a95a:	e8 f1 ab ff ff       	call   5550 <fwp_rc_forget_slot>
    a95f:	e9 a3 f2 ff ff       	jmp    9c07 <fwp_hof0.constprop.0+0x4c7>
    a964:	be 02 00 00 00       	mov    $0x2,%esi
    a969:	bf 08 00 00 00       	mov    $0x8,%edi
    a96e:	e8 1d b3 ff ff       	call   5c90 <fwp_heap_alloc>
    a973:	49 89 c5             	mov    %rax,%r13
    a976:	45 31 f6             	xor    %r14d,%r14d
    a979:	e9 94 fa ff ff       	jmp    a412 <fwp_hof0.constprop.0+0xcd2>
    a97e:	66 90                	xchg   %ax,%ax
    a980:	48 8d 68 ff          	lea    -0x1(%rax),%rbp
    a984:	48 89 ef             	mov    %rbp,%rdi
    a987:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a98b:	0f 85 c1 05 00 00    	jne    af52 <fwp_hof0.constprop.0+0x1812>
    a991:	48 85 ed             	test   %rbp,%rbp
    a994:	0f 84 e6 f2 ff ff    	je     9c80 <fwp_hof0.constprop.0+0x540>
    a99a:	48 c1 e0 04          	shl    $0x4,%rax
    a99e:	48 01 ed             	add    %rbp,%rbp
    a9a1:	4d 8d 66 08          	lea    0x8(%r14),%r12
    a9a5:	4d 8d 7c 06 f8       	lea    -0x8(%r14,%rax,1),%r15
    a9aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a9b0:	f2 41 0f 10 04 24    	movsd  (%r12),%xmm0
    a9b6:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
    a9bb:	49 83 c4 10          	add    $0x10,%r12
    a9bf:	49 8b 7c 24 f8       	mov    -0x8(%r12),%rdi
    a9c4:	f2 41 0f 10 0c 24    	movsd  (%r12),%xmm1
    a9ca:	e8 01 b9 ff ff       	call   62d0 <w120>
    a9cf:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a9d4:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a9d8:	41 0f 11 44 24 f0    	movups %xmm0,-0x10(%r12)
    a9de:	4d 39 e7             	cmp    %r12,%r15
    a9e1:	75 cd                	jne    a9b0 <fwp_hof0.constprop.0+0x1270>
    a9e3:	49 89 2e             	mov    %rbp,(%r14)
    a9e6:	45 31 ff             	xor    %r15d,%r15d
    a9e9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    a9f0:	4b 8b 74 fe 10       	mov    0x10(%r14,%r15,8),%rsi
    a9f5:	49 83 c7 02          	add    $0x2,%r15
    a9f9:	e8 52 b7 ff ff       	call   6150 <f141.constprop.0>
    a9fe:	48 89 c7             	mov    %rax,%rdi
    aa01:	49 39 ef             	cmp    %rbp,%r15
    aa04:	72 ea                	jb     a9f0 <fwp_hof0.constprop.0+0x12b0>
    aa06:	48 89 c1             	mov    %rax,%rcx
    aa09:	e9 82 f2 ff ff       	jmp    9c90 <fwp_hof0.constprop.0+0x550>
    aa0e:	66 90                	xchg   %ax,%ax
    aa10:	48 39 d5             	cmp    %rdx,%rbp
    aa13:	0f 84 67 ef ff ff    	je     9980 <fwp_hof0.constprop.0+0x240>
    aa19:	4c 8b 0d d0 86 01 00 	mov    0x186d0(%rip),%r9        # 230f0 <fwp_tapes>
    aa20:	48 89 d5             	mov    %rdx,%rbp
    aa23:	4c 8d 62 01          	lea    0x1(%rdx),%r12
    aa27:	e9 f4 ef ff ff       	jmp    9a20 <fwp_hof0.constprop.0+0x2e0>
    aa2c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa30:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    aa35:	45 31 c0             	xor    %r8d,%r8d
    aa38:	4c 89 34 24          	mov    %r14,(%rsp)
    aa3c:	48 83 e8 01          	sub    $0x1,%rax
    aa40:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    aa45:	41 0f 90 c0          	seto   %r8b
    aa49:	e9 c0 ed ff ff       	jmp    980e <fwp_hof0.constprop.0+0xce>
    aa4e:	66 90                	xchg   %ax,%ax
    aa50:	4d 8d 63 01          	lea    0x1(%r11),%r12
    aa54:	4c 39 e5             	cmp    %r12,%rbp
    aa57:	7c 3a                	jl     aa93 <fwp_hof0.constprop.0+0x1353>
    aa59:	4d 85 c9             	test   %r9,%r9
    aa5c:	0f 84 13 05 00 00    	je     af75 <fwp_hof0.constprop.0+0x1835>
    aa62:	4c 89 cf             	mov    %r9,%rdi
    aa65:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    aa6c:	00 
    aa6d:	31 f6                	xor    %esi,%esi
    aa6f:	4c 89 e5             	mov    %r12,%rbp
    aa72:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
    aa77:	4c 29 f5             	sub    %r14,%rbp
    aa7a:	e8 41 8a ff ff       	call   34c0 <memset@plt>
    aa7f:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    aa84:	49 89 c1             	mov    %rax,%r9
    aa87:	e9 a6 f3 ff ff       	jmp    9e32 <fwp_hof0.constprop.0+0x6f2>
    aa8c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa90:	4d 89 f4             	mov    %r14,%r12
    aa93:	48 85 ed             	test   %rbp,%rbp
    aa96:	49 0f 44 ec          	cmove  %r12,%rbp
    aa9a:	eb 1a                	jmp    aab6 <fwp_hof0.constprop.0+0x1376>
    aa9c:	0f 1f 40 00          	nopl   0x0(%rax)
    aaa0:	48 8d 54 2d 00       	lea    0x0(%rbp,%rbp,1),%rdx
    aaa5:	48 81 fd 00 00 00 40 	cmp    $0x40000000,%rbp
    aaac:	4c 89 e0             	mov    %r12,%rax
    aaaf:	48 0f 4c c2          	cmovl  %rdx,%rax
    aab3:	48 89 c5             	mov    %rax,%rbp
    aab6:	4c 39 e5             	cmp    %r12,%rbp
    aab9:	7c e5                	jl     aaa0 <fwp_hof0.constprop.0+0x1360>
    aabb:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    aac0:	4d 85 c9             	test   %r9,%r9
    aac3:	0f 84 e7 01 00 00    	je     acb0 <fwp_hof0.constprop.0+0x1570>
    aac9:	4c 89 cf             	mov    %r9,%rdi
    aacc:	48 8d 34 ed 00 00 00 	lea    0x0(,%rbp,8),%rsi
    aad3:	00 
    aad4:	e8 f7 8a ff ff       	call   35d0 <realloc@plt>
    aad9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    aade:	49 89 c1             	mov    %rax,%r9
    aae1:	4d 85 c9             	test   %r9,%r9
    aae4:	0f 84 82 04 00 00    	je     af6c <fwp_hof0.constprop.0+0x182c>
    aaea:	4c 89 8c 24 d0 00 00 	mov    %r9,0xd0(%rsp)
    aaf1:	00 
    aaf2:	48 89 ac 24 e0 00 00 	mov    %rbp,0xe0(%rsp)
    aaf9:	00 
    aafa:	4d 85 e4             	test   %r12,%r12
    aafd:	0f 85 75 03 00 00    	jne    ae78 <fwp_hof0.constprop.0+0x1738>
    ab03:	4c 89 f5             	mov    %r14,%rbp
    ab06:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    ab0d:	48 f7 dd             	neg    %rbp
    ab10:	48 85 c9             	test   %rcx,%rcx
    ab13:	0f 88 2d f3 ff ff    	js     9e46 <fwp_hof0.constprop.0+0x706>
    ab19:	41 89 cb             	mov    %ecx,%r11d
    ab1c:	e9 11 f3 ff ff       	jmp    9e32 <fwp_hof0.constprop.0+0x6f2>
    ab21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab28:	48 8d 3d 31 c4 ff ff 	lea    -0x3bcf(%rip),%rdi        # 6f60 <fwp_tape_finish>
    ab2f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    ab35:	e8 66 3b 00 00       	call   e6a0 <atexit>
    ab3a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    ab40:	85 c0                	test   %eax,%eax
    ab42:	0f 85 cb 04 00 00    	jne    b013 <fwp_hof0.constprop.0+0x18d3>
    ab48:	c7 05 0e 85 00 00 01 	movl   $0x1,0x850e(%rip)        # 13060 <registered_finish.1>
    ab4f:	00 00 00 
    ab52:	e9 dd ed ff ff       	jmp    9934 <fwp_hof0.constprop.0+0x1f4>
    ab57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ab5e:	00 00 
    ab60:	66 85 c0             	test   %ax,%ax
    ab63:	0f 85 47 f9 ff ff    	jne    a4b0 <fwp_hof0.constprop.0+0xd70>
    ab69:	e9 1a f9 ff ff       	jmp    a488 <fwp_hof0.constprop.0+0xd48>
    ab6e:	66 90                	xchg   %ax,%ax
    ab70:	66 85 c0             	test   %ax,%ax
    ab73:	0f 85 5f ed ff ff    	jne    98d8 <fwp_hof0.constprop.0+0x198>
    ab79:	e9 46 ed ff ff       	jmp    98c4 <fwp_hof0.constprop.0+0x184>
    ab7e:	66 90                	xchg   %ax,%ax
    ab80:	49 39 ee             	cmp    %rbp,%r14
    ab83:	0f 8f 07 ff ff ff    	jg     aa90 <fwp_hof0.constprop.0+0x1350>
    ab89:	4d 85 f6             	test   %r14,%r14
    ab8c:	74 12                	je     aba0 <fwp_hof0.constprop.0+0x1460>
    ab8e:	4d 85 c9             	test   %r9,%r9
    ab91:	0f 84 de 03 00 00    	je     af75 <fwp_hof0.constprop.0+0x1835>
    ab97:	4d 85 f6             	test   %r14,%r14
    ab9a:	0f 85 d5 02 00 00    	jne    ae75 <fwp_hof0.constprop.0+0x1735>
    aba0:	31 ed                	xor    %ebp,%ebp
    aba2:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    aba9:	e9 98 f2 ff ff       	jmp    9e46 <fwp_hof0.constprop.0+0x706>
    abae:	66 90                	xchg   %ax,%ax
    abb0:	66 85 c0             	test   %ax,%ax
    abb3:	0f 85 37 f4 ff ff    	jne    9ff0 <fwp_hof0.constprop.0+0x8b0>
    abb9:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    abbd:	0f 85 29 f4 ff ff    	jne    9fec <fwp_hof0.constprop.0+0x8ac>
    abc3:	48 89 ef             	mov    %rbp,%rdi
    abc6:	e8 85 a9 ff ff       	call   5550 <fwp_rc_forget_slot>
    abcb:	e9 1c f4 ff ff       	jmp    9fec <fwp_hof0.constprop.0+0x8ac>
    abd0:	4c 8b 34 24          	mov    (%rsp),%r14
    abd4:	48 89 04 24          	mov    %rax,(%rsp)
    abd8:	e9 35 f8 ff ff       	jmp    a412 <fwp_hof0.constprop.0+0xcd2>
    abdd:	0f 1f 00             	nopl   (%rax)
    abe0:	48 8b 04 24          	mov    (%rsp),%rax
    abe4:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    abeb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    abf2:	48 8b 68 10          	mov    0x10(%rax),%rbp
    abf6:	48 29 c8             	sub    %rcx,%rax
    abf9:	48 c1 e2 10          	shl    $0x10,%rdx
    abfd:	48 39 d0             	cmp    %rdx,%rax
    ac00:	73 66                	jae    ac68 <fwp_hof0.constprop.0+0x1528>
    ac02:	48 89 c7             	mov    %rax,%rdi
    ac05:	48 c1 ef 10          	shr    $0x10,%rdi
    ac09:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    ac0d:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ac11:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ac15:	48 85 ff             	test   %rdi,%rdi
    ac18:	74 4e                	je     ac68 <fwp_hof0.constprop.0+0x1528>
    ac1a:	44 0f b6 06          	movzbl (%rsi),%r8d
    ac1e:	41 80 f8 02          	cmp    $0x2,%r8b
    ac22:	0f 84 85 01 00 00    	je     adad <fwp_hof0.constprop.0+0x166d>
    ac28:	41 80 f8 01          	cmp    $0x1,%r8b
    ac2c:	75 3a                	jne    ac68 <fwp_hof0.constprop.0+0x1528>
    ac2e:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    ac32:	0f b7 c0             	movzwl %ax,%eax
    ac35:	8b 76 1c             	mov    0x1c(%rsi),%esi
    ac38:	49 0f af c0          	imul   %r8,%rax
    ac3c:	48 c1 e8 20          	shr    $0x20,%rax
    ac40:	48 39 f0             	cmp    %rsi,%rax
    ac43:	73 23                	jae    ac68 <fwp_hof0.constprop.0+0x1528>
    ac45:	48 01 c7             	add    %rax,%rdi
    ac48:	80 3f 01             	cmpb   $0x1,(%rdi)
    ac4b:	75 1b                	jne    ac68 <fwp_hof0.constprop.0+0x1528>
    ac4d:	48 8b 3c 24          	mov    (%rsp),%rdi
    ac51:	e8 3a ab ff ff       	call   5790 <fwp_mem_free>
    ac56:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    ac5d:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    ac64:	48 c1 e2 10          	shl    $0x10,%rdx
    ac68:	48 89 e8             	mov    %rbp,%rax
    ac6b:	48 29 c8             	sub    %rcx,%rax
    ac6e:	48 39 d0             	cmp    %rdx,%rax
    ac71:	0f 83 39 f8 ff ff    	jae    a4b0 <fwp_hof0.constprop.0+0xd70>
    ac77:	48 89 2c 24          	mov    %rbp,(%rsp)
    ac7b:	e9 bf f7 ff ff       	jmp    a43f <fwp_hof0.constprop.0+0xcff>
    ac80:	66 85 c0             	test   %ax,%ax
    ac83:	0f 85 17 fc ff ff    	jne    a8a0 <fwp_hof0.constprop.0+0x1160>
    ac89:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    ac8d:	0f 85 09 fc ff ff    	jne    a89c <fwp_hof0.constprop.0+0x115c>
    ac93:	48 89 ef             	mov    %rbp,%rdi
    ac96:	e8 b5 a8 ff ff       	call   5550 <fwp_rc_forget_slot>
    ac9b:	e9 fc fb ff ff       	jmp    a89c <fwp_hof0.constprop.0+0x115c>
    aca0:	48 85 ed             	test   %rbp,%rbp
    aca3:	0f 85 67 ef ff ff    	jne    9c10 <fwp_hof0.constprop.0+0x4d0>
    aca9:	e9 d2 ef ff ff       	jmp    9c80 <fwp_hof0.constprop.0+0x540>
    acae:	66 90                	xchg   %ax,%ax
    acb0:	be 08 00 00 00       	mov    $0x8,%esi
    acb5:	48 89 ef             	mov    %rbp,%rdi
    acb8:	e8 63 88 ff ff       	call   3520 <calloc@plt>
    acbd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    acc2:	49 89 c1             	mov    %rax,%r9
    acc5:	e9 17 fe ff ff       	jmp    aae1 <fwp_hof0.constprop.0+0x13a1>
    acca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    acd0:	66 85 c0             	test   %ax,%ax
    acd3:	0f 85 20 eb ff ff    	jne    97f9 <fwp_hof0.constprop.0+0xb9>
    acd9:	e9 07 eb ff ff       	jmp    97e5 <fwp_hof0.constprop.0+0xa5>
    acde:	66 90                	xchg   %ax,%ax
    ace0:	66 85 c0             	test   %ax,%ax
    ace3:	0f 85 de f8 ff ff    	jne    a5c7 <fwp_hof0.constprop.0+0xe87>
    ace9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    aced:	0f 85 d0 f8 ff ff    	jne    a5c3 <fwp_hof0.constprop.0+0xe83>
    acf3:	4c 89 ff             	mov    %r15,%rdi
    acf6:	e8 55 a8 ff ff       	call   5550 <fwp_rc_forget_slot>
    acfb:	e9 c3 f8 ff ff       	jmp    a5c3 <fwp_hof0.constprop.0+0xe83>
    ad00:	66 85 c0             	test   %ax,%ax
    ad03:	0f 85 77 f9 ff ff    	jne    a680 <fwp_hof0.constprop.0+0xf40>
    ad09:	41 0f b6 04 24       	movzbl (%r12),%eax
    ad0e:	84 c0                	test   %al,%al
    ad10:	0f 84 6a f9 ff ff    	je     a680 <fwp_hof0.constprop.0+0xf40>
    ad16:	3c 01                	cmp    $0x1,%al
    ad18:	0f 85 4e f9 ff ff    	jne    a66c <fwp_hof0.constprop.0+0xf2c>
    ad1e:	48 89 ef             	mov    %rbp,%rdi
    ad21:	e8 6a aa ff ff       	call   5790 <fwp_mem_free>
    ad26:	e9 55 f9 ff ff       	jmp    a680 <fwp_hof0.constprop.0+0xf40>
    ad2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad30:	be 68 00 00 00       	mov    $0x68,%esi
    ad35:	41 bc 01 00 00 00    	mov    $0x1,%r12d
    ad3b:	e9 7b ec ff ff       	jmp    99bb <fwp_hof0.constprop.0+0x27b>
    ad40:	31 ff                	xor    %edi,%edi
    ad42:	e8 09 95 ff ff       	call   4250 <descent_phase_step>
    ad47:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ad4b:	e9 d6 eb ff ff       	jmp    9926 <fwp_hof0.constprop.0+0x1e6>
    ad50:	49 8b 04 24          	mov    (%r12),%rax
    ad54:	48 85 c0             	test   %rax,%rax
    ad57:	0f 88 07 fc ff ff    	js     a964 <fwp_hof0.constprop.0+0x1224>
    ad5d:	48 8b b3 d8 13 00 00 	mov    0x13d8(%rbx),%rsi
    ad64:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    ad69:	48 2b 8b b0 13 00 00 	sub    0x13b0(%rbx),%rcx
    ad70:	48 c1 e6 10          	shl    $0x10,%rsi
    ad74:	48 39 f1             	cmp    %rsi,%rcx
    ad77:	0f 83 e7 fb ff ff    	jae    a964 <fwp_hof0.constprop.0+0x1224>
    ad7d:	48 89 ce             	mov    %rcx,%rsi
    ad80:	48 c1 ee 10          	shr    $0x10,%rsi
    ad84:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    ad88:	48 8b b3 f8 13 00 00 	mov    0x13f8(%rbx),%rsi
    ad8f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ad93:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ad97:	48 85 ff             	test   %rdi,%rdi
    ad9a:	0f 84 c4 fb ff ff    	je     a964 <fwp_hof0.constprop.0+0x1224>
    ada0:	48 0f ba f0 3f       	btr    $0x3f,%rax
    ada5:	49 89 c7             	mov    %rax,%r15
    ada8:	e9 d8 f3 ff ff       	jmp    a185 <fwp_hof0.constprop.0+0xa45>
    adad:	66 85 c0             	test   %ax,%ax
    adb0:	0f 85 b2 fe ff ff    	jne    ac68 <fwp_hof0.constprop.0+0x1528>
    adb6:	e9 8d fe ff ff       	jmp    ac48 <fwp_hof0.constprop.0+0x1508>
    adbb:	48 89 ea             	mov    %rbp,%rdx
    adbe:	48 c1 ea 11          	shr    $0x11,%rdx
    adc2:	48 31 ea             	xor    %rbp,%rdx
    adc5:	48 89 d0             	mov    %rdx,%rax
    adc8:	48 c1 e8 09          	shr    $0x9,%rax
    adcc:	48 31 c2             	xor    %rax,%rdx
    adcf:	0f b6 d2             	movzbl %dl,%edx
    add2:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    add9:	00 
    adda:	48 85 c0             	test   %rax,%rax
    addd:	75 2a                	jne    ae09 <fwp_hof0.constprop.0+0x16c9>
    addf:	e9 85 00 00 00       	jmp    ae69 <fwp_hof0.constprop.0+0x1729>
    ade4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    adea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    adf1:	00 00 00 00 
    adf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    adfc:	00 00 00 00 
    ae00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    ae04:	48 85 c0             	test   %rax,%rax
    ae07:	74 60                	je     ae69 <fwp_hof0.constprop.0+0x1729>
    ae09:	48 89 c2             	mov    %rax,%rdx
    ae0c:	48 39 28             	cmp    %rbp,(%rax)
    ae0f:	75 ef                	jne    ae00 <fwp_hof0.constprop.0+0x16c0>
    ae11:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ae15:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    ae19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ae1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    ae24:	0f 85 86 f6 ff ff    	jne    a4b0 <fwp_hof0.constprop.0+0xd70>
    ae2a:	48 89 ef             	mov    %rbp,%rdi
    ae2d:	e8 1e a7 ff ff       	call   5550 <fwp_rc_forget_slot>
    ae32:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    ae36:	e9 75 f6 ff ff       	jmp    a4b0 <fwp_hof0.constprop.0+0xd70>
    ae3b:	e8 f0 a5 ff ff       	call   5430 <fwp_rc_wide_dup>
    ae40:	e9 93 ea ff ff       	jmp    98d8 <fwp_hof0.constprop.0+0x198>
    ae45:	4c 89 e0             	mov    %r12,%rax
    ae48:	48 c1 e8 11          	shr    $0x11,%rax
    ae4c:	4c 31 e0             	xor    %r12,%rax
    ae4f:	48 89 c2             	mov    %rax,%rdx
    ae52:	48 c1 ea 09          	shr    $0x9,%rdx
    ae56:	48 31 d0             	xor    %rdx,%rax
    ae59:	0f b6 d0             	movzbl %al,%edx
    ae5c:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    ae63:	00 
    ae64:	48 85 c0             	test   %rax,%rax
    ae67:	75 60                	jne    aec9 <fwp_hof0.constprop.0+0x1789>
    ae69:	48 8d 3d 20 4a 00 00 	lea    0x4a20(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    ae70:	e8 7b 95 ff ff       	call   43f0 <fwp_trap>
    ae75:	4d 89 f4             	mov    %r14,%r12
    ae78:	4c 89 cf             	mov    %r9,%rdi
    ae7b:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    ae82:	00 
    ae83:	31 f6                	xor    %esi,%esi
    ae85:	4c 89 e5             	mov    %r12,%rbp
    ae88:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    ae8d:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    ae92:	4c 29 f5             	sub    %r14,%rbp
    ae95:	e8 26 86 ff ff       	call   34c0 <memset@plt>
    ae9a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    ae9f:	49 89 c1             	mov    %rax,%r9
    aea2:	e9 69 fc ff ff       	jmp    ab10 <fwp_hof0.constprop.0+0x13d0>
    aea7:	0f 1f 00             	nopl   (%rax)
    aeaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aeb1:	00 00 00 00 
    aeb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aebc:	00 00 00 00 
    aec0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    aec4:	48 85 c0             	test   %rax,%rax
    aec7:	74 a0                	je     ae69 <fwp_hof0.constprop.0+0x1729>
    aec9:	48 89 c2             	mov    %rax,%rdx
    aecc:	4c 3b 20             	cmp    (%rax),%r12
    aecf:	75 ef                	jne    aec0 <fwp_hof0.constprop.0+0x1780>
    aed1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    aed5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    aed9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    aedd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    aee4:	0f 85 96 f7 ff ff    	jne    a680 <fwp_hof0.constprop.0+0xf40>
    aeea:	4c 89 e7             	mov    %r12,%rdi
    aeed:	e8 5e a6 ff ff       	call   5550 <fwp_rc_forget_slot>
    aef2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    aef7:	e9 84 f7 ff ff       	jmp    a680 <fwp_hof0.constprop.0+0xf40>
    aefc:	e8 2f a5 ff ff       	call   5430 <fwp_rc_wide_dup>
    af01:	e9 f3 e8 ff ff       	jmp    97f9 <fwp_hof0.constprop.0+0xb9>
    af06:	45 31 ff             	xor    %r15d,%r15d
    af09:	e9 c7 f3 ff ff       	jmp    a2d5 <fwp_hof0.constprop.0+0xb95>
    af0e:	48 8d 3d a3 49 00 00 	lea    0x49a3(%rip),%rdi        # f8b8 <_IO_stdin_used+0x8b8>
    af15:	e8 d6 94 ff ff       	call   43f0 <fwp_trap>
    af1a:	48 8d 3d 46 42 00 00 	lea    0x4246(%rip),%rdi        # f167 <_IO_stdin_used+0x167>
    af21:	e8 ca 94 ff ff       	call   43f0 <fwp_trap>
    af26:	48 8d 3d 63 4a 00 00 	lea    0x4a63(%rip),%rdi        # f990 <_IO_stdin_used+0x990>
    af2d:	e8 be 94 ff ff       	call   43f0 <fwp_trap>
    af32:	45 31 ed             	xor    %r13d,%r13d
    af35:	e9 3c fa ff ff       	jmp    a976 <fwp_hof0.constprop.0+0x1236>
    af3a:	48 8d 3d db 42 00 00 	lea    0x42db(%rip),%rdi        # f21c <_IO_stdin_used+0x21c>
    af41:	e8 aa 94 ff ff       	call   43f0 <fwp_trap>
    af46:	48 8d 3d e9 42 00 00 	lea    0x42e9(%rip),%rdi        # f236 <_IO_stdin_used+0x236>
    af4d:	e8 9e 94 ff ff       	call   43f0 <fwp_trap>
    af52:	48 8d 3d 37 42 00 00 	lea    0x4237(%rip),%rdi        # f190 <_IO_stdin_used+0x190>
    af59:	e8 92 94 ff ff       	call   43f0 <fwp_trap>
    af5e:	66 90                	xchg   %ax,%ax
    af60:	48 8d 3d 51 4a 00 00 	lea    0x4a51(%rip),%rdi        # f9b8 <_IO_stdin_used+0x9b8>
    af67:	e8 84 94 ff ff       	call   43f0 <fwp_trap>
    af6c:	4d 85 e4             	test   %r12,%r12
    af6f:	0f 84 8e fb ff ff    	je     ab03 <fwp_hof0.constprop.0+0x13c3>
    af75:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    af7c:	00 
    af7d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    af82:	48 89 05 cf a4 01 00 	mov    %rax,0x1a4cf(%rip)        # 25458 <fwp_cleanups>
    af89:	e8 e2 a0 ff ff       	call   5070 <fwp_tape_buffers_release>
    af8e:	ba 13 00 00 00       	mov    $0x13,%edx
    af93:	48 8b 0d a6 80 00 00 	mov    0x80a6(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    af9a:	be 01 00 00 00       	mov    $0x1,%esi
    af9f:	48 8d 3d 62 40 00 00 	lea    0x4062(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    afa6:	e8 d5 86 ff ff       	call   3680 <fwrite@plt>
    afab:	31 ff                	xor    %edi,%edi
    afad:	e8 0e 86 ff ff       	call   35c0 <fflush@plt>
    afb2:	bf 66 00 00 00       	mov    $0x66,%edi
    afb7:	e8 e4 86 ff ff       	call   36a0 <_Exit@plt>
    afbc:	48 8d 3d 9d 49 00 00 	lea    0x499d(%rip),%rdi        # f960 <_IO_stdin_used+0x960>
    afc3:	e8 28 94 ff ff       	call   43f0 <fwp_trap>
    afc8:	48 8b 0d 71 80 00 00 	mov    0x8071(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    afcf:	ba 13 00 00 00       	mov    $0x13,%edx
    afd4:	be 01 00 00 00       	mov    $0x1,%esi
    afd9:	48 8d 3d 28 40 00 00 	lea    0x4028(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    afe0:	e8 9b 86 ff ff       	call   3680 <fwrite@plt>
    afe5:	31 ff                	xor    %edi,%edi
    afe7:	e8 d4 85 ff ff       	call   35c0 <fflush@plt>
    afec:	bf 66 00 00 00       	mov    $0x66,%edi
    aff1:	e8 aa 86 ff ff       	call   36a0 <_Exit@plt>
    aff6:	48 8d 3d 03 49 00 00 	lea    0x4903(%rip),%rdi        # f900 <_IO_stdin_used+0x900>
    affd:	e8 ee 93 ff ff       	call   43f0 <fwp_trap>
    b002:	e8 59 84 ff ff       	call   3460 <__stack_chk_fail@plt>
    b007:	48 8d 3d 38 42 00 00 	lea    0x4238(%rip),%rdi        # f246 <_IO_stdin_used+0x246>
    b00e:	e8 dd 93 ff ff       	call   43f0 <fwp_trap>
    b013:	48 8b 0d 26 80 00 00 	mov    0x8026(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b01a:	ba 13 00 00 00       	mov    $0x13,%edx
    b01f:	be 01 00 00 00       	mov    $0x1,%esi
    b024:	48 8d 3d dd 3f 00 00 	lea    0x3fdd(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b02b:	e8 50 86 ff ff       	call   3680 <fwrite@plt>
    b030:	31 ff                	xor    %edi,%edi
    b032:	e8 89 85 ff ff       	call   35c0 <fflush@plt>
    b037:	bf 66 00 00 00       	mov    $0x66,%edi
    b03c:	e8 5f 86 ff ff       	call   36a0 <_Exit@plt>
    b041:	0f 1f 40 00          	nopl   0x0(%rax)
    b045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b04c:	00 00 00 00 

000000000000b050 <f0>:
    b050:	41 56                	push   %r14
    b052:	4c 8d 35 67 87 01 00 	lea    0x18767(%rip),%r14        # 237c0 <fwp_heap>
    b059:	41 55                	push   %r13
    b05b:	41 54                	push   %r12
    b05d:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b063:	55                   	push   %rbp
    b064:	53                   	push   %rbx
    b065:	31 db                	xor    %ebx,%ebx
    b067:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b06e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b075:	00 00 
    b077:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b07e:	00 
    b07f:	31 c0                	xor    %eax,%eax
    b081:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b088:	00 
    b089:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b090:	00 00 
    b092:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b097:	48 8d 05 d2 cc ff ff 	lea    -0x332e(%rip),%rax        # 7d70 <fwp_drop1>
    b09e:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b0a3:	48 8b 05 ae a3 01 00 	mov    0x1a3ae(%rip),%rax        # 25458 <fwp_cleanups>
    b0aa:	48 89 25 a7 a3 01 00 	mov    %rsp,0x1a3a7(%rip)        # 25458 <fwp_cleanups>
    b0b1:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b0b5:	48 89 04 24          	mov    %rax,(%rsp)
    b0b9:	48 8d 05 10 8b ff ff 	lea    -0x74f0(%rip),%rax        # 3bd0 <fwp_range_release>
    b0c0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b0c5:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b0ca:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b0cf:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b0d4:	eb 47                	jmp    b11d <f0+0xcd>
    b0d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b0dd:	00 00 00 
    b0e0:	80 f9 01             	cmp    $0x1,%cl
    b0e3:	75 29                	jne    b10e <f0+0xbe>
    b0e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b0e8:	0f b7 c0             	movzwl %ax,%eax
    b0eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b0ee:	48 0f af c1          	imul   %rcx,%rax
    b0f2:	48 c1 e8 20          	shr    $0x20,%rax
    b0f6:	48 39 d0             	cmp    %rdx,%rax
    b0f9:	73 13                	jae    b10e <f0+0xbe>
    b0fb:	49 01 c5             	add    %rax,%r13
    b0fe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b103:	0f 84 c7 27 00 00    	je     d8d0 <f0+0x2880>
    b109:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b10e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b113:	49 83 ec 01          	sub    $0x1,%r12
    b117:	0f 82 83 00 00 00    	jb     b1a0 <f0+0x150>
    b11d:	48 89 ee             	mov    %rbp,%rsi
    b120:	bf 01 00 00 00       	mov    $0x1,%edi
    b125:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b12c:	00 
    b12d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b132:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b139:	00 
    b13a:	e8 71 ac ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b13f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b146:	48 89 c3             	mov    %rax,%rbx
    b149:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b150:	48 c1 e2 10          	shl    $0x10,%rdx
    b154:	48 39 d0             	cmp    %rdx,%rax
    b157:	73 b5                	jae    b10e <f0+0xbe>
    b159:	48 89 c2             	mov    %rax,%rdx
    b15c:	48 c1 ea 10          	shr    $0x10,%rdx
    b160:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b164:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b16b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b16f:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b173:	4d 85 ed             	test   %r13,%r13
    b176:	74 96                	je     b10e <f0+0xbe>
    b178:	0f b6 0a             	movzbl (%rdx),%ecx
    b17b:	80 f9 02             	cmp    $0x2,%cl
    b17e:	0f 85 5c ff ff ff    	jne    b0e0 <f0+0x90>
    b184:	66 85 c0             	test   %ax,%ax
    b187:	0f 84 71 ff ff ff    	je     b0fe <f0+0xae>
    b18d:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b192:	49 83 ec 01          	sub    $0x1,%r12
    b196:	73 85                	jae    b11d <f0+0xcd>
    b198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b19f:	00 
    b1a0:	48 8b 04 24          	mov    (%rsp),%rax
    b1a4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b1a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b1ae:	66 0f 6f 05 8a 4a 00 	movdqa 0x4a8a(%rip),%xmm0        # fc40 <msg.4+0xd0>
    b1b5:	00 
    b1b6:	48 89 05 9b a2 01 00 	mov    %rax,0x1a29b(%rip)        # 25458 <fwp_cleanups>
    b1bd:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b1c2:	e8 e9 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b1c7:	48 8b 15 ca 99 01 00 	mov    0x199ca(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b1ce:	49 89 c5             	mov    %rax,%r13
    b1d1:	48 2b 05 98 99 01 00 	sub    0x19998(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b1d8:	48 c1 e2 10          	shl    $0x10,%rdx
    b1dc:	48 39 d0             	cmp    %rdx,%rax
    b1df:	73 59                	jae    b23a <f0+0x1ea>
    b1e1:	48 89 c2             	mov    %rax,%rdx
    b1e4:	48 c1 ea 10          	shr    $0x10,%rdx
    b1e8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b1ec:	48 8b 15 c5 99 01 00 	mov    0x199c5(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b1f3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b1f7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b1fb:	4d 85 e4             	test   %r12,%r12
    b1fe:	74 3a                	je     b23a <f0+0x1ea>
    b200:	0f b6 0a             	movzbl (%rdx),%ecx
    b203:	80 f9 02             	cmp    $0x2,%cl
    b206:	0f 84 74 27 00 00    	je     d980 <f0+0x2930>
    b20c:	80 f9 01             	cmp    $0x1,%cl
    b20f:	75 29                	jne    b23a <f0+0x1ea>
    b211:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b214:	0f b7 c0             	movzwl %ax,%eax
    b217:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b21a:	48 0f af c1          	imul   %rcx,%rax
    b21e:	48 c1 e8 20          	shr    $0x20,%rax
    b222:	48 39 d0             	cmp    %rdx,%rax
    b225:	73 13                	jae    b23a <f0+0x1ea>
    b227:	49 01 c4             	add    %rax,%r12
    b22a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b22f:	0f 84 26 29 00 00    	je     db5b <f0+0x2b0b>
    b235:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b23a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b23f:	bf 01 00 00 00       	mov    $0x1,%edi
    b244:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b249:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b250:	00 f0 3f 
    b253:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b258:	e8 53 ab ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b25d:	48 8b 15 34 99 01 00 	mov    0x19934(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b264:	49 89 c5             	mov    %rax,%r13
    b267:	48 2b 05 02 99 01 00 	sub    0x19902(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b26e:	48 c1 e2 10          	shl    $0x10,%rdx
    b272:	48 39 d0             	cmp    %rdx,%rax
    b275:	73 59                	jae    b2d0 <f0+0x280>
    b277:	48 89 c2             	mov    %rax,%rdx
    b27a:	48 c1 ea 10          	shr    $0x10,%rdx
    b27e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b282:	48 8b 15 2f 99 01 00 	mov    0x1992f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b289:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b28d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b291:	4d 85 e4             	test   %r12,%r12
    b294:	74 3a                	je     b2d0 <f0+0x280>
    b296:	0f b6 0a             	movzbl (%rdx),%ecx
    b299:	80 f9 02             	cmp    $0x2,%cl
    b29c:	0f 84 ce 26 00 00    	je     d970 <f0+0x2920>
    b2a2:	80 f9 01             	cmp    $0x1,%cl
    b2a5:	75 29                	jne    b2d0 <f0+0x280>
    b2a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b2aa:	0f b7 c0             	movzwl %ax,%eax
    b2ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b2b0:	48 0f af c1          	imul   %rcx,%rax
    b2b4:	48 c1 e8 20          	shr    $0x20,%rax
    b2b8:	48 39 d0             	cmp    %rdx,%rax
    b2bb:	73 13                	jae    b2d0 <f0+0x280>
    b2bd:	49 01 c4             	add    %rax,%r12
    b2c0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b2c5:	0f 84 9d 28 00 00    	je     db68 <f0+0x2b18>
    b2cb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b2d0:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b2d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b2da:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b2df:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b2e6:	33 f3 bf 
    b2e9:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b2ee:	e8 bd aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b2f3:	48 8b 15 9e 98 01 00 	mov    0x1989e(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b2fa:	49 89 c5             	mov    %rax,%r13
    b2fd:	48 2b 05 6c 98 01 00 	sub    0x1986c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b304:	48 c1 e2 10          	shl    $0x10,%rdx
    b308:	48 39 d0             	cmp    %rdx,%rax
    b30b:	73 59                	jae    b366 <f0+0x316>
    b30d:	48 89 c2             	mov    %rax,%rdx
    b310:	48 c1 ea 10          	shr    $0x10,%rdx
    b314:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b318:	48 8b 15 99 98 01 00 	mov    0x19899(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b31f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b323:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b327:	4d 85 e4             	test   %r12,%r12
    b32a:	74 3a                	je     b366 <f0+0x316>
    b32c:	0f b6 0a             	movzbl (%rdx),%ecx
    b32f:	80 f9 02             	cmp    $0x2,%cl
    b332:	0f 84 28 26 00 00    	je     d960 <f0+0x2910>
    b338:	80 f9 01             	cmp    $0x1,%cl
    b33b:	75 29                	jne    b366 <f0+0x316>
    b33d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b340:	0f b7 c0             	movzwl %ax,%eax
    b343:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b346:	48 0f af c1          	imul   %rcx,%rax
    b34a:	48 c1 e8 20          	shr    $0x20,%rax
    b34e:	48 39 d0             	cmp    %rdx,%rax
    b351:	73 13                	jae    b366 <f0+0x316>
    b353:	49 01 c4             	add    %rax,%r12
    b356:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b35b:	0f 84 14 28 00 00    	je     db75 <f0+0x2b25>
    b361:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b366:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b36b:	bf 01 00 00 00       	mov    $0x1,%edi
    b370:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b375:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b37c:	00 f0 3f 
    b37f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b384:	e8 27 aa ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b389:	48 8b 15 08 98 01 00 	mov    0x19808(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b390:	49 89 c5             	mov    %rax,%r13
    b393:	48 2b 05 d6 97 01 00 	sub    0x197d6(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b39a:	48 c1 e2 10          	shl    $0x10,%rdx
    b39e:	48 39 d0             	cmp    %rdx,%rax
    b3a1:	73 59                	jae    b3fc <f0+0x3ac>
    b3a3:	48 89 c2             	mov    %rax,%rdx
    b3a6:	48 c1 ea 10          	shr    $0x10,%rdx
    b3aa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b3ae:	48 8b 15 03 98 01 00 	mov    0x19803(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b3b5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b3b9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b3bd:	4d 85 e4             	test   %r12,%r12
    b3c0:	74 3a                	je     b3fc <f0+0x3ac>
    b3c2:	0f b6 0a             	movzbl (%rdx),%ecx
    b3c5:	80 f9 02             	cmp    $0x2,%cl
    b3c8:	0f 84 f2 25 00 00    	je     d9c0 <f0+0x2970>
    b3ce:	80 f9 01             	cmp    $0x1,%cl
    b3d1:	75 29                	jne    b3fc <f0+0x3ac>
    b3d3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b3d6:	0f b7 c0             	movzwl %ax,%eax
    b3d9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b3dc:	48 0f af c1          	imul   %rcx,%rax
    b3e0:	48 c1 e8 20          	shr    $0x20,%rax
    b3e4:	48 39 d0             	cmp    %rdx,%rax
    b3e7:	73 13                	jae    b3fc <f0+0x3ac>
    b3e9:	49 01 c4             	add    %rax,%r12
    b3ec:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b3f1:	0f 84 8b 27 00 00    	je     db82 <f0+0x2b32>
    b3f7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b3fc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b403:	33 f3 bf 
    b406:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b40d:	00 
    b40e:	bf 01 00 00 00       	mov    $0x1,%edi
    b413:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b41a:	00 
    b41b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b422:	00 
    b423:	e8 88 a9 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b428:	48 8b 15 69 97 01 00 	mov    0x19769(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    b42f:	49 89 c5             	mov    %rax,%r13
    b432:	48 2b 05 37 97 01 00 	sub    0x19737(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    b439:	48 c1 e2 10          	shl    $0x10,%rdx
    b43d:	48 39 d0             	cmp    %rdx,%rax
    b440:	73 59                	jae    b49b <f0+0x44b>
    b442:	48 89 c2             	mov    %rax,%rdx
    b445:	48 c1 ea 10          	shr    $0x10,%rdx
    b449:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b44d:	48 8b 15 64 97 01 00 	mov    0x19764(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    b454:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b458:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b45c:	4d 85 e4             	test   %r12,%r12
    b45f:	74 3a                	je     b49b <f0+0x44b>
    b461:	0f b6 0a             	movzbl (%rdx),%ecx
    b464:	80 f9 02             	cmp    $0x2,%cl
    b467:	0f 84 43 25 00 00    	je     d9b0 <f0+0x2960>
    b46d:	80 f9 01             	cmp    $0x1,%cl
    b470:	75 29                	jne    b49b <f0+0x44b>
    b472:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b475:	0f b7 c0             	movzwl %ax,%eax
    b478:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b47b:	48 0f af c1          	imul   %rcx,%rax
    b47f:	48 c1 e8 20          	shr    $0x20,%rax
    b483:	48 39 d0             	cmp    %rdx,%rax
    b486:	73 13                	jae    b49b <f0+0x44b>
    b488:	49 01 c4             	add    %rax,%r12
    b48b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b490:	0f 84 f9 26 00 00    	je     db8f <f0+0x2b3f>
    b496:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b49b:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b4a2:	00 f0 3f 
    b4a5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b4ac:	00 
    b4ad:	bf 01 00 00 00       	mov    $0x1,%edi
    b4b2:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    b4b9:	00 
    b4ba:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    b4c1:	00 
    b4c2:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    b4c9:	33 f3 bf 
    b4cc:	e8 df a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4d1:	48 89 c7             	mov    %rax,%rdi
    b4d4:	e8 77 b4 ff ff       	call   6950 <fwp_rc_fresh>
    b4d9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    b4e0:	00 
    b4e1:	bf 01 00 00 00       	mov    $0x1,%edi
    b4e6:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    b4ed:	00 
    b4ee:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    b4f5:	00 
    b4f6:	e8 b5 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b4fb:	48 89 c7             	mov    %rax,%rdi
    b4fe:	e8 4d b4 ff ff       	call   6950 <fwp_rc_fresh>
    b503:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    b50a:	00 
    b50b:	bf 01 00 00 00       	mov    $0x1,%edi
    b510:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    b517:	00 
    b518:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    b51f:	00 
    b520:	e8 8b a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b525:	48 89 c7             	mov    %rax,%rdi
    b528:	e8 23 b4 ff ff       	call   6950 <fwp_rc_fresh>
    b52d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    b534:	00 
    b535:	bf 01 00 00 00       	mov    $0x1,%edi
    b53a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    b541:	00 
    b542:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    b549:	00 
    b54a:	e8 61 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b54f:	48 89 c7             	mov    %rax,%rdi
    b552:	e8 f9 b3 ff ff       	call   6950 <fwp_rc_fresh>
    b557:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    b55e:	00 
    b55f:	bf 01 00 00 00       	mov    $0x1,%edi
    b564:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    b56b:	00 
    b56c:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    b573:	00 
    b574:	e8 37 a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b579:	48 89 c7             	mov    %rax,%rdi
    b57c:	e8 cf b3 ff ff       	call   6950 <fwp_rc_fresh>
    b581:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    b588:	00 
    b589:	bf 01 00 00 00       	mov    $0x1,%edi
    b58e:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    b595:	00 
    b596:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    b59d:	00 
    b59e:	e8 0d a8 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5a3:	48 89 c7             	mov    %rax,%rdi
    b5a6:	e8 a5 b3 ff ff       	call   6950 <fwp_rc_fresh>
    b5ab:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    b5b2:	00 
    b5b3:	bf 01 00 00 00       	mov    $0x1,%edi
    b5b8:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    b5bf:	00 
    b5c0:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    b5c7:	00 
    b5c8:	e8 e3 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5cd:	48 89 c7             	mov    %rax,%rdi
    b5d0:	e8 7b b3 ff ff       	call   6950 <fwp_rc_fresh>
    b5d5:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    b5dc:	00 
    b5dd:	bf 01 00 00 00       	mov    $0x1,%edi
    b5e2:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    b5e9:	00 
    b5ea:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    b5f1:	00 
    b5f2:	e8 b9 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b5f7:	48 89 c7             	mov    %rax,%rdi
    b5fa:	e8 51 b3 ff ff       	call   6950 <fwp_rc_fresh>
    b5ff:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    b606:	00 
    b607:	bf 01 00 00 00       	mov    $0x1,%edi
    b60c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    b613:	00 
    b614:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    b61b:	00 
    b61c:	e8 8f a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b621:	48 89 c7             	mov    %rax,%rdi
    b624:	e8 27 b3 ff ff       	call   6950 <fwp_rc_fresh>
    b629:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    b630:	00 
    b631:	bf 01 00 00 00       	mov    $0x1,%edi
    b636:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    b63d:	00 
    b63e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    b645:	00 
    b646:	e8 65 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b64b:	48 89 c7             	mov    %rax,%rdi
    b64e:	e8 fd b2 ff ff       	call   6950 <fwp_rc_fresh>
    b653:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    b65a:	00 
    b65b:	bf 01 00 00 00       	mov    $0x1,%edi
    b660:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    b667:	00 
    b668:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    b66f:	00 
    b670:	e8 3b a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b675:	48 89 c7             	mov    %rax,%rdi
    b678:	e8 d3 b2 ff ff       	call   6950 <fwp_rc_fresh>
    b67d:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    b684:	00 
    b685:	bf 01 00 00 00       	mov    $0x1,%edi
    b68a:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    b691:	00 
    b692:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    b699:	00 
    b69a:	e8 11 a7 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b69f:	48 89 c7             	mov    %rax,%rdi
    b6a2:	e8 a9 b2 ff ff       	call   6950 <fwp_rc_fresh>
    b6a7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    b6ae:	00 
    b6af:	bf 01 00 00 00       	mov    $0x1,%edi
    b6b4:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    b6bb:	00 
    b6bc:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    b6c3:	00 
    b6c4:	e8 e7 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6c9:	48 89 c7             	mov    %rax,%rdi
    b6cc:	e8 7f b2 ff ff       	call   6950 <fwp_rc_fresh>
    b6d1:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    b6d8:	00 
    b6d9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6de:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    b6e5:	00 
    b6e6:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    b6ed:	00 
    b6ee:	e8 bd a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b6f3:	48 89 c7             	mov    %rax,%rdi
    b6f6:	e8 55 b2 ff ff       	call   6950 <fwp_rc_fresh>
    b6fb:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    b702:	00 
    b703:	bf 01 00 00 00       	mov    $0x1,%edi
    b708:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    b70f:	00 
    b710:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    b717:	00 
    b718:	e8 93 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b71d:	48 89 c7             	mov    %rax,%rdi
    b720:	e8 2b b2 ff ff       	call   6950 <fwp_rc_fresh>
    b725:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    b72c:	00 
    b72d:	bf 01 00 00 00       	mov    $0x1,%edi
    b732:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    b739:	00 
    b73a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    b741:	00 
    b742:	e8 69 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b747:	48 89 c7             	mov    %rax,%rdi
    b74a:	e8 01 b2 ff ff       	call   6950 <fwp_rc_fresh>
    b74f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    b756:	00 
    b757:	bf 01 00 00 00       	mov    $0x1,%edi
    b75c:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    b763:	00 
    b764:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    b76b:	00 
    b76c:	e8 3f a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b771:	48 89 c7             	mov    %rax,%rdi
    b774:	e8 d7 b1 ff ff       	call   6950 <fwp_rc_fresh>
    b779:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    b780:	00 
    b781:	bf 01 00 00 00       	mov    $0x1,%edi
    b786:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    b78d:	00 
    b78e:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    b795:	00 
    b796:	e8 15 a6 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b79b:	48 89 c7             	mov    %rax,%rdi
    b79e:	e8 ad b1 ff ff       	call   6950 <fwp_rc_fresh>
    b7a3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    b7aa:	00 
    b7ab:	bf 01 00 00 00       	mov    $0x1,%edi
    b7b0:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    b7b7:	00 
    b7b8:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    b7bf:	00 
    b7c0:	e8 eb a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7c5:	48 89 c7             	mov    %rax,%rdi
    b7c8:	e8 83 b1 ff ff       	call   6950 <fwp_rc_fresh>
    b7cd:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    b7d4:	00 
    b7d5:	bf 01 00 00 00       	mov    $0x1,%edi
    b7da:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    b7e1:	00 
    b7e2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    b7e9:	00 
    b7ea:	e8 c1 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b7ef:	48 89 c7             	mov    %rax,%rdi
    b7f2:	e8 59 b1 ff ff       	call   6950 <fwp_rc_fresh>
    b7f7:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    b7fe:	00 
    b7ff:	bf 01 00 00 00       	mov    $0x1,%edi
    b804:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    b80b:	00 
    b80c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    b813:	00 
    b814:	e8 97 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b819:	48 89 c7             	mov    %rax,%rdi
    b81c:	e8 2f b1 ff ff       	call   6950 <fwp_rc_fresh>
    b821:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    b828:	00 
    b829:	bf 01 00 00 00       	mov    $0x1,%edi
    b82e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    b835:	00 
    b836:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    b83d:	00 
    b83e:	e8 6d a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b843:	48 89 c7             	mov    %rax,%rdi
    b846:	e8 05 b1 ff ff       	call   6950 <fwp_rc_fresh>
    b84b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    b852:	00 
    b853:	bf 01 00 00 00       	mov    $0x1,%edi
    b858:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    b85f:	00 
    b860:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    b867:	00 
    b868:	e8 43 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b86d:	48 89 c7             	mov    %rax,%rdi
    b870:	e8 db b0 ff ff       	call   6950 <fwp_rc_fresh>
    b875:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    b87c:	00 
    b87d:	bf 01 00 00 00       	mov    $0x1,%edi
    b882:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    b889:	00 
    b88a:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    b891:	00 
    b892:	e8 19 a5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b897:	48 89 c7             	mov    %rax,%rdi
    b89a:	e8 b1 b0 ff ff       	call   6950 <fwp_rc_fresh>
    b89f:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    b8a6:	00 
    b8a7:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ac:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    b8b3:	00 
    b8b4:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    b8bb:	00 
    b8bc:	e8 ef a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8c1:	48 89 c7             	mov    %rax,%rdi
    b8c4:	e8 87 b0 ff ff       	call   6950 <fwp_rc_fresh>
    b8c9:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    b8d0:	00 
    b8d1:	bf 01 00 00 00       	mov    $0x1,%edi
    b8d6:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    b8dd:	00 
    b8de:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    b8e5:	00 
    b8e6:	e8 c5 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b8eb:	48 89 c7             	mov    %rax,%rdi
    b8ee:	e8 5d b0 ff ff       	call   6950 <fwp_rc_fresh>
    b8f3:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    b8fa:	00 
    b8fb:	bf 01 00 00 00       	mov    $0x1,%edi
    b900:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    b907:	00 
    b908:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    b90f:	00 
    b910:	e8 9b a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b915:	48 89 c7             	mov    %rax,%rdi
    b918:	e8 33 b0 ff ff       	call   6950 <fwp_rc_fresh>
    b91d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    b924:	00 
    b925:	bf 01 00 00 00       	mov    $0x1,%edi
    b92a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    b931:	00 
    b932:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    b939:	00 
    b93a:	e8 71 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b93f:	48 89 c7             	mov    %rax,%rdi
    b942:	e8 09 b0 ff ff       	call   6950 <fwp_rc_fresh>
    b947:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    b94e:	00 
    b94f:	bf 01 00 00 00       	mov    $0x1,%edi
    b954:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    b95b:	00 
    b95c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    b963:	00 
    b964:	e8 47 a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b969:	48 89 c7             	mov    %rax,%rdi
    b96c:	e8 df af ff ff       	call   6950 <fwp_rc_fresh>
    b971:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    b978:	00 
    b979:	bf 01 00 00 00       	mov    $0x1,%edi
    b97e:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    b985:	00 
    b986:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    b98d:	00 
    b98e:	e8 1d a4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b993:	48 89 c7             	mov    %rax,%rdi
    b996:	e8 b5 af ff ff       	call   6950 <fwp_rc_fresh>
    b99b:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    b9a2:	00 
    b9a3:	bf 01 00 00 00       	mov    $0x1,%edi
    b9a8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    b9af:	00 
    b9b0:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    b9b7:	00 
    b9b8:	e8 f3 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9bd:	48 89 c7             	mov    %rax,%rdi
    b9c0:	e8 8b af ff ff       	call   6950 <fwp_rc_fresh>
    b9c5:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    b9cc:	00 
    b9cd:	bf 01 00 00 00       	mov    $0x1,%edi
    b9d2:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    b9d9:	00 
    b9da:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    b9e1:	00 
    b9e2:	e8 c9 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    b9e7:	48 89 c7             	mov    %rax,%rdi
    b9ea:	e8 61 af ff ff       	call   6950 <fwp_rc_fresh>
    b9ef:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    b9f6:	00 
    b9f7:	bf 01 00 00 00       	mov    $0x1,%edi
    b9fc:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    ba03:	00 
    ba04:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    ba0b:	00 
    ba0c:	e8 9f a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba11:	48 89 c7             	mov    %rax,%rdi
    ba14:	e8 37 af ff ff       	call   6950 <fwp_rc_fresh>
    ba19:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    ba20:	00 
    ba21:	bf 01 00 00 00       	mov    $0x1,%edi
    ba26:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    ba2d:	00 
    ba2e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    ba35:	00 
    ba36:	e8 75 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba3b:	48 89 c7             	mov    %rax,%rdi
    ba3e:	e8 0d af ff ff       	call   6950 <fwp_rc_fresh>
    ba43:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    ba4a:	00 
    ba4b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba50:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    ba57:	00 
    ba58:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    ba5f:	00 
    ba60:	e8 4b a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba65:	48 89 c7             	mov    %rax,%rdi
    ba68:	e8 e3 ae ff ff       	call   6950 <fwp_rc_fresh>
    ba6d:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    ba74:	00 
    ba75:	bf 01 00 00 00       	mov    $0x1,%edi
    ba7a:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    ba81:	00 
    ba82:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    ba89:	00 
    ba8a:	e8 21 a3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ba8f:	48 89 c7             	mov    %rax,%rdi
    ba92:	e8 b9 ae ff ff       	call   6950 <fwp_rc_fresh>
    ba97:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    ba9e:	00 
    ba9f:	bf 01 00 00 00       	mov    $0x1,%edi
    baa4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    baab:	00 
    baac:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    bab3:	00 
    bab4:	e8 f7 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bab9:	48 89 c7             	mov    %rax,%rdi
    babc:	e8 8f ae ff ff       	call   6950 <fwp_rc_fresh>
    bac1:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    bac8:	00 
    bac9:	bf 01 00 00 00       	mov    $0x1,%edi
    bace:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    bad5:	00 
    bad6:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    badd:	00 
    bade:	e8 cd a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bae3:	48 89 c7             	mov    %rax,%rdi
    bae6:	e8 65 ae ff ff       	call   6950 <fwp_rc_fresh>
    baeb:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    baf2:	00 
    baf3:	bf 01 00 00 00       	mov    $0x1,%edi
    baf8:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    baff:	00 
    bb00:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    bb07:	00 
    bb08:	e8 a3 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb0d:	48 89 c7             	mov    %rax,%rdi
    bb10:	e8 3b ae ff ff       	call   6950 <fwp_rc_fresh>
    bb15:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    bb1c:	00 
    bb1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb22:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    bb29:	00 
    bb2a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    bb31:	00 
    bb32:	e8 79 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb37:	48 89 c7             	mov    %rax,%rdi
    bb3a:	e8 11 ae ff ff       	call   6950 <fwp_rc_fresh>
    bb3f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    bb46:	00 
    bb47:	bf 01 00 00 00       	mov    $0x1,%edi
    bb4c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    bb53:	00 
    bb54:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    bb5b:	00 
    bb5c:	e8 4f a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb61:	48 89 c7             	mov    %rax,%rdi
    bb64:	e8 e7 ad ff ff       	call   6950 <fwp_rc_fresh>
    bb69:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    bb70:	00 
    bb71:	bf 01 00 00 00       	mov    $0x1,%edi
    bb76:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    bb7d:	00 
    bb7e:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    bb85:	00 
    bb86:	e8 25 a2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bb8b:	48 89 c7             	mov    %rax,%rdi
    bb8e:	e8 bd ad ff ff       	call   6950 <fwp_rc_fresh>
    bb93:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    bb9a:	00 
    bb9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bba0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    bba7:	00 
    bba8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    bbaf:	00 
    bbb0:	e8 fb a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbb5:	48 89 c7             	mov    %rax,%rdi
    bbb8:	e8 93 ad ff ff       	call   6950 <fwp_rc_fresh>
    bbbd:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    bbc4:	00 
    bbc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbca:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    bbd1:	00 
    bbd2:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    bbd9:	00 
    bbda:	e8 d1 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bbdf:	48 89 c7             	mov    %rax,%rdi
    bbe2:	e8 69 ad ff ff       	call   6950 <fwp_rc_fresh>
    bbe7:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    bbee:	00 
    bbef:	bf 01 00 00 00       	mov    $0x1,%edi
    bbf4:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    bbfb:	00 
    bbfc:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    bc03:	00 
    bc04:	e8 a7 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc09:	48 89 c7             	mov    %rax,%rdi
    bc0c:	e8 3f ad ff ff       	call   6950 <fwp_rc_fresh>
    bc11:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    bc18:	00 
    bc19:	bf 01 00 00 00       	mov    $0x1,%edi
    bc1e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    bc25:	00 
    bc26:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    bc2d:	00 
    bc2e:	e8 7d a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc33:	48 89 c7             	mov    %rax,%rdi
    bc36:	e8 15 ad ff ff       	call   6950 <fwp_rc_fresh>
    bc3b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    bc42:	00 
    bc43:	bf 01 00 00 00       	mov    $0x1,%edi
    bc48:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    bc4f:	00 
    bc50:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    bc57:	00 
    bc58:	e8 53 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc5d:	48 89 c7             	mov    %rax,%rdi
    bc60:	e8 eb ac ff ff       	call   6950 <fwp_rc_fresh>
    bc65:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    bc6c:	00 
    bc6d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc72:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    bc79:	00 
    bc7a:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    bc81:	00 
    bc82:	e8 29 a1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bc87:	48 89 c7             	mov    %rax,%rdi
    bc8a:	e8 c1 ac ff ff       	call   6950 <fwp_rc_fresh>
    bc8f:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    bc96:	00 
    bc97:	bf 01 00 00 00       	mov    $0x1,%edi
    bc9c:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    bca3:	00 
    bca4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    bcab:	00 
    bcac:	e8 ff a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcb1:	48 89 c7             	mov    %rax,%rdi
    bcb4:	e8 97 ac ff ff       	call   6950 <fwp_rc_fresh>
    bcb9:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    bcc0:	00 
    bcc1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcc6:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    bccd:	00 
    bcce:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    bcd5:	00 
    bcd6:	e8 d5 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bcdb:	48 89 c7             	mov    %rax,%rdi
    bcde:	e8 6d ac ff ff       	call   6950 <fwp_rc_fresh>
    bce3:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    bcea:	00 
    bceb:	bf 01 00 00 00       	mov    $0x1,%edi
    bcf0:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    bcf7:	00 
    bcf8:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    bcff:	00 
    bd00:	e8 ab a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd05:	48 89 c7             	mov    %rax,%rdi
    bd08:	e8 43 ac ff ff       	call   6950 <fwp_rc_fresh>
    bd0d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    bd14:	00 
    bd15:	bf 01 00 00 00       	mov    $0x1,%edi
    bd1a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    bd21:	00 
    bd22:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    bd29:	00 
    bd2a:	e8 81 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd2f:	48 89 c7             	mov    %rax,%rdi
    bd32:	e8 19 ac ff ff       	call   6950 <fwp_rc_fresh>
    bd37:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    bd3e:	00 
    bd3f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd44:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    bd4b:	00 
    bd4c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    bd53:	00 
    bd54:	e8 57 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd59:	48 89 c7             	mov    %rax,%rdi
    bd5c:	e8 ef ab ff ff       	call   6950 <fwp_rc_fresh>
    bd61:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    bd68:	00 
    bd69:	bf 01 00 00 00       	mov    $0x1,%edi
    bd6e:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    bd75:	00 
    bd76:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    bd7d:	00 
    bd7e:	e8 2d a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bd83:	48 89 c7             	mov    %rax,%rdi
    bd86:	e8 c5 ab ff ff       	call   6950 <fwp_rc_fresh>
    bd8b:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    bd92:	00 
    bd93:	bf 01 00 00 00       	mov    $0x1,%edi
    bd98:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    bd9f:	00 
    bda0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    bda7:	00 
    bda8:	e8 03 a0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bdad:	48 89 c7             	mov    %rax,%rdi
    bdb0:	e8 9b ab ff ff       	call   6950 <fwp_rc_fresh>
    bdb5:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    bdbc:	00 
    bdbd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdc2:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    bdc9:	00 
    bdca:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    bdd1:	00 
    bdd2:	e8 d9 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bdd7:	48 89 c7             	mov    %rax,%rdi
    bdda:	e8 71 ab ff ff       	call   6950 <fwp_rc_fresh>
    bddf:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    bde6:	00 
    bde7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdec:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    bdf3:	00 
    bdf4:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    bdfb:	00 
    bdfc:	e8 af 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be01:	48 89 c7             	mov    %rax,%rdi
    be04:	e8 47 ab ff ff       	call   6950 <fwp_rc_fresh>
    be09:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    be10:	00 
    be11:	bf 01 00 00 00       	mov    $0x1,%edi
    be16:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    be1d:	00 
    be1e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    be25:	00 
    be26:	e8 85 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be2b:	48 89 c7             	mov    %rax,%rdi
    be2e:	e8 1d ab ff ff       	call   6950 <fwp_rc_fresh>
    be33:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    be3a:	00 
    be3b:	bf 01 00 00 00       	mov    $0x1,%edi
    be40:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    be47:	00 
    be48:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    be4f:	00 
    be50:	e8 5b 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be55:	48 89 c7             	mov    %rax,%rdi
    be58:	e8 f3 aa ff ff       	call   6950 <fwp_rc_fresh>
    be5d:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    be64:	00 
    be65:	bf 01 00 00 00       	mov    $0x1,%edi
    be6a:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    be71:	00 
    be72:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    be79:	00 
    be7a:	e8 31 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    be7f:	48 89 c7             	mov    %rax,%rdi
    be82:	e8 c9 aa ff ff       	call   6950 <fwp_rc_fresh>
    be87:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    be8e:	00 
    be8f:	bf 01 00 00 00       	mov    $0x1,%edi
    be94:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    be9b:	00 
    be9c:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    bea3:	00 
    bea4:	e8 07 9f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bea9:	48 89 c7             	mov    %rax,%rdi
    beac:	e8 9f aa ff ff       	call   6950 <fwp_rc_fresh>
    beb1:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    beb8:	00 
    beb9:	bf 01 00 00 00       	mov    $0x1,%edi
    bebe:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    bec5:	00 
    bec6:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    becd:	00 
    bece:	e8 dd 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bed3:	48 89 c7             	mov    %rax,%rdi
    bed6:	e8 75 aa ff ff       	call   6950 <fwp_rc_fresh>
    bedb:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    bee2:	00 
    bee3:	bf 01 00 00 00       	mov    $0x1,%edi
    bee8:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    beef:	00 
    bef0:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    bef7:	00 
    bef8:	e8 b3 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    befd:	48 89 c7             	mov    %rax,%rdi
    bf00:	e8 4b aa ff ff       	call   6950 <fwp_rc_fresh>
    bf05:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    bf0c:	00 
    bf0d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf12:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    bf19:	00 
    bf1a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    bf21:	00 
    bf22:	e8 89 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf27:	48 89 c7             	mov    %rax,%rdi
    bf2a:	e8 21 aa ff ff       	call   6950 <fwp_rc_fresh>
    bf2f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    bf36:	00 
    bf37:	bf 01 00 00 00       	mov    $0x1,%edi
    bf3c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    bf43:	00 
    bf44:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    bf4b:	00 
    bf4c:	e8 5f 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf51:	48 89 c7             	mov    %rax,%rdi
    bf54:	e8 f7 a9 ff ff       	call   6950 <fwp_rc_fresh>
    bf59:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    bf60:	00 
    bf61:	bf 01 00 00 00       	mov    $0x1,%edi
    bf66:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    bf6d:	00 
    bf6e:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    bf75:	00 
    bf76:	e8 35 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bf7b:	48 89 c7             	mov    %rax,%rdi
    bf7e:	e8 cd a9 ff ff       	call   6950 <fwp_rc_fresh>
    bf83:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    bf8a:	00 
    bf8b:	bf 01 00 00 00       	mov    $0x1,%edi
    bf90:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    bf97:	00 
    bf98:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    bf9f:	00 
    bfa0:	e8 0b 9e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bfa5:	48 89 c7             	mov    %rax,%rdi
    bfa8:	e8 a3 a9 ff ff       	call   6950 <fwp_rc_fresh>
    bfad:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    bfb4:	00 
    bfb5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfba:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    bfc1:	00 
    bfc2:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    bfc9:	00 
    bfca:	e8 e1 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bfcf:	48 89 c7             	mov    %rax,%rdi
    bfd2:	e8 79 a9 ff ff       	call   6950 <fwp_rc_fresh>
    bfd7:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    bfde:	00 
    bfdf:	bf 01 00 00 00       	mov    $0x1,%edi
    bfe4:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    bfeb:	00 
    bfec:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    bff3:	00 
    bff4:	e8 b7 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    bff9:	48 89 c7             	mov    %rax,%rdi
    bffc:	e8 4f a9 ff ff       	call   6950 <fwp_rc_fresh>
    c001:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c008:	00 
    c009:	bf 01 00 00 00       	mov    $0x1,%edi
    c00e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c015:	00 
    c016:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c01d:	00 
    c01e:	e8 8d 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c023:	48 89 c7             	mov    %rax,%rdi
    c026:	e8 25 a9 ff ff       	call   6950 <fwp_rc_fresh>
    c02b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c032:	00 
    c033:	bf 01 00 00 00       	mov    $0x1,%edi
    c038:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c03f:	00 
    c040:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c047:	00 
    c048:	e8 63 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c04d:	48 89 c7             	mov    %rax,%rdi
    c050:	e8 fb a8 ff ff       	call   6950 <fwp_rc_fresh>
    c055:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c05c:	00 
    c05d:	bf 01 00 00 00       	mov    $0x1,%edi
    c062:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c069:	00 
    c06a:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c071:	00 
    c072:	e8 39 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c077:	48 89 c7             	mov    %rax,%rdi
    c07a:	e8 d1 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c07f:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c086:	00 
    c087:	bf 01 00 00 00       	mov    $0x1,%edi
    c08c:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c093:	00 
    c094:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c09b:	00 
    c09c:	e8 0f 9d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c0a1:	48 89 c7             	mov    %rax,%rdi
    c0a4:	e8 a7 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c0a9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c0b0:	00 
    c0b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0b6:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c0bd:	00 
    c0be:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c0c5:	00 
    c0c6:	e8 e5 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c0cb:	48 89 c7             	mov    %rax,%rdi
    c0ce:	e8 7d a8 ff ff       	call   6950 <fwp_rc_fresh>
    c0d3:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c0da:	00 
    c0db:	bf 01 00 00 00       	mov    $0x1,%edi
    c0e0:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c0e7:	00 
    c0e8:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c0ef:	00 
    c0f0:	e8 bb 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c0f5:	48 89 c7             	mov    %rax,%rdi
    c0f8:	e8 53 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c0fd:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c104:	00 
    c105:	bf 01 00 00 00       	mov    $0x1,%edi
    c10a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c111:	00 
    c112:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c119:	00 
    c11a:	e8 91 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c11f:	48 89 c7             	mov    %rax,%rdi
    c122:	e8 29 a8 ff ff       	call   6950 <fwp_rc_fresh>
    c127:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c12e:	00 
    c12f:	bf 01 00 00 00       	mov    $0x1,%edi
    c134:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c13b:	00 
    c13c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c143:	00 
    c144:	e8 67 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c149:	48 89 c7             	mov    %rax,%rdi
    c14c:	e8 ff a7 ff ff       	call   6950 <fwp_rc_fresh>
    c151:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c158:	00 
    c159:	bf 01 00 00 00       	mov    $0x1,%edi
    c15e:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c165:	00 
    c166:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c16d:	00 
    c16e:	e8 3d 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c173:	48 89 c7             	mov    %rax,%rdi
    c176:	e8 d5 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c17b:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c182:	00 
    c183:	bf 01 00 00 00       	mov    $0x1,%edi
    c188:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c18f:	00 
    c190:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c197:	00 
    c198:	e8 13 9c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c19d:	48 89 c7             	mov    %rax,%rdi
    c1a0:	e8 ab a7 ff ff       	call   6950 <fwp_rc_fresh>
    c1a5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c1ac:	00 
    c1ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c1b2:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c1b9:	00 
    c1ba:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c1c1:	00 
    c1c2:	e8 e9 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c1c7:	48 89 c7             	mov    %rax,%rdi
    c1ca:	e8 81 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c1cf:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c1d6:	00 
    c1d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1dc:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c1e3:	00 
    c1e4:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c1eb:	00 
    c1ec:	e8 bf 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c1f1:	48 89 c7             	mov    %rax,%rdi
    c1f4:	e8 57 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c1f9:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c200:	00 
    c201:	bf 01 00 00 00       	mov    $0x1,%edi
    c206:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c20d:	00 
    c20e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c215:	00 
    c216:	e8 95 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c21b:	48 89 c7             	mov    %rax,%rdi
    c21e:	e8 2d a7 ff ff       	call   6950 <fwp_rc_fresh>
    c223:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c22a:	00 
    c22b:	bf 01 00 00 00       	mov    $0x1,%edi
    c230:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c237:	00 
    c238:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c23f:	00 
    c240:	e8 6b 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c245:	48 89 c7             	mov    %rax,%rdi
    c248:	e8 03 a7 ff ff       	call   6950 <fwp_rc_fresh>
    c24d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c254:	00 
    c255:	bf 01 00 00 00       	mov    $0x1,%edi
    c25a:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c261:	00 
    c262:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c269:	00 
    c26a:	e8 41 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c26f:	48 89 c7             	mov    %rax,%rdi
    c272:	e8 d9 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c277:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c27e:	00 
    c27f:	bf 01 00 00 00       	mov    $0x1,%edi
    c284:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c28b:	00 
    c28c:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c293:	00 
    c294:	e8 17 9b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c299:	48 89 c7             	mov    %rax,%rdi
    c29c:	e8 af a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2a1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c2a8:	00 
    c2a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2ae:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c2b5:	00 
    c2b6:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c2bd:	00 
    c2be:	e8 ed 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c2c3:	48 89 c7             	mov    %rax,%rdi
    c2c6:	e8 85 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2cb:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c2d2:	00 
    c2d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2d8:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c2df:	00 
    c2e0:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c2e7:	00 
    c2e8:	e8 c3 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c2ed:	48 89 c7             	mov    %rax,%rdi
    c2f0:	e8 5b a6 ff ff       	call   6950 <fwp_rc_fresh>
    c2f5:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c2fc:	00 
    c2fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c302:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c309:	00 
    c30a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c311:	00 
    c312:	e8 99 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c317:	48 89 c7             	mov    %rax,%rdi
    c31a:	e8 31 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c31f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c326:	00 
    c327:	bf 01 00 00 00       	mov    $0x1,%edi
    c32c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c333:	00 
    c334:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c33b:	00 
    c33c:	e8 6f 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c341:	48 89 c7             	mov    %rax,%rdi
    c344:	e8 07 a6 ff ff       	call   6950 <fwp_rc_fresh>
    c349:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c350:	00 
    c351:	bf 01 00 00 00       	mov    $0x1,%edi
    c356:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c35d:	00 
    c35e:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c365:	00 
    c366:	e8 45 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c36b:	48 89 c7             	mov    %rax,%rdi
    c36e:	e8 dd a5 ff ff       	call   6950 <fwp_rc_fresh>
    c373:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c37a:	00 
    c37b:	bf 01 00 00 00       	mov    $0x1,%edi
    c380:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c387:	00 
    c388:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c38f:	00 
    c390:	e8 1b 9a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c395:	48 8b 15 fc 87 01 00 	mov    0x187fc(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c39c:	49 89 c5             	mov    %rax,%r13
    c39f:	48 2b 05 ca 87 01 00 	sub    0x187ca(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c3a6:	48 c1 e2 10          	shl    $0x10,%rdx
    c3aa:	48 39 d0             	cmp    %rdx,%rax
    c3ad:	73 59                	jae    c408 <f0+0x13b8>
    c3af:	48 89 c2             	mov    %rax,%rdx
    c3b2:	48 c1 ea 10          	shr    $0x10,%rdx
    c3b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c3ba:	48 8b 15 f7 87 01 00 	mov    0x187f7(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c3c1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c3c5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c3c9:	4d 85 e4             	test   %r12,%r12
    c3cc:	74 3a                	je     c408 <f0+0x13b8>
    c3ce:	0f b6 0a             	movzbl (%rdx),%ecx
    c3d1:	80 f9 02             	cmp    $0x2,%cl
    c3d4:	0f 84 c6 15 00 00    	je     d9a0 <f0+0x2950>
    c3da:	80 f9 01             	cmp    $0x1,%cl
    c3dd:	75 29                	jne    c408 <f0+0x13b8>
    c3df:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c3e2:	0f b7 c0             	movzwl %ax,%eax
    c3e5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c3e8:	48 0f af c1          	imul   %rcx,%rax
    c3ec:	48 c1 e8 20          	shr    $0x20,%rax
    c3f0:	48 39 d0             	cmp    %rdx,%rax
    c3f3:	73 13                	jae    c408 <f0+0x13b8>
    c3f5:	49 01 c4             	add    %rax,%r12
    c3f8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c3fd:	0f 84 99 17 00 00    	je     db9c <f0+0x2b4c>
    c403:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c408:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c40f:	33 f3 bf 
    c412:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c419:	00 
    c41a:	bf 01 00 00 00       	mov    $0x1,%edi
    c41f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c426:	00 
    c427:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c42e:	00 
    c42f:	e8 7c 99 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c434:	48 8b 15 5d 87 01 00 	mov    0x1875d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c43b:	49 89 c5             	mov    %rax,%r13
    c43e:	48 2b 05 2b 87 01 00 	sub    0x1872b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c445:	48 c1 e2 10          	shl    $0x10,%rdx
    c449:	48 39 d0             	cmp    %rdx,%rax
    c44c:	73 59                	jae    c4a7 <f0+0x1457>
    c44e:	48 89 c2             	mov    %rax,%rdx
    c451:	48 c1 ea 10          	shr    $0x10,%rdx
    c455:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c459:	48 8b 15 58 87 01 00 	mov    0x18758(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c460:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c464:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c468:	4d 85 e4             	test   %r12,%r12
    c46b:	74 3a                	je     c4a7 <f0+0x1457>
    c46d:	0f b6 0a             	movzbl (%rdx),%ecx
    c470:	80 f9 02             	cmp    $0x2,%cl
    c473:	0f 84 17 15 00 00    	je     d990 <f0+0x2940>
    c479:	80 f9 01             	cmp    $0x1,%cl
    c47c:	75 29                	jne    c4a7 <f0+0x1457>
    c47e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c481:	0f b7 c0             	movzwl %ax,%eax
    c484:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c487:	48 0f af c1          	imul   %rcx,%rax
    c48b:	48 c1 e8 20          	shr    $0x20,%rax
    c48f:	48 39 d0             	cmp    %rdx,%rax
    c492:	73 13                	jae    c4a7 <f0+0x1457>
    c494:	49 01 c4             	add    %rax,%r12
    c497:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c49c:	0f 84 07 17 00 00    	je     dba9 <f0+0x2b59>
    c4a2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c4a7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c4ae:	00 f0 3f 
    c4b1:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    c4b8:	00 
    c4b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c4be:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    c4c5:	00 
    c4c6:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    c4cd:	00 
    c4ce:	e8 dd 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c4d3:	48 8b 15 be 86 01 00 	mov    0x186be(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c4da:	49 89 c5             	mov    %rax,%r13
    c4dd:	48 2b 05 8c 86 01 00 	sub    0x1868c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c4e4:	48 c1 e2 10          	shl    $0x10,%rdx
    c4e8:	48 39 d0             	cmp    %rdx,%rax
    c4eb:	73 59                	jae    c546 <f0+0x14f6>
    c4ed:	48 89 c2             	mov    %rax,%rdx
    c4f0:	48 c1 ea 10          	shr    $0x10,%rdx
    c4f4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c4f8:	48 8b 15 b9 86 01 00 	mov    0x186b9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c4ff:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c503:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c507:	4d 85 e4             	test   %r12,%r12
    c50a:	74 3a                	je     c546 <f0+0x14f6>
    c50c:	0f b6 0a             	movzbl (%rdx),%ecx
    c50f:	80 f9 02             	cmp    $0x2,%cl
    c512:	0f 84 28 15 00 00    	je     da40 <f0+0x29f0>
    c518:	80 f9 01             	cmp    $0x1,%cl
    c51b:	75 29                	jne    c546 <f0+0x14f6>
    c51d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c520:	0f b7 c0             	movzwl %ax,%eax
    c523:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c526:	48 0f af c1          	imul   %rcx,%rax
    c52a:	48 c1 e8 20          	shr    $0x20,%rax
    c52e:	48 39 d0             	cmp    %rdx,%rax
    c531:	73 13                	jae    c546 <f0+0x14f6>
    c533:	49 01 c4             	add    %rax,%r12
    c536:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c53b:	0f 84 75 16 00 00    	je     dbb6 <f0+0x2b66>
    c541:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c546:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c54d:	33 f3 bf 
    c550:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    c557:	00 
    c558:	bf 01 00 00 00       	mov    $0x1,%edi
    c55d:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    c564:	00 
    c565:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    c56c:	00 
    c56d:	e8 3e 98 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c572:	48 8b 15 1f 86 01 00 	mov    0x1861f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c579:	49 89 c5             	mov    %rax,%r13
    c57c:	48 2b 05 ed 85 01 00 	sub    0x185ed(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c583:	48 c1 e2 10          	shl    $0x10,%rdx
    c587:	48 39 d0             	cmp    %rdx,%rax
    c58a:	73 59                	jae    c5e5 <f0+0x1595>
    c58c:	48 89 c2             	mov    %rax,%rdx
    c58f:	48 c1 ea 10          	shr    $0x10,%rdx
    c593:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c597:	48 8b 15 1a 86 01 00 	mov    0x1861a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c59e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c5a2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c5a6:	4d 85 e4             	test   %r12,%r12
    c5a9:	74 3a                	je     c5e5 <f0+0x1595>
    c5ab:	0f b6 0a             	movzbl (%rdx),%ecx
    c5ae:	80 f9 02             	cmp    $0x2,%cl
    c5b1:	0f 84 79 14 00 00    	je     da30 <f0+0x29e0>
    c5b7:	80 f9 01             	cmp    $0x1,%cl
    c5ba:	75 29                	jne    c5e5 <f0+0x1595>
    c5bc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c5bf:	0f b7 c0             	movzwl %ax,%eax
    c5c2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c5c5:	48 0f af c1          	imul   %rcx,%rax
    c5c9:	48 c1 e8 20          	shr    $0x20,%rax
    c5cd:	48 39 d0             	cmp    %rdx,%rax
    c5d0:	73 13                	jae    c5e5 <f0+0x1595>
    c5d2:	49 01 c4             	add    %rax,%r12
    c5d5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c5da:	0f 84 e3 15 00 00    	je     dbc3 <f0+0x2b73>
    c5e0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c5e5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c5ec:	00 f0 3f 
    c5ef:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    c5f6:	00 
    c5f7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5fc:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    c603:	00 
    c604:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    c60b:	00 
    c60c:	e8 9f 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c611:	48 8b 15 80 85 01 00 	mov    0x18580(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c618:	49 89 c5             	mov    %rax,%r13
    c61b:	48 2b 05 4e 85 01 00 	sub    0x1854e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c622:	48 c1 e2 10          	shl    $0x10,%rdx
    c626:	48 39 d0             	cmp    %rdx,%rax
    c629:	73 59                	jae    c684 <f0+0x1634>
    c62b:	48 89 c2             	mov    %rax,%rdx
    c62e:	48 c1 ea 10          	shr    $0x10,%rdx
    c632:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c636:	48 8b 15 7b 85 01 00 	mov    0x1857b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c63d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c641:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c645:	4d 85 e4             	test   %r12,%r12
    c648:	74 3a                	je     c684 <f0+0x1634>
    c64a:	0f b6 0a             	movzbl (%rdx),%ecx
    c64d:	80 f9 02             	cmp    $0x2,%cl
    c650:	0f 84 ca 13 00 00    	je     da20 <f0+0x29d0>
    c656:	80 f9 01             	cmp    $0x1,%cl
    c659:	75 29                	jne    c684 <f0+0x1634>
    c65b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c65e:	0f b7 c0             	movzwl %ax,%eax
    c661:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c664:	48 0f af c1          	imul   %rcx,%rax
    c668:	48 c1 e8 20          	shr    $0x20,%rax
    c66c:	48 39 d0             	cmp    %rdx,%rax
    c66f:	73 13                	jae    c684 <f0+0x1634>
    c671:	49 01 c4             	add    %rax,%r12
    c674:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c679:	0f 84 51 15 00 00    	je     dbd0 <f0+0x2b80>
    c67f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c684:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c68b:	33 f3 bf 
    c68e:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    c695:	00 
    c696:	bf 01 00 00 00       	mov    $0x1,%edi
    c69b:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    c6a2:	00 
    c6a3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    c6aa:	00 
    c6ab:	e8 00 97 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c6b0:	48 8b 15 e1 84 01 00 	mov    0x184e1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c6b7:	49 89 c5             	mov    %rax,%r13
    c6ba:	48 2b 05 af 84 01 00 	sub    0x184af(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c6c1:	48 c1 e2 10          	shl    $0x10,%rdx
    c6c5:	48 39 d0             	cmp    %rdx,%rax
    c6c8:	73 59                	jae    c723 <f0+0x16d3>
    c6ca:	48 89 c2             	mov    %rax,%rdx
    c6cd:	48 c1 ea 10          	shr    $0x10,%rdx
    c6d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c6d5:	48 8b 15 dc 84 01 00 	mov    0x184dc(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c6dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c6e0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c6e4:	4d 85 e4             	test   %r12,%r12
    c6e7:	74 3a                	je     c723 <f0+0x16d3>
    c6e9:	0f b6 0a             	movzbl (%rdx),%ecx
    c6ec:	80 f9 02             	cmp    $0x2,%cl
    c6ef:	0f 84 1b 13 00 00    	je     da10 <f0+0x29c0>
    c6f5:	80 f9 01             	cmp    $0x1,%cl
    c6f8:	75 29                	jne    c723 <f0+0x16d3>
    c6fa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c6fd:	0f b7 c0             	movzwl %ax,%eax
    c700:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c703:	48 0f af c1          	imul   %rcx,%rax
    c707:	48 c1 e8 20          	shr    $0x20,%rax
    c70b:	48 39 d0             	cmp    %rdx,%rax
    c70e:	73 13                	jae    c723 <f0+0x16d3>
    c710:	49 01 c4             	add    %rax,%r12
    c713:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c718:	0f 84 bf 14 00 00    	je     dbdd <f0+0x2b8d>
    c71e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c723:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c72a:	00 f0 3f 
    c72d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    c734:	00 
    c735:	bf 01 00 00 00       	mov    $0x1,%edi
    c73a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    c741:	00 
    c742:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    c749:	00 
    c74a:	e8 61 96 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c74f:	48 8b 15 42 84 01 00 	mov    0x18442(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c756:	49 89 c5             	mov    %rax,%r13
    c759:	48 2b 05 10 84 01 00 	sub    0x18410(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c760:	48 c1 e2 10          	shl    $0x10,%rdx
    c764:	48 39 d0             	cmp    %rdx,%rax
    c767:	73 59                	jae    c7c2 <f0+0x1772>
    c769:	48 89 c2             	mov    %rax,%rdx
    c76c:	48 c1 ea 10          	shr    $0x10,%rdx
    c770:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c774:	48 8b 15 3d 84 01 00 	mov    0x1843d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c77b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c77f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c783:	4d 85 e4             	test   %r12,%r12
    c786:	74 3a                	je     c7c2 <f0+0x1772>
    c788:	0f b6 0a             	movzbl (%rdx),%ecx
    c78b:	80 f9 02             	cmp    $0x2,%cl
    c78e:	0f 84 6c 12 00 00    	je     da00 <f0+0x29b0>
    c794:	80 f9 01             	cmp    $0x1,%cl
    c797:	75 29                	jne    c7c2 <f0+0x1772>
    c799:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c79c:	0f b7 c0             	movzwl %ax,%eax
    c79f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c7a2:	48 0f af c1          	imul   %rcx,%rax
    c7a6:	48 c1 e8 20          	shr    $0x20,%rax
    c7aa:	48 39 d0             	cmp    %rdx,%rax
    c7ad:	73 13                	jae    c7c2 <f0+0x1772>
    c7af:	49 01 c4             	add    %rax,%r12
    c7b2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c7b7:	0f 84 2d 14 00 00    	je     dbea <f0+0x2b9a>
    c7bd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c7c2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c7c9:	33 f3 bf 
    c7cc:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    c7d3:	00 
    c7d4:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d9:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    c7e0:	00 
    c7e1:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    c7e8:	00 
    c7e9:	e8 c2 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c7ee:	48 8b 15 a3 83 01 00 	mov    0x183a3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c7f5:	49 89 c5             	mov    %rax,%r13
    c7f8:	48 2b 05 71 83 01 00 	sub    0x18371(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c7ff:	48 c1 e2 10          	shl    $0x10,%rdx
    c803:	48 39 d0             	cmp    %rdx,%rax
    c806:	73 59                	jae    c861 <f0+0x1811>
    c808:	48 89 c2             	mov    %rax,%rdx
    c80b:	48 c1 ea 10          	shr    $0x10,%rdx
    c80f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c813:	48 8b 15 9e 83 01 00 	mov    0x1839e(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c81a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c81e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c822:	4d 85 e4             	test   %r12,%r12
    c825:	74 3a                	je     c861 <f0+0x1811>
    c827:	0f b6 0a             	movzbl (%rdx),%ecx
    c82a:	80 f9 02             	cmp    $0x2,%cl
    c82d:	0f 84 bd 11 00 00    	je     d9f0 <f0+0x29a0>
    c833:	80 f9 01             	cmp    $0x1,%cl
    c836:	75 29                	jne    c861 <f0+0x1811>
    c838:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c83b:	0f b7 c0             	movzwl %ax,%eax
    c83e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c841:	48 0f af c1          	imul   %rcx,%rax
    c845:	48 c1 e8 20          	shr    $0x20,%rax
    c849:	48 39 d0             	cmp    %rdx,%rax
    c84c:	73 13                	jae    c861 <f0+0x1811>
    c84e:	49 01 c4             	add    %rax,%r12
    c851:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c856:	0f 84 9b 13 00 00    	je     dbf7 <f0+0x2ba7>
    c85c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c861:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c868:	00 f0 3f 
    c86b:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    c872:	00 
    c873:	bf 01 00 00 00       	mov    $0x1,%edi
    c878:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    c87f:	00 
    c880:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    c887:	00 
    c888:	e8 23 95 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c88d:	48 8b 15 04 83 01 00 	mov    0x18304(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c894:	49 89 c5             	mov    %rax,%r13
    c897:	48 2b 05 d2 82 01 00 	sub    0x182d2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c89e:	48 c1 e2 10          	shl    $0x10,%rdx
    c8a2:	48 39 d0             	cmp    %rdx,%rax
    c8a5:	73 59                	jae    c900 <f0+0x18b0>
    c8a7:	48 89 c2             	mov    %rax,%rdx
    c8aa:	48 c1 ea 10          	shr    $0x10,%rdx
    c8ae:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c8b2:	48 8b 15 ff 82 01 00 	mov    0x182ff(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c8b9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c8bd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c8c1:	4d 85 e4             	test   %r12,%r12
    c8c4:	74 3a                	je     c900 <f0+0x18b0>
    c8c6:	0f b6 0a             	movzbl (%rdx),%ecx
    c8c9:	80 f9 02             	cmp    $0x2,%cl
    c8cc:	0f 84 0e 11 00 00    	je     d9e0 <f0+0x2990>
    c8d2:	80 f9 01             	cmp    $0x1,%cl
    c8d5:	75 29                	jne    c900 <f0+0x18b0>
    c8d7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c8da:	0f b7 c0             	movzwl %ax,%eax
    c8dd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c8e0:	48 0f af c1          	imul   %rcx,%rax
    c8e4:	48 c1 e8 20          	shr    $0x20,%rax
    c8e8:	48 39 d0             	cmp    %rdx,%rax
    c8eb:	73 13                	jae    c900 <f0+0x18b0>
    c8ed:	49 01 c4             	add    %rax,%r12
    c8f0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c8f5:	0f 84 09 13 00 00    	je     dc04 <f0+0x2bb4>
    c8fb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c900:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c907:	33 f3 bf 
    c90a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    c911:	00 
    c912:	bf 01 00 00 00       	mov    $0x1,%edi
    c917:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    c91e:	00 
    c91f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    c926:	00 
    c927:	e8 84 94 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c92c:	48 8b 15 65 82 01 00 	mov    0x18265(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c933:	49 89 c5             	mov    %rax,%r13
    c936:	48 2b 05 33 82 01 00 	sub    0x18233(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c93d:	48 c1 e2 10          	shl    $0x10,%rdx
    c941:	48 39 d0             	cmp    %rdx,%rax
    c944:	73 59                	jae    c99f <f0+0x194f>
    c946:	48 89 c2             	mov    %rax,%rdx
    c949:	48 c1 ea 10          	shr    $0x10,%rdx
    c94d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c951:	48 8b 15 60 82 01 00 	mov    0x18260(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c958:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c95c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c960:	4d 85 e4             	test   %r12,%r12
    c963:	74 3a                	je     c99f <f0+0x194f>
    c965:	0f b6 0a             	movzbl (%rdx),%ecx
    c968:	80 f9 02             	cmp    $0x2,%cl
    c96b:	0f 84 5f 10 00 00    	je     d9d0 <f0+0x2980>
    c971:	80 f9 01             	cmp    $0x1,%cl
    c974:	75 29                	jne    c99f <f0+0x194f>
    c976:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c979:	0f b7 c0             	movzwl %ax,%eax
    c97c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c97f:	48 0f af c1          	imul   %rcx,%rax
    c983:	48 c1 e8 20          	shr    $0x20,%rax
    c987:	48 39 d0             	cmp    %rdx,%rax
    c98a:	73 13                	jae    c99f <f0+0x194f>
    c98c:	49 01 c4             	add    %rax,%r12
    c98f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c994:	0f 84 77 12 00 00    	je     dc11 <f0+0x2bc1>
    c99a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c99f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9a6:	00 f0 3f 
    c9a9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    c9b0:	00 
    c9b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c9b6:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    c9bd:	00 
    c9be:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    c9c5:	00 
    c9c6:	e8 e5 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    c9cb:	48 8b 15 c6 81 01 00 	mov    0x181c6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    c9d2:	49 89 c5             	mov    %rax,%r13
    c9d5:	48 2b 05 94 81 01 00 	sub    0x18194(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    c9dc:	48 c1 e2 10          	shl    $0x10,%rdx
    c9e0:	48 39 d0             	cmp    %rdx,%rax
    c9e3:	73 59                	jae    ca3e <f0+0x19ee>
    c9e5:	48 89 c2             	mov    %rax,%rdx
    c9e8:	48 c1 ea 10          	shr    $0x10,%rdx
    c9ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9f0:	48 8b 15 c1 81 01 00 	mov    0x181c1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    c9f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9fb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9ff:	4d 85 e4             	test   %r12,%r12
    ca02:	74 3a                	je     ca3e <f0+0x19ee>
    ca04:	0f b6 0a             	movzbl (%rdx),%ecx
    ca07:	80 f9 02             	cmp    $0x2,%cl
    ca0a:	0f 84 40 0f 00 00    	je     d950 <f0+0x2900>
    ca10:	80 f9 01             	cmp    $0x1,%cl
    ca13:	75 29                	jne    ca3e <f0+0x19ee>
    ca15:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca18:	0f b7 c0             	movzwl %ax,%eax
    ca1b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca1e:	48 0f af c1          	imul   %rcx,%rax
    ca22:	48 c1 e8 20          	shr    $0x20,%rax
    ca26:	48 39 d0             	cmp    %rdx,%rax
    ca29:	73 13                	jae    ca3e <f0+0x19ee>
    ca2b:	49 01 c4             	add    %rax,%r12
    ca2e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca33:	0f 84 e5 11 00 00    	je     dc1e <f0+0x2bce>
    ca39:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca3e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca45:	33 f3 bf 
    ca48:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    ca4f:	00 
    ca50:	bf 01 00 00 00       	mov    $0x1,%edi
    ca55:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    ca5c:	00 
    ca5d:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    ca64:	00 
    ca65:	e8 46 93 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ca6a:	48 8b 15 27 81 01 00 	mov    0x18127(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ca71:	49 89 c5             	mov    %rax,%r13
    ca74:	48 2b 05 f5 80 01 00 	sub    0x180f5(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ca7b:	48 c1 e2 10          	shl    $0x10,%rdx
    ca7f:	48 39 d0             	cmp    %rdx,%rax
    ca82:	73 59                	jae    cadd <f0+0x1a8d>
    ca84:	48 89 c2             	mov    %rax,%rdx
    ca87:	48 c1 ea 10          	shr    $0x10,%rdx
    ca8b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca8f:	48 8b 15 22 81 01 00 	mov    0x18122(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ca96:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca9a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca9e:	4d 85 e4             	test   %r12,%r12
    caa1:	74 3a                	je     cadd <f0+0x1a8d>
    caa3:	0f b6 0a             	movzbl (%rdx),%ecx
    caa6:	80 f9 02             	cmp    $0x2,%cl
    caa9:	0f 84 91 0e 00 00    	je     d940 <f0+0x28f0>
    caaf:	80 f9 01             	cmp    $0x1,%cl
    cab2:	75 29                	jne    cadd <f0+0x1a8d>
    cab4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cab7:	0f b7 c0             	movzwl %ax,%eax
    caba:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cabd:	48 0f af c1          	imul   %rcx,%rax
    cac1:	48 c1 e8 20          	shr    $0x20,%rax
    cac5:	48 39 d0             	cmp    %rdx,%rax
    cac8:	73 13                	jae    cadd <f0+0x1a8d>
    caca:	49 01 c4             	add    %rax,%r12
    cacd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cad2:	0f 84 53 11 00 00    	je     dc2b <f0+0x2bdb>
    cad8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cadd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cae4:	00 f0 3f 
    cae7:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    caee:	00 
    caef:	bf 01 00 00 00       	mov    $0x1,%edi
    caf4:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    cafb:	00 
    cafc:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    cb03:	00 
    cb04:	e8 a7 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cb09:	48 8b 15 88 80 01 00 	mov    0x18088(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cb10:	49 89 c5             	mov    %rax,%r13
    cb13:	48 2b 05 56 80 01 00 	sub    0x18056(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cb1a:	48 c1 e2 10          	shl    $0x10,%rdx
    cb1e:	48 39 d0             	cmp    %rdx,%rax
    cb21:	73 59                	jae    cb7c <f0+0x1b2c>
    cb23:	48 89 c2             	mov    %rax,%rdx
    cb26:	48 c1 ea 10          	shr    $0x10,%rdx
    cb2a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb2e:	48 8b 15 83 80 01 00 	mov    0x18083(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cb35:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb39:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb3d:	4d 85 e4             	test   %r12,%r12
    cb40:	74 3a                	je     cb7c <f0+0x1b2c>
    cb42:	0f b6 0a             	movzbl (%rdx),%ecx
    cb45:	80 f9 02             	cmp    $0x2,%cl
    cb48:	0f 84 e2 0d 00 00    	je     d930 <f0+0x28e0>
    cb4e:	80 f9 01             	cmp    $0x1,%cl
    cb51:	75 29                	jne    cb7c <f0+0x1b2c>
    cb53:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb56:	0f b7 c0             	movzwl %ax,%eax
    cb59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb5c:	48 0f af c1          	imul   %rcx,%rax
    cb60:	48 c1 e8 20          	shr    $0x20,%rax
    cb64:	48 39 d0             	cmp    %rdx,%rax
    cb67:	73 13                	jae    cb7c <f0+0x1b2c>
    cb69:	49 01 c4             	add    %rax,%r12
    cb6c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb71:	0f 84 c1 10 00 00    	je     dc38 <f0+0x2be8>
    cb77:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb7c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cb83:	33 f3 bf 
    cb86:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    cb8d:	00 
    cb8e:	bf 01 00 00 00       	mov    $0x1,%edi
    cb93:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    cb9a:	00 
    cb9b:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    cba2:	00 
    cba3:	e8 08 92 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cba8:	48 8b 15 e9 7f 01 00 	mov    0x17fe9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cbaf:	49 89 c5             	mov    %rax,%r13
    cbb2:	48 2b 05 b7 7f 01 00 	sub    0x17fb7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cbb9:	48 c1 e2 10          	shl    $0x10,%rdx
    cbbd:	48 39 d0             	cmp    %rdx,%rax
    cbc0:	73 59                	jae    cc1b <f0+0x1bcb>
    cbc2:	48 89 c2             	mov    %rax,%rdx
    cbc5:	48 c1 ea 10          	shr    $0x10,%rdx
    cbc9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cbcd:	48 8b 15 e4 7f 01 00 	mov    0x17fe4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cbd4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cbd8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cbdc:	4d 85 e4             	test   %r12,%r12
    cbdf:	74 3a                	je     cc1b <f0+0x1bcb>
    cbe1:	0f b6 0a             	movzbl (%rdx),%ecx
    cbe4:	80 f9 02             	cmp    $0x2,%cl
    cbe7:	0f 84 33 0d 00 00    	je     d920 <f0+0x28d0>
    cbed:	80 f9 01             	cmp    $0x1,%cl
    cbf0:	75 29                	jne    cc1b <f0+0x1bcb>
    cbf2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbf5:	0f b7 c0             	movzwl %ax,%eax
    cbf8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbfb:	48 0f af c1          	imul   %rcx,%rax
    cbff:	48 c1 e8 20          	shr    $0x20,%rax
    cc03:	48 39 d0             	cmp    %rdx,%rax
    cc06:	73 13                	jae    cc1b <f0+0x1bcb>
    cc08:	49 01 c4             	add    %rax,%r12
    cc0b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc10:	0f 84 2f 10 00 00    	je     dc45 <f0+0x2bf5>
    cc16:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc1b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc22:	00 f0 3f 
    cc25:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    cc2c:	00 
    cc2d:	bf 01 00 00 00       	mov    $0x1,%edi
    cc32:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    cc39:	00 
    cc3a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    cc41:	00 
    cc42:	e8 69 91 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cc47:	48 8b 15 4a 7f 01 00 	mov    0x17f4a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cc4e:	49 89 c5             	mov    %rax,%r13
    cc51:	48 2b 05 18 7f 01 00 	sub    0x17f18(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cc58:	48 c1 e2 10          	shl    $0x10,%rdx
    cc5c:	48 39 d0             	cmp    %rdx,%rax
    cc5f:	73 59                	jae    ccba <f0+0x1c6a>
    cc61:	48 89 c2             	mov    %rax,%rdx
    cc64:	48 c1 ea 10          	shr    $0x10,%rdx
    cc68:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc6c:	48 8b 15 45 7f 01 00 	mov    0x17f45(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cc73:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc77:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc7b:	4d 85 e4             	test   %r12,%r12
    cc7e:	74 3a                	je     ccba <f0+0x1c6a>
    cc80:	0f b6 0a             	movzbl (%rdx),%ecx
    cc83:	80 f9 02             	cmp    $0x2,%cl
    cc86:	0f 84 84 0c 00 00    	je     d910 <f0+0x28c0>
    cc8c:	80 f9 01             	cmp    $0x1,%cl
    cc8f:	75 29                	jne    ccba <f0+0x1c6a>
    cc91:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc94:	0f b7 c0             	movzwl %ax,%eax
    cc97:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc9a:	48 0f af c1          	imul   %rcx,%rax
    cc9e:	48 c1 e8 20          	shr    $0x20,%rax
    cca2:	48 39 d0             	cmp    %rdx,%rax
    cca5:	73 13                	jae    ccba <f0+0x1c6a>
    cca7:	49 01 c4             	add    %rax,%r12
    ccaa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ccaf:	0f 84 9d 0f 00 00    	je     dc52 <f0+0x2c02>
    ccb5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ccba:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ccc1:	33 f3 bf 
    ccc4:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    cccb:	00 
    cccc:	bf 01 00 00 00       	mov    $0x1,%edi
    ccd1:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    ccd8:	00 
    ccd9:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    cce0:	00 
    cce1:	e8 ca 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cce6:	48 8b 15 ab 7e 01 00 	mov    0x17eab(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cced:	49 89 c5             	mov    %rax,%r13
    ccf0:	48 2b 05 79 7e 01 00 	sub    0x17e79(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ccf7:	48 c1 e2 10          	shl    $0x10,%rdx
    ccfb:	48 39 d0             	cmp    %rdx,%rax
    ccfe:	73 59                	jae    cd59 <f0+0x1d09>
    cd00:	48 89 c2             	mov    %rax,%rdx
    cd03:	48 c1 ea 10          	shr    $0x10,%rdx
    cd07:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd0b:	48 8b 15 a6 7e 01 00 	mov    0x17ea6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cd12:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd16:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd1a:	4d 85 e4             	test   %r12,%r12
    cd1d:	74 3a                	je     cd59 <f0+0x1d09>
    cd1f:	0f b6 0a             	movzbl (%rdx),%ecx
    cd22:	80 f9 02             	cmp    $0x2,%cl
    cd25:	0f 84 d5 0b 00 00    	je     d900 <f0+0x28b0>
    cd2b:	80 f9 01             	cmp    $0x1,%cl
    cd2e:	75 29                	jne    cd59 <f0+0x1d09>
    cd30:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd33:	0f b7 c0             	movzwl %ax,%eax
    cd36:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd39:	48 0f af c1          	imul   %rcx,%rax
    cd3d:	48 c1 e8 20          	shr    $0x20,%rax
    cd41:	48 39 d0             	cmp    %rdx,%rax
    cd44:	73 13                	jae    cd59 <f0+0x1d09>
    cd46:	49 01 c4             	add    %rax,%r12
    cd49:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd4e:	0f 84 0b 0f 00 00    	je     dc5f <f0+0x2c0f>
    cd54:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd59:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cd60:	00 f0 3f 
    cd63:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    cd6a:	00 
    cd6b:	bf 01 00 00 00       	mov    $0x1,%edi
    cd70:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    cd77:	00 
    cd78:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    cd7f:	00 
    cd80:	e8 2b 90 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cd85:	48 8b 15 0c 7e 01 00 	mov    0x17e0c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cd8c:	49 89 c5             	mov    %rax,%r13
    cd8f:	48 2b 05 da 7d 01 00 	sub    0x17dda(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cd96:	48 c1 e2 10          	shl    $0x10,%rdx
    cd9a:	48 39 d0             	cmp    %rdx,%rax
    cd9d:	73 59                	jae    cdf8 <f0+0x1da8>
    cd9f:	48 89 c2             	mov    %rax,%rdx
    cda2:	48 c1 ea 10          	shr    $0x10,%rdx
    cda6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cdaa:	48 8b 15 07 7e 01 00 	mov    0x17e07(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cdb1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cdb5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cdb9:	4d 85 e4             	test   %r12,%r12
    cdbc:	74 3a                	je     cdf8 <f0+0x1da8>
    cdbe:	0f b6 0a             	movzbl (%rdx),%ecx
    cdc1:	80 f9 02             	cmp    $0x2,%cl
    cdc4:	0f 84 26 0b 00 00    	je     d8f0 <f0+0x28a0>
    cdca:	80 f9 01             	cmp    $0x1,%cl
    cdcd:	75 29                	jne    cdf8 <f0+0x1da8>
    cdcf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cdd2:	0f b7 c0             	movzwl %ax,%eax
    cdd5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cdd8:	48 0f af c1          	imul   %rcx,%rax
    cddc:	48 c1 e8 20          	shr    $0x20,%rax
    cde0:	48 39 d0             	cmp    %rdx,%rax
    cde3:	73 13                	jae    cdf8 <f0+0x1da8>
    cde5:	49 01 c4             	add    %rax,%r12
    cde8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cded:	0f 84 79 0e 00 00    	je     dc6c <f0+0x2c1c>
    cdf3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdf8:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cdff:	33 f3 bf 
    ce02:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    ce09:	00 
    ce0a:	bf 01 00 00 00       	mov    $0x1,%edi
    ce0f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    ce16:	00 
    ce17:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    ce1e:	00 
    ce1f:	e8 8c 8f ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    ce24:	48 8b 15 6d 7d 01 00 	mov    0x17d6d(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ce2b:	49 89 c5             	mov    %rax,%r13
    ce2e:	48 2b 05 3b 7d 01 00 	sub    0x17d3b(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ce35:	48 c1 e2 10          	shl    $0x10,%rdx
    ce39:	48 39 d0             	cmp    %rdx,%rax
    ce3c:	73 59                	jae    ce97 <f0+0x1e47>
    ce3e:	48 89 c2             	mov    %rax,%rdx
    ce41:	48 c1 ea 10          	shr    $0x10,%rdx
    ce45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce49:	48 8b 15 68 7d 01 00 	mov    0x17d68(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ce50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce54:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce58:	4d 85 e4             	test   %r12,%r12
    ce5b:	74 3a                	je     ce97 <f0+0x1e47>
    ce5d:	0f b6 0a             	movzbl (%rdx),%ecx
    ce60:	80 f9 02             	cmp    $0x2,%cl
    ce63:	0f 84 77 0a 00 00    	je     d8e0 <f0+0x2890>
    ce69:	80 f9 01             	cmp    $0x1,%cl
    ce6c:	75 29                	jne    ce97 <f0+0x1e47>
    ce6e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce71:	0f b7 c0             	movzwl %ax,%eax
    ce74:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce77:	48 0f af c1          	imul   %rcx,%rax
    ce7b:	48 c1 e8 20          	shr    $0x20,%rax
    ce7f:	48 39 d0             	cmp    %rdx,%rax
    ce82:	73 13                	jae    ce97 <f0+0x1e47>
    ce84:	49 01 c4             	add    %rax,%r12
    ce87:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce8c:	0f 84 e7 0d 00 00    	je     dc79 <f0+0x2c29>
    ce92:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce97:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    ce9e:	00 f0 3f 
    cea1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    cea8:	00 
    cea9:	bf 01 00 00 00       	mov    $0x1,%edi
    ceae:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    ceb5:	00 
    ceb6:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    cebd:	00 
    cebe:	e8 ed 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cec3:	48 8b 15 ce 7c 01 00 	mov    0x17cce(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    ceca:	49 89 c5             	mov    %rax,%r13
    cecd:	48 2b 05 9c 7c 01 00 	sub    0x17c9c(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    ced4:	48 c1 e2 10          	shl    $0x10,%rdx
    ced8:	48 39 d0             	cmp    %rdx,%rax
    cedb:	73 59                	jae    cf36 <f0+0x1ee6>
    cedd:	48 89 c2             	mov    %rax,%rdx
    cee0:	48 c1 ea 10          	shr    $0x10,%rdx
    cee4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cee8:	48 8b 15 c9 7c 01 00 	mov    0x17cc9(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    ceef:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cef3:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cef7:	4d 85 e4             	test   %r12,%r12
    cefa:	74 3a                	je     cf36 <f0+0x1ee6>
    cefc:	0f b6 0a             	movzbl (%rdx),%ecx
    ceff:	80 f9 02             	cmp    $0x2,%cl
    cf02:	0f 84 38 0c 00 00    	je     db40 <f0+0x2af0>
    cf08:	80 f9 01             	cmp    $0x1,%cl
    cf0b:	75 29                	jne    cf36 <f0+0x1ee6>
    cf0d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf10:	0f b7 c0             	movzwl %ax,%eax
    cf13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf16:	48 0f af c1          	imul   %rcx,%rax
    cf1a:	48 c1 e8 20          	shr    $0x20,%rax
    cf1e:	48 39 d0             	cmp    %rdx,%rax
    cf21:	73 13                	jae    cf36 <f0+0x1ee6>
    cf23:	49 01 c4             	add    %rax,%r12
    cf26:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf2b:	0f 84 55 0d 00 00    	je     dc86 <f0+0x2c36>
    cf31:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf36:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf3d:	33 f3 bf 
    cf40:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    cf47:	00 
    cf48:	bf 01 00 00 00       	mov    $0x1,%edi
    cf4d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    cf54:	00 
    cf55:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    cf5c:	00 
    cf5d:	e8 4e 8e ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    cf62:	48 8b 15 2f 7c 01 00 	mov    0x17c2f(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    cf69:	49 89 c5             	mov    %rax,%r13
    cf6c:	48 2b 05 fd 7b 01 00 	sub    0x17bfd(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    cf73:	48 c1 e2 10          	shl    $0x10,%rdx
    cf77:	48 39 d0             	cmp    %rdx,%rax
    cf7a:	73 59                	jae    cfd5 <f0+0x1f85>
    cf7c:	48 89 c2             	mov    %rax,%rdx
    cf7f:	48 c1 ea 10          	shr    $0x10,%rdx
    cf83:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf87:	48 8b 15 2a 7c 01 00 	mov    0x17c2a(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    cf8e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf92:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf96:	4d 85 e4             	test   %r12,%r12
    cf99:	74 3a                	je     cfd5 <f0+0x1f85>
    cf9b:	0f b6 0a             	movzbl (%rdx),%ecx
    cf9e:	80 f9 02             	cmp    $0x2,%cl
    cfa1:	0f 84 89 0b 00 00    	je     db30 <f0+0x2ae0>
    cfa7:	80 f9 01             	cmp    $0x1,%cl
    cfaa:	75 29                	jne    cfd5 <f0+0x1f85>
    cfac:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cfaf:	0f b7 c0             	movzwl %ax,%eax
    cfb2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cfb5:	48 0f af c1          	imul   %rcx,%rax
    cfb9:	48 c1 e8 20          	shr    $0x20,%rax
    cfbd:	48 39 d0             	cmp    %rdx,%rax
    cfc0:	73 13                	jae    cfd5 <f0+0x1f85>
    cfc2:	49 01 c4             	add    %rax,%r12
    cfc5:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cfca:	0f 84 c3 0c 00 00    	je     dc93 <f0+0x2c43>
    cfd0:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cfd5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cfdc:	00 f0 3f 
    cfdf:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    cfe6:	00 
    cfe7:	bf 01 00 00 00       	mov    $0x1,%edi
    cfec:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    cff3:	00 
    cff4:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    cffb:	00 
    cffc:	e8 af 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d001:	48 8b 15 90 7b 01 00 	mov    0x17b90(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d008:	49 89 c5             	mov    %rax,%r13
    d00b:	48 2b 05 5e 7b 01 00 	sub    0x17b5e(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d012:	48 c1 e2 10          	shl    $0x10,%rdx
    d016:	48 39 d0             	cmp    %rdx,%rax
    d019:	73 59                	jae    d074 <f0+0x2024>
    d01b:	48 89 c2             	mov    %rax,%rdx
    d01e:	48 c1 ea 10          	shr    $0x10,%rdx
    d022:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d026:	48 8b 15 8b 7b 01 00 	mov    0x17b8b(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d02d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d031:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d035:	4d 85 e4             	test   %r12,%r12
    d038:	74 3a                	je     d074 <f0+0x2024>
    d03a:	0f b6 0a             	movzbl (%rdx),%ecx
    d03d:	80 f9 02             	cmp    $0x2,%cl
    d040:	0f 84 da 0a 00 00    	je     db20 <f0+0x2ad0>
    d046:	80 f9 01             	cmp    $0x1,%cl
    d049:	75 29                	jne    d074 <f0+0x2024>
    d04b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d04e:	0f b7 c0             	movzwl %ax,%eax
    d051:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d054:	48 0f af c1          	imul   %rcx,%rax
    d058:	48 c1 e8 20          	shr    $0x20,%rax
    d05c:	48 39 d0             	cmp    %rdx,%rax
    d05f:	73 13                	jae    d074 <f0+0x2024>
    d061:	49 01 c4             	add    %rax,%r12
    d064:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d069:	0f 84 31 0c 00 00    	je     dca0 <f0+0x2c50>
    d06f:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d074:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d07b:	33 f3 bf 
    d07e:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d085:	00 
    d086:	bf 01 00 00 00       	mov    $0x1,%edi
    d08b:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d092:	00 
    d093:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d09a:	00 
    d09b:	e8 10 8d ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d0a0:	48 8b 15 f1 7a 01 00 	mov    0x17af1(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d0a7:	49 89 c5             	mov    %rax,%r13
    d0aa:	48 2b 05 bf 7a 01 00 	sub    0x17abf(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d0b1:	48 c1 e2 10          	shl    $0x10,%rdx
    d0b5:	48 39 d0             	cmp    %rdx,%rax
    d0b8:	73 59                	jae    d113 <f0+0x20c3>
    d0ba:	48 89 c2             	mov    %rax,%rdx
    d0bd:	48 c1 ea 10          	shr    $0x10,%rdx
    d0c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d0c5:	48 8b 15 ec 7a 01 00 	mov    0x17aec(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d0cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d0d0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d0d4:	4d 85 e4             	test   %r12,%r12
    d0d7:	74 3a                	je     d113 <f0+0x20c3>
    d0d9:	0f b6 0a             	movzbl (%rdx),%ecx
    d0dc:	80 f9 02             	cmp    $0x2,%cl
    d0df:	0f 84 2b 0a 00 00    	je     db10 <f0+0x2ac0>
    d0e5:	80 f9 01             	cmp    $0x1,%cl
    d0e8:	75 29                	jne    d113 <f0+0x20c3>
    d0ea:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0ed:	0f b7 c0             	movzwl %ax,%eax
    d0f0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0f3:	48 0f af c1          	imul   %rcx,%rax
    d0f7:	48 c1 e8 20          	shr    $0x20,%rax
    d0fb:	48 39 d0             	cmp    %rdx,%rax
    d0fe:	73 13                	jae    d113 <f0+0x20c3>
    d100:	49 01 c4             	add    %rax,%r12
    d103:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d108:	0f 84 9f 0b 00 00    	je     dcad <f0+0x2c5d>
    d10e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d113:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d11a:	00 f0 3f 
    d11d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d124:	00 
    d125:	bf 01 00 00 00       	mov    $0x1,%edi
    d12a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d131:	00 
    d132:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d139:	00 
    d13a:	e8 71 8c ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d13f:	48 8b 15 52 7a 01 00 	mov    0x17a52(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d146:	49 89 c5             	mov    %rax,%r13
    d149:	48 2b 05 20 7a 01 00 	sub    0x17a20(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d150:	48 c1 e2 10          	shl    $0x10,%rdx
    d154:	48 39 d0             	cmp    %rdx,%rax
    d157:	73 59                	jae    d1b2 <f0+0x2162>
    d159:	48 89 c2             	mov    %rax,%rdx
    d15c:	48 c1 ea 10          	shr    $0x10,%rdx
    d160:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d164:	48 8b 15 4d 7a 01 00 	mov    0x17a4d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d16b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d16f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d173:	4d 85 e4             	test   %r12,%r12
    d176:	74 3a                	je     d1b2 <f0+0x2162>
    d178:	0f b6 0a             	movzbl (%rdx),%ecx
    d17b:	80 f9 02             	cmp    $0x2,%cl
    d17e:	0f 84 7c 09 00 00    	je     db00 <f0+0x2ab0>
    d184:	80 f9 01             	cmp    $0x1,%cl
    d187:	75 29                	jne    d1b2 <f0+0x2162>
    d189:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d18c:	0f b7 c0             	movzwl %ax,%eax
    d18f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d192:	48 0f af c1          	imul   %rcx,%rax
    d196:	48 c1 e8 20          	shr    $0x20,%rax
    d19a:	48 39 d0             	cmp    %rdx,%rax
    d19d:	73 13                	jae    d1b2 <f0+0x2162>
    d19f:	49 01 c4             	add    %rax,%r12
    d1a2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1a7:	0f 84 0d 0b 00 00    	je     dcba <f0+0x2c6a>
    d1ad:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d1b2:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d1b9:	33 f3 bf 
    d1bc:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d1c3:	00 
    d1c4:	bf 01 00 00 00       	mov    $0x1,%edi
    d1c9:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d1d0:	00 
    d1d1:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d1d8:	00 
    d1d9:	e8 d2 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d1de:	48 8b 15 b3 79 01 00 	mov    0x179b3(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d1e5:	49 89 c5             	mov    %rax,%r13
    d1e8:	48 2b 05 81 79 01 00 	sub    0x17981(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d1ef:	48 c1 e2 10          	shl    $0x10,%rdx
    d1f3:	48 39 d0             	cmp    %rdx,%rax
    d1f6:	73 59                	jae    d251 <f0+0x2201>
    d1f8:	48 89 c2             	mov    %rax,%rdx
    d1fb:	48 c1 ea 10          	shr    $0x10,%rdx
    d1ff:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d203:	48 8b 15 ae 79 01 00 	mov    0x179ae(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d20a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d20e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d212:	4d 85 e4             	test   %r12,%r12
    d215:	74 3a                	je     d251 <f0+0x2201>
    d217:	0f b6 0a             	movzbl (%rdx),%ecx
    d21a:	80 f9 02             	cmp    $0x2,%cl
    d21d:	0f 84 cd 08 00 00    	je     daf0 <f0+0x2aa0>
    d223:	80 f9 01             	cmp    $0x1,%cl
    d226:	75 29                	jne    d251 <f0+0x2201>
    d228:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d22b:	0f b7 c0             	movzwl %ax,%eax
    d22e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d231:	48 0f af c1          	imul   %rcx,%rax
    d235:	48 c1 e8 20          	shr    $0x20,%rax
    d239:	48 39 d0             	cmp    %rdx,%rax
    d23c:	73 13                	jae    d251 <f0+0x2201>
    d23e:	49 01 c4             	add    %rax,%r12
    d241:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d246:	0f 84 7b 0a 00 00    	je     dcc7 <f0+0x2c77>
    d24c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d251:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d258:	00 f0 3f 
    d25b:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d262:	00 
    d263:	bf 01 00 00 00       	mov    $0x1,%edi
    d268:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d26f:	00 
    d270:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d277:	00 
    d278:	e8 33 8b ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d27d:	48 8b 15 14 79 01 00 	mov    0x17914(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d284:	49 89 c5             	mov    %rax,%r13
    d287:	48 2b 05 e2 78 01 00 	sub    0x178e2(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d28e:	48 c1 e2 10          	shl    $0x10,%rdx
    d292:	48 39 d0             	cmp    %rdx,%rax
    d295:	73 59                	jae    d2f0 <f0+0x22a0>
    d297:	48 89 c2             	mov    %rax,%rdx
    d29a:	48 c1 ea 10          	shr    $0x10,%rdx
    d29e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2a2:	48 8b 15 0f 79 01 00 	mov    0x1790f(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d2a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d2ad:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d2b1:	4d 85 e4             	test   %r12,%r12
    d2b4:	74 3a                	je     d2f0 <f0+0x22a0>
    d2b6:	0f b6 0a             	movzbl (%rdx),%ecx
    d2b9:	80 f9 02             	cmp    $0x2,%cl
    d2bc:	0f 84 1e 08 00 00    	je     dae0 <f0+0x2a90>
    d2c2:	80 f9 01             	cmp    $0x1,%cl
    d2c5:	75 29                	jne    d2f0 <f0+0x22a0>
    d2c7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d2ca:	0f b7 c0             	movzwl %ax,%eax
    d2cd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d2d0:	48 0f af c1          	imul   %rcx,%rax
    d2d4:	48 c1 e8 20          	shr    $0x20,%rax
    d2d8:	48 39 d0             	cmp    %rdx,%rax
    d2db:	73 13                	jae    d2f0 <f0+0x22a0>
    d2dd:	49 01 c4             	add    %rax,%r12
    d2e0:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d2e5:	0f 84 e9 09 00 00    	je     dcd4 <f0+0x2c84>
    d2eb:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d2f7:	33 f3 bf 
    d2fa:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d301:	00 
    d302:	bf 01 00 00 00       	mov    $0x1,%edi
    d307:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d30e:	00 
    d30f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d316:	00 
    d317:	e8 94 8a ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d31c:	48 8b 15 75 78 01 00 	mov    0x17875(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d323:	49 89 c5             	mov    %rax,%r13
    d326:	48 2b 05 43 78 01 00 	sub    0x17843(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d32d:	48 c1 e2 10          	shl    $0x10,%rdx
    d331:	48 39 d0             	cmp    %rdx,%rax
    d334:	73 59                	jae    d38f <f0+0x233f>
    d336:	48 89 c2             	mov    %rax,%rdx
    d339:	48 c1 ea 10          	shr    $0x10,%rdx
    d33d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d341:	48 8b 15 70 78 01 00 	mov    0x17870(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d348:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d34c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d350:	4d 85 e4             	test   %r12,%r12
    d353:	74 3a                	je     d38f <f0+0x233f>
    d355:	0f b6 0a             	movzbl (%rdx),%ecx
    d358:	80 f9 02             	cmp    $0x2,%cl
    d35b:	0f 84 6f 07 00 00    	je     dad0 <f0+0x2a80>
    d361:	80 f9 01             	cmp    $0x1,%cl
    d364:	75 29                	jne    d38f <f0+0x233f>
    d366:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d369:	0f b7 c0             	movzwl %ax,%eax
    d36c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d36f:	48 0f af c1          	imul   %rcx,%rax
    d373:	48 c1 e8 20          	shr    $0x20,%rax
    d377:	48 39 d0             	cmp    %rdx,%rax
    d37a:	73 13                	jae    d38f <f0+0x233f>
    d37c:	49 01 c4             	add    %rax,%r12
    d37f:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d384:	0f 84 57 09 00 00    	je     dce1 <f0+0x2c91>
    d38a:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d38f:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d396:	00 f0 3f 
    d399:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d3a0:	00 
    d3a1:	bf 01 00 00 00       	mov    $0x1,%edi
    d3a6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d3ad:	00 
    d3ae:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d3b5:	00 
    d3b6:	e8 f5 89 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d3bb:	48 8b 15 d6 77 01 00 	mov    0x177d6(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d3c2:	49 89 c5             	mov    %rax,%r13
    d3c5:	48 2b 05 a4 77 01 00 	sub    0x177a4(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d3cc:	48 c1 e2 10          	shl    $0x10,%rdx
    d3d0:	48 39 d0             	cmp    %rdx,%rax
    d3d3:	73 59                	jae    d42e <f0+0x23de>
    d3d5:	48 89 c2             	mov    %rax,%rdx
    d3d8:	48 c1 ea 10          	shr    $0x10,%rdx
    d3dc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d3e0:	48 8b 15 d1 77 01 00 	mov    0x177d1(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d3e7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3eb:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3ef:	4d 85 e4             	test   %r12,%r12
    d3f2:	74 3a                	je     d42e <f0+0x23de>
    d3f4:	0f b6 0a             	movzbl (%rdx),%ecx
    d3f7:	80 f9 02             	cmp    $0x2,%cl
    d3fa:	0f 84 c0 06 00 00    	je     dac0 <f0+0x2a70>
    d400:	80 f9 01             	cmp    $0x1,%cl
    d403:	75 29                	jne    d42e <f0+0x23de>
    d405:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d408:	0f b7 c0             	movzwl %ax,%eax
    d40b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d40e:	48 0f af c1          	imul   %rcx,%rax
    d412:	48 c1 e8 20          	shr    $0x20,%rax
    d416:	48 39 d0             	cmp    %rdx,%rax
    d419:	73 13                	jae    d42e <f0+0x23de>
    d41b:	49 01 c4             	add    %rax,%r12
    d41e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d423:	0f 84 c5 08 00 00    	je     dcee <f0+0x2c9e>
    d429:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d42e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d435:	33 f3 bf 
    d438:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d43f:	00 
    d440:	bf 01 00 00 00       	mov    $0x1,%edi
    d445:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d44c:	00 
    d44d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d454:	00 
    d455:	e8 56 89 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d45a:	48 8b 15 37 77 01 00 	mov    0x17737(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d461:	49 89 c5             	mov    %rax,%r13
    d464:	48 2b 05 05 77 01 00 	sub    0x17705(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d46b:	48 c1 e2 10          	shl    $0x10,%rdx
    d46f:	48 39 d0             	cmp    %rdx,%rax
    d472:	73 59                	jae    d4cd <f0+0x247d>
    d474:	48 89 c2             	mov    %rax,%rdx
    d477:	48 c1 ea 10          	shr    $0x10,%rdx
    d47b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d47f:	48 8b 15 32 77 01 00 	mov    0x17732(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d486:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d48a:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d48e:	4d 85 e4             	test   %r12,%r12
    d491:	74 3a                	je     d4cd <f0+0x247d>
    d493:	0f b6 0a             	movzbl (%rdx),%ecx
    d496:	80 f9 02             	cmp    $0x2,%cl
    d499:	0f 84 11 06 00 00    	je     dab0 <f0+0x2a60>
    d49f:	80 f9 01             	cmp    $0x1,%cl
    d4a2:	75 29                	jne    d4cd <f0+0x247d>
    d4a4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4a7:	0f b7 c0             	movzwl %ax,%eax
    d4aa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d4ad:	48 0f af c1          	imul   %rcx,%rax
    d4b1:	48 c1 e8 20          	shr    $0x20,%rax
    d4b5:	48 39 d0             	cmp    %rdx,%rax
    d4b8:	73 13                	jae    d4cd <f0+0x247d>
    d4ba:	49 01 c4             	add    %rax,%r12
    d4bd:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d4c2:	0f 84 33 08 00 00    	je     dcfb <f0+0x2cab>
    d4c8:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d4cd:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d4d4:	00 f0 3f 
    d4d7:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    d4de:	00 
    d4df:	bf 01 00 00 00       	mov    $0x1,%edi
    d4e4:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    d4eb:	00 
    d4ec:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    d4f3:	00 
    d4f4:	e8 b7 88 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d4f9:	48 8b 15 98 76 01 00 	mov    0x17698(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d500:	49 89 c5             	mov    %rax,%r13
    d503:	48 2b 05 66 76 01 00 	sub    0x17666(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d50a:	48 c1 e2 10          	shl    $0x10,%rdx
    d50e:	48 39 d0             	cmp    %rdx,%rax
    d511:	73 59                	jae    d56c <f0+0x251c>
    d513:	48 89 c2             	mov    %rax,%rdx
    d516:	48 c1 ea 10          	shr    $0x10,%rdx
    d51a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d51e:	48 8b 15 93 76 01 00 	mov    0x17693(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d525:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d529:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d52d:	4d 85 e4             	test   %r12,%r12
    d530:	74 3a                	je     d56c <f0+0x251c>
    d532:	0f b6 0a             	movzbl (%rdx),%ecx
    d535:	80 f9 02             	cmp    $0x2,%cl
    d538:	0f 84 62 05 00 00    	je     daa0 <f0+0x2a50>
    d53e:	80 f9 01             	cmp    $0x1,%cl
    d541:	75 29                	jne    d56c <f0+0x251c>
    d543:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d546:	0f b7 c0             	movzwl %ax,%eax
    d549:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d54c:	48 0f af c1          	imul   %rcx,%rax
    d550:	48 c1 e8 20          	shr    $0x20,%rax
    d554:	48 39 d0             	cmp    %rdx,%rax
    d557:	73 13                	jae    d56c <f0+0x251c>
    d559:	49 01 c4             	add    %rax,%r12
    d55c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d561:	0f 84 a1 07 00 00    	je     dd08 <f0+0x2cb8>
    d567:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d56c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d573:	33 f3 bf 
    d576:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    d57d:	00 
    d57e:	bf 01 00 00 00       	mov    $0x1,%edi
    d583:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    d58a:	00 
    d58b:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    d592:	00 
    d593:	e8 18 88 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d598:	48 8b 15 f9 75 01 00 	mov    0x175f9(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d59f:	49 89 c5             	mov    %rax,%r13
    d5a2:	48 2b 05 c7 75 01 00 	sub    0x175c7(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d5a9:	48 c1 e2 10          	shl    $0x10,%rdx
    d5ad:	48 39 d0             	cmp    %rdx,%rax
    d5b0:	73 59                	jae    d60b <f0+0x25bb>
    d5b2:	48 89 c2             	mov    %rax,%rdx
    d5b5:	48 c1 ea 10          	shr    $0x10,%rdx
    d5b9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d5bd:	48 8b 15 f4 75 01 00 	mov    0x175f4(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d5c4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d5c8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d5cc:	4d 85 e4             	test   %r12,%r12
    d5cf:	74 3a                	je     d60b <f0+0x25bb>
    d5d1:	0f b6 0a             	movzbl (%rdx),%ecx
    d5d4:	80 f9 02             	cmp    $0x2,%cl
    d5d7:	0f 84 b3 04 00 00    	je     da90 <f0+0x2a40>
    d5dd:	80 f9 01             	cmp    $0x1,%cl
    d5e0:	75 29                	jne    d60b <f0+0x25bb>
    d5e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d5e5:	0f b7 c0             	movzwl %ax,%eax
    d5e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5eb:	48 0f af c1          	imul   %rcx,%rax
    d5ef:	48 c1 e8 20          	shr    $0x20,%rax
    d5f3:	48 39 d0             	cmp    %rdx,%rax
    d5f6:	73 13                	jae    d60b <f0+0x25bb>
    d5f8:	49 01 c4             	add    %rax,%r12
    d5fb:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d600:	0f 84 0f 07 00 00    	je     dd15 <f0+0x2cc5>
    d606:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d60b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d612:	00 f0 3f 
    d615:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    d61c:	00 
    d61d:	bf 01 00 00 00       	mov    $0x1,%edi
    d622:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    d629:	00 
    d62a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    d631:	00 
    d632:	e8 79 87 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d637:	48 8b 15 5a 75 01 00 	mov    0x1755a(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d63e:	49 89 c5             	mov    %rax,%r13
    d641:	48 2b 05 28 75 01 00 	sub    0x17528(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d648:	48 c1 e2 10          	shl    $0x10,%rdx
    d64c:	48 39 d0             	cmp    %rdx,%rax
    d64f:	73 59                	jae    d6aa <f0+0x265a>
    d651:	48 89 c2             	mov    %rax,%rdx
    d654:	48 c1 ea 10          	shr    $0x10,%rdx
    d658:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d65c:	48 8b 15 55 75 01 00 	mov    0x17555(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d663:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d667:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d66b:	4d 85 e4             	test   %r12,%r12
    d66e:	74 3a                	je     d6aa <f0+0x265a>
    d670:	0f b6 0a             	movzbl (%rdx),%ecx
    d673:	80 f9 02             	cmp    $0x2,%cl
    d676:	0f 84 04 04 00 00    	je     da80 <f0+0x2a30>
    d67c:	80 f9 01             	cmp    $0x1,%cl
    d67f:	75 29                	jne    d6aa <f0+0x265a>
    d681:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d684:	0f b7 c0             	movzwl %ax,%eax
    d687:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d68a:	48 0f af c1          	imul   %rcx,%rax
    d68e:	48 c1 e8 20          	shr    $0x20,%rax
    d692:	48 39 d0             	cmp    %rdx,%rax
    d695:	73 13                	jae    d6aa <f0+0x265a>
    d697:	49 01 c4             	add    %rax,%r12
    d69a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d69f:	0f 84 7d 06 00 00    	je     dd22 <f0+0x2cd2>
    d6a5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d6aa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d6b1:	33 f3 bf 
    d6b4:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    d6bb:	00 
    d6bc:	bf 01 00 00 00       	mov    $0x1,%edi
    d6c1:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    d6c8:	00 
    d6c9:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    d6d0:	00 
    d6d1:	e8 da 86 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d6d6:	48 8b 15 bb 74 01 00 	mov    0x174bb(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d6dd:	49 89 c5             	mov    %rax,%r13
    d6e0:	48 2b 05 89 74 01 00 	sub    0x17489(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d6e7:	48 c1 e2 10          	shl    $0x10,%rdx
    d6eb:	48 39 d0             	cmp    %rdx,%rax
    d6ee:	73 59                	jae    d749 <f0+0x26f9>
    d6f0:	48 89 c2             	mov    %rax,%rdx
    d6f3:	48 c1 ea 10          	shr    $0x10,%rdx
    d6f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6fb:	48 8b 15 b6 74 01 00 	mov    0x174b6(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d702:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d706:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d70a:	4d 85 e4             	test   %r12,%r12
    d70d:	74 3a                	je     d749 <f0+0x26f9>
    d70f:	0f b6 0a             	movzbl (%rdx),%ecx
    d712:	80 f9 02             	cmp    $0x2,%cl
    d715:	0f 84 55 03 00 00    	je     da70 <f0+0x2a20>
    d71b:	80 f9 01             	cmp    $0x1,%cl
    d71e:	75 29                	jne    d749 <f0+0x26f9>
    d720:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d723:	0f b7 c0             	movzwl %ax,%eax
    d726:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d729:	48 0f af c1          	imul   %rcx,%rax
    d72d:	48 c1 e8 20          	shr    $0x20,%rax
    d731:	48 39 d0             	cmp    %rdx,%rax
    d734:	73 13                	jae    d749 <f0+0x26f9>
    d736:	49 01 c4             	add    %rax,%r12
    d739:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d73e:	0f 84 eb 05 00 00    	je     dd2f <f0+0x2cdf>
    d744:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d749:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d750:	00 f0 3f 
    d753:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    d75a:	00 
    d75b:	bf 01 00 00 00       	mov    $0x1,%edi
    d760:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    d767:	00 
    d768:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    d76f:	00 
    d770:	e8 3b 86 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d775:	48 8b 15 1c 74 01 00 	mov    0x1741c(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d77c:	49 89 c5             	mov    %rax,%r13
    d77f:	48 2b 05 ea 73 01 00 	sub    0x173ea(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d786:	48 c1 e2 10          	shl    $0x10,%rdx
    d78a:	48 39 d0             	cmp    %rdx,%rax
    d78d:	73 59                	jae    d7e8 <f0+0x2798>
    d78f:	48 89 c2             	mov    %rax,%rdx
    d792:	48 c1 ea 10          	shr    $0x10,%rdx
    d796:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d79a:	48 8b 15 17 74 01 00 	mov    0x17417(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d7a1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7a5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d7a9:	4d 85 e4             	test   %r12,%r12
    d7ac:	74 3a                	je     d7e8 <f0+0x2798>
    d7ae:	0f b6 0a             	movzbl (%rdx),%ecx
    d7b1:	80 f9 02             	cmp    $0x2,%cl
    d7b4:	0f 84 a6 02 00 00    	je     da60 <f0+0x2a10>
    d7ba:	80 f9 01             	cmp    $0x1,%cl
    d7bd:	75 29                	jne    d7e8 <f0+0x2798>
    d7bf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d7c2:	0f b7 c0             	movzwl %ax,%eax
    d7c5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d7c8:	48 0f af c1          	imul   %rcx,%rax
    d7cc:	48 c1 e8 20          	shr    $0x20,%rax
    d7d0:	48 39 d0             	cmp    %rdx,%rax
    d7d3:	73 13                	jae    d7e8 <f0+0x2798>
    d7d5:	49 01 c4             	add    %rax,%r12
    d7d8:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d7dd:	0f 84 59 05 00 00    	je     dd3c <f0+0x2cec>
    d7e3:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7e8:	48 89 ee             	mov    %rbp,%rsi
    d7eb:	bf 01 00 00 00       	mov    $0x1,%edi
    d7f0:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d7f7:	33 f3 bf 
    d7fa:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    d801:	00 
    d802:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    d809:	00 
    d80a:	e8 a1 85 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    d80f:	48 8b 15 82 73 01 00 	mov    0x17382(%rip),%rdx        # 24b98 <fwp_heap+0x13d8>
    d816:	48 89 c5             	mov    %rax,%rbp
    d819:	48 2b 05 50 73 01 00 	sub    0x17350(%rip),%rax        # 24b70 <fwp_heap+0x13b0>
    d820:	48 c1 e2 10          	shl    $0x10,%rdx
    d824:	48 39 d0             	cmp    %rdx,%rax
    d827:	73 59                	jae    d882 <f0+0x2832>
    d829:	48 89 c2             	mov    %rax,%rdx
    d82c:	48 c1 ea 10          	shr    $0x10,%rdx
    d830:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d834:	48 8b 15 7d 73 01 00 	mov    0x1737d(%rip),%rdx        # 24bb8 <fwp_heap+0x13f8>
    d83b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d83f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d843:	4d 85 e4             	test   %r12,%r12
    d846:	74 3a                	je     d882 <f0+0x2832>
    d848:	0f b6 0a             	movzbl (%rdx),%ecx
    d84b:	80 f9 02             	cmp    $0x2,%cl
    d84e:	0f 84 fc 01 00 00    	je     da50 <f0+0x2a00>
    d854:	80 f9 01             	cmp    $0x1,%cl
    d857:	75 29                	jne    d882 <f0+0x2832>
    d859:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d85c:	0f b7 c0             	movzwl %ax,%eax
    d85f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d862:	48 0f af c1          	imul   %rcx,%rax
    d866:	48 c1 e8 20          	shr    $0x20,%rax
    d86a:	48 39 d0             	cmp    %rdx,%rax
    d86d:	73 13                	jae    d882 <f0+0x2832>
    d86f:	49 01 c4             	add    %rax,%r12
    d872:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d877:	0f 84 d1 02 00 00    	je     db4e <f0+0x2afe>
    d87d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d882:	48 89 de             	mov    %rbx,%rsi
    d885:	48 89 ef             	mov    %rbp,%rdi
    d888:	e8 b3 be ff ff       	call   9740 <fwp_hof0.constprop.0>
    d88d:	48 89 ef             	mov    %rbp,%rdi
    d890:	e8 eb a2 ff ff       	call   7b80 <fwp_drop0>
    d895:	48 89 df             	mov    %rbx,%rdi
    d898:	e8 e3 a2 ff ff       	call   7b80 <fwp_drop0>
    d89d:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    d8a4:	00 
    d8a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    d8ac:	00 00 
    d8ae:	0f 85 95 04 00 00    	jne    dd49 <f0+0x2cf9>
    d8b4:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    d8bb:	31 c0                	xor    %eax,%eax
    d8bd:	5b                   	pop    %rbx
    d8be:	5d                   	pop    %rbp
    d8bf:	41 5c                	pop    %r12
    d8c1:	41 5d                	pop    %r13
    d8c3:	41 5e                	pop    %r14
    d8c5:	c3                   	ret
    d8c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    d8cd:	00 00 00 
    d8d0:	4c 89 ef             	mov    %r13,%rdi
    d8d3:	e8 78 7c ff ff       	call   5550 <fwp_rc_forget_slot>
    d8d8:	e9 2c d8 ff ff       	jmp    b109 <f0+0xb9>
    d8dd:	0f 1f 00             	nopl   (%rax)
    d8e0:	66 85 c0             	test   %ax,%ax
    d8e3:	0f 85 ae f5 ff ff    	jne    ce97 <f0+0x1e47>
    d8e9:	e9 99 f5 ff ff       	jmp    ce87 <f0+0x1e37>
    d8ee:	66 90                	xchg   %ax,%ax
    d8f0:	66 85 c0             	test   %ax,%ax
    d8f3:	0f 85 ff f4 ff ff    	jne    cdf8 <f0+0x1da8>
    d8f9:	e9 ea f4 ff ff       	jmp    cde8 <f0+0x1d98>
    d8fe:	66 90                	xchg   %ax,%ax
    d900:	66 85 c0             	test   %ax,%ax
    d903:	0f 85 50 f4 ff ff    	jne    cd59 <f0+0x1d09>
    d909:	e9 3b f4 ff ff       	jmp    cd49 <f0+0x1cf9>
    d90e:	66 90                	xchg   %ax,%ax
    d910:	66 85 c0             	test   %ax,%ax
    d913:	0f 85 a1 f3 ff ff    	jne    ccba <f0+0x1c6a>
    d919:	e9 8c f3 ff ff       	jmp    ccaa <f0+0x1c5a>
    d91e:	66 90                	xchg   %ax,%ax
    d920:	66 85 c0             	test   %ax,%ax
    d923:	0f 85 f2 f2 ff ff    	jne    cc1b <f0+0x1bcb>
    d929:	e9 dd f2 ff ff       	jmp    cc0b <f0+0x1bbb>
    d92e:	66 90                	xchg   %ax,%ax
    d930:	66 85 c0             	test   %ax,%ax
    d933:	0f 85 43 f2 ff ff    	jne    cb7c <f0+0x1b2c>
    d939:	e9 2e f2 ff ff       	jmp    cb6c <f0+0x1b1c>
    d93e:	66 90                	xchg   %ax,%ax
    d940:	66 85 c0             	test   %ax,%ax
    d943:	0f 85 94 f1 ff ff    	jne    cadd <f0+0x1a8d>
    d949:	e9 7f f1 ff ff       	jmp    cacd <f0+0x1a7d>
    d94e:	66 90                	xchg   %ax,%ax
    d950:	66 85 c0             	test   %ax,%ax
    d953:	0f 85 e5 f0 ff ff    	jne    ca3e <f0+0x19ee>
    d959:	e9 d0 f0 ff ff       	jmp    ca2e <f0+0x19de>
    d95e:	66 90                	xchg   %ax,%ax
    d960:	66 85 c0             	test   %ax,%ax
    d963:	0f 85 fd d9 ff ff    	jne    b366 <f0+0x316>
    d969:	e9 e8 d9 ff ff       	jmp    b356 <f0+0x306>
    d96e:	66 90                	xchg   %ax,%ax
    d970:	66 85 c0             	test   %ax,%ax
    d973:	0f 85 57 d9 ff ff    	jne    b2d0 <f0+0x280>
    d979:	e9 42 d9 ff ff       	jmp    b2c0 <f0+0x270>
    d97e:	66 90                	xchg   %ax,%ax
    d980:	66 85 c0             	test   %ax,%ax
    d983:	0f 85 b1 d8 ff ff    	jne    b23a <f0+0x1ea>
    d989:	e9 9c d8 ff ff       	jmp    b22a <f0+0x1da>
    d98e:	66 90                	xchg   %ax,%ax
    d990:	66 85 c0             	test   %ax,%ax
    d993:	0f 85 0e eb ff ff    	jne    c4a7 <f0+0x1457>
    d999:	e9 f9 ea ff ff       	jmp    c497 <f0+0x1447>
    d99e:	66 90                	xchg   %ax,%ax
    d9a0:	66 85 c0             	test   %ax,%ax
    d9a3:	0f 85 5f ea ff ff    	jne    c408 <f0+0x13b8>
    d9a9:	e9 4a ea ff ff       	jmp    c3f8 <f0+0x13a8>
    d9ae:	66 90                	xchg   %ax,%ax
    d9b0:	66 85 c0             	test   %ax,%ax
    d9b3:	0f 85 e2 da ff ff    	jne    b49b <f0+0x44b>
    d9b9:	e9 cd da ff ff       	jmp    b48b <f0+0x43b>
    d9be:	66 90                	xchg   %ax,%ax
    d9c0:	66 85 c0             	test   %ax,%ax
    d9c3:	0f 85 33 da ff ff    	jne    b3fc <f0+0x3ac>
    d9c9:	e9 1e da ff ff       	jmp    b3ec <f0+0x39c>
    d9ce:	66 90                	xchg   %ax,%ax
    d9d0:	66 85 c0             	test   %ax,%ax
    d9d3:	0f 85 c6 ef ff ff    	jne    c99f <f0+0x194f>
    d9d9:	e9 b1 ef ff ff       	jmp    c98f <f0+0x193f>
    d9de:	66 90                	xchg   %ax,%ax
    d9e0:	66 85 c0             	test   %ax,%ax
    d9e3:	0f 85 17 ef ff ff    	jne    c900 <f0+0x18b0>
    d9e9:	e9 02 ef ff ff       	jmp    c8f0 <f0+0x18a0>
    d9ee:	66 90                	xchg   %ax,%ax
    d9f0:	66 85 c0             	test   %ax,%ax
    d9f3:	0f 85 68 ee ff ff    	jne    c861 <f0+0x1811>
    d9f9:	e9 53 ee ff ff       	jmp    c851 <f0+0x1801>
    d9fe:	66 90                	xchg   %ax,%ax
    da00:	66 85 c0             	test   %ax,%ax
    da03:	0f 85 b9 ed ff ff    	jne    c7c2 <f0+0x1772>
    da09:	e9 a4 ed ff ff       	jmp    c7b2 <f0+0x1762>
    da0e:	66 90                	xchg   %ax,%ax
    da10:	66 85 c0             	test   %ax,%ax
    da13:	0f 85 0a ed ff ff    	jne    c723 <f0+0x16d3>
    da19:	e9 f5 ec ff ff       	jmp    c713 <f0+0x16c3>
    da1e:	66 90                	xchg   %ax,%ax
    da20:	66 85 c0             	test   %ax,%ax
    da23:	0f 85 5b ec ff ff    	jne    c684 <f0+0x1634>
    da29:	e9 46 ec ff ff       	jmp    c674 <f0+0x1624>
    da2e:	66 90                	xchg   %ax,%ax
    da30:	66 85 c0             	test   %ax,%ax
    da33:	0f 85 ac eb ff ff    	jne    c5e5 <f0+0x1595>
    da39:	e9 97 eb ff ff       	jmp    c5d5 <f0+0x1585>
    da3e:	66 90                	xchg   %ax,%ax
    da40:	66 85 c0             	test   %ax,%ax
    da43:	0f 85 fd ea ff ff    	jne    c546 <f0+0x14f6>
    da49:	e9 e8 ea ff ff       	jmp    c536 <f0+0x14e6>
    da4e:	66 90                	xchg   %ax,%ax
    da50:	66 85 c0             	test   %ax,%ax
    da53:	0f 85 29 fe ff ff    	jne    d882 <f0+0x2832>
    da59:	e9 14 fe ff ff       	jmp    d872 <f0+0x2822>
    da5e:	66 90                	xchg   %ax,%ax
    da60:	66 85 c0             	test   %ax,%ax
    da63:	0f 85 7f fd ff ff    	jne    d7e8 <f0+0x2798>
    da69:	e9 6a fd ff ff       	jmp    d7d8 <f0+0x2788>
    da6e:	66 90                	xchg   %ax,%ax
    da70:	66 85 c0             	test   %ax,%ax
    da73:	0f 85 d0 fc ff ff    	jne    d749 <f0+0x26f9>
    da79:	e9 bb fc ff ff       	jmp    d739 <f0+0x26e9>
    da7e:	66 90                	xchg   %ax,%ax
    da80:	66 85 c0             	test   %ax,%ax
    da83:	0f 85 21 fc ff ff    	jne    d6aa <f0+0x265a>
    da89:	e9 0c fc ff ff       	jmp    d69a <f0+0x264a>
    da8e:	66 90                	xchg   %ax,%ax
    da90:	66 85 c0             	test   %ax,%ax
    da93:	0f 85 72 fb ff ff    	jne    d60b <f0+0x25bb>
    da99:	e9 5d fb ff ff       	jmp    d5fb <f0+0x25ab>
    da9e:	66 90                	xchg   %ax,%ax
    daa0:	66 85 c0             	test   %ax,%ax
    daa3:	0f 85 c3 fa ff ff    	jne    d56c <f0+0x251c>
    daa9:	e9 ae fa ff ff       	jmp    d55c <f0+0x250c>
    daae:	66 90                	xchg   %ax,%ax
    dab0:	66 85 c0             	test   %ax,%ax
    dab3:	0f 85 14 fa ff ff    	jne    d4cd <f0+0x247d>
    dab9:	e9 ff f9 ff ff       	jmp    d4bd <f0+0x246d>
    dabe:	66 90                	xchg   %ax,%ax
    dac0:	66 85 c0             	test   %ax,%ax
    dac3:	0f 85 65 f9 ff ff    	jne    d42e <f0+0x23de>
    dac9:	e9 50 f9 ff ff       	jmp    d41e <f0+0x23ce>
    dace:	66 90                	xchg   %ax,%ax
    dad0:	66 85 c0             	test   %ax,%ax
    dad3:	0f 85 b6 f8 ff ff    	jne    d38f <f0+0x233f>
    dad9:	e9 a1 f8 ff ff       	jmp    d37f <f0+0x232f>
    dade:	66 90                	xchg   %ax,%ax
    dae0:	66 85 c0             	test   %ax,%ax
    dae3:	0f 85 07 f8 ff ff    	jne    d2f0 <f0+0x22a0>
    dae9:	e9 f2 f7 ff ff       	jmp    d2e0 <f0+0x2290>
    daee:	66 90                	xchg   %ax,%ax
    daf0:	66 85 c0             	test   %ax,%ax
    daf3:	0f 85 58 f7 ff ff    	jne    d251 <f0+0x2201>
    daf9:	e9 43 f7 ff ff       	jmp    d241 <f0+0x21f1>
    dafe:	66 90                	xchg   %ax,%ax
    db00:	66 85 c0             	test   %ax,%ax
    db03:	0f 85 a9 f6 ff ff    	jne    d1b2 <f0+0x2162>
    db09:	e9 94 f6 ff ff       	jmp    d1a2 <f0+0x2152>
    db0e:	66 90                	xchg   %ax,%ax
    db10:	66 85 c0             	test   %ax,%ax
    db13:	0f 85 fa f5 ff ff    	jne    d113 <f0+0x20c3>
    db19:	e9 e5 f5 ff ff       	jmp    d103 <f0+0x20b3>
    db1e:	66 90                	xchg   %ax,%ax
    db20:	66 85 c0             	test   %ax,%ax
    db23:	0f 85 4b f5 ff ff    	jne    d074 <f0+0x2024>
    db29:	e9 36 f5 ff ff       	jmp    d064 <f0+0x2014>
    db2e:	66 90                	xchg   %ax,%ax
    db30:	66 85 c0             	test   %ax,%ax
    db33:	0f 85 9c f4 ff ff    	jne    cfd5 <f0+0x1f85>
    db39:	e9 87 f4 ff ff       	jmp    cfc5 <f0+0x1f75>
    db3e:	66 90                	xchg   %ax,%ax
    db40:	66 85 c0             	test   %ax,%ax
    db43:	0f 85 ed f3 ff ff    	jne    cf36 <f0+0x1ee6>
    db49:	e9 d8 f3 ff ff       	jmp    cf26 <f0+0x1ed6>
    db4e:	4c 89 e7             	mov    %r12,%rdi
    db51:	e8 fa 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db56:	e9 22 fd ff ff       	jmp    d87d <f0+0x282d>
    db5b:	4c 89 e7             	mov    %r12,%rdi
    db5e:	e8 ed 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db63:	e9 cd d6 ff ff       	jmp    b235 <f0+0x1e5>
    db68:	4c 89 e7             	mov    %r12,%rdi
    db6b:	e8 e0 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db70:	e9 56 d7 ff ff       	jmp    b2cb <f0+0x27b>
    db75:	4c 89 e7             	mov    %r12,%rdi
    db78:	e8 d3 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db7d:	e9 df d7 ff ff       	jmp    b361 <f0+0x311>
    db82:	4c 89 e7             	mov    %r12,%rdi
    db85:	e8 c6 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db8a:	e9 68 d8 ff ff       	jmp    b3f7 <f0+0x3a7>
    db8f:	4c 89 e7             	mov    %r12,%rdi
    db92:	e8 b9 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    db97:	e9 fa d8 ff ff       	jmp    b496 <f0+0x446>
    db9c:	4c 89 e7             	mov    %r12,%rdi
    db9f:	e8 ac 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dba4:	e9 5a e8 ff ff       	jmp    c403 <f0+0x13b3>
    dba9:	4c 89 e7             	mov    %r12,%rdi
    dbac:	e8 9f 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbb1:	e9 ec e8 ff ff       	jmp    c4a2 <f0+0x1452>
    dbb6:	4c 89 e7             	mov    %r12,%rdi
    dbb9:	e8 92 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbbe:	e9 7e e9 ff ff       	jmp    c541 <f0+0x14f1>
    dbc3:	4c 89 e7             	mov    %r12,%rdi
    dbc6:	e8 85 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbcb:	e9 10 ea ff ff       	jmp    c5e0 <f0+0x1590>
    dbd0:	4c 89 e7             	mov    %r12,%rdi
    dbd3:	e8 78 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbd8:	e9 a2 ea ff ff       	jmp    c67f <f0+0x162f>
    dbdd:	4c 89 e7             	mov    %r12,%rdi
    dbe0:	e8 6b 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbe5:	e9 34 eb ff ff       	jmp    c71e <f0+0x16ce>
    dbea:	4c 89 e7             	mov    %r12,%rdi
    dbed:	e8 5e 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbf2:	e9 c6 eb ff ff       	jmp    c7bd <f0+0x176d>
    dbf7:	4c 89 e7             	mov    %r12,%rdi
    dbfa:	e8 51 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dbff:	e9 58 ec ff ff       	jmp    c85c <f0+0x180c>
    dc04:	4c 89 e7             	mov    %r12,%rdi
    dc07:	e8 44 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc0c:	e9 ea ec ff ff       	jmp    c8fb <f0+0x18ab>
    dc11:	4c 89 e7             	mov    %r12,%rdi
    dc14:	e8 37 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc19:	e9 7c ed ff ff       	jmp    c99a <f0+0x194a>
    dc1e:	4c 89 e7             	mov    %r12,%rdi
    dc21:	e8 2a 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc26:	e9 0e ee ff ff       	jmp    ca39 <f0+0x19e9>
    dc2b:	4c 89 e7             	mov    %r12,%rdi
    dc2e:	e8 1d 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc33:	e9 a0 ee ff ff       	jmp    cad8 <f0+0x1a88>
    dc38:	4c 89 e7             	mov    %r12,%rdi
    dc3b:	e8 10 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc40:	e9 32 ef ff ff       	jmp    cb77 <f0+0x1b27>
    dc45:	4c 89 e7             	mov    %r12,%rdi
    dc48:	e8 03 79 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc4d:	e9 c4 ef ff ff       	jmp    cc16 <f0+0x1bc6>
    dc52:	4c 89 e7             	mov    %r12,%rdi
    dc55:	e8 f6 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc5a:	e9 56 f0 ff ff       	jmp    ccb5 <f0+0x1c65>
    dc5f:	4c 89 e7             	mov    %r12,%rdi
    dc62:	e8 e9 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc67:	e9 e8 f0 ff ff       	jmp    cd54 <f0+0x1d04>
    dc6c:	4c 89 e7             	mov    %r12,%rdi
    dc6f:	e8 dc 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc74:	e9 7a f1 ff ff       	jmp    cdf3 <f0+0x1da3>
    dc79:	4c 89 e7             	mov    %r12,%rdi
    dc7c:	e8 cf 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc81:	e9 0c f2 ff ff       	jmp    ce92 <f0+0x1e42>
    dc86:	4c 89 e7             	mov    %r12,%rdi
    dc89:	e8 c2 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc8e:	e9 9e f2 ff ff       	jmp    cf31 <f0+0x1ee1>
    dc93:	4c 89 e7             	mov    %r12,%rdi
    dc96:	e8 b5 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dc9b:	e9 30 f3 ff ff       	jmp    cfd0 <f0+0x1f80>
    dca0:	4c 89 e7             	mov    %r12,%rdi
    dca3:	e8 a8 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dca8:	e9 c2 f3 ff ff       	jmp    d06f <f0+0x201f>
    dcad:	4c 89 e7             	mov    %r12,%rdi
    dcb0:	e8 9b 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dcb5:	e9 54 f4 ff ff       	jmp    d10e <f0+0x20be>
    dcba:	4c 89 e7             	mov    %r12,%rdi
    dcbd:	e8 8e 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dcc2:	e9 e6 f4 ff ff       	jmp    d1ad <f0+0x215d>
    dcc7:	4c 89 e7             	mov    %r12,%rdi
    dcca:	e8 81 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dccf:	e9 78 f5 ff ff       	jmp    d24c <f0+0x21fc>
    dcd4:	4c 89 e7             	mov    %r12,%rdi
    dcd7:	e8 74 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dcdc:	e9 0a f6 ff ff       	jmp    d2eb <f0+0x229b>
    dce1:	4c 89 e7             	mov    %r12,%rdi
    dce4:	e8 67 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dce9:	e9 9c f6 ff ff       	jmp    d38a <f0+0x233a>
    dcee:	4c 89 e7             	mov    %r12,%rdi
    dcf1:	e8 5a 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dcf6:	e9 2e f7 ff ff       	jmp    d429 <f0+0x23d9>
    dcfb:	4c 89 e7             	mov    %r12,%rdi
    dcfe:	e8 4d 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd03:	e9 c0 f7 ff ff       	jmp    d4c8 <f0+0x2478>
    dd08:	4c 89 e7             	mov    %r12,%rdi
    dd0b:	e8 40 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd10:	e9 52 f8 ff ff       	jmp    d567 <f0+0x2517>
    dd15:	4c 89 e7             	mov    %r12,%rdi
    dd18:	e8 33 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd1d:	e9 e4 f8 ff ff       	jmp    d606 <f0+0x25b6>
    dd22:	4c 89 e7             	mov    %r12,%rdi
    dd25:	e8 26 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd2a:	e9 76 f9 ff ff       	jmp    d6a5 <f0+0x2655>
    dd2f:	4c 89 e7             	mov    %r12,%rdi
    dd32:	e8 19 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd37:	e9 08 fa ff ff       	jmp    d744 <f0+0x26f4>
    dd3c:	4c 89 e7             	mov    %r12,%rdi
    dd3f:	e8 0c 78 ff ff       	call   5550 <fwp_rc_forget_slot>
    dd44:	e9 9a fa ff ff       	jmp    d7e3 <f0+0x2793>
    dd49:	e8 12 57 ff ff       	call   3460 <__stack_chk_fail@plt>
    dd4e:	66 90                	xchg   %ax,%ax

000000000000dd50 <fwp_main_thread>:
    dd50:	f3 0f 1e fa          	endbr64
    dd54:	41 54                	push   %r12
    dd56:	55                   	push   %rbp
    dd57:	53                   	push   %rbx
    dd58:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    dd5f:	8b 35 ff 6d 01 00    	mov    0x16dff(%rip),%esi        # 24b64 <fwp_heap+0x13a4>
    dd65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    dd6c:	00 00 
    dd6e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    dd75:	00 
    dd76:	31 c0                	xor    %eax,%eax
    dd78:	85 f6                	test   %esi,%esi
    dd7a:	0f 84 a8 06 00 00    	je     e428 <fwp_main_thread+0x6d8>
    dd80:	8b 0d e2 6d 01 00    	mov    0x16de2(%rip),%ecx        # 24b68 <fwp_heap+0x13a8>
    dd86:	85 c9                	test   %ecx,%ecx
    dd88:	0f 85 82 06 00 00    	jne    e410 <fwp_main_thread+0x6c0>
    dd8e:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    dd93:	31 f6                	xor    %esi,%esi
    dd95:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    dd9a:	48 c7 05 ab 53 01 00 	movq   $0x40000000,0x153ab(%rip)        # 23150 <fwp_main_stack_size>
    dda1:	00 00 00 40 
    dda5:	48 89 05 ac 53 01 00 	mov    %rax,0x153ac(%rip)        # 23158 <fwp_main_stack_top>
    ddac:	48 8d 05 cd 52 00 00 	lea    0x52cd(%rip),%rax        # 13080 <alt.5>
    ddb3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ddb8:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    ddbf:	01 00 
    ddc1:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    ddc8:	00 
    ddc9:	e8 f2 58 ff ff       	call   36c0 <sigaltstack@plt>
    ddce:	85 c0                	test   %eax,%eax
    ddd0:	0f 85 8a 06 00 00    	jne    e460 <fwp_main_thread+0x710>
    ddd6:	31 c0                	xor    %eax,%eax
    ddd8:	b9 12 00 00 00       	mov    $0x12,%ecx
    dddd:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    dde2:	f3 48 ab             	rep stos %rax,(%rdi)
    dde5:	48 8d 05 04 5f ff ff 	lea    -0xa0fc(%rip),%rax        # 3cf0 <fwp_segv>
    ddec:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    ddf1:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    ddf8:	04 00 00 08 
    ddfc:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    de01:	e8 7a 57 ff ff       	call   3580 <sigemptyset@plt>
    de06:	85 c0                	test   %eax,%eax
    de08:	0f 85 52 06 00 00    	jne    e460 <fwp_main_thread+0x710>
    de0e:	31 d2                	xor    %edx,%edx
    de10:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de15:	bf 0b 00 00 00       	mov    $0xb,%edi
    de1a:	e8 e1 55 ff ff       	call   3400 <sigaction@plt>
    de1f:	85 c0                	test   %eax,%eax
    de21:	0f 85 39 06 00 00    	jne    e460 <fwp_main_thread+0x710>
    de27:	31 d2                	xor    %edx,%edx
    de29:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    de2e:	bf 07 00 00 00       	mov    $0x7,%edi
    de33:	e8 c8 55 ff ff       	call   3400 <sigaction@plt>
    de38:	85 c0                	test   %eax,%eax
    de3a:	0f 85 20 06 00 00    	jne    e460 <fwp_main_thread+0x710>
    de40:	8b 15 b2 52 01 00    	mov    0x152b2(%rip),%edx        # 230f8 <descent_registered>
    de46:	85 d2                	test   %edx,%edx
    de48:	0f 84 72 05 00 00    	je     e3c0 <fwp_main_thread+0x670>
    de4e:	8b 05 1c 52 00 00    	mov    0x521c(%rip),%eax        # 13070 <st.3>
    de54:	85 c0                	test   %eax,%eax
    de56:	0f 84 90 05 00 00    	je     e3ec <fwp_main_thread+0x69c>
    de5c:	48 8b 2d 3d 59 01 00 	mov    0x1593d(%rip),%rbp        # 237a0 <fwp_cur>
    de63:	48 85 ed             	test   %rbp,%rbp
    de66:	0f 84 74 03 00 00    	je     e1e0 <fwp_main_thread+0x490>
    de6c:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    de71:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    de75:	48 89 eb             	mov    %rbp,%rbx
    de78:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    de7d:	0f 84 41 01 00 00    	je     dfc4 <fwp_main_thread+0x274>
    de83:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    de88:	0f 84 82 02 00 00    	je     e110 <fwp_main_thread+0x3c0>
    de8e:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    de92:	0f 84 68 02 00 00    	je     e100 <fwp_main_thread+0x3b0>
    de98:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    de9c:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    dea0:	0f 85 ea 02 00 00    	jne    e190 <fwp_main_thread+0x440>
    dea6:	48 8b 43 60          	mov    0x60(%rbx),%rax
    deaa:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    deb1:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    deb5:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    debc:	00 00 00 00 
    dec0:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    dec7:	48 85 d2             	test   %rdx,%rdx
    deca:	74 07                	je     ded3 <fwp_main_thread+0x183>
    decc:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    ded3:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ded7:	48 85 c0             	test   %rax,%rax
    deda:	74 34                	je     df10 <fwp_main_thread+0x1c0>
    dedc:	48 89 43 68          	mov    %rax,0x68(%rbx)
    dee0:	48 8b 05 91 58 01 00 	mov    0x15891(%rip),%rax        # 23778 <fwp_timers>
    dee7:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    deeb:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    def2:	00 00 00 00 
    def6:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    defd:	48 85 c0             	test   %rax,%rax
    df00:	74 07                	je     df09 <fwp_main_thread+0x1b9>
    df02:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    df09:	48 89 1d 68 58 01 00 	mov    %rbx,0x15868(%rip)        # 23778 <fwp_timers>
    df10:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    df14:	e8 37 98 ff ff       	call   7750 <fwp_block>
    df19:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    df20:	48 85 c9             	test   %rcx,%rcx
    df23:	74 47                	je     df6c <fwp_main_thread+0x21c>
    df25:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    df2c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    df33:	48 85 d2             	test   %rdx,%rdx
    df36:	0f 84 94 02 00 00    	je     e1d0 <fwp_main_thread+0x480>
    df3c:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    df43:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    df4a:	48 85 c0             	test   %rax,%rax
    df4d:	74 07                	je     df56 <fwp_main_thread+0x206>
    df4f:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    df56:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    df5d:	00 00 00 00 
    df61:	66 0f ef c0          	pxor   %xmm0,%xmm0
    df65:	0f 11 83 18 01 00 00 	movups %xmm0,0x118(%rbx)
    df6c:	48 8b 0d 2d 58 01 00 	mov    0x1582d(%rip),%rcx        # 237a0 <fwp_cur>
    df73:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    df77:	0f 84 03 02 00 00    	je     e180 <fwp_main_thread+0x430>
    df7d:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    df84:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    df8b:	48 85 d2             	test   %rdx,%rdx
    df8e:	0f 84 fc 03 00 00    	je     e390 <fwp_main_thread+0x640>
    df94:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    df9b:	48 85 c0             	test   %rax,%rax
    df9e:	74 07                	je     dfa7 <fwp_main_thread+0x257>
    dfa0:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    dfa7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    dfab:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    dfaf:	0f 11 8b 08 01 00 00 	movups %xmm1,0x108(%rbx)
    dfb6:	48 89 cb             	mov    %rcx,%rbx
    dfb9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    dfbe:	0f 85 bf fe ff ff    	jne    de83 <fwp_main_thread+0x133>
    dfc4:	48 83 3d 6c 74 01 00 	cmpq   $0x0,0x1746c(%rip)        # 25438 <fwp_state_len>
    dfcb:	00 
    dfcc:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    dfd0:	0f 84 bc 00 00 00    	je     e092 <fwp_main_thread+0x342>
    dfd6:	48 39 1d bb 57 01 00 	cmp    %rbx,0x157bb(%rip)        # 23798 <fwp_root>
    dfdd:	c7 05 99 50 01 00 00 	movl   $0x0,0x15099(%rip)        # 23080 <fwp_exit_code>
    dfe4:	00 00 00 
    dfe7:	0f 85 91 04 00 00    	jne    e47e <fwp_main_thread+0x72e>
    dfed:	48 85 db             	test   %rbx,%rbx
    dff0:	0f 84 10 02 00 00    	je     e206 <fwp_main_thread+0x4b6>
    dff6:	48 8b 15 6b 57 01 00 	mov    0x1576b(%rip),%rdx        # 23768 <fwp_tasks_active>
    dffd:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e001:	48 85 d2             	test   %rdx,%rdx
    e004:	0f 84 fc 01 00 00    	je     e206 <fwp_main_thread+0x4b6>
    e00a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e010:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e014:	75 08                	jne    e01e <fwp_main_thread+0x2ce>
    e016:	48 89 d7             	mov    %rdx,%rdi
    e019:	e8 e2 62 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e01e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e025:	48 85 d2             	test   %rdx,%rdx
    e028:	75 e6                	jne    e010 <fwp_main_thread+0x2c0>
    e02a:	eb 31                	jmp    e05d <fwp_main_thread+0x30d>
    e02c:	0f 1f 40 00          	nopl   0x0(%rax)
    e030:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e037:	48 89 1d 42 57 01 00 	mov    %rbx,0x15742(%rip)        # 23780 <fwp_ready_tail>
    e03e:	e8 0d 97 ff ff       	call   7750 <fwp_block>
    e043:	e8 f8 94 ff ff       	call   7540 <fwp_free_zombie>
    e048:	48 83 3d 18 57 01 00 	cmpq   $0x0,0x15718(%rip)        # 23768 <fwp_tasks_active>
    e04f:	00 
    e050:	0f 84 b0 01 00 00    	je     e206 <fwp_main_thread+0x4b6>
    e056:	48 8b 1d 3b 57 01 00 	mov    0x1573b(%rip),%rbx        # 23798 <fwp_root>
    e05d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e061:	75 db                	jne    e03e <fwp_main_thread+0x2ee>
    e063:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e067:	75 d5                	jne    e03e <fwp_main_thread+0x2ee>
    e069:	48 8b 05 10 57 01 00 	mov    0x15710(%rip),%rax        # 23780 <fwp_ready_tail>
    e070:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e074:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e07b:	00 00 00 00 
    e07f:	48 85 c0             	test   %rax,%rax
    e082:	75 ac                	jne    e030 <fwp_main_thread+0x2e0>
    e084:	48 89 1d fd 56 01 00 	mov    %rbx,0x156fd(%rip)        # 23788 <fwp_ready_head>
    e08b:	eb aa                	jmp    e037 <fwp_main_thread+0x2e7>
    e08d:	0f 1f 00             	nopl   (%rax)
    e090:	31 db                	xor    %ebx,%ebx
    e092:	48 83 3d 8e 73 01 00 	cmpq   $0x0,0x1738e(%rip)        # 25428 <fwp_state_owners>
    e099:	00 
    e09a:	0f 85 36 ff ff ff    	jne    dfd6 <fwp_main_thread+0x286>
    e0a0:	48 8b 3d 99 73 01 00 	mov    0x17399(%rip),%rdi        # 25440 <fwp_state>
    e0a7:	e8 e4 76 ff ff       	call   5790 <fwp_mem_free>
    e0ac:	48 c7 05 89 73 01 00 	movq   $0x0,0x17389(%rip)        # 25440 <fwp_state>
    e0b3:	00 00 00 00 
    e0b7:	48 c7 05 6e 73 01 00 	movq   $0x0,0x1736e(%rip)        # 25430 <fwp_state_cap>
    e0be:	00 00 00 00 
    e0c2:	48 85 db             	test   %rbx,%rbx
    e0c5:	0f 84 76 03 00 00    	je     e441 <fwp_main_thread+0x6f1>
    e0cb:	48 39 1d c6 56 01 00 	cmp    %rbx,0x156c6(%rip)        # 23798 <fwp_root>
    e0d2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e0d9:	00 00 00 00 
    e0dd:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e0e4:	00 00 00 00 
    e0e8:	c7 05 8e 4f 01 00 00 	movl   $0x0,0x14f8e(%rip)        # 23080 <fwp_exit_code>
    e0ef:	00 00 00 
    e0f2:	0f 84 fe fe ff ff    	je     dff6 <fwp_main_thread+0x2a6>
    e0f8:	e9 58 56 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e0fd:	0f 1f 00             	nopl   (%rax)
    e100:	e8 5b 64 ff ff       	call   4560 <fwp_now_ns>
    e105:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e109:	0f 8d 91 02 00 00    	jge    e3a0 <fwp_main_thread+0x650>
    e10f:	90                   	nop
    e110:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e114:	0f 85 7e fd ff ff    	jne    de98 <fwp_main_thread+0x148>
    e11a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e11e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e122:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e126:	0f 85 7e fd ff ff    	jne    deaa <fwp_main_thread+0x15a>
    e12c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e130:	48 85 c9             	test   %rcx,%rcx
    e133:	0f 84 71 fd ff ff    	je     deaa <fwp_main_thread+0x15a>
    e139:	48 85 c0             	test   %rax,%rax
    e13c:	0f 84 2f 03 00 00    	je     e471 <fwp_main_thread+0x721>
    e142:	48 39 c8             	cmp    %rcx,%rax
    e145:	48 0f 4f c1          	cmovg  %rcx,%rax
    e149:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e150:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e154:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e15b:	00 00 00 00 
    e15f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e166:	48 85 d2             	test   %rdx,%rdx
    e169:	74 07                	je     e172 <fwp_main_thread+0x422>
    e16b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e172:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e176:	e9 61 fd ff ff       	jmp    dedc <fwp_main_thread+0x18c>
    e17b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e180:	48 89 cb             	mov    %rcx,%rbx
    e183:	e9 f0 fc ff ff       	jmp    de78 <fwp_main_thread+0x128>
    e188:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e18f:	00 
    e190:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e194:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e19b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e1a2:	00 00 00 00 
    e1a6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e1ad:	48 85 c0             	test   %rax,%rax
    e1b0:	0f 84 82 02 00 00    	je     e438 <fwp_main_thread+0x6e8>
    e1b6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e1bd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e1c1:	e9 4a fd ff ff       	jmp    df10 <fwp_main_thread+0x1c0>
    e1c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e1cd:	00 00 00 
    e1d0:	48 89 01             	mov    %rax,(%rcx)
    e1d3:	e9 72 fd ff ff       	jmp    df4a <fwp_main_thread+0x1fa>
    e1d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e1df:	00 
    e1e0:	48 83 3d 50 72 01 00 	cmpq   $0x0,0x17250(%rip)        # 25438 <fwp_state_len>
    e1e7:	00 
    e1e8:	0f 84 a2 fe ff ff    	je     e090 <fwp_main_thread+0x340>
    e1ee:	48 83 3d a2 55 01 00 	cmpq   $0x0,0x155a2(%rip)        # 23798 <fwp_root>
    e1f5:	00 
    e1f6:	c7 05 80 4e 01 00 00 	movl   $0x0,0x14e80(%rip)        # 23080 <fwp_exit_code>
    e1fd:	00 00 00 
    e200:	0f 85 7d 02 00 00    	jne    e483 <fwp_main_thread+0x733>
    e206:	e8 35 93 ff ff       	call   7540 <fwp_free_zombie>
    e20b:	48 83 3d 75 55 01 00 	cmpq   $0x0,0x15575(%rip)        # 23788 <fwp_ready_head>
    e212:	00 
    e213:	0f 85 3c 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e219:	48 83 3d 57 55 01 00 	cmpq   $0x0,0x15557(%rip)        # 23778 <fwp_timers>
    e220:	00 
    e221:	0f 85 2e 55 ff ff    	jne    3755 <fwp_main_thread.cold>
    e227:	8b 1d 37 4f 01 00    	mov    0x14f37(%rip),%ebx        # 23164 <fwp_stack_pool_n>
    e22d:	85 db                	test   %ebx,%ebx
    e22f:	74 36                	je     e267 <fwp_main_thread+0x517>
    e231:	83 eb 01             	sub    $0x1,%ebx
    e234:	48 8d 05 45 4f 01 00 	lea    0x14f45(%rip),%rax        # 23180 <fwp_stack_pool>
    e23b:	48 63 d3             	movslq %ebx,%rdx
    e23e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e242:	eb 07                	jmp    e24b <fwp_main_thread+0x4fb>
    e244:	0f 1f 40 00          	nopl   0x0(%rax)
    e248:	83 eb 01             	sub    $0x1,%ebx
    e24b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e24f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e254:	89 1d 0a 4f 01 00    	mov    %ebx,0x14f0a(%rip)        # 23164 <fwp_stack_pool_n>
    e25a:	48 83 ed 08          	sub    $0x8,%rbp
    e25e:	e8 7d 53 ff ff       	call   35e0 <munmap@plt>
    e263:	85 db                	test   %ebx,%ebx
    e265:	75 e1                	jne    e248 <fwp_main_thread+0x4f8>
    e267:	8b 3d af 4d 00 00    	mov    0x4daf(%rip),%edi        # 1301c <fwp_epfd>
    e26d:	85 ff                	test   %edi,%edi
    e26f:	78 05                	js     e276 <fwp_main_thread+0x526>
    e271:	e8 5a 52 ff ff       	call   34d0 <close@plt>
    e276:	4c 8b 25 03 51 01 00 	mov    0x15103(%rip),%r12        # 23380 <fwp_nfdws>
    e27d:	48 8b 2d 04 51 01 00 	mov    0x15104(%rip),%rbp        # 23388 <fwp_fdws>
    e284:	31 db                	xor    %ebx,%ebx
    e286:	c7 05 8c 4d 00 00 ff 	movl   $0xffffffff,0x4d8c(%rip)        # 1301c <fwp_epfd>
    e28d:	ff ff ff 
    e290:	4d 85 e4             	test   %r12,%r12
    e293:	74 38                	je     e2cd <fwp_main_thread+0x57d>
    e295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e29c:	00 00 00 00 
    e2a0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e2a5:	48 85 ff             	test   %rdi,%rdi
    e2a8:	74 1a                	je     e2c4 <fwp_main_thread+0x574>
    e2aa:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e2ae:	0f 85 a1 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2b4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e2b9:	0f 85 96 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e2bf:	e8 cc 74 ff ff       	call   5790 <fwp_mem_free>
    e2c4:	48 83 c3 01          	add    $0x1,%rbx
    e2c8:	4c 39 e3             	cmp    %r12,%rbx
    e2cb:	75 d3                	jne    e2a0 <fwp_main_thread+0x550>
    e2cd:	48 89 ef             	mov    %rbp,%rdi
    e2d0:	e8 bb 74 ff ff       	call   5790 <fwp_mem_free>
    e2d5:	48 8b 15 bc 54 01 00 	mov    0x154bc(%rip),%rdx        # 23798 <fwp_root>
    e2dc:	48 c7 05 a1 50 01 00 	movq   $0x0,0x150a1(%rip)        # 23388 <fwp_fdws>
    e2e3:	00 00 00 00 
    e2e7:	48 c7 05 8e 50 01 00 	movq   $0x0,0x1508e(%rip)        # 23380 <fwp_nfdws>
    e2ee:	00 00 00 00 
    e2f2:	48 85 d2             	test   %rdx,%rdx
    e2f5:	74 4e                	je     e345 <fwp_main_thread+0x5f5>
    e2f7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e2fc:	0f 85 53 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e302:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e309:	00 
    e30a:	0f 85 45 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e310:	48 83 3d 20 71 01 00 	cmpq   $0x0,0x17120(%rip)        # 25438 <fwp_state_len>
    e317:	00 
    e318:	0f 85 37 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e31e:	48 83 3d 02 71 01 00 	cmpq   $0x0,0x17102(%rip)        # 25428 <fwp_state_owners>
    e325:	00 
    e326:	0f 85 29 54 ff ff    	jne    3755 <fwp_main_thread.cold>
    e32c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e331:	31 c0                	xor    %eax,%eax
    e333:	48 8d 3d 66 50 01 00 	lea    0x15066(%rip),%rdi        # 233a0 <fwp_root_context>
    e33a:	f3 48 ab             	rep stos %rax,(%rdi)
    e33d:	48 89 d7             	mov    %rdx,%rdi
    e340:	e8 4b 74 ff ff       	call   5790 <fwp_mem_free>
    e345:	48 8b 3d d4 4c 00 00 	mov    0x4cd4(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e34c:	48 c7 05 49 54 01 00 	movq   $0x0,0x15449(%rip)        # 237a0 <fwp_cur>
    e353:	00 00 00 00 
    e357:	48 c7 05 36 54 01 00 	movq   $0x0,0x15436(%rip)        # 23798 <fwp_root>
    e35e:	00 00 00 00 
    e362:	e8 59 52 ff ff       	call   35c0 <fflush@plt>
    e367:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e36e:	00 
    e36f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e376:	00 00 
    e378:	0f 85 fb 00 00 00    	jne    e479 <fwp_main_thread+0x729>
    e37e:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e385:	31 c0                	xor    %eax,%eax
    e387:	5b                   	pop    %rbx
    e388:	5d                   	pop    %rbp
    e389:	41 5c                	pop    %r12
    e38b:	c3                   	ret
    e38c:	0f 1f 40 00          	nopl   0x0(%rax)
    e390:	48 89 05 e1 53 01 00 	mov    %rax,0x153e1(%rip)        # 23778 <fwp_timers>
    e397:	e9 ff fb ff ff       	jmp    df9b <fwp_main_thread+0x24b>
    e39c:	0f 1f 40 00          	nopl   0x0(%rax)
    e3a0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e3a4:	0f 85 66 fd ff ff    	jne    e110 <fwp_main_thread+0x3c0>
    e3aa:	48 89 ef             	mov    %rbp,%rdi
    e3ad:	e8 4e 5f ff ff       	call   4300 <fwp_cancel_tree.part.0>
    e3b2:	e9 59 fd ff ff       	jmp    e110 <fwp_main_thread+0x3c0>
    e3b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e3be:	00 00 
    e3c0:	48 8d 3d 49 5a ff ff 	lea    -0xa5b7(%rip),%rdi        # 3e10 <descent_phase_report>
    e3c7:	e8 d4 02 00 00       	call   e6a0 <atexit>
    e3cc:	85 c0                	test   %eax,%eax
    e3ce:	0f 85 98 00 00 00    	jne    e46c <fwp_main_thread+0x71c>
    e3d4:	c7 05 1a 4d 01 00 01 	movl   $0x1,0x14d1a(%rip)        # 230f8 <descent_registered>
    e3db:	00 00 00 
    e3de:	8b 05 8c 4c 00 00    	mov    0x4c8c(%rip),%eax        # 13070 <st.3>
    e3e4:	85 c0                	test   %eax,%eax
    e3e6:	0f 85 70 fa ff ff    	jne    de5c <fwp_main_thread+0x10c>
    e3ec:	e8 5f cc ff ff       	call   b050 <f0>
    e3f1:	48 c7 05 6c 4c 00 00 	movq   $0x0,0x4c6c(%rip)        # 13068 <v.2>
    e3f8:	00 00 00 00 
    e3fc:	c7 05 6a 4c 00 00 01 	movl   $0x1,0x4c6a(%rip)        # 13070 <st.3>
    e403:	00 00 00 
    e406:	e9 51 fa ff ff       	jmp    de5c <fwp_main_thread+0x10c>
    e40b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e410:	48 8d 3d 49 68 ff ff 	lea    -0x97b7(%rip),%rdi        # 4c60 <fwp_heap_report>
    e417:	e8 84 02 00 00       	call   e6a0 <atexit>
    e41c:	e9 6d f9 ff ff       	jmp    dd8e <fwp_main_thread+0x3e>
    e421:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    e428:	e8 43 69 ff ff       	call   4d70 <fwp_heap_init>
    e42d:	e9 4e f9 ff ff       	jmp    dd80 <fwp_main_thread+0x30>
    e432:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e438:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e43c:	e9 cf fa ff ff       	jmp    df10 <fwp_main_thread+0x1c0>
    e441:	48 83 3d 4f 53 01 00 	cmpq   $0x0,0x1534f(%rip)        # 23798 <fwp_root>
    e448:	00 
    e449:	c7 05 2d 4c 01 00 00 	movl   $0x0,0x14c2d(%rip)        # 23080 <fwp_exit_code>
    e450:	00 00 00 
    e453:	0f 84 ad fd ff ff    	je     e206 <fwp_main_thread+0x4b6>
    e459:	e9 f7 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e45e:	66 90                	xchg   %ax,%ax
    e460:	48 8d 3d 81 15 00 00 	lea    0x1581(%rip),%rdi        # f9e8 <_IO_stdin_used+0x9e8>
    e467:	e8 84 5f ff ff       	call   43f0 <fwp_trap>
    e46c:	e8 6f 59 ff ff       	call   3de0 <descent_phase_fail>
    e471:	48 89 c8             	mov    %rcx,%rax
    e474:	e9 d0 fc ff ff       	jmp    e149 <fwp_main_thread+0x3f9>
    e479:	e8 e2 4f ff ff       	call   3460 <__stack_chk_fail@plt>
    e47e:	e9 d2 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e483:	e9 cd 52 ff ff       	jmp    3755 <fwp_main_thread.cold>
    e488:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e48f:	00 

000000000000e490 <__divmodti4>:
    e490:	f3 0f 1e fa          	endbr64
    e494:	55                   	push   %rbp
    e495:	49 89 f1             	mov    %rsi,%r9
    e498:	49 89 d2             	mov    %rdx,%r10
    e49b:	48 89 fe             	mov    %rdi,%rsi
    e49e:	49 89 cb             	mov    %rcx,%r11
    e4a1:	48 89 e5             	mov    %rsp,%rbp
    e4a4:	41 57                	push   %r15
    e4a6:	41 56                	push   %r14
    e4a8:	41 55                	push   %r13
    e4aa:	41 54                	push   %r12
    e4ac:	53                   	push   %rbx
    e4ad:	4c 89 c3             	mov    %r8,%rbx
    e4b0:	45 31 c0             	xor    %r8d,%r8d
    e4b3:	4d 85 c9             	test   %r9,%r9
    e4b6:	79 12                	jns    e4ca <__divmodti4+0x3a>
    e4b8:	31 ff                	xor    %edi,%edi
    e4ba:	48 f7 de             	neg    %rsi
    e4bd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    e4c4:	4c 19 cf             	sbb    %r9,%rdi
    e4c7:	49 89 f9             	mov    %rdi,%r9
    e4ca:	4c 89 d8             	mov    %r11,%rax
    e4cd:	4d 85 db             	test   %r11,%r11
    e4d0:	0f 88 1a 01 00 00    	js     e5f0 <__divmodti4+0x160>
    e4d6:	4c 89 d9             	mov    %r11,%rcx
    e4d9:	49 89 f3             	mov    %rsi,%r11
    e4dc:	75 62                	jne    e540 <__divmodti4+0xb0>
    e4de:	4d 89 c4             	mov    %r8,%r12
    e4e1:	4d 39 d1             	cmp    %r10,%r9
    e4e4:	0f 83 46 01 00 00    	jae    e630 <__divmodti4+0x1a0>
    e4ea:	4c 89 d8             	mov    %r11,%rax
    e4ed:	4c 89 ca             	mov    %r9,%rdx
    e4f0:	49 f7 f2             	div    %r10
    e4f3:	49 89 c3             	mov    %rax,%r11
    e4f6:	31 c0                	xor    %eax,%eax
    e4f8:	48 89 d6             	mov    %rdx,%rsi
    e4fb:	31 ff                	xor    %edi,%edi
    e4fd:	4c 89 d9             	mov    %r11,%rcx
    e500:	48 89 c2             	mov    %rax,%rdx
    e503:	48 89 c8             	mov    %rcx,%rax
    e506:	4d 85 e4             	test   %r12,%r12
    e509:	74 0a                	je     e515 <__divmodti4+0x85>
    e50b:	48 f7 d8             	neg    %rax
    e50e:	48 83 d2 00          	adc    $0x0,%rdx
    e512:	48 f7 da             	neg    %rdx
    e515:	4d 85 c0             	test   %r8,%r8
    e518:	74 0a                	je     e524 <__divmodti4+0x94>
    e51a:	48 f7 de             	neg    %rsi
    e51d:	48 83 d7 00          	adc    $0x0,%rdi
    e521:	48 f7 df             	neg    %rdi
    e524:	48 89 33             	mov    %rsi,(%rbx)
    e527:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    e52b:	5b                   	pop    %rbx
    e52c:	41 5c                	pop    %r12
    e52e:	41 5d                	pop    %r13
    e530:	41 5e                	pop    %r14
    e532:	41 5f                	pop    %r15
    e534:	5d                   	pop    %rbp
    e535:	c3                   	ret
    e536:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e53d:	00 00 00 
    e540:	4d 89 c4             	mov    %r8,%r12
    e543:	49 39 c1             	cmp    %rax,%r9
    e546:	0f 82 ce 00 00 00    	jb     e61a <__divmodti4+0x18a>
    e54c:	31 ff                	xor    %edi,%edi
    e54e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    e553:	48 63 c7             	movslq %edi,%rax
    e556:	be 40 00 00 00       	mov    $0x40,%esi
    e55b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    e560:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    e565:	48 29 c6             	sub    %rax,%rsi
    e568:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    e56d:	48 09 c8             	or     %rcx,%rax
    e570:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    e575:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    e57a:	49 89 c6             	mov    %rax,%r14
    e57d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    e581:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    e586:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    e58b:	49 09 c1             	or     %rax,%r9
    e58e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    e592:	4c 89 c8             	mov    %r9,%rax
    e595:	49 f7 f6             	div    %r14
    e598:	48 89 d1             	mov    %rdx,%rcx
    e59b:	49 89 c3             	mov    %rax,%r11
    e59e:	49 89 c1             	mov    %rax,%r9
    e5a1:	49 f7 e2             	mul    %r10
    e5a4:	49 89 c6             	mov    %rax,%r14
    e5a7:	49 89 d2             	mov    %rdx,%r10
    e5aa:	48 39 d1             	cmp    %rdx,%rcx
    e5ad:	72 07                	jb     e5b6 <__divmodti4+0x126>
    e5af:	75 17                	jne    e5c8 <__divmodti4+0x138>
    e5b1:	49 39 c7             	cmp    %rax,%r15
    e5b4:	73 12                	jae    e5c8 <__divmodti4+0x138>
    e5b6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    e5ba:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    e5be:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    e5c2:	49 89 d2             	mov    %rdx,%r10
    e5c5:	49 89 c6             	mov    %rax,%r14
    e5c8:	4c 89 f8             	mov    %r15,%rax
    e5cb:	4c 29 f0             	sub    %r14,%rax
    e5ce:	4c 19 d1             	sbb    %r10,%rcx
    e5d1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    e5d6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    e5db:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    e5e0:	48 09 c6             	or     %rax,%rsi
    e5e3:	48 89 cf             	mov    %rcx,%rdi
    e5e6:	31 c0                	xor    %eax,%eax
    e5e8:	4c 89 c9             	mov    %r9,%rcx
    e5eb:	e9 10 ff ff ff       	jmp    e500 <__divmodti4+0x70>
    e5f0:	4c 89 d0             	mov    %r10,%rax
    e5f3:	4c 89 da             	mov    %r11,%rdx
    e5f6:	4d 89 c4             	mov    %r8,%r12
    e5f9:	49 89 f3             	mov    %rsi,%r11
    e5fc:	48 f7 d8             	neg    %rax
    e5ff:	49 f7 d4             	not    %r12
    e602:	48 83 d2 00          	adc    $0x0,%rdx
    e606:	49 89 c2             	mov    %rax,%r10
    e609:	48 f7 da             	neg    %rdx
    e60c:	48 89 d1             	mov    %rdx,%rcx
    e60f:	0f 84 cc fe ff ff    	je     e4e1 <__divmodti4+0x51>
    e615:	49 39 d1             	cmp    %rdx,%r9
    e618:	73 46                	jae    e660 <__divmodti4+0x1d0>
    e61a:	4c 89 cf             	mov    %r9,%rdi
    e61d:	31 c0                	xor    %eax,%eax
    e61f:	31 c9                	xor    %ecx,%ecx
    e621:	e9 da fe ff ff       	jmp    e500 <__divmodti4+0x70>
    e626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e62d:	00 00 00 
    e630:	4d 85 d2             	test   %r10,%r10
    e633:	75 0d                	jne    e642 <__divmodti4+0x1b2>
    e635:	b8 01 00 00 00       	mov    $0x1,%eax
    e63a:	31 d2                	xor    %edx,%edx
    e63c:	49 f7 f2             	div    %r10
    e63f:	49 89 c2             	mov    %rax,%r10
    e642:	4c 89 c8             	mov    %r9,%rax
    e645:	31 d2                	xor    %edx,%edx
    e647:	49 f7 f2             	div    %r10
    e64a:	49 89 c1             	mov    %rax,%r9
    e64d:	4c 89 d8             	mov    %r11,%rax
    e650:	49 f7 f2             	div    %r10
    e653:	49 89 c3             	mov    %rax,%r11
    e656:	4c 89 c8             	mov    %r9,%rax
    e659:	e9 9a fe ff ff       	jmp    e4f8 <__divmodti4+0x68>
    e65e:	66 90                	xchg   %ax,%ax
    e660:	45 31 f6             	xor    %r14d,%r14d
    e663:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    e668:	44 89 f7             	mov    %r14d,%edi
    e66b:	45 85 f6             	test   %r14d,%r14d
    e66e:	0f 85 df fe ff ff    	jne    e553 <__divmodti4+0xc3>
    e674:	4c 39 ca             	cmp    %r9,%rdx
    e677:	72 17                	jb     e690 <__divmodti4+0x200>
    e679:	31 c9                	xor    %ecx,%ecx
    e67b:	48 39 c6             	cmp    %rax,%rsi
    e67e:	73 10                	jae    e690 <__divmodti4+0x200>
    e680:	4c 89 cf             	mov    %r9,%rdi
    e683:	31 c0                	xor    %eax,%eax
    e685:	e9 76 fe ff ff       	jmp    e500 <__divmodti4+0x70>
    e68a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    e690:	4c 89 de             	mov    %r11,%rsi
    e693:	b9 01 00 00 00       	mov    $0x1,%ecx
    e698:	48 29 c6             	sub    %rax,%rsi
    e69b:	49 19 d1             	sbb    %rdx,%r9
    e69e:	eb e0                	jmp    e680 <__divmodti4+0x1f0>

000000000000e6a0 <atexit>:
    e6a0:	f3 0f 1e fa          	endbr64
    e6a4:	48 8b 15 5d 49 00 00 	mov    0x495d(%rip),%rdx        # 13008 <__dso_handle>
    e6ab:	31 f6                	xor    %esi,%esi
    e6ad:	e9 ae 4f ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000e6b4 <_fini>:
    e6b4:	f3 0f 1e fa          	endbr64
    e6b8:	48 83 ec 08          	sub    $0x8,%rsp
    e6bc:	48 83 c4 08          	add    $0x8,%rsp
    e6c0:	c3                   	ret
