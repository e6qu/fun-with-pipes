
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/129-199/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 ff 00 00 	mov    0xffd1(%rip),%rax        # 12fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 fd 00 00    	push   0xfdf2(%rip)        # 12e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 fd 00 00    	jmp    *0xfdf4(%rip)        # 12e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 fc 00 00    	jmp    *0xfc66(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e fa 00 00    	jmp    *0xfa8e(%rip)        # 12e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 fa 00 00    	jmp    *0xfa86(%rip)        # 12e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e fa 00 00    	jmp    *0xfa7e(%rip)        # 12e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 fa 00 00    	jmp    *0xfa76(%rip)        # 12e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e fa 00 00    	jmp    *0xfa6e(%rip)        # 12e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 fa 00 00    	jmp    *0xfa66(%rip)        # 12e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e fa 00 00    	jmp    *0xfa5e(%rip)        # 12e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 fa 00 00    	jmp    *0xfa56(%rip)        # 12e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e fa 00 00    	jmp    *0xfa4e(%rip)        # 12e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 fa 00 00    	jmp    *0xfa46(%rip)        # 12e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e fa 00 00    	jmp    *0xfa3e(%rip)        # 12e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 fa 00 00    	jmp    *0xfa36(%rip)        # 12e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e fa 00 00    	jmp    *0xfa2e(%rip)        # 12e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 fa 00 00    	jmp    *0xfa26(%rip)        # 12e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e fa 00 00    	jmp    *0xfa1e(%rip)        # 12e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 fa 00 00    	jmp    *0xfa16(%rip)        # 12ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e fa 00 00    	jmp    *0xfa0e(%rip)        # 12ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 fa 00 00    	jmp    *0xfa06(%rip)        # 12eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe f9 00 00    	jmp    *0xf9fe(%rip)        # 12eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 f9 00 00    	jmp    *0xf9f6(%rip)        # 12ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee f9 00 00    	jmp    *0xf9ee(%rip)        # 12ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 f9 00 00    	jmp    *0xf9e6(%rip)        # 12ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de f9 00 00    	jmp    *0xf9de(%rip)        # 12ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 f9 00 00    	jmp    *0xf9d6(%rip)        # 12ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce f9 00 00    	jmp    *0xf9ce(%rip)        # 12ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 f9 00 00    	jmp    *0xf9c6(%rip)        # 12ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be f9 00 00    	jmp    *0xf9be(%rip)        # 12ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 f9 00 00    	jmp    *0xf9b6(%rip)        # 12f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae f9 00 00    	jmp    *0xf9ae(%rip)        # 12f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 f9 00 00    	jmp    *0xf9a6(%rip)        # 12f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e f9 00 00    	jmp    *0xf99e(%rip)        # 12f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 f9 00 00    	jmp    *0xf996(%rip)        # 12f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e f9 00 00    	jmp    *0xf98e(%rip)        # 12f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 f9 00 00    	jmp    *0xf986(%rip)        # 12f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e f9 00 00    	jmp    *0xf97e(%rip)        # 12f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 f9 00 00    	jmp    *0xf976(%rip)        # 12f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e f9 00 00    	jmp    *0xf96e(%rip)        # 12f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 f9 00 00    	jmp    *0xf966(%rip)        # 12f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e f9 00 00    	jmp    *0xf95e(%rip)        # 12f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 f9 00 00    	jmp    *0xf956(%rip)        # 12f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e f9 00 00    	jmp    *0xf94e(%rip)        # 12f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 f9 00 00    	jmp    *0xf946(%rip)        # 12f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e f9 00 00    	jmp    *0xf93e(%rip)        # 12f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 f9 00 00    	jmp    *0xf936(%rip)        # 12f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e f9 00 00    	jmp    *0xf92e(%rip)        # 12f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 f9 00 00    	jmp    *0xf926(%rip)        # 12f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e f9 00 00    	jmp    *0xf91e(%rip)        # 12f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 f9 00 00    	jmp    *0xf916(%rip)        # 12fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e f9 00 00    	jmp    *0xf90e(%rip)        # 12fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 f9 00 00    	jmp    *0xf906(%rip)        # 12fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe f8 00 00    	jmp    *0xf8fe(%rip)        # 12fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 f8 00 00    	jmp    *0xf8f6(%rip)        # 12fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee f8 00 00    	jmp    *0xf8ee(%rip)        # 12fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 b9 00 00 	lea    0xb9b8(%rip),%r9        # f0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 b9 00 00 	lea    0xb9b5(%rip),%r8        # f0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_hof0.constprop.0.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>
    3750:	e8 ab ff ff ff       	call   3700 <fwp_trap_overflow.constprop.0>

0000000000003755 <fwp_main_thread.cold>:
    3755:	e8 66 fc ff ff       	call   33c0 <abort@plt>

000000000000375a <main.cold>:
    375a:	e8 61 fc ff ff       	call   33c0 <abort@plt>
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 db 00 00 	lea    0xdba1(%rip),%rax        # 11320 <fwp_fn_table>
    377f:	48 89 05 f2 9c 06 00 	mov    %rax,0x69cf2(%rip)        # 6d478 <fwp_fns>
    3786:	48 8b 05 93 f8 00 00 	mov    0xf893(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 9c 06 00 	mov    %rax,0x69cec(%rip)        # 6d480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e bb 00 00 	lea    0xbb4e(%rip),%rdi        # f2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 f8 00 00 	mov    0xf818(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f aa 00 00 	lea    0xaa3f(%rip),%rdx        # e2a0 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 e0 fe ff ff    	jne    375a <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 c4 fe ff ff    	jne    375a <main.cold>
    3896:	48 8b 3d 83 f7 00 00 	mov    0xf783(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 f7 01 00    	mov    0x1f7d8(%rip),%eax        # 23080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe b9 00 00 	lea    0xb9fe(%rip),%rdi        # f2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 c3 00 00 	lea    0xc356(%rip),%rdi        # fc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 39 fe ff ff    	jne    375a <main.cold>
    3921:	48 8d 3d 10 c3 00 00 	lea    0xc310(%rip),%rdi        # fc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 c2 00 00 	lea    0xc2d4(%rip),%rdi        # fc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 c2 00 00 	lea    0xc2a0(%rip),%rdi        # fbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b f6 00 00    	call   *0xf65b(%rip)        # 12fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 f6 00 00 	lea    0xf699(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 f6 00 00 	lea    0xf692(%rip),%rax        # 13020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e f6 00 00 	mov    0xf63e(%rip),%rax        # 12fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 f6 00 00 	lea    0xf669(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 f6 00 00 	lea    0xf662(%rip),%rsi        # 13020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d f6 00 00 	mov    0xf60d(%rip),%rax        # 12fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d f6 00 00 00 	cmpb   $0x0,0xf64d(%rip)        # 13048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea f5 00 00 	cmpq   $0x0,0xf5ea(%rip)        # 12ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 f5 00 00 	mov    0xf5f6(%rip),%rdi        # 13008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 f6 00 00 01 	movb   $0x1,0xf625(%rip)        # 13048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 f5 04 00 	lea    0x4f597(%rip),%r8        # 531a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b f5 04 00 	lea    0x4f53b(%rip),%rcx        # 53160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f f5 04 00 	lea    0x4f50f(%rip),%rcx        # 53140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 f5 04 00 	lea    0x4f541(%rip),%rcx        # 53180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 f5 04 	movdqa 0x4f550(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 f5 04 	paddq  0x4f538(%rip),%xmm0        # 531a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f f4 04 00 	cmp    %rax,0x4f49f(%rip)        # 53120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 f4 04 	movq   %xmm0,0x4f495(%rip)        # 53120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e f4 01 00 	add    0x1f43e(%rip),%rdx        # 230f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c f4 01 00 	add    0x1f42c(%rip),%rax        # 230f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 97 06 00 	mov    0x69779(%rip),%rdi        # 6d480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 f3 00 00 	mov    0xf304(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 f2 00 00 	mov    0xf2f1(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 7a 06 00 	mov    0x67ab1(%rip),%rax        # 6b800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 73 06 00 	mov    0x673f9(%rip),%rax        # 6b1c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 73 06 00 	sub    0x673e5(%rip),%rax        # 6b1c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d bf 00 00 	lea    0xbf2d(%rip),%rsi        # fd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 b1 00 00 	lea    0xb1c5(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 f1 00 00 	mov    0xf1f2(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 8d 06 00 	mov    0x68d8b(%rip),%rax        # 6cc10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 8d 06 00 	lea    0x68d84(%rip),%r8        # 6cc10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 8d 06 00 	mov    0x68d65(%rip),%rbx        # 6cbf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 8d 06 00 	mov    0x68d75(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 8d 06 00 	mov    0x68d11(%rip),%rdi        # 6cc00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 8d 06 00 	sub    %rsi,0x68d5a(%rip)        # 6cc50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 8c 06 00 	mov    0x68cea(%rip),%rax        # 6cbf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 8c 06 00 	add    0x68ca0(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 8c 06 00 	mov    0x68cae(%rip),%rsi        # 6cc00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 8c 06 00 	mov    0x68cbc(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 8c 06 00 	mov    %r12,0x68c6b(%rip)        # 6cc00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 8c 06 00 	mov    %rbp,0x68c59(%rip)        # 6cbf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 8c 06 00 	cmp    %rdi,0x68c3e(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 8c 06 00 	mov    %rdi,0x68c35(%rip)        # 6cbe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 8c 06 00 	sub    %rdi,0x68c79(%rip)        # 6cc50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 8c 06 00 	mov    0x68c21(%rip),%rax        # 6cc08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 8c 06 00 	lea    0x68c1a(%rip),%r8        # 6cc08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff b6 00 00 	lea    0xb6ff(%rip),%rdx        # f708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 f0 00 00 	mov    0xf022(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d ef 00 00 	mov    0xef7d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 af 00 00 	lea    0xaf34(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 76 06 00 	cmp    0x676c9(%rip),%rdi        # 6b800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 76 06 00 	mov    0x6768f(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 76 06 00 	mov    %rdi,0x6766d(%rip)        # 6b7e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 76 06 00 	mov    %rdi,0x67649(%rip)        # 6b7e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 b0 00 00 	lea    0xb019(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 ae 00 00 	lea    0xae27(%rip),%rsi        # f01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 ef 04 	movdqa 0x4ef76(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e ef 04 	paddq  0x4ef5e(%rip),%xmm0        # 531a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ee 01 00 	mov    0x1ee84(%rip),%r8        # 230f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ee 04 00 	mov    0x4ee9e(%rip),%rcx        # 53120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 ed 00 00 	mov    0xedb7(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 b4 00 00 	lea    0xb4c5(%rip),%rdx        # f758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ee 04 00 	lea    0x4eee1(%rip),%r15        # 53180 <ad_raw_peak>
    429f:	4c 8d 35 9a ee 04 00 	lea    0x4ee9a(%rip),%r14        # 53140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 ad 00 00 	lea    0xad79(%rip),%rax        # f02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 e9 00 	movq   0xe956(%rip),%xmm0        # 12c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ee 04 00 	lea    0x4ee9f(%rip),%r13        # 53160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f ad 00 00 	lea    0xad6f(%rip),%rax        # f03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 e9 00 	movq   0xe936(%rip),%xmm0        # 12c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 ed 00 00 	mov    0xed33(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c ad 00 00 	lea    0xad0c(%rip),%rcx        # f020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d b4 00 00 	lea    0xb49d(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 ed 00 00 	mov    0xed04(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 ac 00 00 	lea    0xacf8(%rip),%rdi        # f045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 ed 01 00 	cmpq   $0x0,0x1eda6(%rip)        # 23100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd ed 01 00 	mov    0x1edbd(%rip),%r8        # 23120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be ed 01 00 	mov    0x1edbe(%rip),%r9        # 23128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af ed 01 00 	lea    0x1edaf(%rip),%rbx        # 23120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 ac 00 00 	lea    0xacf4(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 ed 01 00 	mov    0x1edb1(%rip),%rax        # 23130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a ac 00 00 	lea    0xac9a(%rip),%r12        # f020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 ec 00 00 	mov    0xec89(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 b4 00 00 	lea    0xb439(%rip),%rdx        # f7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 ed 01 00 	cmp    0x1ed33(%rip),%rbp        # 23100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 ec 00 00 	mov    0xec58(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b ac 00 00 	lea    0xac5b(%rip),%rdi        # f059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 ec 00 00 	mov    0xec23(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 b3 00 00 	lea    0xb394(%rip),%rdx        # f7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 ac 00 00 	lea    0xac40(%rip),%rcx        # f06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea b2 00 00 	lea    0xb2ea(%rip),%rdi        # f730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 eb 00 00 	mov    0xebc8(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df ab 00 00 	lea    0xabdf(%rip),%rdx        # f05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 eb 00 00 	mov    0xebb0(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ea 00 00 	mov    0xeac1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 aa 00 00 	lea    0xaa78(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 aa 00 00 	lea    0xaac0(%rip),%rdi        # f06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 aa 00 00 	lea    0xaa48(%rip),%rdi        # f087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 b1 00 00 	lea    0xb1e8(%rip),%rdi        # f838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 b7 00 	movdqa 0xb720(%rip),%xmm0        # fd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 8d 06 00 	add    0x68daa(%rip),%rax        # 6d478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c b1 00 00 	lea    0xb13c(%rip),%rdi        # f860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 e9 01 00 	cmp    %rax,0x1e9a5(%rip)        # 230e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 e9 01 00 	add    0x1e9a0(%rip),%rax        # 230f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 b1 00 00 	lea    0xb125(%rip),%rdi        # f890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 a9 00 00 	lea    0xa920(%rip),%r8        # f0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 a7 00 00 	lea    0xa775(%rip),%r8        # f0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 a6 00 00 	lea    0xa612(%rip),%r8        # f0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea a3 00 00 	lea    0xa3ea(%rip),%rdi        # f0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 a5 00 00 	lea    0xa554(%rip),%rsi        # f242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 7e 06 00 	mov    0x67e85(%rip),%r9        # 6cbe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 7e 06 00 	mov    0x67ede(%rip),%r8        # 6cc48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f ab 00 00 	lea    0xab6f(%rip),%rdx        # f8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 7e 06 00 	mov    0x67ec6(%rip),%rcx        # 6cc40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 7e 06 	movsd  0x67ed4(%rip),%xmm1        # 6cc60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 7e 06 	movsd  0x67ec4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 e2 00 00 	mov    0xe2a5(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 af 00 	movdqa 0xafc8(%rip),%xmm0        # fda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 79 06 00 	lea    0x6797f(%rip),%rax        # 6c760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 af 00 	movdqa 0xaff1(%rip),%xmm2        # fde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 79 06 00 	movaps %xmm0,0x67925(%rip)        # 6c720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad af 00 	movdqa 0xafad(%rip),%xmm0        # fdb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 7d 06 00 01 	movl   $0x1,0x67db3(%rip)        # 6cbc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 79 06 00 	movaps %xmm0,0x67913(%rip)        # 6c730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b af 00 	movdqa 0xaf9b(%rip),%xmm0        # fdc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 79 06 00 	movaps %xmm0,0x67914(%rip)        # 6c740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c af 00 	movdqa 0xaf9c(%rip),%xmm0        # fdd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 79 06 00 	movaps %xmm0,0x67915(%rip)        # 6c750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 69 06 00 	lea    0x66995(%rip),%r8        # 6b820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 7c 06 00 	mov    %rax,0x67cb0(%rip)        # 6cbd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 7c 06 00 	mov    %r12,0x67c8e(%rip)        # 6cbe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 7c 06 00 	mov    %rax,0x67c77(%rip)        # 6cbd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 7c 06 00 	mov    %rbx,0x67c90(%rip)        # 6cbf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 7c 06 00 	mov    %rsi,0x67cb9(%rip)        # 6cc20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 a1 00 00 	lea    0xa174(%rip),%rdi        # f0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 7c 06 00 	mov    %rax,0x67c98(%rip)        # 6cc18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 7c 06 00    	mov    %eax,0x67c1c(%rip)        # 6cbc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 68 06 00 	mov    0x6680c(%rip),%r8        # 6b7e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 67 06 00 	mov    %rbx,0x6673c(%rip)        # 6b7e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 67 06 00 	mov    %r8,0x66728(%rip)        # 6b7e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 e0 04 00 	lea    0x4e0e9(%rip),%rcx        # 531c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 e0 04 00 	lea    0x4e098(%rip),%rcx        # 531a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 9f 00 00 	lea    0x9fc2(%rip),%rdi        # f0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 3f             	mov    (%rdi),%rdi
    5147:	48 85 ff             	test   %rdi,%rdi
    514a:	74 05                	je     5151 <fwp_tape_buffers_dispose+0x11>
    514c:	e8 7f ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5151:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5155:	48 85 ff             	test   %rdi,%rdi
    5158:	74 05                	je     515f <fwp_tape_buffers_dispose+0x1f>
    515a:	e8 71 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    515f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5163:	48 85 ff             	test   %rdi,%rdi
    5166:	74 05                	je     516d <fwp_tape_buffers_dispose+0x2d>
    5168:	e8 63 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    516d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5171:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5178:	00 
    5179:	0f 11 03             	movups %xmm0,(%rbx)
    517c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5180:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5184:	5b                   	pop    %rbx
    5185:	c3                   	ret
    5186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    518d:	00 00 00 

0000000000005190 <ad_raw_realloc>:
    5190:	41 55                	push   %r13
    5192:	41 54                	push   %r12
    5194:	55                   	push   %rbp
    5195:	53                   	push   %rbx
    5196:	48 83 ec 08          	sub    $0x8,%rsp
    519a:	48 85 f6             	test   %rsi,%rsi
    519d:	0f 84 a6 00 00 00    	je     5249 <ad_raw_realloc+0xb9>
    51a3:	4c 8d 25 16 e0 04 00 	lea    0x4e016(%rip),%r12        # 531c0 <ad_raw_blocks>
    51aa:	48 89 f5             	mov    %rsi,%rbp
    51ad:	41 89 d5             	mov    %edx,%r13d
    51b0:	31 db                	xor    %ebx,%ebx
    51b2:	4c 89 e0             	mov    %r12,%rax
    51b5:	eb 1a                	jmp    51d1 <ad_raw_realloc+0x41>
    51b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    51be:	00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0x90>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x30>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x56>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xad>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x7c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 9e 00 00 	lea    0x9ee8(%rip),%rax        # f112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 9e 00 00 	lea    0x9ecc(%rip),%rdx        # f0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 9f 00 00 	lea    0x9f04(%rip),%rdi        # f148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 9e 00 00 	lea    0x9edd(%rip),%rdi        # f12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 9e 00 00 	lea    0x9eaa(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae dd 01 00 	lea    0x1ddae(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 dd 01 00 	movaps %xmm0,0x1dd96(%rip)        # 230a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 dd 01 00 	mov    %rsi,0x1dd72(%rip)        # 23088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 dd 01 00 	movaps %xmm0,0x1dd93(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 dd 01 00 	movaps %xmm0,0x1dd97(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 dd 01 00 	mov    %rax,0x1dd98(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 9e 00 00 	lea    0x9e09(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d dd 01 00 	mov    0x1dd1d(%rip),%rsi        # 23088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d dd 01 00 	imul   $0x68,0x1dd6d(%rip),%rdx        # 230e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 de 04 00 	cmp    0x4de26(%rip),%rdx        # 531a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 de 04 00 	mov    0x4de25(%rip),%rax        # 531a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f de 04 00 	add    0x4de1f(%rip),%rax        # 531b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 de 04 00 	add    0x4de20(%rip),%rax        # 531b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c dd 01 00 	mov    0x1dd5c(%rip),%rcx        # 23100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 dd 01 00 	mov    %rdi,0x1dd45(%rip)        # 23100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 dd 01 00 	lea    0x1dd57(%rip),%rcx        # 23120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 a5 00 00 	lea    0xa572(%rip),%rdi        # f968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 9d 00 00 	lea    0x9d6f(%rip),%rdi        # f171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 63 06 00 	mov    0x663a7(%rip),%rbx        # 6b7d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a db 00 00 	mov    0xdb0a(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b a4 00 00 	lea    0xa45b(%rip),%rdi        # f998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 62 06 00 	mov    0x6626d(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 62 06 00 	mov    %rdx,0x66247(%rip)        # 6b7e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 61 06 00 	mov    0x66194(%rip),%rbx        # 6b7d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 61 06 00 	mov    %rbx,0x66151(%rip)        # 6b7d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 61 06 00 	mov    %rdx,0x66151(%rip)        # 6b7e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 61 06 00 	lea    0x66166(%rip),%rsi        # 6b820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 7c 06 00 	addq   $0x1,0x67ce5(%rip)        # 6d468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f a2 00 00 	lea    0xa22f(%rip),%rdi        # f9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 a2 00 00 	lea    0xa240(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 99 00 00 	lea    0x99d2(%rip),%rdi        # f18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 60 06 00 	lea    0x6601e(%rip),%rcx        # 6b820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 7c 06 00 	subq   $0x1,0x67c1f(%rip)        # 6d468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b a1 00 00 	lea    0xa19b(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 7c 06 00 	cmpq   $0x0,0x67c00(%rip)        # 6d468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 7b 06 00 	sub    %rax,0x67b55(%rip)        # 6d470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 7b 06 00 	add    %r12,0x67b33(%rip)        # 6d470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 72 06 00 	mov    0x6728f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 5e 06 00 	lea    0x65e8c(%rip),%rax        # 6b820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 71 06 00 	add    0x671e3(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 71 06 00 	mov    0x671b0(%rip),%rsi        # 6cbd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 71 06 00 	mov    0x671d1(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 71 06 00 	add    0x671c5(%rip),%r8        # 6cc18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 71 06 	addsd  0x6718d(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 5d 06 00 	lea    0x65d42(%rip),%rax        # 6b820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 71 06 00 	sub    %rdi,0x6714c(%rip)        # 6cc40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 71 06 	movsd  %xmm0,0x67164(%rip)        # 6cc60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 71 06 00 	sub    %rdx,0x6711e(%rip)        # 6cc40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 71 06 	addsd  0x67124(%rip),%xmm0        # 6cc60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 71 06 	movsd  %xmm0,0x67118(%rip)        # 6cc60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 70 06 00 	mov    0x670af(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 70 06 00 	add    %rcx,0x670a9(%rip)        # 6cc50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 70 06 00 	cmp    0x67062(%rip),%r9        # 6cc10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 70 06 00 	mov    %r9,0x67059(%rip)        # 6cc10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 70 06 00 	cmp    0x6704a(%rip),%r9        # 6cc08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 70 06 00 	mov    %r9,0x6703d(%rip)        # 6cc08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 6f 06 00 	add    0x66f53(%rip),%rdi        # 6cc18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 5b 06 00 	lea    0x65b30(%rip),%r15        # 6b820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 6e 06 00 	add    0x66ea0(%rip),%r12        # 6cbd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 6e 06 00 	add    0x66ef9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 6e 06 00 	cmp    %rax,0x66ef8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 6e 06 00 	mov    %rax,0x66ee9(%rip)        # 6cc40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 6e 06 00 	mov    %rax,0x66ee8(%rip)        # 6cc48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 6e 06 	addsd  0x66ee4(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 6e 06 	movsd  %xmm0,0x66edc(%rip)        # 6cc58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 6e 06 00    	mov    0x66e23(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 5a 06 00 	lea    0x65a5f(%rip),%rdi        # 6b820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 6e 06 00 	add    0x66e18(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 6e 06 00 	cmp    %rax,0x66e13(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 6e 06 00 	mov    %rax,0x66e04(%rip)        # 6cc40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 6e 06 00 	mov    %rax,0x66e03(%rip)        # 6cc48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 6d 06 	addsd  0x66dff(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 6d 06 	movsd  %xmm0,0x66df7(%rip)        # 6cc58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 75 06 00    	mov    0x675ca(%rip),%ebx        # 6d4e8 <iteration_active>
    5f1e:	8b 05 a0 6c 06 00    	mov    0x66ca0(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 58 06 00 	lea    0x658d4(%rip),%rax        # 6b820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 6c 06 00 	add    0x66c8e(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 6c 06 00 	cmp    %rax,0x66c89(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 6c 06 00 	mov    %rax,0x66c7a(%rip)        # 6cc40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 6c 06 00 	mov    %rax,0x66c79(%rip)        # 6cc48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 6c 06 	addsd  0x66c78(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 6c 06 	movsd  %xmm0,0x66c70(%rip)        # 6cc58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 6c 06 00 	mov    0x66c4d(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 74 06 	subsd  0x674bb(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 74 06 	comisd 0x674ab(%rip),%xmm0        # 6d4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 74 06 	movsd  %xmm0,0x674a1(%rip)        # 6d4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 74 06 00 	addq   $0x1,0x674a4(%rip)        # 6d4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 74 06 00 	add    %rdi,0x67495(%rip)        # 6d4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 6a 06 00    	mov    0x66abc(%rip),%eax        # 6cbc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 73 06 00 	mov    0x673d4(%rip),%r13d        # 6d4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 73 06 00 	addq   $0x1,0x673b4(%rip)        # 6d4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 73 06 00 	addq   $0x18,0x673a4(%rip)        # 6d4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 66 06 00 	movzbl 0x6667f(%rip),%eax        # 6c7c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 56 06 00 	lea    0x656d6(%rip),%rdx        # 6b820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 6a 06 00 	add    0x66aa7(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 6a 06 00 	cmp    %rax,0x66aa2(%rip)        # 6cc48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 6a 06 00 	mov    %rax,0x66a93(%rip)        # 6cc40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 6a 06 00 	mov    %rax,0x66a92(%rip)        # 6cc48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 6a 06 	addsd  0x66a91(%rip),%xmm0        # 6cc58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 6a 06 	movsd  %xmm0,0x66a89(%rip)        # 6cc58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 6a 06 00 	mov    0x66a65(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 72 06 	subsd  0x672d3(%rip),%xmm0        # 6d4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 72 06 	comisd 0x672c3(%rip),%xmm0        # 6d4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 72 06 	movsd  %xmm0,0x672b9(%rip)        # 6d4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_tape_reserve>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	41 54                	push   %r12
    62f8:	55                   	push   %rbp
    62f9:	53                   	push   %rbx
    62fa:	48 83 ec 18          	sub    $0x18,%rsp
    62fe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6305:	0f 87 cd 01 00 00    	ja     64d8 <fwp_tape_reserve+0x1e8>
    630b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    630f:	48 89 fd             	mov    %rdi,%rbp
    6312:	48 39 f3             	cmp    %rsi,%rbx
    6315:	0f 8d 18 01 00 00    	jge    6433 <fwp_tape_reserve+0x143>
    631b:	48 85 db             	test   %rbx,%rbx
    631e:	b8 40 00 00 00       	mov    $0x40,%eax
    6323:	48 0f 44 d8          	cmove  %rax,%rbx
    6327:	48 39 f3             	cmp    %rsi,%rbx
    632a:	7d 24                	jge    6350 <fwp_tape_reserve+0x60>
    632c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6333:	0f 8f 0f 01 00 00    	jg     6448 <fwp_tape_reserve+0x158>
    6339:	48 01 db             	add    %rbx,%rbx
    633c:	48 39 f3             	cmp    %rsi,%rbx
    633f:	7c eb                	jl     632c <fwp_tape_reserve+0x3c>
    6341:	0f 1f 40 00          	nopl   0x0(%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 
    6350:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    6357:	00 
    6358:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    635c:	ba 01 00 00 00       	mov    $0x1,%edx
    6361:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    6365:	4c 89 ee             	mov    %r13,%rsi
    6368:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    636c:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6370:	e8 1b ee ff ff       	call   5190 <ad_raw_realloc>
    6375:	48 85 c0             	test   %rax,%rax
    6378:	0f 84 66 01 00 00    	je     64e4 <fwp_tape_reserve+0x1f4>
    637e:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    6382:	48 89 45 20          	mov    %rax,0x20(%rbp)
    6386:	4d 29 fc             	sub    %r15,%r12
    6389:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    638d:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    6391:	4d 85 f6             	test   %r14,%r14
    6394:	0f 84 f6 00 00 00    	je     6490 <fwp_tape_reserve+0x1a0>
    639a:	49 8b 56 60          	mov    0x60(%r14),%rdx
    639e:	48 39 da             	cmp    %rbx,%rdx
    63a1:	7d 78                	jge    641b <fwp_tape_reserve+0x12b>
    63a3:	48 89 d9             	mov    %rbx,%rcx
    63a6:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    63aa:	be 02 00 00 00       	mov    $0x2,%esi
    63af:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    63b4:	48 c1 e1 04          	shl    $0x4,%rcx
    63b8:	48 89 cf             	mov    %rcx,%rdi
    63bb:	48 89 0c 24          	mov    %rcx,(%rsp)
    63bf:	e8 4c fb ff ff       	call   5f10 <fwp_heap_alloc>
    63c4:	49 89 c5             	mov    %rax,%r13
    63c7:	4d 85 ff             	test   %r15,%r15
    63ca:	74 27                	je     63f3 <fwp_tape_reserve+0x103>
    63cc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    63d1:	48 8b 0c 24          	mov    (%rsp),%rcx
    63d5:	48 89 c7             	mov    %rax,%rdi
    63d8:	4c 89 fe             	mov    %r15,%rsi
    63db:	48 c1 e2 04          	shl    $0x4,%rdx
    63df:	48 39 ca             	cmp    %rcx,%rdx
    63e2:	48 0f 47 d1          	cmova  %rcx,%rdx
    63e6:	e8 95 d1 ff ff       	call   3580 <memcpy@plt>
    63eb:	4c 89 ff             	mov    %r15,%rdi
    63ee:	e8 1d f6 ff ff       	call   5a10 <fwp_mem_free>
    63f3:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    63f7:	48 89 da             	mov    %rbx,%rdx
    63fa:	31 f6                	xor    %esi,%esi
    63fc:	48 29 fa             	sub    %rdi,%rdx
    63ff:	48 c1 e7 04          	shl    $0x4,%rdi
    6403:	48 c1 e2 04          	shl    $0x4,%rdx
    6407:	4c 01 ef             	add    %r13,%rdi
    640a:	e8 a1 d0 ff ff       	call   34b0 <memset@plt>
    640f:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    6413:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6417:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    641b:	4d 85 e4             	test   %r12,%r12
    641e:	75 4b                	jne    646b <fwp_tape_reserve+0x17b>
    6420:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6427:	00 
    6428:	4c 01 e8             	add    %r13,%rax
    642b:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    642f:	48 89 45 28          	mov    %rax,0x28(%rbp)
    6433:	48 83 c4 18          	add    $0x18,%rsp
    6437:	5b                   	pop    %rbx
    6438:	5d                   	pop    %rbp
    6439:	41 5c                	pop    %r12
    643b:	41 5d                	pop    %r13
    643d:	41 5e                	pop    %r14
    643f:	41 5f                	pop    %r15
    6441:	c3                   	ret
    6442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6448:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    644d:	e9 fe fe ff ff       	jmp    6350 <fwp_tape_reserve+0x60>
    6452:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6459:	00 
    645a:	e8 91 d1 ff ff       	call   35f0 <memmove@plt>
    645f:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6463:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6467:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    646b:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    646f:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6476:	00 
    6477:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    647e:	00 
    647f:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6483:	e8 68 d1 ff ff       	call   35f0 <memmove@plt>
    6488:	48 8b 45 20          	mov    0x20(%rbp),%rax
    648c:	eb 9a                	jmp    6428 <fwp_tape_reserve+0x138>
    648e:	66 90                	xchg   %ax,%ax
    6490:	48 89 de             	mov    %rbx,%rsi
    6493:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6497:	ba 02 00 00 00       	mov    $0x2,%edx
    649c:	48 c1 e6 04          	shl    $0x4,%rsi
    64a0:	e8 eb ec ff ff       	call   5190 <ad_raw_realloc>
    64a5:	48 85 c0             	test   %rax,%rax
    64a8:	74 3a                	je     64e4 <fwp_tape_reserve+0x1f4>
    64aa:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    64ae:	48 89 45 30          	mov    %rax,0x30(%rbp)
    64b2:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    64b6:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64ba:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    64be:	4d 85 e4             	test   %r12,%r12
    64c1:	75 8f                	jne    6452 <fwp_tape_reserve+0x162>
    64c3:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    64c7:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64cb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    64d2:	00 
    64d3:	e9 50 ff ff ff       	jmp    6428 <fwp_tape_reserve+0x138>
    64d8:	48 8d 3d c8 8c 00 00 	lea    0x8cc8(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    64df:	e8 6c df ff ff       	call   4450 <fwp_trap>
    64e4:	48 89 ef             	mov    %rbp,%rdi
    64e7:	e8 a4 d7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    64ec:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    64f0:	48 85 ff             	test   %rdi,%rdi
    64f3:	74 05                	je     64fa <fwp_tape_reserve+0x20a>
    64f5:	e8 d6 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    64fa:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    64fe:	48 85 ff             	test   %rdi,%rdi
    6501:	74 05                	je     6508 <fwp_tape_reserve+0x218>
    6503:	e8 c8 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6508:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    650c:	48 85 ff             	test   %rdi,%rdi
    650f:	74 05                	je     6516 <fwp_tape_reserve+0x226>
    6511:	e8 ba eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6516:	31 c9                	xor    %ecx,%ecx
    6518:	31 c0                	xor    %eax,%eax
    651a:	31 d2                	xor    %edx,%edx
    651c:	be 01 00 00 00       	mov    $0x1,%esi
    6521:	89 55 04             	mov    %edx,0x4(%rbp)
    6524:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6528:	ba 13 00 00 00       	mov    $0x13,%edx
    652d:	48 8d 3d d4 8a 00 00 	lea    0x8ad4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    6534:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6538:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    653c:	48 8b 0d fd ca 00 00 	mov    0xcafd(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    6543:	48 89 45 40          	mov    %rax,0x40(%rbp)
    6547:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    654b:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    654f:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6553:	e8 08 d1 ff ff       	call   3660 <fwrite@plt>
    6558:	31 ff                	xor    %edi,%edi
    655a:	e8 41 d0 ff ff       	call   35a0 <fflush@plt>
    655f:	bf 66 00 00 00       	mov    $0x66,%edi
    6564:	e8 17 d1 ff ff       	call   3680 <_Exit@plt>
    6569:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006570 <f141.constprop.0>:
    6570:	41 57                	push   %r15
    6572:	41 56                	push   %r14
    6574:	41 55                	push   %r13
    6576:	41 54                	push   %r12
    6578:	49 89 f4             	mov    %rsi,%r12
    657b:	55                   	push   %rbp
    657c:	48 89 fd             	mov    %rdi,%rbp
    657f:	53                   	push   %rbx
    6580:	48 83 ec 08          	sub    $0x8,%rsp
    6584:	48 85 ff             	test   %rdi,%rdi
    6587:	79 09                	jns    6592 <f141.constprop.0+0x22>
    6589:	48 85 f6             	test   %rsi,%rsi
    658c:	0f 88 fe 00 00 00    	js     6690 <f141.constprop.0+0x120>
    6592:	48 89 f8             	mov    %rdi,%rax
    6595:	48 09 f0             	or     %rsi,%rax
    6598:	0f 89 d2 00 00 00    	jns    6670 <f141.constprop.0+0x100>
    659e:	48 89 f8             	mov    %rdi,%rax
    65a1:	48 c1 f8 20          	sar    $0x20,%rax
    65a5:	48 85 ff             	test   %rdi,%rdi
    65a8:	0f 88 02 01 00 00    	js     66b0 <f141.constprop.0+0x140>
    65ae:	4c 8b 3d b3 97 00 00 	mov    0x97b3(%rip),%r15        # fd68 <msg.4+0x28>
    65b5:	48 89 c7             	mov    %rax,%rdi
    65b8:	e8 73 e1 ff ff       	call   4730 <fwp_tape_of>
    65bd:	48 89 c3             	mov    %rax,%rbx
    65c0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65c5:	0f 85 16 01 00 00    	jne    66e1 <f141.constprop.0+0x171>
    65cb:	4c 8b 68 10          	mov    0x10(%rax),%r13
    65cf:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    65d6:	0f 8f f9 00 00 00    	jg     66d5 <f141.constprop.0+0x165>
    65dc:	89 e8                	mov    %ebp,%eax
    65de:	49 39 c5             	cmp    %rax,%r13
    65e1:	0f 8e e2 00 00 00    	jle    66c9 <f141.constprop.0+0x159>
    65e7:	4d 85 e4             	test   %r12,%r12
    65ea:	78 0c                	js     65f8 <f141.constprop.0+0x88>
    65ec:	44 89 e0             	mov    %r12d,%eax
    65ef:	49 39 c5             	cmp    %rax,%r13
    65f2:	0f 8e d1 00 00 00    	jle    66c9 <f141.constprop.0+0x159>
    65f8:	4d 89 ee             	mov    %r13,%r14
    65fb:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    65ff:	48 89 df             	mov    %rbx,%rdi
    6602:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6606:	e8 e5 fc ff ff       	call   62f0 <fwp_tape_reserve>
    660b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    660f:	4d 85 e4             	test   %r12,%r12
    6612:	48 8b 0d 4f 97 00 00 	mov    0x974f(%rip),%rcx        # fd68 <msg.4+0x28>
    6619:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6620:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6624:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6628:	4c 0f 48 e2          	cmovs  %rdx,%r12
    662c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6630:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6634:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6638:	48 8b 43 38          	mov    0x38(%rbx),%rax
    663c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6640:	49 8d 45 01          	lea    0x1(%r13),%rax
    6644:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6648:	48 83 c4 08          	add    $0x8,%rsp
    664c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6653:	ff ff ff 
    6656:	48 21 e8             	and    %rbp,%rax
    6659:	5b                   	pop    %rbx
    665a:	5d                   	pop    %rbp
    665b:	4c 09 e8             	or     %r13,%rax
    665e:	41 5c                	pop    %r12
    6660:	41 5d                	pop    %r13
    6662:	41 5e                	pop    %r14
    6664:	41 5f                	pop    %r15
    6666:	c3                   	ret
    6667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    666e:	00 00 
    6670:	48 89 f0             	mov    %rsi,%rax
    6673:	48 c1 ff 20          	sar    $0x20,%rdi
    6677:	48 c1 f8 20          	sar    $0x20,%rax
    667b:	48 39 c7             	cmp    %rax,%rdi
    667e:	0f 84 2a ff ff ff    	je     65ae <f141.constprop.0+0x3e>
    6684:	48 8d 3d 8d 93 00 00 	lea    0x938d(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    668b:	e8 c0 dd ff ff       	call   4450 <fwp_trap>
    6690:	48 83 c4 08          	add    $0x8,%rsp
    6694:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    669b:	5b                   	pop    %rbx
    669c:	5d                   	pop    %rbp
    669d:	41 5c                	pop    %r12
    669f:	41 5d                	pop    %r13
    66a1:	41 5e                	pop    %r14
    66a3:	41 5f                	pop    %r15
    66a5:	c3                   	ret
    66a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66ad:	00 00 00 
    66b0:	48 89 f0             	mov    %rsi,%rax
    66b3:	48 89 f5             	mov    %rsi,%rbp
    66b6:	45 31 ff             	xor    %r15d,%r15d
    66b9:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    66c0:	48 c1 f8 20          	sar    $0x20,%rax
    66c4:	e9 ec fe ff ff       	jmp    65b5 <f141.constprop.0+0x45>
    66c9:	48 8d 3d f2 8a 00 00 	lea    0x8af2(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    66d0:	e8 7b dd ff ff       	call   4450 <fwp_trap>
    66d5:	48 8d 3d cb 8a 00 00 	lea    0x8acb(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    66dc:	e8 6f dd ff ff       	call   4450 <fwp_trap>
    66e1:	48 8d 3d 78 93 00 00 	lea    0x9378(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    66e8:	e8 63 dd ff ff       	call   4450 <fwp_trap>
    66ed:	0f 1f 00             	nopl   (%rax)

00000000000066f0 <w120>:
    66f0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    66f4:	41 57                	push   %r15
    66f6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    66fa:	41 56                	push   %r14
    66fc:	41 55                	push   %r13
    66fe:	41 54                	push   %r12
    6700:	49 89 f4             	mov    %rsi,%r12
    6703:	55                   	push   %rbp
    6704:	48 89 fd             	mov    %rdi,%rbp
    6707:	53                   	push   %rbx
    6708:	48 83 ec 38          	sub    $0x38,%rsp
    670c:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6711:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6717:	48 85 ff             	test   %rdi,%rdi
    671a:	0f 88 d0 04 00 00    	js     6bf0 <w120+0x500>
    6720:	49 89 ff             	mov    %rdi,%r15
    6723:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6729:	49 c1 ff 20          	sar    $0x20,%r15
    672d:	4c 89 ff             	mov    %r15,%rdi
    6730:	e8 fb df ff ff       	call   4730 <fwp_tape_of>
    6735:	48 89 c3             	mov    %rax,%rbx
    6738:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    673d:	0f 85 45 05 00 00    	jne    6c88 <w120+0x598>
    6743:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6747:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    674e:	0f 8f 28 05 00 00    	jg     6c7c <w120+0x58c>
    6754:	89 e8                	mov    %ebp,%eax
    6756:	49 39 c5             	cmp    %rax,%r13
    6759:	0f 8e 11 05 00 00    	jle    6c70 <w120+0x580>
    675f:	4d 89 ee             	mov    %r13,%r14
    6762:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6766:	48 89 df             	mov    %rbx,%rdi
    6769:	49 8d 76 01          	lea    0x1(%r14),%rsi
    676d:	e8 7e fb ff ff       	call   62f0 <fwp_tape_reserve>
    6772:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6776:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    677b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6781:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6785:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6789:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    678f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6793:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6797:	48 8b 43 38          	mov    0x38(%rbx),%rax
    679b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    67a1:	49 8d 45 01          	lea    0x1(%r13),%rax
    67a5:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    67ac:	ff ff ff 
    67af:	49 21 ee             	and    %rbp,%r14
    67b2:	48 89 43 10          	mov    %rax,0x10(%rbx)
    67b6:	4d 09 ee             	or     %r13,%r14
    67b9:	4d 89 f5             	mov    %r14,%r13
    67bc:	49 c1 fd 20          	sar    $0x20,%r13
    67c0:	4d 85 e4             	test   %r12,%r12
    67c3:	78 10                	js     67d5 <w120+0xe5>
    67c5:	4c 89 e0             	mov    %r12,%rax
    67c8:	48 c1 f8 20          	sar    $0x20,%rax
    67cc:	4c 39 e8             	cmp    %r13,%rax
    67cf:	0f 85 87 04 00 00    	jne    6c5c <w120+0x56c>
    67d5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    67db:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67e1:	4d 39 ef             	cmp    %r13,%r15
    67e4:	0f 84 d6 03 00 00    	je     6bc0 <w120+0x4d0>
    67ea:	f2 0f 10 1d 76 95 00 	movsd  0x9576(%rip),%xmm3        # fd68 <msg.4+0x28>
    67f1:	00 
    67f2:	f2 0f 10 25 76 95 00 	movsd  0x9576(%rip),%xmm4        # fd70 <msg.4+0x30>
    67f9:	00 
    67fa:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    6800:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    6806:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    680c:	4c 89 ef             	mov    %r13,%rdi
    680f:	e8 1c df ff ff       	call   4730 <fwp_tape_of>
    6814:	48 89 c3             	mov    %rax,%rbx
    6817:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    681c:	0f 85 66 04 00 00    	jne    6c88 <w120+0x598>
    6822:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6826:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    682d:	0f 8f 49 04 00 00    	jg     6c7c <w120+0x58c>
    6833:	44 89 f0             	mov    %r14d,%eax
    6836:	49 39 c7             	cmp    %rax,%r15
    6839:	0f 8e 31 04 00 00    	jle    6c70 <w120+0x580>
    683f:	4d 85 e4             	test   %r12,%r12
    6842:	78 0c                	js     6850 <w120+0x160>
    6844:	44 89 e0             	mov    %r12d,%eax
    6847:	49 39 c7             	cmp    %rax,%r15
    684a:	0f 8e 20 04 00 00    	jle    6c70 <w120+0x580>
    6850:	4c 89 f9             	mov    %r15,%rcx
    6853:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6857:	48 89 df             	mov    %rbx,%rdi
    685a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    685e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6863:	e8 88 fa ff ff       	call   62f0 <fwp_tape_reserve>
    6868:	48 8b 43 20          	mov    0x20(%rbx),%rax
    686c:	4d 85 e4             	test   %r12,%r12
    686f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6873:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6878:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    687e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6884:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6888:	48 8b 43 30          	mov    0x30(%rbx),%rax
    688c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6891:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6898:	49 0f 49 c4          	cmovns %r12,%rax
    689c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    68a0:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    68a3:	48 8b 43 38          	mov    0x38(%rbx),%rax
    68a7:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    68ac:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    68b0:	48 85 ed             	test   %rbp,%rbp
    68b3:	0f 88 0e 04 00 00    	js     6cc7 <w120+0x5d7>
    68b9:	48 89 e8             	mov    %rbp,%rax
    68bc:	48 c1 f8 20          	sar    $0x20,%rax
    68c0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    68c5:	49 39 c5             	cmp    %rax,%r13
    68c8:	74 1a                	je     68e4 <w120+0x1f4>
    68ca:	48 89 c7             	mov    %rax,%rdi
    68cd:	e8 5e de ff ff       	call   4730 <fwp_tape_of>
    68d2:	48 89 c3             	mov    %rax,%rbx
    68d5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    68da:	0f 85 a8 03 00 00    	jne    6c88 <w120+0x598>
    68e0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    68e4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    68eb:	0f 8f 8b 03 00 00    	jg     6c7c <w120+0x58c>
    68f1:	89 e8                	mov    %ebp,%eax
    68f3:	4c 39 e0             	cmp    %r12,%rax
    68f6:	0f 8d 74 03 00 00    	jge    6c70 <w120+0x580>
    68fc:	4c 89 e0             	mov    %r12,%rax
    68ff:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6903:	48 89 df             	mov    %rbx,%rdi
    6906:	48 8d 70 01          	lea    0x1(%rax),%rsi
    690a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    690f:	e8 dc f9 ff ff       	call   62f0 <fwp_tape_reserve>
    6914:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6919:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    691d:	48 8b 0d 4c 94 00 00 	mov    0x944c(%rip),%rcx        # fd70 <msg.4+0x30>
    6924:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    692a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    692d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6931:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6935:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    693b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    693f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6943:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6947:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    694e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6952:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6957:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    695c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6960:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6967:	ff ff ff 
    696a:	48 21 c5             	and    %rax,%rbp
    696d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6973:	4c 09 e5             	or     %r12,%rbp
    6976:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    697d:	ff ff ff 
    6980:	49 21 c6             	and    %rax,%r14
    6983:	4d 09 fe             	or     %r15,%r14
    6986:	4d 89 f4             	mov    %r14,%r12
    6989:	49 c1 fc 20          	sar    $0x20,%r12
    698d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6992:	74 16                	je     69aa <w120+0x2ba>
    6994:	4c 89 e7             	mov    %r12,%rdi
    6997:	e8 94 dd ff ff       	call   4730 <fwp_tape_of>
    699c:	48 89 c3             	mov    %rax,%rbx
    699f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    69a4:	0f 85 de 02 00 00    	jne    6c88 <w120+0x598>
    69aa:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    69ae:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    69b5:	0f 8f c1 02 00 00    	jg     6c7c <w120+0x58c>
    69bb:	44 89 f0             	mov    %r14d,%eax
    69be:	49 39 c7             	cmp    %rax,%r15
    69c1:	0f 8e a9 02 00 00    	jle    6c70 <w120+0x580>
    69c7:	4d 89 fd             	mov    %r15,%r13
    69ca:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    69ce:	48 89 df             	mov    %rbx,%rdi
    69d1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    69d5:	e8 16 f9 ff ff       	call   62f0 <fwp_tape_reserve>
    69da:	48 8b 43 20          	mov    0x20(%rbx),%rax
    69de:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    69e4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69e8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    69ec:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    69f2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    69f6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69fa:	48 8b 43 38          	mov    0x38(%rbx),%rax
    69fe:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a04:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    6a08:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a0f:	ff ff ff 
    6a12:	49 21 c6             	and    %rax,%r14
    6a15:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6a19:	4d 09 fe             	or     %r15,%r14
    6a1c:	4d 89 f7             	mov    %r14,%r15
    6a1f:	49 c1 ff 20          	sar    $0x20,%r15
    6a23:	4d 39 e7             	cmp    %r12,%r15
    6a26:	74 1d                	je     6a45 <w120+0x355>
    6a28:	4c 89 ff             	mov    %r15,%rdi
    6a2b:	e8 00 dd ff ff       	call   4730 <fwp_tape_of>
    6a30:	48 89 c3             	mov    %rax,%rbx
    6a33:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a38:	0f 85 4a 02 00 00    	jne    6c88 <w120+0x598>
    6a3e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6a42:	4d 89 fc             	mov    %r15,%r12
    6a45:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6a4c:	0f 8f 2a 02 00 00    	jg     6c7c <w120+0x58c>
    6a52:	44 89 f0             	mov    %r14d,%eax
    6a55:	4c 39 e8             	cmp    %r13,%rax
    6a58:	0f 8d 12 02 00 00    	jge    6c70 <w120+0x580>
    6a5e:	f2 0f 10 3d 12 93 00 	movsd  0x9312(%rip),%xmm7        # fd78 <msg.4+0x38>
    6a65:	00 
    6a66:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    6a6c:	4d 89 ef             	mov    %r13,%r15
    6a6f:	48 89 df             	mov    %rbx,%rdi
    6a72:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6a78:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    6a7d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6a81:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6a85:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    6a8a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6a90:	e8 5b f8 ff ff       	call   62f0 <fwp_tape_reserve>
    6a95:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6a99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6a9e:	48 8b 15 d3 92 00 00 	mov    0x92d3(%rip),%rdx        # fd78 <msg.4+0x38>
    6aa5:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6aa9:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6aad:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6ab1:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6ab5:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6ab9:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6abd:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6ac4:	ff 
    6ac5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6ac9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6ad0:	00 
    6ad1:	49 8d 45 01          	lea    0x1(%r13),%rax
    6ad5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6ad9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6ae0:	ff ff ff 
    6ae3:	49 21 c6             	and    %rax,%r14
    6ae6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    6aec:	4d 09 ee             	or     %r13,%r14
    6aef:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6af3:	0f 84 57 01 00 00    	je     6c50 <w120+0x560>
    6af9:	48 89 ef             	mov    %rbp,%rdi
    6afc:	48 c1 ff 20          	sar    $0x20,%rdi
    6b00:	4c 39 e7             	cmp    %r12,%rdi
    6b03:	74 13                	je     6b18 <w120+0x428>
    6b05:	e8 26 dc ff ff       	call   4730 <fwp_tape_of>
    6b0a:	48 89 c3             	mov    %rax,%rbx
    6b0d:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6b12:	0f 85 70 01 00 00    	jne    6c88 <w120+0x598>
    6b18:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6b1c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6b23:	0f 8f 53 01 00 00    	jg     6c7c <w120+0x58c>
    6b29:	89 e8                	mov    %ebp,%eax
    6b2b:	4c 39 e0             	cmp    %r12,%rax
    6b2e:	0f 8d 3c 01 00 00    	jge    6c70 <w120+0x580>
    6b34:	4d 89 e5             	mov    %r12,%r13
    6b37:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6b3b:	48 89 df             	mov    %rbx,%rdi
    6b3e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6b42:	e8 a9 f7 ff ff       	call   62f0 <fwp_tape_reserve>
    6b47:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6b4b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6b50:	48 89 ef             	mov    %rbp,%rdi
    6b53:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b57:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6b5b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b61:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6b65:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b69:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6b6d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b73:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6b78:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6b7c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6b83:	ff ff ff 
    6b86:	48 21 c7             	and    %rax,%rdi
    6b89:	4c 09 e7             	or     %r12,%rdi
    6b8c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6b92:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6b98:	4c 89 f6             	mov    %r14,%rsi
    6b9b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6ba0:	e8 cb f9 ff ff       	call   6570 <f141.constprop.0>
    6ba5:	48 83 c4 38          	add    $0x38,%rsp
    6ba9:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6bae:	5b                   	pop    %rbx
    6baf:	5d                   	pop    %rbp
    6bb0:	41 5c                	pop    %r12
    6bb2:	41 5d                	pop    %r13
    6bb4:	41 5e                	pop    %r14
    6bb6:	41 5f                	pop    %r15
    6bb8:	c3                   	ret
    6bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bc0:	f2 0f 10 3d a0 91 00 	movsd  0x91a0(%rip),%xmm7        # fd68 <msg.4+0x28>
    6bc7:	00 
    6bc8:	f2 0f 10 15 a0 91 00 	movsd  0x91a0(%rip),%xmm2        # fd70 <msg.4+0x30>
    6bcf:	00 
    6bd0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6bd6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    6bdc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6be2:	e9 3b fc ff ff       	jmp    6822 <w120+0x132>
    6be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bee:	00 00 
    6bf0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6bf6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6bfc:	48 85 f6             	test   %rsi,%rsi
    6bff:	0f 89 8f 00 00 00    	jns    6c94 <w120+0x5a4>
    6c05:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6c0b:	f2 0f 10 05 55 91 00 	movsd  0x9155(%rip),%xmm0        # fd68 <msg.4+0x28>
    6c12:	00 
    6c13:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    6c1a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c21:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6c26:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6c2a:	f2 0f 59 0d 46 91 00 	mulsd  0x9146(%rip),%xmm1        # fd78 <msg.4+0x38>
    6c31:	00 
    6c32:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6c36:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c3c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6c42:	e9 45 ff ff ff       	jmp    6b8c <w120+0x49c>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c57:	e9 30 ff ff ff       	jmp    6b8c <w120+0x49c>
    6c5c:	48 8d 3d b5 8d 00 00 	lea    0x8db5(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    6c63:	e8 e8 d7 ff ff       	call   4450 <fwp_trap>
    6c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c6f:	00 
    6c70:	48 8d 3d 4b 85 00 00 	lea    0x854b(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    6c77:	e8 d4 d7 ff ff       	call   4450 <fwp_trap>
    6c7c:	48 8d 3d 24 85 00 00 	lea    0x8524(%rip),%rdi        # f1a7 <_IO_stdin_used+0x1a7>
    6c83:	e8 c8 d7 ff ff       	call   4450 <fwp_trap>
    6c88:	48 8d 3d d1 8d 00 00 	lea    0x8dd1(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    6c8f:	e8 bc d7 ff ff       	call   4450 <fwp_trap>
    6c94:	f2 0f 10 35 cc 90 00 	movsd  0x90cc(%rip),%xmm6        # fd68 <msg.4+0x28>
    6c9b:	00 
    6c9c:	49 89 f5             	mov    %rsi,%r13
    6c9f:	49 89 f6             	mov    %rsi,%r14
    6ca2:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6ca9:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6cb0:	00 00 
    6cb2:	49 c1 fd 20          	sar    $0x20,%r13
    6cb6:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    6cbc:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6cc2:	e9 45 fb ff ff       	jmp    680c <w120+0x11c>
    6cc7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    6ccd:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6cd2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6cd9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    6cdd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6ce1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6ce7:	e9 8a fc ff ff       	jmp    6976 <w120+0x286>
    6cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cf0 <fwp_rc_share>:
    6cf0:	48 8b 05 01 5f 06 00 	mov    0x65f01(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6cf7:	48 2b 3d d2 5e 06 00 	sub    0x65ed2(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    6cfe:	48 c1 e0 10          	shl    $0x10,%rax
    6d02:	48 39 c7             	cmp    %rax,%rdi
    6d05:	73 4a                	jae    6d51 <fwp_rc_share+0x61>
    6d07:	48 89 f8             	mov    %rdi,%rax
    6d0a:	48 c1 e8 10          	shr    $0x10,%rax
    6d0e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6d12:	48 8b 05 ff 5e 06 00 	mov    0x65eff(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6d19:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6d1d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6d21:	48 85 d2             	test   %rdx,%rdx
    6d24:	74 2b                	je     6d51 <fwp_rc_share+0x61>
    6d26:	0f b6 08             	movzbl (%rax),%ecx
    6d29:	80 f9 02             	cmp    $0x2,%cl
    6d2c:	74 2a                	je     6d58 <fwp_rc_share+0x68>
    6d2e:	80 f9 01             	cmp    $0x1,%cl
    6d31:	75 1e                	jne    6d51 <fwp_rc_share+0x61>
    6d33:	8b 48 18             	mov    0x18(%rax),%ecx
    6d36:	0f b7 ff             	movzwl %di,%edi
    6d39:	8b 40 1c             	mov    0x1c(%rax),%eax
    6d3c:	48 0f af f9          	imul   %rcx,%rdi
    6d40:	48 c1 ef 20          	shr    $0x20,%rdi
    6d44:	48 39 c7             	cmp    %rax,%rdi
    6d47:	73 08                	jae    6d51 <fwp_rc_share+0x61>
    6d49:	48 01 fa             	add    %rdi,%rdx
    6d4c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6d4f:	75 0d                	jne    6d5e <fwp_rc_share+0x6e>
    6d51:	c3                   	ret
    6d52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d58:	66 85 ff             	test   %di,%di
    6d5b:	74 ef                	je     6d4c <fwp_rc_share+0x5c>
    6d5d:	c3                   	ret
    6d5e:	50                   	push   %rax
    6d5f:	48 8d 3d 2a 8d 00 00 	lea    0x8d2a(%rip),%rdi        # fa90 <_IO_stdin_used+0xa90>
    6d66:	e8 e5 d6 ff ff       	call   4450 <fwp_trap>
    6d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006d70 <fwp_rc_fresh>:
    6d70:	48 8b 15 81 5e 06 00 	mov    0x65e81(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6d77:	48 89 f8             	mov    %rdi,%rax
    6d7a:	48 89 fe             	mov    %rdi,%rsi
    6d7d:	48 2b 05 4c 5e 06 00 	sub    0x65e4c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6d84:	48 c1 e2 10          	shl    $0x10,%rdx
    6d88:	48 39 d0             	cmp    %rdx,%rax
    6d8b:	73 4f                	jae    6ddc <fwp_rc_fresh+0x6c>
    6d8d:	48 89 c2             	mov    %rax,%rdx
    6d90:	48 c1 ea 10          	shr    $0x10,%rdx
    6d94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d98:	48 8b 15 79 5e 06 00 	mov    0x65e79(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6d9f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6da3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6da7:	48 85 d2             	test   %rdx,%rdx
    6daa:	74 30                	je     6ddc <fwp_rc_fresh+0x6c>
    6dac:	0f b6 39             	movzbl (%rcx),%edi
    6daf:	40 80 ff 02          	cmp    $0x2,%dil
    6db3:	74 2b                	je     6de0 <fwp_rc_fresh+0x70>
    6db5:	40 80 ff 01          	cmp    $0x1,%dil
    6db9:	75 21                	jne    6ddc <fwp_rc_fresh+0x6c>
    6dbb:	8b 79 18             	mov    0x18(%rcx),%edi
    6dbe:	0f b7 c0             	movzwl %ax,%eax
    6dc1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6dc4:	48 0f af c7          	imul   %rdi,%rax
    6dc8:	48 c1 e8 20          	shr    $0x20,%rax
    6dcc:	48 39 c8             	cmp    %rcx,%rax
    6dcf:	73 0b                	jae    6ddc <fwp_rc_fresh+0x6c>
    6dd1:	48 01 c2             	add    %rax,%rdx
    6dd4:	80 3a ff             	cmpb   $0xff,(%rdx)
    6dd7:	74 17                	je     6df0 <fwp_rc_fresh+0x80>
    6dd9:	c6 02 01             	movb   $0x1,(%rdx)
    6ddc:	48 89 f0             	mov    %rsi,%rax
    6ddf:	c3                   	ret
    6de0:	66 85 c0             	test   %ax,%ax
    6de3:	74 ef                	je     6dd4 <fwp_rc_fresh+0x64>
    6de5:	48 89 f0             	mov    %rsi,%rax
    6de8:	c3                   	ret
    6de9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6df0:	48 83 ec 18          	sub    $0x18,%rsp
    6df4:	48 89 d7             	mov    %rdx,%rdi
    6df7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6dfc:	48 89 14 24          	mov    %rdx,(%rsp)
    6e00:	e8 cb e9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6e05:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6e0a:	48 8b 14 24          	mov    (%rsp),%rdx
    6e0e:	48 89 f0             	mov    %rsi,%rax
    6e11:	c6 02 01             	movb   $0x1,(%rdx)
    6e14:	48 83 c4 18          	add    $0x18,%rsp
    6e18:	c3                   	ret
    6e19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006e20 <fwp_rc_free_obj>:
    6e20:	48 8b 15 d1 5d 06 00 	mov    0x65dd1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6e27:	48 89 f8             	mov    %rdi,%rax
    6e2a:	48 2b 05 9f 5d 06 00 	sub    0x65d9f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6e31:	48 c1 e2 10          	shl    $0x10,%rdx
    6e35:	48 39 d0             	cmp    %rdx,%rax
    6e38:	73 5b                	jae    6e95 <fwp_rc_free_obj+0x75>
    6e3a:	48 89 c2             	mov    %rax,%rdx
    6e3d:	48 c1 ea 10          	shr    $0x10,%rdx
    6e41:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e45:	48 8b 15 cc 5d 06 00 	mov    0x65dcc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6e4c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6e50:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6e54:	48 85 c9             	test   %rcx,%rcx
    6e57:	74 3c                	je     6e95 <fwp_rc_free_obj+0x75>
    6e59:	0f b6 32             	movzbl (%rdx),%esi
    6e5c:	40 80 fe 02          	cmp    $0x2,%sil
    6e60:	74 2e                	je     6e90 <fwp_rc_free_obj+0x70>
    6e62:	40 80 fe 01          	cmp    $0x1,%sil
    6e66:	75 2d                	jne    6e95 <fwp_rc_free_obj+0x75>
    6e68:	8b 72 18             	mov    0x18(%rdx),%esi
    6e6b:	0f b7 c0             	movzwl %ax,%eax
    6e6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e71:	48 0f af c6          	imul   %rsi,%rax
    6e75:	48 c1 e8 20          	shr    $0x20,%rax
    6e79:	48 39 d0             	cmp    %rdx,%rax
    6e7c:	73 17                	jae    6e95 <fwp_rc_free_obj+0x75>
    6e7e:	48 01 c1             	add    %rax,%rcx
    6e81:	80 39 01             	cmpb   $0x1,(%rcx)
    6e84:	75 0f                	jne    6e95 <fwp_rc_free_obj+0x75>
    6e86:	e9 85 eb ff ff       	jmp    5a10 <fwp_mem_free>
    6e8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e90:	66 85 c0             	test   %ax,%ax
    6e93:	74 ec                	je     6e81 <fwp_rc_free_obj+0x61>
    6e95:	c3                   	ret
    6e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e9d:	00 00 00 

0000000000006ea0 <fwp_rc_dup>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	48 8b 05 4d 5d 06 00 	mov    0x65d4d(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    6eab:	48 2b 3d 1e 5d 06 00 	sub    0x65d1e(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    6eb2:	48 c1 e0 10          	shl    $0x10,%rax
    6eb6:	48 39 c7             	cmp    %rax,%rdi
    6eb9:	73 60                	jae    6f1b <fwp_rc_dup+0x7b>
    6ebb:	48 89 f8             	mov    %rdi,%rax
    6ebe:	48 c1 e8 10          	shr    $0x10,%rax
    6ec2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6ec6:	48 8b 05 4b 5d 06 00 	mov    0x65d4b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    6ecd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6ed1:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6ed5:	48 85 c0             	test   %rax,%rax
    6ed8:	74 41                	je     6f1b <fwp_rc_dup+0x7b>
    6eda:	0f b6 0a             	movzbl (%rdx),%ecx
    6edd:	80 f9 02             	cmp    $0x2,%cl
    6ee0:	74 3e                	je     6f20 <fwp_rc_dup+0x80>
    6ee2:	80 f9 01             	cmp    $0x1,%cl
    6ee5:	75 34                	jne    6f1b <fwp_rc_dup+0x7b>
    6ee7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6eea:	0f b7 ff             	movzwl %di,%edi
    6eed:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6ef0:	48 0f af f9          	imul   %rcx,%rdi
    6ef4:	48 c1 ef 20          	shr    $0x20,%rdi
    6ef8:	48 39 d7             	cmp    %rdx,%rdi
    6efb:	73 1e                	jae    6f1b <fwp_rc_dup+0x7b>
    6efd:	48 01 f8             	add    %rdi,%rax
    6f00:	0f b6 10             	movzbl (%rax),%edx
    6f03:	84 d2                	test   %dl,%dl
    6f05:	74 14                	je     6f1b <fwp_rc_dup+0x7b>
    6f07:	8b 0d db 65 06 00    	mov    0x665db(%rip),%ecx        # 6d4e8 <iteration_active>
    6f0d:	85 c9                	test   %ecx,%ecx
    6f0f:	75 1f                	jne    6f30 <fwp_rc_dup+0x90>
    6f11:	80 fa fd             	cmp    $0xfd,%dl
    6f14:	77 2a                	ja     6f40 <fwp_rc_dup+0xa0>
    6f16:	83 c2 01             	add    $0x1,%edx
    6f19:	88 10                	mov    %dl,(%rax)
    6f1b:	c3                   	ret
    6f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f20:	66 85 ff             	test   %di,%di
    6f23:	74 db                	je     6f00 <fwp_rc_dup+0x60>
    6f25:	c3                   	ret
    6f26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f2d:	00 00 00 
    6f30:	48 83 05 98 65 06 00 	addq   $0x1,0x66598(%rip)        # 6d4d0 <iteration_retains>
    6f37:	01 
    6f38:	eb d7                	jmp    6f11 <fwp_rc_dup+0x71>
    6f3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6f40:	48 89 c7             	mov    %rax,%rdi
    6f43:	e9 68 e7 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6f48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6f4f:	00 

0000000000006f50 <fwp_owned_entry173>:
    6f50:	f3 0f 1e fa          	endbr64
    6f54:	48 83 ec 38          	sub    $0x38,%rsp
    6f58:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6f5d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f64:	00 00 
    6f66:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6f6b:	31 c0                	xor    %eax,%eax
    6f6d:	48 8b 07             	mov    (%rdi),%rax
    6f70:	48 03 47 10          	add    0x10(%rdi),%rax
    6f74:	0f 80 c2 00 00 00    	jo     703c <fwp_owned_entry173+0xec>
    6f7a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6f7f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6f84:	31 ff                	xor    %edi,%edi
    6f86:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6f8a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6f8f:	e8 6c f1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6f94:	48 8b 15 5d 5c 06 00 	mov    0x65c5d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    6f9b:	48 89 c6             	mov    %rax,%rsi
    6f9e:	48 2b 05 2b 5c 06 00 	sub    0x65c2b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    6fa5:	48 c1 e2 10          	shl    $0x10,%rdx
    6fa9:	48 39 d0             	cmp    %rdx,%rax
    6fac:	73 4f                	jae    6ffd <fwp_owned_entry173+0xad>
    6fae:	48 89 c2             	mov    %rax,%rdx
    6fb1:	48 c1 ea 10          	shr    $0x10,%rdx
    6fb5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fb9:	48 8b 15 58 5c 06 00 	mov    0x65c58(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    6fc0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fc4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fc8:	48 85 d2             	test   %rdx,%rdx
    6fcb:	74 30                	je     6ffd <fwp_owned_entry173+0xad>
    6fcd:	0f b6 39             	movzbl (%rcx),%edi
    6fd0:	40 80 ff 02          	cmp    $0x2,%dil
    6fd4:	74 42                	je     7018 <fwp_owned_entry173+0xc8>
    6fd6:	40 80 ff 01          	cmp    $0x1,%dil
    6fda:	75 21                	jne    6ffd <fwp_owned_entry173+0xad>
    6fdc:	8b 79 18             	mov    0x18(%rcx),%edi
    6fdf:	0f b7 c0             	movzwl %ax,%eax
    6fe2:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fe5:	48 0f af c7          	imul   %rdi,%rax
    6fe9:	48 c1 e8 20          	shr    $0x20,%rax
    6fed:	48 39 c8             	cmp    %rcx,%rax
    6ff0:	73 0b                	jae    6ffd <fwp_owned_entry173+0xad>
    6ff2:	48 01 c2             	add    %rax,%rdx
    6ff5:	80 3a ff             	cmpb   $0xff,(%rdx)
    6ff8:	74 26                	je     7020 <fwp_owned_entry173+0xd0>
    6ffa:	c6 02 01             	movb   $0x1,(%rdx)
    6ffd:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7002:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7009:	00 00 
    700b:	75 34                	jne    7041 <fwp_owned_entry173+0xf1>
    700d:	48 89 f0             	mov    %rsi,%rax
    7010:	48 83 c4 38          	add    $0x38,%rsp
    7014:	c3                   	ret
    7015:	0f 1f 00             	nopl   (%rax)
    7018:	66 85 c0             	test   %ax,%ax
    701b:	75 e0                	jne    6ffd <fwp_owned_entry173+0xad>
    701d:	eb d6                	jmp    6ff5 <fwp_owned_entry173+0xa5>
    701f:	90                   	nop
    7020:	48 89 d7             	mov    %rdx,%rdi
    7023:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    7028:	48 89 14 24          	mov    %rdx,(%rsp)
    702c:	e8 9f e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7031:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    7036:	48 8b 14 24          	mov    (%rsp),%rdx
    703a:	eb be                	jmp    6ffa <fwp_owned_entry173+0xaa>
    703c:	e8 bf c6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7041:	e8 0a c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    7046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    704d:	00 00 00 

0000000000007050 <e173>:
    7050:	f3 0f 1e fa          	endbr64
    7054:	53                   	push   %rbx
    7055:	48 83 ec 30          	sub    $0x30,%rsp
    7059:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    705e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7065:	00 00 
    7067:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    706c:	31 c0                	xor    %eax,%eax
    706e:	48 8b 07             	mov    (%rdi),%rax
    7071:	48 03 47 10          	add    0x10(%rdi),%rax
    7075:	0f 80 c9 00 00 00    	jo     7144 <e173+0xf4>
    707b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    7080:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7085:	31 ff                	xor    %edi,%edi
    7087:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    708b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7090:	e8 6b f0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    7095:	48 8b 15 5c 5b 06 00 	mov    0x65b5c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    709c:	48 89 c3             	mov    %rax,%rbx
    709f:	48 2b 05 2a 5b 06 00 	sub    0x65b2a(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    70a6:	48 c1 e2 10          	shl    $0x10,%rdx
    70aa:	48 39 d0             	cmp    %rdx,%rax
    70ad:	73 4f                	jae    70fe <e173+0xae>
    70af:	48 89 c2             	mov    %rax,%rdx
    70b2:	48 c1 ea 10          	shr    $0x10,%rdx
    70b6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70ba:	48 8b 15 57 5b 06 00 	mov    0x65b57(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    70c1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    70c5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    70c9:	48 85 d2             	test   %rdx,%rdx
    70cc:	74 30                	je     70fe <e173+0xae>
    70ce:	0f b6 31             	movzbl (%rcx),%esi
    70d1:	40 80 fe 02          	cmp    $0x2,%sil
    70d5:	74 49                	je     7120 <e173+0xd0>
    70d7:	40 80 fe 01          	cmp    $0x1,%sil
    70db:	75 21                	jne    70fe <e173+0xae>
    70dd:	8b 71 18             	mov    0x18(%rcx),%esi
    70e0:	0f b7 c0             	movzwl %ax,%eax
    70e3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70e6:	48 0f af c6          	imul   %rsi,%rax
    70ea:	48 c1 e8 20          	shr    $0x20,%rax
    70ee:	48 39 c8             	cmp    %rcx,%rax
    70f1:	73 0b                	jae    70fe <e173+0xae>
    70f3:	48 01 c2             	add    %rax,%rdx
    70f6:	80 3a ff             	cmpb   $0xff,(%rdx)
    70f9:	74 35                	je     7130 <e173+0xe0>
    70fb:	c6 02 01             	movb   $0x1,(%rdx)
    70fe:	48 89 df             	mov    %rbx,%rdi
    7101:	e8 ea fb ff ff       	call   6cf0 <fwp_rc_share>
    7106:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    710b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7112:	00 00 
    7114:	75 33                	jne    7149 <e173+0xf9>
    7116:	48 83 c4 30          	add    $0x30,%rsp
    711a:	48 89 d8             	mov    %rbx,%rax
    711d:	5b                   	pop    %rbx
    711e:	c3                   	ret
    711f:	90                   	nop
    7120:	66 85 c0             	test   %ax,%ax
    7123:	75 d9                	jne    70fe <e173+0xae>
    7125:	eb cf                	jmp    70f6 <e173+0xa6>
    7127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    712e:	00 00 
    7130:	48 89 d7             	mov    %rdx,%rdi
    7133:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7138:	e8 93 e6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    713d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7142:	eb b7                	jmp    70fb <e173+0xab>
    7144:	e8 b7 c5 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7149:	e8 02 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    714e:	66 90                	xchg   %ax,%ax

0000000000007150 <fwp_closure_drop>:
    7150:	48 8b 15 a1 5a 06 00 	mov    0x65aa1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7157:	48 89 f8             	mov    %rdi,%rax
    715a:	48 2b 05 6f 5a 06 00 	sub    0x65a6f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7161:	48 c1 e2 10          	shl    $0x10,%rdx
    7165:	48 39 d0             	cmp    %rdx,%rax
    7168:	73 6b                	jae    71d5 <fwp_closure_drop+0x85>
    716a:	48 89 c2             	mov    %rax,%rdx
    716d:	48 c1 ea 10          	shr    $0x10,%rdx
    7171:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7175:	48 8b 15 9c 5a 06 00 	mov    0x65a9c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    717c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7180:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7184:	48 85 d2             	test   %rdx,%rdx
    7187:	74 4c                	je     71d5 <fwp_closure_drop+0x85>
    7189:	0f b6 31             	movzbl (%rcx),%esi
    718c:	40 80 fe 02          	cmp    $0x2,%sil
    7190:	74 3e                	je     71d0 <fwp_closure_drop+0x80>
    7192:	40 80 fe 01          	cmp    $0x1,%sil
    7196:	75 3d                	jne    71d5 <fwp_closure_drop+0x85>
    7198:	8b 71 18             	mov    0x18(%rcx),%esi
    719b:	0f b7 c0             	movzwl %ax,%eax
    719e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    71a1:	48 0f af c6          	imul   %rsi,%rax
    71a5:	48 c1 e8 20          	shr    $0x20,%rax
    71a9:	48 39 c8             	cmp    %rcx,%rax
    71ac:	73 27                	jae    71d5 <fwp_closure_drop+0x85>
    71ae:	48 01 c2             	add    %rax,%rdx
    71b1:	0f b6 02             	movzbl (%rdx),%eax
    71b4:	84 c0                	test   %al,%al
    71b6:	74 1d                	je     71d5 <fwp_closure_drop+0x85>
    71b8:	3c 01                	cmp    $0x1,%al
    71ba:	74 24                	je     71e0 <fwp_closure_drop+0x90>
    71bc:	3c ff                	cmp    $0xff,%al
    71be:	74 48                	je     7208 <fwp_closure_drop+0xb8>
    71c0:	83 e8 01             	sub    $0x1,%eax
    71c3:	88 02                	mov    %al,(%rdx)
    71c5:	c3                   	ret
    71c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71cd:	00 00 00 
    71d0:	66 85 c0             	test   %ax,%ax
    71d3:	74 dc                	je     71b1 <fwp_closure_drop+0x61>
    71d5:	c3                   	ret
    71d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    71dd:	00 00 00 
    71e0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    71e7:	ff ff 
    71e9:	48 85 c0             	test   %rax,%rax
    71ec:	74 12                	je     7200 <fwp_closure_drop+0xb0>
    71ee:	48 89 fe             	mov    %rdi,%rsi
    71f1:	48 89 c7             	mov    %rax,%rdi
    71f4:	e9 b7 d2 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    71f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7200:	e9 5b d4 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7205:	0f 1f 00             	nopl   (%rax)
    7208:	48 89 d0             	mov    %rdx,%rax
    720b:	48 8d 35 0e 46 06 00 	lea    0x6460e(%rip),%rsi        # 6b820 <fwp_heap>
    7212:	48 83 ec 18          	sub    $0x18,%rsp
    7216:	48 c1 e8 11          	shr    $0x11,%rax
    721a:	48 31 d0             	xor    %rdx,%rax
    721d:	48 89 c1             	mov    %rax,%rcx
    7220:	48 c1 e9 09          	shr    $0x9,%rcx
    7224:	48 31 c8             	xor    %rcx,%rax
    7227:	0f b6 c8             	movzbl %al,%ecx
    722a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7231:	00 
    7232:	48 85 c0             	test   %rax,%rax
    7235:	75 12                	jne    7249 <fwp_closure_drop+0xf9>
    7237:	eb 49                	jmp    7282 <fwp_closure_drop+0x132>
    7239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7240:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7244:	48 85 c0             	test   %rax,%rax
    7247:	74 39                	je     7282 <fwp_closure_drop+0x132>
    7249:	48 89 c1             	mov    %rax,%rcx
    724c:	48 39 10             	cmp    %rdx,(%rax)
    724f:	75 ef                	jne    7240 <fwp_closure_drop+0xf0>
    7251:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7255:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7259:	48 89 48 08          	mov    %rcx,0x8(%rax)
    725d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7264:	74 05                	je     726b <fwp_closure_drop+0x11b>
    7266:	48 83 c4 18          	add    $0x18,%rsp
    726a:	c3                   	ret
    726b:	48 89 d7             	mov    %rdx,%rdi
    726e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7273:	e8 58 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    7278:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    727d:	c6 02 fe             	movb   $0xfe,(%rdx)
    7280:	eb e4                	jmp    7266 <fwp_closure_drop+0x116>
    7282:	48 8d 3d 67 87 00 00 	lea    0x8767(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7289:	e8 c2 d1 ff ff       	call   4450 <fwp_trap>
    728e:	66 90                	xchg   %ax,%ax

0000000000007290 <fwp_owned_tape_release>:
    7290:	48 85 ff             	test   %rdi,%rdi
    7293:	0f 84 f7 00 00 00    	je     7390 <fwp_owned_tape_release+0x100>
    7299:	41 54                	push   %r12
    729b:	55                   	push   %rbp
    729c:	53                   	push   %rbx
    729d:	48 8b 07             	mov    (%rdi),%rax
    72a0:	48 85 c0             	test   %rax,%rax
    72a3:	74 08                	je     72ad <fwp_owned_tape_release+0x1d>
    72a5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    72ad:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    72b1:	48 85 d2             	test   %rdx,%rdx
    72b4:	74 03                	je     72b9 <fwp_owned_tape_release+0x29>
    72b6:	48 89 02             	mov    %rax,(%rdx)
    72b9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    72bd:	48 89 fb             	mov    %rdi,%rbx
    72c0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    72c4:	48 85 c0             	test   %rax,%rax
    72c7:	0f 84 89 00 00 00    	je     7356 <fwp_owned_tape_release+0xc6>
    72cd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    72d1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    72d5:	7e 47                	jle    731e <fwp_owned_tape_release+0x8e>
    72d7:	31 ed                	xor    %ebp,%ebp
    72d9:	eb 0d                	jmp    72e8 <fwp_owned_tape_release+0x58>
    72db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    72e0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    72e4:	48 8b 40 68          	mov    0x68(%rax),%rax
    72e8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    72ec:	49 89 ec             	mov    %rbp,%r12
    72ef:	48 83 c5 01          	add    $0x1,%rbp
    72f3:	49 c1 e4 04          	shl    $0x4,%r12
    72f7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    72fb:	ff d0                	call   *%rax
    72fd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7301:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7306:	48 8b 43 10          	mov    0x10(%rbx),%rax
    730a:	ff 50 68             	call   *0x68(%rax)
    730d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7311:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7315:	48 39 e8             	cmp    %rbp,%rax
    7318:	7f c6                	jg     72e0 <fwp_owned_tape_release+0x50>
    731a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    731e:	31 ed                	xor    %ebp,%ebp
    7320:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7325:	7e 28                	jle    734f <fwp_owned_tape_release+0xbf>
    7327:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    732e:	00 00 
    7330:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7334:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7338:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    733c:	74 07                	je     7345 <fwp_owned_tape_release+0xb5>
    733e:	ff 52 68             	call   *0x68(%rdx)
    7341:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7345:	48 83 c5 01          	add    $0x1,%rbp
    7349:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    734d:	7f e1                	jg     7330 <fwp_owned_tape_release+0xa0>
    734f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7353:	ff 52 68             	call   *0x68(%rdx)
    7356:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    735a:	e8 f1 fd ff ff       	call   7150 <fwp_closure_drop>
    735f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    7363:	e8 e8 fd ff ff       	call   7150 <fwp_closure_drop>
    7368:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    736c:	e8 df fd ff ff       	call   7150 <fwp_closure_drop>
    7371:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    7375:	e8 96 e6 ff ff       	call   5a10 <fwp_mem_free>
    737a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    737e:	e8 8d e6 ff ff       	call   5a10 <fwp_mem_free>
    7383:	48 89 df             	mov    %rbx,%rdi
    7386:	5b                   	pop    %rbx
    7387:	5d                   	pop    %rbp
    7388:	41 5c                	pop    %r12
    738a:	e9 81 e6 ff ff       	jmp    5a10 <fwp_mem_free>
    738f:	90                   	nop
    7390:	c3                   	ret
    7391:	0f 1f 40 00          	nopl   0x0(%rax)
    7395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    739c:	00 00 00 00 

00000000000073a0 <fwp_tape_finish>:
    73a0:	f3 0f 1e fa          	endbr64
    73a4:	41 55                	push   %r13
    73a6:	41 54                	push   %r12
    73a8:	55                   	push   %rbp
    73a9:	53                   	push   %rbx
    73aa:	48 83 ec 48          	sub    $0x48,%rsp
    73ae:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    73b5:	00 00 
    73b7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    73bc:	48 8d 3d dd bc 01 00 	lea    0x1bcdd(%rip),%rdi        # 230a0 <fwp_tape_workspace>
    73c3:	e8 78 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    73c8:	48 83 3d 18 bd 01 00 	cmpq   $0x0,0x1bd18(%rip)        # 230e8 <fwp_ntapes>
    73cf:	00 
    73d0:	48 c7 05 ad bc 01 00 	movq   $0x0,0x1bcad(%rip)        # 23088 <fwp_tape_cached_bytes>
    73d7:	00 00 00 00 
    73db:	7e 79                	jle    7456 <fwp_tape_finish+0xb6>
    73dd:	45 31 e4             	xor    %r12d,%r12d
    73e0:	31 ed                	xor    %ebp,%ebp
    73e2:	0f 1f 00             	nopl   (%rax)
    73e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73ec:	00 00 00 00 
    73f0:	48 8b 1d f9 bc 01 00 	mov    0x1bcf9(%rip),%rbx        # 230f0 <fwp_tapes>
    73f7:	48 83 c5 01          	add    $0x1,%rbp
    73fb:	4c 01 e3             	add    %r12,%rbx
    73fe:	49 83 c4 68          	add    $0x68,%r12
    7402:	48 89 df             	mov    %rbx,%rdi
    7405:	e8 86 c8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    740a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    740f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7414:	48 89 e7             	mov    %rsp,%rdi
    7417:	48 8b 43 40          	mov    0x40(%rbx),%rax
    741b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    741f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7424:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7429:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    742e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7432:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7437:	e8 04 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    743c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7440:	e8 4b fe ff ff       	call   7290 <fwp_owned_tape_release>
    7445:	48 39 2d 9c bc 01 00 	cmp    %rbp,0x1bc9c(%rip)        # 230e8 <fwp_ntapes>
    744c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7453:	00 
    7454:	7f 9a                	jg     73f0 <fwp_tape_finish+0x50>
    7456:	48 8b 3d 93 bc 01 00 	mov    0x1bc93(%rip),%rdi        # 230f0 <fwp_tapes>
    745d:	48 85 ff             	test   %rdi,%rdi
    7460:	74 05                	je     7467 <fwp_tape_finish+0xc7>
    7462:	e8 69 dc ff ff       	call   50d0 <ad_raw_free.part.0>
    7467:	48 c7 05 7e bc 01 00 	movq   $0x0,0x1bc7e(%rip)        # 230f0 <fwp_tapes>
    746e:	00 00 00 00 
    7472:	48 c7 05 63 bc 01 00 	movq   $0x0,0x1bc63(%rip)        # 230e0 <fwp_tapes_cap>
    7479:	00 00 00 00 
    747d:	48 c7 05 60 bc 01 00 	movq   $0x0,0x1bc60(%rip)        # 230e8 <fwp_ntapes>
    7484:	00 00 00 00 
    7488:	48 c7 05 45 bc 01 00 	movq   $0x0,0x1bc45(%rip)        # 230d8 <fwp_tape_next_slot>
    748f:	00 00 00 00 
    7493:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7498:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    749f:	00 00 
    74a1:	75 0b                	jne    74ae <fwp_tape_finish+0x10e>
    74a3:	48 83 c4 48          	add    $0x48,%rsp
    74a7:	5b                   	pop    %rbx
    74a8:	5d                   	pop    %rbp
    74a9:	41 5c                	pop    %r12
    74ab:	41 5d                	pop    %r13
    74ad:	c3                   	ret
    74ae:	e8 9d bf ff ff       	call   3450 <__stack_chk_fail@plt>
    74b3:	66 90                	xchg   %ax,%ax
    74b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74bc:	00 00 00 00 

00000000000074c0 <fwp_tape_scope_release>:
    74c0:	f3 0f 1e fa          	endbr64
    74c4:	41 55                	push   %r13
    74c6:	41 54                	push   %r12
    74c8:	55                   	push   %rbp
    74c9:	53                   	push   %rbx
    74ca:	48 83 ec 48          	sub    $0x48,%rsp
    74ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    74d5:	00 00 
    74d7:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    74dc:	48 63 07             	movslq (%rdi),%rax
    74df:	85 c0                	test   %eax,%eax
    74e1:	0f 88 e8 00 00 00    	js     75cf <fwp_tape_scope_release+0x10f>
    74e7:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    74ee:	ec c4 4e 
    74f1:	48 89 fb             	mov    %rdi,%rbx
    74f4:	48 89 e5             	mov    %rsp,%rbp
    74f7:	eb 1f                	jmp    7518 <fwp_tape_scope_release+0x58>
    74f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7500:	e8 3b dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7505:	4c 89 ef             	mov    %r13,%rdi
    7508:	e8 83 fd ff ff       	call   7290 <fwp_owned_tape_release>
    750d:	48 63 03             	movslq (%rbx),%rax
    7510:	85 c0                	test   %eax,%eax
    7512:	0f 88 b7 00 00 00    	js     75cf <fwp_tape_scope_release+0x10f>
    7518:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    751c:	48 8b 35 cd bb 01 00 	mov    0x1bbcd(%rip),%rsi        # 230f0 <fwp_tapes>
    7523:	4c 01 c6             	add    %r8,%rsi
    7526:	48 89 f7             	mov    %rsi,%rdi
    7529:	e8 62 c7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    752e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7533:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7538:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    753f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7543:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7547:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    754e:	00 
    754f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7554:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7559:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    755d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7562:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7566:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    756b:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7572:	00 
    7573:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    757a:	00 
    757b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7582:	00 
    7583:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    7587:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    758b:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    758f:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    7593:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7599:	77 18                	ja     75b3 <fwp_tape_scope_release+0xf3>
    759b:	49 c1 f8 03          	sar    $0x3,%r8
    759f:	4d 0f af c4          	imul   %r12,%r8
    75a3:	4c 3b 05 2e bb 01 00 	cmp    0x1bb2e(%rip),%r8        # 230d8 <fwp_tape_next_slot>
    75aa:	7d 07                	jge    75b3 <fwp_tape_scope_release+0xf3>
    75ac:	4c 89 05 25 bb 01 00 	mov    %r8,0x1bb25(%rip)        # 230d8 <fwp_tape_next_slot>
    75b3:	48 89 ef             	mov    %rbp,%rdi
    75b6:	4d 85 ed             	test   %r13,%r13
    75b9:	0f 85 41 ff ff ff    	jne    7500 <fwp_tape_scope_release+0x40>
    75bf:	e8 9c dc ff ff       	call   5260 <fwp_tape_buffers_release>
    75c4:	48 63 03             	movslq (%rbx),%rax
    75c7:	85 c0                	test   %eax,%eax
    75c9:	0f 89 49 ff ff ff    	jns    7518 <fwp_tape_scope_release+0x58>
    75cf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    75d4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    75db:	00 00 
    75dd:	75 0b                	jne    75ea <fwp_tape_scope_release+0x12a>
    75df:	48 83 c4 48          	add    $0x48,%rsp
    75e3:	5b                   	pop    %rbx
    75e4:	5d                   	pop    %rbp
    75e5:	41 5c                	pop    %r12
    75e7:	41 5d                	pop    %r13
    75e9:	c3                   	ret
    75ea:	e8 61 be ff ff       	call   3450 <__stack_chk_fail@plt>
    75ef:	90                   	nop

00000000000075f0 <fwp_drop4>:
    75f0:	48 8b 0d 01 56 06 00 	mov    0x65601(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    75f7:	48 89 f8             	mov    %rdi,%rax
    75fa:	48 2b 05 cf 55 06 00 	sub    0x655cf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7601:	48 c1 e1 10          	shl    $0x10,%rcx
    7605:	48 39 c8             	cmp    %rcx,%rax
    7608:	0f 83 42 01 00 00    	jae    7750 <fwp_drop4+0x160>
    760e:	48 83 ec 18          	sub    $0x18,%rsp
    7612:	48 89 fa             	mov    %rdi,%rdx
    7615:	4c 8d 05 04 42 06 00 	lea    0x64204(%rip),%r8        # 6b820 <fwp_heap>
    761c:	48 89 c1             	mov    %rax,%rcx
    761f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7626:	48 c1 e9 10          	shr    $0x10,%rcx
    762a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    762e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7632:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7636:	48 85 c9             	test   %rcx,%rcx
    7639:	74 40                	je     767b <fwp_drop4+0x8b>
    763b:	0f b6 3e             	movzbl (%rsi),%edi
    763e:	40 80 ff 02          	cmp    $0x2,%dil
    7642:	74 3c                	je     7680 <fwp_drop4+0x90>
    7644:	40 80 ff 01          	cmp    $0x1,%dil
    7648:	75 31                	jne    767b <fwp_drop4+0x8b>
    764a:	8b 7e 18             	mov    0x18(%rsi),%edi
    764d:	0f b7 c0             	movzwl %ax,%eax
    7650:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7653:	48 0f af c7          	imul   %rdi,%rax
    7657:	48 c1 e8 20          	shr    $0x20,%rax
    765b:	48 39 f0             	cmp    %rsi,%rax
    765e:	73 1b                	jae    767b <fwp_drop4+0x8b>
    7660:	48 01 c1             	add    %rax,%rcx
    7663:	0f b6 01             	movzbl (%rcx),%eax
    7666:	84 c0                	test   %al,%al
    7668:	74 11                	je     767b <fwp_drop4+0x8b>
    766a:	3c 01                	cmp    $0x1,%al
    766c:	74 22                	je     7690 <fwp_drop4+0xa0>
    766e:	3c ff                	cmp    $0xff,%al
    7670:	0f 84 0a 01 00 00    	je     7780 <fwp_drop4+0x190>
    7676:	83 e8 01             	sub    $0x1,%eax
    7679:	88 01                	mov    %al,(%rcx)
    767b:	48 83 c4 18          	add    $0x18,%rsp
    767f:	c3                   	ret
    7680:	66 85 c0             	test   %ax,%ax
    7683:	74 de                	je     7663 <fwp_drop4+0x73>
    7685:	48 83 c4 18          	add    $0x18,%rsp
    7689:	c3                   	ret
    768a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7690:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7694:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    769b:	48 89 f8             	mov    %rdi,%rax
    769e:	48 c1 e1 10          	shl    $0x10,%rcx
    76a2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    76a9:	48 39 c8             	cmp    %rcx,%rax
    76ac:	73 62                	jae    7710 <fwp_drop4+0x120>
    76ae:	48 89 c1             	mov    %rax,%rcx
    76b1:	48 c1 e9 10          	shr    $0x10,%rcx
    76b5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    76b9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    76bd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    76c1:	48 85 c9             	test   %rcx,%rcx
    76c4:	74 4a                	je     7710 <fwp_drop4+0x120>
    76c6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    76ca:	41 80 f9 02          	cmp    $0x2,%r9b
    76ce:	0f 84 9c 00 00 00    	je     7770 <fwp_drop4+0x180>
    76d4:	41 80 f9 01          	cmp    $0x1,%r9b
    76d8:	75 36                	jne    7710 <fwp_drop4+0x120>
    76da:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    76de:	0f b7 c0             	movzwl %ax,%eax
    76e1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    76e4:	49 0f af c1          	imul   %r9,%rax
    76e8:	48 c1 e8 20          	shr    $0x20,%rax
    76ec:	48 39 f0             	cmp    %rsi,%rax
    76ef:	73 1f                	jae    7710 <fwp_drop4+0x120>
    76f1:	48 01 c1             	add    %rax,%rcx
    76f4:	0f b6 01             	movzbl (%rcx),%eax
    76f7:	84 c0                	test   %al,%al
    76f9:	74 15                	je     7710 <fwp_drop4+0x120>
    76fb:	3c 01                	cmp    $0x1,%al
    76fd:	74 59                	je     7758 <fwp_drop4+0x168>
    76ff:	3c ff                	cmp    $0xff,%al
    7701:	0f 84 ff 00 00 00    	je     7806 <fwp_drop4+0x216>
    7707:	83 e8 01             	sub    $0x1,%eax
    770a:	88 01                	mov    %al,(%rcx)
    770c:	0f 1f 40 00          	nopl   0x0(%rax)
    7710:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7714:	48 89 d7             	mov    %rdx,%rdi
    7717:	48 89 0c 24          	mov    %rcx,(%rsp)
    771b:	e8 00 f7 ff ff       	call   6e20 <fwp_rc_free_obj>
    7720:	4c 8d 05 f9 40 06 00 	lea    0x640f9(%rip),%r8        # 6b820 <fwp_heap>
    7727:	48 8b 04 24          	mov    (%rsp),%rax
    772b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7732:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7739:	48 c1 e2 10          	shl    $0x10,%rdx
    773d:	48 39 d0             	cmp    %rdx,%rax
    7740:	0f 83 35 ff ff ff    	jae    767b <fwp_drop4+0x8b>
    7746:	48 8b 14 24          	mov    (%rsp),%rdx
    774a:	e9 cd fe ff ff       	jmp    761c <fwp_drop4+0x2c>
    774f:	90                   	nop
    7750:	c3                   	ret
    7751:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7758:	48 89 14 24          	mov    %rdx,(%rsp)
    775c:	e8 bf f6 ff ff       	call   6e20 <fwp_rc_free_obj>
    7761:	48 8b 14 24          	mov    (%rsp),%rdx
    7765:	eb a9                	jmp    7710 <fwp_drop4+0x120>
    7767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    776e:	00 00 
    7770:	66 85 c0             	test   %ax,%ax
    7773:	75 9b                	jne    7710 <fwp_drop4+0x120>
    7775:	e9 7a ff ff ff       	jmp    76f4 <fwp_drop4+0x104>
    777a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7780:	48 89 c8             	mov    %rcx,%rax
    7783:	48 c1 e8 11          	shr    $0x11,%rax
    7787:	48 31 c8             	xor    %rcx,%rax
    778a:	48 89 c2             	mov    %rax,%rdx
    778d:	48 c1 ea 09          	shr    $0x9,%rdx
    7791:	48 31 d0             	xor    %rdx,%rax
    7794:	0f b6 d0             	movzbl %al,%edx
    7797:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    779e:	00 
    779f:	48 85 c0             	test   %rax,%rax
    77a2:	75 29                	jne    77cd <fwp_drop4+0x1dd>
    77a4:	e9 e3 00 00 00       	jmp    788c <fwp_drop4+0x29c>
    77a9:	90                   	nop
    77aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77b1:	00 00 00 00 
    77b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    77bc:	00 00 00 00 
    77c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    77c4:	48 85 c0             	test   %rax,%rax
    77c7:	0f 84 bf 00 00 00    	je     788c <fwp_drop4+0x29c>
    77cd:	48 89 c2             	mov    %rax,%rdx
    77d0:	48 39 08             	cmp    %rcx,(%rax)
    77d3:	75 eb                	jne    77c0 <fwp_drop4+0x1d0>
    77d5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    77d9:	48 83 ea 01          	sub    $0x1,%rdx
    77dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    77e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    77e8:	0f 85 8d fe ff ff    	jne    767b <fwp_drop4+0x8b>
    77ee:	48 89 cf             	mov    %rcx,%rdi
    77f1:	48 89 0c 24          	mov    %rcx,(%rsp)
    77f5:	e8 d6 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    77fa:	48 8b 0c 24          	mov    (%rsp),%rcx
    77fe:	c6 01 fe             	movb   $0xfe,(%rcx)
    7801:	e9 75 fe ff ff       	jmp    767b <fwp_drop4+0x8b>
    7806:	48 89 ce             	mov    %rcx,%rsi
    7809:	48 c1 ee 11          	shr    $0x11,%rsi
    780d:	48 31 ce             	xor    %rcx,%rsi
    7810:	48 89 f0             	mov    %rsi,%rax
    7813:	48 c1 e8 09          	shr    $0x9,%rax
    7817:	48 31 c6             	xor    %rax,%rsi
    781a:	40 0f b6 f6          	movzbl %sil,%esi
    781e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7825:	00 
    7826:	48 85 c0             	test   %rax,%rax
    7829:	75 1e                	jne    7849 <fwp_drop4+0x259>
    782b:	eb 5f                	jmp    788c <fwp_drop4+0x29c>
    782d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7834:	00 
    7835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    783c:	00 00 00 00 
    7840:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7844:	48 85 c0             	test   %rax,%rax
    7847:	74 43                	je     788c <fwp_drop4+0x29c>
    7849:	48 89 c6             	mov    %rax,%rsi
    784c:	48 39 08             	cmp    %rcx,(%rax)
    784f:	75 ef                	jne    7840 <fwp_drop4+0x250>
    7851:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7855:	48 83 ee 01          	sub    $0x1,%rsi
    7859:	48 89 70 08          	mov    %rsi,0x8(%rax)
    785d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    7864:	0f 85 a6 fe ff ff    	jne    7710 <fwp_drop4+0x120>
    786a:	48 89 cf             	mov    %rcx,%rdi
    786d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7872:	48 89 0c 24          	mov    %rcx,(%rsp)
    7876:	e8 55 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    787b:	48 8b 0c 24          	mov    (%rsp),%rcx
    787f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7884:	c6 01 fe             	movb   $0xfe,(%rcx)
    7887:	e9 84 fe ff ff       	jmp    7710 <fwp_drop4+0x120>
    788c:	48 8d 3d 5d 81 00 00 	lea    0x815d(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7893:	e8 b8 cb ff ff       	call   4450 <fwp_trap>
    7898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    789f:	00 

00000000000078a0 <fwp_arg_drop37>:
    78a0:	f3 0f 1e fa          	endbr64
    78a4:	85 f6                	test   %esi,%esi
    78a6:	75 04                	jne    78ac <fwp_arg_drop37+0xc>
    78a8:	85 d2                	test   %edx,%edx
    78aa:	75 04                	jne    78b0 <fwp_arg_drop37+0x10>
    78ac:	c3                   	ret
    78ad:	0f 1f 00             	nopl   (%rax)
    78b0:	48 8b 3f             	mov    (%rdi),%rdi
    78b3:	e9 38 fd ff ff       	jmp    75f0 <fwp_drop4>
    78b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    78bf:	00 

00000000000078c0 <fwp_task_dispose>:
    78c0:	53                   	push   %rbx
    78c1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    78c5:	0f 84 7b be ff ff    	je     3746 <fwp_task_dispose.cold>
    78cb:	48 89 fb             	mov    %rdi,%rbx
    78ce:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    78d3:	0f 85 6d be ff ff    	jne    3746 <fwp_task_dispose.cold>
    78d9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    78dd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    78e4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    78eb:	00 
    78ec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    78f0:	48 85 ff             	test   %rdi,%rdi
    78f3:	74 07                	je     78fc <fwp_task_dispose+0x3c>
    78f5:	48 85 c0             	test   %rax,%rax
    78f8:	74 02                	je     78fc <fwp_task_dispose+0x3c>
    78fa:	ff d0                	call   *%rax
    78fc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7903:	e8 08 e1 ff ff       	call   5a10 <fwp_mem_free>
    7908:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    790f:	00 00 00 00 
    7913:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7917:	74 6f                	je     7988 <fwp_task_dispose+0xc8>
    7919:	48 8b 15 d8 52 06 00 	mov    0x652d8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7920:	48 89 d8             	mov    %rbx,%rax
    7923:	48 2b 05 a6 52 06 00 	sub    0x652a6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    792a:	48 c1 e2 10          	shl    $0x10,%rdx
    792e:	48 39 d0             	cmp    %rdx,%rax
    7931:	73 4c                	jae    797f <fwp_task_dispose+0xbf>
    7933:	48 89 c2             	mov    %rax,%rdx
    7936:	48 c1 ea 10          	shr    $0x10,%rdx
    793a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    793e:	48 8b 15 d3 52 06 00 	mov    0x652d3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7945:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7949:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    794d:	48 85 c9             	test   %rcx,%rcx
    7950:	74 2d                	je     797f <fwp_task_dispose+0xbf>
    7952:	0f b6 32             	movzbl (%rdx),%esi
    7955:	40 80 fe 02          	cmp    $0x2,%sil
    7959:	74 3d                	je     7998 <fwp_task_dispose+0xd8>
    795b:	40 80 fe 01          	cmp    $0x1,%sil
    795f:	75 1e                	jne    797f <fwp_task_dispose+0xbf>
    7961:	8b 72 18             	mov    0x18(%rdx),%esi
    7964:	0f b7 c0             	movzwl %ax,%eax
    7967:	8b 52 1c             	mov    0x1c(%rdx),%edx
    796a:	48 0f af c6          	imul   %rsi,%rax
    796e:	48 c1 e8 20          	shr    $0x20,%rax
    7972:	48 39 d0             	cmp    %rdx,%rax
    7975:	73 08                	jae    797f <fwp_task_dispose+0xbf>
    7977:	48 01 c1             	add    %rax,%rcx
    797a:	80 39 01             	cmpb   $0x1,(%rcx)
    797d:	74 09                	je     7988 <fwp_task_dispose+0xc8>
    797f:	5b                   	pop    %rbx
    7980:	c3                   	ret
    7981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7988:	48 89 df             	mov    %rbx,%rdi
    798b:	5b                   	pop    %rbx
    798c:	e9 7f e0 ff ff       	jmp    5a10 <fwp_mem_free>
    7991:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7998:	66 85 c0             	test   %ax,%ax
    799b:	74 dd                	je     797a <fwp_task_dispose+0xba>
    799d:	5b                   	pop    %rbx
    799e:	c3                   	ret
    799f:	90                   	nop

00000000000079a0 <fwp_free_zombie>:
    79a0:	48 8b 15 49 3e 06 00 	mov    0x63e49(%rip),%rdx        # 6b7f0 <fwp_zombie>
    79a7:	48 85 d2             	test   %rdx,%rdx
    79aa:	0f 84 98 00 00 00    	je     7a48 <fwp_free_zombie+0xa8>
    79b0:	48 3b 15 49 3e 06 00 	cmp    0x63e49(%rip),%rdx        # 6b800 <fwp_cur>
    79b7:	0f 84 8b 00 00 00    	je     7a48 <fwp_free_zombie+0xa8>
    79bd:	48 83 ec 18          	sub    $0x18,%rsp
    79c1:	48 63 05 0c 38 06 00 	movslq 0x6380c(%rip),%rax        # 6b1d4 <fwp_stack_pool_n>
    79c8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    79cc:	83 f8 3f             	cmp    $0x3f,%eax
    79cf:	7f 7f                	jg     7a50 <fwp_free_zombie+0xb0>
    79d1:	8d 48 01             	lea    0x1(%rax),%ecx
    79d4:	89 0d fa 37 06 00    	mov    %ecx,0x637fa(%rip)        # 6b1d4 <fwp_stack_pool_n>
    79da:	48 8d 0d ff 37 06 00 	lea    0x637ff(%rip),%rcx        # 6b1e0 <fwp_stack_pool>
    79e1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    79e5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    79ec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    79f0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    79f7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    79fb:	48 85 c9             	test   %rcx,%rcx
    79fe:	0f 84 fc 00 00 00    	je     7b00 <fwp_free_zombie+0x160>
    7a04:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    7a0b:	48 85 c0             	test   %rax,%rax
    7a0e:	74 07                	je     7a17 <fwp_free_zombie+0x77>
    7a10:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7a17:	8b 42 5c             	mov    0x5c(%rdx),%eax
    7a1a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7a1e:	48 c7 05 c7 3d 06 00 	movq   $0x0,0x63dc7(%rip)        # 6b7f0 <fwp_zombie>
    7a25:	00 00 00 00 
    7a29:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7a30:	85 c0                	test   %eax,%eax
    7a32:	74 34                	je     7a68 <fwp_free_zombie+0xc8>
    7a34:	83 f8 01             	cmp    $0x1,%eax
    7a37:	0f 84 b3 00 00 00    	je     7af0 <fwp_free_zombie+0x150>
    7a3d:	48 83 c4 18          	add    $0x18,%rsp
    7a41:	c3                   	ret
    7a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a48:	c3                   	ret
    7a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a50:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7a54:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7a59:	e8 62 bb ff ff       	call   35c0 <munmap@plt>
    7a5e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7a63:	eb 80                	jmp    79e5 <fwp_free_zombie+0x45>
    7a65:	0f 1f 00             	nopl   (%rax)
    7a68:	48 8b 0d 89 51 06 00 	mov    0x65189(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7a6f:	48 89 d0             	mov    %rdx,%rax
    7a72:	48 2b 05 57 51 06 00 	sub    0x65157(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7a79:	48 c1 e1 10          	shl    $0x10,%rcx
    7a7d:	48 39 c8             	cmp    %rcx,%rax
    7a80:	73 bb                	jae    7a3d <fwp_free_zombie+0x9d>
    7a82:	48 89 c1             	mov    %rax,%rcx
    7a85:	48 c1 e9 10          	shr    $0x10,%rcx
    7a89:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7a8d:	48 8b 0d 84 51 06 00 	mov    0x65184(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7a94:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7a98:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7a9c:	48 85 c9             	test   %rcx,%rcx
    7a9f:	74 9c                	je     7a3d <fwp_free_zombie+0x9d>
    7aa1:	0f b6 3e             	movzbl (%rsi),%edi
    7aa4:	40 80 ff 02          	cmp    $0x2,%dil
    7aa8:	74 66                	je     7b10 <fwp_free_zombie+0x170>
    7aaa:	40 80 ff 01          	cmp    $0x1,%dil
    7aae:	75 8d                	jne    7a3d <fwp_free_zombie+0x9d>
    7ab0:	8b 7e 18             	mov    0x18(%rsi),%edi
    7ab3:	0f b7 c0             	movzwl %ax,%eax
    7ab6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7ab9:	48 0f af c7          	imul   %rdi,%rax
    7abd:	48 c1 e8 20          	shr    $0x20,%rax
    7ac1:	48 39 f0             	cmp    %rsi,%rax
    7ac4:	0f 83 73 ff ff ff    	jae    7a3d <fwp_free_zombie+0x9d>
    7aca:	48 01 c1             	add    %rax,%rcx
    7acd:	0f b6 01             	movzbl (%rcx),%eax
    7ad0:	84 c0                	test   %al,%al
    7ad2:	0f 84 65 ff ff ff    	je     7a3d <fwp_free_zombie+0x9d>
    7ad8:	3c 01                	cmp    $0x1,%al
    7ada:	74 14                	je     7af0 <fwp_free_zombie+0x150>
    7adc:	3c ff                	cmp    $0xff,%al
    7ade:	74 3b                	je     7b1b <fwp_free_zombie+0x17b>
    7ae0:	83 e8 01             	sub    $0x1,%eax
    7ae3:	88 01                	mov    %al,(%rcx)
    7ae5:	e9 53 ff ff ff       	jmp    7a3d <fwp_free_zombie+0x9d>
    7aea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7af0:	48 89 d7             	mov    %rdx,%rdi
    7af3:	48 83 c4 18          	add    $0x18,%rsp
    7af7:	e9 c4 fd ff ff       	jmp    78c0 <fwp_task_dispose>
    7afc:	0f 1f 40 00          	nopl   0x0(%rax)
    7b00:	48 89 05 c1 3c 06 00 	mov    %rax,0x63cc1(%rip)        # 6b7c8 <fwp_tasks_active>
    7b07:	e9 ff fe ff ff       	jmp    7a0b <fwp_free_zombie+0x6b>
    7b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    7b10:	66 85 c0             	test   %ax,%ax
    7b13:	0f 85 24 ff ff ff    	jne    7a3d <fwp_free_zombie+0x9d>
    7b19:	eb b2                	jmp    7acd <fwp_free_zombie+0x12d>
    7b1b:	48 89 ca             	mov    %rcx,%rdx
    7b1e:	48 8d 35 fb 3c 06 00 	lea    0x63cfb(%rip),%rsi        # 6b820 <fwp_heap>
    7b25:	48 c1 ea 11          	shr    $0x11,%rdx
    7b29:	48 31 ca             	xor    %rcx,%rdx
    7b2c:	48 89 d0             	mov    %rdx,%rax
    7b2f:	48 c1 e8 09          	shr    $0x9,%rax
    7b33:	48 31 c2             	xor    %rax,%rdx
    7b36:	0f b6 d2             	movzbl %dl,%edx
    7b39:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7b40:	00 
    7b41:	48 85 c0             	test   %rax,%rax
    7b44:	75 23                	jne    7b69 <fwp_free_zombie+0x1c9>
    7b46:	eb 5c                	jmp    7ba4 <fwp_free_zombie+0x204>
    7b48:	66 90                	xchg   %ax,%ax
    7b4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b51:	00 00 00 00 
    7b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b5c:	00 00 00 00 
    7b60:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7b64:	48 85 c0             	test   %rax,%rax
    7b67:	74 3b                	je     7ba4 <fwp_free_zombie+0x204>
    7b69:	48 89 c2             	mov    %rax,%rdx
    7b6c:	48 39 08             	cmp    %rcx,(%rax)
    7b6f:	75 ef                	jne    7b60 <fwp_free_zombie+0x1c0>
    7b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b75:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7b79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7b7d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7b84:	0f 85 b3 fe ff ff    	jne    7a3d <fwp_free_zombie+0x9d>
    7b8a:	48 89 cf             	mov    %rcx,%rdi
    7b8d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b92:	e8 39 dc ff ff       	call   57d0 <fwp_rc_forget_slot>
    7b97:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7b9c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7b9f:	e9 99 fe ff ff       	jmp    7a3d <fwp_free_zombie+0x9d>
    7ba4:	48 8d 3d 45 7e 00 00 	lea    0x7e45(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    7bab:	e8 a0 c8 ff ff       	call   4450 <fwp_trap>

0000000000007bb0 <fwp_block>:
    7bb0:	48 83 ec 08          	sub    $0x8,%rsp
    7bb4:	48 8b 05 2d 3c 06 00 	mov    0x63c2d(%rip),%rax        # 6b7e8 <fwp_ready_head>
    7bbb:	48 85 c0             	test   %rax,%rax
    7bbe:	0f 84 1c 01 00 00    	je     7ce0 <fwp_block+0x130>
    7bc4:	90                   	nop
    7bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bcc:	00 00 00 00 
    7bd0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7bd7:	48 89 15 0a 3c 06 00 	mov    %rdx,0x63c0a(%rip)        # 6b7e8 <fwp_ready_head>
    7bde:	48 85 d2             	test   %rdx,%rdx
    7be1:	0f 84 19 01 00 00    	je     7d00 <fwp_block+0x150>
    7be7:	48 8b 15 12 3c 06 00 	mov    0x63c12(%rip),%rdx        # 6b800 <fwp_cur>
    7bee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7bf2:	48 39 c2             	cmp    %rax,%rdx
    7bf5:	0f 84 d5 00 00 00    	je     7cd0 <fwp_block+0x120>
    7bfb:	48 8b 0d 86 58 06 00 	mov    0x65886(%rip),%rcx        # 6d488 <fwp_state_owners>
    7c02:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7c06:	48 89 05 f3 3b 06 00 	mov    %rax,0x63bf3(%rip)        # 6b800 <fwp_cur>
    7c0d:	f3 0f 7e 05 9b 58 06 	movq   0x6589b(%rip),%xmm0        # 6d4b0 <fwp_foreign_callbacks>
    7c14:	00 
    7c15:	0f 16 05 84 58 06 00 	movhps 0x65884(%rip),%xmm0        # 6d4a0 <fwp_state>
    7c1c:	f3 0f 7e 0d 84 58 06 	movq   0x65884(%rip),%xmm1        # 6d4a8 <fwp_handlers>
    7c23:	00 
    7c24:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7c2b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7c32:	0f 16 0d 7f 58 06 00 	movhps 0x6587f(%rip),%xmm1        # 6d4b8 <fwp_cleanups>
    7c39:	f3 0f 7e 05 57 58 06 	movq   0x65857(%rip),%xmm0        # 6d498 <fwp_state_len>
    7c40:	00 
    7c41:	0f 16 05 48 58 06 00 	movhps 0x65848(%rip),%xmm0        # 6d490 <fwp_state_cap>
    7c48:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7c4f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7c56:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7c5a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7c61:	48 89 0d 40 58 06 00 	mov    %rcx,0x65840(%rip)        # 6d4a8 <fwp_handlers>
    7c68:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7c6f:	48 89 0d 42 58 06 00 	mov    %rcx,0x65842(%rip)        # 6d4b8 <fwp_cleanups>
    7c76:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7c7d:	48 89 0d 2c 58 06 00 	mov    %rcx,0x6582c(%rip)        # 6d4b0 <fwp_foreign_callbacks>
    7c84:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7c8b:	48 89 0d 0e 58 06 00 	mov    %rcx,0x6580e(%rip)        # 6d4a0 <fwp_state>
    7c92:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7c99:	48 89 0d f8 57 06 00 	mov    %rcx,0x657f8(%rip)        # 6d498 <fwp_state_len>
    7ca0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7ca7:	48 89 0d e2 57 06 00 	mov    %rcx,0x657e2(%rip)        # 6d490 <fwp_state_cap>
    7cae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7cb5:	48 89 0d cc 57 06 00 	mov    %rcx,0x657cc(%rip)        # 6d488 <fwp_state_owners>
    7cbc:	e8 bf b7 ff ff       	call   3480 <swapcontext@plt>
    7cc1:	f3 0f 1e fa          	endbr64
    7cc5:	e8 d6 fc ff ff       	call   79a0 <fwp_free_zombie>
    7cca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cd0:	8b 05 fa 34 06 00    	mov    0x634fa(%rip),%eax        # 6b1d0 <fwp_slice>
    7cd6:	85 c0                	test   %eax,%eax
    7cd8:	74 36                	je     7d10 <fwp_block+0x160>
    7cda:	48 83 c4 08          	add    $0x8,%rsp
    7cde:	c3                   	ret
    7cdf:	90                   	nop
    7ce0:	e8 2b d7 ff ff       	call   5410 <fwp_poll_events>
    7ce5:	48 8b 05 fc 3a 06 00 	mov    0x63afc(%rip),%rax        # 6b7e8 <fwp_ready_head>
    7cec:	48 85 c0             	test   %rax,%rax
    7cef:	0f 85 db fe ff ff    	jne    7bd0 <fwp_block+0x20>
    7cf5:	eb e9                	jmp    7ce0 <fwp_block+0x130>
    7cf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7cfe:	00 00 
    7d00:	48 c7 05 d5 3a 06 00 	movq   $0x0,0x63ad5(%rip)        # 6b7e0 <fwp_ready_tail>
    7d07:	00 00 00 00 
    7d0b:	e9 d7 fe ff ff       	jmp    7be7 <fwp_block+0x37>
    7d10:	48 8d 3d c8 74 00 00 	lea    0x74c8(%rip),%rdi        # f1df <_IO_stdin_used+0x1df>
    7d17:	e8 74 b6 ff ff       	call   3390 <getenv@plt>
    7d1c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7d21:	48 85 c0             	test   %rax,%rax
    7d24:	74 05                	je     7d2b <fwp_block+0x17b>
    7d26:	80 38 00             	cmpb   $0x0,(%rax)
    7d29:	75 0b                	jne    7d36 <fwp_block+0x186>
    7d2b:	89 15 9f 34 06 00    	mov    %edx,0x6349f(%rip)        # 6b1d0 <fwp_slice>
    7d31:	48 83 c4 08          	add    $0x8,%rsp
    7d35:	c3                   	ret
    7d36:	ba 0a 00 00 00       	mov    $0xa,%edx
    7d3b:	31 f6                	xor    %esi,%esi
    7d3d:	48 89 c7             	mov    %rax,%rdi
    7d40:	e8 fb b7 ff ff       	call   3540 <strtoll@plt>
    7d45:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7d49:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7d50:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7d55:	0f 46 d0             	cmovbe %eax,%edx
    7d58:	eb d1                	jmp    7d2b <fwp_block+0x17b>
    7d5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007d60 <fwp_caps173>:
    7d60:	f3 0f 1e fa          	endbr64
    7d64:	85 f6                	test   %esi,%esi
    7d66:	74 08                	je     7d70 <fwp_caps173+0x10>
    7d68:	c3                   	ret
    7d69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7d70:	48 8b 15 81 4e 06 00 	mov    0x64e81(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7d77:	48 89 f8             	mov    %rdi,%rax
    7d7a:	48 2b 05 4f 4e 06 00 	sub    0x64e4f(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7d81:	48 c1 e2 10          	shl    $0x10,%rdx
    7d85:	48 39 d0             	cmp    %rdx,%rax
    7d88:	73 de                	jae    7d68 <fwp_caps173+0x8>
    7d8a:	48 89 c2             	mov    %rax,%rdx
    7d8d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d95:	48 8b 15 7c 4e 06 00 	mov    0x64e7c(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7d9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7da0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7da4:	48 85 c9             	test   %rcx,%rcx
    7da7:	74 bf                	je     7d68 <fwp_caps173+0x8>
    7da9:	0f b6 32             	movzbl (%rdx),%esi
    7dac:	40 80 fe 02          	cmp    $0x2,%sil
    7db0:	74 2e                	je     7de0 <fwp_caps173+0x80>
    7db2:	40 80 fe 01          	cmp    $0x1,%sil
    7db6:	75 b0                	jne    7d68 <fwp_caps173+0x8>
    7db8:	8b 72 18             	mov    0x18(%rdx),%esi
    7dbb:	0f b7 c0             	movzwl %ax,%eax
    7dbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7dc1:	48 0f af c6          	imul   %rsi,%rax
    7dc5:	48 c1 e8 20          	shr    $0x20,%rax
    7dc9:	48 39 d0             	cmp    %rdx,%rax
    7dcc:	73 9a                	jae    7d68 <fwp_caps173+0x8>
    7dce:	48 01 c1             	add    %rax,%rcx
    7dd1:	80 39 01             	cmpb   $0x1,(%rcx)
    7dd4:	75 92                	jne    7d68 <fwp_caps173+0x8>
    7dd6:	e9 35 dc ff ff       	jmp    5a10 <fwp_mem_free>
    7ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7de0:	66 85 c0             	test   %ax,%ax
    7de3:	74 ec                	je     7dd1 <fwp_caps173+0x71>
    7de5:	c3                   	ret
    7de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7ded:	00 00 00 

0000000000007df0 <fwp_args37>:
    7df0:	f3 0f 1e fa          	endbr64
    7df4:	85 d2                	test   %edx,%edx
    7df6:	74 04                	je     7dfc <fwp_args37+0xc>
    7df8:	85 f6                	test   %esi,%esi
    7dfa:	74 04                	je     7e00 <fwp_args37+0x10>
    7dfc:	c3                   	ret
    7dfd:	0f 1f 00             	nopl   (%rax)
    7e00:	48 8b 15 f1 4d 06 00 	mov    0x64df1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    7e07:	48 8b 07             	mov    (%rdi),%rax
    7e0a:	48 2b 05 bf 4d 06 00 	sub    0x64dbf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    7e11:	48 c1 e2 10          	shl    $0x10,%rdx
    7e15:	48 39 d0             	cmp    %rdx,%rax
    7e18:	73 e2                	jae    7dfc <fwp_args37+0xc>
    7e1a:	48 89 c2             	mov    %rax,%rdx
    7e1d:	48 c1 ea 10          	shr    $0x10,%rdx
    7e21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e25:	48 8b 15 ec 4d 06 00 	mov    0x64dec(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    7e2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e30:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7e34:	48 85 ff             	test   %rdi,%rdi
    7e37:	74 c3                	je     7dfc <fwp_args37+0xc>
    7e39:	0f b6 0a             	movzbl (%rdx),%ecx
    7e3c:	80 f9 02             	cmp    $0x2,%cl
    7e3f:	74 4f                	je     7e90 <fwp_args37+0xa0>
    7e41:	80 f9 01             	cmp    $0x1,%cl
    7e44:	75 b6                	jne    7dfc <fwp_args37+0xc>
    7e46:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e49:	0f b7 c0             	movzwl %ax,%eax
    7e4c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e4f:	48 0f af c1          	imul   %rcx,%rax
    7e53:	48 c1 e8 20          	shr    $0x20,%rax
    7e57:	48 39 d0             	cmp    %rdx,%rax
    7e5a:	73 a0                	jae    7dfc <fwp_args37+0xc>
    7e5c:	48 01 c7             	add    %rax,%rdi
    7e5f:	0f b6 07             	movzbl (%rdi),%eax
    7e62:	84 c0                	test   %al,%al
    7e64:	74 96                	je     7dfc <fwp_args37+0xc>
    7e66:	8b 15 7c 56 06 00    	mov    0x6567c(%rip),%edx        # 6d4e8 <iteration_active>
    7e6c:	85 d2                	test   %edx,%edx
    7e6e:	75 10                	jne    7e80 <fwp_args37+0x90>
    7e70:	3c fd                	cmp    $0xfd,%al
    7e72:	77 22                	ja     7e96 <fwp_args37+0xa6>
    7e74:	83 c0 01             	add    $0x1,%eax
    7e77:	88 07                	mov    %al,(%rdi)
    7e79:	c3                   	ret
    7e7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e80:	48 83 05 48 56 06 00 	addq   $0x1,0x65648(%rip)        # 6d4d0 <iteration_retains>
    7e87:	01 
    7e88:	eb e6                	jmp    7e70 <fwp_args37+0x80>
    7e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7e90:	66 85 c0             	test   %ax,%ax
    7e93:	74 ca                	je     7e5f <fwp_args37+0x6f>
    7e95:	c3                   	ret
    7e96:	e9 15 d8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7e9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007ea0 <fwp_caps37>:
    7ea0:	f3 0f 1e fa          	endbr64
    7ea4:	48 83 ec 18          	sub    $0x18,%rsp
    7ea8:	48 89 f8             	mov    %rdi,%rax
    7eab:	8b 7f 04             	mov    0x4(%rdi),%edi
    7eae:	85 ff                	test   %edi,%edi
    7eb0:	0f 84 9a 00 00 00    	je     7f50 <fwp_caps37+0xb0>
    7eb6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7eba:	85 f6                	test   %esi,%esi
    7ebc:	0f 85 9e 00 00 00    	jne    7f60 <fwp_caps37+0xc0>
    7ec2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7ec7:	e8 24 f7 ff ff       	call   75f0 <fwp_drop4>
    7ecc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7ed1:	48 8b 0d 20 4d 06 00 	mov    0x64d20(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    7ed8:	48 89 c2             	mov    %rax,%rdx
    7edb:	48 2b 15 ee 4c 06 00 	sub    0x64cee(%rip),%rdx        # 6cbd0 <fwp_heap+0x13b0>
    7ee2:	48 c1 e1 10          	shl    $0x10,%rcx
    7ee6:	48 39 ca             	cmp    %rcx,%rdx
    7ee9:	73 6d                	jae    7f58 <fwp_caps37+0xb8>
    7eeb:	48 89 d1             	mov    %rdx,%rcx
    7eee:	48 c1 e9 10          	shr    $0x10,%rcx
    7ef2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7ef6:	48 8b 0d 1b 4d 06 00 	mov    0x64d1b(%rip),%rcx        # 6cc18 <fwp_heap+0x13f8>
    7efd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7f01:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7f05:	48 85 f6             	test   %rsi,%rsi
    7f08:	74 4e                	je     7f58 <fwp_caps37+0xb8>
    7f0a:	0f b6 39             	movzbl (%rcx),%edi
    7f0d:	40 80 ff 02          	cmp    $0x2,%dil
    7f11:	0f 84 c9 00 00 00    	je     7fe0 <fwp_caps37+0x140>
    7f17:	40 80 ff 01          	cmp    $0x1,%dil
    7f1b:	75 3b                	jne    7f58 <fwp_caps37+0xb8>
    7f1d:	8b 79 18             	mov    0x18(%rcx),%edi
    7f20:	0f b7 d2             	movzwl %dx,%edx
    7f23:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7f26:	48 0f af d7          	imul   %rdi,%rdx
    7f2a:	48 c1 ea 20          	shr    $0x20,%rdx
    7f2e:	48 39 ca             	cmp    %rcx,%rdx
    7f31:	73 25                	jae    7f58 <fwp_caps37+0xb8>
    7f33:	48 01 d6             	add    %rdx,%rsi
    7f36:	80 3e 01             	cmpb   $0x1,(%rsi)
    7f39:	75 1d                	jne    7f58 <fwp_caps37+0xb8>
    7f3b:	48 89 c7             	mov    %rax,%rdi
    7f3e:	48 83 c4 18          	add    $0x18,%rsp
    7f42:	e9 c9 da ff ff       	jmp    5a10 <fwp_mem_free>
    7f47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f4e:	00 00 
    7f50:	85 f6                	test   %esi,%esi
    7f52:	0f 84 79 ff ff ff    	je     7ed1 <fwp_caps37+0x31>
    7f58:	48 83 c4 18          	add    $0x18,%rsp
    7f5c:	c3                   	ret
    7f5d:	0f 1f 00             	nopl   (%rax)
    7f60:	48 8b 05 91 4c 06 00 	mov    0x64c91(%rip),%rax        # 6cbf8 <fwp_heap+0x13d8>
    7f67:	48 2b 3d 62 4c 06 00 	sub    0x64c62(%rip),%rdi        # 6cbd0 <fwp_heap+0x13b0>
    7f6e:	48 c1 e0 10          	shl    $0x10,%rax
    7f72:	48 39 c7             	cmp    %rax,%rdi
    7f75:	73 e1                	jae    7f58 <fwp_caps37+0xb8>
    7f77:	48 89 f8             	mov    %rdi,%rax
    7f7a:	48 c1 e8 10          	shr    $0x10,%rax
    7f7e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7f82:	48 8b 05 8f 4c 06 00 	mov    0x64c8f(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    7f89:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7f8d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7f91:	48 85 c0             	test   %rax,%rax
    7f94:	74 c2                	je     7f58 <fwp_caps37+0xb8>
    7f96:	0f b6 0a             	movzbl (%rdx),%ecx
    7f99:	80 f9 02             	cmp    $0x2,%cl
    7f9c:	74 52                	je     7ff0 <fwp_caps37+0x150>
    7f9e:	80 f9 01             	cmp    $0x1,%cl
    7fa1:	75 b5                	jne    7f58 <fwp_caps37+0xb8>
    7fa3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fa6:	0f b7 ff             	movzwl %di,%edi
    7fa9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fac:	48 0f af f9          	imul   %rcx,%rdi
    7fb0:	48 c1 ef 20          	shr    $0x20,%rdi
    7fb4:	48 39 d7             	cmp    %rdx,%rdi
    7fb7:	73 9f                	jae    7f58 <fwp_caps37+0xb8>
    7fb9:	48 01 f8             	add    %rdi,%rax
    7fbc:	0f b6 10             	movzbl (%rax),%edx
    7fbf:	84 d2                	test   %dl,%dl
    7fc1:	74 95                	je     7f58 <fwp_caps37+0xb8>
    7fc3:	8b 0d 1f 55 06 00    	mov    0x6551f(%rip),%ecx        # 6d4e8 <iteration_active>
    7fc9:	85 c9                	test   %ecx,%ecx
    7fcb:	75 33                	jne    8000 <fwp_caps37+0x160>
    7fcd:	80 fa fd             	cmp    $0xfd,%dl
    7fd0:	77 38                	ja     800a <fwp_caps37+0x16a>
    7fd2:	83 c2 01             	add    $0x1,%edx
    7fd5:	88 10                	mov    %dl,(%rax)
    7fd7:	e9 7c ff ff ff       	jmp    7f58 <fwp_caps37+0xb8>
    7fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    7fe0:	66 85 d2             	test   %dx,%dx
    7fe3:	0f 85 6f ff ff ff    	jne    7f58 <fwp_caps37+0xb8>
    7fe9:	e9 48 ff ff ff       	jmp    7f36 <fwp_caps37+0x96>
    7fee:	66 90                	xchg   %ax,%ax
    7ff0:	66 85 ff             	test   %di,%di
    7ff3:	0f 85 5f ff ff ff    	jne    7f58 <fwp_caps37+0xb8>
    7ff9:	eb c1                	jmp    7fbc <fwp_caps37+0x11c>
    7ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8000:	48 83 05 c8 54 06 00 	addq   $0x1,0x654c8(%rip)        # 6d4d0 <iteration_retains>
    8007:	01 
    8008:	eb c3                	jmp    7fcd <fwp_caps37+0x12d>
    800a:	48 89 c7             	mov    %rax,%rdi
    800d:	48 83 c4 18          	add    $0x18,%rsp
    8011:	e9 9a d6 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    8016:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    801d:	00 00 00 

0000000000008020 <fwp_drop0>:
    8020:	f3 0f 1e fa          	endbr64
    8024:	48 8b 15 cd 4b 06 00 	mov    0x64bcd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    802b:	48 89 f8             	mov    %rdi,%rax
    802e:	48 2b 05 9b 4b 06 00 	sub    0x64b9b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8035:	48 c1 e2 10          	shl    $0x10,%rdx
    8039:	48 39 d0             	cmp    %rdx,%rax
    803c:	0f 83 36 01 00 00    	jae    8178 <fwp_drop0+0x158>
    8042:	48 83 ec 18          	sub    $0x18,%rsp
    8046:	48 8d 35 d3 37 06 00 	lea    0x637d3(%rip),%rsi        # 6b820 <fwp_heap>
    804d:	48 89 c2             	mov    %rax,%rdx
    8050:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    8057:	48 c1 ea 10          	shr    $0x10,%rdx
    805b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    805f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    8063:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8067:	48 85 d2             	test   %rdx,%rdx
    806a:	74 42                	je     80ae <fwp_drop0+0x8e>
    806c:	44 0f b6 01          	movzbl (%rcx),%r8d
    8070:	41 80 f8 02          	cmp    $0x2,%r8b
    8074:	74 42                	je     80b8 <fwp_drop0+0x98>
    8076:	41 80 f8 01          	cmp    $0x1,%r8b
    807a:	75 32                	jne    80ae <fwp_drop0+0x8e>
    807c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    8080:	0f b7 c0             	movzwl %ax,%eax
    8083:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8086:	49 0f af c0          	imul   %r8,%rax
    808a:	48 c1 e8 20          	shr    $0x20,%rax
    808e:	48 39 c8             	cmp    %rcx,%rax
    8091:	73 1b                	jae    80ae <fwp_drop0+0x8e>
    8093:	48 01 c2             	add    %rax,%rdx
    8096:	0f b6 02             	movzbl (%rdx),%eax
    8099:	84 c0                	test   %al,%al
    809b:	74 11                	je     80ae <fwp_drop0+0x8e>
    809d:	3c 01                	cmp    $0x1,%al
    809f:	74 27                	je     80c8 <fwp_drop0+0xa8>
    80a1:	3c ff                	cmp    $0xff,%al
    80a3:	0f 84 e7 00 00 00    	je     8190 <fwp_drop0+0x170>
    80a9:	83 e8 01             	sub    $0x1,%eax
    80ac:	88 02                	mov    %al,(%rdx)
    80ae:	48 83 c4 18          	add    $0x18,%rsp
    80b2:	c3                   	ret
    80b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    80b8:	66 85 c0             	test   %ax,%ax
    80bb:	74 d9                	je     8096 <fwp_drop0+0x76>
    80bd:	48 83 c4 18          	add    $0x18,%rsp
    80c1:	c3                   	ret
    80c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    80c8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    80cf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    80d6:	48 89 f8             	mov    %rdi,%rax
    80d9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    80dd:	48 29 c8             	sub    %rcx,%rax
    80e0:	48 c1 e2 10          	shl    $0x10,%rdx
    80e4:	48 39 d0             	cmp    %rdx,%rax
    80e7:	73 71                	jae    815a <fwp_drop0+0x13a>
    80e9:	49 89 c2             	mov    %rax,%r10
    80ec:	49 c1 ea 10          	shr    $0x10,%r10
    80f0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    80f4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    80f8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    80fc:	4d 85 d2             	test   %r10,%r10
    80ff:	74 59                	je     815a <fwp_drop0+0x13a>
    8101:	45 0f b6 19          	movzbl (%r9),%r11d
    8105:	41 80 fb 02          	cmp    $0x2,%r11b
    8109:	74 75                	je     8180 <fwp_drop0+0x160>
    810b:	41 80 fb 01          	cmp    $0x1,%r11b
    810f:	75 49                	jne    815a <fwp_drop0+0x13a>
    8111:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8115:	0f b7 c0             	movzwl %ax,%eax
    8118:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    811c:	49 0f af c3          	imul   %r11,%rax
    8120:	48 c1 e8 20          	shr    $0x20,%rax
    8124:	4c 39 c8             	cmp    %r9,%rax
    8127:	73 31                	jae    815a <fwp_drop0+0x13a>
    8129:	49 01 c2             	add    %rax,%r10
    812c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8130:	75 28                	jne    815a <fwp_drop0+0x13a>
    8132:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8137:	e8 d4 d8 ff ff       	call   5a10 <fwp_mem_free>
    813c:	48 8d 35 dd 36 06 00 	lea    0x636dd(%rip),%rsi        # 6b820 <fwp_heap>
    8143:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8148:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    814f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8156:	48 c1 e2 10          	shl    $0x10,%rdx
    815a:	4c 89 c0             	mov    %r8,%rax
    815d:	48 29 c8             	sub    %rcx,%rax
    8160:	48 39 d0             	cmp    %rdx,%rax
    8163:	0f 83 45 ff ff ff    	jae    80ae <fwp_drop0+0x8e>
    8169:	4c 89 c7             	mov    %r8,%rdi
    816c:	e9 dc fe ff ff       	jmp    804d <fwp_drop0+0x2d>
    8171:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8178:	c3                   	ret
    8179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8180:	66 85 c0             	test   %ax,%ax
    8183:	75 d5                	jne    815a <fwp_drop0+0x13a>
    8185:	eb a5                	jmp    812c <fwp_drop0+0x10c>
    8187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    818e:	00 00 
    8190:	48 89 d0             	mov    %rdx,%rax
    8193:	48 c1 e8 11          	shr    $0x11,%rax
    8197:	48 31 d0             	xor    %rdx,%rax
    819a:	48 89 c1             	mov    %rax,%rcx
    819d:	48 c1 e9 09          	shr    $0x9,%rcx
    81a1:	48 31 c8             	xor    %rcx,%rax
    81a4:	0f b6 c8             	movzbl %al,%ecx
    81a7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    81ae:	00 
    81af:	48 85 c0             	test   %rax,%rax
    81b2:	75 15                	jne    81c9 <fwp_drop0+0x1a9>
    81b4:	eb 4e                	jmp    8204 <fwp_drop0+0x1e4>
    81b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    81bd:	00 00 00 
    81c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    81c4:	48 85 c0             	test   %rax,%rax
    81c7:	74 3b                	je     8204 <fwp_drop0+0x1e4>
    81c9:	48 89 c1             	mov    %rax,%rcx
    81cc:	48 39 10             	cmp    %rdx,(%rax)
    81cf:	75 ef                	jne    81c0 <fwp_drop0+0x1a0>
    81d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    81d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    81d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    81dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    81e4:	0f 85 c4 fe ff ff    	jne    80ae <fwp_drop0+0x8e>
    81ea:	48 89 d7             	mov    %rdx,%rdi
    81ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    81f2:	e8 d9 d5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    81f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    81fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    81ff:	e9 aa fe ff ff       	jmp    80ae <fwp_drop0+0x8e>
    8204:	48 8d 3d e5 77 00 00 	lea    0x77e5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    820b:	e8 40 c2 ff ff       	call   4450 <fwp_trap>

0000000000008210 <fwp_drop1>:
    8210:	f3 0f 1e fa          	endbr64
    8214:	48 8b 15 dd 49 06 00 	mov    0x649dd(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    821b:	48 89 f8             	mov    %rdi,%rax
    821e:	48 2b 05 ab 49 06 00 	sub    0x649ab(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8225:	48 c1 e2 10          	shl    $0x10,%rdx
    8229:	48 39 d0             	cmp    %rdx,%rax
    822c:	0f 83 36 01 00 00    	jae    8368 <fwp_drop1+0x158>
    8232:	48 83 ec 18          	sub    $0x18,%rsp
    8236:	48 8d 35 e3 35 06 00 	lea    0x635e3(%rip),%rsi        # 6b820 <fwp_heap>
    823d:	48 89 c2             	mov    %rax,%rdx
    8240:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    8247:	48 c1 ea 10          	shr    $0x10,%rdx
    824b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    824f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    8253:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8257:	48 85 d2             	test   %rdx,%rdx
    825a:	74 42                	je     829e <fwp_drop1+0x8e>
    825c:	44 0f b6 01          	movzbl (%rcx),%r8d
    8260:	41 80 f8 02          	cmp    $0x2,%r8b
    8264:	74 42                	je     82a8 <fwp_drop1+0x98>
    8266:	41 80 f8 01          	cmp    $0x1,%r8b
    826a:	75 32                	jne    829e <fwp_drop1+0x8e>
    826c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    8270:	0f b7 c0             	movzwl %ax,%eax
    8273:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8276:	49 0f af c0          	imul   %r8,%rax
    827a:	48 c1 e8 20          	shr    $0x20,%rax
    827e:	48 39 c8             	cmp    %rcx,%rax
    8281:	73 1b                	jae    829e <fwp_drop1+0x8e>
    8283:	48 01 c2             	add    %rax,%rdx
    8286:	0f b6 02             	movzbl (%rdx),%eax
    8289:	84 c0                	test   %al,%al
    828b:	74 11                	je     829e <fwp_drop1+0x8e>
    828d:	3c 01                	cmp    $0x1,%al
    828f:	74 27                	je     82b8 <fwp_drop1+0xa8>
    8291:	3c ff                	cmp    $0xff,%al
    8293:	0f 84 e7 00 00 00    	je     8380 <fwp_drop1+0x170>
    8299:	83 e8 01             	sub    $0x1,%eax
    829c:	88 02                	mov    %al,(%rdx)
    829e:	48 83 c4 18          	add    $0x18,%rsp
    82a2:	c3                   	ret
    82a3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    82a8:	66 85 c0             	test   %ax,%ax
    82ab:	74 d9                	je     8286 <fwp_drop1+0x76>
    82ad:	48 83 c4 18          	add    $0x18,%rsp
    82b1:	c3                   	ret
    82b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    82b8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    82bf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    82c6:	48 89 f8             	mov    %rdi,%rax
    82c9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    82cd:	48 29 c8             	sub    %rcx,%rax
    82d0:	48 c1 e2 10          	shl    $0x10,%rdx
    82d4:	48 39 d0             	cmp    %rdx,%rax
    82d7:	73 71                	jae    834a <fwp_drop1+0x13a>
    82d9:	49 89 c2             	mov    %rax,%r10
    82dc:	49 c1 ea 10          	shr    $0x10,%r10
    82e0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    82e4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    82e8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    82ec:	4d 85 d2             	test   %r10,%r10
    82ef:	74 59                	je     834a <fwp_drop1+0x13a>
    82f1:	45 0f b6 19          	movzbl (%r9),%r11d
    82f5:	41 80 fb 02          	cmp    $0x2,%r11b
    82f9:	74 75                	je     8370 <fwp_drop1+0x160>
    82fb:	41 80 fb 01          	cmp    $0x1,%r11b
    82ff:	75 49                	jne    834a <fwp_drop1+0x13a>
    8301:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8305:	0f b7 c0             	movzwl %ax,%eax
    8308:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    830c:	49 0f af c3          	imul   %r11,%rax
    8310:	48 c1 e8 20          	shr    $0x20,%rax
    8314:	4c 39 c8             	cmp    %r9,%rax
    8317:	73 31                	jae    834a <fwp_drop1+0x13a>
    8319:	49 01 c2             	add    %rax,%r10
    831c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8320:	75 28                	jne    834a <fwp_drop1+0x13a>
    8322:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8327:	e8 e4 d6 ff ff       	call   5a10 <fwp_mem_free>
    832c:	48 8d 35 ed 34 06 00 	lea    0x634ed(%rip),%rsi        # 6b820 <fwp_heap>
    8333:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8338:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    833f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8346:	48 c1 e2 10          	shl    $0x10,%rdx
    834a:	4c 89 c0             	mov    %r8,%rax
    834d:	48 29 c8             	sub    %rcx,%rax
    8350:	48 39 d0             	cmp    %rdx,%rax
    8353:	0f 83 45 ff ff ff    	jae    829e <fwp_drop1+0x8e>
    8359:	4c 89 c7             	mov    %r8,%rdi
    835c:	e9 dc fe ff ff       	jmp    823d <fwp_drop1+0x2d>
    8361:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8368:	c3                   	ret
    8369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8370:	66 85 c0             	test   %ax,%ax
    8373:	75 d5                	jne    834a <fwp_drop1+0x13a>
    8375:	eb a5                	jmp    831c <fwp_drop1+0x10c>
    8377:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    837e:	00 00 
    8380:	48 89 d0             	mov    %rdx,%rax
    8383:	48 c1 e8 11          	shr    $0x11,%rax
    8387:	48 31 d0             	xor    %rdx,%rax
    838a:	48 89 c1             	mov    %rax,%rcx
    838d:	48 c1 e9 09          	shr    $0x9,%rcx
    8391:	48 31 c8             	xor    %rcx,%rax
    8394:	0f b6 c8             	movzbl %al,%ecx
    8397:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    839e:	00 
    839f:	48 85 c0             	test   %rax,%rax
    83a2:	75 25                	jne    83c9 <fwp_drop1+0x1b9>
    83a4:	eb 5e                	jmp    8404 <fwp_drop1+0x1f4>
    83a6:	0f 1f 40 00          	nopl   0x0(%rax)
    83aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83b1:	00 00 00 00 
    83b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    83bc:	00 00 00 00 
    83c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    83c4:	48 85 c0             	test   %rax,%rax
    83c7:	74 3b                	je     8404 <fwp_drop1+0x1f4>
    83c9:	48 89 c1             	mov    %rax,%rcx
    83cc:	48 39 10             	cmp    %rdx,(%rax)
    83cf:	75 ef                	jne    83c0 <fwp_drop1+0x1b0>
    83d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    83d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    83d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    83dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    83e4:	0f 85 b4 fe ff ff    	jne    829e <fwp_drop1+0x8e>
    83ea:	48 89 d7             	mov    %rdx,%rdi
    83ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    83f2:	e8 d9 d3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    83f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    83fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    83ff:	e9 9a fe ff ff       	jmp    829e <fwp_drop1+0x8e>
    8404:	48 8d 3d e5 75 00 00 	lea    0x75e5(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    840b:	e8 40 c0 ff ff       	call   4450 <fwp_trap>

0000000000008410 <fwp_drop10>:
    8410:	48 8b 0d e1 47 06 00 	mov    0x647e1(%rip),%rcx        # 6cbf8 <fwp_heap+0x13d8>
    8417:	48 89 f8             	mov    %rdi,%rax
    841a:	48 2b 05 af 47 06 00 	sub    0x647af(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8421:	48 c1 e1 10          	shl    $0x10,%rcx
    8425:	48 39 c8             	cmp    %rcx,%rax
    8428:	0f 83 c2 01 00 00    	jae    85f0 <fwp_drop10+0x1e0>
    842e:	48 83 ec 18          	sub    $0x18,%rsp
    8432:	48 89 fa             	mov    %rdi,%rdx
    8435:	48 8d 35 e4 33 06 00 	lea    0x633e4(%rip),%rsi        # 6b820 <fwp_heap>
    843c:	48 89 c1             	mov    %rax,%rcx
    843f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8446:	48 c1 e9 10          	shr    $0x10,%rcx
    844a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    844e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8452:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8456:	48 85 c9             	test   %rcx,%rcx
    8459:	74 46                	je     84a1 <fwp_drop10+0x91>
    845b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    845f:	41 80 f9 02          	cmp    $0x2,%r9b
    8463:	0f 84 d7 00 00 00    	je     8540 <fwp_drop10+0x130>
    8469:	41 80 f9 01          	cmp    $0x1,%r9b
    846d:	75 32                	jne    84a1 <fwp_drop10+0x91>
    846f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    8473:	0f b7 c0             	movzwl %ax,%eax
    8476:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    8479:	49 0f af c1          	imul   %r9,%rax
    847d:	48 c1 e8 20          	shr    $0x20,%rax
    8481:	48 39 f8             	cmp    %rdi,%rax
    8484:	73 1b                	jae    84a1 <fwp_drop10+0x91>
    8486:	48 01 c1             	add    %rax,%rcx
    8489:	0f b6 01             	movzbl (%rcx),%eax
    848c:	84 c0                	test   %al,%al
    848e:	74 11                	je     84a1 <fwp_drop10+0x91>
    8490:	3c 01                	cmp    $0x1,%al
    8492:	74 1c                	je     84b0 <fwp_drop10+0xa0>
    8494:	3c ff                	cmp    $0xff,%al
    8496:	0f 84 5c 01 00 00    	je     85f8 <fwp_drop10+0x1e8>
    849c:	83 e8 01             	sub    $0x1,%eax
    849f:	88 01                	mov    %al,(%rcx)
    84a1:	48 83 c4 18          	add    $0x18,%rsp
    84a5:	c3                   	ret
    84a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    84ad:	00 00 00 
    84b0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    84b7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    84be:	48 89 d0             	mov    %rdx,%rax
    84c1:	49 89 d1             	mov    %rdx,%r9
    84c4:	48 c1 e1 10          	shl    $0x10,%rcx
    84c8:	48 29 f8             	sub    %rdi,%rax
    84cb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    84cf:	78 7f                	js     8550 <fwp_drop10+0x140>
    84d1:	48 39 c8             	cmp    %rcx,%rax
    84d4:	73 cb                	jae    84a1 <fwp_drop10+0x91>
    84d6:	48 89 c1             	mov    %rax,%rcx
    84d9:	48 c1 e9 10          	shr    $0x10,%rcx
    84dd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    84e1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    84e5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    84e9:	48 85 f6             	test   %rsi,%rsi
    84ec:	74 b3                	je     84a1 <fwp_drop10+0x91>
    84ee:	0f b6 39             	movzbl (%rcx),%edi
    84f1:	40 80 ff 02          	cmp    $0x2,%dil
    84f5:	74 39                	je     8530 <fwp_drop10+0x120>
    84f7:	40 80 ff 01          	cmp    $0x1,%dil
    84fb:	75 a4                	jne    84a1 <fwp_drop10+0x91>
    84fd:	8b 79 18             	mov    0x18(%rcx),%edi
    8500:	0f b7 c0             	movzwl %ax,%eax
    8503:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8506:	48 0f af c7          	imul   %rdi,%rax
    850a:	48 c1 e8 20          	shr    $0x20,%rax
    850e:	48 39 c8             	cmp    %rcx,%rax
    8511:	73 8e                	jae    84a1 <fwp_drop10+0x91>
    8513:	48 01 c6             	add    %rax,%rsi
    8516:	80 3e 01             	cmpb   $0x1,(%rsi)
    8519:	75 86                	jne    84a1 <fwp_drop10+0x91>
    851b:	48 89 d7             	mov    %rdx,%rdi
    851e:	48 83 c4 18          	add    $0x18,%rsp
    8522:	e9 e9 d4 ff ff       	jmp    5a10 <fwp_mem_free>
    8527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    852e:	00 00 
    8530:	66 85 c0             	test   %ax,%ax
    8533:	74 e1                	je     8516 <fwp_drop10+0x106>
    8535:	48 83 c4 18          	add    $0x18,%rsp
    8539:	c3                   	ret
    853a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8540:	66 85 c0             	test   %ax,%ax
    8543:	0f 84 40 ff ff ff    	je     8489 <fwp_drop10+0x79>
    8549:	48 83 c4 18          	add    $0x18,%rsp
    854d:	c3                   	ret
    854e:	66 90                	xchg   %ax,%ax
    8550:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8554:	48 39 c8             	cmp    %rcx,%rax
    8557:	73 74                	jae    85cd <fwp_drop10+0x1bd>
    8559:	49 89 c2             	mov    %rax,%r10
    855c:	49 c1 ea 10          	shr    $0x10,%r10
    8560:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8564:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    8568:	4d 8b 50 20          	mov    0x20(%r8),%r10
    856c:	4d 85 d2             	test   %r10,%r10
    856f:	74 5c                	je     85cd <fwp_drop10+0x1bd>
    8571:	45 0f b6 18          	movzbl (%r8),%r11d
    8575:	41 80 fb 02          	cmp    $0x2,%r11b
    8579:	74 6d                	je     85e8 <fwp_drop10+0x1d8>
    857b:	41 80 fb 01          	cmp    $0x1,%r11b
    857f:	75 4c                	jne    85cd <fwp_drop10+0x1bd>
    8581:	45 8b 58 18          	mov    0x18(%r8),%r11d
    8585:	0f b7 c0             	movzwl %ax,%eax
    8588:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    858c:	49 0f af c3          	imul   %r11,%rax
    8590:	48 c1 e8 20          	shr    $0x20,%rax
    8594:	4c 39 c0             	cmp    %r8,%rax
    8597:	73 34                	jae    85cd <fwp_drop10+0x1bd>
    8599:	49 01 c2             	add    %rax,%r10
    859c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    85a0:	75 2b                	jne    85cd <fwp_drop10+0x1bd>
    85a2:	4c 89 cf             	mov    %r9,%rdi
    85a5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    85aa:	e8 61 d4 ff ff       	call   5a10 <fwp_mem_free>
    85af:	48 8d 35 6a 32 06 00 	lea    0x6326a(%rip),%rsi        # 6b820 <fwp_heap>
    85b6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    85bb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    85c2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    85c9:	48 c1 e1 10          	shl    $0x10,%rcx
    85cd:	48 89 d0             	mov    %rdx,%rax
    85d0:	48 29 f8             	sub    %rdi,%rax
    85d3:	48 39 c8             	cmp    %rcx,%rax
    85d6:	0f 82 60 fe ff ff    	jb     843c <fwp_drop10+0x2c>
    85dc:	e9 c0 fe ff ff       	jmp    84a1 <fwp_drop10+0x91>
    85e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    85e8:	66 85 c0             	test   %ax,%ax
    85eb:	75 e0                	jne    85cd <fwp_drop10+0x1bd>
    85ed:	eb ad                	jmp    859c <fwp_drop10+0x18c>
    85ef:	90                   	nop
    85f0:	c3                   	ret
    85f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    85f8:	48 89 c8             	mov    %rcx,%rax
    85fb:	48 c1 e8 11          	shr    $0x11,%rax
    85ff:	48 31 c8             	xor    %rcx,%rax
    8602:	48 89 c2             	mov    %rax,%rdx
    8605:	48 c1 ea 09          	shr    $0x9,%rdx
    8609:	48 31 d0             	xor    %rdx,%rax
    860c:	0f b6 d0             	movzbl %al,%edx
    860f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8616:	00 
    8617:	48 85 c0             	test   %rax,%rax
    861a:	75 0d                	jne    8629 <fwp_drop10+0x219>
    861c:	eb 46                	jmp    8664 <fwp_drop10+0x254>
    861e:	66 90                	xchg   %ax,%ax
    8620:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8624:	48 85 c0             	test   %rax,%rax
    8627:	74 3b                	je     8664 <fwp_drop10+0x254>
    8629:	48 89 c2             	mov    %rax,%rdx
    862c:	48 39 08             	cmp    %rcx,(%rax)
    862f:	75 ef                	jne    8620 <fwp_drop10+0x210>
    8631:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8635:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8639:	48 89 50 08          	mov    %rdx,0x8(%rax)
    863d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8644:	0f 85 57 fe ff ff    	jne    84a1 <fwp_drop10+0x91>
    864a:	48 89 cf             	mov    %rcx,%rdi
    864d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8652:	e8 79 d1 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8657:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    865c:	c6 01 fe             	movb   $0xfe,(%rcx)
    865f:	e9 3d fe ff ff       	jmp    84a1 <fwp_drop10+0x91>
    8664:	48 8d 3d 85 73 00 00 	lea    0x7385(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    866b:	e8 e0 bd ff ff       	call   4450 <fwp_trap>

0000000000008670 <f37>:
    8670:	41 57                	push   %r15
    8672:	41 56                	push   %r14
    8674:	41 55                	push   %r13
    8676:	41 54                	push   %r12
    8678:	55                   	push   %rbp
    8679:	53                   	push   %rbx
    867a:	48 83 ec 38          	sub    $0x38,%rsp
    867e:	48 8b 15 73 45 06 00 	mov    0x64573(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8685:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    868a:	48 c1 e2 10          	shl    $0x10,%rdx
    868e:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    8695:	00 00 
    8697:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    869c:	48 8b 0d 2d 45 06 00 	mov    0x6452d(%rip),%rcx        # 6cbd0 <fwp_heap+0x13b0>
    86a3:	48 85 ff             	test   %rdi,%rdi
    86a6:	0f 84 5e 03 00 00    	je     8a0a <f37+0x39a>
    86ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    86b1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    86b5:	4c 89 e8             	mov    %r13,%rax
    86b8:	48 29 c8             	sub    %rcx,%rax
    86bb:	48 39 d0             	cmp    %rdx,%rax
    86be:	0f 83 2c 03 00 00    	jae    89f0 <f37+0x380>
    86c4:	48 89 c2             	mov    %rax,%rdx
    86c7:	48 c1 ea 10          	shr    $0x10,%rdx
    86cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86cf:	48 8b 15 42 45 06 00 	mov    0x64542(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    86d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86da:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    86de:	48 85 ff             	test   %rdi,%rdi
    86e1:	0f 84 09 03 00 00    	je     89f0 <f37+0x380>
    86e7:	0f b6 0a             	movzbl (%rdx),%ecx
    86ea:	80 f9 02             	cmp    $0x2,%cl
    86ed:	0f 84 8d 02 00 00    	je     8980 <f37+0x310>
    86f3:	80 f9 01             	cmp    $0x1,%cl
    86f6:	75 24                	jne    871c <f37+0xac>
    86f8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86fb:	0f b7 c0             	movzwl %ax,%eax
    86fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8701:	48 0f af c1          	imul   %rcx,%rax
    8705:	48 c1 e8 20          	shr    $0x20,%rax
    8709:	48 39 d0             	cmp    %rdx,%rax
    870c:	73 0e                	jae    871c <f37+0xac>
    870e:	48 01 c7             	add    %rax,%rdi
    8711:	0f b6 07             	movzbl (%rdi),%eax
    8714:	84 c0                	test   %al,%al
    8716:	0f 85 84 02 00 00    	jne    89a0 <f37+0x330>
    871c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8721:	48 8b 40 10          	mov    0x10(%rax),%rax
    8725:	ba 01 00 00 00       	mov    $0x1,%edx
    872a:	48 85 c0             	test   %rax,%rax
    872d:	74 0e                	je     873d <f37+0xcd>
    872f:	90                   	nop
    8730:	48 8b 40 10          	mov    0x10(%rax),%rax
    8734:	48 83 c2 01          	add    $0x1,%rdx
    8738:	48 85 c0             	test   %rax,%rax
    873b:	75 f3                	jne    8730 <f37+0xc0>
    873d:	4d 85 ed             	test   %r13,%r13
    8740:	0f 84 da 02 00 00    	je     8a20 <f37+0x3b0>
    8746:	4c 89 e8             	mov    %r13,%rax
    8749:	31 db                	xor    %ebx,%ebx
    874b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8750:	48 8b 40 10          	mov    0x10(%rax),%rax
    8754:	48 83 c3 01          	add    $0x1,%rbx
    8758:	48 85 c0             	test   %rax,%rax
    875b:	75 f3                	jne    8750 <f37+0xe0>
    875d:	48 39 d3             	cmp    %rdx,%rbx
    8760:	48 0f 47 da          	cmova  %rdx,%rbx
    8764:	48 89 d8             	mov    %rbx,%rax
    8767:	48 c1 e8 3c          	shr    $0x3c,%rax
    876b:	0f 85 bd 03 00 00    	jne    8b2e <f37+0x4be>
    8771:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    8775:	be 02 00 00 00       	mov    $0x2,%esi
    877a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8781:	00 
    8782:	e8 89 d7 ff ff       	call   5f10 <fwp_heap_alloc>
    8787:	48 89 28             	mov    %rbp,(%rax)
    878a:	48 8b 15 67 44 06 00 	mov    0x64467(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8791:	49 89 c4             	mov    %rax,%r12
    8794:	48 2b 05 35 44 06 00 	sub    0x64435(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    879b:	48 c1 e2 10          	shl    $0x10,%rdx
    879f:	48 39 d0             	cmp    %rdx,%rax
    87a2:	73 57                	jae    87fb <f37+0x18b>
    87a4:	48 89 c2             	mov    %rax,%rdx
    87a7:	48 c1 ea 10          	shr    $0x10,%rdx
    87ab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87af:	48 8b 15 62 44 06 00 	mov    0x64462(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    87b6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    87ba:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    87be:	48 85 ed             	test   %rbp,%rbp
    87c1:	74 38                	je     87fb <f37+0x18b>
    87c3:	0f b6 0a             	movzbl (%rdx),%ecx
    87c6:	80 f9 02             	cmp    $0x2,%cl
    87c9:	0f 84 11 02 00 00    	je     89e0 <f37+0x370>
    87cf:	80 f9 01             	cmp    $0x1,%cl
    87d2:	75 27                	jne    87fb <f37+0x18b>
    87d4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    87d7:	0f b7 c0             	movzwl %ax,%eax
    87da:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87dd:	48 0f af c1          	imul   %rcx,%rax
    87e1:	48 c1 e8 20          	shr    $0x20,%rax
    87e5:	48 39 d0             	cmp    %rdx,%rax
    87e8:	73 11                	jae    87fb <f37+0x18b>
    87ea:	48 01 c5             	add    %rax,%rbp
    87ed:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    87f1:	0f 84 97 02 00 00    	je     8a8e <f37+0x41e>
    87f7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    87fb:	48 85 db             	test   %rbx,%rbx
    87fe:	74 5d                	je     885d <f37+0x1ed>
    8800:	48 c1 e3 04          	shl    $0x4,%rbx
    8804:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8809:	4c 89 e5             	mov    %r12,%rbp
    880c:	4d 89 ef             	mov    %r13,%r15
    880f:	4c 01 e3             	add    %r12,%rbx
    8812:	0f 1f 00             	nopl   (%rax)
    8815:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    881c:	00 00 00 00 
    8820:	49 8b 46 08          	mov    0x8(%r14),%rax
    8824:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8828:	48 83 c5 10          	add    $0x10,%rbp
    882c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8831:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8835:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8839:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    883e:	e8 ad de ff ff       	call   66f0 <w120>
    8843:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8848:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    884c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8850:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8854:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8858:	48 39 eb             	cmp    %rbp,%rbx
    885b:	75 c3                	jne    8820 <f37+0x1b0>
    885d:	4c 89 ef             	mov    %r13,%rdi
    8860:	31 db                	xor    %ebx,%ebx
    8862:	e8 89 ed ff ff       	call   75f0 <fwp_drop4>
    8867:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    886c:	e8 7f ed ff ff       	call   75f0 <fwp_drop4>
    8871:	4d 8b 2c 24          	mov    (%r12),%r13
    8875:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8879:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    8880:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    8887:	4d 85 ed             	test   %r13,%r13
    888a:	74 32                	je     88be <f37+0x24e>
    888c:	0f 1f 40 00          	nopl   0x0(%rax)
    8890:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    8897:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    889c:	48 83 c3 02          	add    $0x2,%rbx
    88a0:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    88a6:	e8 c5 dc ff ff       	call   6570 <f141.constprop.0>
    88ab:	4c 39 eb             	cmp    %r13,%rbx
    88ae:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    88b4:	48 89 c7             	mov    %rax,%rdi
    88b7:	72 d7                	jb     8890 <f37+0x220>
    88b9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    88be:	4c 89 e7             	mov    %r12,%rdi
    88c1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    88c6:	e8 45 fb ff ff       	call   8410 <fwp_drop10>
    88cb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    88d0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    88d5:	31 ff                	xor    %edi,%edi
    88d7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    88dc:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    88e1:	e8 1a d8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    88e6:	48 8b 15 0b 43 06 00 	mov    0x6430b(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    88ed:	48 89 c5             	mov    %rax,%rbp
    88f0:	48 2b 05 d9 42 06 00 	sub    0x642d9(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    88f7:	48 c1 e2 10          	shl    $0x10,%rdx
    88fb:	48 39 d0             	cmp    %rdx,%rax
    88fe:	73 55                	jae    8955 <f37+0x2e5>
    8900:	48 89 c2             	mov    %rax,%rdx
    8903:	48 c1 ea 10          	shr    $0x10,%rdx
    8907:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    890b:	48 8b 15 06 43 06 00 	mov    0x64306(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8912:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8916:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    891a:	48 85 db             	test   %rbx,%rbx
    891d:	74 36                	je     8955 <f37+0x2e5>
    891f:	0f b6 0a             	movzbl (%rdx),%ecx
    8922:	80 f9 02             	cmp    $0x2,%cl
    8925:	0f 84 a5 00 00 00    	je     89d0 <f37+0x360>
    892b:	80 f9 01             	cmp    $0x1,%cl
    892e:	75 25                	jne    8955 <f37+0x2e5>
    8930:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8933:	0f b7 c0             	movzwl %ax,%eax
    8936:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8939:	48 0f af c1          	imul   %rcx,%rax
    893d:	48 c1 e8 20          	shr    $0x20,%rax
    8941:	48 39 d0             	cmp    %rdx,%rax
    8944:	73 0f                	jae    8955 <f37+0x2e5>
    8946:	48 01 c3             	add    %rax,%rbx
    8949:	80 3b ff             	cmpb   $0xff,(%rbx)
    894c:	0f 84 2f 01 00 00    	je     8a81 <f37+0x411>
    8952:	c6 03 01             	movb   $0x1,(%rbx)
    8955:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    895a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8961:	00 00 
    8963:	0f 85 d1 01 00 00    	jne    8b3a <f37+0x4ca>
    8969:	48 83 c4 38          	add    $0x38,%rsp
    896d:	48 89 e8             	mov    %rbp,%rax
    8970:	5b                   	pop    %rbx
    8971:	5d                   	pop    %rbp
    8972:	41 5c                	pop    %r12
    8974:	41 5d                	pop    %r13
    8976:	41 5e                	pop    %r14
    8978:	41 5f                	pop    %r15
    897a:	c3                   	ret
    897b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8980:	66 85 c0             	test   %ax,%ax
    8983:	0f 85 93 fd ff ff    	jne    871c <f37+0xac>
    8989:	0f b6 07             	movzbl (%rdi),%eax
    898c:	84 c0                	test   %al,%al
    898e:	0f 84 88 fd ff ff    	je     871c <f37+0xac>
    8994:	90                   	nop
    8995:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    899c:	00 00 00 00 
    89a0:	8b 15 42 4b 06 00    	mov    0x64b42(%rip),%edx        # 6d4e8 <iteration_active>
    89a6:	85 d2                	test   %edx,%edx
    89a8:	75 56                	jne    8a00 <f37+0x390>
    89aa:	3c fd                	cmp    $0xfd,%al
    89ac:	0f 87 4b 01 00 00    	ja     8afd <f37+0x48d>
    89b2:	83 c0 01             	add    $0x1,%eax
    89b5:	88 07                	mov    %al,(%rdi)
    89b7:	31 d2                	xor    %edx,%edx
    89b9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    89bf:	0f 85 57 fd ff ff    	jne    871c <f37+0xac>
    89c5:	e9 73 fd ff ff       	jmp    873d <f37+0xcd>
    89ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    89d0:	66 85 c0             	test   %ax,%ax
    89d3:	0f 85 7c ff ff ff    	jne    8955 <f37+0x2e5>
    89d9:	e9 6b ff ff ff       	jmp    8949 <f37+0x2d9>
    89de:	66 90                	xchg   %ax,%ax
    89e0:	66 85 c0             	test   %ax,%ax
    89e3:	0f 85 12 fe ff ff    	jne    87fb <f37+0x18b>
    89e9:	e9 ff fd ff ff       	jmp    87ed <f37+0x17d>
    89ee:	66 90                	xchg   %ax,%ax
    89f0:	4c 89 e8             	mov    %r13,%rax
    89f3:	e9 2d fd ff ff       	jmp    8725 <f37+0xb5>
    89f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    89ff:	00 
    8a00:	48 83 05 c8 4a 06 00 	addq   $0x1,0x64ac8(%rip)        # 6d4d0 <iteration_retains>
    8a07:	01 
    8a08:	eb a0                	jmp    89aa <f37+0x33a>
    8a0a:	48 f7 d9             	neg    %rcx
    8a0d:	48 39 d1             	cmp    %rdx,%rcx
    8a10:	0f 82 85 00 00 00    	jb     8a9b <f37+0x42b>
    8a16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8a1d:	00 00 00 
    8a20:	be 02 00 00 00       	mov    $0x2,%esi
    8a25:	bf 08 00 00 00       	mov    $0x8,%edi
    8a2a:	e8 e1 d4 ff ff       	call   5f10 <fwp_heap_alloc>
    8a2f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8a36:	48 8b 15 bb 41 06 00 	mov    0x641bb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    8a3d:	49 89 c4             	mov    %rax,%r12
    8a40:	48 2b 05 89 41 06 00 	sub    0x64189(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    8a47:	48 c1 e2 10          	shl    $0x10,%rdx
    8a4b:	48 39 d0             	cmp    %rdx,%rax
    8a4e:	0f 83 b3 00 00 00    	jae    8b07 <f37+0x497>
    8a54:	48 89 c2             	mov    %rax,%rdx
    8a57:	45 31 ed             	xor    %r13d,%r13d
    8a5a:	48 c1 ea 10          	shr    $0x10,%rdx
    8a5e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8a62:	48 8b 15 af 41 06 00 	mov    0x641af(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    8a69:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8a6d:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    8a71:	48 85 ed             	test   %rbp,%rbp
    8a74:	0f 84 e3 fd ff ff    	je     885d <f37+0x1ed>
    8a7a:	31 db                	xor    %ebx,%ebx
    8a7c:	e9 42 fd ff ff       	jmp    87c3 <f37+0x153>
    8a81:	48 89 df             	mov    %rbx,%rdi
    8a84:	e8 47 cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    8a89:	e9 c4 fe ff ff       	jmp    8952 <f37+0x2e2>
    8a8e:	48 89 ef             	mov    %rbp,%rdi
    8a91:	e8 3a cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    8a96:	e9 5c fd ff ff       	jmp    87f7 <f37+0x187>
    8a9b:	48 89 c8             	mov    %rcx,%rax
    8a9e:	48 c1 e8 10          	shr    $0x10,%rax
    8aa2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8aa6:	48 8b 05 6b 41 06 00 	mov    0x6416b(%rip),%rax        # 6cc18 <fwp_heap+0x13f8>
    8aad:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8ab1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8ab5:	48 85 ff             	test   %rdi,%rdi
    8ab8:	0f 84 62 ff ff ff    	je     8a20 <f37+0x3b0>
    8abe:	0f b6 02             	movzbl (%rdx),%eax
    8ac1:	3c 02                	cmp    $0x2,%al
    8ac3:	74 4a                	je     8b0f <f37+0x49f>
    8ac5:	3c 01                	cmp    $0x1,%al
    8ac7:	0f 85 53 ff ff ff    	jne    8a20 <f37+0x3b0>
    8acd:	0f b7 c1             	movzwl %cx,%eax
    8ad0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8ad3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8ad6:	48 0f af c1          	imul   %rcx,%rax
    8ada:	48 c1 e8 20          	shr    $0x20,%rax
    8ade:	48 39 d0             	cmp    %rdx,%rax
    8ae1:	0f 83 39 ff ff ff    	jae    8a20 <f37+0x3b0>
    8ae7:	48 01 c7             	add    %rax,%rdi
    8aea:	0f b6 07             	movzbl (%rdi),%eax
    8aed:	84 c0                	test   %al,%al
    8aef:	0f 84 2b ff ff ff    	je     8a20 <f37+0x3b0>
    8af5:	45 31 ed             	xor    %r13d,%r13d
    8af8:	e9 a3 fe ff ff       	jmp    89a0 <f37+0x330>
    8afd:	e8 ae cb ff ff       	call   56b0 <fwp_rc_wide_dup>
    8b02:	e9 b0 fe ff ff       	jmp    89b7 <f37+0x347>
    8b07:	45 31 ed             	xor    %r13d,%r13d
    8b0a:	e9 4e fd ff ff       	jmp    885d <f37+0x1ed>
    8b0f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8b15:	49 89 cd             	mov    %rcx,%r13
    8b18:	0f 85 02 ff ff ff    	jne    8a20 <f37+0x3b0>
    8b1e:	0f b6 07             	movzbl (%rdi),%eax
    8b21:	84 c0                	test   %al,%al
    8b23:	0f 85 77 fe ff ff    	jne    89a0 <f37+0x330>
    8b29:	e9 f2 fe ff ff       	jmp    8a20 <f37+0x3b0>
    8b2e:	48 8d 3d b6 66 00 00 	lea    0x66b6(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    8b35:	e8 16 b9 ff ff       	call   4450 <fwp_trap>
    8b3a:	e8 11 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8b3f:	90                   	nop

0000000000008b40 <fwp_owned_entry37>:
    8b40:	f3 0f 1e fa          	endbr64
    8b44:	48 8b 3f             	mov    (%rdi),%rdi
    8b47:	e9 24 fb ff ff       	jmp    8670 <f37>
    8b4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008b50 <e37>:
    8b50:	f3 0f 1e fa          	endbr64
    8b54:	53                   	push   %rbx
    8b55:	48 8b 1f             	mov    (%rdi),%rbx
    8b58:	48 89 df             	mov    %rbx,%rdi
    8b5b:	e8 90 e1 ff ff       	call   6cf0 <fwp_rc_share>
    8b60:	48 89 df             	mov    %rbx,%rdi
    8b63:	e8 08 fb ff ff       	call   8670 <f37>
    8b68:	48 89 c3             	mov    %rax,%rbx
    8b6b:	48 89 c7             	mov    %rax,%rdi
    8b6e:	e8 7d e1 ff ff       	call   6cf0 <fwp_rc_share>
    8b73:	48 89 d8             	mov    %rbx,%rax
    8b76:	5b                   	pop    %rbx
    8b77:	c3                   	ret
    8b78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b7f:	00 

0000000000008b80 <fwp_write>:
    8b80:	41 57                	push   %r15
    8b82:	41 56                	push   %r14
    8b84:	41 55                	push   %r13
    8b86:	41 54                	push   %r12
    8b88:	55                   	push   %rbp
    8b89:	53                   	push   %rbx
    8b8a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8b91:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8b98:	00 00 
    8b9a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8ba1:	00 
    8ba2:	49 89 d4             	mov    %rdx,%r12
    8ba5:	8b 12                	mov    (%rdx),%edx
    8ba7:	83 fa 19             	cmp    $0x19,%edx
    8baa:	77 6a                	ja     8c16 <fwp_write+0x96>
    8bac:	48 89 f5             	mov    %rsi,%rbp
    8baf:	89 d0                	mov    %edx,%eax
    8bb1:	89 ce                	mov    %ecx,%esi
    8bb3:	48 89 fb             	mov    %rdi,%rbx
    8bb6:	48 8d 0d 13 71 00 00 	lea    0x7113(%rip),%rcx        # fcd0 <_IO_stdin_used+0xcd0>
    8bbd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8bc1:	48 01 c8             	add    %rcx,%rax
    8bc4:	3e ff e0             	notrack jmp *%rax
    8bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bce:	00 00 
    8bd0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8bd4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8bd8:	48 89 ca             	mov    %rcx,%rdx
    8bdb:	48 85 c9             	test   %rcx,%rcx
    8bde:	0f 88 9c 0c 00 00    	js     9880 <fwp_write+0xd00>
    8be4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8beb:	00 
    8bec:	48 89 c6             	mov    %rax,%rsi
    8bef:	4c 89 e7             	mov    %r12,%rdi
    8bf2:	e8 49 ae ff ff       	call   3a40 <fwp_fmt_u128>
    8bf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bfe:	00 00 
    8c00:	4c 89 e7             	mov    %r12,%rdi
    8c03:	e8 38 a8 ff ff       	call   3440 <strlen@plt>
    8c08:	4c 89 e6             	mov    %r12,%rsi
    8c0b:	48 89 df             	mov    %rbx,%rdi
    8c0e:	48 89 c2             	mov    %rax,%rdx
    8c11:	e8 da b4 ff ff       	call   40f0 <buf_put>
    8c16:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8c1d:	00 
    8c1e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c25:	00 00 
    8c27:	0f 85 28 04 00 00    	jne    9055 <fwp_write+0x4d5>
    8c2d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8c34:	5b                   	pop    %rbx
    8c35:	5d                   	pop    %rbp
    8c36:	41 5c                	pop    %r12
    8c38:	41 5d                	pop    %r13
    8c3a:	41 5e                	pop    %r14
    8c3c:	41 5f                	pop    %r15
    8c3e:	c3                   	ret
    8c3f:	90                   	nop
    8c40:	49 89 e9             	mov    %rbp,%r9
    8c43:	4c 8d 05 cb 65 00 00 	lea    0x65cb(%rip),%r8        # f215 <_IO_stdin_used+0x215>
    8c4a:	b9 00 02 00 00       	mov    $0x200,%ecx
    8c4f:	ba 02 00 00 00       	mov    $0x2,%edx
    8c54:	be 00 02 00 00       	mov    $0x200,%esi
    8c59:	31 c0                	xor    %eax,%eax
    8c5b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c62:	00 
    8c63:	e8 38 a7 ff ff       	call   33a0 <__snprintf_chk@plt>
    8c68:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c6f:	00 
    8c70:	e8 cb a7 ff ff       	call   3440 <strlen@plt>
    8c75:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8c7c:	00 
    8c7d:	48 89 df             	mov    %rbx,%rdi
    8c80:	48 89 c2             	mov    %rax,%rdx
    8c83:	e8 68 b4 ff ff       	call   40f0 <buf_put>
    8c88:	eb 8c                	jmp    8c16 <fwp_write+0x96>
    8c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c90:	49 89 e9             	mov    %rbp,%r9
    8c93:	4c 8d 05 76 65 00 00 	lea    0x6576(%rip),%r8        # f210 <_IO_stdin_used+0x210>
    8c9a:	eb ae                	jmp    8c4a <fwp_write+0xca>
    8c9c:	0f 1f 40 00          	nopl   0x0(%rax)
    8ca0:	83 fa 13             	cmp    $0x13,%edx
    8ca3:	48 8d 05 5c 65 00 00 	lea    0x655c(%rip),%rax        # f206 <_IO_stdin_used+0x206>
    8caa:	48 8d 35 5a 65 00 00 	lea    0x655a(%rip),%rsi        # f20b <_IO_stdin_used+0x20b>
    8cb1:	ba 04 00 00 00       	mov    $0x4,%edx
    8cb6:	48 0f 44 f0          	cmove  %rax,%rsi
    8cba:	45 31 ed             	xor    %r13d,%r13d
    8cbd:	e8 2e b4 ff ff       	call   40f0 <buf_put>
    8cc2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8cc7:	0f 84 a3 08 00 00    	je     9570 <fwp_write+0x9f0>
    8ccd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8cd2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8cd7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8cdc:	48 89 df             	mov    %rbx,%rdi
    8cdf:	49 0f 44 c5          	cmove  %r13,%rax
    8ce3:	31 c9                	xor    %ecx,%ecx
    8ce5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    8cea:	e8 91 fe ff ff       	call   8b80 <fwp_write>
    8cef:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8cf4:	0f 84 6e 09 00 00    	je     9668 <fwp_write+0xae8>
    8cfa:	49 83 c5 01          	add    $0x1,%r13
    8cfe:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8d02:	0f 83 68 08 00 00    	jae    9570 <fwp_write+0x9f0>
    8d08:	ba 02 00 00 00       	mov    $0x2,%edx
    8d0d:	48 8d 35 41 65 00 00 	lea    0x6541(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8d14:	48 89 df             	mov    %rbx,%rdi
    8d17:	e8 d4 b3 ff ff       	call   40f0 <buf_put>
    8d1c:	eb af                	jmp    8ccd <fwp_write+0x14d>
    8d1e:	66 90                	xchg   %ax,%ax
    8d20:	ba 06 00 00 00       	mov    $0x6,%edx
    8d25:	48 8d 35 02 65 00 00 	lea    0x6502(%rip),%rsi        # f22e <_IO_stdin_used+0x22e>
    8d2c:	48 83 c5 10          	add    $0x10,%rbp
    8d30:	e8 bb b3 ff ff       	call   40f0 <buf_put>
    8d35:	48 89 ef             	mov    %rbp,%rdi
    8d38:	e8 03 a7 ff ff       	call   3440 <strlen@plt>
    8d3d:	48 89 ee             	mov    %rbp,%rsi
    8d40:	48 89 df             	mov    %rbx,%rdi
    8d43:	48 89 c2             	mov    %rax,%rdx
    8d46:	e8 a5 b3 ff ff       	call   40f0 <buf_put>
    8d4b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d50:	ba 01 00 00 00       	mov    $0x1,%edx
    8d55:	48 89 df             	mov    %rbx,%rdi
    8d58:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8d5d:	e8 8e b3 ff ff       	call   40f0 <buf_put>
    8d62:	e9 af fe ff ff       	jmp    8c16 <fwp_write+0x96>
    8d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8d6e:	00 00 
    8d70:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8d77:	00 
    8d78:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8d7f:	00 00 
    8d81:	0f 85 ce 02 00 00    	jne    9055 <fwp_write+0x4d5>
    8d87:	ba 0a 00 00 00       	mov    $0xa,%edx
    8d8c:	48 8d 35 87 64 00 00 	lea    0x6487(%rip),%rsi        # f21a <_IO_stdin_used+0x21a>
    8d93:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8d9a:	48 89 df             	mov    %rbx,%rdi
    8d9d:	5b                   	pop    %rbx
    8d9e:	5d                   	pop    %rbp
    8d9f:	41 5c                	pop    %r12
    8da1:	41 5d                	pop    %r13
    8da3:	41 5e                	pop    %r14
    8da5:	41 5f                	pop    %r15
    8da7:	e9 44 b3 ff ff       	jmp    40f0 <buf_put>
    8dac:	0f 1f 40 00          	nopl   0x0(%rax)
    8db0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8db5:	4d 85 ed             	test   %r13,%r13
    8db8:	0f 84 02 0c 00 00    	je     99c0 <fwp_write+0xe40>
    8dbe:	48 8d 35 9d 64 00 00 	lea    0x649d(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    8dc5:	4c 89 ef             	mov    %r13,%rdi
    8dc8:	e8 53 a7 ff ff       	call   3520 <strcmp@plt>
    8dcd:	41 89 c1             	mov    %eax,%r9d
    8dd0:	85 c0                	test   %eax,%eax
    8dd2:	0f 84 6c 0c 00 00    	je     9a44 <fwp_write+0xec4>
    8dd8:	4c 89 ef             	mov    %r13,%rdi
    8ddb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8de0:	e8 5b a6 ff ff       	call   3440 <strlen@plt>
    8de5:	4c 89 ee             	mov    %r13,%rsi
    8de8:	48 89 df             	mov    %rbx,%rdi
    8deb:	48 89 c2             	mov    %rax,%rdx
    8dee:	e8 fd b2 ff ff       	call   40f0 <buf_put>
    8df3:	ba 01 00 00 00       	mov    $0x1,%edx
    8df8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dfd:	48 89 df             	mov    %rbx,%rdi
    8e00:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8e05:	e8 e6 b2 ff ff       	call   40f0 <buf_put>
    8e0a:	ba 01 00 00 00       	mov    $0x1,%edx
    8e0f:	4c 89 fe             	mov    %r15,%rsi
    8e12:	48 89 df             	mov    %rbx,%rdi
    8e15:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8e1a:	e8 d1 b2 ff ff       	call   40f0 <buf_put>
    8e1f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8e24:	45 31 f6             	xor    %r14d,%r14d
    8e27:	85 d2                	test   %edx,%edx
    8e29:	0f 8e 81 0a 00 00    	jle    98b0 <fwp_write+0xd30>
    8e2f:	45 31 ed             	xor    %r13d,%r13d
    8e32:	4d 85 ed             	test   %r13,%r13
    8e35:	0f 85 75 07 00 00    	jne    95b0 <fwp_write+0xa30>
    8e3b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8e42:	00 
    8e43:	45 85 f6             	test   %r14d,%r14d
    8e46:	0f 84 84 07 00 00    	je     95d0 <fwp_write+0xa50>
    8e4c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8e51:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8e56:	48 89 df             	mov    %rbx,%rdi
    8e59:	49 83 c5 01          	add    $0x1,%r13
    8e5d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8e61:	31 c9                	xor    %ecx,%ecx
    8e63:	e8 18 fd ff ff       	call   8b80 <fwp_write>
    8e68:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8e6d:	7f c3                	jg     8e32 <fwp_write+0x2b2>
    8e6f:	45 85 f6             	test   %r14d,%r14d
    8e72:	0f 84 38 0a 00 00    	je     98b0 <fwp_write+0xd30>
    8e78:	b8 29 00 00 00       	mov    $0x29,%eax
    8e7d:	ba 01 00 00 00       	mov    $0x1,%edx
    8e82:	4c 89 fe             	mov    %r15,%rsi
    8e85:	48 89 df             	mov    %rbx,%rdi
    8e88:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8e8c:	e8 5f b2 ff ff       	call   40f0 <buf_put>
    8e91:	e9 80 fd ff ff       	jmp    8c16 <fwp_write+0x96>
    8e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8e9d:	00 00 00 
    8ea0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ea5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8eaa:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8eaf:	e8 3c b2 ff ff       	call   40f0 <buf_put>
    8eb4:	48 85 ed             	test   %rbp,%rbp
    8eb7:	0f 84 93 06 00 00    	je     9550 <fwp_write+0x9d0>
    8ebd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8ec1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ec6:	31 c9                	xor    %ecx,%ecx
    8ec8:	48 89 df             	mov    %rbx,%rdi
    8ecb:	e8 b0 fc ff ff       	call   8b80 <fwp_write>
    8ed0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8ed4:	48 85 ed             	test   %rbp,%rbp
    8ed7:	0f 84 73 06 00 00    	je     9550 <fwp_write+0x9d0>
    8edd:	ba 02 00 00 00       	mov    $0x2,%edx
    8ee2:	48 8d 35 6c 63 00 00 	lea    0x636c(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    8ee9:	48 89 df             	mov    %rbx,%rdi
    8eec:	e8 ff b1 ff ff       	call   40f0 <buf_put>
    8ef1:	eb ca                	jmp    8ebd <fwp_write+0x33d>
    8ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ef8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8efc:	85 f6                	test   %esi,%esi
    8efe:	0f 84 fc 07 00 00    	je     9700 <fwp_write+0xb80>
    8f04:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f0b:	00 
    8f0c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f13:	00 00 
    8f15:	0f 85 3a 01 00 00    	jne    9055 <fwp_write+0x4d5>
    8f1b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8f1f:	4c 89 ea             	mov    %r13,%rdx
    8f22:	e9 6c fe ff ff       	jmp    8d93 <fwp_write+0x213>
    8f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8f2e:	00 00 
    8f30:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8f35:	ba 01 00 00 00       	mov    $0x1,%edx
    8f3a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8f3f:	48 89 ee             	mov    %rbp,%rsi
    8f42:	e8 a9 b1 ff ff       	call   40f0 <buf_put>
    8f47:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8f4c:	4c 89 e7             	mov    %r12,%rdi
    8f4f:	e8 ec a4 ff ff       	call   3440 <strlen@plt>
    8f54:	4c 89 e6             	mov    %r12,%rsi
    8f57:	48 89 df             	mov    %rbx,%rdi
    8f5a:	48 89 c2             	mov    %rax,%rdx
    8f5d:	e8 8e b1 ff ff       	call   40f0 <buf_put>
    8f62:	ba 01 00 00 00       	mov    $0x1,%edx
    8f67:	48 89 ee             	mov    %rbp,%rsi
    8f6a:	48 89 df             	mov    %rbx,%rdi
    8f6d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8f72:	e8 79 b1 ff ff       	call   40f0 <buf_put>
    8f77:	e9 9a fc ff ff       	jmp    8c16 <fwp_write+0x96>
    8f7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f80:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8f85:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8f89:	0f 8a 8e 0b 00 00    	jp     9b1d <fwp_write+0xf9d>
    8f8f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8f93:	66 0f 54 05 65 6e 00 	andpd  0x6e65(%rip),%xmm0        # fe00 <msg.4+0xc0>
    8f9a:	00 
    8f9b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8fa0:	66 0f 2e 05 d8 6d 00 	ucomisd 0x6dd8(%rip),%xmm0        # fd80 <msg.4+0x40>
    8fa7:	00 
    8fa8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8faf:	00 
    8fb0:	0f 87 b2 09 00 00    	ja     9968 <fwp_write+0xde8>
    8fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fbd:	00 00 00 
    8fc0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8fc4:	89 ee                	mov    %ebp,%esi
    8fc6:	4c 89 e7             	mov    %r12,%rdi
    8fc9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8fce:	e8 9d b7 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8fd3:	31 f6                	xor    %esi,%esi
    8fd5:	4c 89 e7             	mov    %r12,%rdi
    8fd8:	e8 23 a4 ff ff       	call   3400 <strtod@plt>
    8fdd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8fe2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8fe6:	7a 06                	jp     8fee <fwp_write+0x46e>
    8fe8:	0f 84 e9 01 00 00    	je     91d7 <fwp_write+0x657>
    8fee:	83 c5 01             	add    $0x1,%ebp
    8ff1:	83 fd 12             	cmp    $0x12,%ebp
    8ff4:	75 ca                	jne    8fc0 <fwp_write+0x440>
    8ff6:	be 11 00 00 00       	mov    $0x11,%esi
    8ffb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8fff:	4c 89 e7             	mov    %r12,%rdi
    9002:	e8 69 b7 ff ff       	call   4770 <fwp_format_g.constprop.0>
    9007:	e9 cb 01 00 00       	jmp    91d7 <fwp_write+0x657>
    900c:	0f 1f 40 00          	nopl   0x0(%rax)
    9010:	48 83 fd 01          	cmp    $0x1,%rbp
    9014:	0f 84 e6 08 00 00    	je     9900 <fwp_write+0xd80>
    901a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    901e:	b8 02 00 00 00       	mov    $0x2,%eax
    9023:	ba 01 00 00 00       	mov    $0x1,%edx
    9028:	48 0f 44 d0          	cmove  %rax,%rdx
    902c:	48 8d 35 cb 61 00 00 	lea    0x61cb(%rip),%rsi        # f1fe <_IO_stdin_used+0x1fe>
    9033:	48 8d 05 c9 61 00 00 	lea    0x61c9(%rip),%rax        # f203 <_IO_stdin_used+0x203>
    903a:	48 0f 44 f0          	cmove  %rax,%rsi
    903e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9045:	00 
    9046:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    904d:	00 00 
    904f:	0f 84 3e fd ff ff    	je     8d93 <fwp_write+0x213>
    9055:	e8 f6 a3 ff ff       	call   3450 <__stack_chk_fail@plt>
    905a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9060:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    9065:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    906a:	e8 c1 af ff ff       	call   4030 <buf_grow>
    906f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    9073:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    9079:	4c 03 0b             	add    (%rbx),%r9
    907c:	66 45 89 11          	mov    %r10w,(%r9)
    9080:	45 85 e4             	test   %r12d,%r12d
    9083:	0f 8e 07 05 00 00    	jle    9590 <fwp_write+0xa10>
    9089:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    9090:	55 55 55 
    9093:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    9098:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    909f:	aa aa aa 
    90a2:	49 83 c1 01          	add    $0x1,%r9
    90a6:	eb 45                	jmp    90ed <fwp_write+0x56d>
    90a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    90af:	00 
    90b0:	be 01 00 00 00       	mov    $0x1,%esi
    90b5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    90ba:	88 07                	mov    %al,(%rdi)
    90bc:	48 89 e8             	mov    %rbp,%rax
    90bf:	49 f7 e8             	imul   %r8
    90c2:	48 89 e8             	mov    %rbp,%rax
    90c5:	48 c1 f8 3f          	sar    $0x3f,%rax
    90c9:	48 29 c2             	sub    %rax,%rdx
    90cc:	48 85 c9             	test   %rcx,%rcx
    90cf:	0f 95 c0             	setne  %al
    90d2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    90d6:	48 83 ef 01          	sub    $0x1,%rdi
    90da:	48 21 c5             	and    %rax,%rbp
    90dd:	48 29 ea             	sub    %rbp,%rdx
    90e0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    90e4:	49 39 f9             	cmp    %rdi,%r9
    90e7:	0f 84 a3 04 00 00    	je     9590 <fwp_write+0xa10>
    90ed:	48 89 e8             	mov    %rbp,%rax
    90f0:	49 f7 e8             	imul   %r8
    90f3:	48 89 e8             	mov    %rbp,%rax
    90f6:	48 c1 f8 3f          	sar    $0x3f,%rax
    90fa:	48 89 d1             	mov    %rdx,%rcx
    90fd:	48 29 c1             	sub    %rax,%rcx
    9100:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9104:	48 89 e9             	mov    %rbp,%rcx
    9107:	48 29 c1             	sub    %rax,%rcx
    910a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    910e:	49 f7 e2             	mul    %r10
    9111:	b8 30 00 00 00       	mov    $0x30,%eax
    9116:	48 89 d6             	mov    %rdx,%rsi
    9119:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    911d:	48 d1 ee             	shr    $1,%rsi
    9120:	48 01 f2             	add    %rsi,%rdx
    9123:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9127:	48 29 d6             	sub    %rdx,%rsi
    912a:	74 8e                	je     90ba <fwp_write+0x53a>
    912c:	48 83 fe 01          	cmp    $0x1,%rsi
    9130:	0f 85 7a ff ff ff    	jne    90b0 <fwp_write+0x530>
    9136:	31 f6                	xor    %esi,%esi
    9138:	b8 2b 00 00 00       	mov    $0x2b,%eax
    913d:	e9 78 ff ff ff       	jmp    90ba <fwp_write+0x53a>
    9142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9148:	66 0f 6e cd          	movd   %ebp,%xmm1
    914c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    914f:	0f 8a c8 09 00 00    	jp     9b1d <fwp_write+0xf9d>
    9155:	0f 28 c1             	movaps %xmm1,%xmm0
    9158:	0f 54 05 91 6c 00 00 	andps  0x6c91(%rip),%xmm0        # fdf0 <msg.4+0xb0>
    915f:	0f 2e 05 9e 5e 00 00 	ucomiss 0x5e9e(%rip),%xmm0        # f004 <_IO_stdin_used+0x4>
    9166:	0f 87 24 08 00 00    	ja     9990 <fwp_write+0xe10>
    916c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9170:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    9176:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    917d:	00 
    917e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    9182:	66 49 0f 7e d7       	movq   %xmm2,%r15
    9187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    918e:	00 00 
    9190:	44 89 ee             	mov    %r13d,%esi
    9193:	66 49 0f 6e c7       	movq   %r15,%xmm0
    9198:	4c 89 e7             	mov    %r12,%rdi
    919b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    91a0:	e8 cb b5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    91a5:	31 f6                	xor    %esi,%esi
    91a7:	4c 89 e7             	mov    %r12,%rdi
    91aa:	e8 f1 a2 ff ff       	call   34a0 <strtof@plt>
    91af:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    91b4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    91b7:	7a 02                	jp     91bb <fwp_write+0x63b>
    91b9:	74 1c                	je     91d7 <fwp_write+0x657>
    91bb:	41 83 c5 01          	add    $0x1,%r13d
    91bf:	41 83 fd 0a          	cmp    $0xa,%r13d
    91c3:	75 cb                	jne    9190 <fwp_write+0x610>
    91c5:	be 09 00 00 00       	mov    $0x9,%esi
    91ca:	66 49 0f 6e c7       	movq   %r15,%xmm0
    91cf:	4c 89 e7             	mov    %r12,%rdi
    91d2:	e8 99 b5 ff ff       	call   4770 <fwp_format_g.constprop.0>
    91d7:	4c 89 e7             	mov    %r12,%rdi
    91da:	e8 d1 af ff ff       	call   41b0 <fwp_finish_float>
    91df:	e9 1c fa ff ff       	jmp    8c00 <fwp_write+0x80>
    91e4:	0f 1f 40 00          	nopl   0x0(%rax)
    91e8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    91ec:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    91f0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    91f7:	00 
    91f8:	48 89 ef             	mov    %rbp,%rdi
    91fb:	e8 40 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9200:	48 89 ef             	mov    %rbp,%rdi
    9203:	e8 38 a2 ff ff       	call   3440 <strlen@plt>
    9208:	48 89 ee             	mov    %rbp,%rsi
    920b:	48 89 df             	mov    %rbx,%rdi
    920e:	48 89 c2             	mov    %rax,%rdx
    9211:	e8 da ae ff ff       	call   40f0 <buf_put>
    9216:	e9 fb f9 ff ff       	jmp    8c16 <fwp_write+0x96>
    921b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9220:	ba 06 00 00 00       	mov    $0x6,%edx
    9225:	48 8d 35 2c 60 00 00 	lea    0x602c(%rip),%rsi        # f258 <_IO_stdin_used+0x258>
    922c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9232:	e8 b9 ae ff ff       	call   40f0 <buf_put>
    9237:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    923e:	ff ff 7f 
    9241:	48 23 55 00          	and    0x0(%rbp),%rdx
    9245:	0f 84 86 02 00 00    	je     94d1 <fwp_write+0x951>
    924b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9250:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9254:	48 85 d2             	test   %rdx,%rdx
    9257:	0f 84 ae 00 00 00    	je     930b <fwp_write+0x78b>
    925d:	8b 0a                	mov    (%rdx),%ecx
    925f:	83 f9 1c             	cmp    $0x1c,%ecx
    9262:	0f 84 58 06 00 00    	je     98c0 <fwp_write+0xd40>
    9268:	83 f9 1b             	cmp    $0x1b,%ecx
    926b:	0f 87 9a 00 00 00    	ja     930b <fwp_write+0x78b>
    9271:	be 01 00 00 00       	mov    $0x1,%esi
    9276:	48 d3 e6             	shl    %cl,%rsi
    9279:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    927f:	0f 85 4b 04 00 00    	jne    96d0 <fwp_write+0xb50>
    9285:	f7 c6 84 04 00 00    	test   $0x484,%esi
    928b:	0f 85 0f 04 00 00    	jne    96a0 <fwp_write+0xb20>
    9291:	83 e6 21             	and    $0x21,%esi
    9294:	74 75                	je     930b <fwp_write+0x78b>
    9296:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    929b:	48 85 ff             	test   %rdi,%rdi
    929e:	79 07                	jns    92a7 <fwp_write+0x727>
    92a0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    92a4:	4c 01 ee             	add    %r13,%rsi
    92a7:	48 0f be 3e          	movsbq (%rsi),%rdi
    92ab:	85 c9                	test   %ecx,%ecx
    92ad:	40 0f b6 f7          	movzbl %dil,%esi
    92b1:	48 0f 44 f7          	cmove  %rdi,%rsi
    92b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92bc:	00 00 00 00 
    92c0:	31 c9                	xor    %ecx,%ecx
    92c2:	48 89 df             	mov    %rbx,%rdi
    92c5:	49 83 c5 01          	add    $0x1,%r13
    92c9:	e8 b2 f8 ff ff       	call   8b80 <fwp_write>
    92ce:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    92d5:	ff ff 7f 
    92d8:	48 23 55 00          	and    0x0(%rbp),%rdx
    92dc:	49 39 d5             	cmp    %rdx,%r13
    92df:	0f 83 ec 01 00 00    	jae    94d1 <fwp_write+0x951>
    92e5:	ba 02 00 00 00       	mov    $0x2,%edx
    92ea:	48 89 df             	mov    %rbx,%rdi
    92ed:	48 8d 35 61 5f 00 00 	lea    0x5f61(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    92f4:	e8 f7 ad ff ff       	call   40f0 <buf_put>
    92f9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    92fe:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9302:	48 85 d2             	test   %rdx,%rdx
    9305:	0f 85 52 ff ff ff    	jne    925d <fwp_write+0x6dd>
    930b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9310:	48 85 ff             	test   %rdi,%rdi
    9313:	0f 88 cf 05 00 00    	js     98e8 <fwp_write+0xd68>
    9319:	48 8b 31             	mov    (%rcx),%rsi
    931c:	eb a2                	jmp    92c0 <fwp_write+0x740>
    931e:	66 90                	xchg   %ax,%ax
    9320:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9327:	00 
    9328:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    932f:	00 00 
    9331:	0f 85 1e fd ff ff    	jne    9055 <fwp_write+0x4d5>
    9337:	ba 08 00 00 00       	mov    $0x8,%edx
    933c:	48 8d 35 e2 5e 00 00 	lea    0x5ee2(%rip),%rsi        # f225 <_IO_stdin_used+0x225>
    9343:	e9 4b fa ff ff       	jmp    8d93 <fwp_write+0x213>
    9348:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    934f:	00 
    9350:	89 e8                	mov    %ebp,%eax
    9352:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9359:	76 03                	jbe    935e <fwp_write+0x7de>
    935b:	8b 45 00             	mov    0x0(%rbp),%eax
    935e:	41 89 c6             	mov    %eax,%r14d
    9361:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9366:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    936b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    936f:	4c 89 ef             	mov    %r13,%rdi
    9372:	e8 c9 a0 ff ff       	call   3440 <strlen@plt>
    9377:	4c 89 ee             	mov    %r13,%rsi
    937a:	48 89 df             	mov    %rbx,%rdi
    937d:	48 89 c2             	mov    %rax,%rdx
    9380:	e8 6b ad ff ff       	call   40f0 <buf_put>
    9385:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    938a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    938e:	85 f6                	test   %esi,%esi
    9390:	0f 8e 80 f8 ff ff    	jle    8c16 <fwp_write+0x96>
    9396:	45 31 ed             	xor    %r13d,%r13d
    9399:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    939e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    93a3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    93a8:	ba 01 00 00 00       	mov    $0x1,%edx
    93ad:	4c 89 fe             	mov    %r15,%rsi
    93b0:	48 89 04 24          	mov    %rax,(%rsp)
    93b4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    93b9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    93bd:	48 89 df             	mov    %rbx,%rdi
    93c0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    93c4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    93c9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    93ce:	e8 1d ad ff ff       	call   40f0 <buf_put>
    93d3:	41 8b 06             	mov    (%r14),%eax
    93d6:	83 f8 0e             	cmp    $0xe,%eax
    93d9:	0f 84 71 02 00 00    	je     9650 <fwp_write+0xad0>
    93df:	83 f8 10             	cmp    $0x10,%eax
    93e2:	0f 84 38 02 00 00    	je     9620 <fwp_write+0xaa0>
    93e8:	83 f8 0a             	cmp    $0xa,%eax
    93eb:	0f 84 7f 04 00 00    	je     9870 <fwp_write+0xcf0>
    93f1:	0f 8f f9 00 00 00    	jg     94f0 <fwp_write+0x970>
    93f7:	83 f8 03             	cmp    $0x3,%eax
    93fa:	0f 8f 50 04 00 00    	jg     9850 <fwp_write+0xcd0>
    9400:	85 c0                	test   %eax,%eax
    9402:	78 10                	js     9414 <fwp_write+0x894>
    9404:	48 8b 04 24          	mov    (%rsp),%rax
    9408:	48 c1 e8 3f          	shr    $0x3f,%rax
    940c:	85 c0                	test   %eax,%eax
    940e:	0f 85 f9 00 00 00    	jne    950d <fwp_write+0x98d>
    9414:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9419:	48 8b 34 24          	mov    (%rsp),%rsi
    941d:	31 c9                	xor    %ecx,%ecx
    941f:	48 89 df             	mov    %rbx,%rdi
    9422:	e8 59 f7 ff ff       	call   8b80 <fwp_write>
    9427:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    942c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9431:	49 83 c5 01          	add    $0x1,%r13
    9435:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9439:	0f 8f 5f ff ff ff    	jg     939e <fwp_write+0x81e>
    943f:	e9 d2 f7 ff ff       	jmp    8c16 <fwp_write+0x96>
    9444:	0f 1f 40 00          	nopl   0x0(%rax)
    9448:	ba 06 00 00 00       	mov    $0x6,%edx
    944d:	48 8d 35 f7 5d 00 00 	lea    0x5df7(%rip),%rsi        # f24b <_IO_stdin_used+0x24b>
    9454:	45 31 ed             	xor    %r13d,%r13d
    9457:	e8 94 ac ff ff       	call   40f0 <buf_put>
    945c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9461:	75 19                	jne    947c <fwp_write+0x8fc>
    9463:	eb 6c                	jmp    94d1 <fwp_write+0x951>
    9465:	0f 1f 00             	nopl   (%rax)
    9468:	ba 02 00 00 00       	mov    $0x2,%edx
    946d:	48 8d 35 e1 5d 00 00 	lea    0x5de1(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    9474:	48 89 df             	mov    %rbx,%rdi
    9477:	e8 74 ac ff ff       	call   40f0 <buf_put>
    947c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    9482:	b9 00 02 00 00       	mov    $0x200,%ecx
    9487:	31 c0                	xor    %eax,%eax
    9489:	49 83 c5 01          	add    $0x1,%r13
    948d:	4c 8d 05 be 5d 00 00 	lea    0x5dbe(%rip),%r8        # f252 <_IO_stdin_used+0x252>
    9494:	ba 02 00 00 00       	mov    $0x2,%edx
    9499:	be 00 02 00 00       	mov    $0x200,%esi
    949e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    94a5:	00 
    94a6:	e8 f5 9e ff ff       	call   33a0 <__snprintf_chk@plt>
    94ab:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    94b2:	00 
    94b3:	e8 88 9f ff ff       	call   3440 <strlen@plt>
    94b8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    94bf:	00 
    94c0:	48 89 df             	mov    %rbx,%rdi
    94c3:	48 89 c2             	mov    %rax,%rdx
    94c6:	e8 25 ac ff ff       	call   40f0 <buf_put>
    94cb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    94cf:	72 97                	jb     9468 <fwp_write+0x8e8>
    94d1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94d6:	ba 01 00 00 00       	mov    $0x1,%edx
    94db:	48 89 df             	mov    %rbx,%rdi
    94de:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    94e3:	e8 08 ac ff ff       	call   40f0 <buf_put>
    94e8:	e9 29 f7 ff ff       	jmp    8c16 <fwp_write+0x96>
    94ed:	0f 1f 00             	nopl   (%rax)
    94f0:	83 f8 0b             	cmp    $0xb,%eax
    94f3:	0f 85 1b ff ff ff    	jne    9414 <fwp_write+0x894>
    94f9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    94fe:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9502:	83 e0 01             	and    $0x1,%eax
    9505:	85 c0                	test   %eax,%eax
    9507:	0f 84 07 ff ff ff    	je     9414 <fwp_write+0x894>
    950d:	4c 89 fe             	mov    %r15,%rsi
    9510:	48 89 df             	mov    %rbx,%rdi
    9513:	ba 01 00 00 00       	mov    $0x1,%edx
    9518:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    951d:	e8 ce ab ff ff       	call   40f0 <buf_put>
    9522:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9527:	48 8b 34 24          	mov    (%rsp),%rsi
    952b:	31 c9                	xor    %ecx,%ecx
    952d:	48 89 df             	mov    %rbx,%rdi
    9530:	e8 4b f6 ff ff       	call   8b80 <fwp_write>
    9535:	ba 01 00 00 00       	mov    $0x1,%edx
    953a:	4c 89 fe             	mov    %r15,%rsi
    953d:	48 89 df             	mov    %rbx,%rdi
    9540:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9545:	e8 a6 ab ff ff       	call   40f0 <buf_put>
    954a:	e9 d8 fe ff ff       	jmp    9427 <fwp_write+0x8a7>
    954f:	90                   	nop
    9550:	ba 01 00 00 00       	mov    $0x1,%edx
    9555:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    955a:	48 89 df             	mov    %rbx,%rdi
    955d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9562:	e8 89 ab ff ff       	call   40f0 <buf_put>
    9567:	e9 aa f6 ff ff       	jmp    8c16 <fwp_write+0x96>
    956c:	0f 1f 40 00          	nopl   0x0(%rax)
    9570:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9575:	ba 01 00 00 00       	mov    $0x1,%edx
    957a:	48 89 df             	mov    %rbx,%rdi
    957d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    9582:	e8 69 ab ff ff       	call   40f0 <buf_put>
    9587:	e9 8a f6 ff ff       	jmp    8c16 <fwp_write+0x96>
    958c:	0f 1f 40 00          	nopl   0x0(%rax)
    9590:	48 8b 43 08          	mov    0x8(%rbx),%rax
    9594:	48 8b 13             	mov    (%rbx),%rdx
    9597:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    959c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    95a0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    95a4:	e9 6d f6 ff ff       	jmp    8c16 <fwp_write+0x96>
    95a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95b0:	ba 02 00 00 00       	mov    $0x2,%edx
    95b5:	48 8d 35 99 5c 00 00 	lea    0x5c99(%rip),%rsi        # f255 <_IO_stdin_used+0x255>
    95bc:	48 89 df             	mov    %rbx,%rdi
    95bf:	e8 2c ab ff ff       	call   40f0 <buf_put>
    95c4:	e9 72 f8 ff ff       	jmp    8e3b <fwp_write+0x2bb>
    95c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    95d0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    95d5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    95da:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    95de:	48 89 f7             	mov    %rsi,%rdi
    95e1:	48 89 34 24          	mov    %rsi,(%rsp)
    95e5:	e8 56 9e ff ff       	call   3440 <strlen@plt>
    95ea:	48 8b 34 24          	mov    (%rsp),%rsi
    95ee:	48 89 df             	mov    %rbx,%rdi
    95f1:	48 89 c2             	mov    %rax,%rdx
    95f4:	e8 f7 aa ff ff       	call   40f0 <buf_put>
    95f9:	ba 03 00 00 00       	mov    $0x3,%edx
    95fe:	48 8d 35 73 5c 00 00 	lea    0x5c73(%rip),%rsi        # f278 <_IO_stdin_used+0x278>
    9605:	48 89 df             	mov    %rbx,%rdi
    9608:	e8 e3 aa ff ff       	call   40f0 <buf_put>
    960d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9612:	e9 35 f8 ff ff       	jmp    8e4c <fwp_write+0x2cc>
    9617:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    961e:	00 00 
    9620:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9625:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9629:	48 85 ff             	test   %rdi,%rdi
    962c:	0f 84 e2 fd ff ff    	je     9414 <fwp_write+0x894>
    9632:	48 8d 35 29 5c 00 00 	lea    0x5c29(%rip),%rsi        # f262 <_IO_stdin_used+0x262>
    9639:	e8 e2 9e ff ff       	call   3520 <strcmp@plt>
    963e:	85 c0                	test   %eax,%eax
    9640:	0f 95 c0             	setne  %al
    9643:	0f b6 c0             	movzbl %al,%eax
    9646:	e9 c1 fd ff ff       	jmp    940c <fwp_write+0x88c>
    964b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9650:	31 c0                	xor    %eax,%eax
    9652:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9659:	00 
    965a:	0f 97 c0             	seta   %al
    965d:	e9 aa fd ff ff       	jmp    940c <fwp_write+0x88c>
    9662:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9668:	48 89 df             	mov    %rbx,%rdi
    966b:	ba 02 00 00 00       	mov    $0x2,%edx
    9670:	48 8d 35 e8 5b 00 00 	lea    0x5be8(%rip),%rsi        # f25f <_IO_stdin_used+0x25f>
    9677:	e8 74 aa ff ff       	call   40f0 <buf_put>
    967c:	4c 89 e8             	mov    %r13,%rax
    967f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    9684:	31 c9                	xor    %ecx,%ecx
    9686:	48 c1 e0 04          	shl    $0x4,%rax
    968a:	48 89 df             	mov    %rbx,%rdi
    968d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    9692:	e8 e9 f4 ff ff       	call   8b80 <fwp_write>
    9697:	e9 5e f6 ff ff       	jmp    8cfa <fwp_write+0x17a>
    969c:	0f 1f 40 00          	nopl   0x0(%rax)
    96a0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    96a5:	48 85 ff             	test   %rdi,%rdi
    96a8:	79 0c                	jns    96b6 <fwp_write+0xb36>
    96aa:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    96b1:	00 
    96b2:	48 03 75 10          	add    0x10(%rbp),%rsi
    96b6:	48 63 3e             	movslq (%rsi),%rdi
    96b9:	83 f9 02             	cmp    $0x2,%ecx
    96bc:	89 fe                	mov    %edi,%esi
    96be:	48 0f 44 f7          	cmove  %rdi,%rsi
    96c2:	e9 f9 fb ff ff       	jmp    92c0 <fwp_write+0x740>
    96c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96ce:	00 00 
    96d0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    96d5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    96da:	48 85 ff             	test   %rdi,%rdi
    96dd:	0f 88 0f 03 00 00    	js     99f2 <fwp_write+0xe72>
    96e3:	49 0f bf 38          	movswq (%r8),%rdi
    96e7:	83 f9 01             	cmp    $0x1,%ecx
    96ea:	0f b7 f7             	movzwl %di,%esi
    96ed:	48 0f 44 f7          	cmove  %rdi,%rsi
    96f1:	e9 ca fb ff ff       	jmp    92c0 <fwp_write+0x740>
    96f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96fd:	00 00 00 
    9700:	ba 01 00 00 00       	mov    $0x1,%edx
    9705:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    970a:	48 83 c5 08          	add    $0x8,%rbp
    970e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9713:	e8 d8 a9 ff ff       	call   40f0 <buf_put>
    9718:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    971d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9722:	4d 85 ed             	test   %r13,%r13
    9725:	75 46                	jne    976d <fwp_write+0xbed>
    9727:	e9 04 01 00 00       	jmp    9830 <fwp_write+0xcb0>
    972c:	0f 1f 40 00          	nopl   0x0(%rax)
    9730:	41 80 f9 09          	cmp    $0x9,%r9b
    9734:	0f 84 d6 00 00 00    	je     9810 <fwp_write+0xc90>
    973a:	41 80 f9 0a          	cmp    $0xa,%r9b
    973e:	0f 85 9c 00 00 00    	jne    97e0 <fwp_write+0xc60>
    9744:	ba 02 00 00 00       	mov    $0x2,%edx
    9749:	48 8d 35 eb 5a 00 00 	lea    0x5aeb(%rip),%rsi        # f23b <_IO_stdin_used+0x23b>
    9750:	48 89 df             	mov    %rbx,%rdi
    9753:	e8 98 a9 ff ff       	call   40f0 <buf_put>
    9758:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    975f:	00 
    9760:	48 83 c5 01          	add    $0x1,%rbp
    9764:	49 39 ec             	cmp    %rbp,%r12
    9767:	0f 84 c3 00 00 00    	je     9830 <fwp_write+0xcb0>
    976d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    9772:	41 80 f9 0d          	cmp    $0xd,%r9b
    9776:	74 28                	je     97a0 <fwp_write+0xc20>
    9778:	7e b6                	jle    9730 <fwp_write+0xbb0>
    977a:	41 80 f9 22          	cmp    $0x22,%r9b
    977e:	74 40                	je     97c0 <fwp_write+0xc40>
    9780:	41 80 f9 5c          	cmp    $0x5c,%r9b
    9784:	75 5a                	jne    97e0 <fwp_write+0xc60>
    9786:	ba 02 00 00 00       	mov    $0x2,%edx
    978b:	48 8d 35 a6 5a 00 00 	lea    0x5aa6(%rip),%rsi        # f238 <_IO_stdin_used+0x238>
    9792:	48 89 df             	mov    %rbx,%rdi
    9795:	e8 56 a9 ff ff       	call   40f0 <buf_put>
    979a:	eb c4                	jmp    9760 <fwp_write+0xbe0>
    979c:	0f 1f 40 00          	nopl   0x0(%rax)
    97a0:	ba 02 00 00 00       	mov    $0x2,%edx
    97a5:	48 8d 35 95 5a 00 00 	lea    0x5a95(%rip),%rsi        # f241 <_IO_stdin_used+0x241>
    97ac:	48 89 df             	mov    %rbx,%rdi
    97af:	e8 3c a9 ff ff       	call   40f0 <buf_put>
    97b4:	eb aa                	jmp    9760 <fwp_write+0xbe0>
    97b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    97bd:	00 00 00 
    97c0:	ba 02 00 00 00       	mov    $0x2,%edx
    97c5:	48 8d 35 69 5a 00 00 	lea    0x5a69(%rip),%rsi        # f235 <_IO_stdin_used+0x235>
    97cc:	48 89 df             	mov    %rbx,%rdi
    97cf:	e8 1c a9 ff ff       	call   40f0 <buf_put>
    97d4:	eb 8a                	jmp    9760 <fwp_write+0xbe0>
    97d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    97dd:	00 00 00 
    97e0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    97e4:	0f 86 2e 01 00 00    	jbe    9918 <fwp_write+0xd98>
    97ea:	41 80 f9 7f          	cmp    $0x7f,%r9b
    97ee:	0f 84 24 01 00 00    	je     9918 <fwp_write+0xd98>
    97f4:	ba 01 00 00 00       	mov    $0x1,%edx
    97f9:	4c 89 fe             	mov    %r15,%rsi
    97fc:	48 89 df             	mov    %rbx,%rdi
    97ff:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9804:	e8 e7 a8 ff ff       	call   40f0 <buf_put>
    9809:	e9 52 ff ff ff       	jmp    9760 <fwp_write+0xbe0>
    980e:	66 90                	xchg   %ax,%ax
    9810:	ba 02 00 00 00       	mov    $0x2,%edx
    9815:	48 8d 35 22 5a 00 00 	lea    0x5a22(%rip),%rsi        # f23e <_IO_stdin_used+0x23e>
    981c:	48 89 df             	mov    %rbx,%rdi
    981f:	e8 cc a8 ff ff       	call   40f0 <buf_put>
    9824:	e9 37 ff ff ff       	jmp    9760 <fwp_write+0xbe0>
    9829:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9830:	ba 01 00 00 00       	mov    $0x1,%edx
    9835:	4c 89 fe             	mov    %r15,%rsi
    9838:	48 89 df             	mov    %rbx,%rdi
    983b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9840:	e8 ab a8 ff ff       	call   40f0 <buf_put>
    9845:	e9 cc f3 ff ff       	jmp    8c16 <fwp_write+0x96>
    984a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9850:	83 f8 04             	cmp    $0x4,%eax
    9853:	0f 85 bb fb ff ff    	jne    9414 <fwp_write+0x894>
    9859:	48 8b 04 24          	mov    (%rsp),%rax
    985d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9861:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9866:	48 c1 e8 3f          	shr    $0x3f,%rax
    986a:	e9 96 fc ff ff       	jmp    9505 <fwp_write+0x985>
    986f:	90                   	nop
    9870:	8b 0c 24             	mov    (%rsp),%ecx
    9873:	31 c0                	xor    %eax,%eax
    9875:	85 c9                	test   %ecx,%ecx
    9877:	0f 98 c0             	sets   %al
    987a:	e9 86 fc ff ff       	jmp    9505 <fwp_write+0x985>
    987f:	90                   	nop
    9880:	48 f7 d8             	neg    %rax
    9883:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    988a:	00 
    988b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9892:	2d 
    9893:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    989a:	00 
    989b:	48 83 d2 00          	adc    $0x0,%rdx
    989f:	48 89 c6             	mov    %rax,%rsi
    98a2:	48 f7 da             	neg    %rdx
    98a5:	e8 96 a1 ff ff       	call   3a40 <fwp_fmt_u128>
    98aa:	e9 51 f3 ff ff       	jmp    8c00 <fwp_write+0x80>
    98af:	90                   	nop
    98b0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    98b5:	e9 c3 f5 ff ff       	jmp    8e7d <fwp_write+0x2fd>
    98ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98c0:	4c 89 e9             	mov    %r13,%rcx
    98c3:	48 c1 e1 04          	shl    $0x4,%rcx
    98c7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    98cc:	48 85 ff             	test   %rdi,%rdi
    98cf:	0f 89 eb f9 ff ff    	jns    92c0 <fwp_write+0x740>
    98d5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    98d9:	48 89 ce             	mov    %rcx,%rsi
    98dc:	e9 df f9 ff ff       	jmp    92c0 <fwp_write+0x740>
    98e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    98e8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    98ef:	00 
    98f0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    98f4:	e9 20 fa ff ff       	jmp    9319 <fwp_write+0x799>
    98f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9900:	ba 02 00 00 00       	mov    $0x2,%edx
    9905:	48 8d 35 f4 58 00 00 	lea    0x58f4(%rip),%rsi        # f200 <_IO_stdin_used+0x200>
    990c:	e9 2d f7 ff ff       	jmp    903e <fwp_write+0x4be>
    9911:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9918:	4c 8d 05 25 59 00 00 	lea    0x5925(%rip),%r8        # f244 <_IO_stdin_used+0x244>
    991f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9924:	31 c0                	xor    %eax,%eax
    9926:	ba 02 00 00 00       	mov    $0x2,%edx
    992b:	be 10 00 00 00       	mov    $0x10,%esi
    9930:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9937:	00 
    9938:	e8 63 9a ff ff       	call   33a0 <__snprintf_chk@plt>
    993d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9944:	00 
    9945:	e8 f6 9a ff ff       	call   3440 <strlen@plt>
    994a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9951:	00 
    9952:	48 89 df             	mov    %rbx,%rdi
    9955:	48 89 c2             	mov    %rax,%rdx
    9958:	e8 93 a7 ff ff       	call   40f0 <buf_put>
    995d:	e9 fe fd ff ff       	jmp    9760 <fwp_write+0xbe0>
    9962:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9968:	66 0f ef c0          	pxor   %xmm0,%xmm0
    996c:	48 8d 35 87 58 00 00 	lea    0x5887(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    9973:	48 8d 05 7f 58 00 00 	lea    0x587f(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    997a:	4c 89 e7             	mov    %r12,%rdi
    997d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9981:	48 0f 46 f0          	cmovbe %rax,%rsi
    9985:	e8 56 9a ff ff       	call   33e0 <strcpy@plt>
    998a:	e9 71 f2 ff ff       	jmp    8c00 <fwp_write+0x80>
    998f:	90                   	nop
    9990:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9994:	48 8d 35 5f 58 00 00 	lea    0x585f(%rip),%rsi        # f1fa <_IO_stdin_used+0x1fa>
    999b:	48 8d 05 57 58 00 00 	lea    0x5857(%rip),%rax        # f1f9 <_IO_stdin_used+0x1f9>
    99a2:	0f 2f c8             	comiss %xmm0,%xmm1
    99a5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    99ac:	00 
    99ad:	4c 89 e7             	mov    %r12,%rdi
    99b0:	48 0f 46 f0          	cmovbe %rax,%rsi
    99b4:	e8 27 9a ff ff       	call   33e0 <strcpy@plt>
    99b9:	e9 42 f2 ff ff       	jmp    8c00 <fwp_write+0x80>
    99be:	66 90                	xchg   %ax,%ax
    99c0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    99c5:	45 85 c0             	test   %r8d,%r8d
    99c8:	75 34                	jne    99fe <fwp_write+0xe7e>
    99ca:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    99d1:	00 
    99d2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    99d9:	00 00 
    99db:	0f 85 74 f6 ff ff    	jne    9055 <fwp_write+0x4d5>
    99e1:	ba 02 00 00 00       	mov    $0x2,%edx
    99e6:	48 8d 35 88 58 00 00 	lea    0x5888(%rip),%rsi        # f275 <_IO_stdin_used+0x275>
    99ed:	e9 a1 f3 ff ff       	jmp    8d93 <fwp_write+0x213>
    99f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    99f6:	49 89 f0             	mov    %rsi,%r8
    99f9:	e9 e5 fc ff ff       	jmp    96e3 <fwp_write+0xb63>
    99fe:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9a03:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9a08:	85 ff                	test   %edi,%edi
    9a0a:	0f 84 fa f3 ff ff    	je     8e0a <fwp_write+0x28a>
    9a10:	ba 01 00 00 00       	mov    $0x1,%edx
    9a15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9a1a:	48 89 df             	mov    %rbx,%rdi
    9a1d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9a22:	e8 c9 a6 ff ff       	call   40f0 <buf_put>
    9a27:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    9a2c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9a31:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9a37:	85 c0                	test   %eax,%eax
    9a39:	0f 8f f0 f3 ff ff    	jg     8e2f <fwp_write+0x2af>
    9a3f:	e9 34 f4 ff ff       	jmp    8e78 <fwp_write+0x2f8>
    9a44:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9a48:	49 89 c5             	mov    %rax,%r13
    9a4b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9a50:	49 89 c4             	mov    %rax,%r12
    9a53:	49 c1 fd 3f          	sar    $0x3f,%r13
    9a57:	4c 09 e8             	or     %r13,%rax
    9a5a:	0f 84 a7 00 00 00    	je     9b07 <fwp_write+0xf87>
    9a60:	48 8d 2d 59 78 00 00 	lea    0x7859(%rip),%rbp        # 112c0 <units.0>
    9a67:	4d 89 e7             	mov    %r12,%r15
    9a6a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9a6e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9a73:	4c 89 ff             	mov    %r15,%rdi
    9a76:	4c 89 ee             	mov    %r13,%rsi
    9a79:	44 89 0c 24          	mov    %r9d,(%rsp)
    9a7d:	48 99                	cqto
    9a7f:	48 89 d1             	mov    %rdx,%rcx
    9a82:	48 89 c2             	mov    %rax,%rdx
    9a85:	e8 36 50 00 00       	call   eac0 <__divmodti4>
    9a8a:	44 8b 0c 24          	mov    (%rsp),%r9d
    9a8e:	48 89 c1             	mov    %rax,%rcx
    9a91:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9a96:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    9a9b:	0f 84 94 00 00 00    	je     9b35 <fwp_write+0xfb5>
    9aa1:	41 83 c1 01          	add    $0x1,%r9d
    9aa5:	48 83 c5 10          	add    $0x10,%rbp
    9aa9:	41 83 f9 05          	cmp    $0x5,%r9d
    9aad:	75 bb                	jne    9a6a <fwp_write+0xeea>
    9aaf:	4d 85 ed             	test   %r13,%r13
    9ab2:	79 53                	jns    9b07 <fwp_write+0xf87>
    9ab4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9ab9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9abe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9ac3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9ac8:	48 99                	cqto
    9aca:	48 f7 d8             	neg    %rax
    9acd:	48 83 d2 00          	adc    $0x0,%rdx
    9ad1:	48 89 c6             	mov    %rax,%rsi
    9ad4:	48 f7 da             	neg    %rdx
    9ad7:	e8 64 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9adc:	49 89 e8             	mov    %rbp,%r8
    9adf:	ba 00 02 00 00       	mov    $0x200,%edx
    9ae4:	be 02 00 00 00       	mov    $0x2,%esi
    9ae9:	31 c0                	xor    %eax,%eax
    9aeb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9af2:	00 
    9af3:	48 8d 0d 76 57 00 00 	lea    0x5776(%rip),%rcx        # f270 <_IO_stdin_used+0x270>
    9afa:	4c 89 e7             	mov    %r12,%rdi
    9afd:	e8 be 9b ff ff       	call   36c0 <__sprintf_chk@plt>
    9b02:	e9 f9 f0 ff ff       	jmp    8c00 <fwp_write+0x80>
    9b07:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9b0c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9b11:	31 d2                	xor    %edx,%edx
    9b13:	48 89 ef             	mov    %rbp,%rdi
    9b16:	e8 25 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9b1b:	eb bf                	jmp    9adc <fwp_write+0xf5c>
    9b1d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9b24:	4e 61 4e 00 
    9b28:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9b2f:	00 
    9b30:	e9 cb f0 ff ff       	jmp    8c00 <fwp_write+0x80>
    9b35:	44 89 0c 24          	mov    %r9d,(%rsp)
    9b39:	48 89 c8             	mov    %rcx,%rax
    9b3c:	48 85 d2             	test   %rdx,%rdx
    9b3f:	78 51                	js     9b92 <fwp_write+0x1012>
    9b41:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9b46:	48 89 c6             	mov    %rax,%rsi
    9b49:	48 89 ef             	mov    %rbp,%rdi
    9b4c:	e8 ef 9e ff ff       	call   3a40 <fwp_fmt_u128>
    9b51:	44 8b 0c 24          	mov    (%rsp),%r9d
    9b55:	49 63 c1             	movslq %r9d,%rax
    9b58:	49 89 e8             	mov    %rbp,%r8
    9b5b:	ba 00 02 00 00       	mov    $0x200,%edx
    9b60:	be 02 00 00 00       	mov    $0x2,%esi
    9b65:	48 c1 e0 04          	shl    $0x4,%rax
    9b69:	48 8d 3d 50 77 00 00 	lea    0x7750(%rip),%rdi        # 112c0 <units.0>
    9b70:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9b77:	00 
    9b78:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    9b7c:	48 8d 0d e8 56 00 00 	lea    0x56e8(%rip),%rcx        # f26b <_IO_stdin_used+0x26b>
    9b83:	4c 89 e7             	mov    %r12,%rdi
    9b86:	31 c0                	xor    %eax,%eax
    9b88:	e8 33 9b ff ff       	call   36c0 <__sprintf_chk@plt>
    9b8d:	e9 6e f0 ff ff       	jmp    8c00 <fwp_write+0x80>
    9b92:	48 f7 d8             	neg    %rax
    9b95:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9b9a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9b9f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9ba4:	48 83 d2 00          	adc    $0x0,%rdx
    9ba8:	48 89 c6             	mov    %rax,%rsi
    9bab:	48 f7 da             	neg    %rdx
    9bae:	e8 8d 9e ff ff       	call   3a40 <fwp_fmt_u128>
    9bb3:	44 8b 0c 24          	mov    (%rsp),%r9d
    9bb7:	eb 9c                	jmp    9b55 <fwp_write+0xfd5>
    9bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009bc0 <fwp_hof0.constprop.0>:
    9bc0:	41 57                	push   %r15
    9bc2:	41 56                	push   %r14
    9bc4:	41 55                	push   %r13
    9bc6:	41 54                	push   %r12
    9bc8:	55                   	push   %rbp
    9bc9:	53                   	push   %rbx
    9bca:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9bd1:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9bd8:	00 00 
    9bda:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9be1:	00 
    9be2:	31 c0                	xor    %eax,%eax
    9be4:	48 85 f6             	test   %rsi,%rsi
    9be7:	0f 84 2a 0f 00 00    	je     ab17 <fwp_hof0.constprop.0+0xf57>
    9bed:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
    9bf2:	48 8d 2d 27 1c 06 00 	lea    0x61c27(%rip),%rbp        # 6b820 <fwp_heap>
    9bf9:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
    9bfe:	66 90                	xchg   %ax,%ax
    9c00:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9c07:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9c0c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9c13:	48 c1 e2 10          	shl    $0x10,%rdx
    9c17:	48 39 d0             	cmp    %rdx,%rax
    9c1a:	73 71                	jae    9c8d <fwp_hof0.constprop.0+0xcd>
    9c1c:	48 89 c2             	mov    %rax,%rdx
    9c1f:	48 c1 ea 10          	shr    $0x10,%rdx
    9c23:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c27:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9c2e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c32:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9c36:	48 85 ff             	test   %rdi,%rdi
    9c39:	74 52                	je     9c8d <fwp_hof0.constprop.0+0xcd>
    9c3b:	0f b6 0a             	movzbl (%rdx),%ecx
    9c3e:	80 f9 02             	cmp    $0x2,%cl
    9c41:	0f 84 c1 15 00 00    	je     b208 <fwp_hof0.constprop.0+0x1648>
    9c47:	80 f9 01             	cmp    $0x1,%cl
    9c4a:	75 41                	jne    9c8d <fwp_hof0.constprop.0+0xcd>
    9c4c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c4f:	0f b7 c0             	movzwl %ax,%eax
    9c52:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c55:	48 0f af c1          	imul   %rcx,%rax
    9c59:	48 c1 e8 20          	shr    $0x20,%rax
    9c5d:	48 39 d0             	cmp    %rdx,%rax
    9c60:	73 2b                	jae    9c8d <fwp_hof0.constprop.0+0xcd>
    9c62:	48 01 c7             	add    %rax,%rdi
    9c65:	0f b6 07             	movzbl (%rdi),%eax
    9c68:	84 c0                	test   %al,%al
    9c6a:	74 21                	je     9c8d <fwp_hof0.constprop.0+0xcd>
    9c6c:	44 8b 0d 75 38 06 00 	mov    0x63875(%rip),%r9d        # 6d4e8 <iteration_active>
    9c73:	45 85 c9             	test   %r9d,%r9d
    9c76:	74 08                	je     9c80 <fwp_hof0.constprop.0+0xc0>
    9c78:	48 83 05 50 38 06 00 	addq   $0x1,0x63850(%rip)        # 6d4d0 <iteration_retains>
    9c7f:	01 
    9c80:	3c fd                	cmp    $0xfd,%al
    9c82:	0f 87 56 17 00 00    	ja     b3de <fwp_hof0.constprop.0+0x181e>
    9c88:	83 c0 01             	add    $0x1,%eax
    9c8b:	88 07                	mov    %al,(%rdi)
    9c8d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    9c92:	45 31 c0             	xor    %r8d,%r8d
    9c95:	48 c7 44 24 28 c6 00 	movq   $0xc6,0x28(%rsp)
    9c9c:	00 00 
    9c9e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9ca3:	4d 89 c5             	mov    %r8,%r13
    9ca6:	4d 85 c0             	test   %r8,%r8
    9ca9:	0f 85 a1 9a ff ff    	jne    3750 <fwp_hof0.constprop.0.cold+0x5>
    9caf:	48 8b 05 02 38 06 00 	mov    0x63802(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9cb6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9cbd:	4c 8d 3d fc d7 ff ff 	lea    -0x2804(%rip),%r15        # 74c0 <fwp_tape_scope_release>
    9cc4:	c7 44 24 7c ff ff ff 	movl   $0xffffffff,0x7c(%rsp)
    9ccb:	ff 
    9ccc:	4c 89 bc 24 88 00 00 	mov    %r15,0x88(%rsp)
    9cd3:	00 
    9cd4:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9cdb:	00 
    9cdc:	48 8d 44 24 7c       	lea    0x7c(%rsp),%rax
    9ce1:	48 c1 e2 10          	shl    $0x10,%rdx
    9ce5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    9cea:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    9cf1:	00 
    9cf2:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    9cf9:	00 
    9cfa:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9cff:	48 89 05 b2 37 06 00 	mov    %rax,0x637b2(%rip)        # 6d4b8 <fwp_cleanups>
    9d06:	48 8d 05 03 93 00 00 	lea    0x9303(%rip),%rax        # 13010 <fc37>
    9d0d:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9d14:	48 39 d0             	cmp    %rdx,%rax
    9d17:	73 71                	jae    9d8a <fwp_hof0.constprop.0+0x1ca>
    9d19:	48 89 c2             	mov    %rax,%rdx
    9d1c:	48 c1 ea 10          	shr    $0x10,%rdx
    9d20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d24:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9d2b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d2f:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9d33:	48 85 ff             	test   %rdi,%rdi
    9d36:	74 52                	je     9d8a <fwp_hof0.constprop.0+0x1ca>
    9d38:	0f b6 0a             	movzbl (%rdx),%ecx
    9d3b:	80 f9 02             	cmp    $0x2,%cl
    9d3e:	0f 84 bc 12 00 00    	je     b000 <fwp_hof0.constprop.0+0x1440>
    9d44:	80 f9 01             	cmp    $0x1,%cl
    9d47:	75 41                	jne    9d8a <fwp_hof0.constprop.0+0x1ca>
    9d49:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9d4c:	0f b7 c0             	movzwl %ax,%eax
    9d4f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9d52:	48 0f af c1          	imul   %rcx,%rax
    9d56:	48 c1 e8 20          	shr    $0x20,%rax
    9d5a:	48 39 d0             	cmp    %rdx,%rax
    9d5d:	73 2b                	jae    9d8a <fwp_hof0.constprop.0+0x1ca>
    9d5f:	48 01 c7             	add    %rax,%rdi
    9d62:	0f b6 07             	movzbl (%rdi),%eax
    9d65:	84 c0                	test   %al,%al
    9d67:	74 21                	je     9d8a <fwp_hof0.constprop.0+0x1ca>
    9d69:	44 8b 05 78 37 06 00 	mov    0x63778(%rip),%r8d        # 6d4e8 <iteration_active>
    9d70:	45 85 c0             	test   %r8d,%r8d
    9d73:	74 08                	je     9d7d <fwp_hof0.constprop.0+0x1bd>
    9d75:	48 83 05 53 37 06 00 	addq   $0x1,0x63753(%rip)        # 6d4d0 <iteration_retains>
    9d7c:	01 
    9d7d:	3c fd                	cmp    $0xfd,%al
    9d7f:	0f 87 f5 15 00 00    	ja     b37a <fwp_hof0.constprop.0+0x17ba>
    9d85:	83 c0 01             	add    $0x1,%eax
    9d88:	88 07                	mov    %al,(%rdi)
    9d8a:	48 8d 3d 7f 92 00 00 	lea    0x927f(%rip),%rdi        # 13010 <fc37>
    9d91:	e8 ba d3 ff ff       	call   7150 <fwp_closure_drop>
    9d96:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d9b:	48 85 c0             	test   %rax,%rax
    9d9e:	0f 84 e7 14 00 00    	je     b28b <fwp_hof0.constprop.0+0x16cb>
    9da4:	31 d2                	xor    %edx,%edx
    9da6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9dad:	00 00 00 
    9db0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9db4:	48 83 c2 01          	add    $0x1,%rdx
    9db8:	48 85 c0             	test   %rax,%rax
    9dbb:	75 f3                	jne    9db0 <fwp_hof0.constprop.0+0x1f0>
    9dbd:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    9dc4:	0f 87 d6 16 00 00    	ja     b4a0 <fwp_hof0.constprop.0+0x18e0>
    9dca:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    9dcf:	8b 35 8b 92 00 00    	mov    0x928b(%rip),%esi        # 13060 <registered_finish.1>
    9dd5:	85 f6                	test   %esi,%esi
    9dd7:	0f 84 e3 11 00 00    	je     afc0 <fwp_hof0.constprop.0+0x1400>
    9ddd:	4c 8b 35 f4 92 01 00 	mov    0x192f4(%rip),%r14        # 230d8 <fwp_tape_next_slot>
    9de4:	48 8b 1d fd 92 01 00 	mov    0x192fd(%rip),%rbx        # 230e8 <fwp_ntapes>
    9deb:	49 39 de             	cmp    %rbx,%r14
    9dee:	0f 8d fc 0d 00 00    	jge    abf0 <fwp_hof0.constprop.0+0x1030>
    9df4:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9df8:	48 03 05 f1 92 01 00 	add    0x192f1(%rip),%rax        # 230f0 <fwp_tapes>
    9dff:	90                   	nop
    9e00:	8b 48 04             	mov    0x4(%rax),%ecx
    9e03:	85 c9                	test   %ecx,%ecx
    9e05:	75 0c                	jne    9e13 <fwp_hof0.constprop.0+0x253>
    9e07:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9e0d:	0f 86 dd 0d 00 00    	jbe    abf0 <fwp_hof0.constprop.0+0x1030>
    9e13:	49 83 c6 01          	add    $0x1,%r14
    9e17:	48 83 c0 68          	add    $0x68,%rax
    9e1b:	49 39 de             	cmp    %rbx,%r14
    9e1e:	75 e0                	jne    9e00 <fwp_hof0.constprop.0+0x240>
    9e20:	48 81 fb fe ff 00 00 	cmp    $0xfffe,%rbx
    9e27:	0f 8f 8b 16 00 00    	jg     b4b8 <fwp_hof0.constprop.0+0x18f8>
    9e2d:	48 3b 1d ac 92 01 00 	cmp    0x192ac(%rip),%rbx        # 230e0 <fwp_tapes_cap>
    9e34:	4c 8b 25 b5 92 01 00 	mov    0x192b5(%rip),%r12        # 230f0 <fwp_tapes>
    9e3b:	75 4d                	jne    9e8a <fwp_hof0.constprop.0+0x2ca>
    9e3d:	48 85 db             	test   %rbx,%rbx
    9e40:	0f 84 ab 14 00 00    	je     b2f1 <fwp_hof0.constprop.0+0x1731>
    9e46:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    9e4a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9e4f:	49 39 c6             	cmp    %rax,%r14
    9e52:	4c 0f 4f f0          	cmovg  %rax,%r14
    9e56:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    9e5a:	31 d2                	xor    %edx,%edx
    9e5c:	4c 89 e7             	mov    %r12,%rdi
    9e5f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9e65:	e8 26 b3 ff ff       	call   5190 <ad_raw_realloc>
    9e6a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9e70:	48 85 c0             	test   %rax,%rax
    9e73:	49 89 c4             	mov    %rax,%r12
    9e76:	0f 84 90 16 00 00    	je     b50c <fwp_hof0.constprop.0+0x194c>
    9e7c:	48 89 05 6d 92 01 00 	mov    %rax,0x1926d(%rip)        # 230f0 <fwp_tapes>
    9e83:	4c 89 35 56 92 01 00 	mov    %r14,0x19256(%rip)        # 230e0 <fwp_tapes_cap>
    9e8a:	48 6b cb 68          	imul   $0x68,%rbx,%rcx
    9e8e:	31 c0                	xor    %eax,%eax
    9e90:	49 89 de             	mov    %rbx,%r14
    9e93:	4c 01 e1             	add    %r12,%rcx
    9e96:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    9e9a:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
    9ea1:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9ea5:	48 c7 41 60 00 00 00 	movq   $0x0,0x60(%rcx)
    9eac:	00 
    9ead:	48 29 f9             	sub    %rdi,%rcx
    9eb0:	83 c1 68             	add    $0x68,%ecx
    9eb3:	c1 e9 03             	shr    $0x3,%ecx
    9eb6:	f3 48 ab             	rep stos %rax,(%rdi)
    9eb9:	48 8d 43 01          	lea    0x1(%rbx),%rax
    9ebd:	48 89 05 24 92 01 00 	mov    %rax,0x19224(%rip)        # 230e8 <fwp_ntapes>
    9ec4:	49 6b de 68          	imul   $0x68,%r14,%rbx
    9ec8:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9ecc:	48 8d 3d 8d 52 00 00 	lea    0x528d(%rip),%rdi        # f160 <_IO_stdin_used+0x160>
    9ed3:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9ed8:	4c 01 e3             	add    %r12,%rbx
    9edb:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    9ee2:	00 
    9ee3:	e8 a8 94 ff ff       	call   3390 <getenv@plt>
    9ee8:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9eee:	48 85 c0             	test   %rax,%rax
    9ef1:	0f 84 11 0d 00 00    	je     ac08 <fwp_hof0.constprop.0+0x1048>
    9ef7:	80 38 30             	cmpb   $0x30,(%rax)
    9efa:	0f 85 08 0d 00 00    	jne    ac08 <fwp_hof0.constprop.0+0x1048>
    9f00:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9f04:	0f 85 fe 0c 00 00    	jne    ac08 <fwp_hof0.constprop.0+0x1048>
    9f0a:	8b 03                	mov    (%rbx),%eax
    9f0c:	49 8d 76 01          	lea    0x1(%r14),%rsi
    9f10:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    9f14:	c7 43 04 01 00 00 00 	movl   $0x1,0x4(%rbx)
    9f1b:	8d 48 01             	lea    0x1(%rax),%ecx
    9f1e:	48 8b 05 3b 5e 00 00 	mov    0x5e3b(%rip),%rax        # fd60 <msg.4+0x20>
    9f25:	48 89 35 ac 91 01 00 	mov    %rsi,0x191ac(%rip)        # 230d8 <fwp_tape_next_slot>
    9f2c:	89 0b                	mov    %ecx,(%rbx)
    9f2e:	48 89 43 58          	mov    %rax,0x58(%rbx)
    9f32:	48 8b 05 7f 35 06 00 	mov    0x6357f(%rip),%rax        # 6d4b8 <fwp_cleanups>
    9f39:	48 c7 43 50 00 00 00 	movq   $0x0,0x50(%rbx)
    9f40:	00 
    9f41:	48 85 c0             	test   %rax,%rax
    9f44:	75 16                	jne    9f5c <fwp_hof0.constprop.0+0x39c>
    9f46:	e9 b5 15 00 00       	jmp    b500 <fwp_hof0.constprop.0+0x1940>
    9f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9f50:	48 8b 00             	mov    (%rax),%rax
    9f53:	48 85 c0             	test   %rax,%rax
    9f56:	0f 84 a4 15 00 00    	je     b500 <fwp_hof0.constprop.0+0x1940>
    9f5c:	4c 39 78 08          	cmp    %r15,0x8(%rax)
    9f60:	75 ee                	jne    9f50 <fwp_hof0.constprop.0+0x390>
    9f62:	4c 8b 48 10          	mov    0x10(%rax),%r9
    9f66:	44 89 f7             	mov    %r14d,%edi
    9f69:	49 63 01             	movslq (%r9),%rax
    9f6c:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
    9f70:	89 43 5c             	mov    %eax,0x5c(%rbx)
    9f73:	85 c0                	test   %eax,%eax
    9f75:	78 09                	js     9f80 <fwp_hof0.constprop.0+0x3c0>
    9f77:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9f7b:	45 89 74 04 58       	mov    %r14d,0x58(%r12,%rax,1)
    9f80:	41 89 39             	mov    %edi,(%r9)
    9f83:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9f88:	31 db                	xor    %ebx,%ebx
    9f8a:	48 89 f8             	mov    %rdi,%rax
    9f8d:	48 85 ff             	test   %rdi,%rdi
    9f90:	0f 84 ba 0d 00 00    	je     ad50 <fwp_hof0.constprop.0+0x1190>
    9f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f9d:	00 00 00 
    9fa0:	48 8b 40 10          	mov    0x10(%rax),%rax
    9fa4:	48 83 c3 01          	add    $0x1,%rbx
    9fa8:	48 85 c0             	test   %rax,%rax
    9fab:	75 f3                	jne    9fa0 <fwp_hof0.constprop.0+0x3e0>
    9fad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9fb2:	0f 1f 00             	nopl   (%rax)
    9fb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fbc:	00 00 00 00 
    9fc0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9fc4:	48 83 c0 01          	add    $0x1,%rax
    9fc8:	48 85 d2             	test   %rdx,%rdx
    9fcb:	75 f3                	jne    9fc0 <fwp_hof0.constprop.0+0x400>
    9fcd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    9fd4:	ff ff 1f 
    9fd7:	48 39 c2             	cmp    %rax,%rdx
    9fda:	0f 82 b4 14 00 00    	jb     b494 <fwp_hof0.constprop.0+0x18d4>
    9fe0:	48 85 db             	test   %rbx,%rbx
    9fe3:	0f 8e 67 0d 00 00    	jle    ad50 <fwp_hof0.constprop.0+0x1190>
    9fe9:	48 39 c3             	cmp    %rax,%rbx
    9fec:	48 0f 47 d8          	cmova  %rax,%rbx
    9ff0:	48 89 d8             	mov    %rbx,%rax
    9ff3:	48 c1 e8 3c          	shr    $0x3c,%rax
    9ff7:	0f 85 97 14 00 00    	jne    b494 <fwp_hof0.constprop.0+0x18d4>
    9ffd:	4c 8d 3c 1b          	lea    (%rbx,%rbx,1),%r15
    a001:	48 c1 e1 10          	shl    $0x10,%rcx
    a005:	48 09 f1             	or     %rsi,%rcx
    a008:	4a 8d 3c fd 08 00 00 	lea    0x8(,%r15,8),%rdi
    a00f:	00 
    a010:	be 02 00 00 00       	mov    $0x2,%esi
    a015:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a01a:	e8 f1 be ff ff       	call   5f10 <fwp_heap_alloc>
    a01f:	4c 89 38             	mov    %r15,(%rax)
    a022:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a029:	49 89 c6             	mov    %rax,%r14
    a02c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a033:	48 c1 e2 10          	shl    $0x10,%rdx
    a037:	48 39 d0             	cmp    %rdx,%rax
    a03a:	0f 83 00 11 00 00    	jae    b140 <fwp_hof0.constprop.0+0x1580>
    a040:	48 89 c2             	mov    %rax,%rdx
    a043:	48 c1 ea 10          	shr    $0x10,%rdx
    a047:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    a04b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a052:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    a056:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    a05a:	4d 85 ff             	test   %r15,%r15
    a05d:	74 3a                	je     a099 <fwp_hof0.constprop.0+0x4d9>
    a05f:	0f b6 32             	movzbl (%rdx),%esi
    a062:	40 80 fe 02          	cmp    $0x2,%sil
    a066:	0f 84 56 0d 00 00    	je     adc2 <fwp_hof0.constprop.0+0x1202>
    a06c:	40 80 fe 01          	cmp    $0x1,%sil
    a070:	75 27                	jne    a099 <fwp_hof0.constprop.0+0x4d9>
    a072:	8b 72 18             	mov    0x18(%rdx),%esi
    a075:	0f b7 c0             	movzwl %ax,%eax
    a078:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a07b:	48 0f af c6          	imul   %rsi,%rax
    a07f:	48 c1 e8 20          	shr    $0x20,%rax
    a083:	48 39 d0             	cmp    %rdx,%rax
    a086:	73 11                	jae    a099 <fwp_hof0.constprop.0+0x4d9>
    a088:	49 01 c7             	add    %rax,%r15
    a08b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    a08f:	0f 84 40 0d 00 00    	je     add5 <fwp_hof0.constprop.0+0x1215>
    a095:	41 c6 07 01          	movb   $0x1,(%r15)
    a099:	48 85 db             	test   %rbx,%rbx
    a09c:	74 56                	je     a0f4 <fwp_hof0.constprop.0+0x534>
    a09e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a0a3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a0a8:	31 c0                	xor    %eax,%eax
    a0aa:	48 c1 e6 20          	shl    $0x20,%rsi
    a0ae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a0b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0bc:	00 00 00 00 
    a0c0:	48 89 c1             	mov    %rax,%rcx
    a0c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a0c8:	48 01 f1             	add    %rsi,%rcx
    a0cb:	0f 80 7f 96 ff ff    	jo     3750 <fwp_hof0.constprop.0.cold+0x5>
    a0d1:	66 48 0f 6e e1       	movq   %rcx,%xmm4
    a0d6:	48 89 c1             	mov    %rax,%rcx
    a0d9:	48 83 c0 01          	add    $0x1,%rax
    a0dd:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a0e1:	48 c1 e1 04          	shl    $0x4,%rcx
    a0e5:	41 0f 11 44 0e 08    	movups %xmm0,0x8(%r14,%rcx,1)
    a0eb:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a0ef:	48 39 d8             	cmp    %rbx,%rax
    a0f2:	72 cc                	jb     a0c0 <fwp_hof0.constprop.0+0x500>
    a0f4:	49 8b 06             	mov    (%r14),%rax
    a0f7:	48 d1 e8             	shr    $1,%rax
    a0fa:	0f 85 00 0d 00 00    	jne    ae00 <fwp_hof0.constprop.0+0x1240>
    a100:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
    a107:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    a10e:	66 90                	xchg   %ax,%ax
    a110:	4c 89 f7             	mov    %r14,%rdi
    a113:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    a118:	e8 f3 e2 ff ff       	call   8410 <fwp_drop10>
    a11d:	4c 63 7c 24 10       	movslq 0x10(%rsp),%r15
    a122:	4c 89 ff             	mov    %r15,%rdi
    a125:	e8 06 a6 ff ff       	call   4730 <fwp_tape_of>
    a12a:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    a12f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    a134:	48 89 c6             	mov    %rax,%rsi
    a137:	0f 85 44 14 00 00    	jne    b581 <fwp_hof0.constprop.0+0x19c1>
    a13d:	48 89 c7             	mov    %rax,%rdi
    a140:	e8 4b 9b ff ff       	call   3c90 <fwp_tape_unlink_scope>
    a145:	48 8b 5e 48          	mov    0x48(%rsi),%rbx
    a149:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a14e:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a155:	4c 8b 76 08          	mov    0x8(%rsi),%r14
    a159:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a15d:	66 48 0f 6e fb       	movq   %rbx,%xmm7
    a162:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a167:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a16c:	4c 8b 56 40          	mov    0x40(%rsi),%r10
    a170:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a174:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a17a:	77 1a                	ja     a196 <fwp_hof0.constprop.0+0x5d6>
    a17c:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
    a181:	83 e8 01             	sub    $0x1,%eax
    a184:	48 98                	cltq
    a186:	48 3b 05 4b 8f 01 00 	cmp    0x18f4b(%rip),%rax        # 230d8 <fwp_tape_next_slot>
    a18d:	7d 07                	jge    a196 <fwp_hof0.constprop.0+0x5d6>
    a18f:	48 89 05 42 8f 01 00 	mov    %rax,0x18f42(%rip)        # 230d8 <fwp_tape_next_slot>
    a196:	48 8b 05 1b 33 06 00 	mov    0x6331b(%rip),%rax        # 6d4b8 <fwp_cleanups>
    a19d:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a1a1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a1a8:	00 
    a1a9:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a1ad:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a1b4:	00 
    a1b5:	48 8d 05 a4 b0 ff ff 	lea    -0x4f5c(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    a1bc:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    a1c3:	00 
    a1c4:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    a1cb:	00 
    a1cc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a1d1:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a1d8:	00 
    a1d9:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    a1e0:	00 
    a1e1:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a1e8:	00 
    a1e9:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a1f0:	00 
    a1f1:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a1f5:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a1f9:	48 89 05 b8 32 06 00 	mov    %rax,0x632b8(%rip)        # 6d4b8 <fwp_cleanups>
    a200:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    a207:	00 
    a208:	0f 29 9c 24 c0 00 00 	movaps %xmm3,0xc0(%rsp)
    a20f:	00 
    a210:	0f 29 94 24 d0 00 00 	movaps %xmm2,0xd0(%rsp)
    a217:	00 
    a218:	0f 11 84 24 e8 00 00 	movups %xmm0,0xe8(%rsp)
    a21f:	00 
    a220:	4d 85 c9             	test   %r9,%r9
    a223:	0f 88 e7 0d 00 00    	js     b010 <fwp_hof0.constprop.0+0x1450>
    a229:	4c 89 c8             	mov    %r9,%rax
    a22c:	48 c1 f8 20          	sar    $0x20,%rax
    a230:	49 39 c7             	cmp    %rax,%r15
    a233:	0f 85 2f 12 00 00    	jne    b468 <fwp_hof0.constprop.0+0x18a8>
    a239:	44 89 c9             	mov    %r9d,%ecx
    a23c:	49 89 cf             	mov    %rcx,%r15
    a23f:	48 39 ca             	cmp    %rcx,%rdx
    a242:	0f 8e 2c 12 00 00    	jle    b474 <fwp_hof0.constprop.0+0x18b4>
    a248:	49 39 ce             	cmp    %rcx,%r14
    a24b:	0f 8e 5f 0c 00 00    	jle    aeb0 <fwp_hof0.constprop.0+0x12f0>
    a251:	49 39 de             	cmp    %rbx,%r14
    a254:	0f 8f 8e 0c 00 00    	jg     aee8 <fwp_hof0.constprop.0+0x1328>
    a25a:	4d 85 d2             	test   %r10,%r10
    a25d:	0f 84 d7 12 00 00    	je     b53a <fwp_hof0.constprop.0+0x197a>
    a263:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    a268:	4d 8d 7e ff          	lea    -0x1(%r14),%r15
    a26c:	31 f6                	xor    %esi,%esi
    a26e:	4c 89 d7             	mov    %r10,%rdi
    a271:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    a276:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
    a27d:	00 
    a27e:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    a283:	e8 28 92 ff ff       	call   34b0 <memset@plt>
    a288:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    a28e:	66 0f 6f 5c 24 50    	movdqa 0x50(%rsp),%xmm3
    a294:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
    a299:	49 89 c2             	mov    %rax,%r10
    a29c:	f2 0f 10 05 c4 5a 00 	movsd  0x5ac4(%rip),%xmm0        # fd68 <msg.4+0x28>
    a2a3:	00 
    a2a4:	f2 41 0f 58 04 ca    	addsd  (%r10,%rcx,8),%xmm0
    a2aa:	f2 41 0f 11 04 ca    	movsd  %xmm0,(%r10,%rcx,8)
    a2b0:	4d 39 fe             	cmp    %r15,%r14
    a2b3:	0f 8f 8f 00 00 00    	jg     a348 <fwp_hof0.constprop.0+0x788>
    a2b9:	0f 12 fb             	movhlps %xmm3,%xmm7
    a2bc:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    a2c1:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    a2c6:	4d 29 f7             	sub    %r14,%r15
    a2c9:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    a2ce:	0f 12 fa             	movhlps %xmm2,%xmm7
    a2d1:	4b 8d 1c f2          	lea    (%r10,%r14,8),%rbx
    a2d5:	66 49 0f 7e f9       	movq   %xmm7,%r9
    a2da:	4a 8d 04 be          	lea    (%rsi,%r15,4),%rax
    a2de:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a2e2:	48 29 f1             	sub    %rsi,%rcx
    a2e5:	4b 8d 14 f9          	lea    (%r9,%r15,8),%rdx
    a2e9:	4c 29 cb             	sub    %r9,%rbx
    a2ec:	4c 29 cf             	sub    %r9,%rdi
    a2ef:	eb 0b                	jmp    a2fc <fwp_hof0.constprop.0+0x73c>
    a2f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2f8:	48 83 e8 04          	sub    $0x4,%rax
    a2fc:	f2 0f 10 04 13       	movsd  (%rbx,%rdx,1),%xmm0
    a301:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a305:	7a 02                	jp     a309 <fwp_hof0.constprop.0+0x749>
    a307:	74 36                	je     a33f <fwp_hof0.constprop.0+0x77f>
    a309:	4c 63 04 01          	movslq (%rcx,%rax,1),%r8
    a30d:	45 85 c0             	test   %r8d,%r8d
    a310:	78 15                	js     a327 <fwp_hof0.constprop.0+0x767>
    a312:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    a317:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a31b:	f2 43 0f 58 0c c2    	addsd  (%r10,%r8,8),%xmm1
    a321:	f2 43 0f 11 0c c2    	movsd  %xmm1,(%r10,%r8,8)
    a327:	4c 63 00             	movslq (%rax),%r8
    a32a:	45 85 c0             	test   %r8d,%r8d
    a32d:	78 10                	js     a33f <fwp_hof0.constprop.0+0x77f>
    a32f:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a333:	f2 43 0f 58 04 c2    	addsd  (%r10,%r8,8),%xmm0
    a339:	f2 43 0f 11 04 c2    	movsd  %xmm0,(%r10,%r8,8)
    a33f:	48 83 ea 08          	sub    $0x8,%rdx
    a343:	48 39 c6             	cmp    %rax,%rsi
    a346:	75 b0                	jne    a2f8 <fwp_hof0.constprop.0+0x738>
    a348:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a34f:	ff ff 1f 
    a352:	4c 39 f0             	cmp    %r14,%rax
    a355:	0f 82 51 11 00 00    	jb     b4ac <fwp_hof0.constprop.0+0x18ec>
    a35b:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    a362:	00 
    a363:	be 02 00 00 00       	mov    $0x2,%esi
    a368:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
    a36d:	e8 9e bb ff ff       	call   5f10 <fwp_heap_alloc>
    a372:	4d 85 f6             	test   %r14,%r14
    a375:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    a37a:	4c 89 30             	mov    %r14,(%rax)
    a37d:	49 89 c7             	mov    %rax,%r15
    a380:	74 30                	je     a3b2 <fwp_hof0.constprop.0+0x7f2>
    a382:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a389:	00 
    a38a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a391:	00 00 00 00 
    a395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a39c:	00 00 00 00 
    a3a0:	4b 8b 04 ea          	mov    (%r10,%r13,8),%rax
    a3a4:	4b 89 44 ef 08       	mov    %rax,0x8(%r15,%r13,8)
    a3a9:	49 83 c5 01          	add    $0x1,%r13
    a3ad:	4d 39 ee             	cmp    %r13,%r14
    a3b0:	75 ee                	jne    a3a0 <fwp_hof0.constprop.0+0x7e0>
    a3b2:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
    a3b9:	00 
    a3ba:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a3bf:	4c 89 25 f2 30 06 00 	mov    %r12,0x630f2(%rip)        # 6d4b8 <fwp_cleanups>
    a3c6:	e8 95 ae ff ff       	call   5260 <fwp_tape_buffers_release>
    a3cb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a3d2:	4c 89 f8             	mov    %r15,%rax
    a3d5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a3dc:	48 c1 e2 10          	shl    $0x10,%rdx
    a3e0:	48 39 d0             	cmp    %rdx,%rax
    a3e3:	73 55                	jae    a43a <fwp_hof0.constprop.0+0x87a>
    a3e5:	48 89 c2             	mov    %rax,%rdx
    a3e8:	48 c1 ea 10          	shr    $0x10,%rdx
    a3ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3f0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a3f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3fb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a3ff:	48 85 db             	test   %rbx,%rbx
    a402:	74 36                	je     a43a <fwp_hof0.constprop.0+0x87a>
    a404:	0f b6 0a             	movzbl (%rdx),%ecx
    a407:	80 f9 02             	cmp    $0x2,%cl
    a40a:	0f 84 30 0c 00 00    	je     b040 <fwp_hof0.constprop.0+0x1480>
    a410:	80 f9 01             	cmp    $0x1,%cl
    a413:	75 25                	jne    a43a <fwp_hof0.constprop.0+0x87a>
    a415:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a418:	0f b7 c0             	movzwl %ax,%eax
    a41b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a41e:	48 0f af c1          	imul   %rcx,%rax
    a422:	48 c1 e8 20          	shr    $0x20,%rax
    a426:	48 39 d0             	cmp    %rdx,%rax
    a429:	73 0f                	jae    a43a <fwp_hof0.constprop.0+0x87a>
    a42b:	48 01 c3             	add    %rax,%rbx
    a42e:	80 3b ff             	cmpb   $0xff,(%rbx)
    a431:	0f 84 1b 0c 00 00    	je     b052 <fwp_hof0.constprop.0+0x1492>
    a437:	c6 03 01             	movb   $0x1,(%rbx)
    a43a:	4c 3b 64 24 38       	cmp    0x38(%rsp),%r12
    a43f:	0f 85 06 93 ff ff    	jne    374b <fwp_hof0.constprop.0.cold>
    a445:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    a44c:	00 
    a44d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    a452:	48 89 05 5f 30 06 00 	mov    %rax,0x6305f(%rip)        # 6d4b8 <fwp_cleanups>
    a459:	e8 62 d0 ff ff       	call   74c0 <fwp_tape_scope_release>
    a45e:	49 8b 07             	mov    (%r15),%rax
    a461:	49 89 c6             	mov    %rax,%r14
    a464:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a469:	48 85 c0             	test   %rax,%rax
    a46c:	0f 88 2e 08 00 00    	js     aca0 <fwp_hof0.constprop.0+0x10e0>
    a472:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a479:	4c 89 f8             	mov    %r15,%rax
    a47c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a483:	48 c1 e2 10          	shl    $0x10,%rdx
    a487:	48 39 d0             	cmp    %rdx,%rax
    a48a:	0f 83 10 08 00 00    	jae    aca0 <fwp_hof0.constprop.0+0x10e0>
    a490:	48 89 c2             	mov    %rax,%rdx
    a493:	48 c1 ea 10          	shr    $0x10,%rdx
    a497:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a49b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a4a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4a6:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a4aa:	48 85 c9             	test   %rcx,%rcx
    a4ad:	0f 84 ed 07 00 00    	je     aca0 <fwp_hof0.constprop.0+0x10e0>
    a4b3:	0f b6 32             	movzbl (%rdx),%esi
    a4b6:	40 80 fe 02          	cmp    $0x2,%sil
    a4ba:	0f 84 c8 07 00 00    	je     ac88 <fwp_hof0.constprop.0+0x10c8>
    a4c0:	40 80 fe 01          	cmp    $0x1,%sil
    a4c4:	0f 85 d6 07 00 00    	jne    aca0 <fwp_hof0.constprop.0+0x10e0>
    a4ca:	8b 72 18             	mov    0x18(%rdx),%esi
    a4cd:	0f b7 c0             	movzwl %ax,%eax
    a4d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4d3:	48 0f af c6          	imul   %rsi,%rax
    a4d7:	48 c1 e8 20          	shr    $0x20,%rax
    a4db:	48 39 d0             	cmp    %rdx,%rax
    a4de:	0f 83 bc 07 00 00    	jae    aca0 <fwp_hof0.constprop.0+0x10e0>
    a4e4:	48 01 c1             	add    %rax,%rcx
    a4e7:	80 39 01             	cmpb   $0x1,(%rcx)
    a4ea:	0f 85 b0 07 00 00    	jne    aca0 <fwp_hof0.constprop.0+0x10e0>
    a4f0:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    a4f5:	4d 89 fc             	mov    %r15,%r12
    a4f8:	31 ff                	xor    %edi,%edi
    a4fa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a4ff:	48 8d 50 08          	lea    0x8(%rax),%rdx
    a503:	31 c0                	xor    %eax,%eax
    a505:	4d 85 f6             	test   %r14,%r14
    a508:	75 30                	jne    a53a <fwp_hof0.constprop.0+0x97a>
    a50a:	eb 44                	jmp    a550 <fwp_hof0.constprop.0+0x990>
    a50c:	0f 1f 40 00          	nopl   0x0(%rax)
    a510:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a515:	0f 88 65 0f 00 00    	js     b480 <fwp_hof0.constprop.0+0x18c0>
    a51b:	f2 0f 10 05 65 58 00 	movsd  0x5865(%rip),%xmm0        # fd88 <msg.4+0x48>
    a522:	00 
    a523:	f2 0f 59 04 c1       	mulsd  (%rcx,%rax,8),%xmm0
    a528:	48 83 c0 01          	add    $0x1,%rax
    a52c:	48 83 c2 08          	add    $0x8,%rdx
    a530:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    a535:	49 39 c6             	cmp    %rax,%r14
    a538:	74 16                	je     a550 <fwp_hof0.constprop.0+0x990>
    a53a:	49 8d 4f 08          	lea    0x8(%r15),%rcx
    a53e:	49 83 3f 00          	cmpq   $0x0,(%r15)
    a542:	79 cc                	jns    a510 <fwp_hof0.constprop.0+0x950>
    a544:	49 8b 4f 10          	mov    0x10(%r15),%rcx
    a548:	eb c6                	jmp    a510 <fwp_hof0.constprop.0+0x950>
    a54a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a550:	e8 bb de ff ff       	call   8410 <fwp_drop10>
    a555:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a55a:	31 d2                	xor    %edx,%edx
    a55c:	48 89 f8             	mov    %rdi,%rax
    a55f:	48 85 ff             	test   %rdi,%rdi
    a562:	0f 84 2c 0d 00 00    	je     b294 <fwp_hof0.constprop.0+0x16d4>
    a568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a56f:	00 
    a570:	48 8b 40 10          	mov    0x10(%rax),%rax
    a574:	48 83 c2 01          	add    $0x1,%rdx
    a578:	48 85 c0             	test   %rax,%rax
    a57b:	75 f3                	jne    a570 <fwp_hof0.constprop.0+0x9b0>
    a57d:	49 8b 04 24          	mov    (%r12),%rax
    a581:	49 89 c7             	mov    %rax,%r15
    a584:	49 0f ba f7 3f       	btr    $0x3f,%r15
    a589:	48 85 c0             	test   %rax,%rax
    a58c:	0f 88 cb 05 00 00    	js     ab5d <fwp_hof0.constprop.0+0xf9d>
    a592:	48 8b 85 d8 13 00 00 	mov    0x13d8(%rbp),%rax
    a599:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a59e:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    a5a5:	48 c1 e0 10          	shl    $0x10,%rax
    a5a9:	48 39 c1             	cmp    %rax,%rcx
    a5ac:	0f 83 ab 05 00 00    	jae    ab5d <fwp_hof0.constprop.0+0xf9d>
    a5b2:	48 89 c8             	mov    %rcx,%rax
    a5b5:	48 c1 e8 10          	shr    $0x10,%rax
    a5b9:	48 8d 34 80          	lea    (%rax,%rax,4),%rsi
    a5bd:	48 8b 85 f8 13 00 00 	mov    0x13f8(%rbp),%rax
    a5c4:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
    a5c8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a5cc:	48 85 ff             	test   %rdi,%rdi
    a5cf:	0f 84 88 05 00 00    	je     ab5d <fwp_hof0.constprop.0+0xf9d>
    a5d5:	0f b6 06             	movzbl (%rsi),%eax
    a5d8:	3c 02                	cmp    $0x2,%al
    a5da:	0f 84 68 05 00 00    	je     ab48 <fwp_hof0.constprop.0+0xf88>
    a5e0:	3c 01                	cmp    $0x1,%al
    a5e2:	0f 85 69 05 00 00    	jne    ab51 <fwp_hof0.constprop.0+0xf91>
    a5e8:	8b 46 18             	mov    0x18(%rsi),%eax
    a5eb:	0f b7 c9             	movzwl %cx,%ecx
    a5ee:	48 0f af c8          	imul   %rax,%rcx
    a5f2:	8b 46 1c             	mov    0x1c(%rsi),%eax
    a5f5:	48 c1 e9 20          	shr    $0x20,%rcx
    a5f9:	48 39 c1             	cmp    %rax,%rcx
    a5fc:	0f 83 4f 05 00 00    	jae    ab51 <fwp_hof0.constprop.0+0xf91>
    a602:	48 01 cf             	add    %rcx,%rdi
    a605:	80 3f 01             	cmpb   $0x1,(%rdi)
    a608:	0f 85 43 05 00 00    	jne    ab51 <fwp_hof0.constprop.0+0xf91>
    a60e:	49 39 d7             	cmp    %rdx,%r15
    a611:	48 89 d0             	mov    %rdx,%rax
    a614:	49 0f 46 c7          	cmovbe %r15,%rax
    a618:	48 85 c0             	test   %rax,%rax
    a61b:	0f 84 6b 0e 00 00    	je     b48c <fwp_hof0.constprop.0+0x18cc>
    a621:	c7 44 24 30 01 00 00 	movl   $0x1,0x30(%rsp)
    a628:	00 
    a629:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
    a62e:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a633:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a638:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    a63f:	00 
    a640:	31 d2                	xor    %edx,%edx
    a642:	49 8d 78 08          	lea    0x8(%r8),%rdi
    a646:	eb 56                	jmp    a69e <fwp_hof0.constprop.0+0xade>
    a648:	90                   	nop
    a649:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a650:	00 00 00 00 
    a654:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a65b:	00 00 00 00 
    a65f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a666:	00 00 00 00 
    a66a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a671:	00 00 00 00 
    a675:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a67c:	00 00 00 00 
    a680:	f2 0f 10 41 08       	movsd  0x8(%rcx),%xmm0
    a685:	f2 0f 5c 04 16       	subsd  (%rsi,%rdx,1),%xmm0
    a68a:	f2 41 0f 11 44 15 00 	movsd  %xmm0,0x0(%r13,%rdx,1)
    a691:	48 83 c2 08          	add    $0x8,%rdx
    a695:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a699:	49 39 d1             	cmp    %rdx,%r9
    a69c:	74 12                	je     a6b0 <fwp_hof0.constprop.0+0xaf0>
    a69e:	48 89 fe             	mov    %rdi,%rsi
    a6a1:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    a6a6:	79 d8                	jns    a680 <fwp_hof0.constprop.0+0xac0>
    a6a8:	49 8b 70 10          	mov    0x10(%r8),%rsi
    a6ac:	eb d2                	jmp    a680 <fwp_hof0.constprop.0+0xac0>
    a6ae:	66 90                	xchg   %ax,%ax
    a6b0:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a6b5:	48 85 c9             	test   %rcx,%rcx
    a6b8:	0f 84 a2 0d 00 00    	je     b460 <fwp_hof0.constprop.0+0x18a0>
    a6be:	4c 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%r9
    a6c5:	4c 8b 95 b0 13 00 00 	mov    0x13b0(%rbp),%r10
    a6cc:	45 31 ff             	xor    %r15d,%r15d
    a6cf:	4c 8b 9d f8 13 00 00 	mov    0x13f8(%rbp),%r11
    a6d6:	49 c1 e1 10          	shl    $0x10,%r9
    a6da:	eb 1a                	jmp    a6f6 <fwp_hof0.constprop.0+0xb36>
    a6dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a6e0:	49 83 c7 01          	add    $0x1,%r15
    a6e4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    a6e8:	49 39 c7             	cmp    %rax,%r15
    a6eb:	0f 83 5f 01 00 00    	jae    a850 <fwp_hof0.constprop.0+0xc90>
    a6f1:	48 85 c9             	test   %rcx,%rcx
    a6f4:	74 56                	je     a74c <fwp_hof0.constprop.0+0xb8c>
    a6f6:	48 89 ca             	mov    %rcx,%rdx
    a6f9:	4c 29 d2             	sub    %r10,%rdx
    a6fc:	4c 39 ca             	cmp    %r9,%rdx
    a6ff:	73 4b                	jae    a74c <fwp_hof0.constprop.0+0xb8c>
    a701:	48 89 d6             	mov    %rdx,%rsi
    a704:	48 c1 ee 10          	shr    $0x10,%rsi
    a708:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    a70c:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    a710:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a714:	48 85 ff             	test   %rdi,%rdi
    a717:	74 33                	je     a74c <fwp_hof0.constprop.0+0xb8c>
    a719:	44 0f b6 06          	movzbl (%rsi),%r8d
    a71d:	41 80 f8 02          	cmp    $0x2,%r8b
    a721:	0f 84 11 01 00 00    	je     a838 <fwp_hof0.constprop.0+0xc78>
    a727:	41 80 f8 01          	cmp    $0x1,%r8b
    a72b:	75 1f                	jne    a74c <fwp_hof0.constprop.0+0xb8c>
    a72d:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a731:	0f b7 d2             	movzwl %dx,%edx
    a734:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a737:	49 0f af d0          	imul   %r8,%rdx
    a73b:	48 c1 ea 20          	shr    $0x20,%rdx
    a73f:	48 39 f2             	cmp    %rsi,%rdx
    a742:	73 08                	jae    a74c <fwp_hof0.constprop.0+0xb8c>
    a744:	48 01 d7             	add    %rdx,%rdi
    a747:	80 3f 01             	cmpb   $0x1,(%rdi)
    a74a:	74 94                	je     a6e0 <fwp_hof0.constprop.0+0xb20>
    a74c:	49 39 c7             	cmp    %rax,%r15
    a74f:	0f 83 fb 00 00 00    	jae    a850 <fwp_hof0.constprop.0+0xc90>
    a755:	48 89 c3             	mov    %rax,%rbx
    a758:	45 31 f6             	xor    %r14d,%r14d
    a75b:	eb 37                	jmp    a794 <fwp_hof0.constprop.0+0xbd4>
    a75d:	0f 1f 00             	nopl   (%rax)
    a760:	40 80 fe 01          	cmp    $0x1,%sil
    a764:	75 25                	jne    a78b <fwp_hof0.constprop.0+0xbcb>
    a766:	8b 71 18             	mov    0x18(%rcx),%esi
    a769:	0f b7 c0             	movzwl %ax,%eax
    a76c:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a76f:	48 0f af c6          	imul   %rsi,%rax
    a773:	48 c1 e8 20          	shr    $0x20,%rax
    a777:	48 39 c8             	cmp    %rcx,%rax
    a77a:	73 0f                	jae    a78b <fwp_hof0.constprop.0+0xbcb>
    a77c:	48 01 c2             	add    %rax,%rdx
    a77f:	80 3a ff             	cmpb   $0xff,(%rdx)
    a782:	0f 84 60 06 00 00    	je     ade8 <fwp_hof0.constprop.0+0x1228>
    a788:	c6 02 01             	movb   $0x1,(%rdx)
    a78b:	49 39 df             	cmp    %rbx,%r15
    a78e:	0f 83 8c 00 00 00    	jae    a820 <fwp_hof0.constprop.0+0xc60>
    a794:	48 83 eb 01          	sub    $0x1,%rbx
    a798:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a79d:	bf 01 00 00 00       	mov    $0x1,%edi
    a7a2:	f3 41 0f 7e 44 dd 00 	movq   0x0(%r13,%rbx,8),%xmm0
    a7a9:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    a7b0:	00 
    a7b1:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a7b5:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
    a7bc:	00 
    a7bd:	e8 3e b9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a7c2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a7c9:	49 89 c6             	mov    %rax,%r14
    a7cc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a7d3:	48 c1 e2 10          	shl    $0x10,%rdx
    a7d7:	48 39 d0             	cmp    %rdx,%rax
    a7da:	73 af                	jae    a78b <fwp_hof0.constprop.0+0xbcb>
    a7dc:	48 89 c2             	mov    %rax,%rdx
    a7df:	48 c1 ea 10          	shr    $0x10,%rdx
    a7e3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7e7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a7ee:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a7f2:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a7f6:	48 85 d2             	test   %rdx,%rdx
    a7f9:	74 90                	je     a78b <fwp_hof0.constprop.0+0xbcb>
    a7fb:	0f b6 31             	movzbl (%rcx),%esi
    a7fe:	40 80 fe 02          	cmp    $0x2,%sil
    a802:	0f 85 58 ff ff ff    	jne    a760 <fwp_hof0.constprop.0+0xba0>
    a808:	66 85 c0             	test   %ax,%ax
    a80b:	0f 84 6e ff ff ff    	je     a77f <fwp_hof0.constprop.0+0xbbf>
    a811:	49 39 df             	cmp    %rbx,%r15
    a814:	0f 82 7a ff ff ff    	jb     a794 <fwp_hof0.constprop.0+0xbd4>
    a81a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a820:	4d 85 ff             	test   %r15,%r15
    a823:	75 2e                	jne    a853 <fwp_hof0.constprop.0+0xc93>
    a825:	8b 44 24 30          	mov    0x30(%rsp),%eax
    a829:	85 c0                	test   %eax,%eax
    a82b:	4d 0f 45 ef          	cmovne %r15,%r13
    a82f:	eb 63                	jmp    a894 <fwp_hof0.constprop.0+0xcd4>
    a831:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a838:	66 85 d2             	test   %dx,%dx
    a83b:	0f 84 06 ff ff ff    	je     a747 <fwp_hof0.constprop.0+0xb87>
    a841:	49 39 c7             	cmp    %rax,%r15
    a844:	0f 82 0b ff ff ff    	jb     a755 <fwp_hof0.constprop.0+0xb95>
    a84a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a850:	45 31 f6             	xor    %r14d,%r14d
    a853:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a858:	4c 89 ea             	mov    %r13,%rdx
    a85b:	4f 8d 4c fd 00       	lea    0x0(%r13,%r15,8),%r9
    a860:	48 8b 0a             	mov    (%rdx),%rcx
    a863:	48 83 c2 08          	add    $0x8,%rdx
    a867:	48 89 c7             	mov    %rax,%rdi
    a86a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    a86e:	48 8b 40 10          	mov    0x10(%rax),%rax
    a872:	49 39 d1             	cmp    %rdx,%r9
    a875:	75 e9                	jne    a860 <fwp_hof0.constprop.0+0xca0>
    a877:	8b 54 24 30          	mov    0x30(%rsp),%edx
    a87b:	4c 89 77 10          	mov    %r14,0x10(%rdi)
    a87f:	85 d2                	test   %edx,%edx
    a881:	0f 84 d9 07 00 00    	je     b060 <fwp_hof0.constprop.0+0x14a0>
    a887:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a88c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    a891:	45 31 ed             	xor    %r13d,%r13d
    a894:	4c 89 ef             	mov    %r13,%rdi
    a897:	e8 74 b1 ff ff       	call   5a10 <fwp_mem_free>
    a89c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a8a1:	e8 6a db ff ff       	call   8410 <fwp_drop10>
    a8a6:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a8b2:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a8b9:	48 c1 e2 10          	shl    $0x10,%rdx
    a8bd:	48 39 d0             	cmp    %rdx,%rax
    a8c0:	73 6e                	jae    a930 <fwp_hof0.constprop.0+0xd70>
    a8c2:	48 89 c2             	mov    %rax,%rdx
    a8c5:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a8cc:	48 c1 ea 10          	shr    $0x10,%rdx
    a8d0:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a8d4:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a8d8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a8dc:	48 85 db             	test   %rbx,%rbx
    a8df:	74 4f                	je     a930 <fwp_hof0.constprop.0+0xd70>
    a8e1:	0f b6 0a             	movzbl (%rdx),%ecx
    a8e4:	80 f9 02             	cmp    $0x2,%cl
    a8e7:	0f 84 03 07 00 00    	je     aff0 <fwp_hof0.constprop.0+0x1430>
    a8ed:	80 f9 01             	cmp    $0x1,%cl
    a8f0:	75 3e                	jne    a930 <fwp_hof0.constprop.0+0xd70>
    a8f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a8f5:	0f b7 c0             	movzwl %ax,%eax
    a8f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a8fb:	48 0f af c1          	imul   %rcx,%rax
    a8ff:	48 c1 e8 20          	shr    $0x20,%rax
    a903:	48 39 d0             	cmp    %rdx,%rax
    a906:	73 28                	jae    a930 <fwp_hof0.constprop.0+0xd70>
    a908:	48 01 c3             	add    %rax,%rbx
    a90b:	0f b6 03             	movzbl (%rbx),%eax
    a90e:	84 c0                	test   %al,%al
    a910:	74 1e                	je     a930 <fwp_hof0.constprop.0+0xd70>
    a912:	3c 01                	cmp    $0x1,%al
    a914:	0f 84 56 07 00 00    	je     b070 <fwp_hof0.constprop.0+0x14b0>
    a91a:	3c ff                	cmp    $0xff,%al
    a91c:	0f 84 ed 09 00 00    	je     b30f <fwp_hof0.constprop.0+0x174f>
    a922:	83 e8 01             	sub    $0x1,%eax
    a925:	88 03                	mov    %al,(%rbx)
    a927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a92e:	00 00 
    a930:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
    a936:	0f 85 5c 06 00 00    	jne    af98 <fwp_hof0.constprop.0+0x13d8>
    a93c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    a941:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a945:	4c 89 f6             	mov    %r14,%rsi
    a948:	4d 89 f4             	mov    %r14,%r12
    a94b:	b9 01 00 00 00       	mov    $0x1,%ecx
    a950:	48 8d 15 49 82 00 00 	lea    0x8249(%rip),%rdx        # 12ba0 <d0>
    a957:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a95e:	00 00 00 00 00 
    a963:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
    a96a:	00 
    a96b:	e8 10 e2 ff ff       	call   8b80 <fwp_write>
    a970:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
    a977:	00 
    a978:	4c 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%r15
    a97f:	00 
    a980:	48 8d 05 e5 46 00 00 	lea    0x46e5(%rip),%rax        # f06c <_IO_stdin_used+0x6c>
    a987:	48 85 c9             	test   %rcx,%rcx
    a98a:	48 0f 44 c8          	cmove  %rax,%rcx
    a98e:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a992:	0f 87 5a 0b 00 00    	ja     b4f2 <fwp_hof0.constprop.0+0x1932>
    a998:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a99c:	be 01 00 00 00       	mov    $0x1,%esi
    a9a1:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a9a6:	e8 65 b5 ff ff       	call   5f10 <fwp_heap_alloc>
    a9ab:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a9b0:	4c 89 fa             	mov    %r15,%rdx
    a9b3:	4c 89 38             	mov    %r15,(%rax)
    a9b6:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a9ba:	48 89 c3             	mov    %rax,%rbx
    a9bd:	4c 89 ef             	mov    %r13,%rdi
    a9c0:	e8 bb 8b ff ff       	call   3580 <memcpy@plt>
    a9c5:	42 c6 44 3b 08 00    	movb   $0x0,0x8(%rbx,%r15,1)
    a9cb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
    a9d2:	00 
    a9d3:	e8 d8 89 ff ff       	call   33b0 <free@plt>
    a9d8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a9df:	48 89 d8             	mov    %rbx,%rax
    a9e2:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a9e9:	48 c1 e2 10          	shl    $0x10,%rdx
    a9ed:	48 39 d0             	cmp    %rdx,%rax
    a9f0:	73 57                	jae    aa49 <fwp_hof0.constprop.0+0xe89>
    a9f2:	48 89 c2             	mov    %rax,%rdx
    a9f5:	48 c1 ea 10          	shr    $0x10,%rdx
    a9f9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a9fd:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa04:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aa08:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    aa0c:	4d 85 ff             	test   %r15,%r15
    aa0f:	74 38                	je     aa49 <fwp_hof0.constprop.0+0xe89>
    aa11:	0f b6 0a             	movzbl (%rdx),%ecx
    aa14:	80 f9 02             	cmp    $0x2,%cl
    aa17:	0f 84 1b 08 00 00    	je     b238 <fwp_hof0.constprop.0+0x1678>
    aa1d:	80 f9 01             	cmp    $0x1,%cl
    aa20:	75 27                	jne    aa49 <fwp_hof0.constprop.0+0xe89>
    aa22:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aa25:	0f b7 c0             	movzwl %ax,%eax
    aa28:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aa2b:	48 0f af c1          	imul   %rcx,%rax
    aa2f:	48 c1 e8 20          	shr    $0x20,%rax
    aa33:	48 39 d0             	cmp    %rdx,%rax
    aa36:	73 11                	jae    aa49 <fwp_hof0.constprop.0+0xe89>
    aa38:	49 01 c7             	add    %rax,%r15
    aa3b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    aa3f:	0f 84 06 08 00 00    	je     b24b <fwp_hof0.constprop.0+0x168b>
    aa45:	41 c6 07 01          	movb   $0x1,(%r15)
    aa49:	4c 89 e7             	mov    %r12,%rdi
    aa4c:	e8 cf d5 ff ff       	call   8020 <fwp_drop0>
    aa51:	48 8b 13             	mov    (%rbx),%rdx
    aa54:	be 01 00 00 00       	mov    $0x1,%esi
    aa59:	4c 89 ef             	mov    %r13,%rdi
    aa5c:	48 8b 0d 1d 2a 06 00 	mov    0x62a1d(%rip),%rcx        # 6d480 <fwp_prog_out>
    aa63:	e8 f8 8b ff ff       	call   3660 <fwrite@plt>
    aa68:	48 8b 35 11 2a 06 00 	mov    0x62a11(%rip),%rsi        # 6d480 <fwp_prog_out>
    aa6f:	bf 0a 00 00 00       	mov    $0xa,%edi
    aa74:	e8 57 8a ff ff       	call   34d0 <fputc@plt>
    aa79:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa80:	48 89 d8             	mov    %rbx,%rax
    aa83:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa8a:	48 c1 e2 10          	shl    $0x10,%rdx
    aa8e:	48 39 d0             	cmp    %rdx,%rax
    aa91:	73 6d                	jae    ab00 <fwp_hof0.constprop.0+0xf40>
    aa93:	48 89 c2             	mov    %rax,%rdx
    aa96:	48 c1 ea 10          	shr    $0x10,%rdx
    aa9a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa9e:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aaa5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aaa9:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aaad:	4d 85 e4             	test   %r12,%r12
    aab0:	74 4e                	je     ab00 <fwp_hof0.constprop.0+0xf40>
    aab2:	0f b6 0a             	movzbl (%rdx),%ecx
    aab5:	80 f9 02             	cmp    $0x2,%cl
    aab8:	0f 84 a2 07 00 00    	je     b260 <fwp_hof0.constprop.0+0x16a0>
    aabe:	80 f9 01             	cmp    $0x1,%cl
    aac1:	75 3d                	jne    ab00 <fwp_hof0.constprop.0+0xf40>
    aac3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aac6:	0f b7 c0             	movzwl %ax,%eax
    aac9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    aacc:	48 0f af c1          	imul   %rcx,%rax
    aad0:	48 c1 e8 20          	shr    $0x20,%rax
    aad4:	48 39 d0             	cmp    %rdx,%rax
    aad7:	73 27                	jae    ab00 <fwp_hof0.constprop.0+0xf40>
    aad9:	49 01 c4             	add    %rax,%r12
    aadc:	41 0f b6 04 24       	movzbl (%r12),%eax
    aae1:	84 c0                	test   %al,%al
    aae3:	74 1b                	je     ab00 <fwp_hof0.constprop.0+0xf40>
    aae5:	3c 01                	cmp    $0x1,%al
    aae7:	0f 84 91 07 00 00    	je     b27e <fwp_hof0.constprop.0+0x16be>
    aaed:	3c ff                	cmp    $0xff,%al
    aaef:	0f 84 f3 08 00 00    	je     b3e8 <fwp_hof0.constprop.0+0x1828>
    aaf5:	83 e8 01             	sub    $0x1,%eax
    aaf8:	41 88 04 24          	mov    %al,(%r12)
    aafc:	0f 1f 40 00          	nopl   0x0(%rax)
    ab00:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    ab05:	48 8b 40 10          	mov    0x10(%rax),%rax
    ab09:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    ab0e:	48 85 c0             	test   %rax,%rax
    ab11:	0f 85 e9 f0 ff ff    	jne    9c00 <fwp_hof0.constprop.0+0x40>
    ab17:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    ab1e:	00 
    ab1f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ab26:	00 00 
    ab28:	0f 85 6b 0a 00 00    	jne    b599 <fwp_hof0.constprop.0+0x19d9>
    ab2e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    ab35:	31 c0                	xor    %eax,%eax
    ab37:	5b                   	pop    %rbx
    ab38:	5d                   	pop    %rbp
    ab39:	41 5c                	pop    %r12
    ab3b:	41 5d                	pop    %r13
    ab3d:	41 5e                	pop    %r14
    ab3f:	41 5f                	pop    %r15
    ab41:	c3                   	ret
    ab42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab48:	66 85 c9             	test   %cx,%cx
    ab4b:	0f 84 b4 fa ff ff    	je     a605 <fwp_hof0.constprop.0+0xa45>
    ab51:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    ab57:	0f 84 31 03 00 00    	je     ae8e <fwp_hof0.constprop.0+0x12ce>
    ab5d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ab62:	45 31 f6             	xor    %r14d,%r14d
    ab65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab6c:	00 00 00 00 
    ab70:	48 8b 40 10          	mov    0x10(%rax),%rax
    ab74:	4c 89 f2             	mov    %r14,%rdx
    ab77:	49 83 c6 01          	add    $0x1,%r14
    ab7b:	48 85 c0             	test   %rax,%rax
    ab7e:	75 f0                	jne    ab70 <fwp_hof0.constprop.0+0xfb0>
    ab80:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ab87:	ff ff 1f 
    ab8a:	4c 39 f0             	cmp    %r14,%rax
    ab8d:	0f 82 01 09 00 00    	jb     b494 <fwp_hof0.constprop.0+0x18d4>
    ab93:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    ab9a:	00 
    ab9b:	be 02 00 00 00       	mov    $0x2,%esi
    aba0:	e8 6b b3 ff ff       	call   5f10 <fwp_heap_alloc>
    aba5:	4d 39 fe             	cmp    %r15,%r14
    aba8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    abad:	49 89 c5             	mov    %rax,%r13
    abb0:	4c 89 f8             	mov    %r15,%rax
    abb3:	49 0f 46 c6          	cmovbe %r14,%rax
    abb7:	4c 89 e9             	mov    %r13,%rcx
    abba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abc0:	48 8b 72 08          	mov    0x8(%rdx),%rsi
    abc4:	48 83 c1 08          	add    $0x8,%rcx
    abc8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    abcc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    abd0:	48 85 d2             	test   %rdx,%rdx
    abd3:	75 eb                	jne    abc0 <fwp_hof0.constprop.0+0x1000>
    abd5:	48 85 c0             	test   %rax,%rax
    abd8:	0f 84 c2 02 00 00    	je     aea0 <fwp_hof0.constprop.0+0x12e0>
    abde:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
    abe5:	00 
    abe6:	e9 43 fa ff ff       	jmp    a62e <fwp_hof0.constprop.0+0xa6e>
    abeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    abf0:	4c 39 f3             	cmp    %r14,%rbx
    abf3:	0f 84 27 f2 ff ff    	je     9e20 <fwp_hof0.constprop.0+0x260>
    abf9:	4c 8b 25 f0 84 01 00 	mov    0x184f0(%rip),%r12        # 230f0 <fwp_tapes>
    ac00:	e9 bf f2 ff ff       	jmp    9ec4 <fwp_hof0.constprop.0+0x304>
    ac05:	0f 1f 00             	nopl   (%rax)
    ac08:	48 83 3d 78 84 01 00 	cmpq   $0x0,0x18478(%rip)        # 23088 <fwp_tape_cached_bytes>
    ac0f:	00 
    ac10:	0f 84 f4 f2 ff ff    	je     9f0a <fwp_hof0.constprop.0+0x34a>
    ac16:	66 0f 6f 0d 82 84 01 	movdqa 0x18482(%rip),%xmm1        # 230a0 <fwp_tape_workspace>
    ac1d:	00 
    ac1e:	48 c7 05 5f 84 01 00 	movq   $0x0,0x1845f(%rip)        # 23088 <fwp_tape_cached_bytes>
    ac25:	00 00 00 00 
    ac29:	0f 11 4b 20          	movups %xmm1,0x20(%rbx)
    ac2d:	48 8b 05 8c 84 01 00 	mov    0x1848c(%rip),%rax        # 230c0 <fwp_tape_workspace+0x20>
    ac34:	66 0f 6f 0d 74 84 01 	movdqa 0x18474(%rip),%xmm1        # 230b0 <fwp_tape_workspace+0x10>
    ac3b:	00 
    ac3c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    ac40:	48 8b 05 81 84 01 00 	mov    0x18481(%rip),%rax        # 230c8 <fwp_tape_workspace+0x28>
    ac47:	0f 11 4b 30          	movups %xmm1,0x30(%rbx)
    ac4b:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ac4f:	48 89 43 18          	mov    %rax,0x18(%rbx)
    ac53:	48 8b 05 76 84 01 00 	mov    0x18476(%rip),%rax        # 230d0 <fwp_tape_workspace+0x30>
    ac5a:	0f 29 0d 3f 84 01 00 	movaps %xmm1,0x1843f(%rip)        # 230a0 <fwp_tape_workspace>
    ac61:	48 89 43 48          	mov    %rax,0x48(%rbx)
    ac65:	0f 29 0d 44 84 01 00 	movaps %xmm1,0x18444(%rip)        # 230b0 <fwp_tape_workspace+0x10>
    ac6c:	48 c7 05 59 84 01 00 	movq   $0x0,0x18459(%rip)        # 230d0 <fwp_tape_workspace+0x30>
    ac73:	00 00 00 00 
    ac77:	0f 29 0d 42 84 01 00 	movaps %xmm1,0x18442(%rip)        # 230c0 <fwp_tape_workspace+0x20>
    ac7e:	e9 87 f2 ff ff       	jmp    9f0a <fwp_hof0.constprop.0+0x34a>
    ac83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac88:	66 85 c0             	test   %ax,%ax
    ac8b:	0f 84 56 f8 ff ff    	je     a4e7 <fwp_hof0.constprop.0+0x927>
    ac91:	0f 1f 40 00          	nopl   0x0(%rax)
    ac95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ac9c:	00 00 00 00 
    aca0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    aca7:	ff ff 1f 
    acaa:	4c 39 f0             	cmp    %r14,%rax
    acad:	0f 82 f9 07 00 00    	jb     b4ac <fwp_hof0.constprop.0+0x18ec>
    acb3:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    acba:	00 
    acbb:	be 01 00 00 00       	mov    $0x1,%esi
    acc0:	e8 4b b2 ff ff       	call   5f10 <fwp_heap_alloc>
    acc5:	4c 89 30             	mov    %r14,(%rax)
    acc8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    accf:	49 89 c4             	mov    %rax,%r12
    acd2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    acd7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    acde:	48 c1 e2 10          	shl    $0x10,%rdx
    ace2:	48 39 d0             	cmp    %rdx,%rax
    ace5:	73 57                	jae    ad3e <fwp_hof0.constprop.0+0x117e>
    ace7:	48 89 c2             	mov    %rax,%rdx
    acea:	48 c1 ea 10          	shr    $0x10,%rdx
    acee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    acf2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    acf9:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    acfd:	48 8b 59 20          	mov    0x20(%rcx),%rbx
    ad01:	48 85 db             	test   %rbx,%rbx
    ad04:	74 38                	je     ad3e <fwp_hof0.constprop.0+0x117e>
    ad06:	0f b6 31             	movzbl (%rcx),%esi
    ad09:	40 80 fe 02          	cmp    $0x2,%sil
    ad0d:	0f 84 05 04 00 00    	je     b118 <fwp_hof0.constprop.0+0x1558>
    ad13:	40 80 fe 01          	cmp    $0x1,%sil
    ad17:	75 25                	jne    ad3e <fwp_hof0.constprop.0+0x117e>
    ad19:	8b 71 18             	mov    0x18(%rcx),%esi
    ad1c:	0f b7 c0             	movzwl %ax,%eax
    ad1f:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ad22:	48 0f af c6          	imul   %rsi,%rax
    ad26:	48 c1 e8 20          	shr    $0x20,%rax
    ad2a:	48 39 c8             	cmp    %rcx,%rax
    ad2d:	73 0f                	jae    ad3e <fwp_hof0.constprop.0+0x117e>
    ad2f:	48 01 c3             	add    %rax,%rbx
    ad32:	80 3b ff             	cmpb   $0xff,(%rbx)
    ad35:	0f 84 ef 03 00 00    	je     b12a <fwp_hof0.constprop.0+0x156a>
    ad3b:	c6 03 01             	movb   $0x1,(%rbx)
    ad3e:	4c 89 ff             	mov    %r15,%rdi
    ad41:	e9 b4 f7 ff ff       	jmp    a4fa <fwp_hof0.constprop.0+0x93a>
    ad46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ad4d:	00 00 00 
    ad50:	48 c1 e1 10          	shl    $0x10,%rcx
    ad54:	bf 08 00 00 00       	mov    $0x8,%edi
    ad59:	48 09 f1             	or     %rsi,%rcx
    ad5c:	be 02 00 00 00       	mov    $0x2,%esi
    ad61:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    ad66:	e8 a5 b1 ff ff       	call   5f10 <fwp_heap_alloc>
    ad6b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    ad72:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ad79:	49 89 c6             	mov    %rax,%r14
    ad7c:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ad83:	48 c1 e2 10          	shl    $0x10,%rdx
    ad87:	48 39 d0             	cmp    %rdx,%rax
    ad8a:	0f 83 70 f3 ff ff    	jae    a100 <fwp_hof0.constprop.0+0x540>
    ad90:	48 89 c2             	mov    %rax,%rdx
    ad93:	48 c1 ea 10          	shr    $0x10,%rdx
    ad97:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    ad9b:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ada2:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    ada6:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    adaa:	4d 85 ff             	test   %r15,%r15
    adad:	0f 84 41 f3 ff ff    	je     a0f4 <fwp_hof0.constprop.0+0x534>
    adb3:	0f b6 32             	movzbl (%rdx),%esi
    adb6:	31 db                	xor    %ebx,%ebx
    adb8:	40 80 fe 02          	cmp    $0x2,%sil
    adbc:	0f 85 aa f2 ff ff    	jne    a06c <fwp_hof0.constprop.0+0x4ac>
    adc2:	66 85 c0             	test   %ax,%ax
    adc5:	0f 85 ce f2 ff ff    	jne    a099 <fwp_hof0.constprop.0+0x4d9>
    adcb:	41 80 3f ff          	cmpb   $0xff,(%r15)
    adcf:	0f 85 c0 f2 ff ff    	jne    a095 <fwp_hof0.constprop.0+0x4d5>
    add5:	4c 89 ff             	mov    %r15,%rdi
    add8:	e8 f3 a9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    addd:	e9 b3 f2 ff ff       	jmp    a095 <fwp_hof0.constprop.0+0x4d5>
    ade2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ade8:	48 89 d7             	mov    %rdx,%rdi
    adeb:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    adf0:	e8 db a9 ff ff       	call   57d0 <fwp_rc_forget_slot>
    adf5:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    adfa:	e9 89 f9 ff ff       	jmp    a788 <fwp_hof0.constprop.0+0xbc8>
    adff:	90                   	nop
    ae00:	48 8d 58 ff          	lea    -0x1(%rax),%rbx
    ae04:	48 89 df             	mov    %rbx,%rdi
    ae07:	48 c1 ef 3c          	shr    $0x3c,%rdi
    ae0b:	0f 85 83 06 00 00    	jne    b494 <fwp_hof0.constprop.0+0x18d4>
    ae11:	48 85 db             	test   %rbx,%rbx
    ae14:	0f 84 e6 f2 ff ff    	je     a100 <fwp_hof0.constprop.0+0x540>
    ae1a:	48 c1 e0 04          	shl    $0x4,%rax
    ae1e:	48 01 db             	add    %rbx,%rbx
    ae21:	4d 8d 66 08          	lea    0x8(%r14),%r12
    ae25:	4d 8d 7c 06 f8       	lea    -0x8(%r14,%rax,1),%r15
    ae2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae30:	f2 41 0f 10 04 24    	movsd  (%r12),%xmm0
    ae36:	49 8b 74 24 18       	mov    0x18(%r12),%rsi
    ae3b:	49 83 c4 10          	add    $0x10,%r12
    ae3f:	49 8b 7c 24 f8       	mov    -0x8(%r12),%rdi
    ae44:	f2 41 0f 10 0c 24    	movsd  (%r12),%xmm1
    ae4a:	e8 a1 b8 ff ff       	call   66f0 <w120>
    ae4f:	66 48 0f 6e e8       	movq   %rax,%xmm5
    ae54:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    ae58:	41 0f 11 44 24 f0    	movups %xmm0,-0x10(%r12)
    ae5e:	4d 39 e7             	cmp    %r12,%r15
    ae61:	75 cd                	jne    ae30 <fwp_hof0.constprop.0+0x1270>
    ae63:	49 89 1e             	mov    %rbx,(%r14)
    ae66:	45 31 ff             	xor    %r15d,%r15d
    ae69:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    ae70:	4b 8b 74 fe 10       	mov    0x10(%r14,%r15,8),%rsi
    ae75:	49 83 c7 02          	add    $0x2,%r15
    ae79:	e8 f2 b6 ff ff       	call   6570 <f141.constprop.0>
    ae7e:	48 89 c7             	mov    %rax,%rdi
    ae81:	49 39 df             	cmp    %rbx,%r15
    ae84:	72 ea                	jb     ae70 <fwp_hof0.constprop.0+0x12b0>
    ae86:	49 89 c1             	mov    %rax,%r9
    ae89:	e9 82 f2 ff ff       	jmp    a110 <fwp_hof0.constprop.0+0x550>
    ae8e:	be 02 00 00 00       	mov    $0x2,%esi
    ae93:	bf 08 00 00 00       	mov    $0x8,%edi
    ae98:	e8 73 b0 ff ff       	call   5f10 <fwp_heap_alloc>
    ae9d:	49 89 c5             	mov    %rax,%r13
    aea0:	45 31 f6             	xor    %r14d,%r14d
    aea3:	e9 ec f9 ff ff       	jmp    a894 <fwp_hof0.constprop.0+0xcd4>
    aea8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aeaf:	00 
    aeb0:	4c 8d 61 01          	lea    0x1(%rcx),%r12
    aeb4:	4c 39 e3             	cmp    %r12,%rbx
    aeb7:	7c 32                	jl     aeeb <fwp_hof0.constprop.0+0x132b>
    aeb9:	4d 85 d2             	test   %r10,%r10
    aebc:	0f 84 78 06 00 00    	je     b53a <fwp_hof0.constprop.0+0x197a>
    aec2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
    aec7:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    aece:	00 
    aecf:	31 f6                	xor    %esi,%esi
    aed1:	4c 89 d7             	mov    %r10,%rdi
    aed4:	0f 29 54 24 10       	movaps %xmm2,0x10(%rsp)
    aed9:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
    aede:	e9 a0 f3 ff ff       	jmp    a283 <fwp_hof0.constprop.0+0x6c3>
    aee3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aee8:	4d 89 f4             	mov    %r14,%r12
    aeeb:	48 85 db             	test   %rbx,%rbx
    aeee:	49 0f 44 dc          	cmove  %r12,%rbx
    aef2:	eb 21                	jmp    af15 <fwp_hof0.constprop.0+0x1355>
    aef4:	90                   	nop
    aef5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aefc:	00 00 00 00 
    af00:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
    af04:	48 81 fb 00 00 00 40 	cmp    $0x40000000,%rbx
    af0b:	4c 89 e0             	mov    %r12,%rax
    af0e:	48 0f 4c c2          	cmovl  %rdx,%rax
    af12:	48 89 c3             	mov    %rax,%rbx
    af15:	4c 39 e3             	cmp    %r12,%rbx
    af18:	7c e6                	jl     af00 <fwp_hof0.constprop.0+0x1340>
    af1a:	4d 85 d2             	test   %r10,%r10
    af1d:	0f 84 2d 02 00 00    	je     b150 <fwp_hof0.constprop.0+0x1590>
    af23:	4c 89 d7             	mov    %r10,%rdi
    af26:	ba 03 00 00 00       	mov    $0x3,%edx
    af2b:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    af30:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    af37:	00 
    af38:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    af3d:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    af42:	e8 49 a2 ff ff       	call   5190 <ad_raw_realloc>
    af47:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    af4c:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    af52:	48 85 c0             	test   %rax,%rax
    af55:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    af5b:	49 89 c2             	mov    %rax,%r10
    af5e:	0f 84 bc 02 00 00    	je     b220 <fwp_hof0.constprop.0+0x1660>
    af64:	4c 89 94 24 e0 00 00 	mov    %r10,0xe0(%rsp)
    af6b:	00 
    af6c:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
    af73:	00 
    af74:	4d 85 e4             	test   %r12,%r12
    af77:	0f 85 16 04 00 00    	jne    b393 <fwp_hof0.constprop.0+0x17d3>
    af7d:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    af84:	4d 85 c9             	test   %r9,%r9
    af87:	0f 88 23 f3 ff ff    	js     a2b0 <fwp_hof0.constprop.0+0x6f0>
    af8d:	44 89 c9             	mov    %r9d,%ecx
    af90:	e9 07 f3 ff ff       	jmp    a29c <fwp_hof0.constprop.0+0x6dc>
    af95:	0f 1f 00             	nopl   (%rax)
    af98:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    af9d:	45 31 c0             	xor    %r8d,%r8d
    afa0:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    afa5:	48 83 e8 01          	sub    $0x1,%rax
    afa9:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    afae:	41 0f 90 c0          	seto   %r8b
    afb2:	e9 ec ec ff ff       	jmp    9ca3 <fwp_hof0.constprop.0+0xe3>
    afb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    afbe:	00 00 
    afc0:	48 8d 3d d9 c3 ff ff 	lea    -0x3c27(%rip),%rdi        # 73a0 <fwp_tape_finish>
    afc7:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    afcd:	e8 fe 3c 00 00       	call   ecd0 <atexit>
    afd2:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    afd8:	85 c0                	test   %eax,%eax
    afda:	0f 85 e4 04 00 00    	jne    b4c4 <fwp_hof0.constprop.0+0x1904>
    afe0:	c7 05 76 80 00 00 01 	movl   $0x1,0x8076(%rip)        # 13060 <registered_finish.1>
    afe7:	00 00 00 
    afea:	e9 ee ed ff ff       	jmp    9ddd <fwp_hof0.constprop.0+0x21d>
    afef:	90                   	nop
    aff0:	66 85 c0             	test   %ax,%ax
    aff3:	0f 85 37 f9 ff ff    	jne    a930 <fwp_hof0.constprop.0+0xd70>
    aff9:	e9 0d f9 ff ff       	jmp    a90b <fwp_hof0.constprop.0+0xd4b>
    affe:	66 90                	xchg   %ax,%ax
    b000:	66 85 c0             	test   %ax,%ax
    b003:	0f 85 81 ed ff ff    	jne    9d8a <fwp_hof0.constprop.0+0x1ca>
    b009:	e9 54 ed ff ff       	jmp    9d62 <fwp_hof0.constprop.0+0x1a2>
    b00e:	66 90                	xchg   %ax,%ax
    b010:	49 39 de             	cmp    %rbx,%r14
    b013:	0f 8f cf fe ff ff    	jg     aee8 <fwp_hof0.constprop.0+0x1328>
    b019:	4d 85 f6             	test   %r14,%r14
    b01c:	74 12                	je     b030 <fwp_hof0.constprop.0+0x1470>
    b01e:	4d 85 d2             	test   %r10,%r10
    b021:	0f 84 13 05 00 00    	je     b53a <fwp_hof0.constprop.0+0x197a>
    b027:	4d 85 f6             	test   %r14,%r14
    b02a:	0f 85 60 03 00 00    	jne    b390 <fwp_hof0.constprop.0+0x17d0>
    b030:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    b037:	e9 74 f2 ff ff       	jmp    a2b0 <fwp_hof0.constprop.0+0x6f0>
    b03c:	0f 1f 40 00          	nopl   0x0(%rax)
    b040:	66 85 c0             	test   %ax,%ax
    b043:	0f 85 f1 f3 ff ff    	jne    a43a <fwp_hof0.constprop.0+0x87a>
    b049:	80 3b ff             	cmpb   $0xff,(%rbx)
    b04c:	0f 85 e5 f3 ff ff    	jne    a437 <fwp_hof0.constprop.0+0x877>
    b052:	48 89 df             	mov    %rbx,%rdi
    b055:	e8 76 a7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b05a:	e9 d8 f3 ff ff       	jmp    a437 <fwp_hof0.constprop.0+0x877>
    b05f:	90                   	nop
    b060:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b065:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b06a:	e9 25 f8 ff ff       	jmp    a894 <fwp_hof0.constprop.0+0xcd4>
    b06f:	90                   	nop
    b070:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b075:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b07c:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b083:	48 8b 58 10          	mov    0x10(%rax),%rbx
    b087:	48 29 c8             	sub    %rcx,%rax
    b08a:	48 c1 e2 10          	shl    $0x10,%rdx
    b08e:	48 39 d0             	cmp    %rdx,%rax
    b091:	73 67                	jae    b0fa <fwp_hof0.constprop.0+0x153a>
    b093:	48 89 c7             	mov    %rax,%rdi
    b096:	48 c1 ef 10          	shr    $0x10,%rdi
    b09a:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b09e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b0a2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b0a6:	48 85 ff             	test   %rdi,%rdi
    b0a9:	74 4f                	je     b0fa <fwp_hof0.constprop.0+0x153a>
    b0ab:	44 0f b6 06          	movzbl (%rsi),%r8d
    b0af:	41 80 f8 02          	cmp    $0x2,%r8b
    b0b3:	0f 84 48 02 00 00    	je     b301 <fwp_hof0.constprop.0+0x1741>
    b0b9:	41 80 f8 01          	cmp    $0x1,%r8b
    b0bd:	75 3b                	jne    b0fa <fwp_hof0.constprop.0+0x153a>
    b0bf:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b0c3:	0f b7 c0             	movzwl %ax,%eax
    b0c6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b0c9:	49 0f af c0          	imul   %r8,%rax
    b0cd:	48 c1 e8 20          	shr    $0x20,%rax
    b0d1:	48 39 f0             	cmp    %rsi,%rax
    b0d4:	73 24                	jae    b0fa <fwp_hof0.constprop.0+0x153a>
    b0d6:	48 01 c7             	add    %rax,%rdi
    b0d9:	80 3f 01             	cmpb   $0x1,(%rdi)
    b0dc:	75 1c                	jne    b0fa <fwp_hof0.constprop.0+0x153a>
    b0de:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b0e3:	e8 28 a9 ff ff       	call   5a10 <fwp_mem_free>
    b0e8:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b0ef:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b0f6:	48 c1 e2 10          	shl    $0x10,%rdx
    b0fa:	48 89 d8             	mov    %rbx,%rax
    b0fd:	48 29 c8             	sub    %rcx,%rax
    b100:	48 39 d0             	cmp    %rdx,%rax
    b103:	0f 83 27 f8 ff ff    	jae    a930 <fwp_hof0.constprop.0+0xd70>
    b109:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    b10e:	e9 af f7 ff ff       	jmp    a8c2 <fwp_hof0.constprop.0+0xd02>
    b113:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b118:	66 85 c0             	test   %ax,%ax
    b11b:	0f 85 1d fc ff ff    	jne    ad3e <fwp_hof0.constprop.0+0x117e>
    b121:	80 3b ff             	cmpb   $0xff,(%rbx)
    b124:	0f 85 11 fc ff ff    	jne    ad3b <fwp_hof0.constprop.0+0x117b>
    b12a:	48 89 df             	mov    %rbx,%rdi
    b12d:	e8 9e a6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b132:	e9 04 fc ff ff       	jmp    ad3b <fwp_hof0.constprop.0+0x117b>
    b137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b13e:	00 00 
    b140:	48 85 db             	test   %rbx,%rbx
    b143:	0f 85 55 ef ff ff    	jne    a09e <fwp_hof0.constprop.0+0x4de>
    b149:	e9 b2 ef ff ff       	jmp    a100 <fwp_hof0.constprop.0+0x540>
    b14e:	66 90                	xchg   %ax,%ax
    b150:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    b157:	ff ff 1f 
    b15a:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
    b15e:	48 39 c2             	cmp    %rax,%rdx
    b161:	0f 82 26 04 00 00    	jb     b58d <fwp_hof0.constprop.0+0x19cd>
    b167:	48 8d 05 52 80 04 00 	lea    0x48052(%rip),%rax        # 531c0 <ad_raw_blocks>
    b16e:	45 31 ff             	xor    %r15d,%r15d
    b171:	eb 22                	jmp    b195 <fwp_hof0.constprop.0+0x15d5>
    b173:	66 90                	xchg   %ax,%ax
    b175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b17c:	00 00 00 00 
    b180:	49 83 c7 01          	add    $0x1,%r15
    b184:	48 83 c0 18          	add    $0x18,%rax
    b188:	49 81 ff 00 10 00 00 	cmp    $0x1000,%r15
    b18f:	0f 84 3d 02 00 00    	je     b3d2 <fwp_hof0.constprop.0+0x1812>
    b195:	48 83 38 00          	cmpq   $0x0,(%rax)
    b199:	75 e5                	jne    b180 <fwp_hof0.constprop.0+0x15c0>
    b19b:	be 08 00 00 00       	mov    $0x8,%esi
    b1a0:	48 89 df             	mov    %rbx,%rdi
    b1a3:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b1a8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b1ad:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    b1b2:	e8 59 83 ff ff       	call   3510 <calloc@plt>
    b1b7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b1bc:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    b1c2:	48 8d 15 f7 7f 04 00 	lea    0x47ff7(%rip),%rdx        # 531c0 <ad_raw_blocks>
    b1c9:	48 85 c0             	test   %rax,%rax
    b1cc:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b1d2:	49 89 c2             	mov    %rax,%r10
    b1d5:	74 49                	je     b220 <fwp_hof0.constprop.0+0x1660>
    b1d7:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
    b1db:	48 89 c6             	mov    %rax,%rsi
    b1de:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b1e3:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    b1e7:	b9 03 00 00 00       	mov    $0x3,%ecx
    b1ec:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b1f3:	00 
    b1f4:	e8 07 8a ff ff       	call   3c00 <ad_raw_record>
    b1f9:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b1fe:	e9 61 fd ff ff       	jmp    af64 <fwp_hof0.constprop.0+0x13a4>
    b203:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b208:	66 85 c0             	test   %ax,%ax
    b20b:	0f 85 7c ea ff ff    	jne    9c8d <fwp_hof0.constprop.0+0xcd>
    b211:	e9 4f ea ff ff       	jmp    9c65 <fwp_hof0.constprop.0+0xa5>
    b216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b21d:	00 00 00 
    b220:	4d 85 e4             	test   %r12,%r12
    b223:	0f 85 11 03 00 00    	jne    b53a <fwp_hof0.constprop.0+0x197a>
    b229:	45 31 d2             	xor    %r10d,%r10d
    b22c:	e9 4c fd ff ff       	jmp    af7d <fwp_hof0.constprop.0+0x13bd>
    b231:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b238:	66 85 c0             	test   %ax,%ax
    b23b:	0f 85 08 f8 ff ff    	jne    aa49 <fwp_hof0.constprop.0+0xe89>
    b241:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b245:	0f 85 fa f7 ff ff    	jne    aa45 <fwp_hof0.constprop.0+0xe85>
    b24b:	4c 89 ff             	mov    %r15,%rdi
    b24e:	e8 7d a5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b253:	e9 ed f7 ff ff       	jmp    aa45 <fwp_hof0.constprop.0+0xe85>
    b258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b25f:	00 
    b260:	66 85 c0             	test   %ax,%ax
    b263:	0f 85 97 f8 ff ff    	jne    ab00 <fwp_hof0.constprop.0+0xf40>
    b269:	41 0f b6 04 24       	movzbl (%r12),%eax
    b26e:	84 c0                	test   %al,%al
    b270:	0f 84 8a f8 ff ff    	je     ab00 <fwp_hof0.constprop.0+0xf40>
    b276:	3c 01                	cmp    $0x1,%al
    b278:	0f 85 6f f8 ff ff    	jne    aaed <fwp_hof0.constprop.0+0xf2d>
    b27e:	48 89 df             	mov    %rbx,%rdi
    b281:	e8 8a a7 ff ff       	call   5a10 <fwp_mem_free>
    b286:	e9 75 f8 ff ff       	jmp    ab00 <fwp_hof0.constprop.0+0xf40>
    b28b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b28f:	e9 3b eb ff ff       	jmp    9dcf <fwp_hof0.constprop.0+0x20f>
    b294:	49 8b 04 24          	mov    (%r12),%rax
    b298:	48 85 c0             	test   %rax,%rax
    b29b:	0f 88 ed fb ff ff    	js     ae8e <fwp_hof0.constprop.0+0x12ce>
    b2a1:	48 8b b5 d8 13 00 00 	mov    0x13d8(%rbp),%rsi
    b2a8:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    b2ad:	48 2b 8d b0 13 00 00 	sub    0x13b0(%rbp),%rcx
    b2b4:	48 c1 e6 10          	shl    $0x10,%rsi
    b2b8:	48 39 f1             	cmp    %rsi,%rcx
    b2bb:	0f 83 cd fb ff ff    	jae    ae8e <fwp_hof0.constprop.0+0x12ce>
    b2c1:	48 89 ce             	mov    %rcx,%rsi
    b2c4:	48 c1 ee 10          	shr    $0x10,%rsi
    b2c8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b2cc:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    b2d3:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b2d7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b2db:	48 85 ff             	test   %rdi,%rdi
    b2de:	0f 84 aa fb ff ff    	je     ae8e <fwp_hof0.constprop.0+0x12ce>
    b2e4:	48 0f ba f0 3f       	btr    $0x3f,%rax
    b2e9:	49 89 c7             	mov    %rax,%r15
    b2ec:	e9 e4 f2 ff ff       	jmp    a5d5 <fwp_hof0.constprop.0+0xa15>
    b2f1:	be 68 00 00 00       	mov    $0x68,%esi
    b2f6:	41 be 01 00 00 00    	mov    $0x1,%r14d
    b2fc:	e9 59 eb ff ff       	jmp    9e5a <fwp_hof0.constprop.0+0x29a>
    b301:	66 85 c0             	test   %ax,%ax
    b304:	0f 85 f0 fd ff ff    	jne    b0fa <fwp_hof0.constprop.0+0x153a>
    b30a:	e9 ca fd ff ff       	jmp    b0d9 <fwp_hof0.constprop.0+0x1519>
    b30f:	48 89 da             	mov    %rbx,%rdx
    b312:	48 c1 ea 11          	shr    $0x11,%rdx
    b316:	48 31 da             	xor    %rbx,%rdx
    b319:	48 89 d0             	mov    %rdx,%rax
    b31c:	48 c1 e8 09          	shr    $0x9,%rax
    b320:	48 31 c2             	xor    %rax,%rdx
    b323:	0f b6 d2             	movzbl %dl,%edx
    b326:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b32d:	00 
    b32e:	48 85 c0             	test   %rax,%rax
    b331:	75 16                	jne    b349 <fwp_hof0.constprop.0+0x1789>
    b333:	eb 4f                	jmp    b384 <fwp_hof0.constprop.0+0x17c4>
    b335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b33c:	00 00 00 00 
    b340:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b344:	48 85 c0             	test   %rax,%rax
    b347:	74 3b                	je     b384 <fwp_hof0.constprop.0+0x17c4>
    b349:	48 89 c2             	mov    %rax,%rdx
    b34c:	48 3b 18             	cmp    (%rax),%rbx
    b34f:	75 ef                	jne    b340 <fwp_hof0.constprop.0+0x1780>
    b351:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b355:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b359:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b35d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b364:	0f 85 c6 f5 ff ff    	jne    a930 <fwp_hof0.constprop.0+0xd70>
    b36a:	48 89 df             	mov    %rbx,%rdi
    b36d:	e8 5e a4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b372:	c6 03 fe             	movb   $0xfe,(%rbx)
    b375:	e9 b6 f5 ff ff       	jmp    a930 <fwp_hof0.constprop.0+0xd70>
    b37a:	e8 31 a3 ff ff       	call   56b0 <fwp_rc_wide_dup>
    b37f:	e9 06 ea ff ff       	jmp    9d8a <fwp_hof0.constprop.0+0x1ca>
    b384:	48 8d 3d 65 46 00 00 	lea    0x4665(%rip),%rdi        # f9f0 <_IO_stdin_used+0x9f0>
    b38b:	e8 c0 90 ff ff       	call   4450 <fwp_trap>
    b390:	4d 89 f4             	mov    %r14,%r12
    b393:	4c 89 d7             	mov    %r10,%rdi
    b396:	31 f6                	xor    %esi,%esi
    b398:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    b39d:	4d 8d 7c 24 ff       	lea    -0x1(%r12),%r15
    b3a2:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    b3a9:	00 
    b3aa:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b3af:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
    b3b4:	e8 f7 80 ff ff       	call   34b0 <memset@plt>
    b3b9:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    b3be:	66 0f 6f 54 24 50    	movdqa 0x50(%rsp),%xmm2
    b3c4:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b3ca:	49 89 c2             	mov    %rax,%r10
    b3cd:	e9 b2 fb ff ff       	jmp    af84 <fwp_hof0.constprop.0+0x13c4>
    b3d2:	48 8d 3d 39 3d 00 00 	lea    0x3d39(%rip),%rdi        # f112 <_IO_stdin_used+0x112>
    b3d9:	e8 22 8c ff ff       	call   4000 <ad_raw_fail>
    b3de:	e8 cd a2 ff ff       	call   56b0 <fwp_rc_wide_dup>
    b3e3:	e9 a5 e8 ff ff       	jmp    9c8d <fwp_hof0.constprop.0+0xcd>
    b3e8:	4c 89 e0             	mov    %r12,%rax
    b3eb:	48 c1 e8 11          	shr    $0x11,%rax
    b3ef:	4c 31 e0             	xor    %r12,%rax
    b3f2:	48 89 c2             	mov    %rax,%rdx
    b3f5:	48 c1 ea 09          	shr    $0x9,%rdx
    b3f9:	48 31 d0             	xor    %rdx,%rax
    b3fc:	0f b6 d0             	movzbl %al,%edx
    b3ff:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b406:	00 
    b407:	48 85 c0             	test   %rax,%rax
    b40a:	75 21                	jne    b42d <fwp_hof0.constprop.0+0x186d>
    b40c:	e9 73 ff ff ff       	jmp    b384 <fwp_hof0.constprop.0+0x17c4>
    b411:	0f 1f 40 00          	nopl   0x0(%rax)
    b415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b41c:	00 00 00 00 
    b420:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b424:	48 85 c0             	test   %rax,%rax
    b427:	0f 84 57 ff ff ff    	je     b384 <fwp_hof0.constprop.0+0x17c4>
    b42d:	48 89 c2             	mov    %rax,%rdx
    b430:	4c 3b 20             	cmp    (%rax),%r12
    b433:	75 eb                	jne    b420 <fwp_hof0.constprop.0+0x1860>
    b435:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b439:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b43d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b441:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b448:	0f 85 b2 f6 ff ff    	jne    ab00 <fwp_hof0.constprop.0+0xf40>
    b44e:	4c 89 e7             	mov    %r12,%rdi
    b451:	e8 7a a3 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b456:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b45b:	e9 a0 f6 ff ff       	jmp    ab00 <fwp_hof0.constprop.0+0xf40>
    b460:	45 31 ff             	xor    %r15d,%r15d
    b463:	e9 ed f2 ff ff       	jmp    a755 <fwp_hof0.constprop.0+0xb95>
    b468:	48 8d 3d a9 45 00 00 	lea    0x45a9(%rip),%rdi        # fa18 <_IO_stdin_used+0xa18>
    b46f:	e8 dc 8f ff ff       	call   4450 <fwp_trap>
    b474:	48 8d 3d 47 3d 00 00 	lea    0x3d47(%rip),%rdi        # f1c2 <_IO_stdin_used+0x1c2>
    b47b:	e8 d0 8f ff ff       	call   4450 <fwp_trap>
    b480:	48 8d 3d 69 46 00 00 	lea    0x4669(%rip),%rdi        # faf0 <_IO_stdin_used+0xaf0>
    b487:	e8 c4 8f ff ff       	call   4450 <fwp_trap>
    b48c:	45 31 ed             	xor    %r13d,%r13d
    b48f:	e9 0c fa ff ff       	jmp    aea0 <fwp_hof0.constprop.0+0x12e0>
    b494:	48 8d 3d 50 3d 00 00 	lea    0x3d50(%rip),%rdi        # f1eb <_IO_stdin_used+0x1eb>
    b49b:	e8 b0 8f ff ff       	call   4450 <fwp_trap>
    b4a0:	48 8d 3d d5 3d 00 00 	lea    0x3dd5(%rip),%rdi        # f27c <_IO_stdin_used+0x27c>
    b4a7:	e8 a4 8f ff ff       	call   4450 <fwp_trap>
    b4ac:	48 8d 3d ff 3d 00 00 	lea    0x3dff(%rip),%rdi        # f2b2 <_IO_stdin_used+0x2b2>
    b4b3:	e8 98 8f ff ff       	call   4450 <fwp_trap>
    b4b8:	48 8d 3d 01 46 00 00 	lea    0x4601(%rip),%rdi        # fac0 <_IO_stdin_used+0xac0>
    b4bf:	e8 8c 8f ff ff       	call   4450 <fwp_trap>
    b4c4:	48 8b 0d 75 7b 00 00 	mov    0x7b75(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b4cb:	ba 13 00 00 00       	mov    $0x13,%edx
    b4d0:	be 01 00 00 00       	mov    $0x1,%esi
    b4d5:	48 8d 3d 2c 3b 00 00 	lea    0x3b2c(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b4dc:	e8 7f 81 ff ff       	call   3660 <fwrite@plt>
    b4e1:	31 ff                	xor    %edi,%edi
    b4e3:	e8 b8 80 ff ff       	call   35a0 <fflush@plt>
    b4e8:	bf 66 00 00 00       	mov    $0x66,%edi
    b4ed:	e8 8e 81 ff ff       	call   3680 <_Exit@plt>
    b4f2:	48 8d 3d c9 3d 00 00 	lea    0x3dc9(%rip),%rdi        # f2c2 <_IO_stdin_used+0x2c2>
    b4f9:	e8 52 8f ff ff       	call   4450 <fwp_trap>
    b4fe:	66 90                	xchg   %ax,%ax
    b500:	48 8d 3d 11 46 00 00 	lea    0x4611(%rip),%rdi        # fb18 <_IO_stdin_used+0xb18>
    b507:	e8 44 8f ff ff       	call   4450 <fwp_trap>
    b50c:	48 8b 0d 2d 7b 00 00 	mov    0x7b2d(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b513:	ba 13 00 00 00       	mov    $0x13,%edx
    b518:	be 01 00 00 00       	mov    $0x1,%esi
    b51d:	48 8d 3d e4 3a 00 00 	lea    0x3ae4(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b524:	e8 37 81 ff ff       	call   3660 <fwrite@plt>
    b529:	31 ff                	xor    %edi,%edi
    b52b:	e8 70 80 ff ff       	call   35a0 <fflush@plt>
    b530:	bf 66 00 00 00       	mov    $0x66,%edi
    b535:	e8 46 81 ff ff       	call   3680 <_Exit@plt>
    b53a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    b541:	00 
    b542:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    b547:	48 89 05 6a 1f 06 00 	mov    %rax,0x61f6a(%rip)        # 6d4b8 <fwp_cleanups>
    b54e:	e8 0d 9d ff ff       	call   5260 <fwp_tape_buffers_release>
    b553:	ba 13 00 00 00       	mov    $0x13,%edx
    b558:	48 8b 0d e1 7a 00 00 	mov    0x7ae1(%rip),%rcx        # 13040 <stderr@GLIBC_2.2.5>
    b55f:	be 01 00 00 00       	mov    $0x1,%esi
    b564:	48 8d 3d 9d 3a 00 00 	lea    0x3a9d(%rip),%rdi        # f008 <_IO_stdin_used+0x8>
    b56b:	e8 f0 80 ff ff       	call   3660 <fwrite@plt>
    b570:	31 ff                	xor    %edi,%edi
    b572:	e8 29 80 ff ff       	call   35a0 <fflush@plt>
    b577:	bf 66 00 00 00       	mov    $0x66,%edi
    b57c:	e8 ff 80 ff ff       	call   3680 <_Exit@plt>
    b581:	48 8d 3d d8 44 00 00 	lea    0x44d8(%rip),%rdi        # fa60 <_IO_stdin_used+0xa60>
    b588:	e8 c3 8e ff ff       	call   4450 <fwp_trap>
    b58d:	48 8d 3d 02 3d 00 00 	lea    0x3d02(%rip),%rdi        # f296 <_IO_stdin_used+0x296>
    b594:	e8 67 8a ff ff       	call   4000 <ad_raw_fail>
    b599:	e8 b2 7e ff ff       	call   3450 <__stack_chk_fail@plt>
    b59e:	66 90                	xchg   %ax,%ax

000000000000b5a0 <f0>:
    b5a0:	41 56                	push   %r14
    b5a2:	4c 8d 35 77 02 06 00 	lea    0x60277(%rip),%r14        # 6b820 <fwp_heap>
    b5a9:	41 55                	push   %r13
    b5ab:	41 54                	push   %r12
    b5ad:	41 bc 07 00 00 00    	mov    $0x7,%r12d
    b5b3:	55                   	push   %rbp
    b5b4:	53                   	push   %rbx
    b5b5:	31 db                	xor    %ebx,%ebx
    b5b7:	48 81 ec 60 08 00 00 	sub    $0x860,%rsp
    b5be:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b5c5:	00 00 
    b5c7:	48 89 84 24 58 08 00 	mov    %rax,0x858(%rsp)
    b5ce:	00 
    b5cf:	31 c0                	xor    %eax,%eax
    b5d1:	48 8d ac 24 40 08 00 	lea    0x840(%rsp),%rbp
    b5d8:	00 
    b5d9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
    b5e0:	00 00 
    b5e2:	66 48 0f 6e c0       	movq   %rax,%xmm0
    b5e7:	48 8d 05 22 cc ff ff 	lea    -0x33de(%rip),%rax        # 8210 <fwp_drop1>
    b5ee:	66 48 0f 6e c8       	movq   %rax,%xmm1
    b5f3:	48 8b 05 be 1e 06 00 	mov    0x61ebe(%rip),%rax        # 6d4b8 <fwp_cleanups>
    b5fa:	48 89 25 b7 1e 06 00 	mov    %rsp,0x61eb7(%rip)        # 6d4b8 <fwp_cleanups>
    b601:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    b605:	48 89 04 24          	mov    %rax,(%rsp)
    b609:	48 8d 05 c0 85 ff ff 	lea    -0x7a40(%rip),%rax        # 3bd0 <fwp_range_release>
    b610:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b615:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
    b61a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    b61f:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
    b624:	eb 47                	jmp    b66d <f0+0xcd>
    b626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b62d:	00 00 00 
    b630:	80 f9 01             	cmp    $0x1,%cl
    b633:	75 29                	jne    b65e <f0+0xbe>
    b635:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b638:	0f b7 c0             	movzwl %ax,%eax
    b63b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b63e:	48 0f af c1          	imul   %rcx,%rax
    b642:	48 c1 e8 20          	shr    $0x20,%rax
    b646:	48 39 d0             	cmp    %rdx,%rax
    b649:	73 13                	jae    b65e <f0+0xbe>
    b64b:	49 01 c5             	add    %rax,%r13
    b64e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b653:	0f 84 c7 27 00 00    	je     de20 <f0+0x2880>
    b659:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b65e:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b663:	49 83 ec 01          	sub    $0x1,%r12
    b667:	0f 82 83 00 00 00    	jb     b6f0 <f0+0x150>
    b66d:	48 89 ee             	mov    %rbp,%rsi
    b670:	bf 01 00 00 00       	mov    $0x1,%edi
    b675:	48 89 9c 24 48 08 00 	mov    %rbx,0x848(%rsp)
    b67c:	00 
    b67d:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    b682:	4c 89 a4 24 40 08 00 	mov    %r12,0x840(%rsp)
    b689:	00 
    b68a:	e8 71 aa ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b68f:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b696:	48 89 c3             	mov    %rax,%rbx
    b699:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b6a0:	48 c1 e2 10          	shl    $0x10,%rdx
    b6a4:	48 39 d0             	cmp    %rdx,%rax
    b6a7:	73 b5                	jae    b65e <f0+0xbe>
    b6a9:	48 89 c2             	mov    %rax,%rdx
    b6ac:	48 c1 ea 10          	shr    $0x10,%rdx
    b6b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b6b4:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b6bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b6bf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b6c3:	4d 85 ed             	test   %r13,%r13
    b6c6:	74 96                	je     b65e <f0+0xbe>
    b6c8:	0f b6 0a             	movzbl (%rdx),%ecx
    b6cb:	80 f9 02             	cmp    $0x2,%cl
    b6ce:	0f 85 5c ff ff ff    	jne    b630 <f0+0x90>
    b6d4:	66 85 c0             	test   %ax,%ax
    b6d7:	0f 84 71 ff ff ff    	je     b64e <f0+0xae>
    b6dd:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
    b6e2:	49 83 ec 01          	sub    $0x1,%r12
    b6e6:	73 85                	jae    b66d <f0+0xcd>
    b6e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b6ef:	00 
    b6f0:	48 8b 04 24          	mov    (%rsp),%rax
    b6f4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
    b6f9:	bf 01 00 00 00       	mov    $0x1,%edi
    b6fe:	66 0f 6f 05 0a 47 00 	movdqa 0x470a(%rip),%xmm0        # fe10 <msg.4+0xd0>
    b705:	00 
    b706:	48 89 05 ab 1d 06 00 	mov    %rax,0x61dab(%rip)        # 6d4b8 <fwp_cleanups>
    b70d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b712:	e8 e9 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b717:	48 8b 15 da 14 06 00 	mov    0x614da(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b71e:	49 89 c5             	mov    %rax,%r13
    b721:	48 2b 05 a8 14 06 00 	sub    0x614a8(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b728:	48 c1 e2 10          	shl    $0x10,%rdx
    b72c:	48 39 d0             	cmp    %rdx,%rax
    b72f:	73 59                	jae    b78a <f0+0x1ea>
    b731:	48 89 c2             	mov    %rax,%rdx
    b734:	48 c1 ea 10          	shr    $0x10,%rdx
    b738:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b73c:	48 8b 15 d5 14 06 00 	mov    0x614d5(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b743:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b747:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b74b:	4d 85 e4             	test   %r12,%r12
    b74e:	74 3a                	je     b78a <f0+0x1ea>
    b750:	0f b6 0a             	movzbl (%rdx),%ecx
    b753:	80 f9 02             	cmp    $0x2,%cl
    b756:	0f 84 74 27 00 00    	je     ded0 <f0+0x2930>
    b75c:	80 f9 01             	cmp    $0x1,%cl
    b75f:	75 29                	jne    b78a <f0+0x1ea>
    b761:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b764:	0f b7 c0             	movzwl %ax,%eax
    b767:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b76a:	48 0f af c1          	imul   %rcx,%rax
    b76e:	48 c1 e8 20          	shr    $0x20,%rax
    b772:	48 39 d0             	cmp    %rdx,%rax
    b775:	73 13                	jae    b78a <f0+0x1ea>
    b777:	49 01 c4             	add    %rax,%r12
    b77a:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b77f:	0f 84 26 29 00 00    	je     e0ab <f0+0x2b0b>
    b785:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b78a:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
    b78f:	bf 01 00 00 00       	mov    $0x1,%edi
    b794:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
    b799:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b7a0:	00 f0 3f 
    b7a3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    b7a8:	e8 53 a9 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b7ad:	48 8b 15 44 14 06 00 	mov    0x61444(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b7b4:	49 89 c5             	mov    %rax,%r13
    b7b7:	48 2b 05 12 14 06 00 	sub    0x61412(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b7be:	48 c1 e2 10          	shl    $0x10,%rdx
    b7c2:	48 39 d0             	cmp    %rdx,%rax
    b7c5:	73 59                	jae    b820 <f0+0x280>
    b7c7:	48 89 c2             	mov    %rax,%rdx
    b7ca:	48 c1 ea 10          	shr    $0x10,%rdx
    b7ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7d2:	48 8b 15 3f 14 06 00 	mov    0x6143f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b7d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b7e1:	4d 85 e4             	test   %r12,%r12
    b7e4:	74 3a                	je     b820 <f0+0x280>
    b7e6:	0f b6 0a             	movzbl (%rdx),%ecx
    b7e9:	80 f9 02             	cmp    $0x2,%cl
    b7ec:	0f 84 ce 26 00 00    	je     dec0 <f0+0x2920>
    b7f2:	80 f9 01             	cmp    $0x1,%cl
    b7f5:	75 29                	jne    b820 <f0+0x280>
    b7f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7fa:	0f b7 c0             	movzwl %ax,%eax
    b7fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b800:	48 0f af c1          	imul   %rcx,%rax
    b804:	48 c1 e8 20          	shr    $0x20,%rax
    b808:	48 39 d0             	cmp    %rdx,%rax
    b80b:	73 13                	jae    b820 <f0+0x280>
    b80d:	49 01 c4             	add    %rax,%r12
    b810:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b815:	0f 84 9d 28 00 00    	je     e0b8 <f0+0x2b18>
    b81b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b820:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b825:	bf 01 00 00 00       	mov    $0x1,%edi
    b82a:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    b82f:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b836:	33 f3 bf 
    b839:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b83e:	e8 bd a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b843:	48 8b 15 ae 13 06 00 	mov    0x613ae(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b84a:	49 89 c5             	mov    %rax,%r13
    b84d:	48 2b 05 7c 13 06 00 	sub    0x6137c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b854:	48 c1 e2 10          	shl    $0x10,%rdx
    b858:	48 39 d0             	cmp    %rdx,%rax
    b85b:	73 59                	jae    b8b6 <f0+0x316>
    b85d:	48 89 c2             	mov    %rax,%rdx
    b860:	48 c1 ea 10          	shr    $0x10,%rdx
    b864:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b868:	48 8b 15 a9 13 06 00 	mov    0x613a9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b86f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b873:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b877:	4d 85 e4             	test   %r12,%r12
    b87a:	74 3a                	je     b8b6 <f0+0x316>
    b87c:	0f b6 0a             	movzbl (%rdx),%ecx
    b87f:	80 f9 02             	cmp    $0x2,%cl
    b882:	0f 84 28 26 00 00    	je     deb0 <f0+0x2910>
    b888:	80 f9 01             	cmp    $0x1,%cl
    b88b:	75 29                	jne    b8b6 <f0+0x316>
    b88d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b890:	0f b7 c0             	movzwl %ax,%eax
    b893:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b896:	48 0f af c1          	imul   %rcx,%rax
    b89a:	48 c1 e8 20          	shr    $0x20,%rax
    b89e:	48 39 d0             	cmp    %rdx,%rax
    b8a1:	73 13                	jae    b8b6 <f0+0x316>
    b8a3:	49 01 c4             	add    %rax,%r12
    b8a6:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b8ab:	0f 84 14 28 00 00    	je     e0c5 <f0+0x2b25>
    b8b1:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b8b6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b8bb:	bf 01 00 00 00       	mov    $0x1,%edi
    b8c0:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
    b8c5:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b8cc:	00 f0 3f 
    b8cf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b8d4:	e8 27 a8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b8d9:	48 8b 15 18 13 06 00 	mov    0x61318(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b8e0:	49 89 c5             	mov    %rax,%r13
    b8e3:	48 2b 05 e6 12 06 00 	sub    0x612e6(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b8ea:	48 c1 e2 10          	shl    $0x10,%rdx
    b8ee:	48 39 d0             	cmp    %rdx,%rax
    b8f1:	73 59                	jae    b94c <f0+0x3ac>
    b8f3:	48 89 c2             	mov    %rax,%rdx
    b8f6:	48 c1 ea 10          	shr    $0x10,%rdx
    b8fa:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b8fe:	48 8b 15 13 13 06 00 	mov    0x61313(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b905:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b909:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b90d:	4d 85 e4             	test   %r12,%r12
    b910:	74 3a                	je     b94c <f0+0x3ac>
    b912:	0f b6 0a             	movzbl (%rdx),%ecx
    b915:	80 f9 02             	cmp    $0x2,%cl
    b918:	0f 84 f2 25 00 00    	je     df10 <f0+0x2970>
    b91e:	80 f9 01             	cmp    $0x1,%cl
    b921:	75 29                	jne    b94c <f0+0x3ac>
    b923:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b926:	0f b7 c0             	movzwl %ax,%eax
    b929:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b92c:	48 0f af c1          	imul   %rcx,%rax
    b930:	48 c1 e8 20          	shr    $0x20,%rax
    b934:	48 39 d0             	cmp    %rdx,%rax
    b937:	73 13                	jae    b94c <f0+0x3ac>
    b939:	49 01 c4             	add    %rax,%r12
    b93c:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b941:	0f 84 8b 27 00 00    	je     e0d2 <f0+0x2b32>
    b947:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b94c:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b953:	33 f3 bf 
    b956:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    b95d:	00 
    b95e:	bf 01 00 00 00       	mov    $0x1,%edi
    b963:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
    b96a:	00 
    b96b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    b972:	00 
    b973:	e8 88 a7 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b978:	48 8b 15 79 12 06 00 	mov    0x61279(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    b97f:	49 89 c5             	mov    %rax,%r13
    b982:	48 2b 05 47 12 06 00 	sub    0x61247(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    b989:	48 c1 e2 10          	shl    $0x10,%rdx
    b98d:	48 39 d0             	cmp    %rdx,%rax
    b990:	73 59                	jae    b9eb <f0+0x44b>
    b992:	48 89 c2             	mov    %rax,%rdx
    b995:	48 c1 ea 10          	shr    $0x10,%rdx
    b999:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b99d:	48 8b 15 74 12 06 00 	mov    0x61274(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    b9a4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b9a8:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    b9ac:	4d 85 e4             	test   %r12,%r12
    b9af:	74 3a                	je     b9eb <f0+0x44b>
    b9b1:	0f b6 0a             	movzbl (%rdx),%ecx
    b9b4:	80 f9 02             	cmp    $0x2,%cl
    b9b7:	0f 84 43 25 00 00    	je     df00 <f0+0x2960>
    b9bd:	80 f9 01             	cmp    $0x1,%cl
    b9c0:	75 29                	jne    b9eb <f0+0x44b>
    b9c2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b9c5:	0f b7 c0             	movzwl %ax,%eax
    b9c8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b9cb:	48 0f af c1          	imul   %rcx,%rax
    b9cf:	48 c1 e8 20          	shr    $0x20,%rax
    b9d3:	48 39 d0             	cmp    %rdx,%rax
    b9d6:	73 13                	jae    b9eb <f0+0x44b>
    b9d8:	49 01 c4             	add    %rax,%r12
    b9db:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    b9e0:	0f 84 f9 26 00 00    	je     e0df <f0+0x2b3f>
    b9e6:	41 c6 04 24 01       	movb   $0x1,(%r12)
    b9eb:	49 bc 00 00 00 00 00 	movabs $0x3ff0000000000000,%r12
    b9f2:	00 f0 3f 
    b9f5:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
    b9fc:	00 
    b9fd:	bf 01 00 00 00       	mov    $0x1,%edi
    ba02:	4c 89 ac 24 98 00 00 	mov    %r13,0x98(%rsp)
    ba09:	00 
    ba0a:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    ba11:	00 
    ba12:	49 bd 33 33 33 33 33 	movabs $0xbff3333333333333,%r13
    ba19:	33 f3 bf 
    ba1c:	e8 df a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba21:	48 89 c7             	mov    %rax,%rdi
    ba24:	e8 47 b3 ff ff       	call   6d70 <fwp_rc_fresh>
    ba29:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
    ba30:	00 
    ba31:	bf 01 00 00 00       	mov    $0x1,%edi
    ba36:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
    ba3d:	00 
    ba3e:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    ba45:	00 
    ba46:	e8 b5 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba4b:	48 89 c7             	mov    %rax,%rdi
    ba4e:	e8 1d b3 ff ff       	call   6d70 <fwp_rc_fresh>
    ba53:	48 8d b4 24 b0 00 00 	lea    0xb0(%rsp),%rsi
    ba5a:	00 
    ba5b:	bf 01 00 00 00       	mov    $0x1,%edi
    ba60:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
    ba67:	00 
    ba68:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    ba6f:	00 
    ba70:	e8 8b a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba75:	48 89 c7             	mov    %rax,%rdi
    ba78:	e8 f3 b2 ff ff       	call   6d70 <fwp_rc_fresh>
    ba7d:	48 8d b4 24 c0 00 00 	lea    0xc0(%rsp),%rsi
    ba84:	00 
    ba85:	bf 01 00 00 00       	mov    $0x1,%edi
    ba8a:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
    ba91:	00 
    ba92:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    ba99:	00 
    ba9a:	e8 61 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ba9f:	48 89 c7             	mov    %rax,%rdi
    baa2:	e8 c9 b2 ff ff       	call   6d70 <fwp_rc_fresh>
    baa7:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
    baae:	00 
    baaf:	bf 01 00 00 00       	mov    $0x1,%edi
    bab4:	4c 89 a4 24 d0 00 00 	mov    %r12,0xd0(%rsp)
    babb:	00 
    babc:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    bac3:	00 
    bac4:	e8 37 a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bac9:	48 89 c7             	mov    %rax,%rdi
    bacc:	e8 9f b2 ff ff       	call   6d70 <fwp_rc_fresh>
    bad1:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
    bad8:	00 
    bad9:	bf 01 00 00 00       	mov    $0x1,%edi
    bade:	4c 89 ac 24 e0 00 00 	mov    %r13,0xe0(%rsp)
    bae5:	00 
    bae6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
    baed:	00 
    baee:	e8 0d a6 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    baf3:	48 89 c7             	mov    %rax,%rdi
    baf6:	e8 75 b2 ff ff       	call   6d70 <fwp_rc_fresh>
    bafb:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
    bb02:	00 
    bb03:	bf 01 00 00 00       	mov    $0x1,%edi
    bb08:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
    bb0f:	00 
    bb10:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
    bb17:	00 
    bb18:	e8 e3 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb1d:	48 89 c7             	mov    %rax,%rdi
    bb20:	e8 4b b2 ff ff       	call   6d70 <fwp_rc_fresh>
    bb25:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
    bb2c:	00 
    bb2d:	bf 01 00 00 00       	mov    $0x1,%edi
    bb32:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
    bb39:	00 
    bb3a:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
    bb41:	00 
    bb42:	e8 b9 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb47:	48 89 c7             	mov    %rax,%rdi
    bb4a:	e8 21 b2 ff ff       	call   6d70 <fwp_rc_fresh>
    bb4f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    bb56:	00 
    bb57:	bf 01 00 00 00       	mov    $0x1,%edi
    bb5c:	4c 89 a4 24 10 01 00 	mov    %r12,0x110(%rsp)
    bb63:	00 
    bb64:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    bb6b:	00 
    bb6c:	e8 8f a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb71:	48 89 c7             	mov    %rax,%rdi
    bb74:	e8 f7 b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bb79:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    bb80:	00 
    bb81:	bf 01 00 00 00       	mov    $0x1,%edi
    bb86:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
    bb8d:	00 
    bb8e:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
    bb95:	00 
    bb96:	e8 65 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bb9b:	48 89 c7             	mov    %rax,%rdi
    bb9e:	e8 cd b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bba3:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    bbaa:	00 
    bbab:	bf 01 00 00 00       	mov    $0x1,%edi
    bbb0:	4c 89 a4 24 30 01 00 	mov    %r12,0x130(%rsp)
    bbb7:	00 
    bbb8:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
    bbbf:	00 
    bbc0:	e8 3b a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbc5:	48 89 c7             	mov    %rax,%rdi
    bbc8:	e8 a3 b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bbcd:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    bbd4:	00 
    bbd5:	bf 01 00 00 00       	mov    $0x1,%edi
    bbda:	4c 89 ac 24 40 01 00 	mov    %r13,0x140(%rsp)
    bbe1:	00 
    bbe2:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
    bbe9:	00 
    bbea:	e8 11 a5 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bbef:	48 89 c7             	mov    %rax,%rdi
    bbf2:	e8 79 b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bbf7:	48 8d b4 24 50 01 00 	lea    0x150(%rsp),%rsi
    bbfe:	00 
    bbff:	bf 01 00 00 00       	mov    $0x1,%edi
    bc04:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
    bc0b:	00 
    bc0c:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
    bc13:	00 
    bc14:	e8 e7 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc19:	48 89 c7             	mov    %rax,%rdi
    bc1c:	e8 4f b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bc21:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
    bc28:	00 
    bc29:	bf 01 00 00 00       	mov    $0x1,%edi
    bc2e:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
    bc35:	00 
    bc36:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
    bc3d:	00 
    bc3e:	e8 bd a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc43:	48 89 c7             	mov    %rax,%rdi
    bc46:	e8 25 b1 ff ff       	call   6d70 <fwp_rc_fresh>
    bc4b:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
    bc52:	00 
    bc53:	bf 01 00 00 00       	mov    $0x1,%edi
    bc58:	4c 89 a4 24 70 01 00 	mov    %r12,0x170(%rsp)
    bc5f:	00 
    bc60:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
    bc67:	00 
    bc68:	e8 93 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc6d:	48 89 c7             	mov    %rax,%rdi
    bc70:	e8 fb b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bc75:	48 8d b4 24 80 01 00 	lea    0x180(%rsp),%rsi
    bc7c:	00 
    bc7d:	bf 01 00 00 00       	mov    $0x1,%edi
    bc82:	4c 89 ac 24 80 01 00 	mov    %r13,0x180(%rsp)
    bc89:	00 
    bc8a:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
    bc91:	00 
    bc92:	e8 69 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bc97:	48 89 c7             	mov    %rax,%rdi
    bc9a:	e8 d1 b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bc9f:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
    bca6:	00 
    bca7:	bf 01 00 00 00       	mov    $0x1,%edi
    bcac:	4c 89 a4 24 90 01 00 	mov    %r12,0x190(%rsp)
    bcb3:	00 
    bcb4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
    bcbb:	00 
    bcbc:	e8 3f a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bcc1:	48 89 c7             	mov    %rax,%rdi
    bcc4:	e8 a7 b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bcc9:	48 8d b4 24 a0 01 00 	lea    0x1a0(%rsp),%rsi
    bcd0:	00 
    bcd1:	bf 01 00 00 00       	mov    $0x1,%edi
    bcd6:	4c 89 ac 24 a0 01 00 	mov    %r13,0x1a0(%rsp)
    bcdd:	00 
    bcde:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
    bce5:	00 
    bce6:	e8 15 a4 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bceb:	48 89 c7             	mov    %rax,%rdi
    bcee:	e8 7d b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bcf3:	48 8d b4 24 b0 01 00 	lea    0x1b0(%rsp),%rsi
    bcfa:	00 
    bcfb:	bf 01 00 00 00       	mov    $0x1,%edi
    bd00:	4c 89 a4 24 b0 01 00 	mov    %r12,0x1b0(%rsp)
    bd07:	00 
    bd08:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
    bd0f:	00 
    bd10:	e8 eb a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd15:	48 89 c7             	mov    %rax,%rdi
    bd18:	e8 53 b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bd1d:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
    bd24:	00 
    bd25:	bf 01 00 00 00       	mov    $0x1,%edi
    bd2a:	4c 89 ac 24 c0 01 00 	mov    %r13,0x1c0(%rsp)
    bd31:	00 
    bd32:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
    bd39:	00 
    bd3a:	e8 c1 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd3f:	48 89 c7             	mov    %rax,%rdi
    bd42:	e8 29 b0 ff ff       	call   6d70 <fwp_rc_fresh>
    bd47:	48 8d b4 24 d0 01 00 	lea    0x1d0(%rsp),%rsi
    bd4e:	00 
    bd4f:	bf 01 00 00 00       	mov    $0x1,%edi
    bd54:	4c 89 a4 24 d0 01 00 	mov    %r12,0x1d0(%rsp)
    bd5b:	00 
    bd5c:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    bd63:	00 
    bd64:	e8 97 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd69:	48 89 c7             	mov    %rax,%rdi
    bd6c:	e8 ff af ff ff       	call   6d70 <fwp_rc_fresh>
    bd71:	48 8d b4 24 e0 01 00 	lea    0x1e0(%rsp),%rsi
    bd78:	00 
    bd79:	bf 01 00 00 00       	mov    $0x1,%edi
    bd7e:	4c 89 ac 24 e0 01 00 	mov    %r13,0x1e0(%rsp)
    bd85:	00 
    bd86:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    bd8d:	00 
    bd8e:	e8 6d a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bd93:	48 89 c7             	mov    %rax,%rdi
    bd96:	e8 d5 af ff ff       	call   6d70 <fwp_rc_fresh>
    bd9b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
    bda2:	00 
    bda3:	bf 01 00 00 00       	mov    $0x1,%edi
    bda8:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
    bdaf:	00 
    bdb0:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
    bdb7:	00 
    bdb8:	e8 43 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bdbd:	48 89 c7             	mov    %rax,%rdi
    bdc0:	e8 ab af ff ff       	call   6d70 <fwp_rc_fresh>
    bdc5:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
    bdcc:	00 
    bdcd:	bf 01 00 00 00       	mov    $0x1,%edi
    bdd2:	4c 89 ac 24 00 02 00 	mov    %r13,0x200(%rsp)
    bdd9:	00 
    bdda:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
    bde1:	00 
    bde2:	e8 19 a3 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bde7:	48 89 c7             	mov    %rax,%rdi
    bdea:	e8 81 af ff ff       	call   6d70 <fwp_rc_fresh>
    bdef:	48 8d b4 24 10 02 00 	lea    0x210(%rsp),%rsi
    bdf6:	00 
    bdf7:	bf 01 00 00 00       	mov    $0x1,%edi
    bdfc:	4c 89 a4 24 10 02 00 	mov    %r12,0x210(%rsp)
    be03:	00 
    be04:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
    be0b:	00 
    be0c:	e8 ef a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be11:	48 89 c7             	mov    %rax,%rdi
    be14:	e8 57 af ff ff       	call   6d70 <fwp_rc_fresh>
    be19:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
    be20:	00 
    be21:	bf 01 00 00 00       	mov    $0x1,%edi
    be26:	4c 89 ac 24 20 02 00 	mov    %r13,0x220(%rsp)
    be2d:	00 
    be2e:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
    be35:	00 
    be36:	e8 c5 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be3b:	48 89 c7             	mov    %rax,%rdi
    be3e:	e8 2d af ff ff       	call   6d70 <fwp_rc_fresh>
    be43:	48 8d b4 24 30 02 00 	lea    0x230(%rsp),%rsi
    be4a:	00 
    be4b:	bf 01 00 00 00       	mov    $0x1,%edi
    be50:	4c 89 a4 24 30 02 00 	mov    %r12,0x230(%rsp)
    be57:	00 
    be58:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
    be5f:	00 
    be60:	e8 9b a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be65:	48 89 c7             	mov    %rax,%rdi
    be68:	e8 03 af ff ff       	call   6d70 <fwp_rc_fresh>
    be6d:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
    be74:	00 
    be75:	bf 01 00 00 00       	mov    $0x1,%edi
    be7a:	4c 89 ac 24 40 02 00 	mov    %r13,0x240(%rsp)
    be81:	00 
    be82:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
    be89:	00 
    be8a:	e8 71 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    be8f:	48 89 c7             	mov    %rax,%rdi
    be92:	e8 d9 ae ff ff       	call   6d70 <fwp_rc_fresh>
    be97:	48 8d b4 24 50 02 00 	lea    0x250(%rsp),%rsi
    be9e:	00 
    be9f:	bf 01 00 00 00       	mov    $0x1,%edi
    bea4:	4c 89 a4 24 50 02 00 	mov    %r12,0x250(%rsp)
    beab:	00 
    beac:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
    beb3:	00 
    beb4:	e8 47 a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    beb9:	48 89 c7             	mov    %rax,%rdi
    bebc:	e8 af ae ff ff       	call   6d70 <fwp_rc_fresh>
    bec1:	48 8d b4 24 60 02 00 	lea    0x260(%rsp),%rsi
    bec8:	00 
    bec9:	bf 01 00 00 00       	mov    $0x1,%edi
    bece:	4c 89 ac 24 60 02 00 	mov    %r13,0x260(%rsp)
    bed5:	00 
    bed6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
    bedd:	00 
    bede:	e8 1d a2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bee3:	48 89 c7             	mov    %rax,%rdi
    bee6:	e8 85 ae ff ff       	call   6d70 <fwp_rc_fresh>
    beeb:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
    bef2:	00 
    bef3:	bf 01 00 00 00       	mov    $0x1,%edi
    bef8:	4c 89 a4 24 70 02 00 	mov    %r12,0x270(%rsp)
    beff:	00 
    bf00:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
    bf07:	00 
    bf08:	e8 f3 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf0d:	48 89 c7             	mov    %rax,%rdi
    bf10:	e8 5b ae ff ff       	call   6d70 <fwp_rc_fresh>
    bf15:	48 8d b4 24 80 02 00 	lea    0x280(%rsp),%rsi
    bf1c:	00 
    bf1d:	bf 01 00 00 00       	mov    $0x1,%edi
    bf22:	4c 89 ac 24 80 02 00 	mov    %r13,0x280(%rsp)
    bf29:	00 
    bf2a:	48 89 84 24 88 02 00 	mov    %rax,0x288(%rsp)
    bf31:	00 
    bf32:	e8 c9 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf37:	48 89 c7             	mov    %rax,%rdi
    bf3a:	e8 31 ae ff ff       	call   6d70 <fwp_rc_fresh>
    bf3f:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
    bf46:	00 
    bf47:	bf 01 00 00 00       	mov    $0x1,%edi
    bf4c:	4c 89 a4 24 90 02 00 	mov    %r12,0x290(%rsp)
    bf53:	00 
    bf54:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
    bf5b:	00 
    bf5c:	e8 9f a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf61:	48 89 c7             	mov    %rax,%rdi
    bf64:	e8 07 ae ff ff       	call   6d70 <fwp_rc_fresh>
    bf69:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
    bf70:	00 
    bf71:	bf 01 00 00 00       	mov    $0x1,%edi
    bf76:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
    bf7d:	00 
    bf7e:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
    bf85:	00 
    bf86:	e8 75 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bf8b:	48 89 c7             	mov    %rax,%rdi
    bf8e:	e8 dd ad ff ff       	call   6d70 <fwp_rc_fresh>
    bf93:	48 8d b4 24 b0 02 00 	lea    0x2b0(%rsp),%rsi
    bf9a:	00 
    bf9b:	bf 01 00 00 00       	mov    $0x1,%edi
    bfa0:	4c 89 a4 24 b0 02 00 	mov    %r12,0x2b0(%rsp)
    bfa7:	00 
    bfa8:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
    bfaf:	00 
    bfb0:	e8 4b a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfb5:	48 89 c7             	mov    %rax,%rdi
    bfb8:	e8 b3 ad ff ff       	call   6d70 <fwp_rc_fresh>
    bfbd:	48 8d b4 24 c0 02 00 	lea    0x2c0(%rsp),%rsi
    bfc4:	00 
    bfc5:	bf 01 00 00 00       	mov    $0x1,%edi
    bfca:	4c 89 ac 24 c0 02 00 	mov    %r13,0x2c0(%rsp)
    bfd1:	00 
    bfd2:	48 89 84 24 c8 02 00 	mov    %rax,0x2c8(%rsp)
    bfd9:	00 
    bfda:	e8 21 a1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    bfdf:	48 89 c7             	mov    %rax,%rdi
    bfe2:	e8 89 ad ff ff       	call   6d70 <fwp_rc_fresh>
    bfe7:	48 8d b4 24 d0 02 00 	lea    0x2d0(%rsp),%rsi
    bfee:	00 
    bfef:	bf 01 00 00 00       	mov    $0x1,%edi
    bff4:	4c 89 a4 24 d0 02 00 	mov    %r12,0x2d0(%rsp)
    bffb:	00 
    bffc:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
    c003:	00 
    c004:	e8 f7 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c009:	48 89 c7             	mov    %rax,%rdi
    c00c:	e8 5f ad ff ff       	call   6d70 <fwp_rc_fresh>
    c011:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
    c018:	00 
    c019:	bf 01 00 00 00       	mov    $0x1,%edi
    c01e:	4c 89 ac 24 e0 02 00 	mov    %r13,0x2e0(%rsp)
    c025:	00 
    c026:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
    c02d:	00 
    c02e:	e8 cd a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c033:	48 89 c7             	mov    %rax,%rdi
    c036:	e8 35 ad ff ff       	call   6d70 <fwp_rc_fresh>
    c03b:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
    c042:	00 
    c043:	bf 01 00 00 00       	mov    $0x1,%edi
    c048:	4c 89 a4 24 f0 02 00 	mov    %r12,0x2f0(%rsp)
    c04f:	00 
    c050:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
    c057:	00 
    c058:	e8 a3 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c05d:	48 89 c7             	mov    %rax,%rdi
    c060:	e8 0b ad ff ff       	call   6d70 <fwp_rc_fresh>
    c065:	48 8d b4 24 00 03 00 	lea    0x300(%rsp),%rsi
    c06c:	00 
    c06d:	bf 01 00 00 00       	mov    $0x1,%edi
    c072:	4c 89 ac 24 00 03 00 	mov    %r13,0x300(%rsp)
    c079:	00 
    c07a:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
    c081:	00 
    c082:	e8 79 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c087:	48 89 c7             	mov    %rax,%rdi
    c08a:	e8 e1 ac ff ff       	call   6d70 <fwp_rc_fresh>
    c08f:	48 8d b4 24 10 03 00 	lea    0x310(%rsp),%rsi
    c096:	00 
    c097:	bf 01 00 00 00       	mov    $0x1,%edi
    c09c:	4c 89 a4 24 10 03 00 	mov    %r12,0x310(%rsp)
    c0a3:	00 
    c0a4:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
    c0ab:	00 
    c0ac:	e8 4f a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0b1:	48 89 c7             	mov    %rax,%rdi
    c0b4:	e8 b7 ac ff ff       	call   6d70 <fwp_rc_fresh>
    c0b9:	48 8d b4 24 20 03 00 	lea    0x320(%rsp),%rsi
    c0c0:	00 
    c0c1:	bf 01 00 00 00       	mov    $0x1,%edi
    c0c6:	4c 89 ac 24 20 03 00 	mov    %r13,0x320(%rsp)
    c0cd:	00 
    c0ce:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
    c0d5:	00 
    c0d6:	e8 25 a0 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c0db:	48 89 c7             	mov    %rax,%rdi
    c0de:	e8 8d ac ff ff       	call   6d70 <fwp_rc_fresh>
    c0e3:	48 8d b4 24 30 03 00 	lea    0x330(%rsp),%rsi
    c0ea:	00 
    c0eb:	bf 01 00 00 00       	mov    $0x1,%edi
    c0f0:	4c 89 a4 24 30 03 00 	mov    %r12,0x330(%rsp)
    c0f7:	00 
    c0f8:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
    c0ff:	00 
    c100:	e8 fb 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c105:	48 89 c7             	mov    %rax,%rdi
    c108:	e8 63 ac ff ff       	call   6d70 <fwp_rc_fresh>
    c10d:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
    c114:	00 
    c115:	bf 01 00 00 00       	mov    $0x1,%edi
    c11a:	4c 89 ac 24 40 03 00 	mov    %r13,0x340(%rsp)
    c121:	00 
    c122:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
    c129:	00 
    c12a:	e8 d1 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c12f:	48 89 c7             	mov    %rax,%rdi
    c132:	e8 39 ac ff ff       	call   6d70 <fwp_rc_fresh>
    c137:	48 8d b4 24 50 03 00 	lea    0x350(%rsp),%rsi
    c13e:	00 
    c13f:	bf 01 00 00 00       	mov    $0x1,%edi
    c144:	4c 89 a4 24 50 03 00 	mov    %r12,0x350(%rsp)
    c14b:	00 
    c14c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
    c153:	00 
    c154:	e8 a7 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c159:	48 89 c7             	mov    %rax,%rdi
    c15c:	e8 0f ac ff ff       	call   6d70 <fwp_rc_fresh>
    c161:	48 8d b4 24 60 03 00 	lea    0x360(%rsp),%rsi
    c168:	00 
    c169:	bf 01 00 00 00       	mov    $0x1,%edi
    c16e:	4c 89 ac 24 60 03 00 	mov    %r13,0x360(%rsp)
    c175:	00 
    c176:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
    c17d:	00 
    c17e:	e8 7d 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c183:	48 89 c7             	mov    %rax,%rdi
    c186:	e8 e5 ab ff ff       	call   6d70 <fwp_rc_fresh>
    c18b:	48 8d b4 24 70 03 00 	lea    0x370(%rsp),%rsi
    c192:	00 
    c193:	bf 01 00 00 00       	mov    $0x1,%edi
    c198:	4c 89 a4 24 70 03 00 	mov    %r12,0x370(%rsp)
    c19f:	00 
    c1a0:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
    c1a7:	00 
    c1a8:	e8 53 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1ad:	48 89 c7             	mov    %rax,%rdi
    c1b0:	e8 bb ab ff ff       	call   6d70 <fwp_rc_fresh>
    c1b5:	48 8d b4 24 80 03 00 	lea    0x380(%rsp),%rsi
    c1bc:	00 
    c1bd:	bf 01 00 00 00       	mov    $0x1,%edi
    c1c2:	4c 89 ac 24 80 03 00 	mov    %r13,0x380(%rsp)
    c1c9:	00 
    c1ca:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
    c1d1:	00 
    c1d2:	e8 29 9f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c1d7:	48 89 c7             	mov    %rax,%rdi
    c1da:	e8 91 ab ff ff       	call   6d70 <fwp_rc_fresh>
    c1df:	48 8d b4 24 90 03 00 	lea    0x390(%rsp),%rsi
    c1e6:	00 
    c1e7:	bf 01 00 00 00       	mov    $0x1,%edi
    c1ec:	4c 89 a4 24 90 03 00 	mov    %r12,0x390(%rsp)
    c1f3:	00 
    c1f4:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
    c1fb:	00 
    c1fc:	e8 ff 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c201:	48 89 c7             	mov    %rax,%rdi
    c204:	e8 67 ab ff ff       	call   6d70 <fwp_rc_fresh>
    c209:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
    c210:	00 
    c211:	bf 01 00 00 00       	mov    $0x1,%edi
    c216:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
    c21d:	00 
    c21e:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
    c225:	00 
    c226:	e8 d5 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c22b:	48 89 c7             	mov    %rax,%rdi
    c22e:	e8 3d ab ff ff       	call   6d70 <fwp_rc_fresh>
    c233:	48 8d b4 24 b0 03 00 	lea    0x3b0(%rsp),%rsi
    c23a:	00 
    c23b:	bf 01 00 00 00       	mov    $0x1,%edi
    c240:	4c 89 a4 24 b0 03 00 	mov    %r12,0x3b0(%rsp)
    c247:	00 
    c248:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
    c24f:	00 
    c250:	e8 ab 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c255:	48 89 c7             	mov    %rax,%rdi
    c258:	e8 13 ab ff ff       	call   6d70 <fwp_rc_fresh>
    c25d:	48 8d b4 24 c0 03 00 	lea    0x3c0(%rsp),%rsi
    c264:	00 
    c265:	bf 01 00 00 00       	mov    $0x1,%edi
    c26a:	4c 89 ac 24 c0 03 00 	mov    %r13,0x3c0(%rsp)
    c271:	00 
    c272:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
    c279:	00 
    c27a:	e8 81 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c27f:	48 89 c7             	mov    %rax,%rdi
    c282:	e8 e9 aa ff ff       	call   6d70 <fwp_rc_fresh>
    c287:	48 8d b4 24 d0 03 00 	lea    0x3d0(%rsp),%rsi
    c28e:	00 
    c28f:	bf 01 00 00 00       	mov    $0x1,%edi
    c294:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
    c29b:	00 
    c29c:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
    c2a3:	00 
    c2a4:	e8 57 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2a9:	48 89 c7             	mov    %rax,%rdi
    c2ac:	e8 bf aa ff ff       	call   6d70 <fwp_rc_fresh>
    c2b1:	48 8d b4 24 e0 03 00 	lea    0x3e0(%rsp),%rsi
    c2b8:	00 
    c2b9:	bf 01 00 00 00       	mov    $0x1,%edi
    c2be:	4c 89 ac 24 e0 03 00 	mov    %r13,0x3e0(%rsp)
    c2c5:	00 
    c2c6:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
    c2cd:	00 
    c2ce:	e8 2d 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2d3:	48 89 c7             	mov    %rax,%rdi
    c2d6:	e8 95 aa ff ff       	call   6d70 <fwp_rc_fresh>
    c2db:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
    c2e2:	00 
    c2e3:	bf 01 00 00 00       	mov    $0x1,%edi
    c2e8:	4c 89 a4 24 f0 03 00 	mov    %r12,0x3f0(%rsp)
    c2ef:	00 
    c2f0:	48 89 84 24 f8 03 00 	mov    %rax,0x3f8(%rsp)
    c2f7:	00 
    c2f8:	e8 03 9e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c2fd:	48 89 c7             	mov    %rax,%rdi
    c300:	e8 6b aa ff ff       	call   6d70 <fwp_rc_fresh>
    c305:	48 8d b4 24 00 04 00 	lea    0x400(%rsp),%rsi
    c30c:	00 
    c30d:	bf 01 00 00 00       	mov    $0x1,%edi
    c312:	4c 89 ac 24 00 04 00 	mov    %r13,0x400(%rsp)
    c319:	00 
    c31a:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
    c321:	00 
    c322:	e8 d9 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c327:	48 89 c7             	mov    %rax,%rdi
    c32a:	e8 41 aa ff ff       	call   6d70 <fwp_rc_fresh>
    c32f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
    c336:	00 
    c337:	bf 01 00 00 00       	mov    $0x1,%edi
    c33c:	4c 89 a4 24 10 04 00 	mov    %r12,0x410(%rsp)
    c343:	00 
    c344:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
    c34b:	00 
    c34c:	e8 af 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c351:	48 89 c7             	mov    %rax,%rdi
    c354:	e8 17 aa ff ff       	call   6d70 <fwp_rc_fresh>
    c359:	48 8d b4 24 20 04 00 	lea    0x420(%rsp),%rsi
    c360:	00 
    c361:	bf 01 00 00 00       	mov    $0x1,%edi
    c366:	4c 89 ac 24 20 04 00 	mov    %r13,0x420(%rsp)
    c36d:	00 
    c36e:	48 89 84 24 28 04 00 	mov    %rax,0x428(%rsp)
    c375:	00 
    c376:	e8 85 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c37b:	48 89 c7             	mov    %rax,%rdi
    c37e:	e8 ed a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c383:	48 8d b4 24 30 04 00 	lea    0x430(%rsp),%rsi
    c38a:	00 
    c38b:	bf 01 00 00 00       	mov    $0x1,%edi
    c390:	4c 89 a4 24 30 04 00 	mov    %r12,0x430(%rsp)
    c397:	00 
    c398:	48 89 84 24 38 04 00 	mov    %rax,0x438(%rsp)
    c39f:	00 
    c3a0:	e8 5b 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3a5:	48 89 c7             	mov    %rax,%rdi
    c3a8:	e8 c3 a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c3ad:	48 8d b4 24 40 04 00 	lea    0x440(%rsp),%rsi
    c3b4:	00 
    c3b5:	bf 01 00 00 00       	mov    $0x1,%edi
    c3ba:	4c 89 ac 24 40 04 00 	mov    %r13,0x440(%rsp)
    c3c1:	00 
    c3c2:	48 89 84 24 48 04 00 	mov    %rax,0x448(%rsp)
    c3c9:	00 
    c3ca:	e8 31 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3cf:	48 89 c7             	mov    %rax,%rdi
    c3d2:	e8 99 a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c3d7:	48 8d b4 24 50 04 00 	lea    0x450(%rsp),%rsi
    c3de:	00 
    c3df:	bf 01 00 00 00       	mov    $0x1,%edi
    c3e4:	4c 89 a4 24 50 04 00 	mov    %r12,0x450(%rsp)
    c3eb:	00 
    c3ec:	48 89 84 24 58 04 00 	mov    %rax,0x458(%rsp)
    c3f3:	00 
    c3f4:	e8 07 9d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c3f9:	48 89 c7             	mov    %rax,%rdi
    c3fc:	e8 6f a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c401:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
    c408:	00 
    c409:	bf 01 00 00 00       	mov    $0x1,%edi
    c40e:	4c 89 ac 24 60 04 00 	mov    %r13,0x460(%rsp)
    c415:	00 
    c416:	48 89 84 24 68 04 00 	mov    %rax,0x468(%rsp)
    c41d:	00 
    c41e:	e8 dd 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c423:	48 89 c7             	mov    %rax,%rdi
    c426:	e8 45 a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c42b:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
    c432:	00 
    c433:	bf 01 00 00 00       	mov    $0x1,%edi
    c438:	4c 89 a4 24 70 04 00 	mov    %r12,0x470(%rsp)
    c43f:	00 
    c440:	48 89 84 24 78 04 00 	mov    %rax,0x478(%rsp)
    c447:	00 
    c448:	e8 b3 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c44d:	48 89 c7             	mov    %rax,%rdi
    c450:	e8 1b a9 ff ff       	call   6d70 <fwp_rc_fresh>
    c455:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
    c45c:	00 
    c45d:	bf 01 00 00 00       	mov    $0x1,%edi
    c462:	4c 89 ac 24 80 04 00 	mov    %r13,0x480(%rsp)
    c469:	00 
    c46a:	48 89 84 24 88 04 00 	mov    %rax,0x488(%rsp)
    c471:	00 
    c472:	e8 89 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c477:	48 89 c7             	mov    %rax,%rdi
    c47a:	e8 f1 a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c47f:	48 8d b4 24 90 04 00 	lea    0x490(%rsp),%rsi
    c486:	00 
    c487:	bf 01 00 00 00       	mov    $0x1,%edi
    c48c:	4c 89 a4 24 90 04 00 	mov    %r12,0x490(%rsp)
    c493:	00 
    c494:	48 89 84 24 98 04 00 	mov    %rax,0x498(%rsp)
    c49b:	00 
    c49c:	e8 5f 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4a1:	48 89 c7             	mov    %rax,%rdi
    c4a4:	e8 c7 a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c4a9:	48 8d b4 24 a0 04 00 	lea    0x4a0(%rsp),%rsi
    c4b0:	00 
    c4b1:	bf 01 00 00 00       	mov    $0x1,%edi
    c4b6:	4c 89 ac 24 a0 04 00 	mov    %r13,0x4a0(%rsp)
    c4bd:	00 
    c4be:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
    c4c5:	00 
    c4c6:	e8 35 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4cb:	48 89 c7             	mov    %rax,%rdi
    c4ce:	e8 9d a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c4d3:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
    c4da:	00 
    c4db:	bf 01 00 00 00       	mov    $0x1,%edi
    c4e0:	4c 89 a4 24 b0 04 00 	mov    %r12,0x4b0(%rsp)
    c4e7:	00 
    c4e8:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
    c4ef:	00 
    c4f0:	e8 0b 9c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c4f5:	48 89 c7             	mov    %rax,%rdi
    c4f8:	e8 73 a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c4fd:	48 8d b4 24 c0 04 00 	lea    0x4c0(%rsp),%rsi
    c504:	00 
    c505:	bf 01 00 00 00       	mov    $0x1,%edi
    c50a:	4c 89 ac 24 c0 04 00 	mov    %r13,0x4c0(%rsp)
    c511:	00 
    c512:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
    c519:	00 
    c51a:	e8 e1 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c51f:	48 89 c7             	mov    %rax,%rdi
    c522:	e8 49 a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c527:	48 8d b4 24 d0 04 00 	lea    0x4d0(%rsp),%rsi
    c52e:	00 
    c52f:	bf 01 00 00 00       	mov    $0x1,%edi
    c534:	4c 89 a4 24 d0 04 00 	mov    %r12,0x4d0(%rsp)
    c53b:	00 
    c53c:	48 89 84 24 d8 04 00 	mov    %rax,0x4d8(%rsp)
    c543:	00 
    c544:	e8 b7 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c549:	48 89 c7             	mov    %rax,%rdi
    c54c:	e8 1f a8 ff ff       	call   6d70 <fwp_rc_fresh>
    c551:	48 8d b4 24 e0 04 00 	lea    0x4e0(%rsp),%rsi
    c558:	00 
    c559:	bf 01 00 00 00       	mov    $0x1,%edi
    c55e:	4c 89 ac 24 e0 04 00 	mov    %r13,0x4e0(%rsp)
    c565:	00 
    c566:	48 89 84 24 e8 04 00 	mov    %rax,0x4e8(%rsp)
    c56d:	00 
    c56e:	e8 8d 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c573:	48 89 c7             	mov    %rax,%rdi
    c576:	e8 f5 a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c57b:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
    c582:	00 
    c583:	bf 01 00 00 00       	mov    $0x1,%edi
    c588:	4c 89 a4 24 f0 04 00 	mov    %r12,0x4f0(%rsp)
    c58f:	00 
    c590:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
    c597:	00 
    c598:	e8 63 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c59d:	48 89 c7             	mov    %rax,%rdi
    c5a0:	e8 cb a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c5a5:	48 8d b4 24 00 05 00 	lea    0x500(%rsp),%rsi
    c5ac:	00 
    c5ad:	bf 01 00 00 00       	mov    $0x1,%edi
    c5b2:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
    c5b9:	00 
    c5ba:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
    c5c1:	00 
    c5c2:	e8 39 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c5c7:	48 89 c7             	mov    %rax,%rdi
    c5ca:	e8 a1 a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c5cf:	48 8d b4 24 10 05 00 	lea    0x510(%rsp),%rsi
    c5d6:	00 
    c5d7:	bf 01 00 00 00       	mov    $0x1,%edi
    c5dc:	4c 89 a4 24 10 05 00 	mov    %r12,0x510(%rsp)
    c5e3:	00 
    c5e4:	48 89 84 24 18 05 00 	mov    %rax,0x518(%rsp)
    c5eb:	00 
    c5ec:	e8 0f 9b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c5f1:	48 89 c7             	mov    %rax,%rdi
    c5f4:	e8 77 a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c5f9:	48 8d b4 24 20 05 00 	lea    0x520(%rsp),%rsi
    c600:	00 
    c601:	bf 01 00 00 00       	mov    $0x1,%edi
    c606:	4c 89 ac 24 20 05 00 	mov    %r13,0x520(%rsp)
    c60d:	00 
    c60e:	48 89 84 24 28 05 00 	mov    %rax,0x528(%rsp)
    c615:	00 
    c616:	e8 e5 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c61b:	48 89 c7             	mov    %rax,%rdi
    c61e:	e8 4d a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c623:	48 8d b4 24 30 05 00 	lea    0x530(%rsp),%rsi
    c62a:	00 
    c62b:	bf 01 00 00 00       	mov    $0x1,%edi
    c630:	4c 89 a4 24 30 05 00 	mov    %r12,0x530(%rsp)
    c637:	00 
    c638:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
    c63f:	00 
    c640:	e8 bb 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c645:	48 89 c7             	mov    %rax,%rdi
    c648:	e8 23 a7 ff ff       	call   6d70 <fwp_rc_fresh>
    c64d:	48 8d b4 24 40 05 00 	lea    0x540(%rsp),%rsi
    c654:	00 
    c655:	bf 01 00 00 00       	mov    $0x1,%edi
    c65a:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
    c661:	00 
    c662:	48 89 84 24 48 05 00 	mov    %rax,0x548(%rsp)
    c669:	00 
    c66a:	e8 91 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c66f:	48 89 c7             	mov    %rax,%rdi
    c672:	e8 f9 a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c677:	48 8d b4 24 50 05 00 	lea    0x550(%rsp),%rsi
    c67e:	00 
    c67f:	bf 01 00 00 00       	mov    $0x1,%edi
    c684:	4c 89 a4 24 50 05 00 	mov    %r12,0x550(%rsp)
    c68b:	00 
    c68c:	48 89 84 24 58 05 00 	mov    %rax,0x558(%rsp)
    c693:	00 
    c694:	e8 67 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c699:	48 89 c7             	mov    %rax,%rdi
    c69c:	e8 cf a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c6a1:	48 8d b4 24 60 05 00 	lea    0x560(%rsp),%rsi
    c6a8:	00 
    c6a9:	bf 01 00 00 00       	mov    $0x1,%edi
    c6ae:	4c 89 ac 24 60 05 00 	mov    %r13,0x560(%rsp)
    c6b5:	00 
    c6b6:	48 89 84 24 68 05 00 	mov    %rax,0x568(%rsp)
    c6bd:	00 
    c6be:	e8 3d 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c6c3:	48 89 c7             	mov    %rax,%rdi
    c6c6:	e8 a5 a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c6cb:	48 8d b4 24 70 05 00 	lea    0x570(%rsp),%rsi
    c6d2:	00 
    c6d3:	bf 01 00 00 00       	mov    $0x1,%edi
    c6d8:	4c 89 a4 24 70 05 00 	mov    %r12,0x570(%rsp)
    c6df:	00 
    c6e0:	48 89 84 24 78 05 00 	mov    %rax,0x578(%rsp)
    c6e7:	00 
    c6e8:	e8 13 9a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c6ed:	48 89 c7             	mov    %rax,%rdi
    c6f0:	e8 7b a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c6f5:	48 8d b4 24 80 05 00 	lea    0x580(%rsp),%rsi
    c6fc:	00 
    c6fd:	bf 01 00 00 00       	mov    $0x1,%edi
    c702:	4c 89 ac 24 80 05 00 	mov    %r13,0x580(%rsp)
    c709:	00 
    c70a:	48 89 84 24 88 05 00 	mov    %rax,0x588(%rsp)
    c711:	00 
    c712:	e8 e9 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c717:	48 89 c7             	mov    %rax,%rdi
    c71a:	e8 51 a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c71f:	48 8d b4 24 90 05 00 	lea    0x590(%rsp),%rsi
    c726:	00 
    c727:	bf 01 00 00 00       	mov    $0x1,%edi
    c72c:	4c 89 a4 24 90 05 00 	mov    %r12,0x590(%rsp)
    c733:	00 
    c734:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
    c73b:	00 
    c73c:	e8 bf 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c741:	48 89 c7             	mov    %rax,%rdi
    c744:	e8 27 a6 ff ff       	call   6d70 <fwp_rc_fresh>
    c749:	48 8d b4 24 a0 05 00 	lea    0x5a0(%rsp),%rsi
    c750:	00 
    c751:	bf 01 00 00 00       	mov    $0x1,%edi
    c756:	4c 89 ac 24 a0 05 00 	mov    %r13,0x5a0(%rsp)
    c75d:	00 
    c75e:	48 89 84 24 a8 05 00 	mov    %rax,0x5a8(%rsp)
    c765:	00 
    c766:	e8 95 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c76b:	48 89 c7             	mov    %rax,%rdi
    c76e:	e8 fd a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c773:	48 8d b4 24 b0 05 00 	lea    0x5b0(%rsp),%rsi
    c77a:	00 
    c77b:	bf 01 00 00 00       	mov    $0x1,%edi
    c780:	4c 89 a4 24 b0 05 00 	mov    %r12,0x5b0(%rsp)
    c787:	00 
    c788:	48 89 84 24 b8 05 00 	mov    %rax,0x5b8(%rsp)
    c78f:	00 
    c790:	e8 6b 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c795:	48 89 c7             	mov    %rax,%rdi
    c798:	e8 d3 a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c79d:	48 8d b4 24 c0 05 00 	lea    0x5c0(%rsp),%rsi
    c7a4:	00 
    c7a5:	bf 01 00 00 00       	mov    $0x1,%edi
    c7aa:	4c 89 ac 24 c0 05 00 	mov    %r13,0x5c0(%rsp)
    c7b1:	00 
    c7b2:	48 89 84 24 c8 05 00 	mov    %rax,0x5c8(%rsp)
    c7b9:	00 
    c7ba:	e8 41 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c7bf:	48 89 c7             	mov    %rax,%rdi
    c7c2:	e8 a9 a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c7c7:	48 8d b4 24 d0 05 00 	lea    0x5d0(%rsp),%rsi
    c7ce:	00 
    c7cf:	bf 01 00 00 00       	mov    $0x1,%edi
    c7d4:	4c 89 a4 24 d0 05 00 	mov    %r12,0x5d0(%rsp)
    c7db:	00 
    c7dc:	48 89 84 24 d8 05 00 	mov    %rax,0x5d8(%rsp)
    c7e3:	00 
    c7e4:	e8 17 99 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c7e9:	48 89 c7             	mov    %rax,%rdi
    c7ec:	e8 7f a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c7f1:	48 8d b4 24 e0 05 00 	lea    0x5e0(%rsp),%rsi
    c7f8:	00 
    c7f9:	bf 01 00 00 00       	mov    $0x1,%edi
    c7fe:	4c 89 ac 24 e0 05 00 	mov    %r13,0x5e0(%rsp)
    c805:	00 
    c806:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
    c80d:	00 
    c80e:	e8 ed 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c813:	48 89 c7             	mov    %rax,%rdi
    c816:	e8 55 a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c81b:	48 8d b4 24 f0 05 00 	lea    0x5f0(%rsp),%rsi
    c822:	00 
    c823:	bf 01 00 00 00       	mov    $0x1,%edi
    c828:	4c 89 a4 24 f0 05 00 	mov    %r12,0x5f0(%rsp)
    c82f:	00 
    c830:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
    c837:	00 
    c838:	e8 c3 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c83d:	48 89 c7             	mov    %rax,%rdi
    c840:	e8 2b a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c845:	48 8d b4 24 00 06 00 	lea    0x600(%rsp),%rsi
    c84c:	00 
    c84d:	bf 01 00 00 00       	mov    $0x1,%edi
    c852:	4c 89 ac 24 00 06 00 	mov    %r13,0x600(%rsp)
    c859:	00 
    c85a:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
    c861:	00 
    c862:	e8 99 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c867:	48 89 c7             	mov    %rax,%rdi
    c86a:	e8 01 a5 ff ff       	call   6d70 <fwp_rc_fresh>
    c86f:	48 8d b4 24 10 06 00 	lea    0x610(%rsp),%rsi
    c876:	00 
    c877:	bf 01 00 00 00       	mov    $0x1,%edi
    c87c:	4c 89 a4 24 10 06 00 	mov    %r12,0x610(%rsp)
    c883:	00 
    c884:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
    c88b:	00 
    c88c:	e8 6f 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c891:	48 89 c7             	mov    %rax,%rdi
    c894:	e8 d7 a4 ff ff       	call   6d70 <fwp_rc_fresh>
    c899:	48 8d b4 24 20 06 00 	lea    0x620(%rsp),%rsi
    c8a0:	00 
    c8a1:	bf 01 00 00 00       	mov    $0x1,%edi
    c8a6:	4c 89 ac 24 20 06 00 	mov    %r13,0x620(%rsp)
    c8ad:	00 
    c8ae:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
    c8b5:	00 
    c8b6:	e8 45 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c8bb:	48 89 c7             	mov    %rax,%rdi
    c8be:	e8 ad a4 ff ff       	call   6d70 <fwp_rc_fresh>
    c8c3:	48 8d b4 24 30 06 00 	lea    0x630(%rsp),%rsi
    c8ca:	00 
    c8cb:	bf 01 00 00 00       	mov    $0x1,%edi
    c8d0:	4c 89 a4 24 30 06 00 	mov    %r12,0x630(%rsp)
    c8d7:	00 
    c8d8:	48 89 84 24 38 06 00 	mov    %rax,0x638(%rsp)
    c8df:	00 
    c8e0:	e8 1b 98 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c8e5:	48 8b 15 0c 03 06 00 	mov    0x6030c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c8ec:	49 89 c5             	mov    %rax,%r13
    c8ef:	48 2b 05 da 02 06 00 	sub    0x602da(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c8f6:	48 c1 e2 10          	shl    $0x10,%rdx
    c8fa:	48 39 d0             	cmp    %rdx,%rax
    c8fd:	73 59                	jae    c958 <f0+0x13b8>
    c8ff:	48 89 c2             	mov    %rax,%rdx
    c902:	48 c1 ea 10          	shr    $0x10,%rdx
    c906:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c90a:	48 8b 15 07 03 06 00 	mov    0x60307(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c911:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c915:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c919:	4d 85 e4             	test   %r12,%r12
    c91c:	74 3a                	je     c958 <f0+0x13b8>
    c91e:	0f b6 0a             	movzbl (%rdx),%ecx
    c921:	80 f9 02             	cmp    $0x2,%cl
    c924:	0f 84 c6 15 00 00    	je     def0 <f0+0x2950>
    c92a:	80 f9 01             	cmp    $0x1,%cl
    c92d:	75 29                	jne    c958 <f0+0x13b8>
    c92f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c932:	0f b7 c0             	movzwl %ax,%eax
    c935:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c938:	48 0f af c1          	imul   %rcx,%rax
    c93c:	48 c1 e8 20          	shr    $0x20,%rax
    c940:	48 39 d0             	cmp    %rdx,%rax
    c943:	73 13                	jae    c958 <f0+0x13b8>
    c945:	49 01 c4             	add    %rax,%r12
    c948:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c94d:	0f 84 99 17 00 00    	je     e0ec <f0+0x2b4c>
    c953:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c958:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    c95f:	33 f3 bf 
    c962:	48 8d b4 24 40 06 00 	lea    0x640(%rsp),%rsi
    c969:	00 
    c96a:	bf 01 00 00 00       	mov    $0x1,%edi
    c96f:	4c 89 ac 24 48 06 00 	mov    %r13,0x648(%rsp)
    c976:	00 
    c977:	48 89 84 24 40 06 00 	mov    %rax,0x640(%rsp)
    c97e:	00 
    c97f:	e8 7c 97 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    c984:	48 8b 15 6d 02 06 00 	mov    0x6026d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    c98b:	49 89 c5             	mov    %rax,%r13
    c98e:	48 2b 05 3b 02 06 00 	sub    0x6023b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    c995:	48 c1 e2 10          	shl    $0x10,%rdx
    c999:	48 39 d0             	cmp    %rdx,%rax
    c99c:	73 59                	jae    c9f7 <f0+0x1457>
    c99e:	48 89 c2             	mov    %rax,%rdx
    c9a1:	48 c1 ea 10          	shr    $0x10,%rdx
    c9a5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c9a9:	48 8b 15 68 02 06 00 	mov    0x60268(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    c9b0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c9b4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    c9b8:	4d 85 e4             	test   %r12,%r12
    c9bb:	74 3a                	je     c9f7 <f0+0x1457>
    c9bd:	0f b6 0a             	movzbl (%rdx),%ecx
    c9c0:	80 f9 02             	cmp    $0x2,%cl
    c9c3:	0f 84 17 15 00 00    	je     dee0 <f0+0x2940>
    c9c9:	80 f9 01             	cmp    $0x1,%cl
    c9cc:	75 29                	jne    c9f7 <f0+0x1457>
    c9ce:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c9d1:	0f b7 c0             	movzwl %ax,%eax
    c9d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c9d7:	48 0f af c1          	imul   %rcx,%rax
    c9db:	48 c1 e8 20          	shr    $0x20,%rax
    c9df:	48 39 d0             	cmp    %rdx,%rax
    c9e2:	73 13                	jae    c9f7 <f0+0x1457>
    c9e4:	49 01 c4             	add    %rax,%r12
    c9e7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    c9ec:	0f 84 07 17 00 00    	je     e0f9 <f0+0x2b59>
    c9f2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    c9f7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    c9fe:	00 f0 3f 
    ca01:	48 8d b4 24 50 06 00 	lea    0x650(%rsp),%rsi
    ca08:	00 
    ca09:	bf 01 00 00 00       	mov    $0x1,%edi
    ca0e:	4c 89 ac 24 58 06 00 	mov    %r13,0x658(%rsp)
    ca15:	00 
    ca16:	48 89 84 24 50 06 00 	mov    %rax,0x650(%rsp)
    ca1d:	00 
    ca1e:	e8 dd 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ca23:	48 8b 15 ce 01 06 00 	mov    0x601ce(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ca2a:	49 89 c5             	mov    %rax,%r13
    ca2d:	48 2b 05 9c 01 06 00 	sub    0x6019c(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ca34:	48 c1 e2 10          	shl    $0x10,%rdx
    ca38:	48 39 d0             	cmp    %rdx,%rax
    ca3b:	73 59                	jae    ca96 <f0+0x14f6>
    ca3d:	48 89 c2             	mov    %rax,%rdx
    ca40:	48 c1 ea 10          	shr    $0x10,%rdx
    ca44:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ca48:	48 8b 15 c9 01 06 00 	mov    0x601c9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ca4f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ca53:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ca57:	4d 85 e4             	test   %r12,%r12
    ca5a:	74 3a                	je     ca96 <f0+0x14f6>
    ca5c:	0f b6 0a             	movzbl (%rdx),%ecx
    ca5f:	80 f9 02             	cmp    $0x2,%cl
    ca62:	0f 84 28 15 00 00    	je     df90 <f0+0x29f0>
    ca68:	80 f9 01             	cmp    $0x1,%cl
    ca6b:	75 29                	jne    ca96 <f0+0x14f6>
    ca6d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ca70:	0f b7 c0             	movzwl %ax,%eax
    ca73:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ca76:	48 0f af c1          	imul   %rcx,%rax
    ca7a:	48 c1 e8 20          	shr    $0x20,%rax
    ca7e:	48 39 d0             	cmp    %rdx,%rax
    ca81:	73 13                	jae    ca96 <f0+0x14f6>
    ca83:	49 01 c4             	add    %rax,%r12
    ca86:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ca8b:	0f 84 75 16 00 00    	je     e106 <f0+0x2b66>
    ca91:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ca96:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ca9d:	33 f3 bf 
    caa0:	48 8d b4 24 60 06 00 	lea    0x660(%rsp),%rsi
    caa7:	00 
    caa8:	bf 01 00 00 00       	mov    $0x1,%edi
    caad:	4c 89 ac 24 68 06 00 	mov    %r13,0x668(%rsp)
    cab4:	00 
    cab5:	48 89 84 24 60 06 00 	mov    %rax,0x660(%rsp)
    cabc:	00 
    cabd:	e8 3e 96 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cac2:	48 8b 15 2f 01 06 00 	mov    0x6012f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cac9:	49 89 c5             	mov    %rax,%r13
    cacc:	48 2b 05 fd 00 06 00 	sub    0x600fd(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cad3:	48 c1 e2 10          	shl    $0x10,%rdx
    cad7:	48 39 d0             	cmp    %rdx,%rax
    cada:	73 59                	jae    cb35 <f0+0x1595>
    cadc:	48 89 c2             	mov    %rax,%rdx
    cadf:	48 c1 ea 10          	shr    $0x10,%rdx
    cae3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cae7:	48 8b 15 2a 01 06 00 	mov    0x6012a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    caee:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    caf2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    caf6:	4d 85 e4             	test   %r12,%r12
    caf9:	74 3a                	je     cb35 <f0+0x1595>
    cafb:	0f b6 0a             	movzbl (%rdx),%ecx
    cafe:	80 f9 02             	cmp    $0x2,%cl
    cb01:	0f 84 79 14 00 00    	je     df80 <f0+0x29e0>
    cb07:	80 f9 01             	cmp    $0x1,%cl
    cb0a:	75 29                	jne    cb35 <f0+0x1595>
    cb0c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cb0f:	0f b7 c0             	movzwl %ax,%eax
    cb12:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cb15:	48 0f af c1          	imul   %rcx,%rax
    cb19:	48 c1 e8 20          	shr    $0x20,%rax
    cb1d:	48 39 d0             	cmp    %rdx,%rax
    cb20:	73 13                	jae    cb35 <f0+0x1595>
    cb22:	49 01 c4             	add    %rax,%r12
    cb25:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cb2a:	0f 84 e3 15 00 00    	je     e113 <f0+0x2b73>
    cb30:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cb35:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cb3c:	00 f0 3f 
    cb3f:	48 8d b4 24 70 06 00 	lea    0x670(%rsp),%rsi
    cb46:	00 
    cb47:	bf 01 00 00 00       	mov    $0x1,%edi
    cb4c:	4c 89 ac 24 78 06 00 	mov    %r13,0x678(%rsp)
    cb53:	00 
    cb54:	48 89 84 24 70 06 00 	mov    %rax,0x670(%rsp)
    cb5b:	00 
    cb5c:	e8 9f 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cb61:	48 8b 15 90 00 06 00 	mov    0x60090(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cb68:	49 89 c5             	mov    %rax,%r13
    cb6b:	48 2b 05 5e 00 06 00 	sub    0x6005e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cb72:	48 c1 e2 10          	shl    $0x10,%rdx
    cb76:	48 39 d0             	cmp    %rdx,%rax
    cb79:	73 59                	jae    cbd4 <f0+0x1634>
    cb7b:	48 89 c2             	mov    %rax,%rdx
    cb7e:	48 c1 ea 10          	shr    $0x10,%rdx
    cb82:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cb86:	48 8b 15 8b 00 06 00 	mov    0x6008b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cb8d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cb91:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cb95:	4d 85 e4             	test   %r12,%r12
    cb98:	74 3a                	je     cbd4 <f0+0x1634>
    cb9a:	0f b6 0a             	movzbl (%rdx),%ecx
    cb9d:	80 f9 02             	cmp    $0x2,%cl
    cba0:	0f 84 ca 13 00 00    	je     df70 <f0+0x29d0>
    cba6:	80 f9 01             	cmp    $0x1,%cl
    cba9:	75 29                	jne    cbd4 <f0+0x1634>
    cbab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cbae:	0f b7 c0             	movzwl %ax,%eax
    cbb1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cbb4:	48 0f af c1          	imul   %rcx,%rax
    cbb8:	48 c1 e8 20          	shr    $0x20,%rax
    cbbc:	48 39 d0             	cmp    %rdx,%rax
    cbbf:	73 13                	jae    cbd4 <f0+0x1634>
    cbc1:	49 01 c4             	add    %rax,%r12
    cbc4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cbc9:	0f 84 51 15 00 00    	je     e120 <f0+0x2b80>
    cbcf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cbd4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cbdb:	33 f3 bf 
    cbde:	48 8d b4 24 80 06 00 	lea    0x680(%rsp),%rsi
    cbe5:	00 
    cbe6:	bf 01 00 00 00       	mov    $0x1,%edi
    cbeb:	4c 89 ac 24 88 06 00 	mov    %r13,0x688(%rsp)
    cbf2:	00 
    cbf3:	48 89 84 24 80 06 00 	mov    %rax,0x680(%rsp)
    cbfa:	00 
    cbfb:	e8 00 95 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cc00:	48 8b 15 f1 ff 05 00 	mov    0x5fff1(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cc07:	49 89 c5             	mov    %rax,%r13
    cc0a:	48 2b 05 bf ff 05 00 	sub    0x5ffbf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cc11:	48 c1 e2 10          	shl    $0x10,%rdx
    cc15:	48 39 d0             	cmp    %rdx,%rax
    cc18:	73 59                	jae    cc73 <f0+0x16d3>
    cc1a:	48 89 c2             	mov    %rax,%rdx
    cc1d:	48 c1 ea 10          	shr    $0x10,%rdx
    cc21:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cc25:	48 8b 15 ec ff 05 00 	mov    0x5ffec(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cc2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cc30:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cc34:	4d 85 e4             	test   %r12,%r12
    cc37:	74 3a                	je     cc73 <f0+0x16d3>
    cc39:	0f b6 0a             	movzbl (%rdx),%ecx
    cc3c:	80 f9 02             	cmp    $0x2,%cl
    cc3f:	0f 84 1b 13 00 00    	je     df60 <f0+0x29c0>
    cc45:	80 f9 01             	cmp    $0x1,%cl
    cc48:	75 29                	jne    cc73 <f0+0x16d3>
    cc4a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cc4d:	0f b7 c0             	movzwl %ax,%eax
    cc50:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cc53:	48 0f af c1          	imul   %rcx,%rax
    cc57:	48 c1 e8 20          	shr    $0x20,%rax
    cc5b:	48 39 d0             	cmp    %rdx,%rax
    cc5e:	73 13                	jae    cc73 <f0+0x16d3>
    cc60:	49 01 c4             	add    %rax,%r12
    cc63:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cc68:	0f 84 bf 14 00 00    	je     e12d <f0+0x2b8d>
    cc6e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cc73:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cc7a:	00 f0 3f 
    cc7d:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
    cc84:	00 
    cc85:	bf 01 00 00 00       	mov    $0x1,%edi
    cc8a:	4c 89 ac 24 98 06 00 	mov    %r13,0x698(%rsp)
    cc91:	00 
    cc92:	48 89 84 24 90 06 00 	mov    %rax,0x690(%rsp)
    cc99:	00 
    cc9a:	e8 61 94 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cc9f:	48 8b 15 52 ff 05 00 	mov    0x5ff52(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cca6:	49 89 c5             	mov    %rax,%r13
    cca9:	48 2b 05 20 ff 05 00 	sub    0x5ff20(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ccb0:	48 c1 e2 10          	shl    $0x10,%rdx
    ccb4:	48 39 d0             	cmp    %rdx,%rax
    ccb7:	73 59                	jae    cd12 <f0+0x1772>
    ccb9:	48 89 c2             	mov    %rax,%rdx
    ccbc:	48 c1 ea 10          	shr    $0x10,%rdx
    ccc0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ccc4:	48 8b 15 4d ff 05 00 	mov    0x5ff4d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cccb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cccf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ccd3:	4d 85 e4             	test   %r12,%r12
    ccd6:	74 3a                	je     cd12 <f0+0x1772>
    ccd8:	0f b6 0a             	movzbl (%rdx),%ecx
    ccdb:	80 f9 02             	cmp    $0x2,%cl
    ccde:	0f 84 6c 12 00 00    	je     df50 <f0+0x29b0>
    cce4:	80 f9 01             	cmp    $0x1,%cl
    cce7:	75 29                	jne    cd12 <f0+0x1772>
    cce9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ccec:	0f b7 c0             	movzwl %ax,%eax
    ccef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ccf2:	48 0f af c1          	imul   %rcx,%rax
    ccf6:	48 c1 e8 20          	shr    $0x20,%rax
    ccfa:	48 39 d0             	cmp    %rdx,%rax
    ccfd:	73 13                	jae    cd12 <f0+0x1772>
    ccff:	49 01 c4             	add    %rax,%r12
    cd02:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cd07:	0f 84 2d 14 00 00    	je     e13a <f0+0x2b9a>
    cd0d:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cd12:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cd19:	33 f3 bf 
    cd1c:	48 8d b4 24 a0 06 00 	lea    0x6a0(%rsp),%rsi
    cd23:	00 
    cd24:	bf 01 00 00 00       	mov    $0x1,%edi
    cd29:	4c 89 ac 24 a8 06 00 	mov    %r13,0x6a8(%rsp)
    cd30:	00 
    cd31:	48 89 84 24 a0 06 00 	mov    %rax,0x6a0(%rsp)
    cd38:	00 
    cd39:	e8 c2 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cd3e:	48 8b 15 b3 fe 05 00 	mov    0x5feb3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cd45:	49 89 c5             	mov    %rax,%r13
    cd48:	48 2b 05 81 fe 05 00 	sub    0x5fe81(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cd4f:	48 c1 e2 10          	shl    $0x10,%rdx
    cd53:	48 39 d0             	cmp    %rdx,%rax
    cd56:	73 59                	jae    cdb1 <f0+0x1811>
    cd58:	48 89 c2             	mov    %rax,%rdx
    cd5b:	48 c1 ea 10          	shr    $0x10,%rdx
    cd5f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cd63:	48 8b 15 ae fe 05 00 	mov    0x5feae(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cd6a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cd6e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cd72:	4d 85 e4             	test   %r12,%r12
    cd75:	74 3a                	je     cdb1 <f0+0x1811>
    cd77:	0f b6 0a             	movzbl (%rdx),%ecx
    cd7a:	80 f9 02             	cmp    $0x2,%cl
    cd7d:	0f 84 bd 11 00 00    	je     df40 <f0+0x29a0>
    cd83:	80 f9 01             	cmp    $0x1,%cl
    cd86:	75 29                	jne    cdb1 <f0+0x1811>
    cd88:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cd8b:	0f b7 c0             	movzwl %ax,%eax
    cd8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cd91:	48 0f af c1          	imul   %rcx,%rax
    cd95:	48 c1 e8 20          	shr    $0x20,%rax
    cd99:	48 39 d0             	cmp    %rdx,%rax
    cd9c:	73 13                	jae    cdb1 <f0+0x1811>
    cd9e:	49 01 c4             	add    %rax,%r12
    cda1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cda6:	0f 84 9b 13 00 00    	je     e147 <f0+0x2ba7>
    cdac:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cdb1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cdb8:	00 f0 3f 
    cdbb:	48 8d b4 24 b0 06 00 	lea    0x6b0(%rsp),%rsi
    cdc2:	00 
    cdc3:	bf 01 00 00 00       	mov    $0x1,%edi
    cdc8:	4c 89 ac 24 b8 06 00 	mov    %r13,0x6b8(%rsp)
    cdcf:	00 
    cdd0:	48 89 84 24 b0 06 00 	mov    %rax,0x6b0(%rsp)
    cdd7:	00 
    cdd8:	e8 23 93 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cddd:	48 8b 15 14 fe 05 00 	mov    0x5fe14(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cde4:	49 89 c5             	mov    %rax,%r13
    cde7:	48 2b 05 e2 fd 05 00 	sub    0x5fde2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cdee:	48 c1 e2 10          	shl    $0x10,%rdx
    cdf2:	48 39 d0             	cmp    %rdx,%rax
    cdf5:	73 59                	jae    ce50 <f0+0x18b0>
    cdf7:	48 89 c2             	mov    %rax,%rdx
    cdfa:	48 c1 ea 10          	shr    $0x10,%rdx
    cdfe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ce02:	48 8b 15 0f fe 05 00 	mov    0x5fe0f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    ce09:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ce0d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ce11:	4d 85 e4             	test   %r12,%r12
    ce14:	74 3a                	je     ce50 <f0+0x18b0>
    ce16:	0f b6 0a             	movzbl (%rdx),%ecx
    ce19:	80 f9 02             	cmp    $0x2,%cl
    ce1c:	0f 84 0e 11 00 00    	je     df30 <f0+0x2990>
    ce22:	80 f9 01             	cmp    $0x1,%cl
    ce25:	75 29                	jne    ce50 <f0+0x18b0>
    ce27:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ce2a:	0f b7 c0             	movzwl %ax,%eax
    ce2d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ce30:	48 0f af c1          	imul   %rcx,%rax
    ce34:	48 c1 e8 20          	shr    $0x20,%rax
    ce38:	48 39 d0             	cmp    %rdx,%rax
    ce3b:	73 13                	jae    ce50 <f0+0x18b0>
    ce3d:	49 01 c4             	add    %rax,%r12
    ce40:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ce45:	0f 84 09 13 00 00    	je     e154 <f0+0x2bb4>
    ce4b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ce50:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    ce57:	33 f3 bf 
    ce5a:	48 8d b4 24 c0 06 00 	lea    0x6c0(%rsp),%rsi
    ce61:	00 
    ce62:	bf 01 00 00 00       	mov    $0x1,%edi
    ce67:	4c 89 ac 24 c8 06 00 	mov    %r13,0x6c8(%rsp)
    ce6e:	00 
    ce6f:	48 89 84 24 c0 06 00 	mov    %rax,0x6c0(%rsp)
    ce76:	00 
    ce77:	e8 84 92 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    ce7c:	48 8b 15 75 fd 05 00 	mov    0x5fd75(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    ce83:	49 89 c5             	mov    %rax,%r13
    ce86:	48 2b 05 43 fd 05 00 	sub    0x5fd43(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    ce8d:	48 c1 e2 10          	shl    $0x10,%rdx
    ce91:	48 39 d0             	cmp    %rdx,%rax
    ce94:	73 59                	jae    ceef <f0+0x194f>
    ce96:	48 89 c2             	mov    %rax,%rdx
    ce99:	48 c1 ea 10          	shr    $0x10,%rdx
    ce9d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cea1:	48 8b 15 70 fd 05 00 	mov    0x5fd70(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cea8:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ceac:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    ceb0:	4d 85 e4             	test   %r12,%r12
    ceb3:	74 3a                	je     ceef <f0+0x194f>
    ceb5:	0f b6 0a             	movzbl (%rdx),%ecx
    ceb8:	80 f9 02             	cmp    $0x2,%cl
    cebb:	0f 84 5f 10 00 00    	je     df20 <f0+0x2980>
    cec1:	80 f9 01             	cmp    $0x1,%cl
    cec4:	75 29                	jne    ceef <f0+0x194f>
    cec6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cec9:	0f b7 c0             	movzwl %ax,%eax
    cecc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cecf:	48 0f af c1          	imul   %rcx,%rax
    ced3:	48 c1 e8 20          	shr    $0x20,%rax
    ced7:	48 39 d0             	cmp    %rdx,%rax
    ceda:	73 13                	jae    ceef <f0+0x194f>
    cedc:	49 01 c4             	add    %rax,%r12
    cedf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cee4:	0f 84 77 12 00 00    	je     e161 <f0+0x2bc1>
    ceea:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ceef:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    cef6:	00 f0 3f 
    cef9:	48 8d b4 24 d0 06 00 	lea    0x6d0(%rsp),%rsi
    cf00:	00 
    cf01:	bf 01 00 00 00       	mov    $0x1,%edi
    cf06:	4c 89 ac 24 d8 06 00 	mov    %r13,0x6d8(%rsp)
    cf0d:	00 
    cf0e:	48 89 84 24 d0 06 00 	mov    %rax,0x6d0(%rsp)
    cf15:	00 
    cf16:	e8 e5 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cf1b:	48 8b 15 d6 fc 05 00 	mov    0x5fcd6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cf22:	49 89 c5             	mov    %rax,%r13
    cf25:	48 2b 05 a4 fc 05 00 	sub    0x5fca4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cf2c:	48 c1 e2 10          	shl    $0x10,%rdx
    cf30:	48 39 d0             	cmp    %rdx,%rax
    cf33:	73 59                	jae    cf8e <f0+0x19ee>
    cf35:	48 89 c2             	mov    %rax,%rdx
    cf38:	48 c1 ea 10          	shr    $0x10,%rdx
    cf3c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cf40:	48 8b 15 d1 fc 05 00 	mov    0x5fcd1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cf47:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cf4b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cf4f:	4d 85 e4             	test   %r12,%r12
    cf52:	74 3a                	je     cf8e <f0+0x19ee>
    cf54:	0f b6 0a             	movzbl (%rdx),%ecx
    cf57:	80 f9 02             	cmp    $0x2,%cl
    cf5a:	0f 84 40 0f 00 00    	je     dea0 <f0+0x2900>
    cf60:	80 f9 01             	cmp    $0x1,%cl
    cf63:	75 29                	jne    cf8e <f0+0x19ee>
    cf65:	8b 4a 18             	mov    0x18(%rdx),%ecx
    cf68:	0f b7 c0             	movzwl %ax,%eax
    cf6b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    cf6e:	48 0f af c1          	imul   %rcx,%rax
    cf72:	48 c1 e8 20          	shr    $0x20,%rax
    cf76:	48 39 d0             	cmp    %rdx,%rax
    cf79:	73 13                	jae    cf8e <f0+0x19ee>
    cf7b:	49 01 c4             	add    %rax,%r12
    cf7e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    cf83:	0f 84 e5 11 00 00    	je     e16e <f0+0x2bce>
    cf89:	41 c6 04 24 01       	movb   $0x1,(%r12)
    cf8e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    cf95:	33 f3 bf 
    cf98:	48 8d b4 24 e0 06 00 	lea    0x6e0(%rsp),%rsi
    cf9f:	00 
    cfa0:	bf 01 00 00 00       	mov    $0x1,%edi
    cfa5:	4c 89 ac 24 e8 06 00 	mov    %r13,0x6e8(%rsp)
    cfac:	00 
    cfad:	48 89 84 24 e0 06 00 	mov    %rax,0x6e0(%rsp)
    cfb4:	00 
    cfb5:	e8 46 91 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    cfba:	48 8b 15 37 fc 05 00 	mov    0x5fc37(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    cfc1:	49 89 c5             	mov    %rax,%r13
    cfc4:	48 2b 05 05 fc 05 00 	sub    0x5fc05(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    cfcb:	48 c1 e2 10          	shl    $0x10,%rdx
    cfcf:	48 39 d0             	cmp    %rdx,%rax
    cfd2:	73 59                	jae    d02d <f0+0x1a8d>
    cfd4:	48 89 c2             	mov    %rax,%rdx
    cfd7:	48 c1 ea 10          	shr    $0x10,%rdx
    cfdb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    cfdf:	48 8b 15 32 fc 05 00 	mov    0x5fc32(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    cfe6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    cfea:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    cfee:	4d 85 e4             	test   %r12,%r12
    cff1:	74 3a                	je     d02d <f0+0x1a8d>
    cff3:	0f b6 0a             	movzbl (%rdx),%ecx
    cff6:	80 f9 02             	cmp    $0x2,%cl
    cff9:	0f 84 91 0e 00 00    	je     de90 <f0+0x28f0>
    cfff:	80 f9 01             	cmp    $0x1,%cl
    d002:	75 29                	jne    d02d <f0+0x1a8d>
    d004:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d007:	0f b7 c0             	movzwl %ax,%eax
    d00a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d00d:	48 0f af c1          	imul   %rcx,%rax
    d011:	48 c1 e8 20          	shr    $0x20,%rax
    d015:	48 39 d0             	cmp    %rdx,%rax
    d018:	73 13                	jae    d02d <f0+0x1a8d>
    d01a:	49 01 c4             	add    %rax,%r12
    d01d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d022:	0f 84 53 11 00 00    	je     e17b <f0+0x2bdb>
    d028:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d02d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d034:	00 f0 3f 
    d037:	48 8d b4 24 f0 06 00 	lea    0x6f0(%rsp),%rsi
    d03e:	00 
    d03f:	bf 01 00 00 00       	mov    $0x1,%edi
    d044:	4c 89 ac 24 f8 06 00 	mov    %r13,0x6f8(%rsp)
    d04b:	00 
    d04c:	48 89 84 24 f0 06 00 	mov    %rax,0x6f0(%rsp)
    d053:	00 
    d054:	e8 a7 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d059:	48 8b 15 98 fb 05 00 	mov    0x5fb98(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d060:	49 89 c5             	mov    %rax,%r13
    d063:	48 2b 05 66 fb 05 00 	sub    0x5fb66(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d06a:	48 c1 e2 10          	shl    $0x10,%rdx
    d06e:	48 39 d0             	cmp    %rdx,%rax
    d071:	73 59                	jae    d0cc <f0+0x1b2c>
    d073:	48 89 c2             	mov    %rax,%rdx
    d076:	48 c1 ea 10          	shr    $0x10,%rdx
    d07a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d07e:	48 8b 15 93 fb 05 00 	mov    0x5fb93(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d085:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d089:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d08d:	4d 85 e4             	test   %r12,%r12
    d090:	74 3a                	je     d0cc <f0+0x1b2c>
    d092:	0f b6 0a             	movzbl (%rdx),%ecx
    d095:	80 f9 02             	cmp    $0x2,%cl
    d098:	0f 84 e2 0d 00 00    	je     de80 <f0+0x28e0>
    d09e:	80 f9 01             	cmp    $0x1,%cl
    d0a1:	75 29                	jne    d0cc <f0+0x1b2c>
    d0a3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d0a6:	0f b7 c0             	movzwl %ax,%eax
    d0a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d0ac:	48 0f af c1          	imul   %rcx,%rax
    d0b0:	48 c1 e8 20          	shr    $0x20,%rax
    d0b4:	48 39 d0             	cmp    %rdx,%rax
    d0b7:	73 13                	jae    d0cc <f0+0x1b2c>
    d0b9:	49 01 c4             	add    %rax,%r12
    d0bc:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d0c1:	0f 84 c1 10 00 00    	je     e188 <f0+0x2be8>
    d0c7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d0cc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d0d3:	33 f3 bf 
    d0d6:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
    d0dd:	00 
    d0de:	bf 01 00 00 00       	mov    $0x1,%edi
    d0e3:	4c 89 ac 24 08 07 00 	mov    %r13,0x708(%rsp)
    d0ea:	00 
    d0eb:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
    d0f2:	00 
    d0f3:	e8 08 90 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d0f8:	48 8b 15 f9 fa 05 00 	mov    0x5faf9(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d0ff:	49 89 c5             	mov    %rax,%r13
    d102:	48 2b 05 c7 fa 05 00 	sub    0x5fac7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d109:	48 c1 e2 10          	shl    $0x10,%rdx
    d10d:	48 39 d0             	cmp    %rdx,%rax
    d110:	73 59                	jae    d16b <f0+0x1bcb>
    d112:	48 89 c2             	mov    %rax,%rdx
    d115:	48 c1 ea 10          	shr    $0x10,%rdx
    d119:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d11d:	48 8b 15 f4 fa 05 00 	mov    0x5faf4(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d124:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d128:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d12c:	4d 85 e4             	test   %r12,%r12
    d12f:	74 3a                	je     d16b <f0+0x1bcb>
    d131:	0f b6 0a             	movzbl (%rdx),%ecx
    d134:	80 f9 02             	cmp    $0x2,%cl
    d137:	0f 84 33 0d 00 00    	je     de70 <f0+0x28d0>
    d13d:	80 f9 01             	cmp    $0x1,%cl
    d140:	75 29                	jne    d16b <f0+0x1bcb>
    d142:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d145:	0f b7 c0             	movzwl %ax,%eax
    d148:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d14b:	48 0f af c1          	imul   %rcx,%rax
    d14f:	48 c1 e8 20          	shr    $0x20,%rax
    d153:	48 39 d0             	cmp    %rdx,%rax
    d156:	73 13                	jae    d16b <f0+0x1bcb>
    d158:	49 01 c4             	add    %rax,%r12
    d15b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d160:	0f 84 2f 10 00 00    	je     e195 <f0+0x2bf5>
    d166:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d16b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d172:	00 f0 3f 
    d175:	48 8d b4 24 10 07 00 	lea    0x710(%rsp),%rsi
    d17c:	00 
    d17d:	bf 01 00 00 00       	mov    $0x1,%edi
    d182:	4c 89 ac 24 18 07 00 	mov    %r13,0x718(%rsp)
    d189:	00 
    d18a:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
    d191:	00 
    d192:	e8 69 8f ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d197:	48 8b 15 5a fa 05 00 	mov    0x5fa5a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d19e:	49 89 c5             	mov    %rax,%r13
    d1a1:	48 2b 05 28 fa 05 00 	sub    0x5fa28(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d1a8:	48 c1 e2 10          	shl    $0x10,%rdx
    d1ac:	48 39 d0             	cmp    %rdx,%rax
    d1af:	73 59                	jae    d20a <f0+0x1c6a>
    d1b1:	48 89 c2             	mov    %rax,%rdx
    d1b4:	48 c1 ea 10          	shr    $0x10,%rdx
    d1b8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d1bc:	48 8b 15 55 fa 05 00 	mov    0x5fa55(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d1c3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d1c7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d1cb:	4d 85 e4             	test   %r12,%r12
    d1ce:	74 3a                	je     d20a <f0+0x1c6a>
    d1d0:	0f b6 0a             	movzbl (%rdx),%ecx
    d1d3:	80 f9 02             	cmp    $0x2,%cl
    d1d6:	0f 84 84 0c 00 00    	je     de60 <f0+0x28c0>
    d1dc:	80 f9 01             	cmp    $0x1,%cl
    d1df:	75 29                	jne    d20a <f0+0x1c6a>
    d1e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d1e4:	0f b7 c0             	movzwl %ax,%eax
    d1e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d1ea:	48 0f af c1          	imul   %rcx,%rax
    d1ee:	48 c1 e8 20          	shr    $0x20,%rax
    d1f2:	48 39 d0             	cmp    %rdx,%rax
    d1f5:	73 13                	jae    d20a <f0+0x1c6a>
    d1f7:	49 01 c4             	add    %rax,%r12
    d1fa:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d1ff:	0f 84 9d 0f 00 00    	je     e1a2 <f0+0x2c02>
    d205:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d20a:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d211:	33 f3 bf 
    d214:	48 8d b4 24 20 07 00 	lea    0x720(%rsp),%rsi
    d21b:	00 
    d21c:	bf 01 00 00 00       	mov    $0x1,%edi
    d221:	4c 89 ac 24 28 07 00 	mov    %r13,0x728(%rsp)
    d228:	00 
    d229:	48 89 84 24 20 07 00 	mov    %rax,0x720(%rsp)
    d230:	00 
    d231:	e8 ca 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d236:	48 8b 15 bb f9 05 00 	mov    0x5f9bb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d23d:	49 89 c5             	mov    %rax,%r13
    d240:	48 2b 05 89 f9 05 00 	sub    0x5f989(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d247:	48 c1 e2 10          	shl    $0x10,%rdx
    d24b:	48 39 d0             	cmp    %rdx,%rax
    d24e:	73 59                	jae    d2a9 <f0+0x1d09>
    d250:	48 89 c2             	mov    %rax,%rdx
    d253:	48 c1 ea 10          	shr    $0x10,%rdx
    d257:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d25b:	48 8b 15 b6 f9 05 00 	mov    0x5f9b6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d262:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d266:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d26a:	4d 85 e4             	test   %r12,%r12
    d26d:	74 3a                	je     d2a9 <f0+0x1d09>
    d26f:	0f b6 0a             	movzbl (%rdx),%ecx
    d272:	80 f9 02             	cmp    $0x2,%cl
    d275:	0f 84 d5 0b 00 00    	je     de50 <f0+0x28b0>
    d27b:	80 f9 01             	cmp    $0x1,%cl
    d27e:	75 29                	jne    d2a9 <f0+0x1d09>
    d280:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d283:	0f b7 c0             	movzwl %ax,%eax
    d286:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d289:	48 0f af c1          	imul   %rcx,%rax
    d28d:	48 c1 e8 20          	shr    $0x20,%rax
    d291:	48 39 d0             	cmp    %rdx,%rax
    d294:	73 13                	jae    d2a9 <f0+0x1d09>
    d296:	49 01 c4             	add    %rax,%r12
    d299:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d29e:	0f 84 0b 0f 00 00    	je     e1af <f0+0x2c0f>
    d2a4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d2a9:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d2b0:	00 f0 3f 
    d2b3:	48 8d b4 24 30 07 00 	lea    0x730(%rsp),%rsi
    d2ba:	00 
    d2bb:	bf 01 00 00 00       	mov    $0x1,%edi
    d2c0:	4c 89 ac 24 38 07 00 	mov    %r13,0x738(%rsp)
    d2c7:	00 
    d2c8:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
    d2cf:	00 
    d2d0:	e8 2b 8e ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d2d5:	48 8b 15 1c f9 05 00 	mov    0x5f91c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d2dc:	49 89 c5             	mov    %rax,%r13
    d2df:	48 2b 05 ea f8 05 00 	sub    0x5f8ea(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d2e6:	48 c1 e2 10          	shl    $0x10,%rdx
    d2ea:	48 39 d0             	cmp    %rdx,%rax
    d2ed:	73 59                	jae    d348 <f0+0x1da8>
    d2ef:	48 89 c2             	mov    %rax,%rdx
    d2f2:	48 c1 ea 10          	shr    $0x10,%rdx
    d2f6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d2fa:	48 8b 15 17 f9 05 00 	mov    0x5f917(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d301:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d305:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d309:	4d 85 e4             	test   %r12,%r12
    d30c:	74 3a                	je     d348 <f0+0x1da8>
    d30e:	0f b6 0a             	movzbl (%rdx),%ecx
    d311:	80 f9 02             	cmp    $0x2,%cl
    d314:	0f 84 26 0b 00 00    	je     de40 <f0+0x28a0>
    d31a:	80 f9 01             	cmp    $0x1,%cl
    d31d:	75 29                	jne    d348 <f0+0x1da8>
    d31f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d322:	0f b7 c0             	movzwl %ax,%eax
    d325:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d328:	48 0f af c1          	imul   %rcx,%rax
    d32c:	48 c1 e8 20          	shr    $0x20,%rax
    d330:	48 39 d0             	cmp    %rdx,%rax
    d333:	73 13                	jae    d348 <f0+0x1da8>
    d335:	49 01 c4             	add    %rax,%r12
    d338:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d33d:	0f 84 79 0e 00 00    	je     e1bc <f0+0x2c1c>
    d343:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d348:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d34f:	33 f3 bf 
    d352:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
    d359:	00 
    d35a:	bf 01 00 00 00       	mov    $0x1,%edi
    d35f:	4c 89 ac 24 48 07 00 	mov    %r13,0x748(%rsp)
    d366:	00 
    d367:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
    d36e:	00 
    d36f:	e8 8c 8d ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d374:	48 8b 15 7d f8 05 00 	mov    0x5f87d(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d37b:	49 89 c5             	mov    %rax,%r13
    d37e:	48 2b 05 4b f8 05 00 	sub    0x5f84b(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d385:	48 c1 e2 10          	shl    $0x10,%rdx
    d389:	48 39 d0             	cmp    %rdx,%rax
    d38c:	73 59                	jae    d3e7 <f0+0x1e47>
    d38e:	48 89 c2             	mov    %rax,%rdx
    d391:	48 c1 ea 10          	shr    $0x10,%rdx
    d395:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d399:	48 8b 15 78 f8 05 00 	mov    0x5f878(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d3a0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d3a4:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d3a8:	4d 85 e4             	test   %r12,%r12
    d3ab:	74 3a                	je     d3e7 <f0+0x1e47>
    d3ad:	0f b6 0a             	movzbl (%rdx),%ecx
    d3b0:	80 f9 02             	cmp    $0x2,%cl
    d3b3:	0f 84 77 0a 00 00    	je     de30 <f0+0x2890>
    d3b9:	80 f9 01             	cmp    $0x1,%cl
    d3bc:	75 29                	jne    d3e7 <f0+0x1e47>
    d3be:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d3c1:	0f b7 c0             	movzwl %ax,%eax
    d3c4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d3c7:	48 0f af c1          	imul   %rcx,%rax
    d3cb:	48 c1 e8 20          	shr    $0x20,%rax
    d3cf:	48 39 d0             	cmp    %rdx,%rax
    d3d2:	73 13                	jae    d3e7 <f0+0x1e47>
    d3d4:	49 01 c4             	add    %rax,%r12
    d3d7:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d3dc:	0f 84 e7 0d 00 00    	je     e1c9 <f0+0x2c29>
    d3e2:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d3e7:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d3ee:	00 f0 3f 
    d3f1:	48 8d b4 24 50 07 00 	lea    0x750(%rsp),%rsi
    d3f8:	00 
    d3f9:	bf 01 00 00 00       	mov    $0x1,%edi
    d3fe:	4c 89 ac 24 58 07 00 	mov    %r13,0x758(%rsp)
    d405:	00 
    d406:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
    d40d:	00 
    d40e:	e8 ed 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d413:	48 8b 15 de f7 05 00 	mov    0x5f7de(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d41a:	49 89 c5             	mov    %rax,%r13
    d41d:	48 2b 05 ac f7 05 00 	sub    0x5f7ac(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d424:	48 c1 e2 10          	shl    $0x10,%rdx
    d428:	48 39 d0             	cmp    %rdx,%rax
    d42b:	73 59                	jae    d486 <f0+0x1ee6>
    d42d:	48 89 c2             	mov    %rax,%rdx
    d430:	48 c1 ea 10          	shr    $0x10,%rdx
    d434:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d438:	48 8b 15 d9 f7 05 00 	mov    0x5f7d9(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d43f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d443:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d447:	4d 85 e4             	test   %r12,%r12
    d44a:	74 3a                	je     d486 <f0+0x1ee6>
    d44c:	0f b6 0a             	movzbl (%rdx),%ecx
    d44f:	80 f9 02             	cmp    $0x2,%cl
    d452:	0f 84 38 0c 00 00    	je     e090 <f0+0x2af0>
    d458:	80 f9 01             	cmp    $0x1,%cl
    d45b:	75 29                	jne    d486 <f0+0x1ee6>
    d45d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d460:	0f b7 c0             	movzwl %ax,%eax
    d463:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d466:	48 0f af c1          	imul   %rcx,%rax
    d46a:	48 c1 e8 20          	shr    $0x20,%rax
    d46e:	48 39 d0             	cmp    %rdx,%rax
    d471:	73 13                	jae    d486 <f0+0x1ee6>
    d473:	49 01 c4             	add    %rax,%r12
    d476:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d47b:	0f 84 55 0d 00 00    	je     e1d6 <f0+0x2c36>
    d481:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d486:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d48d:	33 f3 bf 
    d490:	48 8d b4 24 60 07 00 	lea    0x760(%rsp),%rsi
    d497:	00 
    d498:	bf 01 00 00 00       	mov    $0x1,%edi
    d49d:	4c 89 ac 24 68 07 00 	mov    %r13,0x768(%rsp)
    d4a4:	00 
    d4a5:	48 89 84 24 60 07 00 	mov    %rax,0x760(%rsp)
    d4ac:	00 
    d4ad:	e8 4e 8c ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d4b2:	48 8b 15 3f f7 05 00 	mov    0x5f73f(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d4b9:	49 89 c5             	mov    %rax,%r13
    d4bc:	48 2b 05 0d f7 05 00 	sub    0x5f70d(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d4c3:	48 c1 e2 10          	shl    $0x10,%rdx
    d4c7:	48 39 d0             	cmp    %rdx,%rax
    d4ca:	73 59                	jae    d525 <f0+0x1f85>
    d4cc:	48 89 c2             	mov    %rax,%rdx
    d4cf:	48 c1 ea 10          	shr    $0x10,%rdx
    d4d3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d4d7:	48 8b 15 3a f7 05 00 	mov    0x5f73a(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d4de:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d4e2:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d4e6:	4d 85 e4             	test   %r12,%r12
    d4e9:	74 3a                	je     d525 <f0+0x1f85>
    d4eb:	0f b6 0a             	movzbl (%rdx),%ecx
    d4ee:	80 f9 02             	cmp    $0x2,%cl
    d4f1:	0f 84 89 0b 00 00    	je     e080 <f0+0x2ae0>
    d4f7:	80 f9 01             	cmp    $0x1,%cl
    d4fa:	75 29                	jne    d525 <f0+0x1f85>
    d4fc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d4ff:	0f b7 c0             	movzwl %ax,%eax
    d502:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d505:	48 0f af c1          	imul   %rcx,%rax
    d509:	48 c1 e8 20          	shr    $0x20,%rax
    d50d:	48 39 d0             	cmp    %rdx,%rax
    d510:	73 13                	jae    d525 <f0+0x1f85>
    d512:	49 01 c4             	add    %rax,%r12
    d515:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d51a:	0f 84 c3 0c 00 00    	je     e1e3 <f0+0x2c43>
    d520:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d525:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d52c:	00 f0 3f 
    d52f:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
    d536:	00 
    d537:	bf 01 00 00 00       	mov    $0x1,%edi
    d53c:	4c 89 ac 24 78 07 00 	mov    %r13,0x778(%rsp)
    d543:	00 
    d544:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
    d54b:	00 
    d54c:	e8 af 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d551:	48 8b 15 a0 f6 05 00 	mov    0x5f6a0(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d558:	49 89 c5             	mov    %rax,%r13
    d55b:	48 2b 05 6e f6 05 00 	sub    0x5f66e(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d562:	48 c1 e2 10          	shl    $0x10,%rdx
    d566:	48 39 d0             	cmp    %rdx,%rax
    d569:	73 59                	jae    d5c4 <f0+0x2024>
    d56b:	48 89 c2             	mov    %rax,%rdx
    d56e:	48 c1 ea 10          	shr    $0x10,%rdx
    d572:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d576:	48 8b 15 9b f6 05 00 	mov    0x5f69b(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d57d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d581:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d585:	4d 85 e4             	test   %r12,%r12
    d588:	74 3a                	je     d5c4 <f0+0x2024>
    d58a:	0f b6 0a             	movzbl (%rdx),%ecx
    d58d:	80 f9 02             	cmp    $0x2,%cl
    d590:	0f 84 da 0a 00 00    	je     e070 <f0+0x2ad0>
    d596:	80 f9 01             	cmp    $0x1,%cl
    d599:	75 29                	jne    d5c4 <f0+0x2024>
    d59b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d59e:	0f b7 c0             	movzwl %ax,%eax
    d5a1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d5a4:	48 0f af c1          	imul   %rcx,%rax
    d5a8:	48 c1 e8 20          	shr    $0x20,%rax
    d5ac:	48 39 d0             	cmp    %rdx,%rax
    d5af:	73 13                	jae    d5c4 <f0+0x2024>
    d5b1:	49 01 c4             	add    %rax,%r12
    d5b4:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d5b9:	0f 84 31 0c 00 00    	je     e1f0 <f0+0x2c50>
    d5bf:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d5c4:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d5cb:	33 f3 bf 
    d5ce:	48 8d b4 24 80 07 00 	lea    0x780(%rsp),%rsi
    d5d5:	00 
    d5d6:	bf 01 00 00 00       	mov    $0x1,%edi
    d5db:	4c 89 ac 24 88 07 00 	mov    %r13,0x788(%rsp)
    d5e2:	00 
    d5e3:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
    d5ea:	00 
    d5eb:	e8 10 8b ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d5f0:	48 8b 15 01 f6 05 00 	mov    0x5f601(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d5f7:	49 89 c5             	mov    %rax,%r13
    d5fa:	48 2b 05 cf f5 05 00 	sub    0x5f5cf(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d601:	48 c1 e2 10          	shl    $0x10,%rdx
    d605:	48 39 d0             	cmp    %rdx,%rax
    d608:	73 59                	jae    d663 <f0+0x20c3>
    d60a:	48 89 c2             	mov    %rax,%rdx
    d60d:	48 c1 ea 10          	shr    $0x10,%rdx
    d611:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d615:	48 8b 15 fc f5 05 00 	mov    0x5f5fc(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d61c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d620:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d624:	4d 85 e4             	test   %r12,%r12
    d627:	74 3a                	je     d663 <f0+0x20c3>
    d629:	0f b6 0a             	movzbl (%rdx),%ecx
    d62c:	80 f9 02             	cmp    $0x2,%cl
    d62f:	0f 84 2b 0a 00 00    	je     e060 <f0+0x2ac0>
    d635:	80 f9 01             	cmp    $0x1,%cl
    d638:	75 29                	jne    d663 <f0+0x20c3>
    d63a:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d63d:	0f b7 c0             	movzwl %ax,%eax
    d640:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d643:	48 0f af c1          	imul   %rcx,%rax
    d647:	48 c1 e8 20          	shr    $0x20,%rax
    d64b:	48 39 d0             	cmp    %rdx,%rax
    d64e:	73 13                	jae    d663 <f0+0x20c3>
    d650:	49 01 c4             	add    %rax,%r12
    d653:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d658:	0f 84 9f 0b 00 00    	je     e1fd <f0+0x2c5d>
    d65e:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d663:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d66a:	00 f0 3f 
    d66d:	48 8d b4 24 90 07 00 	lea    0x790(%rsp),%rsi
    d674:	00 
    d675:	bf 01 00 00 00       	mov    $0x1,%edi
    d67a:	4c 89 ac 24 98 07 00 	mov    %r13,0x798(%rsp)
    d681:	00 
    d682:	48 89 84 24 90 07 00 	mov    %rax,0x790(%rsp)
    d689:	00 
    d68a:	e8 71 8a ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d68f:	48 8b 15 62 f5 05 00 	mov    0x5f562(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d696:	49 89 c5             	mov    %rax,%r13
    d699:	48 2b 05 30 f5 05 00 	sub    0x5f530(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d6a0:	48 c1 e2 10          	shl    $0x10,%rdx
    d6a4:	48 39 d0             	cmp    %rdx,%rax
    d6a7:	73 59                	jae    d702 <f0+0x2162>
    d6a9:	48 89 c2             	mov    %rax,%rdx
    d6ac:	48 c1 ea 10          	shr    $0x10,%rdx
    d6b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d6b4:	48 8b 15 5d f5 05 00 	mov    0x5f55d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d6bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d6bf:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d6c3:	4d 85 e4             	test   %r12,%r12
    d6c6:	74 3a                	je     d702 <f0+0x2162>
    d6c8:	0f b6 0a             	movzbl (%rdx),%ecx
    d6cb:	80 f9 02             	cmp    $0x2,%cl
    d6ce:	0f 84 7c 09 00 00    	je     e050 <f0+0x2ab0>
    d6d4:	80 f9 01             	cmp    $0x1,%cl
    d6d7:	75 29                	jne    d702 <f0+0x2162>
    d6d9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d6dc:	0f b7 c0             	movzwl %ax,%eax
    d6df:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d6e2:	48 0f af c1          	imul   %rcx,%rax
    d6e6:	48 c1 e8 20          	shr    $0x20,%rax
    d6ea:	48 39 d0             	cmp    %rdx,%rax
    d6ed:	73 13                	jae    d702 <f0+0x2162>
    d6ef:	49 01 c4             	add    %rax,%r12
    d6f2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d6f7:	0f 84 0d 0b 00 00    	je     e20a <f0+0x2c6a>
    d6fd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d702:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d709:	33 f3 bf 
    d70c:	48 8d b4 24 a0 07 00 	lea    0x7a0(%rsp),%rsi
    d713:	00 
    d714:	bf 01 00 00 00       	mov    $0x1,%edi
    d719:	4c 89 ac 24 a8 07 00 	mov    %r13,0x7a8(%rsp)
    d720:	00 
    d721:	48 89 84 24 a0 07 00 	mov    %rax,0x7a0(%rsp)
    d728:	00 
    d729:	e8 d2 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d72e:	48 8b 15 c3 f4 05 00 	mov    0x5f4c3(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d735:	49 89 c5             	mov    %rax,%r13
    d738:	48 2b 05 91 f4 05 00 	sub    0x5f491(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d73f:	48 c1 e2 10          	shl    $0x10,%rdx
    d743:	48 39 d0             	cmp    %rdx,%rax
    d746:	73 59                	jae    d7a1 <f0+0x2201>
    d748:	48 89 c2             	mov    %rax,%rdx
    d74b:	48 c1 ea 10          	shr    $0x10,%rdx
    d74f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d753:	48 8b 15 be f4 05 00 	mov    0x5f4be(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d75a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d75e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d762:	4d 85 e4             	test   %r12,%r12
    d765:	74 3a                	je     d7a1 <f0+0x2201>
    d767:	0f b6 0a             	movzbl (%rdx),%ecx
    d76a:	80 f9 02             	cmp    $0x2,%cl
    d76d:	0f 84 cd 08 00 00    	je     e040 <f0+0x2aa0>
    d773:	80 f9 01             	cmp    $0x1,%cl
    d776:	75 29                	jne    d7a1 <f0+0x2201>
    d778:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d77b:	0f b7 c0             	movzwl %ax,%eax
    d77e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d781:	48 0f af c1          	imul   %rcx,%rax
    d785:	48 c1 e8 20          	shr    $0x20,%rax
    d789:	48 39 d0             	cmp    %rdx,%rax
    d78c:	73 13                	jae    d7a1 <f0+0x2201>
    d78e:	49 01 c4             	add    %rax,%r12
    d791:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d796:	0f 84 7b 0a 00 00    	je     e217 <f0+0x2c77>
    d79c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d7a1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d7a8:	00 f0 3f 
    d7ab:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
    d7b2:	00 
    d7b3:	bf 01 00 00 00       	mov    $0x1,%edi
    d7b8:	4c 89 ac 24 b8 07 00 	mov    %r13,0x7b8(%rsp)
    d7bf:	00 
    d7c0:	48 89 84 24 b0 07 00 	mov    %rax,0x7b0(%rsp)
    d7c7:	00 
    d7c8:	e8 33 89 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d7cd:	48 8b 15 24 f4 05 00 	mov    0x5f424(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d7d4:	49 89 c5             	mov    %rax,%r13
    d7d7:	48 2b 05 f2 f3 05 00 	sub    0x5f3f2(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d7de:	48 c1 e2 10          	shl    $0x10,%rdx
    d7e2:	48 39 d0             	cmp    %rdx,%rax
    d7e5:	73 59                	jae    d840 <f0+0x22a0>
    d7e7:	48 89 c2             	mov    %rax,%rdx
    d7ea:	48 c1 ea 10          	shr    $0x10,%rdx
    d7ee:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d7f2:	48 8b 15 1f f4 05 00 	mov    0x5f41f(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d7f9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d7fd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d801:	4d 85 e4             	test   %r12,%r12
    d804:	74 3a                	je     d840 <f0+0x22a0>
    d806:	0f b6 0a             	movzbl (%rdx),%ecx
    d809:	80 f9 02             	cmp    $0x2,%cl
    d80c:	0f 84 1e 08 00 00    	je     e030 <f0+0x2a90>
    d812:	80 f9 01             	cmp    $0x1,%cl
    d815:	75 29                	jne    d840 <f0+0x22a0>
    d817:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d81a:	0f b7 c0             	movzwl %ax,%eax
    d81d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d820:	48 0f af c1          	imul   %rcx,%rax
    d824:	48 c1 e8 20          	shr    $0x20,%rax
    d828:	48 39 d0             	cmp    %rdx,%rax
    d82b:	73 13                	jae    d840 <f0+0x22a0>
    d82d:	49 01 c4             	add    %rax,%r12
    d830:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d835:	0f 84 e9 09 00 00    	je     e224 <f0+0x2c84>
    d83b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d840:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d847:	33 f3 bf 
    d84a:	48 8d b4 24 c0 07 00 	lea    0x7c0(%rsp),%rsi
    d851:	00 
    d852:	bf 01 00 00 00       	mov    $0x1,%edi
    d857:	4c 89 ac 24 c8 07 00 	mov    %r13,0x7c8(%rsp)
    d85e:	00 
    d85f:	48 89 84 24 c0 07 00 	mov    %rax,0x7c0(%rsp)
    d866:	00 
    d867:	e8 94 88 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d86c:	48 8b 15 85 f3 05 00 	mov    0x5f385(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d873:	49 89 c5             	mov    %rax,%r13
    d876:	48 2b 05 53 f3 05 00 	sub    0x5f353(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d87d:	48 c1 e2 10          	shl    $0x10,%rdx
    d881:	48 39 d0             	cmp    %rdx,%rax
    d884:	73 59                	jae    d8df <f0+0x233f>
    d886:	48 89 c2             	mov    %rax,%rdx
    d889:	48 c1 ea 10          	shr    $0x10,%rdx
    d88d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d891:	48 8b 15 80 f3 05 00 	mov    0x5f380(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d898:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d89c:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d8a0:	4d 85 e4             	test   %r12,%r12
    d8a3:	74 3a                	je     d8df <f0+0x233f>
    d8a5:	0f b6 0a             	movzbl (%rdx),%ecx
    d8a8:	80 f9 02             	cmp    $0x2,%cl
    d8ab:	0f 84 6f 07 00 00    	je     e020 <f0+0x2a80>
    d8b1:	80 f9 01             	cmp    $0x1,%cl
    d8b4:	75 29                	jne    d8df <f0+0x233f>
    d8b6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d8b9:	0f b7 c0             	movzwl %ax,%eax
    d8bc:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d8bf:	48 0f af c1          	imul   %rcx,%rax
    d8c3:	48 c1 e8 20          	shr    $0x20,%rax
    d8c7:	48 39 d0             	cmp    %rdx,%rax
    d8ca:	73 13                	jae    d8df <f0+0x233f>
    d8cc:	49 01 c4             	add    %rax,%r12
    d8cf:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d8d4:	0f 84 57 09 00 00    	je     e231 <f0+0x2c91>
    d8da:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d8df:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    d8e6:	00 f0 3f 
    d8e9:	48 8d b4 24 d0 07 00 	lea    0x7d0(%rsp),%rsi
    d8f0:	00 
    d8f1:	bf 01 00 00 00       	mov    $0x1,%edi
    d8f6:	4c 89 ac 24 d8 07 00 	mov    %r13,0x7d8(%rsp)
    d8fd:	00 
    d8fe:	48 89 84 24 d0 07 00 	mov    %rax,0x7d0(%rsp)
    d905:	00 
    d906:	e8 f5 87 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d90b:	48 8b 15 e6 f2 05 00 	mov    0x5f2e6(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d912:	49 89 c5             	mov    %rax,%r13
    d915:	48 2b 05 b4 f2 05 00 	sub    0x5f2b4(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d91c:	48 c1 e2 10          	shl    $0x10,%rdx
    d920:	48 39 d0             	cmp    %rdx,%rax
    d923:	73 59                	jae    d97e <f0+0x23de>
    d925:	48 89 c2             	mov    %rax,%rdx
    d928:	48 c1 ea 10          	shr    $0x10,%rdx
    d92c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d930:	48 8b 15 e1 f2 05 00 	mov    0x5f2e1(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d937:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d93b:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d93f:	4d 85 e4             	test   %r12,%r12
    d942:	74 3a                	je     d97e <f0+0x23de>
    d944:	0f b6 0a             	movzbl (%rdx),%ecx
    d947:	80 f9 02             	cmp    $0x2,%cl
    d94a:	0f 84 c0 06 00 00    	je     e010 <f0+0x2a70>
    d950:	80 f9 01             	cmp    $0x1,%cl
    d953:	75 29                	jne    d97e <f0+0x23de>
    d955:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d958:	0f b7 c0             	movzwl %ax,%eax
    d95b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d95e:	48 0f af c1          	imul   %rcx,%rax
    d962:	48 c1 e8 20          	shr    $0x20,%rax
    d966:	48 39 d0             	cmp    %rdx,%rax
    d969:	73 13                	jae    d97e <f0+0x23de>
    d96b:	49 01 c4             	add    %rax,%r12
    d96e:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    d973:	0f 84 c5 08 00 00    	je     e23e <f0+0x2c9e>
    d979:	41 c6 04 24 01       	movb   $0x1,(%r12)
    d97e:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    d985:	33 f3 bf 
    d988:	48 8d b4 24 e0 07 00 	lea    0x7e0(%rsp),%rsi
    d98f:	00 
    d990:	bf 01 00 00 00       	mov    $0x1,%edi
    d995:	4c 89 ac 24 e8 07 00 	mov    %r13,0x7e8(%rsp)
    d99c:	00 
    d99d:	48 89 84 24 e0 07 00 	mov    %rax,0x7e0(%rsp)
    d9a4:	00 
    d9a5:	e8 56 87 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    d9aa:	48 8b 15 47 f2 05 00 	mov    0x5f247(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    d9b1:	49 89 c5             	mov    %rax,%r13
    d9b4:	48 2b 05 15 f2 05 00 	sub    0x5f215(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    d9bb:	48 c1 e2 10          	shl    $0x10,%rdx
    d9bf:	48 39 d0             	cmp    %rdx,%rax
    d9c2:	73 59                	jae    da1d <f0+0x247d>
    d9c4:	48 89 c2             	mov    %rax,%rdx
    d9c7:	48 c1 ea 10          	shr    $0x10,%rdx
    d9cb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    d9cf:	48 8b 15 42 f2 05 00 	mov    0x5f242(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    d9d6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    d9da:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    d9de:	4d 85 e4             	test   %r12,%r12
    d9e1:	74 3a                	je     da1d <f0+0x247d>
    d9e3:	0f b6 0a             	movzbl (%rdx),%ecx
    d9e6:	80 f9 02             	cmp    $0x2,%cl
    d9e9:	0f 84 11 06 00 00    	je     e000 <f0+0x2a60>
    d9ef:	80 f9 01             	cmp    $0x1,%cl
    d9f2:	75 29                	jne    da1d <f0+0x247d>
    d9f4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    d9f7:	0f b7 c0             	movzwl %ax,%eax
    d9fa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    d9fd:	48 0f af c1          	imul   %rcx,%rax
    da01:	48 c1 e8 20          	shr    $0x20,%rax
    da05:	48 39 d0             	cmp    %rdx,%rax
    da08:	73 13                	jae    da1d <f0+0x247d>
    da0a:	49 01 c4             	add    %rax,%r12
    da0d:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    da12:	0f 84 33 08 00 00    	je     e24b <f0+0x2cab>
    da18:	41 c6 04 24 01       	movb   $0x1,(%r12)
    da1d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    da24:	00 f0 3f 
    da27:	48 8d b4 24 f0 07 00 	lea    0x7f0(%rsp),%rsi
    da2e:	00 
    da2f:	bf 01 00 00 00       	mov    $0x1,%edi
    da34:	4c 89 ac 24 f8 07 00 	mov    %r13,0x7f8(%rsp)
    da3b:	00 
    da3c:	48 89 84 24 f0 07 00 	mov    %rax,0x7f0(%rsp)
    da43:	00 
    da44:	e8 b7 86 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    da49:	48 8b 15 a8 f1 05 00 	mov    0x5f1a8(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    da50:	49 89 c5             	mov    %rax,%r13
    da53:	48 2b 05 76 f1 05 00 	sub    0x5f176(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    da5a:	48 c1 e2 10          	shl    $0x10,%rdx
    da5e:	48 39 d0             	cmp    %rdx,%rax
    da61:	73 59                	jae    dabc <f0+0x251c>
    da63:	48 89 c2             	mov    %rax,%rdx
    da66:	48 c1 ea 10          	shr    $0x10,%rdx
    da6a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    da6e:	48 8b 15 a3 f1 05 00 	mov    0x5f1a3(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    da75:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    da79:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    da7d:	4d 85 e4             	test   %r12,%r12
    da80:	74 3a                	je     dabc <f0+0x251c>
    da82:	0f b6 0a             	movzbl (%rdx),%ecx
    da85:	80 f9 02             	cmp    $0x2,%cl
    da88:	0f 84 62 05 00 00    	je     dff0 <f0+0x2a50>
    da8e:	80 f9 01             	cmp    $0x1,%cl
    da91:	75 29                	jne    dabc <f0+0x251c>
    da93:	8b 4a 18             	mov    0x18(%rdx),%ecx
    da96:	0f b7 c0             	movzwl %ax,%eax
    da99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    da9c:	48 0f af c1          	imul   %rcx,%rax
    daa0:	48 c1 e8 20          	shr    $0x20,%rax
    daa4:	48 39 d0             	cmp    %rdx,%rax
    daa7:	73 13                	jae    dabc <f0+0x251c>
    daa9:	49 01 c4             	add    %rax,%r12
    daac:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dab1:	0f 84 a1 07 00 00    	je     e258 <f0+0x2cb8>
    dab7:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dabc:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dac3:	33 f3 bf 
    dac6:	48 8d b4 24 00 08 00 	lea    0x800(%rsp),%rsi
    dacd:	00 
    dace:	bf 01 00 00 00       	mov    $0x1,%edi
    dad3:	4c 89 ac 24 08 08 00 	mov    %r13,0x808(%rsp)
    dada:	00 
    dadb:	48 89 84 24 00 08 00 	mov    %rax,0x800(%rsp)
    dae2:	00 
    dae3:	e8 18 86 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    dae8:	48 8b 15 09 f1 05 00 	mov    0x5f109(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    daef:	49 89 c5             	mov    %rax,%r13
    daf2:	48 2b 05 d7 f0 05 00 	sub    0x5f0d7(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    daf9:	48 c1 e2 10          	shl    $0x10,%rdx
    dafd:	48 39 d0             	cmp    %rdx,%rax
    db00:	73 59                	jae    db5b <f0+0x25bb>
    db02:	48 89 c2             	mov    %rax,%rdx
    db05:	48 c1 ea 10          	shr    $0x10,%rdx
    db09:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    db0d:	48 8b 15 04 f1 05 00 	mov    0x5f104(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    db14:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    db18:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    db1c:	4d 85 e4             	test   %r12,%r12
    db1f:	74 3a                	je     db5b <f0+0x25bb>
    db21:	0f b6 0a             	movzbl (%rdx),%ecx
    db24:	80 f9 02             	cmp    $0x2,%cl
    db27:	0f 84 b3 04 00 00    	je     dfe0 <f0+0x2a40>
    db2d:	80 f9 01             	cmp    $0x1,%cl
    db30:	75 29                	jne    db5b <f0+0x25bb>
    db32:	8b 4a 18             	mov    0x18(%rdx),%ecx
    db35:	0f b7 c0             	movzwl %ax,%eax
    db38:	8b 52 1c             	mov    0x1c(%rdx),%edx
    db3b:	48 0f af c1          	imul   %rcx,%rax
    db3f:	48 c1 e8 20          	shr    $0x20,%rax
    db43:	48 39 d0             	cmp    %rdx,%rax
    db46:	73 13                	jae    db5b <f0+0x25bb>
    db48:	49 01 c4             	add    %rax,%r12
    db4b:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    db50:	0f 84 0f 07 00 00    	je     e265 <f0+0x2cc5>
    db56:	41 c6 04 24 01       	movb   $0x1,(%r12)
    db5b:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    db62:	00 f0 3f 
    db65:	48 8d b4 24 10 08 00 	lea    0x810(%rsp),%rsi
    db6c:	00 
    db6d:	bf 01 00 00 00       	mov    $0x1,%edi
    db72:	4c 89 ac 24 18 08 00 	mov    %r13,0x818(%rsp)
    db79:	00 
    db7a:	48 89 84 24 10 08 00 	mov    %rax,0x810(%rsp)
    db81:	00 
    db82:	e8 79 85 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    db87:	48 8b 15 6a f0 05 00 	mov    0x5f06a(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    db8e:	49 89 c5             	mov    %rax,%r13
    db91:	48 2b 05 38 f0 05 00 	sub    0x5f038(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    db98:	48 c1 e2 10          	shl    $0x10,%rdx
    db9c:	48 39 d0             	cmp    %rdx,%rax
    db9f:	73 59                	jae    dbfa <f0+0x265a>
    dba1:	48 89 c2             	mov    %rax,%rdx
    dba4:	48 c1 ea 10          	shr    $0x10,%rdx
    dba8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dbac:	48 8b 15 65 f0 05 00 	mov    0x5f065(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    dbb3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dbb7:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dbbb:	4d 85 e4             	test   %r12,%r12
    dbbe:	74 3a                	je     dbfa <f0+0x265a>
    dbc0:	0f b6 0a             	movzbl (%rdx),%ecx
    dbc3:	80 f9 02             	cmp    $0x2,%cl
    dbc6:	0f 84 04 04 00 00    	je     dfd0 <f0+0x2a30>
    dbcc:	80 f9 01             	cmp    $0x1,%cl
    dbcf:	75 29                	jne    dbfa <f0+0x265a>
    dbd1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dbd4:	0f b7 c0             	movzwl %ax,%eax
    dbd7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dbda:	48 0f af c1          	imul   %rcx,%rax
    dbde:	48 c1 e8 20          	shr    $0x20,%rax
    dbe2:	48 39 d0             	cmp    %rdx,%rax
    dbe5:	73 13                	jae    dbfa <f0+0x265a>
    dbe7:	49 01 c4             	add    %rax,%r12
    dbea:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dbef:	0f 84 7d 06 00 00    	je     e272 <f0+0x2cd2>
    dbf5:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dbfa:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dc01:	33 f3 bf 
    dc04:	48 8d b4 24 20 08 00 	lea    0x820(%rsp),%rsi
    dc0b:	00 
    dc0c:	bf 01 00 00 00       	mov    $0x1,%edi
    dc11:	4c 89 ac 24 28 08 00 	mov    %r13,0x828(%rsp)
    dc18:	00 
    dc19:	48 89 84 24 20 08 00 	mov    %rax,0x820(%rsp)
    dc20:	00 
    dc21:	e8 da 84 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    dc26:	48 8b 15 cb ef 05 00 	mov    0x5efcb(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    dc2d:	49 89 c5             	mov    %rax,%r13
    dc30:	48 2b 05 99 ef 05 00 	sub    0x5ef99(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    dc37:	48 c1 e2 10          	shl    $0x10,%rdx
    dc3b:	48 39 d0             	cmp    %rdx,%rax
    dc3e:	73 59                	jae    dc99 <f0+0x26f9>
    dc40:	48 89 c2             	mov    %rax,%rdx
    dc43:	48 c1 ea 10          	shr    $0x10,%rdx
    dc47:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dc4b:	48 8b 15 c6 ef 05 00 	mov    0x5efc6(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    dc52:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dc56:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dc5a:	4d 85 e4             	test   %r12,%r12
    dc5d:	74 3a                	je     dc99 <f0+0x26f9>
    dc5f:	0f b6 0a             	movzbl (%rdx),%ecx
    dc62:	80 f9 02             	cmp    $0x2,%cl
    dc65:	0f 84 55 03 00 00    	je     dfc0 <f0+0x2a20>
    dc6b:	80 f9 01             	cmp    $0x1,%cl
    dc6e:	75 29                	jne    dc99 <f0+0x26f9>
    dc70:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dc73:	0f b7 c0             	movzwl %ax,%eax
    dc76:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dc79:	48 0f af c1          	imul   %rcx,%rax
    dc7d:	48 c1 e8 20          	shr    $0x20,%rax
    dc81:	48 39 d0             	cmp    %rdx,%rax
    dc84:	73 13                	jae    dc99 <f0+0x26f9>
    dc86:	49 01 c4             	add    %rax,%r12
    dc89:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dc8e:	0f 84 eb 05 00 00    	je     e27f <f0+0x2cdf>
    dc94:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dc99:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    dca0:	00 f0 3f 
    dca3:	48 8d b4 24 30 08 00 	lea    0x830(%rsp),%rsi
    dcaa:	00 
    dcab:	bf 01 00 00 00       	mov    $0x1,%edi
    dcb0:	4c 89 ac 24 38 08 00 	mov    %r13,0x838(%rsp)
    dcb7:	00 
    dcb8:	48 89 84 24 30 08 00 	mov    %rax,0x830(%rsp)
    dcbf:	00 
    dcc0:	e8 3b 84 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    dcc5:	48 8b 15 2c ef 05 00 	mov    0x5ef2c(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    dccc:	49 89 c5             	mov    %rax,%r13
    dccf:	48 2b 05 fa ee 05 00 	sub    0x5eefa(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    dcd6:	48 c1 e2 10          	shl    $0x10,%rdx
    dcda:	48 39 d0             	cmp    %rdx,%rax
    dcdd:	73 59                	jae    dd38 <f0+0x2798>
    dcdf:	48 89 c2             	mov    %rax,%rdx
    dce2:	48 c1 ea 10          	shr    $0x10,%rdx
    dce6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dcea:	48 8b 15 27 ef 05 00 	mov    0x5ef27(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    dcf1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dcf5:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dcf9:	4d 85 e4             	test   %r12,%r12
    dcfc:	74 3a                	je     dd38 <f0+0x2798>
    dcfe:	0f b6 0a             	movzbl (%rdx),%ecx
    dd01:	80 f9 02             	cmp    $0x2,%cl
    dd04:	0f 84 a6 02 00 00    	je     dfb0 <f0+0x2a10>
    dd0a:	80 f9 01             	cmp    $0x1,%cl
    dd0d:	75 29                	jne    dd38 <f0+0x2798>
    dd0f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    dd12:	0f b7 c0             	movzwl %ax,%eax
    dd15:	8b 52 1c             	mov    0x1c(%rdx),%edx
    dd18:	48 0f af c1          	imul   %rcx,%rax
    dd1c:	48 c1 e8 20          	shr    $0x20,%rax
    dd20:	48 39 d0             	cmp    %rdx,%rax
    dd23:	73 13                	jae    dd38 <f0+0x2798>
    dd25:	49 01 c4             	add    %rax,%r12
    dd28:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    dd2d:	0f 84 59 05 00 00    	je     e28c <f0+0x2cec>
    dd33:	41 c6 04 24 01       	movb   $0x1,(%r12)
    dd38:	48 89 ee             	mov    %rbp,%rsi
    dd3b:	bf 01 00 00 00       	mov    $0x1,%edi
    dd40:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    dd47:	33 f3 bf 
    dd4a:	4c 89 ac 24 48 08 00 	mov    %r13,0x848(%rsp)
    dd51:	00 
    dd52:	48 89 84 24 40 08 00 	mov    %rax,0x840(%rsp)
    dd59:	00 
    dd5a:	e8 a1 83 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    dd5f:	48 8b 15 92 ee 05 00 	mov    0x5ee92(%rip),%rdx        # 6cbf8 <fwp_heap+0x13d8>
    dd66:	48 89 c5             	mov    %rax,%rbp
    dd69:	48 2b 05 60 ee 05 00 	sub    0x5ee60(%rip),%rax        # 6cbd0 <fwp_heap+0x13b0>
    dd70:	48 c1 e2 10          	shl    $0x10,%rdx
    dd74:	48 39 d0             	cmp    %rdx,%rax
    dd77:	73 59                	jae    ddd2 <f0+0x2832>
    dd79:	48 89 c2             	mov    %rax,%rdx
    dd7c:	48 c1 ea 10          	shr    $0x10,%rdx
    dd80:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    dd84:	48 8b 15 8d ee 05 00 	mov    0x5ee8d(%rip),%rdx        # 6cc18 <fwp_heap+0x13f8>
    dd8b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    dd8f:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    dd93:	4d 85 e4             	test   %r12,%r12
    dd96:	74 3a                	je     ddd2 <f0+0x2832>
    dd98:	0f b6 0a             	movzbl (%rdx),%ecx
    dd9b:	80 f9 02             	cmp    $0x2,%cl
    dd9e:	0f 84 fc 01 00 00    	je     dfa0 <f0+0x2a00>
    dda4:	80 f9 01             	cmp    $0x1,%cl
    dda7:	75 29                	jne    ddd2 <f0+0x2832>
    dda9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ddac:	0f b7 c0             	movzwl %ax,%eax
    ddaf:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ddb2:	48 0f af c1          	imul   %rcx,%rax
    ddb6:	48 c1 e8 20          	shr    $0x20,%rax
    ddba:	48 39 d0             	cmp    %rdx,%rax
    ddbd:	73 13                	jae    ddd2 <f0+0x2832>
    ddbf:	49 01 c4             	add    %rax,%r12
    ddc2:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    ddc7:	0f 84 d1 02 00 00    	je     e09e <f0+0x2afe>
    ddcd:	41 c6 04 24 01       	movb   $0x1,(%r12)
    ddd2:	48 89 de             	mov    %rbx,%rsi
    ddd5:	48 89 ef             	mov    %rbp,%rdi
    ddd8:	e8 e3 bd ff ff       	call   9bc0 <fwp_hof0.constprop.0>
    dddd:	48 89 ef             	mov    %rbp,%rdi
    dde0:	e8 3b a2 ff ff       	call   8020 <fwp_drop0>
    dde5:	48 89 df             	mov    %rbx,%rdi
    dde8:	e8 33 a2 ff ff       	call   8020 <fwp_drop0>
    dded:	48 8b 84 24 58 08 00 	mov    0x858(%rsp),%rax
    ddf4:	00 
    ddf5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ddfc:	00 00 
    ddfe:	0f 85 95 04 00 00    	jne    e299 <f0+0x2cf9>
    de04:	48 81 c4 60 08 00 00 	add    $0x860,%rsp
    de0b:	31 c0                	xor    %eax,%eax
    de0d:	5b                   	pop    %rbx
    de0e:	5d                   	pop    %rbp
    de0f:	41 5c                	pop    %r12
    de11:	41 5d                	pop    %r13
    de13:	41 5e                	pop    %r14
    de15:	c3                   	ret
    de16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    de1d:	00 00 00 
    de20:	4c 89 ef             	mov    %r13,%rdi
    de23:	e8 a8 79 ff ff       	call   57d0 <fwp_rc_forget_slot>
    de28:	e9 2c d8 ff ff       	jmp    b659 <f0+0xb9>
    de2d:	0f 1f 00             	nopl   (%rax)
    de30:	66 85 c0             	test   %ax,%ax
    de33:	0f 85 ae f5 ff ff    	jne    d3e7 <f0+0x1e47>
    de39:	e9 99 f5 ff ff       	jmp    d3d7 <f0+0x1e37>
    de3e:	66 90                	xchg   %ax,%ax
    de40:	66 85 c0             	test   %ax,%ax
    de43:	0f 85 ff f4 ff ff    	jne    d348 <f0+0x1da8>
    de49:	e9 ea f4 ff ff       	jmp    d338 <f0+0x1d98>
    de4e:	66 90                	xchg   %ax,%ax
    de50:	66 85 c0             	test   %ax,%ax
    de53:	0f 85 50 f4 ff ff    	jne    d2a9 <f0+0x1d09>
    de59:	e9 3b f4 ff ff       	jmp    d299 <f0+0x1cf9>
    de5e:	66 90                	xchg   %ax,%ax
    de60:	66 85 c0             	test   %ax,%ax
    de63:	0f 85 a1 f3 ff ff    	jne    d20a <f0+0x1c6a>
    de69:	e9 8c f3 ff ff       	jmp    d1fa <f0+0x1c5a>
    de6e:	66 90                	xchg   %ax,%ax
    de70:	66 85 c0             	test   %ax,%ax
    de73:	0f 85 f2 f2 ff ff    	jne    d16b <f0+0x1bcb>
    de79:	e9 dd f2 ff ff       	jmp    d15b <f0+0x1bbb>
    de7e:	66 90                	xchg   %ax,%ax
    de80:	66 85 c0             	test   %ax,%ax
    de83:	0f 85 43 f2 ff ff    	jne    d0cc <f0+0x1b2c>
    de89:	e9 2e f2 ff ff       	jmp    d0bc <f0+0x1b1c>
    de8e:	66 90                	xchg   %ax,%ax
    de90:	66 85 c0             	test   %ax,%ax
    de93:	0f 85 94 f1 ff ff    	jne    d02d <f0+0x1a8d>
    de99:	e9 7f f1 ff ff       	jmp    d01d <f0+0x1a7d>
    de9e:	66 90                	xchg   %ax,%ax
    dea0:	66 85 c0             	test   %ax,%ax
    dea3:	0f 85 e5 f0 ff ff    	jne    cf8e <f0+0x19ee>
    dea9:	e9 d0 f0 ff ff       	jmp    cf7e <f0+0x19de>
    deae:	66 90                	xchg   %ax,%ax
    deb0:	66 85 c0             	test   %ax,%ax
    deb3:	0f 85 fd d9 ff ff    	jne    b8b6 <f0+0x316>
    deb9:	e9 e8 d9 ff ff       	jmp    b8a6 <f0+0x306>
    debe:	66 90                	xchg   %ax,%ax
    dec0:	66 85 c0             	test   %ax,%ax
    dec3:	0f 85 57 d9 ff ff    	jne    b820 <f0+0x280>
    dec9:	e9 42 d9 ff ff       	jmp    b810 <f0+0x270>
    dece:	66 90                	xchg   %ax,%ax
    ded0:	66 85 c0             	test   %ax,%ax
    ded3:	0f 85 b1 d8 ff ff    	jne    b78a <f0+0x1ea>
    ded9:	e9 9c d8 ff ff       	jmp    b77a <f0+0x1da>
    dede:	66 90                	xchg   %ax,%ax
    dee0:	66 85 c0             	test   %ax,%ax
    dee3:	0f 85 0e eb ff ff    	jne    c9f7 <f0+0x1457>
    dee9:	e9 f9 ea ff ff       	jmp    c9e7 <f0+0x1447>
    deee:	66 90                	xchg   %ax,%ax
    def0:	66 85 c0             	test   %ax,%ax
    def3:	0f 85 5f ea ff ff    	jne    c958 <f0+0x13b8>
    def9:	e9 4a ea ff ff       	jmp    c948 <f0+0x13a8>
    defe:	66 90                	xchg   %ax,%ax
    df00:	66 85 c0             	test   %ax,%ax
    df03:	0f 85 e2 da ff ff    	jne    b9eb <f0+0x44b>
    df09:	e9 cd da ff ff       	jmp    b9db <f0+0x43b>
    df0e:	66 90                	xchg   %ax,%ax
    df10:	66 85 c0             	test   %ax,%ax
    df13:	0f 85 33 da ff ff    	jne    b94c <f0+0x3ac>
    df19:	e9 1e da ff ff       	jmp    b93c <f0+0x39c>
    df1e:	66 90                	xchg   %ax,%ax
    df20:	66 85 c0             	test   %ax,%ax
    df23:	0f 85 c6 ef ff ff    	jne    ceef <f0+0x194f>
    df29:	e9 b1 ef ff ff       	jmp    cedf <f0+0x193f>
    df2e:	66 90                	xchg   %ax,%ax
    df30:	66 85 c0             	test   %ax,%ax
    df33:	0f 85 17 ef ff ff    	jne    ce50 <f0+0x18b0>
    df39:	e9 02 ef ff ff       	jmp    ce40 <f0+0x18a0>
    df3e:	66 90                	xchg   %ax,%ax
    df40:	66 85 c0             	test   %ax,%ax
    df43:	0f 85 68 ee ff ff    	jne    cdb1 <f0+0x1811>
    df49:	e9 53 ee ff ff       	jmp    cda1 <f0+0x1801>
    df4e:	66 90                	xchg   %ax,%ax
    df50:	66 85 c0             	test   %ax,%ax
    df53:	0f 85 b9 ed ff ff    	jne    cd12 <f0+0x1772>
    df59:	e9 a4 ed ff ff       	jmp    cd02 <f0+0x1762>
    df5e:	66 90                	xchg   %ax,%ax
    df60:	66 85 c0             	test   %ax,%ax
    df63:	0f 85 0a ed ff ff    	jne    cc73 <f0+0x16d3>
    df69:	e9 f5 ec ff ff       	jmp    cc63 <f0+0x16c3>
    df6e:	66 90                	xchg   %ax,%ax
    df70:	66 85 c0             	test   %ax,%ax
    df73:	0f 85 5b ec ff ff    	jne    cbd4 <f0+0x1634>
    df79:	e9 46 ec ff ff       	jmp    cbc4 <f0+0x1624>
    df7e:	66 90                	xchg   %ax,%ax
    df80:	66 85 c0             	test   %ax,%ax
    df83:	0f 85 ac eb ff ff    	jne    cb35 <f0+0x1595>
    df89:	e9 97 eb ff ff       	jmp    cb25 <f0+0x1585>
    df8e:	66 90                	xchg   %ax,%ax
    df90:	66 85 c0             	test   %ax,%ax
    df93:	0f 85 fd ea ff ff    	jne    ca96 <f0+0x14f6>
    df99:	e9 e8 ea ff ff       	jmp    ca86 <f0+0x14e6>
    df9e:	66 90                	xchg   %ax,%ax
    dfa0:	66 85 c0             	test   %ax,%ax
    dfa3:	0f 85 29 fe ff ff    	jne    ddd2 <f0+0x2832>
    dfa9:	e9 14 fe ff ff       	jmp    ddc2 <f0+0x2822>
    dfae:	66 90                	xchg   %ax,%ax
    dfb0:	66 85 c0             	test   %ax,%ax
    dfb3:	0f 85 7f fd ff ff    	jne    dd38 <f0+0x2798>
    dfb9:	e9 6a fd ff ff       	jmp    dd28 <f0+0x2788>
    dfbe:	66 90                	xchg   %ax,%ax
    dfc0:	66 85 c0             	test   %ax,%ax
    dfc3:	0f 85 d0 fc ff ff    	jne    dc99 <f0+0x26f9>
    dfc9:	e9 bb fc ff ff       	jmp    dc89 <f0+0x26e9>
    dfce:	66 90                	xchg   %ax,%ax
    dfd0:	66 85 c0             	test   %ax,%ax
    dfd3:	0f 85 21 fc ff ff    	jne    dbfa <f0+0x265a>
    dfd9:	e9 0c fc ff ff       	jmp    dbea <f0+0x264a>
    dfde:	66 90                	xchg   %ax,%ax
    dfe0:	66 85 c0             	test   %ax,%ax
    dfe3:	0f 85 72 fb ff ff    	jne    db5b <f0+0x25bb>
    dfe9:	e9 5d fb ff ff       	jmp    db4b <f0+0x25ab>
    dfee:	66 90                	xchg   %ax,%ax
    dff0:	66 85 c0             	test   %ax,%ax
    dff3:	0f 85 c3 fa ff ff    	jne    dabc <f0+0x251c>
    dff9:	e9 ae fa ff ff       	jmp    daac <f0+0x250c>
    dffe:	66 90                	xchg   %ax,%ax
    e000:	66 85 c0             	test   %ax,%ax
    e003:	0f 85 14 fa ff ff    	jne    da1d <f0+0x247d>
    e009:	e9 ff f9 ff ff       	jmp    da0d <f0+0x246d>
    e00e:	66 90                	xchg   %ax,%ax
    e010:	66 85 c0             	test   %ax,%ax
    e013:	0f 85 65 f9 ff ff    	jne    d97e <f0+0x23de>
    e019:	e9 50 f9 ff ff       	jmp    d96e <f0+0x23ce>
    e01e:	66 90                	xchg   %ax,%ax
    e020:	66 85 c0             	test   %ax,%ax
    e023:	0f 85 b6 f8 ff ff    	jne    d8df <f0+0x233f>
    e029:	e9 a1 f8 ff ff       	jmp    d8cf <f0+0x232f>
    e02e:	66 90                	xchg   %ax,%ax
    e030:	66 85 c0             	test   %ax,%ax
    e033:	0f 85 07 f8 ff ff    	jne    d840 <f0+0x22a0>
    e039:	e9 f2 f7 ff ff       	jmp    d830 <f0+0x2290>
    e03e:	66 90                	xchg   %ax,%ax
    e040:	66 85 c0             	test   %ax,%ax
    e043:	0f 85 58 f7 ff ff    	jne    d7a1 <f0+0x2201>
    e049:	e9 43 f7 ff ff       	jmp    d791 <f0+0x21f1>
    e04e:	66 90                	xchg   %ax,%ax
    e050:	66 85 c0             	test   %ax,%ax
    e053:	0f 85 a9 f6 ff ff    	jne    d702 <f0+0x2162>
    e059:	e9 94 f6 ff ff       	jmp    d6f2 <f0+0x2152>
    e05e:	66 90                	xchg   %ax,%ax
    e060:	66 85 c0             	test   %ax,%ax
    e063:	0f 85 fa f5 ff ff    	jne    d663 <f0+0x20c3>
    e069:	e9 e5 f5 ff ff       	jmp    d653 <f0+0x20b3>
    e06e:	66 90                	xchg   %ax,%ax
    e070:	66 85 c0             	test   %ax,%ax
    e073:	0f 85 4b f5 ff ff    	jne    d5c4 <f0+0x2024>
    e079:	e9 36 f5 ff ff       	jmp    d5b4 <f0+0x2014>
    e07e:	66 90                	xchg   %ax,%ax
    e080:	66 85 c0             	test   %ax,%ax
    e083:	0f 85 9c f4 ff ff    	jne    d525 <f0+0x1f85>
    e089:	e9 87 f4 ff ff       	jmp    d515 <f0+0x1f75>
    e08e:	66 90                	xchg   %ax,%ax
    e090:	66 85 c0             	test   %ax,%ax
    e093:	0f 85 ed f3 ff ff    	jne    d486 <f0+0x1ee6>
    e099:	e9 d8 f3 ff ff       	jmp    d476 <f0+0x1ed6>
    e09e:	4c 89 e7             	mov    %r12,%rdi
    e0a1:	e8 2a 77 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0a6:	e9 22 fd ff ff       	jmp    ddcd <f0+0x282d>
    e0ab:	4c 89 e7             	mov    %r12,%rdi
    e0ae:	e8 1d 77 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0b3:	e9 cd d6 ff ff       	jmp    b785 <f0+0x1e5>
    e0b8:	4c 89 e7             	mov    %r12,%rdi
    e0bb:	e8 10 77 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0c0:	e9 56 d7 ff ff       	jmp    b81b <f0+0x27b>
    e0c5:	4c 89 e7             	mov    %r12,%rdi
    e0c8:	e8 03 77 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0cd:	e9 df d7 ff ff       	jmp    b8b1 <f0+0x311>
    e0d2:	4c 89 e7             	mov    %r12,%rdi
    e0d5:	e8 f6 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0da:	e9 68 d8 ff ff       	jmp    b947 <f0+0x3a7>
    e0df:	4c 89 e7             	mov    %r12,%rdi
    e0e2:	e8 e9 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0e7:	e9 fa d8 ff ff       	jmp    b9e6 <f0+0x446>
    e0ec:	4c 89 e7             	mov    %r12,%rdi
    e0ef:	e8 dc 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e0f4:	e9 5a e8 ff ff       	jmp    c953 <f0+0x13b3>
    e0f9:	4c 89 e7             	mov    %r12,%rdi
    e0fc:	e8 cf 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e101:	e9 ec e8 ff ff       	jmp    c9f2 <f0+0x1452>
    e106:	4c 89 e7             	mov    %r12,%rdi
    e109:	e8 c2 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e10e:	e9 7e e9 ff ff       	jmp    ca91 <f0+0x14f1>
    e113:	4c 89 e7             	mov    %r12,%rdi
    e116:	e8 b5 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e11b:	e9 10 ea ff ff       	jmp    cb30 <f0+0x1590>
    e120:	4c 89 e7             	mov    %r12,%rdi
    e123:	e8 a8 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e128:	e9 a2 ea ff ff       	jmp    cbcf <f0+0x162f>
    e12d:	4c 89 e7             	mov    %r12,%rdi
    e130:	e8 9b 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e135:	e9 34 eb ff ff       	jmp    cc6e <f0+0x16ce>
    e13a:	4c 89 e7             	mov    %r12,%rdi
    e13d:	e8 8e 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e142:	e9 c6 eb ff ff       	jmp    cd0d <f0+0x176d>
    e147:	4c 89 e7             	mov    %r12,%rdi
    e14a:	e8 81 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e14f:	e9 58 ec ff ff       	jmp    cdac <f0+0x180c>
    e154:	4c 89 e7             	mov    %r12,%rdi
    e157:	e8 74 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e15c:	e9 ea ec ff ff       	jmp    ce4b <f0+0x18ab>
    e161:	4c 89 e7             	mov    %r12,%rdi
    e164:	e8 67 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e169:	e9 7c ed ff ff       	jmp    ceea <f0+0x194a>
    e16e:	4c 89 e7             	mov    %r12,%rdi
    e171:	e8 5a 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e176:	e9 0e ee ff ff       	jmp    cf89 <f0+0x19e9>
    e17b:	4c 89 e7             	mov    %r12,%rdi
    e17e:	e8 4d 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e183:	e9 a0 ee ff ff       	jmp    d028 <f0+0x1a88>
    e188:	4c 89 e7             	mov    %r12,%rdi
    e18b:	e8 40 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e190:	e9 32 ef ff ff       	jmp    d0c7 <f0+0x1b27>
    e195:	4c 89 e7             	mov    %r12,%rdi
    e198:	e8 33 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e19d:	e9 c4 ef ff ff       	jmp    d166 <f0+0x1bc6>
    e1a2:	4c 89 e7             	mov    %r12,%rdi
    e1a5:	e8 26 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1aa:	e9 56 f0 ff ff       	jmp    d205 <f0+0x1c65>
    e1af:	4c 89 e7             	mov    %r12,%rdi
    e1b2:	e8 19 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1b7:	e9 e8 f0 ff ff       	jmp    d2a4 <f0+0x1d04>
    e1bc:	4c 89 e7             	mov    %r12,%rdi
    e1bf:	e8 0c 76 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1c4:	e9 7a f1 ff ff       	jmp    d343 <f0+0x1da3>
    e1c9:	4c 89 e7             	mov    %r12,%rdi
    e1cc:	e8 ff 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1d1:	e9 0c f2 ff ff       	jmp    d3e2 <f0+0x1e42>
    e1d6:	4c 89 e7             	mov    %r12,%rdi
    e1d9:	e8 f2 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1de:	e9 9e f2 ff ff       	jmp    d481 <f0+0x1ee1>
    e1e3:	4c 89 e7             	mov    %r12,%rdi
    e1e6:	e8 e5 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1eb:	e9 30 f3 ff ff       	jmp    d520 <f0+0x1f80>
    e1f0:	4c 89 e7             	mov    %r12,%rdi
    e1f3:	e8 d8 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e1f8:	e9 c2 f3 ff ff       	jmp    d5bf <f0+0x201f>
    e1fd:	4c 89 e7             	mov    %r12,%rdi
    e200:	e8 cb 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e205:	e9 54 f4 ff ff       	jmp    d65e <f0+0x20be>
    e20a:	4c 89 e7             	mov    %r12,%rdi
    e20d:	e8 be 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e212:	e9 e6 f4 ff ff       	jmp    d6fd <f0+0x215d>
    e217:	4c 89 e7             	mov    %r12,%rdi
    e21a:	e8 b1 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e21f:	e9 78 f5 ff ff       	jmp    d79c <f0+0x21fc>
    e224:	4c 89 e7             	mov    %r12,%rdi
    e227:	e8 a4 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e22c:	e9 0a f6 ff ff       	jmp    d83b <f0+0x229b>
    e231:	4c 89 e7             	mov    %r12,%rdi
    e234:	e8 97 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e239:	e9 9c f6 ff ff       	jmp    d8da <f0+0x233a>
    e23e:	4c 89 e7             	mov    %r12,%rdi
    e241:	e8 8a 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e246:	e9 2e f7 ff ff       	jmp    d979 <f0+0x23d9>
    e24b:	4c 89 e7             	mov    %r12,%rdi
    e24e:	e8 7d 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e253:	e9 c0 f7 ff ff       	jmp    da18 <f0+0x2478>
    e258:	4c 89 e7             	mov    %r12,%rdi
    e25b:	e8 70 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e260:	e9 52 f8 ff ff       	jmp    dab7 <f0+0x2517>
    e265:	4c 89 e7             	mov    %r12,%rdi
    e268:	e8 63 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e26d:	e9 e4 f8 ff ff       	jmp    db56 <f0+0x25b6>
    e272:	4c 89 e7             	mov    %r12,%rdi
    e275:	e8 56 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e27a:	e9 76 f9 ff ff       	jmp    dbf5 <f0+0x2655>
    e27f:	4c 89 e7             	mov    %r12,%rdi
    e282:	e8 49 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e287:	e9 08 fa ff ff       	jmp    dc94 <f0+0x26f4>
    e28c:	4c 89 e7             	mov    %r12,%rdi
    e28f:	e8 3c 75 ff ff       	call   57d0 <fwp_rc_forget_slot>
    e294:	e9 9a fa ff ff       	jmp    dd33 <f0+0x2793>
    e299:	e8 b2 51 ff ff       	call   3450 <__stack_chk_fail@plt>
    e29e:	66 90                	xchg   %ax,%ax

000000000000e2a0 <fwp_main_thread>:
    e2a0:	f3 0f 1e fa          	endbr64
    e2a4:	41 54                	push   %r12
    e2a6:	55                   	push   %rbp
    e2a7:	53                   	push   %rbx
    e2a8:	48 81 ec d0 00 00 00 	sub    $0xd0,%rsp
    e2af:	8b 0d 0f e9 05 00    	mov    0x5e90f(%rip),%ecx        # 6cbc4 <fwp_heap+0x13a4>
    e2b5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    e2bc:	00 00 
    e2be:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    e2c5:	00 
    e2c6:	31 c0                	xor    %eax,%eax
    e2c8:	85 c9                	test   %ecx,%ecx
    e2ca:	0f 84 58 07 00 00    	je     ea28 <fwp_main_thread+0x788>
    e2d0:	8b 15 f2 e8 05 00    	mov    0x5e8f2(%rip),%edx        # 6cbc8 <fwp_heap+0x13a8>
    e2d6:	85 d2                	test   %edx,%edx
    e2d8:	0f 85 32 07 00 00    	jne    ea10 <fwp_main_thread+0x770>
    e2de:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
    e2e3:	31 f6                	xor    %esi,%esi
    e2e5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    e2ea:	48 c7 05 cb ce 05 00 	movq   $0x40000000,0x5cecb(%rip)        # 6b1c0 <fwp_main_stack_size>
    e2f1:	00 00 00 40 
    e2f5:	48 89 05 cc ce 05 00 	mov    %rax,0x5cecc(%rip)        # 6b1c8 <fwp_main_stack_top>
    e2fc:	48 8d 05 7d 4d 00 00 	lea    0x4d7d(%rip),%rax        # 13080 <alt.5>
    e303:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    e308:	48 c7 44 24 20 00 00 	movq   $0x10000,0x20(%rsp)
    e30f:	01 00 
    e311:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
    e318:	00 
    e319:	e8 82 53 ff ff       	call   36a0 <sigaltstack@plt>
    e31e:	85 c0                	test   %eax,%eax
    e320:	0f 85 6a 07 00 00    	jne    ea90 <fwp_main_thread+0x7f0>
    e326:	31 c0                	xor    %eax,%eax
    e328:	b9 12 00 00 00       	mov    $0x12,%ecx
    e32d:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e332:	f3 48 ab             	rep stos %rax,(%rdi)
    e335:	48 8d 05 04 5a ff ff 	lea    -0xa5fc(%rip),%rax        # 3d40 <fwp_segv>
    e33c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
    e341:	c7 84 24 b8 00 00 00 	movl   $0x8000004,0xb8(%rsp)
    e348:	04 00 00 08 
    e34c:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    e351:	e8 0a 52 ff ff       	call   3560 <sigemptyset@plt>
    e356:	85 c0                	test   %eax,%eax
    e358:	0f 85 32 07 00 00    	jne    ea90 <fwp_main_thread+0x7f0>
    e35e:	31 d2                	xor    %edx,%edx
    e360:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e365:	bf 0b 00 00 00       	mov    $0xb,%edi
    e36a:	e8 81 50 ff ff       	call   33f0 <sigaction@plt>
    e36f:	85 c0                	test   %eax,%eax
    e371:	0f 85 19 07 00 00    	jne    ea90 <fwp_main_thread+0x7f0>
    e377:	31 d2                	xor    %edx,%edx
    e379:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
    e37e:	bf 07 00 00 00       	mov    $0x7,%edi
    e383:	e8 68 50 ff ff       	call   33f0 <sigaction@plt>
    e388:	85 c0                	test   %eax,%eax
    e38a:	0f 85 00 07 00 00    	jne    ea90 <fwp_main_thread+0x7f0>
    e390:	48 8b 05 a9 e8 05 00 	mov    0x5e8a9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e397:	48 85 c0             	test   %rax,%rax
    e39a:	0f 88 50 06 00 00    	js     e9f0 <fwp_main_thread+0x750>
    e3a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e3a4:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    e3a9:	48 8d 3d 70 5e ff ff 	lea    -0xa190(%rip),%rdi        # 4220 <ad_raw_report>
    e3b0:	f2 0f 11 05 10 f1 05 	movsd  %xmm0,0x5f110(%rip)        # 6d4c8 <iteration_start_charge>
    e3b7:	00 
    e3b8:	c7 05 26 f1 05 00 01 	movl   $0x1,0x5f126(%rip)        # 6d4e8 <iteration_active>
    e3bf:	00 00 00 
    e3c2:	e8 09 09 00 00       	call   ecd0 <atexit>
    e3c7:	85 c0                	test   %eax,%eax
    e3c9:	0f 85 cd 06 00 00    	jne    ea9c <fwp_main_thread+0x7fc>
    e3cf:	8b 05 9b 4c 00 00    	mov    0x4c9b(%rip),%eax        # 13070 <st.3>
    e3d5:	85 c0                	test   %eax,%eax
    e3d7:	0f 84 5b 06 00 00    	je     ea38 <fwp_main_thread+0x798>
    e3dd:	48 8b 2d 1c d4 05 00 	mov    0x5d41c(%rip),%rbp        # 6b800 <fwp_cur>
    e3e4:	48 85 ed             	test   %rbp,%rbp
    e3e7:	0f 84 03 03 00 00    	je     e6f0 <fwp_main_thread+0x450>
    e3ed:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    e3f2:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    e3f6:	48 89 eb             	mov    %rbp,%rbx
    e3f9:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e3fe:	0f 84 41 01 00 00    	je     e545 <fwp_main_thread+0x2a5>
    e404:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    e409:	0f 84 11 02 00 00    	je     e620 <fwp_main_thread+0x380>
    e40f:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e413:	0f 84 f7 01 00 00    	je     e610 <fwp_main_thread+0x370>
    e419:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e41d:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e421:	0f 85 79 02 00 00    	jne    e6a0 <fwp_main_thread+0x400>
    e427:	48 8b 43 60          	mov    0x60(%rbx),%rax
    e42b:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e432:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e436:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e43d:	00 00 00 00 
    e441:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e448:	48 85 d2             	test   %rdx,%rdx
    e44b:	74 07                	je     e454 <fwp_main_thread+0x1b4>
    e44d:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e454:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e458:	48 85 c0             	test   %rax,%rax
    e45b:	74 34                	je     e491 <fwp_main_thread+0x1f1>
    e45d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    e461:	48 8b 05 70 d3 05 00 	mov    0x5d370(%rip),%rax        # 6b7d8 <fwp_timers>
    e468:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    e46c:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    e473:	00 00 00 00 
    e477:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    e47e:	48 85 c0             	test   %rax,%rax
    e481:	74 07                	je     e48a <fwp_main_thread+0x1ea>
    e483:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    e48a:	48 89 1d 47 d3 05 00 	mov    %rbx,0x5d347(%rip)        # 6b7d8 <fwp_timers>
    e491:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    e495:	e8 16 97 ff ff       	call   7bb0 <fwp_block>
    e49a:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    e4a1:	48 85 c9             	test   %rcx,%rcx
    e4a4:	74 47                	je     e4ed <fwp_main_thread+0x24d>
    e4a6:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    e4ad:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e4b4:	48 85 d2             	test   %rdx,%rdx
    e4b7:	0f 84 23 02 00 00    	je     e6e0 <fwp_main_thread+0x440>
    e4bd:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    e4c4:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    e4cb:	48 85 c0             	test   %rax,%rax
    e4ce:	74 07                	je     e4d7 <fwp_main_thread+0x237>
    e4d0:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    e4d7:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    e4de:	00 00 00 00 
    e4e2:	66 0f ef d2          	pxor   %xmm2,%xmm2
    e4e6:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    e4ed:	48 8b 0d 0c d3 05 00 	mov    0x5d30c(%rip),%rcx        # 6b800 <fwp_cur>
    e4f4:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    e4f8:	0f 84 92 01 00 00    	je     e690 <fwp_main_thread+0x3f0>
    e4fe:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    e505:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    e50c:	48 85 d2             	test   %rdx,%rdx
    e50f:	0f 84 1b 04 00 00    	je     e930 <fwp_main_thread+0x690>
    e515:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    e51c:	48 85 c0             	test   %rax,%rax
    e51f:	74 07                	je     e528 <fwp_main_thread+0x288>
    e521:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    e528:	66 0f ef db          	pxor   %xmm3,%xmm3
    e52c:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    e530:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    e537:	48 89 cb             	mov    %rcx,%rbx
    e53a:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    e53f:	0f 85 bf fe ff ff    	jne    e404 <fwp_main_thread+0x164>
    e545:	48 83 3d 4b ef 05 00 	cmpq   $0x0,0x5ef4b(%rip)        # 6d498 <fwp_state_len>
    e54c:	00 
    e54d:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    e551:	0f 84 0b 04 00 00    	je     e962 <fwp_main_thread+0x6c2>
    e557:	48 3b 1d 9a d2 05 00 	cmp    0x5d29a(%rip),%rbx        # 6b7f8 <fwp_root>
    e55e:	c7 05 18 4b 01 00 00 	movl   $0x0,0x14b18(%rip)        # 23080 <fwp_exit_code>
    e565:	00 00 00 
    e568:	0f 85 4c 05 00 00    	jne    eaba <fwp_main_thread+0x81a>
    e56e:	48 85 db             	test   %rbx,%rbx
    e571:	0f 84 9f 01 00 00    	je     e716 <fwp_main_thread+0x476>
    e577:	48 8b 15 4a d2 05 00 	mov    0x5d24a(%rip),%rdx        # 6b7c8 <fwp_tasks_active>
    e57e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    e582:	48 85 d2             	test   %rdx,%rdx
    e585:	0f 84 8b 01 00 00    	je     e716 <fwp_main_thread+0x476>
    e58b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e590:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    e594:	75 08                	jne    e59e <fwp_main_thread+0x2fe>
    e596:	48 89 d7             	mov    %rdx,%rdi
    e599:	e8 92 5b ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e59e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    e5a5:	48 85 d2             	test   %rdx,%rdx
    e5a8:	75 e6                	jne    e590 <fwp_main_thread+0x2f0>
    e5aa:	eb 31                	jmp    e5dd <fwp_main_thread+0x33d>
    e5ac:	0f 1f 40 00          	nopl   0x0(%rax)
    e5b0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    e5b7:	48 89 1d 22 d2 05 00 	mov    %rbx,0x5d222(%rip)        # 6b7e0 <fwp_ready_tail>
    e5be:	e8 ed 95 ff ff       	call   7bb0 <fwp_block>
    e5c3:	e8 d8 93 ff ff       	call   79a0 <fwp_free_zombie>
    e5c8:	48 83 3d f8 d1 05 00 	cmpq   $0x0,0x5d1f8(%rip)        # 6b7c8 <fwp_tasks_active>
    e5cf:	00 
    e5d0:	0f 84 40 01 00 00    	je     e716 <fwp_main_thread+0x476>
    e5d6:	48 8b 1d 1b d2 05 00 	mov    0x5d21b(%rip),%rbx        # 6b7f8 <fwp_root>
    e5dd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    e5e1:	75 db                	jne    e5be <fwp_main_thread+0x31e>
    e5e3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    e5e7:	75 d5                	jne    e5be <fwp_main_thread+0x31e>
    e5e9:	48 8b 05 f0 d1 05 00 	mov    0x5d1f0(%rip),%rax        # 6b7e0 <fwp_ready_tail>
    e5f0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    e5f4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    e5fb:	00 00 00 00 
    e5ff:	48 85 c0             	test   %rax,%rax
    e602:	75 ac                	jne    e5b0 <fwp_main_thread+0x310>
    e604:	48 89 1d dd d1 05 00 	mov    %rbx,0x5d1dd(%rip)        # 6b7e8 <fwp_ready_head>
    e60b:	eb aa                	jmp    e5b7 <fwp_main_thread+0x317>
    e60d:	0f 1f 00             	nopl   (%rax)
    e610:	e8 ab 5f ff ff       	call   45c0 <fwp_now_ns>
    e615:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    e619:	0f 8d 21 03 00 00    	jge    e940 <fwp_main_thread+0x6a0>
    e61f:	90                   	nop
    e620:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    e624:	0f 85 ef fd ff ff    	jne    e419 <fwp_main_thread+0x179>
    e62a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    e62e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    e632:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    e636:	0f 85 ef fd ff ff    	jne    e42b <fwp_main_thread+0x18b>
    e63c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    e640:	48 85 c9             	test   %rcx,%rcx
    e643:	0f 84 e2 fd ff ff    	je     e42b <fwp_main_thread+0x18b>
    e649:	48 85 c0             	test   %rax,%rax
    e64c:	0f 84 5b 04 00 00    	je     eaad <fwp_main_thread+0x80d>
    e652:	48 39 c8             	cmp    %rcx,%rax
    e655:	48 0f 4f c1          	cmovg  %rcx,%rax
    e659:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e660:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    e664:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e66b:	00 00 00 00 
    e66f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    e676:	48 85 d2             	test   %rdx,%rdx
    e679:	74 07                	je     e682 <fwp_main_thread+0x3e2>
    e67b:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    e682:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e686:	e9 d2 fd ff ff       	jmp    e45d <fwp_main_thread+0x1bd>
    e68b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    e690:	48 89 cb             	mov    %rcx,%rbx
    e693:	e9 61 fd ff ff       	jmp    e3f9 <fwp_main_thread+0x159>
    e698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e69f:	00 
    e6a0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    e6a4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    e6ab:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    e6b2:	00 00 00 00 
    e6b6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    e6bd:	48 85 c0             	test   %rax,%rax
    e6c0:	0f 84 9a 03 00 00    	je     ea60 <fwp_main_thread+0x7c0>
    e6c6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    e6cd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    e6d1:	e9 bb fd ff ff       	jmp    e491 <fwp_main_thread+0x1f1>
    e6d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e6dd:	00 00 00 
    e6e0:	48 89 01             	mov    %rax,(%rcx)
    e6e3:	e9 e3 fd ff ff       	jmp    e4cb <fwp_main_thread+0x22b>
    e6e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    e6ef:	00 
    e6f0:	48 83 3d a0 ed 05 00 	cmpq   $0x0,0x5eda0(%rip)        # 6d498 <fwp_state_len>
    e6f7:	00 
    e6f8:	0f 84 62 02 00 00    	je     e960 <fwp_main_thread+0x6c0>
    e6fe:	48 83 3d f2 d0 05 00 	cmpq   $0x0,0x5d0f2(%rip)        # 6b7f8 <fwp_root>
    e705:	00 
    e706:	c7 05 70 49 01 00 00 	movl   $0x0,0x14970(%rip)        # 23080 <fwp_exit_code>
    e70d:	00 00 00 
    e710:	0f 85 9f 03 00 00    	jne    eab5 <fwp_main_thread+0x815>
    e716:	e8 85 92 ff ff       	call   79a0 <fwp_free_zombie>
    e71b:	48 83 3d c5 d0 05 00 	cmpq   $0x0,0x5d0c5(%rip)        # 6b7e8 <fwp_ready_head>
    e722:	00 
    e723:	0f 85 2c 50 ff ff    	jne    3755 <fwp_main_thread.cold>
    e729:	48 83 3d a7 d0 05 00 	cmpq   $0x0,0x5d0a7(%rip)        # 6b7d8 <fwp_timers>
    e730:	00 
    e731:	0f 85 1e 50 ff ff    	jne    3755 <fwp_main_thread.cold>
    e737:	8b 1d 97 ca 05 00    	mov    0x5ca97(%rip),%ebx        # 6b1d4 <fwp_stack_pool_n>
    e73d:	85 db                	test   %ebx,%ebx
    e73f:	74 36                	je     e777 <fwp_main_thread+0x4d7>
    e741:	83 eb 01             	sub    $0x1,%ebx
    e744:	48 8d 05 95 ca 05 00 	lea    0x5ca95(%rip),%rax        # 6b1e0 <fwp_stack_pool>
    e74b:	48 63 d3             	movslq %ebx,%rdx
    e74e:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    e752:	eb 07                	jmp    e75b <fwp_main_thread+0x4bb>
    e754:	0f 1f 40 00          	nopl   0x0(%rax)
    e758:	83 eb 01             	sub    $0x1,%ebx
    e75b:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    e75f:	be 00 00 00 10       	mov    $0x10000000,%esi
    e764:	89 1d 6a ca 05 00    	mov    %ebx,0x5ca6a(%rip)        # 6b1d4 <fwp_stack_pool_n>
    e76a:	48 83 ed 08          	sub    $0x8,%rbp
    e76e:	e8 4d 4e ff ff       	call   35c0 <munmap@plt>
    e773:	85 db                	test   %ebx,%ebx
    e775:	75 e1                	jne    e758 <fwp_main_thread+0x4b8>
    e777:	8b 3d 9b 48 00 00    	mov    0x489b(%rip),%edi        # 13018 <fwp_epfd>
    e77d:	85 ff                	test   %edi,%edi
    e77f:	78 05                	js     e786 <fwp_main_thread+0x4e6>
    e781:	e8 3a 4d ff ff       	call   34c0 <close@plt>
    e786:	4c 8b 25 53 cc 05 00 	mov    0x5cc53(%rip),%r12        # 6b3e0 <fwp_nfdws>
    e78d:	48 8b 2d 54 cc 05 00 	mov    0x5cc54(%rip),%rbp        # 6b3e8 <fwp_fdws>
    e794:	31 db                	xor    %ebx,%ebx
    e796:	c7 05 78 48 00 00 ff 	movl   $0xffffffff,0x4878(%rip)        # 13018 <fwp_epfd>
    e79d:	ff ff ff 
    e7a0:	4d 85 e4             	test   %r12,%r12
    e7a3:	74 38                	je     e7dd <fwp_main_thread+0x53d>
    e7a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    e7ac:	00 00 00 00 
    e7b0:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    e7b5:	48 85 ff             	test   %rdi,%rdi
    e7b8:	74 1a                	je     e7d4 <fwp_main_thread+0x534>
    e7ba:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    e7be:	0f 85 91 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e7c4:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    e7c9:	0f 85 86 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e7cf:	e8 3c 72 ff ff       	call   5a10 <fwp_mem_free>
    e7d4:	48 83 c3 01          	add    $0x1,%rbx
    e7d8:	49 39 dc             	cmp    %rbx,%r12
    e7db:	75 d3                	jne    e7b0 <fwp_main_thread+0x510>
    e7dd:	48 89 ef             	mov    %rbp,%rdi
    e7e0:	e8 2b 72 ff ff       	call   5a10 <fwp_mem_free>
    e7e5:	48 8b 15 0c d0 05 00 	mov    0x5d00c(%rip),%rdx        # 6b7f8 <fwp_root>
    e7ec:	48 c7 05 f1 cb 05 00 	movq   $0x0,0x5cbf1(%rip)        # 6b3e8 <fwp_fdws>
    e7f3:	00 00 00 00 
    e7f7:	48 c7 05 de cb 05 00 	movq   $0x0,0x5cbde(%rip)        # 6b3e0 <fwp_nfdws>
    e7fe:	00 00 00 00 
    e802:	48 85 d2             	test   %rdx,%rdx
    e805:	74 4e                	je     e855 <fwp_main_thread+0x5b5>
    e807:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    e80c:	0f 85 43 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e812:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    e819:	00 
    e81a:	0f 85 35 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e820:	48 83 3d 70 ec 05 00 	cmpq   $0x0,0x5ec70(%rip)        # 6d498 <fwp_state_len>
    e827:	00 
    e828:	0f 85 27 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e82e:	48 83 3d 52 ec 05 00 	cmpq   $0x0,0x5ec52(%rip)        # 6d488 <fwp_state_owners>
    e835:	00 
    e836:	0f 85 19 4f ff ff    	jne    3755 <fwp_main_thread.cold>
    e83c:	b9 79 00 00 00       	mov    $0x79,%ecx
    e841:	31 c0                	xor    %eax,%eax
    e843:	48 8d 3d b6 cb 05 00 	lea    0x5cbb6(%rip),%rdi        # 6b400 <fwp_root_context>
    e84a:	f3 48 ab             	rep stos %rax,(%rdi)
    e84d:	48 89 d7             	mov    %rdx,%rdi
    e850:	e8 bb 71 ff ff       	call   5a10 <fwp_mem_free>
    e855:	66 0f 6f 05 53 49 04 	movdqa 0x44953(%rip),%xmm0        # 531b0 <ad_raw_live+0x10>
    e85c:	00 
    e85d:	66 0f d4 05 3b 49 04 	paddq  0x4493b(%rip),%xmm0        # 531a0 <ad_raw_live>
    e864:	00 
    e865:	48 c7 05 90 cf 05 00 	movq   $0x0,0x5cf90(%rip)        # 6b800 <fwp_cur>
    e86c:	00 00 00 00 
    e870:	48 8b 05 c9 e3 05 00 	mov    0x5e3c9(%rip),%rax        # 6cc40 <fwp_heap+0x1420>
    e877:	48 c7 05 76 cf 05 00 	movq   $0x0,0x5cf76(%rip)        # 6b7f8 <fwp_root>
    e87e:	00 00 00 00 
    e882:	c7 05 5c ec 05 00 00 	movl   $0x0,0x5ec5c(%rip)        # 6d4e8 <iteration_active>
    e889:	00 00 00 
    e88c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    e890:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    e895:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    e899:	66 0f d6 05 57 48 01 	movq   %xmm0,0x14857(%rip)        # 230f8 <ad_raw_before_shutdown>
    e8a0:	00 
    e8a1:	48 85 c0             	test   %rax,%rax
    e8a4:	0f 88 26 01 00 00    	js     e9d0 <fwp_main_thread+0x730>
    e8aa:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e8ae:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    e8b3:	f2 0f 5c 0d 0d ec 05 	subsd  0x5ec0d(%rip),%xmm1        # 6d4c8 <iteration_start_charge>
    e8ba:	00 
    e8bb:	48 8b 3d 7e 47 00 00 	mov    0x477e(%rip),%rdi        # 13040 <stderr@GLIBC_2.2.5>
    e8c2:	48 8d 15 a7 12 00 00 	lea    0x12a7(%rip),%rdx        # fb70 <_IO_stdin_used+0xb70>
    e8c9:	be 02 00 00 00       	mov    $0x2,%esi
    e8ce:	f2 0f 10 05 ea eb 05 	movsd  0x5ebea(%rip),%xmm0        # 6d4c0 <iteration_peak>
    e8d5:	00 
    e8d6:	4c 8b 0d f3 eb 05 00 	mov    0x5ebf3(%rip),%r9        # 6d4d0 <iteration_retains>
    e8dd:	b8 02 00 00 00       	mov    $0x2,%eax
    e8e2:	4c 8b 05 ef eb 05 00 	mov    0x5ebef(%rip),%r8        # 6d4d8 <iteration_bytes>
    e8e9:	48 8b 0d f0 eb 05 00 	mov    0x5ebf0(%rip),%rcx        # 6d4e0 <iteration_requests>
    e8f0:	e8 7b 4d ff ff       	call   3670 <__fprintf_chk@plt>
    e8f5:	48 8b 3d 24 47 00 00 	mov    0x4724(%rip),%rdi        # 13020 <stdout@GLIBC_2.2.5>
    e8fc:	e8 9f 4c ff ff       	call   35a0 <fflush@plt>
    e901:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    e908:	00 
    e909:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    e910:	00 00 
    e912:	0f 85 90 01 00 00    	jne    eaa8 <fwp_main_thread+0x808>
    e918:	48 81 c4 d0 00 00 00 	add    $0xd0,%rsp
    e91f:	31 c0                	xor    %eax,%eax
    e921:	5b                   	pop    %rbx
    e922:	5d                   	pop    %rbp
    e923:	41 5c                	pop    %r12
    e925:	c3                   	ret
    e926:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    e92d:	00 00 00 
    e930:	48 89 05 a1 ce 05 00 	mov    %rax,0x5cea1(%rip)        # 6b7d8 <fwp_timers>
    e937:	e9 e0 fb ff ff       	jmp    e51c <fwp_main_thread+0x27c>
    e93c:	0f 1f 40 00          	nopl   0x0(%rax)
    e940:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    e944:	0f 85 d6 fc ff ff    	jne    e620 <fwp_main_thread+0x380>
    e94a:	48 89 ef             	mov    %rbp,%rdi
    e94d:	e8 de 57 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    e952:	e9 c9 fc ff ff       	jmp    e620 <fwp_main_thread+0x380>
    e957:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    e95e:	00 00 
    e960:	31 db                	xor    %ebx,%ebx
    e962:	48 83 3d 1e eb 05 00 	cmpq   $0x0,0x5eb1e(%rip)        # 6d488 <fwp_state_owners>
    e969:	00 
    e96a:	0f 85 e7 fb ff ff    	jne    e557 <fwp_main_thread+0x2b7>
    e970:	48 8b 3d 29 eb 05 00 	mov    0x5eb29(%rip),%rdi        # 6d4a0 <fwp_state>
    e977:	e8 94 70 ff ff       	call   5a10 <fwp_mem_free>
    e97c:	48 c7 05 19 eb 05 00 	movq   $0x0,0x5eb19(%rip)        # 6d4a0 <fwp_state>
    e983:	00 00 00 00 
    e987:	48 c7 05 fe ea 05 00 	movq   $0x0,0x5eafe(%rip)        # 6d490 <fwp_state_cap>
    e98e:	00 00 00 00 
    e992:	48 85 db             	test   %rbx,%rbx
    e995:	0f 84 ce 00 00 00    	je     ea69 <fwp_main_thread+0x7c9>
    e99b:	48 39 1d 56 ce 05 00 	cmp    %rbx,0x5ce56(%rip)        # 6b7f8 <fwp_root>
    e9a2:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    e9a9:	00 00 00 00 
    e9ad:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    e9b4:	00 00 00 00 
    e9b8:	c7 05 be 46 01 00 00 	movl   $0x0,0x146be(%rip)        # 23080 <fwp_exit_code>
    e9bf:	00 00 00 
    e9c2:	0f 84 af fb ff ff    	je     e577 <fwp_main_thread+0x2d7>
    e9c8:	e9 88 4d ff ff       	jmp    3755 <fwp_main_thread.cold>
    e9cd:	0f 1f 00             	nopl   (%rax)
    e9d0:	48 89 c2             	mov    %rax,%rdx
    e9d3:	83 e0 01             	and    $0x1,%eax
    e9d6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    e9da:	48 d1 ea             	shr    $1,%rdx
    e9dd:	48 09 c2             	or     %rax,%rdx
    e9e0:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    e9e5:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    e9e9:	e9 c5 fe ff ff       	jmp    e8b3 <fwp_main_thread+0x613>
    e9ee:	66 90                	xchg   %ax,%ax
    e9f0:	48 89 c2             	mov    %rax,%rdx
    e9f3:	83 e0 01             	and    $0x1,%eax
    e9f6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    e9fa:	48 d1 ea             	shr    $1,%rdx
    e9fd:	48 09 c2             	or     %rax,%rdx
    ea00:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    ea05:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    ea09:	e9 9b f9 ff ff       	jmp    e3a9 <fwp_main_thread+0x109>
    ea0e:	66 90                	xchg   %ax,%ax
    ea10:	48 8d 3d a9 62 ff ff 	lea    -0x9d57(%rip),%rdi        # 4cc0 <fwp_heap_report>
    ea17:	e8 b4 02 00 00       	call   ecd0 <atexit>
    ea1c:	e9 bd f8 ff ff       	jmp    e2de <fwp_main_thread+0x3e>
    ea21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ea28:	e8 a3 63 ff ff       	call   4dd0 <fwp_heap_init>
    ea2d:	e9 9e f8 ff ff       	jmp    e2d0 <fwp_main_thread+0x30>
    ea32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ea38:	e8 63 cb ff ff       	call   b5a0 <f0>
    ea3d:	48 c7 05 20 46 00 00 	movq   $0x0,0x4620(%rip)        # 13068 <v.2>
    ea44:	00 00 00 00 
    ea48:	c7 05 1e 46 00 00 01 	movl   $0x1,0x461e(%rip)        # 13070 <st.3>
    ea4f:	00 00 00 
    ea52:	e9 86 f9 ff ff       	jmp    e3dd <fwp_main_thread+0x13d>
    ea57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ea5e:	00 00 
    ea60:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    ea64:	e9 28 fa ff ff       	jmp    e491 <fwp_main_thread+0x1f1>
    ea69:	48 83 3d 87 cd 05 00 	cmpq   $0x0,0x5cd87(%rip)        # 6b7f8 <fwp_root>
    ea70:	00 
    ea71:	c7 05 05 46 01 00 00 	movl   $0x0,0x14605(%rip)        # 23080 <fwp_exit_code>
    ea78:	00 00 00 
    ea7b:	0f 84 95 fc ff ff    	je     e716 <fwp_main_thread+0x476>
    ea81:	e9 cf 4c ff ff       	jmp    3755 <fwp_main_thread.cold>
    ea86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ea8d:	00 00 00 
    ea90:	48 8d 3d b1 10 00 00 	lea    0x10b1(%rip),%rdi        # fb48 <_IO_stdin_used+0xb48>
    ea97:	e8 b4 59 ff ff       	call   4450 <fwp_trap>
    ea9c:	48 8d 3d 30 08 00 00 	lea    0x830(%rip),%rdi        # f2d3 <_IO_stdin_used+0x2d3>
    eaa3:	e8 58 55 ff ff       	call   4000 <ad_raw_fail>
    eaa8:	e8 a3 49 ff ff       	call   3450 <__stack_chk_fail@plt>
    eaad:	48 89 c8             	mov    %rcx,%rax
    eab0:	e9 a4 fb ff ff       	jmp    e659 <fwp_main_thread+0x3b9>
    eab5:	e9 9b 4c ff ff       	jmp    3755 <fwp_main_thread.cold>
    eaba:	e9 96 4c ff ff       	jmp    3755 <fwp_main_thread.cold>
    eabf:	90                   	nop

000000000000eac0 <__divmodti4>:
    eac0:	f3 0f 1e fa          	endbr64
    eac4:	55                   	push   %rbp
    eac5:	49 89 f1             	mov    %rsi,%r9
    eac8:	49 89 d2             	mov    %rdx,%r10
    eacb:	48 89 fe             	mov    %rdi,%rsi
    eace:	49 89 cb             	mov    %rcx,%r11
    ead1:	48 89 e5             	mov    %rsp,%rbp
    ead4:	41 57                	push   %r15
    ead6:	41 56                	push   %r14
    ead8:	41 55                	push   %r13
    eada:	41 54                	push   %r12
    eadc:	53                   	push   %rbx
    eadd:	4c 89 c3             	mov    %r8,%rbx
    eae0:	45 31 c0             	xor    %r8d,%r8d
    eae3:	4d 85 c9             	test   %r9,%r9
    eae6:	79 12                	jns    eafa <__divmodti4+0x3a>
    eae8:	31 ff                	xor    %edi,%edi
    eaea:	48 f7 de             	neg    %rsi
    eaed:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    eaf4:	4c 19 cf             	sbb    %r9,%rdi
    eaf7:	49 89 f9             	mov    %rdi,%r9
    eafa:	4c 89 d8             	mov    %r11,%rax
    eafd:	4d 85 db             	test   %r11,%r11
    eb00:	0f 88 1a 01 00 00    	js     ec20 <__divmodti4+0x160>
    eb06:	4c 89 d9             	mov    %r11,%rcx
    eb09:	49 89 f3             	mov    %rsi,%r11
    eb0c:	75 62                	jne    eb70 <__divmodti4+0xb0>
    eb0e:	4d 89 c4             	mov    %r8,%r12
    eb11:	4d 39 d1             	cmp    %r10,%r9
    eb14:	0f 83 46 01 00 00    	jae    ec60 <__divmodti4+0x1a0>
    eb1a:	4c 89 d8             	mov    %r11,%rax
    eb1d:	4c 89 ca             	mov    %r9,%rdx
    eb20:	49 f7 f2             	div    %r10
    eb23:	49 89 c3             	mov    %rax,%r11
    eb26:	31 c0                	xor    %eax,%eax
    eb28:	48 89 d6             	mov    %rdx,%rsi
    eb2b:	31 ff                	xor    %edi,%edi
    eb2d:	4c 89 d9             	mov    %r11,%rcx
    eb30:	48 89 c2             	mov    %rax,%rdx
    eb33:	48 89 c8             	mov    %rcx,%rax
    eb36:	4d 85 e4             	test   %r12,%r12
    eb39:	74 0a                	je     eb45 <__divmodti4+0x85>
    eb3b:	48 f7 d8             	neg    %rax
    eb3e:	48 83 d2 00          	adc    $0x0,%rdx
    eb42:	48 f7 da             	neg    %rdx
    eb45:	4d 85 c0             	test   %r8,%r8
    eb48:	74 0a                	je     eb54 <__divmodti4+0x94>
    eb4a:	48 f7 de             	neg    %rsi
    eb4d:	48 83 d7 00          	adc    $0x0,%rdi
    eb51:	48 f7 df             	neg    %rdi
    eb54:	48 89 33             	mov    %rsi,(%rbx)
    eb57:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    eb5b:	5b                   	pop    %rbx
    eb5c:	41 5c                	pop    %r12
    eb5e:	41 5d                	pop    %r13
    eb60:	41 5e                	pop    %r14
    eb62:	41 5f                	pop    %r15
    eb64:	5d                   	pop    %rbp
    eb65:	c3                   	ret
    eb66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    eb6d:	00 00 00 
    eb70:	4d 89 c4             	mov    %r8,%r12
    eb73:	49 39 c1             	cmp    %rax,%r9
    eb76:	0f 82 ce 00 00 00    	jb     ec4a <__divmodti4+0x18a>
    eb7c:	31 ff                	xor    %edi,%edi
    eb7e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    eb83:	48 63 c7             	movslq %edi,%rax
    eb86:	be 40 00 00 00       	mov    $0x40,%esi
    eb8b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    eb90:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    eb95:	48 29 c6             	sub    %rax,%rsi
    eb98:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    eb9d:	48 09 c8             	or     %rcx,%rax
    eba0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    eba5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ebaa:	49 89 c6             	mov    %rax,%r14
    ebad:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ebb1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ebb6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ebbb:	49 09 c1             	or     %rax,%r9
    ebbe:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ebc2:	4c 89 c8             	mov    %r9,%rax
    ebc5:	49 f7 f6             	div    %r14
    ebc8:	48 89 d1             	mov    %rdx,%rcx
    ebcb:	49 89 c3             	mov    %rax,%r11
    ebce:	49 89 c1             	mov    %rax,%r9
    ebd1:	49 f7 e2             	mul    %r10
    ebd4:	49 89 c6             	mov    %rax,%r14
    ebd7:	49 89 d2             	mov    %rdx,%r10
    ebda:	48 39 d1             	cmp    %rdx,%rcx
    ebdd:	72 07                	jb     ebe6 <__divmodti4+0x126>
    ebdf:	75 17                	jne    ebf8 <__divmodti4+0x138>
    ebe1:	49 39 c7             	cmp    %rax,%r15
    ebe4:	73 12                	jae    ebf8 <__divmodti4+0x138>
    ebe6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ebea:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ebee:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ebf2:	49 89 d2             	mov    %rdx,%r10
    ebf5:	49 89 c6             	mov    %rax,%r14
    ebf8:	4c 89 f8             	mov    %r15,%rax
    ebfb:	4c 29 f0             	sub    %r14,%rax
    ebfe:	4c 19 d1             	sbb    %r10,%rcx
    ec01:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ec06:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ec0b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ec10:	48 09 c6             	or     %rax,%rsi
    ec13:	48 89 cf             	mov    %rcx,%rdi
    ec16:	31 c0                	xor    %eax,%eax
    ec18:	4c 89 c9             	mov    %r9,%rcx
    ec1b:	e9 10 ff ff ff       	jmp    eb30 <__divmodti4+0x70>
    ec20:	4c 89 d0             	mov    %r10,%rax
    ec23:	4c 89 da             	mov    %r11,%rdx
    ec26:	4d 89 c4             	mov    %r8,%r12
    ec29:	49 89 f3             	mov    %rsi,%r11
    ec2c:	48 f7 d8             	neg    %rax
    ec2f:	49 f7 d4             	not    %r12
    ec32:	48 83 d2 00          	adc    $0x0,%rdx
    ec36:	49 89 c2             	mov    %rax,%r10
    ec39:	48 f7 da             	neg    %rdx
    ec3c:	48 89 d1             	mov    %rdx,%rcx
    ec3f:	0f 84 cc fe ff ff    	je     eb11 <__divmodti4+0x51>
    ec45:	49 39 d1             	cmp    %rdx,%r9
    ec48:	73 46                	jae    ec90 <__divmodti4+0x1d0>
    ec4a:	4c 89 cf             	mov    %r9,%rdi
    ec4d:	31 c0                	xor    %eax,%eax
    ec4f:	31 c9                	xor    %ecx,%ecx
    ec51:	e9 da fe ff ff       	jmp    eb30 <__divmodti4+0x70>
    ec56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    ec5d:	00 00 00 
    ec60:	4d 85 d2             	test   %r10,%r10
    ec63:	75 0d                	jne    ec72 <__divmodti4+0x1b2>
    ec65:	b8 01 00 00 00       	mov    $0x1,%eax
    ec6a:	31 d2                	xor    %edx,%edx
    ec6c:	49 f7 f2             	div    %r10
    ec6f:	49 89 c2             	mov    %rax,%r10
    ec72:	4c 89 c8             	mov    %r9,%rax
    ec75:	31 d2                	xor    %edx,%edx
    ec77:	49 f7 f2             	div    %r10
    ec7a:	49 89 c1             	mov    %rax,%r9
    ec7d:	4c 89 d8             	mov    %r11,%rax
    ec80:	49 f7 f2             	div    %r10
    ec83:	49 89 c3             	mov    %rax,%r11
    ec86:	4c 89 c8             	mov    %r9,%rax
    ec89:	e9 9a fe ff ff       	jmp    eb28 <__divmodti4+0x68>
    ec8e:	66 90                	xchg   %ax,%ax
    ec90:	45 31 f6             	xor    %r14d,%r14d
    ec93:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    ec98:	44 89 f7             	mov    %r14d,%edi
    ec9b:	45 85 f6             	test   %r14d,%r14d
    ec9e:	0f 85 df fe ff ff    	jne    eb83 <__divmodti4+0xc3>
    eca4:	4c 39 ca             	cmp    %r9,%rdx
    eca7:	72 17                	jb     ecc0 <__divmodti4+0x200>
    eca9:	31 c9                	xor    %ecx,%ecx
    ecab:	48 39 c6             	cmp    %rax,%rsi
    ecae:	73 10                	jae    ecc0 <__divmodti4+0x200>
    ecb0:	4c 89 cf             	mov    %r9,%rdi
    ecb3:	31 c0                	xor    %eax,%eax
    ecb5:	e9 76 fe ff ff       	jmp    eb30 <__divmodti4+0x70>
    ecba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ecc0:	4c 89 de             	mov    %r11,%rsi
    ecc3:	b9 01 00 00 00       	mov    $0x1,%ecx
    ecc8:	48 29 c6             	sub    %rax,%rsi
    eccb:	49 19 d1             	sbb    %rdx,%r9
    ecce:	eb e0                	jmp    ecb0 <__divmodti4+0x1f0>

000000000000ecd0 <atexit>:
    ecd0:	f3 0f 1e fa          	endbr64
    ecd4:	48 8b 15 2d 43 00 00 	mov    0x432d(%rip),%rdx        # 13008 <__dso_handle>
    ecdb:	31 f6                	xor    %esi,%esi
    ecdd:	e9 5e 49 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ece4 <_fini>:
    ece4:	f3 0f 1e fa          	endbr64
    ece8:	48 83 ec 08          	sub    $0x8,%rsp
    ecec:	48 83 c4 08          	add    $0x8,%rsp
    ecf0:	c3                   	ret
