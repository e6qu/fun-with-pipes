
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 df 00 00 	mov    0xdfc1(%rip),%rax        # 10fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da dd 00 00    	push   0xddda(%rip)        # 10e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc dd 00 00    	jmp    *0xdddc(%rip)        # 10e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 dc 00 00    	jmp    *0xdc46(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 d8 00 00    	jmp    *0xd8e6(%rip)        # 10f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de d8 00 00    	jmp    *0xd8de(%rip)        # 10f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 d8 00 00    	jmp    *0xd8d6(%rip)        # 10fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce d8 00 00    	jmp    *0xd8ce(%rip)        # 10fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 d8 00 00    	jmp    *0xd8c6(%rip)        # 10fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be d8 00 00    	jmp    *0xd8be(%rip)        # 10fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 99 00 00 	lea    0x99dd(%rip),%r9        # d0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 99 00 00 	lea    0x99da(%rip),%r8        # d0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 bc 00 00 	lea    0xbce1(%rip),%rax        # f460 <fwp_fn_table>
    377f:	48 89 05 b2 fc 01 00 	mov    %rax,0x1fcb2(%rip)        # 23438 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac fc 01 00 	mov    %rax,0x1fcac(%rip)        # 23440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 9a 00 00 	lea    0x9ab7(%rip),%rdi        # d257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 2f 76 00 00 	lea    0x762f(%rip),%rdx        # ae90 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 d7 01 00    	mov    0x1d7f8(%rip),%eax        # 210a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 99 00 00 	lea    0x9967(%rip),%rdi        # d260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e a1 00 00 	lea    0xa17e(%rip),%rdi        # da88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 a1 00 00 	lea    0xa138(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc a0 00 00 	lea    0xa0fc(%rip),%rdi        # da30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 a0 00 00 	lea    0xa0c8(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b d6 00 00    	call   *0xd64b(%rip)        # 10fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e d6 00 00 	mov    0xd62e(%rip),%rax        # 10fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd d5 00 00 	mov    0xd5fd(%rip),%rax        # 10fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da d5 00 00 	cmpq   $0x0,0xd5da(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee d4 01 00 	add    0x1d4ee(%rip),%rdx        # 21110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc d4 01 00 	add    0x1d4dc(%rip),%rax        # 21110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 f7 01 00 	mov    0x1f7c9(%rip),%rdi        # 23440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 d3 00 00 	mov    0xd3b4(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 d3 00 00 	mov    0xd3a1(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 93 00 00 	lea    0x9345(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 d3 00 00 	mov    0xd392(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 da 01 00 	mov    0x1dac1(%rip),%rax        # 217c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 d3 01 00 	mov    0x1d3f9(%rip),%rax        # 21178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 d3 01 00 	sub    0x1d3e5(%rip),%rax        # 21170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 9d 00 00 	lea    0x9dad(%rip),%rsi        # db70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f 98 00 00 	lea    0x987f(%rip),%rdi        # d668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 d2 00 00 	mov    0xd262(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed d1 00 00 ff 	cmpl   $0xffffffff,0xd1ed(%rip)        # 11020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 91 00 00 	lea    0x91e2(%rip),%rax        # d022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 d2 01 00 	mov    0x1d2e1(%rip),%r9        # 21128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f cd 00 	movq   0xcd9f(%rip),%xmm0        # 10bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 91 00 00 	lea    0x91e7(%rip),%rax        # d044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc d2 01 00 	mov    0x1d2bc(%rip),%r8        # 21120 <descent_inputs>
    3e64:	48 8b 0d c5 d2 01 00 	mov    0x1d2c5(%rip),%rcx        # 21130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 d1 00 00 	mov    0xd1e2(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 91 00 00 	lea    0x91d8(%rip),%rax        # d061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 cd 00 	movq   0xcd67(%rip),%xmm0        # 10bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 98 00 00 	lea    0x9818(%rip),%rdx        # d6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 d2 01 00 	lea    0x1d291(%rip),%r12        # 21140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 cd 00 	movq   0xcd44(%rip),%xmm0        # 10c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b d1 00 00 	mov    0xd17b(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 91 00 00 	lea    0x9175(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 91 00 00 	lea    0x9170(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 d1 00 00 	mov    0xd140(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 91 00 00 	lea    0x9144(%rip),%rdi        # d07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 d1 00 00 	mov    0xd119(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 91 00 00 	lea    0x9143(%rip),%rcx        # d091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 91 00 00 	lea    0x9119(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b ec 01 00 	mov    0x1ec3b(%rip),%rax        # 22bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 ec 01 00 	lea    0x1ec34(%rip),%r8        # 22bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 ec 01 00 	mov    0x1ec15(%rip),%rbx        # 22bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 ec 01 00 	mov    0x1ec25(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 eb 01 00 	mov    0x1ebc1(%rip),%rdi        # 22bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a ec 01 00 	sub    %rsi,0x1ec0a(%rip)        # 22c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a eb 01 00 	mov    0x1eb9a(%rip),%rax        # 22bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 eb 01 00 	add    0x1eb50(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e eb 01 00 	mov    0x1eb5e(%rip),%rsi        # 22bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c eb 01 00 	mov    0x1eb6c(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b eb 01 00 	mov    %r12,0x1eb1b(%rip)        # 22bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 eb 01 00 	mov    %rbp,0x1eb09(%rip)        # 22bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee ea 01 00 	cmp    %rdi,0x1eaee(%rip)        # 22ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 ea 01 00 	mov    %rdi,0x1eae5(%rip)        # 22ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 eb 01 00 	sub    %rdi,0x1eb29(%rip)        # 22c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 ea 01 00 	mov    0x1ead1(%rip),%rax        # 22bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca ea 01 00 	lea    0x1eaca(%rip),%r8        # 22bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ce 00 00 	mov    0xce7d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 8e 00 00 	lea    0x8e14(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 cd 00 00 	movslq 0xcdb5(%rip),%rbp        # 11020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ce 01 00 	mov    0x1ce9a(%rip),%rsi        # 21138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ce 01 00 	lea    0x1ce96(%rip),%rcx        # 21140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ce 01 00 	addq   $0x1,0x1ce6b(%rip)        # 21130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 cd 00 00    	mov    %ebx,0xcd50(%rip)        # 11020 <descent_active_phase>
    42d0:	48 89 05 61 ce 01 00 	mov    %rax,0x1ce61(%rip)        # 21138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 d4 01 00 	cmp    0x1d4b9(%rip),%rdi        # 217c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f d4 01 00 	mov    0x1d47f(%rip),%rax        # 217a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d d4 01 00 	mov    %rdi,0x1d45d(%rip)        # 217a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 d4 01 00 	mov    %rdi,0x1d439(%rip)        # 217a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 8e 00 00 	lea    0x8e18(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 8c 00 00 	lea    0x8cba(%rip),%rsi        # d07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 cc 00 00 	mov    0xcc48(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 8c 00 00 	lea    0x8c64(%rip),%rdx        # d083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 cc 00 00 	mov    0xcc30(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 cb 00 00 	mov    0xcb41(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 8a 00 00 	lea    0x8ad8(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 8b 00 00 	lea    0x8b45(%rip),%rdi        # d092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 8a 00 00 	lea    0x8acd(%rip),%rdi        # d0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 91 00 00 	lea    0x9110(%rip),%rdi        # d700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 95 00 	movdqa 0x9580(%rip),%xmm0        # db90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca ed 01 00 	add    0x1edca(%rip),%rax        # 23438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 90 00 00 	lea    0x9064(%rip),%rdi        # d728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ca 01 00 	cmp    %rax,0x1ca25(%rip)        # 21108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ca 01 00 	add    0x1ca20(%rip),%rax        # 21110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d 90 00 00 	lea    0x904d(%rip),%rdi        # d758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 89 00 00 	lea    0x89a5(%rip),%r8        # d0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 87 00 00 	lea    0x87fa(%rip),%r8        # d0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 86 00 00 	lea    0x8697(%rip),%r8        # d0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 84 00 00 	lea    0x846f(%rip),%rdi        # d0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e 85 00 00 	lea    0x857e(%rip),%rsi        # d20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 de 01 00 	mov    0x1dea5(%rip),%r9        # 22ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe de 01 00 	mov    0x1defe(%rip),%r8        # 22c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 8a 00 00 	lea    0x8a97(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 de 01 00 	mov    0x1dee6(%rip),%rcx        # 22c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 de 01 	movsd  0x1def4(%rip),%xmm1        # 22c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 de 01 	movsd  0x1dee4(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 c3 00 00 	mov    0xc325(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 8e 00 	movdqa 0x8e28(%rip),%xmm0        # dba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f d9 01 00 	lea    0x1d99f(%rip),%rax        # 22720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 8e 00 	movdqa 0x8e51(%rip),%xmm2        # dbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 d9 01 00 	movaps %xmm0,0x1d945(%rip)        # 226e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d 8e 00 	movdqa 0x8e0d(%rip),%xmm0        # dbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 dd 01 00 01 	movl   $0x1,0x1ddd3(%rip)        # 22b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 d9 01 00 	movaps %xmm0,0x1d933(%rip)        # 226f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb 8d 00 	movdqa 0x8dfb(%rip),%xmm0        # dbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 d9 01 00 	movaps %xmm0,0x1d934(%rip)        # 22700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc 8d 00 	movdqa 0x8dfc(%rip),%xmm0        # dbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 d9 01 00 	movaps %xmm0,0x1d935(%rip)        # 22710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 c9 01 00 	lea    0x1c9b5(%rip),%r8        # 217e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 dc 01 00 	mov    %rax,0x1dcd0(%rip)        # 22b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae dc 01 00 	mov    %r12,0x1dcae(%rip)        # 22ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 dc 01 00 	mov    %rax,0x1dc97(%rip)        # 22b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 dc 01 00 	mov    %rbx,0x1dcb0(%rip)        # 22bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 dc 01 00 	mov    %rsi,0x1dcd9(%rip)        # 22be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 81 00 00 	lea    0x81f9(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 dc 01 00 	mov    %rax,0x1dcb8(%rip)        # 22bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c dc 01 00    	mov    %eax,0x1dc3c(%rip)        # 22b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c c8 01 00 	mov    0x1c82c(%rip),%r8        # 217a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c c7 01 00 	mov    %rbx,0x1c75c(%rip)        # 217a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 c7 01 00 	mov    %r8,0x1c748(%rip)        # 217a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 80 00 00 	lea    0x805c(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd bf 01 00 	lea    0x1bfbd(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 bf 01 00 	movaps %xmm0,0x1bfa5(%rip)        # 210c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 bf 01 00 	mov    %rax,0x1bf81(%rip)        # 210a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 bf 01 00 	movaps %xmm0,0x1bfa2(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 bf 01 00 	movaps %xmm0,0x1bfa6(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 bf 01 00 	mov    %rdx,0x1bfa7(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 7f 00 00 	lea    0x7fb3(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 c5 01 00 	mov    0x1c5d7(%rip),%rbx        # 21798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa bd 00 00 	mov    0xbdaa(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 85 00 00 	lea    0x8573(%rip),%rdi        # d830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad c4 01 00 	mov    0x1c4ad(%rip),%rax        # 217a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 c4 01 00 	mov    %rdx,0x1c487(%rip)        # 217a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 c3 01 00 	mov    0x1c3d4(%rip),%rbx        # 21798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 c3 01 00 	mov    %rbx,0x1c391(%rip)        # 21798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 c3 01 00 	mov    %rdx,0x1c391(%rip)        # 217a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 c3 01 00 	lea    0x1c3a6(%rip),%rsi        # 217e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 df 01 00 	addq   $0x1,0x1df25(%rip)        # 23428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 83 00 00 	lea    0x8347(%rip),%rdi        # d860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 83 00 00 	lea    0x8358(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 7b 00 00 	lea    0x7bf7(%rip),%rdi        # d133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e c2 01 00 	lea    0x1c25e(%rip),%rcx        # 217e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f de 01 00 	subq   $0x1,0x1de5f(%rip)        # 23428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 82 00 00 	lea    0x82b3(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 de 01 00 	cmpq   $0x0,0x1de40(%rip)        # 23428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 dd 01 00 	sub    %rax,0x1dd95(%rip)        # 23430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 dd 01 00 	add    %r12,0x1dd73(%rip)        # 23430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf d4 01 00 	mov    0x1d4cf(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc c0 01 00 	lea    0x1c0cc(%rip),%rax        # 217e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 d4 01 00 	add    0x1d423(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 d3 01 00 	mov    0x1d3f0(%rip),%rsi        # 22b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 d4 01 00 	mov    0x1d411(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 d4 01 00 	add    0x1d405(%rip),%r8        # 22bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd d3 01 	addsd  0x1d3cd(%rip),%xmm0        # 22c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 bf 01 00 	lea    0x1bf82(%rip),%rax        # 217e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c d3 01 00 	sub    %rdi,0x1d38c(%rip)        # 22c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 d3 01 	movsd  %xmm0,0x1d3a4(%rip)        # 22c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e d3 01 00 	sub    %rdx,0x1d35e(%rip)        # 22c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 d3 01 	addsd  0x1d364(%rip),%xmm0        # 22c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 d3 01 	movsd  %xmm0,0x1d358(%rip)        # 22c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef d2 01 00 	mov    0x1d2ef(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 d2 01 00 	add    %rcx,0x1d2e9(%rip)        # 22c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 d2 01 00 	cmp    0x1d2a2(%rip),%r9        # 22bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 d2 01 00 	mov    %r9,0x1d299(%rip)        # 22bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a d2 01 00 	cmp    0x1d28a(%rip),%r9        # 22bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d d2 01 00 	mov    %r9,0x1d27d(%rip)        # 22bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 d1 01 00 	add    0x1d193(%rip),%rdi        # 22bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 bd 01 00 	lea    0x1bd70(%rip),%r15        # 217e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 d0 01 00 	add    0x1d0e0(%rip),%r12        # 22b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 d1 01 00 	add    0x1d139(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 d1 01 00 	cmp    %rax,0x1d138(%rip)        # 22c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 d1 01 00 	mov    %rax,0x1d129(%rip)        # 22c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 d1 01 00 	mov    %rax,0x1d128(%rip)        # 22c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 d1 01 	addsd  0x1d124(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c d1 01 	movsd  %xmm0,0x1d11c(%rip)        # 22c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 d0 01 00    	mov    0x1d063(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f bc 01 00 	lea    0x1bc9f(%rip),%rdi        # 217e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 d0 01 00 	add    0x1d058(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 d0 01 00 	cmp    %rax,0x1d053(%rip)        # 22c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 d0 01 00 	mov    %rax,0x1d044(%rip)        # 22c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 d0 01 00 	mov    %rax,0x1d043(%rip)        # 22c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f d0 01 	addsd  0x1d03f(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 d0 01 	movsd  %xmm0,0x1d037(%rip)        # 22c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ce 01 00    	mov    0x1ceee(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 bb 01 00 	lea    0x1bb25(%rip),%rax        # 217e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ce 01 00 	add    0x1cedb(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ce 01 00 	cmp    %rax,0x1ceda(%rip)        # 22c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ce 01 00 	mov    %rax,0x1cecb(%rip)        # 22c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ce 01 00 	mov    %rax,0x1ceca(%rip)        # 22c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ce 01 	addsd  0x1cec6(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ce 01 	movsd  %xmm0,0x1cebe(%rip)        # 22c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c d6 01 00 	add    0x1d64c(%rip),%r9        # 23438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_p_ad_push>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	49 89 d5             	mov    %rdx,%r13
    5ff9:	41 54                	push   %r12
    5ffb:	49 89 fc             	mov    %rdi,%r12
    5ffe:	55                   	push   %rbp
    5fff:	53                   	push   %rbx
    6000:	48 83 ec 48          	sub    $0x48,%rsp
    6004:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6009:	48 85 ff             	test   %rdi,%rdi
    600c:	79 09                	jns    6017 <fwp_p_ad_push+0x27>
    600e:	48 85 d2             	test   %rdx,%rdx
    6011:	0f 88 b9 02 00 00    	js     62d0 <fwp_p_ad_push+0x2e0>
    6017:	48 89 f8             	mov    %rdi,%rax
    601a:	48 89 0c 24          	mov    %rcx,(%rsp)
    601e:	4c 89 c5             	mov    %r8,%rbp
    6021:	48 09 d0             	or     %rdx,%rax
    6024:	0f 89 7e 02 00 00    	jns    62a8 <fwp_p_ad_push+0x2b8>
    602a:	48 85 ff             	test   %rdi,%rdi
    602d:	0f 89 e6 03 00 00    	jns    6419 <fwp_p_ad_push+0x429>
    6033:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6038:	49 89 d6             	mov    %rdx,%r14
    603b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    6042:	00 
    6043:	49 89 d4             	mov    %rdx,%r12
    6046:	49 c1 fe 20          	sar    $0x20,%r14
    604a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    6051:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    6057:	48 85 ed             	test   %rbp,%rbp
    605a:	0f 84 48 03 00 00    	je     63a8 <fwp_p_ad_push+0x3b8>
    6060:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    6064:	0f 84 be 02 00 00    	je     6328 <fwp_p_ad_push+0x338>
    606a:	4c 89 f7             	mov    %r14,%rdi
    606d:	e8 5e e6 ff ff       	call   46d0 <fwp_tape_of>
    6072:	48 89 c3             	mov    %rax,%rbx
    6075:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    607a:	0f 85 3e 03 00 00    	jne    63be <fwp_p_ad_push+0x3ce>
    6080:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    6084:	48 89 45 08          	mov    %rax,0x8(%rbp)
    6088:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    608c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    6093:	0f 8f cd 03 00 00    	jg     6466 <fwp_p_ad_push+0x476>
    6099:	44 89 e0             	mov    %r12d,%eax
    609c:	4c 39 c0             	cmp    %r8,%rax
    609f:	0f 8d b5 03 00 00    	jge    645a <fwp_p_ad_push+0x46a>
    60a5:	4d 85 ed             	test   %r13,%r13
    60a8:	78 0c                	js     60b6 <fwp_p_ad_push+0xc6>
    60aa:	44 89 e8             	mov    %r13d,%eax
    60ad:	4c 39 c0             	cmp    %r8,%rax
    60b0:	0f 8d a4 03 00 00    	jge    645a <fwp_p_ad_push+0x46a>
    60b6:	4d 89 c7             	mov    %r8,%r15
    60b9:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    60bd:	49 8d 47 01          	lea    0x1(%r15),%rax
    60c1:	4c 89 f9             	mov    %r15,%rcx
    60c4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    60ca:	0f 87 96 03 00 00    	ja     6466 <fwp_p_ad_push+0x476>
    60d0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    60d4:	48 39 e8             	cmp    %rbp,%rax
    60d7:	0f 8e 23 02 00 00    	jle    6300 <fwp_p_ad_push+0x310>
    60dd:	48 85 ed             	test   %rbp,%rbp
    60e0:	ba 40 00 00 00       	mov    $0x40,%edx
    60e5:	48 0f 44 ea          	cmove  %rdx,%rbp
    60e9:	48 39 e8             	cmp    %rbp,%rax
    60ec:	7e 22                	jle    6110 <fwp_p_ad_push+0x120>
    60ee:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    60f5:	0f 8f f5 01 00 00    	jg     62f0 <fwp_p_ad_push+0x300>
    60fb:	48 01 ed             	add    %rbp,%rbp
    60fe:	48 39 e8             	cmp    %rbp,%rax
    6101:	7f eb                	jg     60ee <fwp_p_ad_push+0xfe>
    6103:	66 90                	xchg   %ax,%ax
    6105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    610c:	00 00 00 00 
    6110:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6117:	00 
    6118:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    611c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6121:	48 89 c6             	mov    %rax,%rsi
    6124:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6129:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    612d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6132:	e8 99 d4 ff ff       	call   35d0 <realloc@plt>
    6137:	48 85 c0             	test   %rax,%rax
    613a:	0f 84 32 03 00 00    	je     6472 <fwp_p_ad_push+0x482>
    6140:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6144:	4d 85 f6             	test   %r14,%r14
    6147:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    614c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6150:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6155:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6159:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    615d:	0f 84 d5 01 00 00    	je     6338 <fwp_p_ad_push+0x348>
    6163:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6167:	48 39 ea             	cmp    %rbp,%rdx
    616a:	0f 8d bb 00 00 00    	jge    622b <fwp_p_ad_push+0x23b>
    6170:	49 8b 76 40          	mov    0x40(%r14),%rsi
    6174:	48 89 ef             	mov    %rbp,%rdi
    6177:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    617c:	48 c1 e7 04          	shl    $0x4,%rdi
    6180:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    6185:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    618a:	be 02 00 00 00       	mov    $0x2,%esi
    618f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6194:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6199:	e8 f2 fa ff ff       	call   5c90 <fwp_heap_alloc>
    619e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    61a3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    61a8:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    61ad:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    61b2:	48 85 f6             	test   %rsi,%rsi
    61b5:	74 31                	je     61e8 <fwp_p_ad_push+0x1f8>
    61b7:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    61bc:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    61c1:	48 c1 e2 04          	shl    $0x4,%rdx
    61c5:	48 39 fa             	cmp    %rdi,%rdx
    61c8:	48 0f 47 d7          	cmova  %rdi,%rdx
    61cc:	48 89 c7             	mov    %rax,%rdi
    61cf:	e8 cc d3 ff ff       	call   35a0 <memcpy@plt>
    61d4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    61d9:	e8 b2 f5 ff ff       	call   5790 <fwp_mem_free>
    61de:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    61e3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    61e8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    61ec:	48 89 ea             	mov    %rbp,%rdx
    61ef:	31 f6                	xor    %esi,%esi
    61f1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    61f6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    61fb:	48 29 fa             	sub    %rdi,%rdx
    61fe:	48 c1 e7 04          	shl    $0x4,%rdi
    6202:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    6207:	48 c1 e2 04          	shl    $0x4,%rdx
    620b:	e8 b0 d2 ff ff       	call   34c0 <memset@plt>
    6210:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6215:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    6219:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    621e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6223:	49 89 46 40          	mov    %rax,0x40(%r14)
    6227:	48 8b 43 20          	mov    0x20(%rbx),%rax
    622b:	4d 85 ff             	test   %r15,%r15
    622e:	0f 85 9c 01 00 00    	jne    63d0 <fwp_p_ad_push+0x3e0>
    6234:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6238:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    623c:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6243:	00 
    6244:	49 01 c6             	add    %rax,%r14
    6247:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    624b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    624f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6253:	4d 85 ed             	test   %r13,%r13
    6256:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    625c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6263:	4c 0f 48 e8          	cmovs  %rax,%r13
    6267:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    626c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6270:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6275:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6279:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    627e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6282:	48 83 c4 48          	add    $0x48,%rsp
    6286:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    628d:	ff ff ff 
    6290:	4c 21 e0             	and    %r12,%rax
    6293:	5b                   	pop    %rbx
    6294:	5d                   	pop    %rbp
    6295:	4c 09 c0             	or     %r8,%rax
    6298:	41 5c                	pop    %r12
    629a:	41 5d                	pop    %r13
    629c:	41 5e                	pop    %r14
    629e:	41 5f                	pop    %r15
    62a0:	c3                   	ret
    62a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    62a8:	48 c1 fa 20          	sar    $0x20,%rdx
    62ac:	48 c1 ff 20          	sar    $0x20,%rdi
    62b0:	49 89 d6             	mov    %rdx,%r14
    62b3:	48 39 d7             	cmp    %rdx,%rdi
    62b6:	0f 84 9b fd ff ff    	je     6057 <fwp_p_ad_push+0x67>
    62bc:	48 8d 3d ed 75 00 00 	lea    0x75ed(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    62c3:	e8 28 e1 ff ff       	call   43f0 <fwp_trap>
    62c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    62cf:	00 
    62d0:	48 83 c4 48          	add    $0x48,%rsp
    62d4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    62db:	5b                   	pop    %rbx
    62dc:	5d                   	pop    %rbp
    62dd:	41 5c                	pop    %r12
    62df:	41 5d                	pop    %r13
    62e1:	41 5e                	pop    %r14
    62e3:	41 5f                	pop    %r15
    62e5:	c3                   	ret
    62e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ed:	00 00 00 
    62f0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    62f5:	e9 16 fe ff ff       	jmp    6110 <fwp_p_ad_push+0x120>
    62fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6300:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6304:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6308:	48 c1 e1 03          	shl    $0x3,%rcx
    630c:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    6313:	00 
    6314:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6318:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    631c:	e9 2e ff ff ff       	jmp    624f <fwp_p_ad_push+0x25f>
    6321:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6328:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    632c:	e9 57 fd ff ff       	jmp    6088 <fwp_p_ad_push+0x98>
    6331:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6338:	49 89 ee             	mov    %rbp,%r14
    633b:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    633f:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6344:	49 c1 e6 04          	shl    $0x4,%r14
    6348:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    634d:	4c 89 f6             	mov    %r14,%rsi
    6350:	e8 7b d2 ff ff       	call   35d0 <realloc@plt>
    6355:	48 89 c2             	mov    %rax,%rdx
    6358:	48 85 c0             	test   %rax,%rax
    635b:	0f 84 11 01 00 00    	je     6472 <fwp_p_ad_push+0x482>
    6361:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6365:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6369:	4d 85 ff             	test   %r15,%r15
    636c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6371:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6376:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    637a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    637f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6383:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6387:	0f 85 98 00 00 00    	jne    6425 <fwp_p_ad_push+0x435>
    638d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6391:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6395:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    639c:	00 
    639d:	45 31 ff             	xor    %r15d,%r15d
    63a0:	e9 9f fe ff ff       	jmp    6244 <fwp_p_ad_push+0x254>
    63a5:	0f 1f 00             	nopl   (%rax)
    63a8:	4c 89 f7             	mov    %r14,%rdi
    63ab:	e8 20 e3 ff ff       	call   46d0 <fwp_tape_of>
    63b0:	48 89 c3             	mov    %rax,%rbx
    63b3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    63b8:	0f 84 ca fc ff ff    	je     6088 <fwp_p_ad_push+0x98>
    63be:	48 8d 3d 33 75 00 00 	lea    0x7533(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    63c5:	e8 26 e0 ff ff       	call   43f0 <fwp_trap>
    63ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    63d0:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    63d7:	00 
    63d8:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    63dd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    63e1:	49 c1 e7 02          	shl    $0x2,%r15
    63e5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    63ea:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    63f1:	00 
    63f2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    63f6:	4c 89 fa             	mov    %r15,%rdx
    63f9:	e8 12 d2 ff ff       	call   3610 <memmove@plt>
    63fe:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6402:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6406:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    640a:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    640f:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6414:	e9 2b fe ff ff       	jmp    6244 <fwp_p_ad_push+0x254>
    6419:	48 c1 ff 20          	sar    $0x20,%rdi
    641d:	49 89 fe             	mov    %rdi,%r14
    6420:	e9 32 fc ff ff       	jmp    6057 <fwp_p_ad_push+0x67>
    6425:	4c 39 f0             	cmp    %r14,%rax
    6428:	4c 89 f1             	mov    %r14,%rcx
    642b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    6432:	00 
    6433:	49 89 c6             	mov    %rax,%r14
    6436:	48 0f 43 c8          	cmovae %rax,%rcx
    643a:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    643f:	48 29 c1             	sub    %rax,%rcx
    6442:	e8 19 d1 ff ff       	call   3560 <__memmove_chk@plt>
    6447:	4c 03 73 30          	add    0x30(%rbx),%r14
    644b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    644f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6453:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6458:	eb 83                	jmp    63dd <fwp_p_ad_push+0x3ed>
    645a:	48 8d 3d 06 6d 00 00 	lea    0x6d06(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    6461:	e8 8a df ff ff       	call   43f0 <fwp_trap>
    6466:	48 8d 3d df 6c 00 00 	lea    0x6cdf(%rip),%rdi        # d14c <_IO_stdin_used+0x14c>
    646d:	e8 7e df ff ff       	call   43f0 <fwp_trap>
    6472:	48 89 df             	mov    %rbx,%rdi
    6475:	e8 86 d7 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    647a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    647e:	e8 3d cf ff ff       	call   33c0 <free@plt>
    6483:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6487:	e8 34 cf ff ff       	call   33c0 <free@plt>
    648c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6490:	e8 2b cf ff ff       	call   33c0 <free@plt>
    6495:	31 c9                	xor    %ecx,%ecx
    6497:	31 c0                	xor    %eax,%eax
    6499:	31 d2                	xor    %edx,%edx
    649b:	89 53 04             	mov    %edx,0x4(%rbx)
    649e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    64a2:	ba 13 00 00 00       	mov    $0x13,%edx
    64a7:	be 01 00 00 00       	mov    $0x1,%esi
    64ac:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    64b0:	48 8d 3d 51 6b 00 00 	lea    0x6b51(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    64b7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    64bb:	48 8b 0d 9e ab 00 00 	mov    0xab9e(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    64c2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    64c6:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    64ca:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    64ce:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    64d2:	e8 a9 d1 ff ff       	call   3680 <fwrite@plt>
    64d7:	31 ff                	xor    %edi,%edi
    64d9:	e8 e2 d0 ff ff       	call   35c0 <fflush@plt>
    64de:	bf 66 00 00 00       	mov    $0x66,%edi
    64e3:	e8 b8 d1 ff ff       	call   36a0 <_Exit@plt>
    64e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    64ef:	00 

00000000000064f0 <w107>:
    64f0:	41 56                	push   %r14
    64f2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    64f6:	48 89 fa             	mov    %rdi,%rdx
    64f9:	41 55                	push   %r13
    64fb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    64ff:	49 89 fd             	mov    %rdi,%r13
    6502:	41 54                	push   %r12
    6504:	55                   	push   %rbp
    6505:	53                   	push   %rbx
    6506:	48 83 ec 40          	sub    $0x40,%rsp
    650a:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6510:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6515:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    651c:	00 00 
    651e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6523:	48 89 f5             	mov    %rsi,%rbp
    6526:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    652b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6531:	48 89 f1             	mov    %rsi,%rcx
    6534:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    653a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6541:	ff ff 
    6543:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    654a:	00 00 
    654c:	e8 9f fa ff ff       	call   5ff0 <fwp_p_ad_push>
    6551:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6557:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    655c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6562:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6569:	00 f0 3f 
    656c:	48 89 c7             	mov    %rax,%rdi
    656f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6576:	00 f0 bf 
    6579:	48 89 ea             	mov    %rbp,%rdx
    657c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6581:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6587:	e8 64 fa ff ff       	call   5ff0 <fwp_p_ad_push>
    658c:	f2 0f 10 05 8c 76 00 	movsd  0x768c(%rip),%xmm0        # dc20 <msg.4+0xb0>
    6593:	00 
    6594:	4c 89 ef             	mov    %r13,%rdi
    6597:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    659d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    65a2:	49 89 c6             	mov    %rax,%r14
    65a5:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    65ac:	00 f0 3f 
    65af:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    65b6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    65bd:	00 f0 bf 
    65c0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    65c5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    65cb:	e8 20 fa ff ff       	call   5ff0 <fwp_p_ad_push>
    65d0:	4c 89 e1             	mov    %r12,%rcx
    65d3:	4c 89 e6             	mov    %r12,%rsi
    65d6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    65db:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    65e1:	4c 89 f2             	mov    %r14,%rdx
    65e4:	4c 89 f7             	mov    %r14,%rdi
    65e7:	49 89 c5             	mov    %rax,%r13
    65ea:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    65ee:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    65f4:	e8 f7 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    65f9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    65ff:	f2 0f 59 1d 21 76 00 	mulsd  0x7621(%rip),%xmm3        # dc28 <msg.4+0xb8>
    6606:	00 
    6607:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    660c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6611:	48 89 c2             	mov    %rax,%rdx
    6614:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    661b:	00 59 40 
    661e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6625:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    662b:	e8 c0 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6630:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6635:	48 89 e9             	mov    %rbp,%rcx
    6638:	4c 89 ea             	mov    %r13,%rdx
    663b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6641:	48 89 ee             	mov    %rbp,%rsi
    6644:	4c 89 ef             	mov    %r13,%rdi
    6647:	49 89 c4             	mov    %rax,%r12
    664a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    664e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6654:	e8 97 f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6659:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    665f:	45 31 c0             	xor    %r8d,%r8d
    6662:	4c 89 e2             	mov    %r12,%rdx
    6665:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    666b:	48 89 c7             	mov    %rax,%rdi
    666e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6675:	00 f0 3f 
    6678:	48 89 ce             	mov    %rcx,%rsi
    667b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6680:	e8 6b f9 ff ff       	call   5ff0 <fwp_p_ad_push>
    6685:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    668a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6691:	00 00 
    6693:	75 12                	jne    66a7 <w107+0x1b7>
    6695:	48 83 c4 40          	add    $0x40,%rsp
    6699:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    669e:	5b                   	pop    %rbx
    669f:	5d                   	pop    %rbp
    66a0:	41 5c                	pop    %r12
    66a2:	41 5d                	pop    %r13
    66a4:	41 5e                	pop    %r14
    66a6:	c3                   	ret
    66a7:	e8 b4 cd ff ff       	call   3460 <__stack_chk_fail@plt>
    66ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000066b0 <w164.constprop.0>:
    66b0:	41 54                	push   %r12
    66b2:	55                   	push   %rbp
    66b3:	53                   	push   %rbx
    66b4:	48 83 ec 10          	sub    $0x10,%rsp
    66b8:	4c 8b 27             	mov    (%rdi),%r12
    66bb:	4d 85 e4             	test   %r12,%r12
    66be:	74 58                	je     6718 <w164.constprop.0+0x68>
    66c0:	48 89 fd             	mov    %rdi,%rbp
    66c3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    66c7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66ce:	31 db                	xor    %ebx,%ebx
    66d0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    66d6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    66db:	45 31 c0             	xor    %r8d,%r8d
    66de:	48 83 c3 02          	add    $0x2,%rbx
    66e2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    66e9:	00 f0 3f 
    66ec:	48 89 ce             	mov    %rcx,%rsi
    66ef:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    66f5:	e8 f6 f8 ff ff       	call   5ff0 <fwp_p_ad_push>
    66fa:	4c 39 e3             	cmp    %r12,%rbx
    66fd:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    6703:	48 89 c7             	mov    %rax,%rdi
    6706:	72 c8                	jb     66d0 <w164.constprop.0+0x20>
    6708:	48 83 c4 10          	add    $0x10,%rsp
    670c:	48 89 f8             	mov    %rdi,%rax
    670f:	5b                   	pop    %rbx
    6710:	5d                   	pop    %rbp
    6711:	41 5c                	pop    %r12
    6713:	c3                   	ret
    6714:	0f 1f 40 00          	nopl   0x0(%rax)
    6718:	48 83 c4 10          	add    $0x10,%rsp
    671c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6723:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6727:	5b                   	pop    %rbx
    6728:	48 89 f8             	mov    %rdi,%rax
    672b:	5d                   	pop    %rbp
    672c:	41 5c                	pop    %r12
    672e:	c3                   	ret
    672f:	90                   	nop

0000000000006730 <fwp_data.part.0.constprop.0>:
    6730:	41 56                	push   %r14
    6732:	41 89 fe             	mov    %edi,%r14d
    6735:	41 54                	push   %r12
    6737:	49 89 f4             	mov    %rsi,%r12
    673a:	55                   	push   %rbp
    673b:	53                   	push   %rbx
    673c:	48 83 ec 08          	sub    $0x8,%rsp
    6740:	8b 05 3e c4 01 00    	mov    0x1c43e(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    6746:	85 c0                	test   %eax,%eax
    6748:	0f 84 fa 00 00 00    	je     6848 <fwp_data.part.0.constprop.0+0x118>
    674e:	0f b6 05 2d c0 01 00 	movzbl 0x1c02d(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    6755:	48 8d 15 84 b0 01 00 	lea    0x1b084(%rip),%rdx        # 217e0 <fwp_heap>
    675c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6763:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6767:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    676b:	48 8b 18             	mov    (%rax),%rbx
    676e:	48 85 db             	test   %rbx,%rbx
    6771:	0f 84 a9 00 00 00    	je     6820 <fwp_data.part.0.constprop.0+0xf0>
    6777:	48 8b 13             	mov    (%rbx),%rdx
    677a:	48 f7 d2             	not    %rdx
    677d:	48 89 10             	mov    %rdx,(%rax)
    6780:	48 83 fd 18          	cmp    $0x18,%rbp
    6784:	76 1b                	jbe    67a1 <fwp_data.part.0.constprop.0+0x71>
    6786:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    678a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    678e:	31 f6                	xor    %esi,%esi
    6790:	48 c1 e8 03          	shr    $0x3,%rax
    6794:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    679b:	00 
    679c:	e8 1f cd ff ff       	call   34c0 <memset@plt>
    67a1:	48 89 e8             	mov    %rbp,%rax
    67a4:	48 03 05 55 c4 01 00 	add    0x1c455(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    67ab:	0f 82 a8 00 00 00    	jb     6859 <fwp_data.part.0.constprop.0+0x129>
    67b1:	48 39 05 50 c4 01 00 	cmp    %rax,0x1c450(%rip)        # 22c08 <fwp_heap+0x1428>
    67b8:	48 89 05 41 c4 01 00 	mov    %rax,0x1c441(%rip)        # 22c00 <fwp_heap+0x1420>
    67bf:	73 07                	jae    67c8 <fwp_data.part.0.constprop.0+0x98>
    67c1:	48 89 05 40 c4 01 00 	mov    %rax,0x1c440(%rip)        # 22c08 <fwp_heap+0x1428>
    67c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    67cc:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    67d1:	f2 0f 58 05 3f c4 01 	addsd  0x1c43f(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    67d8:	00 
    67d9:	f2 0f 11 05 37 c4 01 	movsd  %xmm0,0x1c437(%rip)        # 22c18 <fwp_heap+0x1438>
    67e0:	00 
    67e1:	b8 02 00 00 00       	mov    $0x2,%eax
    67e6:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    67eb:	66 0f 6e c8          	movd   %eax,%xmm1
    67ef:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    67f3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    67f7:	49 8b 04 24          	mov    (%r12),%rax
    67fb:	48 89 43 08          	mov    %rax,0x8(%rbx)
    67ff:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6804:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6808:	48 83 c4 08          	add    $0x8,%rsp
    680c:	48 89 d8             	mov    %rbx,%rax
    680f:	5b                   	pop    %rbx
    6810:	5d                   	pop    %rbp
    6811:	41 5c                	pop    %r12
    6813:	41 5e                	pop    %r14
    6815:	c3                   	ret
    6816:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    681d:	00 00 00 
    6820:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6824:	48 85 db             	test   %rbx,%rbx
    6827:	74 1f                	je     6848 <fwp_data.part.0.constprop.0+0x118>
    6829:	48 8b 50 10          	mov    0x10(%rax),%rdx
    682d:	48 29 da             	sub    %rbx,%rdx
    6830:	48 39 ea             	cmp    %rbp,%rdx
    6833:	72 13                	jb     6848 <fwp_data.part.0.constprop.0+0x118>
    6835:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6839:	48 89 50 08          	mov    %rdx,0x8(%rax)
    683d:	e9 3e ff ff ff       	jmp    6780 <fwp_data.part.0.constprop.0+0x50>
    6842:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6848:	31 f6                	xor    %esi,%esi
    684a:	bf 18 00 00 00       	mov    $0x18,%edi
    684f:	e8 3c f4 ff ff       	call   5c90 <fwp_heap_alloc>
    6854:	48 89 c3             	mov    %rax,%rbx
    6857:	eb 88                	jmp    67e1 <fwp_data.part.0.constprop.0+0xb1>
    6859:	e8 52 d4 ff ff       	call   3cb0 <fwp_heap_oom>
    685e:	66 90                	xchg   %ax,%ax

0000000000006860 <fwp_rc_share>:
    6860:	48 8b 05 51 c3 01 00 	mov    0x1c351(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    6867:	48 2b 3d 22 c3 01 00 	sub    0x1c322(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    686e:	48 c1 e0 10          	shl    $0x10,%rax
    6872:	48 39 c7             	cmp    %rax,%rdi
    6875:	73 4a                	jae    68c1 <fwp_rc_share+0x61>
    6877:	48 89 f8             	mov    %rdi,%rax
    687a:	48 c1 e8 10          	shr    $0x10,%rax
    687e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6882:	48 8b 05 4f c3 01 00 	mov    0x1c34f(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    6889:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    688d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6891:	48 85 d2             	test   %rdx,%rdx
    6894:	74 2b                	je     68c1 <fwp_rc_share+0x61>
    6896:	0f b6 08             	movzbl (%rax),%ecx
    6899:	80 f9 02             	cmp    $0x2,%cl
    689c:	74 2a                	je     68c8 <fwp_rc_share+0x68>
    689e:	80 f9 01             	cmp    $0x1,%cl
    68a1:	75 1e                	jne    68c1 <fwp_rc_share+0x61>
    68a3:	8b 48 18             	mov    0x18(%rax),%ecx
    68a6:	0f b7 ff             	movzwl %di,%edi
    68a9:	8b 40 1c             	mov    0x1c(%rax),%eax
    68ac:	48 0f af f9          	imul   %rcx,%rdi
    68b0:	48 c1 ef 20          	shr    $0x20,%rdi
    68b4:	48 39 c7             	cmp    %rax,%rdi
    68b7:	73 08                	jae    68c1 <fwp_rc_share+0x61>
    68b9:	48 01 fa             	add    %rdi,%rdx
    68bc:	80 3a 00             	cmpb   $0x0,(%rdx)
    68bf:	75 0d                	jne    68ce <fwp_rc_share+0x6e>
    68c1:	c3                   	ret
    68c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68c8:	66 85 ff             	test   %di,%di
    68cb:	74 ef                	je     68bc <fwp_rc_share+0x5c>
    68cd:	c3                   	ret
    68ce:	50                   	push   %rax
    68cf:	48 8d 3d 52 70 00 00 	lea    0x7052(%rip),%rdi        # d928 <_IO_stdin_used+0x928>
    68d6:	e8 15 db ff ff       	call   43f0 <fwp_trap>
    68db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000068e0 <fwp_rc_free_arr>:
    68e0:	48 8b 15 d1 c2 01 00 	mov    0x1c2d1(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 2b 05 9f c2 01 00 	sub    0x1c29f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    68f1:	48 c1 e2 10          	shl    $0x10,%rdx
    68f5:	48 39 d0             	cmp    %rdx,%rax
    68f8:	73 5b                	jae    6955 <fwp_rc_free_arr+0x75>
    68fa:	48 89 c2             	mov    %rax,%rdx
    68fd:	48 c1 ea 10          	shr    $0x10,%rdx
    6901:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6905:	48 8b 15 cc c2 01 00 	mov    0x1c2cc(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    690c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6910:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6914:	48 85 c9             	test   %rcx,%rcx
    6917:	74 3c                	je     6955 <fwp_rc_free_arr+0x75>
    6919:	0f b6 32             	movzbl (%rdx),%esi
    691c:	40 80 fe 02          	cmp    $0x2,%sil
    6920:	74 2e                	je     6950 <fwp_rc_free_arr+0x70>
    6922:	40 80 fe 01          	cmp    $0x1,%sil
    6926:	75 2d                	jne    6955 <fwp_rc_free_arr+0x75>
    6928:	8b 72 18             	mov    0x18(%rdx),%esi
    692b:	0f b7 c0             	movzwl %ax,%eax
    692e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6931:	48 0f af c6          	imul   %rsi,%rax
    6935:	48 c1 e8 20          	shr    $0x20,%rax
    6939:	48 39 d0             	cmp    %rdx,%rax
    693c:	73 17                	jae    6955 <fwp_rc_free_arr+0x75>
    693e:	48 01 c1             	add    %rax,%rcx
    6941:	80 39 01             	cmpb   $0x1,(%rcx)
    6944:	75 0f                	jne    6955 <fwp_rc_free_arr+0x75>
    6946:	e9 45 ee ff ff       	jmp    5790 <fwp_mem_free>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6950:	66 85 c0             	test   %ax,%ax
    6953:	74 ec                	je     6941 <fwp_rc_free_arr+0x61>
    6955:	c3                   	ret
    6956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    695d:	00 00 00 

0000000000006960 <fwp_rc_dup>:
    6960:	f3 0f 1e fa          	endbr64
    6964:	48 8b 05 4d c2 01 00 	mov    0x1c24d(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    696b:	48 2b 3d 1e c2 01 00 	sub    0x1c21e(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    6972:	48 c1 e0 10          	shl    $0x10,%rax
    6976:	48 39 c7             	cmp    %rax,%rdi
    6979:	73 56                	jae    69d1 <fwp_rc_dup+0x71>
    697b:	48 89 f8             	mov    %rdi,%rax
    697e:	48 c1 e8 10          	shr    $0x10,%rax
    6982:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6986:	48 8b 05 4b c2 01 00 	mov    0x1c24b(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    698d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6991:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6995:	48 85 c0             	test   %rax,%rax
    6998:	74 37                	je     69d1 <fwp_rc_dup+0x71>
    699a:	0f b6 0a             	movzbl (%rdx),%ecx
    699d:	80 f9 02             	cmp    $0x2,%cl
    69a0:	74 36                	je     69d8 <fwp_rc_dup+0x78>
    69a2:	80 f9 01             	cmp    $0x1,%cl
    69a5:	75 2a                	jne    69d1 <fwp_rc_dup+0x71>
    69a7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    69aa:	0f b7 ff             	movzwl %di,%edi
    69ad:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69b0:	48 0f af f9          	imul   %rcx,%rdi
    69b4:	48 c1 ef 20          	shr    $0x20,%rdi
    69b8:	48 39 d7             	cmp    %rdx,%rdi
    69bb:	73 14                	jae    69d1 <fwp_rc_dup+0x71>
    69bd:	48 01 f8             	add    %rdi,%rax
    69c0:	0f b6 10             	movzbl (%rax),%edx
    69c3:	84 d2                	test   %dl,%dl
    69c5:	74 0a                	je     69d1 <fwp_rc_dup+0x71>
    69c7:	80 fa fd             	cmp    $0xfd,%dl
    69ca:	77 14                	ja     69e0 <fwp_rc_dup+0x80>
    69cc:	83 c2 01             	add    $0x1,%edx
    69cf:	88 10                	mov    %dl,(%rax)
    69d1:	c3                   	ret
    69d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    69d8:	66 85 ff             	test   %di,%di
    69db:	74 e3                	je     69c0 <fwp_rc_dup+0x60>
    69dd:	c3                   	ret
    69de:	66 90                	xchg   %ax,%ax
    69e0:	48 89 c7             	mov    %rax,%rdi
    69e3:	e9 48 ea ff ff       	jmp    5430 <fwp_rc_wide_dup>
    69e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    69ef:	00 

00000000000069f0 <fwp_drop0>:
    69f0:	f3 0f 1e fa          	endbr64
    69f4:	48 8b 15 bd c1 01 00 	mov    0x1c1bd(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    69fb:	48 89 f8             	mov    %rdi,%rax
    69fe:	48 2b 05 8b c1 01 00 	sub    0x1c18b(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6a05:	48 c1 e2 10          	shl    $0x10,%rdx
    6a09:	48 39 d0             	cmp    %rdx,%rax
    6a0c:	0f 83 be 00 00 00    	jae    6ad0 <fwp_drop0+0xe0>
    6a12:	48 83 ec 18          	sub    $0x18,%rsp
    6a16:	4c 8d 05 c3 ad 01 00 	lea    0x1adc3(%rip),%r8        # 217e0 <fwp_heap>
    6a1d:	48 89 c2             	mov    %rax,%rdx
    6a20:	48 c1 ea 10          	shr    $0x10,%rdx
    6a24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6a33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6a37:	48 85 d2             	test   %rdx,%rdx
    6a3a:	74 3c                	je     6a78 <fwp_drop0+0x88>
    6a3c:	0f b6 31             	movzbl (%rcx),%esi
    6a3f:	40 80 fe 02          	cmp    $0x2,%sil
    6a43:	74 3b                	je     6a80 <fwp_drop0+0x90>
    6a45:	40 80 fe 01          	cmp    $0x1,%sil
    6a49:	75 2d                	jne    6a78 <fwp_drop0+0x88>
    6a4b:	8b 71 18             	mov    0x18(%rcx),%esi
    6a4e:	0f b7 c0             	movzwl %ax,%eax
    6a51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a54:	48 0f af c6          	imul   %rsi,%rax
    6a58:	48 c1 e8 20          	shr    $0x20,%rax
    6a5c:	48 39 c8             	cmp    %rcx,%rax
    6a5f:	73 17                	jae    6a78 <fwp_drop0+0x88>
    6a61:	48 01 c2             	add    %rax,%rdx
    6a64:	0f b6 02             	movzbl (%rdx),%eax
    6a67:	84 c0                	test   %al,%al
    6a69:	74 0d                	je     6a78 <fwp_drop0+0x88>
    6a6b:	3c 01                	cmp    $0x1,%al
    6a6d:	74 21                	je     6a90 <fwp_drop0+0xa0>
    6a6f:	3c ff                	cmp    $0xff,%al
    6a71:	74 65                	je     6ad8 <fwp_drop0+0xe8>
    6a73:	83 e8 01             	sub    $0x1,%eax
    6a76:	88 02                	mov    %al,(%rdx)
    6a78:	48 83 c4 18          	add    $0x18,%rsp
    6a7c:	c3                   	ret
    6a7d:	0f 1f 00             	nopl   (%rax)
    6a80:	66 85 c0             	test   %ax,%ax
    6a83:	74 df                	je     6a64 <fwp_drop0+0x74>
    6a85:	48 83 c4 18          	add    $0x18,%rsp
    6a89:	c3                   	ret
    6a8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6a94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6a99:	e8 42 fe ff ff       	call   68e0 <fwp_rc_free_arr>
    6a9e:	4c 8d 05 3b ad 01 00 	lea    0x1ad3b(%rip),%r8        # 217e0 <fwp_heap>
    6aa5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6aaa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ab1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ab8:	48 c1 e2 10          	shl    $0x10,%rdx
    6abc:	48 39 d0             	cmp    %rdx,%rax
    6abf:	73 b7                	jae    6a78 <fwp_drop0+0x88>
    6ac1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6ac6:	e9 52 ff ff ff       	jmp    6a1d <fwp_drop0+0x2d>
    6acb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ad0:	c3                   	ret
    6ad1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ad8:	48 89 d0             	mov    %rdx,%rax
    6adb:	48 c1 e8 11          	shr    $0x11,%rax
    6adf:	48 31 d0             	xor    %rdx,%rax
    6ae2:	48 89 c1             	mov    %rax,%rcx
    6ae5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ae9:	48 31 c8             	xor    %rcx,%rax
    6aec:	0f b6 c8             	movzbl %al,%ecx
    6aef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6af6:	00 
    6af7:	48 85 c0             	test   %rax,%rax
    6afa:	75 0d                	jne    6b09 <fwp_drop0+0x119>
    6afc:	eb 46                	jmp    6b44 <fwp_drop0+0x154>
    6afe:	66 90                	xchg   %ax,%ax
    6b00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b04:	48 85 c0             	test   %rax,%rax
    6b07:	74 3b                	je     6b44 <fwp_drop0+0x154>
    6b09:	48 89 c1             	mov    %rax,%rcx
    6b0c:	48 39 10             	cmp    %rdx,(%rax)
    6b0f:	75 ef                	jne    6b00 <fwp_drop0+0x110>
    6b11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6b24:	0f 85 4e ff ff ff    	jne    6a78 <fwp_drop0+0x88>
    6b2a:	48 89 d7             	mov    %rdx,%rdi
    6b2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6b32:	e8 19 ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6b37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6b3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6b3f:	e9 34 ff ff ff       	jmp    6a78 <fwp_drop0+0x88>
    6b44:	48 8d 3d 3d 6d 00 00 	lea    0x6d3d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6b4b:	e8 a0 d8 ff ff       	call   43f0 <fwp_trap>

0000000000006b50 <fwp_arg_drop12>:
    6b50:	f3 0f 1e fa          	endbr64
    6b54:	85 f6                	test   %esi,%esi
    6b56:	75 04                	jne    6b5c <fwp_arg_drop12+0xc>
    6b58:	85 d2                	test   %edx,%edx
    6b5a:	75 04                	jne    6b60 <fwp_arg_drop12+0x10>
    6b5c:	c3                   	ret
    6b5d:	0f 1f 00             	nopl   (%rax)
    6b60:	48 8b 3f             	mov    (%rdi),%rdi
    6b63:	e9 88 fe ff ff       	jmp    69f0 <fwp_drop0>
    6b68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6b6f:	00 

0000000000006b70 <fwp_drop1>:
    6b70:	f3 0f 1e fa          	endbr64
    6b74:	48 8b 15 3d c0 01 00 	mov    0x1c03d(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6b7b:	48 89 f8             	mov    %rdi,%rax
    6b7e:	48 2b 05 0b c0 01 00 	sub    0x1c00b(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6b85:	48 c1 e2 10          	shl    $0x10,%rdx
    6b89:	48 39 d0             	cmp    %rdx,%rax
    6b8c:	0f 83 be 00 00 00    	jae    6c50 <fwp_drop1+0xe0>
    6b92:	48 83 ec 18          	sub    $0x18,%rsp
    6b96:	4c 8d 05 43 ac 01 00 	lea    0x1ac43(%rip),%r8        # 217e0 <fwp_heap>
    6b9d:	48 89 c2             	mov    %rax,%rdx
    6ba0:	48 c1 ea 10          	shr    $0x10,%rdx
    6ba4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ba8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6baf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6bb3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6bb7:	48 85 d2             	test   %rdx,%rdx
    6bba:	74 3c                	je     6bf8 <fwp_drop1+0x88>
    6bbc:	0f b6 31             	movzbl (%rcx),%esi
    6bbf:	40 80 fe 02          	cmp    $0x2,%sil
    6bc3:	74 3b                	je     6c00 <fwp_drop1+0x90>
    6bc5:	40 80 fe 01          	cmp    $0x1,%sil
    6bc9:	75 2d                	jne    6bf8 <fwp_drop1+0x88>
    6bcb:	8b 71 18             	mov    0x18(%rcx),%esi
    6bce:	0f b7 c0             	movzwl %ax,%eax
    6bd1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6bd4:	48 0f af c6          	imul   %rsi,%rax
    6bd8:	48 c1 e8 20          	shr    $0x20,%rax
    6bdc:	48 39 c8             	cmp    %rcx,%rax
    6bdf:	73 17                	jae    6bf8 <fwp_drop1+0x88>
    6be1:	48 01 c2             	add    %rax,%rdx
    6be4:	0f b6 02             	movzbl (%rdx),%eax
    6be7:	84 c0                	test   %al,%al
    6be9:	74 0d                	je     6bf8 <fwp_drop1+0x88>
    6beb:	3c 01                	cmp    $0x1,%al
    6bed:	74 21                	je     6c10 <fwp_drop1+0xa0>
    6bef:	3c ff                	cmp    $0xff,%al
    6bf1:	74 65                	je     6c58 <fwp_drop1+0xe8>
    6bf3:	83 e8 01             	sub    $0x1,%eax
    6bf6:	88 02                	mov    %al,(%rdx)
    6bf8:	48 83 c4 18          	add    $0x18,%rsp
    6bfc:	c3                   	ret
    6bfd:	0f 1f 00             	nopl   (%rax)
    6c00:	66 85 c0             	test   %ax,%ax
    6c03:	74 df                	je     6be4 <fwp_drop1+0x74>
    6c05:	48 83 c4 18          	add    $0x18,%rsp
    6c09:	c3                   	ret
    6c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c10:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6c14:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c19:	e8 c2 fc ff ff       	call   68e0 <fwp_rc_free_arr>
    6c1e:	4c 8d 05 bb ab 01 00 	lea    0x1abbb(%rip),%r8        # 217e0 <fwp_heap>
    6c25:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6c2a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6c31:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6c38:	48 c1 e2 10          	shl    $0x10,%rdx
    6c3c:	48 39 d0             	cmp    %rdx,%rax
    6c3f:	73 b7                	jae    6bf8 <fwp_drop1+0x88>
    6c41:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6c46:	e9 52 ff ff ff       	jmp    6b9d <fwp_drop1+0x2d>
    6c4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c50:	c3                   	ret
    6c51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6c58:	48 89 d0             	mov    %rdx,%rax
    6c5b:	48 c1 e8 11          	shr    $0x11,%rax
    6c5f:	48 31 d0             	xor    %rdx,%rax
    6c62:	48 89 c1             	mov    %rax,%rcx
    6c65:	48 c1 e9 09          	shr    $0x9,%rcx
    6c69:	48 31 c8             	xor    %rcx,%rax
    6c6c:	0f b6 c8             	movzbl %al,%ecx
    6c6f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6c76:	00 
    6c77:	48 85 c0             	test   %rax,%rax
    6c7a:	75 0d                	jne    6c89 <fwp_drop1+0x119>
    6c7c:	eb 46                	jmp    6cc4 <fwp_drop1+0x154>
    6c7e:	66 90                	xchg   %ax,%ax
    6c80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6c84:	48 85 c0             	test   %rax,%rax
    6c87:	74 3b                	je     6cc4 <fwp_drop1+0x154>
    6c89:	48 89 c1             	mov    %rax,%rcx
    6c8c:	48 39 10             	cmp    %rdx,(%rax)
    6c8f:	75 ef                	jne    6c80 <fwp_drop1+0x110>
    6c91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6c95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6c99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6c9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ca4:	0f 85 4e ff ff ff    	jne    6bf8 <fwp_drop1+0x88>
    6caa:	48 89 d7             	mov    %rdx,%rdi
    6cad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6cb2:	e8 99 e8 ff ff       	call   5550 <fwp_rc_forget_slot>
    6cb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6cbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6cbf:	e9 34 ff ff ff       	jmp    6bf8 <fwp_drop1+0x88>
    6cc4:	48 8d 3d bd 6b 00 00 	lea    0x6bbd(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6ccb:	e8 20 d7 ff ff       	call   43f0 <fwp_trap>

0000000000006cd0 <fwp_closure_drop>:
    6cd0:	48 8b 15 e1 be 01 00 	mov    0x1bee1(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6cd7:	48 89 f8             	mov    %rdi,%rax
    6cda:	48 2b 05 af be 01 00 	sub    0x1beaf(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6ce1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ce5:	48 39 d0             	cmp    %rdx,%rax
    6ce8:	73 6b                	jae    6d55 <fwp_closure_drop+0x85>
    6cea:	48 89 c2             	mov    %rax,%rdx
    6ced:	48 c1 ea 10          	shr    $0x10,%rdx
    6cf1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cf5:	48 8b 15 dc be 01 00 	mov    0x1bedc(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    6cfc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d00:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d04:	48 85 d2             	test   %rdx,%rdx
    6d07:	74 4c                	je     6d55 <fwp_closure_drop+0x85>
    6d09:	0f b6 31             	movzbl (%rcx),%esi
    6d0c:	40 80 fe 02          	cmp    $0x2,%sil
    6d10:	74 3e                	je     6d50 <fwp_closure_drop+0x80>
    6d12:	40 80 fe 01          	cmp    $0x1,%sil
    6d16:	75 3d                	jne    6d55 <fwp_closure_drop+0x85>
    6d18:	8b 71 18             	mov    0x18(%rcx),%esi
    6d1b:	0f b7 c0             	movzwl %ax,%eax
    6d1e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d21:	48 0f af c6          	imul   %rsi,%rax
    6d25:	48 c1 e8 20          	shr    $0x20,%rax
    6d29:	48 39 c8             	cmp    %rcx,%rax
    6d2c:	73 27                	jae    6d55 <fwp_closure_drop+0x85>
    6d2e:	48 01 c2             	add    %rax,%rdx
    6d31:	0f b6 02             	movzbl (%rdx),%eax
    6d34:	84 c0                	test   %al,%al
    6d36:	74 1d                	je     6d55 <fwp_closure_drop+0x85>
    6d38:	3c 01                	cmp    $0x1,%al
    6d3a:	74 24                	je     6d60 <fwp_closure_drop+0x90>
    6d3c:	3c ff                	cmp    $0xff,%al
    6d3e:	74 48                	je     6d88 <fwp_closure_drop+0xb8>
    6d40:	83 e8 01             	sub    $0x1,%eax
    6d43:	88 02                	mov    %al,(%rdx)
    6d45:	c3                   	ret
    6d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d4d:	00 00 00 
    6d50:	66 85 c0             	test   %ax,%ax
    6d53:	74 dc                	je     6d31 <fwp_closure_drop+0x61>
    6d55:	c3                   	ret
    6d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d5d:	00 00 00 
    6d60:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6d67:	ff ff 
    6d69:	48 85 c0             	test   %rax,%rax
    6d6c:	74 12                	je     6d80 <fwp_closure_drop+0xb0>
    6d6e:	48 89 fe             	mov    %rdi,%rsi
    6d71:	48 89 c7             	mov    %rax,%rdi
    6d74:	e9 d7 d6 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6d79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d80:	e9 7b d8 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6d85:	0f 1f 00             	nopl   (%rax)
    6d88:	48 89 d0             	mov    %rdx,%rax
    6d8b:	48 8d 35 4e aa 01 00 	lea    0x1aa4e(%rip),%rsi        # 217e0 <fwp_heap>
    6d92:	48 83 ec 18          	sub    $0x18,%rsp
    6d96:	48 c1 e8 11          	shr    $0x11,%rax
    6d9a:	48 31 d0             	xor    %rdx,%rax
    6d9d:	48 89 c1             	mov    %rax,%rcx
    6da0:	48 c1 e9 09          	shr    $0x9,%rcx
    6da4:	48 31 c8             	xor    %rcx,%rax
    6da7:	0f b6 c8             	movzbl %al,%ecx
    6daa:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6db1:	00 
    6db2:	48 85 c0             	test   %rax,%rax
    6db5:	75 12                	jne    6dc9 <fwp_closure_drop+0xf9>
    6db7:	eb 49                	jmp    6e02 <fwp_closure_drop+0x132>
    6db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	74 39                	je     6e02 <fwp_closure_drop+0x132>
    6dc9:	48 89 c1             	mov    %rax,%rcx
    6dcc:	48 39 10             	cmp    %rdx,(%rax)
    6dcf:	75 ef                	jne    6dc0 <fwp_closure_drop+0xf0>
    6dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6de4:	74 05                	je     6deb <fwp_closure_drop+0x11b>
    6de6:	48 83 c4 18          	add    $0x18,%rsp
    6dea:	c3                   	ret
    6deb:	48 89 d7             	mov    %rdx,%rdi
    6dee:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6df3:	e8 58 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6df8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dfd:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e00:	eb e4                	jmp    6de6 <fwp_closure_drop+0x116>
    6e02:	48 8d 3d 7f 6a 00 00 	lea    0x6a7f(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6e09:	e8 e2 d5 ff ff       	call   43f0 <fwp_trap>
    6e0e:	66 90                	xchg   %ax,%ax

0000000000006e10 <fwp_owned_tape_release>:
    6e10:	48 85 ff             	test   %rdi,%rdi
    6e13:	0f 84 f7 00 00 00    	je     6f10 <fwp_owned_tape_release+0x100>
    6e19:	41 54                	push   %r12
    6e1b:	55                   	push   %rbp
    6e1c:	53                   	push   %rbx
    6e1d:	48 8b 07             	mov    (%rdi),%rax
    6e20:	48 85 c0             	test   %rax,%rax
    6e23:	74 08                	je     6e2d <fwp_owned_tape_release+0x1d>
    6e25:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e29:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6e2d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6e31:	48 85 d2             	test   %rdx,%rdx
    6e34:	74 03                	je     6e39 <fwp_owned_tape_release+0x29>
    6e36:	48 89 02             	mov    %rax,(%rdx)
    6e39:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6e3d:	48 89 fb             	mov    %rdi,%rbx
    6e40:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	0f 84 89 00 00 00    	je     6ed6 <fwp_owned_tape_release+0xc6>
    6e4d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6e51:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6e55:	7e 47                	jle    6e9e <fwp_owned_tape_release+0x8e>
    6e57:	31 ed                	xor    %ebp,%ebp
    6e59:	eb 0d                	jmp    6e68 <fwp_owned_tape_release+0x58>
    6e5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6e60:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e64:	48 8b 40 68          	mov    0x68(%rax),%rax
    6e68:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6e6c:	49 89 ec             	mov    %rbp,%r12
    6e6f:	48 83 c5 01          	add    $0x1,%rbp
    6e73:	49 c1 e4 04          	shl    $0x4,%r12
    6e77:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6e7b:	ff d0                	call   *%rax
    6e7d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6e81:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6e86:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6e8a:	ff 50 68             	call   *0x68(%rax)
    6e8d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6e91:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6e95:	48 39 e8             	cmp    %rbp,%rax
    6e98:	7f c6                	jg     6e60 <fwp_owned_tape_release+0x50>
    6e9a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6e9e:	31 ed                	xor    %ebp,%ebp
    6ea0:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6ea5:	7e 28                	jle    6ecf <fwp_owned_tape_release+0xbf>
    6ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6eae:	00 00 
    6eb0:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6eb4:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6eb8:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6ebc:	74 07                	je     6ec5 <fwp_owned_tape_release+0xb5>
    6ebe:	ff 52 68             	call   *0x68(%rdx)
    6ec1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ec5:	48 83 c5 01          	add    $0x1,%rbp
    6ec9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6ecd:	7f e1                	jg     6eb0 <fwp_owned_tape_release+0xa0>
    6ecf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6ed3:	ff 52 68             	call   *0x68(%rdx)
    6ed6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6eda:	e8 f1 fd ff ff       	call   6cd0 <fwp_closure_drop>
    6edf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6ee3:	e8 e8 fd ff ff       	call   6cd0 <fwp_closure_drop>
    6ee8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6eec:	e8 df fd ff ff       	call   6cd0 <fwp_closure_drop>
    6ef1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6ef5:	e8 96 e8 ff ff       	call   5790 <fwp_mem_free>
    6efa:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6efe:	e8 8d e8 ff ff       	call   5790 <fwp_mem_free>
    6f03:	48 89 df             	mov    %rbx,%rdi
    6f06:	5b                   	pop    %rbx
    6f07:	5d                   	pop    %rbp
    6f08:	41 5c                	pop    %r12
    6f0a:	e9 81 e8 ff ff       	jmp    5790 <fwp_mem_free>
    6f0f:	90                   	nop
    6f10:	c3                   	ret
    6f11:	0f 1f 40 00          	nopl   0x0(%rax)
    6f15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f1c:	00 00 00 00 

0000000000006f20 <fwp_tape_finish>:
    6f20:	f3 0f 1e fa          	endbr64
    6f24:	41 56                	push   %r14
    6f26:	48 8d 3d 93 a1 01 00 	lea    0x1a193(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    6f2d:	41 55                	push   %r13
    6f2f:	41 54                	push   %r12
    6f31:	55                   	push   %rbp
    6f32:	53                   	push   %rbx
    6f33:	e8 d8 d1 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6f38:	48 83 3d c8 a1 01 00 	cmpq   $0x0,0x1a1c8(%rip)        # 21108 <fwp_ntapes>
    6f3f:	00 
    6f40:	48 c7 05 5d a1 01 00 	movq   $0x0,0x1a15d(%rip)        # 210a8 <fwp_tape_cached_bytes>
    6f47:	00 00 00 00 
    6f4b:	7e 68                	jle    6fb5 <fwp_tape_finish+0x95>
    6f4d:	45 31 e4             	xor    %r12d,%r12d
    6f50:	31 ed                	xor    %ebp,%ebp
    6f52:	0f 1f 00             	nopl   (%rax)
    6f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f5c:	00 00 00 00 
    6f60:	48 8b 1d a9 a1 01 00 	mov    0x1a1a9(%rip),%rbx        # 21110 <fwp_tapes>
    6f67:	48 83 c5 01          	add    $0x1,%rbp
    6f6b:	4c 01 e3             	add    %r12,%rbx
    6f6e:	49 83 c4 68          	add    $0x68,%r12
    6f72:	48 89 df             	mov    %rbx,%rdi
    6f75:	e8 86 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6f7a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6f7e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f82:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6f86:	e8 35 c4 ff ff       	call   33c0 <free@plt>
    6f8b:	4c 89 f7             	mov    %r14,%rdi
    6f8e:	e8 2d c4 ff ff       	call   33c0 <free@plt>
    6f93:	4c 89 ef             	mov    %r13,%rdi
    6f96:	e8 25 c4 ff ff       	call   33c0 <free@plt>
    6f9b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6f9f:	e8 6c fe ff ff       	call   6e10 <fwp_owned_tape_release>
    6fa4:	48 39 2d 5d a1 01 00 	cmp    %rbp,0x1a15d(%rip)        # 21108 <fwp_ntapes>
    6fab:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6fb2:	00 
    6fb3:	7f ab                	jg     6f60 <fwp_tape_finish+0x40>
    6fb5:	48 8b 3d 54 a1 01 00 	mov    0x1a154(%rip),%rdi        # 21110 <fwp_tapes>
    6fbc:	e8 ff c3 ff ff       	call   33c0 <free@plt>
    6fc1:	5b                   	pop    %rbx
    6fc2:	5d                   	pop    %rbp
    6fc3:	48 c7 05 42 a1 01 00 	movq   $0x0,0x1a142(%rip)        # 21110 <fwp_tapes>
    6fca:	00 00 00 00 
    6fce:	48 c7 05 27 a1 01 00 	movq   $0x0,0x1a127(%rip)        # 21100 <fwp_tapes_cap>
    6fd5:	00 00 00 00 
    6fd9:	41 5c                	pop    %r12
    6fdb:	48 c7 05 22 a1 01 00 	movq   $0x0,0x1a122(%rip)        # 21108 <fwp_ntapes>
    6fe2:	00 00 00 00 
    6fe6:	41 5d                	pop    %r13
    6fe8:	48 c7 05 05 a1 01 00 	movq   $0x0,0x1a105(%rip)        # 210f8 <fwp_tape_next_slot>
    6fef:	00 00 00 00 
    6ff3:	41 5e                	pop    %r14
    6ff5:	c3                   	ret
    6ff6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ffd:	00 00 00 

0000000000007000 <fwp_tape_scope_release>:
    7000:	f3 0f 1e fa          	endbr64
    7004:	41 55                	push   %r13
    7006:	41 54                	push   %r12
    7008:	55                   	push   %rbp
    7009:	53                   	push   %rbx
    700a:	48 83 ec 58          	sub    $0x58,%rsp
    700e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7015:	00 00 
    7017:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    701c:	48 63 07             	movslq (%rdi),%rax
    701f:	85 c0                	test   %eax,%eax
    7021:	0f 88 05 01 00 00    	js     712c <fwp_tape_scope_release+0x12c>
    7027:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    702e:	ec c4 4e 
    7031:	48 89 fb             	mov    %rdi,%rbx
    7034:	eb 3c                	jmp    7072 <fwp_tape_scope_release+0x72>
    7036:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    703d:	00 00 00 
    7040:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7045:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7049:	e8 72 c3 ff ff       	call   33c0 <free@plt>
    704e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7052:	e8 69 c3 ff ff       	call   33c0 <free@plt>
    7057:	4c 89 ef             	mov    %r13,%rdi
    705a:	e8 61 c3 ff ff       	call   33c0 <free@plt>
    705f:	4c 89 e7             	mov    %r12,%rdi
    7062:	e8 a9 fd ff ff       	call   6e10 <fwp_owned_tape_release>
    7067:	48 63 03             	movslq (%rbx),%rax
    706a:	85 c0                	test   %eax,%eax
    706c:	0f 88 ba 00 00 00    	js     712c <fwp_tape_scope_release+0x12c>
    7072:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7076:	48 8b 35 93 a0 01 00 	mov    0x1a093(%rip),%rsi        # 21110 <fwp_tapes>
    707d:	4c 01 c6             	add    %r8,%rsi
    7080:	48 89 f7             	mov    %rsi,%rdi
    7083:	e8 78 cb ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7088:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    708d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7092:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7099:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    709d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    70a1:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    70a8:	00 
    70a9:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    70ae:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    70b2:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    70b7:	66 0f ef d2          	pxor   %xmm2,%xmm2
    70bb:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    70c0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    70c7:	00 
    70c8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    70cf:	00 
    70d0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    70d7:	00 
    70d8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    70dd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    70e2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    70e6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    70ea:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    70ee:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    70f4:	77 18                	ja     710e <fwp_tape_scope_release+0x10e>
    70f6:	49 c1 f8 03          	sar    $0x3,%r8
    70fa:	4c 0f af c5          	imul   %rbp,%r8
    70fe:	4c 3b 05 f3 9f 01 00 	cmp    0x19ff3(%rip),%r8        # 210f8 <fwp_tape_next_slot>
    7105:	7d 07                	jge    710e <fwp_tape_scope_release+0x10e>
    7107:	4c 89 05 ea 9f 01 00 	mov    %r8,0x19fea(%rip)        # 210f8 <fwp_tape_next_slot>
    710e:	4d 85 e4             	test   %r12,%r12
    7111:	0f 85 29 ff ff ff    	jne    7040 <fwp_tape_scope_release+0x40>
    7117:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    711c:	e8 4f df ff ff       	call   5070 <fwp_tape_buffers_release>
    7121:	48 63 03             	movslq (%rbx),%rax
    7124:	85 c0                	test   %eax,%eax
    7126:	0f 89 46 ff ff ff    	jns    7072 <fwp_tape_scope_release+0x72>
    712c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    7131:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7138:	00 00 
    713a:	75 0b                	jne    7147 <fwp_tape_scope_release+0x147>
    713c:	48 83 c4 58          	add    $0x58,%rsp
    7140:	5b                   	pop    %rbx
    7141:	5d                   	pop    %rbp
    7142:	41 5c                	pop    %r12
    7144:	41 5d                	pop    %r13
    7146:	c3                   	ret
    7147:	e8 14 c3 ff ff       	call   3460 <__stack_chk_fail@plt>
    714c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007150 <fwp_task_dispose>:
    7150:	53                   	push   %rbx
    7151:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7155:	0f 84 eb c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    715b:	48 89 fb             	mov    %rdi,%rbx
    715e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7163:	0f 85 dd c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7169:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    716d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7174:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    717b:	00 
    717c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7180:	48 85 ff             	test   %rdi,%rdi
    7183:	74 07                	je     718c <fwp_task_dispose+0x3c>
    7185:	48 85 c0             	test   %rax,%rax
    7188:	74 02                	je     718c <fwp_task_dispose+0x3c>
    718a:	ff d0                	call   *%rax
    718c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7193:	e8 f8 e5 ff ff       	call   5790 <fwp_mem_free>
    7198:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    719f:	00 00 00 00 
    71a3:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    71a7:	74 6f                	je     7218 <fwp_task_dispose+0xc8>
    71a9:	48 8b 15 08 ba 01 00 	mov    0x1ba08(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    71b0:	48 89 d8             	mov    %rbx,%rax
    71b3:	48 2b 05 d6 b9 01 00 	sub    0x1b9d6(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    71ba:	48 c1 e2 10          	shl    $0x10,%rdx
    71be:	48 39 d0             	cmp    %rdx,%rax
    71c1:	73 4c                	jae    720f <fwp_task_dispose+0xbf>
    71c3:	48 89 c2             	mov    %rax,%rdx
    71c6:	48 c1 ea 10          	shr    $0x10,%rdx
    71ca:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    71ce:	48 8b 15 03 ba 01 00 	mov    0x1ba03(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    71d5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    71d9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    71dd:	48 85 c9             	test   %rcx,%rcx
    71e0:	74 2d                	je     720f <fwp_task_dispose+0xbf>
    71e2:	0f b6 32             	movzbl (%rdx),%esi
    71e5:	40 80 fe 02          	cmp    $0x2,%sil
    71e9:	74 3d                	je     7228 <fwp_task_dispose+0xd8>
    71eb:	40 80 fe 01          	cmp    $0x1,%sil
    71ef:	75 1e                	jne    720f <fwp_task_dispose+0xbf>
    71f1:	8b 72 18             	mov    0x18(%rdx),%esi
    71f4:	0f b7 c0             	movzwl %ax,%eax
    71f7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71fa:	48 0f af c6          	imul   %rsi,%rax
    71fe:	48 c1 e8 20          	shr    $0x20,%rax
    7202:	48 39 d0             	cmp    %rdx,%rax
    7205:	73 08                	jae    720f <fwp_task_dispose+0xbf>
    7207:	48 01 c1             	add    %rax,%rcx
    720a:	80 39 01             	cmpb   $0x1,(%rcx)
    720d:	74 09                	je     7218 <fwp_task_dispose+0xc8>
    720f:	5b                   	pop    %rbx
    7210:	c3                   	ret
    7211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7218:	48 89 df             	mov    %rbx,%rdi
    721b:	5b                   	pop    %rbx
    721c:	e9 6f e5 ff ff       	jmp    5790 <fwp_mem_free>
    7221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7228:	66 85 c0             	test   %ax,%ax
    722b:	74 dd                	je     720a <fwp_task_dispose+0xba>
    722d:	5b                   	pop    %rbx
    722e:	c3                   	ret
    722f:	90                   	nop

0000000000007230 <fwp_free_zombie>:
    7230:	48 8b 15 79 a5 01 00 	mov    0x1a579(%rip),%rdx        # 217b0 <fwp_zombie>
    7237:	48 85 d2             	test   %rdx,%rdx
    723a:	0f 84 98 00 00 00    	je     72d8 <fwp_free_zombie+0xa8>
    7240:	48 3b 15 79 a5 01 00 	cmp    0x1a579(%rip),%rdx        # 217c0 <fwp_cur>
    7247:	0f 84 8b 00 00 00    	je     72d8 <fwp_free_zombie+0xa8>
    724d:	48 83 ec 18          	sub    $0x18,%rsp
    7251:	48 63 05 2c 9f 01 00 	movslq 0x19f2c(%rip),%rax        # 21184 <fwp_stack_pool_n>
    7258:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    725c:	83 f8 3f             	cmp    $0x3f,%eax
    725f:	7f 7f                	jg     72e0 <fwp_free_zombie+0xb0>
    7261:	8d 48 01             	lea    0x1(%rax),%ecx
    7264:	89 0d 1a 9f 01 00    	mov    %ecx,0x19f1a(%rip)        # 21184 <fwp_stack_pool_n>
    726a:	48 8d 0d 2f 9f 01 00 	lea    0x19f2f(%rip),%rcx        # 211a0 <fwp_stack_pool>
    7271:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7275:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    727c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7280:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7287:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    728b:	48 85 c9             	test   %rcx,%rcx
    728e:	0f 84 fc 00 00 00    	je     7390 <fwp_free_zombie+0x160>
    7294:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    729b:	48 85 c0             	test   %rax,%rax
    729e:	74 07                	je     72a7 <fwp_free_zombie+0x77>
    72a0:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    72a7:	8b 42 5c             	mov    0x5c(%rdx),%eax
    72aa:	66 0f ef c0          	pxor   %xmm0,%xmm0
    72ae:	48 c7 05 f7 a4 01 00 	movq   $0x0,0x1a4f7(%rip)        # 217b0 <fwp_zombie>
    72b5:	00 00 00 00 
    72b9:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    72c0:	85 c0                	test   %eax,%eax
    72c2:	74 34                	je     72f8 <fwp_free_zombie+0xc8>
    72c4:	83 f8 01             	cmp    $0x1,%eax
    72c7:	0f 84 b3 00 00 00    	je     7380 <fwp_free_zombie+0x150>
    72cd:	48 83 c4 18          	add    $0x18,%rsp
    72d1:	c3                   	ret
    72d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72d8:	c3                   	ret
    72d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72e0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    72e4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    72e9:	e8 f2 c2 ff ff       	call   35e0 <munmap@plt>
    72ee:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72f3:	eb 80                	jmp    7275 <fwp_free_zombie+0x45>
    72f5:	0f 1f 00             	nopl   (%rax)
    72f8:	48 8b 0d b9 b8 01 00 	mov    0x1b8b9(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    72ff:	48 89 d0             	mov    %rdx,%rax
    7302:	48 2b 05 87 b8 01 00 	sub    0x1b887(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7309:	48 c1 e1 10          	shl    $0x10,%rcx
    730d:	48 39 c8             	cmp    %rcx,%rax
    7310:	73 bb                	jae    72cd <fwp_free_zombie+0x9d>
    7312:	48 89 c1             	mov    %rax,%rcx
    7315:	48 c1 e9 10          	shr    $0x10,%rcx
    7319:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    731d:	48 8b 0d b4 b8 01 00 	mov    0x1b8b4(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    7324:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7328:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    732c:	48 85 c9             	test   %rcx,%rcx
    732f:	74 9c                	je     72cd <fwp_free_zombie+0x9d>
    7331:	0f b6 3e             	movzbl (%rsi),%edi
    7334:	40 80 ff 02          	cmp    $0x2,%dil
    7338:	74 66                	je     73a0 <fwp_free_zombie+0x170>
    733a:	40 80 ff 01          	cmp    $0x1,%dil
    733e:	75 8d                	jne    72cd <fwp_free_zombie+0x9d>
    7340:	8b 7e 18             	mov    0x18(%rsi),%edi
    7343:	0f b7 c0             	movzwl %ax,%eax
    7346:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7349:	48 0f af c7          	imul   %rdi,%rax
    734d:	48 c1 e8 20          	shr    $0x20,%rax
    7351:	48 39 f0             	cmp    %rsi,%rax
    7354:	0f 83 73 ff ff ff    	jae    72cd <fwp_free_zombie+0x9d>
    735a:	48 01 c1             	add    %rax,%rcx
    735d:	0f b6 01             	movzbl (%rcx),%eax
    7360:	84 c0                	test   %al,%al
    7362:	0f 84 65 ff ff ff    	je     72cd <fwp_free_zombie+0x9d>
    7368:	3c 01                	cmp    $0x1,%al
    736a:	74 14                	je     7380 <fwp_free_zombie+0x150>
    736c:	3c ff                	cmp    $0xff,%al
    736e:	74 3b                	je     73ab <fwp_free_zombie+0x17b>
    7370:	83 e8 01             	sub    $0x1,%eax
    7373:	88 01                	mov    %al,(%rcx)
    7375:	e9 53 ff ff ff       	jmp    72cd <fwp_free_zombie+0x9d>
    737a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7380:	48 89 d7             	mov    %rdx,%rdi
    7383:	48 83 c4 18          	add    $0x18,%rsp
    7387:	e9 c4 fd ff ff       	jmp    7150 <fwp_task_dispose>
    738c:	0f 1f 40 00          	nopl   0x0(%rax)
    7390:	48 89 05 f1 a3 01 00 	mov    %rax,0x1a3f1(%rip)        # 21788 <fwp_tasks_active>
    7397:	e9 ff fe ff ff       	jmp    729b <fwp_free_zombie+0x6b>
    739c:	0f 1f 40 00          	nopl   0x0(%rax)
    73a0:	66 85 c0             	test   %ax,%ax
    73a3:	0f 85 24 ff ff ff    	jne    72cd <fwp_free_zombie+0x9d>
    73a9:	eb b2                	jmp    735d <fwp_free_zombie+0x12d>
    73ab:	48 89 ca             	mov    %rcx,%rdx
    73ae:	48 8d 35 2b a4 01 00 	lea    0x1a42b(%rip),%rsi        # 217e0 <fwp_heap>
    73b5:	48 c1 ea 11          	shr    $0x11,%rdx
    73b9:	48 31 ca             	xor    %rcx,%rdx
    73bc:	48 89 d0             	mov    %rdx,%rax
    73bf:	48 c1 e8 09          	shr    $0x9,%rax
    73c3:	48 31 c2             	xor    %rax,%rdx
    73c6:	0f b6 d2             	movzbl %dl,%edx
    73c9:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    73d0:	00 
    73d1:	48 85 c0             	test   %rax,%rax
    73d4:	75 13                	jne    73e9 <fwp_free_zombie+0x1b9>
    73d6:	eb 4c                	jmp    7424 <fwp_free_zombie+0x1f4>
    73d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    73df:	00 
    73e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    73e4:	48 85 c0             	test   %rax,%rax
    73e7:	74 3b                	je     7424 <fwp_free_zombie+0x1f4>
    73e9:	48 89 c2             	mov    %rax,%rdx
    73ec:	48 39 08             	cmp    %rcx,(%rax)
    73ef:	75 ef                	jne    73e0 <fwp_free_zombie+0x1b0>
    73f1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73f5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    73f9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    73fd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7404:	0f 85 c3 fe ff ff    	jne    72cd <fwp_free_zombie+0x9d>
    740a:	48 89 cf             	mov    %rcx,%rdi
    740d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7412:	e8 39 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    7417:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    741c:	c6 01 fe             	movb   $0xfe,(%rcx)
    741f:	e9 a9 fe ff ff       	jmp    72cd <fwp_free_zombie+0x9d>
    7424:	48 8d 3d 5d 64 00 00 	lea    0x645d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    742b:	e8 c0 cf ff ff       	call   43f0 <fwp_trap>

0000000000007430 <fwp_block>:
    7430:	48 83 ec 08          	sub    $0x8,%rsp
    7434:	48 8b 05 6d a3 01 00 	mov    0x1a36d(%rip),%rax        # 217a8 <fwp_ready_head>
    743b:	48 85 c0             	test   %rax,%rax
    743e:	0f 84 1c 01 00 00    	je     7560 <fwp_block+0x130>
    7444:	90                   	nop
    7445:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    744c:	00 00 00 00 
    7450:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7457:	48 89 15 4a a3 01 00 	mov    %rdx,0x1a34a(%rip)        # 217a8 <fwp_ready_head>
    745e:	48 85 d2             	test   %rdx,%rdx
    7461:	0f 84 19 01 00 00    	je     7580 <fwp_block+0x150>
    7467:	48 8b 15 52 a3 01 00 	mov    0x1a352(%rip),%rdx        # 217c0 <fwp_cur>
    746e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7472:	48 39 c2             	cmp    %rax,%rdx
    7475:	0f 84 d5 00 00 00    	je     7550 <fwp_block+0x120>
    747b:	48 8b 0d c6 bf 01 00 	mov    0x1bfc6(%rip),%rcx        # 23448 <fwp_state_owners>
    7482:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7486:	48 89 05 33 a3 01 00 	mov    %rax,0x1a333(%rip)        # 217c0 <fwp_cur>
    748d:	f3 0f 7e 05 db bf 01 	movq   0x1bfdb(%rip),%xmm0        # 23470 <fwp_foreign_callbacks>
    7494:	00 
    7495:	0f 16 05 c4 bf 01 00 	movhps 0x1bfc4(%rip),%xmm0        # 23460 <fwp_state>
    749c:	f3 0f 7e 0d c4 bf 01 	movq   0x1bfc4(%rip),%xmm1        # 23468 <fwp_handlers>
    74a3:	00 
    74a4:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    74ab:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    74b2:	0f 16 0d bf bf 01 00 	movhps 0x1bfbf(%rip),%xmm1        # 23478 <fwp_cleanups>
    74b9:	f3 0f 7e 05 97 bf 01 	movq   0x1bf97(%rip),%xmm0        # 23458 <fwp_state_len>
    74c0:	00 
    74c1:	0f 16 05 88 bf 01 00 	movhps 0x1bf88(%rip),%xmm0        # 23450 <fwp_state_cap>
    74c8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    74cf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    74d6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    74da:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    74e1:	48 89 0d 80 bf 01 00 	mov    %rcx,0x1bf80(%rip)        # 23468 <fwp_handlers>
    74e8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    74ef:	48 89 0d 82 bf 01 00 	mov    %rcx,0x1bf82(%rip)        # 23478 <fwp_cleanups>
    74f6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    74fd:	48 89 0d 6c bf 01 00 	mov    %rcx,0x1bf6c(%rip)        # 23470 <fwp_foreign_callbacks>
    7504:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    750b:	48 89 0d 4e bf 01 00 	mov    %rcx,0x1bf4e(%rip)        # 23460 <fwp_state>
    7512:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7519:	48 89 0d 38 bf 01 00 	mov    %rcx,0x1bf38(%rip)        # 23458 <fwp_state_len>
    7520:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7527:	48 89 0d 22 bf 01 00 	mov    %rcx,0x1bf22(%rip)        # 23450 <fwp_state_cap>
    752e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7535:	48 89 0d 0c bf 01 00 	mov    %rcx,0x1bf0c(%rip)        # 23448 <fwp_state_owners>
    753c:	e8 4f bf ff ff       	call   3490 <swapcontext@plt>
    7541:	f3 0f 1e fa          	endbr64
    7545:	e8 e6 fc ff ff       	call   7230 <fwp_free_zombie>
    754a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7550:	8b 05 2a 9c 01 00    	mov    0x19c2a(%rip),%eax        # 21180 <fwp_slice>
    7556:	85 c0                	test   %eax,%eax
    7558:	74 36                	je     7590 <fwp_block+0x160>
    755a:	48 83 c4 08          	add    $0x8,%rsp
    755e:	c3                   	ret
    755f:	90                   	nop
    7560:	e8 3b dc ff ff       	call   51a0 <fwp_poll_events>
    7565:	48 8b 05 3c a2 01 00 	mov    0x1a23c(%rip),%rax        # 217a8 <fwp_ready_head>
    756c:	48 85 c0             	test   %rax,%rax
    756f:	0f 85 db fe ff ff    	jne    7450 <fwp_block+0x20>
    7575:	eb e9                	jmp    7560 <fwp_block+0x130>
    7577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    757e:	00 00 
    7580:	48 c7 05 15 a2 01 00 	movq   $0x0,0x1a215(%rip)        # 217a0 <fwp_ready_tail>
    7587:	00 00 00 00 
    758b:	e9 d7 fe ff ff       	jmp    7467 <fwp_block+0x37>
    7590:	48 8d 3d ed 5b 00 00 	lea    0x5bed(%rip),%rdi        # d184 <_IO_stdin_used+0x184>
    7597:	e8 04 be ff ff       	call   33a0 <getenv@plt>
    759c:	ba 10 27 00 00       	mov    $0x2710,%edx
    75a1:	48 85 c0             	test   %rax,%rax
    75a4:	74 05                	je     75ab <fwp_block+0x17b>
    75a6:	80 38 00             	cmpb   $0x0,(%rax)
    75a9:	75 0b                	jne    75b6 <fwp_block+0x186>
    75ab:	89 15 cf 9b 01 00    	mov    %edx,0x19bcf(%rip)        # 21180 <fwp_slice>
    75b1:	48 83 c4 08          	add    $0x8,%rsp
    75b5:	c3                   	ret
    75b6:	ba 0a 00 00 00       	mov    $0xa,%edx
    75bb:	31 f6                	xor    %esi,%esi
    75bd:	48 89 c7             	mov    %rax,%rdi
    75c0:	e8 8b bf ff ff       	call   3550 <strtoll@plt>
    75c5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    75c9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    75d0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    75d5:	0f 46 d0             	cmovbe %eax,%edx
    75d8:	eb d1                	jmp    75ab <fwp_block+0x17b>
    75da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000075e0 <fwp_owned_entry161>:
    75e0:	f3 0f 1e fa          	endbr64
    75e4:	41 56                	push   %r14
    75e6:	55                   	push   %rbp
    75e7:	53                   	push   %rbx
    75e8:	48 83 ec 10          	sub    $0x10,%rsp
    75ec:	48 8b 07             	mov    (%rdi),%rax
    75ef:	48 03 47 10          	add    0x10(%rdi),%rax
    75f3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    75f8:	0f 80 b7 01 00 00    	jo     77b5 <fwp_owned_entry161+0x1d5>
    75fe:	49 89 c6             	mov    %rax,%r14
    7601:	8b 05 7d b5 01 00    	mov    0x1b57d(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    7607:	48 8d 15 d2 a1 01 00 	lea    0x1a1d2(%rip),%rdx        # 217e0 <fwp_heap>
    760e:	85 c0                	test   %eax,%eax
    7610:	0f 84 52 01 00 00    	je     7768 <fwp_owned_entry161+0x188>
    7616:	0f b6 05 65 b1 01 00 	movzbl 0x1b165(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    761d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7624:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7628:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    762c:	48 8b 18             	mov    (%rax),%rbx
    762f:	48 85 db             	test   %rbx,%rbx
    7632:	0f 84 08 01 00 00    	je     7740 <fwp_owned_entry161+0x160>
    7638:	48 8b 13             	mov    (%rbx),%rdx
    763b:	48 f7 d2             	not    %rdx
    763e:	48 89 10             	mov    %rdx,(%rax)
    7641:	48 83 fd 18          	cmp    $0x18,%rbp
    7645:	76 27                	jbe    766e <fwp_owned_entry161+0x8e>
    7647:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    764b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    764f:	31 f6                	xor    %esi,%esi
    7651:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7657:	48 c1 e8 03          	shr    $0x3,%rax
    765b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7662:	00 
    7663:	e8 58 be ff ff       	call   34c0 <memset@plt>
    7668:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    766e:	48 89 e8             	mov    %rbp,%rax
    7671:	48 03 05 88 b5 01 00 	add    0x1b588(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    7678:	0f 82 3c 01 00 00    	jb     77ba <fwp_owned_entry161+0x1da>
    767e:	48 39 05 83 b5 01 00 	cmp    %rax,0x1b583(%rip)        # 22c08 <fwp_heap+0x1428>
    7685:	48 89 05 74 b5 01 00 	mov    %rax,0x1b574(%rip)        # 22c00 <fwp_heap+0x1420>
    768c:	73 07                	jae    7695 <fwp_owned_entry161+0xb5>
    768e:	48 89 05 73 b5 01 00 	mov    %rax,0x1b573(%rip)        # 22c08 <fwp_heap+0x1428>
    7695:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7699:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    769e:	f2 0f 58 0d 72 b5 01 	addsd  0x1b572(%rip),%xmm1        # 22c18 <fwp_heap+0x1438>
    76a5:	00 
    76a6:	f2 0f 11 0d 6a b5 01 	movsd  %xmm1,0x1b56a(%rip)        # 22c18 <fwp_heap+0x1438>
    76ad:	00 
    76ae:	48 8b 05 7b 65 00 00 	mov    0x657b(%rip),%rax        # dc30 <msg.4+0xc0>
    76b5:	66 49 0f 6e d6       	movq   %r14,%xmm2
    76ba:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    76be:	48 89 03             	mov    %rax,(%rbx)
    76c1:	48 89 d8             	mov    %rbx,%rax
    76c4:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    76c8:	48 8b 15 e9 b4 01 00 	mov    0x1b4e9(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    76cf:	48 2b 05 ba b4 01 00 	sub    0x1b4ba(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    76d6:	48 c1 e2 10          	shl    $0x10,%rdx
    76da:	48 39 d0             	cmp    %rdx,%rax
    76dd:	73 53                	jae    7732 <fwp_owned_entry161+0x152>
    76df:	48 89 c2             	mov    %rax,%rdx
    76e2:	48 c1 ea 10          	shr    $0x10,%rdx
    76e6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    76ea:	48 8b 15 e7 b4 01 00 	mov    0x1b4e7(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    76f1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    76f5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    76f9:	48 85 ed             	test   %rbp,%rbp
    76fc:	74 34                	je     7732 <fwp_owned_entry161+0x152>
    76fe:	0f b6 0a             	movzbl (%rdx),%ecx
    7701:	80 f9 02             	cmp    $0x2,%cl
    7704:	0f 84 86 00 00 00    	je     7790 <fwp_owned_entry161+0x1b0>
    770a:	80 f9 01             	cmp    $0x1,%cl
    770d:	75 23                	jne    7732 <fwp_owned_entry161+0x152>
    770f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7712:	0f b7 c0             	movzwl %ax,%eax
    7715:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7718:	48 0f af c1          	imul   %rcx,%rax
    771c:	48 c1 e8 20          	shr    $0x20,%rax
    7720:	48 39 d0             	cmp    %rdx,%rax
    7723:	73 0d                	jae    7732 <fwp_owned_entry161+0x152>
    7725:	48 01 c5             	add    %rax,%rbp
    7728:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    772c:	74 7a                	je     77a8 <fwp_owned_entry161+0x1c8>
    772e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7732:	48 83 c4 10          	add    $0x10,%rsp
    7736:	48 89 d8             	mov    %rbx,%rax
    7739:	5b                   	pop    %rbx
    773a:	5d                   	pop    %rbp
    773b:	41 5e                	pop    %r14
    773d:	c3                   	ret
    773e:	66 90                	xchg   %ax,%ax
    7740:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7744:	48 85 db             	test   %rbx,%rbx
    7747:	74 1f                	je     7768 <fwp_owned_entry161+0x188>
    7749:	48 8b 50 10          	mov    0x10(%rax),%rdx
    774d:	48 29 da             	sub    %rbx,%rdx
    7750:	48 39 ea             	cmp    %rbp,%rdx
    7753:	72 13                	jb     7768 <fwp_owned_entry161+0x188>
    7755:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7759:	48 89 50 08          	mov    %rdx,0x8(%rax)
    775d:	e9 df fe ff ff       	jmp    7641 <fwp_owned_entry161+0x61>
    7762:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7768:	31 f6                	xor    %esi,%esi
    776a:	bf 18 00 00 00       	mov    $0x18,%edi
    776f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7775:	e8 16 e5 ff ff       	call   5c90 <fwp_heap_alloc>
    777a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7780:	48 89 c3             	mov    %rax,%rbx
    7783:	e9 26 ff ff ff       	jmp    76ae <fwp_owned_entry161+0xce>
    7788:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    778f:	00 
    7790:	66 85 c0             	test   %ax,%ax
    7793:	74 93                	je     7728 <fwp_owned_entry161+0x148>
    7795:	48 83 c4 10          	add    $0x10,%rsp
    7799:	48 89 d8             	mov    %rbx,%rax
    779c:	5b                   	pop    %rbx
    779d:	5d                   	pop    %rbp
    779e:	41 5e                	pop    %r14
    77a0:	c3                   	ret
    77a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    77a8:	48 89 ef             	mov    %rbp,%rdi
    77ab:	e8 a0 dd ff ff       	call   5550 <fwp_rc_forget_slot>
    77b0:	e9 79 ff ff ff       	jmp    772e <fwp_owned_entry161+0x14e>
    77b5:	e8 46 bf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    77ba:	e8 f1 c4 ff ff       	call   3cb0 <fwp_heap_oom>
    77bf:	90                   	nop

00000000000077c0 <e161>:
    77c0:	f3 0f 1e fa          	endbr64
    77c4:	41 56                	push   %r14
    77c6:	55                   	push   %rbp
    77c7:	53                   	push   %rbx
    77c8:	48 83 ec 10          	sub    $0x10,%rsp
    77cc:	48 8b 07             	mov    (%rdi),%rax
    77cf:	48 03 47 10          	add    0x10(%rdi),%rax
    77d3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    77d8:	0f 80 bf 01 00 00    	jo     799d <e161+0x1dd>
    77de:	49 89 c6             	mov    %rax,%r14
    77e1:	8b 05 9d b3 01 00    	mov    0x1b39d(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    77e7:	48 8d 15 f2 9f 01 00 	lea    0x19ff2(%rip),%rdx        # 217e0 <fwp_heap>
    77ee:	85 c0                	test   %eax,%eax
    77f0:	0f 84 62 01 00 00    	je     7958 <e161+0x198>
    77f6:	0f b6 05 85 af 01 00 	movzbl 0x1af85(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    77fd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7804:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7808:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    780c:	48 8b 18             	mov    (%rax),%rbx
    780f:	48 85 db             	test   %rbx,%rbx
    7812:	0f 84 18 01 00 00    	je     7930 <e161+0x170>
    7818:	48 8b 13             	mov    (%rbx),%rdx
    781b:	48 f7 d2             	not    %rdx
    781e:	48 89 10             	mov    %rdx,(%rax)
    7821:	48 83 fd 18          	cmp    $0x18,%rbp
    7825:	76 27                	jbe    784e <e161+0x8e>
    7827:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    782b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    782f:	31 f6                	xor    %esi,%esi
    7831:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7837:	48 c1 e8 03          	shr    $0x3,%rax
    783b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7842:	00 
    7843:	e8 78 bc ff ff       	call   34c0 <memset@plt>
    7848:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    784e:	48 89 e8             	mov    %rbp,%rax
    7851:	48 03 05 a8 b3 01 00 	add    0x1b3a8(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    7858:	0f 82 44 01 00 00    	jb     79a2 <e161+0x1e2>
    785e:	48 39 05 a3 b3 01 00 	cmp    %rax,0x1b3a3(%rip)        # 22c08 <fwp_heap+0x1428>
    7865:	48 89 05 94 b3 01 00 	mov    %rax,0x1b394(%rip)        # 22c00 <fwp_heap+0x1420>
    786c:	73 07                	jae    7875 <e161+0xb5>
    786e:	48 89 05 93 b3 01 00 	mov    %rax,0x1b393(%rip)        # 22c08 <fwp_heap+0x1428>
    7875:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7879:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    787e:	f2 0f 58 0d 92 b3 01 	addsd  0x1b392(%rip),%xmm1        # 22c18 <fwp_heap+0x1438>
    7885:	00 
    7886:	f2 0f 11 0d 8a b3 01 	movsd  %xmm1,0x1b38a(%rip)        # 22c18 <fwp_heap+0x1438>
    788d:	00 
    788e:	48 8b 05 9b 63 00 00 	mov    0x639b(%rip),%rax        # dc30 <msg.4+0xc0>
    7895:	66 49 0f 6e d6       	movq   %r14,%xmm2
    789a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    789e:	48 89 03             	mov    %rax,(%rbx)
    78a1:	48 89 d8             	mov    %rbx,%rax
    78a4:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    78a8:	48 8b 15 09 b3 01 00 	mov    0x1b309(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    78af:	48 2b 05 da b2 01 00 	sub    0x1b2da(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    78b6:	48 c1 e2 10          	shl    $0x10,%rdx
    78ba:	48 39 d0             	cmp    %rdx,%rax
    78bd:	73 57                	jae    7916 <e161+0x156>
    78bf:	48 89 c2             	mov    %rax,%rdx
    78c2:	48 c1 ea 10          	shr    $0x10,%rdx
    78c6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    78ca:	48 8b 15 07 b3 01 00 	mov    0x1b307(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    78d1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78d5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    78d9:	48 85 ed             	test   %rbp,%rbp
    78dc:	74 38                	je     7916 <e161+0x156>
    78de:	0f b6 0a             	movzbl (%rdx),%ecx
    78e1:	80 f9 02             	cmp    $0x2,%cl
    78e4:	0f 84 96 00 00 00    	je     7980 <e161+0x1c0>
    78ea:	80 f9 01             	cmp    $0x1,%cl
    78ed:	75 27                	jne    7916 <e161+0x156>
    78ef:	8b 4a 18             	mov    0x18(%rdx),%ecx
    78f2:	0f b7 c0             	movzwl %ax,%eax
    78f5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78f8:	48 0f af c1          	imul   %rcx,%rax
    78fc:	48 c1 e8 20          	shr    $0x20,%rax
    7900:	48 39 d0             	cmp    %rdx,%rax
    7903:	73 11                	jae    7916 <e161+0x156>
    7905:	48 01 c5             	add    %rax,%rbp
    7908:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    790c:	0f 84 7e 00 00 00    	je     7990 <e161+0x1d0>
    7912:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7916:	48 89 df             	mov    %rbx,%rdi
    7919:	e8 42 ef ff ff       	call   6860 <fwp_rc_share>
    791e:	48 83 c4 10          	add    $0x10,%rsp
    7922:	48 89 d8             	mov    %rbx,%rax
    7925:	5b                   	pop    %rbx
    7926:	5d                   	pop    %rbp
    7927:	41 5e                	pop    %r14
    7929:	c3                   	ret
    792a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7930:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7934:	48 85 db             	test   %rbx,%rbx
    7937:	74 1f                	je     7958 <e161+0x198>
    7939:	48 8b 50 10          	mov    0x10(%rax),%rdx
    793d:	48 29 da             	sub    %rbx,%rdx
    7940:	48 39 ea             	cmp    %rbp,%rdx
    7943:	72 13                	jb     7958 <e161+0x198>
    7945:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7949:	48 89 50 08          	mov    %rdx,0x8(%rax)
    794d:	e9 cf fe ff ff       	jmp    7821 <e161+0x61>
    7952:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7958:	31 f6                	xor    %esi,%esi
    795a:	bf 18 00 00 00       	mov    $0x18,%edi
    795f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7965:	e8 26 e3 ff ff       	call   5c90 <fwp_heap_alloc>
    796a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7970:	48 89 c3             	mov    %rax,%rbx
    7973:	e9 16 ff ff ff       	jmp    788e <e161+0xce>
    7978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    797f:	00 
    7980:	66 85 c0             	test   %ax,%ax
    7983:	75 91                	jne    7916 <e161+0x156>
    7985:	eb 81                	jmp    7908 <e161+0x148>
    7987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    798e:	00 00 
    7990:	48 89 ef             	mov    %rbp,%rdi
    7993:	e8 b8 db ff ff       	call   5550 <fwp_rc_forget_slot>
    7998:	e9 75 ff ff ff       	jmp    7912 <e161+0x152>
    799d:	e8 5e bd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    79a2:	e8 09 c3 ff ff       	call   3cb0 <fwp_heap_oom>
    79a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    79ae:	00 00 

00000000000079b0 <fwp_drop4>:
    79b0:	48 8b 15 01 b2 01 00 	mov    0x1b201(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    79b7:	48 89 f8             	mov    %rdi,%rax
    79ba:	48 2b 05 cf b1 01 00 	sub    0x1b1cf(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    79c1:	48 c1 e2 10          	shl    $0x10,%rdx
    79c5:	48 39 d0             	cmp    %rdx,%rax
    79c8:	0f 83 52 01 00 00    	jae    7b20 <fwp_drop4+0x170>
    79ce:	48 83 ec 18          	sub    $0x18,%rsp
    79d2:	4c 8d 05 07 9e 01 00 	lea    0x19e07(%rip),%r8        # 217e0 <fwp_heap>
    79d9:	48 89 c2             	mov    %rax,%rdx
    79dc:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    79e3:	48 c1 ea 10          	shr    $0x10,%rdx
    79e7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    79eb:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    79ef:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    79f3:	48 85 d2             	test   %rdx,%rdx
    79f6:	74 46                	je     7a3e <fwp_drop4+0x8e>
    79f8:	44 0f b6 09          	movzbl (%rcx),%r9d
    79fc:	41 80 f9 02          	cmp    $0x2,%r9b
    7a00:	0f 84 ca 00 00 00    	je     7ad0 <fwp_drop4+0x120>
    7a06:	41 80 f9 01          	cmp    $0x1,%r9b
    7a0a:	75 32                	jne    7a3e <fwp_drop4+0x8e>
    7a0c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7a10:	0f b7 c0             	movzwl %ax,%eax
    7a13:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a16:	49 0f af c1          	imul   %r9,%rax
    7a1a:	48 c1 e8 20          	shr    $0x20,%rax
    7a1e:	48 39 c8             	cmp    %rcx,%rax
    7a21:	73 1b                	jae    7a3e <fwp_drop4+0x8e>
    7a23:	48 01 c2             	add    %rax,%rdx
    7a26:	0f b6 02             	movzbl (%rdx),%eax
    7a29:	84 c0                	test   %al,%al
    7a2b:	74 11                	je     7a3e <fwp_drop4+0x8e>
    7a2d:	3c 01                	cmp    $0x1,%al
    7a2f:	74 17                	je     7a48 <fwp_drop4+0x98>
    7a31:	3c ff                	cmp    $0xff,%al
    7a33:	0f 84 ef 00 00 00    	je     7b28 <fwp_drop4+0x178>
    7a39:	83 e8 01             	sub    $0x1,%eax
    7a3c:	88 02                	mov    %al,(%rdx)
    7a3e:	48 83 c4 18          	add    $0x18,%rsp
    7a42:	c3                   	ret
    7a43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7a48:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7a4c:	0f 88 8e 00 00 00    	js     7ae0 <fwp_drop4+0x130>
    7a52:	48 8b 15 5f b1 01 00 	mov    0x1b15f(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7a59:	48 89 f8             	mov    %rdi,%rax
    7a5c:	48 2b 05 2d b1 01 00 	sub    0x1b12d(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7a63:	48 c1 e2 10          	shl    $0x10,%rdx
    7a67:	48 39 d0             	cmp    %rdx,%rax
    7a6a:	73 d2                	jae    7a3e <fwp_drop4+0x8e>
    7a6c:	48 89 c2             	mov    %rax,%rdx
    7a6f:	48 c1 ea 10          	shr    $0x10,%rdx
    7a73:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a77:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7a7b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7a7f:	48 85 c9             	test   %rcx,%rcx
    7a82:	74 ba                	je     7a3e <fwp_drop4+0x8e>
    7a84:	0f b6 32             	movzbl (%rdx),%esi
    7a87:	40 80 fe 02          	cmp    $0x2,%sil
    7a8b:	74 33                	je     7ac0 <fwp_drop4+0x110>
    7a8d:	40 80 fe 01          	cmp    $0x1,%sil
    7a91:	75 ab                	jne    7a3e <fwp_drop4+0x8e>
    7a93:	8b 72 18             	mov    0x18(%rdx),%esi
    7a96:	0f b7 c0             	movzwl %ax,%eax
    7a99:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7a9c:	48 0f af c6          	imul   %rsi,%rax
    7aa0:	48 c1 e8 20          	shr    $0x20,%rax
    7aa4:	48 39 d0             	cmp    %rdx,%rax
    7aa7:	73 95                	jae    7a3e <fwp_drop4+0x8e>
    7aa9:	48 01 c1             	add    %rax,%rcx
    7aac:	80 39 01             	cmpb   $0x1,(%rcx)
    7aaf:	75 8d                	jne    7a3e <fwp_drop4+0x8e>
    7ab1:	48 83 c4 18          	add    $0x18,%rsp
    7ab5:	e9 d6 dc ff ff       	jmp    5790 <fwp_mem_free>
    7aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ac0:	66 85 c0             	test   %ax,%ax
    7ac3:	74 e7                	je     7aac <fwp_drop4+0xfc>
    7ac5:	48 83 c4 18          	add    $0x18,%rsp
    7ac9:	c3                   	ret
    7aca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ad0:	66 85 c0             	test   %ax,%ax
    7ad3:	0f 84 4d ff ff ff    	je     7a26 <fwp_drop4+0x76>
    7ad9:	48 83 c4 18          	add    $0x18,%rsp
    7add:	c3                   	ret
    7ade:	66 90                	xchg   %ax,%ax
    7ae0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7ae4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7ae9:	e8 f2 ed ff ff       	call   68e0 <fwp_rc_free_arr>
    7aee:	4c 8d 05 eb 9c 01 00 	lea    0x19ceb(%rip),%r8        # 217e0 <fwp_heap>
    7af5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7afa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7b01:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7b08:	48 c1 e2 10          	shl    $0x10,%rdx
    7b0c:	48 39 d0             	cmp    %rdx,%rax
    7b0f:	0f 83 29 ff ff ff    	jae    7a3e <fwp_drop4+0x8e>
    7b15:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7b1a:	e9 ba fe ff ff       	jmp    79d9 <fwp_drop4+0x29>
    7b1f:	90                   	nop
    7b20:	c3                   	ret
    7b21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b28:	48 89 d0             	mov    %rdx,%rax
    7b2b:	48 c1 e8 11          	shr    $0x11,%rax
    7b2f:	48 31 d0             	xor    %rdx,%rax
    7b32:	48 89 c1             	mov    %rax,%rcx
    7b35:	48 c1 e9 09          	shr    $0x9,%rcx
    7b39:	48 31 c8             	xor    %rcx,%rax
    7b3c:	0f b6 c8             	movzbl %al,%ecx
    7b3f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7b46:	00 
    7b47:	48 85 c0             	test   %rax,%rax
    7b4a:	75 1d                	jne    7b69 <fwp_drop4+0x1b9>
    7b4c:	eb 56                	jmp    7ba4 <fwp_drop4+0x1f4>
    7b4e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b5c:	00 00 00 00 
    7b60:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7b64:	48 85 c0             	test   %rax,%rax
    7b67:	74 3b                	je     7ba4 <fwp_drop4+0x1f4>
    7b69:	48 89 c1             	mov    %rax,%rcx
    7b6c:	48 39 10             	cmp    %rdx,(%rax)
    7b6f:	75 ef                	jne    7b60 <fwp_drop4+0x1b0>
    7b71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b75:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7b79:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7b7d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7b84:	0f 85 b4 fe ff ff    	jne    7a3e <fwp_drop4+0x8e>
    7b8a:	48 89 d7             	mov    %rdx,%rdi
    7b8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b92:	e8 b9 d9 ff ff       	call   5550 <fwp_rc_forget_slot>
    7b97:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b9c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7b9f:	e9 9a fe ff ff       	jmp    7a3e <fwp_drop4+0x8e>
    7ba4:	48 8d 3d dd 5c 00 00 	lea    0x5cdd(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    7bab:	e8 40 c8 ff ff       	call   43f0 <fwp_trap>

0000000000007bb0 <fwp_caps161>:
    7bb0:	f3 0f 1e fa          	endbr64
    7bb4:	85 f6                	test   %esi,%esi
    7bb6:	74 08                	je     7bc0 <fwp_caps161+0x10>
    7bb8:	c3                   	ret
    7bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bc0:	48 8b 15 f1 af 01 00 	mov    0x1aff1(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7bc7:	48 89 f8             	mov    %rdi,%rax
    7bca:	48 2b 05 bf af 01 00 	sub    0x1afbf(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7bd1:	48 c1 e2 10          	shl    $0x10,%rdx
    7bd5:	48 39 d0             	cmp    %rdx,%rax
    7bd8:	73 de                	jae    7bb8 <fwp_caps161+0x8>
    7bda:	48 89 c2             	mov    %rax,%rdx
    7bdd:	48 c1 ea 10          	shr    $0x10,%rdx
    7be1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7be5:	48 8b 15 ec af 01 00 	mov    0x1afec(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7bec:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7bf0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7bf4:	48 85 c9             	test   %rcx,%rcx
    7bf7:	74 bf                	je     7bb8 <fwp_caps161+0x8>
    7bf9:	0f b6 32             	movzbl (%rdx),%esi
    7bfc:	40 80 fe 02          	cmp    $0x2,%sil
    7c00:	74 2e                	je     7c30 <fwp_caps161+0x80>
    7c02:	40 80 fe 01          	cmp    $0x1,%sil
    7c06:	75 b0                	jne    7bb8 <fwp_caps161+0x8>
    7c08:	8b 72 18             	mov    0x18(%rdx),%esi
    7c0b:	0f b7 c0             	movzwl %ax,%eax
    7c0e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c11:	48 0f af c6          	imul   %rsi,%rax
    7c15:	48 c1 e8 20          	shr    $0x20,%rax
    7c19:	48 39 d0             	cmp    %rdx,%rax
    7c1c:	73 9a                	jae    7bb8 <fwp_caps161+0x8>
    7c1e:	48 01 c1             	add    %rax,%rcx
    7c21:	80 39 01             	cmpb   $0x1,(%rcx)
    7c24:	75 92                	jne    7bb8 <fwp_caps161+0x8>
    7c26:	e9 65 db ff ff       	jmp    5790 <fwp_mem_free>
    7c2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7c30:	66 85 c0             	test   %ax,%ax
    7c33:	74 ec                	je     7c21 <fwp_caps161+0x71>
    7c35:	c3                   	ret
    7c36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7c3d:	00 00 00 

0000000000007c40 <fwp_args12>:
    7c40:	f3 0f 1e fa          	endbr64
    7c44:	85 d2                	test   %edx,%edx
    7c46:	74 04                	je     7c4c <fwp_args12+0xc>
    7c48:	85 f6                	test   %esi,%esi
    7c4a:	74 04                	je     7c50 <fwp_args12+0x10>
    7c4c:	c3                   	ret
    7c4d:	0f 1f 00             	nopl   (%rax)
    7c50:	48 8b 15 61 af 01 00 	mov    0x1af61(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7c57:	48 8b 07             	mov    (%rdi),%rax
    7c5a:	48 2b 05 2f af 01 00 	sub    0x1af2f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7c61:	48 c1 e2 10          	shl    $0x10,%rdx
    7c65:	48 39 d0             	cmp    %rdx,%rax
    7c68:	73 e2                	jae    7c4c <fwp_args12+0xc>
    7c6a:	48 89 c2             	mov    %rax,%rdx
    7c6d:	48 c1 ea 10          	shr    $0x10,%rdx
    7c71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c75:	48 8b 15 5c af 01 00 	mov    0x1af5c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7c7c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c80:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7c84:	48 85 ff             	test   %rdi,%rdi
    7c87:	74 c3                	je     7c4c <fwp_args12+0xc>
    7c89:	0f b6 0a             	movzbl (%rdx),%ecx
    7c8c:	80 f9 02             	cmp    $0x2,%cl
    7c8f:	74 2f                	je     7cc0 <fwp_args12+0x80>
    7c91:	80 f9 01             	cmp    $0x1,%cl
    7c94:	75 b6                	jne    7c4c <fwp_args12+0xc>
    7c96:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7c99:	0f b7 c0             	movzwl %ax,%eax
    7c9c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c9f:	48 0f af c1          	imul   %rcx,%rax
    7ca3:	48 c1 e8 20          	shr    $0x20,%rax
    7ca7:	48 39 d0             	cmp    %rdx,%rax
    7caa:	73 a0                	jae    7c4c <fwp_args12+0xc>
    7cac:	48 01 c7             	add    %rax,%rdi
    7caf:	0f b6 07             	movzbl (%rdi),%eax
    7cb2:	84 c0                	test   %al,%al
    7cb4:	74 96                	je     7c4c <fwp_args12+0xc>
    7cb6:	3c fd                	cmp    $0xfd,%al
    7cb8:	77 0c                	ja     7cc6 <fwp_args12+0x86>
    7cba:	83 c0 01             	add    $0x1,%eax
    7cbd:	88 07                	mov    %al,(%rdi)
    7cbf:	c3                   	ret
    7cc0:	66 85 c0             	test   %ax,%ax
    7cc3:	74 ea                	je     7caf <fwp_args12+0x6f>
    7cc5:	c3                   	ret
    7cc6:	e9 65 d7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7ccb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007cd0 <fwp_args23>:
    7cd0:	f3 0f 1e fa          	endbr64
    7cd4:	85 d2                	test   %edx,%edx
    7cd6:	74 04                	je     7cdc <fwp_args23+0xc>
    7cd8:	85 f6                	test   %esi,%esi
    7cda:	74 04                	je     7ce0 <fwp_args23+0x10>
    7cdc:	c3                   	ret
    7cdd:	0f 1f 00             	nopl   (%rax)
    7ce0:	48 8b 15 d1 ae 01 00 	mov    0x1aed1(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7ce7:	48 8b 07             	mov    (%rdi),%rax
    7cea:	48 2b 05 9f ae 01 00 	sub    0x1ae9f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7cf1:	48 c1 e2 10          	shl    $0x10,%rdx
    7cf5:	48 39 d0             	cmp    %rdx,%rax
    7cf8:	73 e2                	jae    7cdc <fwp_args23+0xc>
    7cfa:	48 89 c2             	mov    %rax,%rdx
    7cfd:	48 c1 ea 10          	shr    $0x10,%rdx
    7d01:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d05:	48 8b 15 cc ae 01 00 	mov    0x1aecc(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7d0c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d10:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d14:	48 85 ff             	test   %rdi,%rdi
    7d17:	74 c3                	je     7cdc <fwp_args23+0xc>
    7d19:	0f b6 0a             	movzbl (%rdx),%ecx
    7d1c:	80 f9 02             	cmp    $0x2,%cl
    7d1f:	74 2f                	je     7d50 <fwp_args23+0x80>
    7d21:	80 f9 01             	cmp    $0x1,%cl
    7d24:	75 b6                	jne    7cdc <fwp_args23+0xc>
    7d26:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d29:	0f b7 c0             	movzwl %ax,%eax
    7d2c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d2f:	48 0f af c1          	imul   %rcx,%rax
    7d33:	48 c1 e8 20          	shr    $0x20,%rax
    7d37:	48 39 d0             	cmp    %rdx,%rax
    7d3a:	73 a0                	jae    7cdc <fwp_args23+0xc>
    7d3c:	48 01 c7             	add    %rax,%rdi
    7d3f:	0f b6 07             	movzbl (%rdi),%eax
    7d42:	84 c0                	test   %al,%al
    7d44:	74 96                	je     7cdc <fwp_args23+0xc>
    7d46:	3c fd                	cmp    $0xfd,%al
    7d48:	77 0c                	ja     7d56 <fwp_args23+0x86>
    7d4a:	83 c0 01             	add    $0x1,%eax
    7d4d:	88 07                	mov    %al,(%rdi)
    7d4f:	c3                   	ret
    7d50:	66 85 c0             	test   %ax,%ax
    7d53:	74 ea                	je     7d3f <fwp_args23+0x6f>
    7d55:	c3                   	ret
    7d56:	e9 d5 d6 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7d5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007d60 <fwp_caps12>:
    7d60:	f3 0f 1e fa          	endbr64
    7d64:	48 83 ec 18          	sub    $0x18,%rsp
    7d68:	8b 57 04             	mov    0x4(%rdi),%edx
    7d6b:	48 89 f8             	mov    %rdi,%rax
    7d6e:	85 d2                	test   %edx,%edx
    7d70:	0f 84 9a 00 00 00    	je     7e10 <fwp_caps12+0xb0>
    7d76:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7d7a:	85 f6                	test   %esi,%esi
    7d7c:	0f 85 9e 00 00 00    	jne    7e20 <fwp_caps12+0xc0>
    7d82:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7d87:	e8 64 ec ff ff       	call   69f0 <fwp_drop0>
    7d8c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d91:	48 8b 0d 20 ae 01 00 	mov    0x1ae20(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    7d98:	48 89 c2             	mov    %rax,%rdx
    7d9b:	48 2b 15 ee ad 01 00 	sub    0x1adee(%rip),%rdx        # 22b90 <fwp_heap+0x13b0>
    7da2:	48 c1 e1 10          	shl    $0x10,%rcx
    7da6:	48 39 ca             	cmp    %rcx,%rdx
    7da9:	73 6d                	jae    7e18 <fwp_caps12+0xb8>
    7dab:	48 89 d1             	mov    %rdx,%rcx
    7dae:	48 c1 e9 10          	shr    $0x10,%rcx
    7db2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7db6:	48 8b 0d 1b ae 01 00 	mov    0x1ae1b(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    7dbd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7dc1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7dc5:	48 85 f6             	test   %rsi,%rsi
    7dc8:	74 4e                	je     7e18 <fwp_caps12+0xb8>
    7dca:	0f b6 39             	movzbl (%rcx),%edi
    7dcd:	40 80 ff 02          	cmp    $0x2,%dil
    7dd1:	0f 84 b9 00 00 00    	je     7e90 <fwp_caps12+0x130>
    7dd7:	40 80 ff 01          	cmp    $0x1,%dil
    7ddb:	75 3b                	jne    7e18 <fwp_caps12+0xb8>
    7ddd:	8b 79 18             	mov    0x18(%rcx),%edi
    7de0:	0f b7 d2             	movzwl %dx,%edx
    7de3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7de6:	48 0f af d7          	imul   %rdi,%rdx
    7dea:	48 c1 ea 20          	shr    $0x20,%rdx
    7dee:	48 39 ca             	cmp    %rcx,%rdx
    7df1:	73 25                	jae    7e18 <fwp_caps12+0xb8>
    7df3:	48 01 d6             	add    %rdx,%rsi
    7df6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7df9:	75 1d                	jne    7e18 <fwp_caps12+0xb8>
    7dfb:	48 89 c7             	mov    %rax,%rdi
    7dfe:	48 83 c4 18          	add    $0x18,%rsp
    7e02:	e9 89 d9 ff ff       	jmp    5790 <fwp_mem_free>
    7e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e0e:	00 00 
    7e10:	85 f6                	test   %esi,%esi
    7e12:	0f 84 79 ff ff ff    	je     7d91 <fwp_caps12+0x31>
    7e18:	48 83 c4 18          	add    $0x18,%rsp
    7e1c:	c3                   	ret
    7e1d:	0f 1f 00             	nopl   (%rax)
    7e20:	48 8b 05 91 ad 01 00 	mov    0x1ad91(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    7e27:	48 2b 3d 62 ad 01 00 	sub    0x1ad62(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    7e2e:	48 c1 e0 10          	shl    $0x10,%rax
    7e32:	48 39 c7             	cmp    %rax,%rdi
    7e35:	73 e1                	jae    7e18 <fwp_caps12+0xb8>
    7e37:	48 89 f8             	mov    %rdi,%rax
    7e3a:	48 c1 e8 10          	shr    $0x10,%rax
    7e3e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7e42:	48 8b 05 8f ad 01 00 	mov    0x1ad8f(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    7e49:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7e4d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7e51:	48 85 c0             	test   %rax,%rax
    7e54:	74 c2                	je     7e18 <fwp_caps12+0xb8>
    7e56:	0f b6 0a             	movzbl (%rdx),%ecx
    7e59:	80 f9 02             	cmp    $0x2,%cl
    7e5c:	74 42                	je     7ea0 <fwp_caps12+0x140>
    7e5e:	80 f9 01             	cmp    $0x1,%cl
    7e61:	75 b5                	jne    7e18 <fwp_caps12+0xb8>
    7e63:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7e66:	0f b7 ff             	movzwl %di,%edi
    7e69:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7e6c:	48 0f af f9          	imul   %rcx,%rdi
    7e70:	48 c1 ef 20          	shr    $0x20,%rdi
    7e74:	48 39 d7             	cmp    %rdx,%rdi
    7e77:	73 9f                	jae    7e18 <fwp_caps12+0xb8>
    7e79:	48 01 f8             	add    %rdi,%rax
    7e7c:	0f b6 10             	movzbl (%rax),%edx
    7e7f:	84 d2                	test   %dl,%dl
    7e81:	74 95                	je     7e18 <fwp_caps12+0xb8>
    7e83:	80 fa fd             	cmp    $0xfd,%dl
    7e86:	77 23                	ja     7eab <fwp_caps12+0x14b>
    7e88:	83 c2 01             	add    $0x1,%edx
    7e8b:	88 10                	mov    %dl,(%rax)
    7e8d:	eb 89                	jmp    7e18 <fwp_caps12+0xb8>
    7e8f:	90                   	nop
    7e90:	66 85 d2             	test   %dx,%dx
    7e93:	0f 85 7f ff ff ff    	jne    7e18 <fwp_caps12+0xb8>
    7e99:	e9 58 ff ff ff       	jmp    7df6 <fwp_caps12+0x96>
    7e9e:	66 90                	xchg   %ax,%ax
    7ea0:	66 85 ff             	test   %di,%di
    7ea3:	0f 85 6f ff ff ff    	jne    7e18 <fwp_caps12+0xb8>
    7ea9:	eb d1                	jmp    7e7c <fwp_caps12+0x11c>
    7eab:	48 89 c7             	mov    %rax,%rdi
    7eae:	48 83 c4 18          	add    $0x18,%rsp
    7eb2:	e9 79 d5 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7eb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7ebe:	00 00 

0000000000007ec0 <f12>:
    7ec0:	41 57                	push   %r15
    7ec2:	41 56                	push   %r14
    7ec4:	41 55                	push   %r13
    7ec6:	4c 8d 2d 33 f1 ff ff 	lea    -0xecd(%rip),%r13        # 7000 <fwp_tape_scope_release>
    7ecd:	41 54                	push   %r12
    7ecf:	55                   	push   %rbp
    7ed0:	53                   	push   %rbx
    7ed1:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    7ed8:	48 8b 15 d9 ac 01 00 	mov    0x1acd9(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7edf:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    7ee4:	4c 8d 7c 24 60       	lea    0x60(%rsp),%r15
    7ee9:	48 c1 e2 10          	shl    $0x10,%rdx
    7eed:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7ef4:	00 00 
    7ef6:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    7efd:	00 
    7efe:	31 c0                	xor    %eax,%eax
    7f00:	48 8b 05 71 b5 01 00 	mov    0x1b571(%rip),%rax        # 23478 <fwp_cleanups>
    7f07:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    7f0e:	ff 
    7f0f:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
    7f14:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7f19:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    7f1e:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7f23:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    7f28:	48 8d 05 e1 90 00 00 	lea    0x90e1(%rip),%rax        # 11010 <fc23>
    7f2f:	48 2b 05 5a ac 01 00 	sub    0x1ac5a(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7f36:	4c 89 3d 3b b5 01 00 	mov    %r15,0x1b53b(%rip)        # 23478 <fwp_cleanups>
    7f3d:	48 39 d0             	cmp    %rdx,%rax
    7f40:	73 5d                	jae    7f9f <f12+0xdf>
    7f42:	48 89 c2             	mov    %rax,%rdx
    7f45:	48 c1 ea 10          	shr    $0x10,%rdx
    7f49:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f4d:	48 8b 15 84 ac 01 00 	mov    0x1ac84(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7f54:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f58:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f5c:	48 85 ff             	test   %rdi,%rdi
    7f5f:	74 3e                	je     7f9f <f12+0xdf>
    7f61:	0f b6 0a             	movzbl (%rdx),%ecx
    7f64:	80 f9 02             	cmp    $0x2,%cl
    7f67:	0f 84 d3 11 00 00    	je     9140 <f12+0x1280>
    7f6d:	80 f9 01             	cmp    $0x1,%cl
    7f70:	75 2d                	jne    7f9f <f12+0xdf>
    7f72:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f75:	0f b7 c0             	movzwl %ax,%eax
    7f78:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f7b:	48 0f af c1          	imul   %rcx,%rax
    7f7f:	48 c1 e8 20          	shr    $0x20,%rax
    7f83:	48 39 d0             	cmp    %rdx,%rax
    7f86:	73 17                	jae    7f9f <f12+0xdf>
    7f88:	48 01 c7             	add    %rax,%rdi
    7f8b:	0f b6 07             	movzbl (%rdi),%eax
    7f8e:	84 c0                	test   %al,%al
    7f90:	74 0d                	je     7f9f <f12+0xdf>
    7f92:	3c fd                	cmp    $0xfd,%al
    7f94:	0f 87 0f 14 00 00    	ja     93a9 <f12+0x14e9>
    7f9a:	83 c0 01             	add    $0x1,%eax
    7f9d:	88 07                	mov    %al,(%rdi)
    7f9f:	48 8d 3d 6a 90 00 00 	lea    0x906a(%rip),%rdi        # 11010 <fc23>
    7fa6:	e8 25 ed ff ff       	call   6cd0 <fwp_closure_drop>
    7fab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7fb0:	48 85 c0             	test   %rax,%rax
    7fb3:	0f 84 56 13 00 00    	je     930f <f12+0x144f>
    7fb9:	31 db                	xor    %ebx,%ebx
    7fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7fc0:	48 8b 40 10          	mov    0x10(%rax),%rax
    7fc4:	48 83 c3 01          	add    $0x1,%rbx
    7fc8:	48 85 c0             	test   %rax,%rax
    7fcb:	75 f3                	jne    7fc0 <f12+0x100>
    7fcd:	31 ff                	xor    %edi,%edi
    7fcf:	e8 7c c2 ff ff       	call   4250 <descent_phase_step>
    7fd4:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    7fdb:	0f 87 d6 14 00 00    	ja     94b7 <f12+0x15f7>
    7fe1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    7fe6:	44 8b 05 93 90 00 00 	mov    0x9093(%rip),%r8d        # 11080 <registered_finish.0>
    7fed:	45 85 c0             	test   %r8d,%r8d
    7ff0:	0f 84 1a 11 00 00    	je     9110 <f12+0x1250>
    7ff6:	48 8b 1d fb 90 01 00 	mov    0x190fb(%rip),%rbx        # 210f8 <fwp_tape_next_slot>
    7ffd:	4c 8b 25 04 91 01 00 	mov    0x19104(%rip),%r12        # 21108 <fwp_ntapes>
    8004:	4c 39 e3             	cmp    %r12,%rbx
    8007:	0f 8d e3 05 00 00    	jge    85f0 <f12+0x730>
    800d:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8011:	48 03 05 f8 90 01 00 	add    0x190f8(%rip),%rax        # 21110 <fwp_tapes>
    8018:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    801f:	00 
    8020:	8b 78 04             	mov    0x4(%rax),%edi
    8023:	85 ff                	test   %edi,%edi
    8025:	75 0c                	jne    8033 <f12+0x173>
    8027:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    802d:	0f 86 bd 05 00 00    	jbe    85f0 <f12+0x730>
    8033:	48 83 c3 01          	add    $0x1,%rbx
    8037:	48 83 c0 68          	add    $0x68,%rax
    803b:	4c 39 e3             	cmp    %r12,%rbx
    803e:	75 e0                	jne    8020 <f12+0x160>
    8040:	49 81 fc fe ff 00 00 	cmp    $0xfffe,%r12
    8047:	0f 8f 9a 14 00 00    	jg     94e7 <f12+0x1627>
    804d:	4c 39 25 ac 90 01 00 	cmp    %r12,0x190ac(%rip)        # 21100 <fwp_tapes_cap>
    8054:	48 8b 2d b5 90 01 00 	mov    0x190b5(%rip),%rbp        # 21110 <fwp_tapes>
    805b:	75 4b                	jne    80a8 <f12+0x1e8>
    805d:	4d 85 e4             	test   %r12,%r12
    8060:	0f 84 42 12 00 00    	je     92a8 <f12+0x13e8>
    8066:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    806a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    806f:	49 39 c6             	cmp    %rax,%r14
    8072:	4c 0f 4f f0          	cmovg  %rax,%r14
    8076:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    807a:	48 89 ef             	mov    %rbp,%rdi
    807d:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8083:	e8 48 b5 ff ff       	call   35d0 <realloc@plt>
    8088:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    808e:	48 85 c0             	test   %rax,%rax
    8091:	48 89 c5             	mov    %rax,%rbp
    8094:	0f 84 eb 10 00 00    	je     9185 <f12+0x12c5>
    809a:	48 89 05 6f 90 01 00 	mov    %rax,0x1906f(%rip)        # 21110 <fwp_tapes>
    80a1:	4c 89 35 58 90 01 00 	mov    %r14,0x19058(%rip)        # 21100 <fwp_tapes_cap>
    80a8:	49 6b c4 68          	imul   $0x68,%r12,%rax
    80ac:	49 83 c4 01          	add    $0x1,%r12
    80b0:	48 01 e8             	add    %rbp,%rax
    80b3:	48 8d 78 08          	lea    0x8(%rax),%rdi
    80b7:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    80be:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    80c2:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    80c9:	00 
    80ca:	48 29 f8             	sub    %rdi,%rax
    80cd:	8d 48 68             	lea    0x68(%rax),%ecx
    80d0:	31 c0                	xor    %eax,%eax
    80d2:	c1 e9 03             	shr    $0x3,%ecx
    80d5:	f3 48 ab             	rep stos %rax,(%rdi)
    80d8:	4c 89 25 29 90 01 00 	mov    %r12,0x19029(%rip)        # 21108 <fwp_ntapes>
    80df:	4c 6b e3 68          	imul   $0x68,%rbx,%r12
    80e3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    80e7:	48 8d 3d 34 50 00 00 	lea    0x5034(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    80ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    80f3:	49 01 ec             	add    %rbp,%r12
    80f6:	49 c7 44 24 60 00 00 	movq   $0x0,0x60(%r12)
    80fd:	00 00 
    80ff:	e8 9c b2 ff ff       	call   33a0 <getenv@plt>
    8104:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    810a:	48 85 c0             	test   %rax,%rax
    810d:	74 09                	je     8118 <f12+0x258>
    810f:	80 38 30             	cmpb   $0x30,(%rax)
    8112:	0f 84 28 04 00 00    	je     8540 <f12+0x680>
    8118:	48 83 3d 88 8f 01 00 	cmpq   $0x0,0x18f88(%rip)        # 210a8 <fwp_tape_cached_bytes>
    811f:	00 
    8120:	0f 85 ba 10 00 00    	jne    91e0 <f12+0x1320>
    8126:	41 8b 04 24          	mov    (%r12),%eax
    812a:	4c 8d 43 01          	lea    0x1(%rbx),%r8
    812e:	41 c7 44 24 04 01 00 	movl   $0x1,0x4(%r12)
    8135:	00 00 
    8137:	4c 89 05 ba 8f 01 00 	mov    %r8,0x18fba(%rip)        # 210f8 <fwp_tape_next_slot>
    813e:	8d 70 01             	lea    0x1(%rax),%esi
    8141:	48 8b 05 30 b3 01 00 	mov    0x1b330(%rip),%rax        # 23478 <fwp_cleanups>
    8148:	49 c7 44 24 50 00 00 	movq   $0x0,0x50(%r12)
    814f:	00 00 
    8151:	41 89 34 24          	mov    %esi,(%r12)
    8155:	49 c7 44 24 58 ff ff 	movq   $0xffffffffffffffff,0x58(%r12)
    815c:	ff ff 
    815e:	41 0f 11 44 24 08    	movups %xmm0,0x8(%r12)
    8164:	48 85 c0             	test   %rax,%rax
    8167:	75 13                	jne    817c <f12+0x2bc>
    8169:	e9 6d 13 00 00       	jmp    94db <f12+0x161b>
    816e:	66 90                	xchg   %ax,%ax
    8170:	48 8b 00             	mov    (%rax),%rax
    8173:	48 85 c0             	test   %rax,%rax
    8176:	0f 84 5f 13 00 00    	je     94db <f12+0x161b>
    817c:	4c 39 68 08          	cmp    %r13,0x8(%rax)
    8180:	75 ee                	jne    8170 <f12+0x2b0>
    8182:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8186:	89 df                	mov    %ebx,%edi
    8188:	48 63 01             	movslq (%rcx),%rax
    818b:	49 89 4c 24 50       	mov    %rcx,0x50(%r12)
    8190:	41 89 44 24 5c       	mov    %eax,0x5c(%r12)
    8195:	85 c0                	test   %eax,%eax
    8197:	78 08                	js     81a1 <f12+0x2e1>
    8199:	48 6b c0 68          	imul   $0x68,%rax,%rax
    819d:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    81a1:	89 39                	mov    %edi,(%rcx)
    81a3:	bf 01 00 00 00       	mov    $0x1,%edi
    81a8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    81ad:	89 74 24 10          	mov    %esi,0x10(%rsp)
    81b1:	e8 9a c0 ff ff       	call   4250 <descent_phase_step>
    81b6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    81bb:	31 c9                	xor    %ecx,%ecx
    81bd:	8b 74 24 10          	mov    0x10(%rsp),%esi
    81c1:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    81c6:	48 85 ff             	test   %rdi,%rdi
    81c9:	48 89 f8             	mov    %rdi,%rax
    81cc:	0f 84 7e 03 00 00    	je     8550 <f12+0x690>
    81d2:	0f 1f 00             	nopl   (%rax)
    81d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81dc:	00 00 00 00 
    81e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    81e4:	48 83 c1 01          	add    $0x1,%rcx
    81e8:	48 85 c0             	test   %rax,%rax
    81eb:	75 f3                	jne    81e0 <f12+0x320>
    81ed:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    81f2:	0f 1f 00             	nopl   (%rax)
    81f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81fc:	00 00 00 00 
    8200:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8204:	48 83 c0 01          	add    $0x1,%rax
    8208:	48 85 d2             	test   %rdx,%rdx
    820b:	75 f3                	jne    8200 <f12+0x340>
    820d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8214:	ff ff 1f 
    8217:	48 39 c2             	cmp    %rax,%rdx
    821a:	0f 82 a3 12 00 00    	jb     94c3 <f12+0x1603>
    8220:	48 85 c9             	test   %rcx,%rcx
    8223:	0f 8e 27 03 00 00    	jle    8550 <f12+0x690>
    8229:	48 39 c1             	cmp    %rax,%rcx
    822c:	48 0f 46 c1          	cmovbe %rcx,%rax
    8230:	49 89 c5             	mov    %rax,%r13
    8233:	48 c1 e8 3c          	shr    $0x3c,%rax
    8237:	0f 85 86 12 00 00    	jne    94c3 <f12+0x1603>
    823d:	48 c1 e6 10          	shl    $0x10,%rsi
    8241:	4b 8d 6c 2d 00       	lea    0x0(%r13,%r13,1),%rbp
    8246:	4c 09 c6             	or     %r8,%rsi
    8249:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8250:	00 
    8251:	49 89 f4             	mov    %rsi,%r12
    8254:	be 02 00 00 00       	mov    $0x2,%esi
    8259:	e8 32 da ff ff       	call   5c90 <fwp_heap_alloc>
    825e:	48 89 28             	mov    %rbp,(%rax)
    8261:	48 8b 15 50 a9 01 00 	mov    0x1a950(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    8268:	48 89 c3             	mov    %rax,%rbx
    826b:	48 2b 05 1e a9 01 00 	sub    0x1a91e(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8272:	48 c1 e2 10          	shl    $0x10,%rdx
    8276:	48 39 d0             	cmp    %rdx,%rax
    8279:	0f 83 51 03 00 00    	jae    85d0 <f12+0x710>
    827f:	48 89 c2             	mov    %rax,%rdx
    8282:	48 c1 ea 10          	shr    $0x10,%rdx
    8286:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    828a:	48 8b 15 47 a9 01 00 	mov    0x1a947(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    8291:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    8295:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8299:	48 85 d2             	test   %rdx,%rdx
    829c:	74 38                	je     82d6 <f12+0x416>
    829e:	0f b6 31             	movzbl (%rcx),%esi
    82a1:	40 80 fe 02          	cmp    $0x2,%sil
    82a5:	0f 84 12 03 00 00    	je     85bd <f12+0x6fd>
    82ab:	40 80 fe 01          	cmp    $0x1,%sil
    82af:	75 25                	jne    82d6 <f12+0x416>
    82b1:	8b 71 18             	mov    0x18(%rcx),%esi
    82b4:	0f b7 c0             	movzwl %ax,%eax
    82b7:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    82ba:	48 0f af c6          	imul   %rsi,%rax
    82be:	48 c1 e8 20          	shr    $0x20,%rax
    82c2:	48 39 c8             	cmp    %rcx,%rax
    82c5:	73 0f                	jae    82d6 <f12+0x416>
    82c7:	48 01 c2             	add    %rax,%rdx
    82ca:	80 3a ff             	cmpb   $0xff,(%rdx)
    82cd:	0f 84 a5 10 00 00    	je     9378 <f12+0x14b8>
    82d3:	c6 02 01             	movb   $0x1,(%rdx)
    82d6:	4d 85 ed             	test   %r13,%r13
    82d9:	74 58                	je     8333 <f12+0x473>
    82db:	4c 89 e1             	mov    %r12,%rcx
    82de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    82e3:	31 c0                	xor    %eax,%eax
    82e5:	48 c1 e1 20          	shl    $0x20,%rcx
    82e9:	90                   	nop
    82ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82f1:	00 00 00 00 
    82f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82fc:	00 00 00 00 
    8300:	48 89 c6             	mov    %rax,%rsi
    8303:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8308:	48 01 ce             	add    %rcx,%rsi
    830b:	0f 80 8d 11 00 00    	jo     949e <f12+0x15de>
    8311:	66 48 0f 6e de       	movq   %rsi,%xmm3
    8316:	48 89 c6             	mov    %rax,%rsi
    8319:	48 83 c0 01          	add    $0x1,%rax
    831d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    8321:	48 c1 e6 04          	shl    $0x4,%rsi
    8325:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    832a:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    832e:	4c 39 e8             	cmp    %r13,%rax
    8331:	72 cd                	jb     8300 <f12+0x440>
    8333:	48 8b 03             	mov    (%rbx),%rax
    8336:	48 d1 e8             	shr    $1,%rax
    8339:	0f 84 a1 02 00 00    	je     85e0 <f12+0x720>
    833f:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    8343:	48 89 d1             	mov    %rdx,%rcx
    8346:	48 c1 e9 3c          	shr    $0x3c,%rcx
    834a:	0f 85 73 11 00 00    	jne    94c3 <f12+0x1603>
    8350:	48 8d 2c 12          	lea    (%rdx,%rdx,1),%rbp
    8354:	48 85 d2             	test   %rdx,%rdx
    8357:	74 45                	je     839e <f12+0x4de>
    8359:	48 c1 e0 04          	shl    $0x4,%rax
    835d:	4c 8d 73 08          	lea    0x8(%rbx),%r14
    8361:	4c 8d 6c 03 f8       	lea    -0x8(%rbx,%rax,1),%r13
    8366:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    836d:	00 00 00 
    8370:	f2 41 0f 10 06       	movsd  (%r14),%xmm0
    8375:	49 8b 76 18          	mov    0x18(%r14),%rsi
    8379:	49 83 c6 10          	add    $0x10,%r14
    837d:	49 8b 7e f8          	mov    -0x8(%r14),%rdi
    8381:	f2 41 0f 10 0e       	movsd  (%r14),%xmm1
    8386:	e8 65 e1 ff ff       	call   64f0 <w107>
    838b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8390:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8394:	41 0f 11 46 f0       	movups %xmm0,-0x10(%r14)
    8399:	4d 39 f5             	cmp    %r14,%r13
    839c:	75 d2                	jne    8370 <f12+0x4b0>
    839e:	48 89 2b             	mov    %rbp,(%rbx)
    83a1:	48 89 df             	mov    %rbx,%rdi
    83a4:	e8 07 e3 ff ff       	call   66b0 <w164.constprop.0>
    83a9:	48 89 df             	mov    %rbx,%rdi
    83ac:	49 63 dc             	movslq %r12d,%rbx
    83af:	49 89 c5             	mov    %rax,%r13
    83b2:	e8 f9 f5 ff ff       	call   79b0 <fwp_drop4>
    83b7:	bf 02 00 00 00       	mov    $0x2,%edi
    83bc:	e8 8f be ff ff       	call   4250 <descent_phase_step>
    83c1:	48 89 df             	mov    %rbx,%rdi
    83c4:	e8 07 c3 ff ff       	call   46d0 <fwp_tape_of>
    83c9:	48 89 c6             	mov    %rax,%rsi
    83cc:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    83d1:	0f 85 f8 10 00 00    	jne    94cf <f12+0x160f>
    83d7:	48 89 c7             	mov    %rax,%rdi
    83da:	e8 21 b8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    83df:	f3 0f 6f 7e 20       	movdqu 0x20(%rsi),%xmm7
    83e4:	48 8b 56 48          	mov    0x48(%rsi),%rdx
    83e8:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    83ef:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    83f4:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    83f8:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    83fd:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8402:	66 48 0f 6e d2       	movq   %rdx,%xmm2
    8407:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
    840b:	4c 8b 76 40          	mov    0x40(%rsi),%r14
    840f:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8413:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    8418:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    841e:	77 19                	ja     8439 <f12+0x579>
    8420:	41 0f b7 c4          	movzwl %r12w,%eax
    8424:	83 e8 01             	sub    $0x1,%eax
    8427:	48 98                	cltq
    8429:	48 3b 05 c8 8c 01 00 	cmp    0x18cc8(%rip),%rax        # 210f8 <fwp_tape_next_slot>
    8430:	7d 07                	jge    8439 <f12+0x579>
    8432:	48 89 05 bf 8c 01 00 	mov    %rax,0x18cbf(%rip)        # 210f8 <fwp_tape_next_slot>
    8439:	66 0f ef c9          	pxor   %xmm1,%xmm1
    843d:	48 8b 05 34 b0 01 00 	mov    0x1b034(%rip),%rax        # 23478 <fwp_cleanups>
    8444:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    844a:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
    8451:	00 
    8452:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    8458:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    845c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    8463:	00 
    8464:	48 8d 05 05 cc ff ff 	lea    -0x33fb(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    846b:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    8472:	00 
    8473:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    847a:	00 
    847b:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8482:	00 
    8483:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8487:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    848b:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8492:	00 
    8493:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    849a:	00 
    849b:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    84a2:	00 
    84a3:	4c 89 a4 24 90 00 00 	mov    %r12,0x90(%rsp)
    84aa:	00 
    84ab:	48 89 05 c6 af 01 00 	mov    %rax,0x1afc6(%rip)        # 23478 <fwp_cleanups>
    84b2:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    84b9:	00 
    84ba:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    84c1:	00 
    84c2:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    84c9:	00 
    84ca:	4d 85 ed             	test   %r13,%r13
    84cd:	0f 88 7d 0c 00 00    	js     9150 <f12+0x1290>
    84d3:	4c 89 e8             	mov    %r13,%rax
    84d6:	48 c1 f8 20          	sar    $0x20,%rax
    84da:	48 39 c3             	cmp    %rax,%rbx
    84dd:	0f 85 92 0f 00 00    	jne    9475 <f12+0x15b5>
    84e3:	45 89 ea             	mov    %r13d,%r10d
    84e6:	4c 39 d7             	cmp    %r10,%rdi
    84e9:	0f 8e 92 0f 00 00    	jle    9481 <f12+0x15c1>
    84ef:	4c 39 d5             	cmp    %r10,%rbp
    84f2:	0f 8e 10 01 00 00    	jle    8608 <f12+0x748>
    84f8:	48 39 d5             	cmp    %rdx,%rbp
    84fb:	0f 8f 57 0d 00 00    	jg     9258 <f12+0x1398>
    8501:	4d 85 f6             	test   %r14,%r14
    8504:	0f 84 64 0c 00 00    	je     916e <f12+0x12ae>
    850a:	4c 8d 4d ff          	lea    -0x1(%rbp),%r9
    850e:	31 f6                	xor    %esi,%esi
    8510:	4c 89 f7             	mov    %r14,%rdi
    8513:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    8518:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    851f:	00 
    8520:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    8525:	e8 96 af ff ff       	call   34c0 <memset@plt>
    852a:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    852f:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    8534:	45 31 db             	xor    %r11d,%r11d
    8537:	e9 5b 01 00 00       	jmp    8697 <f12+0x7d7>
    853c:	0f 1f 40 00          	nopl   0x0(%rax)
    8540:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8544:	0f 84 dc fb ff ff    	je     8126 <f12+0x266>
    854a:	e9 c9 fb ff ff       	jmp    8118 <f12+0x258>
    854f:	90                   	nop
    8550:	48 c1 e6 10          	shl    $0x10,%rsi
    8554:	bf 08 00 00 00       	mov    $0x8,%edi
    8559:	4c 09 c6             	or     %r8,%rsi
    855c:	49 89 f4             	mov    %rsi,%r12
    855f:	be 02 00 00 00       	mov    $0x2,%esi
    8564:	e8 27 d7 ff ff       	call   5c90 <fwp_heap_alloc>
    8569:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8570:	48 8b 15 41 a6 01 00 	mov    0x1a641(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    8577:	48 89 c3             	mov    %rax,%rbx
    857a:	48 2b 05 0f a6 01 00 	sub    0x1a60f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8581:	48 c1 e2 10          	shl    $0x10,%rdx
    8585:	48 39 d0             	cmp    %rdx,%rax
    8588:	73 56                	jae    85e0 <f12+0x720>
    858a:	48 89 c2             	mov    %rax,%rdx
    858d:	48 c1 ea 10          	shr    $0x10,%rdx
    8591:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8595:	48 8b 15 3c a6 01 00 	mov    0x1a63c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    859c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    85a0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    85a4:	48 85 d2             	test   %rdx,%rdx
    85a7:	0f 84 86 fd ff ff    	je     8333 <f12+0x473>
    85ad:	0f b6 31             	movzbl (%rcx),%esi
    85b0:	45 31 ed             	xor    %r13d,%r13d
    85b3:	40 80 fe 02          	cmp    $0x2,%sil
    85b7:	0f 85 ee fc ff ff    	jne    82ab <f12+0x3eb>
    85bd:	66 85 c0             	test   %ax,%ax
    85c0:	0f 85 10 fd ff ff    	jne    82d6 <f12+0x416>
    85c6:	e9 ff fc ff ff       	jmp    82ca <f12+0x40a>
    85cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    85d0:	4d 85 ed             	test   %r13,%r13
    85d3:	0f 85 02 fd ff ff    	jne    82db <f12+0x41b>
    85d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    85e0:	31 ed                	xor    %ebp,%ebp
    85e2:	e9 b7 fd ff ff       	jmp    839e <f12+0x4de>
    85e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    85ee:	00 00 
    85f0:	4c 39 e3             	cmp    %r12,%rbx
    85f3:	0f 84 47 fa ff ff    	je     8040 <f12+0x180>
    85f9:	48 8b 2d 10 8b 01 00 	mov    0x18b10(%rip),%rbp        # 21110 <fwp_tapes>
    8600:	e9 da fa ff ff       	jmp    80df <f12+0x21f>
    8605:	0f 1f 00             	nopl   (%rax)
    8608:	49 8d 5a 01          	lea    0x1(%r10),%rbx
    860c:	48 39 da             	cmp    %rbx,%rdx
    860f:	0f 8d 4b 0c 00 00    	jge    9260 <f12+0x13a0>
    8615:	48 85 d2             	test   %rdx,%rdx
    8618:	48 0f 44 d3          	cmove  %rbx,%rdx
    861c:	eb 17                	jmp    8635 <f12+0x775>
    861e:	66 90                	xchg   %ax,%ax
    8620:	48 8d 34 12          	lea    (%rdx,%rdx,1),%rsi
    8624:	48 81 fa 00 00 00 40 	cmp    $0x40000000,%rdx
    862b:	48 89 d8             	mov    %rbx,%rax
    862e:	48 0f 4c c6          	cmovl  %rsi,%rax
    8632:	48 89 c2             	mov    %rax,%rdx
    8635:	48 39 d3             	cmp    %rdx,%rbx
    8638:	7f e6                	jg     8620 <f12+0x760>
    863a:	4d 85 f6             	test   %r14,%r14
    863d:	0f 84 ad 0c 00 00    	je     92f0 <f12+0x1430>
    8643:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
    864a:	00 
    864b:	4c 89 f7             	mov    %r14,%rdi
    864e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    8653:	e8 78 af ff ff       	call   35d0 <realloc@plt>
    8658:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    865d:	49 89 c6             	mov    %rax,%r14
    8660:	4d 85 f6             	test   %r14,%r14
    8663:	0f 84 f3 0a 00 00    	je     915c <f12+0x129c>
    8669:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    8670:	00 
    8671:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
    8678:	00 
    8679:	48 85 db             	test   %rbx,%rbx
    867c:	0f 85 31 0d 00 00    	jne    93b3 <f12+0x14f3>
    8682:	49 89 eb             	mov    %rbp,%r11
    8685:	49 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%r9
    868c:	49 f7 db             	neg    %r11
    868f:	4d 85 ed             	test   %r13,%r13
    8692:	78 17                	js     86ab <f12+0x7eb>
    8694:	45 89 ea             	mov    %r13d,%r10d
    8697:	f2 0f 10 05 81 55 00 	movsd  0x5581(%rip),%xmm0        # dc20 <msg.4+0xb0>
    869e:	00 
    869f:	f2 43 0f 58 04 d6    	addsd  (%r14,%r10,8),%xmm0
    86a5:	f2 43 0f 11 04 d6    	movsd  %xmm0,(%r14,%r10,8)
    86ab:	bf 03 00 00 00       	mov    $0x3,%edi
    86b0:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
    86b5:	48 01 2d 64 8a 01 00 	add    %rbp,0x18a64(%rip)        # 21120 <descent_inputs>
    86bc:	4c 01 1d 65 8a 01 00 	add    %r11,0x18a65(%rip)        # 21128 <descent_nodes>
    86c3:	e8 88 bb ff ff       	call   4250 <descent_phase_step>
    86c8:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
    86cd:	49 39 e9             	cmp    %rbp,%r9
    86d0:	0f 8c 8c 00 00 00    	jl     8762 <f12+0x8a2>
    86d6:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    86db:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    86e0:	49 29 e9             	sub    %rbp,%r9
    86e3:	66 0f ef d2          	pxor   %xmm2,%xmm2
    86e7:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    86ec:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    86f1:	4b 8d 14 cb          	lea    (%r11,%r9,8),%rdx
    86f5:	4a 8d 04 8f          	lea    (%rdi,%r9,4),%rax
    86f9:	4d 8d 0c ee          	lea    (%r14,%rbp,8),%r9
    86fd:	48 29 fe             	sub    %rdi,%rsi
    8700:	4d 29 da             	sub    %r11,%r10
    8703:	4d 29 d9             	sub    %r11,%r9
    8706:	eb 0c                	jmp    8714 <f12+0x854>
    8708:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    870f:	00 
    8710:	48 83 e8 04          	sub    $0x4,%rax
    8714:	f2 41 0f 10 04 11    	movsd  (%r9,%rdx,1),%xmm0
    871a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    871e:	7a 02                	jp     8722 <f12+0x862>
    8720:	74 37                	je     8759 <f12+0x899>
    8722:	4c 63 1c 06          	movslq (%rsi,%rax,1),%r11
    8726:	45 85 db             	test   %r11d,%r11d
    8729:	78 16                	js     8741 <f12+0x881>
    872b:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8731:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8735:	f2 43 0f 58 0c de    	addsd  (%r14,%r11,8),%xmm1
    873b:	f2 43 0f 11 0c de    	movsd  %xmm1,(%r14,%r11,8)
    8741:	4c 63 18             	movslq (%rax),%r11
    8744:	45 85 db             	test   %r11d,%r11d
    8747:	78 10                	js     8759 <f12+0x899>
    8749:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    874d:	f2 43 0f 58 04 de    	addsd  (%r14,%r11,8),%xmm0
    8753:	f2 43 0f 11 04 de    	movsd  %xmm0,(%r14,%r11,8)
    8759:	48 83 ea 08          	sub    $0x8,%rdx
    875d:	48 39 c7             	cmp    %rax,%rdi
    8760:	75 ae                	jne    8710 <f12+0x850>
    8762:	bf 04 00 00 00       	mov    $0x4,%edi
    8767:	e8 e4 ba ff ff       	call   4250 <descent_phase_step>
    876c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8773:	ff ff 1f 
    8776:	48 39 e8             	cmp    %rbp,%rax
    8779:	0f 82 2c 0d 00 00    	jb     94ab <f12+0x15eb>
    877f:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8786:	00 
    8787:	be 02 00 00 00       	mov    $0x2,%esi
    878c:	e8 ff d4 ff ff       	call   5c90 <fwp_heap_alloc>
    8791:	48 89 28             	mov    %rbp,(%rax)
    8794:	48 89 c3             	mov    %rax,%rbx
    8797:	31 c0                	xor    %eax,%eax
    8799:	48 85 ed             	test   %rbp,%rbp
    879c:	74 14                	je     87b2 <f12+0x8f2>
    879e:	66 90                	xchg   %ax,%ax
    87a0:	49 8b 14 c6          	mov    (%r14,%rax,8),%rdx
    87a4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    87a9:	48 83 c0 01          	add    $0x1,%rax
    87ad:	48 39 c5             	cmp    %rax,%rbp
    87b0:	75 ee                	jne    87a0 <f12+0x8e0>
    87b2:	bf 05 00 00 00       	mov    $0x5,%edi
    87b7:	e8 94 ba ff ff       	call   4250 <descent_phase_step>
    87bc:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    87c3:	00 
    87c4:	4c 89 e7             	mov    %r12,%rdi
    87c7:	4c 89 2d aa ac 01 00 	mov    %r13,0x1acaa(%rip)        # 23478 <fwp_cleanups>
    87ce:	e8 9d c8 ff ff       	call   5070 <fwp_tape_buffers_release>
    87d3:	bf 06 00 00 00       	mov    $0x6,%edi
    87d8:	e8 73 ba ff ff       	call   4250 <descent_phase_step>
    87dd:	48 8b 15 d4 a3 01 00 	mov    0x1a3d4(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    87e4:	48 89 d8             	mov    %rbx,%rax
    87e7:	48 2b 05 a2 a3 01 00 	sub    0x1a3a2(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    87ee:	48 c1 e2 10          	shl    $0x10,%rdx
    87f2:	48 39 d0             	cmp    %rdx,%rax
    87f5:	73 59                	jae    8850 <f12+0x990>
    87f7:	48 89 c2             	mov    %rax,%rdx
    87fa:	48 c1 ea 10          	shr    $0x10,%rdx
    87fe:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8802:	48 8b 15 cf a3 01 00 	mov    0x1a3cf(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    8809:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    880d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    8811:	4d 85 e4             	test   %r12,%r12
    8814:	74 3a                	je     8850 <f12+0x990>
    8816:	0f b6 0a             	movzbl (%rdx),%ecx
    8819:	80 f9 02             	cmp    $0x2,%cl
    881c:	0f 84 96 09 00 00    	je     91b8 <f12+0x12f8>
    8822:	80 f9 01             	cmp    $0x1,%cl
    8825:	75 29                	jne    8850 <f12+0x990>
    8827:	8b 4a 18             	mov    0x18(%rdx),%ecx
    882a:	0f b7 c0             	movzwl %ax,%eax
    882d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8830:	48 0f af c1          	imul   %rcx,%rax
    8834:	48 c1 e8 20          	shr    $0x20,%rax
    8838:	48 39 d0             	cmp    %rdx,%rax
    883b:	73 13                	jae    8850 <f12+0x990>
    883d:	49 01 c4             	add    %rax,%r12
    8840:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    8845:	0f 84 44 0b 00 00    	je     938f <f12+0x14cf>
    884b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    8850:	4d 39 fd             	cmp    %r15,%r13
    8853:	0f 85 f2 ae ff ff    	jne    374b <f12.cold>
    8859:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    885e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8863:	48 89 05 0e ac 01 00 	mov    %rax,0x1ac0e(%rip)        # 23478 <fwp_cleanups>
    886a:	e8 91 e7 ff ff       	call   7000 <fwp_tape_scope_release>
    886f:	48 8b 03             	mov    (%rbx),%rax
    8872:	49 89 c4             	mov    %rax,%r12
    8875:	49 0f ba f4 3f       	btr    $0x3f,%r12
    887a:	48 85 c0             	test   %rax,%rax
    887d:	0f 88 bd 07 00 00    	js     9040 <f12+0x1180>
    8883:	48 8b 15 2e a3 01 00 	mov    0x1a32e(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    888a:	48 89 d8             	mov    %rbx,%rax
    888d:	48 2b 05 fc a2 01 00 	sub    0x1a2fc(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8894:	48 c1 e2 10          	shl    $0x10,%rdx
    8898:	48 39 d0             	cmp    %rdx,%rax
    889b:	0f 83 9f 07 00 00    	jae    9040 <f12+0x1180>
    88a1:	48 89 c2             	mov    %rax,%rdx
    88a4:	48 c1 ea 10          	shr    $0x10,%rdx
    88a8:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    88ac:	48 8b 15 25 a3 01 00 	mov    0x1a325(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    88b3:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    88b7:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    88bb:	48 85 c9             	test   %rcx,%rcx
    88be:	0f 84 7c 07 00 00    	je     9040 <f12+0x1180>
    88c4:	0f b6 32             	movzbl (%rdx),%esi
    88c7:	40 80 fe 02          	cmp    $0x2,%sil
    88cb:	0f 84 5f 07 00 00    	je     9030 <f12+0x1170>
    88d1:	40 80 fe 01          	cmp    $0x1,%sil
    88d5:	0f 85 65 07 00 00    	jne    9040 <f12+0x1180>
    88db:	8b 72 18             	mov    0x18(%rdx),%esi
    88de:	0f b7 c0             	movzwl %ax,%eax
    88e1:	8b 52 1c             	mov    0x1c(%rdx),%edx
    88e4:	48 0f af c6          	imul   %rsi,%rax
    88e8:	48 c1 e8 20          	shr    $0x20,%rax
    88ec:	48 39 d0             	cmp    %rdx,%rax
    88ef:	0f 83 4b 07 00 00    	jae    9040 <f12+0x1180>
    88f5:	48 01 c1             	add    %rax,%rcx
    88f8:	80 39 01             	cmpb   $0x1,(%rcx)
    88fb:	0f 85 3f 07 00 00    	jne    9040 <f12+0x1180>
    8901:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
    8906:	49 89 dd             	mov    %rbx,%r13
    8909:	31 ff                	xor    %edi,%edi
    890b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8910:	f2 0f 10 0d 20 53 00 	movsd  0x5320(%rip),%xmm1        # dc38 <msg.4+0xc8>
    8917:	00 
    8918:	48 8d 50 08          	lea    0x8(%rax),%rdx
    891c:	31 c0                	xor    %eax,%eax
    891e:	4d 85 e4             	test   %r12,%r12
    8921:	75 2b                	jne    894e <f12+0xa8e>
    8923:	eb 3b                	jmp    8960 <f12+0xaa0>
    8925:	0f 1f 00             	nopl   (%rax)
    8928:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    892d:	0f 88 5f 0b 00 00    	js     9492 <f12+0x15d2>
    8933:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8938:	48 83 c0 01          	add    $0x1,%rax
    893c:	48 83 c2 08          	add    $0x8,%rdx
    8940:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8944:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8949:	49 39 c4             	cmp    %rax,%r12
    894c:	74 12                	je     8960 <f12+0xaa0>
    894e:	48 8d 4b 08          	lea    0x8(%rbx),%rcx
    8952:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8956:	79 d0                	jns    8928 <f12+0xa68>
    8958:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
    895c:	eb ca                	jmp    8928 <f12+0xa68>
    895e:	66 90                	xchg   %ax,%ax
    8960:	e8 4b f0 ff ff       	call   79b0 <fwp_drop4>
    8965:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    896a:	31 d2                	xor    %edx,%edx
    896c:	48 89 c8             	mov    %rcx,%rax
    896f:	48 85 c9             	test   %rcx,%rcx
    8972:	0f 84 a7 09 00 00    	je     931f <f12+0x145f>
    8978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    897f:	00 
    8980:	48 8b 40 10          	mov    0x10(%rax),%rax
    8984:	48 83 c2 01          	add    $0x1,%rdx
    8988:	48 85 c0             	test   %rax,%rax
    898b:	75 f3                	jne    8980 <f12+0xac0>
    898d:	49 8b 45 00          	mov    0x0(%r13),%rax
    8991:	49 89 c7             	mov    %rax,%r15
    8994:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8999:	48 85 c0             	test   %rax,%rax
    899c:	0f 88 f3 05 00 00    	js     8f95 <f12+0x10d5>
    89a2:	48 8b 0d 0f a2 01 00 	mov    0x1a20f(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    89a9:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    89ae:	48 2b 05 db a1 01 00 	sub    0x1a1db(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    89b5:	48 c1 e1 10          	shl    $0x10,%rcx
    89b9:	48 39 c8             	cmp    %rcx,%rax
    89bc:	0f 83 d3 05 00 00    	jae    8f95 <f12+0x10d5>
    89c2:	48 89 c1             	mov    %rax,%rcx
    89c5:	48 c1 e9 10          	shr    $0x10,%rcx
    89c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    89cd:	48 8b 0d 04 a2 01 00 	mov    0x1a204(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    89d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    89d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    89dc:	48 85 ff             	test   %rdi,%rdi
    89df:	0f 84 b0 05 00 00    	je     8f95 <f12+0x10d5>
    89e5:	0f b6 0e             	movzbl (%rsi),%ecx
    89e8:	80 f9 02             	cmp    $0x2,%cl
    89eb:	0f 84 8f 05 00 00    	je     8f80 <f12+0x10c0>
    89f1:	80 f9 01             	cmp    $0x1,%cl
    89f4:	0f 85 8f 05 00 00    	jne    8f89 <f12+0x10c9>
    89fa:	8b 4e 18             	mov    0x18(%rsi),%ecx
    89fd:	0f b7 c0             	movzwl %ax,%eax
    8a00:	48 0f af c1          	imul   %rcx,%rax
    8a04:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    8a07:	48 c1 e8 20          	shr    $0x20,%rax
    8a0b:	48 39 c8             	cmp    %rcx,%rax
    8a0e:	0f 83 75 05 00 00    	jae    8f89 <f12+0x10c9>
    8a14:	48 01 c7             	add    %rax,%rdi
    8a17:	80 3f 01             	cmpb   $0x1,(%rdi)
    8a1a:	0f 85 69 05 00 00    	jne    8f89 <f12+0x10c9>
    8a20:	4c 39 fa             	cmp    %r15,%rdx
    8a23:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8a27:	4c 89 fd             	mov    %r15,%rbp
    8a2a:	4d 85 ff             	test   %r15,%r15
    8a2d:	0f 84 70 0a 00 00    	je     94a3 <f12+0x15e3>
    8a33:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8a3a:	00 
    8a3b:	4d 8d 65 08          	lea    0x8(%r13),%r12
    8a3f:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8a44:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8a49:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    8a50:	00 
    8a51:	31 c0                	xor    %eax,%eax
    8a53:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8a57:	eb 44                	jmp    8a9d <f12+0xbdd>
    8a59:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8a5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a66:	00 00 00 00 
    8a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a71:	00 00 00 00 
    8a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a7c:	00 00 00 00 
    8a80:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8a85:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    8a8a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8a90:	48 83 c0 08          	add    $0x8,%rax
    8a94:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8a98:	49 39 c0             	cmp    %rax,%r8
    8a9b:	74 1b                	je     8ab8 <f12+0xbf8>
    8a9d:	48 89 fe             	mov    %rdi,%rsi
    8aa0:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
    8aa5:	79 d9                	jns    8a80 <f12+0xbc0>
    8aa7:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8aac:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8ab0:	eb ce                	jmp    8a80 <f12+0xbc0>
    8ab2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8ab8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8abd:	48 85 d2             	test   %rdx,%rdx
    8ac0:	0f 84 a7 09 00 00    	je     946d <f12+0x15ad>
    8ac6:	4c 8b 05 eb a0 01 00 	mov    0x1a0eb(%rip),%r8        # 22bb8 <fwp_heap+0x13d8>
    8acd:	4c 8b 15 bc a0 01 00 	mov    0x1a0bc(%rip),%r10        # 22b90 <fwp_heap+0x13b0>
    8ad4:	45 31 ff             	xor    %r15d,%r15d
    8ad7:	4c 8b 1d fa a0 01 00 	mov    0x1a0fa(%rip),%r11        # 22bd8 <fwp_heap+0x13f8>
    8ade:	49 c1 e0 10          	shl    $0x10,%r8
    8ae2:	eb 1a                	jmp    8afe <f12+0xc3e>
    8ae4:	0f 1f 40 00          	nopl   0x0(%rax)
    8ae8:	49 83 c7 01          	add    $0x1,%r15
    8aec:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8af0:	49 39 ef             	cmp    %rbp,%r15
    8af3:	0f 83 37 02 00 00    	jae    8d30 <f12+0xe70>
    8af9:	48 85 d2             	test   %rdx,%rdx
    8afc:	74 52                	je     8b50 <f12+0xc90>
    8afe:	48 89 d0             	mov    %rdx,%rax
    8b01:	4c 29 d0             	sub    %r10,%rax
    8b04:	4c 39 c0             	cmp    %r8,%rax
    8b07:	73 47                	jae    8b50 <f12+0xc90>
    8b09:	48 89 c6             	mov    %rax,%rsi
    8b0c:	48 c1 ee 10          	shr    $0x10,%rsi
    8b10:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8b14:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8b18:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8b1c:	48 85 ff             	test   %rdi,%rdi
    8b1f:	74 2f                	je     8b50 <f12+0xc90>
    8b21:	0f b6 1e             	movzbl (%rsi),%ebx
    8b24:	80 fb 02             	cmp    $0x2,%bl
    8b27:	0f 84 e3 01 00 00    	je     8d10 <f12+0xe50>
    8b2d:	80 fb 01             	cmp    $0x1,%bl
    8b30:	75 1e                	jne    8b50 <f12+0xc90>
    8b32:	8b 5e 18             	mov    0x18(%rsi),%ebx
    8b35:	0f b7 c0             	movzwl %ax,%eax
    8b38:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8b3b:	48 0f af c3          	imul   %rbx,%rax
    8b3f:	48 c1 e8 20          	shr    $0x20,%rax
    8b43:	48 39 f0             	cmp    %rsi,%rax
    8b46:	73 08                	jae    8b50 <f12+0xc90>
    8b48:	48 01 c7             	add    %rax,%rdi
    8b4b:	80 3f 01             	cmpb   $0x1,(%rdi)
    8b4e:	74 98                	je     8ae8 <f12+0xc28>
    8b50:	49 39 ef             	cmp    %rbp,%r15
    8b53:	0f 83 d7 01 00 00    	jae    8d30 <f12+0xe70>
    8b59:	4c 8b 2d 80 50 00 00 	mov    0x5080(%rip),%r13        # dbe0 <msg.4+0x70>
    8b60:	45 31 f6             	xor    %r14d,%r14d
    8b63:	48 8d 1d 76 8c 01 00 	lea    0x18c76(%rip),%rbx        # 217e0 <fwp_heap>
    8b6a:	e9 19 01 00 00       	jmp    8c88 <f12+0xdc8>
    8b6f:	90                   	nop
    8b70:	49 8b 10             	mov    (%r8),%rdx
    8b73:	48 f7 d2             	not    %rdx
    8b76:	48 89 10             	mov    %rdx,(%rax)
    8b79:	49 83 fb 18          	cmp    $0x18,%r11
    8b7d:	76 3b                	jbe    8bba <f12+0xcfa>
    8b7f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8b83:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8b87:	31 f6                	xor    %esi,%esi
    8b89:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    8b8e:	48 c1 e8 03          	shr    $0x3,%rax
    8b92:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8b97:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8b9e:	00 
    8b9f:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    8ba5:	e8 16 a9 ff ff       	call   34c0 <memset@plt>
    8baa:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8baf:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    8bb4:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    8bba:	4c 89 d8             	mov    %r11,%rax
    8bbd:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8bc4:	0f 82 c3 08 00 00    	jb     948d <f12+0x15cd>
    8bca:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8bd1:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8bd8:	73 07                	jae    8be1 <f12+0xd21>
    8bda:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8be1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8be5:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8bea:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8bf1:	00 
    8bf2:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8bf9:	00 
    8bfa:	66 49 0f 6e ee       	movq   %r14,%xmm5
    8bff:	4d 89 28             	mov    %r13,(%r8)
    8c02:	4c 89 c0             	mov    %r8,%rax
    8c05:	4d 89 c6             	mov    %r8,%r14
    8c08:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8c0c:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8c11:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8c18:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8c1f:	48 c1 e2 10          	shl    $0x10,%rdx
    8c23:	48 39 d0             	cmp    %rdx,%rax
    8c26:	73 57                	jae    8c7f <f12+0xdbf>
    8c28:	48 89 c2             	mov    %rax,%rdx
    8c2b:	48 c1 ea 10          	shr    $0x10,%rdx
    8c2f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8c33:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8c3a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8c3e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8c42:	48 85 d2             	test   %rdx,%rdx
    8c45:	74 38                	je     8c7f <f12+0xdbf>
    8c47:	0f b6 3e             	movzbl (%rsi),%edi
    8c4a:	40 80 ff 02          	cmp    $0x2,%dil
    8c4e:	0f 84 7c 01 00 00    	je     8dd0 <f12+0xf10>
    8c54:	40 80 ff 01          	cmp    $0x1,%dil
    8c58:	75 25                	jne    8c7f <f12+0xdbf>
    8c5a:	8b 7e 18             	mov    0x18(%rsi),%edi
    8c5d:	0f b7 c0             	movzwl %ax,%eax
    8c60:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8c63:	48 0f af c7          	imul   %rdi,%rax
    8c67:	48 c1 e8 20          	shr    $0x20,%rax
    8c6b:	48 39 f0             	cmp    %rsi,%rax
    8c6e:	73 0f                	jae    8c7f <f12+0xdbf>
    8c70:	48 01 c2             	add    %rax,%rdx
    8c73:	80 3a ff             	cmpb   $0xff,(%rdx)
    8c76:	0f 84 74 04 00 00    	je     90f0 <f12+0x1230>
    8c7c:	c6 02 01             	movb   $0x1,(%rdx)
    8c7f:	49 39 ef             	cmp    %rbp,%r15
    8c82:	0f 83 68 01 00 00    	jae    8df0 <f12+0xf30>
    8c88:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8c8e:	48 83 ed 01          	sub    $0x1,%rbp
    8c92:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8c98:	85 f6                	test   %esi,%esi
    8c9a:	74 4c                	je     8ce8 <f12+0xe28>
    8c9c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8ca3:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8caa:	00 
    8cab:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8caf:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8cb3:	4c 8b 00             	mov    (%rax),%r8
    8cb6:	4d 85 c0             	test   %r8,%r8
    8cb9:	0f 85 b1 fe ff ff    	jne    8b70 <f12+0xcb0>
    8cbf:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8cc3:	4d 85 c0             	test   %r8,%r8
    8cc6:	74 20                	je     8ce8 <f12+0xe28>
    8cc8:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8ccc:	4c 29 c2             	sub    %r8,%rdx
    8ccf:	4c 39 da             	cmp    %r11,%rdx
    8cd2:	72 14                	jb     8ce8 <f12+0xe28>
    8cd4:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8cd8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8cdc:	e9 98 fe ff ff       	jmp    8b79 <f12+0xcb9>
    8ce1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ce8:	31 f6                	xor    %esi,%esi
    8cea:	bf 18 00 00 00       	mov    $0x18,%edi
    8cef:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8cf5:	e8 96 cf ff ff       	call   5c90 <fwp_heap_alloc>
    8cfa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8d00:	49 89 c0             	mov    %rax,%r8
    8d03:	e9 f2 fe ff ff       	jmp    8bfa <f12+0xd3a>
    8d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8d0f:	00 
    8d10:	66 85 c0             	test   %ax,%ax
    8d13:	0f 84 32 fe ff ff    	je     8b4b <f12+0xc8b>
    8d19:	49 39 ef             	cmp    %rbp,%r15
    8d1c:	0f 82 37 fe ff ff    	jb     8b59 <f12+0xc99>
    8d22:	0f 1f 00             	nopl   (%rax)
    8d25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d2c:	00 00 00 00 
    8d30:	45 31 f6             	xor    %r14d,%r14d
    8d33:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8d38:	4c 89 e2             	mov    %r12,%rdx
    8d3b:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    8d3f:	90                   	nop
    8d40:	48 8b 0a             	mov    (%rdx),%rcx
    8d43:	48 83 c2 08          	add    $0x8,%rdx
    8d47:	48 89 c6             	mov    %rax,%rsi
    8d4a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8d4e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8d52:	48 39 d7             	cmp    %rdx,%rdi
    8d55:	75 e9                	jne    8d40 <f12+0xe80>
    8d57:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
    8d5b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    8d5f:	85 c9                	test   %ecx,%ecx
    8d61:	0f 84 69 04 00 00    	je     91d0 <f12+0x1310>
    8d67:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8d6c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8d71:	45 31 e4             	xor    %r12d,%r12d
    8d74:	90                   	nop
    8d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d7c:	00 00 00 00 
    8d80:	4c 89 e7             	mov    %r12,%rdi
    8d83:	e8 08 ca ff ff       	call   5790 <fwp_mem_free>
    8d88:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8d8d:	e8 1e ec ff ff       	call   79b0 <fwp_drop4>
    8d92:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8d97:	e8 54 dc ff ff       	call   69f0 <fwp_drop0>
    8d9c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    8da3:	00 
    8da4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8dab:	00 00 
    8dad:	0f 85 40 07 00 00    	jne    94f3 <f12+0x1633>
    8db3:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    8dba:	4c 89 f0             	mov    %r14,%rax
    8dbd:	5b                   	pop    %rbx
    8dbe:	5d                   	pop    %rbp
    8dbf:	41 5c                	pop    %r12
    8dc1:	41 5d                	pop    %r13
    8dc3:	41 5e                	pop    %r14
    8dc5:	41 5f                	pop    %r15
    8dc7:	c3                   	ret
    8dc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8dcf:	00 
    8dd0:	66 85 c0             	test   %ax,%ax
    8dd3:	0f 84 9a fe ff ff    	je     8c73 <f12+0xdb3>
    8dd9:	49 39 ef             	cmp    %rbp,%r15
    8ddc:	0f 82 a6 fe ff ff    	jb     8c88 <f12+0xdc8>
    8de2:	0f 1f 00             	nopl   (%rax)
    8de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8dec:	00 00 00 00 
    8df0:	4d 85 ff             	test   %r15,%r15
    8df3:	0f 85 3a ff ff ff    	jne    8d33 <f12+0xe73>
    8df9:	8b 54 24 40          	mov    0x40(%rsp),%edx
    8dfd:	85 d2                	test   %edx,%edx
    8dff:	4d 0f 45 e7          	cmovne %r15,%r12
    8e03:	66 90                	xchg   %ax,%ax
    8e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8e0c:	00 00 00 00 
    8e10:	48 85 ed             	test   %rbp,%rbp
    8e13:	0f 84 67 ff ff ff    	je     8d80 <f12+0xec0>
    8e19:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8e1f:	48 83 ed 01          	sub    $0x1,%rbp
    8e23:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8e29:	85 c0                	test   %eax,%eax
    8e2b:	0f 84 e7 05 00 00    	je     9418 <f12+0x1558>
    8e31:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8e38:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8e3f:	00 
    8e40:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8e44:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8e48:	4c 8b 38             	mov    (%rax),%r15
    8e4b:	4d 85 ff             	test   %r15,%r15
    8e4e:	0f 84 9c 05 00 00    	je     93f0 <f12+0x1530>
    8e54:	49 8b 17             	mov    (%r15),%rdx
    8e57:	48 f7 d2             	not    %rdx
    8e5a:	48 89 10             	mov    %rdx,(%rax)
    8e5d:	49 83 f8 18          	cmp    $0x18,%r8
    8e61:	76 31                	jbe    8e94 <f12+0xfd4>
    8e63:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8e67:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8e6b:	31 f6                	xor    %esi,%esi
    8e6d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8e72:	48 c1 e8 03          	shr    $0x3,%rax
    8e76:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    8e7c:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8e83:	00 
    8e84:	e8 37 a6 ff ff       	call   34c0 <memset@plt>
    8e89:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8e8e:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    8e94:	4c 89 c0             	mov    %r8,%rax
    8e97:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8e9e:	0f 82 e9 05 00 00    	jb     948d <f12+0x15cd>
    8ea4:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8eab:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8eb2:	73 07                	jae    8ebb <f12+0xffb>
    8eb4:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8ebb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8ebf:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8ec4:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8ecb:	00 
    8ecc:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8ed3:	00 
    8ed4:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8ed9:	4d 89 2f             	mov    %r13,(%r15)
    8edc:	4c 89 f8             	mov    %r15,%rax
    8edf:	4d 89 fe             	mov    %r15,%r14
    8ee2:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8ee6:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8eeb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8ef2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8ef9:	48 c1 e2 10          	shl    $0x10,%rdx
    8efd:	48 39 d0             	cmp    %rdx,%rax
    8f00:	0f 83 0a ff ff ff    	jae    8e10 <f12+0xf50>
    8f06:	48 89 c2             	mov    %rax,%rdx
    8f09:	48 c1 ea 10          	shr    $0x10,%rdx
    8f0d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8f11:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8f18:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8f1c:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8f20:	4d 85 ff             	test   %r15,%r15
    8f23:	0f 84 e7 fe ff ff    	je     8e10 <f12+0xf50>
    8f29:	0f b6 32             	movzbl (%rdx),%esi
    8f2c:	40 80 fe 02          	cmp    $0x2,%sil
    8f30:	0f 84 0a 05 00 00    	je     9440 <f12+0x1580>
    8f36:	40 80 fe 01          	cmp    $0x1,%sil
    8f3a:	0f 85 d0 fe ff ff    	jne    8e10 <f12+0xf50>
    8f40:	8b 72 18             	mov    0x18(%rdx),%esi
    8f43:	0f b7 c0             	movzwl %ax,%eax
    8f46:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f49:	48 0f af c6          	imul   %rsi,%rax
    8f4d:	48 c1 e8 20          	shr    $0x20,%rax
    8f51:	48 39 d0             	cmp    %rdx,%rax
    8f54:	0f 83 b6 fe ff ff    	jae    8e10 <f12+0xf50>
    8f5a:	49 01 c7             	add    %rax,%r15
    8f5d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f61:	0f 84 f9 04 00 00    	je     9460 <f12+0x15a0>
    8f67:	41 c6 07 01          	movb   $0x1,(%r15)
    8f6b:	48 85 ed             	test   %rbp,%rbp
    8f6e:	0f 85 a5 fe ff ff    	jne    8e19 <f12+0xf59>
    8f74:	e9 07 fe ff ff       	jmp    8d80 <f12+0xec0>
    8f79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f80:	66 85 c0             	test   %ax,%ax
    8f83:	0f 84 8e fa ff ff    	je     8a17 <f12+0xb57>
    8f89:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    8f8f:	0f 84 23 03 00 00    	je     92b8 <f12+0x13f8>
    8f95:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8f9a:	31 ed                	xor    %ebp,%ebp
    8f9c:	0f 1f 40 00          	nopl   0x0(%rax)
    8fa0:	48 8b 40 10          	mov    0x10(%rax),%rax
    8fa4:	48 89 ea             	mov    %rbp,%rdx
    8fa7:	48 83 c5 01          	add    $0x1,%rbp
    8fab:	48 85 c0             	test   %rax,%rax
    8fae:	75 f0                	jne    8fa0 <f12+0x10e0>
    8fb0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8fb7:	ff ff 1f 
    8fba:	48 39 e8             	cmp    %rbp,%rax
    8fbd:	0f 82 00 05 00 00    	jb     94c3 <f12+0x1603>
    8fc3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8fca:	00 
    8fcb:	be 02 00 00 00       	mov    $0x2,%esi
    8fd0:	e8 bb cc ff ff       	call   5c90 <fwp_heap_alloc>
    8fd5:	49 39 ef             	cmp    %rbp,%r15
    8fd8:	49 89 c4             	mov    %rax,%r12
    8fdb:	48 89 c2             	mov    %rax,%rdx
    8fde:	49 0f 46 ef          	cmovbe %r15,%rbp
    8fe2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8fe7:	0f 1f 00             	nopl   (%rax)
    8fea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ff1:	00 00 00 00 
    8ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ffc:	00 00 00 00 
    9000:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9004:	48 83 c2 08          	add    $0x8,%rdx
    9008:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    900c:	48 8b 40 10          	mov    0x10(%rax),%rax
    9010:	48 85 c0             	test   %rax,%rax
    9013:	75 eb                	jne    9000 <f12+0x1140>
    9015:	48 85 ed             	test   %rbp,%rbp
    9018:	0f 84 ac 02 00 00    	je     92ca <f12+0x140a>
    901e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    9025:	00 
    9026:	e9 14 fa ff ff       	jmp    8a3f <f12+0xb7f>
    902b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9030:	66 85 c0             	test   %ax,%ax
    9033:	0f 84 bf f8 ff ff    	je     88f8 <f12+0xa38>
    9039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9040:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9047:	ff ff 1f 
    904a:	4c 39 e0             	cmp    %r12,%rax
    904d:	0f 82 58 04 00 00    	jb     94ab <f12+0x15eb>
    9053:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    905a:	00 
    905b:	be 01 00 00 00       	mov    $0x1,%esi
    9060:	e8 2b cc ff ff       	call   5c90 <fwp_heap_alloc>
    9065:	4c 89 20             	mov    %r12,(%rax)
    9068:	48 8b 15 49 9b 01 00 	mov    0x19b49(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    906f:	49 89 c5             	mov    %rax,%r13
    9072:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9077:	48 2b 05 12 9b 01 00 	sub    0x19b12(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    907e:	48 c1 e2 10          	shl    $0x10,%rdx
    9082:	48 39 d0             	cmp    %rdx,%rax
    9085:	73 57                	jae    90de <f12+0x121e>
    9087:	48 89 c2             	mov    %rax,%rdx
    908a:	48 c1 ea 10          	shr    $0x10,%rdx
    908e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9092:	48 8b 15 3f 9b 01 00 	mov    0x19b3f(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9099:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    909d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    90a1:	4d 85 ff             	test   %r15,%r15
    90a4:	74 38                	je     90de <f12+0x121e>
    90a6:	0f b6 0a             	movzbl (%rdx),%ecx
    90a9:	80 f9 02             	cmp    $0x2,%cl
    90ac:	0f 84 26 02 00 00    	je     92d8 <f12+0x1418>
    90b2:	80 f9 01             	cmp    $0x1,%cl
    90b5:	75 27                	jne    90de <f12+0x121e>
    90b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    90ba:	0f b7 c0             	movzwl %ax,%eax
    90bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    90c0:	48 0f af c1          	imul   %rcx,%rax
    90c4:	48 c1 e8 20          	shr    $0x20,%rax
    90c8:	48 39 d0             	cmp    %rdx,%rax
    90cb:	73 11                	jae    90de <f12+0x121e>
    90cd:	49 01 c7             	add    %rax,%r15
    90d0:	41 80 3f ff          	cmpb   $0xff,(%r15)
    90d4:	0f 84 c2 02 00 00    	je     939c <f12+0x14dc>
    90da:	41 c6 07 01          	movb   $0x1,(%r15)
    90de:	48 89 df             	mov    %rbx,%rdi
    90e1:	e9 25 f8 ff ff       	jmp    890b <f12+0xa4b>
    90e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    90ed:	00 00 00 
    90f0:	48 89 d7             	mov    %rdx,%rdi
    90f3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    90f8:	e8 53 c4 ff ff       	call   5550 <fwp_rc_forget_slot>
    90fd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9102:	e9 75 fb ff ff       	jmp    8c7c <f12+0xdbc>
    9107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    910e:	00 00 
    9110:	48 8d 3d 09 de ff ff 	lea    -0x21f7(%rip),%rdi        # 6f20 <fwp_tape_finish>
    9117:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    911d:	e8 de 37 00 00       	call   c900 <atexit>
    9122:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9128:	85 c0                	test   %eax,%eax
    912a:	75 59                	jne    9185 <f12+0x12c5>
    912c:	c7 05 4a 7f 00 00 01 	movl   $0x1,0x7f4a(%rip)        # 11080 <registered_finish.0>
    9133:	00 00 00 
    9136:	e9 bb ee ff ff       	jmp    7ff6 <f12+0x136>
    913b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9140:	66 85 c0             	test   %ax,%ax
    9143:	0f 85 56 ee ff ff    	jne    7f9f <f12+0xdf>
    9149:	e9 3d ee ff ff       	jmp    7f8b <f12+0xcb>
    914e:	66 90                	xchg   %ax,%ax
    9150:	48 89 eb             	mov    %rbp,%rbx
    9153:	48 39 d5             	cmp    %rdx,%rbp
    9156:	0f 8f b9 f4 ff ff    	jg     8615 <f12+0x755>
    915c:	48 85 db             	test   %rbx,%rbx
    915f:	0f 84 1d f5 ff ff    	je     8682 <f12+0x7c2>
    9165:	4d 85 f6             	test   %r14,%r14
    9168:	0f 85 0b f5 ff ff    	jne    8679 <f12+0x7b9>
    916e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9175:	00 
    9176:	4c 89 e7             	mov    %r12,%rdi
    9179:	48 89 05 f8 a2 01 00 	mov    %rax,0x1a2f8(%rip)        # 23478 <fwp_cleanups>
    9180:	e8 eb be ff ff       	call   5070 <fwp_tape_buffers_release>
    9185:	48 8b 0d d4 7e 00 00 	mov    0x7ed4(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    918c:	ba 13 00 00 00       	mov    $0x13,%edx
    9191:	be 01 00 00 00       	mov    $0x1,%esi
    9196:	48 8d 3d 6b 3e 00 00 	lea    0x3e6b(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    919d:	e8 de a4 ff ff       	call   3680 <fwrite@plt>
    91a2:	31 ff                	xor    %edi,%edi
    91a4:	e8 17 a4 ff ff       	call   35c0 <fflush@plt>
    91a9:	bf 66 00 00 00       	mov    $0x66,%edi
    91ae:	e8 ed a4 ff ff       	call   36a0 <_Exit@plt>
    91b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    91b8:	66 85 c0             	test   %ax,%ax
    91bb:	0f 85 8f f6 ff ff    	jne    8850 <f12+0x990>
    91c1:	e9 7a f6 ff ff       	jmp    8840 <f12+0x980>
    91c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    91cd:	00 00 00 
    91d0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    91d5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    91da:	e9 a1 fb ff ff       	jmp    8d80 <f12+0xec0>
    91df:	90                   	nop
    91e0:	66 0f 6f 0d d8 7e 01 	movdqa 0x17ed8(%rip),%xmm1        # 210c0 <fwp_tape_workspace>
    91e7:	00 
    91e8:	48 c7 05 b5 7e 01 00 	movq   $0x0,0x17eb5(%rip)        # 210a8 <fwp_tape_cached_bytes>
    91ef:	00 00 00 00 
    91f3:	41 0f 11 4c 24 20    	movups %xmm1,0x20(%r12)
    91f9:	48 8b 05 e0 7e 01 00 	mov    0x17ee0(%rip),%rax        # 210e0 <fwp_tape_workspace+0x20>
    9200:	66 0f 6f 0d c8 7e 01 	movdqa 0x17ec8(%rip),%xmm1        # 210d0 <fwp_tape_workspace+0x10>
    9207:	00 
    9208:	49 89 44 24 40       	mov    %rax,0x40(%r12)
    920d:	48 8b 05 d4 7e 01 00 	mov    0x17ed4(%rip),%rax        # 210e8 <fwp_tape_workspace+0x28>
    9214:	41 0f 11 4c 24 30    	movups %xmm1,0x30(%r12)
    921a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    921e:	49 89 44 24 18       	mov    %rax,0x18(%r12)
    9223:	48 8b 05 c6 7e 01 00 	mov    0x17ec6(%rip),%rax        # 210f0 <fwp_tape_workspace+0x30>
    922a:	0f 29 0d 8f 7e 01 00 	movaps %xmm1,0x17e8f(%rip)        # 210c0 <fwp_tape_workspace>
    9231:	49 89 44 24 48       	mov    %rax,0x48(%r12)
    9236:	0f 29 0d 93 7e 01 00 	movaps %xmm1,0x17e93(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    923d:	48 c7 05 a8 7e 01 00 	movq   $0x0,0x17ea8(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    9244:	00 00 00 00 
    9248:	0f 29 0d 91 7e 01 00 	movaps %xmm1,0x17e91(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    924f:	e9 d2 ee ff ff       	jmp    8126 <f12+0x266>
    9254:	0f 1f 40 00          	nopl   0x0(%rax)
    9258:	48 89 eb             	mov    %rbp,%rbx
    925b:	e9 b5 f3 ff ff       	jmp    8615 <f12+0x755>
    9260:	4d 85 f6             	test   %r14,%r14
    9263:	0f 84 05 ff ff ff    	je     916e <f12+0x12ae>
    9269:	49 89 db             	mov    %rbx,%r11
    926c:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    9273:	00 
    9274:	31 f6                	xor    %esi,%esi
    9276:	4c 89 f7             	mov    %r14,%rdi
    9279:	49 29 eb             	sub    %rbp,%r11
    927c:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
    9281:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    9286:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    928b:	e8 30 a2 ff ff       	call   34c0 <memset@plt>
    9290:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    9295:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
    929a:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
    929f:	e9 f3 f3 ff ff       	jmp    8697 <f12+0x7d7>
    92a4:	0f 1f 40 00          	nopl   0x0(%rax)
    92a8:	be 68 00 00 00       	mov    $0x68,%esi
    92ad:	41 be 01 00 00 00    	mov    $0x1,%r14d
    92b3:	e9 c2 ed ff ff       	jmp    807a <f12+0x1ba>
    92b8:	be 02 00 00 00       	mov    $0x2,%esi
    92bd:	bf 08 00 00 00       	mov    $0x8,%edi
    92c2:	e8 c9 c9 ff ff       	call   5c90 <fwp_heap_alloc>
    92c7:	49 89 c4             	mov    %rax,%r12
    92ca:	45 31 f6             	xor    %r14d,%r14d
    92cd:	e9 ae fa ff ff       	jmp    8d80 <f12+0xec0>
    92d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    92d8:	66 85 c0             	test   %ax,%ax
    92db:	0f 85 fd fd ff ff    	jne    90de <f12+0x121e>
    92e1:	e9 ea fd ff ff       	jmp    90d0 <f12+0x1210>
    92e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    92ed:	00 00 00 
    92f0:	48 89 d7             	mov    %rdx,%rdi
    92f3:	be 08 00 00 00       	mov    $0x8,%esi
    92f8:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    92fd:	e8 1e a2 ff ff       	call   3520 <calloc@plt>
    9302:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    9307:	49 89 c6             	mov    %rax,%r14
    930a:	e9 51 f3 ff ff       	jmp    8660 <f12+0x7a0>
    930f:	31 ff                	xor    %edi,%edi
    9311:	e8 3a af ff ff       	call   4250 <descent_phase_step>
    9316:	66 0f ef c0          	pxor   %xmm0,%xmm0
    931a:	e9 c7 ec ff ff       	jmp    7fe6 <f12+0x126>
    931f:	49 8b 4d 00          	mov    0x0(%r13),%rcx
    9323:	48 85 c9             	test   %rcx,%rcx
    9326:	78 90                	js     92b8 <f12+0x13f8>
    9328:	48 8b 35 89 98 01 00 	mov    0x19889(%rip),%rsi        # 22bb8 <fwp_heap+0x13d8>
    932f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9334:	48 2b 05 55 98 01 00 	sub    0x19855(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    933b:	48 c1 e6 10          	shl    $0x10,%rsi
    933f:	48 39 f0             	cmp    %rsi,%rax
    9342:	0f 83 70 ff ff ff    	jae    92b8 <f12+0x13f8>
    9348:	48 89 c6             	mov    %rax,%rsi
    934b:	48 c1 ee 10          	shr    $0x10,%rsi
    934f:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9353:	48 8b 35 7e 98 01 00 	mov    0x1987e(%rip),%rsi        # 22bd8 <fwp_heap+0x13f8>
    935a:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    935e:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9362:	48 85 ff             	test   %rdi,%rdi
    9365:	0f 84 4d ff ff ff    	je     92b8 <f12+0x13f8>
    936b:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9370:	49 89 cf             	mov    %rcx,%r15
    9373:	e9 6d f6 ff ff       	jmp    89e5 <f12+0xb25>
    9378:	48 89 d7             	mov    %rdx,%rdi
    937b:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9380:	e8 cb c1 ff ff       	call   5550 <fwp_rc_forget_slot>
    9385:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    938a:	e9 44 ef ff ff       	jmp    82d3 <f12+0x413>
    938f:	4c 89 e7             	mov    %r12,%rdi
    9392:	e8 b9 c1 ff ff       	call   5550 <fwp_rc_forget_slot>
    9397:	e9 af f4 ff ff       	jmp    884b <f12+0x98b>
    939c:	4c 89 ff             	mov    %r15,%rdi
    939f:	e8 ac c1 ff ff       	call   5550 <fwp_rc_forget_slot>
    93a4:	e9 31 fd ff ff       	jmp    90da <f12+0x121a>
    93a9:	e8 82 c0 ff ff       	call   5430 <fwp_rc_wide_dup>
    93ae:	e9 ec eb ff ff       	jmp    7f9f <f12+0xdf>
    93b3:	49 89 db             	mov    %rbx,%r11
    93b6:	4c 8d 4b ff          	lea    -0x1(%rbx),%r9
    93ba:	31 f6                	xor    %esi,%esi
    93bc:	4c 89 f7             	mov    %r14,%rdi
    93bf:	49 29 eb             	sub    %rbp,%r11
    93c2:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    93c9:	00 
    93ca:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
    93cf:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
    93d4:	e8 e7 a0 ff ff       	call   34c0 <memset@plt>
    93d9:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
    93de:	4c 8b 5c 24 38       	mov    0x38(%rsp),%r11
    93e3:	e9 a7 f2 ff ff       	jmp    868f <f12+0x7cf>
    93e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    93ef:	00 
    93f0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    93f4:	4d 85 ff             	test   %r15,%r15
    93f7:	74 1f                	je     9418 <f12+0x1558>
    93f9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    93fd:	4c 29 fa             	sub    %r15,%rdx
    9400:	4c 39 c2             	cmp    %r8,%rdx
    9403:	72 13                	jb     9418 <f12+0x1558>
    9405:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    9409:	48 89 50 08          	mov    %rdx,0x8(%rax)
    940d:	e9 4b fa ff ff       	jmp    8e5d <f12+0xf9d>
    9412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9418:	31 f6                	xor    %esi,%esi
    941a:	bf 18 00 00 00       	mov    $0x18,%edi
    941f:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    9425:	e8 66 c8 ff ff       	call   5c90 <fwp_heap_alloc>
    942a:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9430:	49 89 c7             	mov    %rax,%r15
    9433:	e9 9c fa ff ff       	jmp    8ed4 <f12+0x1014>
    9438:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    943f:	00 
    9440:	66 85 c0             	test   %ax,%ax
    9443:	0f 85 c7 f9 ff ff    	jne    8e10 <f12+0xf50>
    9449:	41 80 3f ff          	cmpb   $0xff,(%r15)
    944d:	0f 85 14 fb ff ff    	jne    8f67 <f12+0x10a7>
    9453:	66 90                	xchg   %ax,%ax
    9455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    945c:	00 00 00 00 
    9460:	4c 89 ff             	mov    %r15,%rdi
    9463:	e8 e8 c0 ff ff       	call   5550 <fwp_rc_forget_slot>
    9468:	e9 fa fa ff ff       	jmp    8f67 <f12+0x10a7>
    946d:	45 31 ff             	xor    %r15d,%r15d
    9470:	e9 e4 f6 ff ff       	jmp    8b59 <f12+0xc99>
    9475:	48 8d 3d 34 44 00 00 	lea    0x4434(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    947c:	e8 6f af ff ff       	call   43f0 <fwp_trap>
    9481:	48 8d 3d df 3c 00 00 	lea    0x3cdf(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    9488:	e8 63 af ff ff       	call   43f0 <fwp_trap>
    948d:	e8 1e a8 ff ff       	call   3cb0 <fwp_heap_oom>
    9492:	48 8d 3d 1f 45 00 00 	lea    0x451f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    9499:	e8 52 af ff ff       	call   43f0 <fwp_trap>
    949e:	e8 5d a2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    94a3:	45 31 e4             	xor    %r12d,%r12d
    94a6:	e9 1f fe ff ff       	jmp    92ca <f12+0x140a>
    94ab:	48 8d 3d 06 3d 00 00 	lea    0x3d06(%rip),%rdi        # d1b8 <_IO_stdin_used+0x1b8>
    94b2:	e8 39 af ff ff       	call   43f0 <fwp_trap>
    94b7:	48 8d 3d d2 3c 00 00 	lea    0x3cd2(%rip),%rdi        # d190 <_IO_stdin_used+0x190>
    94be:	e8 2d af ff ff       	call   43f0 <fwp_trap>
    94c3:	48 8d 3d e0 3c 00 00 	lea    0x3ce0(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    94ca:	e8 21 af ff ff       	call   43f0 <fwp_trap>
    94cf:	48 8d 3d 22 44 00 00 	lea    0x4422(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    94d6:	e8 15 af ff ff       	call   43f0 <fwp_trap>
    94db:	48 8d 3d a6 44 00 00 	lea    0x44a6(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    94e2:	e8 09 af ff ff       	call   43f0 <fwp_trap>
    94e7:	48 8d 3d 6a 44 00 00 	lea    0x446a(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    94ee:	e8 fd ae ff ff       	call   43f0 <fwp_trap>
    94f3:	e8 68 9f ff ff       	call   3460 <__stack_chk_fail@plt>
    94f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    94ff:	00 

0000000000009500 <fwp_owned_entry12>:
    9500:	f3 0f 1e fa          	endbr64
    9504:	48 8b 3f             	mov    (%rdi),%rdi
    9507:	e9 b4 e9 ff ff       	jmp    7ec0 <f12>
    950c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009510 <e12>:
    9510:	f3 0f 1e fa          	endbr64
    9514:	53                   	push   %rbx
    9515:	48 8b 1f             	mov    (%rdi),%rbx
    9518:	48 89 df             	mov    %rbx,%rdi
    951b:	e8 40 d3 ff ff       	call   6860 <fwp_rc_share>
    9520:	48 89 df             	mov    %rbx,%rdi
    9523:	e8 98 e9 ff ff       	call   7ec0 <f12>
    9528:	48 89 c3             	mov    %rax,%rbx
    952b:	48 89 c7             	mov    %rax,%rdi
    952e:	e8 2d d3 ff ff       	call   6860 <fwp_rc_share>
    9533:	48 89 d8             	mov    %rbx,%rax
    9536:	5b                   	pop    %rbx
    9537:	c3                   	ret
    9538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    953f:	00 

0000000000009540 <fwp_drop2>:
    9540:	48 8b 0d 71 96 01 00 	mov    0x19671(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    9547:	48 89 f8             	mov    %rdi,%rax
    954a:	48 2b 05 3f 96 01 00 	sub    0x1963f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9551:	48 c1 e1 10          	shl    $0x10,%rcx
    9555:	48 39 c8             	cmp    %rcx,%rax
    9558:	0f 83 42 01 00 00    	jae    96a0 <fwp_drop2+0x160>
    955e:	48 83 ec 18          	sub    $0x18,%rsp
    9562:	48 89 fa             	mov    %rdi,%rdx
    9565:	4c 8d 05 74 82 01 00 	lea    0x18274(%rip),%r8        # 217e0 <fwp_heap>
    956c:	48 89 c1             	mov    %rax,%rcx
    956f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9576:	48 c1 e9 10          	shr    $0x10,%rcx
    957a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    957e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9582:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9586:	48 85 c9             	test   %rcx,%rcx
    9589:	74 40                	je     95cb <fwp_drop2+0x8b>
    958b:	0f b6 3e             	movzbl (%rsi),%edi
    958e:	40 80 ff 02          	cmp    $0x2,%dil
    9592:	74 3c                	je     95d0 <fwp_drop2+0x90>
    9594:	40 80 ff 01          	cmp    $0x1,%dil
    9598:	75 31                	jne    95cb <fwp_drop2+0x8b>
    959a:	8b 7e 18             	mov    0x18(%rsi),%edi
    959d:	0f b7 c0             	movzwl %ax,%eax
    95a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    95a3:	48 0f af c7          	imul   %rdi,%rax
    95a7:	48 c1 e8 20          	shr    $0x20,%rax
    95ab:	48 39 f0             	cmp    %rsi,%rax
    95ae:	73 1b                	jae    95cb <fwp_drop2+0x8b>
    95b0:	48 01 c1             	add    %rax,%rcx
    95b3:	0f b6 01             	movzbl (%rcx),%eax
    95b6:	84 c0                	test   %al,%al
    95b8:	74 11                	je     95cb <fwp_drop2+0x8b>
    95ba:	3c 01                	cmp    $0x1,%al
    95bc:	74 22                	je     95e0 <fwp_drop2+0xa0>
    95be:	3c ff                	cmp    $0xff,%al
    95c0:	0f 84 0a 01 00 00    	je     96d0 <fwp_drop2+0x190>
    95c6:	83 e8 01             	sub    $0x1,%eax
    95c9:	88 01                	mov    %al,(%rcx)
    95cb:	48 83 c4 18          	add    $0x18,%rsp
    95cf:	c3                   	ret
    95d0:	66 85 c0             	test   %ax,%ax
    95d3:	74 de                	je     95b3 <fwp_drop2+0x73>
    95d5:	48 83 c4 18          	add    $0x18,%rsp
    95d9:	c3                   	ret
    95da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    95e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    95eb:	48 89 f8             	mov    %rdi,%rax
    95ee:	48 c1 e1 10          	shl    $0x10,%rcx
    95f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    95f9:	48 39 c8             	cmp    %rcx,%rax
    95fc:	73 62                	jae    9660 <fwp_drop2+0x120>
    95fe:	48 89 c1             	mov    %rax,%rcx
    9601:	48 c1 e9 10          	shr    $0x10,%rcx
    9605:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9609:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    960d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9611:	48 85 c9             	test   %rcx,%rcx
    9614:	74 4a                	je     9660 <fwp_drop2+0x120>
    9616:	44 0f b6 0e          	movzbl (%rsi),%r9d
    961a:	41 80 f9 02          	cmp    $0x2,%r9b
    961e:	0f 84 9c 00 00 00    	je     96c0 <fwp_drop2+0x180>
    9624:	41 80 f9 01          	cmp    $0x1,%r9b
    9628:	75 36                	jne    9660 <fwp_drop2+0x120>
    962a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    962e:	0f b7 c0             	movzwl %ax,%eax
    9631:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9634:	49 0f af c1          	imul   %r9,%rax
    9638:	48 c1 e8 20          	shr    $0x20,%rax
    963c:	48 39 f0             	cmp    %rsi,%rax
    963f:	73 1f                	jae    9660 <fwp_drop2+0x120>
    9641:	48 01 c1             	add    %rax,%rcx
    9644:	0f b6 01             	movzbl (%rcx),%eax
    9647:	84 c0                	test   %al,%al
    9649:	74 15                	je     9660 <fwp_drop2+0x120>
    964b:	3c 01                	cmp    $0x1,%al
    964d:	74 59                	je     96a8 <fwp_drop2+0x168>
    964f:	3c ff                	cmp    $0xff,%al
    9651:	0f 84 ef 00 00 00    	je     9746 <fwp_drop2+0x206>
    9657:	83 e8 01             	sub    $0x1,%eax
    965a:	88 01                	mov    %al,(%rcx)
    965c:	0f 1f 40 00          	nopl   0x0(%rax)
    9660:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9664:	48 89 d7             	mov    %rdx,%rdi
    9667:	48 89 0c 24          	mov    %rcx,(%rsp)
    966b:	e8 70 d2 ff ff       	call   68e0 <fwp_rc_free_arr>
    9670:	4c 8d 05 69 81 01 00 	lea    0x18169(%rip),%r8        # 217e0 <fwp_heap>
    9677:	48 8b 04 24          	mov    (%rsp),%rax
    967b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9682:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9689:	48 c1 e2 10          	shl    $0x10,%rdx
    968d:	48 39 d0             	cmp    %rdx,%rax
    9690:	0f 83 35 ff ff ff    	jae    95cb <fwp_drop2+0x8b>
    9696:	48 8b 14 24          	mov    (%rsp),%rdx
    969a:	e9 cd fe ff ff       	jmp    956c <fwp_drop2+0x2c>
    969f:	90                   	nop
    96a0:	c3                   	ret
    96a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96a8:	48 89 14 24          	mov    %rdx,(%rsp)
    96ac:	e8 2f d2 ff ff       	call   68e0 <fwp_rc_free_arr>
    96b1:	48 8b 14 24          	mov    (%rsp),%rdx
    96b5:	eb a9                	jmp    9660 <fwp_drop2+0x120>
    96b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96be:	00 00 
    96c0:	66 85 c0             	test   %ax,%ax
    96c3:	75 9b                	jne    9660 <fwp_drop2+0x120>
    96c5:	e9 7a ff ff ff       	jmp    9644 <fwp_drop2+0x104>
    96ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96d0:	48 89 c8             	mov    %rcx,%rax
    96d3:	48 c1 e8 11          	shr    $0x11,%rax
    96d7:	48 31 c8             	xor    %rcx,%rax
    96da:	48 89 c2             	mov    %rax,%rdx
    96dd:	48 c1 ea 09          	shr    $0x9,%rdx
    96e1:	48 31 d0             	xor    %rdx,%rax
    96e4:	0f b6 d0             	movzbl %al,%edx
    96e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    96ee:	00 
    96ef:	48 85 c0             	test   %rax,%rax
    96f2:	75 19                	jne    970d <fwp_drop2+0x1cd>
    96f4:	e9 d3 00 00 00       	jmp    97cc <fwp_drop2+0x28c>
    96f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9704:	48 85 c0             	test   %rax,%rax
    9707:	0f 84 bf 00 00 00    	je     97cc <fwp_drop2+0x28c>
    970d:	48 89 c2             	mov    %rax,%rdx
    9710:	48 39 08             	cmp    %rcx,(%rax)
    9713:	75 eb                	jne    9700 <fwp_drop2+0x1c0>
    9715:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9719:	48 83 ea 01          	sub    $0x1,%rdx
    971d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9721:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9728:	0f 85 9d fe ff ff    	jne    95cb <fwp_drop2+0x8b>
    972e:	48 89 cf             	mov    %rcx,%rdi
    9731:	48 89 0c 24          	mov    %rcx,(%rsp)
    9735:	e8 16 be ff ff       	call   5550 <fwp_rc_forget_slot>
    973a:	48 8b 0c 24          	mov    (%rsp),%rcx
    973e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9741:	e9 85 fe ff ff       	jmp    95cb <fwp_drop2+0x8b>
    9746:	48 89 ce             	mov    %rcx,%rsi
    9749:	48 c1 ee 11          	shr    $0x11,%rsi
    974d:	48 31 ce             	xor    %rcx,%rsi
    9750:	48 89 f0             	mov    %rsi,%rax
    9753:	48 c1 e8 09          	shr    $0x9,%rax
    9757:	48 31 c6             	xor    %rax,%rsi
    975a:	40 0f b6 f6          	movzbl %sil,%esi
    975e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9765:	00 
    9766:	48 85 c0             	test   %rax,%rax
    9769:	75 1e                	jne    9789 <fwp_drop2+0x249>
    976b:	eb 5f                	jmp    97cc <fwp_drop2+0x28c>
    976d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9774:	00 
    9775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    977c:	00 00 00 00 
    9780:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9784:	48 85 c0             	test   %rax,%rax
    9787:	74 43                	je     97cc <fwp_drop2+0x28c>
    9789:	48 89 c6             	mov    %rax,%rsi
    978c:	48 39 08             	cmp    %rcx,(%rax)
    978f:	75 ef                	jne    9780 <fwp_drop2+0x240>
    9791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9795:	48 83 ee 01          	sub    $0x1,%rsi
    9799:	48 89 70 08          	mov    %rsi,0x8(%rax)
    979d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    97a4:	0f 85 b6 fe ff ff    	jne    9660 <fwp_drop2+0x120>
    97aa:	48 89 cf             	mov    %rcx,%rdi
    97ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    97b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    97b6:	e8 95 bd ff ff       	call   5550 <fwp_rc_forget_slot>
    97bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    97bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    97c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    97c7:	e9 94 fe ff ff       	jmp    9660 <fwp_drop2+0x120>
    97cc:	48 8d 3d b5 40 00 00 	lea    0x40b5(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    97d3:	e8 18 ac ff ff       	call   43f0 <fwp_trap>
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 

00000000000097e0 <fwp_arg_drop23>:
    97e0:	f3 0f 1e fa          	endbr64
    97e4:	85 f6                	test   %esi,%esi
    97e6:	75 04                	jne    97ec <fwp_arg_drop23+0xc>
    97e8:	85 d2                	test   %edx,%edx
    97ea:	75 04                	jne    97f0 <fwp_arg_drop23+0x10>
    97ec:	c3                   	ret
    97ed:	0f 1f 00             	nopl   (%rax)
    97f0:	48 8b 3f             	mov    (%rdi),%rdi
    97f3:	e9 48 fd ff ff       	jmp    9540 <fwp_drop2>
    97f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97ff:	00 

0000000000009800 <fwp_caps23>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	48 83 ec 18          	sub    $0x18,%rsp
    9808:	8b 57 04             	mov    0x4(%rdi),%edx
    980b:	48 89 f8             	mov    %rdi,%rax
    980e:	85 d2                	test   %edx,%edx
    9810:	0f 84 9a 00 00 00    	je     98b0 <fwp_caps23+0xb0>
    9816:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    981a:	85 f6                	test   %esi,%esi
    981c:	0f 85 9e 00 00 00    	jne    98c0 <fwp_caps23+0xc0>
    9822:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9827:	e8 14 fd ff ff       	call   9540 <fwp_drop2>
    982c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9831:	48 8b 0d 80 93 01 00 	mov    0x19380(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    9838:	48 89 c2             	mov    %rax,%rdx
    983b:	48 2b 15 4e 93 01 00 	sub    0x1934e(%rip),%rdx        # 22b90 <fwp_heap+0x13b0>
    9842:	48 c1 e1 10          	shl    $0x10,%rcx
    9846:	48 39 ca             	cmp    %rcx,%rdx
    9849:	73 6d                	jae    98b8 <fwp_caps23+0xb8>
    984b:	48 89 d1             	mov    %rdx,%rcx
    984e:	48 c1 e9 10          	shr    $0x10,%rcx
    9852:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9856:	48 8b 0d 7b 93 01 00 	mov    0x1937b(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    985d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9861:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9865:	48 85 f6             	test   %rsi,%rsi
    9868:	74 4e                	je     98b8 <fwp_caps23+0xb8>
    986a:	0f b6 39             	movzbl (%rcx),%edi
    986d:	40 80 ff 02          	cmp    $0x2,%dil
    9871:	0f 84 b9 00 00 00    	je     9930 <fwp_caps23+0x130>
    9877:	40 80 ff 01          	cmp    $0x1,%dil
    987b:	75 3b                	jne    98b8 <fwp_caps23+0xb8>
    987d:	8b 79 18             	mov    0x18(%rcx),%edi
    9880:	0f b7 d2             	movzwl %dx,%edx
    9883:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9886:	48 0f af d7          	imul   %rdi,%rdx
    988a:	48 c1 ea 20          	shr    $0x20,%rdx
    988e:	48 39 ca             	cmp    %rcx,%rdx
    9891:	73 25                	jae    98b8 <fwp_caps23+0xb8>
    9893:	48 01 d6             	add    %rdx,%rsi
    9896:	80 3e 01             	cmpb   $0x1,(%rsi)
    9899:	75 1d                	jne    98b8 <fwp_caps23+0xb8>
    989b:	48 89 c7             	mov    %rax,%rdi
    989e:	48 83 c4 18          	add    $0x18,%rsp
    98a2:	e9 e9 be ff ff       	jmp    5790 <fwp_mem_free>
    98a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    98ae:	00 00 
    98b0:	85 f6                	test   %esi,%esi
    98b2:	0f 84 79 ff ff ff    	je     9831 <fwp_caps23+0x31>
    98b8:	48 83 c4 18          	add    $0x18,%rsp
    98bc:	c3                   	ret
    98bd:	0f 1f 00             	nopl   (%rax)
    98c0:	48 8b 05 f1 92 01 00 	mov    0x192f1(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    98c7:	48 2b 3d c2 92 01 00 	sub    0x192c2(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    98ce:	48 c1 e0 10          	shl    $0x10,%rax
    98d2:	48 39 c7             	cmp    %rax,%rdi
    98d5:	73 e1                	jae    98b8 <fwp_caps23+0xb8>
    98d7:	48 89 f8             	mov    %rdi,%rax
    98da:	48 c1 e8 10          	shr    $0x10,%rax
    98de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    98e2:	48 8b 05 ef 92 01 00 	mov    0x192ef(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    98e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    98ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    98f1:	48 85 c0             	test   %rax,%rax
    98f4:	74 c2                	je     98b8 <fwp_caps23+0xb8>
    98f6:	0f b6 0a             	movzbl (%rdx),%ecx
    98f9:	80 f9 02             	cmp    $0x2,%cl
    98fc:	74 42                	je     9940 <fwp_caps23+0x140>
    98fe:	80 f9 01             	cmp    $0x1,%cl
    9901:	75 b5                	jne    98b8 <fwp_caps23+0xb8>
    9903:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9906:	0f b7 ff             	movzwl %di,%edi
    9909:	8b 52 1c             	mov    0x1c(%rdx),%edx
    990c:	48 0f af f9          	imul   %rcx,%rdi
    9910:	48 c1 ef 20          	shr    $0x20,%rdi
    9914:	48 39 d7             	cmp    %rdx,%rdi
    9917:	73 9f                	jae    98b8 <fwp_caps23+0xb8>
    9919:	48 01 f8             	add    %rdi,%rax
    991c:	0f b6 10             	movzbl (%rax),%edx
    991f:	84 d2                	test   %dl,%dl
    9921:	74 95                	je     98b8 <fwp_caps23+0xb8>
    9923:	80 fa fd             	cmp    $0xfd,%dl
    9926:	77 23                	ja     994b <fwp_caps23+0x14b>
    9928:	83 c2 01             	add    $0x1,%edx
    992b:	88 10                	mov    %dl,(%rax)
    992d:	eb 89                	jmp    98b8 <fwp_caps23+0xb8>
    992f:	90                   	nop
    9930:	66 85 d2             	test   %dx,%dx
    9933:	0f 85 7f ff ff ff    	jne    98b8 <fwp_caps23+0xb8>
    9939:	e9 58 ff ff ff       	jmp    9896 <fwp_caps23+0x96>
    993e:	66 90                	xchg   %ax,%ax
    9940:	66 85 ff             	test   %di,%di
    9943:	0f 85 6f ff ff ff    	jne    98b8 <fwp_caps23+0xb8>
    9949:	eb d1                	jmp    991c <fwp_caps23+0x11c>
    994b:	48 89 c7             	mov    %rax,%rdi
    994e:	48 83 c4 18          	add    $0x18,%rsp
    9952:	e9 d9 ba ff ff       	jmp    5430 <fwp_rc_wide_dup>
    9957:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    995e:	00 00 

0000000000009960 <f23>:
    9960:	41 57                	push   %r15
    9962:	41 56                	push   %r14
    9964:	41 55                	push   %r13
    9966:	41 54                	push   %r12
    9968:	55                   	push   %rbp
    9969:	53                   	push   %rbx
    996a:	48 83 ec 38          	sub    $0x38,%rsp
    996e:	48 8b 15 43 92 01 00 	mov    0x19243(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9975:	48 8b 0d 14 92 01 00 	mov    0x19214(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    997c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9983:	00 00 
    9985:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    998a:	49 89 fc             	mov    %rdi,%r12
    998d:	48 c1 e2 10          	shl    $0x10,%rdx
    9991:	48 85 ff             	test   %rdi,%rdi
    9994:	0f 84 bc 02 00 00    	je     9c56 <f23+0x2f6>
    999a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    999f:	48 89 d8             	mov    %rbx,%rax
    99a2:	48 29 c8             	sub    %rcx,%rax
    99a5:	48 39 d0             	cmp    %rdx,%rax
    99a8:	0f 83 72 03 00 00    	jae    9d20 <f23+0x3c0>
    99ae:	48 89 c2             	mov    %rax,%rdx
    99b1:	48 c1 ea 10          	shr    $0x10,%rdx
    99b5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99b9:	48 8b 15 18 92 01 00 	mov    0x19218(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    99c0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99c4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99c8:	48 85 ff             	test   %rdi,%rdi
    99cb:	0f 84 4f 03 00 00    	je     9d20 <f23+0x3c0>
    99d1:	0f b6 0a             	movzbl (%rdx),%ecx
    99d4:	80 f9 02             	cmp    $0x2,%cl
    99d7:	0f 84 53 02 00 00    	je     9c30 <f23+0x2d0>
    99dd:	80 f9 01             	cmp    $0x1,%cl
    99e0:	75 24                	jne    9a06 <f23+0xa6>
    99e2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99e5:	0f b7 c0             	movzwl %ax,%eax
    99e8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99eb:	48 0f af c1          	imul   %rcx,%rax
    99ef:	48 c1 e8 20          	shr    $0x20,%rax
    99f3:	48 39 d0             	cmp    %rdx,%rax
    99f6:	73 0e                	jae    9a06 <f23+0xa6>
    99f8:	48 01 c7             	add    %rax,%rdi
    99fb:	0f b6 07             	movzbl (%rdi),%eax
    99fe:	84 c0                	test   %al,%al
    9a00:	0f 85 ca 02 00 00    	jne    9cd0 <f23+0x370>
    9a06:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9a0b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    9a10:	ba 01 00 00 00       	mov    $0x1,%edx
    9a15:	48 85 db             	test   %rbx,%rbx
    9a18:	74 13                	je     9a2d <f23+0xcd>
    9a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9a20:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9a24:	48 83 c2 01          	add    $0x1,%rdx
    9a28:	48 85 db             	test   %rbx,%rbx
    9a2b:	75 f3                	jne    9a20 <f23+0xc0>
    9a2d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a32:	48 85 c0             	test   %rax,%rax
    9a35:	0f 84 15 03 00 00    	je     9d50 <f23+0x3f0>
    9a3b:	31 db                	xor    %ebx,%ebx
    9a3d:	0f 1f 00             	nopl   (%rax)
    9a40:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a44:	48 83 c3 01          	add    $0x1,%rbx
    9a48:	48 85 c0             	test   %rax,%rax
    9a4b:	75 f3                	jne    9a40 <f23+0xe0>
    9a4d:	48 39 d3             	cmp    %rdx,%rbx
    9a50:	48 0f 47 da          	cmova  %rdx,%rbx
    9a54:	48 89 d8             	mov    %rbx,%rax
    9a57:	48 c1 e8 3c          	shr    $0x3c,%rax
    9a5b:	0f 85 8f 03 00 00    	jne    9df0 <f23+0x490>
    9a61:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9a65:	be 02 00 00 00       	mov    $0x2,%esi
    9a6a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9a71:	00 
    9a72:	e8 19 c2 ff ff       	call   5c90 <fwp_heap_alloc>
    9a77:	48 89 28             	mov    %rbp,(%rax)
    9a7a:	48 8b 15 37 91 01 00 	mov    0x19137(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9a81:	49 89 c6             	mov    %rax,%r14
    9a84:	48 2b 05 05 91 01 00 	sub    0x19105(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9a8b:	48 c1 e2 10          	shl    $0x10,%rdx
    9a8f:	48 39 d0             	cmp    %rdx,%rax
    9a92:	73 57                	jae    9aeb <f23+0x18b>
    9a94:	48 89 c2             	mov    %rax,%rdx
    9a97:	48 c1 ea 10          	shr    $0x10,%rdx
    9a9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a9f:	48 8b 15 32 91 01 00 	mov    0x19132(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9aa6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aaa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9aae:	48 85 ed             	test   %rbp,%rbp
    9ab1:	74 38                	je     9aeb <f23+0x18b>
    9ab3:	0f b6 0a             	movzbl (%rdx),%ecx
    9ab6:	80 f9 02             	cmp    $0x2,%cl
    9ab9:	0f 84 51 02 00 00    	je     9d10 <f23+0x3b0>
    9abf:	80 f9 01             	cmp    $0x1,%cl
    9ac2:	75 27                	jne    9aeb <f23+0x18b>
    9ac4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ac7:	0f b7 c0             	movzwl %ax,%eax
    9aca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9acd:	48 0f af c1          	imul   %rcx,%rax
    9ad1:	48 c1 e8 20          	shr    $0x20,%rax
    9ad5:	48 39 d0             	cmp    %rdx,%rax
    9ad8:	73 11                	jae    9aeb <f23+0x18b>
    9ada:	48 01 c5             	add    %rax,%rbp
    9add:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9ae1:	0f 84 d5 02 00 00    	je     9dbc <f23+0x45c>
    9ae7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9aeb:	48 85 db             	test   %rbx,%rbx
    9aee:	74 5d                	je     9b4d <f23+0x1ed>
    9af0:	48 c1 e3 04          	shl    $0x4,%rbx
    9af4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9af9:	4c 89 f5             	mov    %r14,%rbp
    9afc:	4d 89 e5             	mov    %r12,%r13
    9aff:	4c 01 f3             	add    %r14,%rbx
    9b02:	0f 1f 00             	nopl   (%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	49 8b 45 08          	mov    0x8(%r13),%rax
    9b14:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9b18:	48 83 c5 10          	add    $0x10,%rbp
    9b1c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9b21:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9b25:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9b29:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    9b2e:	e8 bd c9 ff ff       	call   64f0 <w107>
    9b33:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9b38:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    9b3c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9b40:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9b44:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    9b48:	48 39 dd             	cmp    %rbx,%rbp
    9b4b:	75 c3                	jne    9b10 <f23+0x1b0>
    9b4d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9b52:	e8 e9 f9 ff ff       	call   9540 <fwp_drop2>
    9b57:	4c 89 e7             	mov    %r12,%rdi
    9b5a:	e8 e1 f9 ff ff       	call   9540 <fwp_drop2>
    9b5f:	4c 89 f7             	mov    %r14,%rdi
    9b62:	e8 49 cb ff ff       	call   66b0 <w164.constprop.0>
    9b67:	4c 89 f7             	mov    %r14,%rdi
    9b6a:	48 89 c3             	mov    %rax,%rbx
    9b6d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9b73:	e8 38 de ff ff       	call   79b0 <fwp_drop4>
    9b78:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9b7e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    9b83:	31 ff                	xor    %edi,%edi
    9b85:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9b8a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    9b8e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9b93:	e8 98 cb ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    9b98:	48 8b 15 19 90 01 00 	mov    0x19019(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9b9f:	48 89 c5             	mov    %rax,%rbp
    9ba2:	48 2b 05 e7 8f 01 00 	sub    0x18fe7(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9ba9:	48 c1 e2 10          	shl    $0x10,%rdx
    9bad:	48 39 d0             	cmp    %rdx,%rax
    9bb0:	73 55                	jae    9c07 <f23+0x2a7>
    9bb2:	48 89 c2             	mov    %rax,%rdx
    9bb5:	48 c1 ea 10          	shr    $0x10,%rdx
    9bb9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bbd:	48 8b 15 14 90 01 00 	mov    0x19014(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9bc4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bc8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9bcc:	48 85 db             	test   %rbx,%rbx
    9bcf:	74 36                	je     9c07 <f23+0x2a7>
    9bd1:	0f b6 0a             	movzbl (%rdx),%ecx
    9bd4:	80 f9 02             	cmp    $0x2,%cl
    9bd7:	0f 84 1b 01 00 00    	je     9cf8 <f23+0x398>
    9bdd:	80 f9 01             	cmp    $0x1,%cl
    9be0:	75 25                	jne    9c07 <f23+0x2a7>
    9be2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9be5:	0f b7 c0             	movzwl %ax,%eax
    9be8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9beb:	48 0f af c1          	imul   %rcx,%rax
    9bef:	48 c1 e8 20          	shr    $0x20,%rax
    9bf3:	48 39 d0             	cmp    %rdx,%rax
    9bf6:	73 0f                	jae    9c07 <f23+0x2a7>
    9bf8:	48 01 c3             	add    %rax,%rbx
    9bfb:	80 3b ff             	cmpb   $0xff,(%rbx)
    9bfe:	0f 84 ab 01 00 00    	je     9daf <f23+0x44f>
    9c04:	c6 03 01             	movb   $0x1,(%rbx)
    9c07:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9c0c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c13:	00 00 
    9c15:	0f 85 d0 01 00 00    	jne    9deb <f23+0x48b>
    9c1b:	48 83 c4 38          	add    $0x38,%rsp
    9c1f:	48 89 e8             	mov    %rbp,%rax
    9c22:	5b                   	pop    %rbx
    9c23:	5d                   	pop    %rbp
    9c24:	41 5c                	pop    %r12
    9c26:	41 5d                	pop    %r13
    9c28:	41 5e                	pop    %r14
    9c2a:	41 5f                	pop    %r15
    9c2c:	c3                   	ret
    9c2d:	0f 1f 00             	nopl   (%rax)
    9c30:	66 85 c0             	test   %ax,%ax
    9c33:	0f 85 cd fd ff ff    	jne    9a06 <f23+0xa6>
    9c39:	0f b6 07             	movzbl (%rdi),%eax
    9c3c:	84 c0                	test   %al,%al
    9c3e:	0f 84 c2 fd ff ff    	je     9a06 <f23+0xa6>
    9c44:	3c fd                	cmp    $0xfd,%al
    9c46:	0f 87 95 01 00 00    	ja     9de1 <f23+0x481>
    9c4c:	83 c0 01             	add    $0x1,%eax
    9c4f:	88 07                	mov    %al,(%rdi)
    9c51:	e9 b0 fd ff ff       	jmp    9a06 <f23+0xa6>
    9c56:	48 f7 d9             	neg    %rcx
    9c59:	48 39 d1             	cmp    %rdx,%rcx
    9c5c:	0f 83 ee 00 00 00    	jae    9d50 <f23+0x3f0>
    9c62:	48 89 c8             	mov    %rcx,%rax
    9c65:	48 c1 e8 10          	shr    $0x10,%rax
    9c69:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9c6d:	48 8b 05 64 8f 01 00 	mov    0x18f64(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    9c74:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9c78:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9c7c:	48 85 ff             	test   %rdi,%rdi
    9c7f:	0f 84 cb 00 00 00    	je     9d50 <f23+0x3f0>
    9c85:	0f b6 02             	movzbl (%rdx),%eax
    9c88:	3c 02                	cmp    $0x2,%al
    9c8a:	0f 84 9a 00 00 00    	je     9d2a <f23+0x3ca>
    9c90:	3c 01                	cmp    $0x1,%al
    9c92:	0f 85 b8 00 00 00    	jne    9d50 <f23+0x3f0>
    9c98:	0f b7 c1             	movzwl %cx,%eax
    9c9b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c9e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ca1:	48 0f af c1          	imul   %rcx,%rax
    9ca5:	48 c1 e8 20          	shr    $0x20,%rax
    9ca9:	48 39 d0             	cmp    %rdx,%rax
    9cac:	0f 83 9e 00 00 00    	jae    9d50 <f23+0x3f0>
    9cb2:	48 01 c7             	add    %rax,%rdi
    9cb5:	0f b6 07             	movzbl (%rdi),%eax
    9cb8:	84 c0                	test   %al,%al
    9cba:	0f 84 90 00 00 00    	je     9d50 <f23+0x3f0>
    9cc0:	31 db                	xor    %ebx,%ebx
    9cc2:	0f 1f 00             	nopl   (%rax)
    9cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9ccc:	00 00 00 00 
    9cd0:	3c fd                	cmp    $0xfd,%al
    9cd2:	0f 87 f1 00 00 00    	ja     9dc9 <f23+0x469>
    9cd8:	83 c0 01             	add    $0x1,%eax
    9cdb:	88 07                	mov    %al,(%rdi)
    9cdd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9ce2:	31 d2                	xor    %edx,%edx
    9ce4:	4d 85 e4             	test   %r12,%r12
    9ce7:	0f 85 1e fd ff ff    	jne    9a0b <f23+0xab>
    9ced:	e9 3b fd ff ff       	jmp    9a2d <f23+0xcd>
    9cf2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9cf8:	66 85 c0             	test   %ax,%ax
    9cfb:	0f 85 06 ff ff ff    	jne    9c07 <f23+0x2a7>
    9d01:	e9 f5 fe ff ff       	jmp    9bfb <f23+0x29b>
    9d06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d0d:	00 00 00 
    9d10:	66 85 c0             	test   %ax,%ax
    9d13:	0f 85 d2 fd ff ff    	jne    9aeb <f23+0x18b>
    9d19:	e9 bf fd ff ff       	jmp    9add <f23+0x17d>
    9d1e:	66 90                	xchg   %ax,%ax
    9d20:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9d25:	e9 e6 fc ff ff       	jmp    9a10 <f23+0xb0>
    9d2a:	66 85 c9             	test   %cx,%cx
    9d2d:	75 21                	jne    9d50 <f23+0x3f0>
    9d2f:	0f b6 07             	movzbl (%rdi),%eax
    9d32:	84 c0                	test   %al,%al
    9d34:	74 1a                	je     9d50 <f23+0x3f0>
    9d36:	3c fd                	cmp    $0xfd,%al
    9d38:	0f 87 be 00 00 00    	ja     9dfc <f23+0x49c>
    9d3e:	83 c0 01             	add    $0x1,%eax
    9d41:	88 07                	mov    %al,(%rdi)
    9d43:	66 90                	xchg   %ax,%ax
    9d45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d4c:	00 00 00 00 
    9d50:	be 02 00 00 00       	mov    $0x2,%esi
    9d55:	bf 08 00 00 00       	mov    $0x8,%edi
    9d5a:	e8 31 bf ff ff       	call   5c90 <fwp_heap_alloc>
    9d5f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9d66:	48 8b 15 4b 8e 01 00 	mov    0x18e4b(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9d6d:	49 89 c6             	mov    %rax,%r14
    9d70:	48 2b 05 19 8e 01 00 	sub    0x18e19(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9d77:	48 c1 e2 10          	shl    $0x10,%rdx
    9d7b:	48 39 d0             	cmp    %rdx,%rax
    9d7e:	73 53                	jae    9dd3 <f23+0x473>
    9d80:	48 89 c2             	mov    %rax,%rdx
    9d83:	48 c1 ea 10          	shr    $0x10,%rdx
    9d87:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d8b:	48 8b 15 46 8e 01 00 	mov    0x18e46(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9d92:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d96:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9d9a:	48 85 ed             	test   %rbp,%rbp
    9d9d:	74 34                	je     9dd3 <f23+0x473>
    9d9f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9da6:	00 00 
    9da8:	31 db                	xor    %ebx,%ebx
    9daa:	e9 04 fd ff ff       	jmp    9ab3 <f23+0x153>
    9daf:	48 89 df             	mov    %rbx,%rdi
    9db2:	e8 99 b7 ff ff       	call   5550 <fwp_rc_forget_slot>
    9db7:	e9 48 fe ff ff       	jmp    9c04 <f23+0x2a4>
    9dbc:	48 89 ef             	mov    %rbp,%rdi
    9dbf:	e8 8c b7 ff ff       	call   5550 <fwp_rc_forget_slot>
    9dc4:	e9 1e fd ff ff       	jmp    9ae7 <f23+0x187>
    9dc9:	e8 62 b6 ff ff       	call   5430 <fwp_rc_wide_dup>
    9dce:	e9 0a ff ff ff       	jmp    9cdd <f23+0x37d>
    9dd3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9dda:	00 00 
    9ddc:	e9 6c fd ff ff       	jmp    9b4d <f23+0x1ed>
    9de1:	e8 4a b6 ff ff       	call   5430 <fwp_rc_wide_dup>
    9de6:	e9 1b fc ff ff       	jmp    9a06 <f23+0xa6>
    9deb:	e8 70 96 ff ff       	call   3460 <__stack_chk_fail@plt>
    9df0:	48 8d 3d b3 33 00 00 	lea    0x33b3(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    9df7:	e8 f4 a5 ff ff       	call   43f0 <fwp_trap>
    9dfc:	e8 2f b6 ff ff       	call   5430 <fwp_rc_wide_dup>
    9e01:	e9 4a ff ff ff       	jmp    9d50 <f23+0x3f0>
    9e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e0d:	00 00 00 

0000000000009e10 <fwp_owned_entry23>:
    9e10:	f3 0f 1e fa          	endbr64
    9e14:	48 8b 3f             	mov    (%rdi),%rdi
    9e17:	e9 44 fb ff ff       	jmp    9960 <f23>
    9e1c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009e20 <e23>:
    9e20:	f3 0f 1e fa          	endbr64
    9e24:	53                   	push   %rbx
    9e25:	48 8b 1f             	mov    (%rdi),%rbx
    9e28:	48 89 df             	mov    %rbx,%rdi
    9e2b:	e8 30 ca ff ff       	call   6860 <fwp_rc_share>
    9e30:	48 89 df             	mov    %rbx,%rdi
    9e33:	e8 28 fb ff ff       	call   9960 <f23>
    9e38:	48 89 c3             	mov    %rax,%rbx
    9e3b:	48 89 c7             	mov    %rax,%rdi
    9e3e:	e8 1d ca ff ff       	call   6860 <fwp_rc_share>
    9e43:	48 89 d8             	mov    %rbx,%rax
    9e46:	5b                   	pop    %rbx
    9e47:	c3                   	ret
    9e48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e4f:	00 

0000000000009e50 <fwp_write>:
    9e50:	41 57                	push   %r15
    9e52:	41 56                	push   %r14
    9e54:	41 55                	push   %r13
    9e56:	41 54                	push   %r12
    9e58:	55                   	push   %rbp
    9e59:	53                   	push   %rbx
    9e5a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9e61:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9e68:	00 00 
    9e6a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9e71:	00 
    9e72:	49 89 d4             	mov    %rdx,%r12
    9e75:	8b 12                	mov    (%rdx),%edx
    9e77:	83 fa 19             	cmp    $0x19,%edx
    9e7a:	77 6a                	ja     9ee6 <fwp_write+0x96>
    9e7c:	48 89 f5             	mov    %rsi,%rbp
    9e7f:	89 d0                	mov    %edx,%eax
    9e81:	89 ce                	mov    %ecx,%esi
    9e83:	48 89 fb             	mov    %rdi,%rbx
    9e86:	48 8d 0d 73 3c 00 00 	lea    0x3c73(%rip),%rcx        # db00 <_IO_stdin_used+0xb00>
    9e8d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9e91:	48 01 c8             	add    %rcx,%rax
    9e94:	3e ff e0             	notrack jmp *%rax
    9e97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9e9e:	00 00 
    9ea0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9ea4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9ea8:	48 89 ca             	mov    %rcx,%rdx
    9eab:	48 85 c9             	test   %rcx,%rcx
    9eae:	0f 88 9c 0c 00 00    	js     ab50 <fwp_write+0xd00>
    9eb4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ebb:	00 
    9ebc:	48 89 c6             	mov    %rax,%rsi
    9ebf:	4c 89 e7             	mov    %r12,%rdi
    9ec2:	e8 79 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9ec7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ece:	00 00 
    9ed0:	4c 89 e7             	mov    %r12,%rdi
    9ed3:	e8 78 95 ff ff       	call   3450 <strlen@plt>
    9ed8:	4c 89 e6             	mov    %r12,%rsi
    9edb:	48 89 df             	mov    %rbx,%rdi
    9ede:	48 89 c2             	mov    %rax,%rdx
    9ee1:	e8 2a a3 ff ff       	call   4210 <buf_put>
    9ee6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9eed:	00 
    9eee:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9ef5:	00 00 
    9ef7:	0f 85 28 04 00 00    	jne    a325 <fwp_write+0x4d5>
    9efd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f04:	5b                   	pop    %rbx
    9f05:	5d                   	pop    %rbp
    9f06:	41 5c                	pop    %r12
    9f08:	41 5d                	pop    %r13
    9f0a:	41 5e                	pop    %r14
    9f0c:	41 5f                	pop    %r15
    9f0e:	c3                   	ret
    9f0f:	90                   	nop
    9f10:	49 89 e9             	mov    %rbp,%r9
    9f13:	4c 8d 05 5b 31 00 00 	lea    0x315b(%rip),%r8        # d075 <_IO_stdin_used+0x75>
    9f1a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9f1f:	ba 02 00 00 00       	mov    $0x2,%edx
    9f24:	be 00 02 00 00       	mov    $0x200,%esi
    9f29:	31 c0                	xor    %eax,%eax
    9f2b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f32:	00 
    9f33:	e8 78 94 ff ff       	call   33b0 <__snprintf_chk@plt>
    9f38:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f3f:	00 
    9f40:	e8 0b 95 ff ff       	call   3450 <strlen@plt>
    9f45:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9f4c:	00 
    9f4d:	48 89 df             	mov    %rbx,%rdi
    9f50:	48 89 c2             	mov    %rax,%rdx
    9f53:	e8 b8 a2 ff ff       	call   4210 <buf_put>
    9f58:	eb 8c                	jmp    9ee6 <fwp_write+0x96>
    9f5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9f60:	49 89 e9             	mov    %rbp,%r9
    9f63:	4c 8d 05 75 32 00 00 	lea    0x3275(%rip),%r8        # d1df <_IO_stdin_used+0x1df>
    9f6a:	eb ae                	jmp    9f1a <fwp_write+0xca>
    9f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    9f70:	83 fa 13             	cmp    $0x13,%edx
    9f73:	48 8d 05 5b 32 00 00 	lea    0x325b(%rip),%rax        # d1d5 <_IO_stdin_used+0x1d5>
    9f7a:	48 8d 35 59 32 00 00 	lea    0x3259(%rip),%rsi        # d1da <_IO_stdin_used+0x1da>
    9f81:	ba 04 00 00 00       	mov    $0x4,%edx
    9f86:	48 0f 44 f0          	cmove  %rax,%rsi
    9f8a:	45 31 ed             	xor    %r13d,%r13d
    9f8d:	e8 7e a2 ff ff       	call   4210 <buf_put>
    9f92:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9f97:	0f 84 a3 08 00 00    	je     a840 <fwp_write+0x9f0>
    9f9d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9fa2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9fa7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fac:	48 89 df             	mov    %rbx,%rdi
    9faf:	49 0f 44 c5          	cmove  %r13,%rax
    9fb3:	31 c9                	xor    %ecx,%ecx
    9fb5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9fba:	e8 91 fe ff ff       	call   9e50 <fwp_write>
    9fbf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    9fc4:	0f 84 6e 09 00 00    	je     a938 <fwp_write+0xae8>
    9fca:	49 83 c5 01          	add    $0x1,%r13
    9fce:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    9fd2:	0f 83 68 08 00 00    	jae    a840 <fwp_write+0x9f0>
    9fd8:	ba 02 00 00 00       	mov    $0x2,%edx
    9fdd:	48 8d 35 3b 32 00 00 	lea    0x323b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    9fe4:	48 89 df             	mov    %rbx,%rdi
    9fe7:	e8 24 a2 ff ff       	call   4210 <buf_put>
    9fec:	eb af                	jmp    9f9d <fwp_write+0x14d>
    9fee:	66 90                	xchg   %ax,%ax
    9ff0:	ba 06 00 00 00       	mov    $0x6,%edx
    9ff5:	48 8d 35 fc 31 00 00 	lea    0x31fc(%rip),%rsi        # d1f8 <_IO_stdin_used+0x1f8>
    9ffc:	48 83 c5 10          	add    $0x10,%rbp
    a000:	e8 0b a2 ff ff       	call   4210 <buf_put>
    a005:	48 89 ef             	mov    %rbp,%rdi
    a008:	e8 43 94 ff ff       	call   3450 <strlen@plt>
    a00d:	48 89 ee             	mov    %rbp,%rsi
    a010:	48 89 df             	mov    %rbx,%rdi
    a013:	48 89 c2             	mov    %rax,%rdx
    a016:	e8 f5 a1 ff ff       	call   4210 <buf_put>
    a01b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a020:	ba 01 00 00 00       	mov    $0x1,%edx
    a025:	48 89 df             	mov    %rbx,%rdi
    a028:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a02d:	e8 de a1 ff ff       	call   4210 <buf_put>
    a032:	e9 af fe ff ff       	jmp    9ee6 <fwp_write+0x96>
    a037:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a03e:	00 00 
    a040:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a047:	00 
    a048:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a04f:	00 00 
    a051:	0f 85 ce 02 00 00    	jne    a325 <fwp_write+0x4d5>
    a057:	ba 0a 00 00 00       	mov    $0xa,%edx
    a05c:	48 8d 35 81 31 00 00 	lea    0x3181(%rip),%rsi        # d1e4 <_IO_stdin_used+0x1e4>
    a063:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a06a:	48 89 df             	mov    %rbx,%rdi
    a06d:	5b                   	pop    %rbx
    a06e:	5d                   	pop    %rbp
    a06f:	41 5c                	pop    %r12
    a071:	41 5d                	pop    %r13
    a073:	41 5e                	pop    %r14
    a075:	41 5f                	pop    %r15
    a077:	e9 94 a1 ff ff       	jmp    4210 <buf_put>
    a07c:	0f 1f 40 00          	nopl   0x0(%rax)
    a080:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a085:	4d 85 ed             	test   %r13,%r13
    a088:	0f 84 02 0c 00 00    	je     ac90 <fwp_write+0xe40>
    a08e:	48 8d 35 97 31 00 00 	lea    0x3197(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    a095:	4c 89 ef             	mov    %r13,%rdi
    a098:	e8 93 94 ff ff       	call   3530 <strcmp@plt>
    a09d:	41 89 c1             	mov    %eax,%r9d
    a0a0:	85 c0                	test   %eax,%eax
    a0a2:	0f 84 6c 0c 00 00    	je     ad14 <fwp_write+0xec4>
    a0a8:	4c 89 ef             	mov    %r13,%rdi
    a0ab:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a0b0:	e8 9b 93 ff ff       	call   3450 <strlen@plt>
    a0b5:	4c 89 ee             	mov    %r13,%rsi
    a0b8:	48 89 df             	mov    %rbx,%rdi
    a0bb:	48 89 c2             	mov    %rax,%rdx
    a0be:	e8 4d a1 ff ff       	call   4210 <buf_put>
    a0c3:	ba 01 00 00 00       	mov    $0x1,%edx
    a0c8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a0cd:	48 89 df             	mov    %rbx,%rdi
    a0d0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a0d5:	e8 36 a1 ff ff       	call   4210 <buf_put>
    a0da:	ba 01 00 00 00       	mov    $0x1,%edx
    a0df:	4c 89 fe             	mov    %r15,%rsi
    a0e2:	48 89 df             	mov    %rbx,%rdi
    a0e5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a0ea:	e8 21 a1 ff ff       	call   4210 <buf_put>
    a0ef:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a0f4:	45 31 f6             	xor    %r14d,%r14d
    a0f7:	85 d2                	test   %edx,%edx
    a0f9:	0f 8e 81 0a 00 00    	jle    ab80 <fwp_write+0xd30>
    a0ff:	45 31 ed             	xor    %r13d,%r13d
    a102:	4d 85 ed             	test   %r13,%r13
    a105:	0f 85 75 07 00 00    	jne    a880 <fwp_write+0xa30>
    a10b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a112:	00 
    a113:	45 85 f6             	test   %r14d,%r14d
    a116:	0f 84 84 07 00 00    	je     a8a0 <fwp_write+0xa50>
    a11c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a121:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a126:	48 89 df             	mov    %rbx,%rdi
    a129:	49 83 c5 01          	add    $0x1,%r13
    a12d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a131:	31 c9                	xor    %ecx,%ecx
    a133:	e8 18 fd ff ff       	call   9e50 <fwp_write>
    a138:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a13d:	7f c3                	jg     a102 <fwp_write+0x2b2>
    a13f:	45 85 f6             	test   %r14d,%r14d
    a142:	0f 84 38 0a 00 00    	je     ab80 <fwp_write+0xd30>
    a148:	b8 29 00 00 00       	mov    $0x29,%eax
    a14d:	ba 01 00 00 00       	mov    $0x1,%edx
    a152:	4c 89 fe             	mov    %r15,%rsi
    a155:	48 89 df             	mov    %rbx,%rdi
    a158:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a15c:	e8 af a0 ff ff       	call   4210 <buf_put>
    a161:	e9 80 fd ff ff       	jmp    9ee6 <fwp_write+0x96>
    a166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a16d:	00 00 00 
    a170:	ba 01 00 00 00       	mov    $0x1,%edx
    a175:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a17a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a17f:	e8 8c a0 ff ff       	call   4210 <buf_put>
    a184:	48 85 ed             	test   %rbp,%rbp
    a187:	0f 84 93 06 00 00    	je     a820 <fwp_write+0x9d0>
    a18d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a191:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a196:	31 c9                	xor    %ecx,%ecx
    a198:	48 89 df             	mov    %rbx,%rdi
    a19b:	e8 b0 fc ff ff       	call   9e50 <fwp_write>
    a1a0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a1a4:	48 85 ed             	test   %rbp,%rbp
    a1a7:	0f 84 73 06 00 00    	je     a820 <fwp_write+0x9d0>
    a1ad:	ba 02 00 00 00       	mov    $0x2,%edx
    a1b2:	48 8d 35 66 30 00 00 	lea    0x3066(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a1b9:	48 89 df             	mov    %rbx,%rdi
    a1bc:	e8 4f a0 ff ff       	call   4210 <buf_put>
    a1c1:	eb ca                	jmp    a18d <fwp_write+0x33d>
    a1c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a1c8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a1cc:	85 f6                	test   %esi,%esi
    a1ce:	0f 84 fc 07 00 00    	je     a9d0 <fwp_write+0xb80>
    a1d4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a1db:	00 
    a1dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a1e3:	00 00 
    a1e5:	0f 85 3a 01 00 00    	jne    a325 <fwp_write+0x4d5>
    a1eb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a1ef:	4c 89 ea             	mov    %r13,%rdx
    a1f2:	e9 6c fe ff ff       	jmp    a063 <fwp_write+0x213>
    a1f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1fe:	00 00 
    a200:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a205:	ba 01 00 00 00       	mov    $0x1,%edx
    a20a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a20f:	48 89 ee             	mov    %rbp,%rsi
    a212:	e8 f9 9f ff ff       	call   4210 <buf_put>
    a217:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a21c:	4c 89 e7             	mov    %r12,%rdi
    a21f:	e8 2c 92 ff ff       	call   3450 <strlen@plt>
    a224:	4c 89 e6             	mov    %r12,%rsi
    a227:	48 89 df             	mov    %rbx,%rdi
    a22a:	48 89 c2             	mov    %rax,%rdx
    a22d:	e8 de 9f ff ff       	call   4210 <buf_put>
    a232:	ba 01 00 00 00       	mov    $0x1,%edx
    a237:	48 89 ee             	mov    %rbp,%rsi
    a23a:	48 89 df             	mov    %rbx,%rdi
    a23d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a242:	e8 c9 9f ff ff       	call   4210 <buf_put>
    a247:	e9 9a fc ff ff       	jmp    9ee6 <fwp_write+0x96>
    a24c:	0f 1f 40 00          	nopl   0x0(%rax)
    a250:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a255:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a259:	0f 8a 8e 0b 00 00    	jp     aded <fwp_write+0xf9d>
    a25f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a263:	66 0f 54 05 95 39 00 	andpd  0x3995(%rip),%xmm0        # dc00 <msg.4+0x90>
    a26a:	00 
    a26b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a270:	66 0f 2e 05 c8 39 00 	ucomisd 0x39c8(%rip),%xmm0        # dc40 <msg.4+0xd0>
    a277:	00 
    a278:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a27f:	00 
    a280:	0f 87 b2 09 00 00    	ja     ac38 <fwp_write+0xde8>
    a286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a28d:	00 00 00 
    a290:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a294:	89 ee                	mov    %ebp,%esi
    a296:	4c 89 e7             	mov    %r12,%rdi
    a299:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a29e:	e8 6d a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2a3:	31 f6                	xor    %esi,%esi
    a2a5:	4c 89 e7             	mov    %r12,%rdi
    a2a8:	e8 63 91 ff ff       	call   3410 <strtod@plt>
    a2ad:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a2b2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a2b6:	7a 06                	jp     a2be <fwp_write+0x46e>
    a2b8:	0f 84 e9 01 00 00    	je     a4a7 <fwp_write+0x657>
    a2be:	83 c5 01             	add    $0x1,%ebp
    a2c1:	83 fd 12             	cmp    $0x12,%ebp
    a2c4:	75 ca                	jne    a290 <fwp_write+0x440>
    a2c6:	be 11 00 00 00       	mov    $0x11,%esi
    a2cb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a2cf:	4c 89 e7             	mov    %r12,%rdi
    a2d2:	e8 39 a4 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a2d7:	e9 cb 01 00 00       	jmp    a4a7 <fwp_write+0x657>
    a2dc:	0f 1f 40 00          	nopl   0x0(%rax)
    a2e0:	48 83 fd 01          	cmp    $0x1,%rbp
    a2e4:	0f 84 e6 08 00 00    	je     abd0 <fwp_write+0xd80>
    a2ea:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a2ee:	b8 02 00 00 00       	mov    $0x2,%eax
    a2f3:	ba 01 00 00 00       	mov    $0x1,%edx
    a2f8:	48 0f 44 d0          	cmove  %rax,%rdx
    a2fc:	48 8d 35 ca 2e 00 00 	lea    0x2eca(%rip),%rsi        # d1cd <_IO_stdin_used+0x1cd>
    a303:	48 8d 05 c8 2e 00 00 	lea    0x2ec8(%rip),%rax        # d1d2 <_IO_stdin_used+0x1d2>
    a30a:	48 0f 44 f0          	cmove  %rax,%rsi
    a30e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a315:	00 
    a316:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a31d:	00 00 
    a31f:	0f 84 3e fd ff ff    	je     a063 <fwp_write+0x213>
    a325:	e8 36 91 ff ff       	call   3460 <__stack_chk_fail@plt>
    a32a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a330:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a335:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a33a:	e8 11 9e ff ff       	call   4150 <buf_grow>
    a33f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a343:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a349:	4c 03 0b             	add    (%rbx),%r9
    a34c:	66 45 89 11          	mov    %r10w,(%r9)
    a350:	45 85 e4             	test   %r12d,%r12d
    a353:	0f 8e 07 05 00 00    	jle    a860 <fwp_write+0xa10>
    a359:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a360:	55 55 55 
    a363:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a368:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a36f:	aa aa aa 
    a372:	49 83 c1 01          	add    $0x1,%r9
    a376:	eb 45                	jmp    a3bd <fwp_write+0x56d>
    a378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a37f:	00 
    a380:	be 01 00 00 00       	mov    $0x1,%esi
    a385:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a38a:	88 07                	mov    %al,(%rdi)
    a38c:	48 89 e8             	mov    %rbp,%rax
    a38f:	49 f7 e8             	imul   %r8
    a392:	48 89 e8             	mov    %rbp,%rax
    a395:	48 c1 f8 3f          	sar    $0x3f,%rax
    a399:	48 29 c2             	sub    %rax,%rdx
    a39c:	48 85 c9             	test   %rcx,%rcx
    a39f:	0f 95 c0             	setne  %al
    a3a2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a3a6:	48 83 ef 01          	sub    $0x1,%rdi
    a3aa:	48 21 c5             	and    %rax,%rbp
    a3ad:	48 29 ea             	sub    %rbp,%rdx
    a3b0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a3b4:	49 39 f9             	cmp    %rdi,%r9
    a3b7:	0f 84 a3 04 00 00    	je     a860 <fwp_write+0xa10>
    a3bd:	48 89 e8             	mov    %rbp,%rax
    a3c0:	49 f7 e8             	imul   %r8
    a3c3:	48 89 e8             	mov    %rbp,%rax
    a3c6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a3ca:	48 89 d1             	mov    %rdx,%rcx
    a3cd:	48 29 c1             	sub    %rax,%rcx
    a3d0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a3d4:	48 89 e9             	mov    %rbp,%rcx
    a3d7:	48 29 c1             	sub    %rax,%rcx
    a3da:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a3de:	49 f7 e2             	mul    %r10
    a3e1:	b8 30 00 00 00       	mov    $0x30,%eax
    a3e6:	48 89 d6             	mov    %rdx,%rsi
    a3e9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a3ed:	48 d1 ee             	shr    $1,%rsi
    a3f0:	48 01 f2             	add    %rsi,%rdx
    a3f3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a3f7:	48 29 d6             	sub    %rdx,%rsi
    a3fa:	74 8e                	je     a38a <fwp_write+0x53a>
    a3fc:	48 83 fe 01          	cmp    $0x1,%rsi
    a400:	0f 85 7a ff ff ff    	jne    a380 <fwp_write+0x530>
    a406:	31 f6                	xor    %esi,%esi
    a408:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a40d:	e9 78 ff ff ff       	jmp    a38a <fwp_write+0x53a>
    a412:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a418:	66 0f 6e cd          	movd   %ebp,%xmm1
    a41c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a41f:	0f 8a c8 09 00 00    	jp     aded <fwp_write+0xf9d>
    a425:	0f 28 c1             	movaps %xmm1,%xmm0
    a428:	0f 54 05 c1 37 00 00 	andps  0x37c1(%rip),%xmm0        # dbf0 <msg.4+0x80>
    a42f:	0f 2e 05 ce 2b 00 00 	ucomiss 0x2bce(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a436:	0f 87 24 08 00 00    	ja     ac60 <fwp_write+0xe10>
    a43c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a440:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a446:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a44d:	00 
    a44e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a452:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a45e:	00 00 
    a460:	44 89 ee             	mov    %r13d,%esi
    a463:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a468:	4c 89 e7             	mov    %r12,%rdi
    a46b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a470:	e8 9b a2 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a475:	31 f6                	xor    %esi,%esi
    a477:	4c 89 e7             	mov    %r12,%rdi
    a47a:	e8 31 90 ff ff       	call   34b0 <strtof@plt>
    a47f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a484:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a487:	7a 02                	jp     a48b <fwp_write+0x63b>
    a489:	74 1c                	je     a4a7 <fwp_write+0x657>
    a48b:	41 83 c5 01          	add    $0x1,%r13d
    a48f:	41 83 fd 0a          	cmp    $0xa,%r13d
    a493:	75 cb                	jne    a460 <fwp_write+0x610>
    a495:	be 09 00 00 00       	mov    $0x9,%esi
    a49a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a49f:	4c 89 e7             	mov    %r12,%rdi
    a4a2:	e8 69 a2 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a4a7:	4c 89 e7             	mov    %r12,%rdi
    a4aa:	e8 d1 9e ff ff       	call   4380 <fwp_finish_float>
    a4af:	e9 1c fa ff ff       	jmp    9ed0 <fwp_write+0x80>
    a4b4:	0f 1f 40 00          	nopl   0x0(%rax)
    a4b8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a4bc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a4c0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a4c7:	00 
    a4c8:	48 89 ef             	mov    %rbp,%rdi
    a4cb:	e8 70 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a4d0:	48 89 ef             	mov    %rbp,%rdi
    a4d3:	e8 78 8f ff ff       	call   3450 <strlen@plt>
    a4d8:	48 89 ee             	mov    %rbp,%rsi
    a4db:	48 89 df             	mov    %rbx,%rdi
    a4de:	48 89 c2             	mov    %rax,%rdx
    a4e1:	e8 2a 9d ff ff       	call   4210 <buf_put>
    a4e6:	e9 fb f9 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4f0:	ba 06 00 00 00       	mov    $0x6,%edx
    a4f5:	48 8d 35 26 2d 00 00 	lea    0x2d26(%rip),%rsi        # d222 <_IO_stdin_used+0x222>
    a4fc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a502:	e8 09 9d ff ff       	call   4210 <buf_put>
    a507:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a50e:	ff ff 7f 
    a511:	48 23 55 00          	and    0x0(%rbp),%rdx
    a515:	0f 84 86 02 00 00    	je     a7a1 <fwp_write+0x951>
    a51b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a520:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a524:	48 85 d2             	test   %rdx,%rdx
    a527:	0f 84 ae 00 00 00    	je     a5db <fwp_write+0x78b>
    a52d:	8b 0a                	mov    (%rdx),%ecx
    a52f:	83 f9 1c             	cmp    $0x1c,%ecx
    a532:	0f 84 58 06 00 00    	je     ab90 <fwp_write+0xd40>
    a538:	83 f9 1b             	cmp    $0x1b,%ecx
    a53b:	0f 87 9a 00 00 00    	ja     a5db <fwp_write+0x78b>
    a541:	be 01 00 00 00       	mov    $0x1,%esi
    a546:	48 d3 e6             	shl    %cl,%rsi
    a549:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a54f:	0f 85 4b 04 00 00    	jne    a9a0 <fwp_write+0xb50>
    a555:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a55b:	0f 85 0f 04 00 00    	jne    a970 <fwp_write+0xb20>
    a561:	83 e6 21             	and    $0x21,%esi
    a564:	74 75                	je     a5db <fwp_write+0x78b>
    a566:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a56b:	48 85 ff             	test   %rdi,%rdi
    a56e:	79 07                	jns    a577 <fwp_write+0x727>
    a570:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a574:	4c 01 ee             	add    %r13,%rsi
    a577:	48 0f be 3e          	movsbq (%rsi),%rdi
    a57b:	85 c9                	test   %ecx,%ecx
    a57d:	40 0f b6 f7          	movzbl %dil,%esi
    a581:	48 0f 44 f7          	cmove  %rdi,%rsi
    a585:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a58c:	00 00 00 00 
    a590:	31 c9                	xor    %ecx,%ecx
    a592:	48 89 df             	mov    %rbx,%rdi
    a595:	49 83 c5 01          	add    $0x1,%r13
    a599:	e8 b2 f8 ff ff       	call   9e50 <fwp_write>
    a59e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a5a5:	ff ff 7f 
    a5a8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a5ac:	49 39 d5             	cmp    %rdx,%r13
    a5af:	0f 83 ec 01 00 00    	jae    a7a1 <fwp_write+0x951>
    a5b5:	ba 02 00 00 00       	mov    $0x2,%edx
    a5ba:	48 89 df             	mov    %rbx,%rdi
    a5bd:	48 8d 35 5b 2c 00 00 	lea    0x2c5b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a5c4:	e8 47 9c ff ff       	call   4210 <buf_put>
    a5c9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a5ce:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a5d2:	48 85 d2             	test   %rdx,%rdx
    a5d5:	0f 85 52 ff ff ff    	jne    a52d <fwp_write+0x6dd>
    a5db:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a5e0:	48 85 ff             	test   %rdi,%rdi
    a5e3:	0f 88 cf 05 00 00    	js     abb8 <fwp_write+0xd68>
    a5e9:	48 8b 31             	mov    (%rcx),%rsi
    a5ec:	eb a2                	jmp    a590 <fwp_write+0x740>
    a5ee:	66 90                	xchg   %ax,%ax
    a5f0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a5f7:	00 
    a5f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a5ff:	00 00 
    a601:	0f 85 1e fd ff ff    	jne    a325 <fwp_write+0x4d5>
    a607:	ba 08 00 00 00       	mov    $0x8,%edx
    a60c:	48 8d 35 dc 2b 00 00 	lea    0x2bdc(%rip),%rsi        # d1ef <_IO_stdin_used+0x1ef>
    a613:	e9 4b fa ff ff       	jmp    a063 <fwp_write+0x213>
    a618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a61f:	00 
    a620:	89 e8                	mov    %ebp,%eax
    a622:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a629:	76 03                	jbe    a62e <fwp_write+0x7de>
    a62b:	8b 45 00             	mov    0x0(%rbp),%eax
    a62e:	41 89 c6             	mov    %eax,%r14d
    a631:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a636:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a63b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a63f:	4c 89 ef             	mov    %r13,%rdi
    a642:	e8 09 8e ff ff       	call   3450 <strlen@plt>
    a647:	4c 89 ee             	mov    %r13,%rsi
    a64a:	48 89 df             	mov    %rbx,%rdi
    a64d:	48 89 c2             	mov    %rax,%rdx
    a650:	e8 bb 9b ff ff       	call   4210 <buf_put>
    a655:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a65a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a65e:	85 f6                	test   %esi,%esi
    a660:	0f 8e 80 f8 ff ff    	jle    9ee6 <fwp_write+0x96>
    a666:	45 31 ed             	xor    %r13d,%r13d
    a669:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a66e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a673:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a678:	ba 01 00 00 00       	mov    $0x1,%edx
    a67d:	4c 89 fe             	mov    %r15,%rsi
    a680:	48 89 04 24          	mov    %rax,(%rsp)
    a684:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a689:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a68d:	48 89 df             	mov    %rbx,%rdi
    a690:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a694:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a699:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a69e:	e8 6d 9b ff ff       	call   4210 <buf_put>
    a6a3:	41 8b 06             	mov    (%r14),%eax
    a6a6:	83 f8 0e             	cmp    $0xe,%eax
    a6a9:	0f 84 71 02 00 00    	je     a920 <fwp_write+0xad0>
    a6af:	83 f8 10             	cmp    $0x10,%eax
    a6b2:	0f 84 38 02 00 00    	je     a8f0 <fwp_write+0xaa0>
    a6b8:	83 f8 0a             	cmp    $0xa,%eax
    a6bb:	0f 84 7f 04 00 00    	je     ab40 <fwp_write+0xcf0>
    a6c1:	0f 8f f9 00 00 00    	jg     a7c0 <fwp_write+0x970>
    a6c7:	83 f8 03             	cmp    $0x3,%eax
    a6ca:	0f 8f 50 04 00 00    	jg     ab20 <fwp_write+0xcd0>
    a6d0:	85 c0                	test   %eax,%eax
    a6d2:	78 10                	js     a6e4 <fwp_write+0x894>
    a6d4:	48 8b 04 24          	mov    (%rsp),%rax
    a6d8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a6dc:	85 c0                	test   %eax,%eax
    a6de:	0f 85 f9 00 00 00    	jne    a7dd <fwp_write+0x98d>
    a6e4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a6e9:	48 8b 34 24          	mov    (%rsp),%rsi
    a6ed:	31 c9                	xor    %ecx,%ecx
    a6ef:	48 89 df             	mov    %rbx,%rdi
    a6f2:	e8 59 f7 ff ff       	call   9e50 <fwp_write>
    a6f7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a6fc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a701:	49 83 c5 01          	add    $0x1,%r13
    a705:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a709:	0f 8f 5f ff ff ff    	jg     a66e <fwp_write+0x81e>
    a70f:	e9 d2 f7 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a714:	0f 1f 40 00          	nopl   0x0(%rax)
    a718:	ba 06 00 00 00       	mov    $0x6,%edx
    a71d:	48 8d 35 f1 2a 00 00 	lea    0x2af1(%rip),%rsi        # d215 <_IO_stdin_used+0x215>
    a724:	45 31 ed             	xor    %r13d,%r13d
    a727:	e8 e4 9a ff ff       	call   4210 <buf_put>
    a72c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a731:	75 19                	jne    a74c <fwp_write+0x8fc>
    a733:	eb 6c                	jmp    a7a1 <fwp_write+0x951>
    a735:	0f 1f 00             	nopl   (%rax)
    a738:	ba 02 00 00 00       	mov    $0x2,%edx
    a73d:	48 8d 35 db 2a 00 00 	lea    0x2adb(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a744:	48 89 df             	mov    %rbx,%rdi
    a747:	e8 c4 9a ff ff       	call   4210 <buf_put>
    a74c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a752:	b9 00 02 00 00       	mov    $0x200,%ecx
    a757:	31 c0                	xor    %eax,%eax
    a759:	49 83 c5 01          	add    $0x1,%r13
    a75d:	4c 8d 05 b8 2a 00 00 	lea    0x2ab8(%rip),%r8        # d21c <_IO_stdin_used+0x21c>
    a764:	ba 02 00 00 00       	mov    $0x2,%edx
    a769:	be 00 02 00 00       	mov    $0x200,%esi
    a76e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a775:	00 
    a776:	e8 35 8c ff ff       	call   33b0 <__snprintf_chk@plt>
    a77b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a782:	00 
    a783:	e8 c8 8c ff ff       	call   3450 <strlen@plt>
    a788:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a78f:	00 
    a790:	48 89 df             	mov    %rbx,%rdi
    a793:	48 89 c2             	mov    %rax,%rdx
    a796:	e8 75 9a ff ff       	call   4210 <buf_put>
    a79b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a79f:	72 97                	jb     a738 <fwp_write+0x8e8>
    a7a1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7a6:	ba 01 00 00 00       	mov    $0x1,%edx
    a7ab:	48 89 df             	mov    %rbx,%rdi
    a7ae:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a7b3:	e8 58 9a ff ff       	call   4210 <buf_put>
    a7b8:	e9 29 f7 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a7bd:	0f 1f 00             	nopl   (%rax)
    a7c0:	83 f8 0b             	cmp    $0xb,%eax
    a7c3:	0f 85 1b ff ff ff    	jne    a6e4 <fwp_write+0x894>
    a7c9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a7ce:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a7d2:	83 e0 01             	and    $0x1,%eax
    a7d5:	85 c0                	test   %eax,%eax
    a7d7:	0f 84 07 ff ff ff    	je     a6e4 <fwp_write+0x894>
    a7dd:	4c 89 fe             	mov    %r15,%rsi
    a7e0:	48 89 df             	mov    %rbx,%rdi
    a7e3:	ba 01 00 00 00       	mov    $0x1,%edx
    a7e8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a7ed:	e8 1e 9a ff ff       	call   4210 <buf_put>
    a7f2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a7f7:	48 8b 34 24          	mov    (%rsp),%rsi
    a7fb:	31 c9                	xor    %ecx,%ecx
    a7fd:	48 89 df             	mov    %rbx,%rdi
    a800:	e8 4b f6 ff ff       	call   9e50 <fwp_write>
    a805:	ba 01 00 00 00       	mov    $0x1,%edx
    a80a:	4c 89 fe             	mov    %r15,%rsi
    a80d:	48 89 df             	mov    %rbx,%rdi
    a810:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a815:	e8 f6 99 ff ff       	call   4210 <buf_put>
    a81a:	e9 d8 fe ff ff       	jmp    a6f7 <fwp_write+0x8a7>
    a81f:	90                   	nop
    a820:	ba 01 00 00 00       	mov    $0x1,%edx
    a825:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a82a:	48 89 df             	mov    %rbx,%rdi
    a82d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a832:	e8 d9 99 ff ff       	call   4210 <buf_put>
    a837:	e9 aa f6 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a83c:	0f 1f 40 00          	nopl   0x0(%rax)
    a840:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a845:	ba 01 00 00 00       	mov    $0x1,%edx
    a84a:	48 89 df             	mov    %rbx,%rdi
    a84d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a852:	e8 b9 99 ff ff       	call   4210 <buf_put>
    a857:	e9 8a f6 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a85c:	0f 1f 40 00          	nopl   0x0(%rax)
    a860:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a864:	48 8b 13             	mov    (%rbx),%rdx
    a867:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a86c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a870:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a874:	e9 6d f6 ff ff       	jmp    9ee6 <fwp_write+0x96>
    a879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a880:	ba 02 00 00 00       	mov    $0x2,%edx
    a885:	48 8d 35 93 29 00 00 	lea    0x2993(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a88c:	48 89 df             	mov    %rbx,%rdi
    a88f:	e8 7c 99 ff ff       	call   4210 <buf_put>
    a894:	e9 72 f8 ff ff       	jmp    a10b <fwp_write+0x2bb>
    a899:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8a0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a8a5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a8aa:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a8ae:	48 89 f7             	mov    %rsi,%rdi
    a8b1:	48 89 34 24          	mov    %rsi,(%rsp)
    a8b5:	e8 96 8b ff ff       	call   3450 <strlen@plt>
    a8ba:	48 8b 34 24          	mov    (%rsp),%rsi
    a8be:	48 89 df             	mov    %rbx,%rdi
    a8c1:	48 89 c2             	mov    %rax,%rdx
    a8c4:	e8 47 99 ff ff       	call   4210 <buf_put>
    a8c9:	ba 03 00 00 00       	mov    $0x3,%edx
    a8ce:	48 8d 35 6d 29 00 00 	lea    0x296d(%rip),%rsi        # d242 <_IO_stdin_used+0x242>
    a8d5:	48 89 df             	mov    %rbx,%rdi
    a8d8:	e8 33 99 ff ff       	call   4210 <buf_put>
    a8dd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a8e2:	e9 35 f8 ff ff       	jmp    a11c <fwp_write+0x2cc>
    a8e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a8ee:	00 00 
    a8f0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a8f5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a8f9:	48 85 ff             	test   %rdi,%rdi
    a8fc:	0f 84 e2 fd ff ff    	je     a6e4 <fwp_write+0x894>
    a902:	48 8d 35 23 29 00 00 	lea    0x2923(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    a909:	e8 22 8c ff ff       	call   3530 <strcmp@plt>
    a90e:	85 c0                	test   %eax,%eax
    a910:	0f 95 c0             	setne  %al
    a913:	0f b6 c0             	movzbl %al,%eax
    a916:	e9 c1 fd ff ff       	jmp    a6dc <fwp_write+0x88c>
    a91b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a920:	31 c0                	xor    %eax,%eax
    a922:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a929:	00 
    a92a:	0f 97 c0             	seta   %al
    a92d:	e9 aa fd ff ff       	jmp    a6dc <fwp_write+0x88c>
    a932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a938:	48 89 df             	mov    %rbx,%rdi
    a93b:	ba 02 00 00 00       	mov    $0x2,%edx
    a940:	48 8d 35 e2 28 00 00 	lea    0x28e2(%rip),%rsi        # d229 <_IO_stdin_used+0x229>
    a947:	e8 c4 98 ff ff       	call   4210 <buf_put>
    a94c:	4c 89 e8             	mov    %r13,%rax
    a94f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a954:	31 c9                	xor    %ecx,%ecx
    a956:	48 c1 e0 04          	shl    $0x4,%rax
    a95a:	48 89 df             	mov    %rbx,%rdi
    a95d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a962:	e8 e9 f4 ff ff       	call   9e50 <fwp_write>
    a967:	e9 5e f6 ff ff       	jmp    9fca <fwp_write+0x17a>
    a96c:	0f 1f 40 00          	nopl   0x0(%rax)
    a970:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a975:	48 85 ff             	test   %rdi,%rdi
    a978:	79 0c                	jns    a986 <fwp_write+0xb36>
    a97a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a981:	00 
    a982:	48 03 75 10          	add    0x10(%rbp),%rsi
    a986:	48 63 3e             	movslq (%rsi),%rdi
    a989:	83 f9 02             	cmp    $0x2,%ecx
    a98c:	89 fe                	mov    %edi,%esi
    a98e:	48 0f 44 f7          	cmove  %rdi,%rsi
    a992:	e9 f9 fb ff ff       	jmp    a590 <fwp_write+0x740>
    a997:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a99e:	00 00 
    a9a0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a9a5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a9aa:	48 85 ff             	test   %rdi,%rdi
    a9ad:	0f 88 0f 03 00 00    	js     acc2 <fwp_write+0xe72>
    a9b3:	49 0f bf 38          	movswq (%r8),%rdi
    a9b7:	83 f9 01             	cmp    $0x1,%ecx
    a9ba:	0f b7 f7             	movzwl %di,%esi
    a9bd:	48 0f 44 f7          	cmove  %rdi,%rsi
    a9c1:	e9 ca fb ff ff       	jmp    a590 <fwp_write+0x740>
    a9c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9cd:	00 00 00 
    a9d0:	ba 01 00 00 00       	mov    $0x1,%edx
    a9d5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a9da:	48 83 c5 08          	add    $0x8,%rbp
    a9de:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    a9e3:	e8 28 98 ff ff       	call   4210 <buf_put>
    a9e8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a9ed:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    a9f2:	4d 85 ed             	test   %r13,%r13
    a9f5:	75 46                	jne    aa3d <fwp_write+0xbed>
    a9f7:	e9 04 01 00 00       	jmp    ab00 <fwp_write+0xcb0>
    a9fc:	0f 1f 40 00          	nopl   0x0(%rax)
    aa00:	41 80 f9 09          	cmp    $0x9,%r9b
    aa04:	0f 84 d6 00 00 00    	je     aae0 <fwp_write+0xc90>
    aa0a:	41 80 f9 0a          	cmp    $0xa,%r9b
    aa0e:	0f 85 9c 00 00 00    	jne    aab0 <fwp_write+0xc60>
    aa14:	ba 02 00 00 00       	mov    $0x2,%edx
    aa19:	48 8d 35 e5 27 00 00 	lea    0x27e5(%rip),%rsi        # d205 <_IO_stdin_used+0x205>
    aa20:	48 89 df             	mov    %rbx,%rdi
    aa23:	e8 e8 97 ff ff       	call   4210 <buf_put>
    aa28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa2f:	00 
    aa30:	48 83 c5 01          	add    $0x1,%rbp
    aa34:	49 39 ec             	cmp    %rbp,%r12
    aa37:	0f 84 c3 00 00 00    	je     ab00 <fwp_write+0xcb0>
    aa3d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    aa42:	41 80 f9 0d          	cmp    $0xd,%r9b
    aa46:	74 28                	je     aa70 <fwp_write+0xc20>
    aa48:	7e b6                	jle    aa00 <fwp_write+0xbb0>
    aa4a:	41 80 f9 22          	cmp    $0x22,%r9b
    aa4e:	74 40                	je     aa90 <fwp_write+0xc40>
    aa50:	41 80 f9 5c          	cmp    $0x5c,%r9b
    aa54:	75 5a                	jne    aab0 <fwp_write+0xc60>
    aa56:	ba 02 00 00 00       	mov    $0x2,%edx
    aa5b:	48 8d 35 a0 27 00 00 	lea    0x27a0(%rip),%rsi        # d202 <_IO_stdin_used+0x202>
    aa62:	48 89 df             	mov    %rbx,%rdi
    aa65:	e8 a6 97 ff ff       	call   4210 <buf_put>
    aa6a:	eb c4                	jmp    aa30 <fwp_write+0xbe0>
    aa6c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa70:	ba 02 00 00 00       	mov    $0x2,%edx
    aa75:	48 8d 35 8f 27 00 00 	lea    0x278f(%rip),%rsi        # d20b <_IO_stdin_used+0x20b>
    aa7c:	48 89 df             	mov    %rbx,%rdi
    aa7f:	e8 8c 97 ff ff       	call   4210 <buf_put>
    aa84:	eb aa                	jmp    aa30 <fwp_write+0xbe0>
    aa86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa8d:	00 00 00 
    aa90:	ba 02 00 00 00       	mov    $0x2,%edx
    aa95:	48 8d 35 63 27 00 00 	lea    0x2763(%rip),%rsi        # d1ff <_IO_stdin_used+0x1ff>
    aa9c:	48 89 df             	mov    %rbx,%rdi
    aa9f:	e8 6c 97 ff ff       	call   4210 <buf_put>
    aaa4:	eb 8a                	jmp    aa30 <fwp_write+0xbe0>
    aaa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aaad:	00 00 00 
    aab0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    aab4:	0f 86 2e 01 00 00    	jbe    abe8 <fwp_write+0xd98>
    aaba:	41 80 f9 7f          	cmp    $0x7f,%r9b
    aabe:	0f 84 24 01 00 00    	je     abe8 <fwp_write+0xd98>
    aac4:	ba 01 00 00 00       	mov    $0x1,%edx
    aac9:	4c 89 fe             	mov    %r15,%rsi
    aacc:	48 89 df             	mov    %rbx,%rdi
    aacf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    aad4:	e8 37 97 ff ff       	call   4210 <buf_put>
    aad9:	e9 52 ff ff ff       	jmp    aa30 <fwp_write+0xbe0>
    aade:	66 90                	xchg   %ax,%ax
    aae0:	ba 02 00 00 00       	mov    $0x2,%edx
    aae5:	48 8d 35 1c 27 00 00 	lea    0x271c(%rip),%rsi        # d208 <_IO_stdin_used+0x208>
    aaec:	48 89 df             	mov    %rbx,%rdi
    aaef:	e8 1c 97 ff ff       	call   4210 <buf_put>
    aaf4:	e9 37 ff ff ff       	jmp    aa30 <fwp_write+0xbe0>
    aaf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab00:	ba 01 00 00 00       	mov    $0x1,%edx
    ab05:	4c 89 fe             	mov    %r15,%rsi
    ab08:	48 89 df             	mov    %rbx,%rdi
    ab0b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ab10:	e8 fb 96 ff ff       	call   4210 <buf_put>
    ab15:	e9 cc f3 ff ff       	jmp    9ee6 <fwp_write+0x96>
    ab1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab20:	83 f8 04             	cmp    $0x4,%eax
    ab23:	0f 85 bb fb ff ff    	jne    a6e4 <fwp_write+0x894>
    ab29:	48 8b 04 24          	mov    (%rsp),%rax
    ab2d:	48 8b 40 08          	mov    0x8(%rax),%rax
    ab31:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ab36:	48 c1 e8 3f          	shr    $0x3f,%rax
    ab3a:	e9 96 fc ff ff       	jmp    a7d5 <fwp_write+0x985>
    ab3f:	90                   	nop
    ab40:	8b 0c 24             	mov    (%rsp),%ecx
    ab43:	31 c0                	xor    %eax,%eax
    ab45:	85 c9                	test   %ecx,%ecx
    ab47:	0f 98 c0             	sets   %al
    ab4a:	e9 86 fc ff ff       	jmp    a7d5 <fwp_write+0x985>
    ab4f:	90                   	nop
    ab50:	48 f7 d8             	neg    %rax
    ab53:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    ab5a:	00 
    ab5b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    ab62:	2d 
    ab63:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ab6a:	00 
    ab6b:	48 83 d2 00          	adc    $0x0,%rdx
    ab6f:	48 89 c6             	mov    %rax,%rsi
    ab72:	48 f7 da             	neg    %rdx
    ab75:	e8 c6 8e ff ff       	call   3a40 <fwp_fmt_u128>
    ab7a:	e9 51 f3 ff ff       	jmp    9ed0 <fwp_write+0x80>
    ab7f:	90                   	nop
    ab80:	b8 7d 00 00 00       	mov    $0x7d,%eax
    ab85:	e9 c3 f5 ff ff       	jmp    a14d <fwp_write+0x2fd>
    ab8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab90:	4c 89 e9             	mov    %r13,%rcx
    ab93:	48 c1 e1 04          	shl    $0x4,%rcx
    ab97:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    ab9c:	48 85 ff             	test   %rdi,%rdi
    ab9f:	0f 89 eb f9 ff ff    	jns    a590 <fwp_write+0x740>
    aba5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aba9:	48 89 ce             	mov    %rcx,%rsi
    abac:	e9 df f9 ff ff       	jmp    a590 <fwp_write+0x740>
    abb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abb8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    abbf:	00 
    abc0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    abc4:	e9 20 fa ff ff       	jmp    a5e9 <fwp_write+0x799>
    abc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abd0:	ba 02 00 00 00       	mov    $0x2,%edx
    abd5:	48 8d 35 f3 25 00 00 	lea    0x25f3(%rip),%rsi        # d1cf <_IO_stdin_used+0x1cf>
    abdc:	e9 2d f7 ff ff       	jmp    a30e <fwp_write+0x4be>
    abe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abe8:	4c 8d 05 1f 26 00 00 	lea    0x261f(%rip),%r8        # d20e <_IO_stdin_used+0x20e>
    abef:	b9 10 00 00 00       	mov    $0x10,%ecx
    abf4:	31 c0                	xor    %eax,%eax
    abf6:	ba 02 00 00 00       	mov    $0x2,%edx
    abfb:	be 10 00 00 00       	mov    $0x10,%esi
    ac00:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac07:	00 
    ac08:	e8 a3 87 ff ff       	call   33b0 <__snprintf_chk@plt>
    ac0d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac14:	00 
    ac15:	e8 36 88 ff ff       	call   3450 <strlen@plt>
    ac1a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ac21:	00 
    ac22:	48 89 df             	mov    %rbx,%rdi
    ac25:	48 89 c2             	mov    %rax,%rdx
    ac28:	e8 e3 95 ff ff       	call   4210 <buf_put>
    ac2d:	e9 fe fd ff ff       	jmp    aa30 <fwp_write+0xbe0>
    ac32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac38:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac3c:	48 8d 35 86 25 00 00 	lea    0x2586(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    ac43:	48 8d 05 7e 25 00 00 	lea    0x257e(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    ac4a:	4c 89 e7             	mov    %r12,%rdi
    ac4d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ac51:	48 0f 46 f0          	cmovbe %rax,%rsi
    ac55:	e8 96 87 ff ff       	call   33f0 <strcpy@plt>
    ac5a:	e9 71 f2 ff ff       	jmp    9ed0 <fwp_write+0x80>
    ac5f:	90                   	nop
    ac60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac64:	48 8d 35 5e 25 00 00 	lea    0x255e(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    ac6b:	48 8d 05 56 25 00 00 	lea    0x2556(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    ac72:	0f 2f c8             	comiss %xmm0,%xmm1
    ac75:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ac7c:	00 
    ac7d:	4c 89 e7             	mov    %r12,%rdi
    ac80:	48 0f 46 f0          	cmovbe %rax,%rsi
    ac84:	e8 67 87 ff ff       	call   33f0 <strcpy@plt>
    ac89:	e9 42 f2 ff ff       	jmp    9ed0 <fwp_write+0x80>
    ac8e:	66 90                	xchg   %ax,%ax
    ac90:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    ac95:	45 85 c0             	test   %r8d,%r8d
    ac98:	75 34                	jne    acce <fwp_write+0xe7e>
    ac9a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    aca1:	00 
    aca2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    aca9:	00 00 
    acab:	0f 85 74 f6 ff ff    	jne    a325 <fwp_write+0x4d5>
    acb1:	ba 02 00 00 00       	mov    $0x2,%edx
    acb6:	48 8d 35 82 25 00 00 	lea    0x2582(%rip),%rsi        # d23f <_IO_stdin_used+0x23f>
    acbd:	e9 a1 f3 ff ff       	jmp    a063 <fwp_write+0x213>
    acc2:	48 03 75 10          	add    0x10(%rbp),%rsi
    acc6:	49 89 f0             	mov    %rsi,%r8
    acc9:	e9 e5 fc ff ff       	jmp    a9b3 <fwp_write+0xb63>
    acce:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    acd3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    acd8:	85 ff                	test   %edi,%edi
    acda:	0f 84 fa f3 ff ff    	je     a0da <fwp_write+0x28a>
    ace0:	ba 01 00 00 00       	mov    $0x1,%edx
    ace5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    acea:	48 89 df             	mov    %rbx,%rdi
    aced:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    acf2:	e8 19 95 ff ff       	call   4210 <buf_put>
    acf7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    acfc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad01:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ad07:	85 c0                	test   %eax,%eax
    ad09:	0f 8f f0 f3 ff ff    	jg     a0ff <fwp_write+0x2af>
    ad0f:	e9 34 f4 ff ff       	jmp    a148 <fwp_write+0x2f8>
    ad14:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad18:	49 89 c5             	mov    %rax,%r13
    ad1b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad20:	49 89 c4             	mov    %rax,%r12
    ad23:	49 c1 fd 3f          	sar    $0x3f,%r13
    ad27:	4c 09 e8             	or     %r13,%rax
    ad2a:	0f 84 a7 00 00 00    	je     add7 <fwp_write+0xf87>
    ad30:	48 8d 2d c9 46 00 00 	lea    0x46c9(%rip),%rbp        # f400 <units.1>
    ad37:	4d 89 e7             	mov    %r12,%r15
    ad3a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad3e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ad43:	4c 89 ff             	mov    %r15,%rdi
    ad46:	4c 89 ee             	mov    %r13,%rsi
    ad49:	44 89 0c 24          	mov    %r9d,(%rsp)
    ad4d:	48 99                	cqto
    ad4f:	48 89 d1             	mov    %rdx,%rcx
    ad52:	48 89 c2             	mov    %rax,%rdx
    ad55:	e8 96 19 00 00       	call   c6f0 <__divmodti4>
    ad5a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad5e:	48 89 c1             	mov    %rax,%rcx
    ad61:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ad66:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    ad6b:	0f 84 94 00 00 00    	je     ae05 <fwp_write+0xfb5>
    ad71:	41 83 c1 01          	add    $0x1,%r9d
    ad75:	48 83 c5 10          	add    $0x10,%rbp
    ad79:	41 83 f9 05          	cmp    $0x5,%r9d
    ad7d:	75 bb                	jne    ad3a <fwp_write+0xeea>
    ad7f:	4d 85 ed             	test   %r13,%r13
    ad82:	79 53                	jns    add7 <fwp_write+0xf87>
    ad84:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    ad89:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ad8e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ad93:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ad98:	48 99                	cqto
    ad9a:	48 f7 d8             	neg    %rax
    ad9d:	48 83 d2 00          	adc    $0x0,%rdx
    ada1:	48 89 c6             	mov    %rax,%rsi
    ada4:	48 f7 da             	neg    %rdx
    ada7:	e8 94 8c ff ff       	call   3a40 <fwp_fmt_u128>
    adac:	49 89 e8             	mov    %rbp,%r8
    adaf:	ba 00 02 00 00       	mov    $0x200,%edx
    adb4:	be 02 00 00 00       	mov    $0x2,%esi
    adb9:	31 c0                	xor    %eax,%eax
    adbb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    adc2:	00 
    adc3:	48 8d 0d 70 24 00 00 	lea    0x2470(%rip),%rcx        # d23a <_IO_stdin_used+0x23a>
    adca:	4c 89 e7             	mov    %r12,%rdi
    adcd:	e8 0e 89 ff ff       	call   36e0 <__sprintf_chk@plt>
    add2:	e9 f9 f0 ff ff       	jmp    9ed0 <fwp_write+0x80>
    add7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    addc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ade1:	31 d2                	xor    %edx,%edx
    ade3:	48 89 ef             	mov    %rbp,%rdi
    ade6:	e8 55 8c ff ff       	call   3a40 <fwp_fmt_u128>
    adeb:	eb bf                	jmp    adac <fwp_write+0xf5c>
    aded:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    adf4:	4e 61 4e 00 
    adf8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    adff:	00 
    ae00:	e9 cb f0 ff ff       	jmp    9ed0 <fwp_write+0x80>
    ae05:	44 89 0c 24          	mov    %r9d,(%rsp)
    ae09:	48 89 c8             	mov    %rcx,%rax
    ae0c:	48 85 d2             	test   %rdx,%rdx
    ae0f:	78 51                	js     ae62 <fwp_write+0x1012>
    ae11:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae16:	48 89 c6             	mov    %rax,%rsi
    ae19:	48 89 ef             	mov    %rbp,%rdi
    ae1c:	e8 1f 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ae21:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae25:	49 63 c1             	movslq %r9d,%rax
    ae28:	49 89 e8             	mov    %rbp,%r8
    ae2b:	ba 00 02 00 00       	mov    $0x200,%edx
    ae30:	be 02 00 00 00       	mov    $0x2,%esi
    ae35:	48 c1 e0 04          	shl    $0x4,%rax
    ae39:	48 8d 3d c0 45 00 00 	lea    0x45c0(%rip),%rdi        # f400 <units.1>
    ae40:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae47:	00 
    ae48:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ae4c:	48 8d 0d e2 23 00 00 	lea    0x23e2(%rip),%rcx        # d235 <_IO_stdin_used+0x235>
    ae53:	4c 89 e7             	mov    %r12,%rdi
    ae56:	31 c0                	xor    %eax,%eax
    ae58:	e8 83 88 ff ff       	call   36e0 <__sprintf_chk@plt>
    ae5d:	e9 6e f0 ff ff       	jmp    9ed0 <fwp_write+0x80>
    ae62:	48 f7 d8             	neg    %rax
    ae65:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    ae6a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    ae6f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae74:	48 83 d2 00          	adc    $0x0,%rdx
    ae78:	48 89 c6             	mov    %rax,%rsi
    ae7b:	48 f7 da             	neg    %rdx
    ae7e:	e8 bd 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae83:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae87:	eb 9c                	jmp    ae25 <fwp_write+0xfd5>
    ae89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000ae90 <fwp_main_thread>:
    ae90:	f3 0f 1e fa          	endbr64
    ae94:	55                   	push   %rbp
    ae95:	48 89 e5             	mov    %rsp,%rbp
    ae98:	41 57                	push   %r15
    ae9a:	41 56                	push   %r14
    ae9c:	41 55                	push   %r13
    ae9e:	41 54                	push   %r12
    aea0:	53                   	push   %rbx
    aea1:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
    aea8:	44 8b 0d d5 7c 01 00 	mov    0x17cd5(%rip),%r9d        # 22b84 <fwp_heap+0x13a4>
    aeaf:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aeb6:	00 00 
    aeb8:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    aebc:	31 c0                	xor    %eax,%eax
    aebe:	45 85 c9             	test   %r9d,%r9d
    aec1:	0f 84 42 0e 00 00    	je     bd09 <fwp_main_thread+0xe79>
    aec7:	44 8b 05 ba 7c 01 00 	mov    0x17cba(%rip),%r8d        # 22b88 <fwp_heap+0x13a8>
    aece:	45 85 c0             	test   %r8d,%r8d
    aed1:	0f 85 21 0e 00 00    	jne    bcf8 <fwp_main_thread+0xe68>
    aed7:	48 8d 05 c2 61 00 00 	lea    0x61c2(%rip),%rax        # 110a0 <alt.5>
    aede:	31 f6                	xor    %esi,%esi
    aee0:	48 8d 9d d0 fe ff ff 	lea    -0x130(%rbp),%rbx
    aee7:	48 c7 05 7e 62 01 00 	movq   $0x40000000,0x1627e(%rip)        # 21170 <fwp_main_stack_size>
    aeee:	00 00 00 40 
    aef2:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    aef9:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    af00:	48 89 c7             	mov    %rax,%rdi
    af03:	48 89 1d 6e 62 01 00 	mov    %rbx,0x1626e(%rip)        # 21178 <fwp_main_stack_top>
    af0a:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    af11:	00 00 01 00 
    af15:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    af1c:	00 00 00 
    af1f:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
    af26:	e8 95 87 ff ff       	call   36c0 <sigaltstack@plt>
    af2b:	85 c0                	test   %eax,%eax
    af2d:	0f 85 66 17 00 00    	jne    c699 <fwp_main_thread+0x1809>
    af33:	31 c0                	xor    %eax,%eax
    af35:	b9 12 00 00 00       	mov    $0x12,%ecx
    af3a:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    af41:	f3 48 ab             	rep stos %rax,(%rdi)
    af44:	48 8d 05 a5 8d ff ff 	lea    -0x725b(%rip),%rax        # 3cf0 <fwp_segv>
    af4b:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    af52:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    af59:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    af60:	4c 8d ad 30 ff ff ff 	lea    -0xd0(%rbp),%r13
    af67:	e8 14 86 ff ff       	call   3580 <sigemptyset@plt>
    af6c:	85 c0                	test   %eax,%eax
    af6e:	0f 85 25 17 00 00    	jne    c699 <fwp_main_thread+0x1809>
    af74:	31 d2                	xor    %edx,%edx
    af76:	4c 89 ee             	mov    %r13,%rsi
    af79:	bf 0b 00 00 00       	mov    $0xb,%edi
    af7e:	e8 7d 84 ff ff       	call   3400 <sigaction@plt>
    af83:	85 c0                	test   %eax,%eax
    af85:	0f 85 0e 17 00 00    	jne    c699 <fwp_main_thread+0x1809>
    af8b:	31 d2                	xor    %edx,%edx
    af8d:	4c 89 ee             	mov    %r13,%rsi
    af90:	bf 07 00 00 00       	mov    $0x7,%edi
    af95:	e8 66 84 ff ff       	call   3400 <sigaction@plt>
    af9a:	85 c0                	test   %eax,%eax
    af9c:	0f 85 f7 16 00 00    	jne    c699 <fwp_main_thread+0x1809>
    afa2:	8b 3d 70 61 01 00    	mov    0x16170(%rip),%edi        # 21118 <descent_registered>
    afa8:	85 ff                	test   %edi,%edi
    afaa:	0f 84 30 05 00 00    	je     b4e0 <fwp_main_thread+0x650>
    afb0:	8b 35 da 60 00 00    	mov    0x60da(%rip),%esi        # 11090 <st.3>
    afb6:	85 f6                	test   %esi,%esi
    afb8:	0f 84 4e 05 00 00    	je     b50c <fwp_main_thread+0x67c>
    afbe:	4c 8b 25 fb 67 01 00 	mov    0x167fb(%rip),%r12        # 217c0 <fwp_cur>
    afc5:	4d 85 e4             	test   %r12,%r12
    afc8:	0f 84 c5 01 00 00    	je     b193 <fwp_main_thread+0x303>
    afce:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    afd4:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    afda:	4c 89 e3             	mov    %r12,%rbx
    afdd:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    afe3:	0f 84 48 01 00 00    	je     b131 <fwp_main_thread+0x2a1>
    afe9:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    afef:	0f 84 94 02 00 00    	je     b289 <fwp_main_thread+0x3f9>
    aff5:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    affb:	0f 84 6c 02 00 00    	je     b26d <fwp_main_thread+0x3dd>
    b001:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b006:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b00a:	0f 85 fa 02 00 00    	jne    b30a <fwp_main_thread+0x47a>
    b010:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b014:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b01b:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b020:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b027:	00 00 00 00 
    b02b:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b032:	48 85 d2             	test   %rdx,%rdx
    b035:	74 07                	je     b03e <fwp_main_thread+0x1ae>
    b037:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b03e:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b043:	48 85 c0             	test   %rax,%rax
    b046:	74 34                	je     b07c <fwp_main_thread+0x1ec>
    b048:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b04c:	48 8b 05 45 67 01 00 	mov    0x16745(%rip),%rax        # 21798 <fwp_timers>
    b053:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b057:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b05e:	00 00 00 00 
    b062:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b069:	48 85 c0             	test   %rax,%rax
    b06c:	74 07                	je     b075 <fwp_main_thread+0x1e5>
    b06e:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b075:	48 89 1d 1c 67 01 00 	mov    %rbx,0x1671c(%rip)        # 21798 <fwp_timers>
    b07c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b080:	e8 ab c3 ff ff       	call   7430 <fwp_block>
    b085:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b08c:	48 85 c9             	test   %rcx,%rcx
    b08f:	74 47                	je     b0d8 <fwp_main_thread+0x248>
    b091:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b098:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b09f:	48 85 d2             	test   %rdx,%rdx
    b0a2:	0f 84 5a 02 00 00    	je     b302 <fwp_main_thread+0x472>
    b0a8:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b0af:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b0b6:	48 85 c0             	test   %rax,%rax
    b0b9:	74 07                	je     b0c2 <fwp_main_thread+0x232>
    b0bb:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b0c2:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b0c9:	00 00 00 00 
    b0cd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b0d1:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b0d8:	48 8b 0d e1 66 01 00 	mov    0x166e1(%rip),%rcx        # 217c0 <fwp_cur>
    b0df:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b0e3:	0f 84 11 02 00 00    	je     b2fa <fwp_main_thread+0x46a>
    b0e9:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b0f0:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b0f7:	48 85 d2             	test   %rdx,%rdx
    b0fa:	0f 84 d4 03 00 00    	je     b4d4 <fwp_main_thread+0x644>
    b100:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b107:	48 85 c0             	test   %rax,%rax
    b10a:	74 07                	je     b113 <fwp_main_thread+0x283>
    b10c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b113:	66 0f ef db          	pxor   %xmm3,%xmm3
    b117:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b11b:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b122:	48 89 cb             	mov    %rcx,%rbx
    b125:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    b12b:	0f 85 b8 fe ff ff    	jne    afe9 <fwp_main_thread+0x159>
    b131:	48 83 3d 1f 83 01 00 	cmpq   $0x0,0x1831f(%rip)        # 23458 <fwp_state_len>
    b138:	00 
    b139:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    b13e:	74 63                	je     b1a3 <fwp_main_thread+0x313>
    b140:	48 39 1d 71 66 01 00 	cmp    %rbx,0x16671(%rip)        # 217b8 <fwp_root>
    b147:	c7 05 4f 5f 01 00 00 	movl   $0x0,0x15f4f(%rip)        # 210a0 <fwp_exit_code>
    b14e:	00 00 00 
    b151:	0f 85 93 15 00 00    	jne    c6ea <fwp_main_thread+0x185a>
    b157:	48 85 db             	test   %rbx,%rbx
    b15a:	0f 84 fa 01 00 00    	je     b35a <fwp_main_thread+0x4ca>
    b160:	48 8b 15 21 66 01 00 	mov    0x16621(%rip),%rdx        # 21788 <fwp_tasks_active>
    b167:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b16b:	48 85 d2             	test   %rdx,%rdx
    b16e:	0f 84 e6 01 00 00    	je     b35a <fwp_main_thread+0x4ca>
    b174:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b178:	75 08                	jne    b182 <fwp_main_thread+0x2f2>
    b17a:	48 89 d7             	mov    %rdx,%rdi
    b17d:	e8 7e 91 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b182:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b189:	48 85 d2             	test   %rdx,%rdx
    b18c:	75 e6                	jne    b174 <fwp_main_thread+0x2e4>
    b18e:	e9 aa 00 00 00       	jmp    b23d <fwp_main_thread+0x3ad>
    b193:	48 83 3d bd 82 01 00 	cmpq   $0x0,0x182bd(%rip)        # 23458 <fwp_state_len>
    b19a:	00 
    b19b:	0f 85 a1 01 00 00    	jne    b342 <fwp_main_thread+0x4b2>
    b1a1:	31 db                	xor    %ebx,%ebx
    b1a3:	48 83 3d 9d 82 01 00 	cmpq   $0x0,0x1829d(%rip)        # 23448 <fwp_state_owners>
    b1aa:	00 
    b1ab:	75 93                	jne    b140 <fwp_main_thread+0x2b0>
    b1ad:	48 8b 3d ac 82 01 00 	mov    0x182ac(%rip),%rdi        # 23460 <fwp_state>
    b1b4:	e8 d7 a5 ff ff       	call   5790 <fwp_mem_free>
    b1b9:	48 c7 05 9c 82 01 00 	movq   $0x0,0x1829c(%rip)        # 23460 <fwp_state>
    b1c0:	00 00 00 00 
    b1c4:	48 c7 05 81 82 01 00 	movq   $0x0,0x18281(%rip)        # 23450 <fwp_state_cap>
    b1cb:	00 00 00 00 
    b1cf:	48 85 db             	test   %rbx,%rbx
    b1d2:	0f 84 28 13 00 00    	je     c500 <fwp_main_thread+0x1670>
    b1d8:	48 39 1d d9 65 01 00 	cmp    %rbx,0x165d9(%rip)        # 217b8 <fwp_root>
    b1df:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b1e6:	00 00 00 00 
    b1ea:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b1f1:	00 00 00 00 
    b1f5:	c7 05 a1 5e 01 00 00 	movl   $0x0,0x15ea1(%rip)        # 210a0 <fwp_exit_code>
    b1fc:	00 00 00 
    b1ff:	0f 84 5b ff ff ff    	je     b160 <fwp_main_thread+0x2d0>
    b205:	e9 46 85 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b20a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b210:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b217:	48 89 1d 82 65 01 00 	mov    %rbx,0x16582(%rip)        # 217a0 <fwp_ready_tail>
    b21e:	e8 0d c2 ff ff       	call   7430 <fwp_block>
    b223:	e8 08 c0 ff ff       	call   7230 <fwp_free_zombie>
    b228:	48 83 3d 58 65 01 00 	cmpq   $0x0,0x16558(%rip)        # 21788 <fwp_tasks_active>
    b22f:	00 
    b230:	0f 84 24 01 00 00    	je     b35a <fwp_main_thread+0x4ca>
    b236:	48 8b 1d 7b 65 01 00 	mov    0x1657b(%rip),%rbx        # 217b8 <fwp_root>
    b23d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b241:	75 db                	jne    b21e <fwp_main_thread+0x38e>
    b243:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b247:	75 d5                	jne    b21e <fwp_main_thread+0x38e>
    b249:	48 8b 05 50 65 01 00 	mov    0x16550(%rip),%rax        # 217a0 <fwp_ready_tail>
    b250:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b254:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b25b:	00 00 00 00 
    b25f:	48 85 c0             	test   %rax,%rax
    b262:	75 ac                	jne    b210 <fwp_main_thread+0x380>
    b264:	48 89 1d 3d 65 01 00 	mov    %rbx,0x1653d(%rip)        # 217a8 <fwp_ready_head>
    b26b:	eb aa                	jmp    b217 <fwp_main_thread+0x387>
    b26d:	e8 ee 92 ff ff       	call   4560 <fwp_now_ns>
    b272:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    b277:	7c 10                	jl     b289 <fwp_main_thread+0x3f9>
    b279:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    b27f:	75 08                	jne    b289 <fwp_main_thread+0x3f9>
    b281:	4c 89 e7             	mov    %r12,%rdi
    b284:	e8 77 90 ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b289:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    b28f:	0f 85 6c fd ff ff    	jne    b001 <fwp_main_thread+0x171>
    b295:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    b29a:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b29f:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b2a3:	0f 85 6b fd ff ff    	jne    b014 <fwp_main_thread+0x184>
    b2a9:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b2ad:	48 85 c9             	test   %rcx,%rcx
    b2b0:	0f 84 5e fd ff ff    	je     b014 <fwp_main_thread+0x184>
    b2b6:	48 85 c0             	test   %rax,%rax
    b2b9:	0f 84 86 13 00 00    	je     c645 <fwp_main_thread+0x17b5>
    b2bf:	48 39 c8             	cmp    %rcx,%rax
    b2c2:	48 0f 4f c1          	cmovg  %rcx,%rax
    b2c6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b2cd:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b2d2:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b2d9:	00 00 00 00 
    b2dd:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b2e4:	48 85 d2             	test   %rdx,%rdx
    b2e7:	74 07                	je     b2f0 <fwp_main_thread+0x460>
    b2e9:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b2f0:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b2f5:	e9 4e fd ff ff       	jmp    b048 <fwp_main_thread+0x1b8>
    b2fa:	48 89 cb             	mov    %rcx,%rbx
    b2fd:	e9 db fc ff ff       	jmp    afdd <fwp_main_thread+0x14d>
    b302:	48 89 01             	mov    %rax,(%rcx)
    b305:	e9 ac fd ff ff       	jmp    b0b6 <fwp_main_thread+0x226>
    b30a:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    b30f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b316:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b31d:	00 00 00 00 
    b321:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b328:	48 85 c0             	test   %rax,%rax
    b32b:	0f 84 43 11 00 00    	je     c474 <fwp_main_thread+0x15e4>
    b331:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b338:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b33d:	e9 3a fd ff ff       	jmp    b07c <fwp_main_thread+0x1ec>
    b342:	48 83 3d 6e 64 01 00 	cmpq   $0x0,0x1646e(%rip)        # 217b8 <fwp_root>
    b349:	00 
    b34a:	c7 05 4c 5d 01 00 00 	movl   $0x0,0x15d4c(%rip)        # 210a0 <fwp_exit_code>
    b351:	00 00 00 
    b354:	0f 85 8b 13 00 00    	jne    c6e5 <fwp_main_thread+0x1855>
    b35a:	e8 d1 be ff ff       	call   7230 <fwp_free_zombie>
    b35f:	48 83 3d 41 64 01 00 	cmpq   $0x0,0x16441(%rip)        # 217a8 <fwp_ready_head>
    b366:	00 
    b367:	0f 85 e3 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b36d:	48 83 3d 23 64 01 00 	cmpq   $0x0,0x16423(%rip)        # 21798 <fwp_timers>
    b374:	00 
    b375:	0f 85 d5 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b37b:	8b 05 03 5e 01 00    	mov    0x15e03(%rip),%eax        # 21184 <fwp_stack_pool_n>
    b381:	85 c0                	test   %eax,%eax
    b383:	74 37                	je     b3bc <fwp_main_thread+0x52c>
    b385:	83 e8 01             	sub    $0x1,%eax
    b388:	4c 8d 2d 11 5e 01 00 	lea    0x15e11(%rip),%r13        # 211a0 <fwp_stack_pool>
    b38f:	48 63 d8             	movslq %eax,%rbx
    b392:	89 c0                	mov    %eax,%eax
    b394:	48 89 da             	mov    %rbx,%rdx
    b397:	48 29 c2             	sub    %rax,%rdx
    b39a:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    b39e:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    b3a3:	89 1d db 5d 01 00    	mov    %ebx,0x15ddb(%rip)        # 21184 <fwp_stack_pool_n>
    b3a9:	be 00 00 00 10       	mov    $0x10000000,%esi
    b3ae:	48 83 eb 01          	sub    $0x1,%rbx
    b3b2:	e8 29 82 ff ff       	call   35e0 <munmap@plt>
    b3b7:	4c 39 e3             	cmp    %r12,%rbx
    b3ba:	75 e2                	jne    b39e <fwp_main_thread+0x50e>
    b3bc:	8b 3d 62 5c 00 00    	mov    0x5c62(%rip),%edi        # 11024 <fwp_epfd>
    b3c2:	85 ff                	test   %edi,%edi
    b3c4:	78 05                	js     b3cb <fwp_main_thread+0x53b>
    b3c6:	e8 05 81 ff ff       	call   34d0 <close@plt>
    b3cb:	4c 8b 2d ce 5f 01 00 	mov    0x15fce(%rip),%r13        # 213a0 <fwp_nfdws>
    b3d2:	4c 8b 25 cf 5f 01 00 	mov    0x15fcf(%rip),%r12        # 213a8 <fwp_fdws>
    b3d9:	31 db                	xor    %ebx,%ebx
    b3db:	c7 05 3f 5c 00 00 ff 	movl   $0xffffffff,0x5c3f(%rip)        # 11024 <fwp_epfd>
    b3e2:	ff ff ff 
    b3e5:	4d 85 ed             	test   %r13,%r13
    b3e8:	74 2c                	je     b416 <fwp_main_thread+0x586>
    b3ea:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b3ee:	48 85 ff             	test   %rdi,%rdi
    b3f1:	74 1a                	je     b40d <fwp_main_thread+0x57d>
    b3f3:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b3f7:	0f 85 53 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3fd:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b402:	0f 85 48 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b408:	e8 83 a3 ff ff       	call   5790 <fwp_mem_free>
    b40d:	48 83 c3 01          	add    $0x1,%rbx
    b411:	4c 39 eb             	cmp    %r13,%rbx
    b414:	75 d4                	jne    b3ea <fwp_main_thread+0x55a>
    b416:	4c 89 e7             	mov    %r12,%rdi
    b419:	e8 72 a3 ff ff       	call   5790 <fwp_mem_free>
    b41e:	48 8b 15 93 63 01 00 	mov    0x16393(%rip),%rdx        # 217b8 <fwp_root>
    b425:	48 c7 05 78 5f 01 00 	movq   $0x0,0x15f78(%rip)        # 213a8 <fwp_fdws>
    b42c:	00 00 00 00 
    b430:	48 c7 05 65 5f 01 00 	movq   $0x0,0x15f65(%rip)        # 213a0 <fwp_nfdws>
    b437:	00 00 00 00 
    b43b:	48 85 d2             	test   %rdx,%rdx
    b43e:	74 4e                	je     b48e <fwp_main_thread+0x5fe>
    b440:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b445:	0f 85 05 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b44b:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b452:	00 
    b453:	0f 85 f7 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b459:	48 83 3d f7 7f 01 00 	cmpq   $0x0,0x17ff7(%rip)        # 23458 <fwp_state_len>
    b460:	00 
    b461:	0f 85 e9 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b467:	48 83 3d d9 7f 01 00 	cmpq   $0x0,0x17fd9(%rip)        # 23448 <fwp_state_owners>
    b46e:	00 
    b46f:	0f 85 db 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b475:	b9 79 00 00 00       	mov    $0x79,%ecx
    b47a:	31 c0                	xor    %eax,%eax
    b47c:	48 8d 3d 3d 5f 01 00 	lea    0x15f3d(%rip),%rdi        # 213c0 <fwp_root_context>
    b483:	f3 48 ab             	rep stos %rax,(%rdi)
    b486:	48 89 d7             	mov    %rdx,%rdi
    b489:	e8 02 a3 ff ff       	call   5790 <fwp_mem_free>
    b48e:	48 8b 3d ab 5b 00 00 	mov    0x5bab(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b495:	48 c7 05 20 63 01 00 	movq   $0x0,0x16320(%rip)        # 217c0 <fwp_cur>
    b49c:	00 00 00 00 
    b4a0:	48 c7 05 0d 63 01 00 	movq   $0x0,0x1630d(%rip)        # 217b8 <fwp_root>
    b4a7:	00 00 00 00 
    b4ab:	e8 10 81 ff ff       	call   35c0 <fflush@plt>
    b4b0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b4b4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b4bb:	00 00 
    b4bd:	0f 85 d1 11 00 00    	jne    c694 <fwp_main_thread+0x1804>
    b4c3:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b4c7:	31 c0                	xor    %eax,%eax
    b4c9:	5b                   	pop    %rbx
    b4ca:	41 5c                	pop    %r12
    b4cc:	41 5d                	pop    %r13
    b4ce:	41 5e                	pop    %r14
    b4d0:	41 5f                	pop    %r15
    b4d2:	5d                   	pop    %rbp
    b4d3:	c3                   	ret
    b4d4:	48 89 05 bd 62 01 00 	mov    %rax,0x162bd(%rip)        # 21798 <fwp_timers>
    b4db:	e9 27 fc ff ff       	jmp    b107 <fwp_main_thread+0x277>
    b4e0:	48 8d 3d 29 89 ff ff 	lea    -0x76d7(%rip),%rdi        # 3e10 <descent_phase_report>
    b4e7:	e8 14 14 00 00       	call   c900 <atexit>
    b4ec:	85 c0                	test   %eax,%eax
    b4ee:	0f 85 3d 11 00 00    	jne    c631 <fwp_main_thread+0x17a1>
    b4f4:	c7 05 1a 5c 01 00 01 	movl   $0x1,0x15c1a(%rip)        # 21118 <descent_registered>
    b4fb:	00 00 00 
    b4fe:	8b 35 8c 5b 00 00    	mov    0x5b8c(%rip),%esi        # 11090 <st.3>
    b504:	85 f6                	test   %esi,%esi
    b506:	0f 85 b2 fa ff ff    	jne    afbe <fwp_main_thread+0x12e>
    b50c:	48 8d 05 5d b6 ff ff 	lea    -0x49a3(%rip),%rax        # 6b70 <fwp_drop1>
    b513:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b517:	4c 89 ad b0 fe ff ff 	mov    %r13,-0x150(%rbp)
    b51e:	4c 8b 25 bb 26 00 00 	mov    0x26bb(%rip),%r12        # dbe0 <msg.4+0x70>
    b525:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b52a:	45 31 ff             	xor    %r15d,%r15d
    b52d:	48 8b 05 44 7f 01 00 	mov    0x17f44(%rip),%rax        # 23478 <fwp_cleanups>
    b534:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b53b:	00 00 00 00 
    b53f:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b543:	48 89 1d 2e 7f 01 00 	mov    %rbx,0x17f2e(%rip)        # 23478 <fwp_cleanups>
    b54a:	4c 8d 35 8f 62 01 00 	lea    0x1628f(%rip),%r14        # 217e0 <fwp_heap>
    b551:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    b557:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b55e:	48 8d 05 6b 86 ff ff 	lea    -0x7995(%rip),%rax        # 3bd0 <fwp_range_release>
    b565:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b56c:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
    b573:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b57a:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
    b581:	e9 0a 01 00 00       	jmp    b690 <fwp_main_thread+0x800>
    b586:	48 8b 13             	mov    (%rbx),%rdx
    b589:	48 f7 d2             	not    %rdx
    b58c:	48 89 10             	mov    %rdx,(%rax)
    b58f:	49 83 f8 18          	cmp    $0x18,%r8
    b593:	76 29                	jbe    b5be <fwp_main_thread+0x72e>
    b595:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    b599:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    b59d:	31 f6                	xor    %esi,%esi
    b59f:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b5a6:	48 c1 e8 03          	shr    $0x3,%rax
    b5aa:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b5b1:	00 
    b5b2:	e8 09 7f ff ff       	call   34c0 <memset@plt>
    b5b7:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b5be:	4c 89 c0             	mov    %r8,%rax
    b5c1:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    b5c8:	0f 82 72 10 00 00    	jb     c640 <fwp_main_thread+0x17b0>
    b5ce:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    b5d5:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    b5dc:	73 07                	jae    b5e5 <fwp_main_thread+0x755>
    b5de:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    b5e5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b5e9:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    b5ee:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    b5f5:	00 00 
    b5f7:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    b5fe:	00 00 
    b600:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
    b604:	48 89 d8             	mov    %rbx,%rax
    b607:	49 89 df             	mov    %rbx,%r15
    b60a:	4c 89 23             	mov    %r12,(%rbx)
    b60d:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
    b611:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b618:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b61f:	48 c1 e2 10          	shl    $0x10,%rdx
    b623:	48 39 d0             	cmp    %rdx,%rax
    b626:	73 57                	jae    b67f <fwp_main_thread+0x7ef>
    b628:	48 89 c2             	mov    %rax,%rdx
    b62b:	48 c1 ea 10          	shr    $0x10,%rdx
    b62f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b633:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b63a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b63e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b642:	48 85 d2             	test   %rdx,%rdx
    b645:	74 38                	je     b67f <fwp_main_thread+0x7ef>
    b647:	0f b6 3e             	movzbl (%rsi),%edi
    b64a:	40 80 ff 02          	cmp    $0x2,%dil
    b64e:	0f 84 a8 00 00 00    	je     b6fc <fwp_main_thread+0x86c>
    b654:	40 80 ff 01          	cmp    $0x1,%dil
    b658:	75 25                	jne    b67f <fwp_main_thread+0x7ef>
    b65a:	8b 7e 18             	mov    0x18(%rsi),%edi
    b65d:	0f b7 c0             	movzwl %ax,%eax
    b660:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b663:	48 0f af c7          	imul   %rdi,%rax
    b667:	48 c1 e8 20          	shr    $0x20,%rax
    b66b:	48 39 f0             	cmp    %rsi,%rax
    b66e:	73 0f                	jae    b67f <fwp_main_thread+0x7ef>
    b670:	48 01 c2             	add    %rax,%rdx
    b673:	80 3a ff             	cmpb   $0xff,(%rdx)
    b676:	0f 84 4e 0e 00 00    	je     c4ca <fwp_main_thread+0x163a>
    b67c:	c6 02 01             	movb   $0x1,(%rdx)
    b67f:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b686:	49 83 ed 01          	sub    $0x1,%r13
    b68a:	0f 82 86 00 00 00    	jb     b716 <fwp_main_thread+0x886>
    b690:	41 8b 8e a4 13 00 00 	mov    0x13a4(%r14),%ecx
    b697:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
    b69e:	85 c9                	test   %ecx,%ecx
    b6a0:	74 46                	je     b6e8 <fwp_main_thread+0x858>
    b6a2:	41 0f b6 86 a2 0f 00 	movzbl 0xfa2(%r14),%eax
    b6a9:	00 
    b6aa:	45 8b 84 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r8d
    b6b1:	00 
    b6b2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b6b6:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    b6ba:	48 8b 18             	mov    (%rax),%rbx
    b6bd:	48 85 db             	test   %rbx,%rbx
    b6c0:	0f 85 c0 fe ff ff    	jne    b586 <fwp_main_thread+0x6f6>
    b6c6:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b6ca:	48 85 db             	test   %rbx,%rbx
    b6cd:	74 19                	je     b6e8 <fwp_main_thread+0x858>
    b6cf:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b6d3:	48 29 da             	sub    %rbx,%rdx
    b6d6:	4c 39 c2             	cmp    %r8,%rdx
    b6d9:	72 0d                	jb     b6e8 <fwp_main_thread+0x858>
    b6db:	4a 8d 14 03          	lea    (%rbx,%r8,1),%rdx
    b6df:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b6e3:	e9 a7 fe ff ff       	jmp    b58f <fwp_main_thread+0x6ff>
    b6e8:	31 f6                	xor    %esi,%esi
    b6ea:	bf 18 00 00 00       	mov    $0x18,%edi
    b6ef:	e8 9c a5 ff ff       	call   5c90 <fwp_heap_alloc>
    b6f4:	48 89 c3             	mov    %rax,%rbx
    b6f7:	e9 04 ff ff ff       	jmp    b600 <fwp_main_thread+0x770>
    b6fc:	66 85 c0             	test   %ax,%ax
    b6ff:	0f 84 6e ff ff ff    	je     b673 <fwp_main_thread+0x7e3>
    b705:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b70c:	49 83 ed 01          	sub    $0x1,%r13
    b710:	0f 83 7a ff ff ff    	jae    b690 <fwp_main_thread+0x800>
    b716:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    b71d:	66 0f 6f 05 eb 24 00 	movdqa 0x24eb(%rip),%xmm0        # dc10 <msg.4+0xa0>
    b724:	00 
    b725:	bf 01 00 00 00       	mov    $0x1,%edi
    b72a:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
    b731:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
    b738:	48 89 05 39 7d 01 00 	mov    %rax,0x17d39(%rip)        # 23478 <fwp_cleanups>
    b73f:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    b746:	e8 e5 af ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b74b:	48 8b 15 66 74 01 00 	mov    0x17466(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    b752:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b759:	49 89 c5             	mov    %rax,%r13
    b75c:	48 2b 05 2d 74 01 00 	sub    0x1742d(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    b763:	48 c1 e2 10          	shl    $0x10,%rdx
    b767:	48 39 d0             	cmp    %rdx,%rax
    b76a:	73 55                	jae    b7c1 <fwp_main_thread+0x931>
    b76c:	48 89 c2             	mov    %rax,%rdx
    b76f:	48 c1 ea 10          	shr    $0x10,%rdx
    b773:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b777:	48 8b 15 5a 74 01 00 	mov    0x1745a(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    b77e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b782:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b786:	48 85 db             	test   %rbx,%rbx
    b789:	74 36                	je     b7c1 <fwp_main_thread+0x931>
    b78b:	0f b6 0a             	movzbl (%rdx),%ecx
    b78e:	80 f9 02             	cmp    $0x2,%cl
    b791:	0f 84 09 0d 00 00    	je     c4a0 <fwp_main_thread+0x1610>
    b797:	80 f9 01             	cmp    $0x1,%cl
    b79a:	75 25                	jne    b7c1 <fwp_main_thread+0x931>
    b79c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b79f:	0f b7 c0             	movzwl %ax,%eax
    b7a2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7a5:	48 0f af c1          	imul   %rcx,%rax
    b7a9:	48 c1 e8 20          	shr    $0x20,%rax
    b7ad:	48 39 d0             	cmp    %rdx,%rax
    b7b0:	73 0f                	jae    b7c1 <fwp_main_thread+0x931>
    b7b2:	48 01 c3             	add    %rax,%rbx
    b7b5:	80 3b ff             	cmpb   $0xff,(%rbx)
    b7b8:	0f 84 18 0e 00 00    	je     c5d6 <fwp_main_thread+0x1746>
    b7be:	c6 03 01             	movb   $0x1,(%rbx)
    b7c1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b7c8:	00 f0 3f 
    b7cb:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    b7d2:	bf 01 00 00 00       	mov    $0x1,%edi
    b7d7:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b7de:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
    b7e5:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    b7ec:	e8 3f af ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b7f1:	48 8b 15 c0 73 01 00 	mov    0x173c0(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    b7f8:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b7ff:	49 89 c5             	mov    %rax,%r13
    b802:	48 2b 05 87 73 01 00 	sub    0x17387(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    b809:	48 c1 e2 10          	shl    $0x10,%rdx
    b80d:	48 39 d0             	cmp    %rdx,%rax
    b810:	73 55                	jae    b867 <fwp_main_thread+0x9d7>
    b812:	48 89 c2             	mov    %rax,%rdx
    b815:	48 c1 ea 10          	shr    $0x10,%rdx
    b819:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b81d:	48 8b 15 b4 73 01 00 	mov    0x173b4(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    b824:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b828:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b82c:	48 85 db             	test   %rbx,%rbx
    b82f:	74 36                	je     b867 <fwp_main_thread+0x9d7>
    b831:	0f b6 0a             	movzbl (%rdx),%ecx
    b834:	80 f9 02             	cmp    $0x2,%cl
    b837:	0f 84 55 0c 00 00    	je     c492 <fwp_main_thread+0x1602>
    b83d:	80 f9 01             	cmp    $0x1,%cl
    b840:	75 25                	jne    b867 <fwp_main_thread+0x9d7>
    b842:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b845:	0f b7 c0             	movzwl %ax,%eax
    b848:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b84b:	48 0f af c1          	imul   %rcx,%rax
    b84f:	48 c1 e8 20          	shr    $0x20,%rax
    b853:	48 39 d0             	cmp    %rdx,%rax
    b856:	73 0f                	jae    b867 <fwp_main_thread+0x9d7>
    b858:	48 01 c3             	add    %rax,%rbx
    b85b:	80 3b ff             	cmpb   $0xff,(%rbx)
    b85e:	0f 84 8d 0d 00 00    	je     c5f1 <fwp_main_thread+0x1761>
    b864:	c6 03 01             	movb   $0x1,(%rbx)
    b867:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b86e:	33 f3 bf 
    b871:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    b878:	bf 01 00 00 00       	mov    $0x1,%edi
    b87d:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b884:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    b88b:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
    b892:	e8 99 ae ff ff       	call   6730 <fwp_data.part.0.constprop.0>
    b897:	48 8b 15 1a 73 01 00 	mov    0x1731a(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    b89e:	48 8b 0d eb 72 01 00 	mov    0x172eb(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    b8a5:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
    b8ac:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b8b3:	48 89 d6             	mov    %rdx,%rsi
    b8b6:	48 29 c8             	sub    %rcx,%rax
    b8b9:	48 c1 e6 10          	shl    $0x10,%rsi
    b8bd:	48 39 f0             	cmp    %rsi,%rax
    b8c0:	73 65                	jae    b927 <fwp_main_thread+0xa97>
    b8c2:	48 89 c6             	mov    %rax,%rsi
    b8c5:	48 c1 ee 10          	shr    $0x10,%rsi
    b8c9:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b8cd:	48 8b 35 04 73 01 00 	mov    0x17304(%rip),%rsi        # 22bd8 <fwp_heap+0x13f8>
    b8d4:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b8d8:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    b8dc:	48 85 db             	test   %rbx,%rbx
    b8df:	74 46                	je     b927 <fwp_main_thread+0xa97>
    b8e1:	0f b6 3e             	movzbl (%rsi),%edi
    b8e4:	40 80 ff 02          	cmp    $0x2,%dil
    b8e8:	0f 84 ce 0b 00 00    	je     c4bc <fwp_main_thread+0x162c>
    b8ee:	40 80 ff 01          	cmp    $0x1,%dil
    b8f2:	75 33                	jne    b927 <fwp_main_thread+0xa97>
    b8f4:	8b 7e 18             	mov    0x18(%rsi),%edi
    b8f7:	0f b7 c0             	movzwl %ax,%eax
    b8fa:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b8fd:	48 0f af c7          	imul   %rdi,%rax
    b901:	48 c1 e8 20          	shr    $0x20,%rax
    b905:	48 39 f0             	cmp    %rsi,%rax
    b908:	73 1d                	jae    b927 <fwp_main_thread+0xa97>
    b90a:	48 01 c3             	add    %rax,%rbx
    b90d:	80 3b ff             	cmpb   $0xff,(%rbx)
    b910:	0f 84 f6 0c 00 00    	je     c60c <fwp_main_thread+0x177c>
    b916:	c6 03 01             	movb   $0x1,(%rbx)
    b919:	48 8b 0d 70 72 01 00 	mov    0x17270(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    b920:	48 8b 15 91 72 01 00 	mov    0x17291(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    b927:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
    b92e:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    b935:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    b93c:	4c 89 85 60 fe ff ff 	mov    %r8,-0x1a0(%rbp)
    b943:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b94a:	48 c1 e2 10          	shl    $0x10,%rdx
    b94e:	48 29 c8             	sub    %rcx,%rax
    b951:	48 39 d0             	cmp    %rdx,%rax
    b954:	73 5d                	jae    b9b3 <fwp_main_thread+0xb23>
    b956:	48 89 c2             	mov    %rax,%rdx
    b959:	48 c1 ea 10          	shr    $0x10,%rdx
    b95d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b961:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b968:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b96c:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b970:	48 85 ff             	test   %rdi,%rdi
    b973:	74 3e                	je     b9b3 <fwp_main_thread+0xb23>
    b975:	0f b6 0a             	movzbl (%rdx),%ecx
    b978:	80 f9 02             	cmp    $0x2,%cl
    b97b:	0f 84 2d 0b 00 00    	je     c4ae <fwp_main_thread+0x161e>
    b981:	80 f9 01             	cmp    $0x1,%cl
    b984:	75 2d                	jne    b9b3 <fwp_main_thread+0xb23>
    b986:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b989:	0f b7 c0             	movzwl %ax,%eax
    b98c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b98f:	48 0f af c1          	imul   %rcx,%rax
    b993:	48 c1 e8 20          	shr    $0x20,%rax
    b997:	48 39 d0             	cmp    %rdx,%rax
    b99a:	73 17                	jae    b9b3 <fwp_main_thread+0xb23>
    b99c:	48 01 c7             	add    %rax,%rdi
    b99f:	0f b6 07             	movzbl (%rdi),%eax
    b9a2:	84 c0                	test   %al,%al
    b9a4:	74 0d                	je     b9b3 <fwp_main_thread+0xb23>
    b9a6:	3c fd                	cmp    $0xfd,%al
    b9a8:	0f 87 79 0c 00 00    	ja     c627 <fwp_main_thread+0x1797>
    b9ae:	83 c0 01             	add    $0x1,%eax
    b9b1:	88 07                	mov    %al,(%rdi)
    b9b3:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    b9ba:	48 8b 15 77 7a 01 00 	mov    0x17a77(%rip),%rdx        # 23438 <fwp_fns>
    b9c1:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    b9c8:	48 8d 05 49 56 00 00 	lea    0x5649(%rip),%rax        # 11018 <fc12>
    b9cf:	44 8b 28             	mov    (%rax),%r13d
    b9d2:	49 c1 e5 05          	shl    $0x5,%r13
    b9d6:	49 01 d5             	add    %rdx,%r13
    b9d9:	49 8b 4d 18          	mov    0x18(%r13),%rcx
    b9dd:	48 85 c9             	test   %rcx,%rcx
    b9e0:	0f 84 6a 0c 00 00    	je     c650 <fwp_main_thread+0x17c0>
    b9e6:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    b9eb:	0f 84 ff 08 00 00    	je     c2f0 <fwp_main_thread+0x1460>
    b9f1:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    b9f8:	48 8d 05 19 56 00 00 	lea    0x5619(%rip),%rax        # 11018 <fc12>
    b9ff:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    ba06:	48 c1 e1 10          	shl    $0x10,%rcx
    ba0a:	48 39 c8             	cmp    %rcx,%rax
    ba0d:	73 5f                	jae    ba6e <fwp_main_thread+0xbde>
    ba0f:	48 89 c1             	mov    %rax,%rcx
    ba12:	48 c1 e9 10          	shr    $0x10,%rcx
    ba16:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ba1a:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    ba21:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ba25:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    ba29:	48 85 ff             	test   %rdi,%rdi
    ba2c:	74 40                	je     ba6e <fwp_main_thread+0xbde>
    ba2e:	0f b6 31             	movzbl (%rcx),%esi
    ba31:	40 80 fe 02          	cmp    $0x2,%sil
    ba35:	0f 84 92 09 00 00    	je     c3cd <fwp_main_thread+0x153d>
    ba3b:	40 80 fe 01          	cmp    $0x1,%sil
    ba3f:	75 2d                	jne    ba6e <fwp_main_thread+0xbde>
    ba41:	8b 71 18             	mov    0x18(%rcx),%esi
    ba44:	0f b7 c0             	movzwl %ax,%eax
    ba47:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    ba4a:	48 0f af c6          	imul   %rsi,%rax
    ba4e:	48 c1 e8 20          	shr    $0x20,%rax
    ba52:	48 39 c8             	cmp    %rcx,%rax
    ba55:	73 17                	jae    ba6e <fwp_main_thread+0xbde>
    ba57:	48 01 c7             	add    %rax,%rdi
    ba5a:	0f b6 07             	movzbl (%rdi),%eax
    ba5d:	84 c0                	test   %al,%al
    ba5f:	74 0d                	je     ba6e <fwp_main_thread+0xbde>
    ba61:	3c fd                	cmp    $0xfd,%al
    ba63:	0f 87 fa 09 00 00    	ja     c463 <fwp_main_thread+0x15d3>
    ba69:	83 c0 01             	add    $0x1,%eax
    ba6c:	88 07                	mov    %al,(%rdi)
    ba6e:	48 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%rbx
    ba75:	4c 8d 3d 9c 55 00 00 	lea    0x559c(%rip),%r15        # 11018 <fc12>
    ba7c:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    ba83:	00 00 00 
    ba86:	4c 89 f8             	mov    %r15,%rax
    ba89:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
    ba90:	8b 9d 9c fe ff ff    	mov    -0x164(%rbp),%ebx
    ba96:	41 8b 4d 00          	mov    0x0(%r13),%ecx
    ba9a:	4d 89 fa             	mov    %r15,%r10
    ba9d:	2b 48 04             	sub    0x4(%rax),%ecx
    baa0:	41 8b 07             	mov    (%r15),%eax
    baa3:	39 d9                	cmp    %ebx,%ecx
    baa5:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    baac:	41 89 cc             	mov    %ecx,%r12d
    baaf:	0f 46 d9             	cmovbe %ecx,%ebx
    bab2:	48 c1 e0 05          	shl    $0x5,%rax
    bab6:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    baba:	4c 89 f8             	mov    %r15,%rax
    babd:	49 8b 50 18          	mov    0x18(%r8),%rdx
    bac1:	89 9d 8c fe ff ff    	mov    %ebx,-0x174(%rbp)
    bac7:	89 9d b8 fe ff ff    	mov    %ebx,-0x148(%rbp)
    bacd:	48 85 d2             	test   %rdx,%rdx
    bad0:	0f 84 61 02 00 00    	je     bd37 <fwp_main_thread+0xea7>
    bad6:	89 8d 88 fe ff ff    	mov    %ecx,-0x178(%rbp)
    badc:	eb 66                	jmp    bb44 <fwp_main_thread+0xcb4>
    bade:	66 90                	xchg   %ax,%ax
    bae0:	85 db                	test   %ebx,%ebx
    bae2:	0f 84 87 00 00 00    	je     bb6f <fwp_main_thread+0xcdf>
    bae8:	4c 89 ef             	mov    %r13,%rdi
    baeb:	ff 12                	call   *(%rdx)
    baed:	4c 89 ff             	mov    %r15,%rdi
    baf0:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    baf7:	e8 d4 b1 ff ff       	call   6cd0 <fwp_closure_drop>
    bafc:	44 3b a5 b8 fe ff ff 	cmp    -0x148(%rbp),%r12d
    bb03:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    bb0a:	0f 84 d0 07 00 00    	je     c2e0 <fwp_main_thread+0x1450>
    bb10:	8b 95 98 fe ff ff    	mov    -0x168(%rbp),%edx
    bb16:	44 8b 00             	mov    (%rax),%r8d
    bb19:	4f 8d 6c e5 00       	lea    0x0(%r13,%r12,8),%r13
    bb1e:	49 89 c2             	mov    %rax,%r10
    bb21:	29 da                	sub    %ebx,%edx
    bb23:	49 c1 e0 05          	shl    $0x5,%r8
    bb27:	4c 03 05 0a 79 01 00 	add    0x1790a(%rip),%r8        # 23438 <fwp_fns>
    bb2e:	89 95 b8 fe ff ff    	mov    %edx,-0x148(%rbp)
    bb34:	49 8b 50 18          	mov    0x18(%r8),%rdx
    bb38:	48 85 d2             	test   %rdx,%rdx
    bb3b:	0f 84 ef 01 00 00    	je     bd30 <fwp_main_thread+0xea0>
    bb41:	49 89 c7             	mov    %rax,%r15
    bb44:	41 8b 4a 04          	mov    0x4(%r10),%ecx
    bb48:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    bb4e:	41 8b 18             	mov    (%r8),%ebx
    bb51:	01 c8                	add    %ecx,%eax
    bb53:	89 85 98 fe ff ff    	mov    %eax,-0x168(%rbp)
    bb59:	39 d8                	cmp    %ebx,%eax
    bb5b:	0f 82 cf 04 00 00    	jb     c030 <fwp_main_thread+0x11a0>
    bb61:	41 89 dc             	mov    %ebx,%r12d
    bb64:	41 29 cc             	sub    %ecx,%r12d
    bb67:	85 c9                	test   %ecx,%ecx
    bb69:	0f 84 71 ff ff ff    	je     bae0 <fwp_main_thread+0xc50>
    bb6f:	85 db                	test   %ebx,%ebx
    bb71:	b8 01 00 00 00       	mov    $0x1,%eax
    bb76:	48 89 e6             	mov    %rsp,%rsi
    bb79:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    bb80:	0f 45 c3             	cmovne %ebx,%eax
    bb83:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    bb8a:	00 
    bb8b:	48 c1 e8 04          	shr    $0x4,%rax
    bb8f:	48 c1 e0 04          	shl    $0x4,%rax
    bb93:	48 89 c7             	mov    %rax,%rdi
    bb96:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bb9d:	48 29 fe             	sub    %rdi,%rsi
    bba0:	48 39 f4             	cmp    %rsi,%rsp
    bba3:	74 15                	je     bbba <fwp_main_thread+0xd2a>
    bba5:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    bbac:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    bbb3:	00 00 
    bbb5:	48 39 f4             	cmp    %rsi,%rsp
    bbb8:	75 eb                	jne    bba5 <fwp_main_thread+0xd15>
    bbba:	25 ff 0f 00 00       	and    $0xfff,%eax
    bbbf:	48 29 c4             	sub    %rax,%rsp
    bbc2:	48 85 c0             	test   %rax,%rax
    bbc5:	74 06                	je     bbcd <fwp_main_thread+0xd3d>
    bbc7:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    bbcd:	89 c8                	mov    %ecx,%eax
    bbcf:	48 89 a5 a8 fe ff ff 	mov    %rsp,-0x158(%rbp)
    bbd6:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    bbdd:	00 
    bbde:	31 c0                	xor    %eax,%eax
    bbe0:	85 c9                	test   %ecx,%ecx
    bbe2:	74 35                	je     bc19 <fwp_main_thread+0xd89>
    bbe4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bbea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bbf1:	00 00 00 00 
    bbf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bbfc:	00 00 00 00 
    bc00:	49 8b 7c 02 08       	mov    0x8(%r10,%rax,1),%rdi
    bc05:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    bc0c:	49 89 3c 03          	mov    %rdi,(%r11,%rax,1)
    bc10:	48 83 c0 08          	add    $0x8,%rax
    bc14:	48 39 c6             	cmp    %rax,%rsi
    bc17:	75 e7                	jne    bc00 <fwp_main_thread+0xd70>
    bc19:	45 85 e4             	test   %r12d,%r12d
    bc1c:	74 3e                	je     bc5c <fwp_main_thread+0xdcc>
    bc1e:	44 89 e0             	mov    %r12d,%eax
    bc21:	4c 89 ee             	mov    %r13,%rsi
    bc24:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
    bc29:	90                   	nop
    bc2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc31:	00 00 00 00 
    bc35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bc3c:	00 00 00 00 
    bc40:	4c 8b 0e             	mov    (%rsi),%r9
    bc43:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    bc4a:	89 cf                	mov    %ecx,%edi
    bc4c:	48 83 c6 08          	add    $0x8,%rsi
    bc50:	83 c1 01             	add    $0x1,%ecx
    bc53:	4d 89 0c fb          	mov    %r9,(%r11,%rdi,8)
    bc57:	48 39 f0             	cmp    %rsi,%rax
    bc5a:	75 e4                	jne    bc40 <fwp_main_thread+0xdb0>
    bc5c:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    bc63:	4c 89 f8             	mov    %r15,%rax
    bc66:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bc6d:	48 c1 e1 10          	shl    $0x10,%rcx
    bc71:	48 39 c8             	cmp    %rcx,%rax
    bc74:	73 50                	jae    bcc6 <fwp_main_thread+0xe36>
    bc76:	48 89 c1             	mov    %rax,%rcx
    bc79:	48 c1 e9 10          	shr    $0x10,%rcx
    bc7d:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    bc81:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    bc88:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    bc8c:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    bc90:	48 85 f6             	test   %rsi,%rsi
    bc93:	74 31                	je     bcc6 <fwp_main_thread+0xe36>
    bc95:	0f b6 39             	movzbl (%rcx),%edi
    bc98:	40 80 ff 02          	cmp    $0x2,%dil
    bc9c:	0f 84 86 00 00 00    	je     bd28 <fwp_main_thread+0xe98>
    bca2:	40 80 ff 01          	cmp    $0x1,%dil
    bca6:	75 1e                	jne    bcc6 <fwp_main_thread+0xe36>
    bca8:	8b 79 18             	mov    0x18(%rcx),%edi
    bcab:	0f b7 c0             	movzwl %ax,%eax
    bcae:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bcb1:	48 0f af c7          	imul   %rdi,%rax
    bcb5:	48 c1 e8 20          	shr    $0x20,%rax
    bcb9:	48 39 c8             	cmp    %rcx,%rax
    bcbc:	73 08                	jae    bcc6 <fwp_main_thread+0xe36>
    bcbe:	48 01 c6             	add    %rax,%rsi
    bcc1:	80 3e 01             	cmpb   $0x1,(%rsi)
    bcc4:	74 52                	je     bd18 <fwp_main_thread+0xe88>
    bcc6:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    bccd:	be 01 00 00 00       	mov    $0x1,%esi
    bcd2:	4c 89 ff             	mov    %r15,%rdi
    bcd5:	ff 52 08             	call   *0x8(%rdx)
    bcd8:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    bcdf:	49 8b 40 18          	mov    0x18(%r8),%rax
    bce3:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
    bcea:	ff 10                	call   *(%rax)
    bcec:	48 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%rsp
    bcf3:	e9 f5 fd ff ff       	jmp    baed <fwp_main_thread+0xc5d>
    bcf8:	48 8d 3d 61 8f ff ff 	lea    -0x709f(%rip),%rdi        # 4c60 <fwp_heap_report>
    bcff:	e8 fc 0b 00 00       	call   c900 <atexit>
    bd04:	e9 ce f1 ff ff       	jmp    aed7 <fwp_main_thread+0x47>
    bd09:	e8 62 90 ff ff       	call   4d70 <fwp_heap_init>
    bd0e:	e9 b4 f1 ff ff       	jmp    aec7 <fwp_main_thread+0x37>
    bd13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bd18:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    bd1f:	00 
    bd20:	eb bd                	jmp    bcdf <fwp_main_thread+0xe4f>
    bd22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bd28:	66 85 c0             	test   %ax,%ax
    bd2b:	75 99                	jne    bcc6 <fwp_main_thread+0xe36>
    bd2d:	eb 92                	jmp    bcc1 <fwp_main_thread+0xe31>
    bd2f:	90                   	nop
    bd30:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    bd37:	48 89 c7             	mov    %rax,%rdi
    bd3a:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    bd41:	e8 1a ab ff ff       	call   6860 <fwp_rc_share>
    bd46:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    bd4c:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    bd53:	85 d2                	test   %edx,%edx
    bd55:	74 35                	je     bd8c <fwp_main_thread+0xefc>
    bd57:	89 d1                	mov    %edx,%ecx
    bd59:	44 89 a5 b0 fe ff ff 	mov    %r12d,-0x150(%rbp)
    bd60:	49 89 c7             	mov    %rax,%r15
    bd63:	4d 89 ec             	mov    %r13,%r12
    bd66:	49 8d 5c cd 00       	lea    0x0(%r13,%rcx,8),%rbx
    bd6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bd70:	49 8b 3c 24          	mov    (%r12),%rdi
    bd74:	49 83 c4 08          	add    $0x8,%r12
    bd78:	e8 e3 aa ff ff       	call   6860 <fwp_rc_share>
    bd7d:	4c 39 e3             	cmp    %r12,%rbx
    bd80:	75 ee                	jne    bd70 <fwp_main_thread+0xee0>
    bd82:	44 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%r12d
    bd89:	4c 89 f8             	mov    %r15,%rax
    bd8c:	8b b5 b8 fe ff ff    	mov    -0x148(%rbp),%esi
    bd92:	4c 89 ea             	mov    %r13,%rdx
    bd95:	48 89 c7             	mov    %rax,%rdi
    bd98:	e8 13 a0 ff ff       	call   5db0 <fwp_apply>
    bd9d:	49 89 c7             	mov    %rax,%r15
    bda0:	8b bd 9c fe ff ff    	mov    -0x164(%rbp),%edi
    bda6:	41 39 fc             	cmp    %edi,%r12d
    bda9:	0f 83 8c 00 00 00    	jae    be3b <fwp_main_thread+0xfab>
    bdaf:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    bdb6:	8b 85 8c fe ff ff    	mov    -0x174(%rbp),%eax
    bdbc:	45 8b 2f             	mov    (%r15),%r13d
    bdbf:	48 89 c6             	mov    %rax,%rsi
    bdc2:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    bdc6:	48 8b 15 6b 76 01 00 	mov    0x1766b(%rip),%rdx        # 23438 <fwp_fns>
    bdcd:	49 c1 e5 05          	shl    $0x5,%r13
    bdd1:	29 f7                	sub    %esi,%edi
    bdd3:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    bdda:	4c 89 f8             	mov    %r15,%rax
    bddd:	49 01 d5             	add    %rdx,%r13
    bde0:	89 bd 9c fe ff ff    	mov    %edi,-0x164(%rbp)
    bde6:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
    bdeb:	0f 85 9f fc ff ff    	jne    ba90 <fwp_main_thread+0xc00>
    bdf1:	4c 89 ff             	mov    %r15,%rdi
    bdf4:	e8 67 aa ff ff       	call   6860 <fwp_rc_share>
    bdf9:	44 8b a5 9c fe ff ff 	mov    -0x164(%rbp),%r12d
    be00:	45 85 e4             	test   %r12d,%r12d
    be03:	74 1e                	je     be23 <fwp_main_thread+0xf93>
    be05:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    be0c:	31 db                	xor    %ebx,%ebx
    be0e:	66 90                	xchg   %ax,%ax
    be10:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    be15:	48 83 c3 01          	add    $0x1,%rbx
    be19:	e8 42 aa ff ff       	call   6860 <fwp_rc_share>
    be1e:	44 39 e3             	cmp    %r12d,%ebx
    be21:	72 ed                	jb     be10 <fwp_main_thread+0xf80>
    be23:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    be2a:	8b b5 9c fe ff ff    	mov    -0x164(%rbp),%esi
    be30:	4c 89 ff             	mov    %r15,%rdi
    be33:	e8 78 9f ff ff       	call   5db0 <fwp_apply>
    be38:	49 89 c7             	mov    %rax,%r15
    be3b:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    be42:	66 0f ef c0          	pxor   %xmm0,%xmm0
    be46:	b9 01 00 00 00       	mov    $0x1,%ecx
    be4b:	4c 89 fe             	mov    %r15,%rsi
    be4e:	48 8d 15 2b 4d 00 00 	lea    0x4d2b(%rip),%rdx        # 10b80 <d0>
    be55:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    be5c:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    be63:	00 00 00 00 
    be67:	e8 e4 df ff ff       	call   9e50 <fwp_write>
    be6c:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
    be73:	4c 8b ad f8 fe ff ff 	mov    -0x108(%rbp),%r13
    be7a:	48 8d 05 10 12 00 00 	lea    0x1210(%rip),%rax        # d091 <_IO_stdin_used+0x91>
    be81:	48 85 c9             	test   %rcx,%rcx
    be84:	48 0f 44 c8          	cmove  %rax,%rcx
    be88:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    be8c:	0f 87 f6 07 00 00    	ja     c688 <fwp_main_thread+0x17f8>
    be92:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    be96:	be 01 00 00 00       	mov    $0x1,%esi
    be9b:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    bea2:	e8 e9 9d ff ff       	call   5c90 <fwp_heap_alloc>
    bea7:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
    beae:	4c 89 ea             	mov    %r13,%rdx
    beb1:	4c 89 28             	mov    %r13,(%rax)
    beb4:	4c 8d 60 08          	lea    0x8(%rax),%r12
    beb8:	48 89 c3             	mov    %rax,%rbx
    bebb:	4c 89 e7             	mov    %r12,%rdi
    bebe:	e8 dd 76 ff ff       	call   35a0 <memcpy@plt>
    bec3:	42 c6 44 2b 08 00    	movb   $0x0,0x8(%rbx,%r13,1)
    bec9:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    bed0:	e8 eb 74 ff ff       	call   33c0 <free@plt>
    bed5:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bedc:	48 89 d8             	mov    %rbx,%rax
    bedf:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bee6:	48 c1 e2 10          	shl    $0x10,%rdx
    beea:	48 39 d0             	cmp    %rdx,%rax
    beed:	73 57                	jae    bf46 <fwp_main_thread+0x10b6>
    beef:	48 89 c2             	mov    %rax,%rdx
    bef2:	48 c1 ea 10          	shr    $0x10,%rdx
    bef6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    befa:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bf01:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    bf05:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    bf09:	48 85 d2             	test   %rdx,%rdx
    bf0c:	74 38                	je     bf46 <fwp_main_thread+0x10b6>
    bf0e:	0f b6 31             	movzbl (%rcx),%esi
    bf11:	40 80 fe 02          	cmp    $0x2,%sil
    bf15:	0f 84 ad 06 00 00    	je     c5c8 <fwp_main_thread+0x1738>
    bf1b:	40 80 fe 01          	cmp    $0x1,%sil
    bf1f:	75 25                	jne    bf46 <fwp_main_thread+0x10b6>
    bf21:	8b 71 18             	mov    0x18(%rcx),%esi
    bf24:	0f b7 c0             	movzwl %ax,%eax
    bf27:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bf2a:	48 0f af c6          	imul   %rsi,%rax
    bf2e:	48 c1 e8 20          	shr    $0x20,%rax
    bf32:	48 39 c8             	cmp    %rcx,%rax
    bf35:	73 0f                	jae    bf46 <fwp_main_thread+0x10b6>
    bf37:	48 01 c2             	add    %rax,%rdx
    bf3a:	80 3a ff             	cmpb   $0xff,(%rdx)
    bf3d:	0f 84 58 06 00 00    	je     c59b <fwp_main_thread+0x170b>
    bf43:	c6 02 01             	movb   $0x1,(%rdx)
    bf46:	4c 89 ff             	mov    %r15,%rdi
    bf49:	e8 a2 aa ff ff       	call   69f0 <fwp_drop0>
    bf4e:	48 8b 13             	mov    (%rbx),%rdx
    bf51:	be 01 00 00 00       	mov    $0x1,%esi
    bf56:	4c 89 e7             	mov    %r12,%rdi
    bf59:	48 8b 0d e0 74 01 00 	mov    0x174e0(%rip),%rcx        # 23440 <fwp_prog_out>
    bf60:	e8 1b 77 ff ff       	call   3680 <fwrite@plt>
    bf65:	48 8b 35 d4 74 01 00 	mov    0x174d4(%rip),%rsi        # 23440 <fwp_prog_out>
    bf6c:	bf 0a 00 00 00       	mov    $0xa,%edi
    bf71:	e8 6a 75 ff ff       	call   34e0 <fputc@plt>
    bf76:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    bf7d:	48 89 d8             	mov    %rbx,%rax
    bf80:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bf87:	48 c1 e2 10          	shl    $0x10,%rdx
    bf8b:	48 39 d0             	cmp    %rdx,%rax
    bf8e:	73 69                	jae    bff9 <fwp_main_thread+0x1169>
    bf90:	48 89 c2             	mov    %rax,%rdx
    bf93:	48 c1 ea 10          	shr    $0x10,%rdx
    bf97:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bf9b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bfa2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bfa6:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    bfaa:	4d 85 ed             	test   %r13,%r13
    bfad:	74 4a                	je     bff9 <fwp_main_thread+0x1169>
    bfaf:	0f b6 0a             	movzbl (%rdx),%ecx
    bfb2:	80 f9 02             	cmp    $0x2,%cl
    bfb5:	0f 84 37 05 00 00    	je     c4f2 <fwp_main_thread+0x1662>
    bfbb:	80 f9 01             	cmp    $0x1,%cl
    bfbe:	75 39                	jne    bff9 <fwp_main_thread+0x1169>
    bfc0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bfc3:	0f b7 c0             	movzwl %ax,%eax
    bfc6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bfc9:	48 0f af c1          	imul   %rcx,%rax
    bfcd:	48 c1 e8 20          	shr    $0x20,%rax
    bfd1:	48 39 d0             	cmp    %rdx,%rax
    bfd4:	73 23                	jae    bff9 <fwp_main_thread+0x1169>
    bfd6:	49 01 c5             	add    %rax,%r13
    bfd9:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    bfde:	84 c0                	test   %al,%al
    bfe0:	74 17                	je     bff9 <fwp_main_thread+0x1169>
    bfe2:	3c 01                	cmp    $0x1,%al
    bfe4:	0f 84 fb 04 00 00    	je     c4e5 <fwp_main_thread+0x1655>
    bfea:	3c ff                	cmp    $0xff,%al
    bfec:	0f 84 2e 05 00 00    	je     c520 <fwp_main_thread+0x1690>
    bff2:	83 e8 01             	sub    $0x1,%eax
    bff5:	41 88 45 00          	mov    %al,0x0(%r13)
    bff9:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
    c000:	48 8b 40 10          	mov    0x10(%rax),%rax
    c004:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    c00b:	48 85 c0             	test   %rax,%rax
    c00e:	0f 84 91 06 00 00    	je     c6a5 <fwp_main_thread+0x1815>
    c014:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    c01b:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c022:	e9 1c f9 ff ff       	jmp    b943 <fwp_main_thread+0xab3>
    c027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    c02e:	00 00 
    c030:	41 8b 96 a4 13 00 00 	mov    0x13a4(%r14),%edx
    c037:	8d 70 01             	lea    0x1(%rax),%esi
    c03a:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c041:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    c048:	00 
    c049:	85 d2                	test   %edx,%edx
    c04b:	0f 84 ac 03 00 00    	je     c3fd <fwp_main_thread+0x156d>
    c051:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    c058:	0f 87 9f 03 00 00    	ja     c3fd <fwp_main_thread+0x156d>
    c05e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    c062:	48 c1 e8 04          	shr    $0x4,%rax
    c066:	41 0f b6 94 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%edx
    c06d:	00 00 
    c06f:	41 8b 84 96 00 0f 00 	mov    0xf00(%r14,%rdx,4),%eax
    c076:	00 
    c077:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    c07b:	49 8d 14 d6          	lea    (%r14,%rdx,8),%rdx
    c07f:	48 8b 1a             	mov    (%rdx),%rbx
    c082:	48 85 db             	test   %rbx,%rbx
    c085:	0f 84 50 03 00 00    	je     c3db <fwp_main_thread+0x154b>
    c08b:	4c 8b 1b             	mov    (%rbx),%r11
    c08e:	49 f7 d3             	not    %r11
    c091:	4c 89 1a             	mov    %r11,(%rdx)
    c094:	48 39 c7             	cmp    %rax,%rdi
    c097:	73 61                	jae    c0fa <fwp_main_thread+0x126a>
    c099:	48 89 fa             	mov    %rdi,%rdx
    c09c:	48 83 c7 08          	add    $0x8,%rdi
    c0a0:	48 c7 04 f3 00 00 00 	movq   $0x0,(%rbx,%rsi,8)
    c0a7:	00 
    c0a8:	48 f7 d2             	not    %rdx
    c0ab:	48 01 c2             	add    %rax,%rdx
    c0ae:	48 c1 ea 03          	shr    $0x3,%rdx
    c0b2:	48 39 c7             	cmp    %rax,%rdi
    c0b5:	73 43                	jae    c0fa <fwp_main_thread+0x126a>
    c0b7:	83 e2 01             	and    $0x1,%edx
    c0ba:	74 24                	je     c0e0 <fwp_main_thread+0x1250>
    c0bc:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    c0c3:	00 
    c0c4:	48 83 c7 08          	add    $0x8,%rdi
    c0c8:	48 39 c7             	cmp    %rax,%rdi
    c0cb:	73 2d                	jae    c0fa <fwp_main_thread+0x126a>
    c0cd:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c0d4:	00 
    c0d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c0dc:	00 00 00 00 
    c0e0:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    c0e7:	00 
    c0e8:	48 c7 44 3b 08 00 00 	movq   $0x0,0x8(%rbx,%rdi,1)
    c0ef:	00 00 
    c0f1:	48 83 c7 10          	add    $0x10,%rdi
    c0f5:	48 39 c7             	cmp    %rax,%rdi
    c0f8:	72 e6                	jb     c0e0 <fwp_main_thread+0x1250>
    c0fa:	48 89 c2             	mov    %rax,%rdx
    c0fd:	49 03 96 20 14 00 00 	add    0x1420(%r14),%rdx
    c104:	0f 82 36 05 00 00    	jb     c640 <fwp_main_thread+0x17b0>
    c10a:	49 89 96 20 14 00 00 	mov    %rdx,0x1420(%r14)
    c111:	49 39 96 28 14 00 00 	cmp    %rdx,0x1428(%r14)
    c118:	73 07                	jae    c121 <fwp_main_thread+0x1291>
    c11a:	49 89 96 28 14 00 00 	mov    %rdx,0x1428(%r14)
    c121:	66 0f ef c0          	pxor   %xmm0,%xmm0
    c125:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    c12a:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    c131:	00 00 
    c133:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    c13a:	00 00 
    c13c:	66 41 0f 6e 02       	movd   (%r10),%xmm0
    c141:	66 0f 6e 8d 98 fe ff 	movd   -0x168(%rbp),%xmm1
    c148:	ff 
    c149:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    c14d:	66 0f d6 03          	movq   %xmm0,(%rbx)
    c151:	85 c9                	test   %ecx,%ecx
    c153:	74 3b                	je     c190 <fwp_main_thread+0x1300>
    c155:	89 ca                	mov    %ecx,%edx
    c157:	49 8d 72 08          	lea    0x8(%r10),%rsi
    c15b:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    c15f:	89 8d a8 fe ff ff    	mov    %ecx,-0x158(%rbp)
    c165:	48 c1 e2 03          	shl    $0x3,%rdx
    c169:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    c170:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c177:	e8 94 74 ff ff       	call   3610 <memmove@plt>
    c17c:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c183:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
    c189:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    c190:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    c196:	85 c0                	test   %eax,%eax
    c198:	74 3c                	je     c1d6 <fwp_main_thread+0x1346>
    c19a:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    c1a0:	4c 89 e8             	mov    %r13,%rax
    c1a3:	49 8d 7c d5 00       	lea    0x0(%r13,%rdx,8),%rdi
    c1a8:	66 90                	xchg   %ax,%ax
    c1aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c1b1:	00 00 00 00 
    c1b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c1bc:	00 00 00 00 
    c1c0:	48 8b 30             	mov    (%rax),%rsi
    c1c3:	89 ca                	mov    %ecx,%edx
    c1c5:	48 83 c0 08          	add    $0x8,%rax
    c1c9:	83 c1 01             	add    $0x1,%ecx
    c1cc:	48 89 74 d3 08       	mov    %rsi,0x8(%rbx,%rdx,8)
    c1d1:	48 39 c7             	cmp    %rax,%rdi
    c1d4:	75 ea                	jne    c1c0 <fwp_main_thread+0x1330>
    c1d6:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c1dd:	4c 89 f8             	mov    %r15,%rax
    c1e0:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c1e7:	48 c1 e2 10          	shl    $0x10,%rdx
    c1eb:	48 39 d0             	cmp    %rdx,%rax
    c1ee:	73 54                	jae    c244 <fwp_main_thread+0x13b4>
    c1f0:	48 89 c2             	mov    %rax,%rdx
    c1f3:	48 c1 ea 10          	shr    $0x10,%rdx
    c1f7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c1fb:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c202:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c206:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    c20a:	48 85 c9             	test   %rcx,%rcx
    c20d:	74 35                	je     c244 <fwp_main_thread+0x13b4>
    c20f:	0f b6 32             	movzbl (%rdx),%esi
    c212:	40 80 fe 02          	cmp    $0x2,%sil
    c216:	0f 84 39 02 00 00    	je     c455 <fwp_main_thread+0x15c5>
    c21c:	40 80 fe 01          	cmp    $0x1,%sil
    c220:	75 22                	jne    c244 <fwp_main_thread+0x13b4>
    c222:	8b 72 18             	mov    0x18(%rdx),%esi
    c225:	0f b7 c0             	movzwl %ax,%eax
    c228:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c22b:	48 0f af c6          	imul   %rsi,%rax
    c22f:	48 c1 e8 20          	shr    $0x20,%rax
    c233:	48 39 d0             	cmp    %rdx,%rax
    c236:	73 0c                	jae    c244 <fwp_main_thread+0x13b4>
    c238:	48 01 c1             	add    %rax,%rcx
    c23b:	80 39 01             	cmpb   $0x1,(%rcx)
    c23e:	0f 84 7c 01 00 00    	je     c3c0 <fwp_main_thread+0x1530>
    c244:	49 8b 40 18          	mov    0x18(%r8),%rax
    c248:	be 01 00 00 00       	mov    $0x1,%esi
    c24d:	4c 89 ff             	mov    %r15,%rdi
    c250:	ff 50 08             	call   *0x8(%rax)
    c253:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c25a:	48 89 d8             	mov    %rbx,%rax
    c25d:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c264:	48 c1 e2 10          	shl    $0x10,%rdx
    c268:	48 39 d0             	cmp    %rdx,%rax
    c26b:	73 5b                	jae    c2c8 <fwp_main_thread+0x1438>
    c26d:	48 89 c2             	mov    %rax,%rdx
    c270:	48 c1 ea 10          	shr    $0x10,%rdx
    c274:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c278:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c27f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    c283:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    c287:	4d 85 ed             	test   %r13,%r13
    c28a:	74 3c                	je     c2c8 <fwp_main_thread+0x1438>
    c28c:	0f b6 31             	movzbl (%rcx),%esi
    c28f:	40 80 fe 02          	cmp    $0x2,%sil
    c293:	0f 84 9b 01 00 00    	je     c434 <fwp_main_thread+0x15a4>
    c299:	40 80 fe 01          	cmp    $0x1,%sil
    c29d:	75 29                	jne    c2c8 <fwp_main_thread+0x1438>
    c29f:	8b 71 18             	mov    0x18(%rcx),%esi
    c2a2:	0f b7 c0             	movzwl %ax,%eax
    c2a5:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    c2a8:	48 0f af c6          	imul   %rsi,%rax
    c2ac:	48 c1 e8 20          	shr    $0x20,%rax
    c2b0:	48 39 c8             	cmp    %rcx,%rax
    c2b3:	73 13                	jae    c2c8 <fwp_main_thread+0x1438>
    c2b5:	49 01 c5             	add    %rax,%r13
    c2b8:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c2bd:	0f 84 85 01 00 00    	je     c448 <fwp_main_thread+0x15b8>
    c2c3:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    c2c8:	4c 89 ff             	mov    %r15,%rdi
    c2cb:	49 89 df             	mov    %rbx,%r15
    c2ce:	e8 fd a9 ff ff       	call   6cd0 <fwp_closure_drop>
    c2d3:	e9 c8 fa ff ff       	jmp    bda0 <fwp_main_thread+0xf10>
    c2d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c2df:	00 
    c2e0:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c2e7:	49 89 c7             	mov    %rax,%r15
    c2ea:	e9 b1 fa ff ff       	jmp    bda0 <fwp_main_thread+0xf10>
    c2ef:	90                   	nop
    c2f0:	41 8b 75 00          	mov    0x0(%r13),%esi
    c2f4:	8b 05 22 4d 00 00    	mov    0x4d22(%rip),%eax        # 1101c <fc12+0x4>
    c2fa:	89 f7                	mov    %esi,%edi
    c2fc:	29 c7                	sub    %eax,%edi
    c2fe:	83 ff 01             	cmp    $0x1,%edi
    c301:	0f 85 ea f6 ff ff    	jne    b9f1 <fwp_main_thread+0xb61>
    c307:	48 89 e3             	mov    %rsp,%rbx
    c30a:	85 c0                	test   %eax,%eax
    c30c:	0f 84 6c 01 00 00    	je     c47e <fwp_main_thread+0x15ee>
    c312:	89 f1                	mov    %esi,%ecx
    c314:	ba 08 00 00 00       	mov    $0x8,%edx
    c319:	48 c1 e1 03          	shl    $0x3,%rcx
    c31d:	85 f6                	test   %esi,%esi
    c31f:	48 89 e6             	mov    %rsp,%rsi
    c322:	48 0f 45 d1          	cmovne %rcx,%rdx
    c326:	49 89 d7             	mov    %rdx,%r15
    c329:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    c32d:	48 c1 ea 04          	shr    $0x4,%rdx
    c331:	48 c1 e2 04          	shl    $0x4,%rdx
    c335:	48 89 d7             	mov    %rdx,%rdi
    c338:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    c33f:	48 29 fe             	sub    %rdi,%rsi
    c342:	48 39 f4             	cmp    %rsi,%rsp
    c345:	74 15                	je     c35c <fwp_main_thread+0x14cc>
    c347:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    c34e:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    c355:	00 00 
    c357:	48 39 f4             	cmp    %rsi,%rsp
    c35a:	75 eb                	jne    c347 <fwp_main_thread+0x14b7>
    c35c:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    c362:	48 29 d4             	sub    %rdx,%rsp
    c365:	48 85 d2             	test   %rdx,%rdx
    c368:	74 06                	je     c370 <fwp_main_thread+0x14e0>
    c36a:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    c370:	4c 8d 24 c5 00 00 00 	lea    0x0(,%rax,8),%r12
    c377:	00 
    c378:	4c 89 f9             	mov    %r15,%rcx
    c37b:	48 8d 35 9e 4c 00 00 	lea    0x4c9e(%rip),%rsi        # 11020 <descent_active_phase>
    c382:	48 89 e7             	mov    %rsp,%rdi
    c385:	4c 89 e2             	mov    %r12,%rdx
    c388:	e8 e3 71 ff ff       	call   3570 <__memcpy_chk@plt>
    c38d:	4d 39 e7             	cmp    %r12,%r15
    c390:	4c 89 f9             	mov    %r15,%rcx
    c393:	4a 8d 3c 24          	lea    (%rsp,%r12,1),%rdi
    c397:	49 0f 42 cc          	cmovb  %r12,%rcx
    c39b:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    c3a2:	ba 08 00 00 00       	mov    $0x8,%edx
    c3a7:	4c 29 e1             	sub    %r12,%rcx
    c3aa:	e8 c1 71 ff ff       	call   3570 <__memcpy_chk@plt>
    c3af:	49 8b 45 18          	mov    0x18(%r13),%rax
    c3b3:	48 89 e7             	mov    %rsp,%rdi
    c3b6:	ff 10                	call   *(%rax)
    c3b8:	49 89 c7             	mov    %rax,%r15
    c3bb:	e9 ca 00 00 00       	jmp    c48a <fwp_main_thread+0x15fa>
    c3c0:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    c3c7:	00 
    c3c8:	e9 86 fe ff ff       	jmp    c253 <fwp_main_thread+0x13c3>
    c3cd:	66 85 c0             	test   %ax,%ax
    c3d0:	0f 85 98 f6 ff ff    	jne    ba6e <fwp_main_thread+0xbde>
    c3d6:	e9 7f f6 ff ff       	jmp    ba5a <fwp_main_thread+0xbca>
    c3db:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    c3df:	48 85 db             	test   %rbx,%rbx
    c3e2:	74 19                	je     c3fd <fwp_main_thread+0x156d>
    c3e4:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    c3e8:	49 29 db             	sub    %rbx,%r11
    c3eb:	49 39 c3             	cmp    %rax,%r11
    c3ee:	72 0d                	jb     c3fd <fwp_main_thread+0x156d>
    c3f0:	4c 8d 1c 03          	lea    (%rbx,%rax,1),%r11
    c3f4:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    c3f8:	e9 97 fc ff ff       	jmp    c094 <fwp_main_thread+0x1204>
    c3fd:	31 f6                	xor    %esi,%esi
    c3ff:	89 8d 90 fe ff ff    	mov    %ecx,-0x170(%rbp)
    c405:	4c 89 85 a8 fe ff ff 	mov    %r8,-0x158(%rbp)
    c40c:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c413:	e8 78 98 ff ff       	call   5c90 <fwp_heap_alloc>
    c418:	8b 8d 90 fe ff ff    	mov    -0x170(%rbp),%ecx
    c41e:	4c 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%r8
    c425:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c42c:	48 89 c3             	mov    %rax,%rbx
    c42f:	e9 08 fd ff ff       	jmp    c13c <fwp_main_thread+0x12ac>
    c434:	66 85 c0             	test   %ax,%ax
    c437:	0f 85 8b fe ff ff    	jne    c2c8 <fwp_main_thread+0x1438>
    c43d:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c442:	0f 85 7b fe ff ff    	jne    c2c3 <fwp_main_thread+0x1433>
    c448:	4c 89 ef             	mov    %r13,%rdi
    c44b:	e8 00 91 ff ff       	call   5550 <fwp_rc_forget_slot>
    c450:	e9 6e fe ff ff       	jmp    c2c3 <fwp_main_thread+0x1433>
    c455:	66 85 c0             	test   %ax,%ax
    c458:	0f 85 e6 fd ff ff    	jne    c244 <fwp_main_thread+0x13b4>
    c45e:	e9 d8 fd ff ff       	jmp    c23b <fwp_main_thread+0x13ab>
    c463:	e8 c8 8f ff ff       	call   5430 <fwp_rc_wide_dup>
    c468:	48 8b 15 c9 6f 01 00 	mov    0x16fc9(%rip),%rdx        # 23438 <fwp_fns>
    c46f:	e9 fa f5 ff ff       	jmp    ba6e <fwp_main_thread+0xbde>
    c474:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    c479:	e9 fe eb ff ff       	jmp    b07c <fwp_main_thread+0x1ec>
    c47e:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
    c485:	ff 11                	call   *(%rcx)
    c487:	49 89 c7             	mov    %rax,%r15
    c48a:	48 89 dc             	mov    %rbx,%rsp
    c48d:	e9 a9 f9 ff ff       	jmp    be3b <fwp_main_thread+0xfab>
    c492:	66 85 c0             	test   %ax,%ax
    c495:	0f 85 cc f3 ff ff    	jne    b867 <fwp_main_thread+0x9d7>
    c49b:	e9 bb f3 ff ff       	jmp    b85b <fwp_main_thread+0x9cb>
    c4a0:	66 85 c0             	test   %ax,%ax
    c4a3:	0f 85 18 f3 ff ff    	jne    b7c1 <fwp_main_thread+0x931>
    c4a9:	e9 07 f3 ff ff       	jmp    b7b5 <fwp_main_thread+0x925>
    c4ae:	66 85 c0             	test   %ax,%ax
    c4b1:	0f 85 fc f4 ff ff    	jne    b9b3 <fwp_main_thread+0xb23>
    c4b7:	e9 e3 f4 ff ff       	jmp    b99f <fwp_main_thread+0xb0f>
    c4bc:	66 85 c0             	test   %ax,%ax
    c4bf:	0f 85 62 f4 ff ff    	jne    b927 <fwp_main_thread+0xa97>
    c4c5:	e9 43 f4 ff ff       	jmp    b90d <fwp_main_thread+0xa7d>
    c4ca:	48 89 d7             	mov    %rdx,%rdi
    c4cd:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c4d4:	e8 77 90 ff ff       	call   5550 <fwp_rc_forget_slot>
    c4d9:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c4e0:	e9 97 f1 ff ff       	jmp    b67c <fwp_main_thread+0x7ec>
    c4e5:	48 89 df             	mov    %rbx,%rdi
    c4e8:	e8 f3 a3 ff ff       	call   68e0 <fwp_rc_free_arr>
    c4ed:	e9 07 fb ff ff       	jmp    bff9 <fwp_main_thread+0x1169>
    c4f2:	66 85 c0             	test   %ax,%ax
    c4f5:	0f 85 fe fa ff ff    	jne    bff9 <fwp_main_thread+0x1169>
    c4fb:	e9 d9 fa ff ff       	jmp    bfd9 <fwp_main_thread+0x1149>
    c500:	48 83 3d b0 52 01 00 	cmpq   $0x0,0x152b0(%rip)        # 217b8 <fwp_root>
    c507:	00 
    c508:	c7 05 8e 4b 01 00 00 	movl   $0x0,0x14b8e(%rip)        # 210a0 <fwp_exit_code>
    c50f:	00 00 00 
    c512:	0f 84 42 ee ff ff    	je     b35a <fwp_main_thread+0x4ca>
    c518:	e9 33 72 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c51d:	0f 1f 00             	nopl   (%rax)
    c520:	4c 89 e8             	mov    %r13,%rax
    c523:	48 c1 e8 11          	shr    $0x11,%rax
    c527:	4c 31 e8             	xor    %r13,%rax
    c52a:	48 89 c2             	mov    %rax,%rdx
    c52d:	48 c1 ea 09          	shr    $0x9,%rdx
    c531:	48 31 d0             	xor    %rdx,%rax
    c534:	0f b6 c0             	movzbl %al,%eax
    c537:	49 8b 94 c6 48 14 00 	mov    0x1448(%r14,%rax,8),%rdx
    c53e:	00 
    c53f:	48 85 d2             	test   %rdx,%rdx
    c542:	75 25                	jne    c569 <fwp_main_thread+0x16d9>
    c544:	eb 70                	jmp    c5b6 <fwp_main_thread+0x1726>
    c546:	0f 1f 40 00          	nopl   0x0(%rax)
    c54a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c551:	00 00 00 00 
    c555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c55c:	00 00 00 00 
    c560:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c564:	48 85 d2             	test   %rdx,%rdx
    c567:	74 4d                	je     c5b6 <fwp_main_thread+0x1726>
    c569:	48 89 d0             	mov    %rdx,%rax
    c56c:	4c 39 2a             	cmp    %r13,(%rdx)
    c56f:	75 ef                	jne    c560 <fwp_main_thread+0x16d0>
    c571:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c575:	48 83 e8 01          	sub    $0x1,%rax
    c579:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c57d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c583:	0f 85 70 fa ff ff    	jne    bff9 <fwp_main_thread+0x1169>
    c589:	4c 89 ef             	mov    %r13,%rdi
    c58c:	e8 bf 8f ff ff       	call   5550 <fwp_rc_forget_slot>
    c591:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    c596:	e9 5e fa ff ff       	jmp    bff9 <fwp_main_thread+0x1169>
    c59b:	48 89 d7             	mov    %rdx,%rdi
    c59e:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c5a5:	e8 a6 8f ff ff       	call   5550 <fwp_rc_forget_slot>
    c5aa:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c5b1:	e9 8d f9 ff ff       	jmp    bf43 <fwp_main_thread+0x10b3>
    c5b6:	48 8d 3d cb 12 00 00 	lea    0x12cb(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    c5bd:	e8 2e 7e ff ff       	call   43f0 <fwp_trap>
    c5c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c5c8:	66 85 c0             	test   %ax,%ax
    c5cb:	0f 85 75 f9 ff ff    	jne    bf46 <fwp_main_thread+0x10b6>
    c5d1:	e9 64 f9 ff ff       	jmp    bf3a <fwp_main_thread+0x10aa>
    c5d6:	48 89 df             	mov    %rbx,%rdi
    c5d9:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c5e0:	e8 6b 8f ff ff       	call   5550 <fwp_rc_forget_slot>
    c5e5:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c5ec:	e9 cd f1 ff ff       	jmp    b7be <fwp_main_thread+0x92e>
    c5f1:	48 89 df             	mov    %rbx,%rdi
    c5f4:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c5fb:	e8 50 8f ff ff       	call   5550 <fwp_rc_forget_slot>
    c600:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c607:	e9 58 f2 ff ff       	jmp    b864 <fwp_main_thread+0x9d4>
    c60c:	48 89 df             	mov    %rbx,%rdi
    c60f:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c616:	e8 35 8f ff ff       	call   5550 <fwp_rc_forget_slot>
    c61b:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c622:	e9 ef f2 ff ff       	jmp    b916 <fwp_main_thread+0xa86>
    c627:	e8 04 8e ff ff       	call   5430 <fwp_rc_wide_dup>
    c62c:	e9 82 f3 ff ff       	jmp    b9b3 <fwp_main_thread+0xb23>
    c631:	e8 aa 77 ff ff       	call   3de0 <descent_phase_fail>
    c636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c63d:	00 00 00 
    c640:	e8 6b 76 ff ff       	call   3cb0 <fwp_heap_oom>
    c645:	48 89 c8             	mov    %rcx,%rax
    c648:	e9 79 ec ff ff       	jmp    b2c6 <fwp_main_thread+0x436>
    c64d:	0f 1f 00             	nopl   (%rax)
    c650:	48 89 c7             	mov    %rax,%rdi
    c653:	4c 8d 3d be 49 00 00 	lea    0x49be(%rip),%r15        # 11018 <fc12>
    c65a:	e8 01 a2 ff ff       	call   6860 <fwp_rc_share>
    c65f:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c666:	e8 f5 a1 ff ff       	call   6860 <fwp_rc_share>
    c66b:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    c672:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    c679:	00 00 00 
    c67c:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c683:	e9 9b f7 ff ff       	jmp    be23 <fwp_main_thread+0xf93>
    c688:	48 8d 3d b7 0b 00 00 	lea    0xbb7(%rip),%rdi        # d246 <_IO_stdin_used+0x246>
    c68f:	e8 5c 7d ff ff       	call   43f0 <fwp_trap>
    c694:	e8 c7 6d ff ff       	call   3460 <__stack_chk_fail@plt>
    c699:	48 8d 3d 40 13 00 00 	lea    0x1340(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    c6a0:	e8 4b 7d ff ff       	call   43f0 <fwp_trap>
    c6a5:	4c 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%r8
    c6ac:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c6b3:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c6ba:	e8 31 a3 ff ff       	call   69f0 <fwp_drop0>
    c6bf:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
    c6c6:	e8 25 a3 ff ff       	call   69f0 <fwp_drop0>
    c6cb:	48 c7 05 b2 49 00 00 	movq   $0x0,0x49b2(%rip)        # 11088 <v.2>
    c6d2:	00 00 00 00 
    c6d6:	c7 05 b0 49 00 00 01 	movl   $0x1,0x49b0(%rip)        # 11090 <st.3>
    c6dd:	00 00 00 
    c6e0:	e9 d9 e8 ff ff       	jmp    afbe <fwp_main_thread+0x12e>
    c6e5:	e9 66 70 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c6ea:	e9 61 70 ff ff       	jmp    3750 <fwp_main_thread.cold>
    c6ef:	90                   	nop

000000000000c6f0 <__divmodti4>:
    c6f0:	f3 0f 1e fa          	endbr64
    c6f4:	55                   	push   %rbp
    c6f5:	49 89 f1             	mov    %rsi,%r9
    c6f8:	49 89 d2             	mov    %rdx,%r10
    c6fb:	48 89 fe             	mov    %rdi,%rsi
    c6fe:	49 89 cb             	mov    %rcx,%r11
    c701:	48 89 e5             	mov    %rsp,%rbp
    c704:	41 57                	push   %r15
    c706:	41 56                	push   %r14
    c708:	41 55                	push   %r13
    c70a:	41 54                	push   %r12
    c70c:	53                   	push   %rbx
    c70d:	4c 89 c3             	mov    %r8,%rbx
    c710:	45 31 c0             	xor    %r8d,%r8d
    c713:	4d 85 c9             	test   %r9,%r9
    c716:	79 12                	jns    c72a <__divmodti4+0x3a>
    c718:	31 ff                	xor    %edi,%edi
    c71a:	48 f7 de             	neg    %rsi
    c71d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    c724:	4c 19 cf             	sbb    %r9,%rdi
    c727:	49 89 f9             	mov    %rdi,%r9
    c72a:	4c 89 d8             	mov    %r11,%rax
    c72d:	4d 85 db             	test   %r11,%r11
    c730:	0f 88 1a 01 00 00    	js     c850 <__divmodti4+0x160>
    c736:	4c 89 d9             	mov    %r11,%rcx
    c739:	49 89 f3             	mov    %rsi,%r11
    c73c:	75 62                	jne    c7a0 <__divmodti4+0xb0>
    c73e:	4d 89 c4             	mov    %r8,%r12
    c741:	4d 39 d1             	cmp    %r10,%r9
    c744:	0f 83 46 01 00 00    	jae    c890 <__divmodti4+0x1a0>
    c74a:	4c 89 d8             	mov    %r11,%rax
    c74d:	4c 89 ca             	mov    %r9,%rdx
    c750:	49 f7 f2             	div    %r10
    c753:	49 89 c3             	mov    %rax,%r11
    c756:	31 c0                	xor    %eax,%eax
    c758:	48 89 d6             	mov    %rdx,%rsi
    c75b:	31 ff                	xor    %edi,%edi
    c75d:	4c 89 d9             	mov    %r11,%rcx
    c760:	48 89 c2             	mov    %rax,%rdx
    c763:	48 89 c8             	mov    %rcx,%rax
    c766:	4d 85 e4             	test   %r12,%r12
    c769:	74 0a                	je     c775 <__divmodti4+0x85>
    c76b:	48 f7 d8             	neg    %rax
    c76e:	48 83 d2 00          	adc    $0x0,%rdx
    c772:	48 f7 da             	neg    %rdx
    c775:	4d 85 c0             	test   %r8,%r8
    c778:	74 0a                	je     c784 <__divmodti4+0x94>
    c77a:	48 f7 de             	neg    %rsi
    c77d:	48 83 d7 00          	adc    $0x0,%rdi
    c781:	48 f7 df             	neg    %rdi
    c784:	48 89 33             	mov    %rsi,(%rbx)
    c787:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c78b:	5b                   	pop    %rbx
    c78c:	41 5c                	pop    %r12
    c78e:	41 5d                	pop    %r13
    c790:	41 5e                	pop    %r14
    c792:	41 5f                	pop    %r15
    c794:	5d                   	pop    %rbp
    c795:	c3                   	ret
    c796:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c79d:	00 00 00 
    c7a0:	4d 89 c4             	mov    %r8,%r12
    c7a3:	49 39 c1             	cmp    %rax,%r9
    c7a6:	0f 82 ce 00 00 00    	jb     c87a <__divmodti4+0x18a>
    c7ac:	31 ff                	xor    %edi,%edi
    c7ae:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c7b3:	48 63 c7             	movslq %edi,%rax
    c7b6:	be 40 00 00 00       	mov    $0x40,%esi
    c7bb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c7c0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c7c5:	48 29 c6             	sub    %rax,%rsi
    c7c8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c7cd:	48 09 c8             	or     %rcx,%rax
    c7d0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c7d5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c7da:	49 89 c6             	mov    %rax,%r14
    c7dd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c7e1:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c7e6:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c7eb:	49 09 c1             	or     %rax,%r9
    c7ee:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c7f2:	4c 89 c8             	mov    %r9,%rax
    c7f5:	49 f7 f6             	div    %r14
    c7f8:	48 89 d1             	mov    %rdx,%rcx
    c7fb:	49 89 c3             	mov    %rax,%r11
    c7fe:	49 89 c1             	mov    %rax,%r9
    c801:	49 f7 e2             	mul    %r10
    c804:	49 89 c6             	mov    %rax,%r14
    c807:	49 89 d2             	mov    %rdx,%r10
    c80a:	48 39 d1             	cmp    %rdx,%rcx
    c80d:	72 07                	jb     c816 <__divmodti4+0x126>
    c80f:	75 17                	jne    c828 <__divmodti4+0x138>
    c811:	49 39 c7             	cmp    %rax,%r15
    c814:	73 12                	jae    c828 <__divmodti4+0x138>
    c816:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c81a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c81e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c822:	49 89 d2             	mov    %rdx,%r10
    c825:	49 89 c6             	mov    %rax,%r14
    c828:	4c 89 f8             	mov    %r15,%rax
    c82b:	4c 29 f0             	sub    %r14,%rax
    c82e:	4c 19 d1             	sbb    %r10,%rcx
    c831:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c836:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c83b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c840:	48 09 c6             	or     %rax,%rsi
    c843:	48 89 cf             	mov    %rcx,%rdi
    c846:	31 c0                	xor    %eax,%eax
    c848:	4c 89 c9             	mov    %r9,%rcx
    c84b:	e9 10 ff ff ff       	jmp    c760 <__divmodti4+0x70>
    c850:	4c 89 d0             	mov    %r10,%rax
    c853:	4c 89 da             	mov    %r11,%rdx
    c856:	4d 89 c4             	mov    %r8,%r12
    c859:	49 89 f3             	mov    %rsi,%r11
    c85c:	48 f7 d8             	neg    %rax
    c85f:	49 f7 d4             	not    %r12
    c862:	48 83 d2 00          	adc    $0x0,%rdx
    c866:	49 89 c2             	mov    %rax,%r10
    c869:	48 f7 da             	neg    %rdx
    c86c:	48 89 d1             	mov    %rdx,%rcx
    c86f:	0f 84 cc fe ff ff    	je     c741 <__divmodti4+0x51>
    c875:	49 39 d1             	cmp    %rdx,%r9
    c878:	73 46                	jae    c8c0 <__divmodti4+0x1d0>
    c87a:	4c 89 cf             	mov    %r9,%rdi
    c87d:	31 c0                	xor    %eax,%eax
    c87f:	31 c9                	xor    %ecx,%ecx
    c881:	e9 da fe ff ff       	jmp    c760 <__divmodti4+0x70>
    c886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c88d:	00 00 00 
    c890:	4d 85 d2             	test   %r10,%r10
    c893:	75 0d                	jne    c8a2 <__divmodti4+0x1b2>
    c895:	b8 01 00 00 00       	mov    $0x1,%eax
    c89a:	31 d2                	xor    %edx,%edx
    c89c:	49 f7 f2             	div    %r10
    c89f:	49 89 c2             	mov    %rax,%r10
    c8a2:	4c 89 c8             	mov    %r9,%rax
    c8a5:	31 d2                	xor    %edx,%edx
    c8a7:	49 f7 f2             	div    %r10
    c8aa:	49 89 c1             	mov    %rax,%r9
    c8ad:	4c 89 d8             	mov    %r11,%rax
    c8b0:	49 f7 f2             	div    %r10
    c8b3:	49 89 c3             	mov    %rax,%r11
    c8b6:	4c 89 c8             	mov    %r9,%rax
    c8b9:	e9 9a fe ff ff       	jmp    c758 <__divmodti4+0x68>
    c8be:	66 90                	xchg   %ax,%ax
    c8c0:	45 31 f6             	xor    %r14d,%r14d
    c8c3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c8c8:	44 89 f7             	mov    %r14d,%edi
    c8cb:	45 85 f6             	test   %r14d,%r14d
    c8ce:	0f 85 df fe ff ff    	jne    c7b3 <__divmodti4+0xc3>
    c8d4:	4c 39 ca             	cmp    %r9,%rdx
    c8d7:	72 17                	jb     c8f0 <__divmodti4+0x200>
    c8d9:	31 c9                	xor    %ecx,%ecx
    c8db:	48 39 c6             	cmp    %rax,%rsi
    c8de:	73 10                	jae    c8f0 <__divmodti4+0x200>
    c8e0:	4c 89 cf             	mov    %r9,%rdi
    c8e3:	31 c0                	xor    %eax,%eax
    c8e5:	e9 76 fe ff ff       	jmp    c760 <__divmodti4+0x70>
    c8ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c8f0:	4c 89 de             	mov    %r11,%rsi
    c8f3:	b9 01 00 00 00       	mov    $0x1,%ecx
    c8f8:	48 29 c6             	sub    %rax,%rsi
    c8fb:	49 19 d1             	sbb    %rdx,%r9
    c8fe:	eb e0                	jmp    c8e0 <__divmodti4+0x1f0>

000000000000c900 <atexit>:
    c900:	f3 0f 1e fa          	endbr64
    c904:	48 8b 15 fd 46 00 00 	mov    0x46fd(%rip),%rdx        # 11008 <__dso_handle>
    c90b:	31 f6                	xor    %esi,%esi
    c90d:	e9 4e 6d ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c914 <_fini>:
    c914:	f3 0f 1e fa          	endbr64
    c918:	48 83 ec 08          	sub    $0x8,%rsp
    c91c:	48 83 c4 08          	add    $0x8,%rsp
    c920:	c3                   	ret
