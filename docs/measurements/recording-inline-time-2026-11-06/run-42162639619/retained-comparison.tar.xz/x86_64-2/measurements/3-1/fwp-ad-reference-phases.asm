
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 cf 00 00 	mov    0xcfc1(%rip),%rax        # ffd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da cd 00 00    	push   0xcdda(%rip)        # fe00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc cd 00 00    	jmp    *0xcddc(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 cc 00 00    	jmp    *0xcc46(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fe90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fe98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # fea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # fea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # feb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # feb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # fef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # fef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ff90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ff98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be c8 00 00    	jmp    *0xc8be(%rip)        # ffb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 89 00 00 	lea    0x89dd(%rip),%r9        # c0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 89 00 00 	lea    0x89da(%rip),%r8        # c0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 81 ab 00 00 	lea    0xab81(%rip),%rax        # e300 <fwp_fn_table>
    377f:	48 89 05 92 ec 01 00 	mov    %rax,0x1ec92(%rip)        # 22418 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 8c ec 01 00 	mov    %rax,0x1ec8c(%rip)        # 22420 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 8a 00 00 	lea    0x8ab7(%rip),%rdi        # c257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 3f 5b 00 00 	lea    0x5b3f(%rip),%rdx        # 93a0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 89 00 00 	lea    0x8967(%rip),%rdi        # c260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 86 91 00 00 	lea    0x9186(%rip),%rdi        # ca90 <_IO_stdin_used+0xa90>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 40 91 00 00 	lea    0x9140(%rip),%rdi        # ca68 <_IO_stdin_used+0xa68>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d 04 91 00 00 	lea    0x9104(%rip),%rdi        # ca38 <_IO_stdin_used+0xa38>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d d0 90 00 00 	lea    0x90d0(%rip),%rdi        # ca10 <_IO_stdin_used+0xa10>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b c6 00 00    	call   *0xc64b(%rip)        # ffc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e c6 00 00 	mov    0xc62e(%rip),%rax        # ffc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd c5 00 00 	mov    0xc5fd(%rip),%rax        # ffd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da c5 00 00 	cmpq   $0x0,0xc5da(%rip)        # ffe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d a9 e7 01 00 	mov    0x1e7a9(%rip),%rdi        # 22420 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 a1 ca 01 00 	mov    0x1caa1(%rip),%rax        # 207a0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 d9 c3 01 00 	mov    0x1c3d9(%rip),%rax        # 20158 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 c5 c3 01 00 	sub    0x1c3c5(%rip),%rax        # 20150 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 8d 00 00 	lea    0x8dad(%rip),%rsi        # cb70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 87 88 00 00 	lea    0x8887(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 42 c2 00 00 	mov    0xc242(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d e5 c1 00 00 ff 	cmpl   $0xffffffff,0xc1e5(%rip)        # 10018 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 81 00 00 	lea    0x81e2(%rip),%rax        # c022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d c1 c2 01 00 	mov    0x1c2c1(%rip),%r9        # 20108 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f bd 00 	movq   0xbd9f(%rip),%xmm0        # fbf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 81 00 00 	lea    0x81e7(%rip),%rax        # c044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 9c c2 01 00 	mov    0x1c29c(%rip),%r8        # 20100 <descent_inputs>
    3e64:	48 8b 0d a5 c2 01 00 	mov    0x1c2a5(%rip),%rcx        # 20110 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d c2 c1 00 00 	mov    0xc1c2(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 81 00 00 	lea    0x81d8(%rip),%rax        # c061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 bd 00 	movq   0xbd67(%rip),%xmm0        # fbf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 20 88 00 00 	lea    0x8820(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 71 c2 01 00 	lea    0x1c271(%rip),%r12        # 20120 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 bd 00 	movq   0xbd44(%rip),%xmm0        # fc00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 5b c1 00 00 	mov    0xc15b(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 81 00 00 	lea    0x8175(%rip),%rcx        # c06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 81 00 00 	lea    0x8170(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 20 c1 00 00 	mov    0xc120(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 81 00 00 	lea    0x8144(%rip),%rdi        # c07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d f9 c0 00 00 	mov    0xc0f9(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 81 00 00 	lea    0x8143(%rip),%rcx        # c091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 81 00 00 	lea    0x8119(%rip),%rdx        # c06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 1b dc 01 00 	mov    0x1dc1b(%rip),%rax        # 21bb0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 14 dc 01 00 	lea    0x1dc14(%rip),%r8        # 21bb0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d f5 db 01 00 	mov    0x1dbf5(%rip),%rbx        # 21b98 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 05 dc 01 00 	mov    0x1dc05(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d a1 db 01 00 	mov    0x1dba1(%rip),%rdi        # 21ba0 <fwp_heap+0x13e0>
    3fff:	48 29 35 ea db 01 00 	sub    %rsi,0x1dbea(%rip)        # 21bf0 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 7a db 01 00 	mov    0x1db7a(%rip),%rax        # 21b90 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 30 db 01 00 	add    0x1db30(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 3e db 01 00 	mov    0x1db3e(%rip),%rsi        # 21ba0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 4c db 01 00 	mov    0x1db4c(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 fb da 01 00 	mov    %r12,0x1dafb(%rip)        # 21ba0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d e9 da 01 00 	mov    %rbp,0x1dae9(%rip)        # 21b98 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ce da 01 00 	cmp    %rdi,0x1dace(%rip)        # 21b88 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d c5 da 01 00 	mov    %rdi,0x1dac5(%rip)        # 21b88 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 09 db 01 00 	sub    %rdi,0x1db09(%rip)        # 21bf0 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 b1 da 01 00 	mov    0x1dab1(%rip),%rax        # 21ba8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 aa da 01 00 	lea    0x1daaa(%rip),%r8        # 21ba8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 5d be 00 00 	mov    0xbe5d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 7e 00 00 	lea    0x7e14(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d ad bd 00 00 	movslq 0xbdad(%rip),%rbp        # 10018 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 7a be 01 00 	mov    0x1be7a(%rip),%rsi        # 20118 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 76 be 01 00 	lea    0x1be76(%rip),%rcx        # 20120 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 4b be 01 00 	addq   $0x1,0x1be4b(%rip)        # 20110 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 48 bd 00 00    	mov    %ebx,0xbd48(%rip)        # 10018 <descent_active_phase>
    42d0:	48 89 05 41 be 01 00 	mov    %rax,0x1be41(%rip)        # 20118 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d 99 c4 01 00 	cmp    0x1c499(%rip),%rdi        # 207a0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 5f c4 01 00 	mov    0x1c45f(%rip),%rax        # 20780 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 3d c4 01 00 	mov    %rdi,0x1c43d(%rip)        # 20780 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 19 c4 01 00 	mov    %rdi,0x1c419(%rip)        # 20788 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 ee 7d 00 00 	lea    0x7dee(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 7c 00 00 	lea    0x7cba(%rip),%rsi        # c07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 28 bc 00 00 	mov    0xbc28(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 7c 00 00 	lea    0x7c64(%rip),%rdx        # c083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 10 bc 00 00 	mov    0xbc10(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 21 bb 00 00 	mov    0xbb21(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 7a 00 00 	lea    0x7ad8(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 7b 00 00 	lea    0x7b45(%rip),%rdi        # c092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 7a 00 00 	lea    0x7acd(%rip),%rdi        # c0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 18 81 00 00 	lea    0x8118(%rip),%rdi        # c708 <_IO_stdin_used+0x708>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 b0 85 00 	movdqa 0x85b0(%rip),%xmm0        # cbc0 <msg.4+0x50>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 aa dd 01 00 	add    0x1ddaa(%rip),%rax        # 22418 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 6c 80 00 00 	lea    0x806c(%rip),%rdi        # c730 <_IO_stdin_used+0x730>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 05 ba 01 00 	cmp    %rax,0x1ba05(%rip)        # 200e8 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 00 ba 01 00 	add    0x1ba00(%rip),%rax        # 200f0 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 55 80 00 00 	lea    0x8055(%rip),%rdi        # c760 <_IO_stdin_used+0x760>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 79 00 00 	lea    0x79a5(%rip),%r8        # c0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 77 00 00 	lea    0x77fa(%rip),%r8        # c0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 76 00 00 	lea    0x7697(%rip),%r8        # c0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 74 00 00 	lea    0x746f(%rip),%rdi        # c0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 54 75 00 00 	lea    0x7554(%rip),%rsi        # c1e2 <_IO_stdin_used+0x1e2>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d 85 ce 01 00 	mov    0x1ce85(%rip),%r9        # 21b88 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 de ce 01 00 	mov    0x1cede(%rip),%r8        # 21be8 <fwp_heap+0x1428>
    4d0a:	48 8d 15 9f 7a 00 00 	lea    0x7a9f(%rip),%rdx        # c7b0 <_IO_stdin_used+0x7b0>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d c6 ce 01 00 	mov    0x1cec6(%rip),%rcx        # 21be0 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d d4 ce 01 	movsd  0x1ced4(%rip),%xmm1        # 21c00 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 c4 ce 01 	movsd  0x1cec4(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 05 b3 00 00 	mov    0xb305(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 58 7e 00 	movdqa 0x7e58(%rip),%xmm0        # cbd0 <msg.4+0x60>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 7f c9 01 00 	lea    0x1c97f(%rip),%rax        # 21700 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 81 7e 00 	movdqa 0x7e81(%rip),%xmm2        # cc10 <msg.4+0xa0>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 25 c9 01 00 	movaps %xmm0,0x1c925(%rip)        # 216c0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 3d 7e 00 	movdqa 0x7e3d(%rip),%xmm0        # cbe0 <msg.4+0x70>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 b3 cd 01 00 01 	movl   $0x1,0x1cdb3(%rip)        # 21b64 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 13 c9 01 00 	movaps %xmm0,0x1c913(%rip)        # 216d0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 2b 7e 00 	movdqa 0x7e2b(%rip),%xmm0        # cbf0 <msg.4+0x80>
    4dc4:	00 
    4dc5:	0f 29 05 14 c9 01 00 	movaps %xmm0,0x1c914(%rip)        # 216e0 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 2c 7e 00 	movdqa 0x7e2c(%rip),%xmm0        # cc00 <msg.4+0x90>
    4dd3:	00 
    4dd4:	0f 29 05 15 c9 01 00 	movaps %xmm0,0x1c915(%rip)        # 216f0 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 95 b9 01 00 	lea    0x1b995(%rip),%r8        # 207c0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 b0 cc 01 00 	mov    %rax,0x1ccb0(%rip)        # 21b78 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 8e cc 01 00 	mov    %r12,0x1cc8e(%rip)        # 21b80 <fwp_heap+0x13c0>
    4ef2:	48 89 05 77 cc 01 00 	mov    %rax,0x1cc77(%rip)        # 21b70 <fwp_heap+0x13b0>
    4ef9:	48 89 1d 90 cc 01 00 	mov    %rbx,0x1cc90(%rip)        # 21b90 <fwp_heap+0x13d0>
    4f00:	48 89 35 b9 cc 01 00 	mov    %rsi,0x1ccb9(%rip)        # 21bc0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 71 00 00 	lea    0x71f9(%rip),%rdi        # c112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 98 cc 01 00 	mov    %rax,0x1cc98(%rip)        # 21bb8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 1c cc 01 00    	mov    %eax,0x1cc1c(%rip)        # 21b68 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 0c b8 01 00 	mov    0x1b80c(%rip),%r8        # 20780 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 3c b7 01 00 	mov    %rbx,0x1b73c(%rip)        # 20788 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 28 b7 01 00 	mov    %r8,0x1b728(%rip)        # 20780 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 70 00 00 	lea    0x705c(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d 9d af 01 00 	lea    0x1af9d(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 85 af 01 00 	movaps %xmm0,0x1af85(%rip)        # 200a0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 61 af 01 00 	mov    %rax,0x1af61(%rip)        # 20088 <fwp_tape_cached_bytes>
    5127:	0f 29 05 82 af 01 00 	movaps %xmm0,0x1af82(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 86 af 01 00 	movaps %xmm0,0x1af86(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 87 af 01 00 	mov    %rdx,0x1af87(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 6f 00 00 	lea    0x6fb3(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d b7 b5 01 00 	mov    0x1b5b7(%rip),%rbx        # 20778 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d 8a ad 00 00 	mov    0xad8a(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 7b 75 00 00 	lea    0x757b(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 8d b4 01 00 	mov    0x1b48d(%rip),%rax        # 20780 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 67 b4 01 00 	mov    %rdx,0x1b467(%rip)        # 20780 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d b4 b3 01 00 	mov    0x1b3b4(%rip),%rbx        # 20778 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 71 b3 01 00 	mov    %rbx,0x1b371(%rip)        # 20778 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 71 b3 01 00 	mov    %rdx,0x1b371(%rip)        # 20788 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 86 b3 01 00 	lea    0x1b386(%rip),%rsi        # 207c0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 05 cf 01 00 	addq   $0x1,0x1cf05(%rip)        # 22408 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 4f 73 00 00 	lea    0x734f(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 60 73 00 00 	lea    0x7360(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 6b 00 00 	lea    0x6bf7(%rip),%rdi        # c133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 3e b2 01 00 	lea    0x1b23e(%rip),%rcx        # 207c0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 3f ce 01 00 	subq   $0x1,0x1ce3f(%rip)        # 22408 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d bb 72 00 00 	lea    0x72bb(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 20 ce 01 00 	cmpq   $0x0,0x1ce20(%rip)        # 22408 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 75 cd 01 00 	sub    %rax,0x1cd75(%rip)        # 22410 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 53 cd 01 00 	add    %r12,0x1cd53(%rip)        # 22410 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 af c4 01 00 	mov    0x1c4af(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 ac b0 01 00 	lea    0x1b0ac(%rip),%rax        # 207c0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 03 c4 01 00 	add    0x1c403(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 d0 c3 01 00 	mov    0x1c3d0(%rip),%rsi        # 21b70 <fwp_heap+0x13b0>
    57a0:	48 8b 05 f1 c3 01 00 	mov    0x1c3f1(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 e5 c3 01 00 	add    0x1c3e5(%rip),%r8        # 21bb8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 ad c3 01 	addsd  0x1c3ad(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 62 af 01 00 	lea    0x1af62(%rip),%rax        # 207c0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 6c c3 01 00 	sub    %rdi,0x1c36c(%rip)        # 21be0 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 84 c3 01 	movsd  %xmm0,0x1c384(%rip)        # 21c00 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 3e c3 01 00 	sub    %rdx,0x1c33e(%rip)        # 21be0 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 44 c3 01 	addsd  0x1c344(%rip),%xmm0        # 21c00 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 38 c3 01 	movsd  %xmm0,0x1c338(%rip)        # 21c00 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 cf c2 01 00 	mov    0x1c2cf(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d c9 c2 01 00 	add    %rcx,0x1c2c9(%rip)        # 21bf0 <fwp_heap+0x1430>
    5927:	4c 3b 0d 82 c2 01 00 	cmp    0x1c282(%rip),%r9        # 21bb0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 79 c2 01 00 	mov    %r9,0x1c279(%rip)        # 21bb0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 6a c2 01 00 	cmp    0x1c26a(%rip),%r9        # 21ba8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 5d c2 01 00 	mov    %r9,0x1c25d(%rip)        # 21ba8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 73 c1 01 00 	add    0x1c173(%rip),%rdi        # 21bb8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 50 ad 01 00 	lea    0x1ad50(%rip),%r15        # 207c0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 c0 c0 01 00 	add    0x1c0c0(%rip),%r12        # 21b70 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 19 c1 01 00 	add    0x1c119(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 18 c1 01 00 	cmp    %rax,0x1c118(%rip)        # 21be8 <fwp_heap+0x1428>
    5ad0:	48 89 05 09 c1 01 00 	mov    %rax,0x1c109(%rip)        # 21be0 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 08 c1 01 00 	mov    %rax,0x1c108(%rip)        # 21be8 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 04 c1 01 	addsd  0x1c104(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 fc c0 01 	movsd  %xmm0,0x1c0fc(%rip)        # 21bf8 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 43 c0 01 00    	mov    0x1c043(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 7f ac 01 00 	lea    0x1ac7f(%rip),%rdi        # 207c0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 38 c0 01 00 	add    0x1c038(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 33 c0 01 00 	cmp    %rax,0x1c033(%rip)        # 21be8 <fwp_heap+0x1428>
    5bb5:	48 89 05 24 c0 01 00 	mov    %rax,0x1c024(%rip)        # 21be0 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 23 c0 01 00 	mov    %rax,0x1c023(%rip)        # 21be8 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 1f c0 01 	addsd  0x1c01f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 17 c0 01 	movsd  %xmm0,0x1c017(%rip)        # 21bf8 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ce be 01 00    	mov    0x1bece(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 05 ab 01 00 	lea    0x1ab05(%rip),%rax        # 207c0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 bb be 01 00 	add    0x1bebb(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 ba be 01 00 	cmp    %rax,0x1beba(%rip)        # 21be8 <fwp_heap+0x1428>
    5d2e:	48 89 05 ab be 01 00 	mov    %rax,0x1beab(%rip)        # 21be0 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 aa be 01 00 	mov    %rax,0x1beaa(%rip)        # 21be8 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 a6 be 01 	addsd  0x1bea6(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 9e be 01 	movsd  %xmm0,0x1be9e(%rip)        # 21bf8 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_data.part.0.constprop.0>:
    5db0:	41 56                	push   %r14
    5db2:	41 89 fe             	mov    %edi,%r14d
    5db5:	41 54                	push   %r12
    5db7:	49 89 f4             	mov    %rsi,%r12
    5dba:	55                   	push   %rbp
    5dbb:	53                   	push   %rbx
    5dbc:	48 83 ec 08          	sub    $0x8,%rsp
    5dc0:	8b 05 9e bd 01 00    	mov    0x1bd9e(%rip),%eax        # 21b64 <fwp_heap+0x13a4>
    5dc6:	85 c0                	test   %eax,%eax
    5dc8:	0f 84 fa 00 00 00    	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5dce:	0f b6 05 8d b9 01 00 	movzbl 0x1b98d(%rip),%eax        # 21762 <fwp_heap+0xfa2>
    5dd5:	48 8d 15 e4 a9 01 00 	lea    0x1a9e4(%rip),%rdx        # 207c0 <fwp_heap>
    5ddc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5de3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5de7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5deb:	48 8b 18             	mov    (%rax),%rbx
    5dee:	48 85 db             	test   %rbx,%rbx
    5df1:	0f 84 a9 00 00 00    	je     5ea0 <fwp_data.part.0.constprop.0+0xf0>
    5df7:	48 8b 13             	mov    (%rbx),%rdx
    5dfa:	48 f7 d2             	not    %rdx
    5dfd:	48 89 10             	mov    %rdx,(%rax)
    5e00:	48 83 fd 18          	cmp    $0x18,%rbp
    5e04:	76 1b                	jbe    5e21 <fwp_data.part.0.constprop.0+0x71>
    5e06:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5e0a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5e0e:	31 f6                	xor    %esi,%esi
    5e10:	48 c1 e8 03          	shr    $0x3,%rax
    5e14:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5e1b:	00 
    5e1c:	e8 9f d6 ff ff       	call   34c0 <memset@plt>
    5e21:	48 89 e8             	mov    %rbp,%rax
    5e24:	48 03 05 b5 bd 01 00 	add    0x1bdb5(%rip),%rax        # 21be0 <fwp_heap+0x1420>
    5e2b:	0f 82 a8 00 00 00    	jb     5ed9 <fwp_data.part.0.constprop.0+0x129>
    5e31:	48 39 05 b0 bd 01 00 	cmp    %rax,0x1bdb0(%rip)        # 21be8 <fwp_heap+0x1428>
    5e38:	48 89 05 a1 bd 01 00 	mov    %rax,0x1bda1(%rip)        # 21be0 <fwp_heap+0x1420>
    5e3f:	73 07                	jae    5e48 <fwp_data.part.0.constprop.0+0x98>
    5e41:	48 89 05 a0 bd 01 00 	mov    %rax,0x1bda0(%rip)        # 21be8 <fwp_heap+0x1428>
    5e48:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e4c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5e51:	f2 0f 58 05 9f bd 01 	addsd  0x1bd9f(%rip),%xmm0        # 21bf8 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 97 bd 01 	movsd  %xmm0,0x1bd97(%rip)        # 21bf8 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	b8 02 00 00 00       	mov    $0x2,%eax
    5e66:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5e6b:	66 0f 6e c8          	movd   %eax,%xmm1
    5e6f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5e73:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5e77:	49 8b 04 24          	mov    (%r12),%rax
    5e7b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5e7f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5e84:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5e88:	48 83 c4 08          	add    $0x8,%rsp
    5e8c:	48 89 d8             	mov    %rbx,%rax
    5e8f:	5b                   	pop    %rbx
    5e90:	5d                   	pop    %rbp
    5e91:	41 5c                	pop    %r12
    5e93:	41 5e                	pop    %r14
    5e95:	c3                   	ret
    5e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5e9d:	00 00 00 
    5ea0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5ea4:	48 85 db             	test   %rbx,%rbx
    5ea7:	74 1f                	je     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5ea9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5ead:	48 29 da             	sub    %rbx,%rdx
    5eb0:	48 39 ea             	cmp    %rbp,%rdx
    5eb3:	72 13                	jb     5ec8 <fwp_data.part.0.constprop.0+0x118>
    5eb5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5eb9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ebd:	e9 3e ff ff ff       	jmp    5e00 <fwp_data.part.0.constprop.0+0x50>
    5ec2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ec8:	31 f6                	xor    %esi,%esi
    5eca:	bf 18 00 00 00       	mov    $0x18,%edi
    5ecf:	e8 bc fd ff ff       	call   5c90 <fwp_heap_alloc>
    5ed4:	48 89 c3             	mov    %rax,%rbx
    5ed7:	eb 88                	jmp    5e61 <fwp_data.part.0.constprop.0+0xb1>
    5ed9:	e8 d2 dd ff ff       	call   3cb0 <fwp_heap_oom>
    5ede:	66 90                	xchg   %ax,%ax

0000000000005ee0 <fwp_p_ad_push>:
    5ee0:	41 57                	push   %r15
    5ee2:	41 56                	push   %r14
    5ee4:	41 55                	push   %r13
    5ee6:	49 89 d5             	mov    %rdx,%r13
    5ee9:	41 54                	push   %r12
    5eeb:	49 89 fc             	mov    %rdi,%r12
    5eee:	55                   	push   %rbp
    5eef:	53                   	push   %rbx
    5ef0:	48 83 ec 48          	sub    $0x48,%rsp
    5ef4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5ef9:	48 85 ff             	test   %rdi,%rdi
    5efc:	79 09                	jns    5f07 <fwp_p_ad_push+0x27>
    5efe:	48 85 d2             	test   %rdx,%rdx
    5f01:	0f 88 b9 02 00 00    	js     61c0 <fwp_p_ad_push+0x2e0>
    5f07:	48 89 f8             	mov    %rdi,%rax
    5f0a:	48 89 0c 24          	mov    %rcx,(%rsp)
    5f0e:	4c 89 c5             	mov    %r8,%rbp
    5f11:	48 09 d0             	or     %rdx,%rax
    5f14:	0f 89 7e 02 00 00    	jns    6198 <fwp_p_ad_push+0x2b8>
    5f1a:	48 85 ff             	test   %rdi,%rdi
    5f1d:	0f 89 e6 03 00 00    	jns    6309 <fwp_p_ad_push+0x429>
    5f23:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5f28:	49 89 d6             	mov    %rdx,%r14
    5f2b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5f32:	00 
    5f33:	49 89 d4             	mov    %rdx,%r12
    5f36:	49 c1 fe 20          	sar    $0x20,%r14
    5f3a:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5f41:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5f47:	48 85 ed             	test   %rbp,%rbp
    5f4a:	0f 84 48 03 00 00    	je     6298 <fwp_p_ad_push+0x3b8>
    5f50:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5f54:	0f 84 be 02 00 00    	je     6218 <fwp_p_ad_push+0x338>
    5f5a:	4c 89 f7             	mov    %r14,%rdi
    5f5d:	e8 6e e7 ff ff       	call   46d0 <fwp_tape_of>
    5f62:	48 89 c3             	mov    %rax,%rbx
    5f65:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5f6a:	0f 85 3e 03 00 00    	jne    62ae <fwp_p_ad_push+0x3ce>
    5f70:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5f74:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5f78:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5f7c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5f83:	0f 8f cd 03 00 00    	jg     6356 <fwp_p_ad_push+0x476>
    5f89:	44 89 e0             	mov    %r12d,%eax
    5f8c:	4c 39 c0             	cmp    %r8,%rax
    5f8f:	0f 8d b5 03 00 00    	jge    634a <fwp_p_ad_push+0x46a>
    5f95:	4d 85 ed             	test   %r13,%r13
    5f98:	78 0c                	js     5fa6 <fwp_p_ad_push+0xc6>
    5f9a:	44 89 e8             	mov    %r13d,%eax
    5f9d:	4c 39 c0             	cmp    %r8,%rax
    5fa0:	0f 8d a4 03 00 00    	jge    634a <fwp_p_ad_push+0x46a>
    5fa6:	4d 89 c7             	mov    %r8,%r15
    5fa9:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5fad:	49 8d 47 01          	lea    0x1(%r15),%rax
    5fb1:	4c 89 f9             	mov    %r15,%rcx
    5fb4:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5fba:	0f 87 96 03 00 00    	ja     6356 <fwp_p_ad_push+0x476>
    5fc0:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5fc4:	48 39 e8             	cmp    %rbp,%rax
    5fc7:	0f 8e 23 02 00 00    	jle    61f0 <fwp_p_ad_push+0x310>
    5fcd:	48 85 ed             	test   %rbp,%rbp
    5fd0:	ba 40 00 00 00       	mov    $0x40,%edx
    5fd5:	48 0f 44 ea          	cmove  %rdx,%rbp
    5fd9:	48 39 e8             	cmp    %rbp,%rax
    5fdc:	7e 22                	jle    6000 <fwp_p_ad_push+0x120>
    5fde:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5fe5:	0f 8f f5 01 00 00    	jg     61e0 <fwp_p_ad_push+0x300>
    5feb:	48 01 ed             	add    %rbp,%rbp
    5fee:	48 39 e8             	cmp    %rbp,%rax
    5ff1:	7f eb                	jg     5fde <fwp_p_ad_push+0xfe>
    5ff3:	66 90                	xchg   %ax,%ax
    5ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ffc:	00 00 00 00 
    6000:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    6007:	00 
    6008:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    600c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6011:	48 89 c6             	mov    %rax,%rsi
    6014:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    6019:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    601d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    6022:	e8 a9 d5 ff ff       	call   35d0 <realloc@plt>
    6027:	48 85 c0             	test   %rax,%rax
    602a:	0f 84 32 03 00 00    	je     6362 <fwp_p_ad_push+0x482>
    6030:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    6034:	4d 85 f6             	test   %r14,%r14
    6037:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    603c:	48 89 43 20          	mov    %rax,0x20(%rbx)
    6040:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6045:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6049:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    604d:	0f 84 d5 01 00 00    	je     6228 <fwp_p_ad_push+0x348>
    6053:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6057:	48 39 ea             	cmp    %rbp,%rdx
    605a:	0f 8d bb 00 00 00    	jge    611b <fwp_p_ad_push+0x23b>
    6060:	49 8b 76 40          	mov    0x40(%r14),%rsi
    6064:	48 89 ef             	mov    %rbp,%rdi
    6067:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    606c:	48 c1 e7 04          	shl    $0x4,%rdi
    6070:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    6075:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    607a:	be 02 00 00 00       	mov    $0x2,%esi
    607f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    6084:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    6089:	e8 02 fc ff ff       	call   5c90 <fwp_heap_alloc>
    608e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    6093:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    6098:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    609d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    60a2:	48 85 f6             	test   %rsi,%rsi
    60a5:	74 31                	je     60d8 <fwp_p_ad_push+0x1f8>
    60a7:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    60ac:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    60b1:	48 c1 e2 04          	shl    $0x4,%rdx
    60b5:	48 39 fa             	cmp    %rdi,%rdx
    60b8:	48 0f 47 d7          	cmova  %rdi,%rdx
    60bc:	48 89 c7             	mov    %rax,%rdi
    60bf:	e8 dc d4 ff ff       	call   35a0 <memcpy@plt>
    60c4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    60c9:	e8 c2 f6 ff ff       	call   5790 <fwp_mem_free>
    60ce:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    60d3:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    60d8:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    60dc:	48 89 ea             	mov    %rbp,%rdx
    60df:	31 f6                	xor    %esi,%esi
    60e1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    60e6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    60eb:	48 29 fa             	sub    %rdi,%rdx
    60ee:	48 c1 e7 04          	shl    $0x4,%rdi
    60f2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    60f7:	48 c1 e2 04          	shl    $0x4,%rdx
    60fb:	e8 c0 d3 ff ff       	call   34c0 <memset@plt>
    6100:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    6105:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    6109:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    610e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    6113:	49 89 46 40          	mov    %rax,0x40(%r14)
    6117:	48 8b 43 20          	mov    0x20(%rbx),%rax
    611b:	4d 85 ff             	test   %r15,%r15
    611e:	0f 85 9c 01 00 00    	jne    62c0 <fwp_p_ad_push+0x3e0>
    6124:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6128:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    612c:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    6133:	00 
    6134:	49 01 c6             	add    %rax,%r14
    6137:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    613b:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    613f:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    6143:	4d 85 ed             	test   %r13,%r13
    6146:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    614c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6153:	4c 0f 48 e8          	cmovs  %rax,%r13
    6157:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    615c:	49 8d 40 01          	lea    0x1(%r8),%rax
    6160:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    6165:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    6169:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    616e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6172:	48 83 c4 48          	add    $0x48,%rsp
    6176:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    617d:	ff ff ff 
    6180:	4c 21 e0             	and    %r12,%rax
    6183:	5b                   	pop    %rbx
    6184:	5d                   	pop    %rbp
    6185:	4c 09 c0             	or     %r8,%rax
    6188:	41 5c                	pop    %r12
    618a:	41 5d                	pop    %r13
    618c:	41 5e                	pop    %r14
    618e:	41 5f                	pop    %r15
    6190:	c3                   	ret
    6191:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6198:	48 c1 fa 20          	sar    $0x20,%rdx
    619c:	48 c1 ff 20          	sar    $0x20,%rdi
    61a0:	49 89 d6             	mov    %rdx,%r14
    61a3:	48 39 d7             	cmp    %rdx,%rdi
    61a6:	0f 84 9b fd ff ff    	je     5f47 <fwp_p_ad_push+0x67>
    61ac:	48 8d 3d 05 67 00 00 	lea    0x6705(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    61b3:	e8 38 e2 ff ff       	call   43f0 <fwp_trap>
    61b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    61bf:	00 
    61c0:	48 83 c4 48          	add    $0x48,%rsp
    61c4:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    61cb:	5b                   	pop    %rbx
    61cc:	5d                   	pop    %rbp
    61cd:	41 5c                	pop    %r12
    61cf:	41 5d                	pop    %r13
    61d1:	41 5e                	pop    %r14
    61d3:	41 5f                	pop    %r15
    61d5:	c3                   	ret
    61d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    61dd:	00 00 00 
    61e0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    61e5:	e9 16 fe ff ff       	jmp    6000 <fwp_p_ad_push+0x120>
    61ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    61f0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    61f4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    61f8:	48 c1 e1 03          	shl    $0x3,%rcx
    61fc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    6203:	00 
    6204:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    6208:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    620c:	e9 2e ff ff ff       	jmp    613f <fwp_p_ad_push+0x25f>
    6211:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6218:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    621c:	e9 57 fd ff ff       	jmp    5f78 <fwp_p_ad_push+0x98>
    6221:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6228:	49 89 ee             	mov    %rbp,%r14
    622b:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    622f:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    6234:	49 c1 e6 04          	shl    $0x4,%r14
    6238:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    623d:	4c 89 f6             	mov    %r14,%rsi
    6240:	e8 8b d3 ff ff       	call   35d0 <realloc@plt>
    6245:	48 89 c2             	mov    %rax,%rdx
    6248:	48 85 c0             	test   %rax,%rax
    624b:	0f 84 11 01 00 00    	je     6362 <fwp_p_ad_push+0x482>
    6251:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6255:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6259:	4d 85 ff             	test   %r15,%r15
    625c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6261:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6266:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    626a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    626f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6273:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6277:	0f 85 98 00 00 00    	jne    6315 <fwp_p_ad_push+0x435>
    627d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6281:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6285:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    628c:	00 
    628d:	45 31 ff             	xor    %r15d,%r15d
    6290:	e9 9f fe ff ff       	jmp    6134 <fwp_p_ad_push+0x254>
    6295:	0f 1f 00             	nopl   (%rax)
    6298:	4c 89 f7             	mov    %r14,%rdi
    629b:	e8 30 e4 ff ff       	call   46d0 <fwp_tape_of>
    62a0:	48 89 c3             	mov    %rax,%rbx
    62a3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62a8:	0f 84 ca fc ff ff    	je     5f78 <fwp_p_ad_push+0x98>
    62ae:	48 8d 3d 4b 66 00 00 	lea    0x664b(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    62b5:	e8 36 e1 ff ff       	call   43f0 <fwp_trap>
    62ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    62c0:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    62c7:	00 
    62c8:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    62cd:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    62d1:	49 c1 e7 02          	shl    $0x2,%r15
    62d5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    62da:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    62e1:	00 
    62e2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    62e6:	4c 89 fa             	mov    %r15,%rdx
    62e9:	e8 22 d3 ff ff       	call   3610 <memmove@plt>
    62ee:	48 8b 43 20          	mov    0x20(%rbx),%rax
    62f2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    62f6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    62fa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    62ff:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6304:	e9 2b fe ff ff       	jmp    6134 <fwp_p_ad_push+0x254>
    6309:	48 c1 ff 20          	sar    $0x20,%rdi
    630d:	49 89 fe             	mov    %rdi,%r14
    6310:	e9 32 fc ff ff       	jmp    5f47 <fwp_p_ad_push+0x67>
    6315:	4c 39 f0             	cmp    %r14,%rax
    6318:	4c 89 f1             	mov    %r14,%rcx
    631b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    6322:	00 
    6323:	49 89 c6             	mov    %rax,%r14
    6326:	48 0f 43 c8          	cmovae %rax,%rcx
    632a:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    632f:	48 29 c1             	sub    %rax,%rcx
    6332:	e8 29 d2 ff ff       	call   3560 <__memmove_chk@plt>
    6337:	4c 03 73 30          	add    0x30(%rbx),%r14
    633b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    633f:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6343:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6348:	eb 83                	jmp    62cd <fwp_p_ad_push+0x3ed>
    634a:	48 8d 3d 16 5e 00 00 	lea    0x5e16(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    6351:	e8 9a e0 ff ff       	call   43f0 <fwp_trap>
    6356:	48 8d 3d ef 5d 00 00 	lea    0x5def(%rip),%rdi        # c14c <_IO_stdin_used+0x14c>
    635d:	e8 8e e0 ff ff       	call   43f0 <fwp_trap>
    6362:	48 89 df             	mov    %rbx,%rdi
    6365:	e8 96 d8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    636a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    636e:	e8 4d d0 ff ff       	call   33c0 <free@plt>
    6373:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6377:	e8 44 d0 ff ff       	call   33c0 <free@plt>
    637c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6380:	e8 3b d0 ff ff       	call   33c0 <free@plt>
    6385:	31 c9                	xor    %ecx,%ecx
    6387:	31 c0                	xor    %eax,%eax
    6389:	31 d2                	xor    %edx,%edx
    638b:	89 53 04             	mov    %edx,0x4(%rbx)
    638e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6392:	ba 13 00 00 00       	mov    $0x13,%edx
    6397:	be 01 00 00 00       	mov    $0x1,%esi
    639c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    63a0:	48 8d 3d 61 5c 00 00 	lea    0x5c61(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    63a7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    63ab:	48 8b 0d 8e 9c 00 00 	mov    0x9c8e(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    63b2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    63b6:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    63ba:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    63be:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    63c2:	e8 b9 d2 ff ff       	call   3680 <fwrite@plt>
    63c7:	31 ff                	xor    %edi,%edi
    63c9:	e8 f2 d1 ff ff       	call   35c0 <fflush@plt>
    63ce:	bf 66 00 00 00       	mov    $0x66,%edi
    63d3:	e8 c8 d2 ff ff       	call   36a0 <_Exit@plt>
    63d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    63df:	00 

00000000000063e0 <w120>:
    63e0:	41 56                	push   %r14
    63e2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    63e6:	48 89 fa             	mov    %rdi,%rdx
    63e9:	41 55                	push   %r13
    63eb:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    63ef:	49 89 fd             	mov    %rdi,%r13
    63f2:	41 54                	push   %r12
    63f4:	55                   	push   %rbp
    63f5:	53                   	push   %rbx
    63f6:	48 83 ec 40          	sub    $0x40,%rsp
    63fa:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    6400:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6405:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    640c:	00 00 
    640e:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    6413:	48 89 f5             	mov    %rsi,%rbp
    6416:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    641b:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    6421:	48 89 f1             	mov    %rsi,%rcx
    6424:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    642a:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    6431:	ff ff 
    6433:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    643a:	00 00 
    643c:	e8 9f fa ff ff       	call   5ee0 <fwp_p_ad_push>
    6441:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6447:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    644c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6452:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6459:	00 f0 3f 
    645c:	48 89 c7             	mov    %rax,%rdi
    645f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6466:	00 f0 bf 
    6469:	48 89 ea             	mov    %rbp,%rdx
    646c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6471:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6477:	e8 64 fa ff ff       	call   5ee0 <fwp_p_ad_push>
    647c:	f2 0f 10 05 14 67 00 	movsd  0x6714(%rip),%xmm0        # cb98 <msg.4+0x28>
    6483:	00 
    6484:	4c 89 ef             	mov    %r13,%rdi
    6487:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    648d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6492:	49 89 c6             	mov    %rax,%r14
    6495:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    649c:	00 f0 3f 
    649f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    64a6:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    64ad:	00 f0 bf 
    64b0:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    64b5:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    64bb:	e8 20 fa ff ff       	call   5ee0 <fwp_p_ad_push>
    64c0:	4c 89 e1             	mov    %r12,%rcx
    64c3:	4c 89 e6             	mov    %r12,%rsi
    64c6:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    64cb:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    64d1:	4c 89 f2             	mov    %r14,%rdx
    64d4:	4c 89 f7             	mov    %r14,%rdi
    64d7:	49 89 c5             	mov    %rax,%r13
    64da:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    64de:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64e4:	e8 f7 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    64e9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    64ef:	f2 0f 59 1d a9 66 00 	mulsd  0x66a9(%rip),%xmm3        # cba0 <msg.4+0x30>
    64f6:	00 
    64f7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    64fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6501:	48 89 c2             	mov    %rax,%rdx
    6504:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    650b:	00 59 40 
    650e:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6515:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    651b:	e8 c0 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6520:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6525:	48 89 e9             	mov    %rbp,%rcx
    6528:	4c 89 ea             	mov    %r13,%rdx
    652b:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    6531:	48 89 ee             	mov    %rbp,%rsi
    6534:	4c 89 ef             	mov    %r13,%rdi
    6537:	49 89 c4             	mov    %rax,%r12
    653a:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    653e:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6544:	e8 97 f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6549:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    654f:	45 31 c0             	xor    %r8d,%r8d
    6552:	4c 89 e2             	mov    %r12,%rdx
    6555:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    655b:	48 89 c7             	mov    %rax,%rdi
    655e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6565:	00 f0 3f 
    6568:	48 89 ce             	mov    %rcx,%rsi
    656b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6570:	e8 6b f9 ff ff       	call   5ee0 <fwp_p_ad_push>
    6575:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    657a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6581:	00 00 
    6583:	75 12                	jne    6597 <w120+0x1b7>
    6585:	48 83 c4 40          	add    $0x40,%rsp
    6589:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    658e:	5b                   	pop    %rbx
    658f:	5d                   	pop    %rbp
    6590:	41 5c                	pop    %r12
    6592:	41 5d                	pop    %r13
    6594:	41 5e                	pop    %r14
    6596:	c3                   	ret
    6597:	e8 c4 ce ff ff       	call   3460 <__stack_chk_fail@plt>
    659c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000065a0 <w176.constprop.0>:
    65a0:	41 54                	push   %r12
    65a2:	55                   	push   %rbp
    65a3:	53                   	push   %rbx
    65a4:	48 83 ec 10          	sub    $0x10,%rsp
    65a8:	4c 8b 27             	mov    (%rdi),%r12
    65ab:	4d 85 e4             	test   %r12,%r12
    65ae:	74 58                	je     6608 <w176.constprop.0+0x68>
    65b0:	48 89 fd             	mov    %rdi,%rbp
    65b3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    65b7:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    65be:	31 db                	xor    %ebx,%ebx
    65c0:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    65c6:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    65cb:	45 31 c0             	xor    %r8d,%r8d
    65ce:	48 83 c3 02          	add    $0x2,%rbx
    65d2:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    65d9:	00 f0 3f 
    65dc:	48 89 ce             	mov    %rcx,%rsi
    65df:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    65e5:	e8 f6 f8 ff ff       	call   5ee0 <fwp_p_ad_push>
    65ea:	4c 39 e3             	cmp    %r12,%rbx
    65ed:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    65f3:	48 89 c7             	mov    %rax,%rdi
    65f6:	72 c8                	jb     65c0 <w176.constprop.0+0x20>
    65f8:	48 83 c4 10          	add    $0x10,%rsp
    65fc:	48 89 f8             	mov    %rdi,%rax
    65ff:	5b                   	pop    %rbx
    6600:	5d                   	pop    %rbp
    6601:	41 5c                	pop    %r12
    6603:	c3                   	ret
    6604:	0f 1f 40 00          	nopl   0x0(%rax)
    6608:	48 83 c4 10          	add    $0x10,%rsp
    660c:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6613:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6617:	5b                   	pop    %rbx
    6618:	48 89 f8             	mov    %rdi,%rax
    661b:	5d                   	pop    %rbp
    661c:	41 5c                	pop    %r12
    661e:	c3                   	ret
    661f:	90                   	nop

0000000000006620 <fwp_rc_share>:
    6620:	48 8b 05 71 b5 01 00 	mov    0x1b571(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    6627:	48 2b 3d 42 b5 01 00 	sub    0x1b542(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    662e:	48 c1 e0 10          	shl    $0x10,%rax
    6632:	48 39 c7             	cmp    %rax,%rdi
    6635:	73 4a                	jae    6681 <fwp_rc_share+0x61>
    6637:	48 89 f8             	mov    %rdi,%rax
    663a:	48 c1 e8 10          	shr    $0x10,%rax
    663e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6642:	48 8b 05 6f b5 01 00 	mov    0x1b56f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    6649:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    664d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6651:	48 85 d2             	test   %rdx,%rdx
    6654:	74 2b                	je     6681 <fwp_rc_share+0x61>
    6656:	0f b6 08             	movzbl (%rax),%ecx
    6659:	80 f9 02             	cmp    $0x2,%cl
    665c:	74 2a                	je     6688 <fwp_rc_share+0x68>
    665e:	80 f9 01             	cmp    $0x1,%cl
    6661:	75 1e                	jne    6681 <fwp_rc_share+0x61>
    6663:	8b 48 18             	mov    0x18(%rax),%ecx
    6666:	0f b7 ff             	movzwl %di,%edi
    6669:	8b 40 1c             	mov    0x1c(%rax),%eax
    666c:	48 0f af f9          	imul   %rcx,%rdi
    6670:	48 c1 ef 20          	shr    $0x20,%rdi
    6674:	48 39 c7             	cmp    %rax,%rdi
    6677:	73 08                	jae    6681 <fwp_rc_share+0x61>
    6679:	48 01 fa             	add    %rdi,%rdx
    667c:	80 3a 00             	cmpb   $0x0,(%rdx)
    667f:	75 0d                	jne    668e <fwp_rc_share+0x6e>
    6681:	c3                   	ret
    6682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6688:	66 85 ff             	test   %di,%di
    668b:	74 ef                	je     667c <fwp_rc_share+0x5c>
    668d:	c3                   	ret
    668e:	50                   	push   %rax
    668f:	48 8d 3d 9a 62 00 00 	lea    0x629a(%rip),%rdi        # c930 <_IO_stdin_used+0x930>
    6696:	e8 55 dd ff ff       	call   43f0 <fwp_trap>
    669b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000066a0 <fwp_rc_free_obj>:
    66a0:	48 8b 15 f1 b4 01 00 	mov    0x1b4f1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    66a7:	48 89 f8             	mov    %rdi,%rax
    66aa:	48 2b 05 bf b4 01 00 	sub    0x1b4bf(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    66b1:	48 c1 e2 10          	shl    $0x10,%rdx
    66b5:	48 39 d0             	cmp    %rdx,%rax
    66b8:	73 5b                	jae    6715 <fwp_rc_free_obj+0x75>
    66ba:	48 89 c2             	mov    %rax,%rdx
    66bd:	48 c1 ea 10          	shr    $0x10,%rdx
    66c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66c5:	48 8b 15 ec b4 01 00 	mov    0x1b4ec(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    66cc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    66d0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    66d4:	48 85 c9             	test   %rcx,%rcx
    66d7:	74 3c                	je     6715 <fwp_rc_free_obj+0x75>
    66d9:	0f b6 32             	movzbl (%rdx),%esi
    66dc:	40 80 fe 02          	cmp    $0x2,%sil
    66e0:	74 2e                	je     6710 <fwp_rc_free_obj+0x70>
    66e2:	40 80 fe 01          	cmp    $0x1,%sil
    66e6:	75 2d                	jne    6715 <fwp_rc_free_obj+0x75>
    66e8:	8b 72 18             	mov    0x18(%rdx),%esi
    66eb:	0f b7 c0             	movzwl %ax,%eax
    66ee:	8b 52 1c             	mov    0x1c(%rdx),%edx
    66f1:	48 0f af c6          	imul   %rsi,%rax
    66f5:	48 c1 e8 20          	shr    $0x20,%rax
    66f9:	48 39 d0             	cmp    %rdx,%rax
    66fc:	73 17                	jae    6715 <fwp_rc_free_obj+0x75>
    66fe:	48 01 c1             	add    %rax,%rcx
    6701:	80 39 01             	cmpb   $0x1,(%rcx)
    6704:	75 0f                	jne    6715 <fwp_rc_free_obj+0x75>
    6706:	e9 85 f0 ff ff       	jmp    5790 <fwp_mem_free>
    670b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6710:	66 85 c0             	test   %ax,%ax
    6713:	74 ec                	je     6701 <fwp_rc_free_obj+0x61>
    6715:	c3                   	ret
    6716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    671d:	00 00 00 

0000000000006720 <fwp_rc_dup>:
    6720:	f3 0f 1e fa          	endbr64
    6724:	48 8b 05 6d b4 01 00 	mov    0x1b46d(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    672b:	48 2b 3d 3e b4 01 00 	sub    0x1b43e(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    6732:	48 c1 e0 10          	shl    $0x10,%rax
    6736:	48 39 c7             	cmp    %rax,%rdi
    6739:	73 56                	jae    6791 <fwp_rc_dup+0x71>
    673b:	48 89 f8             	mov    %rdi,%rax
    673e:	48 c1 e8 10          	shr    $0x10,%rax
    6742:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6746:	48 8b 05 6b b4 01 00 	mov    0x1b46b(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    674d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6751:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6755:	48 85 c0             	test   %rax,%rax
    6758:	74 37                	je     6791 <fwp_rc_dup+0x71>
    675a:	0f b6 0a             	movzbl (%rdx),%ecx
    675d:	80 f9 02             	cmp    $0x2,%cl
    6760:	74 36                	je     6798 <fwp_rc_dup+0x78>
    6762:	80 f9 01             	cmp    $0x1,%cl
    6765:	75 2a                	jne    6791 <fwp_rc_dup+0x71>
    6767:	8b 4a 18             	mov    0x18(%rdx),%ecx
    676a:	0f b7 ff             	movzwl %di,%edi
    676d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6770:	48 0f af f9          	imul   %rcx,%rdi
    6774:	48 c1 ef 20          	shr    $0x20,%rdi
    6778:	48 39 d7             	cmp    %rdx,%rdi
    677b:	73 14                	jae    6791 <fwp_rc_dup+0x71>
    677d:	48 01 f8             	add    %rdi,%rax
    6780:	0f b6 10             	movzbl (%rax),%edx
    6783:	84 d2                	test   %dl,%dl
    6785:	74 0a                	je     6791 <fwp_rc_dup+0x71>
    6787:	80 fa fd             	cmp    $0xfd,%dl
    678a:	77 14                	ja     67a0 <fwp_rc_dup+0x80>
    678c:	83 c2 01             	add    $0x1,%edx
    678f:	88 10                	mov    %dl,(%rax)
    6791:	c3                   	ret
    6792:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6798:	66 85 ff             	test   %di,%di
    679b:	74 e3                	je     6780 <fwp_rc_dup+0x60>
    679d:	c3                   	ret
    679e:	66 90                	xchg   %ax,%ax
    67a0:	48 89 c7             	mov    %rax,%rdi
    67a3:	e9 88 ec ff ff       	jmp    5430 <fwp_rc_wide_dup>
    67a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    67af:	00 

00000000000067b0 <fwp_owned_entry173>:
    67b0:	f3 0f 1e fa          	endbr64
    67b4:	48 83 ec 38          	sub    $0x38,%rsp
    67b8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    67bd:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    67c4:	00 00 
    67c6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    67cb:	31 c0                	xor    %eax,%eax
    67cd:	48 8b 07             	mov    (%rdi),%rax
    67d0:	48 03 47 10          	add    0x10(%rdi),%rax
    67d4:	0f 80 c2 00 00 00    	jo     689c <fwp_owned_entry173+0xec>
    67da:	66 48 0f 6e c8       	movq   %rax,%xmm1
    67df:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    67e4:	31 ff                	xor    %edi,%edi
    67e6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    67ea:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    67ef:	e8 bc f5 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    67f4:	48 8b 15 9d b3 01 00 	mov    0x1b39d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    67fb:	48 89 c6             	mov    %rax,%rsi
    67fe:	48 2b 05 6b b3 01 00 	sub    0x1b36b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6805:	48 c1 e2 10          	shl    $0x10,%rdx
    6809:	48 39 d0             	cmp    %rdx,%rax
    680c:	73 4f                	jae    685d <fwp_owned_entry173+0xad>
    680e:	48 89 c2             	mov    %rax,%rdx
    6811:	48 c1 ea 10          	shr    $0x10,%rdx
    6815:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6819:	48 8b 15 98 b3 01 00 	mov    0x1b398(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6820:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6824:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6828:	48 85 d2             	test   %rdx,%rdx
    682b:	74 30                	je     685d <fwp_owned_entry173+0xad>
    682d:	0f b6 39             	movzbl (%rcx),%edi
    6830:	40 80 ff 02          	cmp    $0x2,%dil
    6834:	74 42                	je     6878 <fwp_owned_entry173+0xc8>
    6836:	40 80 ff 01          	cmp    $0x1,%dil
    683a:	75 21                	jne    685d <fwp_owned_entry173+0xad>
    683c:	8b 79 18             	mov    0x18(%rcx),%edi
    683f:	0f b7 c0             	movzwl %ax,%eax
    6842:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6845:	48 0f af c7          	imul   %rdi,%rax
    6849:	48 c1 e8 20          	shr    $0x20,%rax
    684d:	48 39 c8             	cmp    %rcx,%rax
    6850:	73 0b                	jae    685d <fwp_owned_entry173+0xad>
    6852:	48 01 c2             	add    %rax,%rdx
    6855:	80 3a ff             	cmpb   $0xff,(%rdx)
    6858:	74 26                	je     6880 <fwp_owned_entry173+0xd0>
    685a:	c6 02 01             	movb   $0x1,(%rdx)
    685d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6862:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6869:	00 00 
    686b:	75 34                	jne    68a1 <fwp_owned_entry173+0xf1>
    686d:	48 89 f0             	mov    %rsi,%rax
    6870:	48 83 c4 38          	add    $0x38,%rsp
    6874:	c3                   	ret
    6875:	0f 1f 00             	nopl   (%rax)
    6878:	66 85 c0             	test   %ax,%ax
    687b:	75 e0                	jne    685d <fwp_owned_entry173+0xad>
    687d:	eb d6                	jmp    6855 <fwp_owned_entry173+0xa5>
    687f:	90                   	nop
    6880:	48 89 d7             	mov    %rdx,%rdi
    6883:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6888:	48 89 14 24          	mov    %rdx,(%rsp)
    688c:	e8 bf ec ff ff       	call   5550 <fwp_rc_forget_slot>
    6891:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6896:	48 8b 14 24          	mov    (%rsp),%rdx
    689a:	eb be                	jmp    685a <fwp_owned_entry173+0xaa>
    689c:	e8 5f ce ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    68a1:	e8 ba cb ff ff       	call   3460 <__stack_chk_fail@plt>
    68a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    68ad:	00 00 00 

00000000000068b0 <e173>:
    68b0:	f3 0f 1e fa          	endbr64
    68b4:	53                   	push   %rbx
    68b5:	48 83 ec 30          	sub    $0x30,%rsp
    68b9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    68be:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    68c5:	00 00 
    68c7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    68cc:	31 c0                	xor    %eax,%eax
    68ce:	48 8b 07             	mov    (%rdi),%rax
    68d1:	48 03 47 10          	add    0x10(%rdi),%rax
    68d5:	0f 80 c9 00 00 00    	jo     69a4 <e173+0xf4>
    68db:	66 48 0f 6e c8       	movq   %rax,%xmm1
    68e0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    68e5:	31 ff                	xor    %edi,%edi
    68e7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    68eb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    68f0:	e8 bb f4 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    68f5:	48 8b 15 9c b2 01 00 	mov    0x1b29c(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    68fc:	48 89 c3             	mov    %rax,%rbx
    68ff:	48 2b 05 6a b2 01 00 	sub    0x1b26a(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6906:	48 c1 e2 10          	shl    $0x10,%rdx
    690a:	48 39 d0             	cmp    %rdx,%rax
    690d:	73 4f                	jae    695e <e173+0xae>
    690f:	48 89 c2             	mov    %rax,%rdx
    6912:	48 c1 ea 10          	shr    $0x10,%rdx
    6916:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    691a:	48 8b 15 97 b2 01 00 	mov    0x1b297(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    6921:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6925:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6929:	48 85 d2             	test   %rdx,%rdx
    692c:	74 30                	je     695e <e173+0xae>
    692e:	0f b6 31             	movzbl (%rcx),%esi
    6931:	40 80 fe 02          	cmp    $0x2,%sil
    6935:	74 49                	je     6980 <e173+0xd0>
    6937:	40 80 fe 01          	cmp    $0x1,%sil
    693b:	75 21                	jne    695e <e173+0xae>
    693d:	8b 71 18             	mov    0x18(%rcx),%esi
    6940:	0f b7 c0             	movzwl %ax,%eax
    6943:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6946:	48 0f af c6          	imul   %rsi,%rax
    694a:	48 c1 e8 20          	shr    $0x20,%rax
    694e:	48 39 c8             	cmp    %rcx,%rax
    6951:	73 0b                	jae    695e <e173+0xae>
    6953:	48 01 c2             	add    %rax,%rdx
    6956:	80 3a ff             	cmpb   $0xff,(%rdx)
    6959:	74 35                	je     6990 <e173+0xe0>
    695b:	c6 02 01             	movb   $0x1,(%rdx)
    695e:	48 89 df             	mov    %rbx,%rdi
    6961:	e8 ba fc ff ff       	call   6620 <fwp_rc_share>
    6966:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    696b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6972:	00 00 
    6974:	75 33                	jne    69a9 <e173+0xf9>
    6976:	48 83 c4 30          	add    $0x30,%rsp
    697a:	48 89 d8             	mov    %rbx,%rax
    697d:	5b                   	pop    %rbx
    697e:	c3                   	ret
    697f:	90                   	nop
    6980:	66 85 c0             	test   %ax,%ax
    6983:	75 d9                	jne    695e <e173+0xae>
    6985:	eb cf                	jmp    6956 <e173+0xa6>
    6987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    698e:	00 00 
    6990:	48 89 d7             	mov    %rdx,%rdi
    6993:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6998:	e8 b3 eb ff ff       	call   5550 <fwp_rc_forget_slot>
    699d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    69a2:	eb b7                	jmp    695b <e173+0xab>
    69a4:	e8 57 cd ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    69a9:	e8 b2 ca ff ff       	call   3460 <__stack_chk_fail@plt>
    69ae:	66 90                	xchg   %ax,%ax

00000000000069b0 <fwp_closure_drop>:
    69b0:	48 8b 15 e1 b1 01 00 	mov    0x1b1e1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    69b7:	48 89 f8             	mov    %rdi,%rax
    69ba:	48 2b 05 af b1 01 00 	sub    0x1b1af(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    69c1:	48 c1 e2 10          	shl    $0x10,%rdx
    69c5:	48 39 d0             	cmp    %rdx,%rax
    69c8:	73 6b                	jae    6a35 <fwp_closure_drop+0x85>
    69ca:	48 89 c2             	mov    %rax,%rdx
    69cd:	48 c1 ea 10          	shr    $0x10,%rdx
    69d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    69d5:	48 8b 15 dc b1 01 00 	mov    0x1b1dc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    69dc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    69e0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    69e4:	48 85 d2             	test   %rdx,%rdx
    69e7:	74 4c                	je     6a35 <fwp_closure_drop+0x85>
    69e9:	0f b6 31             	movzbl (%rcx),%esi
    69ec:	40 80 fe 02          	cmp    $0x2,%sil
    69f0:	74 3e                	je     6a30 <fwp_closure_drop+0x80>
    69f2:	40 80 fe 01          	cmp    $0x1,%sil
    69f6:	75 3d                	jne    6a35 <fwp_closure_drop+0x85>
    69f8:	8b 71 18             	mov    0x18(%rcx),%esi
    69fb:	0f b7 c0             	movzwl %ax,%eax
    69fe:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6a01:	48 0f af c6          	imul   %rsi,%rax
    6a05:	48 c1 e8 20          	shr    $0x20,%rax
    6a09:	48 39 c8             	cmp    %rcx,%rax
    6a0c:	73 27                	jae    6a35 <fwp_closure_drop+0x85>
    6a0e:	48 01 c2             	add    %rax,%rdx
    6a11:	0f b6 02             	movzbl (%rdx),%eax
    6a14:	84 c0                	test   %al,%al
    6a16:	74 1d                	je     6a35 <fwp_closure_drop+0x85>
    6a18:	3c 01                	cmp    $0x1,%al
    6a1a:	74 24                	je     6a40 <fwp_closure_drop+0x90>
    6a1c:	3c ff                	cmp    $0xff,%al
    6a1e:	74 48                	je     6a68 <fwp_closure_drop+0xb8>
    6a20:	83 e8 01             	sub    $0x1,%eax
    6a23:	88 02                	mov    %al,(%rdx)
    6a25:	c3                   	ret
    6a26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a2d:	00 00 00 
    6a30:	66 85 c0             	test   %ax,%ax
    6a33:	74 dc                	je     6a11 <fwp_closure_drop+0x61>
    6a35:	c3                   	ret
    6a36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a3d:	00 00 00 
    6a40:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6a47:	ff ff 
    6a49:	48 85 c0             	test   %rax,%rax
    6a4c:	74 12                	je     6a60 <fwp_closure_drop+0xb0>
    6a4e:	48 89 fe             	mov    %rdi,%rsi
    6a51:	48 89 c7             	mov    %rax,%rdi
    6a54:	e9 f7 d9 ff ff       	jmp    4450 <fwp_closure_drop_push>
    6a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6a60:	e9 9b db ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    6a65:	0f 1f 00             	nopl   (%rax)
    6a68:	48 89 d0             	mov    %rdx,%rax
    6a6b:	48 8d 35 4e 9d 01 00 	lea    0x19d4e(%rip),%rsi        # 207c0 <fwp_heap>
    6a72:	48 83 ec 18          	sub    $0x18,%rsp
    6a76:	48 c1 e8 11          	shr    $0x11,%rax
    6a7a:	48 31 d0             	xor    %rdx,%rax
    6a7d:	48 89 c1             	mov    %rax,%rcx
    6a80:	48 c1 e9 09          	shr    $0x9,%rcx
    6a84:	48 31 c8             	xor    %rcx,%rax
    6a87:	0f b6 c8             	movzbl %al,%ecx
    6a8a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6a91:	00 
    6a92:	48 85 c0             	test   %rax,%rax
    6a95:	75 12                	jne    6aa9 <fwp_closure_drop+0xf9>
    6a97:	eb 49                	jmp    6ae2 <fwp_closure_drop+0x132>
    6a99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6aa0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6aa4:	48 85 c0             	test   %rax,%rax
    6aa7:	74 39                	je     6ae2 <fwp_closure_drop+0x132>
    6aa9:	48 89 c1             	mov    %rax,%rcx
    6aac:	48 39 10             	cmp    %rdx,(%rax)
    6aaf:	75 ef                	jne    6aa0 <fwp_closure_drop+0xf0>
    6ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6ab5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6ab9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6abd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ac4:	74 05                	je     6acb <fwp_closure_drop+0x11b>
    6ac6:	48 83 c4 18          	add    $0x18,%rsp
    6aca:	c3                   	ret
    6acb:	48 89 d7             	mov    %rdx,%rdi
    6ace:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6ad3:	e8 78 ea ff ff       	call   5550 <fwp_rc_forget_slot>
    6ad8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6add:	c6 02 fe             	movb   $0xfe,(%rdx)
    6ae0:	eb e4                	jmp    6ac6 <fwp_closure_drop+0x116>
    6ae2:	48 8d 3d a7 5d 00 00 	lea    0x5da7(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    6ae9:	e8 02 d9 ff ff       	call   43f0 <fwp_trap>
    6aee:	66 90                	xchg   %ax,%ax

0000000000006af0 <fwp_owned_tape_release>:
    6af0:	48 85 ff             	test   %rdi,%rdi
    6af3:	0f 84 f7 00 00 00    	je     6bf0 <fwp_owned_tape_release+0x100>
    6af9:	41 54                	push   %r12
    6afb:	55                   	push   %rbp
    6afc:	53                   	push   %rbx
    6afd:	48 8b 07             	mov    (%rdi),%rax
    6b00:	48 85 c0             	test   %rax,%rax
    6b03:	74 08                	je     6b0d <fwp_owned_tape_release+0x1d>
    6b05:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6b09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6b0d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6b11:	48 85 d2             	test   %rdx,%rdx
    6b14:	74 03                	je     6b19 <fwp_owned_tape_release+0x29>
    6b16:	48 89 02             	mov    %rax,(%rdx)
    6b19:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6b1d:	48 89 fb             	mov    %rdi,%rbx
    6b20:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6b24:	48 85 c0             	test   %rax,%rax
    6b27:	0f 84 89 00 00 00    	je     6bb6 <fwp_owned_tape_release+0xc6>
    6b2d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6b31:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6b35:	7e 47                	jle    6b7e <fwp_owned_tape_release+0x8e>
    6b37:	31 ed                	xor    %ebp,%ebp
    6b39:	eb 0d                	jmp    6b48 <fwp_owned_tape_release+0x58>
    6b3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b40:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6b44:	48 8b 40 68          	mov    0x68(%rax),%rax
    6b48:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6b4c:	49 89 ec             	mov    %rbp,%r12
    6b4f:	48 83 c5 01          	add    $0x1,%rbp
    6b53:	49 c1 e4 04          	shl    $0x4,%r12
    6b57:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6b5b:	ff d0                	call   *%rax
    6b5d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6b61:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6b66:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6b6a:	ff 50 68             	call   *0x68(%rax)
    6b6d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6b71:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6b75:	48 39 e8             	cmp    %rbp,%rax
    6b78:	7f c6                	jg     6b40 <fwp_owned_tape_release+0x50>
    6b7a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6b7e:	31 ed                	xor    %ebp,%ebp
    6b80:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6b85:	7e 28                	jle    6baf <fwp_owned_tape_release+0xbf>
    6b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6b8e:	00 00 
    6b90:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6b94:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6b98:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6b9c:	74 07                	je     6ba5 <fwp_owned_tape_release+0xb5>
    6b9e:	ff 52 68             	call   *0x68(%rdx)
    6ba1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6ba5:	48 83 c5 01          	add    $0x1,%rbp
    6ba9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6bad:	7f e1                	jg     6b90 <fwp_owned_tape_release+0xa0>
    6baf:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6bb3:	ff 52 68             	call   *0x68(%rdx)
    6bb6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6bba:	e8 f1 fd ff ff       	call   69b0 <fwp_closure_drop>
    6bbf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6bc3:	e8 e8 fd ff ff       	call   69b0 <fwp_closure_drop>
    6bc8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6bcc:	e8 df fd ff ff       	call   69b0 <fwp_closure_drop>
    6bd1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6bd5:	e8 b6 eb ff ff       	call   5790 <fwp_mem_free>
    6bda:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6bde:	e8 ad eb ff ff       	call   5790 <fwp_mem_free>
    6be3:	48 89 df             	mov    %rbx,%rdi
    6be6:	5b                   	pop    %rbx
    6be7:	5d                   	pop    %rbp
    6be8:	41 5c                	pop    %r12
    6bea:	e9 a1 eb ff ff       	jmp    5790 <fwp_mem_free>
    6bef:	90                   	nop
    6bf0:	c3                   	ret
    6bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    6bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6bfc:	00 00 00 00 

0000000000006c00 <fwp_tape_finish>:
    6c00:	f3 0f 1e fa          	endbr64
    6c04:	41 56                	push   %r14
    6c06:	48 8d 3d 93 94 01 00 	lea    0x19493(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6c0d:	41 55                	push   %r13
    6c0f:	41 54                	push   %r12
    6c11:	55                   	push   %rbp
    6c12:	53                   	push   %rbx
    6c13:	e8 f8 d4 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    6c18:	48 83 3d c8 94 01 00 	cmpq   $0x0,0x194c8(%rip)        # 200e8 <fwp_ntapes>
    6c1f:	00 
    6c20:	48 c7 05 5d 94 01 00 	movq   $0x0,0x1945d(%rip)        # 20088 <fwp_tape_cached_bytes>
    6c27:	00 00 00 00 
    6c2b:	7e 68                	jle    6c95 <fwp_tape_finish+0x95>
    6c2d:	45 31 e4             	xor    %r12d,%r12d
    6c30:	31 ed                	xor    %ebp,%ebp
    6c32:	0f 1f 00             	nopl   (%rax)
    6c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6c3c:	00 00 00 00 
    6c40:	48 8b 1d a9 94 01 00 	mov    0x194a9(%rip),%rbx        # 200f0 <fwp_tapes>
    6c47:	48 83 c5 01          	add    $0x1,%rbp
    6c4b:	4c 01 e3             	add    %r12,%rbx
    6c4e:	49 83 c4 68          	add    $0x68,%r12
    6c52:	48 89 df             	mov    %rbx,%rdi
    6c55:	e8 a6 cf ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6c5a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6c5e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6c62:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6c66:	e8 55 c7 ff ff       	call   33c0 <free@plt>
    6c6b:	4c 89 f7             	mov    %r14,%rdi
    6c6e:	e8 4d c7 ff ff       	call   33c0 <free@plt>
    6c73:	4c 89 ef             	mov    %r13,%rdi
    6c76:	e8 45 c7 ff ff       	call   33c0 <free@plt>
    6c7b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6c7f:	e8 6c fe ff ff       	call   6af0 <fwp_owned_tape_release>
    6c84:	48 39 2d 5d 94 01 00 	cmp    %rbp,0x1945d(%rip)        # 200e8 <fwp_ntapes>
    6c8b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6c92:	00 
    6c93:	7f ab                	jg     6c40 <fwp_tape_finish+0x40>
    6c95:	48 8b 3d 54 94 01 00 	mov    0x19454(%rip),%rdi        # 200f0 <fwp_tapes>
    6c9c:	e8 1f c7 ff ff       	call   33c0 <free@plt>
    6ca1:	5b                   	pop    %rbx
    6ca2:	5d                   	pop    %rbp
    6ca3:	48 c7 05 42 94 01 00 	movq   $0x0,0x19442(%rip)        # 200f0 <fwp_tapes>
    6caa:	00 00 00 00 
    6cae:	48 c7 05 27 94 01 00 	movq   $0x0,0x19427(%rip)        # 200e0 <fwp_tapes_cap>
    6cb5:	00 00 00 00 
    6cb9:	41 5c                	pop    %r12
    6cbb:	48 c7 05 22 94 01 00 	movq   $0x0,0x19422(%rip)        # 200e8 <fwp_ntapes>
    6cc2:	00 00 00 00 
    6cc6:	41 5d                	pop    %r13
    6cc8:	48 c7 05 05 94 01 00 	movq   $0x0,0x19405(%rip)        # 200d8 <fwp_tape_next_slot>
    6ccf:	00 00 00 00 
    6cd3:	41 5e                	pop    %r14
    6cd5:	c3                   	ret
    6cd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6cdd:	00 00 00 

0000000000006ce0 <fwp_tape_scope_release>:
    6ce0:	f3 0f 1e fa          	endbr64
    6ce4:	41 55                	push   %r13
    6ce6:	41 54                	push   %r12
    6ce8:	55                   	push   %rbp
    6ce9:	53                   	push   %rbx
    6cea:	48 83 ec 58          	sub    $0x58,%rsp
    6cee:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6cf5:	00 00 
    6cf7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6cfc:	48 63 07             	movslq (%rdi),%rax
    6cff:	85 c0                	test   %eax,%eax
    6d01:	0f 88 05 01 00 00    	js     6e0c <fwp_tape_scope_release+0x12c>
    6d07:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6d0e:	ec c4 4e 
    6d11:	48 89 fb             	mov    %rdi,%rbx
    6d14:	eb 3c                	jmp    6d52 <fwp_tape_scope_release+0x72>
    6d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6d1d:	00 00 00 
    6d20:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6d25:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6d29:	e8 92 c6 ff ff       	call   33c0 <free@plt>
    6d2e:	48 8b 3c 24          	mov    (%rsp),%rdi
    6d32:	e8 89 c6 ff ff       	call   33c0 <free@plt>
    6d37:	4c 89 ef             	mov    %r13,%rdi
    6d3a:	e8 81 c6 ff ff       	call   33c0 <free@plt>
    6d3f:	4c 89 e7             	mov    %r12,%rdi
    6d42:	e8 a9 fd ff ff       	call   6af0 <fwp_owned_tape_release>
    6d47:	48 63 03             	movslq (%rbx),%rax
    6d4a:	85 c0                	test   %eax,%eax
    6d4c:	0f 88 ba 00 00 00    	js     6e0c <fwp_tape_scope_release+0x12c>
    6d52:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6d56:	48 8b 35 93 93 01 00 	mov    0x19393(%rip),%rsi        # 200f0 <fwp_tapes>
    6d5d:	4c 01 c6             	add    %r8,%rsi
    6d60:	48 89 f7             	mov    %rsi,%rdi
    6d63:	e8 98 ce ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6d68:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6d6d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6d72:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6d79:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6d7d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6d81:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6d88:	00 
    6d89:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6d8e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6d92:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6d97:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6d9b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6da0:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6da7:	00 
    6da8:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6daf:	00 
    6db0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6db7:	00 
    6db8:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6dbd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6dc2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6dc6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6dca:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6dce:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6dd4:	77 18                	ja     6dee <fwp_tape_scope_release+0x10e>
    6dd6:	49 c1 f8 03          	sar    $0x3,%r8
    6dda:	4c 0f af c5          	imul   %rbp,%r8
    6dde:	4c 3b 05 f3 92 01 00 	cmp    0x192f3(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6de5:	7d 07                	jge    6dee <fwp_tape_scope_release+0x10e>
    6de7:	4c 89 05 ea 92 01 00 	mov    %r8,0x192ea(%rip)        # 200d8 <fwp_tape_next_slot>
    6dee:	4d 85 e4             	test   %r12,%r12
    6df1:	0f 85 29 ff ff ff    	jne    6d20 <fwp_tape_scope_release+0x40>
    6df7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6dfc:	e8 6f e2 ff ff       	call   5070 <fwp_tape_buffers_release>
    6e01:	48 63 03             	movslq (%rbx),%rax
    6e04:	85 c0                	test   %eax,%eax
    6e06:	0f 89 46 ff ff ff    	jns    6d52 <fwp_tape_scope_release+0x72>
    6e0c:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6e11:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6e18:	00 00 
    6e1a:	75 0b                	jne    6e27 <fwp_tape_scope_release+0x147>
    6e1c:	48 83 c4 58          	add    $0x58,%rsp
    6e20:	5b                   	pop    %rbx
    6e21:	5d                   	pop    %rbp
    6e22:	41 5c                	pop    %r12
    6e24:	41 5d                	pop    %r13
    6e26:	c3                   	ret
    6e27:	e8 34 c6 ff ff       	call   3460 <__stack_chk_fail@plt>
    6e2c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006e30 <fwp_drop4>:
    6e30:	48 8b 0d 61 ad 01 00 	mov    0x1ad61(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    6e37:	48 89 f8             	mov    %rdi,%rax
    6e3a:	48 2b 05 2f ad 01 00 	sub    0x1ad2f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    6e41:	48 c1 e1 10          	shl    $0x10,%rcx
    6e45:	48 39 c8             	cmp    %rcx,%rax
    6e48:	0f 83 42 01 00 00    	jae    6f90 <fwp_drop4+0x160>
    6e4e:	48 83 ec 18          	sub    $0x18,%rsp
    6e52:	48 89 fa             	mov    %rdi,%rdx
    6e55:	4c 8d 05 64 99 01 00 	lea    0x19964(%rip),%r8        # 207c0 <fwp_heap>
    6e5c:	48 89 c1             	mov    %rax,%rcx
    6e5f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6e66:	48 c1 e9 10          	shr    $0x10,%rcx
    6e6a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6e6e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6e72:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6e76:	48 85 c9             	test   %rcx,%rcx
    6e79:	74 40                	je     6ebb <fwp_drop4+0x8b>
    6e7b:	0f b6 3e             	movzbl (%rsi),%edi
    6e7e:	40 80 ff 02          	cmp    $0x2,%dil
    6e82:	74 3c                	je     6ec0 <fwp_drop4+0x90>
    6e84:	40 80 ff 01          	cmp    $0x1,%dil
    6e88:	75 31                	jne    6ebb <fwp_drop4+0x8b>
    6e8a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6e8d:	0f b7 c0             	movzwl %ax,%eax
    6e90:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6e93:	48 0f af c7          	imul   %rdi,%rax
    6e97:	48 c1 e8 20          	shr    $0x20,%rax
    6e9b:	48 39 f0             	cmp    %rsi,%rax
    6e9e:	73 1b                	jae    6ebb <fwp_drop4+0x8b>
    6ea0:	48 01 c1             	add    %rax,%rcx
    6ea3:	0f b6 01             	movzbl (%rcx),%eax
    6ea6:	84 c0                	test   %al,%al
    6ea8:	74 11                	je     6ebb <fwp_drop4+0x8b>
    6eaa:	3c 01                	cmp    $0x1,%al
    6eac:	74 22                	je     6ed0 <fwp_drop4+0xa0>
    6eae:	3c ff                	cmp    $0xff,%al
    6eb0:	0f 84 0a 01 00 00    	je     6fc0 <fwp_drop4+0x190>
    6eb6:	83 e8 01             	sub    $0x1,%eax
    6eb9:	88 01                	mov    %al,(%rcx)
    6ebb:	48 83 c4 18          	add    $0x18,%rsp
    6ebf:	c3                   	ret
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	74 de                	je     6ea3 <fwp_drop4+0x73>
    6ec5:	48 83 c4 18          	add    $0x18,%rsp
    6ec9:	c3                   	ret
    6eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6ed4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6edb:	48 89 f8             	mov    %rdi,%rax
    6ede:	48 c1 e1 10          	shl    $0x10,%rcx
    6ee2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ee9:	48 39 c8             	cmp    %rcx,%rax
    6eec:	73 62                	jae    6f50 <fwp_drop4+0x120>
    6eee:	48 89 c1             	mov    %rax,%rcx
    6ef1:	48 c1 e9 10          	shr    $0x10,%rcx
    6ef5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6ef9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6efd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6f01:	48 85 c9             	test   %rcx,%rcx
    6f04:	74 4a                	je     6f50 <fwp_drop4+0x120>
    6f06:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6f0a:	41 80 f9 02          	cmp    $0x2,%r9b
    6f0e:	0f 84 9c 00 00 00    	je     6fb0 <fwp_drop4+0x180>
    6f14:	41 80 f9 01          	cmp    $0x1,%r9b
    6f18:	75 36                	jne    6f50 <fwp_drop4+0x120>
    6f1a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6f1e:	0f b7 c0             	movzwl %ax,%eax
    6f21:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6f24:	49 0f af c1          	imul   %r9,%rax
    6f28:	48 c1 e8 20          	shr    $0x20,%rax
    6f2c:	48 39 f0             	cmp    %rsi,%rax
    6f2f:	73 1f                	jae    6f50 <fwp_drop4+0x120>
    6f31:	48 01 c1             	add    %rax,%rcx
    6f34:	0f b6 01             	movzbl (%rcx),%eax
    6f37:	84 c0                	test   %al,%al
    6f39:	74 15                	je     6f50 <fwp_drop4+0x120>
    6f3b:	3c 01                	cmp    $0x1,%al
    6f3d:	74 59                	je     6f98 <fwp_drop4+0x168>
    6f3f:	3c ff                	cmp    $0xff,%al
    6f41:	0f 84 ff 00 00 00    	je     7046 <fwp_drop4+0x216>
    6f47:	83 e8 01             	sub    $0x1,%eax
    6f4a:	88 01                	mov    %al,(%rcx)
    6f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6f50:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6f54:	48 89 d7             	mov    %rdx,%rdi
    6f57:	48 89 0c 24          	mov    %rcx,(%rsp)
    6f5b:	e8 40 f7 ff ff       	call   66a0 <fwp_rc_free_obj>
    6f60:	4c 8d 05 59 98 01 00 	lea    0x19859(%rip),%r8        # 207c0 <fwp_heap>
    6f67:	48 8b 04 24          	mov    (%rsp),%rax
    6f6b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6f72:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6f79:	48 c1 e2 10          	shl    $0x10,%rdx
    6f7d:	48 39 d0             	cmp    %rdx,%rax
    6f80:	0f 83 35 ff ff ff    	jae    6ebb <fwp_drop4+0x8b>
    6f86:	48 8b 14 24          	mov    (%rsp),%rdx
    6f8a:	e9 cd fe ff ff       	jmp    6e5c <fwp_drop4+0x2c>
    6f8f:	90                   	nop
    6f90:	c3                   	ret
    6f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f98:	48 89 14 24          	mov    %rdx,(%rsp)
    6f9c:	e8 ff f6 ff ff       	call   66a0 <fwp_rc_free_obj>
    6fa1:	48 8b 14 24          	mov    (%rsp),%rdx
    6fa5:	eb a9                	jmp    6f50 <fwp_drop4+0x120>
    6fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6fae:	00 00 
    6fb0:	66 85 c0             	test   %ax,%ax
    6fb3:	75 9b                	jne    6f50 <fwp_drop4+0x120>
    6fb5:	e9 7a ff ff ff       	jmp    6f34 <fwp_drop4+0x104>
    6fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6fc0:	48 89 c8             	mov    %rcx,%rax
    6fc3:	48 c1 e8 11          	shr    $0x11,%rax
    6fc7:	48 31 c8             	xor    %rcx,%rax
    6fca:	48 89 c2             	mov    %rax,%rdx
    6fcd:	48 c1 ea 09          	shr    $0x9,%rdx
    6fd1:	48 31 d0             	xor    %rdx,%rax
    6fd4:	0f b6 d0             	movzbl %al,%edx
    6fd7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6fde:	00 
    6fdf:	48 85 c0             	test   %rax,%rax
    6fe2:	75 29                	jne    700d <fwp_drop4+0x1dd>
    6fe4:	e9 e3 00 00 00       	jmp    70cc <fwp_drop4+0x29c>
    6fe9:	90                   	nop
    6fea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ff1:	00 00 00 00 
    6ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6ffc:	00 00 00 00 
    7000:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7004:	48 85 c0             	test   %rax,%rax
    7007:	0f 84 bf 00 00 00    	je     70cc <fwp_drop4+0x29c>
    700d:	48 89 c2             	mov    %rax,%rdx
    7010:	48 39 08             	cmp    %rcx,(%rax)
    7013:	75 eb                	jne    7000 <fwp_drop4+0x1d0>
    7015:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7019:	48 83 ea 01          	sub    $0x1,%rdx
    701d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7021:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7028:	0f 85 8d fe ff ff    	jne    6ebb <fwp_drop4+0x8b>
    702e:	48 89 cf             	mov    %rcx,%rdi
    7031:	48 89 0c 24          	mov    %rcx,(%rsp)
    7035:	e8 16 e5 ff ff       	call   5550 <fwp_rc_forget_slot>
    703a:	48 8b 0c 24          	mov    (%rsp),%rcx
    703e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7041:	e9 75 fe ff ff       	jmp    6ebb <fwp_drop4+0x8b>
    7046:	48 89 ce             	mov    %rcx,%rsi
    7049:	48 c1 ee 11          	shr    $0x11,%rsi
    704d:	48 31 ce             	xor    %rcx,%rsi
    7050:	48 89 f0             	mov    %rsi,%rax
    7053:	48 c1 e8 09          	shr    $0x9,%rax
    7057:	48 31 c6             	xor    %rax,%rsi
    705a:	40 0f b6 f6          	movzbl %sil,%esi
    705e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7065:	00 
    7066:	48 85 c0             	test   %rax,%rax
    7069:	75 1e                	jne    7089 <fwp_drop4+0x259>
    706b:	eb 5f                	jmp    70cc <fwp_drop4+0x29c>
    706d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7074:	00 
    7075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    707c:	00 00 00 00 
    7080:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	74 43                	je     70cc <fwp_drop4+0x29c>
    7089:	48 89 c6             	mov    %rax,%rsi
    708c:	48 39 08             	cmp    %rcx,(%rax)
    708f:	75 ef                	jne    7080 <fwp_drop4+0x250>
    7091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7095:	48 83 ee 01          	sub    $0x1,%rsi
    7099:	48 89 70 08          	mov    %rsi,0x8(%rax)
    709d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    70a4:	0f 85 a6 fe ff ff    	jne    6f50 <fwp_drop4+0x120>
    70aa:	48 89 cf             	mov    %rcx,%rdi
    70ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    70b6:	e8 95 e4 ff ff       	call   5550 <fwp_rc_forget_slot>
    70bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    70bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    70c7:	e9 84 fe ff ff       	jmp    6f50 <fwp_drop4+0x120>
    70cc:	48 8d 3d bd 57 00 00 	lea    0x57bd(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    70d3:	e8 18 d3 ff ff       	call   43f0 <fwp_trap>
    70d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70df:	00 

00000000000070e0 <fwp_arg_drop37>:
    70e0:	f3 0f 1e fa          	endbr64
    70e4:	85 f6                	test   %esi,%esi
    70e6:	75 04                	jne    70ec <fwp_arg_drop37+0xc>
    70e8:	85 d2                	test   %edx,%edx
    70ea:	75 04                	jne    70f0 <fwp_arg_drop37+0x10>
    70ec:	c3                   	ret
    70ed:	0f 1f 00             	nopl   (%rax)
    70f0:	48 8b 3f             	mov    (%rdi),%rdi
    70f3:	e9 38 fd ff ff       	jmp    6e30 <fwp_drop4>
    70f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    70ff:	00 

0000000000007100 <fwp_task_dispose>:
    7100:	53                   	push   %rbx
    7101:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7105:	0f 84 3b c6 ff ff    	je     3746 <fwp_task_dispose.cold>
    710b:	48 89 fb             	mov    %rdi,%rbx
    710e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7113:	0f 85 2d c6 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7119:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    711d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7124:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    712b:	00 
    712c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7130:	48 85 ff             	test   %rdi,%rdi
    7133:	74 07                	je     713c <fwp_task_dispose+0x3c>
    7135:	48 85 c0             	test   %rax,%rax
    7138:	74 02                	je     713c <fwp_task_dispose+0x3c>
    713a:	ff d0                	call   *%rax
    713c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7143:	e8 48 e6 ff ff       	call   5790 <fwp_mem_free>
    7148:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    714f:	00 00 00 00 
    7153:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7157:	74 6f                	je     71c8 <fwp_task_dispose+0xc8>
    7159:	48 8b 15 38 aa 01 00 	mov    0x1aa38(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7160:	48 89 d8             	mov    %rbx,%rax
    7163:	48 2b 05 06 aa 01 00 	sub    0x1aa06(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    716a:	48 c1 e2 10          	shl    $0x10,%rdx
    716e:	48 39 d0             	cmp    %rdx,%rax
    7171:	73 4c                	jae    71bf <fwp_task_dispose+0xbf>
    7173:	48 89 c2             	mov    %rax,%rdx
    7176:	48 c1 ea 10          	shr    $0x10,%rdx
    717a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    717e:	48 8b 15 33 aa 01 00 	mov    0x1aa33(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7185:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7189:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    718d:	48 85 c9             	test   %rcx,%rcx
    7190:	74 2d                	je     71bf <fwp_task_dispose+0xbf>
    7192:	0f b6 32             	movzbl (%rdx),%esi
    7195:	40 80 fe 02          	cmp    $0x2,%sil
    7199:	74 3d                	je     71d8 <fwp_task_dispose+0xd8>
    719b:	40 80 fe 01          	cmp    $0x1,%sil
    719f:	75 1e                	jne    71bf <fwp_task_dispose+0xbf>
    71a1:	8b 72 18             	mov    0x18(%rdx),%esi
    71a4:	0f b7 c0             	movzwl %ax,%eax
    71a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    71aa:	48 0f af c6          	imul   %rsi,%rax
    71ae:	48 c1 e8 20          	shr    $0x20,%rax
    71b2:	48 39 d0             	cmp    %rdx,%rax
    71b5:	73 08                	jae    71bf <fwp_task_dispose+0xbf>
    71b7:	48 01 c1             	add    %rax,%rcx
    71ba:	80 39 01             	cmpb   $0x1,(%rcx)
    71bd:	74 09                	je     71c8 <fwp_task_dispose+0xc8>
    71bf:	5b                   	pop    %rbx
    71c0:	c3                   	ret
    71c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71c8:	48 89 df             	mov    %rbx,%rdi
    71cb:	5b                   	pop    %rbx
    71cc:	e9 bf e5 ff ff       	jmp    5790 <fwp_mem_free>
    71d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    71d8:	66 85 c0             	test   %ax,%ax
    71db:	74 dd                	je     71ba <fwp_task_dispose+0xba>
    71dd:	5b                   	pop    %rbx
    71de:	c3                   	ret
    71df:	90                   	nop

00000000000071e0 <fwp_free_zombie>:
    71e0:	48 8b 15 a9 95 01 00 	mov    0x195a9(%rip),%rdx        # 20790 <fwp_zombie>
    71e7:	48 85 d2             	test   %rdx,%rdx
    71ea:	0f 84 98 00 00 00    	je     7288 <fwp_free_zombie+0xa8>
    71f0:	48 3b 15 a9 95 01 00 	cmp    0x195a9(%rip),%rdx        # 207a0 <fwp_cur>
    71f7:	0f 84 8b 00 00 00    	je     7288 <fwp_free_zombie+0xa8>
    71fd:	48 83 ec 18          	sub    $0x18,%rsp
    7201:	48 63 05 5c 8f 01 00 	movslq 0x18f5c(%rip),%rax        # 20164 <fwp_stack_pool_n>
    7208:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    720c:	83 f8 3f             	cmp    $0x3f,%eax
    720f:	7f 7f                	jg     7290 <fwp_free_zombie+0xb0>
    7211:	8d 48 01             	lea    0x1(%rax),%ecx
    7214:	89 0d 4a 8f 01 00    	mov    %ecx,0x18f4a(%rip)        # 20164 <fwp_stack_pool_n>
    721a:	48 8d 0d 5f 8f 01 00 	lea    0x18f5f(%rip),%rcx        # 20180 <fwp_stack_pool>
    7221:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7225:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    722c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7230:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7237:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    723b:	48 85 c9             	test   %rcx,%rcx
    723e:	0f 84 fc 00 00 00    	je     7340 <fwp_free_zombie+0x160>
    7244:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    724b:	48 85 c0             	test   %rax,%rax
    724e:	74 07                	je     7257 <fwp_free_zombie+0x77>
    7250:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7257:	8b 42 5c             	mov    0x5c(%rdx),%eax
    725a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    725e:	48 c7 05 27 95 01 00 	movq   $0x0,0x19527(%rip)        # 20790 <fwp_zombie>
    7265:	00 00 00 00 
    7269:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7270:	85 c0                	test   %eax,%eax
    7272:	74 34                	je     72a8 <fwp_free_zombie+0xc8>
    7274:	83 f8 01             	cmp    $0x1,%eax
    7277:	0f 84 b3 00 00 00    	je     7330 <fwp_free_zombie+0x150>
    727d:	48 83 c4 18          	add    $0x18,%rsp
    7281:	c3                   	ret
    7282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7288:	c3                   	ret
    7289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7290:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7294:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7299:	e8 42 c3 ff ff       	call   35e0 <munmap@plt>
    729e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    72a3:	eb 80                	jmp    7225 <fwp_free_zombie+0x45>
    72a5:	0f 1f 00             	nopl   (%rax)
    72a8:	48 8b 0d e9 a8 01 00 	mov    0x1a8e9(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    72af:	48 89 d0             	mov    %rdx,%rax
    72b2:	48 2b 05 b7 a8 01 00 	sub    0x1a8b7(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    72b9:	48 c1 e1 10          	shl    $0x10,%rcx
    72bd:	48 39 c8             	cmp    %rcx,%rax
    72c0:	73 bb                	jae    727d <fwp_free_zombie+0x9d>
    72c2:	48 89 c1             	mov    %rax,%rcx
    72c5:	48 c1 e9 10          	shr    $0x10,%rcx
    72c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    72cd:	48 8b 0d e4 a8 01 00 	mov    0x1a8e4(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    72d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    72d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    72dc:	48 85 c9             	test   %rcx,%rcx
    72df:	74 9c                	je     727d <fwp_free_zombie+0x9d>
    72e1:	0f b6 3e             	movzbl (%rsi),%edi
    72e4:	40 80 ff 02          	cmp    $0x2,%dil
    72e8:	74 66                	je     7350 <fwp_free_zombie+0x170>
    72ea:	40 80 ff 01          	cmp    $0x1,%dil
    72ee:	75 8d                	jne    727d <fwp_free_zombie+0x9d>
    72f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    72f3:	0f b7 c0             	movzwl %ax,%eax
    72f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    72f9:	48 0f af c7          	imul   %rdi,%rax
    72fd:	48 c1 e8 20          	shr    $0x20,%rax
    7301:	48 39 f0             	cmp    %rsi,%rax
    7304:	0f 83 73 ff ff ff    	jae    727d <fwp_free_zombie+0x9d>
    730a:	48 01 c1             	add    %rax,%rcx
    730d:	0f b6 01             	movzbl (%rcx),%eax
    7310:	84 c0                	test   %al,%al
    7312:	0f 84 65 ff ff ff    	je     727d <fwp_free_zombie+0x9d>
    7318:	3c 01                	cmp    $0x1,%al
    731a:	74 14                	je     7330 <fwp_free_zombie+0x150>
    731c:	3c ff                	cmp    $0xff,%al
    731e:	74 3b                	je     735b <fwp_free_zombie+0x17b>
    7320:	83 e8 01             	sub    $0x1,%eax
    7323:	88 01                	mov    %al,(%rcx)
    7325:	e9 53 ff ff ff       	jmp    727d <fwp_free_zombie+0x9d>
    732a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7330:	48 89 d7             	mov    %rdx,%rdi
    7333:	48 83 c4 18          	add    $0x18,%rsp
    7337:	e9 c4 fd ff ff       	jmp    7100 <fwp_task_dispose>
    733c:	0f 1f 40 00          	nopl   0x0(%rax)
    7340:	48 89 05 21 94 01 00 	mov    %rax,0x19421(%rip)        # 20768 <fwp_tasks_active>
    7347:	e9 ff fe ff ff       	jmp    724b <fwp_free_zombie+0x6b>
    734c:	0f 1f 40 00          	nopl   0x0(%rax)
    7350:	66 85 c0             	test   %ax,%ax
    7353:	0f 85 24 ff ff ff    	jne    727d <fwp_free_zombie+0x9d>
    7359:	eb b2                	jmp    730d <fwp_free_zombie+0x12d>
    735b:	48 89 ca             	mov    %rcx,%rdx
    735e:	48 8d 35 5b 94 01 00 	lea    0x1945b(%rip),%rsi        # 207c0 <fwp_heap>
    7365:	48 c1 ea 11          	shr    $0x11,%rdx
    7369:	48 31 ca             	xor    %rcx,%rdx
    736c:	48 89 d0             	mov    %rdx,%rax
    736f:	48 c1 e8 09          	shr    $0x9,%rax
    7373:	48 31 c2             	xor    %rax,%rdx
    7376:	0f b6 d2             	movzbl %dl,%edx
    7379:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7380:	00 
    7381:	48 85 c0             	test   %rax,%rax
    7384:	75 23                	jne    73a9 <fwp_free_zombie+0x1c9>
    7386:	eb 5c                	jmp    73e4 <fwp_free_zombie+0x204>
    7388:	66 90                	xchg   %ax,%ax
    738a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7391:	00 00 00 00 
    7395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    739c:	00 00 00 00 
    73a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    73a4:	48 85 c0             	test   %rax,%rax
    73a7:	74 3b                	je     73e4 <fwp_free_zombie+0x204>
    73a9:	48 89 c2             	mov    %rax,%rdx
    73ac:	48 39 08             	cmp    %rcx,(%rax)
    73af:	75 ef                	jne    73a0 <fwp_free_zombie+0x1c0>
    73b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    73b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    73b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    73bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    73c4:	0f 85 b3 fe ff ff    	jne    727d <fwp_free_zombie+0x9d>
    73ca:	48 89 cf             	mov    %rcx,%rdi
    73cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    73d2:	e8 79 e1 ff ff       	call   5550 <fwp_rc_forget_slot>
    73d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    73dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    73df:	e9 99 fe ff ff       	jmp    727d <fwp_free_zombie+0x9d>
    73e4:	48 8d 3d a5 54 00 00 	lea    0x54a5(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    73eb:	e8 00 d0 ff ff       	call   43f0 <fwp_trap>

00000000000073f0 <fwp_block>:
    73f0:	48 83 ec 08          	sub    $0x8,%rsp
    73f4:	48 8b 05 8d 93 01 00 	mov    0x1938d(%rip),%rax        # 20788 <fwp_ready_head>
    73fb:	48 85 c0             	test   %rax,%rax
    73fe:	0f 84 1c 01 00 00    	je     7520 <fwp_block+0x130>
    7404:	90                   	nop
    7405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    740c:	00 00 00 00 
    7410:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7417:	48 89 15 6a 93 01 00 	mov    %rdx,0x1936a(%rip)        # 20788 <fwp_ready_head>
    741e:	48 85 d2             	test   %rdx,%rdx
    7421:	0f 84 19 01 00 00    	je     7540 <fwp_block+0x150>
    7427:	48 8b 15 72 93 01 00 	mov    0x19372(%rip),%rdx        # 207a0 <fwp_cur>
    742e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7432:	48 39 c2             	cmp    %rax,%rdx
    7435:	0f 84 d5 00 00 00    	je     7510 <fwp_block+0x120>
    743b:	48 8b 0d e6 af 01 00 	mov    0x1afe6(%rip),%rcx        # 22428 <fwp_state_owners>
    7442:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7446:	48 89 05 53 93 01 00 	mov    %rax,0x19353(%rip)        # 207a0 <fwp_cur>
    744d:	f3 0f 7e 05 fb af 01 	movq   0x1affb(%rip),%xmm0        # 22450 <fwp_foreign_callbacks>
    7454:	00 
    7455:	0f 16 05 e4 af 01 00 	movhps 0x1afe4(%rip),%xmm0        # 22440 <fwp_state>
    745c:	f3 0f 7e 0d e4 af 01 	movq   0x1afe4(%rip),%xmm1        # 22448 <fwp_handlers>
    7463:	00 
    7464:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    746b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7472:	0f 16 0d df af 01 00 	movhps 0x1afdf(%rip),%xmm1        # 22458 <fwp_cleanups>
    7479:	f3 0f 7e 05 b7 af 01 	movq   0x1afb7(%rip),%xmm0        # 22438 <fwp_state_len>
    7480:	00 
    7481:	0f 16 05 a8 af 01 00 	movhps 0x1afa8(%rip),%xmm0        # 22430 <fwp_state_cap>
    7488:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    748f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7496:	48 8b 70 08          	mov    0x8(%rax),%rsi
    749a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    74a1:	48 89 0d a0 af 01 00 	mov    %rcx,0x1afa0(%rip)        # 22448 <fwp_handlers>
    74a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    74af:	48 89 0d a2 af 01 00 	mov    %rcx,0x1afa2(%rip)        # 22458 <fwp_cleanups>
    74b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    74bd:	48 89 0d 8c af 01 00 	mov    %rcx,0x1af8c(%rip)        # 22450 <fwp_foreign_callbacks>
    74c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    74cb:	48 89 0d 6e af 01 00 	mov    %rcx,0x1af6e(%rip)        # 22440 <fwp_state>
    74d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    74d9:	48 89 0d 58 af 01 00 	mov    %rcx,0x1af58(%rip)        # 22438 <fwp_state_len>
    74e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    74e7:	48 89 0d 42 af 01 00 	mov    %rcx,0x1af42(%rip)        # 22430 <fwp_state_cap>
    74ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    74f5:	48 89 0d 2c af 01 00 	mov    %rcx,0x1af2c(%rip)        # 22428 <fwp_state_owners>
    74fc:	e8 8f bf ff ff       	call   3490 <swapcontext@plt>
    7501:	f3 0f 1e fa          	endbr64
    7505:	e8 d6 fc ff ff       	call   71e0 <fwp_free_zombie>
    750a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7510:	8b 05 4a 8c 01 00    	mov    0x18c4a(%rip),%eax        # 20160 <fwp_slice>
    7516:	85 c0                	test   %eax,%eax
    7518:	74 36                	je     7550 <fwp_block+0x160>
    751a:	48 83 c4 08          	add    $0x8,%rsp
    751e:	c3                   	ret
    751f:	90                   	nop
    7520:	e8 7b dc ff ff       	call   51a0 <fwp_poll_events>
    7525:	48 8b 05 5c 92 01 00 	mov    0x1925c(%rip),%rax        # 20788 <fwp_ready_head>
    752c:	48 85 c0             	test   %rax,%rax
    752f:	0f 85 db fe ff ff    	jne    7410 <fwp_block+0x20>
    7535:	eb e9                	jmp    7520 <fwp_block+0x130>
    7537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    753e:	00 00 
    7540:	48 c7 05 35 92 01 00 	movq   $0x0,0x19235(%rip)        # 20780 <fwp_ready_tail>
    7547:	00 00 00 00 
    754b:	e9 d7 fe ff ff       	jmp    7427 <fwp_block+0x37>
    7550:	48 8d 3d 2d 4c 00 00 	lea    0x4c2d(%rip),%rdi        # c184 <_IO_stdin_used+0x184>
    7557:	e8 44 be ff ff       	call   33a0 <getenv@plt>
    755c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7561:	48 85 c0             	test   %rax,%rax
    7564:	74 05                	je     756b <fwp_block+0x17b>
    7566:	80 38 00             	cmpb   $0x0,(%rax)
    7569:	75 0b                	jne    7576 <fwp_block+0x186>
    756b:	89 15 ef 8b 01 00    	mov    %edx,0x18bef(%rip)        # 20160 <fwp_slice>
    7571:	48 83 c4 08          	add    $0x8,%rsp
    7575:	c3                   	ret
    7576:	ba 0a 00 00 00       	mov    $0xa,%edx
    757b:	31 f6                	xor    %esi,%esi
    757d:	48 89 c7             	mov    %rax,%rdi
    7580:	e8 cb bf ff ff       	call   3550 <strtoll@plt>
    7585:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7589:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7590:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7595:	0f 46 d0             	cmovbe %eax,%edx
    7598:	eb d1                	jmp    756b <fwp_block+0x17b>
    759a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000075a0 <fwp_caps173>:
    75a0:	f3 0f 1e fa          	endbr64
    75a4:	85 f6                	test   %esi,%esi
    75a6:	74 08                	je     75b0 <fwp_caps173+0x10>
    75a8:	c3                   	ret
    75a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75b0:	48 8b 15 e1 a5 01 00 	mov    0x1a5e1(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    75b7:	48 89 f8             	mov    %rdi,%rax
    75ba:	48 2b 05 af a5 01 00 	sub    0x1a5af(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    75c1:	48 c1 e2 10          	shl    $0x10,%rdx
    75c5:	48 39 d0             	cmp    %rdx,%rax
    75c8:	73 de                	jae    75a8 <fwp_caps173+0x8>
    75ca:	48 89 c2             	mov    %rax,%rdx
    75cd:	48 c1 ea 10          	shr    $0x10,%rdx
    75d1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    75d5:	48 8b 15 dc a5 01 00 	mov    0x1a5dc(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    75dc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    75e0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    75e4:	48 85 c9             	test   %rcx,%rcx
    75e7:	74 bf                	je     75a8 <fwp_caps173+0x8>
    75e9:	0f b6 32             	movzbl (%rdx),%esi
    75ec:	40 80 fe 02          	cmp    $0x2,%sil
    75f0:	74 2e                	je     7620 <fwp_caps173+0x80>
    75f2:	40 80 fe 01          	cmp    $0x1,%sil
    75f6:	75 b0                	jne    75a8 <fwp_caps173+0x8>
    75f8:	8b 72 18             	mov    0x18(%rdx),%esi
    75fb:	0f b7 c0             	movzwl %ax,%eax
    75fe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7601:	48 0f af c6          	imul   %rsi,%rax
    7605:	48 c1 e8 20          	shr    $0x20,%rax
    7609:	48 39 d0             	cmp    %rdx,%rax
    760c:	73 9a                	jae    75a8 <fwp_caps173+0x8>
    760e:	48 01 c1             	add    %rax,%rcx
    7611:	80 39 01             	cmpb   $0x1,(%rcx)
    7614:	75 92                	jne    75a8 <fwp_caps173+0x8>
    7616:	e9 75 e1 ff ff       	jmp    5790 <fwp_mem_free>
    761b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7620:	66 85 c0             	test   %ax,%ax
    7623:	74 ec                	je     7611 <fwp_caps173+0x71>
    7625:	c3                   	ret
    7626:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    762d:	00 00 00 

0000000000007630 <fwp_args37>:
    7630:	f3 0f 1e fa          	endbr64
    7634:	85 d2                	test   %edx,%edx
    7636:	74 04                	je     763c <fwp_args37+0xc>
    7638:	85 f6                	test   %esi,%esi
    763a:	74 04                	je     7640 <fwp_args37+0x10>
    763c:	c3                   	ret
    763d:	0f 1f 00             	nopl   (%rax)
    7640:	48 8b 15 51 a5 01 00 	mov    0x1a551(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7647:	48 8b 07             	mov    (%rdi),%rax
    764a:	48 2b 05 1f a5 01 00 	sub    0x1a51f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7651:	48 c1 e2 10          	shl    $0x10,%rdx
    7655:	48 39 d0             	cmp    %rdx,%rax
    7658:	73 e2                	jae    763c <fwp_args37+0xc>
    765a:	48 89 c2             	mov    %rax,%rdx
    765d:	48 c1 ea 10          	shr    $0x10,%rdx
    7661:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7665:	48 8b 15 4c a5 01 00 	mov    0x1a54c(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    766c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7670:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7674:	48 85 ff             	test   %rdi,%rdi
    7677:	74 c3                	je     763c <fwp_args37+0xc>
    7679:	0f b6 0a             	movzbl (%rdx),%ecx
    767c:	80 f9 02             	cmp    $0x2,%cl
    767f:	74 2f                	je     76b0 <fwp_args37+0x80>
    7681:	80 f9 01             	cmp    $0x1,%cl
    7684:	75 b6                	jne    763c <fwp_args37+0xc>
    7686:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7689:	0f b7 c0             	movzwl %ax,%eax
    768c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    768f:	48 0f af c1          	imul   %rcx,%rax
    7693:	48 c1 e8 20          	shr    $0x20,%rax
    7697:	48 39 d0             	cmp    %rdx,%rax
    769a:	73 a0                	jae    763c <fwp_args37+0xc>
    769c:	48 01 c7             	add    %rax,%rdi
    769f:	0f b6 07             	movzbl (%rdi),%eax
    76a2:	84 c0                	test   %al,%al
    76a4:	74 96                	je     763c <fwp_args37+0xc>
    76a6:	3c fd                	cmp    $0xfd,%al
    76a8:	77 0c                	ja     76b6 <fwp_args37+0x86>
    76aa:	83 c0 01             	add    $0x1,%eax
    76ad:	88 07                	mov    %al,(%rdi)
    76af:	c3                   	ret
    76b0:	66 85 c0             	test   %ax,%ax
    76b3:	74 ea                	je     769f <fwp_args37+0x6f>
    76b5:	c3                   	ret
    76b6:	e9 75 dd ff ff       	jmp    5430 <fwp_rc_wide_dup>
    76bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

00000000000076c0 <fwp_caps37>:
    76c0:	f3 0f 1e fa          	endbr64
    76c4:	48 83 ec 18          	sub    $0x18,%rsp
    76c8:	8b 57 04             	mov    0x4(%rdi),%edx
    76cb:	48 89 f8             	mov    %rdi,%rax
    76ce:	85 d2                	test   %edx,%edx
    76d0:	0f 84 9a 00 00 00    	je     7770 <fwp_caps37+0xb0>
    76d6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    76da:	85 f6                	test   %esi,%esi
    76dc:	0f 85 9e 00 00 00    	jne    7780 <fwp_caps37+0xc0>
    76e2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    76e7:	e8 44 f7 ff ff       	call   6e30 <fwp_drop4>
    76ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    76f1:	48 8b 0d a0 a4 01 00 	mov    0x1a4a0(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    76f8:	48 89 c2             	mov    %rax,%rdx
    76fb:	48 2b 15 6e a4 01 00 	sub    0x1a46e(%rip),%rdx        # 21b70 <fwp_heap+0x13b0>
    7702:	48 c1 e1 10          	shl    $0x10,%rcx
    7706:	48 39 ca             	cmp    %rcx,%rdx
    7709:	73 6d                	jae    7778 <fwp_caps37+0xb8>
    770b:	48 89 d1             	mov    %rdx,%rcx
    770e:	48 c1 e9 10          	shr    $0x10,%rcx
    7712:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7716:	48 8b 0d 9b a4 01 00 	mov    0x1a49b(%rip),%rcx        # 21bb8 <fwp_heap+0x13f8>
    771d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7721:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7725:	48 85 f6             	test   %rsi,%rsi
    7728:	74 4e                	je     7778 <fwp_caps37+0xb8>
    772a:	0f b6 39             	movzbl (%rcx),%edi
    772d:	40 80 ff 02          	cmp    $0x2,%dil
    7731:	0f 84 b9 00 00 00    	je     77f0 <fwp_caps37+0x130>
    7737:	40 80 ff 01          	cmp    $0x1,%dil
    773b:	75 3b                	jne    7778 <fwp_caps37+0xb8>
    773d:	8b 79 18             	mov    0x18(%rcx),%edi
    7740:	0f b7 d2             	movzwl %dx,%edx
    7743:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7746:	48 0f af d7          	imul   %rdi,%rdx
    774a:	48 c1 ea 20          	shr    $0x20,%rdx
    774e:	48 39 ca             	cmp    %rcx,%rdx
    7751:	73 25                	jae    7778 <fwp_caps37+0xb8>
    7753:	48 01 d6             	add    %rdx,%rsi
    7756:	80 3e 01             	cmpb   $0x1,(%rsi)
    7759:	75 1d                	jne    7778 <fwp_caps37+0xb8>
    775b:	48 89 c7             	mov    %rax,%rdi
    775e:	48 83 c4 18          	add    $0x18,%rsp
    7762:	e9 29 e0 ff ff       	jmp    5790 <fwp_mem_free>
    7767:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    776e:	00 00 
    7770:	85 f6                	test   %esi,%esi
    7772:	0f 84 79 ff ff ff    	je     76f1 <fwp_caps37+0x31>
    7778:	48 83 c4 18          	add    $0x18,%rsp
    777c:	c3                   	ret
    777d:	0f 1f 00             	nopl   (%rax)
    7780:	48 8b 05 11 a4 01 00 	mov    0x1a411(%rip),%rax        # 21b98 <fwp_heap+0x13d8>
    7787:	48 2b 3d e2 a3 01 00 	sub    0x1a3e2(%rip),%rdi        # 21b70 <fwp_heap+0x13b0>
    778e:	48 c1 e0 10          	shl    $0x10,%rax
    7792:	48 39 c7             	cmp    %rax,%rdi
    7795:	73 e1                	jae    7778 <fwp_caps37+0xb8>
    7797:	48 89 f8             	mov    %rdi,%rax
    779a:	48 c1 e8 10          	shr    $0x10,%rax
    779e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    77a2:	48 8b 05 0f a4 01 00 	mov    0x1a40f(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    77a9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    77ad:	48 8b 42 20          	mov    0x20(%rdx),%rax
    77b1:	48 85 c0             	test   %rax,%rax
    77b4:	74 c2                	je     7778 <fwp_caps37+0xb8>
    77b6:	0f b6 0a             	movzbl (%rdx),%ecx
    77b9:	80 f9 02             	cmp    $0x2,%cl
    77bc:	74 42                	je     7800 <fwp_caps37+0x140>
    77be:	80 f9 01             	cmp    $0x1,%cl
    77c1:	75 b5                	jne    7778 <fwp_caps37+0xb8>
    77c3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    77c6:	0f b7 ff             	movzwl %di,%edi
    77c9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    77cc:	48 0f af f9          	imul   %rcx,%rdi
    77d0:	48 c1 ef 20          	shr    $0x20,%rdi
    77d4:	48 39 d7             	cmp    %rdx,%rdi
    77d7:	73 9f                	jae    7778 <fwp_caps37+0xb8>
    77d9:	48 01 f8             	add    %rdi,%rax
    77dc:	0f b6 10             	movzbl (%rax),%edx
    77df:	84 d2                	test   %dl,%dl
    77e1:	74 95                	je     7778 <fwp_caps37+0xb8>
    77e3:	80 fa fd             	cmp    $0xfd,%dl
    77e6:	77 23                	ja     780b <fwp_caps37+0x14b>
    77e8:	83 c2 01             	add    $0x1,%edx
    77eb:	88 10                	mov    %dl,(%rax)
    77ed:	eb 89                	jmp    7778 <fwp_caps37+0xb8>
    77ef:	90                   	nop
    77f0:	66 85 d2             	test   %dx,%dx
    77f3:	0f 85 7f ff ff ff    	jne    7778 <fwp_caps37+0xb8>
    77f9:	e9 58 ff ff ff       	jmp    7756 <fwp_caps37+0x96>
    77fe:	66 90                	xchg   %ax,%ax
    7800:	66 85 ff             	test   %di,%di
    7803:	0f 85 6f ff ff ff    	jne    7778 <fwp_caps37+0xb8>
    7809:	eb d1                	jmp    77dc <fwp_caps37+0x11c>
    780b:	48 89 c7             	mov    %rax,%rdi
    780e:	48 83 c4 18          	add    $0x18,%rsp
    7812:	e9 19 dc ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    781e:	00 00 

0000000000007820 <fwp_drop0>:
    7820:	f3 0f 1e fa          	endbr64
    7824:	48 8b 15 6d a3 01 00 	mov    0x1a36d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    782b:	48 89 f8             	mov    %rdi,%rax
    782e:	48 2b 05 3b a3 01 00 	sub    0x1a33b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7835:	48 c1 e2 10          	shl    $0x10,%rdx
    7839:	48 39 d0             	cmp    %rdx,%rax
    783c:	0f 83 36 01 00 00    	jae    7978 <fwp_drop0+0x158>
    7842:	48 83 ec 18          	sub    $0x18,%rsp
    7846:	48 8d 35 73 8f 01 00 	lea    0x18f73(%rip),%rsi        # 207c0 <fwp_heap>
    784d:	48 89 c2             	mov    %rax,%rdx
    7850:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7857:	48 c1 ea 10          	shr    $0x10,%rdx
    785b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    785f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7863:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7867:	48 85 d2             	test   %rdx,%rdx
    786a:	74 42                	je     78ae <fwp_drop0+0x8e>
    786c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7870:	41 80 f8 02          	cmp    $0x2,%r8b
    7874:	74 42                	je     78b8 <fwp_drop0+0x98>
    7876:	41 80 f8 01          	cmp    $0x1,%r8b
    787a:	75 32                	jne    78ae <fwp_drop0+0x8e>
    787c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7880:	0f b7 c0             	movzwl %ax,%eax
    7883:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7886:	49 0f af c0          	imul   %r8,%rax
    788a:	48 c1 e8 20          	shr    $0x20,%rax
    788e:	48 39 c8             	cmp    %rcx,%rax
    7891:	73 1b                	jae    78ae <fwp_drop0+0x8e>
    7893:	48 01 c2             	add    %rax,%rdx
    7896:	0f b6 02             	movzbl (%rdx),%eax
    7899:	84 c0                	test   %al,%al
    789b:	74 11                	je     78ae <fwp_drop0+0x8e>
    789d:	3c 01                	cmp    $0x1,%al
    789f:	74 27                	je     78c8 <fwp_drop0+0xa8>
    78a1:	3c ff                	cmp    $0xff,%al
    78a3:	0f 84 e7 00 00 00    	je     7990 <fwp_drop0+0x170>
    78a9:	83 e8 01             	sub    $0x1,%eax
    78ac:	88 02                	mov    %al,(%rdx)
    78ae:	48 83 c4 18          	add    $0x18,%rsp
    78b2:	c3                   	ret
    78b3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    78b8:	66 85 c0             	test   %ax,%ax
    78bb:	74 d9                	je     7896 <fwp_drop0+0x76>
    78bd:	48 83 c4 18          	add    $0x18,%rsp
    78c1:	c3                   	ret
    78c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    78c8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    78cf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    78d6:	48 89 f8             	mov    %rdi,%rax
    78d9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    78dd:	48 29 c8             	sub    %rcx,%rax
    78e0:	48 c1 e2 10          	shl    $0x10,%rdx
    78e4:	48 39 d0             	cmp    %rdx,%rax
    78e7:	73 71                	jae    795a <fwp_drop0+0x13a>
    78e9:	49 89 c2             	mov    %rax,%r10
    78ec:	49 c1 ea 10          	shr    $0x10,%r10
    78f0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    78f4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    78f8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    78fc:	4d 85 d2             	test   %r10,%r10
    78ff:	74 59                	je     795a <fwp_drop0+0x13a>
    7901:	45 0f b6 19          	movzbl (%r9),%r11d
    7905:	41 80 fb 02          	cmp    $0x2,%r11b
    7909:	74 75                	je     7980 <fwp_drop0+0x160>
    790b:	41 80 fb 01          	cmp    $0x1,%r11b
    790f:	75 49                	jne    795a <fwp_drop0+0x13a>
    7911:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7915:	0f b7 c0             	movzwl %ax,%eax
    7918:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    791c:	49 0f af c3          	imul   %r11,%rax
    7920:	48 c1 e8 20          	shr    $0x20,%rax
    7924:	4c 39 c8             	cmp    %r9,%rax
    7927:	73 31                	jae    795a <fwp_drop0+0x13a>
    7929:	49 01 c2             	add    %rax,%r10
    792c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7930:	75 28                	jne    795a <fwp_drop0+0x13a>
    7932:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7937:	e8 54 de ff ff       	call   5790 <fwp_mem_free>
    793c:	48 8d 35 7d 8e 01 00 	lea    0x18e7d(%rip),%rsi        # 207c0 <fwp_heap>
    7943:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7948:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    794f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7956:	48 c1 e2 10          	shl    $0x10,%rdx
    795a:	4c 89 c0             	mov    %r8,%rax
    795d:	48 29 c8             	sub    %rcx,%rax
    7960:	48 39 d0             	cmp    %rdx,%rax
    7963:	0f 83 45 ff ff ff    	jae    78ae <fwp_drop0+0x8e>
    7969:	4c 89 c7             	mov    %r8,%rdi
    796c:	e9 dc fe ff ff       	jmp    784d <fwp_drop0+0x2d>
    7971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7978:	c3                   	ret
    7979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7980:	66 85 c0             	test   %ax,%ax
    7983:	75 d5                	jne    795a <fwp_drop0+0x13a>
    7985:	eb a5                	jmp    792c <fwp_drop0+0x10c>
    7987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    798e:	00 00 
    7990:	48 89 d0             	mov    %rdx,%rax
    7993:	48 c1 e8 11          	shr    $0x11,%rax
    7997:	48 31 d0             	xor    %rdx,%rax
    799a:	48 89 c1             	mov    %rax,%rcx
    799d:	48 c1 e9 09          	shr    $0x9,%rcx
    79a1:	48 31 c8             	xor    %rcx,%rax
    79a4:	0f b6 c8             	movzbl %al,%ecx
    79a7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    79ae:	00 
    79af:	48 85 c0             	test   %rax,%rax
    79b2:	75 15                	jne    79c9 <fwp_drop0+0x1a9>
    79b4:	eb 4e                	jmp    7a04 <fwp_drop0+0x1e4>
    79b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    79bd:	00 00 00 
    79c0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    79c4:	48 85 c0             	test   %rax,%rax
    79c7:	74 3b                	je     7a04 <fwp_drop0+0x1e4>
    79c9:	48 89 c1             	mov    %rax,%rcx
    79cc:	48 39 10             	cmp    %rdx,(%rax)
    79cf:	75 ef                	jne    79c0 <fwp_drop0+0x1a0>
    79d1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    79d5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    79d9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    79dd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    79e4:	0f 85 c4 fe ff ff    	jne    78ae <fwp_drop0+0x8e>
    79ea:	48 89 d7             	mov    %rdx,%rdi
    79ed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79f2:	e8 59 db ff ff       	call   5550 <fwp_rc_forget_slot>
    79f7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79fc:	c6 02 fe             	movb   $0xfe,(%rdx)
    79ff:	e9 aa fe ff ff       	jmp    78ae <fwp_drop0+0x8e>
    7a04:	48 8d 3d 85 4e 00 00 	lea    0x4e85(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7a0b:	e8 e0 c9 ff ff       	call   43f0 <fwp_trap>

0000000000007a10 <fwp_drop1>:
    7a10:	f3 0f 1e fa          	endbr64
    7a14:	48 8b 15 7d a1 01 00 	mov    0x1a17d(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7a1b:	48 89 f8             	mov    %rdi,%rax
    7a1e:	48 2b 05 4b a1 01 00 	sub    0x1a14b(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7a25:	48 c1 e2 10          	shl    $0x10,%rdx
    7a29:	48 39 d0             	cmp    %rdx,%rax
    7a2c:	0f 83 36 01 00 00    	jae    7b68 <fwp_drop1+0x158>
    7a32:	48 83 ec 18          	sub    $0x18,%rsp
    7a36:	48 8d 35 83 8d 01 00 	lea    0x18d83(%rip),%rsi        # 207c0 <fwp_heap>
    7a3d:	48 89 c2             	mov    %rax,%rdx
    7a40:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7a47:	48 c1 ea 10          	shr    $0x10,%rdx
    7a4b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a4f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7a53:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a57:	48 85 d2             	test   %rdx,%rdx
    7a5a:	74 42                	je     7a9e <fwp_drop1+0x8e>
    7a5c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7a60:	41 80 f8 02          	cmp    $0x2,%r8b
    7a64:	74 42                	je     7aa8 <fwp_drop1+0x98>
    7a66:	41 80 f8 01          	cmp    $0x1,%r8b
    7a6a:	75 32                	jne    7a9e <fwp_drop1+0x8e>
    7a6c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7a70:	0f b7 c0             	movzwl %ax,%eax
    7a73:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a76:	49 0f af c0          	imul   %r8,%rax
    7a7a:	48 c1 e8 20          	shr    $0x20,%rax
    7a7e:	48 39 c8             	cmp    %rcx,%rax
    7a81:	73 1b                	jae    7a9e <fwp_drop1+0x8e>
    7a83:	48 01 c2             	add    %rax,%rdx
    7a86:	0f b6 02             	movzbl (%rdx),%eax
    7a89:	84 c0                	test   %al,%al
    7a8b:	74 11                	je     7a9e <fwp_drop1+0x8e>
    7a8d:	3c 01                	cmp    $0x1,%al
    7a8f:	74 27                	je     7ab8 <fwp_drop1+0xa8>
    7a91:	3c ff                	cmp    $0xff,%al
    7a93:	0f 84 e7 00 00 00    	je     7b80 <fwp_drop1+0x170>
    7a99:	83 e8 01             	sub    $0x1,%eax
    7a9c:	88 02                	mov    %al,(%rdx)
    7a9e:	48 83 c4 18          	add    $0x18,%rsp
    7aa2:	c3                   	ret
    7aa3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7aa8:	66 85 c0             	test   %ax,%ax
    7aab:	74 d9                	je     7a86 <fwp_drop1+0x76>
    7aad:	48 83 c4 18          	add    $0x18,%rsp
    7ab1:	c3                   	ret
    7ab2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7ab8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7abf:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7ac6:	48 89 f8             	mov    %rdi,%rax
    7ac9:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    7acd:	48 29 c8             	sub    %rcx,%rax
    7ad0:	48 c1 e2 10          	shl    $0x10,%rdx
    7ad4:	48 39 d0             	cmp    %rdx,%rax
    7ad7:	73 71                	jae    7b4a <fwp_drop1+0x13a>
    7ad9:	49 89 c2             	mov    %rax,%r10
    7adc:	49 c1 ea 10          	shr    $0x10,%r10
    7ae0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7ae4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    7ae8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    7aec:	4d 85 d2             	test   %r10,%r10
    7aef:	74 59                	je     7b4a <fwp_drop1+0x13a>
    7af1:	45 0f b6 19          	movzbl (%r9),%r11d
    7af5:	41 80 fb 02          	cmp    $0x2,%r11b
    7af9:	74 75                	je     7b70 <fwp_drop1+0x160>
    7afb:	41 80 fb 01          	cmp    $0x1,%r11b
    7aff:	75 49                	jne    7b4a <fwp_drop1+0x13a>
    7b01:	45 8b 59 18          	mov    0x18(%r9),%r11d
    7b05:	0f b7 c0             	movzwl %ax,%eax
    7b08:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    7b0c:	49 0f af c3          	imul   %r11,%rax
    7b10:	48 c1 e8 20          	shr    $0x20,%rax
    7b14:	4c 39 c8             	cmp    %r9,%rax
    7b17:	73 31                	jae    7b4a <fwp_drop1+0x13a>
    7b19:	49 01 c2             	add    %rax,%r10
    7b1c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b20:	75 28                	jne    7b4a <fwp_drop1+0x13a>
    7b22:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    7b27:	e8 64 dc ff ff       	call   5790 <fwp_mem_free>
    7b2c:	48 8d 35 8d 8c 01 00 	lea    0x18c8d(%rip),%rsi        # 207c0 <fwp_heap>
    7b33:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7b38:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7b3f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7b46:	48 c1 e2 10          	shl    $0x10,%rdx
    7b4a:	4c 89 c0             	mov    %r8,%rax
    7b4d:	48 29 c8             	sub    %rcx,%rax
    7b50:	48 39 d0             	cmp    %rdx,%rax
    7b53:	0f 83 45 ff ff ff    	jae    7a9e <fwp_drop1+0x8e>
    7b59:	4c 89 c7             	mov    %r8,%rdi
    7b5c:	e9 dc fe ff ff       	jmp    7a3d <fwp_drop1+0x2d>
    7b61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b68:	c3                   	ret
    7b69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7b70:	66 85 c0             	test   %ax,%ax
    7b73:	75 d5                	jne    7b4a <fwp_drop1+0x13a>
    7b75:	eb a5                	jmp    7b1c <fwp_drop1+0x10c>
    7b77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7b7e:	00 00 
    7b80:	48 89 d0             	mov    %rdx,%rax
    7b83:	48 c1 e8 11          	shr    $0x11,%rax
    7b87:	48 31 d0             	xor    %rdx,%rax
    7b8a:	48 89 c1             	mov    %rax,%rcx
    7b8d:	48 c1 e9 09          	shr    $0x9,%rcx
    7b91:	48 31 c8             	xor    %rcx,%rax
    7b94:	0f b6 c8             	movzbl %al,%ecx
    7b97:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7b9e:	00 
    7b9f:	48 85 c0             	test   %rax,%rax
    7ba2:	75 25                	jne    7bc9 <fwp_drop1+0x1b9>
    7ba4:	eb 5e                	jmp    7c04 <fwp_drop1+0x1f4>
    7ba6:	0f 1f 40 00          	nopl   0x0(%rax)
    7baa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bb1:	00 00 00 00 
    7bb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bbc:	00 00 00 00 
    7bc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7bc4:	48 85 c0             	test   %rax,%rax
    7bc7:	74 3b                	je     7c04 <fwp_drop1+0x1f4>
    7bc9:	48 89 c1             	mov    %rax,%rcx
    7bcc:	48 39 10             	cmp    %rdx,(%rax)
    7bcf:	75 ef                	jne    7bc0 <fwp_drop1+0x1b0>
    7bd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bdd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7be4:	0f 85 b4 fe ff ff    	jne    7a9e <fwp_drop1+0x8e>
    7bea:	48 89 d7             	mov    %rdx,%rdi
    7bed:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7bf2:	e8 59 d9 ff ff       	call   5550 <fwp_rc_forget_slot>
    7bf7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7bfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    7bff:	e9 9a fe ff ff       	jmp    7a9e <fwp_drop1+0x8e>
    7c04:	48 8d 3d 85 4c 00 00 	lea    0x4c85(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7c0b:	e8 e0 c7 ff ff       	call   43f0 <fwp_trap>

0000000000007c10 <fwp_drop10>:
    7c10:	48 8b 0d 81 9f 01 00 	mov    0x19f81(%rip),%rcx        # 21b98 <fwp_heap+0x13d8>
    7c17:	48 89 f8             	mov    %rdi,%rax
    7c1a:	48 2b 05 4f 9f 01 00 	sub    0x19f4f(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7c21:	48 c1 e1 10          	shl    $0x10,%rcx
    7c25:	48 39 c8             	cmp    %rcx,%rax
    7c28:	0f 83 c2 01 00 00    	jae    7df0 <fwp_drop10+0x1e0>
    7c2e:	48 83 ec 18          	sub    $0x18,%rsp
    7c32:	48 89 fa             	mov    %rdi,%rdx
    7c35:	48 8d 35 84 8b 01 00 	lea    0x18b84(%rip),%rsi        # 207c0 <fwp_heap>
    7c3c:	48 89 c1             	mov    %rax,%rcx
    7c3f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7c46:	48 c1 e9 10          	shr    $0x10,%rcx
    7c4a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7c4e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7c52:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7c56:	48 85 c9             	test   %rcx,%rcx
    7c59:	74 46                	je     7ca1 <fwp_drop10+0x91>
    7c5b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7c5f:	41 80 f9 02          	cmp    $0x2,%r9b
    7c63:	0f 84 d7 00 00 00    	je     7d40 <fwp_drop10+0x130>
    7c69:	41 80 f9 01          	cmp    $0x1,%r9b
    7c6d:	75 32                	jne    7ca1 <fwp_drop10+0x91>
    7c6f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7c73:	0f b7 c0             	movzwl %ax,%eax
    7c76:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7c79:	49 0f af c1          	imul   %r9,%rax
    7c7d:	48 c1 e8 20          	shr    $0x20,%rax
    7c81:	48 39 f8             	cmp    %rdi,%rax
    7c84:	73 1b                	jae    7ca1 <fwp_drop10+0x91>
    7c86:	48 01 c1             	add    %rax,%rcx
    7c89:	0f b6 01             	movzbl (%rcx),%eax
    7c8c:	84 c0                	test   %al,%al
    7c8e:	74 11                	je     7ca1 <fwp_drop10+0x91>
    7c90:	3c 01                	cmp    $0x1,%al
    7c92:	74 1c                	je     7cb0 <fwp_drop10+0xa0>
    7c94:	3c ff                	cmp    $0xff,%al
    7c96:	0f 84 5c 01 00 00    	je     7df8 <fwp_drop10+0x1e8>
    7c9c:	83 e8 01             	sub    $0x1,%eax
    7c9f:	88 01                	mov    %al,(%rcx)
    7ca1:	48 83 c4 18          	add    $0x18,%rsp
    7ca5:	c3                   	ret
    7ca6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cad:	00 00 00 
    7cb0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7cb7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7cbe:	48 89 d0             	mov    %rdx,%rax
    7cc1:	49 89 d1             	mov    %rdx,%r9
    7cc4:	48 c1 e1 10          	shl    $0x10,%rcx
    7cc8:	48 29 f8             	sub    %rdi,%rax
    7ccb:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7ccf:	78 7f                	js     7d50 <fwp_drop10+0x140>
    7cd1:	48 39 c8             	cmp    %rcx,%rax
    7cd4:	73 cb                	jae    7ca1 <fwp_drop10+0x91>
    7cd6:	48 89 c1             	mov    %rax,%rcx
    7cd9:	48 c1 e9 10          	shr    $0x10,%rcx
    7cdd:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7ce1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7ce5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7ce9:	48 85 f6             	test   %rsi,%rsi
    7cec:	74 b3                	je     7ca1 <fwp_drop10+0x91>
    7cee:	0f b6 39             	movzbl (%rcx),%edi
    7cf1:	40 80 ff 02          	cmp    $0x2,%dil
    7cf5:	74 39                	je     7d30 <fwp_drop10+0x120>
    7cf7:	40 80 ff 01          	cmp    $0x1,%dil
    7cfb:	75 a4                	jne    7ca1 <fwp_drop10+0x91>
    7cfd:	8b 79 18             	mov    0x18(%rcx),%edi
    7d00:	0f b7 c0             	movzwl %ax,%eax
    7d03:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7d06:	48 0f af c7          	imul   %rdi,%rax
    7d0a:	48 c1 e8 20          	shr    $0x20,%rax
    7d0e:	48 39 c8             	cmp    %rcx,%rax
    7d11:	73 8e                	jae    7ca1 <fwp_drop10+0x91>
    7d13:	48 01 c6             	add    %rax,%rsi
    7d16:	80 3e 01             	cmpb   $0x1,(%rsi)
    7d19:	75 86                	jne    7ca1 <fwp_drop10+0x91>
    7d1b:	48 89 d7             	mov    %rdx,%rdi
    7d1e:	48 83 c4 18          	add    $0x18,%rsp
    7d22:	e9 69 da ff ff       	jmp    5790 <fwp_mem_free>
    7d27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7d2e:	00 00 
    7d30:	66 85 c0             	test   %ax,%ax
    7d33:	74 e1                	je     7d16 <fwp_drop10+0x106>
    7d35:	48 83 c4 18          	add    $0x18,%rsp
    7d39:	c3                   	ret
    7d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d40:	66 85 c0             	test   %ax,%ax
    7d43:	0f 84 40 ff ff ff    	je     7c89 <fwp_drop10+0x79>
    7d49:	48 83 c4 18          	add    $0x18,%rsp
    7d4d:	c3                   	ret
    7d4e:	66 90                	xchg   %ax,%ax
    7d50:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7d54:	48 39 c8             	cmp    %rcx,%rax
    7d57:	73 74                	jae    7dcd <fwp_drop10+0x1bd>
    7d59:	49 89 c2             	mov    %rax,%r10
    7d5c:	49 c1 ea 10          	shr    $0x10,%r10
    7d60:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7d64:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7d68:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7d6c:	4d 85 d2             	test   %r10,%r10
    7d6f:	74 5c                	je     7dcd <fwp_drop10+0x1bd>
    7d71:	45 0f b6 18          	movzbl (%r8),%r11d
    7d75:	41 80 fb 02          	cmp    $0x2,%r11b
    7d79:	74 6d                	je     7de8 <fwp_drop10+0x1d8>
    7d7b:	41 80 fb 01          	cmp    $0x1,%r11b
    7d7f:	75 4c                	jne    7dcd <fwp_drop10+0x1bd>
    7d81:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7d85:	0f b7 c0             	movzwl %ax,%eax
    7d88:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7d8c:	49 0f af c3          	imul   %r11,%rax
    7d90:	48 c1 e8 20          	shr    $0x20,%rax
    7d94:	4c 39 c0             	cmp    %r8,%rax
    7d97:	73 34                	jae    7dcd <fwp_drop10+0x1bd>
    7d99:	49 01 c2             	add    %rax,%r10
    7d9c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7da0:	75 2b                	jne    7dcd <fwp_drop10+0x1bd>
    7da2:	4c 89 cf             	mov    %r9,%rdi
    7da5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7daa:	e8 e1 d9 ff ff       	call   5790 <fwp_mem_free>
    7daf:	48 8d 35 0a 8a 01 00 	lea    0x18a0a(%rip),%rsi        # 207c0 <fwp_heap>
    7db6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7dbb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7dc2:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7dc9:	48 c1 e1 10          	shl    $0x10,%rcx
    7dcd:	48 89 d0             	mov    %rdx,%rax
    7dd0:	48 29 f8             	sub    %rdi,%rax
    7dd3:	48 39 c8             	cmp    %rcx,%rax
    7dd6:	0f 82 60 fe ff ff    	jb     7c3c <fwp_drop10+0x2c>
    7ddc:	e9 c0 fe ff ff       	jmp    7ca1 <fwp_drop10+0x91>
    7de1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7de8:	66 85 c0             	test   %ax,%ax
    7deb:	75 e0                	jne    7dcd <fwp_drop10+0x1bd>
    7ded:	eb ad                	jmp    7d9c <fwp_drop10+0x18c>
    7def:	90                   	nop
    7df0:	c3                   	ret
    7df1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7df8:	48 89 c8             	mov    %rcx,%rax
    7dfb:	48 c1 e8 11          	shr    $0x11,%rax
    7dff:	48 31 c8             	xor    %rcx,%rax
    7e02:	48 89 c2             	mov    %rax,%rdx
    7e05:	48 c1 ea 09          	shr    $0x9,%rdx
    7e09:	48 31 d0             	xor    %rdx,%rax
    7e0c:	0f b6 d0             	movzbl %al,%edx
    7e0f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7e16:	00 
    7e17:	48 85 c0             	test   %rax,%rax
    7e1a:	75 0d                	jne    7e29 <fwp_drop10+0x219>
    7e1c:	eb 46                	jmp    7e64 <fwp_drop10+0x254>
    7e1e:	66 90                	xchg   %ax,%ax
    7e20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7e24:	48 85 c0             	test   %rax,%rax
    7e27:	74 3b                	je     7e64 <fwp_drop10+0x254>
    7e29:	48 89 c2             	mov    %rax,%rdx
    7e2c:	48 39 08             	cmp    %rcx,(%rax)
    7e2f:	75 ef                	jne    7e20 <fwp_drop10+0x210>
    7e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e35:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7e39:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7e3d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7e44:	0f 85 57 fe ff ff    	jne    7ca1 <fwp_drop10+0x91>
    7e4a:	48 89 cf             	mov    %rcx,%rdi
    7e4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7e52:	e8 f9 d6 ff ff       	call   5550 <fwp_rc_forget_slot>
    7e57:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7e5c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7e5f:	e9 3d fe ff ff       	jmp    7ca1 <fwp_drop10+0x91>
    7e64:	48 8d 3d 25 4a 00 00 	lea    0x4a25(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    7e6b:	e8 80 c5 ff ff       	call   43f0 <fwp_trap>

0000000000007e70 <f37>:
    7e70:	41 57                	push   %r15
    7e72:	41 56                	push   %r14
    7e74:	41 55                	push   %r13
    7e76:	41 54                	push   %r12
    7e78:	55                   	push   %rbp
    7e79:	53                   	push   %rbx
    7e7a:	48 83 ec 38          	sub    $0x38,%rsp
    7e7e:	48 8b 15 13 9d 01 00 	mov    0x19d13(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7e85:	48 8b 0d e4 9c 01 00 	mov    0x19ce4(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    7e8c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7e93:	00 00 
    7e95:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7e9a:	49 89 fc             	mov    %rdi,%r12
    7e9d:	48 c1 e2 10          	shl    $0x10,%rdx
    7ea1:	48 85 ff             	test   %rdi,%rdi
    7ea4:	0f 84 bc 02 00 00    	je     8166 <f37+0x2f6>
    7eaa:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7eaf:	48 89 d8             	mov    %rbx,%rax
    7eb2:	48 29 c8             	sub    %rcx,%rax
    7eb5:	48 39 d0             	cmp    %rdx,%rax
    7eb8:	0f 83 72 03 00 00    	jae    8230 <f37+0x3c0>
    7ebe:	48 89 c2             	mov    %rax,%rdx
    7ec1:	48 c1 ea 10          	shr    $0x10,%rdx
    7ec5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ec9:	48 8b 15 e8 9c 01 00 	mov    0x19ce8(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7ed0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ed4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7ed8:	48 85 ff             	test   %rdi,%rdi
    7edb:	0f 84 4f 03 00 00    	je     8230 <f37+0x3c0>
    7ee1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ee4:	80 f9 02             	cmp    $0x2,%cl
    7ee7:	0f 84 53 02 00 00    	je     8140 <f37+0x2d0>
    7eed:	80 f9 01             	cmp    $0x1,%cl
    7ef0:	75 24                	jne    7f16 <f37+0xa6>
    7ef2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ef5:	0f b7 c0             	movzwl %ax,%eax
    7ef8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7efb:	48 0f af c1          	imul   %rcx,%rax
    7eff:	48 c1 e8 20          	shr    $0x20,%rax
    7f03:	48 39 d0             	cmp    %rdx,%rax
    7f06:	73 0e                	jae    7f16 <f37+0xa6>
    7f08:	48 01 c7             	add    %rax,%rdi
    7f0b:	0f b6 07             	movzbl (%rdi),%eax
    7f0e:	84 c0                	test   %al,%al
    7f10:	0f 85 ca 02 00 00    	jne    81e0 <f37+0x370>
    7f16:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7f1b:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7f20:	ba 01 00 00 00       	mov    $0x1,%edx
    7f25:	48 85 db             	test   %rbx,%rbx
    7f28:	74 13                	je     7f3d <f37+0xcd>
    7f2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7f30:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7f34:	48 83 c2 01          	add    $0x1,%rdx
    7f38:	48 85 db             	test   %rbx,%rbx
    7f3b:	75 f3                	jne    7f30 <f37+0xc0>
    7f3d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7f42:	48 85 c0             	test   %rax,%rax
    7f45:	0f 84 15 03 00 00    	je     8260 <f37+0x3f0>
    7f4b:	31 db                	xor    %ebx,%ebx
    7f4d:	0f 1f 00             	nopl   (%rax)
    7f50:	48 8b 40 10          	mov    0x10(%rax),%rax
    7f54:	48 83 c3 01          	add    $0x1,%rbx
    7f58:	48 85 c0             	test   %rax,%rax
    7f5b:	75 f3                	jne    7f50 <f37+0xe0>
    7f5d:	48 39 d3             	cmp    %rdx,%rbx
    7f60:	48 0f 47 da          	cmova  %rdx,%rbx
    7f64:	48 89 d8             	mov    %rbx,%rax
    7f67:	48 c1 e8 3c          	shr    $0x3c,%rax
    7f6b:	0f 85 8f 03 00 00    	jne    8300 <f37+0x490>
    7f71:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7f75:	be 02 00 00 00       	mov    $0x2,%esi
    7f7a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7f81:	00 
    7f82:	e8 09 dd ff ff       	call   5c90 <fwp_heap_alloc>
    7f87:	48 89 28             	mov    %rbp,(%rax)
    7f8a:	48 8b 15 07 9c 01 00 	mov    0x19c07(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    7f91:	49 89 c6             	mov    %rax,%r14
    7f94:	48 2b 05 d5 9b 01 00 	sub    0x19bd5(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    7f9b:	48 c1 e2 10          	shl    $0x10,%rdx
    7f9f:	48 39 d0             	cmp    %rdx,%rax
    7fa2:	73 57                	jae    7ffb <f37+0x18b>
    7fa4:	48 89 c2             	mov    %rax,%rdx
    7fa7:	48 c1 ea 10          	shr    $0x10,%rdx
    7fab:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7faf:	48 8b 15 02 9c 01 00 	mov    0x19c02(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    7fb6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fba:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7fbe:	48 85 ed             	test   %rbp,%rbp
    7fc1:	74 38                	je     7ffb <f37+0x18b>
    7fc3:	0f b6 0a             	movzbl (%rdx),%ecx
    7fc6:	80 f9 02             	cmp    $0x2,%cl
    7fc9:	0f 84 51 02 00 00    	je     8220 <f37+0x3b0>
    7fcf:	80 f9 01             	cmp    $0x1,%cl
    7fd2:	75 27                	jne    7ffb <f37+0x18b>
    7fd4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fd7:	0f b7 c0             	movzwl %ax,%eax
    7fda:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fdd:	48 0f af c1          	imul   %rcx,%rax
    7fe1:	48 c1 e8 20          	shr    $0x20,%rax
    7fe5:	48 39 d0             	cmp    %rdx,%rax
    7fe8:	73 11                	jae    7ffb <f37+0x18b>
    7fea:	48 01 c5             	add    %rax,%rbp
    7fed:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7ff1:	0f 84 d5 02 00 00    	je     82cc <f37+0x45c>
    7ff7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7ffb:	48 85 db             	test   %rbx,%rbx
    7ffe:	74 5d                	je     805d <f37+0x1ed>
    8000:	48 c1 e3 04          	shl    $0x4,%rbx
    8004:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    8009:	4c 89 f5             	mov    %r14,%rbp
    800c:	4d 89 e5             	mov    %r12,%r13
    800f:	4c 01 f3             	add    %r14,%rbx
    8012:	0f 1f 00             	nopl   (%rax)
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	49 8b 45 08          	mov    0x8(%r13),%rax
    8024:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8028:	48 83 c5 10          	add    $0x10,%rbp
    802c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8031:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8035:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8039:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    803e:	e8 9d e3 ff ff       	call   63e0 <w120>
    8043:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8048:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    804c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8050:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8054:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    8058:	48 39 dd             	cmp    %rbx,%rbp
    805b:	75 c3                	jne    8020 <f37+0x1b0>
    805d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8062:	e8 c9 ed ff ff       	call   6e30 <fwp_drop4>
    8067:	4c 89 e7             	mov    %r12,%rdi
    806a:	e8 c1 ed ff ff       	call   6e30 <fwp_drop4>
    806f:	4c 89 f7             	mov    %r14,%rdi
    8072:	e8 29 e5 ff ff       	call   65a0 <w176.constprop.0>
    8077:	4c 89 f7             	mov    %r14,%rdi
    807a:	48 89 c3             	mov    %rax,%rbx
    807d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8083:	e8 88 fb ff ff       	call   7c10 <fwp_drop10>
    8088:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    808e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    8093:	31 ff                	xor    %edi,%edi
    8095:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    809a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    809e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    80a3:	e8 08 dd ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    80a8:	48 8b 15 e9 9a 01 00 	mov    0x19ae9(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    80af:	48 89 c5             	mov    %rax,%rbp
    80b2:	48 2b 05 b7 9a 01 00 	sub    0x19ab7(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    80b9:	48 c1 e2 10          	shl    $0x10,%rdx
    80bd:	48 39 d0             	cmp    %rdx,%rax
    80c0:	73 55                	jae    8117 <f37+0x2a7>
    80c2:	48 89 c2             	mov    %rax,%rdx
    80c5:	48 c1 ea 10          	shr    $0x10,%rdx
    80c9:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    80cd:	48 8b 15 e4 9a 01 00 	mov    0x19ae4(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    80d4:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    80d8:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    80dc:	48 85 db             	test   %rbx,%rbx
    80df:	74 36                	je     8117 <f37+0x2a7>
    80e1:	0f b6 0a             	movzbl (%rdx),%ecx
    80e4:	80 f9 02             	cmp    $0x2,%cl
    80e7:	0f 84 1b 01 00 00    	je     8208 <f37+0x398>
    80ed:	80 f9 01             	cmp    $0x1,%cl
    80f0:	75 25                	jne    8117 <f37+0x2a7>
    80f2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    80f5:	0f b7 c0             	movzwl %ax,%eax
    80f8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    80fb:	48 0f af c1          	imul   %rcx,%rax
    80ff:	48 c1 e8 20          	shr    $0x20,%rax
    8103:	48 39 d0             	cmp    %rdx,%rax
    8106:	73 0f                	jae    8117 <f37+0x2a7>
    8108:	48 01 c3             	add    %rax,%rbx
    810b:	80 3b ff             	cmpb   $0xff,(%rbx)
    810e:	0f 84 ab 01 00 00    	je     82bf <f37+0x44f>
    8114:	c6 03 01             	movb   $0x1,(%rbx)
    8117:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    811c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8123:	00 00 
    8125:	0f 85 d0 01 00 00    	jne    82fb <f37+0x48b>
    812b:	48 83 c4 38          	add    $0x38,%rsp
    812f:	48 89 e8             	mov    %rbp,%rax
    8132:	5b                   	pop    %rbx
    8133:	5d                   	pop    %rbp
    8134:	41 5c                	pop    %r12
    8136:	41 5d                	pop    %r13
    8138:	41 5e                	pop    %r14
    813a:	41 5f                	pop    %r15
    813c:	c3                   	ret
    813d:	0f 1f 00             	nopl   (%rax)
    8140:	66 85 c0             	test   %ax,%ax
    8143:	0f 85 cd fd ff ff    	jne    7f16 <f37+0xa6>
    8149:	0f b6 07             	movzbl (%rdi),%eax
    814c:	84 c0                	test   %al,%al
    814e:	0f 84 c2 fd ff ff    	je     7f16 <f37+0xa6>
    8154:	3c fd                	cmp    $0xfd,%al
    8156:	0f 87 95 01 00 00    	ja     82f1 <f37+0x481>
    815c:	83 c0 01             	add    $0x1,%eax
    815f:	88 07                	mov    %al,(%rdi)
    8161:	e9 b0 fd ff ff       	jmp    7f16 <f37+0xa6>
    8166:	48 f7 d9             	neg    %rcx
    8169:	48 39 d1             	cmp    %rdx,%rcx
    816c:	0f 83 ee 00 00 00    	jae    8260 <f37+0x3f0>
    8172:	48 89 c8             	mov    %rcx,%rax
    8175:	48 c1 e8 10          	shr    $0x10,%rax
    8179:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    817d:	48 8b 05 34 9a 01 00 	mov    0x19a34(%rip),%rax        # 21bb8 <fwp_heap+0x13f8>
    8184:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8188:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    818c:	48 85 ff             	test   %rdi,%rdi
    818f:	0f 84 cb 00 00 00    	je     8260 <f37+0x3f0>
    8195:	0f b6 02             	movzbl (%rdx),%eax
    8198:	3c 02                	cmp    $0x2,%al
    819a:	0f 84 9a 00 00 00    	je     823a <f37+0x3ca>
    81a0:	3c 01                	cmp    $0x1,%al
    81a2:	0f 85 b8 00 00 00    	jne    8260 <f37+0x3f0>
    81a8:	0f b7 c1             	movzwl %cx,%eax
    81ab:	8b 4a 18             	mov    0x18(%rdx),%ecx
    81ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    81b1:	48 0f af c1          	imul   %rcx,%rax
    81b5:	48 c1 e8 20          	shr    $0x20,%rax
    81b9:	48 39 d0             	cmp    %rdx,%rax
    81bc:	0f 83 9e 00 00 00    	jae    8260 <f37+0x3f0>
    81c2:	48 01 c7             	add    %rax,%rdi
    81c5:	0f b6 07             	movzbl (%rdi),%eax
    81c8:	84 c0                	test   %al,%al
    81ca:	0f 84 90 00 00 00    	je     8260 <f37+0x3f0>
    81d0:	31 db                	xor    %ebx,%ebx
    81d2:	0f 1f 00             	nopl   (%rax)
    81d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    81dc:	00 00 00 00 
    81e0:	3c fd                	cmp    $0xfd,%al
    81e2:	0f 87 f1 00 00 00    	ja     82d9 <f37+0x469>
    81e8:	83 c0 01             	add    $0x1,%eax
    81eb:	88 07                	mov    %al,(%rdi)
    81ed:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    81f2:	31 d2                	xor    %edx,%edx
    81f4:	4d 85 e4             	test   %r12,%r12
    81f7:	0f 85 1e fd ff ff    	jne    7f1b <f37+0xab>
    81fd:	e9 3b fd ff ff       	jmp    7f3d <f37+0xcd>
    8202:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8208:	66 85 c0             	test   %ax,%ax
    820b:	0f 85 06 ff ff ff    	jne    8117 <f37+0x2a7>
    8211:	e9 f5 fe ff ff       	jmp    810b <f37+0x29b>
    8216:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    821d:	00 00 00 
    8220:	66 85 c0             	test   %ax,%ax
    8223:	0f 85 d2 fd ff ff    	jne    7ffb <f37+0x18b>
    8229:	e9 bf fd ff ff       	jmp    7fed <f37+0x17d>
    822e:	66 90                	xchg   %ax,%ax
    8230:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    8235:	e9 e6 fc ff ff       	jmp    7f20 <f37+0xb0>
    823a:	66 85 c9             	test   %cx,%cx
    823d:	75 21                	jne    8260 <f37+0x3f0>
    823f:	0f b6 07             	movzbl (%rdi),%eax
    8242:	84 c0                	test   %al,%al
    8244:	74 1a                	je     8260 <f37+0x3f0>
    8246:	3c fd                	cmp    $0xfd,%al
    8248:	0f 87 be 00 00 00    	ja     830c <f37+0x49c>
    824e:	83 c0 01             	add    $0x1,%eax
    8251:	88 07                	mov    %al,(%rdi)
    8253:	66 90                	xchg   %ax,%ax
    8255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    825c:	00 00 00 00 
    8260:	be 02 00 00 00       	mov    $0x2,%esi
    8265:	bf 08 00 00 00       	mov    $0x8,%edi
    826a:	e8 21 da ff ff       	call   5c90 <fwp_heap_alloc>
    826f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8276:	48 8b 15 1b 99 01 00 	mov    0x1991b(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    827d:	49 89 c6             	mov    %rax,%r14
    8280:	48 2b 05 e9 98 01 00 	sub    0x198e9(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    8287:	48 c1 e2 10          	shl    $0x10,%rdx
    828b:	48 39 d0             	cmp    %rdx,%rax
    828e:	73 53                	jae    82e3 <f37+0x473>
    8290:	48 89 c2             	mov    %rax,%rdx
    8293:	48 c1 ea 10          	shr    $0x10,%rdx
    8297:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    829b:	48 8b 15 16 99 01 00 	mov    0x19916(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    82a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    82a6:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    82aa:	48 85 ed             	test   %rbp,%rbp
    82ad:	74 34                	je     82e3 <f37+0x473>
    82af:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    82b6:	00 00 
    82b8:	31 db                	xor    %ebx,%ebx
    82ba:	e9 04 fd ff ff       	jmp    7fc3 <f37+0x153>
    82bf:	48 89 df             	mov    %rbx,%rdi
    82c2:	e8 89 d2 ff ff       	call   5550 <fwp_rc_forget_slot>
    82c7:	e9 48 fe ff ff       	jmp    8114 <f37+0x2a4>
    82cc:	48 89 ef             	mov    %rbp,%rdi
    82cf:	e8 7c d2 ff ff       	call   5550 <fwp_rc_forget_slot>
    82d4:	e9 1e fd ff ff       	jmp    7ff7 <f37+0x187>
    82d9:	e8 52 d1 ff ff       	call   5430 <fwp_rc_wide_dup>
    82de:	e9 0a ff ff ff       	jmp    81ed <f37+0x37d>
    82e3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    82ea:	00 00 
    82ec:	e9 6c fd ff ff       	jmp    805d <f37+0x1ed>
    82f1:	e8 3a d1 ff ff       	call   5430 <fwp_rc_wide_dup>
    82f6:	e9 1b fc ff ff       	jmp    7f16 <f37+0xa6>
    82fb:	e8 60 b1 ff ff       	call   3460 <__stack_chk_fail@plt>
    8300:	48 8d 3d 89 3e 00 00 	lea    0x3e89(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    8307:	e8 e4 c0 ff ff       	call   43f0 <fwp_trap>
    830c:	e8 1f d1 ff ff       	call   5430 <fwp_rc_wide_dup>
    8311:	e9 4a ff ff ff       	jmp    8260 <f37+0x3f0>
    8316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    831d:	00 00 00 

0000000000008320 <fwp_owned_entry37>:
    8320:	f3 0f 1e fa          	endbr64
    8324:	48 8b 3f             	mov    (%rdi),%rdi
    8327:	e9 44 fb ff ff       	jmp    7e70 <f37>
    832c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008330 <e37>:
    8330:	f3 0f 1e fa          	endbr64
    8334:	53                   	push   %rbx
    8335:	48 8b 1f             	mov    (%rdi),%rbx
    8338:	48 89 df             	mov    %rbx,%rdi
    833b:	e8 e0 e2 ff ff       	call   6620 <fwp_rc_share>
    8340:	48 89 df             	mov    %rbx,%rdi
    8343:	e8 28 fb ff ff       	call   7e70 <f37>
    8348:	48 89 c3             	mov    %rax,%rbx
    834b:	48 89 c7             	mov    %rax,%rdi
    834e:	e8 cd e2 ff ff       	call   6620 <fwp_rc_share>
    8353:	48 89 d8             	mov    %rbx,%rax
    8356:	5b                   	pop    %rbx
    8357:	c3                   	ret
    8358:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    835f:	00 

0000000000008360 <fwp_write>:
    8360:	41 57                	push   %r15
    8362:	41 56                	push   %r14
    8364:	41 55                	push   %r13
    8366:	41 54                	push   %r12
    8368:	55                   	push   %rbp
    8369:	53                   	push   %rbx
    836a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8371:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8378:	00 00 
    837a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8381:	00 
    8382:	49 89 d4             	mov    %rdx,%r12
    8385:	8b 12                	mov    (%rdx),%edx
    8387:	83 fa 19             	cmp    $0x19,%edx
    838a:	77 6a                	ja     83f6 <fwp_write+0x96>
    838c:	48 89 f5             	mov    %rsi,%rbp
    838f:	89 d0                	mov    %edx,%eax
    8391:	89 ce                	mov    %ecx,%esi
    8393:	48 89 fb             	mov    %rdi,%rbx
    8396:	48 8d 0d 63 47 00 00 	lea    0x4763(%rip),%rcx        # cb00 <_IO_stdin_used+0xb00>
    839d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    83a1:	48 01 c8             	add    %rcx,%rax
    83a4:	3e ff e0             	notrack jmp *%rax
    83a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83ae:	00 00 
    83b0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    83b4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    83b8:	48 89 ca             	mov    %rcx,%rdx
    83bb:	48 85 c9             	test   %rcx,%rcx
    83be:	0f 88 9c 0c 00 00    	js     9060 <fwp_write+0xd00>
    83c4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    83cb:	00 
    83cc:	48 89 c6             	mov    %rax,%rsi
    83cf:	4c 89 e7             	mov    %r12,%rdi
    83d2:	e8 69 b6 ff ff       	call   3a40 <fwp_fmt_u128>
    83d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    83de:	00 00 
    83e0:	4c 89 e7             	mov    %r12,%rdi
    83e3:	e8 68 b0 ff ff       	call   3450 <strlen@plt>
    83e8:	4c 89 e6             	mov    %r12,%rsi
    83eb:	48 89 df             	mov    %rbx,%rdi
    83ee:	48 89 c2             	mov    %rax,%rdx
    83f1:	e8 1a be ff ff       	call   4210 <buf_put>
    83f6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    83fd:	00 
    83fe:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8405:	00 00 
    8407:	0f 85 28 04 00 00    	jne    8835 <fwp_write+0x4d5>
    840d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8414:	5b                   	pop    %rbx
    8415:	5d                   	pop    %rbp
    8416:	41 5c                	pop    %r12
    8418:	41 5d                	pop    %r13
    841a:	41 5e                	pop    %r14
    841c:	41 5f                	pop    %r15
    841e:	c3                   	ret
    841f:	90                   	nop
    8420:	49 89 e9             	mov    %rbp,%r9
    8423:	4c 8d 05 4b 3c 00 00 	lea    0x3c4b(%rip),%r8        # c075 <_IO_stdin_used+0x75>
    842a:	b9 00 02 00 00       	mov    $0x200,%ecx
    842f:	ba 02 00 00 00       	mov    $0x2,%edx
    8434:	be 00 02 00 00       	mov    $0x200,%esi
    8439:	31 c0                	xor    %eax,%eax
    843b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8442:	00 
    8443:	e8 68 af ff ff       	call   33b0 <__snprintf_chk@plt>
    8448:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    844f:	00 
    8450:	e8 fb af ff ff       	call   3450 <strlen@plt>
    8455:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    845c:	00 
    845d:	48 89 df             	mov    %rbx,%rdi
    8460:	48 89 c2             	mov    %rax,%rdx
    8463:	e8 a8 bd ff ff       	call   4210 <buf_put>
    8468:	eb 8c                	jmp    83f6 <fwp_write+0x96>
    846a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8470:	49 89 e9             	mov    %rbp,%r9
    8473:	4c 8d 05 3b 3d 00 00 	lea    0x3d3b(%rip),%r8        # c1b5 <_IO_stdin_used+0x1b5>
    847a:	eb ae                	jmp    842a <fwp_write+0xca>
    847c:	0f 1f 40 00          	nopl   0x0(%rax)
    8480:	83 fa 13             	cmp    $0x13,%edx
    8483:	48 8d 05 21 3d 00 00 	lea    0x3d21(%rip),%rax        # c1ab <_IO_stdin_used+0x1ab>
    848a:	48 8d 35 1f 3d 00 00 	lea    0x3d1f(%rip),%rsi        # c1b0 <_IO_stdin_used+0x1b0>
    8491:	ba 04 00 00 00       	mov    $0x4,%edx
    8496:	48 0f 44 f0          	cmove  %rax,%rsi
    849a:	45 31 ed             	xor    %r13d,%r13d
    849d:	e8 6e bd ff ff       	call   4210 <buf_put>
    84a2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    84a7:	0f 84 a3 08 00 00    	je     8d50 <fwp_write+0x9f0>
    84ad:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    84b2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    84b7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    84bc:	48 89 df             	mov    %rbx,%rdi
    84bf:	49 0f 44 c5          	cmove  %r13,%rax
    84c3:	31 c9                	xor    %ecx,%ecx
    84c5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    84ca:	e8 91 fe ff ff       	call   8360 <fwp_write>
    84cf:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    84d4:	0f 84 6e 09 00 00    	je     8e48 <fwp_write+0xae8>
    84da:	49 83 c5 01          	add    $0x1,%r13
    84de:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    84e2:	0f 83 68 08 00 00    	jae    8d50 <fwp_write+0x9f0>
    84e8:	ba 02 00 00 00       	mov    $0x2,%edx
    84ed:	48 8d 35 01 3d 00 00 	lea    0x3d01(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    84f4:	48 89 df             	mov    %rbx,%rdi
    84f7:	e8 14 bd ff ff       	call   4210 <buf_put>
    84fc:	eb af                	jmp    84ad <fwp_write+0x14d>
    84fe:	66 90                	xchg   %ax,%ax
    8500:	ba 06 00 00 00       	mov    $0x6,%edx
    8505:	48 8d 35 c2 3c 00 00 	lea    0x3cc2(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    850c:	48 83 c5 10          	add    $0x10,%rbp
    8510:	e8 fb bc ff ff       	call   4210 <buf_put>
    8515:	48 89 ef             	mov    %rbp,%rdi
    8518:	e8 33 af ff ff       	call   3450 <strlen@plt>
    851d:	48 89 ee             	mov    %rbp,%rsi
    8520:	48 89 df             	mov    %rbx,%rdi
    8523:	48 89 c2             	mov    %rax,%rdx
    8526:	e8 e5 bc ff ff       	call   4210 <buf_put>
    852b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8530:	ba 01 00 00 00       	mov    $0x1,%edx
    8535:	48 89 df             	mov    %rbx,%rdi
    8538:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    853d:	e8 ce bc ff ff       	call   4210 <buf_put>
    8542:	e9 af fe ff ff       	jmp    83f6 <fwp_write+0x96>
    8547:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    854e:	00 00 
    8550:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8557:	00 
    8558:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    855f:	00 00 
    8561:	0f 85 ce 02 00 00    	jne    8835 <fwp_write+0x4d5>
    8567:	ba 0a 00 00 00       	mov    $0xa,%edx
    856c:	48 8d 35 47 3c 00 00 	lea    0x3c47(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    8573:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    857a:	48 89 df             	mov    %rbx,%rdi
    857d:	5b                   	pop    %rbx
    857e:	5d                   	pop    %rbp
    857f:	41 5c                	pop    %r12
    8581:	41 5d                	pop    %r13
    8583:	41 5e                	pop    %r14
    8585:	41 5f                	pop    %r15
    8587:	e9 84 bc ff ff       	jmp    4210 <buf_put>
    858c:	0f 1f 40 00          	nopl   0x0(%rax)
    8590:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8595:	4d 85 ed             	test   %r13,%r13
    8598:	0f 84 02 0c 00 00    	je     91a0 <fwp_write+0xe40>
    859e:	48 8d 35 5d 3c 00 00 	lea    0x3c5d(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    85a5:	4c 89 ef             	mov    %r13,%rdi
    85a8:	e8 83 af ff ff       	call   3530 <strcmp@plt>
    85ad:	41 89 c1             	mov    %eax,%r9d
    85b0:	85 c0                	test   %eax,%eax
    85b2:	0f 84 6c 0c 00 00    	je     9224 <fwp_write+0xec4>
    85b8:	4c 89 ef             	mov    %r13,%rdi
    85bb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    85c0:	e8 8b ae ff ff       	call   3450 <strlen@plt>
    85c5:	4c 89 ee             	mov    %r13,%rsi
    85c8:	48 89 df             	mov    %rbx,%rdi
    85cb:	48 89 c2             	mov    %rax,%rdx
    85ce:	e8 3d bc ff ff       	call   4210 <buf_put>
    85d3:	ba 01 00 00 00       	mov    $0x1,%edx
    85d8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    85dd:	48 89 df             	mov    %rbx,%rdi
    85e0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    85e5:	e8 26 bc ff ff       	call   4210 <buf_put>
    85ea:	ba 01 00 00 00       	mov    $0x1,%edx
    85ef:	4c 89 fe             	mov    %r15,%rsi
    85f2:	48 89 df             	mov    %rbx,%rdi
    85f5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    85fa:	e8 11 bc ff ff       	call   4210 <buf_put>
    85ff:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8604:	45 31 f6             	xor    %r14d,%r14d
    8607:	85 d2                	test   %edx,%edx
    8609:	0f 8e 81 0a 00 00    	jle    9090 <fwp_write+0xd30>
    860f:	45 31 ed             	xor    %r13d,%r13d
    8612:	4d 85 ed             	test   %r13,%r13
    8615:	0f 85 75 07 00 00    	jne    8d90 <fwp_write+0xa30>
    861b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8622:	00 
    8623:	45 85 f6             	test   %r14d,%r14d
    8626:	0f 84 84 07 00 00    	je     8db0 <fwp_write+0xa50>
    862c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8631:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8636:	48 89 df             	mov    %rbx,%rdi
    8639:	49 83 c5 01          	add    $0x1,%r13
    863d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8641:	31 c9                	xor    %ecx,%ecx
    8643:	e8 18 fd ff ff       	call   8360 <fwp_write>
    8648:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    864d:	7f c3                	jg     8612 <fwp_write+0x2b2>
    864f:	45 85 f6             	test   %r14d,%r14d
    8652:	0f 84 38 0a 00 00    	je     9090 <fwp_write+0xd30>
    8658:	b8 29 00 00 00       	mov    $0x29,%eax
    865d:	ba 01 00 00 00       	mov    $0x1,%edx
    8662:	4c 89 fe             	mov    %r15,%rsi
    8665:	48 89 df             	mov    %rbx,%rdi
    8668:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    866c:	e8 9f bb ff ff       	call   4210 <buf_put>
    8671:	e9 80 fd ff ff       	jmp    83f6 <fwp_write+0x96>
    8676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    867d:	00 00 00 
    8680:	ba 01 00 00 00       	mov    $0x1,%edx
    8685:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    868a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    868f:	e8 7c bb ff ff       	call   4210 <buf_put>
    8694:	48 85 ed             	test   %rbp,%rbp
    8697:	0f 84 93 06 00 00    	je     8d30 <fwp_write+0x9d0>
    869d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    86a1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    86a6:	31 c9                	xor    %ecx,%ecx
    86a8:	48 89 df             	mov    %rbx,%rdi
    86ab:	e8 b0 fc ff ff       	call   8360 <fwp_write>
    86b0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    86b4:	48 85 ed             	test   %rbp,%rbp
    86b7:	0f 84 73 06 00 00    	je     8d30 <fwp_write+0x9d0>
    86bd:	ba 02 00 00 00       	mov    $0x2,%edx
    86c2:	48 8d 35 2c 3b 00 00 	lea    0x3b2c(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    86c9:	48 89 df             	mov    %rbx,%rdi
    86cc:	e8 3f bb ff ff       	call   4210 <buf_put>
    86d1:	eb ca                	jmp    869d <fwp_write+0x33d>
    86d3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    86d8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    86dc:	85 f6                	test   %esi,%esi
    86de:	0f 84 fc 07 00 00    	je     8ee0 <fwp_write+0xb80>
    86e4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    86eb:	00 
    86ec:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    86f3:	00 00 
    86f5:	0f 85 3a 01 00 00    	jne    8835 <fwp_write+0x4d5>
    86fb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    86ff:	4c 89 ea             	mov    %r13,%rdx
    8702:	e9 6c fe ff ff       	jmp    8573 <fwp_write+0x213>
    8707:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    870e:	00 00 
    8710:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8715:	ba 01 00 00 00       	mov    $0x1,%edx
    871a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    871f:	48 89 ee             	mov    %rbp,%rsi
    8722:	e8 e9 ba ff ff       	call   4210 <buf_put>
    8727:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    872c:	4c 89 e7             	mov    %r12,%rdi
    872f:	e8 1c ad ff ff       	call   3450 <strlen@plt>
    8734:	4c 89 e6             	mov    %r12,%rsi
    8737:	48 89 df             	mov    %rbx,%rdi
    873a:	48 89 c2             	mov    %rax,%rdx
    873d:	e8 ce ba ff ff       	call   4210 <buf_put>
    8742:	ba 01 00 00 00       	mov    $0x1,%edx
    8747:	48 89 ee             	mov    %rbp,%rsi
    874a:	48 89 df             	mov    %rbx,%rdi
    874d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8752:	e8 b9 ba ff ff       	call   4210 <buf_put>
    8757:	e9 9a fc ff ff       	jmp    83f6 <fwp_write+0x96>
    875c:	0f 1f 40 00          	nopl   0x0(%rax)
    8760:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8765:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8769:	0f 8a 8e 0b 00 00    	jp     92fd <fwp_write+0xf9d>
    876f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8773:	66 0f 54 05 b5 44 00 	andpd  0x44b5(%rip),%xmm0        # cc30 <msg.4+0xc0>
    877a:	00 
    877b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8780:	66 0f 2e 05 20 44 00 	ucomisd 0x4420(%rip),%xmm0        # cba8 <msg.4+0x38>
    8787:	00 
    8788:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    878f:	00 
    8790:	0f 87 b2 09 00 00    	ja     9148 <fwp_write+0xde8>
    8796:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    879d:	00 00 00 
    87a0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    87a4:	89 ee                	mov    %ebp,%esi
    87a6:	4c 89 e7             	mov    %r12,%rdi
    87a9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    87ae:	e8 5d bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    87b3:	31 f6                	xor    %esi,%esi
    87b5:	4c 89 e7             	mov    %r12,%rdi
    87b8:	e8 53 ac ff ff       	call   3410 <strtod@plt>
    87bd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    87c2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    87c6:	7a 06                	jp     87ce <fwp_write+0x46e>
    87c8:	0f 84 e9 01 00 00    	je     89b7 <fwp_write+0x657>
    87ce:	83 c5 01             	add    $0x1,%ebp
    87d1:	83 fd 12             	cmp    $0x12,%ebp
    87d4:	75 ca                	jne    87a0 <fwp_write+0x440>
    87d6:	be 11 00 00 00       	mov    $0x11,%esi
    87db:	66 0f 28 c1          	movapd %xmm1,%xmm0
    87df:	4c 89 e7             	mov    %r12,%rdi
    87e2:	e8 29 bf ff ff       	call   4710 <fwp_format_g.constprop.0>
    87e7:	e9 cb 01 00 00       	jmp    89b7 <fwp_write+0x657>
    87ec:	0f 1f 40 00          	nopl   0x0(%rax)
    87f0:	48 83 fd 01          	cmp    $0x1,%rbp
    87f4:	0f 84 e6 08 00 00    	je     90e0 <fwp_write+0xd80>
    87fa:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    87fe:	b8 02 00 00 00       	mov    $0x2,%eax
    8803:	ba 01 00 00 00       	mov    $0x1,%edx
    8808:	48 0f 44 d0          	cmove  %rax,%rdx
    880c:	48 8d 35 90 39 00 00 	lea    0x3990(%rip),%rsi        # c1a3 <_IO_stdin_used+0x1a3>
    8813:	48 8d 05 8e 39 00 00 	lea    0x398e(%rip),%rax        # c1a8 <_IO_stdin_used+0x1a8>
    881a:	48 0f 44 f0          	cmove  %rax,%rsi
    881e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8825:	00 
    8826:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    882d:	00 00 
    882f:	0f 84 3e fd ff ff    	je     8573 <fwp_write+0x213>
    8835:	e8 26 ac ff ff       	call   3460 <__stack_chk_fail@plt>
    883a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8840:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8845:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    884a:	e8 01 b9 ff ff       	call   4150 <buf_grow>
    884f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8853:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8859:	4c 03 0b             	add    (%rbx),%r9
    885c:	66 45 89 11          	mov    %r10w,(%r9)
    8860:	45 85 e4             	test   %r12d,%r12d
    8863:	0f 8e 07 05 00 00    	jle    8d70 <fwp_write+0xa10>
    8869:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8870:	55 55 55 
    8873:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8878:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    887f:	aa aa aa 
    8882:	49 83 c1 01          	add    $0x1,%r9
    8886:	eb 45                	jmp    88cd <fwp_write+0x56d>
    8888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    888f:	00 
    8890:	be 01 00 00 00       	mov    $0x1,%esi
    8895:	b8 2d 00 00 00       	mov    $0x2d,%eax
    889a:	88 07                	mov    %al,(%rdi)
    889c:	48 89 e8             	mov    %rbp,%rax
    889f:	49 f7 e8             	imul   %r8
    88a2:	48 89 e8             	mov    %rbp,%rax
    88a5:	48 c1 f8 3f          	sar    $0x3f,%rax
    88a9:	48 29 c2             	sub    %rax,%rdx
    88ac:	48 85 c9             	test   %rcx,%rcx
    88af:	0f 95 c0             	setne  %al
    88b2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    88b6:	48 83 ef 01          	sub    $0x1,%rdi
    88ba:	48 21 c5             	and    %rax,%rbp
    88bd:	48 29 ea             	sub    %rbp,%rdx
    88c0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    88c4:	49 39 f9             	cmp    %rdi,%r9
    88c7:	0f 84 a3 04 00 00    	je     8d70 <fwp_write+0xa10>
    88cd:	48 89 e8             	mov    %rbp,%rax
    88d0:	49 f7 e8             	imul   %r8
    88d3:	48 89 e8             	mov    %rbp,%rax
    88d6:	48 c1 f8 3f          	sar    $0x3f,%rax
    88da:	48 89 d1             	mov    %rdx,%rcx
    88dd:	48 29 c1             	sub    %rax,%rcx
    88e0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    88e4:	48 89 e9             	mov    %rbp,%rcx
    88e7:	48 29 c1             	sub    %rax,%rcx
    88ea:	48 8d 41 03          	lea    0x3(%rcx),%rax
    88ee:	49 f7 e2             	mul    %r10
    88f1:	b8 30 00 00 00       	mov    $0x30,%eax
    88f6:	48 89 d6             	mov    %rdx,%rsi
    88f9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    88fd:	48 d1 ee             	shr    $1,%rsi
    8900:	48 01 f2             	add    %rsi,%rdx
    8903:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    8907:	48 29 d6             	sub    %rdx,%rsi
    890a:	74 8e                	je     889a <fwp_write+0x53a>
    890c:	48 83 fe 01          	cmp    $0x1,%rsi
    8910:	0f 85 7a ff ff ff    	jne    8890 <fwp_write+0x530>
    8916:	31 f6                	xor    %esi,%esi
    8918:	b8 2b 00 00 00       	mov    $0x2b,%eax
    891d:	e9 78 ff ff ff       	jmp    889a <fwp_write+0x53a>
    8922:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8928:	66 0f 6e cd          	movd   %ebp,%xmm1
    892c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    892f:	0f 8a c8 09 00 00    	jp     92fd <fwp_write+0xf9d>
    8935:	0f 28 c1             	movaps %xmm1,%xmm0
    8938:	0f 54 05 e1 42 00 00 	andps  0x42e1(%rip),%xmm0        # cc20 <msg.4+0xb0>
    893f:	0f 2e 05 be 36 00 00 	ucomiss 0x36be(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8946:	0f 87 24 08 00 00    	ja     9170 <fwp_write+0xe10>
    894c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8950:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8956:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    895d:	00 
    895e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8962:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    896e:	00 00 
    8970:	44 89 ee             	mov    %r13d,%esi
    8973:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8978:	4c 89 e7             	mov    %r12,%rdi
    897b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8980:	e8 8b bd ff ff       	call   4710 <fwp_format_g.constprop.0>
    8985:	31 f6                	xor    %esi,%esi
    8987:	4c 89 e7             	mov    %r12,%rdi
    898a:	e8 21 ab ff ff       	call   34b0 <strtof@plt>
    898f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8994:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8997:	7a 02                	jp     899b <fwp_write+0x63b>
    8999:	74 1c                	je     89b7 <fwp_write+0x657>
    899b:	41 83 c5 01          	add    $0x1,%r13d
    899f:	41 83 fd 0a          	cmp    $0xa,%r13d
    89a3:	75 cb                	jne    8970 <fwp_write+0x610>
    89a5:	be 09 00 00 00       	mov    $0x9,%esi
    89aa:	66 49 0f 6e c7       	movq   %r15,%xmm0
    89af:	4c 89 e7             	mov    %r12,%rdi
    89b2:	e8 59 bd ff ff       	call   4710 <fwp_format_g.constprop.0>
    89b7:	4c 89 e7             	mov    %r12,%rdi
    89ba:	e8 c1 b9 ff ff       	call   4380 <fwp_finish_float>
    89bf:	e9 1c fa ff ff       	jmp    83e0 <fwp_write+0x80>
    89c4:	0f 1f 40 00          	nopl   0x0(%rax)
    89c8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    89cc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    89d0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    89d7:	00 
    89d8:	48 89 ef             	mov    %rbp,%rdi
    89db:	e8 60 b0 ff ff       	call   3a40 <fwp_fmt_u128>
    89e0:	48 89 ef             	mov    %rbp,%rdi
    89e3:	e8 68 aa ff ff       	call   3450 <strlen@plt>
    89e8:	48 89 ee             	mov    %rbp,%rsi
    89eb:	48 89 df             	mov    %rbx,%rdi
    89ee:	48 89 c2             	mov    %rax,%rdx
    89f1:	e8 1a b8 ff ff       	call   4210 <buf_put>
    89f6:	e9 fb f9 ff ff       	jmp    83f6 <fwp_write+0x96>
    89fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a00:	ba 06 00 00 00       	mov    $0x6,%edx
    8a05:	48 8d 35 ec 37 00 00 	lea    0x37ec(%rip),%rsi        # c1f8 <_IO_stdin_used+0x1f8>
    8a0c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    8a12:	e8 f9 b7 ff ff       	call   4210 <buf_put>
    8a17:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8a1e:	ff ff 7f 
    8a21:	48 23 55 00          	and    0x0(%rbp),%rdx
    8a25:	0f 84 86 02 00 00    	je     8cb1 <fwp_write+0x951>
    8a2b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8a30:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8a34:	48 85 d2             	test   %rdx,%rdx
    8a37:	0f 84 ae 00 00 00    	je     8aeb <fwp_write+0x78b>
    8a3d:	8b 0a                	mov    (%rdx),%ecx
    8a3f:	83 f9 1c             	cmp    $0x1c,%ecx
    8a42:	0f 84 58 06 00 00    	je     90a0 <fwp_write+0xd40>
    8a48:	83 f9 1b             	cmp    $0x1b,%ecx
    8a4b:	0f 87 9a 00 00 00    	ja     8aeb <fwp_write+0x78b>
    8a51:	be 01 00 00 00       	mov    $0x1,%esi
    8a56:	48 d3 e6             	shl    %cl,%rsi
    8a59:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    8a5f:	0f 85 4b 04 00 00    	jne    8eb0 <fwp_write+0xb50>
    8a65:	f7 c6 84 04 00 00    	test   $0x484,%esi
    8a6b:	0f 85 0f 04 00 00    	jne    8e80 <fwp_write+0xb20>
    8a71:	83 e6 21             	and    $0x21,%esi
    8a74:	74 75                	je     8aeb <fwp_write+0x78b>
    8a76:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    8a7b:	48 85 ff             	test   %rdi,%rdi
    8a7e:	79 07                	jns    8a87 <fwp_write+0x727>
    8a80:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8a84:	4c 01 ee             	add    %r13,%rsi
    8a87:	48 0f be 3e          	movsbq (%rsi),%rdi
    8a8b:	85 c9                	test   %ecx,%ecx
    8a8d:	40 0f b6 f7          	movzbl %dil,%esi
    8a91:	48 0f 44 f7          	cmove  %rdi,%rsi
    8a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a9c:	00 00 00 00 
    8aa0:	31 c9                	xor    %ecx,%ecx
    8aa2:	48 89 df             	mov    %rbx,%rdi
    8aa5:	49 83 c5 01          	add    $0x1,%r13
    8aa9:	e8 b2 f8 ff ff       	call   8360 <fwp_write>
    8aae:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8ab5:	ff ff 7f 
    8ab8:	48 23 55 00          	and    0x0(%rbp),%rdx
    8abc:	49 39 d5             	cmp    %rdx,%r13
    8abf:	0f 83 ec 01 00 00    	jae    8cb1 <fwp_write+0x951>
    8ac5:	ba 02 00 00 00       	mov    $0x2,%edx
    8aca:	48 89 df             	mov    %rbx,%rdi
    8acd:	48 8d 35 21 37 00 00 	lea    0x3721(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8ad4:	e8 37 b7 ff ff       	call   4210 <buf_put>
    8ad9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8ade:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    8ae2:	48 85 d2             	test   %rdx,%rdx
    8ae5:	0f 85 52 ff ff ff    	jne    8a3d <fwp_write+0x6dd>
    8aeb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    8af0:	48 85 ff             	test   %rdi,%rdi
    8af3:	0f 88 cf 05 00 00    	js     90c8 <fwp_write+0xd68>
    8af9:	48 8b 31             	mov    (%rcx),%rsi
    8afc:	eb a2                	jmp    8aa0 <fwp_write+0x740>
    8afe:	66 90                	xchg   %ax,%ax
    8b00:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b07:	00 
    8b08:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b0f:	00 00 
    8b11:	0f 85 1e fd ff ff    	jne    8835 <fwp_write+0x4d5>
    8b17:	ba 08 00 00 00       	mov    $0x8,%edx
    8b1c:	48 8d 35 a2 36 00 00 	lea    0x36a2(%rip),%rsi        # c1c5 <_IO_stdin_used+0x1c5>
    8b23:	e9 4b fa ff ff       	jmp    8573 <fwp_write+0x213>
    8b28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8b2f:	00 
    8b30:	89 e8                	mov    %ebp,%eax
    8b32:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    8b39:	76 03                	jbe    8b3e <fwp_write+0x7de>
    8b3b:	8b 45 00             	mov    0x0(%rbp),%eax
    8b3e:	41 89 c6             	mov    %eax,%r14d
    8b41:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8b46:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    8b4b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    8b4f:	4c 89 ef             	mov    %r13,%rdi
    8b52:	e8 f9 a8 ff ff       	call   3450 <strlen@plt>
    8b57:	4c 89 ee             	mov    %r13,%rsi
    8b5a:	48 89 df             	mov    %rbx,%rdi
    8b5d:	48 89 c2             	mov    %rax,%rdx
    8b60:	e8 ab b6 ff ff       	call   4210 <buf_put>
    8b65:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8b6a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    8b6e:	85 f6                	test   %esi,%esi
    8b70:	0f 8e 80 f8 ff ff    	jle    83f6 <fwp_write+0x96>
    8b76:	45 31 ed             	xor    %r13d,%r13d
    8b79:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8b7e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8b83:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8b88:	ba 01 00 00 00       	mov    $0x1,%edx
    8b8d:	4c 89 fe             	mov    %r15,%rsi
    8b90:	48 89 04 24          	mov    %rax,(%rsp)
    8b94:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8b99:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    8b9d:	48 89 df             	mov    %rbx,%rdi
    8ba0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8ba4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8ba9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    8bae:	e8 5d b6 ff ff       	call   4210 <buf_put>
    8bb3:	41 8b 06             	mov    (%r14),%eax
    8bb6:	83 f8 0e             	cmp    $0xe,%eax
    8bb9:	0f 84 71 02 00 00    	je     8e30 <fwp_write+0xad0>
    8bbf:	83 f8 10             	cmp    $0x10,%eax
    8bc2:	0f 84 38 02 00 00    	je     8e00 <fwp_write+0xaa0>
    8bc8:	83 f8 0a             	cmp    $0xa,%eax
    8bcb:	0f 84 7f 04 00 00    	je     9050 <fwp_write+0xcf0>
    8bd1:	0f 8f f9 00 00 00    	jg     8cd0 <fwp_write+0x970>
    8bd7:	83 f8 03             	cmp    $0x3,%eax
    8bda:	0f 8f 50 04 00 00    	jg     9030 <fwp_write+0xcd0>
    8be0:	85 c0                	test   %eax,%eax
    8be2:	78 10                	js     8bf4 <fwp_write+0x894>
    8be4:	48 8b 04 24          	mov    (%rsp),%rax
    8be8:	48 c1 e8 3f          	shr    $0x3f,%rax
    8bec:	85 c0                	test   %eax,%eax
    8bee:	0f 85 f9 00 00 00    	jne    8ced <fwp_write+0x98d>
    8bf4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8bf9:	48 8b 34 24          	mov    (%rsp),%rsi
    8bfd:	31 c9                	xor    %ecx,%ecx
    8bff:	48 89 df             	mov    %rbx,%rdi
    8c02:	e8 59 f7 ff ff       	call   8360 <fwp_write>
    8c07:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    8c0c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8c11:	49 83 c5 01          	add    $0x1,%r13
    8c15:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    8c19:	0f 8f 5f ff ff ff    	jg     8b7e <fwp_write+0x81e>
    8c1f:	e9 d2 f7 ff ff       	jmp    83f6 <fwp_write+0x96>
    8c24:	0f 1f 40 00          	nopl   0x0(%rax)
    8c28:	ba 06 00 00 00       	mov    $0x6,%edx
    8c2d:	48 8d 35 b7 35 00 00 	lea    0x35b7(%rip),%rsi        # c1eb <_IO_stdin_used+0x1eb>
    8c34:	45 31 ed             	xor    %r13d,%r13d
    8c37:	e8 d4 b5 ff ff       	call   4210 <buf_put>
    8c3c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8c41:	75 19                	jne    8c5c <fwp_write+0x8fc>
    8c43:	eb 6c                	jmp    8cb1 <fwp_write+0x951>
    8c45:	0f 1f 00             	nopl   (%rax)
    8c48:	ba 02 00 00 00       	mov    $0x2,%edx
    8c4d:	48 8d 35 a1 35 00 00 	lea    0x35a1(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8c54:	48 89 df             	mov    %rbx,%rdi
    8c57:	e8 b4 b5 ff ff       	call   4210 <buf_put>
    8c5c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8c62:	b9 00 02 00 00       	mov    $0x200,%ecx
    8c67:	31 c0                	xor    %eax,%eax
    8c69:	49 83 c5 01          	add    $0x1,%r13
    8c6d:	4c 8d 05 7e 35 00 00 	lea    0x357e(%rip),%r8        # c1f2 <_IO_stdin_used+0x1f2>
    8c74:	ba 02 00 00 00       	mov    $0x2,%edx
    8c79:	be 00 02 00 00       	mov    $0x200,%esi
    8c7e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c85:	00 
    8c86:	e8 25 a7 ff ff       	call   33b0 <__snprintf_chk@plt>
    8c8b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8c92:	00 
    8c93:	e8 b8 a7 ff ff       	call   3450 <strlen@plt>
    8c98:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8c9f:	00 
    8ca0:	48 89 df             	mov    %rbx,%rdi
    8ca3:	48 89 c2             	mov    %rax,%rdx
    8ca6:	e8 65 b5 ff ff       	call   4210 <buf_put>
    8cab:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8caf:	72 97                	jb     8c48 <fwp_write+0x8e8>
    8cb1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8cb6:	ba 01 00 00 00       	mov    $0x1,%edx
    8cbb:	48 89 df             	mov    %rbx,%rdi
    8cbe:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8cc3:	e8 48 b5 ff ff       	call   4210 <buf_put>
    8cc8:	e9 29 f7 ff ff       	jmp    83f6 <fwp_write+0x96>
    8ccd:	0f 1f 00             	nopl   (%rax)
    8cd0:	83 f8 0b             	cmp    $0xb,%eax
    8cd3:	0f 85 1b ff ff ff    	jne    8bf4 <fwp_write+0x894>
    8cd9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8cde:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8ce2:	83 e0 01             	and    $0x1,%eax
    8ce5:	85 c0                	test   %eax,%eax
    8ce7:	0f 84 07 ff ff ff    	je     8bf4 <fwp_write+0x894>
    8ced:	4c 89 fe             	mov    %r15,%rsi
    8cf0:	48 89 df             	mov    %rbx,%rdi
    8cf3:	ba 01 00 00 00       	mov    $0x1,%edx
    8cf8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8cfd:	e8 0e b5 ff ff       	call   4210 <buf_put>
    8d02:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8d07:	48 8b 34 24          	mov    (%rsp),%rsi
    8d0b:	31 c9                	xor    %ecx,%ecx
    8d0d:	48 89 df             	mov    %rbx,%rdi
    8d10:	e8 4b f6 ff ff       	call   8360 <fwp_write>
    8d15:	ba 01 00 00 00       	mov    $0x1,%edx
    8d1a:	4c 89 fe             	mov    %r15,%rsi
    8d1d:	48 89 df             	mov    %rbx,%rdi
    8d20:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8d25:	e8 e6 b4 ff ff       	call   4210 <buf_put>
    8d2a:	e9 d8 fe ff ff       	jmp    8c07 <fwp_write+0x8a7>
    8d2f:	90                   	nop
    8d30:	ba 01 00 00 00       	mov    $0x1,%edx
    8d35:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d3a:	48 89 df             	mov    %rbx,%rdi
    8d3d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8d42:	e8 c9 b4 ff ff       	call   4210 <buf_put>
    8d47:	e9 aa f6 ff ff       	jmp    83f6 <fwp_write+0x96>
    8d4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d50:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d55:	ba 01 00 00 00       	mov    $0x1,%edx
    8d5a:	48 89 df             	mov    %rbx,%rdi
    8d5d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8d62:	e8 a9 b4 ff ff       	call   4210 <buf_put>
    8d67:	e9 8a f6 ff ff       	jmp    83f6 <fwp_write+0x96>
    8d6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d70:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8d74:	48 8b 13             	mov    (%rbx),%rdx
    8d77:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8d7c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8d80:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8d84:	e9 6d f6 ff ff       	jmp    83f6 <fwp_write+0x96>
    8d89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8d90:	ba 02 00 00 00       	mov    $0x2,%edx
    8d95:	48 8d 35 59 34 00 00 	lea    0x3459(%rip),%rsi        # c1f5 <_IO_stdin_used+0x1f5>
    8d9c:	48 89 df             	mov    %rbx,%rdi
    8d9f:	e8 6c b4 ff ff       	call   4210 <buf_put>
    8da4:	e9 72 f8 ff ff       	jmp    861b <fwp_write+0x2bb>
    8da9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8db0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8db5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8dba:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8dbe:	48 89 f7             	mov    %rsi,%rdi
    8dc1:	48 89 34 24          	mov    %rsi,(%rsp)
    8dc5:	e8 86 a6 ff ff       	call   3450 <strlen@plt>
    8dca:	48 8b 34 24          	mov    (%rsp),%rsi
    8dce:	48 89 df             	mov    %rbx,%rdi
    8dd1:	48 89 c2             	mov    %rax,%rdx
    8dd4:	e8 37 b4 ff ff       	call   4210 <buf_put>
    8dd9:	ba 03 00 00 00       	mov    $0x3,%edx
    8dde:	48 8d 35 33 34 00 00 	lea    0x3433(%rip),%rsi        # c218 <_IO_stdin_used+0x218>
    8de5:	48 89 df             	mov    %rbx,%rdi
    8de8:	e8 23 b4 ff ff       	call   4210 <buf_put>
    8ded:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8df2:	e9 35 f8 ff ff       	jmp    862c <fwp_write+0x2cc>
    8df7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8dfe:	00 00 
    8e00:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8e05:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8e09:	48 85 ff             	test   %rdi,%rdi
    8e0c:	0f 84 e2 fd ff ff    	je     8bf4 <fwp_write+0x894>
    8e12:	48 8d 35 e9 33 00 00 	lea    0x33e9(%rip),%rsi        # c202 <_IO_stdin_used+0x202>
    8e19:	e8 12 a7 ff ff       	call   3530 <strcmp@plt>
    8e1e:	85 c0                	test   %eax,%eax
    8e20:	0f 95 c0             	setne  %al
    8e23:	0f b6 c0             	movzbl %al,%eax
    8e26:	e9 c1 fd ff ff       	jmp    8bec <fwp_write+0x88c>
    8e2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e30:	31 c0                	xor    %eax,%eax
    8e32:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8e39:	00 
    8e3a:	0f 97 c0             	seta   %al
    8e3d:	e9 aa fd ff ff       	jmp    8bec <fwp_write+0x88c>
    8e42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e48:	48 89 df             	mov    %rbx,%rdi
    8e4b:	ba 02 00 00 00       	mov    $0x2,%edx
    8e50:	48 8d 35 a8 33 00 00 	lea    0x33a8(%rip),%rsi        # c1ff <_IO_stdin_used+0x1ff>
    8e57:	e8 b4 b3 ff ff       	call   4210 <buf_put>
    8e5c:	4c 89 e8             	mov    %r13,%rax
    8e5f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8e64:	31 c9                	xor    %ecx,%ecx
    8e66:	48 c1 e0 04          	shl    $0x4,%rax
    8e6a:	48 89 df             	mov    %rbx,%rdi
    8e6d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8e72:	e8 e9 f4 ff ff       	call   8360 <fwp_write>
    8e77:	e9 5e f6 ff ff       	jmp    84da <fwp_write+0x17a>
    8e7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e80:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8e85:	48 85 ff             	test   %rdi,%rdi
    8e88:	79 0c                	jns    8e96 <fwp_write+0xb36>
    8e8a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8e91:	00 
    8e92:	48 03 75 10          	add    0x10(%rbp),%rsi
    8e96:	48 63 3e             	movslq (%rsi),%rdi
    8e99:	83 f9 02             	cmp    $0x2,%ecx
    8e9c:	89 fe                	mov    %edi,%esi
    8e9e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ea2:	e9 f9 fb ff ff       	jmp    8aa0 <fwp_write+0x740>
    8ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8eae:	00 00 
    8eb0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8eb5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8eba:	48 85 ff             	test   %rdi,%rdi
    8ebd:	0f 88 0f 03 00 00    	js     91d2 <fwp_write+0xe72>
    8ec3:	49 0f bf 38          	movswq (%r8),%rdi
    8ec7:	83 f9 01             	cmp    $0x1,%ecx
    8eca:	0f b7 f7             	movzwl %di,%esi
    8ecd:	48 0f 44 f7          	cmove  %rdi,%rsi
    8ed1:	e9 ca fb ff ff       	jmp    8aa0 <fwp_write+0x740>
    8ed6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8edd:	00 00 00 
    8ee0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ee5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8eea:	48 83 c5 08          	add    $0x8,%rbp
    8eee:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8ef3:	e8 18 b3 ff ff       	call   4210 <buf_put>
    8ef8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8efd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8f02:	4d 85 ed             	test   %r13,%r13
    8f05:	75 46                	jne    8f4d <fwp_write+0xbed>
    8f07:	e9 04 01 00 00       	jmp    9010 <fwp_write+0xcb0>
    8f0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f10:	41 80 f9 09          	cmp    $0x9,%r9b
    8f14:	0f 84 d6 00 00 00    	je     8ff0 <fwp_write+0xc90>
    8f1a:	41 80 f9 0a          	cmp    $0xa,%r9b
    8f1e:	0f 85 9c 00 00 00    	jne    8fc0 <fwp_write+0xc60>
    8f24:	ba 02 00 00 00       	mov    $0x2,%edx
    8f29:	48 8d 35 ab 32 00 00 	lea    0x32ab(%rip),%rsi        # c1db <_IO_stdin_used+0x1db>
    8f30:	48 89 df             	mov    %rbx,%rdi
    8f33:	e8 d8 b2 ff ff       	call   4210 <buf_put>
    8f38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8f3f:	00 
    8f40:	48 83 c5 01          	add    $0x1,%rbp
    8f44:	49 39 ec             	cmp    %rbp,%r12
    8f47:	0f 84 c3 00 00 00    	je     9010 <fwp_write+0xcb0>
    8f4d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8f52:	41 80 f9 0d          	cmp    $0xd,%r9b
    8f56:	74 28                	je     8f80 <fwp_write+0xc20>
    8f58:	7e b6                	jle    8f10 <fwp_write+0xbb0>
    8f5a:	41 80 f9 22          	cmp    $0x22,%r9b
    8f5e:	74 40                	je     8fa0 <fwp_write+0xc40>
    8f60:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8f64:	75 5a                	jne    8fc0 <fwp_write+0xc60>
    8f66:	ba 02 00 00 00       	mov    $0x2,%edx
    8f6b:	48 8d 35 66 32 00 00 	lea    0x3266(%rip),%rsi        # c1d8 <_IO_stdin_used+0x1d8>
    8f72:	48 89 df             	mov    %rbx,%rdi
    8f75:	e8 96 b2 ff ff       	call   4210 <buf_put>
    8f7a:	eb c4                	jmp    8f40 <fwp_write+0xbe0>
    8f7c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f80:	ba 02 00 00 00       	mov    $0x2,%edx
    8f85:	48 8d 35 55 32 00 00 	lea    0x3255(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    8f8c:	48 89 df             	mov    %rbx,%rdi
    8f8f:	e8 7c b2 ff ff       	call   4210 <buf_put>
    8f94:	eb aa                	jmp    8f40 <fwp_write+0xbe0>
    8f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f9d:	00 00 00 
    8fa0:	ba 02 00 00 00       	mov    $0x2,%edx
    8fa5:	48 8d 35 29 32 00 00 	lea    0x3229(%rip),%rsi        # c1d5 <_IO_stdin_used+0x1d5>
    8fac:	48 89 df             	mov    %rbx,%rdi
    8faf:	e8 5c b2 ff ff       	call   4210 <buf_put>
    8fb4:	eb 8a                	jmp    8f40 <fwp_write+0xbe0>
    8fb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fbd:	00 00 00 
    8fc0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8fc4:	0f 86 2e 01 00 00    	jbe    90f8 <fwp_write+0xd98>
    8fca:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8fce:	0f 84 24 01 00 00    	je     90f8 <fwp_write+0xd98>
    8fd4:	ba 01 00 00 00       	mov    $0x1,%edx
    8fd9:	4c 89 fe             	mov    %r15,%rsi
    8fdc:	48 89 df             	mov    %rbx,%rdi
    8fdf:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8fe4:	e8 27 b2 ff ff       	call   4210 <buf_put>
    8fe9:	e9 52 ff ff ff       	jmp    8f40 <fwp_write+0xbe0>
    8fee:	66 90                	xchg   %ax,%ax
    8ff0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ff5:	48 8d 35 e2 31 00 00 	lea    0x31e2(%rip),%rsi        # c1de <_IO_stdin_used+0x1de>
    8ffc:	48 89 df             	mov    %rbx,%rdi
    8fff:	e8 0c b2 ff ff       	call   4210 <buf_put>
    9004:	e9 37 ff ff ff       	jmp    8f40 <fwp_write+0xbe0>
    9009:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9010:	ba 01 00 00 00       	mov    $0x1,%edx
    9015:	4c 89 fe             	mov    %r15,%rsi
    9018:	48 89 df             	mov    %rbx,%rdi
    901b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9020:	e8 eb b1 ff ff       	call   4210 <buf_put>
    9025:	e9 cc f3 ff ff       	jmp    83f6 <fwp_write+0x96>
    902a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9030:	83 f8 04             	cmp    $0x4,%eax
    9033:	0f 85 bb fb ff ff    	jne    8bf4 <fwp_write+0x894>
    9039:	48 8b 04 24          	mov    (%rsp),%rax
    903d:	48 8b 40 08          	mov    0x8(%rax),%rax
    9041:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9046:	48 c1 e8 3f          	shr    $0x3f,%rax
    904a:	e9 96 fc ff ff       	jmp    8ce5 <fwp_write+0x985>
    904f:	90                   	nop
    9050:	8b 0c 24             	mov    (%rsp),%ecx
    9053:	31 c0                	xor    %eax,%eax
    9055:	85 c9                	test   %ecx,%ecx
    9057:	0f 98 c0             	sets   %al
    905a:	e9 86 fc ff ff       	jmp    8ce5 <fwp_write+0x985>
    905f:	90                   	nop
    9060:	48 f7 d8             	neg    %rax
    9063:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    906a:	00 
    906b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    9072:	2d 
    9073:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    907a:	00 
    907b:	48 83 d2 00          	adc    $0x0,%rdx
    907f:	48 89 c6             	mov    %rax,%rsi
    9082:	48 f7 da             	neg    %rdx
    9085:	e8 b6 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    908a:	e9 51 f3 ff ff       	jmp    83e0 <fwp_write+0x80>
    908f:	90                   	nop
    9090:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9095:	e9 c3 f5 ff ff       	jmp    865d <fwp_write+0x2fd>
    909a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90a0:	4c 89 e9             	mov    %r13,%rcx
    90a3:	48 c1 e1 04          	shl    $0x4,%rcx
    90a7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    90ac:	48 85 ff             	test   %rdi,%rdi
    90af:	0f 89 eb f9 ff ff    	jns    8aa0 <fwp_write+0x740>
    90b5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    90b9:	48 89 ce             	mov    %rcx,%rsi
    90bc:	e9 df f9 ff ff       	jmp    8aa0 <fwp_write+0x740>
    90c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90c8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    90cf:	00 
    90d0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    90d4:	e9 20 fa ff ff       	jmp    8af9 <fwp_write+0x799>
    90d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90e0:	ba 02 00 00 00       	mov    $0x2,%edx
    90e5:	48 8d 35 b9 30 00 00 	lea    0x30b9(%rip),%rsi        # c1a5 <_IO_stdin_used+0x1a5>
    90ec:	e9 2d f7 ff ff       	jmp    881e <fwp_write+0x4be>
    90f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    90f8:	4c 8d 05 e5 30 00 00 	lea    0x30e5(%rip),%r8        # c1e4 <_IO_stdin_used+0x1e4>
    90ff:	b9 10 00 00 00       	mov    $0x10,%ecx
    9104:	31 c0                	xor    %eax,%eax
    9106:	ba 02 00 00 00       	mov    $0x2,%edx
    910b:	be 10 00 00 00       	mov    $0x10,%esi
    9110:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9117:	00 
    9118:	e8 93 a2 ff ff       	call   33b0 <__snprintf_chk@plt>
    911d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9124:	00 
    9125:	e8 26 a3 ff ff       	call   3450 <strlen@plt>
    912a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9131:	00 
    9132:	48 89 df             	mov    %rbx,%rdi
    9135:	48 89 c2             	mov    %rax,%rdx
    9138:	e8 d3 b0 ff ff       	call   4210 <buf_put>
    913d:	e9 fe fd ff ff       	jmp    8f40 <fwp_write+0xbe0>
    9142:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9148:	66 0f ef c0          	pxor   %xmm0,%xmm0
    914c:	48 8d 35 4c 30 00 00 	lea    0x304c(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    9153:	48 8d 05 44 30 00 00 	lea    0x3044(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    915a:	4c 89 e7             	mov    %r12,%rdi
    915d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    9161:	48 0f 46 f0          	cmovbe %rax,%rsi
    9165:	e8 86 a2 ff ff       	call   33f0 <strcpy@plt>
    916a:	e9 71 f2 ff ff       	jmp    83e0 <fwp_write+0x80>
    916f:	90                   	nop
    9170:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9174:	48 8d 35 24 30 00 00 	lea    0x3024(%rip),%rsi        # c19f <_IO_stdin_used+0x19f>
    917b:	48 8d 05 1c 30 00 00 	lea    0x301c(%rip),%rax        # c19e <_IO_stdin_used+0x19e>
    9182:	0f 2f c8             	comiss %xmm0,%xmm1
    9185:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    918c:	00 
    918d:	4c 89 e7             	mov    %r12,%rdi
    9190:	48 0f 46 f0          	cmovbe %rax,%rsi
    9194:	e8 57 a2 ff ff       	call   33f0 <strcpy@plt>
    9199:	e9 42 f2 ff ff       	jmp    83e0 <fwp_write+0x80>
    919e:	66 90                	xchg   %ax,%ax
    91a0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    91a5:	45 85 c0             	test   %r8d,%r8d
    91a8:	75 34                	jne    91de <fwp_write+0xe7e>
    91aa:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    91b1:	00 
    91b2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    91b9:	00 00 
    91bb:	0f 85 74 f6 ff ff    	jne    8835 <fwp_write+0x4d5>
    91c1:	ba 02 00 00 00       	mov    $0x2,%edx
    91c6:	48 8d 35 48 30 00 00 	lea    0x3048(%rip),%rsi        # c215 <_IO_stdin_used+0x215>
    91cd:	e9 a1 f3 ff ff       	jmp    8573 <fwp_write+0x213>
    91d2:	48 03 75 10          	add    0x10(%rbp),%rsi
    91d6:	49 89 f0             	mov    %rsi,%r8
    91d9:	e9 e5 fc ff ff       	jmp    8ec3 <fwp_write+0xb63>
    91de:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    91e3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    91e8:	85 ff                	test   %edi,%edi
    91ea:	0f 84 fa f3 ff ff    	je     85ea <fwp_write+0x28a>
    91f0:	ba 01 00 00 00       	mov    $0x1,%edx
    91f5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    91fa:	48 89 df             	mov    %rbx,%rdi
    91fd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9202:	e8 09 b0 ff ff       	call   4210 <buf_put>
    9207:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    920c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9211:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9217:	85 c0                	test   %eax,%eax
    9219:	0f 8f f0 f3 ff ff    	jg     860f <fwp_write+0x2af>
    921f:	e9 34 f4 ff ff       	jmp    8658 <fwp_write+0x2f8>
    9224:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9228:	49 89 c5             	mov    %rax,%r13
    922b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9230:	49 89 c4             	mov    %rax,%r12
    9233:	49 c1 fd 3f          	sar    $0x3f,%r13
    9237:	4c 09 e8             	or     %r13,%rax
    923a:	0f 84 a7 00 00 00    	je     92e7 <fwp_write+0xf87>
    9240:	48 8d 2d 59 50 00 00 	lea    0x5059(%rip),%rbp        # e2a0 <units.0>
    9247:	4d 89 e7             	mov    %r12,%r15
    924a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    924e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9253:	4c 89 ff             	mov    %r15,%rdi
    9256:	4c 89 ee             	mov    %r13,%rsi
    9259:	44 89 0c 24          	mov    %r9d,(%rsp)
    925d:	48 99                	cqto
    925f:	48 89 d1             	mov    %rdx,%rcx
    9262:	48 89 c2             	mov    %rax,%rdx
    9265:	e8 a6 23 00 00       	call   b610 <__divmodti4>
    926a:	44 8b 0c 24          	mov    (%rsp),%r9d
    926e:	48 89 c1             	mov    %rax,%rcx
    9271:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9276:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    927b:	0f 84 94 00 00 00    	je     9315 <fwp_write+0xfb5>
    9281:	41 83 c1 01          	add    $0x1,%r9d
    9285:	48 83 c5 10          	add    $0x10,%rbp
    9289:	41 83 f9 05          	cmp    $0x5,%r9d
    928d:	75 bb                	jne    924a <fwp_write+0xeea>
    928f:	4d 85 ed             	test   %r13,%r13
    9292:	79 53                	jns    92e7 <fwp_write+0xf87>
    9294:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9299:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    929e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    92a3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    92a8:	48 99                	cqto
    92aa:	48 f7 d8             	neg    %rax
    92ad:	48 83 d2 00          	adc    $0x0,%rdx
    92b1:	48 89 c6             	mov    %rax,%rsi
    92b4:	48 f7 da             	neg    %rdx
    92b7:	e8 84 a7 ff ff       	call   3a40 <fwp_fmt_u128>
    92bc:	49 89 e8             	mov    %rbp,%r8
    92bf:	ba 00 02 00 00       	mov    $0x200,%edx
    92c4:	be 02 00 00 00       	mov    $0x2,%esi
    92c9:	31 c0                	xor    %eax,%eax
    92cb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    92d2:	00 
    92d3:	48 8d 0d 36 2f 00 00 	lea    0x2f36(%rip),%rcx        # c210 <_IO_stdin_used+0x210>
    92da:	4c 89 e7             	mov    %r12,%rdi
    92dd:	e8 fe a3 ff ff       	call   36e0 <__sprintf_chk@plt>
    92e2:	e9 f9 f0 ff ff       	jmp    83e0 <fwp_write+0x80>
    92e7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    92ec:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    92f1:	31 d2                	xor    %edx,%edx
    92f3:	48 89 ef             	mov    %rbp,%rdi
    92f6:	e8 45 a7 ff ff       	call   3a40 <fwp_fmt_u128>
    92fb:	eb bf                	jmp    92bc <fwp_write+0xf5c>
    92fd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9304:	4e 61 4e 00 
    9308:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    930f:	00 
    9310:	e9 cb f0 ff ff       	jmp    83e0 <fwp_write+0x80>
    9315:	44 89 0c 24          	mov    %r9d,(%rsp)
    9319:	48 89 c8             	mov    %rcx,%rax
    931c:	48 85 d2             	test   %rdx,%rdx
    931f:	78 51                	js     9372 <fwp_write+0x1012>
    9321:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9326:	48 89 c6             	mov    %rax,%rsi
    9329:	48 89 ef             	mov    %rbp,%rdi
    932c:	e8 0f a7 ff ff       	call   3a40 <fwp_fmt_u128>
    9331:	44 8b 0c 24          	mov    (%rsp),%r9d
    9335:	49 63 c1             	movslq %r9d,%rax
    9338:	49 89 e8             	mov    %rbp,%r8
    933b:	ba 00 02 00 00       	mov    $0x200,%edx
    9340:	be 02 00 00 00       	mov    $0x2,%esi
    9345:	48 c1 e0 04          	shl    $0x4,%rax
    9349:	48 8d 3d 50 4f 00 00 	lea    0x4f50(%rip),%rdi        # e2a0 <units.0>
    9350:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9357:	00 
    9358:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    935c:	48 8d 0d a8 2e 00 00 	lea    0x2ea8(%rip),%rcx        # c20b <_IO_stdin_used+0x20b>
    9363:	4c 89 e7             	mov    %r12,%rdi
    9366:	31 c0                	xor    %eax,%eax
    9368:	e8 73 a3 ff ff       	call   36e0 <__sprintf_chk@plt>
    936d:	e9 6e f0 ff ff       	jmp    83e0 <fwp_write+0x80>
    9372:	48 f7 d8             	neg    %rax
    9375:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    937a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    937f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9384:	48 83 d2 00          	adc    $0x0,%rdx
    9388:	48 89 c6             	mov    %rax,%rsi
    938b:	48 f7 da             	neg    %rdx
    938e:	e8 ad a6 ff ff       	call   3a40 <fwp_fmt_u128>
    9393:	44 8b 0c 24          	mov    (%rsp),%r9d
    9397:	eb 9c                	jmp    9335 <fwp_write+0xfd5>
    9399:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000093a0 <fwp_main_thread>:
    93a0:	f3 0f 1e fa          	endbr64
    93a4:	41 57                	push   %r15
    93a6:	41 56                	push   %r14
    93a8:	41 55                	push   %r13
    93aa:	41 54                	push   %r12
    93ac:	55                   	push   %rbp
    93ad:	53                   	push   %rbx
    93ae:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    93b5:	44 8b 15 a8 87 01 00 	mov    0x187a8(%rip),%r10d        # 21b64 <fwp_heap+0x13a4>
    93bc:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    93c3:	00 00 
    93c5:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    93cc:	00 
    93cd:	31 c0                	xor    %eax,%eax
    93cf:	45 85 d2             	test   %r10d,%r10d
    93d2:	0f 84 5a 13 00 00    	je     a732 <fwp_main_thread+0x1392>
    93d8:	44 8b 0d 89 87 01 00 	mov    0x18789(%rip),%r9d        # 21b68 <fwp_heap+0x13a8>
    93df:	45 85 c9             	test   %r9d,%r9d
    93e2:	0f 85 39 13 00 00    	jne    a721 <fwp_main_thread+0x1381>
    93e8:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    93ef:	00 
    93f0:	31 f6                	xor    %esi,%esi
    93f2:	48 c7 05 53 6d 01 00 	movq   $0x40000000,0x16d53(%rip)        # 20150 <fwp_main_stack_size>
    93f9:	00 00 00 40 
    93fd:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    9402:	48 89 05 4f 6d 01 00 	mov    %rax,0x16d4f(%rip)        # 20158 <fwp_main_stack_top>
    9409:	48 8d 05 70 6c 00 00 	lea    0x6c70(%rip),%rax        # 10080 <alt.5>
    9410:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9417:	00 
    9418:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    941f:	00 
    9420:	48 89 c7             	mov    %rax,%rdi
    9423:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9428:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    942f:	00 00 00 01 00 
    9434:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    943b:	00 00 00 00 
    943f:	e8 7c a2 ff ff       	call   36c0 <sigaltstack@plt>
    9444:	85 c0                	test   %eax,%eax
    9446:	0f 85 6c 21 00 00    	jne    b5b8 <fwp_main_thread+0x2218>
    944c:	31 c0                	xor    %eax,%eax
    944e:	b9 12 00 00 00       	mov    $0x12,%ecx
    9453:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    945a:	00 
    945b:	f3 48 ab             	rep stos %rax,(%rdi)
    945e:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    9465:	00 
    9466:	48 8d 05 83 a8 ff ff 	lea    -0x577d(%rip),%rax        # 3cf0 <fwp_segv>
    946d:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    9474:	04 00 00 08 
    9478:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    947f:	00 
    9480:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
    9485:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    948c:	00 
    948d:	e8 ee a0 ff ff       	call   3580 <sigemptyset@plt>
    9492:	85 c0                	test   %eax,%eax
    9494:	0f 85 1e 21 00 00    	jne    b5b8 <fwp_main_thread+0x2218>
    949a:	31 d2                	xor    %edx,%edx
    949c:	48 89 de             	mov    %rbx,%rsi
    949f:	bf 0b 00 00 00       	mov    $0xb,%edi
    94a4:	e8 57 9f ff ff       	call   3400 <sigaction@plt>
    94a9:	85 c0                	test   %eax,%eax
    94ab:	0f 85 07 21 00 00    	jne    b5b8 <fwp_main_thread+0x2218>
    94b1:	31 d2                	xor    %edx,%edx
    94b3:	48 89 de             	mov    %rbx,%rsi
    94b6:	bf 07 00 00 00       	mov    $0x7,%edi
    94bb:	e8 40 9f ff ff       	call   3400 <sigaction@plt>
    94c0:	85 c0                	test   %eax,%eax
    94c2:	0f 85 f0 20 00 00    	jne    b5b8 <fwp_main_thread+0x2218>
    94c8:	44 8b 05 29 6c 01 00 	mov    0x16c29(%rip),%r8d        # 200f8 <descent_registered>
    94cf:	45 85 c0             	test   %r8d,%r8d
    94d2:	0f 84 08 05 00 00    	je     99e0 <fwp_main_thread+0x640>
    94d8:	8b 3d 92 6b 00 00    	mov    0x6b92(%rip),%edi        # 10070 <st.3>
    94de:	85 ff                	test   %edi,%edi
    94e0:	0f 84 26 05 00 00    	je     9a0c <fwp_main_thread+0x66c>
    94e6:	48 8b 2d b3 72 01 00 	mov    0x172b3(%rip),%rbp        # 207a0 <fwp_cur>
    94ed:	48 85 ed             	test   %rbp,%rbp
    94f0:	0f 84 c9 01 00 00    	je     96bf <fwp_main_thread+0x31f>
    94f6:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    94fb:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    94ff:	48 89 eb             	mov    %rbp,%rbx
    9502:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9507:	0f 84 41 01 00 00    	je     964e <fwp_main_thread+0x2ae>
    950d:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9512:	0f 84 e8 03 00 00    	je     9900 <fwp_main_thread+0x560>
    9518:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    951c:	0f 84 b6 03 00 00    	je     98d8 <fwp_main_thread+0x538>
    9522:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9526:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    952a:	0f 85 50 04 00 00    	jne    9980 <fwp_main_thread+0x5e0>
    9530:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9534:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    953b:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    953f:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9546:	00 00 00 00 
    954a:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9551:	48 85 d2             	test   %rdx,%rdx
    9554:	74 07                	je     955d <fwp_main_thread+0x1bd>
    9556:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    955d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9561:	48 85 c0             	test   %rax,%rax
    9564:	74 34                	je     959a <fwp_main_thread+0x1fa>
    9566:	48 89 43 68          	mov    %rax,0x68(%rbx)
    956a:	48 8b 05 07 72 01 00 	mov    0x17207(%rip),%rax        # 20778 <fwp_timers>
    9571:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9575:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    957c:	00 00 00 00 
    9580:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9587:	48 85 c0             	test   %rax,%rax
    958a:	74 07                	je     9593 <fwp_main_thread+0x1f3>
    958c:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9593:	48 89 1d de 71 01 00 	mov    %rbx,0x171de(%rip)        # 20778 <fwp_timers>
    959a:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    959e:	e8 4d de ff ff       	call   73f0 <fwp_block>
    95a3:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    95aa:	48 85 c9             	test   %rcx,%rcx
    95ad:	74 47                	je     95f6 <fwp_main_thread+0x256>
    95af:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    95b6:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    95bd:	48 85 d2             	test   %rdx,%rdx
    95c0:	0f 84 fa 03 00 00    	je     99c0 <fwp_main_thread+0x620>
    95c6:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    95cd:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    95d4:	48 85 c0             	test   %rax,%rax
    95d7:	74 07                	je     95e0 <fwp_main_thread+0x240>
    95d9:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    95e0:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    95e7:	00 00 00 00 
    95eb:	66 0f ef ff          	pxor   %xmm7,%xmm7
    95ef:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    95f6:	48 8b 0d a3 71 01 00 	mov    0x171a3(%rip),%rcx        # 207a0 <fwp_cur>
    95fd:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9601:	0f 84 69 03 00 00    	je     9970 <fwp_main_thread+0x5d0>
    9607:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    960e:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9615:	48 85 d2             	test   %rdx,%rdx
    9618:	0f 84 b2 03 00 00    	je     99d0 <fwp_main_thread+0x630>
    961e:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9625:	48 85 c0             	test   %rax,%rax
    9628:	74 07                	je     9631 <fwp_main_thread+0x291>
    962a:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9631:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9635:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9639:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9640:	48 89 cb             	mov    %rcx,%rbx
    9643:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9648:	0f 85 bf fe ff ff    	jne    950d <fwp_main_thread+0x16d>
    964e:	48 83 3d e2 8d 01 00 	cmpq   $0x0,0x18de2(%rip)        # 22438 <fwp_state_len>
    9655:	00 
    9656:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    965a:	75 0e                	jne    966a <fwp_main_thread+0x2ca>
    965c:	48 83 3d c4 8d 01 00 	cmpq   $0x0,0x18dc4(%rip)        # 22428 <fwp_state_owners>
    9663:	00 
    9664:	0f 84 ac 1d 00 00    	je     b416 <fwp_main_thread+0x2076>
    966a:	48 39 1d 27 71 01 00 	cmp    %rbx,0x17127(%rip)        # 20798 <fwp_root>
    9671:	c7 05 05 6a 01 00 00 	movl   $0x0,0x16a05(%rip)        # 20080 <fwp_exit_code>
    9678:	00 00 00 
    967b:	0f 85 78 1f 00 00    	jne    b5f9 <fwp_main_thread+0x2259>
    9681:	48 85 db             	test   %rbx,%rbx
    9684:	74 5f                	je     96e5 <fwp_main_thread+0x345>
    9686:	48 8b 15 db 70 01 00 	mov    0x170db(%rip),%rdx        # 20768 <fwp_tasks_active>
    968d:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9691:	48 85 d2             	test   %rdx,%rdx
    9694:	74 4f                	je     96e5 <fwp_main_thread+0x345>
    9696:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    969d:	00 00 00 
    96a0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    96a4:	75 08                	jne    96ae <fwp_main_thread+0x30e>
    96a6:	48 89 d7             	mov    %rdx,%rdi
    96a9:	e8 52 ac ff ff       	call   4300 <fwp_cancel_tree.part.0>
    96ae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    96b5:	48 85 d2             	test   %rdx,%rdx
    96b8:	75 e6                	jne    96a0 <fwp_main_thread+0x300>
    96ba:	e9 e6 01 00 00       	jmp    98a5 <fwp_main_thread+0x505>
    96bf:	48 83 3d 71 8d 01 00 	cmpq   $0x0,0x18d71(%rip)        # 22438 <fwp_state_len>
    96c6:	00 
    96c7:	0f 84 2a 1c 00 00    	je     b2f7 <fwp_main_thread+0x1f57>
    96cd:	48 83 3d c3 70 01 00 	cmpq   $0x0,0x170c3(%rip)        # 20798 <fwp_root>
    96d4:	00 
    96d5:	c7 05 a1 69 01 00 00 	movl   $0x0,0x169a1(%rip)        # 20080 <fwp_exit_code>
    96dc:	00 00 00 
    96df:	0f 85 19 1f 00 00    	jne    b5fe <fwp_main_thread+0x225e>
    96e5:	e8 f6 da ff ff       	call   71e0 <fwp_free_zombie>
    96ea:	48 83 3d 96 70 01 00 	cmpq   $0x0,0x17096(%rip)        # 20788 <fwp_ready_head>
    96f1:	00 
    96f2:	0f 85 53 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    96f8:	48 83 3d 78 70 01 00 	cmpq   $0x0,0x17078(%rip)        # 20778 <fwp_timers>
    96ff:	00 
    9700:	0f 85 45 a0 ff ff    	jne    374b <fwp_main_thread.cold>
    9706:	8b 05 58 6a 01 00    	mov    0x16a58(%rip),%eax        # 20164 <fwp_stack_pool_n>
    970c:	85 c0                	test   %eax,%eax
    970e:	74 3d                	je     974d <fwp_main_thread+0x3ad>
    9710:	83 e8 01             	sub    $0x1,%eax
    9713:	4c 8d 25 66 6a 01 00 	lea    0x16a66(%rip),%r12        # 20180 <fwp_stack_pool>
    971a:	48 63 d8             	movslq %eax,%rbx
    971d:	89 c0                	mov    %eax,%eax
    971f:	48 89 da             	mov    %rbx,%rdx
    9722:	48 29 c2             	sub    %rax,%rdx
    9725:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9729:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9730:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9734:	89 1d 2a 6a 01 00    	mov    %ebx,0x16a2a(%rip)        # 20164 <fwp_stack_pool_n>
    973a:	be 00 00 00 10       	mov    $0x10000000,%esi
    973f:	48 83 eb 01          	sub    $0x1,%rbx
    9743:	e8 98 9e ff ff       	call   35e0 <munmap@plt>
    9748:	48 39 eb             	cmp    %rbp,%rbx
    974b:	75 e3                	jne    9730 <fwp_main_thread+0x390>
    974d:	8b 3d c9 68 00 00    	mov    0x68c9(%rip),%edi        # 1001c <fwp_epfd>
    9753:	85 ff                	test   %edi,%edi
    9755:	78 05                	js     975c <fwp_main_thread+0x3bc>
    9757:	e8 74 9d ff ff       	call   34d0 <close@plt>
    975c:	4c 8b 25 1d 6c 01 00 	mov    0x16c1d(%rip),%r12        # 20380 <fwp_nfdws>
    9763:	48 8b 2d 1e 6c 01 00 	mov    0x16c1e(%rip),%rbp        # 20388 <fwp_fdws>
    976a:	31 db                	xor    %ebx,%ebx
    976c:	c7 05 a6 68 00 00 ff 	movl   $0xffffffff,0x68a6(%rip)        # 1001c <fwp_epfd>
    9773:	ff ff ff 
    9776:	4d 85 e4             	test   %r12,%r12
    9779:	74 32                	je     97ad <fwp_main_thread+0x40d>
    977b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9780:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9785:	48 85 ff             	test   %rdi,%rdi
    9788:	74 1a                	je     97a4 <fwp_main_thread+0x404>
    978a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    978e:	0f 85 b7 9f ff ff    	jne    374b <fwp_main_thread.cold>
    9794:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9799:	0f 85 ac 9f ff ff    	jne    374b <fwp_main_thread.cold>
    979f:	e8 ec bf ff ff       	call   5790 <fwp_mem_free>
    97a4:	48 83 c3 01          	add    $0x1,%rbx
    97a8:	4c 39 e3             	cmp    %r12,%rbx
    97ab:	75 d3                	jne    9780 <fwp_main_thread+0x3e0>
    97ad:	48 89 ef             	mov    %rbp,%rdi
    97b0:	e8 db bf ff ff       	call   5790 <fwp_mem_free>
    97b5:	48 8b 15 dc 6f 01 00 	mov    0x16fdc(%rip),%rdx        # 20798 <fwp_root>
    97bc:	48 c7 05 c1 6b 01 00 	movq   $0x0,0x16bc1(%rip)        # 20388 <fwp_fdws>
    97c3:	00 00 00 00 
    97c7:	48 c7 05 ae 6b 01 00 	movq   $0x0,0x16bae(%rip)        # 20380 <fwp_nfdws>
    97ce:	00 00 00 00 
    97d2:	48 85 d2             	test   %rdx,%rdx
    97d5:	74 4e                	je     9825 <fwp_main_thread+0x485>
    97d7:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    97dc:	0f 85 69 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97e2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    97e9:	00 
    97ea:	0f 85 5b 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97f0:	48 83 3d 40 8c 01 00 	cmpq   $0x0,0x18c40(%rip)        # 22438 <fwp_state_len>
    97f7:	00 
    97f8:	0f 85 4d 9f ff ff    	jne    374b <fwp_main_thread.cold>
    97fe:	48 83 3d 22 8c 01 00 	cmpq   $0x0,0x18c22(%rip)        # 22428 <fwp_state_owners>
    9805:	00 
    9806:	0f 85 3f 9f ff ff    	jne    374b <fwp_main_thread.cold>
    980c:	b9 79 00 00 00       	mov    $0x79,%ecx
    9811:	31 c0                	xor    %eax,%eax
    9813:	48 8d 3d 86 6b 01 00 	lea    0x16b86(%rip),%rdi        # 203a0 <fwp_root_context>
    981a:	f3 48 ab             	rep stos %rax,(%rdi)
    981d:	48 89 d7             	mov    %rdx,%rdi
    9820:	e8 6b bf ff ff       	call   5790 <fwp_mem_free>
    9825:	48 8b 3d f4 67 00 00 	mov    0x67f4(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    982c:	48 c7 05 69 6f 01 00 	movq   $0x0,0x16f69(%rip)        # 207a0 <fwp_cur>
    9833:	00 00 00 00 
    9837:	48 c7 05 56 6f 01 00 	movq   $0x0,0x16f56(%rip)        # 20798 <fwp_root>
    983e:	00 00 00 00 
    9842:	e8 79 9d ff ff       	call   35c0 <fflush@plt>
    9847:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    984e:	00 
    984f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9856:	00 00 
    9858:	0f 85 66 1d 00 00    	jne    b5c4 <fwp_main_thread+0x2224>
    985e:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    9865:	31 c0                	xor    %eax,%eax
    9867:	5b                   	pop    %rbx
    9868:	5d                   	pop    %rbp
    9869:	41 5c                	pop    %r12
    986b:	41 5d                	pop    %r13
    986d:	41 5e                	pop    %r14
    986f:	41 5f                	pop    %r15
    9871:	c3                   	ret
    9872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9878:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    987f:	48 89 1d fa 6e 01 00 	mov    %rbx,0x16efa(%rip)        # 20780 <fwp_ready_tail>
    9886:	e8 65 db ff ff       	call   73f0 <fwp_block>
    988b:	e8 50 d9 ff ff       	call   71e0 <fwp_free_zombie>
    9890:	48 83 3d d0 6e 01 00 	cmpq   $0x0,0x16ed0(%rip)        # 20768 <fwp_tasks_active>
    9897:	00 
    9898:	0f 84 47 fe ff ff    	je     96e5 <fwp_main_thread+0x345>
    989e:	48 8b 1d f3 6e 01 00 	mov    0x16ef3(%rip),%rbx        # 20798 <fwp_root>
    98a5:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    98a9:	75 db                	jne    9886 <fwp_main_thread+0x4e6>
    98ab:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    98af:	75 d5                	jne    9886 <fwp_main_thread+0x4e6>
    98b1:	48 8b 05 c8 6e 01 00 	mov    0x16ec8(%rip),%rax        # 20780 <fwp_ready_tail>
    98b8:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    98bc:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    98c3:	00 00 00 00 
    98c7:	48 85 c0             	test   %rax,%rax
    98ca:	75 ac                	jne    9878 <fwp_main_thread+0x4d8>
    98cc:	48 89 1d b5 6e 01 00 	mov    %rbx,0x16eb5(%rip)        # 20788 <fwp_ready_head>
    98d3:	eb aa                	jmp    987f <fwp_main_thread+0x4df>
    98d5:	0f 1f 00             	nopl   (%rax)
    98d8:	e8 83 ac ff ff       	call   4560 <fwp_now_ns>
    98dd:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    98e1:	7c 1d                	jl     9900 <fwp_main_thread+0x560>
    98e3:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    98e7:	75 17                	jne    9900 <fwp_main_thread+0x560>
    98e9:	48 89 ef             	mov    %rbp,%rdi
    98ec:	e8 0f aa ff ff       	call   4300 <fwp_cancel_tree.part.0>
    98f1:	0f 1f 40 00          	nopl   0x0(%rax)
    98f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    98fc:	00 00 00 00 
    9900:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9904:	0f 85 18 fc ff ff    	jne    9522 <fwp_main_thread+0x182>
    990a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    990e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9912:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9916:	0f 85 18 fc ff ff    	jne    9534 <fwp_main_thread+0x194>
    991c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9920:	48 85 c9             	test   %rcx,%rcx
    9923:	0f 84 0b fc ff ff    	je     9534 <fwp_main_thread+0x194>
    9929:	48 39 c8             	cmp    %rcx,%rax
    992c:	48 89 ce             	mov    %rcx,%rsi
    992f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9936:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    993a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9941:	00 00 00 00 
    9945:	48 0f 4e f0          	cmovle %rax,%rsi
    9949:	48 85 c0             	test   %rax,%rax
    994c:	48 89 c8             	mov    %rcx,%rax
    994f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9956:	48 0f 45 c6          	cmovne %rsi,%rax
    995a:	48 85 d2             	test   %rdx,%rdx
    995d:	74 07                	je     9966 <fwp_main_thread+0x5c6>
    995f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9966:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    996a:	e9 f7 fb ff ff       	jmp    9566 <fwp_main_thread+0x1c6>
    996f:	90                   	nop
    9970:	48 89 cb             	mov    %rcx,%rbx
    9973:	e9 8a fb ff ff       	jmp    9502 <fwp_main_thread+0x162>
    9978:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    997f:	00 
    9980:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9984:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    998b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9992:	00 00 00 00 
    9996:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    999d:	48 85 c0             	test   %rax,%rax
    99a0:	0f 84 3a 19 00 00    	je     b2e0 <fwp_main_thread+0x1f40>
    99a6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    99ad:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    99b1:	e9 e4 fb ff ff       	jmp    959a <fwp_main_thread+0x1fa>
    99b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    99bd:	00 00 00 
    99c0:	48 89 01             	mov    %rax,(%rcx)
    99c3:	e9 0c fc ff ff       	jmp    95d4 <fwp_main_thread+0x234>
    99c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    99cf:	00 
    99d0:	48 89 05 a1 6d 01 00 	mov    %rax,0x16da1(%rip)        # 20778 <fwp_timers>
    99d7:	e9 49 fc ff ff       	jmp    9625 <fwp_main_thread+0x285>
    99dc:	0f 1f 40 00          	nopl   0x0(%rax)
    99e0:	48 8d 3d 29 a4 ff ff 	lea    -0x5bd7(%rip),%rdi        # 3e10 <descent_phase_report>
    99e7:	e8 34 1e 00 00       	call   b820 <atexit>
    99ec:	85 c0                	test   %eax,%eax
    99ee:	0f 85 f4 1b 00 00    	jne    b5e8 <fwp_main_thread+0x2248>
    99f4:	c7 05 fa 66 01 00 01 	movl   $0x1,0x166fa(%rip)        # 200f8 <descent_registered>
    99fb:	00 00 00 
    99fe:	8b 3d 6c 66 00 00    	mov    0x666c(%rip),%edi        # 10070 <st.3>
    9a04:	85 ff                	test   %edi,%edi
    9a06:	0f 85 da fa ff ff    	jne    94e6 <fwp_main_thread+0x146>
    9a0c:	48 8d 05 fd df ff ff 	lea    -0x2003(%rip),%rax        # 7a10 <fwp_drop1>
    9a13:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9a17:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
    9a1c:	45 31 f6             	xor    %r14d,%r14d
    9a1f:	66 48 0f 6e f0       	movq   %rax,%xmm6
    9a24:	48 8b 05 2d 8a 01 00 	mov    0x18a2d(%rip),%rax        # 22458 <fwp_cleanups>
    9a2b:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    9a32:	00 00 00 00 00 
    9a37:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    9a3c:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    9a40:	48 8d 2d 79 6d 01 00 	lea    0x16d79(%rip),%rbp        # 207c0 <fwp_heap>
    9a47:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9a4e:	00 
    9a4f:	48 8d 05 7a a1 ff ff 	lea    -0x5e86(%rip),%rax        # 3bd0 <fwp_range_release>
    9a56:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    9a5d:	00 
    9a5e:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9a63:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    9a6a:	00 
    9a6b:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    9a72:	00 
    9a73:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    9a78:	48 89 05 d9 89 01 00 	mov    %rax,0x189d9(%rip)        # 22458 <fwp_cleanups>
    9a7f:	eb 47                	jmp    9ac8 <fwp_main_thread+0x728>
    9a81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9a88:	80 f9 01             	cmp    $0x1,%cl
    9a8b:	75 29                	jne    9ab6 <fwp_main_thread+0x716>
    9a8d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9a90:	0f b7 c0             	movzwl %ax,%eax
    9a93:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a96:	48 0f af c1          	imul   %rcx,%rax
    9a9a:	48 c1 e8 20          	shr    $0x20,%rax
    9a9e:	48 39 d0             	cmp    %rdx,%rax
    9aa1:	73 13                	jae    9ab6 <fwp_main_thread+0x716>
    9aa3:	49 01 c5             	add    %rax,%r13
    9aa6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9aab:	0f 84 a8 18 00 00    	je     b359 <fwp_main_thread+0x1fb9>
    9ab1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9ab6:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9abd:	00 
    9abe:	48 83 eb 01          	sub    $0x1,%rbx
    9ac2:	0f 82 85 00 00 00    	jb     9b4d <fwp_main_thread+0x7ad>
    9ac8:	4c 89 e6             	mov    %r12,%rsi
    9acb:	bf 01 00 00 00       	mov    $0x1,%edi
    9ad0:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    9ad7:	00 
    9ad8:	48 89 9c 24 d8 00 00 	mov    %rbx,0xd8(%rsp)
    9adf:	00 
    9ae0:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
    9ae7:	00 
    9ae8:	e8 c3 c2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9aed:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9af4:	49 89 c6             	mov    %rax,%r14
    9af7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9afe:	48 c1 e2 10          	shl    $0x10,%rdx
    9b02:	48 39 d0             	cmp    %rdx,%rax
    9b05:	73 af                	jae    9ab6 <fwp_main_thread+0x716>
    9b07:	48 89 c2             	mov    %rax,%rdx
    9b0a:	48 c1 ea 10          	shr    $0x10,%rdx
    9b0e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9b12:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9b19:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9b1d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9b21:	4d 85 ed             	test   %r13,%r13
    9b24:	74 90                	je     9ab6 <fwp_main_thread+0x716>
    9b26:	0f b6 0a             	movzbl (%rdx),%ecx
    9b29:	80 f9 02             	cmp    $0x2,%cl
    9b2c:	0f 85 56 ff ff ff    	jne    9a88 <fwp_main_thread+0x6e8>
    9b32:	66 85 c0             	test   %ax,%ax
    9b35:	0f 84 6b ff ff ff    	je     9aa6 <fwp_main_thread+0x706>
    9b3b:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    9b42:	00 
    9b43:	48 83 eb 01          	sub    $0x1,%rbx
    9b47:	0f 83 7b ff ff ff    	jae    9ac8 <fwp_main_thread+0x728>
    9b4d:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    9b54:	00 
    9b55:	66 0f 6f 05 e3 30 00 	movdqa 0x30e3(%rip),%xmm0        # cc40 <msg.4+0xd0>
    9b5c:	00 
    9b5d:	bf 01 00 00 00       	mov    $0x1,%edi
    9b62:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9b69:	00 
    9b6a:	48 89 1d e7 88 01 00 	mov    %rbx,0x188e7(%rip)        # 22458 <fwp_cleanups>
    9b71:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    9b78:	00 
    9b79:	e8 32 c2 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9b7e:	48 8b 15 13 80 01 00 	mov    0x18013(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9b85:	49 89 c5             	mov    %rax,%r13
    9b88:	48 2b 05 e1 7f 01 00 	sub    0x17fe1(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9b8f:	48 c1 e2 10          	shl    $0x10,%rdx
    9b93:	48 39 d0             	cmp    %rdx,%rax
    9b96:	73 59                	jae    9bf1 <fwp_main_thread+0x851>
    9b98:	48 89 c2             	mov    %rax,%rdx
    9b9b:	48 c1 ea 10          	shr    $0x10,%rdx
    9b9f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ba3:	48 8b 15 0e 80 01 00 	mov    0x1800e(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9baa:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bae:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9bb2:	4d 85 e4             	test   %r12,%r12
    9bb5:	74 3a                	je     9bf1 <fwp_main_thread+0x851>
    9bb7:	0f b6 0a             	movzbl (%rdx),%ecx
    9bba:	80 f9 02             	cmp    $0x2,%cl
    9bbd:	0f 84 6c 17 00 00    	je     b32f <fwp_main_thread+0x1f8f>
    9bc3:	80 f9 01             	cmp    $0x1,%cl
    9bc6:	75 29                	jne    9bf1 <fwp_main_thread+0x851>
    9bc8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9bcb:	0f b7 c0             	movzwl %ax,%eax
    9bce:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bd1:	48 0f af c1          	imul   %rcx,%rax
    9bd5:	48 c1 e8 20          	shr    $0x20,%rax
    9bd9:	48 39 d0             	cmp    %rdx,%rax
    9bdc:	73 13                	jae    9bf1 <fwp_main_thread+0x851>
    9bde:	49 01 c4             	add    %rax,%r12
    9be1:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9be6:	0f 84 64 19 00 00    	je     b550 <fwp_main_thread+0x21b0>
    9bec:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9bf1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9bf8:	00 f0 3f 
    9bfb:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9c02:	00 
    9c03:	bf 01 00 00 00       	mov    $0x1,%edi
    9c08:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9c0f:	00 
    9c10:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9c17:	00 
    9c18:	e8 93 c1 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9c1d:	48 8b 15 74 7f 01 00 	mov    0x17f74(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9c24:	49 89 c5             	mov    %rax,%r13
    9c27:	48 2b 05 42 7f 01 00 	sub    0x17f42(%rip),%rax        # 21b70 <fwp_heap+0x13b0>
    9c2e:	48 c1 e2 10          	shl    $0x10,%rdx
    9c32:	48 39 d0             	cmp    %rdx,%rax
    9c35:	73 59                	jae    9c90 <fwp_main_thread+0x8f0>
    9c37:	48 89 c2             	mov    %rax,%rdx
    9c3a:	48 c1 ea 10          	shr    $0x10,%rdx
    9c3e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c42:	48 8b 15 6f 7f 01 00 	mov    0x17f6f(%rip),%rdx        # 21bb8 <fwp_heap+0x13f8>
    9c49:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c4d:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9c51:	4d 85 e4             	test   %r12,%r12
    9c54:	74 3a                	je     9c90 <fwp_main_thread+0x8f0>
    9c56:	0f b6 0a             	movzbl (%rdx),%ecx
    9c59:	80 f9 02             	cmp    $0x2,%cl
    9c5c:	0f 84 e9 16 00 00    	je     b34b <fwp_main_thread+0x1fab>
    9c62:	80 f9 01             	cmp    $0x1,%cl
    9c65:	75 29                	jne    9c90 <fwp_main_thread+0x8f0>
    9c67:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c6a:	0f b7 c0             	movzwl %ax,%eax
    9c6d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c70:	48 0f af c1          	imul   %rcx,%rax
    9c74:	48 c1 e8 20          	shr    $0x20,%rax
    9c78:	48 39 d0             	cmp    %rdx,%rax
    9c7b:	73 13                	jae    9c90 <fwp_main_thread+0x8f0>
    9c7d:	49 01 c4             	add    %rax,%r12
    9c80:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9c85:	0f 84 d2 18 00 00    	je     b55d <fwp_main_thread+0x21bd>
    9c8b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9c90:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9c97:	33 f3 bf 
    9c9a:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    9ca1:	00 
    9ca2:	bf 01 00 00 00       	mov    $0x1,%edi
    9ca7:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    9cae:	00 
    9caf:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    9cb6:	00 
    9cb7:	e8 f4 c0 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    9cbc:	48 8b 15 d5 7e 01 00 	mov    0x17ed5(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9cc3:	48 8b 0d a6 7e 01 00 	mov    0x17ea6(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    9cca:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9ccf:	48 89 d6             	mov    %rdx,%rsi
    9cd2:	48 29 c8             	sub    %rcx,%rax
    9cd5:	48 c1 e6 10          	shl    $0x10,%rsi
    9cd9:	48 39 f0             	cmp    %rsi,%rax
    9cdc:	73 69                	jae    9d47 <fwp_main_thread+0x9a7>
    9cde:	48 89 c6             	mov    %rax,%rsi
    9ce1:	48 c1 ee 10          	shr    $0x10,%rsi
    9ce5:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9ce9:	48 8b 35 c8 7e 01 00 	mov    0x17ec8(%rip),%rsi        # 21bb8 <fwp_heap+0x13f8>
    9cf0:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9cf4:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    9cf8:	4d 85 e4             	test   %r12,%r12
    9cfb:	74 4a                	je     9d47 <fwp_main_thread+0x9a7>
    9cfd:	0f b6 3e             	movzbl (%rsi),%edi
    9d00:	40 80 ff 02          	cmp    $0x2,%dil
    9d04:	0f 84 33 16 00 00    	je     b33d <fwp_main_thread+0x1f9d>
    9d0a:	40 80 ff 01          	cmp    $0x1,%dil
    9d0e:	75 37                	jne    9d47 <fwp_main_thread+0x9a7>
    9d10:	8b 7e 18             	mov    0x18(%rsi),%edi
    9d13:	0f b7 c0             	movzwl %ax,%eax
    9d16:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9d19:	48 0f af c7          	imul   %rdi,%rax
    9d1d:	48 c1 e8 20          	shr    $0x20,%rax
    9d21:	48 39 f0             	cmp    %rsi,%rax
    9d24:	73 21                	jae    9d47 <fwp_main_thread+0x9a7>
    9d26:	49 01 c4             	add    %rax,%r12
    9d29:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9d2e:	0f 84 36 18 00 00    	je     b56a <fwp_main_thread+0x21ca>
    9d34:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9d39:	48 8b 0d 30 7e 01 00 	mov    0x17e30(%rip),%rcx        # 21b70 <fwp_heap+0x13b0>
    9d40:	48 8b 15 51 7e 01 00 	mov    0x17e51(%rip),%rdx        # 21b98 <fwp_heap+0x13d8>
    9d47:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    9d4e:	00 
    9d4f:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
    9d54:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    9d59:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    9d60:	00 
    9d61:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    9d66:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    9d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9d70:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d75:	48 c1 e2 10          	shl    $0x10,%rdx
    9d79:	48 29 c8             	sub    %rcx,%rax
    9d7c:	48 39 d0             	cmp    %rdx,%rax
    9d7f:	73 73                	jae    9df4 <fwp_main_thread+0xa54>
    9d81:	48 89 c6             	mov    %rax,%rsi
    9d84:	48 c1 ee 10          	shr    $0x10,%rsi
    9d88:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9d8c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    9d93:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9d97:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9d9b:	48 85 ff             	test   %rdi,%rdi
    9d9e:	74 54                	je     9df4 <fwp_main_thread+0xa54>
    9da0:	44 0f b6 06          	movzbl (%rsi),%r8d
    9da4:	41 80 f8 02          	cmp    $0x2,%r8b
    9da8:	0f 84 aa 14 00 00    	je     b258 <fwp_main_thread+0x1eb8>
    9dae:	41 80 f8 01          	cmp    $0x1,%r8b
    9db2:	75 40                	jne    9df4 <fwp_main_thread+0xa54>
    9db4:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9db8:	0f b7 c0             	movzwl %ax,%eax
    9dbb:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9dbe:	49 0f af c0          	imul   %r8,%rax
    9dc2:	48 c1 e8 20          	shr    $0x20,%rax
    9dc6:	48 39 f0             	cmp    %rsi,%rax
    9dc9:	73 29                	jae    9df4 <fwp_main_thread+0xa54>
    9dcb:	48 01 c7             	add    %rax,%rdi
    9dce:	0f b6 07             	movzbl (%rdi),%eax
    9dd1:	84 c0                	test   %al,%al
    9dd3:	74 1f                	je     9df4 <fwp_main_thread+0xa54>
    9dd5:	3c fd                	cmp    $0xfd,%al
    9dd7:	0f 87 21 17 00 00    	ja     b4fe <fwp_main_thread+0x215e>
    9ddd:	83 c0 01             	add    $0x1,%eax
    9de0:	88 07                	mov    %al,(%rdi)
    9de2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9de9:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    9df0:	48 c1 e2 10          	shl    $0x10,%rdx
    9df4:	48 8d 05 e5 ce ff ff 	lea    -0x311b(%rip),%rax        # 6ce0 <fwp_tape_scope_release>
    9dfb:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    9e02:	00 
    9e03:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    9e0a:	00 
    9e0b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    9e10:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    9e17:	ff ff ff ff 
    9e1b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    9e22:	00 
    9e23:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    9e28:	48 89 05 29 86 01 00 	mov    %rax,0x18629(%rip)        # 22458 <fwp_cleanups>
    9e2f:	48 8d 05 da 61 00 00 	lea    0x61da(%rip),%rax        # 10010 <fc37>
    9e36:	48 29 c8             	sub    %rcx,%rax
    9e39:	48 39 d0             	cmp    %rdx,%rax
    9e3c:	73 5d                	jae    9e9b <fwp_main_thread+0xafb>
    9e3e:	48 89 c2             	mov    %rax,%rdx
    9e41:	48 c1 ea 10          	shr    $0x10,%rdx
    9e45:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9e49:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9e50:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9e54:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9e58:	48 85 ff             	test   %rdi,%rdi
    9e5b:	74 3e                	je     9e9b <fwp_main_thread+0xafb>
    9e5d:	0f b6 0a             	movzbl (%rdx),%ecx
    9e60:	80 f9 02             	cmp    $0x2,%cl
    9e63:	0f 84 67 12 00 00    	je     b0d0 <fwp_main_thread+0x1d30>
    9e69:	80 f9 01             	cmp    $0x1,%cl
    9e6c:	75 2d                	jne    9e9b <fwp_main_thread+0xafb>
    9e6e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9e71:	0f b7 c0             	movzwl %ax,%eax
    9e74:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9e77:	48 0f af c1          	imul   %rcx,%rax
    9e7b:	48 c1 e8 20          	shr    $0x20,%rax
    9e7f:	48 39 d0             	cmp    %rdx,%rax
    9e82:	73 17                	jae    9e9b <fwp_main_thread+0xafb>
    9e84:	48 01 c7             	add    %rax,%rdi
    9e87:	0f b6 07             	movzbl (%rdi),%eax
    9e8a:	84 c0                	test   %al,%al
    9e8c:	74 0d                	je     9e9b <fwp_main_thread+0xafb>
    9e8e:	3c fd                	cmp    $0xfd,%al
    9e90:	0f 87 46 15 00 00    	ja     b3dc <fwp_main_thread+0x203c>
    9e96:	83 c0 01             	add    $0x1,%eax
    9e99:	88 07                	mov    %al,(%rdi)
    9e9b:	48 8d 3d 6e 61 00 00 	lea    0x616e(%rip),%rdi        # 10010 <fc37>
    9ea2:	45 31 ed             	xor    %r13d,%r13d
    9ea5:	e8 06 cb ff ff       	call   69b0 <fwp_closure_drop>
    9eaa:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    9eaf:	90                   	nop
    9eb0:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    9eb5:	49 83 c5 01          	add    $0x1,%r13
    9eb9:	4d 85 e4             	test   %r12,%r12
    9ebc:	75 f2                	jne    9eb0 <fwp_main_thread+0xb10>
    9ebe:	31 ff                	xor    %edi,%edi
    9ec0:	e8 8b a3 ff ff       	call   4250 <descent_phase_step>
    9ec5:	49 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%r13
    9ecc:	0f 87 c2 16 00 00    	ja     b594 <fwp_main_thread+0x21f4>
    9ed2:	8b 35 88 61 00 00    	mov    0x6188(%rip),%esi        # 10060 <registered_finish.1>
    9ed8:	85 f6                	test   %esi,%esi
    9eda:	0f 84 c0 11 00 00    	je     b0a0 <fwp_main_thread+0x1d00>
    9ee0:	48 8b 15 f1 61 01 00 	mov    0x161f1(%rip),%rdx        # 200d8 <fwp_tape_next_slot>
    9ee7:	4c 8b 35 fa 61 01 00 	mov    0x161fa(%rip),%r14        # 200e8 <fwp_ntapes>
    9eee:	4c 39 f2             	cmp    %r14,%rdx
    9ef1:	0f 8d 29 10 00 00    	jge    af20 <fwp_main_thread+0x1b80>
    9ef7:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    9efb:	48 03 05 ee 61 01 00 	add    0x161ee(%rip),%rax        # 200f0 <fwp_tapes>
    9f02:	0f 1f 00             	nopl   (%rax)
    9f05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f0c:	00 00 00 00 
    9f10:	8b 48 04             	mov    0x4(%rax),%ecx
    9f13:	85 c9                	test   %ecx,%ecx
    9f15:	75 0c                	jne    9f23 <fwp_main_thread+0xb83>
    9f17:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9f1d:	0f 86 fd 0f 00 00    	jbe    af20 <fwp_main_thread+0x1b80>
    9f23:	48 83 c2 01          	add    $0x1,%rdx
    9f27:	48 83 c0 68          	add    $0x68,%rax
    9f2b:	4c 39 f2             	cmp    %r14,%rdx
    9f2e:	75 e0                	jne    9f10 <fwp_main_thread+0xb70>
    9f30:	49 81 fe fe ff 00 00 	cmp    $0xfffe,%r14
    9f37:	0f 8f 6f 16 00 00    	jg     b5ac <fwp_main_thread+0x220c>
    9f3d:	4c 3b 35 9c 61 01 00 	cmp    0x1619c(%rip),%r14        # 200e0 <fwp_tapes_cap>
    9f44:	4c 8b 3d a5 61 01 00 	mov    0x161a5(%rip),%r15        # 200f0 <fwp_tapes>
    9f4b:	75 3f                	jne    9f8c <fwp_main_thread+0xbec>
    9f4d:	4d 85 f6             	test   %r14,%r14
    9f50:	0f 84 6a 13 00 00    	je     b2c0 <fwp_main_thread+0x1f20>
    9f56:	4b 8d 1c 36          	lea    (%r14,%r14,1),%rbx
    9f5a:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9f5f:	48 39 c3             	cmp    %rax,%rbx
    9f62:	48 0f 4f d8          	cmovg  %rax,%rbx
    9f66:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    9f6a:	4c 89 ff             	mov    %r15,%rdi
    9f6d:	e8 5e 96 ff ff       	call   35d0 <realloc@plt>
    9f72:	49 89 c7             	mov    %rax,%r15
    9f75:	48 85 c0             	test   %rax,%rax
    9f78:	0f 84 95 11 00 00    	je     b113 <fwp_main_thread+0x1d73>
    9f7e:	48 89 05 6b 61 01 00 	mov    %rax,0x1616b(%rip)        # 200f0 <fwp_tapes>
    9f85:	48 89 1d 54 61 01 00 	mov    %rbx,0x16154(%rip)        # 200e0 <fwp_tapes_cap>
    9f8c:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9f90:	49 8d 5e 01          	lea    0x1(%r14),%rbx
    9f94:	4c 01 f8             	add    %r15,%rax
    9f97:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9f9b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9fa2:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9fa6:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    9fad:	00 
    9fae:	48 29 f8             	sub    %rdi,%rax
    9fb1:	8d 48 68             	lea    0x68(%rax),%ecx
    9fb4:	31 c0                	xor    %eax,%eax
    9fb6:	c1 e9 03             	shr    $0x3,%ecx
    9fb9:	f3 48 ab             	rep stos %rax,(%rdi)
    9fbc:	48 89 1d 25 61 01 00 	mov    %rbx,0x16125(%rip)        # 200e8 <fwp_ntapes>
    9fc3:	49 6b d6 68          	imul   $0x68,%r14,%rdx
    9fc7:	66 49 0f 6e c5       	movq   %r13,%xmm0
    9fcc:	48 8d 3d 4f 21 00 00 	lea    0x214f(%rip),%rdi        # c122 <_IO_stdin_used+0x122>
    9fd3:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9fd7:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    9fdc:	4c 01 fa             	add    %r15,%rdx
    9fdf:	48 c7 42 60 00 00 00 	movq   $0x0,0x60(%rdx)
    9fe6:	00 
    9fe7:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    9fec:	e8 af 93 ff ff       	call   33a0 <getenv@plt>
    9ff1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9ff6:	66 0f 6f 44 24 20    	movdqa 0x20(%rsp),%xmm0
    9ffc:	48 85 c0             	test   %rax,%rax
    9fff:	0f 84 93 0d 00 00    	je     ad98 <fwp_main_thread+0x19f8>
    a005:	80 38 30             	cmpb   $0x30,(%rax)
    a008:	0f 85 8a 0d 00 00    	jne    ad98 <fwp_main_thread+0x19f8>
    a00e:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a012:	0f 85 80 0d 00 00    	jne    ad98 <fwp_main_thread+0x19f8>
    a018:	8b 02                	mov    (%rdx),%eax
    a01a:	c7 42 04 01 00 00 00 	movl   $0x1,0x4(%rdx)
    a021:	48 89 1d b0 60 01 00 	mov    %rbx,0x160b0(%rip)        # 200d8 <fwp_tape_next_slot>
    a028:	44 8d 68 01          	lea    0x1(%rax),%r13d
    a02c:	48 8b 05 5d 2b 00 00 	mov    0x2b5d(%rip),%rax        # cb90 <msg.4+0x20>
    a033:	48 c7 42 50 00 00 00 	movq   $0x0,0x50(%rdx)
    a03a:	00 
    a03b:	44 89 2a             	mov    %r13d,(%rdx)
    a03e:	48 89 42 58          	mov    %rax,0x58(%rdx)
    a042:	48 8b 05 0f 84 01 00 	mov    0x1840f(%rip),%rax        # 22458 <fwp_cleanups>
    a049:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    a04d:	48 85 c0             	test   %rax,%rax
    a050:	75 1a                	jne    a06c <fwp_main_thread+0xccc>
    a052:	e9 79 15 00 00       	jmp    b5d0 <fwp_main_thread+0x2230>
    a057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a05e:	00 00 
    a060:	48 8b 00             	mov    (%rax),%rax
    a063:	48 85 c0             	test   %rax,%rax
    a066:	0f 84 64 15 00 00    	je     b5d0 <fwp_main_thread+0x2230>
    a06c:	48 8d 3d 6d cc ff ff 	lea    -0x3393(%rip),%rdi        # 6ce0 <fwp_tape_scope_release>
    a073:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a077:	75 e7                	jne    a060 <fwp_main_thread+0xcc0>
    a079:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a07d:	44 89 f1             	mov    %r14d,%ecx
    a080:	48 63 06             	movslq (%rsi),%rax
    a083:	48 89 72 50          	mov    %rsi,0x50(%rdx)
    a087:	89 42 5c             	mov    %eax,0x5c(%rdx)
    a08a:	85 c0                	test   %eax,%eax
    a08c:	78 09                	js     a097 <fwp_main_thread+0xcf7>
    a08e:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a092:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    a097:	89 0e                	mov    %ecx,(%rsi)
    a099:	bf 01 00 00 00       	mov    $0x1,%edi
    a09e:	e8 ad a1 ff ff       	call   4250 <descent_phase_step>
    a0a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a0a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a0af:	00 
    a0b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    a0b4:	49 83 c4 01          	add    $0x1,%r12
    a0b8:	48 85 c0             	test   %rax,%rax
    a0bb:	75 f3                	jne    a0b0 <fwp_main_thread+0xd10>
    a0bd:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    a0c2:	0f 1f 00             	nopl   (%rax)
    a0c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a0cc:	00 00 00 00 
    a0d0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    a0d4:	48 83 c0 01          	add    $0x1,%rax
    a0d8:	4d 85 ff             	test   %r15,%r15
    a0db:	75 f3                	jne    a0d0 <fwp_main_thread+0xd30>
    a0dd:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    a0e4:	ff ff 1f 
    a0e7:	48 39 c2             	cmp    %rax,%rdx
    a0ea:	0f 82 b0 14 00 00    	jb     b5a0 <fwp_main_thread+0x2200>
    a0f0:	4d 85 e4             	test   %r12,%r12
    a0f3:	0f 8e 47 0e 00 00    	jle    af40 <fwp_main_thread+0x1ba0>
    a0f9:	49 39 c4             	cmp    %rax,%r12
    a0fc:	4c 0f 47 e0          	cmova  %rax,%r12
    a100:	4c 89 e0             	mov    %r12,%rax
    a103:	48 c1 e8 3c          	shr    $0x3c,%rax
    a107:	0f 85 93 14 00 00    	jne    b5a0 <fwp_main_thread+0x2200>
    a10d:	4b 8d 14 24          	lea    (%r12,%r12,1),%rdx
    a111:	be 02 00 00 00       	mov    $0x2,%esi
    a116:	49 c1 e5 10          	shl    $0x10,%r13
    a11a:	48 8d 3c d5 08 00 00 	lea    0x8(,%rdx,8),%rdi
    a121:	00 
    a122:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    a127:	4c 09 eb             	or     %r13,%rbx
    a12a:	e8 61 bb ff ff       	call   5c90 <fwp_heap_alloc>
    a12f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a134:	49 89 c6             	mov    %rax,%r14
    a137:	48 89 10             	mov    %rdx,(%rax)
    a13a:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a141:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a148:	48 c1 e2 10          	shl    $0x10,%rdx
    a14c:	48 39 d0             	cmp    %rdx,%rax
    a14f:	0f 83 ab 0d 00 00    	jae    af00 <fwp_main_thread+0x1b60>
    a155:	48 89 c2             	mov    %rax,%rdx
    a158:	48 c1 ea 10          	shr    $0x10,%rdx
    a15c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a160:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a167:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a16b:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a16f:	4d 85 ed             	test   %r13,%r13
    a172:	74 3a                	je     a1ae <fwp_main_thread+0xe0e>
    a174:	0f b6 0a             	movzbl (%rdx),%ecx
    a177:	80 f9 02             	cmp    $0x2,%cl
    a17a:	0f 84 29 0e 00 00    	je     afa9 <fwp_main_thread+0x1c09>
    a180:	80 f9 01             	cmp    $0x1,%cl
    a183:	75 29                	jne    a1ae <fwp_main_thread+0xe0e>
    a185:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a188:	0f b7 c0             	movzwl %ax,%eax
    a18b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a18e:	48 0f af c1          	imul   %rcx,%rax
    a192:	48 c1 e8 20          	shr    $0x20,%rax
    a196:	48 39 d0             	cmp    %rdx,%rax
    a199:	73 13                	jae    a1ae <fwp_main_thread+0xe0e>
    a19b:	49 01 c5             	add    %rax,%r13
    a19e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a1a3:	0f 84 14 0e 00 00    	je     afbd <fwp_main_thread+0x1c1d>
    a1a9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a1ae:	4d 85 e4             	test   %r12,%r12
    a1b1:	0f 84 7d 00 00 00    	je     a234 <fwp_main_thread+0xe94>
    a1b7:	48 89 d9             	mov    %rbx,%rcx
    a1ba:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a1bf:	31 c0                	xor    %eax,%eax
    a1c1:	48 c1 e1 20          	shl    $0x20,%rcx
    a1c5:	0f 1f 40 00          	nopl   0x0(%rax)
    a1c9:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1d0:	00 00 00 00 
    a1d4:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1db:	00 00 00 00 
    a1df:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1e6:	00 00 00 00 
    a1ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1f1:	00 00 00 00 
    a1f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a1fc:	00 00 00 00 
    a200:	48 89 c6             	mov    %rax,%rsi
    a203:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    a208:	48 01 ce             	add    %rcx,%rsi
    a20b:	0f 80 72 13 00 00    	jo     b583 <fwp_main_thread+0x21e3>
    a211:	66 48 0f 6e de       	movq   %rsi,%xmm3
    a216:	48 89 c6             	mov    %rax,%rsi
    a219:	48 83 c0 01          	add    $0x1,%rax
    a21d:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a221:	48 c1 e6 04          	shl    $0x4,%rsi
    a225:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    a22b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a22f:	4c 39 e0             	cmp    %r12,%rax
    a232:	72 cc                	jb     a200 <fwp_main_thread+0xe60>
    a234:	49 8b 06             	mov    (%r14),%rax
    a237:	48 d1 e8             	shr    $1,%rax
    a23a:	0f 84 d0 0c 00 00    	je     af10 <fwp_main_thread+0x1b70>
    a240:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    a244:	48 89 cf             	mov    %rcx,%rdi
    a247:	48 c1 ef 3c          	shr    $0x3c,%rdi
    a24b:	0f 85 4f 13 00 00    	jne    b5a0 <fwp_main_thread+0x2200>
    a251:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    a255:	48 85 c9             	test   %rcx,%rcx
    a258:	74 49                	je     a2a3 <fwp_main_thread+0xf03>
    a25a:	48 c1 e0 04          	shl    $0x4,%rax
    a25e:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a263:	49 89 d5             	mov    %rdx,%r13
    a266:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    a26a:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    a26f:	90                   	nop
    a270:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    a274:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    a278:	48 83 c3 10          	add    $0x10,%rbx
    a27c:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a280:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a284:	e8 57 c1 ff ff       	call   63e0 <w120>
    a289:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a28e:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a292:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a296:	49 39 dc             	cmp    %rbx,%r12
    a299:	75 d5                	jne    a270 <fwp_main_thread+0xed0>
    a29b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a2a0:	4c 89 ea             	mov    %r13,%rdx
    a2a3:	49 89 16             	mov    %rdx,(%r14)
    a2a6:	4c 89 f7             	mov    %r14,%rdi
    a2a9:	4c 63 eb             	movslq %ebx,%r13
    a2ac:	e8 ef c2 ff ff       	call   65a0 <w176.constprop.0>
    a2b1:	4c 89 f7             	mov    %r14,%rdi
    a2b4:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    a2b9:	e8 52 d9 ff ff       	call   7c10 <fwp_drop10>
    a2be:	bf 02 00 00 00       	mov    $0x2,%edi
    a2c3:	e8 88 9f ff ff       	call   4250 <descent_phase_step>
    a2c8:	4c 89 ef             	mov    %r13,%rdi
    a2cb:	e8 00 a4 ff ff       	call   46d0 <fwp_tape_of>
    a2d0:	48 89 c6             	mov    %rax,%rsi
    a2d3:	48 8b 40 60          	mov    0x60(%rax),%rax
    a2d7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a2dc:	48 85 c0             	test   %rax,%rax
    a2df:	0f 85 f7 12 00 00    	jne    b5dc <fwp_main_thread+0x223c>
    a2e5:	48 89 f7             	mov    %rsi,%rdi
    a2e8:	e8 13 99 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    a2ed:	f3 0f 6f 76 20       	movdqu 0x20(%rsi),%xmm6
    a2f2:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a2f6:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a2fd:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    a302:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a307:	0f 29 74 24 40       	movaps %xmm6,0x40(%rsp)
    a30c:	66 49 0f 6e f6       	movq   %r14,%xmm6
    a311:	4c 8b 66 08          	mov    0x8(%rsi),%r12
    a315:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a319:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    a31d:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    a322:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a326:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a32c:	77 18                	ja     a346 <fwp_main_thread+0xfa6>
    a32e:	0f b7 c3             	movzwl %bx,%eax
    a331:	83 e8 01             	sub    $0x1,%eax
    a334:	48 98                	cltq
    a336:	48 3b 05 9b 5d 01 00 	cmp    0x15d9b(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a33d:	7d 07                	jge    a346 <fwp_main_thread+0xfa6>
    a33f:	48 89 05 92 5d 01 00 	mov    %rax,0x15d92(%rip)        # 200d8 <fwp_tape_next_slot>
    a346:	48 8b 05 0b 81 01 00 	mov    0x1810b(%rip),%rax        # 22458 <fwp_cleanups>
    a34d:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a351:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a358:	00 
    a359:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a35d:	66 0f 6f 7c 24 40    	movdqa 0x40(%rsp),%xmm7
    a363:	66 0f 6f 74 24 10    	movdqa 0x10(%rsp),%xmm6
    a369:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a370:	00 
    a371:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
    a376:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a37d:	00 
    a37e:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a382:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a386:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a38d:	00 
    a38e:	48 8d 05 db ac ff ff 	lea    -0x5325(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    a395:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a39c:	00 
    a39d:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    a3a2:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    a3a9:	00 
    a3aa:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a3b1:	00 
    a3b2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
    a3b7:	0f 29 bc 24 d0 00 00 	movaps %xmm7,0xd0(%rsp)
    a3be:	00 
    a3bf:	48 89 05 92 80 01 00 	mov    %rax,0x18092(%rip)        # 22458 <fwp_cleanups>
    a3c6:	0f 29 b4 24 e0 00 00 	movaps %xmm6,0xe0(%rsp)
    a3cd:	00 
    a3ce:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    a3d5:	00 
    a3d6:	48 85 ff             	test   %rdi,%rdi
    a3d9:	0f 88 01 0d 00 00    	js     b0e0 <fwp_main_thread+0x1d40>
    a3df:	48 89 f8             	mov    %rdi,%rax
    a3e2:	48 c1 f8 20          	sar    $0x20,%rax
    a3e6:	49 39 c5             	cmp    %rax,%r13
    a3e9:	0f 85 37 11 00 00    	jne    b526 <fwp_main_thread+0x2186>
    a3ef:	41 89 f9             	mov    %edi,%r9d
    a3f2:	4d 89 cd             	mov    %r9,%r13
    a3f5:	4c 39 ca             	cmp    %r9,%rdx
    a3f8:	0f 8e 1c 11 00 00    	jle    b51a <fwp_main_thread+0x217a>
    a3fe:	4d 39 cc             	cmp    %r9,%r12
    a401:	0f 8e c9 0b 00 00    	jle    afd0 <fwp_main_thread+0x1c30>
    a407:	4d 39 f4             	cmp    %r14,%r12
    a40a:	0f 8f 00 0c 00 00    	jg     b010 <fwp_main_thread+0x1c70>
    a410:	48 85 c9             	test   %rcx,%rcx
    a413:	0f 84 e1 0c 00 00    	je     b0fa <fwp_main_thread+0x1d5a>
    a419:	48 89 cf             	mov    %rcx,%rdi
    a41c:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    a423:	00 
    a424:	31 f6                	xor    %esi,%esi
    a426:	45 31 f6             	xor    %r14d,%r14d
    a429:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    a42e:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    a433:	e8 88 90 ff ff       	call   34c0 <memset@plt>
    a438:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
    a43d:	48 89 c1             	mov    %rax,%rcx
    a440:	f2 0f 10 05 50 27 00 	movsd  0x2750(%rip),%xmm0        # cb98 <msg.4+0x28>
    a447:	00 
    a448:	f2 42 0f 58 04 c9    	addsd  (%rcx,%r9,8),%xmm0
    a44e:	f2 42 0f 11 04 c9    	movsd  %xmm0,(%rcx,%r9,8)
    a454:	bf 03 00 00 00       	mov    $0x3,%edi
    a459:	4c 01 25 a0 5c 01 00 	add    %r12,0x15ca0(%rip)        # 20100 <descent_inputs>
    a460:	4c 01 35 a1 5c 01 00 	add    %r14,0x15ca1(%rip)        # 20108 <descent_nodes>
    a467:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
    a46c:	e8 df 9d ff ff       	call   4250 <descent_phase_step>
    a471:	4d 39 ec             	cmp    %r13,%r12
    a474:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
    a479:	0f 8f 8b 00 00 00    	jg     a50a <fwp_main_thread+0x116a>
    a47f:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
    a484:	4d 29 e5             	sub    %r12,%r13
    a487:	4e 8d 1c e1          	lea    (%rcx,%r12,8),%r11
    a48b:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a48f:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    a494:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
    a499:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a49e:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    a4a2:	4d 29 d3             	sub    %r10,%r11
    a4a5:	4a 8d 04 af          	lea    (%rdi,%r13,4),%rax
    a4a9:	48 29 fe             	sub    %rdi,%rsi
    a4ac:	4d 29 d1             	sub    %r10,%r9
    a4af:	eb 0b                	jmp    a4bc <fwp_main_thread+0x111c>
    a4b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a4b8:	48 83 e8 04          	sub    $0x4,%rax
    a4bc:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a4c2:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a4c6:	7a 02                	jp     a4ca <fwp_main_thread+0x112a>
    a4c8:	74 37                	je     a501 <fwp_main_thread+0x1161>
    a4ca:	4c 63 04 06          	movslq (%rsi,%rax,1),%r8
    a4ce:	45 85 c0             	test   %r8d,%r8d
    a4d1:	78 16                	js     a4e9 <fwp_main_thread+0x1149>
    a4d3:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    a4d9:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a4dd:	f2 42 0f 58 0c c1    	addsd  (%rcx,%r8,8),%xmm1
    a4e3:	f2 42 0f 11 0c c1    	movsd  %xmm1,(%rcx,%r8,8)
    a4e9:	4c 63 00             	movslq (%rax),%r8
    a4ec:	45 85 c0             	test   %r8d,%r8d
    a4ef:	78 10                	js     a501 <fwp_main_thread+0x1161>
    a4f1:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a4f5:	f2 42 0f 58 04 c1    	addsd  (%rcx,%r8,8),%xmm0
    a4fb:	f2 42 0f 11 04 c1    	movsd  %xmm0,(%rcx,%r8,8)
    a501:	48 83 ea 08          	sub    $0x8,%rdx
    a505:	48 39 f8             	cmp    %rdi,%rax
    a508:	75 ae                	jne    a4b8 <fwp_main_thread+0x1118>
    a50a:	bf 04 00 00 00       	mov    $0x4,%edi
    a50f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a514:	e8 37 9d ff ff       	call   4250 <descent_phase_step>
    a519:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a520:	ff ff 1f 
    a523:	4c 39 e0             	cmp    %r12,%rax
    a526:	0f 82 5c 10 00 00    	jb     b588 <fwp_main_thread+0x21e8>
    a52c:	4a 8d 3c e5 08 00 00 	lea    0x8(,%r12,8),%rdi
    a533:	00 
    a534:	be 02 00 00 00       	mov    $0x2,%esi
    a539:	e8 52 b7 ff ff       	call   5c90 <fwp_heap_alloc>
    a53e:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    a543:	4c 89 20             	mov    %r12,(%rax)
    a546:	48 89 c3             	mov    %rax,%rbx
    a549:	31 c0                	xor    %eax,%eax
    a54b:	4d 85 e4             	test   %r12,%r12
    a54e:	74 22                	je     a572 <fwp_main_thread+0x11d2>
    a550:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a55c:	00 00 00 00 
    a560:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    a564:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a569:	48 83 c0 01          	add    $0x1,%rax
    a56d:	49 39 c4             	cmp    %rax,%r12
    a570:	75 ee                	jne    a560 <fwp_main_thread+0x11c0>
    a572:	bf 05 00 00 00       	mov    $0x5,%edi
    a577:	e8 d4 9c ff ff       	call   4250 <descent_phase_step>
    a57c:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
    a583:	00 
    a584:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    a589:	4c 89 25 c8 7e 01 00 	mov    %r12,0x17ec8(%rip)        # 22458 <fwp_cleanups>
    a590:	e8 db aa ff ff       	call   5070 <fwp_tape_buffers_release>
    a595:	bf 06 00 00 00       	mov    $0x6,%edi
    a59a:	e8 b1 9c ff ff       	call   4250 <descent_phase_step>
    a59f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a5a6:	48 89 d8             	mov    %rbx,%rax
    a5a9:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a5b0:	48 c1 e2 10          	shl    $0x10,%rdx
    a5b4:	48 39 d0             	cmp    %rdx,%rax
    a5b7:	73 59                	jae    a612 <fwp_main_thread+0x1272>
    a5b9:	48 89 c2             	mov    %rax,%rdx
    a5bc:	48 c1 ea 10          	shr    $0x10,%rdx
    a5c0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a5c4:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a5cb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a5cf:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a5d3:	4d 85 ed             	test   %r13,%r13
    a5d6:	74 3a                	je     a612 <fwp_main_thread+0x1272>
    a5d8:	0f b6 0a             	movzbl (%rdx),%ecx
    a5db:	80 f9 02             	cmp    $0x2,%cl
    a5de:	0f 84 64 0b 00 00    	je     b148 <fwp_main_thread+0x1da8>
    a5e4:	80 f9 01             	cmp    $0x1,%cl
    a5e7:	75 29                	jne    a612 <fwp_main_thread+0x1272>
    a5e9:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5ec:	0f b7 c0             	movzwl %ax,%eax
    a5ef:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5f2:	48 0f af c1          	imul   %rcx,%rax
    a5f6:	48 c1 e8 20          	shr    $0x20,%rax
    a5fa:	48 39 d0             	cmp    %rdx,%rax
    a5fd:	73 13                	jae    a612 <fwp_main_thread+0x1272>
    a5ff:	49 01 c5             	add    %rax,%r13
    a602:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a607:	0f 84 4f 0b 00 00    	je     b15c <fwp_main_thread+0x1dbc>
    a60d:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a612:	4c 3b 64 24 60       	cmp    0x60(%rsp),%r12
    a617:	0f 85 2e 91 ff ff    	jne    374b <fwp_main_thread.cold>
    a61d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    a624:	00 
    a625:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
    a62a:	48 89 05 27 7e 01 00 	mov    %rax,0x17e27(%rip)        # 22458 <fwp_cleanups>
    a631:	e8 aa c6 ff ff       	call   6ce0 <fwp_tape_scope_release>
    a636:	48 8b 03             	mov    (%rbx),%rax
    a639:	49 89 c5             	mov    %rax,%r13
    a63c:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a641:	48 85 c0             	test   %rax,%rax
    a644:	0f 88 e6 07 00 00    	js     ae30 <fwp_main_thread+0x1a90>
    a64a:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a651:	48 89 d8             	mov    %rbx,%rax
    a654:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a65b:	48 c1 e2 10          	shl    $0x10,%rdx
    a65f:	48 39 d0             	cmp    %rdx,%rax
    a662:	0f 83 c8 07 00 00    	jae    ae30 <fwp_main_thread+0x1a90>
    a668:	48 89 c2             	mov    %rax,%rdx
    a66b:	48 c1 ea 10          	shr    $0x10,%rdx
    a66f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a673:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a67a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a67e:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a682:	48 85 c9             	test   %rcx,%rcx
    a685:	0f 84 a5 07 00 00    	je     ae30 <fwp_main_thread+0x1a90>
    a68b:	0f b6 32             	movzbl (%rdx),%esi
    a68e:	40 80 fe 02          	cmp    $0x2,%sil
    a692:	0f 84 80 07 00 00    	je     ae18 <fwp_main_thread+0x1a78>
    a698:	40 80 fe 01          	cmp    $0x1,%sil
    a69c:	0f 85 8e 07 00 00    	jne    ae30 <fwp_main_thread+0x1a90>
    a6a2:	8b 72 18             	mov    0x18(%rdx),%esi
    a6a5:	0f b7 c0             	movzwl %ax,%eax
    a6a8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a6ab:	48 0f af c6          	imul   %rsi,%rax
    a6af:	48 c1 e8 20          	shr    $0x20,%rax
    a6b3:	48 39 d0             	cmp    %rdx,%rax
    a6b6:	0f 83 74 07 00 00    	jae    ae30 <fwp_main_thread+0x1a90>
    a6bc:	48 01 c1             	add    %rax,%rcx
    a6bf:	80 39 01             	cmpb   $0x1,(%rcx)
    a6c2:	0f 85 68 07 00 00    	jne    ae30 <fwp_main_thread+0x1a90>
    a6c8:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a6cd:	48 89 da             	mov    %rbx,%rdx
    a6d0:	31 ff                	xor    %edi,%edi
    a6d2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a6d7:	48 8d 48 08          	lea    0x8(%rax),%rcx
    a6db:	31 c0                	xor    %eax,%eax
    a6dd:	4d 85 ed             	test   %r13,%r13
    a6e0:	75 2f                	jne    a711 <fwp_main_thread+0x1371>
    a6e2:	eb 5c                	jmp    a740 <fwp_main_thread+0x13a0>
    a6e4:	0f 1f 40 00          	nopl   0x0(%rax)
    a6e8:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a6ec:	0f 88 85 0e 00 00    	js     b577 <fwp_main_thread+0x21d7>
    a6f2:	f2 0f 10 05 b6 24 00 	movsd  0x24b6(%rip),%xmm0        # cbb0 <msg.4+0x40>
    a6f9:	00 
    a6fa:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    a6ff:	48 83 c0 01          	add    $0x1,%rax
    a703:	48 83 c1 08          	add    $0x8,%rcx
    a707:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    a70c:	49 39 c5             	cmp    %rax,%r13
    a70f:	74 2f                	je     a740 <fwp_main_thread+0x13a0>
    a711:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    a715:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    a719:	79 cd                	jns    a6e8 <fwp_main_thread+0x1348>
    a71b:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    a71f:	eb c7                	jmp    a6e8 <fwp_main_thread+0x1348>
    a721:	48 8d 3d 38 a5 ff ff 	lea    -0x5ac8(%rip),%rdi        # 4c60 <fwp_heap_report>
    a728:	e8 f3 10 00 00       	call   b820 <atexit>
    a72d:	e9 b6 ec ff ff       	jmp    93e8 <fwp_main_thread+0x48>
    a732:	e8 39 a6 ff ff       	call   4d70 <fwp_heap_init>
    a737:	e9 9c ec ff ff       	jmp    93d8 <fwp_main_thread+0x38>
    a73c:	0f 1f 40 00          	nopl   0x0(%rax)
    a740:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    a745:	e8 c6 d4 ff ff       	call   7c10 <fwp_drop10>
    a74a:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    a74f:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    a754:	90                   	nop
    a755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a75c:	00 00 00 00 
    a760:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a764:	49 83 c7 01          	add    $0x1,%r15
    a768:	48 85 db             	test   %rbx,%rbx
    a76b:	75 f3                	jne    a760 <fwp_main_thread+0x13c0>
    a76d:	4c 8b 32             	mov    (%rdx),%r14
    a770:	4d 85 f6             	test   %r14,%r14
    a773:	0f 88 07 01 00 00    	js     a880 <fwp_main_thread+0x14e0>
    a779:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    a780:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a785:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a78c:	48 c1 e1 10          	shl    $0x10,%rcx
    a790:	48 39 c8             	cmp    %rcx,%rax
    a793:	0f 83 e7 00 00 00    	jae    a880 <fwp_main_thread+0x14e0>
    a799:	48 89 c1             	mov    %rax,%rcx
    a79c:	48 c1 e9 10          	shr    $0x10,%rcx
    a7a0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a7a4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    a7ab:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a7af:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a7b3:	48 85 f6             	test   %rsi,%rsi
    a7b6:	0f 84 c4 00 00 00    	je     a880 <fwp_main_thread+0x14e0>
    a7bc:	0f b6 39             	movzbl (%rcx),%edi
    a7bf:	40 80 ff 02          	cmp    $0x2,%dil
    a7c3:	0f 84 a7 00 00 00    	je     a870 <fwp_main_thread+0x14d0>
    a7c9:	40 80 ff 01          	cmp    $0x1,%dil
    a7cd:	0f 85 ad 00 00 00    	jne    a880 <fwp_main_thread+0x14e0>
    a7d3:	8b 79 18             	mov    0x18(%rcx),%edi
    a7d6:	0f b7 c0             	movzwl %ax,%eax
    a7d9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a7dc:	48 0f af c7          	imul   %rdi,%rax
    a7e0:	48 c1 e8 20          	shr    $0x20,%rax
    a7e4:	48 39 c8             	cmp    %rcx,%rax
    a7e7:	0f 83 93 00 00 00    	jae    a880 <fwp_main_thread+0x14e0>
    a7ed:	48 01 c6             	add    %rax,%rsi
    a7f0:	80 3e 01             	cmpb   $0x1,(%rsi)
    a7f3:	0f 85 87 00 00 00    	jne    a880 <fwp_main_thread+0x14e0>
    a7f9:	4d 39 f7             	cmp    %r14,%r15
    a7fc:	4d 0f 46 f7          	cmovbe %r15,%r14
    a800:	4d 85 f6             	test   %r14,%r14
    a803:	0f 84 cb 0a 00 00    	je     b2d4 <fwp_main_thread+0x1f34>
    a809:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    a80d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a813:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a818:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a81d:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    a824:	00 
    a825:	31 c0                	xor    %eax,%eax
    a827:	49 8d 79 08          	lea    0x8(%r9),%rdi
    a82b:	eb 34                	jmp    a861 <fwp_main_thread+0x14c1>
    a82d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a834:	00 
    a835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a83c:	00 00 00 00 
    a840:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    a845:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    a84a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    a850:	48 83 c0 08          	add    $0x8,%rax
    a854:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    a858:	49 39 c0             	cmp    %rax,%r8
    a85b:	0f 84 b7 00 00 00    	je     a918 <fwp_main_thread+0x1578>
    a861:	48 89 f9             	mov    %rdi,%rcx
    a864:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a868:	79 d6                	jns    a840 <fwp_main_thread+0x14a0>
    a86a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    a86e:	eb d0                	jmp    a840 <fwp_main_thread+0x14a0>
    a870:	66 85 c0             	test   %ax,%ax
    a873:	0f 84 77 ff ff ff    	je     a7f0 <fwp_main_thread+0x1450>
    a879:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a880:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a885:	45 31 ed             	xor    %r13d,%r13d
    a888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a88f:	00 
    a890:	48 8b 40 10          	mov    0x10(%rax),%rax
    a894:	4c 89 e9             	mov    %r13,%rcx
    a897:	49 83 c5 01          	add    $0x1,%r13
    a89b:	48 85 c0             	test   %rax,%rax
    a89e:	75 f0                	jne    a890 <fwp_main_thread+0x14f0>
    a8a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a8a7:	ff ff 1f 
    a8aa:	4c 39 e8             	cmp    %r13,%rax
    a8ad:	0f 82 ed 0c 00 00    	jb     b5a0 <fwp_main_thread+0x2200>
    a8b3:	be 02 00 00 00       	mov    $0x2,%esi
    a8b8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    a8bf:	00 
    a8c0:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    a8c5:	e8 c6 b3 ff ff       	call   5c90 <fwp_heap_alloc>
    a8ca:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    a8cf:	49 89 c4             	mov    %rax,%r12
    a8d2:	48 89 c6             	mov    %rax,%rsi
    a8d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a8da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    a8e4:	48 83 c6 08          	add    $0x8,%rsi
    a8e8:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    a8ec:	48 8b 40 10          	mov    0x10(%rax),%rax
    a8f0:	48 85 c0             	test   %rax,%rax
    a8f3:	75 eb                	jne    a8e0 <fwp_main_thread+0x1540>
    a8f5:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a8fa:	4d 39 ee             	cmp    %r13,%r14
    a8fd:	4d 0f 47 f5          	cmova  %r13,%r14
    a901:	4d 85 f6             	test   %r14,%r14
    a904:	0f 84 c5 09 00 00    	je     b2cf <fwp_main_thread+0x1f2f>
    a90a:	45 31 ed             	xor    %r13d,%r13d
    a90d:	e9 01 ff ff ff       	jmp    a813 <fwp_main_thread+0x1473>
    a912:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a918:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    a91f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    a926:	45 31 ff             	xor    %r15d,%r15d
    a929:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    a930:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a935:	48 c1 e7 10          	shl    $0x10,%rdi
    a939:	eb 1b                	jmp    a956 <fwp_main_thread+0x15b6>
    a93b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a940:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a944:	49 83 c7 01          	add    $0x1,%r15
    a948:	48 85 d2             	test   %rdx,%rdx
    a94b:	74 5f                	je     a9ac <fwp_main_thread+0x160c>
    a94d:	4d 39 f7             	cmp    %r14,%r15
    a950:	0f 83 fa 03 00 00    	jae    ad50 <fwp_main_thread+0x19b0>
    a956:	48 89 d0             	mov    %rdx,%rax
    a959:	4c 29 c0             	sub    %r8,%rax
    a95c:	48 39 f8             	cmp    %rdi,%rax
    a95f:	73 4b                	jae    a9ac <fwp_main_thread+0x160c>
    a961:	48 89 c1             	mov    %rax,%rcx
    a964:	48 c1 e9 10          	shr    $0x10,%rcx
    a968:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    a96c:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    a970:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a974:	48 85 f6             	test   %rsi,%rsi
    a977:	74 33                	je     a9ac <fwp_main_thread+0x160c>
    a979:	44 0f b6 11          	movzbl (%rcx),%r10d
    a97d:	41 80 fa 02          	cmp    $0x2,%r10b
    a981:	0f 84 b1 03 00 00    	je     ad38 <fwp_main_thread+0x1998>
    a987:	41 80 fa 01          	cmp    $0x1,%r10b
    a98b:	75 1f                	jne    a9ac <fwp_main_thread+0x160c>
    a98d:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    a991:	0f b7 c0             	movzwl %ax,%eax
    a994:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a997:	49 0f af c2          	imul   %r10,%rax
    a99b:	48 c1 e8 20          	shr    $0x20,%rax
    a99f:	48 39 c8             	cmp    %rcx,%rax
    a9a2:	73 08                	jae    a9ac <fwp_main_thread+0x160c>
    a9a4:	48 01 c6             	add    %rax,%rsi
    a9a7:	80 3e 01             	cmpb   $0x1,(%rsi)
    a9aa:	74 94                	je     a940 <fwp_main_thread+0x15a0>
    a9ac:	4d 39 f7             	cmp    %r14,%r15
    a9af:	72 43                	jb     a9f4 <fwp_main_thread+0x1654>
    a9b1:	e9 9a 03 00 00       	jmp    ad50 <fwp_main_thread+0x19b0>
    a9b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a9bd:	00 00 00 
    a9c0:	40 80 fe 01          	cmp    $0x1,%sil
    a9c4:	75 25                	jne    a9eb <fwp_main_thread+0x164b>
    a9c6:	8b 71 18             	mov    0x18(%rcx),%esi
    a9c9:	0f b7 c0             	movzwl %ax,%eax
    a9cc:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a9cf:	48 0f af c6          	imul   %rsi,%rax
    a9d3:	48 c1 e8 20          	shr    $0x20,%rax
    a9d7:	48 39 c8             	cmp    %rcx,%rax
    a9da:	73 0f                	jae    a9eb <fwp_main_thread+0x164b>
    a9dc:	48 01 c2             	add    %rax,%rdx
    a9df:	80 3a ff             	cmpb   $0xff,(%rdx)
    a9e2:	0f 84 f8 04 00 00    	je     aee0 <fwp_main_thread+0x1b40>
    a9e8:	c6 02 01             	movb   $0x1,(%rdx)
    a9eb:	4d 39 fe             	cmp    %r15,%r14
    a9ee:	0f 84 8c 00 00 00    	je     aa80 <fwp_main_thread+0x16e0>
    a9f4:	49 83 ee 01          	sub    $0x1,%r14
    a9f8:	66 48 0f 6e eb       	movq   %rbx,%xmm5
    a9fd:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
    aa02:	bf 01 00 00 00       	mov    $0x1,%edi
    aa07:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    aa0d:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    aa11:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    aa18:	00 
    aa19:	e8 92 b3 ff ff       	call   5db0 <fwp_data.part.0.constprop.0>
    aa1e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa25:	48 89 c3             	mov    %rax,%rbx
    aa28:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aa2f:	48 c1 e2 10          	shl    $0x10,%rdx
    aa33:	48 39 d0             	cmp    %rdx,%rax
    aa36:	73 b3                	jae    a9eb <fwp_main_thread+0x164b>
    aa38:	48 89 c2             	mov    %rax,%rdx
    aa3b:	48 c1 ea 10          	shr    $0x10,%rdx
    aa3f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    aa43:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aa4a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    aa4e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    aa52:	48 85 d2             	test   %rdx,%rdx
    aa55:	74 94                	je     a9eb <fwp_main_thread+0x164b>
    aa57:	0f b6 31             	movzbl (%rcx),%esi
    aa5a:	40 80 fe 02          	cmp    $0x2,%sil
    aa5e:	0f 85 5c ff ff ff    	jne    a9c0 <fwp_main_thread+0x1620>
    aa64:	66 85 c0             	test   %ax,%ax
    aa67:	0f 84 72 ff ff ff    	je     a9df <fwp_main_thread+0x163f>
    aa6d:	4d 39 fe             	cmp    %r15,%r14
    aa70:	75 82                	jne    a9f4 <fwp_main_thread+0x1654>
    aa72:	0f 1f 00             	nopl   (%rax)
    aa75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa7c:	00 00 00 00 
    aa80:	4d 85 f6             	test   %r14,%r14
    aa83:	0f 85 c7 02 00 00    	jne    ad50 <fwp_main_thread+0x19b0>
    aa89:	45 85 ed             	test   %r13d,%r13d
    aa8c:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    aa92:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    aa97:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    aa9c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    aaa1:	e8 ea ac ff ff       	call   5790 <fwp_mem_free>
    aaa6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    aaab:	e8 60 d1 ff ff       	call   7c10 <fwp_drop10>
    aab0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aab7:	4c 89 f0             	mov    %r14,%rax
    aaba:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    aac1:	48 c1 e2 10          	shl    $0x10,%rdx
    aac5:	48 39 d0             	cmp    %rdx,%rax
    aac8:	73 76                	jae    ab40 <fwp_main_thread+0x17a0>
    aaca:	48 89 c2             	mov    %rax,%rdx
    aacd:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    aad4:	48 c1 ea 10          	shr    $0x10,%rdx
    aad8:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    aadc:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    aae0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    aae4:	4d 85 e4             	test   %r12,%r12
    aae7:	74 57                	je     ab40 <fwp_main_thread+0x17a0>
    aae9:	0f b6 0a             	movzbl (%rdx),%ecx
    aaec:	80 f9 02             	cmp    $0x2,%cl
    aaef:	0f 84 cb 05 00 00    	je     b0c0 <fwp_main_thread+0x1d20>
    aaf5:	80 f9 01             	cmp    $0x1,%cl
    aaf8:	75 46                	jne    ab40 <fwp_main_thread+0x17a0>
    aafa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    aafd:	0f b7 c0             	movzwl %ax,%eax
    ab00:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ab03:	48 0f af c1          	imul   %rcx,%rax
    ab07:	48 c1 e8 20          	shr    $0x20,%rax
    ab0b:	48 39 d0             	cmp    %rdx,%rax
    ab0e:	73 30                	jae    ab40 <fwp_main_thread+0x17a0>
    ab10:	49 01 c4             	add    %rax,%r12
    ab13:	41 0f b6 04 24       	movzbl (%r12),%eax
    ab18:	84 c0                	test   %al,%al
    ab1a:	74 24                	je     ab40 <fwp_main_thread+0x17a0>
    ab1c:	3c 01                	cmp    $0x1,%al
    ab1e:	0f 84 4c 06 00 00    	je     b170 <fwp_main_thread+0x1dd0>
    ab24:	3c ff                	cmp    $0xff,%al
    ab26:	0f 84 3a 08 00 00    	je     b366 <fwp_main_thread+0x1fc6>
    ab2c:	83 e8 01             	sub    $0x1,%eax
    ab2f:	41 88 04 24          	mov    %al,(%r12)
    ab33:	66 90                	xchg   %ax,%ax
    ab35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ab3c:	00 00 00 00 
    ab40:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    ab45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ab49:	b9 01 00 00 00       	mov    $0x1,%ecx
    ab4e:	48 89 de             	mov    %rbx,%rsi
    ab51:	48 8d 15 28 50 00 00 	lea    0x5028(%rip),%rdx        # fb80 <d0>
    ab58:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    ab5f:	00 
    ab60:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    ab67:	00 00 00 00 00 
    ab6c:	e8 ef d7 ff ff       	call   8360 <fwp_write>
    ab71:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    ab78:	00 
    ab79:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    ab80:	00 
    ab81:	48 8d 05 09 15 00 00 	lea    0x1509(%rip),%rax        # c091 <_IO_stdin_used+0x91>
    ab88:	4d 85 f6             	test   %r14,%r14
    ab8b:	4c 0f 44 f0          	cmove  %rax,%r14
    ab8f:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    ab93:	0f 87 54 0a 00 00    	ja     b5ed <fwp_main_thread+0x224d>
    ab99:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    ab9d:	be 01 00 00 00       	mov    $0x1,%esi
    aba2:	e8 e9 b0 ff ff       	call   5c90 <fwp_heap_alloc>
    aba7:	4c 89 fa             	mov    %r15,%rdx
    abaa:	4c 89 f6             	mov    %r14,%rsi
    abad:	4c 89 38             	mov    %r15,(%rax)
    abb0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    abb4:	49 89 c4             	mov    %rax,%r12
    abb7:	4c 89 ef             	mov    %r13,%rdi
    abba:	e8 e1 89 ff ff       	call   35a0 <memcpy@plt>
    abbf:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    abc5:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    abcc:	00 
    abcd:	e8 ee 87 ff ff       	call   33c0 <free@plt>
    abd2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    abd9:	4c 89 e0             	mov    %r12,%rax
    abdc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    abe3:	48 c1 e2 10          	shl    $0x10,%rdx
    abe7:	48 39 d0             	cmp    %rdx,%rax
    abea:	73 57                	jae    ac43 <fwp_main_thread+0x18a3>
    abec:	48 89 c2             	mov    %rax,%rdx
    abef:	48 c1 ea 10          	shr    $0x10,%rdx
    abf3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    abf7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    abfe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac02:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ac06:	4d 85 f6             	test   %r14,%r14
    ac09:	74 38                	je     ac43 <fwp_main_thread+0x18a3>
    ac0b:	0f b6 0a             	movzbl (%rdx),%ecx
    ac0e:	80 f9 02             	cmp    $0x2,%cl
    ac11:	0f 84 89 06 00 00    	je     b2a0 <fwp_main_thread+0x1f00>
    ac17:	80 f9 01             	cmp    $0x1,%cl
    ac1a:	75 27                	jne    ac43 <fwp_main_thread+0x18a3>
    ac1c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ac1f:	0f b7 c0             	movzwl %ax,%eax
    ac22:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ac25:	48 0f af c1          	imul   %rcx,%rax
    ac29:	48 c1 e8 20          	shr    $0x20,%rax
    ac2d:	48 39 d0             	cmp    %rdx,%rax
    ac30:	73 11                	jae    ac43 <fwp_main_thread+0x18a3>
    ac32:	49 01 c6             	add    %rax,%r14
    ac35:	41 80 3e ff          	cmpb   $0xff,(%r14)
    ac39:	0f 84 74 06 00 00    	je     b2b3 <fwp_main_thread+0x1f13>
    ac3f:	41 c6 06 01          	movb   $0x1,(%r14)
    ac43:	48 89 df             	mov    %rbx,%rdi
    ac46:	e8 d5 cb ff ff       	call   7820 <fwp_drop0>
    ac4b:	49 8b 14 24          	mov    (%r12),%rdx
    ac4f:	be 01 00 00 00       	mov    $0x1,%esi
    ac54:	4c 89 ef             	mov    %r13,%rdi
    ac57:	48 8b 0d c2 77 01 00 	mov    0x177c2(%rip),%rcx        # 22420 <fwp_prog_out>
    ac5e:	e8 1d 8a ff ff       	call   3680 <fwrite@plt>
    ac63:	48 8b 35 b6 77 01 00 	mov    0x177b6(%rip),%rsi        # 22420 <fwp_prog_out>
    ac6a:	bf 0a 00 00 00       	mov    $0xa,%edi
    ac6f:	e8 6c 88 ff ff       	call   34e0 <fputc@plt>
    ac74:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ac7b:	4c 89 e0             	mov    %r12,%rax
    ac7e:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ac85:	48 c1 e2 10          	shl    $0x10,%rdx
    ac89:	48 39 d0             	cmp    %rdx,%rax
    ac8c:	73 72                	jae    ad00 <fwp_main_thread+0x1960>
    ac8e:	48 89 c2             	mov    %rax,%rdx
    ac91:	48 c1 ea 10          	shr    $0x10,%rdx
    ac95:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac99:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    aca0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    aca4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    aca8:	48 85 db             	test   %rbx,%rbx
    acab:	74 53                	je     ad00 <fwp_main_thread+0x1960>
    acad:	0f b6 0a             	movzbl (%rdx),%ecx
    acb0:	80 f9 02             	cmp    $0x2,%cl
    acb3:	0f 84 b7 05 00 00    	je     b270 <fwp_main_thread+0x1ed0>
    acb9:	80 f9 01             	cmp    $0x1,%cl
    acbc:	75 42                	jne    ad00 <fwp_main_thread+0x1960>
    acbe:	8b 4a 18             	mov    0x18(%rdx),%ecx
    acc1:	0f b7 c0             	movzwl %ax,%eax
    acc4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    acc7:	48 0f af c1          	imul   %rcx,%rax
    accb:	48 c1 e8 20          	shr    $0x20,%rax
    accf:	48 39 d0             	cmp    %rdx,%rax
    acd2:	73 2c                	jae    ad00 <fwp_main_thread+0x1960>
    acd4:	48 01 c3             	add    %rax,%rbx
    acd7:	0f b6 03             	movzbl (%rbx),%eax
    acda:	84 c0                	test   %al,%al
    acdc:	74 22                	je     ad00 <fwp_main_thread+0x1960>
    acde:	3c 01                	cmp    $0x1,%al
    ace0:	0f 84 a6 05 00 00    	je     b28c <fwp_main_thread+0x1eec>
    ace6:	3c ff                	cmp    $0xff,%al
    ace8:	0f 84 8a 07 00 00    	je     b478 <fwp_main_thread+0x20d8>
    acee:	83 e8 01             	sub    $0x1,%eax
    acf1:	88 03                	mov    %al,(%rbx)
    acf3:	66 90                	xchg   %ax,%ax
    acf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    acfc:	00 00 00 00 
    ad00:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    ad05:	48 8b 40 10          	mov    0x10(%rax),%rax
    ad09:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    ad0e:	48 85 c0             	test   %rax,%rax
    ad11:	0f 84 e7 05 00 00    	je     b2fe <fwp_main_thread+0x1f5e>
    ad17:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ad1e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ad25:	48 8b 1d 2c 77 01 00 	mov    0x1772c(%rip),%rbx        # 22458 <fwp_cleanups>
    ad2c:	e9 3f f0 ff ff       	jmp    9d70 <fwp_main_thread+0x9d0>
    ad31:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ad38:	66 85 c0             	test   %ax,%ax
    ad3b:	0f 84 66 fc ff ff    	je     a9a7 <fwp_main_thread+0x1607>
    ad41:	4d 39 f7             	cmp    %r14,%r15
    ad44:	0f 82 aa fc ff ff    	jb     a9f4 <fwp_main_thread+0x1654>
    ad4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ad50:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    ad55:	4c 89 e0             	mov    %r12,%rax
    ad58:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    ad5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad60:	48 8b 10             	mov    (%rax),%rdx
    ad63:	48 83 c0 08          	add    $0x8,%rax
    ad67:	4c 89 f6             	mov    %r14,%rsi
    ad6a:	49 89 56 08          	mov    %rdx,0x8(%r14)
    ad6e:	4d 8b 76 10          	mov    0x10(%r14),%r14
    ad72:	48 39 f8             	cmp    %rdi,%rax
    ad75:	75 e9                	jne    ad60 <fwp_main_thread+0x19c0>
    ad77:	45 85 ed             	test   %r13d,%r13d
    ad7a:	4c 0f 45 64 24 20    	cmovne 0x20(%rsp),%r12
    ad80:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    ad84:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    ad89:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    ad8e:	e9 09 fd ff ff       	jmp    aa9c <fwp_main_thread+0x16fc>
    ad93:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ad98:	48 83 3d e8 52 01 00 	cmpq   $0x0,0x152e8(%rip)        # 20088 <fwp_tape_cached_bytes>
    ad9f:	00 
    ada0:	0f 84 72 f2 ff ff    	je     a018 <fwp_main_thread+0xc78>
    ada6:	66 0f 6f 0d f2 52 01 	movdqa 0x152f2(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    adad:	00 
    adae:	48 c7 05 cf 52 01 00 	movq   $0x0,0x152cf(%rip)        # 20088 <fwp_tape_cached_bytes>
    adb5:	00 00 00 00 
    adb9:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
    adbd:	48 8b 05 fc 52 01 00 	mov    0x152fc(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    adc4:	66 0f 6f 0d e4 52 01 	movdqa 0x152e4(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    adcb:	00 
    adcc:	48 89 42 40          	mov    %rax,0x40(%rdx)
    add0:	48 8b 05 f1 52 01 00 	mov    0x152f1(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    add7:	0f 11 4a 30          	movups %xmm1,0x30(%rdx)
    addb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    addf:	48 89 42 18          	mov    %rax,0x18(%rdx)
    ade3:	48 8b 05 e6 52 01 00 	mov    0x152e6(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    adea:	0f 29 0d af 52 01 00 	movaps %xmm1,0x152af(%rip)        # 200a0 <fwp_tape_workspace>
    adf1:	48 89 42 48          	mov    %rax,0x48(%rdx)
    adf5:	0f 29 0d b4 52 01 00 	movaps %xmm1,0x152b4(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    adfc:	48 c7 05 c9 52 01 00 	movq   $0x0,0x152c9(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    ae03:	00 00 00 00 
    ae07:	0f 29 0d b2 52 01 00 	movaps %xmm1,0x152b2(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    ae0e:	e9 05 f2 ff ff       	jmp    a018 <fwp_main_thread+0xc78>
    ae13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ae18:	66 85 c0             	test   %ax,%ax
    ae1b:	0f 84 9e f8 ff ff    	je     a6bf <fwp_main_thread+0x131f>
    ae21:	0f 1f 40 00          	nopl   0x0(%rax)
    ae25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ae2c:	00 00 00 00 
    ae30:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ae37:	ff ff 1f 
    ae3a:	4c 39 e8             	cmp    %r13,%rax
    ae3d:	0f 82 45 07 00 00    	jb     b588 <fwp_main_thread+0x21e8>
    ae43:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    ae4a:	00 
    ae4b:	be 01 00 00 00       	mov    $0x1,%esi
    ae50:	e8 3b ae ff ff       	call   5c90 <fwp_heap_alloc>
    ae55:	4c 89 28             	mov    %r13,(%rax)
    ae58:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    ae5f:	48 89 c2             	mov    %rax,%rdx
    ae62:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ae67:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ae6e:	48 c1 e1 10          	shl    $0x10,%rcx
    ae72:	48 39 c8             	cmp    %rcx,%rax
    ae75:	73 59                	jae    aed0 <fwp_main_thread+0x1b30>
    ae77:	48 89 c1             	mov    %rax,%rcx
    ae7a:	48 c1 e9 10          	shr    $0x10,%rcx
    ae7e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    ae82:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    ae89:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    ae8d:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    ae91:	4d 85 f6             	test   %r14,%r14
    ae94:	74 3a                	je     aed0 <fwp_main_thread+0x1b30>
    ae96:	0f b6 31             	movzbl (%rcx),%esi
    ae99:	40 80 fe 02          	cmp    $0x2,%sil
    ae9d:	0f 84 6d 03 00 00    	je     b210 <fwp_main_thread+0x1e70>
    aea3:	40 80 fe 01          	cmp    $0x1,%sil
    aea7:	75 27                	jne    aed0 <fwp_main_thread+0x1b30>
    aea9:	8b 71 18             	mov    0x18(%rcx),%esi
    aeac:	0f b7 c0             	movzwl %ax,%eax
    aeaf:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    aeb2:	48 0f af c6          	imul   %rsi,%rax
    aeb6:	48 c1 e8 20          	shr    $0x20,%rax
    aeba:	48 39 c8             	cmp    %rcx,%rax
    aebd:	73 11                	jae    aed0 <fwp_main_thread+0x1b30>
    aebf:	49 01 c6             	add    %rax,%r14
    aec2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    aec6:	0f 84 57 03 00 00    	je     b223 <fwp_main_thread+0x1e83>
    aecc:	41 c6 06 01          	movb   $0x1,(%r14)
    aed0:	48 89 df             	mov    %rbx,%rdi
    aed3:	e9 fa f7 ff ff       	jmp    a6d2 <fwp_main_thread+0x1332>
    aed8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aedf:	00 
    aee0:	48 89 d7             	mov    %rdx,%rdi
    aee3:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    aee8:	e8 63 a6 ff ff       	call   5550 <fwp_rc_forget_slot>
    aeed:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    aef2:	e9 f1 fa ff ff       	jmp    a9e8 <fwp_main_thread+0x1648>
    aef7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aefe:	00 00 
    af00:	4d 85 e4             	test   %r12,%r12
    af03:	0f 85 ae f2 ff ff    	jne    a1b7 <fwp_main_thread+0xe17>
    af09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af10:	31 d2                	xor    %edx,%edx
    af12:	e9 8c f3 ff ff       	jmp    a2a3 <fwp_main_thread+0xf03>
    af17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    af1e:	00 00 
    af20:	49 39 d6             	cmp    %rdx,%r14
    af23:	0f 84 07 f0 ff ff    	je     9f30 <fwp_main_thread+0xb90>
    af29:	4c 8b 3d c0 51 01 00 	mov    0x151c0(%rip),%r15        # 200f0 <fwp_tapes>
    af30:	49 89 d6             	mov    %rdx,%r14
    af33:	48 8d 5a 01          	lea    0x1(%rdx),%rbx
    af37:	e9 87 f0 ff ff       	jmp    9fc3 <fwp_main_thread+0xc23>
    af3c:	0f 1f 40 00          	nopl   0x0(%rax)
    af40:	be 02 00 00 00       	mov    $0x2,%esi
    af45:	bf 08 00 00 00       	mov    $0x8,%edi
    af4a:	49 c1 e5 10          	shl    $0x10,%r13
    af4e:	e8 3d ad ff ff       	call   5c90 <fwp_heap_alloc>
    af53:	4c 09 eb             	or     %r13,%rbx
    af56:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    af5d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    af64:	49 89 c6             	mov    %rax,%r14
    af67:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    af6e:	48 c1 e2 10          	shl    $0x10,%rdx
    af72:	48 39 d0             	cmp    %rdx,%rax
    af75:	73 99                	jae    af10 <fwp_main_thread+0x1b70>
    af77:	48 89 c2             	mov    %rax,%rdx
    af7a:	48 c1 ea 10          	shr    $0x10,%rdx
    af7e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    af82:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    af89:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    af8d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    af91:	4d 85 ed             	test   %r13,%r13
    af94:	0f 84 9a f2 ff ff    	je     a234 <fwp_main_thread+0xe94>
    af9a:	0f b6 0a             	movzbl (%rdx),%ecx
    af9d:	45 31 e4             	xor    %r12d,%r12d
    afa0:	80 f9 02             	cmp    $0x2,%cl
    afa3:	0f 85 d7 f1 ff ff    	jne    a180 <fwp_main_thread+0xde0>
    afa9:	66 85 c0             	test   %ax,%ax
    afac:	0f 85 fc f1 ff ff    	jne    a1ae <fwp_main_thread+0xe0e>
    afb2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    afb7:	0f 85 ec f1 ff ff    	jne    a1a9 <fwp_main_thread+0xe09>
    afbd:	4c 89 ef             	mov    %r13,%rdi
    afc0:	e8 8b a5 ff ff       	call   5550 <fwp_rc_forget_slot>
    afc5:	e9 df f1 ff ff       	jmp    a1a9 <fwp_main_thread+0xe09>
    afca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    afd0:	49 8d 59 01          	lea    0x1(%r9),%rbx
    afd4:	49 39 de             	cmp    %rbx,%r14
    afd7:	7c 3a                	jl     b013 <fwp_main_thread+0x1c73>
    afd9:	48 85 c9             	test   %rcx,%rcx
    afdc:	0f 84 18 01 00 00    	je     b0fa <fwp_main_thread+0x1d5a>
    afe2:	48 89 cf             	mov    %rcx,%rdi
    afe5:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    afec:	00 
    afed:	31 f6                	xor    %esi,%esi
    afef:	49 89 de             	mov    %rbx,%r14
    aff2:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
    aff7:	4d 29 e6             	sub    %r12,%r14
    affa:	e8 c1 84 ff ff       	call   34c0 <memset@plt>
    afff:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
    b004:	48 89 c1             	mov    %rax,%rcx
    b007:	e9 34 f4 ff ff       	jmp    a440 <fwp_main_thread+0x10a0>
    b00c:	0f 1f 40 00          	nopl   0x0(%rax)
    b010:	4c 89 e3             	mov    %r12,%rbx
    b013:	4d 85 f6             	test   %r14,%r14
    b016:	4c 0f 44 f3          	cmove  %rbx,%r14
    b01a:	eb 19                	jmp    b035 <fwp_main_thread+0x1c95>
    b01c:	0f 1f 40 00          	nopl   0x0(%rax)
    b020:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    b024:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    b02b:	48 89 d8             	mov    %rbx,%rax
    b02e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b032:	49 89 c6             	mov    %rax,%r14
    b035:	49 39 de             	cmp    %rbx,%r14
    b038:	7c e6                	jl     b020 <fwp_main_thread+0x1c80>
    b03a:	48 85 c9             	test   %rcx,%rcx
    b03d:	0f 84 fd 01 00 00    	je     b240 <fwp_main_thread+0x1ea0>
    b043:	48 89 cf             	mov    %rcx,%rdi
    b046:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    b04d:	00 
    b04e:	e8 7d 85 ff ff       	call   35d0 <realloc@plt>
    b053:	48 89 c1             	mov    %rax,%rcx
    b056:	48 85 c9             	test   %rcx,%rcx
    b059:	0f 84 8d 00 00 00    	je     b0ec <fwp_main_thread+0x1d4c>
    b05f:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
    b066:	00 
    b067:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
    b06e:	00 
    b06f:	48 85 db             	test   %rbx,%rbx
    b072:	0f 85 7a 03 00 00    	jne    b3f2 <fwp_main_thread+0x2052>
    b078:	4d 89 e6             	mov    %r12,%r14
    b07b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b082:	49 f7 de             	neg    %r14
    b085:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    b08a:	48 85 c0             	test   %rax,%rax
    b08d:	0f 88 c1 f3 ff ff    	js     a454 <fwp_main_thread+0x10b4>
    b093:	41 89 c1             	mov    %eax,%r9d
    b096:	e9 a5 f3 ff ff       	jmp    a440 <fwp_main_thread+0x10a0>
    b09b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b0a0:	48 8d 3d 59 bb ff ff 	lea    -0x44a7(%rip),%rdi        # 6c00 <fwp_tape_finish>
    b0a7:	e8 74 07 00 00       	call   b820 <atexit>
    b0ac:	85 c0                	test   %eax,%eax
    b0ae:	75 63                	jne    b113 <fwp_main_thread+0x1d73>
    b0b0:	c7 05 a6 4f 00 00 01 	movl   $0x1,0x4fa6(%rip)        # 10060 <registered_finish.1>
    b0b7:	00 00 00 
    b0ba:	e9 21 ee ff ff       	jmp    9ee0 <fwp_main_thread+0xb40>
    b0bf:	90                   	nop
    b0c0:	66 85 c0             	test   %ax,%ax
    b0c3:	0f 85 77 fa ff ff    	jne    ab40 <fwp_main_thread+0x17a0>
    b0c9:	e9 45 fa ff ff       	jmp    ab13 <fwp_main_thread+0x1773>
    b0ce:	66 90                	xchg   %ax,%ax
    b0d0:	66 85 c0             	test   %ax,%ax
    b0d3:	0f 85 c2 ed ff ff    	jne    9e9b <fwp_main_thread+0xafb>
    b0d9:	e9 a9 ed ff ff       	jmp    9e87 <fwp_main_thread+0xae7>
    b0de:	66 90                	xchg   %ax,%ax
    b0e0:	4c 89 e3             	mov    %r12,%rbx
    b0e3:	4d 39 f4             	cmp    %r14,%r12
    b0e6:	0f 8f 27 ff ff ff    	jg     b013 <fwp_main_thread+0x1c73>
    b0ec:	48 85 db             	test   %rbx,%rbx
    b0ef:	74 87                	je     b078 <fwp_main_thread+0x1cd8>
    b0f1:	48 85 c9             	test   %rcx,%rcx
    b0f4:	0f 85 75 ff ff ff    	jne    b06f <fwp_main_thread+0x1ccf>
    b0fa:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    b101:	00 
    b102:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    b107:	48 89 05 4a 73 01 00 	mov    %rax,0x1734a(%rip)        # 22458 <fwp_cleanups>
    b10e:	e8 5d 9f ff ff       	call   5070 <fwp_tape_buffers_release>
    b113:	48 8b 0d 26 4f 00 00 	mov    0x4f26(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    b11a:	ba 13 00 00 00       	mov    $0x13,%edx
    b11f:	be 01 00 00 00       	mov    $0x1,%esi
    b124:	48 8d 3d dd 0e 00 00 	lea    0xedd(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    b12b:	e8 50 85 ff ff       	call   3680 <fwrite@plt>
    b130:	31 ff                	xor    %edi,%edi
    b132:	e8 89 84 ff ff       	call   35c0 <fflush@plt>
    b137:	bf 66 00 00 00       	mov    $0x66,%edi
    b13c:	e8 5f 85 ff ff       	call   36a0 <_Exit@plt>
    b141:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b148:	66 85 c0             	test   %ax,%ax
    b14b:	0f 85 c1 f4 ff ff    	jne    a612 <fwp_main_thread+0x1272>
    b151:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b156:	0f 85 b1 f4 ff ff    	jne    a60d <fwp_main_thread+0x126d>
    b15c:	4c 89 ef             	mov    %r13,%rdi
    b15f:	e8 ec a3 ff ff       	call   5550 <fwp_rc_forget_slot>
    b164:	e9 a4 f4 ff ff       	jmp    a60d <fwp_main_thread+0x126d>
    b169:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b170:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b177:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b17e:	4c 89 f0             	mov    %r14,%rax
    b181:	4d 8b 66 10          	mov    0x10(%r14),%r12
    b185:	48 29 c8             	sub    %rcx,%rax
    b188:	48 c1 e2 10          	shl    $0x10,%rdx
    b18c:	48 39 d0             	cmp    %rdx,%rax
    b18f:	73 65                	jae    b1f6 <fwp_main_thread+0x1e56>
    b191:	48 89 c7             	mov    %rax,%rdi
    b194:	48 c1 ef 10          	shr    $0x10,%rdi
    b198:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b19c:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b1a0:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b1a4:	48 85 ff             	test   %rdi,%rdi
    b1a7:	74 4d                	je     b1f6 <fwp_main_thread+0x1e56>
    b1a9:	44 0f b6 06          	movzbl (%rsi),%r8d
    b1ad:	41 80 f8 02          	cmp    $0x2,%r8b
    b1b1:	0f 84 32 01 00 00    	je     b2e9 <fwp_main_thread+0x1f49>
    b1b7:	41 80 f8 01          	cmp    $0x1,%r8b
    b1bb:	75 39                	jne    b1f6 <fwp_main_thread+0x1e56>
    b1bd:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    b1c1:	0f b7 c0             	movzwl %ax,%eax
    b1c4:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b1c7:	49 0f af c0          	imul   %r8,%rax
    b1cb:	48 c1 e8 20          	shr    $0x20,%rax
    b1cf:	48 39 f0             	cmp    %rsi,%rax
    b1d2:	73 22                	jae    b1f6 <fwp_main_thread+0x1e56>
    b1d4:	48 01 c7             	add    %rax,%rdi
    b1d7:	80 3f 01             	cmpb   $0x1,(%rdi)
    b1da:	75 1a                	jne    b1f6 <fwp_main_thread+0x1e56>
    b1dc:	4c 89 f7             	mov    %r14,%rdi
    b1df:	e8 ac a5 ff ff       	call   5790 <fwp_mem_free>
    b1e4:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b1eb:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b1f2:	48 c1 e2 10          	shl    $0x10,%rdx
    b1f6:	4c 89 e0             	mov    %r12,%rax
    b1f9:	48 29 c8             	sub    %rcx,%rax
    b1fc:	48 39 d0             	cmp    %rdx,%rax
    b1ff:	0f 83 3b f9 ff ff    	jae    ab40 <fwp_main_thread+0x17a0>
    b205:	4d 89 e6             	mov    %r12,%r14
    b208:	e9 bd f8 ff ff       	jmp    aaca <fwp_main_thread+0x172a>
    b20d:	0f 1f 00             	nopl   (%rax)
    b210:	66 85 c0             	test   %ax,%ax
    b213:	0f 85 b7 fc ff ff    	jne    aed0 <fwp_main_thread+0x1b30>
    b219:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b21d:	0f 85 a9 fc ff ff    	jne    aecc <fwp_main_thread+0x1b2c>
    b223:	4c 89 f7             	mov    %r14,%rdi
    b226:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
    b22b:	e8 20 a3 ff ff       	call   5550 <fwp_rc_forget_slot>
    b230:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
    b235:	e9 92 fc ff ff       	jmp    aecc <fwp_main_thread+0x1b2c>
    b23a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b240:	be 08 00 00 00       	mov    $0x8,%esi
    b245:	4c 89 f7             	mov    %r14,%rdi
    b248:	e8 d3 82 ff ff       	call   3520 <calloc@plt>
    b24d:	48 89 c1             	mov    %rax,%rcx
    b250:	e9 01 fe ff ff       	jmp    b056 <fwp_main_thread+0x1cb6>
    b255:	0f 1f 00             	nopl   (%rax)
    b258:	66 85 c0             	test   %ax,%ax
    b25b:	0f 85 93 eb ff ff    	jne    9df4 <fwp_main_thread+0xa54>
    b261:	e9 68 eb ff ff       	jmp    9dce <fwp_main_thread+0xa2e>
    b266:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b26d:	00 00 00 
    b270:	66 85 c0             	test   %ax,%ax
    b273:	0f 85 87 fa ff ff    	jne    ad00 <fwp_main_thread+0x1960>
    b279:	0f b6 03             	movzbl (%rbx),%eax
    b27c:	84 c0                	test   %al,%al
    b27e:	0f 84 7c fa ff ff    	je     ad00 <fwp_main_thread+0x1960>
    b284:	3c 01                	cmp    $0x1,%al
    b286:	0f 85 5a fa ff ff    	jne    ace6 <fwp_main_thread+0x1946>
    b28c:	4c 89 e7             	mov    %r12,%rdi
    b28f:	e8 fc a4 ff ff       	call   5790 <fwp_mem_free>
    b294:	e9 67 fa ff ff       	jmp    ad00 <fwp_main_thread+0x1960>
    b299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b2a0:	66 85 c0             	test   %ax,%ax
    b2a3:	0f 85 9a f9 ff ff    	jne    ac43 <fwp_main_thread+0x18a3>
    b2a9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b2ad:	0f 85 8c f9 ff ff    	jne    ac3f <fwp_main_thread+0x189f>
    b2b3:	4c 89 f7             	mov    %r14,%rdi
    b2b6:	e8 95 a2 ff ff       	call   5550 <fwp_rc_forget_slot>
    b2bb:	e9 7f f9 ff ff       	jmp    ac3f <fwp_main_thread+0x189f>
    b2c0:	be 68 00 00 00       	mov    $0x68,%esi
    b2c5:	bb 01 00 00 00       	mov    $0x1,%ebx
    b2ca:	e9 9b ec ff ff       	jmp    9f6a <fwp_main_thread+0xbca>
    b2cf:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    b2d4:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    b2d9:	31 db                	xor    %ebx,%ebx
    b2db:	e9 bc f7 ff ff       	jmp    aa9c <fwp_main_thread+0x16fc>
    b2e0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b2e4:	e9 b1 e2 ff ff       	jmp    959a <fwp_main_thread+0x1fa>
    b2e9:	66 85 c0             	test   %ax,%ax
    b2ec:	0f 85 04 ff ff ff    	jne    b1f6 <fwp_main_thread+0x1e56>
    b2f2:	e9 e0 fe ff ff       	jmp    b1d7 <fwp_main_thread+0x1e37>
    b2f7:	31 db                	xor    %ebx,%ebx
    b2f9:	e9 5e e3 ff ff       	jmp    965c <fwp_main_thread+0x2bc>
    b2fe:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    b303:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b308:	e8 13 c5 ff ff       	call   7820 <fwp_drop0>
    b30d:	4c 89 f7             	mov    %r14,%rdi
    b310:	e8 0b c5 ff ff       	call   7820 <fwp_drop0>
    b315:	48 c7 05 48 4d 00 00 	movq   $0x0,0x4d48(%rip)        # 10068 <v.2>
    b31c:	00 00 00 00 
    b320:	c7 05 46 4d 00 00 01 	movl   $0x1,0x4d46(%rip)        # 10070 <st.3>
    b327:	00 00 00 
    b32a:	e9 b7 e1 ff ff       	jmp    94e6 <fwp_main_thread+0x146>
    b32f:	66 85 c0             	test   %ax,%ax
    b332:	0f 85 b9 e8 ff ff    	jne    9bf1 <fwp_main_thread+0x851>
    b338:	e9 a4 e8 ff ff       	jmp    9be1 <fwp_main_thread+0x841>
    b33d:	66 85 c0             	test   %ax,%ax
    b340:	0f 85 01 ea ff ff    	jne    9d47 <fwp_main_thread+0x9a7>
    b346:	e9 de e9 ff ff       	jmp    9d29 <fwp_main_thread+0x989>
    b34b:	66 85 c0             	test   %ax,%ax
    b34e:	0f 85 3c e9 ff ff    	jne    9c90 <fwp_main_thread+0x8f0>
    b354:	e9 27 e9 ff ff       	jmp    9c80 <fwp_main_thread+0x8e0>
    b359:	4c 89 ef             	mov    %r13,%rdi
    b35c:	e8 ef a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b361:	e9 4b e7 ff ff       	jmp    9ab1 <fwp_main_thread+0x711>
    b366:	4c 89 e2             	mov    %r12,%rdx
    b369:	48 c1 ea 11          	shr    $0x11,%rdx
    b36d:	4c 31 e2             	xor    %r12,%rdx
    b370:	48 89 d0             	mov    %rdx,%rax
    b373:	48 c1 e8 09          	shr    $0x9,%rax
    b377:	48 31 c2             	xor    %rax,%rdx
    b37a:	0f b6 d2             	movzbl %dl,%edx
    b37d:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b384:	00 
    b385:	48 85 c0             	test   %rax,%rax
    b388:	75 1f                	jne    b3a9 <fwp_main_thread+0x2009>
    b38a:	eb 5a                	jmp    b3e6 <fwp_main_thread+0x2046>
    b38c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b393:	00 00 
    b395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b39c:	00 00 00 00 
    b3a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b3a4:	48 85 c0             	test   %rax,%rax
    b3a7:	74 3d                	je     b3e6 <fwp_main_thread+0x2046>
    b3a9:	48 89 c2             	mov    %rax,%rdx
    b3ac:	4c 39 20             	cmp    %r12,(%rax)
    b3af:	75 ef                	jne    b3a0 <fwp_main_thread+0x2000>
    b3b1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b3b5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b3b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b3bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b3c4:	0f 85 76 f7 ff ff    	jne    ab40 <fwp_main_thread+0x17a0>
    b3ca:	4c 89 e7             	mov    %r12,%rdi
    b3cd:	e8 7e a1 ff ff       	call   5550 <fwp_rc_forget_slot>
    b3d2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b3d7:	e9 64 f7 ff ff       	jmp    ab40 <fwp_main_thread+0x17a0>
    b3dc:	e8 4f a0 ff ff       	call   5430 <fwp_rc_wide_dup>
    b3e1:	e9 b5 ea ff ff       	jmp    9e9b <fwp_main_thread+0xafb>
    b3e6:	48 8d 3d a3 14 00 00 	lea    0x14a3(%rip),%rdi        # c890 <_IO_stdin_used+0x890>
    b3ed:	e8 fe 8f ff ff       	call   43f0 <fwp_trap>
    b3f2:	48 89 cf             	mov    %rcx,%rdi
    b3f5:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    b3fc:	00 
    b3fd:	31 f6                	xor    %esi,%esi
    b3ff:	49 89 de             	mov    %rbx,%r14
    b402:	e8 b9 80 ff ff       	call   34c0 <memset@plt>
    b407:	4c 8d 6b ff          	lea    -0x1(%rbx),%r13
    b40b:	4d 29 e6             	sub    %r12,%r14
    b40e:	48 89 c1             	mov    %rax,%rcx
    b411:	e9 6f fc ff ff       	jmp    b085 <fwp_main_thread+0x1ce5>
    b416:	48 8b 3d 23 70 01 00 	mov    0x17023(%rip),%rdi        # 22440 <fwp_state>
    b41d:	e8 6e a3 ff ff       	call   5790 <fwp_mem_free>
    b422:	48 c7 05 13 70 01 00 	movq   $0x0,0x17013(%rip)        # 22440 <fwp_state>
    b429:	00 00 00 00 
    b42d:	48 c7 05 f8 6f 01 00 	movq   $0x0,0x16ff8(%rip)        # 22430 <fwp_state_cap>
    b434:	00 00 00 00 
    b438:	48 85 db             	test   %rbx,%rbx
    b43b:	0f 84 f1 00 00 00    	je     b532 <fwp_main_thread+0x2192>
    b441:	48 3b 1d 50 53 01 00 	cmp    0x15350(%rip),%rbx        # 20798 <fwp_root>
    b448:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b44f:	00 00 00 00 
    b453:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b45a:	00 00 00 00 
    b45e:	c7 05 18 4c 01 00 00 	movl   $0x0,0x14c18(%rip)        # 20080 <fwp_exit_code>
    b465:	00 00 00 
    b468:	0f 84 18 e2 ff ff    	je     9686 <fwp_main_thread+0x2e6>
    b46e:	e9 d8 82 ff ff       	jmp    374b <fwp_main_thread.cold>
    b473:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b478:	48 89 d8             	mov    %rbx,%rax
    b47b:	48 c1 e8 11          	shr    $0x11,%rax
    b47f:	48 31 d8             	xor    %rbx,%rax
    b482:	48 89 c2             	mov    %rax,%rdx
    b485:	48 c1 ea 09          	shr    $0x9,%rdx
    b489:	48 31 d0             	xor    %rdx,%rax
    b48c:	0f b6 d0             	movzbl %al,%edx
    b48f:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b496:	00 
    b497:	48 85 c0             	test   %rax,%rax
    b49a:	75 31                	jne    b4cd <fwp_main_thread+0x212d>
    b49c:	e9 45 ff ff ff       	jmp    b3e6 <fwp_main_thread+0x2046>
    b4a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b4a8:	00 00 
    b4aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b4b1:	00 00 00 00 
    b4b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b4bc:	00 00 00 00 
    b4c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b4c4:	48 85 c0             	test   %rax,%rax
    b4c7:	0f 84 19 ff ff ff    	je     b3e6 <fwp_main_thread+0x2046>
    b4cd:	48 89 c2             	mov    %rax,%rdx
    b4d0:	48 3b 18             	cmp    (%rax),%rbx
    b4d3:	75 eb                	jne    b4c0 <fwp_main_thread+0x2120>
    b4d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b4d9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b4dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b4e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b4e8:	0f 85 12 f8 ff ff    	jne    ad00 <fwp_main_thread+0x1960>
    b4ee:	48 89 df             	mov    %rbx,%rdi
    b4f1:	e8 5a a0 ff ff       	call   5550 <fwp_rc_forget_slot>
    b4f6:	c6 03 fe             	movb   $0xfe,(%rbx)
    b4f9:	e9 02 f8 ff ff       	jmp    ad00 <fwp_main_thread+0x1960>
    b4fe:	e8 2d 9f ff ff       	call   5430 <fwp_rc_wide_dup>
    b503:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b50a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b511:	48 c1 e2 10          	shl    $0x10,%rdx
    b515:	e9 da e8 ff ff       	jmp    9df4 <fwp_main_thread+0xa54>
    b51a:	48 8d 3d 46 0c 00 00 	lea    0xc46(%rip),%rdi        # c167 <_IO_stdin_used+0x167>
    b521:	e8 ca 8e ff ff       	call   43f0 <fwp_trap>
    b526:	48 8d 3d 8b 13 00 00 	lea    0x138b(%rip),%rdi        # c8b8 <_IO_stdin_used+0x8b8>
    b52d:	e8 be 8e ff ff       	call   43f0 <fwp_trap>
    b532:	48 83 3d 5e 52 01 00 	cmpq   $0x0,0x1525e(%rip)        # 20798 <fwp_root>
    b539:	00 
    b53a:	c7 05 3c 4b 01 00 00 	movl   $0x0,0x14b3c(%rip)        # 20080 <fwp_exit_code>
    b541:	00 00 00 
    b544:	0f 84 9b e1 ff ff    	je     96e5 <fwp_main_thread+0x345>
    b54a:	e9 fc 81 ff ff       	jmp    374b <fwp_main_thread.cold>
    b54f:	90                   	nop
    b550:	4c 89 e7             	mov    %r12,%rdi
    b553:	e8 f8 9f ff ff       	call   5550 <fwp_rc_forget_slot>
    b558:	e9 8f e6 ff ff       	jmp    9bec <fwp_main_thread+0x84c>
    b55d:	4c 89 e7             	mov    %r12,%rdi
    b560:	e8 eb 9f ff ff       	call   5550 <fwp_rc_forget_slot>
    b565:	e9 21 e7 ff ff       	jmp    9c8b <fwp_main_thread+0x8eb>
    b56a:	4c 89 e7             	mov    %r12,%rdi
    b56d:	e8 de 9f ff ff       	call   5550 <fwp_rc_forget_slot>
    b572:	e9 bd e7 ff ff       	jmp    9d34 <fwp_main_thread+0x994>
    b577:	48 8d 3d 3a 14 00 00 	lea    0x143a(%rip),%rdi        # c9b8 <_IO_stdin_used+0x9b8>
    b57e:	e8 6d 8e ff ff       	call   43f0 <fwp_trap>
    b583:	e8 78 81 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b588:	48 8d 3d a7 0c 00 00 	lea    0xca7(%rip),%rdi        # c236 <_IO_stdin_used+0x236>
    b58f:	e8 5c 8e ff ff       	call   43f0 <fwp_trap>
    b594:	48 8d 3d 81 0c 00 00 	lea    0xc81(%rip),%rdi        # c21c <_IO_stdin_used+0x21c>
    b59b:	e8 50 8e ff ff       	call   43f0 <fwp_trap>
    b5a0:	48 8d 3d e9 0b 00 00 	lea    0xbe9(%rip),%rdi        # c190 <_IO_stdin_used+0x190>
    b5a7:	e8 44 8e ff ff       	call   43f0 <fwp_trap>
    b5ac:	48 8d 3d d5 13 00 00 	lea    0x13d5(%rip),%rdi        # c988 <_IO_stdin_used+0x988>
    b5b3:	e8 38 8e ff ff       	call   43f0 <fwp_trap>
    b5b8:	48 8d 3d a1 13 00 00 	lea    0x13a1(%rip),%rdi        # c960 <_IO_stdin_used+0x960>
    b5bf:	e8 2c 8e ff ff       	call   43f0 <fwp_trap>
    b5c4:	e8 97 7e ff ff       	call   3460 <__stack_chk_fail@plt>
    b5c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b5d0:	48 8d 3d 09 14 00 00 	lea    0x1409(%rip),%rdi        # c9e0 <_IO_stdin_used+0x9e0>
    b5d7:	e8 14 8e ff ff       	call   43f0 <fwp_trap>
    b5dc:	48 8d 3d 1d 13 00 00 	lea    0x131d(%rip),%rdi        # c900 <_IO_stdin_used+0x900>
    b5e3:	e8 08 8e ff ff       	call   43f0 <fwp_trap>
    b5e8:	e8 f3 87 ff ff       	call   3de0 <descent_phase_fail>
    b5ed:	48 8d 3d 52 0c 00 00 	lea    0xc52(%rip),%rdi        # c246 <_IO_stdin_used+0x246>
    b5f4:	e8 f7 8d ff ff       	call   43f0 <fwp_trap>
    b5f9:	e9 4d 81 ff ff       	jmp    374b <fwp_main_thread.cold>
    b5fe:	e9 48 81 ff ff       	jmp    374b <fwp_main_thread.cold>
    b603:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b60a:	00 00 00 
    b60d:	0f 1f 00             	nopl   (%rax)

000000000000b610 <__divmodti4>:
    b610:	f3 0f 1e fa          	endbr64
    b614:	55                   	push   %rbp
    b615:	49 89 f1             	mov    %rsi,%r9
    b618:	49 89 d2             	mov    %rdx,%r10
    b61b:	48 89 fe             	mov    %rdi,%rsi
    b61e:	49 89 cb             	mov    %rcx,%r11
    b621:	48 89 e5             	mov    %rsp,%rbp
    b624:	41 57                	push   %r15
    b626:	41 56                	push   %r14
    b628:	41 55                	push   %r13
    b62a:	41 54                	push   %r12
    b62c:	53                   	push   %rbx
    b62d:	4c 89 c3             	mov    %r8,%rbx
    b630:	45 31 c0             	xor    %r8d,%r8d
    b633:	4d 85 c9             	test   %r9,%r9
    b636:	79 12                	jns    b64a <__divmodti4+0x3a>
    b638:	31 ff                	xor    %edi,%edi
    b63a:	48 f7 de             	neg    %rsi
    b63d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b644:	4c 19 cf             	sbb    %r9,%rdi
    b647:	49 89 f9             	mov    %rdi,%r9
    b64a:	4c 89 d8             	mov    %r11,%rax
    b64d:	4d 85 db             	test   %r11,%r11
    b650:	0f 88 1a 01 00 00    	js     b770 <__divmodti4+0x160>
    b656:	4c 89 d9             	mov    %r11,%rcx
    b659:	49 89 f3             	mov    %rsi,%r11
    b65c:	75 62                	jne    b6c0 <__divmodti4+0xb0>
    b65e:	4d 89 c4             	mov    %r8,%r12
    b661:	4d 39 d1             	cmp    %r10,%r9
    b664:	0f 83 46 01 00 00    	jae    b7b0 <__divmodti4+0x1a0>
    b66a:	4c 89 d8             	mov    %r11,%rax
    b66d:	4c 89 ca             	mov    %r9,%rdx
    b670:	49 f7 f2             	div    %r10
    b673:	49 89 c3             	mov    %rax,%r11
    b676:	31 c0                	xor    %eax,%eax
    b678:	48 89 d6             	mov    %rdx,%rsi
    b67b:	31 ff                	xor    %edi,%edi
    b67d:	4c 89 d9             	mov    %r11,%rcx
    b680:	48 89 c2             	mov    %rax,%rdx
    b683:	48 89 c8             	mov    %rcx,%rax
    b686:	4d 85 e4             	test   %r12,%r12
    b689:	74 0a                	je     b695 <__divmodti4+0x85>
    b68b:	48 f7 d8             	neg    %rax
    b68e:	48 83 d2 00          	adc    $0x0,%rdx
    b692:	48 f7 da             	neg    %rdx
    b695:	4d 85 c0             	test   %r8,%r8
    b698:	74 0a                	je     b6a4 <__divmodti4+0x94>
    b69a:	48 f7 de             	neg    %rsi
    b69d:	48 83 d7 00          	adc    $0x0,%rdi
    b6a1:	48 f7 df             	neg    %rdi
    b6a4:	48 89 33             	mov    %rsi,(%rbx)
    b6a7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b6ab:	5b                   	pop    %rbx
    b6ac:	41 5c                	pop    %r12
    b6ae:	41 5d                	pop    %r13
    b6b0:	41 5e                	pop    %r14
    b6b2:	41 5f                	pop    %r15
    b6b4:	5d                   	pop    %rbp
    b6b5:	c3                   	ret
    b6b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b6bd:	00 00 00 
    b6c0:	4d 89 c4             	mov    %r8,%r12
    b6c3:	49 39 c1             	cmp    %rax,%r9
    b6c6:	0f 82 ce 00 00 00    	jb     b79a <__divmodti4+0x18a>
    b6cc:	31 ff                	xor    %edi,%edi
    b6ce:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b6d3:	48 63 c7             	movslq %edi,%rax
    b6d6:	be 40 00 00 00       	mov    $0x40,%esi
    b6db:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b6e0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b6e5:	48 29 c6             	sub    %rax,%rsi
    b6e8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b6ed:	48 09 c8             	or     %rcx,%rax
    b6f0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b6f5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b6fa:	49 89 c6             	mov    %rax,%r14
    b6fd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b701:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b706:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b70b:	49 09 c1             	or     %rax,%r9
    b70e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b712:	4c 89 c8             	mov    %r9,%rax
    b715:	49 f7 f6             	div    %r14
    b718:	48 89 d1             	mov    %rdx,%rcx
    b71b:	49 89 c3             	mov    %rax,%r11
    b71e:	49 89 c1             	mov    %rax,%r9
    b721:	49 f7 e2             	mul    %r10
    b724:	49 89 c6             	mov    %rax,%r14
    b727:	49 89 d2             	mov    %rdx,%r10
    b72a:	48 39 d1             	cmp    %rdx,%rcx
    b72d:	72 07                	jb     b736 <__divmodti4+0x126>
    b72f:	75 17                	jne    b748 <__divmodti4+0x138>
    b731:	49 39 c7             	cmp    %rax,%r15
    b734:	73 12                	jae    b748 <__divmodti4+0x138>
    b736:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b73a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b73e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b742:	49 89 d2             	mov    %rdx,%r10
    b745:	49 89 c6             	mov    %rax,%r14
    b748:	4c 89 f8             	mov    %r15,%rax
    b74b:	4c 29 f0             	sub    %r14,%rax
    b74e:	4c 19 d1             	sbb    %r10,%rcx
    b751:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b756:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b75b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b760:	48 09 c6             	or     %rax,%rsi
    b763:	48 89 cf             	mov    %rcx,%rdi
    b766:	31 c0                	xor    %eax,%eax
    b768:	4c 89 c9             	mov    %r9,%rcx
    b76b:	e9 10 ff ff ff       	jmp    b680 <__divmodti4+0x70>
    b770:	4c 89 d0             	mov    %r10,%rax
    b773:	4c 89 da             	mov    %r11,%rdx
    b776:	4d 89 c4             	mov    %r8,%r12
    b779:	49 89 f3             	mov    %rsi,%r11
    b77c:	48 f7 d8             	neg    %rax
    b77f:	49 f7 d4             	not    %r12
    b782:	48 83 d2 00          	adc    $0x0,%rdx
    b786:	49 89 c2             	mov    %rax,%r10
    b789:	48 f7 da             	neg    %rdx
    b78c:	48 89 d1             	mov    %rdx,%rcx
    b78f:	0f 84 cc fe ff ff    	je     b661 <__divmodti4+0x51>
    b795:	49 39 d1             	cmp    %rdx,%r9
    b798:	73 46                	jae    b7e0 <__divmodti4+0x1d0>
    b79a:	4c 89 cf             	mov    %r9,%rdi
    b79d:	31 c0                	xor    %eax,%eax
    b79f:	31 c9                	xor    %ecx,%ecx
    b7a1:	e9 da fe ff ff       	jmp    b680 <__divmodti4+0x70>
    b7a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b7ad:	00 00 00 
    b7b0:	4d 85 d2             	test   %r10,%r10
    b7b3:	75 0d                	jne    b7c2 <__divmodti4+0x1b2>
    b7b5:	b8 01 00 00 00       	mov    $0x1,%eax
    b7ba:	31 d2                	xor    %edx,%edx
    b7bc:	49 f7 f2             	div    %r10
    b7bf:	49 89 c2             	mov    %rax,%r10
    b7c2:	4c 89 c8             	mov    %r9,%rax
    b7c5:	31 d2                	xor    %edx,%edx
    b7c7:	49 f7 f2             	div    %r10
    b7ca:	49 89 c1             	mov    %rax,%r9
    b7cd:	4c 89 d8             	mov    %r11,%rax
    b7d0:	49 f7 f2             	div    %r10
    b7d3:	49 89 c3             	mov    %rax,%r11
    b7d6:	4c 89 c8             	mov    %r9,%rax
    b7d9:	e9 9a fe ff ff       	jmp    b678 <__divmodti4+0x68>
    b7de:	66 90                	xchg   %ax,%ax
    b7e0:	45 31 f6             	xor    %r14d,%r14d
    b7e3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    b7e8:	44 89 f7             	mov    %r14d,%edi
    b7eb:	45 85 f6             	test   %r14d,%r14d
    b7ee:	0f 85 df fe ff ff    	jne    b6d3 <__divmodti4+0xc3>
    b7f4:	4c 39 ca             	cmp    %r9,%rdx
    b7f7:	72 17                	jb     b810 <__divmodti4+0x200>
    b7f9:	31 c9                	xor    %ecx,%ecx
    b7fb:	48 39 c6             	cmp    %rax,%rsi
    b7fe:	73 10                	jae    b810 <__divmodti4+0x200>
    b800:	4c 89 cf             	mov    %r9,%rdi
    b803:	31 c0                	xor    %eax,%eax
    b805:	e9 76 fe ff ff       	jmp    b680 <__divmodti4+0x70>
    b80a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b810:	4c 89 de             	mov    %r11,%rsi
    b813:	b9 01 00 00 00       	mov    $0x1,%ecx
    b818:	48 29 c6             	sub    %rax,%rsi
    b81b:	49 19 d1             	sbb    %rdx,%r9
    b81e:	eb e0                	jmp    b800 <__divmodti4+0x1f0>

000000000000b820 <atexit>:
    b820:	f3 0f 1e fa          	endbr64
    b824:	48 8b 15 dd 47 00 00 	mov    0x47dd(%rip),%rdx        # 10008 <__dso_handle>
    b82b:	31 f6                	xor    %esi,%esi
    b82d:	e9 2e 7e ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b834 <_fini>:
    b834:	f3 0f 1e fa          	endbr64
    b838:	48 83 ec 08          	sub    $0x8,%rsp
    b83c:	48 83 c4 08          	add    $0x8,%rsp
    b840:	c3                   	ret
