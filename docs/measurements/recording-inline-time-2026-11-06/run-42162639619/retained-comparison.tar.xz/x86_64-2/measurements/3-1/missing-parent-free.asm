
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/missing-parent-free:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 df 00 00 	mov    0xdfd1(%rip),%rax        # 10fe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 dd 00 00    	push   0xddf2(%rip)        # 10e18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 dd 00 00    	jmp    *0xddf4(%rip)        # 10e20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 dc 00 00    	jmp    *0xdc66(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e da 00 00    	jmp    *0xda8e(%rip)        # 10e28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 da 00 00    	jmp    *0xda86(%rip)        # 10e30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e da 00 00    	jmp    *0xda7e(%rip)        # 10e38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 da 00 00    	jmp    *0xda76(%rip)        # 10e40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e da 00 00    	jmp    *0xda6e(%rip)        # 10e48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10ea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10ea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10eb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10eb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10ec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10ec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10ed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10ed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10ef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10ef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10f00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10f08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10f10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10f18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10f20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10f28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10f30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10f38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10fa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10fa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10fb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10fb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10fc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10fc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d b8 99 00 00 	lea    0x99b8(%rip),%r9        # d0cf <_IO_stdin_used+0xcf>
    3717:	4c 8d 05 b5 99 00 00 	lea    0x99b5(%rip),%r8        # d0d3 <_IO_stdin_used+0xd3>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 64 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 0a 0d 00 00       	call   4450 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 75 fc ff ff       	call   33c0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 70 fc ff ff       	call   33c0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 6b fc ff ff       	call   33c0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 bb 00 00 	lea    0xbba1(%rip),%rax        # f320 <fwp_fn_table>
    377f:	48 89 05 f2 7c 06 00 	mov    %rax,0x67cf2(%rip)        # 6b478 <fwp_fns>
    3786:	48 8b 05 93 d8 00 00 	mov    0xd893(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ec 7c 06 00 	mov    %rax,0x67cec(%rip)        # 6b480 <fwp_prog_out>
    3794:	e8 27 0e 00 00       	call   45c0 <fwp_now_ns>
    3799:	48 8d 3d 4e 9b 00 00 	lea    0x9b4e(%rip),%rdi        # d2ee <_IO_stdin_used+0x2ee>
    37a0:	e8 eb fb ff ff       	call   3390 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 4e fc ff ff       	call   3410 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 d8 00 00 	mov    0xd818(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 ba fd ff ff       	call   35d0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 0b fd ff ff       	call   3530 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 b1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 8a fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 bf 62 00 00 	lea    0x62bf(%rip),%rdx        # 9b20 <fwp_main_thread>
    3861:	e8 7a fd ff ff       	call   35e0 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 be fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 02 fe ff ff       	call   3690 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 d7 00 00 	mov    0xd783(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    389d:	e8 fe fc ff ff       	call   35a0 <fflush@plt>
    38a2:	8b 05 d8 d7 01 00    	mov    0x1d7d8(%rip),%eax        # 21080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 2f fc ff ff       	call   3500 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d fe 99 00 00 	lea    0x99fe(%rip),%rdi        # d2f7 <_IO_stdin_used+0x2f7>
    38f9:	e8 52 0b 00 00       	call   4450 <fwp_trap>
    38fe:	e8 4d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    3903:	48 8d 3d 56 a3 00 00 	lea    0xa356(%rip),%rdi        # dc60 <_IO_stdin_used+0xc60>
    390a:	e8 41 0b 00 00       	call   4450 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 17 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 10 a3 00 00 	lea    0xa310(%rip),%rdi        # dc38 <_IO_stdin_used+0xc38>
    3928:	e8 23 0b 00 00       	call   4450 <fwp_trap>
    392d:	48 8d 3d d4 a2 00 00 	lea    0xa2d4(%rip),%rdi        # dc08 <_IO_stdin_used+0xc08>
    3934:	e8 17 0b 00 00       	call   4450 <fwp_trap>
    3939:	48 8d 3d a0 a2 00 00 	lea    0xa2a0(%rip),%rdi        # dbe0 <_IO_stdin_used+0xbe0>
    3940:	e8 0b 0b 00 00       	call   4450 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 5b d6 00 00    	call   *0xd65b(%rip)        # 10fd0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 d6 00 00 	lea    0xd699(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 d6 00 00 	lea    0xd692(%rip),%rax        # 11020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 3e d6 00 00 	mov    0xd63e(%rip),%rax        # 10fd8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 d6 00 00 	lea    0xd669(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 d6 00 00 	lea    0xd662(%rip),%rsi        # 11020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 0d d6 00 00 	mov    0xd60d(%rip),%rax        # 10fe8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d d6 00 00 00 	cmpb   $0x0,0xd64d(%rip)        # 11048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d ea d5 00 00 	cmpq   $0x0,0xd5ea(%rip)        # 10ff0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 69 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 d6 00 00 01 	movb   $0x1,0xd625(%rip)        # 11048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 8c f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <ad_raw_record>:
    3c00:	89 c8                	mov    %ecx,%eax
    3c02:	4c 8d 05 97 d5 04 00 	lea    0x4d597(%rip),%r8        # 511a0 <ad_raw_live>
    3c09:	49 89 f1             	mov    %rsi,%r9
    3c0c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3c13:	00 
    3c14:	48 89 d6             	mov    %rdx,%rsi
    3c17:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3c1a:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3c1e:	48 8d 0d 3b d5 04 00 	lea    0x4d53b(%rip),%rcx        # 51160 <ad_raw_requests>
    3c25:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c2a:	48 8d 0d 0f d5 04 00 	lea    0x4d50f(%rip),%rcx        # 51140 <ad_raw_bytes>
    3c31:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c35:	48 01 f2             	add    %rsi,%rdx
    3c38:	48 8d 0d 41 d5 04 00 	lea    0x4d541(%rip),%rcx        # 51180 <ad_raw_peak>
    3c3f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c43:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c47:	4c 89 0f             	mov    %r9,(%rdi)
    3c4a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c4e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c52:	73 04                	jae    3c58 <ad_raw_record+0x58>
    3c54:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c58:	66 0f 6f 05 50 d5 04 	movdqa 0x4d550(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    3c5f:	00 
    3c60:	66 0f d4 05 38 d5 04 	paddq  0x4d538(%rip),%xmm0        # 511a0 <ad_raw_live>
    3c67:	00 
    3c68:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c6c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c71:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c75:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c7a:	48 39 05 9f d4 04 00 	cmp    %rax,0x4d49f(%rip)        # 51120 <ad_raw_total_peak>
    3c81:	73 08                	jae    3c8b <ad_raw_record+0x8b>
    3c83:	66 0f d6 05 95 d4 04 	movq   %xmm0,0x4d495(%rip)        # 51120 <ad_raw_total_peak>
    3c8a:	00 
    3c8b:	c3                   	ret
    3c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c90 <fwp_tape_unlink_scope>:
    3c90:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c94:	48 85 d2             	test   %rdx,%rdx
    3c97:	74 3e                	je     3cd7 <fwp_tape_unlink_scope+0x47>
    3c99:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c9c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3ca0:	85 c9                	test   %ecx,%ecx
    3ca2:	78 3c                	js     3ce0 <fwp_tape_unlink_scope+0x50>
    3ca4:	48 63 d1             	movslq %ecx,%rdx
    3ca7:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3cab:	48 03 15 3e d4 01 00 	add    0x1d43e(%rip),%rdx        # 210f0 <fwp_tapes>
    3cb2:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3cb5:	85 c0                	test   %eax,%eax
    3cb7:	78 0e                	js     3cc7 <fwp_tape_unlink_scope+0x37>
    3cb9:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3cbd:	48 03 05 2c d4 01 00 	add    0x1d42c(%rip),%rax        # 210f0 <fwp_tapes>
    3cc4:	89 48 58             	mov    %ecx,0x58(%rax)
    3cc7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cce:	00 
    3ccf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cd6:	ff 
    3cd7:	c3                   	ret
    3cd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cdf:	00 
    3ce0:	89 02                	mov    %eax,(%rdx)
    3ce2:	eb d1                	jmp    3cb5 <fwp_tape_unlink_scope+0x25>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_args173>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	c3                   	ret
    3cf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cfc:	00 00 00 00 

0000000000003d00 <fwp_flush>:
    3d00:	48 8b 3d 79 77 06 00 	mov    0x67779(%rip),%rdi        # 6b480 <fwp_prog_out>
    3d07:	48 85 ff             	test   %rdi,%rdi
    3d0a:	74 1c                	je     3d28 <fwp_flush+0x28>
    3d0c:	48 83 ec 08          	sub    $0x8,%rsp
    3d10:	e8 8b f8 ff ff       	call   35a0 <fflush@plt>
    3d15:	48 8b 3d 04 d3 00 00 	mov    0xd304(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d1c:	48 83 c4 08          	add    $0x8,%rsp
    3d20:	e9 7b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d25:	0f 1f 00             	nopl   (%rax)
    3d28:	48 8b 3d f1 d2 00 00 	mov    0xd2f1(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    3d2f:	e9 6c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d34:	90                   	nop
    3d35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d3c:	00 00 00 00 

0000000000003d40 <fwp_segv>:
    3d40:	f3 0f 1e fa          	endbr64
    3d44:	48 83 ec 28          	sub    $0x28,%rsp
    3d48:	48 8b 05 b1 5a 06 00 	mov    0x65ab1(%rip),%rax        # 69800 <fwp_cur>
    3d4f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d53:	41 89 f8             	mov    %edi,%r8d
    3d56:	48 85 c0             	test   %rax,%rax
    3d59:	74 6d                	je     3dc8 <fwp_segv+0x88>
    3d5b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d5f:	48 85 d2             	test   %rdx,%rdx
    3d62:	74 64                	je     3dc8 <fwp_segv+0x88>
    3d64:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d68:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d6d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d72:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d77:	e8 a4 f8 ff ff       	call   3620 <sysconf@plt>
    3d7c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d81:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d86:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d8b:	48 01 d0             	add    %rdx,%rax
    3d8e:	48 39 c1             	cmp    %rax,%rcx
    3d91:	b8 00 00 00 00       	mov    $0x0,%eax
    3d96:	40 0f 92 c6          	setb   %sil
    3d9a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3da1:	48 0f 42 d0          	cmovb  %rax,%rdx
    3da5:	31 c0                	xor    %eax,%eax
    3da7:	48 39 d1             	cmp    %rdx,%rcx
    3daa:	0f 93 c0             	setae  %al
    3dad:	21 f0                	and    %esi,%eax
    3daf:	85 c0                	test   %eax,%eax
    3db1:	75 4a                	jne    3dfd <fwp_segv+0xbd>
    3db3:	31 f6                	xor    %esi,%esi
    3db5:	44 89 c7             	mov    %r8d,%edi
    3db8:	48 83 c4 28          	add    $0x28,%rsp
    3dbc:	e9 6f f7 ff ff       	jmp    3530 <signal@plt>
    3dc1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3dc8:	48 8b 05 f9 53 06 00 	mov    0x653f9(%rip),%rax        # 691c8 <fwp_main_stack_top>
    3dcf:	48 85 c0             	test   %rax,%rax
    3dd2:	74 df                	je     3db3 <fwp_segv+0x73>
    3dd4:	48 2b 05 e5 53 06 00 	sub    0x653e5(%rip),%rax        # 691c0 <fwp_main_stack_size>
    3ddb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3de2:	48 39 d1             	cmp    %rdx,%rcx
    3de5:	0f 93 c2             	setae  %dl
    3de8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dee:	48 39 c1             	cmp    %rax,%rcx
    3df1:	0f 92 c0             	setb   %al
    3df4:	0f b6 c0             	movzbl %al,%eax
    3df7:	21 d0                	and    %edx,%eax
    3df9:	85 c0                	test   %eax,%eax
    3dfb:	74 b6                	je     3db3 <fwp_segv+0x73>
    3dfd:	e8 fe fe ff ff       	call   3d00 <fwp_flush>
    3e02:	bf 02 00 00 00       	mov    $0x2,%edi
    3e07:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3e0c:	48 8d 35 2d 9f 00 00 	lea    0x9f2d(%rip),%rsi        # dd40 <msg.4>
    3e13:	e8 08 f6 ff ff       	call   3420 <write@plt>
    3e18:	bf 65 00 00 00       	mov    $0x65,%edi
    3e1d:	e8 ae f5 ff ff       	call   33d0 <_exit@plt>
    3e22:	0f 1f 00             	nopl   (%rax)
    3e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e2c:	00 00 00 00 

0000000000003e30 <fwp_heap_oom>:
    3e30:	50                   	push   %rax
    3e31:	58                   	pop    %rax
    3e32:	ba 13 00 00 00       	mov    $0x13,%edx
    3e37:	be 01 00 00 00       	mov    $0x1,%esi
    3e3c:	48 8d 3d c5 91 00 00 	lea    0x91c5(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3e43:	48 83 ec 08          	sub    $0x8,%rsp
    3e47:	48 8b 0d f2 d1 00 00 	mov    0xd1f2(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    3e4e:	e8 0d f8 ff ff       	call   3660 <fwrite@plt>
    3e53:	31 ff                	xor    %edi,%edi
    3e55:	e8 46 f7 ff ff       	call   35a0 <fflush@plt>
    3e5a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e5f:	e8 1c f8 ff ff       	call   3680 <_Exit@plt>
    3e64:	90                   	nop
    3e65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e6c:	00 00 00 00 

0000000000003e70 <fwp_heap_chunks>:
    3e70:	41 54                	push   %r12
    3e72:	55                   	push   %rbp
    3e73:	53                   	push   %rbx
    3e74:	48 83 ff 01          	cmp    $0x1,%rdi
    3e78:	0f 84 62 01 00 00    	je     3fe0 <fwp_heap_chunks+0x170>
    3e7e:	48 8b 05 8b 6d 06 00 	mov    0x66d8b(%rip),%rax        # 6ac10 <fwp_heap+0x13f0>
    3e85:	4c 8d 05 84 6d 06 00 	lea    0x66d84(%rip),%r8        # 6ac10 <fwp_heap+0x13f0>
    3e8c:	48 8b 1d 65 6d 06 00 	mov    0x66d65(%rip),%rbx        # 6abf8 <fwp_heap+0x13d8>
    3e93:	48 39 d8             	cmp    %rbx,%rax
    3e96:	0f 83 57 01 00 00    	jae    3ff3 <fwp_heap_chunks+0x183>
    3e9c:	48 8b 0d 75 6d 06 00 	mov    0x66d75(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    3ea3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3ea7:	31 f6                	xor    %esi,%esi
    3ea9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3ead:	eb 1e                	jmp    3ecd <fwp_heap_chunks+0x5d>
    3eaf:	90                   	nop
    3eb0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3eb4:	48 39 cf             	cmp    %rcx,%rdi
    3eb7:	0f 84 03 01 00 00    	je     3fc0 <fwp_heap_chunks+0x150>
    3ebd:	48 83 c0 01          	add    $0x1,%rax
    3ec1:	48 89 ce             	mov    %rcx,%rsi
    3ec4:	48 83 c2 28          	add    $0x28,%rdx
    3ec8:	48 39 c3             	cmp    %rax,%rbx
    3ecb:	74 14                	je     3ee1 <fwp_heap_chunks+0x71>
    3ecd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3ed0:	74 de                	je     3eb0 <fwp_heap_chunks+0x40>
    3ed2:	48 83 c0 01          	add    $0x1,%rax
    3ed6:	31 f6                	xor    %esi,%esi
    3ed8:	48 83 c2 28          	add    $0x28,%rdx
    3edc:	48 39 c3             	cmp    %rax,%rbx
    3edf:	75 ec                	jne    3ecd <fwp_heap_chunks+0x5d>
    3ee1:	48 29 f3             	sub    %rsi,%rbx
    3ee4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ee8:	48 8b 3d 11 6d 06 00 	mov    0x66d11(%rip),%rdi        # 6ac00 <fwp_heap+0x13e0>
    3eef:	48 29 35 5a 6d 06 00 	sub    %rsi,0x66d5a(%rip)        # 6ac50 <fwp_heap+0x1430>
    3ef6:	48 39 ef             	cmp    %rbp,%rdi
    3ef9:	0f 83 96 00 00 00    	jae    3f95 <fwp_heap_chunks+0x125>
    3eff:	48 8b 05 ea 6c 06 00 	mov    0x66cea(%rip),%rax        # 6abf0 <fwp_heap+0x13d0>
    3f06:	48 39 e8             	cmp    %rbp,%rax
    3f09:	0f 82 eb 00 00 00    	jb     3ffa <fwp_heap_chunks+0x18a>
    3f0f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3f13:	ba 03 00 00 00       	mov    $0x3,%edx
    3f18:	49 39 c4             	cmp    %rax,%r12
    3f1b:	4c 0f 47 e0          	cmova  %rax,%r12
    3f1f:	4c 89 e6             	mov    %r12,%rsi
    3f22:	48 29 fe             	sub    %rdi,%rsi
    3f25:	48 c1 e7 10          	shl    $0x10,%rdi
    3f29:	48 03 3d a0 6c 06 00 	add    0x66ca0(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    3f30:	48 c1 e6 10          	shl    $0x10,%rsi
    3f34:	e8 c7 f6 ff ff       	call   3600 <mprotect@plt>
    3f39:	85 c0                	test   %eax,%eax
    3f3b:	0f 85 b9 00 00 00    	jne    3ffa <fwp_heap_chunks+0x18a>
    3f41:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f46:	e8 d5 f6 ff ff       	call   3620 <sysconf@plt>
    3f4b:	48 8b 35 ae 6c 06 00 	mov    0x66cae(%rip),%rsi        # 6ac00 <fwp_heap+0x13e0>
    3f52:	48 89 c1             	mov    %rax,%rcx
    3f55:	48 8b 05 bc 6c 06 00 	mov    0x66cbc(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    3f5c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f60:	48 89 ca             	mov    %rcx,%rdx
    3f63:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f67:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f6b:	48 f7 da             	neg    %rdx
    3f6e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f73:	48 21 d7             	and    %rdx,%rdi
    3f76:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f7a:	48 21 d6             	and    %rdx,%rsi
    3f7d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f82:	48 29 fe             	sub    %rdi,%rsi
    3f85:	e8 76 f6 ff ff       	call   3600 <mprotect@plt>
    3f8a:	85 c0                	test   %eax,%eax
    3f8c:	75 6c                	jne    3ffa <fwp_heap_chunks+0x18a>
    3f8e:	4c 89 25 6b 6c 06 00 	mov    %r12,0x66c6b(%rip)        # 6ac00 <fwp_heap+0x13e0>
    3f95:	48 89 ef             	mov    %rbp,%rdi
    3f98:	48 89 2d 59 6c 06 00 	mov    %rbp,0x66c59(%rip)        # 6abf8 <fwp_heap+0x13d8>
    3f9f:	48 c1 e7 10          	shl    $0x10,%rdi
    3fa3:	48 39 3d 3e 6c 06 00 	cmp    %rdi,0x66c3e(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3faa:	73 07                	jae    3fb3 <fwp_heap_chunks+0x143>
    3fac:	48 89 3d 35 6c 06 00 	mov    %rdi,0x66c35(%rip)        # 6abe8 <fwp_heap+0x13c8>
    3fb3:	48 89 d8             	mov    %rbx,%rax
    3fb6:	5b                   	pop    %rbx
    3fb7:	5d                   	pop    %rbp
    3fb8:	41 5c                	pop    %r12
    3fba:	c3                   	ret
    3fbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fc0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fc4:	48 29 f0             	sub    %rsi,%rax
    3fc7:	48 89 c3             	mov    %rax,%rbx
    3fca:	49 89 10             	mov    %rdx,(%r8)
    3fcd:	48 89 d8             	mov    %rbx,%rax
    3fd0:	48 29 3d 79 6c 06 00 	sub    %rdi,0x66c79(%rip)        # 6ac50 <fwp_heap+0x1430>
    3fd7:	5b                   	pop    %rbx
    3fd8:	5d                   	pop    %rbp
    3fd9:	41 5c                	pop    %r12
    3fdb:	c3                   	ret
    3fdc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fe0:	48 8b 05 21 6c 06 00 	mov    0x66c21(%rip),%rax        # 6ac08 <fwp_heap+0x13e8>
    3fe7:	4c 8d 05 1a 6c 06 00 	lea    0x66c1a(%rip),%r8        # 6ac08 <fwp_heap+0x13e8>
    3fee:	e9 99 fe ff ff       	jmp    3e8c <fwp_heap_chunks+0x1c>
    3ff3:	31 f6                	xor    %esi,%esi
    3ff5:	e9 ea fe ff ff       	jmp    3ee4 <fwp_heap_chunks+0x74>
    3ffa:	e8 31 fe ff ff       	call   3e30 <fwp_heap_oom>
    3fff:	90                   	nop

0000000000004000 <ad_raw_fail>:
    4000:	50                   	push   %rax
    4001:	58                   	pop    %rax
    4002:	48 8d 15 ff 96 00 00 	lea    0x96ff(%rip),%rdx        # d708 <_IO_stdin_used+0x708>
    4009:	be 02 00 00 00       	mov    $0x2,%esi
    400e:	31 c0                	xor    %eax,%eax
    4010:	48 83 ec 08          	sub    $0x8,%rsp
    4014:	48 89 f9             	mov    %rdi,%rcx
    4017:	48 8b 3d 22 d0 00 00 	mov    0xd022(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    401e:	e8 4d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4023:	bf e8 00 00 00       	mov    $0xe8,%edi
    4028:	e8 23 f6 ff ff       	call   3650 <exit@plt>
    402d:	0f 1f 00             	nopl   (%rax)

0000000000004030 <buf_grow>:
    4030:	48 83 ec 18          	sub    $0x18,%rsp
    4034:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4038:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    403c:	74 7e                	je     40bc <buf_grow+0x8c>
    403e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4045:	48 29 c2             	sub    %rax,%rdx
    4048:	48 39 f2             	cmp    %rsi,%rdx
    404b:	72 6f                	jb     40bc <buf_grow+0x8c>
    404d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4052:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4056:	48 89 f9             	mov    %rdi,%rcx
    4059:	48 39 d0             	cmp    %rdx,%rax
    405c:	73 48                	jae    40a6 <buf_grow+0x76>
    405e:	48 85 c0             	test   %rax,%rax
    4061:	75 15                	jne    4078 <buf_grow+0x48>
    4063:	48 83 fa 40          	cmp    $0x40,%rdx
    4067:	76 4c                	jbe    40b5 <buf_grow+0x85>
    4069:	b8 40 00 00 00       	mov    $0x40,%eax
    406e:	eb 08                	jmp    4078 <buf_grow+0x48>
    4070:	48 01 c0             	add    %rax,%rax
    4073:	48 39 d0             	cmp    %rdx,%rax
    4076:	73 38                	jae    40b0 <buf_grow+0x80>
    4078:	48 85 c0             	test   %rax,%rax
    407b:	79 f3                	jns    4070 <buf_grow+0x40>
    407d:	48 8b 39             	mov    (%rcx),%rdi
    4080:	48 89 d6             	mov    %rdx,%rsi
    4083:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4088:	48 89 14 24          	mov    %rdx,(%rsp)
    408c:	e8 1f f5 ff ff       	call   35b0 <realloc@plt>
    4091:	48 8b 14 24          	mov    (%rsp),%rdx
    4095:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    409a:	48 85 c0             	test   %rax,%rax
    409d:	74 1d                	je     40bc <buf_grow+0x8c>
    409f:	48 89 01             	mov    %rax,(%rcx)
    40a2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    40a6:	48 83 c4 18          	add    $0x18,%rsp
    40aa:	c3                   	ret
    40ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40b0:	48 89 c2             	mov    %rax,%rdx
    40b3:	eb c8                	jmp    407d <buf_grow+0x4d>
    40b5:	ba 40 00 00 00       	mov    $0x40,%edx
    40ba:	eb c1                	jmp    407d <buf_grow+0x4d>
    40bc:	48 8b 0d 7d cf 00 00 	mov    0xcf7d(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    40c3:	ba 13 00 00 00       	mov    $0x13,%edx
    40c8:	be 01 00 00 00       	mov    $0x1,%esi
    40cd:	48 8d 3d 34 8f 00 00 	lea    0x8f34(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    40d4:	e8 87 f5 ff ff       	call   3660 <fwrite@plt>
    40d9:	31 ff                	xor    %edi,%edi
    40db:	e8 c0 f4 ff ff       	call   35a0 <fflush@plt>
    40e0:	bf 66 00 00 00       	mov    $0x66,%edi
    40e5:	e8 96 f5 ff ff       	call   3680 <_Exit@plt>
    40ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040f0 <buf_put>:
    40f0:	41 54                	push   %r12
    40f2:	49 89 f4             	mov    %rsi,%r12
    40f5:	48 89 d6             	mov    %rdx,%rsi
    40f8:	55                   	push   %rbp
    40f9:	48 89 fd             	mov    %rdi,%rbp
    40fc:	53                   	push   %rbx
    40fd:	48 89 d3             	mov    %rdx,%rbx
    4100:	e8 2b ff ff ff       	call   4030 <buf_grow>
    4105:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4109:	48 89 da             	mov    %rbx,%rdx
    410c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4110:	4c 89 e6             	mov    %r12,%rsi
    4113:	e8 68 f4 ff ff       	call   3580 <memcpy@plt>
    4118:	48 8b 45 00          	mov    0x0(%rbp),%rax
    411c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4120:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4124:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4128:	5b                   	pop    %rbx
    4129:	5d                   	pop    %rbp
    412a:	41 5c                	pop    %r12
    412c:	c3                   	ret
    412d:	0f 1f 00             	nopl   (%rax)

0000000000004130 <fwp_cancel_tree.part.0>:
    4130:	48 3b 3d c9 56 06 00 	cmp    0x656c9(%rip),%rdi        # 69800 <fwp_cur>
    4137:	53                   	push   %rbx
    4138:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    413c:	74 35                	je     4173 <fwp_cancel_tree.part.0+0x43>
    413e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4142:	75 2f                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    4144:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4148:	75 29                	jne    4173 <fwp_cancel_tree.part.0+0x43>
    414a:	48 8b 05 8f 56 06 00 	mov    0x6568f(%rip),%rax        # 697e0 <fwp_ready_tail>
    4151:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4155:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    415c:	00 00 00 00 
    4160:	48 85 c0             	test   %rax,%rax
    4163:	74 33                	je     4198 <fwp_cancel_tree.part.0+0x68>
    4165:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    416c:	48 89 3d 6d 56 06 00 	mov    %rdi,0x6566d(%rip)        # 697e0 <fwp_ready_tail>
    4173:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4177:	48 85 db             	test   %rbx,%rbx
    417a:	74 17                	je     4193 <fwp_cancel_tree.part.0+0x63>
    417c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4180:	75 08                	jne    418a <fwp_cancel_tree.part.0+0x5a>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 a6 ff ff ff       	call   4130 <fwp_cancel_tree.part.0>
    418a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    418e:	48 85 db             	test   %rbx,%rbx
    4191:	75 e9                	jne    417c <fwp_cancel_tree.part.0+0x4c>
    4193:	5b                   	pop    %rbx
    4194:	c3                   	ret
    4195:	0f 1f 00             	nopl   (%rax)
    4198:	48 89 3d 49 56 06 00 	mov    %rdi,0x65649(%rip)        # 697e8 <fwp_ready_head>
    419f:	eb cb                	jmp    416c <fwp_cancel_tree.part.0+0x3c>
    41a1:	0f 1f 40 00          	nopl   0x0(%rax)
    41a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    41ac:	00 00 00 00 

00000000000041b0 <fwp_finish_float>:
    41b0:	53                   	push   %rbx
    41b1:	be 2e 00 00 00       	mov    $0x2e,%esi
    41b6:	48 89 fb             	mov    %rdi,%rbx
    41b9:	e8 b2 f2 ff ff       	call   3470 <strchr@plt>
    41be:	48 85 c0             	test   %rax,%rax
    41c1:	74 05                	je     41c8 <fwp_finish_float+0x18>
    41c3:	5b                   	pop    %rbx
    41c4:	c3                   	ret
    41c5:	0f 1f 00             	nopl   (%rax)
    41c8:	be 65 00 00 00       	mov    $0x65,%esi
    41cd:	48 89 df             	mov    %rbx,%rdi
    41d0:	e8 9b f2 ff ff       	call   3470 <strchr@plt>
    41d5:	48 85 c0             	test   %rax,%rax
    41d8:	75 e9                	jne    41c3 <fwp_finish_float+0x13>
    41da:	48 8d 35 19 90 00 00 	lea    0x9019(%rip),%rsi        # d1fa <_IO_stdin_used+0x1fa>
    41e1:	48 89 df             	mov    %rbx,%rdi
    41e4:	e8 c7 f4 ff ff       	call   36b0 <strstr@plt>
    41e9:	48 85 c0             	test   %rax,%rax
    41ec:	75 d5                	jne    41c3 <fwp_finish_float+0x13>
    41ee:	48 8d 35 27 8e 00 00 	lea    0x8e27(%rip),%rsi        # d01c <_IO_stdin_used+0x1c>
    41f5:	48 89 df             	mov    %rbx,%rdi
    41f8:	e8 b3 f4 ff ff       	call   36b0 <strstr@plt>
    41fd:	48 85 c0             	test   %rax,%rax
    4200:	75 c1                	jne    41c3 <fwp_finish_float+0x13>
    4202:	48 89 df             	mov    %rbx,%rdi
    4205:	e8 36 f2 ff ff       	call   3440 <strlen@plt>
    420a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    420f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4213:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4218:	5b                   	pop    %rbx
    4219:	c3                   	ret
    421a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004220 <ad_raw_report>:
    4220:	f3 0f 1e fa          	endbr64
    4224:	41 57                	push   %r15
    4226:	41 56                	push   %r14
    4228:	41 55                	push   %r13
    422a:	41 54                	push   %r12
    422c:	55                   	push   %rbp
    422d:	53                   	push   %rbx
    422e:	48 83 ec 38          	sub    $0x38,%rsp
    4232:	66 0f 6f 05 76 cf 04 	movdqa 0x4cf76(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    4239:	00 
    423a:	66 0f d4 05 5e cf 04 	paddq  0x4cf5e(%rip),%xmm0        # 511a0 <ad_raw_live>
    4241:	00 
    4242:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4249:	00 00 
    424b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4250:	31 c0                	xor    %eax,%eax
    4252:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4256:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    425b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    425f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4264:	48 85 ed             	test   %rbp,%rbp
    4267:	0f 85 d2 01 00 00    	jne    443f <ad_raw_report+0x21f>
    426d:	4c 8b 05 84 ce 01 00 	mov    0x1ce84(%rip),%r8        # 210f8 <ad_raw_before_shutdown>
    4274:	45 31 c9             	xor    %r9d,%r9d
    4277:	31 c0                	xor    %eax,%eax
    4279:	31 db                	xor    %ebx,%ebx
    427b:	48 8b 0d 9e ce 04 00 	mov    0x4ce9e(%rip),%rcx        # 51120 <ad_raw_total_peak>
    4282:	48 8b 3d b7 cd 00 00 	mov    0xcdb7(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4289:	49 89 e4             	mov    %rsp,%r12
    428c:	48 8d 15 c5 94 00 00 	lea    0x94c5(%rip),%rdx        # d758 <_IO_stdin_used+0x758>
    4293:	be 02 00 00 00       	mov    $0x2,%esi
    4298:	4c 8d 3d e1 ce 04 00 	lea    0x4cee1(%rip),%r15        # 51180 <ad_raw_peak>
    429f:	4c 8d 35 9a ce 04 00 	lea    0x4ce9a(%rip),%r14        # 51140 <ad_raw_bytes>
    42a6:	e8 c5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    42ab:	48 8d 05 79 8d 00 00 	lea    0x8d79(%rip),%rax        # d02b <_IO_stdin_used+0x2b>
    42b2:	f3 0f 7e 05 56 c9 00 	movq   0xc956(%rip),%xmm0        # 10c10 <d0+0x70>
    42b9:	00 
    42ba:	4c 8d 2d 9f ce 04 00 	lea    0x4ce9f(%rip),%r13        # 51160 <ad_raw_requests>
    42c1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42c6:	48 8d 05 6f 8d 00 00 	lea    0x8d6f(%rip),%rax        # d03c <_IO_stdin_used+0x3c>
    42cd:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42d1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42d6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42da:	f3 0f 7e 05 36 c9 00 	movq   0xc936(%rip),%xmm0        # 10c18 <d0+0x78>
    42e1:	00 
    42e2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42e6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42eb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42ef:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42f3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42f8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42fc:	48 85 db             	test   %rbx,%rbx
    42ff:	0f 84 0b 01 00 00    	je     4410 <ad_raw_report+0x1f0>
    4305:	52                   	push   %rdx
    4306:	48 8b 3d 33 cd 00 00 	mov    0xcd33(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    430d:	48 8d 0d 0c 8d 00 00 	lea    0x8d0c(%rip),%rcx        # d020 <_IO_stdin_used+0x20>
    4314:	48 8d 15 9d 94 00 00 	lea    0x949d(%rip),%rdx        # d7b8 <_IO_stdin_used+0x7b8>
    431b:	50                   	push   %rax
    431c:	be 02 00 00 00       	mov    $0x2,%esi
    4321:	31 c0                	xor    %eax,%eax
    4323:	48 83 c3 01          	add    $0x1,%rbx
    4327:	e8 44 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    432c:	5f                   	pop    %rdi
    432d:	41 58                	pop    %r8
    432f:	48 83 fb 04          	cmp    $0x4,%rbx
    4333:	75 b6                	jne    42eb <ad_raw_report+0xcb>
    4335:	48 8b 0d 04 cd 00 00 	mov    0xcd04(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    433c:	ba 13 00 00 00       	mov    $0x13,%edx
    4341:	be 01 00 00 00       	mov    $0x1,%esi
    4346:	48 8d 3d f8 8c 00 00 	lea    0x8cf8(%rip),%rdi        # d045 <_IO_stdin_used+0x45>
    434d:	e8 0e f3 ff ff       	call   3660 <fwrite@plt>
    4352:	48 83 3d a6 cd 01 00 	cmpq   $0x0,0x1cda6(%rip)        # 21100 <ad_raw_checkpoint_count>
    4359:	00 
    435a:	74 75                	je     43d1 <ad_raw_report+0x1b1>
    435c:	4c 8b 05 bd cd 01 00 	mov    0x1cdbd(%rip),%r8        # 21120 <ad_raw_checkpoints>
    4363:	4c 8b 0d be cd 01 00 	mov    0x1cdbe(%rip),%r9        # 21128 <ad_raw_checkpoints+0x8>
    436a:	48 8d 1d af cd 01 00 	lea    0x1cdaf(%rip),%rbx        # 21120 <ad_raw_checkpoints>
    4371:	48 8d 0d f4 8c 00 00 	lea    0x8cf4(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    4378:	48 8b 05 b1 cd 01 00 	mov    0x1cdb1(%rip),%rax        # 21130 <ad_raw_checkpoints+0x10>
    437f:	4c 8d 25 9a 8c 00 00 	lea    0x8c9a(%rip),%r12        # d020 <_IO_stdin_used+0x20>
    4386:	eb 1b                	jmp    43a3 <ad_raw_report+0x183>
    4388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    438f:	00 
    4390:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4394:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4398:	48 83 c3 18          	add    $0x18,%rbx
    439c:	4c 89 e1             	mov    %r12,%rcx
    439f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    43a3:	48 83 ec 08          	sub    $0x8,%rsp
    43a7:	be 02 00 00 00       	mov    $0x2,%esi
    43ac:	48 83 c5 01          	add    $0x1,%rbp
    43b0:	48 8b 3d 89 cc 00 00 	mov    0xcc89(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    43b7:	50                   	push   %rax
    43b8:	48 8d 15 39 94 00 00 	lea    0x9439(%rip),%rdx        # d7f8 <_IO_stdin_used+0x7f8>
    43bf:	31 c0                	xor    %eax,%eax
    43c1:	e8 aa f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43c6:	48 3b 2d 33 cd 01 00 	cmp    0x1cd33(%rip),%rbp        # 21100 <ad_raw_checkpoint_count>
    43cd:	59                   	pop    %rcx
    43ce:	5e                   	pop    %rsi
    43cf:	72 bf                	jb     4390 <ad_raw_report+0x170>
    43d1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43d6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43dd:	00 00 
    43df:	75 6a                	jne    444b <ad_raw_report+0x22b>
    43e1:	48 8b 0d 58 cc 00 00 	mov    0xcc58(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    43e8:	48 83 c4 38          	add    $0x38,%rsp
    43ec:	ba 04 00 00 00       	mov    $0x4,%edx
    43f1:	be 01 00 00 00       	mov    $0x1,%esi
    43f6:	5b                   	pop    %rbx
    43f7:	48 8d 3d 5b 8c 00 00 	lea    0x8c5b(%rip),%rdi        # d059 <_IO_stdin_used+0x59>
    43fe:	5d                   	pop    %rbp
    43ff:	41 5c                	pop    %r12
    4401:	41 5d                	pop    %r13
    4403:	41 5e                	pop    %r14
    4405:	41 5f                	pop    %r15
    4407:	e9 54 f2 ff ff       	jmp    3660 <fwrite@plt>
    440c:	0f 1f 40 00          	nopl   0x0(%rax)
    4410:	52                   	push   %rdx
    4411:	be 02 00 00 00       	mov    $0x2,%esi
    4416:	48 8b 3d 23 cc 00 00 	mov    0xcc23(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    441d:	48 8d 15 94 93 00 00 	lea    0x9394(%rip),%rdx        # d7b8 <_IO_stdin_used+0x7b8>
    4424:	50                   	push   %rax
    4425:	48 8d 0d 40 8c 00 00 	lea    0x8c40(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    442c:	31 c0                	xor    %eax,%eax
    442e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4433:	e8 38 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4438:	58                   	pop    %rax
    4439:	5a                   	pop    %rdx
    443a:	e9 ac fe ff ff       	jmp    42eb <ad_raw_report+0xcb>
    443f:	48 8d 3d ea 92 00 00 	lea    0x92ea(%rip),%rdi        # d730 <_IO_stdin_used+0x730>
    4446:	e8 b5 fb ff ff       	call   4000 <ad_raw_fail>
    444b:	e8 00 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004450 <fwp_trap>:
    4450:	55                   	push   %rbp
    4451:	48 89 fd             	mov    %rdi,%rbp
    4454:	53                   	push   %rbx
    4455:	48 83 ec 08          	sub    $0x8,%rsp
    4459:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4460:	ff ff 
    4462:	e8 99 f8 ff ff       	call   3d00 <fwp_flush>
    4467:	31 c0                	xor    %eax,%eax
    4469:	48 89 e9             	mov    %rbp,%rcx
    446c:	be 02 00 00 00       	mov    $0x2,%esi
    4471:	48 8b 3d c8 cb 00 00 	mov    0xcbc8(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4478:	48 8d 15 df 8b 00 00 	lea    0x8bdf(%rip),%rdx        # d05e <_IO_stdin_used+0x5e>
    447f:	e8 ec f1 ff ff       	call   3670 <__fprintf_chk@plt>
    4484:	48 85 db             	test   %rbx,%rbx
    4487:	74 16                	je     449f <fwp_trap+0x4f>
    4489:	48 8b 3d b0 cb 00 00 	mov    0xcbb0(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4490:	e8 0b f1 ff ff       	call   35a0 <fflush@plt>
    4495:	bf 65 00 00 00       	mov    $0x65,%edi
    449a:	e8 e1 f1 ff ff       	call   3680 <_Exit@plt>
    449f:	bf 65 00 00 00       	mov    $0x65,%edi
    44a4:	e8 a7 f1 ff ff       	call   3650 <exit@plt>
    44a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000044b0 <fwp_closure_drop_push>:
    44b0:	41 56                	push   %r14
    44b2:	41 54                	push   %r12
    44b4:	49 89 f4             	mov    %rsi,%r12
    44b7:	55                   	push   %rbp
    44b8:	48 89 fd             	mov    %rdi,%rbp
    44bb:	53                   	push   %rbx
    44bc:	48 83 ec 18          	sub    $0x18,%rsp
    44c0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44c4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44c8:	74 26                	je     44f0 <fwp_closure_drop_push+0x40>
    44ca:	4c 8b 07             	mov    (%rdi),%r8
    44cd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44d4:	00 
    44d5:	48 83 c3 01          	add    $0x1,%rbx
    44d9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44dd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44e1:	48 83 c4 18          	add    $0x18,%rsp
    44e5:	5b                   	pop    %rbx
    44e6:	5d                   	pop    %rbp
    44e7:	41 5c                	pop    %r12
    44e9:	41 5e                	pop    %r14
    44eb:	c3                   	ret
    44ec:	0f 1f 40 00          	nopl   0x0(%rax)
    44f0:	48 89 d8             	mov    %rbx,%rax
    44f3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44f7:	0f 85 a9 00 00 00    	jne    45a6 <fwp_closure_drop_push+0xf6>
    44fd:	48 89 d9             	mov    %rbx,%rcx
    4500:	48 c1 e1 04          	shl    $0x4,%rcx
    4504:	48 89 cf             	mov    %rcx,%rdi
    4507:	48 89 0c 24          	mov    %rcx,(%rsp)
    450b:	e8 80 f0 ff ff       	call   3590 <malloc@plt>
    4510:	48 8b 0c 24          	mov    (%rsp),%rcx
    4514:	48 85 c0             	test   %rax,%rax
    4517:	74 5f                	je     4578 <fwp_closure_drop_push+0xc8>
    4519:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    451d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4524:	00 
    4525:	48 89 c7             	mov    %rax,%rdi
    4528:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    452c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4531:	48 89 34 24          	mov    %rsi,(%rsp)
    4535:	e8 16 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    453a:	48 8b 34 24          	mov    (%rsp),%rsi
    453e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4543:	49 89 c0             	mov    %rax,%r8
    4546:	48 8d 45 18          	lea    0x18(%rbp),%rax
    454a:	48 39 c6             	cmp    %rax,%rsi
    454d:	74 1c                	je     456b <fwp_closure_drop_push+0xbb>
    454f:	48 89 f7             	mov    %rsi,%rdi
    4552:	4c 89 04 24          	mov    %r8,(%rsp)
    4556:	e8 55 ee ff ff       	call   33b0 <free@plt>
    455b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    455f:	4c 8b 04 24          	mov    (%rsp),%r8
    4563:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    456a:	00 
    456b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    456f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4573:	e9 5d ff ff ff       	jmp    44d5 <fwp_closure_drop_push+0x25>
    4578:	48 8b 0d c1 ca 00 00 	mov    0xcac1(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    457f:	ba 13 00 00 00       	mov    $0x13,%edx
    4584:	be 01 00 00 00       	mov    $0x1,%esi
    4589:	48 8d 3d 78 8a 00 00 	lea    0x8a78(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4590:	e8 cb f0 ff ff       	call   3660 <fwrite@plt>
    4595:	31 ff                	xor    %edi,%edi
    4597:	e8 04 f0 ff ff       	call   35a0 <fflush@plt>
    459c:	bf 66 00 00 00       	mov    $0x66,%edi
    45a1:	e8 da f0 ff ff       	call   3680 <_Exit@plt>
    45a6:	48 8d 3d c0 8a 00 00 	lea    0x8ac0(%rip),%rdi        # d06d <_IO_stdin_used+0x6d>
    45ad:	e8 9e fe ff ff       	call   4450 <fwp_trap>
    45b2:	0f 1f 00             	nopl   (%rax)
    45b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45bc:	00 00 00 00 

00000000000045c0 <fwp_now_ns>:
    45c0:	53                   	push   %rbx
    45c1:	bf 01 00 00 00       	mov    $0x1,%edi
    45c6:	48 83 ec 20          	sub    $0x20,%rsp
    45ca:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45d1:	00 00 
    45d3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45d8:	31 db                	xor    %ebx,%ebx
    45da:	48 89 e6             	mov    %rsp,%rsi
    45dd:	e8 2e ee ff ff       	call   3410 <clock_gettime@plt>
    45e2:	85 c0                	test   %eax,%eax
    45e4:	75 52                	jne    4638 <fwp_now_ns+0x78>
    45e6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45eb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45f0:	48 f7 2c 24          	imulq  (%rsp)
    45f4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45fb:	48 89 f7             	mov    %rsi,%rdi
    45fe:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4602:	48 01 f0             	add    %rsi,%rax
    4605:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    460c:	00 00 80 
    460f:	48 11 fa             	adc    %rdi,%rdx
    4612:	31 ff                	xor    %edi,%edi
    4614:	48 01 c6             	add    %rax,%rsi
    4617:	48 11 d7             	adc    %rdx,%rdi
    461a:	48 39 f1             	cmp    %rsi,%rcx
    461d:	48 19 fb             	sbb    %rdi,%rbx
    4620:	72 27                	jb     4649 <fwp_now_ns+0x89>
    4622:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4627:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    462e:	00 00 
    4630:	75 12                	jne    4644 <fwp_now_ns+0x84>
    4632:	48 83 c4 20          	add    $0x20,%rsp
    4636:	5b                   	pop    %rbx
    4637:	c3                   	ret
    4638:	48 8d 3d 48 8a 00 00 	lea    0x8a48(%rip),%rdi        # d087 <_IO_stdin_used+0x87>
    463f:	e8 0c fe ff ff       	call   4450 <fwp_trap>
    4644:	e8 07 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4649:	48 8d 3d e8 91 00 00 	lea    0x91e8(%rip),%rdi        # d838 <_IO_stdin_used+0x838>
    4650:	e8 fb fd ff ff       	call   4450 <fwp_trap>
    4655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    465c:	00 00 00 00 

0000000000004660 <fwp_closure_drop.part.0>:
    4660:	53                   	push   %rbx
    4661:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4668:	66 0f 6f 05 20 97 00 	movdqa 0x9720(%rip),%xmm0        # dd90 <msg.4+0x50>
    466f:	00 
    4670:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4677:	00 00 
    4679:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4680:	00 
    4681:	48 89 fe             	mov    %rdi,%rsi
    4684:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4689:	48 89 e7             	mov    %rsp,%rdi
    468c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4690:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4695:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    469c:	ff ff 
    469e:	e8 0d fe ff ff       	call   44b0 <fwp_closure_drop_push>
    46a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46a8:	48 85 c0             	test   %rax,%rax
    46ab:	74 39                	je     46e6 <fwp_closure_drop.part.0+0x86>
    46ad:	0f 1f 00             	nopl   (%rax)
    46b0:	48 8b 14 24          	mov    (%rsp),%rdx
    46b4:	48 83 e8 01          	sub    $0x1,%rax
    46b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    46bd:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46c1:	8b 07                	mov    (%rdi),%eax
    46c3:	48 c1 e0 05          	shl    $0x5,%rax
    46c7:	48 03 05 aa 6d 06 00 	add    0x66daa(%rip),%rax        # 6b478 <fwp_fns>
    46ce:	48 8b 40 18          	mov    0x18(%rax),%rax
    46d2:	48 85 c0             	test   %rax,%rax
    46d5:	74 46                	je     471d <fwp_closure_drop.part.0+0xbd>
    46d7:	31 f6                	xor    %esi,%esi
    46d9:	ff 50 08             	call   *0x8(%rax)
    46dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46e1:	48 85 c0             	test   %rax,%rax
    46e4:	75 ca                	jne    46b0 <fwp_closure_drop.part.0+0x50>
    46e6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46ed:	ff ff 00 00 00 00 
    46f3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46f7:	48 39 df             	cmp    %rbx,%rdi
    46fa:	74 05                	je     4701 <fwp_closure_drop.part.0+0xa1>
    46fc:	e8 af ec ff ff       	call   33b0 <free@plt>
    4701:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4708:	00 
    4709:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4710:	00 00 
    4712:	75 15                	jne    4729 <fwp_closure_drop.part.0+0xc9>
    4714:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    471b:	5b                   	pop    %rbx
    471c:	c3                   	ret
    471d:	48 8d 3d 3c 91 00 00 	lea    0x913c(%rip),%rdi        # d860 <_IO_stdin_used+0x860>
    4724:	e8 27 fd ff ff       	call   4450 <fwp_trap>
    4729:	e8 22 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    472e:	66 90                	xchg   %ax,%ax

0000000000004730 <fwp_tape_of>:
    4730:	0f b7 d7             	movzwl %di,%edx
    4733:	48 85 d2             	test   %rdx,%rdx
    4736:	74 28                	je     4760 <fwp_tape_of+0x30>
    4738:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    473c:	48 39 05 a5 c9 01 00 	cmp    %rax,0x1c9a5(%rip)        # 210e8 <fwp_ntapes>
    4743:	7e 1b                	jle    4760 <fwp_tape_of+0x30>
    4745:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4749:	48 03 05 a0 c9 01 00 	add    0x1c9a0(%rip),%rax        # 210f0 <fwp_tapes>
    4750:	8b 50 04             	mov    0x4(%rax),%edx
    4753:	85 d2                	test   %edx,%edx
    4755:	74 09                	je     4760 <fwp_tape_of+0x30>
    4757:	48 c1 ff 10          	sar    $0x10,%rdi
    475b:	39 38                	cmp    %edi,(%rax)
    475d:	75 01                	jne    4760 <fwp_tape_of+0x30>
    475f:	c3                   	ret
    4760:	48 83 ec 08          	sub    $0x8,%rsp
    4764:	48 8d 3d 25 91 00 00 	lea    0x9125(%rip),%rdi        # d890 <_IO_stdin_used+0x890>
    476b:	e8 e0 fc ff ff       	call   4450 <fwp_trap>

0000000000004770 <fwp_format_g.constprop.0>:
    4770:	41 57                	push   %r15
    4772:	b9 40 00 00 00       	mov    $0x40,%ecx
    4777:	ba 02 00 00 00       	mov    $0x2,%edx
    477c:	4c 8d 05 20 89 00 00 	lea    0x8920(%rip),%r8        # d0a3 <_IO_stdin_used+0xa3>
    4783:	41 56                	push   %r14
    4785:	b8 01 00 00 00       	mov    $0x1,%eax
    478a:	41 55                	push   %r13
    478c:	41 54                	push   %r12
    478e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4792:	55                   	push   %rbp
    4793:	45 89 e1             	mov    %r12d,%r9d
    4796:	53                   	push   %rbx
    4797:	48 89 fb             	mov    %rdi,%rbx
    479a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    47a1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    47a8:	00 00 
    47aa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    47b1:	00 
    47b2:	41 89 f7             	mov    %esi,%r15d
    47b5:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    47ba:	be 40 00 00 00       	mov    $0x40,%esi
    47bf:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47c4:	4c 89 f7             	mov    %r14,%rdi
    47c7:	e8 d4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47cc:	be 65 00 00 00       	mov    $0x65,%esi
    47d1:	4c 89 f7             	mov    %r14,%rdi
    47d4:	e8 97 ec ff ff       	call   3470 <strchr@plt>
    47d9:	31 f6                	xor    %esi,%esi
    47db:	ba 0a 00 00 00       	mov    $0xa,%edx
    47e0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47e4:	48 89 c5             	mov    %rax,%rbp
    47e7:	e8 84 ed ff ff       	call   3570 <strtol@plt>
    47ec:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47f1:	49 89 c0             	mov    %rax,%r8
    47f4:	83 c0 05             	add    $0x5,%eax
    47f7:	83 f8 15             	cmp    $0x15,%eax
    47fa:	0f 87 e0 01 00 00    	ja     49e0 <fwp_format_g.constprop.0+0x270>
    4800:	45 89 e5             	mov    %r12d,%r13d
    4803:	45 29 c5             	sub    %r8d,%r13d
    4806:	45 85 ed             	test   %r13d,%r13d
    4809:	0f 8e 21 01 00 00    	jle    4930 <fwp_format_g.constprop.0+0x1c0>
    480f:	41 83 ff 01          	cmp    $0x1,%r15d
    4813:	0f 84 17 01 00 00    	je     4930 <fwp_format_g.constprop.0+0x1c0>
    4819:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    481e:	31 d2                	xor    %edx,%edx
    4820:	4d 63 df             	movslq %r15d,%r11
    4823:	3c 2d                	cmp    $0x2d,%al
    4825:	0f 94 c2             	sete   %dl
    4828:	4c 29 dd             	sub    %r11,%rbp
    482b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    482f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4833:	4d 89 f1             	mov    %r14,%r9
    4836:	4d 29 d1             	sub    %r10,%r9
    4839:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    483d:	3c 2d                	cmp    $0x2d,%al
    483f:	0f 84 fb 03 00 00    	je     4c40 <fwp_format_g.constprop.0+0x4d0>
    4845:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    484a:	b9 48 00 00 00       	mov    $0x48,%ecx
    484f:	48 89 e8             	mov    %rbp,%rax
    4852:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4856:	49 8d 72 01          	lea    0x1(%r10),%rsi
    485a:	49 83 c1 47          	add    $0x47,%r9
    485e:	45 85 c0             	test   %r8d,%r8d
    4861:	0f 88 f1 02 00 00    	js     4b58 <fwp_format_g.constprop.0+0x3e8>
    4867:	45 0f b6 12          	movzbl (%r10),%r10d
    486b:	4d 63 e0             	movslq %r8d,%r12
    486e:	44 88 10             	mov    %r10b,(%rax)
    4871:	41 83 f8 07          	cmp    $0x7,%r8d
    4875:	0f 87 2d 02 00 00    	ja     4aa8 <fwp_format_g.constprop.0+0x338>
    487b:	41 f6 c4 04          	test   $0x4,%r12b
    487f:	0f 85 f2 03 00 00    	jne    4c77 <fwp_format_g.constprop.0+0x507>
    4885:	45 85 e4             	test   %r12d,%r12d
    4888:	74 12                	je     489c <fwp_format_g.constprop.0+0x12c>
    488a:	45 0f b6 06          	movzbl (%r14),%r8d
    488e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4892:	41 f6 c4 02          	test   $0x2,%r12b
    4896:	0f 85 03 04 00 00    	jne    4c9f <fwp_format_g.constprop.0+0x52f>
    489c:	4c 29 e1             	sub    %r12,%rcx
    489f:	4c 01 e7             	add    %r12,%rdi
    48a2:	4c 89 fa             	mov    %r15,%rdx
    48a5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48aa:	48 83 e9 01          	sub    $0x1,%rcx
    48ae:	4d 63 ed             	movslq %r13d,%r13
    48b1:	48 89 0c 24          	mov    %rcx,(%rsp)
    48b5:	e8 96 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48ba:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48bf:	48 8b 0c 24          	mov    (%rsp),%rcx
    48c3:	ba 48 00 00 00       	mov    $0x48,%edx
    48c8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48cc:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48d0:	4c 89 c8             	mov    %r9,%rax
    48d3:	48 29 c8             	sub    %rcx,%rax
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48dd:	4c 29 c9             	sub    %r9,%rcx
    48e0:	4c 89 ea             	mov    %r13,%rdx
    48e3:	48 01 c1             	add    %rax,%rcx
    48e6:	e8 65 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48eb:	4c 01 e8             	add    %r13,%rax
    48ee:	48 29 e8             	sub    %rbp,%rax
    48f1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48f6:	48 39 d0             	cmp    %rdx,%rax
    48f9:	48 0f 47 c2          	cmova  %rdx,%rax
    48fd:	89 c1                	mov    %eax,%ecx
    48ff:	83 f8 08             	cmp    $0x8,%eax
    4902:	0f 83 18 02 00 00    	jae    4b20 <fwp_format_g.constprop.0+0x3b0>
    4908:	a8 04                	test   $0x4,%al
    490a:	0f 85 54 03 00 00    	jne    4c64 <fwp_format_g.constprop.0+0x4f4>
    4910:	85 c0                	test   %eax,%eax
    4912:	74 0f                	je     4923 <fwp_format_g.constprop.0+0x1b3>
    4914:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4919:	88 13                	mov    %dl,(%rbx)
    491b:	a8 02                	test   $0x2,%al
    491d:	0f 85 6b 03 00 00    	jne    4c8e <fwp_format_g.constprop.0+0x51e>
    4923:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4927:	eb 36                	jmp    495f <fwp_format_g.constprop.0+0x1ef>
    4929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4930:	45 31 c9             	xor    %r9d,%r9d
    4933:	45 85 ed             	test   %r13d,%r13d
    4936:	4c 8d 05 75 87 00 00 	lea    0x8775(%rip),%r8        # d0b2 <_IO_stdin_used+0xb2>
    493d:	48 89 df             	mov    %rbx,%rdi
    4940:	45 0f 49 cd          	cmovns %r13d,%r9d
    4944:	ba 02 00 00 00       	mov    $0x2,%edx
    4949:	be 90 01 00 00       	mov    $0x190,%esi
    494e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4955:	b8 01 00 00 00       	mov    $0x1,%eax
    495a:	e8 41 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    495f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4964:	48 89 df             	mov    %rbx,%rdi
    4967:	e8 04 eb ff ff       	call   3470 <strchr@plt>
    496c:	48 85 c0             	test   %rax,%rax
    496f:	74 3f                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4971:	48 89 df             	mov    %rbx,%rdi
    4974:	e8 c7 ea ff ff       	call   3440 <strlen@plt>
    4979:	48 85 c0             	test   %rax,%rax
    497c:	75 0b                	jne    4989 <fwp_format_g.constprop.0+0x219>
    497e:	eb 30                	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4980:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4984:	48 85 c0             	test   %rax,%rax
    4987:	74 27                	je     49b0 <fwp_format_g.constprop.0+0x240>
    4989:	48 89 c2             	mov    %rax,%rdx
    498c:	48 83 e8 01          	sub    $0x1,%rax
    4990:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4994:	74 ea                	je     4980 <fwp_format_g.constprop.0+0x210>
    4996:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    499b:	0f 84 6f 01 00 00    	je     4b10 <fwp_format_g.constprop.0+0x3a0>
    49a1:	0f 1f 40 00          	nopl   0x0(%rax)
    49a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49ac:	00 00 00 00 
    49b0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    49b7:	00 
    49b8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    49bf:	00 00 
    49c1:	0f 85 ec 02 00 00    	jne    4cb3 <fwp_format_g.constprop.0+0x543>
    49c7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ce:	5b                   	pop    %rbx
    49cf:	5d                   	pop    %rbp
    49d0:	41 5c                	pop    %r12
    49d2:	41 5d                	pop    %r13
    49d4:	41 5e                	pop    %r14
    49d6:	41 5f                	pop    %r15
    49d8:	c3                   	ret
    49d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49e0:	4c 29 f5             	sub    %r14,%rbp
    49e3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49e8:	4c 89 f6             	mov    %r14,%rsi
    49eb:	4c 89 04 24          	mov    %r8,(%rsp)
    49ef:	49 89 ec             	mov    %rbp,%r12
    49f2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49f7:	4c 89 e2             	mov    %r12,%rdx
    49fa:	48 89 ef             	mov    %rbp,%rdi
    49fd:	e8 4e eb ff ff       	call   3550 <__memcpy_chk@plt>
    4a02:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4a08:	be 2e 00 00 00       	mov    $0x2e,%esi
    4a0d:	48 89 ef             	mov    %rbp,%rdi
    4a10:	e8 5b ea ff ff       	call   3470 <strchr@plt>
    4a15:	4c 8b 04 24          	mov    (%rsp),%r8
    4a19:	48 85 c0             	test   %rax,%rax
    4a1c:	74 40                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a1e:	4d 85 e4             	test   %r12,%r12
    4a21:	74 3b                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a23:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a28:	eb 23                	jmp    4a4d <fwp_format_g.constprop.0+0x2dd>
    4a2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a31:	00 00 00 00 
    4a35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a3c:	00 00 00 00 
    4a40:	c6 00 00             	movb   $0x0,(%rax)
    4a43:	48 83 e8 01          	sub    $0x1,%rax
    4a47:	49 83 ec 01          	sub    $0x1,%r12
    4a4b:	74 11                	je     4a5e <fwp_format_g.constprop.0+0x2ee>
    4a4d:	80 38 30             	cmpb   $0x30,(%rax)
    4a50:	74 ee                	je     4a40 <fwp_format_g.constprop.0+0x2d0>
    4a52:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a58:	0f 84 fb 01 00 00    	je     4c59 <fwp_format_g.constprop.0+0x4e9>
    4a5e:	44 89 c0             	mov    %r8d,%eax
    4a61:	ba 02 00 00 00       	mov    $0x2,%edx
    4a66:	49 89 e9             	mov    %rbp,%r9
    4a69:	be 90 01 00 00       	mov    $0x190,%esi
    4a6e:	f7 d8                	neg    %eax
    4a70:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a77:	48 89 df             	mov    %rbx,%rdi
    4a7a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a7e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a82:	41 83 e0 02          	and    $0x2,%r8d
    4a86:	41 83 c0 2b          	add    $0x2b,%r8d
    4a8a:	50                   	push   %rax
    4a8b:	31 c0                	xor    %eax,%eax
    4a8d:	41 50                	push   %r8
    4a8f:	4c 8d 05 12 86 00 00 	lea    0x8612(%rip),%r8        # d0a8 <_IO_stdin_used+0xa8>
    4a96:	e8 05 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a9b:	58                   	pop    %rax
    4a9c:	5a                   	pop    %rdx
    4a9d:	e9 0e ff ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4aa2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4aa8:	4d 8b 06             	mov    (%r14),%r8
    4aab:	48 83 c0 09          	add    $0x9,%rax
    4aaf:	4c 89 f2             	mov    %r14,%rdx
    4ab2:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4ab6:	4c 89 07             	mov    %r8,(%rdi)
    4ab9:	45 89 e0             	mov    %r12d,%r8d
    4abc:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4ac1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4ac6:	49 89 f8             	mov    %rdi,%r8
    4ac9:	49 29 c0             	sub    %rax,%r8
    4acc:	4c 29 c2             	sub    %r8,%rdx
    4acf:	45 01 e0             	add    %r12d,%r8d
    4ad2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ad6:	41 83 f8 08          	cmp    $0x8,%r8d
    4ada:	0f 82 bc fd ff ff    	jb     489c <fwp_format_g.constprop.0+0x12c>
    4ae0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ae4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ae8:	45 31 d2             	xor    %r10d,%r10d
    4aeb:	45 89 d3             	mov    %r10d,%r11d
    4aee:	41 83 c2 08          	add    $0x8,%r10d
    4af2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4af6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4afa:	45 39 c2             	cmp    %r8d,%r10d
    4afd:	72 ec                	jb     4aeb <fwp_format_g.constprop.0+0x37b>
    4aff:	48 8b 0c 24          	mov    (%rsp),%rcx
    4b03:	e9 94 fd ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4b08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4b0f:	00 
    4b10:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4b15:	e9 96 fe ff ff       	jmp    49b0 <fwp_format_g.constprop.0+0x240>
    4b1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b20:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b25:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b29:	48 89 ee             	mov    %rbp,%rsi
    4b2c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b30:	48 89 13             	mov    %rdx,(%rbx)
    4b33:	89 c2                	mov    %eax,%edx
    4b35:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b3a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b3f:	48 89 d9             	mov    %rbx,%rcx
    4b42:	48 29 f9             	sub    %rdi,%rcx
    4b45:	48 29 ce             	sub    %rcx,%rsi
    4b48:	01 c1                	add    %eax,%ecx
    4b4a:	c1 e9 03             	shr    $0x3,%ecx
    4b4d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b50:	e9 ce fd ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4b55:	0f 1f 00             	nopl   (%rax)
    4b58:	c6 00 30             	movb   $0x30,(%rax)
    4b5b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b5f:	4c 89 fa             	mov    %r15,%rdx
    4b62:	4c 89 e9             	mov    %r13,%rcx
    4b65:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b6a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b6f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b73:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b78:	e8 d3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b7d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b82:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b87:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b8c:	48 89 c7             	mov    %rax,%rdi
    4b8f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b93:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b98:	4c 89 c8             	mov    %r9,%rax
    4b9b:	4c 29 e8             	sub    %r13,%rax
    4b9e:	48 39 c8             	cmp    %rcx,%rax
    4ba1:	48 0f 42 c1          	cmovb  %rcx,%rax
    4ba5:	4d 29 cd             	sub    %r9,%r13
    4ba8:	49 01 ff             	add    %rdi,%r15
    4bab:	4c 01 e8             	add    %r13,%rax
    4bae:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4bb2:	74 3d                	je     4bf1 <fwp_format_g.constprop.0+0x481>
    4bb4:	41 f7 d0             	not    %r8d
    4bb7:	31 f6                	xor    %esi,%esi
    4bb9:	ba 48 00 00 00       	mov    $0x48,%edx
    4bbe:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4bc3:	48 39 d0             	cmp    %rdx,%rax
    4bc6:	48 0f 43 d0          	cmovae %rax,%rdx
    4bca:	48 89 d1             	mov    %rdx,%rcx
    4bcd:	48 29 c1             	sub    %rax,%rcx
    4bd0:	48 83 c1 01          	add    $0x1,%rcx
    4bd4:	48 39 d1             	cmp    %rdx,%rcx
    4bd7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bdb:	48 83 e8 01          	sub    $0x1,%rax
    4bdf:	48 83 c6 01          	add    $0x1,%rsi
    4be3:	48 29 d0             	sub    %rdx,%rax
    4be6:	48 01 c8             	add    %rcx,%rax
    4be9:	41 39 f0             	cmp    %esi,%r8d
    4bec:	7f cb                	jg     4bb9 <fwp_format_g.constprop.0+0x449>
    4bee:	4d 01 c7             	add    %r8,%r15
    4bf1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bf6:	41 0f b6 12          	movzbl (%r10),%edx
    4bfa:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bfe:	4c 89 f6             	mov    %r14,%rsi
    4c01:	48 39 c8             	cmp    %rcx,%rax
    4c04:	4c 89 1c 24          	mov    %r11,(%rsp)
    4c08:	48 0f 43 c8          	cmovae %rax,%rcx
    4c0c:	41 88 17             	mov    %dl,(%r15)
    4c0f:	48 89 ca             	mov    %rcx,%rdx
    4c12:	48 29 c2             	sub    %rax,%rdx
    4c15:	48 83 c2 01          	add    $0x1,%rdx
    4c19:	48 39 ca             	cmp    %rcx,%rdx
    4c1c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c20:	48 83 e8 01          	sub    $0x1,%rax
    4c24:	48 29 c8             	sub    %rcx,%rax
    4c27:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c2b:	49 63 d4             	movslq %r12d,%rdx
    4c2e:	e8 1d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c33:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c37:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c3b:	e9 ae fc ff ff       	jmp    48ee <fwp_format_g.constprop.0+0x17e>
    4c40:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c45:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c4a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c4f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c54:	e9 f9 fb ff ff       	jmp    4852 <fwp_format_g.constprop.0+0xe2>
    4c59:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c5f:	e9 fa fd ff ff       	jmp    4a5e <fwp_format_g.constprop.0+0x2ee>
    4c64:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c68:	89 13                	mov    %edx,(%rbx)
    4c6a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c6e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c72:	e9 ac fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c77:	41 8b 06             	mov    (%r14),%eax
    4c7a:	89 07                	mov    %eax,(%rdi)
    4c7c:	44 89 e0             	mov    %r12d,%eax
    4c7f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c84:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c89:	e9 0e fc ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4c8e:	89 c2                	mov    %eax,%edx
    4c90:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c95:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c9a:	e9 84 fc ff ff       	jmp    4923 <fwp_format_g.constprop.0+0x1b3>
    4c9f:	44 89 e0             	mov    %r12d,%eax
    4ca2:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4ca8:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4cae:	e9 e9 fb ff ff       	jmp    489c <fwp_format_g.constprop.0+0x12c>
    4cb3:	e8 98 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4cbf:	00 

0000000000004cc0 <fwp_heap_report>:
    4cc0:	f3 0f 1e fa          	endbr64
    4cc4:	41 54                	push   %r12
    4cc6:	48 8d 3d ea 83 00 00 	lea    0x83ea(%rip),%rdi        # d0b7 <_IO_stdin_used+0xb7>
    4ccd:	55                   	push   %rbp
    4cce:	53                   	push   %rbx
    4ccf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cd6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cdd:	00 00 
    4cdf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4ce6:	00 
    4ce7:	48 8d 35 54 85 00 00 	lea    0x8554(%rip),%rsi        # d242 <_IO_stdin_used+0x242>
    4cee:	e8 1d e9 ff ff       	call   3610 <fopen@plt>
    4cf3:	48 85 c0             	test   %rax,%rax
    4cf6:	0f 84 c5 00 00 00    	je     4dc1 <fwp_heap_report+0x101>
    4cfc:	48 89 c5             	mov    %rax,%rbp
    4cff:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d06:	48 89 e3             	mov    %rsp,%rbx
    4d09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4d10:	48 89 ea             	mov    %rbp,%rdx
    4d13:	be 00 01 00 00       	mov    $0x100,%esi
    4d18:	48 89 df             	mov    %rbx,%rdi
    4d1b:	e8 d0 e7 ff ff       	call   34f0 <fgets@plt>
    4d20:	48 85 c0             	test   %rax,%rax
    4d23:	74 2b                	je     4d50 <fwp_heap_report+0x90>
    4d25:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d2b:	75 e3                	jne    4d10 <fwp_heap_report+0x50>
    4d2d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d31:	75 dd                	jne    4d10 <fwp_heap_report+0x50>
    4d33:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d38:	75 d6                	jne    4d10 <fwp_heap_report+0x50>
    4d3a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d3f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d44:	31 f6                	xor    %esi,%esi
    4d46:	e8 25 e8 ff ff       	call   3570 <strtol@plt>
    4d4b:	49 89 c4             	mov    %rax,%r12
    4d4e:	eb c0                	jmp    4d10 <fwp_heap_report+0x50>
    4d50:	48 89 ef             	mov    %rbp,%rdi
    4d53:	e8 d8 e6 ff ff       	call   3430 <fclose@plt>
    4d58:	48 83 ec 08          	sub    $0x8,%rsp
    4d5c:	4c 8b 0d 85 5e 06 00 	mov    0x65e85(%rip),%r9        # 6abe8 <fwp_heap+0x13c8>
    4d63:	4c 8b 05 de 5e 06 00 	mov    0x65ede(%rip),%r8        # 6ac48 <fwp_heap+0x1428>
    4d6a:	48 8d 15 6f 8b 00 00 	lea    0x8b6f(%rip),%rdx        # d8e0 <_IO_stdin_used+0x8e0>
    4d71:	41 54                	push   %r12
    4d73:	48 8b 0d c6 5e 06 00 	mov    0x65ec6(%rip),%rcx        # 6ac40 <fwp_heap+0x1420>
    4d7a:	be 02 00 00 00       	mov    $0x2,%esi
    4d7f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d84:	f2 0f 10 0d d4 5e 06 	movsd  0x65ed4(%rip),%xmm1        # 6ac60 <fwp_heap+0x1440>
    4d8b:	00 
    4d8c:	f2 0f 10 05 c4 5e 06 	movsd  0x65ec4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    4d93:	00 
    4d94:	48 8b 3d a5 c2 00 00 	mov    0xc2a5(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    4d9b:	e8 d0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4da0:	58                   	pop    %rax
    4da1:	5a                   	pop    %rdx
    4da2:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4da9:	00 
    4daa:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4db1:	00 00 
    4db3:	75 15                	jne    4dca <fwp_heap_report+0x10a>
    4db5:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4dbc:	5b                   	pop    %rbx
    4dbd:	5d                   	pop    %rbp
    4dbe:	41 5c                	pop    %r12
    4dc0:	c3                   	ret
    4dc1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4dc8:	eb 8e                	jmp    4d58 <fwp_heap_report+0x98>
    4dca:	e8 81 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4dcf:	90                   	nop

0000000000004dd0 <fwp_heap_init>:
    4dd0:	66 0f 6f 05 c8 8f 00 	movdqa 0x8fc8(%rip),%xmm0        # dda0 <msg.4+0x60>
    4dd7:	00 
    4dd8:	41 54                	push   %r12
    4dda:	48 8d 05 7f 59 06 00 	lea    0x6597f(%rip),%rax        # 6a760 <fwp_heap+0xf40>
    4de1:	ba 00 01 00 00       	mov    $0x100,%edx
    4de6:	55                   	push   %rbp
    4de7:	66 0f 6f 15 f1 8f 00 	movdqa 0x8ff1(%rip),%xmm2        # dde0 <msg.4+0xa0>
    4dee:	00 
    4def:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4df3:	53                   	push   %rbx
    4df4:	0f 29 05 25 59 06 00 	movaps %xmm0,0x65925(%rip)        # 6a720 <fwp_heap+0xf00>
    4dfb:	66 0f 6f 05 ad 8f 00 	movdqa 0x8fad(%rip),%xmm0        # ddb0 <msg.4+0x70>
    4e02:	00 
    4e03:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4e07:	c7 05 b3 5d 06 00 01 	movl   $0x1,0x65db3(%rip)        # 6abc4 <fwp_heap+0x13a4>
    4e0e:	00 00 00 
    4e11:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4e16:	0f 29 05 13 59 06 00 	movaps %xmm0,0x65913(%rip)        # 6a730 <fwp_heap+0xf10>
    4e1d:	66 0f 6f 05 9b 8f 00 	movdqa 0x8f9b(%rip),%xmm0        # ddc0 <msg.4+0x80>
    4e24:	00 
    4e25:	0f 29 05 14 59 06 00 	movaps %xmm0,0x65914(%rip)        # 6a740 <fwp_heap+0xf20>
    4e2c:	66 0f 6f 05 9c 8f 00 	movdqa 0x8f9c(%rip),%xmm0        # ddd0 <msg.4+0x90>
    4e33:	00 
    4e34:	0f 29 05 15 59 06 00 	movaps %xmm0,0x65915(%rip)        # 6a750 <fwp_heap+0xf30>
    4e3b:	89 d3                	mov    %edx,%ebx
    4e3d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e41:	48 83 c0 10          	add    $0x10,%rax
    4e45:	01 d2                	add    %edx,%edx
    4e47:	c1 eb 02             	shr    $0x2,%ebx
    4e4a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e4e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e53:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e57:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e5c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e60:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e64:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e69:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e6e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e72:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e77:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e7b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e7f:	48 39 c7             	cmp    %rax,%rdi
    4e82:	75 b7                	jne    4e3b <fwp_heap_init+0x6b>
    4e84:	4c 8d 05 95 49 06 00 	lea    0x64995(%rip),%r8        # 69820 <fwp_heap>
    4e8b:	31 c9                	xor    %ecx,%ecx
    4e8d:	31 c0                	xor    %eax,%eax
    4e8f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e9d:	00 00 00 
    4ea0:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4ea7:	00 
    4ea8:	48 39 ca             	cmp    %rcx,%rdx
    4eab:	73 0f                	jae    4ebc <fwp_heap_init+0xec>
    4ead:	0f 1f 00             	nopl   (%rax)
    4eb0:	48 83 c0 01          	add    $0x1,%rax
    4eb4:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4eb7:	48 39 ca             	cmp    %rcx,%rdx
    4eba:	72 f4                	jb     4eb0 <fwp_heap_init+0xe0>
    4ebc:	48 83 c1 10          	add    $0x10,%rcx
    4ec0:	88 07                	mov    %al,(%rdi)
    4ec2:	48 83 c7 01          	add    $0x1,%rdi
    4ec6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ecd:	75 d1                	jne    4ea0 <fwp_heap_init+0xd0>
    4ecf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4ed6:	00 00 00 
    4ed9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ede:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ee5:	45 31 c9             	xor    %r9d,%r9d
    4ee8:	31 d2                	xor    %edx,%edx
    4eea:	31 ff                	xor    %edi,%edi
    4eec:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ef2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ef7:	4c 89 e6             	mov    %r12,%rsi
    4efa:	e8 61 e5 ff ff       	call   3460 <mmap@plt>
    4eff:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f03:	75 13                	jne    4f18 <fwp_heap_init+0x148>
    4f05:	48 c1 eb 02          	shr    $0x2,%rbx
    4f09:	83 ed 01             	sub    $0x1,%ebp
    4f0c:	75 d0                	jne    4ede <fwp_heap_init+0x10e>
    4f0e:	e8 1d ef ff ff       	call   3e30 <fwp_heap_oom>
    4f13:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4f18:	48 85 c0             	test   %rax,%rax
    4f1b:	74 f1                	je     4f0e <fwp_heap_init+0x13e>
    4f1d:	48 c1 eb 10          	shr    $0x10,%rbx
    4f21:	48 89 05 b0 5c 06 00 	mov    %rax,0x65cb0(%rip)        # 6abd8 <fwp_heap+0x13b8>
    4f28:	45 31 c9             	xor    %r9d,%r9d
    4f2b:	31 d2                	xor    %edx,%edx
    4f2d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f33:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f37:	31 ff                	xor    %edi,%edi
    4f39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f3f:	66 31 c0             	xor    %ax,%ax
    4f42:	48 c1 e6 03          	shl    $0x3,%rsi
    4f46:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f4b:	4c 89 25 8e 5c 06 00 	mov    %r12,0x65c8e(%rip)        # 6abe0 <fwp_heap+0x13c0>
    4f52:	48 89 05 77 5c 06 00 	mov    %rax,0x65c77(%rip)        # 6abd0 <fwp_heap+0x13b0>
    4f59:	48 89 1d 90 5c 06 00 	mov    %rbx,0x65c90(%rip)        # 6abf0 <fwp_heap+0x13d0>
    4f60:	48 89 35 b9 5c 06 00 	mov    %rsi,0x65cb9(%rip)        # 6ac20 <fwp_heap+0x1400>
    4f67:	e8 f4 e4 ff ff       	call   3460 <mmap@plt>
    4f6c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f70:	74 9c                	je     4f0e <fwp_heap_init+0x13e>
    4f72:	48 8d 3d 74 81 00 00 	lea    0x8174(%rip),%rdi        # d0ed <_IO_stdin_used+0xed>
    4f79:	48 89 05 98 5c 06 00 	mov    %rax,0x65c98(%rip)        # 6ac18 <fwp_heap+0x13f8>
    4f80:	e8 0b e4 ff ff       	call   3390 <getenv@plt>
    4f85:	48 89 c2             	mov    %rax,%rdx
    4f88:	31 c0                	xor    %eax,%eax
    4f8a:	48 85 d2             	test   %rdx,%rdx
    4f8d:	74 15                	je     4fa4 <fwp_heap_init+0x1d4>
    4f8f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f92:	74 10                	je     4fa4 <fwp_heap_init+0x1d4>
    4f94:	0f b6 02             	movzbl (%rdx),%eax
    4f97:	83 e8 30             	sub    $0x30,%eax
    4f9a:	74 13                	je     4faf <fwp_heap_init+0x1df>
    4f9c:	85 c0                	test   %eax,%eax
    4f9e:	0f 95 c0             	setne  %al
    4fa1:	0f b6 c0             	movzbl %al,%eax
    4fa4:	5b                   	pop    %rbx
    4fa5:	5d                   	pop    %rbp
    4fa6:	89 05 1c 5c 06 00    	mov    %eax,0x65c1c(%rip)        # 6abc8 <fwp_heap+0x13a8>
    4fac:	41 5c                	pop    %r12
    4fae:	c3                   	ret
    4faf:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4fb3:	85 c0                	test   %eax,%eax
    4fb5:	0f 95 c0             	setne  %al
    4fb8:	0f b6 c0             	movzbl %al,%eax
    4fbb:	eb e7                	jmp    4fa4 <fwp_heap_init+0x1d4>
    4fbd:	0f 1f 00             	nopl   (%rax)

0000000000004fc0 <fwp_wake_io>:
    4fc0:	48 8b 07             	mov    (%rdi),%rax
    4fc3:	48 85 c0             	test   %rax,%rax
    4fc6:	0f 84 f4 00 00 00    	je     50c0 <fwp_wake_io+0x100>
    4fcc:	53                   	push   %rbx
    4fcd:	4c 8b 05 0c 48 06 00 	mov    0x6480c(%rip),%r8        # 697e0 <fwp_ready_tail>
    4fd4:	49 89 f9             	mov    %rdi,%r9
    4fd7:	48 89 c2             	mov    %rax,%rdx
    4fda:	45 31 db             	xor    %r11d,%r11d
    4fdd:	45 31 d2             	xor    %r10d,%r10d
    4fe0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fe4:	eb 71                	jmp    5057 <fwp_wake_io+0x97>
    4fe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fed:	00 00 00 
    4ff0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4ff7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4ffe:	48 85 c9             	test   %rcx,%rcx
    5001:	74 07                	je     500a <fwp_wake_io+0x4a>
    5003:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    500a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    5011:	00 00 00 00 
    5015:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    501c:	49 8b 01             	mov    (%r9),%rax
    501f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5023:	75 2a                	jne    504f <fwp_wake_io+0x8f>
    5025:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5029:	75 24                	jne    504f <fwp_wake_io+0x8f>
    502b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    502f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5036:	00 00 00 00 
    503a:	4d 85 c0             	test   %r8,%r8
    503d:	74 51                	je     5090 <fwp_wake_io+0xd0>
    503f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5046:	49 89 d0             	mov    %rdx,%r8
    5049:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    504f:	48 89 c2             	mov    %rax,%rdx
    5052:	48 85 c0             	test   %rax,%rax
    5055:	74 49                	je     50a0 <fwp_wake_io+0xe0>
    5057:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    505e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5062:	48 85 ff             	test   %rdi,%rdi
    5065:	74 b8                	je     501f <fwp_wake_io+0x5f>
    5067:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    506e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5075:	48 85 f6             	test   %rsi,%rsi
    5078:	0f 85 72 ff ff ff    	jne    4ff0 <fwp_wake_io+0x30>
    507e:	48 89 0f             	mov    %rcx,(%rdi)
    5081:	e9 78 ff ff ff       	jmp    4ffe <fwp_wake_io+0x3e>
    5086:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    508d:	00 00 00 
    5090:	48 89 d3             	mov    %rdx,%rbx
    5093:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5099:	eb ab                	jmp    5046 <fwp_wake_io+0x86>
    509b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    50a0:	45 84 db             	test   %r11b,%r11b
    50a3:	74 07                	je     50ac <fwp_wake_io+0xec>
    50a5:	48 89 1d 3c 47 06 00 	mov    %rbx,0x6473c(%rip)        # 697e8 <fwp_ready_head>
    50ac:	45 84 d2             	test   %r10b,%r10b
    50af:	74 07                	je     50b8 <fwp_wake_io+0xf8>
    50b1:	4c 89 05 28 47 06 00 	mov    %r8,0x64728(%rip)        # 697e0 <fwp_ready_tail>
    50b8:	5b                   	pop    %rbx
    50b9:	c3                   	ret
    50ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50c0:	c3                   	ret
    50c1:	0f 1f 40 00          	nopl   0x0(%rax)
    50c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50cc:	00 00 00 00 

00000000000050d0 <ad_raw_free.part.0>:
    50d0:	48 8d 0d e9 c0 04 00 	lea    0x4c0e9(%rip),%rcx        # 511c0 <ad_raw_blocks>
    50d7:	31 c0                	xor    %eax,%eax
    50d9:	48 89 ca             	mov    %rcx,%rdx
    50dc:	eb 12                	jmp    50f0 <ad_raw_free.part.0+0x20>
    50de:	66 90                	xchg   %ax,%ax
    50e0:	48 83 c0 01          	add    $0x1,%rax
    50e4:	48 83 c2 18          	add    $0x18,%rdx
    50e8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ee:	74 40                	je     5130 <ad_raw_free.part.0+0x60>
    50f0:	48 3b 3a             	cmp    (%rdx),%rdi
    50f3:	75 eb                	jne    50e0 <ad_raw_free.part.0+0x10>
    50f5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50fd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    5101:	48 8d 0d 98 c0 04 00 	lea    0x4c098(%rip),%rcx        # 511a0 <ad_raw_live>
    5108:	8b 70 10             	mov    0x10(%rax),%esi
    510b:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5112:	00 
    5113:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    5117:	48 2b 50 08          	sub    0x8(%rax),%rdx
    511b:	0f 11 00             	movups %xmm0,(%rax)
    511e:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5122:	e9 89 e2 ff ff       	jmp    33b0 <free@plt>
    5127:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    512e:	00 00 
    5130:	48 83 ec 08          	sub    $0x8,%rsp
    5134:	48 8d 3d c2 7f 00 00 	lea    0x7fc2(%rip),%rdi        # d0fd <_IO_stdin_used+0xfd>
    513b:	e8 c0 ee ff ff       	call   4000 <ad_raw_fail>

0000000000005140 <fwp_tape_buffers_dispose>:
    5140:	53                   	push   %rbx
    5141:	48 89 fb             	mov    %rdi,%rbx
    5144:	48 8b 7f 10          	mov    0x10(%rdi),%rdi
    5148:	48 85 ff             	test   %rdi,%rdi
    514b:	74 05                	je     5152 <fwp_tape_buffers_dispose+0x12>
    514d:	e8 7e ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5152:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5156:	48 85 ff             	test   %rdi,%rdi
    5159:	74 05                	je     5160 <fwp_tape_buffers_dispose+0x20>
    515b:	e8 70 ff ff ff       	call   50d0 <ad_raw_free.part.0>
    5160:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5164:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    516b:	00 
    516c:	0f 11 03             	movups %xmm0,(%rbx)
    516f:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5173:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5177:	5b                   	pop    %rbx
    5178:	c3                   	ret
    5179:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000005180 <ad_raw_realloc>:
    5180:	41 55                	push   %r13
    5182:	41 54                	push   %r12
    5184:	55                   	push   %rbp
    5185:	53                   	push   %rbx
    5186:	48 83 ec 08          	sub    $0x8,%rsp
    518a:	48 85 f6             	test   %rsi,%rsi
    518d:	0f 84 b6 00 00 00    	je     5249 <ad_raw_realloc+0xc9>
    5193:	4c 8d 25 26 c0 04 00 	lea    0x4c026(%rip),%r12        # 511c0 <ad_raw_blocks>
    519a:	48 89 f5             	mov    %rsi,%rbp
    519d:	41 89 d5             	mov    %edx,%r13d
    51a0:	31 db                	xor    %ebx,%ebx
    51a2:	4c 89 e0             	mov    %r12,%rax
    51a5:	eb 2a                	jmp    51d1 <ad_raw_realloc+0x51>
    51a7:	0f 1f 00             	nopl   (%rax)
    51aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51b1:	00 00 00 00 
    51b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51bc:	00 00 00 00 
    51c0:	48 83 c3 01          	add    $0x1,%rbx
    51c4:	48 83 c0 18          	add    $0x18,%rax
    51c8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51cf:	74 4f                	je     5220 <ad_raw_realloc+0xa0>
    51d1:	48 3b 38             	cmp    (%rax),%rdi
    51d4:	75 ea                	jne    51c0 <ad_raw_realloc+0x40>
    51d6:	48 85 ff             	test   %rdi,%rdi
    51d9:	74 0b                	je     51e6 <ad_raw_realloc+0x66>
    51db:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51df:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51e4:	75 57                	jne    523d <ad_raw_realloc+0xbd>
    51e6:	48 89 ee             	mov    %rbp,%rsi
    51e9:	e8 c2 e3 ff ff       	call   35b0 <realloc@plt>
    51ee:	49 89 c2             	mov    %rax,%r10
    51f1:	48 85 c0             	test   %rax,%rax
    51f4:	74 16                	je     520c <ad_raw_realloc+0x8c>
    51f6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51fa:	44 89 e9             	mov    %r13d,%ecx
    51fd:	48 89 ea             	mov    %rbp,%rdx
    5200:	4c 89 d6             	mov    %r10,%rsi
    5203:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    5207:	e8 f4 e9 ff ff       	call   3c00 <ad_raw_record>
    520c:	48 83 c4 08          	add    $0x8,%rsp
    5210:	4c 89 d0             	mov    %r10,%rax
    5213:	5b                   	pop    %rbx
    5214:	5d                   	pop    %rbp
    5215:	41 5c                	pop    %r12
    5217:	41 5d                	pop    %r13
    5219:	c3                   	ret
    521a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5220:	48 85 ff             	test   %rdi,%rdi
    5223:	48 8d 05 e8 7e 00 00 	lea    0x7ee8(%rip),%rax        # d112 <_IO_stdin_used+0x112>
    522a:	48 8d 15 cc 7e 00 00 	lea    0x7ecc(%rip),%rdx        # d0fd <_IO_stdin_used+0xfd>
    5231:	48 0f 45 c2          	cmovne %rdx,%rax
    5235:	48 89 c7             	mov    %rax,%rdi
    5238:	e8 c3 ed ff ff       	call   4000 <ad_raw_fail>
    523d:	48 8d 3d 04 7f 00 00 	lea    0x7f04(%rip),%rdi        # d148 <_IO_stdin_used+0x148>
    5244:	e8 b7 ed ff ff       	call   4000 <ad_raw_fail>
    5249:	48 8d 3d dd 7e 00 00 	lea    0x7edd(%rip),%rdi        # d12d <_IO_stdin_used+0x12d>
    5250:	e8 ab ed ff ff       	call   4000 <ad_raw_fail>
    5255:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    525c:	00 00 00 00 

0000000000005260 <fwp_tape_buffers_release>:
    5260:	f3 0f 1e fa          	endbr64
    5264:	53                   	push   %rbx
    5265:	48 89 fb             	mov    %rdi,%rbx
    5268:	48 83 ec 10          	sub    $0x10,%rsp
    526c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5270:	48 85 c0             	test   %rax,%rax
    5273:	0f 88 d7 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5279:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    527d:	48 85 d2             	test   %rdx,%rdx
    5280:	0f 88 ca 00 00 00    	js     5350 <fwp_tape_buffers_release+0xf0>
    5286:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    528c:	0f 87 be 00 00 00    	ja     5350 <fwp_tape_buffers_release+0xf0>
    5292:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5296:	b8 00 00 08 00       	mov    $0x80000,%eax
    529b:	48 c1 e1 03          	shl    $0x3,%rcx
    529f:	48 29 c8             	sub    %rcx,%rax
    52a2:	48 c1 e8 03          	shr    $0x3,%rax
    52a6:	48 39 d0             	cmp    %rdx,%rax
    52a9:	0f 82 a1 00 00 00    	jb     5350 <fwp_tape_buffers_release+0xf0>
    52af:	48 8d 3d aa 7e 00 00 	lea    0x7eaa(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    52b6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    52bb:	48 89 14 24          	mov    %rdx,(%rsp)
    52bf:	e8 cc e0 ff ff       	call   3390 <getenv@plt>
    52c4:	48 8b 14 24          	mov    (%rsp),%rdx
    52c8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 09                	je     52db <fwp_tape_buffers_release+0x7b>
    52d2:	80 38 30             	cmpb   $0x30,(%rax)
    52d5:	0f 84 05 01 00 00    	je     53e0 <fwp_tape_buffers_release+0x180>
    52db:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52df:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52e3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52e9:	77 71                	ja     535c <fwp_tape_buffers_release+0xfc>
    52eb:	48 8d 3d ae bd 01 00 	lea    0x1bdae(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    52f2:	48 89 34 24          	mov    %rsi,(%rsp)
    52f6:	e8 45 fe ff ff       	call   5140 <fwp_tape_buffers_dispose>
    52fb:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52ff:	48 8b 34 24          	mov    (%rsp),%rsi
    5303:	0f 29 05 96 bd 01 00 	movaps %xmm0,0x1bd96(%rip)        # 210a0 <fwp_tape_workspace>
    530a:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    530f:	48 89 35 72 bd 01 00 	mov    %rsi,0x1bd72(%rip)        # 21088 <fwp_tape_cached_bytes>
    5316:	0f 29 05 93 bd 01 00 	movaps %xmm0,0x1bd93(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    531d:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5322:	0f 29 05 97 bd 01 00 	movaps %xmm0,0x1bd97(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    5329:	48 8b 43 30          	mov    0x30(%rbx),%rax
    532d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5331:	48 89 05 98 bd 01 00 	mov    %rax,0x1bd98(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    5338:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    533f:	00 
    5340:	0f 11 03             	movups %xmm0,(%rbx)
    5343:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5347:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    534b:	eb 1e                	jmp    536b <fwp_tape_buffers_release+0x10b>
    534d:	0f 1f 00             	nopl   (%rax)
    5350:	48 8d 3d 09 7e 00 00 	lea    0x7e09(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    5357:	e8 34 e0 ff ff       	call   3390 <getenv@plt>
    535c:	48 89 df             	mov    %rbx,%rdi
    535f:	e8 dc fd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    5364:	48 8b 35 1d bd 01 00 	mov    0x1bd1d(%rip),%rsi        # 21088 <fwp_tape_cached_bytes>
    536b:	48 6b 15 6d bd 01 00 	imul   $0x68,0x1bd6d(%rip),%rdx        # 210e0 <fwp_tapes_cap>
    5372:	68 
    5373:	48 3b 15 26 be 04 00 	cmp    0x4be26(%rip),%rdx        # 511a0 <ad_raw_live>
    537a:	75 73                	jne    53ef <fwp_tape_buffers_release+0x18f>
    537c:	48 8b 05 25 be 04 00 	mov    0x4be25(%rip),%rax        # 511a8 <ad_raw_live+0x8>
    5383:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5387:	48 01 d0             	add    %rdx,%rax
    538a:	48 03 05 1f be 04 00 	add    0x4be1f(%rip),%rax        # 511b0 <ad_raw_live+0x10>
    5391:	48 03 05 20 be 04 00 	add    0x4be20(%rip),%rax        # 511b8 <ad_raw_live+0x18>
    5398:	48 39 c8             	cmp    %rcx,%rax
    539b:	72 52                	jb     53ef <fwp_tape_buffers_release+0x18f>
    539d:	48 8b 0d 5c bd 01 00 	mov    0x1bd5c(%rip),%rcx        # 21100 <ad_raw_checkpoint_count>
    53a4:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    53ab:	74 4e                	je     53fb <fwp_tape_buffers_release+0x19b>
    53ad:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    53b1:	48 29 d0             	sub    %rdx,%rax
    53b4:	48 89 3d 45 bd 01 00 	mov    %rdi,0x1bd45(%rip)        # 21100 <ad_raw_checkpoint_count>
    53bb:	48 29 f0             	sub    %rsi,%rax
    53be:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53c2:	48 8d 0d 57 bd 01 00 	lea    0x1bd57(%rip),%rcx        # 21120 <ad_raw_checkpoints>
    53c9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53cd:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53d2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53d7:	48 83 c4 10          	add    $0x10,%rsp
    53db:	5b                   	pop    %rbx
    53dc:	c3                   	ret
    53dd:	0f 1f 00             	nopl   (%rax)
    53e0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53e4:	0f 84 72 ff ff ff    	je     535c <fwp_tape_buffers_release+0xfc>
    53ea:	e9 ec fe ff ff       	jmp    52db <fwp_tape_buffers_release+0x7b>
    53ef:	48 8d 3d 72 85 00 00 	lea    0x8572(%rip),%rdi        # d968 <_IO_stdin_used+0x968>
    53f6:	e8 05 ec ff ff       	call   4000 <ad_raw_fail>
    53fb:	48 8d 3d 6f 7d 00 00 	lea    0x7d6f(%rip),%rdi        # d171 <_IO_stdin_used+0x171>
    5402:	e8 f9 eb ff ff       	call   4000 <ad_raw_fail>
    5407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    540e:	00 00 

0000000000005410 <fwp_poll_events>:
    5410:	53                   	push   %rbx
    5411:	48 83 ec 20          	sub    $0x20,%rsp
    5415:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    541c:	00 00 
    541e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5423:	31 c0                	xor    %eax,%eax
    5425:	e8 96 f1 ff ff       	call   45c0 <fwp_now_ns>
    542a:	48 8b 1d a7 43 06 00 	mov    0x643a7(%rip),%rbx        # 697d8 <fwp_timers>
    5431:	48 85 db             	test   %rbx,%rbx
    5434:	0f 84 e6 00 00 00    	je     5520 <fwp_poll_events+0x110>
    543a:	48 89 c6             	mov    %rax,%rsi
    543d:	48 89 da             	mov    %rbx,%rdx
    5440:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5447:	eb 26                	jmp    546f <fwp_poll_events+0x5f>
    5449:	90                   	nop
    544a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5451:	00 00 00 00 
    5455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    545c:	00 00 00 00 
    5460:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5467:	48 89 c8             	mov    %rcx,%rax
    546a:	48 85 d2             	test   %rdx,%rdx
    546d:	74 31                	je     54a0 <fwp_poll_events+0x90>
    546f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5473:	48 85 c0             	test   %rax,%rax
    5476:	78 e8                	js     5460 <fwp_poll_events+0x50>
    5478:	48 39 c1             	cmp    %rax,%rcx
    547b:	7c e3                	jl     5460 <fwp_poll_events+0x50>
    547d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 1c                	je     54a5 <fwp_poll_events+0x95>
    5489:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    548d:	48 39 c1             	cmp    %rax,%rcx
    5490:	7c ce                	jl     5460 <fwp_poll_events+0x50>
    5492:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5499:	48 85 d2             	test   %rdx,%rdx
    549c:	75 d1                	jne    546f <fwp_poll_events+0x5f>
    549e:	66 90                	xchg   %ax,%ax
    54a0:	48 85 c0             	test   %rax,%rax
    54a3:	78 7b                	js     5520 <fwp_poll_events+0x110>
    54a5:	48 29 f0             	sub    %rsi,%rax
    54a8:	48 89 c1             	mov    %rax,%rcx
    54ab:	48 85 c0             	test   %rax,%rax
    54ae:	0f 8e 9c 00 00 00    	jle    5550 <fwp_poll_events+0x140>
    54b4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    54bb:	de 1b 43 
    54be:	48 f7 ea             	imul   %rdx
    54c1:	48 89 c8             	mov    %rcx,%rax
    54c4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54c8:	48 c1 fa 12          	sar    $0x12,%rdx
    54cc:	48 29 c2             	sub    %rax,%rdx
    54cf:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54d6:	48 39 c1             	cmp    %rax,%rcx
    54d9:	0f 95 c0             	setne  %al
    54dc:	0f b6 c0             	movzbl %al,%eax
    54df:	48 01 d0             	add    %rdx,%rax
    54e2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54e8:	0f 8f 32 01 00 00    	jg     5620 <fwp_poll_events+0x210>
    54ee:	48 85 c0             	test   %rax,%rax
    54f1:	74 5d                	je     5550 <fwp_poll_events+0x140>
    54f3:	89 c1                	mov    %eax,%ecx
    54f5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54fc:	48 c1 e9 26          	shr    $0x26,%rcx
    5500:	48 63 d1             	movslq %ecx,%rdx
    5503:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5509:	29 c8                	sub    %ecx,%eax
    550b:	48 98                	cltq
    550d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5514:	e9 11 01 00 00       	jmp    562a <fwp_poll_events+0x21a>
    5519:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5520:	e8 db e7 ff ff       	call   3d00 <fwp_flush>
    5525:	ba 2b 00 00 00       	mov    $0x2b,%edx
    552a:	be 01 00 00 00       	mov    $0x1,%esi
    552f:	48 8b 0d 0a bb 00 00 	mov    0xbb0a(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    5536:	48 8d 3d 5b 84 00 00 	lea    0x845b(%rip),%rdi        # d998 <_IO_stdin_used+0x998>
    553d:	e8 1e e1 ff ff       	call   3660 <fwrite@plt>
    5542:	bf 65 00 00 00       	mov    $0x65,%edi
    5547:	e8 04 e1 ff ff       	call   3650 <exit@plt>
    554c:	0f 1f 40 00          	nopl   0x0(%rax)
    5550:	e8 6b f0 ff ff       	call   45c0 <fwp_now_ns>
    5555:	48 89 c1             	mov    %rax,%rcx
    5558:	66 0f ef c0          	pxor   %xmm0,%xmm0
    555c:	eb 44                	jmp    55a2 <fwp_poll_events+0x192>
    555e:	66 90                	xchg   %ax,%ax
    5560:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5564:	75 33                	jne    5599 <fwp_poll_events+0x189>
    5566:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    556a:	75 2d                	jne    5599 <fwp_poll_events+0x189>
    556c:	48 8b 05 6d 42 06 00 	mov    0x6426d(%rip),%rax        # 697e0 <fwp_ready_tail>
    5573:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5577:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    557e:	00 00 00 00 
    5582:	48 85 c0             	test   %rax,%rax
    5585:	0f 84 05 01 00 00    	je     5690 <fwp_poll_events+0x280>
    558b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5592:	48 89 15 47 42 06 00 	mov    %rdx,0x64247(%rip)        # 697e0 <fwp_ready_tail>
    5599:	48 85 db             	test   %rbx,%rbx
    559c:	0f 84 be 00 00 00    	je     5660 <fwp_poll_events+0x250>
    55a2:	48 89 da             	mov    %rbx,%rdx
    55a5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    55ac:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    55b0:	7f e7                	jg     5599 <fwp_poll_events+0x189>
    55b2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    55b6:	74 2e                	je     55e6 <fwp_poll_events+0x1d6>
    55b8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    55bf:	48 85 c0             	test   %rax,%rax
    55c2:	0f 84 b8 00 00 00    	je     5680 <fwp_poll_events+0x270>
    55c8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55cf:	48 85 db             	test   %rbx,%rbx
    55d2:	74 07                	je     55db <fwp_poll_events+0x1cb>
    55d4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55db:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55df:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55e6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ea:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ee:	48 85 c0             	test   %rax,%rax
    55f1:	0f 84 69 ff ff ff    	je     5560 <fwp_poll_events+0x150>
    55f7:	48 39 c8             	cmp    %rcx,%rax
    55fa:	0f 8f 60 ff ff ff    	jg     5560 <fwp_poll_events+0x150>
    5600:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5604:	0f 85 56 ff ff ff    	jne    5560 <fwp_poll_events+0x150>
    560a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    560e:	75 89                	jne    5599 <fwp_poll_events+0x189>
    5610:	48 89 d7             	mov    %rdx,%rdi
    5613:	e8 18 eb ff ff       	call   4130 <fwp_cancel_tree.part.0>
    5618:	e9 43 ff ff ff       	jmp    5560 <fwp_poll_events+0x150>
    561d:	0f 1f 00             	nopl   (%rax)
    5620:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5625:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    562a:	48 89 e7             	mov    %rsp,%rdi
    562d:	31 f6                	xor    %esi,%esi
    562f:	48 89 14 24          	mov    %rdx,(%rsp)
    5633:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5638:	e8 53 de ff ff       	call   3490 <nanosleep@plt>
    563d:	48 8b 1d 94 41 06 00 	mov    0x64194(%rip),%rbx        # 697d8 <fwp_timers>
    5644:	e8 77 ef ff ff       	call   45c0 <fwp_now_ns>
    5649:	48 89 c1             	mov    %rax,%rcx
    564c:	48 85 db             	test   %rbx,%rbx
    564f:	0f 85 03 ff ff ff    	jne    5558 <fwp_poll_events+0x148>
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5665:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    566c:	00 00 
    566e:	75 2c                	jne    569c <fwp_poll_events+0x28c>
    5670:	48 83 c4 20          	add    $0x20,%rsp
    5674:	5b                   	pop    %rbx
    5675:	c3                   	ret
    5676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    567d:	00 00 00 
    5680:	48 89 1d 51 41 06 00 	mov    %rbx,0x64151(%rip)        # 697d8 <fwp_timers>
    5687:	e9 43 ff ff ff       	jmp    55cf <fwp_poll_events+0x1bf>
    568c:	0f 1f 40 00          	nopl   0x0(%rax)
    5690:	48 89 15 51 41 06 00 	mov    %rdx,0x64151(%rip)        # 697e8 <fwp_ready_head>
    5697:	e9 f6 fe ff ff       	jmp    5592 <fwp_poll_events+0x182>
    569c:	e8 af dd ff ff       	call   3450 <__stack_chk_fail@plt>
    56a1:	0f 1f 40 00          	nopl   0x0(%rax)
    56a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56ac:	00 00 00 00 

00000000000056b0 <fwp_rc_wide_dup>:
    56b0:	48 89 fa             	mov    %rdi,%rdx
    56b3:	48 8d 35 66 41 06 00 	lea    0x64166(%rip),%rsi        # 69820 <fwp_heap>
    56ba:	48 83 ec 18          	sub    $0x18,%rsp
    56be:	48 89 f9             	mov    %rdi,%rcx
    56c1:	48 c1 ea 11          	shr    $0x11,%rdx
    56c5:	48 31 fa             	xor    %rdi,%rdx
    56c8:	48 89 d0             	mov    %rdx,%rax
    56cb:	48 c1 e8 09          	shr    $0x9,%rax
    56cf:	48 31 c2             	xor    %rax,%rdx
    56d2:	0f b6 d2             	movzbl %dl,%edx
    56d5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56dc:	00 
    56dd:	49 8b 00             	mov    (%r8),%rax
    56e0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56e7:	00 00 
    56e9:	75 21                	jne    570c <fwp_rc_wide_dup+0x5c>
    56eb:	e9 98 00 00 00       	jmp    5788 <fwp_rc_wide_dup+0xd8>
    56f0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56fc:	00 00 00 00 
    5700:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5704:	48 85 d2             	test   %rdx,%rdx
    5707:	74 2f                	je     5738 <fwp_rc_wide_dup+0x88>
    5709:	48 89 d0             	mov    %rdx,%rax
    570c:	48 3b 08             	cmp    (%rax),%rcx
    570f:	75 ef                	jne    5700 <fwp_rc_wide_dup+0x50>
    5711:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5714:	74 7c                	je     5792 <fwp_rc_wide_dup+0xe2>
    5716:	48 8b 50 08          	mov    0x8(%rax),%rdx
    571a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    571e:	0f 84 91 00 00 00    	je     57b5 <fwp_rc_wide_dup+0x105>
    5724:	48 83 c2 01          	add    $0x1,%rdx
    5728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    572c:	48 83 c4 18          	add    $0x18,%rsp
    5730:	c3                   	ret
    5731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5738:	4c 8d 40 10          	lea    0x10(%rax),%r8
    573c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    573f:	75 68                	jne    57a9 <fwp_rc_wide_dup+0xf9>
    5741:	bf 18 00 00 00       	mov    $0x18,%edi
    5746:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    574b:	4c 89 04 24          	mov    %r8,(%rsp)
    574f:	e8 3c de ff ff       	call   3590 <malloc@plt>
    5754:	4c 8b 04 24          	mov    (%rsp),%r8
    5758:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    575d:	48 85 c0             	test   %rax,%rax
    5760:	74 5f                	je     57c1 <fwp_rc_wide_dup+0x111>
    5762:	48 89 08             	mov    %rcx,(%rax)
    5765:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    576c:	00 
    576d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5774:	00 
    5775:	49 89 00             	mov    %rax,(%r8)
    5778:	c6 01 ff             	movb   $0xff,(%rcx)
    577b:	48 83 05 e5 5c 06 00 	addq   $0x1,0x65ce5(%rip)        # 6b468 <fwp_heap+0x1c48>
    5782:	01 
    5783:	48 83 c4 18          	add    $0x18,%rsp
    5787:	c3                   	ret
    5788:	80 3f fe             	cmpb   $0xfe,(%rdi)
    578b:	75 13                	jne    57a0 <fwp_rc_wide_dup+0xf0>
    578d:	48 85 c0             	test   %rax,%rax
    5790:	74 af                	je     5741 <fwp_rc_wide_dup+0x91>
    5792:	48 8d 3d 2f 82 00 00 	lea    0x822f(%rip),%rdi        # d9c8 <_IO_stdin_used+0x9c8>
    5799:	e8 b2 ec ff ff       	call   4450 <fwp_trap>
    579e:	66 90                	xchg   %ax,%ax
    57a0:	48 85 c0             	test   %rax,%rax
    57a3:	0f 85 6d ff ff ff    	jne    5716 <fwp_rc_wide_dup+0x66>
    57a9:	48 8d 3d 40 82 00 00 	lea    0x8240(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    57b0:	e8 9b ec ff ff       	call   4450 <fwp_trap>
    57b5:	48 8d 3d d2 79 00 00 	lea    0x79d2(%rip),%rdi        # d18e <_IO_stdin_used+0x18e>
    57bc:	e8 8f ec ff ff       	call   4450 <fwp_trap>
    57c1:	e8 6a e6 ff ff       	call   3e30 <fwp_heap_oom>
    57c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57cd:	00 00 00 

00000000000057d0 <fwp_rc_forget_slot>:
    57d0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57d3:	74 0b                	je     57e0 <fwp_rc_forget_slot+0x10>
    57d5:	c3                   	ret
    57d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57dd:	00 00 00 
    57e0:	48 89 f8             	mov    %rdi,%rax
    57e3:	48 83 ec 08          	sub    $0x8,%rsp
    57e7:	48 89 fa             	mov    %rdi,%rdx
    57ea:	48 c1 e8 11          	shr    $0x11,%rax
    57ee:	48 31 f8             	xor    %rdi,%rax
    57f1:	48 89 c1             	mov    %rax,%rcx
    57f4:	48 c1 e9 09          	shr    $0x9,%rcx
    57f8:	48 31 c8             	xor    %rcx,%rax
    57fb:	48 8d 0d 1e 40 06 00 	lea    0x6401e(%rip),%rcx        # 69820 <fwp_heap>
    5802:	0f b6 c0             	movzbl %al,%eax
    5805:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    580c:	00 
    580d:	48 85 ff             	test   %rdi,%rdi
    5810:	74 3c                	je     584e <fwp_rc_forget_slot+0x7e>
    5812:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5819:	00 
    581a:	48 8b 01             	mov    (%rcx),%rax
    581d:	eb 11                	jmp    5830 <fwp_rc_forget_slot+0x60>
    581f:	90                   	nop
    5820:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5824:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5828:	48 85 ff             	test   %rdi,%rdi
    582b:	74 21                	je     584e <fwp_rc_forget_slot+0x7e>
    582d:	48 89 f8             	mov    %rdi,%rax
    5830:	48 3b 10             	cmp    (%rax),%rdx
    5833:	75 eb                	jne    5820 <fwp_rc_forget_slot+0x50>
    5835:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5839:	48 89 01             	mov    %rax,(%rcx)
    583c:	e8 6f db ff ff       	call   33b0 <free@plt>
    5841:	48 83 2d 1f 5c 06 00 	subq   $0x1,0x65c1f(%rip)        # 6b468 <fwp_heap+0x1c48>
    5848:	01 
    5849:	48 83 c4 08          	add    $0x8,%rsp
    584d:	c3                   	ret
    584e:	48 8d 3d 9b 81 00 00 	lea    0x819b(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    5855:	e8 f6 eb ff ff       	call   4450 <fwp_trap>
    585a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005860 <fwp_rc_prepare_chunk>:
    5860:	48 83 3d 00 5c 06 00 	cmpq   $0x0,0x65c00(%rip)        # 6b468 <fwp_heap+0x1c48>
    5867:	00 
    5868:	41 54                	push   %r12
    586a:	49 89 f4             	mov    %rsi,%r12
    586d:	55                   	push   %rbp
    586e:	48 89 fd             	mov    %rdi,%rbp
    5871:	53                   	push   %rbx
    5872:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5875:	0f 84 7d 00 00 00    	je     58f8 <fwp_rc_prepare_chunk+0x98>
    587b:	31 db                	xor    %ebx,%ebx
    587d:	85 c0                	test   %eax,%eax
    587f:	75 5f                	jne    58e0 <fwp_rc_prepare_chunk+0x80>
    5881:	48 85 f6             	test   %rsi,%rsi
    5884:	74 7c                	je     5902 <fwp_rc_prepare_chunk+0xa2>
    5886:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    588a:	e8 21 db ff ff       	call   33b0 <free@plt>
    588f:	90                   	nop
    5890:	be 01 00 00 00       	mov    $0x1,%esi
    5895:	4c 89 e7             	mov    %r12,%rdi
    5898:	e8 73 dc ff ff       	call   3510 <calloc@plt>
    589d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    58a1:	48 85 c0             	test   %rax,%rax
    58a4:	0f 85 87 00 00 00    	jne    5931 <fwp_rc_prepare_chunk+0xd1>
    58aa:	e8 81 e5 ff ff       	call   3e30 <fwp_heap_oom>
    58af:	90                   	nop
    58b0:	e8 1b ff ff ff       	call   57d0 <fwp_rc_forget_slot>
    58b5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58b8:	48 83 c3 01          	add    $0x1,%rbx
    58bc:	48 39 c3             	cmp    %rax,%rbx
    58bf:	73 37                	jae    58f8 <fwp_rc_prepare_chunk+0x98>
    58c1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58c8:	00 00 
    58ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58d1:	00 00 00 00 
    58d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58dc:	00 00 00 00 
    58e0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58e4:	48 01 df             	add    %rbx,%rdi
    58e7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ea:	74 c4                	je     58b0 <fwp_rc_prepare_chunk+0x50>
    58ec:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58ef:	48 83 c3 01          	add    $0x1,%rbx
    58f3:	48 39 c3             	cmp    %rax,%rbx
    58f6:	72 e8                	jb     58e0 <fwp_rc_prepare_chunk+0x80>
    58f8:	49 39 c4             	cmp    %rax,%r12
    58fb:	75 13                	jne    5910 <fwp_rc_prepare_chunk+0xb0>
    58fd:	4d 85 e4             	test   %r12,%r12
    5900:	75 46                	jne    5948 <fwp_rc_prepare_chunk+0xe8>
    5902:	5b                   	pop    %rbx
    5903:	5d                   	pop    %rbp
    5904:	41 5c                	pop    %r12
    5906:	c3                   	ret
    5907:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    590e:	00 00 
    5910:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5914:	48 29 05 55 5b 06 00 	sub    %rax,0x65b55(%rip)        # 6b470 <fwp_heap+0x1c50>
    591b:	e8 90 da ff ff       	call   33b0 <free@plt>
    5920:	4d 85 e4             	test   %r12,%r12
    5923:	0f 85 67 ff ff ff    	jne    5890 <fwp_rc_prepare_chunk+0x30>
    5929:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5930:	00 
    5931:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5935:	5b                   	pop    %rbx
    5936:	4c 01 25 33 5b 06 00 	add    %r12,0x65b33(%rip)        # 6b470 <fwp_heap+0x1c50>
    593d:	5d                   	pop    %rbp
    593e:	41 5c                	pop    %r12
    5940:	c3                   	ret
    5941:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5948:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    594c:	5b                   	pop    %rbx
    594d:	4c 89 e2             	mov    %r12,%rdx
    5950:	31 f6                	xor    %esi,%esi
    5952:	5d                   	pop    %rbp
    5953:	41 5c                	pop    %r12
    5955:	e9 56 db ff ff       	jmp    34b0 <memset@plt>
    595a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005960 <fwp_heap_refill>:
    5960:	41 56                	push   %r14
    5962:	41 89 d6             	mov    %edx,%r14d
    5965:	41 55                	push   %r13
    5967:	41 89 f5             	mov    %esi,%r13d
    596a:	41 54                	push   %r12
    596c:	49 89 fc             	mov    %rdi,%r12
    596f:	bf 01 00 00 00       	mov    $0x1,%edi
    5974:	55                   	push   %rbp
    5975:	53                   	push   %rbx
    5976:	e8 f5 e4 ff ff       	call   3e70 <fwp_heap_chunks>
    597b:	48 89 c3             	mov    %rax,%rbx
    597e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5982:	48 8b 05 8f 52 06 00 	mov    0x6528f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    5989:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    598d:	48 8d 05 8c 3e 06 00 	lea    0x63e8c(%rip),%rax        # 69820 <fwp_heap>
    5994:	31 d2                	xor    %edx,%edx
    5996:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    599a:	48 89 ef             	mov    %rbp,%rdi
    599d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    59a1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    59a5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    59ac:	00 
    59ad:	b8 00 00 01 00       	mov    $0x10000,%eax
    59b2:	f7 f1                	div    %ecx
    59b4:	31 d2                	xor    %edx,%edx
    59b6:	66 0f 6e c1          	movd   %ecx,%xmm0
    59ba:	66 0f 6e c8          	movd   %eax,%xmm1
    59be:	89 c6                	mov    %eax,%esi
    59c0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59c5:	48 01 c8             	add    %rcx,%rax
    59c8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59cc:	48 f7 f1             	div    %rcx
    59cf:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59d4:	89 45 18             	mov    %eax,0x18(%rbp)
    59d7:	e8 84 fe ff ff       	call   5860 <fwp_rc_prepare_chunk>
    59dc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59df:	48 89 d8             	mov    %rbx,%rax
    59e2:	48 c1 e0 10          	shl    $0x10,%rax
    59e6:	48 03 05 e3 51 06 00 	add    0x651e3(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    59ed:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59f1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59f6:	8b 55 08             	mov    0x8(%rbp),%edx
    59f9:	48 0f af d1          	imul   %rcx,%rdx
    59fd:	48 01 c2             	add    %rax,%rdx
    5a00:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5a05:	5b                   	pop    %rbx
    5a06:	5d                   	pop    %rbp
    5a07:	41 5c                	pop    %r12
    5a09:	41 5d                	pop    %r13
    5a0b:	41 5e                	pop    %r14
    5a0d:	c3                   	ret
    5a0e:	66 90                	xchg   %ax,%ax

0000000000005a10 <fwp_mem_free>:
    5a10:	48 85 ff             	test   %rdi,%rdi
    5a13:	0f 84 17 02 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a19:	48 8b 35 b0 51 06 00 	mov    0x651b0(%rip),%rsi        # 6abd0 <fwp_heap+0x13b0>
    5a20:	48 8b 05 d1 51 06 00 	mov    0x651d1(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    5a27:	48 89 fa             	mov    %rdi,%rdx
    5a2a:	48 29 f2             	sub    %rsi,%rdx
    5a2d:	48 c1 e0 10          	shl    $0x10,%rax
    5a31:	48 39 c2             	cmp    %rax,%rdx
    5a34:	0f 83 f6 01 00 00    	jae    5c30 <fwp_mem_free+0x220>
    5a3a:	49 89 d1             	mov    %rdx,%r9
    5a3d:	49 c1 e9 10          	shr    $0x10,%r9
    5a41:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a45:	48 c1 e0 03          	shl    $0x3,%rax
    5a49:	49 89 c0             	mov    %rax,%r8
    5a4c:	4c 03 05 c5 51 06 00 	add    0x651c5(%rip),%r8        # 6ac18 <fwp_heap+0x13f8>
    5a53:	0f 84 d7 01 00 00    	je     5c30 <fwp_mem_free+0x220>
    5a59:	48 83 ec 38          	sub    $0x38,%rsp
    5a5d:	48 89 f9             	mov    %rdi,%rcx
    5a60:	41 0f b6 38          	movzbl (%r8),%edi
    5a64:	40 80 ff 01          	cmp    $0x1,%dil
    5a68:	74 16                	je     5a80 <fwp_mem_free+0x70>
    5a6a:	40 80 ff 02          	cmp    $0x2,%dil
    5a6e:	0f 84 94 00 00 00    	je     5b08 <fwp_mem_free+0xf8>
    5a74:	48 83 c4 38          	add    $0x38,%rsp
    5a78:	c3                   	ret
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a84:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a89:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a8e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a92:	4d 85 d2             	test   %r10,%r10
    5a95:	74 1d                	je     5ab4 <fwp_mem_free+0xa4>
    5a97:	0f b7 c1             	movzwl %cx,%eax
    5a9a:	31 d2                	xor    %edx,%edx
    5a9c:	48 f7 f7             	div    %rdi
    5a9f:	49 01 c2             	add    %rax,%r10
    5aa2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5aa6:	0f 84 44 01 00 00    	je     5bf0 <fwp_mem_free+0x1e0>
    5aac:	41 c6 02 00          	movb   $0x0,(%r10)
    5ab0:	41 8b 78 04          	mov    0x4(%r8),%edi
    5ab4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5abb:	49 63 c1             	movslq %r9d,%rax
    5abe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ac2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ac6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5acb:	f2 0f 58 05 8d 51 06 	addsd  0x6518d(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5ad2:	00 
    5ad3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ad7:	48 8d 05 42 3d 06 00 	lea    0x63d42(%rip),%rax        # 69820 <fwp_heap>
    5ade:	48 01 d0             	add    %rdx,%rax
    5ae1:	48 8b 10             	mov    (%rax),%rdx
    5ae4:	48 f7 d2             	not    %rdx
    5ae7:	48 89 11             	mov    %rdx,(%rcx)
    5aea:	48 89 08             	mov    %rcx,(%rax)
    5aed:	48 29 3d 4c 51 06 00 	sub    %rdi,0x6514c(%rip)        # 6ac40 <fwp_heap+0x1420>
    5af4:	f2 0f 11 05 64 51 06 	movsd  %xmm0,0x65164(%rip)        # 6ac60 <fwp_heap+0x1440>
    5afb:	00 
    5afc:	48 83 c4 38          	add    $0x38,%rsp
    5b00:	c3                   	ret
    5b01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5b08:	66 31 d2             	xor    %dx,%dx
    5b0b:	48 01 d6             	add    %rdx,%rsi
    5b0e:	48 39 f1             	cmp    %rsi,%rcx
    5b11:	0f 85 5d ff ff ff    	jne    5a74 <fwp_mem_free+0x64>
    5b17:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5b1b:	48 29 15 1e 51 06 00 	sub    %rdx,0x6511e(%rip)        # 6ac40 <fwp_heap+0x1420>
    5b22:	48 85 d2             	test   %rdx,%rdx
    5b25:	0f 88 a5 00 00 00    	js     5bd0 <fwp_mem_free+0x1c0>
    5b2b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b2f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b34:	f2 0f 58 05 24 51 06 	addsd  0x65124(%rip),%xmm0        # 6ac60 <fwp_heap+0x1440>
    5b3b:	00 
    5b3c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b40:	f2 0f 11 05 18 51 06 	movsd  %xmm0,0x65118(%rip)        # 6ac60 <fwp_heap+0x1440>
    5b47:	00 
    5b48:	48 85 d2             	test   %rdx,%rdx
    5b4b:	74 0c                	je     5b59 <fwp_mem_free+0x149>
    5b4d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b50:	0f 84 db 00 00 00    	je     5c31 <fwp_mem_free+0x221>
    5b56:	c6 02 00             	movb   $0x0,(%rdx)
    5b59:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b5d:	48 85 c9             	test   %rcx,%rcx
    5b60:	74 3e                	je     5ba0 <fwp_mem_free+0x190>
    5b62:	48 8b 15 af 50 06 00 	mov    0x650af(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    5b69:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b6d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b71:	48 01 d0             	add    %rdx,%rax
    5b74:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b78:	48 89 d6             	mov    %rdx,%rsi
    5b7b:	48 29 c6             	sub    %rax,%rsi
    5b7e:	83 e6 08             	and    $0x8,%esi
    5b81:	74 0d                	je     5b90 <fwp_mem_free+0x180>
    5b83:	c6 00 00             	movb   $0x0,(%rax)
    5b86:	48 83 c0 28          	add    $0x28,%rax
    5b8a:	48 39 c2             	cmp    %rax,%rdx
    5b8d:	74 11                	je     5ba0 <fwp_mem_free+0x190>
    5b8f:	90                   	nop
    5b90:	c6 00 00             	movb   $0x0,(%rax)
    5b93:	48 83 c0 50          	add    $0x50,%rax
    5b97:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b9b:	48 39 c2             	cmp    %rax,%rdx
    5b9e:	75 f0                	jne    5b90 <fwp_mem_free+0x180>
    5ba0:	48 01 0d a9 50 06 00 	add    %rcx,0x650a9(%rip)        # 6ac50 <fwp_heap+0x1430>
    5ba7:	4c 3b 0d 62 50 06 00 	cmp    0x65062(%rip),%r9        # 6ac10 <fwp_heap+0x13f0>
    5bae:	73 07                	jae    5bb7 <fwp_mem_free+0x1a7>
    5bb0:	4c 89 0d 59 50 06 00 	mov    %r9,0x65059(%rip)        # 6ac10 <fwp_heap+0x13f0>
    5bb7:	4c 3b 0d 4a 50 06 00 	cmp    0x6504a(%rip),%r9        # 6ac08 <fwp_heap+0x13e8>
    5bbe:	0f 83 b0 fe ff ff    	jae    5a74 <fwp_mem_free+0x64>
    5bc4:	4c 89 0d 3d 50 06 00 	mov    %r9,0x6503d(%rip)        # 6ac08 <fwp_heap+0x13e8>
    5bcb:	e9 a4 fe ff ff       	jmp    5a74 <fwp_mem_free+0x64>
    5bd0:	48 89 d1             	mov    %rdx,%rcx
    5bd3:	83 e2 01             	and    $0x1,%edx
    5bd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bda:	48 d1 e9             	shr    $1,%rcx
    5bdd:	48 09 d1             	or     %rdx,%rcx
    5be0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5be5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5be9:	e9 46 ff ff ff       	jmp    5b34 <fwp_mem_free+0x124>
    5bee:	66 90                	xchg   %ax,%ax
    5bf0:	4c 89 d7             	mov    %r10,%rdi
    5bf3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bf8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bfd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5c02:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5c06:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5c0b:	e8 c0 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c10:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5c15:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5c1a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5c1f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c24:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c29:	e9 7e fe ff ff       	jmp    5aac <fwp_mem_free+0x9c>
    5c2e:	66 90                	xchg   %ax,%ax
    5c30:	c3                   	ret
    5c31:	48 89 d7             	mov    %rdx,%rdi
    5c34:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c39:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c3e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c48:	e8 83 fb ff ff       	call   57d0 <fwp_rc_forget_slot>
    5c4d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c52:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c57:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c5c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c61:	e9 f0 fe ff ff       	jmp    5b56 <fwp_mem_free+0x146>
    5c66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c6d:	00 00 00 

0000000000005c70 <fwp_heap_alloc_big>:
    5c70:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c77:	00 00 40 
    5c7a:	41 57                	push   %r15
    5c7c:	41 56                	push   %r14
    5c7e:	41 55                	push   %r13
    5c80:	41 54                	push   %r12
    5c82:	55                   	push   %rbp
    5c83:	53                   	push   %rbx
    5c84:	48 83 ec 08          	sub    $0x8,%rsp
    5c88:	48 39 f8             	cmp    %rdi,%rax
    5c8b:	0f 82 fa 00 00 00    	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5c91:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c98:	49 89 fd             	mov    %rdi,%r13
    5c9b:	41 89 f6             	mov    %esi,%r14d
    5c9e:	48 c1 ed 10          	shr    $0x10,%rbp
    5ca2:	48 89 ef             	mov    %rbp,%rdi
    5ca5:	e8 c6 e1 ff ff       	call   3e70 <fwp_heap_chunks>
    5caa:	be 01 00 00 00       	mov    $0x1,%esi
    5caf:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5cb3:	49 89 c4             	mov    %rax,%r12
    5cb6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5cbd:	00 
    5cbe:	48 03 3d 53 4f 06 00 	add    0x64f53(%rip),%rdi        # 6ac18 <fwp_heap+0x13f8>
    5cc5:	c6 07 02             	movb   $0x2,(%rdi)
    5cc8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5ccc:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5ccf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cd3:	e8 88 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5cd8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cdc:	76 47                	jbe    5d25 <fwp_heap_alloc_big+0xb5>
    5cde:	4c 01 e5             	add    %r12,%rbp
    5ce1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5ce8:	00 
    5ce9:	4c 8d 3d 30 3b 06 00 	lea    0x63b30(%rip),%r15        # 69820 <fwp_heap>
    5cf0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cf5:	49 c1 e6 03          	shl    $0x3,%r14
    5cf9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d00:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5d07:	31 f6                	xor    %esi,%esi
    5d09:	48 01 dd             	add    %rbx,%rbp
    5d0c:	48 83 c3 28          	add    $0x28,%rbx
    5d10:	48 89 ef             	mov    %rbp,%rdi
    5d13:	e8 48 fb ff ff       	call   5860 <fwp_rc_prepare_chunk>
    5d18:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5d1c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d20:	49 39 de             	cmp    %rbx,%r14
    5d23:	75 db                	jne    5d00 <fwp_heap_alloc_big+0x90>
    5d25:	49 c1 e4 10          	shl    $0x10,%r12
    5d29:	4c 03 25 a0 4e 06 00 	add    0x64ea0(%rip),%r12        # 6abd0 <fwp_heap+0x13b0>
    5d30:	4c 89 ea             	mov    %r13,%rdx
    5d33:	31 f6                	xor    %esi,%esi
    5d35:	4c 89 e7             	mov    %r12,%rdi
    5d38:	e8 73 d7 ff ff       	call   34b0 <memset@plt>
    5d3d:	4c 89 e8             	mov    %r13,%rax
    5d40:	48 03 05 f9 4e 06 00 	add    0x64ef9(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5d47:	72 42                	jb     5d8b <fwp_heap_alloc_big+0x11b>
    5d49:	48 39 05 f8 4e 06 00 	cmp    %rax,0x64ef8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d50:	48 89 05 e9 4e 06 00 	mov    %rax,0x64ee9(%rip)        # 6ac40 <fwp_heap+0x1420>
    5d57:	73 07                	jae    5d60 <fwp_heap_alloc_big+0xf0>
    5d59:	48 89 05 e8 4e 06 00 	mov    %rax,0x64ee8(%rip)        # 6ac48 <fwp_heap+0x1428>
    5d60:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d64:	4c 89 e0             	mov    %r12,%rax
    5d67:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d6c:	f2 0f 58 05 e4 4e 06 	addsd  0x64ee4(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5d73:	00 
    5d74:	f2 0f 11 05 dc 4e 06 	movsd  %xmm0,0x64edc(%rip)        # 6ac58 <fwp_heap+0x1438>
    5d7b:	00 
    5d7c:	48 83 c4 08          	add    $0x8,%rsp
    5d80:	5b                   	pop    %rbx
    5d81:	5d                   	pop    %rbp
    5d82:	41 5c                	pop    %r12
    5d84:	41 5d                	pop    %r13
    5d86:	41 5e                	pop    %r14
    5d88:	41 5f                	pop    %r15
    5d8a:	c3                   	ret
    5d8b:	e8 a0 e0 ff ff       	call   3e30 <fwp_heap_oom>

0000000000005d90 <fwp_heap_alloc_slow>:
    5d90:	53                   	push   %rbx
    5d91:	48 89 f9             	mov    %rdi,%rcx
    5d94:	41 89 f1             	mov    %esi,%r9d
    5d97:	48 83 ec 10          	sub    $0x10,%rsp
    5d9b:	8b 05 23 4e 06 00    	mov    0x64e23(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5da1:	85 c0                	test   %eax,%eax
    5da3:	0f 84 c7 00 00 00    	je     5e70 <fwp_heap_alloc_slow+0xe0>
    5da9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5db0:	0f 87 dd 00 00 00    	ja     5e93 <fwp_heap_alloc_slow+0x103>
    5db6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5dba:	48 8d 3d 5f 3a 06 00 	lea    0x63a5f(%rip),%rdi        # 69820 <fwp_heap>
    5dc1:	49 63 f1             	movslq %r9d,%rsi
    5dc4:	48 c1 e8 04          	shr    $0x4,%rax
    5dc8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5dcf:	00 00 
    5dd1:	41 0f b6 c2          	movzbl %r10b,%eax
    5dd5:	4c 89 d2             	mov    %r10,%rdx
    5dd8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5ddc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5de3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dea:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dee:	48 01 f8             	add    %rdi,%rax
    5df1:	4c 8b 00             	mov    (%rax),%r8
    5df4:	4d 85 c0             	test   %r8,%r8
    5df7:	0f 84 ab 00 00 00    	je     5ea8 <fwp_heap_alloc_slow+0x118>
    5dfd:	49 8b 10             	mov    (%r8),%rdx
    5e00:	48 f7 d2             	not    %rdx
    5e03:	48 89 10             	mov    %rdx,(%rax)
    5e06:	41 83 f9 01          	cmp    $0x1,%r9d
    5e0a:	4c 89 c7             	mov    %r8,%rdi
    5e0d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5e11:	31 f6                	xor    %esi,%esi
    5e13:	48 89 ca             	mov    %rcx,%rdx
    5e16:	e8 95 d6 ff ff       	call   34b0 <memset@plt>
    5e1b:	49 89 c0             	mov    %rax,%r8
    5e1e:	48 89 d8             	mov    %rbx,%rax
    5e21:	48 03 05 18 4e 06 00 	add    0x64e18(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5e28:	0f 82 d9 00 00 00    	jb     5f07 <fwp_heap_alloc_slow+0x177>
    5e2e:	48 39 05 13 4e 06 00 	cmp    %rax,0x64e13(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e35:	48 89 05 04 4e 06 00 	mov    %rax,0x64e04(%rip)        # 6ac40 <fwp_heap+0x1420>
    5e3c:	73 07                	jae    5e45 <fwp_heap_alloc_slow+0xb5>
    5e3e:	48 89 05 03 4e 06 00 	mov    %rax,0x64e03(%rip)        # 6ac48 <fwp_heap+0x1428>
    5e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e49:	4c 89 c0             	mov    %r8,%rax
    5e4c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e51:	f2 0f 58 05 ff 4d 06 	addsd  0x64dff(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5e58:	00 
    5e59:	f2 0f 11 05 f7 4d 06 	movsd  %xmm0,0x64df7(%rip)        # 6ac58 <fwp_heap+0x1438>
    5e60:	00 
    5e61:	48 83 c4 10          	add    $0x10,%rsp
    5e65:	5b                   	pop    %rbx
    5e66:	c3                   	ret
    5e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e6e:	00 00 
    5e70:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e74:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e78:	e8 53 ef ff ff       	call   4dd0 <fwp_heap_init>
    5e7d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e81:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e86:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e8d:	0f 86 23 ff ff ff    	jbe    5db6 <fwp_heap_alloc_slow+0x26>
    5e93:	48 83 c4 10          	add    $0x10,%rsp
    5e97:	44 89 ce             	mov    %r9d,%esi
    5e9a:	48 89 cf             	mov    %rcx,%rdi
    5e9d:	5b                   	pop    %rbx
    5e9e:	e9 cd fd ff ff       	jmp    5c70 <fwp_heap_alloc_big>
    5ea3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5ea8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5eac:	4d 85 c0             	test   %r8,%r8
    5eaf:	74 1f                	je     5ed0 <fwp_heap_alloc_slow+0x140>
    5eb1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5eb5:	4d 29 c3             	sub    %r8,%r11
    5eb8:	49 39 db             	cmp    %rbx,%r11
    5ebb:	72 13                	jb     5ed0 <fwp_heap_alloc_slow+0x140>
    5ebd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ec1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ec5:	e9 3c ff ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5ed0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5ed7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5edb:	44 89 ca             	mov    %r9d,%edx
    5ede:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ee3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ee7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5eeb:	44 89 d6             	mov    %r10d,%esi
    5eee:	48 01 c7             	add    %rax,%rdi
    5ef1:	e8 6a fa ff ff       	call   5960 <fwp_heap_refill>
    5ef6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5efb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5eff:	49 89 c0             	mov    %rax,%r8
    5f02:	e9 ff fe ff ff       	jmp    5e06 <fwp_heap_alloc_slow+0x76>
    5f07:	e8 24 df ff ff       	call   3e30 <fwp_heap_oom>
    5f0c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005f10 <fwp_heap_alloc>:
    5f10:	53                   	push   %rbx
    5f11:	48 89 fa             	mov    %rdi,%rdx
    5f14:	48 83 ec 10          	sub    $0x10,%rsp
    5f18:	8b 1d ca 55 06 00    	mov    0x655ca(%rip),%ebx        # 6b4e8 <iteration_active>
    5f1e:	8b 05 a0 4c 06 00    	mov    0x64ca0(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    5f24:	85 db                	test   %ebx,%ebx
    5f26:	0f 85 04 01 00 00    	jne    6030 <fwp_heap_alloc+0x120>
    5f2c:	85 c0                	test   %eax,%eax
    5f2e:	0f 84 ac 01 00 00    	je     60e0 <fwp_heap_alloc+0x1d0>
    5f34:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f3b:	0f 87 9f 01 00 00    	ja     60e0 <fwp_heap_alloc+0x1d0>
    5f41:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f45:	48 8d 05 d4 38 06 00 	lea    0x638d4(%rip),%rax        # 69820 <fwp_heap>
    5f4c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f50:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f57:	00 
    5f58:	48 63 ce             	movslq %esi,%rcx
    5f5b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f62:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f69:	00 
    5f6a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f6e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f72:	48 01 c8             	add    %rcx,%rax
    5f75:	48 8b 08             	mov    (%rax),%rcx
    5f78:	48 85 c9             	test   %rcx,%rcx
    5f7b:	0f 84 ff 00 00 00    	je     6080 <fwp_heap_alloc+0x170>
    5f81:	48 8b 39             	mov    (%rcx),%rdi
    5f84:	48 f7 d7             	not    %rdi
    5f87:	48 89 38             	mov    %rdi,(%rax)
    5f8a:	83 fe 01             	cmp    $0x1,%esi
    5f8d:	48 89 cf             	mov    %rcx,%rdi
    5f90:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f95:	49 0f 45 d0          	cmovne %r8,%rdx
    5f99:	31 f6                	xor    %esi,%esi
    5f9b:	e8 10 d5 ff ff       	call   34b0 <memset@plt>
    5fa0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5fa5:	48 89 c1             	mov    %rax,%rcx
    5fa8:	4c 89 c0             	mov    %r8,%rax
    5fab:	48 03 05 8e 4c 06 00 	add    0x64c8e(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5fb2:	0f 82 35 01 00 00    	jb     60ed <fwp_heap_alloc+0x1dd>
    5fb8:	48 39 05 89 4c 06 00 	cmp    %rax,0x64c89(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fbf:	48 89 05 7a 4c 06 00 	mov    %rax,0x64c7a(%rip)        # 6ac40 <fwp_heap+0x1420>
    5fc6:	73 07                	jae    5fcf <fwp_heap_alloc+0xbf>
    5fc8:	48 89 05 79 4c 06 00 	mov    %rax,0x64c79(%rip)        # 6ac48 <fwp_heap+0x1428>
    5fcf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fd3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fd8:	f2 0f 58 05 78 4c 06 	addsd  0x64c78(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    5fdf:	00 
    5fe0:	f2 0f 11 05 70 4c 06 	movsd  %xmm0,0x64c70(%rip)        # 6ac58 <fwp_heap+0x1438>
    5fe7:	00 
    5fe8:	85 db                	test   %ebx,%ebx
    5fea:	74 33                	je     601f <fwp_heap_alloc+0x10f>
    5fec:	48 8b 05 4d 4c 06 00 	mov    0x64c4d(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    5ff3:	48 85 c0             	test   %rax,%rax
    5ff6:	0f 88 ac 00 00 00    	js     60a8 <fwp_heap_alloc+0x198>
    5ffc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6000:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    6005:	f2 0f 5c 05 bb 54 06 	subsd  0x654bb(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    600c:	00 
    600d:	66 0f 2f 05 ab 54 06 	comisd 0x654ab(%rip),%xmm0        # 6b4c0 <iteration_peak>
    6014:	00 
    6015:	76 08                	jbe    601f <fwp_heap_alloc+0x10f>
    6017:	f2 0f 11 05 a1 54 06 	movsd  %xmm0,0x654a1(%rip)        # 6b4c0 <iteration_peak>
    601e:	00 
    601f:	48 83 c4 10          	add    $0x10,%rsp
    6023:	48 89 c8             	mov    %rcx,%rax
    6026:	5b                   	pop    %rbx
    6027:	c3                   	ret
    6028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    602f:	00 
    6030:	85 f6                	test   %esi,%esi
    6032:	74 34                	je     6068 <fwp_heap_alloc+0x158>
    6034:	48 83 05 a4 54 06 00 	addq   $0x1,0x654a4(%rip)        # 6b4e0 <iteration_requests>
    603b:	01 
    603c:	48 01 3d 95 54 06 00 	add    %rdi,0x65495(%rip)        # 6b4d8 <iteration_bytes>
    6043:	85 c0                	test   %eax,%eax
    6045:	74 0d                	je     6054 <fwp_heap_alloc+0x144>
    6047:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    604e:	0f 86 ed fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6054:	48 89 d7             	mov    %rdx,%rdi
    6057:	e8 34 fd ff ff       	call   5d90 <fwp_heap_alloc_slow>
    605c:	48 89 c1             	mov    %rax,%rcx
    605f:	eb 8b                	jmp    5fec <fwp_heap_alloc+0xdc>
    6061:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6068:	85 c0                	test   %eax,%eax
    606a:	74 0d                	je     6079 <fwp_heap_alloc+0x169>
    606c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6073:	0f 86 c8 fe ff ff    	jbe    5f41 <fwp_heap_alloc+0x31>
    6079:	31 f6                	xor    %esi,%esi
    607b:	eb d7                	jmp    6054 <fwp_heap_alloc+0x144>
    607d:	0f 1f 00             	nopl   (%rax)
    6080:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6084:	48 85 c9             	test   %rcx,%rcx
    6087:	74 0c                	je     6095 <fwp_heap_alloc+0x185>
    6089:	48 8b 78 10          	mov    0x10(%rax),%rdi
    608d:	48 29 cf             	sub    %rcx,%rdi
    6090:	4c 39 c7             	cmp    %r8,%rdi
    6093:	73 3b                	jae    60d0 <fwp_heap_alloc+0x1c0>
    6095:	48 89 d7             	mov    %rdx,%rdi
    6098:	e8 f3 fc ff ff       	call   5d90 <fwp_heap_alloc_slow>
    609d:	48 89 c1             	mov    %rax,%rcx
    60a0:	e9 43 ff ff ff       	jmp    5fe8 <fwp_heap_alloc+0xd8>
    60a5:	0f 1f 00             	nopl   (%rax)
    60a8:	48 89 c2             	mov    %rax,%rdx
    60ab:	83 e0 01             	and    $0x1,%eax
    60ae:	66 0f ef c0          	pxor   %xmm0,%xmm0
    60b2:	48 d1 ea             	shr    $1,%rdx
    60b5:	48 09 c2             	or     %rax,%rdx
    60b8:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    60bd:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60c1:	e9 3f ff ff ff       	jmp    6005 <fwp_heap_alloc+0xf5>
    60c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60cd:	00 00 00 
    60d0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60d4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60d8:	e9 ad fe ff ff       	jmp    5f8a <fwp_heap_alloc+0x7a>
    60dd:	0f 1f 00             	nopl   (%rax)
    60e0:	48 83 c4 10          	add    $0x10,%rsp
    60e4:	48 89 d7             	mov    %rdx,%rdi
    60e7:	5b                   	pop    %rbx
    60e8:	e9 a3 fc ff ff       	jmp    5d90 <fwp_heap_alloc_slow>
    60ed:	e8 3e dd ff ff       	call   3e30 <fwp_heap_oom>
    60f2:	0f 1f 00             	nopl   (%rax)
    60f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60fc:	00 00 00 00 

0000000000006100 <fwp_data.part.0.constprop.0>:
    6100:	41 56                	push   %r14
    6102:	8b 05 bc 4a 06 00    	mov    0x64abc(%rip),%eax        # 6abc4 <fwp_heap+0x13a4>
    6108:	41 89 fe             	mov    %edi,%r14d
    610b:	41 55                	push   %r13
    610d:	44 8b 2d d4 53 06 00 	mov    0x653d4(%rip),%r13d        # 6b4e8 <iteration_active>
    6114:	41 54                	push   %r12
    6116:	49 89 f4             	mov    %rsi,%r12
    6119:	55                   	push   %rbp
    611a:	53                   	push   %rbx
    611b:	45 85 ed             	test   %r13d,%r13d
    611e:	0f 84 1c 01 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x140>
    6124:	48 83 05 b4 53 06 00 	addq   $0x1,0x653b4(%rip)        # 6b4e0 <iteration_requests>
    612b:	01 
    612c:	48 83 05 a4 53 06 00 	addq   $0x18,0x653a4(%rip)        # 6b4d8 <iteration_bytes>
    6133:	18 
    6134:	85 c0                	test   %eax,%eax
    6136:	0f 84 8c 01 00 00    	je     62c8 <fwp_data.part.0.constprop.0+0x1c8>
    613c:	0f b6 05 7f 46 06 00 	movzbl 0x6467f(%rip),%eax        # 6a7c2 <fwp_heap+0xfa2>
    6143:	48 8d 15 d6 36 06 00 	lea    0x636d6(%rip),%rdx        # 69820 <fwp_heap>
    614a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6151:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6155:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6159:	48 8b 18             	mov    (%rax),%rbx
    615c:	48 85 db             	test   %rbx,%rbx
    615f:	0f 84 fb 00 00 00    	je     6260 <fwp_data.part.0.constprop.0+0x160>
    6165:	48 8b 13             	mov    (%rbx),%rdx
    6168:	48 f7 d2             	not    %rdx
    616b:	48 89 10             	mov    %rdx,(%rax)
    616e:	48 83 fd 18          	cmp    $0x18,%rbp
    6172:	76 1b                	jbe    618f <fwp_data.part.0.constprop.0+0x8f>
    6174:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6178:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    617c:	31 f6                	xor    %esi,%esi
    617e:	48 c1 e8 03          	shr    $0x3,%rax
    6182:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6189:	00 
    618a:	e8 21 d3 ff ff       	call   34b0 <memset@plt>
    618f:	48 89 e8             	mov    %rbp,%rax
    6192:	48 03 05 a7 4a 06 00 	add    0x64aa7(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    6199:	0f 82 3d 01 00 00    	jb     62dc <fwp_data.part.0.constprop.0+0x1dc>
    619f:	48 39 05 a2 4a 06 00 	cmp    %rax,0x64aa2(%rip)        # 6ac48 <fwp_heap+0x1428>
    61a6:	48 89 05 93 4a 06 00 	mov    %rax,0x64a93(%rip)        # 6ac40 <fwp_heap+0x1420>
    61ad:	73 07                	jae    61b6 <fwp_data.part.0.constprop.0+0xb6>
    61af:	48 89 05 92 4a 06 00 	mov    %rax,0x64a92(%rip)        # 6ac48 <fwp_heap+0x1428>
    61b6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61ba:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    61bf:	f2 0f 58 05 91 4a 06 	addsd  0x64a91(%rip),%xmm0        # 6ac58 <fwp_heap+0x1438>
    61c6:	00 
    61c7:	f2 0f 11 05 89 4a 06 	movsd  %xmm0,0x64a89(%rip)        # 6ac58 <fwp_heap+0x1438>
    61ce:	00 
    61cf:	45 85 ed             	test   %r13d,%r13d
    61d2:	74 33                	je     6207 <fwp_data.part.0.constprop.0+0x107>
    61d4:	48 8b 05 65 4a 06 00 	mov    0x64a65(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    61db:	48 85 c0             	test   %rax,%rax
    61de:	0f 88 a4 00 00 00    	js     6288 <fwp_data.part.0.constprop.0+0x188>
    61e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61e8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61ed:	f2 0f 5c 05 d3 52 06 	subsd  0x652d3(%rip),%xmm0        # 6b4c8 <iteration_start_charge>
    61f4:	00 
    61f5:	66 0f 2f 05 c3 52 06 	comisd 0x652c3(%rip),%xmm0        # 6b4c0 <iteration_peak>
    61fc:	00 
    61fd:	76 08                	jbe    6207 <fwp_data.part.0.constprop.0+0x107>
    61ff:	f2 0f 11 05 b9 52 06 	movsd  %xmm0,0x652b9(%rip)        # 6b4c0 <iteration_peak>
    6206:	00 
    6207:	b8 02 00 00 00       	mov    $0x2,%eax
    620c:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6211:	66 0f 6e c8          	movd   %eax,%xmm1
    6215:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6219:	66 0f d6 03          	movq   %xmm0,(%rbx)
    621d:	49 8b 04 24          	mov    (%r12),%rax
    6221:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6225:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    622a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    622e:	48 89 d8             	mov    %rbx,%rax
    6231:	5b                   	pop    %rbx
    6232:	5d                   	pop    %rbp
    6233:	41 5c                	pop    %r12
    6235:	41 5d                	pop    %r13
    6237:	41 5e                	pop    %r14
    6239:	c3                   	ret
    623a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6240:	85 c0                	test   %eax,%eax
    6242:	0f 85 f4 fe ff ff    	jne    613c <fwp_data.part.0.constprop.0+0x3c>
    6248:	31 f6                	xor    %esi,%esi
    624a:	bf 18 00 00 00       	mov    $0x18,%edi
    624f:	e8 bc fc ff ff       	call   5f10 <fwp_heap_alloc>
    6254:	48 89 c3             	mov    %rax,%rbx
    6257:	eb ae                	jmp    6207 <fwp_data.part.0.constprop.0+0x107>
    6259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6260:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6264:	48 85 db             	test   %rbx,%rbx
    6267:	74 47                	je     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6269:	48 8b 50 10          	mov    0x10(%rax),%rdx
    626d:	48 29 da             	sub    %rbx,%rdx
    6270:	48 39 ea             	cmp    %rbp,%rdx
    6273:	72 3b                	jb     62b0 <fwp_data.part.0.constprop.0+0x1b0>
    6275:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6279:	48 89 50 08          	mov    %rdx,0x8(%rax)
    627d:	e9 ec fe ff ff       	jmp    616e <fwp_data.part.0.constprop.0+0x6e>
    6282:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6288:	48 89 c2             	mov    %rax,%rdx
    628b:	83 e0 01             	and    $0x1,%eax
    628e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6292:	48 d1 ea             	shr    $1,%rdx
    6295:	48 09 c2             	or     %rax,%rdx
    6298:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    629d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    62a1:	e9 47 ff ff ff       	jmp    61ed <fwp_data.part.0.constprop.0+0xed>
    62a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    62ad:	00 00 00 
    62b0:	31 f6                	xor    %esi,%esi
    62b2:	bf 18 00 00 00       	mov    $0x18,%edi
    62b7:	e8 54 fc ff ff       	call   5f10 <fwp_heap_alloc>
    62bc:	48 89 c3             	mov    %rax,%rbx
    62bf:	e9 0b ff ff ff       	jmp    61cf <fwp_data.part.0.constprop.0+0xcf>
    62c4:	0f 1f 40 00          	nopl   0x0(%rax)
    62c8:	31 f6                	xor    %esi,%esi
    62ca:	bf 18 00 00 00       	mov    $0x18,%edi
    62cf:	e8 3c fc ff ff       	call   5f10 <fwp_heap_alloc>
    62d4:	48 89 c3             	mov    %rax,%rbx
    62d7:	e9 f8 fe ff ff       	jmp    61d4 <fwp_data.part.0.constprop.0+0xd4>
    62dc:	e8 4f db ff ff       	call   3e30 <fwp_heap_oom>
    62e1:	0f 1f 40 00          	nopl   0x0(%rax)
    62e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62ec:	00 00 00 00 

00000000000062f0 <fwp_tape_reserve>:
    62f0:	41 57                	push   %r15
    62f2:	41 56                	push   %r14
    62f4:	41 55                	push   %r13
    62f6:	41 54                	push   %r12
    62f8:	55                   	push   %rbp
    62f9:	53                   	push   %rbx
    62fa:	48 83 ec 18          	sub    $0x18,%rsp
    62fe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6305:	0f 87 cd 01 00 00    	ja     64d8 <fwp_tape_reserve+0x1e8>
    630b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    630f:	48 89 fd             	mov    %rdi,%rbp
    6312:	48 39 f3             	cmp    %rsi,%rbx
    6315:	0f 8d 18 01 00 00    	jge    6433 <fwp_tape_reserve+0x143>
    631b:	48 85 db             	test   %rbx,%rbx
    631e:	b8 40 00 00 00       	mov    $0x40,%eax
    6323:	48 0f 44 d8          	cmove  %rax,%rbx
    6327:	48 39 f3             	cmp    %rsi,%rbx
    632a:	7d 24                	jge    6350 <fwp_tape_reserve+0x60>
    632c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6333:	0f 8f 0f 01 00 00    	jg     6448 <fwp_tape_reserve+0x158>
    6339:	48 01 db             	add    %rbx,%rbx
    633c:	48 39 f3             	cmp    %rsi,%rbx
    633f:	7c eb                	jl     632c <fwp_tape_reserve+0x3c>
    6341:	0f 1f 40 00          	nopl   0x0(%rax)
    6345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    634c:	00 00 00 00 
    6350:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    6357:	00 
    6358:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    635c:	ba 01 00 00 00       	mov    $0x1,%edx
    6361:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    6365:	4c 89 ee             	mov    %r13,%rsi
    6368:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    636c:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6370:	e8 0b ee ff ff       	call   5180 <ad_raw_realloc>
    6375:	48 85 c0             	test   %rax,%rax
    6378:	0f 84 66 01 00 00    	je     64e4 <fwp_tape_reserve+0x1f4>
    637e:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    6382:	48 89 45 20          	mov    %rax,0x20(%rbp)
    6386:	4d 29 fc             	sub    %r15,%r12
    6389:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    638d:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    6391:	4d 85 f6             	test   %r14,%r14
    6394:	0f 84 f6 00 00 00    	je     6490 <fwp_tape_reserve+0x1a0>
    639a:	49 8b 56 60          	mov    0x60(%r14),%rdx
    639e:	48 39 da             	cmp    %rbx,%rdx
    63a1:	7d 78                	jge    641b <fwp_tape_reserve+0x12b>
    63a3:	48 89 d9             	mov    %rbx,%rcx
    63a6:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    63aa:	be 02 00 00 00       	mov    $0x2,%esi
    63af:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    63b4:	48 c1 e1 04          	shl    $0x4,%rcx
    63b8:	48 89 cf             	mov    %rcx,%rdi
    63bb:	48 89 0c 24          	mov    %rcx,(%rsp)
    63bf:	e8 4c fb ff ff       	call   5f10 <fwp_heap_alloc>
    63c4:	49 89 c5             	mov    %rax,%r13
    63c7:	4d 85 ff             	test   %r15,%r15
    63ca:	74 27                	je     63f3 <fwp_tape_reserve+0x103>
    63cc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    63d1:	48 8b 0c 24          	mov    (%rsp),%rcx
    63d5:	48 89 c7             	mov    %rax,%rdi
    63d8:	4c 89 fe             	mov    %r15,%rsi
    63db:	48 c1 e2 04          	shl    $0x4,%rdx
    63df:	48 39 ca             	cmp    %rcx,%rdx
    63e2:	48 0f 47 d1          	cmova  %rcx,%rdx
    63e6:	e8 95 d1 ff ff       	call   3580 <memcpy@plt>
    63eb:	4c 89 ff             	mov    %r15,%rdi
    63ee:	e8 1d f6 ff ff       	call   5a10 <fwp_mem_free>
    63f3:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    63f7:	48 89 da             	mov    %rbx,%rdx
    63fa:	31 f6                	xor    %esi,%esi
    63fc:	48 29 fa             	sub    %rdi,%rdx
    63ff:	48 c1 e7 04          	shl    $0x4,%rdi
    6403:	48 c1 e2 04          	shl    $0x4,%rdx
    6407:	4c 01 ef             	add    %r13,%rdi
    640a:	e8 a1 d0 ff ff       	call   34b0 <memset@plt>
    640f:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    6413:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6417:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    641b:	4d 85 e4             	test   %r12,%r12
    641e:	75 4b                	jne    646b <fwp_tape_reserve+0x17b>
    6420:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6427:	00 
    6428:	4c 01 e8             	add    %r13,%rax
    642b:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    642f:	48 89 45 28          	mov    %rax,0x28(%rbp)
    6433:	48 83 c4 18          	add    $0x18,%rsp
    6437:	5b                   	pop    %rbx
    6438:	5d                   	pop    %rbp
    6439:	41 5c                	pop    %r12
    643b:	41 5d                	pop    %r13
    643d:	41 5e                	pop    %r14
    643f:	41 5f                	pop    %r15
    6441:	c3                   	ret
    6442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6448:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    644d:	e9 fe fe ff ff       	jmp    6350 <fwp_tape_reserve+0x60>
    6452:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6459:	00 
    645a:	e8 91 d1 ff ff       	call   35f0 <memmove@plt>
    645f:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6463:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6467:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    646b:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    646f:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6476:	00 
    6477:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    647e:	00 
    647f:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6483:	e8 68 d1 ff ff       	call   35f0 <memmove@plt>
    6488:	48 8b 45 20          	mov    0x20(%rbp),%rax
    648c:	eb 9a                	jmp    6428 <fwp_tape_reserve+0x138>
    648e:	66 90                	xchg   %ax,%ax
    6490:	48 89 de             	mov    %rbx,%rsi
    6493:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6497:	ba 02 00 00 00       	mov    $0x2,%edx
    649c:	48 c1 e6 04          	shl    $0x4,%rsi
    64a0:	e8 db ec ff ff       	call   5180 <ad_raw_realloc>
    64a5:	48 85 c0             	test   %rax,%rax
    64a8:	74 3a                	je     64e4 <fwp_tape_reserve+0x1f4>
    64aa:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    64ae:	48 89 45 30          	mov    %rax,0x30(%rbp)
    64b2:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    64b6:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    64ba:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    64be:	4d 85 e4             	test   %r12,%r12
    64c1:	75 8f                	jne    6452 <fwp_tape_reserve+0x162>
    64c3:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    64c7:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64cb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    64d2:	00 
    64d3:	e9 50 ff ff ff       	jmp    6428 <fwp_tape_reserve+0x138>
    64d8:	48 8d 3d c8 6c 00 00 	lea    0x6cc8(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    64df:	e8 6c df ff ff       	call   4450 <fwp_trap>
    64e4:	48 89 ef             	mov    %rbp,%rdi
    64e7:	e8 a4 d7 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    64ec:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    64f0:	48 85 ff             	test   %rdi,%rdi
    64f3:	74 05                	je     64fa <fwp_tape_reserve+0x20a>
    64f5:	e8 d6 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    64fa:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    64fe:	48 85 ff             	test   %rdi,%rdi
    6501:	74 05                	je     6508 <fwp_tape_reserve+0x218>
    6503:	e8 c8 eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6508:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    650c:	48 85 ff             	test   %rdi,%rdi
    650f:	74 05                	je     6516 <fwp_tape_reserve+0x226>
    6511:	e8 ba eb ff ff       	call   50d0 <ad_raw_free.part.0>
    6516:	31 c9                	xor    %ecx,%ecx
    6518:	31 c0                	xor    %eax,%eax
    651a:	31 d2                	xor    %edx,%edx
    651c:	be 01 00 00 00       	mov    $0x1,%esi
    6521:	89 55 04             	mov    %edx,0x4(%rbp)
    6524:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6528:	ba 13 00 00 00       	mov    $0x13,%edx
    652d:	48 8d 3d d4 6a 00 00 	lea    0x6ad4(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    6534:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6538:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    653c:	48 8b 0d fd aa 00 00 	mov    0xaafd(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    6543:	48 89 45 40          	mov    %rax,0x40(%rbp)
    6547:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    654b:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    654f:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6553:	e8 08 d1 ff ff       	call   3660 <fwrite@plt>
    6558:	31 ff                	xor    %edi,%edi
    655a:	e8 41 d0 ff ff       	call   35a0 <fflush@plt>
    655f:	bf 66 00 00 00       	mov    $0x66,%edi
    6564:	e8 17 d1 ff ff       	call   3680 <_Exit@plt>
    6569:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006570 <f141.constprop.0>:
    6570:	41 57                	push   %r15
    6572:	41 56                	push   %r14
    6574:	41 55                	push   %r13
    6576:	41 54                	push   %r12
    6578:	49 89 f4             	mov    %rsi,%r12
    657b:	55                   	push   %rbp
    657c:	48 89 fd             	mov    %rdi,%rbp
    657f:	53                   	push   %rbx
    6580:	48 83 ec 08          	sub    $0x8,%rsp
    6584:	48 85 ff             	test   %rdi,%rdi
    6587:	79 09                	jns    6592 <f141.constprop.0+0x22>
    6589:	48 85 f6             	test   %rsi,%rsi
    658c:	0f 88 fe 00 00 00    	js     6690 <f141.constprop.0+0x120>
    6592:	48 89 f8             	mov    %rdi,%rax
    6595:	48 09 f0             	or     %rsi,%rax
    6598:	0f 89 d2 00 00 00    	jns    6670 <f141.constprop.0+0x100>
    659e:	48 89 f8             	mov    %rdi,%rax
    65a1:	48 c1 f8 20          	sar    $0x20,%rax
    65a5:	48 85 ff             	test   %rdi,%rdi
    65a8:	0f 88 02 01 00 00    	js     66b0 <f141.constprop.0+0x140>
    65ae:	4c 8b 3d b3 77 00 00 	mov    0x77b3(%rip),%r15        # dd68 <msg.4+0x28>
    65b5:	48 89 c7             	mov    %rax,%rdi
    65b8:	e8 73 e1 ff ff       	call   4730 <fwp_tape_of>
    65bd:	48 89 c3             	mov    %rax,%rbx
    65c0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65c5:	0f 85 16 01 00 00    	jne    66e1 <f141.constprop.0+0x171>
    65cb:	4c 8b 68 10          	mov    0x10(%rax),%r13
    65cf:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    65d6:	0f 8f f9 00 00 00    	jg     66d5 <f141.constprop.0+0x165>
    65dc:	89 e8                	mov    %ebp,%eax
    65de:	49 39 c5             	cmp    %rax,%r13
    65e1:	0f 8e e2 00 00 00    	jle    66c9 <f141.constprop.0+0x159>
    65e7:	4d 85 e4             	test   %r12,%r12
    65ea:	78 0c                	js     65f8 <f141.constprop.0+0x88>
    65ec:	44 89 e0             	mov    %r12d,%eax
    65ef:	49 39 c5             	cmp    %rax,%r13
    65f2:	0f 8e d1 00 00 00    	jle    66c9 <f141.constprop.0+0x159>
    65f8:	4d 89 ee             	mov    %r13,%r14
    65fb:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    65ff:	48 89 df             	mov    %rbx,%rdi
    6602:	49 8d 76 01          	lea    0x1(%r14),%rsi
    6606:	e8 e5 fc ff ff       	call   62f0 <fwp_tape_reserve>
    660b:	48 8b 43 20          	mov    0x20(%rbx),%rax
    660f:	4d 85 e4             	test   %r12,%r12
    6612:	48 8b 0d 4f 77 00 00 	mov    0x774f(%rip),%rcx        # dd68 <msg.4+0x28>
    6619:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6620:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6624:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6628:	4c 0f 48 e2          	cmovs  %rdx,%r12
    662c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6630:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6634:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6638:	48 8b 43 38          	mov    0x38(%rbx),%rax
    663c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6640:	49 8d 45 01          	lea    0x1(%r13),%rax
    6644:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6648:	48 83 c4 08          	add    $0x8,%rsp
    664c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6653:	ff ff ff 
    6656:	48 21 e8             	and    %rbp,%rax
    6659:	5b                   	pop    %rbx
    665a:	5d                   	pop    %rbp
    665b:	4c 09 e8             	or     %r13,%rax
    665e:	41 5c                	pop    %r12
    6660:	41 5d                	pop    %r13
    6662:	41 5e                	pop    %r14
    6664:	41 5f                	pop    %r15
    6666:	c3                   	ret
    6667:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    666e:	00 00 
    6670:	48 89 f0             	mov    %rsi,%rax
    6673:	48 c1 ff 20          	sar    $0x20,%rdi
    6677:	48 c1 f8 20          	sar    $0x20,%rax
    667b:	48 39 c7             	cmp    %rax,%rdi
    667e:	0f 84 2a ff ff ff    	je     65ae <f141.constprop.0+0x3e>
    6684:	48 8d 3d 8d 73 00 00 	lea    0x738d(%rip),%rdi        # da18 <_IO_stdin_used+0xa18>
    668b:	e8 c0 dd ff ff       	call   4450 <fwp_trap>
    6690:	48 83 c4 08          	add    $0x8,%rsp
    6694:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    669b:	5b                   	pop    %rbx
    669c:	5d                   	pop    %rbp
    669d:	41 5c                	pop    %r12
    669f:	41 5d                	pop    %r13
    66a1:	41 5e                	pop    %r14
    66a3:	41 5f                	pop    %r15
    66a5:	c3                   	ret
    66a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    66ad:	00 00 00 
    66b0:	48 89 f0             	mov    %rsi,%rax
    66b3:	48 89 f5             	mov    %rsi,%rbp
    66b6:	45 31 ff             	xor    %r15d,%r15d
    66b9:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    66c0:	48 c1 f8 20          	sar    $0x20,%rax
    66c4:	e9 ec fe ff ff       	jmp    65b5 <f141.constprop.0+0x45>
    66c9:	48 8d 3d f2 6a 00 00 	lea    0x6af2(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    66d0:	e8 7b dd ff ff       	call   4450 <fwp_trap>
    66d5:	48 8d 3d cb 6a 00 00 	lea    0x6acb(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    66dc:	e8 6f dd ff ff       	call   4450 <fwp_trap>
    66e1:	48 8d 3d 78 73 00 00 	lea    0x7378(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    66e8:	e8 63 dd ff ff       	call   4450 <fwp_trap>
    66ed:	0f 1f 00             	nopl   (%rax)

00000000000066f0 <w120>:
    66f0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    66f4:	41 57                	push   %r15
    66f6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    66fa:	41 56                	push   %r14
    66fc:	41 55                	push   %r13
    66fe:	41 54                	push   %r12
    6700:	49 89 f4             	mov    %rsi,%r12
    6703:	55                   	push   %rbp
    6704:	48 89 fd             	mov    %rdi,%rbp
    6707:	53                   	push   %rbx
    6708:	48 83 ec 38          	sub    $0x38,%rsp
    670c:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6711:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6717:	48 85 ff             	test   %rdi,%rdi
    671a:	0f 88 d0 04 00 00    	js     6bf0 <w120+0x500>
    6720:	49 89 ff             	mov    %rdi,%r15
    6723:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6729:	49 c1 ff 20          	sar    $0x20,%r15
    672d:	4c 89 ff             	mov    %r15,%rdi
    6730:	e8 fb df ff ff       	call   4730 <fwp_tape_of>
    6735:	48 89 c3             	mov    %rax,%rbx
    6738:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    673d:	0f 85 45 05 00 00    	jne    6c88 <w120+0x598>
    6743:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6747:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    674e:	0f 8f 28 05 00 00    	jg     6c7c <w120+0x58c>
    6754:	89 e8                	mov    %ebp,%eax
    6756:	49 39 c5             	cmp    %rax,%r13
    6759:	0f 8e 11 05 00 00    	jle    6c70 <w120+0x580>
    675f:	4d 89 ee             	mov    %r13,%r14
    6762:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6766:	48 89 df             	mov    %rbx,%rdi
    6769:	49 8d 76 01          	lea    0x1(%r14),%rsi
    676d:	e8 7e fb ff ff       	call   62f0 <fwp_tape_reserve>
    6772:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6776:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    677b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6781:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6785:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6789:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    678f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6793:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6797:	48 8b 43 38          	mov    0x38(%rbx),%rax
    679b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    67a1:	49 8d 45 01          	lea    0x1(%r13),%rax
    67a5:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    67ac:	ff ff ff 
    67af:	49 21 ee             	and    %rbp,%r14
    67b2:	48 89 43 10          	mov    %rax,0x10(%rbx)
    67b6:	4d 09 ee             	or     %r13,%r14
    67b9:	4d 89 f5             	mov    %r14,%r13
    67bc:	49 c1 fd 20          	sar    $0x20,%r13
    67c0:	4d 85 e4             	test   %r12,%r12
    67c3:	78 10                	js     67d5 <w120+0xe5>
    67c5:	4c 89 e0             	mov    %r12,%rax
    67c8:	48 c1 f8 20          	sar    $0x20,%rax
    67cc:	4c 39 e8             	cmp    %r13,%rax
    67cf:	0f 85 87 04 00 00    	jne    6c5c <w120+0x56c>
    67d5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    67db:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67e1:	4d 39 ef             	cmp    %r13,%r15
    67e4:	0f 84 d6 03 00 00    	je     6bc0 <w120+0x4d0>
    67ea:	f2 0f 10 1d 76 75 00 	movsd  0x7576(%rip),%xmm3        # dd68 <msg.4+0x28>
    67f1:	00 
    67f2:	f2 0f 10 25 76 75 00 	movsd  0x7576(%rip),%xmm4        # dd70 <msg.4+0x30>
    67f9:	00 
    67fa:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    6800:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    6806:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    680c:	4c 89 ef             	mov    %r13,%rdi
    680f:	e8 1c df ff ff       	call   4730 <fwp_tape_of>
    6814:	48 89 c3             	mov    %rax,%rbx
    6817:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    681c:	0f 85 66 04 00 00    	jne    6c88 <w120+0x598>
    6822:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6826:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    682d:	0f 8f 49 04 00 00    	jg     6c7c <w120+0x58c>
    6833:	44 89 f0             	mov    %r14d,%eax
    6836:	49 39 c7             	cmp    %rax,%r15
    6839:	0f 8e 31 04 00 00    	jle    6c70 <w120+0x580>
    683f:	4d 85 e4             	test   %r12,%r12
    6842:	78 0c                	js     6850 <w120+0x160>
    6844:	44 89 e0             	mov    %r12d,%eax
    6847:	49 39 c7             	cmp    %rax,%r15
    684a:	0f 8e 20 04 00 00    	jle    6c70 <w120+0x580>
    6850:	4c 89 f9             	mov    %r15,%rcx
    6853:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6857:	48 89 df             	mov    %rbx,%rdi
    685a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    685e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6863:	e8 88 fa ff ff       	call   62f0 <fwp_tape_reserve>
    6868:	48 8b 43 20          	mov    0x20(%rbx),%rax
    686c:	4d 85 e4             	test   %r12,%r12
    686f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6873:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6878:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    687e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6884:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6888:	48 8b 43 30          	mov    0x30(%rbx),%rax
    688c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6891:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6898:	49 0f 49 c4          	cmovns %r12,%rax
    689c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    68a0:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    68a3:	48 8b 43 38          	mov    0x38(%rbx),%rax
    68a7:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    68ac:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    68b0:	48 85 ed             	test   %rbp,%rbp
    68b3:	0f 88 0e 04 00 00    	js     6cc7 <w120+0x5d7>
    68b9:	48 89 e8             	mov    %rbp,%rax
    68bc:	48 c1 f8 20          	sar    $0x20,%rax
    68c0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    68c5:	49 39 c5             	cmp    %rax,%r13
    68c8:	74 1a                	je     68e4 <w120+0x1f4>
    68ca:	48 89 c7             	mov    %rax,%rdi
    68cd:	e8 5e de ff ff       	call   4730 <fwp_tape_of>
    68d2:	48 89 c3             	mov    %rax,%rbx
    68d5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    68da:	0f 85 a8 03 00 00    	jne    6c88 <w120+0x598>
    68e0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    68e4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    68eb:	0f 8f 8b 03 00 00    	jg     6c7c <w120+0x58c>
    68f1:	89 e8                	mov    %ebp,%eax
    68f3:	4c 39 e0             	cmp    %r12,%rax
    68f6:	0f 8d 74 03 00 00    	jge    6c70 <w120+0x580>
    68fc:	4c 89 e0             	mov    %r12,%rax
    68ff:	48 2b 43 08          	sub    0x8(%rbx),%rax
    6903:	48 89 df             	mov    %rbx,%rdi
    6906:	48 8d 70 01          	lea    0x1(%rax),%rsi
    690a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    690f:	e8 dc f9 ff ff       	call   62f0 <fwp_tape_reserve>
    6914:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6919:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    691d:	48 8b 0d 4c 74 00 00 	mov    0x744c(%rip),%rcx        # dd70 <msg.4+0x30>
    6924:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    692a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    692d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6931:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6935:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    693b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    693f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6943:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6947:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    694e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6952:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6957:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    695c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6960:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6967:	ff ff ff 
    696a:	48 21 c5             	and    %rax,%rbp
    696d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6973:	4c 09 e5             	or     %r12,%rbp
    6976:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    697d:	ff ff ff 
    6980:	49 21 c6             	and    %rax,%r14
    6983:	4d 09 fe             	or     %r15,%r14
    6986:	4d 89 f4             	mov    %r14,%r12
    6989:	49 c1 fc 20          	sar    $0x20,%r12
    698d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6992:	74 16                	je     69aa <w120+0x2ba>
    6994:	4c 89 e7             	mov    %r12,%rdi
    6997:	e8 94 dd ff ff       	call   4730 <fwp_tape_of>
    699c:	48 89 c3             	mov    %rax,%rbx
    699f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    69a4:	0f 85 de 02 00 00    	jne    6c88 <w120+0x598>
    69aa:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    69ae:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    69b5:	0f 8f c1 02 00 00    	jg     6c7c <w120+0x58c>
    69bb:	44 89 f0             	mov    %r14d,%eax
    69be:	49 39 c7             	cmp    %rax,%r15
    69c1:	0f 8e a9 02 00 00    	jle    6c70 <w120+0x580>
    69c7:	4d 89 fd             	mov    %r15,%r13
    69ca:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    69ce:	48 89 df             	mov    %rbx,%rdi
    69d1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    69d5:	e8 16 f9 ff ff       	call   62f0 <fwp_tape_reserve>
    69da:	48 8b 43 20          	mov    0x20(%rbx),%rax
    69de:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    69e4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69e8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    69ec:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    69f2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    69f6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69fa:	48 8b 43 38          	mov    0x38(%rbx),%rax
    69fe:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    6a04:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    6a08:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6a0f:	ff ff ff 
    6a12:	49 21 c6             	and    %rax,%r14
    6a15:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6a19:	4d 09 fe             	or     %r15,%r14
    6a1c:	4d 89 f7             	mov    %r14,%r15
    6a1f:	49 c1 ff 20          	sar    $0x20,%r15
    6a23:	4d 39 e7             	cmp    %r12,%r15
    6a26:	74 1d                	je     6a45 <w120+0x355>
    6a28:	4c 89 ff             	mov    %r15,%rdi
    6a2b:	e8 00 dd ff ff       	call   4730 <fwp_tape_of>
    6a30:	48 89 c3             	mov    %rax,%rbx
    6a33:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a38:	0f 85 4a 02 00 00    	jne    6c88 <w120+0x598>
    6a3e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6a42:	4d 89 fc             	mov    %r15,%r12
    6a45:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6a4c:	0f 8f 2a 02 00 00    	jg     6c7c <w120+0x58c>
    6a52:	44 89 f0             	mov    %r14d,%eax
    6a55:	4c 39 e8             	cmp    %r13,%rax
    6a58:	0f 8d 12 02 00 00    	jge    6c70 <w120+0x580>
    6a5e:	f2 0f 10 3d 12 73 00 	movsd  0x7312(%rip),%xmm7        # dd78 <msg.4+0x38>
    6a65:	00 
    6a66:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    6a6c:	4d 89 ef             	mov    %r13,%r15
    6a6f:	48 89 df             	mov    %rbx,%rdi
    6a72:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6a78:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    6a7d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6a81:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6a85:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    6a8a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6a90:	e8 5b f8 ff ff       	call   62f0 <fwp_tape_reserve>
    6a95:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6a99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6a9e:	48 8b 15 d3 72 00 00 	mov    0x72d3(%rip),%rdx        # dd78 <msg.4+0x38>
    6aa5:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6aa9:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6aad:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6ab1:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6ab5:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6ab9:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6abd:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6ac4:	ff 
    6ac5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6ac9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6ad0:	00 
    6ad1:	49 8d 45 01          	lea    0x1(%r13),%rax
    6ad5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6ad9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6ae0:	ff ff ff 
    6ae3:	49 21 c6             	and    %rax,%r14
    6ae6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    6aec:	4d 09 ee             	or     %r13,%r14
    6aef:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6af3:	0f 84 57 01 00 00    	je     6c50 <w120+0x560>
    6af9:	48 89 ef             	mov    %rbp,%rdi
    6afc:	48 c1 ff 20          	sar    $0x20,%rdi
    6b00:	4c 39 e7             	cmp    %r12,%rdi
    6b03:	74 13                	je     6b18 <w120+0x428>
    6b05:	e8 26 dc ff ff       	call   4730 <fwp_tape_of>
    6b0a:	48 89 c3             	mov    %rax,%rbx
    6b0d:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6b12:	0f 85 70 01 00 00    	jne    6c88 <w120+0x598>
    6b18:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6b1c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6b23:	0f 8f 53 01 00 00    	jg     6c7c <w120+0x58c>
    6b29:	89 e8                	mov    %ebp,%eax
    6b2b:	4c 39 e0             	cmp    %r12,%rax
    6b2e:	0f 8d 3c 01 00 00    	jge    6c70 <w120+0x580>
    6b34:	4d 89 e5             	mov    %r12,%r13
    6b37:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6b3b:	48 89 df             	mov    %rbx,%rdi
    6b3e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6b42:	e8 a9 f7 ff ff       	call   62f0 <fwp_tape_reserve>
    6b47:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6b4b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6b50:	48 89 ef             	mov    %rbp,%rdi
    6b53:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b57:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6b5b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b61:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6b65:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b69:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6b6d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b73:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6b78:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6b7c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6b83:	ff ff ff 
    6b86:	48 21 c7             	and    %rax,%rdi
    6b89:	4c 09 e7             	or     %r12,%rdi
    6b8c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6b92:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6b98:	4c 89 f6             	mov    %r14,%rsi
    6b9b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6ba0:	e8 cb f9 ff ff       	call   6570 <f141.constprop.0>
    6ba5:	48 83 c4 38          	add    $0x38,%rsp
    6ba9:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6bae:	5b                   	pop    %rbx
    6baf:	5d                   	pop    %rbp
    6bb0:	41 5c                	pop    %r12
    6bb2:	41 5d                	pop    %r13
    6bb4:	41 5e                	pop    %r14
    6bb6:	41 5f                	pop    %r15
    6bb8:	c3                   	ret
    6bb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6bc0:	f2 0f 10 3d a0 71 00 	movsd  0x71a0(%rip),%xmm7        # dd68 <msg.4+0x28>
    6bc7:	00 
    6bc8:	f2 0f 10 15 a0 71 00 	movsd  0x71a0(%rip),%xmm2        # dd70 <msg.4+0x30>
    6bcf:	00 
    6bd0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6bd6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    6bdc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6be2:	e9 3b fc ff ff       	jmp    6822 <w120+0x132>
    6be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bee:	00 00 
    6bf0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6bf6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6bfc:	48 85 f6             	test   %rsi,%rsi
    6bff:	0f 89 8f 00 00 00    	jns    6c94 <w120+0x5a4>
    6c05:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6c0b:	f2 0f 10 05 55 71 00 	movsd  0x7155(%rip),%xmm0        # dd68 <msg.4+0x28>
    6c12:	00 
    6c13:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    6c1a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c21:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6c26:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6c2a:	f2 0f 59 0d 46 71 00 	mulsd  0x7146(%rip),%xmm1        # dd78 <msg.4+0x38>
    6c31:	00 
    6c32:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6c36:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c3c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6c42:	e9 45 ff ff ff       	jmp    6b8c <w120+0x49c>
    6c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c4e:	00 00 
    6c50:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c57:	e9 30 ff ff ff       	jmp    6b8c <w120+0x49c>
    6c5c:	48 8d 3d b5 6d 00 00 	lea    0x6db5(%rip),%rdi        # da18 <_IO_stdin_used+0xa18>
    6c63:	e8 e8 d7 ff ff       	call   4450 <fwp_trap>
    6c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c6f:	00 
    6c70:	48 8d 3d 4b 65 00 00 	lea    0x654b(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    6c77:	e8 d4 d7 ff ff       	call   4450 <fwp_trap>
    6c7c:	48 8d 3d 24 65 00 00 	lea    0x6524(%rip),%rdi        # d1a7 <_IO_stdin_used+0x1a7>
    6c83:	e8 c8 d7 ff ff       	call   4450 <fwp_trap>
    6c88:	48 8d 3d d1 6d 00 00 	lea    0x6dd1(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    6c8f:	e8 bc d7 ff ff       	call   4450 <fwp_trap>
    6c94:	f2 0f 10 35 cc 70 00 	movsd  0x70cc(%rip),%xmm6        # dd68 <msg.4+0x28>
    6c9b:	00 
    6c9c:	49 89 f5             	mov    %rsi,%r13
    6c9f:	49 89 f6             	mov    %rsi,%r14
    6ca2:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6ca9:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6cb0:	00 00 
    6cb2:	49 c1 fd 20          	sar    $0x20,%r13
    6cb6:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    6cbc:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6cc2:	e9 45 fb ff ff       	jmp    680c <w120+0x11c>
    6cc7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    6ccd:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6cd2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6cd9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    6cdd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6ce1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6ce7:	e9 8a fc ff ff       	jmp    6976 <w120+0x286>
    6cec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cf0 <fwp_rc_share>:
    6cf0:	48 8b 05 01 3f 06 00 	mov    0x63f01(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    6cf7:	48 2b 3d d2 3e 06 00 	sub    0x63ed2(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    6cfe:	48 c1 e0 10          	shl    $0x10,%rax
    6d02:	48 39 c7             	cmp    %rax,%rdi
    6d05:	73 4a                	jae    6d51 <fwp_rc_share+0x61>
    6d07:	48 89 f8             	mov    %rdi,%rax
    6d0a:	48 c1 e8 10          	shr    $0x10,%rax
    6d0e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6d12:	48 8b 05 ff 3e 06 00 	mov    0x63eff(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    6d19:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6d1d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6d21:	48 85 d2             	test   %rdx,%rdx
    6d24:	74 2b                	je     6d51 <fwp_rc_share+0x61>
    6d26:	0f b6 08             	movzbl (%rax),%ecx
    6d29:	80 f9 02             	cmp    $0x2,%cl
    6d2c:	74 2a                	je     6d58 <fwp_rc_share+0x68>
    6d2e:	80 f9 01             	cmp    $0x1,%cl
    6d31:	75 1e                	jne    6d51 <fwp_rc_share+0x61>
    6d33:	8b 48 18             	mov    0x18(%rax),%ecx
    6d36:	0f b7 ff             	movzwl %di,%edi
    6d39:	8b 40 1c             	mov    0x1c(%rax),%eax
    6d3c:	48 0f af f9          	imul   %rcx,%rdi
    6d40:	48 c1 ef 20          	shr    $0x20,%rdi
    6d44:	48 39 c7             	cmp    %rax,%rdi
    6d47:	73 08                	jae    6d51 <fwp_rc_share+0x61>
    6d49:	48 01 fa             	add    %rdi,%rdx
    6d4c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6d4f:	75 0d                	jne    6d5e <fwp_rc_share+0x6e>
    6d51:	c3                   	ret
    6d52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d58:	66 85 ff             	test   %di,%di
    6d5b:	74 ef                	je     6d4c <fwp_rc_share+0x5c>
    6d5d:	c3                   	ret
    6d5e:	50                   	push   %rax
    6d5f:	48 8d 3d 2a 6d 00 00 	lea    0x6d2a(%rip),%rdi        # da90 <_IO_stdin_used+0xa90>
    6d66:	e8 e5 d6 ff ff       	call   4450 <fwp_trap>
    6d6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006d70 <fwp_rc_free_obj>:
    6d70:	48 8b 15 81 3e 06 00 	mov    0x63e81(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6d77:	48 89 f8             	mov    %rdi,%rax
    6d7a:	48 2b 05 4f 3e 06 00 	sub    0x63e4f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6d81:	48 c1 e2 10          	shl    $0x10,%rdx
    6d85:	48 39 d0             	cmp    %rdx,%rax
    6d88:	73 5b                	jae    6de5 <fwp_rc_free_obj+0x75>
    6d8a:	48 89 c2             	mov    %rax,%rdx
    6d8d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d91:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d95:	48 8b 15 7c 3e 06 00 	mov    0x63e7c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6d9c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6da0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6da4:	48 85 c9             	test   %rcx,%rcx
    6da7:	74 3c                	je     6de5 <fwp_rc_free_obj+0x75>
    6da9:	0f b6 32             	movzbl (%rdx),%esi
    6dac:	40 80 fe 02          	cmp    $0x2,%sil
    6db0:	74 2e                	je     6de0 <fwp_rc_free_obj+0x70>
    6db2:	40 80 fe 01          	cmp    $0x1,%sil
    6db6:	75 2d                	jne    6de5 <fwp_rc_free_obj+0x75>
    6db8:	8b 72 18             	mov    0x18(%rdx),%esi
    6dbb:	0f b7 c0             	movzwl %ax,%eax
    6dbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6dc1:	48 0f af c6          	imul   %rsi,%rax
    6dc5:	48 c1 e8 20          	shr    $0x20,%rax
    6dc9:	48 39 d0             	cmp    %rdx,%rax
    6dcc:	73 17                	jae    6de5 <fwp_rc_free_obj+0x75>
    6dce:	48 01 c1             	add    %rax,%rcx
    6dd1:	80 39 01             	cmpb   $0x1,(%rcx)
    6dd4:	75 0f                	jne    6de5 <fwp_rc_free_obj+0x75>
    6dd6:	e9 35 ec ff ff       	jmp    5a10 <fwp_mem_free>
    6ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6de0:	66 85 c0             	test   %ax,%ax
    6de3:	74 ec                	je     6dd1 <fwp_rc_free_obj+0x61>
    6de5:	c3                   	ret
    6de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ded:	00 00 00 

0000000000006df0 <fwp_rc_dup>:
    6df0:	f3 0f 1e fa          	endbr64
    6df4:	48 8b 05 fd 3d 06 00 	mov    0x63dfd(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    6dfb:	48 2b 3d ce 3d 06 00 	sub    0x63dce(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    6e02:	48 c1 e0 10          	shl    $0x10,%rax
    6e06:	48 39 c7             	cmp    %rax,%rdi
    6e09:	73 60                	jae    6e6b <fwp_rc_dup+0x7b>
    6e0b:	48 89 f8             	mov    %rdi,%rax
    6e0e:	48 c1 e8 10          	shr    $0x10,%rax
    6e12:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6e16:	48 8b 05 fb 3d 06 00 	mov    0x63dfb(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    6e1d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6e21:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6e25:	48 85 c0             	test   %rax,%rax
    6e28:	74 41                	je     6e6b <fwp_rc_dup+0x7b>
    6e2a:	0f b6 0a             	movzbl (%rdx),%ecx
    6e2d:	80 f9 02             	cmp    $0x2,%cl
    6e30:	74 3e                	je     6e70 <fwp_rc_dup+0x80>
    6e32:	80 f9 01             	cmp    $0x1,%cl
    6e35:	75 34                	jne    6e6b <fwp_rc_dup+0x7b>
    6e37:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6e3a:	0f b7 ff             	movzwl %di,%edi
    6e3d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e40:	48 0f af f9          	imul   %rcx,%rdi
    6e44:	48 c1 ef 20          	shr    $0x20,%rdi
    6e48:	48 39 d7             	cmp    %rdx,%rdi
    6e4b:	73 1e                	jae    6e6b <fwp_rc_dup+0x7b>
    6e4d:	48 01 f8             	add    %rdi,%rax
    6e50:	0f b6 10             	movzbl (%rax),%edx
    6e53:	84 d2                	test   %dl,%dl
    6e55:	74 14                	je     6e6b <fwp_rc_dup+0x7b>
    6e57:	8b 0d 8b 46 06 00    	mov    0x6468b(%rip),%ecx        # 6b4e8 <iteration_active>
    6e5d:	85 c9                	test   %ecx,%ecx
    6e5f:	75 1f                	jne    6e80 <fwp_rc_dup+0x90>
    6e61:	80 fa fd             	cmp    $0xfd,%dl
    6e64:	77 2a                	ja     6e90 <fwp_rc_dup+0xa0>
    6e66:	83 c2 01             	add    $0x1,%edx
    6e69:	88 10                	mov    %dl,(%rax)
    6e6b:	c3                   	ret
    6e6c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e70:	66 85 ff             	test   %di,%di
    6e73:	74 db                	je     6e50 <fwp_rc_dup+0x60>
    6e75:	c3                   	ret
    6e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e7d:	00 00 00 
    6e80:	48 83 05 48 46 06 00 	addq   $0x1,0x64648(%rip)        # 6b4d0 <iteration_retains>
    6e87:	01 
    6e88:	eb d7                	jmp    6e61 <fwp_rc_dup+0x71>
    6e8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e90:	48 89 c7             	mov    %rax,%rdi
    6e93:	e9 18 e8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    6e98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e9f:	00 

0000000000006ea0 <fwp_owned_entry173>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	48 83 ec 38          	sub    $0x38,%rsp
    6ea8:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6ead:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6eb4:	00 00 
    6eb6:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6ebb:	31 c0                	xor    %eax,%eax
    6ebd:	48 8b 07             	mov    (%rdi),%rax
    6ec0:	48 03 47 10          	add    0x10(%rdi),%rax
    6ec4:	0f 80 c2 00 00 00    	jo     6f8c <fwp_owned_entry173+0xec>
    6eca:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6ecf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6ed4:	31 ff                	xor    %edi,%edi
    6ed6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6eda:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6edf:	e8 1c f2 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6ee4:	48 8b 15 0d 3d 06 00 	mov    0x63d0d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6eeb:	48 89 c6             	mov    %rax,%rsi
    6eee:	48 2b 05 db 3c 06 00 	sub    0x63cdb(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6ef5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ef9:	48 39 d0             	cmp    %rdx,%rax
    6efc:	73 4f                	jae    6f4d <fwp_owned_entry173+0xad>
    6efe:	48 89 c2             	mov    %rax,%rdx
    6f01:	48 c1 ea 10          	shr    $0x10,%rdx
    6f05:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f09:	48 8b 15 08 3d 06 00 	mov    0x63d08(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    6f10:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6f14:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6f18:	48 85 d2             	test   %rdx,%rdx
    6f1b:	74 30                	je     6f4d <fwp_owned_entry173+0xad>
    6f1d:	0f b6 39             	movzbl (%rcx),%edi
    6f20:	40 80 ff 02          	cmp    $0x2,%dil
    6f24:	74 42                	je     6f68 <fwp_owned_entry173+0xc8>
    6f26:	40 80 ff 01          	cmp    $0x1,%dil
    6f2a:	75 21                	jne    6f4d <fwp_owned_entry173+0xad>
    6f2c:	8b 79 18             	mov    0x18(%rcx),%edi
    6f2f:	0f b7 c0             	movzwl %ax,%eax
    6f32:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f35:	48 0f af c7          	imul   %rdi,%rax
    6f39:	48 c1 e8 20          	shr    $0x20,%rax
    6f3d:	48 39 c8             	cmp    %rcx,%rax
    6f40:	73 0b                	jae    6f4d <fwp_owned_entry173+0xad>
    6f42:	48 01 c2             	add    %rax,%rdx
    6f45:	80 3a ff             	cmpb   $0xff,(%rdx)
    6f48:	74 26                	je     6f70 <fwp_owned_entry173+0xd0>
    6f4a:	c6 02 01             	movb   $0x1,(%rdx)
    6f4d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6f52:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f59:	00 00 
    6f5b:	75 34                	jne    6f91 <fwp_owned_entry173+0xf1>
    6f5d:	48 89 f0             	mov    %rsi,%rax
    6f60:	48 83 c4 38          	add    $0x38,%rsp
    6f64:	c3                   	ret
    6f65:	0f 1f 00             	nopl   (%rax)
    6f68:	66 85 c0             	test   %ax,%ax
    6f6b:	75 e0                	jne    6f4d <fwp_owned_entry173+0xad>
    6f6d:	eb d6                	jmp    6f45 <fwp_owned_entry173+0xa5>
    6f6f:	90                   	nop
    6f70:	48 89 d7             	mov    %rdx,%rdi
    6f73:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6f78:	48 89 14 24          	mov    %rdx,(%rsp)
    6f7c:	e8 4f e8 ff ff       	call   57d0 <fwp_rc_forget_slot>
    6f81:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6f86:	48 8b 14 24          	mov    (%rsp),%rdx
    6f8a:	eb be                	jmp    6f4a <fwp_owned_entry173+0xaa>
    6f8c:	e8 6f c7 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6f91:	e8 ba c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f9d:	00 00 00 

0000000000006fa0 <e173>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	53                   	push   %rbx
    6fa5:	48 83 ec 30          	sub    $0x30,%rsp
    6fa9:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6fae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6fb5:	00 00 
    6fb7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6fbc:	31 c0                	xor    %eax,%eax
    6fbe:	48 8b 07             	mov    (%rdi),%rax
    6fc1:	48 03 47 10          	add    0x10(%rdi),%rax
    6fc5:	0f 80 c9 00 00 00    	jo     7094 <e173+0xf4>
    6fcb:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6fd0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6fd5:	31 ff                	xor    %edi,%edi
    6fd7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6fdb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6fe0:	e8 1b f1 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    6fe5:	48 8b 15 0c 3c 06 00 	mov    0x63c0c(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    6fec:	48 89 c3             	mov    %rax,%rbx
    6fef:	48 2b 05 da 3b 06 00 	sub    0x63bda(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    6ff6:	48 c1 e2 10          	shl    $0x10,%rdx
    6ffa:	48 39 d0             	cmp    %rdx,%rax
    6ffd:	73 4f                	jae    704e <e173+0xae>
    6fff:	48 89 c2             	mov    %rax,%rdx
    7002:	48 c1 ea 10          	shr    $0x10,%rdx
    7006:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    700a:	48 8b 15 07 3c 06 00 	mov    0x63c07(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7011:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    7015:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7019:	48 85 d2             	test   %rdx,%rdx
    701c:	74 30                	je     704e <e173+0xae>
    701e:	0f b6 31             	movzbl (%rcx),%esi
    7021:	40 80 fe 02          	cmp    $0x2,%sil
    7025:	74 49                	je     7070 <e173+0xd0>
    7027:	40 80 fe 01          	cmp    $0x1,%sil
    702b:	75 21                	jne    704e <e173+0xae>
    702d:	8b 71 18             	mov    0x18(%rcx),%esi
    7030:	0f b7 c0             	movzwl %ax,%eax
    7033:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7036:	48 0f af c6          	imul   %rsi,%rax
    703a:	48 c1 e8 20          	shr    $0x20,%rax
    703e:	48 39 c8             	cmp    %rcx,%rax
    7041:	73 0b                	jae    704e <e173+0xae>
    7043:	48 01 c2             	add    %rax,%rdx
    7046:	80 3a ff             	cmpb   $0xff,(%rdx)
    7049:	74 35                	je     7080 <e173+0xe0>
    704b:	c6 02 01             	movb   $0x1,(%rdx)
    704e:	48 89 df             	mov    %rbx,%rdi
    7051:	e8 9a fc ff ff       	call   6cf0 <fwp_rc_share>
    7056:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    705b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7062:	00 00 
    7064:	75 33                	jne    7099 <e173+0xf9>
    7066:	48 83 c4 30          	add    $0x30,%rsp
    706a:	48 89 d8             	mov    %rbx,%rax
    706d:	5b                   	pop    %rbx
    706e:	c3                   	ret
    706f:	90                   	nop
    7070:	66 85 c0             	test   %ax,%ax
    7073:	75 d9                	jne    704e <e173+0xae>
    7075:	eb cf                	jmp    7046 <e173+0xa6>
    7077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    707e:	00 00 
    7080:	48 89 d7             	mov    %rdx,%rdi
    7083:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7088:	e8 43 e7 ff ff       	call   57d0 <fwp_rc_forget_slot>
    708d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7092:	eb b7                	jmp    704b <e173+0xab>
    7094:	e8 67 c6 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7099:	e8 b2 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    709e:	66 90                	xchg   %ax,%ax

00000000000070a0 <fwp_closure_drop>:
    70a0:	48 8b 15 51 3b 06 00 	mov    0x63b51(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    70a7:	48 89 f8             	mov    %rdi,%rax
    70aa:	48 2b 05 1f 3b 06 00 	sub    0x63b1f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    70b1:	48 c1 e2 10          	shl    $0x10,%rdx
    70b5:	48 39 d0             	cmp    %rdx,%rax
    70b8:	73 6b                	jae    7125 <fwp_closure_drop+0x85>
    70ba:	48 89 c2             	mov    %rax,%rdx
    70bd:	48 c1 ea 10          	shr    $0x10,%rdx
    70c1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70c5:	48 8b 15 4c 3b 06 00 	mov    0x63b4c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    70cc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    70d0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    70d4:	48 85 d2             	test   %rdx,%rdx
    70d7:	74 4c                	je     7125 <fwp_closure_drop+0x85>
    70d9:	0f b6 31             	movzbl (%rcx),%esi
    70dc:	40 80 fe 02          	cmp    $0x2,%sil
    70e0:	74 3e                	je     7120 <fwp_closure_drop+0x80>
    70e2:	40 80 fe 01          	cmp    $0x1,%sil
    70e6:	75 3d                	jne    7125 <fwp_closure_drop+0x85>
    70e8:	8b 71 18             	mov    0x18(%rcx),%esi
    70eb:	0f b7 c0             	movzwl %ax,%eax
    70ee:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70f1:	48 0f af c6          	imul   %rsi,%rax
    70f5:	48 c1 e8 20          	shr    $0x20,%rax
    70f9:	48 39 c8             	cmp    %rcx,%rax
    70fc:	73 27                	jae    7125 <fwp_closure_drop+0x85>
    70fe:	48 01 c2             	add    %rax,%rdx
    7101:	0f b6 02             	movzbl (%rdx),%eax
    7104:	84 c0                	test   %al,%al
    7106:	74 1d                	je     7125 <fwp_closure_drop+0x85>
    7108:	3c 01                	cmp    $0x1,%al
    710a:	74 24                	je     7130 <fwp_closure_drop+0x90>
    710c:	3c ff                	cmp    $0xff,%al
    710e:	74 48                	je     7158 <fwp_closure_drop+0xb8>
    7110:	83 e8 01             	sub    $0x1,%eax
    7113:	88 02                	mov    %al,(%rdx)
    7115:	c3                   	ret
    7116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    711d:	00 00 00 
    7120:	66 85 c0             	test   %ax,%ax
    7123:	74 dc                	je     7101 <fwp_closure_drop+0x61>
    7125:	c3                   	ret
    7126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    712d:	00 00 00 
    7130:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7137:	ff ff 
    7139:	48 85 c0             	test   %rax,%rax
    713c:	74 12                	je     7150 <fwp_closure_drop+0xb0>
    713e:	48 89 fe             	mov    %rdi,%rsi
    7141:	48 89 c7             	mov    %rax,%rdi
    7144:	e9 67 d3 ff ff       	jmp    44b0 <fwp_closure_drop_push>
    7149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7150:	e9 0b d5 ff ff       	jmp    4660 <fwp_closure_drop.part.0>
    7155:	0f 1f 00             	nopl   (%rax)
    7158:	48 89 d0             	mov    %rdx,%rax
    715b:	48 8d 35 be 26 06 00 	lea    0x626be(%rip),%rsi        # 69820 <fwp_heap>
    7162:	48 83 ec 18          	sub    $0x18,%rsp
    7166:	48 c1 e8 11          	shr    $0x11,%rax
    716a:	48 31 d0             	xor    %rdx,%rax
    716d:	48 89 c1             	mov    %rax,%rcx
    7170:	48 c1 e9 09          	shr    $0x9,%rcx
    7174:	48 31 c8             	xor    %rcx,%rax
    7177:	0f b6 c8             	movzbl %al,%ecx
    717a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7181:	00 
    7182:	48 85 c0             	test   %rax,%rax
    7185:	75 22                	jne    71a9 <fwp_closure_drop+0x109>
    7187:	eb 59                	jmp    71e2 <fwp_closure_drop+0x142>
    7189:	90                   	nop
    718a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7191:	00 00 00 00 
    7195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    719c:	00 00 00 00 
    71a0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    71a4:	48 85 c0             	test   %rax,%rax
    71a7:	74 39                	je     71e2 <fwp_closure_drop+0x142>
    71a9:	48 89 c1             	mov    %rax,%rcx
    71ac:	48 39 10             	cmp    %rdx,(%rax)
    71af:	75 ef                	jne    71a0 <fwp_closure_drop+0x100>
    71b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    71b5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    71b9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    71bd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71c4:	74 05                	je     71cb <fwp_closure_drop+0x12b>
    71c6:	48 83 c4 18          	add    $0x18,%rsp
    71ca:	c3                   	ret
    71cb:	48 89 d7             	mov    %rdx,%rdi
    71ce:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71d3:	e8 f8 e5 ff ff       	call   57d0 <fwp_rc_forget_slot>
    71d8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71dd:	c6 02 fe             	movb   $0xfe,(%rdx)
    71e0:	eb e4                	jmp    71c6 <fwp_closure_drop+0x126>
    71e2:	48 8d 3d 07 68 00 00 	lea    0x6807(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    71e9:	e8 62 d2 ff ff       	call   4450 <fwp_trap>
    71ee:	66 90                	xchg   %ax,%ax

00000000000071f0 <fwp_owned_tape_release>:
    71f0:	48 85 ff             	test   %rdi,%rdi
    71f3:	0f 84 f7 00 00 00    	je     72f0 <fwp_owned_tape_release+0x100>
    71f9:	41 54                	push   %r12
    71fb:	55                   	push   %rbp
    71fc:	53                   	push   %rbx
    71fd:	48 8b 07             	mov    (%rdi),%rax
    7200:	48 85 c0             	test   %rax,%rax
    7203:	74 08                	je     720d <fwp_owned_tape_release+0x1d>
    7205:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7209:	48 89 50 08          	mov    %rdx,0x8(%rax)
    720d:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    7211:	48 85 d2             	test   %rdx,%rdx
    7214:	74 03                	je     7219 <fwp_owned_tape_release+0x29>
    7216:	48 89 02             	mov    %rax,(%rdx)
    7219:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    721d:	48 89 fb             	mov    %rdi,%rbx
    7220:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7224:	48 85 c0             	test   %rax,%rax
    7227:	0f 84 89 00 00 00    	je     72b6 <fwp_owned_tape_release+0xc6>
    722d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7231:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7235:	7e 47                	jle    727e <fwp_owned_tape_release+0x8e>
    7237:	31 ed                	xor    %ebp,%ebp
    7239:	eb 0d                	jmp    7248 <fwp_owned_tape_release+0x58>
    723b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7240:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7244:	48 8b 40 68          	mov    0x68(%rax),%rax
    7248:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    724c:	49 89 ec             	mov    %rbp,%r12
    724f:	48 83 c5 01          	add    $0x1,%rbp
    7253:	49 c1 e4 04          	shl    $0x4,%r12
    7257:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    725b:	ff d0                	call   *%rax
    725d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7261:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7266:	48 8b 43 10          	mov    0x10(%rbx),%rax
    726a:	ff 50 68             	call   *0x68(%rax)
    726d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7271:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7275:	48 39 e8             	cmp    %rbp,%rax
    7278:	7f c6                	jg     7240 <fwp_owned_tape_release+0x50>
    727a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    727e:	31 ed                	xor    %ebp,%ebp
    7280:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7285:	7e 28                	jle    72af <fwp_owned_tape_release+0xbf>
    7287:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    728e:	00 00 
    7290:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7294:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7298:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    729c:	74 07                	je     72a5 <fwp_owned_tape_release+0xb5>
    729e:	ff 52 68             	call   *0x68(%rdx)
    72a1:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    72a5:	48 83 c5 01          	add    $0x1,%rbp
    72a9:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    72ad:	7f e1                	jg     7290 <fwp_owned_tape_release+0xa0>
    72af:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    72b3:	ff 52 68             	call   *0x68(%rdx)
    72b6:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    72ba:	e8 e1 fd ff ff       	call   70a0 <fwp_closure_drop>
    72bf:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    72c3:	e8 d8 fd ff ff       	call   70a0 <fwp_closure_drop>
    72c8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    72cc:	e8 cf fd ff ff       	call   70a0 <fwp_closure_drop>
    72d1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    72d5:	e8 36 e7 ff ff       	call   5a10 <fwp_mem_free>
    72da:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    72de:	e8 2d e7 ff ff       	call   5a10 <fwp_mem_free>
    72e3:	48 89 df             	mov    %rbx,%rdi
    72e6:	5b                   	pop    %rbx
    72e7:	5d                   	pop    %rbp
    72e8:	41 5c                	pop    %r12
    72ea:	e9 21 e7 ff ff       	jmp    5a10 <fwp_mem_free>
    72ef:	90                   	nop
    72f0:	c3                   	ret
    72f1:	0f 1f 40 00          	nopl   0x0(%rax)
    72f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72fc:	00 00 00 00 

0000000000007300 <fwp_tape_finish>:
    7300:	f3 0f 1e fa          	endbr64
    7304:	41 55                	push   %r13
    7306:	41 54                	push   %r12
    7308:	55                   	push   %rbp
    7309:	53                   	push   %rbx
    730a:	48 83 ec 48          	sub    $0x48,%rsp
    730e:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    7315:	00 00 
    7317:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    731c:	48 8d 3d 7d 9d 01 00 	lea    0x19d7d(%rip),%rdi        # 210a0 <fwp_tape_workspace>
    7323:	e8 18 de ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7328:	48 83 3d b8 9d 01 00 	cmpq   $0x0,0x19db8(%rip)        # 210e8 <fwp_ntapes>
    732f:	00 
    7330:	48 c7 05 4d 9d 01 00 	movq   $0x0,0x19d4d(%rip)        # 21088 <fwp_tape_cached_bytes>
    7337:	00 00 00 00 
    733b:	7e 79                	jle    73b6 <fwp_tape_finish+0xb6>
    733d:	45 31 e4             	xor    %r12d,%r12d
    7340:	31 ed                	xor    %ebp,%ebp
    7342:	0f 1f 00             	nopl   (%rax)
    7345:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    734c:	00 00 00 00 
    7350:	48 8b 1d 99 9d 01 00 	mov    0x19d99(%rip),%rbx        # 210f0 <fwp_tapes>
    7357:	48 83 c5 01          	add    $0x1,%rbp
    735b:	4c 01 e3             	add    %r12,%rbx
    735e:	49 83 c4 68          	add    $0x68,%r12
    7362:	48 89 df             	mov    %rbx,%rdi
    7365:	e8 26 c9 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    736a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    736f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7374:	48 89 e7             	mov    %rsp,%rdi
    7377:	48 8b 43 40          	mov    0x40(%rbx),%rax
    737b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    737f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7384:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7389:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    738e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7392:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7397:	e8 a4 dd ff ff       	call   5140 <fwp_tape_buffers_dispose>
    739c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    73a0:	e8 4b fe ff ff       	call   71f0 <fwp_owned_tape_release>
    73a5:	48 39 2d 3c 9d 01 00 	cmp    %rbp,0x19d3c(%rip)        # 210e8 <fwp_ntapes>
    73ac:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    73b3:	00 
    73b4:	7f 9a                	jg     7350 <fwp_tape_finish+0x50>
    73b6:	48 8b 3d 33 9d 01 00 	mov    0x19d33(%rip),%rdi        # 210f0 <fwp_tapes>
    73bd:	48 85 ff             	test   %rdi,%rdi
    73c0:	74 05                	je     73c7 <fwp_tape_finish+0xc7>
    73c2:	e8 09 dd ff ff       	call   50d0 <ad_raw_free.part.0>
    73c7:	48 c7 05 1e 9d 01 00 	movq   $0x0,0x19d1e(%rip)        # 210f0 <fwp_tapes>
    73ce:	00 00 00 00 
    73d2:	48 c7 05 03 9d 01 00 	movq   $0x0,0x19d03(%rip)        # 210e0 <fwp_tapes_cap>
    73d9:	00 00 00 00 
    73dd:	48 c7 05 00 9d 01 00 	movq   $0x0,0x19d00(%rip)        # 210e8 <fwp_ntapes>
    73e4:	00 00 00 00 
    73e8:	48 c7 05 e5 9c 01 00 	movq   $0x0,0x19ce5(%rip)        # 210d8 <fwp_tape_next_slot>
    73ef:	00 00 00 00 
    73f3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    73f8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    73ff:	00 00 
    7401:	75 0b                	jne    740e <fwp_tape_finish+0x10e>
    7403:	48 83 c4 48          	add    $0x48,%rsp
    7407:	5b                   	pop    %rbx
    7408:	5d                   	pop    %rbp
    7409:	41 5c                	pop    %r12
    740b:	41 5d                	pop    %r13
    740d:	c3                   	ret
    740e:	e8 3d c0 ff ff       	call   3450 <__stack_chk_fail@plt>
    7413:	66 90                	xchg   %ax,%ax
    7415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    741c:	00 00 00 00 

0000000000007420 <fwp_tape_scope_release>:
    7420:	f3 0f 1e fa          	endbr64
    7424:	41 55                	push   %r13
    7426:	41 54                	push   %r12
    7428:	55                   	push   %rbp
    7429:	53                   	push   %rbx
    742a:	48 83 ec 48          	sub    $0x48,%rsp
    742e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7435:	00 00 
    7437:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    743c:	48 63 07             	movslq (%rdi),%rax
    743f:	85 c0                	test   %eax,%eax
    7441:	0f 88 e8 00 00 00    	js     752f <fwp_tape_scope_release+0x10f>
    7447:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    744e:	ec c4 4e 
    7451:	48 89 fb             	mov    %rdi,%rbx
    7454:	48 89 e5             	mov    %rsp,%rbp
    7457:	eb 1f                	jmp    7478 <fwp_tape_scope_release+0x58>
    7459:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7460:	e8 db dc ff ff       	call   5140 <fwp_tape_buffers_dispose>
    7465:	4c 89 ef             	mov    %r13,%rdi
    7468:	e8 83 fd ff ff       	call   71f0 <fwp_owned_tape_release>
    746d:	48 63 03             	movslq (%rbx),%rax
    7470:	85 c0                	test   %eax,%eax
    7472:	0f 88 b7 00 00 00    	js     752f <fwp_tape_scope_release+0x10f>
    7478:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    747c:	48 8b 35 6d 9c 01 00 	mov    0x19c6d(%rip),%rsi        # 210f0 <fwp_tapes>
    7483:	4c 01 c6             	add    %r8,%rsi
    7486:	48 89 f7             	mov    %rsi,%rdi
    7489:	e8 02 c8 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    748e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7493:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7498:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    749f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    74a3:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    74a7:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    74ae:	00 
    74af:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    74b4:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    74b9:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    74bd:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74c2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74c6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74cb:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    74d2:	00 
    74d3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    74da:	00 
    74db:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    74e2:	00 
    74e3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    74e7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    74eb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    74ef:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    74f3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    74f9:	77 18                	ja     7513 <fwp_tape_scope_release+0xf3>
    74fb:	49 c1 f8 03          	sar    $0x3,%r8
    74ff:	4d 0f af c4          	imul   %r12,%r8
    7503:	4c 3b 05 ce 9b 01 00 	cmp    0x19bce(%rip),%r8        # 210d8 <fwp_tape_next_slot>
    750a:	7d 07                	jge    7513 <fwp_tape_scope_release+0xf3>
    750c:	4c 89 05 c5 9b 01 00 	mov    %r8,0x19bc5(%rip)        # 210d8 <fwp_tape_next_slot>
    7513:	48 89 ef             	mov    %rbp,%rdi
    7516:	4d 85 ed             	test   %r13,%r13
    7519:	0f 85 41 ff ff ff    	jne    7460 <fwp_tape_scope_release+0x40>
    751f:	e8 3c dd ff ff       	call   5260 <fwp_tape_buffers_release>
    7524:	48 63 03             	movslq (%rbx),%rax
    7527:	85 c0                	test   %eax,%eax
    7529:	0f 89 49 ff ff ff    	jns    7478 <fwp_tape_scope_release+0x58>
    752f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7534:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    753b:	00 00 
    753d:	75 0b                	jne    754a <fwp_tape_scope_release+0x12a>
    753f:	48 83 c4 48          	add    $0x48,%rsp
    7543:	5b                   	pop    %rbx
    7544:	5d                   	pop    %rbp
    7545:	41 5c                	pop    %r12
    7547:	41 5d                	pop    %r13
    7549:	c3                   	ret
    754a:	e8 01 bf ff ff       	call   3450 <__stack_chk_fail@plt>
    754f:	90                   	nop

0000000000007550 <fwp_drop4>:
    7550:	48 8b 0d a1 36 06 00 	mov    0x636a1(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    7557:	48 89 f8             	mov    %rdi,%rax
    755a:	48 2b 05 6f 36 06 00 	sub    0x6366f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7561:	48 c1 e1 10          	shl    $0x10,%rcx
    7565:	48 39 c8             	cmp    %rcx,%rax
    7568:	0f 83 42 01 00 00    	jae    76b0 <fwp_drop4+0x160>
    756e:	48 83 ec 18          	sub    $0x18,%rsp
    7572:	48 89 fa             	mov    %rdi,%rdx
    7575:	4c 8d 05 a4 22 06 00 	lea    0x622a4(%rip),%r8        # 69820 <fwp_heap>
    757c:	48 89 c1             	mov    %rax,%rcx
    757f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7586:	48 c1 e9 10          	shr    $0x10,%rcx
    758a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    758e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7592:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7596:	48 85 c9             	test   %rcx,%rcx
    7599:	74 40                	je     75db <fwp_drop4+0x8b>
    759b:	0f b6 3e             	movzbl (%rsi),%edi
    759e:	40 80 ff 02          	cmp    $0x2,%dil
    75a2:	74 3c                	je     75e0 <fwp_drop4+0x90>
    75a4:	40 80 ff 01          	cmp    $0x1,%dil
    75a8:	75 31                	jne    75db <fwp_drop4+0x8b>
    75aa:	8b 7e 18             	mov    0x18(%rsi),%edi
    75ad:	0f b7 c0             	movzwl %ax,%eax
    75b0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    75b3:	48 0f af c7          	imul   %rdi,%rax
    75b7:	48 c1 e8 20          	shr    $0x20,%rax
    75bb:	48 39 f0             	cmp    %rsi,%rax
    75be:	73 1b                	jae    75db <fwp_drop4+0x8b>
    75c0:	48 01 c1             	add    %rax,%rcx
    75c3:	0f b6 01             	movzbl (%rcx),%eax
    75c6:	84 c0                	test   %al,%al
    75c8:	74 11                	je     75db <fwp_drop4+0x8b>
    75ca:	3c 01                	cmp    $0x1,%al
    75cc:	74 22                	je     75f0 <fwp_drop4+0xa0>
    75ce:	3c ff                	cmp    $0xff,%al
    75d0:	0f 84 0a 01 00 00    	je     76e0 <fwp_drop4+0x190>
    75d6:	83 e8 01             	sub    $0x1,%eax
    75d9:	88 01                	mov    %al,(%rcx)
    75db:	48 83 c4 18          	add    $0x18,%rsp
    75df:	c3                   	ret
    75e0:	66 85 c0             	test   %ax,%ax
    75e3:	74 de                	je     75c3 <fwp_drop4+0x73>
    75e5:	48 83 c4 18          	add    $0x18,%rsp
    75e9:	c3                   	ret
    75ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75f0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    75f4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    75fb:	48 89 f8             	mov    %rdi,%rax
    75fe:	48 c1 e1 10          	shl    $0x10,%rcx
    7602:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7609:	48 39 c8             	cmp    %rcx,%rax
    760c:	73 62                	jae    7670 <fwp_drop4+0x120>
    760e:	48 89 c1             	mov    %rax,%rcx
    7611:	48 c1 e9 10          	shr    $0x10,%rcx
    7615:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7619:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    761d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7621:	48 85 c9             	test   %rcx,%rcx
    7624:	74 4a                	je     7670 <fwp_drop4+0x120>
    7626:	44 0f b6 0e          	movzbl (%rsi),%r9d
    762a:	41 80 f9 02          	cmp    $0x2,%r9b
    762e:	0f 84 9c 00 00 00    	je     76d0 <fwp_drop4+0x180>
    7634:	41 80 f9 01          	cmp    $0x1,%r9b
    7638:	75 36                	jne    7670 <fwp_drop4+0x120>
    763a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    763e:	0f b7 c0             	movzwl %ax,%eax
    7641:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7644:	49 0f af c1          	imul   %r9,%rax
    7648:	48 c1 e8 20          	shr    $0x20,%rax
    764c:	48 39 f0             	cmp    %rsi,%rax
    764f:	73 1f                	jae    7670 <fwp_drop4+0x120>
    7651:	48 01 c1             	add    %rax,%rcx
    7654:	0f b6 01             	movzbl (%rcx),%eax
    7657:	84 c0                	test   %al,%al
    7659:	74 15                	je     7670 <fwp_drop4+0x120>
    765b:	3c 01                	cmp    $0x1,%al
    765d:	74 59                	je     76b8 <fwp_drop4+0x168>
    765f:	3c ff                	cmp    $0xff,%al
    7661:	0f 84 ff 00 00 00    	je     7766 <fwp_drop4+0x216>
    7667:	83 e8 01             	sub    $0x1,%eax
    766a:	88 01                	mov    %al,(%rcx)
    766c:	0f 1f 40 00          	nopl   0x0(%rax)
    7670:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7674:	48 89 d7             	mov    %rdx,%rdi
    7677:	48 89 0c 24          	mov    %rcx,(%rsp)
    767b:	e8 f0 f6 ff ff       	call   6d70 <fwp_rc_free_obj>
    7680:	4c 8d 05 99 21 06 00 	lea    0x62199(%rip),%r8        # 69820 <fwp_heap>
    7687:	48 8b 04 24          	mov    (%rsp),%rax
    768b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7692:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7699:	48 c1 e2 10          	shl    $0x10,%rdx
    769d:	48 39 d0             	cmp    %rdx,%rax
    76a0:	0f 83 35 ff ff ff    	jae    75db <fwp_drop4+0x8b>
    76a6:	48 8b 14 24          	mov    (%rsp),%rdx
    76aa:	e9 cd fe ff ff       	jmp    757c <fwp_drop4+0x2c>
    76af:	90                   	nop
    76b0:	c3                   	ret
    76b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    76b8:	48 89 14 24          	mov    %rdx,(%rsp)
    76bc:	e8 af f6 ff ff       	call   6d70 <fwp_rc_free_obj>
    76c1:	48 8b 14 24          	mov    (%rsp),%rdx
    76c5:	eb a9                	jmp    7670 <fwp_drop4+0x120>
    76c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76ce:	00 00 
    76d0:	66 85 c0             	test   %ax,%ax
    76d3:	75 9b                	jne    7670 <fwp_drop4+0x120>
    76d5:	e9 7a ff ff ff       	jmp    7654 <fwp_drop4+0x104>
    76da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76e0:	48 89 c8             	mov    %rcx,%rax
    76e3:	48 c1 e8 11          	shr    $0x11,%rax
    76e7:	48 31 c8             	xor    %rcx,%rax
    76ea:	48 89 c2             	mov    %rax,%rdx
    76ed:	48 c1 ea 09          	shr    $0x9,%rdx
    76f1:	48 31 d0             	xor    %rdx,%rax
    76f4:	0f b6 d0             	movzbl %al,%edx
    76f7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    76fe:	00 
    76ff:	48 85 c0             	test   %rax,%rax
    7702:	75 29                	jne    772d <fwp_drop4+0x1dd>
    7704:	e9 e3 00 00 00       	jmp    77ec <fwp_drop4+0x29c>
    7709:	90                   	nop
    770a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7711:	00 00 00 00 
    7715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    771c:	00 00 00 00 
    7720:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7724:	48 85 c0             	test   %rax,%rax
    7727:	0f 84 bf 00 00 00    	je     77ec <fwp_drop4+0x29c>
    772d:	48 89 c2             	mov    %rax,%rdx
    7730:	48 39 08             	cmp    %rcx,(%rax)
    7733:	75 eb                	jne    7720 <fwp_drop4+0x1d0>
    7735:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7739:	48 83 ea 01          	sub    $0x1,%rdx
    773d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7741:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7748:	0f 85 8d fe ff ff    	jne    75db <fwp_drop4+0x8b>
    774e:	48 89 cf             	mov    %rcx,%rdi
    7751:	48 89 0c 24          	mov    %rcx,(%rsp)
    7755:	e8 76 e0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    775a:	48 8b 0c 24          	mov    (%rsp),%rcx
    775e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7761:	e9 75 fe ff ff       	jmp    75db <fwp_drop4+0x8b>
    7766:	48 89 ce             	mov    %rcx,%rsi
    7769:	48 c1 ee 11          	shr    $0x11,%rsi
    776d:	48 31 ce             	xor    %rcx,%rsi
    7770:	48 89 f0             	mov    %rsi,%rax
    7773:	48 c1 e8 09          	shr    $0x9,%rax
    7777:	48 31 c6             	xor    %rax,%rsi
    777a:	40 0f b6 f6          	movzbl %sil,%esi
    777e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7785:	00 
    7786:	48 85 c0             	test   %rax,%rax
    7789:	75 1e                	jne    77a9 <fwp_drop4+0x259>
    778b:	eb 5f                	jmp    77ec <fwp_drop4+0x29c>
    778d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7794:	00 
    7795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    779c:	00 00 00 00 
    77a0:	48 8b 46 10          	mov    0x10(%rsi),%rax
    77a4:	48 85 c0             	test   %rax,%rax
    77a7:	74 43                	je     77ec <fwp_drop4+0x29c>
    77a9:	48 89 c6             	mov    %rax,%rsi
    77ac:	48 39 08             	cmp    %rcx,(%rax)
    77af:	75 ef                	jne    77a0 <fwp_drop4+0x250>
    77b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    77b5:	48 83 ee 01          	sub    $0x1,%rsi
    77b9:	48 89 70 08          	mov    %rsi,0x8(%rax)
    77bd:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    77c4:	0f 85 a6 fe ff ff    	jne    7670 <fwp_drop4+0x120>
    77ca:	48 89 cf             	mov    %rcx,%rdi
    77cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77d2:	48 89 0c 24          	mov    %rcx,(%rsp)
    77d6:	e8 f5 df ff ff       	call   57d0 <fwp_rc_forget_slot>
    77db:	48 8b 0c 24          	mov    (%rsp),%rcx
    77df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77e4:	c6 01 fe             	movb   $0xfe,(%rcx)
    77e7:	e9 84 fe ff ff       	jmp    7670 <fwp_drop4+0x120>
    77ec:	48 8d 3d fd 61 00 00 	lea    0x61fd(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    77f3:	e8 58 cc ff ff       	call   4450 <fwp_trap>
    77f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77ff:	00 

0000000000007800 <fwp_arg_drop37>:
    7800:	f3 0f 1e fa          	endbr64
    7804:	85 f6                	test   %esi,%esi
    7806:	75 04                	jne    780c <fwp_arg_drop37+0xc>
    7808:	85 d2                	test   %edx,%edx
    780a:	75 04                	jne    7810 <fwp_arg_drop37+0x10>
    780c:	c3                   	ret
    780d:	0f 1f 00             	nopl   (%rax)
    7810:	48 8b 3f             	mov    (%rdi),%rdi
    7813:	e9 38 fd ff ff       	jmp    7550 <fwp_drop4>
    7818:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    781f:	00 

0000000000007820 <fwp_task_dispose>:
    7820:	53                   	push   %rbx
    7821:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7825:	0f 84 1b bf ff ff    	je     3746 <fwp_task_dispose.cold>
    782b:	48 89 fb             	mov    %rdi,%rbx
    782e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7833:	0f 85 0d bf ff ff    	jne    3746 <fwp_task_dispose.cold>
    7839:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    783d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7844:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    784b:	00 
    784c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7850:	48 85 ff             	test   %rdi,%rdi
    7853:	74 07                	je     785c <fwp_task_dispose+0x3c>
    7855:	48 85 c0             	test   %rax,%rax
    7858:	74 02                	je     785c <fwp_task_dispose+0x3c>
    785a:	ff d0                	call   *%rax
    785c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7863:	e8 a8 e1 ff ff       	call   5a10 <fwp_mem_free>
    7868:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    786f:	00 00 00 00 
    7873:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7877:	74 6f                	je     78e8 <fwp_task_dispose+0xc8>
    7879:	48 8b 15 78 33 06 00 	mov    0x63378(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7880:	48 89 d8             	mov    %rbx,%rax
    7883:	48 2b 05 46 33 06 00 	sub    0x63346(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    788a:	48 c1 e2 10          	shl    $0x10,%rdx
    788e:	48 39 d0             	cmp    %rdx,%rax
    7891:	73 4c                	jae    78df <fwp_task_dispose+0xbf>
    7893:	48 89 c2             	mov    %rax,%rdx
    7896:	48 c1 ea 10          	shr    $0x10,%rdx
    789a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    789e:	48 8b 15 73 33 06 00 	mov    0x63373(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    78a5:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    78a9:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    78ad:	48 85 c9             	test   %rcx,%rcx
    78b0:	74 2d                	je     78df <fwp_task_dispose+0xbf>
    78b2:	0f b6 32             	movzbl (%rdx),%esi
    78b5:	40 80 fe 02          	cmp    $0x2,%sil
    78b9:	74 3d                	je     78f8 <fwp_task_dispose+0xd8>
    78bb:	40 80 fe 01          	cmp    $0x1,%sil
    78bf:	75 1e                	jne    78df <fwp_task_dispose+0xbf>
    78c1:	8b 72 18             	mov    0x18(%rdx),%esi
    78c4:	0f b7 c0             	movzwl %ax,%eax
    78c7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78ca:	48 0f af c6          	imul   %rsi,%rax
    78ce:	48 c1 e8 20          	shr    $0x20,%rax
    78d2:	48 39 d0             	cmp    %rdx,%rax
    78d5:	73 08                	jae    78df <fwp_task_dispose+0xbf>
    78d7:	48 01 c1             	add    %rax,%rcx
    78da:	80 39 01             	cmpb   $0x1,(%rcx)
    78dd:	74 09                	je     78e8 <fwp_task_dispose+0xc8>
    78df:	5b                   	pop    %rbx
    78e0:	c3                   	ret
    78e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78e8:	48 89 df             	mov    %rbx,%rdi
    78eb:	5b                   	pop    %rbx
    78ec:	e9 1f e1 ff ff       	jmp    5a10 <fwp_mem_free>
    78f1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78f8:	66 85 c0             	test   %ax,%ax
    78fb:	74 dd                	je     78da <fwp_task_dispose+0xba>
    78fd:	5b                   	pop    %rbx
    78fe:	c3                   	ret
    78ff:	90                   	nop

0000000000007900 <fwp_free_zombie>:
    7900:	48 8b 15 e9 1e 06 00 	mov    0x61ee9(%rip),%rdx        # 697f0 <fwp_zombie>
    7907:	48 85 d2             	test   %rdx,%rdx
    790a:	0f 84 98 00 00 00    	je     79a8 <fwp_free_zombie+0xa8>
    7910:	48 3b 15 e9 1e 06 00 	cmp    0x61ee9(%rip),%rdx        # 69800 <fwp_cur>
    7917:	0f 84 8b 00 00 00    	je     79a8 <fwp_free_zombie+0xa8>
    791d:	48 83 ec 18          	sub    $0x18,%rsp
    7921:	48 63 05 ac 18 06 00 	movslq 0x618ac(%rip),%rax        # 691d4 <fwp_stack_pool_n>
    7928:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    792c:	83 f8 3f             	cmp    $0x3f,%eax
    792f:	7f 7f                	jg     79b0 <fwp_free_zombie+0xb0>
    7931:	8d 48 01             	lea    0x1(%rax),%ecx
    7934:	89 0d 9a 18 06 00    	mov    %ecx,0x6189a(%rip)        # 691d4 <fwp_stack_pool_n>
    793a:	48 8d 0d 9f 18 06 00 	lea    0x6189f(%rip),%rcx        # 691e0 <fwp_stack_pool>
    7941:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7945:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    794c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7950:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7957:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    795b:	48 85 c9             	test   %rcx,%rcx
    795e:	0f 84 fc 00 00 00    	je     7a60 <fwp_free_zombie+0x160>
    7964:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    796b:	48 85 c0             	test   %rax,%rax
    796e:	74 07                	je     7977 <fwp_free_zombie+0x77>
    7970:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7977:	8b 42 5c             	mov    0x5c(%rdx),%eax
    797a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    797e:	48 c7 05 67 1e 06 00 	movq   $0x0,0x61e67(%rip)        # 697f0 <fwp_zombie>
    7985:	00 00 00 00 
    7989:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7990:	85 c0                	test   %eax,%eax
    7992:	74 34                	je     79c8 <fwp_free_zombie+0xc8>
    7994:	83 f8 01             	cmp    $0x1,%eax
    7997:	0f 84 b3 00 00 00    	je     7a50 <fwp_free_zombie+0x150>
    799d:	48 83 c4 18          	add    $0x18,%rsp
    79a1:	c3                   	ret
    79a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79a8:	c3                   	ret
    79a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    79b0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    79b4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79b9:	e8 02 bc ff ff       	call   35c0 <munmap@plt>
    79be:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79c3:	eb 80                	jmp    7945 <fwp_free_zombie+0x45>
    79c5:	0f 1f 00             	nopl   (%rax)
    79c8:	48 8b 0d 29 32 06 00 	mov    0x63229(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    79cf:	48 89 d0             	mov    %rdx,%rax
    79d2:	48 2b 05 f7 31 06 00 	sub    0x631f7(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    79d9:	48 c1 e1 10          	shl    $0x10,%rcx
    79dd:	48 39 c8             	cmp    %rcx,%rax
    79e0:	73 bb                	jae    799d <fwp_free_zombie+0x9d>
    79e2:	48 89 c1             	mov    %rax,%rcx
    79e5:	48 c1 e9 10          	shr    $0x10,%rcx
    79e9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79ed:	48 8b 0d 24 32 06 00 	mov    0x63224(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    79f4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    79f8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    79fc:	48 85 c9             	test   %rcx,%rcx
    79ff:	74 9c                	je     799d <fwp_free_zombie+0x9d>
    7a01:	0f b6 3e             	movzbl (%rsi),%edi
    7a04:	40 80 ff 02          	cmp    $0x2,%dil
    7a08:	74 66                	je     7a70 <fwp_free_zombie+0x170>
    7a0a:	40 80 ff 01          	cmp    $0x1,%dil
    7a0e:	75 8d                	jne    799d <fwp_free_zombie+0x9d>
    7a10:	8b 7e 18             	mov    0x18(%rsi),%edi
    7a13:	0f b7 c0             	movzwl %ax,%eax
    7a16:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7a19:	48 0f af c7          	imul   %rdi,%rax
    7a1d:	48 c1 e8 20          	shr    $0x20,%rax
    7a21:	48 39 f0             	cmp    %rsi,%rax
    7a24:	0f 83 73 ff ff ff    	jae    799d <fwp_free_zombie+0x9d>
    7a2a:	48 01 c1             	add    %rax,%rcx
    7a2d:	0f b6 01             	movzbl (%rcx),%eax
    7a30:	84 c0                	test   %al,%al
    7a32:	0f 84 65 ff ff ff    	je     799d <fwp_free_zombie+0x9d>
    7a38:	3c 01                	cmp    $0x1,%al
    7a3a:	74 14                	je     7a50 <fwp_free_zombie+0x150>
    7a3c:	3c ff                	cmp    $0xff,%al
    7a3e:	74 3b                	je     7a7b <fwp_free_zombie+0x17b>
    7a40:	83 e8 01             	sub    $0x1,%eax
    7a43:	88 01                	mov    %al,(%rcx)
    7a45:	e9 53 ff ff ff       	jmp    799d <fwp_free_zombie+0x9d>
    7a4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a50:	48 89 d7             	mov    %rdx,%rdi
    7a53:	48 83 c4 18          	add    $0x18,%rsp
    7a57:	e9 c4 fd ff ff       	jmp    7820 <fwp_task_dispose>
    7a5c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a60:	48 89 05 61 1d 06 00 	mov    %rax,0x61d61(%rip)        # 697c8 <fwp_tasks_active>
    7a67:	e9 ff fe ff ff       	jmp    796b <fwp_free_zombie+0x6b>
    7a6c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a70:	66 85 c0             	test   %ax,%ax
    7a73:	0f 85 24 ff ff ff    	jne    799d <fwp_free_zombie+0x9d>
    7a79:	eb b2                	jmp    7a2d <fwp_free_zombie+0x12d>
    7a7b:	48 89 ca             	mov    %rcx,%rdx
    7a7e:	48 8d 35 9b 1d 06 00 	lea    0x61d9b(%rip),%rsi        # 69820 <fwp_heap>
    7a85:	48 c1 ea 11          	shr    $0x11,%rdx
    7a89:	48 31 ca             	xor    %rcx,%rdx
    7a8c:	48 89 d0             	mov    %rdx,%rax
    7a8f:	48 c1 e8 09          	shr    $0x9,%rax
    7a93:	48 31 c2             	xor    %rax,%rdx
    7a96:	0f b6 d2             	movzbl %dl,%edx
    7a99:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7aa0:	00 
    7aa1:	48 85 c0             	test   %rax,%rax
    7aa4:	75 23                	jne    7ac9 <fwp_free_zombie+0x1c9>
    7aa6:	eb 5c                	jmp    7b04 <fwp_free_zombie+0x204>
    7aa8:	66 90                	xchg   %ax,%ax
    7aaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ab1:	00 00 00 00 
    7ab5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7abc:	00 00 00 00 
    7ac0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7ac4:	48 85 c0             	test   %rax,%rax
    7ac7:	74 3b                	je     7b04 <fwp_free_zombie+0x204>
    7ac9:	48 89 c2             	mov    %rax,%rdx
    7acc:	48 39 08             	cmp    %rcx,(%rax)
    7acf:	75 ef                	jne    7ac0 <fwp_free_zombie+0x1c0>
    7ad1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ad5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7ad9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7add:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ae4:	0f 85 b3 fe ff ff    	jne    799d <fwp_free_zombie+0x9d>
    7aea:	48 89 cf             	mov    %rcx,%rdi
    7aed:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7af2:	e8 d9 dc ff ff       	call   57d0 <fwp_rc_forget_slot>
    7af7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7afc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7aff:	e9 99 fe ff ff       	jmp    799d <fwp_free_zombie+0x9d>
    7b04:	48 8d 3d e5 5e 00 00 	lea    0x5ee5(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    7b0b:	e8 40 c9 ff ff       	call   4450 <fwp_trap>

0000000000007b10 <fwp_block>:
    7b10:	48 83 ec 08          	sub    $0x8,%rsp
    7b14:	48 8b 05 cd 1c 06 00 	mov    0x61ccd(%rip),%rax        # 697e8 <fwp_ready_head>
    7b1b:	48 85 c0             	test   %rax,%rax
    7b1e:	0f 84 1c 01 00 00    	je     7c40 <fwp_block+0x130>
    7b24:	90                   	nop
    7b25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b2c:	00 00 00 00 
    7b30:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7b37:	48 89 15 aa 1c 06 00 	mov    %rdx,0x61caa(%rip)        # 697e8 <fwp_ready_head>
    7b3e:	48 85 d2             	test   %rdx,%rdx
    7b41:	0f 84 19 01 00 00    	je     7c60 <fwp_block+0x150>
    7b47:	48 8b 15 b2 1c 06 00 	mov    0x61cb2(%rip),%rdx        # 69800 <fwp_cur>
    7b4e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7b52:	48 39 c2             	cmp    %rax,%rdx
    7b55:	0f 84 d5 00 00 00    	je     7c30 <fwp_block+0x120>
    7b5b:	48 8b 0d 26 39 06 00 	mov    0x63926(%rip),%rcx        # 6b488 <fwp_state_owners>
    7b62:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7b66:	48 89 05 93 1c 06 00 	mov    %rax,0x61c93(%rip)        # 69800 <fwp_cur>
    7b6d:	f3 0f 7e 05 3b 39 06 	movq   0x6393b(%rip),%xmm0        # 6b4b0 <fwp_foreign_callbacks>
    7b74:	00 
    7b75:	0f 16 05 24 39 06 00 	movhps 0x63924(%rip),%xmm0        # 6b4a0 <fwp_state>
    7b7c:	f3 0f 7e 0d 24 39 06 	movq   0x63924(%rip),%xmm1        # 6b4a8 <fwp_handlers>
    7b83:	00 
    7b84:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7b8b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7b92:	0f 16 0d 1f 39 06 00 	movhps 0x6391f(%rip),%xmm1        # 6b4b8 <fwp_cleanups>
    7b99:	f3 0f 7e 05 f7 38 06 	movq   0x638f7(%rip),%xmm0        # 6b498 <fwp_state_len>
    7ba0:	00 
    7ba1:	0f 16 05 e8 38 06 00 	movhps 0x638e8(%rip),%xmm0        # 6b490 <fwp_state_cap>
    7ba8:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7baf:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7bb6:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bba:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7bc1:	48 89 0d e0 38 06 00 	mov    %rcx,0x638e0(%rip)        # 6b4a8 <fwp_handlers>
    7bc8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7bcf:	48 89 0d e2 38 06 00 	mov    %rcx,0x638e2(%rip)        # 6b4b8 <fwp_cleanups>
    7bd6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7bdd:	48 89 0d cc 38 06 00 	mov    %rcx,0x638cc(%rip)        # 6b4b0 <fwp_foreign_callbacks>
    7be4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7beb:	48 89 0d ae 38 06 00 	mov    %rcx,0x638ae(%rip)        # 6b4a0 <fwp_state>
    7bf2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7bf9:	48 89 0d 98 38 06 00 	mov    %rcx,0x63898(%rip)        # 6b498 <fwp_state_len>
    7c00:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7c07:	48 89 0d 82 38 06 00 	mov    %rcx,0x63882(%rip)        # 6b490 <fwp_state_cap>
    7c0e:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7c15:	48 89 0d 6c 38 06 00 	mov    %rcx,0x6386c(%rip)        # 6b488 <fwp_state_owners>
    7c1c:	e8 5f b8 ff ff       	call   3480 <swapcontext@plt>
    7c21:	f3 0f 1e fa          	endbr64
    7c25:	e8 d6 fc ff ff       	call   7900 <fwp_free_zombie>
    7c2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c30:	8b 05 9a 15 06 00    	mov    0x6159a(%rip),%eax        # 691d0 <fwp_slice>
    7c36:	85 c0                	test   %eax,%eax
    7c38:	74 36                	je     7c70 <fwp_block+0x160>
    7c3a:	48 83 c4 08          	add    $0x8,%rsp
    7c3e:	c3                   	ret
    7c3f:	90                   	nop
    7c40:	e8 cb d7 ff ff       	call   5410 <fwp_poll_events>
    7c45:	48 8b 05 9c 1b 06 00 	mov    0x61b9c(%rip),%rax        # 697e8 <fwp_ready_head>
    7c4c:	48 85 c0             	test   %rax,%rax
    7c4f:	0f 85 db fe ff ff    	jne    7b30 <fwp_block+0x20>
    7c55:	eb e9                	jmp    7c40 <fwp_block+0x130>
    7c57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c5e:	00 00 
    7c60:	48 c7 05 75 1b 06 00 	movq   $0x0,0x61b75(%rip)        # 697e0 <fwp_ready_tail>
    7c67:	00 00 00 00 
    7c6b:	e9 d7 fe ff ff       	jmp    7b47 <fwp_block+0x37>
    7c70:	48 8d 3d 68 55 00 00 	lea    0x5568(%rip),%rdi        # d1df <_IO_stdin_used+0x1df>
    7c77:	e8 14 b7 ff ff       	call   3390 <getenv@plt>
    7c7c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7c81:	48 85 c0             	test   %rax,%rax
    7c84:	74 05                	je     7c8b <fwp_block+0x17b>
    7c86:	80 38 00             	cmpb   $0x0,(%rax)
    7c89:	75 0b                	jne    7c96 <fwp_block+0x186>
    7c8b:	89 15 3f 15 06 00    	mov    %edx,0x6153f(%rip)        # 691d0 <fwp_slice>
    7c91:	48 83 c4 08          	add    $0x8,%rsp
    7c95:	c3                   	ret
    7c96:	ba 0a 00 00 00       	mov    $0xa,%edx
    7c9b:	31 f6                	xor    %esi,%esi
    7c9d:	48 89 c7             	mov    %rax,%rdi
    7ca0:	e8 9b b8 ff ff       	call   3540 <strtoll@plt>
    7ca5:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7ca9:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7cb0:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7cb5:	0f 46 d0             	cmovbe %eax,%edx
    7cb8:	eb d1                	jmp    7c8b <fwp_block+0x17b>
    7cba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007cc0 <fwp_caps173>:
    7cc0:	f3 0f 1e fa          	endbr64
    7cc4:	85 f6                	test   %esi,%esi
    7cc6:	74 08                	je     7cd0 <fwp_caps173+0x10>
    7cc8:	c3                   	ret
    7cc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cd0:	48 8b 15 21 2f 06 00 	mov    0x62f21(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7cd7:	48 89 f8             	mov    %rdi,%rax
    7cda:	48 2b 05 ef 2e 06 00 	sub    0x62eef(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7ce1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce5:	48 39 d0             	cmp    %rdx,%rax
    7ce8:	73 de                	jae    7cc8 <fwp_caps173+0x8>
    7cea:	48 89 c2             	mov    %rax,%rdx
    7ced:	48 c1 ea 10          	shr    $0x10,%rdx
    7cf1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7cf5:	48 8b 15 1c 2f 06 00 	mov    0x62f1c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7cfc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d00:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d04:	48 85 c9             	test   %rcx,%rcx
    7d07:	74 bf                	je     7cc8 <fwp_caps173+0x8>
    7d09:	0f b6 32             	movzbl (%rdx),%esi
    7d0c:	40 80 fe 02          	cmp    $0x2,%sil
    7d10:	74 2e                	je     7d40 <fwp_caps173+0x80>
    7d12:	40 80 fe 01          	cmp    $0x1,%sil
    7d16:	75 b0                	jne    7cc8 <fwp_caps173+0x8>
    7d18:	8b 72 18             	mov    0x18(%rdx),%esi
    7d1b:	0f b7 c0             	movzwl %ax,%eax
    7d1e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d21:	48 0f af c6          	imul   %rsi,%rax
    7d25:	48 c1 e8 20          	shr    $0x20,%rax
    7d29:	48 39 d0             	cmp    %rdx,%rax
    7d2c:	73 9a                	jae    7cc8 <fwp_caps173+0x8>
    7d2e:	48 01 c1             	add    %rax,%rcx
    7d31:	80 39 01             	cmpb   $0x1,(%rcx)
    7d34:	75 92                	jne    7cc8 <fwp_caps173+0x8>
    7d36:	e9 d5 dc ff ff       	jmp    5a10 <fwp_mem_free>
    7d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d40:	66 85 c0             	test   %ax,%ax
    7d43:	74 ec                	je     7d31 <fwp_caps173+0x71>
    7d45:	c3                   	ret
    7d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d4d:	00 00 00 

0000000000007d50 <fwp_args37>:
    7d50:	f3 0f 1e fa          	endbr64
    7d54:	85 d2                	test   %edx,%edx
    7d56:	74 04                	je     7d5c <fwp_args37+0xc>
    7d58:	85 f6                	test   %esi,%esi
    7d5a:	74 04                	je     7d60 <fwp_args37+0x10>
    7d5c:	c3                   	ret
    7d5d:	0f 1f 00             	nopl   (%rax)
    7d60:	48 8b 15 91 2e 06 00 	mov    0x62e91(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7d67:	48 8b 07             	mov    (%rdi),%rax
    7d6a:	48 2b 05 5f 2e 06 00 	sub    0x62e5f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7d71:	48 c1 e2 10          	shl    $0x10,%rdx
    7d75:	48 39 d0             	cmp    %rdx,%rax
    7d78:	73 e2                	jae    7d5c <fwp_args37+0xc>
    7d7a:	48 89 c2             	mov    %rax,%rdx
    7d7d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d85:	48 8b 15 8c 2e 06 00 	mov    0x62e8c(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    7d8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d90:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d94:	48 85 ff             	test   %rdi,%rdi
    7d97:	74 c3                	je     7d5c <fwp_args37+0xc>
    7d99:	0f b6 0a             	movzbl (%rdx),%ecx
    7d9c:	80 f9 02             	cmp    $0x2,%cl
    7d9f:	74 4f                	je     7df0 <fwp_args37+0xa0>
    7da1:	80 f9 01             	cmp    $0x1,%cl
    7da4:	75 b6                	jne    7d5c <fwp_args37+0xc>
    7da6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7da9:	0f b7 c0             	movzwl %ax,%eax
    7dac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7daf:	48 0f af c1          	imul   %rcx,%rax
    7db3:	48 c1 e8 20          	shr    $0x20,%rax
    7db7:	48 39 d0             	cmp    %rdx,%rax
    7dba:	73 a0                	jae    7d5c <fwp_args37+0xc>
    7dbc:	48 01 c7             	add    %rax,%rdi
    7dbf:	0f b6 07             	movzbl (%rdi),%eax
    7dc2:	84 c0                	test   %al,%al
    7dc4:	74 96                	je     7d5c <fwp_args37+0xc>
    7dc6:	8b 15 1c 37 06 00    	mov    0x6371c(%rip),%edx        # 6b4e8 <iteration_active>
    7dcc:	85 d2                	test   %edx,%edx
    7dce:	75 10                	jne    7de0 <fwp_args37+0x90>
    7dd0:	3c fd                	cmp    $0xfd,%al
    7dd2:	77 22                	ja     7df6 <fwp_args37+0xa6>
    7dd4:	83 c0 01             	add    $0x1,%eax
    7dd7:	88 07                	mov    %al,(%rdi)
    7dd9:	c3                   	ret
    7dda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7de0:	48 83 05 e8 36 06 00 	addq   $0x1,0x636e8(%rip)        # 6b4d0 <iteration_retains>
    7de7:	01 
    7de8:	eb e6                	jmp    7dd0 <fwp_args37+0x80>
    7dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7df0:	66 85 c0             	test   %ax,%ax
    7df3:	74 ca                	je     7dbf <fwp_args37+0x6f>
    7df5:	c3                   	ret
    7df6:	e9 b5 d8 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007e00 <fwp_caps37>:
    7e00:	f3 0f 1e fa          	endbr64
    7e04:	48 83 ec 18          	sub    $0x18,%rsp
    7e08:	48 89 f8             	mov    %rdi,%rax
    7e0b:	8b 7f 04             	mov    0x4(%rdi),%edi
    7e0e:	85 ff                	test   %edi,%edi
    7e10:	0f 84 9a 00 00 00    	je     7eb0 <fwp_caps37+0xb0>
    7e16:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7e1a:	85 f6                	test   %esi,%esi
    7e1c:	0f 85 9e 00 00 00    	jne    7ec0 <fwp_caps37+0xc0>
    7e22:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e27:	e8 24 f7 ff ff       	call   7550 <fwp_drop4>
    7e2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e31:	48 8b 0d c0 2d 06 00 	mov    0x62dc0(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    7e38:	48 89 c2             	mov    %rax,%rdx
    7e3b:	48 2b 15 8e 2d 06 00 	sub    0x62d8e(%rip),%rdx        # 6abd0 <fwp_heap+0x13b0>
    7e42:	48 c1 e1 10          	shl    $0x10,%rcx
    7e46:	48 39 ca             	cmp    %rcx,%rdx
    7e49:	73 6d                	jae    7eb8 <fwp_caps37+0xb8>
    7e4b:	48 89 d1             	mov    %rdx,%rcx
    7e4e:	48 c1 e9 10          	shr    $0x10,%rcx
    7e52:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e56:	48 8b 0d bb 2d 06 00 	mov    0x62dbb(%rip),%rcx        # 6ac18 <fwp_heap+0x13f8>
    7e5d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e61:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e65:	48 85 f6             	test   %rsi,%rsi
    7e68:	74 4e                	je     7eb8 <fwp_caps37+0xb8>
    7e6a:	0f b6 39             	movzbl (%rcx),%edi
    7e6d:	40 80 ff 02          	cmp    $0x2,%dil
    7e71:	0f 84 c9 00 00 00    	je     7f40 <fwp_caps37+0x140>
    7e77:	40 80 ff 01          	cmp    $0x1,%dil
    7e7b:	75 3b                	jne    7eb8 <fwp_caps37+0xb8>
    7e7d:	8b 79 18             	mov    0x18(%rcx),%edi
    7e80:	0f b7 d2             	movzwl %dx,%edx
    7e83:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e86:	48 0f af d7          	imul   %rdi,%rdx
    7e8a:	48 c1 ea 20          	shr    $0x20,%rdx
    7e8e:	48 39 ca             	cmp    %rcx,%rdx
    7e91:	73 25                	jae    7eb8 <fwp_caps37+0xb8>
    7e93:	48 01 d6             	add    %rdx,%rsi
    7e96:	80 3e 01             	cmpb   $0x1,(%rsi)
    7e99:	75 1d                	jne    7eb8 <fwp_caps37+0xb8>
    7e9b:	48 89 c7             	mov    %rax,%rdi
    7e9e:	48 83 c4 18          	add    $0x18,%rsp
    7ea2:	e9 69 db ff ff       	jmp    5a10 <fwp_mem_free>
    7ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7eae:	00 00 
    7eb0:	85 f6                	test   %esi,%esi
    7eb2:	0f 84 79 ff ff ff    	je     7e31 <fwp_caps37+0x31>
    7eb8:	48 83 c4 18          	add    $0x18,%rsp
    7ebc:	c3                   	ret
    7ebd:	0f 1f 00             	nopl   (%rax)
    7ec0:	48 8b 05 31 2d 06 00 	mov    0x62d31(%rip),%rax        # 6abf8 <fwp_heap+0x13d8>
    7ec7:	48 2b 3d 02 2d 06 00 	sub    0x62d02(%rip),%rdi        # 6abd0 <fwp_heap+0x13b0>
    7ece:	48 c1 e0 10          	shl    $0x10,%rax
    7ed2:	48 39 c7             	cmp    %rax,%rdi
    7ed5:	73 e1                	jae    7eb8 <fwp_caps37+0xb8>
    7ed7:	48 89 f8             	mov    %rdi,%rax
    7eda:	48 c1 e8 10          	shr    $0x10,%rax
    7ede:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ee2:	48 8b 05 2f 2d 06 00 	mov    0x62d2f(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    7ee9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7eed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ef1:	48 85 c0             	test   %rax,%rax
    7ef4:	74 c2                	je     7eb8 <fwp_caps37+0xb8>
    7ef6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ef9:	80 f9 02             	cmp    $0x2,%cl
    7efc:	74 52                	je     7f50 <fwp_caps37+0x150>
    7efe:	80 f9 01             	cmp    $0x1,%cl
    7f01:	75 b5                	jne    7eb8 <fwp_caps37+0xb8>
    7f03:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f06:	0f b7 ff             	movzwl %di,%edi
    7f09:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f0c:	48 0f af f9          	imul   %rcx,%rdi
    7f10:	48 c1 ef 20          	shr    $0x20,%rdi
    7f14:	48 39 d7             	cmp    %rdx,%rdi
    7f17:	73 9f                	jae    7eb8 <fwp_caps37+0xb8>
    7f19:	48 01 f8             	add    %rdi,%rax
    7f1c:	0f b6 10             	movzbl (%rax),%edx
    7f1f:	84 d2                	test   %dl,%dl
    7f21:	74 95                	je     7eb8 <fwp_caps37+0xb8>
    7f23:	8b 0d bf 35 06 00    	mov    0x635bf(%rip),%ecx        # 6b4e8 <iteration_active>
    7f29:	85 c9                	test   %ecx,%ecx
    7f2b:	75 33                	jne    7f60 <fwp_caps37+0x160>
    7f2d:	80 fa fd             	cmp    $0xfd,%dl
    7f30:	77 38                	ja     7f6a <fwp_caps37+0x16a>
    7f32:	83 c2 01             	add    $0x1,%edx
    7f35:	88 10                	mov    %dl,(%rax)
    7f37:	e9 7c ff ff ff       	jmp    7eb8 <fwp_caps37+0xb8>
    7f3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7f40:	66 85 d2             	test   %dx,%dx
    7f43:	0f 85 6f ff ff ff    	jne    7eb8 <fwp_caps37+0xb8>
    7f49:	e9 48 ff ff ff       	jmp    7e96 <fwp_caps37+0x96>
    7f4e:	66 90                	xchg   %ax,%ax
    7f50:	66 85 ff             	test   %di,%di
    7f53:	0f 85 5f ff ff ff    	jne    7eb8 <fwp_caps37+0xb8>
    7f59:	eb c1                	jmp    7f1c <fwp_caps37+0x11c>
    7f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f60:	48 83 05 68 35 06 00 	addq   $0x1,0x63568(%rip)        # 6b4d0 <iteration_retains>
    7f67:	01 
    7f68:	eb c3                	jmp    7f2d <fwp_caps37+0x12d>
    7f6a:	48 89 c7             	mov    %rax,%rdi
    7f6d:	48 83 c4 18          	add    $0x18,%rsp
    7f71:	e9 3a d7 ff ff       	jmp    56b0 <fwp_rc_wide_dup>
    7f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f7d:	00 00 00 

0000000000007f80 <fwp_drop0>:
    7f80:	f3 0f 1e fa          	endbr64
    7f84:	48 8b 15 6d 2c 06 00 	mov    0x62c6d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    7f8b:	48 89 f8             	mov    %rdi,%rax
    7f8e:	48 2b 05 3b 2c 06 00 	sub    0x62c3b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    7f95:	48 c1 e2 10          	shl    $0x10,%rdx
    7f99:	48 39 d0             	cmp    %rdx,%rax
    7f9c:	0f 83 36 01 00 00    	jae    80d8 <fwp_drop0+0x158>
    7fa2:	48 83 ec 18          	sub    $0x18,%rsp
    7fa6:	48 8d 35 73 18 06 00 	lea    0x61873(%rip),%rsi        # 69820 <fwp_heap>
    7fad:	48 89 c2             	mov    %rax,%rdx
    7fb0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7fb7:	48 c1 ea 10          	shr    $0x10,%rdx
    7fbb:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7fbf:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7fc3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7fc7:	48 85 d2             	test   %rdx,%rdx
    7fca:	74 42                	je     800e <fwp_drop0+0x8e>
    7fcc:	44 0f b6 01          	movzbl (%rcx),%r8d
    7fd0:	41 80 f8 02          	cmp    $0x2,%r8b
    7fd4:	74 42                	je     8018 <fwp_drop0+0x98>
    7fd6:	41 80 f8 01          	cmp    $0x1,%r8b
    7fda:	75 32                	jne    800e <fwp_drop0+0x8e>
    7fdc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7fe0:	0f b7 c0             	movzwl %ax,%eax
    7fe3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fe6:	49 0f af c0          	imul   %r8,%rax
    7fea:	48 c1 e8 20          	shr    $0x20,%rax
    7fee:	48 39 c8             	cmp    %rcx,%rax
    7ff1:	73 1b                	jae    800e <fwp_drop0+0x8e>
    7ff3:	48 01 c2             	add    %rax,%rdx
    7ff6:	0f b6 02             	movzbl (%rdx),%eax
    7ff9:	84 c0                	test   %al,%al
    7ffb:	74 11                	je     800e <fwp_drop0+0x8e>
    7ffd:	3c 01                	cmp    $0x1,%al
    7fff:	74 27                	je     8028 <fwp_drop0+0xa8>
    8001:	3c ff                	cmp    $0xff,%al
    8003:	0f 84 e7 00 00 00    	je     80f0 <fwp_drop0+0x170>
    8009:	83 e8 01             	sub    $0x1,%eax
    800c:	88 02                	mov    %al,(%rdx)
    800e:	48 83 c4 18          	add    $0x18,%rsp
    8012:	c3                   	ret
    8013:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8018:	66 85 c0             	test   %ax,%ax
    801b:	74 d9                	je     7ff6 <fwp_drop0+0x76>
    801d:	48 83 c4 18          	add    $0x18,%rsp
    8021:	c3                   	ret
    8022:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8028:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    802f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8036:	48 89 f8             	mov    %rdi,%rax
    8039:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    803d:	48 29 c8             	sub    %rcx,%rax
    8040:	48 c1 e2 10          	shl    $0x10,%rdx
    8044:	48 39 d0             	cmp    %rdx,%rax
    8047:	73 71                	jae    80ba <fwp_drop0+0x13a>
    8049:	49 89 c2             	mov    %rax,%r10
    804c:	49 c1 ea 10          	shr    $0x10,%r10
    8050:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8054:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8058:	4d 8b 51 20          	mov    0x20(%r9),%r10
    805c:	4d 85 d2             	test   %r10,%r10
    805f:	74 59                	je     80ba <fwp_drop0+0x13a>
    8061:	45 0f b6 19          	movzbl (%r9),%r11d
    8065:	41 80 fb 02          	cmp    $0x2,%r11b
    8069:	74 75                	je     80e0 <fwp_drop0+0x160>
    806b:	41 80 fb 01          	cmp    $0x1,%r11b
    806f:	75 49                	jne    80ba <fwp_drop0+0x13a>
    8071:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8075:	0f b7 c0             	movzwl %ax,%eax
    8078:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    807c:	49 0f af c3          	imul   %r11,%rax
    8080:	48 c1 e8 20          	shr    $0x20,%rax
    8084:	4c 39 c8             	cmp    %r9,%rax
    8087:	73 31                	jae    80ba <fwp_drop0+0x13a>
    8089:	49 01 c2             	add    %rax,%r10
    808c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8090:	75 28                	jne    80ba <fwp_drop0+0x13a>
    8092:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8097:	e8 74 d9 ff ff       	call   5a10 <fwp_mem_free>
    809c:	48 8d 35 7d 17 06 00 	lea    0x6177d(%rip),%rsi        # 69820 <fwp_heap>
    80a3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    80a8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    80af:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    80b6:	48 c1 e2 10          	shl    $0x10,%rdx
    80ba:	4c 89 c0             	mov    %r8,%rax
    80bd:	48 29 c8             	sub    %rcx,%rax
    80c0:	48 39 d0             	cmp    %rdx,%rax
    80c3:	0f 83 45 ff ff ff    	jae    800e <fwp_drop0+0x8e>
    80c9:	4c 89 c7             	mov    %r8,%rdi
    80cc:	e9 dc fe ff ff       	jmp    7fad <fwp_drop0+0x2d>
    80d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80d8:	c3                   	ret
    80d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80e0:	66 85 c0             	test   %ax,%ax
    80e3:	75 d5                	jne    80ba <fwp_drop0+0x13a>
    80e5:	eb a5                	jmp    808c <fwp_drop0+0x10c>
    80e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ee:	00 00 
    80f0:	48 89 d0             	mov    %rdx,%rax
    80f3:	48 c1 e8 11          	shr    $0x11,%rax
    80f7:	48 31 d0             	xor    %rdx,%rax
    80fa:	48 89 c1             	mov    %rax,%rcx
    80fd:	48 c1 e9 09          	shr    $0x9,%rcx
    8101:	48 31 c8             	xor    %rcx,%rax
    8104:	0f b6 c8             	movzbl %al,%ecx
    8107:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    810e:	00 
    810f:	48 85 c0             	test   %rax,%rax
    8112:	75 15                	jne    8129 <fwp_drop0+0x1a9>
    8114:	eb 4e                	jmp    8164 <fwp_drop0+0x1e4>
    8116:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    811d:	00 00 00 
    8120:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8124:	48 85 c0             	test   %rax,%rax
    8127:	74 3b                	je     8164 <fwp_drop0+0x1e4>
    8129:	48 89 c1             	mov    %rax,%rcx
    812c:	48 39 10             	cmp    %rdx,(%rax)
    812f:	75 ef                	jne    8120 <fwp_drop0+0x1a0>
    8131:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8135:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8139:	48 89 48 08          	mov    %rcx,0x8(%rax)
    813d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8144:	0f 85 c4 fe ff ff    	jne    800e <fwp_drop0+0x8e>
    814a:	48 89 d7             	mov    %rdx,%rdi
    814d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8152:	e8 79 d6 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8157:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    815c:	c6 02 fe             	movb   $0xfe,(%rdx)
    815f:	e9 aa fe ff ff       	jmp    800e <fwp_drop0+0x8e>
    8164:	48 8d 3d 85 58 00 00 	lea    0x5885(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    816b:	e8 e0 c2 ff ff       	call   4450 <fwp_trap>

0000000000008170 <fwp_drop1>:
    8170:	f3 0f 1e fa          	endbr64
    8174:	48 8b 15 7d 2a 06 00 	mov    0x62a7d(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    817b:	48 89 f8             	mov    %rdi,%rax
    817e:	48 2b 05 4b 2a 06 00 	sub    0x62a4b(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8185:	48 c1 e2 10          	shl    $0x10,%rdx
    8189:	48 39 d0             	cmp    %rdx,%rax
    818c:	0f 83 36 01 00 00    	jae    82c8 <fwp_drop1+0x158>
    8192:	48 83 ec 18          	sub    $0x18,%rsp
    8196:	48 8d 35 83 16 06 00 	lea    0x61683(%rip),%rsi        # 69820 <fwp_heap>
    819d:	48 89 c2             	mov    %rax,%rdx
    81a0:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    81a7:	48 c1 ea 10          	shr    $0x10,%rdx
    81ab:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    81af:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    81b3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    81b7:	48 85 d2             	test   %rdx,%rdx
    81ba:	74 42                	je     81fe <fwp_drop1+0x8e>
    81bc:	44 0f b6 01          	movzbl (%rcx),%r8d
    81c0:	41 80 f8 02          	cmp    $0x2,%r8b
    81c4:	74 42                	je     8208 <fwp_drop1+0x98>
    81c6:	41 80 f8 01          	cmp    $0x1,%r8b
    81ca:	75 32                	jne    81fe <fwp_drop1+0x8e>
    81cc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    81d0:	0f b7 c0             	movzwl %ax,%eax
    81d3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81d6:	49 0f af c0          	imul   %r8,%rax
    81da:	48 c1 e8 20          	shr    $0x20,%rax
    81de:	48 39 c8             	cmp    %rcx,%rax
    81e1:	73 1b                	jae    81fe <fwp_drop1+0x8e>
    81e3:	48 01 c2             	add    %rax,%rdx
    81e6:	0f b6 02             	movzbl (%rdx),%eax
    81e9:	84 c0                	test   %al,%al
    81eb:	74 11                	je     81fe <fwp_drop1+0x8e>
    81ed:	3c 01                	cmp    $0x1,%al
    81ef:	74 27                	je     8218 <fwp_drop1+0xa8>
    81f1:	3c ff                	cmp    $0xff,%al
    81f3:	0f 84 e7 00 00 00    	je     82e0 <fwp_drop1+0x170>
    81f9:	83 e8 01             	sub    $0x1,%eax
    81fc:	88 02                	mov    %al,(%rdx)
    81fe:	48 83 c4 18          	add    $0x18,%rsp
    8202:	c3                   	ret
    8203:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8208:	66 85 c0             	test   %ax,%ax
    820b:	74 d9                	je     81e6 <fwp_drop1+0x76>
    820d:	48 83 c4 18          	add    $0x18,%rsp
    8211:	c3                   	ret
    8212:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8218:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    821f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8226:	48 89 f8             	mov    %rdi,%rax
    8229:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    822d:	48 29 c8             	sub    %rcx,%rax
    8230:	48 c1 e2 10          	shl    $0x10,%rdx
    8234:	48 39 d0             	cmp    %rdx,%rax
    8237:	73 71                	jae    82aa <fwp_drop1+0x13a>
    8239:	49 89 c2             	mov    %rax,%r10
    823c:	49 c1 ea 10          	shr    $0x10,%r10
    8240:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8244:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8248:	4d 8b 51 20          	mov    0x20(%r9),%r10
    824c:	4d 85 d2             	test   %r10,%r10
    824f:	74 59                	je     82aa <fwp_drop1+0x13a>
    8251:	45 0f b6 19          	movzbl (%r9),%r11d
    8255:	41 80 fb 02          	cmp    $0x2,%r11b
    8259:	74 75                	je     82d0 <fwp_drop1+0x160>
    825b:	41 80 fb 01          	cmp    $0x1,%r11b
    825f:	75 49                	jne    82aa <fwp_drop1+0x13a>
    8261:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8265:	0f b7 c0             	movzwl %ax,%eax
    8268:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    826c:	49 0f af c3          	imul   %r11,%rax
    8270:	48 c1 e8 20          	shr    $0x20,%rax
    8274:	4c 39 c8             	cmp    %r9,%rax
    8277:	73 31                	jae    82aa <fwp_drop1+0x13a>
    8279:	49 01 c2             	add    %rax,%r10
    827c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8280:	75 28                	jne    82aa <fwp_drop1+0x13a>
    8282:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8287:	e8 84 d7 ff ff       	call   5a10 <fwp_mem_free>
    828c:	48 8d 35 8d 15 06 00 	lea    0x6158d(%rip),%rsi        # 69820 <fwp_heap>
    8293:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8298:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    829f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    82a6:	48 c1 e2 10          	shl    $0x10,%rdx
    82aa:	4c 89 c0             	mov    %r8,%rax
    82ad:	48 29 c8             	sub    %rcx,%rax
    82b0:	48 39 d0             	cmp    %rdx,%rax
    82b3:	0f 83 45 ff ff ff    	jae    81fe <fwp_drop1+0x8e>
    82b9:	4c 89 c7             	mov    %r8,%rdi
    82bc:	e9 dc fe ff ff       	jmp    819d <fwp_drop1+0x2d>
    82c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82c8:	c3                   	ret
    82c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82d0:	66 85 c0             	test   %ax,%ax
    82d3:	75 d5                	jne    82aa <fwp_drop1+0x13a>
    82d5:	eb a5                	jmp    827c <fwp_drop1+0x10c>
    82d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82de:	00 00 
    82e0:	48 89 d0             	mov    %rdx,%rax
    82e3:	48 c1 e8 11          	shr    $0x11,%rax
    82e7:	48 31 d0             	xor    %rdx,%rax
    82ea:	48 89 c1             	mov    %rax,%rcx
    82ed:	48 c1 e9 09          	shr    $0x9,%rcx
    82f1:	48 31 c8             	xor    %rcx,%rax
    82f4:	0f b6 c8             	movzbl %al,%ecx
    82f7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    82fe:	00 
    82ff:	48 85 c0             	test   %rax,%rax
    8302:	75 25                	jne    8329 <fwp_drop1+0x1b9>
    8304:	eb 5e                	jmp    8364 <fwp_drop1+0x1f4>
    8306:	0f 1f 40 00          	nopl   0x0(%rax)
    830a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8311:	00 00 00 00 
    8315:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    831c:	00 00 00 00 
    8320:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8324:	48 85 c0             	test   %rax,%rax
    8327:	74 3b                	je     8364 <fwp_drop1+0x1f4>
    8329:	48 89 c1             	mov    %rax,%rcx
    832c:	48 39 10             	cmp    %rdx,(%rax)
    832f:	75 ef                	jne    8320 <fwp_drop1+0x1b0>
    8331:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8335:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8339:	48 89 48 08          	mov    %rcx,0x8(%rax)
    833d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8344:	0f 85 b4 fe ff ff    	jne    81fe <fwp_drop1+0x8e>
    834a:	48 89 d7             	mov    %rdx,%rdi
    834d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8352:	e8 79 d4 ff ff       	call   57d0 <fwp_rc_forget_slot>
    8357:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    835c:	c6 02 fe             	movb   $0xfe,(%rdx)
    835f:	e9 9a fe ff ff       	jmp    81fe <fwp_drop1+0x8e>
    8364:	48 8d 3d 85 56 00 00 	lea    0x5685(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    836b:	e8 e0 c0 ff ff       	call   4450 <fwp_trap>

0000000000008370 <fwp_drop10>:
    8370:	48 8b 0d 81 28 06 00 	mov    0x62881(%rip),%rcx        # 6abf8 <fwp_heap+0x13d8>
    8377:	48 89 f8             	mov    %rdi,%rax
    837a:	48 2b 05 4f 28 06 00 	sub    0x6284f(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8381:	48 c1 e1 10          	shl    $0x10,%rcx
    8385:	48 39 c8             	cmp    %rcx,%rax
    8388:	0f 83 c2 01 00 00    	jae    8550 <fwp_drop10+0x1e0>
    838e:	48 83 ec 18          	sub    $0x18,%rsp
    8392:	48 89 fa             	mov    %rdi,%rdx
    8395:	48 8d 35 84 14 06 00 	lea    0x61484(%rip),%rsi        # 69820 <fwp_heap>
    839c:	48 89 c1             	mov    %rax,%rcx
    839f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    83a6:	48 c1 e9 10          	shr    $0x10,%rcx
    83aa:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    83ae:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    83b2:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    83b6:	48 85 c9             	test   %rcx,%rcx
    83b9:	74 46                	je     8401 <fwp_drop10+0x91>
    83bb:	44 0f b6 0f          	movzbl (%rdi),%r9d
    83bf:	41 80 f9 02          	cmp    $0x2,%r9b
    83c3:	0f 84 d7 00 00 00    	je     84a0 <fwp_drop10+0x130>
    83c9:	41 80 f9 01          	cmp    $0x1,%r9b
    83cd:	75 32                	jne    8401 <fwp_drop10+0x91>
    83cf:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    83d3:	0f b7 c0             	movzwl %ax,%eax
    83d6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    83d9:	49 0f af c1          	imul   %r9,%rax
    83dd:	48 c1 e8 20          	shr    $0x20,%rax
    83e1:	48 39 f8             	cmp    %rdi,%rax
    83e4:	73 1b                	jae    8401 <fwp_drop10+0x91>
    83e6:	48 01 c1             	add    %rax,%rcx
    83e9:	0f b6 01             	movzbl (%rcx),%eax
    83ec:	84 c0                	test   %al,%al
    83ee:	74 11                	je     8401 <fwp_drop10+0x91>
    83f0:	3c 01                	cmp    $0x1,%al
    83f2:	74 1c                	je     8410 <fwp_drop10+0xa0>
    83f4:	3c ff                	cmp    $0xff,%al
    83f6:	0f 84 5c 01 00 00    	je     8558 <fwp_drop10+0x1e8>
    83fc:	83 e8 01             	sub    $0x1,%eax
    83ff:	88 01                	mov    %al,(%rcx)
    8401:	48 83 c4 18          	add    $0x18,%rsp
    8405:	c3                   	ret
    8406:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    840d:	00 00 00 
    8410:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8417:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    841e:	48 89 d0             	mov    %rdx,%rax
    8421:	49 89 d1             	mov    %rdx,%r9
    8424:	48 c1 e1 10          	shl    $0x10,%rcx
    8428:	48 29 f8             	sub    %rdi,%rax
    842b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    842f:	78 7f                	js     84b0 <fwp_drop10+0x140>
    8431:	48 39 c8             	cmp    %rcx,%rax
    8434:	73 cb                	jae    8401 <fwp_drop10+0x91>
    8436:	48 89 c1             	mov    %rax,%rcx
    8439:	48 c1 e9 10          	shr    $0x10,%rcx
    843d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8441:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8445:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8449:	48 85 f6             	test   %rsi,%rsi
    844c:	74 b3                	je     8401 <fwp_drop10+0x91>
    844e:	0f b6 39             	movzbl (%rcx),%edi
    8451:	40 80 ff 02          	cmp    $0x2,%dil
    8455:	74 39                	je     8490 <fwp_drop10+0x120>
    8457:	40 80 ff 01          	cmp    $0x1,%dil
    845b:	75 a4                	jne    8401 <fwp_drop10+0x91>
    845d:	8b 79 18             	mov    0x18(%rcx),%edi
    8460:	0f b7 c0             	movzwl %ax,%eax
    8463:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8466:	48 0f af c7          	imul   %rdi,%rax
    846a:	48 c1 e8 20          	shr    $0x20,%rax
    846e:	48 39 c8             	cmp    %rcx,%rax
    8471:	73 8e                	jae    8401 <fwp_drop10+0x91>
    8473:	48 01 c6             	add    %rax,%rsi
    8476:	80 3e 01             	cmpb   $0x1,(%rsi)
    8479:	75 86                	jne    8401 <fwp_drop10+0x91>
    847b:	48 89 d7             	mov    %rdx,%rdi
    847e:	48 83 c4 18          	add    $0x18,%rsp
    8482:	e9 89 d5 ff ff       	jmp    5a10 <fwp_mem_free>
    8487:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    848e:	00 00 
    8490:	66 85 c0             	test   %ax,%ax
    8493:	74 e1                	je     8476 <fwp_drop10+0x106>
    8495:	48 83 c4 18          	add    $0x18,%rsp
    8499:	c3                   	ret
    849a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    84a0:	66 85 c0             	test   %ax,%ax
    84a3:	0f 84 40 ff ff ff    	je     83e9 <fwp_drop10+0x79>
    84a9:	48 83 c4 18          	add    $0x18,%rsp
    84ad:	c3                   	ret
    84ae:	66 90                	xchg   %ax,%ax
    84b0:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    84b4:	48 39 c8             	cmp    %rcx,%rax
    84b7:	73 74                	jae    852d <fwp_drop10+0x1bd>
    84b9:	49 89 c2             	mov    %rax,%r10
    84bc:	49 c1 ea 10          	shr    $0x10,%r10
    84c0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    84c4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    84c8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    84cc:	4d 85 d2             	test   %r10,%r10
    84cf:	74 5c                	je     852d <fwp_drop10+0x1bd>
    84d1:	45 0f b6 18          	movzbl (%r8),%r11d
    84d5:	41 80 fb 02          	cmp    $0x2,%r11b
    84d9:	74 6d                	je     8548 <fwp_drop10+0x1d8>
    84db:	41 80 fb 01          	cmp    $0x1,%r11b
    84df:	75 4c                	jne    852d <fwp_drop10+0x1bd>
    84e1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    84e5:	0f b7 c0             	movzwl %ax,%eax
    84e8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    84ec:	49 0f af c3          	imul   %r11,%rax
    84f0:	48 c1 e8 20          	shr    $0x20,%rax
    84f4:	4c 39 c0             	cmp    %r8,%rax
    84f7:	73 34                	jae    852d <fwp_drop10+0x1bd>
    84f9:	49 01 c2             	add    %rax,%r10
    84fc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8500:	75 2b                	jne    852d <fwp_drop10+0x1bd>
    8502:	4c 89 cf             	mov    %r9,%rdi
    8505:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    850a:	e8 01 d5 ff ff       	call   5a10 <fwp_mem_free>
    850f:	48 8d 35 0a 13 06 00 	lea    0x6130a(%rip),%rsi        # 69820 <fwp_heap>
    8516:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    851b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8522:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8529:	48 c1 e1 10          	shl    $0x10,%rcx
    852d:	48 89 d0             	mov    %rdx,%rax
    8530:	48 29 f8             	sub    %rdi,%rax
    8533:	48 39 c8             	cmp    %rcx,%rax
    8536:	0f 82 60 fe ff ff    	jb     839c <fwp_drop10+0x2c>
    853c:	e9 c0 fe ff ff       	jmp    8401 <fwp_drop10+0x91>
    8541:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8548:	66 85 c0             	test   %ax,%ax
    854b:	75 e0                	jne    852d <fwp_drop10+0x1bd>
    854d:	eb ad                	jmp    84fc <fwp_drop10+0x18c>
    854f:	90                   	nop
    8550:	c3                   	ret
    8551:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8558:	48 89 c8             	mov    %rcx,%rax
    855b:	48 c1 e8 11          	shr    $0x11,%rax
    855f:	48 31 c8             	xor    %rcx,%rax
    8562:	48 89 c2             	mov    %rax,%rdx
    8565:	48 c1 ea 09          	shr    $0x9,%rdx
    8569:	48 31 d0             	xor    %rdx,%rax
    856c:	0f b6 d0             	movzbl %al,%edx
    856f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8576:	00 
    8577:	48 85 c0             	test   %rax,%rax
    857a:	75 0d                	jne    8589 <fwp_drop10+0x219>
    857c:	eb 46                	jmp    85c4 <fwp_drop10+0x254>
    857e:	66 90                	xchg   %ax,%ax
    8580:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8584:	48 85 c0             	test   %rax,%rax
    8587:	74 3b                	je     85c4 <fwp_drop10+0x254>
    8589:	48 89 c2             	mov    %rax,%rdx
    858c:	48 39 08             	cmp    %rcx,(%rax)
    858f:	75 ef                	jne    8580 <fwp_drop10+0x210>
    8591:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8595:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8599:	48 89 50 08          	mov    %rdx,0x8(%rax)
    859d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    85a4:	0f 85 57 fe ff ff    	jne    8401 <fwp_drop10+0x91>
    85aa:	48 89 cf             	mov    %rcx,%rdi
    85ad:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    85b2:	e8 19 d2 ff ff       	call   57d0 <fwp_rc_forget_slot>
    85b7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    85bc:	c6 01 fe             	movb   $0xfe,(%rcx)
    85bf:	e9 3d fe ff ff       	jmp    8401 <fwp_drop10+0x91>
    85c4:	48 8d 3d 25 54 00 00 	lea    0x5425(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    85cb:	e8 80 be ff ff       	call   4450 <fwp_trap>

00000000000085d0 <f37>:
    85d0:	41 57                	push   %r15
    85d2:	41 56                	push   %r14
    85d4:	41 55                	push   %r13
    85d6:	41 54                	push   %r12
    85d8:	55                   	push   %rbp
    85d9:	53                   	push   %rbx
    85da:	48 83 ec 38          	sub    $0x38,%rsp
    85de:	48 8b 15 13 26 06 00 	mov    0x62613(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    85e5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    85ea:	48 c1 e2 10          	shl    $0x10,%rdx
    85ee:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    85f5:	00 00 
    85f7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    85fc:	48 8b 0d cd 25 06 00 	mov    0x625cd(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    8603:	48 85 ff             	test   %rdi,%rdi
    8606:	0f 84 5e 03 00 00    	je     896a <f37+0x39a>
    860c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8611:	4c 8b 68 10          	mov    0x10(%rax),%r13
    8615:	4c 89 e8             	mov    %r13,%rax
    8618:	48 29 c8             	sub    %rcx,%rax
    861b:	48 39 d0             	cmp    %rdx,%rax
    861e:	0f 83 2c 03 00 00    	jae    8950 <f37+0x380>
    8624:	48 89 c2             	mov    %rax,%rdx
    8627:	48 c1 ea 10          	shr    $0x10,%rdx
    862b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    862f:	48 8b 15 e2 25 06 00 	mov    0x625e2(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8636:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    863a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    863e:	48 85 ff             	test   %rdi,%rdi
    8641:	0f 84 09 03 00 00    	je     8950 <f37+0x380>
    8647:	0f b6 0a             	movzbl (%rdx),%ecx
    864a:	80 f9 02             	cmp    $0x2,%cl
    864d:	0f 84 8d 02 00 00    	je     88e0 <f37+0x310>
    8653:	80 f9 01             	cmp    $0x1,%cl
    8656:	75 24                	jne    867c <f37+0xac>
    8658:	8b 4a 18             	mov    0x18(%rdx),%ecx
    865b:	0f b7 c0             	movzwl %ax,%eax
    865e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8661:	48 0f af c1          	imul   %rcx,%rax
    8665:	48 c1 e8 20          	shr    $0x20,%rax
    8669:	48 39 d0             	cmp    %rdx,%rax
    866c:	73 0e                	jae    867c <f37+0xac>
    866e:	48 01 c7             	add    %rax,%rdi
    8671:	0f b6 07             	movzbl (%rdi),%eax
    8674:	84 c0                	test   %al,%al
    8676:	0f 85 84 02 00 00    	jne    8900 <f37+0x330>
    867c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8681:	48 8b 40 10          	mov    0x10(%rax),%rax
    8685:	ba 01 00 00 00       	mov    $0x1,%edx
    868a:	48 85 c0             	test   %rax,%rax
    868d:	74 0e                	je     869d <f37+0xcd>
    868f:	90                   	nop
    8690:	48 8b 40 10          	mov    0x10(%rax),%rax
    8694:	48 83 c2 01          	add    $0x1,%rdx
    8698:	48 85 c0             	test   %rax,%rax
    869b:	75 f3                	jne    8690 <f37+0xc0>
    869d:	4d 85 ed             	test   %r13,%r13
    86a0:	0f 84 da 02 00 00    	je     8980 <f37+0x3b0>
    86a6:	4c 89 e8             	mov    %r13,%rax
    86a9:	31 db                	xor    %ebx,%ebx
    86ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    86b0:	48 8b 40 10          	mov    0x10(%rax),%rax
    86b4:	48 83 c3 01          	add    $0x1,%rbx
    86b8:	48 85 c0             	test   %rax,%rax
    86bb:	75 f3                	jne    86b0 <f37+0xe0>
    86bd:	48 39 d3             	cmp    %rdx,%rbx
    86c0:	48 0f 47 da          	cmova  %rdx,%rbx
    86c4:	48 89 d8             	mov    %rbx,%rax
    86c7:	48 c1 e8 3c          	shr    $0x3c,%rax
    86cb:	0f 85 bd 03 00 00    	jne    8a8e <f37+0x4be>
    86d1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    86d5:	be 02 00 00 00       	mov    $0x2,%esi
    86da:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    86e1:	00 
    86e2:	e8 29 d8 ff ff       	call   5f10 <fwp_heap_alloc>
    86e7:	48 89 28             	mov    %rbp,(%rax)
    86ea:	48 8b 15 07 25 06 00 	mov    0x62507(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    86f1:	49 89 c4             	mov    %rax,%r12
    86f4:	48 2b 05 d5 24 06 00 	sub    0x624d5(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    86fb:	48 c1 e2 10          	shl    $0x10,%rdx
    86ff:	48 39 d0             	cmp    %rdx,%rax
    8702:	73 57                	jae    875b <f37+0x18b>
    8704:	48 89 c2             	mov    %rax,%rdx
    8707:	48 c1 ea 10          	shr    $0x10,%rdx
    870b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    870f:	48 8b 15 02 25 06 00 	mov    0x62502(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8716:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    871a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    871e:	48 85 ed             	test   %rbp,%rbp
    8721:	74 38                	je     875b <f37+0x18b>
    8723:	0f b6 0a             	movzbl (%rdx),%ecx
    8726:	80 f9 02             	cmp    $0x2,%cl
    8729:	0f 84 11 02 00 00    	je     8940 <f37+0x370>
    872f:	80 f9 01             	cmp    $0x1,%cl
    8732:	75 27                	jne    875b <f37+0x18b>
    8734:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8737:	0f b7 c0             	movzwl %ax,%eax
    873a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    873d:	48 0f af c1          	imul   %rcx,%rax
    8741:	48 c1 e8 20          	shr    $0x20,%rax
    8745:	48 39 d0             	cmp    %rdx,%rax
    8748:	73 11                	jae    875b <f37+0x18b>
    874a:	48 01 c5             	add    %rax,%rbp
    874d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8751:	0f 84 97 02 00 00    	je     89ee <f37+0x41e>
    8757:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    875b:	48 85 db             	test   %rbx,%rbx
    875e:	74 5d                	je     87bd <f37+0x1ed>
    8760:	48 c1 e3 04          	shl    $0x4,%rbx
    8764:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8769:	4c 89 e5             	mov    %r12,%rbp
    876c:	4d 89 ef             	mov    %r13,%r15
    876f:	4c 01 e3             	add    %r12,%rbx
    8772:	0f 1f 00             	nopl   (%rax)
    8775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    877c:	00 00 00 00 
    8780:	49 8b 46 08          	mov    0x8(%r14),%rax
    8784:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8788:	48 83 c5 10          	add    $0x10,%rbp
    878c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8791:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8795:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8799:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    879e:	e8 4d df ff ff       	call   66f0 <w120>
    87a3:	66 48 0f 6e d0       	movq   %rax,%xmm2
    87a8:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    87ac:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    87b0:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    87b4:	4d 8b 76 10          	mov    0x10(%r14),%r14
    87b8:	48 39 eb             	cmp    %rbp,%rbx
    87bb:	75 c3                	jne    8780 <f37+0x1b0>
    87bd:	4c 89 ef             	mov    %r13,%rdi
    87c0:	31 db                	xor    %ebx,%ebx
    87c2:	e8 89 ed ff ff       	call   7550 <fwp_drop4>
    87c7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    87cc:	e8 7f ed ff ff       	call   7550 <fwp_drop4>
    87d1:	4d 8b 2c 24          	mov    (%r12),%r13
    87d5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    87d9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    87e0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    87e7:	4d 85 ed             	test   %r13,%r13
    87ea:	74 32                	je     881e <f37+0x24e>
    87ec:	0f 1f 40 00          	nopl   0x0(%rax)
    87f0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    87f7:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    87fc:	48 83 c3 02          	add    $0x2,%rbx
    8800:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    8806:	e8 65 dd ff ff       	call   6570 <f141.constprop.0>
    880b:	4c 39 eb             	cmp    %r13,%rbx
    880e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    8814:	48 89 c7             	mov    %rax,%rdi
    8817:	72 d7                	jb     87f0 <f37+0x220>
    8819:	66 49 0f 7e c5       	movq   %xmm0,%r13
    881e:	4c 89 e7             	mov    %r12,%rdi
    8821:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8826:	e8 45 fb ff ff       	call   8370 <fwp_drop10>
    882b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8830:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8835:	31 ff                	xor    %edi,%edi
    8837:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    883c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8841:	e8 ba d8 ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    8846:	48 8b 15 ab 23 06 00 	mov    0x623ab(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    884d:	48 89 c5             	mov    %rax,%rbp
    8850:	48 2b 05 79 23 06 00 	sub    0x62379(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    8857:	48 c1 e2 10          	shl    $0x10,%rdx
    885b:	48 39 d0             	cmp    %rdx,%rax
    885e:	73 55                	jae    88b5 <f37+0x2e5>
    8860:	48 89 c2             	mov    %rax,%rdx
    8863:	48 c1 ea 10          	shr    $0x10,%rdx
    8867:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    886b:	48 8b 15 a6 23 06 00 	mov    0x623a6(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    8872:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8876:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    887a:	48 85 db             	test   %rbx,%rbx
    887d:	74 36                	je     88b5 <f37+0x2e5>
    887f:	0f b6 0a             	movzbl (%rdx),%ecx
    8882:	80 f9 02             	cmp    $0x2,%cl
    8885:	0f 84 a5 00 00 00    	je     8930 <f37+0x360>
    888b:	80 f9 01             	cmp    $0x1,%cl
    888e:	75 25                	jne    88b5 <f37+0x2e5>
    8890:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8893:	0f b7 c0             	movzwl %ax,%eax
    8896:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8899:	48 0f af c1          	imul   %rcx,%rax
    889d:	48 c1 e8 20          	shr    $0x20,%rax
    88a1:	48 39 d0             	cmp    %rdx,%rax
    88a4:	73 0f                	jae    88b5 <f37+0x2e5>
    88a6:	48 01 c3             	add    %rax,%rbx
    88a9:	80 3b ff             	cmpb   $0xff,(%rbx)
    88ac:	0f 84 2f 01 00 00    	je     89e1 <f37+0x411>
    88b2:	c6 03 01             	movb   $0x1,(%rbx)
    88b5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    88ba:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88c1:	00 00 
    88c3:	0f 85 d1 01 00 00    	jne    8a9a <f37+0x4ca>
    88c9:	48 83 c4 38          	add    $0x38,%rsp
    88cd:	48 89 e8             	mov    %rbp,%rax
    88d0:	5b                   	pop    %rbx
    88d1:	5d                   	pop    %rbp
    88d2:	41 5c                	pop    %r12
    88d4:	41 5d                	pop    %r13
    88d6:	41 5e                	pop    %r14
    88d8:	41 5f                	pop    %r15
    88da:	c3                   	ret
    88db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88e0:	66 85 c0             	test   %ax,%ax
    88e3:	0f 85 93 fd ff ff    	jne    867c <f37+0xac>
    88e9:	0f b6 07             	movzbl (%rdi),%eax
    88ec:	84 c0                	test   %al,%al
    88ee:	0f 84 88 fd ff ff    	je     867c <f37+0xac>
    88f4:	90                   	nop
    88f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88fc:	00 00 00 00 
    8900:	8b 15 e2 2b 06 00    	mov    0x62be2(%rip),%edx        # 6b4e8 <iteration_active>
    8906:	85 d2                	test   %edx,%edx
    8908:	75 56                	jne    8960 <f37+0x390>
    890a:	3c fd                	cmp    $0xfd,%al
    890c:	0f 87 4b 01 00 00    	ja     8a5d <f37+0x48d>
    8912:	83 c0 01             	add    $0x1,%eax
    8915:	88 07                	mov    %al,(%rdi)
    8917:	31 d2                	xor    %edx,%edx
    8919:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    891f:	0f 85 57 fd ff ff    	jne    867c <f37+0xac>
    8925:	e9 73 fd ff ff       	jmp    869d <f37+0xcd>
    892a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8930:	66 85 c0             	test   %ax,%ax
    8933:	0f 85 7c ff ff ff    	jne    88b5 <f37+0x2e5>
    8939:	e9 6b ff ff ff       	jmp    88a9 <f37+0x2d9>
    893e:	66 90                	xchg   %ax,%ax
    8940:	66 85 c0             	test   %ax,%ax
    8943:	0f 85 12 fe ff ff    	jne    875b <f37+0x18b>
    8949:	e9 ff fd ff ff       	jmp    874d <f37+0x17d>
    894e:	66 90                	xchg   %ax,%ax
    8950:	4c 89 e8             	mov    %r13,%rax
    8953:	e9 2d fd ff ff       	jmp    8685 <f37+0xb5>
    8958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    895f:	00 
    8960:	48 83 05 68 2b 06 00 	addq   $0x1,0x62b68(%rip)        # 6b4d0 <iteration_retains>
    8967:	01 
    8968:	eb a0                	jmp    890a <f37+0x33a>
    896a:	48 f7 d9             	neg    %rcx
    896d:	48 39 d1             	cmp    %rdx,%rcx
    8970:	0f 82 85 00 00 00    	jb     89fb <f37+0x42b>
    8976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    897d:	00 00 00 
    8980:	be 02 00 00 00       	mov    $0x2,%esi
    8985:	bf 08 00 00 00       	mov    $0x8,%edi
    898a:	e8 81 d5 ff ff       	call   5f10 <fwp_heap_alloc>
    898f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8996:	48 8b 15 5b 22 06 00 	mov    0x6225b(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    899d:	49 89 c4             	mov    %rax,%r12
    89a0:	48 2b 05 29 22 06 00 	sub    0x62229(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    89a7:	48 c1 e2 10          	shl    $0x10,%rdx
    89ab:	48 39 d0             	cmp    %rdx,%rax
    89ae:	0f 83 b3 00 00 00    	jae    8a67 <f37+0x497>
    89b4:	48 89 c2             	mov    %rax,%rdx
    89b7:	45 31 ed             	xor    %r13d,%r13d
    89ba:	48 c1 ea 10          	shr    $0x10,%rdx
    89be:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89c2:	48 8b 15 4f 22 06 00 	mov    0x6224f(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    89c9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89cd:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    89d1:	48 85 ed             	test   %rbp,%rbp
    89d4:	0f 84 e3 fd ff ff    	je     87bd <f37+0x1ed>
    89da:	31 db                	xor    %ebx,%ebx
    89dc:	e9 42 fd ff ff       	jmp    8723 <f37+0x153>
    89e1:	48 89 df             	mov    %rbx,%rdi
    89e4:	e8 e7 cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    89e9:	e9 c4 fe ff ff       	jmp    88b2 <f37+0x2e2>
    89ee:	48 89 ef             	mov    %rbp,%rdi
    89f1:	e8 da cd ff ff       	call   57d0 <fwp_rc_forget_slot>
    89f6:	e9 5c fd ff ff       	jmp    8757 <f37+0x187>
    89fb:	48 89 c8             	mov    %rcx,%rax
    89fe:	48 c1 e8 10          	shr    $0x10,%rax
    8a02:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8a06:	48 8b 05 0b 22 06 00 	mov    0x6220b(%rip),%rax        # 6ac18 <fwp_heap+0x13f8>
    8a0d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    8a11:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8a15:	48 85 ff             	test   %rdi,%rdi
    8a18:	0f 84 62 ff ff ff    	je     8980 <f37+0x3b0>
    8a1e:	0f b6 02             	movzbl (%rdx),%eax
    8a21:	3c 02                	cmp    $0x2,%al
    8a23:	74 4a                	je     8a6f <f37+0x49f>
    8a25:	3c 01                	cmp    $0x1,%al
    8a27:	0f 85 53 ff ff ff    	jne    8980 <f37+0x3b0>
    8a2d:	0f b7 c1             	movzwl %cx,%eax
    8a30:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a33:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a36:	48 0f af c1          	imul   %rcx,%rax
    8a3a:	48 c1 e8 20          	shr    $0x20,%rax
    8a3e:	48 39 d0             	cmp    %rdx,%rax
    8a41:	0f 83 39 ff ff ff    	jae    8980 <f37+0x3b0>
    8a47:	48 01 c7             	add    %rax,%rdi
    8a4a:	0f b6 07             	movzbl (%rdi),%eax
    8a4d:	84 c0                	test   %al,%al
    8a4f:	0f 84 2b ff ff ff    	je     8980 <f37+0x3b0>
    8a55:	45 31 ed             	xor    %r13d,%r13d
    8a58:	e9 a3 fe ff ff       	jmp    8900 <f37+0x330>
    8a5d:	e8 4e cc ff ff       	call   56b0 <fwp_rc_wide_dup>
    8a62:	e9 b0 fe ff ff       	jmp    8917 <f37+0x347>
    8a67:	45 31 ed             	xor    %r13d,%r13d
    8a6a:	e9 4e fd ff ff       	jmp    87bd <f37+0x1ed>
    8a6f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8a75:	49 89 cd             	mov    %rcx,%r13
    8a78:	0f 85 02 ff ff ff    	jne    8980 <f37+0x3b0>
    8a7e:	0f b6 07             	movzbl (%rdi),%eax
    8a81:	84 c0                	test   %al,%al
    8a83:	0f 85 77 fe ff ff    	jne    8900 <f37+0x330>
    8a89:	e9 f2 fe ff ff       	jmp    8980 <f37+0x3b0>
    8a8e:	48 8d 3d 56 47 00 00 	lea    0x4756(%rip),%rdi        # d1eb <_IO_stdin_used+0x1eb>
    8a95:	e8 b6 b9 ff ff       	call   4450 <fwp_trap>
    8a9a:	e8 b1 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8a9f:	90                   	nop

0000000000008aa0 <fwp_owned_entry37>:
    8aa0:	f3 0f 1e fa          	endbr64
    8aa4:	48 8b 3f             	mov    (%rdi),%rdi
    8aa7:	e9 24 fb ff ff       	jmp    85d0 <f37>
    8aac:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008ab0 <e37>:
    8ab0:	f3 0f 1e fa          	endbr64
    8ab4:	53                   	push   %rbx
    8ab5:	48 8b 1f             	mov    (%rdi),%rbx
    8ab8:	48 89 df             	mov    %rbx,%rdi
    8abb:	e8 30 e2 ff ff       	call   6cf0 <fwp_rc_share>
    8ac0:	48 89 df             	mov    %rbx,%rdi
    8ac3:	e8 08 fb ff ff       	call   85d0 <f37>
    8ac8:	48 89 c3             	mov    %rax,%rbx
    8acb:	48 89 c7             	mov    %rax,%rdi
    8ace:	e8 1d e2 ff ff       	call   6cf0 <fwp_rc_share>
    8ad3:	48 89 d8             	mov    %rbx,%rax
    8ad6:	5b                   	pop    %rbx
    8ad7:	c3                   	ret
    8ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8adf:	00 

0000000000008ae0 <fwp_write>:
    8ae0:	41 57                	push   %r15
    8ae2:	41 56                	push   %r14
    8ae4:	41 55                	push   %r13
    8ae6:	41 54                	push   %r12
    8ae8:	55                   	push   %rbp
    8ae9:	53                   	push   %rbx
    8aea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8af1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8af8:	00 00 
    8afa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8b01:	00 
    8b02:	49 89 d4             	mov    %rdx,%r12
    8b05:	8b 12                	mov    (%rdx),%edx
    8b07:	83 fa 19             	cmp    $0x19,%edx
    8b0a:	77 6a                	ja     8b76 <fwp_write+0x96>
    8b0c:	48 89 f5             	mov    %rsi,%rbp
    8b0f:	89 d0                	mov    %edx,%eax
    8b11:	89 ce                	mov    %ecx,%esi
    8b13:	48 89 fb             	mov    %rdi,%rbx
    8b16:	48 8d 0d b3 51 00 00 	lea    0x51b3(%rip),%rcx        # dcd0 <_IO_stdin_used+0xcd0>
    8b1d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8b21:	48 01 c8             	add    %rcx,%rax
    8b24:	3e ff e0             	notrack jmp *%rax
    8b27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b2e:	00 00 
    8b30:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8b34:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8b38:	48 89 ca             	mov    %rcx,%rdx
    8b3b:	48 85 c9             	test   %rcx,%rcx
    8b3e:	0f 88 9c 0c 00 00    	js     97e0 <fwp_write+0xd00>
    8b44:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8b4b:	00 
    8b4c:	48 89 c6             	mov    %rax,%rsi
    8b4f:	4c 89 e7             	mov    %r12,%rdi
    8b52:	e8 e9 ae ff ff       	call   3a40 <fwp_fmt_u128>
    8b57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b5e:	00 00 
    8b60:	4c 89 e7             	mov    %r12,%rdi
    8b63:	e8 d8 a8 ff ff       	call   3440 <strlen@plt>
    8b68:	4c 89 e6             	mov    %r12,%rsi
    8b6b:	48 89 df             	mov    %rbx,%rdi
    8b6e:	48 89 c2             	mov    %rax,%rdx
    8b71:	e8 7a b5 ff ff       	call   40f0 <buf_put>
    8b76:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b7d:	00 
    8b7e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b85:	00 00 
    8b87:	0f 85 28 04 00 00    	jne    8fb5 <fwp_write+0x4d5>
    8b8d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8b94:	5b                   	pop    %rbx
    8b95:	5d                   	pop    %rbp
    8b96:	41 5c                	pop    %r12
    8b98:	41 5d                	pop    %r13
    8b9a:	41 5e                	pop    %r14
    8b9c:	41 5f                	pop    %r15
    8b9e:	c3                   	ret
    8b9f:	90                   	nop
    8ba0:	49 89 e9             	mov    %rbp,%r9
    8ba3:	4c 8d 05 6b 46 00 00 	lea    0x466b(%rip),%r8        # d215 <_IO_stdin_used+0x215>
    8baa:	b9 00 02 00 00       	mov    $0x200,%ecx
    8baf:	ba 02 00 00 00       	mov    $0x2,%edx
    8bb4:	be 00 02 00 00       	mov    $0x200,%esi
    8bb9:	31 c0                	xor    %eax,%eax
    8bbb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8bc2:	00 
    8bc3:	e8 d8 a7 ff ff       	call   33a0 <__snprintf_chk@plt>
    8bc8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8bcf:	00 
    8bd0:	e8 6b a8 ff ff       	call   3440 <strlen@plt>
    8bd5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8bdc:	00 
    8bdd:	48 89 df             	mov    %rbx,%rdi
    8be0:	48 89 c2             	mov    %rax,%rdx
    8be3:	e8 08 b5 ff ff       	call   40f0 <buf_put>
    8be8:	eb 8c                	jmp    8b76 <fwp_write+0x96>
    8bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bf0:	49 89 e9             	mov    %rbp,%r9
    8bf3:	4c 8d 05 16 46 00 00 	lea    0x4616(%rip),%r8        # d210 <_IO_stdin_used+0x210>
    8bfa:	eb ae                	jmp    8baa <fwp_write+0xca>
    8bfc:	0f 1f 40 00          	nopl   0x0(%rax)
    8c00:	83 fa 13             	cmp    $0x13,%edx
    8c03:	48 8d 05 fc 45 00 00 	lea    0x45fc(%rip),%rax        # d206 <_IO_stdin_used+0x206>
    8c0a:	48 8d 35 fa 45 00 00 	lea    0x45fa(%rip),%rsi        # d20b <_IO_stdin_used+0x20b>
    8c11:	ba 04 00 00 00       	mov    $0x4,%edx
    8c16:	48 0f 44 f0          	cmove  %rax,%rsi
    8c1a:	45 31 ed             	xor    %r13d,%r13d
    8c1d:	e8 ce b4 ff ff       	call   40f0 <buf_put>
    8c22:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8c27:	0f 84 a3 08 00 00    	je     94d0 <fwp_write+0x9f0>
    8c2d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8c32:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8c37:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8c3c:	48 89 df             	mov    %rbx,%rdi
    8c3f:	49 0f 44 c5          	cmove  %r13,%rax
    8c43:	31 c9                	xor    %ecx,%ecx
    8c45:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    8c4a:	e8 91 fe ff ff       	call   8ae0 <fwp_write>
    8c4f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8c54:	0f 84 6e 09 00 00    	je     95c8 <fwp_write+0xae8>
    8c5a:	49 83 c5 01          	add    $0x1,%r13
    8c5e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8c62:	0f 83 68 08 00 00    	jae    94d0 <fwp_write+0x9f0>
    8c68:	ba 02 00 00 00       	mov    $0x2,%edx
    8c6d:	48 8d 35 e1 45 00 00 	lea    0x45e1(%rip),%rsi        # d255 <_IO_stdin_used+0x255>
    8c74:	48 89 df             	mov    %rbx,%rdi
    8c77:	e8 74 b4 ff ff       	call   40f0 <buf_put>
    8c7c:	eb af                	jmp    8c2d <fwp_write+0x14d>
    8c7e:	66 90                	xchg   %ax,%ax
    8c80:	ba 06 00 00 00       	mov    $0x6,%edx
    8c85:	48 8d 35 a2 45 00 00 	lea    0x45a2(%rip),%rsi        # d22e <_IO_stdin_used+0x22e>
    8c8c:	48 83 c5 10          	add    $0x10,%rbp
    8c90:	e8 5b b4 ff ff       	call   40f0 <buf_put>
    8c95:	48 89 ef             	mov    %rbp,%rdi
    8c98:	e8 a3 a7 ff ff       	call   3440 <strlen@plt>
    8c9d:	48 89 ee             	mov    %rbp,%rsi
    8ca0:	48 89 df             	mov    %rbx,%rdi
    8ca3:	48 89 c2             	mov    %rax,%rdx
    8ca6:	e8 45 b4 ff ff       	call   40f0 <buf_put>
    8cab:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8cb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8cb5:	48 89 df             	mov    %rbx,%rdi
    8cb8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8cbd:	e8 2e b4 ff ff       	call   40f0 <buf_put>
    8cc2:	e9 af fe ff ff       	jmp    8b76 <fwp_write+0x96>
    8cc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cce:	00 00 
    8cd0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8cd7:	00 
    8cd8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8cdf:	00 00 
    8ce1:	0f 85 ce 02 00 00    	jne    8fb5 <fwp_write+0x4d5>
    8ce7:	ba 0a 00 00 00       	mov    $0xa,%edx
    8cec:	48 8d 35 27 45 00 00 	lea    0x4527(%rip),%rsi        # d21a <_IO_stdin_used+0x21a>
    8cf3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8cfa:	48 89 df             	mov    %rbx,%rdi
    8cfd:	5b                   	pop    %rbx
    8cfe:	5d                   	pop    %rbp
    8cff:	41 5c                	pop    %r12
    8d01:	41 5d                	pop    %r13
    8d03:	41 5e                	pop    %r14
    8d05:	41 5f                	pop    %r15
    8d07:	e9 e4 b3 ff ff       	jmp    40f0 <buf_put>
    8d0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d10:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8d15:	4d 85 ed             	test   %r13,%r13
    8d18:	0f 84 02 0c 00 00    	je     9920 <fwp_write+0xe40>
    8d1e:	48 8d 35 3d 45 00 00 	lea    0x453d(%rip),%rsi        # d262 <_IO_stdin_used+0x262>
    8d25:	4c 89 ef             	mov    %r13,%rdi
    8d28:	e8 f3 a7 ff ff       	call   3520 <strcmp@plt>
    8d2d:	41 89 c1             	mov    %eax,%r9d
    8d30:	85 c0                	test   %eax,%eax
    8d32:	0f 84 6c 0c 00 00    	je     99a4 <fwp_write+0xec4>
    8d38:	4c 89 ef             	mov    %r13,%rdi
    8d3b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d40:	e8 fb a6 ff ff       	call   3440 <strlen@plt>
    8d45:	4c 89 ee             	mov    %r13,%rsi
    8d48:	48 89 df             	mov    %rbx,%rdi
    8d4b:	48 89 c2             	mov    %rax,%rdx
    8d4e:	e8 9d b3 ff ff       	call   40f0 <buf_put>
    8d53:	ba 01 00 00 00       	mov    $0x1,%edx
    8d58:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d5d:	48 89 df             	mov    %rbx,%rdi
    8d60:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8d65:	e8 86 b3 ff ff       	call   40f0 <buf_put>
    8d6a:	ba 01 00 00 00       	mov    $0x1,%edx
    8d6f:	4c 89 fe             	mov    %r15,%rsi
    8d72:	48 89 df             	mov    %rbx,%rdi
    8d75:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8d7a:	e8 71 b3 ff ff       	call   40f0 <buf_put>
    8d7f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8d84:	45 31 f6             	xor    %r14d,%r14d
    8d87:	85 d2                	test   %edx,%edx
    8d89:	0f 8e 81 0a 00 00    	jle    9810 <fwp_write+0xd30>
    8d8f:	45 31 ed             	xor    %r13d,%r13d
    8d92:	4d 85 ed             	test   %r13,%r13
    8d95:	0f 85 75 07 00 00    	jne    9510 <fwp_write+0xa30>
    8d9b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8da2:	00 
    8da3:	45 85 f6             	test   %r14d,%r14d
    8da6:	0f 84 84 07 00 00    	je     9530 <fwp_write+0xa50>
    8dac:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8db1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8db6:	48 89 df             	mov    %rbx,%rdi
    8db9:	49 83 c5 01          	add    $0x1,%r13
    8dbd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8dc1:	31 c9                	xor    %ecx,%ecx
    8dc3:	e8 18 fd ff ff       	call   8ae0 <fwp_write>
    8dc8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8dcd:	7f c3                	jg     8d92 <fwp_write+0x2b2>
    8dcf:	45 85 f6             	test   %r14d,%r14d
    8dd2:	0f 84 38 0a 00 00    	je     9810 <fwp_write+0xd30>
    8dd8:	b8 29 00 00 00       	mov    $0x29,%eax
    8ddd:	ba 01 00 00 00       	mov    $0x1,%edx
    8de2:	4c 89 fe             	mov    %r15,%rsi
    8de5:	48 89 df             	mov    %rbx,%rdi
    8de8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8dec:	e8 ff b2 ff ff       	call   40f0 <buf_put>
    8df1:	e9 80 fd ff ff       	jmp    8b76 <fwp_write+0x96>
    8df6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8dfd:	00 00 00 
    8e00:	ba 01 00 00 00       	mov    $0x1,%edx
    8e05:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8e0a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8e0f:	e8 dc b2 ff ff       	call   40f0 <buf_put>
    8e14:	48 85 ed             	test   %rbp,%rbp
    8e17:	0f 84 93 06 00 00    	je     94b0 <fwp_write+0x9d0>
    8e1d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8e21:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e26:	31 c9                	xor    %ecx,%ecx
    8e28:	48 89 df             	mov    %rbx,%rdi
    8e2b:	e8 b0 fc ff ff       	call   8ae0 <fwp_write>
    8e30:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8e34:	48 85 ed             	test   %rbp,%rbp
    8e37:	0f 84 73 06 00 00    	je     94b0 <fwp_write+0x9d0>
    8e3d:	ba 02 00 00 00       	mov    $0x2,%edx
    8e42:	48 8d 35 0c 44 00 00 	lea    0x440c(%rip),%rsi        # d255 <_IO_stdin_used+0x255>
    8e49:	48 89 df             	mov    %rbx,%rdi
    8e4c:	e8 9f b2 ff ff       	call   40f0 <buf_put>
    8e51:	eb ca                	jmp    8e1d <fwp_write+0x33d>
    8e53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e58:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8e5c:	85 f6                	test   %esi,%esi
    8e5e:	0f 84 fc 07 00 00    	je     9660 <fwp_write+0xb80>
    8e64:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e6b:	00 
    8e6c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e73:	00 00 
    8e75:	0f 85 3a 01 00 00    	jne    8fb5 <fwp_write+0x4d5>
    8e7b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8e7f:	4c 89 ea             	mov    %r13,%rdx
    8e82:	e9 6c fe ff ff       	jmp    8cf3 <fwp_write+0x213>
    8e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e8e:	00 00 
    8e90:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8e95:	ba 01 00 00 00       	mov    $0x1,%edx
    8e9a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8e9f:	48 89 ee             	mov    %rbp,%rsi
    8ea2:	e8 49 b2 ff ff       	call   40f0 <buf_put>
    8ea7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8eac:	4c 89 e7             	mov    %r12,%rdi
    8eaf:	e8 8c a5 ff ff       	call   3440 <strlen@plt>
    8eb4:	4c 89 e6             	mov    %r12,%rsi
    8eb7:	48 89 df             	mov    %rbx,%rdi
    8eba:	48 89 c2             	mov    %rax,%rdx
    8ebd:	e8 2e b2 ff ff       	call   40f0 <buf_put>
    8ec2:	ba 01 00 00 00       	mov    $0x1,%edx
    8ec7:	48 89 ee             	mov    %rbp,%rsi
    8eca:	48 89 df             	mov    %rbx,%rdi
    8ecd:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8ed2:	e8 19 b2 ff ff       	call   40f0 <buf_put>
    8ed7:	e9 9a fc ff ff       	jmp    8b76 <fwp_write+0x96>
    8edc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ee0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8ee5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8ee9:	0f 8a 8e 0b 00 00    	jp     9a7d <fwp_write+0xf9d>
    8eef:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ef3:	66 0f 54 05 05 4f 00 	andpd  0x4f05(%rip),%xmm0        # de00 <msg.4+0xc0>
    8efa:	00 
    8efb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8f00:	66 0f 2e 05 78 4e 00 	ucomisd 0x4e78(%rip),%xmm0        # dd80 <msg.4+0x40>
    8f07:	00 
    8f08:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f0f:	00 
    8f10:	0f 87 b2 09 00 00    	ja     98c8 <fwp_write+0xde8>
    8f16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8f1d:	00 00 00 
    8f20:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8f24:	89 ee                	mov    %ebp,%esi
    8f26:	4c 89 e7             	mov    %r12,%rdi
    8f29:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8f2e:	e8 3d b8 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8f33:	31 f6                	xor    %esi,%esi
    8f35:	4c 89 e7             	mov    %r12,%rdi
    8f38:	e8 c3 a4 ff ff       	call   3400 <strtod@plt>
    8f3d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8f42:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8f46:	7a 06                	jp     8f4e <fwp_write+0x46e>
    8f48:	0f 84 e9 01 00 00    	je     9137 <fwp_write+0x657>
    8f4e:	83 c5 01             	add    $0x1,%ebp
    8f51:	83 fd 12             	cmp    $0x12,%ebp
    8f54:	75 ca                	jne    8f20 <fwp_write+0x440>
    8f56:	be 11 00 00 00       	mov    $0x11,%esi
    8f5b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8f5f:	4c 89 e7             	mov    %r12,%rdi
    8f62:	e8 09 b8 ff ff       	call   4770 <fwp_format_g.constprop.0>
    8f67:	e9 cb 01 00 00       	jmp    9137 <fwp_write+0x657>
    8f6c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f70:	48 83 fd 01          	cmp    $0x1,%rbp
    8f74:	0f 84 e6 08 00 00    	je     9860 <fwp_write+0xd80>
    8f7a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8f7e:	b8 02 00 00 00       	mov    $0x2,%eax
    8f83:	ba 01 00 00 00       	mov    $0x1,%edx
    8f88:	48 0f 44 d0          	cmove  %rax,%rdx
    8f8c:	48 8d 35 6b 42 00 00 	lea    0x426b(%rip),%rsi        # d1fe <_IO_stdin_used+0x1fe>
    8f93:	48 8d 05 69 42 00 00 	lea    0x4269(%rip),%rax        # d203 <_IO_stdin_used+0x203>
    8f9a:	48 0f 44 f0          	cmove  %rax,%rsi
    8f9e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8fa5:	00 
    8fa6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8fad:	00 00 
    8faf:	0f 84 3e fd ff ff    	je     8cf3 <fwp_write+0x213>
    8fb5:	e8 96 a4 ff ff       	call   3450 <__stack_chk_fail@plt>
    8fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fc0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8fc5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8fca:	e8 61 b0 ff ff       	call   4030 <buf_grow>
    8fcf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8fd3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8fd9:	4c 03 0b             	add    (%rbx),%r9
    8fdc:	66 45 89 11          	mov    %r10w,(%r9)
    8fe0:	45 85 e4             	test   %r12d,%r12d
    8fe3:	0f 8e 07 05 00 00    	jle    94f0 <fwp_write+0xa10>
    8fe9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8ff0:	55 55 55 
    8ff3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8ff8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8fff:	aa aa aa 
    9002:	49 83 c1 01          	add    $0x1,%r9
    9006:	eb 45                	jmp    904d <fwp_write+0x56d>
    9008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    900f:	00 
    9010:	be 01 00 00 00       	mov    $0x1,%esi
    9015:	b8 2d 00 00 00       	mov    $0x2d,%eax
    901a:	88 07                	mov    %al,(%rdi)
    901c:	48 89 e8             	mov    %rbp,%rax
    901f:	49 f7 e8             	imul   %r8
    9022:	48 89 e8             	mov    %rbp,%rax
    9025:	48 c1 f8 3f          	sar    $0x3f,%rax
    9029:	48 29 c2             	sub    %rax,%rdx
    902c:	48 85 c9             	test   %rcx,%rcx
    902f:	0f 95 c0             	setne  %al
    9032:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9036:	48 83 ef 01          	sub    $0x1,%rdi
    903a:	48 21 c5             	and    %rax,%rbp
    903d:	48 29 ea             	sub    %rbp,%rdx
    9040:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9044:	49 39 f9             	cmp    %rdi,%r9
    9047:	0f 84 a3 04 00 00    	je     94f0 <fwp_write+0xa10>
    904d:	48 89 e8             	mov    %rbp,%rax
    9050:	49 f7 e8             	imul   %r8
    9053:	48 89 e8             	mov    %rbp,%rax
    9056:	48 c1 f8 3f          	sar    $0x3f,%rax
    905a:	48 89 d1             	mov    %rdx,%rcx
    905d:	48 29 c1             	sub    %rax,%rcx
    9060:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9064:	48 89 e9             	mov    %rbp,%rcx
    9067:	48 29 c1             	sub    %rax,%rcx
    906a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    906e:	49 f7 e2             	mul    %r10
    9071:	b8 30 00 00 00       	mov    $0x30,%eax
    9076:	48 89 d6             	mov    %rdx,%rsi
    9079:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    907d:	48 d1 ee             	shr    $1,%rsi
    9080:	48 01 f2             	add    %rsi,%rdx
    9083:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9087:	48 29 d6             	sub    %rdx,%rsi
    908a:	74 8e                	je     901a <fwp_write+0x53a>
    908c:	48 83 fe 01          	cmp    $0x1,%rsi
    9090:	0f 85 7a ff ff ff    	jne    9010 <fwp_write+0x530>
    9096:	31 f6                	xor    %esi,%esi
    9098:	b8 2b 00 00 00       	mov    $0x2b,%eax
    909d:	e9 78 ff ff ff       	jmp    901a <fwp_write+0x53a>
    90a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90a8:	66 0f 6e cd          	movd   %ebp,%xmm1
    90ac:	0f 2e c9             	ucomiss %xmm1,%xmm1
    90af:	0f 8a c8 09 00 00    	jp     9a7d <fwp_write+0xf9d>
    90b5:	0f 28 c1             	movaps %xmm1,%xmm0
    90b8:	0f 54 05 31 4d 00 00 	andps  0x4d31(%rip),%xmm0        # ddf0 <msg.4+0xb0>
    90bf:	0f 2e 05 3e 3f 00 00 	ucomiss 0x3f3e(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    90c6:	0f 87 24 08 00 00    	ja     98f0 <fwp_write+0xe10>
    90cc:	66 0f ef d2          	pxor   %xmm2,%xmm2
    90d0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    90d6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    90dd:	00 
    90de:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    90e2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    90e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90ee:	00 00 
    90f0:	44 89 ee             	mov    %r13d,%esi
    90f3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    90f8:	4c 89 e7             	mov    %r12,%rdi
    90fb:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    9100:	e8 6b b6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    9105:	31 f6                	xor    %esi,%esi
    9107:	4c 89 e7             	mov    %r12,%rdi
    910a:	e8 91 a3 ff ff       	call   34a0 <strtof@plt>
    910f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    9114:	0f 2e c8             	ucomiss %xmm0,%xmm1
    9117:	7a 02                	jp     911b <fwp_write+0x63b>
    9119:	74 1c                	je     9137 <fwp_write+0x657>
    911b:	41 83 c5 01          	add    $0x1,%r13d
    911f:	41 83 fd 0a          	cmp    $0xa,%r13d
    9123:	75 cb                	jne    90f0 <fwp_write+0x610>
    9125:	be 09 00 00 00       	mov    $0x9,%esi
    912a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    912f:	4c 89 e7             	mov    %r12,%rdi
    9132:	e8 39 b6 ff ff       	call   4770 <fwp_format_g.constprop.0>
    9137:	4c 89 e7             	mov    %r12,%rdi
    913a:	e8 71 b0 ff ff       	call   41b0 <fwp_finish_float>
    913f:	e9 1c fa ff ff       	jmp    8b60 <fwp_write+0x80>
    9144:	0f 1f 40 00          	nopl   0x0(%rax)
    9148:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    914c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9150:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9157:	00 
    9158:	48 89 ef             	mov    %rbp,%rdi
    915b:	e8 e0 a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9160:	48 89 ef             	mov    %rbp,%rdi
    9163:	e8 d8 a2 ff ff       	call   3440 <strlen@plt>
    9168:	48 89 ee             	mov    %rbp,%rsi
    916b:	48 89 df             	mov    %rbx,%rdi
    916e:	48 89 c2             	mov    %rax,%rdx
    9171:	e8 7a af ff ff       	call   40f0 <buf_put>
    9176:	e9 fb f9 ff ff       	jmp    8b76 <fwp_write+0x96>
    917b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9180:	ba 06 00 00 00       	mov    $0x6,%edx
    9185:	48 8d 35 cc 40 00 00 	lea    0x40cc(%rip),%rsi        # d258 <_IO_stdin_used+0x258>
    918c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9192:	e8 59 af ff ff       	call   40f0 <buf_put>
    9197:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    919e:	ff ff 7f 
    91a1:	48 23 55 00          	and    0x0(%rbp),%rdx
    91a5:	0f 84 86 02 00 00    	je     9431 <fwp_write+0x951>
    91ab:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    91b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    91b4:	48 85 d2             	test   %rdx,%rdx
    91b7:	0f 84 ae 00 00 00    	je     926b <fwp_write+0x78b>
    91bd:	8b 0a                	mov    (%rdx),%ecx
    91bf:	83 f9 1c             	cmp    $0x1c,%ecx
    91c2:	0f 84 58 06 00 00    	je     9820 <fwp_write+0xd40>
    91c8:	83 f9 1b             	cmp    $0x1b,%ecx
    91cb:	0f 87 9a 00 00 00    	ja     926b <fwp_write+0x78b>
    91d1:	be 01 00 00 00       	mov    $0x1,%esi
    91d6:	48 d3 e6             	shl    %cl,%rsi
    91d9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    91df:	0f 85 4b 04 00 00    	jne    9630 <fwp_write+0xb50>
    91e5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    91eb:	0f 85 0f 04 00 00    	jne    9600 <fwp_write+0xb20>
    91f1:	83 e6 21             	and    $0x21,%esi
    91f4:	74 75                	je     926b <fwp_write+0x78b>
    91f6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    91fb:	48 85 ff             	test   %rdi,%rdi
    91fe:	79 07                	jns    9207 <fwp_write+0x727>
    9200:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    9204:	4c 01 ee             	add    %r13,%rsi
    9207:	48 0f be 3e          	movsbq (%rsi),%rdi
    920b:	85 c9                	test   %ecx,%ecx
    920d:	40 0f b6 f7          	movzbl %dil,%esi
    9211:	48 0f 44 f7          	cmove  %rdi,%rsi
    9215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    921c:	00 00 00 00 
    9220:	31 c9                	xor    %ecx,%ecx
    9222:	48 89 df             	mov    %rbx,%rdi
    9225:	49 83 c5 01          	add    $0x1,%r13
    9229:	e8 b2 f8 ff ff       	call   8ae0 <fwp_write>
    922e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9235:	ff ff 7f 
    9238:	48 23 55 00          	and    0x0(%rbp),%rdx
    923c:	49 39 d5             	cmp    %rdx,%r13
    923f:	0f 83 ec 01 00 00    	jae    9431 <fwp_write+0x951>
    9245:	ba 02 00 00 00       	mov    $0x2,%edx
    924a:	48 89 df             	mov    %rbx,%rdi
    924d:	48 8d 35 01 40 00 00 	lea    0x4001(%rip),%rsi        # d255 <_IO_stdin_used+0x255>
    9254:	e8 97 ae ff ff       	call   40f0 <buf_put>
    9259:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    925e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9262:	48 85 d2             	test   %rdx,%rdx
    9265:	0f 85 52 ff ff ff    	jne    91bd <fwp_write+0x6dd>
    926b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9270:	48 85 ff             	test   %rdi,%rdi
    9273:	0f 88 cf 05 00 00    	js     9848 <fwp_write+0xd68>
    9279:	48 8b 31             	mov    (%rcx),%rsi
    927c:	eb a2                	jmp    9220 <fwp_write+0x740>
    927e:	66 90                	xchg   %ax,%ax
    9280:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9287:	00 
    9288:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    928f:	00 00 
    9291:	0f 85 1e fd ff ff    	jne    8fb5 <fwp_write+0x4d5>
    9297:	ba 08 00 00 00       	mov    $0x8,%edx
    929c:	48 8d 35 82 3f 00 00 	lea    0x3f82(%rip),%rsi        # d225 <_IO_stdin_used+0x225>
    92a3:	e9 4b fa ff ff       	jmp    8cf3 <fwp_write+0x213>
    92a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    92af:	00 
    92b0:	89 e8                	mov    %ebp,%eax
    92b2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    92b9:	76 03                	jbe    92be <fwp_write+0x7de>
    92bb:	8b 45 00             	mov    0x0(%rbp),%eax
    92be:	41 89 c6             	mov    %eax,%r14d
    92c1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    92c6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    92cb:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    92cf:	4c 89 ef             	mov    %r13,%rdi
    92d2:	e8 69 a1 ff ff       	call   3440 <strlen@plt>
    92d7:	4c 89 ee             	mov    %r13,%rsi
    92da:	48 89 df             	mov    %rbx,%rdi
    92dd:	48 89 c2             	mov    %rax,%rdx
    92e0:	e8 0b ae ff ff       	call   40f0 <buf_put>
    92e5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    92ea:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    92ee:	85 f6                	test   %esi,%esi
    92f0:	0f 8e 80 f8 ff ff    	jle    8b76 <fwp_write+0x96>
    92f6:	45 31 ed             	xor    %r13d,%r13d
    92f9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92fe:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    9303:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9308:	ba 01 00 00 00       	mov    $0x1,%edx
    930d:	4c 89 fe             	mov    %r15,%rsi
    9310:	48 89 04 24          	mov    %rax,(%rsp)
    9314:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    9319:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    931d:	48 89 df             	mov    %rbx,%rdi
    9320:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9324:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9329:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    932e:	e8 bd ad ff ff       	call   40f0 <buf_put>
    9333:	41 8b 06             	mov    (%r14),%eax
    9336:	83 f8 0e             	cmp    $0xe,%eax
    9339:	0f 84 71 02 00 00    	je     95b0 <fwp_write+0xad0>
    933f:	83 f8 10             	cmp    $0x10,%eax
    9342:	0f 84 38 02 00 00    	je     9580 <fwp_write+0xaa0>
    9348:	83 f8 0a             	cmp    $0xa,%eax
    934b:	0f 84 7f 04 00 00    	je     97d0 <fwp_write+0xcf0>
    9351:	0f 8f f9 00 00 00    	jg     9450 <fwp_write+0x970>
    9357:	83 f8 03             	cmp    $0x3,%eax
    935a:	0f 8f 50 04 00 00    	jg     97b0 <fwp_write+0xcd0>
    9360:	85 c0                	test   %eax,%eax
    9362:	78 10                	js     9374 <fwp_write+0x894>
    9364:	48 8b 04 24          	mov    (%rsp),%rax
    9368:	48 c1 e8 3f          	shr    $0x3f,%rax
    936c:	85 c0                	test   %eax,%eax
    936e:	0f 85 f9 00 00 00    	jne    946d <fwp_write+0x98d>
    9374:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9379:	48 8b 34 24          	mov    (%rsp),%rsi
    937d:	31 c9                	xor    %ecx,%ecx
    937f:	48 89 df             	mov    %rbx,%rdi
    9382:	e8 59 f7 ff ff       	call   8ae0 <fwp_write>
    9387:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    938c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9391:	49 83 c5 01          	add    $0x1,%r13
    9395:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9399:	0f 8f 5f ff ff ff    	jg     92fe <fwp_write+0x81e>
    939f:	e9 d2 f7 ff ff       	jmp    8b76 <fwp_write+0x96>
    93a4:	0f 1f 40 00          	nopl   0x0(%rax)
    93a8:	ba 06 00 00 00       	mov    $0x6,%edx
    93ad:	48 8d 35 97 3e 00 00 	lea    0x3e97(%rip),%rsi        # d24b <_IO_stdin_used+0x24b>
    93b4:	45 31 ed             	xor    %r13d,%r13d
    93b7:	e8 34 ad ff ff       	call   40f0 <buf_put>
    93bc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    93c1:	75 19                	jne    93dc <fwp_write+0x8fc>
    93c3:	eb 6c                	jmp    9431 <fwp_write+0x951>
    93c5:	0f 1f 00             	nopl   (%rax)
    93c8:	ba 02 00 00 00       	mov    $0x2,%edx
    93cd:	48 8d 35 81 3e 00 00 	lea    0x3e81(%rip),%rsi        # d255 <_IO_stdin_used+0x255>
    93d4:	48 89 df             	mov    %rbx,%rdi
    93d7:	e8 14 ad ff ff       	call   40f0 <buf_put>
    93dc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    93e2:	b9 00 02 00 00       	mov    $0x200,%ecx
    93e7:	31 c0                	xor    %eax,%eax
    93e9:	49 83 c5 01          	add    $0x1,%r13
    93ed:	4c 8d 05 5e 3e 00 00 	lea    0x3e5e(%rip),%r8        # d252 <_IO_stdin_used+0x252>
    93f4:	ba 02 00 00 00       	mov    $0x2,%edx
    93f9:	be 00 02 00 00       	mov    $0x200,%esi
    93fe:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9405:	00 
    9406:	e8 95 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    940b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9412:	00 
    9413:	e8 28 a0 ff ff       	call   3440 <strlen@plt>
    9418:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    941f:	00 
    9420:	48 89 df             	mov    %rbx,%rdi
    9423:	48 89 c2             	mov    %rax,%rdx
    9426:	e8 c5 ac ff ff       	call   40f0 <buf_put>
    942b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    942f:	72 97                	jb     93c8 <fwp_write+0x8e8>
    9431:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9436:	ba 01 00 00 00       	mov    $0x1,%edx
    943b:	48 89 df             	mov    %rbx,%rdi
    943e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9443:	e8 a8 ac ff ff       	call   40f0 <buf_put>
    9448:	e9 29 f7 ff ff       	jmp    8b76 <fwp_write+0x96>
    944d:	0f 1f 00             	nopl   (%rax)
    9450:	83 f8 0b             	cmp    $0xb,%eax
    9453:	0f 85 1b ff ff ff    	jne    9374 <fwp_write+0x894>
    9459:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    945e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9462:	83 e0 01             	and    $0x1,%eax
    9465:	85 c0                	test   %eax,%eax
    9467:	0f 84 07 ff ff ff    	je     9374 <fwp_write+0x894>
    946d:	4c 89 fe             	mov    %r15,%rsi
    9470:	48 89 df             	mov    %rbx,%rdi
    9473:	ba 01 00 00 00       	mov    $0x1,%edx
    9478:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    947d:	e8 6e ac ff ff       	call   40f0 <buf_put>
    9482:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9487:	48 8b 34 24          	mov    (%rsp),%rsi
    948b:	31 c9                	xor    %ecx,%ecx
    948d:	48 89 df             	mov    %rbx,%rdi
    9490:	e8 4b f6 ff ff       	call   8ae0 <fwp_write>
    9495:	ba 01 00 00 00       	mov    $0x1,%edx
    949a:	4c 89 fe             	mov    %r15,%rsi
    949d:	48 89 df             	mov    %rbx,%rdi
    94a0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    94a5:	e8 46 ac ff ff       	call   40f0 <buf_put>
    94aa:	e9 d8 fe ff ff       	jmp    9387 <fwp_write+0x8a7>
    94af:	90                   	nop
    94b0:	ba 01 00 00 00       	mov    $0x1,%edx
    94b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94ba:	48 89 df             	mov    %rbx,%rdi
    94bd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    94c2:	e8 29 ac ff ff       	call   40f0 <buf_put>
    94c7:	e9 aa f6 ff ff       	jmp    8b76 <fwp_write+0x96>
    94cc:	0f 1f 40 00          	nopl   0x0(%rax)
    94d0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94d5:	ba 01 00 00 00       	mov    $0x1,%edx
    94da:	48 89 df             	mov    %rbx,%rdi
    94dd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    94e2:	e8 09 ac ff ff       	call   40f0 <buf_put>
    94e7:	e9 8a f6 ff ff       	jmp    8b76 <fwp_write+0x96>
    94ec:	0f 1f 40 00          	nopl   0x0(%rax)
    94f0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    94f4:	48 8b 13             	mov    (%rbx),%rdx
    94f7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    94fc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    9500:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    9504:	e9 6d f6 ff ff       	jmp    8b76 <fwp_write+0x96>
    9509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9510:	ba 02 00 00 00       	mov    $0x2,%edx
    9515:	48 8d 35 39 3d 00 00 	lea    0x3d39(%rip),%rsi        # d255 <_IO_stdin_used+0x255>
    951c:	48 89 df             	mov    %rbx,%rdi
    951f:	e8 cc ab ff ff       	call   40f0 <buf_put>
    9524:	e9 72 f8 ff ff       	jmp    8d9b <fwp_write+0x2bb>
    9529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9530:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9535:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    953a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    953e:	48 89 f7             	mov    %rsi,%rdi
    9541:	48 89 34 24          	mov    %rsi,(%rsp)
    9545:	e8 f6 9e ff ff       	call   3440 <strlen@plt>
    954a:	48 8b 34 24          	mov    (%rsp),%rsi
    954e:	48 89 df             	mov    %rbx,%rdi
    9551:	48 89 c2             	mov    %rax,%rdx
    9554:	e8 97 ab ff ff       	call   40f0 <buf_put>
    9559:	ba 03 00 00 00       	mov    $0x3,%edx
    955e:	48 8d 35 13 3d 00 00 	lea    0x3d13(%rip),%rsi        # d278 <_IO_stdin_used+0x278>
    9565:	48 89 df             	mov    %rbx,%rdi
    9568:	e8 83 ab ff ff       	call   40f0 <buf_put>
    956d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9572:	e9 35 f8 ff ff       	jmp    8dac <fwp_write+0x2cc>
    9577:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    957e:	00 00 
    9580:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9585:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9589:	48 85 ff             	test   %rdi,%rdi
    958c:	0f 84 e2 fd ff ff    	je     9374 <fwp_write+0x894>
    9592:	48 8d 35 c9 3c 00 00 	lea    0x3cc9(%rip),%rsi        # d262 <_IO_stdin_used+0x262>
    9599:	e8 82 9f ff ff       	call   3520 <strcmp@plt>
    959e:	85 c0                	test   %eax,%eax
    95a0:	0f 95 c0             	setne  %al
    95a3:	0f b6 c0             	movzbl %al,%eax
    95a6:	e9 c1 fd ff ff       	jmp    936c <fwp_write+0x88c>
    95ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95b0:	31 c0                	xor    %eax,%eax
    95b2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    95b9:	00 
    95ba:	0f 97 c0             	seta   %al
    95bd:	e9 aa fd ff ff       	jmp    936c <fwp_write+0x88c>
    95c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95c8:	48 89 df             	mov    %rbx,%rdi
    95cb:	ba 02 00 00 00       	mov    $0x2,%edx
    95d0:	48 8d 35 88 3c 00 00 	lea    0x3c88(%rip),%rsi        # d25f <_IO_stdin_used+0x25f>
    95d7:	e8 14 ab ff ff       	call   40f0 <buf_put>
    95dc:	4c 89 e8             	mov    %r13,%rax
    95df:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    95e4:	31 c9                	xor    %ecx,%ecx
    95e6:	48 c1 e0 04          	shl    $0x4,%rax
    95ea:	48 89 df             	mov    %rbx,%rdi
    95ed:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    95f2:	e8 e9 f4 ff ff       	call   8ae0 <fwp_write>
    95f7:	e9 5e f6 ff ff       	jmp    8c5a <fwp_write+0x17a>
    95fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9600:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    9605:	48 85 ff             	test   %rdi,%rdi
    9608:	79 0c                	jns    9616 <fwp_write+0xb36>
    960a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    9611:	00 
    9612:	48 03 75 10          	add    0x10(%rbp),%rsi
    9616:	48 63 3e             	movslq (%rsi),%rdi
    9619:	83 f9 02             	cmp    $0x2,%ecx
    961c:	89 fe                	mov    %edi,%esi
    961e:	48 0f 44 f7          	cmove  %rdi,%rsi
    9622:	e9 f9 fb ff ff       	jmp    9220 <fwp_write+0x740>
    9627:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    962e:	00 00 
    9630:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9635:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    963a:	48 85 ff             	test   %rdi,%rdi
    963d:	0f 88 0f 03 00 00    	js     9952 <fwp_write+0xe72>
    9643:	49 0f bf 38          	movswq (%r8),%rdi
    9647:	83 f9 01             	cmp    $0x1,%ecx
    964a:	0f b7 f7             	movzwl %di,%esi
    964d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9651:	e9 ca fb ff ff       	jmp    9220 <fwp_write+0x740>
    9656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    965d:	00 00 00 
    9660:	ba 01 00 00 00       	mov    $0x1,%edx
    9665:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    966a:	48 83 c5 08          	add    $0x8,%rbp
    966e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9673:	e8 78 aa ff ff       	call   40f0 <buf_put>
    9678:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    967d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9682:	4d 85 ed             	test   %r13,%r13
    9685:	75 46                	jne    96cd <fwp_write+0xbed>
    9687:	e9 04 01 00 00       	jmp    9790 <fwp_write+0xcb0>
    968c:	0f 1f 40 00          	nopl   0x0(%rax)
    9690:	41 80 f9 09          	cmp    $0x9,%r9b
    9694:	0f 84 d6 00 00 00    	je     9770 <fwp_write+0xc90>
    969a:	41 80 f9 0a          	cmp    $0xa,%r9b
    969e:	0f 85 9c 00 00 00    	jne    9740 <fwp_write+0xc60>
    96a4:	ba 02 00 00 00       	mov    $0x2,%edx
    96a9:	48 8d 35 8b 3b 00 00 	lea    0x3b8b(%rip),%rsi        # d23b <_IO_stdin_used+0x23b>
    96b0:	48 89 df             	mov    %rbx,%rdi
    96b3:	e8 38 aa ff ff       	call   40f0 <buf_put>
    96b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    96bf:	00 
    96c0:	48 83 c5 01          	add    $0x1,%rbp
    96c4:	49 39 ec             	cmp    %rbp,%r12
    96c7:	0f 84 c3 00 00 00    	je     9790 <fwp_write+0xcb0>
    96cd:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    96d2:	41 80 f9 0d          	cmp    $0xd,%r9b
    96d6:	74 28                	je     9700 <fwp_write+0xc20>
    96d8:	7e b6                	jle    9690 <fwp_write+0xbb0>
    96da:	41 80 f9 22          	cmp    $0x22,%r9b
    96de:	74 40                	je     9720 <fwp_write+0xc40>
    96e0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    96e4:	75 5a                	jne    9740 <fwp_write+0xc60>
    96e6:	ba 02 00 00 00       	mov    $0x2,%edx
    96eb:	48 8d 35 46 3b 00 00 	lea    0x3b46(%rip),%rsi        # d238 <_IO_stdin_used+0x238>
    96f2:	48 89 df             	mov    %rbx,%rdi
    96f5:	e8 f6 a9 ff ff       	call   40f0 <buf_put>
    96fa:	eb c4                	jmp    96c0 <fwp_write+0xbe0>
    96fc:	0f 1f 40 00          	nopl   0x0(%rax)
    9700:	ba 02 00 00 00       	mov    $0x2,%edx
    9705:	48 8d 35 35 3b 00 00 	lea    0x3b35(%rip),%rsi        # d241 <_IO_stdin_used+0x241>
    970c:	48 89 df             	mov    %rbx,%rdi
    970f:	e8 dc a9 ff ff       	call   40f0 <buf_put>
    9714:	eb aa                	jmp    96c0 <fwp_write+0xbe0>
    9716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    971d:	00 00 00 
    9720:	ba 02 00 00 00       	mov    $0x2,%edx
    9725:	48 8d 35 09 3b 00 00 	lea    0x3b09(%rip),%rsi        # d235 <_IO_stdin_used+0x235>
    972c:	48 89 df             	mov    %rbx,%rdi
    972f:	e8 bc a9 ff ff       	call   40f0 <buf_put>
    9734:	eb 8a                	jmp    96c0 <fwp_write+0xbe0>
    9736:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    973d:	00 00 00 
    9740:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9744:	0f 86 2e 01 00 00    	jbe    9878 <fwp_write+0xd98>
    974a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    974e:	0f 84 24 01 00 00    	je     9878 <fwp_write+0xd98>
    9754:	ba 01 00 00 00       	mov    $0x1,%edx
    9759:	4c 89 fe             	mov    %r15,%rsi
    975c:	48 89 df             	mov    %rbx,%rdi
    975f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9764:	e8 87 a9 ff ff       	call   40f0 <buf_put>
    9769:	e9 52 ff ff ff       	jmp    96c0 <fwp_write+0xbe0>
    976e:	66 90                	xchg   %ax,%ax
    9770:	ba 02 00 00 00       	mov    $0x2,%edx
    9775:	48 8d 35 c2 3a 00 00 	lea    0x3ac2(%rip),%rsi        # d23e <_IO_stdin_used+0x23e>
    977c:	48 89 df             	mov    %rbx,%rdi
    977f:	e8 6c a9 ff ff       	call   40f0 <buf_put>
    9784:	e9 37 ff ff ff       	jmp    96c0 <fwp_write+0xbe0>
    9789:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9790:	ba 01 00 00 00       	mov    $0x1,%edx
    9795:	4c 89 fe             	mov    %r15,%rsi
    9798:	48 89 df             	mov    %rbx,%rdi
    979b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    97a0:	e8 4b a9 ff ff       	call   40f0 <buf_put>
    97a5:	e9 cc f3 ff ff       	jmp    8b76 <fwp_write+0x96>
    97aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    97b0:	83 f8 04             	cmp    $0x4,%eax
    97b3:	0f 85 bb fb ff ff    	jne    9374 <fwp_write+0x894>
    97b9:	48 8b 04 24          	mov    (%rsp),%rax
    97bd:	48 8b 40 08          	mov    0x8(%rax),%rax
    97c1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    97c6:	48 c1 e8 3f          	shr    $0x3f,%rax
    97ca:	e9 96 fc ff ff       	jmp    9465 <fwp_write+0x985>
    97cf:	90                   	nop
    97d0:	8b 0c 24             	mov    (%rsp),%ecx
    97d3:	31 c0                	xor    %eax,%eax
    97d5:	85 c9                	test   %ecx,%ecx
    97d7:	0f 98 c0             	sets   %al
    97da:	e9 86 fc ff ff       	jmp    9465 <fwp_write+0x985>
    97df:	90                   	nop
    97e0:	48 f7 d8             	neg    %rax
    97e3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    97ea:	00 
    97eb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    97f2:	2d 
    97f3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97fa:	00 
    97fb:	48 83 d2 00          	adc    $0x0,%rdx
    97ff:	48 89 c6             	mov    %rax,%rsi
    9802:	48 f7 da             	neg    %rdx
    9805:	e8 36 a2 ff ff       	call   3a40 <fwp_fmt_u128>
    980a:	e9 51 f3 ff ff       	jmp    8b60 <fwp_write+0x80>
    980f:	90                   	nop
    9810:	b8 7d 00 00 00       	mov    $0x7d,%eax
    9815:	e9 c3 f5 ff ff       	jmp    8ddd <fwp_write+0x2fd>
    981a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9820:	4c 89 e9             	mov    %r13,%rcx
    9823:	48 c1 e1 04          	shl    $0x4,%rcx
    9827:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    982c:	48 85 ff             	test   %rdi,%rdi
    982f:	0f 89 eb f9 ff ff    	jns    9220 <fwp_write+0x740>
    9835:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9839:	48 89 ce             	mov    %rcx,%rsi
    983c:	e9 df f9 ff ff       	jmp    9220 <fwp_write+0x740>
    9841:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9848:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    984f:	00 
    9850:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9854:	e9 20 fa ff ff       	jmp    9279 <fwp_write+0x799>
    9859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9860:	ba 02 00 00 00       	mov    $0x2,%edx
    9865:	48 8d 35 94 39 00 00 	lea    0x3994(%rip),%rsi        # d200 <_IO_stdin_used+0x200>
    986c:	e9 2d f7 ff ff       	jmp    8f9e <fwp_write+0x4be>
    9871:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9878:	4c 8d 05 c5 39 00 00 	lea    0x39c5(%rip),%r8        # d244 <_IO_stdin_used+0x244>
    987f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9884:	31 c0                	xor    %eax,%eax
    9886:	ba 02 00 00 00       	mov    $0x2,%edx
    988b:	be 10 00 00 00       	mov    $0x10,%esi
    9890:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9897:	00 
    9898:	e8 03 9b ff ff       	call   33a0 <__snprintf_chk@plt>
    989d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    98a4:	00 
    98a5:	e8 96 9b ff ff       	call   3440 <strlen@plt>
    98aa:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    98b1:	00 
    98b2:	48 89 df             	mov    %rbx,%rdi
    98b5:	48 89 c2             	mov    %rax,%rdx
    98b8:	e8 33 a8 ff ff       	call   40f0 <buf_put>
    98bd:	e9 fe fd ff ff       	jmp    96c0 <fwp_write+0xbe0>
    98c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98c8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98cc:	48 8d 35 27 39 00 00 	lea    0x3927(%rip),%rsi        # d1fa <_IO_stdin_used+0x1fa>
    98d3:	48 8d 05 1f 39 00 00 	lea    0x391f(%rip),%rax        # d1f9 <_IO_stdin_used+0x1f9>
    98da:	4c 89 e7             	mov    %r12,%rdi
    98dd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    98e1:	48 0f 46 f0          	cmovbe %rax,%rsi
    98e5:	e8 f6 9a ff ff       	call   33e0 <strcpy@plt>
    98ea:	e9 71 f2 ff ff       	jmp    8b60 <fwp_write+0x80>
    98ef:	90                   	nop
    98f0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98f4:	48 8d 35 ff 38 00 00 	lea    0x38ff(%rip),%rsi        # d1fa <_IO_stdin_used+0x1fa>
    98fb:	48 8d 05 f7 38 00 00 	lea    0x38f7(%rip),%rax        # d1f9 <_IO_stdin_used+0x1f9>
    9902:	0f 2f c8             	comiss %xmm0,%xmm1
    9905:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    990c:	00 
    990d:	4c 89 e7             	mov    %r12,%rdi
    9910:	48 0f 46 f0          	cmovbe %rax,%rsi
    9914:	e8 c7 9a ff ff       	call   33e0 <strcpy@plt>
    9919:	e9 42 f2 ff ff       	jmp    8b60 <fwp_write+0x80>
    991e:	66 90                	xchg   %ax,%ax
    9920:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9925:	45 85 c0             	test   %r8d,%r8d
    9928:	75 34                	jne    995e <fwp_write+0xe7e>
    992a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9931:	00 
    9932:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9939:	00 00 
    993b:	0f 85 74 f6 ff ff    	jne    8fb5 <fwp_write+0x4d5>
    9941:	ba 02 00 00 00       	mov    $0x2,%edx
    9946:	48 8d 35 28 39 00 00 	lea    0x3928(%rip),%rsi        # d275 <_IO_stdin_used+0x275>
    994d:	e9 a1 f3 ff ff       	jmp    8cf3 <fwp_write+0x213>
    9952:	48 03 75 10          	add    0x10(%rbp),%rsi
    9956:	49 89 f0             	mov    %rsi,%r8
    9959:	e9 e5 fc ff ff       	jmp    9643 <fwp_write+0xb63>
    995e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9963:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9968:	85 ff                	test   %edi,%edi
    996a:	0f 84 fa f3 ff ff    	je     8d6a <fwp_write+0x28a>
    9970:	ba 01 00 00 00       	mov    $0x1,%edx
    9975:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    997a:	48 89 df             	mov    %rbx,%rdi
    997d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9982:	e8 69 a7 ff ff       	call   40f0 <buf_put>
    9987:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    998c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9991:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9997:	85 c0                	test   %eax,%eax
    9999:	0f 8f f0 f3 ff ff    	jg     8d8f <fwp_write+0x2af>
    999f:	e9 34 f4 ff ff       	jmp    8dd8 <fwp_write+0x2f8>
    99a4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    99a8:	49 89 c5             	mov    %rax,%r13
    99ab:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    99b0:	49 89 c4             	mov    %rax,%r12
    99b3:	49 c1 fd 3f          	sar    $0x3f,%r13
    99b7:	4c 09 e8             	or     %r13,%rax
    99ba:	0f 84 a7 00 00 00    	je     9a67 <fwp_write+0xf87>
    99c0:	48 8d 2d f9 58 00 00 	lea    0x58f9(%rip),%rbp        # f2c0 <units.0>
    99c7:	4d 89 e7             	mov    %r12,%r15
    99ca:	48 8b 45 08          	mov    0x8(%rbp),%rax
    99ce:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    99d3:	4c 89 ff             	mov    %r15,%rdi
    99d6:	4c 89 ee             	mov    %r13,%rsi
    99d9:	44 89 0c 24          	mov    %r9d,(%rsp)
    99dd:	48 99                	cqto
    99df:	48 89 d1             	mov    %rdx,%rcx
    99e2:	48 89 c2             	mov    %rax,%rdx
    99e5:	e8 b6 25 00 00       	call   bfa0 <__divmodti4>
    99ea:	44 8b 0c 24          	mov    (%rsp),%r9d
    99ee:	48 89 c1             	mov    %rax,%rcx
    99f1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    99f6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    99fb:	0f 84 94 00 00 00    	je     9a95 <fwp_write+0xfb5>
    9a01:	41 83 c1 01          	add    $0x1,%r9d
    9a05:	48 83 c5 10          	add    $0x10,%rbp
    9a09:	41 83 f9 05          	cmp    $0x5,%r9d
    9a0d:	75 bb                	jne    99ca <fwp_write+0xeea>
    9a0f:	4d 85 ed             	test   %r13,%r13
    9a12:	79 53                	jns    9a67 <fwp_write+0xf87>
    9a14:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a19:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9a1e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9a23:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9a28:	48 99                	cqto
    9a2a:	48 f7 d8             	neg    %rax
    9a2d:	48 83 d2 00          	adc    $0x0,%rdx
    9a31:	48 89 c6             	mov    %rax,%rsi
    9a34:	48 f7 da             	neg    %rdx
    9a37:	e8 04 a0 ff ff       	call   3a40 <fwp_fmt_u128>
    9a3c:	49 89 e8             	mov    %rbp,%r8
    9a3f:	ba 00 02 00 00       	mov    $0x200,%edx
    9a44:	be 02 00 00 00       	mov    $0x2,%esi
    9a49:	31 c0                	xor    %eax,%eax
    9a4b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a52:	00 
    9a53:	48 8d 0d 16 38 00 00 	lea    0x3816(%rip),%rcx        # d270 <_IO_stdin_used+0x270>
    9a5a:	4c 89 e7             	mov    %r12,%rdi
    9a5d:	e8 5e 9c ff ff       	call   36c0 <__sprintf_chk@plt>
    9a62:	e9 f9 f0 ff ff       	jmp    8b60 <fwp_write+0x80>
    9a67:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9a6c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9a71:	31 d2                	xor    %edx,%edx
    9a73:	48 89 ef             	mov    %rbp,%rdi
    9a76:	e8 c5 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9a7b:	eb bf                	jmp    9a3c <fwp_write+0xf5c>
    9a7d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9a84:	4e 61 4e 00 
    9a88:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a8f:	00 
    9a90:	e9 cb f0 ff ff       	jmp    8b60 <fwp_write+0x80>
    9a95:	44 89 0c 24          	mov    %r9d,(%rsp)
    9a99:	48 89 c8             	mov    %rcx,%rax
    9a9c:	48 85 d2             	test   %rdx,%rdx
    9a9f:	78 51                	js     9af2 <fwp_write+0x1012>
    9aa1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9aa6:	48 89 c6             	mov    %rax,%rsi
    9aa9:	48 89 ef             	mov    %rbp,%rdi
    9aac:	e8 8f 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9ab1:	44 8b 0c 24          	mov    (%rsp),%r9d
    9ab5:	49 63 c1             	movslq %r9d,%rax
    9ab8:	49 89 e8             	mov    %rbp,%r8
    9abb:	ba 00 02 00 00       	mov    $0x200,%edx
    9ac0:	be 02 00 00 00       	mov    $0x2,%esi
    9ac5:	48 c1 e0 04          	shl    $0x4,%rax
    9ac9:	48 8d 3d f0 57 00 00 	lea    0x57f0(%rip),%rdi        # f2c0 <units.0>
    9ad0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ad7:	00 
    9ad8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    9adc:	48 8d 0d 88 37 00 00 	lea    0x3788(%rip),%rcx        # d26b <_IO_stdin_used+0x26b>
    9ae3:	4c 89 e7             	mov    %r12,%rdi
    9ae6:	31 c0                	xor    %eax,%eax
    9ae8:	e8 d3 9b ff ff       	call   36c0 <__sprintf_chk@plt>
    9aed:	e9 6e f0 ff ff       	jmp    8b60 <fwp_write+0x80>
    9af2:	48 f7 d8             	neg    %rax
    9af5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9afa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9aff:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9b04:	48 83 d2 00          	adc    $0x0,%rdx
    9b08:	48 89 c6             	mov    %rax,%rsi
    9b0b:	48 f7 da             	neg    %rdx
    9b0e:	e8 2d 9f ff ff       	call   3a40 <fwp_fmt_u128>
    9b13:	44 8b 0c 24          	mov    (%rsp),%r9d
    9b17:	eb 9c                	jmp    9ab5 <fwp_write+0xfd5>
    9b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009b20 <fwp_main_thread>:
    9b20:	f3 0f 1e fa          	endbr64
    9b24:	41 57                	push   %r15
    9b26:	41 56                	push   %r14
    9b28:	41 55                	push   %r13
    9b2a:	41 54                	push   %r12
    9b2c:	55                   	push   %rbp
    9b2d:	53                   	push   %rbx
    9b2e:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
    9b35:	8b 1d 89 10 06 00    	mov    0x61089(%rip),%ebx        # 6abc4 <fwp_heap+0x13a4>
    9b3b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9b42:	00 00 
    9b44:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
    9b4b:	00 
    9b4c:	31 c0                	xor    %eax,%eax
    9b4e:	85 db                	test   %ebx,%ebx
    9b50:	0f 84 73 13 00 00    	je     aec9 <fwp_main_thread+0x13a9>
    9b56:	44 8b 1d 6b 10 06 00 	mov    0x6106b(%rip),%r11d        # 6abc8 <fwp_heap+0x13a8>
    9b5d:	45 85 db             	test   %r11d,%r11d
    9b60:	0f 85 78 13 00 00    	jne    aede <fwp_main_thread+0x13be>
    9b66:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
    9b6d:	00 
    9b6e:	31 f6                	xor    %esi,%esi
    9b70:	48 c7 05 45 f6 05 00 	movq   $0x40000000,0x5f645(%rip)        # 691c0 <fwp_main_stack_size>
    9b77:	00 00 00 40 
    9b7b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9b80:	48 89 05 41 f6 05 00 	mov    %rax,0x5f641(%rip)        # 691c8 <fwp_main_stack_top>
    9b87:	48 8d 05 f2 74 00 00 	lea    0x74f2(%rip),%rax        # 11080 <alt.5>
    9b8e:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9b95:	00 
    9b96:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
    9b9d:	00 
    9b9e:	48 89 c7             	mov    %rax,%rdi
    9ba1:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    9ba6:	48 c7 84 24 e0 00 00 	movq   $0x10000,0xe0(%rsp)
    9bad:	00 00 00 01 00 
    9bb2:	c7 84 24 d8 00 00 00 	movl   $0x0,0xd8(%rsp)
    9bb9:	00 00 00 00 
    9bbd:	e8 de 9a ff ff       	call   36a0 <sigaltstack@plt>
    9bc2:	85 c0                	test   %eax,%eax
    9bc4:	0f 85 6e 23 00 00    	jne    bf38 <fwp_main_thread+0x2418>
    9bca:	31 c0                	xor    %eax,%eax
    9bcc:	b9 12 00 00 00       	mov    $0x12,%ecx
    9bd1:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    9bd8:	00 
    9bd9:	f3 48 ab             	rep stos %rax,(%rdi)
    9bdc:	48 8d 9c 24 40 01 00 	lea    0x140(%rsp),%rbx
    9be3:	00 
    9be4:	48 8d 05 55 a1 ff ff 	lea    -0x5eab(%rip),%rax        # 3d40 <fwp_segv>
    9beb:	c7 84 24 c8 01 00 00 	movl   $0x8000004,0x1c8(%rsp)
    9bf2:	04 00 00 08 
    9bf6:	48 8d bc 24 48 01 00 	lea    0x148(%rsp),%rdi
    9bfd:	00 
    9bfe:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9c03:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
    9c0a:	00 
    9c0b:	e8 50 99 ff ff       	call   3560 <sigemptyset@plt>
    9c10:	85 c0                	test   %eax,%eax
    9c12:	0f 85 20 23 00 00    	jne    bf38 <fwp_main_thread+0x2418>
    9c18:	31 d2                	xor    %edx,%edx
    9c1a:	48 89 de             	mov    %rbx,%rsi
    9c1d:	bf 0b 00 00 00       	mov    $0xb,%edi
    9c22:	e8 c9 97 ff ff       	call   33f0 <sigaction@plt>
    9c27:	85 c0                	test   %eax,%eax
    9c29:	0f 85 09 23 00 00    	jne    bf38 <fwp_main_thread+0x2418>
    9c2f:	31 d2                	xor    %edx,%edx
    9c31:	48 89 de             	mov    %rbx,%rsi
    9c34:	bf 07 00 00 00       	mov    $0x7,%edi
    9c39:	e8 b2 97 ff ff       	call   33f0 <sigaction@plt>
    9c3e:	85 c0                	test   %eax,%eax
    9c40:	0f 85 f2 22 00 00    	jne    bf38 <fwp_main_thread+0x2418>
    9c46:	48 8b 05 f3 0f 06 00 	mov    0x60ff3(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    9c4d:	48 85 c0             	test   %rax,%rax
    9c50:	0f 88 ba 05 00 00    	js     a210 <fwp_main_thread+0x6f0>
    9c56:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9c5a:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9c5f:	48 8d 3d ba a5 ff ff 	lea    -0x5a46(%rip),%rdi        # 4220 <ad_raw_report>
    9c66:	f2 0f 11 05 5a 18 06 	movsd  %xmm0,0x6185a(%rip)        # 6b4c8 <iteration_start_charge>
    9c6d:	00 
    9c6e:	c7 05 70 18 06 00 01 	movl   $0x1,0x61870(%rip)        # 6b4e8 <iteration_active>
    9c75:	00 00 00 
    9c78:	e8 33 25 00 00       	call   c1b0 <atexit>
    9c7d:	85 c0                	test   %eax,%eax
    9c7f:	0f 85 e7 22 00 00    	jne    bf6c <fwp_main_thread+0x244c>
    9c85:	44 8b 15 e4 73 00 00 	mov    0x73e4(%rip),%r10d        # 11070 <st.3>
    9c8c:	45 85 d2             	test   %r10d,%r10d
    9c8f:	0f 84 b9 05 00 00    	je     a24e <fwp_main_thread+0x72e>
    9c95:	48 8b 2d 64 fb 05 00 	mov    0x5fb64(%rip),%rbp        # 69800 <fwp_cur>
    9c9c:	48 85 ed             	test   %rbp,%rbp
    9c9f:	0f 84 cb 01 00 00    	je     9e70 <fwp_main_thread+0x350>
    9ca5:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9caa:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9cae:	48 89 eb             	mov    %rbp,%rbx
    9cb1:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9cb6:	0f 84 41 01 00 00    	je     9dfd <fwp_main_thread+0x2dd>
    9cbc:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9cc1:	0f 84 69 04 00 00    	je     a130 <fwp_main_thread+0x610>
    9cc7:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9ccb:	0f 84 3f 04 00 00    	je     a110 <fwp_main_thread+0x5f0>
    9cd1:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9cd5:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9cd9:	0f 85 d1 04 00 00    	jne    a1b0 <fwp_main_thread+0x690>
    9cdf:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9ce3:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9cea:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9cee:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9cf5:	00 00 00 00 
    9cf9:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9d00:	48 85 d2             	test   %rdx,%rdx
    9d03:	74 07                	je     9d0c <fwp_main_thread+0x1ec>
    9d05:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9d0c:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9d10:	48 85 c0             	test   %rax,%rax
    9d13:	74 34                	je     9d49 <fwp_main_thread+0x229>
    9d15:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9d19:	48 8b 05 b8 fa 05 00 	mov    0x5fab8(%rip),%rax        # 697d8 <fwp_timers>
    9d20:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9d24:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9d2b:	00 00 00 00 
    9d2f:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9d36:	48 85 c0             	test   %rax,%rax
    9d39:	74 07                	je     9d42 <fwp_main_thread+0x222>
    9d3b:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9d42:	48 89 1d 8f fa 05 00 	mov    %rbx,0x5fa8f(%rip)        # 697d8 <fwp_timers>
    9d49:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9d4d:	e8 be dd ff ff       	call   7b10 <fwp_block>
    9d52:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9d59:	48 85 c9             	test   %rcx,%rcx
    9d5c:	74 47                	je     9da5 <fwp_main_thread+0x285>
    9d5e:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9d65:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9d6c:	48 85 d2             	test   %rdx,%rdx
    9d6f:	0f 84 7b 04 00 00    	je     a1f0 <fwp_main_thread+0x6d0>
    9d75:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9d7c:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9d83:	48 85 c0             	test   %rax,%rax
    9d86:	74 07                	je     9d8f <fwp_main_thread+0x26f>
    9d88:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9d8f:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9d96:	00 00 00 00 
    9d9a:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9d9e:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    9da5:	48 8b 0d 54 fa 05 00 	mov    0x5fa54(%rip),%rcx        # 69800 <fwp_cur>
    9dac:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9db0:	0f 84 ea 03 00 00    	je     a1a0 <fwp_main_thread+0x680>
    9db6:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9dbd:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9dc4:	48 85 d2             	test   %rdx,%rdx
    9dc7:	0f 84 33 04 00 00    	je     a200 <fwp_main_thread+0x6e0>
    9dcd:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9dd4:	48 85 c0             	test   %rax,%rax
    9dd7:	74 07                	je     9de0 <fwp_main_thread+0x2c0>
    9dd9:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9de0:	66 0f ef ff          	pxor   %xmm7,%xmm7
    9de4:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9de8:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    9def:	48 89 cb             	mov    %rcx,%rbx
    9df2:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9df7:	0f 85 bf fe ff ff    	jne    9cbc <fwp_main_thread+0x19c>
    9dfd:	48 83 3d 93 16 06 00 	cmpq   $0x0,0x61693(%rip)        # 6b498 <fwp_state_len>
    9e04:	00 
    9e05:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9e09:	75 0e                	jne    9e19 <fwp_main_thread+0x2f9>
    9e0b:	48 83 3d 75 16 06 00 	cmpq   $0x0,0x61675(%rip)        # 6b488 <fwp_state_owners>
    9e12:	00 
    9e13:	0f 84 6b 1f 00 00    	je     bd84 <fwp_main_thread+0x2264>
    9e19:	48 39 1d d8 f9 05 00 	cmp    %rbx,0x5f9d8(%rip)        # 697f8 <fwp_root>
    9e20:	c7 05 56 72 01 00 00 	movl   $0x0,0x17256(%rip)        # 21080 <fwp_exit_code>
    9e27:	00 00 00 
    9e2a:	0f 85 6a 21 00 00    	jne    bf9a <fwp_main_thread+0x247a>
    9e30:	48 85 db             	test   %rbx,%rbx
    9e33:	74 61                	je     9e96 <fwp_main_thread+0x376>
    9e35:	48 8b 15 8c f9 05 00 	mov    0x5f98c(%rip),%rdx        # 697c8 <fwp_tasks_active>
    9e3c:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9e40:	48 85 d2             	test   %rdx,%rdx
    9e43:	74 51                	je     9e96 <fwp_main_thread+0x376>
    9e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e4c:	00 00 00 00 
    9e50:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9e54:	75 08                	jne    9e5e <fwp_main_thread+0x33e>
    9e56:	48 89 d7             	mov    %rdx,%rdi
    9e59:	e8 d2 a2 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    9e5e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9e65:	48 85 d2             	test   %rdx,%rdx
    9e68:	75 e6                	jne    9e50 <fwp_main_thread+0x330>
    9e6a:	e9 6e 02 00 00       	jmp    a0dd <fwp_main_thread+0x5bd>
    9e6f:	90                   	nop
    9e70:	48 83 3d 20 16 06 00 	cmpq   $0x0,0x61620(%rip)        # 6b498 <fwp_state_len>
    9e77:	00 
    9e78:	0f 84 79 1d 00 00    	je     bbf7 <fwp_main_thread+0x20d7>
    9e7e:	48 83 3d 72 f9 05 00 	cmpq   $0x0,0x5f972(%rip)        # 697f8 <fwp_root>
    9e85:	00 
    9e86:	c7 05 f0 71 01 00 00 	movl   $0x0,0x171f0(%rip)        # 21080 <fwp_exit_code>
    9e8d:	00 00 00 
    9e90:	0f 85 ff 20 00 00    	jne    bf95 <fwp_main_thread+0x2475>
    9e96:	e8 65 da ff ff       	call   7900 <fwp_free_zombie>
    9e9b:	48 83 3d 45 f9 05 00 	cmpq   $0x0,0x5f945(%rip)        # 697e8 <fwp_ready_head>
    9ea2:	00 
    9ea3:	0f 85 a2 98 ff ff    	jne    374b <fwp_main_thread.cold>
    9ea9:	48 83 3d 27 f9 05 00 	cmpq   $0x0,0x5f927(%rip)        # 697d8 <fwp_timers>
    9eb0:	00 
    9eb1:	0f 85 94 98 ff ff    	jne    374b <fwp_main_thread.cold>
    9eb7:	8b 05 17 f3 05 00    	mov    0x5f317(%rip),%eax        # 691d4 <fwp_stack_pool_n>
    9ebd:	85 c0                	test   %eax,%eax
    9ebf:	74 3c                	je     9efd <fwp_main_thread+0x3dd>
    9ec1:	83 e8 01             	sub    $0x1,%eax
    9ec4:	4c 8d 25 15 f3 05 00 	lea    0x5f315(%rip),%r12        # 691e0 <fwp_stack_pool>
    9ecb:	48 63 d8             	movslq %eax,%rbx
    9ece:	89 c0                	mov    %eax,%eax
    9ed0:	48 89 da             	mov    %rbx,%rdx
    9ed3:	48 29 c2             	sub    %rax,%rdx
    9ed6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9eda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9ee0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9ee4:	89 1d ea f2 05 00    	mov    %ebx,0x5f2ea(%rip)        # 691d4 <fwp_stack_pool_n>
    9eea:	be 00 00 00 10       	mov    $0x10000000,%esi
    9eef:	48 83 eb 01          	sub    $0x1,%rbx
    9ef3:	e8 c8 96 ff ff       	call   35c0 <munmap@plt>
    9ef8:	48 39 eb             	cmp    %rbp,%rbx
    9efb:	75 e3                	jne    9ee0 <fwp_main_thread+0x3c0>
    9efd:	8b 3d 15 71 00 00    	mov    0x7115(%rip),%edi        # 11018 <fwp_epfd>
    9f03:	85 ff                	test   %edi,%edi
    9f05:	78 05                	js     9f0c <fwp_main_thread+0x3ec>
    9f07:	e8 b4 95 ff ff       	call   34c0 <close@plt>
    9f0c:	4c 8b 25 cd f4 05 00 	mov    0x5f4cd(%rip),%r12        # 693e0 <fwp_nfdws>
    9f13:	48 8b 2d ce f4 05 00 	mov    0x5f4ce(%rip),%rbp        # 693e8 <fwp_fdws>
    9f1a:	31 db                	xor    %ebx,%ebx
    9f1c:	c7 05 f2 70 00 00 ff 	movl   $0xffffffff,0x70f2(%rip)        # 11018 <fwp_epfd>
    9f23:	ff ff ff 
    9f26:	4d 85 e4             	test   %r12,%r12
    9f29:	74 32                	je     9f5d <fwp_main_thread+0x43d>
    9f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9f30:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9f35:	48 85 ff             	test   %rdi,%rdi
    9f38:	74 1a                	je     9f54 <fwp_main_thread+0x434>
    9f3a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    9f3e:	0f 85 07 98 ff ff    	jne    374b <fwp_main_thread.cold>
    9f44:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9f49:	0f 85 fc 97 ff ff    	jne    374b <fwp_main_thread.cold>
    9f4f:	e8 bc ba ff ff       	call   5a10 <fwp_mem_free>
    9f54:	48 83 c3 01          	add    $0x1,%rbx
    9f58:	4c 39 e3             	cmp    %r12,%rbx
    9f5b:	75 d3                	jne    9f30 <fwp_main_thread+0x410>
    9f5d:	48 89 ef             	mov    %rbp,%rdi
    9f60:	e8 ab ba ff ff       	call   5a10 <fwp_mem_free>
    9f65:	48 8b 15 8c f8 05 00 	mov    0x5f88c(%rip),%rdx        # 697f8 <fwp_root>
    9f6c:	48 c7 05 71 f4 05 00 	movq   $0x0,0x5f471(%rip)        # 693e8 <fwp_fdws>
    9f73:	00 00 00 00 
    9f77:	48 c7 05 5e f4 05 00 	movq   $0x0,0x5f45e(%rip)        # 693e0 <fwp_nfdws>
    9f7e:	00 00 00 00 
    9f82:	48 85 d2             	test   %rdx,%rdx
    9f85:	74 4e                	je     9fd5 <fwp_main_thread+0x4b5>
    9f87:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    9f8c:	0f 85 b9 97 ff ff    	jne    374b <fwp_main_thread.cold>
    9f92:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9f99:	00 
    9f9a:	0f 85 ab 97 ff ff    	jne    374b <fwp_main_thread.cold>
    9fa0:	48 83 3d f0 14 06 00 	cmpq   $0x0,0x614f0(%rip)        # 6b498 <fwp_state_len>
    9fa7:	00 
    9fa8:	0f 85 9d 97 ff ff    	jne    374b <fwp_main_thread.cold>
    9fae:	48 83 3d d2 14 06 00 	cmpq   $0x0,0x614d2(%rip)        # 6b488 <fwp_state_owners>
    9fb5:	00 
    9fb6:	0f 85 8f 97 ff ff    	jne    374b <fwp_main_thread.cold>
    9fbc:	b9 79 00 00 00       	mov    $0x79,%ecx
    9fc1:	31 c0                	xor    %eax,%eax
    9fc3:	48 8d 3d 36 f4 05 00 	lea    0x5f436(%rip),%rdi        # 69400 <fwp_root_context>
    9fca:	f3 48 ab             	rep stos %rax,(%rdi)
    9fcd:	48 89 d7             	mov    %rdx,%rdi
    9fd0:	e8 3b ba ff ff       	call   5a10 <fwp_mem_free>
    9fd5:	66 0f 6f 05 d3 71 04 	movdqa 0x471d3(%rip),%xmm0        # 511b0 <ad_raw_live+0x10>
    9fdc:	00 
    9fdd:	66 0f d4 05 bb 71 04 	paddq  0x471bb(%rip),%xmm0        # 511a0 <ad_raw_live>
    9fe4:	00 
    9fe5:	48 c7 05 10 f8 05 00 	movq   $0x0,0x5f810(%rip)        # 69800 <fwp_cur>
    9fec:	00 00 00 00 
    9ff0:	48 8b 05 49 0c 06 00 	mov    0x60c49(%rip),%rax        # 6ac40 <fwp_heap+0x1420>
    9ff7:	48 c7 05 f6 f7 05 00 	movq   $0x0,0x5f7f6(%rip)        # 697f8 <fwp_root>
    9ffe:	00 00 00 00 
    a002:	c7 05 dc 14 06 00 00 	movl   $0x0,0x614dc(%rip)        # 6b4e8 <iteration_active>
    a009:	00 00 00 
    a00c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    a010:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    a015:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    a019:	66 0f d6 05 d7 70 01 	movq   %xmm0,0x170d7(%rip)        # 210f8 <ad_raw_before_shutdown>
    a020:	00 
    a021:	48 85 c0             	test   %rax,%rax
    a024:	0f 88 06 02 00 00    	js     a230 <fwp_main_thread+0x710>
    a02a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a02e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    a033:	f2 0f 5c 0d 8d 14 06 	subsd  0x6148d(%rip),%xmm1        # 6b4c8 <iteration_start_charge>
    a03a:	00 
    a03b:	48 8b 3d fe 6f 00 00 	mov    0x6ffe(%rip),%rdi        # 11040 <stderr@GLIBC_2.2.5>
    a042:	48 8d 15 f7 3a 00 00 	lea    0x3af7(%rip),%rdx        # db40 <_IO_stdin_used+0xb40>
    a049:	be 02 00 00 00       	mov    $0x2,%esi
    a04e:	f2 0f 10 05 6a 14 06 	movsd  0x6146a(%rip),%xmm0        # 6b4c0 <iteration_peak>
    a055:	00 
    a056:	4c 8b 0d 73 14 06 00 	mov    0x61473(%rip),%r9        # 6b4d0 <iteration_retains>
    a05d:	b8 02 00 00 00       	mov    $0x2,%eax
    a062:	4c 8b 05 6f 14 06 00 	mov    0x6146f(%rip),%r8        # 6b4d8 <iteration_bytes>
    a069:	48 8b 0d 70 14 06 00 	mov    0x61470(%rip),%rcx        # 6b4e0 <iteration_requests>
    a070:	e8 fb 95 ff ff       	call   3670 <__fprintf_chk@plt>
    a075:	48 8b 3d a4 6f 00 00 	mov    0x6fa4(%rip),%rdi        # 11020 <stdout@GLIBC_2.2.5>
    a07c:	e8 1f 95 ff ff       	call   35a0 <fflush@plt>
    a081:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
    a088:	00 
    a089:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a090:	00 00 
    a092:	0f 85 e0 1e 00 00    	jne    bf78 <fwp_main_thread+0x2458>
    a098:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
    a09f:	31 c0                	xor    %eax,%eax
    a0a1:	5b                   	pop    %rbx
    a0a2:	5d                   	pop    %rbp
    a0a3:	41 5c                	pop    %r12
    a0a5:	41 5d                	pop    %r13
    a0a7:	41 5e                	pop    %r14
    a0a9:	41 5f                	pop    %r15
    a0ab:	c3                   	ret
    a0ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a0b0:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    a0b7:	48 89 1d 22 f7 05 00 	mov    %rbx,0x5f722(%rip)        # 697e0 <fwp_ready_tail>
    a0be:	e8 4d da ff ff       	call   7b10 <fwp_block>
    a0c3:	e8 38 d8 ff ff       	call   7900 <fwp_free_zombie>
    a0c8:	48 83 3d f8 f6 05 00 	cmpq   $0x0,0x5f6f8(%rip)        # 697c8 <fwp_tasks_active>
    a0cf:	00 
    a0d0:	0f 84 c0 fd ff ff    	je     9e96 <fwp_main_thread+0x376>
    a0d6:	48 8b 1d 1b f7 05 00 	mov    0x5f71b(%rip),%rbx        # 697f8 <fwp_root>
    a0dd:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    a0e1:	75 db                	jne    a0be <fwp_main_thread+0x59e>
    a0e3:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    a0e7:	75 d5                	jne    a0be <fwp_main_thread+0x59e>
    a0e9:	48 8b 05 f0 f6 05 00 	mov    0x5f6f0(%rip),%rax        # 697e0 <fwp_ready_tail>
    a0f0:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    a0f4:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    a0fb:	00 00 00 00 
    a0ff:	48 85 c0             	test   %rax,%rax
    a102:	75 ac                	jne    a0b0 <fwp_main_thread+0x590>
    a104:	48 89 1d dd f6 05 00 	mov    %rbx,0x5f6dd(%rip)        # 697e8 <fwp_ready_head>
    a10b:	eb aa                	jmp    a0b7 <fwp_main_thread+0x597>
    a10d:	0f 1f 00             	nopl   (%rax)
    a110:	e8 ab a4 ff ff       	call   45c0 <fwp_now_ns>
    a115:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    a119:	7c 15                	jl     a130 <fwp_main_thread+0x610>
    a11b:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a11f:	75 0f                	jne    a130 <fwp_main_thread+0x610>
    a121:	48 89 ef             	mov    %rbp,%rdi
    a124:	e8 07 a0 ff ff       	call   4130 <fwp_cancel_tree.part.0>
    a129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a130:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    a134:	0f 85 97 fb ff ff    	jne    9cd1 <fwp_main_thread+0x1b1>
    a13a:	48 8b 45 60          	mov    0x60(%rbp),%rax
    a13e:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    a142:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    a146:	0f 85 97 fb ff ff    	jne    9ce3 <fwp_main_thread+0x1c3>
    a14c:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    a150:	48 85 c9             	test   %rcx,%rcx
    a153:	0f 84 8a fb ff ff    	je     9ce3 <fwp_main_thread+0x1c3>
    a159:	48 39 c8             	cmp    %rcx,%rax
    a15c:	48 89 ce             	mov    %rcx,%rsi
    a15f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a166:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    a16a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a171:	00 00 00 00 
    a175:	48 0f 4e f0          	cmovle %rax,%rsi
    a179:	48 85 c0             	test   %rax,%rax
    a17c:	48 89 c8             	mov    %rcx,%rax
    a17f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    a186:	48 0f 45 c6          	cmovne %rsi,%rax
    a18a:	48 85 d2             	test   %rdx,%rdx
    a18d:	74 07                	je     a196 <fwp_main_thread+0x676>
    a18f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    a196:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a19a:	e9 76 fb ff ff       	jmp    9d15 <fwp_main_thread+0x1f5>
    a19f:	90                   	nop
    a1a0:	48 89 cb             	mov    %rcx,%rbx
    a1a3:	e9 09 fb ff ff       	jmp    9cb1 <fwp_main_thread+0x191>
    a1a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1af:	00 
    a1b0:	48 8b 45 40          	mov    0x40(%rbp),%rax
    a1b4:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    a1bb:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    a1c2:	00 00 00 00 
    a1c6:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    a1cd:	48 85 c0             	test   %rax,%rax
    a1d0:	0f 84 fb 19 00 00    	je     bbd1 <fwp_main_thread+0x20b1>
    a1d6:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    a1dd:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a1e1:	e9 63 fb ff ff       	jmp    9d49 <fwp_main_thread+0x229>
    a1e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1ed:	00 00 00 
    a1f0:	48 89 01             	mov    %rax,(%rcx)
    a1f3:	e9 8b fb ff ff       	jmp    9d83 <fwp_main_thread+0x263>
    a1f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a1ff:	00 
    a200:	48 89 05 d1 f5 05 00 	mov    %rax,0x5f5d1(%rip)        # 697d8 <fwp_timers>
    a207:	e9 c8 fb ff ff       	jmp    9dd4 <fwp_main_thread+0x2b4>
    a20c:	0f 1f 40 00          	nopl   0x0(%rax)
    a210:	48 89 c2             	mov    %rax,%rdx
    a213:	83 e0 01             	and    $0x1,%eax
    a216:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a21a:	48 d1 ea             	shr    $1,%rdx
    a21d:	48 09 c2             	or     %rax,%rdx
    a220:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    a225:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    a229:	e9 31 fa ff ff       	jmp    9c5f <fwp_main_thread+0x13f>
    a22e:	66 90                	xchg   %ax,%ax
    a230:	48 89 c2             	mov    %rax,%rdx
    a233:	83 e0 01             	and    $0x1,%eax
    a236:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a23a:	48 d1 ea             	shr    $1,%rdx
    a23d:	48 09 c2             	or     %rax,%rdx
    a240:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    a245:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    a249:	e9 e5 fd ff ff       	jmp    a033 <fwp_main_thread+0x513>
    a24e:	48 8d 05 1b df ff ff 	lea    -0x20e5(%rip),%rax        # 8170 <fwp_drop1>
    a255:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a259:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    a25e:	45 31 f6             	xor    %r14d,%r14d
    a261:	66 48 0f 6e d8       	movq   %rax,%xmm3
    a266:	48 8b 05 4b 12 06 00 	mov    0x6124b(%rip),%rax        # 6b4b8 <fwp_cleanups>
    a26d:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
    a274:	00 00 00 00 00 
    a279:	bd ff 01 00 00       	mov    $0x1ff,%ebp
    a27e:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    a282:	4c 8d 25 97 f5 05 00 	lea    0x5f597(%rip),%r12        # 69820 <fwp_heap>
    a289:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    a290:	00 
    a291:	48 8d 05 38 99 ff ff 	lea    -0x66c8(%rip),%rax        # 3bd0 <fwp_range_release>
    a298:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    a29f:	00 
    a2a0:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    a2a5:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    a2ac:	00 
    a2ad:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a2b4:	00 
    a2b5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    a2ba:	48 89 05 f7 11 06 00 	mov    %rax,0x611f7(%rip)        # 6b4b8 <fwp_cleanups>
    a2c1:	eb 45                	jmp    a308 <fwp_main_thread+0x7e8>
    a2c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a2c8:	80 f9 01             	cmp    $0x1,%cl
    a2cb:	75 29                	jne    a2f6 <fwp_main_thread+0x7d6>
    a2cd:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a2d0:	0f b7 c0             	movzwl %ax,%eax
    a2d3:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a2d6:	48 0f af c1          	imul   %rcx,%rax
    a2da:	48 c1 e8 20          	shr    $0x20,%rax
    a2de:	48 39 d0             	cmp    %rdx,%rax
    a2e1:	73 13                	jae    a2f6 <fwp_main_thread+0x7d6>
    a2e3:	49 01 c5             	add    %rax,%r13
    a2e6:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a2eb:	0f 84 91 19 00 00    	je     bc82 <fwp_main_thread+0x2162>
    a2f1:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a2f6:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    a2fd:	00 
    a2fe:	48 83 ed 01          	sub    $0x1,%rbp
    a302:	0f 82 88 00 00 00    	jb     a390 <fwp_main_thread+0x870>
    a308:	48 89 de             	mov    %rbx,%rsi
    a30b:	bf 01 00 00 00       	mov    $0x1,%edi
    a310:	4c 89 b4 24 48 01 00 	mov    %r14,0x148(%rsp)
    a317:	00 
    a318:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
    a31f:	00 
    a320:	48 89 ac 24 40 01 00 	mov    %rbp,0x140(%rsp)
    a327:	00 
    a328:	e8 d3 bd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a32d:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a334:	00 
    a335:	49 89 c6             	mov    %rax,%r14
    a338:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    a33f:	00 
    a340:	48 c1 e2 10          	shl    $0x10,%rdx
    a344:	48 39 d0             	cmp    %rdx,%rax
    a347:	73 ad                	jae    a2f6 <fwp_main_thread+0x7d6>
    a349:	48 89 c2             	mov    %rax,%rdx
    a34c:	48 c1 ea 10          	shr    $0x10,%rdx
    a350:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a354:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a35b:	00 
    a35c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a360:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a364:	4d 85 ed             	test   %r13,%r13
    a367:	74 8d                	je     a2f6 <fwp_main_thread+0x7d6>
    a369:	0f b6 0a             	movzbl (%rdx),%ecx
    a36c:	80 f9 02             	cmp    $0x2,%cl
    a36f:	0f 85 53 ff ff ff    	jne    a2c8 <fwp_main_thread+0x7a8>
    a375:	66 85 c0             	test   %ax,%ax
    a378:	0f 84 68 ff ff ff    	je     a2e6 <fwp_main_thread+0x7c6>
    a37e:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    a385:	00 
    a386:	48 83 ed 01          	sub    $0x1,%rbp
    a38a:	0f 83 78 ff ff ff    	jae    a308 <fwp_main_thread+0x7e8>
    a390:	48 8b 9c 24 b0 00 00 	mov    0xb0(%rsp),%rbx
    a397:	00 
    a398:	66 0f 6f 05 70 3a 00 	movdqa 0x3a70(%rip),%xmm0        # de10 <msg.4+0xd0>
    a39f:	00 
    a3a0:	bf 01 00 00 00       	mov    $0x1,%edi
    a3a5:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    a3ac:	00 
    a3ad:	48 89 1d 04 11 06 00 	mov    %rbx,0x61104(%rip)        # 6b4b8 <fwp_cleanups>
    a3b4:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
    a3bb:	00 
    a3bc:	e8 3f bd ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a3c1:	48 8b 15 30 08 06 00 	mov    0x60830(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    a3c8:	49 89 c5             	mov    %rax,%r13
    a3cb:	48 2b 05 fe 07 06 00 	sub    0x607fe(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    a3d2:	48 c1 e2 10          	shl    $0x10,%rdx
    a3d6:	48 39 d0             	cmp    %rdx,%rax
    a3d9:	73 57                	jae    a432 <fwp_main_thread+0x912>
    a3db:	48 89 c2             	mov    %rax,%rdx
    a3de:	48 c1 ea 10          	shr    $0x10,%rdx
    a3e2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a3e6:	48 8b 15 2b 08 06 00 	mov    0x6082b(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    a3ed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3f1:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a3f5:	48 85 ed             	test   %rbp,%rbp
    a3f8:	74 38                	je     a432 <fwp_main_thread+0x912>
    a3fa:	0f b6 0a             	movzbl (%rdx),%ecx
    a3fd:	80 f9 02             	cmp    $0x2,%cl
    a400:	0f 84 50 18 00 00    	je     bc56 <fwp_main_thread+0x2136>
    a406:	80 f9 01             	cmp    $0x1,%cl
    a409:	75 27                	jne    a432 <fwp_main_thread+0x912>
    a40b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a40e:	0f b7 c0             	movzwl %ax,%eax
    a411:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a414:	48 0f af c1          	imul   %rcx,%rax
    a418:	48 c1 e8 20          	shr    $0x20,%rax
    a41c:	48 39 d0             	cmp    %rdx,%rax
    a41f:	73 11                	jae    a432 <fwp_main_thread+0x912>
    a421:	48 01 c5             	add    %rax,%rbp
    a424:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a428:	0f 84 3c 1a 00 00    	je     be6a <fwp_main_thread+0x234a>
    a42e:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a432:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a439:	00 f0 3f 
    a43c:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    a443:	00 
    a444:	bf 01 00 00 00       	mov    $0x1,%edi
    a449:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    a450:	00 
    a451:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    a458:	00 
    a459:	e8 a2 bc ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a45e:	48 8b 15 93 07 06 00 	mov    0x60793(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    a465:	49 89 c5             	mov    %rax,%r13
    a468:	48 2b 05 61 07 06 00 	sub    0x60761(%rip),%rax        # 6abd0 <fwp_heap+0x13b0>
    a46f:	48 c1 e2 10          	shl    $0x10,%rdx
    a473:	48 39 d0             	cmp    %rdx,%rax
    a476:	73 57                	jae    a4cf <fwp_main_thread+0x9af>
    a478:	48 89 c2             	mov    %rax,%rdx
    a47b:	48 c1 ea 10          	shr    $0x10,%rdx
    a47f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a483:	48 8b 15 8e 07 06 00 	mov    0x6078e(%rip),%rdx        # 6ac18 <fwp_heap+0x13f8>
    a48a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a48e:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a492:	48 85 ed             	test   %rbp,%rbp
    a495:	74 38                	je     a4cf <fwp_main_thread+0x9af>
    a497:	0f b6 0a             	movzbl (%rdx),%ecx
    a49a:	80 f9 02             	cmp    $0x2,%cl
    a49d:	0f 84 a5 17 00 00    	je     bc48 <fwp_main_thread+0x2128>
    a4a3:	80 f9 01             	cmp    $0x1,%cl
    a4a6:	75 27                	jne    a4cf <fwp_main_thread+0x9af>
    a4a8:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4ab:	0f b7 c0             	movzwl %ax,%eax
    a4ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4b1:	48 0f af c1          	imul   %rcx,%rax
    a4b5:	48 c1 e8 20          	shr    $0x20,%rax
    a4b9:	48 39 d0             	cmp    %rdx,%rax
    a4bc:	73 11                	jae    a4cf <fwp_main_thread+0x9af>
    a4be:	48 01 c5             	add    %rax,%rbp
    a4c1:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a4c5:	0f 84 ac 19 00 00    	je     be77 <fwp_main_thread+0x2357>
    a4cb:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a4cf:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a4d6:	33 f3 bf 
    a4d9:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
    a4e0:	00 
    a4e1:	bf 01 00 00 00       	mov    $0x1,%edi
    a4e6:	4c 89 ac 24 18 01 00 	mov    %r13,0x118(%rsp)
    a4ed:	00 
    a4ee:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
    a4f5:	00 
    a4f6:	e8 05 bc ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    a4fb:	48 8b 15 f6 06 06 00 	mov    0x606f6(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    a502:	48 8b 0d c7 06 06 00 	mov    0x606c7(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    a509:	48 89 04 24          	mov    %rax,(%rsp)
    a50d:	48 89 d6             	mov    %rdx,%rsi
    a510:	48 29 c8             	sub    %rcx,%rax
    a513:	48 c1 e6 10          	shl    $0x10,%rsi
    a517:	48 39 f0             	cmp    %rsi,%rax
    a51a:	73 67                	jae    a583 <fwp_main_thread+0xa63>
    a51c:	48 89 c6             	mov    %rax,%rsi
    a51f:	48 c1 ee 10          	shr    $0x10,%rsi
    a523:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a527:	48 8b 35 ea 06 06 00 	mov    0x606ea(%rip),%rsi        # 6ac18 <fwp_heap+0x13f8>
    a52e:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a532:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
    a536:	48 85 ed             	test   %rbp,%rbp
    a539:	74 48                	je     a583 <fwp_main_thread+0xa63>
    a53b:	0f b6 3e             	movzbl (%rsi),%edi
    a53e:	40 80 ff 02          	cmp    $0x2,%dil
    a542:	0f 84 1c 17 00 00    	je     bc64 <fwp_main_thread+0x2144>
    a548:	40 80 ff 01          	cmp    $0x1,%dil
    a54c:	75 35                	jne    a583 <fwp_main_thread+0xa63>
    a54e:	8b 7e 18             	mov    0x18(%rsi),%edi
    a551:	0f b7 c0             	movzwl %ax,%eax
    a554:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a557:	48 0f af c7          	imul   %rdi,%rax
    a55b:	48 c1 e8 20          	shr    $0x20,%rax
    a55f:	48 39 f0             	cmp    %rsi,%rax
    a562:	73 1f                	jae    a583 <fwp_main_thread+0xa63>
    a564:	48 01 c5             	add    %rax,%rbp
    a567:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    a56b:	0f 84 13 19 00 00    	je     be84 <fwp_main_thread+0x2364>
    a571:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    a575:	48 8b 0d 54 06 06 00 	mov    0x60654(%rip),%rcx        # 6abd0 <fwp_heap+0x13b0>
    a57c:	48 8b 15 75 06 06 00 	mov    0x60675(%rip),%rdx        # 6abf8 <fwp_heap+0x13d8>
    a583:	48 8d 84 24 8c 00 00 	lea    0x8c(%rsp),%rax
    a58a:	00 
    a58b:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
    a590:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    a595:	48 8d 84 24 90 00 00 	lea    0x90(%rsp),%rax
    a59c:	00 
    a59d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    a5a2:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    a5a7:	48 8b 04 24          	mov    (%rsp),%rax
    a5ab:	48 c1 e2 10          	shl    $0x10,%rdx
    a5af:	48 29 c8             	sub    %rcx,%rax
    a5b2:	48 39 d0             	cmp    %rdx,%rax
    a5b5:	0f 83 8a 00 00 00    	jae    a645 <fwp_main_thread+0xb25>
    a5bb:	48 89 c6             	mov    %rax,%rsi
    a5be:	48 c1 ee 10          	shr    $0x10,%rsi
    a5c2:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a5c6:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    a5cd:	00 
    a5ce:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a5d2:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    a5d6:	48 85 ff             	test   %rdi,%rdi
    a5d9:	74 6a                	je     a645 <fwp_main_thread+0xb25>
    a5db:	44 0f b6 06          	movzbl (%rsi),%r8d
    a5df:	41 80 f8 02          	cmp    $0x2,%r8b
    a5e3:	0f 84 87 15 00 00    	je     bb70 <fwp_main_thread+0x2050>
    a5e9:	41 80 f8 01          	cmp    $0x1,%r8b
    a5ed:	75 56                	jne    a645 <fwp_main_thread+0xb25>
    a5ef:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    a5f3:	0f b7 c0             	movzwl %ax,%eax
    a5f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a5f9:	49 0f af c0          	imul   %r8,%rax
    a5fd:	48 c1 e8 20          	shr    $0x20,%rax
    a601:	48 39 f0             	cmp    %rsi,%rax
    a604:	73 3f                	jae    a645 <fwp_main_thread+0xb25>
    a606:	48 01 c7             	add    %rax,%rdi
    a609:	0f b6 07             	movzbl (%rdi),%eax
    a60c:	84 c0                	test   %al,%al
    a60e:	74 35                	je     a645 <fwp_main_thread+0xb25>
    a610:	44 8b 0d d1 0e 06 00 	mov    0x60ed1(%rip),%r9d        # 6b4e8 <iteration_active>
    a617:	45 85 c9             	test   %r9d,%r9d
    a61a:	74 08                	je     a624 <fwp_main_thread+0xb04>
    a61c:	48 83 05 ac 0e 06 00 	addq   $0x1,0x60eac(%rip)        # 6b4d0 <iteration_retains>
    a623:	01 
    a624:	3c fd                	cmp    $0xfd,%al
    a626:	0f 87 c8 17 00 00    	ja     bdf4 <fwp_main_thread+0x22d4>
    a62c:	83 c0 01             	add    $0x1,%eax
    a62f:	88 07                	mov    %al,(%rdi)
    a631:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    a638:	00 
    a639:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    a640:	00 
    a641:	48 c1 e2 10          	shl    $0x10,%rdx
    a645:	48 8d 05 d4 cd ff ff 	lea    -0x322c(%rip),%rax        # 7420 <fwp_tape_scope_release>
    a64c:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
    a653:	00 
    a654:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
    a65b:	00 
    a65c:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a661:	c7 84 24 8c 00 00 00 	movl   $0xffffffff,0x8c(%rsp)
    a668:	ff ff ff ff 
    a66c:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
    a673:	00 
    a674:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    a679:	48 89 05 38 0e 06 00 	mov    %rax,0x60e38(%rip)        # 6b4b8 <fwp_cleanups>
    a680:	48 8d 05 89 69 00 00 	lea    0x6989(%rip),%rax        # 11010 <fc37>
    a687:	48 29 c8             	sub    %rcx,%rax
    a68a:	48 39 d0             	cmp    %rdx,%rax
    a68d:	73 72                	jae    a701 <fwp_main_thread+0xbe1>
    a68f:	48 89 c2             	mov    %rax,%rdx
    a692:	48 c1 ea 10          	shr    $0x10,%rdx
    a696:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a69a:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    a6a1:	00 
    a6a2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a6a6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a6aa:	48 85 ff             	test   %rdi,%rdi
    a6ad:	74 52                	je     a701 <fwp_main_thread+0xbe1>
    a6af:	0f b6 0a             	movzbl (%rdx),%ecx
    a6b2:	80 f9 02             	cmp    $0x2,%cl
    a6b5:	0f 84 95 12 00 00    	je     b950 <fwp_main_thread+0x1e30>
    a6bb:	80 f9 01             	cmp    $0x1,%cl
    a6be:	75 41                	jne    a701 <fwp_main_thread+0xbe1>
    a6c0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a6c3:	0f b7 c0             	movzwl %ax,%eax
    a6c6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a6c9:	48 0f af c1          	imul   %rcx,%rax
    a6cd:	48 c1 e8 20          	shr    $0x20,%rax
    a6d1:	48 39 d0             	cmp    %rdx,%rax
    a6d4:	73 2b                	jae    a701 <fwp_main_thread+0xbe1>
    a6d6:	48 01 c7             	add    %rax,%rdi
    a6d9:	0f b6 07             	movzbl (%rdi),%eax
    a6dc:	84 c0                	test   %al,%al
    a6de:	74 21                	je     a701 <fwp_main_thread+0xbe1>
    a6e0:	44 8b 05 01 0e 06 00 	mov    0x60e01(%rip),%r8d        # 6b4e8 <iteration_active>
    a6e7:	45 85 c0             	test   %r8d,%r8d
    a6ea:	74 08                	je     a6f4 <fwp_main_thread+0xbd4>
    a6ec:	48 83 05 dc 0d 06 00 	addq   $0x1,0x60ddc(%rip)        # 6b4d0 <iteration_retains>
    a6f3:	01 
    a6f4:	3c fd                	cmp    $0xfd,%al
    a6f6:	0f 87 4a 16 00 00    	ja     bd46 <fwp_main_thread+0x2226>
    a6fc:	83 c0 01             	add    $0x1,%eax
    a6ff:	88 07                	mov    %al,(%rdi)
    a701:	48 8d 3d 08 69 00 00 	lea    0x6908(%rip),%rdi        # 11010 <fc37>
    a708:	31 ed                	xor    %ebp,%ebp
    a70a:	e8 91 c9 ff ff       	call   70a0 <fwp_closure_drop>
    a70f:	48 8b 1c 24          	mov    (%rsp),%rbx
    a713:	66 90                	xchg   %ax,%ax
    a715:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a71c:	00 00 00 00 
    a720:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a724:	48 83 c5 01          	add    $0x1,%rbp
    a728:	48 85 db             	test   %rbx,%rbx
    a72b:	75 f3                	jne    a720 <fwp_main_thread+0xc00>
    a72d:	48 81 fd ff ff ff 7f 	cmp    $0x7fffffff,%rbp
    a734:	0f 87 9f 17 00 00    	ja     bed9 <fwp_main_thread+0x23b9>
    a73a:	8b 35 20 69 00 00    	mov    0x6920(%rip),%esi        # 11060 <registered_finish.1>
    a740:	85 f6                	test   %esi,%esi
    a742:	0f 84 d0 11 00 00    	je     b918 <fwp_main_thread+0x1df8>
    a748:	4c 8b 3d 89 69 01 00 	mov    0x16989(%rip),%r15        # 210d8 <fwp_tape_next_slot>
    a74f:	4c 8b 2d 92 69 01 00 	mov    0x16992(%rip),%r13        # 210e8 <fwp_ntapes>
    a756:	4d 39 fd             	cmp    %r15,%r13
    a759:	0f 8e 29 0e 00 00    	jle    b588 <fwp_main_thread+0x1a68>
    a75f:	49 6b c7 68          	imul   $0x68,%r15,%rax
    a763:	48 03 05 86 69 01 00 	add    0x16986(%rip),%rax        # 210f0 <fwp_tapes>
    a76a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a770:	8b 48 04             	mov    0x4(%rax),%ecx
    a773:	85 c9                	test   %ecx,%ecx
    a775:	75 0c                	jne    a783 <fwp_main_thread+0xc63>
    a777:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    a77d:	0f 86 05 0e 00 00    	jbe    b588 <fwp_main_thread+0x1a68>
    a783:	49 83 c7 01          	add    $0x1,%r15
    a787:	48 83 c0 68          	add    $0x68,%rax
    a78b:	4d 39 fd             	cmp    %r15,%r13
    a78e:	75 e0                	jne    a770 <fwp_main_thread+0xc50>
    a790:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    a797:	0f 8f b3 17 00 00    	jg     bf50 <fwp_main_thread+0x2430>
    a79d:	4c 39 2d 3c 69 01 00 	cmp    %r13,0x1693c(%rip)        # 210e0 <fwp_tapes_cap>
    a7a4:	4c 8b 35 45 69 01 00 	mov    0x16945(%rip),%r14        # 210f0 <fwp_tapes>
    a7ab:	75 42                	jne    a7ef <fwp_main_thread+0xccf>
    a7ad:	4d 85 ed             	test   %r13,%r13
    a7b0:	0f 84 24 14 00 00    	je     bbda <fwp_main_thread+0x20ba>
    a7b6:	4f 8d 7c 2d 00       	lea    0x0(%r13,%r13,1),%r15
    a7bb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    a7c0:	49 39 c7             	cmp    %rax,%r15
    a7c3:	4c 0f 4f f8          	cmovg  %rax,%r15
    a7c7:	49 6b f7 68          	imul   $0x68,%r15,%rsi
    a7cb:	4c 89 f7             	mov    %r14,%rdi
    a7ce:	31 d2                	xor    %edx,%edx
    a7d0:	e8 ab a9 ff ff       	call   5180 <ad_raw_realloc>
    a7d5:	49 89 c6             	mov    %rax,%r14
    a7d8:	48 85 c0             	test   %rax,%rax
    a7db:	0f 84 1d 17 00 00    	je     befe <fwp_main_thread+0x23de>
    a7e1:	48 89 05 08 69 01 00 	mov    %rax,0x16908(%rip)        # 210f0 <fwp_tapes>
    a7e8:	4c 89 3d f1 68 01 00 	mov    %r15,0x168f1(%rip)        # 210e0 <fwp_tapes_cap>
    a7ef:	49 6b c5 68          	imul   $0x68,%r13,%rax
    a7f3:	4d 89 ef             	mov    %r13,%r15
    a7f6:	4c 01 f0             	add    %r14,%rax
    a7f9:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a7fd:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a804:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    a808:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    a80f:	00 
    a810:	48 29 f8             	sub    %rdi,%rax
    a813:	8d 48 68             	lea    0x68(%rax),%ecx
    a816:	31 c0                	xor    %eax,%eax
    a818:	c1 e9 03             	shr    $0x3,%ecx
    a81b:	f3 48 ab             	rep stos %rax,(%rdi)
    a81e:	49 8d 45 01          	lea    0x1(%r13),%rax
    a822:	48 89 05 bf 68 01 00 	mov    %rax,0x168bf(%rip)        # 210e8 <fwp_ntapes>
    a829:	4d 6b ef 68          	imul   $0x68,%r15,%r13
    a82d:	66 48 0f 6e c5       	movq   %rbp,%xmm0
    a832:	48 8d 3d 27 29 00 00 	lea    0x2927(%rip),%rdi        # d160 <_IO_stdin_used+0x160>
    a839:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    a83d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    a842:	4d 01 f5             	add    %r14,%r13
    a845:	49 c7 45 60 00 00 00 	movq   $0x0,0x60(%r13)
    a84c:	00 
    a84d:	e8 3e 8b ff ff       	call   3390 <getenv@plt>
    a852:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    a858:	48 85 c0             	test   %rax,%rax
    a85b:	0f 84 3f 0d 00 00    	je     b5a0 <fwp_main_thread+0x1a80>
    a861:	80 38 30             	cmpb   $0x30,(%rax)
    a864:	0f 85 36 0d 00 00    	jne    b5a0 <fwp_main_thread+0x1a80>
    a86a:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    a86e:	0f 85 2c 0d 00 00    	jne    b5a0 <fwp_main_thread+0x1a80>
    a874:	41 8b 45 00          	mov    0x0(%r13),%eax
    a878:	49 8d 6f 01          	lea    0x1(%r15),%rbp
    a87c:	41 c7 45 04 01 00 00 	movl   $0x1,0x4(%r13)
    a883:	00 
    a884:	48 89 2d 4d 68 01 00 	mov    %rbp,0x1684d(%rip)        # 210d8 <fwp_tape_next_slot>
    a88b:	8d 50 01             	lea    0x1(%rax),%edx
    a88e:	48 8b 05 cb 34 00 00 	mov    0x34cb(%rip),%rax        # dd60 <msg.4+0x20>
    a895:	41 0f 11 45 08       	movups %xmm0,0x8(%r13)
    a89a:	41 89 55 00          	mov    %edx,0x0(%r13)
    a89e:	49 89 45 58          	mov    %rax,0x58(%r13)
    a8a2:	48 8b 05 0f 0c 06 00 	mov    0x60c0f(%rip),%rax        # 6b4b8 <fwp_cleanups>
    a8a9:	49 c7 45 50 00 00 00 	movq   $0x0,0x50(%r13)
    a8b0:	00 
    a8b1:	48 85 c0             	test   %rax,%rax
    a8b4:	75 16                	jne    a8cc <fwp_main_thread+0xdac>
    a8b6:	e9 a5 16 00 00       	jmp    bf60 <fwp_main_thread+0x2440>
    a8bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a8c0:	48 8b 00             	mov    (%rax),%rax
    a8c3:	48 85 c0             	test   %rax,%rax
    a8c6:	0f 84 94 16 00 00    	je     bf60 <fwp_main_thread+0x2440>
    a8cc:	48 8d 3d 4d cb ff ff 	lea    -0x34b3(%rip),%rdi        # 7420 <fwp_tape_scope_release>
    a8d3:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    a8d7:	75 e7                	jne    a8c0 <fwp_main_thread+0xda0>
    a8d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    a8dd:	44 89 f9             	mov    %r15d,%ecx
    a8e0:	48 63 06             	movslq (%rsi),%rax
    a8e3:	49 89 75 50          	mov    %rsi,0x50(%r13)
    a8e7:	41 89 45 5c          	mov    %eax,0x5c(%r13)
    a8eb:	85 c0                	test   %eax,%eax
    a8ed:	78 09                	js     a8f8 <fwp_main_thread+0xdd8>
    a8ef:	48 6b c0 68          	imul   $0x68,%rax,%rax
    a8f3:	45 89 7c 06 58       	mov    %r15d,0x58(%r14,%rax,1)
    a8f8:	89 0e                	mov    %ecx,(%rsi)
    a8fa:	48 8b 04 24          	mov    (%rsp),%rax
    a8fe:	66 90                	xchg   %ax,%ax
    a900:	48 8b 40 10          	mov    0x10(%rax),%rax
    a904:	48 83 c3 01          	add    $0x1,%rbx
    a908:	48 85 c0             	test   %rax,%rax
    a90b:	75 f3                	jne    a900 <fwp_main_thread+0xde0>
    a90d:	4c 8b 34 24          	mov    (%rsp),%r14
    a911:	0f 1f 40 00          	nopl   0x0(%rax)
    a915:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a91c:	00 00 00 00 
    a920:	4d 8b 76 10          	mov    0x10(%r14),%r14
    a924:	48 83 c0 01          	add    $0x1,%rax
    a928:	4d 85 f6             	test   %r14,%r14
    a92b:	75 f3                	jne    a920 <fwp_main_thread+0xe00>
    a92d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    a934:	ff ff 1f 
    a937:	48 39 c1             	cmp    %rax,%rcx
    a93a:	0f 82 8d 15 00 00    	jb     becd <fwp_main_thread+0x23ad>
    a940:	48 85 db             	test   %rbx,%rbx
    a943:	0f 8e 47 0e 00 00    	jle    b790 <fwp_main_thread+0x1c70>
    a949:	48 39 c3             	cmp    %rax,%rbx
    a94c:	48 0f 47 d8          	cmova  %rax,%rbx
    a950:	48 89 d8             	mov    %rbx,%rax
    a953:	48 c1 e8 3c          	shr    $0x3c,%rax
    a957:	0f 85 70 15 00 00    	jne    becd <fwp_main_thread+0x23ad>
    a95d:	4c 8d 2c 1b          	lea    (%rbx,%rbx,1),%r13
    a961:	48 c1 e2 10          	shl    $0x10,%rdx
    a965:	be 02 00 00 00       	mov    $0x2,%esi
    a96a:	48 09 ea             	or     %rbp,%rdx
    a96d:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    a974:	00 
    a975:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    a97a:	e8 91 b5 ff ff       	call   5f10 <fwp_heap_alloc>
    a97f:	4c 89 28             	mov    %r13,(%rax)
    a982:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    a989:	00 
    a98a:	48 89 c5             	mov    %rax,%rbp
    a98d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    a994:	00 
    a995:	48 c1 e1 10          	shl    $0x10,%rcx
    a999:	48 39 c8             	cmp    %rcx,%rax
    a99c:	0f 83 ee 10 00 00    	jae    ba90 <fwp_main_thread+0x1f70>
    a9a2:	48 89 c1             	mov    %rax,%rcx
    a9a5:	48 c1 e9 10          	shr    $0x10,%rcx
    a9a9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a9ad:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    a9b4:	00 
    a9b5:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a9b9:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    a9bd:	4d 85 ed             	test   %r13,%r13
    a9c0:	74 3c                	je     a9fe <fwp_main_thread+0xede>
    a9c2:	0f b6 31             	movzbl (%rcx),%esi
    a9c5:	40 80 fe 02          	cmp    $0x2,%sil
    a9c9:	0f 84 36 0e 00 00    	je     b805 <fwp_main_thread+0x1ce5>
    a9cf:	40 80 fe 01          	cmp    $0x1,%sil
    a9d3:	75 29                	jne    a9fe <fwp_main_thread+0xede>
    a9d5:	8b 71 18             	mov    0x18(%rcx),%esi
    a9d8:	0f b7 c0             	movzwl %ax,%eax
    a9db:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a9de:	48 0f af c6          	imul   %rsi,%rax
    a9e2:	48 c1 e8 20          	shr    $0x20,%rax
    a9e6:	48 39 c8             	cmp    %rcx,%rax
    a9e9:	73 13                	jae    a9fe <fwp_main_thread+0xede>
    a9eb:	49 01 c5             	add    %rax,%r13
    a9ee:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a9f3:	0f 84 20 0e 00 00    	je     b819 <fwp_main_thread+0x1cf9>
    a9f9:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a9fe:	48 85 db             	test   %rbx,%rbx
    aa01:	74 70                	je     aa73 <fwp_main_thread+0xf53>
    aa03:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    aa08:	48 8b 0c 24          	mov    (%rsp),%rcx
    aa0c:	31 c0                	xor    %eax,%eax
    aa0e:	48 c1 e6 20          	shl    $0x20,%rsi
    aa12:	66 90                	xchg   %ax,%ax
    aa14:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa1b:	00 00 00 00 
    aa1f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa26:	00 00 00 00 
    aa2a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa31:	00 00 00 00 
    aa35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa3c:	00 00 00 00 
    aa40:	48 89 c2             	mov    %rax,%rdx
    aa43:	f3 0f 7e 41 08       	movq   0x8(%rcx),%xmm0
    aa48:	48 01 f2             	add    %rsi,%rdx
    aa4b:	0f 80 77 14 00 00    	jo     bec8 <fwp_main_thread+0x23a8>
    aa51:	66 48 0f 6e e2       	movq   %rdx,%xmm4
    aa56:	48 89 c2             	mov    %rax,%rdx
    aa59:	48 83 c0 01          	add    $0x1,%rax
    aa5d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    aa61:	48 c1 e2 04          	shl    $0x4,%rdx
    aa65:	0f 11 44 15 08       	movups %xmm0,0x8(%rbp,%rdx,1)
    aa6a:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    aa6e:	48 39 d8             	cmp    %rbx,%rax
    aa71:	72 cd                	jb     aa40 <fwp_main_thread+0xf20>
    aa73:	48 8b 45 00          	mov    0x0(%rbp),%rax
    aa77:	48 d1 e8             	shr    $1,%rax
    aa7a:	0f 85 80 0c 00 00    	jne    b700 <fwp_main_thread+0x1be0>
    aa80:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
    aa87:	00 
    aa88:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    aa8f:	90                   	nop
    aa90:	48 89 ef             	mov    %rbp,%rdi
    aa93:	e8 d8 d8 ff ff       	call   8370 <fwp_drop10>
    aa98:	4c 63 6c 24 20       	movslq 0x20(%rsp),%r13
    aa9d:	4c 89 ef             	mov    %r13,%rdi
    aaa0:	e8 8b 9c ff ff       	call   4730 <fwp_tape_of>
    aaa5:	48 89 c6             	mov    %rax,%rsi
    aaa8:	48 8b 40 60          	mov    0x60(%rax),%rax
    aaac:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    aab1:	48 85 c0             	test   %rax,%rax
    aab4:	0f 85 8a 14 00 00    	jne    bf44 <fwp_main_thread+0x2424>
    aaba:	48 89 f7             	mov    %rsi,%rdi
    aabd:	e8 ce 91 ff ff       	call   3c90 <fwp_tape_unlink_scope>
    aac2:	48 8b 5e 48          	mov    0x48(%rsi),%rbx
    aac6:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    aacb:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    aad2:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
    aad6:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    aada:	66 48 0f 6e fb       	movq   %rbx,%xmm7
    aadf:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    aae4:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    aae9:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    aaed:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    aaf1:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    aaf7:	77 1a                	ja     ab13 <fwp_main_thread+0xff3>
    aaf9:	0f b7 44 24 20       	movzwl 0x20(%rsp),%eax
    aafe:	83 e8 01             	sub    $0x1,%eax
    ab01:	48 98                	cltq
    ab03:	48 3b 05 ce 65 01 00 	cmp    0x165ce(%rip),%rax        # 210d8 <fwp_tape_next_slot>
    ab0a:	7d 07                	jge    ab13 <fwp_main_thread+0xff3>
    ab0c:	48 89 05 c5 65 01 00 	mov    %rax,0x165c5(%rip)        # 210d8 <fwp_tape_next_slot>
    ab13:	48 8b 05 9e 09 06 00 	mov    0x6099e(%rip),%rax        # 6b4b8 <fwp_cleanups>
    ab1a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ab1e:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    ab25:	00 
    ab26:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    ab2d:	00 
    ab2e:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    ab35:	00 
    ab36:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    ab3a:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    ab3e:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    ab42:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    ab49:	00 
    ab4a:	48 8d 05 0f a7 ff ff 	lea    -0x58f1(%rip),%rax        # 5260 <fwp_tape_buffers_release>
    ab51:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
    ab58:	00 
    ab59:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    ab5e:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    ab65:	00 
    ab66:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    ab6d:	00 
    ab6e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    ab73:	0f 29 9c 24 d0 00 00 	movaps %xmm3,0xd0(%rsp)
    ab7a:	00 
    ab7b:	48 89 05 36 09 06 00 	mov    %rax,0x60936(%rip)        # 6b4b8 <fwp_cleanups>
    ab82:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
    ab89:	00 
    ab8a:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
    ab91:	00 
    ab92:	4d 85 ff             	test   %r15,%r15
    ab95:	0f 88 c5 0d 00 00    	js     b960 <fwp_main_thread+0x1e40>
    ab9b:	4c 89 f8             	mov    %r15,%rax
    ab9e:	48 c1 f8 20          	sar    $0x20,%rax
    aba2:	49 39 c5             	cmp    %rax,%r13
    aba5:	0f 85 05 13 00 00    	jne    beb0 <fwp_main_thread+0x2390>
    abab:	44 89 f9             	mov    %r15d,%ecx
    abae:	49 89 cd             	mov    %rcx,%r13
    abb1:	48 39 ca             	cmp    %rcx,%rdx
    abb4:	0f 8e a4 12 00 00    	jle    be5e <fwp_main_thread+0x233e>
    abba:	49 39 c9             	cmp    %rcx,%r9
    abbd:	0f 8e 6d 0c 00 00    	jle    b830 <fwp_main_thread+0x1d10>
    abc3:	49 39 d9             	cmp    %rbx,%r9
    abc6:	0f 8f a4 0c 00 00    	jg     b870 <fwp_main_thread+0x1d50>
    abcc:	4d 85 c0             	test   %r8,%r8
    abcf:	0f 84 10 13 00 00    	je     bee5 <fwp_main_thread+0x23c5>
    abd5:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    abda:	4d 8d 69 ff          	lea    -0x1(%r9),%r13
    abde:	31 f6                	xor    %esi,%esi
    abe0:	4c 89 c7             	mov    %r8,%rdi
    abe3:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    abe8:	4a 8d 14 cd 00 00 00 	lea    0x0(,%r9,8),%rdx
    abef:	00 
    abf0:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    abf5:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    abfa:	e8 b1 88 ff ff       	call   34b0 <memset@plt>
    abff:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    ac04:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    ac0a:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    ac10:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
    ac15:	49 89 c0             	mov    %rax,%r8
    ac18:	f2 0f 10 05 48 31 00 	movsd  0x3148(%rip),%xmm0        # dd68 <msg.4+0x28>
    ac1f:	00 
    ac20:	f2 41 0f 58 04 c8    	addsd  (%r8,%rcx,8),%xmm0
    ac26:	f2 41 0f 11 04 c8    	movsd  %xmm0,(%r8,%rcx,8)
    ac2c:	4d 39 e9             	cmp    %r13,%r9
    ac2f:	0f 8f 8c 00 00 00    	jg     acc1 <fwp_main_thread+0x11a1>
    ac35:	0f 12 fb             	movhlps %xmm3,%xmm7
    ac38:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    ac3d:	0f 12 da             	movhlps %xmm2,%xmm3
    ac40:	4d 29 cd             	sub    %r9,%r13
    ac43:	66 49 0f 7e da       	movq   %xmm3,%r10
    ac48:	66 48 0f 7e fe       	movq   %xmm7,%rsi
    ac4d:	66 48 0f 7e d7       	movq   %xmm2,%rdi
    ac52:	4f 8d 1c c8          	lea    (%r8,%r9,8),%r11
    ac56:	4b 8d 14 ea          	lea    (%r10,%r13,8),%rdx
    ac5a:	66 0f ef d2          	pxor   %xmm2,%xmm2
    ac5e:	48 29 f1             	sub    %rsi,%rcx
    ac61:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    ac65:	4d 29 d3             	sub    %r10,%r11
    ac68:	4c 29 d7             	sub    %r10,%rdi
    ac6b:	eb 07                	jmp    ac74 <fwp_main_thread+0x1154>
    ac6d:	0f 1f 00             	nopl   (%rax)
    ac70:	48 83 e8 04          	sub    $0x4,%rax
    ac74:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    ac7a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    ac7e:	7a 02                	jp     ac82 <fwp_main_thread+0x1162>
    ac80:	74 36                	je     acb8 <fwp_main_thread+0x1198>
    ac82:	4c 63 14 01          	movslq (%rcx,%rax,1),%r10
    ac86:	45 85 d2             	test   %r10d,%r10d
    ac89:	78 15                	js     aca0 <fwp_main_thread+0x1180>
    ac8b:	f2 0f 10 0c 17       	movsd  (%rdi,%rdx,1),%xmm1
    ac90:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    ac94:	f2 43 0f 58 0c d0    	addsd  (%r8,%r10,8),%xmm1
    ac9a:	f2 43 0f 11 0c d0    	movsd  %xmm1,(%r8,%r10,8)
    aca0:	4c 63 10             	movslq (%rax),%r10
    aca3:	45 85 d2             	test   %r10d,%r10d
    aca6:	78 10                	js     acb8 <fwp_main_thread+0x1198>
    aca8:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    acac:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    acb2:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    acb8:	48 83 ea 08          	sub    $0x8,%rdx
    acbc:	48 39 f0             	cmp    %rsi,%rax
    acbf:	75 af                	jne    ac70 <fwp_main_thread+0x1150>
    acc1:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    acc8:	ff ff 1f 
    accb:	4c 39 c8             	cmp    %r9,%rax
    acce:	0f 82 58 12 00 00    	jb     bf2c <fwp_main_thread+0x240c>
    acd4:	4a 8d 3c cd 08 00 00 	lea    0x8(,%r9,8),%rdi
    acdb:	00 
    acdc:	be 02 00 00 00       	mov    $0x2,%esi
    ace1:	4c 89 44 24 30       	mov    %r8,0x30(%rsp)
    ace6:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    aceb:	e8 20 b2 ff ff       	call   5f10 <fwp_heap_alloc>
    acf0:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    acf5:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
    acfa:	48 89 c3             	mov    %rax,%rbx
    acfd:	4c 89 08             	mov    %r9,(%rax)
    ad00:	31 c0                	xor    %eax,%eax
    ad02:	4d 85 c9             	test   %r9,%r9
    ad05:	74 2b                	je     ad32 <fwp_main_thread+0x1212>
    ad07:	0f 1f 00             	nopl   (%rax)
    ad0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad11:	00 00 00 00 
    ad15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    ad1c:	00 00 00 00 
    ad20:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    ad24:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    ad29:	48 83 c0 01          	add    $0x1,%rax
    ad2d:	49 39 c1             	cmp    %rax,%r9
    ad30:	75 ee                	jne    ad20 <fwp_main_thread+0x1200>
    ad32:	48 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%rbp
    ad39:	00 
    ad3a:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    ad3f:	48 89 2d 72 07 06 00 	mov    %rbp,0x60772(%rip)        # 6b4b8 <fwp_cleanups>
    ad46:	e8 15 a5 ff ff       	call   5260 <fwp_tape_buffers_release>
    ad4b:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ad52:	00 
    ad53:	48 89 d8             	mov    %rbx,%rax
    ad56:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    ad5d:	00 
    ad5e:	48 c1 e2 10          	shl    $0x10,%rdx
    ad62:	48 39 d0             	cmp    %rdx,%rax
    ad65:	73 5a                	jae    adc1 <fwp_main_thread+0x12a1>
    ad67:	48 89 c2             	mov    %rax,%rdx
    ad6a:	48 c1 ea 10          	shr    $0x10,%rdx
    ad6e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ad72:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    ad79:	00 
    ad7a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ad7e:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    ad82:	4d 85 ed             	test   %r13,%r13
    ad85:	74 3a                	je     adc1 <fwp_main_thread+0x12a1>
    ad87:	0f b6 0a             	movzbl (%rdx),%ecx
    ad8a:	80 f9 02             	cmp    $0x2,%cl
    ad8d:	0f 84 fd 0b 00 00    	je     b990 <fwp_main_thread+0x1e70>
    ad93:	80 f9 01             	cmp    $0x1,%cl
    ad96:	75 29                	jne    adc1 <fwp_main_thread+0x12a1>
    ad98:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ad9b:	0f b7 c0             	movzwl %ax,%eax
    ad9e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ada1:	48 0f af c1          	imul   %rcx,%rax
    ada5:	48 c1 e8 20          	shr    $0x20,%rax
    ada9:	48 39 d0             	cmp    %rdx,%rax
    adac:	73 13                	jae    adc1 <fwp_main_thread+0x12a1>
    adae:	49 01 c5             	add    %rax,%r13
    adb1:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    adb6:	0f 84 e8 0b 00 00    	je     b9a4 <fwp_main_thread+0x1e84>
    adbc:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    adc1:	48 3b 6c 24 48       	cmp    0x48(%rsp),%rbp
    adc6:	0f 85 7f 89 ff ff    	jne    374b <fwp_main_thread.cold>
    adcc:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
    add3:	00 
    add4:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    add9:	48 89 05 d8 06 06 00 	mov    %rax,0x606d8(%rip)        # 6b4b8 <fwp_cleanups>
    ade0:	e8 3b c6 ff ff       	call   7420 <fwp_tape_scope_release>
    ade5:	48 8b 03             	mov    (%rbx),%rax
    ade8:	49 89 c5             	mov    %rax,%r13
    adeb:	49 0f ba f5 3f       	btr    $0x3f,%r13
    adf0:	48 85 c0             	test   %rax,%rax
    adf3:	0f 88 37 08 00 00    	js     b630 <fwp_main_thread+0x1b10>
    adf9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ae00:	00 
    ae01:	48 89 d8             	mov    %rbx,%rax
    ae04:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    ae0b:	00 
    ae0c:	48 c1 e2 10          	shl    $0x10,%rdx
    ae10:	48 39 d0             	cmp    %rdx,%rax
    ae13:	0f 83 17 08 00 00    	jae    b630 <fwp_main_thread+0x1b10>
    ae19:	48 89 c2             	mov    %rax,%rdx
    ae1c:	48 c1 ea 10          	shr    $0x10,%rdx
    ae20:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ae24:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    ae2b:	00 
    ae2c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ae30:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    ae34:	48 85 c9             	test   %rcx,%rcx
    ae37:	0f 84 f3 07 00 00    	je     b630 <fwp_main_thread+0x1b10>
    ae3d:	0f b6 32             	movzbl (%rdx),%esi
    ae40:	40 80 fe 02          	cmp    $0x2,%sil
    ae44:	0f 84 d6 07 00 00    	je     b620 <fwp_main_thread+0x1b00>
    ae4a:	40 80 fe 01          	cmp    $0x1,%sil
    ae4e:	0f 85 dc 07 00 00    	jne    b630 <fwp_main_thread+0x1b10>
    ae54:	8b 72 18             	mov    0x18(%rdx),%esi
    ae57:	0f b7 c0             	movzwl %ax,%eax
    ae5a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ae5d:	48 0f af c6          	imul   %rsi,%rax
    ae61:	48 c1 e8 20          	shr    $0x20,%rax
    ae65:	48 39 d0             	cmp    %rdx,%rax
    ae68:	0f 83 c2 07 00 00    	jae    b630 <fwp_main_thread+0x1b10>
    ae6e:	48 01 c1             	add    %rax,%rcx
    ae71:	80 39 01             	cmpb   $0x1,(%rcx)
    ae74:	0f 85 b6 07 00 00    	jne    b630 <fwp_main_thread+0x1b10>
    ae7a:	48 89 da             	mov    %rbx,%rdx
    ae7d:	48 89 dd             	mov    %rbx,%rbp
    ae80:	31 ff                	xor    %edi,%edi
    ae82:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
    ae86:	31 c0                	xor    %eax,%eax
    ae88:	4d 85 ed             	test   %r13,%r13
    ae8b:	75 2c                	jne    aeb9 <fwp_main_thread+0x1399>
    ae8d:	eb 61                	jmp    aef0 <fwp_main_thread+0x13d0>
    ae8f:	90                   	nop
    ae90:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    ae94:	0f 88 22 10 00 00    	js     bebc <fwp_main_thread+0x239c>
    ae9a:	f2 0f 10 05 e6 2e 00 	movsd  0x2ee6(%rip),%xmm0        # dd88 <msg.4+0x48>
    aea1:	00 
    aea2:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    aea7:	48 83 c0 01          	add    $0x1,%rax
    aeab:	48 83 c1 08          	add    $0x8,%rcx
    aeaf:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    aeb4:	49 39 c5             	cmp    %rax,%r13
    aeb7:	74 37                	je     aef0 <fwp_main_thread+0x13d0>
    aeb9:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    aebd:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    aec1:	79 cd                	jns    ae90 <fwp_main_thread+0x1370>
    aec3:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    aec7:	eb c7                	jmp    ae90 <fwp_main_thread+0x1370>
    aec9:	e8 02 9f ff ff       	call   4dd0 <fwp_heap_init>
    aece:	44 8b 1d f3 fc 05 00 	mov    0x5fcf3(%rip),%r11d        # 6abc8 <fwp_heap+0x13a8>
    aed5:	45 85 db             	test   %r11d,%r11d
    aed8:	0f 84 88 ec ff ff    	je     9b66 <fwp_main_thread+0x46>
    aede:	48 8d 3d db 9d ff ff 	lea    -0x6225(%rip),%rdi        # 4cc0 <fwp_heap_report>
    aee5:	e8 c6 12 00 00       	call   c1b0 <atexit>
    aeea:	e9 77 ec ff ff       	jmp    9b66 <fwp_main_thread+0x46>
    aeef:	90                   	nop
    aef0:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    aef5:	e8 76 d4 ff ff       	call   8370 <fwp_drop10>
    aefa:	48 8b 1c 24          	mov    (%rsp),%rbx
    aefe:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    af03:	66 90                	xchg   %ax,%ax
    af05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    af0c:	00 00 00 00 
    af10:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    af14:	49 83 c6 01          	add    $0x1,%r14
    af18:	48 85 db             	test   %rbx,%rbx
    af1b:	75 f3                	jne    af10 <fwp_main_thread+0x13f0>
    af1d:	4c 8b 2a             	mov    (%rdx),%r13
    af20:	4d 85 ed             	test   %r13,%r13
    af23:	0f 88 27 01 00 00    	js     b050 <fwp_main_thread+0x1530>
    af29:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    af30:	00 
    af31:	48 89 e8             	mov    %rbp,%rax
    af34:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    af3b:	00 
    af3c:	48 c1 e1 10          	shl    $0x10,%rcx
    af40:	48 39 c8             	cmp    %rcx,%rax
    af43:	0f 83 07 01 00 00    	jae    b050 <fwp_main_thread+0x1530>
    af49:	48 89 c1             	mov    %rax,%rcx
    af4c:	48 c1 e9 10          	shr    $0x10,%rcx
    af50:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    af54:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    af5b:	00 
    af5c:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    af60:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    af64:	48 85 f6             	test   %rsi,%rsi
    af67:	0f 84 e3 00 00 00    	je     b050 <fwp_main_thread+0x1530>
    af6d:	0f b6 39             	movzbl (%rcx),%edi
    af70:	40 80 ff 02          	cmp    $0x2,%dil
    af74:	0f 84 be 00 00 00    	je     b038 <fwp_main_thread+0x1518>
    af7a:	40 80 ff 01          	cmp    $0x1,%dil
    af7e:	0f 85 cc 00 00 00    	jne    b050 <fwp_main_thread+0x1530>
    af84:	8b 79 18             	mov    0x18(%rcx),%edi
    af87:	0f b7 c0             	movzwl %ax,%eax
    af8a:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    af8d:	48 0f af c7          	imul   %rdi,%rax
    af91:	48 c1 e8 20          	shr    $0x20,%rax
    af95:	48 39 c8             	cmp    %rcx,%rax
    af98:	0f 83 b2 00 00 00    	jae    b050 <fwp_main_thread+0x1530>
    af9e:	48 01 c6             	add    %rax,%rsi
    afa1:	80 3e 01             	cmpb   $0x1,(%rsi)
    afa4:	0f 85 a6 00 00 00    	jne    b050 <fwp_main_thread+0x1530>
    afaa:	4d 39 ee             	cmp    %r13,%r14
    afad:	4c 89 e9             	mov    %r13,%rcx
    afb0:	49 0f 46 ce          	cmovbe %r14,%rcx
    afb4:	48 85 c9             	test   %rcx,%rcx
    afb7:	0f 84 7e 0d 00 00    	je     bd3b <fwp_main_thread+0x221b>
    afbd:	c7 44 24 20 01 00 00 	movl   $0x1,0x20(%rsp)
    afc4:	00 
    afc5:	4c 8d 7a 08          	lea    0x8(%rdx),%r15
    afc9:	48 8b 34 24          	mov    (%rsp),%rsi
    afcd:	4c 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%r8
    afd4:	00 
    afd5:	31 c0                	xor    %eax,%eax
    afd7:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
    afdb:	eb 45                	jmp    b022 <fwp_main_thread+0x1502>
    afdd:	66 90                	xchg   %ax,%ax
    afdf:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    afe6:	00 00 00 00 
    afea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aff1:	00 00 00 00 
    aff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    affc:	00 00 00 00 
    b000:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    b005:	f2 41 0f 5c 04 01    	subsd  (%r9,%rax,1),%xmm0
    b00b:	f2 41 0f 11 04 07    	movsd  %xmm0,(%r15,%rax,1)
    b011:	48 83 c0 08          	add    $0x8,%rax
    b015:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    b019:	49 39 c0             	cmp    %rax,%r8
    b01c:	0f 84 de 00 00 00    	je     b100 <fwp_main_thread+0x15e0>
    b022:	49 89 f9             	mov    %rdi,%r9
    b025:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    b029:	79 d5                	jns    b000 <fwp_main_thread+0x14e0>
    b02b:	4c 8b 4d 10          	mov    0x10(%rbp),%r9
    b02f:	eb cf                	jmp    b000 <fwp_main_thread+0x14e0>
    b031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b038:	66 85 c0             	test   %ax,%ax
    b03b:	0f 84 60 ff ff ff    	je     afa1 <fwp_main_thread+0x1481>
    b041:	0f 1f 40 00          	nopl   0x0(%rax)
    b045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b04c:	00 00 00 00 
    b050:	48 8b 04 24          	mov    (%rsp),%rax
    b054:	45 31 f6             	xor    %r14d,%r14d
    b057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b05e:	00 00 
    b060:	48 8b 40 10          	mov    0x10(%rax),%rax
    b064:	4c 89 f1             	mov    %r14,%rcx
    b067:	49 83 c6 01          	add    $0x1,%r14
    b06b:	48 85 c0             	test   %rax,%rax
    b06e:	75 f0                	jne    b060 <fwp_main_thread+0x1540>
    b070:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b077:	ff ff 1f 
    b07a:	4c 39 f0             	cmp    %r14,%rax
    b07d:	0f 82 4a 0e 00 00    	jb     becd <fwp_main_thread+0x23ad>
    b083:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    b08a:	00 
    b08b:	be 02 00 00 00       	mov    $0x2,%esi
    b090:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b095:	e8 76 ae ff ff       	call   5f10 <fwp_heap_alloc>
    b09a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    b09f:	49 89 c7             	mov    %rax,%r15
    b0a2:	48 89 c1             	mov    %rax,%rcx
    b0a5:	48 8b 04 24          	mov    (%rsp),%rax
    b0a9:	90                   	nop
    b0aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0b1:	00 00 00 00 
    b0b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b0bc:	00 00 00 00 
    b0c0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    b0c4:	48 83 c1 08          	add    $0x8,%rcx
    b0c8:	48 89 71 f8          	mov    %rsi,-0x8(%rcx)
    b0cc:	48 8b 40 10          	mov    0x10(%rax),%rax
    b0d0:	48 85 c0             	test   %rax,%rax
    b0d3:	75 eb                	jne    b0c0 <fwp_main_thread+0x15a0>
    b0d5:	4c 89 e9             	mov    %r13,%rcx
    b0d8:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    b0dd:	4c 39 f1             	cmp    %r14,%rcx
    b0e0:	49 0f 47 ce          	cmova  %r14,%rcx
    b0e4:	48 85 c9             	test   %rcx,%rcx
    b0e7:	0f 84 85 0b 00 00    	je     bc72 <fwp_main_thread+0x2152>
    b0ed:	c7 44 24 20 00 00 00 	movl   $0x0,0x20(%rsp)
    b0f4:	00 
    b0f5:	e9 cf fe ff ff       	jmp    afc9 <fwp_main_thread+0x14a9>
    b0fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b100:	4d 8b 84 24 d8 13 00 	mov    0x13d8(%r12),%r8
    b107:	00 
    b108:	4d 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%r9
    b10f:	00 
    b110:	45 31 f6             	xor    %r14d,%r14d
    b113:	4d 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%r10
    b11a:	00 
    b11b:	48 8b 14 24          	mov    (%rsp),%rdx
    b11f:	49 c1 e0 10          	shl    $0x10,%r8
    b123:	eb 15                	jmp    b13a <fwp_main_thread+0x161a>
    b125:	0f 1f 00             	nopl   (%rax)
    b128:	49 83 c6 01          	add    $0x1,%r14
    b12c:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    b130:	49 39 ce             	cmp    %rcx,%r14
    b133:	73 5b                	jae    b190 <fwp_main_thread+0x1670>
    b135:	48 85 d2             	test   %rdx,%rdx
    b138:	74 56                	je     b190 <fwp_main_thread+0x1670>
    b13a:	48 89 d0             	mov    %rdx,%rax
    b13d:	4c 29 c8             	sub    %r9,%rax
    b140:	4c 39 c0             	cmp    %r8,%rax
    b143:	73 4b                	jae    b190 <fwp_main_thread+0x1670>
    b145:	48 89 c6             	mov    %rax,%rsi
    b148:	48 c1 ee 10          	shr    $0x10,%rsi
    b14c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    b150:	49 8d 34 f2          	lea    (%r10,%rsi,8),%rsi
    b154:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b158:	48 85 ff             	test   %rdi,%rdi
    b15b:	74 33                	je     b190 <fwp_main_thread+0x1670>
    b15d:	44 0f b6 1e          	movzbl (%rsi),%r11d
    b161:	41 80 fb 02          	cmp    $0x2,%r11b
    b165:	0f 84 15 01 00 00    	je     b280 <fwp_main_thread+0x1760>
    b16b:	41 80 fb 01          	cmp    $0x1,%r11b
    b16f:	75 1f                	jne    b190 <fwp_main_thread+0x1670>
    b171:	44 8b 5e 18          	mov    0x18(%rsi),%r11d
    b175:	0f b7 c0             	movzwl %ax,%eax
    b178:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b17b:	49 0f af c3          	imul   %r11,%rax
    b17f:	48 c1 e8 20          	shr    $0x20,%rax
    b183:	48 39 f0             	cmp    %rsi,%rax
    b186:	73 08                	jae    b190 <fwp_main_thread+0x1670>
    b188:	48 01 c7             	add    %rax,%rdi
    b18b:	80 3f 01             	cmpb   $0x1,(%rdi)
    b18e:	74 98                	je     b128 <fwp_main_thread+0x1608>
    b190:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    b194:	49 39 ce             	cmp    %rcx,%r14
    b197:	72 3f                	jb     b1d8 <fwp_main_thread+0x16b8>
    b199:	e9 02 01 00 00       	jmp    b2a0 <fwp_main_thread+0x1780>
    b19e:	66 90                	xchg   %ax,%ax
    b1a0:	40 80 fe 01          	cmp    $0x1,%sil
    b1a4:	75 25                	jne    b1cb <fwp_main_thread+0x16ab>
    b1a6:	8b 71 18             	mov    0x18(%rcx),%esi
    b1a9:	0f b7 c0             	movzwl %ax,%eax
    b1ac:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b1af:	48 0f af c6          	imul   %rsi,%rax
    b1b3:	48 c1 e8 20          	shr    $0x20,%rax
    b1b7:	48 39 c8             	cmp    %rcx,%rax
    b1ba:	73 0f                	jae    b1cb <fwp_main_thread+0x16ab>
    b1bc:	48 01 c2             	add    %rax,%rdx
    b1bf:	80 3a ff             	cmpb   $0xff,(%rdx)
    b1c2:	0f 84 18 05 00 00    	je     b6e0 <fwp_main_thread+0x1bc0>
    b1c8:	c6 02 01             	movb   $0x1,(%rdx)
    b1cb:	4d 39 ee             	cmp    %r13,%r14
    b1ce:	0f 84 8c 00 00 00    	je     b260 <fwp_main_thread+0x1740>
    b1d4:	49 83 ed 01          	sub    $0x1,%r13
    b1d8:	f3 43 0f 7e 04 ef    	movq   (%r15,%r13,8),%xmm0
    b1de:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    b1e3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    b1e8:	bf 01 00 00 00       	mov    $0x1,%edi
    b1ed:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    b1f1:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    b1f8:	00 
    b1f9:	e8 02 af ff ff       	call   6100 <fwp_data.part.0.constprop.0>
    b1fe:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b205:	00 
    b206:	48 89 c3             	mov    %rax,%rbx
    b209:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b210:	00 
    b211:	48 c1 e2 10          	shl    $0x10,%rdx
    b215:	48 39 d0             	cmp    %rdx,%rax
    b218:	73 b1                	jae    b1cb <fwp_main_thread+0x16ab>
    b21a:	48 89 c2             	mov    %rax,%rdx
    b21d:	48 c1 ea 10          	shr    $0x10,%rdx
    b221:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b225:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b22c:	00 
    b22d:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    b231:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    b235:	48 85 d2             	test   %rdx,%rdx
    b238:	74 91                	je     b1cb <fwp_main_thread+0x16ab>
    b23a:	0f b6 31             	movzbl (%rcx),%esi
    b23d:	40 80 fe 02          	cmp    $0x2,%sil
    b241:	0f 85 59 ff ff ff    	jne    b1a0 <fwp_main_thread+0x1680>
    b247:	66 85 c0             	test   %ax,%ax
    b24a:	0f 84 6f ff ff ff    	je     b1bf <fwp_main_thread+0x169f>
    b250:	4d 39 ee             	cmp    %r13,%r14
    b253:	0f 85 7b ff ff ff    	jne    b1d4 <fwp_main_thread+0x16b4>
    b259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b260:	4d 85 f6             	test   %r14,%r14
    b263:	75 3b                	jne    b2a0 <fwp_main_thread+0x1780>
    b265:	8b 44 24 20          	mov    0x20(%rsp),%eax
    b269:	4c 8b 34 24          	mov    (%rsp),%r14
    b26d:	85 c0                	test   %eax,%eax
    b26f:	4c 0f 45 7c 24 10    	cmovne 0x10(%rsp),%r15
    b275:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    b27a:	eb 74                	jmp    b2f0 <fwp_main_thread+0x17d0>
    b27c:	0f 1f 40 00          	nopl   0x0(%rax)
    b280:	66 85 c0             	test   %ax,%ax
    b283:	0f 84 02 ff ff ff    	je     b18b <fwp_main_thread+0x166b>
    b289:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    b28d:	49 39 ce             	cmp    %rcx,%r14
    b290:	0f 82 42 ff ff ff    	jb     b1d8 <fwp_main_thread+0x16b8>
    b296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b29d:	00 00 00 
    b2a0:	4b 8d 34 f7          	lea    (%r15,%r14,8),%rsi
    b2a4:	4c 8b 34 24          	mov    (%rsp),%r14
    b2a8:	4c 89 f8             	mov    %r15,%rax
    b2ab:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b2b2:	00 00 00 
    b2b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    b2bc:	00 00 00 00 
    b2c0:	48 8b 10             	mov    (%rax),%rdx
    b2c3:	48 83 c0 08          	add    $0x8,%rax
    b2c7:	4c 89 f1             	mov    %r14,%rcx
    b2ca:	49 89 56 08          	mov    %rdx,0x8(%r14)
    b2ce:	4d 8b 76 10          	mov    0x10(%r14),%r14
    b2d2:	48 39 f0             	cmp    %rsi,%rax
    b2d5:	75 e9                	jne    b2c0 <fwp_main_thread+0x17a0>
    b2d7:	8b 54 24 20          	mov    0x20(%rsp),%edx
    b2db:	48 89 59 10          	mov    %rbx,0x10(%rcx)
    b2df:	48 8b 1c 24          	mov    (%rsp),%rbx
    b2e3:	85 d2                	test   %edx,%edx
    b2e5:	4c 0f 45 7c 24 10    	cmovne 0x10(%rsp),%r15
    b2eb:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    b2f0:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    b2f5:	e8 16 a7 ff ff       	call   5a10 <fwp_mem_free>
    b2fa:	48 89 ef             	mov    %rbp,%rdi
    b2fd:	e8 6e d0 ff ff       	call   8370 <fwp_drop10>
    b302:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b309:	00 
    b30a:	4c 89 f0             	mov    %r14,%rax
    b30d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b314:	00 
    b315:	48 c1 e2 10          	shl    $0x10,%rdx
    b319:	48 39 d0             	cmp    %rdx,%rax
    b31c:	73 72                	jae    b390 <fwp_main_thread+0x1870>
    b31e:	48 89 c2             	mov    %rax,%rdx
    b321:	49 8b b4 24 f8 13 00 	mov    0x13f8(%r12),%rsi
    b328:	00 
    b329:	48 c1 ea 10          	shr    $0x10,%rdx
    b32d:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    b331:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    b335:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    b339:	48 85 ed             	test   %rbp,%rbp
    b33c:	74 52                	je     b390 <fwp_main_thread+0x1870>
    b33e:	0f b6 0a             	movzbl (%rdx),%ecx
    b341:	80 f9 02             	cmp    $0x2,%cl
    b344:	0f 84 f6 05 00 00    	je     b940 <fwp_main_thread+0x1e20>
    b34a:	80 f9 01             	cmp    $0x1,%cl
    b34d:	75 41                	jne    b390 <fwp_main_thread+0x1870>
    b34f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b352:	0f b7 c0             	movzwl %ax,%eax
    b355:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b358:	48 0f af c1          	imul   %rcx,%rax
    b35c:	48 c1 e8 20          	shr    $0x20,%rax
    b360:	48 39 d0             	cmp    %rdx,%rax
    b363:	73 2b                	jae    b390 <fwp_main_thread+0x1870>
    b365:	48 01 c5             	add    %rax,%rbp
    b368:	0f b6 45 00          	movzbl 0x0(%rbp),%eax
    b36c:	84 c0                	test   %al,%al
    b36e:	74 20                	je     b390 <fwp_main_thread+0x1870>
    b370:	3c 01                	cmp    $0x1,%al
    b372:	0f 84 40 06 00 00    	je     b9b8 <fwp_main_thread+0x1e98>
    b378:	3c ff                	cmp    $0xff,%al
    b37a:	0f 84 4d 09 00 00    	je     bccd <fwp_main_thread+0x21ad>
    b380:	83 e8 01             	sub    $0x1,%eax
    b383:	88 45 00             	mov    %al,0x0(%rbp)
    b386:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b38d:	00 00 00 
    b390:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    b395:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b399:	b9 01 00 00 00       	mov    $0x1,%ecx
    b39e:	48 89 de             	mov    %rbx,%rsi
    b3a1:	48 8d 15 f8 57 00 00 	lea    0x57f8(%rip),%rdx        # 10ba0 <d0>
    b3a8:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
    b3af:	00 
    b3b0:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    b3b7:	00 00 00 00 00 
    b3bc:	e8 1f d7 ff ff       	call   8ae0 <fwp_write>
    b3c1:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
    b3c8:	00 
    b3c9:	4c 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%r15
    b3d0:	00 
    b3d1:	48 8d 05 94 1c 00 00 	lea    0x1c94(%rip),%rax        # d06c <_IO_stdin_used+0x6c>
    b3d8:	4d 85 f6             	test   %r14,%r14
    b3db:	4c 0f 44 f0          	cmove  %rax,%r14
    b3df:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    b3e3:	0f 87 a0 0b 00 00    	ja     bf89 <fwp_main_thread+0x2469>
    b3e9:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    b3ed:	be 01 00 00 00       	mov    $0x1,%esi
    b3f2:	e8 19 ab ff ff       	call   5f10 <fwp_heap_alloc>
    b3f7:	4c 89 fa             	mov    %r15,%rdx
    b3fa:	4c 89 f6             	mov    %r14,%rsi
    b3fd:	4c 89 38             	mov    %r15,(%rax)
    b400:	4c 8d 68 08          	lea    0x8(%rax),%r13
    b404:	48 89 c5             	mov    %rax,%rbp
    b407:	4c 89 ef             	mov    %r13,%rdi
    b40a:	e8 71 81 ff ff       	call   3580 <memcpy@plt>
    b40f:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    b415:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
    b41c:	00 
    b41d:	e8 8e 7f ff ff       	call   33b0 <free@plt>
    b422:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b429:	00 
    b42a:	48 89 e8             	mov    %rbp,%rax
    b42d:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b434:	00 
    b435:	48 c1 e2 10          	shl    $0x10,%rdx
    b439:	48 39 d0             	cmp    %rdx,%rax
    b43c:	73 58                	jae    b496 <fwp_main_thread+0x1976>
    b43e:	48 89 c2             	mov    %rax,%rdx
    b441:	48 c1 ea 10          	shr    $0x10,%rdx
    b445:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b449:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b450:	00 
    b451:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b455:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    b459:	4d 85 f6             	test   %r14,%r14
    b45c:	74 38                	je     b496 <fwp_main_thread+0x1976>
    b45e:	0f b6 0a             	movzbl (%rdx),%ecx
    b461:	80 f9 02             	cmp    $0x2,%cl
    b464:	0f 84 36 07 00 00    	je     bba0 <fwp_main_thread+0x2080>
    b46a:	80 f9 01             	cmp    $0x1,%cl
    b46d:	75 27                	jne    b496 <fwp_main_thread+0x1976>
    b46f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b472:	0f b7 c0             	movzwl %ax,%eax
    b475:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b478:	48 0f af c1          	imul   %rcx,%rax
    b47c:	48 c1 e8 20          	shr    $0x20,%rax
    b480:	48 39 d0             	cmp    %rdx,%rax
    b483:	73 11                	jae    b496 <fwp_main_thread+0x1976>
    b485:	49 01 c6             	add    %rax,%r14
    b488:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b48c:	0f 84 21 07 00 00    	je     bbb3 <fwp_main_thread+0x2093>
    b492:	41 c6 06 01          	movb   $0x1,(%r14)
    b496:	48 89 df             	mov    %rbx,%rdi
    b499:	e8 e2 ca ff ff       	call   7f80 <fwp_drop0>
    b49e:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    b4a2:	be 01 00 00 00       	mov    $0x1,%esi
    b4a7:	4c 89 ef             	mov    %r13,%rdi
    b4aa:	48 8b 0d cf ff 05 00 	mov    0x5ffcf(%rip),%rcx        # 6b480 <fwp_prog_out>
    b4b1:	e8 aa 81 ff ff       	call   3660 <fwrite@plt>
    b4b6:	48 8b 35 c3 ff 05 00 	mov    0x5ffc3(%rip),%rsi        # 6b480 <fwp_prog_out>
    b4bd:	bf 0a 00 00 00       	mov    $0xa,%edi
    b4c2:	e8 09 80 ff ff       	call   34d0 <fputc@plt>
    b4c7:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b4ce:	00 
    b4cf:	48 89 e8             	mov    %rbp,%rax
    b4d2:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b4d9:	00 
    b4da:	48 c1 e2 10          	shl    $0x10,%rdx
    b4de:	48 39 d0             	cmp    %rdx,%rax
    b4e1:	73 6d                	jae    b550 <fwp_main_thread+0x1a30>
    b4e3:	48 89 c2             	mov    %rax,%rdx
    b4e6:	48 c1 ea 10          	shr    $0x10,%rdx
    b4ea:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b4ee:	49 8b 94 24 f8 13 00 	mov    0x13f8(%r12),%rdx
    b4f5:	00 
    b4f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b4fa:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    b4fe:	48 85 db             	test   %rbx,%rbx
    b501:	74 4d                	je     b550 <fwp_main_thread+0x1a30>
    b503:	0f b6 0a             	movzbl (%rdx),%ecx
    b506:	80 f9 02             	cmp    $0x2,%cl
    b509:	0f 84 71 06 00 00    	je     bb80 <fwp_main_thread+0x2060>
    b50f:	80 f9 01             	cmp    $0x1,%cl
    b512:	75 3c                	jne    b550 <fwp_main_thread+0x1a30>
    b514:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b517:	0f b7 c0             	movzwl %ax,%eax
    b51a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b51d:	48 0f af c1          	imul   %rcx,%rax
    b521:	48 c1 e8 20          	shr    $0x20,%rax
    b525:	48 39 d0             	cmp    %rdx,%rax
    b528:	73 26                	jae    b550 <fwp_main_thread+0x1a30>
    b52a:	48 01 c3             	add    %rax,%rbx
    b52d:	0f b6 03             	movzbl (%rbx),%eax
    b530:	84 c0                	test   %al,%al
    b532:	74 1c                	je     b550 <fwp_main_thread+0x1a30>
    b534:	3c 01                	cmp    $0x1,%al
    b536:	0f 84 ae 06 00 00    	je     bbea <fwp_main_thread+0x20ca>
    b53c:	3c ff                	cmp    $0xff,%al
    b53e:	0f 84 0c 08 00 00    	je     bd50 <fwp_main_thread+0x2230>
    b544:	83 e8 01             	sub    $0x1,%eax
    b547:	88 03                	mov    %al,(%rbx)
    b549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b550:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    b555:	48 8b 40 10          	mov    0x10(%rax),%rax
    b559:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    b55e:	48 85 c0             	test   %rax,%rax
    b561:	0f 84 36 07 00 00    	je     bc9d <fwp_main_thread+0x217d>
    b567:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b56e:	00 
    b56f:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b576:	00 
    b577:	48 8b 1d 3a ff 05 00 	mov    0x5ff3a(%rip),%rbx        # 6b4b8 <fwp_cleanups>
    b57e:	e9 24 f0 ff ff       	jmp    a5a7 <fwp_main_thread+0xa87>
    b583:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b588:	4d 39 fd             	cmp    %r15,%r13
    b58b:	0f 84 ff f1 ff ff    	je     a790 <fwp_main_thread+0xc70>
    b591:	4c 8b 35 58 5b 01 00 	mov    0x15b58(%rip),%r14        # 210f0 <fwp_tapes>
    b598:	e9 8c f2 ff ff       	jmp    a829 <fwp_main_thread+0xd09>
    b59d:	0f 1f 00             	nopl   (%rax)
    b5a0:	48 83 3d e0 5a 01 00 	cmpq   $0x0,0x15ae0(%rip)        # 21088 <fwp_tape_cached_bytes>
    b5a7:	00 
    b5a8:	0f 84 c6 f2 ff ff    	je     a874 <fwp_main_thread+0xd54>
    b5ae:	66 0f 6f 0d ea 5a 01 	movdqa 0x15aea(%rip),%xmm1        # 210a0 <fwp_tape_workspace>
    b5b5:	00 
    b5b6:	48 c7 05 c7 5a 01 00 	movq   $0x0,0x15ac7(%rip)        # 21088 <fwp_tape_cached_bytes>
    b5bd:	00 00 00 00 
    b5c1:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
    b5c6:	48 8b 05 f3 5a 01 00 	mov    0x15af3(%rip),%rax        # 210c0 <fwp_tape_workspace+0x20>
    b5cd:	66 0f 6f 0d db 5a 01 	movdqa 0x15adb(%rip),%xmm1        # 210b0 <fwp_tape_workspace+0x10>
    b5d4:	00 
    b5d5:	49 89 45 40          	mov    %rax,0x40(%r13)
    b5d9:	48 8b 05 e8 5a 01 00 	mov    0x15ae8(%rip),%rax        # 210c8 <fwp_tape_workspace+0x28>
    b5e0:	41 0f 11 4d 30       	movups %xmm1,0x30(%r13)
    b5e5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b5e9:	49 89 45 18          	mov    %rax,0x18(%r13)
    b5ed:	48 8b 05 dc 5a 01 00 	mov    0x15adc(%rip),%rax        # 210d0 <fwp_tape_workspace+0x30>
    b5f4:	0f 29 0d a5 5a 01 00 	movaps %xmm1,0x15aa5(%rip)        # 210a0 <fwp_tape_workspace>
    b5fb:	49 89 45 48          	mov    %rax,0x48(%r13)
    b5ff:	0f 29 0d aa 5a 01 00 	movaps %xmm1,0x15aaa(%rip)        # 210b0 <fwp_tape_workspace+0x10>
    b606:	48 c7 05 bf 5a 01 00 	movq   $0x0,0x15abf(%rip)        # 210d0 <fwp_tape_workspace+0x30>
    b60d:	00 00 00 00 
    b611:	0f 29 0d a8 5a 01 00 	movaps %xmm1,0x15aa8(%rip)        # 210c0 <fwp_tape_workspace+0x20>
    b618:	e9 57 f2 ff ff       	jmp    a874 <fwp_main_thread+0xd54>
    b61d:	0f 1f 00             	nopl   (%rax)
    b620:	66 85 c0             	test   %ax,%ax
    b623:	0f 84 48 f8 ff ff    	je     ae71 <fwp_main_thread+0x1351>
    b629:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b630:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    b637:	ff ff 1f 
    b63a:	4c 39 e8             	cmp    %r13,%rax
    b63d:	0f 82 e9 08 00 00    	jb     bf2c <fwp_main_thread+0x240c>
    b643:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    b64a:	00 
    b64b:	be 01 00 00 00       	mov    $0x1,%esi
    b650:	e8 bb a8 ff ff       	call   5f10 <fwp_heap_alloc>
    b655:	4c 89 28             	mov    %r13,(%rax)
    b658:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    b65f:	00 
    b660:	48 89 c2             	mov    %rax,%rdx
    b663:	48 89 c5             	mov    %rax,%rbp
    b666:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b66d:	00 
    b66e:	48 c1 e1 10          	shl    $0x10,%rcx
    b672:	48 39 c8             	cmp    %rcx,%rax
    b675:	73 5a                	jae    b6d1 <fwp_main_thread+0x1bb1>
    b677:	48 89 c1             	mov    %rax,%rcx
    b67a:	48 c1 e9 10          	shr    $0x10,%rcx
    b67e:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b682:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    b689:	00 
    b68a:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b68e:	4c 8b 79 20          	mov    0x20(%rcx),%r15
    b692:	4d 85 ff             	test   %r15,%r15
    b695:	74 3a                	je     b6d1 <fwp_main_thread+0x1bb1>
    b697:	0f b6 31             	movzbl (%rcx),%esi
    b69a:	40 80 fe 02          	cmp    $0x2,%sil
    b69e:	0f 84 bc 03 00 00    	je     ba60 <fwp_main_thread+0x1f40>
    b6a4:	40 80 fe 01          	cmp    $0x1,%sil
    b6a8:	75 27                	jne    b6d1 <fwp_main_thread+0x1bb1>
    b6aa:	8b 71 18             	mov    0x18(%rcx),%esi
    b6ad:	0f b7 c0             	movzwl %ax,%eax
    b6b0:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    b6b3:	48 0f af c6          	imul   %rsi,%rax
    b6b7:	48 c1 e8 20          	shr    $0x20,%rax
    b6bb:	48 39 c8             	cmp    %rcx,%rax
    b6be:	73 11                	jae    b6d1 <fwp_main_thread+0x1bb1>
    b6c0:	49 01 c7             	add    %rax,%r15
    b6c3:	41 80 3f ff          	cmpb   $0xff,(%r15)
    b6c7:	0f 84 a6 03 00 00    	je     ba73 <fwp_main_thread+0x1f53>
    b6cd:	41 c6 07 01          	movb   $0x1,(%r15)
    b6d1:	48 89 df             	mov    %rbx,%rdi
    b6d4:	e9 a9 f7 ff ff       	jmp    ae82 <fwp_main_thread+0x1362>
    b6d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b6e0:	48 89 d7             	mov    %rdx,%rdi
    b6e3:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    b6e8:	e8 e3 a0 ff ff       	call   57d0 <fwp_rc_forget_slot>
    b6ed:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    b6f2:	e9 d1 fa ff ff       	jmp    b1c8 <fwp_main_thread+0x16a8>
    b6f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b6fe:	00 00 
    b700:	48 8d 58 ff          	lea    -0x1(%rax),%rbx
    b704:	48 89 df             	mov    %rbx,%rdi
    b707:	48 c1 ef 3c          	shr    $0x3c,%rdi
    b70b:	0f 85 bc 07 00 00    	jne    becd <fwp_main_thread+0x23ad>
    b711:	48 85 db             	test   %rbx,%rbx
    b714:	0f 84 66 f3 ff ff    	je     aa80 <fwp_main_thread+0xf60>
    b71a:	48 c1 e0 04          	shl    $0x4,%rax
    b71e:	48 01 db             	add    %rbx,%rbx
    b721:	4c 8d 7d 08          	lea    0x8(%rbp),%r15
    b725:	4c 8d 6c 05 f8       	lea    -0x8(%rbp,%rax,1),%r13
    b72a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b730:	f2 41 0f 10 07       	movsd  (%r15),%xmm0
    b735:	49 8b 77 18          	mov    0x18(%r15),%rsi
    b739:	49 83 c7 10          	add    $0x10,%r15
    b73d:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
    b741:	f2 41 0f 10 0f       	movsd  (%r15),%xmm1
    b746:	e8 a5 af ff ff       	call   66f0 <w120>
    b74b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    b750:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    b754:	41 0f 11 47 f0       	movups %xmm0,-0x10(%r15)
    b759:	4d 39 fd             	cmp    %r15,%r13
    b75c:	75 d2                	jne    b730 <fwp_main_thread+0x1c10>
    b75e:	48 89 5d 00          	mov    %rbx,0x0(%rbp)
    b762:	45 31 ed             	xor    %r13d,%r13d
    b765:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    b76c:	0f 1f 40 00          	nopl   0x0(%rax)
    b770:	4a 8b 74 ed 10       	mov    0x10(%rbp,%r13,8),%rsi
    b775:	49 83 c5 02          	add    $0x2,%r13
    b779:	e8 f2 ad ff ff       	call   6570 <f141.constprop.0>
    b77e:	48 89 c7             	mov    %rax,%rdi
    b781:	49 39 dd             	cmp    %rbx,%r13
    b784:	72 ea                	jb     b770 <fwp_main_thread+0x1c50>
    b786:	49 89 c7             	mov    %rax,%r15
    b789:	e9 02 f3 ff ff       	jmp    aa90 <fwp_main_thread+0xf70>
    b78e:	66 90                	xchg   %ax,%ax
    b790:	48 c1 e2 10          	shl    $0x10,%rdx
    b794:	be 02 00 00 00       	mov    $0x2,%esi
    b799:	bf 08 00 00 00       	mov    $0x8,%edi
    b79e:	48 09 ea             	or     %rbp,%rdx
    b7a1:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    b7a6:	e8 65 a7 ff ff       	call   5f10 <fwp_heap_alloc>
    b7ab:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    b7b2:	49 8b 8c 24 d8 13 00 	mov    0x13d8(%r12),%rcx
    b7b9:	00 
    b7ba:	48 89 c5             	mov    %rax,%rbp
    b7bd:	49 2b 84 24 b0 13 00 	sub    0x13b0(%r12),%rax
    b7c4:	00 
    b7c5:	48 c1 e1 10          	shl    $0x10,%rcx
    b7c9:	48 39 c8             	cmp    %rcx,%rax
    b7cc:	0f 83 ae f2 ff ff    	jae    aa80 <fwp_main_thread+0xf60>
    b7d2:	48 89 c1             	mov    %rax,%rcx
    b7d5:	48 c1 e9 10          	shr    $0x10,%rcx
    b7d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    b7dd:	49 8b 8c 24 f8 13 00 	mov    0x13f8(%r12),%rcx
    b7e4:	00 
    b7e5:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    b7e9:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    b7ed:	4d 85 ed             	test   %r13,%r13
    b7f0:	0f 84 7d f2 ff ff    	je     aa73 <fwp_main_thread+0xf53>
    b7f6:	0f b6 31             	movzbl (%rcx),%esi
    b7f9:	31 db                	xor    %ebx,%ebx
    b7fb:	40 80 fe 02          	cmp    $0x2,%sil
    b7ff:	0f 85 ca f1 ff ff    	jne    a9cf <fwp_main_thread+0xeaf>
    b805:	66 85 c0             	test   %ax,%ax
    b808:	0f 85 f0 f1 ff ff    	jne    a9fe <fwp_main_thread+0xede>
    b80e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b813:	0f 85 e0 f1 ff ff    	jne    a9f9 <fwp_main_thread+0xed9>
    b819:	4c 89 ef             	mov    %r13,%rdi
    b81c:	e8 af 9f ff ff       	call   57d0 <fwp_rc_forget_slot>
    b821:	e9 d3 f1 ff ff       	jmp    a9f9 <fwp_main_thread+0xed9>
    b826:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b82d:	00 00 00 
    b830:	48 8d 69 01          	lea    0x1(%rcx),%rbp
    b834:	48 39 eb             	cmp    %rbp,%rbx
    b837:	7c 3a                	jl     b873 <fwp_main_thread+0x1d53>
    b839:	4d 85 c0             	test   %r8,%r8
    b83c:	0f 84 a3 06 00 00    	je     bee5 <fwp_main_thread+0x23c5>
    b842:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b847:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    b84e:	00 
    b84f:	31 f6                	xor    %esi,%esi
    b851:	4c 89 c7             	mov    %r8,%rdi
    b854:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
    b859:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b85e:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b863:	e9 92 f3 ff ff       	jmp    abfa <fwp_main_thread+0x10da>
    b868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b86f:	00 
    b870:	4c 89 cd             	mov    %r9,%rbp
    b873:	48 85 db             	test   %rbx,%rbx
    b876:	48 0f 44 dd          	cmove  %rbp,%rbx
    b87a:	eb 19                	jmp    b895 <fwp_main_thread+0x1d75>
    b87c:	0f 1f 40 00          	nopl   0x0(%rax)
    b880:	48 8d 14 1b          	lea    (%rbx,%rbx,1),%rdx
    b884:	48 81 fb 00 00 00 40 	cmp    $0x40000000,%rbx
    b88b:	48 89 e8             	mov    %rbp,%rax
    b88e:	48 0f 4c c2          	cmovl  %rdx,%rax
    b892:	48 89 c3             	mov    %rax,%rbx
    b895:	48 39 eb             	cmp    %rbp,%rbx
    b898:	7c e6                	jl     b880 <fwp_main_thread+0x1d60>
    b89a:	4d 85 c0             	test   %r8,%r8
    b89d:	0f 84 fd 01 00 00    	je     baa0 <fwp_main_thread+0x1f80>
    b8a3:	4c 89 c7             	mov    %r8,%rdi
    b8a6:	ba 03 00 00 00       	mov    $0x3,%edx
    b8ab:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    b8b0:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
    b8b7:	00 
    b8b8:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b8bd:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b8c2:	e8 b9 98 ff ff       	call   5180 <ad_raw_realloc>
    b8c7:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    b8cc:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b8d2:	48 85 c0             	test   %rax,%rax
    b8d5:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b8db:	49 89 c0             	mov    %rax,%r8
    b8de:	0f 84 dc 02 00 00    	je     bbc0 <fwp_main_thread+0x20a0>
    b8e4:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
    b8eb:	00 
    b8ec:	48 89 9c 24 00 01 00 	mov    %rbx,0x100(%rsp)
    b8f3:	00 
    b8f4:	48 85 ed             	test   %rbp,%rbp
    b8f7:	0f 85 0d 03 00 00    	jne    bc0a <fwp_main_thread+0x20ea>
    b8fd:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b904:	4d 85 ff             	test   %r15,%r15
    b907:	0f 88 1f f3 ff ff    	js     ac2c <fwp_main_thread+0x110c>
    b90d:	44 89 f9             	mov    %r15d,%ecx
    b910:	e9 03 f3 ff ff       	jmp    ac18 <fwp_main_thread+0x10f8>
    b915:	0f 1f 00             	nopl   (%rax)
    b918:	48 8d 3d e1 b9 ff ff 	lea    -0x461f(%rip),%rdi        # 7300 <fwp_tape_finish>
    b91f:	e8 8c 08 00 00       	call   c1b0 <atexit>
    b924:	85 c0                	test   %eax,%eax
    b926:	0f 85 d2 05 00 00    	jne    befe <fwp_main_thread+0x23de>
    b92c:	c7 05 2a 57 00 00 01 	movl   $0x1,0x572a(%rip)        # 11060 <registered_finish.1>
    b933:	00 00 00 
    b936:	e9 0d ee ff ff       	jmp    a748 <fwp_main_thread+0xc28>
    b93b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b940:	66 85 c0             	test   %ax,%ax
    b943:	0f 85 47 fa ff ff    	jne    b390 <fwp_main_thread+0x1870>
    b949:	e9 1a fa ff ff       	jmp    b368 <fwp_main_thread+0x1848>
    b94e:	66 90                	xchg   %ax,%ax
    b950:	66 85 c0             	test   %ax,%ax
    b953:	0f 85 a8 ed ff ff    	jne    a701 <fwp_main_thread+0xbe1>
    b959:	e9 7b ed ff ff       	jmp    a6d9 <fwp_main_thread+0xbb9>
    b95e:	66 90                	xchg   %ax,%ax
    b960:	49 39 d9             	cmp    %rbx,%r9
    b963:	0f 8f 07 ff ff ff    	jg     b870 <fwp_main_thread+0x1d50>
    b969:	4d 85 c0             	test   %r8,%r8
    b96c:	0f 85 8c 02 00 00    	jne    bbfe <fwp_main_thread+0x20de>
    b972:	4d 85 c9             	test   %r9,%r9
    b975:	0f 85 6a 05 00 00    	jne    bee5 <fwp_main_thread+0x23c5>
    b97b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    b982:	e9 a5 f2 ff ff       	jmp    ac2c <fwp_main_thread+0x110c>
    b987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b98e:	00 00 
    b990:	66 85 c0             	test   %ax,%ax
    b993:	0f 85 28 f4 ff ff    	jne    adc1 <fwp_main_thread+0x12a1>
    b999:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b99e:	0f 85 18 f4 ff ff    	jne    adbc <fwp_main_thread+0x129c>
    b9a4:	4c 89 ef             	mov    %r13,%rdi
    b9a7:	e8 24 9e ff ff       	call   57d0 <fwp_rc_forget_slot>
    b9ac:	e9 0b f4 ff ff       	jmp    adbc <fwp_main_thread+0x129c>
    b9b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b9b8:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    b9bf:	00 
    b9c0:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    b9c7:	00 
    b9c8:	4c 89 f0             	mov    %r14,%rax
    b9cb:	49 8b 6e 10          	mov    0x10(%r14),%rbp
    b9cf:	48 29 c8             	sub    %rcx,%rax
    b9d2:	48 c1 e2 10          	shl    $0x10,%rdx
    b9d6:	48 39 d0             	cmp    %rdx,%rax
    b9d9:	73 67                	jae    ba42 <fwp_main_thread+0x1f22>
    b9db:	48 89 c7             	mov    %rax,%rdi
    b9de:	48 c1 ef 10          	shr    $0x10,%rdi
    b9e2:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    b9e6:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b9ea:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    b9ee:	48 85 ff             	test   %rdi,%rdi
    b9f1:	74 4f                	je     ba42 <fwp_main_thread+0x1f22>
    b9f3:	44 0f b6 06          	movzbl (%rsi),%r8d
    b9f7:	41 80 f8 02          	cmp    $0x2,%r8b
    b9fb:	0f 84 8e 02 00 00    	je     bc8f <fwp_main_thread+0x216f>
    ba01:	41 80 f8 01          	cmp    $0x1,%r8b
    ba05:	75 3b                	jne    ba42 <fwp_main_thread+0x1f22>
    ba07:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    ba0b:	0f b7 c0             	movzwl %ax,%eax
    ba0e:	8b 76 1c             	mov    0x1c(%rsi),%esi
    ba11:	49 0f af c0          	imul   %r8,%rax
    ba15:	48 c1 e8 20          	shr    $0x20,%rax
    ba19:	48 39 f0             	cmp    %rsi,%rax
    ba1c:	73 24                	jae    ba42 <fwp_main_thread+0x1f22>
    ba1e:	48 01 c7             	add    %rax,%rdi
    ba21:	80 3f 01             	cmpb   $0x1,(%rdi)
    ba24:	75 1c                	jne    ba42 <fwp_main_thread+0x1f22>
    ba26:	4c 89 f7             	mov    %r14,%rdi
    ba29:	e8 e2 9f ff ff       	call   5a10 <fwp_mem_free>
    ba2e:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    ba35:	00 
    ba36:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    ba3d:	00 
    ba3e:	48 c1 e2 10          	shl    $0x10,%rdx
    ba42:	48 89 e8             	mov    %rbp,%rax
    ba45:	48 29 c8             	sub    %rcx,%rax
    ba48:	48 39 d0             	cmp    %rdx,%rax
    ba4b:	0f 83 3f f9 ff ff    	jae    b390 <fwp_main_thread+0x1870>
    ba51:	49 89 ee             	mov    %rbp,%r14
    ba54:	e9 c5 f8 ff ff       	jmp    b31e <fwp_main_thread+0x17fe>
    ba59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ba60:	66 85 c0             	test   %ax,%ax
    ba63:	0f 85 68 fc ff ff    	jne    b6d1 <fwp_main_thread+0x1bb1>
    ba69:	41 80 3f ff          	cmpb   $0xff,(%r15)
    ba6d:	0f 85 5a fc ff ff    	jne    b6cd <fwp_main_thread+0x1bad>
    ba73:	4c 89 ff             	mov    %r15,%rdi
    ba76:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
    ba7b:	e8 50 9d ff ff       	call   57d0 <fwp_rc_forget_slot>
    ba80:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
    ba85:	e9 43 fc ff ff       	jmp    b6cd <fwp_main_thread+0x1bad>
    ba8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ba90:	48 85 db             	test   %rbx,%rbx
    ba93:	0f 85 6a ef ff ff    	jne    aa03 <fwp_main_thread+0xee3>
    ba99:	e9 e2 ef ff ff       	jmp    aa80 <fwp_main_thread+0xf60>
    ba9e:	66 90                	xchg   %ax,%ax
    baa0:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    baa7:	ff ff 1f 
    baaa:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
    baae:	48 39 c2             	cmp    %rax,%rdx
    bab1:	0f 82 c6 04 00 00    	jb     bf7d <fwp_main_thread+0x245d>
    bab7:	48 8d 05 02 57 04 00 	lea    0x45702(%rip),%rax        # 511c0 <ad_raw_blocks>
    babe:	45 31 ed             	xor    %r13d,%r13d
    bac1:	eb 32                	jmp    baf5 <fwp_main_thread+0x1fd5>
    bac3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    baca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bad1:	00 00 00 00 
    bad5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    badc:	00 00 00 00 
    bae0:	49 83 c5 01          	add    $0x1,%r13
    bae4:	48 83 c0 18          	add    $0x18,%rax
    bae8:	49 81 fd 00 10 00 00 	cmp    $0x1000,%r13
    baef:	0f 84 f3 02 00 00    	je     bde8 <fwp_main_thread+0x22c8>
    baf5:	48 83 38 00          	cmpq   $0x0,(%rax)
    baf9:	75 e5                	jne    bae0 <fwp_main_thread+0x1fc0>
    bafb:	be 08 00 00 00       	mov    $0x8,%esi
    bb00:	48 89 df             	mov    %rbx,%rdi
    bb03:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    bb08:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    bb0d:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    bb12:	e8 f9 79 ff ff       	call   3510 <calloc@plt>
    bb17:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    bb1c:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    bb22:	48 8d 15 97 56 04 00 	lea    0x45697(%rip),%rdx        # 511c0 <ad_raw_blocks>
    bb29:	48 85 c0             	test   %rax,%rax
    bb2c:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    bb32:	0f 84 88 00 00 00    	je     bbc0 <fwp_main_thread+0x20a0>
    bb38:	4b 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%rcx
    bb3d:	48 89 c6             	mov    %rax,%rsi
    bb40:	4c 89 4c 24 30       	mov    %r9,0x30(%rsp)
    bb45:	48 8d 3c ca          	lea    (%rdx,%rcx,8),%rdi
    bb49:	b9 03 00 00 00       	mov    $0x3,%ecx
    bb4e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    bb53:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    bb5a:	00 
    bb5b:	e8 a0 80 ff ff       	call   3c00 <ad_raw_record>
    bb60:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
    bb65:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    bb6a:	e9 75 fd ff ff       	jmp    b8e4 <fwp_main_thread+0x1dc4>
    bb6f:	90                   	nop
    bb70:	66 85 c0             	test   %ax,%ax
    bb73:	0f 85 cc ea ff ff    	jne    a645 <fwp_main_thread+0xb25>
    bb79:	e9 8b ea ff ff       	jmp    a609 <fwp_main_thread+0xae9>
    bb7e:	66 90                	xchg   %ax,%ax
    bb80:	66 85 c0             	test   %ax,%ax
    bb83:	0f 85 c7 f9 ff ff    	jne    b550 <fwp_main_thread+0x1a30>
    bb89:	0f b6 03             	movzbl (%rbx),%eax
    bb8c:	84 c0                	test   %al,%al
    bb8e:	0f 85 a0 f9 ff ff    	jne    b534 <fwp_main_thread+0x1a14>
    bb94:	e9 b7 f9 ff ff       	jmp    b550 <fwp_main_thread+0x1a30>
    bb99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bba0:	66 85 c0             	test   %ax,%ax
    bba3:	0f 85 ed f8 ff ff    	jne    b496 <fwp_main_thread+0x1976>
    bba9:	41 80 3e ff          	cmpb   $0xff,(%r14)
    bbad:	0f 85 df f8 ff ff    	jne    b492 <fwp_main_thread+0x1972>
    bbb3:	4c 89 f7             	mov    %r14,%rdi
    bbb6:	e8 15 9c ff ff       	call   57d0 <fwp_rc_forget_slot>
    bbbb:	e9 d2 f8 ff ff       	jmp    b492 <fwp_main_thread+0x1972>
    bbc0:	48 85 ed             	test   %rbp,%rbp
    bbc3:	0f 85 1c 03 00 00    	jne    bee5 <fwp_main_thread+0x23c5>
    bbc9:	45 31 c0             	xor    %r8d,%r8d
    bbcc:	e9 2c fd ff ff       	jmp    b8fd <fwp_main_thread+0x1ddd>
    bbd1:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    bbd5:	e9 6f e1 ff ff       	jmp    9d49 <fwp_main_thread+0x229>
    bbda:	be 68 00 00 00       	mov    $0x68,%esi
    bbdf:	41 bf 01 00 00 00    	mov    $0x1,%r15d
    bbe5:	e9 e1 eb ff ff       	jmp    a7cb <fwp_main_thread+0xcab>
    bbea:	48 89 ef             	mov    %rbp,%rdi
    bbed:	e8 1e 9e ff ff       	call   5a10 <fwp_mem_free>
    bbf2:	e9 59 f9 ff ff       	jmp    b550 <fwp_main_thread+0x1a30>
    bbf7:	31 db                	xor    %ebx,%ebx
    bbf9:	e9 0d e2 ff ff       	jmp    9e0b <fwp_main_thread+0x2eb>
    bbfe:	4d 85 c9             	test   %r9,%r9
    bc01:	0f 84 74 fd ff ff    	je     b97b <fwp_main_thread+0x1e5b>
    bc07:	4c 89 cd             	mov    %r9,%rbp
    bc0a:	4c 89 c7             	mov    %r8,%rdi
    bc0d:	31 f6                	xor    %esi,%esi
    bc0f:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
    bc14:	4c 8d 6d ff          	lea    -0x1(%rbp),%r13
    bc18:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    bc1f:	00 
    bc20:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    bc25:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    bc2a:	e8 81 78 ff ff       	call   34b0 <memset@plt>
    bc2f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
    bc34:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    bc3a:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    bc40:	49 89 c0             	mov    %rax,%r8
    bc43:	e9 bc fc ff ff       	jmp    b904 <fwp_main_thread+0x1de4>
    bc48:	66 85 c0             	test   %ax,%ax
    bc4b:	0f 85 7e e8 ff ff    	jne    a4cf <fwp_main_thread+0x9af>
    bc51:	e9 6b e8 ff ff       	jmp    a4c1 <fwp_main_thread+0x9a1>
    bc56:	66 85 c0             	test   %ax,%ax
    bc59:	0f 85 d3 e7 ff ff    	jne    a432 <fwp_main_thread+0x912>
    bc5f:	e9 c0 e7 ff ff       	jmp    a424 <fwp_main_thread+0x904>
    bc64:	66 85 c0             	test   %ax,%ax
    bc67:	0f 85 16 e9 ff ff    	jne    a583 <fwp_main_thread+0xa63>
    bc6d:	e9 f5 e8 ff ff       	jmp    a567 <fwp_main_thread+0xa47>
    bc72:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
    bc77:	4c 8b 34 24          	mov    (%rsp),%r14
    bc7b:	31 db                	xor    %ebx,%ebx
    bc7d:	e9 6e f6 ff ff       	jmp    b2f0 <fwp_main_thread+0x17d0>
    bc82:	4c 89 ef             	mov    %r13,%rdi
    bc85:	e8 46 9b ff ff       	call   57d0 <fwp_rc_forget_slot>
    bc8a:	e9 62 e6 ff ff       	jmp    a2f1 <fwp_main_thread+0x7d1>
    bc8f:	66 85 c0             	test   %ax,%ax
    bc92:	0f 85 aa fd ff ff    	jne    ba42 <fwp_main_thread+0x1f22>
    bc98:	e9 84 fd ff ff       	jmp    ba21 <fwp_main_thread+0x1f01>
    bc9d:	4c 8b 74 24 78       	mov    0x78(%rsp),%r14
    bca2:	48 8b 3c 24          	mov    (%rsp),%rdi
    bca6:	e8 d5 c2 ff ff       	call   7f80 <fwp_drop0>
    bcab:	4c 89 f7             	mov    %r14,%rdi
    bcae:	e8 cd c2 ff ff       	call   7f80 <fwp_drop0>
    bcb3:	48 c7 05 aa 53 00 00 	movq   $0x0,0x53aa(%rip)        # 11068 <v.2>
    bcba:	00 00 00 00 
    bcbe:	c7 05 a8 53 00 00 01 	movl   $0x1,0x53a8(%rip)        # 11070 <st.3>
    bcc5:	00 00 00 
    bcc8:	e9 c8 df ff ff       	jmp    9c95 <fwp_main_thread+0x175>
    bccd:	48 89 ea             	mov    %rbp,%rdx
    bcd0:	48 c1 ea 11          	shr    $0x11,%rdx
    bcd4:	48 31 ea             	xor    %rbp,%rdx
    bcd7:	48 89 d0             	mov    %rdx,%rax
    bcda:	48 c1 e8 09          	shr    $0x9,%rax
    bcde:	48 31 c2             	xor    %rax,%rdx
    bce1:	0f b6 d2             	movzbl %dl,%edx
    bce4:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bceb:	00 
    bcec:	48 85 c0             	test   %rax,%rax
    bcef:	75 18                	jne    bd09 <fwp_main_thread+0x21e9>
    bcf1:	e9 82 00 00 00       	jmp    bd78 <fwp_main_thread+0x2258>
    bcf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bcfd:	00 00 00 
    bd00:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bd04:	48 85 c0             	test   %rax,%rax
    bd07:	74 6f                	je     bd78 <fwp_main_thread+0x2258>
    bd09:	48 89 c2             	mov    %rax,%rdx
    bd0c:	48 3b 28             	cmp    (%rax),%rbp
    bd0f:	75 ef                	jne    bd00 <fwp_main_thread+0x21e0>
    bd11:	48 8b 78 08          	mov    0x8(%rax),%rdi
    bd15:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    bd19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bd1d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bd24:	0f 85 66 f6 ff ff    	jne    b390 <fwp_main_thread+0x1870>
    bd2a:	48 89 ef             	mov    %rbp,%rdi
    bd2d:	e8 9e 9a ff ff       	call   57d0 <fwp_rc_forget_slot>
    bd32:	c6 45 00 fe          	movb   $0xfe,0x0(%rbp)
    bd36:	e9 55 f6 ff ff       	jmp    b390 <fwp_main_thread+0x1870>
    bd3b:	4c 8b 34 24          	mov    (%rsp),%r14
    bd3f:	31 db                	xor    %ebx,%ebx
    bd41:	e9 aa f5 ff ff       	jmp    b2f0 <fwp_main_thread+0x17d0>
    bd46:	e8 65 99 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bd4b:	e9 b1 e9 ff ff       	jmp    a701 <fwp_main_thread+0xbe1>
    bd50:	48 89 d8             	mov    %rbx,%rax
    bd53:	48 c1 e8 11          	shr    $0x11,%rax
    bd57:	48 31 d8             	xor    %rbx,%rax
    bd5a:	48 89 c2             	mov    %rax,%rdx
    bd5d:	48 c1 ea 09          	shr    $0x9,%rdx
    bd61:	48 31 d0             	xor    %rdx,%rax
    bd64:	0f b6 d0             	movzbl %al,%edx
    bd67:	49 8b 84 d4 48 14 00 	mov    0x1448(%r12,%rdx,8),%rax
    bd6e:	00 
    bd6f:	48 85 c0             	test   %rax,%rax
    bd72:	0f 85 b5 00 00 00    	jne    be2d <fwp_main_thread+0x230d>
    bd78:	48 8d 3d 71 1c 00 00 	lea    0x1c71(%rip),%rdi        # d9f0 <_IO_stdin_used+0x9f0>
    bd7f:	e8 cc 86 ff ff       	call   4450 <fwp_trap>
    bd84:	48 8b 3d 15 f7 05 00 	mov    0x5f715(%rip),%rdi        # 6b4a0 <fwp_state>
    bd8b:	e8 80 9c ff ff       	call   5a10 <fwp_mem_free>
    bd90:	48 c7 05 05 f7 05 00 	movq   $0x0,0x5f705(%rip)        # 6b4a0 <fwp_state>
    bd97:	00 00 00 00 
    bd9b:	48 c7 05 ea f6 05 00 	movq   $0x0,0x5f6ea(%rip)        # 6b490 <fwp_state_cap>
    bda2:	00 00 00 00 
    bda6:	48 85 db             	test   %rbx,%rbx
    bda9:	0f 84 e2 00 00 00    	je     be91 <fwp_main_thread+0x2371>
    bdaf:	48 3b 1d 42 da 05 00 	cmp    0x5da42(%rip),%rbx        # 697f8 <fwp_root>
    bdb6:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    bdbd:	00 00 00 00 
    bdc1:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    bdc8:	00 00 00 00 
    bdcc:	c7 05 aa 52 01 00 00 	movl   $0x0,0x152aa(%rip)        # 21080 <fwp_exit_code>
    bdd3:	00 00 00 
    bdd6:	0f 84 59 e0 ff ff    	je     9e35 <fwp_main_thread+0x315>
    bddc:	e9 6a 79 ff ff       	jmp    374b <fwp_main_thread.cold>
    bde1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bde8:	48 8d 3d 23 13 00 00 	lea    0x1323(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    bdef:	e8 0c 82 ff ff       	call   4000 <ad_raw_fail>
    bdf4:	e8 b7 98 ff ff       	call   56b0 <fwp_rc_wide_dup>
    bdf9:	49 8b 94 24 d8 13 00 	mov    0x13d8(%r12),%rdx
    be00:	00 
    be01:	49 8b 8c 24 b0 13 00 	mov    0x13b0(%r12),%rcx
    be08:	00 
    be09:	48 c1 e2 10          	shl    $0x10,%rdx
    be0d:	e9 33 e8 ff ff       	jmp    a645 <fwp_main_thread+0xb25>
    be12:	0f 1f 00             	nopl   (%rax)
    be15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    be1c:	00 00 00 00 
    be20:	48 8b 42 10          	mov    0x10(%rdx),%rax
    be24:	48 85 c0             	test   %rax,%rax
    be27:	0f 84 4b ff ff ff    	je     bd78 <fwp_main_thread+0x2258>
    be2d:	48 89 c2             	mov    %rax,%rdx
    be30:	48 39 18             	cmp    %rbx,(%rax)
    be33:	75 eb                	jne    be20 <fwp_main_thread+0x2300>
    be35:	48 8b 78 08          	mov    0x8(%rax),%rdi
    be39:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    be3d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    be41:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    be48:	0f 85 02 f7 ff ff    	jne    b550 <fwp_main_thread+0x1a30>
    be4e:	48 89 df             	mov    %rbx,%rdi
    be51:	e8 7a 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    be56:	c6 03 fe             	movb   $0xfe,(%rbx)
    be59:	e9 f2 f6 ff ff       	jmp    b550 <fwp_main_thread+0x1a30>
    be5e:	48 8d 3d 5d 13 00 00 	lea    0x135d(%rip),%rdi        # d1c2 <_IO_stdin_used+0x1c2>
    be65:	e8 e6 85 ff ff       	call   4450 <fwp_trap>
    be6a:	48 89 ef             	mov    %rbp,%rdi
    be6d:	e8 5e 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    be72:	e9 b7 e5 ff ff       	jmp    a42e <fwp_main_thread+0x90e>
    be77:	48 89 ef             	mov    %rbp,%rdi
    be7a:	e8 51 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    be7f:	e9 47 e6 ff ff       	jmp    a4cb <fwp_main_thread+0x9ab>
    be84:	48 89 ef             	mov    %rbp,%rdi
    be87:	e8 44 99 ff ff       	call   57d0 <fwp_rc_forget_slot>
    be8c:	e9 e0 e6 ff ff       	jmp    a571 <fwp_main_thread+0xa51>
    be91:	48 83 3d 5f d9 05 00 	cmpq   $0x0,0x5d95f(%rip)        # 697f8 <fwp_root>
    be98:	00 
    be99:	c7 05 dd 51 01 00 00 	movl   $0x0,0x151dd(%rip)        # 21080 <fwp_exit_code>
    bea0:	00 00 00 
    bea3:	0f 84 ed df ff ff    	je     9e96 <fwp_main_thread+0x376>
    bea9:	e9 9d 78 ff ff       	jmp    374b <fwp_main_thread.cold>
    beae:	66 90                	xchg   %ax,%ax
    beb0:	48 8d 3d 61 1b 00 00 	lea    0x1b61(%rip),%rdi        # da18 <_IO_stdin_used+0xa18>
    beb7:	e8 94 85 ff ff       	call   4450 <fwp_trap>
    bebc:	48 8d 3d 55 1c 00 00 	lea    0x1c55(%rip),%rdi        # db18 <_IO_stdin_used+0xb18>
    bec3:	e8 88 85 ff ff       	call   4450 <fwp_trap>
    bec8:	e8 33 78 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    becd:	48 8d 3d 17 13 00 00 	lea    0x1317(%rip),%rdi        # d1eb <_IO_stdin_used+0x1eb>
    bed4:	e8 77 85 ff ff       	call   4450 <fwp_trap>
    bed9:	48 8d 3d b7 13 00 00 	lea    0x13b7(%rip),%rdi        # d297 <_IO_stdin_used+0x297>
    bee0:	e8 6b 85 ff ff       	call   4450 <fwp_trap>
    bee5:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
    beec:	00 
    beed:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    bef2:	48 89 05 bf f5 05 00 	mov    %rax,0x5f5bf(%rip)        # 6b4b8 <fwp_cleanups>
    bef9:	e8 62 93 ff ff       	call   5260 <fwp_tape_buffers_release>
    befe:	48 8b 0d 3b 51 00 00 	mov    0x513b(%rip),%rcx        # 11040 <stderr@GLIBC_2.2.5>
    bf05:	ba 13 00 00 00       	mov    $0x13,%edx
    bf0a:	be 01 00 00 00       	mov    $0x1,%esi
    bf0f:	48 8d 3d f2 10 00 00 	lea    0x10f2(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    bf16:	e8 45 77 ff ff       	call   3660 <fwrite@plt>
    bf1b:	31 ff                	xor    %edi,%edi
    bf1d:	e8 7e 76 ff ff       	call   35a0 <fflush@plt>
    bf22:	bf 66 00 00 00       	mov    $0x66,%edi
    bf27:	e8 54 77 ff ff       	call   3680 <_Exit@plt>
    bf2c:	48 8d 3d 9a 13 00 00 	lea    0x139a(%rip),%rdi        # d2cd <_IO_stdin_used+0x2cd>
    bf33:	e8 18 85 ff ff       	call   4450 <fwp_trap>
    bf38:	48 8d 3d 81 1b 00 00 	lea    0x1b81(%rip),%rdi        # dac0 <_IO_stdin_used+0xac0>
    bf3f:	e8 0c 85 ff ff       	call   4450 <fwp_trap>
    bf44:	48 8d 3d 15 1b 00 00 	lea    0x1b15(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    bf4b:	e8 00 85 ff ff       	call   4450 <fwp_trap>
    bf50:	48 8d 3d 91 1b 00 00 	lea    0x1b91(%rip),%rdi        # dae8 <_IO_stdin_used+0xae8>
    bf57:	e8 f4 84 ff ff       	call   4450 <fwp_trap>
    bf5c:	0f 1f 40 00          	nopl   0x0(%rax)
    bf60:	48 8d 3d 49 1c 00 00 	lea    0x1c49(%rip),%rdi        # dbb0 <_IO_stdin_used+0xbb0>
    bf67:	e8 e4 84 ff ff       	call   4450 <fwp_trap>
    bf6c:	48 8d 3d 09 13 00 00 	lea    0x1309(%rip),%rdi        # d27c <_IO_stdin_used+0x27c>
    bf73:	e8 88 80 ff ff       	call   4000 <ad_raw_fail>
    bf78:	e8 d3 74 ff ff       	call   3450 <__stack_chk_fail@plt>
    bf7d:	48 8d 3d 2d 13 00 00 	lea    0x132d(%rip),%rdi        # d2b1 <_IO_stdin_used+0x2b1>
    bf84:	e8 77 80 ff ff       	call   4000 <ad_raw_fail>
    bf89:	48 8d 3d 4d 13 00 00 	lea    0x134d(%rip),%rdi        # d2dd <_IO_stdin_used+0x2dd>
    bf90:	e8 bb 84 ff ff       	call   4450 <fwp_trap>
    bf95:	e9 b1 77 ff ff       	jmp    374b <fwp_main_thread.cold>
    bf9a:	e9 ac 77 ff ff       	jmp    374b <fwp_main_thread.cold>
    bf9f:	90                   	nop

000000000000bfa0 <__divmodti4>:
    bfa0:	f3 0f 1e fa          	endbr64
    bfa4:	55                   	push   %rbp
    bfa5:	49 89 f1             	mov    %rsi,%r9
    bfa8:	49 89 d2             	mov    %rdx,%r10
    bfab:	48 89 fe             	mov    %rdi,%rsi
    bfae:	49 89 cb             	mov    %rcx,%r11
    bfb1:	48 89 e5             	mov    %rsp,%rbp
    bfb4:	41 57                	push   %r15
    bfb6:	41 56                	push   %r14
    bfb8:	41 55                	push   %r13
    bfba:	41 54                	push   %r12
    bfbc:	53                   	push   %rbx
    bfbd:	4c 89 c3             	mov    %r8,%rbx
    bfc0:	45 31 c0             	xor    %r8d,%r8d
    bfc3:	4d 85 c9             	test   %r9,%r9
    bfc6:	79 12                	jns    bfda <__divmodti4+0x3a>
    bfc8:	31 ff                	xor    %edi,%edi
    bfca:	48 f7 de             	neg    %rsi
    bfcd:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bfd4:	4c 19 cf             	sbb    %r9,%rdi
    bfd7:	49 89 f9             	mov    %rdi,%r9
    bfda:	4c 89 d8             	mov    %r11,%rax
    bfdd:	4d 85 db             	test   %r11,%r11
    bfe0:	0f 88 1a 01 00 00    	js     c100 <__divmodti4+0x160>
    bfe6:	4c 89 d9             	mov    %r11,%rcx
    bfe9:	49 89 f3             	mov    %rsi,%r11
    bfec:	75 62                	jne    c050 <__divmodti4+0xb0>
    bfee:	4d 89 c4             	mov    %r8,%r12
    bff1:	4d 39 d1             	cmp    %r10,%r9
    bff4:	0f 83 46 01 00 00    	jae    c140 <__divmodti4+0x1a0>
    bffa:	4c 89 d8             	mov    %r11,%rax
    bffd:	4c 89 ca             	mov    %r9,%rdx
    c000:	49 f7 f2             	div    %r10
    c003:	49 89 c3             	mov    %rax,%r11
    c006:	31 c0                	xor    %eax,%eax
    c008:	48 89 d6             	mov    %rdx,%rsi
    c00b:	31 ff                	xor    %edi,%edi
    c00d:	4c 89 d9             	mov    %r11,%rcx
    c010:	48 89 c2             	mov    %rax,%rdx
    c013:	48 89 c8             	mov    %rcx,%rax
    c016:	4d 85 e4             	test   %r12,%r12
    c019:	74 0a                	je     c025 <__divmodti4+0x85>
    c01b:	48 f7 d8             	neg    %rax
    c01e:	48 83 d2 00          	adc    $0x0,%rdx
    c022:	48 f7 da             	neg    %rdx
    c025:	4d 85 c0             	test   %r8,%r8
    c028:	74 0a                	je     c034 <__divmodti4+0x94>
    c02a:	48 f7 de             	neg    %rsi
    c02d:	48 83 d7 00          	adc    $0x0,%rdi
    c031:	48 f7 df             	neg    %rdi
    c034:	48 89 33             	mov    %rsi,(%rbx)
    c037:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    c03b:	5b                   	pop    %rbx
    c03c:	41 5c                	pop    %r12
    c03e:	41 5d                	pop    %r13
    c040:	41 5e                	pop    %r14
    c042:	41 5f                	pop    %r15
    c044:	5d                   	pop    %rbp
    c045:	c3                   	ret
    c046:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c04d:	00 00 00 
    c050:	4d 89 c4             	mov    %r8,%r12
    c053:	49 39 c1             	cmp    %rax,%r9
    c056:	0f 82 ce 00 00 00    	jb     c12a <__divmodti4+0x18a>
    c05c:	31 ff                	xor    %edi,%edi
    c05e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    c063:	48 63 c7             	movslq %edi,%rax
    c066:	be 40 00 00 00       	mov    $0x40,%esi
    c06b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    c070:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    c075:	48 29 c6             	sub    %rax,%rsi
    c078:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    c07d:	48 09 c8             	or     %rcx,%rax
    c080:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    c085:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    c08a:	49 89 c6             	mov    %rax,%r14
    c08d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    c091:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    c096:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    c09b:	49 09 c1             	or     %rax,%r9
    c09e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    c0a2:	4c 89 c8             	mov    %r9,%rax
    c0a5:	49 f7 f6             	div    %r14
    c0a8:	48 89 d1             	mov    %rdx,%rcx
    c0ab:	49 89 c3             	mov    %rax,%r11
    c0ae:	49 89 c1             	mov    %rax,%r9
    c0b1:	49 f7 e2             	mul    %r10
    c0b4:	49 89 c6             	mov    %rax,%r14
    c0b7:	49 89 d2             	mov    %rdx,%r10
    c0ba:	48 39 d1             	cmp    %rdx,%rcx
    c0bd:	72 07                	jb     c0c6 <__divmodti4+0x126>
    c0bf:	75 17                	jne    c0d8 <__divmodti4+0x138>
    c0c1:	49 39 c7             	cmp    %rax,%r15
    c0c4:	73 12                	jae    c0d8 <__divmodti4+0x138>
    c0c6:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    c0ca:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    c0ce:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    c0d2:	49 89 d2             	mov    %rdx,%r10
    c0d5:	49 89 c6             	mov    %rax,%r14
    c0d8:	4c 89 f8             	mov    %r15,%rax
    c0db:	4c 29 f0             	sub    %r14,%rax
    c0de:	4c 19 d1             	sbb    %r10,%rcx
    c0e1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    c0e6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    c0eb:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    c0f0:	48 09 c6             	or     %rax,%rsi
    c0f3:	48 89 cf             	mov    %rcx,%rdi
    c0f6:	31 c0                	xor    %eax,%eax
    c0f8:	4c 89 c9             	mov    %r9,%rcx
    c0fb:	e9 10 ff ff ff       	jmp    c010 <__divmodti4+0x70>
    c100:	4c 89 d0             	mov    %r10,%rax
    c103:	4c 89 da             	mov    %r11,%rdx
    c106:	4d 89 c4             	mov    %r8,%r12
    c109:	49 89 f3             	mov    %rsi,%r11
    c10c:	48 f7 d8             	neg    %rax
    c10f:	49 f7 d4             	not    %r12
    c112:	48 83 d2 00          	adc    $0x0,%rdx
    c116:	49 89 c2             	mov    %rax,%r10
    c119:	48 f7 da             	neg    %rdx
    c11c:	48 89 d1             	mov    %rdx,%rcx
    c11f:	0f 84 cc fe ff ff    	je     bff1 <__divmodti4+0x51>
    c125:	49 39 d1             	cmp    %rdx,%r9
    c128:	73 46                	jae    c170 <__divmodti4+0x1d0>
    c12a:	4c 89 cf             	mov    %r9,%rdi
    c12d:	31 c0                	xor    %eax,%eax
    c12f:	31 c9                	xor    %ecx,%ecx
    c131:	e9 da fe ff ff       	jmp    c010 <__divmodti4+0x70>
    c136:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c13d:	00 00 00 
    c140:	4d 85 d2             	test   %r10,%r10
    c143:	75 0d                	jne    c152 <__divmodti4+0x1b2>
    c145:	b8 01 00 00 00       	mov    $0x1,%eax
    c14a:	31 d2                	xor    %edx,%edx
    c14c:	49 f7 f2             	div    %r10
    c14f:	49 89 c2             	mov    %rax,%r10
    c152:	4c 89 c8             	mov    %r9,%rax
    c155:	31 d2                	xor    %edx,%edx
    c157:	49 f7 f2             	div    %r10
    c15a:	49 89 c1             	mov    %rax,%r9
    c15d:	4c 89 d8             	mov    %r11,%rax
    c160:	49 f7 f2             	div    %r10
    c163:	49 89 c3             	mov    %rax,%r11
    c166:	4c 89 c8             	mov    %r9,%rax
    c169:	e9 9a fe ff ff       	jmp    c008 <__divmodti4+0x68>
    c16e:	66 90                	xchg   %ax,%ax
    c170:	45 31 f6             	xor    %r14d,%r14d
    c173:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    c178:	44 89 f7             	mov    %r14d,%edi
    c17b:	45 85 f6             	test   %r14d,%r14d
    c17e:	0f 85 df fe ff ff    	jne    c063 <__divmodti4+0xc3>
    c184:	4c 39 ca             	cmp    %r9,%rdx
    c187:	72 17                	jb     c1a0 <__divmodti4+0x200>
    c189:	31 c9                	xor    %ecx,%ecx
    c18b:	48 39 c6             	cmp    %rax,%rsi
    c18e:	73 10                	jae    c1a0 <__divmodti4+0x200>
    c190:	4c 89 cf             	mov    %r9,%rdi
    c193:	31 c0                	xor    %eax,%eax
    c195:	e9 76 fe ff ff       	jmp    c010 <__divmodti4+0x70>
    c19a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c1a0:	4c 89 de             	mov    %r11,%rsi
    c1a3:	b9 01 00 00 00       	mov    $0x1,%ecx
    c1a8:	48 29 c6             	sub    %rax,%rsi
    c1ab:	49 19 d1             	sbb    %rdx,%r9
    c1ae:	eb e0                	jmp    c190 <__divmodti4+0x1f0>

000000000000c1b0 <atexit>:
    c1b0:	f3 0f 1e fa          	endbr64
    c1b4:	48 8b 15 4d 4e 00 00 	mov    0x4e4d(%rip),%rdx        # 11008 <__dso_handle>
    c1bb:	31 f6                	xor    %esi,%esi
    c1bd:	e9 7e 74 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000c1c4 <_fini>:
    c1c4:	f3 0f 1e fa          	endbr64
    c1c8:	48 83 ec 08          	sub    $0x8,%rsp
    c1cc:	48 83 c4 08          	add    $0x8,%rsp
    c1d0:	c3                   	ret
