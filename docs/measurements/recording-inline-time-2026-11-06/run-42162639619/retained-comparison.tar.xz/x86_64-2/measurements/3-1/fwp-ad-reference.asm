
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-reference:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 cf 00 00 	mov    0xcfc9(%rip),%rax        # ffd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 cd 00 00    	push   0xcde2(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 cd 00 00    	jmp    *0xcde4(%rip)        # fe10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e cc 00 00    	jmp    *0xcc4e(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # feb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # feb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ffa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ffa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 89 00 00 	lea    0x897a(%rip),%r9        # c091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 89 00 00 	lea    0x8977(%rip),%r8        # c095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <fwp_main_thread.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <main.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>
    3755:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    375c:	00 00 00 
    375f:	90                   	nop

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 a1 ab 00 00 	lea    0xaba1(%rip),%rax        # e320 <fwp_fn_table>
    377f:	48 89 05 32 ec 01 00 	mov    %rax,0x1ec32(%rip)        # 223b8 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c ec 01 00 	mov    %rax,0x1ec2c(%rip)        # 223c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 8a 00 00 	lea    0x8a59(%rip),%rdi        # c1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 ff 58 00 00 	lea    0x58ff(%rip),%rdx        # 9160 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 d6 fe ff ff    	jne    3750 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 ba fe ff ff    	jne    3750 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 89 00 00 	lea    0x8909(%rip),%rdi        # c202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 96 90 00 00 	lea    0x9096(%rip),%rdi        # c9a0 <_IO_stdin_used+0x9a0>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 2f fe ff ff    	jne    3750 <main.cold>
    3921:	48 8d 3d 50 90 00 00 	lea    0x9050(%rip),%rdi        # c978 <_IO_stdin_used+0x978>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 14 90 00 00 	lea    0x9014(%rip),%rdi        # c948 <_IO_stdin_used+0x948>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d e0 8f 00 00 	lea    0x8fe0(%rip),%rdi        # c920 <_IO_stdin_used+0x920>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 c6 00 00    	call   *0xc653(%rip)        # ffc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 c6 00 00 	mov    0xc636(%rip),%rax        # ffd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 c6 00 00 	mov    0xc605(%rip),%rax        # ffe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 c5 00 00 	cmpq   $0x0,0xc5e2(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args173>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 e7 01 00 	mov    0x1e749(%rip),%rdi        # 223c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ca 01 00 	mov    0x1ca41(%rip),%rax        # 20740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 c3 01 00 	mov    0x1c381(%rip),%rax        # 20100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d c3 01 00 	sub    0x1c36d(%rip),%rax        # 200f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 8c 00 00 	lea    0x8cbd(%rip),%rsi        # ca80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b dd 01 00 	mov    0x1dd5b(%rip),%rax        # 21b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 dd 01 00 	lea    0x1dd54(%rip),%r8        # 21b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 dd 01 00 	mov    0x1dd35(%rip),%rbx        # 21b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 dd 01 00 	mov    0x1dd45(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 dc 01 00 	mov    0x1dce1(%rip),%rdi        # 21b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a dd 01 00 	sub    %rsi,0x1dd2a(%rip)        # 21b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba dc 01 00 	mov    0x1dcba(%rip),%rax        # 21b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 dc 01 00 	add    0x1dc70(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e dc 01 00 	mov    0x1dc7e(%rip),%rsi        # 21b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c dc 01 00 	mov    0x1dc8c(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b dc 01 00 	mov    %r12,0x1dc3b(%rip)        # 21b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 dc 01 00 	mov    %rbp,0x1dc29(%rip)        # 21b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e dc 01 00 	cmp    %rdi,0x1dc0e(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 dc 01 00 	mov    %rdi,0x1dc05(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 dc 01 00 	sub    %rdi,0x1dc49(%rip)        # 21b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 db 01 00 	mov    0x1dbf1(%rip),%rax        # 21b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea db 01 00 	lea    0x1dbea(%rip),%r8        # 21b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd bf 00 00 	mov    0xbffd(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 7f 00 00 	lea    0x7fb4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 c6 01 00 	cmp    0x1c689(%rip),%rdi        # 20740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f c6 01 00 	mov    0x1c64f(%rip),%rax        # 20720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d c6 01 00 	mov    %rdi,0x1c62d(%rip)        # 20720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 c6 01 00 	mov    %rdi,0x1c609(%rip)        # 20728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 db 7f 00 00 	lea    0x7fdb(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 7e 00 00 	lea    0x7ea7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 be 00 00 	mov    0xbe78(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 7e 00 00 	lea    0x7e51(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 be 00 00 	mov    0xbe60(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 bd 00 00 	mov    0xbd71(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 7d 00 00 	lea    0x7d28(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 7d 00 00 	lea    0x7d32(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 7c 00 00 	lea    0x7cba(%rip),%rdi        # c049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 70 82 00 00 	lea    0x8270(%rip),%rdi        # c610 <_IO_stdin_used+0x610>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 10 87 00 	movdqa 0x8710(%rip),%xmm0        # cad0 <msg.4+0x50>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a df 01 00 	add    0x1df9a(%rip),%rax        # 223b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d cc 81 00 00 	lea    0x81cc(%rip),%rdi        # c640 <_IO_stdin_used+0x640>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 bc 01 00 	cmp    %rax,0x1bc55(%rip)        # 200e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 bc 01 00 	add    0x1bc50(%rip),%rax        # 200f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d b5 81 00 00 	lea    0x81b5(%rip),%rdi        # c670 <_IO_stdin_used+0x670>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 7b 00 00 	lea    0x7b92(%rip),%r8        # c065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 79 00 00 	lea    0x79e7(%rip),%r8        # c074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 78 00 00 	lea    0x7874(%rip),%r8        # c06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 76 00 00 	lea    0x764c(%rip),%rdi        # c079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 36 77 00 00 	lea    0x7736(%rip),%rsi        # c184 <_IO_stdin_used+0x184>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 d0 01 00 	mov    0x1d065(%rip),%r9        # 21b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be d0 01 00 	mov    0x1d0be(%rip),%r8        # 21b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 ef 7b 00 00 	lea    0x7bef(%rip),%rdx        # c6c0 <_IO_stdin_used+0x6c0>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 d0 01 00 	mov    0x1d0a6(%rip),%rcx        # 21b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 d0 01 	movsd  0x1d0b4(%rip),%xmm1        # 21ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 d0 01 	movsd  0x1d0a4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 b5 00 00 	mov    0xb545(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 a8 7f 00 	movdqa 0x7fa8(%rip),%xmm0        # cae0 <msg.4+0x60>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f cb 01 00 	lea    0x1cb5f(%rip),%rax        # 216a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 d1 7f 00 	movdqa 0x7fd1(%rip),%xmm2        # cb20 <msg.4+0xa0>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 cb 01 00 	movaps %xmm0,0x1cb05(%rip)        # 21660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 8d 7f 00 	movdqa 0x7f8d(%rip),%xmm0        # caf0 <msg.4+0x70>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 cf 01 00 01 	movl   $0x1,0x1cf93(%rip)        # 21b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ca 01 00 	movaps %xmm0,0x1caf3(%rip)        # 21670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 7b 7f 00 	movdqa 0x7f7b(%rip),%xmm0        # cb00 <msg.4+0x80>
    4b84:	00 
    4b85:	0f 29 05 f4 ca 01 00 	movaps %xmm0,0x1caf4(%rip)        # 21680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 7c 7f 00 	movdqa 0x7f7c(%rip),%xmm0        # cb10 <msg.4+0x90>
    4b93:	00 
    4b94:	0f 29 05 f5 ca 01 00 	movaps %xmm0,0x1caf5(%rip)        # 21690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 bb 01 00 	lea    0x1bb75(%rip),%r8        # 20760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ce 01 00 	mov    %rax,0x1ce90(%rip)        # 21b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ce 01 00 	mov    %r12,0x1ce6e(%rip)        # 21b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ce 01 00 	mov    %rax,0x1ce57(%rip)        # 21b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ce 01 00 	mov    %rbx,0x1ce70(%rip)        # 21b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ce 01 00 	mov    %rsi,0x1ce99(%rip)        # 21b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 73 00 00 	lea    0x73d6(%rip),%rdi        # c0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ce 01 00 	mov    %rax,0x1ce78(%rip)        # 21b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc cd 01 00    	mov    %eax,0x1cdfc(%rip)        # 21b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec b9 01 00 	mov    0x1b9ec(%rip),%r8        # 20720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c b9 01 00 	mov    %rbx,0x1b91c(%rip)        # 20728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 b9 01 00 	mov    %r8,0x1b908(%rip)        # 20720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 72 00 00 	lea    0x7239(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd b1 01 00 	lea    0x1b1dd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 b1 01 00 	movaps %xmm0,0x1b1c5(%rip)        # 200a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 b1 01 00 	mov    %rax,0x1b1a1(%rip)        # 20088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 b1 01 00 	movaps %xmm0,0x1b1c2(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 b1 01 00 	movaps %xmm0,0x1b1c6(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 b1 01 00 	mov    %rdx,0x1b1c7(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 71 00 00 	lea    0x7190(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 b7 01 00 	mov    0x1b797(%rip),%rbx        # 20718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca af 00 00 	mov    0xafca(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d cb 76 00 00 	lea    0x76cb(%rip),%rdi        # c748 <_IO_stdin_used+0x748>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d b6 01 00 	mov    0x1b66d(%rip),%rax        # 20720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 b6 01 00 	mov    %rdx,0x1b647(%rip)        # 20720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 b5 01 00 	mov    0x1b594(%rip),%rbx        # 20718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 b5 01 00 	mov    %rbx,0x1b551(%rip)        # 20718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 b5 01 00 	mov    %rdx,0x1b551(%rip)        # 20728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 b5 01 00 	lea    0x1b566(%rip),%rsi        # 20760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 d0 01 00 	addq   $0x1,0x1d0e5(%rip)        # 223a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 9f 74 00 00 	lea    0x749f(%rip),%rdi        # c778 <_IO_stdin_used+0x778>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d b0 74 00 00 	lea    0x74b0(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 6d 00 00 	lea    0x6dd4(%rip),%rdi        # c0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e b4 01 00 	lea    0x1b41e(%rip),%rcx        # 20760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f d0 01 00 	subq   $0x1,0x1d01f(%rip)        # 223a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 0b 74 00 00 	lea    0x740b(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 d0 01 00 	cmpq   $0x0,0x1d000(%rip)        # 223a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 cf 01 00 	sub    %rax,0x1cf55(%rip)        # 223b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 cf 01 00 	add    %r12,0x1cf33(%rip)        # 223b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c b2 01 00 	lea    0x1b28c(%rip),%rax        # 20760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 c5 01 00 	add    0x1c5e3(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 c5 01 00 	mov    0x1c5b0(%rip),%rsi        # 21b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 c5 01 00 	mov    0x1c5d1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 c5 01 00 	add    0x1c5c5(%rip),%r8        # 21b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d c5 01 	addsd  0x1c58d(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 b1 01 00 	lea    0x1b142(%rip),%rax        # 20760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c c5 01 00 	sub    %rdi,0x1c54c(%rip)        # 21b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 c5 01 	movsd  %xmm0,0x1c564(%rip)        # 21ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e c5 01 00 	sub    %rdx,0x1c51e(%rip)        # 21b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 c5 01 	addsd  0x1c524(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 c5 01 	movsd  %xmm0,0x1c518(%rip)        # 21ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af c4 01 00 	mov    0x1c4af(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 c4 01 00 	add    %rcx,0x1c4a9(%rip)        # 21b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 c4 01 00 	cmp    0x1c462(%rip),%r9        # 21b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 c4 01 00 	mov    %r9,0x1c459(%rip)        # 21b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a c4 01 00 	cmp    0x1c44a(%rip),%r9        # 21b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d c4 01 00 	mov    %r9,0x1c43d(%rip)        # 21b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 c3 01 00 	add    0x1c353(%rip),%rdi        # 21b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 af 01 00 	lea    0x1af30(%rip),%r15        # 20760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 c2 01 00 	add    0x1c2a0(%rip),%r12        # 21b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 c2 01 00 	add    0x1c2f9(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 c2 01 00 	cmp    %rax,0x1c2f8(%rip)        # 21b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 c2 01 00 	mov    %rax,0x1c2e9(%rip)        # 21b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 c2 01 00 	mov    %rax,0x1c2e8(%rip)        # 21b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 c2 01 	addsd  0x1c2e4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc c2 01 	movsd  %xmm0,0x1c2dc(%rip)        # 21b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 c2 01 00    	mov    0x1c223(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ae 01 00 	lea    0x1ae5f(%rip),%rdi        # 20760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 c2 01 00 	add    0x1c218(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 c2 01 00 	cmp    %rax,0x1c213(%rip)        # 21b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 c2 01 00 	mov    %rax,0x1c204(%rip)        # 21b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 c2 01 00 	mov    %rax,0x1c203(%rip)        # 21b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff c1 01 	addsd  0x1c1ff(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 c1 01 	movsd  %xmm0,0x1c1f7(%rip)        # 21b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae c0 01 00    	mov    0x1c0ae(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 ac 01 00 	lea    0x1ace5(%rip),%rax        # 20760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b c0 01 00 	add    0x1c09b(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a c0 01 00 	cmp    %rax,0x1c09a(%rip)        # 21b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b c0 01 00 	mov    %rax,0x1c08b(%rip)        # 21b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a c0 01 00 	mov    %rax,0x1c08a(%rip)        # 21b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 c0 01 	addsd  0x1c086(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e c0 01 	movsd  %xmm0,0x1c07e(%rip)        # 21b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_data.part.0.constprop.0>:
    5b70:	41 56                	push   %r14
    5b72:	41 89 fe             	mov    %edi,%r14d
    5b75:	41 54                	push   %r12
    5b77:	49 89 f4             	mov    %rsi,%r12
    5b7a:	55                   	push   %rbp
    5b7b:	53                   	push   %rbx
    5b7c:	48 83 ec 08          	sub    $0x8,%rsp
    5b80:	8b 05 7e bf 01 00    	mov    0x1bf7e(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    5b86:	85 c0                	test   %eax,%eax
    5b88:	0f 84 fa 00 00 00    	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5b8e:	0f b6 05 6d bb 01 00 	movzbl 0x1bb6d(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    5b95:	48 8d 15 c4 ab 01 00 	lea    0x1abc4(%rip),%rdx        # 20760 <fwp_heap>
    5b9c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    5ba3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5ba7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    5bab:	48 8b 18             	mov    (%rax),%rbx
    5bae:	48 85 db             	test   %rbx,%rbx
    5bb1:	0f 84 a9 00 00 00    	je     5c60 <fwp_data.part.0.constprop.0+0xf0>
    5bb7:	48 8b 13             	mov    (%rbx),%rdx
    5bba:	48 f7 d2             	not    %rdx
    5bbd:	48 89 10             	mov    %rdx,(%rax)
    5bc0:	48 83 fd 18          	cmp    $0x18,%rbp
    5bc4:	76 1b                	jbe    5be1 <fwp_data.part.0.constprop.0+0x71>
    5bc6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    5bca:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    5bce:	31 f6                	xor    %esi,%esi
    5bd0:	48 c1 e8 03          	shr    $0x3,%rax
    5bd4:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    5bdb:	00 
    5bdc:	e8 df d8 ff ff       	call   34c0 <memset@plt>
    5be1:	48 89 e8             	mov    %rbp,%rax
    5be4:	48 03 05 95 bf 01 00 	add    0x1bf95(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5beb:	0f 82 a8 00 00 00    	jb     5c99 <fwp_data.part.0.constprop.0+0x129>
    5bf1:	48 39 05 90 bf 01 00 	cmp    %rax,0x1bf90(%rip)        # 21b88 <fwp_heap+0x1428>
    5bf8:	48 89 05 81 bf 01 00 	mov    %rax,0x1bf81(%rip)        # 21b80 <fwp_heap+0x1420>
    5bff:	73 07                	jae    5c08 <fwp_data.part.0.constprop.0+0x98>
    5c01:	48 89 05 80 bf 01 00 	mov    %rax,0x1bf80(%rip)        # 21b88 <fwp_heap+0x1428>
    5c08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5c0c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    5c11:	f2 0f 58 05 7f bf 01 	addsd  0x1bf7f(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5c18:	00 
    5c19:	f2 0f 11 05 77 bf 01 	movsd  %xmm0,0x1bf77(%rip)        # 21b98 <fwp_heap+0x1438>
    5c20:	00 
    5c21:	b8 02 00 00 00       	mov    $0x2,%eax
    5c26:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    5c2b:	66 0f 6e c8          	movd   %eax,%xmm1
    5c2f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5c33:	66 0f d6 03          	movq   %xmm0,(%rbx)
    5c37:	49 8b 04 24          	mov    (%r12),%rax
    5c3b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    5c3f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    5c44:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5c48:	48 83 c4 08          	add    $0x8,%rsp
    5c4c:	48 89 d8             	mov    %rbx,%rax
    5c4f:	5b                   	pop    %rbx
    5c50:	5d                   	pop    %rbp
    5c51:	41 5c                	pop    %r12
    5c53:	41 5e                	pop    %r14
    5c55:	c3                   	ret
    5c56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c5d:	00 00 00 
    5c60:	48 8b 58 08          	mov    0x8(%rax),%rbx
    5c64:	48 85 db             	test   %rbx,%rbx
    5c67:	74 1f                	je     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c69:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5c6d:	48 29 da             	sub    %rbx,%rdx
    5c70:	48 39 ea             	cmp    %rbp,%rdx
    5c73:	72 13                	jb     5c88 <fwp_data.part.0.constprop.0+0x118>
    5c75:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    5c79:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c7d:	e9 3e ff ff ff       	jmp    5bc0 <fwp_data.part.0.constprop.0+0x50>
    5c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c88:	31 f6                	xor    %esi,%esi
    5c8a:	bf 18 00 00 00       	mov    $0x18,%edi
    5c8f:	e8 bc fd ff ff       	call   5a50 <fwp_heap_alloc>
    5c94:	48 89 c3             	mov    %rax,%rbx
    5c97:	eb 88                	jmp    5c21 <fwp_data.part.0.constprop.0+0xb1>
    5c99:	e8 12 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c9e:	66 90                	xchg   %ax,%ax

0000000000005ca0 <fwp_p_ad_push>:
    5ca0:	41 57                	push   %r15
    5ca2:	41 56                	push   %r14
    5ca4:	41 55                	push   %r13
    5ca6:	49 89 d5             	mov    %rdx,%r13
    5ca9:	41 54                	push   %r12
    5cab:	49 89 fc             	mov    %rdi,%r12
    5cae:	55                   	push   %rbp
    5caf:	53                   	push   %rbx
    5cb0:	48 83 ec 48          	sub    $0x48,%rsp
    5cb4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    5cb9:	48 85 ff             	test   %rdi,%rdi
    5cbc:	79 09                	jns    5cc7 <fwp_p_ad_push+0x27>
    5cbe:	48 85 d2             	test   %rdx,%rdx
    5cc1:	0f 88 b9 02 00 00    	js     5f80 <fwp_p_ad_push+0x2e0>
    5cc7:	48 89 f8             	mov    %rdi,%rax
    5cca:	48 89 0c 24          	mov    %rcx,(%rsp)
    5cce:	4c 89 c5             	mov    %r8,%rbp
    5cd1:	48 09 d0             	or     %rdx,%rax
    5cd4:	0f 89 7e 02 00 00    	jns    5f58 <fwp_p_ad_push+0x2b8>
    5cda:	48 85 ff             	test   %rdi,%rdi
    5cdd:	0f 89 e6 03 00 00    	jns    60c9 <fwp_p_ad_push+0x429>
    5ce3:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    5ce8:	49 89 d6             	mov    %rdx,%r14
    5ceb:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
    5cf2:	00 
    5cf3:	49 89 d4             	mov    %rdx,%r12
    5cf6:	49 c1 fe 20          	sar    $0x20,%r14
    5cfa:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    5d01:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    5d07:	48 85 ed             	test   %rbp,%rbp
    5d0a:	0f 84 48 03 00 00    	je     6058 <fwp_p_ad_push+0x3b8>
    5d10:	4c 39 75 00          	cmp    %r14,0x0(%rbp)
    5d14:	0f 84 be 02 00 00    	je     5fd8 <fwp_p_ad_push+0x338>
    5d1a:	4c 89 f7             	mov    %r14,%rdi
    5d1d:	e8 5e e7 ff ff       	call   4480 <fwp_tape_of>
    5d22:	48 89 c3             	mov    %rax,%rbx
    5d25:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    5d2a:	0f 85 3e 03 00 00    	jne    606e <fwp_p_ad_push+0x3ce>
    5d30:	4c 89 75 00          	mov    %r14,0x0(%rbp)
    5d34:	48 89 45 08          	mov    %rax,0x8(%rbp)
    5d38:	4c 8b 43 10          	mov    0x10(%rbx),%r8
    5d3c:	49 81 f8 fe ff ff 7f 	cmp    $0x7ffffffe,%r8
    5d43:	0f 8f cd 03 00 00    	jg     6116 <fwp_p_ad_push+0x476>
    5d49:	44 89 e0             	mov    %r12d,%eax
    5d4c:	4c 39 c0             	cmp    %r8,%rax
    5d4f:	0f 8d b5 03 00 00    	jge    610a <fwp_p_ad_push+0x46a>
    5d55:	4d 85 ed             	test   %r13,%r13
    5d58:	78 0c                	js     5d66 <fwp_p_ad_push+0xc6>
    5d5a:	44 89 e8             	mov    %r13d,%eax
    5d5d:	4c 39 c0             	cmp    %r8,%rax
    5d60:	0f 8d a4 03 00 00    	jge    610a <fwp_p_ad_push+0x46a>
    5d66:	4d 89 c7             	mov    %r8,%r15
    5d69:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    5d6d:	49 8d 47 01          	lea    0x1(%r15),%rax
    5d71:	4c 89 f9             	mov    %r15,%rcx
    5d74:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5d7a:	0f 87 96 03 00 00    	ja     6116 <fwp_p_ad_push+0x476>
    5d80:	48 8b 6b 18          	mov    0x18(%rbx),%rbp
    5d84:	48 39 e8             	cmp    %rbp,%rax
    5d87:	0f 8e 23 02 00 00    	jle    5fb0 <fwp_p_ad_push+0x310>
    5d8d:	48 85 ed             	test   %rbp,%rbp
    5d90:	ba 40 00 00 00       	mov    $0x40,%edx
    5d95:	48 0f 44 ea          	cmove  %rdx,%rbp
    5d99:	48 39 e8             	cmp    %rbp,%rax
    5d9c:	7e 22                	jle    5dc0 <fwp_p_ad_push+0x120>
    5d9e:	48 81 fd ff ff ff 3f 	cmp    $0x3fffffff,%rbp
    5da5:	0f 8f f5 01 00 00    	jg     5fa0 <fwp_p_ad_push+0x300>
    5dab:	48 01 ed             	add    %rbp,%rbp
    5dae:	48 39 e8             	cmp    %rbp,%rax
    5db1:	7f eb                	jg     5d9e <fwp_p_ad_push+0xfe>
    5db3:	66 90                	xchg   %ax,%ax
    5db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dbc:	00 00 00 00 
    5dc0:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
    5dc7:	00 
    5dc8:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5dcc:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5dd1:	48 89 c6             	mov    %rax,%rsi
    5dd4:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5dd9:	4c 8b 73 60          	mov    0x60(%rbx),%r14
    5ddd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5de2:	e8 e9 d7 ff ff       	call   35d0 <realloc@plt>
    5de7:	48 85 c0             	test   %rax,%rax
    5dea:	0f 84 32 03 00 00    	je     6122 <fwp_p_ad_push+0x482>
    5df0:	48 8b 53 18          	mov    0x18(%rbx),%rdx
    5df4:	4d 85 f6             	test   %r14,%r14
    5df7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5dfc:	48 89 43 20          	mov    %rax,0x20(%rbx)
    5e00:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    5e05:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5e09:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    5e0d:	0f 84 d5 01 00 00    	je     5fe8 <fwp_p_ad_push+0x348>
    5e13:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5e17:	48 39 ea             	cmp    %rbp,%rdx
    5e1a:	0f 8d bb 00 00 00    	jge    5edb <fwp_p_ad_push+0x23b>
    5e20:	49 8b 76 40          	mov    0x40(%r14),%rsi
    5e24:	48 89 ef             	mov    %rbp,%rdi
    5e27:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5e2c:	48 c1 e7 04          	shl    $0x4,%rdi
    5e30:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5e35:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    5e3a:	be 02 00 00 00       	mov    $0x2,%esi
    5e3f:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
    5e44:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
    5e49:	e8 02 fc ff ff       	call   5a50 <fwp_heap_alloc>
    5e4e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    5e53:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5e58:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5e5d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5e62:	48 85 f6             	test   %rsi,%rsi
    5e65:	74 31                	je     5e98 <fwp_p_ad_push+0x1f8>
    5e67:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    5e6c:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    5e71:	48 c1 e2 04          	shl    $0x4,%rdx
    5e75:	48 39 fa             	cmp    %rdi,%rdx
    5e78:	48 0f 47 d7          	cmova  %rdi,%rdx
    5e7c:	48 89 c7             	mov    %rax,%rdi
    5e7f:	e8 1c d7 ff ff       	call   35a0 <memcpy@plt>
    5e84:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    5e89:	e8 c2 f6 ff ff       	call   5550 <fwp_mem_free>
    5e8e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5e93:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5e98:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5e9c:	48 89 ea             	mov    %rbp,%rdx
    5e9f:	31 f6                	xor    %esi,%esi
    5ea1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
    5ea6:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5eab:	48 29 fa             	sub    %rdi,%rdx
    5eae:	48 c1 e7 04          	shl    $0x4,%rdi
    5eb2:	48 03 7c 24 18       	add    0x18(%rsp),%rdi
    5eb7:	48 c1 e2 04          	shl    $0x4,%rdx
    5ebb:	e8 00 d6 ff ff       	call   34c0 <memset@plt>
    5ec0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5ec5:	49 89 6e 60          	mov    %rbp,0x60(%r14)
    5ec9:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    5ece:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    5ed3:	49 89 46 40          	mov    %rax,0x40(%r14)
    5ed7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5edb:	4d 85 ff             	test   %r15,%r15
    5ede:	0f 85 9c 01 00 00    	jne    6080 <fwp_p_ad_push+0x3e0>
    5ee4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5ee8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5eec:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    5ef3:	00 
    5ef4:	49 01 c6             	add    %rax,%r14
    5ef7:	48 89 6b 18          	mov    %rbp,0x18(%rbx)
    5efb:	4c 89 73 28          	mov    %r14,0x28(%rbx)
    5eff:	46 89 24 38          	mov    %r12d,(%rax,%r15,1)
    5f03:	4d 85 ed             	test   %r13,%r13
    5f06:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    5f0c:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f13:	4c 0f 48 e8          	cmovs  %rax,%r13
    5f17:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    5f1c:	49 8d 40 01          	lea    0x1(%r8),%rax
    5f20:	f2 0f 11 0c 0a       	movsd  %xmm1,(%rdx,%rcx,1)
    5f25:	47 89 2c 3e          	mov    %r13d,(%r14,%r15,1)
    5f29:	f2 0f 11 14 0f       	movsd  %xmm2,(%rdi,%rcx,1)
    5f2e:	48 89 43 10          	mov    %rax,0x10(%rbx)
    5f32:	48 83 c4 48          	add    $0x48,%rsp
    5f36:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    5f3d:	ff ff ff 
    5f40:	4c 21 e0             	and    %r12,%rax
    5f43:	5b                   	pop    %rbx
    5f44:	5d                   	pop    %rbp
    5f45:	4c 09 c0             	or     %r8,%rax
    5f48:	41 5c                	pop    %r12
    5f4a:	41 5d                	pop    %r13
    5f4c:	41 5e                	pop    %r14
    5f4e:	41 5f                	pop    %r15
    5f50:	c3                   	ret
    5f51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5f58:	48 c1 fa 20          	sar    $0x20,%rdx
    5f5c:	48 c1 ff 20          	sar    $0x20,%rdi
    5f60:	49 89 d6             	mov    %rdx,%r14
    5f63:	48 39 d7             	cmp    %rdx,%rdi
    5f66:	0f 84 9b fd ff ff    	je     5d07 <fwp_p_ad_push+0x67>
    5f6c:	48 8d 3d 55 68 00 00 	lea    0x6855(%rip),%rdi        # c7c8 <_IO_stdin_used+0x7c8>
    5f73:	e8 28 e2 ff ff       	call   41a0 <fwp_trap>
    5f78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    5f7f:	00 
    5f80:	48 83 c4 48          	add    $0x48,%rsp
    5f84:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5f8b:	5b                   	pop    %rbx
    5f8c:	5d                   	pop    %rbp
    5f8d:	41 5c                	pop    %r12
    5f8f:	41 5d                	pop    %r13
    5f91:	41 5e                	pop    %r14
    5f93:	41 5f                	pop    %r15
    5f95:	c3                   	ret
    5f96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5f9d:	00 00 00 
    5fa0:	bd ff ff ff 7f       	mov    $0x7fffffff,%ebp
    5fa5:	e9 16 fe ff ff       	jmp    5dc0 <fwp_p_ad_push+0x120>
    5faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5fb0:	48 8b 43 20          	mov    0x20(%rbx),%rax
    5fb4:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    5fb8:	48 c1 e1 03          	shl    $0x3,%rcx
    5fbc:	4e 8d 3c bd 00 00 00 	lea    0x0(,%r15,4),%r15
    5fc3:	00 
    5fc4:	4c 8b 73 28          	mov    0x28(%rbx),%r14
    5fc8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    5fcc:	e9 2e ff ff ff       	jmp    5eff <fwp_p_ad_push+0x25f>
    5fd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fd8:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    5fdc:	e9 57 fd ff ff       	jmp    5d38 <fwp_p_ad_push+0x98>
    5fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fe8:	49 89 ee             	mov    %rbp,%r14
    5feb:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    5fef:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
    5ff4:	49 c1 e6 04          	shl    $0x4,%r14
    5ff8:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    5ffd:	4c 89 f6             	mov    %r14,%rsi
    6000:	e8 cb d5 ff ff       	call   35d0 <realloc@plt>
    6005:	48 89 c2             	mov    %rax,%rdx
    6008:	48 85 c0             	test   %rax,%rax
    600b:	0f 84 11 01 00 00    	je     6122 <fwp_p_ad_push+0x482>
    6011:	48 89 43 30          	mov    %rax,0x30(%rbx)
    6015:	48 8b 43 18          	mov    0x18(%rbx),%rax
    6019:	4d 85 ff             	test   %r15,%r15
    601c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6021:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    6026:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
    602a:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    602f:	48 89 73 38          	mov    %rsi,0x38(%rbx)
    6033:	48 8d 3c 02          	lea    (%rdx,%rax,1),%rdi
    6037:	0f 85 98 00 00 00    	jne    60d5 <fwp_p_ad_push+0x435>
    603d:	48 89 7b 38          	mov    %rdi,0x38(%rbx)
    6041:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6045:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    604c:	00 
    604d:	45 31 ff             	xor    %r15d,%r15d
    6050:	e9 9f fe ff ff       	jmp    5ef4 <fwp_p_ad_push+0x254>
    6055:	0f 1f 00             	nopl   (%rax)
    6058:	4c 89 f7             	mov    %r14,%rdi
    605b:	e8 20 e4 ff ff       	call   4480 <fwp_tape_of>
    6060:	48 89 c3             	mov    %rax,%rbx
    6063:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6068:	0f 84 ca fc ff ff    	je     5d38 <fwp_p_ad_push+0x98>
    606e:	48 8d 3d 9b 67 00 00 	lea    0x679b(%rip),%rdi        # c810 <_IO_stdin_used+0x810>
    6075:	e8 26 e1 ff ff       	call   41a0 <fwp_trap>
    607a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6080:	4a 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%rsi
    6087:	00 
    6088:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
    608d:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6091:	49 c1 e7 02          	shl    $0x2,%r15
    6095:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    609a:	4c 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14
    60a1:	00 
    60a2:	4a 8d 3c 30          	lea    (%rax,%r14,1),%rdi
    60a6:	4c 89 fa             	mov    %r15,%rdx
    60a9:	e8 62 d5 ff ff       	call   3610 <memmove@plt>
    60ae:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60b2:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    60b6:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    60ba:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    60bf:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    60c4:	e9 2b fe ff ff       	jmp    5ef4 <fwp_p_ad_push+0x254>
    60c9:	48 c1 ff 20          	sar    $0x20,%rdi
    60cd:	49 89 fe             	mov    %rdi,%r14
    60d0:	e9 32 fc ff ff       	jmp    5d07 <fwp_p_ad_push+0x67>
    60d5:	4c 39 f0             	cmp    %r14,%rax
    60d8:	4c 89 f1             	mov    %r14,%rcx
    60db:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
    60e2:	00 
    60e3:	49 89 c6             	mov    %rax,%r14
    60e6:	48 0f 43 c8          	cmovae %rax,%rcx
    60ea:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    60ef:	48 29 c1             	sub    %rax,%rcx
    60f2:	e8 69 d4 ff ff       	call   3560 <__memmove_chk@plt>
    60f7:	4c 03 73 30          	add    0x30(%rbx),%r14
    60fb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60ff:	4c 89 73 38          	mov    %r14,0x38(%rbx)
    6103:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    6108:	eb 83                	jmp    608d <fwp_p_ad_push+0x3ed>
    610a:	48 8d 3d f3 5f 00 00 	lea    0x5ff3(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    6111:	e8 8a e0 ff ff       	call   41a0 <fwp_trap>
    6116:	48 8d 3d cc 5f 00 00 	lea    0x5fcc(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    611d:	e8 7e e0 ff ff       	call   41a0 <fwp_trap>
    6122:	48 89 df             	mov    %rbx,%rdi
    6125:	e8 d6 da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    612a:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    612e:	e8 8d d2 ff ff       	call   33c0 <free@plt>
    6133:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6137:	e8 84 d2 ff ff       	call   33c0 <free@plt>
    613c:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6140:	e8 7b d2 ff ff       	call   33c0 <free@plt>
    6145:	31 c9                	xor    %ecx,%ecx
    6147:	31 c0                	xor    %eax,%eax
    6149:	31 d2                	xor    %edx,%edx
    614b:	89 53 04             	mov    %edx,0x4(%rbx)
    614e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6152:	ba 13 00 00 00       	mov    $0x13,%edx
    6157:	be 01 00 00 00       	mov    $0x1,%esi
    615c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    6160:	48 8d 3d a1 5e 00 00 	lea    0x5ea1(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    6167:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    616b:	48 8b 0d ce 9e 00 00 	mov    0x9ece(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    6172:	48 89 43 40          	mov    %rax,0x40(%rbx)
    6176:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    617a:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
    617e:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    6182:	e8 f9 d4 ff ff       	call   3680 <fwrite@plt>
    6187:	31 ff                	xor    %edi,%edi
    6189:	e8 32 d4 ff ff       	call   35c0 <fflush@plt>
    618e:	bf 66 00 00 00       	mov    $0x66,%edi
    6193:	e8 08 d5 ff ff       	call   36a0 <_Exit@plt>
    6198:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    619f:	00 

00000000000061a0 <w120>:
    61a0:	41 56                	push   %r14
    61a2:	66 0f 28 e0          	movapd %xmm0,%xmm4
    61a6:	48 89 fa             	mov    %rdi,%rdx
    61a9:	41 55                	push   %r13
    61ab:	f2 0f 59 e0          	mulsd  %xmm0,%xmm4
    61af:	49 89 fd             	mov    %rdi,%r13
    61b2:	41 54                	push   %r12
    61b4:	55                   	push   %rbp
    61b5:	53                   	push   %rbx
    61b6:	48 83 ec 40          	sub    $0x40,%rsp
    61ba:	f2 0f 11 4c 24 18    	movsd  %xmm1,0x18(%rsp)
    61c0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    61c5:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    61cc:	00 00 
    61ce:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
    61d3:	48 89 f5             	mov    %rsi,%rbp
    61d6:	66 48 0f 7e c6       	movq   %xmm0,%rsi
    61db:	f2 0f 11 64 24 08    	movsd  %xmm4,0x8(%rsp)
    61e1:	48 89 f1             	mov    %rsi,%rcx
    61e4:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    61ea:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
    61f1:	ff ff 
    61f3:	48 c7 44 24 28 00 00 	movq   $0x0,0x28(%rsp)
    61fa:	00 00 
    61fc:	e8 9f fa ff ff       	call   5ca0 <fwp_p_ad_push>
    6201:	f2 0f 10 4c 24 18    	movsd  0x18(%rsp),%xmm1
    6207:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    620c:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6212:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6219:	00 f0 3f 
    621c:	48 89 c7             	mov    %rax,%rdi
    621f:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    6226:	00 f0 bf 
    6229:	48 89 ea             	mov    %rbp,%rdx
    622c:	66 49 0f 7e cc       	movq   %xmm1,%r12
    6231:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6237:	e8 64 fa ff ff       	call   5ca0 <fwp_p_ad_push>
    623c:	f2 0f 10 05 64 68 00 	movsd  0x6864(%rip),%xmm0        # caa8 <msg.4+0x28>
    6243:	00 
    6244:	4c 89 ef             	mov    %r13,%rdi
    6247:	f2 0f 5c 44 24 10    	subsd  0x10(%rsp),%xmm0
    624d:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    6252:	49 89 c6             	mov    %rax,%r14
    6255:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    625c:	00 f0 3f 
    625f:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6266:	48 be 00 00 00 00 00 	movabs $0xbff0000000000000,%rsi
    626d:	00 f0 bf 
    6270:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    6275:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    627b:	e8 20 fa ff ff       	call   5ca0 <fwp_p_ad_push>
    6280:	4c 89 e1             	mov    %r12,%rcx
    6283:	4c 89 e6             	mov    %r12,%rsi
    6286:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    628b:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6291:	4c 89 f2             	mov    %r14,%rdx
    6294:	4c 89 f7             	mov    %r14,%rdi
    6297:	49 89 c5             	mov    %rax,%r13
    629a:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    629e:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    62a4:	e8 f7 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    62a9:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    62af:	f2 0f 59 1d f9 67 00 	mulsd  0x67f9(%rip),%xmm3        # cab0 <msg.4+0x30>
    62b6:	00 
    62b7:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62bc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    62c1:	48 89 c2             	mov    %rax,%rdx
    62c4:	48 b9 00 00 00 00 00 	movabs $0x4059000000000000,%rcx
    62cb:	00 59 40 
    62ce:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    62d5:	f2 0f 11 5c 24 08    	movsd  %xmm3,0x8(%rsp)
    62db:	e8 c0 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    62e0:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    62e5:	48 89 e9             	mov    %rbp,%rcx
    62e8:	4c 89 ea             	mov    %r13,%rdx
    62eb:	f2 0f 10 44 24 10    	movsd  0x10(%rsp),%xmm0
    62f1:	48 89 ee             	mov    %rbp,%rsi
    62f4:	4c 89 ef             	mov    %r13,%rdi
    62f7:	49 89 c4             	mov    %rax,%r12
    62fa:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    62fe:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6304:	e8 97 f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    6309:	f2 0f 10 5c 24 08    	movsd  0x8(%rsp),%xmm3
    630f:	45 31 c0             	xor    %r8d,%r8d
    6312:	4c 89 e2             	mov    %r12,%rdx
    6315:	f2 0f 58 5c 24 10    	addsd  0x10(%rsp),%xmm3
    631b:	48 89 c7             	mov    %rax,%rdi
    631e:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6325:	00 f0 3f 
    6328:	48 89 ce             	mov    %rcx,%rsi
    632b:	66 48 0f 7e db       	movq   %xmm3,%rbx
    6330:	e8 6b f9 ff ff       	call   5ca0 <fwp_p_ad_push>
    6335:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
    633a:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    6341:	00 00 
    6343:	75 12                	jne    6357 <w120+0x1b7>
    6345:	48 83 c4 40          	add    $0x40,%rsp
    6349:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    634e:	5b                   	pop    %rbx
    634f:	5d                   	pop    %rbp
    6350:	41 5c                	pop    %r12
    6352:	41 5d                	pop    %r13
    6354:	41 5e                	pop    %r14
    6356:	c3                   	ret
    6357:	e8 04 d1 ff ff       	call   3460 <__stack_chk_fail@plt>
    635c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006360 <w176.constprop.0>:
    6360:	41 54                	push   %r12
    6362:	55                   	push   %rbp
    6363:	53                   	push   %rbx
    6364:	48 83 ec 10          	sub    $0x10,%rsp
    6368:	4c 8b 27             	mov    (%rdi),%r12
    636b:	4d 85 e4             	test   %r12,%r12
    636e:	74 58                	je     63c8 <w176.constprop.0+0x68>
    6370:	48 89 fd             	mov    %rdi,%rbp
    6373:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6377:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    637e:	31 db                	xor    %ebx,%ebx
    6380:	f2 0f 58 44 dd 08    	addsd  0x8(%rbp,%rbx,8),%xmm0
    6386:	48 8b 54 dd 10       	mov    0x10(%rbp,%rbx,8),%rdx
    638b:	45 31 c0             	xor    %r8d,%r8d
    638e:	48 83 c3 02          	add    $0x2,%rbx
    6392:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
    6399:	00 f0 3f 
    639c:	48 89 ce             	mov    %rcx,%rsi
    639f:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    63a5:	e8 f6 f8 ff ff       	call   5ca0 <fwp_p_ad_push>
    63aa:	4c 39 e3             	cmp    %r12,%rbx
    63ad:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    63b3:	48 89 c7             	mov    %rax,%rdi
    63b6:	72 c8                	jb     6380 <w176.constprop.0+0x20>
    63b8:	48 83 c4 10          	add    $0x10,%rsp
    63bc:	48 89 f8             	mov    %rdi,%rax
    63bf:	5b                   	pop    %rbx
    63c0:	5d                   	pop    %rbp
    63c1:	41 5c                	pop    %r12
    63c3:	c3                   	ret
    63c4:	0f 1f 40 00          	nopl   0x0(%rax)
    63c8:	48 83 c4 10          	add    $0x10,%rsp
    63cc:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    63d3:	66 0f ef c0          	pxor   %xmm0,%xmm0
    63d7:	5b                   	pop    %rbx
    63d8:	48 89 f8             	mov    %rdi,%rax
    63db:	5d                   	pop    %rbp
    63dc:	41 5c                	pop    %r12
    63de:	c3                   	ret
    63df:	90                   	nop

00000000000063e0 <fwp_rc_share>:
    63e0:	48 8b 05 51 b7 01 00 	mov    0x1b751(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    63e7:	48 2b 3d 22 b7 01 00 	sub    0x1b722(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    63ee:	48 c1 e0 10          	shl    $0x10,%rax
    63f2:	48 39 c7             	cmp    %rax,%rdi
    63f5:	73 4a                	jae    6441 <fwp_rc_share+0x61>
    63f7:	48 89 f8             	mov    %rdi,%rax
    63fa:	48 c1 e8 10          	shr    $0x10,%rax
    63fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6402:	48 8b 05 4f b7 01 00 	mov    0x1b74f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    6409:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    640d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6411:	48 85 d2             	test   %rdx,%rdx
    6414:	74 2b                	je     6441 <fwp_rc_share+0x61>
    6416:	0f b6 08             	movzbl (%rax),%ecx
    6419:	80 f9 02             	cmp    $0x2,%cl
    641c:	74 2a                	je     6448 <fwp_rc_share+0x68>
    641e:	80 f9 01             	cmp    $0x1,%cl
    6421:	75 1e                	jne    6441 <fwp_rc_share+0x61>
    6423:	8b 48 18             	mov    0x18(%rax),%ecx
    6426:	0f b7 ff             	movzwl %di,%edi
    6429:	8b 40 1c             	mov    0x1c(%rax),%eax
    642c:	48 0f af f9          	imul   %rcx,%rdi
    6430:	48 c1 ef 20          	shr    $0x20,%rdi
    6434:	48 39 c7             	cmp    %rax,%rdi
    6437:	73 08                	jae    6441 <fwp_rc_share+0x61>
    6439:	48 01 fa             	add    %rdi,%rdx
    643c:	80 3a 00             	cmpb   $0x0,(%rdx)
    643f:	75 0d                	jne    644e <fwp_rc_share+0x6e>
    6441:	c3                   	ret
    6442:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6448:	66 85 ff             	test   %di,%di
    644b:	74 ef                	je     643c <fwp_rc_share+0x5c>
    644d:	c3                   	ret
    644e:	50                   	push   %rax
    644f:	48 8d 3d ea 63 00 00 	lea    0x63ea(%rip),%rdi        # c840 <_IO_stdin_used+0x840>
    6456:	e8 45 dd ff ff       	call   41a0 <fwp_trap>
    645b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006460 <fwp_rc_free_obj>:
    6460:	48 8b 15 d1 b6 01 00 	mov    0x1b6d1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6467:	48 89 f8             	mov    %rdi,%rax
    646a:	48 2b 05 9f b6 01 00 	sub    0x1b69f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6471:	48 c1 e2 10          	shl    $0x10,%rdx
    6475:	48 39 d0             	cmp    %rdx,%rax
    6478:	73 5b                	jae    64d5 <fwp_rc_free_obj+0x75>
    647a:	48 89 c2             	mov    %rax,%rdx
    647d:	48 c1 ea 10          	shr    $0x10,%rdx
    6481:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6485:	48 8b 15 cc b6 01 00 	mov    0x1b6cc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    648c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6490:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6494:	48 85 c9             	test   %rcx,%rcx
    6497:	74 3c                	je     64d5 <fwp_rc_free_obj+0x75>
    6499:	0f b6 32             	movzbl (%rdx),%esi
    649c:	40 80 fe 02          	cmp    $0x2,%sil
    64a0:	74 2e                	je     64d0 <fwp_rc_free_obj+0x70>
    64a2:	40 80 fe 01          	cmp    $0x1,%sil
    64a6:	75 2d                	jne    64d5 <fwp_rc_free_obj+0x75>
    64a8:	8b 72 18             	mov    0x18(%rdx),%esi
    64ab:	0f b7 c0             	movzwl %ax,%eax
    64ae:	8b 52 1c             	mov    0x1c(%rdx),%edx
    64b1:	48 0f af c6          	imul   %rsi,%rax
    64b5:	48 c1 e8 20          	shr    $0x20,%rax
    64b9:	48 39 d0             	cmp    %rdx,%rax
    64bc:	73 17                	jae    64d5 <fwp_rc_free_obj+0x75>
    64be:	48 01 c1             	add    %rax,%rcx
    64c1:	80 39 01             	cmpb   $0x1,(%rcx)
    64c4:	75 0f                	jne    64d5 <fwp_rc_free_obj+0x75>
    64c6:	e9 85 f0 ff ff       	jmp    5550 <fwp_mem_free>
    64cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    64d0:	66 85 c0             	test   %ax,%ax
    64d3:	74 ec                	je     64c1 <fwp_rc_free_obj+0x61>
    64d5:	c3                   	ret
    64d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    64dd:	00 00 00 

00000000000064e0 <fwp_rc_dup>:
    64e0:	f3 0f 1e fa          	endbr64
    64e4:	48 8b 05 4d b6 01 00 	mov    0x1b64d(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    64eb:	48 2b 3d 1e b6 01 00 	sub    0x1b61e(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    64f2:	48 c1 e0 10          	shl    $0x10,%rax
    64f6:	48 39 c7             	cmp    %rax,%rdi
    64f9:	73 56                	jae    6551 <fwp_rc_dup+0x71>
    64fb:	48 89 f8             	mov    %rdi,%rax
    64fe:	48 c1 e8 10          	shr    $0x10,%rax
    6502:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6506:	48 8b 05 4b b6 01 00 	mov    0x1b64b(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    650d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6511:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6515:	48 85 c0             	test   %rax,%rax
    6518:	74 37                	je     6551 <fwp_rc_dup+0x71>
    651a:	0f b6 0a             	movzbl (%rdx),%ecx
    651d:	80 f9 02             	cmp    $0x2,%cl
    6520:	74 36                	je     6558 <fwp_rc_dup+0x78>
    6522:	80 f9 01             	cmp    $0x1,%cl
    6525:	75 2a                	jne    6551 <fwp_rc_dup+0x71>
    6527:	8b 4a 18             	mov    0x18(%rdx),%ecx
    652a:	0f b7 ff             	movzwl %di,%edi
    652d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6530:	48 0f af f9          	imul   %rcx,%rdi
    6534:	48 c1 ef 20          	shr    $0x20,%rdi
    6538:	48 39 d7             	cmp    %rdx,%rdi
    653b:	73 14                	jae    6551 <fwp_rc_dup+0x71>
    653d:	48 01 f8             	add    %rdi,%rax
    6540:	0f b6 10             	movzbl (%rax),%edx
    6543:	84 d2                	test   %dl,%dl
    6545:	74 0a                	je     6551 <fwp_rc_dup+0x71>
    6547:	80 fa fd             	cmp    $0xfd,%dl
    654a:	77 14                	ja     6560 <fwp_rc_dup+0x80>
    654c:	83 c2 01             	add    $0x1,%edx
    654f:	88 10                	mov    %dl,(%rax)
    6551:	c3                   	ret
    6552:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6558:	66 85 ff             	test   %di,%di
    655b:	74 e3                	je     6540 <fwp_rc_dup+0x60>
    655d:	c3                   	ret
    655e:	66 90                	xchg   %ax,%ax
    6560:	48 89 c7             	mov    %rax,%rdi
    6563:	e9 88 ec ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6568:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    656f:	00 

0000000000006570 <fwp_owned_entry173>:
    6570:	f3 0f 1e fa          	endbr64
    6574:	48 83 ec 38          	sub    $0x38,%rsp
    6578:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    657d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6584:	00 00 
    6586:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    658b:	31 c0                	xor    %eax,%eax
    658d:	48 8b 07             	mov    (%rdi),%rax
    6590:	48 03 47 10          	add    0x10(%rdi),%rax
    6594:	0f 80 c2 00 00 00    	jo     665c <fwp_owned_entry173+0xec>
    659a:	66 48 0f 6e c8       	movq   %rax,%xmm1
    659f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    65a4:	31 ff                	xor    %edi,%edi
    65a6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    65aa:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    65af:	e8 bc f5 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    65b4:	48 8b 15 7d b5 01 00 	mov    0x1b57d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    65bb:	48 89 c6             	mov    %rax,%rsi
    65be:	48 2b 05 4b b5 01 00 	sub    0x1b54b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    65c5:	48 c1 e2 10          	shl    $0x10,%rdx
    65c9:	48 39 d0             	cmp    %rdx,%rax
    65cc:	73 4f                	jae    661d <fwp_owned_entry173+0xad>
    65ce:	48 89 c2             	mov    %rax,%rdx
    65d1:	48 c1 ea 10          	shr    $0x10,%rdx
    65d5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    65d9:	48 8b 15 78 b5 01 00 	mov    0x1b578(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    65e0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    65e4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    65e8:	48 85 d2             	test   %rdx,%rdx
    65eb:	74 30                	je     661d <fwp_owned_entry173+0xad>
    65ed:	0f b6 39             	movzbl (%rcx),%edi
    65f0:	40 80 ff 02          	cmp    $0x2,%dil
    65f4:	74 42                	je     6638 <fwp_owned_entry173+0xc8>
    65f6:	40 80 ff 01          	cmp    $0x1,%dil
    65fa:	75 21                	jne    661d <fwp_owned_entry173+0xad>
    65fc:	8b 79 18             	mov    0x18(%rcx),%edi
    65ff:	0f b7 c0             	movzwl %ax,%eax
    6602:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6605:	48 0f af c7          	imul   %rdi,%rax
    6609:	48 c1 e8 20          	shr    $0x20,%rax
    660d:	48 39 c8             	cmp    %rcx,%rax
    6610:	73 0b                	jae    661d <fwp_owned_entry173+0xad>
    6612:	48 01 c2             	add    %rax,%rdx
    6615:	80 3a ff             	cmpb   $0xff,(%rdx)
    6618:	74 26                	je     6640 <fwp_owned_entry173+0xd0>
    661a:	c6 02 01             	movb   $0x1,(%rdx)
    661d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6622:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6629:	00 00 
    662b:	75 34                	jne    6661 <fwp_owned_entry173+0xf1>
    662d:	48 89 f0             	mov    %rsi,%rax
    6630:	48 83 c4 38          	add    $0x38,%rsp
    6634:	c3                   	ret
    6635:	0f 1f 00             	nopl   (%rax)
    6638:	66 85 c0             	test   %ax,%ax
    663b:	75 e0                	jne    661d <fwp_owned_entry173+0xad>
    663d:	eb d6                	jmp    6615 <fwp_owned_entry173+0xa5>
    663f:	90                   	nop
    6640:	48 89 d7             	mov    %rdx,%rdi
    6643:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6648:	48 89 14 24          	mov    %rdx,(%rsp)
    664c:	e8 bf ec ff ff       	call   5310 <fwp_rc_forget_slot>
    6651:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6656:	48 8b 14 24          	mov    (%rsp),%rdx
    665a:	eb be                	jmp    661a <fwp_owned_entry173+0xaa>
    665c:	e8 9f d0 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6661:	e8 fa cd ff ff       	call   3460 <__stack_chk_fail@plt>
    6666:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    666d:	00 00 00 

0000000000006670 <e173>:
    6670:	f3 0f 1e fa          	endbr64
    6674:	53                   	push   %rbx
    6675:	48 83 ec 30          	sub    $0x30,%rsp
    6679:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    667e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6685:	00 00 
    6687:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    668c:	31 c0                	xor    %eax,%eax
    668e:	48 8b 07             	mov    (%rdi),%rax
    6691:	48 03 47 10          	add    0x10(%rdi),%rax
    6695:	0f 80 c9 00 00 00    	jo     6764 <e173+0xf4>
    669b:	66 48 0f 6e c8       	movq   %rax,%xmm1
    66a0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    66a5:	31 ff                	xor    %edi,%edi
    66a7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    66ab:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    66b0:	e8 bb f4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    66b5:	48 8b 15 7c b4 01 00 	mov    0x1b47c(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    66bc:	48 89 c3             	mov    %rax,%rbx
    66bf:	48 2b 05 4a b4 01 00 	sub    0x1b44a(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    66c6:	48 c1 e2 10          	shl    $0x10,%rdx
    66ca:	48 39 d0             	cmp    %rdx,%rax
    66cd:	73 4f                	jae    671e <e173+0xae>
    66cf:	48 89 c2             	mov    %rax,%rdx
    66d2:	48 c1 ea 10          	shr    $0x10,%rdx
    66d6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    66da:	48 8b 15 77 b4 01 00 	mov    0x1b477(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    66e1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    66e5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    66e9:	48 85 d2             	test   %rdx,%rdx
    66ec:	74 30                	je     671e <e173+0xae>
    66ee:	0f b6 31             	movzbl (%rcx),%esi
    66f1:	40 80 fe 02          	cmp    $0x2,%sil
    66f5:	74 49                	je     6740 <e173+0xd0>
    66f7:	40 80 fe 01          	cmp    $0x1,%sil
    66fb:	75 21                	jne    671e <e173+0xae>
    66fd:	8b 71 18             	mov    0x18(%rcx),%esi
    6700:	0f b7 c0             	movzwl %ax,%eax
    6703:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6706:	48 0f af c6          	imul   %rsi,%rax
    670a:	48 c1 e8 20          	shr    $0x20,%rax
    670e:	48 39 c8             	cmp    %rcx,%rax
    6711:	73 0b                	jae    671e <e173+0xae>
    6713:	48 01 c2             	add    %rax,%rdx
    6716:	80 3a ff             	cmpb   $0xff,(%rdx)
    6719:	74 35                	je     6750 <e173+0xe0>
    671b:	c6 02 01             	movb   $0x1,(%rdx)
    671e:	48 89 df             	mov    %rbx,%rdi
    6721:	e8 ba fc ff ff       	call   63e0 <fwp_rc_share>
    6726:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    672b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6732:	00 00 
    6734:	75 33                	jne    6769 <e173+0xf9>
    6736:	48 83 c4 30          	add    $0x30,%rsp
    673a:	48 89 d8             	mov    %rbx,%rax
    673d:	5b                   	pop    %rbx
    673e:	c3                   	ret
    673f:	90                   	nop
    6740:	66 85 c0             	test   %ax,%ax
    6743:	75 d9                	jne    671e <e173+0xae>
    6745:	eb cf                	jmp    6716 <e173+0xa6>
    6747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    674e:	00 00 
    6750:	48 89 d7             	mov    %rdx,%rdi
    6753:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6758:	e8 b3 eb ff ff       	call   5310 <fwp_rc_forget_slot>
    675d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6762:	eb b7                	jmp    671b <e173+0xab>
    6764:	e8 97 cf ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    6769:	e8 f2 cc ff ff       	call   3460 <__stack_chk_fail@plt>
    676e:	66 90                	xchg   %ax,%ax

0000000000006770 <fwp_closure_drop>:
    6770:	48 8b 15 c1 b3 01 00 	mov    0x1b3c1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6777:	48 89 f8             	mov    %rdi,%rax
    677a:	48 2b 05 8f b3 01 00 	sub    0x1b38f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6781:	48 c1 e2 10          	shl    $0x10,%rdx
    6785:	48 39 d0             	cmp    %rdx,%rax
    6788:	73 6b                	jae    67f5 <fwp_closure_drop+0x85>
    678a:	48 89 c2             	mov    %rax,%rdx
    678d:	48 c1 ea 10          	shr    $0x10,%rdx
    6791:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6795:	48 8b 15 bc b3 01 00 	mov    0x1b3bc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    679c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    67a0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    67a4:	48 85 d2             	test   %rdx,%rdx
    67a7:	74 4c                	je     67f5 <fwp_closure_drop+0x85>
    67a9:	0f b6 31             	movzbl (%rcx),%esi
    67ac:	40 80 fe 02          	cmp    $0x2,%sil
    67b0:	74 3e                	je     67f0 <fwp_closure_drop+0x80>
    67b2:	40 80 fe 01          	cmp    $0x1,%sil
    67b6:	75 3d                	jne    67f5 <fwp_closure_drop+0x85>
    67b8:	8b 71 18             	mov    0x18(%rcx),%esi
    67bb:	0f b7 c0             	movzwl %ax,%eax
    67be:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    67c1:	48 0f af c6          	imul   %rsi,%rax
    67c5:	48 c1 e8 20          	shr    $0x20,%rax
    67c9:	48 39 c8             	cmp    %rcx,%rax
    67cc:	73 27                	jae    67f5 <fwp_closure_drop+0x85>
    67ce:	48 01 c2             	add    %rax,%rdx
    67d1:	0f b6 02             	movzbl (%rdx),%eax
    67d4:	84 c0                	test   %al,%al
    67d6:	74 1d                	je     67f5 <fwp_closure_drop+0x85>
    67d8:	3c 01                	cmp    $0x1,%al
    67da:	74 24                	je     6800 <fwp_closure_drop+0x90>
    67dc:	3c ff                	cmp    $0xff,%al
    67de:	74 48                	je     6828 <fwp_closure_drop+0xb8>
    67e0:	83 e8 01             	sub    $0x1,%eax
    67e3:	88 02                	mov    %al,(%rdx)
    67e5:	c3                   	ret
    67e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67ed:	00 00 00 
    67f0:	66 85 c0             	test   %ax,%ax
    67f3:	74 dc                	je     67d1 <fwp_closure_drop+0x61>
    67f5:	c3                   	ret
    67f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    67fd:	00 00 00 
    6800:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6807:	ff ff 
    6809:	48 85 c0             	test   %rax,%rax
    680c:	74 12                	je     6820 <fwp_closure_drop+0xb0>
    680e:	48 89 fe             	mov    %rdi,%rsi
    6811:	48 89 c7             	mov    %rax,%rdi
    6814:	e9 e7 d9 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6820:	e9 8b db ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6825:	0f 1f 00             	nopl   (%rax)
    6828:	48 89 d0             	mov    %rdx,%rax
    682b:	48 8d 35 2e 9f 01 00 	lea    0x19f2e(%rip),%rsi        # 20760 <fwp_heap>
    6832:	48 83 ec 18          	sub    $0x18,%rsp
    6836:	48 c1 e8 11          	shr    $0x11,%rax
    683a:	48 31 d0             	xor    %rdx,%rax
    683d:	48 89 c1             	mov    %rax,%rcx
    6840:	48 c1 e9 09          	shr    $0x9,%rcx
    6844:	48 31 c8             	xor    %rcx,%rax
    6847:	0f b6 c8             	movzbl %al,%ecx
    684a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6851:	00 
    6852:	48 85 c0             	test   %rax,%rax
    6855:	75 12                	jne    6869 <fwp_closure_drop+0xf9>
    6857:	eb 49                	jmp    68a2 <fwp_closure_drop+0x132>
    6859:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6860:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6864:	48 85 c0             	test   %rax,%rax
    6867:	74 39                	je     68a2 <fwp_closure_drop+0x132>
    6869:	48 89 c1             	mov    %rax,%rcx
    686c:	48 39 10             	cmp    %rdx,(%rax)
    686f:	75 ef                	jne    6860 <fwp_closure_drop+0xf0>
    6871:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6875:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6879:	48 89 48 08          	mov    %rcx,0x8(%rax)
    687d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6884:	74 05                	je     688b <fwp_closure_drop+0x11b>
    6886:	48 83 c4 18          	add    $0x18,%rsp
    688a:	c3                   	ret
    688b:	48 89 d7             	mov    %rdx,%rdi
    688e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6893:	e8 78 ea ff ff       	call   5310 <fwp_rc_forget_slot>
    6898:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    689d:	c6 02 fe             	movb   $0xfe,(%rdx)
    68a0:	eb e4                	jmp    6886 <fwp_closure_drop+0x116>
    68a2:	48 8d 3d f7 5e 00 00 	lea    0x5ef7(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    68a9:	e8 f2 d8 ff ff       	call   41a0 <fwp_trap>
    68ae:	66 90                	xchg   %ax,%ax

00000000000068b0 <fwp_owned_tape_release>:
    68b0:	48 85 ff             	test   %rdi,%rdi
    68b3:	0f 84 f7 00 00 00    	je     69b0 <fwp_owned_tape_release+0x100>
    68b9:	41 54                	push   %r12
    68bb:	55                   	push   %rbp
    68bc:	53                   	push   %rbx
    68bd:	48 8b 07             	mov    (%rdi),%rax
    68c0:	48 85 c0             	test   %rax,%rax
    68c3:	74 08                	je     68cd <fwp_owned_tape_release+0x1d>
    68c5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    68c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    68cd:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    68d1:	48 85 d2             	test   %rdx,%rdx
    68d4:	74 03                	je     68d9 <fwp_owned_tape_release+0x29>
    68d6:	48 89 02             	mov    %rax,(%rdx)
    68d9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    68dd:	48 89 fb             	mov    %rdi,%rbx
    68e0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    68e4:	48 85 c0             	test   %rax,%rax
    68e7:	0f 84 89 00 00 00    	je     6976 <fwp_owned_tape_release+0xc6>
    68ed:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    68f1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    68f5:	7e 47                	jle    693e <fwp_owned_tape_release+0x8e>
    68f7:	31 ed                	xor    %ebp,%ebp
    68f9:	eb 0d                	jmp    6908 <fwp_owned_tape_release+0x58>
    68fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6900:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6904:	48 8b 40 68          	mov    0x68(%rax),%rax
    6908:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    690c:	49 89 ec             	mov    %rbp,%r12
    690f:	48 83 c5 01          	add    $0x1,%rbp
    6913:	49 c1 e4 04          	shl    $0x4,%r12
    6917:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    691b:	ff d0                	call   *%rax
    691d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6921:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6926:	48 8b 43 10          	mov    0x10(%rbx),%rax
    692a:	ff 50 68             	call   *0x68(%rax)
    692d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6931:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6935:	48 39 e8             	cmp    %rbp,%rax
    6938:	7f c6                	jg     6900 <fwp_owned_tape_release+0x50>
    693a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    693e:	31 ed                	xor    %ebp,%ebp
    6940:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6945:	7e 28                	jle    696f <fwp_owned_tape_release+0xbf>
    6947:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    694e:	00 00 
    6950:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6954:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6958:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    695c:	74 07                	je     6965 <fwp_owned_tape_release+0xb5>
    695e:	ff 52 68             	call   *0x68(%rdx)
    6961:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6965:	48 83 c5 01          	add    $0x1,%rbp
    6969:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    696d:	7f e1                	jg     6950 <fwp_owned_tape_release+0xa0>
    696f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6973:	ff 52 68             	call   *0x68(%rdx)
    6976:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    697a:	e8 f1 fd ff ff       	call   6770 <fwp_closure_drop>
    697f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6983:	e8 e8 fd ff ff       	call   6770 <fwp_closure_drop>
    6988:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    698c:	e8 df fd ff ff       	call   6770 <fwp_closure_drop>
    6991:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6995:	e8 b6 eb ff ff       	call   5550 <fwp_mem_free>
    699a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    699e:	e8 ad eb ff ff       	call   5550 <fwp_mem_free>
    69a3:	48 89 df             	mov    %rbx,%rdi
    69a6:	5b                   	pop    %rbx
    69a7:	5d                   	pop    %rbp
    69a8:	41 5c                	pop    %r12
    69aa:	e9 a1 eb ff ff       	jmp    5550 <fwp_mem_free>
    69af:	90                   	nop
    69b0:	c3                   	ret
    69b1:	0f 1f 40 00          	nopl   0x0(%rax)
    69b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    69bc:	00 00 00 00 

00000000000069c0 <fwp_tape_finish>:
    69c0:	f3 0f 1e fa          	endbr64
    69c4:	41 56                	push   %r14
    69c6:	48 8d 3d d3 96 01 00 	lea    0x196d3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    69cd:	41 55                	push   %r13
    69cf:	41 54                	push   %r12
    69d1:	55                   	push   %rbp
    69d2:	53                   	push   %rbx
    69d3:	e8 98 d5 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    69d8:	48 83 3d 08 97 01 00 	cmpq   $0x0,0x19708(%rip)        # 200e8 <fwp_ntapes>
    69df:	00 
    69e0:	48 c7 05 9d 96 01 00 	movq   $0x0,0x1969d(%rip)        # 20088 <fwp_tape_cached_bytes>
    69e7:	00 00 00 00 
    69eb:	7e 68                	jle    6a55 <fwp_tape_finish+0x95>
    69ed:	45 31 e4             	xor    %r12d,%r12d
    69f0:	31 ed                	xor    %ebp,%ebp
    69f2:	0f 1f 00             	nopl   (%rax)
    69f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    69fc:	00 00 00 00 
    6a00:	48 8b 1d e9 96 01 00 	mov    0x196e9(%rip),%rbx        # 200f0 <fwp_tapes>
    6a07:	48 83 c5 01          	add    $0x1,%rbp
    6a0b:	4c 01 e3             	add    %r12,%rbx
    6a0e:	49 83 c4 68          	add    $0x68,%r12
    6a12:	48 89 df             	mov    %rbx,%rdi
    6a15:	e8 e6 d1 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6a1a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6a1e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6a22:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    6a26:	e8 95 c9 ff ff       	call   33c0 <free@plt>
    6a2b:	4c 89 f7             	mov    %r14,%rdi
    6a2e:	e8 8d c9 ff ff       	call   33c0 <free@plt>
    6a33:	4c 89 ef             	mov    %r13,%rdi
    6a36:	e8 85 c9 ff ff       	call   33c0 <free@plt>
    6a3b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    6a3f:	e8 6c fe ff ff       	call   68b0 <fwp_owned_tape_release>
    6a44:	48 39 2d 9d 96 01 00 	cmp    %rbp,0x1969d(%rip)        # 200e8 <fwp_ntapes>
    6a4b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    6a52:	00 
    6a53:	7f ab                	jg     6a00 <fwp_tape_finish+0x40>
    6a55:	48 8b 3d 94 96 01 00 	mov    0x19694(%rip),%rdi        # 200f0 <fwp_tapes>
    6a5c:	e8 5f c9 ff ff       	call   33c0 <free@plt>
    6a61:	5b                   	pop    %rbx
    6a62:	5d                   	pop    %rbp
    6a63:	48 c7 05 82 96 01 00 	movq   $0x0,0x19682(%rip)        # 200f0 <fwp_tapes>
    6a6a:	00 00 00 00 
    6a6e:	48 c7 05 67 96 01 00 	movq   $0x0,0x19667(%rip)        # 200e0 <fwp_tapes_cap>
    6a75:	00 00 00 00 
    6a79:	41 5c                	pop    %r12
    6a7b:	48 c7 05 62 96 01 00 	movq   $0x0,0x19662(%rip)        # 200e8 <fwp_ntapes>
    6a82:	00 00 00 00 
    6a86:	41 5d                	pop    %r13
    6a88:	48 c7 05 45 96 01 00 	movq   $0x0,0x19645(%rip)        # 200d8 <fwp_tape_next_slot>
    6a8f:	00 00 00 00 
    6a93:	41 5e                	pop    %r14
    6a95:	c3                   	ret
    6a96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6a9d:	00 00 00 

0000000000006aa0 <fwp_tape_scope_release>:
    6aa0:	f3 0f 1e fa          	endbr64
    6aa4:	41 55                	push   %r13
    6aa6:	41 54                	push   %r12
    6aa8:	55                   	push   %rbp
    6aa9:	53                   	push   %rbx
    6aaa:	48 83 ec 58          	sub    $0x58,%rsp
    6aae:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6ab5:	00 00 
    6ab7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    6abc:	48 63 07             	movslq (%rdi),%rax
    6abf:	85 c0                	test   %eax,%eax
    6ac1:	0f 88 05 01 00 00    	js     6bcc <fwp_tape_scope_release+0x12c>
    6ac7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    6ace:	ec c4 4e 
    6ad1:	48 89 fb             	mov    %rdi,%rbx
    6ad4:	eb 3c                	jmp    6b12 <fwp_tape_scope_release+0x72>
    6ad6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6add:	00 00 00 
    6ae0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    6ae5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    6ae9:	e8 d2 c8 ff ff       	call   33c0 <free@plt>
    6aee:	48 8b 3c 24          	mov    (%rsp),%rdi
    6af2:	e8 c9 c8 ff ff       	call   33c0 <free@plt>
    6af7:	4c 89 ef             	mov    %r13,%rdi
    6afa:	e8 c1 c8 ff ff       	call   33c0 <free@plt>
    6aff:	4c 89 e7             	mov    %r12,%rdi
    6b02:	e8 a9 fd ff ff       	call   68b0 <fwp_owned_tape_release>
    6b07:	48 63 03             	movslq (%rbx),%rax
    6b0a:	85 c0                	test   %eax,%eax
    6b0c:	0f 88 ba 00 00 00    	js     6bcc <fwp_tape_scope_release+0x12c>
    6b12:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    6b16:	48 8b 35 d3 95 01 00 	mov    0x195d3(%rip),%rsi        # 200f0 <fwp_tapes>
    6b1d:	4c 01 c6             	add    %r8,%rsi
    6b20:	48 89 f7             	mov    %rsi,%rdi
    6b23:	e8 d8 d0 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6b28:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    6b2d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    6b32:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    6b39:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    6b3d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    6b41:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    6b48:	00 
    6b49:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    6b4e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    6b52:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    6b57:	66 0f ef d2          	pxor   %xmm2,%xmm2
    6b5b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    6b60:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    6b67:	00 
    6b68:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    6b6f:	00 
    6b70:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    6b77:	00 
    6b78:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    6b7d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    6b82:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    6b86:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    6b8a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    6b8e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    6b94:	77 18                	ja     6bae <fwp_tape_scope_release+0x10e>
    6b96:	49 c1 f8 03          	sar    $0x3,%r8
    6b9a:	4c 0f af c5          	imul   %rbp,%r8
    6b9e:	4c 3b 05 33 95 01 00 	cmp    0x19533(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    6ba5:	7d 07                	jge    6bae <fwp_tape_scope_release+0x10e>
    6ba7:	4c 89 05 2a 95 01 00 	mov    %r8,0x1952a(%rip)        # 200d8 <fwp_tape_next_slot>
    6bae:	4d 85 e4             	test   %r12,%r12
    6bb1:	0f 85 29 ff ff ff    	jne    6ae0 <fwp_tape_scope_release+0x40>
    6bb7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    6bbc:	e8 6f e2 ff ff       	call   4e30 <fwp_tape_buffers_release>
    6bc1:	48 63 03             	movslq (%rbx),%rax
    6bc4:	85 c0                	test   %eax,%eax
    6bc6:	0f 89 46 ff ff ff    	jns    6b12 <fwp_tape_scope_release+0x72>
    6bcc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    6bd1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6bd8:	00 00 
    6bda:	75 0b                	jne    6be7 <fwp_tape_scope_release+0x147>
    6bdc:	48 83 c4 58          	add    $0x58,%rsp
    6be0:	5b                   	pop    %rbx
    6be1:	5d                   	pop    %rbp
    6be2:	41 5c                	pop    %r12
    6be4:	41 5d                	pop    %r13
    6be6:	c3                   	ret
    6be7:	e8 74 c8 ff ff       	call   3460 <__stack_chk_fail@plt>
    6bec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006bf0 <fwp_drop4>:
    6bf0:	48 8b 0d 41 af 01 00 	mov    0x1af41(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    6bf7:	48 89 f8             	mov    %rdi,%rax
    6bfa:	48 2b 05 0f af 01 00 	sub    0x1af0f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6c01:	48 c1 e1 10          	shl    $0x10,%rcx
    6c05:	48 39 c8             	cmp    %rcx,%rax
    6c08:	0f 83 42 01 00 00    	jae    6d50 <fwp_drop4+0x160>
    6c0e:	48 83 ec 18          	sub    $0x18,%rsp
    6c12:	48 89 fa             	mov    %rdi,%rdx
    6c15:	4c 8d 05 44 9b 01 00 	lea    0x19b44(%rip),%r8        # 20760 <fwp_heap>
    6c1c:	48 89 c1             	mov    %rax,%rcx
    6c1f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    6c26:	48 c1 e9 10          	shr    $0x10,%rcx
    6c2a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6c2e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6c32:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6c36:	48 85 c9             	test   %rcx,%rcx
    6c39:	74 40                	je     6c7b <fwp_drop4+0x8b>
    6c3b:	0f b6 3e             	movzbl (%rsi),%edi
    6c3e:	40 80 ff 02          	cmp    $0x2,%dil
    6c42:	74 3c                	je     6c80 <fwp_drop4+0x90>
    6c44:	40 80 ff 01          	cmp    $0x1,%dil
    6c48:	75 31                	jne    6c7b <fwp_drop4+0x8b>
    6c4a:	8b 7e 18             	mov    0x18(%rsi),%edi
    6c4d:	0f b7 c0             	movzwl %ax,%eax
    6c50:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6c53:	48 0f af c7          	imul   %rdi,%rax
    6c57:	48 c1 e8 20          	shr    $0x20,%rax
    6c5b:	48 39 f0             	cmp    %rsi,%rax
    6c5e:	73 1b                	jae    6c7b <fwp_drop4+0x8b>
    6c60:	48 01 c1             	add    %rax,%rcx
    6c63:	0f b6 01             	movzbl (%rcx),%eax
    6c66:	84 c0                	test   %al,%al
    6c68:	74 11                	je     6c7b <fwp_drop4+0x8b>
    6c6a:	3c 01                	cmp    $0x1,%al
    6c6c:	74 22                	je     6c90 <fwp_drop4+0xa0>
    6c6e:	3c ff                	cmp    $0xff,%al
    6c70:	0f 84 0a 01 00 00    	je     6d80 <fwp_drop4+0x190>
    6c76:	83 e8 01             	sub    $0x1,%eax
    6c79:	88 01                	mov    %al,(%rcx)
    6c7b:	48 83 c4 18          	add    $0x18,%rsp
    6c7f:	c3                   	ret
    6c80:	66 85 c0             	test   %ax,%ax
    6c83:	74 de                	je     6c63 <fwp_drop4+0x73>
    6c85:	48 83 c4 18          	add    $0x18,%rsp
    6c89:	c3                   	ret
    6c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c90:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    6c94:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    6c9b:	48 89 f8             	mov    %rdi,%rax
    6c9e:	48 c1 e1 10          	shl    $0x10,%rcx
    6ca2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ca9:	48 39 c8             	cmp    %rcx,%rax
    6cac:	73 62                	jae    6d10 <fwp_drop4+0x120>
    6cae:	48 89 c1             	mov    %rax,%rcx
    6cb1:	48 c1 e9 10          	shr    $0x10,%rcx
    6cb5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    6cb9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    6cbd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    6cc1:	48 85 c9             	test   %rcx,%rcx
    6cc4:	74 4a                	je     6d10 <fwp_drop4+0x120>
    6cc6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    6cca:	41 80 f9 02          	cmp    $0x2,%r9b
    6cce:	0f 84 9c 00 00 00    	je     6d70 <fwp_drop4+0x180>
    6cd4:	41 80 f9 01          	cmp    $0x1,%r9b
    6cd8:	75 36                	jne    6d10 <fwp_drop4+0x120>
    6cda:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    6cde:	0f b7 c0             	movzwl %ax,%eax
    6ce1:	8b 76 1c             	mov    0x1c(%rsi),%esi
    6ce4:	49 0f af c1          	imul   %r9,%rax
    6ce8:	48 c1 e8 20          	shr    $0x20,%rax
    6cec:	48 39 f0             	cmp    %rsi,%rax
    6cef:	73 1f                	jae    6d10 <fwp_drop4+0x120>
    6cf1:	48 01 c1             	add    %rax,%rcx
    6cf4:	0f b6 01             	movzbl (%rcx),%eax
    6cf7:	84 c0                	test   %al,%al
    6cf9:	74 15                	je     6d10 <fwp_drop4+0x120>
    6cfb:	3c 01                	cmp    $0x1,%al
    6cfd:	74 59                	je     6d58 <fwp_drop4+0x168>
    6cff:	3c ff                	cmp    $0xff,%al
    6d01:	0f 84 ff 00 00 00    	je     6e06 <fwp_drop4+0x216>
    6d07:	83 e8 01             	sub    $0x1,%eax
    6d0a:	88 01                	mov    %al,(%rcx)
    6d0c:	0f 1f 40 00          	nopl   0x0(%rax)
    6d10:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    6d14:	48 89 d7             	mov    %rdx,%rdi
    6d17:	48 89 0c 24          	mov    %rcx,(%rsp)
    6d1b:	e8 40 f7 ff ff       	call   6460 <fwp_rc_free_obj>
    6d20:	4c 8d 05 39 9a 01 00 	lea    0x19a39(%rip),%r8        # 20760 <fwp_heap>
    6d27:	48 8b 04 24          	mov    (%rsp),%rax
    6d2b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6d32:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d39:	48 c1 e2 10          	shl    $0x10,%rdx
    6d3d:	48 39 d0             	cmp    %rdx,%rax
    6d40:	0f 83 35 ff ff ff    	jae    6c7b <fwp_drop4+0x8b>
    6d46:	48 8b 14 24          	mov    (%rsp),%rdx
    6d4a:	e9 cd fe ff ff       	jmp    6c1c <fwp_drop4+0x2c>
    6d4f:	90                   	nop
    6d50:	c3                   	ret
    6d51:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d58:	48 89 14 24          	mov    %rdx,(%rsp)
    6d5c:	e8 ff f6 ff ff       	call   6460 <fwp_rc_free_obj>
    6d61:	48 8b 14 24          	mov    (%rsp),%rdx
    6d65:	eb a9                	jmp    6d10 <fwp_drop4+0x120>
    6d67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6d6e:	00 00 
    6d70:	66 85 c0             	test   %ax,%ax
    6d73:	75 9b                	jne    6d10 <fwp_drop4+0x120>
    6d75:	e9 7a ff ff ff       	jmp    6cf4 <fwp_drop4+0x104>
    6d7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d80:	48 89 c8             	mov    %rcx,%rax
    6d83:	48 c1 e8 11          	shr    $0x11,%rax
    6d87:	48 31 c8             	xor    %rcx,%rax
    6d8a:	48 89 c2             	mov    %rax,%rdx
    6d8d:	48 c1 ea 09          	shr    $0x9,%rdx
    6d91:	48 31 d0             	xor    %rdx,%rax
    6d94:	0f b6 d0             	movzbl %al,%edx
    6d97:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    6d9e:	00 
    6d9f:	48 85 c0             	test   %rax,%rax
    6da2:	75 29                	jne    6dcd <fwp_drop4+0x1dd>
    6da4:	e9 e3 00 00 00       	jmp    6e8c <fwp_drop4+0x29c>
    6da9:	90                   	nop
    6daa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6db1:	00 00 00 00 
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	0f 84 bf 00 00 00    	je     6e8c <fwp_drop4+0x29c>
    6dcd:	48 89 c2             	mov    %rax,%rdx
    6dd0:	48 39 08             	cmp    %rcx,(%rax)
    6dd3:	75 eb                	jne    6dc0 <fwp_drop4+0x1d0>
    6dd5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    6dd9:	48 83 ea 01          	sub    $0x1,%rdx
    6ddd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6de1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    6de8:	0f 85 8d fe ff ff    	jne    6c7b <fwp_drop4+0x8b>
    6dee:	48 89 cf             	mov    %rcx,%rdi
    6df1:	48 89 0c 24          	mov    %rcx,(%rsp)
    6df5:	e8 16 e5 ff ff       	call   5310 <fwp_rc_forget_slot>
    6dfa:	48 8b 0c 24          	mov    (%rsp),%rcx
    6dfe:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e01:	e9 75 fe ff ff       	jmp    6c7b <fwp_drop4+0x8b>
    6e06:	48 89 ce             	mov    %rcx,%rsi
    6e09:	48 c1 ee 11          	shr    $0x11,%rsi
    6e0d:	48 31 ce             	xor    %rcx,%rsi
    6e10:	48 89 f0             	mov    %rsi,%rax
    6e13:	48 c1 e8 09          	shr    $0x9,%rax
    6e17:	48 31 c6             	xor    %rax,%rsi
    6e1a:	40 0f b6 f6          	movzbl %sil,%esi
    6e1e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    6e25:	00 
    6e26:	48 85 c0             	test   %rax,%rax
    6e29:	75 1e                	jne    6e49 <fwp_drop4+0x259>
    6e2b:	eb 5f                	jmp    6e8c <fwp_drop4+0x29c>
    6e2d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e34:	00 
    6e35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6e3c:	00 00 00 00 
    6e40:	48 8b 46 10          	mov    0x10(%rsi),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	74 43                	je     6e8c <fwp_drop4+0x29c>
    6e49:	48 89 c6             	mov    %rax,%rsi
    6e4c:	48 39 08             	cmp    %rcx,(%rax)
    6e4f:	75 ef                	jne    6e40 <fwp_drop4+0x250>
    6e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e55:	48 83 ee 01          	sub    $0x1,%rsi
    6e59:	48 89 70 08          	mov    %rsi,0x8(%rax)
    6e5d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    6e64:	0f 85 a6 fe ff ff    	jne    6d10 <fwp_drop4+0x120>
    6e6a:	48 89 cf             	mov    %rcx,%rdi
    6e6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e72:	48 89 0c 24          	mov    %rcx,(%rsp)
    6e76:	e8 95 e4 ff ff       	call   5310 <fwp_rc_forget_slot>
    6e7b:	48 8b 0c 24          	mov    (%rsp),%rcx
    6e7f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e84:	c6 01 fe             	movb   $0xfe,(%rcx)
    6e87:	e9 84 fe ff ff       	jmp    6d10 <fwp_drop4+0x120>
    6e8c:	48 8d 3d 0d 59 00 00 	lea    0x590d(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    6e93:	e8 08 d3 ff ff       	call   41a0 <fwp_trap>
    6e98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e9f:	00 

0000000000006ea0 <fwp_arg_drop37>:
    6ea0:	f3 0f 1e fa          	endbr64
    6ea4:	85 f6                	test   %esi,%esi
    6ea6:	75 04                	jne    6eac <fwp_arg_drop37+0xc>
    6ea8:	85 d2                	test   %edx,%edx
    6eaa:	75 04                	jne    6eb0 <fwp_arg_drop37+0x10>
    6eac:	c3                   	ret
    6ead:	0f 1f 00             	nopl   (%rax)
    6eb0:	48 8b 3f             	mov    (%rdi),%rdi
    6eb3:	e9 38 fd ff ff       	jmp    6bf0 <fwp_drop4>
    6eb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6ebf:	00 

0000000000006ec0 <fwp_task_dispose>:
    6ec0:	53                   	push   %rbx
    6ec1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    6ec5:	0f 84 7b c8 ff ff    	je     3746 <fwp_task_dispose.cold>
    6ecb:	48 89 fb             	mov    %rdi,%rbx
    6ece:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    6ed3:	0f 85 6d c8 ff ff    	jne    3746 <fwp_task_dispose.cold>
    6ed9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    6edd:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    6ee4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    6eeb:	00 
    6eec:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    6ef0:	48 85 ff             	test   %rdi,%rdi
    6ef3:	74 07                	je     6efc <fwp_task_dispose+0x3c>
    6ef5:	48 85 c0             	test   %rax,%rax
    6ef8:	74 02                	je     6efc <fwp_task_dispose+0x3c>
    6efa:	ff d0                	call   *%rax
    6efc:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    6f03:	e8 48 e6 ff ff       	call   5550 <fwp_mem_free>
    6f08:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    6f0f:	00 00 00 00 
    6f13:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    6f17:	74 6f                	je     6f88 <fwp_task_dispose+0xc8>
    6f19:	48 8b 15 18 ac 01 00 	mov    0x1ac18(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6f20:	48 89 d8             	mov    %rbx,%rax
    6f23:	48 2b 05 e6 ab 01 00 	sub    0x1abe6(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6f2a:	48 c1 e2 10          	shl    $0x10,%rdx
    6f2e:	48 39 d0             	cmp    %rdx,%rax
    6f31:	73 4c                	jae    6f7f <fwp_task_dispose+0xbf>
    6f33:	48 89 c2             	mov    %rax,%rdx
    6f36:	48 c1 ea 10          	shr    $0x10,%rdx
    6f3a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6f3e:	48 8b 15 13 ac 01 00 	mov    0x1ac13(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    6f45:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6f49:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6f4d:	48 85 c9             	test   %rcx,%rcx
    6f50:	74 2d                	je     6f7f <fwp_task_dispose+0xbf>
    6f52:	0f b6 32             	movzbl (%rdx),%esi
    6f55:	40 80 fe 02          	cmp    $0x2,%sil
    6f59:	74 3d                	je     6f98 <fwp_task_dispose+0xd8>
    6f5b:	40 80 fe 01          	cmp    $0x1,%sil
    6f5f:	75 1e                	jne    6f7f <fwp_task_dispose+0xbf>
    6f61:	8b 72 18             	mov    0x18(%rdx),%esi
    6f64:	0f b7 c0             	movzwl %ax,%eax
    6f67:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6f6a:	48 0f af c6          	imul   %rsi,%rax
    6f6e:	48 c1 e8 20          	shr    $0x20,%rax
    6f72:	48 39 d0             	cmp    %rdx,%rax
    6f75:	73 08                	jae    6f7f <fwp_task_dispose+0xbf>
    6f77:	48 01 c1             	add    %rax,%rcx
    6f7a:	80 39 01             	cmpb   $0x1,(%rcx)
    6f7d:	74 09                	je     6f88 <fwp_task_dispose+0xc8>
    6f7f:	5b                   	pop    %rbx
    6f80:	c3                   	ret
    6f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f88:	48 89 df             	mov    %rbx,%rdi
    6f8b:	5b                   	pop    %rbx
    6f8c:	e9 bf e5 ff ff       	jmp    5550 <fwp_mem_free>
    6f91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f98:	66 85 c0             	test   %ax,%ax
    6f9b:	74 dd                	je     6f7a <fwp_task_dispose+0xba>
    6f9d:	5b                   	pop    %rbx
    6f9e:	c3                   	ret
    6f9f:	90                   	nop

0000000000006fa0 <fwp_free_zombie>:
    6fa0:	48 8b 15 89 97 01 00 	mov    0x19789(%rip),%rdx        # 20730 <fwp_zombie>
    6fa7:	48 85 d2             	test   %rdx,%rdx
    6faa:	0f 84 98 00 00 00    	je     7048 <fwp_free_zombie+0xa8>
    6fb0:	48 3b 15 89 97 01 00 	cmp    0x19789(%rip),%rdx        # 20740 <fwp_cur>
    6fb7:	0f 84 8b 00 00 00    	je     7048 <fwp_free_zombie+0xa8>
    6fbd:	48 83 ec 18          	sub    $0x18,%rsp
    6fc1:	48 63 05 44 91 01 00 	movslq 0x19144(%rip),%rax        # 2010c <fwp_stack_pool_n>
    6fc8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    6fcc:	83 f8 3f             	cmp    $0x3f,%eax
    6fcf:	7f 7f                	jg     7050 <fwp_free_zombie+0xb0>
    6fd1:	8d 48 01             	lea    0x1(%rax),%ecx
    6fd4:	89 0d 32 91 01 00    	mov    %ecx,0x19132(%rip)        # 2010c <fwp_stack_pool_n>
    6fda:	48 8d 0d 3f 91 01 00 	lea    0x1913f(%rip),%rcx        # 20120 <fwp_stack_pool>
    6fe1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    6fe5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    6fec:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6ff0:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    6ff7:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    6ffb:	48 85 c9             	test   %rcx,%rcx
    6ffe:	0f 84 fc 00 00 00    	je     7100 <fwp_free_zombie+0x160>
    7004:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    700b:	48 85 c0             	test   %rax,%rax
    700e:	74 07                	je     7017 <fwp_free_zombie+0x77>
    7010:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7017:	8b 42 5c             	mov    0x5c(%rdx),%eax
    701a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    701e:	48 c7 05 07 97 01 00 	movq   $0x0,0x19707(%rip)        # 20730 <fwp_zombie>
    7025:	00 00 00 00 
    7029:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7030:	85 c0                	test   %eax,%eax
    7032:	74 34                	je     7068 <fwp_free_zombie+0xc8>
    7034:	83 f8 01             	cmp    $0x1,%eax
    7037:	0f 84 b3 00 00 00    	je     70f0 <fwp_free_zombie+0x150>
    703d:	48 83 c4 18          	add    $0x18,%rsp
    7041:	c3                   	ret
    7042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7048:	c3                   	ret
    7049:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7050:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7054:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7059:	e8 82 c5 ff ff       	call   35e0 <munmap@plt>
    705e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7063:	eb 80                	jmp    6fe5 <fwp_free_zombie+0x45>
    7065:	0f 1f 00             	nopl   (%rax)
    7068:	48 8b 0d c9 aa 01 00 	mov    0x1aac9(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    706f:	48 89 d0             	mov    %rdx,%rax
    7072:	48 2b 05 97 aa 01 00 	sub    0x1aa97(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7079:	48 c1 e1 10          	shl    $0x10,%rcx
    707d:	48 39 c8             	cmp    %rcx,%rax
    7080:	73 bb                	jae    703d <fwp_free_zombie+0x9d>
    7082:	48 89 c1             	mov    %rax,%rcx
    7085:	48 c1 e9 10          	shr    $0x10,%rcx
    7089:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    708d:	48 8b 0d c4 aa 01 00 	mov    0x1aac4(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    7094:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    7098:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    709c:	48 85 c9             	test   %rcx,%rcx
    709f:	74 9c                	je     703d <fwp_free_zombie+0x9d>
    70a1:	0f b6 3e             	movzbl (%rsi),%edi
    70a4:	40 80 ff 02          	cmp    $0x2,%dil
    70a8:	74 66                	je     7110 <fwp_free_zombie+0x170>
    70aa:	40 80 ff 01          	cmp    $0x1,%dil
    70ae:	75 8d                	jne    703d <fwp_free_zombie+0x9d>
    70b0:	8b 7e 18             	mov    0x18(%rsi),%edi
    70b3:	0f b7 c0             	movzwl %ax,%eax
    70b6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    70b9:	48 0f af c7          	imul   %rdi,%rax
    70bd:	48 c1 e8 20          	shr    $0x20,%rax
    70c1:	48 39 f0             	cmp    %rsi,%rax
    70c4:	0f 83 73 ff ff ff    	jae    703d <fwp_free_zombie+0x9d>
    70ca:	48 01 c1             	add    %rax,%rcx
    70cd:	0f b6 01             	movzbl (%rcx),%eax
    70d0:	84 c0                	test   %al,%al
    70d2:	0f 84 65 ff ff ff    	je     703d <fwp_free_zombie+0x9d>
    70d8:	3c 01                	cmp    $0x1,%al
    70da:	74 14                	je     70f0 <fwp_free_zombie+0x150>
    70dc:	3c ff                	cmp    $0xff,%al
    70de:	74 3b                	je     711b <fwp_free_zombie+0x17b>
    70e0:	83 e8 01             	sub    $0x1,%eax
    70e3:	88 01                	mov    %al,(%rcx)
    70e5:	e9 53 ff ff ff       	jmp    703d <fwp_free_zombie+0x9d>
    70ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    70f0:	48 89 d7             	mov    %rdx,%rdi
    70f3:	48 83 c4 18          	add    $0x18,%rsp
    70f7:	e9 c4 fd ff ff       	jmp    6ec0 <fwp_task_dispose>
    70fc:	0f 1f 40 00          	nopl   0x0(%rax)
    7100:	48 89 05 01 96 01 00 	mov    %rax,0x19601(%rip)        # 20708 <fwp_tasks_active>
    7107:	e9 ff fe ff ff       	jmp    700b <fwp_free_zombie+0x6b>
    710c:	0f 1f 40 00          	nopl   0x0(%rax)
    7110:	66 85 c0             	test   %ax,%ax
    7113:	0f 85 24 ff ff ff    	jne    703d <fwp_free_zombie+0x9d>
    7119:	eb b2                	jmp    70cd <fwp_free_zombie+0x12d>
    711b:	48 89 ca             	mov    %rcx,%rdx
    711e:	48 8d 35 3b 96 01 00 	lea    0x1963b(%rip),%rsi        # 20760 <fwp_heap>
    7125:	48 c1 ea 11          	shr    $0x11,%rdx
    7129:	48 31 ca             	xor    %rcx,%rdx
    712c:	48 89 d0             	mov    %rdx,%rax
    712f:	48 c1 e8 09          	shr    $0x9,%rax
    7133:	48 31 c2             	xor    %rax,%rdx
    7136:	0f b6 d2             	movzbl %dl,%edx
    7139:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7140:	00 
    7141:	48 85 c0             	test   %rax,%rax
    7144:	75 23                	jne    7169 <fwp_free_zombie+0x1c9>
    7146:	eb 5c                	jmp    71a4 <fwp_free_zombie+0x204>
    7148:	66 90                	xchg   %ax,%ax
    714a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7151:	00 00 00 00 
    7155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    715c:	00 00 00 00 
    7160:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7164:	48 85 c0             	test   %rax,%rax
    7167:	74 3b                	je     71a4 <fwp_free_zombie+0x204>
    7169:	48 89 c2             	mov    %rax,%rdx
    716c:	48 39 08             	cmp    %rcx,(%rax)
    716f:	75 ef                	jne    7160 <fwp_free_zombie+0x1c0>
    7171:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7175:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7179:	48 89 50 08          	mov    %rdx,0x8(%rax)
    717d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7184:	0f 85 b3 fe ff ff    	jne    703d <fwp_free_zombie+0x9d>
    718a:	48 89 cf             	mov    %rcx,%rdi
    718d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7192:	e8 79 e1 ff ff       	call   5310 <fwp_rc_forget_slot>
    7197:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    719c:	c6 01 fe             	movb   $0xfe,(%rcx)
    719f:	e9 99 fe ff ff       	jmp    703d <fwp_free_zombie+0x9d>
    71a4:	48 8d 3d f5 55 00 00 	lea    0x55f5(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    71ab:	e8 f0 cf ff ff       	call   41a0 <fwp_trap>

00000000000071b0 <fwp_block>:
    71b0:	48 83 ec 08          	sub    $0x8,%rsp
    71b4:	48 8b 05 6d 95 01 00 	mov    0x1956d(%rip),%rax        # 20728 <fwp_ready_head>
    71bb:	48 85 c0             	test   %rax,%rax
    71be:	0f 84 1c 01 00 00    	je     72e0 <fwp_block+0x130>
    71c4:	90                   	nop
    71c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71cc:	00 00 00 00 
    71d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    71d7:	48 89 15 4a 95 01 00 	mov    %rdx,0x1954a(%rip)        # 20728 <fwp_ready_head>
    71de:	48 85 d2             	test   %rdx,%rdx
    71e1:	0f 84 19 01 00 00    	je     7300 <fwp_block+0x150>
    71e7:	48 8b 15 52 95 01 00 	mov    0x19552(%rip),%rdx        # 20740 <fwp_cur>
    71ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    71f2:	48 39 c2             	cmp    %rax,%rdx
    71f5:	0f 84 d5 00 00 00    	je     72d0 <fwp_block+0x120>
    71fb:	48 8b 0d c6 b1 01 00 	mov    0x1b1c6(%rip),%rcx        # 223c8 <fwp_state_owners>
    7202:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7206:	48 89 05 33 95 01 00 	mov    %rax,0x19533(%rip)        # 20740 <fwp_cur>
    720d:	f3 0f 7e 05 db b1 01 	movq   0x1b1db(%rip),%xmm0        # 223f0 <fwp_foreign_callbacks>
    7214:	00 
    7215:	0f 16 05 c4 b1 01 00 	movhps 0x1b1c4(%rip),%xmm0        # 223e0 <fwp_state>
    721c:	f3 0f 7e 0d c4 b1 01 	movq   0x1b1c4(%rip),%xmm1        # 223e8 <fwp_handlers>
    7223:	00 
    7224:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    722b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7232:	0f 16 0d bf b1 01 00 	movhps 0x1b1bf(%rip),%xmm1        # 223f8 <fwp_cleanups>
    7239:	f3 0f 7e 05 97 b1 01 	movq   0x1b197(%rip),%xmm0        # 223d8 <fwp_state_len>
    7240:	00 
    7241:	0f 16 05 88 b1 01 00 	movhps 0x1b188(%rip),%xmm0        # 223d0 <fwp_state_cap>
    7248:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    724f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7256:	48 8b 70 08          	mov    0x8(%rax),%rsi
    725a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7261:	48 89 0d 80 b1 01 00 	mov    %rcx,0x1b180(%rip)        # 223e8 <fwp_handlers>
    7268:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    726f:	48 89 0d 82 b1 01 00 	mov    %rcx,0x1b182(%rip)        # 223f8 <fwp_cleanups>
    7276:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    727d:	48 89 0d 6c b1 01 00 	mov    %rcx,0x1b16c(%rip)        # 223f0 <fwp_foreign_callbacks>
    7284:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    728b:	48 89 0d 4e b1 01 00 	mov    %rcx,0x1b14e(%rip)        # 223e0 <fwp_state>
    7292:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7299:	48 89 0d 38 b1 01 00 	mov    %rcx,0x1b138(%rip)        # 223d8 <fwp_state_len>
    72a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    72a7:	48 89 0d 22 b1 01 00 	mov    %rcx,0x1b122(%rip)        # 223d0 <fwp_state_cap>
    72ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    72b5:	48 89 0d 0c b1 01 00 	mov    %rcx,0x1b10c(%rip)        # 223c8 <fwp_state_owners>
    72bc:	e8 cf c1 ff ff       	call   3490 <swapcontext@plt>
    72c1:	f3 0f 1e fa          	endbr64
    72c5:	e8 d6 fc ff ff       	call   6fa0 <fwp_free_zombie>
    72ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    72d0:	8b 05 32 8e 01 00    	mov    0x18e32(%rip),%eax        # 20108 <fwp_slice>
    72d6:	85 c0                	test   %eax,%eax
    72d8:	74 36                	je     7310 <fwp_block+0x160>
    72da:	48 83 c4 08          	add    $0x8,%rsp
    72de:	c3                   	ret
    72df:	90                   	nop
    72e0:	e8 7b dc ff ff       	call   4f60 <fwp_poll_events>
    72e5:	48 8b 05 3c 94 01 00 	mov    0x1943c(%rip),%rax        # 20728 <fwp_ready_head>
    72ec:	48 85 c0             	test   %rax,%rax
    72ef:	0f 85 db fe ff ff    	jne    71d0 <fwp_block+0x20>
    72f5:	eb e9                	jmp    72e0 <fwp_block+0x130>
    72f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    72fe:	00 00 
    7300:	48 c7 05 15 94 01 00 	movq   $0x0,0x19415(%rip)        # 20720 <fwp_ready_tail>
    7307:	00 00 00 00 
    730b:	e9 d7 fe ff ff       	jmp    71e7 <fwp_block+0x37>
    7310:	48 8d 3d 0a 4e 00 00 	lea    0x4e0a(%rip),%rdi        # c121 <_IO_stdin_used+0x121>
    7317:	e8 84 c0 ff ff       	call   33a0 <getenv@plt>
    731c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7321:	48 85 c0             	test   %rax,%rax
    7324:	74 05                	je     732b <fwp_block+0x17b>
    7326:	80 38 00             	cmpb   $0x0,(%rax)
    7329:	75 0b                	jne    7336 <fwp_block+0x186>
    732b:	89 15 d7 8d 01 00    	mov    %edx,0x18dd7(%rip)        # 20108 <fwp_slice>
    7331:	48 83 c4 08          	add    $0x8,%rsp
    7335:	c3                   	ret
    7336:	ba 0a 00 00 00       	mov    $0xa,%edx
    733b:	31 f6                	xor    %esi,%esi
    733d:	48 89 c7             	mov    %rax,%rdi
    7340:	e8 0b c2 ff ff       	call   3550 <strtoll@plt>
    7345:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7349:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7350:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7355:	0f 46 d0             	cmovbe %eax,%edx
    7358:	eb d1                	jmp    732b <fwp_block+0x17b>
    735a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007360 <fwp_caps173>:
    7360:	f3 0f 1e fa          	endbr64
    7364:	85 f6                	test   %esi,%esi
    7366:	74 08                	je     7370 <fwp_caps173+0x10>
    7368:	c3                   	ret
    7369:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7370:	48 8b 15 c1 a7 01 00 	mov    0x1a7c1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7377:	48 89 f8             	mov    %rdi,%rax
    737a:	48 2b 05 8f a7 01 00 	sub    0x1a78f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7381:	48 c1 e2 10          	shl    $0x10,%rdx
    7385:	48 39 d0             	cmp    %rdx,%rax
    7388:	73 de                	jae    7368 <fwp_caps173+0x8>
    738a:	48 89 c2             	mov    %rax,%rdx
    738d:	48 c1 ea 10          	shr    $0x10,%rdx
    7391:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7395:	48 8b 15 bc a7 01 00 	mov    0x1a7bc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    739c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    73a0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    73a4:	48 85 c9             	test   %rcx,%rcx
    73a7:	74 bf                	je     7368 <fwp_caps173+0x8>
    73a9:	0f b6 32             	movzbl (%rdx),%esi
    73ac:	40 80 fe 02          	cmp    $0x2,%sil
    73b0:	74 2e                	je     73e0 <fwp_caps173+0x80>
    73b2:	40 80 fe 01          	cmp    $0x1,%sil
    73b6:	75 b0                	jne    7368 <fwp_caps173+0x8>
    73b8:	8b 72 18             	mov    0x18(%rdx),%esi
    73bb:	0f b7 c0             	movzwl %ax,%eax
    73be:	8b 52 1c             	mov    0x1c(%rdx),%edx
    73c1:	48 0f af c6          	imul   %rsi,%rax
    73c5:	48 c1 e8 20          	shr    $0x20,%rax
    73c9:	48 39 d0             	cmp    %rdx,%rax
    73cc:	73 9a                	jae    7368 <fwp_caps173+0x8>
    73ce:	48 01 c1             	add    %rax,%rcx
    73d1:	80 39 01             	cmpb   $0x1,(%rcx)
    73d4:	75 92                	jne    7368 <fwp_caps173+0x8>
    73d6:	e9 75 e1 ff ff       	jmp    5550 <fwp_mem_free>
    73db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    73e0:	66 85 c0             	test   %ax,%ax
    73e3:	74 ec                	je     73d1 <fwp_caps173+0x71>
    73e5:	c3                   	ret
    73e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    73ed:	00 00 00 

00000000000073f0 <fwp_args37>:
    73f0:	f3 0f 1e fa          	endbr64
    73f4:	85 d2                	test   %edx,%edx
    73f6:	74 04                	je     73fc <fwp_args37+0xc>
    73f8:	85 f6                	test   %esi,%esi
    73fa:	74 04                	je     7400 <fwp_args37+0x10>
    73fc:	c3                   	ret
    73fd:	0f 1f 00             	nopl   (%rax)
    7400:	48 8b 15 31 a7 01 00 	mov    0x1a731(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7407:	48 8b 07             	mov    (%rdi),%rax
    740a:	48 2b 05 ff a6 01 00 	sub    0x1a6ff(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7411:	48 c1 e2 10          	shl    $0x10,%rdx
    7415:	48 39 d0             	cmp    %rdx,%rax
    7418:	73 e2                	jae    73fc <fwp_args37+0xc>
    741a:	48 89 c2             	mov    %rax,%rdx
    741d:	48 c1 ea 10          	shr    $0x10,%rdx
    7421:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7425:	48 8b 15 2c a7 01 00 	mov    0x1a72c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    742c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7430:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7434:	48 85 ff             	test   %rdi,%rdi
    7437:	74 c3                	je     73fc <fwp_args37+0xc>
    7439:	0f b6 0a             	movzbl (%rdx),%ecx
    743c:	80 f9 02             	cmp    $0x2,%cl
    743f:	74 2f                	je     7470 <fwp_args37+0x80>
    7441:	80 f9 01             	cmp    $0x1,%cl
    7444:	75 b6                	jne    73fc <fwp_args37+0xc>
    7446:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7449:	0f b7 c0             	movzwl %ax,%eax
    744c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    744f:	48 0f af c1          	imul   %rcx,%rax
    7453:	48 c1 e8 20          	shr    $0x20,%rax
    7457:	48 39 d0             	cmp    %rdx,%rax
    745a:	73 a0                	jae    73fc <fwp_args37+0xc>
    745c:	48 01 c7             	add    %rax,%rdi
    745f:	0f b6 07             	movzbl (%rdi),%eax
    7462:	84 c0                	test   %al,%al
    7464:	74 96                	je     73fc <fwp_args37+0xc>
    7466:	3c fd                	cmp    $0xfd,%al
    7468:	77 0c                	ja     7476 <fwp_args37+0x86>
    746a:	83 c0 01             	add    $0x1,%eax
    746d:	88 07                	mov    %al,(%rdi)
    746f:	c3                   	ret
    7470:	66 85 c0             	test   %ax,%ax
    7473:	74 ea                	je     745f <fwp_args37+0x6f>
    7475:	c3                   	ret
    7476:	e9 75 dd ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    747b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007480 <fwp_caps37>:
    7480:	f3 0f 1e fa          	endbr64
    7484:	48 83 ec 18          	sub    $0x18,%rsp
    7488:	8b 57 04             	mov    0x4(%rdi),%edx
    748b:	48 89 f8             	mov    %rdi,%rax
    748e:	85 d2                	test   %edx,%edx
    7490:	0f 84 9a 00 00 00    	je     7530 <fwp_caps37+0xb0>
    7496:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    749a:	85 f6                	test   %esi,%esi
    749c:	0f 85 9e 00 00 00    	jne    7540 <fwp_caps37+0xc0>
    74a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    74a7:	e8 44 f7 ff ff       	call   6bf0 <fwp_drop4>
    74ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    74b1:	48 8b 0d 80 a6 01 00 	mov    0x1a680(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    74b8:	48 89 c2             	mov    %rax,%rdx
    74bb:	48 2b 15 4e a6 01 00 	sub    0x1a64e(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    74c2:	48 c1 e1 10          	shl    $0x10,%rcx
    74c6:	48 39 ca             	cmp    %rcx,%rdx
    74c9:	73 6d                	jae    7538 <fwp_caps37+0xb8>
    74cb:	48 89 d1             	mov    %rdx,%rcx
    74ce:	48 c1 e9 10          	shr    $0x10,%rcx
    74d2:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    74d6:	48 8b 0d 7b a6 01 00 	mov    0x1a67b(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    74dd:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    74e1:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    74e5:	48 85 f6             	test   %rsi,%rsi
    74e8:	74 4e                	je     7538 <fwp_caps37+0xb8>
    74ea:	0f b6 39             	movzbl (%rcx),%edi
    74ed:	40 80 ff 02          	cmp    $0x2,%dil
    74f1:	0f 84 b9 00 00 00    	je     75b0 <fwp_caps37+0x130>
    74f7:	40 80 ff 01          	cmp    $0x1,%dil
    74fb:	75 3b                	jne    7538 <fwp_caps37+0xb8>
    74fd:	8b 79 18             	mov    0x18(%rcx),%edi
    7500:	0f b7 d2             	movzwl %dx,%edx
    7503:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7506:	48 0f af d7          	imul   %rdi,%rdx
    750a:	48 c1 ea 20          	shr    $0x20,%rdx
    750e:	48 39 ca             	cmp    %rcx,%rdx
    7511:	73 25                	jae    7538 <fwp_caps37+0xb8>
    7513:	48 01 d6             	add    %rdx,%rsi
    7516:	80 3e 01             	cmpb   $0x1,(%rsi)
    7519:	75 1d                	jne    7538 <fwp_caps37+0xb8>
    751b:	48 89 c7             	mov    %rax,%rdi
    751e:	48 83 c4 18          	add    $0x18,%rsp
    7522:	e9 29 e0 ff ff       	jmp    5550 <fwp_mem_free>
    7527:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    752e:	00 00 
    7530:	85 f6                	test   %esi,%esi
    7532:	0f 84 79 ff ff ff    	je     74b1 <fwp_caps37+0x31>
    7538:	48 83 c4 18          	add    $0x18,%rsp
    753c:	c3                   	ret
    753d:	0f 1f 00             	nopl   (%rax)
    7540:	48 8b 05 f1 a5 01 00 	mov    0x1a5f1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    7547:	48 2b 3d c2 a5 01 00 	sub    0x1a5c2(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    754e:	48 c1 e0 10          	shl    $0x10,%rax
    7552:	48 39 c7             	cmp    %rax,%rdi
    7555:	73 e1                	jae    7538 <fwp_caps37+0xb8>
    7557:	48 89 f8             	mov    %rdi,%rax
    755a:	48 c1 e8 10          	shr    $0x10,%rax
    755e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7562:	48 8b 05 ef a5 01 00 	mov    0x1a5ef(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    7569:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    756d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7571:	48 85 c0             	test   %rax,%rax
    7574:	74 c2                	je     7538 <fwp_caps37+0xb8>
    7576:	0f b6 0a             	movzbl (%rdx),%ecx
    7579:	80 f9 02             	cmp    $0x2,%cl
    757c:	74 42                	je     75c0 <fwp_caps37+0x140>
    757e:	80 f9 01             	cmp    $0x1,%cl
    7581:	75 b5                	jne    7538 <fwp_caps37+0xb8>
    7583:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7586:	0f b7 ff             	movzwl %di,%edi
    7589:	8b 52 1c             	mov    0x1c(%rdx),%edx
    758c:	48 0f af f9          	imul   %rcx,%rdi
    7590:	48 c1 ef 20          	shr    $0x20,%rdi
    7594:	48 39 d7             	cmp    %rdx,%rdi
    7597:	73 9f                	jae    7538 <fwp_caps37+0xb8>
    7599:	48 01 f8             	add    %rdi,%rax
    759c:	0f b6 10             	movzbl (%rax),%edx
    759f:	84 d2                	test   %dl,%dl
    75a1:	74 95                	je     7538 <fwp_caps37+0xb8>
    75a3:	80 fa fd             	cmp    $0xfd,%dl
    75a6:	77 23                	ja     75cb <fwp_caps37+0x14b>
    75a8:	83 c2 01             	add    $0x1,%edx
    75ab:	88 10                	mov    %dl,(%rax)
    75ad:	eb 89                	jmp    7538 <fwp_caps37+0xb8>
    75af:	90                   	nop
    75b0:	66 85 d2             	test   %dx,%dx
    75b3:	0f 85 7f ff ff ff    	jne    7538 <fwp_caps37+0xb8>
    75b9:	e9 58 ff ff ff       	jmp    7516 <fwp_caps37+0x96>
    75be:	66 90                	xchg   %ax,%ax
    75c0:	66 85 ff             	test   %di,%di
    75c3:	0f 85 6f ff ff ff    	jne    7538 <fwp_caps37+0xb8>
    75c9:	eb d1                	jmp    759c <fwp_caps37+0x11c>
    75cb:	48 89 c7             	mov    %rax,%rdi
    75ce:	48 83 c4 18          	add    $0x18,%rsp
    75d2:	e9 19 dc ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    75d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75de:	00 00 

00000000000075e0 <fwp_drop0>:
    75e0:	f3 0f 1e fa          	endbr64
    75e4:	48 8b 15 4d a5 01 00 	mov    0x1a54d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    75eb:	48 89 f8             	mov    %rdi,%rax
    75ee:	48 2b 05 1b a5 01 00 	sub    0x1a51b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    75f5:	48 c1 e2 10          	shl    $0x10,%rdx
    75f9:	48 39 d0             	cmp    %rdx,%rax
    75fc:	0f 83 36 01 00 00    	jae    7738 <fwp_drop0+0x158>
    7602:	48 83 ec 18          	sub    $0x18,%rsp
    7606:	48 8d 35 53 91 01 00 	lea    0x19153(%rip),%rsi        # 20760 <fwp_heap>
    760d:	48 89 c2             	mov    %rax,%rdx
    7610:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7617:	48 c1 ea 10          	shr    $0x10,%rdx
    761b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    761f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7623:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7627:	48 85 d2             	test   %rdx,%rdx
    762a:	74 42                	je     766e <fwp_drop0+0x8e>
    762c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7630:	41 80 f8 02          	cmp    $0x2,%r8b
    7634:	74 42                	je     7678 <fwp_drop0+0x98>
    7636:	41 80 f8 01          	cmp    $0x1,%r8b
    763a:	75 32                	jne    766e <fwp_drop0+0x8e>
    763c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7640:	0f b7 c0             	movzwl %ax,%eax
    7643:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7646:	49 0f af c0          	imul   %r8,%rax
    764a:	48 c1 e8 20          	shr    $0x20,%rax
    764e:	48 39 c8             	cmp    %rcx,%rax
    7651:	73 1b                	jae    766e <fwp_drop0+0x8e>
    7653:	48 01 c2             	add    %rax,%rdx
    7656:	0f b6 02             	movzbl (%rdx),%eax
    7659:	84 c0                	test   %al,%al
    765b:	74 11                	je     766e <fwp_drop0+0x8e>
    765d:	3c 01                	cmp    $0x1,%al
    765f:	74 27                	je     7688 <fwp_drop0+0xa8>
    7661:	3c ff                	cmp    $0xff,%al
    7663:	0f 84 e7 00 00 00    	je     7750 <fwp_drop0+0x170>
    7669:	83 e8 01             	sub    $0x1,%eax
    766c:	88 02                	mov    %al,(%rdx)
    766e:	48 83 c4 18          	add    $0x18,%rsp
    7672:	c3                   	ret
    7673:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7678:	66 85 c0             	test   %ax,%ax
    767b:	74 d9                	je     7656 <fwp_drop0+0x76>
    767d:	48 83 c4 18          	add    $0x18,%rsp
    7681:	c3                   	ret
    7682:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7688:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    768f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7696:	48 89 f8             	mov    %rdi,%rax
    7699:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    769d:	48 29 c8             	sub    %rcx,%rax
    76a0:	48 c1 e2 10          	shl    $0x10,%rdx
    76a4:	48 39 d0             	cmp    %rdx,%rax
    76a7:	73 71                	jae    771a <fwp_drop0+0x13a>
    76a9:	49 89 c2             	mov    %rax,%r10
    76ac:	49 c1 ea 10          	shr    $0x10,%r10
    76b0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    76b4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    76b8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    76bc:	4d 85 d2             	test   %r10,%r10
    76bf:	74 59                	je     771a <fwp_drop0+0x13a>
    76c1:	45 0f b6 19          	movzbl (%r9),%r11d
    76c5:	41 80 fb 02          	cmp    $0x2,%r11b
    76c9:	74 75                	je     7740 <fwp_drop0+0x160>
    76cb:	41 80 fb 01          	cmp    $0x1,%r11b
    76cf:	75 49                	jne    771a <fwp_drop0+0x13a>
    76d1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    76d5:	0f b7 c0             	movzwl %ax,%eax
    76d8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    76dc:	49 0f af c3          	imul   %r11,%rax
    76e0:	48 c1 e8 20          	shr    $0x20,%rax
    76e4:	4c 39 c8             	cmp    %r9,%rax
    76e7:	73 31                	jae    771a <fwp_drop0+0x13a>
    76e9:	49 01 c2             	add    %rax,%r10
    76ec:	41 80 3a 01          	cmpb   $0x1,(%r10)
    76f0:	75 28                	jne    771a <fwp_drop0+0x13a>
    76f2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    76f7:	e8 54 de ff ff       	call   5550 <fwp_mem_free>
    76fc:	48 8d 35 5d 90 01 00 	lea    0x1905d(%rip),%rsi        # 20760 <fwp_heap>
    7703:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    7708:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    770f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7716:	48 c1 e2 10          	shl    $0x10,%rdx
    771a:	4c 89 c0             	mov    %r8,%rax
    771d:	48 29 c8             	sub    %rcx,%rax
    7720:	48 39 d0             	cmp    %rdx,%rax
    7723:	0f 83 45 ff ff ff    	jae    766e <fwp_drop0+0x8e>
    7729:	4c 89 c7             	mov    %r8,%rdi
    772c:	e9 dc fe ff ff       	jmp    760d <fwp_drop0+0x2d>
    7731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7738:	c3                   	ret
    7739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7740:	66 85 c0             	test   %ax,%ax
    7743:	75 d5                	jne    771a <fwp_drop0+0x13a>
    7745:	eb a5                	jmp    76ec <fwp_drop0+0x10c>
    7747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    774e:	00 00 
    7750:	48 89 d0             	mov    %rdx,%rax
    7753:	48 c1 e8 11          	shr    $0x11,%rax
    7757:	48 31 d0             	xor    %rdx,%rax
    775a:	48 89 c1             	mov    %rax,%rcx
    775d:	48 c1 e9 09          	shr    $0x9,%rcx
    7761:	48 31 c8             	xor    %rcx,%rax
    7764:	0f b6 c8             	movzbl %al,%ecx
    7767:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    776e:	00 
    776f:	48 85 c0             	test   %rax,%rax
    7772:	75 15                	jne    7789 <fwp_drop0+0x1a9>
    7774:	eb 4e                	jmp    77c4 <fwp_drop0+0x1e4>
    7776:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    777d:	00 00 00 
    7780:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7784:	48 85 c0             	test   %rax,%rax
    7787:	74 3b                	je     77c4 <fwp_drop0+0x1e4>
    7789:	48 89 c1             	mov    %rax,%rcx
    778c:	48 39 10             	cmp    %rdx,(%rax)
    778f:	75 ef                	jne    7780 <fwp_drop0+0x1a0>
    7791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7795:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7799:	48 89 48 08          	mov    %rcx,0x8(%rax)
    779d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    77a4:	0f 85 c4 fe ff ff    	jne    766e <fwp_drop0+0x8e>
    77aa:	48 89 d7             	mov    %rdx,%rdi
    77ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77b2:	e8 59 db ff ff       	call   5310 <fwp_rc_forget_slot>
    77b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    77bf:	e9 aa fe ff ff       	jmp    766e <fwp_drop0+0x8e>
    77c4:	48 8d 3d d5 4f 00 00 	lea    0x4fd5(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    77cb:	e8 d0 c9 ff ff       	call   41a0 <fwp_trap>

00000000000077d0 <fwp_drop1>:
    77d0:	f3 0f 1e fa          	endbr64
    77d4:	48 8b 15 5d a3 01 00 	mov    0x1a35d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    77db:	48 89 f8             	mov    %rdi,%rax
    77de:	48 2b 05 2b a3 01 00 	sub    0x1a32b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    77e5:	48 c1 e2 10          	shl    $0x10,%rdx
    77e9:	48 39 d0             	cmp    %rdx,%rax
    77ec:	0f 83 36 01 00 00    	jae    7928 <fwp_drop1+0x158>
    77f2:	48 83 ec 18          	sub    $0x18,%rsp
    77f6:	48 8d 35 63 8f 01 00 	lea    0x18f63(%rip),%rsi        # 20760 <fwp_heap>
    77fd:	48 89 c2             	mov    %rax,%rdx
    7800:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7807:	48 c1 ea 10          	shr    $0x10,%rdx
    780b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    780f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7813:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7817:	48 85 d2             	test   %rdx,%rdx
    781a:	74 42                	je     785e <fwp_drop1+0x8e>
    781c:	44 0f b6 01          	movzbl (%rcx),%r8d
    7820:	41 80 f8 02          	cmp    $0x2,%r8b
    7824:	74 42                	je     7868 <fwp_drop1+0x98>
    7826:	41 80 f8 01          	cmp    $0x1,%r8b
    782a:	75 32                	jne    785e <fwp_drop1+0x8e>
    782c:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7830:	0f b7 c0             	movzwl %ax,%eax
    7833:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7836:	49 0f af c0          	imul   %r8,%rax
    783a:	48 c1 e8 20          	shr    $0x20,%rax
    783e:	48 39 c8             	cmp    %rcx,%rax
    7841:	73 1b                	jae    785e <fwp_drop1+0x8e>
    7843:	48 01 c2             	add    %rax,%rdx
    7846:	0f b6 02             	movzbl (%rdx),%eax
    7849:	84 c0                	test   %al,%al
    784b:	74 11                	je     785e <fwp_drop1+0x8e>
    784d:	3c 01                	cmp    $0x1,%al
    784f:	74 27                	je     7878 <fwp_drop1+0xa8>
    7851:	3c ff                	cmp    $0xff,%al
    7853:	0f 84 e7 00 00 00    	je     7940 <fwp_drop1+0x170>
    7859:	83 e8 01             	sub    $0x1,%eax
    785c:	88 02                	mov    %al,(%rdx)
    785e:	48 83 c4 18          	add    $0x18,%rsp
    7862:	c3                   	ret
    7863:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7868:	66 85 c0             	test   %ax,%ax
    786b:	74 d9                	je     7846 <fwp_drop1+0x76>
    786d:	48 83 c4 18          	add    $0x18,%rsp
    7871:	c3                   	ret
    7872:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7878:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    787f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    7886:	48 89 f8             	mov    %rdi,%rax
    7889:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    788d:	48 29 c8             	sub    %rcx,%rax
    7890:	48 c1 e2 10          	shl    $0x10,%rdx
    7894:	48 39 d0             	cmp    %rdx,%rax
    7897:	73 71                	jae    790a <fwp_drop1+0x13a>
    7899:	49 89 c2             	mov    %rax,%r10
    789c:	49 c1 ea 10          	shr    $0x10,%r10
    78a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    78a4:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    78a8:	4d 8b 51 20          	mov    0x20(%r9),%r10
    78ac:	4d 85 d2             	test   %r10,%r10
    78af:	74 59                	je     790a <fwp_drop1+0x13a>
    78b1:	45 0f b6 19          	movzbl (%r9),%r11d
    78b5:	41 80 fb 02          	cmp    $0x2,%r11b
    78b9:	74 75                	je     7930 <fwp_drop1+0x160>
    78bb:	41 80 fb 01          	cmp    $0x1,%r11b
    78bf:	75 49                	jne    790a <fwp_drop1+0x13a>
    78c1:	45 8b 59 18          	mov    0x18(%r9),%r11d
    78c5:	0f b7 c0             	movzwl %ax,%eax
    78c8:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    78cc:	49 0f af c3          	imul   %r11,%rax
    78d0:	48 c1 e8 20          	shr    $0x20,%rax
    78d4:	4c 39 c8             	cmp    %r9,%rax
    78d7:	73 31                	jae    790a <fwp_drop1+0x13a>
    78d9:	49 01 c2             	add    %rax,%r10
    78dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    78e0:	75 28                	jne    790a <fwp_drop1+0x13a>
    78e2:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    78e7:	e8 64 dc ff ff       	call   5550 <fwp_mem_free>
    78ec:	48 8d 35 6d 8e 01 00 	lea    0x18e6d(%rip),%rsi        # 20760 <fwp_heap>
    78f3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    78f8:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    78ff:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    7906:	48 c1 e2 10          	shl    $0x10,%rdx
    790a:	4c 89 c0             	mov    %r8,%rax
    790d:	48 29 c8             	sub    %rcx,%rax
    7910:	48 39 d0             	cmp    %rdx,%rax
    7913:	0f 83 45 ff ff ff    	jae    785e <fwp_drop1+0x8e>
    7919:	4c 89 c7             	mov    %r8,%rdi
    791c:	e9 dc fe ff ff       	jmp    77fd <fwp_drop1+0x2d>
    7921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7928:	c3                   	ret
    7929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7930:	66 85 c0             	test   %ax,%ax
    7933:	75 d5                	jne    790a <fwp_drop1+0x13a>
    7935:	eb a5                	jmp    78dc <fwp_drop1+0x10c>
    7937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    793e:	00 00 
    7940:	48 89 d0             	mov    %rdx,%rax
    7943:	48 c1 e8 11          	shr    $0x11,%rax
    7947:	48 31 d0             	xor    %rdx,%rax
    794a:	48 89 c1             	mov    %rax,%rcx
    794d:	48 c1 e9 09          	shr    $0x9,%rcx
    7951:	48 31 c8             	xor    %rcx,%rax
    7954:	0f b6 c8             	movzbl %al,%ecx
    7957:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    795e:	00 
    795f:	48 85 c0             	test   %rax,%rax
    7962:	75 25                	jne    7989 <fwp_drop1+0x1b9>
    7964:	eb 5e                	jmp    79c4 <fwp_drop1+0x1f4>
    7966:	0f 1f 40 00          	nopl   0x0(%rax)
    796a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7971:	00 00 00 00 
    7975:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    797c:	00 00 00 00 
    7980:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7984:	48 85 c0             	test   %rax,%rax
    7987:	74 3b                	je     79c4 <fwp_drop1+0x1f4>
    7989:	48 89 c1             	mov    %rax,%rcx
    798c:	48 39 10             	cmp    %rdx,(%rax)
    798f:	75 ef                	jne    7980 <fwp_drop1+0x1b0>
    7991:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7995:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7999:	48 89 48 08          	mov    %rcx,0x8(%rax)
    799d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    79a4:	0f 85 b4 fe ff ff    	jne    785e <fwp_drop1+0x8e>
    79aa:	48 89 d7             	mov    %rdx,%rdi
    79ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    79b2:	e8 59 d9 ff ff       	call   5310 <fwp_rc_forget_slot>
    79b7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79bc:	c6 02 fe             	movb   $0xfe,(%rdx)
    79bf:	e9 9a fe ff ff       	jmp    785e <fwp_drop1+0x8e>
    79c4:	48 8d 3d d5 4d 00 00 	lea    0x4dd5(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    79cb:	e8 d0 c7 ff ff       	call   41a0 <fwp_trap>

00000000000079d0 <fwp_drop10>:
    79d0:	48 8b 0d 61 a1 01 00 	mov    0x1a161(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    79d7:	48 89 f8             	mov    %rdi,%rax
    79da:	48 2b 05 2f a1 01 00 	sub    0x1a12f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    79e1:	48 c1 e1 10          	shl    $0x10,%rcx
    79e5:	48 39 c8             	cmp    %rcx,%rax
    79e8:	0f 83 c2 01 00 00    	jae    7bb0 <fwp_drop10+0x1e0>
    79ee:	48 83 ec 18          	sub    $0x18,%rsp
    79f2:	48 89 fa             	mov    %rdi,%rdx
    79f5:	48 8d 35 64 8d 01 00 	lea    0x18d64(%rip),%rsi        # 20760 <fwp_heap>
    79fc:	48 89 c1             	mov    %rax,%rcx
    79ff:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    7a06:	48 c1 e9 10          	shr    $0x10,%rcx
    7a0a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7a0e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    7a12:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    7a16:	48 85 c9             	test   %rcx,%rcx
    7a19:	74 46                	je     7a61 <fwp_drop10+0x91>
    7a1b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    7a1f:	41 80 f9 02          	cmp    $0x2,%r9b
    7a23:	0f 84 d7 00 00 00    	je     7b00 <fwp_drop10+0x130>
    7a29:	41 80 f9 01          	cmp    $0x1,%r9b
    7a2d:	75 32                	jne    7a61 <fwp_drop10+0x91>
    7a2f:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    7a33:	0f b7 c0             	movzwl %ax,%eax
    7a36:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    7a39:	49 0f af c1          	imul   %r9,%rax
    7a3d:	48 c1 e8 20          	shr    $0x20,%rax
    7a41:	48 39 f8             	cmp    %rdi,%rax
    7a44:	73 1b                	jae    7a61 <fwp_drop10+0x91>
    7a46:	48 01 c1             	add    %rax,%rcx
    7a49:	0f b6 01             	movzbl (%rcx),%eax
    7a4c:	84 c0                	test   %al,%al
    7a4e:	74 11                	je     7a61 <fwp_drop10+0x91>
    7a50:	3c 01                	cmp    $0x1,%al
    7a52:	74 1c                	je     7a70 <fwp_drop10+0xa0>
    7a54:	3c ff                	cmp    $0xff,%al
    7a56:	0f 84 5c 01 00 00    	je     7bb8 <fwp_drop10+0x1e8>
    7a5c:	83 e8 01             	sub    $0x1,%eax
    7a5f:	88 01                	mov    %al,(%rcx)
    7a61:	48 83 c4 18          	add    $0x18,%rsp
    7a65:	c3                   	ret
    7a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7a6d:	00 00 00 
    7a70:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7a77:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7a7e:	48 89 d0             	mov    %rdx,%rax
    7a81:	49 89 d1             	mov    %rdx,%r9
    7a84:	48 c1 e1 10          	shl    $0x10,%rcx
    7a88:	48 29 f8             	sub    %rdi,%rax
    7a8b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    7a8f:	78 7f                	js     7b10 <fwp_drop10+0x140>
    7a91:	48 39 c8             	cmp    %rcx,%rax
    7a94:	73 cb                	jae    7a61 <fwp_drop10+0x91>
    7a96:	48 89 c1             	mov    %rax,%rcx
    7a99:	48 c1 e9 10          	shr    $0x10,%rcx
    7a9d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    7aa1:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    7aa5:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7aa9:	48 85 f6             	test   %rsi,%rsi
    7aac:	74 b3                	je     7a61 <fwp_drop10+0x91>
    7aae:	0f b6 39             	movzbl (%rcx),%edi
    7ab1:	40 80 ff 02          	cmp    $0x2,%dil
    7ab5:	74 39                	je     7af0 <fwp_drop10+0x120>
    7ab7:	40 80 ff 01          	cmp    $0x1,%dil
    7abb:	75 a4                	jne    7a61 <fwp_drop10+0x91>
    7abd:	8b 79 18             	mov    0x18(%rcx),%edi
    7ac0:	0f b7 c0             	movzwl %ax,%eax
    7ac3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7ac6:	48 0f af c7          	imul   %rdi,%rax
    7aca:	48 c1 e8 20          	shr    $0x20,%rax
    7ace:	48 39 c8             	cmp    %rcx,%rax
    7ad1:	73 8e                	jae    7a61 <fwp_drop10+0x91>
    7ad3:	48 01 c6             	add    %rax,%rsi
    7ad6:	80 3e 01             	cmpb   $0x1,(%rsi)
    7ad9:	75 86                	jne    7a61 <fwp_drop10+0x91>
    7adb:	48 89 d7             	mov    %rdx,%rdi
    7ade:	48 83 c4 18          	add    $0x18,%rsp
    7ae2:	e9 69 da ff ff       	jmp    5550 <fwp_mem_free>
    7ae7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7aee:	00 00 
    7af0:	66 85 c0             	test   %ax,%ax
    7af3:	74 e1                	je     7ad6 <fwp_drop10+0x106>
    7af5:	48 83 c4 18          	add    $0x18,%rsp
    7af9:	c3                   	ret
    7afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b00:	66 85 c0             	test   %ax,%ax
    7b03:	0f 84 40 ff ff ff    	je     7a49 <fwp_drop10+0x79>
    7b09:	48 83 c4 18          	add    $0x18,%rsp
    7b0d:	c3                   	ret
    7b0e:	66 90                	xchg   %ax,%ax
    7b10:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    7b14:	48 39 c8             	cmp    %rcx,%rax
    7b17:	73 74                	jae    7b8d <fwp_drop10+0x1bd>
    7b19:	49 89 c2             	mov    %rax,%r10
    7b1c:	49 c1 ea 10          	shr    $0x10,%r10
    7b20:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    7b24:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    7b28:	4d 8b 50 20          	mov    0x20(%r8),%r10
    7b2c:	4d 85 d2             	test   %r10,%r10
    7b2f:	74 5c                	je     7b8d <fwp_drop10+0x1bd>
    7b31:	45 0f b6 18          	movzbl (%r8),%r11d
    7b35:	41 80 fb 02          	cmp    $0x2,%r11b
    7b39:	74 6d                	je     7ba8 <fwp_drop10+0x1d8>
    7b3b:	41 80 fb 01          	cmp    $0x1,%r11b
    7b3f:	75 4c                	jne    7b8d <fwp_drop10+0x1bd>
    7b41:	45 8b 58 18          	mov    0x18(%r8),%r11d
    7b45:	0f b7 c0             	movzwl %ax,%eax
    7b48:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    7b4c:	49 0f af c3          	imul   %r11,%rax
    7b50:	48 c1 e8 20          	shr    $0x20,%rax
    7b54:	4c 39 c0             	cmp    %r8,%rax
    7b57:	73 34                	jae    7b8d <fwp_drop10+0x1bd>
    7b59:	49 01 c2             	add    %rax,%r10
    7b5c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    7b60:	75 2b                	jne    7b8d <fwp_drop10+0x1bd>
    7b62:	4c 89 cf             	mov    %r9,%rdi
    7b65:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7b6a:	e8 e1 d9 ff ff       	call   5550 <fwp_mem_free>
    7b6f:	48 8d 35 ea 8b 01 00 	lea    0x18bea(%rip),%rsi        # 20760 <fwp_heap>
    7b76:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7b7b:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    7b82:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    7b89:	48 c1 e1 10          	shl    $0x10,%rcx
    7b8d:	48 89 d0             	mov    %rdx,%rax
    7b90:	48 29 f8             	sub    %rdi,%rax
    7b93:	48 39 c8             	cmp    %rcx,%rax
    7b96:	0f 82 60 fe ff ff    	jb     79fc <fwp_drop10+0x2c>
    7b9c:	e9 c0 fe ff ff       	jmp    7a61 <fwp_drop10+0x91>
    7ba1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ba8:	66 85 c0             	test   %ax,%ax
    7bab:	75 e0                	jne    7b8d <fwp_drop10+0x1bd>
    7bad:	eb ad                	jmp    7b5c <fwp_drop10+0x18c>
    7baf:	90                   	nop
    7bb0:	c3                   	ret
    7bb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bb8:	48 89 c8             	mov    %rcx,%rax
    7bbb:	48 c1 e8 11          	shr    $0x11,%rax
    7bbf:	48 31 c8             	xor    %rcx,%rax
    7bc2:	48 89 c2             	mov    %rax,%rdx
    7bc5:	48 c1 ea 09          	shr    $0x9,%rdx
    7bc9:	48 31 d0             	xor    %rdx,%rax
    7bcc:	0f b6 d0             	movzbl %al,%edx
    7bcf:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7bd6:	00 
    7bd7:	48 85 c0             	test   %rax,%rax
    7bda:	75 0d                	jne    7be9 <fwp_drop10+0x219>
    7bdc:	eb 46                	jmp    7c24 <fwp_drop10+0x254>
    7bde:	66 90                	xchg   %ax,%ax
    7be0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	74 3b                	je     7c24 <fwp_drop10+0x254>
    7be9:	48 89 c2             	mov    %rax,%rdx
    7bec:	48 39 08             	cmp    %rcx,(%rax)
    7bef:	75 ef                	jne    7be0 <fwp_drop10+0x210>
    7bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bf5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7bf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7bfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7c04:	0f 85 57 fe ff ff    	jne    7a61 <fwp_drop10+0x91>
    7c0a:	48 89 cf             	mov    %rcx,%rdi
    7c0d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7c12:	e8 f9 d6 ff ff       	call   5310 <fwp_rc_forget_slot>
    7c17:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7c1c:	c6 01 fe             	movb   $0xfe,(%rcx)
    7c1f:	e9 3d fe ff ff       	jmp    7a61 <fwp_drop10+0x91>
    7c24:	48 8d 3d 75 4b 00 00 	lea    0x4b75(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    7c2b:	e8 70 c5 ff ff       	call   41a0 <fwp_trap>

0000000000007c30 <f37>:
    7c30:	41 57                	push   %r15
    7c32:	41 56                	push   %r14
    7c34:	41 55                	push   %r13
    7c36:	41 54                	push   %r12
    7c38:	55                   	push   %rbp
    7c39:	53                   	push   %rbx
    7c3a:	48 83 ec 38          	sub    $0x38,%rsp
    7c3e:	48 8b 15 f3 9e 01 00 	mov    0x19ef3(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7c45:	48 8b 0d c4 9e 01 00 	mov    0x19ec4(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    7c4c:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    7c53:	00 00 
    7c55:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    7c5a:	49 89 fc             	mov    %rdi,%r12
    7c5d:	48 c1 e2 10          	shl    $0x10,%rdx
    7c61:	48 85 ff             	test   %rdi,%rdi
    7c64:	0f 84 bc 02 00 00    	je     7f26 <f37+0x2f6>
    7c6a:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7c6f:	48 89 d8             	mov    %rbx,%rax
    7c72:	48 29 c8             	sub    %rcx,%rax
    7c75:	48 39 d0             	cmp    %rdx,%rax
    7c78:	0f 83 72 03 00 00    	jae    7ff0 <f37+0x3c0>
    7c7e:	48 89 c2             	mov    %rax,%rdx
    7c81:	48 c1 ea 10          	shr    $0x10,%rdx
    7c85:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c89:	48 8b 15 c8 9e 01 00 	mov    0x19ec8(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7c90:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c94:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7c98:	48 85 ff             	test   %rdi,%rdi
    7c9b:	0f 84 4f 03 00 00    	je     7ff0 <f37+0x3c0>
    7ca1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ca4:	80 f9 02             	cmp    $0x2,%cl
    7ca7:	0f 84 53 02 00 00    	je     7f00 <f37+0x2d0>
    7cad:	80 f9 01             	cmp    $0x1,%cl
    7cb0:	75 24                	jne    7cd6 <f37+0xa6>
    7cb2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7cb5:	0f b7 c0             	movzwl %ax,%eax
    7cb8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7cbb:	48 0f af c1          	imul   %rcx,%rax
    7cbf:	48 c1 e8 20          	shr    $0x20,%rax
    7cc3:	48 39 d0             	cmp    %rdx,%rax
    7cc6:	73 0e                	jae    7cd6 <f37+0xa6>
    7cc8:	48 01 c7             	add    %rax,%rdi
    7ccb:	0f b6 07             	movzbl (%rdi),%eax
    7cce:	84 c0                	test   %al,%al
    7cd0:	0f 85 ca 02 00 00    	jne    7fa0 <f37+0x370>
    7cd6:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7cdb:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
    7ce0:	ba 01 00 00 00       	mov    $0x1,%edx
    7ce5:	48 85 db             	test   %rbx,%rbx
    7ce8:	74 13                	je     7cfd <f37+0xcd>
    7cea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7cf0:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    7cf4:	48 83 c2 01          	add    $0x1,%rdx
    7cf8:	48 85 db             	test   %rbx,%rbx
    7cfb:	75 f3                	jne    7cf0 <f37+0xc0>
    7cfd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7d02:	48 85 c0             	test   %rax,%rax
    7d05:	0f 84 15 03 00 00    	je     8020 <f37+0x3f0>
    7d0b:	31 db                	xor    %ebx,%ebx
    7d0d:	0f 1f 00             	nopl   (%rax)
    7d10:	48 8b 40 10          	mov    0x10(%rax),%rax
    7d14:	48 83 c3 01          	add    $0x1,%rbx
    7d18:	48 85 c0             	test   %rax,%rax
    7d1b:	75 f3                	jne    7d10 <f37+0xe0>
    7d1d:	48 39 d3             	cmp    %rdx,%rbx
    7d20:	48 0f 47 da          	cmova  %rdx,%rbx
    7d24:	48 89 d8             	mov    %rbx,%rax
    7d27:	48 c1 e8 3c          	shr    $0x3c,%rax
    7d2b:	0f 85 8f 03 00 00    	jne    80c0 <f37+0x490>
    7d31:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    7d35:	be 02 00 00 00       	mov    $0x2,%esi
    7d3a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    7d41:	00 
    7d42:	e8 09 dd ff ff       	call   5a50 <fwp_heap_alloc>
    7d47:	48 89 28             	mov    %rbp,(%rax)
    7d4a:	48 8b 15 e7 9d 01 00 	mov    0x19de7(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7d51:	49 89 c6             	mov    %rax,%r14
    7d54:	48 2b 05 b5 9d 01 00 	sub    0x19db5(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7d5b:	48 c1 e2 10          	shl    $0x10,%rdx
    7d5f:	48 39 d0             	cmp    %rdx,%rax
    7d62:	73 57                	jae    7dbb <f37+0x18b>
    7d64:	48 89 c2             	mov    %rax,%rdx
    7d67:	48 c1 ea 10          	shr    $0x10,%rdx
    7d6b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d6f:	48 8b 15 e2 9d 01 00 	mov    0x19de2(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7d76:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d7a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7d7e:	48 85 ed             	test   %rbp,%rbp
    7d81:	74 38                	je     7dbb <f37+0x18b>
    7d83:	0f b6 0a             	movzbl (%rdx),%ecx
    7d86:	80 f9 02             	cmp    $0x2,%cl
    7d89:	0f 84 51 02 00 00    	je     7fe0 <f37+0x3b0>
    7d8f:	80 f9 01             	cmp    $0x1,%cl
    7d92:	75 27                	jne    7dbb <f37+0x18b>
    7d94:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d97:	0f b7 c0             	movzwl %ax,%eax
    7d9a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d9d:	48 0f af c1          	imul   %rcx,%rax
    7da1:	48 c1 e8 20          	shr    $0x20,%rax
    7da5:	48 39 d0             	cmp    %rdx,%rax
    7da8:	73 11                	jae    7dbb <f37+0x18b>
    7daa:	48 01 c5             	add    %rax,%rbp
    7dad:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7db1:	0f 84 d5 02 00 00    	je     808c <f37+0x45c>
    7db7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7dbb:	48 85 db             	test   %rbx,%rbx
    7dbe:	74 5d                	je     7e1d <f37+0x1ed>
    7dc0:	48 c1 e3 04          	shl    $0x4,%rbx
    7dc4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    7dc9:	4c 89 f5             	mov    %r14,%rbp
    7dcc:	4d 89 e5             	mov    %r12,%r13
    7dcf:	4c 01 f3             	add    %r14,%rbx
    7dd2:	0f 1f 00             	nopl   (%rax)
    7dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7ddc:	00 00 00 00 
    7de0:	49 8b 45 08          	mov    0x8(%r13),%rax
    7de4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    7de8:	48 83 c5 10          	add    $0x10,%rbp
    7dec:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    7df1:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    7df5:	48 8b 78 10          	mov    0x10(%rax),%rdi
    7df9:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    7dfe:	e8 9d e3 ff ff       	call   61a0 <w120>
    7e03:	66 48 0f 6e d0       	movq   %rax,%xmm2
    7e08:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7e0c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    7e10:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    7e14:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    7e18:	48 39 dd             	cmp    %rbx,%rbp
    7e1b:	75 c3                	jne    7de0 <f37+0x1b0>
    7e1d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7e22:	e8 c9 ed ff ff       	call   6bf0 <fwp_drop4>
    7e27:	4c 89 e7             	mov    %r12,%rdi
    7e2a:	e8 c1 ed ff ff       	call   6bf0 <fwp_drop4>
    7e2f:	4c 89 f7             	mov    %r14,%rdi
    7e32:	e8 29 e5 ff ff       	call   6360 <w176.constprop.0>
    7e37:	4c 89 f7             	mov    %r14,%rdi
    7e3a:	48 89 c3             	mov    %rax,%rbx
    7e3d:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    7e43:	e8 88 fb ff ff       	call   79d0 <fwp_drop10>
    7e48:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    7e4e:	66 48 0f 6e db       	movq   %rbx,%xmm3
    7e53:	31 ff                	xor    %edi,%edi
    7e55:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    7e5a:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    7e5e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7e63:	e8 08 dd ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    7e68:	48 8b 15 c9 9c 01 00 	mov    0x19cc9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7e6f:	48 89 c5             	mov    %rax,%rbp
    7e72:	48 2b 05 97 9c 01 00 	sub    0x19c97(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7e79:	48 c1 e2 10          	shl    $0x10,%rdx
    7e7d:	48 39 d0             	cmp    %rdx,%rax
    7e80:	73 55                	jae    7ed7 <f37+0x2a7>
    7e82:	48 89 c2             	mov    %rax,%rdx
    7e85:	48 c1 ea 10          	shr    $0x10,%rdx
    7e89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7e8d:	48 8b 15 c4 9c 01 00 	mov    0x19cc4(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7e94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7e98:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    7e9c:	48 85 db             	test   %rbx,%rbx
    7e9f:	74 36                	je     7ed7 <f37+0x2a7>
    7ea1:	0f b6 0a             	movzbl (%rdx),%ecx
    7ea4:	80 f9 02             	cmp    $0x2,%cl
    7ea7:	0f 84 1b 01 00 00    	je     7fc8 <f37+0x398>
    7ead:	80 f9 01             	cmp    $0x1,%cl
    7eb0:	75 25                	jne    7ed7 <f37+0x2a7>
    7eb2:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7eb5:	0f b7 c0             	movzwl %ax,%eax
    7eb8:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ebb:	48 0f af c1          	imul   %rcx,%rax
    7ebf:	48 c1 e8 20          	shr    $0x20,%rax
    7ec3:	48 39 d0             	cmp    %rdx,%rax
    7ec6:	73 0f                	jae    7ed7 <f37+0x2a7>
    7ec8:	48 01 c3             	add    %rax,%rbx
    7ecb:	80 3b ff             	cmpb   $0xff,(%rbx)
    7ece:	0f 84 ab 01 00 00    	je     807f <f37+0x44f>
    7ed4:	c6 03 01             	movb   $0x1,(%rbx)
    7ed7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    7edc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7ee3:	00 00 
    7ee5:	0f 85 d0 01 00 00    	jne    80bb <f37+0x48b>
    7eeb:	48 83 c4 38          	add    $0x38,%rsp
    7eef:	48 89 e8             	mov    %rbp,%rax
    7ef2:	5b                   	pop    %rbx
    7ef3:	5d                   	pop    %rbp
    7ef4:	41 5c                	pop    %r12
    7ef6:	41 5d                	pop    %r13
    7ef8:	41 5e                	pop    %r14
    7efa:	41 5f                	pop    %r15
    7efc:	c3                   	ret
    7efd:	0f 1f 00             	nopl   (%rax)
    7f00:	66 85 c0             	test   %ax,%ax
    7f03:	0f 85 cd fd ff ff    	jne    7cd6 <f37+0xa6>
    7f09:	0f b6 07             	movzbl (%rdi),%eax
    7f0c:	84 c0                	test   %al,%al
    7f0e:	0f 84 c2 fd ff ff    	je     7cd6 <f37+0xa6>
    7f14:	3c fd                	cmp    $0xfd,%al
    7f16:	0f 87 95 01 00 00    	ja     80b1 <f37+0x481>
    7f1c:	83 c0 01             	add    $0x1,%eax
    7f1f:	88 07                	mov    %al,(%rdi)
    7f21:	e9 b0 fd ff ff       	jmp    7cd6 <f37+0xa6>
    7f26:	48 f7 d9             	neg    %rcx
    7f29:	48 39 d1             	cmp    %rdx,%rcx
    7f2c:	0f 83 ee 00 00 00    	jae    8020 <f37+0x3f0>
    7f32:	48 89 c8             	mov    %rcx,%rax
    7f35:	48 c1 e8 10          	shr    $0x10,%rax
    7f39:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7f3d:	48 8b 05 14 9c 01 00 	mov    0x19c14(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    7f44:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7f48:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f4c:	48 85 ff             	test   %rdi,%rdi
    7f4f:	0f 84 cb 00 00 00    	je     8020 <f37+0x3f0>
    7f55:	0f b6 02             	movzbl (%rdx),%eax
    7f58:	3c 02                	cmp    $0x2,%al
    7f5a:	0f 84 9a 00 00 00    	je     7ffa <f37+0x3ca>
    7f60:	3c 01                	cmp    $0x1,%al
    7f62:	0f 85 b8 00 00 00    	jne    8020 <f37+0x3f0>
    7f68:	0f b7 c1             	movzwl %cx,%eax
    7f6b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f6e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f71:	48 0f af c1          	imul   %rcx,%rax
    7f75:	48 c1 e8 20          	shr    $0x20,%rax
    7f79:	48 39 d0             	cmp    %rdx,%rax
    7f7c:	0f 83 9e 00 00 00    	jae    8020 <f37+0x3f0>
    7f82:	48 01 c7             	add    %rax,%rdi
    7f85:	0f b6 07             	movzbl (%rdi),%eax
    7f88:	84 c0                	test   %al,%al
    7f8a:	0f 84 90 00 00 00    	je     8020 <f37+0x3f0>
    7f90:	31 db                	xor    %ebx,%ebx
    7f92:	0f 1f 00             	nopl   (%rax)
    7f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7f9c:	00 00 00 00 
    7fa0:	3c fd                	cmp    $0xfd,%al
    7fa2:	0f 87 f1 00 00 00    	ja     8099 <f37+0x469>
    7fa8:	83 c0 01             	add    $0x1,%eax
    7fab:	88 07                	mov    %al,(%rdi)
    7fad:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7fb2:	31 d2                	xor    %edx,%edx
    7fb4:	4d 85 e4             	test   %r12,%r12
    7fb7:	0f 85 1e fd ff ff    	jne    7cdb <f37+0xab>
    7fbd:	e9 3b fd ff ff       	jmp    7cfd <f37+0xcd>
    7fc2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7fc8:	66 85 c0             	test   %ax,%ax
    7fcb:	0f 85 06 ff ff ff    	jne    7ed7 <f37+0x2a7>
    7fd1:	e9 f5 fe ff ff       	jmp    7ecb <f37+0x29b>
    7fd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7fdd:	00 00 00 
    7fe0:	66 85 c0             	test   %ax,%ax
    7fe3:	0f 85 d2 fd ff ff    	jne    7dbb <f37+0x18b>
    7fe9:	e9 bf fd ff ff       	jmp    7dad <f37+0x17d>
    7fee:	66 90                	xchg   %ax,%ax
    7ff0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    7ff5:	e9 e6 fc ff ff       	jmp    7ce0 <f37+0xb0>
    7ffa:	66 85 c9             	test   %cx,%cx
    7ffd:	75 21                	jne    8020 <f37+0x3f0>
    7fff:	0f b6 07             	movzbl (%rdi),%eax
    8002:	84 c0                	test   %al,%al
    8004:	74 1a                	je     8020 <f37+0x3f0>
    8006:	3c fd                	cmp    $0xfd,%al
    8008:	0f 87 be 00 00 00    	ja     80cc <f37+0x49c>
    800e:	83 c0 01             	add    $0x1,%eax
    8011:	88 07                	mov    %al,(%rdi)
    8013:	66 90                	xchg   %ax,%ax
    8015:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    801c:	00 00 00 00 
    8020:	be 02 00 00 00       	mov    $0x2,%esi
    8025:	bf 08 00 00 00       	mov    $0x8,%edi
    802a:	e8 21 da ff ff       	call   5a50 <fwp_heap_alloc>
    802f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8036:	48 8b 15 fb 9a 01 00 	mov    0x19afb(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    803d:	49 89 c6             	mov    %rax,%r14
    8040:	48 2b 05 c9 9a 01 00 	sub    0x19ac9(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8047:	48 c1 e2 10          	shl    $0x10,%rdx
    804b:	48 39 d0             	cmp    %rdx,%rax
    804e:	73 53                	jae    80a3 <f37+0x473>
    8050:	48 89 c2             	mov    %rax,%rdx
    8053:	48 c1 ea 10          	shr    $0x10,%rdx
    8057:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    805b:	48 8b 15 f6 9a 01 00 	mov    0x19af6(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8062:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8066:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    806a:	48 85 ed             	test   %rbp,%rbp
    806d:	74 34                	je     80a3 <f37+0x473>
    806f:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    8076:	00 00 
    8078:	31 db                	xor    %ebx,%ebx
    807a:	e9 04 fd ff ff       	jmp    7d83 <f37+0x153>
    807f:	48 89 df             	mov    %rbx,%rdi
    8082:	e8 89 d2 ff ff       	call   5310 <fwp_rc_forget_slot>
    8087:	e9 48 fe ff ff       	jmp    7ed4 <f37+0x2a4>
    808c:	48 89 ef             	mov    %rbp,%rdi
    808f:	e8 7c d2 ff ff       	call   5310 <fwp_rc_forget_slot>
    8094:	e9 1e fd ff ff       	jmp    7db7 <f37+0x187>
    8099:	e8 52 d1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    809e:	e9 0a ff ff ff       	jmp    7fad <f37+0x37d>
    80a3:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    80aa:	00 00 
    80ac:	e9 6c fd ff ff       	jmp    7e1d <f37+0x1ed>
    80b1:	e8 3a d1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    80b6:	e9 1b fc ff ff       	jmp    7cd6 <f37+0xa6>
    80bb:	e8 a0 b3 ff ff       	call   3460 <__stack_chk_fail@plt>
    80c0:	48 8d 3d 66 40 00 00 	lea    0x4066(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    80c7:	e8 d4 c0 ff ff       	call   41a0 <fwp_trap>
    80cc:	e8 1f d1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    80d1:	e9 4a ff ff ff       	jmp    8020 <f37+0x3f0>
    80d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80dd:	00 00 00 

00000000000080e0 <fwp_owned_entry37>:
    80e0:	f3 0f 1e fa          	endbr64
    80e4:	48 8b 3f             	mov    (%rdi),%rdi
    80e7:	e9 44 fb ff ff       	jmp    7c30 <f37>
    80ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000080f0 <e37>:
    80f0:	f3 0f 1e fa          	endbr64
    80f4:	53                   	push   %rbx
    80f5:	48 8b 1f             	mov    (%rdi),%rbx
    80f8:	48 89 df             	mov    %rbx,%rdi
    80fb:	e8 e0 e2 ff ff       	call   63e0 <fwp_rc_share>
    8100:	48 89 df             	mov    %rbx,%rdi
    8103:	e8 28 fb ff ff       	call   7c30 <f37>
    8108:	48 89 c3             	mov    %rax,%rbx
    810b:	48 89 c7             	mov    %rax,%rdi
    810e:	e8 cd e2 ff ff       	call   63e0 <fwp_rc_share>
    8113:	48 89 d8             	mov    %rbx,%rax
    8116:	5b                   	pop    %rbx
    8117:	c3                   	ret
    8118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    811f:	00 

0000000000008120 <fwp_write>:
    8120:	41 57                	push   %r15
    8122:	41 56                	push   %r14
    8124:	41 55                	push   %r13
    8126:	41 54                	push   %r12
    8128:	55                   	push   %rbp
    8129:	53                   	push   %rbx
    812a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8131:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8138:	00 00 
    813a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8141:	00 
    8142:	49 89 d4             	mov    %rdx,%r12
    8145:	8b 12                	mov    (%rdx),%edx
    8147:	83 fa 19             	cmp    $0x19,%edx
    814a:	77 6a                	ja     81b6 <fwp_write+0x96>
    814c:	48 89 f5             	mov    %rsi,%rbp
    814f:	89 d0                	mov    %edx,%eax
    8151:	89 ce                	mov    %ecx,%esi
    8153:	48 89 fb             	mov    %rdi,%rbx
    8156:	48 8d 0d b3 48 00 00 	lea    0x48b3(%rip),%rcx        # ca10 <_IO_stdin_used+0xa10>
    815d:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8161:	48 01 c8             	add    %rcx,%rax
    8164:	3e ff e0             	notrack jmp *%rax
    8167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    816e:	00 00 
    8170:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8174:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8178:	48 89 ca             	mov    %rcx,%rdx
    817b:	48 85 c9             	test   %rcx,%rcx
    817e:	0f 88 9c 0c 00 00    	js     8e20 <fwp_write+0xd00>
    8184:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    818b:	00 
    818c:	48 89 c6             	mov    %rax,%rsi
    818f:	4c 89 e7             	mov    %r12,%rdi
    8192:	e8 a9 b8 ff ff       	call   3a40 <fwp_fmt_u128>
    8197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    819e:	00 00 
    81a0:	4c 89 e7             	mov    %r12,%rdi
    81a3:	e8 a8 b2 ff ff       	call   3450 <strlen@plt>
    81a8:	4c 89 e6             	mov    %r12,%rsi
    81ab:	48 89 df             	mov    %rbx,%rdi
    81ae:	48 89 c2             	mov    %rax,%rdx
    81b1:	e8 ba be ff ff       	call   4070 <buf_put>
    81b6:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    81bd:	00 
    81be:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    81c5:	00 00 
    81c7:	0f 85 28 04 00 00    	jne    85f5 <fwp_write+0x4d5>
    81cd:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    81d4:	5b                   	pop    %rbx
    81d5:	5d                   	pop    %rbp
    81d6:	41 5c                	pop    %r12
    81d8:	41 5d                	pop    %r13
    81da:	41 5e                	pop    %r14
    81dc:	41 5f                	pop    %r15
    81de:	c3                   	ret
    81df:	90                   	nop
    81e0:	49 89 e9             	mov    %rbp,%r9
    81e3:	4c 8d 05 6d 3f 00 00 	lea    0x3f6d(%rip),%r8        # c157 <_IO_stdin_used+0x157>
    81ea:	b9 00 02 00 00       	mov    $0x200,%ecx
    81ef:	ba 02 00 00 00       	mov    $0x2,%edx
    81f4:	be 00 02 00 00       	mov    $0x200,%esi
    81f9:	31 c0                	xor    %eax,%eax
    81fb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8202:	00 
    8203:	e8 a8 b1 ff ff       	call   33b0 <__snprintf_chk@plt>
    8208:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    820f:	00 
    8210:	e8 3b b2 ff ff       	call   3450 <strlen@plt>
    8215:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    821c:	00 
    821d:	48 89 df             	mov    %rbx,%rdi
    8220:	48 89 c2             	mov    %rax,%rdx
    8223:	e8 48 be ff ff       	call   4070 <buf_put>
    8228:	eb 8c                	jmp    81b6 <fwp_write+0x96>
    822a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8230:	49 89 e9             	mov    %rbp,%r9
    8233:	4c 8d 05 18 3f 00 00 	lea    0x3f18(%rip),%r8        # c152 <_IO_stdin_used+0x152>
    823a:	eb ae                	jmp    81ea <fwp_write+0xca>
    823c:	0f 1f 40 00          	nopl   0x0(%rax)
    8240:	83 fa 13             	cmp    $0x13,%edx
    8243:	48 8d 05 fe 3e 00 00 	lea    0x3efe(%rip),%rax        # c148 <_IO_stdin_used+0x148>
    824a:	48 8d 35 fc 3e 00 00 	lea    0x3efc(%rip),%rsi        # c14d <_IO_stdin_used+0x14d>
    8251:	ba 04 00 00 00       	mov    $0x4,%edx
    8256:	48 0f 44 f0          	cmove  %rax,%rsi
    825a:	45 31 ed             	xor    %r13d,%r13d
    825d:	e8 0e be ff ff       	call   4070 <buf_put>
    8262:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8267:	0f 84 a3 08 00 00    	je     8b10 <fwp_write+0x9f0>
    826d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8272:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8277:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    827c:	48 89 df             	mov    %rbx,%rdi
    827f:	49 0f 44 c5          	cmove  %r13,%rax
    8283:	31 c9                	xor    %ecx,%ecx
    8285:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    828a:	e8 91 fe ff ff       	call   8120 <fwp_write>
    828f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8294:	0f 84 6e 09 00 00    	je     8c08 <fwp_write+0xae8>
    829a:	49 83 c5 01          	add    $0x1,%r13
    829e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    82a2:	0f 83 68 08 00 00    	jae    8b10 <fwp_write+0x9f0>
    82a8:	ba 02 00 00 00       	mov    $0x2,%edx
    82ad:	48 8d 35 e3 3e 00 00 	lea    0x3ee3(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    82b4:	48 89 df             	mov    %rbx,%rdi
    82b7:	e8 b4 bd ff ff       	call   4070 <buf_put>
    82bc:	eb af                	jmp    826d <fwp_write+0x14d>
    82be:	66 90                	xchg   %ax,%ax
    82c0:	ba 06 00 00 00       	mov    $0x6,%edx
    82c5:	48 8d 35 a4 3e 00 00 	lea    0x3ea4(%rip),%rsi        # c170 <_IO_stdin_used+0x170>
    82cc:	48 83 c5 10          	add    $0x10,%rbp
    82d0:	e8 9b bd ff ff       	call   4070 <buf_put>
    82d5:	48 89 ef             	mov    %rbp,%rdi
    82d8:	e8 73 b1 ff ff       	call   3450 <strlen@plt>
    82dd:	48 89 ee             	mov    %rbp,%rsi
    82e0:	48 89 df             	mov    %rbx,%rdi
    82e3:	48 89 c2             	mov    %rax,%rdx
    82e6:	e8 85 bd ff ff       	call   4070 <buf_put>
    82eb:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    82f0:	ba 01 00 00 00       	mov    $0x1,%edx
    82f5:	48 89 df             	mov    %rbx,%rdi
    82f8:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    82fd:	e8 6e bd ff ff       	call   4070 <buf_put>
    8302:	e9 af fe ff ff       	jmp    81b6 <fwp_write+0x96>
    8307:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    830e:	00 00 
    8310:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8317:	00 
    8318:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    831f:	00 00 
    8321:	0f 85 ce 02 00 00    	jne    85f5 <fwp_write+0x4d5>
    8327:	ba 0a 00 00 00       	mov    $0xa,%edx
    832c:	48 8d 35 29 3e 00 00 	lea    0x3e29(%rip),%rsi        # c15c <_IO_stdin_used+0x15c>
    8333:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    833a:	48 89 df             	mov    %rbx,%rdi
    833d:	5b                   	pop    %rbx
    833e:	5d                   	pop    %rbp
    833f:	41 5c                	pop    %r12
    8341:	41 5d                	pop    %r13
    8343:	41 5e                	pop    %r14
    8345:	41 5f                	pop    %r15
    8347:	e9 24 bd ff ff       	jmp    4070 <buf_put>
    834c:	0f 1f 40 00          	nopl   0x0(%rax)
    8350:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8355:	4d 85 ed             	test   %r13,%r13
    8358:	0f 84 02 0c 00 00    	je     8f60 <fwp_write+0xe40>
    835e:	48 8d 35 3f 3e 00 00 	lea    0x3e3f(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    8365:	4c 89 ef             	mov    %r13,%rdi
    8368:	e8 c3 b1 ff ff       	call   3530 <strcmp@plt>
    836d:	41 89 c1             	mov    %eax,%r9d
    8370:	85 c0                	test   %eax,%eax
    8372:	0f 84 6c 0c 00 00    	je     8fe4 <fwp_write+0xec4>
    8378:	4c 89 ef             	mov    %r13,%rdi
    837b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8380:	e8 cb b0 ff ff       	call   3450 <strlen@plt>
    8385:	4c 89 ee             	mov    %r13,%rsi
    8388:	48 89 df             	mov    %rbx,%rdi
    838b:	48 89 c2             	mov    %rax,%rdx
    838e:	e8 dd bc ff ff       	call   4070 <buf_put>
    8393:	ba 01 00 00 00       	mov    $0x1,%edx
    8398:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    839d:	48 89 df             	mov    %rbx,%rdi
    83a0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    83a5:	e8 c6 bc ff ff       	call   4070 <buf_put>
    83aa:	ba 01 00 00 00       	mov    $0x1,%edx
    83af:	4c 89 fe             	mov    %r15,%rsi
    83b2:	48 89 df             	mov    %rbx,%rdi
    83b5:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    83ba:	e8 b1 bc ff ff       	call   4070 <buf_put>
    83bf:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    83c4:	45 31 f6             	xor    %r14d,%r14d
    83c7:	85 d2                	test   %edx,%edx
    83c9:	0f 8e 81 0a 00 00    	jle    8e50 <fwp_write+0xd30>
    83cf:	45 31 ed             	xor    %r13d,%r13d
    83d2:	4d 85 ed             	test   %r13,%r13
    83d5:	0f 85 75 07 00 00    	jne    8b50 <fwp_write+0xa30>
    83db:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    83e2:	00 
    83e3:	45 85 f6             	test   %r14d,%r14d
    83e6:	0f 84 84 07 00 00    	je     8b70 <fwp_write+0xa50>
    83ec:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    83f1:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    83f6:	48 89 df             	mov    %rbx,%rdi
    83f9:	49 83 c5 01          	add    $0x1,%r13
    83fd:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8401:	31 c9                	xor    %ecx,%ecx
    8403:	e8 18 fd ff ff       	call   8120 <fwp_write>
    8408:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    840d:	7f c3                	jg     83d2 <fwp_write+0x2b2>
    840f:	45 85 f6             	test   %r14d,%r14d
    8412:	0f 84 38 0a 00 00    	je     8e50 <fwp_write+0xd30>
    8418:	b8 29 00 00 00       	mov    $0x29,%eax
    841d:	ba 01 00 00 00       	mov    $0x1,%edx
    8422:	4c 89 fe             	mov    %r15,%rsi
    8425:	48 89 df             	mov    %rbx,%rdi
    8428:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    842c:	e8 3f bc ff ff       	call   4070 <buf_put>
    8431:	e9 80 fd ff ff       	jmp    81b6 <fwp_write+0x96>
    8436:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    843d:	00 00 00 
    8440:	ba 01 00 00 00       	mov    $0x1,%edx
    8445:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    844a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    844f:	e8 1c bc ff ff       	call   4070 <buf_put>
    8454:	48 85 ed             	test   %rbp,%rbp
    8457:	0f 84 93 06 00 00    	je     8af0 <fwp_write+0x9d0>
    845d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8461:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8466:	31 c9                	xor    %ecx,%ecx
    8468:	48 89 df             	mov    %rbx,%rdi
    846b:	e8 b0 fc ff ff       	call   8120 <fwp_write>
    8470:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8474:	48 85 ed             	test   %rbp,%rbp
    8477:	0f 84 73 06 00 00    	je     8af0 <fwp_write+0x9d0>
    847d:	ba 02 00 00 00       	mov    $0x2,%edx
    8482:	48 8d 35 0e 3d 00 00 	lea    0x3d0e(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8489:	48 89 df             	mov    %rbx,%rdi
    848c:	e8 df bb ff ff       	call   4070 <buf_put>
    8491:	eb ca                	jmp    845d <fwp_write+0x33d>
    8493:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8498:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    849c:	85 f6                	test   %esi,%esi
    849e:	0f 84 fc 07 00 00    	je     8ca0 <fwp_write+0xb80>
    84a4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    84ab:	00 
    84ac:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    84b3:	00 00 
    84b5:	0f 85 3a 01 00 00    	jne    85f5 <fwp_write+0x4d5>
    84bb:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    84bf:	4c 89 ea             	mov    %r13,%rdx
    84c2:	e9 6c fe ff ff       	jmp    8333 <fwp_write+0x213>
    84c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    84ce:	00 00 
    84d0:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    84d5:	ba 01 00 00 00       	mov    $0x1,%edx
    84da:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    84df:	48 89 ee             	mov    %rbp,%rsi
    84e2:	e8 89 bb ff ff       	call   4070 <buf_put>
    84e7:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    84ec:	4c 89 e7             	mov    %r12,%rdi
    84ef:	e8 5c af ff ff       	call   3450 <strlen@plt>
    84f4:	4c 89 e6             	mov    %r12,%rsi
    84f7:	48 89 df             	mov    %rbx,%rdi
    84fa:	48 89 c2             	mov    %rax,%rdx
    84fd:	e8 6e bb ff ff       	call   4070 <buf_put>
    8502:	ba 01 00 00 00       	mov    $0x1,%edx
    8507:	48 89 ee             	mov    %rbp,%rsi
    850a:	48 89 df             	mov    %rbx,%rdi
    850d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8512:	e8 59 bb ff ff       	call   4070 <buf_put>
    8517:	e9 9a fc ff ff       	jmp    81b6 <fwp_write+0x96>
    851c:	0f 1f 40 00          	nopl   0x0(%rax)
    8520:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8525:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8529:	0f 8a 8e 0b 00 00    	jp     90bd <fwp_write+0xf9d>
    852f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8533:	66 0f 54 05 05 46 00 	andpd  0x4605(%rip),%xmm0        # cb40 <msg.4+0xc0>
    853a:	00 
    853b:	bd 01 00 00 00       	mov    $0x1,%ebp
    8540:	66 0f 2e 05 70 45 00 	ucomisd 0x4570(%rip),%xmm0        # cab8 <msg.4+0x38>
    8547:	00 
    8548:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    854f:	00 
    8550:	0f 87 b2 09 00 00    	ja     8f08 <fwp_write+0xde8>
    8556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    855d:	00 00 00 
    8560:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8564:	89 ee                	mov    %ebp,%esi
    8566:	4c 89 e7             	mov    %r12,%rdi
    8569:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    856e:	e8 4d bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8573:	31 f6                	xor    %esi,%esi
    8575:	4c 89 e7             	mov    %r12,%rdi
    8578:	e8 93 ae ff ff       	call   3410 <strtod@plt>
    857d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8582:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8586:	7a 06                	jp     858e <fwp_write+0x46e>
    8588:	0f 84 e9 01 00 00    	je     8777 <fwp_write+0x657>
    858e:	83 c5 01             	add    $0x1,%ebp
    8591:	83 fd 12             	cmp    $0x12,%ebp
    8594:	75 ca                	jne    8560 <fwp_write+0x440>
    8596:	be 11 00 00 00       	mov    $0x11,%esi
    859b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    859f:	4c 89 e7             	mov    %r12,%rdi
    85a2:	e8 19 bf ff ff       	call   44c0 <fwp_format_g.constprop.0>
    85a7:	e9 cb 01 00 00       	jmp    8777 <fwp_write+0x657>
    85ac:	0f 1f 40 00          	nopl   0x0(%rax)
    85b0:	48 83 fd 01          	cmp    $0x1,%rbp
    85b4:	0f 84 e6 08 00 00    	je     8ea0 <fwp_write+0xd80>
    85ba:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    85be:	b8 02 00 00 00       	mov    $0x2,%eax
    85c3:	ba 01 00 00 00       	mov    $0x1,%edx
    85c8:	48 0f 44 d0          	cmove  %rax,%rdx
    85cc:	48 8d 35 6d 3b 00 00 	lea    0x3b6d(%rip),%rsi        # c140 <_IO_stdin_used+0x140>
    85d3:	48 8d 05 6b 3b 00 00 	lea    0x3b6b(%rip),%rax        # c145 <_IO_stdin_used+0x145>
    85da:	48 0f 44 f0          	cmove  %rax,%rsi
    85de:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    85e5:	00 
    85e6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    85ed:	00 00 
    85ef:	0f 84 3e fd ff ff    	je     8333 <fwp_write+0x213>
    85f5:	e8 66 ae ff ff       	call   3460 <__stack_chk_fail@plt>
    85fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8600:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8605:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    860a:	e8 a1 b9 ff ff       	call   3fb0 <buf_grow>
    860f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8613:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8619:	4c 03 0b             	add    (%rbx),%r9
    861c:	66 45 89 11          	mov    %r10w,(%r9)
    8620:	45 85 e4             	test   %r12d,%r12d
    8623:	0f 8e 07 05 00 00    	jle    8b30 <fwp_write+0xa10>
    8629:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8630:	55 55 55 
    8633:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8638:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    863f:	aa aa aa 
    8642:	49 83 c1 01          	add    $0x1,%r9
    8646:	eb 45                	jmp    868d <fwp_write+0x56d>
    8648:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    864f:	00 
    8650:	be 01 00 00 00       	mov    $0x1,%esi
    8655:	b8 2d 00 00 00       	mov    $0x2d,%eax
    865a:	88 07                	mov    %al,(%rdi)
    865c:	48 89 e8             	mov    %rbp,%rax
    865f:	49 f7 e8             	imul   %r8
    8662:	48 89 e8             	mov    %rbp,%rax
    8665:	48 c1 f8 3f          	sar    $0x3f,%rax
    8669:	48 29 c2             	sub    %rax,%rdx
    866c:	48 85 c9             	test   %rcx,%rcx
    866f:	0f 95 c0             	setne  %al
    8672:	48 c1 ed 3f          	shr    $0x3f,%rbp
    8676:	48 83 ef 01          	sub    $0x1,%rdi
    867a:	48 21 c5             	and    %rax,%rbp
    867d:	48 29 ea             	sub    %rbp,%rdx
    8680:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    8684:	49 39 f9             	cmp    %rdi,%r9
    8687:	0f 84 a3 04 00 00    	je     8b30 <fwp_write+0xa10>
    868d:	48 89 e8             	mov    %rbp,%rax
    8690:	49 f7 e8             	imul   %r8
    8693:	48 89 e8             	mov    %rbp,%rax
    8696:	48 c1 f8 3f          	sar    $0x3f,%rax
    869a:	48 89 d1             	mov    %rdx,%rcx
    869d:	48 29 c1             	sub    %rax,%rcx
    86a0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    86a4:	48 89 e9             	mov    %rbp,%rcx
    86a7:	48 29 c1             	sub    %rax,%rcx
    86aa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    86ae:	49 f7 e2             	mul    %r10
    86b1:	b8 30 00 00 00       	mov    $0x30,%eax
    86b6:	48 89 d6             	mov    %rdx,%rsi
    86b9:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    86bd:	48 d1 ee             	shr    $1,%rsi
    86c0:	48 01 f2             	add    %rsi,%rdx
    86c3:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    86c7:	48 29 d6             	sub    %rdx,%rsi
    86ca:	74 8e                	je     865a <fwp_write+0x53a>
    86cc:	48 83 fe 01          	cmp    $0x1,%rsi
    86d0:	0f 85 7a ff ff ff    	jne    8650 <fwp_write+0x530>
    86d6:	31 f6                	xor    %esi,%esi
    86d8:	b8 2b 00 00 00       	mov    $0x2b,%eax
    86dd:	e9 78 ff ff ff       	jmp    865a <fwp_write+0x53a>
    86e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    86e8:	66 0f 6e cd          	movd   %ebp,%xmm1
    86ec:	0f 2e c9             	ucomiss %xmm1,%xmm1
    86ef:	0f 8a c8 09 00 00    	jp     90bd <fwp_write+0xf9d>
    86f5:	0f 28 c1             	movaps %xmm1,%xmm0
    86f8:	0f 54 05 31 44 00 00 	andps  0x4431(%rip),%xmm0        # cb30 <msg.4+0xb0>
    86ff:	0f 2e 05 fe 38 00 00 	ucomiss 0x38fe(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    8706:	0f 87 24 08 00 00    	ja     8f30 <fwp_write+0xe10>
    870c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    8710:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8716:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    871d:	00 
    871e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    8722:	66 49 0f 7e d7       	movq   %xmm2,%r15
    8727:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    872e:	00 00 
    8730:	44 89 ee             	mov    %r13d,%esi
    8733:	66 49 0f 6e c7       	movq   %r15,%xmm0
    8738:	4c 89 e7             	mov    %r12,%rdi
    873b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    8740:	e8 7b bd ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8745:	31 f6                	xor    %esi,%esi
    8747:	4c 89 e7             	mov    %r12,%rdi
    874a:	e8 61 ad ff ff       	call   34b0 <strtof@plt>
    874f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    8754:	0f 2e c8             	ucomiss %xmm0,%xmm1
    8757:	7a 02                	jp     875b <fwp_write+0x63b>
    8759:	74 1c                	je     8777 <fwp_write+0x657>
    875b:	41 83 c5 01          	add    $0x1,%r13d
    875f:	41 83 fd 0a          	cmp    $0xa,%r13d
    8763:	75 cb                	jne    8730 <fwp_write+0x610>
    8765:	be 09 00 00 00       	mov    $0x9,%esi
    876a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    876f:	4c 89 e7             	mov    %r12,%rdi
    8772:	e8 49 bd ff ff       	call   44c0 <fwp_format_g.constprop.0>
    8777:	4c 89 e7             	mov    %r12,%rdi
    877a:	e8 b1 b9 ff ff       	call   4130 <fwp_finish_float>
    877f:	e9 1c fa ff ff       	jmp    81a0 <fwp_write+0x80>
    8784:	0f 1f 40 00          	nopl   0x0(%rax)
    8788:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    878c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    8790:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    8797:	00 
    8798:	48 89 ef             	mov    %rbp,%rdi
    879b:	e8 a0 b2 ff ff       	call   3a40 <fwp_fmt_u128>
    87a0:	48 89 ef             	mov    %rbp,%rdi
    87a3:	e8 a8 ac ff ff       	call   3450 <strlen@plt>
    87a8:	48 89 ee             	mov    %rbp,%rsi
    87ab:	48 89 df             	mov    %rbx,%rdi
    87ae:	48 89 c2             	mov    %rax,%rdx
    87b1:	e8 ba b8 ff ff       	call   4070 <buf_put>
    87b6:	e9 fb f9 ff ff       	jmp    81b6 <fwp_write+0x96>
    87bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    87c0:	ba 06 00 00 00       	mov    $0x6,%edx
    87c5:	48 8d 35 ce 39 00 00 	lea    0x39ce(%rip),%rsi        # c19a <_IO_stdin_used+0x19a>
    87cc:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    87d2:	e8 99 b8 ff ff       	call   4070 <buf_put>
    87d7:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    87de:	ff ff 7f 
    87e1:	48 23 55 00          	and    0x0(%rbp),%rdx
    87e5:	0f 84 86 02 00 00    	je     8a71 <fwp_write+0x951>
    87eb:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    87f0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    87f4:	48 85 d2             	test   %rdx,%rdx
    87f7:	0f 84 ae 00 00 00    	je     88ab <fwp_write+0x78b>
    87fd:	8b 0a                	mov    (%rdx),%ecx
    87ff:	83 f9 1c             	cmp    $0x1c,%ecx
    8802:	0f 84 58 06 00 00    	je     8e60 <fwp_write+0xd40>
    8808:	83 f9 1b             	cmp    $0x1b,%ecx
    880b:	0f 87 9a 00 00 00    	ja     88ab <fwp_write+0x78b>
    8811:	be 01 00 00 00       	mov    $0x1,%esi
    8816:	48 d3 e6             	shl    %cl,%rsi
    8819:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    881f:	0f 85 4b 04 00 00    	jne    8c70 <fwp_write+0xb50>
    8825:	f7 c6 84 04 00 00    	test   $0x484,%esi
    882b:	0f 85 0f 04 00 00    	jne    8c40 <fwp_write+0xb20>
    8831:	83 e6 21             	and    $0x21,%esi
    8834:	74 75                	je     88ab <fwp_write+0x78b>
    8836:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    883b:	48 85 ff             	test   %rdi,%rdi
    883e:	79 07                	jns    8847 <fwp_write+0x727>
    8840:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    8844:	4c 01 ee             	add    %r13,%rsi
    8847:	48 0f be 3e          	movsbq (%rsi),%rdi
    884b:	85 c9                	test   %ecx,%ecx
    884d:	40 0f b6 f7          	movzbl %dil,%esi
    8851:	48 0f 44 f7          	cmove  %rdi,%rsi
    8855:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    885c:	00 00 00 00 
    8860:	31 c9                	xor    %ecx,%ecx
    8862:	48 89 df             	mov    %rbx,%rdi
    8865:	49 83 c5 01          	add    $0x1,%r13
    8869:	e8 b2 f8 ff ff       	call   8120 <fwp_write>
    886e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    8875:	ff ff 7f 
    8878:	48 23 55 00          	and    0x0(%rbp),%rdx
    887c:	49 39 d5             	cmp    %rdx,%r13
    887f:	0f 83 ec 01 00 00    	jae    8a71 <fwp_write+0x951>
    8885:	ba 02 00 00 00       	mov    $0x2,%edx
    888a:	48 89 df             	mov    %rbx,%rdi
    888d:	48 8d 35 03 39 00 00 	lea    0x3903(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8894:	e8 d7 b7 ff ff       	call   4070 <buf_put>
    8899:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    889e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    88a2:	48 85 d2             	test   %rdx,%rdx
    88a5:	0f 85 52 ff ff ff    	jne    87fd <fwp_write+0x6dd>
    88ab:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    88b0:	48 85 ff             	test   %rdi,%rdi
    88b3:	0f 88 cf 05 00 00    	js     8e88 <fwp_write+0xd68>
    88b9:	48 8b 31             	mov    (%rcx),%rsi
    88bc:	eb a2                	jmp    8860 <fwp_write+0x740>
    88be:	66 90                	xchg   %ax,%ax
    88c0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    88c7:	00 
    88c8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88cf:	00 00 
    88d1:	0f 85 1e fd ff ff    	jne    85f5 <fwp_write+0x4d5>
    88d7:	ba 08 00 00 00       	mov    $0x8,%edx
    88dc:	48 8d 35 84 38 00 00 	lea    0x3884(%rip),%rsi        # c167 <_IO_stdin_used+0x167>
    88e3:	e9 4b fa ff ff       	jmp    8333 <fwp_write+0x213>
    88e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    88ef:	00 
    88f0:	89 e8                	mov    %ebp,%eax
    88f2:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    88f9:	76 03                	jbe    88fe <fwp_write+0x7de>
    88fb:	8b 45 00             	mov    0x0(%rbp),%eax
    88fe:	41 89 c6             	mov    %eax,%r14d
    8901:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8906:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    890b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    890f:	4c 89 ef             	mov    %r13,%rdi
    8912:	e8 39 ab ff ff       	call   3450 <strlen@plt>
    8917:	4c 89 ee             	mov    %r13,%rsi
    891a:	48 89 df             	mov    %rbx,%rdi
    891d:	48 89 c2             	mov    %rax,%rdx
    8920:	e8 4b b7 ff ff       	call   4070 <buf_put>
    8925:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    892a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    892e:	85 f6                	test   %esi,%esi
    8930:	0f 8e 80 f8 ff ff    	jle    81b6 <fwp_write+0x96>
    8936:	45 31 ed             	xor    %r13d,%r13d
    8939:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    893e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    8943:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8948:	ba 01 00 00 00       	mov    $0x1,%edx
    894d:	4c 89 fe             	mov    %r15,%rsi
    8950:	48 89 04 24          	mov    %rax,(%rsp)
    8954:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    8959:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    895d:	48 89 df             	mov    %rbx,%rdi
    8960:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    8964:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8969:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    896e:	e8 fd b6 ff ff       	call   4070 <buf_put>
    8973:	41 8b 06             	mov    (%r14),%eax
    8976:	83 f8 0e             	cmp    $0xe,%eax
    8979:	0f 84 71 02 00 00    	je     8bf0 <fwp_write+0xad0>
    897f:	83 f8 10             	cmp    $0x10,%eax
    8982:	0f 84 38 02 00 00    	je     8bc0 <fwp_write+0xaa0>
    8988:	83 f8 0a             	cmp    $0xa,%eax
    898b:	0f 84 7f 04 00 00    	je     8e10 <fwp_write+0xcf0>
    8991:	0f 8f f9 00 00 00    	jg     8a90 <fwp_write+0x970>
    8997:	83 f8 03             	cmp    $0x3,%eax
    899a:	0f 8f 50 04 00 00    	jg     8df0 <fwp_write+0xcd0>
    89a0:	85 c0                	test   %eax,%eax
    89a2:	78 10                	js     89b4 <fwp_write+0x894>
    89a4:	48 8b 04 24          	mov    (%rsp),%rax
    89a8:	48 c1 e8 3f          	shr    $0x3f,%rax
    89ac:	85 c0                	test   %eax,%eax
    89ae:	0f 85 f9 00 00 00    	jne    8aad <fwp_write+0x98d>
    89b4:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    89b9:	48 8b 34 24          	mov    (%rsp),%rsi
    89bd:	31 c9                	xor    %ecx,%ecx
    89bf:	48 89 df             	mov    %rbx,%rdi
    89c2:	e8 59 f7 ff ff       	call   8120 <fwp_write>
    89c7:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    89cc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    89d1:	49 83 c5 01          	add    $0x1,%r13
    89d5:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    89d9:	0f 8f 5f ff ff ff    	jg     893e <fwp_write+0x81e>
    89df:	e9 d2 f7 ff ff       	jmp    81b6 <fwp_write+0x96>
    89e4:	0f 1f 40 00          	nopl   0x0(%rax)
    89e8:	ba 06 00 00 00       	mov    $0x6,%edx
    89ed:	48 8d 35 99 37 00 00 	lea    0x3799(%rip),%rsi        # c18d <_IO_stdin_used+0x18d>
    89f4:	45 31 ed             	xor    %r13d,%r13d
    89f7:	e8 74 b6 ff ff       	call   4070 <buf_put>
    89fc:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8a01:	75 19                	jne    8a1c <fwp_write+0x8fc>
    8a03:	eb 6c                	jmp    8a71 <fwp_write+0x951>
    8a05:	0f 1f 00             	nopl   (%rax)
    8a08:	ba 02 00 00 00       	mov    $0x2,%edx
    8a0d:	48 8d 35 83 37 00 00 	lea    0x3783(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8a14:	48 89 df             	mov    %rbx,%rdi
    8a17:	e8 54 b6 ff ff       	call   4070 <buf_put>
    8a1c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    8a22:	b9 00 02 00 00       	mov    $0x200,%ecx
    8a27:	31 c0                	xor    %eax,%eax
    8a29:	49 83 c5 01          	add    $0x1,%r13
    8a2d:	4c 8d 05 60 37 00 00 	lea    0x3760(%rip),%r8        # c194 <_IO_stdin_used+0x194>
    8a34:	ba 02 00 00 00       	mov    $0x2,%edx
    8a39:	be 00 02 00 00       	mov    $0x200,%esi
    8a3e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8a45:	00 
    8a46:	e8 65 a9 ff ff       	call   33b0 <__snprintf_chk@plt>
    8a4b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8a52:	00 
    8a53:	e8 f8 a9 ff ff       	call   3450 <strlen@plt>
    8a58:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8a5f:	00 
    8a60:	48 89 df             	mov    %rbx,%rdi
    8a63:	48 89 c2             	mov    %rax,%rdx
    8a66:	e8 05 b6 ff ff       	call   4070 <buf_put>
    8a6b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8a6f:	72 97                	jb     8a08 <fwp_write+0x8e8>
    8a71:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8a76:	ba 01 00 00 00       	mov    $0x1,%edx
    8a7b:	48 89 df             	mov    %rbx,%rdi
    8a7e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8a83:	e8 e8 b5 ff ff       	call   4070 <buf_put>
    8a88:	e9 29 f7 ff ff       	jmp    81b6 <fwp_write+0x96>
    8a8d:	0f 1f 00             	nopl   (%rax)
    8a90:	83 f8 0b             	cmp    $0xb,%eax
    8a93:	0f 85 1b ff ff ff    	jne    89b4 <fwp_write+0x894>
    8a99:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    8a9e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    8aa2:	83 e0 01             	and    $0x1,%eax
    8aa5:	85 c0                	test   %eax,%eax
    8aa7:	0f 84 07 ff ff ff    	je     89b4 <fwp_write+0x894>
    8aad:	4c 89 fe             	mov    %r15,%rsi
    8ab0:	48 89 df             	mov    %rbx,%rdi
    8ab3:	ba 01 00 00 00       	mov    $0x1,%edx
    8ab8:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8abd:	e8 ae b5 ff ff       	call   4070 <buf_put>
    8ac2:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8ac7:	48 8b 34 24          	mov    (%rsp),%rsi
    8acb:	31 c9                	xor    %ecx,%ecx
    8acd:	48 89 df             	mov    %rbx,%rdi
    8ad0:	e8 4b f6 ff ff       	call   8120 <fwp_write>
    8ad5:	ba 01 00 00 00       	mov    $0x1,%edx
    8ada:	4c 89 fe             	mov    %r15,%rsi
    8add:	48 89 df             	mov    %rbx,%rdi
    8ae0:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    8ae5:	e8 86 b5 ff ff       	call   4070 <buf_put>
    8aea:	e9 d8 fe ff ff       	jmp    89c7 <fwp_write+0x8a7>
    8aef:	90                   	nop
    8af0:	ba 01 00 00 00       	mov    $0x1,%edx
    8af5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8afa:	48 89 df             	mov    %rbx,%rdi
    8afd:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    8b02:	e8 69 b5 ff ff       	call   4070 <buf_put>
    8b07:	e9 aa f6 ff ff       	jmp    81b6 <fwp_write+0x96>
    8b0c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b10:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8b15:	ba 01 00 00 00       	mov    $0x1,%edx
    8b1a:	48 89 df             	mov    %rbx,%rdi
    8b1d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    8b22:	e8 49 b5 ff ff       	call   4070 <buf_put>
    8b27:	e9 8a f6 ff ff       	jmp    81b6 <fwp_write+0x96>
    8b2c:	0f 1f 40 00          	nopl   0x0(%rax)
    8b30:	48 8b 43 08          	mov    0x8(%rbx),%rax
    8b34:	48 8b 13             	mov    (%rbx),%rdx
    8b37:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    8b3c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    8b40:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    8b44:	e9 6d f6 ff ff       	jmp    81b6 <fwp_write+0x96>
    8b49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b50:	ba 02 00 00 00       	mov    $0x2,%edx
    8b55:	48 8d 35 3b 36 00 00 	lea    0x363b(%rip),%rsi        # c197 <_IO_stdin_used+0x197>
    8b5c:	48 89 df             	mov    %rbx,%rdi
    8b5f:	e8 0c b5 ff ff       	call   4070 <buf_put>
    8b64:	e9 72 f8 ff ff       	jmp    83db <fwp_write+0x2bb>
    8b69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8b70:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    8b75:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8b7a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    8b7e:	48 89 f7             	mov    %rsi,%rdi
    8b81:	48 89 34 24          	mov    %rsi,(%rsp)
    8b85:	e8 c6 a8 ff ff       	call   3450 <strlen@plt>
    8b8a:	48 8b 34 24          	mov    (%rsp),%rsi
    8b8e:	48 89 df             	mov    %rbx,%rdi
    8b91:	48 89 c2             	mov    %rax,%rdx
    8b94:	e8 d7 b4 ff ff       	call   4070 <buf_put>
    8b99:	ba 03 00 00 00       	mov    $0x3,%edx
    8b9e:	48 8d 35 15 36 00 00 	lea    0x3615(%rip),%rsi        # c1ba <_IO_stdin_used+0x1ba>
    8ba5:	48 89 df             	mov    %rbx,%rdi
    8ba8:	e8 c3 b4 ff ff       	call   4070 <buf_put>
    8bad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8bb2:	e9 35 f8 ff ff       	jmp    83ec <fwp_write+0x2cc>
    8bb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8bbe:	00 00 
    8bc0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8bc5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    8bc9:	48 85 ff             	test   %rdi,%rdi
    8bcc:	0f 84 e2 fd ff ff    	je     89b4 <fwp_write+0x894>
    8bd2:	48 8d 35 cb 35 00 00 	lea    0x35cb(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    8bd9:	e8 52 a9 ff ff       	call   3530 <strcmp@plt>
    8bde:	85 c0                	test   %eax,%eax
    8be0:	0f 95 c0             	setne  %al
    8be3:	0f b6 c0             	movzbl %al,%eax
    8be6:	e9 c1 fd ff ff       	jmp    89ac <fwp_write+0x88c>
    8beb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8bf0:	31 c0                	xor    %eax,%eax
    8bf2:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    8bf9:	00 
    8bfa:	0f 97 c0             	seta   %al
    8bfd:	e9 aa fd ff ff       	jmp    89ac <fwp_write+0x88c>
    8c02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8c08:	48 89 df             	mov    %rbx,%rdi
    8c0b:	ba 02 00 00 00       	mov    $0x2,%edx
    8c10:	48 8d 35 8a 35 00 00 	lea    0x358a(%rip),%rsi        # c1a1 <_IO_stdin_used+0x1a1>
    8c17:	e8 54 b4 ff ff       	call   4070 <buf_put>
    8c1c:	4c 89 e8             	mov    %r13,%rax
    8c1f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    8c24:	31 c9                	xor    %ecx,%ecx
    8c26:	48 c1 e0 04          	shl    $0x4,%rax
    8c2a:	48 89 df             	mov    %rbx,%rdi
    8c2d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    8c32:	e8 e9 f4 ff ff       	call   8120 <fwp_write>
    8c37:	e9 5e f6 ff ff       	jmp    829a <fwp_write+0x17a>
    8c3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8c40:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    8c45:	48 85 ff             	test   %rdi,%rdi
    8c48:	79 0c                	jns    8c56 <fwp_write+0xb36>
    8c4a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    8c51:	00 
    8c52:	48 03 75 10          	add    0x10(%rbp),%rsi
    8c56:	48 63 3e             	movslq (%rsi),%rdi
    8c59:	83 f9 02             	cmp    $0x2,%ecx
    8c5c:	89 fe                	mov    %edi,%esi
    8c5e:	48 0f 44 f7          	cmove  %rdi,%rsi
    8c62:	e9 f9 fb ff ff       	jmp    8860 <fwp_write+0x740>
    8c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8c6e:	00 00 
    8c70:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    8c75:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    8c7a:	48 85 ff             	test   %rdi,%rdi
    8c7d:	0f 88 0f 03 00 00    	js     8f92 <fwp_write+0xe72>
    8c83:	49 0f bf 38          	movswq (%r8),%rdi
    8c87:	83 f9 01             	cmp    $0x1,%ecx
    8c8a:	0f b7 f7             	movzwl %di,%esi
    8c8d:	48 0f 44 f7          	cmove  %rdi,%rsi
    8c91:	e9 ca fb ff ff       	jmp    8860 <fwp_write+0x740>
    8c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c9d:	00 00 00 
    8ca0:	ba 01 00 00 00       	mov    $0x1,%edx
    8ca5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8caa:	48 83 c5 08          	add    $0x8,%rbp
    8cae:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8cb3:	e8 b8 b3 ff ff       	call   4070 <buf_put>
    8cb8:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8cbd:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    8cc2:	4d 85 ed             	test   %r13,%r13
    8cc5:	75 46                	jne    8d0d <fwp_write+0xbed>
    8cc7:	e9 04 01 00 00       	jmp    8dd0 <fwp_write+0xcb0>
    8ccc:	0f 1f 40 00          	nopl   0x0(%rax)
    8cd0:	41 80 f9 09          	cmp    $0x9,%r9b
    8cd4:	0f 84 d6 00 00 00    	je     8db0 <fwp_write+0xc90>
    8cda:	41 80 f9 0a          	cmp    $0xa,%r9b
    8cde:	0f 85 9c 00 00 00    	jne    8d80 <fwp_write+0xc60>
    8ce4:	ba 02 00 00 00       	mov    $0x2,%edx
    8ce9:	48 8d 35 8d 34 00 00 	lea    0x348d(%rip),%rsi        # c17d <_IO_stdin_used+0x17d>
    8cf0:	48 89 df             	mov    %rbx,%rdi
    8cf3:	e8 78 b3 ff ff       	call   4070 <buf_put>
    8cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8cff:	00 
    8d00:	48 83 c5 01          	add    $0x1,%rbp
    8d04:	49 39 ec             	cmp    %rbp,%r12
    8d07:	0f 84 c3 00 00 00    	je     8dd0 <fwp_write+0xcb0>
    8d0d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    8d12:	41 80 f9 0d          	cmp    $0xd,%r9b
    8d16:	74 28                	je     8d40 <fwp_write+0xc20>
    8d18:	7e b6                	jle    8cd0 <fwp_write+0xbb0>
    8d1a:	41 80 f9 22          	cmp    $0x22,%r9b
    8d1e:	74 40                	je     8d60 <fwp_write+0xc40>
    8d20:	41 80 f9 5c          	cmp    $0x5c,%r9b
    8d24:	75 5a                	jne    8d80 <fwp_write+0xc60>
    8d26:	ba 02 00 00 00       	mov    $0x2,%edx
    8d2b:	48 8d 35 48 34 00 00 	lea    0x3448(%rip),%rsi        # c17a <_IO_stdin_used+0x17a>
    8d32:	48 89 df             	mov    %rbx,%rdi
    8d35:	e8 36 b3 ff ff       	call   4070 <buf_put>
    8d3a:	eb c4                	jmp    8d00 <fwp_write+0xbe0>
    8d3c:	0f 1f 40 00          	nopl   0x0(%rax)
    8d40:	ba 02 00 00 00       	mov    $0x2,%edx
    8d45:	48 8d 35 37 34 00 00 	lea    0x3437(%rip),%rsi        # c183 <_IO_stdin_used+0x183>
    8d4c:	48 89 df             	mov    %rbx,%rdi
    8d4f:	e8 1c b3 ff ff       	call   4070 <buf_put>
    8d54:	eb aa                	jmp    8d00 <fwp_write+0xbe0>
    8d56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d5d:	00 00 00 
    8d60:	ba 02 00 00 00       	mov    $0x2,%edx
    8d65:	48 8d 35 0b 34 00 00 	lea    0x340b(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    8d6c:	48 89 df             	mov    %rbx,%rdi
    8d6f:	e8 fc b2 ff ff       	call   4070 <buf_put>
    8d74:	eb 8a                	jmp    8d00 <fwp_write+0xbe0>
    8d76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8d7d:	00 00 00 
    8d80:	41 80 f9 1f          	cmp    $0x1f,%r9b
    8d84:	0f 86 2e 01 00 00    	jbe    8eb8 <fwp_write+0xd98>
    8d8a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    8d8e:	0f 84 24 01 00 00    	je     8eb8 <fwp_write+0xd98>
    8d94:	ba 01 00 00 00       	mov    $0x1,%edx
    8d99:	4c 89 fe             	mov    %r15,%rsi
    8d9c:	48 89 df             	mov    %rbx,%rdi
    8d9f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    8da4:	e8 c7 b2 ff ff       	call   4070 <buf_put>
    8da9:	e9 52 ff ff ff       	jmp    8d00 <fwp_write+0xbe0>
    8dae:	66 90                	xchg   %ax,%ax
    8db0:	ba 02 00 00 00       	mov    $0x2,%edx
    8db5:	48 8d 35 c4 33 00 00 	lea    0x33c4(%rip),%rsi        # c180 <_IO_stdin_used+0x180>
    8dbc:	48 89 df             	mov    %rbx,%rdi
    8dbf:	e8 ac b2 ff ff       	call   4070 <buf_put>
    8dc4:	e9 37 ff ff ff       	jmp    8d00 <fwp_write+0xbe0>
    8dc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8dd0:	ba 01 00 00 00       	mov    $0x1,%edx
    8dd5:	4c 89 fe             	mov    %r15,%rsi
    8dd8:	48 89 df             	mov    %rbx,%rdi
    8ddb:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    8de0:	e8 8b b2 ff ff       	call   4070 <buf_put>
    8de5:	e9 cc f3 ff ff       	jmp    81b6 <fwp_write+0x96>
    8dea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8df0:	83 f8 04             	cmp    $0x4,%eax
    8df3:	0f 85 bb fb ff ff    	jne    89b4 <fwp_write+0x894>
    8df9:	48 8b 04 24          	mov    (%rsp),%rax
    8dfd:	48 8b 40 08          	mov    0x8(%rax),%rax
    8e01:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8e06:	48 c1 e8 3f          	shr    $0x3f,%rax
    8e0a:	e9 96 fc ff ff       	jmp    8aa5 <fwp_write+0x985>
    8e0f:	90                   	nop
    8e10:	8b 0c 24             	mov    (%rsp),%ecx
    8e13:	31 c0                	xor    %eax,%eax
    8e15:	85 c9                	test   %ecx,%ecx
    8e17:	0f 98 c0             	sets   %al
    8e1a:	e9 86 fc ff ff       	jmp    8aa5 <fwp_write+0x985>
    8e1f:	90                   	nop
    8e20:	48 f7 d8             	neg    %rax
    8e23:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    8e2a:	00 
    8e2b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    8e32:	2d 
    8e33:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8e3a:	00 
    8e3b:	48 83 d2 00          	adc    $0x0,%rdx
    8e3f:	48 89 c6             	mov    %rax,%rsi
    8e42:	48 f7 da             	neg    %rdx
    8e45:	e8 f6 ab ff ff       	call   3a40 <fwp_fmt_u128>
    8e4a:	e9 51 f3 ff ff       	jmp    81a0 <fwp_write+0x80>
    8e4f:	90                   	nop
    8e50:	b8 7d 00 00 00       	mov    $0x7d,%eax
    8e55:	e9 c3 f5 ff ff       	jmp    841d <fwp_write+0x2fd>
    8e5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8e60:	4c 89 e9             	mov    %r13,%rcx
    8e63:	48 c1 e1 04          	shl    $0x4,%rcx
    8e67:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    8e6c:	48 85 ff             	test   %rdi,%rdi
    8e6f:	0f 89 eb f9 ff ff    	jns    8860 <fwp_write+0x740>
    8e75:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8e79:	48 89 ce             	mov    %rcx,%rsi
    8e7c:	e9 df f9 ff ff       	jmp    8860 <fwp_write+0x740>
    8e81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8e88:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8e8f:	00 
    8e90:	48 03 4d 10          	add    0x10(%rbp),%rcx
    8e94:	e9 20 fa ff ff       	jmp    88b9 <fwp_write+0x799>
    8e99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8ea0:	ba 02 00 00 00       	mov    $0x2,%edx
    8ea5:	48 8d 35 96 32 00 00 	lea    0x3296(%rip),%rsi        # c142 <_IO_stdin_used+0x142>
    8eac:	e9 2d f7 ff ff       	jmp    85de <fwp_write+0x4be>
    8eb1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8eb8:	4c 8d 05 c7 32 00 00 	lea    0x32c7(%rip),%r8        # c186 <_IO_stdin_used+0x186>
    8ebf:	b9 10 00 00 00       	mov    $0x10,%ecx
    8ec4:	31 c0                	xor    %eax,%eax
    8ec6:	ba 02 00 00 00       	mov    $0x2,%edx
    8ecb:	be 10 00 00 00       	mov    $0x10,%esi
    8ed0:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ed7:	00 
    8ed8:	e8 d3 a4 ff ff       	call   33b0 <__snprintf_chk@plt>
    8edd:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ee4:	00 
    8ee5:	e8 66 a5 ff ff       	call   3450 <strlen@plt>
    8eea:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8ef1:	00 
    8ef2:	48 89 df             	mov    %rbx,%rdi
    8ef5:	48 89 c2             	mov    %rax,%rdx
    8ef8:	e8 73 b1 ff ff       	call   4070 <buf_put>
    8efd:	e9 fe fd ff ff       	jmp    8d00 <fwp_write+0xbe0>
    8f02:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8f08:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f0c:	48 8d 35 29 32 00 00 	lea    0x3229(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    8f13:	48 8d 05 21 32 00 00 	lea    0x3221(%rip),%rax        # c13b <_IO_stdin_used+0x13b>
    8f1a:	4c 89 e7             	mov    %r12,%rdi
    8f1d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    8f21:	48 0f 46 f0          	cmovbe %rax,%rsi
    8f25:	e8 c6 a4 ff ff       	call   33f0 <strcpy@plt>
    8f2a:	e9 71 f2 ff ff       	jmp    81a0 <fwp_write+0x80>
    8f2f:	90                   	nop
    8f30:	66 0f ef c0          	pxor   %xmm0,%xmm0
    8f34:	48 8d 35 01 32 00 00 	lea    0x3201(%rip),%rsi        # c13c <_IO_stdin_used+0x13c>
    8f3b:	48 8d 05 f9 31 00 00 	lea    0x31f9(%rip),%rax        # c13b <_IO_stdin_used+0x13b>
    8f42:	0f 2f c8             	comiss %xmm0,%xmm1
    8f45:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8f4c:	00 
    8f4d:	4c 89 e7             	mov    %r12,%rdi
    8f50:	48 0f 46 f0          	cmovbe %rax,%rsi
    8f54:	e8 97 a4 ff ff       	call   33f0 <strcpy@plt>
    8f59:	e9 42 f2 ff ff       	jmp    81a0 <fwp_write+0x80>
    8f5e:	66 90                	xchg   %ax,%ax
    8f60:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    8f65:	45 85 c0             	test   %r8d,%r8d
    8f68:	75 34                	jne    8f9e <fwp_write+0xe7e>
    8f6a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f71:	00 
    8f72:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f79:	00 00 
    8f7b:	0f 85 74 f6 ff ff    	jne    85f5 <fwp_write+0x4d5>
    8f81:	ba 02 00 00 00       	mov    $0x2,%edx
    8f86:	48 8d 35 2a 32 00 00 	lea    0x322a(%rip),%rsi        # c1b7 <_IO_stdin_used+0x1b7>
    8f8d:	e9 a1 f3 ff ff       	jmp    8333 <fwp_write+0x213>
    8f92:	48 03 75 10          	add    0x10(%rbp),%rsi
    8f96:	49 89 f0             	mov    %rsi,%r8
    8f99:	e9 e5 fc ff ff       	jmp    8c83 <fwp_write+0xb63>
    8f9e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    8fa3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fa8:	85 ff                	test   %edi,%edi
    8faa:	0f 84 fa f3 ff ff    	je     83aa <fwp_write+0x28a>
    8fb0:	ba 01 00 00 00       	mov    $0x1,%edx
    8fb5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8fba:	48 89 df             	mov    %rbx,%rdi
    8fbd:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    8fc2:	e8 a9 b0 ff ff       	call   4070 <buf_put>
    8fc7:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    8fcc:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8fd1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    8fd7:	85 c0                	test   %eax,%eax
    8fd9:	0f 8f f0 f3 ff ff    	jg     83cf <fwp_write+0x2af>
    8fdf:	e9 34 f4 ff ff       	jmp    8418 <fwp_write+0x2f8>
    8fe4:	48 8b 45 08          	mov    0x8(%rbp),%rax
    8fe8:	49 89 c5             	mov    %rax,%r13
    8feb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8ff0:	49 89 c4             	mov    %rax,%r12
    8ff3:	49 c1 fd 3f          	sar    $0x3f,%r13
    8ff7:	4c 09 e8             	or     %r13,%rax
    8ffa:	0f 84 a7 00 00 00    	je     90a7 <fwp_write+0xf87>
    9000:	48 8d 2d b9 52 00 00 	lea    0x52b9(%rip),%rbp        # e2c0 <units.0>
    9007:	4d 89 e7             	mov    %r12,%r15
    900a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    900e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    9013:	4c 89 ff             	mov    %r15,%rdi
    9016:	4c 89 ee             	mov    %r13,%rsi
    9019:	44 89 0c 24          	mov    %r9d,(%rsp)
    901d:	48 99                	cqto
    901f:	48 89 d1             	mov    %rdx,%rcx
    9022:	48 89 c2             	mov    %rax,%rdx
    9025:	e8 26 23 00 00       	call   b350 <__divmodti4>
    902a:	44 8b 0c 24          	mov    (%rsp),%r9d
    902e:	48 89 c1             	mov    %rax,%rcx
    9031:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    9036:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    903b:	0f 84 94 00 00 00    	je     90d5 <fwp_write+0xfb5>
    9041:	41 83 c1 01          	add    $0x1,%r9d
    9045:	48 83 c5 10          	add    $0x10,%rbp
    9049:	41 83 f9 05          	cmp    $0x5,%r9d
    904d:	75 bb                	jne    900a <fwp_write+0xeea>
    904f:	4d 85 ed             	test   %r13,%r13
    9052:	79 53                	jns    90a7 <fwp_write+0xf87>
    9054:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9059:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    905e:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9063:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9068:	48 99                	cqto
    906a:	48 f7 d8             	neg    %rax
    906d:	48 83 d2 00          	adc    $0x0,%rdx
    9071:	48 89 c6             	mov    %rax,%rsi
    9074:	48 f7 da             	neg    %rdx
    9077:	e8 c4 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    907c:	49 89 e8             	mov    %rbp,%r8
    907f:	ba 00 02 00 00       	mov    $0x200,%edx
    9084:	be 02 00 00 00       	mov    $0x2,%esi
    9089:	31 c0                	xor    %eax,%eax
    908b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9092:	00 
    9093:	48 8d 0d 18 31 00 00 	lea    0x3118(%rip),%rcx        # c1b2 <_IO_stdin_used+0x1b2>
    909a:	4c 89 e7             	mov    %r12,%rdi
    909d:	e8 3e a6 ff ff       	call   36e0 <__sprintf_chk@plt>
    90a2:	e9 f9 f0 ff ff       	jmp    81a0 <fwp_write+0x80>
    90a7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    90b1:	31 d2                	xor    %edx,%edx
    90b3:	48 89 ef             	mov    %rbp,%rdi
    90b6:	e8 85 a9 ff ff       	call   3a40 <fwp_fmt_u128>
    90bb:	eb bf                	jmp    907c <fwp_write+0xf5c>
    90bd:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    90c4:	4e 61 4e 00 
    90c8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    90cf:	00 
    90d0:	e9 cb f0 ff ff       	jmp    81a0 <fwp_write+0x80>
    90d5:	44 89 0c 24          	mov    %r9d,(%rsp)
    90d9:	48 89 c8             	mov    %rcx,%rax
    90dc:	48 85 d2             	test   %rdx,%rdx
    90df:	78 51                	js     9132 <fwp_write+0x1012>
    90e1:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    90e6:	48 89 c6             	mov    %rax,%rsi
    90e9:	48 89 ef             	mov    %rbp,%rdi
    90ec:	e8 4f a9 ff ff       	call   3a40 <fwp_fmt_u128>
    90f1:	44 8b 0c 24          	mov    (%rsp),%r9d
    90f5:	49 63 c1             	movslq %r9d,%rax
    90f8:	49 89 e8             	mov    %rbp,%r8
    90fb:	ba 00 02 00 00       	mov    $0x200,%edx
    9100:	be 02 00 00 00       	mov    $0x2,%esi
    9105:	48 c1 e0 04          	shl    $0x4,%rax
    9109:	48 8d 3d b0 51 00 00 	lea    0x51b0(%rip),%rdi        # e2c0 <units.0>
    9110:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9117:	00 
    9118:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    911c:	48 8d 0d 8a 30 00 00 	lea    0x308a(%rip),%rcx        # c1ad <_IO_stdin_used+0x1ad>
    9123:	4c 89 e7             	mov    %r12,%rdi
    9126:	31 c0                	xor    %eax,%eax
    9128:	e8 b3 a5 ff ff       	call   36e0 <__sprintf_chk@plt>
    912d:	e9 6e f0 ff ff       	jmp    81a0 <fwp_write+0x80>
    9132:	48 f7 d8             	neg    %rax
    9135:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    913a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    913f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9144:	48 83 d2 00          	adc    $0x0,%rdx
    9148:	48 89 c6             	mov    %rax,%rsi
    914b:	48 f7 da             	neg    %rdx
    914e:	e8 ed a8 ff ff       	call   3a40 <fwp_fmt_u128>
    9153:	44 8b 0c 24          	mov    (%rsp),%r9d
    9157:	eb 9c                	jmp    90f5 <fwp_write+0xfd5>
    9159:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009160 <fwp_main_thread>:
    9160:	f3 0f 1e fa          	endbr64
    9164:	41 57                	push   %r15
    9166:	41 56                	push   %r14
    9168:	41 55                	push   %r13
    916a:	41 54                	push   %r12
    916c:	55                   	push   %rbp
    916d:	53                   	push   %rbx
    916e:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
    9175:	44 8b 05 88 89 01 00 	mov    0x18988(%rip),%r8d        # 21b04 <fwp_heap+0x13a4>
    917c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9183:	00 00 
    9185:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
    918c:	00 
    918d:	31 c0                	xor    %eax,%eax
    918f:	45 85 c0             	test   %r8d,%r8d
    9192:	0f 84 b1 12 00 00    	je     a449 <fwp_main_thread+0x12e9>
    9198:	8b 3d 6a 89 01 00    	mov    0x1896a(%rip),%edi        # 21b08 <fwp_heap+0x13a8>
    919e:	85 ff                	test   %edi,%edi
    91a0:	0f 85 e6 05 00 00    	jne    978c <fwp_main_thread+0x62c>
    91a6:	48 8d 84 24 c0 00 00 	lea    0xc0(%rsp),%rax
    91ad:	00 
    91ae:	31 f6                	xor    %esi,%esi
    91b0:	48 c7 05 3d 6f 01 00 	movq   $0x40000000,0x16f3d(%rip)        # 200f8 <fwp_main_stack_size>
    91b7:	00 00 00 40 
    91bb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    91c0:	48 89 05 39 6f 01 00 	mov    %rax,0x16f39(%rip)        # 20100 <fwp_main_stack_top>
    91c7:	48 8d 05 b2 6e 00 00 	lea    0x6eb2(%rip),%rax        # 10080 <alt.5>
    91ce:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
    91d5:	00 
    91d6:	48 8d 84 24 e0 00 00 	lea    0xe0(%rsp),%rax
    91dd:	00 
    91de:	48 89 c7             	mov    %rax,%rdi
    91e1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    91e6:	48 c7 84 24 f0 00 00 	movq   $0x10000,0xf0(%rsp)
    91ed:	00 00 00 01 00 
    91f2:	c7 84 24 e8 00 00 00 	movl   $0x0,0xe8(%rsp)
    91f9:	00 00 00 00 
    91fd:	e8 be a4 ff ff       	call   36c0 <sigaltstack@plt>
    9202:	85 c0                	test   %eax,%eax
    9204:	0f 85 fe 20 00 00    	jne    b308 <fwp_main_thread+0x21a8>
    920a:	31 db                	xor    %ebx,%ebx
    920c:	b9 12 00 00 00       	mov    $0x12,%ecx
    9211:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
    9218:	00 
    9219:	48 89 d8             	mov    %rbx,%rax
    921c:	4c 8d bc 24 50 01 00 	lea    0x150(%rsp),%r15
    9223:	00 
    9224:	f3 48 ab             	rep stos %rax,(%rdi)
    9227:	48 8d 05 c2 aa ff ff 	lea    -0x553e(%rip),%rax        # 3cf0 <fwp_segv>
    922e:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
    9235:	00 
    9236:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
    923b:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
    9242:	00 
    9243:	c7 84 24 d8 01 00 00 	movl   $0x8000004,0x1d8(%rsp)
    924a:	04 00 00 08 
    924e:	e8 2d a3 ff ff       	call   3580 <sigemptyset@plt>
    9253:	85 c0                	test   %eax,%eax
    9255:	0f 85 ad 20 00 00    	jne    b308 <fwp_main_thread+0x21a8>
    925b:	31 d2                	xor    %edx,%edx
    925d:	4c 89 fe             	mov    %r15,%rsi
    9260:	bf 0b 00 00 00       	mov    $0xb,%edi
    9265:	e8 96 a1 ff ff       	call   3400 <sigaction@plt>
    926a:	85 c0                	test   %eax,%eax
    926c:	0f 85 96 20 00 00    	jne    b308 <fwp_main_thread+0x21a8>
    9272:	31 d2                	xor    %edx,%edx
    9274:	4c 89 fe             	mov    %r15,%rsi
    9277:	bf 07 00 00 00       	mov    $0x7,%edi
    927c:	e8 7f a1 ff ff       	call   3400 <sigaction@plt>
    9281:	85 c0                	test   %eax,%eax
    9283:	0f 85 7f 20 00 00    	jne    b308 <fwp_main_thread+0x21a8>
    9289:	8b 35 e1 6d 00 00    	mov    0x6de1(%rip),%esi        # 10070 <st.3>
    928f:	85 f6                	test   %esi,%esi
    9291:	0f 84 06 05 00 00    	je     979d <fwp_main_thread+0x63d>
    9297:	48 8b 2d a2 74 01 00 	mov    0x174a2(%rip),%rbp        # 20740 <fwp_cur>
    929e:	48 85 ed             	test   %rbp,%rbp
    92a1:	0f 84 c8 01 00 00    	je     946f <fwp_main_thread+0x30f>
    92a7:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    92ac:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    92b0:	48 89 eb             	mov    %rbp,%rbx
    92b3:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    92b8:	0f 84 41 01 00 00    	je     93ff <fwp_main_thread+0x29f>
    92be:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    92c3:	0f 84 e7 03 00 00    	je     96b0 <fwp_main_thread+0x550>
    92c9:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    92cd:	0f 84 b5 03 00 00    	je     9688 <fwp_main_thread+0x528>
    92d3:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    92d7:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    92db:	0f 85 4f 04 00 00    	jne    9730 <fwp_main_thread+0x5d0>
    92e1:	48 8b 43 60          	mov    0x60(%rbx),%rax
    92e5:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    92ec:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    92f0:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    92f7:	00 00 00 00 
    92fb:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9302:	48 85 d2             	test   %rdx,%rdx
    9305:	74 07                	je     930e <fwp_main_thread+0x1ae>
    9307:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    930e:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9312:	48 85 c0             	test   %rax,%rax
    9315:	74 34                	je     934b <fwp_main_thread+0x1eb>
    9317:	48 89 43 68          	mov    %rax,0x68(%rbx)
    931b:	48 8b 05 f6 73 01 00 	mov    0x173f6(%rip),%rax        # 20718 <fwp_timers>
    9322:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9326:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    932d:	00 00 00 00 
    9331:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9338:	48 85 c0             	test   %rax,%rax
    933b:	74 07                	je     9344 <fwp_main_thread+0x1e4>
    933d:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9344:	48 89 1d cd 73 01 00 	mov    %rbx,0x173cd(%rip)        # 20718 <fwp_timers>
    934b:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    934f:	e8 5c de ff ff       	call   71b0 <fwp_block>
    9354:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    935b:	48 85 c9             	test   %rcx,%rcx
    935e:	74 47                	je     93a7 <fwp_main_thread+0x247>
    9360:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9367:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    936e:	48 85 d2             	test   %rdx,%rdx
    9371:	0f 84 f9 03 00 00    	je     9770 <fwp_main_thread+0x610>
    9377:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    937e:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9385:	48 85 c0             	test   %rax,%rax
    9388:	74 07                	je     9391 <fwp_main_thread+0x231>
    938a:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9391:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9398:	00 00 00 00 
    939c:	66 0f ef ff          	pxor   %xmm7,%xmm7
    93a0:	0f 11 bb 18 01 00 00 	movups %xmm7,0x118(%rbx)
    93a7:	48 8b 0d 92 73 01 00 	mov    0x17392(%rip),%rcx        # 20740 <fwp_cur>
    93ae:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    93b2:	0f 84 68 03 00 00    	je     9720 <fwp_main_thread+0x5c0>
    93b8:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    93bf:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    93c6:	48 85 d2             	test   %rdx,%rdx
    93c9:	0f 84 b1 03 00 00    	je     9780 <fwp_main_thread+0x620>
    93cf:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    93d6:	48 85 c0             	test   %rax,%rax
    93d9:	74 07                	je     93e2 <fwp_main_thread+0x282>
    93db:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    93e2:	66 0f ef ff          	pxor   %xmm7,%xmm7
    93e6:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    93ea:	0f 11 bb 08 01 00 00 	movups %xmm7,0x108(%rbx)
    93f1:	48 89 cb             	mov    %rcx,%rbx
    93f4:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    93f9:	0f 85 bf fe ff ff    	jne    92be <fwp_main_thread+0x15e>
    93ff:	48 83 3d d1 8f 01 00 	cmpq   $0x0,0x18fd1(%rip)        # 223d8 <fwp_state_len>
    9406:	00 
    9407:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    940b:	75 0e                	jne    941b <fwp_main_thread+0x2bb>
    940d:	48 83 3d b3 8f 01 00 	cmpq   $0x0,0x18fb3(%rip)        # 223c8 <fwp_state_owners>
    9414:	00 
    9415:	0f 84 14 1d 00 00    	je     b12f <fwp_main_thread+0x1fcf>
    941b:	48 39 1d 16 73 01 00 	cmp    %rbx,0x17316(%rip)        # 20738 <fwp_root>
    9422:	c7 05 54 6c 01 00 00 	movl   $0x0,0x16c54(%rip)        # 20080 <fwp_exit_code>
    9429:	00 00 00 
    942c:	0f 85 17 1f 00 00    	jne    b349 <fwp_main_thread+0x21e9>
    9432:	48 85 db             	test   %rbx,%rbx
    9435:	74 5e                	je     9495 <fwp_main_thread+0x335>
    9437:	48 8b 15 ca 72 01 00 	mov    0x172ca(%rip),%rdx        # 20708 <fwp_tasks_active>
    943e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9442:	48 85 d2             	test   %rdx,%rdx
    9445:	74 4e                	je     9495 <fwp_main_thread+0x335>
    9447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    944e:	00 00 
    9450:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9454:	75 08                	jne    945e <fwp_main_thread+0x2fe>
    9456:	48 89 d7             	mov    %rdx,%rdi
    9459:	e8 52 ac ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    945e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9465:	48 85 d2             	test   %rdx,%rdx
    9468:	75 e6                	jne    9450 <fwp_main_thread+0x2f0>
    946a:	e9 e6 01 00 00       	jmp    9655 <fwp_main_thread+0x4f5>
    946f:	48 83 3d 61 8f 01 00 	cmpq   $0x0,0x18f61(%rip)        # 223d8 <fwp_state_len>
    9476:	00 
    9477:	0f 84 84 1b 00 00    	je     b001 <fwp_main_thread+0x1ea1>
    947d:	48 83 3d b3 72 01 00 	cmpq   $0x0,0x172b3(%rip)        # 20738 <fwp_root>
    9484:	00 
    9485:	c7 05 f1 6b 01 00 00 	movl   $0x0,0x16bf1(%rip)        # 20080 <fwp_exit_code>
    948c:	00 00 00 
    948f:	0f 85 af 1e 00 00    	jne    b344 <fwp_main_thread+0x21e4>
    9495:	e8 06 db ff ff       	call   6fa0 <fwp_free_zombie>
    949a:	48 83 3d 86 72 01 00 	cmpq   $0x0,0x17286(%rip)        # 20728 <fwp_ready_head>
    94a1:	00 
    94a2:	0f 85 a3 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94a8:	48 83 3d 68 72 01 00 	cmpq   $0x0,0x17268(%rip)        # 20718 <fwp_timers>
    94af:	00 
    94b0:	0f 85 95 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    94b6:	8b 05 50 6c 01 00    	mov    0x16c50(%rip),%eax        # 2010c <fwp_stack_pool_n>
    94bc:	85 c0                	test   %eax,%eax
    94be:	74 3d                	je     94fd <fwp_main_thread+0x39d>
    94c0:	83 e8 01             	sub    $0x1,%eax
    94c3:	4c 8d 25 56 6c 01 00 	lea    0x16c56(%rip),%r12        # 20120 <fwp_stack_pool>
    94ca:	48 63 d8             	movslq %eax,%rbx
    94cd:	89 c0                	mov    %eax,%eax
    94cf:	48 89 da             	mov    %rbx,%rdx
    94d2:	48 29 c2             	sub    %rax,%rdx
    94d5:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    94d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94e0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    94e4:	89 1d 22 6c 01 00    	mov    %ebx,0x16c22(%rip)        # 2010c <fwp_stack_pool_n>
    94ea:	be 00 00 00 10       	mov    $0x10000000,%esi
    94ef:	48 83 eb 01          	sub    $0x1,%rbx
    94f3:	e8 e8 a0 ff ff       	call   35e0 <munmap@plt>
    94f8:	48 39 eb             	cmp    %rbp,%rbx
    94fb:	75 e3                	jne    94e0 <fwp_main_thread+0x380>
    94fd:	8b 3d 15 6b 00 00    	mov    0x6b15(%rip),%edi        # 10018 <fwp_epfd>
    9503:	85 ff                	test   %edi,%edi
    9505:	78 05                	js     950c <fwp_main_thread+0x3ac>
    9507:	e8 c4 9f ff ff       	call   34d0 <close@plt>
    950c:	4c 8b 25 0d 6e 01 00 	mov    0x16e0d(%rip),%r12        # 20320 <fwp_nfdws>
    9513:	48 8b 2d 0e 6e 01 00 	mov    0x16e0e(%rip),%rbp        # 20328 <fwp_fdws>
    951a:	31 db                	xor    %ebx,%ebx
    951c:	c7 05 f2 6a 00 00 ff 	movl   $0xffffffff,0x6af2(%rip)        # 10018 <fwp_epfd>
    9523:	ff ff ff 
    9526:	4d 85 e4             	test   %r12,%r12
    9529:	74 32                	je     955d <fwp_main_thread+0x3fd>
    952b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9530:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    9535:	48 85 ff             	test   %rdi,%rdi
    9538:	74 1a                	je     9554 <fwp_main_thread+0x3f4>
    953a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    953e:	0f 85 07 a2 ff ff    	jne    374b <fwp_main_thread.cold>
    9544:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    9549:	0f 85 fc a1 ff ff    	jne    374b <fwp_main_thread.cold>
    954f:	e8 fc bf ff ff       	call   5550 <fwp_mem_free>
    9554:	48 83 c3 01          	add    $0x1,%rbx
    9558:	4c 39 e3             	cmp    %r12,%rbx
    955b:	75 d3                	jne    9530 <fwp_main_thread+0x3d0>
    955d:	48 89 ef             	mov    %rbp,%rdi
    9560:	e8 eb bf ff ff       	call   5550 <fwp_mem_free>
    9565:	48 8b 15 cc 71 01 00 	mov    0x171cc(%rip),%rdx        # 20738 <fwp_root>
    956c:	48 c7 05 b1 6d 01 00 	movq   $0x0,0x16db1(%rip)        # 20328 <fwp_fdws>
    9573:	00 00 00 00 
    9577:	48 c7 05 9e 6d 01 00 	movq   $0x0,0x16d9e(%rip)        # 20320 <fwp_nfdws>
    957e:	00 00 00 00 
    9582:	48 85 d2             	test   %rdx,%rdx
    9585:	74 4e                	je     95d5 <fwp_main_thread+0x475>
    9587:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    958c:	0f 85 b9 a1 ff ff    	jne    374b <fwp_main_thread.cold>
    9592:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    9599:	00 
    959a:	0f 85 ab a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95a0:	48 83 3d 30 8e 01 00 	cmpq   $0x0,0x18e30(%rip)        # 223d8 <fwp_state_len>
    95a7:	00 
    95a8:	0f 85 9d a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95ae:	48 83 3d 12 8e 01 00 	cmpq   $0x0,0x18e12(%rip)        # 223c8 <fwp_state_owners>
    95b5:	00 
    95b6:	0f 85 8f a1 ff ff    	jne    374b <fwp_main_thread.cold>
    95bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    95c1:	31 c0                	xor    %eax,%eax
    95c3:	48 8d 3d 76 6d 01 00 	lea    0x16d76(%rip),%rdi        # 20340 <fwp_root_context>
    95ca:	f3 48 ab             	rep stos %rax,(%rdi)
    95cd:	48 89 d7             	mov    %rdx,%rdi
    95d0:	e8 7b bf ff ff       	call   5550 <fwp_mem_free>
    95d5:	48 8b 3d 44 6a 00 00 	mov    0x6a44(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    95dc:	48 c7 05 59 71 01 00 	movq   $0x0,0x17159(%rip)        # 20740 <fwp_cur>
    95e3:	00 00 00 00 
    95e7:	48 c7 05 46 71 01 00 	movq   $0x0,0x17146(%rip)        # 20738 <fwp_root>
    95ee:	00 00 00 00 
    95f2:	e8 c9 9f ff ff       	call   35c0 <fflush@plt>
    95f7:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
    95fe:	00 
    95ff:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9606:	00 00 
    9608:	0f 85 06 1d 00 00    	jne    b314 <fwp_main_thread+0x21b4>
    960e:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
    9615:	31 c0                	xor    %eax,%eax
    9617:	5b                   	pop    %rbx
    9618:	5d                   	pop    %rbp
    9619:	41 5c                	pop    %r12
    961b:	41 5d                	pop    %r13
    961d:	41 5e                	pop    %r14
    961f:	41 5f                	pop    %r15
    9621:	c3                   	ret
    9622:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9628:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    962f:	48 89 1d ea 70 01 00 	mov    %rbx,0x170ea(%rip)        # 20720 <fwp_ready_tail>
    9636:	e8 75 db ff ff       	call   71b0 <fwp_block>
    963b:	e8 60 d9 ff ff       	call   6fa0 <fwp_free_zombie>
    9640:	48 83 3d c0 70 01 00 	cmpq   $0x0,0x170c0(%rip)        # 20708 <fwp_tasks_active>
    9647:	00 
    9648:	0f 84 47 fe ff ff    	je     9495 <fwp_main_thread+0x335>
    964e:	48 8b 1d e3 70 01 00 	mov    0x170e3(%rip),%rbx        # 20738 <fwp_root>
    9655:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9659:	75 db                	jne    9636 <fwp_main_thread+0x4d6>
    965b:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    965f:	75 d5                	jne    9636 <fwp_main_thread+0x4d6>
    9661:	48 8b 05 b8 70 01 00 	mov    0x170b8(%rip),%rax        # 20720 <fwp_ready_tail>
    9668:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    966c:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9673:	00 00 00 00 
    9677:	48 85 c0             	test   %rax,%rax
    967a:	75 ac                	jne    9628 <fwp_main_thread+0x4c8>
    967c:	48 89 1d a5 70 01 00 	mov    %rbx,0x170a5(%rip)        # 20728 <fwp_ready_head>
    9683:	eb aa                	jmp    962f <fwp_main_thread+0x4cf>
    9685:	0f 1f 00             	nopl   (%rax)
    9688:	e8 83 ac ff ff       	call   4310 <fwp_now_ns>
    968d:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9691:	7c 1d                	jl     96b0 <fwp_main_thread+0x550>
    9693:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    9697:	75 17                	jne    96b0 <fwp_main_thread+0x550>
    9699:	48 89 ef             	mov    %rbp,%rdi
    969c:	e8 0f aa ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    96a1:	0f 1f 40 00          	nopl   0x0(%rax)
    96a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    96ac:	00 00 00 00 
    96b0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    96b4:	0f 85 19 fc ff ff    	jne    92d3 <fwp_main_thread+0x173>
    96ba:	48 8b 45 60          	mov    0x60(%rbp),%rax
    96be:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    96c2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    96c6:	0f 85 19 fc ff ff    	jne    92e5 <fwp_main_thread+0x185>
    96cc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    96d0:	48 85 c9             	test   %rcx,%rcx
    96d3:	0f 84 0c fc ff ff    	je     92e5 <fwp_main_thread+0x185>
    96d9:	48 39 c8             	cmp    %rcx,%rax
    96dc:	48 89 ce             	mov    %rcx,%rsi
    96df:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    96e6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    96ea:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    96f1:	00 00 00 00 
    96f5:	48 0f 4e f0          	cmovle %rax,%rsi
    96f9:	48 85 c0             	test   %rax,%rax
    96fc:	48 89 c8             	mov    %rcx,%rax
    96ff:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9706:	48 0f 45 c6          	cmovne %rsi,%rax
    970a:	48 85 d2             	test   %rdx,%rdx
    970d:	74 07                	je     9716 <fwp_main_thread+0x5b6>
    970f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9716:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    971a:	e9 f8 fb ff ff       	jmp    9317 <fwp_main_thread+0x1b7>
    971f:	90                   	nop
    9720:	48 89 cb             	mov    %rcx,%rbx
    9723:	e9 8b fb ff ff       	jmp    92b3 <fwp_main_thread+0x153>
    9728:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    972f:	00 
    9730:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9734:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    973b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9742:	00 00 00 00 
    9746:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    974d:	48 85 c0             	test   %rax,%rax
    9750:	0f 84 94 18 00 00    	je     afea <fwp_main_thread+0x1e8a>
    9756:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    975d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9761:	e9 e5 fb ff ff       	jmp    934b <fwp_main_thread+0x1eb>
    9766:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    976d:	00 00 00 
    9770:	48 89 01             	mov    %rax,(%rcx)
    9773:	e9 0d fc ff ff       	jmp    9385 <fwp_main_thread+0x225>
    9778:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    977f:	00 
    9780:	48 89 05 91 6f 01 00 	mov    %rax,0x16f91(%rip)        # 20718 <fwp_timers>
    9787:	e9 4a fc ff ff       	jmp    93d6 <fwp_main_thread+0x276>
    978c:	48 8d 3d 8d b2 ff ff 	lea    -0x4d73(%rip),%rdi        # 4a20 <fwp_heap_report>
    9793:	e8 c8 1d 00 00       	call   b560 <atexit>
    9798:	e9 09 fa ff ff       	jmp    91a6 <fwp_main_thread+0x46>
    979d:	48 8d 05 2c e0 ff ff 	lea    -0x1fd4(%rip),%rax        # 77d0 <fwp_drop1>
    97a4:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    97a9:	45 31 f6             	xor    %r14d,%r14d
    97ac:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
    97b3:	00 00 00 00 00 
    97b8:	66 48 0f 6e f8       	movq   %rax,%xmm7
    97bd:	48 8b 05 34 8c 01 00 	mov    0x18c34(%rip),%rax        # 223f8 <fwp_cleanups>
    97c4:	4c 8b 64 24 20       	mov    0x20(%rsp),%r12
    97c9:	bb ff 01 00 00       	mov    $0x1ff,%ebx
    97ce:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    97d2:	48 8d 2d 87 6f 01 00 	lea    0x16f87(%rip),%rbp        # 20760 <fwp_heap>
    97d9:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    97e0:	00 
    97e1:	48 8d 05 e8 a3 ff ff 	lea    -0x5c18(%rip),%rax        # 3bd0 <fwp_range_release>
    97e8:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    97ef:	00 
    97f0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    97f5:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
    97fc:	00 
    97fd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    9804:	00 
    9805:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    980a:	48 89 05 e7 8b 01 00 	mov    %rax,0x18be7(%rip)        # 223f8 <fwp_cleanups>
    9811:	eb 45                	jmp    9858 <fwp_main_thread+0x6f8>
    9813:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9818:	80 f9 01             	cmp    $0x1,%cl
    981b:	75 29                	jne    9846 <fwp_main_thread+0x6e6>
    981d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9820:	0f b7 c0             	movzwl %ax,%eax
    9823:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9826:	48 0f af c1          	imul   %rcx,%rax
    982a:	48 c1 e8 20          	shr    $0x20,%rax
    982e:	48 39 d0             	cmp    %rdx,%rax
    9831:	73 13                	jae    9846 <fwp_main_thread+0x6e6>
    9833:	49 01 c5             	add    %rax,%r13
    9836:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    983b:	0f 84 25 18 00 00    	je     b066 <fwp_main_thread+0x1f06>
    9841:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9846:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    984d:	00 
    984e:	48 83 eb 01          	sub    $0x1,%rbx
    9852:	0f 82 85 00 00 00    	jb     98dd <fwp_main_thread+0x77d>
    9858:	4c 89 e6             	mov    %r12,%rsi
    985b:	bf 01 00 00 00       	mov    $0x1,%edi
    9860:	4c 89 b4 24 58 01 00 	mov    %r14,0x158(%rsp)
    9867:	00 
    9868:	48 89 9c 24 e8 00 00 	mov    %rbx,0xe8(%rsp)
    986f:	00 
    9870:	48 89 9c 24 50 01 00 	mov    %rbx,0x150(%rsp)
    9877:	00 
    9878:	e8 f3 c2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    987d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9884:	49 89 c6             	mov    %rax,%r14
    9887:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    988e:	48 c1 e2 10          	shl    $0x10,%rdx
    9892:	48 39 d0             	cmp    %rdx,%rax
    9895:	73 af                	jae    9846 <fwp_main_thread+0x6e6>
    9897:	48 89 c2             	mov    %rax,%rdx
    989a:	48 c1 ea 10          	shr    $0x10,%rdx
    989e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    98a2:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    98a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    98ad:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    98b1:	4d 85 ed             	test   %r13,%r13
    98b4:	74 90                	je     9846 <fwp_main_thread+0x6e6>
    98b6:	0f b6 0a             	movzbl (%rdx),%ecx
    98b9:	80 f9 02             	cmp    $0x2,%cl
    98bc:	0f 85 56 ff ff ff    	jne    9818 <fwp_main_thread+0x6b8>
    98c2:	66 85 c0             	test   %ax,%ax
    98c5:	0f 84 6b ff ff ff    	je     9836 <fwp_main_thread+0x6d6>
    98cb:	4c 89 b4 24 e0 00 00 	mov    %r14,0xe0(%rsp)
    98d2:	00 
    98d3:	48 83 eb 01          	sub    $0x1,%rbx
    98d7:	0f 83 7b ff ff ff    	jae    9858 <fwp_main_thread+0x6f8>
    98dd:	48 8b 9c 24 c0 00 00 	mov    0xc0(%rsp),%rbx
    98e4:	00 
    98e5:	66 0f 6f 05 63 32 00 	movdqa 0x3263(%rip),%xmm0        # cb50 <msg.4+0xd0>
    98ec:	00 
    98ed:	bf 01 00 00 00       	mov    $0x1,%edi
    98f2:	48 8d b4 24 40 01 00 	lea    0x140(%rsp),%rsi
    98f9:	00 
    98fa:	48 89 1d f7 8a 01 00 	mov    %rbx,0x18af7(%rip)        # 223f8 <fwp_cleanups>
    9901:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
    9908:	00 
    9909:	e8 62 c2 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    990e:	48 8b 15 23 82 01 00 	mov    0x18223(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9915:	49 89 c5             	mov    %rax,%r13
    9918:	48 2b 05 f1 81 01 00 	sub    0x181f1(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    991f:	48 c1 e2 10          	shl    $0x10,%rdx
    9923:	48 39 d0             	cmp    %rdx,%rax
    9926:	73 59                	jae    9981 <fwp_main_thread+0x821>
    9928:	48 89 c2             	mov    %rax,%rdx
    992b:	48 c1 ea 10          	shr    $0x10,%rdx
    992f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9933:	48 8b 15 1e 82 01 00 	mov    0x1821e(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    993a:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    993e:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    9942:	4d 85 e4             	test   %r12,%r12
    9945:	74 3a                	je     9981 <fwp_main_thread+0x821>
    9947:	0f b6 0a             	movzbl (%rdx),%ecx
    994a:	80 f9 02             	cmp    $0x2,%cl
    994d:	0f 84 05 17 00 00    	je     b058 <fwp_main_thread+0x1ef8>
    9953:	80 f9 01             	cmp    $0x1,%cl
    9956:	75 29                	jne    9981 <fwp_main_thread+0x821>
    9958:	8b 4a 18             	mov    0x18(%rdx),%ecx
    995b:	0f b7 c0             	movzwl %ax,%eax
    995e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9961:	48 0f af c1          	imul   %rcx,%rax
    9965:	48 c1 e8 20          	shr    $0x20,%rax
    9969:	48 39 d0             	cmp    %rdx,%rax
    996c:	73 13                	jae    9981 <fwp_main_thread+0x821>
    996e:	49 01 c4             	add    %rax,%r12
    9971:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9976:	0f 84 d4 18 00 00    	je     b250 <fwp_main_thread+0x20f0>
    997c:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9981:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    9988:	00 f0 3f 
    998b:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
    9992:	00 
    9993:	bf 01 00 00 00       	mov    $0x1,%edi
    9998:	4c 89 ac 24 38 01 00 	mov    %r13,0x138(%rsp)
    999f:	00 
    99a0:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
    99a7:	00 
    99a8:	e8 c3 c1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    99ad:	48 8b 15 84 81 01 00 	mov    0x18184(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    99b4:	49 89 c5             	mov    %rax,%r13
    99b7:	48 2b 05 52 81 01 00 	sub    0x18152(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    99be:	48 c1 e2 10          	shl    $0x10,%rdx
    99c2:	48 39 d0             	cmp    %rdx,%rax
    99c5:	73 59                	jae    9a20 <fwp_main_thread+0x8c0>
    99c7:	48 89 c2             	mov    %rax,%rdx
    99ca:	48 c1 ea 10          	shr    $0x10,%rdx
    99ce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99d2:	48 8b 15 7f 81 01 00 	mov    0x1817f(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    99d9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99dd:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    99e1:	4d 85 e4             	test   %r12,%r12
    99e4:	74 3a                	je     9a20 <fwp_main_thread+0x8c0>
    99e6:	0f b6 0a             	movzbl (%rdx),%ecx
    99e9:	80 f9 02             	cmp    $0x2,%cl
    99ec:	0f 84 58 16 00 00    	je     b04a <fwp_main_thread+0x1eea>
    99f2:	80 f9 01             	cmp    $0x1,%cl
    99f5:	75 29                	jne    9a20 <fwp_main_thread+0x8c0>
    99f7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99fa:	0f b7 c0             	movzwl %ax,%eax
    99fd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9a00:	48 0f af c1          	imul   %rcx,%rax
    9a04:	48 c1 e8 20          	shr    $0x20,%rax
    9a08:	48 39 d0             	cmp    %rdx,%rax
    9a0b:	73 13                	jae    9a20 <fwp_main_thread+0x8c0>
    9a0d:	49 01 c4             	add    %rax,%r12
    9a10:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9a15:	0f 84 42 18 00 00    	je     b25d <fwp_main_thread+0x20fd>
    9a1b:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9a20:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    9a27:	33 f3 bf 
    9a2a:	48 8d b4 24 20 01 00 	lea    0x120(%rsp),%rsi
    9a31:	00 
    9a32:	bf 01 00 00 00       	mov    $0x1,%edi
    9a37:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
    9a3e:	00 
    9a3f:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
    9a46:	00 
    9a47:	e8 24 c1 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    9a4c:	48 8b 15 e5 80 01 00 	mov    0x180e5(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9a53:	48 8b 0d b6 80 01 00 	mov    0x180b6(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    9a5a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9a5f:	48 89 d6             	mov    %rdx,%rsi
    9a62:	48 29 c8             	sub    %rcx,%rax
    9a65:	48 c1 e6 10          	shl    $0x10,%rsi
    9a69:	48 39 f0             	cmp    %rsi,%rax
    9a6c:	73 69                	jae    9ad7 <fwp_main_thread+0x977>
    9a6e:	48 89 c6             	mov    %rax,%rsi
    9a71:	48 c1 ee 10          	shr    $0x10,%rsi
    9a75:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9a79:	48 8b 35 d8 80 01 00 	mov    0x180d8(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    9a80:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9a84:	4c 8b 66 20          	mov    0x20(%rsi),%r12
    9a88:	4d 85 e4             	test   %r12,%r12
    9a8b:	74 4a                	je     9ad7 <fwp_main_thread+0x977>
    9a8d:	0f b6 3e             	movzbl (%rsi),%edi
    9a90:	40 80 ff 02          	cmp    $0x2,%dil
    9a94:	0f 84 a2 15 00 00    	je     b03c <fwp_main_thread+0x1edc>
    9a9a:	40 80 ff 01          	cmp    $0x1,%dil
    9a9e:	75 37                	jne    9ad7 <fwp_main_thread+0x977>
    9aa0:	8b 7e 18             	mov    0x18(%rsi),%edi
    9aa3:	0f b7 c0             	movzwl %ax,%eax
    9aa6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9aa9:	48 0f af c7          	imul   %rdi,%rax
    9aad:	48 c1 e8 20          	shr    $0x20,%rax
    9ab1:	48 39 f0             	cmp    %rsi,%rax
    9ab4:	73 21                	jae    9ad7 <fwp_main_thread+0x977>
    9ab6:	49 01 c4             	add    %rax,%r12
    9ab9:	41 80 3c 24 ff       	cmpb   $0xff,(%r12)
    9abe:	0f 84 a6 17 00 00    	je     b26a <fwp_main_thread+0x210a>
    9ac4:	41 c6 04 24 01       	movb   $0x1,(%r12)
    9ac9:	48 8b 0d 40 80 01 00 	mov    0x18040(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    9ad0:	48 8b 15 61 80 01 00 	mov    0x18061(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9ad7:	48 8d 84 24 9c 00 00 	lea    0x9c(%rsp),%rax
    9ade:	00 
    9adf:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
    9ae6:	00 
    9ae7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    9aec:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    9af3:	00 
    9af4:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    9af9:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
    9b00:	00 
    9b01:	0f 1f 40 00          	nopl   0x0(%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b15:	48 c1 e2 10          	shl    $0x10,%rdx
    9b19:	48 29 c8             	sub    %rcx,%rax
    9b1c:	48 39 d0             	cmp    %rdx,%rax
    9b1f:	73 73                	jae    9b94 <fwp_main_thread+0xa34>
    9b21:	48 89 c6             	mov    %rax,%rsi
    9b24:	48 c1 ee 10          	shr    $0x10,%rsi
    9b28:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9b2c:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    9b33:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9b37:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9b3b:	48 85 ff             	test   %rdi,%rdi
    9b3e:	74 54                	je     9b94 <fwp_main_thread+0xa34>
    9b40:	44 0f b6 06          	movzbl (%rsi),%r8d
    9b44:	41 80 f8 02          	cmp    $0x2,%r8b
    9b48:	0f 84 1a 14 00 00    	je     af68 <fwp_main_thread+0x1e08>
    9b4e:	41 80 f8 01          	cmp    $0x1,%r8b
    9b52:	75 40                	jne    9b94 <fwp_main_thread+0xa34>
    9b54:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    9b58:	0f b7 c0             	movzwl %ax,%eax
    9b5b:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9b5e:	49 0f af c0          	imul   %r8,%rax
    9b62:	48 c1 e8 20          	shr    $0x20,%rax
    9b66:	48 39 f0             	cmp    %rsi,%rax
    9b69:	73 29                	jae    9b94 <fwp_main_thread+0xa34>
    9b6b:	48 01 c7             	add    %rax,%rdi
    9b6e:	0f b6 07             	movzbl (%rdi),%eax
    9b71:	84 c0                	test   %al,%al
    9b73:	74 1f                	je     9b94 <fwp_main_thread+0xa34>
    9b75:	3c fd                	cmp    $0xfd,%al
    9b77:	0f 87 81 16 00 00    	ja     b1fe <fwp_main_thread+0x209e>
    9b7d:	83 c0 01             	add    $0x1,%eax
    9b80:	88 07                	mov    %al,(%rdi)
    9b82:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9b89:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    9b90:	48 c1 e2 10          	shl    $0x10,%rdx
    9b94:	48 8d 05 05 cf ff ff 	lea    -0x30fb(%rip),%rax        # 6aa0 <fwp_tape_scope_release>
    9b9b:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
    9ba2:	00 
    9ba3:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
    9baa:	00 
    9bab:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    9bb0:	c7 84 24 9c 00 00 00 	movl   $0xffffffff,0x9c(%rsp)
    9bb7:	ff ff ff ff 
    9bbb:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
    9bc2:	00 
    9bc3:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    9bc8:	48 89 05 29 88 01 00 	mov    %rax,0x18829(%rip)        # 223f8 <fwp_cleanups>
    9bcf:	48 8d 05 3a 64 00 00 	lea    0x643a(%rip),%rax        # 10010 <fc37>
    9bd6:	48 29 c8             	sub    %rcx,%rax
    9bd9:	48 39 d0             	cmp    %rdx,%rax
    9bdc:	73 5d                	jae    9c3b <fwp_main_thread+0xadb>
    9bde:	48 89 c2             	mov    %rax,%rdx
    9be1:	48 c1 ea 10          	shr    $0x10,%rdx
    9be5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9be9:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9bf0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9bf4:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9bf8:	48 85 ff             	test   %rdi,%rdi
    9bfb:	74 3e                	je     9c3b <fwp_main_thread+0xadb>
    9bfd:	0f b6 0a             	movzbl (%rdx),%ecx
    9c00:	80 f9 02             	cmp    $0x2,%cl
    9c03:	0f 84 f7 11 00 00    	je     ae00 <fwp_main_thread+0x1ca0>
    9c09:	80 f9 01             	cmp    $0x1,%cl
    9c0c:	75 2d                	jne    9c3b <fwp_main_thread+0xadb>
    9c0e:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c11:	0f b7 c0             	movzwl %ax,%eax
    9c14:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c17:	48 0f af c1          	imul   %rcx,%rax
    9c1b:	48 c1 e8 20          	shr    $0x20,%rax
    9c1f:	48 39 d0             	cmp    %rdx,%rax
    9c22:	73 17                	jae    9c3b <fwp_main_thread+0xadb>
    9c24:	48 01 c7             	add    %rax,%rdi
    9c27:	0f b6 07             	movzbl (%rdi),%eax
    9c2a:	84 c0                	test   %al,%al
    9c2c:	74 0d                	je     9c3b <fwp_main_thread+0xadb>
    9c2e:	3c fd                	cmp    $0xfd,%al
    9c30:	0f 87 a6 14 00 00    	ja     b0dc <fwp_main_thread+0x1f7c>
    9c36:	83 c0 01             	add    $0x1,%eax
    9c39:	88 07                	mov    %al,(%rdi)
    9c3b:	48 8d 3d ce 63 00 00 	lea    0x63ce(%rip),%rdi        # 10010 <fc37>
    9c42:	31 db                	xor    %ebx,%ebx
    9c44:	e8 27 cb ff ff       	call   6770 <fwp_closure_drop>
    9c49:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    9c4e:	66 90                	xchg   %ax,%ax
    9c50:	4d 8b 64 24 10       	mov    0x10(%r12),%r12
    9c55:	48 83 c3 01          	add    $0x1,%rbx
    9c59:	4d 85 e4             	test   %r12,%r12
    9c5c:	75 f2                	jne    9c50 <fwp_main_thread+0xaf0>
    9c5e:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    9c65:	0f 87 85 16 00 00    	ja     b2f0 <fwp_main_thread+0x2190>
    9c6b:	8b 0d ef 63 00 00    	mov    0x63ef(%rip),%ecx        # 10060 <registered_finish.1>
    9c71:	85 c9                	test   %ecx,%ecx
    9c73:	0f 84 47 11 00 00    	je     adc0 <fwp_main_thread+0x1c60>
    9c79:	4c 8b 35 58 64 01 00 	mov    0x16458(%rip),%r14        # 200d8 <fwp_tape_next_slot>
    9c80:	4c 8b 2d 61 64 01 00 	mov    0x16461(%rip),%r13        # 200e8 <fwp_ntapes>
    9c87:	4d 39 ee             	cmp    %r13,%r14
    9c8a:	0f 8d 28 0e 00 00    	jge    aab8 <fwp_main_thread+0x1958>
    9c90:	49 6b c6 68          	imul   $0x68,%r14,%rax
    9c94:	48 03 05 55 64 01 00 	add    0x16455(%rip),%rax        # 200f0 <fwp_tapes>
    9c9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9ca0:	8b 50 04             	mov    0x4(%rax),%edx
    9ca3:	85 d2                	test   %edx,%edx
    9ca5:	75 0c                	jne    9cb3 <fwp_main_thread+0xb53>
    9ca7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    9cad:	0f 86 05 0e 00 00    	jbe    aab8 <fwp_main_thread+0x1958>
    9cb3:	49 83 c6 01          	add    $0x1,%r14
    9cb7:	48 83 c0 68          	add    $0x68,%rax
    9cbb:	4d 39 ee             	cmp    %r13,%r14
    9cbe:	75 e0                	jne    9ca0 <fwp_main_thread+0xb40>
    9cc0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    9cc7:	0f 8f 2f 16 00 00    	jg     b2fc <fwp_main_thread+0x219c>
    9ccd:	4c 3b 2d 0c 64 01 00 	cmp    0x1640c(%rip),%r13        # 200e0 <fwp_tapes_cap>
    9cd4:	4c 8b 3d 15 64 01 00 	mov    0x16415(%rip),%r15        # 200f0 <fwp_tapes>
    9cdb:	75 40                	jne    9d1d <fwp_main_thread+0xbbd>
    9cdd:	4d 85 ed             	test   %r13,%r13
    9ce0:	0f 84 f4 12 00 00    	je     afda <fwp_main_thread+0x1e7a>
    9ce6:	4f 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%r14
    9ceb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9cf0:	49 39 c6             	cmp    %rax,%r14
    9cf3:	4c 0f 4f f0          	cmovg  %rax,%r14
    9cf7:	49 6b f6 68          	imul   $0x68,%r14,%rsi
    9cfb:	4c 89 ff             	mov    %r15,%rdi
    9cfe:	e8 cd 98 ff ff       	call   35d0 <realloc@plt>
    9d03:	49 89 c7             	mov    %rax,%r15
    9d06:	48 85 c0             	test   %rax,%rax
    9d09:	0f 84 a7 15 00 00    	je     b2b6 <fwp_main_thread+0x2156>
    9d0f:	48 89 05 da 63 01 00 	mov    %rax,0x163da(%rip)        # 200f0 <fwp_tapes>
    9d16:	4c 89 35 c3 63 01 00 	mov    %r14,0x163c3(%rip)        # 200e0 <fwp_tapes_cap>
    9d1d:	49 6b c5 68          	imul   $0x68,%r13,%rax
    9d21:	4d 89 ee             	mov    %r13,%r14
    9d24:	4c 01 f8             	add    %r15,%rax
    9d27:	48 8d 78 08          	lea    0x8(%rax),%rdi
    9d2b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9d32:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    9d36:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    9d3d:	00 
    9d3e:	48 29 f8             	sub    %rdi,%rax
    9d41:	8d 48 68             	lea    0x68(%rax),%ecx
    9d44:	31 c0                	xor    %eax,%eax
    9d46:	c1 e9 03             	shr    $0x3,%ecx
    9d49:	f3 48 ab             	rep stos %rax,(%rdi)
    9d4c:	49 8d 45 01          	lea    0x1(%r13),%rax
    9d50:	48 89 05 91 63 01 00 	mov    %rax,0x16391(%rip)        # 200e8 <fwp_ntapes>
    9d57:	4d 6b ee 68          	imul   $0x68,%r14,%r13
    9d5b:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    9d60:	48 8d 3d 58 23 00 00 	lea    0x2358(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    9d67:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    9d6b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    9d70:	4d 01 fd             	add    %r15,%r13
    9d73:	49 c7 45 60 00 00 00 	movq   $0x0,0x60(%r13)
    9d7a:	00 
    9d7b:	e8 20 96 ff ff       	call   33a0 <getenv@plt>
    9d80:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    9d86:	48 85 c0             	test   %rax,%rax
    9d89:	0f 84 41 0d 00 00    	je     aad0 <fwp_main_thread+0x1970>
    9d8f:	80 38 30             	cmpb   $0x30,(%rax)
    9d92:	0f 85 38 0d 00 00    	jne    aad0 <fwp_main_thread+0x1970>
    9d98:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    9d9c:	0f 85 2e 0d 00 00    	jne    aad0 <fwp_main_thread+0x1970>
    9da2:	41 8b 45 00          	mov    0x0(%r13),%eax
    9da6:	49 8d 5e 01          	lea    0x1(%r14),%rbx
    9daa:	41 c7 45 04 01 00 00 	movl   $0x1,0x4(%r13)
    9db1:	00 
    9db2:	48 89 1d 1f 63 01 00 	mov    %rbx,0x1631f(%rip)        # 200d8 <fwp_tape_next_slot>
    9db9:	8d 50 01             	lea    0x1(%rax),%edx
    9dbc:	48 8b 05 dd 2c 00 00 	mov    0x2cdd(%rip),%rax        # caa0 <msg.4+0x20>
    9dc3:	41 0f 11 45 08       	movups %xmm0,0x8(%r13)
    9dc8:	41 89 55 00          	mov    %edx,0x0(%r13)
    9dcc:	49 89 45 58          	mov    %rax,0x58(%r13)
    9dd0:	48 8b 05 21 86 01 00 	mov    0x18621(%rip),%rax        # 223f8 <fwp_cleanups>
    9dd7:	49 c7 45 50 00 00 00 	movq   $0x0,0x50(%r13)
    9dde:	00 
    9ddf:	48 85 c0             	test   %rax,%rax
    9de2:	75 28                	jne    9e0c <fwp_main_thread+0xcac>
    9de4:	e9 37 15 00 00       	jmp    b320 <fwp_main_thread+0x21c0>
    9de9:	90                   	nop
    9dea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9df1:	00 00 00 00 
    9df5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9dfc:	00 00 00 00 
    9e00:	48 8b 00             	mov    (%rax),%rax
    9e03:	48 85 c0             	test   %rax,%rax
    9e06:	0f 84 14 15 00 00    	je     b320 <fwp_main_thread+0x21c0>
    9e0c:	48 8d 3d 8d cc ff ff 	lea    -0x3373(%rip),%rdi        # 6aa0 <fwp_tape_scope_release>
    9e13:	48 39 78 08          	cmp    %rdi,0x8(%rax)
    9e17:	75 e7                	jne    9e00 <fwp_main_thread+0xca0>
    9e19:	48 8b 70 10          	mov    0x10(%rax),%rsi
    9e1d:	44 89 f1             	mov    %r14d,%ecx
    9e20:	48 63 06             	movslq (%rsi),%rax
    9e23:	49 89 75 50          	mov    %rsi,0x50(%r13)
    9e27:	41 89 45 5c          	mov    %eax,0x5c(%r13)
    9e2b:	85 c0                	test   %eax,%eax
    9e2d:	78 09                	js     9e38 <fwp_main_thread+0xcd8>
    9e2f:	48 6b c0 68          	imul   $0x68,%rax,%rax
    9e33:	45 89 74 07 58       	mov    %r14d,0x58(%r15,%rax,1)
    9e38:	89 0e                	mov    %ecx,(%rsi)
    9e3a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9e3f:	90                   	nop
    9e40:	48 8b 40 10          	mov    0x10(%rax),%rax
    9e44:	49 83 c4 01          	add    $0x1,%r12
    9e48:	48 85 c0             	test   %rax,%rax
    9e4b:	75 f3                	jne    9e40 <fwp_main_thread+0xce0>
    9e4d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9e52:	0f 1f 00             	nopl   (%rax)
    9e55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9e5c:	00 00 00 00 
    9e60:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9e64:	48 83 c0 01          	add    $0x1,%rax
    9e68:	4d 85 ff             	test   %r15,%r15
    9e6b:	75 f3                	jne    9e60 <fwp_main_thread+0xd00>
    9e6d:	48 b9 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rcx
    9e74:	ff ff 1f 
    9e77:	48 39 c1             	cmp    %rax,%rcx
    9e7a:	0f 82 64 14 00 00    	jb     b2e4 <fwp_main_thread+0x2184>
    9e80:	4d 85 e4             	test   %r12,%r12
    9e83:	0f 8e c7 0d 00 00    	jle    ac50 <fwp_main_thread+0x1af0>
    9e89:	49 39 c4             	cmp    %rax,%r12
    9e8c:	4c 0f 47 e0          	cmova  %rax,%r12
    9e90:	4c 89 e0             	mov    %r12,%rax
    9e93:	48 c1 e8 3c          	shr    $0x3c,%rax
    9e97:	0f 85 47 14 00 00    	jne    b2e4 <fwp_main_thread+0x2184>
    9e9d:	4f 8d 2c 24          	lea    (%r12,%r12,1),%r13
    9ea1:	48 c1 e2 10          	shl    $0x10,%rdx
    9ea5:	be 02 00 00 00       	mov    $0x2,%esi
    9eaa:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    9eb1:	00 
    9eb2:	48 09 d3             	or     %rdx,%rbx
    9eb5:	e8 96 bb ff ff       	call   5a50 <fwp_heap_alloc>
    9eba:	4c 89 28             	mov    %r13,(%rax)
    9ebd:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    9ec4:	49 89 c6             	mov    %rax,%r14
    9ec7:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    9ece:	48 c1 e2 10          	shl    $0x10,%rdx
    9ed2:	48 39 d0             	cmp    %rdx,%rax
    9ed5:	0f 83 55 0d 00 00    	jae    ac30 <fwp_main_thread+0x1ad0>
    9edb:	48 89 c2             	mov    %rax,%rdx
    9ede:	48 c1 ea 10          	shr    $0x10,%rdx
    9ee2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9ee6:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    9eed:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ef1:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    9ef5:	4d 85 ed             	test   %r13,%r13
    9ef8:	74 3a                	je     9f34 <fwp_main_thread+0xdd4>
    9efa:	0f b6 0a             	movzbl (%rdx),%ecx
    9efd:	80 f9 02             	cmp    $0x2,%cl
    9f00:	0f 84 b3 0d 00 00    	je     acb9 <fwp_main_thread+0x1b59>
    9f06:	80 f9 01             	cmp    $0x1,%cl
    9f09:	75 29                	jne    9f34 <fwp_main_thread+0xdd4>
    9f0b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f0e:	0f b7 c0             	movzwl %ax,%eax
    9f11:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f14:	48 0f af c1          	imul   %rcx,%rax
    9f18:	48 c1 e8 20          	shr    $0x20,%rax
    9f1c:	48 39 d0             	cmp    %rdx,%rax
    9f1f:	73 13                	jae    9f34 <fwp_main_thread+0xdd4>
    9f21:	49 01 c5             	add    %rax,%r13
    9f24:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    9f29:	0f 84 9e 0d 00 00    	je     accd <fwp_main_thread+0x1b6d>
    9f2f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    9f34:	4d 85 e4             	test   %r12,%r12
    9f37:	74 7b                	je     9fb4 <fwp_main_thread+0xe54>
    9f39:	48 89 d9             	mov    %rbx,%rcx
    9f3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9f41:	31 c0                	xor    %eax,%eax
    9f43:	48 c1 e1 20          	shl    $0x20,%rcx
    9f47:	66 90                	xchg   %ax,%ax
    9f49:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f50:	00 00 00 00 
    9f54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f5b:	00 00 00 00 
    9f5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f66:	00 00 00 00 
    9f6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f71:	00 00 00 00 
    9f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9f7c:	00 00 00 00 
    9f80:	48 89 c6             	mov    %rax,%rsi
    9f83:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    9f88:	48 01 ce             	add    %rcx,%rsi
    9f8b:	0f 80 f2 12 00 00    	jo     b283 <fwp_main_thread+0x2123>
    9f91:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    9f96:	48 89 c6             	mov    %rax,%rsi
    9f99:	48 83 c0 01          	add    $0x1,%rax
    9f9d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    9fa1:	48 c1 e6 04          	shl    $0x4,%rsi
    9fa5:	41 0f 11 44 36 08    	movups %xmm0,0x8(%r14,%rsi,1)
    9fab:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    9faf:	4c 39 e0             	cmp    %r12,%rax
    9fb2:	72 cc                	jb     9f80 <fwp_main_thread+0xe20>
    9fb4:	49 8b 06             	mov    (%r14),%rax
    9fb7:	48 d1 e8             	shr    $1,%rax
    9fba:	0f 84 80 0c 00 00    	je     ac40 <fwp_main_thread+0x1ae0>
    9fc0:	48 8d 48 ff          	lea    -0x1(%rax),%rcx
    9fc4:	48 89 cf             	mov    %rcx,%rdi
    9fc7:	48 c1 ef 3c          	shr    $0x3c,%rdi
    9fcb:	0f 85 13 13 00 00    	jne    b2e4 <fwp_main_thread+0x2184>
    9fd1:	48 8d 14 09          	lea    (%rcx,%rcx,1),%rdx
    9fd5:	48 85 c9             	test   %rcx,%rcx
    9fd8:	74 49                	je     a023 <fwp_main_thread+0xec3>
    9fda:	48 c1 e0 04          	shl    $0x4,%rax
    9fde:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    9fe3:	49 89 d5             	mov    %rdx,%r13
    9fe6:	49 8d 5e 08          	lea    0x8(%r14),%rbx
    9fea:	4d 8d 64 06 f8       	lea    -0x8(%r14,%rax,1),%r12
    9fef:	90                   	nop
    9ff0:	f2 0f 10 03          	movsd  (%rbx),%xmm0
    9ff4:	48 8b 73 18          	mov    0x18(%rbx),%rsi
    9ff8:	48 83 c3 10          	add    $0x10,%rbx
    9ffc:	48 8b 7b f8          	mov    -0x8(%rbx),%rdi
    a000:	f2 0f 10 0b          	movsd  (%rbx),%xmm1
    a004:	e8 97 c1 ff ff       	call   61a0 <w120>
    a009:	66 48 0f 6e e8       	movq   %rax,%xmm5
    a00e:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    a012:	0f 11 43 f0          	movups %xmm0,-0x10(%rbx)
    a016:	49 39 dc             	cmp    %rbx,%r12
    a019:	75 d5                	jne    9ff0 <fwp_main_thread+0xe90>
    a01b:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
    a020:	4c 89 ea             	mov    %r13,%rdx
    a023:	49 89 16             	mov    %rdx,(%r14)
    a026:	4c 89 f7             	mov    %r14,%rdi
    a029:	4c 63 eb             	movslq %ebx,%r13
    a02c:	e8 2f c3 ff ff       	call   6360 <w176.constprop.0>
    a031:	4c 89 f7             	mov    %r14,%rdi
    a034:	49 89 c4             	mov    %rax,%r12
    a037:	e8 94 d9 ff ff       	call   79d0 <fwp_drop10>
    a03c:	4c 89 ef             	mov    %r13,%rdi
    a03f:	e8 3c a4 ff ff       	call   4480 <fwp_tape_of>
    a044:	48 89 c6             	mov    %rax,%rsi
    a047:	48 8b 40 60          	mov    0x60(%rax),%rax
    a04b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a050:	48 85 c0             	test   %rax,%rax
    a053:	0f 85 d3 12 00 00    	jne    b32c <fwp_main_thread+0x21cc>
    a059:	48 89 f7             	mov    %rsi,%rdi
    a05c:	e8 9f 9b ff ff       	call   3c00 <fwp_tape_unlink_scope>
    a061:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    a065:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    a06a:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    a071:	4c 8b 46 08          	mov    0x8(%rsi),%r8
    a075:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    a079:	66 49 0f 6e fe       	movq   %r14,%xmm7
    a07e:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    a083:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    a088:	48 8b 4e 40          	mov    0x40(%rsi),%rcx
    a08c:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    a090:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    a096:	77 18                	ja     a0b0 <fwp_main_thread+0xf50>
    a098:	0f b7 c3             	movzwl %bx,%eax
    a09b:	83 e8 01             	sub    $0x1,%eax
    a09e:	48 98                	cltq
    a0a0:	48 3b 05 31 60 01 00 	cmp    0x16031(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    a0a7:	7d 07                	jge    a0b0 <fwp_main_thread+0xf50>
    a0a9:	48 89 05 28 60 01 00 	mov    %rax,0x16028(%rip)        # 200d8 <fwp_tape_next_slot>
    a0b0:	48 8b 05 41 83 01 00 	mov    0x18341(%rip),%rax        # 223f8 <fwp_cleanups>
    a0b7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a0bb:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    a0c2:	00 
    a0c3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    a0ca:	00 
    a0cb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    a0d2:	00 
    a0d3:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    a0d7:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    a0db:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    a0df:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
    a0e6:	00 
    a0e7:	48 8d 05 42 ad ff ff 	lea    -0x52be(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    a0ee:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    a0f5:	00 
    a0f6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
    a0fb:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
    a102:	00 
    a103:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
    a10a:	00 
    a10b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    a110:	0f 29 9c 24 e0 00 00 	movaps %xmm3,0xe0(%rsp)
    a117:	00 
    a118:	48 89 05 d9 82 01 00 	mov    %rax,0x182d9(%rip)        # 223f8 <fwp_cleanups>
    a11f:	0f 29 94 24 f0 00 00 	movaps %xmm2,0xf0(%rsp)
    a126:	00 
    a127:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
    a12e:	00 
    a12f:	4d 85 e4             	test   %r12,%r12
    a132:	0f 88 d8 0c 00 00    	js     ae10 <fwp_main_thread+0x1cb0>
    a138:	4c 89 e0             	mov    %r12,%rax
    a13b:	48 c1 f8 20          	sar    $0x20,%rax
    a13f:	49 39 c5             	cmp    %rax,%r13
    a142:	0f 85 de 10 00 00    	jne    b226 <fwp_main_thread+0x20c6>
    a148:	45 89 e5             	mov    %r12d,%r13d
    a14b:	4c 89 eb             	mov    %r13,%rbx
    a14e:	4c 39 ea             	cmp    %r13,%rdx
    a151:	0f 8e c3 10 00 00    	jle    b21a <fwp_main_thread+0x20ba>
    a157:	4d 39 e8             	cmp    %r13,%r8
    a15a:	0f 8e 80 0b 00 00    	jle    ace0 <fwp_main_thread+0x1b80>
    a160:	4d 39 f0             	cmp    %r14,%r8
    a163:	0f 8f a7 0b 00 00    	jg     ad10 <fwp_main_thread+0x1bb0>
    a169:	48 85 c9             	test   %rcx,%rcx
    a16c:	0f 84 2b 11 00 00    	je     b29d <fwp_main_thread+0x213d>
    a172:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    a177:	49 8d 58 ff          	lea    -0x1(%r8),%rbx
    a17b:	31 f6                	xor    %esi,%esi
    a17d:	48 89 cf             	mov    %rcx,%rdi
    a180:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    a185:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
    a18c:	00 
    a18d:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    a192:	e8 29 93 ff ff       	call   34c0 <memset@plt>
    a197:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a19c:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    a1a2:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    a1a8:	48 89 c1             	mov    %rax,%rcx
    a1ab:	f2 0f 10 05 f5 28 00 	movsd  0x28f5(%rip),%xmm0        # caa8 <msg.4+0x28>
    a1b2:	00 
    a1b3:	f2 42 0f 58 04 e9    	addsd  (%rcx,%r13,8),%xmm0
    a1b9:	f2 42 0f 11 04 e9    	movsd  %xmm0,(%rcx,%r13,8)
    a1bf:	4c 39 c3             	cmp    %r8,%rbx
    a1c2:	0f 8c 8a 00 00 00    	jl     a252 <fwp_main_thread+0x10f2>
    a1c8:	0f 12 fb             	movhlps %xmm3,%xmm7
    a1cb:	66 48 0f 7e de       	movq   %xmm3,%rsi
    a1d0:	0f 12 da             	movhlps %xmm2,%xmm3
    a1d3:	4c 29 c3             	sub    %r8,%rbx
    a1d6:	66 49 0f 7e da       	movq   %xmm3,%r10
    a1db:	66 48 0f 7e ff       	movq   %xmm7,%rdi
    a1e0:	66 49 0f 7e d1       	movq   %xmm2,%r9
    a1e5:	4e 8d 1c c1          	lea    (%rcx,%r8,8),%r11
    a1e9:	49 8d 14 da          	lea    (%r10,%rbx,8),%rdx
    a1ed:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a1f1:	48 29 fe             	sub    %rdi,%rsi
    a1f4:	48 8d 04 9f          	lea    (%rdi,%rbx,4),%rax
    a1f8:	4d 29 d3             	sub    %r10,%r11
    a1fb:	4d 29 d1             	sub    %r10,%r9
    a1fe:	eb 04                	jmp    a204 <fwp_main_thread+0x10a4>
    a200:	48 83 e8 04          	sub    $0x4,%rax
    a204:	f2 41 0f 10 04 13    	movsd  (%r11,%rdx,1),%xmm0
    a20a:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    a20e:	7a 02                	jp     a212 <fwp_main_thread+0x10b2>
    a210:	74 37                	je     a249 <fwp_main_thread+0x10e9>
    a212:	4c 63 14 06          	movslq (%rsi,%rax,1),%r10
    a216:	45 85 d2             	test   %r10d,%r10d
    a219:	78 16                	js     a231 <fwp_main_thread+0x10d1>
    a21b:	f2 41 0f 10 0c 11    	movsd  (%r9,%rdx,1),%xmm1
    a221:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    a225:	f2 42 0f 58 0c d1    	addsd  (%rcx,%r10,8),%xmm1
    a22b:	f2 42 0f 11 0c d1    	movsd  %xmm1,(%rcx,%r10,8)
    a231:	4c 63 10             	movslq (%rax),%r10
    a234:	45 85 d2             	test   %r10d,%r10d
    a237:	78 10                	js     a249 <fwp_main_thread+0x10e9>
    a239:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    a23d:	f2 42 0f 58 04 d1    	addsd  (%rcx,%r10,8),%xmm0
    a243:	f2 42 0f 11 04 d1    	movsd  %xmm0,(%rcx,%r10,8)
    a249:	48 83 ea 08          	sub    $0x8,%rdx
    a24d:	48 39 f8             	cmp    %rdi,%rax
    a250:	75 ae                	jne    a200 <fwp_main_thread+0x10a0>
    a252:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a259:	ff ff 1f 
    a25c:	4c 39 c0             	cmp    %r8,%rax
    a25f:	0f 82 23 10 00 00    	jb     b288 <fwp_main_thread+0x2128>
    a265:	4a 8d 3c c5 08 00 00 	lea    0x8(,%r8,8),%rdi
    a26c:	00 
    a26d:	be 02 00 00 00       	mov    $0x2,%esi
    a272:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
    a277:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    a27c:	e8 cf b7 ff ff       	call   5a50 <fwp_heap_alloc>
    a281:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    a286:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    a28b:	48 89 c3             	mov    %rax,%rbx
    a28e:	4c 89 00             	mov    %r8,(%rax)
    a291:	31 c0                	xor    %eax,%eax
    a293:	4d 85 c0             	test   %r8,%r8
    a296:	74 1a                	je     a2b2 <fwp_main_thread+0x1152>
    a298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a29f:	00 
    a2a0:	48 8b 14 c1          	mov    (%rcx,%rax,8),%rdx
    a2a4:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    a2a9:	48 83 c0 01          	add    $0x1,%rax
    a2ad:	49 39 c0             	cmp    %rax,%r8
    a2b0:	75 ee                	jne    a2a0 <fwp_main_thread+0x1140>
    a2b2:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
    a2b9:	00 
    a2ba:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a2bf:	4c 89 25 32 81 01 00 	mov    %r12,0x18132(%rip)        # 223f8 <fwp_cleanups>
    a2c6:	e8 65 ab ff ff       	call   4e30 <fwp_tape_buffers_release>
    a2cb:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a2d2:	48 89 d8             	mov    %rbx,%rax
    a2d5:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a2dc:	48 c1 e2 10          	shl    $0x10,%rdx
    a2e0:	48 39 d0             	cmp    %rdx,%rax
    a2e3:	73 59                	jae    a33e <fwp_main_thread+0x11de>
    a2e5:	48 89 c2             	mov    %rax,%rdx
    a2e8:	48 c1 ea 10          	shr    $0x10,%rdx
    a2ec:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a2f0:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a2f7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a2fb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a2ff:	4d 85 ed             	test   %r13,%r13
    a302:	74 3a                	je     a33e <fwp_main_thread+0x11de>
    a304:	0f b6 0a             	movzbl (%rdx),%ecx
    a307:	80 f9 02             	cmp    $0x2,%cl
    a30a:	0f 84 30 0b 00 00    	je     ae40 <fwp_main_thread+0x1ce0>
    a310:	80 f9 01             	cmp    $0x1,%cl
    a313:	75 29                	jne    a33e <fwp_main_thread+0x11de>
    a315:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a318:	0f b7 c0             	movzwl %ax,%eax
    a31b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a31e:	48 0f af c1          	imul   %rcx,%rax
    a322:	48 c1 e8 20          	shr    $0x20,%rax
    a326:	48 39 d0             	cmp    %rdx,%rax
    a329:	73 13                	jae    a33e <fwp_main_thread+0x11de>
    a32b:	49 01 c5             	add    %rax,%r13
    a32e:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a333:	0f 84 1b 0b 00 00    	je     ae54 <fwp_main_thread+0x1cf4>
    a339:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a33e:	4c 3b 64 24 50       	cmp    0x50(%rsp),%r12
    a343:	0f 85 02 94 ff ff    	jne    374b <fwp_main_thread.cold>
    a349:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
    a350:	00 
    a351:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
    a356:	48 89 05 9b 80 01 00 	mov    %rax,0x1809b(%rip)        # 223f8 <fwp_cleanups>
    a35d:	e8 3e c7 ff ff       	call   6aa0 <fwp_tape_scope_release>
    a362:	48 8b 03             	mov    (%rbx),%rax
    a365:	49 89 c5             	mov    %rax,%r13
    a368:	49 0f ba f5 3f       	btr    $0x3f,%r13
    a36d:	48 85 c0             	test   %rax,%rax
    a370:	0f 88 ea 07 00 00    	js     ab60 <fwp_main_thread+0x1a00>
    a376:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a37d:	48 89 d8             	mov    %rbx,%rax
    a380:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a387:	48 c1 e2 10          	shl    $0x10,%rdx
    a38b:	48 39 d0             	cmp    %rdx,%rax
    a38e:	0f 83 cc 07 00 00    	jae    ab60 <fwp_main_thread+0x1a00>
    a394:	48 89 c2             	mov    %rax,%rdx
    a397:	48 c1 ea 10          	shr    $0x10,%rdx
    a39b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a39f:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a3a6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3aa:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    a3ae:	48 85 c9             	test   %rcx,%rcx
    a3b1:	0f 84 a9 07 00 00    	je     ab60 <fwp_main_thread+0x1a00>
    a3b7:	0f b6 32             	movzbl (%rdx),%esi
    a3ba:	40 80 fe 02          	cmp    $0x2,%sil
    a3be:	0f 84 8c 07 00 00    	je     ab50 <fwp_main_thread+0x19f0>
    a3c4:	40 80 fe 01          	cmp    $0x1,%sil
    a3c8:	0f 85 92 07 00 00    	jne    ab60 <fwp_main_thread+0x1a00>
    a3ce:	8b 72 18             	mov    0x18(%rdx),%esi
    a3d1:	0f b7 c0             	movzwl %ax,%eax
    a3d4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a3d7:	48 0f af c6          	imul   %rsi,%rax
    a3db:	48 c1 e8 20          	shr    $0x20,%rax
    a3df:	48 39 d0             	cmp    %rdx,%rax
    a3e2:	0f 83 78 07 00 00    	jae    ab60 <fwp_main_thread+0x1a00>
    a3e8:	48 01 c1             	add    %rax,%rcx
    a3eb:	80 39 01             	cmpb   $0x1,(%rcx)
    a3ee:	0f 85 6c 07 00 00    	jne    ab60 <fwp_main_thread+0x1a00>
    a3f4:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
    a3f9:	48 89 da             	mov    %rbx,%rdx
    a3fc:	31 ff                	xor    %edi,%edi
    a3fe:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a403:	48 8d 48 08          	lea    0x8(%rax),%rcx
    a407:	31 c0                	xor    %eax,%eax
    a409:	4d 85 ed             	test   %r13,%r13
    a40c:	75 2b                	jne    a439 <fwp_main_thread+0x12d9>
    a40e:	eb 48                	jmp    a458 <fwp_main_thread+0x12f8>
    a410:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a414:	0f 88 5d 0e 00 00    	js     b277 <fwp_main_thread+0x2117>
    a41a:	f2 0f 10 05 9e 26 00 	movsd  0x269e(%rip),%xmm0        # cac0 <msg.4+0x40>
    a421:	00 
    a422:	f2 0f 59 04 c6       	mulsd  (%rsi,%rax,8),%xmm0
    a427:	48 83 c0 01          	add    $0x1,%rax
    a42b:	48 83 c1 08          	add    $0x8,%rcx
    a42f:	f2 0f 11 41 f8       	movsd  %xmm0,-0x8(%rcx)
    a434:	49 39 c5             	cmp    %rax,%r13
    a437:	74 1f                	je     a458 <fwp_main_thread+0x12f8>
    a439:	48 8d 73 08          	lea    0x8(%rbx),%rsi
    a43d:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    a441:	79 cd                	jns    a410 <fwp_main_thread+0x12b0>
    a443:	48 8b 73 10          	mov    0x10(%rbx),%rsi
    a447:	eb c7                	jmp    a410 <fwp_main_thread+0x12b0>
    a449:	e8 e2 a6 ff ff       	call   4b30 <fwp_heap_init>
    a44e:	e9 45 ed ff ff       	jmp    9198 <fwp_main_thread+0x38>
    a453:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a458:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a45d:	e8 6e d5 ff ff       	call   79d0 <fwp_drop10>
    a462:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    a467:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a46c:	0f 1f 40 00          	nopl   0x0(%rax)
    a470:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    a474:	49 83 c7 01          	add    $0x1,%r15
    a478:	48 85 db             	test   %rbx,%rbx
    a47b:	75 f3                	jne    a470 <fwp_main_thread+0x1310>
    a47d:	4c 8b 32             	mov    (%rdx),%r14
    a480:	4d 85 f6             	test   %r14,%r14
    a483:	0f 88 f7 00 00 00    	js     a580 <fwp_main_thread+0x1420>
    a489:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    a490:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a495:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a49c:	48 c1 e1 10          	shl    $0x10,%rcx
    a4a0:	48 39 c8             	cmp    %rcx,%rax
    a4a3:	0f 83 d7 00 00 00    	jae    a580 <fwp_main_thread+0x1420>
    a4a9:	48 89 c1             	mov    %rax,%rcx
    a4ac:	48 c1 e9 10          	shr    $0x10,%rcx
    a4b0:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    a4b4:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    a4bb:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    a4bf:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a4c3:	48 85 f6             	test   %rsi,%rsi
    a4c6:	0f 84 b4 00 00 00    	je     a580 <fwp_main_thread+0x1420>
    a4cc:	0f b6 39             	movzbl (%rcx),%edi
    a4cf:	40 80 ff 02          	cmp    $0x2,%dil
    a4d3:	0f 84 97 00 00 00    	je     a570 <fwp_main_thread+0x1410>
    a4d9:	40 80 ff 01          	cmp    $0x1,%dil
    a4dd:	0f 85 9d 00 00 00    	jne    a580 <fwp_main_thread+0x1420>
    a4e3:	8b 79 18             	mov    0x18(%rcx),%edi
    a4e6:	0f b7 c0             	movzwl %ax,%eax
    a4e9:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a4ec:	48 0f af c7          	imul   %rdi,%rax
    a4f0:	48 c1 e8 20          	shr    $0x20,%rax
    a4f4:	48 39 c8             	cmp    %rcx,%rax
    a4f7:	0f 83 83 00 00 00    	jae    a580 <fwp_main_thread+0x1420>
    a4fd:	48 01 c6             	add    %rax,%rsi
    a500:	80 3e 01             	cmpb   $0x1,(%rsi)
    a503:	75 7b                	jne    a580 <fwp_main_thread+0x1420>
    a505:	4d 39 f7             	cmp    %r14,%r15
    a508:	4d 0f 46 f7          	cmovbe %r15,%r14
    a50c:	4d 85 f6             	test   %r14,%r14
    a50f:	0f 84 b9 0a 00 00    	je     afce <fwp_main_thread+0x1e6e>
    a515:	4c 8d 62 08          	lea    0x8(%rdx),%r12
    a519:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a51f:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    a524:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    a529:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
    a530:	00 
    a531:	31 c0                	xor    %eax,%eax
    a533:	49 8d 79 08          	lea    0x8(%r9),%rdi
    a537:	eb 28                	jmp    a561 <fwp_main_thread+0x1401>
    a539:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a540:	f2 0f 10 46 08       	movsd  0x8(%rsi),%xmm0
    a545:	f2 0f 5c 04 01       	subsd  (%rcx,%rax,1),%xmm0
    a54a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    a550:	48 83 c0 08          	add    $0x8,%rax
    a554:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    a558:	49 39 c0             	cmp    %rax,%r8
    a55b:	0f 84 b7 00 00 00    	je     a618 <fwp_main_thread+0x14b8>
    a561:	48 89 f9             	mov    %rdi,%rcx
    a564:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    a568:	79 d6                	jns    a540 <fwp_main_thread+0x13e0>
    a56a:	49 8b 49 10          	mov    0x10(%r9),%rcx
    a56e:	eb d0                	jmp    a540 <fwp_main_thread+0x13e0>
    a570:	66 85 c0             	test   %ax,%ax
    a573:	0f 84 87 ff ff ff    	je     a500 <fwp_main_thread+0x13a0>
    a579:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a580:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a585:	45 31 ed             	xor    %r13d,%r13d
    a588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a58f:	00 
    a590:	48 8b 40 10          	mov    0x10(%rax),%rax
    a594:	4c 89 e9             	mov    %r13,%rcx
    a597:	49 83 c5 01          	add    $0x1,%r13
    a59b:	48 85 c0             	test   %rax,%rax
    a59e:	75 f0                	jne    a590 <fwp_main_thread+0x1430>
    a5a0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    a5a7:	ff ff 1f 
    a5aa:	4c 39 e8             	cmp    %r13,%rax
    a5ad:	0f 82 31 0d 00 00    	jb     b2e4 <fwp_main_thread+0x2184>
    a5b3:	be 02 00 00 00       	mov    $0x2,%esi
    a5b8:	48 8d 3c cd 10 00 00 	lea    0x10(,%rcx,8),%rdi
    a5bf:	00 
    a5c0:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    a5c5:	e8 86 b4 ff ff       	call   5a50 <fwp_heap_alloc>
    a5ca:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    a5cf:	49 89 c4             	mov    %rax,%r12
    a5d2:	48 89 c6             	mov    %rax,%rsi
    a5d5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    a5da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5e0:	48 8b 48 08          	mov    0x8(%rax),%rcx
    a5e4:	48 83 c6 08          	add    $0x8,%rsi
    a5e8:	48 89 4e f8          	mov    %rcx,-0x8(%rsi)
    a5ec:	48 8b 40 10          	mov    0x10(%rax),%rax
    a5f0:	48 85 c0             	test   %rax,%rax
    a5f3:	75 eb                	jne    a5e0 <fwp_main_thread+0x1480>
    a5f5:	49 0f ba f6 3f       	btr    $0x3f,%r14
    a5fa:	4d 39 ee             	cmp    %r13,%r14
    a5fd:	4d 0f 47 f5          	cmova  %r13,%r14
    a601:	4d 85 f6             	test   %r14,%r14
    a604:	0f 84 bf 09 00 00    	je     afc9 <fwp_main_thread+0x1e69>
    a60a:	45 31 ed             	xor    %r13d,%r13d
    a60d:	e9 0d ff ff ff       	jmp    a51f <fwp_main_thread+0x13bf>
    a612:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a618:	48 8b bd d8 13 00 00 	mov    0x13d8(%rbp),%rdi
    a61f:	4c 8b 85 b0 13 00 00 	mov    0x13b0(%rbp),%r8
    a626:	45 31 ff             	xor    %r15d,%r15d
    a629:	4c 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%r9
    a630:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    a635:	48 c1 e7 10          	shl    $0x10,%rdi
    a639:	eb 1b                	jmp    a656 <fwp_main_thread+0x14f6>
    a63b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a640:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    a644:	49 83 c7 01          	add    $0x1,%r15
    a648:	48 85 d2             	test   %rdx,%rdx
    a64b:	74 5f                	je     a6ac <fwp_main_thread+0x154c>
    a64d:	4d 39 f7             	cmp    %r14,%r15
    a650:	0f 83 0a 04 00 00    	jae    aa60 <fwp_main_thread+0x1900>
    a656:	48 89 d0             	mov    %rdx,%rax
    a659:	4c 29 c0             	sub    %r8,%rax
    a65c:	48 39 f8             	cmp    %rdi,%rax
    a65f:	73 4b                	jae    a6ac <fwp_main_thread+0x154c>
    a661:	48 89 c1             	mov    %rax,%rcx
    a664:	48 c1 e9 10          	shr    $0x10,%rcx
    a668:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    a66c:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
    a670:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    a674:	48 85 f6             	test   %rsi,%rsi
    a677:	74 33                	je     a6ac <fwp_main_thread+0x154c>
    a679:	44 0f b6 11          	movzbl (%rcx),%r10d
    a67d:	41 80 fa 02          	cmp    $0x2,%r10b
    a681:	0f 84 b9 03 00 00    	je     aa40 <fwp_main_thread+0x18e0>
    a687:	41 80 fa 01          	cmp    $0x1,%r10b
    a68b:	75 1f                	jne    a6ac <fwp_main_thread+0x154c>
    a68d:	44 8b 51 18          	mov    0x18(%rcx),%r10d
    a691:	0f b7 c0             	movzwl %ax,%eax
    a694:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a697:	49 0f af c2          	imul   %r10,%rax
    a69b:	48 c1 e8 20          	shr    $0x20,%rax
    a69f:	48 39 c8             	cmp    %rcx,%rax
    a6a2:	73 08                	jae    a6ac <fwp_main_thread+0x154c>
    a6a4:	48 01 c6             	add    %rax,%rsi
    a6a7:	80 3e 01             	cmpb   $0x1,(%rsi)
    a6aa:	74 94                	je     a640 <fwp_main_thread+0x14e0>
    a6ac:	4d 39 f7             	cmp    %r14,%r15
    a6af:	72 43                	jb     a6f4 <fwp_main_thread+0x1594>
    a6b1:	e9 aa 03 00 00       	jmp    aa60 <fwp_main_thread+0x1900>
    a6b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a6bd:	00 00 00 
    a6c0:	40 80 fe 01          	cmp    $0x1,%sil
    a6c4:	75 25                	jne    a6eb <fwp_main_thread+0x158b>
    a6c6:	8b 71 18             	mov    0x18(%rcx),%esi
    a6c9:	0f b7 c0             	movzwl %ax,%eax
    a6cc:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    a6cf:	48 0f af c6          	imul   %rsi,%rax
    a6d3:	48 c1 e8 20          	shr    $0x20,%rax
    a6d7:	48 39 c8             	cmp    %rcx,%rax
    a6da:	73 0f                	jae    a6eb <fwp_main_thread+0x158b>
    a6dc:	48 01 c2             	add    %rax,%rdx
    a6df:	80 3a ff             	cmpb   $0xff,(%rdx)
    a6e2:	0f 84 28 05 00 00    	je     ac10 <fwp_main_thread+0x1ab0>
    a6e8:	c6 02 01             	movb   $0x1,(%rdx)
    a6eb:	4d 39 fe             	cmp    %r15,%r14
    a6ee:	0f 84 8c 00 00 00    	je     a780 <fwp_main_thread+0x1620>
    a6f4:	49 83 ee 01          	sub    $0x1,%r14
    a6f8:	66 48 0f 6e f3       	movq   %rbx,%xmm6
    a6fd:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
    a702:	bf 01 00 00 00       	mov    $0x1,%edi
    a707:	f3 43 0f 7e 04 f4    	movq   (%r12,%r14,8),%xmm0
    a70d:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    a711:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
    a718:	00 
    a719:	e8 52 b4 ff ff       	call   5b70 <fwp_data.part.0.constprop.0>
    a71e:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a725:	48 89 c3             	mov    %rax,%rbx
    a728:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a72f:	48 c1 e2 10          	shl    $0x10,%rdx
    a733:	48 39 d0             	cmp    %rdx,%rax
    a736:	73 b3                	jae    a6eb <fwp_main_thread+0x158b>
    a738:	48 89 c2             	mov    %rax,%rdx
    a73b:	48 c1 ea 10          	shr    $0x10,%rdx
    a73f:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a743:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a74a:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    a74e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    a752:	48 85 d2             	test   %rdx,%rdx
    a755:	74 94                	je     a6eb <fwp_main_thread+0x158b>
    a757:	0f b6 31             	movzbl (%rcx),%esi
    a75a:	40 80 fe 02          	cmp    $0x2,%sil
    a75e:	0f 85 5c ff ff ff    	jne    a6c0 <fwp_main_thread+0x1560>
    a764:	66 85 c0             	test   %ax,%ax
    a767:	0f 84 72 ff ff ff    	je     a6df <fwp_main_thread+0x157f>
    a76d:	4d 39 fe             	cmp    %r15,%r14
    a770:	75 82                	jne    a6f4 <fwp_main_thread+0x1594>
    a772:	0f 1f 00             	nopl   (%rax)
    a775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a77c:	00 00 00 00 
    a780:	4d 85 f6             	test   %r14,%r14
    a783:	0f 85 d7 02 00 00    	jne    aa60 <fwp_main_thread+0x1900>
    a789:	45 85 ed             	test   %r13d,%r13d
    a78c:	4c 0f 45 64 24 28    	cmovne 0x28(%rsp),%r12
    a792:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    a797:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    a79c:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
    a7a1:	e8 aa ad ff ff       	call   5550 <fwp_mem_free>
    a7a6:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    a7ab:	e8 20 d2 ff ff       	call   79d0 <fwp_drop10>
    a7b0:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a7b7:	4c 89 f0             	mov    %r14,%rax
    a7ba:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a7c1:	48 c1 e2 10          	shl    $0x10,%rdx
    a7c5:	48 39 d0             	cmp    %rdx,%rax
    a7c8:	73 76                	jae    a840 <fwp_main_thread+0x16e0>
    a7ca:	48 89 c2             	mov    %rax,%rdx
    a7cd:	48 8b b5 f8 13 00 00 	mov    0x13f8(%rbp),%rsi
    a7d4:	48 c1 ea 10          	shr    $0x10,%rdx
    a7d8:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    a7dc:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    a7e0:	4c 8b 62 20          	mov    0x20(%rdx),%r12
    a7e4:	4d 85 e4             	test   %r12,%r12
    a7e7:	74 57                	je     a840 <fwp_main_thread+0x16e0>
    a7e9:	0f b6 0a             	movzbl (%rdx),%ecx
    a7ec:	80 f9 02             	cmp    $0x2,%cl
    a7ef:	0f 84 f3 05 00 00    	je     ade8 <fwp_main_thread+0x1c88>
    a7f5:	80 f9 01             	cmp    $0x1,%cl
    a7f8:	75 46                	jne    a840 <fwp_main_thread+0x16e0>
    a7fa:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a7fd:	0f b7 c0             	movzwl %ax,%eax
    a800:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a803:	48 0f af c1          	imul   %rcx,%rax
    a807:	48 c1 e8 20          	shr    $0x20,%rax
    a80b:	48 39 d0             	cmp    %rdx,%rax
    a80e:	73 30                	jae    a840 <fwp_main_thread+0x16e0>
    a810:	49 01 c4             	add    %rax,%r12
    a813:	41 0f b6 04 24       	movzbl (%r12),%eax
    a818:	84 c0                	test   %al,%al
    a81a:	74 24                	je     a840 <fwp_main_thread+0x16e0>
    a81c:	3c 01                	cmp    $0x1,%al
    a81e:	0f 84 44 06 00 00    	je     ae68 <fwp_main_thread+0x1d08>
    a824:	3c ff                	cmp    $0xff,%al
    a826:	0f 84 47 08 00 00    	je     b073 <fwp_main_thread+0x1f13>
    a82c:	83 e8 01             	sub    $0x1,%eax
    a82f:	41 88 04 24          	mov    %al,(%r12)
    a833:	66 90                	xchg   %ax,%ax
    a835:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a83c:	00 00 00 00 
    a840:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a845:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a849:	b9 01 00 00 00       	mov    $0x1,%ecx
    a84e:	48 89 de             	mov    %rbx,%rsi
    a851:	48 8d 15 48 53 00 00 	lea    0x5348(%rip),%rdx        # fba0 <d0>
    a858:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
    a85f:	00 
    a860:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
    a867:	00 00 00 00 00 
    a86c:	e8 af d8 ff ff       	call   8120 <fwp_write>
    a871:	4c 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%r14
    a878:	00 
    a879:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
    a880:	00 
    a881:	48 8d 05 a6 17 00 00 	lea    0x17a6(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    a888:	4d 85 f6             	test   %r14,%r14
    a88b:	4c 0f 44 f0          	cmove  %rax,%r14
    a88f:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    a893:	0f 87 9f 0a 00 00    	ja     b338 <fwp_main_thread+0x21d8>
    a899:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    a89d:	be 01 00 00 00       	mov    $0x1,%esi
    a8a2:	e8 a9 b1 ff ff       	call   5a50 <fwp_heap_alloc>
    a8a7:	4c 89 fa             	mov    %r15,%rdx
    a8aa:	4c 89 f6             	mov    %r14,%rsi
    a8ad:	4c 89 38             	mov    %r15,(%rax)
    a8b0:	4c 8d 68 08          	lea    0x8(%rax),%r13
    a8b4:	49 89 c4             	mov    %rax,%r12
    a8b7:	4c 89 ef             	mov    %r13,%rdi
    a8ba:	e8 e1 8c ff ff       	call   35a0 <memcpy@plt>
    a8bf:	43 c6 44 3c 08 00    	movb   $0x0,0x8(%r12,%r15,1)
    a8c5:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
    a8cc:	00 
    a8cd:	e8 ee 8a ff ff       	call   33c0 <free@plt>
    a8d2:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a8d9:	4c 89 e0             	mov    %r12,%rax
    a8dc:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a8e3:	48 c1 e2 10          	shl    $0x10,%rdx
    a8e7:	48 39 d0             	cmp    %rdx,%rax
    a8ea:	73 57                	jae    a943 <fwp_main_thread+0x17e3>
    a8ec:	48 89 c2             	mov    %rax,%rdx
    a8ef:	48 c1 ea 10          	shr    $0x10,%rdx
    a8f3:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a8f7:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a8fe:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a902:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a906:	4d 85 f6             	test   %r14,%r14
    a909:	74 38                	je     a943 <fwp_main_thread+0x17e3>
    a90b:	0f b6 0a             	movzbl (%rdx),%ecx
    a90e:	80 f9 02             	cmp    $0x2,%cl
    a911:	0f 84 69 06 00 00    	je     af80 <fwp_main_thread+0x1e20>
    a917:	80 f9 01             	cmp    $0x1,%cl
    a91a:	75 27                	jne    a943 <fwp_main_thread+0x17e3>
    a91c:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a91f:	0f b7 c0             	movzwl %ax,%eax
    a922:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a925:	48 0f af c1          	imul   %rcx,%rax
    a929:	48 c1 e8 20          	shr    $0x20,%rax
    a92d:	48 39 d0             	cmp    %rdx,%rax
    a930:	73 11                	jae    a943 <fwp_main_thread+0x17e3>
    a932:	49 01 c6             	add    %rax,%r14
    a935:	41 80 3e ff          	cmpb   $0xff,(%r14)
    a939:	0f 84 54 06 00 00    	je     af93 <fwp_main_thread+0x1e33>
    a93f:	41 c6 06 01          	movb   $0x1,(%r14)
    a943:	48 89 df             	mov    %rbx,%rdi
    a946:	e8 95 cc ff ff       	call   75e0 <fwp_drop0>
    a94b:	49 8b 14 24          	mov    (%r12),%rdx
    a94f:	be 01 00 00 00       	mov    $0x1,%esi
    a954:	4c 89 ef             	mov    %r13,%rdi
    a957:	48 8b 0d 62 7a 01 00 	mov    0x17a62(%rip),%rcx        # 223c0 <fwp_prog_out>
    a95e:	e8 1d 8d ff ff       	call   3680 <fwrite@plt>
    a963:	48 8b 35 56 7a 01 00 	mov    0x17a56(%rip),%rsi        # 223c0 <fwp_prog_out>
    a96a:	bf 0a 00 00 00       	mov    $0xa,%edi
    a96f:	e8 6c 8b ff ff       	call   34e0 <fputc@plt>
    a974:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    a97b:	4c 89 e0             	mov    %r12,%rax
    a97e:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    a985:	48 c1 e2 10          	shl    $0x10,%rdx
    a989:	48 39 d0             	cmp    %rdx,%rax
    a98c:	73 72                	jae    aa00 <fwp_main_thread+0x18a0>
    a98e:	48 89 c2             	mov    %rax,%rdx
    a991:	48 c1 ea 10          	shr    $0x10,%rdx
    a995:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a999:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    a9a0:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a9a4:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a9a8:	48 85 db             	test   %rbx,%rbx
    a9ab:	74 53                	je     aa00 <fwp_main_thread+0x18a0>
    a9ad:	0f b6 0a             	movzbl (%rdx),%ecx
    a9b0:	80 f9 02             	cmp    $0x2,%cl
    a9b3:	0f 84 e7 05 00 00    	je     afa0 <fwp_main_thread+0x1e40>
    a9b9:	80 f9 01             	cmp    $0x1,%cl
    a9bc:	75 42                	jne    aa00 <fwp_main_thread+0x18a0>
    a9be:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a9c1:	0f b7 c0             	movzwl %ax,%eax
    a9c4:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a9c7:	48 0f af c1          	imul   %rcx,%rax
    a9cb:	48 c1 e8 20          	shr    $0x20,%rax
    a9cf:	48 39 d0             	cmp    %rdx,%rax
    a9d2:	73 2c                	jae    aa00 <fwp_main_thread+0x18a0>
    a9d4:	48 01 c3             	add    %rax,%rbx
    a9d7:	0f b6 03             	movzbl (%rbx),%eax
    a9da:	84 c0                	test   %al,%al
    a9dc:	74 22                	je     aa00 <fwp_main_thread+0x18a0>
    a9de:	3c 01                	cmp    $0x1,%al
    a9e0:	0f 84 d6 05 00 00    	je     afbc <fwp_main_thread+0x1e5c>
    a9e6:	3c ff                	cmp    $0xff,%al
    a9e8:	0f 84 a2 07 00 00    	je     b190 <fwp_main_thread+0x2030>
    a9ee:	83 e8 01             	sub    $0x1,%eax
    a9f1:	88 03                	mov    %al,(%rbx)
    a9f3:	66 90                	xchg   %ax,%ax
    a9f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a9fc:	00 00 00 00 
    aa00:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    aa07:	00 
    aa08:	48 8b 40 10          	mov    0x10(%rax),%rax
    aa0c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    aa13:	00 
    aa14:	48 85 c0             	test   %rax,%rax
    aa17:	0f 84 eb 05 00 00    	je     b008 <fwp_main_thread+0x1ea8>
    aa1d:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    aa24:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aa2b:	48 8b 1d c6 79 01 00 	mov    0x179c6(%rip),%rbx        # 223f8 <fwp_cleanups>
    aa32:	e9 d9 f0 ff ff       	jmp    9b10 <fwp_main_thread+0x9b0>
    aa37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aa3e:	00 00 
    aa40:	66 85 c0             	test   %ax,%ax
    aa43:	0f 84 5e fc ff ff    	je     a6a7 <fwp_main_thread+0x1547>
    aa49:	4d 39 f7             	cmp    %r14,%r15
    aa4c:	0f 82 a2 fc ff ff    	jb     a6f4 <fwp_main_thread+0x1594>
    aa52:	0f 1f 00             	nopl   (%rax)
    aa55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa5c:	00 00 00 00 
    aa60:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    aa65:	4c 89 e0             	mov    %r12,%rax
    aa68:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    aa6c:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    aa73:	00 00 
    aa75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    aa7c:	00 00 00 00 
    aa80:	48 8b 10             	mov    (%rax),%rdx
    aa83:	48 83 c0 08          	add    $0x8,%rax
    aa87:	4c 89 f6             	mov    %r14,%rsi
    aa8a:	49 89 56 08          	mov    %rdx,0x8(%r14)
    aa8e:	4d 8b 76 10          	mov    0x10(%r14),%r14
    aa92:	48 39 f8             	cmp    %rdi,%rax
    aa95:	75 e9                	jne    aa80 <fwp_main_thread+0x1920>
    aa97:	45 85 ed             	test   %r13d,%r13d
    aa9a:	4c 0f 45 64 24 28    	cmovne 0x28(%rsp),%r12
    aaa0:	48 89 5e 10          	mov    %rbx,0x10(%rsi)
    aaa4:	48 8b 5c 24 08       	mov    0x8(%rsp),%rbx
    aaa9:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    aaae:	e9 e9 fc ff ff       	jmp    a79c <fwp_main_thread+0x163c>
    aab3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    aab8:	4d 39 f5             	cmp    %r14,%r13
    aabb:	0f 84 ff f1 ff ff    	je     9cc0 <fwp_main_thread+0xb60>
    aac1:	4c 8b 3d 28 56 01 00 	mov    0x15628(%rip),%r15        # 200f0 <fwp_tapes>
    aac8:	e9 8a f2 ff ff       	jmp    9d57 <fwp_main_thread+0xbf7>
    aacd:	0f 1f 00             	nopl   (%rax)
    aad0:	48 83 3d b0 55 01 00 	cmpq   $0x0,0x155b0(%rip)        # 20088 <fwp_tape_cached_bytes>
    aad7:	00 
    aad8:	0f 84 c4 f2 ff ff    	je     9da2 <fwp_main_thread+0xc42>
    aade:	66 0f 6f 0d ba 55 01 	movdqa 0x155ba(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    aae5:	00 
    aae6:	48 c7 05 97 55 01 00 	movq   $0x0,0x15597(%rip)        # 20088 <fwp_tape_cached_bytes>
    aaed:	00 00 00 00 
    aaf1:	41 0f 11 4d 20       	movups %xmm1,0x20(%r13)
    aaf6:	48 8b 05 c3 55 01 00 	mov    0x155c3(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    aafd:	66 0f 6f 0d ab 55 01 	movdqa 0x155ab(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    ab04:	00 
    ab05:	49 89 45 40          	mov    %rax,0x40(%r13)
    ab09:	48 8b 05 b8 55 01 00 	mov    0x155b8(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    ab10:	41 0f 11 4d 30       	movups %xmm1,0x30(%r13)
    ab15:	66 0f ef c9          	pxor   %xmm1,%xmm1
    ab19:	49 89 45 18          	mov    %rax,0x18(%r13)
    ab1d:	48 8b 05 ac 55 01 00 	mov    0x155ac(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    ab24:	0f 29 0d 75 55 01 00 	movaps %xmm1,0x15575(%rip)        # 200a0 <fwp_tape_workspace>
    ab2b:	49 89 45 48          	mov    %rax,0x48(%r13)
    ab2f:	0f 29 0d 7a 55 01 00 	movaps %xmm1,0x1557a(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    ab36:	48 c7 05 8f 55 01 00 	movq   $0x0,0x1558f(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    ab3d:	00 00 00 00 
    ab41:	0f 29 0d 78 55 01 00 	movaps %xmm1,0x15578(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    ab48:	e9 55 f2 ff ff       	jmp    9da2 <fwp_main_thread+0xc42>
    ab4d:	0f 1f 00             	nopl   (%rax)
    ab50:	66 85 c0             	test   %ax,%ax
    ab53:	0f 84 92 f8 ff ff    	je     a3eb <fwp_main_thread+0x128b>
    ab59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab60:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    ab67:	ff ff 1f 
    ab6a:	4c 39 e8             	cmp    %r13,%rax
    ab6d:	0f 82 15 07 00 00    	jb     b288 <fwp_main_thread+0x2128>
    ab73:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    ab7a:	00 
    ab7b:	be 01 00 00 00       	mov    $0x1,%esi
    ab80:	e8 cb ae ff ff       	call   5a50 <fwp_heap_alloc>
    ab85:	4c 89 28             	mov    %r13,(%rax)
    ab88:	48 8b 8d d8 13 00 00 	mov    0x13d8(%rbp),%rcx
    ab8f:	48 89 c2             	mov    %rax,%rdx
    ab92:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    ab97:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ab9e:	48 c1 e1 10          	shl    $0x10,%rcx
    aba2:	48 39 c8             	cmp    %rcx,%rax
    aba5:	73 59                	jae    ac00 <fwp_main_thread+0x1aa0>
    aba7:	48 89 c1             	mov    %rax,%rcx
    abaa:	48 c1 e9 10          	shr    $0x10,%rcx
    abae:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    abb2:	48 8b 8d f8 13 00 00 	mov    0x13f8(%rbp),%rcx
    abb9:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    abbd:	4c 8b 71 20          	mov    0x20(%rcx),%r14
    abc1:	4d 85 f6             	test   %r14,%r14
    abc4:	74 3a                	je     ac00 <fwp_main_thread+0x1aa0>
    abc6:	0f b6 31             	movzbl (%rcx),%esi
    abc9:	40 80 fe 02          	cmp    $0x2,%sil
    abcd:	0f 84 35 03 00 00    	je     af08 <fwp_main_thread+0x1da8>
    abd3:	40 80 fe 01          	cmp    $0x1,%sil
    abd7:	75 27                	jne    ac00 <fwp_main_thread+0x1aa0>
    abd9:	8b 71 18             	mov    0x18(%rcx),%esi
    abdc:	0f b7 c0             	movzwl %ax,%eax
    abdf:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    abe2:	48 0f af c6          	imul   %rsi,%rax
    abe6:	48 c1 e8 20          	shr    $0x20,%rax
    abea:	48 39 c8             	cmp    %rcx,%rax
    abed:	73 11                	jae    ac00 <fwp_main_thread+0x1aa0>
    abef:	49 01 c6             	add    %rax,%r14
    abf2:	41 80 3e ff          	cmpb   $0xff,(%r14)
    abf6:	0f 84 1f 03 00 00    	je     af1b <fwp_main_thread+0x1dbb>
    abfc:	41 c6 06 01          	movb   $0x1,(%r14)
    ac00:	48 89 df             	mov    %rbx,%rdi
    ac03:	e9 f6 f7 ff ff       	jmp    a3fe <fwp_main_thread+0x129e>
    ac08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ac0f:	00 
    ac10:	48 89 d7             	mov    %rdx,%rdi
    ac13:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ac18:	e8 f3 a6 ff ff       	call   5310 <fwp_rc_forget_slot>
    ac1d:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ac22:	e9 c1 fa ff ff       	jmp    a6e8 <fwp_main_thread+0x1588>
    ac27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac2e:	00 00 
    ac30:	4d 85 e4             	test   %r12,%r12
    ac33:	0f 85 00 f3 ff ff    	jne    9f39 <fwp_main_thread+0xdd9>
    ac39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac40:	31 d2                	xor    %edx,%edx
    ac42:	e9 dc f3 ff ff       	jmp    a023 <fwp_main_thread+0xec3>
    ac47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac4e:	00 00 
    ac50:	48 c1 e2 10          	shl    $0x10,%rdx
    ac54:	be 02 00 00 00       	mov    $0x2,%esi
    ac59:	bf 08 00 00 00       	mov    $0x8,%edi
    ac5e:	48 09 d3             	or     %rdx,%rbx
    ac61:	e8 ea ad ff ff       	call   5a50 <fwp_heap_alloc>
    ac66:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    ac6d:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ac74:	49 89 c6             	mov    %rax,%r14
    ac77:	48 2b 85 b0 13 00 00 	sub    0x13b0(%rbp),%rax
    ac7e:	48 c1 e2 10          	shl    $0x10,%rdx
    ac82:	48 39 d0             	cmp    %rdx,%rax
    ac85:	73 b9                	jae    ac40 <fwp_main_thread+0x1ae0>
    ac87:	48 89 c2             	mov    %rax,%rdx
    ac8a:	48 c1 ea 10          	shr    $0x10,%rdx
    ac8e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ac92:	48 8b 95 f8 13 00 00 	mov    0x13f8(%rbp),%rdx
    ac99:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ac9d:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    aca1:	4d 85 ed             	test   %r13,%r13
    aca4:	0f 84 0a f3 ff ff    	je     9fb4 <fwp_main_thread+0xe54>
    acaa:	0f b6 0a             	movzbl (%rdx),%ecx
    acad:	45 31 e4             	xor    %r12d,%r12d
    acb0:	80 f9 02             	cmp    $0x2,%cl
    acb3:	0f 85 4d f2 ff ff    	jne    9f06 <fwp_main_thread+0xda6>
    acb9:	66 85 c0             	test   %ax,%ax
    acbc:	0f 85 72 f2 ff ff    	jne    9f34 <fwp_main_thread+0xdd4>
    acc2:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    acc7:	0f 85 62 f2 ff ff    	jne    9f2f <fwp_main_thread+0xdcf>
    accd:	4c 89 ef             	mov    %r13,%rdi
    acd0:	e8 3b a6 ff ff       	call   5310 <fwp_rc_forget_slot>
    acd5:	e9 55 f2 ff ff       	jmp    9f2f <fwp_main_thread+0xdcf>
    acda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ace0:	49 8d 55 01          	lea    0x1(%r13),%rdx
    ace4:	49 39 d6             	cmp    %rdx,%r14
    ace7:	7c 2a                	jl     ad13 <fwp_main_thread+0x1bb3>
    ace9:	48 85 c9             	test   %rcx,%rcx
    acec:	0f 84 ab 05 00 00    	je     b29d <fwp_main_thread+0x213d>
    acf2:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    acf7:	48 c1 e2 03          	shl    $0x3,%rdx
    acfb:	31 f6                	xor    %esi,%esi
    acfd:	48 89 cf             	mov    %rcx,%rdi
    ad00:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    ad05:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    ad0a:	e9 83 f4 ff ff       	jmp    a192 <fwp_main_thread+0x1032>
    ad0f:	90                   	nop
    ad10:	4c 89 c2             	mov    %r8,%rdx
    ad13:	4d 85 f6             	test   %r14,%r14
    ad16:	4c 0f 44 f2          	cmove  %rdx,%r14
    ad1a:	eb 19                	jmp    ad35 <fwp_main_thread+0x1bd5>
    ad1c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad20:	4b 8d 34 36          	lea    (%r14,%r14,1),%rsi
    ad24:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    ad2b:	48 89 d0             	mov    %rdx,%rax
    ad2e:	48 0f 4c c6          	cmovl  %rsi,%rax
    ad32:	49 89 c6             	mov    %rax,%r14
    ad35:	49 39 d6             	cmp    %rdx,%r14
    ad38:	7c e6                	jl     ad20 <fwp_main_thread+0x1bc0>
    ad3a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    ad3f:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    ad44:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
    ad49:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
    ad4e:	48 85 c9             	test   %rcx,%rcx
    ad51:	0f 84 e1 01 00 00    	je     af38 <fwp_main_thread+0x1dd8>
    ad57:	48 89 cf             	mov    %rcx,%rdi
    ad5a:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    ad61:	00 
    ad62:	e8 69 88 ff ff       	call   35d0 <realloc@plt>
    ad67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    ad6c:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    ad71:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    ad77:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    ad7d:	48 89 c1             	mov    %rax,%rcx
    ad80:	48 85 c9             	test   %rcx,%rcx
    ad83:	0f 84 0b 05 00 00    	je     b294 <fwp_main_thread+0x2134>
    ad89:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
    ad90:	00 
    ad91:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
    ad98:	00 
    ad99:	48 85 d2             	test   %rdx,%rdx
    ad9c:	0f 85 53 03 00 00    	jne    b0f5 <fwp_main_thread+0x1f95>
    ada2:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    ada9:	4d 85 e4             	test   %r12,%r12
    adac:	0f 88 0d f4 ff ff    	js     a1bf <fwp_main_thread+0x105f>
    adb2:	45 89 e5             	mov    %r12d,%r13d
    adb5:	e9 f1 f3 ff ff       	jmp    a1ab <fwp_main_thread+0x104b>
    adba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    adc0:	48 8d 3d f9 bb ff ff 	lea    -0x4407(%rip),%rdi        # 69c0 <fwp_tape_finish>
    adc7:	e8 94 07 00 00       	call   b560 <atexit>
    adcc:	85 c0                	test   %eax,%eax
    adce:	0f 85 e2 04 00 00    	jne    b2b6 <fwp_main_thread+0x2156>
    add4:	c7 05 82 52 00 00 01 	movl   $0x1,0x5282(%rip)        # 10060 <registered_finish.1>
    addb:	00 00 00 
    adde:	e9 96 ee ff ff       	jmp    9c79 <fwp_main_thread+0xb19>
    ade3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ade8:	66 85 c0             	test   %ax,%ax
    adeb:	0f 85 4f fa ff ff    	jne    a840 <fwp_main_thread+0x16e0>
    adf1:	e9 1d fa ff ff       	jmp    a813 <fwp_main_thread+0x16b3>
    adf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adfd:	00 00 00 
    ae00:	66 85 c0             	test   %ax,%ax
    ae03:	0f 85 32 ee ff ff    	jne    9c3b <fwp_main_thread+0xadb>
    ae09:	e9 19 ee ff ff       	jmp    9c27 <fwp_main_thread+0xac7>
    ae0e:	66 90                	xchg   %ax,%ax
    ae10:	4d 39 f0             	cmp    %r14,%r8
    ae13:	0f 8f f7 fe ff ff    	jg     ad10 <fwp_main_thread+0x1bb0>
    ae19:	4d 85 c0             	test   %r8,%r8
    ae1c:	74 12                	je     ae30 <fwp_main_thread+0x1cd0>
    ae1e:	48 85 c9             	test   %rcx,%rcx
    ae21:	0f 84 76 04 00 00    	je     b29d <fwp_main_thread+0x213d>
    ae27:	4d 85 c0             	test   %r8,%r8
    ae2a:	0f 85 c2 02 00 00    	jne    b0f2 <fwp_main_thread+0x1f92>
    ae30:	48 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%rbx
    ae37:	e9 83 f3 ff ff       	jmp    a1bf <fwp_main_thread+0x105f>
    ae3c:	0f 1f 40 00          	nopl   0x0(%rax)
    ae40:	66 85 c0             	test   %ax,%ax
    ae43:	0f 85 f5 f4 ff ff    	jne    a33e <fwp_main_thread+0x11de>
    ae49:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    ae4e:	0f 85 e5 f4 ff ff    	jne    a339 <fwp_main_thread+0x11d9>
    ae54:	4c 89 ef             	mov    %r13,%rdi
    ae57:	e8 b4 a4 ff ff       	call   5310 <fwp_rc_forget_slot>
    ae5c:	e9 d8 f4 ff ff       	jmp    a339 <fwp_main_thread+0x11d9>
    ae61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae68:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    ae6f:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    ae76:	4c 89 f0             	mov    %r14,%rax
    ae79:	4d 8b 66 10          	mov    0x10(%r14),%r12
    ae7d:	48 29 c8             	sub    %rcx,%rax
    ae80:	48 c1 e2 10          	shl    $0x10,%rdx
    ae84:	48 39 d0             	cmp    %rdx,%rax
    ae87:	73 65                	jae    aeee <fwp_main_thread+0x1d8e>
    ae89:	48 89 c7             	mov    %rax,%rdi
    ae8c:	48 c1 ef 10          	shr    $0x10,%rdi
    ae90:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
    ae94:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    ae98:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    ae9c:	48 85 ff             	test   %rdi,%rdi
    ae9f:	74 4d                	je     aeee <fwp_main_thread+0x1d8e>
    aea1:	44 0f b6 06          	movzbl (%rsi),%r8d
    aea5:	41 80 f8 02          	cmp    $0x2,%r8b
    aea9:	0f 84 44 01 00 00    	je     aff3 <fwp_main_thread+0x1e93>
    aeaf:	41 80 f8 01          	cmp    $0x1,%r8b
    aeb3:	75 39                	jne    aeee <fwp_main_thread+0x1d8e>
    aeb5:	44 8b 46 18          	mov    0x18(%rsi),%r8d
    aeb9:	0f b7 c0             	movzwl %ax,%eax
    aebc:	8b 76 1c             	mov    0x1c(%rsi),%esi
    aebf:	49 0f af c0          	imul   %r8,%rax
    aec3:	48 c1 e8 20          	shr    $0x20,%rax
    aec7:	48 39 f0             	cmp    %rsi,%rax
    aeca:	73 22                	jae    aeee <fwp_main_thread+0x1d8e>
    aecc:	48 01 c7             	add    %rax,%rdi
    aecf:	80 3f 01             	cmpb   $0x1,(%rdi)
    aed2:	75 1a                	jne    aeee <fwp_main_thread+0x1d8e>
    aed4:	4c 89 f7             	mov    %r14,%rdi
    aed7:	e8 74 a6 ff ff       	call   5550 <fwp_mem_free>
    aedc:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    aee3:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    aeea:	48 c1 e2 10          	shl    $0x10,%rdx
    aeee:	4c 89 e0             	mov    %r12,%rax
    aef1:	48 29 c8             	sub    %rcx,%rax
    aef4:	48 39 d0             	cmp    %rdx,%rax
    aef7:	0f 83 43 f9 ff ff    	jae    a840 <fwp_main_thread+0x16e0>
    aefd:	4d 89 e6             	mov    %r12,%r14
    af00:	e9 c5 f8 ff ff       	jmp    a7ca <fwp_main_thread+0x166a>
    af05:	0f 1f 00             	nopl   (%rax)
    af08:	66 85 c0             	test   %ax,%ax
    af0b:	0f 85 ef fc ff ff    	jne    ac00 <fwp_main_thread+0x1aa0>
    af11:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af15:	0f 85 e1 fc ff ff    	jne    abfc <fwp_main_thread+0x1a9c>
    af1b:	4c 89 f7             	mov    %r14,%rdi
    af1e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
    af23:	e8 e8 a3 ff ff       	call   5310 <fwp_rc_forget_slot>
    af28:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    af2d:	e9 ca fc ff ff       	jmp    abfc <fwp_main_thread+0x1a9c>
    af32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af38:	be 08 00 00 00       	mov    $0x8,%esi
    af3d:	4c 89 f7             	mov    %r14,%rdi
    af40:	e8 db 85 ff ff       	call   3520 <calloc@plt>
    af45:	66 0f 6f 5c 24 70    	movdqa 0x70(%rsp),%xmm3
    af4b:	66 0f 6f 54 24 60    	movdqa 0x60(%rsp),%xmm2
    af51:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
    af56:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    af5b:	48 89 c1             	mov    %rax,%rcx
    af5e:	e9 1d fe ff ff       	jmp    ad80 <fwp_main_thread+0x1c20>
    af63:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    af68:	66 85 c0             	test   %ax,%ax
    af6b:	0f 85 23 ec ff ff    	jne    9b94 <fwp_main_thread+0xa34>
    af71:	e9 f8 eb ff ff       	jmp    9b6e <fwp_main_thread+0xa0e>
    af76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    af7d:	00 00 00 
    af80:	66 85 c0             	test   %ax,%ax
    af83:	0f 85 ba f9 ff ff    	jne    a943 <fwp_main_thread+0x17e3>
    af89:	41 80 3e ff          	cmpb   $0xff,(%r14)
    af8d:	0f 85 ac f9 ff ff    	jne    a93f <fwp_main_thread+0x17df>
    af93:	4c 89 f7             	mov    %r14,%rdi
    af96:	e8 75 a3 ff ff       	call   5310 <fwp_rc_forget_slot>
    af9b:	e9 9f f9 ff ff       	jmp    a93f <fwp_main_thread+0x17df>
    afa0:	66 85 c0             	test   %ax,%ax
    afa3:	0f 85 57 fa ff ff    	jne    aa00 <fwp_main_thread+0x18a0>
    afa9:	0f b6 03             	movzbl (%rbx),%eax
    afac:	84 c0                	test   %al,%al
    afae:	0f 84 4c fa ff ff    	je     aa00 <fwp_main_thread+0x18a0>
    afb4:	3c 01                	cmp    $0x1,%al
    afb6:	0f 85 2a fa ff ff    	jne    a9e6 <fwp_main_thread+0x1886>
    afbc:	4c 89 e7             	mov    %r12,%rdi
    afbf:	e8 8c a5 ff ff       	call   5550 <fwp_mem_free>
    afc4:	e9 37 fa ff ff       	jmp    aa00 <fwp_main_thread+0x18a0>
    afc9:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
    afce:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    afd3:	31 db                	xor    %ebx,%ebx
    afd5:	e9 c2 f7 ff ff       	jmp    a79c <fwp_main_thread+0x163c>
    afda:	be 68 00 00 00       	mov    $0x68,%esi
    afdf:	41 be 01 00 00 00    	mov    $0x1,%r14d
    afe5:	e9 11 ed ff ff       	jmp    9cfb <fwp_main_thread+0xb9b>
    afea:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    afee:	e9 58 e3 ff ff       	jmp    934b <fwp_main_thread+0x1eb>
    aff3:	66 85 c0             	test   %ax,%ax
    aff6:	0f 85 f2 fe ff ff    	jne    aeee <fwp_main_thread+0x1d8e>
    affc:	e9 ce fe ff ff       	jmp    aecf <fwp_main_thread+0x1d6f>
    b001:	31 db                	xor    %ebx,%ebx
    b003:	e9 05 e4 ff ff       	jmp    940d <fwp_main_thread+0x2ad>
    b008:	4c 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14
    b00f:	00 
    b010:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b015:	e8 c6 c5 ff ff       	call   75e0 <fwp_drop0>
    b01a:	4c 89 f7             	mov    %r14,%rdi
    b01d:	e8 be c5 ff ff       	call   75e0 <fwp_drop0>
    b022:	48 c7 05 3b 50 00 00 	movq   $0x0,0x503b(%rip)        # 10068 <v.2>
    b029:	00 00 00 00 
    b02d:	c7 05 39 50 00 00 01 	movl   $0x1,0x5039(%rip)        # 10070 <st.3>
    b034:	00 00 00 
    b037:	e9 5b e2 ff ff       	jmp    9297 <fwp_main_thread+0x137>
    b03c:	66 85 c0             	test   %ax,%ax
    b03f:	0f 85 92 ea ff ff    	jne    9ad7 <fwp_main_thread+0x977>
    b045:	e9 6f ea ff ff       	jmp    9ab9 <fwp_main_thread+0x959>
    b04a:	66 85 c0             	test   %ax,%ax
    b04d:	0f 85 cd e9 ff ff    	jne    9a20 <fwp_main_thread+0x8c0>
    b053:	e9 b8 e9 ff ff       	jmp    9a10 <fwp_main_thread+0x8b0>
    b058:	66 85 c0             	test   %ax,%ax
    b05b:	0f 85 20 e9 ff ff    	jne    9981 <fwp_main_thread+0x821>
    b061:	e9 0b e9 ff ff       	jmp    9971 <fwp_main_thread+0x811>
    b066:	4c 89 ef             	mov    %r13,%rdi
    b069:	e8 a2 a2 ff ff       	call   5310 <fwp_rc_forget_slot>
    b06e:	e9 ce e7 ff ff       	jmp    9841 <fwp_main_thread+0x6e1>
    b073:	4c 89 e2             	mov    %r12,%rdx
    b076:	48 c1 ea 11          	shr    $0x11,%rdx
    b07a:	4c 31 e2             	xor    %r12,%rdx
    b07d:	48 89 d0             	mov    %rdx,%rax
    b080:	48 c1 e8 09          	shr    $0x9,%rax
    b084:	48 31 c2             	xor    %rax,%rdx
    b087:	0f b6 d2             	movzbl %dl,%edx
    b08a:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b091:	00 
    b092:	48 85 c0             	test   %rax,%rax
    b095:	75 12                	jne    b0a9 <fwp_main_thread+0x1f49>
    b097:	eb 4d                	jmp    b0e6 <fwp_main_thread+0x1f86>
    b099:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b0a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b0a4:	48 85 c0             	test   %rax,%rax
    b0a7:	74 3d                	je     b0e6 <fwp_main_thread+0x1f86>
    b0a9:	48 89 c2             	mov    %rax,%rdx
    b0ac:	4c 39 20             	cmp    %r12,(%rax)
    b0af:	75 ef                	jne    b0a0 <fwp_main_thread+0x1f40>
    b0b1:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b0b5:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b0b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b0bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b0c4:	0f 85 76 f7 ff ff    	jne    a840 <fwp_main_thread+0x16e0>
    b0ca:	4c 89 e7             	mov    %r12,%rdi
    b0cd:	e8 3e a2 ff ff       	call   5310 <fwp_rc_forget_slot>
    b0d2:	41 c6 04 24 fe       	movb   $0xfe,(%r12)
    b0d7:	e9 64 f7 ff ff       	jmp    a840 <fwp_main_thread+0x16e0>
    b0dc:	e8 0f a1 ff ff       	call   51f0 <fwp_rc_wide_dup>
    b0e1:	e9 55 eb ff ff       	jmp    9c3b <fwp_main_thread+0xadb>
    b0e6:	48 8d 3d b3 16 00 00 	lea    0x16b3(%rip),%rdi        # c7a0 <_IO_stdin_used+0x7a0>
    b0ed:	e8 ae 90 ff ff       	call   41a0 <fwp_trap>
    b0f2:	4c 89 c2             	mov    %r8,%rdx
    b0f5:	48 89 cf             	mov    %rcx,%rdi
    b0f8:	48 8d 5a ff          	lea    -0x1(%rdx),%rbx
    b0fc:	31 f6                	xor    %esi,%esi
    b0fe:	48 c1 e2 03          	shl    $0x3,%rdx
    b102:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    b107:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
    b10c:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
    b111:	e8 aa 83 ff ff       	call   34c0 <memset@plt>
    b116:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    b11b:	66 0f 6f 54 24 30    	movdqa 0x30(%rsp),%xmm2
    b121:	66 0f 6f 5c 24 60    	movdqa 0x60(%rsp),%xmm3
    b127:	48 89 c1             	mov    %rax,%rcx
    b12a:	e9 7a fc ff ff       	jmp    ada9 <fwp_main_thread+0x1c49>
    b12f:	48 8b 3d aa 72 01 00 	mov    0x172aa(%rip),%rdi        # 223e0 <fwp_state>
    b136:	e8 15 a4 ff ff       	call   5550 <fwp_mem_free>
    b13b:	48 c7 05 9a 72 01 00 	movq   $0x0,0x1729a(%rip)        # 223e0 <fwp_state>
    b142:	00 00 00 00 
    b146:	48 c7 05 7f 72 01 00 	movq   $0x0,0x1727f(%rip)        # 223d0 <fwp_state_cap>
    b14d:	00 00 00 00 
    b151:	48 85 db             	test   %rbx,%rbx
    b154:	0f 84 d8 00 00 00    	je     b232 <fwp_main_thread+0x20d2>
    b15a:	48 3b 1d d7 55 01 00 	cmp    0x155d7(%rip),%rbx        # 20738 <fwp_root>
    b161:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b168:	00 00 00 00 
    b16c:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b173:	00 00 00 00 
    b177:	c7 05 ff 4e 01 00 00 	movl   $0x0,0x14eff(%rip)        # 20080 <fwp_exit_code>
    b17e:	00 00 00 
    b181:	0f 84 b0 e2 ff ff    	je     9437 <fwp_main_thread+0x2d7>
    b187:	e9 bf 85 ff ff       	jmp    374b <fwp_main_thread.cold>
    b18c:	0f 1f 40 00          	nopl   0x0(%rax)
    b190:	48 89 d8             	mov    %rbx,%rax
    b193:	48 c1 e8 11          	shr    $0x11,%rax
    b197:	48 31 d8             	xor    %rbx,%rax
    b19a:	48 89 c2             	mov    %rax,%rdx
    b19d:	48 c1 ea 09          	shr    $0x9,%rdx
    b1a1:	48 31 d0             	xor    %rdx,%rax
    b1a4:	0f b6 d0             	movzbl %al,%edx
    b1a7:	48 8b 84 d5 48 14 00 	mov    0x1448(%rbp,%rdx,8),%rax
    b1ae:	00 
    b1af:	48 85 c0             	test   %rax,%rax
    b1b2:	75 19                	jne    b1cd <fwp_main_thread+0x206d>
    b1b4:	e9 2d ff ff ff       	jmp    b0e6 <fwp_main_thread+0x1f86>
    b1b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b1c0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    b1c4:	48 85 c0             	test   %rax,%rax
    b1c7:	0f 84 19 ff ff ff    	je     b0e6 <fwp_main_thread+0x1f86>
    b1cd:	48 89 c2             	mov    %rax,%rdx
    b1d0:	48 3b 18             	cmp    (%rax),%rbx
    b1d3:	75 eb                	jne    b1c0 <fwp_main_thread+0x2060>
    b1d5:	48 8b 78 08          	mov    0x8(%rax),%rdi
    b1d9:	48 8d 57 ff          	lea    -0x1(%rdi),%rdx
    b1dd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b1e1:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    b1e8:	0f 85 12 f8 ff ff    	jne    aa00 <fwp_main_thread+0x18a0>
    b1ee:	48 89 df             	mov    %rbx,%rdi
    b1f1:	e8 1a a1 ff ff       	call   5310 <fwp_rc_forget_slot>
    b1f6:	c6 03 fe             	movb   $0xfe,(%rbx)
    b1f9:	e9 02 f8 ff ff       	jmp    aa00 <fwp_main_thread+0x18a0>
    b1fe:	e8 ed 9f ff ff       	call   51f0 <fwp_rc_wide_dup>
    b203:	48 8b 95 d8 13 00 00 	mov    0x13d8(%rbp),%rdx
    b20a:	48 8b 8d b0 13 00 00 	mov    0x13b0(%rbp),%rcx
    b211:	48 c1 e2 10          	shl    $0x10,%rdx
    b215:	e9 7a e9 ff ff       	jmp    9b94 <fwp_main_thread+0xa34>
    b21a:	48 8d 3d e3 0e 00 00 	lea    0xee3(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    b221:	e8 7a 8f ff ff       	call   41a0 <fwp_trap>
    b226:	48 8d 3d 9b 15 00 00 	lea    0x159b(%rip),%rdi        # c7c8 <_IO_stdin_used+0x7c8>
    b22d:	e8 6e 8f ff ff       	call   41a0 <fwp_trap>
    b232:	48 83 3d fe 54 01 00 	cmpq   $0x0,0x154fe(%rip)        # 20738 <fwp_root>
    b239:	00 
    b23a:	c7 05 3c 4e 01 00 00 	movl   $0x0,0x14e3c(%rip)        # 20080 <fwp_exit_code>
    b241:	00 00 00 
    b244:	0f 84 4b e2 ff ff    	je     9495 <fwp_main_thread+0x335>
    b24a:	e9 fc 84 ff ff       	jmp    374b <fwp_main_thread.cold>
    b24f:	90                   	nop
    b250:	4c 89 e7             	mov    %r12,%rdi
    b253:	e8 b8 a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b258:	e9 1f e7 ff ff       	jmp    997c <fwp_main_thread+0x81c>
    b25d:	4c 89 e7             	mov    %r12,%rdi
    b260:	e8 ab a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b265:	e9 b1 e7 ff ff       	jmp    9a1b <fwp_main_thread+0x8bb>
    b26a:	4c 89 e7             	mov    %r12,%rdi
    b26d:	e8 9e a0 ff ff       	call   5310 <fwp_rc_forget_slot>
    b272:	e9 4d e8 ff ff       	jmp    9ac4 <fwp_main_thread+0x964>
    b277:	48 8d 3d 4a 16 00 00 	lea    0x164a(%rip),%rdi        # c8c8 <_IO_stdin_used+0x8c8>
    b27e:	e8 1d 8f ff ff       	call   41a0 <fwp_trap>
    b283:	e8 78 84 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    b288:	48 8d 3d 49 0f 00 00 	lea    0xf49(%rip),%rdi        # c1d8 <_IO_stdin_used+0x1d8>
    b28f:	e8 0c 8f ff ff       	call   41a0 <fwp_trap>
    b294:	48 85 d2             	test   %rdx,%rdx
    b297:	0f 84 05 fb ff ff    	je     ada2 <fwp_main_thread+0x1c42>
    b29d:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
    b2a4:	00 
    b2a5:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    b2aa:	48 89 05 47 71 01 00 	mov    %rax,0x17147(%rip)        # 223f8 <fwp_cleanups>
    b2b1:	e8 7a 9b ff ff       	call   4e30 <fwp_tape_buffers_release>
    b2b6:	48 8b 0d 83 4d 00 00 	mov    0x4d83(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    b2bd:	ba 13 00 00 00       	mov    $0x13,%edx
    b2c2:	be 01 00 00 00       	mov    $0x1,%esi
    b2c7:	48 8d 3d 3a 0d 00 00 	lea    0xd3a(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    b2ce:	e8 ad 83 ff ff       	call   3680 <fwrite@plt>
    b2d3:	31 ff                	xor    %edi,%edi
    b2d5:	e8 e6 82 ff ff       	call   35c0 <fflush@plt>
    b2da:	bf 66 00 00 00       	mov    $0x66,%edi
    b2df:	e8 bc 83 ff ff       	call   36a0 <_Exit@plt>
    b2e4:	48 8d 3d 42 0e 00 00 	lea    0xe42(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    b2eb:	e8 b0 8e ff ff       	call   41a0 <fwp_trap>
    b2f0:	48 8d 3d c7 0e 00 00 	lea    0xec7(%rip),%rdi        # c1be <_IO_stdin_used+0x1be>
    b2f7:	e8 a4 8e ff ff       	call   41a0 <fwp_trap>
    b2fc:	48 8d 3d 95 15 00 00 	lea    0x1595(%rip),%rdi        # c898 <_IO_stdin_used+0x898>
    b303:	e8 98 8e ff ff       	call   41a0 <fwp_trap>
    b308:	48 8d 3d 61 15 00 00 	lea    0x1561(%rip),%rdi        # c870 <_IO_stdin_used+0x870>
    b30f:	e8 8c 8e ff ff       	call   41a0 <fwp_trap>
    b314:	e8 47 81 ff ff       	call   3460 <__stack_chk_fail@plt>
    b319:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b320:	48 8d 3d c9 15 00 00 	lea    0x15c9(%rip),%rdi        # c8f0 <_IO_stdin_used+0x8f0>
    b327:	e8 74 8e ff ff       	call   41a0 <fwp_trap>
    b32c:	48 8d 3d dd 14 00 00 	lea    0x14dd(%rip),%rdi        # c810 <_IO_stdin_used+0x810>
    b333:	e8 68 8e ff ff       	call   41a0 <fwp_trap>
    b338:	48 8d 3d a9 0e 00 00 	lea    0xea9(%rip),%rdi        # c1e8 <_IO_stdin_used+0x1e8>
    b33f:	e8 5c 8e ff ff       	call   41a0 <fwp_trap>
    b344:	e9 02 84 ff ff       	jmp    374b <fwp_main_thread.cold>
    b349:	e9 fd 83 ff ff       	jmp    374b <fwp_main_thread.cold>
    b34e:	66 90                	xchg   %ax,%ax

000000000000b350 <__divmodti4>:
    b350:	f3 0f 1e fa          	endbr64
    b354:	55                   	push   %rbp
    b355:	49 89 f1             	mov    %rsi,%r9
    b358:	49 89 d2             	mov    %rdx,%r10
    b35b:	48 89 fe             	mov    %rdi,%rsi
    b35e:	49 89 cb             	mov    %rcx,%r11
    b361:	48 89 e5             	mov    %rsp,%rbp
    b364:	41 57                	push   %r15
    b366:	41 56                	push   %r14
    b368:	41 55                	push   %r13
    b36a:	41 54                	push   %r12
    b36c:	53                   	push   %rbx
    b36d:	4c 89 c3             	mov    %r8,%rbx
    b370:	45 31 c0             	xor    %r8d,%r8d
    b373:	4d 85 c9             	test   %r9,%r9
    b376:	79 12                	jns    b38a <__divmodti4+0x3a>
    b378:	31 ff                	xor    %edi,%edi
    b37a:	48 f7 de             	neg    %rsi
    b37d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    b384:	4c 19 cf             	sbb    %r9,%rdi
    b387:	49 89 f9             	mov    %rdi,%r9
    b38a:	4c 89 d8             	mov    %r11,%rax
    b38d:	4d 85 db             	test   %r11,%r11
    b390:	0f 88 1a 01 00 00    	js     b4b0 <__divmodti4+0x160>
    b396:	4c 89 d9             	mov    %r11,%rcx
    b399:	49 89 f3             	mov    %rsi,%r11
    b39c:	75 62                	jne    b400 <__divmodti4+0xb0>
    b39e:	4d 89 c4             	mov    %r8,%r12
    b3a1:	4d 39 d1             	cmp    %r10,%r9
    b3a4:	0f 83 46 01 00 00    	jae    b4f0 <__divmodti4+0x1a0>
    b3aa:	4c 89 d8             	mov    %r11,%rax
    b3ad:	4c 89 ca             	mov    %r9,%rdx
    b3b0:	49 f7 f2             	div    %r10
    b3b3:	49 89 c3             	mov    %rax,%r11
    b3b6:	31 c0                	xor    %eax,%eax
    b3b8:	48 89 d6             	mov    %rdx,%rsi
    b3bb:	31 ff                	xor    %edi,%edi
    b3bd:	4c 89 d9             	mov    %r11,%rcx
    b3c0:	48 89 c2             	mov    %rax,%rdx
    b3c3:	48 89 c8             	mov    %rcx,%rax
    b3c6:	4d 85 e4             	test   %r12,%r12
    b3c9:	74 0a                	je     b3d5 <__divmodti4+0x85>
    b3cb:	48 f7 d8             	neg    %rax
    b3ce:	48 83 d2 00          	adc    $0x0,%rdx
    b3d2:	48 f7 da             	neg    %rdx
    b3d5:	4d 85 c0             	test   %r8,%r8
    b3d8:	74 0a                	je     b3e4 <__divmodti4+0x94>
    b3da:	48 f7 de             	neg    %rsi
    b3dd:	48 83 d7 00          	adc    $0x0,%rdi
    b3e1:	48 f7 df             	neg    %rdi
    b3e4:	48 89 33             	mov    %rsi,(%rbx)
    b3e7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    b3eb:	5b                   	pop    %rbx
    b3ec:	41 5c                	pop    %r12
    b3ee:	41 5d                	pop    %r13
    b3f0:	41 5e                	pop    %r14
    b3f2:	41 5f                	pop    %r15
    b3f4:	5d                   	pop    %rbp
    b3f5:	c3                   	ret
    b3f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b3fd:	00 00 00 
    b400:	4d 89 c4             	mov    %r8,%r12
    b403:	49 39 c1             	cmp    %rax,%r9
    b406:	0f 82 ce 00 00 00    	jb     b4da <__divmodti4+0x18a>
    b40c:	31 ff                	xor    %edi,%edi
    b40e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    b413:	48 63 c7             	movslq %edi,%rax
    b416:	be 40 00 00 00       	mov    $0x40,%esi
    b41b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    b420:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    b425:	48 29 c6             	sub    %rax,%rsi
    b428:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    b42d:	48 09 c8             	or     %rcx,%rax
    b430:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    b435:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    b43a:	49 89 c6             	mov    %rax,%r14
    b43d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b441:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    b446:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    b44b:	49 09 c1             	or     %rax,%r9
    b44e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    b452:	4c 89 c8             	mov    %r9,%rax
    b455:	49 f7 f6             	div    %r14
    b458:	48 89 d1             	mov    %rdx,%rcx
    b45b:	49 89 c3             	mov    %rax,%r11
    b45e:	49 89 c1             	mov    %rax,%r9
    b461:	49 f7 e2             	mul    %r10
    b464:	49 89 c6             	mov    %rax,%r14
    b467:	49 89 d2             	mov    %rdx,%r10
    b46a:	48 39 d1             	cmp    %rdx,%rcx
    b46d:	72 07                	jb     b476 <__divmodti4+0x126>
    b46f:	75 17                	jne    b488 <__divmodti4+0x138>
    b471:	49 39 c7             	cmp    %rax,%r15
    b474:	73 12                	jae    b488 <__divmodti4+0x138>
    b476:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    b47a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    b47e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    b482:	49 89 d2             	mov    %rdx,%r10
    b485:	49 89 c6             	mov    %rax,%r14
    b488:	4c 89 f8             	mov    %r15,%rax
    b48b:	4c 29 f0             	sub    %r14,%rax
    b48e:	4c 19 d1             	sbb    %r10,%rcx
    b491:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    b496:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    b49b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    b4a0:	48 09 c6             	or     %rax,%rsi
    b4a3:	48 89 cf             	mov    %rcx,%rdi
    b4a6:	31 c0                	xor    %eax,%eax
    b4a8:	4c 89 c9             	mov    %r9,%rcx
    b4ab:	e9 10 ff ff ff       	jmp    b3c0 <__divmodti4+0x70>
    b4b0:	4c 89 d0             	mov    %r10,%rax
    b4b3:	4c 89 da             	mov    %r11,%rdx
    b4b6:	4d 89 c4             	mov    %r8,%r12
    b4b9:	49 89 f3             	mov    %rsi,%r11
    b4bc:	48 f7 d8             	neg    %rax
    b4bf:	49 f7 d4             	not    %r12
    b4c2:	48 83 d2 00          	adc    $0x0,%rdx
    b4c6:	49 89 c2             	mov    %rax,%r10
    b4c9:	48 f7 da             	neg    %rdx
    b4cc:	48 89 d1             	mov    %rdx,%rcx
    b4cf:	0f 84 cc fe ff ff    	je     b3a1 <__divmodti4+0x51>
    b4d5:	49 39 d1             	cmp    %rdx,%r9
    b4d8:	73 46                	jae    b520 <__divmodti4+0x1d0>
    b4da:	4c 89 cf             	mov    %r9,%rdi
    b4dd:	31 c0                	xor    %eax,%eax
    b4df:	31 c9                	xor    %ecx,%ecx
    b4e1:	e9 da fe ff ff       	jmp    b3c0 <__divmodti4+0x70>
    b4e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b4ed:	00 00 00 
    b4f0:	4d 85 d2             	test   %r10,%r10
    b4f3:	75 0d                	jne    b502 <__divmodti4+0x1b2>
    b4f5:	b8 01 00 00 00       	mov    $0x1,%eax
    b4fa:	31 d2                	xor    %edx,%edx
    b4fc:	49 f7 f2             	div    %r10
    b4ff:	49 89 c2             	mov    %rax,%r10
    b502:	4c 89 c8             	mov    %r9,%rax
    b505:	31 d2                	xor    %edx,%edx
    b507:	49 f7 f2             	div    %r10
    b50a:	49 89 c1             	mov    %rax,%r9
    b50d:	4c 89 d8             	mov    %r11,%rax
    b510:	49 f7 f2             	div    %r10
    b513:	49 89 c3             	mov    %rax,%r11
    b516:	4c 89 c8             	mov    %r9,%rax
    b519:	e9 9a fe ff ff       	jmp    b3b8 <__divmodti4+0x68>
    b51e:	66 90                	xchg   %ax,%ax
    b520:	45 31 f6             	xor    %r14d,%r14d
    b523:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    b528:	44 89 f7             	mov    %r14d,%edi
    b52b:	45 85 f6             	test   %r14d,%r14d
    b52e:	0f 85 df fe ff ff    	jne    b413 <__divmodti4+0xc3>
    b534:	4c 39 ca             	cmp    %r9,%rdx
    b537:	72 17                	jb     b550 <__divmodti4+0x200>
    b539:	31 c9                	xor    %ecx,%ecx
    b53b:	48 39 c6             	cmp    %rax,%rsi
    b53e:	73 10                	jae    b550 <__divmodti4+0x200>
    b540:	4c 89 cf             	mov    %r9,%rdi
    b543:	31 c0                	xor    %eax,%eax
    b545:	e9 76 fe ff ff       	jmp    b3c0 <__divmodti4+0x70>
    b54a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b550:	4c 89 de             	mov    %r11,%rsi
    b553:	b9 01 00 00 00       	mov    $0x1,%ecx
    b558:	48 29 c6             	sub    %rax,%rsi
    b55b:	49 19 d1             	sbb    %rdx,%r9
    b55e:	eb e0                	jmp    b540 <__divmodti4+0x1f0>

000000000000b560 <atexit>:
    b560:	f3 0f 1e fa          	endbr64
    b564:	48 8b 15 9d 4a 00 00 	mov    0x4a9d(%rip),%rdx        # 10008 <__dso_handle>
    b56b:	31 f6                	xor    %esi,%esi
    b56d:	e9 ee 80 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000b574 <_fini>:
    b574:	f3 0f 1e fa          	endbr64
    b578:	48 83 ec 08          	sub    $0x8,%rsp
    b57c:	48 83 c4 08          	add    $0x8,%rsp
    b580:	c3                   	ret
