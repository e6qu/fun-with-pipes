
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-1/fwp-ad-history-phases:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c1 df 00 00 	mov    0xdfc1(%rip),%rax        # 10fd0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 da dd 00 00    	push   0xddda(%rip)        # 10e00 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 dc dd 00 00    	jmp    *0xdddc(%rip)        # 10e08 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 46 dc 00 00    	jmp    *0xdc46(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 66 da 00 00    	jmp    *0xda66(%rip)        # 10e10 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 5e da 00 00    	jmp    *0xda5e(%rip)        # 10e18 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 56 da 00 00    	jmp    *0xda56(%rip)        # 10e20 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 4e da 00 00    	jmp    *0xda4e(%rip)        # 10e28 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 46 da 00 00    	jmp    *0xda46(%rip)        # 10e30 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 3e da 00 00    	jmp    *0xda3e(%rip)        # 10e38 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 36 da 00 00    	jmp    *0xda36(%rip)        # 10e40 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 2e da 00 00    	jmp    *0xda2e(%rip)        # 10e48 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 26 da 00 00    	jmp    *0xda26(%rip)        # 10e50 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 1e da 00 00    	jmp    *0xda1e(%rip)        # 10e58 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 16 da 00 00    	jmp    *0xda16(%rip)        # 10e60 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 0e da 00 00    	jmp    *0xda0e(%rip)        # 10e68 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 06 da 00 00    	jmp    *0xda06(%rip)        # 10e70 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 fe d9 00 00    	jmp    *0xd9fe(%rip)        # 10e78 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 f6 d9 00 00    	jmp    *0xd9f6(%rip)        # 10e80 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 ee d9 00 00    	jmp    *0xd9ee(%rip)        # 10e88 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 e6 d9 00 00    	jmp    *0xd9e6(%rip)        # 10e90 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 de d9 00 00    	jmp    *0xd9de(%rip)        # 10e98 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 d6 d9 00 00    	jmp    *0xd9d6(%rip)        # 10ea0 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ce d9 00 00    	jmp    *0xd9ce(%rip)        # 10ea8 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 c6 d9 00 00    	jmp    *0xd9c6(%rip)        # 10eb0 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 be d9 00 00    	jmp    *0xd9be(%rip)        # 10eb8 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 b6 d9 00 00    	jmp    *0xd9b6(%rip)        # 10ec0 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ae d9 00 00    	jmp    *0xd9ae(%rip)        # 10ec8 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 a6 d9 00 00    	jmp    *0xd9a6(%rip)        # 10ed0 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 9e d9 00 00    	jmp    *0xd99e(%rip)        # 10ed8 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 96 d9 00 00    	jmp    *0xd996(%rip)        # 10ee0 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 8e d9 00 00    	jmp    *0xd98e(%rip)        # 10ee8 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 86 d9 00 00    	jmp    *0xd986(%rip)        # 10ef0 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 7e d9 00 00    	jmp    *0xd97e(%rip)        # 10ef8 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 76 d9 00 00    	jmp    *0xd976(%rip)        # 10f00 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 6e d9 00 00    	jmp    *0xd96e(%rip)        # 10f08 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 66 d9 00 00    	jmp    *0xd966(%rip)        # 10f10 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 5e d9 00 00    	jmp    *0xd95e(%rip)        # 10f18 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 56 d9 00 00    	jmp    *0xd956(%rip)        # 10f20 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 4e d9 00 00    	jmp    *0xd94e(%rip)        # 10f28 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 46 d9 00 00    	jmp    *0xd946(%rip)        # 10f30 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 3e d9 00 00    	jmp    *0xd93e(%rip)        # 10f38 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 36 d9 00 00    	jmp    *0xd936(%rip)        # 10f40 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 2e d9 00 00    	jmp    *0xd92e(%rip)        # 10f48 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 26 d9 00 00    	jmp    *0xd926(%rip)        # 10f50 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 1e d9 00 00    	jmp    *0xd91e(%rip)        # 10f58 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 16 d9 00 00    	jmp    *0xd916(%rip)        # 10f60 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 0e d9 00 00    	jmp    *0xd90e(%rip)        # 10f68 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 06 d9 00 00    	jmp    *0xd906(%rip)        # 10f70 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 fe d8 00 00    	jmp    *0xd8fe(%rip)        # 10f78 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 f6 d8 00 00    	jmp    *0xd8f6(%rip)        # 10f80 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 ee d8 00 00    	jmp    *0xd8ee(%rip)        # 10f88 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 e6 d8 00 00    	jmp    *0xd8e6(%rip)        # 10f90 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 de d8 00 00    	jmp    *0xd8de(%rip)        # 10f98 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 d6 d8 00 00    	jmp    *0xd8d6(%rip)        # 10fa0 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ce d8 00 00    	jmp    *0xd8ce(%rip)        # 10fa8 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 c6 d8 00 00    	jmp    *0xd8c6(%rip)        # 10fb0 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 be d8 00 00    	jmp    *0xd8be(%rip)        # 10fb8 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d dd 99 00 00 	lea    0x99dd(%rip),%r9        # d0f4 <_IO_stdin_used+0xf4>
    3717:	4c 8d 05 da 99 00 00 	lea    0x99da(%rip),%r8        # d0f8 <_IO_stdin_used+0xf8>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 aa 0c 00 00       	call   43f0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 e1 bc 00 00 	lea    0xbce1(%rip),%rax        # f460 <fwp_fn_table>
    377f:	48 89 05 b2 fc 01 00 	mov    %rax,0x1fcb2(%rip)        # 23438 <fwp_fns>
    3786:	48 8b 05 b3 d8 00 00 	mov    0xd8b3(%rip),%rax        # 11040 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 ac fc 01 00 	mov    %rax,0x1fcac(%rip)        # 23440 <fwp_prog_out>
    3794:	e8 c7 0d 00 00       	call   4560 <fwp_now_ns>
    3799:	48 8d 3d b7 9a 00 00 	lea    0x9ab7(%rip),%rdi        # d257 <_IO_stdin_used+0x257>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 38 d8 00 00 	mov    0xd838(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 4f 79 00 00 	lea    0x794f(%rip),%rdx        # b1b0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d a3 d7 00 00 	mov    0xd7a3(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 f8 d7 01 00    	mov    0x1d7f8(%rip),%eax        # 210a0 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 67 99 00 00 	lea    0x9967(%rip),%rdi        # d260 <_IO_stdin_used+0x260>
    38f9:	e8 f2 0a 00 00       	call   43f0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 7e a1 00 00 	lea    0xa17e(%rip),%rdi        # da88 <_IO_stdin_used+0xa88>
    390a:	e8 e1 0a 00 00       	call   43f0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 38 a1 00 00 	lea    0xa138(%rip),%rdi        # da60 <_IO_stdin_used+0xa60>
    3928:	e8 c3 0a 00 00       	call   43f0 <fwp_trap>
    392d:	48 8d 3d fc a0 00 00 	lea    0xa0fc(%rip),%rdi        # da30 <_IO_stdin_used+0xa30>
    3934:	e8 b7 0a 00 00       	call   43f0 <fwp_trap>
    3939:	48 8d 3d c8 a0 00 00 	lea    0xa0c8(%rip),%rdi        # da08 <_IO_stdin_used+0xa08>
    3940:	e8 ab 0a 00 00       	call   43f0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 4b d6 00 00    	call   *0xd64b(%rip)        # 10fc0 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d a1 d6 00 00 	lea    0xd6a1(%rip),%rdi        # 11028 <__TMC_END__>
    3987:	48 8d 05 9a d6 00 00 	lea    0xd69a(%rip),%rax        # 11028 <__TMC_END__>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 2e d6 00 00 	mov    0xd62e(%rip),%rax        # 10fc8 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 71 d6 00 00 	lea    0xd671(%rip),%rdi        # 11028 <__TMC_END__>
    39b7:	48 8d 35 6a d6 00 00 	lea    0xd66a(%rip),%rsi        # 11028 <__TMC_END__>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 fd d5 00 00 	mov    0xd5fd(%rip),%rax        # 10fd8 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 6d d6 00 00 00 	cmpb   $0x0,0xd66d(%rip)        # 11068 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d da d5 00 00 	cmpq   $0x0,0xd5da(%rip)        # 10fe0 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 d5 00 00 	mov    0xd5f6(%rip),%rdi        # 11008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 45 d6 00 00 01 	movb   $0x1,0xd645(%rip)        # 11068 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ee d4 01 00 	add    0x1d4ee(%rip),%rdx        # 21110 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 dc d4 01 00 	add    0x1d4dc(%rip),%rax        # 21110 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d c9 f7 01 00 	mov    0x1f7c9(%rip),%rdi        # 23440 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d b4 d3 00 00 	mov    0xd3b4(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d a1 d3 00 00 	mov    0xd3a1(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 93 00 00 	lea    0x9345(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 92 d3 00 00 	mov    0xd392(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 c1 da 01 00 	mov    0x1dac1(%rip),%rax        # 217c0 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 f9 d3 01 00 	mov    0x1d3f9(%rip),%rax        # 21178 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 e5 d3 01 00 	sub    0x1d3e5(%rip),%rax        # 21170 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 ad 9d 00 00 	lea    0x9dad(%rip),%rsi        # db70 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <descent_phase_fail>:
    3de0:	50                   	push   %rax
    3de1:	58                   	pop    %rax
    3de2:	48 8d 3d 7f 98 00 00 	lea    0x987f(%rip),%rdi        # d668 <_IO_stdin_used+0x668>
    3de9:	ba 41 00 00 00       	mov    $0x41,%edx
    3dee:	be 01 00 00 00       	mov    $0x1,%esi
    3df3:	48 83 ec 08          	sub    $0x8,%rsp
    3df7:	48 8b 0d 62 d2 00 00 	mov    0xd262(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3dfe:	e8 7d f8 ff ff       	call   3680 <fwrite@plt>
    3e03:	bf e9 00 00 00       	mov    $0xe9,%edi
    3e08:	e8 93 f8 ff ff       	call   36a0 <_Exit@plt>
    3e0d:	0f 1f 00             	nopl   (%rax)

0000000000003e10 <descent_phase_report>:
    3e10:	f3 0f 1e fa          	endbr64
    3e14:	41 54                	push   %r12
    3e16:	55                   	push   %rbp
    3e17:	53                   	push   %rbx
    3e18:	48 83 ec 40          	sub    $0x40,%rsp
    3e1c:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3e23:	00 00 
    3e25:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    3e2a:	31 c0                	xor    %eax,%eax
    3e2c:	83 3d ed d1 00 00 ff 	cmpl   $0xffffffff,0xd1ed(%rip)        # 11020 <descent_active_phase>
    3e33:	0f 85 32 01 00 00    	jne    3f6b <descent_phase_report+0x15b>
    3e39:	48 8d 05 e2 91 00 00 	lea    0x91e2(%rip),%rax        # d022 <_IO_stdin_used+0x22>
    3e40:	4c 8b 0d e1 d2 01 00 	mov    0x1d2e1(%rip),%r9        # 21128 <descent_nodes>
    3e47:	31 db                	xor    %ebx,%ebx
    3e49:	f3 0f 7e 05 9f cd 00 	movq   0xcd9f(%rip),%xmm0        # 10bf0 <d0+0x70>
    3e50:	00 
    3e51:	66 48 0f 6e c8       	movq   %rax,%xmm1
    3e56:	48 8d 05 e7 91 00 00 	lea    0x91e7(%rip),%rax        # d044 <_IO_stdin_used+0x44>
    3e5d:	4c 8b 05 bc d2 01 00 	mov    0x1d2bc(%rip),%r8        # 21120 <descent_inputs>
    3e64:	48 8b 0d c5 d2 01 00 	mov    0x1d2c5(%rip),%rcx        # 21130 <descent_updates>
    3e6b:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    3e6f:	66 48 0f 6e d0       	movq   %rax,%xmm2
    3e74:	48 89 e5             	mov    %rsp,%rbp
    3e77:	48 8b 3d e2 d1 00 00 	mov    0xd1e2(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3e7e:	0f 29 04 24          	movaps %xmm0,(%rsp)
    3e82:	48 8d 05 d8 91 00 00 	lea    0x91d8(%rip),%rax        # d061 <_IO_stdin_used+0x61>
    3e89:	f3 0f 7e 05 67 cd 00 	movq   0xcd67(%rip),%xmm0        # 10bf8 <d0+0x78>
    3e90:	00 
    3e91:	48 8d 15 18 98 00 00 	lea    0x9818(%rip),%rdx        # d6b0 <_IO_stdin_used+0x6b0>
    3e98:	66 48 0f 6e d8       	movq   %rax,%xmm3
    3e9d:	be 02 00 00 00       	mov    $0x2,%esi
    3ea2:	31 c0                	xor    %eax,%eax
    3ea4:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    3ea8:	4c 8d 25 91 d2 01 00 	lea    0x1d291(%rip),%r12        # 21140 <descent_phase_ns>
    3eaf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    3eb4:	f3 0f 7e 05 44 cd 00 	movq   0xcd44(%rip),%xmm0        # 10c00 <d0+0x80>
    3ebb:	00 
    3ebc:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    3ec0:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    3ec5:	e8 c6 f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3ed0:	4d 8b 0c dc          	mov    (%r12,%rbx,8),%r9
    3ed4:	4c 8b 44 dd 00       	mov    0x0(%rbp,%rbx,8),%r8
    3ed9:	48 85 db             	test   %rbx,%rbx
    3edc:	74 62                	je     3f40 <descent_phase_report+0x130>
    3ede:	48 8b 3d 7b d1 00 00 	mov    0xd17b(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3ee5:	be 02 00 00 00       	mov    $0x2,%esi
    3eea:	31 c0                	xor    %eax,%eax
    3eec:	48 83 c3 01          	add    $0x1,%rbx
    3ef0:	48 8d 0d 75 91 00 00 	lea    0x9175(%rip),%rcx        # d06c <_IO_stdin_used+0x6c>
    3ef7:	48 8d 15 70 91 00 00 	lea    0x9170(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3efe:	e8 8d f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f03:	48 83 fb 06          	cmp    $0x6,%rbx
    3f07:	75 c7                	jne    3ed0 <descent_phase_report+0xc0>
    3f09:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    3f0e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3f15:	00 00 
    3f17:	75 57                	jne    3f70 <descent_phase_report+0x160>
    3f19:	48 8b 0d 40 d1 00 00 	mov    0xd140(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    3f20:	48 83 c4 40          	add    $0x40,%rsp
    3f24:	ba 04 00 00 00       	mov    $0x4,%edx
    3f29:	be 01 00 00 00       	mov    $0x1,%esi
    3f2e:	5b                   	pop    %rbx
    3f2f:	48 8d 3d 44 91 00 00 	lea    0x9144(%rip),%rdi        # d07a <_IO_stdin_used+0x7a>
    3f36:	5d                   	pop    %rbp
    3f37:	41 5c                	pop    %r12
    3f39:	e9 42 f7 ff ff       	jmp    3680 <fwrite@plt>
    3f3e:	66 90                	xchg   %ax,%ax
    3f40:	48 8b 3d 19 d1 00 00 	mov    0xd119(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    3f47:	48 8d 0d 43 91 00 00 	lea    0x9143(%rip),%rcx        # d091 <_IO_stdin_used+0x91>
    3f4e:	48 8d 15 19 91 00 00 	lea    0x9119(%rip),%rdx        # d06e <_IO_stdin_used+0x6e>
    3f55:	31 c0                	xor    %eax,%eax
    3f57:	be 02 00 00 00       	mov    $0x2,%esi
    3f5c:	bb 01 00 00 00       	mov    $0x1,%ebx
    3f61:	e8 2a f7 ff ff       	call   3690 <__fprintf_chk@plt>
    3f66:	e9 65 ff ff ff       	jmp    3ed0 <descent_phase_report+0xc0>
    3f6b:	e8 70 fe ff ff       	call   3de0 <descent_phase_fail>
    3f70:	e8 eb f4 ff ff       	call   3460 <__stack_chk_fail@plt>
    3f75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3f7c:	00 00 00 00 

0000000000003f80 <fwp_heap_chunks>:
    3f80:	41 54                	push   %r12
    3f82:	55                   	push   %rbp
    3f83:	53                   	push   %rbx
    3f84:	48 83 ff 01          	cmp    $0x1,%rdi
    3f88:	0f 84 62 01 00 00    	je     40f0 <fwp_heap_chunks+0x170>
    3f8e:	48 8b 05 3b ec 01 00 	mov    0x1ec3b(%rip),%rax        # 22bd0 <fwp_heap+0x13f0>
    3f95:	4c 8d 05 34 ec 01 00 	lea    0x1ec34(%rip),%r8        # 22bd0 <fwp_heap+0x13f0>
    3f9c:	48 8b 1d 15 ec 01 00 	mov    0x1ec15(%rip),%rbx        # 22bb8 <fwp_heap+0x13d8>
    3fa3:	48 39 d8             	cmp    %rbx,%rax
    3fa6:	0f 83 57 01 00 00    	jae    4103 <fwp_heap_chunks+0x183>
    3fac:	48 8b 0d 25 ec 01 00 	mov    0x1ec25(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    3fb3:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3fb7:	31 f6                	xor    %esi,%esi
    3fb9:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3fbd:	eb 1e                	jmp    3fdd <fwp_heap_chunks+0x5d>
    3fbf:	90                   	nop
    3fc0:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3fc4:	48 39 cf             	cmp    %rcx,%rdi
    3fc7:	0f 84 03 01 00 00    	je     40d0 <fwp_heap_chunks+0x150>
    3fcd:	48 83 c0 01          	add    $0x1,%rax
    3fd1:	48 89 ce             	mov    %rcx,%rsi
    3fd4:	48 83 c2 28          	add    $0x28,%rdx
    3fd8:	48 39 c3             	cmp    %rax,%rbx
    3fdb:	74 14                	je     3ff1 <fwp_heap_chunks+0x71>
    3fdd:	80 3a 00             	cmpb   $0x0,(%rdx)
    3fe0:	74 de                	je     3fc0 <fwp_heap_chunks+0x40>
    3fe2:	48 83 c0 01          	add    $0x1,%rax
    3fe6:	31 f6                	xor    %esi,%esi
    3fe8:	48 83 c2 28          	add    $0x28,%rdx
    3fec:	48 39 c3             	cmp    %rax,%rbx
    3fef:	75 ec                	jne    3fdd <fwp_heap_chunks+0x5d>
    3ff1:	48 29 f3             	sub    %rsi,%rbx
    3ff4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ff8:	48 8b 3d c1 eb 01 00 	mov    0x1ebc1(%rip),%rdi        # 22bc0 <fwp_heap+0x13e0>
    3fff:	48 29 35 0a ec 01 00 	sub    %rsi,0x1ec0a(%rip)        # 22c10 <fwp_heap+0x1430>
    4006:	48 39 ef             	cmp    %rbp,%rdi
    4009:	0f 83 96 00 00 00    	jae    40a5 <fwp_heap_chunks+0x125>
    400f:	48 8b 05 9a eb 01 00 	mov    0x1eb9a(%rip),%rax        # 22bb0 <fwp_heap+0x13d0>
    4016:	48 39 e8             	cmp    %rbp,%rax
    4019:	0f 82 eb 00 00 00    	jb     410a <fwp_heap_chunks+0x18a>
    401f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    4023:	ba 03 00 00 00       	mov    $0x3,%edx
    4028:	49 39 c4             	cmp    %rax,%r12
    402b:	4c 0f 47 e0          	cmova  %rax,%r12
    402f:	4c 89 e6             	mov    %r12,%rsi
    4032:	48 29 fe             	sub    %rdi,%rsi
    4035:	48 c1 e7 10          	shl    $0x10,%rdi
    4039:	48 03 3d 50 eb 01 00 	add    0x1eb50(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    4040:	48 c1 e6 10          	shl    $0x10,%rsi
    4044:	e8 d7 f5 ff ff       	call   3620 <mprotect@plt>
    4049:	85 c0                	test   %eax,%eax
    404b:	0f 85 b9 00 00 00    	jne    410a <fwp_heap_chunks+0x18a>
    4051:	bf 1e 00 00 00       	mov    $0x1e,%edi
    4056:	e8 e5 f5 ff ff       	call   3640 <sysconf@plt>
    405b:	48 8b 35 5e eb 01 00 	mov    0x1eb5e(%rip),%rsi        # 22bc0 <fwp_heap+0x13e0>
    4062:	48 89 c1             	mov    %rax,%rcx
    4065:	48 8b 05 6c eb 01 00 	mov    0x1eb6c(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    406c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    4070:	48 89 ca             	mov    %rcx,%rdx
    4073:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    4077:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    407b:	48 f7 da             	neg    %rdx
    407e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    4083:	48 21 d7             	and    %rdx,%rdi
    4086:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    408a:	48 21 d6             	and    %rdx,%rsi
    408d:	ba 03 00 00 00       	mov    $0x3,%edx
    4092:	48 29 fe             	sub    %rdi,%rsi
    4095:	e8 86 f5 ff ff       	call   3620 <mprotect@plt>
    409a:	85 c0                	test   %eax,%eax
    409c:	75 6c                	jne    410a <fwp_heap_chunks+0x18a>
    409e:	4c 89 25 1b eb 01 00 	mov    %r12,0x1eb1b(%rip)        # 22bc0 <fwp_heap+0x13e0>
    40a5:	48 89 ef             	mov    %rbp,%rdi
    40a8:	48 89 2d 09 eb 01 00 	mov    %rbp,0x1eb09(%rip)        # 22bb8 <fwp_heap+0x13d8>
    40af:	48 c1 e7 10          	shl    $0x10,%rdi
    40b3:	48 39 3d ee ea 01 00 	cmp    %rdi,0x1eaee(%rip)        # 22ba8 <fwp_heap+0x13c8>
    40ba:	73 07                	jae    40c3 <fwp_heap_chunks+0x143>
    40bc:	48 89 3d e5 ea 01 00 	mov    %rdi,0x1eae5(%rip)        # 22ba8 <fwp_heap+0x13c8>
    40c3:	48 89 d8             	mov    %rbx,%rax
    40c6:	5b                   	pop    %rbx
    40c7:	5d                   	pop    %rbp
    40c8:	41 5c                	pop    %r12
    40ca:	c3                   	ret
    40cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    40d0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    40d4:	48 29 f0             	sub    %rsi,%rax
    40d7:	48 89 c3             	mov    %rax,%rbx
    40da:	49 89 10             	mov    %rdx,(%r8)
    40dd:	48 89 d8             	mov    %rbx,%rax
    40e0:	48 29 3d 29 eb 01 00 	sub    %rdi,0x1eb29(%rip)        # 22c10 <fwp_heap+0x1430>
    40e7:	5b                   	pop    %rbx
    40e8:	5d                   	pop    %rbp
    40e9:	41 5c                	pop    %r12
    40eb:	c3                   	ret
    40ec:	0f 1f 40 00          	nopl   0x0(%rax)
    40f0:	48 8b 05 d1 ea 01 00 	mov    0x1ead1(%rip),%rax        # 22bc8 <fwp_heap+0x13e8>
    40f7:	4c 8d 05 ca ea 01 00 	lea    0x1eaca(%rip),%r8        # 22bc8 <fwp_heap+0x13e8>
    40fe:	e9 99 fe ff ff       	jmp    3f9c <fwp_heap_chunks+0x1c>
    4103:	31 f6                	xor    %esi,%esi
    4105:	e9 ea fe ff ff       	jmp    3ff4 <fwp_heap_chunks+0x74>
    410a:	e8 a1 fb ff ff       	call   3cb0 <fwp_heap_oom>
    410f:	90                   	nop

0000000000004110 <fwp_tape_buffers_dispose>:
    4110:	53                   	push   %rbx
    4111:	48 89 fb             	mov    %rdi,%rbx
    4114:	48 8b 3f             	mov    (%rdi),%rdi
    4117:	e8 a4 f2 ff ff       	call   33c0 <free@plt>
    411c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    4120:	e8 9b f2 ff ff       	call   33c0 <free@plt>
    4125:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    4129:	e8 92 f2 ff ff       	call   33c0 <free@plt>
    412e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4132:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4139:	00 
    413a:	0f 11 03             	movups %xmm0,(%rbx)
    413d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4141:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4145:	5b                   	pop    %rbx
    4146:	c3                   	ret
    4147:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    414e:	00 00 

0000000000004150 <buf_grow>:
    4150:	48 83 ec 18          	sub    $0x18,%rsp
    4154:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4158:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    415c:	74 7e                	je     41dc <buf_grow+0x8c>
    415e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4165:	48 29 c2             	sub    %rax,%rdx
    4168:	48 39 f2             	cmp    %rsi,%rdx
    416b:	72 6f                	jb     41dc <buf_grow+0x8c>
    416d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4172:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4176:	48 89 f9             	mov    %rdi,%rcx
    4179:	48 39 d0             	cmp    %rdx,%rax
    417c:	73 48                	jae    41c6 <buf_grow+0x76>
    417e:	48 85 c0             	test   %rax,%rax
    4181:	75 15                	jne    4198 <buf_grow+0x48>
    4183:	48 83 fa 40          	cmp    $0x40,%rdx
    4187:	76 4c                	jbe    41d5 <buf_grow+0x85>
    4189:	b8 40 00 00 00       	mov    $0x40,%eax
    418e:	eb 08                	jmp    4198 <buf_grow+0x48>
    4190:	48 01 c0             	add    %rax,%rax
    4193:	48 39 d0             	cmp    %rdx,%rax
    4196:	73 38                	jae    41d0 <buf_grow+0x80>
    4198:	48 85 c0             	test   %rax,%rax
    419b:	79 f3                	jns    4190 <buf_grow+0x40>
    419d:	48 8b 39             	mov    (%rcx),%rdi
    41a0:	48 89 d6             	mov    %rdx,%rsi
    41a3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    41a8:	48 89 14 24          	mov    %rdx,(%rsp)
    41ac:	e8 1f f4 ff ff       	call   35d0 <realloc@plt>
    41b1:	48 8b 14 24          	mov    (%rsp),%rdx
    41b5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    41ba:	48 85 c0             	test   %rax,%rax
    41bd:	74 1d                	je     41dc <buf_grow+0x8c>
    41bf:	48 89 01             	mov    %rax,(%rcx)
    41c2:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    41c6:	48 83 c4 18          	add    $0x18,%rsp
    41ca:	c3                   	ret
    41cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    41d0:	48 89 c2             	mov    %rax,%rdx
    41d3:	eb c8                	jmp    419d <buf_grow+0x4d>
    41d5:	ba 40 00 00 00       	mov    $0x40,%edx
    41da:	eb c1                	jmp    419d <buf_grow+0x4d>
    41dc:	48 8b 0d 7d ce 00 00 	mov    0xce7d(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    41e3:	ba 13 00 00 00       	mov    $0x13,%edx
    41e8:	be 01 00 00 00       	mov    $0x1,%esi
    41ed:	48 8d 3d 14 8e 00 00 	lea    0x8e14(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    41f4:	e8 87 f4 ff ff       	call   3680 <fwrite@plt>
    41f9:	31 ff                	xor    %edi,%edi
    41fb:	e8 c0 f3 ff ff       	call   35c0 <fflush@plt>
    4200:	bf 66 00 00 00       	mov    $0x66,%edi
    4205:	e8 96 f4 ff ff       	call   36a0 <_Exit@plt>
    420a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004210 <buf_put>:
    4210:	41 54                	push   %r12
    4212:	49 89 f4             	mov    %rsi,%r12
    4215:	48 89 d6             	mov    %rdx,%rsi
    4218:	55                   	push   %rbp
    4219:	48 89 fd             	mov    %rdi,%rbp
    421c:	53                   	push   %rbx
    421d:	48 89 d3             	mov    %rdx,%rbx
    4220:	e8 2b ff ff ff       	call   4150 <buf_grow>
    4225:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4229:	48 89 da             	mov    %rbx,%rdx
    422c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4230:	4c 89 e6             	mov    %r12,%rsi
    4233:	e8 68 f3 ff ff       	call   35a0 <memcpy@plt>
    4238:	48 8b 45 00          	mov    0x0(%rbp),%rax
    423c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4240:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4244:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4248:	5b                   	pop    %rbx
    4249:	5d                   	pop    %rbp
    424a:	41 5c                	pop    %r12
    424c:	c3                   	ret
    424d:	0f 1f 00             	nopl   (%rax)

0000000000004250 <descent_phase_step>:
    4250:	55                   	push   %rbp
    4251:	53                   	push   %rbx
    4252:	48 83 ec 28          	sub    $0x28,%rsp
    4256:	64 48 8b 2c 25 28 00 	mov    %fs:0x28,%rbp
    425d:	00 00 
    425f:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
    4264:	48 63 2d b5 cd 00 00 	movslq 0xcdb5(%rip),%rbp        # 11020 <descent_active_phase>
    426b:	8d 45 01             	lea    0x1(%rbp),%eax
    426e:	39 f8                	cmp    %edi,%eax
    4270:	75 7c                	jne    42ee <descent_phase_step+0x9e>
    4272:	89 fb                	mov    %edi,%ebx
    4274:	48 89 e6             	mov    %rsp,%rsi
    4277:	bf 01 00 00 00       	mov    $0x1,%edi
    427c:	e8 9f f1 ff ff       	call   3420 <clock_gettime@plt>
    4281:	85 c0                	test   %eax,%eax
    4283:	75 69                	jne    42ee <descent_phase_step+0x9e>
    4285:	48 69 04 24 00 ca 9a 	imul   $0x3b9aca00,(%rsp),%rax
    428c:	3b 
    428d:	48 03 44 24 08       	add    0x8(%rsp),%rax
    4292:	83 fd ff             	cmp    $0xffffffff,%ebp
    4295:	74 21                	je     42b8 <descent_phase_step+0x68>
    4297:	48 8b 35 9a ce 01 00 	mov    0x1ce9a(%rip),%rsi        # 21138 <descent_last_ns>
    429e:	48 39 f0             	cmp    %rsi,%rax
    42a1:	72 4b                	jb     42ee <descent_phase_step+0x9e>
    42a3:	48 8d 0d 96 ce 01 00 	lea    0x1ce96(%rip),%rcx        # 21140 <descent_phase_ns>
    42aa:	48 8b 14 e9          	mov    (%rcx,%rbp,8),%rdx
    42ae:	48 29 f2             	sub    %rsi,%rdx
    42b1:	48 01 c2             	add    %rax,%rdx
    42b4:	48 89 14 e9          	mov    %rdx,(%rcx,%rbp,8)
    42b8:	83 fb 06             	cmp    $0x6,%ebx
    42bb:	75 0d                	jne    42ca <descent_phase_step+0x7a>
    42bd:	48 83 05 6b ce 01 00 	addq   $0x1,0x1ce6b(%rip)        # 21130 <descent_updates>
    42c4:	01 
    42c5:	bb ff ff ff ff       	mov    $0xffffffff,%ebx
    42ca:	89 1d 50 cd 00 00    	mov    %ebx,0xcd50(%rip)        # 11020 <descent_active_phase>
    42d0:	48 89 05 61 ce 01 00 	mov    %rax,0x1ce61(%rip)        # 21138 <descent_last_ns>
    42d7:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    42dc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    42e3:	00 00 
    42e5:	75 0c                	jne    42f3 <descent_phase_step+0xa3>
    42e7:	48 83 c4 28          	add    $0x28,%rsp
    42eb:	5b                   	pop    %rbx
    42ec:	5d                   	pop    %rbp
    42ed:	c3                   	ret
    42ee:	e8 ed fa ff ff       	call   3de0 <descent_phase_fail>
    42f3:	e8 68 f1 ff ff       	call   3460 <__stack_chk_fail@plt>
    42f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    42ff:	00 

0000000000004300 <fwp_cancel_tree.part.0>:
    4300:	48 3b 3d b9 d4 01 00 	cmp    0x1d4b9(%rip),%rdi        # 217c0 <fwp_cur>
    4307:	53                   	push   %rbx
    4308:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    430c:	74 35                	je     4343 <fwp_cancel_tree.part.0+0x43>
    430e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4312:	75 2f                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    4314:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4318:	75 29                	jne    4343 <fwp_cancel_tree.part.0+0x43>
    431a:	48 8b 05 7f d4 01 00 	mov    0x1d47f(%rip),%rax        # 217a0 <fwp_ready_tail>
    4321:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4325:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    432c:	00 00 00 00 
    4330:	48 85 c0             	test   %rax,%rax
    4333:	74 33                	je     4368 <fwp_cancel_tree.part.0+0x68>
    4335:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    433c:	48 89 3d 5d d4 01 00 	mov    %rdi,0x1d45d(%rip)        # 217a0 <fwp_ready_tail>
    4343:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4347:	48 85 db             	test   %rbx,%rbx
    434a:	74 17                	je     4363 <fwp_cancel_tree.part.0+0x63>
    434c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4350:	75 08                	jne    435a <fwp_cancel_tree.part.0+0x5a>
    4352:	48 89 df             	mov    %rbx,%rdi
    4355:	e8 a6 ff ff ff       	call   4300 <fwp_cancel_tree.part.0>
    435a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    435e:	48 85 db             	test   %rbx,%rbx
    4361:	75 e9                	jne    434c <fwp_cancel_tree.part.0+0x4c>
    4363:	5b                   	pop    %rbx
    4364:	c3                   	ret
    4365:	0f 1f 00             	nopl   (%rax)
    4368:	48 89 3d 39 d4 01 00 	mov    %rdi,0x1d439(%rip)        # 217a8 <fwp_ready_head>
    436f:	eb cb                	jmp    433c <fwp_cancel_tree.part.0+0x3c>
    4371:	0f 1f 40 00          	nopl   0x0(%rax)
    4375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    437c:	00 00 00 00 

0000000000004380 <fwp_finish_float>:
    4380:	53                   	push   %rbx
    4381:	be 2e 00 00 00       	mov    $0x2e,%esi
    4386:	48 89 fb             	mov    %rdi,%rbx
    4389:	e8 f2 f0 ff ff       	call   3480 <strchr@plt>
    438e:	48 85 c0             	test   %rax,%rax
    4391:	74 05                	je     4398 <fwp_finish_float+0x18>
    4393:	5b                   	pop    %rbx
    4394:	c3                   	ret
    4395:	0f 1f 00             	nopl   (%rax)
    4398:	be 65 00 00 00       	mov    $0x65,%esi
    439d:	48 89 df             	mov    %rbx,%rdi
    43a0:	e8 db f0 ff ff       	call   3480 <strchr@plt>
    43a5:	48 85 c0             	test   %rax,%rax
    43a8:	75 e9                	jne    4393 <fwp_finish_float+0x13>
    43aa:	48 8d 35 18 8e 00 00 	lea    0x8e18(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    43b1:	48 89 df             	mov    %rbx,%rdi
    43b4:	e8 17 f3 ff ff       	call   36d0 <strstr@plt>
    43b9:	48 85 c0             	test   %rax,%rax
    43bc:	75 d5                	jne    4393 <fwp_finish_float+0x13>
    43be:	48 8d 35 ba 8c 00 00 	lea    0x8cba(%rip),%rsi        # d07f <_IO_stdin_used+0x7f>
    43c5:	48 89 df             	mov    %rbx,%rdi
    43c8:	e8 03 f3 ff ff       	call   36d0 <strstr@plt>
    43cd:	48 85 c0             	test   %rax,%rax
    43d0:	75 c1                	jne    4393 <fwp_finish_float+0x13>
    43d2:	48 89 df             	mov    %rbx,%rdi
    43d5:	e8 76 f0 ff ff       	call   3450 <strlen@plt>
    43da:	ba 2e 30 00 00       	mov    $0x302e,%edx
    43df:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    43e3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    43e8:	5b                   	pop    %rbx
    43e9:	c3                   	ret
    43ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000043f0 <fwp_trap>:
    43f0:	55                   	push   %rbp
    43f1:	48 89 fd             	mov    %rdi,%rbp
    43f4:	53                   	push   %rbx
    43f5:	48 83 ec 08          	sub    $0x8,%rsp
    43f9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4400:	ff ff 
    4402:	e8 69 f8 ff ff       	call   3c70 <fwp_flush>
    4407:	31 c0                	xor    %eax,%eax
    4409:	48 89 e9             	mov    %rbp,%rcx
    440c:	be 02 00 00 00       	mov    $0x2,%esi
    4411:	48 8b 3d 48 cc 00 00 	mov    0xcc48(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4418:	48 8d 15 64 8c 00 00 	lea    0x8c64(%rip),%rdx        # d083 <_IO_stdin_used+0x83>
    441f:	e8 6c f2 ff ff       	call   3690 <__fprintf_chk@plt>
    4424:	48 85 db             	test   %rbx,%rbx
    4427:	74 16                	je     443f <fwp_trap+0x4f>
    4429:	48 8b 3d 30 cc 00 00 	mov    0xcc30(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4430:	e8 8b f1 ff ff       	call   35c0 <fflush@plt>
    4435:	bf 65 00 00 00       	mov    $0x65,%edi
    443a:	e8 61 f2 ff ff       	call   36a0 <_Exit@plt>
    443f:	bf 65 00 00 00       	mov    $0x65,%edi
    4444:	e8 27 f2 ff ff       	call   3670 <exit@plt>
    4449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004450 <fwp_closure_drop_push>:
    4450:	41 56                	push   %r14
    4452:	41 54                	push   %r12
    4454:	49 89 f4             	mov    %rsi,%r12
    4457:	55                   	push   %rbp
    4458:	48 89 fd             	mov    %rdi,%rbp
    445b:	53                   	push   %rbx
    445c:	48 83 ec 18          	sub    $0x18,%rsp
    4460:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4464:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4468:	74 26                	je     4490 <fwp_closure_drop_push+0x40>
    446a:	4c 8b 07             	mov    (%rdi),%r8
    446d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4474:	00 
    4475:	48 83 c3 01          	add    $0x1,%rbx
    4479:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    447d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4481:	48 83 c4 18          	add    $0x18,%rsp
    4485:	5b                   	pop    %rbx
    4486:	5d                   	pop    %rbp
    4487:	41 5c                	pop    %r12
    4489:	41 5e                	pop    %r14
    448b:	c3                   	ret
    448c:	0f 1f 40 00          	nopl   0x0(%rax)
    4490:	48 89 d8             	mov    %rbx,%rax
    4493:	48 c1 e8 3c          	shr    $0x3c,%rax
    4497:	0f 85 a9 00 00 00    	jne    4546 <fwp_closure_drop_push+0xf6>
    449d:	48 89 d9             	mov    %rbx,%rcx
    44a0:	48 c1 e1 04          	shl    $0x4,%rcx
    44a4:	48 89 cf             	mov    %rcx,%rdi
    44a7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44ab:	e8 00 f1 ff ff       	call   35b0 <malloc@plt>
    44b0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44b4:	48 85 c0             	test   %rax,%rax
    44b7:	74 5f                	je     4518 <fwp_closure_drop_push+0xc8>
    44b9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44bd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44c4:	00 
    44c5:	48 89 c7             	mov    %rax,%rdi
    44c8:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    44cc:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    44d1:	48 89 34 24          	mov    %rsi,(%rsp)
    44d5:	e8 96 f0 ff ff       	call   3570 <__memcpy_chk@plt>
    44da:	48 8b 34 24          	mov    (%rsp),%rsi
    44de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    44e3:	49 89 c0             	mov    %rax,%r8
    44e6:	48 8d 45 18          	lea    0x18(%rbp),%rax
    44ea:	48 39 c6             	cmp    %rax,%rsi
    44ed:	74 1c                	je     450b <fwp_closure_drop_push+0xbb>
    44ef:	48 89 f7             	mov    %rsi,%rdi
    44f2:	4c 89 04 24          	mov    %r8,(%rsp)
    44f6:	e8 c5 ee ff ff       	call   33c0 <free@plt>
    44fb:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    44ff:	4c 8b 04 24          	mov    (%rsp),%r8
    4503:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    450a:	00 
    450b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    450f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4513:	e9 5d ff ff ff       	jmp    4475 <fwp_closure_drop_push+0x25>
    4518:	48 8b 0d 41 cb 00 00 	mov    0xcb41(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    451f:	ba 13 00 00 00       	mov    $0x13,%edx
    4524:	be 01 00 00 00       	mov    $0x1,%esi
    4529:	48 8d 3d d8 8a 00 00 	lea    0x8ad8(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    4530:	e8 4b f1 ff ff       	call   3680 <fwrite@plt>
    4535:	31 ff                	xor    %edi,%edi
    4537:	e8 84 f0 ff ff       	call   35c0 <fflush@plt>
    453c:	bf 66 00 00 00       	mov    $0x66,%edi
    4541:	e8 5a f1 ff ff       	call   36a0 <_Exit@plt>
    4546:	48 8d 3d 45 8b 00 00 	lea    0x8b45(%rip),%rdi        # d092 <_IO_stdin_used+0x92>
    454d:	e8 9e fe ff ff       	call   43f0 <fwp_trap>
    4552:	0f 1f 00             	nopl   (%rax)
    4555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    455c:	00 00 00 00 

0000000000004560 <fwp_now_ns>:
    4560:	53                   	push   %rbx
    4561:	bf 01 00 00 00       	mov    $0x1,%edi
    4566:	48 83 ec 20          	sub    $0x20,%rsp
    456a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4571:	00 00 
    4573:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4578:	31 db                	xor    %ebx,%ebx
    457a:	48 89 e6             	mov    %rsp,%rsi
    457d:	e8 9e ee ff ff       	call   3420 <clock_gettime@plt>
    4582:	85 c0                	test   %eax,%eax
    4584:	75 52                	jne    45d8 <fwp_now_ns+0x78>
    4586:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    458b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4590:	48 f7 2c 24          	imulq  (%rsp)
    4594:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    459b:	48 89 f7             	mov    %rsi,%rdi
    459e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45a2:	48 01 f0             	add    %rsi,%rax
    45a5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ac:	00 00 80 
    45af:	48 11 fa             	adc    %rdi,%rdx
    45b2:	31 ff                	xor    %edi,%edi
    45b4:	48 01 c6             	add    %rax,%rsi
    45b7:	48 11 d7             	adc    %rdx,%rdi
    45ba:	48 39 f1             	cmp    %rsi,%rcx
    45bd:	48 19 fb             	sbb    %rdi,%rbx
    45c0:	72 27                	jb     45e9 <fwp_now_ns+0x89>
    45c2:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    45c7:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    45ce:	00 00 
    45d0:	75 12                	jne    45e4 <fwp_now_ns+0x84>
    45d2:	48 83 c4 20          	add    $0x20,%rsp
    45d6:	5b                   	pop    %rbx
    45d7:	c3                   	ret
    45d8:	48 8d 3d cd 8a 00 00 	lea    0x8acd(%rip),%rdi        # d0ac <_IO_stdin_used+0xac>
    45df:	e8 0c fe ff ff       	call   43f0 <fwp_trap>
    45e4:	e8 77 ee ff ff       	call   3460 <__stack_chk_fail@plt>
    45e9:	48 8d 3d 10 91 00 00 	lea    0x9110(%rip),%rdi        # d700 <_IO_stdin_used+0x700>
    45f0:	e8 fb fd ff ff       	call   43f0 <fwp_trap>
    45f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    45fc:	00 00 00 00 

0000000000004600 <fwp_closure_drop.part.0>:
    4600:	53                   	push   %rbx
    4601:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4608:	66 0f 6f 05 80 95 00 	movdqa 0x9580(%rip),%xmm0        # db90 <msg.4+0x20>
    460f:	00 
    4610:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4617:	00 00 
    4619:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4620:	00 
    4621:	48 89 fe             	mov    %rdi,%rsi
    4624:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4629:	48 89 e7             	mov    %rsp,%rdi
    462c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4630:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4635:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    463c:	ff ff 
    463e:	e8 0d fe ff ff       	call   4450 <fwp_closure_drop_push>
    4643:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4648:	48 85 c0             	test   %rax,%rax
    464b:	74 39                	je     4686 <fwp_closure_drop.part.0+0x86>
    464d:	0f 1f 00             	nopl   (%rax)
    4650:	48 8b 14 24          	mov    (%rsp),%rdx
    4654:	48 83 e8 01          	sub    $0x1,%rax
    4658:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    465d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4661:	8b 07                	mov    (%rdi),%eax
    4663:	48 c1 e0 05          	shl    $0x5,%rax
    4667:	48 03 05 ca ed 01 00 	add    0x1edca(%rip),%rax        # 23438 <fwp_fns>
    466e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4672:	48 85 c0             	test   %rax,%rax
    4675:	74 46                	je     46bd <fwp_closure_drop.part.0+0xbd>
    4677:	31 f6                	xor    %esi,%esi
    4679:	ff 50 08             	call   *0x8(%rax)
    467c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4681:	48 85 c0             	test   %rax,%rax
    4684:	75 ca                	jne    4650 <fwp_closure_drop.part.0+0x50>
    4686:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    468d:	ff ff 00 00 00 00 
    4693:	48 8b 3c 24          	mov    (%rsp),%rdi
    4697:	48 39 df             	cmp    %rbx,%rdi
    469a:	74 05                	je     46a1 <fwp_closure_drop.part.0+0xa1>
    469c:	e8 1f ed ff ff       	call   33c0 <free@plt>
    46a1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46a8:	00 
    46a9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46b0:	00 00 
    46b2:	75 15                	jne    46c9 <fwp_closure_drop.part.0+0xc9>
    46b4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46bb:	5b                   	pop    %rbx
    46bc:	c3                   	ret
    46bd:	48 8d 3d 64 90 00 00 	lea    0x9064(%rip),%rdi        # d728 <_IO_stdin_used+0x728>
    46c4:	e8 27 fd ff ff       	call   43f0 <fwp_trap>
    46c9:	e8 92 ed ff ff       	call   3460 <__stack_chk_fail@plt>
    46ce:	66 90                	xchg   %ax,%ax

00000000000046d0 <fwp_tape_of>:
    46d0:	0f b7 d7             	movzwl %di,%edx
    46d3:	48 85 d2             	test   %rdx,%rdx
    46d6:	74 28                	je     4700 <fwp_tape_of+0x30>
    46d8:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    46dc:	48 39 05 25 ca 01 00 	cmp    %rax,0x1ca25(%rip)        # 21108 <fwp_ntapes>
    46e3:	7e 1b                	jle    4700 <fwp_tape_of+0x30>
    46e5:	48 6b c0 68          	imul   $0x68,%rax,%rax
    46e9:	48 03 05 20 ca 01 00 	add    0x1ca20(%rip),%rax        # 21110 <fwp_tapes>
    46f0:	8b 50 04             	mov    0x4(%rax),%edx
    46f3:	85 d2                	test   %edx,%edx
    46f5:	74 09                	je     4700 <fwp_tape_of+0x30>
    46f7:	48 c1 ff 10          	sar    $0x10,%rdi
    46fb:	39 38                	cmp    %edi,(%rax)
    46fd:	75 01                	jne    4700 <fwp_tape_of+0x30>
    46ff:	c3                   	ret
    4700:	48 83 ec 08          	sub    $0x8,%rsp
    4704:	48 8d 3d 4d 90 00 00 	lea    0x904d(%rip),%rdi        # d758 <_IO_stdin_used+0x758>
    470b:	e8 e0 fc ff ff       	call   43f0 <fwp_trap>

0000000000004710 <fwp_format_g.constprop.0>:
    4710:	41 57                	push   %r15
    4712:	b9 40 00 00 00       	mov    $0x40,%ecx
    4717:	ba 02 00 00 00       	mov    $0x2,%edx
    471c:	4c 8d 05 a5 89 00 00 	lea    0x89a5(%rip),%r8        # d0c8 <_IO_stdin_used+0xc8>
    4723:	41 56                	push   %r14
    4725:	b8 01 00 00 00       	mov    $0x1,%eax
    472a:	41 55                	push   %r13
    472c:	41 54                	push   %r12
    472e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4732:	55                   	push   %rbp
    4733:	45 89 e1             	mov    %r12d,%r9d
    4736:	53                   	push   %rbx
    4737:	48 89 fb             	mov    %rdi,%rbx
    473a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4741:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4748:	00 00 
    474a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4751:	00 
    4752:	41 89 f7             	mov    %esi,%r15d
    4755:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    475a:	be 40 00 00 00       	mov    $0x40,%esi
    475f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4764:	4c 89 f7             	mov    %r14,%rdi
    4767:	e8 44 ec ff ff       	call   33b0 <__snprintf_chk@plt>
    476c:	be 65 00 00 00       	mov    $0x65,%esi
    4771:	4c 89 f7             	mov    %r14,%rdi
    4774:	e8 07 ed ff ff       	call   3480 <strchr@plt>
    4779:	31 f6                	xor    %esi,%esi
    477b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4780:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4784:	48 89 c5             	mov    %rax,%rbp
    4787:	e8 04 ee ff ff       	call   3590 <strtol@plt>
    478c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4791:	49 89 c0             	mov    %rax,%r8
    4794:	83 c0 05             	add    $0x5,%eax
    4797:	83 f8 15             	cmp    $0x15,%eax
    479a:	0f 87 e0 01 00 00    	ja     4980 <fwp_format_g.constprop.0+0x270>
    47a0:	45 89 e5             	mov    %r12d,%r13d
    47a3:	45 29 c5             	sub    %r8d,%r13d
    47a6:	45 85 ed             	test   %r13d,%r13d
    47a9:	0f 8e 21 01 00 00    	jle    48d0 <fwp_format_g.constprop.0+0x1c0>
    47af:	41 83 ff 01          	cmp    $0x1,%r15d
    47b3:	0f 84 17 01 00 00    	je     48d0 <fwp_format_g.constprop.0+0x1c0>
    47b9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47be:	31 d2                	xor    %edx,%edx
    47c0:	4d 63 df             	movslq %r15d,%r11
    47c3:	3c 2d                	cmp    $0x2d,%al
    47c5:	0f 94 c2             	sete   %dl
    47c8:	4c 29 dd             	sub    %r11,%rbp
    47cb:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    47cf:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    47d3:	4d 89 f1             	mov    %r14,%r9
    47d6:	4d 29 d1             	sub    %r10,%r9
    47d9:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    47dd:	3c 2d                	cmp    $0x2d,%al
    47df:	0f 84 fb 03 00 00    	je     4be0 <fwp_format_g.constprop.0+0x4d0>
    47e5:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    47ea:	b9 48 00 00 00       	mov    $0x48,%ecx
    47ef:	48 89 e8             	mov    %rbp,%rax
    47f2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47f6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    47fa:	49 83 c1 47          	add    $0x47,%r9
    47fe:	45 85 c0             	test   %r8d,%r8d
    4801:	0f 88 f1 02 00 00    	js     4af8 <fwp_format_g.constprop.0+0x3e8>
    4807:	45 0f b6 12          	movzbl (%r10),%r10d
    480b:	4d 63 e0             	movslq %r8d,%r12
    480e:	44 88 10             	mov    %r10b,(%rax)
    4811:	41 83 f8 07          	cmp    $0x7,%r8d
    4815:	0f 87 2d 02 00 00    	ja     4a48 <fwp_format_g.constprop.0+0x338>
    481b:	41 f6 c4 04          	test   $0x4,%r12b
    481f:	0f 85 f2 03 00 00    	jne    4c17 <fwp_format_g.constprop.0+0x507>
    4825:	45 85 e4             	test   %r12d,%r12d
    4828:	74 12                	je     483c <fwp_format_g.constprop.0+0x12c>
    482a:	45 0f b6 06          	movzbl (%r14),%r8d
    482e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4832:	41 f6 c4 02          	test   $0x2,%r12b
    4836:	0f 85 03 04 00 00    	jne    4c3f <fwp_format_g.constprop.0+0x52f>
    483c:	4c 29 e1             	sub    %r12,%rcx
    483f:	4c 01 e7             	add    %r12,%rdi
    4842:	4c 89 fa             	mov    %r15,%rdx
    4845:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    484a:	48 83 e9 01          	sub    $0x1,%rcx
    484e:	4d 63 ed             	movslq %r13d,%r13
    4851:	48 89 0c 24          	mov    %rcx,(%rsp)
    4855:	e8 16 ed ff ff       	call   3570 <__memcpy_chk@plt>
    485a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	ba 48 00 00 00       	mov    $0x48,%edx
    4868:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    486c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4870:	4c 89 c8             	mov    %r9,%rax
    4873:	48 29 c8             	sub    %rcx,%rax
    4876:	48 39 d0             	cmp    %rdx,%rax
    4879:	48 0f 42 c2          	cmovb  %rdx,%rax
    487d:	4c 29 c9             	sub    %r9,%rcx
    4880:	4c 89 ea             	mov    %r13,%rdx
    4883:	48 01 c1             	add    %rax,%rcx
    4886:	e8 e5 ec ff ff       	call   3570 <__memcpy_chk@plt>
    488b:	4c 01 e8             	add    %r13,%rax
    488e:	48 29 e8             	sub    %rbp,%rax
    4891:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4896:	48 39 d0             	cmp    %rdx,%rax
    4899:	48 0f 47 c2          	cmova  %rdx,%rax
    489d:	89 c1                	mov    %eax,%ecx
    489f:	83 f8 08             	cmp    $0x8,%eax
    48a2:	0f 83 18 02 00 00    	jae    4ac0 <fwp_format_g.constprop.0+0x3b0>
    48a8:	a8 04                	test   $0x4,%al
    48aa:	0f 85 54 03 00 00    	jne    4c04 <fwp_format_g.constprop.0+0x4f4>
    48b0:	85 c0                	test   %eax,%eax
    48b2:	74 0f                	je     48c3 <fwp_format_g.constprop.0+0x1b3>
    48b4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48b9:	88 13                	mov    %dl,(%rbx)
    48bb:	a8 02                	test   $0x2,%al
    48bd:	0f 85 6b 03 00 00    	jne    4c2e <fwp_format_g.constprop.0+0x51e>
    48c3:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    48c7:	eb 36                	jmp    48ff <fwp_format_g.constprop.0+0x1ef>
    48c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    48d0:	45 31 c9             	xor    %r9d,%r9d
    48d3:	45 85 ed             	test   %r13d,%r13d
    48d6:	4c 8d 05 fa 87 00 00 	lea    0x87fa(%rip),%r8        # d0d7 <_IO_stdin_used+0xd7>
    48dd:	48 89 df             	mov    %rbx,%rdi
    48e0:	45 0f 49 cd          	cmovns %r13d,%r9d
    48e4:	ba 02 00 00 00       	mov    $0x2,%edx
    48e9:	be 90 01 00 00       	mov    $0x190,%esi
    48ee:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    48f5:	b8 01 00 00 00       	mov    $0x1,%eax
    48fa:	e8 b1 ea ff ff       	call   33b0 <__snprintf_chk@plt>
    48ff:	be 2e 00 00 00       	mov    $0x2e,%esi
    4904:	48 89 df             	mov    %rbx,%rdi
    4907:	e8 74 eb ff ff       	call   3480 <strchr@plt>
    490c:	48 85 c0             	test   %rax,%rax
    490f:	74 3f                	je     4950 <fwp_format_g.constprop.0+0x240>
    4911:	48 89 df             	mov    %rbx,%rdi
    4914:	e8 37 eb ff ff       	call   3450 <strlen@plt>
    4919:	48 85 c0             	test   %rax,%rax
    491c:	75 0b                	jne    4929 <fwp_format_g.constprop.0+0x219>
    491e:	eb 30                	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4920:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4924:	48 85 c0             	test   %rax,%rax
    4927:	74 27                	je     4950 <fwp_format_g.constprop.0+0x240>
    4929:	48 89 c2             	mov    %rax,%rdx
    492c:	48 83 e8 01          	sub    $0x1,%rax
    4930:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4934:	74 ea                	je     4920 <fwp_format_g.constprop.0+0x210>
    4936:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    493b:	0f 84 6f 01 00 00    	je     4ab0 <fwp_format_g.constprop.0+0x3a0>
    4941:	0f 1f 40 00          	nopl   0x0(%rax)
    4945:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    494c:	00 00 00 00 
    4950:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4957:	00 
    4958:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    495f:	00 00 
    4961:	0f 85 ec 02 00 00    	jne    4c53 <fwp_format_g.constprop.0+0x543>
    4967:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    496e:	5b                   	pop    %rbx
    496f:	5d                   	pop    %rbp
    4970:	41 5c                	pop    %r12
    4972:	41 5d                	pop    %r13
    4974:	41 5e                	pop    %r14
    4976:	41 5f                	pop    %r15
    4978:	c3                   	ret
    4979:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4980:	4c 29 f5             	sub    %r14,%rbp
    4983:	b9 40 00 00 00       	mov    $0x40,%ecx
    4988:	4c 89 f6             	mov    %r14,%rsi
    498b:	4c 89 04 24          	mov    %r8,(%rsp)
    498f:	49 89 ec             	mov    %rbp,%r12
    4992:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4997:	4c 89 e2             	mov    %r12,%rdx
    499a:	48 89 ef             	mov    %rbp,%rdi
    499d:	e8 ce eb ff ff       	call   3570 <__memcpy_chk@plt>
    49a2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49a8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ad:	48 89 ef             	mov    %rbp,%rdi
    49b0:	e8 cb ea ff ff       	call   3480 <strchr@plt>
    49b5:	4c 8b 04 24          	mov    (%rsp),%r8
    49b9:	48 85 c0             	test   %rax,%rax
    49bc:	74 40                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49be:	4d 85 e4             	test   %r12,%r12
    49c1:	74 3b                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49c3:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    49c8:	eb 23                	jmp    49ed <fwp_format_g.constprop.0+0x2dd>
    49ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49d1:	00 00 00 00 
    49d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    49dc:	00 00 00 00 
    49e0:	c6 00 00             	movb   $0x0,(%rax)
    49e3:	48 83 e8 01          	sub    $0x1,%rax
    49e7:	49 83 ec 01          	sub    $0x1,%r12
    49eb:	74 11                	je     49fe <fwp_format_g.constprop.0+0x2ee>
    49ed:	80 38 30             	cmpb   $0x30,(%rax)
    49f0:	74 ee                	je     49e0 <fwp_format_g.constprop.0+0x2d0>
    49f2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    49f8:	0f 84 fb 01 00 00    	je     4bf9 <fwp_format_g.constprop.0+0x4e9>
    49fe:	44 89 c0             	mov    %r8d,%eax
    4a01:	ba 02 00 00 00       	mov    $0x2,%edx
    4a06:	49 89 e9             	mov    %rbp,%r9
    4a09:	be 90 01 00 00       	mov    $0x190,%esi
    4a0e:	f7 d8                	neg    %eax
    4a10:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a17:	48 89 df             	mov    %rbx,%rdi
    4a1a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a1e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a22:	41 83 e0 02          	and    $0x2,%r8d
    4a26:	41 83 c0 2b          	add    $0x2b,%r8d
    4a2a:	50                   	push   %rax
    4a2b:	31 c0                	xor    %eax,%eax
    4a2d:	41 50                	push   %r8
    4a2f:	4c 8d 05 97 86 00 00 	lea    0x8697(%rip),%r8        # d0cd <_IO_stdin_used+0xcd>
    4a36:	e8 75 e9 ff ff       	call   33b0 <__snprintf_chk@plt>
    4a3b:	58                   	pop    %rax
    4a3c:	5a                   	pop    %rdx
    4a3d:	e9 0e ff ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a48:	4d 8b 06             	mov    (%r14),%r8
    4a4b:	48 83 c0 09          	add    $0x9,%rax
    4a4f:	4c 89 f2             	mov    %r14,%rdx
    4a52:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a56:	4c 89 07             	mov    %r8,(%rdi)
    4a59:	45 89 e0             	mov    %r12d,%r8d
    4a5c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4a61:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4a66:	49 89 f8             	mov    %rdi,%r8
    4a69:	49 29 c0             	sub    %rax,%r8
    4a6c:	4c 29 c2             	sub    %r8,%rdx
    4a6f:	45 01 e0             	add    %r12d,%r8d
    4a72:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a76:	41 83 f8 08          	cmp    $0x8,%r8d
    4a7a:	0f 82 bc fd ff ff    	jb     483c <fwp_format_g.constprop.0+0x12c>
    4a80:	48 89 0c 24          	mov    %rcx,(%rsp)
    4a84:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4a88:	45 31 d2             	xor    %r10d,%r10d
    4a8b:	45 89 d3             	mov    %r10d,%r11d
    4a8e:	41 83 c2 08          	add    $0x8,%r10d
    4a92:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4a96:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4a9a:	45 39 c2             	cmp    %r8d,%r10d
    4a9d:	72 ec                	jb     4a8b <fwp_format_g.constprop.0+0x37b>
    4a9f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4aa3:	e9 94 fd ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4aa8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aaf:	00 
    4ab0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4ab5:	e9 96 fe ff ff       	jmp    4950 <fwp_format_g.constprop.0+0x240>
    4aba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4ac0:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4ac5:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4ac9:	48 89 ee             	mov    %rbp,%rsi
    4acc:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4ad0:	48 89 13             	mov    %rdx,(%rbx)
    4ad3:	89 c2                	mov    %eax,%edx
    4ad5:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4ada:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4adf:	48 89 d9             	mov    %rbx,%rcx
    4ae2:	48 29 f9             	sub    %rdi,%rcx
    4ae5:	48 29 ce             	sub    %rcx,%rsi
    4ae8:	01 c1                	add    %eax,%ecx
    4aea:	c1 e9 03             	shr    $0x3,%ecx
    4aed:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4af0:	e9 ce fd ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4af5:	0f 1f 00             	nopl   (%rax)
    4af8:	c6 00 30             	movb   $0x30,(%rax)
    4afb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4aff:	4c 89 fa             	mov    %r15,%rdx
    4b02:	4c 89 e9             	mov    %r13,%rcx
    4b05:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b0a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b0f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b13:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b18:	e8 53 ea ff ff       	call   3570 <__memcpy_chk@plt>
    4b1d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b22:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b27:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b2c:	48 89 c7             	mov    %rax,%rdi
    4b2f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b33:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b38:	4c 89 c8             	mov    %r9,%rax
    4b3b:	4c 29 e8             	sub    %r13,%rax
    4b3e:	48 39 c8             	cmp    %rcx,%rax
    4b41:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b45:	4d 29 cd             	sub    %r9,%r13
    4b48:	49 01 ff             	add    %rdi,%r15
    4b4b:	4c 01 e8             	add    %r13,%rax
    4b4e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b52:	74 3d                	je     4b91 <fwp_format_g.constprop.0+0x481>
    4b54:	41 f7 d0             	not    %r8d
    4b57:	31 f6                	xor    %esi,%esi
    4b59:	ba 48 00 00 00       	mov    $0x48,%edx
    4b5e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4b63:	48 39 d0             	cmp    %rdx,%rax
    4b66:	48 0f 43 d0          	cmovae %rax,%rdx
    4b6a:	48 89 d1             	mov    %rdx,%rcx
    4b6d:	48 29 c1             	sub    %rax,%rcx
    4b70:	48 83 c1 01          	add    $0x1,%rcx
    4b74:	48 39 d1             	cmp    %rdx,%rcx
    4b77:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4b7b:	48 83 e8 01          	sub    $0x1,%rax
    4b7f:	48 83 c6 01          	add    $0x1,%rsi
    4b83:	48 29 d0             	sub    %rdx,%rax
    4b86:	48 01 c8             	add    %rcx,%rax
    4b89:	41 39 f0             	cmp    %esi,%r8d
    4b8c:	7f cb                	jg     4b59 <fwp_format_g.constprop.0+0x449>
    4b8e:	4d 01 c7             	add    %r8,%r15
    4b91:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b96:	41 0f b6 12          	movzbl (%r10),%edx
    4b9a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4b9e:	4c 89 f6             	mov    %r14,%rsi
    4ba1:	48 39 c8             	cmp    %rcx,%rax
    4ba4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4ba8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bac:	41 88 17             	mov    %dl,(%r15)
    4baf:	48 89 ca             	mov    %rcx,%rdx
    4bb2:	48 29 c2             	sub    %rax,%rdx
    4bb5:	48 83 c2 01          	add    $0x1,%rdx
    4bb9:	48 39 ca             	cmp    %rcx,%rdx
    4bbc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4bc0:	48 83 e8 01          	sub    $0x1,%rax
    4bc4:	48 29 c8             	sub    %rcx,%rax
    4bc7:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4bcb:	49 63 d4             	movslq %r12d,%rdx
    4bce:	e8 9d e9 ff ff       	call   3570 <__memcpy_chk@plt>
    4bd3:	4c 8b 1c 24          	mov    (%rsp),%r11
    4bd7:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4bdb:	e9 ae fc ff ff       	jmp    488e <fwp_format_g.constprop.0+0x17e>
    4be0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4be5:	b9 47 00 00 00       	mov    $0x47,%ecx
    4bea:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4bef:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4bf4:	e9 f9 fb ff ff       	jmp    47f2 <fwp_format_g.constprop.0+0xe2>
    4bf9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4bff:	e9 fa fd ff ff       	jmp    49fe <fwp_format_g.constprop.0+0x2ee>
    4c04:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c08:	89 13                	mov    %edx,(%rbx)
    4c0a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c0e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c12:	e9 ac fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c17:	41 8b 06             	mov    (%r14),%eax
    4c1a:	89 07                	mov    %eax,(%rdi)
    4c1c:	44 89 e0             	mov    %r12d,%eax
    4c1f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c24:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c29:	e9 0e fc ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c2e:	89 c2                	mov    %eax,%edx
    4c30:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c35:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c3a:	e9 84 fc ff ff       	jmp    48c3 <fwp_format_g.constprop.0+0x1b3>
    4c3f:	44 89 e0             	mov    %r12d,%eax
    4c42:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c48:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c4e:	e9 e9 fb ff ff       	jmp    483c <fwp_format_g.constprop.0+0x12c>
    4c53:	e8 08 e8 ff ff       	call   3460 <__stack_chk_fail@plt>
    4c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c5f:	00 

0000000000004c60 <fwp_heap_report>:
    4c60:	f3 0f 1e fa          	endbr64
    4c64:	41 54                	push   %r12
    4c66:	48 8d 3d 6f 84 00 00 	lea    0x846f(%rip),%rdi        # d0dc <_IO_stdin_used+0xdc>
    4c6d:	55                   	push   %rbp
    4c6e:	53                   	push   %rbx
    4c6f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4c76:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4c7d:	00 00 
    4c7f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4c86:	00 
    4c87:	48 8d 35 7e 85 00 00 	lea    0x857e(%rip),%rsi        # d20c <_IO_stdin_used+0x20c>
    4c8e:	e8 9d e9 ff ff       	call   3630 <fopen@plt>
    4c93:	48 85 c0             	test   %rax,%rax
    4c96:	0f 84 c5 00 00 00    	je     4d61 <fwp_heap_report+0x101>
    4c9c:	48 89 c5             	mov    %rax,%rbp
    4c9f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ca6:	48 89 e3             	mov    %rsp,%rbx
    4ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cb0:	48 89 ea             	mov    %rbp,%rdx
    4cb3:	be 00 01 00 00       	mov    $0x100,%esi
    4cb8:	48 89 df             	mov    %rbx,%rdi
    4cbb:	e8 40 e8 ff ff       	call   3500 <fgets@plt>
    4cc0:	48 85 c0             	test   %rax,%rax
    4cc3:	74 2b                	je     4cf0 <fwp_heap_report+0x90>
    4cc5:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4ccb:	75 e3                	jne    4cb0 <fwp_heap_report+0x50>
    4ccd:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4cd1:	75 dd                	jne    4cb0 <fwp_heap_report+0x50>
    4cd3:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4cd8:	75 d6                	jne    4cb0 <fwp_heap_report+0x50>
    4cda:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4cdf:	ba 0a 00 00 00       	mov    $0xa,%edx
    4ce4:	31 f6                	xor    %esi,%esi
    4ce6:	e8 a5 e8 ff ff       	call   3590 <strtol@plt>
    4ceb:	49 89 c4             	mov    %rax,%r12
    4cee:	eb c0                	jmp    4cb0 <fwp_heap_report+0x50>
    4cf0:	48 89 ef             	mov    %rbp,%rdi
    4cf3:	e8 48 e7 ff ff       	call   3440 <fclose@plt>
    4cf8:	48 83 ec 08          	sub    $0x8,%rsp
    4cfc:	4c 8b 0d a5 de 01 00 	mov    0x1dea5(%rip),%r9        # 22ba8 <fwp_heap+0x13c8>
    4d03:	4c 8b 05 fe de 01 00 	mov    0x1defe(%rip),%r8        # 22c08 <fwp_heap+0x1428>
    4d0a:	48 8d 15 97 8a 00 00 	lea    0x8a97(%rip),%rdx        # d7a8 <_IO_stdin_used+0x7a8>
    4d11:	41 54                	push   %r12
    4d13:	48 8b 0d e6 de 01 00 	mov    0x1dee6(%rip),%rcx        # 22c00 <fwp_heap+0x1420>
    4d1a:	be 02 00 00 00       	mov    $0x2,%esi
    4d1f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d24:	f2 0f 10 0d f4 de 01 	movsd  0x1def4(%rip),%xmm1        # 22c20 <fwp_heap+0x1440>
    4d2b:	00 
    4d2c:	f2 0f 10 05 e4 de 01 	movsd  0x1dee4(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    4d33:	00 
    4d34:	48 8b 3d 25 c3 00 00 	mov    0xc325(%rip),%rdi        # 11060 <stderr@GLIBC_2.2.5>
    4d3b:	e8 50 e9 ff ff       	call   3690 <__fprintf_chk@plt>
    4d40:	58                   	pop    %rax
    4d41:	5a                   	pop    %rdx
    4d42:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d49:	00 
    4d4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d51:	00 00 
    4d53:	75 15                	jne    4d6a <fwp_heap_report+0x10a>
    4d55:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d5c:	5b                   	pop    %rbx
    4d5d:	5d                   	pop    %rbp
    4d5e:	41 5c                	pop    %r12
    4d60:	c3                   	ret
    4d61:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4d68:	eb 8e                	jmp    4cf8 <fwp_heap_report+0x98>
    4d6a:	e8 f1 e6 ff ff       	call   3460 <__stack_chk_fail@plt>
    4d6f:	90                   	nop

0000000000004d70 <fwp_heap_init>:
    4d70:	66 0f 6f 05 28 8e 00 	movdqa 0x8e28(%rip),%xmm0        # dba0 <msg.4+0x30>
    4d77:	00 
    4d78:	41 54                	push   %r12
    4d7a:	48 8d 05 9f d9 01 00 	lea    0x1d99f(%rip),%rax        # 22720 <fwp_heap+0xf40>
    4d81:	ba 00 01 00 00       	mov    $0x100,%edx
    4d86:	55                   	push   %rbp
    4d87:	66 0f 6f 15 51 8e 00 	movdqa 0x8e51(%rip),%xmm2        # dbe0 <msg.4+0x70>
    4d8e:	00 
    4d8f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4d93:	53                   	push   %rbx
    4d94:	0f 29 05 45 d9 01 00 	movaps %xmm0,0x1d945(%rip)        # 226e0 <fwp_heap+0xf00>
    4d9b:	66 0f 6f 05 0d 8e 00 	movdqa 0x8e0d(%rip),%xmm0        # dbb0 <msg.4+0x40>
    4da2:	00 
    4da3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4da7:	c7 05 d3 dd 01 00 01 	movl   $0x1,0x1ddd3(%rip)        # 22b84 <fwp_heap+0x13a4>
    4dae:	00 00 00 
    4db1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4db6:	0f 29 05 33 d9 01 00 	movaps %xmm0,0x1d933(%rip)        # 226f0 <fwp_heap+0xf10>
    4dbd:	66 0f 6f 05 fb 8d 00 	movdqa 0x8dfb(%rip),%xmm0        # dbc0 <msg.4+0x50>
    4dc4:	00 
    4dc5:	0f 29 05 34 d9 01 00 	movaps %xmm0,0x1d934(%rip)        # 22700 <fwp_heap+0xf20>
    4dcc:	66 0f 6f 05 fc 8d 00 	movdqa 0x8dfc(%rip),%xmm0        # dbd0 <msg.4+0x60>
    4dd3:	00 
    4dd4:	0f 29 05 35 d9 01 00 	movaps %xmm0,0x1d935(%rip)        # 22710 <fwp_heap+0xf30>
    4ddb:	89 d3                	mov    %edx,%ebx
    4ddd:	66 0f 6e e2          	movd   %edx,%xmm4
    4de1:	48 83 c0 10          	add    $0x10,%rax
    4de5:	01 d2                	add    %edx,%edx
    4de7:	c1 eb 02             	shr    $0x2,%ebx
    4dea:	66 0f 6e c3          	movd   %ebx,%xmm0
    4dee:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4df3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4df7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4dfc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e00:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e04:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e09:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e0e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e12:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e17:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e1b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e1f:	48 39 c7             	cmp    %rax,%rdi
    4e22:	75 b7                	jne    4ddb <fwp_heap_init+0x6b>
    4e24:	4c 8d 05 b5 c9 01 00 	lea    0x1c9b5(%rip),%r8        # 217e0 <fwp_heap>
    4e2b:	31 c9                	xor    %ecx,%ecx
    4e2d:	31 c0                	xor    %eax,%eax
    4e2f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e3d:	00 00 00 
    4e40:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e47:	00 
    4e48:	48 39 ca             	cmp    %rcx,%rdx
    4e4b:	73 0f                	jae    4e5c <fwp_heap_init+0xec>
    4e4d:	0f 1f 00             	nopl   (%rax)
    4e50:	48 83 c0 01          	add    $0x1,%rax
    4e54:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e57:	48 39 ca             	cmp    %rcx,%rdx
    4e5a:	72 f4                	jb     4e50 <fwp_heap_init+0xe0>
    4e5c:	48 83 c1 10          	add    $0x10,%rcx
    4e60:	88 07                	mov    %al,(%rdi)
    4e62:	48 83 c7 01          	add    $0x1,%rdi
    4e66:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4e6d:	75 d1                	jne    4e40 <fwp_heap_init+0xd0>
    4e6f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4e76:	00 00 00 
    4e79:	bd 05 00 00 00       	mov    $0x5,%ebp
    4e7e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4e85:	45 31 c9             	xor    %r9d,%r9d
    4e88:	31 d2                	xor    %edx,%edx
    4e8a:	31 ff                	xor    %edi,%edi
    4e8c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4e92:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4e97:	4c 89 e6             	mov    %r12,%rsi
    4e9a:	e8 d1 e5 ff ff       	call   3470 <mmap@plt>
    4e9f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ea3:	75 13                	jne    4eb8 <fwp_heap_init+0x148>
    4ea5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ea9:	83 ed 01             	sub    $0x1,%ebp
    4eac:	75 d0                	jne    4e7e <fwp_heap_init+0x10e>
    4eae:	e8 fd ed ff ff       	call   3cb0 <fwp_heap_oom>
    4eb3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4eb8:	48 85 c0             	test   %rax,%rax
    4ebb:	74 f1                	je     4eae <fwp_heap_init+0x13e>
    4ebd:	48 c1 eb 10          	shr    $0x10,%rbx
    4ec1:	48 89 05 d0 dc 01 00 	mov    %rax,0x1dcd0(%rip)        # 22b98 <fwp_heap+0x13b8>
    4ec8:	45 31 c9             	xor    %r9d,%r9d
    4ecb:	31 d2                	xor    %edx,%edx
    4ecd:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4ed3:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4ed7:	31 ff                	xor    %edi,%edi
    4ed9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4edf:	66 31 c0             	xor    %ax,%ax
    4ee2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ee6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4eeb:	4c 89 25 ae dc 01 00 	mov    %r12,0x1dcae(%rip)        # 22ba0 <fwp_heap+0x13c0>
    4ef2:	48 89 05 97 dc 01 00 	mov    %rax,0x1dc97(%rip)        # 22b90 <fwp_heap+0x13b0>
    4ef9:	48 89 1d b0 dc 01 00 	mov    %rbx,0x1dcb0(%rip)        # 22bb0 <fwp_heap+0x13d0>
    4f00:	48 89 35 d9 dc 01 00 	mov    %rsi,0x1dcd9(%rip)        # 22be0 <fwp_heap+0x1400>
    4f07:	e8 64 e5 ff ff       	call   3470 <mmap@plt>
    4f0c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f10:	74 9c                	je     4eae <fwp_heap_init+0x13e>
    4f12:	48 8d 3d f9 81 00 00 	lea    0x81f9(%rip),%rdi        # d112 <_IO_stdin_used+0x112>
    4f19:	48 89 05 b8 dc 01 00 	mov    %rax,0x1dcb8(%rip)        # 22bd8 <fwp_heap+0x13f8>
    4f20:	e8 7b e4 ff ff       	call   33a0 <getenv@plt>
    4f25:	48 89 c2             	mov    %rax,%rdx
    4f28:	31 c0                	xor    %eax,%eax
    4f2a:	48 85 d2             	test   %rdx,%rdx
    4f2d:	74 15                	je     4f44 <fwp_heap_init+0x1d4>
    4f2f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f32:	74 10                	je     4f44 <fwp_heap_init+0x1d4>
    4f34:	0f b6 02             	movzbl (%rdx),%eax
    4f37:	83 e8 30             	sub    $0x30,%eax
    4f3a:	74 13                	je     4f4f <fwp_heap_init+0x1df>
    4f3c:	85 c0                	test   %eax,%eax
    4f3e:	0f 95 c0             	setne  %al
    4f41:	0f b6 c0             	movzbl %al,%eax
    4f44:	5b                   	pop    %rbx
    4f45:	5d                   	pop    %rbp
    4f46:	89 05 3c dc 01 00    	mov    %eax,0x1dc3c(%rip)        # 22b88 <fwp_heap+0x13a8>
    4f4c:	41 5c                	pop    %r12
    4f4e:	c3                   	ret
    4f4f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f53:	85 c0                	test   %eax,%eax
    4f55:	0f 95 c0             	setne  %al
    4f58:	0f b6 c0             	movzbl %al,%eax
    4f5b:	eb e7                	jmp    4f44 <fwp_heap_init+0x1d4>
    4f5d:	0f 1f 00             	nopl   (%rax)

0000000000004f60 <fwp_wake_io>:
    4f60:	48 8b 07             	mov    (%rdi),%rax
    4f63:	48 85 c0             	test   %rax,%rax
    4f66:	0f 84 f4 00 00 00    	je     5060 <fwp_wake_io+0x100>
    4f6c:	53                   	push   %rbx
    4f6d:	4c 8b 05 2c c8 01 00 	mov    0x1c82c(%rip),%r8        # 217a0 <fwp_ready_tail>
    4f74:	49 89 f9             	mov    %rdi,%r9
    4f77:	48 89 c2             	mov    %rax,%rdx
    4f7a:	45 31 db             	xor    %r11d,%r11d
    4f7d:	45 31 d2             	xor    %r10d,%r10d
    4f80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f84:	eb 71                	jmp    4ff7 <fwp_wake_io+0x97>
    4f86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4f8d:	00 00 00 
    4f90:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4f97:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4f9e:	48 85 c9             	test   %rcx,%rcx
    4fa1:	74 07                	je     4faa <fwp_wake_io+0x4a>
    4fa3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4faa:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4fb1:	00 00 00 00 
    4fb5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4fbc:	49 8b 01             	mov    (%r9),%rax
    4fbf:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4fc3:	75 2a                	jne    4fef <fwp_wake_io+0x8f>
    4fc5:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4fc9:	75 24                	jne    4fef <fwp_wake_io+0x8f>
    4fcb:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4fcf:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4fd6:	00 00 00 00 
    4fda:	4d 85 c0             	test   %r8,%r8
    4fdd:	74 51                	je     5030 <fwp_wake_io+0xd0>
    4fdf:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4fe6:	49 89 d0             	mov    %rdx,%r8
    4fe9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4fef:	48 89 c2             	mov    %rax,%rdx
    4ff2:	48 85 c0             	test   %rax,%rax
    4ff5:	74 49                	je     5040 <fwp_wake_io+0xe0>
    4ff7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4ffe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5002:	48 85 ff             	test   %rdi,%rdi
    5005:	74 b8                	je     4fbf <fwp_wake_io+0x5f>
    5007:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    500e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5015:	48 85 f6             	test   %rsi,%rsi
    5018:	0f 85 72 ff ff ff    	jne    4f90 <fwp_wake_io+0x30>
    501e:	48 89 0f             	mov    %rcx,(%rdi)
    5021:	e9 78 ff ff ff       	jmp    4f9e <fwp_wake_io+0x3e>
    5026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    502d:	00 00 00 
    5030:	48 89 d3             	mov    %rdx,%rbx
    5033:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5039:	eb ab                	jmp    4fe6 <fwp_wake_io+0x86>
    503b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5040:	45 84 db             	test   %r11b,%r11b
    5043:	74 07                	je     504c <fwp_wake_io+0xec>
    5045:	48 89 1d 5c c7 01 00 	mov    %rbx,0x1c75c(%rip)        # 217a8 <fwp_ready_head>
    504c:	45 84 d2             	test   %r10b,%r10b
    504f:	74 07                	je     5058 <fwp_wake_io+0xf8>
    5051:	4c 89 05 48 c7 01 00 	mov    %r8,0x1c748(%rip)        # 217a0 <fwp_ready_tail>
    5058:	5b                   	pop    %rbx
    5059:	c3                   	ret
    505a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5060:	c3                   	ret
    5061:	0f 1f 40 00          	nopl   0x0(%rax)
    5065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    506c:	00 00 00 00 

0000000000005070 <fwp_tape_buffers_release>:
    5070:	f3 0f 1e fa          	endbr64
    5074:	53                   	push   %rbx
    5075:	48 89 fb             	mov    %rdi,%rbx
    5078:	48 83 ec 10          	sub    $0x10,%rsp
    507c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5080:	48 85 c0             	test   %rax,%rax
    5083:	0f 88 df 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5089:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    508d:	48 85 d2             	test   %rdx,%rdx
    5090:	0f 88 d2 00 00 00    	js     5168 <fwp_tape_buffers_release+0xf8>
    5096:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    509c:	0f 87 c6 00 00 00    	ja     5168 <fwp_tape_buffers_release+0xf8>
    50a2:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    50a6:	b8 00 00 08 00       	mov    $0x80000,%eax
    50ab:	48 c1 e1 03          	shl    $0x3,%rcx
    50af:	48 29 c8             	sub    %rcx,%rax
    50b2:	48 c1 e8 03          	shr    $0x3,%rax
    50b6:	48 39 d0             	cmp    %rdx,%rax
    50b9:	0f 82 a9 00 00 00    	jb     5168 <fwp_tape_buffers_release+0xf8>
    50bf:	48 8d 3d 5c 80 00 00 	lea    0x805c(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    50c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    50cb:	48 89 14 24          	mov    %rdx,(%rsp)
    50cf:	e8 cc e2 ff ff       	call   33a0 <getenv@plt>
    50d4:	48 8b 14 24          	mov    (%rsp),%rdx
    50d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    50dd:	48 85 c0             	test   %rax,%rax
    50e0:	74 09                	je     50eb <fwp_tape_buffers_release+0x7b>
    50e2:	80 38 30             	cmpb   $0x30,(%rax)
    50e5:	0f 84 9d 00 00 00    	je     5188 <fwp_tape_buffers_release+0x118>
    50eb:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    50ef:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    50f3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    50fa:	77 78                	ja     5174 <fwp_tape_buffers_release+0x104>
    50fc:	48 8d 3d bd bf 01 00 	lea    0x1bfbd(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    5103:	48 89 04 24          	mov    %rax,(%rsp)
    5107:	e8 04 f0 ff ff       	call   4110 <fwp_tape_buffers_dispose>
    510c:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    5110:	48 8b 04 24          	mov    (%rsp),%rax
    5114:	0f 29 05 a5 bf 01 00 	movaps %xmm0,0x1bfa5(%rip)        # 210c0 <fwp_tape_workspace>
    511b:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    5120:	48 89 05 81 bf 01 00 	mov    %rax,0x1bf81(%rip)        # 210a8 <fwp_tape_cached_bytes>
    5127:	0f 29 05 a2 bf 01 00 	movaps %xmm0,0x1bfa2(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    512e:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5133:	0f 29 05 a6 bf 01 00 	movaps %xmm0,0x1bfa6(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    513a:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    513e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5142:	48 89 15 a7 bf 01 00 	mov    %rdx,0x1bfa7(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    5149:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5150:	00 
    5151:	0f 11 03             	movups %xmm0,(%rbx)
    5154:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5158:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    515c:	48 83 c4 10          	add    $0x10,%rsp
    5160:	5b                   	pop    %rbx
    5161:	c3                   	ret
    5162:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5168:	48 8d 3d b3 7f 00 00 	lea    0x7fb3(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    516f:	e8 2c e2 ff ff       	call   33a0 <getenv@plt>
    5174:	48 83 c4 10          	add    $0x10,%rsp
    5178:	48 89 df             	mov    %rbx,%rdi
    517b:	5b                   	pop    %rbx
    517c:	e9 8f ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    5181:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5188:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    518c:	0f 85 59 ff ff ff    	jne    50eb <fwp_tape_buffers_release+0x7b>
    5192:	48 83 c4 10          	add    $0x10,%rsp
    5196:	48 89 df             	mov    %rbx,%rdi
    5199:	5b                   	pop    %rbx
    519a:	e9 71 ef ff ff       	jmp    4110 <fwp_tape_buffers_dispose>
    519f:	90                   	nop

00000000000051a0 <fwp_poll_events>:
    51a0:	53                   	push   %rbx
    51a1:	48 83 ec 20          	sub    $0x20,%rsp
    51a5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    51b3:	31 c0                	xor    %eax,%eax
    51b5:	e8 a6 f3 ff ff       	call   4560 <fwp_now_ns>
    51ba:	48 8b 1d d7 c5 01 00 	mov    0x1c5d7(%rip),%rbx        # 21798 <fwp_timers>
    51c1:	48 85 db             	test   %rbx,%rbx
    51c4:	0f 84 d6 00 00 00    	je     52a0 <fwp_poll_events+0x100>
    51ca:	48 89 c6             	mov    %rax,%rsi
    51cd:	48 89 da             	mov    %rbx,%rdx
    51d0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    51d7:	eb 16                	jmp    51ef <fwp_poll_events+0x4f>
    51d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    51e0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    51e7:	48 89 c8             	mov    %rcx,%rax
    51ea:	48 85 d2             	test   %rdx,%rdx
    51ed:	74 31                	je     5220 <fwp_poll_events+0x80>
    51ef:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    51f3:	48 85 c0             	test   %rax,%rax
    51f6:	78 e8                	js     51e0 <fwp_poll_events+0x40>
    51f8:	48 39 c1             	cmp    %rax,%rcx
    51fb:	7c e3                	jl     51e0 <fwp_poll_events+0x40>
    51fd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5204:	48 85 d2             	test   %rdx,%rdx
    5207:	74 1c                	je     5225 <fwp_poll_events+0x85>
    5209:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    520d:	48 39 c1             	cmp    %rax,%rcx
    5210:	7c ce                	jl     51e0 <fwp_poll_events+0x40>
    5212:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5219:	48 85 d2             	test   %rdx,%rdx
    521c:	75 d1                	jne    51ef <fwp_poll_events+0x4f>
    521e:	66 90                	xchg   %ax,%ax
    5220:	48 85 c0             	test   %rax,%rax
    5223:	78 7b                	js     52a0 <fwp_poll_events+0x100>
    5225:	48 29 f0             	sub    %rsi,%rax
    5228:	48 89 c1             	mov    %rax,%rcx
    522b:	48 85 c0             	test   %rax,%rax
    522e:	0f 8e 9c 00 00 00    	jle    52d0 <fwp_poll_events+0x130>
    5234:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    523b:	de 1b 43 
    523e:	48 f7 ea             	imul   %rdx
    5241:	48 89 c8             	mov    %rcx,%rax
    5244:	48 c1 f8 3f          	sar    $0x3f,%rax
    5248:	48 c1 fa 12          	sar    $0x12,%rdx
    524c:	48 29 c2             	sub    %rax,%rdx
    524f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5256:	48 39 c1             	cmp    %rax,%rcx
    5259:	0f 95 c0             	setne  %al
    525c:	0f b6 c0             	movzbl %al,%eax
    525f:	48 01 d0             	add    %rdx,%rax
    5262:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5268:	0f 8f 32 01 00 00    	jg     53a0 <fwp_poll_events+0x200>
    526e:	48 85 c0             	test   %rax,%rax
    5271:	74 5d                	je     52d0 <fwp_poll_events+0x130>
    5273:	89 c1                	mov    %eax,%ecx
    5275:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    527c:	48 c1 e9 26          	shr    $0x26,%rcx
    5280:	48 63 d1             	movslq %ecx,%rdx
    5283:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5289:	29 c8                	sub    %ecx,%eax
    528b:	48 98                	cltq
    528d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5294:	e9 11 01 00 00       	jmp    53aa <fwp_poll_events+0x20a>
    5299:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    52a0:	e8 cb e9 ff ff       	call   3c70 <fwp_flush>
    52a5:	ba 2b 00 00 00       	mov    $0x2b,%edx
    52aa:	be 01 00 00 00       	mov    $0x1,%esi
    52af:	48 8b 0d aa bd 00 00 	mov    0xbdaa(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    52b6:	48 8d 3d 73 85 00 00 	lea    0x8573(%rip),%rdi        # d830 <_IO_stdin_used+0x830>
    52bd:	e8 be e3 ff ff       	call   3680 <fwrite@plt>
    52c2:	bf 65 00 00 00       	mov    $0x65,%edi
    52c7:	e8 a4 e3 ff ff       	call   3670 <exit@plt>
    52cc:	0f 1f 40 00          	nopl   0x0(%rax)
    52d0:	e8 8b f2 ff ff       	call   4560 <fwp_now_ns>
    52d5:	48 89 c1             	mov    %rax,%rcx
    52d8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    52dc:	eb 44                	jmp    5322 <fwp_poll_events+0x182>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    52e4:	75 33                	jne    5319 <fwp_poll_events+0x179>
    52e6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    52ea:	75 2d                	jne    5319 <fwp_poll_events+0x179>
    52ec:	48 8b 05 ad c4 01 00 	mov    0x1c4ad(%rip),%rax        # 217a0 <fwp_ready_tail>
    52f3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    52f7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    52fe:	00 00 00 00 
    5302:	48 85 c0             	test   %rax,%rax
    5305:	0f 84 05 01 00 00    	je     5410 <fwp_poll_events+0x270>
    530b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5312:	48 89 15 87 c4 01 00 	mov    %rdx,0x1c487(%rip)        # 217a0 <fwp_ready_tail>
    5319:	48 85 db             	test   %rbx,%rbx
    531c:	0f 84 be 00 00 00    	je     53e0 <fwp_poll_events+0x240>
    5322:	48 89 da             	mov    %rbx,%rdx
    5325:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    532c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5330:	7f e7                	jg     5319 <fwp_poll_events+0x179>
    5332:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5336:	74 2e                	je     5366 <fwp_poll_events+0x1c6>
    5338:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    533f:	48 85 c0             	test   %rax,%rax
    5342:	0f 84 b8 00 00 00    	je     5400 <fwp_poll_events+0x260>
    5348:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    534f:	48 85 db             	test   %rbx,%rbx
    5352:	74 07                	je     535b <fwp_poll_events+0x1bb>
    5354:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    535b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    535f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5366:	48 8b 42 60          	mov    0x60(%rdx),%rax
    536a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    536e:	48 85 c0             	test   %rax,%rax
    5371:	0f 84 69 ff ff ff    	je     52e0 <fwp_poll_events+0x140>
    5377:	48 39 c8             	cmp    %rcx,%rax
    537a:	0f 8f 60 ff ff ff    	jg     52e0 <fwp_poll_events+0x140>
    5380:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5384:	0f 85 56 ff ff ff    	jne    52e0 <fwp_poll_events+0x140>
    538a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    538e:	75 89                	jne    5319 <fwp_poll_events+0x179>
    5390:	48 89 d7             	mov    %rdx,%rdi
    5393:	e8 68 ef ff ff       	call   4300 <fwp_cancel_tree.part.0>
    5398:	e9 43 ff ff ff       	jmp    52e0 <fwp_poll_events+0x140>
    539d:	0f 1f 00             	nopl   (%rax)
    53a0:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    53a5:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    53aa:	48 89 e7             	mov    %rsp,%rdi
    53ad:	31 f6                	xor    %esi,%esi
    53af:	48 89 14 24          	mov    %rdx,(%rsp)
    53b3:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    53b8:	e8 e3 e0 ff ff       	call   34a0 <nanosleep@plt>
    53bd:	48 8b 1d d4 c3 01 00 	mov    0x1c3d4(%rip),%rbx        # 21798 <fwp_timers>
    53c4:	e8 97 f1 ff ff       	call   4560 <fwp_now_ns>
    53c9:	48 89 c1             	mov    %rax,%rcx
    53cc:	48 85 db             	test   %rbx,%rbx
    53cf:	0f 85 03 ff ff ff    	jne    52d8 <fwp_poll_events+0x138>
    53d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    53dc:	00 00 00 00 
    53e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    53e5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    53ec:	00 00 
    53ee:	75 2c                	jne    541c <fwp_poll_events+0x27c>
    53f0:	48 83 c4 20          	add    $0x20,%rsp
    53f4:	5b                   	pop    %rbx
    53f5:	c3                   	ret
    53f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    53fd:	00 00 00 
    5400:	48 89 1d 91 c3 01 00 	mov    %rbx,0x1c391(%rip)        # 21798 <fwp_timers>
    5407:	e9 43 ff ff ff       	jmp    534f <fwp_poll_events+0x1af>
    540c:	0f 1f 40 00          	nopl   0x0(%rax)
    5410:	48 89 15 91 c3 01 00 	mov    %rdx,0x1c391(%rip)        # 217a8 <fwp_ready_head>
    5417:	e9 f6 fe ff ff       	jmp    5312 <fwp_poll_events+0x172>
    541c:	e8 3f e0 ff ff       	call   3460 <__stack_chk_fail@plt>
    5421:	0f 1f 40 00          	nopl   0x0(%rax)
    5425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    542c:	00 00 00 00 

0000000000005430 <fwp_rc_wide_dup>:
    5430:	48 89 fa             	mov    %rdi,%rdx
    5433:	48 8d 35 a6 c3 01 00 	lea    0x1c3a6(%rip),%rsi        # 217e0 <fwp_heap>
    543a:	48 83 ec 18          	sub    $0x18,%rsp
    543e:	48 89 f9             	mov    %rdi,%rcx
    5441:	48 c1 ea 11          	shr    $0x11,%rdx
    5445:	48 31 fa             	xor    %rdi,%rdx
    5448:	48 89 d0             	mov    %rdx,%rax
    544b:	48 c1 e8 09          	shr    $0x9,%rax
    544f:	48 31 c2             	xor    %rax,%rdx
    5452:	0f b6 d2             	movzbl %dl,%edx
    5455:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    545c:	00 
    545d:	49 8b 00             	mov    (%r8),%rax
    5460:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5467:	00 00 
    5469:	75 21                	jne    548c <fwp_rc_wide_dup+0x5c>
    546b:	e9 98 00 00 00       	jmp    5508 <fwp_rc_wide_dup+0xd8>
    5470:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    547c:	00 00 00 00 
    5480:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5484:	48 85 d2             	test   %rdx,%rdx
    5487:	74 2f                	je     54b8 <fwp_rc_wide_dup+0x88>
    5489:	48 89 d0             	mov    %rdx,%rax
    548c:	48 3b 08             	cmp    (%rax),%rcx
    548f:	75 ef                	jne    5480 <fwp_rc_wide_dup+0x50>
    5491:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5494:	74 7c                	je     5512 <fwp_rc_wide_dup+0xe2>
    5496:	48 8b 50 08          	mov    0x8(%rax),%rdx
    549a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    549e:	0f 84 91 00 00 00    	je     5535 <fwp_rc_wide_dup+0x105>
    54a4:	48 83 c2 01          	add    $0x1,%rdx
    54a8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    54ac:	48 83 c4 18          	add    $0x18,%rsp
    54b0:	c3                   	ret
    54b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    54b8:	4c 8d 40 10          	lea    0x10(%rax),%r8
    54bc:	80 39 fe             	cmpb   $0xfe,(%rcx)
    54bf:	75 68                	jne    5529 <fwp_rc_wide_dup+0xf9>
    54c1:	bf 18 00 00 00       	mov    $0x18,%edi
    54c6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    54cb:	4c 89 04 24          	mov    %r8,(%rsp)
    54cf:	e8 dc e0 ff ff       	call   35b0 <malloc@plt>
    54d4:	4c 8b 04 24          	mov    (%rsp),%r8
    54d8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    54dd:	48 85 c0             	test   %rax,%rax
    54e0:	74 5f                	je     5541 <fwp_rc_wide_dup+0x111>
    54e2:	48 89 08             	mov    %rcx,(%rax)
    54e5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    54ec:	00 
    54ed:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    54f4:	00 
    54f5:	49 89 00             	mov    %rax,(%r8)
    54f8:	c6 01 ff             	movb   $0xff,(%rcx)
    54fb:	48 83 05 25 df 01 00 	addq   $0x1,0x1df25(%rip)        # 23428 <fwp_heap+0x1c48>
    5502:	01 
    5503:	48 83 c4 18          	add    $0x18,%rsp
    5507:	c3                   	ret
    5508:	80 3f fe             	cmpb   $0xfe,(%rdi)
    550b:	75 13                	jne    5520 <fwp_rc_wide_dup+0xf0>
    550d:	48 85 c0             	test   %rax,%rax
    5510:	74 af                	je     54c1 <fwp_rc_wide_dup+0x91>
    5512:	48 8d 3d 47 83 00 00 	lea    0x8347(%rip),%rdi        # d860 <_IO_stdin_used+0x860>
    5519:	e8 d2 ee ff ff       	call   43f0 <fwp_trap>
    551e:	66 90                	xchg   %ax,%ax
    5520:	48 85 c0             	test   %rax,%rax
    5523:	0f 85 6d ff ff ff    	jne    5496 <fwp_rc_wide_dup+0x66>
    5529:	48 8d 3d 58 83 00 00 	lea    0x8358(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    5530:	e8 bb ee ff ff       	call   43f0 <fwp_trap>
    5535:	48 8d 3d f7 7b 00 00 	lea    0x7bf7(%rip),%rdi        # d133 <_IO_stdin_used+0x133>
    553c:	e8 af ee ff ff       	call   43f0 <fwp_trap>
    5541:	e8 6a e7 ff ff       	call   3cb0 <fwp_heap_oom>
    5546:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    554d:	00 00 00 

0000000000005550 <fwp_rc_forget_slot>:
    5550:	80 3f ff             	cmpb   $0xff,(%rdi)
    5553:	74 0b                	je     5560 <fwp_rc_forget_slot+0x10>
    5555:	c3                   	ret
    5556:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    555d:	00 00 00 
    5560:	48 89 f8             	mov    %rdi,%rax
    5563:	48 83 ec 08          	sub    $0x8,%rsp
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 c1 e8 11          	shr    $0x11,%rax
    556e:	48 31 f8             	xor    %rdi,%rax
    5571:	48 89 c1             	mov    %rax,%rcx
    5574:	48 c1 e9 09          	shr    $0x9,%rcx
    5578:	48 31 c8             	xor    %rcx,%rax
    557b:	48 8d 0d 5e c2 01 00 	lea    0x1c25e(%rip),%rcx        # 217e0 <fwp_heap>
    5582:	0f b6 c0             	movzbl %al,%eax
    5585:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    558c:	00 
    558d:	48 85 ff             	test   %rdi,%rdi
    5590:	74 3c                	je     55ce <fwp_rc_forget_slot+0x7e>
    5592:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5599:	00 
    559a:	48 8b 01             	mov    (%rcx),%rax
    559d:	eb 11                	jmp    55b0 <fwp_rc_forget_slot+0x60>
    559f:	90                   	nop
    55a0:	48 8b 78 10          	mov    0x10(%rax),%rdi
    55a4:	48 8d 48 10          	lea    0x10(%rax),%rcx
    55a8:	48 85 ff             	test   %rdi,%rdi
    55ab:	74 21                	je     55ce <fwp_rc_forget_slot+0x7e>
    55ad:	48 89 f8             	mov    %rdi,%rax
    55b0:	48 3b 10             	cmp    (%rax),%rdx
    55b3:	75 eb                	jne    55a0 <fwp_rc_forget_slot+0x50>
    55b5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    55b9:	48 89 01             	mov    %rax,(%rcx)
    55bc:	e8 ff dd ff ff       	call   33c0 <free@plt>
    55c1:	48 83 2d 5f de 01 00 	subq   $0x1,0x1de5f(%rip)        # 23428 <fwp_heap+0x1c48>
    55c8:	01 
    55c9:	48 83 c4 08          	add    $0x8,%rsp
    55cd:	c3                   	ret
    55ce:	48 8d 3d b3 82 00 00 	lea    0x82b3(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    55d5:	e8 16 ee ff ff       	call   43f0 <fwp_trap>
    55da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000055e0 <fwp_rc_prepare_chunk>:
    55e0:	48 83 3d 40 de 01 00 	cmpq   $0x0,0x1de40(%rip)        # 23428 <fwp_heap+0x1c48>
    55e7:	00 
    55e8:	41 54                	push   %r12
    55ea:	49 89 f4             	mov    %rsi,%r12
    55ed:	55                   	push   %rbp
    55ee:	48 89 fd             	mov    %rdi,%rbp
    55f1:	53                   	push   %rbx
    55f2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    55f5:	0f 84 7d 00 00 00    	je     5678 <fwp_rc_prepare_chunk+0x98>
    55fb:	31 db                	xor    %ebx,%ebx
    55fd:	85 c0                	test   %eax,%eax
    55ff:	75 5f                	jne    5660 <fwp_rc_prepare_chunk+0x80>
    5601:	48 85 f6             	test   %rsi,%rsi
    5604:	74 7c                	je     5682 <fwp_rc_prepare_chunk+0xa2>
    5606:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    560a:	e8 b1 dd ff ff       	call   33c0 <free@plt>
    560f:	90                   	nop
    5610:	be 01 00 00 00       	mov    $0x1,%esi
    5615:	4c 89 e7             	mov    %r12,%rdi
    5618:	e8 03 df ff ff       	call   3520 <calloc@plt>
    561d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5621:	48 85 c0             	test   %rax,%rax
    5624:	0f 85 87 00 00 00    	jne    56b1 <fwp_rc_prepare_chunk+0xd1>
    562a:	e8 81 e6 ff ff       	call   3cb0 <fwp_heap_oom>
    562f:	90                   	nop
    5630:	e8 1b ff ff ff       	call   5550 <fwp_rc_forget_slot>
    5635:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5638:	48 83 c3 01          	add    $0x1,%rbx
    563c:	48 39 c3             	cmp    %rax,%rbx
    563f:	73 37                	jae    5678 <fwp_rc_prepare_chunk+0x98>
    5641:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5648:	00 00 
    564a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5651:	00 00 00 00 
    5655:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    565c:	00 00 00 00 
    5660:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5664:	48 01 df             	add    %rbx,%rdi
    5667:	80 3f ff             	cmpb   $0xff,(%rdi)
    566a:	74 c4                	je     5630 <fwp_rc_prepare_chunk+0x50>
    566c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    566f:	48 83 c3 01          	add    $0x1,%rbx
    5673:	48 39 c3             	cmp    %rax,%rbx
    5676:	72 e8                	jb     5660 <fwp_rc_prepare_chunk+0x80>
    5678:	49 39 c4             	cmp    %rax,%r12
    567b:	75 13                	jne    5690 <fwp_rc_prepare_chunk+0xb0>
    567d:	4d 85 e4             	test   %r12,%r12
    5680:	75 46                	jne    56c8 <fwp_rc_prepare_chunk+0xe8>
    5682:	5b                   	pop    %rbx
    5683:	5d                   	pop    %rbp
    5684:	41 5c                	pop    %r12
    5686:	c3                   	ret
    5687:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    568e:	00 00 
    5690:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5694:	48 29 05 95 dd 01 00 	sub    %rax,0x1dd95(%rip)        # 23430 <fwp_heap+0x1c50>
    569b:	e8 20 dd ff ff       	call   33c0 <free@plt>
    56a0:	4d 85 e4             	test   %r12,%r12
    56a3:	0f 85 67 ff ff ff    	jne    5610 <fwp_rc_prepare_chunk+0x30>
    56a9:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    56b0:	00 
    56b1:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    56b5:	5b                   	pop    %rbx
    56b6:	4c 01 25 73 dd 01 00 	add    %r12,0x1dd73(%rip)        # 23430 <fwp_heap+0x1c50>
    56bd:	5d                   	pop    %rbp
    56be:	41 5c                	pop    %r12
    56c0:	c3                   	ret
    56c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    56c8:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    56cc:	5b                   	pop    %rbx
    56cd:	4c 89 e2             	mov    %r12,%rdx
    56d0:	31 f6                	xor    %esi,%esi
    56d2:	5d                   	pop    %rbp
    56d3:	41 5c                	pop    %r12
    56d5:	e9 e6 dd ff ff       	jmp    34c0 <memset@plt>
    56da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000056e0 <fwp_heap_refill>:
    56e0:	41 56                	push   %r14
    56e2:	41 89 d6             	mov    %edx,%r14d
    56e5:	41 55                	push   %r13
    56e7:	41 89 f5             	mov    %esi,%r13d
    56ea:	41 54                	push   %r12
    56ec:	49 89 fc             	mov    %rdi,%r12
    56ef:	bf 01 00 00 00       	mov    $0x1,%edi
    56f4:	55                   	push   %rbp
    56f5:	53                   	push   %rbx
    56f6:	e8 85 e8 ff ff       	call   3f80 <fwp_heap_chunks>
    56fb:	48 89 c3             	mov    %rax,%rbx
    56fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5702:	48 8b 05 cf d4 01 00 	mov    0x1d4cf(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    5709:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    570d:	48 8d 05 cc c0 01 00 	lea    0x1c0cc(%rip),%rax        # 217e0 <fwp_heap>
    5714:	31 d2                	xor    %edx,%edx
    5716:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    571a:	48 89 ef             	mov    %rbp,%rdi
    571d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5721:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5725:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    572c:	00 
    572d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5732:	f7 f1                	div    %ecx
    5734:	31 d2                	xor    %edx,%edx
    5736:	66 0f 6e c1          	movd   %ecx,%xmm0
    573a:	66 0f 6e c8          	movd   %eax,%xmm1
    573e:	89 c6                	mov    %eax,%esi
    5740:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5745:	48 01 c8             	add    %rcx,%rax
    5748:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    574c:	48 f7 f1             	div    %rcx
    574f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5754:	89 45 18             	mov    %eax,0x18(%rbp)
    5757:	e8 84 fe ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    575c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    575f:	48 89 d8             	mov    %rbx,%rax
    5762:	48 c1 e0 10          	shl    $0x10,%rax
    5766:	48 03 05 23 d4 01 00 	add    0x1d423(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    576d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5771:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5776:	8b 55 08             	mov    0x8(%rbp),%edx
    5779:	48 0f af d1          	imul   %rcx,%rdx
    577d:	48 01 c2             	add    %rax,%rdx
    5780:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5785:	5b                   	pop    %rbx
    5786:	5d                   	pop    %rbp
    5787:	41 5c                	pop    %r12
    5789:	41 5d                	pop    %r13
    578b:	41 5e                	pop    %r14
    578d:	c3                   	ret
    578e:	66 90                	xchg   %ax,%ax

0000000000005790 <fwp_mem_free>:
    5790:	48 85 ff             	test   %rdi,%rdi
    5793:	0f 84 17 02 00 00    	je     59b0 <fwp_mem_free+0x220>
    5799:	48 8b 35 f0 d3 01 00 	mov    0x1d3f0(%rip),%rsi        # 22b90 <fwp_heap+0x13b0>
    57a0:	48 8b 05 11 d4 01 00 	mov    0x1d411(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    57a7:	48 89 fa             	mov    %rdi,%rdx
    57aa:	48 29 f2             	sub    %rsi,%rdx
    57ad:	48 c1 e0 10          	shl    $0x10,%rax
    57b1:	48 39 c2             	cmp    %rax,%rdx
    57b4:	0f 83 f6 01 00 00    	jae    59b0 <fwp_mem_free+0x220>
    57ba:	49 89 d1             	mov    %rdx,%r9
    57bd:	49 c1 e9 10          	shr    $0x10,%r9
    57c1:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    57c5:	48 c1 e0 03          	shl    $0x3,%rax
    57c9:	49 89 c0             	mov    %rax,%r8
    57cc:	4c 03 05 05 d4 01 00 	add    0x1d405(%rip),%r8        # 22bd8 <fwp_heap+0x13f8>
    57d3:	0f 84 d7 01 00 00    	je     59b0 <fwp_mem_free+0x220>
    57d9:	48 83 ec 38          	sub    $0x38,%rsp
    57dd:	48 89 f9             	mov    %rdi,%rcx
    57e0:	41 0f b6 38          	movzbl (%r8),%edi
    57e4:	40 80 ff 01          	cmp    $0x1,%dil
    57e8:	74 16                	je     5800 <fwp_mem_free+0x70>
    57ea:	40 80 ff 02          	cmp    $0x2,%dil
    57ee:	0f 84 94 00 00 00    	je     5888 <fwp_mem_free+0xf8>
    57f4:	48 83 c4 38          	add    $0x38,%rsp
    57f8:	c3                   	ret
    57f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5800:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5804:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5809:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    580e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5812:	4d 85 d2             	test   %r10,%r10
    5815:	74 1d                	je     5834 <fwp_mem_free+0xa4>
    5817:	0f b7 c1             	movzwl %cx,%eax
    581a:	31 d2                	xor    %edx,%edx
    581c:	48 f7 f7             	div    %rdi
    581f:	49 01 c2             	add    %rax,%r10
    5822:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5826:	0f 84 44 01 00 00    	je     5970 <fwp_mem_free+0x1e0>
    582c:	41 c6 02 00          	movb   $0x0,(%r10)
    5830:	41 8b 78 04          	mov    0x4(%r8),%edi
    5834:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    583b:	49 63 c1             	movslq %r9d,%rax
    583e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5842:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5846:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    584b:	f2 0f 58 05 cd d3 01 	addsd  0x1d3cd(%rip),%xmm0        # 22c20 <fwp_heap+0x1440>
    5852:	00 
    5853:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5857:	48 8d 05 82 bf 01 00 	lea    0x1bf82(%rip),%rax        # 217e0 <fwp_heap>
    585e:	48 01 d0             	add    %rdx,%rax
    5861:	48 8b 10             	mov    (%rax),%rdx
    5864:	48 f7 d2             	not    %rdx
    5867:	48 89 11             	mov    %rdx,(%rcx)
    586a:	48 89 08             	mov    %rcx,(%rax)
    586d:	48 29 3d 8c d3 01 00 	sub    %rdi,0x1d38c(%rip)        # 22c00 <fwp_heap+0x1420>
    5874:	f2 0f 11 05 a4 d3 01 	movsd  %xmm0,0x1d3a4(%rip)        # 22c20 <fwp_heap+0x1440>
    587b:	00 
    587c:	48 83 c4 38          	add    $0x38,%rsp
    5880:	c3                   	ret
    5881:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5888:	66 31 d2             	xor    %dx,%dx
    588b:	48 01 d6             	add    %rdx,%rsi
    588e:	48 39 f1             	cmp    %rsi,%rcx
    5891:	0f 85 5d ff ff ff    	jne    57f4 <fwp_mem_free+0x64>
    5897:	49 8b 50 10          	mov    0x10(%r8),%rdx
    589b:	48 29 15 5e d3 01 00 	sub    %rdx,0x1d35e(%rip)        # 22c00 <fwp_heap+0x1420>
    58a2:	48 85 d2             	test   %rdx,%rdx
    58a5:	0f 88 a5 00 00 00    	js     5950 <fwp_mem_free+0x1c0>
    58ab:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58af:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    58b4:	f2 0f 58 05 64 d3 01 	addsd  0x1d364(%rip),%xmm0        # 22c20 <fwp_heap+0x1440>
    58bb:	00 
    58bc:	49 8b 50 20          	mov    0x20(%r8),%rdx
    58c0:	f2 0f 11 05 58 d3 01 	movsd  %xmm0,0x1d358(%rip)        # 22c20 <fwp_heap+0x1440>
    58c7:	00 
    58c8:	48 85 d2             	test   %rdx,%rdx
    58cb:	74 0c                	je     58d9 <fwp_mem_free+0x149>
    58cd:	80 3a ff             	cmpb   $0xff,(%rdx)
    58d0:	0f 84 db 00 00 00    	je     59b1 <fwp_mem_free+0x221>
    58d6:	c6 02 00             	movb   $0x0,(%rdx)
    58d9:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    58dd:	48 85 c9             	test   %rcx,%rcx
    58e0:	74 3e                	je     5920 <fwp_mem_free+0x190>
    58e2:	48 8b 15 ef d2 01 00 	mov    0x1d2ef(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    58e9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    58ed:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    58f1:	48 01 d0             	add    %rdx,%rax
    58f4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    58f8:	48 89 d6             	mov    %rdx,%rsi
    58fb:	48 29 c6             	sub    %rax,%rsi
    58fe:	83 e6 08             	and    $0x8,%esi
    5901:	74 0d                	je     5910 <fwp_mem_free+0x180>
    5903:	c6 00 00             	movb   $0x0,(%rax)
    5906:	48 83 c0 28          	add    $0x28,%rax
    590a:	48 39 c2             	cmp    %rax,%rdx
    590d:	74 11                	je     5920 <fwp_mem_free+0x190>
    590f:	90                   	nop
    5910:	c6 00 00             	movb   $0x0,(%rax)
    5913:	48 83 c0 50          	add    $0x50,%rax
    5917:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    591b:	48 39 c2             	cmp    %rax,%rdx
    591e:	75 f0                	jne    5910 <fwp_mem_free+0x180>
    5920:	48 01 0d e9 d2 01 00 	add    %rcx,0x1d2e9(%rip)        # 22c10 <fwp_heap+0x1430>
    5927:	4c 3b 0d a2 d2 01 00 	cmp    0x1d2a2(%rip),%r9        # 22bd0 <fwp_heap+0x13f0>
    592e:	73 07                	jae    5937 <fwp_mem_free+0x1a7>
    5930:	4c 89 0d 99 d2 01 00 	mov    %r9,0x1d299(%rip)        # 22bd0 <fwp_heap+0x13f0>
    5937:	4c 3b 0d 8a d2 01 00 	cmp    0x1d28a(%rip),%r9        # 22bc8 <fwp_heap+0x13e8>
    593e:	0f 83 b0 fe ff ff    	jae    57f4 <fwp_mem_free+0x64>
    5944:	4c 89 0d 7d d2 01 00 	mov    %r9,0x1d27d(%rip)        # 22bc8 <fwp_heap+0x13e8>
    594b:	e9 a4 fe ff ff       	jmp    57f4 <fwp_mem_free+0x64>
    5950:	48 89 d1             	mov    %rdx,%rcx
    5953:	83 e2 01             	and    $0x1,%edx
    5956:	66 0f ef c0          	pxor   %xmm0,%xmm0
    595a:	48 d1 e9             	shr    $1,%rcx
    595d:	48 09 d1             	or     %rdx,%rcx
    5960:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5965:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5969:	e9 46 ff ff ff       	jmp    58b4 <fwp_mem_free+0x124>
    596e:	66 90                	xchg   %ax,%ax
    5970:	4c 89 d7             	mov    %r10,%rdi
    5973:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5978:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    597d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5982:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5986:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    598b:	e8 c0 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    5990:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5995:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    599a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    599f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    59a4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    59a9:	e9 7e fe ff ff       	jmp    582c <fwp_mem_free+0x9c>
    59ae:	66 90                	xchg   %ax,%ax
    59b0:	c3                   	ret
    59b1:	48 89 d7             	mov    %rdx,%rdi
    59b4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    59b9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    59be:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    59c3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    59c8:	e8 83 fb ff ff       	call   5550 <fwp_rc_forget_slot>
    59cd:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    59d2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    59d7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    59dc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    59e1:	e9 f0 fe ff ff       	jmp    58d6 <fwp_mem_free+0x146>
    59e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    59ed:	00 00 00 

00000000000059f0 <fwp_heap_alloc_big>:
    59f0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    59f7:	00 00 40 
    59fa:	41 57                	push   %r15
    59fc:	41 56                	push   %r14
    59fe:	41 55                	push   %r13
    5a00:	41 54                	push   %r12
    5a02:	55                   	push   %rbp
    5a03:	53                   	push   %rbx
    5a04:	48 83 ec 08          	sub    $0x8,%rsp
    5a08:	48 39 f8             	cmp    %rdi,%rax
    5a0b:	0f 82 fa 00 00 00    	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5a11:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5a18:	49 89 fd             	mov    %rdi,%r13
    5a1b:	41 89 f6             	mov    %esi,%r14d
    5a1e:	48 c1 ed 10          	shr    $0x10,%rbp
    5a22:	48 89 ef             	mov    %rbp,%rdi
    5a25:	e8 56 e5 ff ff       	call   3f80 <fwp_heap_chunks>
    5a2a:	be 01 00 00 00       	mov    $0x1,%esi
    5a2f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5a33:	49 89 c4             	mov    %rax,%r12
    5a36:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5a3d:	00 
    5a3e:	48 03 3d 93 d1 01 00 	add    0x1d193(%rip),%rdi        # 22bd8 <fwp_heap+0x13f8>
    5a45:	c6 07 02             	movb   $0x2,(%rdi)
    5a48:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5a4c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5a4f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5a53:	e8 88 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a58:	48 83 fd 01          	cmp    $0x1,%rbp
    5a5c:	76 47                	jbe    5aa5 <fwp_heap_alloc_big+0xb5>
    5a5e:	4c 01 e5             	add    %r12,%rbp
    5a61:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5a68:	00 
    5a69:	4c 8d 3d 70 bd 01 00 	lea    0x1bd70(%rip),%r15        # 217e0 <fwp_heap>
    5a70:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5a75:	49 c1 e6 03          	shl    $0x3,%r14
    5a79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a80:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5a87:	31 f6                	xor    %esi,%esi
    5a89:	48 01 dd             	add    %rbx,%rbp
    5a8c:	48 83 c3 28          	add    $0x28,%rbx
    5a90:	48 89 ef             	mov    %rbp,%rdi
    5a93:	e8 48 fb ff ff       	call   55e0 <fwp_rc_prepare_chunk>
    5a98:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5a9c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5aa0:	49 39 de             	cmp    %rbx,%r14
    5aa3:	75 db                	jne    5a80 <fwp_heap_alloc_big+0x90>
    5aa5:	49 c1 e4 10          	shl    $0x10,%r12
    5aa9:	4c 03 25 e0 d0 01 00 	add    0x1d0e0(%rip),%r12        # 22b90 <fwp_heap+0x13b0>
    5ab0:	4c 89 ea             	mov    %r13,%rdx
    5ab3:	31 f6                	xor    %esi,%esi
    5ab5:	4c 89 e7             	mov    %r12,%rdi
    5ab8:	e8 03 da ff ff       	call   34c0 <memset@plt>
    5abd:	4c 89 e8             	mov    %r13,%rax
    5ac0:	48 03 05 39 d1 01 00 	add    0x1d139(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5ac7:	72 42                	jb     5b0b <fwp_heap_alloc_big+0x11b>
    5ac9:	48 39 05 38 d1 01 00 	cmp    %rax,0x1d138(%rip)        # 22c08 <fwp_heap+0x1428>
    5ad0:	48 89 05 29 d1 01 00 	mov    %rax,0x1d129(%rip)        # 22c00 <fwp_heap+0x1420>
    5ad7:	73 07                	jae    5ae0 <fwp_heap_alloc_big+0xf0>
    5ad9:	48 89 05 28 d1 01 00 	mov    %rax,0x1d128(%rip)        # 22c08 <fwp_heap+0x1428>
    5ae0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5ae4:	4c 89 e0             	mov    %r12,%rax
    5ae7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5aec:	f2 0f 58 05 24 d1 01 	addsd  0x1d124(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5af3:	00 
    5af4:	f2 0f 11 05 1c d1 01 	movsd  %xmm0,0x1d11c(%rip)        # 22c18 <fwp_heap+0x1438>
    5afb:	00 
    5afc:	48 83 c4 08          	add    $0x8,%rsp
    5b00:	5b                   	pop    %rbx
    5b01:	5d                   	pop    %rbp
    5b02:	41 5c                	pop    %r12
    5b04:	41 5d                	pop    %r13
    5b06:	41 5e                	pop    %r14
    5b08:	41 5f                	pop    %r15
    5b0a:	c3                   	ret
    5b0b:	e8 a0 e1 ff ff       	call   3cb0 <fwp_heap_oom>

0000000000005b10 <fwp_heap_alloc_slow>:
    5b10:	53                   	push   %rbx
    5b11:	48 89 f9             	mov    %rdi,%rcx
    5b14:	41 89 f1             	mov    %esi,%r9d
    5b17:	48 83 ec 10          	sub    $0x10,%rsp
    5b1b:	8b 05 63 d0 01 00    	mov    0x1d063(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    5b21:	85 c0                	test   %eax,%eax
    5b23:	0f 84 c7 00 00 00    	je     5bf0 <fwp_heap_alloc_slow+0xe0>
    5b29:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5b30:	0f 87 dd 00 00 00    	ja     5c13 <fwp_heap_alloc_slow+0x103>
    5b36:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5b3a:	48 8d 3d 9f bc 01 00 	lea    0x1bc9f(%rip),%rdi        # 217e0 <fwp_heap>
    5b41:	49 63 f1             	movslq %r9d,%rsi
    5b44:	48 c1 e8 04          	shr    $0x4,%rax
    5b48:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5b4f:	00 00 
    5b51:	41 0f b6 c2          	movzbl %r10b,%eax
    5b55:	4c 89 d2             	mov    %r10,%rdx
    5b58:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5b5c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5b63:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5b6a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5b6e:	48 01 f8             	add    %rdi,%rax
    5b71:	4c 8b 00             	mov    (%rax),%r8
    5b74:	4d 85 c0             	test   %r8,%r8
    5b77:	0f 84 ab 00 00 00    	je     5c28 <fwp_heap_alloc_slow+0x118>
    5b7d:	49 8b 10             	mov    (%r8),%rdx
    5b80:	48 f7 d2             	not    %rdx
    5b83:	48 89 10             	mov    %rdx,(%rax)
    5b86:	41 83 f9 01          	cmp    $0x1,%r9d
    5b8a:	4c 89 c7             	mov    %r8,%rdi
    5b8d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5b91:	31 f6                	xor    %esi,%esi
    5b93:	48 89 ca             	mov    %rcx,%rdx
    5b96:	e8 25 d9 ff ff       	call   34c0 <memset@plt>
    5b9b:	49 89 c0             	mov    %rax,%r8
    5b9e:	48 89 d8             	mov    %rbx,%rax
    5ba1:	48 03 05 58 d0 01 00 	add    0x1d058(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5ba8:	0f 82 d9 00 00 00    	jb     5c87 <fwp_heap_alloc_slow+0x177>
    5bae:	48 39 05 53 d0 01 00 	cmp    %rax,0x1d053(%rip)        # 22c08 <fwp_heap+0x1428>
    5bb5:	48 89 05 44 d0 01 00 	mov    %rax,0x1d044(%rip)        # 22c00 <fwp_heap+0x1420>
    5bbc:	73 07                	jae    5bc5 <fwp_heap_alloc_slow+0xb5>
    5bbe:	48 89 05 43 d0 01 00 	mov    %rax,0x1d043(%rip)        # 22c08 <fwp_heap+0x1428>
    5bc5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bc9:	4c 89 c0             	mov    %r8,%rax
    5bcc:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5bd1:	f2 0f 58 05 3f d0 01 	addsd  0x1d03f(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5bd8:	00 
    5bd9:	f2 0f 11 05 37 d0 01 	movsd  %xmm0,0x1d037(%rip)        # 22c18 <fwp_heap+0x1438>
    5be0:	00 
    5be1:	48 83 c4 10          	add    $0x10,%rsp
    5be5:	5b                   	pop    %rbx
    5be6:	c3                   	ret
    5be7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5bee:	00 00 
    5bf0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5bf4:	48 89 3c 24          	mov    %rdi,(%rsp)
    5bf8:	e8 73 f1 ff ff       	call   4d70 <fwp_heap_init>
    5bfd:	48 8b 0c 24          	mov    (%rsp),%rcx
    5c01:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5c06:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5c0d:	0f 86 23 ff ff ff    	jbe    5b36 <fwp_heap_alloc_slow+0x26>
    5c13:	48 83 c4 10          	add    $0x10,%rsp
    5c17:	44 89 ce             	mov    %r9d,%esi
    5c1a:	48 89 cf             	mov    %rcx,%rdi
    5c1d:	5b                   	pop    %rbx
    5c1e:	e9 cd fd ff ff       	jmp    59f0 <fwp_heap_alloc_big>
    5c23:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5c28:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5c2c:	4d 85 c0             	test   %r8,%r8
    5c2f:	74 1f                	je     5c50 <fwp_heap_alloc_slow+0x140>
    5c31:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5c35:	4d 29 c3             	sub    %r8,%r11
    5c38:	49 39 db             	cmp    %rbx,%r11
    5c3b:	72 13                	jb     5c50 <fwp_heap_alloc_slow+0x140>
    5c3d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5c41:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5c45:	e9 3c ff ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5c50:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5c57:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5c5b:	44 89 ca             	mov    %r9d,%edx
    5c5e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5c63:	44 89 0c 24          	mov    %r9d,(%rsp)
    5c67:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5c6b:	44 89 d6             	mov    %r10d,%esi
    5c6e:	48 01 c7             	add    %rax,%rdi
    5c71:	e8 6a fa ff ff       	call   56e0 <fwp_heap_refill>
    5c76:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5c7b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5c7f:	49 89 c0             	mov    %rax,%r8
    5c82:	e9 ff fe ff ff       	jmp    5b86 <fwp_heap_alloc_slow+0x76>
    5c87:	e8 24 e0 ff ff       	call   3cb0 <fwp_heap_oom>
    5c8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005c90 <fwp_heap_alloc>:
    5c90:	8b 05 ee ce 01 00    	mov    0x1ceee(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    5c96:	48 89 fa             	mov    %rdi,%rdx
    5c99:	89 f7                	mov    %esi,%edi
    5c9b:	85 c0                	test   %eax,%eax
    5c9d:	0f 84 f5 00 00 00    	je     5d98 <fwp_heap_alloc+0x108>
    5ca3:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5caa:	0f 87 e8 00 00 00    	ja     5d98 <fwp_heap_alloc+0x108>
    5cb0:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5cb4:	48 8d 05 25 bb 01 00 	lea    0x1bb25(%rip),%rax        # 217e0 <fwp_heap>
    5cbb:	48 83 ec 18          	sub    $0x18,%rsp
    5cbf:	41 89 f0             	mov    %esi,%r8d
    5cc2:	48 c1 e9 04          	shr    $0x4,%rcx
    5cc6:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5ccd:	00 
    5cce:	48 63 cf             	movslq %edi,%rcx
    5cd1:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5cd8:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5cdf:	00 
    5ce0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5ce4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5ce8:	48 01 c8             	add    %rcx,%rax
    5ceb:	48 8b 08             	mov    (%rax),%rcx
    5cee:	48 85 c9             	test   %rcx,%rcx
    5cf1:	74 6d                	je     5d60 <fwp_heap_alloc+0xd0>
    5cf3:	48 8b 31             	mov    (%rcx),%rsi
    5cf6:	48 f7 d6             	not    %rsi
    5cf9:	48 89 30             	mov    %rsi,(%rax)
    5cfc:	41 83 f8 01          	cmp    $0x1,%r8d
    5d00:	48 89 cf             	mov    %rcx,%rdi
    5d03:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5d08:	49 0f 45 d1          	cmovne %r9,%rdx
    5d0c:	31 f6                	xor    %esi,%esi
    5d0e:	e8 ad d7 ff ff       	call   34c0 <memset@plt>
    5d13:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5d18:	48 89 c1             	mov    %rax,%rcx
    5d1b:	4c 89 c8             	mov    %r9,%rax
    5d1e:	48 03 05 db ce 01 00 	add    0x1cedb(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    5d25:	72 7b                	jb     5da2 <fwp_heap_alloc+0x112>
    5d27:	48 39 05 da ce 01 00 	cmp    %rax,0x1ceda(%rip)        # 22c08 <fwp_heap+0x1428>
    5d2e:	48 89 05 cb ce 01 00 	mov    %rax,0x1cecb(%rip)        # 22c00 <fwp_heap+0x1420>
    5d35:	73 07                	jae    5d3e <fwp_heap_alloc+0xae>
    5d37:	48 89 05 ca ce 01 00 	mov    %rax,0x1ceca(%rip)        # 22c08 <fwp_heap+0x1428>
    5d3e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d42:	48 89 c8             	mov    %rcx,%rax
    5d45:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5d4a:	f2 0f 58 05 c6 ce 01 	addsd  0x1cec6(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    5d51:	00 
    5d52:	f2 0f 11 05 be ce 01 	movsd  %xmm0,0x1cebe(%rip)        # 22c18 <fwp_heap+0x1438>
    5d59:	00 
    5d5a:	48 83 c4 18          	add    $0x18,%rsp
    5d5e:	c3                   	ret
    5d5f:	90                   	nop
    5d60:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5d64:	48 85 c9             	test   %rcx,%rcx
    5d67:	74 0c                	je     5d75 <fwp_heap_alloc+0xe5>
    5d69:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5d6d:	48 29 ce             	sub    %rcx,%rsi
    5d70:	4c 39 ce             	cmp    %r9,%rsi
    5d73:	73 13                	jae    5d88 <fwp_heap_alloc+0xf8>
    5d75:	89 fe                	mov    %edi,%esi
    5d77:	48 83 c4 18          	add    $0x18,%rsp
    5d7b:	48 89 d7             	mov    %rdx,%rdi
    5d7e:	e9 8d fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5d83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d88:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5d8c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5d90:	e9 67 ff ff ff       	jmp    5cfc <fwp_heap_alloc+0x6c>
    5d95:	0f 1f 00             	nopl   (%rax)
    5d98:	89 fe                	mov    %edi,%esi
    5d9a:	48 89 d7             	mov    %rdx,%rdi
    5d9d:	e9 6e fd ff ff       	jmp    5b10 <fwp_heap_alloc_slow>
    5da2:	e8 09 df ff ff       	call   3cb0 <fwp_heap_oom>
    5da7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5dae:	00 00 

0000000000005db0 <fwp_apply>:
    5db0:	55                   	push   %rbp
    5db1:	48 89 f9             	mov    %rdi,%rcx
    5db4:	48 89 e5             	mov    %rsp,%rbp
    5db7:	41 57                	push   %r15
    5db9:	41 56                	push   %r14
    5dbb:	41 55                	push   %r13
    5dbd:	41 89 f5             	mov    %esi,%r13d
    5dc0:	41 54                	push   %r12
    5dc2:	53                   	push   %rbx
    5dc3:	48 83 ec 28          	sub    $0x28,%rsp
    5dc7:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5dce:	00 00 
    5dd0:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5dd4:	49 89 d6             	mov    %rdx,%r14
    5dd7:	44 8b 09             	mov    (%rcx),%r9d
    5dda:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5dde:	49 89 e0             	mov    %rsp,%r8
    5de1:	49 c1 e1 05          	shl    $0x5,%r9
    5de5:	4c 03 0d 4c d6 01 00 	add    0x1d64c(%rip),%r9        # 23438 <fwp_fns>
    5dec:	41 8b 19             	mov    (%r9),%ebx
    5def:	45 85 e4             	test   %r12d,%r12d
    5df2:	75 2c                	jne    5e20 <fwp_apply+0x70>
    5df4:	41 39 dd             	cmp    %ebx,%r13d
    5df7:	72 27                	jb     5e20 <fwp_apply+0x70>
    5df9:	85 db                	test   %ebx,%ebx
    5dfb:	0f 84 a7 01 00 00    	je     5fa8 <fwp_apply+0x1f8>
    5e01:	4c 89 f7             	mov    %r14,%rdi
    5e04:	41 ff 51 08          	call   *0x8(%r9)
    5e08:	48 89 c1             	mov    %rax,%rcx
    5e0b:	41 39 dd             	cmp    %ebx,%r13d
    5e0e:	0f 84 6c 01 00 00    	je     5f80 <fwp_apply+0x1d0>
    5e14:	89 d8                	mov    %ebx,%eax
    5e16:	41 29 dd             	sub    %ebx,%r13d
    5e19:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5e1d:	eb b8                	jmp    5dd7 <fwp_apply+0x27>
    5e1f:	90                   	nop
    5e20:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5e25:	41 39 df             	cmp    %ebx,%r15d
    5e28:	0f 82 cc 00 00 00    	jb     5efa <fwp_apply+0x14a>
    5e2e:	41 89 df             	mov    %ebx,%r15d
    5e31:	b8 01 00 00 00       	mov    $0x1,%eax
    5e36:	48 89 e2             	mov    %rsp,%rdx
    5e39:	45 29 e7             	sub    %r12d,%r15d
    5e3c:	85 db                	test   %ebx,%ebx
    5e3e:	0f 45 c3             	cmovne %ebx,%eax
    5e41:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5e48:	00 
    5e49:	48 c1 e8 04          	shr    $0x4,%rax
    5e4d:	48 c1 e0 04          	shl    $0x4,%rax
    5e51:	48 89 c6             	mov    %rax,%rsi
    5e54:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5e5b:	48 29 f2             	sub    %rsi,%rdx
    5e5e:	48 39 d4             	cmp    %rdx,%rsp
    5e61:	74 15                	je     5e78 <fwp_apply+0xc8>
    5e63:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5e6a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5e71:	00 00 
    5e73:	48 39 d4             	cmp    %rdx,%rsp
    5e76:	75 eb                	jne    5e63 <fwp_apply+0xb3>
    5e78:	25 ff 0f 00 00       	and    $0xfff,%eax
    5e7d:	48 29 c4             	sub    %rax,%rsp
    5e80:	48 85 c0             	test   %rax,%rax
    5e83:	0f 85 49 01 00 00    	jne    5fd2 <fwp_apply+0x222>
    5e89:	45 89 e2             	mov    %r12d,%r10d
    5e8c:	48 89 e6             	mov    %rsp,%rsi
    5e8f:	48 89 e7             	mov    %rsp,%rdi
    5e92:	31 c0                	xor    %eax,%eax
    5e94:	49 c1 e2 03          	shl    $0x3,%r10
    5e98:	45 85 e4             	test   %r12d,%r12d
    5e9b:	74 15                	je     5eb2 <fwp_apply+0x102>
    5e9d:	0f 1f 00             	nopl   (%rax)
    5ea0:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5ea5:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5ea9:	48 83 c0 08          	add    $0x8,%rax
    5ead:	4c 39 d0             	cmp    %r10,%rax
    5eb0:	75 ee                	jne    5ea0 <fwp_apply+0xf0>
    5eb2:	45 85 ff             	test   %r15d,%r15d
    5eb5:	0f 84 f4 00 00 00    	je     5faf <fwp_apply+0x1ff>
    5ebb:	44 89 fa             	mov    %r15d,%edx
    5ebe:	4c 89 f0             	mov    %r14,%rax
    5ec1:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5ec5:	44 89 e2             	mov    %r12d,%edx
    5ec8:	66 90                	xchg   %ax,%ax
    5eca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5ed1:	00 00 00 00 
    5ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5edc:	00 00 00 00 
    5ee0:	4c 8b 10             	mov    (%rax),%r10
    5ee3:	89 d1                	mov    %edx,%ecx
    5ee5:	48 83 c0 08          	add    $0x8,%rax
    5ee9:	83 c2 01             	add    $0x1,%edx
    5eec:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5ef0:	4c 39 d8             	cmp    %r11,%rax
    5ef3:	75 eb                	jne    5ee0 <fwp_apply+0x130>
    5ef5:	e9 b5 00 00 00       	jmp    5faf <fwp_apply+0x1ff>
    5efa:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5efe:	be 02 00 00 00       	mov    $0x2,%esi
    5f03:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5f07:	48 c1 e7 03          	shl    $0x3,%rdi
    5f0b:	e8 80 fd ff ff       	call   5c90 <fwp_heap_alloc>
    5f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5f14:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5f19:	48 89 c3             	mov    %rax,%rbx
    5f1c:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5f20:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5f24:	66 0f d6 00          	movq   %xmm0,(%rax)
    5f28:	45 85 e4             	test   %r12d,%r12d
    5f2b:	74 14                	je     5f41 <fwp_apply+0x191>
    5f2d:	44 89 e2             	mov    %r12d,%edx
    5f30:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5f34:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5f38:	48 c1 e2 03          	shl    $0x3,%rdx
    5f3c:	e8 cf d6 ff ff       	call   3610 <memmove@plt>
    5f41:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5f45:	45 85 ed             	test   %r13d,%r13d
    5f48:	74 2e                	je     5f78 <fwp_apply+0x1c8>
    5f4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f51:	00 00 00 00 
    5f55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5f5c:	00 00 00 00 
    5f60:	49 8b 16             	mov    (%r14),%rdx
    5f63:	44 89 e0             	mov    %r12d,%eax
    5f66:	49 83 c6 08          	add    $0x8,%r14
    5f6a:	41 83 c4 01          	add    $0x1,%r12d
    5f6e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5f73:	49 39 ce             	cmp    %rcx,%r14
    5f76:	75 e8                	jne    5f60 <fwp_apply+0x1b0>
    5f78:	48 89 d9             	mov    %rbx,%rcx
    5f7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f80:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5f84:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5f8b:	00 00 
    5f8d:	75 4e                	jne    5fdd <fwp_apply+0x22d>
    5f8f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5f93:	48 89 c8             	mov    %rcx,%rax
    5f96:	5b                   	pop    %rbx
    5f97:	41 5c                	pop    %r12
    5f99:	41 5d                	pop    %r13
    5f9b:	41 5e                	pop    %r14
    5f9d:	41 5f                	pop    %r15
    5f9f:	5d                   	pop    %rbp
    5fa0:	c3                   	ret
    5fa1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5fa8:	45 31 ff             	xor    %r15d,%r15d
    5fab:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5faf:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5fb3:	41 ff 51 08          	call   *0x8(%r9)
    5fb7:	48 89 c1             	mov    %rax,%rcx
    5fba:	45 39 fd             	cmp    %r15d,%r13d
    5fbd:	74 c1                	je     5f80 <fwp_apply+0x1d0>
    5fbf:	45 01 e5             	add    %r12d,%r13d
    5fc2:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5fc6:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5fca:	41 29 dd             	sub    %ebx,%r13d
    5fcd:	e9 05 fe ff ff       	jmp    5dd7 <fwp_apply+0x27>
    5fd2:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5fd8:	e9 ac fe ff ff       	jmp    5e89 <fwp_apply+0xd9>
    5fdd:	e8 7e d4 ff ff       	call   3460 <__stack_chk_fail@plt>
    5fe2:	0f 1f 00             	nopl   (%rax)
    5fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5fec:	00 00 00 00 

0000000000005ff0 <fwp_tape_reserve>:
    5ff0:	41 57                	push   %r15
    5ff2:	41 56                	push   %r14
    5ff4:	41 55                	push   %r13
    5ff6:	41 54                	push   %r12
    5ff8:	55                   	push   %rbp
    5ff9:	53                   	push   %rbx
    5ffa:	48 83 ec 18          	sub    $0x18,%rsp
    5ffe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    6005:	0f 87 d3 01 00 00    	ja     61de <fwp_tape_reserve+0x1ee>
    600b:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    600f:	48 89 fd             	mov    %rdi,%rbp
    6012:	48 39 f3             	cmp    %rsi,%rbx
    6015:	0f 8d 13 01 00 00    	jge    612e <fwp_tape_reserve+0x13e>
    601b:	48 85 db             	test   %rbx,%rbx
    601e:	b8 40 00 00 00       	mov    $0x40,%eax
    6023:	48 0f 44 d8          	cmove  %rax,%rbx
    6027:	48 39 f3             	cmp    %rsi,%rbx
    602a:	7d 24                	jge    6050 <fwp_tape_reserve+0x60>
    602c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6033:	0f 8f 07 01 00 00    	jg     6140 <fwp_tape_reserve+0x150>
    6039:	48 01 db             	add    %rbx,%rbx
    603c:	48 39 f3             	cmp    %rsi,%rbx
    603f:	7c eb                	jl     602c <fwp_tape_reserve+0x3c>
    6041:	0f 1f 40 00          	nopl   0x0(%rax)
    6045:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    604c:	00 00 00 00 
    6050:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    6057:	00 
    6058:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    605c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    6060:	4c 89 ee             	mov    %r13,%rsi
    6063:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    6067:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    606b:	e8 60 d5 ff ff       	call   35d0 <realloc@plt>
    6070:	48 85 c0             	test   %rax,%rax
    6073:	0f 84 71 01 00 00    	je     61ea <fwp_tape_reserve+0x1fa>
    6079:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    607d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    6081:	4d 29 fc             	sub    %r15,%r12
    6084:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    6088:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    608c:	4d 85 f6             	test   %r14,%r14
    608f:	0f 84 03 01 00 00    	je     6198 <fwp_tape_reserve+0x1a8>
    6095:	49 8b 56 60          	mov    0x60(%r14),%rdx
    6099:	48 39 da             	cmp    %rbx,%rdx
    609c:	7d 78                	jge    6116 <fwp_tape_reserve+0x126>
    609e:	48 89 d9             	mov    %rbx,%rcx
    60a1:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    60a5:	be 02 00 00 00       	mov    $0x2,%esi
    60aa:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    60af:	48 c1 e1 04          	shl    $0x4,%rcx
    60b3:	48 89 cf             	mov    %rcx,%rdi
    60b6:	48 89 0c 24          	mov    %rcx,(%rsp)
    60ba:	e8 d1 fb ff ff       	call   5c90 <fwp_heap_alloc>
    60bf:	49 89 c5             	mov    %rax,%r13
    60c2:	4d 85 ff             	test   %r15,%r15
    60c5:	74 27                	je     60ee <fwp_tape_reserve+0xfe>
    60c7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    60cc:	48 8b 0c 24          	mov    (%rsp),%rcx
    60d0:	48 89 c7             	mov    %rax,%rdi
    60d3:	4c 89 fe             	mov    %r15,%rsi
    60d6:	48 c1 e2 04          	shl    $0x4,%rdx
    60da:	48 39 ca             	cmp    %rcx,%rdx
    60dd:	48 0f 47 d1          	cmova  %rcx,%rdx
    60e1:	e8 ba d4 ff ff       	call   35a0 <memcpy@plt>
    60e6:	4c 89 ff             	mov    %r15,%rdi
    60e9:	e8 a2 f6 ff ff       	call   5790 <fwp_mem_free>
    60ee:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    60f2:	48 89 da             	mov    %rbx,%rdx
    60f5:	31 f6                	xor    %esi,%esi
    60f7:	48 29 fa             	sub    %rdi,%rdx
    60fa:	48 c1 e7 04          	shl    $0x4,%rdi
    60fe:	48 c1 e2 04          	shl    $0x4,%rdx
    6102:	4c 01 ef             	add    %r13,%rdi
    6105:	e8 b6 d3 ff ff       	call   34c0 <memset@plt>
    610a:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    610e:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6112:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    6116:	4d 85 e4             	test   %r12,%r12
    6119:	75 55                	jne    6170 <fwp_tape_reserve+0x180>
    611b:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6122:	00 
    6123:	4c 01 e8             	add    %r13,%rax
    6126:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    612a:	48 89 45 28          	mov    %rax,0x28(%rbp)
    612e:	48 83 c4 18          	add    $0x18,%rsp
    6132:	5b                   	pop    %rbx
    6133:	5d                   	pop    %rbp
    6134:	41 5c                	pop    %r12
    6136:	41 5d                	pop    %r13
    6138:	41 5e                	pop    %r14
    613a:	41 5f                	pop    %r15
    613c:	c3                   	ret
    613d:	0f 1f 00             	nopl   (%rax)
    6140:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    6145:	e9 06 ff ff ff       	jmp    6050 <fwp_tape_reserve+0x60>
    614a:	4d 39 f5             	cmp    %r14,%r13
    614d:	4c 89 f1             	mov    %r14,%rcx
    6150:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6157:	00 
    6158:	49 0f 43 cd          	cmovae %r13,%rcx
    615c:	4c 29 e9             	sub    %r13,%rcx
    615f:	e8 fc d3 ff ff       	call   3560 <__memmove_chk@plt>
    6164:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6168:	48 8b 45 20          	mov    0x20(%rbp),%rax
    616c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    6170:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    6174:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    617b:	00 
    617c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    6183:	00 
    6184:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6188:	e8 83 d4 ff ff       	call   3610 <memmove@plt>
    618d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6191:	eb 90                	jmp    6123 <fwp_tape_reserve+0x133>
    6193:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6198:	49 89 de             	mov    %rbx,%r14
    619b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    619f:	49 c1 e6 04          	shl    $0x4,%r14
    61a3:	4c 89 f6             	mov    %r14,%rsi
    61a6:	e8 25 d4 ff ff       	call   35d0 <realloc@plt>
    61ab:	48 85 c0             	test   %rax,%rax
    61ae:	74 3a                	je     61ea <fwp_tape_reserve+0x1fa>
    61b0:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    61b4:	48 89 45 30          	mov    %rax,0x30(%rbp)
    61b8:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    61bc:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    61c0:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    61c4:	4d 85 e4             	test   %r12,%r12
    61c7:	75 81                	jne    614a <fwp_tape_reserve+0x15a>
    61c9:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    61cd:	48 8b 45 20          	mov    0x20(%rbp),%rax
    61d1:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    61d8:	00 
    61d9:	e9 45 ff ff ff       	jmp    6123 <fwp_tape_reserve+0x133>
    61de:	48 8d 3d 67 6f 00 00 	lea    0x6f67(%rip),%rdi        # d14c <_IO_stdin_used+0x14c>
    61e5:	e8 06 e2 ff ff       	call   43f0 <fwp_trap>
    61ea:	48 89 ef             	mov    %rbp,%rdi
    61ed:	e8 0e da ff ff       	call   3c00 <fwp_tape_unlink_scope>
    61f2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    61f6:	e8 c5 d1 ff ff       	call   33c0 <free@plt>
    61fb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    61ff:	e8 bc d1 ff ff       	call   33c0 <free@plt>
    6204:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    6208:	e8 b3 d1 ff ff       	call   33c0 <free@plt>
    620d:	31 c9                	xor    %ecx,%ecx
    620f:	31 c0                	xor    %eax,%eax
    6211:	31 d2                	xor    %edx,%edx
    6213:	89 55 04             	mov    %edx,0x4(%rbp)
    6216:	66 0f ef c0          	pxor   %xmm0,%xmm0
    621a:	ba 13 00 00 00       	mov    $0x13,%edx
    621f:	be 01 00 00 00       	mov    $0x1,%esi
    6224:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6228:	48 8d 3d d9 6d 00 00 	lea    0x6dd9(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    622f:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    6233:	48 8b 0d 26 ae 00 00 	mov    0xae26(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    623a:	48 89 45 40          	mov    %rax,0x40(%rbp)
    623e:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6242:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6246:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    624a:	e8 31 d4 ff ff       	call   3680 <fwrite@plt>
    624f:	31 ff                	xor    %edi,%edi
    6251:	e8 6a d3 ff ff       	call   35c0 <fflush@plt>
    6256:	bf 66 00 00 00       	mov    $0x66,%edi
    625b:	e8 40 d4 ff ff       	call   36a0 <_Exit@plt>

0000000000006260 <f128.constprop.0>:
    6260:	41 57                	push   %r15
    6262:	41 56                	push   %r14
    6264:	41 55                	push   %r13
    6266:	41 54                	push   %r12
    6268:	49 89 f4             	mov    %rsi,%r12
    626b:	55                   	push   %rbp
    626c:	48 89 fd             	mov    %rdi,%rbp
    626f:	53                   	push   %rbx
    6270:	48 83 ec 08          	sub    $0x8,%rsp
    6274:	48 85 ff             	test   %rdi,%rdi
    6277:	79 09                	jns    6282 <f128.constprop.0+0x22>
    6279:	48 85 f6             	test   %rsi,%rsi
    627c:	0f 88 fe 00 00 00    	js     6380 <f128.constprop.0+0x120>
    6282:	48 89 f8             	mov    %rdi,%rax
    6285:	48 09 f0             	or     %rsi,%rax
    6288:	0f 89 d2 00 00 00    	jns    6360 <f128.constprop.0+0x100>
    628e:	48 89 f8             	mov    %rdi,%rax
    6291:	48 c1 f8 20          	sar    $0x20,%rax
    6295:	48 85 ff             	test   %rdi,%rdi
    6298:	0f 88 02 01 00 00    	js     63a0 <f128.constprop.0+0x140>
    629e:	4c 8b 3d 7b 79 00 00 	mov    0x797b(%rip),%r15        # dc20 <msg.4+0xb0>
    62a5:	48 89 c7             	mov    %rax,%rdi
    62a8:	e8 23 e4 ff ff       	call   46d0 <fwp_tape_of>
    62ad:	48 89 c3             	mov    %rax,%rbx
    62b0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62b5:	0f 85 16 01 00 00    	jne    63d1 <f128.constprop.0+0x171>
    62bb:	4c 8b 68 10          	mov    0x10(%rax),%r13
    62bf:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    62c6:	0f 8f f9 00 00 00    	jg     63c5 <f128.constprop.0+0x165>
    62cc:	89 e8                	mov    %ebp,%eax
    62ce:	49 39 c5             	cmp    %rax,%r13
    62d1:	0f 8e e2 00 00 00    	jle    63b9 <f128.constprop.0+0x159>
    62d7:	4d 85 e4             	test   %r12,%r12
    62da:	78 0c                	js     62e8 <f128.constprop.0+0x88>
    62dc:	44 89 e0             	mov    %r12d,%eax
    62df:	49 39 c5             	cmp    %rax,%r13
    62e2:	0f 8e d1 00 00 00    	jle    63b9 <f128.constprop.0+0x159>
    62e8:	4d 89 ee             	mov    %r13,%r14
    62eb:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    62ef:	48 89 df             	mov    %rbx,%rdi
    62f2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    62f6:	e8 f5 fc ff ff       	call   5ff0 <fwp_tape_reserve>
    62fb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    62ff:	4d 85 e4             	test   %r12,%r12
    6302:	48 8b 0d 17 79 00 00 	mov    0x7917(%rip),%rcx        # dc20 <msg.4+0xb0>
    6309:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6310:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6314:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6318:	4c 0f 48 e2          	cmovs  %rdx,%r12
    631c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6320:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6324:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6328:	48 8b 43 38          	mov    0x38(%rbx),%rax
    632c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6330:	49 8d 45 01          	lea    0x1(%r13),%rax
    6334:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6338:	48 83 c4 08          	add    $0x8,%rsp
    633c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6343:	ff ff ff 
    6346:	48 21 e8             	and    %rbp,%rax
    6349:	5b                   	pop    %rbx
    634a:	5d                   	pop    %rbp
    634b:	4c 09 e8             	or     %r13,%rax
    634e:	41 5c                	pop    %r12
    6350:	41 5d                	pop    %r13
    6352:	41 5e                	pop    %r14
    6354:	41 5f                	pop    %r15
    6356:	c3                   	ret
    6357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    635e:	00 00 
    6360:	48 89 f0             	mov    %rsi,%rax
    6363:	48 c1 ff 20          	sar    $0x20,%rdi
    6367:	48 c1 f8 20          	sar    $0x20,%rax
    636b:	48 39 c7             	cmp    %rax,%rdi
    636e:	0f 84 2a ff ff ff    	je     629e <f128.constprop.0+0x3e>
    6374:	48 8d 3d 35 75 00 00 	lea    0x7535(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    637b:	e8 70 e0 ff ff       	call   43f0 <fwp_trap>
    6380:	48 83 c4 08          	add    $0x8,%rsp
    6384:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    638b:	5b                   	pop    %rbx
    638c:	5d                   	pop    %rbp
    638d:	41 5c                	pop    %r12
    638f:	41 5d                	pop    %r13
    6391:	41 5e                	pop    %r14
    6393:	41 5f                	pop    %r15
    6395:	c3                   	ret
    6396:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    639d:	00 00 00 
    63a0:	48 89 f0             	mov    %rsi,%rax
    63a3:	48 89 f5             	mov    %rsi,%rbp
    63a6:	45 31 ff             	xor    %r15d,%r15d
    63a9:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    63b0:	48 c1 f8 20          	sar    $0x20,%rax
    63b4:	e9 ec fe ff ff       	jmp    62a5 <f128.constprop.0+0x45>
    63b9:	48 8d 3d a7 6d 00 00 	lea    0x6da7(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    63c0:	e8 2b e0 ff ff       	call   43f0 <fwp_trap>
    63c5:	48 8d 3d 80 6d 00 00 	lea    0x6d80(%rip),%rdi        # d14c <_IO_stdin_used+0x14c>
    63cc:	e8 1f e0 ff ff       	call   43f0 <fwp_trap>
    63d1:	48 8d 3d 20 75 00 00 	lea    0x7520(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    63d8:	e8 13 e0 ff ff       	call   43f0 <fwp_trap>
    63dd:	0f 1f 00             	nopl   (%rax)

00000000000063e0 <w107>:
    63e0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    63e4:	41 57                	push   %r15
    63e6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    63ea:	41 56                	push   %r14
    63ec:	41 55                	push   %r13
    63ee:	41 54                	push   %r12
    63f0:	49 89 f4             	mov    %rsi,%r12
    63f3:	55                   	push   %rbp
    63f4:	48 89 fd             	mov    %rdi,%rbp
    63f7:	53                   	push   %rbx
    63f8:	48 83 ec 38          	sub    $0x38,%rsp
    63fc:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    6401:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    6407:	48 85 ff             	test   %rdi,%rdi
    640a:	0f 88 d0 04 00 00    	js     68e0 <w107+0x500>
    6410:	49 89 ff             	mov    %rdi,%r15
    6413:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6419:	49 c1 ff 20          	sar    $0x20,%r15
    641d:	4c 89 ff             	mov    %r15,%rdi
    6420:	e8 ab e2 ff ff       	call   46d0 <fwp_tape_of>
    6425:	48 89 c3             	mov    %rax,%rbx
    6428:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    642d:	0f 85 45 05 00 00    	jne    6978 <w107+0x598>
    6433:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6437:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    643e:	0f 8f 28 05 00 00    	jg     696c <w107+0x58c>
    6444:	89 e8                	mov    %ebp,%eax
    6446:	49 39 c5             	cmp    %rax,%r13
    6449:	0f 8e 11 05 00 00    	jle    6960 <w107+0x580>
    644f:	4d 89 ee             	mov    %r13,%r14
    6452:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6456:	48 89 df             	mov    %rbx,%rdi
    6459:	49 8d 76 01          	lea    0x1(%r14),%rsi
    645d:	e8 8e fb ff ff       	call   5ff0 <fwp_tape_reserve>
    6462:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6466:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    646b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6471:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6475:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6479:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    647f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6483:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6487:	48 8b 43 38          	mov    0x38(%rbx),%rax
    648b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6491:	49 8d 45 01          	lea    0x1(%r13),%rax
    6495:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    649c:	ff ff ff 
    649f:	49 21 ee             	and    %rbp,%r14
    64a2:	48 89 43 10          	mov    %rax,0x10(%rbx)
    64a6:	4d 09 ee             	or     %r13,%r14
    64a9:	4d 89 f5             	mov    %r14,%r13
    64ac:	49 c1 fd 20          	sar    $0x20,%r13
    64b0:	4d 85 e4             	test   %r12,%r12
    64b3:	78 10                	js     64c5 <w107+0xe5>
    64b5:	4c 89 e0             	mov    %r12,%rax
    64b8:	48 c1 f8 20          	sar    $0x20,%rax
    64bc:	4c 39 e8             	cmp    %r13,%rax
    64bf:	0f 85 87 04 00 00    	jne    694c <w107+0x56c>
    64c5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    64cb:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    64d1:	4d 39 ef             	cmp    %r13,%r15
    64d4:	0f 84 d6 03 00 00    	je     68b0 <w107+0x4d0>
    64da:	f2 0f 10 1d 3e 77 00 	movsd  0x773e(%rip),%xmm3        # dc20 <msg.4+0xb0>
    64e1:	00 
    64e2:	f2 0f 10 25 3e 77 00 	movsd  0x773e(%rip),%xmm4        # dc28 <msg.4+0xb8>
    64e9:	00 
    64ea:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    64f0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    64f6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    64fc:	4c 89 ef             	mov    %r13,%rdi
    64ff:	e8 cc e1 ff ff       	call   46d0 <fwp_tape_of>
    6504:	48 89 c3             	mov    %rax,%rbx
    6507:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    650c:	0f 85 66 04 00 00    	jne    6978 <w107+0x598>
    6512:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6516:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    651d:	0f 8f 49 04 00 00    	jg     696c <w107+0x58c>
    6523:	44 89 f0             	mov    %r14d,%eax
    6526:	49 39 c7             	cmp    %rax,%r15
    6529:	0f 8e 31 04 00 00    	jle    6960 <w107+0x580>
    652f:	4d 85 e4             	test   %r12,%r12
    6532:	78 0c                	js     6540 <w107+0x160>
    6534:	44 89 e0             	mov    %r12d,%eax
    6537:	49 39 c7             	cmp    %rax,%r15
    653a:	0f 8e 20 04 00 00    	jle    6960 <w107+0x580>
    6540:	4c 89 f9             	mov    %r15,%rcx
    6543:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6547:	48 89 df             	mov    %rbx,%rdi
    654a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    654e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6553:	e8 98 fa ff ff       	call   5ff0 <fwp_tape_reserve>
    6558:	48 8b 43 20          	mov    0x20(%rbx),%rax
    655c:	4d 85 e4             	test   %r12,%r12
    655f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6563:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6568:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    656e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6574:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6578:	48 8b 43 30          	mov    0x30(%rbx),%rax
    657c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6581:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6588:	49 0f 49 c4          	cmovns %r12,%rax
    658c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6590:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6593:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6597:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    659c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    65a0:	48 85 ed             	test   %rbp,%rbp
    65a3:	0f 88 0e 04 00 00    	js     69b7 <w107+0x5d7>
    65a9:	48 89 e8             	mov    %rbp,%rax
    65ac:	48 c1 f8 20          	sar    $0x20,%rax
    65b0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    65b5:	49 39 c5             	cmp    %rax,%r13
    65b8:	74 1a                	je     65d4 <w107+0x1f4>
    65ba:	48 89 c7             	mov    %rax,%rdi
    65bd:	e8 0e e1 ff ff       	call   46d0 <fwp_tape_of>
    65c2:	48 89 c3             	mov    %rax,%rbx
    65c5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65ca:	0f 85 a8 03 00 00    	jne    6978 <w107+0x598>
    65d0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    65d4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    65db:	0f 8f 8b 03 00 00    	jg     696c <w107+0x58c>
    65e1:	89 e8                	mov    %ebp,%eax
    65e3:	4c 39 e0             	cmp    %r12,%rax
    65e6:	0f 8d 74 03 00 00    	jge    6960 <w107+0x580>
    65ec:	4c 89 e0             	mov    %r12,%rax
    65ef:	48 2b 43 08          	sub    0x8(%rbx),%rax
    65f3:	48 89 df             	mov    %rbx,%rdi
    65f6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    65fa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    65ff:	e8 ec f9 ff ff       	call   5ff0 <fwp_tape_reserve>
    6604:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    6609:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    660d:	48 8b 0d 14 76 00 00 	mov    0x7614(%rip),%rcx        # dc28 <msg.4+0xb8>
    6614:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    661a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    661d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6621:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6625:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    662b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    662f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6633:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6637:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    663e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6642:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6647:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    664c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6650:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6657:	ff ff ff 
    665a:	48 21 c5             	and    %rax,%rbp
    665d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6663:	4c 09 e5             	or     %r12,%rbp
    6666:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    666d:	ff ff ff 
    6670:	49 21 c6             	and    %rax,%r14
    6673:	4d 09 fe             	or     %r15,%r14
    6676:	4d 89 f4             	mov    %r14,%r12
    6679:	49 c1 fc 20          	sar    $0x20,%r12
    667d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6682:	74 16                	je     669a <w107+0x2ba>
    6684:	4c 89 e7             	mov    %r12,%rdi
    6687:	e8 44 e0 ff ff       	call   46d0 <fwp_tape_of>
    668c:	48 89 c3             	mov    %rax,%rbx
    668f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6694:	0f 85 de 02 00 00    	jne    6978 <w107+0x598>
    669a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    669e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    66a5:	0f 8f c1 02 00 00    	jg     696c <w107+0x58c>
    66ab:	44 89 f0             	mov    %r14d,%eax
    66ae:	49 39 c7             	cmp    %rax,%r15
    66b1:	0f 8e a9 02 00 00    	jle    6960 <w107+0x580>
    66b7:	4d 89 fd             	mov    %r15,%r13
    66ba:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    66be:	48 89 df             	mov    %rbx,%rdi
    66c1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    66c5:	e8 26 f9 ff ff       	call   5ff0 <fwp_tape_reserve>
    66ca:	48 8b 43 20          	mov    0x20(%rbx),%rax
    66ce:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    66d4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    66d8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    66dc:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    66e2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    66e6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    66ea:	48 8b 43 38          	mov    0x38(%rbx),%rax
    66ee:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    66f4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    66f8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    66ff:	ff ff ff 
    6702:	49 21 c6             	and    %rax,%r14
    6705:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    6709:	4d 09 fe             	or     %r15,%r14
    670c:	4d 89 f7             	mov    %r14,%r15
    670f:	49 c1 ff 20          	sar    $0x20,%r15
    6713:	4d 39 e7             	cmp    %r12,%r15
    6716:	74 1d                	je     6735 <w107+0x355>
    6718:	4c 89 ff             	mov    %r15,%rdi
    671b:	e8 b0 df ff ff       	call   46d0 <fwp_tape_of>
    6720:	48 89 c3             	mov    %rax,%rbx
    6723:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6728:	0f 85 4a 02 00 00    	jne    6978 <w107+0x598>
    672e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6732:	4d 89 fc             	mov    %r15,%r12
    6735:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    673c:	0f 8f 2a 02 00 00    	jg     696c <w107+0x58c>
    6742:	44 89 f0             	mov    %r14d,%eax
    6745:	4c 39 e8             	cmp    %r13,%rax
    6748:	0f 8d 12 02 00 00    	jge    6960 <w107+0x580>
    674e:	f2 0f 10 3d da 74 00 	movsd  0x74da(%rip),%xmm7        # dc30 <msg.4+0xc0>
    6755:	00 
    6756:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    675c:	4d 89 ef             	mov    %r13,%r15
    675f:	48 89 df             	mov    %rbx,%rdi
    6762:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6768:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    676d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6771:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6775:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    677a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6780:	e8 6b f8 ff ff       	call   5ff0 <fwp_tape_reserve>
    6785:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6789:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    678e:	48 8b 15 9b 74 00 00 	mov    0x749b(%rip),%rdx        # dc30 <msg.4+0xc0>
    6795:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6799:	48 8b 43 30          	mov    0x30(%rbx),%rax
    679d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    67a1:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    67a5:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    67a9:	48 8b 43 28          	mov    0x28(%rbx),%rax
    67ad:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    67b4:	ff 
    67b5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    67b9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    67c0:	00 
    67c1:	49 8d 45 01          	lea    0x1(%r13),%rax
    67c5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    67c9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    67d0:	ff ff ff 
    67d3:	49 21 c6             	and    %rax,%r14
    67d6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    67dc:	4d 09 ee             	or     %r13,%r14
    67df:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    67e3:	0f 84 57 01 00 00    	je     6940 <w107+0x560>
    67e9:	48 89 ef             	mov    %rbp,%rdi
    67ec:	48 c1 ff 20          	sar    $0x20,%rdi
    67f0:	4c 39 e7             	cmp    %r12,%rdi
    67f3:	74 13                	je     6808 <w107+0x428>
    67f5:	e8 d6 de ff ff       	call   46d0 <fwp_tape_of>
    67fa:	48 89 c3             	mov    %rax,%rbx
    67fd:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6802:	0f 85 70 01 00 00    	jne    6978 <w107+0x598>
    6808:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    680c:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6813:	0f 8f 53 01 00 00    	jg     696c <w107+0x58c>
    6819:	89 e8                	mov    %ebp,%eax
    681b:	4c 39 e0             	cmp    %r12,%rax
    681e:	0f 8d 3c 01 00 00    	jge    6960 <w107+0x580>
    6824:	4d 89 e5             	mov    %r12,%r13
    6827:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    682b:	48 89 df             	mov    %rbx,%rdi
    682e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6832:	e8 b9 f7 ff ff       	call   5ff0 <fwp_tape_reserve>
    6837:	48 8b 43 20          	mov    0x20(%rbx),%rax
    683b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6840:	48 89 ef             	mov    %rbp,%rdi
    6843:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6847:	48 8b 43 30          	mov    0x30(%rbx),%rax
    684b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6851:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6855:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6859:	48 8b 43 38          	mov    0x38(%rbx),%rax
    685d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6863:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6868:	48 89 43 10          	mov    %rax,0x10(%rbx)
    686c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6873:	ff ff ff 
    6876:	48 21 c7             	and    %rax,%rdi
    6879:	4c 09 e7             	or     %r12,%rdi
    687c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6882:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6888:	4c 89 f6             	mov    %r14,%rsi
    688b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6890:	e8 cb f9 ff ff       	call   6260 <f128.constprop.0>
    6895:	48 83 c4 38          	add    $0x38,%rsp
    6899:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    689e:	5b                   	pop    %rbx
    689f:	5d                   	pop    %rbp
    68a0:	41 5c                	pop    %r12
    68a2:	41 5d                	pop    %r13
    68a4:	41 5e                	pop    %r14
    68a6:	41 5f                	pop    %r15
    68a8:	c3                   	ret
    68a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    68b0:	f2 0f 10 3d 68 73 00 	movsd  0x7368(%rip),%xmm7        # dc20 <msg.4+0xb0>
    68b7:	00 
    68b8:	f2 0f 10 15 68 73 00 	movsd  0x7368(%rip),%xmm2        # dc28 <msg.4+0xb8>
    68bf:	00 
    68c0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    68c6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    68cc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    68d2:	e9 3b fc ff ff       	jmp    6512 <w107+0x132>
    68d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    68de:	00 00 
    68e0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    68e6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    68ec:	48 85 f6             	test   %rsi,%rsi
    68ef:	0f 89 8f 00 00 00    	jns    6984 <w107+0x5a4>
    68f5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    68fb:	f2 0f 10 05 1d 73 00 	movsd  0x731d(%rip),%xmm0        # dc20 <msg.4+0xb0>
    6902:	00 
    6903:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    690a:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6911:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6916:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    691a:	f2 0f 59 0d 0e 73 00 	mulsd  0x730e(%rip),%xmm1        # dc30 <msg.4+0xc0>
    6921:	00 
    6922:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6926:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    692c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6932:	e9 45 ff ff ff       	jmp    687c <w107+0x49c>
    6937:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    693e:	00 00 
    6940:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6947:	e9 30 ff ff ff       	jmp    687c <w107+0x49c>
    694c:	48 8d 3d 5d 6f 00 00 	lea    0x6f5d(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    6953:	e8 98 da ff ff       	call   43f0 <fwp_trap>
    6958:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    695f:	00 
    6960:	48 8d 3d 00 68 00 00 	lea    0x6800(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    6967:	e8 84 da ff ff       	call   43f0 <fwp_trap>
    696c:	48 8d 3d d9 67 00 00 	lea    0x67d9(%rip),%rdi        # d14c <_IO_stdin_used+0x14c>
    6973:	e8 78 da ff ff       	call   43f0 <fwp_trap>
    6978:	48 8d 3d 79 6f 00 00 	lea    0x6f79(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    697f:	e8 6c da ff ff       	call   43f0 <fwp_trap>
    6984:	f2 0f 10 35 94 72 00 	movsd  0x7294(%rip),%xmm6        # dc20 <msg.4+0xb0>
    698b:	00 
    698c:	49 89 f5             	mov    %rsi,%r13
    698f:	49 89 f6             	mov    %rsi,%r14
    6992:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6999:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    69a0:	00 00 
    69a2:	49 c1 fd 20          	sar    $0x20,%r13
    69a6:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    69ac:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    69b2:	e9 45 fb ff ff       	jmp    64fc <w107+0x11c>
    69b7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    69bd:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    69c2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    69c9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    69cd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    69d1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    69d7:	e9 8a fc ff ff       	jmp    6666 <w107+0x286>
    69dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000069e0 <fwp_data.part.0.constprop.0>:
    69e0:	41 56                	push   %r14
    69e2:	41 89 fe             	mov    %edi,%r14d
    69e5:	41 54                	push   %r12
    69e7:	49 89 f4             	mov    %rsi,%r12
    69ea:	55                   	push   %rbp
    69eb:	53                   	push   %rbx
    69ec:	48 83 ec 08          	sub    $0x8,%rsp
    69f0:	8b 05 8e c1 01 00    	mov    0x1c18e(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    69f6:	85 c0                	test   %eax,%eax
    69f8:	0f 84 fa 00 00 00    	je     6af8 <fwp_data.part.0.constprop.0+0x118>
    69fe:	0f b6 05 7d bd 01 00 	movzbl 0x1bd7d(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    6a05:	48 8d 15 d4 ad 01 00 	lea    0x1add4(%rip),%rdx        # 217e0 <fwp_heap>
    6a0c:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6a13:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6a17:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6a1b:	48 8b 18             	mov    (%rax),%rbx
    6a1e:	48 85 db             	test   %rbx,%rbx
    6a21:	0f 84 a9 00 00 00    	je     6ad0 <fwp_data.part.0.constprop.0+0xf0>
    6a27:	48 8b 13             	mov    (%rbx),%rdx
    6a2a:	48 f7 d2             	not    %rdx
    6a2d:	48 89 10             	mov    %rdx,(%rax)
    6a30:	48 83 fd 18          	cmp    $0x18,%rbp
    6a34:	76 1b                	jbe    6a51 <fwp_data.part.0.constprop.0+0x71>
    6a36:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6a3a:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    6a3e:	31 f6                	xor    %esi,%esi
    6a40:	48 c1 e8 03          	shr    $0x3,%rax
    6a44:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6a4b:	00 
    6a4c:	e8 6f ca ff ff       	call   34c0 <memset@plt>
    6a51:	48 89 e8             	mov    %rbp,%rax
    6a54:	48 03 05 a5 c1 01 00 	add    0x1c1a5(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    6a5b:	0f 82 a8 00 00 00    	jb     6b09 <fwp_data.part.0.constprop.0+0x129>
    6a61:	48 39 05 a0 c1 01 00 	cmp    %rax,0x1c1a0(%rip)        # 22c08 <fwp_heap+0x1428>
    6a68:	48 89 05 91 c1 01 00 	mov    %rax,0x1c191(%rip)        # 22c00 <fwp_heap+0x1420>
    6a6f:	73 07                	jae    6a78 <fwp_data.part.0.constprop.0+0x98>
    6a71:	48 89 05 90 c1 01 00 	mov    %rax,0x1c190(%rip)        # 22c08 <fwp_heap+0x1428>
    6a78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6a7c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6a81:	f2 0f 58 05 8f c1 01 	addsd  0x1c18f(%rip),%xmm0        # 22c18 <fwp_heap+0x1438>
    6a88:	00 
    6a89:	f2 0f 11 05 87 c1 01 	movsd  %xmm0,0x1c187(%rip)        # 22c18 <fwp_heap+0x1438>
    6a90:	00 
    6a91:	b8 02 00 00 00       	mov    $0x2,%eax
    6a96:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    6a9b:	66 0f 6e c8          	movd   %eax,%xmm1
    6a9f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6aa3:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6aa7:	49 8b 04 24          	mov    (%r12),%rax
    6aab:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6aaf:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6ab4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6ab8:	48 83 c4 08          	add    $0x8,%rsp
    6abc:	48 89 d8             	mov    %rbx,%rax
    6abf:	5b                   	pop    %rbx
    6ac0:	5d                   	pop    %rbp
    6ac1:	41 5c                	pop    %r12
    6ac3:	41 5e                	pop    %r14
    6ac5:	c3                   	ret
    6ac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6acd:	00 00 00 
    6ad0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6ad4:	48 85 db             	test   %rbx,%rbx
    6ad7:	74 1f                	je     6af8 <fwp_data.part.0.constprop.0+0x118>
    6ad9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    6add:	48 29 da             	sub    %rbx,%rdx
    6ae0:	48 39 ea             	cmp    %rbp,%rdx
    6ae3:	72 13                	jb     6af8 <fwp_data.part.0.constprop.0+0x118>
    6ae5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6ae9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6aed:	e9 3e ff ff ff       	jmp    6a30 <fwp_data.part.0.constprop.0+0x50>
    6af2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6af8:	31 f6                	xor    %esi,%esi
    6afa:	bf 18 00 00 00       	mov    $0x18,%edi
    6aff:	e8 8c f1 ff ff       	call   5c90 <fwp_heap_alloc>
    6b04:	48 89 c3             	mov    %rax,%rbx
    6b07:	eb 88                	jmp    6a91 <fwp_data.part.0.constprop.0+0xb1>
    6b09:	e8 a2 d1 ff ff       	call   3cb0 <fwp_heap_oom>
    6b0e:	66 90                	xchg   %ax,%ax

0000000000006b10 <fwp_rc_share>:
    6b10:	48 8b 05 a1 c0 01 00 	mov    0x1c0a1(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    6b17:	48 2b 3d 72 c0 01 00 	sub    0x1c072(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    6b1e:	48 c1 e0 10          	shl    $0x10,%rax
    6b22:	48 39 c7             	cmp    %rax,%rdi
    6b25:	73 4a                	jae    6b71 <fwp_rc_share+0x61>
    6b27:	48 89 f8             	mov    %rdi,%rax
    6b2a:	48 c1 e8 10          	shr    $0x10,%rax
    6b2e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6b32:	48 8b 05 9f c0 01 00 	mov    0x1c09f(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    6b39:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6b3d:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6b41:	48 85 d2             	test   %rdx,%rdx
    6b44:	74 2b                	je     6b71 <fwp_rc_share+0x61>
    6b46:	0f b6 08             	movzbl (%rax),%ecx
    6b49:	80 f9 02             	cmp    $0x2,%cl
    6b4c:	74 2a                	je     6b78 <fwp_rc_share+0x68>
    6b4e:	80 f9 01             	cmp    $0x1,%cl
    6b51:	75 1e                	jne    6b71 <fwp_rc_share+0x61>
    6b53:	8b 48 18             	mov    0x18(%rax),%ecx
    6b56:	0f b7 ff             	movzwl %di,%edi
    6b59:	8b 40 1c             	mov    0x1c(%rax),%eax
    6b5c:	48 0f af f9          	imul   %rcx,%rdi
    6b60:	48 c1 ef 20          	shr    $0x20,%rdi
    6b64:	48 39 c7             	cmp    %rax,%rdi
    6b67:	73 08                	jae    6b71 <fwp_rc_share+0x61>
    6b69:	48 01 fa             	add    %rdi,%rdx
    6b6c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6b6f:	75 0d                	jne    6b7e <fwp_rc_share+0x6e>
    6b71:	c3                   	ret
    6b72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b78:	66 85 ff             	test   %di,%di
    6b7b:	74 ef                	je     6b6c <fwp_rc_share+0x5c>
    6b7d:	c3                   	ret
    6b7e:	50                   	push   %rax
    6b7f:	48 8d 3d a2 6d 00 00 	lea    0x6da2(%rip),%rdi        # d928 <_IO_stdin_used+0x928>
    6b86:	e8 65 d8 ff ff       	call   43f0 <fwp_trap>
    6b8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006b90 <fwp_rc_free_arr>:
    6b90:	48 8b 15 21 c0 01 00 	mov    0x1c021(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6b97:	48 89 f8             	mov    %rdi,%rax
    6b9a:	48 2b 05 ef bf 01 00 	sub    0x1bfef(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6ba1:	48 c1 e2 10          	shl    $0x10,%rdx
    6ba5:	48 39 d0             	cmp    %rdx,%rax
    6ba8:	73 5b                	jae    6c05 <fwp_rc_free_arr+0x75>
    6baa:	48 89 c2             	mov    %rax,%rdx
    6bad:	48 c1 ea 10          	shr    $0x10,%rdx
    6bb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6bb5:	48 8b 15 1c c0 01 00 	mov    0x1c01c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    6bbc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6bc0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6bc4:	48 85 c9             	test   %rcx,%rcx
    6bc7:	74 3c                	je     6c05 <fwp_rc_free_arr+0x75>
    6bc9:	0f b6 32             	movzbl (%rdx),%esi
    6bcc:	40 80 fe 02          	cmp    $0x2,%sil
    6bd0:	74 2e                	je     6c00 <fwp_rc_free_arr+0x70>
    6bd2:	40 80 fe 01          	cmp    $0x1,%sil
    6bd6:	75 2d                	jne    6c05 <fwp_rc_free_arr+0x75>
    6bd8:	8b 72 18             	mov    0x18(%rdx),%esi
    6bdb:	0f b7 c0             	movzwl %ax,%eax
    6bde:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6be1:	48 0f af c6          	imul   %rsi,%rax
    6be5:	48 c1 e8 20          	shr    $0x20,%rax
    6be9:	48 39 d0             	cmp    %rdx,%rax
    6bec:	73 17                	jae    6c05 <fwp_rc_free_arr+0x75>
    6bee:	48 01 c1             	add    %rax,%rcx
    6bf1:	80 39 01             	cmpb   $0x1,(%rcx)
    6bf4:	75 0f                	jne    6c05 <fwp_rc_free_arr+0x75>
    6bf6:	e9 95 eb ff ff       	jmp    5790 <fwp_mem_free>
    6bfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6c00:	66 85 c0             	test   %ax,%ax
    6c03:	74 ec                	je     6bf1 <fwp_rc_free_arr+0x61>
    6c05:	c3                   	ret
    6c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6c0d:	00 00 00 

0000000000006c10 <fwp_rc_dup>:
    6c10:	f3 0f 1e fa          	endbr64
    6c14:	48 8b 05 9d bf 01 00 	mov    0x1bf9d(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    6c1b:	48 2b 3d 6e bf 01 00 	sub    0x1bf6e(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    6c22:	48 c1 e0 10          	shl    $0x10,%rax
    6c26:	48 39 c7             	cmp    %rax,%rdi
    6c29:	73 56                	jae    6c81 <fwp_rc_dup+0x71>
    6c2b:	48 89 f8             	mov    %rdi,%rax
    6c2e:	48 c1 e8 10          	shr    $0x10,%rax
    6c32:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6c36:	48 8b 05 9b bf 01 00 	mov    0x1bf9b(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    6c3d:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6c41:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6c45:	48 85 c0             	test   %rax,%rax
    6c48:	74 37                	je     6c81 <fwp_rc_dup+0x71>
    6c4a:	0f b6 0a             	movzbl (%rdx),%ecx
    6c4d:	80 f9 02             	cmp    $0x2,%cl
    6c50:	74 36                	je     6c88 <fwp_rc_dup+0x78>
    6c52:	80 f9 01             	cmp    $0x1,%cl
    6c55:	75 2a                	jne    6c81 <fwp_rc_dup+0x71>
    6c57:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6c5a:	0f b7 ff             	movzwl %di,%edi
    6c5d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6c60:	48 0f af f9          	imul   %rcx,%rdi
    6c64:	48 c1 ef 20          	shr    $0x20,%rdi
    6c68:	48 39 d7             	cmp    %rdx,%rdi
    6c6b:	73 14                	jae    6c81 <fwp_rc_dup+0x71>
    6c6d:	48 01 f8             	add    %rdi,%rax
    6c70:	0f b6 10             	movzbl (%rax),%edx
    6c73:	84 d2                	test   %dl,%dl
    6c75:	74 0a                	je     6c81 <fwp_rc_dup+0x71>
    6c77:	80 fa fd             	cmp    $0xfd,%dl
    6c7a:	77 14                	ja     6c90 <fwp_rc_dup+0x80>
    6c7c:	83 c2 01             	add    $0x1,%edx
    6c7f:	88 10                	mov    %dl,(%rax)
    6c81:	c3                   	ret
    6c82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c88:	66 85 ff             	test   %di,%di
    6c8b:	74 e3                	je     6c70 <fwp_rc_dup+0x60>
    6c8d:	c3                   	ret
    6c8e:	66 90                	xchg   %ax,%ax
    6c90:	48 89 c7             	mov    %rax,%rdi
    6c93:	e9 98 e7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    6c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c9f:	00 

0000000000006ca0 <fwp_drop0>:
    6ca0:	f3 0f 1e fa          	endbr64
    6ca4:	48 8b 15 0d bf 01 00 	mov    0x1bf0d(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6cab:	48 89 f8             	mov    %rdi,%rax
    6cae:	48 2b 05 db be 01 00 	sub    0x1bedb(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6cb5:	48 c1 e2 10          	shl    $0x10,%rdx
    6cb9:	48 39 d0             	cmp    %rdx,%rax
    6cbc:	0f 83 be 00 00 00    	jae    6d80 <fwp_drop0+0xe0>
    6cc2:	48 83 ec 18          	sub    $0x18,%rsp
    6cc6:	4c 8d 05 13 ab 01 00 	lea    0x1ab13(%rip),%r8        # 217e0 <fwp_heap>
    6ccd:	48 89 c2             	mov    %rax,%rdx
    6cd0:	48 c1 ea 10          	shr    $0x10,%rdx
    6cd4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6cd8:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6cdf:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ce3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ce7:	48 85 d2             	test   %rdx,%rdx
    6cea:	74 3c                	je     6d28 <fwp_drop0+0x88>
    6cec:	0f b6 31             	movzbl (%rcx),%esi
    6cef:	40 80 fe 02          	cmp    $0x2,%sil
    6cf3:	74 3b                	je     6d30 <fwp_drop0+0x90>
    6cf5:	40 80 fe 01          	cmp    $0x1,%sil
    6cf9:	75 2d                	jne    6d28 <fwp_drop0+0x88>
    6cfb:	8b 71 18             	mov    0x18(%rcx),%esi
    6cfe:	0f b7 c0             	movzwl %ax,%eax
    6d01:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6d04:	48 0f af c6          	imul   %rsi,%rax
    6d08:	48 c1 e8 20          	shr    $0x20,%rax
    6d0c:	48 39 c8             	cmp    %rcx,%rax
    6d0f:	73 17                	jae    6d28 <fwp_drop0+0x88>
    6d11:	48 01 c2             	add    %rax,%rdx
    6d14:	0f b6 02             	movzbl (%rdx),%eax
    6d17:	84 c0                	test   %al,%al
    6d19:	74 0d                	je     6d28 <fwp_drop0+0x88>
    6d1b:	3c 01                	cmp    $0x1,%al
    6d1d:	74 21                	je     6d40 <fwp_drop0+0xa0>
    6d1f:	3c ff                	cmp    $0xff,%al
    6d21:	74 65                	je     6d88 <fwp_drop0+0xe8>
    6d23:	83 e8 01             	sub    $0x1,%eax
    6d26:	88 02                	mov    %al,(%rdx)
    6d28:	48 83 c4 18          	add    $0x18,%rsp
    6d2c:	c3                   	ret
    6d2d:	0f 1f 00             	nopl   (%rax)
    6d30:	66 85 c0             	test   %ax,%ax
    6d33:	74 df                	je     6d14 <fwp_drop0+0x74>
    6d35:	48 83 c4 18          	add    $0x18,%rsp
    6d39:	c3                   	ret
    6d3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d40:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6d44:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6d49:	e8 42 fe ff ff       	call   6b90 <fwp_rc_free_arr>
    6d4e:	4c 8d 05 8b aa 01 00 	lea    0x1aa8b(%rip),%r8        # 217e0 <fwp_heap>
    6d55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6d5a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6d61:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6d68:	48 c1 e2 10          	shl    $0x10,%rdx
    6d6c:	48 39 d0             	cmp    %rdx,%rax
    6d6f:	73 b7                	jae    6d28 <fwp_drop0+0x88>
    6d71:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6d76:	e9 52 ff ff ff       	jmp    6ccd <fwp_drop0+0x2d>
    6d7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6d80:	c3                   	ret
    6d81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6d88:	48 89 d0             	mov    %rdx,%rax
    6d8b:	48 c1 e8 11          	shr    $0x11,%rax
    6d8f:	48 31 d0             	xor    %rdx,%rax
    6d92:	48 89 c1             	mov    %rax,%rcx
    6d95:	48 c1 e9 09          	shr    $0x9,%rcx
    6d99:	48 31 c8             	xor    %rcx,%rax
    6d9c:	0f b6 c8             	movzbl %al,%ecx
    6d9f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6da6:	00 
    6da7:	48 85 c0             	test   %rax,%rax
    6daa:	75 1d                	jne    6dc9 <fwp_drop0+0x129>
    6dac:	eb 56                	jmp    6e04 <fwp_drop0+0x164>
    6dae:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6dbc:	00 00 00 00 
    6dc0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6dc4:	48 85 c0             	test   %rax,%rax
    6dc7:	74 3b                	je     6e04 <fwp_drop0+0x164>
    6dc9:	48 89 c1             	mov    %rax,%rcx
    6dcc:	48 39 10             	cmp    %rdx,(%rax)
    6dcf:	75 ef                	jne    6dc0 <fwp_drop0+0x120>
    6dd1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6dd5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6dd9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6ddd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6de4:	0f 85 3e ff ff ff    	jne    6d28 <fwp_drop0+0x88>
    6dea:	48 89 d7             	mov    %rdx,%rdi
    6ded:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6df2:	e8 59 e7 ff ff       	call   5550 <fwp_rc_forget_slot>
    6df7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6dfc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6dff:	e9 24 ff ff ff       	jmp    6d28 <fwp_drop0+0x88>
    6e04:	48 8d 3d 7d 6a 00 00 	lea    0x6a7d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6e0b:	e8 e0 d5 ff ff       	call   43f0 <fwp_trap>

0000000000006e10 <fwp_arg_drop12>:
    6e10:	f3 0f 1e fa          	endbr64
    6e14:	85 f6                	test   %esi,%esi
    6e16:	75 04                	jne    6e1c <fwp_arg_drop12+0xc>
    6e18:	85 d2                	test   %edx,%edx
    6e1a:	75 04                	jne    6e20 <fwp_arg_drop12+0x10>
    6e1c:	c3                   	ret
    6e1d:	0f 1f 00             	nopl   (%rax)
    6e20:	48 8b 3f             	mov    (%rdi),%rdi
    6e23:	e9 78 fe ff ff       	jmp    6ca0 <fwp_drop0>
    6e28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e2f:	00 

0000000000006e30 <fwp_drop1>:
    6e30:	f3 0f 1e fa          	endbr64
    6e34:	48 8b 15 7d bd 01 00 	mov    0x1bd7d(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6e3b:	48 89 f8             	mov    %rdi,%rax
    6e3e:	48 2b 05 4b bd 01 00 	sub    0x1bd4b(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6e45:	48 c1 e2 10          	shl    $0x10,%rdx
    6e49:	48 39 d0             	cmp    %rdx,%rax
    6e4c:	0f 83 be 00 00 00    	jae    6f10 <fwp_drop1+0xe0>
    6e52:	48 83 ec 18          	sub    $0x18,%rsp
    6e56:	4c 8d 05 83 a9 01 00 	lea    0x1a983(%rip),%r8        # 217e0 <fwp_heap>
    6e5d:	48 89 c2             	mov    %rax,%rdx
    6e60:	48 c1 ea 10          	shr    $0x10,%rdx
    6e64:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6e68:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6e6f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6e73:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6e77:	48 85 d2             	test   %rdx,%rdx
    6e7a:	74 3c                	je     6eb8 <fwp_drop1+0x88>
    6e7c:	0f b6 31             	movzbl (%rcx),%esi
    6e7f:	40 80 fe 02          	cmp    $0x2,%sil
    6e83:	74 3b                	je     6ec0 <fwp_drop1+0x90>
    6e85:	40 80 fe 01          	cmp    $0x1,%sil
    6e89:	75 2d                	jne    6eb8 <fwp_drop1+0x88>
    6e8b:	8b 71 18             	mov    0x18(%rcx),%esi
    6e8e:	0f b7 c0             	movzwl %ax,%eax
    6e91:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6e94:	48 0f af c6          	imul   %rsi,%rax
    6e98:	48 c1 e8 20          	shr    $0x20,%rax
    6e9c:	48 39 c8             	cmp    %rcx,%rax
    6e9f:	73 17                	jae    6eb8 <fwp_drop1+0x88>
    6ea1:	48 01 c2             	add    %rax,%rdx
    6ea4:	0f b6 02             	movzbl (%rdx),%eax
    6ea7:	84 c0                	test   %al,%al
    6ea9:	74 0d                	je     6eb8 <fwp_drop1+0x88>
    6eab:	3c 01                	cmp    $0x1,%al
    6ead:	74 21                	je     6ed0 <fwp_drop1+0xa0>
    6eaf:	3c ff                	cmp    $0xff,%al
    6eb1:	74 65                	je     6f18 <fwp_drop1+0xe8>
    6eb3:	83 e8 01             	sub    $0x1,%eax
    6eb6:	88 02                	mov    %al,(%rdx)
    6eb8:	48 83 c4 18          	add    $0x18,%rsp
    6ebc:	c3                   	ret
    6ebd:	0f 1f 00             	nopl   (%rax)
    6ec0:	66 85 c0             	test   %ax,%ax
    6ec3:	74 df                	je     6ea4 <fwp_drop1+0x74>
    6ec5:	48 83 c4 18          	add    $0x18,%rsp
    6ec9:	c3                   	ret
    6eca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6ed0:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6ed4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6ed9:	e8 b2 fc ff ff       	call   6b90 <fwp_rc_free_arr>
    6ede:	4c 8d 05 fb a8 01 00 	lea    0x1a8fb(%rip),%r8        # 217e0 <fwp_heap>
    6ee5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6eea:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6ef1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6ef8:	48 c1 e2 10          	shl    $0x10,%rdx
    6efc:	48 39 d0             	cmp    %rdx,%rax
    6eff:	73 b7                	jae    6eb8 <fwp_drop1+0x88>
    6f01:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6f06:	e9 52 ff ff ff       	jmp    6e5d <fwp_drop1+0x2d>
    6f0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6f10:	c3                   	ret
    6f11:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6f18:	48 89 d0             	mov    %rdx,%rax
    6f1b:	48 c1 e8 11          	shr    $0x11,%rax
    6f1f:	48 31 d0             	xor    %rdx,%rax
    6f22:	48 89 c1             	mov    %rax,%rcx
    6f25:	48 c1 e9 09          	shr    $0x9,%rcx
    6f29:	48 31 c8             	xor    %rcx,%rax
    6f2c:	0f b6 c8             	movzbl %al,%ecx
    6f2f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6f36:	00 
    6f37:	48 85 c0             	test   %rax,%rax
    6f3a:	75 0d                	jne    6f49 <fwp_drop1+0x119>
    6f3c:	eb 46                	jmp    6f84 <fwp_drop1+0x154>
    6f3e:	66 90                	xchg   %ax,%ax
    6f40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6f44:	48 85 c0             	test   %rax,%rax
    6f47:	74 3b                	je     6f84 <fwp_drop1+0x154>
    6f49:	48 89 c1             	mov    %rax,%rcx
    6f4c:	48 39 10             	cmp    %rdx,(%rax)
    6f4f:	75 ef                	jne    6f40 <fwp_drop1+0x110>
    6f51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6f55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6f59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6f5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6f64:	0f 85 4e ff ff ff    	jne    6eb8 <fwp_drop1+0x88>
    6f6a:	48 89 d7             	mov    %rdx,%rdi
    6f6d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6f72:	e8 d9 e5 ff ff       	call   5550 <fwp_rc_forget_slot>
    6f77:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6f7c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6f7f:	e9 34 ff ff ff       	jmp    6eb8 <fwp_drop1+0x88>
    6f84:	48 8d 3d fd 68 00 00 	lea    0x68fd(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    6f8b:	e8 60 d4 ff ff       	call   43f0 <fwp_trap>

0000000000006f90 <fwp_closure_drop>:
    6f90:	48 8b 15 21 bc 01 00 	mov    0x1bc21(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    6f97:	48 89 f8             	mov    %rdi,%rax
    6f9a:	48 2b 05 ef bb 01 00 	sub    0x1bbef(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    6fa1:	48 c1 e2 10          	shl    $0x10,%rdx
    6fa5:	48 39 d0             	cmp    %rdx,%rax
    6fa8:	73 6b                	jae    7015 <fwp_closure_drop+0x85>
    6faa:	48 89 c2             	mov    %rax,%rdx
    6fad:	48 c1 ea 10          	shr    $0x10,%rdx
    6fb1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fb5:	48 8b 15 1c bc 01 00 	mov    0x1bc1c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    6fbc:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6fc0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6fc4:	48 85 d2             	test   %rdx,%rdx
    6fc7:	74 4c                	je     7015 <fwp_closure_drop+0x85>
    6fc9:	0f b6 31             	movzbl (%rcx),%esi
    6fcc:	40 80 fe 02          	cmp    $0x2,%sil
    6fd0:	74 3e                	je     7010 <fwp_closure_drop+0x80>
    6fd2:	40 80 fe 01          	cmp    $0x1,%sil
    6fd6:	75 3d                	jne    7015 <fwp_closure_drop+0x85>
    6fd8:	8b 71 18             	mov    0x18(%rcx),%esi
    6fdb:	0f b7 c0             	movzwl %ax,%eax
    6fde:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6fe1:	48 0f af c6          	imul   %rsi,%rax
    6fe5:	48 c1 e8 20          	shr    $0x20,%rax
    6fe9:	48 39 c8             	cmp    %rcx,%rax
    6fec:	73 27                	jae    7015 <fwp_closure_drop+0x85>
    6fee:	48 01 c2             	add    %rax,%rdx
    6ff1:	0f b6 02             	movzbl (%rdx),%eax
    6ff4:	84 c0                	test   %al,%al
    6ff6:	74 1d                	je     7015 <fwp_closure_drop+0x85>
    6ff8:	3c 01                	cmp    $0x1,%al
    6ffa:	74 24                	je     7020 <fwp_closure_drop+0x90>
    6ffc:	3c ff                	cmp    $0xff,%al
    6ffe:	74 48                	je     7048 <fwp_closure_drop+0xb8>
    7000:	83 e8 01             	sub    $0x1,%eax
    7003:	88 02                	mov    %al,(%rdx)
    7005:	c3                   	ret
    7006:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    700d:	00 00 00 
    7010:	66 85 c0             	test   %ax,%ax
    7013:	74 dc                	je     6ff1 <fwp_closure_drop+0x61>
    7015:	c3                   	ret
    7016:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    701d:	00 00 00 
    7020:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7027:	ff ff 
    7029:	48 85 c0             	test   %rax,%rax
    702c:	74 12                	je     7040 <fwp_closure_drop+0xb0>
    702e:	48 89 fe             	mov    %rdi,%rsi
    7031:	48 89 c7             	mov    %rax,%rdi
    7034:	e9 17 d4 ff ff       	jmp    4450 <fwp_closure_drop_push>
    7039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7040:	e9 bb d5 ff ff       	jmp    4600 <fwp_closure_drop.part.0>
    7045:	0f 1f 00             	nopl   (%rax)
    7048:	48 89 d0             	mov    %rdx,%rax
    704b:	48 8d 35 8e a7 01 00 	lea    0x1a78e(%rip),%rsi        # 217e0 <fwp_heap>
    7052:	48 83 ec 18          	sub    $0x18,%rsp
    7056:	48 c1 e8 11          	shr    $0x11,%rax
    705a:	48 31 d0             	xor    %rdx,%rax
    705d:	48 89 c1             	mov    %rax,%rcx
    7060:	48 c1 e9 09          	shr    $0x9,%rcx
    7064:	48 31 c8             	xor    %rcx,%rax
    7067:	0f b6 c8             	movzbl %al,%ecx
    706a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7071:	00 
    7072:	48 85 c0             	test   %rax,%rax
    7075:	75 12                	jne    7089 <fwp_closure_drop+0xf9>
    7077:	eb 49                	jmp    70c2 <fwp_closure_drop+0x132>
    7079:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7080:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7084:	48 85 c0             	test   %rax,%rax
    7087:	74 39                	je     70c2 <fwp_closure_drop+0x132>
    7089:	48 89 c1             	mov    %rax,%rcx
    708c:	48 39 10             	cmp    %rdx,(%rax)
    708f:	75 ef                	jne    7080 <fwp_closure_drop+0xf0>
    7091:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7095:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7099:	48 89 48 08          	mov    %rcx,0x8(%rax)
    709d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    70a4:	74 05                	je     70ab <fwp_closure_drop+0x11b>
    70a6:	48 83 c4 18          	add    $0x18,%rsp
    70aa:	c3                   	ret
    70ab:	48 89 d7             	mov    %rdx,%rdi
    70ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    70b3:	e8 98 e4 ff ff       	call   5550 <fwp_rc_forget_slot>
    70b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    70bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    70c0:	eb e4                	jmp    70a6 <fwp_closure_drop+0x116>
    70c2:	48 8d 3d bf 67 00 00 	lea    0x67bf(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    70c9:	e8 22 d3 ff ff       	call   43f0 <fwp_trap>
    70ce:	66 90                	xchg   %ax,%ax

00000000000070d0 <fwp_owned_tape_release>:
    70d0:	48 85 ff             	test   %rdi,%rdi
    70d3:	0f 84 f7 00 00 00    	je     71d0 <fwp_owned_tape_release+0x100>
    70d9:	41 54                	push   %r12
    70db:	55                   	push   %rbp
    70dc:	53                   	push   %rbx
    70dd:	48 8b 07             	mov    (%rdi),%rax
    70e0:	48 85 c0             	test   %rax,%rax
    70e3:	74 08                	je     70ed <fwp_owned_tape_release+0x1d>
    70e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    70e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    70ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    70f1:	48 85 d2             	test   %rdx,%rdx
    70f4:	74 03                	je     70f9 <fwp_owned_tape_release+0x29>
    70f6:	48 89 02             	mov    %rax,(%rdx)
    70f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    70fd:	48 89 fb             	mov    %rdi,%rbx
    7100:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7104:	48 85 c0             	test   %rax,%rax
    7107:	0f 84 89 00 00 00    	je     7196 <fwp_owned_tape_release+0xc6>
    710d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7111:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7115:	7e 47                	jle    715e <fwp_owned_tape_release+0x8e>
    7117:	31 ed                	xor    %ebp,%ebp
    7119:	eb 0d                	jmp    7128 <fwp_owned_tape_release+0x58>
    711b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7120:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7124:	48 8b 40 68          	mov    0x68(%rax),%rax
    7128:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    712c:	49 89 ec             	mov    %rbp,%r12
    712f:	48 83 c5 01          	add    $0x1,%rbp
    7133:	49 c1 e4 04          	shl    $0x4,%r12
    7137:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    713b:	ff d0                	call   *%rax
    713d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7141:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7146:	48 8b 43 10          	mov    0x10(%rbx),%rax
    714a:	ff 50 68             	call   *0x68(%rax)
    714d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7151:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7155:	48 39 e8             	cmp    %rbp,%rax
    7158:	7f c6                	jg     7120 <fwp_owned_tape_release+0x50>
    715a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    715e:	31 ed                	xor    %ebp,%ebp
    7160:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7165:	7e 28                	jle    718f <fwp_owned_tape_release+0xbf>
    7167:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    716e:	00 00 
    7170:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7174:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7178:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    717c:	74 07                	je     7185 <fwp_owned_tape_release+0xb5>
    717e:	ff 52 68             	call   *0x68(%rdx)
    7181:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7185:	48 83 c5 01          	add    $0x1,%rbp
    7189:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    718d:	7f e1                	jg     7170 <fwp_owned_tape_release+0xa0>
    718f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7193:	ff 52 68             	call   *0x68(%rdx)
    7196:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    719a:	e8 f1 fd ff ff       	call   6f90 <fwp_closure_drop>
    719f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    71a3:	e8 e8 fd ff ff       	call   6f90 <fwp_closure_drop>
    71a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    71ac:	e8 df fd ff ff       	call   6f90 <fwp_closure_drop>
    71b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    71b5:	e8 d6 e5 ff ff       	call   5790 <fwp_mem_free>
    71ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    71be:	e8 cd e5 ff ff       	call   5790 <fwp_mem_free>
    71c3:	48 89 df             	mov    %rbx,%rdi
    71c6:	5b                   	pop    %rbx
    71c7:	5d                   	pop    %rbp
    71c8:	41 5c                	pop    %r12
    71ca:	e9 c1 e5 ff ff       	jmp    5790 <fwp_mem_free>
    71cf:	90                   	nop
    71d0:	c3                   	ret
    71d1:	0f 1f 40 00          	nopl   0x0(%rax)
    71d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    71dc:	00 00 00 00 

00000000000071e0 <fwp_tape_finish>:
    71e0:	f3 0f 1e fa          	endbr64
    71e4:	41 56                	push   %r14
    71e6:	48 8d 3d d3 9e 01 00 	lea    0x19ed3(%rip),%rdi        # 210c0 <fwp_tape_workspace>
    71ed:	41 55                	push   %r13
    71ef:	41 54                	push   %r12
    71f1:	55                   	push   %rbp
    71f2:	53                   	push   %rbx
    71f3:	e8 18 cf ff ff       	call   4110 <fwp_tape_buffers_dispose>
    71f8:	48 83 3d 08 9f 01 00 	cmpq   $0x0,0x19f08(%rip)        # 21108 <fwp_ntapes>
    71ff:	00 
    7200:	48 c7 05 9d 9e 01 00 	movq   $0x0,0x19e9d(%rip)        # 210a8 <fwp_tape_cached_bytes>
    7207:	00 00 00 00 
    720b:	7e 68                	jle    7275 <fwp_tape_finish+0x95>
    720d:	45 31 e4             	xor    %r12d,%r12d
    7210:	31 ed                	xor    %ebp,%ebp
    7212:	0f 1f 00             	nopl   (%rax)
    7215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    721c:	00 00 00 00 
    7220:	48 8b 1d e9 9e 01 00 	mov    0x19ee9(%rip),%rbx        # 21110 <fwp_tapes>
    7227:	48 83 c5 01          	add    $0x1,%rbp
    722b:	4c 01 e3             	add    %r12,%rbx
    722e:	49 83 c4 68          	add    $0x68,%r12
    7232:	48 89 df             	mov    %rbx,%rdi
    7235:	e8 c6 c9 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    723a:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    723e:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7242:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7246:	e8 75 c1 ff ff       	call   33c0 <free@plt>
    724b:	4c 89 f7             	mov    %r14,%rdi
    724e:	e8 6d c1 ff ff       	call   33c0 <free@plt>
    7253:	4c 89 ef             	mov    %r13,%rdi
    7256:	e8 65 c1 ff ff       	call   33c0 <free@plt>
    725b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    725f:	e8 6c fe ff ff       	call   70d0 <fwp_owned_tape_release>
    7264:	48 39 2d 9d 9e 01 00 	cmp    %rbp,0x19e9d(%rip)        # 21108 <fwp_ntapes>
    726b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7272:	00 
    7273:	7f ab                	jg     7220 <fwp_tape_finish+0x40>
    7275:	48 8b 3d 94 9e 01 00 	mov    0x19e94(%rip),%rdi        # 21110 <fwp_tapes>
    727c:	e8 3f c1 ff ff       	call   33c0 <free@plt>
    7281:	5b                   	pop    %rbx
    7282:	5d                   	pop    %rbp
    7283:	48 c7 05 82 9e 01 00 	movq   $0x0,0x19e82(%rip)        # 21110 <fwp_tapes>
    728a:	00 00 00 00 
    728e:	48 c7 05 67 9e 01 00 	movq   $0x0,0x19e67(%rip)        # 21100 <fwp_tapes_cap>
    7295:	00 00 00 00 
    7299:	41 5c                	pop    %r12
    729b:	48 c7 05 62 9e 01 00 	movq   $0x0,0x19e62(%rip)        # 21108 <fwp_ntapes>
    72a2:	00 00 00 00 
    72a6:	41 5d                	pop    %r13
    72a8:	48 c7 05 45 9e 01 00 	movq   $0x0,0x19e45(%rip)        # 210f8 <fwp_tape_next_slot>
    72af:	00 00 00 00 
    72b3:	41 5e                	pop    %r14
    72b5:	c3                   	ret
    72b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72bd:	00 00 00 

00000000000072c0 <fwp_tape_scope_release>:
    72c0:	f3 0f 1e fa          	endbr64
    72c4:	41 55                	push   %r13
    72c6:	41 54                	push   %r12
    72c8:	55                   	push   %rbp
    72c9:	53                   	push   %rbx
    72ca:	48 83 ec 58          	sub    $0x58,%rsp
    72ce:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    72d5:	00 00 
    72d7:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    72dc:	48 63 07             	movslq (%rdi),%rax
    72df:	85 c0                	test   %eax,%eax
    72e1:	0f 88 05 01 00 00    	js     73ec <fwp_tape_scope_release+0x12c>
    72e7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    72ee:	ec c4 4e 
    72f1:	48 89 fb             	mov    %rdi,%rbx
    72f4:	eb 3c                	jmp    7332 <fwp_tape_scope_release+0x72>
    72f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    72fd:	00 00 00 
    7300:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    7305:	0f 29 04 24          	movaps %xmm0,(%rsp)
    7309:	e8 b2 c0 ff ff       	call   33c0 <free@plt>
    730e:	48 8b 3c 24          	mov    (%rsp),%rdi
    7312:	e8 a9 c0 ff ff       	call   33c0 <free@plt>
    7317:	4c 89 ef             	mov    %r13,%rdi
    731a:	e8 a1 c0 ff ff       	call   33c0 <free@plt>
    731f:	4c 89 e7             	mov    %r12,%rdi
    7322:	e8 a9 fd ff ff       	call   70d0 <fwp_owned_tape_release>
    7327:	48 63 03             	movslq (%rbx),%rax
    732a:	85 c0                	test   %eax,%eax
    732c:	0f 88 ba 00 00 00    	js     73ec <fwp_tape_scope_release+0x12c>
    7332:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    7336:	48 8b 35 d3 9d 01 00 	mov    0x19dd3(%rip),%rsi        # 21110 <fwp_tapes>
    733d:	4c 01 c6             	add    %r8,%rsi
    7340:	48 89 f7             	mov    %rsi,%rdi
    7343:	e8 b8 c8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7348:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    734d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7352:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7359:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    735d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7361:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7368:	00 
    7369:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    736e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7372:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7377:	66 0f ef d2          	pxor   %xmm2,%xmm2
    737b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7380:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7387:	00 
    7388:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    738f:	00 
    7390:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7397:	00 
    7398:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    739d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    73a2:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    73a6:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    73aa:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    73ae:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    73b4:	77 18                	ja     73ce <fwp_tape_scope_release+0x10e>
    73b6:	49 c1 f8 03          	sar    $0x3,%r8
    73ba:	4c 0f af c5          	imul   %rbp,%r8
    73be:	4c 3b 05 33 9d 01 00 	cmp    0x19d33(%rip),%r8        # 210f8 <fwp_tape_next_slot>
    73c5:	7d 07                	jge    73ce <fwp_tape_scope_release+0x10e>
    73c7:	4c 89 05 2a 9d 01 00 	mov    %r8,0x19d2a(%rip)        # 210f8 <fwp_tape_next_slot>
    73ce:	4d 85 e4             	test   %r12,%r12
    73d1:	0f 85 29 ff ff ff    	jne    7300 <fwp_tape_scope_release+0x40>
    73d7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    73dc:	e8 8f dc ff ff       	call   5070 <fwp_tape_buffers_release>
    73e1:	48 63 03             	movslq (%rbx),%rax
    73e4:	85 c0                	test   %eax,%eax
    73e6:	0f 89 46 ff ff ff    	jns    7332 <fwp_tape_scope_release+0x72>
    73ec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    73f1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    73f8:	00 00 
    73fa:	75 0b                	jne    7407 <fwp_tape_scope_release+0x147>
    73fc:	48 83 c4 58          	add    $0x58,%rsp
    7400:	5b                   	pop    %rbx
    7401:	5d                   	pop    %rbp
    7402:	41 5c                	pop    %r12
    7404:	41 5d                	pop    %r13
    7406:	c3                   	ret
    7407:	e8 54 c0 ff ff       	call   3460 <__stack_chk_fail@plt>
    740c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000007410 <fwp_task_dispose>:
    7410:	53                   	push   %rbx
    7411:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7415:	0f 84 2b c3 ff ff    	je     3746 <fwp_task_dispose.cold>
    741b:	48 89 fb             	mov    %rdi,%rbx
    741e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7423:	0f 85 1d c3 ff ff    	jne    3746 <fwp_task_dispose.cold>
    7429:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    742d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7434:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    743b:	00 
    743c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7440:	48 85 ff             	test   %rdi,%rdi
    7443:	74 07                	je     744c <fwp_task_dispose+0x3c>
    7445:	48 85 c0             	test   %rax,%rax
    7448:	74 02                	je     744c <fwp_task_dispose+0x3c>
    744a:	ff d0                	call   *%rax
    744c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7453:	e8 38 e3 ff ff       	call   5790 <fwp_mem_free>
    7458:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    745f:	00 00 00 00 
    7463:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7467:	74 6f                	je     74d8 <fwp_task_dispose+0xc8>
    7469:	48 8b 15 48 b7 01 00 	mov    0x1b748(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7470:	48 89 d8             	mov    %rbx,%rax
    7473:	48 2b 05 16 b7 01 00 	sub    0x1b716(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    747a:	48 c1 e2 10          	shl    $0x10,%rdx
    747e:	48 39 d0             	cmp    %rdx,%rax
    7481:	73 4c                	jae    74cf <fwp_task_dispose+0xbf>
    7483:	48 89 c2             	mov    %rax,%rdx
    7486:	48 c1 ea 10          	shr    $0x10,%rdx
    748a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    748e:	48 8b 15 43 b7 01 00 	mov    0x1b743(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7495:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7499:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    749d:	48 85 c9             	test   %rcx,%rcx
    74a0:	74 2d                	je     74cf <fwp_task_dispose+0xbf>
    74a2:	0f b6 32             	movzbl (%rdx),%esi
    74a5:	40 80 fe 02          	cmp    $0x2,%sil
    74a9:	74 3d                	je     74e8 <fwp_task_dispose+0xd8>
    74ab:	40 80 fe 01          	cmp    $0x1,%sil
    74af:	75 1e                	jne    74cf <fwp_task_dispose+0xbf>
    74b1:	8b 72 18             	mov    0x18(%rdx),%esi
    74b4:	0f b7 c0             	movzwl %ax,%eax
    74b7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    74ba:	48 0f af c6          	imul   %rsi,%rax
    74be:	48 c1 e8 20          	shr    $0x20,%rax
    74c2:	48 39 d0             	cmp    %rdx,%rax
    74c5:	73 08                	jae    74cf <fwp_task_dispose+0xbf>
    74c7:	48 01 c1             	add    %rax,%rcx
    74ca:	80 39 01             	cmpb   $0x1,(%rcx)
    74cd:	74 09                	je     74d8 <fwp_task_dispose+0xc8>
    74cf:	5b                   	pop    %rbx
    74d0:	c3                   	ret
    74d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74d8:	48 89 df             	mov    %rbx,%rdi
    74db:	5b                   	pop    %rbx
    74dc:	e9 af e2 ff ff       	jmp    5790 <fwp_mem_free>
    74e1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    74e8:	66 85 c0             	test   %ax,%ax
    74eb:	74 dd                	je     74ca <fwp_task_dispose+0xba>
    74ed:	5b                   	pop    %rbx
    74ee:	c3                   	ret
    74ef:	90                   	nop

00000000000074f0 <fwp_free_zombie>:
    74f0:	48 8b 15 b9 a2 01 00 	mov    0x1a2b9(%rip),%rdx        # 217b0 <fwp_zombie>
    74f7:	48 85 d2             	test   %rdx,%rdx
    74fa:	0f 84 98 00 00 00    	je     7598 <fwp_free_zombie+0xa8>
    7500:	48 3b 15 b9 a2 01 00 	cmp    0x1a2b9(%rip),%rdx        # 217c0 <fwp_cur>
    7507:	0f 84 8b 00 00 00    	je     7598 <fwp_free_zombie+0xa8>
    750d:	48 83 ec 18          	sub    $0x18,%rsp
    7511:	48 63 05 6c 9c 01 00 	movslq 0x19c6c(%rip),%rax        # 21184 <fwp_stack_pool_n>
    7518:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    751c:	83 f8 3f             	cmp    $0x3f,%eax
    751f:	7f 7f                	jg     75a0 <fwp_free_zombie+0xb0>
    7521:	8d 48 01             	lea    0x1(%rax),%ecx
    7524:	89 0d 5a 9c 01 00    	mov    %ecx,0x19c5a(%rip)        # 21184 <fwp_stack_pool_n>
    752a:	48 8d 0d 6f 9c 01 00 	lea    0x19c6f(%rip),%rcx        # 211a0 <fwp_stack_pool>
    7531:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7535:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    753c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7540:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7547:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    754b:	48 85 c9             	test   %rcx,%rcx
    754e:	0f 84 fc 00 00 00    	je     7650 <fwp_free_zombie+0x160>
    7554:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    755b:	48 85 c0             	test   %rax,%rax
    755e:	74 07                	je     7567 <fwp_free_zombie+0x77>
    7560:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7567:	8b 42 5c             	mov    0x5c(%rdx),%eax
    756a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    756e:	48 c7 05 37 a2 01 00 	movq   $0x0,0x1a237(%rip)        # 217b0 <fwp_zombie>
    7575:	00 00 00 00 
    7579:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7580:	85 c0                	test   %eax,%eax
    7582:	74 34                	je     75b8 <fwp_free_zombie+0xc8>
    7584:	83 f8 01             	cmp    $0x1,%eax
    7587:	0f 84 b3 00 00 00    	je     7640 <fwp_free_zombie+0x150>
    758d:	48 83 c4 18          	add    $0x18,%rsp
    7591:	c3                   	ret
    7592:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7598:	c3                   	ret
    7599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    75a0:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    75a4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    75a9:	e8 32 c0 ff ff       	call   35e0 <munmap@plt>
    75ae:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    75b3:	eb 80                	jmp    7535 <fwp_free_zombie+0x45>
    75b5:	0f 1f 00             	nopl   (%rax)
    75b8:	48 8b 0d f9 b5 01 00 	mov    0x1b5f9(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    75bf:	48 89 d0             	mov    %rdx,%rax
    75c2:	48 2b 05 c7 b5 01 00 	sub    0x1b5c7(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    75c9:	48 c1 e1 10          	shl    $0x10,%rcx
    75cd:	48 39 c8             	cmp    %rcx,%rax
    75d0:	73 bb                	jae    758d <fwp_free_zombie+0x9d>
    75d2:	48 89 c1             	mov    %rax,%rcx
    75d5:	48 c1 e9 10          	shr    $0x10,%rcx
    75d9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    75dd:	48 8b 0d f4 b5 01 00 	mov    0x1b5f4(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    75e4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    75e8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    75ec:	48 85 c9             	test   %rcx,%rcx
    75ef:	74 9c                	je     758d <fwp_free_zombie+0x9d>
    75f1:	0f b6 3e             	movzbl (%rsi),%edi
    75f4:	40 80 ff 02          	cmp    $0x2,%dil
    75f8:	74 66                	je     7660 <fwp_free_zombie+0x170>
    75fa:	40 80 ff 01          	cmp    $0x1,%dil
    75fe:	75 8d                	jne    758d <fwp_free_zombie+0x9d>
    7600:	8b 7e 18             	mov    0x18(%rsi),%edi
    7603:	0f b7 c0             	movzwl %ax,%eax
    7606:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7609:	48 0f af c7          	imul   %rdi,%rax
    760d:	48 c1 e8 20          	shr    $0x20,%rax
    7611:	48 39 f0             	cmp    %rsi,%rax
    7614:	0f 83 73 ff ff ff    	jae    758d <fwp_free_zombie+0x9d>
    761a:	48 01 c1             	add    %rax,%rcx
    761d:	0f b6 01             	movzbl (%rcx),%eax
    7620:	84 c0                	test   %al,%al
    7622:	0f 84 65 ff ff ff    	je     758d <fwp_free_zombie+0x9d>
    7628:	3c 01                	cmp    $0x1,%al
    762a:	74 14                	je     7640 <fwp_free_zombie+0x150>
    762c:	3c ff                	cmp    $0xff,%al
    762e:	74 3b                	je     766b <fwp_free_zombie+0x17b>
    7630:	83 e8 01             	sub    $0x1,%eax
    7633:	88 01                	mov    %al,(%rcx)
    7635:	e9 53 ff ff ff       	jmp    758d <fwp_free_zombie+0x9d>
    763a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7640:	48 89 d7             	mov    %rdx,%rdi
    7643:	48 83 c4 18          	add    $0x18,%rsp
    7647:	e9 c4 fd ff ff       	jmp    7410 <fwp_task_dispose>
    764c:	0f 1f 40 00          	nopl   0x0(%rax)
    7650:	48 89 05 31 a1 01 00 	mov    %rax,0x1a131(%rip)        # 21788 <fwp_tasks_active>
    7657:	e9 ff fe ff ff       	jmp    755b <fwp_free_zombie+0x6b>
    765c:	0f 1f 40 00          	nopl   0x0(%rax)
    7660:	66 85 c0             	test   %ax,%ax
    7663:	0f 85 24 ff ff ff    	jne    758d <fwp_free_zombie+0x9d>
    7669:	eb b2                	jmp    761d <fwp_free_zombie+0x12d>
    766b:	48 89 ca             	mov    %rcx,%rdx
    766e:	48 8d 35 6b a1 01 00 	lea    0x1a16b(%rip),%rsi        # 217e0 <fwp_heap>
    7675:	48 c1 ea 11          	shr    $0x11,%rdx
    7679:	48 31 ca             	xor    %rcx,%rdx
    767c:	48 89 d0             	mov    %rdx,%rax
    767f:	48 c1 e8 09          	shr    $0x9,%rax
    7683:	48 31 c2             	xor    %rax,%rdx
    7686:	0f b6 d2             	movzbl %dl,%edx
    7689:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7690:	00 
    7691:	48 85 c0             	test   %rax,%rax
    7694:	75 13                	jne    76a9 <fwp_free_zombie+0x1b9>
    7696:	eb 4c                	jmp    76e4 <fwp_free_zombie+0x1f4>
    7698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    769f:	00 
    76a0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    76a4:	48 85 c0             	test   %rax,%rax
    76a7:	74 3b                	je     76e4 <fwp_free_zombie+0x1f4>
    76a9:	48 89 c2             	mov    %rax,%rdx
    76ac:	48 39 08             	cmp    %rcx,(%rax)
    76af:	75 ef                	jne    76a0 <fwp_free_zombie+0x1b0>
    76b1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    76b5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    76b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    76bd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    76c4:	0f 85 c3 fe ff ff    	jne    758d <fwp_free_zombie+0x9d>
    76ca:	48 89 cf             	mov    %rcx,%rdi
    76cd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    76d2:	e8 79 de ff ff       	call   5550 <fwp_rc_forget_slot>
    76d7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    76dc:	c6 01 fe             	movb   $0xfe,(%rcx)
    76df:	e9 a9 fe ff ff       	jmp    758d <fwp_free_zombie+0x9d>
    76e4:	48 8d 3d 9d 61 00 00 	lea    0x619d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    76eb:	e8 00 cd ff ff       	call   43f0 <fwp_trap>

00000000000076f0 <fwp_block>:
    76f0:	48 83 ec 08          	sub    $0x8,%rsp
    76f4:	48 8b 05 ad a0 01 00 	mov    0x1a0ad(%rip),%rax        # 217a8 <fwp_ready_head>
    76fb:	48 85 c0             	test   %rax,%rax
    76fe:	0f 84 1c 01 00 00    	je     7820 <fwp_block+0x130>
    7704:	90                   	nop
    7705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    770c:	00 00 00 00 
    7710:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7717:	48 89 15 8a a0 01 00 	mov    %rdx,0x1a08a(%rip)        # 217a8 <fwp_ready_head>
    771e:	48 85 d2             	test   %rdx,%rdx
    7721:	0f 84 19 01 00 00    	je     7840 <fwp_block+0x150>
    7727:	48 8b 15 92 a0 01 00 	mov    0x1a092(%rip),%rdx        # 217c0 <fwp_cur>
    772e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7732:	48 39 c2             	cmp    %rax,%rdx
    7735:	0f 84 d5 00 00 00    	je     7810 <fwp_block+0x120>
    773b:	48 8b 0d 06 bd 01 00 	mov    0x1bd06(%rip),%rcx        # 23448 <fwp_state_owners>
    7742:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7746:	48 89 05 73 a0 01 00 	mov    %rax,0x1a073(%rip)        # 217c0 <fwp_cur>
    774d:	f3 0f 7e 05 1b bd 01 	movq   0x1bd1b(%rip),%xmm0        # 23470 <fwp_foreign_callbacks>
    7754:	00 
    7755:	0f 16 05 04 bd 01 00 	movhps 0x1bd04(%rip),%xmm0        # 23460 <fwp_state>
    775c:	f3 0f 7e 0d 04 bd 01 	movq   0x1bd04(%rip),%xmm1        # 23468 <fwp_handlers>
    7763:	00 
    7764:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    776b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7772:	0f 16 0d ff bc 01 00 	movhps 0x1bcff(%rip),%xmm1        # 23478 <fwp_cleanups>
    7779:	f3 0f 7e 05 d7 bc 01 	movq   0x1bcd7(%rip),%xmm0        # 23458 <fwp_state_len>
    7780:	00 
    7781:	0f 16 05 c8 bc 01 00 	movhps 0x1bcc8(%rip),%xmm0        # 23450 <fwp_state_cap>
    7788:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    778f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7796:	48 8b 70 08          	mov    0x8(%rax),%rsi
    779a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    77a1:	48 89 0d c0 bc 01 00 	mov    %rcx,0x1bcc0(%rip)        # 23468 <fwp_handlers>
    77a8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    77af:	48 89 0d c2 bc 01 00 	mov    %rcx,0x1bcc2(%rip)        # 23478 <fwp_cleanups>
    77b6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    77bd:	48 89 0d ac bc 01 00 	mov    %rcx,0x1bcac(%rip)        # 23470 <fwp_foreign_callbacks>
    77c4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    77cb:	48 89 0d 8e bc 01 00 	mov    %rcx,0x1bc8e(%rip)        # 23460 <fwp_state>
    77d2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    77d9:	48 89 0d 78 bc 01 00 	mov    %rcx,0x1bc78(%rip)        # 23458 <fwp_state_len>
    77e0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    77e7:	48 89 0d 62 bc 01 00 	mov    %rcx,0x1bc62(%rip)        # 23450 <fwp_state_cap>
    77ee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    77f5:	48 89 0d 4c bc 01 00 	mov    %rcx,0x1bc4c(%rip)        # 23448 <fwp_state_owners>
    77fc:	e8 8f bc ff ff       	call   3490 <swapcontext@plt>
    7801:	f3 0f 1e fa          	endbr64
    7805:	e8 e6 fc ff ff       	call   74f0 <fwp_free_zombie>
    780a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7810:	8b 05 6a 99 01 00    	mov    0x1996a(%rip),%eax        # 21180 <fwp_slice>
    7816:	85 c0                	test   %eax,%eax
    7818:	74 36                	je     7850 <fwp_block+0x160>
    781a:	48 83 c4 08          	add    $0x8,%rsp
    781e:	c3                   	ret
    781f:	90                   	nop
    7820:	e8 7b d9 ff ff       	call   51a0 <fwp_poll_events>
    7825:	48 8b 05 7c 9f 01 00 	mov    0x19f7c(%rip),%rax        # 217a8 <fwp_ready_head>
    782c:	48 85 c0             	test   %rax,%rax
    782f:	0f 85 db fe ff ff    	jne    7710 <fwp_block+0x20>
    7835:	eb e9                	jmp    7820 <fwp_block+0x130>
    7837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    783e:	00 00 
    7840:	48 c7 05 55 9f 01 00 	movq   $0x0,0x19f55(%rip)        # 217a0 <fwp_ready_tail>
    7847:	00 00 00 00 
    784b:	e9 d7 fe ff ff       	jmp    7727 <fwp_block+0x37>
    7850:	48 8d 3d 2d 59 00 00 	lea    0x592d(%rip),%rdi        # d184 <_IO_stdin_used+0x184>
    7857:	e8 44 bb ff ff       	call   33a0 <getenv@plt>
    785c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7861:	48 85 c0             	test   %rax,%rax
    7864:	74 05                	je     786b <fwp_block+0x17b>
    7866:	80 38 00             	cmpb   $0x0,(%rax)
    7869:	75 0b                	jne    7876 <fwp_block+0x186>
    786b:	89 15 0f 99 01 00    	mov    %edx,0x1990f(%rip)        # 21180 <fwp_slice>
    7871:	48 83 c4 08          	add    $0x8,%rsp
    7875:	c3                   	ret
    7876:	ba 0a 00 00 00       	mov    $0xa,%edx
    787b:	31 f6                	xor    %esi,%esi
    787d:	48 89 c7             	mov    %rax,%rdi
    7880:	e8 cb bc ff ff       	call   3550 <strtoll@plt>
    7885:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7889:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7890:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7895:	0f 46 d0             	cmovbe %eax,%edx
    7898:	eb d1                	jmp    786b <fwp_block+0x17b>
    789a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000078a0 <fwp_owned_entry161>:
    78a0:	f3 0f 1e fa          	endbr64
    78a4:	41 56                	push   %r14
    78a6:	55                   	push   %rbp
    78a7:	53                   	push   %rbx
    78a8:	48 83 ec 10          	sub    $0x10,%rsp
    78ac:	48 8b 07             	mov    (%rdi),%rax
    78af:	48 03 47 10          	add    0x10(%rdi),%rax
    78b3:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    78b8:	0f 80 b7 01 00 00    	jo     7a75 <fwp_owned_entry161+0x1d5>
    78be:	49 89 c6             	mov    %rax,%r14
    78c1:	8b 05 bd b2 01 00    	mov    0x1b2bd(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    78c7:	48 8d 15 12 9f 01 00 	lea    0x19f12(%rip),%rdx        # 217e0 <fwp_heap>
    78ce:	85 c0                	test   %eax,%eax
    78d0:	0f 84 52 01 00 00    	je     7a28 <fwp_owned_entry161+0x188>
    78d6:	0f b6 05 a5 ae 01 00 	movzbl 0x1aea5(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    78dd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    78e4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    78e8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    78ec:	48 8b 18             	mov    (%rax),%rbx
    78ef:	48 85 db             	test   %rbx,%rbx
    78f2:	0f 84 08 01 00 00    	je     7a00 <fwp_owned_entry161+0x160>
    78f8:	48 8b 13             	mov    (%rbx),%rdx
    78fb:	48 f7 d2             	not    %rdx
    78fe:	48 89 10             	mov    %rdx,(%rax)
    7901:	48 83 fd 18          	cmp    $0x18,%rbp
    7905:	76 27                	jbe    792e <fwp_owned_entry161+0x8e>
    7907:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    790b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    790f:	31 f6                	xor    %esi,%esi
    7911:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7917:	48 c1 e8 03          	shr    $0x3,%rax
    791b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7922:	00 
    7923:	e8 98 bb ff ff       	call   34c0 <memset@plt>
    7928:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    792e:	48 89 e8             	mov    %rbp,%rax
    7931:	48 03 05 c8 b2 01 00 	add    0x1b2c8(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    7938:	0f 82 3c 01 00 00    	jb     7a7a <fwp_owned_entry161+0x1da>
    793e:	48 39 05 c3 b2 01 00 	cmp    %rax,0x1b2c3(%rip)        # 22c08 <fwp_heap+0x1428>
    7945:	48 89 05 b4 b2 01 00 	mov    %rax,0x1b2b4(%rip)        # 22c00 <fwp_heap+0x1420>
    794c:	73 07                	jae    7955 <fwp_owned_entry161+0xb5>
    794e:	48 89 05 b3 b2 01 00 	mov    %rax,0x1b2b3(%rip)        # 22c08 <fwp_heap+0x1428>
    7955:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7959:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    795e:	f2 0f 58 0d b2 b2 01 	addsd  0x1b2b2(%rip),%xmm1        # 22c18 <fwp_heap+0x1438>
    7965:	00 
    7966:	f2 0f 11 0d aa b2 01 	movsd  %xmm1,0x1b2aa(%rip)        # 22c18 <fwp_heap+0x1438>
    796d:	00 
    796e:	48 8b 05 c3 62 00 00 	mov    0x62c3(%rip),%rax        # dc38 <msg.4+0xc8>
    7975:	66 49 0f 6e d6       	movq   %r14,%xmm2
    797a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    797e:	48 89 03             	mov    %rax,(%rbx)
    7981:	48 89 d8             	mov    %rbx,%rax
    7984:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7988:	48 8b 15 29 b2 01 00 	mov    0x1b229(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    798f:	48 2b 05 fa b1 01 00 	sub    0x1b1fa(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7996:	48 c1 e2 10          	shl    $0x10,%rdx
    799a:	48 39 d0             	cmp    %rdx,%rax
    799d:	73 53                	jae    79f2 <fwp_owned_entry161+0x152>
    799f:	48 89 c2             	mov    %rax,%rdx
    79a2:	48 c1 ea 10          	shr    $0x10,%rdx
    79a6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    79aa:	48 8b 15 27 b2 01 00 	mov    0x1b227(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    79b1:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    79b5:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    79b9:	48 85 ed             	test   %rbp,%rbp
    79bc:	74 34                	je     79f2 <fwp_owned_entry161+0x152>
    79be:	0f b6 0a             	movzbl (%rdx),%ecx
    79c1:	80 f9 02             	cmp    $0x2,%cl
    79c4:	0f 84 86 00 00 00    	je     7a50 <fwp_owned_entry161+0x1b0>
    79ca:	80 f9 01             	cmp    $0x1,%cl
    79cd:	75 23                	jne    79f2 <fwp_owned_entry161+0x152>
    79cf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    79d2:	0f b7 c0             	movzwl %ax,%eax
    79d5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    79d8:	48 0f af c1          	imul   %rcx,%rax
    79dc:	48 c1 e8 20          	shr    $0x20,%rax
    79e0:	48 39 d0             	cmp    %rdx,%rax
    79e3:	73 0d                	jae    79f2 <fwp_owned_entry161+0x152>
    79e5:	48 01 c5             	add    %rax,%rbp
    79e8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    79ec:	74 7a                	je     7a68 <fwp_owned_entry161+0x1c8>
    79ee:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    79f2:	48 83 c4 10          	add    $0x10,%rsp
    79f6:	48 89 d8             	mov    %rbx,%rax
    79f9:	5b                   	pop    %rbx
    79fa:	5d                   	pop    %rbp
    79fb:	41 5e                	pop    %r14
    79fd:	c3                   	ret
    79fe:	66 90                	xchg   %ax,%ax
    7a00:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7a04:	48 85 db             	test   %rbx,%rbx
    7a07:	74 1f                	je     7a28 <fwp_owned_entry161+0x188>
    7a09:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7a0d:	48 29 da             	sub    %rbx,%rdx
    7a10:	48 39 ea             	cmp    %rbp,%rdx
    7a13:	72 13                	jb     7a28 <fwp_owned_entry161+0x188>
    7a15:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7a19:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7a1d:	e9 df fe ff ff       	jmp    7901 <fwp_owned_entry161+0x61>
    7a22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a28:	31 f6                	xor    %esi,%esi
    7a2a:	bf 18 00 00 00       	mov    $0x18,%edi
    7a2f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7a35:	e8 56 e2 ff ff       	call   5c90 <fwp_heap_alloc>
    7a3a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7a40:	48 89 c3             	mov    %rax,%rbx
    7a43:	e9 26 ff ff ff       	jmp    796e <fwp_owned_entry161+0xce>
    7a48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7a4f:	00 
    7a50:	66 85 c0             	test   %ax,%ax
    7a53:	74 93                	je     79e8 <fwp_owned_entry161+0x148>
    7a55:	48 83 c4 10          	add    $0x10,%rsp
    7a59:	48 89 d8             	mov    %rbx,%rax
    7a5c:	5b                   	pop    %rbx
    7a5d:	5d                   	pop    %rbp
    7a5e:	41 5e                	pop    %r14
    7a60:	c3                   	ret
    7a61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7a68:	48 89 ef             	mov    %rbp,%rdi
    7a6b:	e8 e0 da ff ff       	call   5550 <fwp_rc_forget_slot>
    7a70:	e9 79 ff ff ff       	jmp    79ee <fwp_owned_entry161+0x14e>
    7a75:	e8 86 bc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7a7a:	e8 31 c2 ff ff       	call   3cb0 <fwp_heap_oom>
    7a7f:	90                   	nop

0000000000007a80 <e161>:
    7a80:	f3 0f 1e fa          	endbr64
    7a84:	41 56                	push   %r14
    7a86:	55                   	push   %rbp
    7a87:	53                   	push   %rbx
    7a88:	48 83 ec 10          	sub    $0x10,%rsp
    7a8c:	48 8b 07             	mov    (%rdi),%rax
    7a8f:	48 03 47 10          	add    0x10(%rdi),%rax
    7a93:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7a98:	0f 80 bf 01 00 00    	jo     7c5d <e161+0x1dd>
    7a9e:	49 89 c6             	mov    %rax,%r14
    7aa1:	8b 05 dd b0 01 00    	mov    0x1b0dd(%rip),%eax        # 22b84 <fwp_heap+0x13a4>
    7aa7:	48 8d 15 32 9d 01 00 	lea    0x19d32(%rip),%rdx        # 217e0 <fwp_heap>
    7aae:	85 c0                	test   %eax,%eax
    7ab0:	0f 84 62 01 00 00    	je     7c18 <e161+0x198>
    7ab6:	0f b6 05 c5 ac 01 00 	movzbl 0x1acc5(%rip),%eax        # 22782 <fwp_heap+0xfa2>
    7abd:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7ac4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7ac8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    7acc:	48 8b 18             	mov    (%rax),%rbx
    7acf:	48 85 db             	test   %rbx,%rbx
    7ad2:	0f 84 18 01 00 00    	je     7bf0 <e161+0x170>
    7ad8:	48 8b 13             	mov    (%rbx),%rdx
    7adb:	48 f7 d2             	not    %rdx
    7ade:	48 89 10             	mov    %rdx,(%rax)
    7ae1:	48 83 fd 18          	cmp    $0x18,%rbp
    7ae5:	76 27                	jbe    7b0e <e161+0x8e>
    7ae7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    7aeb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    7aef:	31 f6                	xor    %esi,%esi
    7af1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7af7:	48 c1 e8 03          	shr    $0x3,%rax
    7afb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    7b02:	00 
    7b03:	e8 b8 b9 ff ff       	call   34c0 <memset@plt>
    7b08:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7b0e:	48 89 e8             	mov    %rbp,%rax
    7b11:	48 03 05 e8 b0 01 00 	add    0x1b0e8(%rip),%rax        # 22c00 <fwp_heap+0x1420>
    7b18:	0f 82 44 01 00 00    	jb     7c62 <e161+0x1e2>
    7b1e:	48 39 05 e3 b0 01 00 	cmp    %rax,0x1b0e3(%rip)        # 22c08 <fwp_heap+0x1428>
    7b25:	48 89 05 d4 b0 01 00 	mov    %rax,0x1b0d4(%rip)        # 22c00 <fwp_heap+0x1420>
    7b2c:	73 07                	jae    7b35 <e161+0xb5>
    7b2e:	48 89 05 d3 b0 01 00 	mov    %rax,0x1b0d3(%rip)        # 22c08 <fwp_heap+0x1428>
    7b35:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7b39:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    7b3e:	f2 0f 58 0d d2 b0 01 	addsd  0x1b0d2(%rip),%xmm1        # 22c18 <fwp_heap+0x1438>
    7b45:	00 
    7b46:	f2 0f 11 0d ca b0 01 	movsd  %xmm1,0x1b0ca(%rip)        # 22c18 <fwp_heap+0x1438>
    7b4d:	00 
    7b4e:	48 8b 05 e3 60 00 00 	mov    0x60e3(%rip),%rax        # dc38 <msg.4+0xc8>
    7b55:	66 49 0f 6e d6       	movq   %r14,%xmm2
    7b5a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    7b5e:	48 89 03             	mov    %rax,(%rbx)
    7b61:	48 89 d8             	mov    %rbx,%rax
    7b64:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7b68:	48 8b 15 49 b0 01 00 	mov    0x1b049(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7b6f:	48 2b 05 1a b0 01 00 	sub    0x1b01a(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7b76:	48 c1 e2 10          	shl    $0x10,%rdx
    7b7a:	48 39 d0             	cmp    %rdx,%rax
    7b7d:	73 57                	jae    7bd6 <e161+0x156>
    7b7f:	48 89 c2             	mov    %rax,%rdx
    7b82:	48 c1 ea 10          	shr    $0x10,%rdx
    7b86:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7b8a:	48 8b 15 47 b0 01 00 	mov    0x1b047(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7b91:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7b95:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7b99:	48 85 ed             	test   %rbp,%rbp
    7b9c:	74 38                	je     7bd6 <e161+0x156>
    7b9e:	0f b6 0a             	movzbl (%rdx),%ecx
    7ba1:	80 f9 02             	cmp    $0x2,%cl
    7ba4:	0f 84 96 00 00 00    	je     7c40 <e161+0x1c0>
    7baa:	80 f9 01             	cmp    $0x1,%cl
    7bad:	75 27                	jne    7bd6 <e161+0x156>
    7baf:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7bb2:	0f b7 c0             	movzwl %ax,%eax
    7bb5:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7bb8:	48 0f af c1          	imul   %rcx,%rax
    7bbc:	48 c1 e8 20          	shr    $0x20,%rax
    7bc0:	48 39 d0             	cmp    %rdx,%rax
    7bc3:	73 11                	jae    7bd6 <e161+0x156>
    7bc5:	48 01 c5             	add    %rax,%rbp
    7bc8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    7bcc:	0f 84 7e 00 00 00    	je     7c50 <e161+0x1d0>
    7bd2:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7bd6:	48 89 df             	mov    %rbx,%rdi
    7bd9:	e8 32 ef ff ff       	call   6b10 <fwp_rc_share>
    7bde:	48 83 c4 10          	add    $0x10,%rsp
    7be2:	48 89 d8             	mov    %rbx,%rax
    7be5:	5b                   	pop    %rbx
    7be6:	5d                   	pop    %rbp
    7be7:	41 5e                	pop    %r14
    7be9:	c3                   	ret
    7bea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7bf0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    7bf4:	48 85 db             	test   %rbx,%rbx
    7bf7:	74 1f                	je     7c18 <e161+0x198>
    7bf9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    7bfd:	48 29 da             	sub    %rbx,%rdx
    7c00:	48 39 ea             	cmp    %rbp,%rdx
    7c03:	72 13                	jb     7c18 <e161+0x198>
    7c05:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    7c09:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7c0d:	e9 cf fe ff ff       	jmp    7ae1 <e161+0x61>
    7c12:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c18:	31 f6                	xor    %esi,%esi
    7c1a:	bf 18 00 00 00       	mov    $0x18,%edi
    7c1f:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    7c25:	e8 66 e0 ff ff       	call   5c90 <fwp_heap_alloc>
    7c2a:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7c30:	48 89 c3             	mov    %rax,%rbx
    7c33:	e9 16 ff ff ff       	jmp    7b4e <e161+0xce>
    7c38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7c3f:	00 
    7c40:	66 85 c0             	test   %ax,%ax
    7c43:	75 91                	jne    7bd6 <e161+0x156>
    7c45:	eb 81                	jmp    7bc8 <e161+0x148>
    7c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c4e:	00 00 
    7c50:	48 89 ef             	mov    %rbp,%rdi
    7c53:	e8 f8 d8 ff ff       	call   5550 <fwp_rc_forget_slot>
    7c58:	e9 75 ff ff ff       	jmp    7bd2 <e161+0x152>
    7c5d:	e8 9e ba ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7c62:	e8 49 c0 ff ff       	call   3cb0 <fwp_heap_oom>
    7c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c6e:	00 00 

0000000000007c70 <fwp_drop4>:
    7c70:	48 8b 15 41 af 01 00 	mov    0x1af41(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7c77:	48 89 f8             	mov    %rdi,%rax
    7c7a:	48 2b 05 0f af 01 00 	sub    0x1af0f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7c81:	48 c1 e2 10          	shl    $0x10,%rdx
    7c85:	48 39 d0             	cmp    %rdx,%rax
    7c88:	0f 83 52 01 00 00    	jae    7de0 <fwp_drop4+0x170>
    7c8e:	48 83 ec 18          	sub    $0x18,%rsp
    7c92:	4c 8d 05 47 9b 01 00 	lea    0x19b47(%rip),%r8        # 217e0 <fwp_heap>
    7c99:	48 89 c2             	mov    %rax,%rdx
    7c9c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7ca3:	48 c1 ea 10          	shr    $0x10,%rdx
    7ca7:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7cab:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7caf:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7cb3:	48 85 d2             	test   %rdx,%rdx
    7cb6:	74 46                	je     7cfe <fwp_drop4+0x8e>
    7cb8:	44 0f b6 09          	movzbl (%rcx),%r9d
    7cbc:	41 80 f9 02          	cmp    $0x2,%r9b
    7cc0:	0f 84 ca 00 00 00    	je     7d90 <fwp_drop4+0x120>
    7cc6:	41 80 f9 01          	cmp    $0x1,%r9b
    7cca:	75 32                	jne    7cfe <fwp_drop4+0x8e>
    7ccc:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7cd0:	0f b7 c0             	movzwl %ax,%eax
    7cd3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7cd6:	49 0f af c1          	imul   %r9,%rax
    7cda:	48 c1 e8 20          	shr    $0x20,%rax
    7cde:	48 39 c8             	cmp    %rcx,%rax
    7ce1:	73 1b                	jae    7cfe <fwp_drop4+0x8e>
    7ce3:	48 01 c2             	add    %rax,%rdx
    7ce6:	0f b6 02             	movzbl (%rdx),%eax
    7ce9:	84 c0                	test   %al,%al
    7ceb:	74 11                	je     7cfe <fwp_drop4+0x8e>
    7ced:	3c 01                	cmp    $0x1,%al
    7cef:	74 17                	je     7d08 <fwp_drop4+0x98>
    7cf1:	3c ff                	cmp    $0xff,%al
    7cf3:	0f 84 ef 00 00 00    	je     7de8 <fwp_drop4+0x178>
    7cf9:	83 e8 01             	sub    $0x1,%eax
    7cfc:	88 02                	mov    %al,(%rdx)
    7cfe:	48 83 c4 18          	add    $0x18,%rsp
    7d02:	c3                   	ret
    7d03:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d08:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7d0c:	0f 88 8e 00 00 00    	js     7da0 <fwp_drop4+0x130>
    7d12:	48 8b 15 9f ae 01 00 	mov    0x1ae9f(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7d19:	48 89 f8             	mov    %rdi,%rax
    7d1c:	48 2b 05 6d ae 01 00 	sub    0x1ae6d(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7d23:	48 c1 e2 10          	shl    $0x10,%rdx
    7d27:	48 39 d0             	cmp    %rdx,%rax
    7d2a:	73 d2                	jae    7cfe <fwp_drop4+0x8e>
    7d2c:	48 89 c2             	mov    %rax,%rdx
    7d2f:	48 c1 ea 10          	shr    $0x10,%rdx
    7d33:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7d37:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7d3b:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7d3f:	48 85 c9             	test   %rcx,%rcx
    7d42:	74 ba                	je     7cfe <fwp_drop4+0x8e>
    7d44:	0f b6 32             	movzbl (%rdx),%esi
    7d47:	40 80 fe 02          	cmp    $0x2,%sil
    7d4b:	74 33                	je     7d80 <fwp_drop4+0x110>
    7d4d:	40 80 fe 01          	cmp    $0x1,%sil
    7d51:	75 ab                	jne    7cfe <fwp_drop4+0x8e>
    7d53:	8b 72 18             	mov    0x18(%rdx),%esi
    7d56:	0f b7 c0             	movzwl %ax,%eax
    7d59:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d5c:	48 0f af c6          	imul   %rsi,%rax
    7d60:	48 c1 e8 20          	shr    $0x20,%rax
    7d64:	48 39 d0             	cmp    %rdx,%rax
    7d67:	73 95                	jae    7cfe <fwp_drop4+0x8e>
    7d69:	48 01 c1             	add    %rax,%rcx
    7d6c:	80 39 01             	cmpb   $0x1,(%rcx)
    7d6f:	75 8d                	jne    7cfe <fwp_drop4+0x8e>
    7d71:	48 83 c4 18          	add    $0x18,%rsp
    7d75:	e9 16 da ff ff       	jmp    5790 <fwp_mem_free>
    7d7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d80:	66 85 c0             	test   %ax,%ax
    7d83:	74 e7                	je     7d6c <fwp_drop4+0xfc>
    7d85:	48 83 c4 18          	add    $0x18,%rsp
    7d89:	c3                   	ret
    7d8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7d90:	66 85 c0             	test   %ax,%ax
    7d93:	0f 84 4d ff ff ff    	je     7ce6 <fwp_drop4+0x76>
    7d99:	48 83 c4 18          	add    $0x18,%rsp
    7d9d:	c3                   	ret
    7d9e:	66 90                	xchg   %ax,%ax
    7da0:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7da4:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7da9:	e8 e2 ed ff ff       	call   6b90 <fwp_rc_free_arr>
    7dae:	4c 8d 05 2b 9a 01 00 	lea    0x19a2b(%rip),%r8        # 217e0 <fwp_heap>
    7db5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7dba:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7dc1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7dc8:	48 c1 e2 10          	shl    $0x10,%rdx
    7dcc:	48 39 d0             	cmp    %rdx,%rax
    7dcf:	0f 83 29 ff ff ff    	jae    7cfe <fwp_drop4+0x8e>
    7dd5:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7dda:	e9 ba fe ff ff       	jmp    7c99 <fwp_drop4+0x29>
    7ddf:	90                   	nop
    7de0:	c3                   	ret
    7de1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7de8:	48 89 d0             	mov    %rdx,%rax
    7deb:	48 c1 e8 11          	shr    $0x11,%rax
    7def:	48 31 d0             	xor    %rdx,%rax
    7df2:	48 89 c1             	mov    %rax,%rcx
    7df5:	48 c1 e9 09          	shr    $0x9,%rcx
    7df9:	48 31 c8             	xor    %rcx,%rax
    7dfc:	0f b6 c8             	movzbl %al,%ecx
    7dff:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7e06:	00 
    7e07:	48 85 c0             	test   %rax,%rax
    7e0a:	75 1d                	jne    7e29 <fwp_drop4+0x1b9>
    7e0c:	eb 56                	jmp    7e64 <fwp_drop4+0x1f4>
    7e0e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7e1c:	00 00 00 00 
    7e20:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7e24:	48 85 c0             	test   %rax,%rax
    7e27:	74 3b                	je     7e64 <fwp_drop4+0x1f4>
    7e29:	48 89 c1             	mov    %rax,%rcx
    7e2c:	48 39 10             	cmp    %rdx,(%rax)
    7e2f:	75 ef                	jne    7e20 <fwp_drop4+0x1b0>
    7e31:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7e35:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7e39:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7e3d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7e44:	0f 85 b4 fe ff ff    	jne    7cfe <fwp_drop4+0x8e>
    7e4a:	48 89 d7             	mov    %rdx,%rdi
    7e4d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7e52:	e8 f9 d6 ff ff       	call   5550 <fwp_rc_forget_slot>
    7e57:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7e5c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7e5f:	e9 9a fe ff ff       	jmp    7cfe <fwp_drop4+0x8e>
    7e64:	48 8d 3d 1d 5a 00 00 	lea    0x5a1d(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    7e6b:	e8 80 c5 ff ff       	call   43f0 <fwp_trap>

0000000000007e70 <fwp_caps161>:
    7e70:	f3 0f 1e fa          	endbr64
    7e74:	85 f6                	test   %esi,%esi
    7e76:	74 08                	je     7e80 <fwp_caps161+0x10>
    7e78:	c3                   	ret
    7e79:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7e80:	48 8b 15 31 ad 01 00 	mov    0x1ad31(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7e87:	48 89 f8             	mov    %rdi,%rax
    7e8a:	48 2b 05 ff ac 01 00 	sub    0x1acff(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7e91:	48 c1 e2 10          	shl    $0x10,%rdx
    7e95:	48 39 d0             	cmp    %rdx,%rax
    7e98:	73 de                	jae    7e78 <fwp_caps161+0x8>
    7e9a:	48 89 c2             	mov    %rax,%rdx
    7e9d:	48 c1 ea 10          	shr    $0x10,%rdx
    7ea1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7ea5:	48 8b 15 2c ad 01 00 	mov    0x1ad2c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7eac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7eb0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7eb4:	48 85 c9             	test   %rcx,%rcx
    7eb7:	74 bf                	je     7e78 <fwp_caps161+0x8>
    7eb9:	0f b6 32             	movzbl (%rdx),%esi
    7ebc:	40 80 fe 02          	cmp    $0x2,%sil
    7ec0:	74 2e                	je     7ef0 <fwp_caps161+0x80>
    7ec2:	40 80 fe 01          	cmp    $0x1,%sil
    7ec6:	75 b0                	jne    7e78 <fwp_caps161+0x8>
    7ec8:	8b 72 18             	mov    0x18(%rdx),%esi
    7ecb:	0f b7 c0             	movzwl %ax,%eax
    7ece:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7ed1:	48 0f af c6          	imul   %rsi,%rax
    7ed5:	48 c1 e8 20          	shr    $0x20,%rax
    7ed9:	48 39 d0             	cmp    %rdx,%rax
    7edc:	73 9a                	jae    7e78 <fwp_caps161+0x8>
    7ede:	48 01 c1             	add    %rax,%rcx
    7ee1:	80 39 01             	cmpb   $0x1,(%rcx)
    7ee4:	75 92                	jne    7e78 <fwp_caps161+0x8>
    7ee6:	e9 a5 d8 ff ff       	jmp    5790 <fwp_mem_free>
    7eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ef0:	66 85 c0             	test   %ax,%ax
    7ef3:	74 ec                	je     7ee1 <fwp_caps161+0x71>
    7ef5:	c3                   	ret
    7ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7efd:	00 00 00 

0000000000007f00 <fwp_args12>:
    7f00:	f3 0f 1e fa          	endbr64
    7f04:	85 d2                	test   %edx,%edx
    7f06:	74 04                	je     7f0c <fwp_args12+0xc>
    7f08:	85 f6                	test   %esi,%esi
    7f0a:	74 04                	je     7f10 <fwp_args12+0x10>
    7f0c:	c3                   	ret
    7f0d:	0f 1f 00             	nopl   (%rax)
    7f10:	48 8b 15 a1 ac 01 00 	mov    0x1aca1(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7f17:	48 8b 07             	mov    (%rdi),%rax
    7f1a:	48 2b 05 6f ac 01 00 	sub    0x1ac6f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7f21:	48 c1 e2 10          	shl    $0x10,%rdx
    7f25:	48 39 d0             	cmp    %rdx,%rax
    7f28:	73 e2                	jae    7f0c <fwp_args12+0xc>
    7f2a:	48 89 c2             	mov    %rax,%rdx
    7f2d:	48 c1 ea 10          	shr    $0x10,%rdx
    7f31:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7f35:	48 8b 15 9c ac 01 00 	mov    0x1ac9c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7f3c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7f40:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7f44:	48 85 ff             	test   %rdi,%rdi
    7f47:	74 c3                	je     7f0c <fwp_args12+0xc>
    7f49:	0f b6 0a             	movzbl (%rdx),%ecx
    7f4c:	80 f9 02             	cmp    $0x2,%cl
    7f4f:	74 2f                	je     7f80 <fwp_args12+0x80>
    7f51:	80 f9 01             	cmp    $0x1,%cl
    7f54:	75 b6                	jne    7f0c <fwp_args12+0xc>
    7f56:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7f59:	0f b7 c0             	movzwl %ax,%eax
    7f5c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7f5f:	48 0f af c1          	imul   %rcx,%rax
    7f63:	48 c1 e8 20          	shr    $0x20,%rax
    7f67:	48 39 d0             	cmp    %rdx,%rax
    7f6a:	73 a0                	jae    7f0c <fwp_args12+0xc>
    7f6c:	48 01 c7             	add    %rax,%rdi
    7f6f:	0f b6 07             	movzbl (%rdi),%eax
    7f72:	84 c0                	test   %al,%al
    7f74:	74 96                	je     7f0c <fwp_args12+0xc>
    7f76:	3c fd                	cmp    $0xfd,%al
    7f78:	77 0c                	ja     7f86 <fwp_args12+0x86>
    7f7a:	83 c0 01             	add    $0x1,%eax
    7f7d:	88 07                	mov    %al,(%rdi)
    7f7f:	c3                   	ret
    7f80:	66 85 c0             	test   %ax,%ax
    7f83:	74 ea                	je     7f6f <fwp_args12+0x6f>
    7f85:	c3                   	ret
    7f86:	e9 a5 d4 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    7f8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007f90 <fwp_args23>:
    7f90:	f3 0f 1e fa          	endbr64
    7f94:	85 d2                	test   %edx,%edx
    7f96:	74 04                	je     7f9c <fwp_args23+0xc>
    7f98:	85 f6                	test   %esi,%esi
    7f9a:	74 04                	je     7fa0 <fwp_args23+0x10>
    7f9c:	c3                   	ret
    7f9d:	0f 1f 00             	nopl   (%rax)
    7fa0:	48 8b 15 11 ac 01 00 	mov    0x1ac11(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    7fa7:	48 8b 07             	mov    (%rdi),%rax
    7faa:	48 2b 05 df ab 01 00 	sub    0x1abdf(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    7fb1:	48 c1 e2 10          	shl    $0x10,%rdx
    7fb5:	48 39 d0             	cmp    %rdx,%rax
    7fb8:	73 e2                	jae    7f9c <fwp_args23+0xc>
    7fba:	48 89 c2             	mov    %rax,%rdx
    7fbd:	48 c1 ea 10          	shr    $0x10,%rdx
    7fc1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fc5:	48 8b 15 0c ac 01 00 	mov    0x1ac0c(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    7fcc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fd0:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7fd4:	48 85 ff             	test   %rdi,%rdi
    7fd7:	74 c3                	je     7f9c <fwp_args23+0xc>
    7fd9:	0f b6 0a             	movzbl (%rdx),%ecx
    7fdc:	80 f9 02             	cmp    $0x2,%cl
    7fdf:	74 2f                	je     8010 <fwp_args23+0x80>
    7fe1:	80 f9 01             	cmp    $0x1,%cl
    7fe4:	75 b6                	jne    7f9c <fwp_args23+0xc>
    7fe6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7fe9:	0f b7 c0             	movzwl %ax,%eax
    7fec:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7fef:	48 0f af c1          	imul   %rcx,%rax
    7ff3:	48 c1 e8 20          	shr    $0x20,%rax
    7ff7:	48 39 d0             	cmp    %rdx,%rax
    7ffa:	73 a0                	jae    7f9c <fwp_args23+0xc>
    7ffc:	48 01 c7             	add    %rax,%rdi
    7fff:	0f b6 07             	movzbl (%rdi),%eax
    8002:	84 c0                	test   %al,%al
    8004:	74 96                	je     7f9c <fwp_args23+0xc>
    8006:	3c fd                	cmp    $0xfd,%al
    8008:	77 0c                	ja     8016 <fwp_args23+0x86>
    800a:	83 c0 01             	add    $0x1,%eax
    800d:	88 07                	mov    %al,(%rdi)
    800f:	c3                   	ret
    8010:	66 85 c0             	test   %ax,%ax
    8013:	74 ea                	je     7fff <fwp_args23+0x6f>
    8015:	c3                   	ret
    8016:	e9 15 d4 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    801b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000008020 <fwp_caps12>:
    8020:	f3 0f 1e fa          	endbr64
    8024:	48 83 ec 18          	sub    $0x18,%rsp
    8028:	8b 57 04             	mov    0x4(%rdi),%edx
    802b:	48 89 f8             	mov    %rdi,%rax
    802e:	85 d2                	test   %edx,%edx
    8030:	0f 84 9a 00 00 00    	je     80d0 <fwp_caps12+0xb0>
    8036:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    803a:	85 f6                	test   %esi,%esi
    803c:	0f 85 9e 00 00 00    	jne    80e0 <fwp_caps12+0xc0>
    8042:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8047:	e8 54 ec ff ff       	call   6ca0 <fwp_drop0>
    804c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8051:	48 8b 0d 60 ab 01 00 	mov    0x1ab60(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    8058:	48 89 c2             	mov    %rax,%rdx
    805b:	48 2b 15 2e ab 01 00 	sub    0x1ab2e(%rip),%rdx        # 22b90 <fwp_heap+0x13b0>
    8062:	48 c1 e1 10          	shl    $0x10,%rcx
    8066:	48 39 ca             	cmp    %rcx,%rdx
    8069:	73 6d                	jae    80d8 <fwp_caps12+0xb8>
    806b:	48 89 d1             	mov    %rdx,%rcx
    806e:	48 c1 e9 10          	shr    $0x10,%rcx
    8072:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8076:	48 8b 0d 5b ab 01 00 	mov    0x1ab5b(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    807d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    8081:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8085:	48 85 f6             	test   %rsi,%rsi
    8088:	74 4e                	je     80d8 <fwp_caps12+0xb8>
    808a:	0f b6 39             	movzbl (%rcx),%edi
    808d:	40 80 ff 02          	cmp    $0x2,%dil
    8091:	0f 84 b9 00 00 00    	je     8150 <fwp_caps12+0x130>
    8097:	40 80 ff 01          	cmp    $0x1,%dil
    809b:	75 3b                	jne    80d8 <fwp_caps12+0xb8>
    809d:	8b 79 18             	mov    0x18(%rcx),%edi
    80a0:	0f b7 d2             	movzwl %dx,%edx
    80a3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    80a6:	48 0f af d7          	imul   %rdi,%rdx
    80aa:	48 c1 ea 20          	shr    $0x20,%rdx
    80ae:	48 39 ca             	cmp    %rcx,%rdx
    80b1:	73 25                	jae    80d8 <fwp_caps12+0xb8>
    80b3:	48 01 d6             	add    %rdx,%rsi
    80b6:	80 3e 01             	cmpb   $0x1,(%rsi)
    80b9:	75 1d                	jne    80d8 <fwp_caps12+0xb8>
    80bb:	48 89 c7             	mov    %rax,%rdi
    80be:	48 83 c4 18          	add    $0x18,%rsp
    80c2:	e9 c9 d6 ff ff       	jmp    5790 <fwp_mem_free>
    80c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ce:	00 00 
    80d0:	85 f6                	test   %esi,%esi
    80d2:	0f 84 79 ff ff ff    	je     8051 <fwp_caps12+0x31>
    80d8:	48 83 c4 18          	add    $0x18,%rsp
    80dc:	c3                   	ret
    80dd:	0f 1f 00             	nopl   (%rax)
    80e0:	48 8b 05 d1 aa 01 00 	mov    0x1aad1(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    80e7:	48 2b 3d a2 aa 01 00 	sub    0x1aaa2(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    80ee:	48 c1 e0 10          	shl    $0x10,%rax
    80f2:	48 39 c7             	cmp    %rax,%rdi
    80f5:	73 e1                	jae    80d8 <fwp_caps12+0xb8>
    80f7:	48 89 f8             	mov    %rdi,%rax
    80fa:	48 c1 e8 10          	shr    $0x10,%rax
    80fe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    8102:	48 8b 05 cf aa 01 00 	mov    0x1aacf(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    8109:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    810d:	48 8b 42 20          	mov    0x20(%rdx),%rax
    8111:	48 85 c0             	test   %rax,%rax
    8114:	74 c2                	je     80d8 <fwp_caps12+0xb8>
    8116:	0f b6 0a             	movzbl (%rdx),%ecx
    8119:	80 f9 02             	cmp    $0x2,%cl
    811c:	74 42                	je     8160 <fwp_caps12+0x140>
    811e:	80 f9 01             	cmp    $0x1,%cl
    8121:	75 b5                	jne    80d8 <fwp_caps12+0xb8>
    8123:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8126:	0f b7 ff             	movzwl %di,%edi
    8129:	8b 52 1c             	mov    0x1c(%rdx),%edx
    812c:	48 0f af f9          	imul   %rcx,%rdi
    8130:	48 c1 ef 20          	shr    $0x20,%rdi
    8134:	48 39 d7             	cmp    %rdx,%rdi
    8137:	73 9f                	jae    80d8 <fwp_caps12+0xb8>
    8139:	48 01 f8             	add    %rdi,%rax
    813c:	0f b6 10             	movzbl (%rax),%edx
    813f:	84 d2                	test   %dl,%dl
    8141:	74 95                	je     80d8 <fwp_caps12+0xb8>
    8143:	80 fa fd             	cmp    $0xfd,%dl
    8146:	77 23                	ja     816b <fwp_caps12+0x14b>
    8148:	83 c2 01             	add    $0x1,%edx
    814b:	88 10                	mov    %dl,(%rax)
    814d:	eb 89                	jmp    80d8 <fwp_caps12+0xb8>
    814f:	90                   	nop
    8150:	66 85 d2             	test   %dx,%dx
    8153:	0f 85 7f ff ff ff    	jne    80d8 <fwp_caps12+0xb8>
    8159:	e9 58 ff ff ff       	jmp    80b6 <fwp_caps12+0x96>
    815e:	66 90                	xchg   %ax,%ax
    8160:	66 85 ff             	test   %di,%di
    8163:	0f 85 6f ff ff ff    	jne    80d8 <fwp_caps12+0xb8>
    8169:	eb d1                	jmp    813c <fwp_caps12+0x11c>
    816b:	48 89 c7             	mov    %rax,%rdi
    816e:	48 83 c4 18          	add    $0x18,%rsp
    8172:	e9 b9 d2 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    8177:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    817e:	00 00 

0000000000008180 <f12>:
    8180:	41 57                	push   %r15
    8182:	41 56                	push   %r14
    8184:	41 55                	push   %r13
    8186:	41 54                	push   %r12
    8188:	4c 8d 25 31 f1 ff ff 	lea    -0xecf(%rip),%r12        # 72c0 <fwp_tape_scope_release>
    818f:	55                   	push   %rbp
    8190:	53                   	push   %rbx
    8191:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
    8198:	48 8b 15 19 aa 01 00 	mov    0x1aa19(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    819f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    81a4:	48 c1 e2 10          	shl    $0x10,%rdx
    81a8:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    81af:	00 00 
    81b1:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
    81b8:	00 
    81b9:	31 c0                	xor    %eax,%eax
    81bb:	48 8b 05 b6 b2 01 00 	mov    0x1b2b6(%rip),%rax        # 23478 <fwp_cleanups>
    81c2:	c7 44 24 5c ff ff ff 	movl   $0xffffffff,0x5c(%rsp)
    81c9:	ff 
    81ca:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    81cf:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    81d4:	48 8d 44 24 5c       	lea    0x5c(%rsp),%rax
    81d9:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    81de:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    81e3:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
    81e8:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    81ed:	48 89 05 84 b2 01 00 	mov    %rax,0x1b284(%rip)        # 23478 <fwp_cleanups>
    81f4:	48 8d 05 15 8e 00 00 	lea    0x8e15(%rip),%rax        # 11010 <fc23>
    81fb:	48 2b 05 8e a9 01 00 	sub    0x1a98e(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8202:	48 39 d0             	cmp    %rdx,%rax
    8205:	73 5d                	jae    8264 <f12+0xe4>
    8207:	48 89 c2             	mov    %rax,%rdx
    820a:	48 c1 ea 10          	shr    $0x10,%rdx
    820e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8212:	48 8b 15 bf a9 01 00 	mov    0x1a9bf(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    8219:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    821d:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    8221:	48 85 ff             	test   %rdi,%rdi
    8224:	74 3e                	je     8264 <f12+0xe4>
    8226:	0f b6 0a             	movzbl (%rdx),%ecx
    8229:	80 f9 02             	cmp    $0x2,%cl
    822c:	0f 84 0e 12 00 00    	je     9440 <f12+0x12c0>
    8232:	80 f9 01             	cmp    $0x1,%cl
    8235:	75 2d                	jne    8264 <f12+0xe4>
    8237:	8b 4a 18             	mov    0x18(%rdx),%ecx
    823a:	0f b7 c0             	movzwl %ax,%eax
    823d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8240:	48 0f af c1          	imul   %rcx,%rax
    8244:	48 c1 e8 20          	shr    $0x20,%rax
    8248:	48 39 d0             	cmp    %rdx,%rax
    824b:	73 17                	jae    8264 <f12+0xe4>
    824d:	48 01 c7             	add    %rax,%rdi
    8250:	0f b6 07             	movzbl (%rdi),%eax
    8253:	84 c0                	test   %al,%al
    8255:	74 0d                	je     8264 <f12+0xe4>
    8257:	3c fd                	cmp    $0xfd,%al
    8259:	0f 87 35 14 00 00    	ja     9694 <f12+0x1514>
    825f:	83 c0 01             	add    $0x1,%eax
    8262:	88 07                	mov    %al,(%rdi)
    8264:	48 8d 3d a5 8d 00 00 	lea    0x8da5(%rip),%rdi        # 11010 <fc23>
    826b:	e8 20 ed ff ff       	call   6f90 <fwp_closure_drop>
    8270:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8275:	48 85 c0             	test   %rax,%rax
    8278:	0f 84 87 13 00 00    	je     9605 <f12+0x1485>
    827e:	31 db                	xor    %ebx,%ebx
    8280:	48 8b 40 10          	mov    0x10(%rax),%rax
    8284:	48 83 c3 01          	add    $0x1,%rbx
    8288:	48 85 c0             	test   %rax,%rax
    828b:	75 f3                	jne    8280 <f12+0x100>
    828d:	31 ff                	xor    %edi,%edi
    828f:	e8 bc bf ff ff       	call   4250 <descent_phase_step>
    8294:	48 81 fb ff ff ff 7f 	cmp    $0x7fffffff,%rbx
    829b:	0f 87 e6 14 00 00    	ja     9787 <f12+0x1607>
    82a1:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    82a6:	44 8b 05 d3 8d 00 00 	mov    0x8dd3(%rip),%r8d        # 11080 <registered_finish.0>
    82ad:	45 85 c0             	test   %r8d,%r8d
    82b0:	0f 84 5a 11 00 00    	je     9410 <f12+0x1290>
    82b6:	48 8b 15 3b 8e 01 00 	mov    0x18e3b(%rip),%rdx        # 210f8 <fwp_tape_next_slot>
    82bd:	48 8b 1d 44 8e 01 00 	mov    0x18e44(%rip),%rbx        # 21108 <fwp_ntapes>
    82c4:	48 39 da             	cmp    %rbx,%rdx
    82c7:	0f 8d f3 05 00 00    	jge    88c0 <f12+0x740>
    82cd:	48 6b c2 68          	imul   $0x68,%rdx,%rax
    82d1:	48 03 05 38 8e 01 00 	add    0x18e38(%rip),%rax        # 21110 <fwp_tapes>
    82d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    82df:	00 
    82e0:	8b 78 04             	mov    0x4(%rax),%edi
    82e3:	85 ff                	test   %edi,%edi
    82e5:	75 0c                	jne    82f3 <f12+0x173>
    82e7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    82ed:	0f 86 cd 05 00 00    	jbe    88c0 <f12+0x740>
    82f3:	48 83 c2 01          	add    $0x1,%rdx
    82f7:	48 83 c0 68          	add    $0x68,%rax
    82fb:	48 39 da             	cmp    %rbx,%rdx
    82fe:	75 e0                	jne    82e0 <f12+0x160>
    8300:	48 81 fb fe ff 00 00 	cmp    $0xfffe,%rbx
    8307:	0f 8f af 14 00 00    	jg     97bc <f12+0x163c>
    830d:	48 39 1d ec 8d 01 00 	cmp    %rbx,0x18dec(%rip)        # 21100 <fwp_tapes_cap>
    8314:	48 8b 2d f5 8d 01 00 	mov    0x18df5(%rip),%rbp        # 21110 <fwp_tapes>
    831b:	75 42                	jne    835f <f12+0x1df>
    831d:	48 85 db             	test   %rbx,%rbx
    8320:	0f 85 6a 12 00 00    	jne    9590 <f12+0x1410>
    8326:	be 68 00 00 00       	mov    $0x68,%esi
    832b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    8331:	48 89 ef             	mov    %rbp,%rdi
    8334:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    833a:	e8 91 b2 ff ff       	call   35d0 <realloc@plt>
    833f:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    8345:	48 85 c0             	test   %rax,%rax
    8348:	48 89 c5             	mov    %rax,%rbp
    834b:	0f 84 36 11 00 00    	je     9487 <f12+0x1307>
    8351:	48 89 05 b8 8d 01 00 	mov    %rax,0x18db8(%rip)        # 21110 <fwp_tapes>
    8358:	4c 89 2d a1 8d 01 00 	mov    %r13,0x18da1(%rip)        # 21100 <fwp_tapes_cap>
    835f:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    8363:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    8367:	48 01 e8             	add    %rbp,%rax
    836a:	48 8d 78 08          	lea    0x8(%rax),%rdi
    836e:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8375:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8379:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8380:	00 
    8381:	48 29 f8             	sub    %rdi,%rax
    8384:	8d 48 68             	lea    0x68(%rax),%ecx
    8387:	31 c0                	xor    %eax,%eax
    8389:	c1 e9 03             	shr    $0x3,%ecx
    838c:	f3 48 ab             	rep stos %rax,(%rdi)
    838f:	4c 89 2d 72 8d 01 00 	mov    %r13,0x18d72(%rip)        # 21108 <fwp_ntapes>
    8396:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    839a:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    839e:	48 8d 3d 7d 4d 00 00 	lea    0x4d7d(%rip),%rdi        # d122 <_IO_stdin_used+0x122>
    83a5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    83aa:	49 01 ee             	add    %rbp,%r14
    83ad:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    83b4:	00 
    83b5:	e8 e6 af ff ff       	call   33a0 <getenv@plt>
    83ba:	66 0f 6f 44 24 10    	movdqa 0x10(%rsp),%xmm0
    83c0:	48 85 c0             	test   %rax,%rax
    83c3:	74 09                	je     83ce <f12+0x24e>
    83c5:	80 38 30             	cmpb   $0x30,(%rax)
    83c8:	0f 84 d2 03 00 00    	je     87a0 <f12+0x620>
    83ce:	48 83 3d d2 8c 01 00 	cmpq   $0x0,0x18cd2(%rip)        # 210a8 <fwp_tape_cached_bytes>
    83d5:	00 
    83d6:	0f 85 04 11 00 00    	jne    94e0 <f12+0x1360>
    83dc:	41 8b 06             	mov    (%r14),%eax
    83df:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    83e6:	00 
    83e7:	4c 89 2d 0a 8d 01 00 	mov    %r13,0x18d0a(%rip)        # 210f8 <fwp_tape_next_slot>
    83ee:	8d 70 01             	lea    0x1(%rax),%esi
    83f1:	48 8b 05 80 b0 01 00 	mov    0x1b080(%rip),%rax        # 23478 <fwp_cleanups>
    83f8:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    83fd:	41 89 36             	mov    %esi,(%r14)
    8400:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    8407:	00 
    8408:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    840f:	ff 
    8410:	48 85 c0             	test   %rax,%rax
    8413:	75 17                	jne    842c <f12+0x2ac>
    8415:	e9 96 13 00 00       	jmp    97b0 <f12+0x1630>
    841a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8420:	48 8b 00             	mov    (%rax),%rax
    8423:	48 85 c0             	test   %rax,%rax
    8426:	0f 84 84 13 00 00    	je     97b0 <f12+0x1630>
    842c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8430:	75 ee                	jne    8420 <f12+0x2a0>
    8432:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8436:	89 d9                	mov    %ebx,%ecx
    8438:	48 63 02             	movslq (%rdx),%rax
    843b:	49 89 56 50          	mov    %rdx,0x50(%r14)
    843f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8443:	85 c0                	test   %eax,%eax
    8445:	78 08                	js     844f <f12+0x2cf>
    8447:	48 6b c0 68          	imul   $0x68,%rax,%rax
    844b:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    844f:	89 0a                	mov    %ecx,(%rdx)
    8451:	bf 01 00 00 00       	mov    $0x1,%edi
    8456:	89 74 24 10          	mov    %esi,0x10(%rsp)
    845a:	e8 f1 bd ff ff       	call   4250 <descent_phase_step>
    845f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    8464:	31 c9                	xor    %ecx,%ecx
    8466:	8b 74 24 10          	mov    0x10(%rsp),%esi
    846a:	48 85 ff             	test   %rdi,%rdi
    846d:	48 89 f8             	mov    %rdi,%rax
    8470:	0f 84 3a 03 00 00    	je     87b0 <f12+0x630>
    8476:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    847d:	00 00 00 
    8480:	48 8b 40 10          	mov    0x10(%rax),%rax
    8484:	48 83 c1 01          	add    $0x1,%rcx
    8488:	48 85 c0             	test   %rax,%rax
    848b:	75 f3                	jne    8480 <f12+0x300>
    848d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8492:	0f 1f 00             	nopl   (%rax)
    8495:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    849c:	00 00 00 00 
    84a0:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    84a4:	48 83 c0 01          	add    $0x1,%rax
    84a8:	48 85 d2             	test   %rdx,%rdx
    84ab:	75 f3                	jne    84a0 <f12+0x320>
    84ad:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    84b4:	ff ff 1f 
    84b7:	48 39 c2             	cmp    %rax,%rdx
    84ba:	0f 82 d3 12 00 00    	jb     9793 <f12+0x1613>
    84c0:	48 85 c9             	test   %rcx,%rcx
    84c3:	0f 8e e7 02 00 00    	jle    87b0 <f12+0x630>
    84c9:	48 39 c1             	cmp    %rax,%rcx
    84cc:	48 0f 46 c1          	cmovbe %rcx,%rax
    84d0:	49 89 c4             	mov    %rax,%r12
    84d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    84d7:	0f 85 b6 12 00 00    	jne    9793 <f12+0x1613>
    84dd:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    84e1:	48 c1 e6 10          	shl    $0x10,%rsi
    84e5:	49 09 f5             	or     %rsi,%r13
    84e8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    84ef:	00 
    84f0:	be 02 00 00 00       	mov    $0x2,%esi
    84f5:	e8 96 d7 ff ff       	call   5c90 <fwp_heap_alloc>
    84fa:	4c 89 30             	mov    %r14,(%rax)
    84fd:	48 8b 15 b4 a6 01 00 	mov    0x1a6b4(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    8504:	48 89 c3             	mov    %rax,%rbx
    8507:	48 2b 05 82 a6 01 00 	sub    0x1a682(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    850e:	48 c1 e2 10          	shl    $0x10,%rdx
    8512:	48 39 d0             	cmp    %rdx,%rax
    8515:	0f 83 c5 10 00 00    	jae    95e0 <f12+0x1460>
    851b:	48 89 c2             	mov    %rax,%rdx
    851e:	48 c1 ea 10          	shr    $0x10,%rdx
    8522:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8526:	48 8b 15 ab a6 01 00 	mov    0x1a6ab(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    852d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8531:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8535:	4d 85 f6             	test   %r14,%r14
    8538:	74 38                	je     8572 <f12+0x3f2>
    853a:	0f b6 0a             	movzbl (%rdx),%ecx
    853d:	80 f9 02             	cmp    $0x2,%cl
    8540:	0f 84 d7 02 00 00    	je     881d <f12+0x69d>
    8546:	80 f9 01             	cmp    $0x1,%cl
    8549:	75 27                	jne    8572 <f12+0x3f2>
    854b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    854e:	0f b7 c0             	movzwl %ax,%eax
    8551:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8554:	48 0f af c1          	imul   %rcx,%rax
    8558:	48 c1 e8 20          	shr    $0x20,%rax
    855c:	48 39 d0             	cmp    %rdx,%rax
    855f:	73 11                	jae    8572 <f12+0x3f2>
    8561:	49 01 c6             	add    %rax,%r14
    8564:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8568:	0f 84 ff 10 00 00    	je     966d <f12+0x14ed>
    856e:	41 c6 06 01          	movb   $0x1,(%r14)
    8572:	4d 85 e4             	test   %r12,%r12
    8575:	74 7c                	je     85f3 <f12+0x473>
    8577:	4c 89 e9             	mov    %r13,%rcx
    857a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    857f:	31 c0                	xor    %eax,%eax
    8581:	48 c1 e1 20          	shl    $0x20,%rcx
    8585:	0f 1f 40 00          	nopl   0x0(%rax)
    8589:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8590:	00 00 00 00 
    8594:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    859b:	00 00 00 00 
    859f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85a6:	00 00 00 00 
    85aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85b1:	00 00 00 00 
    85b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    85bc:	00 00 00 00 
    85c0:	48 89 c6             	mov    %rax,%rsi
    85c3:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    85c8:	48 01 ce             	add    %rcx,%rsi
    85cb:	0f 80 9d 11 00 00    	jo     976e <f12+0x15ee>
    85d1:	66 48 0f 6e de       	movq   %rsi,%xmm3
    85d6:	48 89 c6             	mov    %rax,%rsi
    85d9:	48 83 c0 01          	add    $0x1,%rax
    85dd:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    85e1:	48 c1 e6 04          	shl    $0x4,%rsi
    85e5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    85ea:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    85ee:	4c 39 e0             	cmp    %r12,%rax
    85f1:	72 cd                	jb     85c0 <f12+0x440>
    85f3:	48 8b 03             	mov    (%rbx),%rax
    85f6:	48 d1 e8             	shr    $1,%rax
    85f9:	0f 85 31 02 00 00    	jne    8830 <f12+0x6b0>
    85ff:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    8606:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    860d:	0f 1f 00             	nopl   (%rax)
    8610:	48 89 df             	mov    %rbx,%rdi
    8613:	4d 63 e5             	movslq %r13d,%r12
    8616:	e8 55 f6 ff ff       	call   7c70 <fwp_drop4>
    861b:	bf 02 00 00 00       	mov    $0x2,%edi
    8620:	e8 2b bc ff ff       	call   4250 <descent_phase_step>
    8625:	4c 89 e7             	mov    %r12,%rdi
    8628:	e8 a3 c0 ff ff       	call   46d0 <fwp_tape_of>
    862d:	48 89 c6             	mov    %rax,%rsi
    8630:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    8635:	0f 85 69 11 00 00    	jne    97a4 <f12+0x1624>
    863b:	48 89 c7             	mov    %rax,%rdi
    863e:	e8 bd b5 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    8643:	f3 0f 6f 7e 20       	movdqu 0x20(%rsi),%xmm7
    8648:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    864c:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8653:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8658:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    865c:	0f 29 7c 24 20       	movaps %xmm7,0x20(%rsp)
    8661:	f3 0f 6f 7e 30       	movdqu 0x30(%rsi),%xmm7
    8666:	66 49 0f 6e d6       	movq   %r14,%xmm2
    866b:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    866f:	48 8b 5e 40          	mov    0x40(%rsi),%rbx
    8673:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    8677:	0f 29 7c 24 10       	movaps %xmm7,0x10(%rsp)
    867c:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    8682:	77 19                	ja     869d <f12+0x51d>
    8684:	41 0f b7 c5          	movzwl %r13w,%eax
    8688:	83 e8 01             	sub    $0x1,%eax
    868b:	48 98                	cltq
    868d:	48 3b 05 64 8a 01 00 	cmp    0x18a64(%rip),%rax        # 210f8 <fwp_tape_next_slot>
    8694:	7d 07                	jge    869d <f12+0x51d>
    8696:	48 89 05 5b 8a 01 00 	mov    %rax,0x18a5b(%rip)        # 210f8 <fwp_tape_next_slot>
    869d:	66 0f ef c9          	pxor   %xmm1,%xmm1
    86a1:	48 8b 05 d0 ad 01 00 	mov    0x1add0(%rip),%rax        # 23478 <fwp_cleanups>
    86a8:	66 0f 6f 7c 24 20    	movdqa 0x20(%rsp),%xmm7
    86ae:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    86b5:	00 
    86b6:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    86ba:	66 0f 6f 54 24 10    	movdqa 0x10(%rsp),%xmm2
    86c0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    86c7:	00 
    86c8:	48 8d 05 a1 c9 ff ff 	lea    -0x365f(%rip),%rax        # 5070 <fwp_tape_buffers_release>
    86cf:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
    86d6:	00 
    86d7:	48 8d 84 24 a0 00 00 	lea    0xa0(%rsp),%rax
    86de:	00 
    86df:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    86e4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
    86eb:	00 
    86ec:	48 8d 84 24 80 00 00 	lea    0x80(%rsp),%rax
    86f3:	00 
    86f4:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    86f8:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    86fc:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    8703:	00 
    8704:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    870b:	00 
    870c:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
    8713:	00 
    8714:	48 89 05 5d ad 01 00 	mov    %rax,0x1ad5d(%rip)        # 23478 <fwp_cleanups>
    871b:	0f 29 bc 24 a0 00 00 	movaps %xmm7,0xa0(%rsp)
    8722:	00 
    8723:	0f 29 94 24 b0 00 00 	movaps %xmm2,0xb0(%rsp)
    872a:	00 
    872b:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
    8732:	00 
    8733:	4d 85 ff             	test   %r15,%r15
    8736:	0f 88 14 0d 00 00    	js     9450 <f12+0x12d0>
    873c:	4c 89 f8             	mov    %r15,%rax
    873f:	48 c1 f8 20          	sar    $0x20,%rax
    8743:	49 39 c4             	cmp    %rax,%r12
    8746:	0f 85 f9 0f 00 00    	jne    9745 <f12+0x15c5>
    874c:	45 89 fa             	mov    %r15d,%r10d
    874f:	4d 89 d5             	mov    %r10,%r13
    8752:	4c 39 d2             	cmp    %r10,%rdx
    8755:	0f 8e f6 0f 00 00    	jle    9751 <f12+0x15d1>
    875b:	4c 39 d5             	cmp    %r10,%rbp
    875e:	0f 8e 7c 01 00 00    	jle    88e0 <f12+0x760>
    8764:	4c 39 f5             	cmp    %r14,%rbp
    8767:	0f 8f 13 0e 00 00    	jg     9580 <f12+0x1400>
    876d:	48 85 db             	test   %rbx,%rbx
    8770:	0f 84 f8 0c 00 00    	je     946e <f12+0x12ee>
    8776:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    877d:	00 
    877e:	31 f6                	xor    %esi,%esi
    8780:	48 89 df             	mov    %rbx,%rdi
    8783:	45 31 f6             	xor    %r14d,%r14d
    8786:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    878b:	4c 8d 6d ff          	lea    -0x1(%rbp),%r13
    878f:	e8 2c ad ff ff       	call   34c0 <memset@plt>
    8794:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    8799:	e9 cf 01 00 00       	jmp    896d <f12+0x7ed>
    879e:	66 90                	xchg   %ax,%ax
    87a0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    87a4:	0f 84 32 fc ff ff    	je     83dc <f12+0x25c>
    87aa:	e9 1f fc ff ff       	jmp    83ce <f12+0x24e>
    87af:	90                   	nop
    87b0:	48 c1 e6 10          	shl    $0x10,%rsi
    87b4:	bf 08 00 00 00       	mov    $0x8,%edi
    87b9:	49 09 f5             	or     %rsi,%r13
    87bc:	be 02 00 00 00       	mov    $0x2,%esi
    87c1:	e8 ca d4 ff ff       	call   5c90 <fwp_heap_alloc>
    87c6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    87cd:	48 8b 15 e4 a3 01 00 	mov    0x1a3e4(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    87d4:	48 89 c3             	mov    %rax,%rbx
    87d7:	48 2b 05 b2 a3 01 00 	sub    0x1a3b2(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    87de:	48 c1 e2 10          	shl    $0x10,%rdx
    87e2:	48 39 d0             	cmp    %rdx,%rax
    87e5:	0f 83 14 fe ff ff    	jae    85ff <f12+0x47f>
    87eb:	48 89 c2             	mov    %rax,%rdx
    87ee:	48 c1 ea 10          	shr    $0x10,%rdx
    87f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    87f6:	48 8b 15 db a3 01 00 	mov    0x1a3db(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    87fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8801:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8805:	4d 85 f6             	test   %r14,%r14
    8808:	0f 84 e5 fd ff ff    	je     85f3 <f12+0x473>
    880e:	0f b6 0a             	movzbl (%rdx),%ecx
    8811:	45 31 e4             	xor    %r12d,%r12d
    8814:	80 f9 02             	cmp    $0x2,%cl
    8817:	0f 85 29 fd ff ff    	jne    8546 <f12+0x3c6>
    881d:	66 85 c0             	test   %ax,%ax
    8820:	0f 85 4c fd ff ff    	jne    8572 <f12+0x3f2>
    8826:	e9 39 fd ff ff       	jmp    8564 <f12+0x3e4>
    882b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8830:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    8834:	4c 89 e1             	mov    %r12,%rcx
    8837:	48 c1 e9 3c          	shr    $0x3c,%rcx
    883b:	0f 85 52 0f 00 00    	jne    9793 <f12+0x1613>
    8841:	4d 85 e4             	test   %r12,%r12
    8844:	0f 84 b5 fd ff ff    	je     85ff <f12+0x47f>
    884a:	48 c1 e0 04          	shl    $0x4,%rax
    884e:	4d 01 e4             	add    %r12,%r12
    8851:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    8855:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    885a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8860:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    8865:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    8869:	48 83 c5 10          	add    $0x10,%rbp
    886d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    8871:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    8876:	e8 65 db ff ff       	call   63e0 <w107>
    887b:	66 48 0f 6e e0       	movq   %rax,%xmm4
    8880:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    8884:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    8888:	49 39 ee             	cmp    %rbp,%r14
    888b:	75 d3                	jne    8860 <f12+0x6e0>
    888d:	4c 89 23             	mov    %r12,(%rbx)
    8890:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    8897:	45 31 f6             	xor    %r14d,%r14d
    889a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    88a0:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    88a5:	4c 89 ff             	mov    %r15,%rdi
    88a8:	49 83 c6 02          	add    $0x2,%r14
    88ac:	e8 af d9 ff ff       	call   6260 <f128.constprop.0>
    88b1:	49 89 c7             	mov    %rax,%r15
    88b4:	4d 39 e6             	cmp    %r12,%r14
    88b7:	72 e7                	jb     88a0 <f12+0x720>
    88b9:	e9 52 fd ff ff       	jmp    8610 <f12+0x490>
    88be:	66 90                	xchg   %ax,%ax
    88c0:	48 39 d3             	cmp    %rdx,%rbx
    88c3:	0f 84 37 fa ff ff    	je     8300 <f12+0x180>
    88c9:	48 8b 2d 40 88 01 00 	mov    0x18840(%rip),%rbp        # 21110 <fwp_tapes>
    88d0:	48 89 d3             	mov    %rdx,%rbx
    88d3:	4c 8d 6a 01          	lea    0x1(%rdx),%r13
    88d7:	e9 ba fa ff ff       	jmp    8396 <f12+0x216>
    88dc:	0f 1f 40 00          	nopl   0x0(%rax)
    88e0:	4d 8d 62 01          	lea    0x1(%r10),%r12
    88e4:	4d 39 e6             	cmp    %r12,%r14
    88e7:	0f 8d 63 0c 00 00    	jge    9550 <f12+0x13d0>
    88ed:	4d 85 f6             	test   %r14,%r14
    88f0:	4d 0f 44 f4          	cmove  %r12,%r14
    88f4:	eb 1f                	jmp    8915 <f12+0x795>
    88f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    88fd:	00 00 00 
    8900:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8904:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    890b:	4c 89 e0             	mov    %r12,%rax
    890e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8912:	49 89 c6             	mov    %rax,%r14
    8915:	4d 39 e6             	cmp    %r12,%r14
    8918:	7c e6                	jl     8900 <f12+0x780>
    891a:	48 85 db             	test   %rbx,%rbx
    891d:	0f 84 cd 0c 00 00    	je     95f0 <f12+0x1470>
    8923:	48 89 df             	mov    %rbx,%rdi
    8926:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    892d:	00 
    892e:	e8 9d ac ff ff       	call   35d0 <realloc@plt>
    8933:	48 89 c3             	mov    %rax,%rbx
    8936:	48 85 db             	test   %rbx,%rbx
    8939:	0f 84 1d 0b 00 00    	je     945c <f12+0x12dc>
    893f:	48 89 9c 24 c0 00 00 	mov    %rbx,0xc0(%rsp)
    8946:	00 
    8947:	4c 89 b4 24 d0 00 00 	mov    %r14,0xd0(%rsp)
    894e:	00 
    894f:	4d 85 e4             	test   %r12,%r12
    8952:	0f 85 46 0d 00 00    	jne    969e <f12+0x151e>
    8958:	49 89 ee             	mov    %rbp,%r14
    895b:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
    8962:	49 f7 de             	neg    %r14
    8965:	4d 85 ff             	test   %r15,%r15
    8968:	78 17                	js     8981 <f12+0x801>
    896a:	45 89 fa             	mov    %r15d,%r10d
    896d:	f2 0f 10 05 ab 52 00 	movsd  0x52ab(%rip),%xmm0        # dc20 <msg.4+0xb0>
    8974:	00 
    8975:	f2 42 0f 58 04 d3    	addsd  (%rbx,%r10,8),%xmm0
    897b:	f2 42 0f 11 04 d3    	movsd  %xmm0,(%rbx,%r10,8)
    8981:	bf 03 00 00 00       	mov    $0x3,%edi
    8986:	48 01 2d 93 87 01 00 	add    %rbp,0x18793(%rip)        # 21120 <descent_inputs>
    898d:	4c 01 35 94 87 01 00 	add    %r14,0x18794(%rip)        # 21128 <descent_nodes>
    8994:	e8 b7 b8 ff ff       	call   4250 <descent_phase_step>
    8999:	4c 39 ed             	cmp    %r13,%rbp
    899c:	0f 8f 87 00 00 00    	jg     8a29 <f12+0x8a9>
    89a2:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    89a7:	49 29 ed             	sub    %rbp,%r13
    89aa:	48 8d 3c eb          	lea    (%rbx,%rbp,8),%rdi
    89ae:	66 0f ef d2          	pxor   %xmm2,%xmm2
    89b2:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
    89b7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    89bc:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    89c1:	4b 8d 14 eb          	lea    (%r11,%r13,8),%rdx
    89c5:	4c 29 df             	sub    %r11,%rdi
    89c8:	4a 8d 04 ae          	lea    (%rsi,%r13,4),%rax
    89cc:	48 29 f1             	sub    %rsi,%rcx
    89cf:	4d 29 da             	sub    %r11,%r10
    89d2:	eb 08                	jmp    89dc <f12+0x85c>
    89d4:	0f 1f 40 00          	nopl   0x0(%rax)
    89d8:	48 83 e8 04          	sub    $0x4,%rax
    89dc:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    89e1:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    89e5:	7a 02                	jp     89e9 <f12+0x869>
    89e7:	74 37                	je     8a20 <f12+0x8a0>
    89e9:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    89ed:	45 85 db             	test   %r11d,%r11d
    89f0:	78 16                	js     8a08 <f12+0x888>
    89f2:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    89f8:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    89fc:	f2 42 0f 58 0c db    	addsd  (%rbx,%r11,8),%xmm1
    8a02:	f2 42 0f 11 0c db    	movsd  %xmm1,(%rbx,%r11,8)
    8a08:	4c 63 18             	movslq (%rax),%r11
    8a0b:	45 85 db             	test   %r11d,%r11d
    8a0e:	78 10                	js     8a20 <f12+0x8a0>
    8a10:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    8a14:	f2 42 0f 58 04 db    	addsd  (%rbx,%r11,8),%xmm0
    8a1a:	f2 42 0f 11 04 db    	movsd  %xmm0,(%rbx,%r11,8)
    8a20:	48 83 ea 08          	sub    $0x8,%rdx
    8a24:	48 39 c6             	cmp    %rax,%rsi
    8a27:	75 af                	jne    89d8 <f12+0x858>
    8a29:	bf 04 00 00 00       	mov    $0x4,%edi
    8a2e:	e8 1d b8 ff ff       	call   4250 <descent_phase_step>
    8a33:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8a3a:	ff ff 1f 
    8a3d:	48 39 e8             	cmp    %rbp,%rax
    8a40:	0f 82 35 0d 00 00    	jb     977b <f12+0x15fb>
    8a46:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    8a4d:	00 
    8a4e:	be 02 00 00 00       	mov    $0x2,%esi
    8a53:	e8 38 d2 ff ff       	call   5c90 <fwp_heap_alloc>
    8a58:	48 89 28             	mov    %rbp,(%rax)
    8a5b:	49 89 c4             	mov    %rax,%r12
    8a5e:	31 c0                	xor    %eax,%eax
    8a60:	48 85 ed             	test   %rbp,%rbp
    8a63:	74 2d                	je     8a92 <f12+0x912>
    8a65:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a71:	00 00 00 00 
    8a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8a7c:	00 00 00 00 
    8a80:	48 8b 14 c3          	mov    (%rbx,%rax,8),%rdx
    8a84:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    8a89:	48 83 c0 01          	add    $0x1,%rax
    8a8d:	48 39 c5             	cmp    %rax,%rbp
    8a90:	75 ee                	jne    8a80 <f12+0x900>
    8a92:	bf 05 00 00 00       	mov    $0x5,%edi
    8a97:	e8 b4 b7 ff ff       	call   4250 <descent_phase_step>
    8a9c:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
    8aa3:	00 
    8aa4:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    8aa9:	4c 89 2d c8 a9 01 00 	mov    %r13,0x1a9c8(%rip)        # 23478 <fwp_cleanups>
    8ab0:	e8 bb c5 ff ff       	call   5070 <fwp_tape_buffers_release>
    8ab5:	bf 06 00 00 00       	mov    $0x6,%edi
    8aba:	e8 91 b7 ff ff       	call   4250 <descent_phase_step>
    8abf:	48 8b 15 f2 a0 01 00 	mov    0x1a0f2(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    8ac6:	4c 89 e0             	mov    %r12,%rax
    8ac9:	48 2b 05 c0 a0 01 00 	sub    0x1a0c0(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8ad0:	48 c1 e2 10          	shl    $0x10,%rdx
    8ad4:	48 39 d0             	cmp    %rdx,%rax
    8ad7:	73 55                	jae    8b2e <f12+0x9ae>
    8ad9:	48 89 c2             	mov    %rax,%rdx
    8adc:	48 c1 ea 10          	shr    $0x10,%rdx
    8ae0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ae4:	48 8b 15 ed a0 01 00 	mov    0x1a0ed(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    8aeb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8aef:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    8af3:	48 85 db             	test   %rbx,%rbx
    8af6:	74 36                	je     8b2e <f12+0x9ae>
    8af8:	0f b6 0a             	movzbl (%rdx),%ecx
    8afb:	80 f9 02             	cmp    $0x2,%cl
    8afe:	0f 84 b4 09 00 00    	je     94b8 <f12+0x1338>
    8b04:	80 f9 01             	cmp    $0x1,%cl
    8b07:	75 25                	jne    8b2e <f12+0x9ae>
    8b09:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8b0c:	0f b7 c0             	movzwl %ax,%eax
    8b0f:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8b12:	48 0f af c1          	imul   %rcx,%rax
    8b16:	48 c1 e8 20          	shr    $0x20,%rax
    8b1a:	48 39 d0             	cmp    %rdx,%rax
    8b1d:	73 0f                	jae    8b2e <f12+0x9ae>
    8b1f:	48 01 c3             	add    %rax,%rbx
    8b22:	80 3b ff             	cmpb   $0xff,(%rbx)
    8b25:	0f 84 4f 0b 00 00    	je     967a <f12+0x14fa>
    8b2b:	c6 03 01             	movb   $0x1,(%rbx)
    8b2e:	4c 3b 6c 24 40       	cmp    0x40(%rsp),%r13
    8b33:	0f 85 12 ac ff ff    	jne    374b <f12.cold>
    8b39:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
    8b3e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    8b43:	48 89 05 2e a9 01 00 	mov    %rax,0x1a92e(%rip)        # 23478 <fwp_cleanups>
    8b4a:	e8 71 e7 ff ff       	call   72c0 <fwp_tape_scope_release>
    8b4f:	49 8b 04 24          	mov    (%r12),%rax
    8b53:	49 89 c5             	mov    %rax,%r13
    8b56:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8b5b:	48 85 c0             	test   %rax,%rax
    8b5e:	0f 88 dc 07 00 00    	js     9340 <f12+0x11c0>
    8b64:	48 8b 15 4d a0 01 00 	mov    0x1a04d(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    8b6b:	4c 89 e0             	mov    %r12,%rax
    8b6e:	48 2b 05 1b a0 01 00 	sub    0x1a01b(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8b75:	48 c1 e2 10          	shl    $0x10,%rdx
    8b79:	48 39 d0             	cmp    %rdx,%rax
    8b7c:	0f 83 be 07 00 00    	jae    9340 <f12+0x11c0>
    8b82:	48 89 c2             	mov    %rax,%rdx
    8b85:	48 c1 ea 10          	shr    $0x10,%rdx
    8b89:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8b8d:	48 8b 15 44 a0 01 00 	mov    0x1a044(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    8b94:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8b98:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8b9c:	48 85 c9             	test   %rcx,%rcx
    8b9f:	0f 84 9b 07 00 00    	je     9340 <f12+0x11c0>
    8ba5:	0f b6 32             	movzbl (%rdx),%esi
    8ba8:	40 80 fe 02          	cmp    $0x2,%sil
    8bac:	0f 84 7e 07 00 00    	je     9330 <f12+0x11b0>
    8bb2:	40 80 fe 01          	cmp    $0x1,%sil
    8bb6:	0f 85 84 07 00 00    	jne    9340 <f12+0x11c0>
    8bbc:	8b 72 18             	mov    0x18(%rdx),%esi
    8bbf:	0f b7 c0             	movzwl %ax,%eax
    8bc2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8bc5:	48 0f af c6          	imul   %rsi,%rax
    8bc9:	48 c1 e8 20          	shr    $0x20,%rax
    8bcd:	48 39 d0             	cmp    %rdx,%rax
    8bd0:	0f 83 6a 07 00 00    	jae    9340 <f12+0x11c0>
    8bd6:	48 01 c1             	add    %rax,%rcx
    8bd9:	80 39 01             	cmpb   $0x1,(%rcx)
    8bdc:	0f 85 5e 07 00 00    	jne    9340 <f12+0x11c0>
    8be2:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
    8be7:	4c 89 e3             	mov    %r12,%rbx
    8bea:	31 ff                	xor    %edi,%edi
    8bec:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8bf1:	f2 0f 10 0d 47 50 00 	movsd  0x5047(%rip),%xmm1        # dc40 <msg.4+0xd0>
    8bf8:	00 
    8bf9:	48 8d 50 08          	lea    0x8(%rax),%rdx
    8bfd:	31 c0                	xor    %eax,%eax
    8bff:	4d 85 ed             	test   %r13,%r13
    8c02:	75 31                	jne    8c35 <f12+0xab5>
    8c04:	eb 4a                	jmp    8c50 <f12+0xad0>
    8c06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8c0d:	00 00 00 
    8c10:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8c14:	0f 88 48 0b 00 00    	js     9762 <f12+0x15e2>
    8c1a:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    8c1f:	48 83 c0 01          	add    $0x1,%rax
    8c23:	48 83 c2 08          	add    $0x8,%rdx
    8c27:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    8c2b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8c30:	49 39 c5             	cmp    %rax,%r13
    8c33:	74 1b                	je     8c50 <f12+0xad0>
    8c35:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    8c3a:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    8c3f:	79 cf                	jns    8c10 <f12+0xa90>
    8c41:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8c46:	eb c8                	jmp    8c10 <f12+0xa90>
    8c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c4f:	00 
    8c50:	e8 1b f0 ff ff       	call   7c70 <fwp_drop4>
    8c55:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    8c5a:	31 d2                	xor    %edx,%edx
    8c5c:	48 89 c8             	mov    %rcx,%rax
    8c5f:	48 85 c9             	test   %rcx,%rcx
    8c62:	0f 84 ad 09 00 00    	je     9615 <f12+0x1495>
    8c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c6f:	00 
    8c70:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c74:	48 83 c2 01          	add    $0x1,%rdx
    8c78:	48 85 c0             	test   %rax,%rax
    8c7b:	75 f3                	jne    8c70 <f12+0xaf0>
    8c7d:	48 8b 03             	mov    (%rbx),%rax
    8c80:	49 89 c7             	mov    %rax,%r15
    8c83:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8c88:	48 85 c0             	test   %rax,%rax
    8c8b:	0f 88 04 06 00 00    	js     9295 <f12+0x1115>
    8c91:	48 8b 0d 20 9f 01 00 	mov    0x19f20(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    8c98:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    8c9d:	48 2b 05 ec 9e 01 00 	sub    0x19eec(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    8ca4:	48 c1 e1 10          	shl    $0x10,%rcx
    8ca8:	48 39 c8             	cmp    %rcx,%rax
    8cab:	0f 83 e4 05 00 00    	jae    9295 <f12+0x1115>
    8cb1:	48 89 c1             	mov    %rax,%rcx
    8cb4:	48 c1 e9 10          	shr    $0x10,%rcx
    8cb8:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    8cbc:	48 8b 0d 15 9f 01 00 	mov    0x19f15(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    8cc3:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    8cc7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8ccb:	48 85 ff             	test   %rdi,%rdi
    8cce:	0f 84 c1 05 00 00    	je     9295 <f12+0x1115>
    8cd4:	0f b6 0e             	movzbl (%rsi),%ecx
    8cd7:	80 f9 02             	cmp    $0x2,%cl
    8cda:	0f 84 a0 05 00 00    	je     9280 <f12+0x1100>
    8ce0:	80 f9 01             	cmp    $0x1,%cl
    8ce3:	0f 85 a0 05 00 00    	jne    9289 <f12+0x1109>
    8ce9:	8b 4e 18             	mov    0x18(%rsi),%ecx
    8cec:	0f b7 c0             	movzwl %ax,%eax
    8cef:	48 0f af c1          	imul   %rcx,%rax
    8cf3:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    8cf6:	48 c1 e8 20          	shr    $0x20,%rax
    8cfa:	48 39 c8             	cmp    %rcx,%rax
    8cfd:	0f 83 86 05 00 00    	jae    9289 <f12+0x1109>
    8d03:	48 01 c7             	add    %rax,%rdi
    8d06:	80 3f 01             	cmpb   $0x1,(%rdi)
    8d09:	0f 85 7a 05 00 00    	jne    9289 <f12+0x1109>
    8d0f:	4c 39 fa             	cmp    %r15,%rdx
    8d12:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8d16:	4c 89 fd             	mov    %r15,%rbp
    8d19:	4d 85 ff             	test   %r15,%r15
    8d1c:	0f 84 51 0a 00 00    	je     9773 <f12+0x15f3>
    8d22:	c7 44 24 40 01 00 00 	movl   $0x1,0x40(%rsp)
    8d29:	00 
    8d2a:	4c 8d 63 08          	lea    0x8(%rbx),%r12
    8d2e:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8d33:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8d38:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    8d3f:	00 
    8d40:	31 c0                	xor    %eax,%eax
    8d42:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8d46:	eb 55                	jmp    8d9d <f12+0xc1d>
    8d48:	90                   	nop
    8d49:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d50:	00 00 00 00 
    8d54:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d5b:	00 00 00 00 
    8d5f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d66:	00 00 00 00 
    8d6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d71:	00 00 00 00 
    8d75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8d7c:	00 00 00 00 
    8d80:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8d85:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    8d8a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8d90:	48 83 c0 08          	add    $0x8,%rax
    8d94:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8d98:	49 39 c0             	cmp    %rax,%r8
    8d9b:	74 1b                	je     8db8 <f12+0xc38>
    8d9d:	48 89 fe             	mov    %rdi,%rsi
    8da0:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8da4:	79 da                	jns    8d80 <f12+0xc00>
    8da6:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
    8dab:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8daf:	eb cf                	jmp    8d80 <f12+0xc00>
    8db1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8db8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    8dbd:	48 85 d2             	test   %rdx,%rdx
    8dc0:	0f 84 77 09 00 00    	je     973d <f12+0x15bd>
    8dc6:	4c 8b 05 eb 9d 01 00 	mov    0x19deb(%rip),%r8        # 22bb8 <fwp_heap+0x13d8>
    8dcd:	4c 8b 15 bc 9d 01 00 	mov    0x19dbc(%rip),%r10        # 22b90 <fwp_heap+0x13b0>
    8dd4:	45 31 ff             	xor    %r15d,%r15d
    8dd7:	4c 8b 1d fa 9d 01 00 	mov    0x19dfa(%rip),%r11        # 22bd8 <fwp_heap+0x13f8>
    8dde:	49 c1 e0 10          	shl    $0x10,%r8
    8de2:	eb 1a                	jmp    8dfe <f12+0xc7e>
    8de4:	0f 1f 40 00          	nopl   0x0(%rax)
    8de8:	49 83 c7 01          	add    $0x1,%r15
    8dec:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8df0:	49 39 ef             	cmp    %rbp,%r15
    8df3:	0f 83 37 02 00 00    	jae    9030 <f12+0xeb0>
    8df9:	48 85 d2             	test   %rdx,%rdx
    8dfc:	74 52                	je     8e50 <f12+0xcd0>
    8dfe:	48 89 d0             	mov    %rdx,%rax
    8e01:	4c 29 d0             	sub    %r10,%rax
    8e04:	4c 39 c0             	cmp    %r8,%rax
    8e07:	73 47                	jae    8e50 <f12+0xcd0>
    8e09:	48 89 c6             	mov    %rax,%rsi
    8e0c:	48 c1 ee 10          	shr    $0x10,%rsi
    8e10:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    8e14:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    8e18:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    8e1c:	48 85 ff             	test   %rdi,%rdi
    8e1f:	74 2f                	je     8e50 <f12+0xcd0>
    8e21:	0f b6 1e             	movzbl (%rsi),%ebx
    8e24:	80 fb 02             	cmp    $0x2,%bl
    8e27:	0f 84 e3 01 00 00    	je     9010 <f12+0xe90>
    8e2d:	80 fb 01             	cmp    $0x1,%bl
    8e30:	75 1e                	jne    8e50 <f12+0xcd0>
    8e32:	8b 5e 18             	mov    0x18(%rsi),%ebx
    8e35:	0f b7 c0             	movzwl %ax,%eax
    8e38:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8e3b:	48 0f af c3          	imul   %rbx,%rax
    8e3f:	48 c1 e8 20          	shr    $0x20,%rax
    8e43:	48 39 f0             	cmp    %rsi,%rax
    8e46:	73 08                	jae    8e50 <f12+0xcd0>
    8e48:	48 01 c7             	add    %rax,%rdi
    8e4b:	80 3f 01             	cmpb   $0x1,(%rdi)
    8e4e:	74 98                	je     8de8 <f12+0xc68>
    8e50:	49 39 ef             	cmp    %rbp,%r15
    8e53:	0f 83 d7 01 00 00    	jae    9030 <f12+0xeb0>
    8e59:	4c 8b 2d 80 4d 00 00 	mov    0x4d80(%rip),%r13        # dbe0 <msg.4+0x70>
    8e60:	45 31 f6             	xor    %r14d,%r14d
    8e63:	48 8d 1d 76 89 01 00 	lea    0x18976(%rip),%rbx        # 217e0 <fwp_heap>
    8e6a:	e9 19 01 00 00       	jmp    8f88 <f12+0xe08>
    8e6f:	90                   	nop
    8e70:	49 8b 10             	mov    (%r8),%rdx
    8e73:	48 f7 d2             	not    %rdx
    8e76:	48 89 10             	mov    %rdx,(%rax)
    8e79:	49 83 fb 18          	cmp    $0x18,%r11
    8e7d:	76 3b                	jbe    8eba <f12+0xd3a>
    8e7f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8e83:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8e87:	31 f6                	xor    %esi,%esi
    8e89:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
    8e8e:	48 c1 e8 03          	shr    $0x3,%rax
    8e92:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    8e97:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8e9e:	00 
    8e9f:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    8ea5:	e8 16 a6 ff ff       	call   34c0 <memset@plt>
    8eaa:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    8eaf:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    8eb4:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    8eba:	4c 89 d8             	mov    %r11,%rax
    8ebd:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8ec4:	0f 82 93 08 00 00    	jb     975d <f12+0x15dd>
    8eca:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8ed1:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8ed8:	73 07                	jae    8ee1 <f12+0xd61>
    8eda:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8ee1:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8ee5:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8eea:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8ef1:	00 
    8ef2:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8ef9:	00 
    8efa:	66 49 0f 6e ee       	movq   %r14,%xmm5
    8eff:	4d 89 28             	mov    %r13,(%r8)
    8f02:	4c 89 c0             	mov    %r8,%rax
    8f05:	4d 89 c6             	mov    %r8,%r14
    8f08:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    8f0c:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8f11:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8f18:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8f1f:	48 c1 e2 10          	shl    $0x10,%rdx
    8f23:	48 39 d0             	cmp    %rdx,%rax
    8f26:	73 57                	jae    8f7f <f12+0xdff>
    8f28:	48 89 c2             	mov    %rax,%rdx
    8f2b:	48 c1 ea 10          	shr    $0x10,%rdx
    8f2f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8f33:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8f3a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8f3e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8f42:	48 85 d2             	test   %rdx,%rdx
    8f45:	74 38                	je     8f7f <f12+0xdff>
    8f47:	0f b6 3e             	movzbl (%rsi),%edi
    8f4a:	40 80 ff 02          	cmp    $0x2,%dil
    8f4e:	0f 84 7c 01 00 00    	je     90d0 <f12+0xf50>
    8f54:	40 80 ff 01          	cmp    $0x1,%dil
    8f58:	75 25                	jne    8f7f <f12+0xdff>
    8f5a:	8b 7e 18             	mov    0x18(%rsi),%edi
    8f5d:	0f b7 c0             	movzwl %ax,%eax
    8f60:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8f63:	48 0f af c7          	imul   %rdi,%rax
    8f67:	48 c1 e8 20          	shr    $0x20,%rax
    8f6b:	48 39 f0             	cmp    %rsi,%rax
    8f6e:	73 0f                	jae    8f7f <f12+0xdff>
    8f70:	48 01 c2             	add    %rax,%rdx
    8f73:	80 3a ff             	cmpb   $0xff,(%rdx)
    8f76:	0f 84 74 04 00 00    	je     93f0 <f12+0x1270>
    8f7c:	c6 02 01             	movb   $0x1,(%rdx)
    8f7f:	49 39 ef             	cmp    %rbp,%r15
    8f82:	0f 83 68 01 00 00    	jae    90f0 <f12+0xf70>
    8f88:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8f8e:	48 83 ed 01          	sub    $0x1,%rbp
    8f92:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8f98:	85 f6                	test   %esi,%esi
    8f9a:	74 4c                	je     8fe8 <f12+0xe68>
    8f9c:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8fa3:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8faa:	00 
    8fab:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8faf:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8fb3:	4c 8b 00             	mov    (%rax),%r8
    8fb6:	4d 85 c0             	test   %r8,%r8
    8fb9:	0f 85 b1 fe ff ff    	jne    8e70 <f12+0xcf0>
    8fbf:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8fc3:	4d 85 c0             	test   %r8,%r8
    8fc6:	74 20                	je     8fe8 <f12+0xe68>
    8fc8:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8fcc:	4c 29 c2             	sub    %r8,%rdx
    8fcf:	4c 39 da             	cmp    %r11,%rdx
    8fd2:	72 14                	jb     8fe8 <f12+0xe68>
    8fd4:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8fd8:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8fdc:	e9 98 fe ff ff       	jmp    8e79 <f12+0xcf9>
    8fe1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8fe8:	31 f6                	xor    %esi,%esi
    8fea:	bf 18 00 00 00       	mov    $0x18,%edi
    8fef:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    8ff5:	e8 96 cc ff ff       	call   5c90 <fwp_heap_alloc>
    8ffa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9000:	49 89 c0             	mov    %rax,%r8
    9003:	e9 f2 fe ff ff       	jmp    8efa <f12+0xd7a>
    9008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    900f:	00 
    9010:	66 85 c0             	test   %ax,%ax
    9013:	0f 84 32 fe ff ff    	je     8e4b <f12+0xccb>
    9019:	49 39 ef             	cmp    %rbp,%r15
    901c:	0f 82 37 fe ff ff    	jb     8e59 <f12+0xcd9>
    9022:	0f 1f 00             	nopl   (%rax)
    9025:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    902c:	00 00 00 00 
    9030:	45 31 f6             	xor    %r14d,%r14d
    9033:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9038:	4c 89 e2             	mov    %r12,%rdx
    903b:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    903f:	90                   	nop
    9040:	48 8b 0a             	mov    (%rdx),%rcx
    9043:	48 83 c2 08          	add    $0x8,%rdx
    9047:	48 89 c6             	mov    %rax,%rsi
    904a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    904e:	48 8b 40 10          	mov    0x10(%rax),%rax
    9052:	48 39 d7             	cmp    %rdx,%rdi
    9055:	75 e9                	jne    9040 <f12+0xec0>
    9057:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
    905b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    905f:	85 c9                	test   %ecx,%ecx
    9061:	0f 84 69 04 00 00    	je     94d0 <f12+0x1350>
    9067:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    906c:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9071:	45 31 e4             	xor    %r12d,%r12d
    9074:	90                   	nop
    9075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    907c:	00 00 00 00 
    9080:	4c 89 e7             	mov    %r12,%rdi
    9083:	e8 08 c7 ff ff       	call   5790 <fwp_mem_free>
    9088:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
    908d:	e8 de eb ff ff       	call   7c70 <fwp_drop4>
    9092:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9097:	e8 04 dc ff ff       	call   6ca0 <fwp_drop0>
    909c:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
    90a3:	00 
    90a4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    90ab:	00 00 
    90ad:	0f 85 ec 06 00 00    	jne    979f <f12+0x161f>
    90b3:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
    90ba:	4c 89 f0             	mov    %r14,%rax
    90bd:	5b                   	pop    %rbx
    90be:	5d                   	pop    %rbp
    90bf:	41 5c                	pop    %r12
    90c1:	41 5d                	pop    %r13
    90c3:	41 5e                	pop    %r14
    90c5:	41 5f                	pop    %r15
    90c7:	c3                   	ret
    90c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    90cf:	00 
    90d0:	66 85 c0             	test   %ax,%ax
    90d3:	0f 84 9a fe ff ff    	je     8f73 <f12+0xdf3>
    90d9:	49 39 ef             	cmp    %rbp,%r15
    90dc:	0f 82 a6 fe ff ff    	jb     8f88 <f12+0xe08>
    90e2:	0f 1f 00             	nopl   (%rax)
    90e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    90ec:	00 00 00 00 
    90f0:	4d 85 ff             	test   %r15,%r15
    90f3:	0f 85 3a ff ff ff    	jne    9033 <f12+0xeb3>
    90f9:	8b 54 24 40          	mov    0x40(%rsp),%edx
    90fd:	85 d2                	test   %edx,%edx
    90ff:	4d 0f 45 e7          	cmovne %r15,%r12
    9103:	66 90                	xchg   %ax,%ax
    9105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    910c:	00 00 00 00 
    9110:	48 85 ed             	test   %rbp,%rbp
    9113:	0f 84 67 ff ff ff    	je     9080 <f12+0xf00>
    9119:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    911f:	48 83 ed 01          	sub    $0x1,%rbp
    9123:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    9129:	85 c0                	test   %eax,%eax
    912b:	0f 84 b7 05 00 00    	je     96e8 <f12+0x1568>
    9131:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    9138:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    913f:	00 
    9140:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    9144:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    9148:	4c 8b 38             	mov    (%rax),%r15
    914b:	4d 85 ff             	test   %r15,%r15
    914e:	0f 84 6c 05 00 00    	je     96c0 <f12+0x1540>
    9154:	49 8b 17             	mov    (%r15),%rdx
    9157:	48 f7 d2             	not    %rdx
    915a:	48 89 10             	mov    %rdx,(%rax)
    915d:	49 83 f8 18          	cmp    $0x18,%r8
    9161:	76 31                	jbe    9194 <f12+0x1014>
    9163:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    9167:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    916b:	31 f6                	xor    %esi,%esi
    916d:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    9172:	48 c1 e8 03          	shr    $0x3,%rax
    9176:	66 0f d6 44 24 20    	movq   %xmm0,0x20(%rsp)
    917c:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    9183:	00 
    9184:	e8 37 a3 ff ff       	call   34c0 <memset@plt>
    9189:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    918e:	f3 0f 7e 44 24 20    	movq   0x20(%rsp),%xmm0
    9194:	4c 89 c0             	mov    %r8,%rax
    9197:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    919e:	0f 82 b9 05 00 00    	jb     975d <f12+0x15dd>
    91a4:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    91ab:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    91b2:	73 07                	jae    91bb <f12+0x103b>
    91b4:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    91bb:	66 0f ef c9          	pxor   %xmm1,%xmm1
    91bf:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    91c4:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    91cb:	00 
    91cc:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    91d3:	00 
    91d4:	66 49 0f 6e f6       	movq   %r14,%xmm6
    91d9:	4d 89 2f             	mov    %r13,(%r15)
    91dc:	4c 89 f8             	mov    %r15,%rax
    91df:	4d 89 fe             	mov    %r15,%r14
    91e2:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    91e6:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    91eb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    91f2:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    91f9:	48 c1 e2 10          	shl    $0x10,%rdx
    91fd:	48 39 d0             	cmp    %rdx,%rax
    9200:	0f 83 0a ff ff ff    	jae    9110 <f12+0xf90>
    9206:	48 89 c2             	mov    %rax,%rdx
    9209:	48 c1 ea 10          	shr    $0x10,%rdx
    920d:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    9211:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    9218:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    921c:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    9220:	4d 85 ff             	test   %r15,%r15
    9223:	0f 84 e7 fe ff ff    	je     9110 <f12+0xf90>
    9229:	0f b6 32             	movzbl (%rdx),%esi
    922c:	40 80 fe 02          	cmp    $0x2,%sil
    9230:	0f 84 da 04 00 00    	je     9710 <f12+0x1590>
    9236:	40 80 fe 01          	cmp    $0x1,%sil
    923a:	0f 85 d0 fe ff ff    	jne    9110 <f12+0xf90>
    9240:	8b 72 18             	mov    0x18(%rdx),%esi
    9243:	0f b7 c0             	movzwl %ax,%eax
    9246:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9249:	48 0f af c6          	imul   %rsi,%rax
    924d:	48 c1 e8 20          	shr    $0x20,%rax
    9251:	48 39 d0             	cmp    %rdx,%rax
    9254:	0f 83 b6 fe ff ff    	jae    9110 <f12+0xf90>
    925a:	49 01 c7             	add    %rax,%r15
    925d:	41 80 3f ff          	cmpb   $0xff,(%r15)
    9261:	0f 84 c9 04 00 00    	je     9730 <f12+0x15b0>
    9267:	41 c6 07 01          	movb   $0x1,(%r15)
    926b:	48 85 ed             	test   %rbp,%rbp
    926e:	0f 85 a5 fe ff ff    	jne    9119 <f12+0xf99>
    9274:	e9 07 fe ff ff       	jmp    9080 <f12+0xf00>
    9279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9280:	66 85 c0             	test   %ax,%ax
    9283:	0f 84 7d fa ff ff    	je     8d06 <f12+0xb86>
    9289:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    928f:	0f 84 14 03 00 00    	je     95a9 <f12+0x1429>
    9295:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    929a:	31 ed                	xor    %ebp,%ebp
    929c:	0f 1f 40 00          	nopl   0x0(%rax)
    92a0:	48 8b 40 10          	mov    0x10(%rax),%rax
    92a4:	48 89 ea             	mov    %rbp,%rdx
    92a7:	48 83 c5 01          	add    $0x1,%rbp
    92ab:	48 85 c0             	test   %rax,%rax
    92ae:	75 f0                	jne    92a0 <f12+0x1120>
    92b0:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    92b7:	ff ff 1f 
    92ba:	48 39 e8             	cmp    %rbp,%rax
    92bd:	0f 82 d0 04 00 00    	jb     9793 <f12+0x1613>
    92c3:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    92ca:	00 
    92cb:	be 02 00 00 00       	mov    $0x2,%esi
    92d0:	e8 bb c9 ff ff       	call   5c90 <fwp_heap_alloc>
    92d5:	49 39 ef             	cmp    %rbp,%r15
    92d8:	49 89 c4             	mov    %rax,%r12
    92db:	48 89 c2             	mov    %rax,%rdx
    92de:	49 0f 46 ef          	cmovbe %r15,%rbp
    92e2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    92e7:	0f 1f 00             	nopl   (%rax)
    92ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92f1:	00 00 00 00 
    92f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    92fc:	00 00 00 00 
    9300:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9304:	48 83 c2 08          	add    $0x8,%rdx
    9308:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    930c:	48 8b 40 10          	mov    0x10(%rax),%rax
    9310:	48 85 c0             	test   %rax,%rax
    9313:	75 eb                	jne    9300 <f12+0x1180>
    9315:	48 85 ed             	test   %rbp,%rbp
    9318:	0f 84 9d 02 00 00    	je     95bb <f12+0x143b>
    931e:	c7 44 24 40 00 00 00 	movl   $0x0,0x40(%rsp)
    9325:	00 
    9326:	e9 03 fa ff ff       	jmp    8d2e <f12+0xbae>
    932b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9330:	66 85 c0             	test   %ax,%ax
    9333:	0f 84 a0 f8 ff ff    	je     8bd9 <f12+0xa59>
    9339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9340:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    9347:	ff ff 1f 
    934a:	4c 39 e8             	cmp    %r13,%rax
    934d:	0f 82 28 04 00 00    	jb     977b <f12+0x15fb>
    9353:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    935a:	00 
    935b:	be 01 00 00 00       	mov    $0x1,%esi
    9360:	e8 2b c9 ff ff       	call   5c90 <fwp_heap_alloc>
    9365:	4c 89 28             	mov    %r13,(%rax)
    9368:	48 8b 15 49 98 01 00 	mov    0x19849(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    936f:	48 89 c3             	mov    %rax,%rbx
    9372:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    9377:	48 2b 05 12 98 01 00 	sub    0x19812(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    937e:	48 c1 e2 10          	shl    $0x10,%rdx
    9382:	48 39 d0             	cmp    %rdx,%rax
    9385:	73 57                	jae    93de <f12+0x125e>
    9387:	48 89 c2             	mov    %rax,%rdx
    938a:	48 c1 ea 10          	shr    $0x10,%rdx
    938e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9392:	48 8b 15 3f 98 01 00 	mov    0x1983f(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9399:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    939d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    93a1:	4d 85 ff             	test   %r15,%r15
    93a4:	74 38                	je     93de <f12+0x125e>
    93a6:	0f b6 0a             	movzbl (%rdx),%ecx
    93a9:	80 f9 02             	cmp    $0x2,%cl
    93ac:	0f 84 16 02 00 00    	je     95c8 <f12+0x1448>
    93b2:	80 f9 01             	cmp    $0x1,%cl
    93b5:	75 27                	jne    93de <f12+0x125e>
    93b7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    93ba:	0f b7 c0             	movzwl %ax,%eax
    93bd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    93c0:	48 0f af c1          	imul   %rcx,%rax
    93c4:	48 c1 e8 20          	shr    $0x20,%rax
    93c8:	48 39 d0             	cmp    %rdx,%rax
    93cb:	73 11                	jae    93de <f12+0x125e>
    93cd:	49 01 c7             	add    %rax,%r15
    93d0:	41 80 3f ff          	cmpb   $0xff,(%r15)
    93d4:	0f 84 ad 02 00 00    	je     9687 <f12+0x1507>
    93da:	41 c6 07 01          	movb   $0x1,(%r15)
    93de:	4c 89 e7             	mov    %r12,%rdi
    93e1:	e9 06 f8 ff ff       	jmp    8bec <f12+0xa6c>
    93e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93ed:	00 00 00 
    93f0:	48 89 d7             	mov    %rdx,%rdi
    93f3:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
    93f8:	e8 53 c1 ff ff       	call   5550 <fwp_rc_forget_slot>
    93fd:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9402:	e9 75 fb ff ff       	jmp    8f7c <f12+0xdfc>
    9407:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    940e:	00 00 
    9410:	48 8d 3d c9 dd ff ff 	lea    -0x2237(%rip),%rdi        # 71e0 <fwp_tape_finish>
    9417:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    941d:	e8 fe 37 00 00       	call   cc20 <atexit>
    9422:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9428:	85 c0                	test   %eax,%eax
    942a:	75 5b                	jne    9487 <f12+0x1307>
    942c:	c7 05 4a 7c 00 00 01 	movl   $0x1,0x7c4a(%rip)        # 11080 <registered_finish.0>
    9433:	00 00 00 
    9436:	e9 7b ee ff ff       	jmp    82b6 <f12+0x136>
    943b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9440:	66 85 c0             	test   %ax,%ax
    9443:	0f 85 1b ee ff ff    	jne    8264 <f12+0xe4>
    9449:	e9 02 ee ff ff       	jmp    8250 <f12+0xd0>
    944e:	66 90                	xchg   %ax,%ax
    9450:	49 89 ec             	mov    %rbp,%r12
    9453:	4c 39 f5             	cmp    %r14,%rbp
    9456:	0f 8f 91 f4 ff ff    	jg     88ed <f12+0x76d>
    945c:	4d 85 e4             	test   %r12,%r12
    945f:	0f 84 f3 f4 ff ff    	je     8958 <f12+0x7d8>
    9465:	48 85 db             	test   %rbx,%rbx
    9468:	0f 85 e1 f4 ff ff    	jne    894f <f12+0x7cf>
    946e:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
    9475:	00 
    9476:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
    947b:	48 89 05 f6 9f 01 00 	mov    %rax,0x19ff6(%rip)        # 23478 <fwp_cleanups>
    9482:	e8 e9 bb ff ff       	call   5070 <fwp_tape_buffers_release>
    9487:	48 8b 0d d2 7b 00 00 	mov    0x7bd2(%rip),%rcx        # 11060 <stderr@GLIBC_2.2.5>
    948e:	ba 13 00 00 00       	mov    $0x13,%edx
    9493:	be 01 00 00 00       	mov    $0x1,%esi
    9498:	48 8d 3d 69 3b 00 00 	lea    0x3b69(%rip),%rdi        # d008 <_IO_stdin_used+0x8>
    949f:	e8 dc a1 ff ff       	call   3680 <fwrite@plt>
    94a4:	31 ff                	xor    %edi,%edi
    94a6:	e8 15 a1 ff ff       	call   35c0 <fflush@plt>
    94ab:	bf 66 00 00 00       	mov    $0x66,%edi
    94b0:	e8 eb a1 ff ff       	call   36a0 <_Exit@plt>
    94b5:	0f 1f 00             	nopl   (%rax)
    94b8:	66 85 c0             	test   %ax,%ax
    94bb:	0f 85 6d f6 ff ff    	jne    8b2e <f12+0x9ae>
    94c1:	e9 5c f6 ff ff       	jmp    8b22 <f12+0x9a2>
    94c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    94cd:	00 00 00 
    94d0:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    94d5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    94da:	e9 a1 fb ff ff       	jmp    9080 <f12+0xf00>
    94df:	90                   	nop
    94e0:	66 0f 6f 0d d8 7b 01 	movdqa 0x17bd8(%rip),%xmm1        # 210c0 <fwp_tape_workspace>
    94e7:	00 
    94e8:	48 c7 05 b5 7b 01 00 	movq   $0x0,0x17bb5(%rip)        # 210a8 <fwp_tape_cached_bytes>
    94ef:	00 00 00 00 
    94f3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    94f8:	48 8b 05 e1 7b 01 00 	mov    0x17be1(%rip),%rax        # 210e0 <fwp_tape_workspace+0x20>
    94ff:	66 0f 6f 0d c9 7b 01 	movdqa 0x17bc9(%rip),%xmm1        # 210d0 <fwp_tape_workspace+0x10>
    9506:	00 
    9507:	49 89 46 40          	mov    %rax,0x40(%r14)
    950b:	48 8b 05 d6 7b 01 00 	mov    0x17bd6(%rip),%rax        # 210e8 <fwp_tape_workspace+0x28>
    9512:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    9517:	66 0f ef c9          	pxor   %xmm1,%xmm1
    951b:	49 89 46 18          	mov    %rax,0x18(%r14)
    951f:	48 8b 05 ca 7b 01 00 	mov    0x17bca(%rip),%rax        # 210f0 <fwp_tape_workspace+0x30>
    9526:	0f 29 0d 93 7b 01 00 	movaps %xmm1,0x17b93(%rip)        # 210c0 <fwp_tape_workspace>
    952d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9531:	0f 29 0d 98 7b 01 00 	movaps %xmm1,0x17b98(%rip)        # 210d0 <fwp_tape_workspace+0x10>
    9538:	48 c7 05 ad 7b 01 00 	movq   $0x0,0x17bad(%rip)        # 210f0 <fwp_tape_workspace+0x30>
    953f:	00 00 00 00 
    9543:	0f 29 0d 96 7b 01 00 	movaps %xmm1,0x17b96(%rip)        # 210e0 <fwp_tape_workspace+0x20>
    954a:	e9 8d ee ff ff       	jmp    83dc <f12+0x25c>
    954f:	90                   	nop
    9550:	48 85 db             	test   %rbx,%rbx
    9553:	0f 84 15 ff ff ff    	je     946e <f12+0x12ee>
    9559:	4d 89 e6             	mov    %r12,%r14
    955c:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    9563:	00 
    9564:	31 f6                	xor    %esi,%esi
    9566:	48 89 df             	mov    %rbx,%rdi
    9569:	4c 89 54 24 48       	mov    %r10,0x48(%rsp)
    956e:	49 29 ee             	sub    %rbp,%r14
    9571:	e8 4a 9f ff ff       	call   34c0 <memset@plt>
    9576:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
    957b:	e9 ed f3 ff ff       	jmp    896d <f12+0x7ed>
    9580:	49 89 ec             	mov    %rbp,%r12
    9583:	e9 65 f3 ff ff       	jmp    88ed <f12+0x76d>
    9588:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    958f:	00 
    9590:	4c 8d 2c 1b          	lea    (%rbx,%rbx,1),%r13
    9594:	b8 ff ff 00 00       	mov    $0xffff,%eax
    9599:	49 39 c5             	cmp    %rax,%r13
    959c:	4c 0f 4f e8          	cmovg  %rax,%r13
    95a0:	49 6b f5 68          	imul   $0x68,%r13,%rsi
    95a4:	e9 88 ed ff ff       	jmp    8331 <f12+0x1b1>
    95a9:	be 02 00 00 00       	mov    $0x2,%esi
    95ae:	bf 08 00 00 00       	mov    $0x8,%edi
    95b3:	e8 d8 c6 ff ff       	call   5c90 <fwp_heap_alloc>
    95b8:	49 89 c4             	mov    %rax,%r12
    95bb:	45 31 f6             	xor    %r14d,%r14d
    95be:	e9 bd fa ff ff       	jmp    9080 <f12+0xf00>
    95c3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    95c8:	66 85 c0             	test   %ax,%ax
    95cb:	0f 85 0d fe ff ff    	jne    93de <f12+0x125e>
    95d1:	e9 fa fd ff ff       	jmp    93d0 <f12+0x1250>
    95d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    95dd:	00 00 00 
    95e0:	4d 85 e4             	test   %r12,%r12
    95e3:	0f 85 8e ef ff ff    	jne    8577 <f12+0x3f7>
    95e9:	e9 11 f0 ff ff       	jmp    85ff <f12+0x47f>
    95ee:	66 90                	xchg   %ax,%ax
    95f0:	be 08 00 00 00       	mov    $0x8,%esi
    95f5:	4c 89 f7             	mov    %r14,%rdi
    95f8:	e8 23 9f ff ff       	call   3520 <calloc@plt>
    95fd:	48 89 c3             	mov    %rax,%rbx
    9600:	e9 31 f3 ff ff       	jmp    8936 <f12+0x7b6>
    9605:	31 ff                	xor    %edi,%edi
    9607:	e8 44 ac ff ff       	call   4250 <descent_phase_step>
    960c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9610:	e9 91 ec ff ff       	jmp    82a6 <f12+0x126>
    9615:	48 8b 0b             	mov    (%rbx),%rcx
    9618:	48 85 c9             	test   %rcx,%rcx
    961b:	78 8c                	js     95a9 <f12+0x1429>
    961d:	48 8b 35 94 95 01 00 	mov    0x19594(%rip),%rsi        # 22bb8 <fwp_heap+0x13d8>
    9624:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    9629:	48 2b 05 60 95 01 00 	sub    0x19560(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9630:	48 c1 e6 10          	shl    $0x10,%rsi
    9634:	48 39 f0             	cmp    %rsi,%rax
    9637:	0f 83 6c ff ff ff    	jae    95a9 <f12+0x1429>
    963d:	48 89 c6             	mov    %rax,%rsi
    9640:	48 c1 ee 10          	shr    $0x10,%rsi
    9644:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    9648:	48 8b 35 89 95 01 00 	mov    0x19589(%rip),%rsi        # 22bd8 <fwp_heap+0x13f8>
    964f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9653:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    9657:	48 85 ff             	test   %rdi,%rdi
    965a:	0f 84 49 ff ff ff    	je     95a9 <f12+0x1429>
    9660:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9665:	49 89 cf             	mov    %rcx,%r15
    9668:	e9 67 f6 ff ff       	jmp    8cd4 <f12+0xb54>
    966d:	4c 89 f7             	mov    %r14,%rdi
    9670:	e8 db be ff ff       	call   5550 <fwp_rc_forget_slot>
    9675:	e9 f4 ee ff ff       	jmp    856e <f12+0x3ee>
    967a:	48 89 df             	mov    %rbx,%rdi
    967d:	e8 ce be ff ff       	call   5550 <fwp_rc_forget_slot>
    9682:	e9 a4 f4 ff ff       	jmp    8b2b <f12+0x9ab>
    9687:	4c 89 ff             	mov    %r15,%rdi
    968a:	e8 c1 be ff ff       	call   5550 <fwp_rc_forget_slot>
    968f:	e9 46 fd ff ff       	jmp    93da <f12+0x125a>
    9694:	e8 97 bd ff ff       	call   5430 <fwp_rc_wide_dup>
    9699:	e9 c6 eb ff ff       	jmp    8264 <f12+0xe4>
    969e:	4d 89 e6             	mov    %r12,%r14
    96a1:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    96a8:	00 
    96a9:	31 f6                	xor    %esi,%esi
    96ab:	48 89 df             	mov    %rbx,%rdi
    96ae:	4d 8d 6c 24 ff       	lea    -0x1(%r12),%r13
    96b3:	49 29 ee             	sub    %rbp,%r14
    96b6:	e8 05 9e ff ff       	call   34c0 <memset@plt>
    96bb:	e9 a5 f2 ff ff       	jmp    8965 <f12+0x7e5>
    96c0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    96c4:	4d 85 ff             	test   %r15,%r15
    96c7:	74 1f                	je     96e8 <f12+0x1568>
    96c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    96cd:	4c 29 fa             	sub    %r15,%rdx
    96d0:	4c 39 c2             	cmp    %r8,%rdx
    96d3:	72 13                	jb     96e8 <f12+0x1568>
    96d5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    96d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    96dd:	e9 7b fa ff ff       	jmp    915d <f12+0xfdd>
    96e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96e8:	31 f6                	xor    %esi,%esi
    96ea:	bf 18 00 00 00       	mov    $0x18,%edi
    96ef:	66 0f d6 44 24 10    	movq   %xmm0,0x10(%rsp)
    96f5:	e8 96 c5 ff ff       	call   5c90 <fwp_heap_alloc>
    96fa:	f3 0f 7e 44 24 10    	movq   0x10(%rsp),%xmm0
    9700:	49 89 c7             	mov    %rax,%r15
    9703:	e9 cc fa ff ff       	jmp    91d4 <f12+0x1054>
    9708:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    970f:	00 
    9710:	66 85 c0             	test   %ax,%ax
    9713:	0f 85 f7 f9 ff ff    	jne    9110 <f12+0xf90>
    9719:	41 80 3f ff          	cmpb   $0xff,(%r15)
    971d:	0f 85 44 fb ff ff    	jne    9267 <f12+0x10e7>
    9723:	66 90                	xchg   %ax,%ax
    9725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    972c:	00 00 00 00 
    9730:	4c 89 ff             	mov    %r15,%rdi
    9733:	e8 18 be ff ff       	call   5550 <fwp_rc_forget_slot>
    9738:	e9 2a fb ff ff       	jmp    9267 <f12+0x10e7>
    973d:	45 31 ff             	xor    %r15d,%r15d
    9740:	e9 14 f7 ff ff       	jmp    8e59 <f12+0xcd9>
    9745:	48 8d 3d 64 41 00 00 	lea    0x4164(%rip),%rdi        # d8b0 <_IO_stdin_used+0x8b0>
    974c:	e8 9f ac ff ff       	call   43f0 <fwp_trap>
    9751:	48 8d 3d 0f 3a 00 00 	lea    0x3a0f(%rip),%rdi        # d167 <_IO_stdin_used+0x167>
    9758:	e8 93 ac ff ff       	call   43f0 <fwp_trap>
    975d:	e8 4e a5 ff ff       	call   3cb0 <fwp_heap_oom>
    9762:	48 8d 3d 4f 42 00 00 	lea    0x424f(%rip),%rdi        # d9b8 <_IO_stdin_used+0x9b8>
    9769:	e8 82 ac ff ff       	call   43f0 <fwp_trap>
    976e:	e8 8d 9f ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9773:	45 31 e4             	xor    %r12d,%r12d
    9776:	e9 40 fe ff ff       	jmp    95bb <f12+0x143b>
    977b:	48 8d 3d 36 3a 00 00 	lea    0x3a36(%rip),%rdi        # d1b8 <_IO_stdin_used+0x1b8>
    9782:	e8 69 ac ff ff       	call   43f0 <fwp_trap>
    9787:	48 8d 3d 02 3a 00 00 	lea    0x3a02(%rip),%rdi        # d190 <_IO_stdin_used+0x190>
    978e:	e8 5d ac ff ff       	call   43f0 <fwp_trap>
    9793:	48 8d 3d 10 3a 00 00 	lea    0x3a10(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    979a:	e8 51 ac ff ff       	call   43f0 <fwp_trap>
    979f:	e8 bc 9c ff ff       	call   3460 <__stack_chk_fail@plt>
    97a4:	48 8d 3d 4d 41 00 00 	lea    0x414d(%rip),%rdi        # d8f8 <_IO_stdin_used+0x8f8>
    97ab:	e8 40 ac ff ff       	call   43f0 <fwp_trap>
    97b0:	48 8d 3d d1 41 00 00 	lea    0x41d1(%rip),%rdi        # d988 <_IO_stdin_used+0x988>
    97b7:	e8 34 ac ff ff       	call   43f0 <fwp_trap>
    97bc:	48 8d 3d 95 41 00 00 	lea    0x4195(%rip),%rdi        # d958 <_IO_stdin_used+0x958>
    97c3:	e8 28 ac ff ff       	call   43f0 <fwp_trap>
    97c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97cf:	00 

00000000000097d0 <fwp_owned_entry12>:
    97d0:	f3 0f 1e fa          	endbr64
    97d4:	48 8b 3f             	mov    (%rdi),%rdi
    97d7:	e9 a4 e9 ff ff       	jmp    8180 <f12>
    97dc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000097e0 <e12>:
    97e0:	f3 0f 1e fa          	endbr64
    97e4:	53                   	push   %rbx
    97e5:	48 8b 1f             	mov    (%rdi),%rbx
    97e8:	48 89 df             	mov    %rbx,%rdi
    97eb:	e8 20 d3 ff ff       	call   6b10 <fwp_rc_share>
    97f0:	48 89 df             	mov    %rbx,%rdi
    97f3:	e8 88 e9 ff ff       	call   8180 <f12>
    97f8:	48 89 c3             	mov    %rax,%rbx
    97fb:	48 89 c7             	mov    %rax,%rdi
    97fe:	e8 0d d3 ff ff       	call   6b10 <fwp_rc_share>
    9803:	48 89 d8             	mov    %rbx,%rax
    9806:	5b                   	pop    %rbx
    9807:	c3                   	ret
    9808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    980f:	00 

0000000000009810 <fwp_drop2>:
    9810:	48 8b 0d a1 93 01 00 	mov    0x193a1(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    9817:	48 89 f8             	mov    %rdi,%rax
    981a:	48 2b 05 6f 93 01 00 	sub    0x1936f(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9821:	48 c1 e1 10          	shl    $0x10,%rcx
    9825:	48 39 c8             	cmp    %rcx,%rax
    9828:	0f 83 42 01 00 00    	jae    9970 <fwp_drop2+0x160>
    982e:	48 83 ec 18          	sub    $0x18,%rsp
    9832:	48 89 fa             	mov    %rdi,%rdx
    9835:	4c 8d 05 a4 7f 01 00 	lea    0x17fa4(%rip),%r8        # 217e0 <fwp_heap>
    983c:	48 89 c1             	mov    %rax,%rcx
    983f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9846:	48 c1 e9 10          	shr    $0x10,%rcx
    984a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    984e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9852:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9856:	48 85 c9             	test   %rcx,%rcx
    9859:	74 40                	je     989b <fwp_drop2+0x8b>
    985b:	0f b6 3e             	movzbl (%rsi),%edi
    985e:	40 80 ff 02          	cmp    $0x2,%dil
    9862:	74 3c                	je     98a0 <fwp_drop2+0x90>
    9864:	40 80 ff 01          	cmp    $0x1,%dil
    9868:	75 31                	jne    989b <fwp_drop2+0x8b>
    986a:	8b 7e 18             	mov    0x18(%rsi),%edi
    986d:	0f b7 c0             	movzwl %ax,%eax
    9870:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9873:	48 0f af c7          	imul   %rdi,%rax
    9877:	48 c1 e8 20          	shr    $0x20,%rax
    987b:	48 39 f0             	cmp    %rsi,%rax
    987e:	73 1b                	jae    989b <fwp_drop2+0x8b>
    9880:	48 01 c1             	add    %rax,%rcx
    9883:	0f b6 01             	movzbl (%rcx),%eax
    9886:	84 c0                	test   %al,%al
    9888:	74 11                	je     989b <fwp_drop2+0x8b>
    988a:	3c 01                	cmp    $0x1,%al
    988c:	74 22                	je     98b0 <fwp_drop2+0xa0>
    988e:	3c ff                	cmp    $0xff,%al
    9890:	0f 84 0a 01 00 00    	je     99a0 <fwp_drop2+0x190>
    9896:	83 e8 01             	sub    $0x1,%eax
    9899:	88 01                	mov    %al,(%rcx)
    989b:	48 83 c4 18          	add    $0x18,%rsp
    989f:	c3                   	ret
    98a0:	66 85 c0             	test   %ax,%ax
    98a3:	74 de                	je     9883 <fwp_drop2+0x73>
    98a5:	48 83 c4 18          	add    $0x18,%rsp
    98a9:	c3                   	ret
    98aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98b0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    98b4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    98bb:	48 89 f8             	mov    %rdi,%rax
    98be:	48 c1 e1 10          	shl    $0x10,%rcx
    98c2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    98c9:	48 39 c8             	cmp    %rcx,%rax
    98cc:	73 62                	jae    9930 <fwp_drop2+0x120>
    98ce:	48 89 c1             	mov    %rax,%rcx
    98d1:	48 c1 e9 10          	shr    $0x10,%rcx
    98d5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    98d9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    98dd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    98e1:	48 85 c9             	test   %rcx,%rcx
    98e4:	74 4a                	je     9930 <fwp_drop2+0x120>
    98e6:	44 0f b6 0e          	movzbl (%rsi),%r9d
    98ea:	41 80 f9 02          	cmp    $0x2,%r9b
    98ee:	0f 84 9c 00 00 00    	je     9990 <fwp_drop2+0x180>
    98f4:	41 80 f9 01          	cmp    $0x1,%r9b
    98f8:	75 36                	jne    9930 <fwp_drop2+0x120>
    98fa:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    98fe:	0f b7 c0             	movzwl %ax,%eax
    9901:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9904:	49 0f af c1          	imul   %r9,%rax
    9908:	48 c1 e8 20          	shr    $0x20,%rax
    990c:	48 39 f0             	cmp    %rsi,%rax
    990f:	73 1f                	jae    9930 <fwp_drop2+0x120>
    9911:	48 01 c1             	add    %rax,%rcx
    9914:	0f b6 01             	movzbl (%rcx),%eax
    9917:	84 c0                	test   %al,%al
    9919:	74 15                	je     9930 <fwp_drop2+0x120>
    991b:	3c 01                	cmp    $0x1,%al
    991d:	74 59                	je     9978 <fwp_drop2+0x168>
    991f:	3c ff                	cmp    $0xff,%al
    9921:	0f 84 ff 00 00 00    	je     9a26 <fwp_drop2+0x216>
    9927:	83 e8 01             	sub    $0x1,%eax
    992a:	88 01                	mov    %al,(%rcx)
    992c:	0f 1f 40 00          	nopl   0x0(%rax)
    9930:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9934:	48 89 d7             	mov    %rdx,%rdi
    9937:	48 89 0c 24          	mov    %rcx,(%rsp)
    993b:	e8 50 d2 ff ff       	call   6b90 <fwp_rc_free_arr>
    9940:	4c 8d 05 99 7e 01 00 	lea    0x17e99(%rip),%r8        # 217e0 <fwp_heap>
    9947:	48 8b 04 24          	mov    (%rsp),%rax
    994b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9952:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9959:	48 c1 e2 10          	shl    $0x10,%rdx
    995d:	48 39 d0             	cmp    %rdx,%rax
    9960:	0f 83 35 ff ff ff    	jae    989b <fwp_drop2+0x8b>
    9966:	48 8b 14 24          	mov    (%rsp),%rdx
    996a:	e9 cd fe ff ff       	jmp    983c <fwp_drop2+0x2c>
    996f:	90                   	nop
    9970:	c3                   	ret
    9971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9978:	48 89 14 24          	mov    %rdx,(%rsp)
    997c:	e8 0f d2 ff ff       	call   6b90 <fwp_rc_free_arr>
    9981:	48 8b 14 24          	mov    (%rsp),%rdx
    9985:	eb a9                	jmp    9930 <fwp_drop2+0x120>
    9987:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    998e:	00 00 
    9990:	66 85 c0             	test   %ax,%ax
    9993:	75 9b                	jne    9930 <fwp_drop2+0x120>
    9995:	e9 7a ff ff ff       	jmp    9914 <fwp_drop2+0x104>
    999a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    99a0:	48 89 c8             	mov    %rcx,%rax
    99a3:	48 c1 e8 11          	shr    $0x11,%rax
    99a7:	48 31 c8             	xor    %rcx,%rax
    99aa:	48 89 c2             	mov    %rax,%rdx
    99ad:	48 c1 ea 09          	shr    $0x9,%rdx
    99b1:	48 31 d0             	xor    %rdx,%rax
    99b4:	0f b6 d0             	movzbl %al,%edx
    99b7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    99be:	00 
    99bf:	48 85 c0             	test   %rax,%rax
    99c2:	75 29                	jne    99ed <fwp_drop2+0x1dd>
    99c4:	e9 e3 00 00 00       	jmp    9aac <fwp_drop2+0x29c>
    99c9:	90                   	nop
    99ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99d1:	00 00 00 00 
    99d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    99dc:	00 00 00 00 
    99e0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    99e4:	48 85 c0             	test   %rax,%rax
    99e7:	0f 84 bf 00 00 00    	je     9aac <fwp_drop2+0x29c>
    99ed:	48 89 c2             	mov    %rax,%rdx
    99f0:	48 39 08             	cmp    %rcx,(%rax)
    99f3:	75 eb                	jne    99e0 <fwp_drop2+0x1d0>
    99f5:	48 8b 50 08          	mov    0x8(%rax),%rdx
    99f9:	48 83 ea 01          	sub    $0x1,%rdx
    99fd:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9a01:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9a08:	0f 85 8d fe ff ff    	jne    989b <fwp_drop2+0x8b>
    9a0e:	48 89 cf             	mov    %rcx,%rdi
    9a11:	48 89 0c 24          	mov    %rcx,(%rsp)
    9a15:	e8 36 bb ff ff       	call   5550 <fwp_rc_forget_slot>
    9a1a:	48 8b 0c 24          	mov    (%rsp),%rcx
    9a1e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9a21:	e9 75 fe ff ff       	jmp    989b <fwp_drop2+0x8b>
    9a26:	48 89 ce             	mov    %rcx,%rsi
    9a29:	48 c1 ee 11          	shr    $0x11,%rsi
    9a2d:	48 31 ce             	xor    %rcx,%rsi
    9a30:	48 89 f0             	mov    %rsi,%rax
    9a33:	48 c1 e8 09          	shr    $0x9,%rax
    9a37:	48 31 c6             	xor    %rax,%rsi
    9a3a:	40 0f b6 f6          	movzbl %sil,%esi
    9a3e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9a45:	00 
    9a46:	48 85 c0             	test   %rax,%rax
    9a49:	75 1e                	jne    9a69 <fwp_drop2+0x259>
    9a4b:	eb 5f                	jmp    9aac <fwp_drop2+0x29c>
    9a4d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a54:	00 
    9a55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9a5c:	00 00 00 00 
    9a60:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9a64:	48 85 c0             	test   %rax,%rax
    9a67:	74 43                	je     9aac <fwp_drop2+0x29c>
    9a69:	48 89 c6             	mov    %rax,%rsi
    9a6c:	48 39 08             	cmp    %rcx,(%rax)
    9a6f:	75 ef                	jne    9a60 <fwp_drop2+0x250>
    9a71:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9a75:	48 83 ee 01          	sub    $0x1,%rsi
    9a79:	48 89 70 08          	mov    %rsi,0x8(%rax)
    9a7d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    9a84:	0f 85 a6 fe ff ff    	jne    9930 <fwp_drop2+0x120>
    9a8a:	48 89 cf             	mov    %rcx,%rdi
    9a8d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    9a92:	48 89 0c 24          	mov    %rcx,(%rsp)
    9a96:	e8 b5 ba ff ff       	call   5550 <fwp_rc_forget_slot>
    9a9b:	48 8b 0c 24          	mov    (%rsp),%rcx
    9a9f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    9aa4:	c6 01 fe             	movb   $0xfe,(%rcx)
    9aa7:	e9 84 fe ff ff       	jmp    9930 <fwp_drop2+0x120>
    9aac:	48 8d 3d d5 3d 00 00 	lea    0x3dd5(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    9ab3:	e8 38 a9 ff ff       	call   43f0 <fwp_trap>
    9ab8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9abf:	00 

0000000000009ac0 <fwp_arg_drop23>:
    9ac0:	f3 0f 1e fa          	endbr64
    9ac4:	85 f6                	test   %esi,%esi
    9ac6:	75 04                	jne    9acc <fwp_arg_drop23+0xc>
    9ac8:	85 d2                	test   %edx,%edx
    9aca:	75 04                	jne    9ad0 <fwp_arg_drop23+0x10>
    9acc:	c3                   	ret
    9acd:	0f 1f 00             	nopl   (%rax)
    9ad0:	48 8b 3f             	mov    (%rdi),%rdi
    9ad3:	e9 38 fd ff ff       	jmp    9810 <fwp_drop2>
    9ad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9adf:	00 

0000000000009ae0 <fwp_caps23>:
    9ae0:	f3 0f 1e fa          	endbr64
    9ae4:	48 83 ec 18          	sub    $0x18,%rsp
    9ae8:	8b 57 04             	mov    0x4(%rdi),%edx
    9aeb:	48 89 f8             	mov    %rdi,%rax
    9aee:	85 d2                	test   %edx,%edx
    9af0:	0f 84 9a 00 00 00    	je     9b90 <fwp_caps23+0xb0>
    9af6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    9afa:	85 f6                	test   %esi,%esi
    9afc:	0f 85 9e 00 00 00    	jne    9ba0 <fwp_caps23+0xc0>
    9b02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9b07:	e8 04 fd ff ff       	call   9810 <fwp_drop2>
    9b0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9b11:	48 8b 0d a0 90 01 00 	mov    0x190a0(%rip),%rcx        # 22bb8 <fwp_heap+0x13d8>
    9b18:	48 89 c2             	mov    %rax,%rdx
    9b1b:	48 2b 15 6e 90 01 00 	sub    0x1906e(%rip),%rdx        # 22b90 <fwp_heap+0x13b0>
    9b22:	48 c1 e1 10          	shl    $0x10,%rcx
    9b26:	48 39 ca             	cmp    %rcx,%rdx
    9b29:	73 6d                	jae    9b98 <fwp_caps23+0xb8>
    9b2b:	48 89 d1             	mov    %rdx,%rcx
    9b2e:	48 c1 e9 10          	shr    $0x10,%rcx
    9b32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9b36:	48 8b 0d 9b 90 01 00 	mov    0x1909b(%rip),%rcx        # 22bd8 <fwp_heap+0x13f8>
    9b3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9b41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9b45:	48 85 f6             	test   %rsi,%rsi
    9b48:	74 4e                	je     9b98 <fwp_caps23+0xb8>
    9b4a:	0f b6 39             	movzbl (%rcx),%edi
    9b4d:	40 80 ff 02          	cmp    $0x2,%dil
    9b51:	0f 84 b9 00 00 00    	je     9c10 <fwp_caps23+0x130>
    9b57:	40 80 ff 01          	cmp    $0x1,%dil
    9b5b:	75 3b                	jne    9b98 <fwp_caps23+0xb8>
    9b5d:	8b 79 18             	mov    0x18(%rcx),%edi
    9b60:	0f b7 d2             	movzwl %dx,%edx
    9b63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9b66:	48 0f af d7          	imul   %rdi,%rdx
    9b6a:	48 c1 ea 20          	shr    $0x20,%rdx
    9b6e:	48 39 ca             	cmp    %rcx,%rdx
    9b71:	73 25                	jae    9b98 <fwp_caps23+0xb8>
    9b73:	48 01 d6             	add    %rdx,%rsi
    9b76:	80 3e 01             	cmpb   $0x1,(%rsi)
    9b79:	75 1d                	jne    9b98 <fwp_caps23+0xb8>
    9b7b:	48 89 c7             	mov    %rax,%rdi
    9b7e:	48 83 c4 18          	add    $0x18,%rsp
    9b82:	e9 09 bc ff ff       	jmp    5790 <fwp_mem_free>
    9b87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9b8e:	00 00 
    9b90:	85 f6                	test   %esi,%esi
    9b92:	0f 84 79 ff ff ff    	je     9b11 <fwp_caps23+0x31>
    9b98:	48 83 c4 18          	add    $0x18,%rsp
    9b9c:	c3                   	ret
    9b9d:	0f 1f 00             	nopl   (%rax)
    9ba0:	48 8b 05 11 90 01 00 	mov    0x19011(%rip),%rax        # 22bb8 <fwp_heap+0x13d8>
    9ba7:	48 2b 3d e2 8f 01 00 	sub    0x18fe2(%rip),%rdi        # 22b90 <fwp_heap+0x13b0>
    9bae:	48 c1 e0 10          	shl    $0x10,%rax
    9bb2:	48 39 c7             	cmp    %rax,%rdi
    9bb5:	73 e1                	jae    9b98 <fwp_caps23+0xb8>
    9bb7:	48 89 f8             	mov    %rdi,%rax
    9bba:	48 c1 e8 10          	shr    $0x10,%rax
    9bbe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9bc2:	48 8b 05 0f 90 01 00 	mov    0x1900f(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    9bc9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9bcd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    9bd1:	48 85 c0             	test   %rax,%rax
    9bd4:	74 c2                	je     9b98 <fwp_caps23+0xb8>
    9bd6:	0f b6 0a             	movzbl (%rdx),%ecx
    9bd9:	80 f9 02             	cmp    $0x2,%cl
    9bdc:	74 42                	je     9c20 <fwp_caps23+0x140>
    9bde:	80 f9 01             	cmp    $0x1,%cl
    9be1:	75 b5                	jne    9b98 <fwp_caps23+0xb8>
    9be3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9be6:	0f b7 ff             	movzwl %di,%edi
    9be9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9bec:	48 0f af f9          	imul   %rcx,%rdi
    9bf0:	48 c1 ef 20          	shr    $0x20,%rdi
    9bf4:	48 39 d7             	cmp    %rdx,%rdi
    9bf7:	73 9f                	jae    9b98 <fwp_caps23+0xb8>
    9bf9:	48 01 f8             	add    %rdi,%rax
    9bfc:	0f b6 10             	movzbl (%rax),%edx
    9bff:	84 d2                	test   %dl,%dl
    9c01:	74 95                	je     9b98 <fwp_caps23+0xb8>
    9c03:	80 fa fd             	cmp    $0xfd,%dl
    9c06:	77 23                	ja     9c2b <fwp_caps23+0x14b>
    9c08:	83 c2 01             	add    $0x1,%edx
    9c0b:	88 10                	mov    %dl,(%rax)
    9c0d:	eb 89                	jmp    9b98 <fwp_caps23+0xb8>
    9c0f:	90                   	nop
    9c10:	66 85 d2             	test   %dx,%dx
    9c13:	0f 85 7f ff ff ff    	jne    9b98 <fwp_caps23+0xb8>
    9c19:	e9 58 ff ff ff       	jmp    9b76 <fwp_caps23+0x96>
    9c1e:	66 90                	xchg   %ax,%ax
    9c20:	66 85 ff             	test   %di,%di
    9c23:	0f 85 6f ff ff ff    	jne    9b98 <fwp_caps23+0xb8>
    9c29:	eb d1                	jmp    9bfc <fwp_caps23+0x11c>
    9c2b:	48 89 c7             	mov    %rax,%rdi
    9c2e:	48 83 c4 18          	add    $0x18,%rsp
    9c32:	e9 f9 b7 ff ff       	jmp    5430 <fwp_rc_wide_dup>
    9c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9c3e:	00 00 

0000000000009c40 <f23>:
    9c40:	41 57                	push   %r15
    9c42:	41 56                	push   %r14
    9c44:	41 55                	push   %r13
    9c46:	41 54                	push   %r12
    9c48:	55                   	push   %rbp
    9c49:	53                   	push   %rbx
    9c4a:	48 83 ec 38          	sub    $0x38,%rsp
    9c4e:	48 8b 15 63 8f 01 00 	mov    0x18f63(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9c55:	48 8b 0d 34 8f 01 00 	mov    0x18f34(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    9c5c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    9c63:	00 00 
    9c65:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    9c6a:	49 89 fd             	mov    %rdi,%r13
    9c6d:	48 c1 e2 10          	shl    $0x10,%rdx
    9c71:	48 85 ff             	test   %rdi,%rdi
    9c74:	0f 84 fc 02 00 00    	je     9f76 <f23+0x336>
    9c7a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    9c7e:	48 89 d8             	mov    %rbx,%rax
    9c81:	48 29 c8             	sub    %rcx,%rax
    9c84:	48 39 d0             	cmp    %rdx,%rax
    9c87:	0f 83 b3 03 00 00    	jae    a040 <f23+0x400>
    9c8d:	48 89 c2             	mov    %rax,%rdx
    9c90:	48 c1 ea 10          	shr    $0x10,%rdx
    9c94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9c98:	48 8b 15 39 8f 01 00 	mov    0x18f39(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9c9f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ca3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9ca7:	48 85 ff             	test   %rdi,%rdi
    9caa:	0f 84 90 03 00 00    	je     a040 <f23+0x400>
    9cb0:	0f b6 0a             	movzbl (%rdx),%ecx
    9cb3:	80 f9 02             	cmp    $0x2,%cl
    9cb6:	0f 84 94 02 00 00    	je     9f50 <f23+0x310>
    9cbc:	80 f9 01             	cmp    $0x1,%cl
    9cbf:	75 24                	jne    9ce5 <f23+0xa5>
    9cc1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cc4:	0f b7 c0             	movzwl %ax,%eax
    9cc7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9cca:	48 0f af c1          	imul   %rcx,%rax
    9cce:	48 c1 e8 20          	shr    $0x20,%rax
    9cd2:	48 39 d0             	cmp    %rdx,%rax
    9cd5:	73 0e                	jae    9ce5 <f23+0xa5>
    9cd7:	48 01 c7             	add    %rax,%rdi
    9cda:	0f b6 07             	movzbl (%rdi),%eax
    9cdd:	84 c0                	test   %al,%al
    9cdf:	0f 85 0b 03 00 00    	jne    9ff0 <f23+0x3b0>
    9ce5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9cea:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    9cee:	ba 01 00 00 00       	mov    $0x1,%edx
    9cf3:	48 85 db             	test   %rbx,%rbx
    9cf6:	74 15                	je     9d0d <f23+0xcd>
    9cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9cff:	00 
    9d00:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9d04:	48 83 c2 01          	add    $0x1,%rdx
    9d08:	48 85 db             	test   %rbx,%rbx
    9d0b:	75 f3                	jne    9d00 <f23+0xc0>
    9d0d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9d12:	48 85 c0             	test   %rax,%rax
    9d15:	0f 84 55 03 00 00    	je     a070 <f23+0x430>
    9d1b:	31 db                	xor    %ebx,%ebx
    9d1d:	0f 1f 00             	nopl   (%rax)
    9d20:	48 8b 40 10          	mov    0x10(%rax),%rax
    9d24:	48 83 c3 01          	add    $0x1,%rbx
    9d28:	48 85 c0             	test   %rax,%rax
    9d2b:	75 f3                	jne    9d20 <f23+0xe0>
    9d2d:	48 39 d3             	cmp    %rdx,%rbx
    9d30:	48 0f 47 da          	cmova  %rdx,%rbx
    9d34:	48 89 d8             	mov    %rbx,%rax
    9d37:	48 c1 e8 3c          	shr    $0x3c,%rax
    9d3b:	0f 85 d3 03 00 00    	jne    a114 <f23+0x4d4>
    9d41:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9d45:	be 02 00 00 00       	mov    $0x2,%esi
    9d4a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9d51:	00 
    9d52:	e8 39 bf ff ff       	call   5c90 <fwp_heap_alloc>
    9d57:	48 89 28             	mov    %rbp,(%rax)
    9d5a:	48 8b 15 57 8e 01 00 	mov    0x18e57(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9d61:	49 89 c4             	mov    %rax,%r12
    9d64:	48 2b 05 25 8e 01 00 	sub    0x18e25(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9d6b:	48 c1 e2 10          	shl    $0x10,%rdx
    9d6f:	48 39 d0             	cmp    %rdx,%rax
    9d72:	73 57                	jae    9dcb <f23+0x18b>
    9d74:	48 89 c2             	mov    %rax,%rdx
    9d77:	48 c1 ea 10          	shr    $0x10,%rdx
    9d7b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9d7f:	48 8b 15 52 8e 01 00 	mov    0x18e52(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9d86:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9d8a:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9d8e:	48 85 ed             	test   %rbp,%rbp
    9d91:	74 38                	je     9dcb <f23+0x18b>
    9d93:	0f b6 0a             	movzbl (%rdx),%ecx
    9d96:	80 f9 02             	cmp    $0x2,%cl
    9d99:	0f 84 91 02 00 00    	je     a030 <f23+0x3f0>
    9d9f:	80 f9 01             	cmp    $0x1,%cl
    9da2:	75 27                	jne    9dcb <f23+0x18b>
    9da4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9da7:	0f b7 c0             	movzwl %ax,%eax
    9daa:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9dad:	48 0f af c1          	imul   %rcx,%rax
    9db1:	48 c1 e8 20          	shr    $0x20,%rax
    9db5:	48 39 d0             	cmp    %rdx,%rax
    9db8:	73 11                	jae    9dcb <f23+0x18b>
    9dba:	48 01 c5             	add    %rax,%rbp
    9dbd:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9dc1:	0f 84 19 03 00 00    	je     a0e0 <f23+0x4a0>
    9dc7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9dcb:	48 85 db             	test   %rbx,%rbx
    9dce:	74 5d                	je     9e2d <f23+0x1ed>
    9dd0:	48 c1 e3 04          	shl    $0x4,%rbx
    9dd4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9dd9:	4c 89 e5             	mov    %r12,%rbp
    9ddc:	4d 89 ee             	mov    %r13,%r14
    9ddf:	4c 01 e3             	add    %r12,%rbx
    9de2:	0f 1f 00             	nopl   (%rax)
    9de5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9dec:	00 00 00 00 
    9df0:	49 8b 46 08          	mov    0x8(%r14),%rax
    9df4:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9df8:	48 83 c5 10          	add    $0x10,%rbp
    9dfc:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9e01:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9e05:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9e09:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    9e0e:	e8 cd c5 ff ff       	call   63e0 <w107>
    9e13:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9e18:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    9e1c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9e20:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9e24:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9e28:	48 39 eb             	cmp    %rbp,%rbx
    9e2b:	75 c3                	jne    9df0 <f23+0x1b0>
    9e2d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9e32:	31 db                	xor    %ebx,%ebx
    9e34:	e8 d7 f9 ff ff       	call   9810 <fwp_drop2>
    9e39:	4c 89 ef             	mov    %r13,%rdi
    9e3c:	e8 cf f9 ff ff       	call   9810 <fwp_drop2>
    9e41:	4d 8b 2c 24          	mov    (%r12),%r13
    9e45:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9e49:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9e50:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9e57:	4d 85 ed             	test   %r13,%r13
    9e5a:	74 32                	je     9e8e <f23+0x24e>
    9e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e60:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9e67:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    9e6c:	48 83 c3 02          	add    $0x2,%rbx
    9e70:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9e76:	e8 e5 c3 ff ff       	call   6260 <f128.constprop.0>
    9e7b:	4c 39 eb             	cmp    %r13,%rbx
    9e7e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9e84:	48 89 c7             	mov    %rax,%rdi
    9e87:	72 d7                	jb     9e60 <f23+0x220>
    9e89:	66 49 0f 7e c5       	movq   %xmm0,%r13
    9e8e:	4c 89 e7             	mov    %r12,%rdi
    9e91:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9e96:	e8 d5 dd ff ff       	call   7c70 <fwp_drop4>
    9e9b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9ea0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9ea5:	31 ff                	xor    %edi,%edi
    9ea7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9eac:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9eb1:	e8 2a cb ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    9eb6:	48 8b 15 fb 8c 01 00 	mov    0x18cfb(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    9ebd:	48 89 c5             	mov    %rax,%rbp
    9ec0:	48 2b 05 c9 8c 01 00 	sub    0x18cc9(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    9ec7:	48 c1 e2 10          	shl    $0x10,%rdx
    9ecb:	48 39 d0             	cmp    %rdx,%rax
    9ece:	73 55                	jae    9f25 <f23+0x2e5>
    9ed0:	48 89 c2             	mov    %rax,%rdx
    9ed3:	48 c1 ea 10          	shr    $0x10,%rdx
    9ed7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9edb:	48 8b 15 f6 8c 01 00 	mov    0x18cf6(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    9ee2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ee6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9eea:	48 85 db             	test   %rbx,%rbx
    9eed:	74 36                	je     9f25 <f23+0x2e5>
    9eef:	0f b6 0a             	movzbl (%rdx),%ecx
    9ef2:	80 f9 02             	cmp    $0x2,%cl
    9ef5:	0f 84 1d 01 00 00    	je     a018 <f23+0x3d8>
    9efb:	80 f9 01             	cmp    $0x1,%cl
    9efe:	75 25                	jne    9f25 <f23+0x2e5>
    9f00:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9f03:	0f b7 c0             	movzwl %ax,%eax
    9f06:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9f09:	48 0f af c1          	imul   %rcx,%rax
    9f0d:	48 c1 e8 20          	shr    $0x20,%rax
    9f11:	48 39 d0             	cmp    %rdx,%rax
    9f14:	73 0f                	jae    9f25 <f23+0x2e5>
    9f16:	48 01 c3             	add    %rax,%rbx
    9f19:	80 3b ff             	cmpb   $0xff,(%rbx)
    9f1c:	0f 84 b1 01 00 00    	je     a0d3 <f23+0x493>
    9f22:	c6 03 01             	movb   $0x1,(%rbx)
    9f25:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9f2a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f31:	00 00 
    9f33:	0f 85 d6 01 00 00    	jne    a10f <f23+0x4cf>
    9f39:	48 83 c4 38          	add    $0x38,%rsp
    9f3d:	48 89 e8             	mov    %rbp,%rax
    9f40:	5b                   	pop    %rbx
    9f41:	5d                   	pop    %rbp
    9f42:	41 5c                	pop    %r12
    9f44:	41 5d                	pop    %r13
    9f46:	41 5e                	pop    %r14
    9f48:	41 5f                	pop    %r15
    9f4a:	c3                   	ret
    9f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9f50:	66 85 c0             	test   %ax,%ax
    9f53:	0f 85 8c fd ff ff    	jne    9ce5 <f23+0xa5>
    9f59:	0f b6 07             	movzbl (%rdi),%eax
    9f5c:	84 c0                	test   %al,%al
    9f5e:	0f 84 81 fd ff ff    	je     9ce5 <f23+0xa5>
    9f64:	3c fd                	cmp    $0xfd,%al
    9f66:	0f 87 99 01 00 00    	ja     a105 <f23+0x4c5>
    9f6c:	83 c0 01             	add    $0x1,%eax
    9f6f:	88 07                	mov    %al,(%rdi)
    9f71:	e9 6f fd ff ff       	jmp    9ce5 <f23+0xa5>
    9f76:	48 f7 d9             	neg    %rcx
    9f79:	48 39 d1             	cmp    %rdx,%rcx
    9f7c:	0f 83 ee 00 00 00    	jae    a070 <f23+0x430>
    9f82:	48 89 c8             	mov    %rcx,%rax
    9f85:	48 c1 e8 10          	shr    $0x10,%rax
    9f89:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9f8d:	48 8b 05 44 8c 01 00 	mov    0x18c44(%rip),%rax        # 22bd8 <fwp_heap+0x13f8>
    9f94:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9f98:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9f9c:	48 85 ff             	test   %rdi,%rdi
    9f9f:	0f 84 cb 00 00 00    	je     a070 <f23+0x430>
    9fa5:	0f b6 02             	movzbl (%rdx),%eax
    9fa8:	3c 02                	cmp    $0x2,%al
    9faa:	0f 84 9a 00 00 00    	je     a04a <f23+0x40a>
    9fb0:	3c 01                	cmp    $0x1,%al
    9fb2:	0f 85 b8 00 00 00    	jne    a070 <f23+0x430>
    9fb8:	0f b7 c1             	movzwl %cx,%eax
    9fbb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9fbe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9fc1:	48 0f af c1          	imul   %rcx,%rax
    9fc5:	48 c1 e8 20          	shr    $0x20,%rax
    9fc9:	48 39 d0             	cmp    %rdx,%rax
    9fcc:	0f 83 9e 00 00 00    	jae    a070 <f23+0x430>
    9fd2:	48 01 c7             	add    %rax,%rdi
    9fd5:	0f b6 07             	movzbl (%rdi),%eax
    9fd8:	84 c0                	test   %al,%al
    9fda:	0f 84 90 00 00 00    	je     a070 <f23+0x430>
    9fe0:	31 db                	xor    %ebx,%ebx
    9fe2:	0f 1f 00             	nopl   (%rax)
    9fe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9fec:	00 00 00 00 
    9ff0:	3c fd                	cmp    $0xfd,%al
    9ff2:	0f 87 f5 00 00 00    	ja     a0ed <f23+0x4ad>
    9ff8:	83 c0 01             	add    $0x1,%eax
    9ffb:	88 07                	mov    %al,(%rdi)
    9ffd:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    a002:	31 d2                	xor    %edx,%edx
    a004:	4d 85 ed             	test   %r13,%r13
    a007:	0f 85 dd fc ff ff    	jne    9cea <f23+0xaa>
    a00d:	e9 fb fc ff ff       	jmp    9d0d <f23+0xcd>
    a012:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a018:	66 85 c0             	test   %ax,%ax
    a01b:	0f 85 04 ff ff ff    	jne    9f25 <f23+0x2e5>
    a021:	e9 f3 fe ff ff       	jmp    9f19 <f23+0x2d9>
    a026:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a02d:	00 00 00 
    a030:	66 85 c0             	test   %ax,%ax
    a033:	0f 85 92 fd ff ff    	jne    9dcb <f23+0x18b>
    a039:	e9 7f fd ff ff       	jmp    9dbd <f23+0x17d>
    a03e:	66 90                	xchg   %ax,%ax
    a040:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    a045:	e9 a4 fc ff ff       	jmp    9cee <f23+0xae>
    a04a:	66 85 c9             	test   %cx,%cx
    a04d:	75 21                	jne    a070 <f23+0x430>
    a04f:	0f b6 07             	movzbl (%rdi),%eax
    a052:	84 c0                	test   %al,%al
    a054:	74 1a                	je     a070 <f23+0x430>
    a056:	3c fd                	cmp    $0xfd,%al
    a058:	0f 87 c2 00 00 00    	ja     a120 <f23+0x4e0>
    a05e:	83 c0 01             	add    $0x1,%eax
    a061:	88 07                	mov    %al,(%rdi)
    a063:	66 90                	xchg   %ax,%ax
    a065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a06c:	00 00 00 00 
    a070:	be 02 00 00 00       	mov    $0x2,%esi
    a075:	bf 08 00 00 00       	mov    $0x8,%edi
    a07a:	e8 11 bc ff ff       	call   5c90 <fwp_heap_alloc>
    a07f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    a086:	48 8b 15 2b 8b 01 00 	mov    0x18b2b(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    a08d:	49 89 c4             	mov    %rax,%r12
    a090:	48 2b 05 f9 8a 01 00 	sub    0x18af9(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    a097:	48 c1 e2 10          	shl    $0x10,%rdx
    a09b:	48 39 d0             	cmp    %rdx,%rax
    a09e:	73 57                	jae    a0f7 <f23+0x4b7>
    a0a0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    a0a7:	00 00 
    a0a9:	48 89 c2             	mov    %rax,%rdx
    a0ac:	48 c1 ea 10          	shr    $0x10,%rdx
    a0b0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a0b4:	48 8b 15 1d 8b 01 00 	mov    0x18b1d(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    a0bb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a0bf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    a0c3:	48 85 ed             	test   %rbp,%rbp
    a0c6:	0f 84 61 fd ff ff    	je     9e2d <f23+0x1ed>
    a0cc:	31 db                	xor    %ebx,%ebx
    a0ce:	e9 c0 fc ff ff       	jmp    9d93 <f23+0x153>
    a0d3:	48 89 df             	mov    %rbx,%rdi
    a0d6:	e8 75 b4 ff ff       	call   5550 <fwp_rc_forget_slot>
    a0db:	e9 42 fe ff ff       	jmp    9f22 <f23+0x2e2>
    a0e0:	48 89 ef             	mov    %rbp,%rdi
    a0e3:	e8 68 b4 ff ff       	call   5550 <fwp_rc_forget_slot>
    a0e8:	e9 da fc ff ff       	jmp    9dc7 <f23+0x187>
    a0ed:	e8 3e b3 ff ff       	call   5430 <fwp_rc_wide_dup>
    a0f2:	e9 06 ff ff ff       	jmp    9ffd <f23+0x3bd>
    a0f7:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    a0fe:	00 00 
    a100:	e9 28 fd ff ff       	jmp    9e2d <f23+0x1ed>
    a105:	e8 26 b3 ff ff       	call   5430 <fwp_rc_wide_dup>
    a10a:	e9 d6 fb ff ff       	jmp    9ce5 <f23+0xa5>
    a10f:	e8 4c 93 ff ff       	call   3460 <__stack_chk_fail@plt>
    a114:	48 8d 3d 8f 30 00 00 	lea    0x308f(%rip),%rdi        # d1aa <_IO_stdin_used+0x1aa>
    a11b:	e8 d0 a2 ff ff       	call   43f0 <fwp_trap>
    a120:	e8 0b b3 ff ff       	call   5430 <fwp_rc_wide_dup>
    a125:	e9 46 ff ff ff       	jmp    a070 <f23+0x430>
    a12a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

000000000000a130 <fwp_owned_entry23>:
    a130:	f3 0f 1e fa          	endbr64
    a134:	48 8b 3f             	mov    (%rdi),%rdi
    a137:	e9 04 fb ff ff       	jmp    9c40 <f23>
    a13c:	0f 1f 40 00          	nopl   0x0(%rax)

000000000000a140 <e23>:
    a140:	f3 0f 1e fa          	endbr64
    a144:	53                   	push   %rbx
    a145:	48 8b 1f             	mov    (%rdi),%rbx
    a148:	48 89 df             	mov    %rbx,%rdi
    a14b:	e8 c0 c9 ff ff       	call   6b10 <fwp_rc_share>
    a150:	48 89 df             	mov    %rbx,%rdi
    a153:	e8 e8 fa ff ff       	call   9c40 <f23>
    a158:	48 89 c3             	mov    %rax,%rbx
    a15b:	48 89 c7             	mov    %rax,%rdi
    a15e:	e8 ad c9 ff ff       	call   6b10 <fwp_rc_share>
    a163:	48 89 d8             	mov    %rbx,%rax
    a166:	5b                   	pop    %rbx
    a167:	c3                   	ret
    a168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a16f:	00 

000000000000a170 <fwp_write>:
    a170:	41 57                	push   %r15
    a172:	41 56                	push   %r14
    a174:	41 55                	push   %r13
    a176:	41 54                	push   %r12
    a178:	55                   	push   %rbp
    a179:	53                   	push   %rbx
    a17a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    a181:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    a188:	00 00 
    a18a:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    a191:	00 
    a192:	49 89 d4             	mov    %rdx,%r12
    a195:	8b 12                	mov    (%rdx),%edx
    a197:	83 fa 19             	cmp    $0x19,%edx
    a19a:	77 6a                	ja     a206 <fwp_write+0x96>
    a19c:	48 89 f5             	mov    %rsi,%rbp
    a19f:	89 d0                	mov    %edx,%eax
    a1a1:	89 ce                	mov    %ecx,%esi
    a1a3:	48 89 fb             	mov    %rdi,%rbx
    a1a6:	48 8d 0d 53 39 00 00 	lea    0x3953(%rip),%rcx        # db00 <_IO_stdin_used+0xb00>
    a1ad:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    a1b1:	48 01 c8             	add    %rcx,%rax
    a1b4:	3e ff e0             	notrack jmp *%rax
    a1b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1be:	00 00 
    a1c0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    a1c4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    a1c8:	48 89 ca             	mov    %rcx,%rdx
    a1cb:	48 85 c9             	test   %rcx,%rcx
    a1ce:	0f 88 9c 0c 00 00    	js     ae70 <fwp_write+0xd00>
    a1d4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a1db:	00 
    a1dc:	48 89 c6             	mov    %rax,%rsi
    a1df:	4c 89 e7             	mov    %r12,%rdi
    a1e2:	e8 59 98 ff ff       	call   3a40 <fwp_fmt_u128>
    a1e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1ee:	00 00 
    a1f0:	4c 89 e7             	mov    %r12,%rdi
    a1f3:	e8 58 92 ff ff       	call   3450 <strlen@plt>
    a1f8:	4c 89 e6             	mov    %r12,%rsi
    a1fb:	48 89 df             	mov    %rbx,%rdi
    a1fe:	48 89 c2             	mov    %rax,%rdx
    a201:	e8 0a a0 ff ff       	call   4210 <buf_put>
    a206:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a20d:	00 
    a20e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a215:	00 00 
    a217:	0f 85 28 04 00 00    	jne    a645 <fwp_write+0x4d5>
    a21d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a224:	5b                   	pop    %rbx
    a225:	5d                   	pop    %rbp
    a226:	41 5c                	pop    %r12
    a228:	41 5d                	pop    %r13
    a22a:	41 5e                	pop    %r14
    a22c:	41 5f                	pop    %r15
    a22e:	c3                   	ret
    a22f:	90                   	nop
    a230:	49 89 e9             	mov    %rbp,%r9
    a233:	4c 8d 05 3b 2e 00 00 	lea    0x2e3b(%rip),%r8        # d075 <_IO_stdin_used+0x75>
    a23a:	b9 00 02 00 00       	mov    $0x200,%ecx
    a23f:	ba 02 00 00 00       	mov    $0x2,%edx
    a244:	be 00 02 00 00       	mov    $0x200,%esi
    a249:	31 c0                	xor    %eax,%eax
    a24b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a252:	00 
    a253:	e8 58 91 ff ff       	call   33b0 <__snprintf_chk@plt>
    a258:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a25f:	00 
    a260:	e8 eb 91 ff ff       	call   3450 <strlen@plt>
    a265:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a26c:	00 
    a26d:	48 89 df             	mov    %rbx,%rdi
    a270:	48 89 c2             	mov    %rax,%rdx
    a273:	e8 98 9f ff ff       	call   4210 <buf_put>
    a278:	eb 8c                	jmp    a206 <fwp_write+0x96>
    a27a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a280:	49 89 e9             	mov    %rbp,%r9
    a283:	4c 8d 05 55 2f 00 00 	lea    0x2f55(%rip),%r8        # d1df <_IO_stdin_used+0x1df>
    a28a:	eb ae                	jmp    a23a <fwp_write+0xca>
    a28c:	0f 1f 40 00          	nopl   0x0(%rax)
    a290:	83 fa 13             	cmp    $0x13,%edx
    a293:	48 8d 05 3b 2f 00 00 	lea    0x2f3b(%rip),%rax        # d1d5 <_IO_stdin_used+0x1d5>
    a29a:	48 8d 35 39 2f 00 00 	lea    0x2f39(%rip),%rsi        # d1da <_IO_stdin_used+0x1da>
    a2a1:	ba 04 00 00 00       	mov    $0x4,%edx
    a2a6:	48 0f 44 f0          	cmove  %rax,%rsi
    a2aa:	45 31 ed             	xor    %r13d,%r13d
    a2ad:	e8 5e 9f ff ff       	call   4210 <buf_put>
    a2b2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a2b7:	0f 84 a3 08 00 00    	je     ab60 <fwp_write+0x9f0>
    a2bd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    a2c2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    a2c7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a2cc:	48 89 df             	mov    %rbx,%rdi
    a2cf:	49 0f 44 c5          	cmove  %r13,%rax
    a2d3:	31 c9                	xor    %ecx,%ecx
    a2d5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    a2da:	e8 91 fe ff ff       	call   a170 <fwp_write>
    a2df:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a2e4:	0f 84 6e 09 00 00    	je     ac58 <fwp_write+0xae8>
    a2ea:	49 83 c5 01          	add    $0x1,%r13
    a2ee:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a2f2:	0f 83 68 08 00 00    	jae    ab60 <fwp_write+0x9f0>
    a2f8:	ba 02 00 00 00       	mov    $0x2,%edx
    a2fd:	48 8d 35 1b 2f 00 00 	lea    0x2f1b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a304:	48 89 df             	mov    %rbx,%rdi
    a307:	e8 04 9f ff ff       	call   4210 <buf_put>
    a30c:	eb af                	jmp    a2bd <fwp_write+0x14d>
    a30e:	66 90                	xchg   %ax,%ax
    a310:	ba 06 00 00 00       	mov    $0x6,%edx
    a315:	48 8d 35 dc 2e 00 00 	lea    0x2edc(%rip),%rsi        # d1f8 <_IO_stdin_used+0x1f8>
    a31c:	48 83 c5 10          	add    $0x10,%rbp
    a320:	e8 eb 9e ff ff       	call   4210 <buf_put>
    a325:	48 89 ef             	mov    %rbp,%rdi
    a328:	e8 23 91 ff ff       	call   3450 <strlen@plt>
    a32d:	48 89 ee             	mov    %rbp,%rsi
    a330:	48 89 df             	mov    %rbx,%rdi
    a333:	48 89 c2             	mov    %rax,%rdx
    a336:	e8 d5 9e ff ff       	call   4210 <buf_put>
    a33b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a340:	ba 01 00 00 00       	mov    $0x1,%edx
    a345:	48 89 df             	mov    %rbx,%rdi
    a348:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a34d:	e8 be 9e ff ff       	call   4210 <buf_put>
    a352:	e9 af fe ff ff       	jmp    a206 <fwp_write+0x96>
    a357:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a35e:	00 00 
    a360:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a367:	00 
    a368:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a36f:	00 00 
    a371:	0f 85 ce 02 00 00    	jne    a645 <fwp_write+0x4d5>
    a377:	ba 0a 00 00 00       	mov    $0xa,%edx
    a37c:	48 8d 35 61 2e 00 00 	lea    0x2e61(%rip),%rsi        # d1e4 <_IO_stdin_used+0x1e4>
    a383:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a38a:	48 89 df             	mov    %rbx,%rdi
    a38d:	5b                   	pop    %rbx
    a38e:	5d                   	pop    %rbp
    a38f:	41 5c                	pop    %r12
    a391:	41 5d                	pop    %r13
    a393:	41 5e                	pop    %r14
    a395:	41 5f                	pop    %r15
    a397:	e9 74 9e ff ff       	jmp    4210 <buf_put>
    a39c:	0f 1f 40 00          	nopl   0x0(%rax)
    a3a0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a3a5:	4d 85 ed             	test   %r13,%r13
    a3a8:	0f 84 02 0c 00 00    	je     afb0 <fwp_write+0xe40>
    a3ae:	48 8d 35 77 2e 00 00 	lea    0x2e77(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    a3b5:	4c 89 ef             	mov    %r13,%rdi
    a3b8:	e8 73 91 ff ff       	call   3530 <strcmp@plt>
    a3bd:	41 89 c1             	mov    %eax,%r9d
    a3c0:	85 c0                	test   %eax,%eax
    a3c2:	0f 84 6c 0c 00 00    	je     b034 <fwp_write+0xec4>
    a3c8:	4c 89 ef             	mov    %r13,%rdi
    a3cb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a3d0:	e8 7b 90 ff ff       	call   3450 <strlen@plt>
    a3d5:	4c 89 ee             	mov    %r13,%rsi
    a3d8:	48 89 df             	mov    %rbx,%rdi
    a3db:	48 89 c2             	mov    %rax,%rdx
    a3de:	e8 2d 9e ff ff       	call   4210 <buf_put>
    a3e3:	ba 01 00 00 00       	mov    $0x1,%edx
    a3e8:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a3ed:	48 89 df             	mov    %rbx,%rdi
    a3f0:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a3f5:	e8 16 9e ff ff       	call   4210 <buf_put>
    a3fa:	ba 01 00 00 00       	mov    $0x1,%edx
    a3ff:	4c 89 fe             	mov    %r15,%rsi
    a402:	48 89 df             	mov    %rbx,%rdi
    a405:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a40a:	e8 01 9e ff ff       	call   4210 <buf_put>
    a40f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a414:	45 31 f6             	xor    %r14d,%r14d
    a417:	85 d2                	test   %edx,%edx
    a419:	0f 8e 81 0a 00 00    	jle    aea0 <fwp_write+0xd30>
    a41f:	45 31 ed             	xor    %r13d,%r13d
    a422:	4d 85 ed             	test   %r13,%r13
    a425:	0f 85 75 07 00 00    	jne    aba0 <fwp_write+0xa30>
    a42b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a432:	00 
    a433:	45 85 f6             	test   %r14d,%r14d
    a436:	0f 84 84 07 00 00    	je     abc0 <fwp_write+0xa50>
    a43c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a441:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a446:	48 89 df             	mov    %rbx,%rdi
    a449:	49 83 c5 01          	add    $0x1,%r13
    a44d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a451:	31 c9                	xor    %ecx,%ecx
    a453:	e8 18 fd ff ff       	call   a170 <fwp_write>
    a458:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a45d:	7f c3                	jg     a422 <fwp_write+0x2b2>
    a45f:	45 85 f6             	test   %r14d,%r14d
    a462:	0f 84 38 0a 00 00    	je     aea0 <fwp_write+0xd30>
    a468:	b8 29 00 00 00       	mov    $0x29,%eax
    a46d:	ba 01 00 00 00       	mov    $0x1,%edx
    a472:	4c 89 fe             	mov    %r15,%rsi
    a475:	48 89 df             	mov    %rbx,%rdi
    a478:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a47c:	e8 8f 9d ff ff       	call   4210 <buf_put>
    a481:	e9 80 fd ff ff       	jmp    a206 <fwp_write+0x96>
    a486:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a48d:	00 00 00 
    a490:	ba 01 00 00 00       	mov    $0x1,%edx
    a495:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a49a:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a49f:	e8 6c 9d ff ff       	call   4210 <buf_put>
    a4a4:	48 85 ed             	test   %rbp,%rbp
    a4a7:	0f 84 93 06 00 00    	je     ab40 <fwp_write+0x9d0>
    a4ad:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a4b1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a4b6:	31 c9                	xor    %ecx,%ecx
    a4b8:	48 89 df             	mov    %rbx,%rdi
    a4bb:	e8 b0 fc ff ff       	call   a170 <fwp_write>
    a4c0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a4c4:	48 85 ed             	test   %rbp,%rbp
    a4c7:	0f 84 73 06 00 00    	je     ab40 <fwp_write+0x9d0>
    a4cd:	ba 02 00 00 00       	mov    $0x2,%edx
    a4d2:	48 8d 35 46 2d 00 00 	lea    0x2d46(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a4d9:	48 89 df             	mov    %rbx,%rdi
    a4dc:	e8 2f 9d ff ff       	call   4210 <buf_put>
    a4e1:	eb ca                	jmp    a4ad <fwp_write+0x33d>
    a4e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a4e8:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a4ec:	85 f6                	test   %esi,%esi
    a4ee:	0f 84 fc 07 00 00    	je     acf0 <fwp_write+0xb80>
    a4f4:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a4fb:	00 
    a4fc:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a503:	00 00 
    a505:	0f 85 3a 01 00 00    	jne    a645 <fwp_write+0x4d5>
    a50b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a50f:	4c 89 ea             	mov    %r13,%rdx
    a512:	e9 6c fe ff ff       	jmp    a383 <fwp_write+0x213>
    a517:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a51e:	00 00 
    a520:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a525:	ba 01 00 00 00       	mov    $0x1,%edx
    a52a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a52f:	48 89 ee             	mov    %rbp,%rsi
    a532:	e8 d9 9c ff ff       	call   4210 <buf_put>
    a537:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a53c:	4c 89 e7             	mov    %r12,%rdi
    a53f:	e8 0c 8f ff ff       	call   3450 <strlen@plt>
    a544:	4c 89 e6             	mov    %r12,%rsi
    a547:	48 89 df             	mov    %rbx,%rdi
    a54a:	48 89 c2             	mov    %rax,%rdx
    a54d:	e8 be 9c ff ff       	call   4210 <buf_put>
    a552:	ba 01 00 00 00       	mov    $0x1,%edx
    a557:	48 89 ee             	mov    %rbp,%rsi
    a55a:	48 89 df             	mov    %rbx,%rdi
    a55d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a562:	e8 a9 9c ff ff       	call   4210 <buf_put>
    a567:	e9 9a fc ff ff       	jmp    a206 <fwp_write+0x96>
    a56c:	0f 1f 40 00          	nopl   0x0(%rax)
    a570:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a575:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a579:	0f 8a 8e 0b 00 00    	jp     b10d <fwp_write+0xf9d>
    a57f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a583:	66 0f 54 05 75 36 00 	andpd  0x3675(%rip),%xmm0        # dc00 <msg.4+0x90>
    a58a:	00 
    a58b:	bd 01 00 00 00       	mov    $0x1,%ebp
    a590:	66 0f 2e 05 b0 36 00 	ucomisd 0x36b0(%rip),%xmm0        # dc48 <msg.4+0xd8>
    a597:	00 
    a598:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a59f:	00 
    a5a0:	0f 87 b2 09 00 00    	ja     af58 <fwp_write+0xde8>
    a5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a5ad:	00 00 00 
    a5b0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a5b4:	89 ee                	mov    %ebp,%esi
    a5b6:	4c 89 e7             	mov    %r12,%rdi
    a5b9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a5be:	e8 4d a1 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a5c3:	31 f6                	xor    %esi,%esi
    a5c5:	4c 89 e7             	mov    %r12,%rdi
    a5c8:	e8 43 8e ff ff       	call   3410 <strtod@plt>
    a5cd:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a5d2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a5d6:	7a 06                	jp     a5de <fwp_write+0x46e>
    a5d8:	0f 84 e9 01 00 00    	je     a7c7 <fwp_write+0x657>
    a5de:	83 c5 01             	add    $0x1,%ebp
    a5e1:	83 fd 12             	cmp    $0x12,%ebp
    a5e4:	75 ca                	jne    a5b0 <fwp_write+0x440>
    a5e6:	be 11 00 00 00       	mov    $0x11,%esi
    a5eb:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a5ef:	4c 89 e7             	mov    %r12,%rdi
    a5f2:	e8 19 a1 ff ff       	call   4710 <fwp_format_g.constprop.0>
    a5f7:	e9 cb 01 00 00       	jmp    a7c7 <fwp_write+0x657>
    a5fc:	0f 1f 40 00          	nopl   0x0(%rax)
    a600:	48 83 fd 01          	cmp    $0x1,%rbp
    a604:	0f 84 e6 08 00 00    	je     aef0 <fwp_write+0xd80>
    a60a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a60e:	b8 02 00 00 00       	mov    $0x2,%eax
    a613:	ba 01 00 00 00       	mov    $0x1,%edx
    a618:	48 0f 44 d0          	cmove  %rax,%rdx
    a61c:	48 8d 35 aa 2b 00 00 	lea    0x2baa(%rip),%rsi        # d1cd <_IO_stdin_used+0x1cd>
    a623:	48 8d 05 a8 2b 00 00 	lea    0x2ba8(%rip),%rax        # d1d2 <_IO_stdin_used+0x1d2>
    a62a:	48 0f 44 f0          	cmove  %rax,%rsi
    a62e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a635:	00 
    a636:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a63d:	00 00 
    a63f:	0f 84 3e fd ff ff    	je     a383 <fwp_write+0x213>
    a645:	e8 16 8e ff ff       	call   3460 <__stack_chk_fail@plt>
    a64a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a650:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a655:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a65a:	e8 f1 9a ff ff       	call   4150 <buf_grow>
    a65f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a663:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a669:	4c 03 0b             	add    (%rbx),%r9
    a66c:	66 45 89 11          	mov    %r10w,(%r9)
    a670:	45 85 e4             	test   %r12d,%r12d
    a673:	0f 8e 07 05 00 00    	jle    ab80 <fwp_write+0xa10>
    a679:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a680:	55 55 55 
    a683:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a688:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a68f:	aa aa aa 
    a692:	49 83 c1 01          	add    $0x1,%r9
    a696:	eb 45                	jmp    a6dd <fwp_write+0x56d>
    a698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a69f:	00 
    a6a0:	be 01 00 00 00       	mov    $0x1,%esi
    a6a5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a6aa:	88 07                	mov    %al,(%rdi)
    a6ac:	48 89 e8             	mov    %rbp,%rax
    a6af:	49 f7 e8             	imul   %r8
    a6b2:	48 89 e8             	mov    %rbp,%rax
    a6b5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a6b9:	48 29 c2             	sub    %rax,%rdx
    a6bc:	48 85 c9             	test   %rcx,%rcx
    a6bf:	0f 95 c0             	setne  %al
    a6c2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a6c6:	48 83 ef 01          	sub    $0x1,%rdi
    a6ca:	48 21 c5             	and    %rax,%rbp
    a6cd:	48 29 ea             	sub    %rbp,%rdx
    a6d0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a6d4:	49 39 f9             	cmp    %rdi,%r9
    a6d7:	0f 84 a3 04 00 00    	je     ab80 <fwp_write+0xa10>
    a6dd:	48 89 e8             	mov    %rbp,%rax
    a6e0:	49 f7 e8             	imul   %r8
    a6e3:	48 89 e8             	mov    %rbp,%rax
    a6e6:	48 c1 f8 3f          	sar    $0x3f,%rax
    a6ea:	48 89 d1             	mov    %rdx,%rcx
    a6ed:	48 29 c1             	sub    %rax,%rcx
    a6f0:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a6f4:	48 89 e9             	mov    %rbp,%rcx
    a6f7:	48 29 c1             	sub    %rax,%rcx
    a6fa:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a6fe:	49 f7 e2             	mul    %r10
    a701:	b8 30 00 00 00       	mov    $0x30,%eax
    a706:	48 89 d6             	mov    %rdx,%rsi
    a709:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a70d:	48 d1 ee             	shr    $1,%rsi
    a710:	48 01 f2             	add    %rsi,%rdx
    a713:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a717:	48 29 d6             	sub    %rdx,%rsi
    a71a:	74 8e                	je     a6aa <fwp_write+0x53a>
    a71c:	48 83 fe 01          	cmp    $0x1,%rsi
    a720:	0f 85 7a ff ff ff    	jne    a6a0 <fwp_write+0x530>
    a726:	31 f6                	xor    %esi,%esi
    a728:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a72d:	e9 78 ff ff ff       	jmp    a6aa <fwp_write+0x53a>
    a732:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a738:	66 0f 6e cd          	movd   %ebp,%xmm1
    a73c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a73f:	0f 8a c8 09 00 00    	jp     b10d <fwp_write+0xf9d>
    a745:	0f 28 c1             	movaps %xmm1,%xmm0
    a748:	0f 54 05 a1 34 00 00 	andps  0x34a1(%rip),%xmm0        # dbf0 <msg.4+0x80>
    a74f:	0f 2e 05 ae 28 00 00 	ucomiss 0x28ae(%rip),%xmm0        # d004 <_IO_stdin_used+0x4>
    a756:	0f 87 24 08 00 00    	ja     af80 <fwp_write+0xe10>
    a75c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a760:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a766:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a76d:	00 
    a76e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a772:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a777:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a77e:	00 00 
    a780:	44 89 ee             	mov    %r13d,%esi
    a783:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a788:	4c 89 e7             	mov    %r12,%rdi
    a78b:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a790:	e8 7b 9f ff ff       	call   4710 <fwp_format_g.constprop.0>
    a795:	31 f6                	xor    %esi,%esi
    a797:	4c 89 e7             	mov    %r12,%rdi
    a79a:	e8 11 8d ff ff       	call   34b0 <strtof@plt>
    a79f:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a7a4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a7a7:	7a 02                	jp     a7ab <fwp_write+0x63b>
    a7a9:	74 1c                	je     a7c7 <fwp_write+0x657>
    a7ab:	41 83 c5 01          	add    $0x1,%r13d
    a7af:	41 83 fd 0a          	cmp    $0xa,%r13d
    a7b3:	75 cb                	jne    a780 <fwp_write+0x610>
    a7b5:	be 09 00 00 00       	mov    $0x9,%esi
    a7ba:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a7bf:	4c 89 e7             	mov    %r12,%rdi
    a7c2:	e8 49 9f ff ff       	call   4710 <fwp_format_g.constprop.0>
    a7c7:	4c 89 e7             	mov    %r12,%rdi
    a7ca:	e8 b1 9b ff ff       	call   4380 <fwp_finish_float>
    a7cf:	e9 1c fa ff ff       	jmp    a1f0 <fwp_write+0x80>
    a7d4:	0f 1f 40 00          	nopl   0x0(%rax)
    a7d8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a7dc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a7e0:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a7e7:	00 
    a7e8:	48 89 ef             	mov    %rbp,%rdi
    a7eb:	e8 50 92 ff ff       	call   3a40 <fwp_fmt_u128>
    a7f0:	48 89 ef             	mov    %rbp,%rdi
    a7f3:	e8 58 8c ff ff       	call   3450 <strlen@plt>
    a7f8:	48 89 ee             	mov    %rbp,%rsi
    a7fb:	48 89 df             	mov    %rbx,%rdi
    a7fe:	48 89 c2             	mov    %rax,%rdx
    a801:	e8 0a 9a ff ff       	call   4210 <buf_put>
    a806:	e9 fb f9 ff ff       	jmp    a206 <fwp_write+0x96>
    a80b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a810:	ba 06 00 00 00       	mov    $0x6,%edx
    a815:	48 8d 35 06 2a 00 00 	lea    0x2a06(%rip),%rsi        # d222 <_IO_stdin_used+0x222>
    a81c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a822:	e8 e9 99 ff ff       	call   4210 <buf_put>
    a827:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a82e:	ff ff 7f 
    a831:	48 23 55 00          	and    0x0(%rbp),%rdx
    a835:	0f 84 86 02 00 00    	je     aac1 <fwp_write+0x951>
    a83b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a840:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a844:	48 85 d2             	test   %rdx,%rdx
    a847:	0f 84 ae 00 00 00    	je     a8fb <fwp_write+0x78b>
    a84d:	8b 0a                	mov    (%rdx),%ecx
    a84f:	83 f9 1c             	cmp    $0x1c,%ecx
    a852:	0f 84 58 06 00 00    	je     aeb0 <fwp_write+0xd40>
    a858:	83 f9 1b             	cmp    $0x1b,%ecx
    a85b:	0f 87 9a 00 00 00    	ja     a8fb <fwp_write+0x78b>
    a861:	be 01 00 00 00       	mov    $0x1,%esi
    a866:	48 d3 e6             	shl    %cl,%rsi
    a869:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a86f:	0f 85 4b 04 00 00    	jne    acc0 <fwp_write+0xb50>
    a875:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a87b:	0f 85 0f 04 00 00    	jne    ac90 <fwp_write+0xb20>
    a881:	83 e6 21             	and    $0x21,%esi
    a884:	74 75                	je     a8fb <fwp_write+0x78b>
    a886:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a88b:	48 85 ff             	test   %rdi,%rdi
    a88e:	79 07                	jns    a897 <fwp_write+0x727>
    a890:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a894:	4c 01 ee             	add    %r13,%rsi
    a897:	48 0f be 3e          	movsbq (%rsi),%rdi
    a89b:	85 c9                	test   %ecx,%ecx
    a89d:	40 0f b6 f7          	movzbl %dil,%esi
    a8a1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a8a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a8ac:	00 00 00 00 
    a8b0:	31 c9                	xor    %ecx,%ecx
    a8b2:	48 89 df             	mov    %rbx,%rdi
    a8b5:	49 83 c5 01          	add    $0x1,%r13
    a8b9:	e8 b2 f8 ff ff       	call   a170 <fwp_write>
    a8be:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a8c5:	ff ff 7f 
    a8c8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a8cc:	49 39 d5             	cmp    %rdx,%r13
    a8cf:	0f 83 ec 01 00 00    	jae    aac1 <fwp_write+0x951>
    a8d5:	ba 02 00 00 00       	mov    $0x2,%edx
    a8da:	48 89 df             	mov    %rbx,%rdi
    a8dd:	48 8d 35 3b 29 00 00 	lea    0x293b(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    a8e4:	e8 27 99 ff ff       	call   4210 <buf_put>
    a8e9:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a8ee:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a8f2:	48 85 d2             	test   %rdx,%rdx
    a8f5:	0f 85 52 ff ff ff    	jne    a84d <fwp_write+0x6dd>
    a8fb:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a900:	48 85 ff             	test   %rdi,%rdi
    a903:	0f 88 cf 05 00 00    	js     aed8 <fwp_write+0xd68>
    a909:	48 8b 31             	mov    (%rcx),%rsi
    a90c:	eb a2                	jmp    a8b0 <fwp_write+0x740>
    a90e:	66 90                	xchg   %ax,%ax
    a910:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a917:	00 
    a918:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a91f:	00 00 
    a921:	0f 85 1e fd ff ff    	jne    a645 <fwp_write+0x4d5>
    a927:	ba 08 00 00 00       	mov    $0x8,%edx
    a92c:	48 8d 35 bc 28 00 00 	lea    0x28bc(%rip),%rsi        # d1ef <_IO_stdin_used+0x1ef>
    a933:	e9 4b fa ff ff       	jmp    a383 <fwp_write+0x213>
    a938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a93f:	00 
    a940:	89 e8                	mov    %ebp,%eax
    a942:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a949:	76 03                	jbe    a94e <fwp_write+0x7de>
    a94b:	8b 45 00             	mov    0x0(%rbp),%eax
    a94e:	41 89 c6             	mov    %eax,%r14d
    a951:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a956:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a95b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a95f:	4c 89 ef             	mov    %r13,%rdi
    a962:	e8 e9 8a ff ff       	call   3450 <strlen@plt>
    a967:	4c 89 ee             	mov    %r13,%rsi
    a96a:	48 89 df             	mov    %rbx,%rdi
    a96d:	48 89 c2             	mov    %rax,%rdx
    a970:	e8 9b 98 ff ff       	call   4210 <buf_put>
    a975:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a97a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a97e:	85 f6                	test   %esi,%esi
    a980:	0f 8e 80 f8 ff ff    	jle    a206 <fwp_write+0x96>
    a986:	45 31 ed             	xor    %r13d,%r13d
    a989:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a98e:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a993:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a998:	ba 01 00 00 00       	mov    $0x1,%edx
    a99d:	4c 89 fe             	mov    %r15,%rsi
    a9a0:	48 89 04 24          	mov    %rax,(%rsp)
    a9a4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a9a9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a9ad:	48 89 df             	mov    %rbx,%rdi
    a9b0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a9b4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a9b9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a9be:	e8 4d 98 ff ff       	call   4210 <buf_put>
    a9c3:	41 8b 06             	mov    (%r14),%eax
    a9c6:	83 f8 0e             	cmp    $0xe,%eax
    a9c9:	0f 84 71 02 00 00    	je     ac40 <fwp_write+0xad0>
    a9cf:	83 f8 10             	cmp    $0x10,%eax
    a9d2:	0f 84 38 02 00 00    	je     ac10 <fwp_write+0xaa0>
    a9d8:	83 f8 0a             	cmp    $0xa,%eax
    a9db:	0f 84 7f 04 00 00    	je     ae60 <fwp_write+0xcf0>
    a9e1:	0f 8f f9 00 00 00    	jg     aae0 <fwp_write+0x970>
    a9e7:	83 f8 03             	cmp    $0x3,%eax
    a9ea:	0f 8f 50 04 00 00    	jg     ae40 <fwp_write+0xcd0>
    a9f0:	85 c0                	test   %eax,%eax
    a9f2:	78 10                	js     aa04 <fwp_write+0x894>
    a9f4:	48 8b 04 24          	mov    (%rsp),%rax
    a9f8:	48 c1 e8 3f          	shr    $0x3f,%rax
    a9fc:	85 c0                	test   %eax,%eax
    a9fe:	0f 85 f9 00 00 00    	jne    aafd <fwp_write+0x98d>
    aa04:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    aa09:	48 8b 34 24          	mov    (%rsp),%rsi
    aa0d:	31 c9                	xor    %ecx,%ecx
    aa0f:	48 89 df             	mov    %rbx,%rdi
    aa12:	e8 59 f7 ff ff       	call   a170 <fwp_write>
    aa17:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    aa1c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    aa21:	49 83 c5 01          	add    $0x1,%r13
    aa25:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    aa29:	0f 8f 5f ff ff ff    	jg     a98e <fwp_write+0x81e>
    aa2f:	e9 d2 f7 ff ff       	jmp    a206 <fwp_write+0x96>
    aa34:	0f 1f 40 00          	nopl   0x0(%rax)
    aa38:	ba 06 00 00 00       	mov    $0x6,%edx
    aa3d:	48 8d 35 d1 27 00 00 	lea    0x27d1(%rip),%rsi        # d215 <_IO_stdin_used+0x215>
    aa44:	45 31 ed             	xor    %r13d,%r13d
    aa47:	e8 c4 97 ff ff       	call   4210 <buf_put>
    aa4c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    aa51:	75 19                	jne    aa6c <fwp_write+0x8fc>
    aa53:	eb 6c                	jmp    aac1 <fwp_write+0x951>
    aa55:	0f 1f 00             	nopl   (%rax)
    aa58:	ba 02 00 00 00       	mov    $0x2,%edx
    aa5d:	48 8d 35 bb 27 00 00 	lea    0x27bb(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    aa64:	48 89 df             	mov    %rbx,%rdi
    aa67:	e8 a4 97 ff ff       	call   4210 <buf_put>
    aa6c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    aa72:	b9 00 02 00 00       	mov    $0x200,%ecx
    aa77:	31 c0                	xor    %eax,%eax
    aa79:	49 83 c5 01          	add    $0x1,%r13
    aa7d:	4c 8d 05 98 27 00 00 	lea    0x2798(%rip),%r8        # d21c <_IO_stdin_used+0x21c>
    aa84:	ba 02 00 00 00       	mov    $0x2,%edx
    aa89:	be 00 02 00 00       	mov    $0x200,%esi
    aa8e:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aa95:	00 
    aa96:	e8 15 89 ff ff       	call   33b0 <__snprintf_chk@plt>
    aa9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    aaa2:	00 
    aaa3:	e8 a8 89 ff ff       	call   3450 <strlen@plt>
    aaa8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    aaaf:	00 
    aab0:	48 89 df             	mov    %rbx,%rdi
    aab3:	48 89 c2             	mov    %rax,%rdx
    aab6:	e8 55 97 ff ff       	call   4210 <buf_put>
    aabb:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    aabf:	72 97                	jb     aa58 <fwp_write+0x8e8>
    aac1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aac6:	ba 01 00 00 00       	mov    $0x1,%edx
    aacb:	48 89 df             	mov    %rbx,%rdi
    aace:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    aad3:	e8 38 97 ff ff       	call   4210 <buf_put>
    aad8:	e9 29 f7 ff ff       	jmp    a206 <fwp_write+0x96>
    aadd:	0f 1f 00             	nopl   (%rax)
    aae0:	83 f8 0b             	cmp    $0xb,%eax
    aae3:	0f 85 1b ff ff ff    	jne    aa04 <fwp_write+0x894>
    aae9:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    aaee:	66 0f 50 c3          	movmskpd %xmm3,%eax
    aaf2:	83 e0 01             	and    $0x1,%eax
    aaf5:	85 c0                	test   %eax,%eax
    aaf7:	0f 84 07 ff ff ff    	je     aa04 <fwp_write+0x894>
    aafd:	4c 89 fe             	mov    %r15,%rsi
    ab00:	48 89 df             	mov    %rbx,%rdi
    ab03:	ba 01 00 00 00       	mov    $0x1,%edx
    ab08:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ab0d:	e8 fe 96 ff ff       	call   4210 <buf_put>
    ab12:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    ab17:	48 8b 34 24          	mov    (%rsp),%rsi
    ab1b:	31 c9                	xor    %ecx,%ecx
    ab1d:	48 89 df             	mov    %rbx,%rdi
    ab20:	e8 4b f6 ff ff       	call   a170 <fwp_write>
    ab25:	ba 01 00 00 00       	mov    $0x1,%edx
    ab2a:	4c 89 fe             	mov    %r15,%rsi
    ab2d:	48 89 df             	mov    %rbx,%rdi
    ab30:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    ab35:	e8 d6 96 ff ff       	call   4210 <buf_put>
    ab3a:	e9 d8 fe ff ff       	jmp    aa17 <fwp_write+0x8a7>
    ab3f:	90                   	nop
    ab40:	ba 01 00 00 00       	mov    $0x1,%edx
    ab45:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab4a:	48 89 df             	mov    %rbx,%rdi
    ab4d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    ab52:	e8 b9 96 ff ff       	call   4210 <buf_put>
    ab57:	e9 aa f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab5c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab60:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ab65:	ba 01 00 00 00       	mov    $0x1,%edx
    ab6a:	48 89 df             	mov    %rbx,%rdi
    ab6d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    ab72:	e8 99 96 ff ff       	call   4210 <buf_put>
    ab77:	e9 8a f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab7c:	0f 1f 40 00          	nopl   0x0(%rax)
    ab80:	48 8b 43 08          	mov    0x8(%rbx),%rax
    ab84:	48 8b 13             	mov    (%rbx),%rdx
    ab87:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    ab8c:	48 89 43 08          	mov    %rax,0x8(%rbx)
    ab90:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    ab94:	e9 6d f6 ff ff       	jmp    a206 <fwp_write+0x96>
    ab99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aba0:	ba 02 00 00 00       	mov    $0x2,%edx
    aba5:	48 8d 35 73 26 00 00 	lea    0x2673(%rip),%rsi        # d21f <_IO_stdin_used+0x21f>
    abac:	48 89 df             	mov    %rbx,%rdi
    abaf:	e8 5c 96 ff ff       	call   4210 <buf_put>
    abb4:	e9 72 f8 ff ff       	jmp    a42b <fwp_write+0x2bb>
    abb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abc0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    abc5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    abca:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    abce:	48 89 f7             	mov    %rsi,%rdi
    abd1:	48 89 34 24          	mov    %rsi,(%rsp)
    abd5:	e8 76 88 ff ff       	call   3450 <strlen@plt>
    abda:	48 8b 34 24          	mov    (%rsp),%rsi
    abde:	48 89 df             	mov    %rbx,%rdi
    abe1:	48 89 c2             	mov    %rax,%rdx
    abe4:	e8 27 96 ff ff       	call   4210 <buf_put>
    abe9:	ba 03 00 00 00       	mov    $0x3,%edx
    abee:	48 8d 35 4d 26 00 00 	lea    0x264d(%rip),%rsi        # d242 <_IO_stdin_used+0x242>
    abf5:	48 89 df             	mov    %rbx,%rdi
    abf8:	e8 13 96 ff ff       	call   4210 <buf_put>
    abfd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    ac02:	e9 35 f8 ff ff       	jmp    a43c <fwp_write+0x2cc>
    ac07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    ac0e:	00 00 
    ac10:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    ac15:	48 8b 78 08          	mov    0x8(%rax),%rdi
    ac19:	48 85 ff             	test   %rdi,%rdi
    ac1c:	0f 84 e2 fd ff ff    	je     aa04 <fwp_write+0x894>
    ac22:	48 8d 35 03 26 00 00 	lea    0x2603(%rip),%rsi        # d22c <_IO_stdin_used+0x22c>
    ac29:	e8 02 89 ff ff       	call   3530 <strcmp@plt>
    ac2e:	85 c0                	test   %eax,%eax
    ac30:	0f 95 c0             	setne  %al
    ac33:	0f b6 c0             	movzbl %al,%eax
    ac36:	e9 c1 fd ff ff       	jmp    a9fc <fwp_write+0x88c>
    ac3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    ac40:	31 c0                	xor    %eax,%eax
    ac42:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    ac49:	00 
    ac4a:	0f 97 c0             	seta   %al
    ac4d:	e9 aa fd ff ff       	jmp    a9fc <fwp_write+0x88c>
    ac52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac58:	48 89 df             	mov    %rbx,%rdi
    ac5b:	ba 02 00 00 00       	mov    $0x2,%edx
    ac60:	48 8d 35 c2 25 00 00 	lea    0x25c2(%rip),%rsi        # d229 <_IO_stdin_used+0x229>
    ac67:	e8 a4 95 ff ff       	call   4210 <buf_put>
    ac6c:	4c 89 e8             	mov    %r13,%rax
    ac6f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    ac74:	31 c9                	xor    %ecx,%ecx
    ac76:	48 c1 e0 04          	shl    $0x4,%rax
    ac7a:	48 89 df             	mov    %rbx,%rdi
    ac7d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    ac82:	e8 e9 f4 ff ff       	call   a170 <fwp_write>
    ac87:	e9 5e f6 ff ff       	jmp    a2ea <fwp_write+0x17a>
    ac8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ac90:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    ac95:	48 85 ff             	test   %rdi,%rdi
    ac98:	79 0c                	jns    aca6 <fwp_write+0xb36>
    ac9a:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    aca1:	00 
    aca2:	48 03 75 10          	add    0x10(%rbp),%rsi
    aca6:	48 63 3e             	movslq (%rsi),%rdi
    aca9:	83 f9 02             	cmp    $0x2,%ecx
    acac:	89 fe                	mov    %edi,%esi
    acae:	48 0f 44 f7          	cmove  %rdi,%rsi
    acb2:	e9 f9 fb ff ff       	jmp    a8b0 <fwp_write+0x740>
    acb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    acbe:	00 00 
    acc0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    acc5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    acca:	48 85 ff             	test   %rdi,%rdi
    accd:	0f 88 0f 03 00 00    	js     afe2 <fwp_write+0xe72>
    acd3:	49 0f bf 38          	movswq (%r8),%rdi
    acd7:	83 f9 01             	cmp    $0x1,%ecx
    acda:	0f b7 f7             	movzwl %di,%esi
    acdd:	48 0f 44 f7          	cmove  %rdi,%rsi
    ace1:	e9 ca fb ff ff       	jmp    a8b0 <fwp_write+0x740>
    ace6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aced:	00 00 00 
    acf0:	ba 01 00 00 00       	mov    $0x1,%edx
    acf5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    acfa:	48 83 c5 08          	add    $0x8,%rbp
    acfe:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ad03:	e8 08 95 ff ff       	call   4210 <buf_put>
    ad08:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad0d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    ad12:	4d 85 ed             	test   %r13,%r13
    ad15:	75 46                	jne    ad5d <fwp_write+0xbed>
    ad17:	e9 04 01 00 00       	jmp    ae20 <fwp_write+0xcb0>
    ad1c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad20:	41 80 f9 09          	cmp    $0x9,%r9b
    ad24:	0f 84 d6 00 00 00    	je     ae00 <fwp_write+0xc90>
    ad2a:	41 80 f9 0a          	cmp    $0xa,%r9b
    ad2e:	0f 85 9c 00 00 00    	jne    add0 <fwp_write+0xc60>
    ad34:	ba 02 00 00 00       	mov    $0x2,%edx
    ad39:	48 8d 35 c5 24 00 00 	lea    0x24c5(%rip),%rsi        # d205 <_IO_stdin_used+0x205>
    ad40:	48 89 df             	mov    %rbx,%rdi
    ad43:	e8 c8 94 ff ff       	call   4210 <buf_put>
    ad48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    ad4f:	00 
    ad50:	48 83 c5 01          	add    $0x1,%rbp
    ad54:	49 39 ec             	cmp    %rbp,%r12
    ad57:	0f 84 c3 00 00 00    	je     ae20 <fwp_write+0xcb0>
    ad5d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    ad62:	41 80 f9 0d          	cmp    $0xd,%r9b
    ad66:	74 28                	je     ad90 <fwp_write+0xc20>
    ad68:	7e b6                	jle    ad20 <fwp_write+0xbb0>
    ad6a:	41 80 f9 22          	cmp    $0x22,%r9b
    ad6e:	74 40                	je     adb0 <fwp_write+0xc40>
    ad70:	41 80 f9 5c          	cmp    $0x5c,%r9b
    ad74:	75 5a                	jne    add0 <fwp_write+0xc60>
    ad76:	ba 02 00 00 00       	mov    $0x2,%edx
    ad7b:	48 8d 35 80 24 00 00 	lea    0x2480(%rip),%rsi        # d202 <_IO_stdin_used+0x202>
    ad82:	48 89 df             	mov    %rbx,%rdi
    ad85:	e8 86 94 ff ff       	call   4210 <buf_put>
    ad8a:	eb c4                	jmp    ad50 <fwp_write+0xbe0>
    ad8c:	0f 1f 40 00          	nopl   0x0(%rax)
    ad90:	ba 02 00 00 00       	mov    $0x2,%edx
    ad95:	48 8d 35 6f 24 00 00 	lea    0x246f(%rip),%rsi        # d20b <_IO_stdin_used+0x20b>
    ad9c:	48 89 df             	mov    %rbx,%rdi
    ad9f:	e8 6c 94 ff ff       	call   4210 <buf_put>
    ada4:	eb aa                	jmp    ad50 <fwp_write+0xbe0>
    ada6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adad:	00 00 00 
    adb0:	ba 02 00 00 00       	mov    $0x2,%edx
    adb5:	48 8d 35 43 24 00 00 	lea    0x2443(%rip),%rsi        # d1ff <_IO_stdin_used+0x1ff>
    adbc:	48 89 df             	mov    %rbx,%rdi
    adbf:	e8 4c 94 ff ff       	call   4210 <buf_put>
    adc4:	eb 8a                	jmp    ad50 <fwp_write+0xbe0>
    adc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    adcd:	00 00 00 
    add0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    add4:	0f 86 2e 01 00 00    	jbe    af08 <fwp_write+0xd98>
    adda:	41 80 f9 7f          	cmp    $0x7f,%r9b
    adde:	0f 84 24 01 00 00    	je     af08 <fwp_write+0xd98>
    ade4:	ba 01 00 00 00       	mov    $0x1,%edx
    ade9:	4c 89 fe             	mov    %r15,%rsi
    adec:	48 89 df             	mov    %rbx,%rdi
    adef:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    adf4:	e8 17 94 ff ff       	call   4210 <buf_put>
    adf9:	e9 52 ff ff ff       	jmp    ad50 <fwp_write+0xbe0>
    adfe:	66 90                	xchg   %ax,%ax
    ae00:	ba 02 00 00 00       	mov    $0x2,%edx
    ae05:	48 8d 35 fc 23 00 00 	lea    0x23fc(%rip),%rsi        # d208 <_IO_stdin_used+0x208>
    ae0c:	48 89 df             	mov    %rbx,%rdi
    ae0f:	e8 fc 93 ff ff       	call   4210 <buf_put>
    ae14:	e9 37 ff ff ff       	jmp    ad50 <fwp_write+0xbe0>
    ae19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ae20:	ba 01 00 00 00       	mov    $0x1,%edx
    ae25:	4c 89 fe             	mov    %r15,%rsi
    ae28:	48 89 df             	mov    %rbx,%rdi
    ae2b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ae30:	e8 db 93 ff ff       	call   4210 <buf_put>
    ae35:	e9 cc f3 ff ff       	jmp    a206 <fwp_write+0x96>
    ae3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ae40:	83 f8 04             	cmp    $0x4,%eax
    ae43:	0f 85 bb fb ff ff    	jne    aa04 <fwp_write+0x894>
    ae49:	48 8b 04 24          	mov    (%rsp),%rax
    ae4d:	48 8b 40 08          	mov    0x8(%rax),%rax
    ae51:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ae56:	48 c1 e8 3f          	shr    $0x3f,%rax
    ae5a:	e9 96 fc ff ff       	jmp    aaf5 <fwp_write+0x985>
    ae5f:	90                   	nop
    ae60:	8b 0c 24             	mov    (%rsp),%ecx
    ae63:	31 c0                	xor    %eax,%eax
    ae65:	85 c9                	test   %ecx,%ecx
    ae67:	0f 98 c0             	sets   %al
    ae6a:	e9 86 fc ff ff       	jmp    aaf5 <fwp_write+0x985>
    ae6f:	90                   	nop
    ae70:	48 f7 d8             	neg    %rax
    ae73:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    ae7a:	00 
    ae7b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    ae82:	2d 
    ae83:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae8a:	00 
    ae8b:	48 83 d2 00          	adc    $0x0,%rdx
    ae8f:	48 89 c6             	mov    %rax,%rsi
    ae92:	48 f7 da             	neg    %rdx
    ae95:	e8 a6 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae9a:	e9 51 f3 ff ff       	jmp    a1f0 <fwp_write+0x80>
    ae9f:	90                   	nop
    aea0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    aea5:	e9 c3 f5 ff ff       	jmp    a46d <fwp_write+0x2fd>
    aeaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    aeb0:	4c 89 e9             	mov    %r13,%rcx
    aeb3:	48 c1 e1 04          	shl    $0x4,%rcx
    aeb7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    aebc:	48 85 ff             	test   %rdi,%rdi
    aebf:	0f 89 eb f9 ff ff    	jns    a8b0 <fwp_write+0x740>
    aec5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aec9:	48 89 ce             	mov    %rcx,%rsi
    aecc:	e9 df f9 ff ff       	jmp    a8b0 <fwp_write+0x740>
    aed1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aed8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    aedf:	00 
    aee0:	48 03 4d 10          	add    0x10(%rbp),%rcx
    aee4:	e9 20 fa ff ff       	jmp    a909 <fwp_write+0x799>
    aee9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    aef0:	ba 02 00 00 00       	mov    $0x2,%edx
    aef5:	48 8d 35 d3 22 00 00 	lea    0x22d3(%rip),%rsi        # d1cf <_IO_stdin_used+0x1cf>
    aefc:	e9 2d f7 ff ff       	jmp    a62e <fwp_write+0x4be>
    af01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    af08:	4c 8d 05 ff 22 00 00 	lea    0x22ff(%rip),%r8        # d20e <_IO_stdin_used+0x20e>
    af0f:	b9 10 00 00 00       	mov    $0x10,%ecx
    af14:	31 c0                	xor    %eax,%eax
    af16:	ba 02 00 00 00       	mov    $0x2,%edx
    af1b:	be 10 00 00 00       	mov    $0x10,%esi
    af20:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    af27:	00 
    af28:	e8 83 84 ff ff       	call   33b0 <__snprintf_chk@plt>
    af2d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    af34:	00 
    af35:	e8 16 85 ff ff       	call   3450 <strlen@plt>
    af3a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    af41:	00 
    af42:	48 89 df             	mov    %rbx,%rdi
    af45:	48 89 c2             	mov    %rax,%rdx
    af48:	e8 c3 92 ff ff       	call   4210 <buf_put>
    af4d:	e9 fe fd ff ff       	jmp    ad50 <fwp_write+0xbe0>
    af52:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    af58:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af5c:	48 8d 35 66 22 00 00 	lea    0x2266(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    af63:	48 8d 05 5e 22 00 00 	lea    0x225e(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    af6a:	4c 89 e7             	mov    %r12,%rdi
    af6d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    af71:	48 0f 46 f0          	cmovbe %rax,%rsi
    af75:	e8 76 84 ff ff       	call   33f0 <strcpy@plt>
    af7a:	e9 71 f2 ff ff       	jmp    a1f0 <fwp_write+0x80>
    af7f:	90                   	nop
    af80:	66 0f ef c0          	pxor   %xmm0,%xmm0
    af84:	48 8d 35 3e 22 00 00 	lea    0x223e(%rip),%rsi        # d1c9 <_IO_stdin_used+0x1c9>
    af8b:	48 8d 05 36 22 00 00 	lea    0x2236(%rip),%rax        # d1c8 <_IO_stdin_used+0x1c8>
    af92:	0f 2f c8             	comiss %xmm0,%xmm1
    af95:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    af9c:	00 
    af9d:	4c 89 e7             	mov    %r12,%rdi
    afa0:	48 0f 46 f0          	cmovbe %rax,%rsi
    afa4:	e8 47 84 ff ff       	call   33f0 <strcpy@plt>
    afa9:	e9 42 f2 ff ff       	jmp    a1f0 <fwp_write+0x80>
    afae:	66 90                	xchg   %ax,%ax
    afb0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    afb5:	45 85 c0             	test   %r8d,%r8d
    afb8:	75 34                	jne    afee <fwp_write+0xe7e>
    afba:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    afc1:	00 
    afc2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    afc9:	00 00 
    afcb:	0f 85 74 f6 ff ff    	jne    a645 <fwp_write+0x4d5>
    afd1:	ba 02 00 00 00       	mov    $0x2,%edx
    afd6:	48 8d 35 62 22 00 00 	lea    0x2262(%rip),%rsi        # d23f <_IO_stdin_used+0x23f>
    afdd:	e9 a1 f3 ff ff       	jmp    a383 <fwp_write+0x213>
    afe2:	48 03 75 10          	add    0x10(%rbp),%rsi
    afe6:	49 89 f0             	mov    %rsi,%r8
    afe9:	e9 e5 fc ff ff       	jmp    acd3 <fwp_write+0xb63>
    afee:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    aff3:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aff8:	85 ff                	test   %edi,%edi
    affa:	0f 84 fa f3 ff ff    	je     a3fa <fwp_write+0x28a>
    b000:	ba 01 00 00 00       	mov    $0x1,%edx
    b005:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    b00a:	48 89 df             	mov    %rbx,%rdi
    b00d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    b012:	e8 f9 91 ff ff       	call   4210 <buf_put>
    b017:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    b01c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    b021:	41 be 01 00 00 00    	mov    $0x1,%r14d
    b027:	85 c0                	test   %eax,%eax
    b029:	0f 8f f0 f3 ff ff    	jg     a41f <fwp_write+0x2af>
    b02f:	e9 34 f4 ff ff       	jmp    a468 <fwp_write+0x2f8>
    b034:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b038:	49 89 c5             	mov    %rax,%r13
    b03b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    b040:	49 89 c4             	mov    %rax,%r12
    b043:	49 c1 fd 3f          	sar    $0x3f,%r13
    b047:	4c 09 e8             	or     %r13,%rax
    b04a:	0f 84 a7 00 00 00    	je     b0f7 <fwp_write+0xf87>
    b050:	48 8d 2d a9 43 00 00 	lea    0x43a9(%rip),%rbp        # f400 <units.1>
    b057:	4d 89 e7             	mov    %r12,%r15
    b05a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    b05e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    b063:	4c 89 ff             	mov    %r15,%rdi
    b066:	4c 89 ee             	mov    %r13,%rsi
    b069:	44 89 0c 24          	mov    %r9d,(%rsp)
    b06d:	48 99                	cqto
    b06f:	48 89 d1             	mov    %rdx,%rcx
    b072:	48 89 c2             	mov    %rax,%rdx
    b075:	e8 96 19 00 00       	call   ca10 <__divmodti4>
    b07a:	44 8b 0c 24          	mov    (%rsp),%r9d
    b07e:	48 89 c1             	mov    %rax,%rcx
    b081:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b086:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    b08b:	0f 84 94 00 00 00    	je     b125 <fwp_write+0xfb5>
    b091:	41 83 c1 01          	add    $0x1,%r9d
    b095:	48 83 c5 10          	add    $0x10,%rbp
    b099:	41 83 f9 05          	cmp    $0x5,%r9d
    b09d:	75 bb                	jne    b05a <fwp_write+0xeea>
    b09f:	4d 85 ed             	test   %r13,%r13
    b0a2:	79 53                	jns    b0f7 <fwp_write+0xf87>
    b0a4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b0a9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b0ae:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b0b3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b0b8:	48 99                	cqto
    b0ba:	48 f7 d8             	neg    %rax
    b0bd:	48 83 d2 00          	adc    $0x0,%rdx
    b0c1:	48 89 c6             	mov    %rax,%rsi
    b0c4:	48 f7 da             	neg    %rdx
    b0c7:	e8 74 89 ff ff       	call   3a40 <fwp_fmt_u128>
    b0cc:	49 89 e8             	mov    %rbp,%r8
    b0cf:	ba 00 02 00 00       	mov    $0x200,%edx
    b0d4:	be 02 00 00 00       	mov    $0x2,%esi
    b0d9:	31 c0                	xor    %eax,%eax
    b0db:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b0e2:	00 
    b0e3:	48 8d 0d 50 21 00 00 	lea    0x2150(%rip),%rcx        # d23a <_IO_stdin_used+0x23a>
    b0ea:	4c 89 e7             	mov    %r12,%rdi
    b0ed:	e8 ee 85 ff ff       	call   36e0 <__sprintf_chk@plt>
    b0f2:	e9 f9 f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b0f7:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b0fc:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    b101:	31 d2                	xor    %edx,%edx
    b103:	48 89 ef             	mov    %rbp,%rdi
    b106:	e8 35 89 ff ff       	call   3a40 <fwp_fmt_u128>
    b10b:	eb bf                	jmp    b0cc <fwp_write+0xf5c>
    b10d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    b114:	4e 61 4e 00 
    b118:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b11f:	00 
    b120:	e9 cb f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b125:	44 89 0c 24          	mov    %r9d,(%rsp)
    b129:	48 89 c8             	mov    %rcx,%rax
    b12c:	48 85 d2             	test   %rdx,%rdx
    b12f:	78 51                	js     b182 <fwp_write+0x1012>
    b131:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b136:	48 89 c6             	mov    %rax,%rsi
    b139:	48 89 ef             	mov    %rbp,%rdi
    b13c:	e8 ff 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b141:	44 8b 0c 24          	mov    (%rsp),%r9d
    b145:	49 63 c1             	movslq %r9d,%rax
    b148:	49 89 e8             	mov    %rbp,%r8
    b14b:	ba 00 02 00 00       	mov    $0x200,%edx
    b150:	be 02 00 00 00       	mov    $0x2,%esi
    b155:	48 c1 e0 04          	shl    $0x4,%rax
    b159:	48 8d 3d a0 42 00 00 	lea    0x42a0(%rip),%rdi        # f400 <units.1>
    b160:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    b167:	00 
    b168:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    b16c:	48 8d 0d c2 20 00 00 	lea    0x20c2(%rip),%rcx        # d235 <_IO_stdin_used+0x235>
    b173:	4c 89 e7             	mov    %r12,%rdi
    b176:	31 c0                	xor    %eax,%eax
    b178:	e8 63 85 ff ff       	call   36e0 <__sprintf_chk@plt>
    b17d:	e9 6e f0 ff ff       	jmp    a1f0 <fwp_write+0x80>
    b182:	48 f7 d8             	neg    %rax
    b185:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    b18a:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    b18f:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    b194:	48 83 d2 00          	adc    $0x0,%rdx
    b198:	48 89 c6             	mov    %rax,%rsi
    b19b:	48 f7 da             	neg    %rdx
    b19e:	e8 9d 88 ff ff       	call   3a40 <fwp_fmt_u128>
    b1a3:	44 8b 0c 24          	mov    (%rsp),%r9d
    b1a7:	eb 9c                	jmp    b145 <fwp_write+0xfd5>
    b1a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000b1b0 <fwp_main_thread>:
    b1b0:	f3 0f 1e fa          	endbr64
    b1b4:	55                   	push   %rbp
    b1b5:	48 89 e5             	mov    %rsp,%rbp
    b1b8:	41 57                	push   %r15
    b1ba:	41 56                	push   %r14
    b1bc:	41 55                	push   %r13
    b1be:	41 54                	push   %r12
    b1c0:	53                   	push   %rbx
    b1c1:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
    b1c8:	44 8b 0d b5 79 01 00 	mov    0x179b5(%rip),%r9d        # 22b84 <fwp_heap+0x13a4>
    b1cf:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    b1d6:	00 00 
    b1d8:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    b1dc:	31 c0                	xor    %eax,%eax
    b1de:	45 85 c9             	test   %r9d,%r9d
    b1e1:	0f 84 42 0e 00 00    	je     c029 <fwp_main_thread+0xe79>
    b1e7:	44 8b 05 9a 79 01 00 	mov    0x1799a(%rip),%r8d        # 22b88 <fwp_heap+0x13a8>
    b1ee:	45 85 c0             	test   %r8d,%r8d
    b1f1:	0f 85 21 0e 00 00    	jne    c018 <fwp_main_thread+0xe68>
    b1f7:	48 8d 05 a2 5e 00 00 	lea    0x5ea2(%rip),%rax        # 110a0 <alt.5>
    b1fe:	31 f6                	xor    %esi,%esi
    b200:	48 8d 9d d0 fe ff ff 	lea    -0x130(%rbp),%rbx
    b207:	48 c7 05 5e 5f 01 00 	movq   $0x40000000,0x15f5e(%rip)        # 21170 <fwp_main_stack_size>
    b20e:	00 00 00 40 
    b212:	48 89 85 f0 fe ff ff 	mov    %rax,-0x110(%rbp)
    b219:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
    b220:	48 89 c7             	mov    %rax,%rdi
    b223:	48 89 1d 4e 5f 01 00 	mov    %rbx,0x15f4e(%rip)        # 21178 <fwp_main_stack_top>
    b22a:	48 c7 85 00 ff ff ff 	movq   $0x10000,-0x100(%rbp)
    b231:	00 00 01 00 
    b235:	c7 85 f8 fe ff ff 00 	movl   $0x0,-0x108(%rbp)
    b23c:	00 00 00 
    b23f:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
    b246:	e8 75 84 ff ff       	call   36c0 <sigaltstack@plt>
    b24b:	85 c0                	test   %eax,%eax
    b24d:	0f 85 66 17 00 00    	jne    c9b9 <fwp_main_thread+0x1809>
    b253:	31 c0                	xor    %eax,%eax
    b255:	b9 12 00 00 00       	mov    $0x12,%ecx
    b25a:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    b261:	f3 48 ab             	rep stos %rax,(%rdi)
    b264:	48 8d 05 85 8a ff ff 	lea    -0x757b(%rip),%rax        # 3cf0 <fwp_segv>
    b26b:	48 8d bd 38 ff ff ff 	lea    -0xc8(%rbp),%rdi
    b272:	c7 45 b8 04 00 00 08 	movl   $0x8000004,-0x48(%rbp)
    b279:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
    b280:	4c 8d ad 30 ff ff ff 	lea    -0xd0(%rbp),%r13
    b287:	e8 f4 82 ff ff       	call   3580 <sigemptyset@plt>
    b28c:	85 c0                	test   %eax,%eax
    b28e:	0f 85 25 17 00 00    	jne    c9b9 <fwp_main_thread+0x1809>
    b294:	31 d2                	xor    %edx,%edx
    b296:	4c 89 ee             	mov    %r13,%rsi
    b299:	bf 0b 00 00 00       	mov    $0xb,%edi
    b29e:	e8 5d 81 ff ff       	call   3400 <sigaction@plt>
    b2a3:	85 c0                	test   %eax,%eax
    b2a5:	0f 85 0e 17 00 00    	jne    c9b9 <fwp_main_thread+0x1809>
    b2ab:	31 d2                	xor    %edx,%edx
    b2ad:	4c 89 ee             	mov    %r13,%rsi
    b2b0:	bf 07 00 00 00       	mov    $0x7,%edi
    b2b5:	e8 46 81 ff ff       	call   3400 <sigaction@plt>
    b2ba:	85 c0                	test   %eax,%eax
    b2bc:	0f 85 f7 16 00 00    	jne    c9b9 <fwp_main_thread+0x1809>
    b2c2:	8b 3d 50 5e 01 00    	mov    0x15e50(%rip),%edi        # 21118 <descent_registered>
    b2c8:	85 ff                	test   %edi,%edi
    b2ca:	0f 84 30 05 00 00    	je     b800 <fwp_main_thread+0x650>
    b2d0:	8b 35 ba 5d 00 00    	mov    0x5dba(%rip),%esi        # 11090 <st.3>
    b2d6:	85 f6                	test   %esi,%esi
    b2d8:	0f 84 4e 05 00 00    	je     b82c <fwp_main_thread+0x67c>
    b2de:	4c 8b 25 db 64 01 00 	mov    0x164db(%rip),%r12        # 217c0 <fwp_cur>
    b2e5:	4d 85 e4             	test   %r12,%r12
    b2e8:	0f 84 c5 01 00 00    	je     b4b3 <fwp_main_thread+0x303>
    b2ee:	45 0f b6 6c 24 52    	movzbl 0x52(%r12),%r13d
    b2f4:	41 c6 44 24 52 01    	movb   $0x1,0x52(%r12)
    b2fa:	4c 89 e3             	mov    %r12,%rbx
    b2fd:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    b303:	0f 84 48 01 00 00    	je     b451 <fwp_main_thread+0x2a1>
    b309:	49 83 7c 24 60 00    	cmpq   $0x0,0x60(%r12)
    b30f:	0f 84 94 02 00 00    	je     b5a9 <fwp_main_thread+0x3f9>
    b315:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    b31b:	0f 84 6c 02 00 00    	je     b58d <fwp_main_thread+0x3dd>
    b321:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b326:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b32a:	0f 85 fa 02 00 00    	jne    b62a <fwp_main_thread+0x47a>
    b330:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b334:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b33b:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b340:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b347:	00 00 00 00 
    b34b:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b352:	48 85 d2             	test   %rdx,%rdx
    b355:	74 07                	je     b35e <fwp_main_thread+0x1ae>
    b357:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b35e:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b363:	48 85 c0             	test   %rax,%rax
    b366:	74 34                	je     b39c <fwp_main_thread+0x1ec>
    b368:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b36c:	48 8b 05 25 64 01 00 	mov    0x16425(%rip),%rax        # 21798 <fwp_timers>
    b373:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b377:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b37e:	00 00 00 00 
    b382:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b389:	48 85 c0             	test   %rax,%rax
    b38c:	74 07                	je     b395 <fwp_main_thread+0x1e5>
    b38e:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b395:	48 89 1d fc 63 01 00 	mov    %rbx,0x163fc(%rip)        # 21798 <fwp_timers>
    b39c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b3a0:	e8 4b c3 ff ff       	call   76f0 <fwp_block>
    b3a5:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b3ac:	48 85 c9             	test   %rcx,%rcx
    b3af:	74 47                	je     b3f8 <fwp_main_thread+0x248>
    b3b1:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b3b8:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b3bf:	48 85 d2             	test   %rdx,%rdx
    b3c2:	0f 84 5a 02 00 00    	je     b622 <fwp_main_thread+0x472>
    b3c8:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b3cf:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b3d6:	48 85 c0             	test   %rax,%rax
    b3d9:	74 07                	je     b3e2 <fwp_main_thread+0x232>
    b3db:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b3e2:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b3e9:	00 00 00 00 
    b3ed:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b3f1:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    b3f8:	48 8b 0d c1 63 01 00 	mov    0x163c1(%rip),%rcx        # 217c0 <fwp_cur>
    b3ff:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b403:	0f 84 11 02 00 00    	je     b61a <fwp_main_thread+0x46a>
    b409:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b410:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b417:	48 85 d2             	test   %rdx,%rdx
    b41a:	0f 84 d4 03 00 00    	je     b7f4 <fwp_main_thread+0x644>
    b420:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b427:	48 85 c0             	test   %rax,%rax
    b42a:	74 07                	je     b433 <fwp_main_thread+0x283>
    b42c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b433:	66 0f ef db          	pxor   %xmm3,%xmm3
    b437:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b43b:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    b442:	48 89 cb             	mov    %rcx,%rbx
    b445:	49 83 7c 24 28 00    	cmpq   $0x0,0x28(%r12)
    b44b:	0f 85 b8 fe ff ff    	jne    b309 <fwp_main_thread+0x159>
    b451:	48 83 3d ff 7f 01 00 	cmpq   $0x0,0x17fff(%rip)        # 23458 <fwp_state_len>
    b458:	00 
    b459:	45 88 6c 24 52       	mov    %r13b,0x52(%r12)
    b45e:	74 63                	je     b4c3 <fwp_main_thread+0x313>
    b460:	48 39 1d 51 63 01 00 	cmp    %rbx,0x16351(%rip)        # 217b8 <fwp_root>
    b467:	c7 05 2f 5c 01 00 00 	movl   $0x0,0x15c2f(%rip)        # 210a0 <fwp_exit_code>
    b46e:	00 00 00 
    b471:	0f 85 93 15 00 00    	jne    ca0a <fwp_main_thread+0x185a>
    b477:	48 85 db             	test   %rbx,%rbx
    b47a:	0f 84 fa 01 00 00    	je     b67a <fwp_main_thread+0x4ca>
    b480:	48 8b 15 01 63 01 00 	mov    0x16301(%rip),%rdx        # 21788 <fwp_tasks_active>
    b487:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b48b:	48 85 d2             	test   %rdx,%rdx
    b48e:	0f 84 e6 01 00 00    	je     b67a <fwp_main_thread+0x4ca>
    b494:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b498:	75 08                	jne    b4a2 <fwp_main_thread+0x2f2>
    b49a:	48 89 d7             	mov    %rdx,%rdi
    b49d:	e8 5e 8e ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b4a2:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b4a9:	48 85 d2             	test   %rdx,%rdx
    b4ac:	75 e6                	jne    b494 <fwp_main_thread+0x2e4>
    b4ae:	e9 aa 00 00 00       	jmp    b55d <fwp_main_thread+0x3ad>
    b4b3:	48 83 3d 9d 7f 01 00 	cmpq   $0x0,0x17f9d(%rip)        # 23458 <fwp_state_len>
    b4ba:	00 
    b4bb:	0f 85 a1 01 00 00    	jne    b662 <fwp_main_thread+0x4b2>
    b4c1:	31 db                	xor    %ebx,%ebx
    b4c3:	48 83 3d 7d 7f 01 00 	cmpq   $0x0,0x17f7d(%rip)        # 23448 <fwp_state_owners>
    b4ca:	00 
    b4cb:	75 93                	jne    b460 <fwp_main_thread+0x2b0>
    b4cd:	48 8b 3d 8c 7f 01 00 	mov    0x17f8c(%rip),%rdi        # 23460 <fwp_state>
    b4d4:	e8 b7 a2 ff ff       	call   5790 <fwp_mem_free>
    b4d9:	48 c7 05 7c 7f 01 00 	movq   $0x0,0x17f7c(%rip)        # 23460 <fwp_state>
    b4e0:	00 00 00 00 
    b4e4:	48 c7 05 61 7f 01 00 	movq   $0x0,0x17f61(%rip)        # 23450 <fwp_state_cap>
    b4eb:	00 00 00 00 
    b4ef:	48 85 db             	test   %rbx,%rbx
    b4f2:	0f 84 28 13 00 00    	je     c820 <fwp_main_thread+0x1670>
    b4f8:	48 39 1d b9 62 01 00 	cmp    %rbx,0x162b9(%rip)        # 217b8 <fwp_root>
    b4ff:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b506:	00 00 00 00 
    b50a:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b511:	00 00 00 00 
    b515:	c7 05 81 5b 01 00 00 	movl   $0x0,0x15b81(%rip)        # 210a0 <fwp_exit_code>
    b51c:	00 00 00 
    b51f:	0f 84 5b ff ff ff    	je     b480 <fwp_main_thread+0x2d0>
    b525:	e9 26 82 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b52a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b530:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b537:	48 89 1d 62 62 01 00 	mov    %rbx,0x16262(%rip)        # 217a0 <fwp_ready_tail>
    b53e:	e8 ad c1 ff ff       	call   76f0 <fwp_block>
    b543:	e8 a8 bf ff ff       	call   74f0 <fwp_free_zombie>
    b548:	48 83 3d 38 62 01 00 	cmpq   $0x0,0x16238(%rip)        # 21788 <fwp_tasks_active>
    b54f:	00 
    b550:	0f 84 24 01 00 00    	je     b67a <fwp_main_thread+0x4ca>
    b556:	48 8b 1d 5b 62 01 00 	mov    0x1625b(%rip),%rbx        # 217b8 <fwp_root>
    b55d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b561:	75 db                	jne    b53e <fwp_main_thread+0x38e>
    b563:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b567:	75 d5                	jne    b53e <fwp_main_thread+0x38e>
    b569:	48 8b 05 30 62 01 00 	mov    0x16230(%rip),%rax        # 217a0 <fwp_ready_tail>
    b570:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b574:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b57b:	00 00 00 00 
    b57f:	48 85 c0             	test   %rax,%rax
    b582:	75 ac                	jne    b530 <fwp_main_thread+0x380>
    b584:	48 89 1d 1d 62 01 00 	mov    %rbx,0x1621d(%rip)        # 217a8 <fwp_ready_head>
    b58b:	eb aa                	jmp    b537 <fwp_main_thread+0x387>
    b58d:	e8 ce 8f ff ff       	call   4560 <fwp_now_ns>
    b592:	49 3b 44 24 60       	cmp    0x60(%r12),%rax
    b597:	7c 10                	jl     b5a9 <fwp_main_thread+0x3f9>
    b599:	41 80 7c 24 50 00    	cmpb   $0x0,0x50(%r12)
    b59f:	75 08                	jne    b5a9 <fwp_main_thread+0x3f9>
    b5a1:	4c 89 e7             	mov    %r12,%rdi
    b5a4:	e8 57 8d ff ff       	call   4300 <fwp_cancel_tree.part.0>
    b5a9:	41 80 7c 24 51 00    	cmpb   $0x0,0x51(%r12)
    b5af:	0f 85 6c fd ff ff    	jne    b321 <fwp_main_thread+0x171>
    b5b5:	49 8b 44 24 60       	mov    0x60(%r12),%rax
    b5ba:	49 8d 54 24 40       	lea    0x40(%r12),%rdx
    b5bf:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b5c3:	0f 85 6b fd ff ff    	jne    b334 <fwp_main_thread+0x184>
    b5c9:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b5cd:	48 85 c9             	test   %rcx,%rcx
    b5d0:	0f 84 5e fd ff ff    	je     b334 <fwp_main_thread+0x184>
    b5d6:	48 85 c0             	test   %rax,%rax
    b5d9:	0f 84 86 13 00 00    	je     c965 <fwp_main_thread+0x17b5>
    b5df:	48 39 c8             	cmp    %rcx,%rax
    b5e2:	48 0f 4f c1          	cmovg  %rcx,%rax
    b5e6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b5ed:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    b5f2:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b5f9:	00 00 00 00 
    b5fd:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b604:	48 85 d2             	test   %rdx,%rdx
    b607:	74 07                	je     b610 <fwp_main_thread+0x460>
    b609:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b610:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b615:	e9 4e fd ff ff       	jmp    b368 <fwp_main_thread+0x1b8>
    b61a:	48 89 cb             	mov    %rcx,%rbx
    b61d:	e9 db fc ff ff       	jmp    b2fd <fwp_main_thread+0x14d>
    b622:	48 89 01             	mov    %rax,(%rcx)
    b625:	e9 ac fd ff ff       	jmp    b3d6 <fwp_main_thread+0x226>
    b62a:	49 8b 44 24 40       	mov    0x40(%r12),%rax
    b62f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b636:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b63d:	00 00 00 00 
    b641:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b648:	48 85 c0             	test   %rax,%rax
    b64b:	0f 84 43 11 00 00    	je     c794 <fwp_main_thread+0x15e4>
    b651:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b658:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    b65d:	e9 3a fd ff ff       	jmp    b39c <fwp_main_thread+0x1ec>
    b662:	48 83 3d 4e 61 01 00 	cmpq   $0x0,0x1614e(%rip)        # 217b8 <fwp_root>
    b669:	00 
    b66a:	c7 05 2c 5a 01 00 00 	movl   $0x0,0x15a2c(%rip)        # 210a0 <fwp_exit_code>
    b671:	00 00 00 
    b674:	0f 85 8b 13 00 00    	jne    ca05 <fwp_main_thread+0x1855>
    b67a:	e8 71 be ff ff       	call   74f0 <fwp_free_zombie>
    b67f:	48 83 3d 21 61 01 00 	cmpq   $0x0,0x16121(%rip)        # 217a8 <fwp_ready_head>
    b686:	00 
    b687:	0f 85 c3 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b68d:	48 83 3d 03 61 01 00 	cmpq   $0x0,0x16103(%rip)        # 21798 <fwp_timers>
    b694:	00 
    b695:	0f 85 b5 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b69b:	8b 05 e3 5a 01 00    	mov    0x15ae3(%rip),%eax        # 21184 <fwp_stack_pool_n>
    b6a1:	85 c0                	test   %eax,%eax
    b6a3:	74 37                	je     b6dc <fwp_main_thread+0x52c>
    b6a5:	83 e8 01             	sub    $0x1,%eax
    b6a8:	4c 8d 2d f1 5a 01 00 	lea    0x15af1(%rip),%r13        # 211a0 <fwp_stack_pool>
    b6af:	48 63 d8             	movslq %eax,%rbx
    b6b2:	89 c0                	mov    %eax,%eax
    b6b4:	48 89 da             	mov    %rbx,%rdx
    b6b7:	48 29 c2             	sub    %rax,%rdx
    b6ba:	4c 8d 62 ff          	lea    -0x1(%rdx),%r12
    b6be:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    b6c3:	89 1d bb 5a 01 00    	mov    %ebx,0x15abb(%rip)        # 21184 <fwp_stack_pool_n>
    b6c9:	be 00 00 00 10       	mov    $0x10000000,%esi
    b6ce:	48 83 eb 01          	sub    $0x1,%rbx
    b6d2:	e8 09 7f ff ff       	call   35e0 <munmap@plt>
    b6d7:	4c 39 e3             	cmp    %r12,%rbx
    b6da:	75 e2                	jne    b6be <fwp_main_thread+0x50e>
    b6dc:	8b 3d 42 59 00 00    	mov    0x5942(%rip),%edi        # 11024 <fwp_epfd>
    b6e2:	85 ff                	test   %edi,%edi
    b6e4:	78 05                	js     b6eb <fwp_main_thread+0x53b>
    b6e6:	e8 e5 7d ff ff       	call   34d0 <close@plt>
    b6eb:	4c 8b 2d ae 5c 01 00 	mov    0x15cae(%rip),%r13        # 213a0 <fwp_nfdws>
    b6f2:	4c 8b 25 af 5c 01 00 	mov    0x15caf(%rip),%r12        # 213a8 <fwp_fdws>
    b6f9:	31 db                	xor    %ebx,%ebx
    b6fb:	c7 05 1f 59 00 00 ff 	movl   $0xffffffff,0x591f(%rip)        # 11024 <fwp_epfd>
    b702:	ff ff ff 
    b705:	4d 85 ed             	test   %r13,%r13
    b708:	74 2c                	je     b736 <fwp_main_thread+0x586>
    b70a:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b70e:	48 85 ff             	test   %rdi,%rdi
    b711:	74 1a                	je     b72d <fwp_main_thread+0x57d>
    b713:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b717:	0f 85 33 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b71d:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b722:	0f 85 28 80 ff ff    	jne    3750 <fwp_main_thread.cold>
    b728:	e8 63 a0 ff ff       	call   5790 <fwp_mem_free>
    b72d:	48 83 c3 01          	add    $0x1,%rbx
    b731:	4c 39 eb             	cmp    %r13,%rbx
    b734:	75 d4                	jne    b70a <fwp_main_thread+0x55a>
    b736:	4c 89 e7             	mov    %r12,%rdi
    b739:	e8 52 a0 ff ff       	call   5790 <fwp_mem_free>
    b73e:	48 8b 15 73 60 01 00 	mov    0x16073(%rip),%rdx        # 217b8 <fwp_root>
    b745:	48 c7 05 58 5c 01 00 	movq   $0x0,0x15c58(%rip)        # 213a8 <fwp_fdws>
    b74c:	00 00 00 00 
    b750:	48 c7 05 45 5c 01 00 	movq   $0x0,0x15c45(%rip)        # 213a0 <fwp_nfdws>
    b757:	00 00 00 00 
    b75b:	48 85 d2             	test   %rdx,%rdx
    b75e:	74 4e                	je     b7ae <fwp_main_thread+0x5fe>
    b760:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b765:	0f 85 e5 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b76b:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b772:	00 
    b773:	0f 85 d7 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b779:	48 83 3d d7 7c 01 00 	cmpq   $0x0,0x17cd7(%rip)        # 23458 <fwp_state_len>
    b780:	00 
    b781:	0f 85 c9 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b787:	48 83 3d b9 7c 01 00 	cmpq   $0x0,0x17cb9(%rip)        # 23448 <fwp_state_owners>
    b78e:	00 
    b78f:	0f 85 bb 7f ff ff    	jne    3750 <fwp_main_thread.cold>
    b795:	b9 79 00 00 00       	mov    $0x79,%ecx
    b79a:	31 c0                	xor    %eax,%eax
    b79c:	48 8d 3d 1d 5c 01 00 	lea    0x15c1d(%rip),%rdi        # 213c0 <fwp_root_context>
    b7a3:	f3 48 ab             	rep stos %rax,(%rdi)
    b7a6:	48 89 d7             	mov    %rdx,%rdi
    b7a9:	e8 e2 9f ff ff       	call   5790 <fwp_mem_free>
    b7ae:	48 8b 3d 8b 58 00 00 	mov    0x588b(%rip),%rdi        # 11040 <stdout@GLIBC_2.2.5>
    b7b5:	48 c7 05 00 60 01 00 	movq   $0x0,0x16000(%rip)        # 217c0 <fwp_cur>
    b7bc:	00 00 00 00 
    b7c0:	48 c7 05 ed 5f 01 00 	movq   $0x0,0x15fed(%rip)        # 217b8 <fwp_root>
    b7c7:	00 00 00 00 
    b7cb:	e8 f0 7d ff ff       	call   35c0 <fflush@plt>
    b7d0:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    b7d4:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b7db:	00 00 
    b7dd:	0f 85 d1 11 00 00    	jne    c9b4 <fwp_main_thread+0x1804>
    b7e3:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    b7e7:	31 c0                	xor    %eax,%eax
    b7e9:	5b                   	pop    %rbx
    b7ea:	41 5c                	pop    %r12
    b7ec:	41 5d                	pop    %r13
    b7ee:	41 5e                	pop    %r14
    b7f0:	41 5f                	pop    %r15
    b7f2:	5d                   	pop    %rbp
    b7f3:	c3                   	ret
    b7f4:	48 89 05 9d 5f 01 00 	mov    %rax,0x15f9d(%rip)        # 21798 <fwp_timers>
    b7fb:	e9 27 fc ff ff       	jmp    b427 <fwp_main_thread+0x277>
    b800:	48 8d 3d 09 86 ff ff 	lea    -0x79f7(%rip),%rdi        # 3e10 <descent_phase_report>
    b807:	e8 14 14 00 00       	call   cc20 <atexit>
    b80c:	85 c0                	test   %eax,%eax
    b80e:	0f 85 3d 11 00 00    	jne    c951 <fwp_main_thread+0x17a1>
    b814:	c7 05 fa 58 01 00 01 	movl   $0x1,0x158fa(%rip)        # 21118 <descent_registered>
    b81b:	00 00 00 
    b81e:	8b 35 6c 58 00 00    	mov    0x586c(%rip),%esi        # 11090 <st.3>
    b824:	85 f6                	test   %esi,%esi
    b826:	0f 85 b2 fa ff ff    	jne    b2de <fwp_main_thread+0x12e>
    b82c:	48 8d 05 fd b5 ff ff 	lea    -0x4a03(%rip),%rax        # 6e30 <fwp_drop1>
    b833:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b837:	4c 89 ad b0 fe ff ff 	mov    %r13,-0x150(%rbp)
    b83e:	4c 8b 25 9b 23 00 00 	mov    0x239b(%rip),%r12        # dbe0 <msg.4+0x70>
    b845:	66 48 0f 6e e0       	movq   %rax,%xmm4
    b84a:	45 31 ff             	xor    %r15d,%r15d
    b84d:	48 8b 05 24 7c 01 00 	mov    0x17c24(%rip),%rax        # 23478 <fwp_cleanups>
    b854:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
    b85b:	00 00 00 00 
    b85f:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    b863:	48 89 1d 0e 7c 01 00 	mov    %rbx,0x17c0e(%rip)        # 23478 <fwp_cleanups>
    b86a:	4c 8d 35 6f 5f 01 00 	lea    0x15f6f(%rip),%r14        # 217e0 <fwp_heap>
    b871:	41 bd ff 01 00 00    	mov    $0x1ff,%r13d
    b877:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
    b87e:	48 8d 05 4b 83 ff ff 	lea    -0x7cb5(%rip),%rax        # 3bd0 <fwp_range_release>
    b885:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
    b88c:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
    b893:	0f 29 85 00 ff ff ff 	movaps %xmm0,-0x100(%rbp)
    b89a:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
    b8a1:	e9 0a 01 00 00       	jmp    b9b0 <fwp_main_thread+0x800>
    b8a6:	48 8b 13             	mov    (%rbx),%rdx
    b8a9:	48 f7 d2             	not    %rdx
    b8ac:	48 89 10             	mov    %rdx,(%rax)
    b8af:	49 83 f8 18          	cmp    $0x18,%r8
    b8b3:	76 29                	jbe    b8de <fwp_main_thread+0x72e>
    b8b5:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    b8b9:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    b8bd:	31 f6                	xor    %esi,%esi
    b8bf:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    b8c6:	48 c1 e8 03          	shr    $0x3,%rax
    b8ca:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b8d1:	00 
    b8d2:	e8 e9 7b ff ff       	call   34c0 <memset@plt>
    b8d7:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    b8de:	4c 89 c0             	mov    %r8,%rax
    b8e1:	49 03 86 20 14 00 00 	add    0x1420(%r14),%rax
    b8e8:	0f 82 72 10 00 00    	jb     c960 <fwp_main_thread+0x17b0>
    b8ee:	49 89 86 20 14 00 00 	mov    %rax,0x1420(%r14)
    b8f5:	49 39 86 28 14 00 00 	cmp    %rax,0x1428(%r14)
    b8fc:	73 07                	jae    b905 <fwp_main_thread+0x755>
    b8fe:	49 89 86 28 14 00 00 	mov    %rax,0x1428(%r14)
    b905:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b909:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    b90e:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    b915:	00 00 
    b917:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    b91e:	00 00 
    b920:	4c 89 7b 10          	mov    %r15,0x10(%rbx)
    b924:	48 89 d8             	mov    %rbx,%rax
    b927:	49 89 df             	mov    %rbx,%r15
    b92a:	4c 89 23             	mov    %r12,(%rbx)
    b92d:	4c 89 6b 08          	mov    %r13,0x8(%rbx)
    b931:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    b938:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    b93f:	48 c1 e2 10          	shl    $0x10,%rdx
    b943:	48 39 d0             	cmp    %rdx,%rax
    b946:	73 57                	jae    b99f <fwp_main_thread+0x7ef>
    b948:	48 89 c2             	mov    %rax,%rdx
    b94b:	48 c1 ea 10          	shr    $0x10,%rdx
    b94f:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b953:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    b95a:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b95e:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b962:	48 85 d2             	test   %rdx,%rdx
    b965:	74 38                	je     b99f <fwp_main_thread+0x7ef>
    b967:	0f b6 3e             	movzbl (%rsi),%edi
    b96a:	40 80 ff 02          	cmp    $0x2,%dil
    b96e:	0f 84 a8 00 00 00    	je     ba1c <fwp_main_thread+0x86c>
    b974:	40 80 ff 01          	cmp    $0x1,%dil
    b978:	75 25                	jne    b99f <fwp_main_thread+0x7ef>
    b97a:	8b 7e 18             	mov    0x18(%rsi),%edi
    b97d:	0f b7 c0             	movzwl %ax,%eax
    b980:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b983:	48 0f af c7          	imul   %rdi,%rax
    b987:	48 c1 e8 20          	shr    $0x20,%rax
    b98b:	48 39 f0             	cmp    %rsi,%rax
    b98e:	73 0f                	jae    b99f <fwp_main_thread+0x7ef>
    b990:	48 01 c2             	add    %rax,%rdx
    b993:	80 3a ff             	cmpb   $0xff,(%rdx)
    b996:	0f 84 4e 0e 00 00    	je     c7ea <fwp_main_thread+0x163a>
    b99c:	c6 02 01             	movb   $0x1,(%rdx)
    b99f:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    b9a6:	49 83 ed 01          	sub    $0x1,%r13
    b9aa:	0f 82 86 00 00 00    	jb     ba36 <fwp_main_thread+0x886>
    b9b0:	41 8b 8e a4 13 00 00 	mov    0x13a4(%r14),%ecx
    b9b7:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
    b9be:	85 c9                	test   %ecx,%ecx
    b9c0:	74 46                	je     ba08 <fwp_main_thread+0x858>
    b9c2:	41 0f b6 86 a2 0f 00 	movzbl 0xfa2(%r14),%eax
    b9c9:	00 
    b9ca:	45 8b 84 86 00 0f 00 	mov    0xf00(%r14,%rax,4),%r8d
    b9d1:	00 
    b9d2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b9d6:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
    b9da:	48 8b 18             	mov    (%rax),%rbx
    b9dd:	48 85 db             	test   %rbx,%rbx
    b9e0:	0f 85 c0 fe ff ff    	jne    b8a6 <fwp_main_thread+0x6f6>
    b9e6:	48 8b 58 08          	mov    0x8(%rax),%rbx
    b9ea:	48 85 db             	test   %rbx,%rbx
    b9ed:	74 19                	je     ba08 <fwp_main_thread+0x858>
    b9ef:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b9f3:	48 29 da             	sub    %rbx,%rdx
    b9f6:	4c 39 c2             	cmp    %r8,%rdx
    b9f9:	72 0d                	jb     ba08 <fwp_main_thread+0x858>
    b9fb:	4a 8d 14 03          	lea    (%rbx,%r8,1),%rdx
    b9ff:	48 89 50 08          	mov    %rdx,0x8(%rax)
    ba03:	e9 a7 fe ff ff       	jmp    b8af <fwp_main_thread+0x6ff>
    ba08:	31 f6                	xor    %esi,%esi
    ba0a:	bf 18 00 00 00       	mov    $0x18,%edi
    ba0f:	e8 7c a2 ff ff       	call   5c90 <fwp_heap_alloc>
    ba14:	48 89 c3             	mov    %rax,%rbx
    ba17:	e9 04 ff ff ff       	jmp    b920 <fwp_main_thread+0x770>
    ba1c:	66 85 c0             	test   %ax,%ax
    ba1f:	0f 84 6e ff ff ff    	je     b993 <fwp_main_thread+0x7e3>
    ba25:	48 89 9d f0 fe ff ff 	mov    %rbx,-0x110(%rbp)
    ba2c:	49 83 ed 01          	sub    $0x1,%r13
    ba30:	0f 83 7a ff ff ff    	jae    b9b0 <fwp_main_thread+0x800>
    ba36:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
    ba3d:	66 0f 6f 05 cb 21 00 	movdqa 0x21cb(%rip),%xmm0        # dc10 <msg.4+0xa0>
    ba44:	00 
    ba45:	bf 01 00 00 00       	mov    $0x1,%edi
    ba4a:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
    ba51:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
    ba58:	48 89 05 19 7a 01 00 	mov    %rax,0x17a19(%rip)        # 23478 <fwp_cleanups>
    ba5f:	0f 29 85 30 ff ff ff 	movaps %xmm0,-0xd0(%rbp)
    ba66:	e8 75 af ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    ba6b:	48 8b 15 46 71 01 00 	mov    0x17146(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    ba72:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    ba79:	49 89 c5             	mov    %rax,%r13
    ba7c:	48 2b 05 0d 71 01 00 	sub    0x1710d(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    ba83:	48 c1 e2 10          	shl    $0x10,%rdx
    ba87:	48 39 d0             	cmp    %rdx,%rax
    ba8a:	73 55                	jae    bae1 <fwp_main_thread+0x931>
    ba8c:	48 89 c2             	mov    %rax,%rdx
    ba8f:	48 c1 ea 10          	shr    $0x10,%rdx
    ba93:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba97:	48 8b 15 3a 71 01 00 	mov    0x1713a(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    ba9e:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    baa2:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    baa6:	48 85 db             	test   %rbx,%rbx
    baa9:	74 36                	je     bae1 <fwp_main_thread+0x931>
    baab:	0f b6 0a             	movzbl (%rdx),%ecx
    baae:	80 f9 02             	cmp    $0x2,%cl
    bab1:	0f 84 09 0d 00 00    	je     c7c0 <fwp_main_thread+0x1610>
    bab7:	80 f9 01             	cmp    $0x1,%cl
    baba:	75 25                	jne    bae1 <fwp_main_thread+0x931>
    babc:	8b 4a 18             	mov    0x18(%rdx),%ecx
    babf:	0f b7 c0             	movzwl %ax,%eax
    bac2:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bac5:	48 0f af c1          	imul   %rcx,%rax
    bac9:	48 c1 e8 20          	shr    $0x20,%rax
    bacd:	48 39 d0             	cmp    %rdx,%rax
    bad0:	73 0f                	jae    bae1 <fwp_main_thread+0x931>
    bad2:	48 01 c3             	add    %rax,%rbx
    bad5:	80 3b ff             	cmpb   $0xff,(%rbx)
    bad8:	0f 84 18 0e 00 00    	je     c8f6 <fwp_main_thread+0x1746>
    bade:	c6 03 01             	movb   $0x1,(%rbx)
    bae1:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    bae8:	00 f0 3f 
    baeb:	48 8d b5 20 ff ff ff 	lea    -0xe0(%rbp),%rsi
    baf2:	bf 01 00 00 00       	mov    $0x1,%edi
    baf7:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    bafe:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
    bb05:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
    bb0c:	e8 cf ae ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bb11:	48 8b 15 a0 70 01 00 	mov    0x170a0(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    bb18:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    bb1f:	49 89 c5             	mov    %rax,%r13
    bb22:	48 2b 05 67 70 01 00 	sub    0x17067(%rip),%rax        # 22b90 <fwp_heap+0x13b0>
    bb29:	48 c1 e2 10          	shl    $0x10,%rdx
    bb2d:	48 39 d0             	cmp    %rdx,%rax
    bb30:	73 55                	jae    bb87 <fwp_main_thread+0x9d7>
    bb32:	48 89 c2             	mov    %rax,%rdx
    bb35:	48 c1 ea 10          	shr    $0x10,%rdx
    bb39:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb3d:	48 8b 15 94 70 01 00 	mov    0x17094(%rip),%rdx        # 22bd8 <fwp_heap+0x13f8>
    bb44:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb48:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    bb4c:	48 85 db             	test   %rbx,%rbx
    bb4f:	74 36                	je     bb87 <fwp_main_thread+0x9d7>
    bb51:	0f b6 0a             	movzbl (%rdx),%ecx
    bb54:	80 f9 02             	cmp    $0x2,%cl
    bb57:	0f 84 55 0c 00 00    	je     c7b2 <fwp_main_thread+0x1602>
    bb5d:	80 f9 01             	cmp    $0x1,%cl
    bb60:	75 25                	jne    bb87 <fwp_main_thread+0x9d7>
    bb62:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb65:	0f b7 c0             	movzwl %ax,%eax
    bb68:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb6b:	48 0f af c1          	imul   %rcx,%rax
    bb6f:	48 c1 e8 20          	shr    $0x20,%rax
    bb73:	48 39 d0             	cmp    %rdx,%rax
    bb76:	73 0f                	jae    bb87 <fwp_main_thread+0x9d7>
    bb78:	48 01 c3             	add    %rax,%rbx
    bb7b:	80 3b ff             	cmpb   $0xff,(%rbx)
    bb7e:	0f 84 8d 0d 00 00    	je     c911 <fwp_main_thread+0x1761>
    bb84:	c6 03 01             	movb   $0x1,(%rbx)
    bb87:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    bb8e:	33 f3 bf 
    bb91:	48 8d b5 10 ff ff ff 	lea    -0xf0(%rbp),%rsi
    bb98:	bf 01 00 00 00       	mov    $0x1,%edi
    bb9d:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    bba4:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
    bbab:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
    bbb2:	e8 29 ae ff ff       	call   69e0 <fwp_data.part.0.constprop.0>
    bbb7:	48 8b 15 fa 6f 01 00 	mov    0x16ffa(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    bbbe:	48 8b 0d cb 6f 01 00 	mov    0x16fcb(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    bbc5:	48 89 85 70 fe ff ff 	mov    %rax,-0x190(%rbp)
    bbcc:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    bbd3:	48 89 d6             	mov    %rdx,%rsi
    bbd6:	48 29 c8             	sub    %rcx,%rax
    bbd9:	48 c1 e6 10          	shl    $0x10,%rsi
    bbdd:	48 39 f0             	cmp    %rsi,%rax
    bbe0:	73 65                	jae    bc47 <fwp_main_thread+0xa97>
    bbe2:	48 89 c6             	mov    %rax,%rsi
    bbe5:	48 c1 ee 10          	shr    $0x10,%rsi
    bbe9:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    bbed:	48 8b 35 e4 6f 01 00 	mov    0x16fe4(%rip),%rsi        # 22bd8 <fwp_heap+0x13f8>
    bbf4:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    bbf8:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    bbfc:	48 85 db             	test   %rbx,%rbx
    bbff:	74 46                	je     bc47 <fwp_main_thread+0xa97>
    bc01:	0f b6 3e             	movzbl (%rsi),%edi
    bc04:	40 80 ff 02          	cmp    $0x2,%dil
    bc08:	0f 84 ce 0b 00 00    	je     c7dc <fwp_main_thread+0x162c>
    bc0e:	40 80 ff 01          	cmp    $0x1,%dil
    bc12:	75 33                	jne    bc47 <fwp_main_thread+0xa97>
    bc14:	8b 7e 18             	mov    0x18(%rsi),%edi
    bc17:	0f b7 c0             	movzwl %ax,%eax
    bc1a:	8b 76 1c             	mov    0x1c(%rsi),%esi
    bc1d:	48 0f af c7          	imul   %rdi,%rax
    bc21:	48 c1 e8 20          	shr    $0x20,%rax
    bc25:	48 39 f0             	cmp    %rsi,%rax
    bc28:	73 1d                	jae    bc47 <fwp_main_thread+0xa97>
    bc2a:	48 01 c3             	add    %rax,%rbx
    bc2d:	80 3b ff             	cmpb   $0xff,(%rbx)
    bc30:	0f 84 f6 0c 00 00    	je     c92c <fwp_main_thread+0x177c>
    bc36:	c6 03 01             	movb   $0x1,(%rbx)
    bc39:	48 8b 0d 50 6f 01 00 	mov    0x16f50(%rip),%rcx        # 22b90 <fwp_heap+0x13b0>
    bc40:	48 8b 15 71 6f 01 00 	mov    0x16f71(%rip),%rdx        # 22bb8 <fwp_heap+0x13d8>
    bc47:	48 8d 85 c8 fe ff ff 	lea    -0x138(%rbp),%rax
    bc4e:	4c 89 85 68 fe ff ff 	mov    %r8,-0x198(%rbp)
    bc55:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
    bc5c:	4c 89 85 60 fe ff ff 	mov    %r8,-0x1a0(%rbp)
    bc63:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    bc6a:	48 c1 e2 10          	shl    $0x10,%rdx
    bc6e:	48 29 c8             	sub    %rcx,%rax
    bc71:	48 39 d0             	cmp    %rdx,%rax
    bc74:	73 5d                	jae    bcd3 <fwp_main_thread+0xb23>
    bc76:	48 89 c2             	mov    %rax,%rdx
    bc79:	48 c1 ea 10          	shr    $0x10,%rdx
    bc7d:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bc81:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    bc88:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bc8c:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    bc90:	48 85 ff             	test   %rdi,%rdi
    bc93:	74 3e                	je     bcd3 <fwp_main_thread+0xb23>
    bc95:	0f b6 0a             	movzbl (%rdx),%ecx
    bc98:	80 f9 02             	cmp    $0x2,%cl
    bc9b:	0f 84 2d 0b 00 00    	je     c7ce <fwp_main_thread+0x161e>
    bca1:	80 f9 01             	cmp    $0x1,%cl
    bca4:	75 2d                	jne    bcd3 <fwp_main_thread+0xb23>
    bca6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bca9:	0f b7 c0             	movzwl %ax,%eax
    bcac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bcaf:	48 0f af c1          	imul   %rcx,%rax
    bcb3:	48 c1 e8 20          	shr    $0x20,%rax
    bcb7:	48 39 d0             	cmp    %rdx,%rax
    bcba:	73 17                	jae    bcd3 <fwp_main_thread+0xb23>
    bcbc:	48 01 c7             	add    %rax,%rdi
    bcbf:	0f b6 07             	movzbl (%rdi),%eax
    bcc2:	84 c0                	test   %al,%al
    bcc4:	74 0d                	je     bcd3 <fwp_main_thread+0xb23>
    bcc6:	3c fd                	cmp    $0xfd,%al
    bcc8:	0f 87 79 0c 00 00    	ja     c947 <fwp_main_thread+0x1797>
    bcce:	83 c0 01             	add    $0x1,%eax
    bcd1:	88 07                	mov    %al,(%rdi)
    bcd3:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
    bcda:	48 8b 15 57 77 01 00 	mov    0x17757(%rip),%rdx        # 23438 <fwp_fns>
    bce1:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
    bce8:	48 8d 05 29 53 00 00 	lea    0x5329(%rip),%rax        # 11018 <fc12>
    bcef:	44 8b 28             	mov    (%rax),%r13d
    bcf2:	49 c1 e5 05          	shl    $0x5,%r13
    bcf6:	49 01 d5             	add    %rdx,%r13
    bcf9:	49 8b 4d 18          	mov    0x18(%r13),%rcx
    bcfd:	48 85 c9             	test   %rcx,%rcx
    bd00:	0f 84 6a 0c 00 00    	je     c970 <fwp_main_thread+0x17c0>
    bd06:	48 83 79 18 00       	cmpq   $0x0,0x18(%rcx)
    bd0b:	0f 84 ff 08 00 00    	je     c610 <fwp_main_thread+0x1460>
    bd11:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    bd18:	48 8d 05 f9 52 00 00 	lea    0x52f9(%rip),%rax        # 11018 <fc12>
    bd1f:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bd26:	48 c1 e1 10          	shl    $0x10,%rcx
    bd2a:	48 39 c8             	cmp    %rcx,%rax
    bd2d:	73 5f                	jae    bd8e <fwp_main_thread+0xbde>
    bd2f:	48 89 c1             	mov    %rax,%rcx
    bd32:	48 c1 e9 10          	shr    $0x10,%rcx
    bd36:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    bd3a:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    bd41:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    bd45:	48 8b 79 20          	mov    0x20(%rcx),%rdi
    bd49:	48 85 ff             	test   %rdi,%rdi
    bd4c:	74 40                	je     bd8e <fwp_main_thread+0xbde>
    bd4e:	0f b6 31             	movzbl (%rcx),%esi
    bd51:	40 80 fe 02          	cmp    $0x2,%sil
    bd55:	0f 84 92 09 00 00    	je     c6ed <fwp_main_thread+0x153d>
    bd5b:	40 80 fe 01          	cmp    $0x1,%sil
    bd5f:	75 2d                	jne    bd8e <fwp_main_thread+0xbde>
    bd61:	8b 71 18             	mov    0x18(%rcx),%esi
    bd64:	0f b7 c0             	movzwl %ax,%eax
    bd67:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bd6a:	48 0f af c6          	imul   %rsi,%rax
    bd6e:	48 c1 e8 20          	shr    $0x20,%rax
    bd72:	48 39 c8             	cmp    %rcx,%rax
    bd75:	73 17                	jae    bd8e <fwp_main_thread+0xbde>
    bd77:	48 01 c7             	add    %rax,%rdi
    bd7a:	0f b6 07             	movzbl (%rdi),%eax
    bd7d:	84 c0                	test   %al,%al
    bd7f:	74 0d                	je     bd8e <fwp_main_thread+0xbde>
    bd81:	3c fd                	cmp    $0xfd,%al
    bd83:	0f 87 fa 09 00 00    	ja     c783 <fwp_main_thread+0x15d3>
    bd89:	83 c0 01             	add    $0x1,%eax
    bd8c:	88 07                	mov    %al,(%rdi)
    bd8e:	48 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%rbx
    bd95:	4c 8d 3d 7c 52 00 00 	lea    0x527c(%rip),%r15        # 11018 <fc12>
    bd9c:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    bda3:	00 00 00 
    bda6:	4c 89 f8             	mov    %r15,%rax
    bda9:	48 89 9d a0 fe ff ff 	mov    %rbx,-0x160(%rbp)
    bdb0:	8b 9d 9c fe ff ff    	mov    -0x164(%rbp),%ebx
    bdb6:	41 8b 4d 00          	mov    0x0(%r13),%ecx
    bdba:	4d 89 fa             	mov    %r15,%r10
    bdbd:	2b 48 04             	sub    0x4(%rax),%ecx
    bdc0:	41 8b 07             	mov    (%r15),%eax
    bdc3:	39 d9                	cmp    %ebx,%ecx
    bdc5:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    bdcc:	41 89 cc             	mov    %ecx,%r12d
    bdcf:	0f 46 d9             	cmovbe %ecx,%ebx
    bdd2:	48 c1 e0 05          	shl    $0x5,%rax
    bdd6:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
    bdda:	4c 89 f8             	mov    %r15,%rax
    bddd:	49 8b 50 18          	mov    0x18(%r8),%rdx
    bde1:	89 9d 8c fe ff ff    	mov    %ebx,-0x174(%rbp)
    bde7:	89 9d b8 fe ff ff    	mov    %ebx,-0x148(%rbp)
    bded:	48 85 d2             	test   %rdx,%rdx
    bdf0:	0f 84 61 02 00 00    	je     c057 <fwp_main_thread+0xea7>
    bdf6:	89 8d 88 fe ff ff    	mov    %ecx,-0x178(%rbp)
    bdfc:	eb 66                	jmp    be64 <fwp_main_thread+0xcb4>
    bdfe:	66 90                	xchg   %ax,%ax
    be00:	85 db                	test   %ebx,%ebx
    be02:	0f 84 87 00 00 00    	je     be8f <fwp_main_thread+0xcdf>
    be08:	4c 89 ef             	mov    %r13,%rdi
    be0b:	ff 12                	call   *(%rdx)
    be0d:	4c 89 ff             	mov    %r15,%rdi
    be10:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    be17:	e8 74 b1 ff ff       	call   6f90 <fwp_closure_drop>
    be1c:	44 3b a5 b8 fe ff ff 	cmp    -0x148(%rbp),%r12d
    be23:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    be2a:	0f 84 d0 07 00 00    	je     c600 <fwp_main_thread+0x1450>
    be30:	8b 95 98 fe ff ff    	mov    -0x168(%rbp),%edx
    be36:	44 8b 00             	mov    (%rax),%r8d
    be39:	4f 8d 6c e5 00       	lea    0x0(%r13,%r12,8),%r13
    be3e:	49 89 c2             	mov    %rax,%r10
    be41:	29 da                	sub    %ebx,%edx
    be43:	49 c1 e0 05          	shl    $0x5,%r8
    be47:	4c 03 05 ea 75 01 00 	add    0x175ea(%rip),%r8        # 23438 <fwp_fns>
    be4e:	89 95 b8 fe ff ff    	mov    %edx,-0x148(%rbp)
    be54:	49 8b 50 18          	mov    0x18(%r8),%rdx
    be58:	48 85 d2             	test   %rdx,%rdx
    be5b:	0f 84 ef 01 00 00    	je     c050 <fwp_main_thread+0xea0>
    be61:	49 89 c7             	mov    %rax,%r15
    be64:	41 8b 4a 04          	mov    0x4(%r10),%ecx
    be68:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    be6e:	41 8b 18             	mov    (%r8),%ebx
    be71:	01 c8                	add    %ecx,%eax
    be73:	89 85 98 fe ff ff    	mov    %eax,-0x168(%rbp)
    be79:	39 d8                	cmp    %ebx,%eax
    be7b:	0f 82 cf 04 00 00    	jb     c350 <fwp_main_thread+0x11a0>
    be81:	41 89 dc             	mov    %ebx,%r12d
    be84:	41 29 cc             	sub    %ecx,%r12d
    be87:	85 c9                	test   %ecx,%ecx
    be89:	0f 84 71 ff ff ff    	je     be00 <fwp_main_thread+0xc50>
    be8f:	85 db                	test   %ebx,%ebx
    be91:	b8 01 00 00 00       	mov    $0x1,%eax
    be96:	48 89 e6             	mov    %rsp,%rsi
    be99:	48 89 a5 b0 fe ff ff 	mov    %rsp,-0x150(%rbp)
    bea0:	0f 45 c3             	cmovne %ebx,%eax
    bea3:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    beaa:	00 
    beab:	48 c1 e8 04          	shr    $0x4,%rax
    beaf:	48 c1 e0 04          	shl    $0x4,%rax
    beb3:	48 89 c7             	mov    %rax,%rdi
    beb6:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    bebd:	48 29 fe             	sub    %rdi,%rsi
    bec0:	48 39 f4             	cmp    %rsi,%rsp
    bec3:	74 15                	je     beda <fwp_main_thread+0xd2a>
    bec5:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    becc:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    bed3:	00 00 
    bed5:	48 39 f4             	cmp    %rsi,%rsp
    bed8:	75 eb                	jne    bec5 <fwp_main_thread+0xd15>
    beda:	25 ff 0f 00 00       	and    $0xfff,%eax
    bedf:	48 29 c4             	sub    %rax,%rsp
    bee2:	48 85 c0             	test   %rax,%rax
    bee5:	74 06                	je     beed <fwp_main_thread+0xd3d>
    bee7:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    beed:	89 c8                	mov    %ecx,%eax
    beef:	48 89 a5 a8 fe ff ff 	mov    %rsp,-0x158(%rbp)
    bef6:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
    befd:	00 
    befe:	31 c0                	xor    %eax,%eax
    bf00:	85 c9                	test   %ecx,%ecx
    bf02:	74 35                	je     bf39 <fwp_main_thread+0xd89>
    bf04:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bf0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bf11:	00 00 00 00 
    bf15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bf1c:	00 00 00 00 
    bf20:	49 8b 7c 02 08       	mov    0x8(%r10,%rax,1),%rdi
    bf25:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    bf2c:	49 89 3c 03          	mov    %rdi,(%r11,%rax,1)
    bf30:	48 83 c0 08          	add    $0x8,%rax
    bf34:	48 39 c6             	cmp    %rax,%rsi
    bf37:	75 e7                	jne    bf20 <fwp_main_thread+0xd70>
    bf39:	45 85 e4             	test   %r12d,%r12d
    bf3c:	74 3e                	je     bf7c <fwp_main_thread+0xdcc>
    bf3e:	44 89 e0             	mov    %r12d,%eax
    bf41:	4c 89 ee             	mov    %r13,%rsi
    bf44:	49 8d 44 c5 00       	lea    0x0(%r13,%rax,8),%rax
    bf49:	90                   	nop
    bf4a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bf51:	00 00 00 00 
    bf55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    bf5c:	00 00 00 00 
    bf60:	4c 8b 0e             	mov    (%rsi),%r9
    bf63:	4c 8b 9d a8 fe ff ff 	mov    -0x158(%rbp),%r11
    bf6a:	89 cf                	mov    %ecx,%edi
    bf6c:	48 83 c6 08          	add    $0x8,%rsi
    bf70:	83 c1 01             	add    $0x1,%ecx
    bf73:	4d 89 0c fb          	mov    %r9,(%r11,%rdi,8)
    bf77:	48 39 f0             	cmp    %rsi,%rax
    bf7a:	75 e4                	jne    bf60 <fwp_main_thread+0xdb0>
    bf7c:	49 8b 8e d8 13 00 00 	mov    0x13d8(%r14),%rcx
    bf83:	4c 89 f8             	mov    %r15,%rax
    bf86:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    bf8d:	48 c1 e1 10          	shl    $0x10,%rcx
    bf91:	48 39 c8             	cmp    %rcx,%rax
    bf94:	73 50                	jae    bfe6 <fwp_main_thread+0xe36>
    bf96:	48 89 c1             	mov    %rax,%rcx
    bf99:	48 c1 e9 10          	shr    $0x10,%rcx
    bf9d:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    bfa1:	49 8b 8e f8 13 00 00 	mov    0x13f8(%r14),%rcx
    bfa8:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    bfac:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    bfb0:	48 85 f6             	test   %rsi,%rsi
    bfb3:	74 31                	je     bfe6 <fwp_main_thread+0xe36>
    bfb5:	0f b6 39             	movzbl (%rcx),%edi
    bfb8:	40 80 ff 02          	cmp    $0x2,%dil
    bfbc:	0f 84 86 00 00 00    	je     c048 <fwp_main_thread+0xe98>
    bfc2:	40 80 ff 01          	cmp    $0x1,%dil
    bfc6:	75 1e                	jne    bfe6 <fwp_main_thread+0xe36>
    bfc8:	8b 79 18             	mov    0x18(%rcx),%edi
    bfcb:	0f b7 c0             	movzwl %ax,%eax
    bfce:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    bfd1:	48 0f af c7          	imul   %rdi,%rax
    bfd5:	48 c1 e8 20          	shr    $0x20,%rax
    bfd9:	48 39 c8             	cmp    %rcx,%rax
    bfdc:	73 08                	jae    bfe6 <fwp_main_thread+0xe36>
    bfde:	48 01 c6             	add    %rax,%rsi
    bfe1:	80 3e 01             	cmpb   $0x1,(%rsi)
    bfe4:	74 52                	je     c038 <fwp_main_thread+0xe88>
    bfe6:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    bfed:	be 01 00 00 00       	mov    $0x1,%esi
    bff2:	4c 89 ff             	mov    %r15,%rdi
    bff5:	ff 52 08             	call   *0x8(%rdx)
    bff8:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    bfff:	49 8b 40 18          	mov    0x18(%r8),%rax
    c003:	48 8b bd a8 fe ff ff 	mov    -0x158(%rbp),%rdi
    c00a:	ff 10                	call   *(%rax)
    c00c:	48 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%rsp
    c013:	e9 f5 fd ff ff       	jmp    be0d <fwp_main_thread+0xc5d>
    c018:	48 8d 3d 41 8c ff ff 	lea    -0x73bf(%rip),%rdi        # 4c60 <fwp_heap_report>
    c01f:	e8 fc 0b 00 00       	call   cc20 <atexit>
    c024:	e9 ce f1 ff ff       	jmp    b1f7 <fwp_main_thread+0x47>
    c029:	e8 42 8d ff ff       	call   4d70 <fwp_heap_init>
    c02e:	e9 b4 f1 ff ff       	jmp    b1e7 <fwp_main_thread+0x37>
    c033:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    c038:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    c03f:	00 
    c040:	eb bd                	jmp    bfff <fwp_main_thread+0xe4f>
    c042:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c048:	66 85 c0             	test   %ax,%ax
    c04b:	75 99                	jne    bfe6 <fwp_main_thread+0xe36>
    c04d:	eb 92                	jmp    bfe1 <fwp_main_thread+0xe31>
    c04f:	90                   	nop
    c050:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c057:	48 89 c7             	mov    %rax,%rdi
    c05a:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
    c061:	e8 aa aa ff ff       	call   6b10 <fwp_rc_share>
    c066:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    c06c:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
    c073:	85 d2                	test   %edx,%edx
    c075:	74 35                	je     c0ac <fwp_main_thread+0xefc>
    c077:	89 d1                	mov    %edx,%ecx
    c079:	44 89 a5 b0 fe ff ff 	mov    %r12d,-0x150(%rbp)
    c080:	49 89 c7             	mov    %rax,%r15
    c083:	4d 89 ec             	mov    %r13,%r12
    c086:	49 8d 5c cd 00       	lea    0x0(%r13,%rcx,8),%rbx
    c08b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    c090:	49 8b 3c 24          	mov    (%r12),%rdi
    c094:	49 83 c4 08          	add    $0x8,%r12
    c098:	e8 73 aa ff ff       	call   6b10 <fwp_rc_share>
    c09d:	4c 39 e3             	cmp    %r12,%rbx
    c0a0:	75 ee                	jne    c090 <fwp_main_thread+0xee0>
    c0a2:	44 8b a5 b0 fe ff ff 	mov    -0x150(%rbp),%r12d
    c0a9:	4c 89 f8             	mov    %r15,%rax
    c0ac:	8b b5 b8 fe ff ff    	mov    -0x148(%rbp),%esi
    c0b2:	4c 89 ea             	mov    %r13,%rdx
    c0b5:	48 89 c7             	mov    %rax,%rdi
    c0b8:	e8 f3 9c ff ff       	call   5db0 <fwp_apply>
    c0bd:	49 89 c7             	mov    %rax,%r15
    c0c0:	8b bd 9c fe ff ff    	mov    -0x164(%rbp),%edi
    c0c6:	41 39 fc             	cmp    %edi,%r12d
    c0c9:	0f 83 8c 00 00 00    	jae    c15b <fwp_main_thread+0xfab>
    c0cf:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    c0d6:	8b 85 8c fe ff ff    	mov    -0x174(%rbp),%eax
    c0dc:	45 8b 2f             	mov    (%r15),%r13d
    c0df:	48 89 c6             	mov    %rax,%rsi
    c0e2:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    c0e6:	48 8b 15 4b 73 01 00 	mov    0x1734b(%rip),%rdx        # 23438 <fwp_fns>
    c0ed:	49 c1 e5 05          	shl    $0x5,%r13
    c0f1:	29 f7                	sub    %esi,%edi
    c0f3:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c0fa:	4c 89 f8             	mov    %r15,%rax
    c0fd:	49 01 d5             	add    %rdx,%r13
    c100:	89 bd 9c fe ff ff    	mov    %edi,-0x164(%rbp)
    c106:	49 83 7d 18 00       	cmpq   $0x0,0x18(%r13)
    c10b:	0f 85 9f fc ff ff    	jne    bdb0 <fwp_main_thread+0xc00>
    c111:	4c 89 ff             	mov    %r15,%rdi
    c114:	e8 f7 a9 ff ff       	call   6b10 <fwp_rc_share>
    c119:	44 8b a5 9c fe ff ff 	mov    -0x164(%rbp),%r12d
    c120:	45 85 e4             	test   %r12d,%r12d
    c123:	74 1e                	je     c143 <fwp_main_thread+0xf93>
    c125:	4c 8b ad a0 fe ff ff 	mov    -0x160(%rbp),%r13
    c12c:	31 db                	xor    %ebx,%ebx
    c12e:	66 90                	xchg   %ax,%ax
    c130:	49 8b 7c dd 00       	mov    0x0(%r13,%rbx,8),%rdi
    c135:	48 83 c3 01          	add    $0x1,%rbx
    c139:	e8 d2 a9 ff ff       	call   6b10 <fwp_rc_share>
    c13e:	44 39 e3             	cmp    %r12d,%ebx
    c141:	72 ed                	jb     c130 <fwp_main_thread+0xf80>
    c143:	48 8b 95 a0 fe ff ff 	mov    -0x160(%rbp),%rdx
    c14a:	8b b5 9c fe ff ff    	mov    -0x164(%rbp),%esi
    c150:	4c 89 ff             	mov    %r15,%rdi
    c153:	e8 58 9c ff ff       	call   5db0 <fwp_apply>
    c158:	49 89 c7             	mov    %rax,%r15
    c15b:	48 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%rdi
    c162:	66 0f ef c0          	pxor   %xmm0,%xmm0
    c166:	b9 01 00 00 00       	mov    $0x1,%ecx
    c16b:	4c 89 fe             	mov    %r15,%rsi
    c16e:	48 8d 15 0b 4a 00 00 	lea    0x4a0b(%rip),%rdx        # 10b80 <d0>
    c175:	0f 29 85 f0 fe ff ff 	movaps %xmm0,-0x110(%rbp)
    c17c:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
    c183:	00 00 00 00 
    c187:	e8 e4 df ff ff       	call   a170 <fwp_write>
    c18c:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
    c193:	4c 8b ad f8 fe ff ff 	mov    -0x108(%rbp),%r13
    c19a:	48 8d 05 f0 0e 00 00 	lea    0xef0(%rip),%rax        # d091 <_IO_stdin_used+0x91>
    c1a1:	48 85 c9             	test   %rcx,%rcx
    c1a4:	48 0f 44 c8          	cmove  %rax,%rcx
    c1a8:	49 83 fd f6          	cmp    $0xfffffffffffffff6,%r13
    c1ac:	0f 87 f6 07 00 00    	ja     c9a8 <fwp_main_thread+0x17f8>
    c1b2:	49 8d 7d 09          	lea    0x9(%r13),%rdi
    c1b6:	be 01 00 00 00       	mov    $0x1,%esi
    c1bb:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
    c1c2:	e8 c9 9a ff ff       	call   5c90 <fwp_heap_alloc>
    c1c7:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
    c1ce:	4c 89 ea             	mov    %r13,%rdx
    c1d1:	4c 89 28             	mov    %r13,(%rax)
    c1d4:	4c 8d 60 08          	lea    0x8(%rax),%r12
    c1d8:	48 89 c3             	mov    %rax,%rbx
    c1db:	4c 89 e7             	mov    %r12,%rdi
    c1de:	e8 bd 73 ff ff       	call   35a0 <memcpy@plt>
    c1e3:	42 c6 44 2b 08 00    	movb   $0x0,0x8(%rbx,%r13,1)
    c1e9:	48 8b bd f0 fe ff ff 	mov    -0x110(%rbp),%rdi
    c1f0:	e8 cb 71 ff ff       	call   33c0 <free@plt>
    c1f5:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c1fc:	48 89 d8             	mov    %rbx,%rax
    c1ff:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c206:	48 c1 e2 10          	shl    $0x10,%rdx
    c20a:	48 39 d0             	cmp    %rdx,%rax
    c20d:	73 57                	jae    c266 <fwp_main_thread+0x10b6>
    c20f:	48 89 c2             	mov    %rax,%rdx
    c212:	48 c1 ea 10          	shr    $0x10,%rdx
    c216:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c21a:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c221:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    c225:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    c229:	48 85 d2             	test   %rdx,%rdx
    c22c:	74 38                	je     c266 <fwp_main_thread+0x10b6>
    c22e:	0f b6 31             	movzbl (%rcx),%esi
    c231:	40 80 fe 02          	cmp    $0x2,%sil
    c235:	0f 84 ad 06 00 00    	je     c8e8 <fwp_main_thread+0x1738>
    c23b:	40 80 fe 01          	cmp    $0x1,%sil
    c23f:	75 25                	jne    c266 <fwp_main_thread+0x10b6>
    c241:	8b 71 18             	mov    0x18(%rcx),%esi
    c244:	0f b7 c0             	movzwl %ax,%eax
    c247:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    c24a:	48 0f af c6          	imul   %rsi,%rax
    c24e:	48 c1 e8 20          	shr    $0x20,%rax
    c252:	48 39 c8             	cmp    %rcx,%rax
    c255:	73 0f                	jae    c266 <fwp_main_thread+0x10b6>
    c257:	48 01 c2             	add    %rax,%rdx
    c25a:	80 3a ff             	cmpb   $0xff,(%rdx)
    c25d:	0f 84 58 06 00 00    	je     c8bb <fwp_main_thread+0x170b>
    c263:	c6 02 01             	movb   $0x1,(%rdx)
    c266:	4c 89 ff             	mov    %r15,%rdi
    c269:	e8 32 aa ff ff       	call   6ca0 <fwp_drop0>
    c26e:	48 8b 13             	mov    (%rbx),%rdx
    c271:	be 01 00 00 00       	mov    $0x1,%esi
    c276:	4c 89 e7             	mov    %r12,%rdi
    c279:	48 8b 0d c0 71 01 00 	mov    0x171c0(%rip),%rcx        # 23440 <fwp_prog_out>
    c280:	e8 fb 73 ff ff       	call   3680 <fwrite@plt>
    c285:	48 8b 35 b4 71 01 00 	mov    0x171b4(%rip),%rsi        # 23440 <fwp_prog_out>
    c28c:	bf 0a 00 00 00       	mov    $0xa,%edi
    c291:	e8 4a 72 ff ff       	call   34e0 <fputc@plt>
    c296:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c29d:	48 89 d8             	mov    %rbx,%rax
    c2a0:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c2a7:	48 c1 e2 10          	shl    $0x10,%rdx
    c2ab:	48 39 d0             	cmp    %rdx,%rax
    c2ae:	73 69                	jae    c319 <fwp_main_thread+0x1169>
    c2b0:	48 89 c2             	mov    %rax,%rdx
    c2b3:	48 c1 ea 10          	shr    $0x10,%rdx
    c2b7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c2bb:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c2c2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c2c6:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    c2ca:	4d 85 ed             	test   %r13,%r13
    c2cd:	74 4a                	je     c319 <fwp_main_thread+0x1169>
    c2cf:	0f b6 0a             	movzbl (%rdx),%ecx
    c2d2:	80 f9 02             	cmp    $0x2,%cl
    c2d5:	0f 84 37 05 00 00    	je     c812 <fwp_main_thread+0x1662>
    c2db:	80 f9 01             	cmp    $0x1,%cl
    c2de:	75 39                	jne    c319 <fwp_main_thread+0x1169>
    c2e0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    c2e3:	0f b7 c0             	movzwl %ax,%eax
    c2e6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c2e9:	48 0f af c1          	imul   %rcx,%rax
    c2ed:	48 c1 e8 20          	shr    $0x20,%rax
    c2f1:	48 39 d0             	cmp    %rdx,%rax
    c2f4:	73 23                	jae    c319 <fwp_main_thread+0x1169>
    c2f6:	49 01 c5             	add    %rax,%r13
    c2f9:	41 0f b6 45 00       	movzbl 0x0(%r13),%eax
    c2fe:	84 c0                	test   %al,%al
    c300:	74 17                	je     c319 <fwp_main_thread+0x1169>
    c302:	3c 01                	cmp    $0x1,%al
    c304:	0f 84 fb 04 00 00    	je     c805 <fwp_main_thread+0x1655>
    c30a:	3c ff                	cmp    $0xff,%al
    c30c:	0f 84 2e 05 00 00    	je     c840 <fwp_main_thread+0x1690>
    c312:	83 e8 01             	sub    $0x1,%eax
    c315:	41 88 45 00          	mov    %al,0x0(%r13)
    c319:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
    c320:	48 8b 40 10          	mov    0x10(%rax),%rax
    c324:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
    c32b:	48 85 c0             	test   %rax,%rax
    c32e:	0f 84 91 06 00 00    	je     c9c5 <fwp_main_thread+0x1815>
    c334:	49 8b 8e b0 13 00 00 	mov    0x13b0(%r14),%rcx
    c33b:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c342:	e9 1c f9 ff ff       	jmp    bc63 <fwp_main_thread+0xab3>
    c347:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    c34e:	00 00 
    c350:	41 8b 96 a4 13 00 00 	mov    0x13a4(%r14),%edx
    c357:	8d 70 01             	lea    0x1(%rax),%esi
    c35a:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c361:	48 8d 3c f5 00 00 00 	lea    0x0(,%rsi,8),%rdi
    c368:	00 
    c369:	85 d2                	test   %edx,%edx
    c36b:	0f 84 ac 03 00 00    	je     c71d <fwp_main_thread+0x156d>
    c371:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    c378:	0f 87 9f 03 00 00    	ja     c71d <fwp_main_thread+0x156d>
    c37e:	48 8d 47 0f          	lea    0xf(%rdi),%rax
    c382:	48 c1 e8 04          	shr    $0x4,%rax
    c386:	41 0f b6 94 06 a0 0f 	movzbl 0xfa0(%r14,%rax,1),%edx
    c38d:	00 00 
    c38f:	41 8b 84 96 00 0f 00 	mov    0xf00(%r14,%rdx,4),%eax
    c396:	00 
    c397:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
    c39b:	49 8d 14 d6          	lea    (%r14,%rdx,8),%rdx
    c39f:	48 8b 1a             	mov    (%rdx),%rbx
    c3a2:	48 85 db             	test   %rbx,%rbx
    c3a5:	0f 84 50 03 00 00    	je     c6fb <fwp_main_thread+0x154b>
    c3ab:	4c 8b 1b             	mov    (%rbx),%r11
    c3ae:	49 f7 d3             	not    %r11
    c3b1:	4c 89 1a             	mov    %r11,(%rdx)
    c3b4:	48 39 c7             	cmp    %rax,%rdi
    c3b7:	73 61                	jae    c41a <fwp_main_thread+0x126a>
    c3b9:	48 89 fa             	mov    %rdi,%rdx
    c3bc:	48 83 c7 08          	add    $0x8,%rdi
    c3c0:	48 c7 04 f3 00 00 00 	movq   $0x0,(%rbx,%rsi,8)
    c3c7:	00 
    c3c8:	48 f7 d2             	not    %rdx
    c3cb:	48 01 c2             	add    %rax,%rdx
    c3ce:	48 c1 ea 03          	shr    $0x3,%rdx
    c3d2:	48 39 c7             	cmp    %rax,%rdi
    c3d5:	73 43                	jae    c41a <fwp_main_thread+0x126a>
    c3d7:	83 e2 01             	and    $0x1,%edx
    c3da:	74 24                	je     c400 <fwp_main_thread+0x1250>
    c3dc:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    c3e3:	00 
    c3e4:	48 83 c7 08          	add    $0x8,%rdi
    c3e8:	48 39 c7             	cmp    %rax,%rdi
    c3eb:	73 2d                	jae    c41a <fwp_main_thread+0x126a>
    c3ed:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c3f4:	00 
    c3f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c3fc:	00 00 00 00 
    c400:	48 c7 04 3b 00 00 00 	movq   $0x0,(%rbx,%rdi,1)
    c407:	00 
    c408:	48 c7 44 3b 08 00 00 	movq   $0x0,0x8(%rbx,%rdi,1)
    c40f:	00 00 
    c411:	48 83 c7 10          	add    $0x10,%rdi
    c415:	48 39 c7             	cmp    %rax,%rdi
    c418:	72 e6                	jb     c400 <fwp_main_thread+0x1250>
    c41a:	48 89 c2             	mov    %rax,%rdx
    c41d:	49 03 96 20 14 00 00 	add    0x1420(%r14),%rdx
    c424:	0f 82 36 05 00 00    	jb     c960 <fwp_main_thread+0x17b0>
    c42a:	49 89 96 20 14 00 00 	mov    %rdx,0x1420(%r14)
    c431:	49 39 96 28 14 00 00 	cmp    %rdx,0x1428(%r14)
    c438:	73 07                	jae    c441 <fwp_main_thread+0x1291>
    c43a:	49 89 96 28 14 00 00 	mov    %rdx,0x1428(%r14)
    c441:	66 0f ef c0          	pxor   %xmm0,%xmm0
    c445:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    c44a:	f2 41 0f 58 86 38 14 	addsd  0x1438(%r14),%xmm0
    c451:	00 00 
    c453:	f2 41 0f 11 86 38 14 	movsd  %xmm0,0x1438(%r14)
    c45a:	00 00 
    c45c:	66 41 0f 6e 02       	movd   (%r10),%xmm0
    c461:	66 0f 6e 8d 98 fe ff 	movd   -0x168(%rbp),%xmm1
    c468:	ff 
    c469:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    c46d:	66 0f d6 03          	movq   %xmm0,(%rbx)
    c471:	85 c9                	test   %ecx,%ecx
    c473:	74 3b                	je     c4b0 <fwp_main_thread+0x1300>
    c475:	89 ca                	mov    %ecx,%edx
    c477:	49 8d 72 08          	lea    0x8(%r10),%rsi
    c47b:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    c47f:	89 8d a8 fe ff ff    	mov    %ecx,-0x158(%rbp)
    c485:	48 c1 e2 03          	shl    $0x3,%rdx
    c489:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
    c490:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c497:	e8 74 71 ff ff       	call   3610 <memmove@plt>
    c49c:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c4a3:	8b 8d a8 fe ff ff    	mov    -0x158(%rbp),%ecx
    c4a9:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
    c4b0:	8b 85 b8 fe ff ff    	mov    -0x148(%rbp),%eax
    c4b6:	85 c0                	test   %eax,%eax
    c4b8:	74 3c                	je     c4f6 <fwp_main_thread+0x1346>
    c4ba:	8b 95 b8 fe ff ff    	mov    -0x148(%rbp),%edx
    c4c0:	4c 89 e8             	mov    %r13,%rax
    c4c3:	49 8d 7c d5 00       	lea    0x0(%r13,%rdx,8),%rdi
    c4c8:	66 90                	xchg   %ax,%ax
    c4ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c4d1:	00 00 00 00 
    c4d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c4dc:	00 00 00 00 
    c4e0:	48 8b 30             	mov    (%rax),%rsi
    c4e3:	89 ca                	mov    %ecx,%edx
    c4e5:	48 83 c0 08          	add    $0x8,%rax
    c4e9:	83 c1 01             	add    $0x1,%ecx
    c4ec:	48 89 74 d3 08       	mov    %rsi,0x8(%rbx,%rdx,8)
    c4f1:	48 39 c7             	cmp    %rax,%rdi
    c4f4:	75 ea                	jne    c4e0 <fwp_main_thread+0x1330>
    c4f6:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c4fd:	4c 89 f8             	mov    %r15,%rax
    c500:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c507:	48 c1 e2 10          	shl    $0x10,%rdx
    c50b:	48 39 d0             	cmp    %rdx,%rax
    c50e:	73 54                	jae    c564 <fwp_main_thread+0x13b4>
    c510:	48 89 c2             	mov    %rax,%rdx
    c513:	48 c1 ea 10          	shr    $0x10,%rdx
    c517:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c51b:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c522:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    c526:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    c52a:	48 85 c9             	test   %rcx,%rcx
    c52d:	74 35                	je     c564 <fwp_main_thread+0x13b4>
    c52f:	0f b6 32             	movzbl (%rdx),%esi
    c532:	40 80 fe 02          	cmp    $0x2,%sil
    c536:	0f 84 39 02 00 00    	je     c775 <fwp_main_thread+0x15c5>
    c53c:	40 80 fe 01          	cmp    $0x1,%sil
    c540:	75 22                	jne    c564 <fwp_main_thread+0x13b4>
    c542:	8b 72 18             	mov    0x18(%rdx),%esi
    c545:	0f b7 c0             	movzwl %ax,%eax
    c548:	8b 52 1c             	mov    0x1c(%rdx),%edx
    c54b:	48 0f af c6          	imul   %rsi,%rax
    c54f:	48 c1 e8 20          	shr    $0x20,%rax
    c553:	48 39 d0             	cmp    %rdx,%rax
    c556:	73 0c                	jae    c564 <fwp_main_thread+0x13b4>
    c558:	48 01 c1             	add    %rax,%rcx
    c55b:	80 39 01             	cmpb   $0x1,(%rcx)
    c55e:	0f 84 7c 01 00 00    	je     c6e0 <fwp_main_thread+0x1530>
    c564:	49 8b 40 18          	mov    0x18(%r8),%rax
    c568:	be 01 00 00 00       	mov    $0x1,%esi
    c56d:	4c 89 ff             	mov    %r15,%rdi
    c570:	ff 50 08             	call   *0x8(%rax)
    c573:	49 8b 96 d8 13 00 00 	mov    0x13d8(%r14),%rdx
    c57a:	48 89 d8             	mov    %rbx,%rax
    c57d:	49 2b 86 b0 13 00 00 	sub    0x13b0(%r14),%rax
    c584:	48 c1 e2 10          	shl    $0x10,%rdx
    c588:	48 39 d0             	cmp    %rdx,%rax
    c58b:	73 5b                	jae    c5e8 <fwp_main_thread+0x1438>
    c58d:	48 89 c2             	mov    %rax,%rdx
    c590:	48 c1 ea 10          	shr    $0x10,%rdx
    c594:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    c598:	49 8b 96 f8 13 00 00 	mov    0x13f8(%r14),%rdx
    c59f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    c5a3:	4c 8b 69 20          	mov    0x20(%rcx),%r13
    c5a7:	4d 85 ed             	test   %r13,%r13
    c5aa:	74 3c                	je     c5e8 <fwp_main_thread+0x1438>
    c5ac:	0f b6 31             	movzbl (%rcx),%esi
    c5af:	40 80 fe 02          	cmp    $0x2,%sil
    c5b3:	0f 84 9b 01 00 00    	je     c754 <fwp_main_thread+0x15a4>
    c5b9:	40 80 fe 01          	cmp    $0x1,%sil
    c5bd:	75 29                	jne    c5e8 <fwp_main_thread+0x1438>
    c5bf:	8b 71 18             	mov    0x18(%rcx),%esi
    c5c2:	0f b7 c0             	movzwl %ax,%eax
    c5c5:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    c5c8:	48 0f af c6          	imul   %rsi,%rax
    c5cc:	48 c1 e8 20          	shr    $0x20,%rax
    c5d0:	48 39 c8             	cmp    %rcx,%rax
    c5d3:	73 13                	jae    c5e8 <fwp_main_thread+0x1438>
    c5d5:	49 01 c5             	add    %rax,%r13
    c5d8:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c5dd:	0f 84 85 01 00 00    	je     c768 <fwp_main_thread+0x15b8>
    c5e3:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    c5e8:	4c 89 ff             	mov    %r15,%rdi
    c5eb:	49 89 df             	mov    %rbx,%r15
    c5ee:	e8 9d a9 ff ff       	call   6f90 <fwp_closure_drop>
    c5f3:	e9 c8 fa ff ff       	jmp    c0c0 <fwp_main_thread+0xf10>
    c5f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    c5ff:	00 
    c600:	44 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12d
    c607:	49 89 c7             	mov    %rax,%r15
    c60a:	e9 b1 fa ff ff       	jmp    c0c0 <fwp_main_thread+0xf10>
    c60f:	90                   	nop
    c610:	41 8b 75 00          	mov    0x0(%r13),%esi
    c614:	8b 05 02 4a 00 00    	mov    0x4a02(%rip),%eax        # 1101c <fc12+0x4>
    c61a:	89 f7                	mov    %esi,%edi
    c61c:	29 c7                	sub    %eax,%edi
    c61e:	83 ff 01             	cmp    $0x1,%edi
    c621:	0f 85 ea f6 ff ff    	jne    bd11 <fwp_main_thread+0xb61>
    c627:	48 89 e3             	mov    %rsp,%rbx
    c62a:	85 c0                	test   %eax,%eax
    c62c:	0f 84 6c 01 00 00    	je     c79e <fwp_main_thread+0x15ee>
    c632:	89 f1                	mov    %esi,%ecx
    c634:	ba 08 00 00 00       	mov    $0x8,%edx
    c639:	48 c1 e1 03          	shl    $0x3,%rcx
    c63d:	85 f6                	test   %esi,%esi
    c63f:	48 89 e6             	mov    %rsp,%rsi
    c642:	48 0f 45 d1          	cmovne %rcx,%rdx
    c646:	49 89 d7             	mov    %rdx,%r15
    c649:	48 8d 52 0f          	lea    0xf(%rdx),%rdx
    c64d:	48 c1 ea 04          	shr    $0x4,%rdx
    c651:	48 c1 e2 04          	shl    $0x4,%rdx
    c655:	48 89 d7             	mov    %rdx,%rdi
    c658:	48 81 e7 00 f0 ff ff 	and    $0xfffffffffffff000,%rdi
    c65f:	48 29 fe             	sub    %rdi,%rsi
    c662:	48 39 f4             	cmp    %rsi,%rsp
    c665:	74 15                	je     c67c <fwp_main_thread+0x14cc>
    c667:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    c66e:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    c675:	00 00 
    c677:	48 39 f4             	cmp    %rsi,%rsp
    c67a:	75 eb                	jne    c667 <fwp_main_thread+0x14b7>
    c67c:	81 e2 ff 0f 00 00    	and    $0xfff,%edx
    c682:	48 29 d4             	sub    %rdx,%rsp
    c685:	48 85 d2             	test   %rdx,%rdx
    c688:	74 06                	je     c690 <fwp_main_thread+0x14e0>
    c68a:	48 83 4c 14 f8 00    	orq    $0x0,-0x8(%rsp,%rdx,1)
    c690:	4c 8d 24 c5 00 00 00 	lea    0x0(,%rax,8),%r12
    c697:	00 
    c698:	4c 89 f9             	mov    %r15,%rcx
    c69b:	48 8d 35 7e 49 00 00 	lea    0x497e(%rip),%rsi        # 11020 <descent_active_phase>
    c6a2:	48 89 e7             	mov    %rsp,%rdi
    c6a5:	4c 89 e2             	mov    %r12,%rdx
    c6a8:	e8 c3 6e ff ff       	call   3570 <__memcpy_chk@plt>
    c6ad:	4d 39 e7             	cmp    %r12,%r15
    c6b0:	4c 89 f9             	mov    %r15,%rcx
    c6b3:	4a 8d 3c 24          	lea    (%rsp,%r12,1),%rdi
    c6b7:	49 0f 42 cc          	cmovb  %r12,%rcx
    c6bb:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
    c6c2:	ba 08 00 00 00       	mov    $0x8,%edx
    c6c7:	4c 29 e1             	sub    %r12,%rcx
    c6ca:	e8 a1 6e ff ff       	call   3570 <__memcpy_chk@plt>
    c6cf:	49 8b 45 18          	mov    0x18(%r13),%rax
    c6d3:	48 89 e7             	mov    %rsp,%rdi
    c6d6:	ff 10                	call   *(%rax)
    c6d8:	49 89 c7             	mov    %rax,%r15
    c6db:	e9 ca 00 00 00       	jmp    c7aa <fwp_main_thread+0x15fa>
    c6e0:	41 c7 42 04 00 00 00 	movl   $0x0,0x4(%r10)
    c6e7:	00 
    c6e8:	e9 86 fe ff ff       	jmp    c573 <fwp_main_thread+0x13c3>
    c6ed:	66 85 c0             	test   %ax,%ax
    c6f0:	0f 85 98 f6 ff ff    	jne    bd8e <fwp_main_thread+0xbde>
    c6f6:	e9 7f f6 ff ff       	jmp    bd7a <fwp_main_thread+0xbca>
    c6fb:	48 8b 5a 08          	mov    0x8(%rdx),%rbx
    c6ff:	48 85 db             	test   %rbx,%rbx
    c702:	74 19                	je     c71d <fwp_main_thread+0x156d>
    c704:	4c 8b 5a 10          	mov    0x10(%rdx),%r11
    c708:	49 29 db             	sub    %rbx,%r11
    c70b:	49 39 c3             	cmp    %rax,%r11
    c70e:	72 0d                	jb     c71d <fwp_main_thread+0x156d>
    c710:	4c 8d 1c 03          	lea    (%rbx,%rax,1),%r11
    c714:	4c 89 5a 08          	mov    %r11,0x8(%rdx)
    c718:	e9 97 fc ff ff       	jmp    c3b4 <fwp_main_thread+0x1204>
    c71d:	31 f6                	xor    %esi,%esi
    c71f:	89 8d 90 fe ff ff    	mov    %ecx,-0x170(%rbp)
    c725:	4c 89 85 a8 fe ff ff 	mov    %r8,-0x158(%rbp)
    c72c:	4c 89 95 b0 fe ff ff 	mov    %r10,-0x150(%rbp)
    c733:	e8 58 95 ff ff       	call   5c90 <fwp_heap_alloc>
    c738:	8b 8d 90 fe ff ff    	mov    -0x170(%rbp),%ecx
    c73e:	4c 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%r8
    c745:	4c 8b 95 b0 fe ff ff 	mov    -0x150(%rbp),%r10
    c74c:	48 89 c3             	mov    %rax,%rbx
    c74f:	e9 08 fd ff ff       	jmp    c45c <fwp_main_thread+0x12ac>
    c754:	66 85 c0             	test   %ax,%ax
    c757:	0f 85 8b fe ff ff    	jne    c5e8 <fwp_main_thread+0x1438>
    c75d:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    c762:	0f 85 7b fe ff ff    	jne    c5e3 <fwp_main_thread+0x1433>
    c768:	4c 89 ef             	mov    %r13,%rdi
    c76b:	e8 e0 8d ff ff       	call   5550 <fwp_rc_forget_slot>
    c770:	e9 6e fe ff ff       	jmp    c5e3 <fwp_main_thread+0x1433>
    c775:	66 85 c0             	test   %ax,%ax
    c778:	0f 85 e6 fd ff ff    	jne    c564 <fwp_main_thread+0x13b4>
    c77e:	e9 d8 fd ff ff       	jmp    c55b <fwp_main_thread+0x13ab>
    c783:	e8 a8 8c ff ff       	call   5430 <fwp_rc_wide_dup>
    c788:	48 8b 15 a9 6c 01 00 	mov    0x16ca9(%rip),%rdx        # 23438 <fwp_fns>
    c78f:	e9 fa f5 ff ff       	jmp    bd8e <fwp_main_thread+0xbde>
    c794:	49 89 5c 24 40       	mov    %rbx,0x40(%r12)
    c799:	e9 fe eb ff ff       	jmp    b39c <fwp_main_thread+0x1ec>
    c79e:	48 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%rdi
    c7a5:	ff 11                	call   *(%rcx)
    c7a7:	49 89 c7             	mov    %rax,%r15
    c7aa:	48 89 dc             	mov    %rbx,%rsp
    c7ad:	e9 a9 f9 ff ff       	jmp    c15b <fwp_main_thread+0xfab>
    c7b2:	66 85 c0             	test   %ax,%ax
    c7b5:	0f 85 cc f3 ff ff    	jne    bb87 <fwp_main_thread+0x9d7>
    c7bb:	e9 bb f3 ff ff       	jmp    bb7b <fwp_main_thread+0x9cb>
    c7c0:	66 85 c0             	test   %ax,%ax
    c7c3:	0f 85 18 f3 ff ff    	jne    bae1 <fwp_main_thread+0x931>
    c7c9:	e9 07 f3 ff ff       	jmp    bad5 <fwp_main_thread+0x925>
    c7ce:	66 85 c0             	test   %ax,%ax
    c7d1:	0f 85 fc f4 ff ff    	jne    bcd3 <fwp_main_thread+0xb23>
    c7d7:	e9 e3 f4 ff ff       	jmp    bcbf <fwp_main_thread+0xb0f>
    c7dc:	66 85 c0             	test   %ax,%ax
    c7df:	0f 85 62 f4 ff ff    	jne    bc47 <fwp_main_thread+0xa97>
    c7e5:	e9 43 f4 ff ff       	jmp    bc2d <fwp_main_thread+0xa7d>
    c7ea:	48 89 d7             	mov    %rdx,%rdi
    c7ed:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c7f4:	e8 57 8d ff ff       	call   5550 <fwp_rc_forget_slot>
    c7f9:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c800:	e9 97 f1 ff ff       	jmp    b99c <fwp_main_thread+0x7ec>
    c805:	48 89 df             	mov    %rbx,%rdi
    c808:	e8 83 a3 ff ff       	call   6b90 <fwp_rc_free_arr>
    c80d:	e9 07 fb ff ff       	jmp    c319 <fwp_main_thread+0x1169>
    c812:	66 85 c0             	test   %ax,%ax
    c815:	0f 85 fe fa ff ff    	jne    c319 <fwp_main_thread+0x1169>
    c81b:	e9 d9 fa ff ff       	jmp    c2f9 <fwp_main_thread+0x1149>
    c820:	48 83 3d 90 4f 01 00 	cmpq   $0x0,0x14f90(%rip)        # 217b8 <fwp_root>
    c827:	00 
    c828:	c7 05 6e 48 01 00 00 	movl   $0x0,0x1486e(%rip)        # 210a0 <fwp_exit_code>
    c82f:	00 00 00 
    c832:	0f 84 42 ee ff ff    	je     b67a <fwp_main_thread+0x4ca>
    c838:	e9 13 6f ff ff       	jmp    3750 <fwp_main_thread.cold>
    c83d:	0f 1f 00             	nopl   (%rax)
    c840:	4c 89 e8             	mov    %r13,%rax
    c843:	48 c1 e8 11          	shr    $0x11,%rax
    c847:	4c 31 e8             	xor    %r13,%rax
    c84a:	48 89 c2             	mov    %rax,%rdx
    c84d:	48 c1 ea 09          	shr    $0x9,%rdx
    c851:	48 31 d0             	xor    %rdx,%rax
    c854:	0f b6 c0             	movzbl %al,%eax
    c857:	49 8b 94 c6 48 14 00 	mov    0x1448(%r14,%rax,8),%rdx
    c85e:	00 
    c85f:	48 85 d2             	test   %rdx,%rdx
    c862:	75 25                	jne    c889 <fwp_main_thread+0x16d9>
    c864:	eb 70                	jmp    c8d6 <fwp_main_thread+0x1726>
    c866:	0f 1f 40 00          	nopl   0x0(%rax)
    c86a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c871:	00 00 00 00 
    c875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    c87c:	00 00 00 00 
    c880:	48 8b 50 10          	mov    0x10(%rax),%rdx
    c884:	48 85 d2             	test   %rdx,%rdx
    c887:	74 4d                	je     c8d6 <fwp_main_thread+0x1726>
    c889:	48 89 d0             	mov    %rdx,%rax
    c88c:	4c 39 2a             	cmp    %r13,(%rdx)
    c88f:	75 ef                	jne    c880 <fwp_main_thread+0x16d0>
    c891:	48 8b 42 08          	mov    0x8(%rdx),%rax
    c895:	48 83 e8 01          	sub    $0x1,%rax
    c899:	48 89 42 08          	mov    %rax,0x8(%rdx)
    c89d:	48 3d fe 00 00 00    	cmp    $0xfe,%rax
    c8a3:	0f 85 70 fa ff ff    	jne    c319 <fwp_main_thread+0x1169>
    c8a9:	4c 89 ef             	mov    %r13,%rdi
    c8ac:	e8 9f 8c ff ff       	call   5550 <fwp_rc_forget_slot>
    c8b1:	41 c6 45 00 fe       	movb   $0xfe,0x0(%r13)
    c8b6:	e9 5e fa ff ff       	jmp    c319 <fwp_main_thread+0x1169>
    c8bb:	48 89 d7             	mov    %rdx,%rdi
    c8be:	48 89 95 b8 fe ff ff 	mov    %rdx,-0x148(%rbp)
    c8c5:	e8 86 8c ff ff       	call   5550 <fwp_rc_forget_slot>
    c8ca:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
    c8d1:	e9 8d f9 ff ff       	jmp    c263 <fwp_main_thread+0x10b3>
    c8d6:	48 8d 3d ab 0f 00 00 	lea    0xfab(%rip),%rdi        # d888 <_IO_stdin_used+0x888>
    c8dd:	e8 0e 7b ff ff       	call   43f0 <fwp_trap>
    c8e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    c8e8:	66 85 c0             	test   %ax,%ax
    c8eb:	0f 85 75 f9 ff ff    	jne    c266 <fwp_main_thread+0x10b6>
    c8f1:	e9 64 f9 ff ff       	jmp    c25a <fwp_main_thread+0x10aa>
    c8f6:	48 89 df             	mov    %rbx,%rdi
    c8f9:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c900:	e8 4b 8c ff ff       	call   5550 <fwp_rc_forget_slot>
    c905:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c90c:	e9 cd f1 ff ff       	jmp    bade <fwp_main_thread+0x92e>
    c911:	48 89 df             	mov    %rbx,%rdi
    c914:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c91b:	e8 30 8c ff ff       	call   5550 <fwp_rc_forget_slot>
    c920:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c927:	e9 58 f2 ff ff       	jmp    bb84 <fwp_main_thread+0x9d4>
    c92c:	48 89 df             	mov    %rbx,%rdi
    c92f:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c936:	e8 15 8c ff ff       	call   5550 <fwp_rc_forget_slot>
    c93b:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
    c942:	e9 ef f2 ff ff       	jmp    bc36 <fwp_main_thread+0xa86>
    c947:	e8 e4 8a ff ff       	call   5430 <fwp_rc_wide_dup>
    c94c:	e9 82 f3 ff ff       	jmp    bcd3 <fwp_main_thread+0xb23>
    c951:	e8 8a 74 ff ff       	call   3de0 <descent_phase_fail>
    c956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    c95d:	00 00 00 
    c960:	e8 4b 73 ff ff       	call   3cb0 <fwp_heap_oom>
    c965:	48 89 c8             	mov    %rcx,%rax
    c968:	e9 79 ec ff ff       	jmp    b5e6 <fwp_main_thread+0x436>
    c96d:	0f 1f 00             	nopl   (%rax)
    c970:	48 89 c7             	mov    %rax,%rdi
    c973:	4c 8d 3d 9e 46 00 00 	lea    0x469e(%rip),%r15        # 11018 <fc12>
    c97a:	e8 91 a1 ff ff       	call   6b10 <fwp_rc_share>
    c97f:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c986:	e8 85 a1 ff ff       	call   6b10 <fwp_rc_share>
    c98b:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
    c992:	c7 85 9c fe ff ff 01 	movl   $0x1,-0x164(%rbp)
    c999:	00 00 00 
    c99c:	48 89 85 a0 fe ff ff 	mov    %rax,-0x160(%rbp)
    c9a3:	e9 9b f7 ff ff       	jmp    c143 <fwp_main_thread+0xf93>
    c9a8:	48 8d 3d 97 08 00 00 	lea    0x897(%rip),%rdi        # d246 <_IO_stdin_used+0x246>
    c9af:	e8 3c 7a ff ff       	call   43f0 <fwp_trap>
    c9b4:	e8 a7 6a ff ff       	call   3460 <__stack_chk_fail@plt>
    c9b9:	48 8d 3d 20 10 00 00 	lea    0x1020(%rip),%rdi        # d9e0 <_IO_stdin_used+0x9e0>
    c9c0:	e8 2b 7a ff ff       	call   43f0 <fwp_trap>
    c9c5:	4c 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%r8
    c9cc:	48 8b bd 70 fe ff ff 	mov    -0x190(%rbp),%rdi
    c9d3:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
    c9da:	e8 c1 a2 ff ff       	call   6ca0 <fwp_drop0>
    c9df:	48 8b bd b8 fe ff ff 	mov    -0x148(%rbp),%rdi
    c9e6:	e8 b5 a2 ff ff       	call   6ca0 <fwp_drop0>
    c9eb:	48 c7 05 92 46 00 00 	movq   $0x0,0x4692(%rip)        # 11088 <v.2>
    c9f2:	00 00 00 00 
    c9f6:	c7 05 90 46 00 00 01 	movl   $0x1,0x4690(%rip)        # 11090 <st.3>
    c9fd:	00 00 00 
    ca00:	e9 d9 e8 ff ff       	jmp    b2de <fwp_main_thread+0x12e>
    ca05:	e9 46 6d ff ff       	jmp    3750 <fwp_main_thread.cold>
    ca0a:	e9 41 6d ff ff       	jmp    3750 <fwp_main_thread.cold>
    ca0f:	90                   	nop

000000000000ca10 <__divmodti4>:
    ca10:	f3 0f 1e fa          	endbr64
    ca14:	55                   	push   %rbp
    ca15:	49 89 f1             	mov    %rsi,%r9
    ca18:	49 89 d2             	mov    %rdx,%r10
    ca1b:	48 89 fe             	mov    %rdi,%rsi
    ca1e:	49 89 cb             	mov    %rcx,%r11
    ca21:	48 89 e5             	mov    %rsp,%rbp
    ca24:	41 57                	push   %r15
    ca26:	41 56                	push   %r14
    ca28:	41 55                	push   %r13
    ca2a:	41 54                	push   %r12
    ca2c:	53                   	push   %rbx
    ca2d:	4c 89 c3             	mov    %r8,%rbx
    ca30:	45 31 c0             	xor    %r8d,%r8d
    ca33:	4d 85 c9             	test   %r9,%r9
    ca36:	79 12                	jns    ca4a <__divmodti4+0x3a>
    ca38:	31 ff                	xor    %edi,%edi
    ca3a:	48 f7 de             	neg    %rsi
    ca3d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    ca44:	4c 19 cf             	sbb    %r9,%rdi
    ca47:	49 89 f9             	mov    %rdi,%r9
    ca4a:	4c 89 d8             	mov    %r11,%rax
    ca4d:	4d 85 db             	test   %r11,%r11
    ca50:	0f 88 1a 01 00 00    	js     cb70 <__divmodti4+0x160>
    ca56:	4c 89 d9             	mov    %r11,%rcx
    ca59:	49 89 f3             	mov    %rsi,%r11
    ca5c:	75 62                	jne    cac0 <__divmodti4+0xb0>
    ca5e:	4d 89 c4             	mov    %r8,%r12
    ca61:	4d 39 d1             	cmp    %r10,%r9
    ca64:	0f 83 46 01 00 00    	jae    cbb0 <__divmodti4+0x1a0>
    ca6a:	4c 89 d8             	mov    %r11,%rax
    ca6d:	4c 89 ca             	mov    %r9,%rdx
    ca70:	49 f7 f2             	div    %r10
    ca73:	49 89 c3             	mov    %rax,%r11
    ca76:	31 c0                	xor    %eax,%eax
    ca78:	48 89 d6             	mov    %rdx,%rsi
    ca7b:	31 ff                	xor    %edi,%edi
    ca7d:	4c 89 d9             	mov    %r11,%rcx
    ca80:	48 89 c2             	mov    %rax,%rdx
    ca83:	48 89 c8             	mov    %rcx,%rax
    ca86:	4d 85 e4             	test   %r12,%r12
    ca89:	74 0a                	je     ca95 <__divmodti4+0x85>
    ca8b:	48 f7 d8             	neg    %rax
    ca8e:	48 83 d2 00          	adc    $0x0,%rdx
    ca92:	48 f7 da             	neg    %rdx
    ca95:	4d 85 c0             	test   %r8,%r8
    ca98:	74 0a                	je     caa4 <__divmodti4+0x94>
    ca9a:	48 f7 de             	neg    %rsi
    ca9d:	48 83 d7 00          	adc    $0x0,%rdi
    caa1:	48 f7 df             	neg    %rdi
    caa4:	48 89 33             	mov    %rsi,(%rbx)
    caa7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    caab:	5b                   	pop    %rbx
    caac:	41 5c                	pop    %r12
    caae:	41 5d                	pop    %r13
    cab0:	41 5e                	pop    %r14
    cab2:	41 5f                	pop    %r15
    cab4:	5d                   	pop    %rbp
    cab5:	c3                   	ret
    cab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    cabd:	00 00 00 
    cac0:	4d 89 c4             	mov    %r8,%r12
    cac3:	49 39 c1             	cmp    %rax,%r9
    cac6:	0f 82 ce 00 00 00    	jb     cb9a <__divmodti4+0x18a>
    cacc:	31 ff                	xor    %edi,%edi
    cace:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    cad3:	48 63 c7             	movslq %edi,%rax
    cad6:	be 40 00 00 00       	mov    $0x40,%esi
    cadb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    cae0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    cae5:	48 29 c6             	sub    %rax,%rsi
    cae8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    caed:	48 09 c8             	or     %rcx,%rax
    caf0:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    caf5:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    cafa:	49 89 c6             	mov    %rax,%r14
    cafd:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    cb01:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    cb06:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    cb0b:	49 09 c1             	or     %rax,%r9
    cb0e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    cb12:	4c 89 c8             	mov    %r9,%rax
    cb15:	49 f7 f6             	div    %r14
    cb18:	48 89 d1             	mov    %rdx,%rcx
    cb1b:	49 89 c3             	mov    %rax,%r11
    cb1e:	49 89 c1             	mov    %rax,%r9
    cb21:	49 f7 e2             	mul    %r10
    cb24:	49 89 c6             	mov    %rax,%r14
    cb27:	49 89 d2             	mov    %rdx,%r10
    cb2a:	48 39 d1             	cmp    %rdx,%rcx
    cb2d:	72 07                	jb     cb36 <__divmodti4+0x126>
    cb2f:	75 17                	jne    cb48 <__divmodti4+0x138>
    cb31:	49 39 c7             	cmp    %rax,%r15
    cb34:	73 12                	jae    cb48 <__divmodti4+0x138>
    cb36:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    cb3a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    cb3e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    cb42:	49 89 d2             	mov    %rdx,%r10
    cb45:	49 89 c6             	mov    %rax,%r14
    cb48:	4c 89 f8             	mov    %r15,%rax
    cb4b:	4c 29 f0             	sub    %r14,%rax
    cb4e:	4c 19 d1             	sbb    %r10,%rcx
    cb51:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    cb56:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    cb5b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    cb60:	48 09 c6             	or     %rax,%rsi
    cb63:	48 89 cf             	mov    %rcx,%rdi
    cb66:	31 c0                	xor    %eax,%eax
    cb68:	4c 89 c9             	mov    %r9,%rcx
    cb6b:	e9 10 ff ff ff       	jmp    ca80 <__divmodti4+0x70>
    cb70:	4c 89 d0             	mov    %r10,%rax
    cb73:	4c 89 da             	mov    %r11,%rdx
    cb76:	4d 89 c4             	mov    %r8,%r12
    cb79:	49 89 f3             	mov    %rsi,%r11
    cb7c:	48 f7 d8             	neg    %rax
    cb7f:	49 f7 d4             	not    %r12
    cb82:	48 83 d2 00          	adc    $0x0,%rdx
    cb86:	49 89 c2             	mov    %rax,%r10
    cb89:	48 f7 da             	neg    %rdx
    cb8c:	48 89 d1             	mov    %rdx,%rcx
    cb8f:	0f 84 cc fe ff ff    	je     ca61 <__divmodti4+0x51>
    cb95:	49 39 d1             	cmp    %rdx,%r9
    cb98:	73 46                	jae    cbe0 <__divmodti4+0x1d0>
    cb9a:	4c 89 cf             	mov    %r9,%rdi
    cb9d:	31 c0                	xor    %eax,%eax
    cb9f:	31 c9                	xor    %ecx,%ecx
    cba1:	e9 da fe ff ff       	jmp    ca80 <__divmodti4+0x70>
    cba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    cbad:	00 00 00 
    cbb0:	4d 85 d2             	test   %r10,%r10
    cbb3:	75 0d                	jne    cbc2 <__divmodti4+0x1b2>
    cbb5:	b8 01 00 00 00       	mov    $0x1,%eax
    cbba:	31 d2                	xor    %edx,%edx
    cbbc:	49 f7 f2             	div    %r10
    cbbf:	49 89 c2             	mov    %rax,%r10
    cbc2:	4c 89 c8             	mov    %r9,%rax
    cbc5:	31 d2                	xor    %edx,%edx
    cbc7:	49 f7 f2             	div    %r10
    cbca:	49 89 c1             	mov    %rax,%r9
    cbcd:	4c 89 d8             	mov    %r11,%rax
    cbd0:	49 f7 f2             	div    %r10
    cbd3:	49 89 c3             	mov    %rax,%r11
    cbd6:	4c 89 c8             	mov    %r9,%rax
    cbd9:	e9 9a fe ff ff       	jmp    ca78 <__divmodti4+0x68>
    cbde:	66 90                	xchg   %ax,%ax
    cbe0:	45 31 f6             	xor    %r14d,%r14d
    cbe3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    cbe8:	44 89 f7             	mov    %r14d,%edi
    cbeb:	45 85 f6             	test   %r14d,%r14d
    cbee:	0f 85 df fe ff ff    	jne    cad3 <__divmodti4+0xc3>
    cbf4:	4c 39 ca             	cmp    %r9,%rdx
    cbf7:	72 17                	jb     cc10 <__divmodti4+0x200>
    cbf9:	31 c9                	xor    %ecx,%ecx
    cbfb:	48 39 c6             	cmp    %rax,%rsi
    cbfe:	73 10                	jae    cc10 <__divmodti4+0x200>
    cc00:	4c 89 cf             	mov    %r9,%rdi
    cc03:	31 c0                	xor    %eax,%eax
    cc05:	e9 76 fe ff ff       	jmp    ca80 <__divmodti4+0x70>
    cc0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    cc10:	4c 89 de             	mov    %r11,%rsi
    cc13:	b9 01 00 00 00       	mov    $0x1,%ecx
    cc18:	48 29 c6             	sub    %rax,%rsi
    cc1b:	49 19 d1             	sbb    %rdx,%r9
    cc1e:	eb e0                	jmp    cc00 <__divmodti4+0x1f0>

000000000000cc20 <atexit>:
    cc20:	f3 0f 1e fa          	endbr64
    cc24:	48 8b 15 dd 43 00 00 	mov    0x43dd(%rip),%rdx        # 11008 <__dso_handle>
    cc2b:	31 f6                	xor    %esi,%esi
    cc2d:	e9 2e 6a ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000cc34 <_fini>:
    cc34:	f3 0f 1e fa          	endbr64
    cc38:	48 83 ec 08          	sub    $0x8,%rsp
    cc3c:	48 83 c4 08          	add    $0x8,%rsp
    cc40:	c3                   	ret
