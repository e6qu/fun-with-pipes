
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-history:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 c9 cf 00 00 	mov    0xcfc9(%rip),%rax        # ffd8 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 e2 cd 00 00    	push   0xcde2(%rip)        # fe08 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 e4 cd 00 00    	jmp    *0xcde4(%rip)        # fe10 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax
    3380:	f3 0f 1e fa          	endbr64
    3384:	68 35 00 00 00       	push   $0x35
    3389:	e9 92 fc ff ff       	jmp    3020 <_init+0x20>
    338e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003390 <__cxa_finalize@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 4e cc 00 00    	jmp    *0xcc4e(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

00000000000033a0 <getenv@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 6e ca 00 00    	jmp    *0xca6e(%rip)        # fe18 <getenv@GLIBC_2.2.5>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <__snprintf_chk@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 66 ca 00 00    	jmp    *0xca66(%rip)        # fe20 <__snprintf_chk@GLIBC_2.3.4>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <free@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 5e ca 00 00    	jmp    *0xca5e(%rip)        # fe28 <free@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <abort@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 56 ca 00 00    	jmp    *0xca56(%rip)        # fe30 <abort@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <_exit@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 4e ca 00 00    	jmp    *0xca4e(%rip)        # fe38 <_exit@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <strcpy@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 46 ca 00 00    	jmp    *0xca46(%rip)        # fe40 <strcpy@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <sigaction@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 3e ca 00 00    	jmp    *0xca3e(%rip)        # fe48 <sigaction@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <strtod@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 36 ca 00 00    	jmp    *0xca36(%rip)        # fe50 <strtod@GLIBC_2.2.5>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <clock_gettime@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 2e ca 00 00    	jmp    *0xca2e(%rip)        # fe58 <clock_gettime@GLIBC_2.17>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <write@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 26 ca 00 00    	jmp    *0xca26(%rip)        # fe60 <write@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <fclose@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 1e ca 00 00    	jmp    *0xca1e(%rip)        # fe68 <fclose@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <strlen@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 16 ca 00 00    	jmp    *0xca16(%rip)        # fe70 <strlen@GLIBC_2.2.5>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <__stack_chk_fail@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 0e ca 00 00    	jmp    *0xca0e(%rip)        # fe78 <__stack_chk_fail@GLIBC_2.4>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <mmap@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 06 ca 00 00    	jmp    *0xca06(%rip)        # fe80 <mmap@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <strchr@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 fe c9 00 00    	jmp    *0xc9fe(%rip)        # fe88 <strchr@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <swapcontext@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 f6 c9 00 00    	jmp    *0xc9f6(%rip)        # fe90 <swapcontext@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <nanosleep@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 ee c9 00 00    	jmp    *0xc9ee(%rip)        # fe98 <nanosleep@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <strtof@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 e6 c9 00 00    	jmp    *0xc9e6(%rip)        # fea0 <strtof@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <memset@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 de c9 00 00    	jmp    *0xc9de(%rip)        # fea8 <memset@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <close@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 d6 c9 00 00    	jmp    *0xc9d6(%rip)        # feb0 <close@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <fputc@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 ce c9 00 00    	jmp    *0xc9ce(%rip)        # feb8 <fputc@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <pthread_attr_init@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 c6 c9 00 00    	jmp    *0xc9c6(%rip)        # fec0 <pthread_attr_init@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <fgets@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 be c9 00 00    	jmp    *0xc9be(%rip)        # fec8 <fgets@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <strtoull@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 b6 c9 00 00    	jmp    *0xc9b6(%rip)        # fed0 <strtoull@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <calloc@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 ae c9 00 00    	jmp    *0xc9ae(%rip)        # fed8 <calloc@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <strcmp@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 a6 c9 00 00    	jmp    *0xc9a6(%rip)        # fee0 <strcmp@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <signal@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 9e c9 00 00    	jmp    *0xc99e(%rip)        # fee8 <signal@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <strtoll@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 96 c9 00 00    	jmp    *0xc996(%rip)        # fef0 <strtoll@GLIBC_2.2.5>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <__memmove_chk@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 8e c9 00 00    	jmp    *0xc98e(%rip)        # fef8 <__memmove_chk@GLIBC_2.3.4>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <__memcpy_chk@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 86 c9 00 00    	jmp    *0xc986(%rip)        # ff00 <__memcpy_chk@GLIBC_2.3.4>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <sigemptyset@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 7e c9 00 00    	jmp    *0xc97e(%rip)        # ff08 <sigemptyset@GLIBC_2.2.5>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <strtol@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 76 c9 00 00    	jmp    *0xc976(%rip)        # ff10 <strtol@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <memcpy@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 6e c9 00 00    	jmp    *0xc96e(%rip)        # ff18 <memcpy@GLIBC_2.14>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <malloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 66 c9 00 00    	jmp    *0xc966(%rip)        # ff20 <malloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <fflush@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 5e c9 00 00    	jmp    *0xc95e(%rip)        # ff28 <fflush@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <realloc@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 56 c9 00 00    	jmp    *0xc956(%rip)        # ff30 <realloc@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <munmap@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 4e c9 00 00    	jmp    *0xc94e(%rip)        # ff38 <munmap@GLIBC_2.2.5>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <setvbuf@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 46 c9 00 00    	jmp    *0xc946(%rip)        # ff40 <setvbuf@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <pthread_create@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 3e c9 00 00    	jmp    *0xc93e(%rip)        # ff48 <pthread_create@GLIBC_2.34>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <memmove@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 36 c9 00 00    	jmp    *0xc936(%rip)        # ff50 <memmove@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <mprotect@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 2e c9 00 00    	jmp    *0xc92e(%rip)        # ff58 <mprotect@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <fopen@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 26 c9 00 00    	jmp    *0xc926(%rip)        # ff60 <fopen@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <sysconf@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 1e c9 00 00    	jmp    *0xc91e(%rip)        # ff68 <sysconf@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <pthread_attr_destroy@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 16 c9 00 00    	jmp    *0xc916(%rip)        # ff70 <pthread_attr_destroy@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <__cxa_atexit@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 0e c9 00 00    	jmp    *0xc90e(%rip)        # ff78 <__cxa_atexit@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <exit@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 06 c9 00 00    	jmp    *0xc906(%rip)        # ff80 <exit@GLIBC_2.2.5>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <fwrite@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 fe c8 00 00    	jmp    *0xc8fe(%rip)        # ff88 <fwrite@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <__fprintf_chk@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 f6 c8 00 00    	jmp    *0xc8f6(%rip)        # ff90 <__fprintf_chk@GLIBC_2.3.4>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <_Exit@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 ee c8 00 00    	jmp    *0xc8ee(%rip)        # ff98 <_Exit@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <pthread_join@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 e6 c8 00 00    	jmp    *0xc8e6(%rip)        # ffa0 <pthread_join@GLIBC_2.34>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <sigaltstack@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 de c8 00 00    	jmp    *0xc8de(%rip)        # ffa8 <sigaltstack@GLIBC_2.2.5>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <strstr@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 d6 c8 00 00    	jmp    *0xc8d6(%rip)        # ffb0 <strstr@GLIBC_2.2.5>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036e0 <__sprintf_chk@plt>:
    36e0:	f3 0f 1e fa          	endbr64
    36e4:	ff 25 ce c8 00 00    	jmp    *0xc8ce(%rip)        # ffb8 <__sprintf_chk@GLIBC_2.3.4>
    36ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036f0 <pthread_attr_setstacksize@plt>:
    36f0:	f3 0f 1e fa          	endbr64
    36f4:	ff 25 c6 c8 00 00    	jmp    *0xc8c6(%rip)        # ffc0 <pthread_attr_setstacksize@GLIBC_2.34>
    36fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

0000000000003700 <fwp_trap_overflow.constprop.0>:
    3700:	53                   	push   %rbx
    3701:	b9 60 00 00 00       	mov    $0x60,%ecx
    3706:	ba 02 00 00 00       	mov    $0x2,%edx
    370b:	be 60 00 00 00       	mov    $0x60,%esi
    3710:	4c 8d 0d 7a 89 00 00 	lea    0x897a(%rip),%r9        # c091 <_IO_stdin_used+0x91>
    3717:	4c 8d 05 77 89 00 00 	lea    0x8977(%rip),%r8        # c095 <_IO_stdin_used+0x95>
    371e:	48 83 ec 70          	sub    $0x70,%rsp
    3722:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3729:	00 00 
    372b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3730:	31 c0                	xor    %eax,%eax
    3732:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3737:	e8 74 fc ff ff       	call   33b0 <__snprintf_chk@plt>
    373c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3741:	e8 5a 0a 00 00       	call   41a0 <fwp_trap>

0000000000003746 <fwp_task_dispose.cold>:
    3746:	e8 85 fc ff ff       	call   33d0 <abort@plt>

000000000000374b <f12.cold>:
    374b:	e8 80 fc ff ff       	call   33d0 <abort@plt>

0000000000003750 <fwp_main_thread.cold>:
    3750:	e8 7b fc ff ff       	call   33d0 <abort@plt>

0000000000003755 <main.cold>:
    3755:	e8 76 fc ff ff       	call   33d0 <abort@plt>
    375a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003760 <main>:
    3760:	f3 0f 1e fa          	endbr64
    3764:	55                   	push   %rbp
    3765:	53                   	push   %rbx
    3766:	48 83 ec 68          	sub    $0x68,%rsp
    376a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3771:	00 00 
    3773:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3778:	48 8d 05 01 ad 00 00 	lea    0xad01(%rip),%rax        # e480 <fwp_fn_table>
    377f:	48 89 05 32 ec 01 00 	mov    %rax,0x1ec32(%rip)        # 223b8 <fwp_fns>
    3786:	48 8b 05 93 c8 00 00 	mov    0xc893(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    378d:	48 89 05 2c ec 01 00 	mov    %rax,0x1ec2c(%rip)        # 223c0 <fwp_prog_out>
    3794:	e8 77 0b 00 00       	call   4310 <fwp_now_ns>
    3799:	48 8d 3d 59 8a 00 00 	lea    0x8a59(%rip),%rdi        # c1f9 <_IO_stdin_used+0x1f9>
    37a0:	e8 fb fb ff ff       	call   33a0 <getenv@plt>
    37a5:	48 85 c0             	test   %rax,%rax
    37a8:	74 0c                	je     37b6 <main+0x56>
    37aa:	48 89 c3             	mov    %rax,%rbx
    37ad:	80 38 00             	cmpb   $0x0,(%rax)
    37b0:	0f 85 09 01 00 00    	jne    38bf <main+0x15f>
    37b6:	31 ff                	xor    %edi,%edi
    37b8:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    37bd:	e8 5e fc ff ff       	call   3420 <clock_gettime@plt>
    37c2:	85 c0                	test   %eax,%eax
    37c4:	0f 85 28 01 00 00    	jne    38f2 <main+0x192>
    37ca:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37cf:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37d4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37d9:	48 89 cb             	mov    %rcx,%rbx
    37dc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37e0:	48 01 c8             	add    %rcx,%rax
    37e3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ea:	00 00 80 
    37ed:	48 11 da             	adc    %rbx,%rdx
    37f0:	31 db                	xor    %ebx,%ebx
    37f2:	48 01 c8             	add    %rcx,%rax
    37f5:	48 11 da             	adc    %rbx,%rdx
    37f8:	48 85 d2             	test   %rdx,%rdx
    37fb:	0f 85 38 01 00 00    	jne    3939 <main+0x1d9>
    3801:	48 8b 3d 18 c8 00 00 	mov    0xc818(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3808:	31 d2                	xor    %edx,%edx
    380a:	31 f6                	xor    %esi,%esi
    380c:	b9 00 00 01 00       	mov    $0x10000,%ecx
    3811:	e8 da fd ff ff       	call   35f0 <setvbuf@plt>
    3816:	bf 0d 00 00 00       	mov    $0xd,%edi
    381b:	be 01 00 00 00       	mov    $0x1,%esi
    3820:	e8 1b fd ff ff       	call   3540 <signal@plt>
    3825:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    382a:	e8 c1 fc ff ff       	call   34f0 <pthread_attr_init@plt>
    382f:	85 c0                	test   %eax,%eax
    3831:	0f 85 f6 00 00 00    	jne    392d <main+0x1cd>
    3837:	be 00 00 00 40       	mov    $0x40000000,%esi
    383c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3841:	e8 aa fe ff ff       	call   36f0 <pthread_attr_setstacksize@plt>
    3846:	85 c0                	test   %eax,%eax
    3848:	0f 85 c1 00 00 00    	jne    390f <main+0x1af>
    384e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3853:	31 c9                	xor    %ecx,%ecx
    3855:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    385a:	48 8d 15 6f 76 00 00 	lea    0x766f(%rip),%rdx        # aed0 <fwp_main_thread>
    3861:	e8 9a fd ff ff       	call   3600 <pthread_create@plt>
    3866:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    386b:	89 c5                	mov    %eax,%ebp
    386d:	e8 de fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3872:	85 c0                	test   %eax,%eax
    3874:	0f 85 db fe ff ff    	jne    3755 <main.cold>
    387a:	85 ed                	test   %ebp,%ebp
    387c:	0f 85 81 00 00 00    	jne    3903 <main+0x1a3>
    3882:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3887:	31 f6                	xor    %esi,%esi
    3889:	e8 22 fe ff ff       	call   36b0 <pthread_join@plt>
    388e:	85 c0                	test   %eax,%eax
    3890:	0f 85 bf fe ff ff    	jne    3755 <main.cold>
    3896:	48 8b 3d 83 c7 00 00 	mov    0xc783(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    389d:	e8 1e fd ff ff       	call   35c0 <fflush@plt>
    38a2:	8b 05 d8 c7 01 00    	mov    0x1c7d8(%rip),%eax        # 20080 <fwp_exit_code>
    38a8:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    38ad:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    38b4:	00 00 
    38b6:	75 46                	jne    38fe <main+0x19e>
    38b8:	48 83 c4 68          	add    $0x68,%rsp
    38bc:	5b                   	pop    %rbx
    38bd:	5d                   	pop    %rbp
    38be:	c3                   	ret
    38bf:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38c4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38c9:	48 89 c7             	mov    %rax,%rdi
    38cc:	e8 3f fc ff ff       	call   3510 <strtoull@plt>
    38d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38d6:	80 38 00             	cmpb   $0x0,(%rax)
    38d9:	0f 85 d7 fe ff ff    	jne    37b6 <main+0x56>
    38df:	0f b6 03             	movzbl (%rbx),%eax
    38e2:	83 e8 2b             	sub    $0x2b,%eax
    38e5:	a8 fd                	test   $0xfd,%al
    38e7:	0f 84 c9 fe ff ff    	je     37b6 <main+0x56>
    38ed:	e9 0f ff ff ff       	jmp    3801 <main+0xa1>
    38f2:	48 8d 3d 09 89 00 00 	lea    0x8909(%rip),%rdi        # c202 <_IO_stdin_used+0x202>
    38f9:	e8 a2 08 00 00       	call   41a0 <fwp_trap>
    38fe:	e8 5d fb ff ff       	call   3460 <__stack_chk_fail@plt>
    3903:	48 8d 3d 8e 90 00 00 	lea    0x908e(%rip),%rdi        # c998 <_IO_stdin_used+0x998>
    390a:	e8 91 08 00 00       	call   41a0 <fwp_trap>
    390f:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3914:	e8 37 fd ff ff       	call   3650 <pthread_attr_destroy@plt>
    3919:	85 c0                	test   %eax,%eax
    391b:	0f 85 34 fe ff ff    	jne    3755 <main.cold>
    3921:	48 8d 3d 48 90 00 00 	lea    0x9048(%rip),%rdi        # c970 <_IO_stdin_used+0x970>
    3928:	e8 73 08 00 00       	call   41a0 <fwp_trap>
    392d:	48 8d 3d 0c 90 00 00 	lea    0x900c(%rip),%rdi        # c940 <_IO_stdin_used+0x940>
    3934:	e8 67 08 00 00       	call   41a0 <fwp_trap>
    3939:	48 8d 3d d8 8f 00 00 	lea    0x8fd8(%rip),%rdi        # c918 <_IO_stdin_used+0x918>
    3940:	e8 5b 08 00 00       	call   41a0 <fwp_trap>
    3945:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    394c:	00 00 00 
    394f:	90                   	nop

0000000000003950 <_start>:
    3950:	f3 0f 1e fa          	endbr64
    3954:	31 ed                	xor    %ebp,%ebp
    3956:	49 89 d1             	mov    %rdx,%r9
    3959:	5e                   	pop    %rsi
    395a:	48 89 e2             	mov    %rsp,%rdx
    395d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3961:	50                   	push   %rax
    3962:	54                   	push   %rsp
    3963:	45 31 c0             	xor    %r8d,%r8d
    3966:	31 c9                	xor    %ecx,%ecx
    3968:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3760 <main>
    396f:	ff 15 53 c6 00 00    	call   *0xc653(%rip)        # ffc8 <__libc_start_main@GLIBC_2.34>
    3975:	f4                   	hlt
    3976:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    397d:	00 00 00 

0000000000003980 <deregister_tm_clones>:
    3980:	48 8d 3d 99 c6 00 00 	lea    0xc699(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3987:	48 8d 05 92 c6 00 00 	lea    0xc692(%rip),%rax        # 10020 <stdout@GLIBC_2.2.5>
    398e:	48 39 f8             	cmp    %rdi,%rax
    3991:	74 15                	je     39a8 <deregister_tm_clones+0x28>
    3993:	48 8b 05 36 c6 00 00 	mov    0xc636(%rip),%rax        # ffd0 <_ITM_deregisterTMCloneTable>
    399a:	48 85 c0             	test   %rax,%rax
    399d:	74 09                	je     39a8 <deregister_tm_clones+0x28>
    399f:	ff e0                	jmp    *%rax
    39a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    39a8:	c3                   	ret
    39a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039b0 <register_tm_clones>:
    39b0:	48 8d 3d 69 c6 00 00 	lea    0xc669(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    39b7:	48 8d 35 62 c6 00 00 	lea    0xc662(%rip),%rsi        # 10020 <stdout@GLIBC_2.2.5>
    39be:	48 29 fe             	sub    %rdi,%rsi
    39c1:	48 89 f0             	mov    %rsi,%rax
    39c4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39c8:	48 c1 f8 03          	sar    $0x3,%rax
    39cc:	48 01 c6             	add    %rax,%rsi
    39cf:	48 d1 fe             	sar    $1,%rsi
    39d2:	74 14                	je     39e8 <register_tm_clones+0x38>
    39d4:	48 8b 05 05 c6 00 00 	mov    0xc605(%rip),%rax        # ffe0 <_ITM_registerTMCloneTable>
    39db:	48 85 c0             	test   %rax,%rax
    39de:	74 08                	je     39e8 <register_tm_clones+0x38>
    39e0:	ff e0                	jmp    *%rax
    39e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39e8:	c3                   	ret
    39e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039f0 <__do_global_dtors_aux>:
    39f0:	f3 0f 1e fa          	endbr64
    39f4:	80 3d 4d c6 00 00 00 	cmpb   $0x0,0xc64d(%rip)        # 10048 <completed.0>
    39fb:	75 2b                	jne    3a28 <__do_global_dtors_aux+0x38>
    39fd:	55                   	push   %rbp
    39fe:	48 83 3d e2 c5 00 00 	cmpq   $0x0,0xc5e2(%rip)        # ffe8 <__cxa_finalize@GLIBC_2.2.5>
    3a05:	00 
    3a06:	48 89 e5             	mov    %rsp,%rbp
    3a09:	74 0c                	je     3a17 <__do_global_dtors_aux+0x27>
    3a0b:	48 8b 3d f6 c5 00 00 	mov    0xc5f6(%rip),%rdi        # 10008 <__dso_handle>
    3a12:	e8 79 f9 ff ff       	call   3390 <__cxa_finalize@plt>
    3a17:	e8 64 ff ff ff       	call   3980 <deregister_tm_clones>
    3a1c:	c6 05 25 c6 00 00 01 	movb   $0x1,0xc625(%rip)        # 10048 <completed.0>
    3a23:	5d                   	pop    %rbp
    3a24:	c3                   	ret
    3a25:	0f 1f 00             	nopl   (%rax)
    3a28:	c3                   	ret
    3a29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a30 <frame_dummy>:
    3a30:	f3 0f 1e fa          	endbr64
    3a34:	e9 77 ff ff ff       	jmp    39b0 <register_tm_clones>
    3a39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a40 <fwp_fmt_u128>:
    3a40:	41 57                	push   %r15
    3a42:	41 56                	push   %r14
    3a44:	41 55                	push   %r13
    3a46:	41 54                	push   %r12
    3a48:	55                   	push   %rbp
    3a49:	53                   	push   %rbx
    3a4a:	48 83 ec 68          	sub    $0x68,%rsp
    3a4e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a55:	00 00 
    3a57:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a5c:	48 89 f0             	mov    %rsi,%rax
    3a5f:	48 09 d0             	or     %rdx,%rax
    3a62:	75 7c                	jne    3ae0 <fwp_fmt_u128+0xa0>
    3a64:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a69:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a6e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a73:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a76:	48 89 f8             	mov    %rdi,%rax
    3a79:	49 01 d4             	add    %rdx,%r12
    3a7c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a81:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a88:	00 00 
    3a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a91:	00 00 00 00 
    3a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a9c:	00 00 00 00 
    3aa0:	41 0f b6 14 24       	movzbl (%r12),%edx
    3aa5:	48 83 c0 01          	add    $0x1,%rax
    3aa9:	49 83 ec 01          	sub    $0x1,%r12
    3aad:	88 50 ff             	mov    %dl,-0x1(%rax)
    3ab0:	48 39 c8             	cmp    %rcx,%rax
    3ab3:	75 eb                	jne    3aa0 <fwp_fmt_u128+0x60>
    3ab5:	48 63 ed             	movslq %ebp,%rbp
    3ab8:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3abc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3ac1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3ac8:	00 00 
    3aca:	0f 85 ef 00 00 00    	jne    3bbf <fwp_fmt_u128+0x17f>
    3ad0:	48 83 c4 68          	add    $0x68,%rsp
    3ad4:	5b                   	pop    %rbx
    3ad5:	5d                   	pop    %rbp
    3ad6:	41 5c                	pop    %r12
    3ad8:	41 5d                	pop    %r13
    3ada:	41 5e                	pop    %r14
    3adc:	41 5f                	pop    %r15
    3ade:	c3                   	ret
    3adf:	90                   	nop
    3ae0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ae5:	49 89 f2             	mov    %rsi,%r10
    3ae8:	49 89 d3             	mov    %rdx,%r11
    3aeb:	31 ed                	xor    %ebp,%ebp
    3aed:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3af2:	4c 89 e3             	mov    %r12,%rbx
    3af5:	45 31 f6             	xor    %r14d,%r14d
    3af8:	49 89 f9             	mov    %rdi,%r9
    3afb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3b02:	cc cc cc 
    3b05:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3b0b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3b12:	cc cc cc 
    3b15:	4c 89 2c 24          	mov    %r13,(%rsp)
    3b19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b20:	4c 89 d6             	mov    %r10,%rsi
    3b23:	4c 89 df             	mov    %r11,%rdi
    3b26:	4c 01 de             	add    %r11,%rsi
    3b29:	48 83 d6 00          	adc    $0x0,%rsi
    3b2d:	45 31 ed             	xor    %r13d,%r13d
    3b30:	48 89 f0             	mov    %rsi,%rax
    3b33:	48 f7 e1             	mul    %rcx
    3b36:	48 89 d0             	mov    %rdx,%rax
    3b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b3d:	48 c1 e8 02          	shr    $0x2,%rax
    3b41:	48 01 c2             	add    %rax,%rdx
    3b44:	48 8b 04 24          	mov    (%rsp),%rax
    3b48:	48 29 d6             	sub    %rdx,%rsi
    3b4b:	49 89 f4             	mov    %rsi,%r12
    3b4e:	4c 89 d6             	mov    %r10,%rsi
    3b51:	4c 29 e6             	sub    %r12,%rsi
    3b54:	4c 19 ef             	sbb    %r13,%rdi
    3b57:	48 0f af c6          	imul   %rsi,%rax
    3b5b:	49 89 f8             	mov    %rdi,%r8
    3b5e:	4c 0f af c1          	imul   %rcx,%r8
    3b62:	49 01 c0             	add    %rax,%r8
    3b65:	48 89 f0             	mov    %rsi,%rax
    3b68:	48 f7 e1             	mul    %rcx
    3b6b:	48 89 c6             	mov    %rax,%rsi
    3b6e:	83 e0 01             	and    $0x1,%eax
    3b71:	49 01 d0             	add    %rdx,%r8
    3b74:	49 f7 e7             	mul    %r15
    3b77:	4c 89 c7             	mov    %r8,%rdi
    3b7a:	4c 89 d2             	mov    %r10,%rdx
    3b7d:	4c 01 e0             	add    %r12,%rax
    3b80:	48 d1 ef             	shr    $1,%rdi
    3b83:	83 c5 01             	add    $0x1,%ebp
    3b86:	48 83 c3 01          	add    $0x1,%rbx
    3b8a:	83 c0 30             	add    $0x30,%eax
    3b8d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b92:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b95:	4c 89 d8             	mov    %r11,%rax
    3b98:	49 89 fb             	mov    %rdi,%r11
    3b9b:	bf 09 00 00 00       	mov    $0x9,%edi
    3ba0:	48 39 d7             	cmp    %rdx,%rdi
    3ba3:	4c 89 f7             	mov    %r14,%rdi
    3ba6:	49 89 f2             	mov    %rsi,%r10
    3ba9:	48 19 c7             	sbb    %rax,%rdi
    3bac:	0f 82 6e ff ff ff    	jb     3b20 <fwp_fmt_u128+0xe0>
    3bb2:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3bb7:	4c 89 cf             	mov    %r9,%rdi
    3bba:	e9 b4 fe ff ff       	jmp    3a73 <fwp_fmt_u128+0x33>
    3bbf:	e8 9c f8 ff ff       	call   3460 <__stack_chk_fail@plt>
    3bc4:	90                   	nop
    3bc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bcc:	00 00 00 00 

0000000000003bd0 <fwp_range_release>:
    3bd0:	f3 0f 1e fa          	endbr64
    3bd4:	53                   	push   %rbx
    3bd5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bd9:	48 89 fb             	mov    %rdi,%rbx
    3bdc:	48 85 c0             	test   %rax,%rax
    3bdf:	74 06                	je     3be7 <fwp_range_release+0x17>
    3be1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3be5:	ff d0                	call   *%rax
    3be7:	48 8b 3b             	mov    (%rbx),%rdi
    3bea:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bee:	5b                   	pop    %rbx
    3bef:	ff e0                	jmp    *%rax
    3bf1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bfc:	00 00 00 00 

0000000000003c00 <fwp_tape_unlink_scope>:
    3c00:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c04:	48 85 d2             	test   %rdx,%rdx
    3c07:	74 3e                	je     3c47 <fwp_tape_unlink_scope+0x47>
    3c09:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c0c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c10:	85 c9                	test   %ecx,%ecx
    3c12:	78 3c                	js     3c50 <fwp_tape_unlink_scope+0x50>
    3c14:	48 63 d1             	movslq %ecx,%rdx
    3c17:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c1b:	48 03 15 ce c4 01 00 	add    0x1c4ce(%rip),%rdx        # 200f0 <fwp_tapes>
    3c22:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c25:	85 c0                	test   %eax,%eax
    3c27:	78 0e                	js     3c37 <fwp_tape_unlink_scope+0x37>
    3c29:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c2d:	48 03 05 bc c4 01 00 	add    0x1c4bc(%rip),%rax        # 200f0 <fwp_tapes>
    3c34:	89 48 58             	mov    %ecx,0x58(%rax)
    3c37:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3c3e:	00 
    3c3f:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3c46:	ff 
    3c47:	c3                   	ret
    3c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3c4f:	00 
    3c50:	89 02                	mov    %eax,(%rdx)
    3c52:	eb d1                	jmp    3c25 <fwp_tape_unlink_scope+0x25>
    3c54:	90                   	nop
    3c55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c5c:	00 00 00 00 

0000000000003c60 <fwp_args161>:
    3c60:	f3 0f 1e fa          	endbr64
    3c64:	c3                   	ret
    3c65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3c6c:	00 00 00 00 

0000000000003c70 <fwp_flush>:
    3c70:	48 8b 3d 49 e7 01 00 	mov    0x1e749(%rip),%rdi        # 223c0 <fwp_prog_out>
    3c77:	48 85 ff             	test   %rdi,%rdi
    3c7a:	74 1c                	je     3c98 <fwp_flush+0x28>
    3c7c:	48 83 ec 08          	sub    $0x8,%rsp
    3c80:	e8 3b f9 ff ff       	call   35c0 <fflush@plt>
    3c85:	48 8b 3d 94 c3 00 00 	mov    0xc394(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c8c:	48 83 c4 08          	add    $0x8,%rsp
    3c90:	e9 2b f9 ff ff       	jmp    35c0 <fflush@plt>
    3c95:	0f 1f 00             	nopl   (%rax)
    3c98:	48 8b 3d 81 c3 00 00 	mov    0xc381(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    3c9f:	e9 1c f9 ff ff       	jmp    35c0 <fflush@plt>
    3ca4:	90                   	nop
    3ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cac:	00 00 00 00 

0000000000003cb0 <fwp_heap_oom>:
    3cb0:	50                   	push   %rax
    3cb1:	58                   	pop    %rax
    3cb2:	ba 13 00 00 00       	mov    $0x13,%edx
    3cb7:	be 01 00 00 00       	mov    $0x1,%esi
    3cbc:	48 8d 3d 45 83 00 00 	lea    0x8345(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    3cc3:	48 83 ec 08          	sub    $0x8,%rsp
    3cc7:	48 8b 0d 72 c3 00 00 	mov    0xc372(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    3cce:	e8 ad f9 ff ff       	call   3680 <fwrite@plt>
    3cd3:	31 ff                	xor    %edi,%edi
    3cd5:	e8 e6 f8 ff ff       	call   35c0 <fflush@plt>
    3cda:	bf 66 00 00 00       	mov    $0x66,%edi
    3cdf:	e8 bc f9 ff ff       	call   36a0 <_Exit@plt>
    3ce4:	90                   	nop
    3ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cec:	00 00 00 00 

0000000000003cf0 <fwp_segv>:
    3cf0:	f3 0f 1e fa          	endbr64
    3cf4:	48 83 ec 28          	sub    $0x28,%rsp
    3cf8:	48 8b 05 41 ca 01 00 	mov    0x1ca41(%rip),%rax        # 20740 <fwp_cur>
    3cff:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d03:	41 89 f8             	mov    %edi,%r8d
    3d06:	48 85 c0             	test   %rax,%rax
    3d09:	74 6d                	je     3d78 <fwp_segv+0x88>
    3d0b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d0f:	48 85 d2             	test   %rdx,%rdx
    3d12:	74 64                	je     3d78 <fwp_segv+0x88>
    3d14:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d18:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d1d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d22:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d27:	e8 14 f9 ff ff       	call   3640 <sysconf@plt>
    3d2c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d31:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d36:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d3b:	48 01 d0             	add    %rdx,%rax
    3d3e:	48 39 c1             	cmp    %rax,%rcx
    3d41:	b8 00 00 00 00       	mov    $0x0,%eax
    3d46:	40 0f 92 c6          	setb   %sil
    3d4a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d51:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d55:	31 c0                	xor    %eax,%eax
    3d57:	48 39 d1             	cmp    %rdx,%rcx
    3d5a:	0f 93 c0             	setae  %al
    3d5d:	21 f0                	and    %esi,%eax
    3d5f:	85 c0                	test   %eax,%eax
    3d61:	75 4a                	jne    3dad <fwp_segv+0xbd>
    3d63:	31 f6                	xor    %esi,%esi
    3d65:	44 89 c7             	mov    %r8d,%edi
    3d68:	48 83 c4 28          	add    $0x28,%rsp
    3d6c:	e9 cf f7 ff ff       	jmp    3540 <signal@plt>
    3d71:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3d78:	48 8b 05 81 c3 01 00 	mov    0x1c381(%rip),%rax        # 20100 <fwp_main_stack_top>
    3d7f:	48 85 c0             	test   %rax,%rax
    3d82:	74 df                	je     3d63 <fwp_segv+0x73>
    3d84:	48 2b 05 6d c3 01 00 	sub    0x1c36d(%rip),%rax        # 200f8 <fwp_main_stack_size>
    3d8b:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3d92:	48 39 d1             	cmp    %rdx,%rcx
    3d95:	0f 93 c2             	setae  %dl
    3d98:	48 05 00 00 10 00    	add    $0x100000,%rax
    3d9e:	48 39 c1             	cmp    %rax,%rcx
    3da1:	0f 92 c0             	setb   %al
    3da4:	0f b6 c0             	movzbl %al,%eax
    3da7:	21 d0                	and    %edx,%eax
    3da9:	85 c0                	test   %eax,%eax
    3dab:	74 b6                	je     3d63 <fwp_segv+0x73>
    3dad:	e8 be fe ff ff       	call   3c70 <fwp_flush>
    3db2:	bf 02 00 00 00       	mov    $0x2,%edi
    3db7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dbc:	48 8d 35 bd 8c 00 00 	lea    0x8cbd(%rip),%rsi        # ca80 <msg.4>
    3dc3:	e8 68 f6 ff ff       	call   3430 <write@plt>
    3dc8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dcd:	e8 0e f6 ff ff       	call   33e0 <_exit@plt>
    3dd2:	0f 1f 00             	nopl   (%rax)
    3dd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ddc:	00 00 00 00 

0000000000003de0 <fwp_heap_chunks>:
    3de0:	41 54                	push   %r12
    3de2:	55                   	push   %rbp
    3de3:	53                   	push   %rbx
    3de4:	48 83 ff 01          	cmp    $0x1,%rdi
    3de8:	0f 84 62 01 00 00    	je     3f50 <fwp_heap_chunks+0x170>
    3dee:	48 8b 05 5b dd 01 00 	mov    0x1dd5b(%rip),%rax        # 21b50 <fwp_heap+0x13f0>
    3df5:	4c 8d 05 54 dd 01 00 	lea    0x1dd54(%rip),%r8        # 21b50 <fwp_heap+0x13f0>
    3dfc:	48 8b 1d 35 dd 01 00 	mov    0x1dd35(%rip),%rbx        # 21b38 <fwp_heap+0x13d8>
    3e03:	48 39 d8             	cmp    %rbx,%rax
    3e06:	0f 83 57 01 00 00    	jae    3f63 <fwp_heap_chunks+0x183>
    3e0c:	48 8b 0d 45 dd 01 00 	mov    0x1dd45(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    3e13:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e17:	31 f6                	xor    %esi,%esi
    3e19:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e1d:	eb 1e                	jmp    3e3d <fwp_heap_chunks+0x5d>
    3e1f:	90                   	nop
    3e20:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e24:	48 39 cf             	cmp    %rcx,%rdi
    3e27:	0f 84 03 01 00 00    	je     3f30 <fwp_heap_chunks+0x150>
    3e2d:	48 83 c0 01          	add    $0x1,%rax
    3e31:	48 89 ce             	mov    %rcx,%rsi
    3e34:	48 83 c2 28          	add    $0x28,%rdx
    3e38:	48 39 c3             	cmp    %rax,%rbx
    3e3b:	74 14                	je     3e51 <fwp_heap_chunks+0x71>
    3e3d:	80 3a 00             	cmpb   $0x0,(%rdx)
    3e40:	74 de                	je     3e20 <fwp_heap_chunks+0x40>
    3e42:	48 83 c0 01          	add    $0x1,%rax
    3e46:	31 f6                	xor    %esi,%esi
    3e48:	48 83 c2 28          	add    $0x28,%rdx
    3e4c:	48 39 c3             	cmp    %rax,%rbx
    3e4f:	75 ec                	jne    3e3d <fwp_heap_chunks+0x5d>
    3e51:	48 29 f3             	sub    %rsi,%rbx
    3e54:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3e58:	48 8b 3d e1 dc 01 00 	mov    0x1dce1(%rip),%rdi        # 21b40 <fwp_heap+0x13e0>
    3e5f:	48 29 35 2a dd 01 00 	sub    %rsi,0x1dd2a(%rip)        # 21b90 <fwp_heap+0x1430>
    3e66:	48 39 ef             	cmp    %rbp,%rdi
    3e69:	0f 83 96 00 00 00    	jae    3f05 <fwp_heap_chunks+0x125>
    3e6f:	48 8b 05 ba dc 01 00 	mov    0x1dcba(%rip),%rax        # 21b30 <fwp_heap+0x13d0>
    3e76:	48 39 e8             	cmp    %rbp,%rax
    3e79:	0f 82 eb 00 00 00    	jb     3f6a <fwp_heap_chunks+0x18a>
    3e7f:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3e83:	ba 03 00 00 00       	mov    $0x3,%edx
    3e88:	49 39 c4             	cmp    %rax,%r12
    3e8b:	4c 0f 47 e0          	cmova  %rax,%r12
    3e8f:	4c 89 e6             	mov    %r12,%rsi
    3e92:	48 29 fe             	sub    %rdi,%rsi
    3e95:	48 c1 e7 10          	shl    $0x10,%rdi
    3e99:	48 03 3d 70 dc 01 00 	add    0x1dc70(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    3ea0:	48 c1 e6 10          	shl    $0x10,%rsi
    3ea4:	e8 77 f7 ff ff       	call   3620 <mprotect@plt>
    3ea9:	85 c0                	test   %eax,%eax
    3eab:	0f 85 b9 00 00 00    	jne    3f6a <fwp_heap_chunks+0x18a>
    3eb1:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3eb6:	e8 85 f7 ff ff       	call   3640 <sysconf@plt>
    3ebb:	48 8b 35 7e dc 01 00 	mov    0x1dc7e(%rip),%rsi        # 21b40 <fwp_heap+0x13e0>
    3ec2:	48 89 c1             	mov    %rax,%rcx
    3ec5:	48 8b 05 8c dc 01 00 	mov    0x1dc8c(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    3ecc:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3ed0:	48 89 ca             	mov    %rcx,%rdx
    3ed3:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3ed7:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3edb:	48 f7 da             	neg    %rdx
    3ede:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3ee3:	48 21 d7             	and    %rdx,%rdi
    3ee6:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3eea:	48 21 d6             	and    %rdx,%rsi
    3eed:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef2:	48 29 fe             	sub    %rdi,%rsi
    3ef5:	e8 26 f7 ff ff       	call   3620 <mprotect@plt>
    3efa:	85 c0                	test   %eax,%eax
    3efc:	75 6c                	jne    3f6a <fwp_heap_chunks+0x18a>
    3efe:	4c 89 25 3b dc 01 00 	mov    %r12,0x1dc3b(%rip)        # 21b40 <fwp_heap+0x13e0>
    3f05:	48 89 ef             	mov    %rbp,%rdi
    3f08:	48 89 2d 29 dc 01 00 	mov    %rbp,0x1dc29(%rip)        # 21b38 <fwp_heap+0x13d8>
    3f0f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f13:	48 39 3d 0e dc 01 00 	cmp    %rdi,0x1dc0e(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f1a:	73 07                	jae    3f23 <fwp_heap_chunks+0x143>
    3f1c:	48 89 3d 05 dc 01 00 	mov    %rdi,0x1dc05(%rip)        # 21b28 <fwp_heap+0x13c8>
    3f23:	48 89 d8             	mov    %rbx,%rax
    3f26:	5b                   	pop    %rbx
    3f27:	5d                   	pop    %rbp
    3f28:	41 5c                	pop    %r12
    3f2a:	c3                   	ret
    3f2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3f30:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3f34:	48 29 f0             	sub    %rsi,%rax
    3f37:	48 89 c3             	mov    %rax,%rbx
    3f3a:	49 89 10             	mov    %rdx,(%r8)
    3f3d:	48 89 d8             	mov    %rbx,%rax
    3f40:	48 29 3d 49 dc 01 00 	sub    %rdi,0x1dc49(%rip)        # 21b90 <fwp_heap+0x1430>
    3f47:	5b                   	pop    %rbx
    3f48:	5d                   	pop    %rbp
    3f49:	41 5c                	pop    %r12
    3f4b:	c3                   	ret
    3f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    3f50:	48 8b 05 f1 db 01 00 	mov    0x1dbf1(%rip),%rax        # 21b48 <fwp_heap+0x13e8>
    3f57:	4c 8d 05 ea db 01 00 	lea    0x1dbea(%rip),%r8        # 21b48 <fwp_heap+0x13e8>
    3f5e:	e9 99 fe ff ff       	jmp    3dfc <fwp_heap_chunks+0x1c>
    3f63:	31 f6                	xor    %esi,%esi
    3f65:	e9 ea fe ff ff       	jmp    3e54 <fwp_heap_chunks+0x74>
    3f6a:	e8 41 fd ff ff       	call   3cb0 <fwp_heap_oom>
    3f6f:	90                   	nop

0000000000003f70 <fwp_tape_buffers_dispose>:
    3f70:	53                   	push   %rbx
    3f71:	48 89 fb             	mov    %rdi,%rbx
    3f74:	48 8b 3f             	mov    (%rdi),%rdi
    3f77:	e8 44 f4 ff ff       	call   33c0 <free@plt>
    3f7c:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    3f80:	e8 3b f4 ff ff       	call   33c0 <free@plt>
    3f85:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    3f89:	e8 32 f4 ff ff       	call   33c0 <free@plt>
    3f8e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    3f92:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    3f99:	00 
    3f9a:	0f 11 03             	movups %xmm0,(%rbx)
    3f9d:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    3fa1:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    3fa5:	5b                   	pop    %rbx
    3fa6:	c3                   	ret
    3fa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3fae:	00 00 

0000000000003fb0 <buf_grow>:
    3fb0:	48 83 ec 18          	sub    $0x18,%rsp
    3fb4:	48 8b 47 08          	mov    0x8(%rdi),%rax
    3fb8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    3fbc:	74 7e                	je     403c <buf_grow+0x8c>
    3fbe:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    3fc5:	48 29 c2             	sub    %rax,%rdx
    3fc8:	48 39 f2             	cmp    %rsi,%rdx
    3fcb:	72 6f                	jb     403c <buf_grow+0x8c>
    3fcd:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    3fd2:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3fd6:	48 89 f9             	mov    %rdi,%rcx
    3fd9:	48 39 d0             	cmp    %rdx,%rax
    3fdc:	73 48                	jae    4026 <buf_grow+0x76>
    3fde:	48 85 c0             	test   %rax,%rax
    3fe1:	75 15                	jne    3ff8 <buf_grow+0x48>
    3fe3:	48 83 fa 40          	cmp    $0x40,%rdx
    3fe7:	76 4c                	jbe    4035 <buf_grow+0x85>
    3fe9:	b8 40 00 00 00       	mov    $0x40,%eax
    3fee:	eb 08                	jmp    3ff8 <buf_grow+0x48>
    3ff0:	48 01 c0             	add    %rax,%rax
    3ff3:	48 39 d0             	cmp    %rdx,%rax
    3ff6:	73 38                	jae    4030 <buf_grow+0x80>
    3ff8:	48 85 c0             	test   %rax,%rax
    3ffb:	79 f3                	jns    3ff0 <buf_grow+0x40>
    3ffd:	48 8b 39             	mov    (%rcx),%rdi
    4000:	48 89 d6             	mov    %rdx,%rsi
    4003:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4008:	48 89 14 24          	mov    %rdx,(%rsp)
    400c:	e8 bf f5 ff ff       	call   35d0 <realloc@plt>
    4011:	48 8b 14 24          	mov    (%rsp),%rdx
    4015:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    401a:	48 85 c0             	test   %rax,%rax
    401d:	74 1d                	je     403c <buf_grow+0x8c>
    401f:	48 89 01             	mov    %rax,(%rcx)
    4022:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4026:	48 83 c4 18          	add    $0x18,%rsp
    402a:	c3                   	ret
    402b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4030:	48 89 c2             	mov    %rax,%rdx
    4033:	eb c8                	jmp    3ffd <buf_grow+0x4d>
    4035:	ba 40 00 00 00       	mov    $0x40,%edx
    403a:	eb c1                	jmp    3ffd <buf_grow+0x4d>
    403c:	48 8b 0d fd bf 00 00 	mov    0xbffd(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    4043:	ba 13 00 00 00       	mov    $0x13,%edx
    4048:	be 01 00 00 00       	mov    $0x1,%esi
    404d:	48 8d 3d b4 7f 00 00 	lea    0x7fb4(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    4054:	e8 27 f6 ff ff       	call   3680 <fwrite@plt>
    4059:	31 ff                	xor    %edi,%edi
    405b:	e8 60 f5 ff ff       	call   35c0 <fflush@plt>
    4060:	bf 66 00 00 00       	mov    $0x66,%edi
    4065:	e8 36 f6 ff ff       	call   36a0 <_Exit@plt>
    406a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004070 <buf_put>:
    4070:	41 54                	push   %r12
    4072:	49 89 f4             	mov    %rsi,%r12
    4075:	48 89 d6             	mov    %rdx,%rsi
    4078:	55                   	push   %rbp
    4079:	48 89 fd             	mov    %rdi,%rbp
    407c:	53                   	push   %rbx
    407d:	48 89 d3             	mov    %rdx,%rbx
    4080:	e8 2b ff ff ff       	call   3fb0 <buf_grow>
    4085:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    4089:	48 89 da             	mov    %rbx,%rdx
    408c:	48 03 7d 00          	add    0x0(%rbp),%rdi
    4090:	4c 89 e6             	mov    %r12,%rsi
    4093:	e8 08 f5 ff ff       	call   35a0 <memcpy@plt>
    4098:	48 8b 45 00          	mov    0x0(%rbp),%rax
    409c:	48 03 5d 08          	add    0x8(%rbp),%rbx
    40a0:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    40a4:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    40a8:	5b                   	pop    %rbx
    40a9:	5d                   	pop    %rbp
    40aa:	41 5c                	pop    %r12
    40ac:	c3                   	ret
    40ad:	0f 1f 00             	nopl   (%rax)

00000000000040b0 <fwp_cancel_tree.part.0>:
    40b0:	48 3b 3d 89 c6 01 00 	cmp    0x1c689(%rip),%rdi        # 20740 <fwp_cur>
    40b7:	53                   	push   %rbx
    40b8:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    40bc:	74 35                	je     40f3 <fwp_cancel_tree.part.0+0x43>
    40be:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    40c2:	75 2f                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40c4:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    40c8:	75 29                	jne    40f3 <fwp_cancel_tree.part.0+0x43>
    40ca:	48 8b 05 4f c6 01 00 	mov    0x1c64f(%rip),%rax        # 20720 <fwp_ready_tail>
    40d1:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    40d5:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    40dc:	00 00 00 00 
    40e0:	48 85 c0             	test   %rax,%rax
    40e3:	74 33                	je     4118 <fwp_cancel_tree.part.0+0x68>
    40e5:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    40ec:	48 89 3d 2d c6 01 00 	mov    %rdi,0x1c62d(%rip)        # 20720 <fwp_ready_tail>
    40f3:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    40f7:	48 85 db             	test   %rbx,%rbx
    40fa:	74 17                	je     4113 <fwp_cancel_tree.part.0+0x63>
    40fc:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4100:	75 08                	jne    410a <fwp_cancel_tree.part.0+0x5a>
    4102:	48 89 df             	mov    %rbx,%rdi
    4105:	e8 a6 ff ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    410a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    410e:	48 85 db             	test   %rbx,%rbx
    4111:	75 e9                	jne    40fc <fwp_cancel_tree.part.0+0x4c>
    4113:	5b                   	pop    %rbx
    4114:	c3                   	ret
    4115:	0f 1f 00             	nopl   (%rax)
    4118:	48 89 3d 09 c6 01 00 	mov    %rdi,0x1c609(%rip)        # 20728 <fwp_ready_head>
    411f:	eb cb                	jmp    40ec <fwp_cancel_tree.part.0+0x3c>
    4121:	0f 1f 40 00          	nopl   0x0(%rax)
    4125:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    412c:	00 00 00 00 

0000000000004130 <fwp_finish_float>:
    4130:	53                   	push   %rbx
    4131:	be 2e 00 00 00       	mov    $0x2e,%esi
    4136:	48 89 fb             	mov    %rdi,%rbx
    4139:	e8 42 f3 ff ff       	call   3480 <strchr@plt>
    413e:	48 85 c0             	test   %rax,%rax
    4141:	74 05                	je     4148 <fwp_finish_float+0x18>
    4143:	5b                   	pop    %rbx
    4144:	c3                   	ret
    4145:	0f 1f 00             	nopl   (%rax)
    4148:	be 65 00 00 00       	mov    $0x65,%esi
    414d:	48 89 df             	mov    %rbx,%rdi
    4150:	e8 2b f3 ff ff       	call   3480 <strchr@plt>
    4155:	48 85 c0             	test   %rax,%rax
    4158:	75 e9                	jne    4143 <fwp_finish_float+0x13>
    415a:	48 8d 35 05 80 00 00 	lea    0x8005(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    4161:	48 89 df             	mov    %rbx,%rdi
    4164:	e8 67 f5 ff ff       	call   36d0 <strstr@plt>
    4169:	48 85 c0             	test   %rax,%rax
    416c:	75 d5                	jne    4143 <fwp_finish_float+0x13>
    416e:	48 8d 35 a7 7e 00 00 	lea    0x7ea7(%rip),%rsi        # c01c <_IO_stdin_used+0x1c>
    4175:	48 89 df             	mov    %rbx,%rdi
    4178:	e8 53 f5 ff ff       	call   36d0 <strstr@plt>
    417d:	48 85 c0             	test   %rax,%rax
    4180:	75 c1                	jne    4143 <fwp_finish_float+0x13>
    4182:	48 89 df             	mov    %rbx,%rdi
    4185:	e8 c6 f2 ff ff       	call   3450 <strlen@plt>
    418a:	ba 2e 30 00 00       	mov    $0x302e,%edx
    418f:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    4193:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    4198:	5b                   	pop    %rbx
    4199:	c3                   	ret
    419a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000041a0 <fwp_trap>:
    41a0:	55                   	push   %rbp
    41a1:	48 89 fd             	mov    %rdi,%rbp
    41a4:	53                   	push   %rbx
    41a5:	48 83 ec 08          	sub    $0x8,%rsp
    41a9:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    41b0:	ff ff 
    41b2:	e8 b9 fa ff ff       	call   3c70 <fwp_flush>
    41b7:	31 c0                	xor    %eax,%eax
    41b9:	48 89 e9             	mov    %rbp,%rcx
    41bc:	be 02 00 00 00       	mov    $0x2,%esi
    41c1:	48 8b 3d 78 be 00 00 	mov    0xbe78(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41c8:	48 8d 15 51 7e 00 00 	lea    0x7e51(%rip),%rdx        # c020 <_IO_stdin_used+0x20>
    41cf:	e8 bc f4 ff ff       	call   3690 <__fprintf_chk@plt>
    41d4:	48 85 db             	test   %rbx,%rbx
    41d7:	74 16                	je     41ef <fwp_trap+0x4f>
    41d9:	48 8b 3d 60 be 00 00 	mov    0xbe60(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    41e0:	e8 db f3 ff ff       	call   35c0 <fflush@plt>
    41e5:	bf 65 00 00 00       	mov    $0x65,%edi
    41ea:	e8 b1 f4 ff ff       	call   36a0 <_Exit@plt>
    41ef:	bf 65 00 00 00       	mov    $0x65,%edi
    41f4:	e8 77 f4 ff ff       	call   3670 <exit@plt>
    41f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004200 <fwp_closure_drop_push>:
    4200:	41 56                	push   %r14
    4202:	41 54                	push   %r12
    4204:	49 89 f4             	mov    %rsi,%r12
    4207:	55                   	push   %rbp
    4208:	48 89 fd             	mov    %rdi,%rbp
    420b:	53                   	push   %rbx
    420c:	48 83 ec 18          	sub    $0x18,%rsp
    4210:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    4214:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    4218:	74 26                	je     4240 <fwp_closure_drop_push+0x40>
    421a:	4c 8b 07             	mov    (%rdi),%r8
    421d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4224:	00 
    4225:	48 83 c3 01          	add    $0x1,%rbx
    4229:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    422d:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    4231:	48 83 c4 18          	add    $0x18,%rsp
    4235:	5b                   	pop    %rbx
    4236:	5d                   	pop    %rbp
    4237:	41 5c                	pop    %r12
    4239:	41 5e                	pop    %r14
    423b:	c3                   	ret
    423c:	0f 1f 40 00          	nopl   0x0(%rax)
    4240:	48 89 d8             	mov    %rbx,%rax
    4243:	48 c1 e8 3c          	shr    $0x3c,%rax
    4247:	0f 85 a9 00 00 00    	jne    42f6 <fwp_closure_drop_push+0xf6>
    424d:	48 89 d9             	mov    %rbx,%rcx
    4250:	48 c1 e1 04          	shl    $0x4,%rcx
    4254:	48 89 cf             	mov    %rcx,%rdi
    4257:	48 89 0c 24          	mov    %rcx,(%rsp)
    425b:	e8 50 f3 ff ff       	call   35b0 <malloc@plt>
    4260:	48 8b 0c 24          	mov    (%rsp),%rcx
    4264:	48 85 c0             	test   %rax,%rax
    4267:	74 5f                	je     42c8 <fwp_closure_drop_push+0xc8>
    4269:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    426d:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4274:	00 
    4275:	48 89 c7             	mov    %rax,%rdi
    4278:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    427c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4281:	48 89 34 24          	mov    %rsi,(%rsp)
    4285:	e8 e6 f2 ff ff       	call   3570 <__memcpy_chk@plt>
    428a:	48 8b 34 24          	mov    (%rsp),%rsi
    428e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4293:	49 89 c0             	mov    %rax,%r8
    4296:	48 8d 45 18          	lea    0x18(%rbp),%rax
    429a:	48 39 c6             	cmp    %rax,%rsi
    429d:	74 1c                	je     42bb <fwp_closure_drop_push+0xbb>
    429f:	48 89 f7             	mov    %rsi,%rdi
    42a2:	4c 89 04 24          	mov    %r8,(%rsp)
    42a6:	e8 15 f1 ff ff       	call   33c0 <free@plt>
    42ab:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    42af:	4c 8b 04 24          	mov    (%rsp),%r8
    42b3:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    42ba:	00 
    42bb:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    42bf:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    42c3:	e9 5d ff ff ff       	jmp    4225 <fwp_closure_drop_push+0x25>
    42c8:	48 8b 0d 71 bd 00 00 	mov    0xbd71(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    42cf:	ba 13 00 00 00       	mov    $0x13,%edx
    42d4:	be 01 00 00 00       	mov    $0x1,%esi
    42d9:	48 8d 3d 28 7d 00 00 	lea    0x7d28(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    42e0:	e8 9b f3 ff ff       	call   3680 <fwrite@plt>
    42e5:	31 ff                	xor    %edi,%edi
    42e7:	e8 d4 f2 ff ff       	call   35c0 <fflush@plt>
    42ec:	bf 66 00 00 00       	mov    $0x66,%edi
    42f1:	e8 aa f3 ff ff       	call   36a0 <_Exit@plt>
    42f6:	48 8d 3d 32 7d 00 00 	lea    0x7d32(%rip),%rdi        # c02f <_IO_stdin_used+0x2f>
    42fd:	e8 9e fe ff ff       	call   41a0 <fwp_trap>
    4302:	0f 1f 00             	nopl   (%rax)
    4305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    430c:	00 00 00 00 

0000000000004310 <fwp_now_ns>:
    4310:	53                   	push   %rbx
    4311:	bf 01 00 00 00       	mov    $0x1,%edi
    4316:	48 83 ec 20          	sub    $0x20,%rsp
    431a:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    4321:	00 00 
    4323:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    4328:	31 db                	xor    %ebx,%ebx
    432a:	48 89 e6             	mov    %rsp,%rsi
    432d:	e8 ee f0 ff ff       	call   3420 <clock_gettime@plt>
    4332:	85 c0                	test   %eax,%eax
    4334:	75 52                	jne    4388 <fwp_now_ns+0x78>
    4336:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    433b:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    4340:	48 f7 2c 24          	imulq  (%rsp)
    4344:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    434b:	48 89 f7             	mov    %rsi,%rdi
    434e:	48 c1 ff 3f          	sar    $0x3f,%rdi
    4352:	48 01 f0             	add    %rsi,%rax
    4355:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    435c:	00 00 80 
    435f:	48 11 fa             	adc    %rdi,%rdx
    4362:	31 ff                	xor    %edi,%edi
    4364:	48 01 c6             	add    %rax,%rsi
    4367:	48 11 d7             	adc    %rdx,%rdi
    436a:	48 39 f1             	cmp    %rsi,%rcx
    436d:	48 19 fb             	sbb    %rdi,%rbx
    4370:	72 27                	jb     4399 <fwp_now_ns+0x89>
    4372:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4377:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    437e:	00 00 
    4380:	75 12                	jne    4394 <fwp_now_ns+0x84>
    4382:	48 83 c4 20          	add    $0x20,%rsp
    4386:	5b                   	pop    %rbx
    4387:	c3                   	ret
    4388:	48 8d 3d ba 7c 00 00 	lea    0x7cba(%rip),%rdi        # c049 <_IO_stdin_used+0x49>
    438f:	e8 0c fe ff ff       	call   41a0 <fwp_trap>
    4394:	e8 c7 f0 ff ff       	call   3460 <__stack_chk_fail@plt>
    4399:	48 8d 3d 68 82 00 00 	lea    0x8268(%rip),%rdi        # c608 <_IO_stdin_used+0x608>
    43a0:	e8 fb fd ff ff       	call   41a0 <fwp_trap>
    43a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    43ac:	00 00 00 00 

00000000000043b0 <fwp_closure_drop.part.0>:
    43b0:	53                   	push   %rbx
    43b1:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    43b8:	66 0f 6f 05 e0 86 00 	movdqa 0x86e0(%rip),%xmm0        # caa0 <msg.4+0x20>
    43bf:	00 
    43c0:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    43c7:	00 00 
    43c9:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    43d0:	00 
    43d1:	48 89 fe             	mov    %rdi,%rsi
    43d4:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    43d9:	48 89 e7             	mov    %rsp,%rdi
    43dc:	48 89 1c 24          	mov    %rbx,(%rsp)
    43e0:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    43e5:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    43ec:	ff ff 
    43ee:	e8 0d fe ff ff       	call   4200 <fwp_closure_drop_push>
    43f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    43f8:	48 85 c0             	test   %rax,%rax
    43fb:	74 39                	je     4436 <fwp_closure_drop.part.0+0x86>
    43fd:	0f 1f 00             	nopl   (%rax)
    4400:	48 8b 14 24          	mov    (%rsp),%rdx
    4404:	48 83 e8 01          	sub    $0x1,%rax
    4408:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    440d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    4411:	8b 07                	mov    (%rdi),%eax
    4413:	48 c1 e0 05          	shl    $0x5,%rax
    4417:	48 03 05 9a df 01 00 	add    0x1df9a(%rip),%rax        # 223b8 <fwp_fns>
    441e:	48 8b 40 18          	mov    0x18(%rax),%rax
    4422:	48 85 c0             	test   %rax,%rax
    4425:	74 46                	je     446d <fwp_closure_drop.part.0+0xbd>
    4427:	31 f6                	xor    %esi,%esi
    4429:	ff 50 08             	call   *0x8(%rax)
    442c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4431:	48 85 c0             	test   %rax,%rax
    4434:	75 ca                	jne    4400 <fwp_closure_drop.part.0+0x50>
    4436:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    443d:	ff ff 00 00 00 00 
    4443:	48 8b 3c 24          	mov    (%rsp),%rdi
    4447:	48 39 df             	cmp    %rbx,%rdi
    444a:	74 05                	je     4451 <fwp_closure_drop.part.0+0xa1>
    444c:	e8 6f ef ff ff       	call   33c0 <free@plt>
    4451:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    4458:	00 
    4459:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4460:	00 00 
    4462:	75 15                	jne    4479 <fwp_closure_drop.part.0+0xc9>
    4464:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    446b:	5b                   	pop    %rbx
    446c:	c3                   	ret
    446d:	48 8d 3d c4 81 00 00 	lea    0x81c4(%rip),%rdi        # c638 <_IO_stdin_used+0x638>
    4474:	e8 27 fd ff ff       	call   41a0 <fwp_trap>
    4479:	e8 e2 ef ff ff       	call   3460 <__stack_chk_fail@plt>
    447e:	66 90                	xchg   %ax,%ax

0000000000004480 <fwp_tape_of>:
    4480:	0f b7 d7             	movzwl %di,%edx
    4483:	48 85 d2             	test   %rdx,%rdx
    4486:	74 28                	je     44b0 <fwp_tape_of+0x30>
    4488:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    448c:	48 39 05 55 bc 01 00 	cmp    %rax,0x1bc55(%rip)        # 200e8 <fwp_ntapes>
    4493:	7e 1b                	jle    44b0 <fwp_tape_of+0x30>
    4495:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4499:	48 03 05 50 bc 01 00 	add    0x1bc50(%rip),%rax        # 200f0 <fwp_tapes>
    44a0:	8b 50 04             	mov    0x4(%rax),%edx
    44a3:	85 d2                	test   %edx,%edx
    44a5:	74 09                	je     44b0 <fwp_tape_of+0x30>
    44a7:	48 c1 ff 10          	sar    $0x10,%rdi
    44ab:	39 38                	cmp    %edi,(%rax)
    44ad:	75 01                	jne    44b0 <fwp_tape_of+0x30>
    44af:	c3                   	ret
    44b0:	48 83 ec 08          	sub    $0x8,%rsp
    44b4:	48 8d 3d ad 81 00 00 	lea    0x81ad(%rip),%rdi        # c668 <_IO_stdin_used+0x668>
    44bb:	e8 e0 fc ff ff       	call   41a0 <fwp_trap>

00000000000044c0 <fwp_format_g.constprop.0>:
    44c0:	41 57                	push   %r15
    44c2:	b9 40 00 00 00       	mov    $0x40,%ecx
    44c7:	ba 02 00 00 00       	mov    $0x2,%edx
    44cc:	4c 8d 05 92 7b 00 00 	lea    0x7b92(%rip),%r8        # c065 <_IO_stdin_used+0x65>
    44d3:	41 56                	push   %r14
    44d5:	b8 01 00 00 00       	mov    $0x1,%eax
    44da:	41 55                	push   %r13
    44dc:	41 54                	push   %r12
    44de:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    44e2:	55                   	push   %rbp
    44e3:	45 89 e1             	mov    %r12d,%r9d
    44e6:	53                   	push   %rbx
    44e7:	48 89 fb             	mov    %rdi,%rbx
    44ea:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    44f1:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    44f8:	00 00 
    44fa:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4501:	00 
    4502:	41 89 f7             	mov    %esi,%r15d
    4505:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    450a:	be 40 00 00 00       	mov    $0x40,%esi
    450f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    4514:	4c 89 f7             	mov    %r14,%rdi
    4517:	e8 94 ee ff ff       	call   33b0 <__snprintf_chk@plt>
    451c:	be 65 00 00 00       	mov    $0x65,%esi
    4521:	4c 89 f7             	mov    %r14,%rdi
    4524:	e8 57 ef ff ff       	call   3480 <strchr@plt>
    4529:	31 f6                	xor    %esi,%esi
    452b:	ba 0a 00 00 00       	mov    $0xa,%edx
    4530:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4534:	48 89 c5             	mov    %rax,%rbp
    4537:	e8 54 f0 ff ff       	call   3590 <strtol@plt>
    453c:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    4541:	49 89 c0             	mov    %rax,%r8
    4544:	83 c0 05             	add    $0x5,%eax
    4547:	83 f8 15             	cmp    $0x15,%eax
    454a:	0f 87 f0 01 00 00    	ja     4740 <fwp_format_g.constprop.0+0x280>
    4550:	45 89 e5             	mov    %r12d,%r13d
    4553:	45 29 c5             	sub    %r8d,%r13d
    4556:	45 85 ed             	test   %r13d,%r13d
    4559:	0f 8e 21 01 00 00    	jle    4680 <fwp_format_g.constprop.0+0x1c0>
    455f:	41 83 ff 01          	cmp    $0x1,%r15d
    4563:	0f 84 17 01 00 00    	je     4680 <fwp_format_g.constprop.0+0x1c0>
    4569:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    456e:	31 d2                	xor    %edx,%edx
    4570:	4d 63 df             	movslq %r15d,%r11
    4573:	3c 2d                	cmp    $0x2d,%al
    4575:	0f 94 c2             	sete   %dl
    4578:	4c 29 dd             	sub    %r11,%rbp
    457b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    457f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4583:	4d 89 f1             	mov    %r14,%r9
    4586:	4d 29 d1             	sub    %r10,%r9
    4589:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    458d:	3c 2d                	cmp    $0x2d,%al
    458f:	0f 84 0b 04 00 00    	je     49a0 <fwp_format_g.constprop.0+0x4e0>
    4595:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    459a:	b9 48 00 00 00       	mov    $0x48,%ecx
    459f:	48 89 e8             	mov    %rbp,%rax
    45a2:	48 8d 78 01          	lea    0x1(%rax),%rdi
    45a6:	49 8d 72 01          	lea    0x1(%r10),%rsi
    45aa:	49 83 c1 47          	add    $0x47,%r9
    45ae:	45 85 c0             	test   %r8d,%r8d
    45b1:	0f 88 01 03 00 00    	js     48b8 <fwp_format_g.constprop.0+0x3f8>
    45b7:	45 0f b6 12          	movzbl (%r10),%r10d
    45bb:	4d 63 e0             	movslq %r8d,%r12
    45be:	44 88 10             	mov    %r10b,(%rax)
    45c1:	41 83 f8 07          	cmp    $0x7,%r8d
    45c5:	0f 87 3d 02 00 00    	ja     4808 <fwp_format_g.constprop.0+0x348>
    45cb:	41 f6 c4 04          	test   $0x4,%r12b
    45cf:	0f 85 02 04 00 00    	jne    49d7 <fwp_format_g.constprop.0+0x517>
    45d5:	45 85 e4             	test   %r12d,%r12d
    45d8:	74 12                	je     45ec <fwp_format_g.constprop.0+0x12c>
    45da:	45 0f b6 06          	movzbl (%r14),%r8d
    45de:	44 88 40 01          	mov    %r8b,0x1(%rax)
    45e2:	41 f6 c4 02          	test   $0x2,%r12b
    45e6:	0f 85 13 04 00 00    	jne    49ff <fwp_format_g.constprop.0+0x53f>
    45ec:	4c 29 e1             	sub    %r12,%rcx
    45ef:	4c 01 e7             	add    %r12,%rdi
    45f2:	4c 89 fa             	mov    %r15,%rdx
    45f5:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    45fa:	48 83 e9 01          	sub    $0x1,%rcx
    45fe:	4d 63 ed             	movslq %r13d,%r13
    4601:	48 89 0c 24          	mov    %rcx,(%rsp)
    4605:	e8 66 ef ff ff       	call   3570 <__memcpy_chk@plt>
    460a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    460f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4613:	ba 48 00 00 00       	mov    $0x48,%edx
    4618:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    461c:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    4620:	4c 89 c8             	mov    %r9,%rax
    4623:	48 29 c8             	sub    %rcx,%rax
    4626:	48 39 d0             	cmp    %rdx,%rax
    4629:	48 0f 42 c2          	cmovb  %rdx,%rax
    462d:	4c 29 c9             	sub    %r9,%rcx
    4630:	4c 89 ea             	mov    %r13,%rdx
    4633:	48 01 c1             	add    %rax,%rcx
    4636:	e8 35 ef ff ff       	call   3570 <__memcpy_chk@plt>
    463b:	4c 01 e8             	add    %r13,%rax
    463e:	48 29 e8             	sub    %rbp,%rax
    4641:	ba 8f 01 00 00       	mov    $0x18f,%edx
    4646:	48 39 d0             	cmp    %rdx,%rax
    4649:	48 0f 47 c2          	cmova  %rdx,%rax
    464d:	89 c1                	mov    %eax,%ecx
    464f:	83 f8 08             	cmp    $0x8,%eax
    4652:	0f 83 28 02 00 00    	jae    4880 <fwp_format_g.constprop.0+0x3c0>
    4658:	a8 04                	test   $0x4,%al
    465a:	0f 85 64 03 00 00    	jne    49c4 <fwp_format_g.constprop.0+0x504>
    4660:	85 c0                	test   %eax,%eax
    4662:	74 0f                	je     4673 <fwp_format_g.constprop.0+0x1b3>
    4664:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    4669:	88 13                	mov    %dl,(%rbx)
    466b:	a8 02                	test   $0x2,%al
    466d:	0f 85 7b 03 00 00    	jne    49ee <fwp_format_g.constprop.0+0x52e>
    4673:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4677:	eb 36                	jmp    46af <fwp_format_g.constprop.0+0x1ef>
    4679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4680:	45 31 c9             	xor    %r9d,%r9d
    4683:	45 85 ed             	test   %r13d,%r13d
    4686:	4c 8d 05 e7 79 00 00 	lea    0x79e7(%rip),%r8        # c074 <_IO_stdin_used+0x74>
    468d:	48 89 df             	mov    %rbx,%rdi
    4690:	45 0f 49 cd          	cmovns %r13d,%r9d
    4694:	ba 02 00 00 00       	mov    $0x2,%edx
    4699:	be 90 01 00 00       	mov    $0x190,%esi
    469e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    46a5:	b8 01 00 00 00       	mov    $0x1,%eax
    46aa:	e8 01 ed ff ff       	call   33b0 <__snprintf_chk@plt>
    46af:	be 2e 00 00 00       	mov    $0x2e,%esi
    46b4:	48 89 df             	mov    %rbx,%rdi
    46b7:	e8 c4 ed ff ff       	call   3480 <strchr@plt>
    46bc:	48 85 c0             	test   %rax,%rax
    46bf:	74 4f                	je     4710 <fwp_format_g.constprop.0+0x250>
    46c1:	48 89 df             	mov    %rbx,%rdi
    46c4:	e8 87 ed ff ff       	call   3450 <strlen@plt>
    46c9:	48 85 c0             	test   %rax,%rax
    46cc:	75 1b                	jne    46e9 <fwp_format_g.constprop.0+0x229>
    46ce:	eb 40                	jmp    4710 <fwp_format_g.constprop.0+0x250>
    46d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    46d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    46dc:	00 00 00 00 
    46e0:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    46e4:	48 85 c0             	test   %rax,%rax
    46e7:	74 27                	je     4710 <fwp_format_g.constprop.0+0x250>
    46e9:	48 89 c2             	mov    %rax,%rdx
    46ec:	48 83 e8 01          	sub    $0x1,%rax
    46f0:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    46f4:	74 ea                	je     46e0 <fwp_format_g.constprop.0+0x220>
    46f6:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    46fb:	0f 84 6f 01 00 00    	je     4870 <fwp_format_g.constprop.0+0x3b0>
    4701:	0f 1f 40 00          	nopl   0x0(%rax)
    4705:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    470c:	00 00 00 00 
    4710:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4717:	00 
    4718:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    471f:	00 00 
    4721:	0f 85 ec 02 00 00    	jne    4a13 <fwp_format_g.constprop.0+0x553>
    4727:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    472e:	5b                   	pop    %rbx
    472f:	5d                   	pop    %rbp
    4730:	41 5c                	pop    %r12
    4732:	41 5d                	pop    %r13
    4734:	41 5e                	pop    %r14
    4736:	41 5f                	pop    %r15
    4738:	c3                   	ret
    4739:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4740:	4c 29 f5             	sub    %r14,%rbp
    4743:	b9 40 00 00 00       	mov    $0x40,%ecx
    4748:	4c 89 f6             	mov    %r14,%rsi
    474b:	4c 89 04 24          	mov    %r8,(%rsp)
    474f:	49 89 ec             	mov    %rbp,%r12
    4752:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4757:	4c 89 e2             	mov    %r12,%rdx
    475a:	48 89 ef             	mov    %rbp,%rdi
    475d:	e8 0e ee ff ff       	call   3570 <__memcpy_chk@plt>
    4762:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    4768:	be 2e 00 00 00       	mov    $0x2e,%esi
    476d:	48 89 ef             	mov    %rbp,%rdi
    4770:	e8 0b ed ff ff       	call   3480 <strchr@plt>
    4775:	4c 8b 04 24          	mov    (%rsp),%r8
    4779:	48 85 c0             	test   %rax,%rax
    477c:	74 40                	je     47be <fwp_format_g.constprop.0+0x2fe>
    477e:	4d 85 e4             	test   %r12,%r12
    4781:	74 3b                	je     47be <fwp_format_g.constprop.0+0x2fe>
    4783:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4788:	eb 23                	jmp    47ad <fwp_format_g.constprop.0+0x2ed>
    478a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4791:	00 00 00 00 
    4795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    479c:	00 00 00 00 
    47a0:	c6 00 00             	movb   $0x0,(%rax)
    47a3:	48 83 e8 01          	sub    $0x1,%rax
    47a7:	49 83 ec 01          	sub    $0x1,%r12
    47ab:	74 11                	je     47be <fwp_format_g.constprop.0+0x2fe>
    47ad:	80 38 30             	cmpb   $0x30,(%rax)
    47b0:	74 ee                	je     47a0 <fwp_format_g.constprop.0+0x2e0>
    47b2:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    47b8:	0f 84 fb 01 00 00    	je     49b9 <fwp_format_g.constprop.0+0x4f9>
    47be:	44 89 c0             	mov    %r8d,%eax
    47c1:	ba 02 00 00 00       	mov    $0x2,%edx
    47c6:	49 89 e9             	mov    %rbp,%r9
    47c9:	be 90 01 00 00       	mov    $0x190,%esi
    47ce:	f7 d8                	neg    %eax
    47d0:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    47d7:	48 89 df             	mov    %rbx,%rdi
    47da:	41 0f 48 c0          	cmovs  %r8d,%eax
    47de:	41 c1 f8 1f          	sar    $0x1f,%r8d
    47e2:	41 83 e0 02          	and    $0x2,%r8d
    47e6:	41 83 c0 2b          	add    $0x2b,%r8d
    47ea:	50                   	push   %rax
    47eb:	31 c0                	xor    %eax,%eax
    47ed:	41 50                	push   %r8
    47ef:	4c 8d 05 74 78 00 00 	lea    0x7874(%rip),%r8        # c06a <_IO_stdin_used+0x6a>
    47f6:	e8 b5 eb ff ff       	call   33b0 <__snprintf_chk@plt>
    47fb:	58                   	pop    %rax
    47fc:	5a                   	pop    %rdx
    47fd:	e9 0e ff ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    4802:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4808:	4d 8b 06             	mov    (%r14),%r8
    480b:	48 83 c0 09          	add    $0x9,%rax
    480f:	4c 89 f2             	mov    %r14,%rdx
    4812:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4816:	4c 89 07             	mov    %r8,(%rdi)
    4819:	45 89 e0             	mov    %r12d,%r8d
    481c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4821:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4826:	49 89 f8             	mov    %rdi,%r8
    4829:	49 29 c0             	sub    %rax,%r8
    482c:	4c 29 c2             	sub    %r8,%rdx
    482f:	45 01 e0             	add    %r12d,%r8d
    4832:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4836:	41 83 f8 08          	cmp    $0x8,%r8d
    483a:	0f 82 ac fd ff ff    	jb     45ec <fwp_format_g.constprop.0+0x12c>
    4840:	48 89 0c 24          	mov    %rcx,(%rsp)
    4844:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4848:	45 31 d2             	xor    %r10d,%r10d
    484b:	45 89 d3             	mov    %r10d,%r11d
    484e:	41 83 c2 08          	add    $0x8,%r10d
    4852:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4856:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    485a:	45 39 c2             	cmp    %r8d,%r10d
    485d:	72 ec                	jb     484b <fwp_format_g.constprop.0+0x38b>
    485f:	48 8b 0c 24          	mov    (%rsp),%rcx
    4863:	e9 84 fd ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4868:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    486f:	00 
    4870:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4875:	e9 96 fe ff ff       	jmp    4710 <fwp_format_g.constprop.0+0x250>
    487a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4880:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4885:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4889:	48 89 ee             	mov    %rbp,%rsi
    488c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4890:	48 89 13             	mov    %rdx,(%rbx)
    4893:	89 c2                	mov    %eax,%edx
    4895:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    489a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    489f:	48 89 d9             	mov    %rbx,%rcx
    48a2:	48 29 f9             	sub    %rdi,%rcx
    48a5:	48 29 ce             	sub    %rcx,%rsi
    48a8:	01 c1                	add    %eax,%ecx
    48aa:	c1 e9 03             	shr    $0x3,%ecx
    48ad:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    48b0:	e9 be fd ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    48b5:	0f 1f 00             	nopl   (%rax)
    48b8:	c6 00 30             	movb   $0x30,(%rax)
    48bb:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    48bf:	4c 89 fa             	mov    %r15,%rdx
    48c2:	4c 89 e9             	mov    %r13,%rcx
    48c5:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    48ca:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    48cf:	4c 89 14 24          	mov    %r10,(%rsp)
    48d3:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    48d8:	e8 93 ec ff ff       	call   3570 <__memcpy_chk@plt>
    48dd:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    48e2:	b9 48 00 00 00       	mov    $0x48,%ecx
    48e7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    48ec:	48 89 c7             	mov    %rax,%rdi
    48ef:	4c 8b 14 24          	mov    (%rsp),%r10
    48f3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    48f8:	4c 89 c8             	mov    %r9,%rax
    48fb:	4c 29 e8             	sub    %r13,%rax
    48fe:	48 39 c8             	cmp    %rcx,%rax
    4901:	48 0f 42 c1          	cmovb  %rcx,%rax
    4905:	4d 29 cd             	sub    %r9,%r13
    4908:	49 01 ff             	add    %rdi,%r15
    490b:	4c 01 e8             	add    %r13,%rax
    490e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4912:	74 3d                	je     4951 <fwp_format_g.constprop.0+0x491>
    4914:	41 f7 d0             	not    %r8d
    4917:	31 f6                	xor    %esi,%esi
    4919:	ba 48 00 00 00       	mov    $0x48,%edx
    491e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4923:	48 39 d0             	cmp    %rdx,%rax
    4926:	48 0f 43 d0          	cmovae %rax,%rdx
    492a:	48 89 d1             	mov    %rdx,%rcx
    492d:	48 29 c1             	sub    %rax,%rcx
    4930:	48 83 c1 01          	add    $0x1,%rcx
    4934:	48 39 d1             	cmp    %rdx,%rcx
    4937:	48 0f 42 ca          	cmovb  %rdx,%rcx
    493b:	48 83 e8 01          	sub    $0x1,%rax
    493f:	48 83 c6 01          	add    $0x1,%rsi
    4943:	48 29 d0             	sub    %rdx,%rax
    4946:	48 01 c8             	add    %rcx,%rax
    4949:	41 39 f0             	cmp    %esi,%r8d
    494c:	7f cb                	jg     4919 <fwp_format_g.constprop.0+0x459>
    494e:	4d 01 c7             	add    %r8,%r15
    4951:	b9 48 00 00 00       	mov    $0x48,%ecx
    4956:	41 0f b6 12          	movzbl (%r10),%edx
    495a:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    495e:	4c 89 f6             	mov    %r14,%rsi
    4961:	48 39 c8             	cmp    %rcx,%rax
    4964:	4c 89 1c 24          	mov    %r11,(%rsp)
    4968:	48 0f 43 c8          	cmovae %rax,%rcx
    496c:	41 88 17             	mov    %dl,(%r15)
    496f:	48 89 ca             	mov    %rcx,%rdx
    4972:	48 29 c2             	sub    %rax,%rdx
    4975:	48 83 c2 01          	add    $0x1,%rdx
    4979:	48 39 ca             	cmp    %rcx,%rdx
    497c:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4980:	48 83 e8 01          	sub    $0x1,%rax
    4984:	48 29 c8             	sub    %rcx,%rax
    4987:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    498b:	49 63 d4             	movslq %r12d,%rdx
    498e:	e8 dd eb ff ff       	call   3570 <__memcpy_chk@plt>
    4993:	4c 8b 1c 24          	mov    (%rsp),%r11
    4997:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    499b:	e9 9e fc ff ff       	jmp    463e <fwp_format_g.constprop.0+0x17e>
    49a0:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    49a5:	b9 47 00 00 00       	mov    $0x47,%ecx
    49aa:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    49af:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49b4:	e9 e9 fb ff ff       	jmp    45a2 <fwp_format_g.constprop.0+0xe2>
    49b9:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    49bf:	e9 fa fd ff ff       	jmp    47be <fwp_format_g.constprop.0+0x2fe>
    49c4:	8b 54 24 60          	mov    0x60(%rsp),%edx
    49c8:	89 13                	mov    %edx,(%rbx)
    49ca:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    49ce:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    49d2:	e9 9c fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49d7:	41 8b 06             	mov    (%r14),%eax
    49da:	89 07                	mov    %eax,(%rdi)
    49dc:	44 89 e0             	mov    %r12d,%eax
    49df:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    49e4:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    49e9:	e9 fe fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    49ee:	89 c2                	mov    %eax,%edx
    49f0:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    49f5:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    49fa:	e9 74 fc ff ff       	jmp    4673 <fwp_format_g.constprop.0+0x1b3>
    49ff:	44 89 e0             	mov    %r12d,%eax
    4a02:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4a08:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4a0e:	e9 d9 fb ff ff       	jmp    45ec <fwp_format_g.constprop.0+0x12c>
    4a13:	e8 48 ea ff ff       	call   3460 <__stack_chk_fail@plt>
    4a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4a1f:	00 

0000000000004a20 <fwp_heap_report>:
    4a20:	f3 0f 1e fa          	endbr64
    4a24:	41 54                	push   %r12
    4a26:	48 8d 3d 4c 76 00 00 	lea    0x764c(%rip),%rdi        # c079 <_IO_stdin_used+0x79>
    4a2d:	55                   	push   %rbp
    4a2e:	53                   	push   %rbx
    4a2f:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4a36:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4a3d:	00 00 
    4a3f:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4a46:	00 
    4a47:	48 8d 35 60 77 00 00 	lea    0x7760(%rip),%rsi        # c1ae <_IO_stdin_used+0x1ae>
    4a4e:	e8 dd eb ff ff       	call   3630 <fopen@plt>
    4a53:	48 85 c0             	test   %rax,%rax
    4a56:	0f 84 c5 00 00 00    	je     4b21 <fwp_heap_report+0x101>
    4a5c:	48 89 c5             	mov    %rax,%rbp
    4a5f:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4a66:	48 89 e3             	mov    %rsp,%rbx
    4a69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4a70:	48 89 ea             	mov    %rbp,%rdx
    4a73:	be 00 01 00 00       	mov    $0x100,%esi
    4a78:	48 89 df             	mov    %rbx,%rdi
    4a7b:	e8 80 ea ff ff       	call   3500 <fgets@plt>
    4a80:	48 85 c0             	test   %rax,%rax
    4a83:	74 2b                	je     4ab0 <fwp_heap_report+0x90>
    4a85:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4a8b:	75 e3                	jne    4a70 <fwp_heap_report+0x50>
    4a8d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4a91:	75 dd                	jne    4a70 <fwp_heap_report+0x50>
    4a93:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4a98:	75 d6                	jne    4a70 <fwp_heap_report+0x50>
    4a9a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4a9f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4aa4:	31 f6                	xor    %esi,%esi
    4aa6:	e8 e5 ea ff ff       	call   3590 <strtol@plt>
    4aab:	49 89 c4             	mov    %rax,%r12
    4aae:	eb c0                	jmp    4a70 <fwp_heap_report+0x50>
    4ab0:	48 89 ef             	mov    %rbp,%rdi
    4ab3:	e8 88 e9 ff ff       	call   3440 <fclose@plt>
    4ab8:	48 83 ec 08          	sub    $0x8,%rsp
    4abc:	4c 8b 0d 65 d0 01 00 	mov    0x1d065(%rip),%r9        # 21b28 <fwp_heap+0x13c8>
    4ac3:	4c 8b 05 be d0 01 00 	mov    0x1d0be(%rip),%r8        # 21b88 <fwp_heap+0x1428>
    4aca:	48 8d 15 e7 7b 00 00 	lea    0x7be7(%rip),%rdx        # c6b8 <_IO_stdin_used+0x6b8>
    4ad1:	41 54                	push   %r12
    4ad3:	48 8b 0d a6 d0 01 00 	mov    0x1d0a6(%rip),%rcx        # 21b80 <fwp_heap+0x1420>
    4ada:	be 02 00 00 00       	mov    $0x2,%esi
    4adf:	b8 02 00 00 00       	mov    $0x2,%eax
    4ae4:	f2 0f 10 0d b4 d0 01 	movsd  0x1d0b4(%rip),%xmm1        # 21ba0 <fwp_heap+0x1440>
    4aeb:	00 
    4aec:	f2 0f 10 05 a4 d0 01 	movsd  0x1d0a4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    4af3:	00 
    4af4:	48 8b 3d 45 b5 00 00 	mov    0xb545(%rip),%rdi        # 10040 <stderr@GLIBC_2.2.5>
    4afb:	e8 90 eb ff ff       	call   3690 <__fprintf_chk@plt>
    4b00:	58                   	pop    %rax
    4b01:	5a                   	pop    %rdx
    4b02:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4b09:	00 
    4b0a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4b11:	00 00 
    4b13:	75 15                	jne    4b2a <fwp_heap_report+0x10a>
    4b15:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4b1c:	5b                   	pop    %rbx
    4b1d:	5d                   	pop    %rbp
    4b1e:	41 5c                	pop    %r12
    4b20:	c3                   	ret
    4b21:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4b28:	eb 8e                	jmp    4ab8 <fwp_heap_report+0x98>
    4b2a:	e8 31 e9 ff ff       	call   3460 <__stack_chk_fail@plt>
    4b2f:	90                   	nop

0000000000004b30 <fwp_heap_init>:
    4b30:	66 0f 6f 05 78 7f 00 	movdqa 0x7f78(%rip),%xmm0        # cab0 <msg.4+0x30>
    4b37:	00 
    4b38:	41 54                	push   %r12
    4b3a:	48 8d 05 5f cb 01 00 	lea    0x1cb5f(%rip),%rax        # 216a0 <fwp_heap+0xf40>
    4b41:	ba 00 01 00 00       	mov    $0x100,%edx
    4b46:	55                   	push   %rbp
    4b47:	66 0f 6f 15 a1 7f 00 	movdqa 0x7fa1(%rip),%xmm2        # caf0 <msg.4+0x70>
    4b4e:	00 
    4b4f:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4b53:	53                   	push   %rbx
    4b54:	0f 29 05 05 cb 01 00 	movaps %xmm0,0x1cb05(%rip)        # 21660 <fwp_heap+0xf00>
    4b5b:	66 0f 6f 05 5d 7f 00 	movdqa 0x7f5d(%rip),%xmm0        # cac0 <msg.4+0x40>
    4b62:	00 
    4b63:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4b67:	c7 05 93 cf 01 00 01 	movl   $0x1,0x1cf93(%rip)        # 21b04 <fwp_heap+0x13a4>
    4b6e:	00 00 00 
    4b71:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4b76:	0f 29 05 f3 ca 01 00 	movaps %xmm0,0x1caf3(%rip)        # 21670 <fwp_heap+0xf10>
    4b7d:	66 0f 6f 05 4b 7f 00 	movdqa 0x7f4b(%rip),%xmm0        # cad0 <msg.4+0x50>
    4b84:	00 
    4b85:	0f 29 05 f4 ca 01 00 	movaps %xmm0,0x1caf4(%rip)        # 21680 <fwp_heap+0xf20>
    4b8c:	66 0f 6f 05 4c 7f 00 	movdqa 0x7f4c(%rip),%xmm0        # cae0 <msg.4+0x60>
    4b93:	00 
    4b94:	0f 29 05 f5 ca 01 00 	movaps %xmm0,0x1caf5(%rip)        # 21690 <fwp_heap+0xf30>
    4b9b:	89 d3                	mov    %edx,%ebx
    4b9d:	66 0f 6e e2          	movd   %edx,%xmm4
    4ba1:	48 83 c0 10          	add    $0x10,%rax
    4ba5:	01 d2                	add    %edx,%edx
    4ba7:	c1 eb 02             	shr    $0x2,%ebx
    4baa:	66 0f 6e c3          	movd   %ebx,%xmm0
    4bae:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4bb3:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4bb7:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4bbc:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4bc0:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4bc4:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4bc9:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4bce:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4bd2:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4bd7:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4bdb:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4bdf:	48 39 c7             	cmp    %rax,%rdi
    4be2:	75 b7                	jne    4b9b <fwp_heap_init+0x6b>
    4be4:	4c 8d 05 75 bb 01 00 	lea    0x1bb75(%rip),%r8        # 20760 <fwp_heap>
    4beb:	31 c9                	xor    %ecx,%ecx
    4bed:	31 c0                	xor    %eax,%eax
    4bef:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4bf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4bfd:	00 00 00 
    4c00:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4c07:	00 
    4c08:	48 39 ca             	cmp    %rcx,%rdx
    4c0b:	73 0f                	jae    4c1c <fwp_heap_init+0xec>
    4c0d:	0f 1f 00             	nopl   (%rax)
    4c10:	48 83 c0 01          	add    $0x1,%rax
    4c14:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4c17:	48 39 ca             	cmp    %rcx,%rdx
    4c1a:	72 f4                	jb     4c10 <fwp_heap_init+0xe0>
    4c1c:	48 83 c1 10          	add    $0x10,%rcx
    4c20:	88 07                	mov    %al,(%rdi)
    4c22:	48 83 c7 01          	add    $0x1,%rdi
    4c26:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4c2d:	75 d1                	jne    4c00 <fwp_heap_init+0xd0>
    4c2f:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4c36:	00 00 00 
    4c39:	bd 05 00 00 00       	mov    $0x5,%ebp
    4c3e:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4c45:	45 31 c9             	xor    %r9d,%r9d
    4c48:	31 d2                	xor    %edx,%edx
    4c4a:	31 ff                	xor    %edi,%edi
    4c4c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c52:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4c57:	4c 89 e6             	mov    %r12,%rsi
    4c5a:	e8 11 e8 ff ff       	call   3470 <mmap@plt>
    4c5f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4c63:	75 13                	jne    4c78 <fwp_heap_init+0x148>
    4c65:	48 c1 eb 02          	shr    $0x2,%rbx
    4c69:	83 ed 01             	sub    $0x1,%ebp
    4c6c:	75 d0                	jne    4c3e <fwp_heap_init+0x10e>
    4c6e:	e8 3d f0 ff ff       	call   3cb0 <fwp_heap_oom>
    4c73:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4c78:	48 85 c0             	test   %rax,%rax
    4c7b:	74 f1                	je     4c6e <fwp_heap_init+0x13e>
    4c7d:	48 c1 eb 10          	shr    $0x10,%rbx
    4c81:	48 89 05 90 ce 01 00 	mov    %rax,0x1ce90(%rip)        # 21b18 <fwp_heap+0x13b8>
    4c88:	45 31 c9             	xor    %r9d,%r9d
    4c8b:	31 d2                	xor    %edx,%edx
    4c8d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4c93:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4c97:	31 ff                	xor    %edi,%edi
    4c99:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4c9f:	66 31 c0             	xor    %ax,%ax
    4ca2:	48 c1 e6 03          	shl    $0x3,%rsi
    4ca6:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4cab:	4c 89 25 6e ce 01 00 	mov    %r12,0x1ce6e(%rip)        # 21b20 <fwp_heap+0x13c0>
    4cb2:	48 89 05 57 ce 01 00 	mov    %rax,0x1ce57(%rip)        # 21b10 <fwp_heap+0x13b0>
    4cb9:	48 89 1d 70 ce 01 00 	mov    %rbx,0x1ce70(%rip)        # 21b30 <fwp_heap+0x13d0>
    4cc0:	48 89 35 99 ce 01 00 	mov    %rsi,0x1ce99(%rip)        # 21b60 <fwp_heap+0x1400>
    4cc7:	e8 a4 e7 ff ff       	call   3470 <mmap@plt>
    4ccc:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4cd0:	74 9c                	je     4c6e <fwp_heap_init+0x13e>
    4cd2:	48 8d 3d d6 73 00 00 	lea    0x73d6(%rip),%rdi        # c0af <_IO_stdin_used+0xaf>
    4cd9:	48 89 05 78 ce 01 00 	mov    %rax,0x1ce78(%rip)        # 21b58 <fwp_heap+0x13f8>
    4ce0:	e8 bb e6 ff ff       	call   33a0 <getenv@plt>
    4ce5:	48 89 c2             	mov    %rax,%rdx
    4ce8:	31 c0                	xor    %eax,%eax
    4cea:	48 85 d2             	test   %rdx,%rdx
    4ced:	74 15                	je     4d04 <fwp_heap_init+0x1d4>
    4cef:	80 3a 00             	cmpb   $0x0,(%rdx)
    4cf2:	74 10                	je     4d04 <fwp_heap_init+0x1d4>
    4cf4:	0f b6 02             	movzbl (%rdx),%eax
    4cf7:	83 e8 30             	sub    $0x30,%eax
    4cfa:	74 13                	je     4d0f <fwp_heap_init+0x1df>
    4cfc:	85 c0                	test   %eax,%eax
    4cfe:	0f 95 c0             	setne  %al
    4d01:	0f b6 c0             	movzbl %al,%eax
    4d04:	5b                   	pop    %rbx
    4d05:	5d                   	pop    %rbp
    4d06:	89 05 fc cd 01 00    	mov    %eax,0x1cdfc(%rip)        # 21b08 <fwp_heap+0x13a8>
    4d0c:	41 5c                	pop    %r12
    4d0e:	c3                   	ret
    4d0f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4d13:	85 c0                	test   %eax,%eax
    4d15:	0f 95 c0             	setne  %al
    4d18:	0f b6 c0             	movzbl %al,%eax
    4d1b:	eb e7                	jmp    4d04 <fwp_heap_init+0x1d4>
    4d1d:	0f 1f 00             	nopl   (%rax)

0000000000004d20 <fwp_wake_io>:
    4d20:	48 8b 07             	mov    (%rdi),%rax
    4d23:	48 85 c0             	test   %rax,%rax
    4d26:	0f 84 f4 00 00 00    	je     4e20 <fwp_wake_io+0x100>
    4d2c:	53                   	push   %rbx
    4d2d:	4c 8b 05 ec b9 01 00 	mov    0x1b9ec(%rip),%r8        # 20720 <fwp_ready_tail>
    4d34:	49 89 f9             	mov    %rdi,%r9
    4d37:	48 89 c2             	mov    %rax,%rdx
    4d3a:	45 31 db             	xor    %r11d,%r11d
    4d3d:	45 31 d2             	xor    %r10d,%r10d
    4d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4d44:	eb 71                	jmp    4db7 <fwp_wake_io+0x97>
    4d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4d4d:	00 00 00 
    4d50:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4d57:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4d5e:	48 85 c9             	test   %rcx,%rcx
    4d61:	74 07                	je     4d6a <fwp_wake_io+0x4a>
    4d63:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4d6a:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4d71:	00 00 00 00 
    4d75:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4d7c:	49 8b 01             	mov    (%r9),%rax
    4d7f:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    4d83:	75 2a                	jne    4daf <fwp_wake_io+0x8f>
    4d85:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    4d89:	75 24                	jne    4daf <fwp_wake_io+0x8f>
    4d8b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    4d8f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    4d96:	00 00 00 00 
    4d9a:	4d 85 c0             	test   %r8,%r8
    4d9d:	74 51                	je     4df0 <fwp_wake_io+0xd0>
    4d9f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    4da6:	49 89 d0             	mov    %rdx,%r8
    4da9:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    4daf:	48 89 c2             	mov    %rax,%rdx
    4db2:	48 85 c0             	test   %rax,%rax
    4db5:	74 49                	je     4e00 <fwp_wake_io+0xe0>
    4db7:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    4dbe:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    4dc2:	48 85 ff             	test   %rdi,%rdi
    4dc5:	74 b8                	je     4d7f <fwp_wake_io+0x5f>
    4dc7:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    4dce:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4dd5:	48 85 f6             	test   %rsi,%rsi
    4dd8:	0f 85 72 ff ff ff    	jne    4d50 <fwp_wake_io+0x30>
    4dde:	48 89 0f             	mov    %rcx,(%rdi)
    4de1:	e9 78 ff ff ff       	jmp    4d5e <fwp_wake_io+0x3e>
    4de6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4ded:	00 00 00 
    4df0:	48 89 d3             	mov    %rdx,%rbx
    4df3:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    4df9:	eb ab                	jmp    4da6 <fwp_wake_io+0x86>
    4dfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4e00:	45 84 db             	test   %r11b,%r11b
    4e03:	74 07                	je     4e0c <fwp_wake_io+0xec>
    4e05:	48 89 1d 1c b9 01 00 	mov    %rbx,0x1b91c(%rip)        # 20728 <fwp_ready_head>
    4e0c:	45 84 d2             	test   %r10b,%r10b
    4e0f:	74 07                	je     4e18 <fwp_wake_io+0xf8>
    4e11:	4c 89 05 08 b9 01 00 	mov    %r8,0x1b908(%rip)        # 20720 <fwp_ready_tail>
    4e18:	5b                   	pop    %rbx
    4e19:	c3                   	ret
    4e1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4e20:	c3                   	ret
    4e21:	0f 1f 40 00          	nopl   0x0(%rax)
    4e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4e2c:	00 00 00 00 

0000000000004e30 <fwp_tape_buffers_release>:
    4e30:	f3 0f 1e fa          	endbr64
    4e34:	53                   	push   %rbx
    4e35:	48 89 fb             	mov    %rdi,%rbx
    4e38:	48 83 ec 10          	sub    $0x10,%rsp
    4e3c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    4e40:	48 85 c0             	test   %rax,%rax
    4e43:	0f 88 df 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e49:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    4e4d:	48 85 d2             	test   %rdx,%rdx
    4e50:	0f 88 d2 00 00 00    	js     4f28 <fwp_tape_buffers_release+0xf8>
    4e56:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    4e5c:	0f 87 c6 00 00 00    	ja     4f28 <fwp_tape_buffers_release+0xf8>
    4e62:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    4e66:	b8 00 00 08 00       	mov    $0x80000,%eax
    4e6b:	48 c1 e1 03          	shl    $0x3,%rcx
    4e6f:	48 29 c8             	sub    %rcx,%rax
    4e72:	48 c1 e8 03          	shr    $0x3,%rax
    4e76:	48 39 d0             	cmp    %rdx,%rax
    4e79:	0f 82 a9 00 00 00    	jb     4f28 <fwp_tape_buffers_release+0xf8>
    4e7f:	48 8d 3d 39 72 00 00 	lea    0x7239(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4e86:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4e8b:	48 89 14 24          	mov    %rdx,(%rsp)
    4e8f:	e8 0c e5 ff ff       	call   33a0 <getenv@plt>
    4e94:	48 8b 14 24          	mov    (%rsp),%rdx
    4e98:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    4e9d:	48 85 c0             	test   %rax,%rax
    4ea0:	74 09                	je     4eab <fwp_tape_buffers_release+0x7b>
    4ea2:	80 38 30             	cmpb   $0x30,(%rax)
    4ea5:	0f 84 9d 00 00 00    	je     4f48 <fwp_tape_buffers_release+0x118>
    4eab:	48 8d 04 d1          	lea    (%rcx,%rdx,8),%rax
    4eaf:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    4eb3:	48 81 fa ff ff 07 00 	cmp    $0x7ffff,%rdx
    4eba:	77 78                	ja     4f34 <fwp_tape_buffers_release+0x104>
    4ebc:	48 8d 3d dd b1 01 00 	lea    0x1b1dd(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    4ec3:	48 89 04 24          	mov    %rax,(%rsp)
    4ec7:	e8 a4 f0 ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    4ecc:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    4ed0:	48 8b 04 24          	mov    (%rsp),%rax
    4ed4:	0f 29 05 c5 b1 01 00 	movaps %xmm0,0x1b1c5(%rip)        # 200a0 <fwp_tape_workspace>
    4edb:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    4ee0:	48 89 05 a1 b1 01 00 	mov    %rax,0x1b1a1(%rip)        # 20088 <fwp_tape_cached_bytes>
    4ee7:	0f 29 05 c2 b1 01 00 	movaps %xmm0,0x1b1c2(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    4eee:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    4ef3:	0f 29 05 c6 b1 01 00 	movaps %xmm0,0x1b1c6(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    4efa:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    4efe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4f02:	48 89 15 c7 b1 01 00 	mov    %rdx,0x1b1c7(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    4f09:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    4f10:	00 
    4f11:	0f 11 03             	movups %xmm0,(%rbx)
    4f14:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    4f18:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    4f1c:	48 83 c4 10          	add    $0x10,%rsp
    4f20:	5b                   	pop    %rbx
    4f21:	c3                   	ret
    4f22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4f28:	48 8d 3d 90 71 00 00 	lea    0x7190(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    4f2f:	e8 6c e4 ff ff       	call   33a0 <getenv@plt>
    4f34:	48 83 c4 10          	add    $0x10,%rsp
    4f38:	48 89 df             	mov    %rbx,%rdi
    4f3b:	5b                   	pop    %rbx
    4f3c:	e9 2f f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4f48:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    4f4c:	0f 85 59 ff ff ff    	jne    4eab <fwp_tape_buffers_release+0x7b>
    4f52:	48 83 c4 10          	add    $0x10,%rsp
    4f56:	48 89 df             	mov    %rbx,%rdi
    4f59:	5b                   	pop    %rbx
    4f5a:	e9 11 f0 ff ff       	jmp    3f70 <fwp_tape_buffers_dispose>
    4f5f:	90                   	nop

0000000000004f60 <fwp_poll_events>:
    4f60:	53                   	push   %rbx
    4f61:	48 83 ec 20          	sub    $0x20,%rsp
    4f65:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4f6c:	00 00 
    4f6e:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    4f73:	31 c0                	xor    %eax,%eax
    4f75:	e8 96 f3 ff ff       	call   4310 <fwp_now_ns>
    4f7a:	48 8b 1d 97 b7 01 00 	mov    0x1b797(%rip),%rbx        # 20718 <fwp_timers>
    4f81:	48 85 db             	test   %rbx,%rbx
    4f84:	0f 84 d6 00 00 00    	je     5060 <fwp_poll_events+0x100>
    4f8a:	48 89 c6             	mov    %rax,%rsi
    4f8d:	48 89 da             	mov    %rbx,%rdx
    4f90:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    4f97:	eb 16                	jmp    4faf <fwp_poll_events+0x4f>
    4f99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4fa0:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fa7:	48 89 c8             	mov    %rcx,%rax
    4faa:	48 85 d2             	test   %rdx,%rdx
    4fad:	74 31                	je     4fe0 <fwp_poll_events+0x80>
    4faf:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fb3:	48 85 c0             	test   %rax,%rax
    4fb6:	78 e8                	js     4fa0 <fwp_poll_events+0x40>
    4fb8:	48 39 c1             	cmp    %rax,%rcx
    4fbb:	7c e3                	jl     4fa0 <fwp_poll_events+0x40>
    4fbd:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fc4:	48 85 d2             	test   %rdx,%rdx
    4fc7:	74 1c                	je     4fe5 <fwp_poll_events+0x85>
    4fc9:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    4fcd:	48 39 c1             	cmp    %rax,%rcx
    4fd0:	7c ce                	jl     4fa0 <fwp_poll_events+0x40>
    4fd2:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    4fd9:	48 85 d2             	test   %rdx,%rdx
    4fdc:	75 d1                	jne    4faf <fwp_poll_events+0x4f>
    4fde:	66 90                	xchg   %ax,%ax
    4fe0:	48 85 c0             	test   %rax,%rax
    4fe3:	78 7b                	js     5060 <fwp_poll_events+0x100>
    4fe5:	48 29 f0             	sub    %rsi,%rax
    4fe8:	48 89 c1             	mov    %rax,%rcx
    4feb:	48 85 c0             	test   %rax,%rax
    4fee:	0f 8e 9c 00 00 00    	jle    5090 <fwp_poll_events+0x130>
    4ff4:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    4ffb:	de 1b 43 
    4ffe:	48 f7 ea             	imul   %rdx
    5001:	48 89 c8             	mov    %rcx,%rax
    5004:	48 c1 f8 3f          	sar    $0x3f,%rax
    5008:	48 c1 fa 12          	sar    $0x12,%rdx
    500c:	48 29 c2             	sub    %rax,%rdx
    500f:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    5016:	48 39 c1             	cmp    %rax,%rcx
    5019:	0f 95 c0             	setne  %al
    501c:	0f b6 c0             	movzbl %al,%eax
    501f:	48 01 d0             	add    %rdx,%rax
    5022:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    5028:	0f 8f 32 01 00 00    	jg     5160 <fwp_poll_events+0x200>
    502e:	48 85 c0             	test   %rax,%rax
    5031:	74 5d                	je     5090 <fwp_poll_events+0x130>
    5033:	89 c1                	mov    %eax,%ecx
    5035:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    503c:	48 c1 e9 26          	shr    $0x26,%rcx
    5040:	48 63 d1             	movslq %ecx,%rdx
    5043:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    5049:	29 c8                	sub    %ecx,%eax
    504b:	48 98                	cltq
    504d:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    5054:	e9 11 01 00 00       	jmp    516a <fwp_poll_events+0x20a>
    5059:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5060:	e8 0b ec ff ff       	call   3c70 <fwp_flush>
    5065:	ba 2b 00 00 00       	mov    $0x2b,%edx
    506a:	be 01 00 00 00       	mov    $0x1,%esi
    506f:	48 8b 0d ca af 00 00 	mov    0xafca(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5076:	48 8d 3d c3 76 00 00 	lea    0x76c3(%rip),%rdi        # c740 <_IO_stdin_used+0x740>
    507d:	e8 fe e5 ff ff       	call   3680 <fwrite@plt>
    5082:	bf 65 00 00 00       	mov    $0x65,%edi
    5087:	e8 e4 e5 ff ff       	call   3670 <exit@plt>
    508c:	0f 1f 40 00          	nopl   0x0(%rax)
    5090:	e8 7b f2 ff ff       	call   4310 <fwp_now_ns>
    5095:	48 89 c1             	mov    %rax,%rcx
    5098:	66 0f ef c0          	pxor   %xmm0,%xmm0
    509c:	eb 44                	jmp    50e2 <fwp_poll_events+0x182>
    509e:	66 90                	xchg   %ax,%ax
    50a0:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    50a4:	75 33                	jne    50d9 <fwp_poll_events+0x179>
    50a6:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    50aa:	75 2d                	jne    50d9 <fwp_poll_events+0x179>
    50ac:	48 8b 05 6d b6 01 00 	mov    0x1b66d(%rip),%rax        # 20720 <fwp_ready_tail>
    50b3:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    50b7:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    50be:	00 00 00 00 
    50c2:	48 85 c0             	test   %rax,%rax
    50c5:	0f 84 05 01 00 00    	je     51d0 <fwp_poll_events+0x270>
    50cb:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    50d2:	48 89 15 47 b6 01 00 	mov    %rdx,0x1b647(%rip)        # 20720 <fwp_ready_tail>
    50d9:	48 85 db             	test   %rbx,%rbx
    50dc:	0f 84 be 00 00 00    	je     51a0 <fwp_poll_events+0x240>
    50e2:	48 89 da             	mov    %rbx,%rdx
    50e5:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    50ec:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    50f0:	7f e7                	jg     50d9 <fwp_poll_events+0x179>
    50f2:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    50f6:	74 2e                	je     5126 <fwp_poll_events+0x1c6>
    50f8:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    50ff:	48 85 c0             	test   %rax,%rax
    5102:	0f 84 b8 00 00 00    	je     51c0 <fwp_poll_events+0x260>
    5108:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    510f:	48 85 db             	test   %rbx,%rbx
    5112:	74 07                	je     511b <fwp_poll_events+0x1bb>
    5114:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    511b:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    511f:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    5126:	48 8b 42 60          	mov    0x60(%rdx),%rax
    512a:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    512e:	48 85 c0             	test   %rax,%rax
    5131:	0f 84 69 ff ff ff    	je     50a0 <fwp_poll_events+0x140>
    5137:	48 39 c8             	cmp    %rcx,%rax
    513a:	0f 8f 60 ff ff ff    	jg     50a0 <fwp_poll_events+0x140>
    5140:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    5144:	0f 85 56 ff ff ff    	jne    50a0 <fwp_poll_events+0x140>
    514a:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    514e:	75 89                	jne    50d9 <fwp_poll_events+0x179>
    5150:	48 89 d7             	mov    %rdx,%rdi
    5153:	e8 58 ef ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    5158:	e9 43 ff ff ff       	jmp    50a0 <fwp_poll_events+0x140>
    515d:	0f 1f 00             	nopl   (%rax)
    5160:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5165:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    516a:	48 89 e7             	mov    %rsp,%rdi
    516d:	31 f6                	xor    %esi,%esi
    516f:	48 89 14 24          	mov    %rdx,(%rsp)
    5173:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5178:	e8 23 e3 ff ff       	call   34a0 <nanosleep@plt>
    517d:	48 8b 1d 94 b5 01 00 	mov    0x1b594(%rip),%rbx        # 20718 <fwp_timers>
    5184:	e8 87 f1 ff ff       	call   4310 <fwp_now_ns>
    5189:	48 89 c1             	mov    %rax,%rcx
    518c:	48 85 db             	test   %rbx,%rbx
    518f:	0f 85 03 ff ff ff    	jne    5098 <fwp_poll_events+0x138>
    5195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    519c:	00 00 00 00 
    51a0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    51a5:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    51ac:	00 00 
    51ae:	75 2c                	jne    51dc <fwp_poll_events+0x27c>
    51b0:	48 83 c4 20          	add    $0x20,%rsp
    51b4:	5b                   	pop    %rbx
    51b5:	c3                   	ret
    51b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    51bd:	00 00 00 
    51c0:	48 89 1d 51 b5 01 00 	mov    %rbx,0x1b551(%rip)        # 20718 <fwp_timers>
    51c7:	e9 43 ff ff ff       	jmp    510f <fwp_poll_events+0x1af>
    51cc:	0f 1f 40 00          	nopl   0x0(%rax)
    51d0:	48 89 15 51 b5 01 00 	mov    %rdx,0x1b551(%rip)        # 20728 <fwp_ready_head>
    51d7:	e9 f6 fe ff ff       	jmp    50d2 <fwp_poll_events+0x172>
    51dc:	e8 7f e2 ff ff       	call   3460 <__stack_chk_fail@plt>
    51e1:	0f 1f 40 00          	nopl   0x0(%rax)
    51e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    51ec:	00 00 00 00 

00000000000051f0 <fwp_rc_wide_dup>:
    51f0:	48 89 fa             	mov    %rdi,%rdx
    51f3:	48 8d 35 66 b5 01 00 	lea    0x1b566(%rip),%rsi        # 20760 <fwp_heap>
    51fa:	48 83 ec 18          	sub    $0x18,%rsp
    51fe:	48 89 f9             	mov    %rdi,%rcx
    5201:	48 c1 ea 11          	shr    $0x11,%rdx
    5205:	48 31 fa             	xor    %rdi,%rdx
    5208:	48 89 d0             	mov    %rdx,%rax
    520b:	48 c1 e8 09          	shr    $0x9,%rax
    520f:	48 31 c2             	xor    %rax,%rdx
    5212:	0f b6 d2             	movzbl %dl,%edx
    5215:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    521c:	00 
    521d:	49 8b 00             	mov    (%r8),%rax
    5220:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    5227:	00 00 
    5229:	75 21                	jne    524c <fwp_rc_wide_dup+0x5c>
    522b:	e9 98 00 00 00       	jmp    52c8 <fwp_rc_wide_dup+0xd8>
    5230:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 
    5240:	48 8b 50 10          	mov    0x10(%rax),%rdx
    5244:	48 85 d2             	test   %rdx,%rdx
    5247:	74 2f                	je     5278 <fwp_rc_wide_dup+0x88>
    5249:	48 89 d0             	mov    %rdx,%rax
    524c:	48 3b 08             	cmp    (%rax),%rcx
    524f:	75 ef                	jne    5240 <fwp_rc_wide_dup+0x50>
    5251:	80 39 fe             	cmpb   $0xfe,(%rcx)
    5254:	74 7c                	je     52d2 <fwp_rc_wide_dup+0xe2>
    5256:	48 8b 50 08          	mov    0x8(%rax),%rdx
    525a:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    525e:	0f 84 91 00 00 00    	je     52f5 <fwp_rc_wide_dup+0x105>
    5264:	48 83 c2 01          	add    $0x1,%rdx
    5268:	48 89 50 08          	mov    %rdx,0x8(%rax)
    526c:	48 83 c4 18          	add    $0x18,%rsp
    5270:	c3                   	ret
    5271:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5278:	4c 8d 40 10          	lea    0x10(%rax),%r8
    527c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    527f:	75 68                	jne    52e9 <fwp_rc_wide_dup+0xf9>
    5281:	bf 18 00 00 00       	mov    $0x18,%edi
    5286:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    528b:	4c 89 04 24          	mov    %r8,(%rsp)
    528f:	e8 1c e3 ff ff       	call   35b0 <malloc@plt>
    5294:	4c 8b 04 24          	mov    (%rsp),%r8
    5298:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    529d:	48 85 c0             	test   %rax,%rax
    52a0:	74 5f                	je     5301 <fwp_rc_wide_dup+0x111>
    52a2:	48 89 08             	mov    %rcx,(%rax)
    52a5:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    52ac:	00 
    52ad:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    52b4:	00 
    52b5:	49 89 00             	mov    %rax,(%r8)
    52b8:	c6 01 ff             	movb   $0xff,(%rcx)
    52bb:	48 83 05 e5 d0 01 00 	addq   $0x1,0x1d0e5(%rip)        # 223a8 <fwp_heap+0x1c48>
    52c2:	01 
    52c3:	48 83 c4 18          	add    $0x18,%rsp
    52c7:	c3                   	ret
    52c8:	80 3f fe             	cmpb   $0xfe,(%rdi)
    52cb:	75 13                	jne    52e0 <fwp_rc_wide_dup+0xf0>
    52cd:	48 85 c0             	test   %rax,%rax
    52d0:	74 af                	je     5281 <fwp_rc_wide_dup+0x91>
    52d2:	48 8d 3d 97 74 00 00 	lea    0x7497(%rip),%rdi        # c770 <_IO_stdin_used+0x770>
    52d9:	e8 c2 ee ff ff       	call   41a0 <fwp_trap>
    52de:	66 90                	xchg   %ax,%ax
    52e0:	48 85 c0             	test   %rax,%rax
    52e3:	0f 85 6d ff ff ff    	jne    5256 <fwp_rc_wide_dup+0x66>
    52e9:	48 8d 3d a8 74 00 00 	lea    0x74a8(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    52f0:	e8 ab ee ff ff       	call   41a0 <fwp_trap>
    52f5:	48 8d 3d d4 6d 00 00 	lea    0x6dd4(%rip),%rdi        # c0d0 <_IO_stdin_used+0xd0>
    52fc:	e8 9f ee ff ff       	call   41a0 <fwp_trap>
    5301:	e8 aa e9 ff ff       	call   3cb0 <fwp_heap_oom>
    5306:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    530d:	00 00 00 

0000000000005310 <fwp_rc_forget_slot>:
    5310:	80 3f ff             	cmpb   $0xff,(%rdi)
    5313:	74 0b                	je     5320 <fwp_rc_forget_slot+0x10>
    5315:	c3                   	ret
    5316:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    531d:	00 00 00 
    5320:	48 89 f8             	mov    %rdi,%rax
    5323:	48 83 ec 08          	sub    $0x8,%rsp
    5327:	48 89 fa             	mov    %rdi,%rdx
    532a:	48 c1 e8 11          	shr    $0x11,%rax
    532e:	48 31 f8             	xor    %rdi,%rax
    5331:	48 89 c1             	mov    %rax,%rcx
    5334:	48 c1 e9 09          	shr    $0x9,%rcx
    5338:	48 31 c8             	xor    %rcx,%rax
    533b:	48 8d 0d 1e b4 01 00 	lea    0x1b41e(%rip),%rcx        # 20760 <fwp_heap>
    5342:	0f b6 c0             	movzbl %al,%eax
    5345:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    534c:	00 
    534d:	48 85 ff             	test   %rdi,%rdi
    5350:	74 3c                	je     538e <fwp_rc_forget_slot+0x7e>
    5352:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    5359:	00 
    535a:	48 8b 01             	mov    (%rcx),%rax
    535d:	eb 11                	jmp    5370 <fwp_rc_forget_slot+0x60>
    535f:	90                   	nop
    5360:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5364:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5368:	48 85 ff             	test   %rdi,%rdi
    536b:	74 21                	je     538e <fwp_rc_forget_slot+0x7e>
    536d:	48 89 f8             	mov    %rdi,%rax
    5370:	48 3b 10             	cmp    (%rax),%rdx
    5373:	75 eb                	jne    5360 <fwp_rc_forget_slot+0x50>
    5375:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5379:	48 89 01             	mov    %rax,(%rcx)
    537c:	e8 3f e0 ff ff       	call   33c0 <free@plt>
    5381:	48 83 2d 1f d0 01 00 	subq   $0x1,0x1d01f(%rip)        # 223a8 <fwp_heap+0x1c48>
    5388:	01 
    5389:	48 83 c4 08          	add    $0x8,%rsp
    538d:	c3                   	ret
    538e:	48 8d 3d 03 74 00 00 	lea    0x7403(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    5395:	e8 06 ee ff ff       	call   41a0 <fwp_trap>
    539a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000053a0 <fwp_rc_prepare_chunk>:
    53a0:	48 83 3d 00 d0 01 00 	cmpq   $0x0,0x1d000(%rip)        # 223a8 <fwp_heap+0x1c48>
    53a7:	00 
    53a8:	41 54                	push   %r12
    53aa:	49 89 f4             	mov    %rsi,%r12
    53ad:	55                   	push   %rbp
    53ae:	48 89 fd             	mov    %rdi,%rbp
    53b1:	53                   	push   %rbx
    53b2:	8b 47 1c             	mov    0x1c(%rdi),%eax
    53b5:	0f 84 7d 00 00 00    	je     5438 <fwp_rc_prepare_chunk+0x98>
    53bb:	31 db                	xor    %ebx,%ebx
    53bd:	85 c0                	test   %eax,%eax
    53bf:	75 5f                	jne    5420 <fwp_rc_prepare_chunk+0x80>
    53c1:	48 85 f6             	test   %rsi,%rsi
    53c4:	74 7c                	je     5442 <fwp_rc_prepare_chunk+0xa2>
    53c6:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    53ca:	e8 f1 df ff ff       	call   33c0 <free@plt>
    53cf:	90                   	nop
    53d0:	be 01 00 00 00       	mov    $0x1,%esi
    53d5:	4c 89 e7             	mov    %r12,%rdi
    53d8:	e8 43 e1 ff ff       	call   3520 <calloc@plt>
    53dd:	48 89 45 20          	mov    %rax,0x20(%rbp)
    53e1:	48 85 c0             	test   %rax,%rax
    53e4:	0f 85 87 00 00 00    	jne    5471 <fwp_rc_prepare_chunk+0xd1>
    53ea:	e8 c1 e8 ff ff       	call   3cb0 <fwp_heap_oom>
    53ef:	90                   	nop
    53f0:	e8 1b ff ff ff       	call   5310 <fwp_rc_forget_slot>
    53f5:	8b 45 1c             	mov    0x1c(%rbp),%eax
    53f8:	48 83 c3 01          	add    $0x1,%rbx
    53fc:	48 39 c3             	cmp    %rax,%rbx
    53ff:	73 37                	jae    5438 <fwp_rc_prepare_chunk+0x98>
    5401:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5408:	00 00 
    540a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5411:	00 00 00 00 
    5415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    541c:	00 00 00 00 
    5420:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5424:	48 01 df             	add    %rbx,%rdi
    5427:	80 3f ff             	cmpb   $0xff,(%rdi)
    542a:	74 c4                	je     53f0 <fwp_rc_prepare_chunk+0x50>
    542c:	8b 45 1c             	mov    0x1c(%rbp),%eax
    542f:	48 83 c3 01          	add    $0x1,%rbx
    5433:	48 39 c3             	cmp    %rax,%rbx
    5436:	72 e8                	jb     5420 <fwp_rc_prepare_chunk+0x80>
    5438:	49 39 c4             	cmp    %rax,%r12
    543b:	75 13                	jne    5450 <fwp_rc_prepare_chunk+0xb0>
    543d:	4d 85 e4             	test   %r12,%r12
    5440:	75 46                	jne    5488 <fwp_rc_prepare_chunk+0xe8>
    5442:	5b                   	pop    %rbx
    5443:	5d                   	pop    %rbp
    5444:	41 5c                	pop    %r12
    5446:	c3                   	ret
    5447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    544e:	00 00 
    5450:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5454:	48 29 05 55 cf 01 00 	sub    %rax,0x1cf55(%rip)        # 223b0 <fwp_heap+0x1c50>
    545b:	e8 60 df ff ff       	call   33c0 <free@plt>
    5460:	4d 85 e4             	test   %r12,%r12
    5463:	0f 85 67 ff ff ff    	jne    53d0 <fwp_rc_prepare_chunk+0x30>
    5469:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5470:	00 
    5471:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5475:	5b                   	pop    %rbx
    5476:	4c 01 25 33 cf 01 00 	add    %r12,0x1cf33(%rip)        # 223b0 <fwp_heap+0x1c50>
    547d:	5d                   	pop    %rbp
    547e:	41 5c                	pop    %r12
    5480:	c3                   	ret
    5481:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5488:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    548c:	5b                   	pop    %rbx
    548d:	4c 89 e2             	mov    %r12,%rdx
    5490:	31 f6                	xor    %esi,%esi
    5492:	5d                   	pop    %rbp
    5493:	41 5c                	pop    %r12
    5495:	e9 26 e0 ff ff       	jmp    34c0 <memset@plt>
    549a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000054a0 <fwp_heap_refill>:
    54a0:	41 56                	push   %r14
    54a2:	41 89 d6             	mov    %edx,%r14d
    54a5:	41 55                	push   %r13
    54a7:	41 89 f5             	mov    %esi,%r13d
    54aa:	41 54                	push   %r12
    54ac:	49 89 fc             	mov    %rdi,%r12
    54af:	bf 01 00 00 00       	mov    $0x1,%edi
    54b4:	55                   	push   %rbp
    54b5:	53                   	push   %rbx
    54b6:	e8 25 e9 ff ff       	call   3de0 <fwp_heap_chunks>
    54bb:	48 89 c3             	mov    %rax,%rbx
    54be:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    54c2:	48 8b 05 8f c6 01 00 	mov    0x1c68f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    54c9:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    54cd:	48 8d 05 8c b2 01 00 	lea    0x1b28c(%rip),%rax        # 20760 <fwp_heap>
    54d4:	31 d2                	xor    %edx,%edx
    54d6:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    54da:	48 89 ef             	mov    %rbp,%rdi
    54dd:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    54e1:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    54e5:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    54ec:	00 
    54ed:	b8 00 00 01 00       	mov    $0x10000,%eax
    54f2:	f7 f1                	div    %ecx
    54f4:	31 d2                	xor    %edx,%edx
    54f6:	66 0f 6e c1          	movd   %ecx,%xmm0
    54fa:	66 0f 6e c8          	movd   %eax,%xmm1
    54fe:	89 c6                	mov    %eax,%esi
    5500:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    5505:	48 01 c8             	add    %rcx,%rax
    5508:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    550c:	48 f7 f1             	div    %rcx
    550f:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    5514:	89 45 18             	mov    %eax,0x18(%rbp)
    5517:	e8 84 fe ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    551c:	8b 4d 04             	mov    0x4(%rbp),%ecx
    551f:	48 89 d8             	mov    %rbx,%rax
    5522:	48 c1 e0 10          	shl    $0x10,%rax
    5526:	48 03 05 e3 c5 01 00 	add    0x1c5e3(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    552d:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    5531:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    5536:	8b 55 08             	mov    0x8(%rbp),%edx
    5539:	48 0f af d1          	imul   %rcx,%rdx
    553d:	48 01 c2             	add    %rax,%rdx
    5540:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    5545:	5b                   	pop    %rbx
    5546:	5d                   	pop    %rbp
    5547:	41 5c                	pop    %r12
    5549:	41 5d                	pop    %r13
    554b:	41 5e                	pop    %r14
    554d:	c3                   	ret
    554e:	66 90                	xchg   %ax,%ax

0000000000005550 <fwp_mem_free>:
    5550:	48 85 ff             	test   %rdi,%rdi
    5553:	0f 84 17 02 00 00    	je     5770 <fwp_mem_free+0x220>
    5559:	48 8b 35 b0 c5 01 00 	mov    0x1c5b0(%rip),%rsi        # 21b10 <fwp_heap+0x13b0>
    5560:	48 8b 05 d1 c5 01 00 	mov    0x1c5d1(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    5567:	48 89 fa             	mov    %rdi,%rdx
    556a:	48 29 f2             	sub    %rsi,%rdx
    556d:	48 c1 e0 10          	shl    $0x10,%rax
    5571:	48 39 c2             	cmp    %rax,%rdx
    5574:	0f 83 f6 01 00 00    	jae    5770 <fwp_mem_free+0x220>
    557a:	49 89 d1             	mov    %rdx,%r9
    557d:	49 c1 e9 10          	shr    $0x10,%r9
    5581:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5585:	48 c1 e0 03          	shl    $0x3,%rax
    5589:	49 89 c0             	mov    %rax,%r8
    558c:	4c 03 05 c5 c5 01 00 	add    0x1c5c5(%rip),%r8        # 21b58 <fwp_heap+0x13f8>
    5593:	0f 84 d7 01 00 00    	je     5770 <fwp_mem_free+0x220>
    5599:	48 83 ec 38          	sub    $0x38,%rsp
    559d:	48 89 f9             	mov    %rdi,%rcx
    55a0:	41 0f b6 38          	movzbl (%r8),%edi
    55a4:	40 80 ff 01          	cmp    $0x1,%dil
    55a8:	74 16                	je     55c0 <fwp_mem_free+0x70>
    55aa:	40 80 ff 02          	cmp    $0x2,%dil
    55ae:	0f 84 94 00 00 00    	je     5648 <fwp_mem_free+0xf8>
    55b4:	48 83 c4 38          	add    $0x38,%rsp
    55b8:	c3                   	ret
    55b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    55c0:	4d 8b 50 20          	mov    0x20(%r8),%r10
    55c4:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    55c9:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    55ce:	41 8b 78 04          	mov    0x4(%r8),%edi
    55d2:	4d 85 d2             	test   %r10,%r10
    55d5:	74 1d                	je     55f4 <fwp_mem_free+0xa4>
    55d7:	0f b7 c1             	movzwl %cx,%eax
    55da:	31 d2                	xor    %edx,%edx
    55dc:	48 f7 f7             	div    %rdi
    55df:	49 01 c2             	add    %rax,%r10
    55e2:	41 80 3a ff          	cmpb   $0xff,(%r10)
    55e6:	0f 84 44 01 00 00    	je     5730 <fwp_mem_free+0x1e0>
    55ec:	41 c6 02 00          	movb   $0x0,(%r10)
    55f0:	41 8b 78 04          	mov    0x4(%r8),%edi
    55f4:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    55fb:	49 63 c1             	movslq %r9d,%rax
    55fe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5602:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5606:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    560b:	f2 0f 58 05 8d c5 01 	addsd  0x1c58d(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    5612:	00 
    5613:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5617:	48 8d 05 42 b1 01 00 	lea    0x1b142(%rip),%rax        # 20760 <fwp_heap>
    561e:	48 01 d0             	add    %rdx,%rax
    5621:	48 8b 10             	mov    (%rax),%rdx
    5624:	48 f7 d2             	not    %rdx
    5627:	48 89 11             	mov    %rdx,(%rcx)
    562a:	48 89 08             	mov    %rcx,(%rax)
    562d:	48 29 3d 4c c5 01 00 	sub    %rdi,0x1c54c(%rip)        # 21b80 <fwp_heap+0x1420>
    5634:	f2 0f 11 05 64 c5 01 	movsd  %xmm0,0x1c564(%rip)        # 21ba0 <fwp_heap+0x1440>
    563b:	00 
    563c:	48 83 c4 38          	add    $0x38,%rsp
    5640:	c3                   	ret
    5641:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5648:	66 31 d2             	xor    %dx,%dx
    564b:	48 01 d6             	add    %rdx,%rsi
    564e:	48 39 f1             	cmp    %rsi,%rcx
    5651:	0f 85 5d ff ff ff    	jne    55b4 <fwp_mem_free+0x64>
    5657:	49 8b 50 10          	mov    0x10(%r8),%rdx
    565b:	48 29 15 1e c5 01 00 	sub    %rdx,0x1c51e(%rip)        # 21b80 <fwp_heap+0x1420>
    5662:	48 85 d2             	test   %rdx,%rdx
    5665:	0f 88 a5 00 00 00    	js     5710 <fwp_mem_free+0x1c0>
    566b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    566f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5674:	f2 0f 58 05 24 c5 01 	addsd  0x1c524(%rip),%xmm0        # 21ba0 <fwp_heap+0x1440>
    567b:	00 
    567c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5680:	f2 0f 11 05 18 c5 01 	movsd  %xmm0,0x1c518(%rip)        # 21ba0 <fwp_heap+0x1440>
    5687:	00 
    5688:	48 85 d2             	test   %rdx,%rdx
    568b:	74 0c                	je     5699 <fwp_mem_free+0x149>
    568d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5690:	0f 84 db 00 00 00    	je     5771 <fwp_mem_free+0x221>
    5696:	c6 02 00             	movb   $0x0,(%rdx)
    5699:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    569d:	48 85 c9             	test   %rcx,%rcx
    56a0:	74 3e                	je     56e0 <fwp_mem_free+0x190>
    56a2:	48 8b 15 af c4 01 00 	mov    0x1c4af(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    56a9:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    56ad:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    56b1:	48 01 d0             	add    %rdx,%rax
    56b4:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    56b8:	48 89 d6             	mov    %rdx,%rsi
    56bb:	48 29 c6             	sub    %rax,%rsi
    56be:	83 e6 08             	and    $0x8,%esi
    56c1:	74 0d                	je     56d0 <fwp_mem_free+0x180>
    56c3:	c6 00 00             	movb   $0x0,(%rax)
    56c6:	48 83 c0 28          	add    $0x28,%rax
    56ca:	48 39 c2             	cmp    %rax,%rdx
    56cd:	74 11                	je     56e0 <fwp_mem_free+0x190>
    56cf:	90                   	nop
    56d0:	c6 00 00             	movb   $0x0,(%rax)
    56d3:	48 83 c0 50          	add    $0x50,%rax
    56d7:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    56db:	48 39 c2             	cmp    %rax,%rdx
    56de:	75 f0                	jne    56d0 <fwp_mem_free+0x180>
    56e0:	48 01 0d a9 c4 01 00 	add    %rcx,0x1c4a9(%rip)        # 21b90 <fwp_heap+0x1430>
    56e7:	4c 3b 0d 62 c4 01 00 	cmp    0x1c462(%rip),%r9        # 21b50 <fwp_heap+0x13f0>
    56ee:	73 07                	jae    56f7 <fwp_mem_free+0x1a7>
    56f0:	4c 89 0d 59 c4 01 00 	mov    %r9,0x1c459(%rip)        # 21b50 <fwp_heap+0x13f0>
    56f7:	4c 3b 0d 4a c4 01 00 	cmp    0x1c44a(%rip),%r9        # 21b48 <fwp_heap+0x13e8>
    56fe:	0f 83 b0 fe ff ff    	jae    55b4 <fwp_mem_free+0x64>
    5704:	4c 89 0d 3d c4 01 00 	mov    %r9,0x1c43d(%rip)        # 21b48 <fwp_heap+0x13e8>
    570b:	e9 a4 fe ff ff       	jmp    55b4 <fwp_mem_free+0x64>
    5710:	48 89 d1             	mov    %rdx,%rcx
    5713:	83 e2 01             	and    $0x1,%edx
    5716:	66 0f ef c0          	pxor   %xmm0,%xmm0
    571a:	48 d1 e9             	shr    $1,%rcx
    571d:	48 09 d1             	or     %rdx,%rcx
    5720:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5725:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5729:	e9 46 ff ff ff       	jmp    5674 <fwp_mem_free+0x124>
    572e:	66 90                	xchg   %ax,%ax
    5730:	4c 89 d7             	mov    %r10,%rdi
    5733:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5738:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    573d:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5742:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5746:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    574b:	e8 c0 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    5750:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5755:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    575a:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    575f:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5764:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5769:	e9 7e fe ff ff       	jmp    55ec <fwp_mem_free+0x9c>
    576e:	66 90                	xchg   %ax,%ax
    5770:	c3                   	ret
    5771:	48 89 d7             	mov    %rdx,%rdi
    5774:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5779:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    577e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5783:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5788:	e8 83 fb ff ff       	call   5310 <fwp_rc_forget_slot>
    578d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5792:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5797:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    579c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    57a1:	e9 f0 fe ff ff       	jmp    5696 <fwp_mem_free+0x146>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_heap_alloc_big>:
    57b0:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    57b7:	00 00 40 
    57ba:	41 57                	push   %r15
    57bc:	41 56                	push   %r14
    57be:	41 55                	push   %r13
    57c0:	41 54                	push   %r12
    57c2:	55                   	push   %rbp
    57c3:	53                   	push   %rbx
    57c4:	48 83 ec 08          	sub    $0x8,%rsp
    57c8:	48 39 f8             	cmp    %rdi,%rax
    57cb:	0f 82 fa 00 00 00    	jb     58cb <fwp_heap_alloc_big+0x11b>
    57d1:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    57d8:	49 89 fd             	mov    %rdi,%r13
    57db:	41 89 f6             	mov    %esi,%r14d
    57de:	48 c1 ed 10          	shr    $0x10,%rbp
    57e2:	48 89 ef             	mov    %rbp,%rdi
    57e5:	e8 f6 e5 ff ff       	call   3de0 <fwp_heap_chunks>
    57ea:	be 01 00 00 00       	mov    $0x1,%esi
    57ef:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    57f3:	49 89 c4             	mov    %rax,%r12
    57f6:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    57fd:	00 
    57fe:	48 03 3d 53 c3 01 00 	add    0x1c353(%rip),%rdi        # 21b58 <fwp_heap+0x13f8>
    5805:	c6 07 02             	movb   $0x2,(%rdi)
    5808:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    580c:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    580f:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5813:	e8 88 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5818:	48 83 fd 01          	cmp    $0x1,%rbp
    581c:	76 47                	jbe    5865 <fwp_heap_alloc_big+0xb5>
    581e:	4c 01 e5             	add    %r12,%rbp
    5821:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5828:	00 
    5829:	4c 8d 3d 30 af 01 00 	lea    0x1af30(%rip),%r15        # 20760 <fwp_heap>
    5830:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5835:	49 c1 e6 03          	shl    $0x3,%r14
    5839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5840:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5847:	31 f6                	xor    %esi,%esi
    5849:	48 01 dd             	add    %rbx,%rbp
    584c:	48 83 c3 28          	add    $0x28,%rbx
    5850:	48 89 ef             	mov    %rbp,%rdi
    5853:	e8 48 fb ff ff       	call   53a0 <fwp_rc_prepare_chunk>
    5858:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    585c:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5860:	49 39 de             	cmp    %rbx,%r14
    5863:	75 db                	jne    5840 <fwp_heap_alloc_big+0x90>
    5865:	49 c1 e4 10          	shl    $0x10,%r12
    5869:	4c 03 25 a0 c2 01 00 	add    0x1c2a0(%rip),%r12        # 21b10 <fwp_heap+0x13b0>
    5870:	4c 89 ea             	mov    %r13,%rdx
    5873:	31 f6                	xor    %esi,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 43 dc ff ff       	call   34c0 <memset@plt>
    587d:	4c 89 e8             	mov    %r13,%rax
    5880:	48 03 05 f9 c2 01 00 	add    0x1c2f9(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5887:	72 42                	jb     58cb <fwp_heap_alloc_big+0x11b>
    5889:	48 39 05 f8 c2 01 00 	cmp    %rax,0x1c2f8(%rip)        # 21b88 <fwp_heap+0x1428>
    5890:	48 89 05 e9 c2 01 00 	mov    %rax,0x1c2e9(%rip)        # 21b80 <fwp_heap+0x1420>
    5897:	73 07                	jae    58a0 <fwp_heap_alloc_big+0xf0>
    5899:	48 89 05 e8 c2 01 00 	mov    %rax,0x1c2e8(%rip)        # 21b88 <fwp_heap+0x1428>
    58a0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    58a4:	4c 89 e0             	mov    %r12,%rax
    58a7:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    58ac:	f2 0f 58 05 e4 c2 01 	addsd  0x1c2e4(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    58b3:	00 
    58b4:	f2 0f 11 05 dc c2 01 	movsd  %xmm0,0x1c2dc(%rip)        # 21b98 <fwp_heap+0x1438>
    58bb:	00 
    58bc:	48 83 c4 08          	add    $0x8,%rsp
    58c0:	5b                   	pop    %rbx
    58c1:	5d                   	pop    %rbp
    58c2:	41 5c                	pop    %r12
    58c4:	41 5d                	pop    %r13
    58c6:	41 5e                	pop    %r14
    58c8:	41 5f                	pop    %r15
    58ca:	c3                   	ret
    58cb:	e8 e0 e3 ff ff       	call   3cb0 <fwp_heap_oom>

00000000000058d0 <fwp_heap_alloc_slow>:
    58d0:	53                   	push   %rbx
    58d1:	48 89 f9             	mov    %rdi,%rcx
    58d4:	41 89 f1             	mov    %esi,%r9d
    58d7:	48 83 ec 10          	sub    $0x10,%rsp
    58db:	8b 05 23 c2 01 00    	mov    0x1c223(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    58e1:	85 c0                	test   %eax,%eax
    58e3:	0f 84 c7 00 00 00    	je     59b0 <fwp_heap_alloc_slow+0xe0>
    58e9:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    58f0:	0f 87 dd 00 00 00    	ja     59d3 <fwp_heap_alloc_slow+0x103>
    58f6:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    58fa:	48 8d 3d 5f ae 01 00 	lea    0x1ae5f(%rip),%rdi        # 20760 <fwp_heap>
    5901:	49 63 f1             	movslq %r9d,%rsi
    5904:	48 c1 e8 04          	shr    $0x4,%rax
    5908:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    590f:	00 00 
    5911:	41 0f b6 c2          	movzbl %r10b,%eax
    5915:	4c 89 d2             	mov    %r10,%rdx
    5918:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    591c:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5923:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    592a:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    592e:	48 01 f8             	add    %rdi,%rax
    5931:	4c 8b 00             	mov    (%rax),%r8
    5934:	4d 85 c0             	test   %r8,%r8
    5937:	0f 84 ab 00 00 00    	je     59e8 <fwp_heap_alloc_slow+0x118>
    593d:	49 8b 10             	mov    (%r8),%rdx
    5940:	48 f7 d2             	not    %rdx
    5943:	48 89 10             	mov    %rdx,(%rax)
    5946:	41 83 f9 01          	cmp    $0x1,%r9d
    594a:	4c 89 c7             	mov    %r8,%rdi
    594d:	48 0f 45 cb          	cmovne %rbx,%rcx
    5951:	31 f6                	xor    %esi,%esi
    5953:	48 89 ca             	mov    %rcx,%rdx
    5956:	e8 65 db ff ff       	call   34c0 <memset@plt>
    595b:	49 89 c0             	mov    %rax,%r8
    595e:	48 89 d8             	mov    %rbx,%rax
    5961:	48 03 05 18 c2 01 00 	add    0x1c218(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5968:	0f 82 d9 00 00 00    	jb     5a47 <fwp_heap_alloc_slow+0x177>
    596e:	48 39 05 13 c2 01 00 	cmp    %rax,0x1c213(%rip)        # 21b88 <fwp_heap+0x1428>
    5975:	48 89 05 04 c2 01 00 	mov    %rax,0x1c204(%rip)        # 21b80 <fwp_heap+0x1420>
    597c:	73 07                	jae    5985 <fwp_heap_alloc_slow+0xb5>
    597e:	48 89 05 03 c2 01 00 	mov    %rax,0x1c203(%rip)        # 21b88 <fwp_heap+0x1428>
    5985:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5989:	4c 89 c0             	mov    %r8,%rax
    598c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5991:	f2 0f 58 05 ff c1 01 	addsd  0x1c1ff(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5998:	00 
    5999:	f2 0f 11 05 f7 c1 01 	movsd  %xmm0,0x1c1f7(%rip)        # 21b98 <fwp_heap+0x1438>
    59a0:	00 
    59a1:	48 83 c4 10          	add    $0x10,%rsp
    59a5:	5b                   	pop    %rbx
    59a6:	c3                   	ret
    59a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    59ae:	00 00 
    59b0:	89 74 24 08          	mov    %esi,0x8(%rsp)
    59b4:	48 89 3c 24          	mov    %rdi,(%rsp)
    59b8:	e8 73 f1 ff ff       	call   4b30 <fwp_heap_init>
    59bd:	48 8b 0c 24          	mov    (%rsp),%rcx
    59c1:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    59c6:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    59cd:	0f 86 23 ff ff ff    	jbe    58f6 <fwp_heap_alloc_slow+0x26>
    59d3:	48 83 c4 10          	add    $0x10,%rsp
    59d7:	44 89 ce             	mov    %r9d,%esi
    59da:	48 89 cf             	mov    %rcx,%rdi
    59dd:	5b                   	pop    %rbx
    59de:	e9 cd fd ff ff       	jmp    57b0 <fwp_heap_alloc_big>
    59e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    59e8:	4c 8b 40 08          	mov    0x8(%rax),%r8
    59ec:	4d 85 c0             	test   %r8,%r8
    59ef:	74 1f                	je     5a10 <fwp_heap_alloc_slow+0x140>
    59f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    59f5:	4d 29 c3             	sub    %r8,%r11
    59f8:	49 39 db             	cmp    %rbx,%r11
    59fb:	72 13                	jb     5a10 <fwp_heap_alloc_slow+0x140>
    59fd:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5a01:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5a05:	e9 3c ff ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5a10:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a17:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5a1b:	44 89 ca             	mov    %r9d,%edx
    5a1e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5a23:	44 89 0c 24          	mov    %r9d,(%rsp)
    5a27:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5a2b:	44 89 d6             	mov    %r10d,%esi
    5a2e:	48 01 c7             	add    %rax,%rdi
    5a31:	e8 6a fa ff ff       	call   54a0 <fwp_heap_refill>
    5a36:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5a3b:	44 8b 0c 24          	mov    (%rsp),%r9d
    5a3f:	49 89 c0             	mov    %rax,%r8
    5a42:	e9 ff fe ff ff       	jmp    5946 <fwp_heap_alloc_slow+0x76>
    5a47:	e8 64 e2 ff ff       	call   3cb0 <fwp_heap_oom>
    5a4c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005a50 <fwp_heap_alloc>:
    5a50:	8b 05 ae c0 01 00    	mov    0x1c0ae(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    5a56:	48 89 fa             	mov    %rdi,%rdx
    5a59:	89 f7                	mov    %esi,%edi
    5a5b:	85 c0                	test   %eax,%eax
    5a5d:	0f 84 f5 00 00 00    	je     5b58 <fwp_heap_alloc+0x108>
    5a63:	48 81 fa 00 40 00 00 	cmp    $0x4000,%rdx
    5a6a:	0f 87 e8 00 00 00    	ja     5b58 <fwp_heap_alloc+0x108>
    5a70:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5a74:	48 8d 05 e5 ac 01 00 	lea    0x1ace5(%rip),%rax        # 20760 <fwp_heap>
    5a7b:	48 83 ec 18          	sub    $0x18,%rsp
    5a7f:	41 89 f0             	mov    %esi,%r8d
    5a82:	48 c1 e9 04          	shr    $0x4,%rcx
    5a86:	0f b6 b4 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%esi
    5a8d:	00 
    5a8e:	48 63 cf             	movslq %edi,%rcx
    5a91:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5a98:	44 8b 8c b0 00 0f 00 	mov    0xf00(%rax,%rsi,4),%r9d
    5a9f:	00 
    5aa0:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
    5aa4:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    5aa8:	48 01 c8             	add    %rcx,%rax
    5aab:	48 8b 08             	mov    (%rax),%rcx
    5aae:	48 85 c9             	test   %rcx,%rcx
    5ab1:	74 6d                	je     5b20 <fwp_heap_alloc+0xd0>
    5ab3:	48 8b 31             	mov    (%rcx),%rsi
    5ab6:	48 f7 d6             	not    %rsi
    5ab9:	48 89 30             	mov    %rsi,(%rax)
    5abc:	41 83 f8 01          	cmp    $0x1,%r8d
    5ac0:	48 89 cf             	mov    %rcx,%rdi
    5ac3:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    5ac8:	49 0f 45 d1          	cmovne %r9,%rdx
    5acc:	31 f6                	xor    %esi,%esi
    5ace:	e8 ed d9 ff ff       	call   34c0 <memset@plt>
    5ad3:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    5ad8:	48 89 c1             	mov    %rax,%rcx
    5adb:	4c 89 c8             	mov    %r9,%rax
    5ade:	48 03 05 9b c0 01 00 	add    0x1c09b(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    5ae5:	72 7b                	jb     5b62 <fwp_heap_alloc+0x112>
    5ae7:	48 39 05 9a c0 01 00 	cmp    %rax,0x1c09a(%rip)        # 21b88 <fwp_heap+0x1428>
    5aee:	48 89 05 8b c0 01 00 	mov    %rax,0x1c08b(%rip)        # 21b80 <fwp_heap+0x1420>
    5af5:	73 07                	jae    5afe <fwp_heap_alloc+0xae>
    5af7:	48 89 05 8a c0 01 00 	mov    %rax,0x1c08a(%rip)        # 21b88 <fwp_heap+0x1428>
    5afe:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b02:	48 89 c8             	mov    %rcx,%rax
    5b05:	f2 49 0f 2a c1       	cvtsi2sd %r9,%xmm0
    5b0a:	f2 0f 58 05 86 c0 01 	addsd  0x1c086(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    5b11:	00 
    5b12:	f2 0f 11 05 7e c0 01 	movsd  %xmm0,0x1c07e(%rip)        # 21b98 <fwp_heap+0x1438>
    5b19:	00 
    5b1a:	48 83 c4 18          	add    $0x18,%rsp
    5b1e:	c3                   	ret
    5b1f:	90                   	nop
    5b20:	48 8b 48 08          	mov    0x8(%rax),%rcx
    5b24:	48 85 c9             	test   %rcx,%rcx
    5b27:	74 0c                	je     5b35 <fwp_heap_alloc+0xe5>
    5b29:	48 8b 70 10          	mov    0x10(%rax),%rsi
    5b2d:	48 29 ce             	sub    %rcx,%rsi
    5b30:	4c 39 ce             	cmp    %r9,%rsi
    5b33:	73 13                	jae    5b48 <fwp_heap_alloc+0xf8>
    5b35:	89 fe                	mov    %edi,%esi
    5b37:	48 83 c4 18          	add    $0x18,%rsp
    5b3b:	48 89 d7             	mov    %rdx,%rdi
    5b3e:	e9 8d fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b43:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5b48:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4c:	48 89 70 08          	mov    %rsi,0x8(%rax)
    5b50:	e9 67 ff ff ff       	jmp    5abc <fwp_heap_alloc+0x6c>
    5b55:	0f 1f 00             	nopl   (%rax)
    5b58:	89 fe                	mov    %edi,%esi
    5b5a:	48 89 d7             	mov    %rdx,%rdi
    5b5d:	e9 6e fd ff ff       	jmp    58d0 <fwp_heap_alloc_slow>
    5b62:	e8 49 e1 ff ff       	call   3cb0 <fwp_heap_oom>
    5b67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5b6e:	00 00 

0000000000005b70 <fwp_apply>:
    5b70:	55                   	push   %rbp
    5b71:	48 89 f9             	mov    %rdi,%rcx
    5b74:	48 89 e5             	mov    %rsp,%rbp
    5b77:	41 57                	push   %r15
    5b79:	41 56                	push   %r14
    5b7b:	41 55                	push   %r13
    5b7d:	41 89 f5             	mov    %esi,%r13d
    5b80:	41 54                	push   %r12
    5b82:	53                   	push   %rbx
    5b83:	48 83 ec 28          	sub    $0x28,%rsp
    5b87:	64 4c 8b 34 25 28 00 	mov    %fs:0x28,%r14
    5b8e:	00 00 
    5b90:	4c 89 75 c8          	mov    %r14,-0x38(%rbp)
    5b94:	49 89 d6             	mov    %rdx,%r14
    5b97:	44 8b 09             	mov    (%rcx),%r9d
    5b9a:	44 8b 61 04          	mov    0x4(%rcx),%r12d
    5b9e:	49 89 e0             	mov    %rsp,%r8
    5ba1:	49 c1 e1 05          	shl    $0x5,%r9
    5ba5:	4c 03 0d 0c c8 01 00 	add    0x1c80c(%rip),%r9        # 223b8 <fwp_fns>
    5bac:	41 8b 19             	mov    (%r9),%ebx
    5baf:	45 85 e4             	test   %r12d,%r12d
    5bb2:	75 2c                	jne    5be0 <fwp_apply+0x70>
    5bb4:	41 39 dd             	cmp    %ebx,%r13d
    5bb7:	72 27                	jb     5be0 <fwp_apply+0x70>
    5bb9:	85 db                	test   %ebx,%ebx
    5bbb:	0f 84 a7 01 00 00    	je     5d68 <fwp_apply+0x1f8>
    5bc1:	4c 89 f7             	mov    %r14,%rdi
    5bc4:	41 ff 51 08          	call   *0x8(%r9)
    5bc8:	48 89 c1             	mov    %rax,%rcx
    5bcb:	41 39 dd             	cmp    %ebx,%r13d
    5bce:	0f 84 6c 01 00 00    	je     5d40 <fwp_apply+0x1d0>
    5bd4:	89 d8                	mov    %ebx,%eax
    5bd6:	41 29 dd             	sub    %ebx,%r13d
    5bd9:	4d 8d 34 c6          	lea    (%r14,%rax,8),%r14
    5bdd:	eb b8                	jmp    5b97 <fwp_apply+0x27>
    5bdf:	90                   	nop
    5be0:	47 8d 7c 25 00       	lea    0x0(%r13,%r12,1),%r15d
    5be5:	41 39 df             	cmp    %ebx,%r15d
    5be8:	0f 82 cc 00 00 00    	jb     5cba <fwp_apply+0x14a>
    5bee:	41 89 df             	mov    %ebx,%r15d
    5bf1:	b8 01 00 00 00       	mov    $0x1,%eax
    5bf6:	48 89 e2             	mov    %rsp,%rdx
    5bf9:	45 29 e7             	sub    %r12d,%r15d
    5bfc:	85 db                	test   %ebx,%ebx
    5bfe:	0f 45 c3             	cmovne %ebx,%eax
    5c01:	48 8d 04 c5 0f 00 00 	lea    0xf(,%rax,8),%rax
    5c08:	00 
    5c09:	48 c1 e8 04          	shr    $0x4,%rax
    5c0d:	48 c1 e0 04          	shl    $0x4,%rax
    5c11:	48 89 c6             	mov    %rax,%rsi
    5c14:	48 81 e6 00 f0 ff ff 	and    $0xfffffffffffff000,%rsi
    5c1b:	48 29 f2             	sub    %rsi,%rdx
    5c1e:	48 39 d4             	cmp    %rdx,%rsp
    5c21:	74 15                	je     5c38 <fwp_apply+0xc8>
    5c23:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
    5c2a:	48 83 8c 24 f8 0f 00 	orq    $0x0,0xff8(%rsp)
    5c31:	00 00 
    5c33:	48 39 d4             	cmp    %rdx,%rsp
    5c36:	75 eb                	jne    5c23 <fwp_apply+0xb3>
    5c38:	25 ff 0f 00 00       	and    $0xfff,%eax
    5c3d:	48 29 c4             	sub    %rax,%rsp
    5c40:	48 85 c0             	test   %rax,%rax
    5c43:	0f 85 49 01 00 00    	jne    5d92 <fwp_apply+0x222>
    5c49:	45 89 e2             	mov    %r12d,%r10d
    5c4c:	48 89 e6             	mov    %rsp,%rsi
    5c4f:	48 89 e7             	mov    %rsp,%rdi
    5c52:	31 c0                	xor    %eax,%eax
    5c54:	49 c1 e2 03          	shl    $0x3,%r10
    5c58:	45 85 e4             	test   %r12d,%r12d
    5c5b:	74 15                	je     5c72 <fwp_apply+0x102>
    5c5d:	0f 1f 00             	nopl   (%rax)
    5c60:	48 8b 54 01 08       	mov    0x8(%rcx,%rax,1),%rdx
    5c65:	48 89 14 06          	mov    %rdx,(%rsi,%rax,1)
    5c69:	48 83 c0 08          	add    $0x8,%rax
    5c6d:	4c 39 d0             	cmp    %r10,%rax
    5c70:	75 ee                	jne    5c60 <fwp_apply+0xf0>
    5c72:	45 85 ff             	test   %r15d,%r15d
    5c75:	0f 84 f4 00 00 00    	je     5d6f <fwp_apply+0x1ff>
    5c7b:	44 89 fa             	mov    %r15d,%edx
    5c7e:	4c 89 f0             	mov    %r14,%rax
    5c81:	4d 8d 1c d6          	lea    (%r14,%rdx,8),%r11
    5c85:	44 89 e2             	mov    %r12d,%edx
    5c88:	66 90                	xchg   %ax,%ax
    5c8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c91:	00 00 00 00 
    5c95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5c9c:	00 00 00 00 
    5ca0:	4c 8b 10             	mov    (%rax),%r10
    5ca3:	89 d1                	mov    %edx,%ecx
    5ca5:	48 83 c0 08          	add    $0x8,%rax
    5ca9:	83 c2 01             	add    $0x1,%edx
    5cac:	4c 89 14 ce          	mov    %r10,(%rsi,%rcx,8)
    5cb0:	4c 39 d8             	cmp    %r11,%rax
    5cb3:	75 eb                	jne    5ca0 <fwp_apply+0x130>
    5cb5:	e9 b5 00 00 00       	jmp    5d6f <fwp_apply+0x1ff>
    5cba:	41 8d 7f 01          	lea    0x1(%r15),%edi
    5cbe:	be 02 00 00 00       	mov    $0x2,%esi
    5cc3:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
    5cc7:	48 c1 e7 03          	shl    $0x3,%rdi
    5ccb:	e8 80 fd ff ff       	call   5a50 <fwp_heap_alloc>
    5cd0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
    5cd4:	66 41 0f 6e cf       	movd   %r15d,%xmm1
    5cd9:	48 89 c3             	mov    %rax,%rbx
    5cdc:	66 0f 6e 01          	movd   (%rcx),%xmm0
    5ce0:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    5ce4:	66 0f d6 00          	movq   %xmm0,(%rax)
    5ce8:	45 85 e4             	test   %r12d,%r12d
    5ceb:	74 14                	je     5d01 <fwp_apply+0x191>
    5ced:	44 89 e2             	mov    %r12d,%edx
    5cf0:	48 8d 71 08          	lea    0x8(%rcx),%rsi
    5cf4:	48 8d 78 08          	lea    0x8(%rax),%rdi
    5cf8:	48 c1 e2 03          	shl    $0x3,%rdx
    5cfc:	e8 0f d9 ff ff       	call   3610 <memmove@plt>
    5d01:	4b 8d 0c ee          	lea    (%r14,%r13,8),%rcx
    5d05:	45 85 ed             	test   %r13d,%r13d
    5d08:	74 2e                	je     5d38 <fwp_apply+0x1c8>
    5d0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d11:	00 00 00 00 
    5d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5d1c:	00 00 00 00 
    5d20:	49 8b 16             	mov    (%r14),%rdx
    5d23:	44 89 e0             	mov    %r12d,%eax
    5d26:	49 83 c6 08          	add    $0x8,%r14
    5d2a:	41 83 c4 01          	add    $0x1,%r12d
    5d2e:	48 89 54 c3 08       	mov    %rdx,0x8(%rbx,%rax,8)
    5d33:	49 39 ce             	cmp    %rcx,%r14
    5d36:	75 e8                	jne    5d20 <fwp_apply+0x1b0>
    5d38:	48 89 d9             	mov    %rbx,%rcx
    5d3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5d40:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
    5d44:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    5d4b:	00 00 
    5d4d:	75 4e                	jne    5d9d <fwp_apply+0x22d>
    5d4f:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
    5d53:	48 89 c8             	mov    %rcx,%rax
    5d56:	5b                   	pop    %rbx
    5d57:	41 5c                	pop    %r12
    5d59:	41 5d                	pop    %r13
    5d5b:	41 5e                	pop    %r14
    5d5d:	41 5f                	pop    %r15
    5d5f:	5d                   	pop    %rbp
    5d60:	c3                   	ret
    5d61:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5d68:	45 31 ff             	xor    %r15d,%r15d
    5d6b:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
    5d6f:	4c 89 45 b8          	mov    %r8,-0x48(%rbp)
    5d73:	41 ff 51 08          	call   *0x8(%r9)
    5d77:	48 89 c1             	mov    %rax,%rcx
    5d7a:	45 39 fd             	cmp    %r15d,%r13d
    5d7d:	74 c1                	je     5d40 <fwp_apply+0x1d0>
    5d7f:	45 01 e5             	add    %r12d,%r13d
    5d82:	4f 8d 34 fe          	lea    (%r14,%r15,8),%r14
    5d86:	48 8b 65 b8          	mov    -0x48(%rbp),%rsp
    5d8a:	41 29 dd             	sub    %ebx,%r13d
    5d8d:	e9 05 fe ff ff       	jmp    5b97 <fwp_apply+0x27>
    5d92:	48 83 4c 04 f8 00    	orq    $0x0,-0x8(%rsp,%rax,1)
    5d98:	e9 ac fe ff ff       	jmp    5c49 <fwp_apply+0xd9>
    5d9d:	e8 be d6 ff ff       	call   3460 <__stack_chk_fail@plt>
    5da2:	0f 1f 00             	nopl   (%rax)
    5da5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5dac:	00 00 00 00 

0000000000005db0 <fwp_tape_reserve>:
    5db0:	41 57                	push   %r15
    5db2:	41 56                	push   %r14
    5db4:	41 55                	push   %r13
    5db6:	41 54                	push   %r12
    5db8:	55                   	push   %rbp
    5db9:	53                   	push   %rbx
    5dba:	48 83 ec 18          	sub    $0x18,%rsp
    5dbe:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    5dc5:	0f 87 d3 01 00 00    	ja     5f9e <fwp_tape_reserve+0x1ee>
    5dcb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    5dcf:	48 89 fd             	mov    %rdi,%rbp
    5dd2:	48 39 f3             	cmp    %rsi,%rbx
    5dd5:	0f 8d 13 01 00 00    	jge    5eee <fwp_tape_reserve+0x13e>
    5ddb:	48 85 db             	test   %rbx,%rbx
    5dde:	b8 40 00 00 00       	mov    $0x40,%eax
    5de3:	48 0f 44 d8          	cmove  %rax,%rbx
    5de7:	48 39 f3             	cmp    %rsi,%rbx
    5dea:	7d 24                	jge    5e10 <fwp_tape_reserve+0x60>
    5dec:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    5df3:	0f 8f 07 01 00 00    	jg     5f00 <fwp_tape_reserve+0x150>
    5df9:	48 01 db             	add    %rbx,%rbx
    5dfc:	48 39 f3             	cmp    %rsi,%rbx
    5dff:	7c eb                	jl     5dec <fwp_tape_reserve+0x3c>
    5e01:	0f 1f 40 00          	nopl   0x0(%rax)
    5e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5e0c:	00 00 00 00 
    5e10:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    5e17:	00 
    5e18:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5e1c:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    5e20:	4c 89 ee             	mov    %r13,%rsi
    5e23:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    5e27:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    5e2b:	e8 a0 d7 ff ff       	call   35d0 <realloc@plt>
    5e30:	48 85 c0             	test   %rax,%rax
    5e33:	0f 84 71 01 00 00    	je     5faa <fwp_tape_reserve+0x1fa>
    5e39:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5e3d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5e41:	4d 29 fc             	sub    %r15,%r12
    5e44:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    5e48:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    5e4c:	4d 85 f6             	test   %r14,%r14
    5e4f:	0f 84 03 01 00 00    	je     5f58 <fwp_tape_reserve+0x1a8>
    5e55:	49 8b 56 60          	mov    0x60(%r14),%rdx
    5e59:	48 39 da             	cmp    %rbx,%rdx
    5e5c:	7d 78                	jge    5ed6 <fwp_tape_reserve+0x126>
    5e5e:	48 89 d9             	mov    %rbx,%rcx
    5e61:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    5e65:	be 02 00 00 00       	mov    $0x2,%esi
    5e6a:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5e6f:	48 c1 e1 04          	shl    $0x4,%rcx
    5e73:	48 89 cf             	mov    %rcx,%rdi
    5e76:	48 89 0c 24          	mov    %rcx,(%rsp)
    5e7a:	e8 d1 fb ff ff       	call   5a50 <fwp_heap_alloc>
    5e7f:	49 89 c5             	mov    %rax,%r13
    5e82:	4d 85 ff             	test   %r15,%r15
    5e85:	74 27                	je     5eae <fwp_tape_reserve+0xfe>
    5e87:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5e8c:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e90:	48 89 c7             	mov    %rax,%rdi
    5e93:	4c 89 fe             	mov    %r15,%rsi
    5e96:	48 c1 e2 04          	shl    $0x4,%rdx
    5e9a:	48 39 ca             	cmp    %rcx,%rdx
    5e9d:	48 0f 47 d1          	cmova  %rcx,%rdx
    5ea1:	e8 fa d6 ff ff       	call   35a0 <memcpy@plt>
    5ea6:	4c 89 ff             	mov    %r15,%rdi
    5ea9:	e8 a2 f6 ff ff       	call   5550 <fwp_mem_free>
    5eae:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    5eb2:	48 89 da             	mov    %rbx,%rdx
    5eb5:	31 f6                	xor    %esi,%esi
    5eb7:	48 29 fa             	sub    %rdi,%rdx
    5eba:	48 c1 e7 04          	shl    $0x4,%rdi
    5ebe:	48 c1 e2 04          	shl    $0x4,%rdx
    5ec2:	4c 01 ef             	add    %r13,%rdi
    5ec5:	e8 f6 d5 ff ff       	call   34c0 <memset@plt>
    5eca:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    5ece:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5ed2:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    5ed6:	4d 85 e4             	test   %r12,%r12
    5ed9:	75 55                	jne    5f30 <fwp_tape_reserve+0x180>
    5edb:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5ee2:	00 
    5ee3:	4c 01 e8             	add    %r13,%rax
    5ee6:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    5eea:	48 89 45 28          	mov    %rax,0x28(%rbp)
    5eee:	48 83 c4 18          	add    $0x18,%rsp
    5ef2:	5b                   	pop    %rbx
    5ef3:	5d                   	pop    %rbp
    5ef4:	41 5c                	pop    %r12
    5ef6:	41 5d                	pop    %r13
    5ef8:	41 5e                	pop    %r14
    5efa:	41 5f                	pop    %r15
    5efc:	c3                   	ret
    5efd:	0f 1f 00             	nopl   (%rax)
    5f00:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    5f05:	e9 06 ff ff ff       	jmp    5e10 <fwp_tape_reserve+0x60>
    5f0a:	4d 39 f5             	cmp    %r14,%r13
    5f0d:	4c 89 f1             	mov    %r14,%rcx
    5f10:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    5f17:	00 
    5f18:	49 0f 43 cd          	cmovae %r13,%rcx
    5f1c:	4c 29 e9             	sub    %r13,%rcx
    5f1f:	e8 3c d6 ff ff       	call   3560 <__memmove_chk@plt>
    5f24:	4c 03 6d 30          	add    0x30(%rbp),%r13
    5f28:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f2c:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    5f30:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    5f34:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5f3b:	00 
    5f3c:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    5f43:	00 
    5f44:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5f48:	e8 c3 d6 ff ff       	call   3610 <memmove@plt>
    5f4d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f51:	eb 90                	jmp    5ee3 <fwp_tape_reserve+0x133>
    5f53:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5f58:	49 89 de             	mov    %rbx,%r14
    5f5b:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5f5f:	49 c1 e6 04          	shl    $0x4,%r14
    5f63:	4c 89 f6             	mov    %r14,%rsi
    5f66:	e8 65 d6 ff ff       	call   35d0 <realloc@plt>
    5f6b:	48 85 c0             	test   %rax,%rax
    5f6e:	74 3a                	je     5faa <fwp_tape_reserve+0x1fa>
    5f70:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    5f74:	48 89 45 30          	mov    %rax,0x30(%rbp)
    5f78:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    5f7c:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    5f80:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    5f84:	4d 85 e4             	test   %r12,%r12
    5f87:	75 81                	jne    5f0a <fwp_tape_reserve+0x15a>
    5f89:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    5f8d:	48 8b 45 20          	mov    0x20(%rbp),%rax
    5f91:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    5f98:	00 
    5f99:	e9 45 ff ff ff       	jmp    5ee3 <fwp_tape_reserve+0x133>
    5f9e:	48 8d 3d 44 61 00 00 	lea    0x6144(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    5fa5:	e8 f6 e1 ff ff       	call   41a0 <fwp_trap>
    5faa:	48 89 ef             	mov    %rbp,%rdi
    5fad:	e8 4e dc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    5fb2:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    5fb6:	e8 05 d4 ff ff       	call   33c0 <free@plt>
    5fbb:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    5fbf:	e8 fc d3 ff ff       	call   33c0 <free@plt>
    5fc4:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    5fc8:	e8 f3 d3 ff ff       	call   33c0 <free@plt>
    5fcd:	31 c9                	xor    %ecx,%ecx
    5fcf:	31 c0                	xor    %eax,%eax
    5fd1:	31 d2                	xor    %edx,%edx
    5fd3:	89 55 04             	mov    %edx,0x4(%rbp)
    5fd6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fda:	ba 13 00 00 00       	mov    $0x13,%edx
    5fdf:	be 01 00 00 00       	mov    $0x1,%esi
    5fe4:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    5fe8:	48 8d 3d 19 60 00 00 	lea    0x6019(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    5fef:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    5ff3:	48 8b 0d 46 a0 00 00 	mov    0xa046(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    5ffa:	48 89 45 40          	mov    %rax,0x40(%rbp)
    5ffe:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    6002:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    6006:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    600a:	e8 71 d6 ff ff       	call   3680 <fwrite@plt>
    600f:	31 ff                	xor    %edi,%edi
    6011:	e8 aa d5 ff ff       	call   35c0 <fflush@plt>
    6016:	bf 66 00 00 00       	mov    $0x66,%edi
    601b:	e8 80 d6 ff ff       	call   36a0 <_Exit@plt>

0000000000006020 <f128.constprop.0>:
    6020:	41 57                	push   %r15
    6022:	41 56                	push   %r14
    6024:	41 55                	push   %r13
    6026:	41 54                	push   %r12
    6028:	49 89 f4             	mov    %rsi,%r12
    602b:	55                   	push   %rbp
    602c:	48 89 fd             	mov    %rdi,%rbp
    602f:	53                   	push   %rbx
    6030:	48 83 ec 08          	sub    $0x8,%rsp
    6034:	48 85 ff             	test   %rdi,%rdi
    6037:	79 09                	jns    6042 <f128.constprop.0+0x22>
    6039:	48 85 f6             	test   %rsi,%rsi
    603c:	0f 88 fe 00 00 00    	js     6140 <f128.constprop.0+0x120>
    6042:	48 89 f8             	mov    %rdi,%rax
    6045:	48 09 f0             	or     %rsi,%rax
    6048:	0f 89 d2 00 00 00    	jns    6120 <f128.constprop.0+0x100>
    604e:	48 89 f8             	mov    %rdi,%rax
    6051:	48 c1 f8 20          	sar    $0x20,%rax
    6055:	48 85 ff             	test   %rdi,%rdi
    6058:	0f 88 02 01 00 00    	js     6160 <f128.constprop.0+0x140>
    605e:	4c 8b 3d cb 6a 00 00 	mov    0x6acb(%rip),%r15        # cb30 <msg.4+0xb0>
    6065:	48 89 c7             	mov    %rax,%rdi
    6068:	e8 13 e4 ff ff       	call   4480 <fwp_tape_of>
    606d:	48 89 c3             	mov    %rax,%rbx
    6070:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6075:	0f 85 16 01 00 00    	jne    6191 <f128.constprop.0+0x171>
    607b:	4c 8b 68 10          	mov    0x10(%rax),%r13
    607f:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6086:	0f 8f f9 00 00 00    	jg     6185 <f128.constprop.0+0x165>
    608c:	89 e8                	mov    %ebp,%eax
    608e:	49 39 c5             	cmp    %rax,%r13
    6091:	0f 8e e2 00 00 00    	jle    6179 <f128.constprop.0+0x159>
    6097:	4d 85 e4             	test   %r12,%r12
    609a:	78 0c                	js     60a8 <f128.constprop.0+0x88>
    609c:	44 89 e0             	mov    %r12d,%eax
    609f:	49 39 c5             	cmp    %rax,%r13
    60a2:	0f 8e d1 00 00 00    	jle    6179 <f128.constprop.0+0x159>
    60a8:	4d 89 ee             	mov    %r13,%r14
    60ab:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    60af:	48 89 df             	mov    %rbx,%rdi
    60b2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    60b6:	e8 f5 fc ff ff       	call   5db0 <fwp_tape_reserve>
    60bb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    60bf:	4d 85 e4             	test   %r12,%r12
    60c2:	48 8b 0d 67 6a 00 00 	mov    0x6a67(%rip),%rcx        # cb30 <msg.4+0xb0>
    60c9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    60d0:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    60d4:	48 8b 43 30          	mov    0x30(%rbx),%rax
    60d8:	4c 0f 48 e2          	cmovs  %rdx,%r12
    60dc:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    60e0:	48 8b 43 28          	mov    0x28(%rbx),%rax
    60e4:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    60e8:	48 8b 43 38          	mov    0x38(%rbx),%rax
    60ec:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    60f0:	49 8d 45 01          	lea    0x1(%r13),%rax
    60f4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    60f8:	48 83 c4 08          	add    $0x8,%rsp
    60fc:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6103:	ff ff ff 
    6106:	48 21 e8             	and    %rbp,%rax
    6109:	5b                   	pop    %rbx
    610a:	5d                   	pop    %rbp
    610b:	4c 09 e8             	or     %r13,%rax
    610e:	41 5c                	pop    %r12
    6110:	41 5d                	pop    %r13
    6112:	41 5e                	pop    %r14
    6114:	41 5f                	pop    %r15
    6116:	c3                   	ret
    6117:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    611e:	00 00 
    6120:	48 89 f0             	mov    %rsi,%rax
    6123:	48 c1 ff 20          	sar    $0x20,%rdi
    6127:	48 c1 f8 20          	sar    $0x20,%rax
    612b:	48 39 c7             	cmp    %rax,%rdi
    612e:	0f 84 2a ff ff ff    	je     605e <f128.constprop.0+0x3e>
    6134:	48 8d 3d 85 66 00 00 	lea    0x6685(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    613b:	e8 60 e0 ff ff       	call   41a0 <fwp_trap>
    6140:	48 83 c4 08          	add    $0x8,%rsp
    6144:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    614b:	5b                   	pop    %rbx
    614c:	5d                   	pop    %rbp
    614d:	41 5c                	pop    %r12
    614f:	41 5d                	pop    %r13
    6151:	41 5e                	pop    %r14
    6153:	41 5f                	pop    %r15
    6155:	c3                   	ret
    6156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    615d:	00 00 00 
    6160:	48 89 f0             	mov    %rsi,%rax
    6163:	48 89 f5             	mov    %rsi,%rbp
    6166:	45 31 ff             	xor    %r15d,%r15d
    6169:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6170:	48 c1 f8 20          	sar    $0x20,%rax
    6174:	e9 ec fe ff ff       	jmp    6065 <f128.constprop.0+0x45>
    6179:	48 8d 3d 84 5f 00 00 	lea    0x5f84(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    6180:	e8 1b e0 ff ff       	call   41a0 <fwp_trap>
    6185:	48 8d 3d 5d 5f 00 00 	lea    0x5f5d(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    618c:	e8 0f e0 ff ff       	call   41a0 <fwp_trap>
    6191:	48 8d 3d 70 66 00 00 	lea    0x6670(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    6198:	e8 03 e0 ff ff       	call   41a0 <fwp_trap>
    619d:	0f 1f 00             	nopl   (%rax)

00000000000061a0 <w107>:
    61a0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    61a4:	41 57                	push   %r15
    61a6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    61aa:	41 56                	push   %r14
    61ac:	41 55                	push   %r13
    61ae:	41 54                	push   %r12
    61b0:	49 89 f4             	mov    %rsi,%r12
    61b3:	55                   	push   %rbp
    61b4:	48 89 fd             	mov    %rdi,%rbp
    61b7:	53                   	push   %rbx
    61b8:	48 83 ec 38          	sub    $0x38,%rsp
    61bc:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    61c1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    61c7:	48 85 ff             	test   %rdi,%rdi
    61ca:	0f 88 d0 04 00 00    	js     66a0 <w107+0x500>
    61d0:	49 89 ff             	mov    %rdi,%r15
    61d3:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    61d9:	49 c1 ff 20          	sar    $0x20,%r15
    61dd:	4c 89 ff             	mov    %r15,%rdi
    61e0:	e8 9b e2 ff ff       	call   4480 <fwp_tape_of>
    61e5:	48 89 c3             	mov    %rax,%rbx
    61e8:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    61ed:	0f 85 45 05 00 00    	jne    6738 <w107+0x598>
    61f3:	4c 8b 68 10          	mov    0x10(%rax),%r13
    61f7:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    61fe:	0f 8f 28 05 00 00    	jg     672c <w107+0x58c>
    6204:	89 e8                	mov    %ebp,%eax
    6206:	49 39 c5             	cmp    %rax,%r13
    6209:	0f 8e 11 05 00 00    	jle    6720 <w107+0x580>
    620f:	4d 89 ee             	mov    %r13,%r14
    6212:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6216:	48 89 df             	mov    %rbx,%rdi
    6219:	49 8d 76 01          	lea    0x1(%r14),%rsi
    621d:	e8 8e fb ff ff       	call   5db0 <fwp_tape_reserve>
    6222:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6226:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    622b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6231:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6235:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6239:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    623f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6243:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6247:	48 8b 43 38          	mov    0x38(%rbx),%rax
    624b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6251:	49 8d 45 01          	lea    0x1(%r13),%rax
    6255:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    625c:	ff ff ff 
    625f:	49 21 ee             	and    %rbp,%r14
    6262:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6266:	4d 09 ee             	or     %r13,%r14
    6269:	4d 89 f5             	mov    %r14,%r13
    626c:	49 c1 fd 20          	sar    $0x20,%r13
    6270:	4d 85 e4             	test   %r12,%r12
    6273:	78 10                	js     6285 <w107+0xe5>
    6275:	4c 89 e0             	mov    %r12,%rax
    6278:	48 c1 f8 20          	sar    $0x20,%rax
    627c:	4c 39 e8             	cmp    %r13,%rax
    627f:	0f 85 87 04 00 00    	jne    670c <w107+0x56c>
    6285:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    628b:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6291:	4d 39 ef             	cmp    %r13,%r15
    6294:	0f 84 d6 03 00 00    	je     6670 <w107+0x4d0>
    629a:	f2 0f 10 1d 8e 68 00 	movsd  0x688e(%rip),%xmm3        # cb30 <msg.4+0xb0>
    62a1:	00 
    62a2:	f2 0f 10 25 8e 68 00 	movsd  0x688e(%rip),%xmm4        # cb38 <msg.4+0xb8>
    62a9:	00 
    62aa:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    62b0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    62b6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    62bc:	4c 89 ef             	mov    %r13,%rdi
    62bf:	e8 bc e1 ff ff       	call   4480 <fwp_tape_of>
    62c4:	48 89 c3             	mov    %rax,%rbx
    62c7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    62cc:	0f 85 66 04 00 00    	jne    6738 <w107+0x598>
    62d2:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    62d6:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    62dd:	0f 8f 49 04 00 00    	jg     672c <w107+0x58c>
    62e3:	44 89 f0             	mov    %r14d,%eax
    62e6:	49 39 c7             	cmp    %rax,%r15
    62e9:	0f 8e 31 04 00 00    	jle    6720 <w107+0x580>
    62ef:	4d 85 e4             	test   %r12,%r12
    62f2:	78 0c                	js     6300 <w107+0x160>
    62f4:	44 89 e0             	mov    %r12d,%eax
    62f7:	49 39 c7             	cmp    %rax,%r15
    62fa:	0f 8e 20 04 00 00    	jle    6720 <w107+0x580>
    6300:	4c 89 f9             	mov    %r15,%rcx
    6303:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6307:	48 89 df             	mov    %rbx,%rdi
    630a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    630e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6313:	e8 98 fa ff ff       	call   5db0 <fwp_tape_reserve>
    6318:	48 8b 43 20          	mov    0x20(%rbx),%rax
    631c:	4d 85 e4             	test   %r12,%r12
    631f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6323:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6328:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    632e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6334:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6338:	48 8b 43 30          	mov    0x30(%rbx),%rax
    633c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6341:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6348:	49 0f 49 c4          	cmovns %r12,%rax
    634c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6350:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6353:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6357:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    635c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6360:	48 85 ed             	test   %rbp,%rbp
    6363:	0f 88 0e 04 00 00    	js     6777 <w107+0x5d7>
    6369:	48 89 e8             	mov    %rbp,%rax
    636c:	48 c1 f8 20          	sar    $0x20,%rax
    6370:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    6375:	49 39 c5             	cmp    %rax,%r13
    6378:	74 1a                	je     6394 <w107+0x1f4>
    637a:	48 89 c7             	mov    %rax,%rdi
    637d:	e8 fe e0 ff ff       	call   4480 <fwp_tape_of>
    6382:	48 89 c3             	mov    %rax,%rbx
    6385:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    638a:	0f 85 a8 03 00 00    	jne    6738 <w107+0x598>
    6390:	4c 8b 60 10          	mov    0x10(%rax),%r12
    6394:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    639b:	0f 8f 8b 03 00 00    	jg     672c <w107+0x58c>
    63a1:	89 e8                	mov    %ebp,%eax
    63a3:	4c 39 e0             	cmp    %r12,%rax
    63a6:	0f 8d 74 03 00 00    	jge    6720 <w107+0x580>
    63ac:	4c 89 e0             	mov    %r12,%rax
    63af:	48 2b 43 08          	sub    0x8(%rbx),%rax
    63b3:	48 89 df             	mov    %rbx,%rdi
    63b6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    63ba:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    63bf:	e8 ec f9 ff ff       	call   5db0 <fwp_tape_reserve>
    63c4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    63c9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    63cd:	48 8b 0d 64 67 00 00 	mov    0x6764(%rip),%rcx        # cb38 <msg.4+0xb8>
    63d4:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    63da:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    63dd:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    63e1:	66 0f 28 ee          	movapd %xmm6,%xmm5
    63e5:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    63eb:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    63ef:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    63f3:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    63f7:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    63fe:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6402:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6407:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    640c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6410:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6417:	ff ff ff 
    641a:	48 21 c5             	and    %rax,%rbp
    641d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6423:	4c 09 e5             	or     %r12,%rbp
    6426:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    642d:	ff ff ff 
    6430:	49 21 c6             	and    %rax,%r14
    6433:	4d 09 fe             	or     %r15,%r14
    6436:	4d 89 f4             	mov    %r14,%r12
    6439:	49 c1 fc 20          	sar    $0x20,%r12
    643d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6442:	74 16                	je     645a <w107+0x2ba>
    6444:	4c 89 e7             	mov    %r12,%rdi
    6447:	e8 34 e0 ff ff       	call   4480 <fwp_tape_of>
    644c:	48 89 c3             	mov    %rax,%rbx
    644f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6454:	0f 85 de 02 00 00    	jne    6738 <w107+0x598>
    645a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    645e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6465:	0f 8f c1 02 00 00    	jg     672c <w107+0x58c>
    646b:	44 89 f0             	mov    %r14d,%eax
    646e:	49 39 c7             	cmp    %rax,%r15
    6471:	0f 8e a9 02 00 00    	jle    6720 <w107+0x580>
    6477:	4d 89 fd             	mov    %r15,%r13
    647a:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    647e:	48 89 df             	mov    %rbx,%rdi
    6481:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6485:	e8 26 f9 ff ff       	call   5db0 <fwp_tape_reserve>
    648a:	48 8b 43 20          	mov    0x20(%rbx),%rax
    648e:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    6494:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    6498:	48 8b 43 30          	mov    0x30(%rbx),%rax
    649c:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    64a2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    64a6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    64aa:	48 8b 43 38          	mov    0x38(%rbx),%rax
    64ae:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    64b4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    64b8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    64bf:	ff ff ff 
    64c2:	49 21 c6             	and    %rax,%r14
    64c5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    64c9:	4d 09 fe             	or     %r15,%r14
    64cc:	4d 89 f7             	mov    %r14,%r15
    64cf:	49 c1 ff 20          	sar    $0x20,%r15
    64d3:	4d 39 e7             	cmp    %r12,%r15
    64d6:	74 1d                	je     64f5 <w107+0x355>
    64d8:	4c 89 ff             	mov    %r15,%rdi
    64db:	e8 a0 df ff ff       	call   4480 <fwp_tape_of>
    64e0:	48 89 c3             	mov    %rax,%rbx
    64e3:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    64e8:	0f 85 4a 02 00 00    	jne    6738 <w107+0x598>
    64ee:	4c 8b 68 10          	mov    0x10(%rax),%r13
    64f2:	4d 89 fc             	mov    %r15,%r12
    64f5:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    64fc:	0f 8f 2a 02 00 00    	jg     672c <w107+0x58c>
    6502:	44 89 f0             	mov    %r14d,%eax
    6505:	4c 39 e8             	cmp    %r13,%rax
    6508:	0f 8d 12 02 00 00    	jge    6720 <w107+0x580>
    650e:	f2 0f 10 3d 2a 66 00 	movsd  0x662a(%rip),%xmm7        # cb40 <msg.4+0xc0>
    6515:	00 
    6516:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    651c:	4d 89 ef             	mov    %r13,%r15
    651f:	48 89 df             	mov    %rbx,%rdi
    6522:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6528:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    652d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6531:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6535:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    653a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6540:	e8 6b f8 ff ff       	call   5db0 <fwp_tape_reserve>
    6545:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6549:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    654e:	48 8b 15 eb 65 00 00 	mov    0x65eb(%rip),%rdx        # cb40 <msg.4+0xc0>
    6555:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6559:	48 8b 43 30          	mov    0x30(%rbx),%rax
    655d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6561:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6565:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6569:	48 8b 43 28          	mov    0x28(%rbx),%rax
    656d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6574:	ff 
    6575:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6579:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6580:	00 
    6581:	49 8d 45 01          	lea    0x1(%r13),%rax
    6585:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6589:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6590:	ff ff ff 
    6593:	49 21 c6             	and    %rax,%r14
    6596:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    659c:	4d 09 ee             	or     %r13,%r14
    659f:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    65a3:	0f 84 57 01 00 00    	je     6700 <w107+0x560>
    65a9:	48 89 ef             	mov    %rbp,%rdi
    65ac:	48 c1 ff 20          	sar    $0x20,%rdi
    65b0:	4c 39 e7             	cmp    %r12,%rdi
    65b3:	74 13                	je     65c8 <w107+0x428>
    65b5:	e8 c6 de ff ff       	call   4480 <fwp_tape_of>
    65ba:	48 89 c3             	mov    %rax,%rbx
    65bd:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65c2:	0f 85 70 01 00 00    	jne    6738 <w107+0x598>
    65c8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    65cc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    65d3:	0f 8f 53 01 00 00    	jg     672c <w107+0x58c>
    65d9:	89 e8                	mov    %ebp,%eax
    65db:	4c 39 e0             	cmp    %r12,%rax
    65de:	0f 8d 3c 01 00 00    	jge    6720 <w107+0x580>
    65e4:	4d 89 e5             	mov    %r12,%r13
    65e7:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    65eb:	48 89 df             	mov    %rbx,%rdi
    65ee:	49 8d 75 01          	lea    0x1(%r13),%rsi
    65f2:	e8 b9 f7 ff ff       	call   5db0 <fwp_tape_reserve>
    65f7:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65fb:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6600:	48 89 ef             	mov    %rbp,%rdi
    6603:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6607:	48 8b 43 30          	mov    0x30(%rbx),%rax
    660b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6611:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6615:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6619:	48 8b 43 38          	mov    0x38(%rbx),%rax
    661d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6623:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6628:	48 89 43 10          	mov    %rax,0x10(%rbx)
    662c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6633:	ff ff ff 
    6636:	48 21 c7             	and    %rax,%rdi
    6639:	4c 09 e7             	or     %r12,%rdi
    663c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6642:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6648:	4c 89 f6             	mov    %r14,%rsi
    664b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6650:	e8 cb f9 ff ff       	call   6020 <f128.constprop.0>
    6655:	48 83 c4 38          	add    $0x38,%rsp
    6659:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    665e:	5b                   	pop    %rbx
    665f:	5d                   	pop    %rbp
    6660:	41 5c                	pop    %r12
    6662:	41 5d                	pop    %r13
    6664:	41 5e                	pop    %r14
    6666:	41 5f                	pop    %r15
    6668:	c3                   	ret
    6669:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6670:	f2 0f 10 3d b8 64 00 	movsd  0x64b8(%rip),%xmm7        # cb30 <msg.4+0xb0>
    6677:	00 
    6678:	f2 0f 10 15 b8 64 00 	movsd  0x64b8(%rip),%xmm2        # cb38 <msg.4+0xb8>
    667f:	00 
    6680:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6686:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    668c:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6692:	e9 3b fc ff ff       	jmp    62d2 <w107+0x132>
    6697:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    669e:	00 00 
    66a0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    66a6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66ac:	48 85 f6             	test   %rsi,%rsi
    66af:	0f 89 8f 00 00 00    	jns    6744 <w107+0x5a4>
    66b5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    66bb:	f2 0f 10 05 6d 64 00 	movsd  0x646d(%rip),%xmm0        # cb30 <msg.4+0xb0>
    66c2:	00 
    66c3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    66ca:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    66d1:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    66d6:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    66da:	f2 0f 59 0d 5e 64 00 	mulsd  0x645e(%rip),%xmm1        # cb40 <msg.4+0xc0>
    66e1:	00 
    66e2:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    66e6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    66ec:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    66f2:	e9 45 ff ff ff       	jmp    663c <w107+0x49c>
    66f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    66fe:	00 00 
    6700:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6707:	e9 30 ff ff ff       	jmp    663c <w107+0x49c>
    670c:	48 8d 3d ad 60 00 00 	lea    0x60ad(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    6713:	e8 88 da ff ff       	call   41a0 <fwp_trap>
    6718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    671f:	00 
    6720:	48 8d 3d dd 59 00 00 	lea    0x59dd(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    6727:	e8 74 da ff ff       	call   41a0 <fwp_trap>
    672c:	48 8d 3d b6 59 00 00 	lea    0x59b6(%rip),%rdi        # c0e9 <_IO_stdin_used+0xe9>
    6733:	e8 68 da ff ff       	call   41a0 <fwp_trap>
    6738:	48 8d 3d c9 60 00 00 	lea    0x60c9(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    673f:	e8 5c da ff ff       	call   41a0 <fwp_trap>
    6744:	f2 0f 10 35 e4 63 00 	movsd  0x63e4(%rip),%xmm6        # cb30 <msg.4+0xb0>
    674b:	00 
    674c:	49 89 f5             	mov    %rsi,%r13
    674f:	49 89 f6             	mov    %rsi,%r14
    6752:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6759:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6760:	00 00 
    6762:	49 c1 fd 20          	sar    $0x20,%r13
    6766:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    676c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6772:	e9 45 fb ff ff       	jmp    62bc <w107+0x11c>
    6777:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    677d:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6782:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6789:	66 0f 28 f4          	movapd %xmm4,%xmm6
    678d:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6791:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6797:	e9 8a fc ff ff       	jmp    6426 <w107+0x286>
    679c:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000067a0 <fwp_data.part.0.constprop.0>:
    67a0:	41 56                	push   %r14
    67a2:	41 89 fe             	mov    %edi,%r14d
    67a5:	41 54                	push   %r12
    67a7:	49 89 f4             	mov    %rsi,%r12
    67aa:	55                   	push   %rbp
    67ab:	53                   	push   %rbx
    67ac:	48 83 ec 08          	sub    $0x8,%rsp
    67b0:	8b 05 4e b3 01 00    	mov    0x1b34e(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    67b6:	85 c0                	test   %eax,%eax
    67b8:	0f 84 fa 00 00 00    	je     68b8 <fwp_data.part.0.constprop.0+0x118>
    67be:	0f b6 05 3d af 01 00 	movzbl 0x1af3d(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    67c5:	48 8d 15 94 9f 01 00 	lea    0x19f94(%rip),%rdx        # 20760 <fwp_heap>
    67cc:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    67d3:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    67d7:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    67db:	48 8b 18             	mov    (%rax),%rbx
    67de:	48 85 db             	test   %rbx,%rbx
    67e1:	0f 84 a9 00 00 00    	je     6890 <fwp_data.part.0.constprop.0+0xf0>
    67e7:	48 8b 13             	mov    (%rbx),%rdx
    67ea:	48 f7 d2             	not    %rdx
    67ed:	48 89 10             	mov    %rdx,(%rax)
    67f0:	48 83 fd 18          	cmp    $0x18,%rbp
    67f4:	76 1b                	jbe    6811 <fwp_data.part.0.constprop.0+0x71>
    67f6:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    67fa:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    67fe:	31 f6                	xor    %esi,%esi
    6800:	48 c1 e8 03          	shr    $0x3,%rax
    6804:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    680b:	00 
    680c:	e8 af cc ff ff       	call   34c0 <memset@plt>
    6811:	48 89 e8             	mov    %rbp,%rax
    6814:	48 03 05 65 b3 01 00 	add    0x1b365(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    681b:	0f 82 a8 00 00 00    	jb     68c9 <fwp_data.part.0.constprop.0+0x129>
    6821:	48 39 05 60 b3 01 00 	cmp    %rax,0x1b360(%rip)        # 21b88 <fwp_heap+0x1428>
    6828:	48 89 05 51 b3 01 00 	mov    %rax,0x1b351(%rip)        # 21b80 <fwp_heap+0x1420>
    682f:	73 07                	jae    6838 <fwp_data.part.0.constprop.0+0x98>
    6831:	48 89 05 50 b3 01 00 	mov    %rax,0x1b350(%rip)        # 21b88 <fwp_heap+0x1428>
    6838:	66 0f ef c0          	pxor   %xmm0,%xmm0
    683c:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    6841:	f2 0f 58 05 4f b3 01 	addsd  0x1b34f(%rip),%xmm0        # 21b98 <fwp_heap+0x1438>
    6848:	00 
    6849:	f2 0f 11 05 47 b3 01 	movsd  %xmm0,0x1b347(%rip)        # 21b98 <fwp_heap+0x1438>
    6850:	00 
    6851:	b8 02 00 00 00       	mov    $0x2,%eax
    6856:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    685b:	66 0f 6e c8          	movd   %eax,%xmm1
    685f:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    6863:	66 0f d6 03          	movq   %xmm0,(%rbx)
    6867:	49 8b 04 24          	mov    (%r12),%rax
    686b:	48 89 43 08          	mov    %rax,0x8(%rbx)
    686f:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    6874:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6878:	48 83 c4 08          	add    $0x8,%rsp
    687c:	48 89 d8             	mov    %rbx,%rax
    687f:	5b                   	pop    %rbx
    6880:	5d                   	pop    %rbp
    6881:	41 5c                	pop    %r12
    6883:	41 5e                	pop    %r14
    6885:	c3                   	ret
    6886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    688d:	00 00 00 
    6890:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6894:	48 85 db             	test   %rbx,%rbx
    6897:	74 1f                	je     68b8 <fwp_data.part.0.constprop.0+0x118>
    6899:	48 8b 50 10          	mov    0x10(%rax),%rdx
    689d:	48 29 da             	sub    %rbx,%rdx
    68a0:	48 39 ea             	cmp    %rbp,%rdx
    68a3:	72 13                	jb     68b8 <fwp_data.part.0.constprop.0+0x118>
    68a5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    68a9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    68ad:	e9 3e ff ff ff       	jmp    67f0 <fwp_data.part.0.constprop.0+0x50>
    68b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    68b8:	31 f6                	xor    %esi,%esi
    68ba:	bf 18 00 00 00       	mov    $0x18,%edi
    68bf:	e8 8c f1 ff ff       	call   5a50 <fwp_heap_alloc>
    68c4:	48 89 c3             	mov    %rax,%rbx
    68c7:	eb 88                	jmp    6851 <fwp_data.part.0.constprop.0+0xb1>
    68c9:	e8 e2 d3 ff ff       	call   3cb0 <fwp_heap_oom>
    68ce:	66 90                	xchg   %ax,%ax

00000000000068d0 <fwp_rc_share>:
    68d0:	48 8b 05 61 b2 01 00 	mov    0x1b261(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    68d7:	48 2b 3d 32 b2 01 00 	sub    0x1b232(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    68de:	48 c1 e0 10          	shl    $0x10,%rax
    68e2:	48 39 c7             	cmp    %rax,%rdi
    68e5:	73 4a                	jae    6931 <fwp_rc_share+0x61>
    68e7:	48 89 f8             	mov    %rdi,%rax
    68ea:	48 c1 e8 10          	shr    $0x10,%rax
    68ee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    68f2:	48 8b 05 5f b2 01 00 	mov    0x1b25f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    68f9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    68fd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6901:	48 85 d2             	test   %rdx,%rdx
    6904:	74 2b                	je     6931 <fwp_rc_share+0x61>
    6906:	0f b6 08             	movzbl (%rax),%ecx
    6909:	80 f9 02             	cmp    $0x2,%cl
    690c:	74 2a                	je     6938 <fwp_rc_share+0x68>
    690e:	80 f9 01             	cmp    $0x1,%cl
    6911:	75 1e                	jne    6931 <fwp_rc_share+0x61>
    6913:	8b 48 18             	mov    0x18(%rax),%ecx
    6916:	0f b7 ff             	movzwl %di,%edi
    6919:	8b 40 1c             	mov    0x1c(%rax),%eax
    691c:	48 0f af f9          	imul   %rcx,%rdi
    6920:	48 c1 ef 20          	shr    $0x20,%rdi
    6924:	48 39 c7             	cmp    %rax,%rdi
    6927:	73 08                	jae    6931 <fwp_rc_share+0x61>
    6929:	48 01 fa             	add    %rdi,%rdx
    692c:	80 3a 00             	cmpb   $0x0,(%rdx)
    692f:	75 0d                	jne    693e <fwp_rc_share+0x6e>
    6931:	c3                   	ret
    6932:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6938:	66 85 ff             	test   %di,%di
    693b:	74 ef                	je     692c <fwp_rc_share+0x5c>
    693d:	c3                   	ret
    693e:	50                   	push   %rax
    693f:	48 8d 3d f2 5e 00 00 	lea    0x5ef2(%rip),%rdi        # c838 <_IO_stdin_used+0x838>
    6946:	e8 55 d8 ff ff       	call   41a0 <fwp_trap>
    694b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006950 <fwp_rc_free_arr>:
    6950:	48 8b 15 e1 b1 01 00 	mov    0x1b1e1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6957:	48 89 f8             	mov    %rdi,%rax
    695a:	48 2b 05 af b1 01 00 	sub    0x1b1af(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6961:	48 c1 e2 10          	shl    $0x10,%rdx
    6965:	48 39 d0             	cmp    %rdx,%rax
    6968:	73 5b                	jae    69c5 <fwp_rc_free_arr+0x75>
    696a:	48 89 c2             	mov    %rax,%rdx
    696d:	48 c1 ea 10          	shr    $0x10,%rdx
    6971:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6975:	48 8b 15 dc b1 01 00 	mov    0x1b1dc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    697c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6980:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6984:	48 85 c9             	test   %rcx,%rcx
    6987:	74 3c                	je     69c5 <fwp_rc_free_arr+0x75>
    6989:	0f b6 32             	movzbl (%rdx),%esi
    698c:	40 80 fe 02          	cmp    $0x2,%sil
    6990:	74 2e                	je     69c0 <fwp_rc_free_arr+0x70>
    6992:	40 80 fe 01          	cmp    $0x1,%sil
    6996:	75 2d                	jne    69c5 <fwp_rc_free_arr+0x75>
    6998:	8b 72 18             	mov    0x18(%rdx),%esi
    699b:	0f b7 c0             	movzwl %ax,%eax
    699e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    69a1:	48 0f af c6          	imul   %rsi,%rax
    69a5:	48 c1 e8 20          	shr    $0x20,%rax
    69a9:	48 39 d0             	cmp    %rdx,%rax
    69ac:	73 17                	jae    69c5 <fwp_rc_free_arr+0x75>
    69ae:	48 01 c1             	add    %rax,%rcx
    69b1:	80 39 01             	cmpb   $0x1,(%rcx)
    69b4:	75 0f                	jne    69c5 <fwp_rc_free_arr+0x75>
    69b6:	e9 95 eb ff ff       	jmp    5550 <fwp_mem_free>
    69bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    69c0:	66 85 c0             	test   %ax,%ax
    69c3:	74 ec                	je     69b1 <fwp_rc_free_arr+0x61>
    69c5:	c3                   	ret
    69c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    69cd:	00 00 00 

00000000000069d0 <fwp_rc_dup>:
    69d0:	f3 0f 1e fa          	endbr64
    69d4:	48 8b 05 5d b1 01 00 	mov    0x1b15d(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    69db:	48 2b 3d 2e b1 01 00 	sub    0x1b12e(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    69e2:	48 c1 e0 10          	shl    $0x10,%rax
    69e6:	48 39 c7             	cmp    %rax,%rdi
    69e9:	73 56                	jae    6a41 <fwp_rc_dup+0x71>
    69eb:	48 89 f8             	mov    %rdi,%rax
    69ee:	48 c1 e8 10          	shr    $0x10,%rax
    69f2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    69f6:	48 8b 05 5b b1 01 00 	mov    0x1b15b(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    69fd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6a01:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6a05:	48 85 c0             	test   %rax,%rax
    6a08:	74 37                	je     6a41 <fwp_rc_dup+0x71>
    6a0a:	0f b6 0a             	movzbl (%rdx),%ecx
    6a0d:	80 f9 02             	cmp    $0x2,%cl
    6a10:	74 36                	je     6a48 <fwp_rc_dup+0x78>
    6a12:	80 f9 01             	cmp    $0x1,%cl
    6a15:	75 2a                	jne    6a41 <fwp_rc_dup+0x71>
    6a17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6a1a:	0f b7 ff             	movzwl %di,%edi
    6a1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6a20:	48 0f af f9          	imul   %rcx,%rdi
    6a24:	48 c1 ef 20          	shr    $0x20,%rdi
    6a28:	48 39 d7             	cmp    %rdx,%rdi
    6a2b:	73 14                	jae    6a41 <fwp_rc_dup+0x71>
    6a2d:	48 01 f8             	add    %rdi,%rax
    6a30:	0f b6 10             	movzbl (%rax),%edx
    6a33:	84 d2                	test   %dl,%dl
    6a35:	74 0a                	je     6a41 <fwp_rc_dup+0x71>
    6a37:	80 fa fd             	cmp    $0xfd,%dl
    6a3a:	77 14                	ja     6a50 <fwp_rc_dup+0x80>
    6a3c:	83 c2 01             	add    $0x1,%edx
    6a3f:	88 10                	mov    %dl,(%rax)
    6a41:	c3                   	ret
    6a42:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6a48:	66 85 ff             	test   %di,%di
    6a4b:	74 e3                	je     6a30 <fwp_rc_dup+0x60>
    6a4d:	c3                   	ret
    6a4e:	66 90                	xchg   %ax,%ax
    6a50:	48 89 c7             	mov    %rax,%rdi
    6a53:	e9 98 e7 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    6a58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6a5f:	00 

0000000000006a60 <fwp_drop0>:
    6a60:	f3 0f 1e fa          	endbr64
    6a64:	48 8b 15 cd b0 01 00 	mov    0x1b0cd(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6a6b:	48 89 f8             	mov    %rdi,%rax
    6a6e:	48 2b 05 9b b0 01 00 	sub    0x1b09b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6a75:	48 c1 e2 10          	shl    $0x10,%rdx
    6a79:	48 39 d0             	cmp    %rdx,%rax
    6a7c:	0f 83 be 00 00 00    	jae    6b40 <fwp_drop0+0xe0>
    6a82:	48 83 ec 18          	sub    $0x18,%rsp
    6a86:	4c 8d 05 d3 9c 01 00 	lea    0x19cd3(%rip),%r8        # 20760 <fwp_heap>
    6a8d:	48 89 c2             	mov    %rax,%rdx
    6a90:	48 c1 ea 10          	shr    $0x10,%rdx
    6a94:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6a98:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6a9f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6aa3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6aa7:	48 85 d2             	test   %rdx,%rdx
    6aaa:	74 3c                	je     6ae8 <fwp_drop0+0x88>
    6aac:	0f b6 31             	movzbl (%rcx),%esi
    6aaf:	40 80 fe 02          	cmp    $0x2,%sil
    6ab3:	74 3b                	je     6af0 <fwp_drop0+0x90>
    6ab5:	40 80 fe 01          	cmp    $0x1,%sil
    6ab9:	75 2d                	jne    6ae8 <fwp_drop0+0x88>
    6abb:	8b 71 18             	mov    0x18(%rcx),%esi
    6abe:	0f b7 c0             	movzwl %ax,%eax
    6ac1:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6ac4:	48 0f af c6          	imul   %rsi,%rax
    6ac8:	48 c1 e8 20          	shr    $0x20,%rax
    6acc:	48 39 c8             	cmp    %rcx,%rax
    6acf:	73 17                	jae    6ae8 <fwp_drop0+0x88>
    6ad1:	48 01 c2             	add    %rax,%rdx
    6ad4:	0f b6 02             	movzbl (%rdx),%eax
    6ad7:	84 c0                	test   %al,%al
    6ad9:	74 0d                	je     6ae8 <fwp_drop0+0x88>
    6adb:	3c 01                	cmp    $0x1,%al
    6add:	74 21                	je     6b00 <fwp_drop0+0xa0>
    6adf:	3c ff                	cmp    $0xff,%al
    6ae1:	74 65                	je     6b48 <fwp_drop0+0xe8>
    6ae3:	83 e8 01             	sub    $0x1,%eax
    6ae6:	88 02                	mov    %al,(%rdx)
    6ae8:	48 83 c4 18          	add    $0x18,%rsp
    6aec:	c3                   	ret
    6aed:	0f 1f 00             	nopl   (%rax)
    6af0:	66 85 c0             	test   %ax,%ax
    6af3:	74 df                	je     6ad4 <fwp_drop0+0x74>
    6af5:	48 83 c4 18          	add    $0x18,%rsp
    6af9:	c3                   	ret
    6afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6b00:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6b04:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6b09:	e8 42 fe ff ff       	call   6950 <fwp_rc_free_arr>
    6b0e:	4c 8d 05 4b 9c 01 00 	lea    0x19c4b(%rip),%r8        # 20760 <fwp_heap>
    6b15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6b1a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6b21:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6b28:	48 c1 e2 10          	shl    $0x10,%rdx
    6b2c:	48 39 d0             	cmp    %rdx,%rax
    6b2f:	73 b7                	jae    6ae8 <fwp_drop0+0x88>
    6b31:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6b36:	e9 52 ff ff ff       	jmp    6a8d <fwp_drop0+0x2d>
    6b3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6b40:	c3                   	ret
    6b41:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b48:	48 89 d0             	mov    %rdx,%rax
    6b4b:	48 c1 e8 11          	shr    $0x11,%rax
    6b4f:	48 31 d0             	xor    %rdx,%rax
    6b52:	48 89 c1             	mov    %rax,%rcx
    6b55:	48 c1 e9 09          	shr    $0x9,%rcx
    6b59:	48 31 c8             	xor    %rcx,%rax
    6b5c:	0f b6 c8             	movzbl %al,%ecx
    6b5f:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6b66:	00 
    6b67:	48 85 c0             	test   %rax,%rax
    6b6a:	75 1d                	jne    6b89 <fwp_drop0+0x129>
    6b6c:	eb 56                	jmp    6bc4 <fwp_drop0+0x164>
    6b6e:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6b75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6b7c:	00 00 00 00 
    6b80:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6b84:	48 85 c0             	test   %rax,%rax
    6b87:	74 3b                	je     6bc4 <fwp_drop0+0x164>
    6b89:	48 89 c1             	mov    %rax,%rcx
    6b8c:	48 39 10             	cmp    %rdx,(%rax)
    6b8f:	75 ef                	jne    6b80 <fwp_drop0+0x120>
    6b91:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6b95:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6b99:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6b9d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6ba4:	0f 85 3e ff ff ff    	jne    6ae8 <fwp_drop0+0x88>
    6baa:	48 89 d7             	mov    %rdx,%rdi
    6bad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6bb2:	e8 59 e7 ff ff       	call   5310 <fwp_rc_forget_slot>
    6bb7:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6bbc:	c6 02 fe             	movb   $0xfe,(%rdx)
    6bbf:	e9 24 ff ff ff       	jmp    6ae8 <fwp_drop0+0x88>
    6bc4:	48 8d 3d cd 5b 00 00 	lea    0x5bcd(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6bcb:	e8 d0 d5 ff ff       	call   41a0 <fwp_trap>

0000000000006bd0 <fwp_arg_drop12>:
    6bd0:	f3 0f 1e fa          	endbr64
    6bd4:	85 f6                	test   %esi,%esi
    6bd6:	75 04                	jne    6bdc <fwp_arg_drop12+0xc>
    6bd8:	85 d2                	test   %edx,%edx
    6bda:	75 04                	jne    6be0 <fwp_arg_drop12+0x10>
    6bdc:	c3                   	ret
    6bdd:	0f 1f 00             	nopl   (%rax)
    6be0:	48 8b 3f             	mov    (%rdi),%rdi
    6be3:	e9 78 fe ff ff       	jmp    6a60 <fwp_drop0>
    6be8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6bef:	00 

0000000000006bf0 <fwp_drop1>:
    6bf0:	f3 0f 1e fa          	endbr64
    6bf4:	48 8b 15 3d af 01 00 	mov    0x1af3d(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6bfb:	48 89 f8             	mov    %rdi,%rax
    6bfe:	48 2b 05 0b af 01 00 	sub    0x1af0b(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6c05:	48 c1 e2 10          	shl    $0x10,%rdx
    6c09:	48 39 d0             	cmp    %rdx,%rax
    6c0c:	0f 83 be 00 00 00    	jae    6cd0 <fwp_drop1+0xe0>
    6c12:	48 83 ec 18          	sub    $0x18,%rsp
    6c16:	4c 8d 05 43 9b 01 00 	lea    0x19b43(%rip),%r8        # 20760 <fwp_heap>
    6c1d:	48 89 c2             	mov    %rax,%rdx
    6c20:	48 c1 ea 10          	shr    $0x10,%rdx
    6c24:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6c28:	49 8b 90 f8 13 00 00 	mov    0x13f8(%r8),%rdx
    6c2f:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6c33:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6c37:	48 85 d2             	test   %rdx,%rdx
    6c3a:	74 3c                	je     6c78 <fwp_drop1+0x88>
    6c3c:	0f b6 31             	movzbl (%rcx),%esi
    6c3f:	40 80 fe 02          	cmp    $0x2,%sil
    6c43:	74 3b                	je     6c80 <fwp_drop1+0x90>
    6c45:	40 80 fe 01          	cmp    $0x1,%sil
    6c49:	75 2d                	jne    6c78 <fwp_drop1+0x88>
    6c4b:	8b 71 18             	mov    0x18(%rcx),%esi
    6c4e:	0f b7 c0             	movzwl %ax,%eax
    6c51:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6c54:	48 0f af c6          	imul   %rsi,%rax
    6c58:	48 c1 e8 20          	shr    $0x20,%rax
    6c5c:	48 39 c8             	cmp    %rcx,%rax
    6c5f:	73 17                	jae    6c78 <fwp_drop1+0x88>
    6c61:	48 01 c2             	add    %rax,%rdx
    6c64:	0f b6 02             	movzbl (%rdx),%eax
    6c67:	84 c0                	test   %al,%al
    6c69:	74 0d                	je     6c78 <fwp_drop1+0x88>
    6c6b:	3c 01                	cmp    $0x1,%al
    6c6d:	74 21                	je     6c90 <fwp_drop1+0xa0>
    6c6f:	3c ff                	cmp    $0xff,%al
    6c71:	74 65                	je     6cd8 <fwp_drop1+0xe8>
    6c73:	83 e8 01             	sub    $0x1,%eax
    6c76:	88 02                	mov    %al,(%rdx)
    6c78:	48 83 c4 18          	add    $0x18,%rsp
    6c7c:	c3                   	ret
    6c7d:	0f 1f 00             	nopl   (%rax)
    6c80:	66 85 c0             	test   %ax,%ax
    6c83:	74 df                	je     6c64 <fwp_drop1+0x74>
    6c85:	48 83 c4 18          	add    $0x18,%rsp
    6c89:	c3                   	ret
    6c8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6c90:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
    6c94:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    6c99:	e8 b2 fc ff ff       	call   6950 <fwp_rc_free_arr>
    6c9e:	4c 8d 05 bb 9a 01 00 	lea    0x19abb(%rip),%r8        # 20760 <fwp_heap>
    6ca5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    6caa:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    6cb1:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    6cb8:	48 c1 e2 10          	shl    $0x10,%rdx
    6cbc:	48 39 d0             	cmp    %rdx,%rax
    6cbf:	73 b7                	jae    6c78 <fwp_drop1+0x88>
    6cc1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    6cc6:	e9 52 ff ff ff       	jmp    6c1d <fwp_drop1+0x2d>
    6ccb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6cd0:	c3                   	ret
    6cd1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6cd8:	48 89 d0             	mov    %rdx,%rax
    6cdb:	48 c1 e8 11          	shr    $0x11,%rax
    6cdf:	48 31 d0             	xor    %rdx,%rax
    6ce2:	48 89 c1             	mov    %rax,%rcx
    6ce5:	48 c1 e9 09          	shr    $0x9,%rcx
    6ce9:	48 31 c8             	xor    %rcx,%rax
    6cec:	0f b6 c8             	movzbl %al,%ecx
    6cef:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    6cf6:	00 
    6cf7:	48 85 c0             	test   %rax,%rax
    6cfa:	75 0d                	jne    6d09 <fwp_drop1+0x119>
    6cfc:	eb 46                	jmp    6d44 <fwp_drop1+0x154>
    6cfe:	66 90                	xchg   %ax,%ax
    6d00:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6d04:	48 85 c0             	test   %rax,%rax
    6d07:	74 3b                	je     6d44 <fwp_drop1+0x154>
    6d09:	48 89 c1             	mov    %rax,%rcx
    6d0c:	48 39 10             	cmp    %rdx,(%rax)
    6d0f:	75 ef                	jne    6d00 <fwp_drop1+0x110>
    6d11:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6d15:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6d19:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6d1d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6d24:	0f 85 4e ff ff ff    	jne    6c78 <fwp_drop1+0x88>
    6d2a:	48 89 d7             	mov    %rdx,%rdi
    6d2d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6d32:	e8 d9 e5 ff ff       	call   5310 <fwp_rc_forget_slot>
    6d37:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6d3c:	c6 02 fe             	movb   $0xfe,(%rdx)
    6d3f:	e9 34 ff ff ff       	jmp    6c78 <fwp_drop1+0x88>
    6d44:	48 8d 3d 4d 5a 00 00 	lea    0x5a4d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6d4b:	e8 50 d4 ff ff       	call   41a0 <fwp_trap>

0000000000006d50 <fwp_closure_drop>:
    6d50:	48 8b 15 e1 ad 01 00 	mov    0x1ade1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    6d57:	48 89 f8             	mov    %rdi,%rax
    6d5a:	48 2b 05 af ad 01 00 	sub    0x1adaf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    6d61:	48 c1 e2 10          	shl    $0x10,%rdx
    6d65:	48 39 d0             	cmp    %rdx,%rax
    6d68:	73 6b                	jae    6dd5 <fwp_closure_drop+0x85>
    6d6a:	48 89 c2             	mov    %rax,%rdx
    6d6d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d75:	48 8b 15 dc ad 01 00 	mov    0x1addc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    6d7c:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6d80:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6d84:	48 85 d2             	test   %rdx,%rdx
    6d87:	74 4c                	je     6dd5 <fwp_closure_drop+0x85>
    6d89:	0f b6 31             	movzbl (%rcx),%esi
    6d8c:	40 80 fe 02          	cmp    $0x2,%sil
    6d90:	74 3e                	je     6dd0 <fwp_closure_drop+0x80>
    6d92:	40 80 fe 01          	cmp    $0x1,%sil
    6d96:	75 3d                	jne    6dd5 <fwp_closure_drop+0x85>
    6d98:	8b 71 18             	mov    0x18(%rcx),%esi
    6d9b:	0f b7 c0             	movzwl %ax,%eax
    6d9e:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6da1:	48 0f af c6          	imul   %rsi,%rax
    6da5:	48 c1 e8 20          	shr    $0x20,%rax
    6da9:	48 39 c8             	cmp    %rcx,%rax
    6dac:	73 27                	jae    6dd5 <fwp_closure_drop+0x85>
    6dae:	48 01 c2             	add    %rax,%rdx
    6db1:	0f b6 02             	movzbl (%rdx),%eax
    6db4:	84 c0                	test   %al,%al
    6db6:	74 1d                	je     6dd5 <fwp_closure_drop+0x85>
    6db8:	3c 01                	cmp    $0x1,%al
    6dba:	74 24                	je     6de0 <fwp_closure_drop+0x90>
    6dbc:	3c ff                	cmp    $0xff,%al
    6dbe:	74 48                	je     6e08 <fwp_closure_drop+0xb8>
    6dc0:	83 e8 01             	sub    $0x1,%eax
    6dc3:	88 02                	mov    %al,(%rdx)
    6dc5:	c3                   	ret
    6dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dcd:	00 00 00 
    6dd0:	66 85 c0             	test   %ax,%ax
    6dd3:	74 dc                	je     6db1 <fwp_closure_drop+0x61>
    6dd5:	c3                   	ret
    6dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6ddd:	00 00 00 
    6de0:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    6de7:	ff ff 
    6de9:	48 85 c0             	test   %rax,%rax
    6dec:	74 12                	je     6e00 <fwp_closure_drop+0xb0>
    6dee:	48 89 fe             	mov    %rdi,%rsi
    6df1:	48 89 c7             	mov    %rax,%rdi
    6df4:	e9 07 d4 ff ff       	jmp    4200 <fwp_closure_drop_push>
    6df9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e00:	e9 ab d5 ff ff       	jmp    43b0 <fwp_closure_drop.part.0>
    6e05:	0f 1f 00             	nopl   (%rax)
    6e08:	48 89 d0             	mov    %rdx,%rax
    6e0b:	48 8d 35 4e 99 01 00 	lea    0x1994e(%rip),%rsi        # 20760 <fwp_heap>
    6e12:	48 83 ec 18          	sub    $0x18,%rsp
    6e16:	48 c1 e8 11          	shr    $0x11,%rax
    6e1a:	48 31 d0             	xor    %rdx,%rax
    6e1d:	48 89 c1             	mov    %rax,%rcx
    6e20:	48 c1 e9 09          	shr    $0x9,%rcx
    6e24:	48 31 c8             	xor    %rcx,%rax
    6e27:	0f b6 c8             	movzbl %al,%ecx
    6e2a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    6e31:	00 
    6e32:	48 85 c0             	test   %rax,%rax
    6e35:	75 12                	jne    6e49 <fwp_closure_drop+0xf9>
    6e37:	eb 49                	jmp    6e82 <fwp_closure_drop+0x132>
    6e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6e40:	48 8b 41 10          	mov    0x10(%rcx),%rax
    6e44:	48 85 c0             	test   %rax,%rax
    6e47:	74 39                	je     6e82 <fwp_closure_drop+0x132>
    6e49:	48 89 c1             	mov    %rax,%rcx
    6e4c:	48 39 10             	cmp    %rdx,(%rax)
    6e4f:	75 ef                	jne    6e40 <fwp_closure_drop+0xf0>
    6e51:	48 8b 70 08          	mov    0x8(%rax),%rsi
    6e55:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    6e59:	48 89 48 08          	mov    %rcx,0x8(%rax)
    6e5d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    6e64:	74 05                	je     6e6b <fwp_closure_drop+0x11b>
    6e66:	48 83 c4 18          	add    $0x18,%rsp
    6e6a:	c3                   	ret
    6e6b:	48 89 d7             	mov    %rdx,%rdi
    6e6e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6e73:	e8 98 e4 ff ff       	call   5310 <fwp_rc_forget_slot>
    6e78:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    6e7d:	c6 02 fe             	movb   $0xfe,(%rdx)
    6e80:	eb e4                	jmp    6e66 <fwp_closure_drop+0x116>
    6e82:	48 8d 3d 0f 59 00 00 	lea    0x590f(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    6e89:	e8 12 d3 ff ff       	call   41a0 <fwp_trap>
    6e8e:	66 90                	xchg   %ax,%ax

0000000000006e90 <fwp_owned_tape_release>:
    6e90:	48 85 ff             	test   %rdi,%rdi
    6e93:	0f 84 f7 00 00 00    	je     6f90 <fwp_owned_tape_release+0x100>
    6e99:	41 54                	push   %r12
    6e9b:	55                   	push   %rbp
    6e9c:	53                   	push   %rbx
    6e9d:	48 8b 07             	mov    (%rdi),%rax
    6ea0:	48 85 c0             	test   %rax,%rax
    6ea3:	74 08                	je     6ead <fwp_owned_tape_release+0x1d>
    6ea5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6ea9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    6ead:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    6eb1:	48 85 d2             	test   %rdx,%rdx
    6eb4:	74 03                	je     6eb9 <fwp_owned_tape_release+0x29>
    6eb6:	48 89 02             	mov    %rax,(%rdx)
    6eb9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    6ebd:	48 89 fb             	mov    %rdi,%rbx
    6ec0:	48 8b 42 68          	mov    0x68(%rdx),%rax
    6ec4:	48 85 c0             	test   %rax,%rax
    6ec7:	0f 84 89 00 00 00    	je     6f56 <fwp_owned_tape_release+0xc6>
    6ecd:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    6ed1:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    6ed5:	7e 47                	jle    6f1e <fwp_owned_tape_release+0x8e>
    6ed7:	31 ed                	xor    %ebp,%ebp
    6ed9:	eb 0d                	jmp    6ee8 <fwp_owned_tape_release+0x58>
    6edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6ee0:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6ee4:	48 8b 40 68          	mov    0x68(%rax),%rax
    6ee8:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    6eec:	49 89 ec             	mov    %rbp,%r12
    6eef:	48 83 c5 01          	add    $0x1,%rbp
    6ef3:	49 c1 e4 04          	shl    $0x4,%r12
    6ef7:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    6efb:	ff d0                	call   *%rax
    6efd:	48 8b 43 40          	mov    0x40(%rbx),%rax
    6f01:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    6f06:	48 8b 43 10          	mov    0x10(%rbx),%rax
    6f0a:	ff 50 68             	call   *0x68(%rax)
    6f0d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    6f11:	48 2b 43 50          	sub    0x50(%rbx),%rax
    6f15:	48 39 e8             	cmp    %rbp,%rax
    6f18:	7f c6                	jg     6ee0 <fwp_owned_tape_release+0x50>
    6f1a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f1e:	31 ed                	xor    %ebp,%ebp
    6f20:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    6f25:	7e 28                	jle    6f4f <fwp_owned_tape_release+0xbf>
    6f27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6f2e:	00 00 
    6f30:	48 8b 43 48          	mov    0x48(%rbx),%rax
    6f34:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    6f38:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    6f3c:	74 07                	je     6f45 <fwp_owned_tape_release+0xb5>
    6f3e:	ff 52 68             	call   *0x68(%rdx)
    6f41:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    6f45:	48 83 c5 01          	add    $0x1,%rbp
    6f49:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    6f4d:	7f e1                	jg     6f30 <fwp_owned_tape_release+0xa0>
    6f4f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    6f53:	ff 52 68             	call   *0x68(%rdx)
    6f56:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    6f5a:	e8 f1 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f5f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    6f63:	e8 e8 fd ff ff       	call   6d50 <fwp_closure_drop>
    6f68:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    6f6c:	e8 df fd ff ff       	call   6d50 <fwp_closure_drop>
    6f71:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    6f75:	e8 d6 e5 ff ff       	call   5550 <fwp_mem_free>
    6f7a:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    6f7e:	e8 cd e5 ff ff       	call   5550 <fwp_mem_free>
    6f83:	48 89 df             	mov    %rbx,%rdi
    6f86:	5b                   	pop    %rbx
    6f87:	5d                   	pop    %rbp
    6f88:	41 5c                	pop    %r12
    6f8a:	e9 c1 e5 ff ff       	jmp    5550 <fwp_mem_free>
    6f8f:	90                   	nop
    6f90:	c3                   	ret
    6f91:	0f 1f 40 00          	nopl   0x0(%rax)
    6f95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6f9c:	00 00 00 00 

0000000000006fa0 <fwp_tape_finish>:
    6fa0:	f3 0f 1e fa          	endbr64
    6fa4:	41 56                	push   %r14
    6fa6:	48 8d 3d f3 90 01 00 	lea    0x190f3(%rip),%rdi        # 200a0 <fwp_tape_workspace>
    6fad:	41 55                	push   %r13
    6faf:	41 54                	push   %r12
    6fb1:	55                   	push   %rbp
    6fb2:	53                   	push   %rbx
    6fb3:	e8 b8 cf ff ff       	call   3f70 <fwp_tape_buffers_dispose>
    6fb8:	48 83 3d 28 91 01 00 	cmpq   $0x0,0x19128(%rip)        # 200e8 <fwp_ntapes>
    6fbf:	00 
    6fc0:	48 c7 05 bd 90 01 00 	movq   $0x0,0x190bd(%rip)        # 20088 <fwp_tape_cached_bytes>
    6fc7:	00 00 00 00 
    6fcb:	7e 68                	jle    7035 <fwp_tape_finish+0x95>
    6fcd:	45 31 e4             	xor    %r12d,%r12d
    6fd0:	31 ed                	xor    %ebp,%ebp
    6fd2:	0f 1f 00             	nopl   (%rax)
    6fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    6fdc:	00 00 00 00 
    6fe0:	48 8b 1d 09 91 01 00 	mov    0x19109(%rip),%rbx        # 200f0 <fwp_tapes>
    6fe7:	48 83 c5 01          	add    $0x1,%rbp
    6feb:	4c 01 e3             	add    %r12,%rbx
    6fee:	49 83 c4 68          	add    $0x68,%r12
    6ff2:	48 89 df             	mov    %rbx,%rdi
    6ff5:	e8 06 cc ff ff       	call   3c00 <fwp_tape_unlink_scope>
    6ffa:	4c 8b 73 30          	mov    0x30(%rbx),%r14
    6ffe:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7002:	4c 8b 6b 40          	mov    0x40(%rbx),%r13
    7006:	e8 b5 c3 ff ff       	call   33c0 <free@plt>
    700b:	4c 89 f7             	mov    %r14,%rdi
    700e:	e8 ad c3 ff ff       	call   33c0 <free@plt>
    7013:	4c 89 ef             	mov    %r13,%rdi
    7016:	e8 a5 c3 ff ff       	call   33c0 <free@plt>
    701b:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    701f:	e8 6c fe ff ff       	call   6e90 <fwp_owned_tape_release>
    7024:	48 39 2d bd 90 01 00 	cmp    %rbp,0x190bd(%rip)        # 200e8 <fwp_ntapes>
    702b:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7032:	00 
    7033:	7f ab                	jg     6fe0 <fwp_tape_finish+0x40>
    7035:	48 8b 3d b4 90 01 00 	mov    0x190b4(%rip),%rdi        # 200f0 <fwp_tapes>
    703c:	e8 7f c3 ff ff       	call   33c0 <free@plt>
    7041:	5b                   	pop    %rbx
    7042:	5d                   	pop    %rbp
    7043:	48 c7 05 a2 90 01 00 	movq   $0x0,0x190a2(%rip)        # 200f0 <fwp_tapes>
    704a:	00 00 00 00 
    704e:	48 c7 05 87 90 01 00 	movq   $0x0,0x19087(%rip)        # 200e0 <fwp_tapes_cap>
    7055:	00 00 00 00 
    7059:	41 5c                	pop    %r12
    705b:	48 c7 05 82 90 01 00 	movq   $0x0,0x19082(%rip)        # 200e8 <fwp_ntapes>
    7062:	00 00 00 00 
    7066:	41 5d                	pop    %r13
    7068:	48 c7 05 65 90 01 00 	movq   $0x0,0x19065(%rip)        # 200d8 <fwp_tape_next_slot>
    706f:	00 00 00 00 
    7073:	41 5e                	pop    %r14
    7075:	c3                   	ret
    7076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    707d:	00 00 00 

0000000000007080 <fwp_tape_scope_release>:
    7080:	f3 0f 1e fa          	endbr64
    7084:	41 55                	push   %r13
    7086:	41 54                	push   %r12
    7088:	55                   	push   %rbp
    7089:	53                   	push   %rbx
    708a:	48 83 ec 58          	sub    $0x58,%rsp
    708e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7095:	00 00 
    7097:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
    709c:	48 63 07             	movslq (%rdi),%rax
    709f:	85 c0                	test   %eax,%eax
    70a1:	0f 88 05 01 00 00    	js     71ac <fwp_tape_scope_release+0x12c>
    70a7:	48 bd c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%rbp
    70ae:	ec c4 4e 
    70b1:	48 89 fb             	mov    %rdi,%rbx
    70b4:	eb 3c                	jmp    70f2 <fwp_tape_scope_release+0x72>
    70b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70bd:	00 00 00 
    70c0:	66 48 0f 7e cf       	movq   %xmm1,%rdi
    70c5:	0f 29 04 24          	movaps %xmm0,(%rsp)
    70c9:	e8 f2 c2 ff ff       	call   33c0 <free@plt>
    70ce:	48 8b 3c 24          	mov    (%rsp),%rdi
    70d2:	e8 e9 c2 ff ff       	call   33c0 <free@plt>
    70d7:	4c 89 ef             	mov    %r13,%rdi
    70da:	e8 e1 c2 ff ff       	call   33c0 <free@plt>
    70df:	4c 89 e7             	mov    %r12,%rdi
    70e2:	e8 a9 fd ff ff       	call   6e90 <fwp_owned_tape_release>
    70e7:	48 63 03             	movslq (%rbx),%rax
    70ea:	85 c0                	test   %eax,%eax
    70ec:	0f 88 ba 00 00 00    	js     71ac <fwp_tape_scope_release+0x12c>
    70f2:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    70f6:	48 8b 35 f3 8f 01 00 	mov    0x18ff3(%rip),%rsi        # 200f0 <fwp_tapes>
    70fd:	4c 01 c6             	add    %r8,%rsi
    7100:	48 89 f7             	mov    %rsi,%rdi
    7103:	e8 f8 ca ff ff       	call   3c00 <fwp_tape_unlink_scope>
    7108:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    710d:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7112:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    7119:	4c 8b 6e 40          	mov    0x40(%rsi),%r13
    711d:	4c 8b 66 60          	mov    0x60(%rsi),%r12
    7121:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    7128:	00 
    7129:	f3 0f 7e 56 18       	movq   0x18(%rsi),%xmm2
    712e:	0f 16 56 48          	movhps 0x48(%rsi),%xmm2
    7132:	0f 11 54 24 38       	movups %xmm2,0x38(%rsp)
    7137:	66 0f ef d2          	pxor   %xmm2,%xmm2
    713b:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
    7140:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    7147:	00 
    7148:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    714f:	00 
    7150:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    7157:	00 
    7158:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
    715d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
    7162:	0f 11 56 20          	movups %xmm2,0x20(%rsi)
    7166:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
    716a:	0f 11 56 08          	movups %xmm2,0x8(%rsi)
    716e:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    7174:	77 18                	ja     718e <fwp_tape_scope_release+0x10e>
    7176:	49 c1 f8 03          	sar    $0x3,%r8
    717a:	4c 0f af c5          	imul   %rbp,%r8
    717e:	4c 3b 05 53 8f 01 00 	cmp    0x18f53(%rip),%r8        # 200d8 <fwp_tape_next_slot>
    7185:	7d 07                	jge    718e <fwp_tape_scope_release+0x10e>
    7187:	4c 89 05 4a 8f 01 00 	mov    %r8,0x18f4a(%rip)        # 200d8 <fwp_tape_next_slot>
    718e:	4d 85 e4             	test   %r12,%r12
    7191:	0f 85 29 ff ff ff    	jne    70c0 <fwp_tape_scope_release+0x40>
    7197:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    719c:	e8 8f dc ff ff       	call   4e30 <fwp_tape_buffers_release>
    71a1:	48 63 03             	movslq (%rbx),%rax
    71a4:	85 c0                	test   %eax,%eax
    71a6:	0f 89 46 ff ff ff    	jns    70f2 <fwp_tape_scope_release+0x72>
    71ac:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
    71b1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    71b8:	00 00 
    71ba:	75 0b                	jne    71c7 <fwp_tape_scope_release+0x147>
    71bc:	48 83 c4 58          	add    $0x58,%rsp
    71c0:	5b                   	pop    %rbx
    71c1:	5d                   	pop    %rbp
    71c2:	41 5c                	pop    %r12
    71c4:	41 5d                	pop    %r13
    71c6:	c3                   	ret
    71c7:	e8 94 c2 ff ff       	call   3460 <__stack_chk_fail@plt>
    71cc:	0f 1f 40 00          	nopl   0x0(%rax)

00000000000071d0 <fwp_task_dispose>:
    71d0:	53                   	push   %rbx
    71d1:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    71d5:	0f 84 6b c5 ff ff    	je     3746 <fwp_task_dispose.cold>
    71db:	48 89 fb             	mov    %rdi,%rbx
    71de:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    71e3:	0f 85 5d c5 ff ff    	jne    3746 <fwp_task_dispose.cold>
    71e9:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    71ed:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    71f4:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    71fb:	00 
    71fc:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7200:	48 85 ff             	test   %rdi,%rdi
    7203:	74 07                	je     720c <fwp_task_dispose+0x3c>
    7205:	48 85 c0             	test   %rax,%rax
    7208:	74 02                	je     720c <fwp_task_dispose+0x3c>
    720a:	ff d0                	call   *%rax
    720c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7213:	e8 38 e3 ff ff       	call   5550 <fwp_mem_free>
    7218:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    721f:	00 00 00 00 
    7223:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7227:	74 6f                	je     7298 <fwp_task_dispose+0xc8>
    7229:	48 8b 15 08 a9 01 00 	mov    0x1a908(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7230:	48 89 d8             	mov    %rbx,%rax
    7233:	48 2b 05 d6 a8 01 00 	sub    0x1a8d6(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    723a:	48 c1 e2 10          	shl    $0x10,%rdx
    723e:	48 39 d0             	cmp    %rdx,%rax
    7241:	73 4c                	jae    728f <fwp_task_dispose+0xbf>
    7243:	48 89 c2             	mov    %rax,%rdx
    7246:	48 c1 ea 10          	shr    $0x10,%rdx
    724a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    724e:	48 8b 15 03 a9 01 00 	mov    0x1a903(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7255:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7259:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    725d:	48 85 c9             	test   %rcx,%rcx
    7260:	74 2d                	je     728f <fwp_task_dispose+0xbf>
    7262:	0f b6 32             	movzbl (%rdx),%esi
    7265:	40 80 fe 02          	cmp    $0x2,%sil
    7269:	74 3d                	je     72a8 <fwp_task_dispose+0xd8>
    726b:	40 80 fe 01          	cmp    $0x1,%sil
    726f:	75 1e                	jne    728f <fwp_task_dispose+0xbf>
    7271:	8b 72 18             	mov    0x18(%rdx),%esi
    7274:	0f b7 c0             	movzwl %ax,%eax
    7277:	8b 52 1c             	mov    0x1c(%rdx),%edx
    727a:	48 0f af c6          	imul   %rsi,%rax
    727e:	48 c1 e8 20          	shr    $0x20,%rax
    7282:	48 39 d0             	cmp    %rdx,%rax
    7285:	73 08                	jae    728f <fwp_task_dispose+0xbf>
    7287:	48 01 c1             	add    %rax,%rcx
    728a:	80 39 01             	cmpb   $0x1,(%rcx)
    728d:	74 09                	je     7298 <fwp_task_dispose+0xc8>
    728f:	5b                   	pop    %rbx
    7290:	c3                   	ret
    7291:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7298:	48 89 df             	mov    %rbx,%rdi
    729b:	5b                   	pop    %rbx
    729c:	e9 af e2 ff ff       	jmp    5550 <fwp_mem_free>
    72a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    72a8:	66 85 c0             	test   %ax,%ax
    72ab:	74 dd                	je     728a <fwp_task_dispose+0xba>
    72ad:	5b                   	pop    %rbx
    72ae:	c3                   	ret
    72af:	90                   	nop

00000000000072b0 <fwp_free_zombie>:
    72b0:	48 8b 15 79 94 01 00 	mov    0x19479(%rip),%rdx        # 20730 <fwp_zombie>
    72b7:	48 85 d2             	test   %rdx,%rdx
    72ba:	0f 84 98 00 00 00    	je     7358 <fwp_free_zombie+0xa8>
    72c0:	48 3b 15 79 94 01 00 	cmp    0x19479(%rip),%rdx        # 20740 <fwp_cur>
    72c7:	0f 84 8b 00 00 00    	je     7358 <fwp_free_zombie+0xa8>
    72cd:	48 83 ec 18          	sub    $0x18,%rsp
    72d1:	48 63 05 34 8e 01 00 	movslq 0x18e34(%rip),%rax        # 2010c <fwp_stack_pool_n>
    72d8:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    72dc:	83 f8 3f             	cmp    $0x3f,%eax
    72df:	7f 7f                	jg     7360 <fwp_free_zombie+0xb0>
    72e1:	8d 48 01             	lea    0x1(%rax),%ecx
    72e4:	89 0d 22 8e 01 00    	mov    %ecx,0x18e22(%rip)        # 2010c <fwp_stack_pool_n>
    72ea:	48 8d 0d 2f 8e 01 00 	lea    0x18e2f(%rip),%rcx        # 20120 <fwp_stack_pool>
    72f1:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    72f5:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    72fc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7300:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7307:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    730b:	48 85 c9             	test   %rcx,%rcx
    730e:	0f 84 fc 00 00 00    	je     7410 <fwp_free_zombie+0x160>
    7314:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    731b:	48 85 c0             	test   %rax,%rax
    731e:	74 07                	je     7327 <fwp_free_zombie+0x77>
    7320:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7327:	8b 42 5c             	mov    0x5c(%rdx),%eax
    732a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    732e:	48 c7 05 f7 93 01 00 	movq   $0x0,0x193f7(%rip)        # 20730 <fwp_zombie>
    7335:	00 00 00 00 
    7339:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7340:	85 c0                	test   %eax,%eax
    7342:	74 34                	je     7378 <fwp_free_zombie+0xc8>
    7344:	83 f8 01             	cmp    $0x1,%eax
    7347:	0f 84 b3 00 00 00    	je     7400 <fwp_free_zombie+0x150>
    734d:	48 83 c4 18          	add    $0x18,%rsp
    7351:	c3                   	ret
    7352:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7358:	c3                   	ret
    7359:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7360:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7364:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7369:	e8 72 c2 ff ff       	call   35e0 <munmap@plt>
    736e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7373:	eb 80                	jmp    72f5 <fwp_free_zombie+0x45>
    7375:	0f 1f 00             	nopl   (%rax)
    7378:	48 8b 0d b9 a7 01 00 	mov    0x1a7b9(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    737f:	48 89 d0             	mov    %rdx,%rax
    7382:	48 2b 05 87 a7 01 00 	sub    0x1a787(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7389:	48 c1 e1 10          	shl    $0x10,%rcx
    738d:	48 39 c8             	cmp    %rcx,%rax
    7390:	73 bb                	jae    734d <fwp_free_zombie+0x9d>
    7392:	48 89 c1             	mov    %rax,%rcx
    7395:	48 c1 e9 10          	shr    $0x10,%rcx
    7399:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    739d:	48 8b 0d b4 a7 01 00 	mov    0x1a7b4(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    73a4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    73a8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    73ac:	48 85 c9             	test   %rcx,%rcx
    73af:	74 9c                	je     734d <fwp_free_zombie+0x9d>
    73b1:	0f b6 3e             	movzbl (%rsi),%edi
    73b4:	40 80 ff 02          	cmp    $0x2,%dil
    73b8:	74 66                	je     7420 <fwp_free_zombie+0x170>
    73ba:	40 80 ff 01          	cmp    $0x1,%dil
    73be:	75 8d                	jne    734d <fwp_free_zombie+0x9d>
    73c0:	8b 7e 18             	mov    0x18(%rsi),%edi
    73c3:	0f b7 c0             	movzwl %ax,%eax
    73c6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    73c9:	48 0f af c7          	imul   %rdi,%rax
    73cd:	48 c1 e8 20          	shr    $0x20,%rax
    73d1:	48 39 f0             	cmp    %rsi,%rax
    73d4:	0f 83 73 ff ff ff    	jae    734d <fwp_free_zombie+0x9d>
    73da:	48 01 c1             	add    %rax,%rcx
    73dd:	0f b6 01             	movzbl (%rcx),%eax
    73e0:	84 c0                	test   %al,%al
    73e2:	0f 84 65 ff ff ff    	je     734d <fwp_free_zombie+0x9d>
    73e8:	3c 01                	cmp    $0x1,%al
    73ea:	74 14                	je     7400 <fwp_free_zombie+0x150>
    73ec:	3c ff                	cmp    $0xff,%al
    73ee:	74 3b                	je     742b <fwp_free_zombie+0x17b>
    73f0:	83 e8 01             	sub    $0x1,%eax
    73f3:	88 01                	mov    %al,(%rcx)
    73f5:	e9 53 ff ff ff       	jmp    734d <fwp_free_zombie+0x9d>
    73fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7400:	48 89 d7             	mov    %rdx,%rdi
    7403:	48 83 c4 18          	add    $0x18,%rsp
    7407:	e9 c4 fd ff ff       	jmp    71d0 <fwp_task_dispose>
    740c:	0f 1f 40 00          	nopl   0x0(%rax)
    7410:	48 89 05 f1 92 01 00 	mov    %rax,0x192f1(%rip)        # 20708 <fwp_tasks_active>
    7417:	e9 ff fe ff ff       	jmp    731b <fwp_free_zombie+0x6b>
    741c:	0f 1f 40 00          	nopl   0x0(%rax)
    7420:	66 85 c0             	test   %ax,%ax
    7423:	0f 85 24 ff ff ff    	jne    734d <fwp_free_zombie+0x9d>
    7429:	eb b2                	jmp    73dd <fwp_free_zombie+0x12d>
    742b:	48 89 ca             	mov    %rcx,%rdx
    742e:	48 8d 35 2b 93 01 00 	lea    0x1932b(%rip),%rsi        # 20760 <fwp_heap>
    7435:	48 c1 ea 11          	shr    $0x11,%rdx
    7439:	48 31 ca             	xor    %rcx,%rdx
    743c:	48 89 d0             	mov    %rdx,%rax
    743f:	48 c1 e8 09          	shr    $0x9,%rax
    7443:	48 31 c2             	xor    %rax,%rdx
    7446:	0f b6 d2             	movzbl %dl,%edx
    7449:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7450:	00 
    7451:	48 85 c0             	test   %rax,%rax
    7454:	75 13                	jne    7469 <fwp_free_zombie+0x1b9>
    7456:	eb 4c                	jmp    74a4 <fwp_free_zombie+0x1f4>
    7458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    745f:	00 
    7460:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7464:	48 85 c0             	test   %rax,%rax
    7467:	74 3b                	je     74a4 <fwp_free_zombie+0x1f4>
    7469:	48 89 c2             	mov    %rax,%rdx
    746c:	48 39 08             	cmp    %rcx,(%rax)
    746f:	75 ef                	jne    7460 <fwp_free_zombie+0x1b0>
    7471:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7475:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7479:	48 89 50 08          	mov    %rdx,0x8(%rax)
    747d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7484:	0f 85 c3 fe ff ff    	jne    734d <fwp_free_zombie+0x9d>
    748a:	48 89 cf             	mov    %rcx,%rdi
    748d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7492:	e8 79 de ff ff       	call   5310 <fwp_rc_forget_slot>
    7497:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    749c:	c6 01 fe             	movb   $0xfe,(%rcx)
    749f:	e9 a9 fe ff ff       	jmp    734d <fwp_free_zombie+0x9d>
    74a4:	48 8d 3d ed 52 00 00 	lea    0x52ed(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    74ab:	e8 f0 cc ff ff       	call   41a0 <fwp_trap>

00000000000074b0 <fwp_block>:
    74b0:	48 83 ec 08          	sub    $0x8,%rsp
    74b4:	48 8b 05 6d 92 01 00 	mov    0x1926d(%rip),%rax        # 20728 <fwp_ready_head>
    74bb:	48 85 c0             	test   %rax,%rax
    74be:	0f 84 1c 01 00 00    	je     75e0 <fwp_block+0x130>
    74c4:	90                   	nop
    74c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    74cc:	00 00 00 00 
    74d0:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    74d7:	48 89 15 4a 92 01 00 	mov    %rdx,0x1924a(%rip)        # 20728 <fwp_ready_head>
    74de:	48 85 d2             	test   %rdx,%rdx
    74e1:	0f 84 19 01 00 00    	je     7600 <fwp_block+0x150>
    74e7:	48 8b 15 52 92 01 00 	mov    0x19252(%rip),%rdx        # 20740 <fwp_cur>
    74ee:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    74f2:	48 39 c2             	cmp    %rax,%rdx
    74f5:	0f 84 d5 00 00 00    	je     75d0 <fwp_block+0x120>
    74fb:	48 8b 0d c6 ae 01 00 	mov    0x1aec6(%rip),%rcx        # 223c8 <fwp_state_owners>
    7502:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7506:	48 89 05 33 92 01 00 	mov    %rax,0x19233(%rip)        # 20740 <fwp_cur>
    750d:	f3 0f 7e 05 db ae 01 	movq   0x1aedb(%rip),%xmm0        # 223f0 <fwp_foreign_callbacks>
    7514:	00 
    7515:	0f 16 05 c4 ae 01 00 	movhps 0x1aec4(%rip),%xmm0        # 223e0 <fwp_state>
    751c:	f3 0f 7e 0d c4 ae 01 	movq   0x1aec4(%rip),%xmm1        # 223e8 <fwp_handlers>
    7523:	00 
    7524:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    752b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7532:	0f 16 0d bf ae 01 00 	movhps 0x1aebf(%rip),%xmm1        # 223f8 <fwp_cleanups>
    7539:	f3 0f 7e 05 97 ae 01 	movq   0x1ae97(%rip),%xmm0        # 223d8 <fwp_state_len>
    7540:	00 
    7541:	0f 16 05 88 ae 01 00 	movhps 0x1ae88(%rip),%xmm0        # 223d0 <fwp_state_cap>
    7548:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    754f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7556:	48 8b 70 08          	mov    0x8(%rax),%rsi
    755a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7561:	48 89 0d 80 ae 01 00 	mov    %rcx,0x1ae80(%rip)        # 223e8 <fwp_handlers>
    7568:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    756f:	48 89 0d 82 ae 01 00 	mov    %rcx,0x1ae82(%rip)        # 223f8 <fwp_cleanups>
    7576:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    757d:	48 89 0d 6c ae 01 00 	mov    %rcx,0x1ae6c(%rip)        # 223f0 <fwp_foreign_callbacks>
    7584:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    758b:	48 89 0d 4e ae 01 00 	mov    %rcx,0x1ae4e(%rip)        # 223e0 <fwp_state>
    7592:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7599:	48 89 0d 38 ae 01 00 	mov    %rcx,0x1ae38(%rip)        # 223d8 <fwp_state_len>
    75a0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    75a7:	48 89 0d 22 ae 01 00 	mov    %rcx,0x1ae22(%rip)        # 223d0 <fwp_state_cap>
    75ae:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    75b5:	48 89 0d 0c ae 01 00 	mov    %rcx,0x1ae0c(%rip)        # 223c8 <fwp_state_owners>
    75bc:	e8 cf be ff ff       	call   3490 <swapcontext@plt>
    75c1:	f3 0f 1e fa          	endbr64
    75c5:	e8 e6 fc ff ff       	call   72b0 <fwp_free_zombie>
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	8b 05 32 8b 01 00    	mov    0x18b32(%rip),%eax        # 20108 <fwp_slice>
    75d6:	85 c0                	test   %eax,%eax
    75d8:	74 36                	je     7610 <fwp_block+0x160>
    75da:	48 83 c4 08          	add    $0x8,%rsp
    75de:	c3                   	ret
    75df:	90                   	nop
    75e0:	e8 7b d9 ff ff       	call   4f60 <fwp_poll_events>
    75e5:	48 8b 05 3c 91 01 00 	mov    0x1913c(%rip),%rax        # 20728 <fwp_ready_head>
    75ec:	48 85 c0             	test   %rax,%rax
    75ef:	0f 85 db fe ff ff    	jne    74d0 <fwp_block+0x20>
    75f5:	eb e9                	jmp    75e0 <fwp_block+0x130>
    75f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    75fe:	00 00 
    7600:	48 c7 05 15 91 01 00 	movq   $0x0,0x19115(%rip)        # 20720 <fwp_ready_tail>
    7607:	00 00 00 00 
    760b:	e9 d7 fe ff ff       	jmp    74e7 <fwp_block+0x37>
    7610:	48 8d 3d 0a 4b 00 00 	lea    0x4b0a(%rip),%rdi        # c121 <_IO_stdin_used+0x121>
    7617:	e8 84 bd ff ff       	call   33a0 <getenv@plt>
    761c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7621:	48 85 c0             	test   %rax,%rax
    7624:	74 05                	je     762b <fwp_block+0x17b>
    7626:	80 38 00             	cmpb   $0x0,(%rax)
    7629:	75 0b                	jne    7636 <fwp_block+0x186>
    762b:	89 15 d7 8a 01 00    	mov    %edx,0x18ad7(%rip)        # 20108 <fwp_slice>
    7631:	48 83 c4 08          	add    $0x8,%rsp
    7635:	c3                   	ret
    7636:	ba 0a 00 00 00       	mov    $0xa,%edx
    763b:	31 f6                	xor    %esi,%esi
    763d:	48 89 c7             	mov    %rax,%rdi
    7640:	e8 0b bf ff ff       	call   3550 <strtoll@plt>
    7645:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7649:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7650:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7655:	0f 46 d0             	cmovbe %eax,%edx
    7658:	eb d1                	jmp    762b <fwp_block+0x17b>
    765a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007660 <fwp_owned_entry161>:
    7660:	f3 0f 1e fa          	endbr64
    7664:	41 56                	push   %r14
    7666:	55                   	push   %rbp
    7667:	53                   	push   %rbx
    7668:	48 83 ec 10          	sub    $0x10,%rsp
    766c:	48 8b 07             	mov    (%rdi),%rax
    766f:	48 03 47 10          	add    0x10(%rdi),%rax
    7673:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7678:	0f 80 b7 01 00 00    	jo     7835 <fwp_owned_entry161+0x1d5>
    767e:	49 89 c6             	mov    %rax,%r14
    7681:	8b 05 7d a4 01 00    	mov    0x1a47d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    7687:	48 8d 15 d2 90 01 00 	lea    0x190d2(%rip),%rdx        # 20760 <fwp_heap>
    768e:	85 c0                	test   %eax,%eax
    7690:	0f 84 52 01 00 00    	je     77e8 <fwp_owned_entry161+0x188>
    7696:	0f b6 05 65 a0 01 00 	movzbl 0x1a065(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    769d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    76a4:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    76a8:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    76ac:	48 8b 18             	mov    (%rax),%rbx
    76af:	48 85 db             	test   %rbx,%rbx
    76b2:	0f 84 08 01 00 00    	je     77c0 <fwp_owned_entry161+0x160>
    76b8:	48 8b 13             	mov    (%rbx),%rdx
    76bb:	48 f7 d2             	not    %rdx
    76be:	48 89 10             	mov    %rdx,(%rax)
    76c1:	48 83 fd 18          	cmp    $0x18,%rbp
    76c5:	76 27                	jbe    76ee <fwp_owned_entry161+0x8e>
    76c7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    76cb:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    76cf:	31 f6                	xor    %esi,%esi
    76d1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    76d7:	48 c1 e8 03          	shr    $0x3,%rax
    76db:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    76e2:	00 
    76e3:	e8 d8 bd ff ff       	call   34c0 <memset@plt>
    76e8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    76ee:	48 89 e8             	mov    %rbp,%rax
    76f1:	48 03 05 88 a4 01 00 	add    0x1a488(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    76f8:	0f 82 3c 01 00 00    	jb     783a <fwp_owned_entry161+0x1da>
    76fe:	48 39 05 83 a4 01 00 	cmp    %rax,0x1a483(%rip)        # 21b88 <fwp_heap+0x1428>
    7705:	48 89 05 74 a4 01 00 	mov    %rax,0x1a474(%rip)        # 21b80 <fwp_heap+0x1420>
    770c:	73 07                	jae    7715 <fwp_owned_entry161+0xb5>
    770e:	48 89 05 73 a4 01 00 	mov    %rax,0x1a473(%rip)        # 21b88 <fwp_heap+0x1428>
    7715:	66 0f ef c9          	pxor   %xmm1,%xmm1
    7719:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    771e:	f2 0f 58 0d 72 a4 01 	addsd  0x1a472(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7725:	00 
    7726:	f2 0f 11 0d 6a a4 01 	movsd  %xmm1,0x1a46a(%rip)        # 21b98 <fwp_heap+0x1438>
    772d:	00 
    772e:	48 8b 05 13 54 00 00 	mov    0x5413(%rip),%rax        # cb48 <msg.4+0xc8>
    7735:	66 49 0f 6e d6       	movq   %r14,%xmm2
    773a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    773e:	48 89 03             	mov    %rax,(%rbx)
    7741:	48 89 d8             	mov    %rbx,%rax
    7744:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7748:	48 8b 15 e9 a3 01 00 	mov    0x1a3e9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    774f:	48 2b 05 ba a3 01 00 	sub    0x1a3ba(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7756:	48 c1 e2 10          	shl    $0x10,%rdx
    775a:	48 39 d0             	cmp    %rdx,%rax
    775d:	73 53                	jae    77b2 <fwp_owned_entry161+0x152>
    775f:	48 89 c2             	mov    %rax,%rdx
    7762:	48 c1 ea 10          	shr    $0x10,%rdx
    7766:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    776a:	48 8b 15 e7 a3 01 00 	mov    0x1a3e7(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7771:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7775:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7779:	48 85 ed             	test   %rbp,%rbp
    777c:	74 34                	je     77b2 <fwp_owned_entry161+0x152>
    777e:	0f b6 0a             	movzbl (%rdx),%ecx
    7781:	80 f9 02             	cmp    $0x2,%cl
    7784:	0f 84 86 00 00 00    	je     7810 <fwp_owned_entry161+0x1b0>
    778a:	80 f9 01             	cmp    $0x1,%cl
    778d:	75 23                	jne    77b2 <fwp_owned_entry161+0x152>
    778f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7792:	0f b7 c0             	movzwl %ax,%eax
    7795:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7798:	48 0f af c1          	imul   %rcx,%rax
    779c:	48 c1 e8 20          	shr    $0x20,%rax
    77a0:	48 39 d0             	cmp    %rdx,%rax
    77a3:	73 0d                	jae    77b2 <fwp_owned_entry161+0x152>
    77a5:	48 01 c5             	add    %rax,%rbp
    77a8:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    77ac:	74 7a                	je     7828 <fwp_owned_entry161+0x1c8>
    77ae:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    77b2:	48 83 c4 10          	add    $0x10,%rsp
    77b6:	48 89 d8             	mov    %rbx,%rax
    77b9:	5b                   	pop    %rbx
    77ba:	5d                   	pop    %rbp
    77bb:	41 5e                	pop    %r14
    77bd:	c3                   	ret
    77be:	66 90                	xchg   %ax,%ax
    77c0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    77c4:	48 85 db             	test   %rbx,%rbx
    77c7:	74 1f                	je     77e8 <fwp_owned_entry161+0x188>
    77c9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    77cd:	48 29 da             	sub    %rbx,%rdx
    77d0:	48 39 ea             	cmp    %rbp,%rdx
    77d3:	72 13                	jb     77e8 <fwp_owned_entry161+0x188>
    77d5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    77d9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    77dd:	e9 df fe ff ff       	jmp    76c1 <fwp_owned_entry161+0x61>
    77e2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    77e8:	31 f6                	xor    %esi,%esi
    77ea:	bf 18 00 00 00       	mov    $0x18,%edi
    77ef:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    77f5:	e8 56 e2 ff ff       	call   5a50 <fwp_heap_alloc>
    77fa:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    7800:	48 89 c3             	mov    %rax,%rbx
    7803:	e9 26 ff ff ff       	jmp    772e <fwp_owned_entry161+0xce>
    7808:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    780f:	00 
    7810:	66 85 c0             	test   %ax,%ax
    7813:	74 93                	je     77a8 <fwp_owned_entry161+0x148>
    7815:	48 83 c4 10          	add    $0x10,%rsp
    7819:	48 89 d8             	mov    %rbx,%rax
    781c:	5b                   	pop    %rbx
    781d:	5d                   	pop    %rbp
    781e:	41 5e                	pop    %r14
    7820:	c3                   	ret
    7821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7828:	48 89 ef             	mov    %rbp,%rdi
    782b:	e8 e0 da ff ff       	call   5310 <fwp_rc_forget_slot>
    7830:	e9 79 ff ff ff       	jmp    77ae <fwp_owned_entry161+0x14e>
    7835:	e8 c6 be ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    783a:	e8 71 c4 ff ff       	call   3cb0 <fwp_heap_oom>
    783f:	90                   	nop

0000000000007840 <e161>:
    7840:	f3 0f 1e fa          	endbr64
    7844:	41 56                	push   %r14
    7846:	55                   	push   %rbp
    7847:	53                   	push   %rbx
    7848:	48 83 ec 10          	sub    $0x10,%rsp
    784c:	48 8b 07             	mov    (%rdi),%rax
    784f:	48 03 47 10          	add    0x10(%rdi),%rax
    7853:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    7858:	0f 80 bf 01 00 00    	jo     7a1d <e161+0x1dd>
    785e:	49 89 c6             	mov    %rax,%r14
    7861:	8b 05 9d a2 01 00    	mov    0x1a29d(%rip),%eax        # 21b04 <fwp_heap+0x13a4>
    7867:	48 8d 15 f2 8e 01 00 	lea    0x18ef2(%rip),%rdx        # 20760 <fwp_heap>
    786e:	85 c0                	test   %eax,%eax
    7870:	0f 84 62 01 00 00    	je     79d8 <e161+0x198>
    7876:	0f b6 05 85 9e 01 00 	movzbl 0x19e85(%rip),%eax        # 21702 <fwp_heap+0xfa2>
    787d:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    7884:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    7888:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    788c:	48 8b 18             	mov    (%rax),%rbx
    788f:	48 85 db             	test   %rbx,%rbx
    7892:	0f 84 18 01 00 00    	je     79b0 <e161+0x170>
    7898:	48 8b 13             	mov    (%rbx),%rdx
    789b:	48 f7 d2             	not    %rdx
    789e:	48 89 10             	mov    %rdx,(%rax)
    78a1:	48 83 fd 18          	cmp    $0x18,%rbp
    78a5:	76 27                	jbe    78ce <e161+0x8e>
    78a7:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    78ab:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    78af:	31 f6                	xor    %esi,%esi
    78b1:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    78b7:	48 c1 e8 03          	shr    $0x3,%rax
    78bb:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    78c2:	00 
    78c3:	e8 f8 bb ff ff       	call   34c0 <memset@plt>
    78c8:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    78ce:	48 89 e8             	mov    %rbp,%rax
    78d1:	48 03 05 a8 a2 01 00 	add    0x1a2a8(%rip),%rax        # 21b80 <fwp_heap+0x1420>
    78d8:	0f 82 44 01 00 00    	jb     7a22 <e161+0x1e2>
    78de:	48 39 05 a3 a2 01 00 	cmp    %rax,0x1a2a3(%rip)        # 21b88 <fwp_heap+0x1428>
    78e5:	48 89 05 94 a2 01 00 	mov    %rax,0x1a294(%rip)        # 21b80 <fwp_heap+0x1420>
    78ec:	73 07                	jae    78f5 <e161+0xb5>
    78ee:	48 89 05 93 a2 01 00 	mov    %rax,0x1a293(%rip)        # 21b88 <fwp_heap+0x1428>
    78f5:	66 0f ef c9          	pxor   %xmm1,%xmm1
    78f9:	f2 48 0f 2a cd       	cvtsi2sd %rbp,%xmm1
    78fe:	f2 0f 58 0d 92 a2 01 	addsd  0x1a292(%rip),%xmm1        # 21b98 <fwp_heap+0x1438>
    7905:	00 
    7906:	f2 0f 11 0d 8a a2 01 	movsd  %xmm1,0x1a28a(%rip)        # 21b98 <fwp_heap+0x1438>
    790d:	00 
    790e:	48 8b 05 33 52 00 00 	mov    0x5233(%rip),%rax        # cb48 <msg.4+0xc8>
    7915:	66 49 0f 6e d6       	movq   %r14,%xmm2
    791a:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    791e:	48 89 03             	mov    %rax,(%rbx)
    7921:	48 89 d8             	mov    %rbx,%rax
    7924:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
    7928:	48 8b 15 09 a2 01 00 	mov    0x1a209(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    792f:	48 2b 05 da a1 01 00 	sub    0x1a1da(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7936:	48 c1 e2 10          	shl    $0x10,%rdx
    793a:	48 39 d0             	cmp    %rdx,%rax
    793d:	73 57                	jae    7996 <e161+0x156>
    793f:	48 89 c2             	mov    %rax,%rdx
    7942:	48 c1 ea 10          	shr    $0x10,%rdx
    7946:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    794a:	48 8b 15 07 a2 01 00 	mov    0x1a207(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7951:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7955:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    7959:	48 85 ed             	test   %rbp,%rbp
    795c:	74 38                	je     7996 <e161+0x156>
    795e:	0f b6 0a             	movzbl (%rdx),%ecx
    7961:	80 f9 02             	cmp    $0x2,%cl
    7964:	0f 84 96 00 00 00    	je     7a00 <e161+0x1c0>
    796a:	80 f9 01             	cmp    $0x1,%cl
    796d:	75 27                	jne    7996 <e161+0x156>
    796f:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7972:	0f b7 c0             	movzwl %ax,%eax
    7975:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7978:	48 0f af c1          	imul   %rcx,%rax
    797c:	48 c1 e8 20          	shr    $0x20,%rax
    7980:	48 39 d0             	cmp    %rdx,%rax
    7983:	73 11                	jae    7996 <e161+0x156>
    7985:	48 01 c5             	add    %rax,%rbp
    7988:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    798c:	0f 84 7e 00 00 00    	je     7a10 <e161+0x1d0>
    7992:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    7996:	48 89 df             	mov    %rbx,%rdi
    7999:	e8 32 ef ff ff       	call   68d0 <fwp_rc_share>
    799e:	48 83 c4 10          	add    $0x10,%rsp
    79a2:	48 89 d8             	mov    %rbx,%rax
    79a5:	5b                   	pop    %rbx
    79a6:	5d                   	pop    %rbp
    79a7:	41 5e                	pop    %r14
    79a9:	c3                   	ret
    79aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79b0:	48 8b 58 08          	mov    0x8(%rax),%rbx
    79b4:	48 85 db             	test   %rbx,%rbx
    79b7:	74 1f                	je     79d8 <e161+0x198>
    79b9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    79bd:	48 29 da             	sub    %rbx,%rdx
    79c0:	48 39 ea             	cmp    %rbp,%rdx
    79c3:	72 13                	jb     79d8 <e161+0x198>
    79c5:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    79c9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    79cd:	e9 cf fe ff ff       	jmp    78a1 <e161+0x61>
    79d2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    79d8:	31 f6                	xor    %esi,%esi
    79da:	bf 18 00 00 00       	mov    $0x18,%edi
    79df:	66 0f d6 44 24 08    	movq   %xmm0,0x8(%rsp)
    79e5:	e8 66 e0 ff ff       	call   5a50 <fwp_heap_alloc>
    79ea:	f3 0f 7e 44 24 08    	movq   0x8(%rsp),%xmm0
    79f0:	48 89 c3             	mov    %rax,%rbx
    79f3:	e9 16 ff ff ff       	jmp    790e <e161+0xce>
    79f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    79ff:	00 
    7a00:	66 85 c0             	test   %ax,%ax
    7a03:	75 91                	jne    7996 <e161+0x156>
    7a05:	eb 81                	jmp    7988 <e161+0x148>
    7a07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a0e:	00 00 
    7a10:	48 89 ef             	mov    %rbp,%rdi
    7a13:	e8 f8 d8 ff ff       	call   5310 <fwp_rc_forget_slot>
    7a18:	e9 75 ff ff ff       	jmp    7992 <e161+0x152>
    7a1d:	e8 de bc ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    7a22:	e8 89 c2 ff ff       	call   3cb0 <fwp_heap_oom>
    7a27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7a2e:	00 00 

0000000000007a30 <fwp_drop4>:
    7a30:	48 8b 15 01 a1 01 00 	mov    0x1a101(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7a37:	48 89 f8             	mov    %rdi,%rax
    7a3a:	48 2b 05 cf a0 01 00 	sub    0x1a0cf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7a41:	48 c1 e2 10          	shl    $0x10,%rdx
    7a45:	48 39 d0             	cmp    %rdx,%rax
    7a48:	0f 83 52 01 00 00    	jae    7ba0 <fwp_drop4+0x170>
    7a4e:	48 83 ec 18          	sub    $0x18,%rsp
    7a52:	4c 8d 05 07 8d 01 00 	lea    0x18d07(%rip),%r8        # 20760 <fwp_heap>
    7a59:	48 89 c2             	mov    %rax,%rdx
    7a5c:	49 8b b0 f8 13 00 00 	mov    0x13f8(%r8),%rsi
    7a63:	48 c1 ea 10          	shr    $0x10,%rdx
    7a67:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7a6b:	48 8d 0c d6          	lea    (%rsi,%rdx,8),%rcx
    7a6f:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7a73:	48 85 d2             	test   %rdx,%rdx
    7a76:	74 46                	je     7abe <fwp_drop4+0x8e>
    7a78:	44 0f b6 09          	movzbl (%rcx),%r9d
    7a7c:	41 80 f9 02          	cmp    $0x2,%r9b
    7a80:	0f 84 ca 00 00 00    	je     7b50 <fwp_drop4+0x120>
    7a86:	41 80 f9 01          	cmp    $0x1,%r9b
    7a8a:	75 32                	jne    7abe <fwp_drop4+0x8e>
    7a8c:	44 8b 49 18          	mov    0x18(%rcx),%r9d
    7a90:	0f b7 c0             	movzwl %ax,%eax
    7a93:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7a96:	49 0f af c1          	imul   %r9,%rax
    7a9a:	48 c1 e8 20          	shr    $0x20,%rax
    7a9e:	48 39 c8             	cmp    %rcx,%rax
    7aa1:	73 1b                	jae    7abe <fwp_drop4+0x8e>
    7aa3:	48 01 c2             	add    %rax,%rdx
    7aa6:	0f b6 02             	movzbl (%rdx),%eax
    7aa9:	84 c0                	test   %al,%al
    7aab:	74 11                	je     7abe <fwp_drop4+0x8e>
    7aad:	3c 01                	cmp    $0x1,%al
    7aaf:	74 17                	je     7ac8 <fwp_drop4+0x98>
    7ab1:	3c ff                	cmp    $0xff,%al
    7ab3:	0f 84 ef 00 00 00    	je     7ba8 <fwp_drop4+0x178>
    7ab9:	83 e8 01             	sub    $0x1,%eax
    7abc:	88 02                	mov    %al,(%rdx)
    7abe:	48 83 c4 18          	add    $0x18,%rsp
    7ac2:	c3                   	ret
    7ac3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ac8:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    7acc:	0f 88 8e 00 00 00    	js     7b60 <fwp_drop4+0x130>
    7ad2:	48 8b 15 5f a0 01 00 	mov    0x1a05f(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7ad9:	48 89 f8             	mov    %rdi,%rax
    7adc:	48 2b 05 2d a0 01 00 	sub    0x1a02d(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7ae3:	48 c1 e2 10          	shl    $0x10,%rdx
    7ae7:	48 39 d0             	cmp    %rdx,%rax
    7aea:	73 d2                	jae    7abe <fwp_drop4+0x8e>
    7aec:	48 89 c2             	mov    %rax,%rdx
    7aef:	48 c1 ea 10          	shr    $0x10,%rdx
    7af3:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7af7:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
    7afb:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7aff:	48 85 c9             	test   %rcx,%rcx
    7b02:	74 ba                	je     7abe <fwp_drop4+0x8e>
    7b04:	0f b6 32             	movzbl (%rdx),%esi
    7b07:	40 80 fe 02          	cmp    $0x2,%sil
    7b0b:	74 33                	je     7b40 <fwp_drop4+0x110>
    7b0d:	40 80 fe 01          	cmp    $0x1,%sil
    7b11:	75 ab                	jne    7abe <fwp_drop4+0x8e>
    7b13:	8b 72 18             	mov    0x18(%rdx),%esi
    7b16:	0f b7 c0             	movzwl %ax,%eax
    7b19:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7b1c:	48 0f af c6          	imul   %rsi,%rax
    7b20:	48 c1 e8 20          	shr    $0x20,%rax
    7b24:	48 39 d0             	cmp    %rdx,%rax
    7b27:	73 95                	jae    7abe <fwp_drop4+0x8e>
    7b29:	48 01 c1             	add    %rax,%rcx
    7b2c:	80 39 01             	cmpb   $0x1,(%rcx)
    7b2f:	75 8d                	jne    7abe <fwp_drop4+0x8e>
    7b31:	48 83 c4 18          	add    $0x18,%rsp
    7b35:	e9 16 da ff ff       	jmp    5550 <fwp_mem_free>
    7b3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b40:	66 85 c0             	test   %ax,%ax
    7b43:	74 e7                	je     7b2c <fwp_drop4+0xfc>
    7b45:	48 83 c4 18          	add    $0x18,%rsp
    7b49:	c3                   	ret
    7b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7b50:	66 85 c0             	test   %ax,%ax
    7b53:	0f 84 4d ff ff ff    	je     7aa6 <fwp_drop4+0x76>
    7b59:	48 83 c4 18          	add    $0x18,%rsp
    7b5d:	c3                   	ret
    7b5e:	66 90                	xchg   %ax,%ax
    7b60:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    7b64:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7b69:	e8 e2 ed ff ff       	call   6950 <fwp_rc_free_arr>
    7b6e:	4c 8d 05 eb 8b 01 00 	lea    0x18beb(%rip),%r8        # 20760 <fwp_heap>
    7b75:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7b7a:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7b81:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7b88:	48 c1 e2 10          	shl    $0x10,%rdx
    7b8c:	48 39 d0             	cmp    %rdx,%rax
    7b8f:	0f 83 29 ff ff ff    	jae    7abe <fwp_drop4+0x8e>
    7b95:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    7b9a:	e9 ba fe ff ff       	jmp    7a59 <fwp_drop4+0x29>
    7b9f:	90                   	nop
    7ba0:	c3                   	ret
    7ba1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7ba8:	48 89 d0             	mov    %rdx,%rax
    7bab:	48 c1 e8 11          	shr    $0x11,%rax
    7baf:	48 31 d0             	xor    %rdx,%rax
    7bb2:	48 89 c1             	mov    %rax,%rcx
    7bb5:	48 c1 e9 09          	shr    $0x9,%rcx
    7bb9:	48 31 c8             	xor    %rcx,%rax
    7bbc:	0f b6 c8             	movzbl %al,%ecx
    7bbf:	49 8b 84 c8 48 14 00 	mov    0x1448(%r8,%rcx,8),%rax
    7bc6:	00 
    7bc7:	48 85 c0             	test   %rax,%rax
    7bca:	75 1d                	jne    7be9 <fwp_drop4+0x1b9>
    7bcc:	eb 56                	jmp    7c24 <fwp_drop4+0x1f4>
    7bce:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7bdc:	00 00 00 00 
    7be0:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7be4:	48 85 c0             	test   %rax,%rax
    7be7:	74 3b                	je     7c24 <fwp_drop4+0x1f4>
    7be9:	48 89 c1             	mov    %rax,%rcx
    7bec:	48 39 10             	cmp    %rdx,(%rax)
    7bef:	75 ef                	jne    7be0 <fwp_drop4+0x1b0>
    7bf1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7bf5:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7bf9:	48 89 48 08          	mov    %rcx,0x8(%rax)
    7bfd:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    7c04:	0f 85 b4 fe ff ff    	jne    7abe <fwp_drop4+0x8e>
    7c0a:	48 89 d7             	mov    %rdx,%rdi
    7c0d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7c12:	e8 f9 d6 ff ff       	call   5310 <fwp_rc_forget_slot>
    7c17:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7c1c:	c6 02 fe             	movb   $0xfe,(%rdx)
    7c1f:	e9 9a fe ff ff       	jmp    7abe <fwp_drop4+0x8e>
    7c24:	48 8d 3d 6d 4b 00 00 	lea    0x4b6d(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    7c2b:	e8 70 c5 ff ff       	call   41a0 <fwp_trap>

0000000000007c30 <fwp_caps161>:
    7c30:	f3 0f 1e fa          	endbr64
    7c34:	85 f6                	test   %esi,%esi
    7c36:	74 08                	je     7c40 <fwp_caps161+0x10>
    7c38:	c3                   	ret
    7c39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7c40:	48 8b 15 f1 9e 01 00 	mov    0x19ef1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7c47:	48 89 f8             	mov    %rdi,%rax
    7c4a:	48 2b 05 bf 9e 01 00 	sub    0x19ebf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7c51:	48 c1 e2 10          	shl    $0x10,%rdx
    7c55:	48 39 d0             	cmp    %rdx,%rax
    7c58:	73 de                	jae    7c38 <fwp_caps161+0x8>
    7c5a:	48 89 c2             	mov    %rax,%rdx
    7c5d:	48 c1 ea 10          	shr    $0x10,%rdx
    7c61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7c65:	48 8b 15 ec 9e 01 00 	mov    0x19eec(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7c6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7c70:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7c74:	48 85 c9             	test   %rcx,%rcx
    7c77:	74 bf                	je     7c38 <fwp_caps161+0x8>
    7c79:	0f b6 32             	movzbl (%rdx),%esi
    7c7c:	40 80 fe 02          	cmp    $0x2,%sil
    7c80:	74 2e                	je     7cb0 <fwp_caps161+0x80>
    7c82:	40 80 fe 01          	cmp    $0x1,%sil
    7c86:	75 b0                	jne    7c38 <fwp_caps161+0x8>
    7c88:	8b 72 18             	mov    0x18(%rdx),%esi
    7c8b:	0f b7 c0             	movzwl %ax,%eax
    7c8e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7c91:	48 0f af c6          	imul   %rsi,%rax
    7c95:	48 c1 e8 20          	shr    $0x20,%rax
    7c99:	48 39 d0             	cmp    %rdx,%rax
    7c9c:	73 9a                	jae    7c38 <fwp_caps161+0x8>
    7c9e:	48 01 c1             	add    %rax,%rcx
    7ca1:	80 39 01             	cmpb   $0x1,(%rcx)
    7ca4:	75 92                	jne    7c38 <fwp_caps161+0x8>
    7ca6:	e9 a5 d8 ff ff       	jmp    5550 <fwp_mem_free>
    7cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7cb0:	66 85 c0             	test   %ax,%ax
    7cb3:	74 ec                	je     7ca1 <fwp_caps161+0x71>
    7cb5:	c3                   	ret
    7cb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7cbd:	00 00 00 

0000000000007cc0 <fwp_args12>:
    7cc0:	f3 0f 1e fa          	endbr64
    7cc4:	85 d2                	test   %edx,%edx
    7cc6:	74 04                	je     7ccc <fwp_args12+0xc>
    7cc8:	85 f6                	test   %esi,%esi
    7cca:	74 04                	je     7cd0 <fwp_args12+0x10>
    7ccc:	c3                   	ret
    7ccd:	0f 1f 00             	nopl   (%rax)
    7cd0:	48 8b 15 61 9e 01 00 	mov    0x19e61(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7cd7:	48 8b 07             	mov    (%rdi),%rax
    7cda:	48 2b 05 2f 9e 01 00 	sub    0x19e2f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7ce1:	48 c1 e2 10          	shl    $0x10,%rdx
    7ce5:	48 39 d0             	cmp    %rdx,%rax
    7ce8:	73 e2                	jae    7ccc <fwp_args12+0xc>
    7cea:	48 89 c2             	mov    %rax,%rdx
    7ced:	48 c1 ea 10          	shr    $0x10,%rdx
    7cf1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7cf5:	48 8b 15 5c 9e 01 00 	mov    0x19e5c(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7cfc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d00:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d04:	48 85 ff             	test   %rdi,%rdi
    7d07:	74 c3                	je     7ccc <fwp_args12+0xc>
    7d09:	0f b6 0a             	movzbl (%rdx),%ecx
    7d0c:	80 f9 02             	cmp    $0x2,%cl
    7d0f:	74 2f                	je     7d40 <fwp_args12+0x80>
    7d11:	80 f9 01             	cmp    $0x1,%cl
    7d14:	75 b6                	jne    7ccc <fwp_args12+0xc>
    7d16:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d19:	0f b7 c0             	movzwl %ax,%eax
    7d1c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d1f:	48 0f af c1          	imul   %rcx,%rax
    7d23:	48 c1 e8 20          	shr    $0x20,%rax
    7d27:	48 39 d0             	cmp    %rdx,%rax
    7d2a:	73 a0                	jae    7ccc <fwp_args12+0xc>
    7d2c:	48 01 c7             	add    %rax,%rdi
    7d2f:	0f b6 07             	movzbl (%rdi),%eax
    7d32:	84 c0                	test   %al,%al
    7d34:	74 96                	je     7ccc <fwp_args12+0xc>
    7d36:	3c fd                	cmp    $0xfd,%al
    7d38:	77 0c                	ja     7d46 <fwp_args12+0x86>
    7d3a:	83 c0 01             	add    $0x1,%eax
    7d3d:	88 07                	mov    %al,(%rdi)
    7d3f:	c3                   	ret
    7d40:	66 85 c0             	test   %ax,%ax
    7d43:	74 ea                	je     7d2f <fwp_args12+0x6f>
    7d45:	c3                   	ret
    7d46:	e9 a5 d4 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7d4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007d50 <fwp_args23>:
    7d50:	f3 0f 1e fa          	endbr64
    7d54:	85 d2                	test   %edx,%edx
    7d56:	74 04                	je     7d5c <fwp_args23+0xc>
    7d58:	85 f6                	test   %esi,%esi
    7d5a:	74 04                	je     7d60 <fwp_args23+0x10>
    7d5c:	c3                   	ret
    7d5d:	0f 1f 00             	nopl   (%rax)
    7d60:	48 8b 15 d1 9d 01 00 	mov    0x19dd1(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7d67:	48 8b 07             	mov    (%rdi),%rax
    7d6a:	48 2b 05 9f 9d 01 00 	sub    0x19d9f(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7d71:	48 c1 e2 10          	shl    $0x10,%rdx
    7d75:	48 39 d0             	cmp    %rdx,%rax
    7d78:	73 e2                	jae    7d5c <fwp_args23+0xc>
    7d7a:	48 89 c2             	mov    %rax,%rdx
    7d7d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d81:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d85:	48 8b 15 cc 9d 01 00 	mov    0x19dcc(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7d8c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d90:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d94:	48 85 ff             	test   %rdi,%rdi
    7d97:	74 c3                	je     7d5c <fwp_args23+0xc>
    7d99:	0f b6 0a             	movzbl (%rdx),%ecx
    7d9c:	80 f9 02             	cmp    $0x2,%cl
    7d9f:	74 2f                	je     7dd0 <fwp_args23+0x80>
    7da1:	80 f9 01             	cmp    $0x1,%cl
    7da4:	75 b6                	jne    7d5c <fwp_args23+0xc>
    7da6:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7da9:	0f b7 c0             	movzwl %ax,%eax
    7dac:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7daf:	48 0f af c1          	imul   %rcx,%rax
    7db3:	48 c1 e8 20          	shr    $0x20,%rax
    7db7:	48 39 d0             	cmp    %rdx,%rax
    7dba:	73 a0                	jae    7d5c <fwp_args23+0xc>
    7dbc:	48 01 c7             	add    %rax,%rdi
    7dbf:	0f b6 07             	movzbl (%rdi),%eax
    7dc2:	84 c0                	test   %al,%al
    7dc4:	74 96                	je     7d5c <fwp_args23+0xc>
    7dc6:	3c fd                	cmp    $0xfd,%al
    7dc8:	77 0c                	ja     7dd6 <fwp_args23+0x86>
    7dca:	83 c0 01             	add    $0x1,%eax
    7dcd:	88 07                	mov    %al,(%rdi)
    7dcf:	c3                   	ret
    7dd0:	66 85 c0             	test   %ax,%ax
    7dd3:	74 ea                	je     7dbf <fwp_args23+0x6f>
    7dd5:	c3                   	ret
    7dd6:	e9 15 d4 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007de0 <fwp_caps12>:
    7de0:	f3 0f 1e fa          	endbr64
    7de4:	48 83 ec 18          	sub    $0x18,%rsp
    7de8:	8b 57 04             	mov    0x4(%rdi),%edx
    7deb:	48 89 f8             	mov    %rdi,%rax
    7dee:	85 d2                	test   %edx,%edx
    7df0:	0f 84 9a 00 00 00    	je     7e90 <fwp_caps12+0xb0>
    7df6:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    7dfa:	85 f6                	test   %esi,%esi
    7dfc:	0f 85 9e 00 00 00    	jne    7ea0 <fwp_caps12+0xc0>
    7e02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e07:	e8 54 ec ff ff       	call   6a60 <fwp_drop0>
    7e0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e11:	48 8b 0d 20 9d 01 00 	mov    0x19d20(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    7e18:	48 89 c2             	mov    %rax,%rdx
    7e1b:	48 2b 15 ee 9c 01 00 	sub    0x19cee(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    7e22:	48 c1 e1 10          	shl    $0x10,%rcx
    7e26:	48 39 ca             	cmp    %rcx,%rdx
    7e29:	73 6d                	jae    7e98 <fwp_caps12+0xb8>
    7e2b:	48 89 d1             	mov    %rdx,%rcx
    7e2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7e32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e36:	48 8b 0d 1b 9d 01 00 	mov    0x19d1b(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    7e3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e45:	48 85 f6             	test   %rsi,%rsi
    7e48:	74 4e                	je     7e98 <fwp_caps12+0xb8>
    7e4a:	0f b6 39             	movzbl (%rcx),%edi
    7e4d:	40 80 ff 02          	cmp    $0x2,%dil
    7e51:	0f 84 b9 00 00 00    	je     7f10 <fwp_caps12+0x130>
    7e57:	40 80 ff 01          	cmp    $0x1,%dil
    7e5b:	75 3b                	jne    7e98 <fwp_caps12+0xb8>
    7e5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7e60:	0f b7 d2             	movzwl %dx,%edx
    7e63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e66:	48 0f af d7          	imul   %rdi,%rdx
    7e6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7e6e:	48 39 ca             	cmp    %rcx,%rdx
    7e71:	73 25                	jae    7e98 <fwp_caps12+0xb8>
    7e73:	48 01 d6             	add    %rdx,%rsi
    7e76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7e79:	75 1d                	jne    7e98 <fwp_caps12+0xb8>
    7e7b:	48 89 c7             	mov    %rax,%rdi
    7e7e:	48 83 c4 18          	add    $0x18,%rsp
    7e82:	e9 c9 d6 ff ff       	jmp    5550 <fwp_mem_free>
    7e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e8e:	00 00 
    7e90:	85 f6                	test   %esi,%esi
    7e92:	0f 84 79 ff ff ff    	je     7e11 <fwp_caps12+0x31>
    7e98:	48 83 c4 18          	add    $0x18,%rsp
    7e9c:	c3                   	ret
    7e9d:	0f 1f 00             	nopl   (%rax)
    7ea0:	48 8b 05 91 9c 01 00 	mov    0x19c91(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    7ea7:	48 2b 3d 62 9c 01 00 	sub    0x19c62(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    7eae:	48 c1 e0 10          	shl    $0x10,%rax
    7eb2:	48 39 c7             	cmp    %rax,%rdi
    7eb5:	73 e1                	jae    7e98 <fwp_caps12+0xb8>
    7eb7:	48 89 f8             	mov    %rdi,%rax
    7eba:	48 c1 e8 10          	shr    $0x10,%rax
    7ebe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ec2:	48 8b 05 8f 9c 01 00 	mov    0x19c8f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    7ec9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7ecd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ed1:	48 85 c0             	test   %rax,%rax
    7ed4:	74 c2                	je     7e98 <fwp_caps12+0xb8>
    7ed6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ed9:	80 f9 02             	cmp    $0x2,%cl
    7edc:	74 42                	je     7f20 <fwp_caps12+0x140>
    7ede:	80 f9 01             	cmp    $0x1,%cl
    7ee1:	75 b5                	jne    7e98 <fwp_caps12+0xb8>
    7ee3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ee6:	0f b7 ff             	movzwl %di,%edi
    7ee9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7eec:	48 0f af f9          	imul   %rcx,%rdi
    7ef0:	48 c1 ef 20          	shr    $0x20,%rdi
    7ef4:	48 39 d7             	cmp    %rdx,%rdi
    7ef7:	73 9f                	jae    7e98 <fwp_caps12+0xb8>
    7ef9:	48 01 f8             	add    %rdi,%rax
    7efc:	0f b6 10             	movzbl (%rax),%edx
    7eff:	84 d2                	test   %dl,%dl
    7f01:	74 95                	je     7e98 <fwp_caps12+0xb8>
    7f03:	80 fa fd             	cmp    $0xfd,%dl
    7f06:	77 23                	ja     7f2b <fwp_caps12+0x14b>
    7f08:	83 c2 01             	add    $0x1,%edx
    7f0b:	88 10                	mov    %dl,(%rax)
    7f0d:	eb 89                	jmp    7e98 <fwp_caps12+0xb8>
    7f0f:	90                   	nop
    7f10:	66 85 d2             	test   %dx,%dx
    7f13:	0f 85 7f ff ff ff    	jne    7e98 <fwp_caps12+0xb8>
    7f19:	e9 58 ff ff ff       	jmp    7e76 <fwp_caps12+0x96>
    7f1e:	66 90                	xchg   %ax,%ax
    7f20:	66 85 ff             	test   %di,%di
    7f23:	0f 85 6f ff ff ff    	jne    7e98 <fwp_caps12+0xb8>
    7f29:	eb d1                	jmp    7efc <fwp_caps12+0x11c>
    7f2b:	48 89 c7             	mov    %rax,%rdi
    7f2e:	48 83 c4 18          	add    $0x18,%rsp
    7f32:	e9 b9 d2 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    7f37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7f3e:	00 00 

0000000000007f40 <f12>:
    7f40:	41 57                	push   %r15
    7f42:	41 56                	push   %r14
    7f44:	41 55                	push   %r13
    7f46:	41 54                	push   %r12
    7f48:	4c 8d 25 31 f1 ff ff 	lea    -0xecf(%rip),%r12        # 7080 <fwp_tape_scope_release>
    7f4f:	55                   	push   %rbp
    7f50:	53                   	push   %rbx
    7f51:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
    7f58:	48 8b 15 d9 9b 01 00 	mov    0x19bd9(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    7f5f:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
    7f64:	48 c1 e2 10          	shl    $0x10,%rdx
    7f68:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7f6f:	00 00 
    7f71:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
    7f78:	00 
    7f79:	31 c0                	xor    %eax,%eax
    7f7b:	48 8b 05 76 a4 01 00 	mov    0x1a476(%rip),%rax        # 223f8 <fwp_cleanups>
    7f82:	c7 44 24 4c ff ff ff 	movl   $0xffffffff,0x4c(%rsp)
    7f89:	ff 
    7f8a:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
    7f8f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
    7f94:	48 8d 44 24 4c       	lea    0x4c(%rsp),%rax
    7f99:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    7f9e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    7fa3:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
    7fa8:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    7fad:	48 89 05 44 a4 01 00 	mov    %rax,0x1a444(%rip)        # 223f8 <fwp_cleanups>
    7fb4:	48 8d 05 55 80 00 00 	lea    0x8055(%rip),%rax        # 10010 <fc23>
    7fbb:	48 2b 05 4e 9b 01 00 	sub    0x19b4e(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    7fc2:	48 39 d0             	cmp    %rdx,%rax
    7fc5:	73 5d                	jae    8024 <f12+0xe4>
    7fc7:	48 89 c2             	mov    %rax,%rdx
    7fca:	48 c1 ea 10          	shr    $0x10,%rdx
    7fce:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7fd2:	48 8b 15 7f 9b 01 00 	mov    0x19b7f(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    7fd9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7fdd:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7fe1:	48 85 ff             	test   %rdi,%rdi
    7fe4:	74 3e                	je     8024 <f12+0xe4>
    7fe6:	0f b6 0a             	movzbl (%rdx),%ecx
    7fe9:	80 f9 02             	cmp    $0x2,%cl
    7fec:	0f 84 6e 11 00 00    	je     9160 <f12+0x1220>
    7ff2:	80 f9 01             	cmp    $0x1,%cl
    7ff5:	75 2d                	jne    8024 <f12+0xe4>
    7ff7:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ffa:	0f b7 c0             	movzwl %ax,%eax
    7ffd:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8000:	48 0f af c1          	imul   %rcx,%rax
    8004:	48 c1 e8 20          	shr    $0x20,%rax
    8008:	48 39 d0             	cmp    %rdx,%rax
    800b:	73 17                	jae    8024 <f12+0xe4>
    800d:	48 01 c7             	add    %rax,%rdi
    8010:	0f b6 07             	movzbl (%rdi),%eax
    8013:	84 c0                	test   %al,%al
    8015:	74 0d                	je     8024 <f12+0xe4>
    8017:	3c fd                	cmp    $0xfd,%al
    8019:	0f 87 76 13 00 00    	ja     9395 <f12+0x1455>
    801f:	83 c0 01             	add    $0x1,%eax
    8022:	88 07                	mov    %al,(%rdi)
    8024:	48 8d 3d e5 7f 00 00 	lea    0x7fe5(%rip),%rdi        # 10010 <fc23>
    802b:	e8 20 ed ff ff       	call   6d50 <fwp_closure_drop>
    8030:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8035:	48 85 c0             	test   %rax,%rax
    8038:	0f 84 82 12 00 00    	je     92c0 <f12+0x1380>
    803e:	31 d2                	xor    %edx,%edx
    8040:	48 8b 40 10          	mov    0x10(%rax),%rax
    8044:	48 83 c2 01          	add    $0x1,%rdx
    8048:	48 85 c0             	test   %rax,%rax
    804b:	75 f3                	jne    8040 <f12+0x100>
    804d:	48 81 fa ff ff ff 7f 	cmp    $0x7fffffff,%rdx
    8054:	0f 87 01 14 00 00    	ja     945b <f12+0x151b>
    805a:	66 48 0f 6e c2       	movq   %rdx,%xmm0
    805f:	44 8b 05 fa 7f 00 00 	mov    0x7ffa(%rip),%r8d        # 10060 <registered_finish.0>
    8066:	45 85 c0             	test   %r8d,%r8d
    8069:	0f 84 c1 10 00 00    	je     9130 <f12+0x11f0>
    806f:	48 8b 1d 62 80 01 00 	mov    0x18062(%rip),%rbx        # 200d8 <fwp_tape_next_slot>
    8076:	4c 8b 2d 6b 80 01 00 	mov    0x1806b(%rip),%r13        # 200e8 <fwp_ntapes>
    807d:	4c 39 eb             	cmp    %r13,%rbx
    8080:	0f 8d e2 00 00 00    	jge    8168 <f12+0x228>
    8086:	48 6b c3 68          	imul   $0x68,%rbx,%rax
    808a:	48 03 05 5f 80 01 00 	add    0x1805f(%rip),%rax        # 200f0 <fwp_tapes>
    8091:	0f 1f 40 00          	nopl   0x0(%rax)
    8095:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    809c:	00 00 00 00 
    80a0:	8b 78 04             	mov    0x4(%rax),%edi
    80a3:	85 ff                	test   %edi,%edi
    80a5:	75 0c                	jne    80b3 <f12+0x173>
    80a7:	81 38 fe 7f 00 00    	cmpl   $0x7ffe,(%rax)
    80ad:	0f 86 b5 00 00 00    	jbe    8168 <f12+0x228>
    80b3:	48 83 c3 01          	add    $0x1,%rbx
    80b7:	48 83 c0 68          	add    $0x68,%rax
    80bb:	4c 39 eb             	cmp    %r13,%rbx
    80be:	75 e0                	jne    80a0 <f12+0x160>
    80c0:	49 81 fd fe ff 00 00 	cmp    $0xfffe,%r13
    80c7:	0f 8f 09 14 00 00    	jg     94d6 <f12+0x1596>
    80cd:	4c 39 2d 0c 80 01 00 	cmp    %r13,0x1800c(%rip)        # 200e0 <fwp_tapes_cap>
    80d4:	48 8b 2d 15 80 01 00 	mov    0x18015(%rip),%rbp        # 200f0 <fwp_tapes>
    80db:	75 4a                	jne    8127 <f12+0x1e7>
    80dd:	4d 85 ed             	test   %r13,%r13
    80e0:	0f 84 3b 12 00 00    	je     9321 <f12+0x13e1>
    80e6:	4b 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%rbx
    80eb:	b8 ff ff 00 00       	mov    $0xffff,%eax
    80f0:	48 39 c3             	cmp    %rax,%rbx
    80f3:	48 0f 4f d8          	cmovg  %rax,%rbx
    80f7:	48 6b f3 68          	imul   $0x68,%rbx,%rsi
    80fb:	48 89 ef             	mov    %rbp,%rdi
    80fe:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8103:	e8 c8 b4 ff ff       	call   35d0 <realloc@plt>
    8108:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    810d:	48 85 c0             	test   %rax,%rax
    8110:	48 89 c5             	mov    %rax,%rbp
    8113:	0f 84 83 13 00 00    	je     949c <f12+0x155c>
    8119:	48 89 05 d0 7f 01 00 	mov    %rax,0x17fd0(%rip)        # 200f0 <fwp_tapes>
    8120:	48 89 1d b9 7f 01 00 	mov    %rbx,0x17fb9(%rip)        # 200e0 <fwp_tapes_cap>
    8127:	49 6b c5 68          	imul   $0x68,%r13,%rax
    812b:	4c 89 eb             	mov    %r13,%rbx
    812e:	48 01 e8             	add    %rbp,%rax
    8131:	48 8d 78 08          	lea    0x8(%rax),%rdi
    8135:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    813c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    8140:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
    8147:	00 
    8148:	48 29 f8             	sub    %rdi,%rax
    814b:	8d 48 68             	lea    0x68(%rax),%ecx
    814e:	31 c0                	xor    %eax,%eax
    8150:	c1 e9 03             	shr    $0x3,%ecx
    8153:	f3 48 ab             	rep stos %rax,(%rdi)
    8156:	49 8d 45 01          	lea    0x1(%r13),%rax
    815a:	48 89 05 87 7f 01 00 	mov    %rax,0x17f87(%rip)        # 200e8 <fwp_ntapes>
    8161:	eb 15                	jmp    8178 <f12+0x238>
    8163:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8168:	49 39 dd             	cmp    %rbx,%r13
    816b:	0f 84 4f ff ff ff    	je     80c0 <f12+0x180>
    8171:	48 8b 2d 78 7f 01 00 	mov    0x17f78(%rip),%rbp        # 200f0 <fwp_tapes>
    8178:	4c 6b f3 68          	imul   $0x68,%rbx,%r14
    817c:	66 0f 6c c0          	punpcklqdq %xmm0,%xmm0
    8180:	48 8d 3d 38 3f 00 00 	lea    0x3f38(%rip),%rdi        # c0bf <_IO_stdin_used+0xbf>
    8187:	0f 29 04 24          	movaps %xmm0,(%rsp)
    818b:	49 01 ee             	add    %rbp,%r14
    818e:	49 c7 46 60 00 00 00 	movq   $0x0,0x60(%r14)
    8195:	00 
    8196:	e8 05 b2 ff ff       	call   33a0 <getenv@plt>
    819b:	66 0f 6f 04 24       	movdqa (%rsp),%xmm0
    81a0:	48 85 c0             	test   %rax,%rax
    81a3:	74 09                	je     81ae <f12+0x26e>
    81a5:	80 38 30             	cmpb   $0x30,(%rax)
    81a8:	0f 84 82 06 00 00    	je     8830 <f12+0x8f0>
    81ae:	48 83 3d d2 7e 01 00 	cmpq   $0x0,0x17ed2(%rip)        # 20088 <fwp_tape_cached_bytes>
    81b5:	00 
    81b6:	0f 85 04 10 00 00    	jne    91c0 <f12+0x1280>
    81bc:	41 8b 06             	mov    (%r14),%eax
    81bf:	4c 8d 6b 01          	lea    0x1(%rbx),%r13
    81c3:	41 c7 46 04 01 00 00 	movl   $0x1,0x4(%r14)
    81ca:	00 
    81cb:	4c 89 2d 06 7f 01 00 	mov    %r13,0x17f06(%rip)        # 200d8 <fwp_tape_next_slot>
    81d2:	8d 70 01             	lea    0x1(%rax),%esi
    81d5:	48 8b 05 1c a2 01 00 	mov    0x1a21c(%rip),%rax        # 223f8 <fwp_cleanups>
    81dc:	41 0f 11 46 08       	movups %xmm0,0x8(%r14)
    81e1:	41 89 36             	mov    %esi,(%r14)
    81e4:	49 c7 46 50 00 00 00 	movq   $0x0,0x50(%r14)
    81eb:	00 
    81ec:	49 c7 46 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%r14)
    81f3:	ff 
    81f4:	48 85 c0             	test   %rax,%rax
    81f7:	75 13                	jne    820c <f12+0x2cc>
    81f9:	e9 cc 12 00 00       	jmp    94ca <f12+0x158a>
    81fe:	66 90                	xchg   %ax,%ax
    8200:	48 8b 00             	mov    (%rax),%rax
    8203:	48 85 c0             	test   %rax,%rax
    8206:	0f 84 be 12 00 00    	je     94ca <f12+0x158a>
    820c:	4c 39 60 08          	cmp    %r12,0x8(%rax)
    8210:	75 ee                	jne    8200 <f12+0x2c0>
    8212:	48 8b 48 10          	mov    0x10(%rax),%rcx
    8216:	89 df                	mov    %ebx,%edi
    8218:	48 63 01             	movslq (%rcx),%rax
    821b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    821f:	41 89 46 5c          	mov    %eax,0x5c(%r14)
    8223:	85 c0                	test   %eax,%eax
    8225:	78 08                	js     822f <f12+0x2ef>
    8227:	48 6b c0 68          	imul   $0x68,%rax,%rax
    822b:	89 5c 05 58          	mov    %ebx,0x58(%rbp,%rax,1)
    822f:	89 39                	mov    %edi,(%rcx)
    8231:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    8236:	31 c9                	xor    %ecx,%ecx
    8238:	48 89 f8             	mov    %rdi,%rax
    823b:	48 85 ff             	test   %rdi,%rdi
    823e:	0f 84 6c 0d 00 00    	je     8fb0 <f12+0x1070>
    8244:	90                   	nop
    8245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    824c:	00 00 00 00 
    8250:	48 8b 40 10          	mov    0x10(%rax),%rax
    8254:	48 83 c1 01          	add    $0x1,%rcx
    8258:	48 85 c0             	test   %rax,%rax
    825b:	75 f3                	jne    8250 <f12+0x310>
    825d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8262:	0f 1f 00             	nopl   (%rax)
    8265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    826c:	00 00 00 00 
    8270:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8274:	48 83 c0 01          	add    $0x1,%rax
    8278:	48 85 d2             	test   %rdx,%rdx
    827b:	75 f3                	jne    8270 <f12+0x330>
    827d:	48 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdx
    8284:	ff ff 1f 
    8287:	48 39 c2             	cmp    %rax,%rdx
    828a:	0f 82 d7 11 00 00    	jb     9467 <f12+0x1527>
    8290:	48 85 c9             	test   %rcx,%rcx
    8293:	0f 8e 17 0d 00 00    	jle    8fb0 <f12+0x1070>
    8299:	48 39 c1             	cmp    %rax,%rcx
    829c:	48 0f 46 c1          	cmovbe %rcx,%rax
    82a0:	49 89 c4             	mov    %rax,%r12
    82a3:	48 c1 e8 3c          	shr    $0x3c,%rax
    82a7:	0f 85 ba 11 00 00    	jne    9467 <f12+0x1527>
    82ad:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
    82b1:	48 c1 e6 10          	shl    $0x10,%rsi
    82b5:	49 09 f5             	or     %rsi,%r13
    82b8:	4a 8d 3c f5 08 00 00 	lea    0x8(,%r14,8),%rdi
    82bf:	00 
    82c0:	be 02 00 00 00       	mov    $0x2,%esi
    82c5:	e8 86 d7 ff ff       	call   5a50 <fwp_heap_alloc>
    82ca:	4c 89 30             	mov    %r14,(%rax)
    82cd:	48 8b 15 64 98 01 00 	mov    0x19864(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    82d4:	48 89 c3             	mov    %rax,%rbx
    82d7:	48 2b 05 32 98 01 00 	sub    0x19832(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    82de:	48 c1 e2 10          	shl    $0x10,%rdx
    82e2:	48 39 d0             	cmp    %rdx,%rax
    82e5:	0f 83 a5 0f 00 00    	jae    9290 <f12+0x1350>
    82eb:	48 89 c2             	mov    %rax,%rdx
    82ee:	48 c1 ea 10          	shr    $0x10,%rdx
    82f2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    82f6:	48 8b 15 5b 98 01 00 	mov    0x1985b(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    82fd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8301:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    8305:	4d 85 f6             	test   %r14,%r14
    8308:	74 38                	je     8342 <f12+0x402>
    830a:	0f b6 0a             	movzbl (%rdx),%ecx
    830d:	80 f9 02             	cmp    $0x2,%cl
    8310:	0f 84 07 0d 00 00    	je     901d <f12+0x10dd>
    8316:	80 f9 01             	cmp    $0x1,%cl
    8319:	75 27                	jne    8342 <f12+0x402>
    831b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    831e:	0f b7 c0             	movzwl %ax,%eax
    8321:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8324:	48 0f af c1          	imul   %rcx,%rax
    8328:	48 c1 e8 20          	shr    $0x20,%rax
    832c:	48 39 d0             	cmp    %rdx,%rax
    832f:	73 11                	jae    8342 <f12+0x402>
    8331:	49 01 c6             	add    %rax,%r14
    8334:	41 80 3e ff          	cmpb   $0xff,(%r14)
    8338:	0f 84 f2 0f 00 00    	je     9330 <f12+0x13f0>
    833e:	41 c6 06 01          	movb   $0x1,(%r14)
    8342:	4d 85 e4             	test   %r12,%r12
    8345:	74 6c                	je     83b3 <f12+0x473>
    8347:	4c 89 e9             	mov    %r13,%rcx
    834a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    834f:	31 c0                	xor    %eax,%eax
    8351:	48 c1 e1 20          	shl    $0x20,%rcx
    8355:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    835c:	00 00 00 
    835f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8366:	00 00 00 00 
    836a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8371:	00 00 00 00 
    8375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    837c:	00 00 00 00 
    8380:	48 89 c6             	mov    %rax,%rsi
    8383:	f3 0f 7e 42 08       	movq   0x8(%rdx),%xmm0
    8388:	48 01 ce             	add    %rcx,%rsi
    838b:	0f 80 bd 10 00 00    	jo     944e <f12+0x150e>
    8391:	66 48 0f 6e e6       	movq   %rsi,%xmm4
    8396:	48 89 c6             	mov    %rax,%rsi
    8399:	48 83 c0 01          	add    $0x1,%rax
    839d:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    83a1:	48 c1 e6 04          	shl    $0x4,%rsi
    83a5:	0f 11 44 33 08       	movups %xmm0,0x8(%rbx,%rsi,1)
    83aa:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    83ae:	4c 39 e0             	cmp    %r12,%rax
    83b1:	72 cd                	jb     8380 <f12+0x440>
    83b3:	48 8b 03             	mov    (%rbx),%rax
    83b6:	48 d1 e8             	shr    $1,%rax
    83b9:	0f 85 89 0c 00 00    	jne    9048 <f12+0x1108>
    83bf:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
    83c6:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    83cd:	0f 1f 00             	nopl   (%rax)
    83d0:	48 89 df             	mov    %rbx,%rdi
    83d3:	4d 63 e5             	movslq %r13d,%r12
    83d6:	e8 55 f6 ff ff       	call   7a30 <fwp_drop4>
    83db:	4c 89 e7             	mov    %r12,%rdi
    83de:	e8 9d c0 ff ff       	call   4480 <fwp_tape_of>
    83e3:	48 89 c6             	mov    %rax,%rsi
    83e6:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    83eb:	0f 85 f1 10 00 00    	jne    94e2 <f12+0x15a2>
    83f1:	48 89 c7             	mov    %rax,%rdi
    83f4:	e8 07 b8 ff ff       	call   3c00 <fwp_tape_unlink_scope>
    83f9:	4c 8b 76 48          	mov    0x48(%rsi),%r14
    83fd:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    8402:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    8409:	48 8b 6e 08          	mov    0x8(%rsi),%rbp
    840d:	48 8b 56 10          	mov    0x10(%rsi),%rdx
    8411:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8416:	f3 0f 6f 5e 20       	movdqu 0x20(%rsi),%xmm3
    841b:	f3 0f 6f 56 30       	movdqu 0x30(%rsi),%xmm2
    8420:	4c 8b 46 40          	mov    0x40(%rsi),%r8
    8424:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8428:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    842e:	77 19                	ja     8449 <f12+0x509>
    8430:	41 0f b7 c5          	movzwl %r13w,%eax
    8434:	83 e8 01             	sub    $0x1,%eax
    8437:	48 98                	cltq
    8439:	48 3b 05 98 7c 01 00 	cmp    0x17c98(%rip),%rax        # 200d8 <fwp_tape_next_slot>
    8440:	7d 07                	jge    8449 <f12+0x509>
    8442:	48 89 05 8f 7c 01 00 	mov    %rax,0x17c8f(%rip)        # 200d8 <fwp_tape_next_slot>
    8449:	48 8b 05 a8 9f 01 00 	mov    0x19fa8(%rip),%rax        # 223f8 <fwp_cleanups>
    8450:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8454:	48 8d 9c 24 90 00 00 	lea    0x90(%rsp),%rbx
    845b:	00 
    845c:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    8463:	00 
    8464:	0f 11 4e 08          	movups %xmm1,0x8(%rsi)
    8468:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    846d:	48 8d 05 bc c9 ff ff 	lea    -0x3644(%rip),%rax        # 4e30 <fwp_tape_buffers_release>
    8474:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
    8479:	48 8d 44 24 70       	lea    0x70(%rsp),%rax
    847e:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
    8482:	0f 11 4e 30          	movups %xmm1,0x30(%rsi)
    8486:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    848d:	00 
    848e:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    8495:	00 
    8496:	4c 89 84 24 b0 00 00 	mov    %r8,0xb0(%rsp)
    849d:	00 
    849e:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
    84a5:	00 
    84a6:	48 89 05 4b 9f 01 00 	mov    %rax,0x19f4b(%rip)        # 223f8 <fwp_cleanups>
    84ad:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
    84b4:	00 
    84b5:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
    84bc:	00 
    84bd:	0f 11 84 24 b8 00 00 	movups %xmm0,0xb8(%rsp)
    84c4:	00 
    84c5:	4d 85 ff             	test   %r15,%r15
    84c8:	0f 88 a2 0c 00 00    	js     9170 <f12+0x1230>
    84ce:	4c 89 f8             	mov    %r15,%rax
    84d1:	48 c1 f8 20          	sar    $0x20,%rax
    84d5:	49 39 c4             	cmp    %rax,%r12
    84d8:	0f 85 53 0f 00 00    	jne    9431 <f12+0x14f1>
    84de:	45 89 fa             	mov    %r15d,%r10d
    84e1:	4d 89 d4             	mov    %r10,%r12
    84e4:	4c 39 d2             	cmp    %r10,%rdx
    84e7:	0f 8e 38 0f 00 00    	jle    9425 <f12+0x14e5>
    84ed:	4c 39 d5             	cmp    %r10,%rbp
    84f0:	0f 8e ea 0b 00 00    	jle    90e0 <f12+0x11a0>
    84f6:	4c 39 f5             	cmp    %r14,%rbp
    84f9:	0f 8e 31 0d 00 00    	jle    9230 <f12+0x12f0>
    84ff:	49 89 ed             	mov    %rbp,%r13
    8502:	4d 85 f6             	test   %r14,%r14
    8505:	4d 0f 44 f5          	cmove  %r13,%r14
    8509:	eb 2a                	jmp    8535 <f12+0x5f5>
    850b:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8512:	00 00 00 
    8515:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    851c:	00 00 00 00 
    8520:	4b 8d 14 36          	lea    (%r14,%r14,1),%rdx
    8524:	49 81 fe 00 00 00 40 	cmp    $0x40000000,%r14
    852b:	4c 89 e8             	mov    %r13,%rax
    852e:	48 0f 4c c2          	cmovl  %rdx,%rax
    8532:	49 89 c6             	mov    %rax,%r14
    8535:	4d 39 ee             	cmp    %r13,%r14
    8538:	7c e6                	jl     8520 <f12+0x5e0>
    853a:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    853f:	0f 29 14 24          	movaps %xmm2,(%rsp)
    8543:	4d 85 c0             	test   %r8,%r8
    8546:	0f 84 54 0d 00 00    	je     92a0 <f12+0x1360>
    854c:	4c 89 c7             	mov    %r8,%rdi
    854f:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
    8556:	00 
    8557:	e8 74 b0 ff ff       	call   35d0 <realloc@plt>
    855c:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    8561:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    8567:	49 89 c0             	mov    %rax,%r8
    856a:	4d 85 c0             	test   %r8,%r8
    856d:	0f 84 0c 0f 00 00    	je     947f <f12+0x153f>
    8573:	4c 89 84 24 b0 00 00 	mov    %r8,0xb0(%rsp)
    857a:	00 
    857b:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
    8582:	00 
    8583:	4d 85 ed             	test   %r13,%r13
    8586:	0f 85 ca 0d 00 00    	jne    9356 <f12+0x1416>
    858c:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    8593:	4d 85 ff             	test   %r15,%r15
    8596:	78 17                	js     85af <f12+0x66f>
    8598:	45 89 fa             	mov    %r15d,%r10d
    859b:	f2 0f 10 05 8d 45 00 	movsd  0x458d(%rip),%xmm0        # cb30 <msg.4+0xb0>
    85a2:	00 
    85a3:	f2 43 0f 58 04 d0    	addsd  (%r8,%r10,8),%xmm0
    85a9:	f2 43 0f 11 04 d0    	movsd  %xmm0,(%r8,%r10,8)
    85af:	4c 39 e5             	cmp    %r12,%rbp
    85b2:	0f 8f 89 00 00 00    	jg     8641 <f12+0x701>
    85b8:	0f 12 f3             	movhlps %xmm3,%xmm6
    85bb:	66 48 0f 7e d9       	movq   %xmm3,%rcx
    85c0:	0f 12 da             	movhlps %xmm2,%xmm3
    85c3:	49 29 ec             	sub    %rbp,%r12
    85c6:	66 49 0f 7e db       	movq   %xmm3,%r11
    85cb:	66 48 0f 7e f6       	movq   %xmm6,%rsi
    85d0:	66 49 0f 7e d2       	movq   %xmm2,%r10
    85d5:	49 8d 3c e8          	lea    (%r8,%rbp,8),%rdi
    85d9:	4b 8d 14 e3          	lea    (%r11,%r12,8),%rdx
    85dd:	66 0f ef d2          	pxor   %xmm2,%xmm2
    85e1:	48 29 f1             	sub    %rsi,%rcx
    85e4:	4a 8d 04 a6          	lea    (%rsi,%r12,4),%rax
    85e8:	4c 29 df             	sub    %r11,%rdi
    85eb:	4d 29 da             	sub    %r11,%r10
    85ee:	eb 04                	jmp    85f4 <f12+0x6b4>
    85f0:	48 83 e8 04          	sub    $0x4,%rax
    85f4:	f2 0f 10 04 17       	movsd  (%rdi,%rdx,1),%xmm0
    85f9:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
    85fd:	7a 02                	jp     8601 <f12+0x6c1>
    85ff:	74 37                	je     8638 <f12+0x6f8>
    8601:	4c 63 1c 01          	movslq (%rcx,%rax,1),%r11
    8605:	45 85 db             	test   %r11d,%r11d
    8608:	78 16                	js     8620 <f12+0x6e0>
    860a:	f2 41 0f 10 0c 12    	movsd  (%r10,%rdx,1),%xmm1
    8610:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
    8614:	f2 43 0f 58 0c d8    	addsd  (%r8,%r11,8),%xmm1
    861a:	f2 43 0f 11 0c d8    	movsd  %xmm1,(%r8,%r11,8)
    8620:	4c 63 18             	movslq (%rax),%r11
    8623:	45 85 db             	test   %r11d,%r11d
    8626:	78 10                	js     8638 <f12+0x6f8>
    8628:	f2 0f 59 02          	mulsd  (%rdx),%xmm0
    862c:	f2 43 0f 58 04 d8    	addsd  (%r8,%r11,8),%xmm0
    8632:	f2 43 0f 11 04 d8    	movsd  %xmm0,(%r8,%r11,8)
    8638:	48 83 ea 08          	sub    $0x8,%rdx
    863c:	48 39 c6             	cmp    %rax,%rsi
    863f:	75 af                	jne    85f0 <f12+0x6b0>
    8641:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8648:	ff ff 1f 
    864b:	48 39 e8             	cmp    %rbp,%rax
    864e:	0f 82 1f 0e 00 00    	jb     9473 <f12+0x1533>
    8654:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    865b:	00 
    865c:	be 02 00 00 00       	mov    $0x2,%esi
    8661:	4c 89 04 24          	mov    %r8,(%rsp)
    8665:	e8 e6 d3 ff ff       	call   5a50 <fwp_heap_alloc>
    866a:	4c 8b 04 24          	mov    (%rsp),%r8
    866e:	48 89 28             	mov    %rbp,(%rax)
    8671:	49 89 c4             	mov    %rax,%r12
    8674:	31 c0                	xor    %eax,%eax
    8676:	48 85 ed             	test   %rbp,%rbp
    8679:	74 17                	je     8692 <f12+0x752>
    867b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8680:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    8684:	49 89 54 c4 08       	mov    %rdx,0x8(%r12,%rax,8)
    8689:	48 83 c0 01          	add    $0x1,%rax
    868d:	48 39 c5             	cmp    %rax,%rbp
    8690:	75 ee                	jne    8680 <f12+0x740>
    8692:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
    8697:	48 89 df             	mov    %rbx,%rdi
    869a:	4c 89 2d 57 9d 01 00 	mov    %r13,0x19d57(%rip)        # 223f8 <fwp_cleanups>
    86a1:	e8 8a c7 ff ff       	call   4e30 <fwp_tape_buffers_release>
    86a6:	48 8b 15 8b 94 01 00 	mov    0x1948b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    86ad:	4c 89 e0             	mov    %r12,%rax
    86b0:	48 2b 05 59 94 01 00 	sub    0x19459(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    86b7:	48 c1 e2 10          	shl    $0x10,%rdx
    86bb:	48 39 d0             	cmp    %rdx,%rax
    86be:	73 55                	jae    8715 <f12+0x7d5>
    86c0:	48 89 c2             	mov    %rax,%rdx
    86c3:	48 c1 ea 10          	shr    $0x10,%rdx
    86c7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86cb:	48 8b 15 86 94 01 00 	mov    0x19486(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    86d2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86d6:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    86da:	48 85 db             	test   %rbx,%rbx
    86dd:	74 36                	je     8715 <f12+0x7d5>
    86df:	0f b6 0a             	movzbl (%rdx),%ecx
    86e2:	80 f9 02             	cmp    $0x2,%cl
    86e5:	0f 84 b5 0a 00 00    	je     91a0 <f12+0x1260>
    86eb:	80 f9 01             	cmp    $0x1,%cl
    86ee:	75 25                	jne    8715 <f12+0x7d5>
    86f0:	8b 4a 18             	mov    0x18(%rdx),%ecx
    86f3:	0f b7 c0             	movzwl %ax,%eax
    86f6:	8b 52 1c             	mov    0x1c(%rdx),%edx
    86f9:	48 0f af c1          	imul   %rcx,%rax
    86fd:	48 c1 e8 20          	shr    $0x20,%rax
    8701:	48 39 d0             	cmp    %rdx,%rax
    8704:	73 0f                	jae    8715 <f12+0x7d5>
    8706:	48 01 c3             	add    %rax,%rbx
    8709:	80 3b ff             	cmpb   $0xff,(%rbx)
    870c:	0f 84 2b 0c 00 00    	je     933d <f12+0x13fd>
    8712:	c6 03 01             	movb   $0x1,(%rbx)
    8715:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
    871a:	0f 85 2b b0 ff ff    	jne    374b <f12.cold>
    8720:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
    8725:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    872a:	48 89 05 c7 9c 01 00 	mov    %rax,0x19cc7(%rip)        # 223f8 <fwp_cleanups>
    8731:	e8 4a e9 ff ff       	call   7080 <fwp_tape_scope_release>
    8736:	49 8b 04 24          	mov    (%r12),%rax
    873a:	49 89 c5             	mov    %rax,%r13
    873d:	49 0f ba f5 3f       	btr    $0x3f,%r13
    8742:	48 85 c0             	test   %rax,%rax
    8745:	0f 88 b5 07 00 00    	js     8f00 <f12+0xfc0>
    874b:	48 8b 15 e6 93 01 00 	mov    0x193e6(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8752:	4c 89 e0             	mov    %r12,%rax
    8755:	48 2b 05 b4 93 01 00 	sub    0x193b4(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    875c:	48 c1 e2 10          	shl    $0x10,%rdx
    8760:	48 39 d0             	cmp    %rdx,%rax
    8763:	0f 83 97 07 00 00    	jae    8f00 <f12+0xfc0>
    8769:	48 89 c2             	mov    %rax,%rdx
    876c:	48 c1 ea 10          	shr    $0x10,%rdx
    8770:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8774:	48 8b 15 dd 93 01 00 	mov    0x193dd(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    877b:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    877f:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    8783:	48 85 c9             	test   %rcx,%rcx
    8786:	0f 84 74 07 00 00    	je     8f00 <f12+0xfc0>
    878c:	0f b6 32             	movzbl (%rdx),%esi
    878f:	40 80 fe 02          	cmp    $0x2,%sil
    8793:	0f 84 57 07 00 00    	je     8ef0 <f12+0xfb0>
    8799:	40 80 fe 01          	cmp    $0x1,%sil
    879d:	0f 85 5d 07 00 00    	jne    8f00 <f12+0xfc0>
    87a3:	8b 72 18             	mov    0x18(%rdx),%esi
    87a6:	0f b7 c0             	movzwl %ax,%eax
    87a9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    87ac:	48 0f af c6          	imul   %rsi,%rax
    87b0:	48 c1 e8 20          	shr    $0x20,%rax
    87b4:	48 39 d0             	cmp    %rdx,%rax
    87b7:	0f 83 43 07 00 00    	jae    8f00 <f12+0xfc0>
    87bd:	48 01 c1             	add    %rax,%rcx
    87c0:	80 39 01             	cmpb   $0x1,(%rcx)
    87c3:	0f 85 37 07 00 00    	jne    8f00 <f12+0xfc0>
    87c9:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
    87ce:	4c 89 e3             	mov    %r12,%rbx
    87d1:	31 ff                	xor    %edi,%edi
    87d3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    87d8:	f2 0f 10 0d 70 43 00 	movsd  0x4370(%rip),%xmm1        # cb50 <msg.4+0xd0>
    87df:	00 
    87e0:	48 8d 50 08          	lea    0x8(%rax),%rdx
    87e4:	31 c0                	xor    %eax,%eax
    87e6:	4d 85 ed             	test   %r13,%r13
    87e9:	75 2a                	jne    8815 <f12+0x8d5>
    87eb:	eb 53                	jmp    8840 <f12+0x900>
    87ed:	0f 1f 00             	nopl   (%rax)
    87f0:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    87f4:	0f 88 48 0c 00 00    	js     9442 <f12+0x1502>
    87fa:	f2 0f 10 04 c1       	movsd  (%rcx,%rax,8),%xmm0
    87ff:	48 83 c0 01          	add    $0x1,%rax
    8803:	48 83 c2 08          	add    $0x8,%rdx
    8807:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
    880b:	f2 0f 11 42 f8       	movsd  %xmm0,-0x8(%rdx)
    8810:	49 39 c5             	cmp    %rax,%r13
    8813:	74 2b                	je     8840 <f12+0x900>
    8815:	49 8d 4c 24 08       	lea    0x8(%r12),%rcx
    881a:	49 83 3c 24 00       	cmpq   $0x0,(%r12)
    881f:	79 cf                	jns    87f0 <f12+0x8b0>
    8821:	49 8b 4c 24 10       	mov    0x10(%r12),%rcx
    8826:	eb c8                	jmp    87f0 <f12+0x8b0>
    8828:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    882f:	00 
    8830:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    8834:	0f 84 82 f9 ff ff    	je     81bc <f12+0x27c>
    883a:	e9 6f f9 ff ff       	jmp    81ae <f12+0x26e>
    883f:	90                   	nop
    8840:	e8 eb f1 ff ff       	call   7a30 <fwp_drop4>
    8845:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    884a:	31 d2                	xor    %edx,%edx
    884c:	48 89 c8             	mov    %rcx,%rax
    884f:	48 85 c9             	test   %rcx,%rcx
    8852:	0f 84 71 0a 00 00    	je     92c9 <f12+0x1389>
    8858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    885f:	00 
    8860:	48 8b 40 10          	mov    0x10(%rax),%rax
    8864:	48 83 c2 01          	add    $0x1,%rdx
    8868:	48 85 c0             	test   %rax,%rax
    886b:	75 f3                	jne    8860 <f12+0x920>
    886d:	48 8b 03             	mov    (%rbx),%rax
    8870:	49 89 c7             	mov    %rax,%r15
    8873:	49 0f ba f7 3f       	btr    $0x3f,%r15
    8878:	48 85 c0             	test   %rax,%rax
    887b:	0f 88 d4 05 00 00    	js     8e55 <f12+0xf15>
    8881:	48 8b 0d b0 92 01 00 	mov    0x192b0(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    8888:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    888d:	48 2b 05 7c 92 01 00 	sub    0x1927c(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8894:	48 c1 e1 10          	shl    $0x10,%rcx
    8898:	48 39 c8             	cmp    %rcx,%rax
    889b:	0f 83 b4 05 00 00    	jae    8e55 <f12+0xf15>
    88a1:	48 89 c1             	mov    %rax,%rcx
    88a4:	48 c1 e9 10          	shr    $0x10,%rcx
    88a8:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    88ac:	48 8b 0d a5 92 01 00 	mov    0x192a5(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    88b3:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    88b7:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    88bb:	48 85 ff             	test   %rdi,%rdi
    88be:	0f 84 91 05 00 00    	je     8e55 <f12+0xf15>
    88c4:	0f b6 0e             	movzbl (%rsi),%ecx
    88c7:	80 f9 02             	cmp    $0x2,%cl
    88ca:	0f 84 70 05 00 00    	je     8e40 <f12+0xf00>
    88d0:	80 f9 01             	cmp    $0x1,%cl
    88d3:	0f 85 70 05 00 00    	jne    8e49 <f12+0xf09>
    88d9:	8b 4e 18             	mov    0x18(%rsi),%ecx
    88dc:	0f b7 c0             	movzwl %ax,%eax
    88df:	48 0f af c1          	imul   %rcx,%rax
    88e3:	8b 4e 1c             	mov    0x1c(%rsi),%ecx
    88e6:	48 c1 e8 20          	shr    $0x20,%rax
    88ea:	48 39 c8             	cmp    %rcx,%rax
    88ed:	0f 83 56 05 00 00    	jae    8e49 <f12+0xf09>
    88f3:	48 01 c7             	add    %rax,%rdi
    88f6:	80 3f 01             	cmpb   $0x1,(%rdi)
    88f9:	0f 85 4a 05 00 00    	jne    8e49 <f12+0xf09>
    88ff:	4c 39 fa             	cmp    %r15,%rdx
    8902:	4c 0f 46 fa          	cmovbe %rdx,%r15
    8906:	4c 89 fd             	mov    %r15,%rbp
    8909:	4d 85 ff             	test   %r15,%r15
    890c:	0f 84 41 0b 00 00    	je     9453 <f12+0x1513>
    8912:	c7 44 24 38 01 00 00 	movl   $0x1,0x38(%rsp)
    8919:	00 
    891a:	4c 8d 63 08          	lea    0x8(%rbx),%r12
    891e:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    8923:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    8928:	4c 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%r8
    892f:	00 
    8930:	31 c0                	xor    %eax,%eax
    8932:	48 8d 79 08          	lea    0x8(%rcx),%rdi
    8936:	eb 25                	jmp    895d <f12+0xa1d>
    8938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    893f:	00 
    8940:	f2 0f 10 42 08       	movsd  0x8(%rdx),%xmm0
    8945:	f2 0f 5c 04 06       	subsd  (%rsi,%rax,1),%xmm0
    894a:	f2 41 0f 11 04 04    	movsd  %xmm0,(%r12,%rax,1)
    8950:	48 83 c0 08          	add    $0x8,%rax
    8954:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    8958:	49 39 c0             	cmp    %rax,%r8
    895b:	74 1b                	je     8978 <f12+0xa38>
    895d:	48 89 fe             	mov    %rdi,%rsi
    8960:	48 83 3b 00          	cmpq   $0x0,(%rbx)
    8964:	79 da                	jns    8940 <f12+0xa00>
    8966:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    896b:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    896f:	eb cf                	jmp    8940 <f12+0xa00>
    8971:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8978:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    897d:	48 85 d2             	test   %rdx,%rdx
    8980:	0f 84 97 0a 00 00    	je     941d <f12+0x14dd>
    8986:	4c 8b 05 ab 91 01 00 	mov    0x191ab(%rip),%r8        # 21b38 <fwp_heap+0x13d8>
    898d:	4c 8b 15 7c 91 01 00 	mov    0x1917c(%rip),%r10        # 21b10 <fwp_heap+0x13b0>
    8994:	45 31 ff             	xor    %r15d,%r15d
    8997:	4c 8b 1d ba 91 01 00 	mov    0x191ba(%rip),%r11        # 21b58 <fwp_heap+0x13f8>
    899e:	49 c1 e0 10          	shl    $0x10,%r8
    89a2:	eb 1a                	jmp    89be <f12+0xa7e>
    89a4:	0f 1f 40 00          	nopl   0x0(%rax)
    89a8:	49 83 c7 01          	add    $0x1,%r15
    89ac:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    89b0:	49 39 ef             	cmp    %rbp,%r15
    89b3:	0f 83 27 02 00 00    	jae    8be0 <f12+0xca0>
    89b9:	48 85 d2             	test   %rdx,%rdx
    89bc:	74 52                	je     8a10 <f12+0xad0>
    89be:	48 89 d0             	mov    %rdx,%rax
    89c1:	4c 29 d0             	sub    %r10,%rax
    89c4:	4c 39 c0             	cmp    %r8,%rax
    89c7:	73 47                	jae    8a10 <f12+0xad0>
    89c9:	48 89 c6             	mov    %rax,%rsi
    89cc:	48 c1 ee 10          	shr    $0x10,%rsi
    89d0:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    89d4:	49 8d 34 f3          	lea    (%r11,%rsi,8),%rsi
    89d8:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    89dc:	48 85 ff             	test   %rdi,%rdi
    89df:	74 2f                	je     8a10 <f12+0xad0>
    89e1:	0f b6 1e             	movzbl (%rsi),%ebx
    89e4:	80 fb 02             	cmp    $0x2,%bl
    89e7:	0f 84 d3 01 00 00    	je     8bc0 <f12+0xc80>
    89ed:	80 fb 01             	cmp    $0x1,%bl
    89f0:	75 1e                	jne    8a10 <f12+0xad0>
    89f2:	8b 5e 18             	mov    0x18(%rsi),%ebx
    89f5:	0f b7 c0             	movzwl %ax,%eax
    89f8:	8b 76 1c             	mov    0x1c(%rsi),%esi
    89fb:	48 0f af c3          	imul   %rbx,%rax
    89ff:	48 c1 e8 20          	shr    $0x20,%rax
    8a03:	48 39 f0             	cmp    %rsi,%rax
    8a06:	73 08                	jae    8a10 <f12+0xad0>
    8a08:	48 01 c7             	add    %rax,%rdi
    8a0b:	80 3f 01             	cmpb   $0x1,(%rdi)
    8a0e:	74 98                	je     89a8 <f12+0xa68>
    8a10:	49 39 ef             	cmp    %rbp,%r15
    8a13:	0f 83 c7 01 00 00    	jae    8be0 <f12+0xca0>
    8a19:	4c 8b 2d d0 40 00 00 	mov    0x40d0(%rip),%r13        # caf0 <msg.4+0x70>
    8a20:	45 31 f6             	xor    %r14d,%r14d
    8a23:	48 8d 1d 36 7d 01 00 	lea    0x17d36(%rip),%rbx        # 20760 <fwp_heap>
    8a2a:	e9 17 01 00 00       	jmp    8b46 <f12+0xc06>
    8a2f:	90                   	nop
    8a30:	49 8b 10             	mov    (%r8),%rdx
    8a33:	48 f7 d2             	not    %rdx
    8a36:	48 89 10             	mov    %rdx,(%rax)
    8a39:	49 83 fb 18          	cmp    $0x18,%r11
    8a3d:	76 39                	jbe    8a78 <f12+0xb38>
    8a3f:	49 8d 43 e7          	lea    -0x19(%r11),%rax
    8a43:	49 8d 78 18          	lea    0x18(%r8),%rdi
    8a47:	31 f6                	xor    %esi,%esi
    8a49:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    8a4e:	48 c1 e8 03          	shr    $0x3,%rax
    8a52:	4c 89 04 24          	mov    %r8,(%rsp)
    8a56:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8a5d:	00 
    8a5e:	66 0f d6 44 24 30    	movq   %xmm0,0x30(%rsp)
    8a64:	e8 57 aa ff ff       	call   34c0 <memset@plt>
    8a69:	4c 8b 04 24          	mov    (%rsp),%r8
    8a6d:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    8a72:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
    8a78:	4c 89 d8             	mov    %r11,%rax
    8a7b:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8a82:	0f 82 b5 09 00 00    	jb     943d <f12+0x14fd>
    8a88:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8a8f:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8a96:	73 07                	jae    8a9f <f12+0xb5f>
    8a98:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8a9f:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8aa3:	f2 49 0f 2a cb       	cvtsi2sd %r11,%xmm1
    8aa8:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8aaf:	00 
    8ab0:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8ab7:	00 
    8ab8:	66 49 0f 6e f6       	movq   %r14,%xmm6
    8abd:	4d 89 28             	mov    %r13,(%r8)
    8ac0:	4c 89 c0             	mov    %r8,%rax
    8ac3:	4d 89 c6             	mov    %r8,%r14
    8ac6:	66 0f 6c c6          	punpcklqdq %xmm6,%xmm0
    8aca:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
    8acf:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8ad6:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8add:	48 c1 e2 10          	shl    $0x10,%rdx
    8ae1:	48 39 d0             	cmp    %rdx,%rax
    8ae4:	73 57                	jae    8b3d <f12+0xbfd>
    8ae6:	48 89 c2             	mov    %rax,%rdx
    8ae9:	48 c1 ea 10          	shr    $0x10,%rdx
    8aed:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8af1:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8af8:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    8afc:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    8b00:	48 85 d2             	test   %rdx,%rdx
    8b03:	74 38                	je     8b3d <f12+0xbfd>
    8b05:	0f b6 3e             	movzbl (%rsi),%edi
    8b08:	40 80 ff 02          	cmp    $0x2,%dil
    8b0c:	0f 84 7e 01 00 00    	je     8c90 <f12+0xd50>
    8b12:	40 80 ff 01          	cmp    $0x1,%dil
    8b16:	75 25                	jne    8b3d <f12+0xbfd>
    8b18:	8b 7e 18             	mov    0x18(%rsi),%edi
    8b1b:	0f b7 c0             	movzwl %ax,%eax
    8b1e:	8b 76 1c             	mov    0x1c(%rsi),%esi
    8b21:	48 0f af c7          	imul   %rdi,%rax
    8b25:	48 c1 e8 20          	shr    $0x20,%rax
    8b29:	48 39 f0             	cmp    %rsi,%rax
    8b2c:	73 0f                	jae    8b3d <f12+0xbfd>
    8b2e:	48 01 c2             	add    %rax,%rdx
    8b31:	80 3a ff             	cmpb   $0xff,(%rdx)
    8b34:	0f 84 f6 04 00 00    	je     9030 <f12+0x10f0>
    8b3a:	c6 02 01             	movb   $0x1,(%rdx)
    8b3d:	49 39 ef             	cmp    %rbp,%r15
    8b40:	0f 83 6a 01 00 00    	jae    8cb0 <f12+0xd70>
    8b46:	8b b3 a4 13 00 00    	mov    0x13a4(%rbx),%esi
    8b4c:	48 83 ed 01          	sub    $0x1,%rbp
    8b50:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8b56:	85 f6                	test   %esi,%esi
    8b58:	74 46                	je     8ba0 <f12+0xc60>
    8b5a:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8b61:	44 8b 9c 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r11d
    8b68:	00 
    8b69:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8b6d:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8b71:	4c 8b 00             	mov    (%rax),%r8
    8b74:	4d 85 c0             	test   %r8,%r8
    8b77:	0f 85 b3 fe ff ff    	jne    8a30 <f12+0xaf0>
    8b7d:	4c 8b 40 08          	mov    0x8(%rax),%r8
    8b81:	4d 85 c0             	test   %r8,%r8
    8b84:	74 1a                	je     8ba0 <f12+0xc60>
    8b86:	48 8b 50 10          	mov    0x10(%rax),%rdx
    8b8a:	4c 29 c2             	sub    %r8,%rdx
    8b8d:	4c 39 da             	cmp    %r11,%rdx
    8b90:	72 0e                	jb     8ba0 <f12+0xc60>
    8b92:	4b 8d 14 18          	lea    (%r8,%r11,1),%rdx
    8b96:	48 89 50 08          	mov    %rdx,0x8(%rax)
    8b9a:	e9 9a fe ff ff       	jmp    8a39 <f12+0xaf9>
    8b9f:	90                   	nop
    8ba0:	31 f6                	xor    %esi,%esi
    8ba2:	bf 18 00 00 00       	mov    $0x18,%edi
    8ba7:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    8bac:	e8 9f ce ff ff       	call   5a50 <fwp_heap_alloc>
    8bb1:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    8bb6:	49 89 c0             	mov    %rax,%r8
    8bb9:	e9 fa fe ff ff       	jmp    8ab8 <f12+0xb78>
    8bbe:	66 90                	xchg   %ax,%ax
    8bc0:	66 85 c0             	test   %ax,%ax
    8bc3:	0f 84 42 fe ff ff    	je     8a0b <f12+0xacb>
    8bc9:	49 39 ef             	cmp    %rbp,%r15
    8bcc:	0f 82 47 fe ff ff    	jb     8a19 <f12+0xad9>
    8bd2:	0f 1f 00             	nopl   (%rax)
    8bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bdc:	00 00 00 00 
    8be0:	45 31 f6             	xor    %r14d,%r14d
    8be3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8be8:	4c 89 e2             	mov    %r12,%rdx
    8beb:	4b 8d 3c fc          	lea    (%r12,%r15,8),%rdi
    8bef:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8bfc:	00 00 00 00 
    8c00:	48 8b 0a             	mov    (%rdx),%rcx
    8c03:	48 83 c2 08          	add    $0x8,%rdx
    8c07:	48 89 c6             	mov    %rax,%rsi
    8c0a:	48 89 48 08          	mov    %rcx,0x8(%rax)
    8c0e:	48 8b 40 10          	mov    0x10(%rax),%rax
    8c12:	48 39 d7             	cmp    %rdx,%rdi
    8c15:	75 e9                	jne    8c00 <f12+0xcc0>
    8c17:	8b 4c 24 38          	mov    0x38(%rsp),%ecx
    8c1b:	4c 89 76 10          	mov    %r14,0x10(%rsi)
    8c1f:	85 c9                	test   %ecx,%ecx
    8c21:	0f 84 89 05 00 00    	je     91b0 <f12+0x1270>
    8c27:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    8c2c:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    8c31:	45 31 e4             	xor    %r12d,%r12d
    8c34:	90                   	nop
    8c35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8c3c:	00 00 00 00 
    8c40:	4c 89 e7             	mov    %r12,%rdi
    8c43:	e8 08 c9 ff ff       	call   5550 <fwp_mem_free>
    8c48:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
    8c4d:	e8 de ed ff ff       	call   7a30 <fwp_drop4>
    8c52:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    8c57:	e8 04 de ff ff       	call   6a60 <fwp_drop0>
    8c5c:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
    8c63:	00 
    8c64:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8c6b:	00 00 
    8c6d:	0f 85 7b 08 00 00    	jne    94ee <f12+0x15ae>
    8c73:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
    8c7a:	4c 89 f0             	mov    %r14,%rax
    8c7d:	5b                   	pop    %rbx
    8c7e:	5d                   	pop    %rbp
    8c7f:	41 5c                	pop    %r12
    8c81:	41 5d                	pop    %r13
    8c83:	41 5e                	pop    %r14
    8c85:	41 5f                	pop    %r15
    8c87:	c3                   	ret
    8c88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8c8f:	00 
    8c90:	66 85 c0             	test   %ax,%ax
    8c93:	0f 84 98 fe ff ff    	je     8b31 <f12+0xbf1>
    8c99:	49 39 ef             	cmp    %rbp,%r15
    8c9c:	0f 82 a4 fe ff ff    	jb     8b46 <f12+0xc06>
    8ca2:	0f 1f 00             	nopl   (%rax)
    8ca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8cac:	00 00 00 00 
    8cb0:	4d 85 ff             	test   %r15,%r15
    8cb3:	0f 85 2a ff ff ff    	jne    8be3 <f12+0xca3>
    8cb9:	8b 54 24 38          	mov    0x38(%rsp),%edx
    8cbd:	85 d2                	test   %edx,%edx
    8cbf:	4d 0f 45 e7          	cmovne %r15,%r12
    8cc3:	66 90                	xchg   %ax,%ax
    8cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ccc:	00 00 00 00 
    8cd0:	48 85 ed             	test   %rbp,%rbp
    8cd3:	0f 84 67 ff ff ff    	je     8c40 <f12+0xd00>
    8cd9:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    8cdf:	48 83 ed 01          	sub    $0x1,%rbp
    8ce3:	f3 41 0f 7e 04 ec    	movq   (%r12,%rbp,8),%xmm0
    8ce9:	85 c0                	test   %eax,%eax
    8ceb:	0f 84 d7 06 00 00    	je     93c8 <f12+0x1488>
    8cf1:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    8cf8:	44 8b 84 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r8d
    8cff:	00 
    8d00:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    8d04:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    8d08:	4c 8b 38             	mov    (%rax),%r15
    8d0b:	4d 85 ff             	test   %r15,%r15
    8d0e:	0f 84 8c 06 00 00    	je     93a0 <f12+0x1460>
    8d14:	49 8b 17             	mov    (%r15),%rdx
    8d17:	48 f7 d2             	not    %rdx
    8d1a:	48 89 10             	mov    %rdx,(%rax)
    8d1d:	49 83 f8 18          	cmp    $0x18,%r8
    8d21:	76 2f                	jbe    8d52 <f12+0xe12>
    8d23:	49 8d 40 e7          	lea    -0x19(%r8),%rax
    8d27:	49 8d 7f 18          	lea    0x18(%r15),%rdi
    8d2b:	31 f6                	xor    %esi,%esi
    8d2d:	4c 89 04 24          	mov    %r8,(%rsp)
    8d31:	48 c1 e8 03          	shr    $0x3,%rax
    8d35:	66 0f d6 44 24 18    	movq   %xmm0,0x18(%rsp)
    8d3b:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    8d42:	00 
    8d43:	e8 78 a7 ff ff       	call   34c0 <memset@plt>
    8d48:	4c 8b 04 24          	mov    (%rsp),%r8
    8d4c:	f3 0f 7e 44 24 18    	movq   0x18(%rsp),%xmm0
    8d52:	4c 89 c0             	mov    %r8,%rax
    8d55:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    8d5c:	0f 82 db 06 00 00    	jb     943d <f12+0x14fd>
    8d62:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    8d69:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    8d70:	73 07                	jae    8d79 <f12+0xe39>
    8d72:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    8d79:	66 0f ef c9          	pxor   %xmm1,%xmm1
    8d7d:	f2 49 0f 2a c8       	cvtsi2sd %r8,%xmm1
    8d82:	f2 0f 58 8b 38 14 00 	addsd  0x1438(%rbx),%xmm1
    8d89:	00 
    8d8a:	f2 0f 11 8b 38 14 00 	movsd  %xmm1,0x1438(%rbx)
    8d91:	00 
    8d92:	66 49 0f 6e fe       	movq   %r14,%xmm7
    8d97:	4d 89 2f             	mov    %r13,(%r15)
    8d9a:	4c 89 f8             	mov    %r15,%rax
    8d9d:	4d 89 fe             	mov    %r15,%r14
    8da0:	66 0f 6c c7          	punpcklqdq %xmm7,%xmm0
    8da4:	41 0f 11 47 08       	movups %xmm0,0x8(%r15)
    8da9:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    8db0:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    8db7:	48 c1 e2 10          	shl    $0x10,%rdx
    8dbb:	48 39 d0             	cmp    %rdx,%rax
    8dbe:	0f 83 0c ff ff ff    	jae    8cd0 <f12+0xd90>
    8dc4:	48 89 c2             	mov    %rax,%rdx
    8dc7:	48 c1 ea 10          	shr    $0x10,%rdx
    8dcb:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    8dcf:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    8dd6:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    8dda:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8dde:	4d 85 ff             	test   %r15,%r15
    8de1:	0f 84 e9 fe ff ff    	je     8cd0 <f12+0xd90>
    8de7:	0f b6 32             	movzbl (%rdx),%esi
    8dea:	40 80 fe 02          	cmp    $0x2,%sil
    8dee:	0f 84 fc 05 00 00    	je     93f0 <f12+0x14b0>
    8df4:	40 80 fe 01          	cmp    $0x1,%sil
    8df8:	0f 85 d2 fe ff ff    	jne    8cd0 <f12+0xd90>
    8dfe:	8b 72 18             	mov    0x18(%rdx),%esi
    8e01:	0f b7 c0             	movzwl %ax,%eax
    8e04:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8e07:	48 0f af c6          	imul   %rsi,%rax
    8e0b:	48 c1 e8 20          	shr    $0x20,%rax
    8e0f:	48 39 d0             	cmp    %rdx,%rax
    8e12:	0f 83 b8 fe ff ff    	jae    8cd0 <f12+0xd90>
    8e18:	49 01 c7             	add    %rax,%r15
    8e1b:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8e1f:	0f 84 eb 05 00 00    	je     9410 <f12+0x14d0>
    8e25:	41 c6 07 01          	movb   $0x1,(%r15)
    8e29:	48 85 ed             	test   %rbp,%rbp
    8e2c:	0f 85 a7 fe ff ff    	jne    8cd9 <f12+0xd99>
    8e32:	e9 09 fe ff ff       	jmp    8c40 <f12+0xd00>
    8e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e3e:	00 00 
    8e40:	66 85 c0             	test   %ax,%ax
    8e43:	0f 84 ad fa ff ff    	je     88f6 <f12+0x9b6>
    8e49:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
    8e4f:	0f 84 08 04 00 00    	je     925d <f12+0x131d>
    8e55:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8e5a:	31 ed                	xor    %ebp,%ebp
    8e5c:	0f 1f 40 00          	nopl   0x0(%rax)
    8e60:	48 8b 40 10          	mov    0x10(%rax),%rax
    8e64:	48 89 ea             	mov    %rbp,%rdx
    8e67:	48 83 c5 01          	add    $0x1,%rbp
    8e6b:	48 85 c0             	test   %rax,%rax
    8e6e:	75 f0                	jne    8e60 <f12+0xf20>
    8e70:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8e77:	ff ff 1f 
    8e7a:	48 39 e8             	cmp    %rbp,%rax
    8e7d:	0f 82 e4 05 00 00    	jb     9467 <f12+0x1527>
    8e83:	48 8d 3c d5 10 00 00 	lea    0x10(,%rdx,8),%rdi
    8e8a:	00 
    8e8b:	be 02 00 00 00       	mov    $0x2,%esi
    8e90:	e8 bb cb ff ff       	call   5a50 <fwp_heap_alloc>
    8e95:	49 39 ef             	cmp    %rbp,%r15
    8e98:	49 89 c4             	mov    %rax,%r12
    8e9b:	48 89 c2             	mov    %rax,%rdx
    8e9e:	49 0f 46 ef          	cmovbe %r15,%rbp
    8ea2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    8ea7:	0f 1f 00             	nopl   (%rax)
    8eaa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8eb1:	00 00 00 00 
    8eb5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    8ebc:	00 00 00 00 
    8ec0:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8ec4:	48 83 c2 08          	add    $0x8,%rdx
    8ec8:	48 89 72 f8          	mov    %rsi,-0x8(%rdx)
    8ecc:	48 8b 40 10          	mov    0x10(%rax),%rax
    8ed0:	48 85 c0             	test   %rax,%rax
    8ed3:	75 eb                	jne    8ec0 <f12+0xf80>
    8ed5:	48 85 ed             	test   %rbp,%rbp
    8ed8:	0f 84 91 03 00 00    	je     926f <f12+0x132f>
    8ede:	c7 44 24 38 00 00 00 	movl   $0x0,0x38(%rsp)
    8ee5:	00 
    8ee6:	e9 33 fa ff ff       	jmp    891e <f12+0x9de>
    8eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8ef0:	66 85 c0             	test   %ax,%ax
    8ef3:	0f 84 c7 f8 ff ff    	je     87c0 <f12+0x880>
    8ef9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8f00:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
    8f07:	ff ff 1f 
    8f0a:	4c 39 e8             	cmp    %r13,%rax
    8f0d:	0f 82 60 05 00 00    	jb     9473 <f12+0x1533>
    8f13:	4a 8d 3c ed 08 00 00 	lea    0x8(,%r13,8),%rdi
    8f1a:	00 
    8f1b:	be 01 00 00 00       	mov    $0x1,%esi
    8f20:	e8 2b cb ff ff       	call   5a50 <fwp_heap_alloc>
    8f25:	4c 89 28             	mov    %r13,(%rax)
    8f28:	48 8b 15 09 8c 01 00 	mov    0x18c09(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8f2f:	48 89 c3             	mov    %rax,%rbx
    8f32:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    8f37:	48 2b 05 d2 8b 01 00 	sub    0x18bd2(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8f3e:	48 c1 e2 10          	shl    $0x10,%rdx
    8f42:	48 39 d0             	cmp    %rdx,%rax
    8f45:	73 57                	jae    8f9e <f12+0x105e>
    8f47:	48 89 c2             	mov    %rax,%rdx
    8f4a:	48 c1 ea 10          	shr    $0x10,%rdx
    8f4e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8f52:	48 8b 15 ff 8b 01 00 	mov    0x18bff(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8f59:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8f5d:	4c 8b 7a 20          	mov    0x20(%rdx),%r15
    8f61:	4d 85 ff             	test   %r15,%r15
    8f64:	74 38                	je     8f9e <f12+0x105e>
    8f66:	0f b6 0a             	movzbl (%rdx),%ecx
    8f69:	80 f9 02             	cmp    $0x2,%cl
    8f6c:	0f 84 0e 03 00 00    	je     9280 <f12+0x1340>
    8f72:	80 f9 01             	cmp    $0x1,%cl
    8f75:	75 27                	jne    8f9e <f12+0x105e>
    8f77:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8f7a:	0f b7 c0             	movzwl %ax,%eax
    8f7d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8f80:	48 0f af c1          	imul   %rcx,%rax
    8f84:	48 c1 e8 20          	shr    $0x20,%rax
    8f88:	48 39 d0             	cmp    %rdx,%rax
    8f8b:	73 11                	jae    8f9e <f12+0x105e>
    8f8d:	49 01 c7             	add    %rax,%r15
    8f90:	41 80 3f ff          	cmpb   $0xff,(%r15)
    8f94:	0f 84 ee 03 00 00    	je     9388 <f12+0x1448>
    8f9a:	41 c6 07 01          	movb   $0x1,(%r15)
    8f9e:	4c 89 e7             	mov    %r12,%rdi
    8fa1:	e9 2d f8 ff ff       	jmp    87d3 <f12+0x893>
    8fa6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8fad:	00 00 00 
    8fb0:	48 c1 e6 10          	shl    $0x10,%rsi
    8fb4:	bf 08 00 00 00       	mov    $0x8,%edi
    8fb9:	49 09 f5             	or     %rsi,%r13
    8fbc:	be 02 00 00 00       	mov    $0x2,%esi
    8fc1:	e8 8a ca ff ff       	call   5a50 <fwp_heap_alloc>
    8fc6:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8fcd:	48 8b 15 64 8b 01 00 	mov    0x18b64(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    8fd4:	48 89 c3             	mov    %rax,%rbx
    8fd7:	48 2b 05 32 8b 01 00 	sub    0x18b32(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    8fde:	48 c1 e2 10          	shl    $0x10,%rdx
    8fe2:	48 39 d0             	cmp    %rdx,%rax
    8fe5:	0f 83 d4 f3 ff ff    	jae    83bf <f12+0x47f>
    8feb:	48 89 c2             	mov    %rax,%rdx
    8fee:	48 c1 ea 10          	shr    $0x10,%rdx
    8ff2:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    8ff6:	48 8b 15 5b 8b 01 00 	mov    0x18b5b(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    8ffd:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9001:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    9005:	4d 85 f6             	test   %r14,%r14
    9008:	0f 84 a5 f3 ff ff    	je     83b3 <f12+0x473>
    900e:	0f b6 0a             	movzbl (%rdx),%ecx
    9011:	45 31 e4             	xor    %r12d,%r12d
    9014:	80 f9 02             	cmp    $0x2,%cl
    9017:	0f 85 f9 f2 ff ff    	jne    8316 <f12+0x3d6>
    901d:	66 85 c0             	test   %ax,%ax
    9020:	0f 85 1c f3 ff ff    	jne    8342 <f12+0x402>
    9026:	e9 09 f3 ff ff       	jmp    8334 <f12+0x3f4>
    902b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9030:	48 89 d7             	mov    %rdx,%rdi
    9033:	48 89 14 24          	mov    %rdx,(%rsp)
    9037:	e8 d4 c2 ff ff       	call   5310 <fwp_rc_forget_slot>
    903c:	48 8b 14 24          	mov    (%rsp),%rdx
    9040:	e9 f5 fa ff ff       	jmp    8b3a <f12+0xbfa>
    9045:	0f 1f 00             	nopl   (%rax)
    9048:	4c 8d 60 ff          	lea    -0x1(%rax),%r12
    904c:	4c 89 e1             	mov    %r12,%rcx
    904f:	48 c1 e9 3c          	shr    $0x3c,%rcx
    9053:	0f 85 0e 04 00 00    	jne    9467 <f12+0x1527>
    9059:	4d 85 e4             	test   %r12,%r12
    905c:	0f 84 5d f3 ff ff    	je     83bf <f12+0x47f>
    9062:	48 c1 e0 04          	shl    $0x4,%rax
    9066:	4d 01 e4             	add    %r12,%r12
    9069:	48 8d 6b 08          	lea    0x8(%rbx),%rbp
    906d:	4c 8d 74 03 f8       	lea    -0x8(%rbx,%rax,1),%r14
    9072:	0f 1f 00             	nopl   (%rax)
    9075:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    907c:	00 00 00 00 
    9080:	f2 0f 10 45 00       	movsd  0x0(%rbp),%xmm0
    9085:	48 8b 75 18          	mov    0x18(%rbp),%rsi
    9089:	48 83 c5 10          	add    $0x10,%rbp
    908d:	48 8b 7d f8          	mov    -0x8(%rbp),%rdi
    9091:	f2 0f 10 4d 00       	movsd  0x0(%rbp),%xmm1
    9096:	e8 05 d1 ff ff       	call   61a0 <w107>
    909b:	66 48 0f 6e e8       	movq   %rax,%xmm5
    90a0:	66 0f 6c c5          	punpcklqdq %xmm5,%xmm0
    90a4:	0f 11 45 f0          	movups %xmm0,-0x10(%rbp)
    90a8:	49 39 ee             	cmp    %rbp,%r14
    90ab:	75 d3                	jne    9080 <f12+0x1140>
    90ad:	4c 89 23             	mov    %r12,(%rbx)
    90b0:	49 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%r15
    90b7:	45 31 f6             	xor    %r14d,%r14d
    90ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    90c0:	4a 8b 74 f3 10       	mov    0x10(%rbx,%r14,8),%rsi
    90c5:	4c 89 ff             	mov    %r15,%rdi
    90c8:	49 83 c6 02          	add    $0x2,%r14
    90cc:	e8 4f cf ff ff       	call   6020 <f128.constprop.0>
    90d1:	49 89 c7             	mov    %rax,%r15
    90d4:	4d 39 e6             	cmp    %r12,%r14
    90d7:	72 e7                	jb     90c0 <f12+0x1180>
    90d9:	e9 f2 f2 ff ff       	jmp    83d0 <f12+0x490>
    90de:	66 90                	xchg   %ax,%ax
    90e0:	4d 8d 6a 01          	lea    0x1(%r10),%r13
    90e4:	4d 39 ee             	cmp    %r13,%r14
    90e7:	0f 8c 15 f4 ff ff    	jl     8502 <f12+0x5c2>
    90ed:	4d 85 c0             	test   %r8,%r8
    90f0:	0f 84 92 03 00 00    	je     9488 <f12+0x1548>
    90f6:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    90fb:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    9102:	00 
    9103:	31 f6                	xor    %esi,%esi
    9105:	4c 89 c7             	mov    %r8,%rdi
    9108:	0f 29 14 24          	movaps %xmm2,(%rsp)
    910c:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    9111:	e8 aa a3 ff ff       	call   34c0 <memset@plt>
    9116:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    911b:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    9121:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
    9126:	49 89 c0             	mov    %rax,%r8
    9129:	e9 6d f4 ff ff       	jmp    859b <f12+0x65b>
    912e:	66 90                	xchg   %ax,%ax
    9130:	48 8d 3d 69 de ff ff 	lea    -0x2197(%rip),%rdi        # 6fa0 <fwp_tape_finish>
    9137:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    913c:	e8 2f 2e 00 00       	call   bf70 <atexit>
    9141:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    9146:	85 c0                	test   %eax,%eax
    9148:	0f 85 4e 03 00 00    	jne    949c <f12+0x155c>
    914e:	c7 05 08 6f 00 00 01 	movl   $0x1,0x6f08(%rip)        # 10060 <registered_finish.0>
    9155:	00 00 00 
    9158:	e9 12 ef ff ff       	jmp    806f <f12+0x12f>
    915d:	0f 1f 00             	nopl   (%rax)
    9160:	66 85 c0             	test   %ax,%ax
    9163:	0f 85 bb ee ff ff    	jne    8024 <f12+0xe4>
    9169:	e9 a2 ee ff ff       	jmp    8010 <f12+0xd0>
    916e:	66 90                	xchg   %ax,%ax
    9170:	4c 39 f5             	cmp    %r14,%rbp
    9173:	0f 8f 86 f3 ff ff    	jg     84ff <f12+0x5bf>
    9179:	4d 85 c0             	test   %r8,%r8
    917c:	0f 85 c8 01 00 00    	jne    934a <f12+0x140a>
    9182:	48 85 ed             	test   %rbp,%rbp
    9185:	0f 85 fd 02 00 00    	jne    9488 <f12+0x1548>
    918b:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    9192:	e9 18 f4 ff ff       	jmp    85af <f12+0x66f>
    9197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    919e:	00 00 
    91a0:	66 85 c0             	test   %ax,%ax
    91a3:	0f 85 6c f5 ff ff    	jne    8715 <f12+0x7d5>
    91a9:	e9 5b f5 ff ff       	jmp    8709 <f12+0x7c9>
    91ae:	66 90                	xchg   %ax,%ax
    91b0:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    91b5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    91ba:	e9 81 fa ff ff       	jmp    8c40 <f12+0xd00>
    91bf:	90                   	nop
    91c0:	66 0f 6f 0d d8 6e 01 	movdqa 0x16ed8(%rip),%xmm1        # 200a0 <fwp_tape_workspace>
    91c7:	00 
    91c8:	48 c7 05 b5 6e 01 00 	movq   $0x0,0x16eb5(%rip)        # 20088 <fwp_tape_cached_bytes>
    91cf:	00 00 00 00 
    91d3:	41 0f 11 4e 20       	movups %xmm1,0x20(%r14)
    91d8:	48 8b 05 e1 6e 01 00 	mov    0x16ee1(%rip),%rax        # 200c0 <fwp_tape_workspace+0x20>
    91df:	66 0f 6f 0d c9 6e 01 	movdqa 0x16ec9(%rip),%xmm1        # 200b0 <fwp_tape_workspace+0x10>
    91e6:	00 
    91e7:	49 89 46 40          	mov    %rax,0x40(%r14)
    91eb:	48 8b 05 d6 6e 01 00 	mov    0x16ed6(%rip),%rax        # 200c8 <fwp_tape_workspace+0x28>
    91f2:	41 0f 11 4e 30       	movups %xmm1,0x30(%r14)
    91f7:	66 0f ef c9          	pxor   %xmm1,%xmm1
    91fb:	49 89 46 18          	mov    %rax,0x18(%r14)
    91ff:	48 8b 05 ca 6e 01 00 	mov    0x16eca(%rip),%rax        # 200d0 <fwp_tape_workspace+0x30>
    9206:	0f 29 0d 93 6e 01 00 	movaps %xmm1,0x16e93(%rip)        # 200a0 <fwp_tape_workspace>
    920d:	49 89 46 48          	mov    %rax,0x48(%r14)
    9211:	0f 29 0d 98 6e 01 00 	movaps %xmm1,0x16e98(%rip)        # 200b0 <fwp_tape_workspace+0x10>
    9218:	48 c7 05 ad 6e 01 00 	movq   $0x0,0x16ead(%rip)        # 200d0 <fwp_tape_workspace+0x30>
    921f:	00 00 00 00 
    9223:	0f 29 0d 96 6e 01 00 	movaps %xmm1,0x16e96(%rip)        # 200c0 <fwp_tape_workspace+0x20>
    922a:	e9 8d ef ff ff       	jmp    81bc <f12+0x27c>
    922f:	90                   	nop
    9230:	4d 85 c0             	test   %r8,%r8
    9233:	0f 84 4f 02 00 00    	je     9488 <f12+0x1548>
    9239:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
    923e:	4c 8d 65 ff          	lea    -0x1(%rbp),%r12
    9242:	31 f6                	xor    %esi,%esi
    9244:	4c 89 c7             	mov    %r8,%rdi
    9247:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    924c:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
    9253:	00 
    9254:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9258:	e9 b4 fe ff ff       	jmp    9111 <f12+0x11d1>
    925d:	be 02 00 00 00       	mov    $0x2,%esi
    9262:	bf 08 00 00 00       	mov    $0x8,%edi
    9267:	e8 e4 c7 ff ff       	call   5a50 <fwp_heap_alloc>
    926c:	49 89 c4             	mov    %rax,%r12
    926f:	45 31 f6             	xor    %r14d,%r14d
    9272:	e9 c9 f9 ff ff       	jmp    8c40 <f12+0xd00>
    9277:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    927e:	00 00 
    9280:	66 85 c0             	test   %ax,%ax
    9283:	0f 85 15 fd ff ff    	jne    8f9e <f12+0x105e>
    9289:	e9 02 fd ff ff       	jmp    8f90 <f12+0x1050>
    928e:	66 90                	xchg   %ax,%ax
    9290:	4d 85 e4             	test   %r12,%r12
    9293:	0f 85 ae f0 ff ff    	jne    8347 <f12+0x407>
    9299:	e9 21 f1 ff ff       	jmp    83bf <f12+0x47f>
    929e:	66 90                	xchg   %ax,%ax
    92a0:	be 08 00 00 00       	mov    $0x8,%esi
    92a5:	4c 89 f7             	mov    %r14,%rdi
    92a8:	e8 73 a2 ff ff       	call   3520 <calloc@plt>
    92ad:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    92b3:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    92b8:	49 89 c0             	mov    %rax,%r8
    92bb:	e9 aa f2 ff ff       	jmp    856a <f12+0x62a>
    92c0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    92c4:	e9 96 ed ff ff       	jmp    805f <f12+0x11f>
    92c9:	48 8b 0b             	mov    (%rbx),%rcx
    92cc:	48 85 c9             	test   %rcx,%rcx
    92cf:	78 8c                	js     925d <f12+0x131d>
    92d1:	48 8b 35 60 88 01 00 	mov    0x18860(%rip),%rsi        # 21b38 <fwp_heap+0x13d8>
    92d8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    92dd:	48 2b 05 2c 88 01 00 	sub    0x1882c(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    92e4:	48 c1 e6 10          	shl    $0x10,%rsi
    92e8:	48 39 f0             	cmp    %rsi,%rax
    92eb:	0f 83 6c ff ff ff    	jae    925d <f12+0x131d>
    92f1:	48 89 c6             	mov    %rax,%rsi
    92f4:	48 c1 ee 10          	shr    $0x10,%rsi
    92f8:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    92fc:	48 8b 35 55 88 01 00 	mov    0x18855(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    9303:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    9307:	48 8b 7e 20          	mov    0x20(%rsi),%rdi
    930b:	48 85 ff             	test   %rdi,%rdi
    930e:	0f 84 49 ff ff ff    	je     925d <f12+0x131d>
    9314:	48 0f ba f1 3f       	btr    $0x3f,%rcx
    9319:	49 89 cf             	mov    %rcx,%r15
    931c:	e9 a3 f5 ff ff       	jmp    88c4 <f12+0x984>
    9321:	be 68 00 00 00       	mov    $0x68,%esi
    9326:	bb 01 00 00 00       	mov    $0x1,%ebx
    932b:	e9 cb ed ff ff       	jmp    80fb <f12+0x1bb>
    9330:	4c 89 f7             	mov    %r14,%rdi
    9333:	e8 d8 bf ff ff       	call   5310 <fwp_rc_forget_slot>
    9338:	e9 01 f0 ff ff       	jmp    833e <f12+0x3fe>
    933d:	48 89 df             	mov    %rbx,%rdi
    9340:	e8 cb bf ff ff       	call   5310 <fwp_rc_forget_slot>
    9345:	e9 c8 f3 ff ff       	jmp    8712 <f12+0x7d2>
    934a:	48 85 ed             	test   %rbp,%rbp
    934d:	0f 84 38 fe ff ff    	je     918b <f12+0x124b>
    9353:	49 89 ed             	mov    %rbp,%r13
    9356:	4c 89 c7             	mov    %r8,%rdi
    9359:	31 f6                	xor    %esi,%esi
    935b:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
    9360:	4d 8d 65 ff          	lea    -0x1(%r13),%r12
    9364:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
    936b:	00 
    936c:	0f 29 14 24          	movaps %xmm2,(%rsp)
    9370:	e8 4b a1 ff ff       	call   34c0 <memset@plt>
    9375:	66 0f 6f 14 24       	movdqa (%rsp),%xmm2
    937a:	66 0f 6f 5c 24 20    	movdqa 0x20(%rsp),%xmm3
    9380:	49 89 c0             	mov    %rax,%r8
    9383:	e9 0b f2 ff ff       	jmp    8593 <f12+0x653>
    9388:	4c 89 ff             	mov    %r15,%rdi
    938b:	e8 80 bf ff ff       	call   5310 <fwp_rc_forget_slot>
    9390:	e9 05 fc ff ff       	jmp    8f9a <f12+0x105a>
    9395:	e8 56 be ff ff       	call   51f0 <fwp_rc_wide_dup>
    939a:	e9 85 ec ff ff       	jmp    8024 <f12+0xe4>
    939f:	90                   	nop
    93a0:	4c 8b 78 08          	mov    0x8(%rax),%r15
    93a4:	4d 85 ff             	test   %r15,%r15
    93a7:	74 1f                	je     93c8 <f12+0x1488>
    93a9:	48 8b 50 10          	mov    0x10(%rax),%rdx
    93ad:	4c 29 fa             	sub    %r15,%rdx
    93b0:	4c 39 c2             	cmp    %r8,%rdx
    93b3:	72 13                	jb     93c8 <f12+0x1488>
    93b5:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    93b9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    93bd:	e9 5b f9 ff ff       	jmp    8d1d <f12+0xddd>
    93c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    93c8:	31 f6                	xor    %esi,%esi
    93ca:	bf 18 00 00 00       	mov    $0x18,%edi
    93cf:	66 0f d6 04 24       	movq   %xmm0,(%rsp)
    93d4:	e8 77 c6 ff ff       	call   5a50 <fwp_heap_alloc>
    93d9:	f3 0f 7e 04 24       	movq   (%rsp),%xmm0
    93de:	49 89 c7             	mov    %rax,%r15
    93e1:	e9 ac f9 ff ff       	jmp    8d92 <f12+0xe52>
    93e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    93ed:	00 00 00 
    93f0:	66 85 c0             	test   %ax,%ax
    93f3:	0f 85 d7 f8 ff ff    	jne    8cd0 <f12+0xd90>
    93f9:	41 80 3f ff          	cmpb   $0xff,(%r15)
    93fd:	0f 85 22 fa ff ff    	jne    8e25 <f12+0xee5>
    9403:	66 90                	xchg   %ax,%ax
    9405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    940c:	00 00 00 00 
    9410:	4c 89 ff             	mov    %r15,%rdi
    9413:	e8 f8 be ff ff       	call   5310 <fwp_rc_forget_slot>
    9418:	e9 08 fa ff ff       	jmp    8e25 <f12+0xee5>
    941d:	45 31 ff             	xor    %r15d,%r15d
    9420:	e9 f4 f5 ff ff       	jmp    8a19 <f12+0xad9>
    9425:	48 8d 3d d8 2c 00 00 	lea    0x2cd8(%rip),%rdi        # c104 <_IO_stdin_used+0x104>
    942c:	e8 6f ad ff ff       	call   41a0 <fwp_trap>
    9431:	48 8d 3d 88 33 00 00 	lea    0x3388(%rip),%rdi        # c7c0 <_IO_stdin_used+0x7c0>
    9438:	e8 63 ad ff ff       	call   41a0 <fwp_trap>
    943d:	e8 6e a8 ff ff       	call   3cb0 <fwp_heap_oom>
    9442:	48 8d 3d 7f 34 00 00 	lea    0x347f(%rip),%rdi        # c8c8 <_IO_stdin_used+0x8c8>
    9449:	e8 52 ad ff ff       	call   41a0 <fwp_trap>
    944e:	e8 ad a2 ff ff       	call   3700 <fwp_trap_overflow.constprop.0>
    9453:	45 31 e4             	xor    %r12d,%r12d
    9456:	e9 14 fe ff ff       	jmp    926f <f12+0x132f>
    945b:	48 8d 3d cb 2c 00 00 	lea    0x2ccb(%rip),%rdi        # c12d <_IO_stdin_used+0x12d>
    9462:	e8 39 ad ff ff       	call   41a0 <fwp_trap>
    9467:	48 8d 3d d9 2c 00 00 	lea    0x2cd9(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    946e:	e8 2d ad ff ff       	call   41a0 <fwp_trap>
    9473:	48 8d 3d db 2c 00 00 	lea    0x2cdb(%rip),%rdi        # c155 <_IO_stdin_used+0x155>
    947a:	e8 21 ad ff ff       	call   41a0 <fwp_trap>
    947f:	4d 85 ed             	test   %r13,%r13
    9482:	0f 84 04 f1 ff ff    	je     858c <f12+0x64c>
    9488:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
    948d:	48 89 df             	mov    %rbx,%rdi
    9490:	48 89 05 61 8f 01 00 	mov    %rax,0x18f61(%rip)        # 223f8 <fwp_cleanups>
    9497:	e8 94 b9 ff ff       	call   4e30 <fwp_tape_buffers_release>
    949c:	48 8b 0d 9d 6b 00 00 	mov    0x6b9d(%rip),%rcx        # 10040 <stderr@GLIBC_2.2.5>
    94a3:	ba 13 00 00 00       	mov    $0x13,%edx
    94a8:	be 01 00 00 00       	mov    $0x1,%esi
    94ad:	48 8d 3d 54 2b 00 00 	lea    0x2b54(%rip),%rdi        # c008 <_IO_stdin_used+0x8>
    94b4:	e8 c7 a1 ff ff       	call   3680 <fwrite@plt>
    94b9:	31 ff                	xor    %edi,%edi
    94bb:	e8 00 a1 ff ff       	call   35c0 <fflush@plt>
    94c0:	bf 66 00 00 00       	mov    $0x66,%edi
    94c5:	e8 d6 a1 ff ff       	call   36a0 <_Exit@plt>
    94ca:	48 8d 3d c7 33 00 00 	lea    0x33c7(%rip),%rdi        # c898 <_IO_stdin_used+0x898>
    94d1:	e8 ca ac ff ff       	call   41a0 <fwp_trap>
    94d6:	48 8d 3d 8b 33 00 00 	lea    0x338b(%rip),%rdi        # c868 <_IO_stdin_used+0x868>
    94dd:	e8 be ac ff ff       	call   41a0 <fwp_trap>
    94e2:	48 8d 3d 1f 33 00 00 	lea    0x331f(%rip),%rdi        # c808 <_IO_stdin_used+0x808>
    94e9:	e8 b2 ac ff ff       	call   41a0 <fwp_trap>
    94ee:	e8 6d 9f ff ff       	call   3460 <__stack_chk_fail@plt>
    94f3:	66 90                	xchg   %ax,%ax
    94f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    94fc:	00 00 00 00 

0000000000009500 <fwp_owned_entry12>:
    9500:	f3 0f 1e fa          	endbr64
    9504:	48 8b 3f             	mov    (%rdi),%rdi
    9507:	e9 34 ea ff ff       	jmp    7f40 <f12>
    950c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009510 <e12>:
    9510:	f3 0f 1e fa          	endbr64
    9514:	53                   	push   %rbx
    9515:	48 8b 1f             	mov    (%rdi),%rbx
    9518:	48 89 df             	mov    %rbx,%rdi
    951b:	e8 b0 d3 ff ff       	call   68d0 <fwp_rc_share>
    9520:	48 89 df             	mov    %rbx,%rdi
    9523:	e8 18 ea ff ff       	call   7f40 <f12>
    9528:	48 89 c3             	mov    %rax,%rbx
    952b:	48 89 c7             	mov    %rax,%rdi
    952e:	e8 9d d3 ff ff       	call   68d0 <fwp_rc_share>
    9533:	48 89 d8             	mov    %rbx,%rax
    9536:	5b                   	pop    %rbx
    9537:	c3                   	ret
    9538:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    953f:	00 

0000000000009540 <fwp_drop2>:
    9540:	48 8b 0d f1 85 01 00 	mov    0x185f1(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    9547:	48 89 f8             	mov    %rdi,%rax
    954a:	48 2b 05 bf 85 01 00 	sub    0x185bf(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9551:	48 c1 e1 10          	shl    $0x10,%rcx
    9555:	48 39 c8             	cmp    %rcx,%rax
    9558:	0f 83 42 01 00 00    	jae    96a0 <fwp_drop2+0x160>
    955e:	48 83 ec 18          	sub    $0x18,%rsp
    9562:	48 89 fa             	mov    %rdi,%rdx
    9565:	4c 8d 05 f4 71 01 00 	lea    0x171f4(%rip),%r8        # 20760 <fwp_heap>
    956c:	48 89 c1             	mov    %rax,%rcx
    956f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    9576:	48 c1 e9 10          	shr    $0x10,%rcx
    957a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    957e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    9582:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9586:	48 85 c9             	test   %rcx,%rcx
    9589:	74 40                	je     95cb <fwp_drop2+0x8b>
    958b:	0f b6 3e             	movzbl (%rsi),%edi
    958e:	40 80 ff 02          	cmp    $0x2,%dil
    9592:	74 3c                	je     95d0 <fwp_drop2+0x90>
    9594:	40 80 ff 01          	cmp    $0x1,%dil
    9598:	75 31                	jne    95cb <fwp_drop2+0x8b>
    959a:	8b 7e 18             	mov    0x18(%rsi),%edi
    959d:	0f b7 c0             	movzwl %ax,%eax
    95a0:	8b 76 1c             	mov    0x1c(%rsi),%esi
    95a3:	48 0f af c7          	imul   %rdi,%rax
    95a7:	48 c1 e8 20          	shr    $0x20,%rax
    95ab:	48 39 f0             	cmp    %rsi,%rax
    95ae:	73 1b                	jae    95cb <fwp_drop2+0x8b>
    95b0:	48 01 c1             	add    %rax,%rcx
    95b3:	0f b6 01             	movzbl (%rcx),%eax
    95b6:	84 c0                	test   %al,%al
    95b8:	74 11                	je     95cb <fwp_drop2+0x8b>
    95ba:	3c 01                	cmp    $0x1,%al
    95bc:	74 22                	je     95e0 <fwp_drop2+0xa0>
    95be:	3c ff                	cmp    $0xff,%al
    95c0:	0f 84 0a 01 00 00    	je     96d0 <fwp_drop2+0x190>
    95c6:	83 e8 01             	sub    $0x1,%eax
    95c9:	88 01                	mov    %al,(%rcx)
    95cb:	48 83 c4 18          	add    $0x18,%rsp
    95cf:	c3                   	ret
    95d0:	66 85 c0             	test   %ax,%ax
    95d3:	74 de                	je     95b3 <fwp_drop2+0x73>
    95d5:	48 83 c4 18          	add    $0x18,%rsp
    95d9:	c3                   	ret
    95da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95e0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    95e4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    95eb:	48 89 f8             	mov    %rdi,%rax
    95ee:	48 c1 e1 10          	shl    $0x10,%rcx
    95f2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    95f9:	48 39 c8             	cmp    %rcx,%rax
    95fc:	73 62                	jae    9660 <fwp_drop2+0x120>
    95fe:	48 89 c1             	mov    %rax,%rcx
    9601:	48 c1 e9 10          	shr    $0x10,%rcx
    9605:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    9609:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    960d:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    9611:	48 85 c9             	test   %rcx,%rcx
    9614:	74 4a                	je     9660 <fwp_drop2+0x120>
    9616:	44 0f b6 0e          	movzbl (%rsi),%r9d
    961a:	41 80 f9 02          	cmp    $0x2,%r9b
    961e:	0f 84 9c 00 00 00    	je     96c0 <fwp_drop2+0x180>
    9624:	41 80 f9 01          	cmp    $0x1,%r9b
    9628:	75 36                	jne    9660 <fwp_drop2+0x120>
    962a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    962e:	0f b7 c0             	movzwl %ax,%eax
    9631:	8b 76 1c             	mov    0x1c(%rsi),%esi
    9634:	49 0f af c1          	imul   %r9,%rax
    9638:	48 c1 e8 20          	shr    $0x20,%rax
    963c:	48 39 f0             	cmp    %rsi,%rax
    963f:	73 1f                	jae    9660 <fwp_drop2+0x120>
    9641:	48 01 c1             	add    %rax,%rcx
    9644:	0f b6 01             	movzbl (%rcx),%eax
    9647:	84 c0                	test   %al,%al
    9649:	74 15                	je     9660 <fwp_drop2+0x120>
    964b:	3c 01                	cmp    $0x1,%al
    964d:	74 59                	je     96a8 <fwp_drop2+0x168>
    964f:	3c ff                	cmp    $0xff,%al
    9651:	0f 84 ef 00 00 00    	je     9746 <fwp_drop2+0x206>
    9657:	83 e8 01             	sub    $0x1,%eax
    965a:	88 01                	mov    %al,(%rcx)
    965c:	0f 1f 40 00          	nopl   0x0(%rax)
    9660:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    9664:	48 89 d7             	mov    %rdx,%rdi
    9667:	48 89 0c 24          	mov    %rcx,(%rsp)
    966b:	e8 e0 d2 ff ff       	call   6950 <fwp_rc_free_arr>
    9670:	4c 8d 05 e9 70 01 00 	lea    0x170e9(%rip),%r8        # 20760 <fwp_heap>
    9677:	48 8b 04 24          	mov    (%rsp),%rax
    967b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    9682:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    9689:	48 c1 e2 10          	shl    $0x10,%rdx
    968d:	48 39 d0             	cmp    %rdx,%rax
    9690:	0f 83 35 ff ff ff    	jae    95cb <fwp_drop2+0x8b>
    9696:	48 8b 14 24          	mov    (%rsp),%rdx
    969a:	e9 cd fe ff ff       	jmp    956c <fwp_drop2+0x2c>
    969f:	90                   	nop
    96a0:	c3                   	ret
    96a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    96a8:	48 89 14 24          	mov    %rdx,(%rsp)
    96ac:	e8 9f d2 ff ff       	call   6950 <fwp_rc_free_arr>
    96b1:	48 8b 14 24          	mov    (%rsp),%rdx
    96b5:	eb a9                	jmp    9660 <fwp_drop2+0x120>
    96b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    96be:	00 00 
    96c0:	66 85 c0             	test   %ax,%ax
    96c3:	75 9b                	jne    9660 <fwp_drop2+0x120>
    96c5:	e9 7a ff ff ff       	jmp    9644 <fwp_drop2+0x104>
    96ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    96d0:	48 89 c8             	mov    %rcx,%rax
    96d3:	48 c1 e8 11          	shr    $0x11,%rax
    96d7:	48 31 c8             	xor    %rcx,%rax
    96da:	48 89 c2             	mov    %rax,%rdx
    96dd:	48 c1 ea 09          	shr    $0x9,%rdx
    96e1:	48 31 d0             	xor    %rdx,%rax
    96e4:	0f b6 d0             	movzbl %al,%edx
    96e7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    96ee:	00 
    96ef:	48 85 c0             	test   %rax,%rax
    96f2:	75 19                	jne    970d <fwp_drop2+0x1cd>
    96f4:	e9 d3 00 00 00       	jmp    97cc <fwp_drop2+0x28c>
    96f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    9704:	48 85 c0             	test   %rax,%rax
    9707:	0f 84 bf 00 00 00    	je     97cc <fwp_drop2+0x28c>
    970d:	48 89 c2             	mov    %rax,%rdx
    9710:	48 39 08             	cmp    %rcx,(%rax)
    9713:	75 eb                	jne    9700 <fwp_drop2+0x1c0>
    9715:	48 8b 50 08          	mov    0x8(%rax),%rdx
    9719:	48 83 ea 01          	sub    $0x1,%rdx
    971d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    9721:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    9728:	0f 85 9d fe ff ff    	jne    95cb <fwp_drop2+0x8b>
    972e:	48 89 cf             	mov    %rcx,%rdi
    9731:	48 89 0c 24          	mov    %rcx,(%rsp)
    9735:	e8 d6 bb ff ff       	call   5310 <fwp_rc_forget_slot>
    973a:	48 8b 0c 24          	mov    (%rsp),%rcx
    973e:	c6 01 fe             	movb   $0xfe,(%rcx)
    9741:	e9 85 fe ff ff       	jmp    95cb <fwp_drop2+0x8b>
    9746:	48 89 ce             	mov    %rcx,%rsi
    9749:	48 c1 ee 11          	shr    $0x11,%rsi
    974d:	48 31 ce             	xor    %rcx,%rsi
    9750:	48 89 f0             	mov    %rsi,%rax
    9753:	48 c1 e8 09          	shr    $0x9,%rax
    9757:	48 31 c6             	xor    %rax,%rsi
    975a:	40 0f b6 f6          	movzbl %sil,%esi
    975e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    9765:	00 
    9766:	48 85 c0             	test   %rax,%rax
    9769:	75 1e                	jne    9789 <fwp_drop2+0x249>
    976b:	eb 5f                	jmp    97cc <fwp_drop2+0x28c>
    976d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9774:	00 
    9775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    977c:	00 00 00 00 
    9780:	48 8b 46 10          	mov    0x10(%rsi),%rax
    9784:	48 85 c0             	test   %rax,%rax
    9787:	74 43                	je     97cc <fwp_drop2+0x28c>
    9789:	48 89 c6             	mov    %rax,%rsi
    978c:	48 39 08             	cmp    %rcx,(%rax)
    978f:	75 ef                	jne    9780 <fwp_drop2+0x240>
    9791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    9795:	48 83 ee 01          	sub    $0x1,%rsi
    9799:	48 89 70 08          	mov    %rsi,0x8(%rax)
    979d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    97a4:	0f 85 b6 fe ff ff    	jne    9660 <fwp_drop2+0x120>
    97aa:	48 89 cf             	mov    %rcx,%rdi
    97ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    97b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    97b6:	e8 55 bb ff ff       	call   5310 <fwp_rc_forget_slot>
    97bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    97bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    97c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    97c7:	e9 94 fe ff ff       	jmp    9660 <fwp_drop2+0x120>
    97cc:	48 8d 3d c5 2f 00 00 	lea    0x2fc5(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    97d3:	e8 c8 a9 ff ff       	call   41a0 <fwp_trap>
    97d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97df:	00 

00000000000097e0 <fwp_arg_drop23>:
    97e0:	f3 0f 1e fa          	endbr64
    97e4:	85 f6                	test   %esi,%esi
    97e6:	75 04                	jne    97ec <fwp_arg_drop23+0xc>
    97e8:	85 d2                	test   %edx,%edx
    97ea:	75 04                	jne    97f0 <fwp_arg_drop23+0x10>
    97ec:	c3                   	ret
    97ed:	0f 1f 00             	nopl   (%rax)
    97f0:	48 8b 3f             	mov    (%rdi),%rdi
    97f3:	e9 48 fd ff ff       	jmp    9540 <fwp_drop2>
    97f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    97ff:	00 

0000000000009800 <fwp_caps23>:
    9800:	f3 0f 1e fa          	endbr64
    9804:	48 83 ec 18          	sub    $0x18,%rsp
    9808:	8b 57 04             	mov    0x4(%rdi),%edx
    980b:	48 89 f8             	mov    %rdi,%rax
    980e:	85 d2                	test   %edx,%edx
    9810:	0f 84 9a 00 00 00    	je     98b0 <fwp_caps23+0xb0>
    9816:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    981a:	85 f6                	test   %esi,%esi
    981c:	0f 85 9e 00 00 00    	jne    98c0 <fwp_caps23+0xc0>
    9822:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9827:	e8 14 fd ff ff       	call   9540 <fwp_drop2>
    982c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9831:	48 8b 0d 00 83 01 00 	mov    0x18300(%rip),%rcx        # 21b38 <fwp_heap+0x13d8>
    9838:	48 89 c2             	mov    %rax,%rdx
    983b:	48 2b 15 ce 82 01 00 	sub    0x182ce(%rip),%rdx        # 21b10 <fwp_heap+0x13b0>
    9842:	48 c1 e1 10          	shl    $0x10,%rcx
    9846:	48 39 ca             	cmp    %rcx,%rdx
    9849:	73 6d                	jae    98b8 <fwp_caps23+0xb8>
    984b:	48 89 d1             	mov    %rdx,%rcx
    984e:	48 c1 e9 10          	shr    $0x10,%rcx
    9852:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    9856:	48 8b 0d fb 82 01 00 	mov    0x182fb(%rip),%rcx        # 21b58 <fwp_heap+0x13f8>
    985d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    9861:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    9865:	48 85 f6             	test   %rsi,%rsi
    9868:	74 4e                	je     98b8 <fwp_caps23+0xb8>
    986a:	0f b6 39             	movzbl (%rcx),%edi
    986d:	40 80 ff 02          	cmp    $0x2,%dil
    9871:	0f 84 b9 00 00 00    	je     9930 <fwp_caps23+0x130>
    9877:	40 80 ff 01          	cmp    $0x1,%dil
    987b:	75 3b                	jne    98b8 <fwp_caps23+0xb8>
    987d:	8b 79 18             	mov    0x18(%rcx),%edi
    9880:	0f b7 d2             	movzwl %dx,%edx
    9883:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    9886:	48 0f af d7          	imul   %rdi,%rdx
    988a:	48 c1 ea 20          	shr    $0x20,%rdx
    988e:	48 39 ca             	cmp    %rcx,%rdx
    9891:	73 25                	jae    98b8 <fwp_caps23+0xb8>
    9893:	48 01 d6             	add    %rdx,%rsi
    9896:	80 3e 01             	cmpb   $0x1,(%rsi)
    9899:	75 1d                	jne    98b8 <fwp_caps23+0xb8>
    989b:	48 89 c7             	mov    %rax,%rdi
    989e:	48 83 c4 18          	add    $0x18,%rsp
    98a2:	e9 a9 bc ff ff       	jmp    5550 <fwp_mem_free>
    98a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    98ae:	00 00 
    98b0:	85 f6                	test   %esi,%esi
    98b2:	0f 84 79 ff ff ff    	je     9831 <fwp_caps23+0x31>
    98b8:	48 83 c4 18          	add    $0x18,%rsp
    98bc:	c3                   	ret
    98bd:	0f 1f 00             	nopl   (%rax)
    98c0:	48 8b 05 71 82 01 00 	mov    0x18271(%rip),%rax        # 21b38 <fwp_heap+0x13d8>
    98c7:	48 2b 3d 42 82 01 00 	sub    0x18242(%rip),%rdi        # 21b10 <fwp_heap+0x13b0>
    98ce:	48 c1 e0 10          	shl    $0x10,%rax
    98d2:	48 39 c7             	cmp    %rax,%rdi
    98d5:	73 e1                	jae    98b8 <fwp_caps23+0xb8>
    98d7:	48 89 f8             	mov    %rdi,%rax
    98da:	48 c1 e8 10          	shr    $0x10,%rax
    98de:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    98e2:	48 8b 05 6f 82 01 00 	mov    0x1826f(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    98e9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    98ed:	48 8b 42 20          	mov    0x20(%rdx),%rax
    98f1:	48 85 c0             	test   %rax,%rax
    98f4:	74 c2                	je     98b8 <fwp_caps23+0xb8>
    98f6:	0f b6 0a             	movzbl (%rdx),%ecx
    98f9:	80 f9 02             	cmp    $0x2,%cl
    98fc:	74 42                	je     9940 <fwp_caps23+0x140>
    98fe:	80 f9 01             	cmp    $0x1,%cl
    9901:	75 b5                	jne    98b8 <fwp_caps23+0xb8>
    9903:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9906:	0f b7 ff             	movzwl %di,%edi
    9909:	8b 52 1c             	mov    0x1c(%rdx),%edx
    990c:	48 0f af f9          	imul   %rcx,%rdi
    9910:	48 c1 ef 20          	shr    $0x20,%rdi
    9914:	48 39 d7             	cmp    %rdx,%rdi
    9917:	73 9f                	jae    98b8 <fwp_caps23+0xb8>
    9919:	48 01 f8             	add    %rdi,%rax
    991c:	0f b6 10             	movzbl (%rax),%edx
    991f:	84 d2                	test   %dl,%dl
    9921:	74 95                	je     98b8 <fwp_caps23+0xb8>
    9923:	80 fa fd             	cmp    $0xfd,%dl
    9926:	77 23                	ja     994b <fwp_caps23+0x14b>
    9928:	83 c2 01             	add    $0x1,%edx
    992b:	88 10                	mov    %dl,(%rax)
    992d:	eb 89                	jmp    98b8 <fwp_caps23+0xb8>
    992f:	90                   	nop
    9930:	66 85 d2             	test   %dx,%dx
    9933:	0f 85 7f ff ff ff    	jne    98b8 <fwp_caps23+0xb8>
    9939:	e9 58 ff ff ff       	jmp    9896 <fwp_caps23+0x96>
    993e:	66 90                	xchg   %ax,%ax
    9940:	66 85 ff             	test   %di,%di
    9943:	0f 85 6f ff ff ff    	jne    98b8 <fwp_caps23+0xb8>
    9949:	eb d1                	jmp    991c <fwp_caps23+0x11c>
    994b:	48 89 c7             	mov    %rax,%rdi
    994e:	48 83 c4 18          	add    $0x18,%rsp
    9952:	e9 99 b8 ff ff       	jmp    51f0 <fwp_rc_wide_dup>
    9957:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    995e:	00 00 

0000000000009960 <f23>:
    9960:	41 57                	push   %r15
    9962:	41 56                	push   %r14
    9964:	41 55                	push   %r13
    9966:	41 54                	push   %r12
    9968:	55                   	push   %rbp
    9969:	53                   	push   %rbx
    996a:	48 83 ec 38          	sub    $0x38,%rsp
    996e:	48 8b 15 c3 81 01 00 	mov    0x181c3(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9975:	48 8b 0d 94 81 01 00 	mov    0x18194(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    997c:	64 4c 8b 2c 25 28 00 	mov    %fs:0x28,%r13
    9983:	00 00 
    9985:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
    998a:	49 89 fd             	mov    %rdi,%r13
    998d:	48 c1 e2 10          	shl    $0x10,%rdx
    9991:	48 85 ff             	test   %rdi,%rdi
    9994:	0f 84 fc 02 00 00    	je     9c96 <f23+0x336>
    999a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    999e:	48 89 d8             	mov    %rbx,%rax
    99a1:	48 29 c8             	sub    %rcx,%rax
    99a4:	48 39 d0             	cmp    %rdx,%rax
    99a7:	0f 83 b3 03 00 00    	jae    9d60 <f23+0x400>
    99ad:	48 89 c2             	mov    %rax,%rdx
    99b0:	48 c1 ea 10          	shr    $0x10,%rdx
    99b4:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    99b8:	48 8b 15 99 81 01 00 	mov    0x18199(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    99bf:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    99c3:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    99c7:	48 85 ff             	test   %rdi,%rdi
    99ca:	0f 84 90 03 00 00    	je     9d60 <f23+0x400>
    99d0:	0f b6 0a             	movzbl (%rdx),%ecx
    99d3:	80 f9 02             	cmp    $0x2,%cl
    99d6:	0f 84 94 02 00 00    	je     9c70 <f23+0x310>
    99dc:	80 f9 01             	cmp    $0x1,%cl
    99df:	75 24                	jne    9a05 <f23+0xa5>
    99e1:	8b 4a 18             	mov    0x18(%rdx),%ecx
    99e4:	0f b7 c0             	movzwl %ax,%eax
    99e7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    99ea:	48 0f af c1          	imul   %rcx,%rax
    99ee:	48 c1 e8 20          	shr    $0x20,%rax
    99f2:	48 39 d0             	cmp    %rdx,%rax
    99f5:	73 0e                	jae    9a05 <f23+0xa5>
    99f7:	48 01 c7             	add    %rax,%rdi
    99fa:	0f b6 07             	movzbl (%rdi),%eax
    99fd:	84 c0                	test   %al,%al
    99ff:	0f 85 0b 03 00 00    	jne    9d10 <f23+0x3b0>
    9a05:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9a0a:	49 8b 5d 10          	mov    0x10(%r13),%rbx
    9a0e:	ba 01 00 00 00       	mov    $0x1,%edx
    9a13:	48 85 db             	test   %rbx,%rbx
    9a16:	74 15                	je     9a2d <f23+0xcd>
    9a18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9a1f:	00 
    9a20:	48 8b 5b 10          	mov    0x10(%rbx),%rbx
    9a24:	48 83 c2 01          	add    $0x1,%rdx
    9a28:	48 85 db             	test   %rbx,%rbx
    9a2b:	75 f3                	jne    9a20 <f23+0xc0>
    9a2d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9a32:	48 85 c0             	test   %rax,%rax
    9a35:	0f 84 55 03 00 00    	je     9d90 <f23+0x430>
    9a3b:	31 db                	xor    %ebx,%ebx
    9a3d:	0f 1f 00             	nopl   (%rax)
    9a40:	48 8b 40 10          	mov    0x10(%rax),%rax
    9a44:	48 83 c3 01          	add    $0x1,%rbx
    9a48:	48 85 c0             	test   %rax,%rax
    9a4b:	75 f3                	jne    9a40 <f23+0xe0>
    9a4d:	48 39 d3             	cmp    %rdx,%rbx
    9a50:	48 0f 47 da          	cmova  %rdx,%rbx
    9a54:	48 89 d8             	mov    %rbx,%rax
    9a57:	48 c1 e8 3c          	shr    $0x3c,%rax
    9a5b:	0f 85 d3 03 00 00    	jne    9e34 <f23+0x4d4>
    9a61:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    9a65:	be 02 00 00 00       	mov    $0x2,%esi
    9a6a:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    9a71:	00 
    9a72:	e8 d9 bf ff ff       	call   5a50 <fwp_heap_alloc>
    9a77:	48 89 28             	mov    %rbp,(%rax)
    9a7a:	48 8b 15 b7 80 01 00 	mov    0x180b7(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9a81:	49 89 c4             	mov    %rax,%r12
    9a84:	48 2b 05 85 80 01 00 	sub    0x18085(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9a8b:	48 c1 e2 10          	shl    $0x10,%rdx
    9a8f:	48 39 d0             	cmp    %rdx,%rax
    9a92:	73 57                	jae    9aeb <f23+0x18b>
    9a94:	48 89 c2             	mov    %rax,%rdx
    9a97:	48 c1 ea 10          	shr    $0x10,%rdx
    9a9b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9a9f:	48 8b 15 b2 80 01 00 	mov    0x180b2(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9aa6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9aaa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9aae:	48 85 ed             	test   %rbp,%rbp
    9ab1:	74 38                	je     9aeb <f23+0x18b>
    9ab3:	0f b6 0a             	movzbl (%rdx),%ecx
    9ab6:	80 f9 02             	cmp    $0x2,%cl
    9ab9:	0f 84 91 02 00 00    	je     9d50 <f23+0x3f0>
    9abf:	80 f9 01             	cmp    $0x1,%cl
    9ac2:	75 27                	jne    9aeb <f23+0x18b>
    9ac4:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9ac7:	0f b7 c0             	movzwl %ax,%eax
    9aca:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9acd:	48 0f af c1          	imul   %rcx,%rax
    9ad1:	48 c1 e8 20          	shr    $0x20,%rax
    9ad5:	48 39 d0             	cmp    %rdx,%rax
    9ad8:	73 11                	jae    9aeb <f23+0x18b>
    9ada:	48 01 c5             	add    %rax,%rbp
    9add:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    9ae1:	0f 84 19 03 00 00    	je     9e00 <f23+0x4a0>
    9ae7:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    9aeb:	48 85 db             	test   %rbx,%rbx
    9aee:	74 5d                	je     9b4d <f23+0x1ed>
    9af0:	48 c1 e3 04          	shl    $0x4,%rbx
    9af4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    9af9:	4c 89 e5             	mov    %r12,%rbp
    9afc:	4d 89 ee             	mov    %r13,%r14
    9aff:	4c 01 e3             	add    %r12,%rbx
    9b02:	0f 1f 00             	nopl   (%rax)
    9b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9b0c:	00 00 00 00 
    9b10:	49 8b 46 08          	mov    0x8(%r14),%rax
    9b14:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    9b18:	48 83 c5 10          	add    $0x10,%rbp
    9b1c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    9b21:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    9b25:	48 8b 78 10          	mov    0x10(%rax),%rdi
    9b29:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    9b2e:	e8 6d c6 ff ff       	call   61a0 <w107>
    9b33:	66 48 0f 6e d0       	movq   %rax,%xmm2
    9b38:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    9b3c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    9b40:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    9b44:	4d 8b 76 10          	mov    0x10(%r14),%r14
    9b48:	48 39 eb             	cmp    %rbp,%rbx
    9b4b:	75 c3                	jne    9b10 <f23+0x1b0>
    9b4d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9b52:	31 db                	xor    %ebx,%ebx
    9b54:	e8 e7 f9 ff ff       	call   9540 <fwp_drop2>
    9b59:	4c 89 ef             	mov    %r13,%rdi
    9b5c:	e8 df f9 ff ff       	call   9540 <fwp_drop2>
    9b61:	4d 8b 2c 24          	mov    (%r12),%r13
    9b65:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9b69:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    9b70:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    9b77:	4d 85 ed             	test   %r13,%r13
    9b7a:	74 32                	je     9bae <f23+0x24e>
    9b7c:	0f 1f 40 00          	nopl   0x0(%rax)
    9b80:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    9b87:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    9b8c:	48 83 c3 02          	add    $0x2,%rbx
    9b90:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    9b96:	e8 85 c4 ff ff       	call   6020 <f128.constprop.0>
    9b9b:	4c 39 eb             	cmp    %r13,%rbx
    9b9e:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    9ba4:	48 89 c7             	mov    %rax,%rdi
    9ba7:	72 d7                	jb     9b80 <f23+0x220>
    9ba9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    9bae:	4c 89 e7             	mov    %r12,%rdi
    9bb1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9bb6:	e8 75 de ff ff       	call   7a30 <fwp_drop4>
    9bbb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    9bc0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    9bc5:	31 ff                	xor    %edi,%edi
    9bc7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    9bcc:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9bd1:	e8 ca cb ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    9bd6:	48 8b 15 5b 7f 01 00 	mov    0x17f5b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9bdd:	48 89 c5             	mov    %rax,%rbp
    9be0:	48 2b 05 29 7f 01 00 	sub    0x17f29(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9be7:	48 c1 e2 10          	shl    $0x10,%rdx
    9beb:	48 39 d0             	cmp    %rdx,%rax
    9bee:	73 55                	jae    9c45 <f23+0x2e5>
    9bf0:	48 89 c2             	mov    %rax,%rdx
    9bf3:	48 c1 ea 10          	shr    $0x10,%rdx
    9bf7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9bfb:	48 8b 15 56 7f 01 00 	mov    0x17f56(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9c02:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9c06:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    9c0a:	48 85 db             	test   %rbx,%rbx
    9c0d:	74 36                	je     9c45 <f23+0x2e5>
    9c0f:	0f b6 0a             	movzbl (%rdx),%ecx
    9c12:	80 f9 02             	cmp    $0x2,%cl
    9c15:	0f 84 1d 01 00 00    	je     9d38 <f23+0x3d8>
    9c1b:	80 f9 01             	cmp    $0x1,%cl
    9c1e:	75 25                	jne    9c45 <f23+0x2e5>
    9c20:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9c23:	0f b7 c0             	movzwl %ax,%eax
    9c26:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9c29:	48 0f af c1          	imul   %rcx,%rax
    9c2d:	48 c1 e8 20          	shr    $0x20,%rax
    9c31:	48 39 d0             	cmp    %rdx,%rax
    9c34:	73 0f                	jae    9c45 <f23+0x2e5>
    9c36:	48 01 c3             	add    %rax,%rbx
    9c39:	80 3b ff             	cmpb   $0xff,(%rbx)
    9c3c:	0f 84 b1 01 00 00    	je     9df3 <f23+0x493>
    9c42:	c6 03 01             	movb   $0x1,(%rbx)
    9c45:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    9c4a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9c51:	00 00 
    9c53:	0f 85 d6 01 00 00    	jne    9e2f <f23+0x4cf>
    9c59:	48 83 c4 38          	add    $0x38,%rsp
    9c5d:	48 89 e8             	mov    %rbp,%rax
    9c60:	5b                   	pop    %rbx
    9c61:	5d                   	pop    %rbp
    9c62:	41 5c                	pop    %r12
    9c64:	41 5d                	pop    %r13
    9c66:	41 5e                	pop    %r14
    9c68:	41 5f                	pop    %r15
    9c6a:	c3                   	ret
    9c6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9c70:	66 85 c0             	test   %ax,%ax
    9c73:	0f 85 8c fd ff ff    	jne    9a05 <f23+0xa5>
    9c79:	0f b6 07             	movzbl (%rdi),%eax
    9c7c:	84 c0                	test   %al,%al
    9c7e:	0f 84 81 fd ff ff    	je     9a05 <f23+0xa5>
    9c84:	3c fd                	cmp    $0xfd,%al
    9c86:	0f 87 99 01 00 00    	ja     9e25 <f23+0x4c5>
    9c8c:	83 c0 01             	add    $0x1,%eax
    9c8f:	88 07                	mov    %al,(%rdi)
    9c91:	e9 6f fd ff ff       	jmp    9a05 <f23+0xa5>
    9c96:	48 f7 d9             	neg    %rcx
    9c99:	48 39 d1             	cmp    %rdx,%rcx
    9c9c:	0f 83 ee 00 00 00    	jae    9d90 <f23+0x430>
    9ca2:	48 89 c8             	mov    %rcx,%rax
    9ca5:	48 c1 e8 10          	shr    $0x10,%rax
    9ca9:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    9cad:	48 8b 05 a4 7e 01 00 	mov    0x17ea4(%rip),%rax        # 21b58 <fwp_heap+0x13f8>
    9cb4:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    9cb8:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    9cbc:	48 85 ff             	test   %rdi,%rdi
    9cbf:	0f 84 cb 00 00 00    	je     9d90 <f23+0x430>
    9cc5:	0f b6 02             	movzbl (%rdx),%eax
    9cc8:	3c 02                	cmp    $0x2,%al
    9cca:	0f 84 9a 00 00 00    	je     9d6a <f23+0x40a>
    9cd0:	3c 01                	cmp    $0x1,%al
    9cd2:	0f 85 b8 00 00 00    	jne    9d90 <f23+0x430>
    9cd8:	0f b7 c1             	movzwl %cx,%eax
    9cdb:	8b 4a 18             	mov    0x18(%rdx),%ecx
    9cde:	8b 52 1c             	mov    0x1c(%rdx),%edx
    9ce1:	48 0f af c1          	imul   %rcx,%rax
    9ce5:	48 c1 e8 20          	shr    $0x20,%rax
    9ce9:	48 39 d0             	cmp    %rdx,%rax
    9cec:	0f 83 9e 00 00 00    	jae    9d90 <f23+0x430>
    9cf2:	48 01 c7             	add    %rax,%rdi
    9cf5:	0f b6 07             	movzbl (%rdi),%eax
    9cf8:	84 c0                	test   %al,%al
    9cfa:	0f 84 90 00 00 00    	je     9d90 <f23+0x430>
    9d00:	31 db                	xor    %ebx,%ebx
    9d02:	0f 1f 00             	nopl   (%rax)
    9d05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d0c:	00 00 00 00 
    9d10:	3c fd                	cmp    $0xfd,%al
    9d12:	0f 87 f5 00 00 00    	ja     9e0d <f23+0x4ad>
    9d18:	83 c0 01             	add    $0x1,%eax
    9d1b:	88 07                	mov    %al,(%rdi)
    9d1d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9d22:	31 d2                	xor    %edx,%edx
    9d24:	4d 85 ed             	test   %r13,%r13
    9d27:	0f 85 dd fc ff ff    	jne    9a0a <f23+0xaa>
    9d2d:	e9 fb fc ff ff       	jmp    9a2d <f23+0xcd>
    9d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9d38:	66 85 c0             	test   %ax,%ax
    9d3b:	0f 85 04 ff ff ff    	jne    9c45 <f23+0x2e5>
    9d41:	e9 f3 fe ff ff       	jmp    9c39 <f23+0x2d9>
    9d46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9d4d:	00 00 00 
    9d50:	66 85 c0             	test   %ax,%ax
    9d53:	0f 85 92 fd ff ff    	jne    9aeb <f23+0x18b>
    9d59:	e9 7f fd ff ff       	jmp    9add <f23+0x17d>
    9d5e:	66 90                	xchg   %ax,%ax
    9d60:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
    9d65:	e9 a4 fc ff ff       	jmp    9a0e <f23+0xae>
    9d6a:	66 85 c9             	test   %cx,%cx
    9d6d:	75 21                	jne    9d90 <f23+0x430>
    9d6f:	0f b6 07             	movzbl (%rdi),%eax
    9d72:	84 c0                	test   %al,%al
    9d74:	74 1a                	je     9d90 <f23+0x430>
    9d76:	3c fd                	cmp    $0xfd,%al
    9d78:	0f 87 c2 00 00 00    	ja     9e40 <f23+0x4e0>
    9d7e:	83 c0 01             	add    $0x1,%eax
    9d81:	88 07                	mov    %al,(%rdi)
    9d83:	66 90                	xchg   %ax,%ax
    9d85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    9d8c:	00 00 00 00 
    9d90:	be 02 00 00 00       	mov    $0x2,%esi
    9d95:	bf 08 00 00 00       	mov    $0x8,%edi
    9d9a:	e8 b1 bc ff ff       	call   5a50 <fwp_heap_alloc>
    9d9f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    9da6:	48 8b 15 8b 7d 01 00 	mov    0x17d8b(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    9dad:	49 89 c4             	mov    %rax,%r12
    9db0:	48 2b 05 59 7d 01 00 	sub    0x17d59(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    9db7:	48 c1 e2 10          	shl    $0x10,%rdx
    9dbb:	48 39 d0             	cmp    %rdx,%rax
    9dbe:	73 57                	jae    9e17 <f23+0x4b7>
    9dc0:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9dc7:	00 00 
    9dc9:	48 89 c2             	mov    %rax,%rdx
    9dcc:	48 c1 ea 10          	shr    $0x10,%rdx
    9dd0:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    9dd4:	48 8b 15 7d 7d 01 00 	mov    0x17d7d(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    9ddb:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    9ddf:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    9de3:	48 85 ed             	test   %rbp,%rbp
    9de6:	0f 84 61 fd ff ff    	je     9b4d <f23+0x1ed>
    9dec:	31 db                	xor    %ebx,%ebx
    9dee:	e9 c0 fc ff ff       	jmp    9ab3 <f23+0x153>
    9df3:	48 89 df             	mov    %rbx,%rdi
    9df6:	e8 15 b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9dfb:	e9 42 fe ff ff       	jmp    9c42 <f23+0x2e2>
    9e00:	48 89 ef             	mov    %rbp,%rdi
    9e03:	e8 08 b5 ff ff       	call   5310 <fwp_rc_forget_slot>
    9e08:	e9 da fc ff ff       	jmp    9ae7 <f23+0x187>
    9e0d:	e8 de b3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9e12:	e9 06 ff ff ff       	jmp    9d1d <f23+0x3bd>
    9e17:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
    9e1e:	00 00 
    9e20:	e9 28 fd ff ff       	jmp    9b4d <f23+0x1ed>
    9e25:	e8 c6 b3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9e2a:	e9 d6 fb ff ff       	jmp    9a05 <f23+0xa5>
    9e2f:	e8 2c 96 ff ff       	call   3460 <__stack_chk_fail@plt>
    9e34:	48 8d 3d 0c 23 00 00 	lea    0x230c(%rip),%rdi        # c147 <_IO_stdin_used+0x147>
    9e3b:	e8 60 a3 ff ff       	call   41a0 <fwp_trap>
    9e40:	e8 ab b3 ff ff       	call   51f0 <fwp_rc_wide_dup>
    9e45:	e9 46 ff ff ff       	jmp    9d90 <f23+0x430>
    9e4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000009e50 <fwp_owned_entry23>:
    9e50:	f3 0f 1e fa          	endbr64
    9e54:	48 8b 3f             	mov    (%rdi),%rdi
    9e57:	e9 04 fb ff ff       	jmp    9960 <f23>
    9e5c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000009e60 <e23>:
    9e60:	f3 0f 1e fa          	endbr64
    9e64:	53                   	push   %rbx
    9e65:	48 8b 1f             	mov    (%rdi),%rbx
    9e68:	48 89 df             	mov    %rbx,%rdi
    9e6b:	e8 60 ca ff ff       	call   68d0 <fwp_rc_share>
    9e70:	48 89 df             	mov    %rbx,%rdi
    9e73:	e8 e8 fa ff ff       	call   9960 <f23>
    9e78:	48 89 c3             	mov    %rax,%rbx
    9e7b:	48 89 c7             	mov    %rax,%rdi
    9e7e:	e8 4d ca ff ff       	call   68d0 <fwp_rc_share>
    9e83:	48 89 d8             	mov    %rbx,%rax
    9e86:	5b                   	pop    %rbx
    9e87:	c3                   	ret
    9e88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9e8f:	00 

0000000000009e90 <fwp_write>:
    9e90:	41 57                	push   %r15
    9e92:	41 56                	push   %r14
    9e94:	41 55                	push   %r13
    9e96:	41 54                	push   %r12
    9e98:	55                   	push   %rbp
    9e99:	53                   	push   %rbx
    9e9a:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    9ea1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    9ea8:	00 00 
    9eaa:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    9eb1:	00 
    9eb2:	49 89 d4             	mov    %rdx,%r12
    9eb5:	8b 12                	mov    (%rdx),%edx
    9eb7:	83 fa 19             	cmp    $0x19,%edx
    9eba:	77 6a                	ja     9f26 <fwp_write+0x96>
    9ebc:	48 89 f5             	mov    %rsi,%rbp
    9ebf:	89 d0                	mov    %edx,%eax
    9ec1:	89 ce                	mov    %ecx,%esi
    9ec3:	48 89 fb             	mov    %rdi,%rbx
    9ec6:	48 8d 0d 43 2b 00 00 	lea    0x2b43(%rip),%rcx        # ca10 <_IO_stdin_used+0xa10>
    9ecd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    9ed1:	48 01 c8             	add    %rcx,%rax
    9ed4:	3e ff e0             	notrack jmp *%rax
    9ed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9ede:	00 00 
    9ee0:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    9ee4:	48 8b 45 00          	mov    0x0(%rbp),%rax
    9ee8:	48 89 ca             	mov    %rcx,%rdx
    9eeb:	48 85 c9             	test   %rcx,%rcx
    9eee:	0f 88 9c 0c 00 00    	js     ab90 <fwp_write+0xd00>
    9ef4:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9efb:	00 
    9efc:	48 89 c6             	mov    %rax,%rsi
    9eff:	4c 89 e7             	mov    %r12,%rdi
    9f02:	e8 39 9b ff ff       	call   3a40 <fwp_fmt_u128>
    9f07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    9f0e:	00 00 
    9f10:	4c 89 e7             	mov    %r12,%rdi
    9f13:	e8 38 95 ff ff       	call   3450 <strlen@plt>
    9f18:	4c 89 e6             	mov    %r12,%rsi
    9f1b:	48 89 df             	mov    %rbx,%rdi
    9f1e:	48 89 c2             	mov    %rax,%rdx
    9f21:	e8 4a a1 ff ff       	call   4070 <buf_put>
    9f26:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9f2d:	00 
    9f2e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9f35:	00 00 
    9f37:	0f 85 28 04 00 00    	jne    a365 <fwp_write+0x4d5>
    9f3d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    9f44:	5b                   	pop    %rbx
    9f45:	5d                   	pop    %rbp
    9f46:	41 5c                	pop    %r12
    9f48:	41 5d                	pop    %r13
    9f4a:	41 5e                	pop    %r14
    9f4c:	41 5f                	pop    %r15
    9f4e:	c3                   	ret
    9f4f:	90                   	nop
    9f50:	49 89 e9             	mov    %rbp,%r9
    9f53:	4c 8d 05 27 22 00 00 	lea    0x2227(%rip),%r8        # c181 <_IO_stdin_used+0x181>
    9f5a:	b9 00 02 00 00       	mov    $0x200,%ecx
    9f5f:	ba 02 00 00 00       	mov    $0x2,%edx
    9f64:	be 00 02 00 00       	mov    $0x200,%esi
    9f69:	31 c0                	xor    %eax,%eax
    9f6b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f72:	00 
    9f73:	e8 38 94 ff ff       	call   33b0 <__snprintf_chk@plt>
    9f78:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9f7f:	00 
    9f80:	e8 cb 94 ff ff       	call   3450 <strlen@plt>
    9f85:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9f8c:	00 
    9f8d:	48 89 df             	mov    %rbx,%rdi
    9f90:	48 89 c2             	mov    %rax,%rdx
    9f93:	e8 d8 a0 ff ff       	call   4070 <buf_put>
    9f98:	eb 8c                	jmp    9f26 <fwp_write+0x96>
    9f9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fa0:	49 89 e9             	mov    %rbp,%r9
    9fa3:	4c 8d 05 d2 21 00 00 	lea    0x21d2(%rip),%r8        # c17c <_IO_stdin_used+0x17c>
    9faa:	eb ae                	jmp    9f5a <fwp_write+0xca>
    9fac:	0f 1f 40 00          	nopl   0x0(%rax)
    9fb0:	83 fa 13             	cmp    $0x13,%edx
    9fb3:	48 8d 05 b8 21 00 00 	lea    0x21b8(%rip),%rax        # c172 <_IO_stdin_used+0x172>
    9fba:	48 8d 35 b6 21 00 00 	lea    0x21b6(%rip),%rsi        # c177 <_IO_stdin_used+0x177>
    9fc1:	ba 04 00 00 00       	mov    $0x4,%edx
    9fc6:	48 0f 44 f0          	cmove  %rax,%rsi
    9fca:	45 31 ed             	xor    %r13d,%r13d
    9fcd:	e8 9e a0 ff ff       	call   4070 <buf_put>
    9fd2:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    9fd7:	0f 84 a3 08 00 00    	je     a880 <fwp_write+0x9f0>
    9fdd:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    9fe2:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    9fe7:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9fec:	48 89 df             	mov    %rbx,%rdi
    9fef:	49 0f 44 c5          	cmove  %r13,%rax
    9ff3:	31 c9                	xor    %ecx,%ecx
    9ff5:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    9ffa:	e8 91 fe ff ff       	call   9e90 <fwp_write>
    9fff:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    a004:	0f 84 6e 09 00 00    	je     a978 <fwp_write+0xae8>
    a00a:	49 83 c5 01          	add    $0x1,%r13
    a00e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a012:	0f 83 68 08 00 00    	jae    a880 <fwp_write+0x9f0>
    a018:	ba 02 00 00 00       	mov    $0x2,%edx
    a01d:	48 8d 35 9d 21 00 00 	lea    0x219d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a024:	48 89 df             	mov    %rbx,%rdi
    a027:	e8 44 a0 ff ff       	call   4070 <buf_put>
    a02c:	eb af                	jmp    9fdd <fwp_write+0x14d>
    a02e:	66 90                	xchg   %ax,%ax
    a030:	ba 06 00 00 00       	mov    $0x6,%edx
    a035:	48 8d 35 5e 21 00 00 	lea    0x215e(%rip),%rsi        # c19a <_IO_stdin_used+0x19a>
    a03c:	48 83 c5 10          	add    $0x10,%rbp
    a040:	e8 2b a0 ff ff       	call   4070 <buf_put>
    a045:	48 89 ef             	mov    %rbp,%rdi
    a048:	e8 03 94 ff ff       	call   3450 <strlen@plt>
    a04d:	48 89 ee             	mov    %rbp,%rsi
    a050:	48 89 df             	mov    %rbx,%rdi
    a053:	48 89 c2             	mov    %rax,%rdx
    a056:	e8 15 a0 ff ff       	call   4070 <buf_put>
    a05b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a060:	ba 01 00 00 00       	mov    $0x1,%edx
    a065:	48 89 df             	mov    %rbx,%rdi
    a068:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a06d:	e8 fe 9f ff ff       	call   4070 <buf_put>
    a072:	e9 af fe ff ff       	jmp    9f26 <fwp_write+0x96>
    a077:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a07e:	00 00 
    a080:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a087:	00 
    a088:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a08f:	00 00 
    a091:	0f 85 ce 02 00 00    	jne    a365 <fwp_write+0x4d5>
    a097:	ba 0a 00 00 00       	mov    $0xa,%edx
    a09c:	48 8d 35 e3 20 00 00 	lea    0x20e3(%rip),%rsi        # c186 <_IO_stdin_used+0x186>
    a0a3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    a0aa:	48 89 df             	mov    %rbx,%rdi
    a0ad:	5b                   	pop    %rbx
    a0ae:	5d                   	pop    %rbp
    a0af:	41 5c                	pop    %r12
    a0b1:	41 5d                	pop    %r13
    a0b3:	41 5e                	pop    %r14
    a0b5:	41 5f                	pop    %r15
    a0b7:	e9 b4 9f ff ff       	jmp    4070 <buf_put>
    a0bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a0c0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    a0c5:	4d 85 ed             	test   %r13,%r13
    a0c8:	0f 84 02 0c 00 00    	je     acd0 <fwp_write+0xe40>
    a0ce:	48 8d 35 f9 20 00 00 	lea    0x20f9(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    a0d5:	4c 89 ef             	mov    %r13,%rdi
    a0d8:	e8 53 94 ff ff       	call   3530 <strcmp@plt>
    a0dd:	41 89 c1             	mov    %eax,%r9d
    a0e0:	85 c0                	test   %eax,%eax
    a0e2:	0f 84 6c 0c 00 00    	je     ad54 <fwp_write+0xec4>
    a0e8:	4c 89 ef             	mov    %r13,%rdi
    a0eb:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a0f0:	e8 5b 93 ff ff       	call   3450 <strlen@plt>
    a0f5:	4c 89 ee             	mov    %r13,%rsi
    a0f8:	48 89 df             	mov    %rbx,%rdi
    a0fb:	48 89 c2             	mov    %rax,%rdx
    a0fe:	e8 6d 9f ff ff       	call   4070 <buf_put>
    a103:	ba 01 00 00 00       	mov    $0x1,%edx
    a108:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a10d:	48 89 df             	mov    %rbx,%rdi
    a110:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a115:	e8 56 9f ff ff       	call   4070 <buf_put>
    a11a:	ba 01 00 00 00       	mov    $0x1,%edx
    a11f:	4c 89 fe             	mov    %r15,%rsi
    a122:	48 89 df             	mov    %rbx,%rdi
    a125:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    a12a:	e8 41 9f ff ff       	call   4070 <buf_put>
    a12f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    a134:	45 31 f6             	xor    %r14d,%r14d
    a137:	85 d2                	test   %edx,%edx
    a139:	0f 8e 81 0a 00 00    	jle    abc0 <fwp_write+0xd30>
    a13f:	45 31 ed             	xor    %r13d,%r13d
    a142:	4d 85 ed             	test   %r13,%r13
    a145:	0f 85 75 07 00 00    	jne    a8c0 <fwp_write+0xa30>
    a14b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    a152:	00 
    a153:	45 85 f6             	test   %r14d,%r14d
    a156:	0f 84 84 07 00 00    	je     a8e0 <fwp_write+0xa50>
    a15c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    a161:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    a166:	48 89 df             	mov    %rbx,%rdi
    a169:	49 83 c5 01          	add    $0x1,%r13
    a16d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    a171:	31 c9                	xor    %ecx,%ecx
    a173:	e8 18 fd ff ff       	call   9e90 <fwp_write>
    a178:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    a17d:	7f c3                	jg     a142 <fwp_write+0x2b2>
    a17f:	45 85 f6             	test   %r14d,%r14d
    a182:	0f 84 38 0a 00 00    	je     abc0 <fwp_write+0xd30>
    a188:	b8 29 00 00 00       	mov    $0x29,%eax
    a18d:	ba 01 00 00 00       	mov    $0x1,%edx
    a192:	4c 89 fe             	mov    %r15,%rsi
    a195:	48 89 df             	mov    %rbx,%rdi
    a198:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    a19c:	e8 cf 9e ff ff       	call   4070 <buf_put>
    a1a1:	e9 80 fd ff ff       	jmp    9f26 <fwp_write+0x96>
    a1a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a1ad:	00 00 00 
    a1b0:	ba 01 00 00 00       	mov    $0x1,%edx
    a1b5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a1ba:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    a1bf:	e8 ac 9e ff ff       	call   4070 <buf_put>
    a1c4:	48 85 ed             	test   %rbp,%rbp
    a1c7:	0f 84 93 06 00 00    	je     a860 <fwp_write+0x9d0>
    a1cd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    a1d1:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a1d6:	31 c9                	xor    %ecx,%ecx
    a1d8:	48 89 df             	mov    %rbx,%rdi
    a1db:	e8 b0 fc ff ff       	call   9e90 <fwp_write>
    a1e0:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    a1e4:	48 85 ed             	test   %rbp,%rbp
    a1e7:	0f 84 73 06 00 00    	je     a860 <fwp_write+0x9d0>
    a1ed:	ba 02 00 00 00       	mov    $0x2,%edx
    a1f2:	48 8d 35 c8 1f 00 00 	lea    0x1fc8(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a1f9:	48 89 df             	mov    %rbx,%rdi
    a1fc:	e8 6f 9e ff ff       	call   4070 <buf_put>
    a201:	eb ca                	jmp    a1cd <fwp_write+0x33d>
    a203:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a208:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    a20c:	85 f6                	test   %esi,%esi
    a20e:	0f 84 fc 07 00 00    	je     aa10 <fwp_write+0xb80>
    a214:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a21b:	00 
    a21c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a223:	00 00 
    a225:	0f 85 3a 01 00 00    	jne    a365 <fwp_write+0x4d5>
    a22b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    a22f:	4c 89 ea             	mov    %r13,%rdx
    a232:	e9 6c fe ff ff       	jmp    a0a3 <fwp_write+0x213>
    a237:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a23e:	00 00 
    a240:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    a245:	ba 01 00 00 00       	mov    $0x1,%edx
    a24a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    a24f:	48 89 ee             	mov    %rbp,%rsi
    a252:	e8 19 9e ff ff       	call   4070 <buf_put>
    a257:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    a25c:	4c 89 e7             	mov    %r12,%rdi
    a25f:	e8 ec 91 ff ff       	call   3450 <strlen@plt>
    a264:	4c 89 e6             	mov    %r12,%rsi
    a267:	48 89 df             	mov    %rbx,%rdi
    a26a:	48 89 c2             	mov    %rax,%rdx
    a26d:	e8 fe 9d ff ff       	call   4070 <buf_put>
    a272:	ba 01 00 00 00       	mov    $0x1,%edx
    a277:	48 89 ee             	mov    %rbp,%rsi
    a27a:	48 89 df             	mov    %rbx,%rdi
    a27d:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    a282:	e8 e9 9d ff ff       	call   4070 <buf_put>
    a287:	e9 9a fc ff ff       	jmp    9f26 <fwp_write+0x96>
    a28c:	0f 1f 40 00          	nopl   0x0(%rax)
    a290:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    a295:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    a299:	0f 8a 8e 0b 00 00    	jp     ae2d <fwp_write+0xf9d>
    a29f:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a2a3:	66 0f 54 05 65 28 00 	andpd  0x2865(%rip),%xmm0        # cb10 <msg.4+0x90>
    a2aa:	00 
    a2ab:	bd 01 00 00 00       	mov    $0x1,%ebp
    a2b0:	66 0f 2e 05 a0 28 00 	ucomisd 0x28a0(%rip),%xmm0        # cb58 <msg.4+0xd8>
    a2b7:	00 
    a2b8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a2bf:	00 
    a2c0:	0f 87 b2 09 00 00    	ja     ac78 <fwp_write+0xde8>
    a2c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a2cd:	00 00 00 
    a2d0:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a2d4:	89 ee                	mov    %ebp,%esi
    a2d6:	4c 89 e7             	mov    %r12,%rdi
    a2d9:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    a2de:	e8 dd a1 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a2e3:	31 f6                	xor    %esi,%esi
    a2e5:	4c 89 e7             	mov    %r12,%rdi
    a2e8:	e8 23 91 ff ff       	call   3410 <strtod@plt>
    a2ed:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    a2f2:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    a2f6:	7a 06                	jp     a2fe <fwp_write+0x46e>
    a2f8:	0f 84 e9 01 00 00    	je     a4e7 <fwp_write+0x657>
    a2fe:	83 c5 01             	add    $0x1,%ebp
    a301:	83 fd 12             	cmp    $0x12,%ebp
    a304:	75 ca                	jne    a2d0 <fwp_write+0x440>
    a306:	be 11 00 00 00       	mov    $0x11,%esi
    a30b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    a30f:	4c 89 e7             	mov    %r12,%rdi
    a312:	e8 a9 a1 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a317:	e9 cb 01 00 00       	jmp    a4e7 <fwp_write+0x657>
    a31c:	0f 1f 40 00          	nopl   0x0(%rax)
    a320:	48 83 fd 01          	cmp    $0x1,%rbp
    a324:	0f 84 e6 08 00 00    	je     ac10 <fwp_write+0xd80>
    a32a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    a32e:	b8 02 00 00 00       	mov    $0x2,%eax
    a333:	ba 01 00 00 00       	mov    $0x1,%edx
    a338:	48 0f 44 d0          	cmove  %rax,%rdx
    a33c:	48 8d 35 27 1e 00 00 	lea    0x1e27(%rip),%rsi        # c16a <_IO_stdin_used+0x16a>
    a343:	48 8d 05 25 1e 00 00 	lea    0x1e25(%rip),%rax        # c16f <_IO_stdin_used+0x16f>
    a34a:	48 0f 44 f0          	cmove  %rax,%rsi
    a34e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a355:	00 
    a356:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a35d:	00 00 
    a35f:	0f 84 3e fd ff ff    	je     a0a3 <fwp_write+0x213>
    a365:	e8 f6 90 ff ff       	call   3460 <__stack_chk_fail@plt>
    a36a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a370:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    a375:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    a37a:	e8 31 9c ff ff       	call   3fb0 <buf_grow>
    a37f:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    a383:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    a389:	4c 03 0b             	add    (%rbx),%r9
    a38c:	66 45 89 11          	mov    %r10w,(%r9)
    a390:	45 85 e4             	test   %r12d,%r12d
    a393:	0f 8e 07 05 00 00    	jle    a8a0 <fwp_write+0xa10>
    a399:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    a3a0:	55 55 55 
    a3a3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    a3a8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    a3af:	aa aa aa 
    a3b2:	49 83 c1 01          	add    $0x1,%r9
    a3b6:	eb 45                	jmp    a3fd <fwp_write+0x56d>
    a3b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a3bf:	00 
    a3c0:	be 01 00 00 00       	mov    $0x1,%esi
    a3c5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    a3ca:	88 07                	mov    %al,(%rdi)
    a3cc:	48 89 e8             	mov    %rbp,%rax
    a3cf:	49 f7 e8             	imul   %r8
    a3d2:	48 89 e8             	mov    %rbp,%rax
    a3d5:	48 c1 f8 3f          	sar    $0x3f,%rax
    a3d9:	48 29 c2             	sub    %rax,%rdx
    a3dc:	48 85 c9             	test   %rcx,%rcx
    a3df:	0f 95 c0             	setne  %al
    a3e2:	48 c1 ed 3f          	shr    $0x3f,%rbp
    a3e6:	48 83 ef 01          	sub    $0x1,%rdi
    a3ea:	48 21 c5             	and    %rax,%rbp
    a3ed:	48 29 ea             	sub    %rbp,%rdx
    a3f0:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    a3f4:	49 39 f9             	cmp    %rdi,%r9
    a3f7:	0f 84 a3 04 00 00    	je     a8a0 <fwp_write+0xa10>
    a3fd:	48 89 e8             	mov    %rbp,%rax
    a400:	49 f7 e8             	imul   %r8
    a403:	48 89 e8             	mov    %rbp,%rax
    a406:	48 c1 f8 3f          	sar    $0x3f,%rax
    a40a:	48 89 d1             	mov    %rdx,%rcx
    a40d:	48 29 c1             	sub    %rax,%rcx
    a410:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    a414:	48 89 e9             	mov    %rbp,%rcx
    a417:	48 29 c1             	sub    %rax,%rcx
    a41a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    a41e:	49 f7 e2             	mul    %r10
    a421:	b8 30 00 00 00       	mov    $0x30,%eax
    a426:	48 89 d6             	mov    %rdx,%rsi
    a429:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    a42d:	48 d1 ee             	shr    $1,%rsi
    a430:	48 01 f2             	add    %rsi,%rdx
    a433:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    a437:	48 29 d6             	sub    %rdx,%rsi
    a43a:	74 8e                	je     a3ca <fwp_write+0x53a>
    a43c:	48 83 fe 01          	cmp    $0x1,%rsi
    a440:	0f 85 7a ff ff ff    	jne    a3c0 <fwp_write+0x530>
    a446:	31 f6                	xor    %esi,%esi
    a448:	b8 2b 00 00 00       	mov    $0x2b,%eax
    a44d:	e9 78 ff ff ff       	jmp    a3ca <fwp_write+0x53a>
    a452:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a458:	66 0f 6e cd          	movd   %ebp,%xmm1
    a45c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    a45f:	0f 8a c8 09 00 00    	jp     ae2d <fwp_write+0xf9d>
    a465:	0f 28 c1             	movaps %xmm1,%xmm0
    a468:	0f 54 05 91 26 00 00 	andps  0x2691(%rip),%xmm0        # cb00 <msg.4+0x80>
    a46f:	0f 2e 05 8e 1b 00 00 	ucomiss 0x1b8e(%rip),%xmm0        # c004 <_IO_stdin_used+0x4>
    a476:	0f 87 24 08 00 00    	ja     aca0 <fwp_write+0xe10>
    a47c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    a480:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    a486:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    a48d:	00 
    a48e:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    a492:	66 49 0f 7e d7       	movq   %xmm2,%r15
    a497:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a49e:	00 00 
    a4a0:	44 89 ee             	mov    %r13d,%esi
    a4a3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a4a8:	4c 89 e7             	mov    %r12,%rdi
    a4ab:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    a4b0:	e8 0b a0 ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a4b5:	31 f6                	xor    %esi,%esi
    a4b7:	4c 89 e7             	mov    %r12,%rdi
    a4ba:	e8 f1 8f ff ff       	call   34b0 <strtof@plt>
    a4bf:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    a4c4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    a4c7:	7a 02                	jp     a4cb <fwp_write+0x63b>
    a4c9:	74 1c                	je     a4e7 <fwp_write+0x657>
    a4cb:	41 83 c5 01          	add    $0x1,%r13d
    a4cf:	41 83 fd 0a          	cmp    $0xa,%r13d
    a4d3:	75 cb                	jne    a4a0 <fwp_write+0x610>
    a4d5:	be 09 00 00 00       	mov    $0x9,%esi
    a4da:	66 49 0f 6e c7       	movq   %r15,%xmm0
    a4df:	4c 89 e7             	mov    %r12,%rdi
    a4e2:	e8 d9 9f ff ff       	call   44c0 <fwp_format_g.constprop.0>
    a4e7:	4c 89 e7             	mov    %r12,%rdi
    a4ea:	e8 41 9c ff ff       	call   4130 <fwp_finish_float>
    a4ef:	e9 1c fa ff ff       	jmp    9f10 <fwp_write+0x80>
    a4f4:	0f 1f 40 00          	nopl   0x0(%rax)
    a4f8:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    a4fc:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    a500:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    a507:	00 
    a508:	48 89 ef             	mov    %rbp,%rdi
    a50b:	e8 30 95 ff ff       	call   3a40 <fwp_fmt_u128>
    a510:	48 89 ef             	mov    %rbp,%rdi
    a513:	e8 38 8f ff ff       	call   3450 <strlen@plt>
    a518:	48 89 ee             	mov    %rbp,%rsi
    a51b:	48 89 df             	mov    %rbx,%rdi
    a51e:	48 89 c2             	mov    %rax,%rdx
    a521:	e8 4a 9b ff ff       	call   4070 <buf_put>
    a526:	e9 fb f9 ff ff       	jmp    9f26 <fwp_write+0x96>
    a52b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a530:	ba 06 00 00 00       	mov    $0x6,%edx
    a535:	48 8d 35 88 1c 00 00 	lea    0x1c88(%rip),%rsi        # c1c4 <_IO_stdin_used+0x1c4>
    a53c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    a542:	e8 29 9b ff ff       	call   4070 <buf_put>
    a547:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a54e:	ff ff 7f 
    a551:	48 23 55 00          	and    0x0(%rbp),%rdx
    a555:	0f 84 86 02 00 00    	je     a7e1 <fwp_write+0x951>
    a55b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a560:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a564:	48 85 d2             	test   %rdx,%rdx
    a567:	0f 84 ae 00 00 00    	je     a61b <fwp_write+0x78b>
    a56d:	8b 0a                	mov    (%rdx),%ecx
    a56f:	83 f9 1c             	cmp    $0x1c,%ecx
    a572:	0f 84 58 06 00 00    	je     abd0 <fwp_write+0xd40>
    a578:	83 f9 1b             	cmp    $0x1b,%ecx
    a57b:	0f 87 9a 00 00 00    	ja     a61b <fwp_write+0x78b>
    a581:	be 01 00 00 00       	mov    $0x1,%esi
    a586:	48 d3 e6             	shl    %cl,%rsi
    a589:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    a58f:	0f 85 4b 04 00 00    	jne    a9e0 <fwp_write+0xb50>
    a595:	f7 c6 84 04 00 00    	test   $0x484,%esi
    a59b:	0f 85 0f 04 00 00    	jne    a9b0 <fwp_write+0xb20>
    a5a1:	83 e6 21             	and    $0x21,%esi
    a5a4:	74 75                	je     a61b <fwp_write+0x78b>
    a5a6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    a5ab:	48 85 ff             	test   %rdi,%rdi
    a5ae:	79 07                	jns    a5b7 <fwp_write+0x727>
    a5b0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    a5b4:	4c 01 ee             	add    %r13,%rsi
    a5b7:	48 0f be 3e          	movsbq (%rsi),%rdi
    a5bb:	85 c9                	test   %ecx,%ecx
    a5bd:	40 0f b6 f7          	movzbl %dil,%esi
    a5c1:	48 0f 44 f7          	cmove  %rdi,%rsi
    a5c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a5cc:	00 00 00 00 
    a5d0:	31 c9                	xor    %ecx,%ecx
    a5d2:	48 89 df             	mov    %rbx,%rdi
    a5d5:	49 83 c5 01          	add    $0x1,%r13
    a5d9:	e8 b2 f8 ff ff       	call   9e90 <fwp_write>
    a5de:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    a5e5:	ff ff 7f 
    a5e8:	48 23 55 00          	and    0x0(%rbp),%rdx
    a5ec:	49 39 d5             	cmp    %rdx,%r13
    a5ef:	0f 83 ec 01 00 00    	jae    a7e1 <fwp_write+0x951>
    a5f5:	ba 02 00 00 00       	mov    $0x2,%edx
    a5fa:	48 89 df             	mov    %rbx,%rdi
    a5fd:	48 8d 35 bd 1b 00 00 	lea    0x1bbd(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a604:	e8 67 9a ff ff       	call   4070 <buf_put>
    a609:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    a60e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    a612:	48 85 d2             	test   %rdx,%rdx
    a615:	0f 85 52 ff ff ff    	jne    a56d <fwp_write+0x6dd>
    a61b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    a620:	48 85 ff             	test   %rdi,%rdi
    a623:	0f 88 cf 05 00 00    	js     abf8 <fwp_write+0xd68>
    a629:	48 8b 31             	mov    (%rcx),%rsi
    a62c:	eb a2                	jmp    a5d0 <fwp_write+0x740>
    a62e:	66 90                	xchg   %ax,%ax
    a630:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    a637:	00 
    a638:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a63f:	00 00 
    a641:	0f 85 1e fd ff ff    	jne    a365 <fwp_write+0x4d5>
    a647:	ba 08 00 00 00       	mov    $0x8,%edx
    a64c:	48 8d 35 3e 1b 00 00 	lea    0x1b3e(%rip),%rsi        # c191 <_IO_stdin_used+0x191>
    a653:	e9 4b fa ff ff       	jmp    a0a3 <fwp_write+0x213>
    a658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    a65f:	00 
    a660:	89 e8                	mov    %ebp,%eax
    a662:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    a669:	76 03                	jbe    a66e <fwp_write+0x7de>
    a66b:	8b 45 00             	mov    0x0(%rbp),%eax
    a66e:	41 89 c6             	mov    %eax,%r14d
    a671:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a676:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    a67b:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    a67f:	4c 89 ef             	mov    %r13,%rdi
    a682:	e8 c9 8d ff ff       	call   3450 <strlen@plt>
    a687:	4c 89 ee             	mov    %r13,%rsi
    a68a:	48 89 df             	mov    %rbx,%rdi
    a68d:	48 89 c2             	mov    %rax,%rdx
    a690:	e8 db 99 ff ff       	call   4070 <buf_put>
    a695:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a69a:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    a69e:	85 f6                	test   %esi,%esi
    a6a0:	0f 8e 80 f8 ff ff    	jle    9f26 <fwp_write+0x96>
    a6a6:	45 31 ed             	xor    %r13d,%r13d
    a6a9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    a6ae:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    a6b3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a6b8:	ba 01 00 00 00       	mov    $0x1,%edx
    a6bd:	4c 89 fe             	mov    %r15,%rsi
    a6c0:	48 89 04 24          	mov    %rax,(%rsp)
    a6c4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    a6c9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    a6cd:	48 89 df             	mov    %rbx,%rdi
    a6d0:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    a6d4:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    a6d9:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    a6de:	e8 8d 99 ff ff       	call   4070 <buf_put>
    a6e3:	41 8b 06             	mov    (%r14),%eax
    a6e6:	83 f8 0e             	cmp    $0xe,%eax
    a6e9:	0f 84 71 02 00 00    	je     a960 <fwp_write+0xad0>
    a6ef:	83 f8 10             	cmp    $0x10,%eax
    a6f2:	0f 84 38 02 00 00    	je     a930 <fwp_write+0xaa0>
    a6f8:	83 f8 0a             	cmp    $0xa,%eax
    a6fb:	0f 84 7f 04 00 00    	je     ab80 <fwp_write+0xcf0>
    a701:	0f 8f f9 00 00 00    	jg     a800 <fwp_write+0x970>
    a707:	83 f8 03             	cmp    $0x3,%eax
    a70a:	0f 8f 50 04 00 00    	jg     ab60 <fwp_write+0xcd0>
    a710:	85 c0                	test   %eax,%eax
    a712:	78 10                	js     a724 <fwp_write+0x894>
    a714:	48 8b 04 24          	mov    (%rsp),%rax
    a718:	48 c1 e8 3f          	shr    $0x3f,%rax
    a71c:	85 c0                	test   %eax,%eax
    a71e:	0f 85 f9 00 00 00    	jne    a81d <fwp_write+0x98d>
    a724:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a729:	48 8b 34 24          	mov    (%rsp),%rsi
    a72d:	31 c9                	xor    %ecx,%ecx
    a72f:	48 89 df             	mov    %rbx,%rdi
    a732:	e8 59 f7 ff ff       	call   9e90 <fwp_write>
    a737:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    a73c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a741:	49 83 c5 01          	add    $0x1,%r13
    a745:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    a749:	0f 8f 5f ff ff ff    	jg     a6ae <fwp_write+0x81e>
    a74f:	e9 d2 f7 ff ff       	jmp    9f26 <fwp_write+0x96>
    a754:	0f 1f 40 00          	nopl   0x0(%rax)
    a758:	ba 06 00 00 00       	mov    $0x6,%edx
    a75d:	48 8d 35 53 1a 00 00 	lea    0x1a53(%rip),%rsi        # c1b7 <_IO_stdin_used+0x1b7>
    a764:	45 31 ed             	xor    %r13d,%r13d
    a767:	e8 04 99 ff ff       	call   4070 <buf_put>
    a76c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    a771:	75 19                	jne    a78c <fwp_write+0x8fc>
    a773:	eb 6c                	jmp    a7e1 <fwp_write+0x951>
    a775:	0f 1f 00             	nopl   (%rax)
    a778:	ba 02 00 00 00       	mov    $0x2,%edx
    a77d:	48 8d 35 3d 1a 00 00 	lea    0x1a3d(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a784:	48 89 df             	mov    %rbx,%rdi
    a787:	e8 e4 98 ff ff       	call   4070 <buf_put>
    a78c:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    a792:	b9 00 02 00 00       	mov    $0x200,%ecx
    a797:	31 c0                	xor    %eax,%eax
    a799:	49 83 c5 01          	add    $0x1,%r13
    a79d:	4c 8d 05 1a 1a 00 00 	lea    0x1a1a(%rip),%r8        # c1be <_IO_stdin_used+0x1be>
    a7a4:	ba 02 00 00 00       	mov    $0x2,%edx
    a7a9:	be 00 02 00 00       	mov    $0x200,%esi
    a7ae:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7b5:	00 
    a7b6:	e8 f5 8b ff ff       	call   33b0 <__snprintf_chk@plt>
    a7bb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    a7c2:	00 
    a7c3:	e8 88 8c ff ff       	call   3450 <strlen@plt>
    a7c8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    a7cf:	00 
    a7d0:	48 89 df             	mov    %rbx,%rdi
    a7d3:	48 89 c2             	mov    %rax,%rdx
    a7d6:	e8 95 98 ff ff       	call   4070 <buf_put>
    a7db:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    a7df:	72 97                	jb     a778 <fwp_write+0x8e8>
    a7e1:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a7e6:	ba 01 00 00 00       	mov    $0x1,%edx
    a7eb:	48 89 df             	mov    %rbx,%rdi
    a7ee:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a7f3:	e8 78 98 ff ff       	call   4070 <buf_put>
    a7f8:	e9 29 f7 ff ff       	jmp    9f26 <fwp_write+0x96>
    a7fd:	0f 1f 00             	nopl   (%rax)
    a800:	83 f8 0b             	cmp    $0xb,%eax
    a803:	0f 85 1b ff ff ff    	jne    a724 <fwp_write+0x894>
    a809:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    a80e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    a812:	83 e0 01             	and    $0x1,%eax
    a815:	85 c0                	test   %eax,%eax
    a817:	0f 84 07 ff ff ff    	je     a724 <fwp_write+0x894>
    a81d:	4c 89 fe             	mov    %r15,%rsi
    a820:	48 89 df             	mov    %rbx,%rdi
    a823:	ba 01 00 00 00       	mov    $0x1,%edx
    a828:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    a82d:	e8 3e 98 ff ff       	call   4070 <buf_put>
    a832:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    a837:	48 8b 34 24          	mov    (%rsp),%rsi
    a83b:	31 c9                	xor    %ecx,%ecx
    a83d:	48 89 df             	mov    %rbx,%rdi
    a840:	e8 4b f6 ff ff       	call   9e90 <fwp_write>
    a845:	ba 01 00 00 00       	mov    $0x1,%edx
    a84a:	4c 89 fe             	mov    %r15,%rsi
    a84d:	48 89 df             	mov    %rbx,%rdi
    a850:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    a855:	e8 16 98 ff ff       	call   4070 <buf_put>
    a85a:	e9 d8 fe ff ff       	jmp    a737 <fwp_write+0x8a7>
    a85f:	90                   	nop
    a860:	ba 01 00 00 00       	mov    $0x1,%edx
    a865:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a86a:	48 89 df             	mov    %rbx,%rdi
    a86d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    a872:	e8 f9 97 ff ff       	call   4070 <buf_put>
    a877:	e9 aa f6 ff ff       	jmp    9f26 <fwp_write+0x96>
    a87c:	0f 1f 40 00          	nopl   0x0(%rax)
    a880:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    a885:	ba 01 00 00 00       	mov    $0x1,%edx
    a88a:	48 89 df             	mov    %rbx,%rdi
    a88d:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    a892:	e8 d9 97 ff ff       	call   4070 <buf_put>
    a897:	e9 8a f6 ff ff       	jmp    9f26 <fwp_write+0x96>
    a89c:	0f 1f 40 00          	nopl   0x0(%rax)
    a8a0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    a8a4:	48 8b 13             	mov    (%rbx),%rdx
    a8a7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    a8ac:	48 89 43 08          	mov    %rax,0x8(%rbx)
    a8b0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    a8b4:	e9 6d f6 ff ff       	jmp    9f26 <fwp_write+0x96>
    a8b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8c0:	ba 02 00 00 00       	mov    $0x2,%edx
    a8c5:	48 8d 35 f5 18 00 00 	lea    0x18f5(%rip),%rsi        # c1c1 <_IO_stdin_used+0x1c1>
    a8cc:	48 89 df             	mov    %rbx,%rdi
    a8cf:	e8 9c 97 ff ff       	call   4070 <buf_put>
    a8d4:	e9 72 f8 ff ff       	jmp    a14b <fwp_write+0x2bb>
    a8d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8e0:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    a8e5:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    a8ea:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    a8ee:	48 89 f7             	mov    %rsi,%rdi
    a8f1:	48 89 34 24          	mov    %rsi,(%rsp)
    a8f5:	e8 56 8b ff ff       	call   3450 <strlen@plt>
    a8fa:	48 8b 34 24          	mov    (%rsp),%rsi
    a8fe:	48 89 df             	mov    %rbx,%rdi
    a901:	48 89 c2             	mov    %rax,%rdx
    a904:	e8 67 97 ff ff       	call   4070 <buf_put>
    a909:	ba 03 00 00 00       	mov    $0x3,%edx
    a90e:	48 8d 35 cf 18 00 00 	lea    0x18cf(%rip),%rsi        # c1e4 <_IO_stdin_used+0x1e4>
    a915:	48 89 df             	mov    %rbx,%rdi
    a918:	e8 53 97 ff ff       	call   4070 <buf_put>
    a91d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    a922:	e9 35 f8 ff ff       	jmp    a15c <fwp_write+0x2cc>
    a927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a92e:	00 00 
    a930:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    a935:	48 8b 78 08          	mov    0x8(%rax),%rdi
    a939:	48 85 ff             	test   %rdi,%rdi
    a93c:	0f 84 e2 fd ff ff    	je     a724 <fwp_write+0x894>
    a942:	48 8d 35 85 18 00 00 	lea    0x1885(%rip),%rsi        # c1ce <_IO_stdin_used+0x1ce>
    a949:	e8 e2 8b ff ff       	call   3530 <strcmp@plt>
    a94e:	85 c0                	test   %eax,%eax
    a950:	0f 95 c0             	setne  %al
    a953:	0f b6 c0             	movzbl %al,%eax
    a956:	e9 c1 fd ff ff       	jmp    a71c <fwp_write+0x88c>
    a95b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a960:	31 c0                	xor    %eax,%eax
    a962:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    a969:	00 
    a96a:	0f 97 c0             	seta   %al
    a96d:	e9 aa fd ff ff       	jmp    a71c <fwp_write+0x88c>
    a972:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a978:	48 89 df             	mov    %rbx,%rdi
    a97b:	ba 02 00 00 00       	mov    $0x2,%edx
    a980:	48 8d 35 44 18 00 00 	lea    0x1844(%rip),%rsi        # c1cb <_IO_stdin_used+0x1cb>
    a987:	e8 e4 96 ff ff       	call   4070 <buf_put>
    a98c:	4c 89 e8             	mov    %r13,%rax
    a98f:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    a994:	31 c9                	xor    %ecx,%ecx
    a996:	48 c1 e0 04          	shl    $0x4,%rax
    a99a:	48 89 df             	mov    %rbx,%rdi
    a99d:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    a9a2:	e8 e9 f4 ff ff       	call   9e90 <fwp_write>
    a9a7:	e9 5e f6 ff ff       	jmp    a00a <fwp_write+0x17a>
    a9ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a9b0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    a9b5:	48 85 ff             	test   %rdi,%rdi
    a9b8:	79 0c                	jns    a9c6 <fwp_write+0xb36>
    a9ba:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    a9c1:	00 
    a9c2:	48 03 75 10          	add    0x10(%rbp),%rsi
    a9c6:	48 63 3e             	movslq (%rsi),%rdi
    a9c9:	83 f9 02             	cmp    $0x2,%ecx
    a9cc:	89 fe                	mov    %edi,%esi
    a9ce:	48 0f 44 f7          	cmove  %rdi,%rsi
    a9d2:	e9 f9 fb ff ff       	jmp    a5d0 <fwp_write+0x740>
    a9d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9de:	00 00 
    a9e0:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    a9e5:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    a9ea:	48 85 ff             	test   %rdi,%rdi
    a9ed:	0f 88 0f 03 00 00    	js     ad02 <fwp_write+0xe72>
    a9f3:	49 0f bf 38          	movswq (%r8),%rdi
    a9f7:	83 f9 01             	cmp    $0x1,%ecx
    a9fa:	0f b7 f7             	movzwl %di,%esi
    a9fd:	48 0f 44 f7          	cmove  %rdi,%rsi
    aa01:	e9 ca fb ff ff       	jmp    a5d0 <fwp_write+0x740>
    aa06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa0d:	00 00 00 
    aa10:	ba 01 00 00 00       	mov    $0x1,%edx
    aa15:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    aa1a:	48 83 c5 08          	add    $0x8,%rbp
    aa1e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    aa23:	e8 48 96 ff ff       	call   4070 <buf_put>
    aa28:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    aa2d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    aa32:	4d 85 ed             	test   %r13,%r13
    aa35:	75 46                	jne    aa7d <fwp_write+0xbed>
    aa37:	e9 04 01 00 00       	jmp    ab40 <fwp_write+0xcb0>
    aa3c:	0f 1f 40 00          	nopl   0x0(%rax)
    aa40:	41 80 f9 09          	cmp    $0x9,%r9b
    aa44:	0f 84 d6 00 00 00    	je     ab20 <fwp_write+0xc90>
    aa4a:	41 80 f9 0a          	cmp    $0xa,%r9b
    aa4e:	0f 85 9c 00 00 00    	jne    aaf0 <fwp_write+0xc60>
    aa54:	ba 02 00 00 00       	mov    $0x2,%edx
    aa59:	48 8d 35 47 17 00 00 	lea    0x1747(%rip),%rsi        # c1a7 <_IO_stdin_used+0x1a7>
    aa60:	48 89 df             	mov    %rbx,%rdi
    aa63:	e8 08 96 ff ff       	call   4070 <buf_put>
    aa68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    aa6f:	00 
    aa70:	48 83 c5 01          	add    $0x1,%rbp
    aa74:	49 39 ec             	cmp    %rbp,%r12
    aa77:	0f 84 c3 00 00 00    	je     ab40 <fwp_write+0xcb0>
    aa7d:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    aa82:	41 80 f9 0d          	cmp    $0xd,%r9b
    aa86:	74 28                	je     aab0 <fwp_write+0xc20>
    aa88:	7e b6                	jle    aa40 <fwp_write+0xbb0>
    aa8a:	41 80 f9 22          	cmp    $0x22,%r9b
    aa8e:	74 40                	je     aad0 <fwp_write+0xc40>
    aa90:	41 80 f9 5c          	cmp    $0x5c,%r9b
    aa94:	75 5a                	jne    aaf0 <fwp_write+0xc60>
    aa96:	ba 02 00 00 00       	mov    $0x2,%edx
    aa9b:	48 8d 35 02 17 00 00 	lea    0x1702(%rip),%rsi        # c1a4 <_IO_stdin_used+0x1a4>
    aaa2:	48 89 df             	mov    %rbx,%rdi
    aaa5:	e8 c6 95 ff ff       	call   4070 <buf_put>
    aaaa:	eb c4                	jmp    aa70 <fwp_write+0xbe0>
    aaac:	0f 1f 40 00          	nopl   0x0(%rax)
    aab0:	ba 02 00 00 00       	mov    $0x2,%edx
    aab5:	48 8d 35 f1 16 00 00 	lea    0x16f1(%rip),%rsi        # c1ad <_IO_stdin_used+0x1ad>
    aabc:	48 89 df             	mov    %rbx,%rdi
    aabf:	e8 ac 95 ff ff       	call   4070 <buf_put>
    aac4:	eb aa                	jmp    aa70 <fwp_write+0xbe0>
    aac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aacd:	00 00 00 
    aad0:	ba 02 00 00 00       	mov    $0x2,%edx
    aad5:	48 8d 35 c5 16 00 00 	lea    0x16c5(%rip),%rsi        # c1a1 <_IO_stdin_used+0x1a1>
    aadc:	48 89 df             	mov    %rbx,%rdi
    aadf:	e8 8c 95 ff ff       	call   4070 <buf_put>
    aae4:	eb 8a                	jmp    aa70 <fwp_write+0xbe0>
    aae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aaed:	00 00 00 
    aaf0:	41 80 f9 1f          	cmp    $0x1f,%r9b
    aaf4:	0f 86 2e 01 00 00    	jbe    ac28 <fwp_write+0xd98>
    aafa:	41 80 f9 7f          	cmp    $0x7f,%r9b
    aafe:	0f 84 24 01 00 00    	je     ac28 <fwp_write+0xd98>
    ab04:	ba 01 00 00 00       	mov    $0x1,%edx
    ab09:	4c 89 fe             	mov    %r15,%rsi
    ab0c:	48 89 df             	mov    %rbx,%rdi
    ab0f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    ab14:	e8 57 95 ff ff       	call   4070 <buf_put>
    ab19:	e9 52 ff ff ff       	jmp    aa70 <fwp_write+0xbe0>
    ab1e:	66 90                	xchg   %ax,%ax
    ab20:	ba 02 00 00 00       	mov    $0x2,%edx
    ab25:	48 8d 35 7e 16 00 00 	lea    0x167e(%rip),%rsi        # c1aa <_IO_stdin_used+0x1aa>
    ab2c:	48 89 df             	mov    %rbx,%rdi
    ab2f:	e8 3c 95 ff ff       	call   4070 <buf_put>
    ab34:	e9 37 ff ff ff       	jmp    aa70 <fwp_write+0xbe0>
    ab39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ab40:	ba 01 00 00 00       	mov    $0x1,%edx
    ab45:	4c 89 fe             	mov    %r15,%rsi
    ab48:	48 89 df             	mov    %rbx,%rdi
    ab4b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    ab50:	e8 1b 95 ff ff       	call   4070 <buf_put>
    ab55:	e9 cc f3 ff ff       	jmp    9f26 <fwp_write+0x96>
    ab5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ab60:	83 f8 04             	cmp    $0x4,%eax
    ab63:	0f 85 bb fb ff ff    	jne    a724 <fwp_write+0x894>
    ab69:	48 8b 04 24          	mov    (%rsp),%rax
    ab6d:	48 8b 40 08          	mov    0x8(%rax),%rax
    ab71:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ab76:	48 c1 e8 3f          	shr    $0x3f,%rax
    ab7a:	e9 96 fc ff ff       	jmp    a815 <fwp_write+0x985>
    ab7f:	90                   	nop
    ab80:	8b 0c 24             	mov    (%rsp),%ecx
    ab83:	31 c0                	xor    %eax,%eax
    ab85:	85 c9                	test   %ecx,%ecx
    ab87:	0f 98 c0             	sets   %al
    ab8a:	e9 86 fc ff ff       	jmp    a815 <fwp_write+0x985>
    ab8f:	90                   	nop
    ab90:	48 f7 d8             	neg    %rax
    ab93:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    ab9a:	00 
    ab9b:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    aba2:	2d 
    aba3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    abaa:	00 
    abab:	48 83 d2 00          	adc    $0x0,%rdx
    abaf:	48 89 c6             	mov    %rax,%rsi
    abb2:	48 f7 da             	neg    %rdx
    abb5:	e8 86 8e ff ff       	call   3a40 <fwp_fmt_u128>
    abba:	e9 51 f3 ff ff       	jmp    9f10 <fwp_write+0x80>
    abbf:	90                   	nop
    abc0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    abc5:	e9 c3 f5 ff ff       	jmp    a18d <fwp_write+0x2fd>
    abca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    abd0:	4c 89 e9             	mov    %r13,%rcx
    abd3:	48 c1 e1 04          	shl    $0x4,%rcx
    abd7:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    abdc:	48 85 ff             	test   %rdi,%rdi
    abdf:	0f 89 eb f9 ff ff    	jns    a5d0 <fwp_write+0x740>
    abe5:	48 03 4d 10          	add    0x10(%rbp),%rcx
    abe9:	48 89 ce             	mov    %rcx,%rsi
    abec:	e9 df f9 ff ff       	jmp    a5d0 <fwp_write+0x740>
    abf1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    abf8:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    abff:	00 
    ac00:	48 03 4d 10          	add    0x10(%rbp),%rcx
    ac04:	e9 20 fa ff ff       	jmp    a629 <fwp_write+0x799>
    ac09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac10:	ba 02 00 00 00       	mov    $0x2,%edx
    ac15:	48 8d 35 50 15 00 00 	lea    0x1550(%rip),%rsi        # c16c <_IO_stdin_used+0x16c>
    ac1c:	e9 2d f7 ff ff       	jmp    a34e <fwp_write+0x4be>
    ac21:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    ac28:	4c 8d 05 81 15 00 00 	lea    0x1581(%rip),%r8        # c1b0 <_IO_stdin_used+0x1b0>
    ac2f:	b9 10 00 00 00       	mov    $0x10,%ecx
    ac34:	31 c0                	xor    %eax,%eax
    ac36:	ba 02 00 00 00       	mov    $0x2,%edx
    ac3b:	be 10 00 00 00       	mov    $0x10,%esi
    ac40:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac47:	00 
    ac48:	e8 63 87 ff ff       	call   33b0 <__snprintf_chk@plt>
    ac4d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    ac54:	00 
    ac55:	e8 f6 87 ff ff       	call   3450 <strlen@plt>
    ac5a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    ac61:	00 
    ac62:	48 89 df             	mov    %rbx,%rdi
    ac65:	48 89 c2             	mov    %rax,%rdx
    ac68:	e8 03 94 ff ff       	call   4070 <buf_put>
    ac6d:	e9 fe fd ff ff       	jmp    aa70 <fwp_write+0xbe0>
    ac72:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac78:	66 0f ef c0          	pxor   %xmm0,%xmm0
    ac7c:	48 8d 35 e3 14 00 00 	lea    0x14e3(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    ac83:	48 8d 05 db 14 00 00 	lea    0x14db(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    ac8a:	4c 89 e7             	mov    %r12,%rdi
    ac8d:	66 0f 2f c8          	comisd %xmm0,%xmm1
    ac91:	48 0f 46 f0          	cmovbe %rax,%rsi
    ac95:	e8 56 87 ff ff       	call   33f0 <strcpy@plt>
    ac9a:	e9 71 f2 ff ff       	jmp    9f10 <fwp_write+0x80>
    ac9f:	90                   	nop
    aca0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    aca4:	48 8d 35 bb 14 00 00 	lea    0x14bb(%rip),%rsi        # c166 <_IO_stdin_used+0x166>
    acab:	48 8d 05 b3 14 00 00 	lea    0x14b3(%rip),%rax        # c165 <_IO_stdin_used+0x165>
    acb2:	0f 2f c8             	comiss %xmm0,%xmm1
    acb5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    acbc:	00 
    acbd:	4c 89 e7             	mov    %r12,%rdi
    acc0:	48 0f 46 f0          	cmovbe %rax,%rsi
    acc4:	e8 27 87 ff ff       	call   33f0 <strcpy@plt>
    acc9:	e9 42 f2 ff ff       	jmp    9f10 <fwp_write+0x80>
    acce:	66 90                	xchg   %ax,%ax
    acd0:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    acd5:	45 85 c0             	test   %r8d,%r8d
    acd8:	75 34                	jne    ad0e <fwp_write+0xe7e>
    acda:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    ace1:	00 
    ace2:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    ace9:	00 00 
    aceb:	0f 85 74 f6 ff ff    	jne    a365 <fwp_write+0x4d5>
    acf1:	ba 02 00 00 00       	mov    $0x2,%edx
    acf6:	48 8d 35 e4 14 00 00 	lea    0x14e4(%rip),%rsi        # c1e1 <_IO_stdin_used+0x1e1>
    acfd:	e9 a1 f3 ff ff       	jmp    a0a3 <fwp_write+0x213>
    ad02:	48 03 75 10          	add    0x10(%rbp),%rsi
    ad06:	49 89 f0             	mov    %rsi,%r8
    ad09:	e9 e5 fc ff ff       	jmp    a9f3 <fwp_write+0xb63>
    ad0e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    ad13:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad18:	85 ff                	test   %edi,%edi
    ad1a:	0f 84 fa f3 ff ff    	je     a11a <fwp_write+0x28a>
    ad20:	ba 01 00 00 00       	mov    $0x1,%edx
    ad25:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    ad2a:	48 89 df             	mov    %rbx,%rdi
    ad2d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    ad32:	e8 39 93 ff ff       	call   4070 <buf_put>
    ad37:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    ad3c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    ad41:	41 be 01 00 00 00    	mov    $0x1,%r14d
    ad47:	85 c0                	test   %eax,%eax
    ad49:	0f 8f f0 f3 ff ff    	jg     a13f <fwp_write+0x2af>
    ad4f:	e9 34 f4 ff ff       	jmp    a188 <fwp_write+0x2f8>
    ad54:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad58:	49 89 c5             	mov    %rax,%r13
    ad5b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    ad60:	49 89 c4             	mov    %rax,%r12
    ad63:	49 c1 fd 3f          	sar    $0x3f,%r13
    ad67:	4c 09 e8             	or     %r13,%rax
    ad6a:	0f 84 a7 00 00 00    	je     ae17 <fwp_write+0xf87>
    ad70:	48 8d 2d a9 36 00 00 	lea    0x36a9(%rip),%rbp        # e420 <units.1>
    ad77:	4d 89 e7             	mov    %r12,%r15
    ad7a:	48 8b 45 08          	mov    0x8(%rbp),%rax
    ad7e:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    ad83:	4c 89 ff             	mov    %r15,%rdi
    ad86:	4c 89 ee             	mov    %r13,%rsi
    ad89:	44 89 0c 24          	mov    %r9d,(%rsp)
    ad8d:	48 99                	cqto
    ad8f:	48 89 d1             	mov    %rdx,%rcx
    ad92:	48 89 c2             	mov    %rax,%rdx
    ad95:	e8 c6 0f 00 00       	call   bd60 <__divmodti4>
    ad9a:	44 8b 0c 24          	mov    (%rsp),%r9d
    ad9e:	48 89 c1             	mov    %rax,%rcx
    ada1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    ada6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    adab:	0f 84 94 00 00 00    	je     ae45 <fwp_write+0xfb5>
    adb1:	41 83 c1 01          	add    $0x1,%r9d
    adb5:	48 83 c5 10          	add    $0x10,%rbp
    adb9:	41 83 f9 05          	cmp    $0x5,%r9d
    adbd:	75 bb                	jne    ad7a <fwp_write+0xeea>
    adbf:	4d 85 ed             	test   %r13,%r13
    adc2:	79 53                	jns    ae17 <fwp_write+0xf87>
    adc4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    adc9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    adce:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    add3:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    add8:	48 99                	cqto
    adda:	48 f7 d8             	neg    %rax
    addd:	48 83 d2 00          	adc    $0x0,%rdx
    ade1:	48 89 c6             	mov    %rax,%rsi
    ade4:	48 f7 da             	neg    %rdx
    ade7:	e8 54 8c ff ff       	call   3a40 <fwp_fmt_u128>
    adec:	49 89 e8             	mov    %rbp,%r8
    adef:	ba 00 02 00 00       	mov    $0x200,%edx
    adf4:	be 02 00 00 00       	mov    $0x2,%esi
    adf9:	31 c0                	xor    %eax,%eax
    adfb:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae02:	00 
    ae03:	48 8d 0d d2 13 00 00 	lea    0x13d2(%rip),%rcx        # c1dc <_IO_stdin_used+0x1dc>
    ae0a:	4c 89 e7             	mov    %r12,%rdi
    ae0d:	e8 ce 88 ff ff       	call   36e0 <__sprintf_chk@plt>
    ae12:	e9 f9 f0 ff ff       	jmp    9f10 <fwp_write+0x80>
    ae17:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae1c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    ae21:	31 d2                	xor    %edx,%edx
    ae23:	48 89 ef             	mov    %rbp,%rdi
    ae26:	e8 15 8c ff ff       	call   3a40 <fwp_fmt_u128>
    ae2b:	eb bf                	jmp    adec <fwp_write+0xf5c>
    ae2d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    ae34:	4e 61 4e 00 
    ae38:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae3f:	00 
    ae40:	e9 cb f0 ff ff       	jmp    9f10 <fwp_write+0x80>
    ae45:	44 89 0c 24          	mov    %r9d,(%rsp)
    ae49:	48 89 c8             	mov    %rcx,%rax
    ae4c:	48 85 d2             	test   %rdx,%rdx
    ae4f:	78 51                	js     aea2 <fwp_write+0x1012>
    ae51:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    ae56:	48 89 c6             	mov    %rax,%rsi
    ae59:	48 89 ef             	mov    %rbp,%rdi
    ae5c:	e8 df 8b ff ff       	call   3a40 <fwp_fmt_u128>
    ae61:	44 8b 0c 24          	mov    (%rsp),%r9d
    ae65:	49 63 c1             	movslq %r9d,%rax
    ae68:	49 89 e8             	mov    %rbp,%r8
    ae6b:	ba 00 02 00 00       	mov    $0x200,%edx
    ae70:	be 02 00 00 00       	mov    $0x2,%esi
    ae75:	48 c1 e0 04          	shl    $0x4,%rax
    ae79:	48 8d 3d a0 35 00 00 	lea    0x35a0(%rip),%rdi        # e420 <units.1>
    ae80:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    ae87:	00 
    ae88:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    ae8c:	48 8d 0d 44 13 00 00 	lea    0x1344(%rip),%rcx        # c1d7 <_IO_stdin_used+0x1d7>
    ae93:	4c 89 e7             	mov    %r12,%rdi
    ae96:	31 c0                	xor    %eax,%eax
    ae98:	e8 43 88 ff ff       	call   36e0 <__sprintf_chk@plt>
    ae9d:	e9 6e f0 ff ff       	jmp    9f10 <fwp_write+0x80>
    aea2:	48 f7 d8             	neg    %rax
    aea5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    aeaa:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    aeaf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    aeb4:	48 83 d2 00          	adc    $0x0,%rdx
    aeb8:	48 89 c6             	mov    %rax,%rsi
    aebb:	48 f7 da             	neg    %rdx
    aebe:	e8 7d 8b ff ff       	call   3a40 <fwp_fmt_u128>
    aec3:	44 8b 0c 24          	mov    (%rsp),%r9d
    aec7:	eb 9c                	jmp    ae65 <fwp_write+0xfd5>
    aec9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

000000000000aed0 <fwp_main_thread>:
    aed0:	f3 0f 1e fa          	endbr64
    aed4:	41 57                	push   %r15
    aed6:	41 56                	push   %r14
    aed8:	41 55                	push   %r13
    aeda:	41 54                	push   %r12
    aedc:	55                   	push   %rbp
    aedd:	53                   	push   %rbx
    aede:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    aee5:	8b 35 19 6c 01 00    	mov    0x16c19(%rip),%esi        # 21b04 <fwp_heap+0x13a4>
    aeeb:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    aef2:	00 00 
    aef4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    aefb:	00 
    aefc:	31 c0                	xor    %eax,%eax
    aefe:	85 f6                	test   %esi,%esi
    af00:	0f 84 42 06 00 00    	je     b548 <fwp_main_thread+0x678>
    af06:	8b 0d fc 6b 01 00    	mov    0x16bfc(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    af0c:	85 c9                	test   %ecx,%ecx
    af0e:	0f 85 47 06 00 00    	jne    b55b <fwp_main_thread+0x68b>
    af14:	48 8d 05 65 51 00 00 	lea    0x5165(%rip),%rax        # 10080 <alt.5>
    af1b:	4c 8d 64 24 20       	lea    0x20(%rsp),%r12
    af20:	31 f6                	xor    %esi,%esi
    af22:	48 c7 05 cb 51 01 00 	movq   $0x40000000,0x151cb(%rip)        # 200f8 <fwp_main_stack_size>
    af29:	00 00 00 40 
    af2d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    af32:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    af37:	48 89 c7             	mov    %rax,%rdi
    af3a:	4c 89 25 bf 51 01 00 	mov    %r12,0x151bf(%rip)        # 20100 <fwp_main_stack_top>
    af41:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    af48:	01 00 
    af4a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    af51:	00 
    af52:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    af57:	e8 64 87 ff ff       	call   36c0 <sigaltstack@plt>
    af5c:	85 c0                	test   %eax,%eax
    af5e:	0f 85 b7 0d 00 00    	jne    bd1b <fwp_main_thread+0xe4b>
    af64:	31 db                	xor    %ebx,%ebx
    af66:	b9 12 00 00 00       	mov    $0x12,%ecx
    af6b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    af72:	00 
    af73:	48 89 d8             	mov    %rbx,%rax
    af76:	4c 8d b4 24 80 00 00 	lea    0x80(%rsp),%r14
    af7d:	00 
    af7e:	f3 48 ab             	rep stos %rax,(%rdi)
    af81:	48 8d 05 68 8d ff ff 	lea    -0x7298(%rip),%rax        # 3cf0 <fwp_segv>
    af88:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    af8f:	00 
    af90:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    af95:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    af9c:	00 
    af9d:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    afa4:	04 00 00 08 
    afa8:	e8 d3 85 ff ff       	call   3580 <sigemptyset@plt>
    afad:	85 c0                	test   %eax,%eax
    afaf:	0f 85 66 0d 00 00    	jne    bd1b <fwp_main_thread+0xe4b>
    afb5:	31 d2                	xor    %edx,%edx
    afb7:	4c 89 f6             	mov    %r14,%rsi
    afba:	bf 0b 00 00 00       	mov    $0xb,%edi
    afbf:	e8 3c 84 ff ff       	call   3400 <sigaction@plt>
    afc4:	85 c0                	test   %eax,%eax
    afc6:	0f 85 4f 0d 00 00    	jne    bd1b <fwp_main_thread+0xe4b>
    afcc:	31 d2                	xor    %edx,%edx
    afce:	4c 89 f6             	mov    %r14,%rsi
    afd1:	bf 07 00 00 00       	mov    $0x7,%edi
    afd6:	e8 25 84 ff ff       	call   3400 <sigaction@plt>
    afdb:	85 c0                	test   %eax,%eax
    afdd:	0f 85 38 0d 00 00    	jne    bd1b <fwp_main_thread+0xe4b>
    afe3:	8b 15 87 50 00 00    	mov    0x5087(%rip),%edx        # 10070 <st.3>
    afe9:	85 d2                	test   %edx,%edx
    afeb:	0f 84 7f 05 00 00    	je     b570 <fwp_main_thread+0x6a0>
    aff1:	48 8b 2d 48 57 01 00 	mov    0x15748(%rip),%rbp        # 20740 <fwp_cur>
    aff8:	48 85 ed             	test   %rbp,%rbp
    affb:	0f 84 bf 01 00 00    	je     b1c0 <fwp_main_thread+0x2f0>
    b001:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    b006:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    b00a:	48 89 eb             	mov    %rbp,%rbx
    b00d:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b012:	0f 84 41 01 00 00    	je     b159 <fwp_main_thread+0x289>
    b018:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    b01d:	0f 84 9d 02 00 00    	je     b2c0 <fwp_main_thread+0x3f0>
    b023:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b027:	0f 84 73 02 00 00    	je     b2a0 <fwp_main_thread+0x3d0>
    b02d:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b031:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b035:	0f 85 05 03 00 00    	jne    b340 <fwp_main_thread+0x470>
    b03b:	48 8b 43 60          	mov    0x60(%rbx),%rax
    b03f:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b046:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b04a:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b051:	00 00 00 00 
    b055:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b05c:	48 85 d2             	test   %rdx,%rdx
    b05f:	74 07                	je     b068 <fwp_main_thread+0x198>
    b061:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b068:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b06c:	48 85 c0             	test   %rax,%rax
    b06f:	74 34                	je     b0a5 <fwp_main_thread+0x1d5>
    b071:	48 89 43 68          	mov    %rax,0x68(%rbx)
    b075:	48 8b 05 9c 56 01 00 	mov    0x1569c(%rip),%rax        # 20718 <fwp_timers>
    b07c:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    b080:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    b087:	00 00 00 00 
    b08b:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    b092:	48 85 c0             	test   %rax,%rax
    b095:	74 07                	je     b09e <fwp_main_thread+0x1ce>
    b097:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    b09e:	48 89 1d 73 56 01 00 	mov    %rbx,0x15673(%rip)        # 20718 <fwp_timers>
    b0a5:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    b0a9:	e8 02 c4 ff ff       	call   74b0 <fwp_block>
    b0ae:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    b0b5:	48 85 c9             	test   %rcx,%rcx
    b0b8:	74 47                	je     b101 <fwp_main_thread+0x231>
    b0ba:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    b0c1:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b0c8:	48 85 d2             	test   %rdx,%rdx
    b0cb:	0f 84 af 02 00 00    	je     b380 <fwp_main_thread+0x4b0>
    b0d1:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    b0d8:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    b0df:	48 85 c0             	test   %rax,%rax
    b0e2:	74 07                	je     b0eb <fwp_main_thread+0x21b>
    b0e4:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    b0eb:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    b0f2:	00 00 00 00 
    b0f6:	66 0f ef c9          	pxor   %xmm1,%xmm1
    b0fa:	0f 11 8b 18 01 00 00 	movups %xmm1,0x118(%rbx)
    b101:	48 8b 0d 38 56 01 00 	mov    0x15638(%rip),%rcx        # 20740 <fwp_cur>
    b108:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    b10c:	0f 84 1e 02 00 00    	je     b330 <fwp_main_thread+0x460>
    b112:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    b119:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    b120:	48 85 d2             	test   %rdx,%rdx
    b123:	0f 84 0f 04 00 00    	je     b538 <fwp_main_thread+0x668>
    b129:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    b130:	48 85 c0             	test   %rax,%rax
    b133:	74 07                	je     b13c <fwp_main_thread+0x26c>
    b135:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    b13c:	66 0f ef d2          	pxor   %xmm2,%xmm2
    b140:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    b144:	0f 11 93 08 01 00 00 	movups %xmm2,0x108(%rbx)
    b14b:	48 89 cb             	mov    %rcx,%rbx
    b14e:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    b153:	0f 85 bf fe ff ff    	jne    b018 <fwp_main_thread+0x148>
    b159:	48 83 3d 77 72 01 00 	cmpq   $0x0,0x17277(%rip)        # 223d8 <fwp_state_len>
    b160:	00 
    b161:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    b165:	74 69                	je     b1d0 <fwp_main_thread+0x300>
    b167:	48 39 1d ca 55 01 00 	cmp    %rbx,0x155ca(%rip)        # 20738 <fwp_root>
    b16e:	c7 05 08 4f 01 00 00 	movl   $0x0,0x14f08(%rip)        # 20080 <fwp_exit_code>
    b175:	00 00 00 
    b178:	0f 85 d0 0b 00 00    	jne    bd4e <fwp_main_thread+0xe7e>
    b17e:	48 85 db             	test   %rbx,%rbx
    b181:	0f 84 21 02 00 00    	je     b3a8 <fwp_main_thread+0x4d8>
    b187:	48 8b 15 7a 55 01 00 	mov    0x1557a(%rip),%rdx        # 20708 <fwp_tasks_active>
    b18e:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    b192:	48 85 d2             	test   %rdx,%rdx
    b195:	0f 84 0d 02 00 00    	je     b3a8 <fwp_main_thread+0x4d8>
    b19b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b1a0:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    b1a4:	75 08                	jne    b1ae <fwp_main_thread+0x2de>
    b1a6:	48 89 d7             	mov    %rdx,%rdi
    b1a9:	e8 02 8f ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    b1ae:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    b1b5:	48 85 d2             	test   %rdx,%rdx
    b1b8:	75 e6                	jne    b1a0 <fwp_main_thread+0x2d0>
    b1ba:	e9 ae 00 00 00       	jmp    b26d <fwp_main_thread+0x39d>
    b1bf:	90                   	nop
    b1c0:	48 83 3d 10 72 01 00 	cmpq   $0x0,0x17210(%rip)        # 223d8 <fwp_state_len>
    b1c7:	00 
    b1c8:	0f 85 c2 01 00 00    	jne    b390 <fwp_main_thread+0x4c0>
    b1ce:	31 db                	xor    %ebx,%ebx
    b1d0:	48 83 3d f0 71 01 00 	cmpq   $0x0,0x171f0(%rip)        # 223c8 <fwp_state_owners>
    b1d7:	00 
    b1d8:	75 8d                	jne    b167 <fwp_main_thread+0x297>
    b1da:	48 8b 3d ff 71 01 00 	mov    0x171ff(%rip),%rdi        # 223e0 <fwp_state>
    b1e1:	e8 6a a3 ff ff       	call   5550 <fwp_mem_free>
    b1e6:	48 c7 05 ef 71 01 00 	movq   $0x0,0x171ef(%rip)        # 223e0 <fwp_state>
    b1ed:	00 00 00 00 
    b1f1:	48 c7 05 d4 71 01 00 	movq   $0x0,0x171d4(%rip)        # 223d0 <fwp_state_cap>
    b1f8:	00 00 00 00 
    b1fc:	48 85 db             	test   %rbx,%rbx
    b1ff:	0f 84 1e 0a 00 00    	je     bc23 <fwp_main_thread+0xd53>
    b205:	48 39 1d 2c 55 01 00 	cmp    %rbx,0x1552c(%rip)        # 20738 <fwp_root>
    b20c:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    b213:	00 00 00 00 
    b217:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    b21e:	00 00 00 00 
    b222:	c7 05 54 4e 01 00 00 	movl   $0x0,0x14e54(%rip)        # 20080 <fwp_exit_code>
    b229:	00 00 00 
    b22c:	0f 84 55 ff ff ff    	je     b187 <fwp_main_thread+0x2b7>
    b232:	e9 19 85 ff ff       	jmp    3750 <fwp_main_thread.cold>
    b237:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b23e:	00 00 
    b240:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    b247:	48 89 1d d2 54 01 00 	mov    %rbx,0x154d2(%rip)        # 20720 <fwp_ready_tail>
    b24e:	e8 5d c2 ff ff       	call   74b0 <fwp_block>
    b253:	e8 58 c0 ff ff       	call   72b0 <fwp_free_zombie>
    b258:	48 83 3d a8 54 01 00 	cmpq   $0x0,0x154a8(%rip)        # 20708 <fwp_tasks_active>
    b25f:	00 
    b260:	0f 84 42 01 00 00    	je     b3a8 <fwp_main_thread+0x4d8>
    b266:	48 8b 1d cb 54 01 00 	mov    0x154cb(%rip),%rbx        # 20738 <fwp_root>
    b26d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    b271:	75 db                	jne    b24e <fwp_main_thread+0x37e>
    b273:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    b277:	75 d5                	jne    b24e <fwp_main_thread+0x37e>
    b279:	48 8b 05 a0 54 01 00 	mov    0x154a0(%rip),%rax        # 20720 <fwp_ready_tail>
    b280:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    b284:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    b28b:	00 00 00 00 
    b28f:	48 85 c0             	test   %rax,%rax
    b292:	75 ac                	jne    b240 <fwp_main_thread+0x370>
    b294:	48 89 1d 8d 54 01 00 	mov    %rbx,0x1548d(%rip)        # 20728 <fwp_ready_head>
    b29b:	eb aa                	jmp    b247 <fwp_main_thread+0x377>
    b29d:	0f 1f 00             	nopl   (%rax)
    b2a0:	e8 6b 90 ff ff       	call   4310 <fwp_now_ns>
    b2a5:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    b2a9:	7c 15                	jl     b2c0 <fwp_main_thread+0x3f0>
    b2ab:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    b2af:	75 0f                	jne    b2c0 <fwp_main_thread+0x3f0>
    b2b1:	48 89 ef             	mov    %rbp,%rdi
    b2b4:	e8 f7 8d ff ff       	call   40b0 <fwp_cancel_tree.part.0>
    b2b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b2c0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    b2c4:	0f 85 63 fd ff ff    	jne    b02d <fwp_main_thread+0x15d>
    b2ca:	48 8b 45 60          	mov    0x60(%rbp),%rax
    b2ce:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    b2d2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    b2d6:	0f 85 63 fd ff ff    	jne    b03f <fwp_main_thread+0x16f>
    b2dc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    b2e0:	48 85 c9             	test   %rcx,%rcx
    b2e3:	0f 84 56 fd ff ff    	je     b03f <fwp_main_thread+0x16f>
    b2e9:	48 39 c8             	cmp    %rcx,%rax
    b2ec:	48 89 ce             	mov    %rcx,%rsi
    b2ef:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b2f6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    b2fa:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b301:	00 00 00 00 
    b305:	48 0f 4e f0          	cmovle %rax,%rsi
    b309:	48 85 c0             	test   %rax,%rax
    b30c:	48 89 c8             	mov    %rcx,%rax
    b30f:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    b316:	48 0f 45 c6          	cmovne %rsi,%rax
    b31a:	48 85 d2             	test   %rdx,%rdx
    b31d:	74 07                	je     b326 <fwp_main_thread+0x456>
    b31f:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    b326:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b32a:	e9 42 fd ff ff       	jmp    b071 <fwp_main_thread+0x1a1>
    b32f:	90                   	nop
    b330:	48 89 cb             	mov    %rcx,%rbx
    b333:	e9 d5 fc ff ff       	jmp    b00d <fwp_main_thread+0x13d>
    b338:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b33f:	00 
    b340:	48 8b 45 40          	mov    0x40(%rbp),%rax
    b344:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    b34b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    b352:	00 00 00 00 
    b356:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    b35d:	48 85 c0             	test   %rax,%rax
    b360:	0f 84 3a 08 00 00    	je     bba0 <fwp_main_thread+0xcd0>
    b366:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    b36d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    b371:	e9 2f fd ff ff       	jmp    b0a5 <fwp_main_thread+0x1d5>
    b376:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    b37d:	00 00 00 
    b380:	48 89 01             	mov    %rax,(%rcx)
    b383:	e9 57 fd ff ff       	jmp    b0df <fwp_main_thread+0x20f>
    b388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b38f:	00 
    b390:	48 83 3d a0 53 01 00 	cmpq   $0x0,0x153a0(%rip)        # 20738 <fwp_root>
    b397:	00 
    b398:	c7 05 de 4c 01 00 00 	movl   $0x0,0x14cde(%rip)        # 20080 <fwp_exit_code>
    b39f:	00 00 00 
    b3a2:	0f 85 a1 09 00 00    	jne    bd49 <fwp_main_thread+0xe79>
    b3a8:	e8 03 bf ff ff       	call   72b0 <fwp_free_zombie>
    b3ad:	48 83 3d 73 53 01 00 	cmpq   $0x0,0x15373(%rip)        # 20728 <fwp_ready_head>
    b3b4:	00 
    b3b5:	0f 85 95 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3bb:	48 83 3d 55 53 01 00 	cmpq   $0x0,0x15355(%rip)        # 20718 <fwp_timers>
    b3c2:	00 
    b3c3:	0f 85 87 83 ff ff    	jne    3750 <fwp_main_thread.cold>
    b3c9:	8b 05 3d 4d 01 00    	mov    0x14d3d(%rip),%eax        # 2010c <fwp_stack_pool_n>
    b3cf:	85 c0                	test   %eax,%eax
    b3d1:	74 3a                	je     b40d <fwp_main_thread+0x53d>
    b3d3:	83 e8 01             	sub    $0x1,%eax
    b3d6:	4c 8d 25 43 4d 01 00 	lea    0x14d43(%rip),%r12        # 20120 <fwp_stack_pool>
    b3dd:	48 63 d8             	movslq %eax,%rbx
    b3e0:	89 c0                	mov    %eax,%eax
    b3e2:	48 89 da             	mov    %rbx,%rdx
    b3e5:	48 29 c2             	sub    %rax,%rdx
    b3e8:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    b3ec:	0f 1f 40 00          	nopl   0x0(%rax)
    b3f0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    b3f4:	89 1d 12 4d 01 00    	mov    %ebx,0x14d12(%rip)        # 2010c <fwp_stack_pool_n>
    b3fa:	be 00 00 00 10       	mov    $0x10000000,%esi
    b3ff:	48 83 eb 01          	sub    $0x1,%rbx
    b403:	e8 d8 81 ff ff       	call   35e0 <munmap@plt>
    b408:	48 39 dd             	cmp    %rbx,%rbp
    b40b:	75 e3                	jne    b3f0 <fwp_main_thread+0x520>
    b40d:	8b 3d 05 4c 00 00    	mov    0x4c05(%rip),%edi        # 10018 <fwp_epfd>
    b413:	85 ff                	test   %edi,%edi
    b415:	78 05                	js     b41c <fwp_main_thread+0x54c>
    b417:	e8 b4 80 ff ff       	call   34d0 <close@plt>
    b41c:	4c 8b 25 fd 4e 01 00 	mov    0x14efd(%rip),%r12        # 20320 <fwp_nfdws>
    b423:	48 8b 2d fe 4e 01 00 	mov    0x14efe(%rip),%rbp        # 20328 <fwp_fdws>
    b42a:	31 db                	xor    %ebx,%ebx
    b42c:	c7 05 e2 4b 00 00 ff 	movl   $0xffffffff,0x4be2(%rip)        # 10018 <fwp_epfd>
    b433:	ff ff ff 
    b436:	4d 85 e4             	test   %r12,%r12
    b439:	74 32                	je     b46d <fwp_main_thread+0x59d>
    b43b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    b440:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    b445:	48 85 ff             	test   %rdi,%rdi
    b448:	74 1a                	je     b464 <fwp_main_thread+0x594>
    b44a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    b44e:	0f 85 fc 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b454:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    b459:	0f 85 f1 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b45f:	e8 ec a0 ff ff       	call   5550 <fwp_mem_free>
    b464:	48 83 c3 01          	add    $0x1,%rbx
    b468:	49 39 dc             	cmp    %rbx,%r12
    b46b:	75 d3                	jne    b440 <fwp_main_thread+0x570>
    b46d:	48 89 ef             	mov    %rbp,%rdi
    b470:	e8 db a0 ff ff       	call   5550 <fwp_mem_free>
    b475:	48 8b 15 bc 52 01 00 	mov    0x152bc(%rip),%rdx        # 20738 <fwp_root>
    b47c:	48 c7 05 a1 4e 01 00 	movq   $0x0,0x14ea1(%rip)        # 20328 <fwp_fdws>
    b483:	00 00 00 00 
    b487:	48 c7 05 8e 4e 01 00 	movq   $0x0,0x14e8e(%rip)        # 20320 <fwp_nfdws>
    b48e:	00 00 00 00 
    b492:	48 85 d2             	test   %rdx,%rdx
    b495:	74 4e                	je     b4e5 <fwp_main_thread+0x615>
    b497:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    b49c:	0f 85 ae 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b4a2:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    b4a9:	00 
    b4aa:	0f 85 a0 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b4b0:	48 83 3d 20 6f 01 00 	cmpq   $0x0,0x16f20(%rip)        # 223d8 <fwp_state_len>
    b4b7:	00 
    b4b8:	0f 85 92 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b4be:	48 83 3d 02 6f 01 00 	cmpq   $0x0,0x16f02(%rip)        # 223c8 <fwp_state_owners>
    b4c5:	00 
    b4c6:	0f 85 84 82 ff ff    	jne    3750 <fwp_main_thread.cold>
    b4cc:	b9 79 00 00 00       	mov    $0x79,%ecx
    b4d1:	31 c0                	xor    %eax,%eax
    b4d3:	48 8d 3d 66 4e 01 00 	lea    0x14e66(%rip),%rdi        # 20340 <fwp_root_context>
    b4da:	f3 48 ab             	rep stos %rax,(%rdi)
    b4dd:	48 89 d7             	mov    %rdx,%rdi
    b4e0:	e8 6b a0 ff ff       	call   5550 <fwp_mem_free>
    b4e5:	48 8b 3d 34 4b 00 00 	mov    0x4b34(%rip),%rdi        # 10020 <stdout@GLIBC_2.2.5>
    b4ec:	48 c7 05 49 52 01 00 	movq   $0x0,0x15249(%rip)        # 20740 <fwp_cur>
    b4f3:	00 00 00 00 
    b4f7:	48 c7 05 36 52 01 00 	movq   $0x0,0x15236(%rip)        # 20738 <fwp_root>
    b4fe:	00 00 00 00 
    b502:	e8 b9 80 ff ff       	call   35c0 <fflush@plt>
    b507:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    b50e:	00 
    b50f:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    b516:	00 00 
    b518:	0f 85 1a 08 00 00    	jne    bd38 <fwp_main_thread+0xe68>
    b51e:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    b525:	31 c0                	xor    %eax,%eax
    b527:	5b                   	pop    %rbx
    b528:	5d                   	pop    %rbp
    b529:	41 5c                	pop    %r12
    b52b:	41 5d                	pop    %r13
    b52d:	41 5e                	pop    %r14
    b52f:	41 5f                	pop    %r15
    b531:	c3                   	ret
    b532:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    b538:	48 89 05 d9 51 01 00 	mov    %rax,0x151d9(%rip)        # 20718 <fwp_timers>
    b53f:	e9 ec fb ff ff       	jmp    b130 <fwp_main_thread+0x260>
    b544:	0f 1f 40 00          	nopl   0x0(%rax)
    b548:	e8 e3 95 ff ff       	call   4b30 <fwp_heap_init>
    b54d:	8b 0d b5 65 01 00    	mov    0x165b5(%rip),%ecx        # 21b08 <fwp_heap+0x13a8>
    b553:	85 c9                	test   %ecx,%ecx
    b555:	0f 84 b9 f9 ff ff    	je     af14 <fwp_main_thread+0x44>
    b55b:	48 8d 3d be 94 ff ff 	lea    -0x6b42(%rip),%rdi        # 4a20 <fwp_heap_report>
    b562:	e8 09 0a 00 00       	call   bf70 <atexit>
    b567:	e9 a8 f9 ff ff       	jmp    af14 <fwp_main_thread+0x44>
    b56c:	0f 1f 40 00          	nopl   0x0(%rax)
    b570:	48 8d 05 79 b6 ff ff 	lea    -0x4987(%rip),%rax        # 6bf0 <fwp_drop1>
    b577:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    b57c:	4c 8b 35 6d 15 00 00 	mov    0x156d(%rip),%r14        # caf0 <msg.4+0x70>
    b583:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    b58a:	00 00 
    b58c:	66 48 0f 6e d8       	movq   %rax,%xmm3
    b591:	48 8b 05 60 6e 01 00 	mov    0x16e60(%rip),%rax        # 223f8 <fwp_cleanups>
    b598:	31 ed                	xor    %ebp,%ebp
    b59a:	4c 89 25 57 6e 01 00 	mov    %r12,0x16e57(%rip)        # 223f8 <fwp_cleanups>
    b5a1:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    b5a5:	41 bf ff 7f 00 00    	mov    $0x7fff,%r15d
    b5ab:	48 8d 1d ae 51 01 00 	lea    0x151ae(%rip),%rbx        # 20760 <fwp_heap>
    b5b2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    b5b7:	48 8d 05 12 86 ff ff 	lea    -0x79ee(%rip),%rax        # 3bd0 <fwp_range_release>
    b5be:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    b5c3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    b5c8:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    b5cd:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    b5d2:	e9 06 01 00 00       	jmp    b6dd <fwp_main_thread+0x80d>
    b5d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    b5de:	00 00 
    b5e0:	49 8b 14 24          	mov    (%r12),%rdx
    b5e4:	48 f7 d2             	not    %rdx
    b5e7:	48 89 10             	mov    %rdx,(%rax)
    b5ea:	49 83 fd 18          	cmp    $0x18,%r13
    b5ee:	76 1c                	jbe    b60c <fwp_main_thread+0x73c>
    b5f0:	49 8d 45 e7          	lea    -0x19(%r13),%rax
    b5f4:	49 8d 7c 24 18       	lea    0x18(%r12),%rdi
    b5f9:	31 f6                	xor    %esi,%esi
    b5fb:	48 c1 e8 03          	shr    $0x3,%rax
    b5ff:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    b606:	00 
    b607:	e8 b4 7e ff ff       	call   34c0 <memset@plt>
    b60c:	4c 89 e8             	mov    %r13,%rax
    b60f:	48 03 83 20 14 00 00 	add    0x1420(%rbx),%rax
    b616:	0f 82 0b 07 00 00    	jb     bd27 <fwp_main_thread+0xe57>
    b61c:	48 89 83 20 14 00 00 	mov    %rax,0x1420(%rbx)
    b623:	48 39 83 28 14 00 00 	cmp    %rax,0x1428(%rbx)
    b62a:	73 07                	jae    b633 <fwp_main_thread+0x763>
    b62c:	48 89 83 28 14 00 00 	mov    %rax,0x1428(%rbx)
    b633:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b637:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    b63c:	f2 0f 58 83 38 14 00 	addsd  0x1438(%rbx),%xmm0
    b643:	00 
    b644:	f2 0f 11 83 38 14 00 	movsd  %xmm0,0x1438(%rbx)
    b64b:	00 
    b64c:	49 89 6c 24 10       	mov    %rbp,0x10(%r12)
    b651:	4c 89 e0             	mov    %r12,%rax
    b654:	4c 89 e5             	mov    %r12,%rbp
    b657:	4d 89 34 24          	mov    %r14,(%r12)
    b65b:	4d 89 7c 24 08       	mov    %r15,0x8(%r12)
    b660:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    b667:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    b66e:	48 c1 e2 10          	shl    $0x10,%rdx
    b672:	48 39 d0             	cmp    %rdx,%rax
    b675:	73 57                	jae    b6ce <fwp_main_thread+0x7fe>
    b677:	48 89 c2             	mov    %rax,%rdx
    b67a:	48 c1 ea 10          	shr    $0x10,%rdx
    b67e:	48 8d 34 92          	lea    (%rdx,%rdx,4),%rsi
    b682:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b689:	48 8d 34 f2          	lea    (%rdx,%rsi,8),%rsi
    b68d:	48 8b 56 20          	mov    0x20(%rsi),%rdx
    b691:	48 85 d2             	test   %rdx,%rdx
    b694:	74 38                	je     b6ce <fwp_main_thread+0x7fe>
    b696:	0f b6 3e             	movzbl (%rsi),%edi
    b699:	40 80 ff 02          	cmp    $0x2,%dil
    b69d:	0f 84 ad 00 00 00    	je     b750 <fwp_main_thread+0x880>
    b6a3:	40 80 ff 01          	cmp    $0x1,%dil
    b6a7:	75 25                	jne    b6ce <fwp_main_thread+0x7fe>
    b6a9:	8b 7e 18             	mov    0x18(%rsi),%edi
    b6ac:	0f b7 c0             	movzwl %ax,%eax
    b6af:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b6b2:	48 0f af c7          	imul   %rdi,%rax
    b6b6:	48 c1 e8 20          	shr    $0x20,%rax
    b6ba:	48 39 f0             	cmp    %rsi,%rax
    b6bd:	73 0f                	jae    b6ce <fwp_main_thread+0x7fe>
    b6bf:	48 01 c2             	add    %rax,%rdx
    b6c2:	80 3a ff             	cmpb   $0xff,(%rdx)
    b6c5:	0f 84 25 05 00 00    	je     bbf0 <fwp_main_thread+0xd20>
    b6cb:	c6 02 01             	movb   $0x1,(%rdx)
    b6ce:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b6d3:	49 83 ef 01          	sub    $0x1,%r15
    b6d7:	0f 82 93 00 00 00    	jb     b770 <fwp_main_thread+0x8a0>
    b6dd:	8b 83 a4 13 00 00    	mov    0x13a4(%rbx),%eax
    b6e3:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
    b6e8:	85 c0                	test   %eax,%eax
    b6ea:	74 4c                	je     b738 <fwp_main_thread+0x868>
    b6ec:	0f b6 83 a2 0f 00 00 	movzbl 0xfa2(%rbx),%eax
    b6f3:	44 8b ac 83 00 0f 00 	mov    0xf00(%rbx,%rax,4),%r13d
    b6fa:	00 
    b6fb:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    b6ff:	48 8d 04 c3          	lea    (%rbx,%rax,8),%rax
    b703:	4c 8b 20             	mov    (%rax),%r12
    b706:	4d 85 e4             	test   %r12,%r12
    b709:	0f 85 d1 fe ff ff    	jne    b5e0 <fwp_main_thread+0x710>
    b70f:	4c 8b 60 08          	mov    0x8(%rax),%r12
    b713:	4d 85 e4             	test   %r12,%r12
    b716:	74 20                	je     b738 <fwp_main_thread+0x868>
    b718:	48 8b 50 10          	mov    0x10(%rax),%rdx
    b71c:	4c 29 e2             	sub    %r12,%rdx
    b71f:	4c 39 ea             	cmp    %r13,%rdx
    b722:	72 14                	jb     b738 <fwp_main_thread+0x868>
    b724:	4b 8d 14 2c          	lea    (%r12,%r13,1),%rdx
    b728:	48 89 50 08          	mov    %rdx,0x8(%rax)
    b72c:	e9 b9 fe ff ff       	jmp    b5ea <fwp_main_thread+0x71a>
    b731:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    b738:	31 f6                	xor    %esi,%esi
    b73a:	bf 18 00 00 00       	mov    $0x18,%edi
    b73f:	e8 0c a3 ff ff       	call   5a50 <fwp_heap_alloc>
    b744:	49 89 c4             	mov    %rax,%r12
    b747:	e9 00 ff ff ff       	jmp    b64c <fwp_main_thread+0x77c>
    b74c:	0f 1f 40 00          	nopl   0x0(%rax)
    b750:	66 85 c0             	test   %ax,%ax
    b753:	0f 84 69 ff ff ff    	je     b6c2 <fwp_main_thread+0x7f2>
    b759:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
    b75e:	49 83 ef 01          	sub    $0x1,%r15
    b762:	0f 83 75 ff ff ff    	jae    b6dd <fwp_main_thread+0x80d>
    b768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    b76f:	00 
    b770:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    b775:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    b77a:	bf 01 00 00 00       	mov    $0x1,%edi
    b77f:	66 0f 6f 05 99 13 00 	movdqa 0x1399(%rip),%xmm0        # cb20 <msg.4+0xa0>
    b786:	00 
    b787:	48 89 05 6a 6c 01 00 	mov    %rax,0x16c6a(%rip)        # 223f8 <fwp_cleanups>
    b78e:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    b795:	00 
    b796:	e8 05 b0 ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b79b:	48 8b 15 96 63 01 00 	mov    0x16396(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b7a2:	49 89 c6             	mov    %rax,%r14
    b7a5:	48 2b 05 64 63 01 00 	sub    0x16364(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b7ac:	48 c1 e2 10          	shl    $0x10,%rdx
    b7b0:	48 39 d0             	cmp    %rdx,%rax
    b7b3:	73 59                	jae    b80e <fwp_main_thread+0x93e>
    b7b5:	48 89 c2             	mov    %rax,%rdx
    b7b8:	48 c1 ea 10          	shr    $0x10,%rdx
    b7bc:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b7c0:	48 8b 15 91 63 01 00 	mov    0x16391(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b7c7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b7cb:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b7cf:	4d 85 ed             	test   %r13,%r13
    b7d2:	74 3a                	je     b80e <fwp_main_thread+0x93e>
    b7d4:	0f b6 0a             	movzbl (%rdx),%ecx
    b7d7:	80 f9 02             	cmp    $0x2,%cl
    b7da:	0f 84 00 04 00 00    	je     bbe0 <fwp_main_thread+0xd10>
    b7e0:	80 f9 01             	cmp    $0x1,%cl
    b7e3:	75 29                	jne    b80e <fwp_main_thread+0x93e>
    b7e5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b7e8:	0f b7 c0             	movzwl %ax,%eax
    b7eb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b7ee:	48 0f af c1          	imul   %rcx,%rax
    b7f2:	48 c1 e8 20          	shr    $0x20,%rax
    b7f6:	48 39 d0             	cmp    %rdx,%rax
    b7f9:	73 13                	jae    b80e <fwp_main_thread+0x93e>
    b7fb:	49 01 c5             	add    %rax,%r13
    b7fe:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b803:	0f 84 6e 04 00 00    	je     bc77 <fwp_main_thread+0xda7>
    b809:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b80e:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    b813:	bf 01 00 00 00       	mov    $0x1,%edi
    b818:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
    b81d:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    b824:	00 f0 3f 
    b827:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    b82c:	e8 6f af ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b831:	48 8b 15 00 63 01 00 	mov    0x16300(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b838:	49 89 c6             	mov    %rax,%r14
    b83b:	48 2b 05 ce 62 01 00 	sub    0x162ce(%rip),%rax        # 21b10 <fwp_heap+0x13b0>
    b842:	48 c1 e2 10          	shl    $0x10,%rdx
    b846:	48 39 d0             	cmp    %rdx,%rax
    b849:	73 59                	jae    b8a4 <fwp_main_thread+0x9d4>
    b84b:	48 89 c2             	mov    %rax,%rdx
    b84e:	48 c1 ea 10          	shr    $0x10,%rdx
    b852:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b856:	48 8b 15 fb 62 01 00 	mov    0x162fb(%rip),%rdx        # 21b58 <fwp_heap+0x13f8>
    b85d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b861:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    b865:	4d 85 ed             	test   %r13,%r13
    b868:	74 3a                	je     b8a4 <fwp_main_thread+0x9d4>
    b86a:	0f b6 0a             	movzbl (%rdx),%ecx
    b86d:	80 f9 02             	cmp    $0x2,%cl
    b870:	0f 84 5a 03 00 00    	je     bbd0 <fwp_main_thread+0xd00>
    b876:	80 f9 01             	cmp    $0x1,%cl
    b879:	75 29                	jne    b8a4 <fwp_main_thread+0x9d4>
    b87b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b87e:	0f b7 c0             	movzwl %ax,%eax
    b881:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b884:	48 0f af c1          	imul   %rcx,%rax
    b888:	48 c1 e8 20          	shr    $0x20,%rax
    b88c:	48 39 d0             	cmp    %rdx,%rax
    b88f:	73 13                	jae    b8a4 <fwp_main_thread+0x9d4>
    b891:	49 01 c5             	add    %rax,%r13
    b894:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    b899:	0f 84 e5 03 00 00    	je     bc84 <fwp_main_thread+0xdb4>
    b89f:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    b8a4:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    b8a9:	bf 01 00 00 00       	mov    $0x1,%edi
    b8ae:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
    b8b3:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    b8ba:	33 f3 bf 
    b8bd:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    b8c2:	e8 d9 ae ff ff       	call   67a0 <fwp_data.part.0.constprop.0>
    b8c7:	48 8b 15 6a 62 01 00 	mov    0x1626a(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b8ce:	48 8b 0d 3b 62 01 00 	mov    0x1623b(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b8d5:	49 89 c5             	mov    %rax,%r13
    b8d8:	48 89 d6             	mov    %rdx,%rsi
    b8db:	48 29 c8             	sub    %rcx,%rax
    b8de:	48 c1 e6 10          	shl    $0x10,%rsi
    b8e2:	48 39 f0             	cmp    %rsi,%rax
    b8e5:	73 67                	jae    b94e <fwp_main_thread+0xa7e>
    b8e7:	48 89 c6             	mov    %rax,%rsi
    b8ea:	48 c1 ee 10          	shr    $0x10,%rsi
    b8ee:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    b8f2:	48 8b 35 5f 62 01 00 	mov    0x1625f(%rip),%rsi        # 21b58 <fwp_heap+0x13f8>
    b8f9:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    b8fd:	4c 8b 76 20          	mov    0x20(%rsi),%r14
    b901:	4d 85 f6             	test   %r14,%r14
    b904:	74 48                	je     b94e <fwp_main_thread+0xa7e>
    b906:	0f b6 3e             	movzbl (%rsi),%edi
    b909:	40 80 ff 02          	cmp    $0x2,%dil
    b90d:	0f 84 ad 02 00 00    	je     bbc0 <fwp_main_thread+0xcf0>
    b913:	40 80 ff 01          	cmp    $0x1,%dil
    b917:	75 35                	jne    b94e <fwp_main_thread+0xa7e>
    b919:	8b 7e 18             	mov    0x18(%rsi),%edi
    b91c:	0f b7 c0             	movzwl %ax,%eax
    b91f:	8b 76 1c             	mov    0x1c(%rsi),%esi
    b922:	48 0f af c7          	imul   %rdi,%rax
    b926:	48 c1 e8 20          	shr    $0x20,%rax
    b92a:	48 39 f0             	cmp    %rsi,%rax
    b92d:	73 1f                	jae    b94e <fwp_main_thread+0xa7e>
    b92f:	49 01 c6             	add    %rax,%r14
    b932:	41 80 3e ff          	cmpb   $0xff,(%r14)
    b936:	0f 84 55 03 00 00    	je     bc91 <fwp_main_thread+0xdc1>
    b93c:	41 c6 06 01          	movb   $0x1,(%r14)
    b940:	48 8b 0d c9 61 01 00 	mov    0x161c9(%rip),%rcx        # 21b10 <fwp_heap+0x13b0>
    b947:	48 8b 15 ea 61 01 00 	mov    0x161ea(%rip),%rdx        # 21b38 <fwp_heap+0x13d8>
    b94e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
    b953:	4c 89 e8             	mov    %r13,%rax
    b956:	48 c1 e2 10          	shl    $0x10,%rdx
    b95a:	48 29 c8             	sub    %rcx,%rax
    b95d:	48 39 d0             	cmp    %rdx,%rax
    b960:	73 5d                	jae    b9bf <fwp_main_thread+0xaef>
    b962:	48 89 c2             	mov    %rax,%rdx
    b965:	48 c1 ea 10          	shr    $0x10,%rdx
    b969:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    b96d:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    b974:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    b978:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    b97c:	48 85 ff             	test   %rdi,%rdi
    b97f:	74 3e                	je     b9bf <fwp_main_thread+0xaef>
    b981:	0f b6 0a             	movzbl (%rdx),%ecx
    b984:	80 f9 02             	cmp    $0x2,%cl
    b987:	0f 84 23 02 00 00    	je     bbb0 <fwp_main_thread+0xce0>
    b98d:	80 f9 01             	cmp    $0x1,%cl
    b990:	75 2d                	jne    b9bf <fwp_main_thread+0xaef>
    b992:	8b 4a 18             	mov    0x18(%rdx),%ecx
    b995:	0f b7 c0             	movzwl %ax,%eax
    b998:	8b 52 1c             	mov    0x1c(%rdx),%edx
    b99b:	48 0f af c1          	imul   %rcx,%rax
    b99f:	48 c1 e8 20          	shr    $0x20,%rax
    b9a3:	48 39 d0             	cmp    %rdx,%rax
    b9a6:	73 17                	jae    b9bf <fwp_main_thread+0xaef>
    b9a8:	48 01 c7             	add    %rax,%rdi
    b9ab:	0f b6 07             	movzbl (%rdi),%eax
    b9ae:	84 c0                	test   %al,%al
    b9b0:	74 0d                	je     b9bf <fwp_main_thread+0xaef>
    b9b2:	3c fd                	cmp    $0xfd,%al
    b9b4:	0f 87 e4 02 00 00    	ja     bc9e <fwp_main_thread+0xdce>
    b9ba:	83 c0 01             	add    $0x1,%eax
    b9bd:	88 07                	mov    %al,(%rdi)
    b9bf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    b9c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    b9c8:	b9 01 00 00 00       	mov    $0x1,%ecx
    b9cd:	4c 89 ee             	mov    %r13,%rsi
    b9d0:	48 8d 15 c9 41 00 00 	lea    0x41c9(%rip),%rdx        # fba0 <d0>
    b9d7:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    b9dc:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    b9e3:	00 00 
    b9e5:	e8 a6 e4 ff ff       	call   9e90 <fwp_write>
    b9ea:	4c 8b 74 24 40       	mov    0x40(%rsp),%r14
    b9ef:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
    b9f4:	48 8d 05 33 06 00 00 	lea    0x633(%rip),%rax        # c02e <_IO_stdin_used+0x2e>
    b9fb:	4d 85 f6             	test   %r14,%r14
    b9fe:	4c 0f 44 f0          	cmove  %rax,%r14
    ba02:	49 83 ff f6          	cmp    $0xfffffffffffffff6,%r15
    ba06:	0f 87 31 03 00 00    	ja     bd3d <fwp_main_thread+0xe6d>
    ba0c:	49 8d 7f 09          	lea    0x9(%r15),%rdi
    ba10:	be 01 00 00 00       	mov    $0x1,%esi
    ba15:	e8 36 a0 ff ff       	call   5a50 <fwp_heap_alloc>
    ba1a:	4c 89 fa             	mov    %r15,%rdx
    ba1d:	4c 89 f6             	mov    %r14,%rsi
    ba20:	4c 89 38             	mov    %r15,(%rax)
    ba23:	48 89 c5             	mov    %rax,%rbp
    ba26:	48 8d 40 08          	lea    0x8(%rax),%rax
    ba2a:	48 89 c7             	mov    %rax,%rdi
    ba2d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    ba32:	e8 69 7b ff ff       	call   35a0 <memcpy@plt>
    ba37:	42 c6 44 3d 08 00    	movb   $0x0,0x8(%rbp,%r15,1)
    ba3d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    ba42:	e8 79 79 ff ff       	call   33c0 <free@plt>
    ba47:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    ba4e:	48 89 e8             	mov    %rbp,%rax
    ba51:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    ba58:	48 c1 e2 10          	shl    $0x10,%rdx
    ba5c:	48 39 d0             	cmp    %rdx,%rax
    ba5f:	73 57                	jae    bab8 <fwp_main_thread+0xbe8>
    ba61:	48 89 c2             	mov    %rax,%rdx
    ba64:	48 c1 ea 10          	shr    $0x10,%rdx
    ba68:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    ba6c:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    ba73:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    ba77:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    ba7b:	4d 85 f6             	test   %r14,%r14
    ba7e:	74 38                	je     bab8 <fwp_main_thread+0xbe8>
    ba80:	0f b6 0a             	movzbl (%rdx),%ecx
    ba83:	80 f9 02             	cmp    $0x2,%cl
    ba86:	0f 84 89 01 00 00    	je     bc15 <fwp_main_thread+0xd45>
    ba8c:	80 f9 01             	cmp    $0x1,%cl
    ba8f:	75 27                	jne    bab8 <fwp_main_thread+0xbe8>
    ba91:	8b 4a 18             	mov    0x18(%rdx),%ecx
    ba94:	0f b7 c0             	movzwl %ax,%eax
    ba97:	8b 52 1c             	mov    0x1c(%rdx),%edx
    ba9a:	48 0f af c1          	imul   %rcx,%rax
    ba9e:	48 c1 e8 20          	shr    $0x20,%rax
    baa2:	48 39 d0             	cmp    %rdx,%rax
    baa5:	73 11                	jae    bab8 <fwp_main_thread+0xbe8>
    baa7:	49 01 c6             	add    %rax,%r14
    baaa:	41 80 3e ff          	cmpb   $0xff,(%r14)
    baae:	0f 84 f4 01 00 00    	je     bca8 <fwp_main_thread+0xdd8>
    bab4:	41 c6 06 01          	movb   $0x1,(%r14)
    bab8:	4c 89 ef             	mov    %r13,%rdi
    babb:	e8 a0 af ff ff       	call   6a60 <fwp_drop0>
    bac0:	48 8b 55 00          	mov    0x0(%rbp),%rdx
    bac4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    bac9:	be 01 00 00 00       	mov    $0x1,%esi
    bace:	48 8b 0d eb 68 01 00 	mov    0x168eb(%rip),%rcx        # 223c0 <fwp_prog_out>
    bad5:	e8 a6 7b ff ff       	call   3680 <fwrite@plt>
    bada:	48 8b 35 df 68 01 00 	mov    0x168df(%rip),%rsi        # 223c0 <fwp_prog_out>
    bae1:	bf 0a 00 00 00       	mov    $0xa,%edi
    bae6:	e8 f5 79 ff ff       	call   34e0 <fputc@plt>
    baeb:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    baf2:	48 89 e8             	mov    %rbp,%rax
    baf5:	48 2b 83 b0 13 00 00 	sub    0x13b0(%rbx),%rax
    bafc:	48 c1 e2 10          	shl    $0x10,%rdx
    bb00:	48 39 d0             	cmp    %rdx,%rax
    bb03:	73 6b                	jae    bb70 <fwp_main_thread+0xca0>
    bb05:	48 89 c2             	mov    %rax,%rdx
    bb08:	48 c1 ea 10          	shr    $0x10,%rdx
    bb0c:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    bb10:	48 8b 93 f8 13 00 00 	mov    0x13f8(%rbx),%rdx
    bb17:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    bb1b:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    bb1f:	4d 85 f6             	test   %r14,%r14
    bb22:	74 4c                	je     bb70 <fwp_main_thread+0xca0>
    bb24:	0f b6 0a             	movzbl (%rdx),%ecx
    bb27:	80 f9 02             	cmp    $0x2,%cl
    bb2a:	0f 84 d7 00 00 00    	je     bc07 <fwp_main_thread+0xd37>
    bb30:	80 f9 01             	cmp    $0x1,%cl
    bb33:	75 3b                	jne    bb70 <fwp_main_thread+0xca0>
    bb35:	8b 4a 18             	mov    0x18(%rdx),%ecx
    bb38:	0f b7 c0             	movzwl %ax,%eax
    bb3b:	8b 52 1c             	mov    0x1c(%rdx),%edx
    bb3e:	48 0f af c1          	imul   %rcx,%rax
    bb42:	48 c1 e8 20          	shr    $0x20,%rax
    bb46:	48 39 d0             	cmp    %rdx,%rax
    bb49:	73 25                	jae    bb70 <fwp_main_thread+0xca0>
    bb4b:	49 01 c6             	add    %rax,%r14
    bb4e:	41 0f b6 06          	movzbl (%r14),%eax
    bb52:	84 c0                	test   %al,%al
    bb54:	74 1a                	je     bb70 <fwp_main_thread+0xca0>
    bb56:	3c 01                	cmp    $0x1,%al
    bb58:	0f 84 0c 01 00 00    	je     bc6a <fwp_main_thread+0xd9a>
    bb5e:	3c ff                	cmp    $0xff,%al
    bb60:	0f 84 4f 01 00 00    	je     bcb5 <fwp_main_thread+0xde5>
    bb66:	83 e8 01             	sub    $0x1,%eax
    bb69:	41 88 06             	mov    %al,(%r14)
    bb6c:	0f 1f 40 00          	nopl   0x0(%rax)
    bb70:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    bb75:	48 8b 40 10          	mov    0x10(%rax),%rax
    bb79:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
    bb7e:	48 85 c0             	test   %rax,%rax
    bb81:	0f 84 b9 00 00 00    	je     bc40 <fwp_main_thread+0xd70>
    bb87:	48 8b 8b b0 13 00 00 	mov    0x13b0(%rbx),%rcx
    bb8e:	48 8b 93 d8 13 00 00 	mov    0x13d8(%rbx),%rdx
    bb95:	e9 b9 fd ff ff       	jmp    b953 <fwp_main_thread+0xa83>
    bb9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bba0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    bba4:	e9 fc f4 ff ff       	jmp    b0a5 <fwp_main_thread+0x1d5>
    bba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    bbb0:	66 85 c0             	test   %ax,%ax
    bbb3:	0f 85 06 fe ff ff    	jne    b9bf <fwp_main_thread+0xaef>
    bbb9:	e9 ed fd ff ff       	jmp    b9ab <fwp_main_thread+0xadb>
    bbbe:	66 90                	xchg   %ax,%ax
    bbc0:	66 85 c0             	test   %ax,%ax
    bbc3:	0f 85 85 fd ff ff    	jne    b94e <fwp_main_thread+0xa7e>
    bbc9:	e9 64 fd ff ff       	jmp    b932 <fwp_main_thread+0xa62>
    bbce:	66 90                	xchg   %ax,%ax
    bbd0:	66 85 c0             	test   %ax,%ax
    bbd3:	0f 85 cb fc ff ff    	jne    b8a4 <fwp_main_thread+0x9d4>
    bbd9:	e9 b6 fc ff ff       	jmp    b894 <fwp_main_thread+0x9c4>
    bbde:	66 90                	xchg   %ax,%ax
    bbe0:	66 85 c0             	test   %ax,%ax
    bbe3:	0f 85 25 fc ff ff    	jne    b80e <fwp_main_thread+0x93e>
    bbe9:	e9 10 fc ff ff       	jmp    b7fe <fwp_main_thread+0x92e>
    bbee:	66 90                	xchg   %ax,%ax
    bbf0:	48 89 d7             	mov    %rdx,%rdi
    bbf3:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    bbf8:	e8 13 97 ff ff       	call   5310 <fwp_rc_forget_slot>
    bbfd:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    bc02:	e9 c4 fa ff ff       	jmp    b6cb <fwp_main_thread+0x7fb>
    bc07:	66 85 c0             	test   %ax,%ax
    bc0a:	0f 85 60 ff ff ff    	jne    bb70 <fwp_main_thread+0xca0>
    bc10:	e9 39 ff ff ff       	jmp    bb4e <fwp_main_thread+0xc7e>
    bc15:	66 85 c0             	test   %ax,%ax
    bc18:	0f 85 9a fe ff ff    	jne    bab8 <fwp_main_thread+0xbe8>
    bc1e:	e9 87 fe ff ff       	jmp    baaa <fwp_main_thread+0xbda>
    bc23:	48 83 3d 0d 4b 01 00 	cmpq   $0x0,0x14b0d(%rip)        # 20738 <fwp_root>
    bc2a:	00 
    bc2b:	c7 05 4b 44 01 00 00 	movl   $0x0,0x1444b(%rip)        # 20080 <fwp_exit_code>
    bc32:	00 00 00 
    bc35:	0f 84 6d f7 ff ff    	je     b3a8 <fwp_main_thread+0x4d8>
    bc3b:	e9 10 7b ff ff       	jmp    3750 <fwp_main_thread.cold>
    bc40:	4c 89 ef             	mov    %r13,%rdi
    bc43:	e8 18 ae ff ff       	call   6a60 <fwp_drop0>
    bc48:	4c 89 e7             	mov    %r12,%rdi
    bc4b:	e8 10 ae ff ff       	call   6a60 <fwp_drop0>
    bc50:	48 c7 05 0d 44 00 00 	movq   $0x0,0x440d(%rip)        # 10068 <v.2>
    bc57:	00 00 00 00 
    bc5b:	c7 05 0b 44 00 00 01 	movl   $0x1,0x440b(%rip)        # 10070 <st.3>
    bc62:	00 00 00 
    bc65:	e9 87 f3 ff ff       	jmp    aff1 <fwp_main_thread+0x121>
    bc6a:	48 89 ef             	mov    %rbp,%rdi
    bc6d:	e8 de ac ff ff       	call   6950 <fwp_rc_free_arr>
    bc72:	e9 f9 fe ff ff       	jmp    bb70 <fwp_main_thread+0xca0>
    bc77:	4c 89 ef             	mov    %r13,%rdi
    bc7a:	e8 91 96 ff ff       	call   5310 <fwp_rc_forget_slot>
    bc7f:	e9 85 fb ff ff       	jmp    b809 <fwp_main_thread+0x939>
    bc84:	4c 89 ef             	mov    %r13,%rdi
    bc87:	e8 84 96 ff ff       	call   5310 <fwp_rc_forget_slot>
    bc8c:	e9 0e fc ff ff       	jmp    b89f <fwp_main_thread+0x9cf>
    bc91:	4c 89 f7             	mov    %r14,%rdi
    bc94:	e8 77 96 ff ff       	call   5310 <fwp_rc_forget_slot>
    bc99:	e9 9e fc ff ff       	jmp    b93c <fwp_main_thread+0xa6c>
    bc9e:	e8 4d 95 ff ff       	call   51f0 <fwp_rc_wide_dup>
    bca3:	e9 17 fd ff ff       	jmp    b9bf <fwp_main_thread+0xaef>
    bca8:	4c 89 f7             	mov    %r14,%rdi
    bcab:	e8 60 96 ff ff       	call   5310 <fwp_rc_forget_slot>
    bcb0:	e9 ff fd ff ff       	jmp    bab4 <fwp_main_thread+0xbe4>
    bcb5:	4c 89 f0             	mov    %r14,%rax
    bcb8:	48 c1 e8 11          	shr    $0x11,%rax
    bcbc:	4c 31 f0             	xor    %r14,%rax
    bcbf:	48 89 c2             	mov    %rax,%rdx
    bcc2:	48 c1 ea 09          	shr    $0x9,%rdx
    bcc6:	48 31 d0             	xor    %rdx,%rax
    bcc9:	0f b6 d0             	movzbl %al,%edx
    bccc:	48 8b 84 d3 48 14 00 	mov    0x1448(%rbx,%rdx,8),%rax
    bcd3:	00 
    bcd4:	48 85 c0             	test   %rax,%rax
    bcd7:	75 10                	jne    bce9 <fwp_main_thread+0xe19>
    bcd9:	eb 51                	jmp    bd2c <fwp_main_thread+0xe5c>
    bcdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    bce0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    bce4:	48 85 c0             	test   %rax,%rax
    bce7:	74 43                	je     bd2c <fwp_main_thread+0xe5c>
    bce9:	48 89 c2             	mov    %rax,%rdx
    bcec:	4c 3b 30             	cmp    (%rax),%r14
    bcef:	75 ef                	jne    bce0 <fwp_main_thread+0xe10>
    bcf1:	48 8b 48 08          	mov    0x8(%rax),%rcx
    bcf5:	48 8d 51 ff          	lea    -0x1(%rcx),%rdx
    bcf9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    bcfd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    bd04:	0f 85 66 fe ff ff    	jne    bb70 <fwp_main_thread+0xca0>
    bd0a:	4c 89 f7             	mov    %r14,%rdi
    bd0d:	e8 fe 95 ff ff       	call   5310 <fwp_rc_forget_slot>
    bd12:	41 c6 06 fe          	movb   $0xfe,(%r14)
    bd16:	e9 55 fe ff ff       	jmp    bb70 <fwp_main_thread+0xca0>
    bd1b:	48 8d 3d ce 0b 00 00 	lea    0xbce(%rip),%rdi        # c8f0 <_IO_stdin_used+0x8f0>
    bd22:	e8 79 84 ff ff       	call   41a0 <fwp_trap>
    bd27:	e8 84 7f ff ff       	call   3cb0 <fwp_heap_oom>
    bd2c:	48 8d 3d 65 0a 00 00 	lea    0xa65(%rip),%rdi        # c798 <_IO_stdin_used+0x798>
    bd33:	e8 68 84 ff ff       	call   41a0 <fwp_trap>
    bd38:	e8 23 77 ff ff       	call   3460 <__stack_chk_fail@plt>
    bd3d:	48 8d 3d a4 04 00 00 	lea    0x4a4(%rip),%rdi        # c1e8 <_IO_stdin_used+0x1e8>
    bd44:	e8 57 84 ff ff       	call   41a0 <fwp_trap>
    bd49:	e9 02 7a ff ff       	jmp    3750 <fwp_main_thread.cold>
    bd4e:	e9 fd 79 ff ff       	jmp    3750 <fwp_main_thread.cold>
    bd53:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    bd5a:	00 00 00 
    bd5d:	0f 1f 00             	nopl   (%rax)

000000000000bd60 <__divmodti4>:
    bd60:	f3 0f 1e fa          	endbr64
    bd64:	55                   	push   %rbp
    bd65:	49 89 f1             	mov    %rsi,%r9
    bd68:	49 89 d2             	mov    %rdx,%r10
    bd6b:	48 89 fe             	mov    %rdi,%rsi
    bd6e:	49 89 cb             	mov    %rcx,%r11
    bd71:	48 89 e5             	mov    %rsp,%rbp
    bd74:	41 57                	push   %r15
    bd76:	41 56                	push   %r14
    bd78:	41 55                	push   %r13
    bd7a:	41 54                	push   %r12
    bd7c:	53                   	push   %rbx
    bd7d:	4c 89 c3             	mov    %r8,%rbx
    bd80:	45 31 c0             	xor    %r8d,%r8d
    bd83:	4d 85 c9             	test   %r9,%r9
    bd86:	79 12                	jns    bd9a <__divmodti4+0x3a>
    bd88:	31 ff                	xor    %edi,%edi
    bd8a:	48 f7 de             	neg    %rsi
    bd8d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    bd94:	4c 19 cf             	sbb    %r9,%rdi
    bd97:	49 89 f9             	mov    %rdi,%r9
    bd9a:	4c 89 d8             	mov    %r11,%rax
    bd9d:	4d 85 db             	test   %r11,%r11
    bda0:	0f 88 1a 01 00 00    	js     bec0 <__divmodti4+0x160>
    bda6:	4c 89 d9             	mov    %r11,%rcx
    bda9:	49 89 f3             	mov    %rsi,%r11
    bdac:	75 62                	jne    be10 <__divmodti4+0xb0>
    bdae:	4d 89 c4             	mov    %r8,%r12
    bdb1:	4d 39 d1             	cmp    %r10,%r9
    bdb4:	0f 83 46 01 00 00    	jae    bf00 <__divmodti4+0x1a0>
    bdba:	4c 89 d8             	mov    %r11,%rax
    bdbd:	4c 89 ca             	mov    %r9,%rdx
    bdc0:	49 f7 f2             	div    %r10
    bdc3:	49 89 c3             	mov    %rax,%r11
    bdc6:	31 c0                	xor    %eax,%eax
    bdc8:	48 89 d6             	mov    %rdx,%rsi
    bdcb:	31 ff                	xor    %edi,%edi
    bdcd:	4c 89 d9             	mov    %r11,%rcx
    bdd0:	48 89 c2             	mov    %rax,%rdx
    bdd3:	48 89 c8             	mov    %rcx,%rax
    bdd6:	4d 85 e4             	test   %r12,%r12
    bdd9:	74 0a                	je     bde5 <__divmodti4+0x85>
    bddb:	48 f7 d8             	neg    %rax
    bdde:	48 83 d2 00          	adc    $0x0,%rdx
    bde2:	48 f7 da             	neg    %rdx
    bde5:	4d 85 c0             	test   %r8,%r8
    bde8:	74 0a                	je     bdf4 <__divmodti4+0x94>
    bdea:	48 f7 de             	neg    %rsi
    bded:	48 83 d7 00          	adc    $0x0,%rdi
    bdf1:	48 f7 df             	neg    %rdi
    bdf4:	48 89 33             	mov    %rsi,(%rbx)
    bdf7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    bdfb:	5b                   	pop    %rbx
    bdfc:	41 5c                	pop    %r12
    bdfe:	41 5d                	pop    %r13
    be00:	41 5e                	pop    %r14
    be02:	41 5f                	pop    %r15
    be04:	5d                   	pop    %rbp
    be05:	c3                   	ret
    be06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    be0d:	00 00 00 
    be10:	4d 89 c4             	mov    %r8,%r12
    be13:	49 39 c1             	cmp    %rax,%r9
    be16:	0f 82 ce 00 00 00    	jb     beea <__divmodti4+0x18a>
    be1c:	31 ff                	xor    %edi,%edi
    be1e:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    be23:	48 63 c7             	movslq %edi,%rax
    be26:	be 40 00 00 00       	mov    $0x40,%esi
    be2b:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    be30:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    be35:	48 29 c6             	sub    %rax,%rsi
    be38:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    be3d:	48 09 c8             	or     %rcx,%rax
    be40:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    be45:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    be4a:	49 89 c6             	mov    %rax,%r14
    be4d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    be51:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    be56:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    be5b:	49 09 c1             	or     %rax,%r9
    be5e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    be62:	4c 89 c8             	mov    %r9,%rax
    be65:	49 f7 f6             	div    %r14
    be68:	48 89 d1             	mov    %rdx,%rcx
    be6b:	49 89 c3             	mov    %rax,%r11
    be6e:	49 89 c1             	mov    %rax,%r9
    be71:	49 f7 e2             	mul    %r10
    be74:	49 89 c6             	mov    %rax,%r14
    be77:	49 89 d2             	mov    %rdx,%r10
    be7a:	48 39 d1             	cmp    %rdx,%rcx
    be7d:	72 07                	jb     be86 <__divmodti4+0x126>
    be7f:	75 17                	jne    be98 <__divmodti4+0x138>
    be81:	49 39 c7             	cmp    %rax,%r15
    be84:	73 12                	jae    be98 <__divmodti4+0x138>
    be86:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    be8a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    be8e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    be92:	49 89 d2             	mov    %rdx,%r10
    be95:	49 89 c6             	mov    %rax,%r14
    be98:	4c 89 f8             	mov    %r15,%rax
    be9b:	4c 29 f0             	sub    %r14,%rax
    be9e:	4c 19 d1             	sbb    %r10,%rcx
    bea1:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    bea6:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    beab:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    beb0:	48 09 c6             	or     %rax,%rsi
    beb3:	48 89 cf             	mov    %rcx,%rdi
    beb6:	31 c0                	xor    %eax,%eax
    beb8:	4c 89 c9             	mov    %r9,%rcx
    bebb:	e9 10 ff ff ff       	jmp    bdd0 <__divmodti4+0x70>
    bec0:	4c 89 d0             	mov    %r10,%rax
    bec3:	4c 89 da             	mov    %r11,%rdx
    bec6:	4d 89 c4             	mov    %r8,%r12
    bec9:	49 89 f3             	mov    %rsi,%r11
    becc:	48 f7 d8             	neg    %rax
    becf:	49 f7 d4             	not    %r12
    bed2:	48 83 d2 00          	adc    $0x0,%rdx
    bed6:	49 89 c2             	mov    %rax,%r10
    bed9:	48 f7 da             	neg    %rdx
    bedc:	48 89 d1             	mov    %rdx,%rcx
    bedf:	0f 84 cc fe ff ff    	je     bdb1 <__divmodti4+0x51>
    bee5:	49 39 d1             	cmp    %rdx,%r9
    bee8:	73 46                	jae    bf30 <__divmodti4+0x1d0>
    beea:	4c 89 cf             	mov    %r9,%rdi
    beed:	31 c0                	xor    %eax,%eax
    beef:	31 c9                	xor    %ecx,%ecx
    bef1:	e9 da fe ff ff       	jmp    bdd0 <__divmodti4+0x70>
    bef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    befd:	00 00 00 
    bf00:	4d 85 d2             	test   %r10,%r10
    bf03:	75 0d                	jne    bf12 <__divmodti4+0x1b2>
    bf05:	b8 01 00 00 00       	mov    $0x1,%eax
    bf0a:	31 d2                	xor    %edx,%edx
    bf0c:	49 f7 f2             	div    %r10
    bf0f:	49 89 c2             	mov    %rax,%r10
    bf12:	4c 89 c8             	mov    %r9,%rax
    bf15:	31 d2                	xor    %edx,%edx
    bf17:	49 f7 f2             	div    %r10
    bf1a:	49 89 c1             	mov    %rax,%r9
    bf1d:	4c 89 d8             	mov    %r11,%rax
    bf20:	49 f7 f2             	div    %r10
    bf23:	49 89 c3             	mov    %rax,%r11
    bf26:	4c 89 c8             	mov    %r9,%rax
    bf29:	e9 9a fe ff ff       	jmp    bdc8 <__divmodti4+0x68>
    bf2e:	66 90                	xchg   %ax,%ax
    bf30:	45 31 f6             	xor    %r14d,%r14d
    bf33:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    bf38:	44 89 f7             	mov    %r14d,%edi
    bf3b:	45 85 f6             	test   %r14d,%r14d
    bf3e:	0f 85 df fe ff ff    	jne    be23 <__divmodti4+0xc3>
    bf44:	4c 39 ca             	cmp    %r9,%rdx
    bf47:	72 17                	jb     bf60 <__divmodti4+0x200>
    bf49:	31 c9                	xor    %ecx,%ecx
    bf4b:	48 39 c6             	cmp    %rax,%rsi
    bf4e:	73 10                	jae    bf60 <__divmodti4+0x200>
    bf50:	4c 89 cf             	mov    %r9,%rdi
    bf53:	31 c0                	xor    %eax,%eax
    bf55:	e9 76 fe ff ff       	jmp    bdd0 <__divmodti4+0x70>
    bf5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    bf60:	4c 89 de             	mov    %r11,%rsi
    bf63:	b9 01 00 00 00       	mov    $0x1,%ecx
    bf68:	48 29 c6             	sub    %rax,%rsi
    bf6b:	49 19 d1             	sbb    %rdx,%r9
    bf6e:	eb e0                	jmp    bf50 <__divmodti4+0x1f0>

000000000000bf70 <atexit>:
    bf70:	f3 0f 1e fa          	endbr64
    bf74:	48 8b 15 8d 40 00 00 	mov    0x408d(%rip),%rdx        # 10008 <__dso_handle>
    bf7b:	31 f6                	xor    %esi,%esi
    bf7d:	e9 de 76 ff ff       	jmp    3660 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000bf84 <_fini>:
    bf84:	f3 0f 1e fa          	endbr64
    bf88:	48 83 ec 08          	sub    $0x8,%rsp
    bf8c:	48 83 c4 08          	add    $0x8,%rsp
    bf90:	c3                   	ret
