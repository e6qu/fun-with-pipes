
/home/runner/work/fun-with-pipes/fun-with-pipes/descent-peers-evidence/3-0/fwp-ad-profile:     file format elf64-x86-64


Disassembly of section .init:

0000000000003000 <_init>:
    3000:	f3 0f 1e fa          	endbr64
    3004:	48 83 ec 08          	sub    $0x8,%rsp
    3008:	48 8b 05 d1 bf 00 00 	mov    0xbfd1(%rip),%rax        # efe0 <__gmon_start__>
    300f:	48 85 c0             	test   %rax,%rax
    3012:	74 02                	je     3016 <_init+0x16>
    3014:	ff d0                	call   *%rax
    3016:	48 83 c4 08          	add    $0x8,%rsp
    301a:	c3                   	ret

Disassembly of section .plt:

0000000000003020 <.plt>:
    3020:	ff 35 f2 bd 00 00    	push   0xbdf2(%rip)        # ee18 <_GLOBAL_OFFSET_TABLE_+0x8>
    3026:	ff 25 f4 bd 00 00    	jmp    *0xbdf4(%rip)        # ee20 <_GLOBAL_OFFSET_TABLE_+0x10>
    302c:	0f 1f 40 00          	nopl   0x0(%rax)
    3030:	f3 0f 1e fa          	endbr64
    3034:	68 00 00 00 00       	push   $0x0
    3039:	e9 e2 ff ff ff       	jmp    3020 <_init+0x20>
    303e:	66 90                	xchg   %ax,%ax
    3040:	f3 0f 1e fa          	endbr64
    3044:	68 01 00 00 00       	push   $0x1
    3049:	e9 d2 ff ff ff       	jmp    3020 <_init+0x20>
    304e:	66 90                	xchg   %ax,%ax
    3050:	f3 0f 1e fa          	endbr64
    3054:	68 02 00 00 00       	push   $0x2
    3059:	e9 c2 ff ff ff       	jmp    3020 <_init+0x20>
    305e:	66 90                	xchg   %ax,%ax
    3060:	f3 0f 1e fa          	endbr64
    3064:	68 03 00 00 00       	push   $0x3
    3069:	e9 b2 ff ff ff       	jmp    3020 <_init+0x20>
    306e:	66 90                	xchg   %ax,%ax
    3070:	f3 0f 1e fa          	endbr64
    3074:	68 04 00 00 00       	push   $0x4
    3079:	e9 a2 ff ff ff       	jmp    3020 <_init+0x20>
    307e:	66 90                	xchg   %ax,%ax
    3080:	f3 0f 1e fa          	endbr64
    3084:	68 05 00 00 00       	push   $0x5
    3089:	e9 92 ff ff ff       	jmp    3020 <_init+0x20>
    308e:	66 90                	xchg   %ax,%ax
    3090:	f3 0f 1e fa          	endbr64
    3094:	68 06 00 00 00       	push   $0x6
    3099:	e9 82 ff ff ff       	jmp    3020 <_init+0x20>
    309e:	66 90                	xchg   %ax,%ax
    30a0:	f3 0f 1e fa          	endbr64
    30a4:	68 07 00 00 00       	push   $0x7
    30a9:	e9 72 ff ff ff       	jmp    3020 <_init+0x20>
    30ae:	66 90                	xchg   %ax,%ax
    30b0:	f3 0f 1e fa          	endbr64
    30b4:	68 08 00 00 00       	push   $0x8
    30b9:	e9 62 ff ff ff       	jmp    3020 <_init+0x20>
    30be:	66 90                	xchg   %ax,%ax
    30c0:	f3 0f 1e fa          	endbr64
    30c4:	68 09 00 00 00       	push   $0x9
    30c9:	e9 52 ff ff ff       	jmp    3020 <_init+0x20>
    30ce:	66 90                	xchg   %ax,%ax
    30d0:	f3 0f 1e fa          	endbr64
    30d4:	68 0a 00 00 00       	push   $0xa
    30d9:	e9 42 ff ff ff       	jmp    3020 <_init+0x20>
    30de:	66 90                	xchg   %ax,%ax
    30e0:	f3 0f 1e fa          	endbr64
    30e4:	68 0b 00 00 00       	push   $0xb
    30e9:	e9 32 ff ff ff       	jmp    3020 <_init+0x20>
    30ee:	66 90                	xchg   %ax,%ax
    30f0:	f3 0f 1e fa          	endbr64
    30f4:	68 0c 00 00 00       	push   $0xc
    30f9:	e9 22 ff ff ff       	jmp    3020 <_init+0x20>
    30fe:	66 90                	xchg   %ax,%ax
    3100:	f3 0f 1e fa          	endbr64
    3104:	68 0d 00 00 00       	push   $0xd
    3109:	e9 12 ff ff ff       	jmp    3020 <_init+0x20>
    310e:	66 90                	xchg   %ax,%ax
    3110:	f3 0f 1e fa          	endbr64
    3114:	68 0e 00 00 00       	push   $0xe
    3119:	e9 02 ff ff ff       	jmp    3020 <_init+0x20>
    311e:	66 90                	xchg   %ax,%ax
    3120:	f3 0f 1e fa          	endbr64
    3124:	68 0f 00 00 00       	push   $0xf
    3129:	e9 f2 fe ff ff       	jmp    3020 <_init+0x20>
    312e:	66 90                	xchg   %ax,%ax
    3130:	f3 0f 1e fa          	endbr64
    3134:	68 10 00 00 00       	push   $0x10
    3139:	e9 e2 fe ff ff       	jmp    3020 <_init+0x20>
    313e:	66 90                	xchg   %ax,%ax
    3140:	f3 0f 1e fa          	endbr64
    3144:	68 11 00 00 00       	push   $0x11
    3149:	e9 d2 fe ff ff       	jmp    3020 <_init+0x20>
    314e:	66 90                	xchg   %ax,%ax
    3150:	f3 0f 1e fa          	endbr64
    3154:	68 12 00 00 00       	push   $0x12
    3159:	e9 c2 fe ff ff       	jmp    3020 <_init+0x20>
    315e:	66 90                	xchg   %ax,%ax
    3160:	f3 0f 1e fa          	endbr64
    3164:	68 13 00 00 00       	push   $0x13
    3169:	e9 b2 fe ff ff       	jmp    3020 <_init+0x20>
    316e:	66 90                	xchg   %ax,%ax
    3170:	f3 0f 1e fa          	endbr64
    3174:	68 14 00 00 00       	push   $0x14
    3179:	e9 a2 fe ff ff       	jmp    3020 <_init+0x20>
    317e:	66 90                	xchg   %ax,%ax
    3180:	f3 0f 1e fa          	endbr64
    3184:	68 15 00 00 00       	push   $0x15
    3189:	e9 92 fe ff ff       	jmp    3020 <_init+0x20>
    318e:	66 90                	xchg   %ax,%ax
    3190:	f3 0f 1e fa          	endbr64
    3194:	68 16 00 00 00       	push   $0x16
    3199:	e9 82 fe ff ff       	jmp    3020 <_init+0x20>
    319e:	66 90                	xchg   %ax,%ax
    31a0:	f3 0f 1e fa          	endbr64
    31a4:	68 17 00 00 00       	push   $0x17
    31a9:	e9 72 fe ff ff       	jmp    3020 <_init+0x20>
    31ae:	66 90                	xchg   %ax,%ax
    31b0:	f3 0f 1e fa          	endbr64
    31b4:	68 18 00 00 00       	push   $0x18
    31b9:	e9 62 fe ff ff       	jmp    3020 <_init+0x20>
    31be:	66 90                	xchg   %ax,%ax
    31c0:	f3 0f 1e fa          	endbr64
    31c4:	68 19 00 00 00       	push   $0x19
    31c9:	e9 52 fe ff ff       	jmp    3020 <_init+0x20>
    31ce:	66 90                	xchg   %ax,%ax
    31d0:	f3 0f 1e fa          	endbr64
    31d4:	68 1a 00 00 00       	push   $0x1a
    31d9:	e9 42 fe ff ff       	jmp    3020 <_init+0x20>
    31de:	66 90                	xchg   %ax,%ax
    31e0:	f3 0f 1e fa          	endbr64
    31e4:	68 1b 00 00 00       	push   $0x1b
    31e9:	e9 32 fe ff ff       	jmp    3020 <_init+0x20>
    31ee:	66 90                	xchg   %ax,%ax
    31f0:	f3 0f 1e fa          	endbr64
    31f4:	68 1c 00 00 00       	push   $0x1c
    31f9:	e9 22 fe ff ff       	jmp    3020 <_init+0x20>
    31fe:	66 90                	xchg   %ax,%ax
    3200:	f3 0f 1e fa          	endbr64
    3204:	68 1d 00 00 00       	push   $0x1d
    3209:	e9 12 fe ff ff       	jmp    3020 <_init+0x20>
    320e:	66 90                	xchg   %ax,%ax
    3210:	f3 0f 1e fa          	endbr64
    3214:	68 1e 00 00 00       	push   $0x1e
    3219:	e9 02 fe ff ff       	jmp    3020 <_init+0x20>
    321e:	66 90                	xchg   %ax,%ax
    3220:	f3 0f 1e fa          	endbr64
    3224:	68 1f 00 00 00       	push   $0x1f
    3229:	e9 f2 fd ff ff       	jmp    3020 <_init+0x20>
    322e:	66 90                	xchg   %ax,%ax
    3230:	f3 0f 1e fa          	endbr64
    3234:	68 20 00 00 00       	push   $0x20
    3239:	e9 e2 fd ff ff       	jmp    3020 <_init+0x20>
    323e:	66 90                	xchg   %ax,%ax
    3240:	f3 0f 1e fa          	endbr64
    3244:	68 21 00 00 00       	push   $0x21
    3249:	e9 d2 fd ff ff       	jmp    3020 <_init+0x20>
    324e:	66 90                	xchg   %ax,%ax
    3250:	f3 0f 1e fa          	endbr64
    3254:	68 22 00 00 00       	push   $0x22
    3259:	e9 c2 fd ff ff       	jmp    3020 <_init+0x20>
    325e:	66 90                	xchg   %ax,%ax
    3260:	f3 0f 1e fa          	endbr64
    3264:	68 23 00 00 00       	push   $0x23
    3269:	e9 b2 fd ff ff       	jmp    3020 <_init+0x20>
    326e:	66 90                	xchg   %ax,%ax
    3270:	f3 0f 1e fa          	endbr64
    3274:	68 24 00 00 00       	push   $0x24
    3279:	e9 a2 fd ff ff       	jmp    3020 <_init+0x20>
    327e:	66 90                	xchg   %ax,%ax
    3280:	f3 0f 1e fa          	endbr64
    3284:	68 25 00 00 00       	push   $0x25
    3289:	e9 92 fd ff ff       	jmp    3020 <_init+0x20>
    328e:	66 90                	xchg   %ax,%ax
    3290:	f3 0f 1e fa          	endbr64
    3294:	68 26 00 00 00       	push   $0x26
    3299:	e9 82 fd ff ff       	jmp    3020 <_init+0x20>
    329e:	66 90                	xchg   %ax,%ax
    32a0:	f3 0f 1e fa          	endbr64
    32a4:	68 27 00 00 00       	push   $0x27
    32a9:	e9 72 fd ff ff       	jmp    3020 <_init+0x20>
    32ae:	66 90                	xchg   %ax,%ax
    32b0:	f3 0f 1e fa          	endbr64
    32b4:	68 28 00 00 00       	push   $0x28
    32b9:	e9 62 fd ff ff       	jmp    3020 <_init+0x20>
    32be:	66 90                	xchg   %ax,%ax
    32c0:	f3 0f 1e fa          	endbr64
    32c4:	68 29 00 00 00       	push   $0x29
    32c9:	e9 52 fd ff ff       	jmp    3020 <_init+0x20>
    32ce:	66 90                	xchg   %ax,%ax
    32d0:	f3 0f 1e fa          	endbr64
    32d4:	68 2a 00 00 00       	push   $0x2a
    32d9:	e9 42 fd ff ff       	jmp    3020 <_init+0x20>
    32de:	66 90                	xchg   %ax,%ax
    32e0:	f3 0f 1e fa          	endbr64
    32e4:	68 2b 00 00 00       	push   $0x2b
    32e9:	e9 32 fd ff ff       	jmp    3020 <_init+0x20>
    32ee:	66 90                	xchg   %ax,%ax
    32f0:	f3 0f 1e fa          	endbr64
    32f4:	68 2c 00 00 00       	push   $0x2c
    32f9:	e9 22 fd ff ff       	jmp    3020 <_init+0x20>
    32fe:	66 90                	xchg   %ax,%ax
    3300:	f3 0f 1e fa          	endbr64
    3304:	68 2d 00 00 00       	push   $0x2d
    3309:	e9 12 fd ff ff       	jmp    3020 <_init+0x20>
    330e:	66 90                	xchg   %ax,%ax
    3310:	f3 0f 1e fa          	endbr64
    3314:	68 2e 00 00 00       	push   $0x2e
    3319:	e9 02 fd ff ff       	jmp    3020 <_init+0x20>
    331e:	66 90                	xchg   %ax,%ax
    3320:	f3 0f 1e fa          	endbr64
    3324:	68 2f 00 00 00       	push   $0x2f
    3329:	e9 f2 fc ff ff       	jmp    3020 <_init+0x20>
    332e:	66 90                	xchg   %ax,%ax
    3330:	f3 0f 1e fa          	endbr64
    3334:	68 30 00 00 00       	push   $0x30
    3339:	e9 e2 fc ff ff       	jmp    3020 <_init+0x20>
    333e:	66 90                	xchg   %ax,%ax
    3340:	f3 0f 1e fa          	endbr64
    3344:	68 31 00 00 00       	push   $0x31
    3349:	e9 d2 fc ff ff       	jmp    3020 <_init+0x20>
    334e:	66 90                	xchg   %ax,%ax
    3350:	f3 0f 1e fa          	endbr64
    3354:	68 32 00 00 00       	push   $0x32
    3359:	e9 c2 fc ff ff       	jmp    3020 <_init+0x20>
    335e:	66 90                	xchg   %ax,%ax
    3360:	f3 0f 1e fa          	endbr64
    3364:	68 33 00 00 00       	push   $0x33
    3369:	e9 b2 fc ff ff       	jmp    3020 <_init+0x20>
    336e:	66 90                	xchg   %ax,%ax
    3370:	f3 0f 1e fa          	endbr64
    3374:	68 34 00 00 00       	push   $0x34
    3379:	e9 a2 fc ff ff       	jmp    3020 <_init+0x20>
    337e:	66 90                	xchg   %ax,%ax

Disassembly of section .plt.got:

0000000000003380 <__cxa_finalize@plt>:
    3380:	f3 0f 1e fa          	endbr64
    3384:	ff 25 66 bc 00 00    	jmp    *0xbc66(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    338a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .plt.sec:

0000000000003390 <getenv@plt>:
    3390:	f3 0f 1e fa          	endbr64
    3394:	ff 25 8e ba 00 00    	jmp    *0xba8e(%rip)        # ee28 <getenv@GLIBC_2.2.5>
    339a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033a0 <__snprintf_chk@plt>:
    33a0:	f3 0f 1e fa          	endbr64
    33a4:	ff 25 86 ba 00 00    	jmp    *0xba86(%rip)        # ee30 <__snprintf_chk@GLIBC_2.3.4>
    33aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033b0 <free@plt>:
    33b0:	f3 0f 1e fa          	endbr64
    33b4:	ff 25 7e ba 00 00    	jmp    *0xba7e(%rip)        # ee38 <free@GLIBC_2.2.5>
    33ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033c0 <abort@plt>:
    33c0:	f3 0f 1e fa          	endbr64
    33c4:	ff 25 76 ba 00 00    	jmp    *0xba76(%rip)        # ee40 <abort@GLIBC_2.2.5>
    33ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033d0 <_exit@plt>:
    33d0:	f3 0f 1e fa          	endbr64
    33d4:	ff 25 6e ba 00 00    	jmp    *0xba6e(%rip)        # ee48 <_exit@GLIBC_2.2.5>
    33da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033e0 <strcpy@plt>:
    33e0:	f3 0f 1e fa          	endbr64
    33e4:	ff 25 66 ba 00 00    	jmp    *0xba66(%rip)        # ee50 <strcpy@GLIBC_2.2.5>
    33ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000033f0 <sigaction@plt>:
    33f0:	f3 0f 1e fa          	endbr64
    33f4:	ff 25 5e ba 00 00    	jmp    *0xba5e(%rip)        # ee58 <sigaction@GLIBC_2.2.5>
    33fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003400 <strtod@plt>:
    3400:	f3 0f 1e fa          	endbr64
    3404:	ff 25 56 ba 00 00    	jmp    *0xba56(%rip)        # ee60 <strtod@GLIBC_2.2.5>
    340a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003410 <clock_gettime@plt>:
    3410:	f3 0f 1e fa          	endbr64
    3414:	ff 25 4e ba 00 00    	jmp    *0xba4e(%rip)        # ee68 <clock_gettime@GLIBC_2.17>
    341a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003420 <write@plt>:
    3420:	f3 0f 1e fa          	endbr64
    3424:	ff 25 46 ba 00 00    	jmp    *0xba46(%rip)        # ee70 <write@GLIBC_2.2.5>
    342a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003430 <fclose@plt>:
    3430:	f3 0f 1e fa          	endbr64
    3434:	ff 25 3e ba 00 00    	jmp    *0xba3e(%rip)        # ee78 <fclose@GLIBC_2.2.5>
    343a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003440 <strlen@plt>:
    3440:	f3 0f 1e fa          	endbr64
    3444:	ff 25 36 ba 00 00    	jmp    *0xba36(%rip)        # ee80 <strlen@GLIBC_2.2.5>
    344a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003450 <__stack_chk_fail@plt>:
    3450:	f3 0f 1e fa          	endbr64
    3454:	ff 25 2e ba 00 00    	jmp    *0xba2e(%rip)        # ee88 <__stack_chk_fail@GLIBC_2.4>
    345a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003460 <mmap@plt>:
    3460:	f3 0f 1e fa          	endbr64
    3464:	ff 25 26 ba 00 00    	jmp    *0xba26(%rip)        # ee90 <mmap@GLIBC_2.2.5>
    346a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003470 <strchr@plt>:
    3470:	f3 0f 1e fa          	endbr64
    3474:	ff 25 1e ba 00 00    	jmp    *0xba1e(%rip)        # ee98 <strchr@GLIBC_2.2.5>
    347a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003480 <swapcontext@plt>:
    3480:	f3 0f 1e fa          	endbr64
    3484:	ff 25 16 ba 00 00    	jmp    *0xba16(%rip)        # eea0 <swapcontext@GLIBC_2.2.5>
    348a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003490 <nanosleep@plt>:
    3490:	f3 0f 1e fa          	endbr64
    3494:	ff 25 0e ba 00 00    	jmp    *0xba0e(%rip)        # eea8 <nanosleep@GLIBC_2.2.5>
    349a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034a0 <strtof@plt>:
    34a0:	f3 0f 1e fa          	endbr64
    34a4:	ff 25 06 ba 00 00    	jmp    *0xba06(%rip)        # eeb0 <strtof@GLIBC_2.2.5>
    34aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034b0 <memset@plt>:
    34b0:	f3 0f 1e fa          	endbr64
    34b4:	ff 25 fe b9 00 00    	jmp    *0xb9fe(%rip)        # eeb8 <memset@GLIBC_2.2.5>
    34ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034c0 <close@plt>:
    34c0:	f3 0f 1e fa          	endbr64
    34c4:	ff 25 f6 b9 00 00    	jmp    *0xb9f6(%rip)        # eec0 <close@GLIBC_2.2.5>
    34ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034d0 <fputc@plt>:
    34d0:	f3 0f 1e fa          	endbr64
    34d4:	ff 25 ee b9 00 00    	jmp    *0xb9ee(%rip)        # eec8 <fputc@GLIBC_2.2.5>
    34da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034e0 <pthread_attr_init@plt>:
    34e0:	f3 0f 1e fa          	endbr64
    34e4:	ff 25 e6 b9 00 00    	jmp    *0xb9e6(%rip)        # eed0 <pthread_attr_init@GLIBC_2.2.5>
    34ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000034f0 <fgets@plt>:
    34f0:	f3 0f 1e fa          	endbr64
    34f4:	ff 25 de b9 00 00    	jmp    *0xb9de(%rip)        # eed8 <fgets@GLIBC_2.2.5>
    34fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003500 <strtoull@plt>:
    3500:	f3 0f 1e fa          	endbr64
    3504:	ff 25 d6 b9 00 00    	jmp    *0xb9d6(%rip)        # eee0 <strtoull@GLIBC_2.2.5>
    350a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003510 <calloc@plt>:
    3510:	f3 0f 1e fa          	endbr64
    3514:	ff 25 ce b9 00 00    	jmp    *0xb9ce(%rip)        # eee8 <calloc@GLIBC_2.2.5>
    351a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003520 <strcmp@plt>:
    3520:	f3 0f 1e fa          	endbr64
    3524:	ff 25 c6 b9 00 00    	jmp    *0xb9c6(%rip)        # eef0 <strcmp@GLIBC_2.2.5>
    352a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003530 <signal@plt>:
    3530:	f3 0f 1e fa          	endbr64
    3534:	ff 25 be b9 00 00    	jmp    *0xb9be(%rip)        # eef8 <signal@GLIBC_2.2.5>
    353a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003540 <strtoll@plt>:
    3540:	f3 0f 1e fa          	endbr64
    3544:	ff 25 b6 b9 00 00    	jmp    *0xb9b6(%rip)        # ef00 <strtoll@GLIBC_2.2.5>
    354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003550 <__memcpy_chk@plt>:
    3550:	f3 0f 1e fa          	endbr64
    3554:	ff 25 ae b9 00 00    	jmp    *0xb9ae(%rip)        # ef08 <__memcpy_chk@GLIBC_2.3.4>
    355a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003560 <sigemptyset@plt>:
    3560:	f3 0f 1e fa          	endbr64
    3564:	ff 25 a6 b9 00 00    	jmp    *0xb9a6(%rip)        # ef10 <sigemptyset@GLIBC_2.2.5>
    356a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003570 <strtol@plt>:
    3570:	f3 0f 1e fa          	endbr64
    3574:	ff 25 9e b9 00 00    	jmp    *0xb99e(%rip)        # ef18 <strtol@GLIBC_2.2.5>
    357a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003580 <memcpy@plt>:
    3580:	f3 0f 1e fa          	endbr64
    3584:	ff 25 96 b9 00 00    	jmp    *0xb996(%rip)        # ef20 <memcpy@GLIBC_2.14>
    358a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003590 <malloc@plt>:
    3590:	f3 0f 1e fa          	endbr64
    3594:	ff 25 8e b9 00 00    	jmp    *0xb98e(%rip)        # ef28 <malloc@GLIBC_2.2.5>
    359a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035a0 <fflush@plt>:
    35a0:	f3 0f 1e fa          	endbr64
    35a4:	ff 25 86 b9 00 00    	jmp    *0xb986(%rip)        # ef30 <fflush@GLIBC_2.2.5>
    35aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035b0 <realloc@plt>:
    35b0:	f3 0f 1e fa          	endbr64
    35b4:	ff 25 7e b9 00 00    	jmp    *0xb97e(%rip)        # ef38 <realloc@GLIBC_2.2.5>
    35ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035c0 <munmap@plt>:
    35c0:	f3 0f 1e fa          	endbr64
    35c4:	ff 25 76 b9 00 00    	jmp    *0xb976(%rip)        # ef40 <munmap@GLIBC_2.2.5>
    35ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035d0 <setvbuf@plt>:
    35d0:	f3 0f 1e fa          	endbr64
    35d4:	ff 25 6e b9 00 00    	jmp    *0xb96e(%rip)        # ef48 <setvbuf@GLIBC_2.2.5>
    35da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035e0 <pthread_create@plt>:
    35e0:	f3 0f 1e fa          	endbr64
    35e4:	ff 25 66 b9 00 00    	jmp    *0xb966(%rip)        # ef50 <pthread_create@GLIBC_2.34>
    35ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000035f0 <memmove@plt>:
    35f0:	f3 0f 1e fa          	endbr64
    35f4:	ff 25 5e b9 00 00    	jmp    *0xb95e(%rip)        # ef58 <memmove@GLIBC_2.2.5>
    35fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003600 <mprotect@plt>:
    3600:	f3 0f 1e fa          	endbr64
    3604:	ff 25 56 b9 00 00    	jmp    *0xb956(%rip)        # ef60 <mprotect@GLIBC_2.2.5>
    360a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003610 <fopen@plt>:
    3610:	f3 0f 1e fa          	endbr64
    3614:	ff 25 4e b9 00 00    	jmp    *0xb94e(%rip)        # ef68 <fopen@GLIBC_2.2.5>
    361a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003620 <sysconf@plt>:
    3620:	f3 0f 1e fa          	endbr64
    3624:	ff 25 46 b9 00 00    	jmp    *0xb946(%rip)        # ef70 <sysconf@GLIBC_2.2.5>
    362a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003630 <pthread_attr_destroy@plt>:
    3630:	f3 0f 1e fa          	endbr64
    3634:	ff 25 3e b9 00 00    	jmp    *0xb93e(%rip)        # ef78 <pthread_attr_destroy@GLIBC_2.2.5>
    363a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003640 <__cxa_atexit@plt>:
    3640:	f3 0f 1e fa          	endbr64
    3644:	ff 25 36 b9 00 00    	jmp    *0xb936(%rip)        # ef80 <__cxa_atexit@GLIBC_2.2.5>
    364a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003650 <exit@plt>:
    3650:	f3 0f 1e fa          	endbr64
    3654:	ff 25 2e b9 00 00    	jmp    *0xb92e(%rip)        # ef88 <exit@GLIBC_2.2.5>
    365a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003660 <fwrite@plt>:
    3660:	f3 0f 1e fa          	endbr64
    3664:	ff 25 26 b9 00 00    	jmp    *0xb926(%rip)        # ef90 <fwrite@GLIBC_2.2.5>
    366a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003670 <__fprintf_chk@plt>:
    3670:	f3 0f 1e fa          	endbr64
    3674:	ff 25 1e b9 00 00    	jmp    *0xb91e(%rip)        # ef98 <__fprintf_chk@GLIBC_2.3.4>
    367a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003680 <_Exit@plt>:
    3680:	f3 0f 1e fa          	endbr64
    3684:	ff 25 16 b9 00 00    	jmp    *0xb916(%rip)        # efa0 <_Exit@GLIBC_2.2.5>
    368a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000003690 <pthread_join@plt>:
    3690:	f3 0f 1e fa          	endbr64
    3694:	ff 25 0e b9 00 00    	jmp    *0xb90e(%rip)        # efa8 <pthread_join@GLIBC_2.34>
    369a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036a0 <sigaltstack@plt>:
    36a0:	f3 0f 1e fa          	endbr64
    36a4:	ff 25 06 b9 00 00    	jmp    *0xb906(%rip)        # efb0 <sigaltstack@GLIBC_2.2.5>
    36aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036b0 <strstr@plt>:
    36b0:	f3 0f 1e fa          	endbr64
    36b4:	ff 25 fe b8 00 00    	jmp    *0xb8fe(%rip)        # efb8 <strstr@GLIBC_2.2.5>
    36ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036c0 <__sprintf_chk@plt>:
    36c0:	f3 0f 1e fa          	endbr64
    36c4:	ff 25 f6 b8 00 00    	jmp    *0xb8f6(%rip)        # efc0 <__sprintf_chk@GLIBC_2.3.4>
    36ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000036d0 <pthread_attr_setstacksize@plt>:
    36d0:	f3 0f 1e fa          	endbr64
    36d4:	ff 25 ee b8 00 00    	jmp    *0xb8ee(%rip)        # efc8 <pthread_attr_setstacksize@GLIBC_2.34>
    36da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

Disassembly of section .text:

00000000000036e0 <fwp_trap_overflow.constprop.0>:
    36e0:	53                   	push   %rbx
    36e1:	b9 60 00 00 00       	mov    $0x60,%ecx
    36e6:	ba 02 00 00 00       	mov    $0x2,%edx
    36eb:	be 60 00 00 00       	mov    $0x60,%esi
    36f0:	4c 8d 0d d8 79 00 00 	lea    0x79d8(%rip),%r9        # b0cf <_IO_stdin_used+0xcf>
    36f7:	4c 8d 05 d5 79 00 00 	lea    0x79d5(%rip),%r8        # b0d3 <_IO_stdin_used+0xd3>
    36fe:	48 83 ec 70          	sub    $0x70,%rsp
    3702:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3709:	00 00 
    370b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
    3710:	31 c0                	xor    %eax,%eax
    3712:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3717:	e8 84 fc ff ff       	call   33a0 <__snprintf_chk@plt>
    371c:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
    3721:	e8 0a 0d 00 00       	call   4430 <fwp_trap>

0000000000003726 <fwp_task_dispose.cold>:
    3726:	e8 95 fc ff ff       	call   33c0 <abort@plt>

000000000000372b <fwp_main_thread.cold>:
    372b:	e8 90 fc ff ff       	call   33c0 <abort@plt>

0000000000003730 <main.cold>:
    3730:	e8 8b fc ff ff       	call   33c0 <abort@plt>
    3735:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    373c:	00 00 00 
    373f:	90                   	nop

0000000000003740 <main>:
    3740:	f3 0f 1e fa          	endbr64
    3744:	55                   	push   %rbp
    3745:	53                   	push   %rbx
    3746:	48 83 ec 68          	sub    $0x68,%rsp
    374a:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3751:	00 00 
    3753:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3758:	48 8d 05 c1 9b 00 00 	lea    0x9bc1(%rip),%rax        # d320 <fwp_fn_table>
    375f:	48 89 05 12 5d 06 00 	mov    %rax,0x65d12(%rip)        # 69478 <fwp_fns>
    3766:	48 8b 05 b3 b8 00 00 	mov    0xb8b3(%rip),%rax        # f020 <stdout@GLIBC_2.2.5>
    376d:	48 89 05 0c 5d 06 00 	mov    %rax,0x65d0c(%rip)        # 69480 <fwp_prog_out>
    3774:	e8 27 0e 00 00       	call   45a0 <fwp_now_ns>
    3779:	48 8d 3d 28 7b 00 00 	lea    0x7b28(%rip),%rdi        # b2a8 <_IO_stdin_used+0x2a8>
    3780:	e8 0b fc ff ff       	call   3390 <getenv@plt>
    3785:	48 85 c0             	test   %rax,%rax
    3788:	74 0c                	je     3796 <main+0x56>
    378a:	48 89 c3             	mov    %rax,%rbx
    378d:	80 38 00             	cmpb   $0x0,(%rax)
    3790:	0f 85 09 01 00 00    	jne    389f <main+0x15f>
    3796:	31 ff                	xor    %edi,%edi
    3798:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    379d:	e8 6e fc ff ff       	call   3410 <clock_gettime@plt>
    37a2:	85 c0                	test   %eax,%eax
    37a4:	0f 85 28 01 00 00    	jne    38d2 <main+0x192>
    37aa:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    37af:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    37b4:	48 f7 6c 24 10       	imulq  0x10(%rsp)
    37b9:	48 89 cb             	mov    %rcx,%rbx
    37bc:	48 c1 fb 3f          	sar    $0x3f,%rbx
    37c0:	48 01 c8             	add    %rcx,%rax
    37c3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
    37ca:	00 00 80 
    37cd:	48 11 da             	adc    %rbx,%rdx
    37d0:	31 db                	xor    %ebx,%ebx
    37d2:	48 01 c8             	add    %rcx,%rax
    37d5:	48 11 da             	adc    %rbx,%rdx
    37d8:	48 85 d2             	test   %rdx,%rdx
    37db:	0f 85 38 01 00 00    	jne    3919 <main+0x1d9>
    37e1:	48 8b 3d 38 b8 00 00 	mov    0xb838(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    37e8:	31 d2                	xor    %edx,%edx
    37ea:	31 f6                	xor    %esi,%esi
    37ec:	b9 00 00 01 00       	mov    $0x10000,%ecx
    37f1:	e8 da fd ff ff       	call   35d0 <setvbuf@plt>
    37f6:	bf 0d 00 00 00       	mov    $0xd,%edi
    37fb:	be 01 00 00 00       	mov    $0x1,%esi
    3800:	e8 2b fd ff ff       	call   3530 <signal@plt>
    3805:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    380a:	e8 d1 fc ff ff       	call   34e0 <pthread_attr_init@plt>
    380f:	85 c0                	test   %eax,%eax
    3811:	0f 85 f6 00 00 00    	jne    390d <main+0x1cd>
    3817:	be 00 00 00 40       	mov    $0x40000000,%esi
    381c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    3821:	e8 aa fe ff ff       	call   36d0 <pthread_attr_setstacksize@plt>
    3826:	85 c0                	test   %eax,%eax
    3828:	0f 85 c1 00 00 00    	jne    38ef <main+0x1af>
    382e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
    3833:	31 c9                	xor    %ecx,%ecx
    3835:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
    383a:	48 8d 15 bf 62 00 00 	lea    0x62bf(%rip),%rdx        # 9b00 <fwp_main_thread>
    3841:	e8 9a fd ff ff       	call   35e0 <pthread_create@plt>
    3846:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    384b:	89 c5                	mov    %eax,%ebp
    384d:	e8 de fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    3852:	85 c0                	test   %eax,%eax
    3854:	0f 85 d6 fe ff ff    	jne    3730 <main.cold>
    385a:	85 ed                	test   %ebp,%ebp
    385c:	0f 85 81 00 00 00    	jne    38e3 <main+0x1a3>
    3862:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    3867:	31 f6                	xor    %esi,%esi
    3869:	e8 22 fe ff ff       	call   3690 <pthread_join@plt>
    386e:	85 c0                	test   %eax,%eax
    3870:	0f 85 ba fe ff ff    	jne    3730 <main.cold>
    3876:	48 8b 3d a3 b7 00 00 	mov    0xb7a3(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    387d:	e8 1e fd ff ff       	call   35a0 <fflush@plt>
    3882:	8b 05 f8 b7 01 00    	mov    0x1b7f8(%rip),%eax        # 1f080 <fwp_exit_code>
    3888:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
    388d:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    3894:	00 00 
    3896:	75 46                	jne    38de <main+0x19e>
    3898:	48 83 c4 68          	add    $0x68,%rsp
    389c:	5b                   	pop    %rbx
    389d:	5d                   	pop    %rbp
    389e:	c3                   	ret
    389f:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
    38a4:	ba 0a 00 00 00       	mov    $0xa,%edx
    38a9:	48 89 c7             	mov    %rax,%rdi
    38ac:	e8 4f fc ff ff       	call   3500 <strtoull@plt>
    38b1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    38b6:	80 38 00             	cmpb   $0x0,(%rax)
    38b9:	0f 85 d7 fe ff ff    	jne    3796 <main+0x56>
    38bf:	0f b6 03             	movzbl (%rbx),%eax
    38c2:	83 e8 2b             	sub    $0x2b,%eax
    38c5:	a8 fd                	test   $0xfd,%al
    38c7:	0f 84 c9 fe ff ff    	je     3796 <main+0x56>
    38cd:	e9 0f ff ff ff       	jmp    37e1 <main+0xa1>
    38d2:	48 8d 3d d8 79 00 00 	lea    0x79d8(%rip),%rdi        # b2b1 <_IO_stdin_used+0x2b1>
    38d9:	e8 52 0b 00 00       	call   4430 <fwp_trap>
    38de:	e8 6d fb ff ff       	call   3450 <__stack_chk_fail@plt>
    38e3:	48 8d 3d a6 82 00 00 	lea    0x82a6(%rip),%rdi        # bb90 <_IO_stdin_used+0xb90>
    38ea:	e8 41 0b 00 00       	call   4430 <fwp_trap>
    38ef:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
    38f4:	e8 37 fd ff ff       	call   3630 <pthread_attr_destroy@plt>
    38f9:	85 c0                	test   %eax,%eax
    38fb:	0f 85 2f fe ff ff    	jne    3730 <main.cold>
    3901:	48 8d 3d 60 82 00 00 	lea    0x8260(%rip),%rdi        # bb68 <_IO_stdin_used+0xb68>
    3908:	e8 23 0b 00 00       	call   4430 <fwp_trap>
    390d:	48 8d 3d 24 82 00 00 	lea    0x8224(%rip),%rdi        # bb38 <_IO_stdin_used+0xb38>
    3914:	e8 17 0b 00 00       	call   4430 <fwp_trap>
    3919:	48 8d 3d f0 81 00 00 	lea    0x81f0(%rip),%rdi        # bb10 <_IO_stdin_used+0xb10>
    3920:	e8 0b 0b 00 00       	call   4430 <fwp_trap>
    3925:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    392c:	00 00 00 
    392f:	90                   	nop

0000000000003930 <_start>:
    3930:	f3 0f 1e fa          	endbr64
    3934:	31 ed                	xor    %ebp,%ebp
    3936:	49 89 d1             	mov    %rdx,%r9
    3939:	5e                   	pop    %rsi
    393a:	48 89 e2             	mov    %rsp,%rdx
    393d:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
    3941:	50                   	push   %rax
    3942:	54                   	push   %rsp
    3943:	45 31 c0             	xor    %r8d,%r8d
    3946:	31 c9                	xor    %ecx,%ecx
    3948:	48 8d 3d f1 fd ff ff 	lea    -0x20f(%rip),%rdi        # 3740 <main>
    394f:	ff 15 7b b6 00 00    	call   *0xb67b(%rip)        # efd0 <__libc_start_main@GLIBC_2.34>
    3955:	f4                   	hlt
    3956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    395d:	00 00 00 

0000000000003960 <deregister_tm_clones>:
    3960:	48 8d 3d b1 b6 00 00 	lea    0xb6b1(%rip),%rdi        # f018 <__TMC_END__>
    3967:	48 8d 05 aa b6 00 00 	lea    0xb6aa(%rip),%rax        # f018 <__TMC_END__>
    396e:	48 39 f8             	cmp    %rdi,%rax
    3971:	74 15                	je     3988 <deregister_tm_clones+0x28>
    3973:	48 8b 05 5e b6 00 00 	mov    0xb65e(%rip),%rax        # efd8 <_ITM_deregisterTMCloneTable>
    397a:	48 85 c0             	test   %rax,%rax
    397d:	74 09                	je     3988 <deregister_tm_clones+0x28>
    397f:	ff e0                	jmp    *%rax
    3981:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3988:	c3                   	ret
    3989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003990 <register_tm_clones>:
    3990:	48 8d 3d 81 b6 00 00 	lea    0xb681(%rip),%rdi        # f018 <__TMC_END__>
    3997:	48 8d 35 7a b6 00 00 	lea    0xb67a(%rip),%rsi        # f018 <__TMC_END__>
    399e:	48 29 fe             	sub    %rdi,%rsi
    39a1:	48 89 f0             	mov    %rsi,%rax
    39a4:	48 c1 ee 3f          	shr    $0x3f,%rsi
    39a8:	48 c1 f8 03          	sar    $0x3,%rax
    39ac:	48 01 c6             	add    %rax,%rsi
    39af:	48 d1 fe             	sar    $1,%rsi
    39b2:	74 14                	je     39c8 <register_tm_clones+0x38>
    39b4:	48 8b 05 2d b6 00 00 	mov    0xb62d(%rip),%rax        # efe8 <_ITM_registerTMCloneTable>
    39bb:	48 85 c0             	test   %rax,%rax
    39be:	74 08                	je     39c8 <register_tm_clones+0x38>
    39c0:	ff e0                	jmp    *%rax
    39c2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    39c8:	c3                   	ret
    39c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

00000000000039d0 <__do_global_dtors_aux>:
    39d0:	f3 0f 1e fa          	endbr64
    39d4:	80 3d 6d b6 00 00 00 	cmpb   $0x0,0xb66d(%rip)        # f048 <completed.0>
    39db:	75 2b                	jne    3a08 <__do_global_dtors_aux+0x38>
    39dd:	55                   	push   %rbp
    39de:	48 83 3d 0a b6 00 00 	cmpq   $0x0,0xb60a(%rip)        # eff0 <__cxa_finalize@GLIBC_2.2.5>
    39e5:	00 
    39e6:	48 89 e5             	mov    %rsp,%rbp
    39e9:	74 0c                	je     39f7 <__do_global_dtors_aux+0x27>
    39eb:	48 8b 3d 16 b6 00 00 	mov    0xb616(%rip),%rdi        # f008 <__dso_handle>
    39f2:	e8 89 f9 ff ff       	call   3380 <__cxa_finalize@plt>
    39f7:	e8 64 ff ff ff       	call   3960 <deregister_tm_clones>
    39fc:	c6 05 45 b6 00 00 01 	movb   $0x1,0xb645(%rip)        # f048 <completed.0>
    3a03:	5d                   	pop    %rbp
    3a04:	c3                   	ret
    3a05:	0f 1f 00             	nopl   (%rax)
    3a08:	c3                   	ret
    3a09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a10 <frame_dummy>:
    3a10:	f3 0f 1e fa          	endbr64
    3a14:	e9 77 ff ff ff       	jmp    3990 <register_tm_clones>
    3a19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000003a20 <fwp_fmt_u128>:
    3a20:	41 57                	push   %r15
    3a22:	41 56                	push   %r14
    3a24:	41 55                	push   %r13
    3a26:	41 54                	push   %r12
    3a28:	55                   	push   %rbp
    3a29:	53                   	push   %rbx
    3a2a:	48 83 ec 68          	sub    $0x68,%rsp
    3a2e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    3a35:	00 00 
    3a37:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
    3a3c:	48 89 f0             	mov    %rsi,%rax
    3a3f:	48 09 d0             	or     %rdx,%rax
    3a42:	75 7c                	jne    3ac0 <fwp_fmt_u128+0xa0>
    3a44:	c6 44 24 10 30       	movb   $0x30,0x10(%rsp)
    3a49:	bd 01 00 00 00       	mov    $0x1,%ebp
    3a4e:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3a53:	8d 55 ff             	lea    -0x1(%rbp),%edx
    3a56:	48 89 f8             	mov    %rdi,%rax
    3a59:	49 01 d4             	add    %rdx,%r12
    3a5c:	48 8d 4c 17 01       	lea    0x1(%rdi,%rdx,1),%rcx
    3a61:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    3a68:	00 00 
    3a6a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a71:	00 00 00 00 
    3a75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3a7c:	00 00 00 00 
    3a80:	41 0f b6 14 24       	movzbl (%r12),%edx
    3a85:	48 83 c0 01          	add    $0x1,%rax
    3a89:	49 83 ec 01          	sub    $0x1,%r12
    3a8d:	88 50 ff             	mov    %dl,-0x1(%rax)
    3a90:	48 39 c8             	cmp    %rcx,%rax
    3a93:	75 eb                	jne    3a80 <fwp_fmt_u128+0x60>
    3a95:	48 63 ed             	movslq %ebp,%rbp
    3a98:	c6 04 2f 00          	movb   $0x0,(%rdi,%rbp,1)
    3a9c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
    3aa1:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    3aa8:	00 00 
    3aaa:	0f 85 ef 00 00 00    	jne    3b9f <fwp_fmt_u128+0x17f>
    3ab0:	48 83 c4 68          	add    $0x68,%rsp
    3ab4:	5b                   	pop    %rbx
    3ab5:	5d                   	pop    %rbp
    3ab6:	41 5c                	pop    %r12
    3ab8:	41 5d                	pop    %r13
    3aba:	41 5e                	pop    %r14
    3abc:	41 5f                	pop    %r15
    3abe:	c3                   	ret
    3abf:	90                   	nop
    3ac0:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
    3ac5:	49 89 f2             	mov    %rsi,%r10
    3ac8:	49 89 d3             	mov    %rdx,%r11
    3acb:	31 ed                	xor    %ebp,%ebp
    3acd:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
    3ad2:	4c 89 e3             	mov    %r12,%rbx
    3ad5:	45 31 f6             	xor    %r14d,%r14d
    3ad8:	49 89 f9             	mov    %rdi,%r9
    3adb:	49 bd cc cc cc cc cc 	movabs $0xcccccccccccccccc,%r13
    3ae2:	cc cc cc 
    3ae5:	41 bf 05 00 00 00    	mov    $0x5,%r15d
    3aeb:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
    3af2:	cc cc cc 
    3af5:	4c 89 2c 24          	mov    %r13,(%rsp)
    3af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3b00:	4c 89 d6             	mov    %r10,%rsi
    3b03:	4c 89 df             	mov    %r11,%rdi
    3b06:	4c 01 de             	add    %r11,%rsi
    3b09:	48 83 d6 00          	adc    $0x0,%rsi
    3b0d:	45 31 ed             	xor    %r13d,%r13d
    3b10:	48 89 f0             	mov    %rsi,%rax
    3b13:	48 f7 e1             	mul    %rcx
    3b16:	48 89 d0             	mov    %rdx,%rax
    3b19:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
    3b1d:	48 c1 e8 02          	shr    $0x2,%rax
    3b21:	48 01 c2             	add    %rax,%rdx
    3b24:	48 8b 04 24          	mov    (%rsp),%rax
    3b28:	48 29 d6             	sub    %rdx,%rsi
    3b2b:	49 89 f4             	mov    %rsi,%r12
    3b2e:	4c 89 d6             	mov    %r10,%rsi
    3b31:	4c 29 e6             	sub    %r12,%rsi
    3b34:	4c 19 ef             	sbb    %r13,%rdi
    3b37:	48 0f af c6          	imul   %rsi,%rax
    3b3b:	49 89 f8             	mov    %rdi,%r8
    3b3e:	4c 0f af c1          	imul   %rcx,%r8
    3b42:	49 01 c0             	add    %rax,%r8
    3b45:	48 89 f0             	mov    %rsi,%rax
    3b48:	48 f7 e1             	mul    %rcx
    3b4b:	48 89 c6             	mov    %rax,%rsi
    3b4e:	83 e0 01             	and    $0x1,%eax
    3b51:	49 01 d0             	add    %rdx,%r8
    3b54:	49 f7 e7             	mul    %r15
    3b57:	4c 89 c7             	mov    %r8,%rdi
    3b5a:	4c 89 d2             	mov    %r10,%rdx
    3b5d:	4c 01 e0             	add    %r12,%rax
    3b60:	48 d1 ef             	shr    $1,%rdi
    3b63:	83 c5 01             	add    $0x1,%ebp
    3b66:	48 83 c3 01          	add    $0x1,%rbx
    3b6a:	83 c0 30             	add    $0x30,%eax
    3b6d:	4c 0f ac c6 01       	shrd   $0x1,%r8,%rsi
    3b72:	88 43 ff             	mov    %al,-0x1(%rbx)
    3b75:	4c 89 d8             	mov    %r11,%rax
    3b78:	49 89 fb             	mov    %rdi,%r11
    3b7b:	bf 09 00 00 00       	mov    $0x9,%edi
    3b80:	48 39 d7             	cmp    %rdx,%rdi
    3b83:	4c 89 f7             	mov    %r14,%rdi
    3b86:	49 89 f2             	mov    %rsi,%r10
    3b89:	48 19 c7             	sbb    %rax,%rdi
    3b8c:	0f 82 6e ff ff ff    	jb     3b00 <fwp_fmt_u128+0xe0>
    3b92:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    3b97:	4c 89 cf             	mov    %r9,%rdi
    3b9a:	e9 b4 fe ff ff       	jmp    3a53 <fwp_fmt_u128+0x33>
    3b9f:	e8 ac f8 ff ff       	call   3450 <__stack_chk_fail@plt>
    3ba4:	90                   	nop
    3ba5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bac:	00 00 00 00 

0000000000003bb0 <fwp_range_release>:
    3bb0:	f3 0f 1e fa          	endbr64
    3bb4:	53                   	push   %rbx
    3bb5:	48 8b 47 10          	mov    0x10(%rdi),%rax
    3bb9:	48 89 fb             	mov    %rdi,%rbx
    3bbc:	48 85 c0             	test   %rax,%rax
    3bbf:	74 06                	je     3bc7 <fwp_range_release+0x17>
    3bc1:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
    3bc5:	ff d0                	call   *%rax
    3bc7:	48 8b 3b             	mov    (%rbx),%rdi
    3bca:	48 8b 43 18          	mov    0x18(%rbx),%rax
    3bce:	5b                   	pop    %rbx
    3bcf:	ff e0                	jmp    *%rax
    3bd1:	0f 1f 40 00          	nopl   0x0(%rax)
    3bd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3bdc:	00 00 00 00 

0000000000003be0 <ad_raw_record>:
    3be0:	89 c8                	mov    %ecx,%eax
    3be2:	4c 8d 05 b7 b5 04 00 	lea    0x4b5b7(%rip),%r8        # 4f1a0 <ad_raw_live>
    3be9:	49 89 f1             	mov    %rsi,%r9
    3bec:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    3bf3:	00 
    3bf4:	48 89 d6             	mov    %rdx,%rsi
    3bf7:	89 4f 10             	mov    %ecx,0x10(%rdi)
    3bfa:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
    3bfe:	48 8d 0d 5b b5 04 00 	lea    0x4b55b(%rip),%rcx        # 4f160 <ad_raw_requests>
    3c05:	48 83 04 c1 01       	addq   $0x1,(%rcx,%rax,8)
    3c0a:	48 8d 0d 2f b5 04 00 	lea    0x4b52f(%rip),%rcx        # 4f140 <ad_raw_bytes>
    3c11:	48 01 34 c1          	add    %rsi,(%rcx,%rax,8)
    3c15:	48 01 f2             	add    %rsi,%rdx
    3c18:	48 8d 0d 61 b5 04 00 	lea    0x4b561(%rip),%rcx        # 4f180 <ad_raw_peak>
    3c1f:	48 2b 57 08          	sub    0x8(%rdi),%rdx
    3c23:	49 89 14 c0          	mov    %rdx,(%r8,%rax,8)
    3c27:	4c 89 0f             	mov    %r9,(%rdi)
    3c2a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    3c2e:	48 39 14 c1          	cmp    %rdx,(%rcx,%rax,8)
    3c32:	73 04                	jae    3c38 <ad_raw_record+0x58>
    3c34:	48 89 14 c1          	mov    %rdx,(%rcx,%rax,8)
    3c38:	66 0f 6f 05 70 b5 04 	movdqa 0x4b570(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    3c3f:	00 
    3c40:	66 0f d4 05 58 b5 04 	paddq  0x4b558(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    3c47:	00 
    3c48:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    3c4c:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    3c51:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    3c55:	66 48 0f 7e c0       	movq   %xmm0,%rax
    3c5a:	48 39 05 bf b4 04 00 	cmp    %rax,0x4b4bf(%rip)        # 4f120 <ad_raw_total_peak>
    3c61:	73 08                	jae    3c6b <ad_raw_record+0x8b>
    3c63:	66 0f d6 05 b5 b4 04 	movq   %xmm0,0x4b4b5(%rip)        # 4f120 <ad_raw_total_peak>
    3c6a:	00 
    3c6b:	c3                   	ret
    3c6c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000003c70 <fwp_tape_unlink_scope>:
    3c70:	48 8b 57 50          	mov    0x50(%rdi),%rdx
    3c74:	48 85 d2             	test   %rdx,%rdx
    3c77:	74 3e                	je     3cb7 <fwp_tape_unlink_scope+0x47>
    3c79:	8b 4f 58             	mov    0x58(%rdi),%ecx
    3c7c:	48 63 47 5c          	movslq 0x5c(%rdi),%rax
    3c80:	85 c9                	test   %ecx,%ecx
    3c82:	78 3c                	js     3cc0 <fwp_tape_unlink_scope+0x50>
    3c84:	48 63 d1             	movslq %ecx,%rdx
    3c87:	48 6b d2 68          	imul   $0x68,%rdx,%rdx
    3c8b:	48 03 15 5e b4 01 00 	add    0x1b45e(%rip),%rdx        # 1f0f0 <fwp_tapes>
    3c92:	89 42 5c             	mov    %eax,0x5c(%rdx)
    3c95:	85 c0                	test   %eax,%eax
    3c97:	78 0e                	js     3ca7 <fwp_tape_unlink_scope+0x37>
    3c99:	48 6b c0 68          	imul   $0x68,%rax,%rax
    3c9d:	48 03 05 4c b4 01 00 	add    0x1b44c(%rip),%rax        # 1f0f0 <fwp_tapes>
    3ca4:	89 48 58             	mov    %ecx,0x58(%rax)
    3ca7:	48 c7 47 50 00 00 00 	movq   $0x0,0x50(%rdi)
    3cae:	00 
    3caf:	48 c7 47 58 ff ff ff 	movq   $0xffffffffffffffff,0x58(%rdi)
    3cb6:	ff 
    3cb7:	c3                   	ret
    3cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    3cbf:	00 
    3cc0:	89 02                	mov    %eax,(%rdx)
    3cc2:	eb d1                	jmp    3c95 <fwp_tape_unlink_scope+0x25>
    3cc4:	90                   	nop
    3cc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3ccc:	00 00 00 00 

0000000000003cd0 <fwp_args173>:
    3cd0:	f3 0f 1e fa          	endbr64
    3cd4:	c3                   	ret
    3cd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3cdc:	00 00 00 00 

0000000000003ce0 <fwp_flush>:
    3ce0:	48 8b 3d 99 57 06 00 	mov    0x65799(%rip),%rdi        # 69480 <fwp_prog_out>
    3ce7:	48 85 ff             	test   %rdi,%rdi
    3cea:	74 1c                	je     3d08 <fwp_flush+0x28>
    3cec:	48 83 ec 08          	sub    $0x8,%rsp
    3cf0:	e8 ab f8 ff ff       	call   35a0 <fflush@plt>
    3cf5:	48 8b 3d 24 b3 00 00 	mov    0xb324(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3cfc:	48 83 c4 08          	add    $0x8,%rsp
    3d00:	e9 9b f8 ff ff       	jmp    35a0 <fflush@plt>
    3d05:	0f 1f 00             	nopl   (%rax)
    3d08:	48 8b 3d 11 b3 00 00 	mov    0xb311(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    3d0f:	e9 8c f8 ff ff       	jmp    35a0 <fflush@plt>
    3d14:	90                   	nop
    3d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3d1c:	00 00 00 00 

0000000000003d20 <fwp_segv>:
    3d20:	f3 0f 1e fa          	endbr64
    3d24:	48 83 ec 28          	sub    $0x28,%rsp
    3d28:	48 8b 05 d1 3a 06 00 	mov    0x63ad1(%rip),%rax        # 67800 <fwp_cur>
    3d2f:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    3d33:	41 89 f8             	mov    %edi,%r8d
    3d36:	48 85 c0             	test   %rax,%rax
    3d39:	74 6d                	je     3da8 <fwp_segv+0x88>
    3d3b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    3d3f:	48 85 d2             	test   %rdx,%rdx
    3d42:	74 64                	je     3da8 <fwp_segv+0x88>
    3d44:	89 7c 24 14          	mov    %edi,0x14(%rsp)
    3d48:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3d4d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    3d52:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
    3d57:	e8 c4 f8 ff ff       	call   3620 <sysconf@plt>
    3d5c:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    3d61:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3d66:	44 8b 44 24 14       	mov    0x14(%rsp),%r8d
    3d6b:	48 01 d0             	add    %rdx,%rax
    3d6e:	48 39 c1             	cmp    %rax,%rcx
    3d71:	b8 00 00 00 00       	mov    $0x0,%eax
    3d76:	40 0f 92 c6          	setb   %sil
    3d7a:	48 81 ea 00 00 10 00 	sub    $0x100000,%rdx
    3d81:	48 0f 42 d0          	cmovb  %rax,%rdx
    3d85:	31 c0                	xor    %eax,%eax
    3d87:	48 39 d1             	cmp    %rdx,%rcx
    3d8a:	0f 93 c0             	setae  %al
    3d8d:	21 f0                	and    %esi,%eax
    3d8f:	85 c0                	test   %eax,%eax
    3d91:	75 4a                	jne    3ddd <fwp_segv+0xbd>
    3d93:	31 f6                	xor    %esi,%esi
    3d95:	44 89 c7             	mov    %r8d,%edi
    3d98:	48 83 c4 28          	add    $0x28,%rsp
    3d9c:	e9 8f f7 ff ff       	jmp    3530 <signal@plt>
    3da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    3da8:	48 8b 05 19 34 06 00 	mov    0x63419(%rip),%rax        # 671c8 <fwp_main_stack_top>
    3daf:	48 85 c0             	test   %rax,%rax
    3db2:	74 df                	je     3d93 <fwp_segv+0x73>
    3db4:	48 2b 05 05 34 06 00 	sub    0x63405(%rip),%rax        # 671c0 <fwp_main_stack_size>
    3dbb:	48 8d 90 00 00 f0 ff 	lea    -0x100000(%rax),%rdx
    3dc2:	48 39 d1             	cmp    %rdx,%rcx
    3dc5:	0f 93 c2             	setae  %dl
    3dc8:	48 05 00 00 10 00    	add    $0x100000,%rax
    3dce:	48 39 c1             	cmp    %rax,%rcx
    3dd1:	0f 92 c0             	setb   %al
    3dd4:	0f b6 c0             	movzbl %al,%eax
    3dd7:	21 d0                	and    %edx,%eax
    3dd9:	85 c0                	test   %eax,%eax
    3ddb:	74 b6                	je     3d93 <fwp_segv+0x73>
    3ddd:	e8 fe fe ff ff       	call   3ce0 <fwp_flush>
    3de2:	bf 02 00 00 00       	mov    $0x2,%edi
    3de7:	ba 1a 00 00 00       	mov    $0x1a,%edx
    3dec:	48 8d 35 7d 7e 00 00 	lea    0x7e7d(%rip),%rsi        # bc70 <msg.4>
    3df3:	e8 28 f6 ff ff       	call   3420 <write@plt>
    3df8:	bf 65 00 00 00       	mov    $0x65,%edi
    3dfd:	e8 ce f5 ff ff       	call   33d0 <_exit@plt>
    3e02:	0f 1f 00             	nopl   (%rax)
    3e05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e0c:	00 00 00 00 

0000000000003e10 <fwp_heap_oom>:
    3e10:	50                   	push   %rax
    3e11:	58                   	pop    %rax
    3e12:	ba 13 00 00 00       	mov    $0x13,%edx
    3e17:	be 01 00 00 00       	mov    $0x1,%esi
    3e1c:	48 8d 3d e5 71 00 00 	lea    0x71e5(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    3e23:	48 83 ec 08          	sub    $0x8,%rsp
    3e27:	48 8b 0d 12 b2 00 00 	mov    0xb212(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    3e2e:	e8 2d f8 ff ff       	call   3660 <fwrite@plt>
    3e33:	31 ff                	xor    %edi,%edi
    3e35:	e8 66 f7 ff ff       	call   35a0 <fflush@plt>
    3e3a:	bf 66 00 00 00       	mov    $0x66,%edi
    3e3f:	e8 3c f8 ff ff       	call   3680 <_Exit@plt>
    3e44:	90                   	nop
    3e45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    3e4c:	00 00 00 00 

0000000000003e50 <fwp_heap_chunks>:
    3e50:	41 54                	push   %r12
    3e52:	55                   	push   %rbp
    3e53:	53                   	push   %rbx
    3e54:	48 83 ff 01          	cmp    $0x1,%rdi
    3e58:	0f 84 62 01 00 00    	je     3fc0 <fwp_heap_chunks+0x170>
    3e5e:	48 8b 05 ab 4d 06 00 	mov    0x64dab(%rip),%rax        # 68c10 <fwp_heap+0x13f0>
    3e65:	4c 8d 05 a4 4d 06 00 	lea    0x64da4(%rip),%r8        # 68c10 <fwp_heap+0x13f0>
    3e6c:	48 8b 1d 85 4d 06 00 	mov    0x64d85(%rip),%rbx        # 68bf8 <fwp_heap+0x13d8>
    3e73:	48 39 d8             	cmp    %rbx,%rax
    3e76:	0f 83 57 01 00 00    	jae    3fd3 <fwp_heap_chunks+0x183>
    3e7c:	48 8b 0d 95 4d 06 00 	mov    0x64d95(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    3e83:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    3e87:	31 f6                	xor    %esi,%esi
    3e89:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
    3e8d:	eb 1e                	jmp    3ead <fwp_heap_chunks+0x5d>
    3e8f:	90                   	nop
    3e90:	48 8d 4e 01          	lea    0x1(%rsi),%rcx
    3e94:	48 39 cf             	cmp    %rcx,%rdi
    3e97:	0f 84 03 01 00 00    	je     3fa0 <fwp_heap_chunks+0x150>
    3e9d:	48 83 c0 01          	add    $0x1,%rax
    3ea1:	48 89 ce             	mov    %rcx,%rsi
    3ea4:	48 83 c2 28          	add    $0x28,%rdx
    3ea8:	48 39 c3             	cmp    %rax,%rbx
    3eab:	74 14                	je     3ec1 <fwp_heap_chunks+0x71>
    3ead:	80 3a 00             	cmpb   $0x0,(%rdx)
    3eb0:	74 de                	je     3e90 <fwp_heap_chunks+0x40>
    3eb2:	48 83 c0 01          	add    $0x1,%rax
    3eb6:	31 f6                	xor    %esi,%esi
    3eb8:	48 83 c2 28          	add    $0x28,%rdx
    3ebc:	48 39 c3             	cmp    %rax,%rbx
    3ebf:	75 ec                	jne    3ead <fwp_heap_chunks+0x5d>
    3ec1:	48 29 f3             	sub    %rsi,%rbx
    3ec4:	48 8d 2c 1f          	lea    (%rdi,%rbx,1),%rbp
    3ec8:	48 8b 3d 31 4d 06 00 	mov    0x64d31(%rip),%rdi        # 68c00 <fwp_heap+0x13e0>
    3ecf:	48 29 35 7a 4d 06 00 	sub    %rsi,0x64d7a(%rip)        # 68c50 <fwp_heap+0x1430>
    3ed6:	48 39 ef             	cmp    %rbp,%rdi
    3ed9:	0f 83 96 00 00 00    	jae    3f75 <fwp_heap_chunks+0x125>
    3edf:	48 8b 05 0a 4d 06 00 	mov    0x64d0a(%rip),%rax        # 68bf0 <fwp_heap+0x13d0>
    3ee6:	48 39 e8             	cmp    %rbp,%rax
    3ee9:	0f 82 eb 00 00 00    	jb     3fda <fwp_heap_chunks+0x18a>
    3eef:	4c 8d 65 40          	lea    0x40(%rbp),%r12
    3ef3:	ba 03 00 00 00       	mov    $0x3,%edx
    3ef8:	49 39 c4             	cmp    %rax,%r12
    3efb:	4c 0f 47 e0          	cmova  %rax,%r12
    3eff:	4c 89 e6             	mov    %r12,%rsi
    3f02:	48 29 fe             	sub    %rdi,%rsi
    3f05:	48 c1 e7 10          	shl    $0x10,%rdi
    3f09:	48 03 3d c0 4c 06 00 	add    0x64cc0(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    3f10:	48 c1 e6 10          	shl    $0x10,%rsi
    3f14:	e8 e7 f6 ff ff       	call   3600 <mprotect@plt>
    3f19:	85 c0                	test   %eax,%eax
    3f1b:	0f 85 b9 00 00 00    	jne    3fda <fwp_heap_chunks+0x18a>
    3f21:	bf 1e 00 00 00       	mov    $0x1e,%edi
    3f26:	e8 f5 f6 ff ff       	call   3620 <sysconf@plt>
    3f2b:	48 8b 35 ce 4c 06 00 	mov    0x64cce(%rip),%rsi        # 68c00 <fwp_heap+0x13e0>
    3f32:	48 89 c1             	mov    %rax,%rcx
    3f35:	48 8b 05 dc 4c 06 00 	mov    0x64cdc(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    3f3c:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    3f40:	48 89 ca             	mov    %rcx,%rdx
    3f43:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
    3f47:	4b 8d 34 a4          	lea    (%r12,%r12,4),%rsi
    3f4b:	48 f7 da             	neg    %rdx
    3f4e:	48 8d 44 f0 ff       	lea    -0x1(%rax,%rsi,8),%rax
    3f53:	48 21 d7             	and    %rdx,%rdi
    3f56:	48 8d 34 08          	lea    (%rax,%rcx,1),%rsi
    3f5a:	48 21 d6             	and    %rdx,%rsi
    3f5d:	ba 03 00 00 00       	mov    $0x3,%edx
    3f62:	48 29 fe             	sub    %rdi,%rsi
    3f65:	e8 96 f6 ff ff       	call   3600 <mprotect@plt>
    3f6a:	85 c0                	test   %eax,%eax
    3f6c:	75 6c                	jne    3fda <fwp_heap_chunks+0x18a>
    3f6e:	4c 89 25 8b 4c 06 00 	mov    %r12,0x64c8b(%rip)        # 68c00 <fwp_heap+0x13e0>
    3f75:	48 89 ef             	mov    %rbp,%rdi
    3f78:	48 89 2d 79 4c 06 00 	mov    %rbp,0x64c79(%rip)        # 68bf8 <fwp_heap+0x13d8>
    3f7f:	48 c1 e7 10          	shl    $0x10,%rdi
    3f83:	48 39 3d 5e 4c 06 00 	cmp    %rdi,0x64c5e(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f8a:	73 07                	jae    3f93 <fwp_heap_chunks+0x143>
    3f8c:	48 89 3d 55 4c 06 00 	mov    %rdi,0x64c55(%rip)        # 68be8 <fwp_heap+0x13c8>
    3f93:	48 89 d8             	mov    %rbx,%rax
    3f96:	5b                   	pop    %rbx
    3f97:	5d                   	pop    %rbp
    3f98:	41 5c                	pop    %r12
    3f9a:	c3                   	ret
    3f9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    3fa0:	48 8d 50 01          	lea    0x1(%rax),%rdx
    3fa4:	48 29 f0             	sub    %rsi,%rax
    3fa7:	48 89 c3             	mov    %rax,%rbx
    3faa:	49 89 10             	mov    %rdx,(%r8)
    3fad:	48 89 d8             	mov    %rbx,%rax
    3fb0:	48 29 3d 99 4c 06 00 	sub    %rdi,0x64c99(%rip)        # 68c50 <fwp_heap+0x1430>
    3fb7:	5b                   	pop    %rbx
    3fb8:	5d                   	pop    %rbp
    3fb9:	41 5c                	pop    %r12
    3fbb:	c3                   	ret
    3fbc:	0f 1f 40 00          	nopl   0x0(%rax)
    3fc0:	48 8b 05 41 4c 06 00 	mov    0x64c41(%rip),%rax        # 68c08 <fwp_heap+0x13e8>
    3fc7:	4c 8d 05 3a 4c 06 00 	lea    0x64c3a(%rip),%r8        # 68c08 <fwp_heap+0x13e8>
    3fce:	e9 99 fe ff ff       	jmp    3e6c <fwp_heap_chunks+0x1c>
    3fd3:	31 f6                	xor    %esi,%esi
    3fd5:	e9 ea fe ff ff       	jmp    3ec4 <fwp_heap_chunks+0x74>
    3fda:	e8 31 fe ff ff       	call   3e10 <fwp_heap_oom>
    3fdf:	90                   	nop

0000000000003fe0 <ad_raw_fail>:
    3fe0:	50                   	push   %rax
    3fe1:	58                   	pop    %rax
    3fe2:	48 8d 15 d7 76 00 00 	lea    0x76d7(%rip),%rdx        # b6c0 <_IO_stdin_used+0x6c0>
    3fe9:	be 02 00 00 00       	mov    $0x2,%esi
    3fee:	31 c0                	xor    %eax,%eax
    3ff0:	48 83 ec 08          	sub    $0x8,%rsp
    3ff4:	48 89 f9             	mov    %rdi,%rcx
    3ff7:	48 8b 3d 42 b0 00 00 	mov    0xb042(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    3ffe:	e8 6d f6 ff ff       	call   3670 <__fprintf_chk@plt>
    4003:	bf e8 00 00 00       	mov    $0xe8,%edi
    4008:	e8 43 f6 ff ff       	call   3650 <exit@plt>
    400d:	0f 1f 00             	nopl   (%rax)

0000000000004010 <buf_grow>:
    4010:	48 83 ec 18          	sub    $0x18,%rsp
    4014:	48 8b 47 08          	mov    0x8(%rdi),%rax
    4018:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    401c:	74 7e                	je     409c <buf_grow+0x8c>
    401e:	48 c7 c2 fe ff ff ff 	mov    $0xfffffffffffffffe,%rdx
    4025:	48 29 c2             	sub    %rax,%rdx
    4028:	48 39 f2             	cmp    %rsi,%rdx
    402b:	72 6f                	jb     409c <buf_grow+0x8c>
    402d:	48 8d 54 30 01       	lea    0x1(%rax,%rsi,1),%rdx
    4032:	48 8b 47 10          	mov    0x10(%rdi),%rax
    4036:	48 89 f9             	mov    %rdi,%rcx
    4039:	48 39 d0             	cmp    %rdx,%rax
    403c:	73 48                	jae    4086 <buf_grow+0x76>
    403e:	48 85 c0             	test   %rax,%rax
    4041:	75 15                	jne    4058 <buf_grow+0x48>
    4043:	48 83 fa 40          	cmp    $0x40,%rdx
    4047:	76 4c                	jbe    4095 <buf_grow+0x85>
    4049:	b8 40 00 00 00       	mov    $0x40,%eax
    404e:	eb 08                	jmp    4058 <buf_grow+0x48>
    4050:	48 01 c0             	add    %rax,%rax
    4053:	48 39 d0             	cmp    %rdx,%rax
    4056:	73 38                	jae    4090 <buf_grow+0x80>
    4058:	48 85 c0             	test   %rax,%rax
    405b:	79 f3                	jns    4050 <buf_grow+0x40>
    405d:	48 8b 39             	mov    (%rcx),%rdi
    4060:	48 89 d6             	mov    %rdx,%rsi
    4063:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    4068:	48 89 14 24          	mov    %rdx,(%rsp)
    406c:	e8 3f f5 ff ff       	call   35b0 <realloc@plt>
    4071:	48 8b 14 24          	mov    (%rsp),%rdx
    4075:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    407a:	48 85 c0             	test   %rax,%rax
    407d:	74 1d                	je     409c <buf_grow+0x8c>
    407f:	48 89 01             	mov    %rax,(%rcx)
    4082:	48 89 51 10          	mov    %rdx,0x10(%rcx)
    4086:	48 83 c4 18          	add    $0x18,%rsp
    408a:	c3                   	ret
    408b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4090:	48 89 c2             	mov    %rax,%rdx
    4093:	eb c8                	jmp    405d <buf_grow+0x4d>
    4095:	ba 40 00 00 00       	mov    $0x40,%edx
    409a:	eb c1                	jmp    405d <buf_grow+0x4d>
    409c:	48 8b 0d 9d af 00 00 	mov    0xaf9d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    40a3:	ba 13 00 00 00       	mov    $0x13,%edx
    40a8:	be 01 00 00 00       	mov    $0x1,%esi
    40ad:	48 8d 3d 54 6f 00 00 	lea    0x6f54(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    40b4:	e8 a7 f5 ff ff       	call   3660 <fwrite@plt>
    40b9:	31 ff                	xor    %edi,%edi
    40bb:	e8 e0 f4 ff ff       	call   35a0 <fflush@plt>
    40c0:	bf 66 00 00 00       	mov    $0x66,%edi
    40c5:	e8 b6 f5 ff ff       	call   3680 <_Exit@plt>
    40ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

00000000000040d0 <buf_put>:
    40d0:	41 54                	push   %r12
    40d2:	49 89 f4             	mov    %rsi,%r12
    40d5:	48 89 d6             	mov    %rdx,%rsi
    40d8:	55                   	push   %rbp
    40d9:	48 89 fd             	mov    %rdi,%rbp
    40dc:	53                   	push   %rbx
    40dd:	48 89 d3             	mov    %rdx,%rbx
    40e0:	e8 2b ff ff ff       	call   4010 <buf_grow>
    40e5:	48 8b 7d 08          	mov    0x8(%rbp),%rdi
    40e9:	48 89 da             	mov    %rbx,%rdx
    40ec:	48 03 7d 00          	add    0x0(%rbp),%rdi
    40f0:	4c 89 e6             	mov    %r12,%rsi
    40f3:	e8 88 f4 ff ff       	call   3580 <memcpy@plt>
    40f8:	48 8b 45 00          	mov    0x0(%rbp),%rax
    40fc:	48 03 5d 08          	add    0x8(%rbp),%rbx
    4100:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    4104:	c6 04 18 00          	movb   $0x0,(%rax,%rbx,1)
    4108:	5b                   	pop    %rbx
    4109:	5d                   	pop    %rbp
    410a:	41 5c                	pop    %r12
    410c:	c3                   	ret
    410d:	0f 1f 00             	nopl   (%rax)

0000000000004110 <fwp_cancel_tree.part.0>:
    4110:	48 3b 3d e9 36 06 00 	cmp    0x636e9(%rip),%rdi        # 67800 <fwp_cur>
    4117:	53                   	push   %rbx
    4118:	c6 47 51 01          	movb   $0x1,0x51(%rdi)
    411c:	74 35                	je     4153 <fwp_cancel_tree.part.0+0x43>
    411e:	80 7f 54 00          	cmpb   $0x0,0x54(%rdi)
    4122:	75 2f                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    4124:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    4128:	75 29                	jne    4153 <fwp_cancel_tree.part.0+0x43>
    412a:	48 8b 05 af 36 06 00 	mov    0x636af(%rip),%rax        # 677e0 <fwp_ready_tail>
    4131:	c6 47 54 01          	movb   $0x1,0x54(%rdi)
    4135:	48 c7 87 00 01 00 00 	movq   $0x0,0x100(%rdi)
    413c:	00 00 00 00 
    4140:	48 85 c0             	test   %rax,%rax
    4143:	74 33                	je     4178 <fwp_cancel_tree.part.0+0x68>
    4145:	48 89 b8 00 01 00 00 	mov    %rdi,0x100(%rax)
    414c:	48 89 3d 8d 36 06 00 	mov    %rdi,0x6368d(%rip)        # 677e0 <fwp_ready_tail>
    4153:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
    4157:	48 85 db             	test   %rbx,%rbx
    415a:	74 17                	je     4173 <fwp_cancel_tree.part.0+0x63>
    415c:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    4160:	75 08                	jne    416a <fwp_cancel_tree.part.0+0x5a>
    4162:	48 89 df             	mov    %rbx,%rdi
    4165:	e8 a6 ff ff ff       	call   4110 <fwp_cancel_tree.part.0>
    416a:	48 8b 5b 30          	mov    0x30(%rbx),%rbx
    416e:	48 85 db             	test   %rbx,%rbx
    4171:	75 e9                	jne    415c <fwp_cancel_tree.part.0+0x4c>
    4173:	5b                   	pop    %rbx
    4174:	c3                   	ret
    4175:	0f 1f 00             	nopl   (%rax)
    4178:	48 89 3d 69 36 06 00 	mov    %rdi,0x63669(%rip)        # 677e8 <fwp_ready_head>
    417f:	eb cb                	jmp    414c <fwp_cancel_tree.part.0+0x3c>
    4181:	0f 1f 40 00          	nopl   0x0(%rax)
    4185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    418c:	00 00 00 00 

0000000000004190 <fwp_finish_float>:
    4190:	53                   	push   %rbx
    4191:	be 2e 00 00 00       	mov    $0x2e,%esi
    4196:	48 89 fb             	mov    %rdi,%rbx
    4199:	e8 d2 f2 ff ff       	call   3470 <strchr@plt>
    419e:	48 85 c0             	test   %rax,%rax
    41a1:	74 05                	je     41a8 <fwp_finish_float+0x18>
    41a3:	5b                   	pop    %rbx
    41a4:	c3                   	ret
    41a5:	0f 1f 00             	nopl   (%rax)
    41a8:	be 65 00 00 00       	mov    $0x65,%esi
    41ad:	48 89 df             	mov    %rbx,%rdi
    41b0:	e8 bb f2 ff ff       	call   3470 <strchr@plt>
    41b5:	48 85 c0             	test   %rax,%rax
    41b8:	75 e9                	jne    41a3 <fwp_finish_float+0x13>
    41ba:	48 8d 35 39 70 00 00 	lea    0x7039(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    41c1:	48 89 df             	mov    %rbx,%rdi
    41c4:	e8 e7 f4 ff ff       	call   36b0 <strstr@plt>
    41c9:	48 85 c0             	test   %rax,%rax
    41cc:	75 d5                	jne    41a3 <fwp_finish_float+0x13>
    41ce:	48 8d 35 47 6e 00 00 	lea    0x6e47(%rip),%rsi        # b01c <_IO_stdin_used+0x1c>
    41d5:	48 89 df             	mov    %rbx,%rdi
    41d8:	e8 d3 f4 ff ff       	call   36b0 <strstr@plt>
    41dd:	48 85 c0             	test   %rax,%rax
    41e0:	75 c1                	jne    41a3 <fwp_finish_float+0x13>
    41e2:	48 89 df             	mov    %rbx,%rdi
    41e5:	e8 56 f2 ff ff       	call   3440 <strlen@plt>
    41ea:	ba 2e 30 00 00       	mov    $0x302e,%edx
    41ef:	66 89 14 03          	mov    %dx,(%rbx,%rax,1)
    41f3:	c6 44 03 02 00       	movb   $0x0,0x2(%rbx,%rax,1)
    41f8:	5b                   	pop    %rbx
    41f9:	c3                   	ret
    41fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000004200 <ad_raw_report>:
    4200:	f3 0f 1e fa          	endbr64
    4204:	41 57                	push   %r15
    4206:	41 56                	push   %r14
    4208:	41 55                	push   %r13
    420a:	41 54                	push   %r12
    420c:	55                   	push   %rbp
    420d:	53                   	push   %rbx
    420e:	48 83 ec 38          	sub    $0x38,%rsp
    4212:	66 0f 6f 05 96 af 04 	movdqa 0x4af96(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    4219:	00 
    421a:	66 0f d4 05 7e af 04 	paddq  0x4af7e(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    4221:	00 
    4222:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    4229:	00 00 
    422b:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    4230:	31 c0                	xor    %eax,%eax
    4232:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4236:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    423b:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    423f:	66 48 0f 7e c5       	movq   %xmm0,%rbp
    4244:	48 85 ed             	test   %rbp,%rbp
    4247:	0f 85 d2 01 00 00    	jne    441f <ad_raw_report+0x21f>
    424d:	4c 8b 05 a4 ae 01 00 	mov    0x1aea4(%rip),%r8        # 1f0f8 <ad_raw_before_shutdown>
    4254:	45 31 c9             	xor    %r9d,%r9d
    4257:	31 c0                	xor    %eax,%eax
    4259:	31 db                	xor    %ebx,%ebx
    425b:	48 8b 0d be ae 04 00 	mov    0x4aebe(%rip),%rcx        # 4f120 <ad_raw_total_peak>
    4262:	48 8b 3d d7 ad 00 00 	mov    0xadd7(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4269:	49 89 e4             	mov    %rsp,%r12
    426c:	48 8d 15 9d 74 00 00 	lea    0x749d(%rip),%rdx        # b710 <_IO_stdin_used+0x710>
    4273:	be 02 00 00 00       	mov    $0x2,%esi
    4278:	4c 8d 3d 01 af 04 00 	lea    0x4af01(%rip),%r15        # 4f180 <ad_raw_peak>
    427f:	4c 8d 35 ba ae 04 00 	lea    0x4aeba(%rip),%r14        # 4f140 <ad_raw_bytes>
    4286:	e8 e5 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    428b:	48 8d 05 99 6d 00 00 	lea    0x6d99(%rip),%rax        # b02b <_IO_stdin_used+0x2b>
    4292:	f3 0f 7e 05 76 a9 00 	movq   0xa976(%rip),%xmm0        # ec10 <d0+0x70>
    4299:	00 
    429a:	4c 8d 2d bf ae 04 00 	lea    0x4aebf(%rip),%r13        # 4f160 <ad_raw_requests>
    42a1:	66 48 0f 6e d0       	movq   %rax,%xmm2
    42a6:	48 8d 05 8f 6d 00 00 	lea    0x6d8f(%rip),%rax        # b03c <_IO_stdin_used+0x3c>
    42ad:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    42b1:	66 48 0f 6e d8       	movq   %rax,%xmm3
    42b6:	0f 29 04 24          	movaps %xmm0,(%rsp)
    42ba:	f3 0f 7e 05 56 a9 00 	movq   0xa956(%rip),%xmm0        # ec18 <d0+0x78>
    42c1:	00 
    42c2:	66 0f 6c c3          	punpcklqdq %xmm3,%xmm0
    42c6:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    42cb:	49 8b 14 df          	mov    (%r15,%rbx,8),%rdx
    42cf:	49 8b 04 de          	mov    (%r14,%rbx,8),%rax
    42d3:	4d 8b 4c dd 00       	mov    0x0(%r13,%rbx,8),%r9
    42d8:	4d 8b 04 dc          	mov    (%r12,%rbx,8),%r8
    42dc:	48 85 db             	test   %rbx,%rbx
    42df:	0f 84 0b 01 00 00    	je     43f0 <ad_raw_report+0x1f0>
    42e5:	52                   	push   %rdx
    42e6:	48 8b 3d 53 ad 00 00 	mov    0xad53(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    42ed:	48 8d 0d 2c 6d 00 00 	lea    0x6d2c(%rip),%rcx        # b020 <_IO_stdin_used+0x20>
    42f4:	48 8d 15 75 74 00 00 	lea    0x7475(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    42fb:	50                   	push   %rax
    42fc:	be 02 00 00 00       	mov    $0x2,%esi
    4301:	31 c0                	xor    %eax,%eax
    4303:	48 83 c3 01          	add    $0x1,%rbx
    4307:	e8 64 f3 ff ff       	call   3670 <__fprintf_chk@plt>
    430c:	5f                   	pop    %rdi
    430d:	41 58                	pop    %r8
    430f:	48 83 fb 04          	cmp    $0x4,%rbx
    4313:	75 b6                	jne    42cb <ad_raw_report+0xcb>
    4315:	48 8b 0d 24 ad 00 00 	mov    0xad24(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    431c:	ba 13 00 00 00       	mov    $0x13,%edx
    4321:	be 01 00 00 00       	mov    $0x1,%esi
    4326:	48 8d 3d 18 6d 00 00 	lea    0x6d18(%rip),%rdi        # b045 <_IO_stdin_used+0x45>
    432d:	e8 2e f3 ff ff       	call   3660 <fwrite@plt>
    4332:	48 83 3d c6 ad 01 00 	cmpq   $0x0,0x1adc6(%rip)        # 1f100 <ad_raw_checkpoint_count>
    4339:	00 
    433a:	74 75                	je     43b1 <ad_raw_report+0x1b1>
    433c:	4c 8b 05 dd ad 01 00 	mov    0x1addd(%rip),%r8        # 1f120 <ad_raw_checkpoints>
    4343:	4c 8b 0d de ad 01 00 	mov    0x1adde(%rip),%r9        # 1f128 <ad_raw_checkpoints+0x8>
    434a:	48 8d 1d cf ad 01 00 	lea    0x1adcf(%rip),%rbx        # 1f120 <ad_raw_checkpoints>
    4351:	48 8d 0d 14 6d 00 00 	lea    0x6d14(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    4358:	48 8b 05 d1 ad 01 00 	mov    0x1add1(%rip),%rax        # 1f130 <ad_raw_checkpoints+0x10>
    435f:	4c 8d 25 ba 6c 00 00 	lea    0x6cba(%rip),%r12        # b020 <_IO_stdin_used+0x20>
    4366:	eb 1b                	jmp    4383 <ad_raw_report+0x183>
    4368:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    436f:	00 
    4370:	4c 8b 43 18          	mov    0x18(%rbx),%r8
    4374:	4c 8b 4b 20          	mov    0x20(%rbx),%r9
    4378:	48 83 c3 18          	add    $0x18,%rbx
    437c:	4c 89 e1             	mov    %r12,%rcx
    437f:	48 8b 43 10          	mov    0x10(%rbx),%rax
    4383:	48 83 ec 08          	sub    $0x8,%rsp
    4387:	be 02 00 00 00       	mov    $0x2,%esi
    438c:	48 83 c5 01          	add    $0x1,%rbp
    4390:	48 8b 3d a9 ac 00 00 	mov    0xaca9(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4397:	50                   	push   %rax
    4398:	48 8d 15 11 74 00 00 	lea    0x7411(%rip),%rdx        # b7b0 <_IO_stdin_used+0x7b0>
    439f:	31 c0                	xor    %eax,%eax
    43a1:	e8 ca f2 ff ff       	call   3670 <__fprintf_chk@plt>
    43a6:	48 3b 2d 53 ad 01 00 	cmp    0x1ad53(%rip),%rbp        # 1f100 <ad_raw_checkpoint_count>
    43ad:	59                   	pop    %rcx
    43ae:	5e                   	pop    %rsi
    43af:	72 bf                	jb     4370 <ad_raw_report+0x170>
    43b1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    43b6:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    43bd:	00 00 
    43bf:	75 6a                	jne    442b <ad_raw_report+0x22b>
    43c1:	48 8b 0d 78 ac 00 00 	mov    0xac78(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    43c8:	48 83 c4 38          	add    $0x38,%rsp
    43cc:	ba 04 00 00 00       	mov    $0x4,%edx
    43d1:	be 01 00 00 00       	mov    $0x1,%esi
    43d6:	5b                   	pop    %rbx
    43d7:	48 8d 3d 7b 6c 00 00 	lea    0x6c7b(%rip),%rdi        # b059 <_IO_stdin_used+0x59>
    43de:	5d                   	pop    %rbp
    43df:	41 5c                	pop    %r12
    43e1:	41 5d                	pop    %r13
    43e3:	41 5e                	pop    %r14
    43e5:	41 5f                	pop    %r15
    43e7:	e9 74 f2 ff ff       	jmp    3660 <fwrite@plt>
    43ec:	0f 1f 40 00          	nopl   0x0(%rax)
    43f0:	52                   	push   %rdx
    43f1:	be 02 00 00 00       	mov    $0x2,%esi
    43f6:	48 8b 3d 43 ac 00 00 	mov    0xac43(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    43fd:	48 8d 15 6c 73 00 00 	lea    0x736c(%rip),%rdx        # b770 <_IO_stdin_used+0x770>
    4404:	50                   	push   %rax
    4405:	48 8d 0d 60 6c 00 00 	lea    0x6c60(%rip),%rcx        # b06c <_IO_stdin_used+0x6c>
    440c:	31 c0                	xor    %eax,%eax
    440e:	bb 01 00 00 00       	mov    $0x1,%ebx
    4413:	e8 58 f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4418:	58                   	pop    %rax
    4419:	5a                   	pop    %rdx
    441a:	e9 ac fe ff ff       	jmp    42cb <ad_raw_report+0xcb>
    441f:	48 8d 3d c2 72 00 00 	lea    0x72c2(%rip),%rdi        # b6e8 <_IO_stdin_used+0x6e8>
    4426:	e8 b5 fb ff ff       	call   3fe0 <ad_raw_fail>
    442b:	e8 20 f0 ff ff       	call   3450 <__stack_chk_fail@plt>

0000000000004430 <fwp_trap>:
    4430:	55                   	push   %rbp
    4431:	48 89 fd             	mov    %rdi,%rbp
    4434:	53                   	push   %rbx
    4435:	48 83 ec 08          	sub    $0x8,%rsp
    4439:	64 48 8b 1c 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rbx
    4440:	ff ff 
    4442:	e8 99 f8 ff ff       	call   3ce0 <fwp_flush>
    4447:	31 c0                	xor    %eax,%eax
    4449:	48 89 e9             	mov    %rbp,%rcx
    444c:	be 02 00 00 00       	mov    $0x2,%esi
    4451:	48 8b 3d e8 ab 00 00 	mov    0xabe8(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4458:	48 8d 15 ff 6b 00 00 	lea    0x6bff(%rip),%rdx        # b05e <_IO_stdin_used+0x5e>
    445f:	e8 0c f2 ff ff       	call   3670 <__fprintf_chk@plt>
    4464:	48 85 db             	test   %rbx,%rbx
    4467:	74 16                	je     447f <fwp_trap+0x4f>
    4469:	48 8b 3d d0 ab 00 00 	mov    0xabd0(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4470:	e8 2b f1 ff ff       	call   35a0 <fflush@plt>
    4475:	bf 65 00 00 00       	mov    $0x65,%edi
    447a:	e8 01 f2 ff ff       	call   3680 <_Exit@plt>
    447f:	bf 65 00 00 00       	mov    $0x65,%edi
    4484:	e8 c7 f1 ff ff       	call   3650 <exit@plt>
    4489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000004490 <fwp_closure_drop_push>:
    4490:	41 56                	push   %r14
    4492:	41 54                	push   %r12
    4494:	49 89 f4             	mov    %rsi,%r12
    4497:	55                   	push   %rbp
    4498:	48 89 fd             	mov    %rdi,%rbp
    449b:	53                   	push   %rbx
    449c:	48 83 ec 18          	sub    $0x18,%rsp
    44a0:	48 8b 5f 08          	mov    0x8(%rdi),%rbx
    44a4:	48 3b 5f 10          	cmp    0x10(%rdi),%rbx
    44a8:	74 26                	je     44d0 <fwp_closure_drop_push+0x40>
    44aa:	4c 8b 07             	mov    (%rdi),%r8
    44ad:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    44b4:	00 
    44b5:	48 83 c3 01          	add    $0x1,%rbx
    44b9:	48 89 5d 08          	mov    %rbx,0x8(%rbp)
    44bd:	4d 89 24 10          	mov    %r12,(%r8,%rdx,1)
    44c1:	48 83 c4 18          	add    $0x18,%rsp
    44c5:	5b                   	pop    %rbx
    44c6:	5d                   	pop    %rbp
    44c7:	41 5c                	pop    %r12
    44c9:	41 5e                	pop    %r14
    44cb:	c3                   	ret
    44cc:	0f 1f 40 00          	nopl   0x0(%rax)
    44d0:	48 89 d8             	mov    %rbx,%rax
    44d3:	48 c1 e8 3c          	shr    $0x3c,%rax
    44d7:	0f 85 a9 00 00 00    	jne    4586 <fwp_closure_drop_push+0xf6>
    44dd:	48 89 d9             	mov    %rbx,%rcx
    44e0:	48 c1 e1 04          	shl    $0x4,%rcx
    44e4:	48 89 cf             	mov    %rcx,%rdi
    44e7:	48 89 0c 24          	mov    %rcx,(%rsp)
    44eb:	e8 a0 f0 ff ff       	call   3590 <malloc@plt>
    44f0:	48 8b 0c 24          	mov    (%rsp),%rcx
    44f4:	48 85 c0             	test   %rax,%rax
    44f7:	74 5f                	je     4558 <fwp_closure_drop_push+0xc8>
    44f9:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    44fd:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    4504:	00 
    4505:	48 89 c7             	mov    %rax,%rdi
    4508:	4c 8d 34 1b          	lea    (%rbx,%rbx,1),%r14
    450c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    4511:	48 89 34 24          	mov    %rsi,(%rsp)
    4515:	e8 36 f0 ff ff       	call   3550 <__memcpy_chk@plt>
    451a:	48 8b 34 24          	mov    (%rsp),%rsi
    451e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    4523:	49 89 c0             	mov    %rax,%r8
    4526:	48 8d 45 18          	lea    0x18(%rbp),%rax
    452a:	48 39 c6             	cmp    %rax,%rsi
    452d:	74 1c                	je     454b <fwp_closure_drop_push+0xbb>
    452f:	48 89 f7             	mov    %rsi,%rdi
    4532:	4c 89 04 24          	mov    %r8,(%rsp)
    4536:	e8 75 ee ff ff       	call   33b0 <free@plt>
    453b:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
    453f:	4c 8b 04 24          	mov    (%rsp),%r8
    4543:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
    454a:	00 
    454b:	4c 89 45 00          	mov    %r8,0x0(%rbp)
    454f:	4c 89 75 10          	mov    %r14,0x10(%rbp)
    4553:	e9 5d ff ff ff       	jmp    44b5 <fwp_closure_drop_push+0x25>
    4558:	48 8b 0d e1 aa 00 00 	mov    0xaae1(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    455f:	ba 13 00 00 00       	mov    $0x13,%edx
    4564:	be 01 00 00 00       	mov    $0x1,%esi
    4569:	48 8d 3d 98 6a 00 00 	lea    0x6a98(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    4570:	e8 eb f0 ff ff       	call   3660 <fwrite@plt>
    4575:	31 ff                	xor    %edi,%edi
    4577:	e8 24 f0 ff ff       	call   35a0 <fflush@plt>
    457c:	bf 66 00 00 00       	mov    $0x66,%edi
    4581:	e8 fa f0 ff ff       	call   3680 <_Exit@plt>
    4586:	48 8d 3d e0 6a 00 00 	lea    0x6ae0(%rip),%rdi        # b06d <_IO_stdin_used+0x6d>
    458d:	e8 9e fe ff ff       	call   4430 <fwp_trap>
    4592:	0f 1f 00             	nopl   (%rax)
    4595:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    459c:	00 00 00 00 

00000000000045a0 <fwp_now_ns>:
    45a0:	53                   	push   %rbx
    45a1:	bf 01 00 00 00       	mov    $0x1,%edi
    45a6:	48 83 ec 20          	sub    $0x20,%rsp
    45aa:	64 48 8b 1c 25 28 00 	mov    %fs:0x28,%rbx
    45b1:	00 00 
    45b3:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
    45b8:	31 db                	xor    %ebx,%ebx
    45ba:	48 89 e6             	mov    %rsp,%rsi
    45bd:	e8 4e ee ff ff       	call   3410 <clock_gettime@plt>
    45c2:	85 c0                	test   %eax,%eax
    45c4:	75 52                	jne    4618 <fwp_now_ns+0x78>
    45c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    45cb:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
    45d0:	48 f7 2c 24          	imulq  (%rsp)
    45d4:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    45db:	48 89 f7             	mov    %rsi,%rdi
    45de:	48 c1 ff 3f          	sar    $0x3f,%rdi
    45e2:	48 01 f0             	add    %rsi,%rax
    45e5:	48 be 00 00 00 00 00 	movabs $0x8000000000000000,%rsi
    45ec:	00 00 80 
    45ef:	48 11 fa             	adc    %rdi,%rdx
    45f2:	31 ff                	xor    %edi,%edi
    45f4:	48 01 c6             	add    %rax,%rsi
    45f7:	48 11 d7             	adc    %rdx,%rdi
    45fa:	48 39 f1             	cmp    %rsi,%rcx
    45fd:	48 19 fb             	sbb    %rdi,%rbx
    4600:	72 27                	jb     4629 <fwp_now_ns+0x89>
    4602:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
    4607:	64 48 2b 14 25 28 00 	sub    %fs:0x28,%rdx
    460e:	00 00 
    4610:	75 12                	jne    4624 <fwp_now_ns+0x84>
    4612:	48 83 c4 20          	add    $0x20,%rsp
    4616:	5b                   	pop    %rbx
    4617:	c3                   	ret
    4618:	48 8d 3d 68 6a 00 00 	lea    0x6a68(%rip),%rdi        # b087 <_IO_stdin_used+0x87>
    461f:	e8 0c fe ff ff       	call   4430 <fwp_trap>
    4624:	e8 27 ee ff ff       	call   3450 <__stack_chk_fail@plt>
    4629:	48 8d 3d c0 71 00 00 	lea    0x71c0(%rip),%rdi        # b7f0 <_IO_stdin_used+0x7f0>
    4630:	e8 fb fd ff ff       	call   4430 <fwp_trap>
    4635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    463c:	00 00 00 00 

0000000000004640 <fwp_closure_drop.part.0>:
    4640:	53                   	push   %rbx
    4641:	48 81 ec 20 02 00 00 	sub    $0x220,%rsp
    4648:	66 0f 6f 05 40 76 00 	movdqa 0x7640(%rip),%xmm0        # bc90 <msg.4+0x20>
    464f:	00 
    4650:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4657:	00 00 
    4659:	48 89 b4 24 18 02 00 	mov    %rsi,0x218(%rsp)
    4660:	00 
    4661:	48 89 fe             	mov    %rdi,%rsi
    4664:	48 8d 5c 24 18       	lea    0x18(%rsp),%rbx
    4669:	48 89 e7             	mov    %rsp,%rdi
    466c:	48 89 1c 24          	mov    %rbx,(%rsp)
    4670:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
    4675:	64 48 89 24 25 f8 ff 	mov    %rsp,%fs:0xfffffffffffffff8
    467c:	ff ff 
    467e:	e8 0d fe ff ff       	call   4490 <fwp_closure_drop_push>
    4683:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    4688:	48 85 c0             	test   %rax,%rax
    468b:	74 39                	je     46c6 <fwp_closure_drop.part.0+0x86>
    468d:	0f 1f 00             	nopl   (%rax)
    4690:	48 8b 14 24          	mov    (%rsp),%rdx
    4694:	48 83 e8 01          	sub    $0x1,%rax
    4698:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    469d:	48 8b 3c c2          	mov    (%rdx,%rax,8),%rdi
    46a1:	8b 07                	mov    (%rdi),%eax
    46a3:	48 c1 e0 05          	shl    $0x5,%rax
    46a7:	48 03 05 ca 4d 06 00 	add    0x64dca(%rip),%rax        # 69478 <fwp_fns>
    46ae:	48 8b 40 18          	mov    0x18(%rax),%rax
    46b2:	48 85 c0             	test   %rax,%rax
    46b5:	74 46                	je     46fd <fwp_closure_drop.part.0+0xbd>
    46b7:	31 f6                	xor    %esi,%esi
    46b9:	ff 50 08             	call   *0x8(%rax)
    46bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    46c1:	48 85 c0             	test   %rax,%rax
    46c4:	75 ca                	jne    4690 <fwp_closure_drop.part.0+0x50>
    46c6:	64 48 c7 04 25 f8 ff 	movq   $0x0,%fs:0xfffffffffffffff8
    46cd:	ff ff 00 00 00 00 
    46d3:	48 8b 3c 24          	mov    (%rsp),%rdi
    46d7:	48 39 df             	cmp    %rbx,%rdi
    46da:	74 05                	je     46e1 <fwp_closure_drop.part.0+0xa1>
    46dc:	e8 cf ec ff ff       	call   33b0 <free@plt>
    46e1:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
    46e8:	00 
    46e9:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    46f0:	00 00 
    46f2:	75 15                	jne    4709 <fwp_closure_drop.part.0+0xc9>
    46f4:	48 81 c4 20 02 00 00 	add    $0x220,%rsp
    46fb:	5b                   	pop    %rbx
    46fc:	c3                   	ret
    46fd:	48 8d 3d 14 71 00 00 	lea    0x7114(%rip),%rdi        # b818 <_IO_stdin_used+0x818>
    4704:	e8 27 fd ff ff       	call   4430 <fwp_trap>
    4709:	e8 42 ed ff ff       	call   3450 <__stack_chk_fail@plt>
    470e:	66 90                	xchg   %ax,%ax

0000000000004710 <fwp_tape_of>:
    4710:	0f b7 d7             	movzwl %di,%edx
    4713:	48 85 d2             	test   %rdx,%rdx
    4716:	74 28                	je     4740 <fwp_tape_of+0x30>
    4718:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
    471c:	48 39 05 c5 a9 01 00 	cmp    %rax,0x1a9c5(%rip)        # 1f0e8 <fwp_ntapes>
    4723:	7e 1b                	jle    4740 <fwp_tape_of+0x30>
    4725:	48 6b c0 68          	imul   $0x68,%rax,%rax
    4729:	48 03 05 c0 a9 01 00 	add    0x1a9c0(%rip),%rax        # 1f0f0 <fwp_tapes>
    4730:	8b 50 04             	mov    0x4(%rax),%edx
    4733:	85 d2                	test   %edx,%edx
    4735:	74 09                	je     4740 <fwp_tape_of+0x30>
    4737:	48 c1 ff 10          	sar    $0x10,%rdi
    473b:	39 38                	cmp    %edi,(%rax)
    473d:	75 01                	jne    4740 <fwp_tape_of+0x30>
    473f:	c3                   	ret
    4740:	48 83 ec 08          	sub    $0x8,%rsp
    4744:	48 8d 3d fd 70 00 00 	lea    0x70fd(%rip),%rdi        # b848 <_IO_stdin_used+0x848>
    474b:	e8 e0 fc ff ff       	call   4430 <fwp_trap>

0000000000004750 <fwp_format_g.constprop.0>:
    4750:	41 57                	push   %r15
    4752:	b9 40 00 00 00       	mov    $0x40,%ecx
    4757:	ba 02 00 00 00       	mov    $0x2,%edx
    475c:	4c 8d 05 40 69 00 00 	lea    0x6940(%rip),%r8        # b0a3 <_IO_stdin_used+0xa3>
    4763:	41 56                	push   %r14
    4765:	b8 01 00 00 00       	mov    $0x1,%eax
    476a:	41 55                	push   %r13
    476c:	41 54                	push   %r12
    476e:	44 8d 66 ff          	lea    -0x1(%rsi),%r12d
    4772:	55                   	push   %rbp
    4773:	45 89 e1             	mov    %r12d,%r9d
    4776:	53                   	push   %rbx
    4777:	48 89 fb             	mov    %rdi,%rbx
    477a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
    4781:	64 4c 8b 3c 25 28 00 	mov    %fs:0x28,%r15
    4788:	00 00 
    478a:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
    4791:	00 
    4792:	41 89 f7             	mov    %esi,%r15d
    4795:	4c 8d 74 24 20       	lea    0x20(%rsp),%r14
    479a:	be 40 00 00 00       	mov    $0x40,%esi
    479f:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    47a4:	4c 89 f7             	mov    %r14,%rdi
    47a7:	e8 f4 eb ff ff       	call   33a0 <__snprintf_chk@plt>
    47ac:	be 65 00 00 00       	mov    $0x65,%esi
    47b1:	4c 89 f7             	mov    %r14,%rdi
    47b4:	e8 b7 ec ff ff       	call   3470 <strchr@plt>
    47b9:	31 f6                	xor    %esi,%esi
    47bb:	ba 0a 00 00 00       	mov    $0xa,%edx
    47c0:	48 8d 78 01          	lea    0x1(%rax),%rdi
    47c4:	48 89 c5             	mov    %rax,%rbp
    47c7:	e8 a4 ed ff ff       	call   3570 <strtol@plt>
    47cc:	f2 0f 10 04 24       	movsd  (%rsp),%xmm0
    47d1:	49 89 c0             	mov    %rax,%r8
    47d4:	83 c0 05             	add    $0x5,%eax
    47d7:	83 f8 15             	cmp    $0x15,%eax
    47da:	0f 87 e0 01 00 00    	ja     49c0 <fwp_format_g.constprop.0+0x270>
    47e0:	45 89 e5             	mov    %r12d,%r13d
    47e3:	45 29 c5             	sub    %r8d,%r13d
    47e6:	45 85 ed             	test   %r13d,%r13d
    47e9:	0f 8e 21 01 00 00    	jle    4910 <fwp_format_g.constprop.0+0x1c0>
    47ef:	41 83 ff 01          	cmp    $0x1,%r15d
    47f3:	0f 84 17 01 00 00    	je     4910 <fwp_format_g.constprop.0+0x1c0>
    47f9:	0f b6 44 24 20       	movzbl 0x20(%rsp),%eax
    47fe:	31 d2                	xor    %edx,%edx
    4800:	4d 63 df             	movslq %r15d,%r11
    4803:	3c 2d                	cmp    $0x2d,%al
    4805:	0f 94 c2             	sete   %dl
    4808:	4c 29 dd             	sub    %r11,%rbp
    480b:	4d 8d 14 16          	lea    (%r14,%rdx,1),%r10
    480f:	4c 8d 75 01          	lea    0x1(%rbp),%r14
    4813:	4d 89 f1             	mov    %r14,%r9
    4816:	4d 29 d1             	sub    %r10,%r9
    4819:	4d 8d 79 ff          	lea    -0x1(%r9),%r15
    481d:	3c 2d                	cmp    $0x2d,%al
    481f:	0f 84 fb 03 00 00    	je     4c20 <fwp_format_g.constprop.0+0x4d0>
    4825:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    482a:	b9 48 00 00 00       	mov    $0x48,%ecx
    482f:	48 89 e8             	mov    %rbp,%rax
    4832:	48 8d 78 01          	lea    0x1(%rax),%rdi
    4836:	49 8d 72 01          	lea    0x1(%r10),%rsi
    483a:	49 83 c1 47          	add    $0x47,%r9
    483e:	45 85 c0             	test   %r8d,%r8d
    4841:	0f 88 f1 02 00 00    	js     4b38 <fwp_format_g.constprop.0+0x3e8>
    4847:	45 0f b6 12          	movzbl (%r10),%r10d
    484b:	4d 63 e0             	movslq %r8d,%r12
    484e:	44 88 10             	mov    %r10b,(%rax)
    4851:	41 83 f8 07          	cmp    $0x7,%r8d
    4855:	0f 87 2d 02 00 00    	ja     4a88 <fwp_format_g.constprop.0+0x338>
    485b:	41 f6 c4 04          	test   $0x4,%r12b
    485f:	0f 85 f2 03 00 00    	jne    4c57 <fwp_format_g.constprop.0+0x507>
    4865:	45 85 e4             	test   %r12d,%r12d
    4868:	74 12                	je     487c <fwp_format_g.constprop.0+0x12c>
    486a:	45 0f b6 06          	movzbl (%r14),%r8d
    486e:	44 88 40 01          	mov    %r8b,0x1(%rax)
    4872:	41 f6 c4 02          	test   $0x2,%r12b
    4876:	0f 85 03 04 00 00    	jne    4c7f <fwp_format_g.constprop.0+0x52f>
    487c:	4c 29 e1             	sub    %r12,%rcx
    487f:	4c 01 e7             	add    %r12,%rdi
    4882:	4c 89 fa             	mov    %r15,%rdx
    4885:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    488a:	48 83 e9 01          	sub    $0x1,%rcx
    488e:	4d 63 ed             	movslq %r13d,%r13
    4891:	48 89 0c 24          	mov    %rcx,(%rsp)
    4895:	e8 b6 ec ff ff       	call   3550 <__memcpy_chk@plt>
    489a:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    489f:	48 8b 0c 24          	mov    (%rsp),%rcx
    48a3:	ba 48 00 00 00       	mov    $0x48,%edx
    48a8:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
    48ac:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
    48b0:	4c 89 c8             	mov    %r9,%rax
    48b3:	48 29 c8             	sub    %rcx,%rax
    48b6:	48 39 d0             	cmp    %rdx,%rax
    48b9:	48 0f 42 c2          	cmovb  %rdx,%rax
    48bd:	4c 29 c9             	sub    %r9,%rcx
    48c0:	4c 89 ea             	mov    %r13,%rdx
    48c3:	48 01 c1             	add    %rax,%rcx
    48c6:	e8 85 ec ff ff       	call   3550 <__memcpy_chk@plt>
    48cb:	4c 01 e8             	add    %r13,%rax
    48ce:	48 29 e8             	sub    %rbp,%rax
    48d1:	ba 8f 01 00 00       	mov    $0x18f,%edx
    48d6:	48 39 d0             	cmp    %rdx,%rax
    48d9:	48 0f 47 c2          	cmova  %rdx,%rax
    48dd:	89 c1                	mov    %eax,%ecx
    48df:	83 f8 08             	cmp    $0x8,%eax
    48e2:	0f 83 18 02 00 00    	jae    4b00 <fwp_format_g.constprop.0+0x3b0>
    48e8:	a8 04                	test   $0x4,%al
    48ea:	0f 85 54 03 00 00    	jne    4c44 <fwp_format_g.constprop.0+0x4f4>
    48f0:	85 c0                	test   %eax,%eax
    48f2:	74 0f                	je     4903 <fwp_format_g.constprop.0+0x1b3>
    48f4:	0f b6 54 24 60       	movzbl 0x60(%rsp),%edx
    48f9:	88 13                	mov    %dl,(%rbx)
    48fb:	a8 02                	test   $0x2,%al
    48fd:	0f 85 6b 03 00 00    	jne    4c6e <fwp_format_g.constprop.0+0x51e>
    4903:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4907:	eb 36                	jmp    493f <fwp_format_g.constprop.0+0x1ef>
    4909:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4910:	45 31 c9             	xor    %r9d,%r9d
    4913:	45 85 ed             	test   %r13d,%r13d
    4916:	4c 8d 05 95 67 00 00 	lea    0x6795(%rip),%r8        # b0b2 <_IO_stdin_used+0xb2>
    491d:	48 89 df             	mov    %rbx,%rdi
    4920:	45 0f 49 cd          	cmovns %r13d,%r9d
    4924:	ba 02 00 00 00       	mov    $0x2,%edx
    4929:	be 90 01 00 00       	mov    $0x190,%esi
    492e:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4935:	b8 01 00 00 00       	mov    $0x1,%eax
    493a:	e8 61 ea ff ff       	call   33a0 <__snprintf_chk@plt>
    493f:	be 2e 00 00 00       	mov    $0x2e,%esi
    4944:	48 89 df             	mov    %rbx,%rdi
    4947:	e8 24 eb ff ff       	call   3470 <strchr@plt>
    494c:	48 85 c0             	test   %rax,%rax
    494f:	74 3f                	je     4990 <fwp_format_g.constprop.0+0x240>
    4951:	48 89 df             	mov    %rbx,%rdi
    4954:	e8 e7 ea ff ff       	call   3440 <strlen@plt>
    4959:	48 85 c0             	test   %rax,%rax
    495c:	75 0b                	jne    4969 <fwp_format_g.constprop.0+0x219>
    495e:	eb 30                	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4960:	c6 04 03 00          	movb   $0x0,(%rbx,%rax,1)
    4964:	48 85 c0             	test   %rax,%rax
    4967:	74 27                	je     4990 <fwp_format_g.constprop.0+0x240>
    4969:	48 89 c2             	mov    %rax,%rdx
    496c:	48 83 e8 01          	sub    $0x1,%rax
    4970:	80 3c 03 30          	cmpb   $0x30,(%rbx,%rax,1)
    4974:	74 ea                	je     4960 <fwp_format_g.constprop.0+0x210>
    4976:	80 7c 13 ff 2e       	cmpb   $0x2e,-0x1(%rbx,%rdx,1)
    497b:	0f 84 6f 01 00 00    	je     4af0 <fwp_format_g.constprop.0+0x3a0>
    4981:	0f 1f 40 00          	nopl   0x0(%rax)
    4985:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    498c:	00 00 00 00 
    4990:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
    4997:	00 
    4998:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    499f:	00 00 
    49a1:	0f 85 ec 02 00 00    	jne    4c93 <fwp_format_g.constprop.0+0x543>
    49a7:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
    49ae:	5b                   	pop    %rbx
    49af:	5d                   	pop    %rbp
    49b0:	41 5c                	pop    %r12
    49b2:	41 5d                	pop    %r13
    49b4:	41 5e                	pop    %r14
    49b6:	41 5f                	pop    %r15
    49b8:	c3                   	ret
    49b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    49c0:	4c 29 f5             	sub    %r14,%rbp
    49c3:	b9 40 00 00 00       	mov    $0x40,%ecx
    49c8:	4c 89 f6             	mov    %r14,%rsi
    49cb:	4c 89 04 24          	mov    %r8,(%rsp)
    49cf:	49 89 ec             	mov    %rbp,%r12
    49d2:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    49d7:	4c 89 e2             	mov    %r12,%rdx
    49da:	48 89 ef             	mov    %rbp,%rdi
    49dd:	e8 6e eb ff ff       	call   3550 <__memcpy_chk@plt>
    49e2:	42 c6 44 24 60 00    	movb   $0x0,0x60(%rsp,%r12,1)
    49e8:	be 2e 00 00 00       	mov    $0x2e,%esi
    49ed:	48 89 ef             	mov    %rbp,%rdi
    49f0:	e8 7b ea ff ff       	call   3470 <strchr@plt>
    49f5:	4c 8b 04 24          	mov    (%rsp),%r8
    49f9:	48 85 c0             	test   %rax,%rax
    49fc:	74 40                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    49fe:	4d 85 e4             	test   %r12,%r12
    4a01:	74 3b                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a03:	4a 8d 44 24 5f       	lea    0x5f(%rsp,%r12,1),%rax
    4a08:	eb 23                	jmp    4a2d <fwp_format_g.constprop.0+0x2dd>
    4a0a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a11:	00 00 00 00 
    4a15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    4a1c:	00 00 00 00 
    4a20:	c6 00 00             	movb   $0x0,(%rax)
    4a23:	48 83 e8 01          	sub    $0x1,%rax
    4a27:	49 83 ec 01          	sub    $0x1,%r12
    4a2b:	74 11                	je     4a3e <fwp_format_g.constprop.0+0x2ee>
    4a2d:	80 38 30             	cmpb   $0x30,(%rax)
    4a30:	74 ee                	je     4a20 <fwp_format_g.constprop.0+0x2d0>
    4a32:	42 80 7c 24 5f 2e    	cmpb   $0x2e,0x5f(%rsp,%r12,1)
    4a38:	0f 84 fb 01 00 00    	je     4c39 <fwp_format_g.constprop.0+0x4e9>
    4a3e:	44 89 c0             	mov    %r8d,%eax
    4a41:	ba 02 00 00 00       	mov    $0x2,%edx
    4a46:	49 89 e9             	mov    %rbp,%r9
    4a49:	be 90 01 00 00       	mov    $0x190,%esi
    4a4e:	f7 d8                	neg    %eax
    4a50:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
    4a57:	48 89 df             	mov    %rbx,%rdi
    4a5a:	41 0f 48 c0          	cmovs  %r8d,%eax
    4a5e:	41 c1 f8 1f          	sar    $0x1f,%r8d
    4a62:	41 83 e0 02          	and    $0x2,%r8d
    4a66:	41 83 c0 2b          	add    $0x2b,%r8d
    4a6a:	50                   	push   %rax
    4a6b:	31 c0                	xor    %eax,%eax
    4a6d:	41 50                	push   %r8
    4a6f:	4c 8d 05 32 66 00 00 	lea    0x6632(%rip),%r8        # b0a8 <_IO_stdin_used+0xa8>
    4a76:	e8 25 e9 ff ff       	call   33a0 <__snprintf_chk@plt>
    4a7b:	58                   	pop    %rax
    4a7c:	5a                   	pop    %rdx
    4a7d:	e9 0e ff ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4a82:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4a88:	4d 8b 06             	mov    (%r14),%r8
    4a8b:	48 83 c0 09          	add    $0x9,%rax
    4a8f:	4c 89 f2             	mov    %r14,%rdx
    4a92:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
    4a96:	4c 89 07             	mov    %r8,(%rdi)
    4a99:	45 89 e0             	mov    %r12d,%r8d
    4a9c:	4f 8b 54 06 f8       	mov    -0x8(%r14,%r8,1),%r10
    4aa1:	4e 89 54 07 f8       	mov    %r10,-0x8(%rdi,%r8,1)
    4aa6:	49 89 f8             	mov    %rdi,%r8
    4aa9:	49 29 c0             	sub    %rax,%r8
    4aac:	4c 29 c2             	sub    %r8,%rdx
    4aaf:	45 01 e0             	add    %r12d,%r8d
    4ab2:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ab6:	41 83 f8 08          	cmp    $0x8,%r8d
    4aba:	0f 82 bc fd ff ff    	jb     487c <fwp_format_g.constprop.0+0x12c>
    4ac0:	48 89 0c 24          	mov    %rcx,(%rsp)
    4ac4:	41 83 e0 f8          	and    $0xfffffff8,%r8d
    4ac8:	45 31 d2             	xor    %r10d,%r10d
    4acb:	45 89 d3             	mov    %r10d,%r11d
    4ace:	41 83 c2 08          	add    $0x8,%r10d
    4ad2:	4a 8b 0c 1a          	mov    (%rdx,%r11,1),%rcx
    4ad6:	4a 89 0c 18          	mov    %rcx,(%rax,%r11,1)
    4ada:	45 39 c2             	cmp    %r8d,%r10d
    4add:	72 ec                	jb     4acb <fwp_format_g.constprop.0+0x37b>
    4adf:	48 8b 0c 24          	mov    (%rsp),%rcx
    4ae3:	e9 94 fd ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4aef:	00 
    4af0:	c6 44 13 ff 00       	movb   $0x0,-0x1(%rbx,%rdx,1)
    4af5:	e9 96 fe ff ff       	jmp    4990 <fwp_format_g.constprop.0+0x240>
    4afa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    4b00:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
    4b05:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
    4b09:	48 89 ee             	mov    %rbp,%rsi
    4b0c:	48 83 e7 f8          	and    $0xfffffffffffffff8,%rdi
    4b10:	48 89 13             	mov    %rdx,(%rbx)
    4b13:	89 c2                	mov    %eax,%edx
    4b15:	48 8b 4c 15 f8       	mov    -0x8(%rbp,%rdx,1),%rcx
    4b1a:	48 89 4c 13 f8       	mov    %rcx,-0x8(%rbx,%rdx,1)
    4b1f:	48 89 d9             	mov    %rbx,%rcx
    4b22:	48 29 f9             	sub    %rdi,%rcx
    4b25:	48 29 ce             	sub    %rcx,%rsi
    4b28:	01 c1                	add    %eax,%ecx
    4b2a:	c1 e9 03             	shr    $0x3,%ecx
    4b2d:	f3 48 a5             	rep movsq (%rsi),(%rdi)
    4b30:	e9 ce fd ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4b35:	0f 1f 00             	nopl   (%rax)
    4b38:	c6 00 30             	movb   $0x30,(%rax)
    4b3b:	4c 8d 69 ff          	lea    -0x1(%rcx),%r13
    4b3f:	4c 89 fa             	mov    %r15,%rdx
    4b42:	4c 89 e9             	mov    %r13,%rcx
    4b45:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
    4b4a:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
    4b4f:	4c 89 14 24          	mov    %r10,(%rsp)
    4b53:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
    4b58:	e8 f3 e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4b5d:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    4b62:	b9 48 00 00 00       	mov    $0x48,%ecx
    4b67:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    4b6c:	48 89 c7             	mov    %rax,%rdi
    4b6f:	4c 8b 14 24          	mov    (%rsp),%r10
    4b73:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
    4b78:	4c 89 c8             	mov    %r9,%rax
    4b7b:	4c 29 e8             	sub    %r13,%rax
    4b7e:	48 39 c8             	cmp    %rcx,%rax
    4b81:	48 0f 42 c1          	cmovb  %rcx,%rax
    4b85:	4d 29 cd             	sub    %r9,%r13
    4b88:	49 01 ff             	add    %rdi,%r15
    4b8b:	4c 01 e8             	add    %r13,%rax
    4b8e:	41 83 f8 ff          	cmp    $0xffffffff,%r8d
    4b92:	74 3d                	je     4bd1 <fwp_format_g.constprop.0+0x481>
    4b94:	41 f7 d0             	not    %r8d
    4b97:	31 f6                	xor    %esi,%esi
    4b99:	ba 48 00 00 00       	mov    $0x48,%edx
    4b9e:	41 c6 04 37 30       	movb   $0x30,(%r15,%rsi,1)
    4ba3:	48 39 d0             	cmp    %rdx,%rax
    4ba6:	48 0f 43 d0          	cmovae %rax,%rdx
    4baa:	48 89 d1             	mov    %rdx,%rcx
    4bad:	48 29 c1             	sub    %rax,%rcx
    4bb0:	48 83 c1 01          	add    $0x1,%rcx
    4bb4:	48 39 d1             	cmp    %rdx,%rcx
    4bb7:	48 0f 42 ca          	cmovb  %rdx,%rcx
    4bbb:	48 83 e8 01          	sub    $0x1,%rax
    4bbf:	48 83 c6 01          	add    $0x1,%rsi
    4bc3:	48 29 d0             	sub    %rdx,%rax
    4bc6:	48 01 c8             	add    %rcx,%rax
    4bc9:	41 39 f0             	cmp    %esi,%r8d
    4bcc:	7f cb                	jg     4b99 <fwp_format_g.constprop.0+0x449>
    4bce:	4d 01 c7             	add    %r8,%r15
    4bd1:	b9 48 00 00 00       	mov    $0x48,%ecx
    4bd6:	41 0f b6 12          	movzbl (%r10),%edx
    4bda:	49 8d 7f 01          	lea    0x1(%r15),%rdi
    4bde:	4c 89 f6             	mov    %r14,%rsi
    4be1:	48 39 c8             	cmp    %rcx,%rax
    4be4:	4c 89 1c 24          	mov    %r11,(%rsp)
    4be8:	48 0f 43 c8          	cmovae %rax,%rcx
    4bec:	41 88 17             	mov    %dl,(%r15)
    4bef:	48 89 ca             	mov    %rcx,%rdx
    4bf2:	48 29 c2             	sub    %rax,%rdx
    4bf5:	48 83 c2 01          	add    $0x1,%rdx
    4bf9:	48 39 ca             	cmp    %rcx,%rdx
    4bfc:	48 0f 42 d1          	cmovb  %rcx,%rdx
    4c00:	48 83 e8 01          	sub    $0x1,%rax
    4c04:	48 29 c8             	sub    %rcx,%rax
    4c07:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
    4c0b:	49 63 d4             	movslq %r12d,%rdx
    4c0e:	e8 3d e9 ff ff       	call   3550 <__memcpy_chk@plt>
    4c13:	4c 8b 1c 24          	mov    (%rsp),%r11
    4c17:	4b 8d 04 1f          	lea    (%r15,%r11,1),%rax
    4c1b:	e9 ae fc ff ff       	jmp    48ce <fwp_format_g.constprop.0+0x17e>
    4c20:	c6 44 24 60 2d       	movb   $0x2d,0x60(%rsp)
    4c25:	b9 47 00 00 00       	mov    $0x47,%ecx
    4c2a:	48 8d 44 24 61       	lea    0x61(%rsp),%rax
    4c2f:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
    4c34:	e9 f9 fb ff ff       	jmp    4832 <fwp_format_g.constprop.0+0xe2>
    4c39:	42 c6 44 24 5f 00    	movb   $0x0,0x5f(%rsp,%r12,1)
    4c3f:	e9 fa fd ff ff       	jmp    4a3e <fwp_format_g.constprop.0+0x2ee>
    4c44:	8b 54 24 60          	mov    0x60(%rsp),%edx
    4c48:	89 13                	mov    %edx,(%rbx)
    4c4a:	8b 54 0d fc          	mov    -0x4(%rbp,%rcx,1),%edx
    4c4e:	89 54 0b fc          	mov    %edx,-0x4(%rbx,%rcx,1)
    4c52:	e9 ac fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c57:	41 8b 06             	mov    (%r14),%eax
    4c5a:	89 07                	mov    %eax,(%rdi)
    4c5c:	44 89 e0             	mov    %r12d,%eax
    4c5f:	45 8b 44 06 fc       	mov    -0x4(%r14,%rax,1),%r8d
    4c64:	44 89 44 07 fc       	mov    %r8d,-0x4(%rdi,%rax,1)
    4c69:	e9 0e fc ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c6e:	89 c2                	mov    %eax,%edx
    4c70:	0f b7 4c 15 fe       	movzwl -0x2(%rbp,%rdx,1),%ecx
    4c75:	66 89 4c 13 fe       	mov    %cx,-0x2(%rbx,%rdx,1)
    4c7a:	e9 84 fc ff ff       	jmp    4903 <fwp_format_g.constprop.0+0x1b3>
    4c7f:	44 89 e0             	mov    %r12d,%eax
    4c82:	45 0f b7 44 06 fe    	movzwl -0x2(%r14,%rax,1),%r8d
    4c88:	66 44 89 44 07 fe    	mov    %r8w,-0x2(%rdi,%rax,1)
    4c8e:	e9 e9 fb ff ff       	jmp    487c <fwp_format_g.constprop.0+0x12c>
    4c93:	e8 b8 e7 ff ff       	call   3450 <__stack_chk_fail@plt>
    4c98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    4c9f:	00 

0000000000004ca0 <fwp_heap_report>:
    4ca0:	f3 0f 1e fa          	endbr64
    4ca4:	41 54                	push   %r12
    4ca6:	48 8d 3d 0a 64 00 00 	lea    0x640a(%rip),%rdi        # b0b7 <_IO_stdin_used+0xb7>
    4cad:	55                   	push   %rbp
    4cae:	53                   	push   %rbx
    4caf:	48 81 ec 10 01 00 00 	sub    $0x110,%rsp
    4cb6:	64 48 8b 34 25 28 00 	mov    %fs:0x28,%rsi
    4cbd:	00 00 
    4cbf:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
    4cc6:	00 
    4cc7:	48 8d 35 74 65 00 00 	lea    0x6574(%rip),%rsi        # b242 <_IO_stdin_used+0x242>
    4cce:	e8 3d e9 ff ff       	call   3610 <fopen@plt>
    4cd3:	48 85 c0             	test   %rax,%rax
    4cd6:	0f 84 c5 00 00 00    	je     4da1 <fwp_heap_report+0x101>
    4cdc:	48 89 c5             	mov    %rax,%rbp
    4cdf:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4ce6:	48 89 e3             	mov    %rsp,%rbx
    4ce9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    4cf0:	48 89 ea             	mov    %rbp,%rdx
    4cf3:	be 00 01 00 00       	mov    $0x100,%esi
    4cf8:	48 89 df             	mov    %rbx,%rdi
    4cfb:	e8 f0 e7 ff ff       	call   34f0 <fgets@plt>
    4d00:	48 85 c0             	test   %rax,%rax
    4d03:	74 2b                	je     4d30 <fwp_heap_report+0x90>
    4d05:	81 3b 56 6d 48 57    	cmpl   $0x57486d56,(%rbx)
    4d0b:	75 e3                	jne    4cf0 <fwp_heap_report+0x50>
    4d0d:	80 7b 04 4d          	cmpb   $0x4d,0x4(%rbx)
    4d11:	75 dd                	jne    4cf0 <fwp_heap_report+0x50>
    4d13:	80 7c 24 05 3a       	cmpb   $0x3a,0x5(%rsp)
    4d18:	75 d6                	jne    4cf0 <fwp_heap_report+0x50>
    4d1a:	48 8d 7c 24 06       	lea    0x6(%rsp),%rdi
    4d1f:	ba 0a 00 00 00       	mov    $0xa,%edx
    4d24:	31 f6                	xor    %esi,%esi
    4d26:	e8 45 e8 ff ff       	call   3570 <strtol@plt>
    4d2b:	49 89 c4             	mov    %rax,%r12
    4d2e:	eb c0                	jmp    4cf0 <fwp_heap_report+0x50>
    4d30:	48 89 ef             	mov    %rbp,%rdi
    4d33:	e8 f8 e6 ff ff       	call   3430 <fclose@plt>
    4d38:	48 83 ec 08          	sub    $0x8,%rsp
    4d3c:	4c 8b 0d a5 3e 06 00 	mov    0x63ea5(%rip),%r9        # 68be8 <fwp_heap+0x13c8>
    4d43:	4c 8b 05 fe 3e 06 00 	mov    0x63efe(%rip),%r8        # 68c48 <fwp_heap+0x1428>
    4d4a:	48 8d 15 47 6b 00 00 	lea    0x6b47(%rip),%rdx        # b898 <_IO_stdin_used+0x898>
    4d51:	41 54                	push   %r12
    4d53:	48 8b 0d e6 3e 06 00 	mov    0x63ee6(%rip),%rcx        # 68c40 <fwp_heap+0x1420>
    4d5a:	be 02 00 00 00       	mov    $0x2,%esi
    4d5f:	b8 02 00 00 00       	mov    $0x2,%eax
    4d64:	f2 0f 10 0d f4 3e 06 	movsd  0x63ef4(%rip),%xmm1        # 68c60 <fwp_heap+0x1440>
    4d6b:	00 
    4d6c:	f2 0f 10 05 e4 3e 06 	movsd  0x63ee4(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    4d73:	00 
    4d74:	48 8b 3d c5 a2 00 00 	mov    0xa2c5(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    4d7b:	e8 f0 e8 ff ff       	call   3670 <__fprintf_chk@plt>
    4d80:	58                   	pop    %rax
    4d81:	5a                   	pop    %rdx
    4d82:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
    4d89:	00 
    4d8a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    4d91:	00 00 
    4d93:	75 15                	jne    4daa <fwp_heap_report+0x10a>
    4d95:	48 81 c4 10 01 00 00 	add    $0x110,%rsp
    4d9c:	5b                   	pop    %rbx
    4d9d:	5d                   	pop    %rbp
    4d9e:	41 5c                	pop    %r12
    4da0:	c3                   	ret
    4da1:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    4da8:	eb 8e                	jmp    4d38 <fwp_heap_report+0x98>
    4daa:	e8 a1 e6 ff ff       	call   3450 <__stack_chk_fail@plt>
    4daf:	90                   	nop

0000000000004db0 <fwp_heap_init>:
    4db0:	66 0f 6f 05 e8 6e 00 	movdqa 0x6ee8(%rip),%xmm0        # bca0 <msg.4+0x30>
    4db7:	00 
    4db8:	41 54                	push   %r12
    4dba:	48 8d 05 9f 39 06 00 	lea    0x6399f(%rip),%rax        # 68760 <fwp_heap+0xf40>
    4dc1:	ba 00 01 00 00       	mov    $0x100,%edx
    4dc6:	55                   	push   %rbp
    4dc7:	66 0f 6f 15 11 6f 00 	movdqa 0x6f11(%rip),%xmm2        # bce0 <msg.4+0x70>
    4dce:	00 
    4dcf:	48 8d 78 60          	lea    0x60(%rax),%rdi
    4dd3:	53                   	push   %rbx
    4dd4:	0f 29 05 45 39 06 00 	movaps %xmm0,0x63945(%rip)        # 68720 <fwp_heap+0xf00>
    4ddb:	66 0f 6f 05 cd 6e 00 	movdqa 0x6ecd(%rip),%xmm0        # bcb0 <msg.4+0x40>
    4de2:	00 
    4de3:	66 0f 6f da          	movdqa %xmm2,%xmm3
    4de7:	c7 05 d3 3d 06 00 01 	movl   $0x1,0x63dd3(%rip)        # 68bc4 <fwp_heap+0x13a4>
    4dee:	00 00 00 
    4df1:	66 0f 73 d3 20       	psrlq  $0x20,%xmm3
    4df6:	0f 29 05 33 39 06 00 	movaps %xmm0,0x63933(%rip)        # 68730 <fwp_heap+0xf10>
    4dfd:	66 0f 6f 05 bb 6e 00 	movdqa 0x6ebb(%rip),%xmm0        # bcc0 <msg.4+0x50>
    4e04:	00 
    4e05:	0f 29 05 34 39 06 00 	movaps %xmm0,0x63934(%rip)        # 68740 <fwp_heap+0xf20>
    4e0c:	66 0f 6f 05 bc 6e 00 	movdqa 0x6ebc(%rip),%xmm0        # bcd0 <msg.4+0x60>
    4e13:	00 
    4e14:	0f 29 05 35 39 06 00 	movaps %xmm0,0x63935(%rip)        # 68750 <fwp_heap+0xf30>
    4e1b:	89 d3                	mov    %edx,%ebx
    4e1d:	66 0f 6e e2          	movd   %edx,%xmm4
    4e21:	48 83 c0 10          	add    $0x10,%rax
    4e25:	01 d2                	add    %edx,%edx
    4e27:	c1 eb 02             	shr    $0x2,%ebx
    4e2a:	66 0f 6e c3          	movd   %ebx,%xmm0
    4e2e:	66 0f 70 c0 00       	pshufd $0x0,%xmm0,%xmm0
    4e33:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    4e37:	66 0f 73 d0 20       	psrlq  $0x20,%xmm0
    4e3c:	66 0f f4 ca          	pmuludq %xmm2,%xmm1
    4e40:	66 0f f4 c3          	pmuludq %xmm3,%xmm0
    4e44:	66 0f 70 c9 08       	pshufd $0x8,%xmm1,%xmm1
    4e49:	66 0f 70 c0 08       	pshufd $0x8,%xmm0,%xmm0
    4e4e:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
    4e52:	66 0f 70 c4 00       	pshufd $0x0,%xmm4,%xmm0
    4e57:	66 0f fe c1          	paddd  %xmm1,%xmm0
    4e5b:	0f 29 40 f0          	movaps %xmm0,-0x10(%rax)
    4e5f:	48 39 c7             	cmp    %rax,%rdi
    4e62:	75 b7                	jne    4e1b <fwp_heap_init+0x6b>
    4e64:	4c 8d 05 b5 29 06 00 	lea    0x629b5(%rip),%r8        # 67820 <fwp_heap>
    4e6b:	31 c9                	xor    %ecx,%ecx
    4e6d:	31 c0                	xor    %eax,%eax
    4e6f:	49 8d b0 00 0f 00 00 	lea    0xf00(%r8),%rsi
    4e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4e7d:	00 00 00 
    4e80:	41 8b 94 80 00 0f 00 	mov    0xf00(%r8,%rax,4),%edx
    4e87:	00 
    4e88:	48 39 ca             	cmp    %rcx,%rdx
    4e8b:	73 0f                	jae    4e9c <fwp_heap_init+0xec>
    4e8d:	0f 1f 00             	nopl   (%rax)
    4e90:	48 83 c0 01          	add    $0x1,%rax
    4e94:	8b 14 86             	mov    (%rsi,%rax,4),%edx
    4e97:	48 39 ca             	cmp    %rcx,%rdx
    4e9a:	72 f4                	jb     4e90 <fwp_heap_init+0xe0>
    4e9c:	48 83 c1 10          	add    $0x10,%rcx
    4ea0:	88 07                	mov    %al,(%rdi)
    4ea2:	48 83 c7 01          	add    $0x1,%rdi
    4ea6:	48 81 f9 10 40 00 00 	cmp    $0x4010,%rcx
    4ead:	75 d1                	jne    4e80 <fwp_heap_init+0xd0>
    4eaf:	48 bb 00 00 00 00 10 	movabs $0x1000000000,%rbx
    4eb6:	00 00 00 
    4eb9:	bd 05 00 00 00       	mov    $0x5,%ebp
    4ebe:	4c 8d a3 00 00 01 00 	lea    0x10000(%rbx),%r12
    4ec5:	45 31 c9             	xor    %r9d,%r9d
    4ec8:	31 d2                	xor    %edx,%edx
    4eca:	31 ff                	xor    %edi,%edi
    4ecc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4ed2:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4ed7:	4c 89 e6             	mov    %r12,%rsi
    4eda:	e8 81 e5 ff ff       	call   3460 <mmap@plt>
    4edf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4ee3:	75 13                	jne    4ef8 <fwp_heap_init+0x148>
    4ee5:	48 c1 eb 02          	shr    $0x2,%rbx
    4ee9:	83 ed 01             	sub    $0x1,%ebp
    4eec:	75 d0                	jne    4ebe <fwp_heap_init+0x10e>
    4eee:	e8 1d ef ff ff       	call   3e10 <fwp_heap_oom>
    4ef3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    4ef8:	48 85 c0             	test   %rax,%rax
    4efb:	74 f1                	je     4eee <fwp_heap_init+0x13e>
    4efd:	48 c1 eb 10          	shr    $0x10,%rbx
    4f01:	48 89 05 d0 3c 06 00 	mov    %rax,0x63cd0(%rip)        # 68bd8 <fwp_heap+0x13b8>
    4f08:	45 31 c9             	xor    %r9d,%r9d
    4f0b:	31 d2                	xor    %edx,%edx
    4f0d:	48 05 ff ff 00 00    	add    $0xffff,%rax
    4f13:	48 8d 34 9b          	lea    (%rbx,%rbx,4),%rsi
    4f17:	31 ff                	xor    %edi,%edi
    4f19:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    4f1f:	66 31 c0             	xor    %ax,%ax
    4f22:	48 c1 e6 03          	shl    $0x3,%rsi
    4f26:	b9 22 40 00 00       	mov    $0x4022,%ecx
    4f2b:	4c 89 25 ae 3c 06 00 	mov    %r12,0x63cae(%rip)        # 68be0 <fwp_heap+0x13c0>
    4f32:	48 89 05 97 3c 06 00 	mov    %rax,0x63c97(%rip)        # 68bd0 <fwp_heap+0x13b0>
    4f39:	48 89 1d b0 3c 06 00 	mov    %rbx,0x63cb0(%rip)        # 68bf0 <fwp_heap+0x13d0>
    4f40:	48 89 35 d9 3c 06 00 	mov    %rsi,0x63cd9(%rip)        # 68c20 <fwp_heap+0x1400>
    4f47:	e8 14 e5 ff ff       	call   3460 <mmap@plt>
    4f4c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
    4f50:	74 9c                	je     4eee <fwp_heap_init+0x13e>
    4f52:	48 8d 3d 94 61 00 00 	lea    0x6194(%rip),%rdi        # b0ed <_IO_stdin_used+0xed>
    4f59:	48 89 05 b8 3c 06 00 	mov    %rax,0x63cb8(%rip)        # 68c18 <fwp_heap+0x13f8>
    4f60:	e8 2b e4 ff ff       	call   3390 <getenv@plt>
    4f65:	48 89 c2             	mov    %rax,%rdx
    4f68:	31 c0                	xor    %eax,%eax
    4f6a:	48 85 d2             	test   %rdx,%rdx
    4f6d:	74 15                	je     4f84 <fwp_heap_init+0x1d4>
    4f6f:	80 3a 00             	cmpb   $0x0,(%rdx)
    4f72:	74 10                	je     4f84 <fwp_heap_init+0x1d4>
    4f74:	0f b6 02             	movzbl (%rdx),%eax
    4f77:	83 e8 30             	sub    $0x30,%eax
    4f7a:	74 13                	je     4f8f <fwp_heap_init+0x1df>
    4f7c:	85 c0                	test   %eax,%eax
    4f7e:	0f 95 c0             	setne  %al
    4f81:	0f b6 c0             	movzbl %al,%eax
    4f84:	5b                   	pop    %rbx
    4f85:	5d                   	pop    %rbp
    4f86:	89 05 3c 3c 06 00    	mov    %eax,0x63c3c(%rip)        # 68bc8 <fwp_heap+0x13a8>
    4f8c:	41 5c                	pop    %r12
    4f8e:	c3                   	ret
    4f8f:	0f b6 42 01          	movzbl 0x1(%rdx),%eax
    4f93:	85 c0                	test   %eax,%eax
    4f95:	0f 95 c0             	setne  %al
    4f98:	0f b6 c0             	movzbl %al,%eax
    4f9b:	eb e7                	jmp    4f84 <fwp_heap_init+0x1d4>
    4f9d:	0f 1f 00             	nopl   (%rax)

0000000000004fa0 <fwp_wake_io>:
    4fa0:	48 8b 07             	mov    (%rdi),%rax
    4fa3:	48 85 c0             	test   %rax,%rax
    4fa6:	0f 84 f4 00 00 00    	je     50a0 <fwp_wake_io+0x100>
    4fac:	53                   	push   %rbx
    4fad:	4c 8b 05 2c 28 06 00 	mov    0x6282c(%rip),%r8        # 677e0 <fwp_ready_tail>
    4fb4:	49 89 f9             	mov    %rdi,%r9
    4fb7:	48 89 c2             	mov    %rax,%rdx
    4fba:	45 31 db             	xor    %r11d,%r11d
    4fbd:	45 31 d2             	xor    %r10d,%r10d
    4fc0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    4fc4:	eb 71                	jmp    5037 <fwp_wake_io+0x97>
    4fc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    4fcd:	00 00 00 
    4fd0:	48 89 8e 28 01 00 00 	mov    %rcx,0x128(%rsi)
    4fd7:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    4fde:	48 85 c9             	test   %rcx,%rcx
    4fe1:	74 07                	je     4fea <fwp_wake_io+0x4a>
    4fe3:	48 89 b1 20 01 00 00 	mov    %rsi,0x120(%rcx)
    4fea:	48 c7 80 28 01 00 00 	movq   $0x0,0x128(%rax)
    4ff1:	00 00 00 00 
    4ff5:	0f 11 80 18 01 00 00 	movups %xmm0,0x118(%rax)
    4ffc:	49 8b 01             	mov    (%r9),%rax
    4fff:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5003:	75 2a                	jne    502f <fwp_wake_io+0x8f>
    5005:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    5009:	75 24                	jne    502f <fwp_wake_io+0x8f>
    500b:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    500f:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    5016:	00 00 00 00 
    501a:	4d 85 c0             	test   %r8,%r8
    501d:	74 51                	je     5070 <fwp_wake_io+0xd0>
    501f:	49 89 90 00 01 00 00 	mov    %rdx,0x100(%r8)
    5026:	49 89 d0             	mov    %rdx,%r8
    5029:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    502f:	48 89 c2             	mov    %rax,%rdx
    5032:	48 85 c0             	test   %rax,%rax
    5035:	74 49                	je     5080 <fwp_wake_io+0xe0>
    5037:	48 8b b8 18 01 00 00 	mov    0x118(%rax),%rdi
    503e:	c6 40 57 01          	movb   $0x1,0x57(%rax)
    5042:	48 85 ff             	test   %rdi,%rdi
    5045:	74 b8                	je     4fff <fwp_wake_io+0x5f>
    5047:	48 8b b0 20 01 00 00 	mov    0x120(%rax),%rsi
    504e:	48 8b 88 28 01 00 00 	mov    0x128(%rax),%rcx
    5055:	48 85 f6             	test   %rsi,%rsi
    5058:	0f 85 72 ff ff ff    	jne    4fd0 <fwp_wake_io+0x30>
    505e:	48 89 0f             	mov    %rcx,(%rdi)
    5061:	e9 78 ff ff ff       	jmp    4fde <fwp_wake_io+0x3e>
    5066:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    506d:	00 00 00 
    5070:	48 89 d3             	mov    %rdx,%rbx
    5073:	41 bb 01 00 00 00    	mov    $0x1,%r11d
    5079:	eb ab                	jmp    5026 <fwp_wake_io+0x86>
    507b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5080:	45 84 db             	test   %r11b,%r11b
    5083:	74 07                	je     508c <fwp_wake_io+0xec>
    5085:	48 89 1d 5c 27 06 00 	mov    %rbx,0x6275c(%rip)        # 677e8 <fwp_ready_head>
    508c:	45 84 d2             	test   %r10b,%r10b
    508f:	74 07                	je     5098 <fwp_wake_io+0xf8>
    5091:	4c 89 05 48 27 06 00 	mov    %r8,0x62748(%rip)        # 677e0 <fwp_ready_tail>
    5098:	5b                   	pop    %rbx
    5099:	c3                   	ret
    509a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    50a0:	c3                   	ret
    50a1:	0f 1f 40 00          	nopl   0x0(%rax)
    50a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    50ac:	00 00 00 00 

00000000000050b0 <ad_raw_free.part.0>:
    50b0:	48 8d 0d 09 a1 04 00 	lea    0x4a109(%rip),%rcx        # 4f1c0 <ad_raw_blocks>
    50b7:	31 c0                	xor    %eax,%eax
    50b9:	48 89 ca             	mov    %rcx,%rdx
    50bc:	eb 12                	jmp    50d0 <ad_raw_free.part.0+0x20>
    50be:	66 90                	xchg   %ax,%ax
    50c0:	48 83 c0 01          	add    $0x1,%rax
    50c4:	48 83 c2 18          	add    $0x18,%rdx
    50c8:	48 3d 00 10 00 00    	cmp    $0x1000,%rax
    50ce:	74 40                	je     5110 <ad_raw_free.part.0+0x60>
    50d0:	48 3b 3a             	cmp    (%rdx),%rdi
    50d3:	75 eb                	jne    50c0 <ad_raw_free.part.0+0x10>
    50d5:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    50d9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    50dd:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
    50e1:	48 8d 0d b8 a0 04 00 	lea    0x4a0b8(%rip),%rcx        # 4f1a0 <ad_raw_live>
    50e8:	8b 70 10             	mov    0x10(%rax),%esi
    50eb:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    50f2:	00 
    50f3:	48 8b 14 f1          	mov    (%rcx,%rsi,8),%rdx
    50f7:	48 2b 50 08          	sub    0x8(%rax),%rdx
    50fb:	0f 11 00             	movups %xmm0,(%rax)
    50fe:	48 89 14 f1          	mov    %rdx,(%rcx,%rsi,8)
    5102:	e9 a9 e2 ff ff       	jmp    33b0 <free@plt>
    5107:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    510e:	00 00 
    5110:	48 83 ec 08          	sub    $0x8,%rsp
    5114:	48 8d 3d e2 5f 00 00 	lea    0x5fe2(%rip),%rdi        # b0fd <_IO_stdin_used+0xfd>
    511b:	e8 c0 ee ff ff       	call   3fe0 <ad_raw_fail>

0000000000005120 <fwp_tape_buffers_dispose>:
    5120:	53                   	push   %rbx
    5121:	48 89 fb             	mov    %rdi,%rbx
    5124:	48 8b 3f             	mov    (%rdi),%rdi
    5127:	48 85 ff             	test   %rdi,%rdi
    512a:	74 05                	je     5131 <fwp_tape_buffers_dispose+0x11>
    512c:	e8 7f ff ff ff       	call   50b0 <ad_raw_free.part.0>
    5131:	48 8b 7b 10          	mov    0x10(%rbx),%rdi
    5135:	48 85 ff             	test   %rdi,%rdi
    5138:	74 05                	je     513f <fwp_tape_buffers_dispose+0x1f>
    513a:	e8 71 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    513f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    5143:	48 85 ff             	test   %rdi,%rdi
    5146:	74 05                	je     514d <fwp_tape_buffers_dispose+0x2d>
    5148:	e8 63 ff ff ff       	call   50b0 <ad_raw_free.part.0>
    514d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5151:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    5158:	00 
    5159:	0f 11 03             	movups %xmm0,(%rbx)
    515c:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5160:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    5164:	5b                   	pop    %rbx
    5165:	c3                   	ret
    5166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    516d:	00 00 00 

0000000000005170 <ad_raw_realloc>:
    5170:	41 55                	push   %r13
    5172:	41 54                	push   %r12
    5174:	55                   	push   %rbp
    5175:	53                   	push   %rbx
    5176:	48 83 ec 08          	sub    $0x8,%rsp
    517a:	48 85 f6             	test   %rsi,%rsi
    517d:	0f 84 a6 00 00 00    	je     5229 <ad_raw_realloc+0xb9>
    5183:	4c 8d 25 36 a0 04 00 	lea    0x4a036(%rip),%r12        # 4f1c0 <ad_raw_blocks>
    518a:	48 89 f5             	mov    %rsi,%rbp
    518d:	41 89 d5             	mov    %edx,%r13d
    5190:	31 db                	xor    %ebx,%ebx
    5192:	4c 89 e0             	mov    %r12,%rax
    5195:	eb 1a                	jmp    51b1 <ad_raw_realloc+0x41>
    5197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    519e:	00 00 
    51a0:	48 83 c3 01          	add    $0x1,%rbx
    51a4:	48 83 c0 18          	add    $0x18,%rax
    51a8:	48 81 fb 00 10 00 00 	cmp    $0x1000,%rbx
    51af:	74 4f                	je     5200 <ad_raw_realloc+0x90>
    51b1:	48 3b 38             	cmp    (%rax),%rdi
    51b4:	75 ea                	jne    51a0 <ad_raw_realloc+0x30>
    51b6:	48 85 ff             	test   %rdi,%rdi
    51b9:	74 0b                	je     51c6 <ad_raw_realloc+0x56>
    51bb:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51bf:	45 39 6c c4 10       	cmp    %r13d,0x10(%r12,%rax,8)
    51c4:	75 57                	jne    521d <ad_raw_realloc+0xad>
    51c6:	48 89 ee             	mov    %rbp,%rsi
    51c9:	e8 e2 e3 ff ff       	call   35b0 <realloc@plt>
    51ce:	49 89 c2             	mov    %rax,%r10
    51d1:	48 85 c0             	test   %rax,%rax
    51d4:	74 16                	je     51ec <ad_raw_realloc+0x7c>
    51d6:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
    51da:	44 89 e9             	mov    %r13d,%ecx
    51dd:	48 89 ea             	mov    %rbp,%rdx
    51e0:	4c 89 d6             	mov    %r10,%rsi
    51e3:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
    51e7:	e8 f4 e9 ff ff       	call   3be0 <ad_raw_record>
    51ec:	48 83 c4 08          	add    $0x8,%rsp
    51f0:	4c 89 d0             	mov    %r10,%rax
    51f3:	5b                   	pop    %rbx
    51f4:	5d                   	pop    %rbp
    51f5:	41 5c                	pop    %r12
    51f7:	41 5d                	pop    %r13
    51f9:	c3                   	ret
    51fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5200:	48 85 ff             	test   %rdi,%rdi
    5203:	48 8d 05 08 5f 00 00 	lea    0x5f08(%rip),%rax        # b112 <_IO_stdin_used+0x112>
    520a:	48 8d 15 ec 5e 00 00 	lea    0x5eec(%rip),%rdx        # b0fd <_IO_stdin_used+0xfd>
    5211:	48 0f 45 c2          	cmovne %rdx,%rax
    5215:	48 89 c7             	mov    %rax,%rdi
    5218:	e8 c3 ed ff ff       	call   3fe0 <ad_raw_fail>
    521d:	48 8d 3d 24 5f 00 00 	lea    0x5f24(%rip),%rdi        # b148 <_IO_stdin_used+0x148>
    5224:	e8 b7 ed ff ff       	call   3fe0 <ad_raw_fail>
    5229:	48 8d 3d fd 5e 00 00 	lea    0x5efd(%rip),%rdi        # b12d <_IO_stdin_used+0x12d>
    5230:	e8 ab ed ff ff       	call   3fe0 <ad_raw_fail>
    5235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    523c:	00 00 00 00 

0000000000005240 <fwp_tape_buffers_release>:
    5240:	f3 0f 1e fa          	endbr64
    5244:	53                   	push   %rbx
    5245:	48 89 fb             	mov    %rdi,%rbx
    5248:	48 83 ec 10          	sub    $0x10,%rsp
    524c:	48 8b 47 28          	mov    0x28(%rdi),%rax
    5250:	48 85 c0             	test   %rax,%rax
    5253:	0f 88 d7 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5259:	48 8b 57 30          	mov    0x30(%rdi),%rdx
    525d:	48 85 d2             	test   %rdx,%rdx
    5260:	0f 88 ca 00 00 00    	js     5330 <fwp_tape_buffers_release+0xf0>
    5266:	48 3d 55 55 00 00    	cmp    $0x5555,%rax
    526c:	0f 87 be 00 00 00    	ja     5330 <fwp_tape_buffers_release+0xf0>
    5272:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
    5276:	b8 00 00 08 00       	mov    $0x80000,%eax
    527b:	48 c1 e1 03          	shl    $0x3,%rcx
    527f:	48 29 c8             	sub    %rcx,%rax
    5282:	48 c1 e8 03          	shr    $0x3,%rax
    5286:	48 39 d0             	cmp    %rdx,%rax
    5289:	0f 82 a1 00 00 00    	jb     5330 <fwp_tape_buffers_release+0xf0>
    528f:	48 8d 3d ca 5e 00 00 	lea    0x5eca(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5296:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    529b:	48 89 14 24          	mov    %rdx,(%rsp)
    529f:	e8 ec e0 ff ff       	call   3390 <getenv@plt>
    52a4:	48 8b 14 24          	mov    (%rsp),%rdx
    52a8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    52ad:	48 85 c0             	test   %rax,%rax
    52b0:	74 09                	je     52bb <fwp_tape_buffers_release+0x7b>
    52b2:	80 38 30             	cmpb   $0x30,(%rax)
    52b5:	0f 84 05 01 00 00    	je     53c0 <fwp_tape_buffers_release+0x180>
    52bb:	48 8d 34 d1          	lea    (%rcx,%rdx,8),%rsi
    52bf:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
    52c3:	48 3d ff ff 07 00    	cmp    $0x7ffff,%rax
    52c9:	77 71                	ja     533c <fwp_tape_buffers_release+0xfc>
    52cb:	48 8d 3d ce 9d 01 00 	lea    0x19dce(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    52d2:	48 89 34 24          	mov    %rsi,(%rsp)
    52d6:	e8 45 fe ff ff       	call   5120 <fwp_tape_buffers_dispose>
    52db:	f3 0f 6f 03          	movdqu (%rbx),%xmm0
    52df:	48 8b 34 24          	mov    (%rsp),%rsi
    52e3:	0f 29 05 b6 9d 01 00 	movaps %xmm0,0x19db6(%rip)        # 1f0a0 <fwp_tape_workspace>
    52ea:	f3 0f 6f 43 10       	movdqu 0x10(%rbx),%xmm0
    52ef:	48 89 35 92 9d 01 00 	mov    %rsi,0x19d92(%rip)        # 1f088 <fwp_tape_cached_bytes>
    52f6:	0f 29 05 b3 9d 01 00 	movaps %xmm0,0x19db3(%rip)        # 1f0b0 <fwp_tape_workspace+0x10>
    52fd:	f3 0f 6f 43 20       	movdqu 0x20(%rbx),%xmm0
    5302:	0f 29 05 b7 9d 01 00 	movaps %xmm0,0x19db7(%rip)        # 1f0c0 <fwp_tape_workspace+0x20>
    5309:	48 8b 43 30          	mov    0x30(%rbx),%rax
    530d:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5311:	48 89 05 b8 9d 01 00 	mov    %rax,0x19db8(%rip)        # 1f0d0 <fwp_tape_workspace+0x30>
    5318:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
    531f:	00 
    5320:	0f 11 03             	movups %xmm0,(%rbx)
    5323:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
    5327:	0f 11 43 20          	movups %xmm0,0x20(%rbx)
    532b:	eb 1e                	jmp    534b <fwp_tape_buffers_release+0x10b>
    532d:	0f 1f 00             	nopl   (%rax)
    5330:	48 8d 3d 29 5e 00 00 	lea    0x5e29(%rip),%rdi        # b160 <_IO_stdin_used+0x160>
    5337:	e8 54 e0 ff ff       	call   3390 <getenv@plt>
    533c:	48 89 df             	mov    %rbx,%rdi
    533f:	e8 dc fd ff ff       	call   5120 <fwp_tape_buffers_dispose>
    5344:	48 8b 35 3d 9d 01 00 	mov    0x19d3d(%rip),%rsi        # 1f088 <fwp_tape_cached_bytes>
    534b:	48 6b 15 8d 9d 01 00 	imul   $0x68,0x19d8d(%rip),%rdx        # 1f0e0 <fwp_tapes_cap>
    5352:	68 
    5353:	48 3b 15 46 9e 04 00 	cmp    0x49e46(%rip),%rdx        # 4f1a0 <ad_raw_live>
    535a:	75 73                	jne    53cf <fwp_tape_buffers_release+0x18f>
    535c:	48 8b 05 45 9e 04 00 	mov    0x49e45(%rip),%rax        # 4f1a8 <ad_raw_live+0x8>
    5363:	48 8d 0c 32          	lea    (%rdx,%rsi,1),%rcx
    5367:	48 01 d0             	add    %rdx,%rax
    536a:	48 03 05 3f 9e 04 00 	add    0x49e3f(%rip),%rax        # 4f1b0 <ad_raw_live+0x10>
    5371:	48 03 05 40 9e 04 00 	add    0x49e40(%rip),%rax        # 4f1b8 <ad_raw_live+0x18>
    5378:	48 39 c8             	cmp    %rcx,%rax
    537b:	72 52                	jb     53cf <fwp_tape_buffers_release+0x18f>
    537d:	48 8b 0d 7c 9d 01 00 	mov    0x19d7c(%rip),%rcx        # 1f100 <ad_raw_checkpoint_count>
    5384:	48 81 f9 00 20 00 00 	cmp    $0x2000,%rcx
    538b:	74 4e                	je     53db <fwp_tape_buffers_release+0x19b>
    538d:	48 8d 79 01          	lea    0x1(%rcx),%rdi
    5391:	48 29 d0             	sub    %rdx,%rax
    5394:	48 89 3d 65 9d 01 00 	mov    %rdi,0x19d65(%rip)        # 1f100 <ad_raw_checkpoint_count>
    539b:	48 29 f0             	sub    %rsi,%rax
    539e:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
    53a2:	48 8d 0d 77 9d 01 00 	lea    0x19d77(%rip),%rcx        # 1f120 <ad_raw_checkpoints>
    53a9:	48 89 14 f9          	mov    %rdx,(%rcx,%rdi,8)
    53ad:	48 89 74 f9 08       	mov    %rsi,0x8(%rcx,%rdi,8)
    53b2:	48 89 44 f9 10       	mov    %rax,0x10(%rcx,%rdi,8)
    53b7:	48 83 c4 10          	add    $0x10,%rsp
    53bb:	5b                   	pop    %rbx
    53bc:	c3                   	ret
    53bd:	0f 1f 00             	nopl   (%rax)
    53c0:	80 78 01 00          	cmpb   $0x0,0x1(%rax)
    53c4:	0f 84 72 ff ff ff    	je     533c <fwp_tape_buffers_release+0xfc>
    53ca:	e9 ec fe ff ff       	jmp    52bb <fwp_tape_buffers_release+0x7b>
    53cf:	48 8d 3d 4a 65 00 00 	lea    0x654a(%rip),%rdi        # b920 <_IO_stdin_used+0x920>
    53d6:	e8 05 ec ff ff       	call   3fe0 <ad_raw_fail>
    53db:	48 8d 3d 8f 5d 00 00 	lea    0x5d8f(%rip),%rdi        # b171 <_IO_stdin_used+0x171>
    53e2:	e8 f9 eb ff ff       	call   3fe0 <ad_raw_fail>
    53e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    53ee:	00 00 

00000000000053f0 <fwp_poll_events>:
    53f0:	53                   	push   %rbx
    53f1:	48 83 ec 20          	sub    $0x20,%rsp
    53f5:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    53fc:	00 00 
    53fe:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    5403:	31 c0                	xor    %eax,%eax
    5405:	e8 96 f1 ff ff       	call   45a0 <fwp_now_ns>
    540a:	48 8b 1d c7 23 06 00 	mov    0x623c7(%rip),%rbx        # 677d8 <fwp_timers>
    5411:	48 85 db             	test   %rbx,%rbx
    5414:	0f 84 e6 00 00 00    	je     5500 <fwp_poll_events+0x110>
    541a:	48 89 c6             	mov    %rax,%rsi
    541d:	48 89 da             	mov    %rbx,%rdx
    5420:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    5427:	eb 26                	jmp    544f <fwp_poll_events+0x5f>
    5429:	90                   	nop
    542a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    5431:	00 00 00 00 
    5435:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    543c:	00 00 00 00 
    5440:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5447:	48 89 c8             	mov    %rcx,%rax
    544a:	48 85 d2             	test   %rdx,%rdx
    544d:	74 31                	je     5480 <fwp_poll_events+0x90>
    544f:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    5453:	48 85 c0             	test   %rax,%rax
    5456:	78 e8                	js     5440 <fwp_poll_events+0x50>
    5458:	48 39 c1             	cmp    %rax,%rcx
    545b:	7c e3                	jl     5440 <fwp_poll_events+0x50>
    545d:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5464:	48 85 d2             	test   %rdx,%rdx
    5467:	74 1c                	je     5485 <fwp_poll_events+0x95>
    5469:	48 8b 4a 68          	mov    0x68(%rdx),%rcx
    546d:	48 39 c1             	cmp    %rax,%rcx
    5470:	7c ce                	jl     5440 <fwp_poll_events+0x50>
    5472:	48 8b 92 10 01 00 00 	mov    0x110(%rdx),%rdx
    5479:	48 85 d2             	test   %rdx,%rdx
    547c:	75 d1                	jne    544f <fwp_poll_events+0x5f>
    547e:	66 90                	xchg   %ax,%ax
    5480:	48 85 c0             	test   %rax,%rax
    5483:	78 7b                	js     5500 <fwp_poll_events+0x110>
    5485:	48 29 f0             	sub    %rsi,%rax
    5488:	48 89 c1             	mov    %rax,%rcx
    548b:	48 85 c0             	test   %rax,%rax
    548e:	0f 8e 9c 00 00 00    	jle    5530 <fwp_poll_events+0x140>
    5494:	48 ba db 34 b6 d7 82 	movabs $0x431bde82d7b634db,%rdx
    549b:	de 1b 43 
    549e:	48 f7 ea             	imul   %rdx
    54a1:	48 89 c8             	mov    %rcx,%rax
    54a4:	48 c1 f8 3f          	sar    $0x3f,%rax
    54a8:	48 c1 fa 12          	sar    $0x12,%rdx
    54ac:	48 29 c2             	sub    %rax,%rdx
    54af:	48 69 c2 40 42 0f 00 	imul   $0xf4240,%rdx,%rax
    54b6:	48 39 c1             	cmp    %rax,%rcx
    54b9:	0f 95 c0             	setne  %al
    54bc:	0f b6 c0             	movzbl %al,%eax
    54bf:	48 01 d0             	add    %rdx,%rax
    54c2:	48 3d ff ff ff 7f    	cmp    $0x7fffffff,%rax
    54c8:	0f 8f 32 01 00 00    	jg     5600 <fwp_poll_events+0x210>
    54ce:	48 85 c0             	test   %rax,%rax
    54d1:	74 5d                	je     5530 <fwp_poll_events+0x140>
    54d3:	89 c1                	mov    %eax,%ecx
    54d5:	48 69 c9 d3 4d 62 10 	imul   $0x10624dd3,%rcx,%rcx
    54dc:	48 c1 e9 26          	shr    $0x26,%rcx
    54e0:	48 63 d1             	movslq %ecx,%rdx
    54e3:	69 c9 e8 03 00 00    	imul   $0x3e8,%ecx,%ecx
    54e9:	29 c8                	sub    %ecx,%eax
    54eb:	48 98                	cltq
    54ed:	48 69 c0 40 42 0f 00 	imul   $0xf4240,%rax,%rax
    54f4:	e9 11 01 00 00       	jmp    560a <fwp_poll_events+0x21a>
    54f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5500:	e8 db e7 ff ff       	call   3ce0 <fwp_flush>
    5505:	ba 2b 00 00 00       	mov    $0x2b,%edx
    550a:	be 01 00 00 00       	mov    $0x1,%esi
    550f:	48 8b 0d 2a 9b 00 00 	mov    0x9b2a(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    5516:	48 8d 3d 33 64 00 00 	lea    0x6433(%rip),%rdi        # b950 <_IO_stdin_used+0x950>
    551d:	e8 3e e1 ff ff       	call   3660 <fwrite@plt>
    5522:	bf 65 00 00 00       	mov    $0x65,%edi
    5527:	e8 24 e1 ff ff       	call   3650 <exit@plt>
    552c:	0f 1f 40 00          	nopl   0x0(%rax)
    5530:	e8 6b f0 ff ff       	call   45a0 <fwp_now_ns>
    5535:	48 89 c1             	mov    %rax,%rcx
    5538:	66 0f ef c0          	pxor   %xmm0,%xmm0
    553c:	eb 44                	jmp    5582 <fwp_poll_events+0x192>
    553e:	66 90                	xchg   %ax,%ax
    5540:	80 7a 54 00          	cmpb   $0x0,0x54(%rdx)
    5544:	75 33                	jne    5579 <fwp_poll_events+0x189>
    5546:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    554a:	75 2d                	jne    5579 <fwp_poll_events+0x189>
    554c:	48 8b 05 8d 22 06 00 	mov    0x6228d(%rip),%rax        # 677e0 <fwp_ready_tail>
    5553:	c6 42 54 01          	movb   $0x1,0x54(%rdx)
    5557:	48 c7 82 00 01 00 00 	movq   $0x0,0x100(%rdx)
    555e:	00 00 00 00 
    5562:	48 85 c0             	test   %rax,%rax
    5565:	0f 84 05 01 00 00    	je     5670 <fwp_poll_events+0x280>
    556b:	48 89 90 00 01 00 00 	mov    %rdx,0x100(%rax)
    5572:	48 89 15 67 22 06 00 	mov    %rdx,0x62267(%rip)        # 677e0 <fwp_ready_tail>
    5579:	48 85 db             	test   %rbx,%rbx
    557c:	0f 84 be 00 00 00    	je     5640 <fwp_poll_events+0x250>
    5582:	48 89 da             	mov    %rbx,%rdx
    5585:	48 8b 9b 10 01 00 00 	mov    0x110(%rbx),%rbx
    558c:	48 39 4a 68          	cmp    %rcx,0x68(%rdx)
    5590:	7f e7                	jg     5579 <fwp_poll_events+0x189>
    5592:	80 7a 55 00          	cmpb   $0x0,0x55(%rdx)
    5596:	74 2e                	je     55c6 <fwp_poll_events+0x1d6>
    5598:	48 8b 82 08 01 00 00 	mov    0x108(%rdx),%rax
    559f:	48 85 c0             	test   %rax,%rax
    55a2:	0f 84 b8 00 00 00    	je     5660 <fwp_poll_events+0x270>
    55a8:	48 89 98 10 01 00 00 	mov    %rbx,0x110(%rax)
    55af:	48 85 db             	test   %rbx,%rbx
    55b2:	74 07                	je     55bb <fwp_poll_events+0x1cb>
    55b4:	48 89 83 08 01 00 00 	mov    %rax,0x108(%rbx)
    55bb:	c6 42 55 00          	movb   $0x0,0x55(%rdx)
    55bf:	0f 11 82 08 01 00 00 	movups %xmm0,0x108(%rdx)
    55c6:	48 8b 42 60          	mov    0x60(%rdx),%rax
    55ca:	c6 42 56 01          	movb   $0x1,0x56(%rdx)
    55ce:	48 85 c0             	test   %rax,%rax
    55d1:	0f 84 69 ff ff ff    	je     5540 <fwp_poll_events+0x150>
    55d7:	48 39 c8             	cmp    %rcx,%rax
    55da:	0f 8f 60 ff ff ff    	jg     5540 <fwp_poll_events+0x150>
    55e0:	80 7a 51 00          	cmpb   $0x0,0x51(%rdx)
    55e4:	0f 85 56 ff ff ff    	jne    5540 <fwp_poll_events+0x150>
    55ea:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    55ee:	75 89                	jne    5579 <fwp_poll_events+0x189>
    55f0:	48 89 d7             	mov    %rdx,%rdi
    55f3:	e8 18 eb ff ff       	call   4110 <fwp_cancel_tree.part.0>
    55f8:	e9 43 ff ff ff       	jmp    5540 <fwp_poll_events+0x150>
    55fd:	0f 1f 00             	nopl   (%rax)
    5600:	b8 c0 6f 90 26       	mov    $0x26906fc0,%eax
    5605:	ba 9b c4 20 00       	mov    $0x20c49b,%edx
    560a:	48 89 e7             	mov    %rsp,%rdi
    560d:	31 f6                	xor    %esi,%esi
    560f:	48 89 14 24          	mov    %rdx,(%rsp)
    5613:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    5618:	e8 73 de ff ff       	call   3490 <nanosleep@plt>
    561d:	48 8b 1d b4 21 06 00 	mov    0x621b4(%rip),%rbx        # 677d8 <fwp_timers>
    5624:	e8 77 ef ff ff       	call   45a0 <fwp_now_ns>
    5629:	48 89 c1             	mov    %rax,%rcx
    562c:	48 85 db             	test   %rbx,%rbx
    562f:	0f 85 03 ff ff ff    	jne    5538 <fwp_poll_events+0x148>
    5635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    563c:	00 00 00 00 
    5640:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    5645:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    564c:	00 00 
    564e:	75 2c                	jne    567c <fwp_poll_events+0x28c>
    5650:	48 83 c4 20          	add    $0x20,%rsp
    5654:	5b                   	pop    %rbx
    5655:	c3                   	ret
    5656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    565d:	00 00 00 
    5660:	48 89 1d 71 21 06 00 	mov    %rbx,0x62171(%rip)        # 677d8 <fwp_timers>
    5667:	e9 43 ff ff ff       	jmp    55af <fwp_poll_events+0x1bf>
    566c:	0f 1f 40 00          	nopl   0x0(%rax)
    5670:	48 89 15 71 21 06 00 	mov    %rdx,0x62171(%rip)        # 677e8 <fwp_ready_head>
    5677:	e9 f6 fe ff ff       	jmp    5572 <fwp_poll_events+0x182>
    567c:	e8 cf dd ff ff       	call   3450 <__stack_chk_fail@plt>
    5681:	0f 1f 40 00          	nopl   0x0(%rax)
    5685:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    568c:	00 00 00 00 

0000000000005690 <fwp_rc_wide_dup>:
    5690:	48 89 fa             	mov    %rdi,%rdx
    5693:	48 8d 35 86 21 06 00 	lea    0x62186(%rip),%rsi        # 67820 <fwp_heap>
    569a:	48 83 ec 18          	sub    $0x18,%rsp
    569e:	48 89 f9             	mov    %rdi,%rcx
    56a1:	48 c1 ea 11          	shr    $0x11,%rdx
    56a5:	48 31 fa             	xor    %rdi,%rdx
    56a8:	48 89 d0             	mov    %rdx,%rax
    56ab:	48 c1 e8 09          	shr    $0x9,%rax
    56af:	48 31 c2             	xor    %rax,%rdx
    56b2:	0f b6 d2             	movzbl %dl,%edx
    56b5:	4c 8d 84 d6 48 14 00 	lea    0x1448(%rsi,%rdx,8),%r8
    56bc:	00 
    56bd:	49 8b 00             	mov    (%r8),%rax
    56c0:	48 83 bc d6 48 14 00 	cmpq   $0x0,0x1448(%rsi,%rdx,8)
    56c7:	00 00 
    56c9:	75 21                	jne    56ec <fwp_rc_wide_dup+0x5c>
    56cb:	e9 98 00 00 00       	jmp    5768 <fwp_rc_wide_dup+0xd8>
    56d0:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    56d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    56dc:	00 00 00 00 
    56e0:	48 8b 50 10          	mov    0x10(%rax),%rdx
    56e4:	48 85 d2             	test   %rdx,%rdx
    56e7:	74 2f                	je     5718 <fwp_rc_wide_dup+0x88>
    56e9:	48 89 d0             	mov    %rdx,%rax
    56ec:	48 3b 08             	cmp    (%rax),%rcx
    56ef:	75 ef                	jne    56e0 <fwp_rc_wide_dup+0x50>
    56f1:	80 39 fe             	cmpb   $0xfe,(%rcx)
    56f4:	74 7c                	je     5772 <fwp_rc_wide_dup+0xe2>
    56f6:	48 8b 50 08          	mov    0x8(%rax),%rdx
    56fa:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
    56fe:	0f 84 91 00 00 00    	je     5795 <fwp_rc_wide_dup+0x105>
    5704:	48 83 c2 01          	add    $0x1,%rdx
    5708:	48 89 50 08          	mov    %rdx,0x8(%rax)
    570c:	48 83 c4 18          	add    $0x18,%rsp
    5710:	c3                   	ret
    5711:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5718:	4c 8d 40 10          	lea    0x10(%rax),%r8
    571c:	80 39 fe             	cmpb   $0xfe,(%rcx)
    571f:	75 68                	jne    5789 <fwp_rc_wide_dup+0xf9>
    5721:	bf 18 00 00 00       	mov    $0x18,%edi
    5726:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    572b:	4c 89 04 24          	mov    %r8,(%rsp)
    572f:	e8 5c de ff ff       	call   3590 <malloc@plt>
    5734:	4c 8b 04 24          	mov    (%rsp),%r8
    5738:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    573d:	48 85 c0             	test   %rax,%rax
    5740:	74 5f                	je     57a1 <fwp_rc_wide_dup+0x111>
    5742:	48 89 08             	mov    %rcx,(%rax)
    5745:	48 c7 40 08 ff 00 00 	movq   $0xff,0x8(%rax)
    574c:	00 
    574d:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
    5754:	00 
    5755:	49 89 00             	mov    %rax,(%r8)
    5758:	c6 01 ff             	movb   $0xff,(%rcx)
    575b:	48 83 05 05 3d 06 00 	addq   $0x1,0x63d05(%rip)        # 69468 <fwp_heap+0x1c48>
    5762:	01 
    5763:	48 83 c4 18          	add    $0x18,%rsp
    5767:	c3                   	ret
    5768:	80 3f fe             	cmpb   $0xfe,(%rdi)
    576b:	75 13                	jne    5780 <fwp_rc_wide_dup+0xf0>
    576d:	48 85 c0             	test   %rax,%rax
    5770:	74 af                	je     5721 <fwp_rc_wide_dup+0x91>
    5772:	48 8d 3d 07 62 00 00 	lea    0x6207(%rip),%rdi        # b980 <_IO_stdin_used+0x980>
    5779:	e8 b2 ec ff ff       	call   4430 <fwp_trap>
    577e:	66 90                	xchg   %ax,%ax
    5780:	48 85 c0             	test   %rax,%rax
    5783:	0f 85 6d ff ff ff    	jne    56f6 <fwp_rc_wide_dup+0x66>
    5789:	48 8d 3d 18 62 00 00 	lea    0x6218(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5790:	e8 9b ec ff ff       	call   4430 <fwp_trap>
    5795:	48 8d 3d f2 59 00 00 	lea    0x59f2(%rip),%rdi        # b18e <_IO_stdin_used+0x18e>
    579c:	e8 8f ec ff ff       	call   4430 <fwp_trap>
    57a1:	e8 6a e6 ff ff       	call   3e10 <fwp_heap_oom>
    57a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57ad:	00 00 00 

00000000000057b0 <fwp_rc_forget_slot>:
    57b0:	80 3f ff             	cmpb   $0xff,(%rdi)
    57b3:	74 0b                	je     57c0 <fwp_rc_forget_slot+0x10>
    57b5:	c3                   	ret
    57b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    57bd:	00 00 00 
    57c0:	48 89 f8             	mov    %rdi,%rax
    57c3:	48 83 ec 08          	sub    $0x8,%rsp
    57c7:	48 89 fa             	mov    %rdi,%rdx
    57ca:	48 c1 e8 11          	shr    $0x11,%rax
    57ce:	48 31 f8             	xor    %rdi,%rax
    57d1:	48 89 c1             	mov    %rax,%rcx
    57d4:	48 c1 e9 09          	shr    $0x9,%rcx
    57d8:	48 31 c8             	xor    %rcx,%rax
    57db:	48 8d 0d 3e 20 06 00 	lea    0x6203e(%rip),%rcx        # 67820 <fwp_heap>
    57e2:	0f b6 c0             	movzbl %al,%eax
    57e5:	48 8b bc c1 48 14 00 	mov    0x1448(%rcx,%rax,8),%rdi
    57ec:	00 
    57ed:	48 85 ff             	test   %rdi,%rdi
    57f0:	74 3c                	je     582e <fwp_rc_forget_slot+0x7e>
    57f2:	48 8d 8c c1 48 14 00 	lea    0x1448(%rcx,%rax,8),%rcx
    57f9:	00 
    57fa:	48 8b 01             	mov    (%rcx),%rax
    57fd:	eb 11                	jmp    5810 <fwp_rc_forget_slot+0x60>
    57ff:	90                   	nop
    5800:	48 8b 78 10          	mov    0x10(%rax),%rdi
    5804:	48 8d 48 10          	lea    0x10(%rax),%rcx
    5808:	48 85 ff             	test   %rdi,%rdi
    580b:	74 21                	je     582e <fwp_rc_forget_slot+0x7e>
    580d:	48 89 f8             	mov    %rdi,%rax
    5810:	48 3b 10             	cmp    (%rax),%rdx
    5813:	75 eb                	jne    5800 <fwp_rc_forget_slot+0x50>
    5815:	48 8b 47 10          	mov    0x10(%rdi),%rax
    5819:	48 89 01             	mov    %rax,(%rcx)
    581c:	e8 8f db ff ff       	call   33b0 <free@plt>
    5821:	48 83 2d 3f 3c 06 00 	subq   $0x1,0x63c3f(%rip)        # 69468 <fwp_heap+0x1c48>
    5828:	01 
    5829:	48 83 c4 08          	add    $0x8,%rsp
    582d:	c3                   	ret
    582e:	48 8d 3d 73 61 00 00 	lea    0x6173(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    5835:	e8 f6 eb ff ff       	call   4430 <fwp_trap>
    583a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005840 <fwp_rc_prepare_chunk>:
    5840:	48 83 3d 20 3c 06 00 	cmpq   $0x0,0x63c20(%rip)        # 69468 <fwp_heap+0x1c48>
    5847:	00 
    5848:	41 54                	push   %r12
    584a:	49 89 f4             	mov    %rsi,%r12
    584d:	55                   	push   %rbp
    584e:	48 89 fd             	mov    %rdi,%rbp
    5851:	53                   	push   %rbx
    5852:	8b 47 1c             	mov    0x1c(%rdi),%eax
    5855:	0f 84 7d 00 00 00    	je     58d8 <fwp_rc_prepare_chunk+0x98>
    585b:	31 db                	xor    %ebx,%ebx
    585d:	85 c0                	test   %eax,%eax
    585f:	75 5f                	jne    58c0 <fwp_rc_prepare_chunk+0x80>
    5861:	48 85 f6             	test   %rsi,%rsi
    5864:	74 7c                	je     58e2 <fwp_rc_prepare_chunk+0xa2>
    5866:	48 8b 7f 20          	mov    0x20(%rdi),%rdi
    586a:	e8 41 db ff ff       	call   33b0 <free@plt>
    586f:	90                   	nop
    5870:	be 01 00 00 00       	mov    $0x1,%esi
    5875:	4c 89 e7             	mov    %r12,%rdi
    5878:	e8 93 dc ff ff       	call   3510 <calloc@plt>
    587d:	48 89 45 20          	mov    %rax,0x20(%rbp)
    5881:	48 85 c0             	test   %rax,%rax
    5884:	0f 85 87 00 00 00    	jne    5911 <fwp_rc_prepare_chunk+0xd1>
    588a:	e8 81 e5 ff ff       	call   3e10 <fwp_heap_oom>
    588f:	90                   	nop
    5890:	e8 1b ff ff ff       	call   57b0 <fwp_rc_forget_slot>
    5895:	8b 45 1c             	mov    0x1c(%rbp),%eax
    5898:	48 83 c3 01          	add    $0x1,%rbx
    589c:	48 39 c3             	cmp    %rax,%rbx
    589f:	73 37                	jae    58d8 <fwp_rc_prepare_chunk+0x98>
    58a1:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58a8:	00 00 
    58aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58b1:	00 00 00 00 
    58b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    58bc:	00 00 00 00 
    58c0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58c4:	48 01 df             	add    %rbx,%rdi
    58c7:	80 3f ff             	cmpb   $0xff,(%rdi)
    58ca:	74 c4                	je     5890 <fwp_rc_prepare_chunk+0x50>
    58cc:	8b 45 1c             	mov    0x1c(%rbp),%eax
    58cf:	48 83 c3 01          	add    $0x1,%rbx
    58d3:	48 39 c3             	cmp    %rax,%rbx
    58d6:	72 e8                	jb     58c0 <fwp_rc_prepare_chunk+0x80>
    58d8:	49 39 c4             	cmp    %rax,%r12
    58db:	75 13                	jne    58f0 <fwp_rc_prepare_chunk+0xb0>
    58dd:	4d 85 e4             	test   %r12,%r12
    58e0:	75 46                	jne    5928 <fwp_rc_prepare_chunk+0xe8>
    58e2:	5b                   	pop    %rbx
    58e3:	5d                   	pop    %rbp
    58e4:	41 5c                	pop    %r12
    58e6:	c3                   	ret
    58e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    58ee:	00 00 
    58f0:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    58f4:	48 29 05 75 3b 06 00 	sub    %rax,0x63b75(%rip)        # 69470 <fwp_heap+0x1c50>
    58fb:	e8 b0 da ff ff       	call   33b0 <free@plt>
    5900:	4d 85 e4             	test   %r12,%r12
    5903:	0f 85 67 ff ff ff    	jne    5870 <fwp_rc_prepare_chunk+0x30>
    5909:	48 c7 45 20 00 00 00 	movq   $0x0,0x20(%rbp)
    5910:	00 
    5911:	44 89 65 1c          	mov    %r12d,0x1c(%rbp)
    5915:	5b                   	pop    %rbx
    5916:	4c 01 25 53 3b 06 00 	add    %r12,0x63b53(%rip)        # 69470 <fwp_heap+0x1c50>
    591d:	5d                   	pop    %rbp
    591e:	41 5c                	pop    %r12
    5920:	c3                   	ret
    5921:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5928:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    592c:	5b                   	pop    %rbx
    592d:	4c 89 e2             	mov    %r12,%rdx
    5930:	31 f6                	xor    %esi,%esi
    5932:	5d                   	pop    %rbp
    5933:	41 5c                	pop    %r12
    5935:	e9 76 db ff ff       	jmp    34b0 <memset@plt>
    593a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000005940 <fwp_heap_refill>:
    5940:	41 56                	push   %r14
    5942:	41 89 d6             	mov    %edx,%r14d
    5945:	41 55                	push   %r13
    5947:	41 89 f5             	mov    %esi,%r13d
    594a:	41 54                	push   %r12
    594c:	49 89 fc             	mov    %rdi,%r12
    594f:	bf 01 00 00 00       	mov    $0x1,%edi
    5954:	55                   	push   %rbp
    5955:	53                   	push   %rbx
    5956:	e8 f5 e4 ff ff       	call   3e50 <fwp_heap_chunks>
    595b:	48 89 c3             	mov    %rax,%rbx
    595e:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    5962:	48 8b 05 af 32 06 00 	mov    0x632af(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    5969:	48 8d 2c d0          	lea    (%rax,%rdx,8),%rbp
    596d:	48 8d 05 ac 1e 06 00 	lea    0x61eac(%rip),%rax        # 67820 <fwp_heap>
    5974:	31 d2                	xor    %edx,%edx
    5976:	44 88 75 01          	mov    %r14b,0x1(%rbp)
    597a:	48 89 ef             	mov    %rbp,%rdi
    597d:	44 88 6d 02          	mov    %r13b,0x2(%rbp)
    5981:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    5985:	42 8b 8c a8 00 0f 00 	mov    0xf00(%rax,%r13,4),%ecx
    598c:	00 
    598d:	b8 00 00 01 00       	mov    $0x10000,%eax
    5992:	f7 f1                	div    %ecx
    5994:	31 d2                	xor    %edx,%edx
    5996:	66 0f 6e c1          	movd   %ecx,%xmm0
    599a:	66 0f 6e c8          	movd   %eax,%xmm1
    599e:	89 c6                	mov    %eax,%esi
    59a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    59a5:	48 01 c8             	add    %rcx,%rax
    59a8:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    59ac:	48 f7 f1             	div    %rcx
    59af:	66 0f d6 45 04       	movq   %xmm0,0x4(%rbp)
    59b4:	89 45 18             	mov    %eax,0x18(%rbp)
    59b7:	e8 84 fe ff ff       	call   5840 <fwp_rc_prepare_chunk>
    59bc:	8b 4d 04             	mov    0x4(%rbp),%ecx
    59bf:	48 89 d8             	mov    %rbx,%rax
    59c2:	48 c1 e0 10          	shl    $0x10,%rax
    59c6:	48 03 05 03 32 06 00 	add    0x63203(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    59cd:	48 8d 14 08          	lea    (%rax,%rcx,1),%rdx
    59d1:	49 89 54 24 08       	mov    %rdx,0x8(%r12)
    59d6:	8b 55 08             	mov    0x8(%rbp),%edx
    59d9:	48 0f af d1          	imul   %rcx,%rdx
    59dd:	48 01 c2             	add    %rax,%rdx
    59e0:	49 89 54 24 10       	mov    %rdx,0x10(%r12)
    59e5:	5b                   	pop    %rbx
    59e6:	5d                   	pop    %rbp
    59e7:	41 5c                	pop    %r12
    59e9:	41 5d                	pop    %r13
    59eb:	41 5e                	pop    %r14
    59ed:	c3                   	ret
    59ee:	66 90                	xchg   %ax,%ax

00000000000059f0 <fwp_mem_free>:
    59f0:	48 85 ff             	test   %rdi,%rdi
    59f3:	0f 84 17 02 00 00    	je     5c10 <fwp_mem_free+0x220>
    59f9:	48 8b 35 d0 31 06 00 	mov    0x631d0(%rip),%rsi        # 68bd0 <fwp_heap+0x13b0>
    5a00:	48 8b 05 f1 31 06 00 	mov    0x631f1(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    5a07:	48 89 fa             	mov    %rdi,%rdx
    5a0a:	48 29 f2             	sub    %rsi,%rdx
    5a0d:	48 c1 e0 10          	shl    $0x10,%rax
    5a11:	48 39 c2             	cmp    %rax,%rdx
    5a14:	0f 83 f6 01 00 00    	jae    5c10 <fwp_mem_free+0x220>
    5a1a:	49 89 d1             	mov    %rdx,%r9
    5a1d:	49 c1 e9 10          	shr    $0x10,%r9
    5a21:	4b 8d 04 89          	lea    (%r9,%r9,4),%rax
    5a25:	48 c1 e0 03          	shl    $0x3,%rax
    5a29:	49 89 c0             	mov    %rax,%r8
    5a2c:	4c 03 05 e5 31 06 00 	add    0x631e5(%rip),%r8        # 68c18 <fwp_heap+0x13f8>
    5a33:	0f 84 d7 01 00 00    	je     5c10 <fwp_mem_free+0x220>
    5a39:	48 83 ec 38          	sub    $0x38,%rsp
    5a3d:	48 89 f9             	mov    %rdi,%rcx
    5a40:	41 0f b6 38          	movzbl (%r8),%edi
    5a44:	40 80 ff 01          	cmp    $0x1,%dil
    5a48:	74 16                	je     5a60 <fwp_mem_free+0x70>
    5a4a:	40 80 ff 02          	cmp    $0x2,%dil
    5a4e:	0f 84 94 00 00 00    	je     5ae8 <fwp_mem_free+0xf8>
    5a54:	48 83 c4 38          	add    $0x38,%rsp
    5a58:	c3                   	ret
    5a59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5a60:	4d 8b 50 20          	mov    0x20(%r8),%r10
    5a64:	41 0f b6 70 01       	movzbl 0x1(%r8),%esi
    5a69:	45 0f b6 48 02       	movzbl 0x2(%r8),%r9d
    5a6e:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a72:	4d 85 d2             	test   %r10,%r10
    5a75:	74 1d                	je     5a94 <fwp_mem_free+0xa4>
    5a77:	0f b7 c1             	movzwl %cx,%eax
    5a7a:	31 d2                	xor    %edx,%edx
    5a7c:	48 f7 f7             	div    %rdi
    5a7f:	49 01 c2             	add    %rax,%r10
    5a82:	41 80 3a ff          	cmpb   $0xff,(%r10)
    5a86:	0f 84 44 01 00 00    	je     5bd0 <fwp_mem_free+0x1e0>
    5a8c:	41 c6 02 00          	movb   $0x0,(%r10)
    5a90:	41 8b 78 04          	mov    0x4(%r8),%edi
    5a94:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5a9b:	49 63 c1             	movslq %r9d,%rax
    5a9e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5aa2:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    5aa6:	f2 48 0f 2a c7       	cvtsi2sd %rdi,%xmm0
    5aab:	f2 0f 58 05 ad 31 06 	addsd  0x631ad(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5ab2:	00 
    5ab3:	48 8d 14 c6          	lea    (%rsi,%rax,8),%rdx
    5ab7:	48 8d 05 62 1d 06 00 	lea    0x61d62(%rip),%rax        # 67820 <fwp_heap>
    5abe:	48 01 d0             	add    %rdx,%rax
    5ac1:	48 8b 10             	mov    (%rax),%rdx
    5ac4:	48 f7 d2             	not    %rdx
    5ac7:	48 89 11             	mov    %rdx,(%rcx)
    5aca:	48 89 08             	mov    %rcx,(%rax)
    5acd:	48 29 3d 6c 31 06 00 	sub    %rdi,0x6316c(%rip)        # 68c40 <fwp_heap+0x1420>
    5ad4:	f2 0f 11 05 84 31 06 	movsd  %xmm0,0x63184(%rip)        # 68c60 <fwp_heap+0x1440>
    5adb:	00 
    5adc:	48 83 c4 38          	add    $0x38,%rsp
    5ae0:	c3                   	ret
    5ae1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ae8:	66 31 d2             	xor    %dx,%dx
    5aeb:	48 01 d6             	add    %rdx,%rsi
    5aee:	48 39 f1             	cmp    %rsi,%rcx
    5af1:	0f 85 5d ff ff ff    	jne    5a54 <fwp_mem_free+0x64>
    5af7:	49 8b 50 10          	mov    0x10(%r8),%rdx
    5afb:	48 29 15 3e 31 06 00 	sub    %rdx,0x6313e(%rip)        # 68c40 <fwp_heap+0x1420>
    5b02:	48 85 d2             	test   %rdx,%rdx
    5b05:	0f 88 a5 00 00 00    	js     5bb0 <fwp_mem_free+0x1c0>
    5b0b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5b0f:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    5b14:	f2 0f 58 05 44 31 06 	addsd  0x63144(%rip),%xmm0        # 68c60 <fwp_heap+0x1440>
    5b1b:	00 
    5b1c:	49 8b 50 20          	mov    0x20(%r8),%rdx
    5b20:	f2 0f 11 05 38 31 06 	movsd  %xmm0,0x63138(%rip)        # 68c60 <fwp_heap+0x1440>
    5b27:	00 
    5b28:	48 85 d2             	test   %rdx,%rdx
    5b2b:	74 0c                	je     5b39 <fwp_mem_free+0x149>
    5b2d:	80 3a ff             	cmpb   $0xff,(%rdx)
    5b30:	0f 84 db 00 00 00    	je     5c11 <fwp_mem_free+0x221>
    5b36:	c6 02 00             	movb   $0x0,(%rdx)
    5b39:	41 8b 48 0c          	mov    0xc(%r8),%ecx
    5b3d:	48 85 c9             	test   %rcx,%rcx
    5b40:	74 3e                	je     5b80 <fwp_mem_free+0x190>
    5b42:	48 8b 15 cf 30 06 00 	mov    0x630cf(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    5b49:	4a 8d 34 09          	lea    (%rcx,%r9,1),%rsi
    5b4d:	48 8d 34 b6          	lea    (%rsi,%rsi,4),%rsi
    5b51:	48 01 d0             	add    %rdx,%rax
    5b54:	48 8d 14 f2          	lea    (%rdx,%rsi,8),%rdx
    5b58:	48 89 d6             	mov    %rdx,%rsi
    5b5b:	48 29 c6             	sub    %rax,%rsi
    5b5e:	83 e6 08             	and    $0x8,%esi
    5b61:	74 0d                	je     5b70 <fwp_mem_free+0x180>
    5b63:	c6 00 00             	movb   $0x0,(%rax)
    5b66:	48 83 c0 28          	add    $0x28,%rax
    5b6a:	48 39 c2             	cmp    %rax,%rdx
    5b6d:	74 11                	je     5b80 <fwp_mem_free+0x190>
    5b6f:	90                   	nop
    5b70:	c6 00 00             	movb   $0x0,(%rax)
    5b73:	48 83 c0 50          	add    $0x50,%rax
    5b77:	c6 40 d8 00          	movb   $0x0,-0x28(%rax)
    5b7b:	48 39 c2             	cmp    %rax,%rdx
    5b7e:	75 f0                	jne    5b70 <fwp_mem_free+0x180>
    5b80:	48 01 0d c9 30 06 00 	add    %rcx,0x630c9(%rip)        # 68c50 <fwp_heap+0x1430>
    5b87:	4c 3b 0d 82 30 06 00 	cmp    0x63082(%rip),%r9        # 68c10 <fwp_heap+0x13f0>
    5b8e:	73 07                	jae    5b97 <fwp_mem_free+0x1a7>
    5b90:	4c 89 0d 79 30 06 00 	mov    %r9,0x63079(%rip)        # 68c10 <fwp_heap+0x13f0>
    5b97:	4c 3b 0d 6a 30 06 00 	cmp    0x6306a(%rip),%r9        # 68c08 <fwp_heap+0x13e8>
    5b9e:	0f 83 b0 fe ff ff    	jae    5a54 <fwp_mem_free+0x64>
    5ba4:	4c 89 0d 5d 30 06 00 	mov    %r9,0x6305d(%rip)        # 68c08 <fwp_heap+0x13e8>
    5bab:	e9 a4 fe ff ff       	jmp    5a54 <fwp_mem_free+0x64>
    5bb0:	48 89 d1             	mov    %rdx,%rcx
    5bb3:	83 e2 01             	and    $0x1,%edx
    5bb6:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5bba:	48 d1 e9             	shr    $1,%rcx
    5bbd:	48 09 d1             	or     %rdx,%rcx
    5bc0:	f2 48 0f 2a c1       	cvtsi2sd %rcx,%xmm0
    5bc5:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    5bc9:	e9 46 ff ff ff       	jmp    5b14 <fwp_mem_free+0x124>
    5bce:	66 90                	xchg   %ax,%ax
    5bd0:	4c 89 d7             	mov    %r10,%rdi
    5bd3:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    5bd8:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
    5bdd:	44 89 4c 24 18       	mov    %r9d,0x18(%rsp)
    5be2:	89 74 24 10          	mov    %esi,0x10(%rsp)
    5be6:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
    5beb:	e8 c0 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5bf0:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    5bf5:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
    5bfa:	44 8b 4c 24 18       	mov    0x18(%rsp),%r9d
    5bff:	48 63 74 24 10       	movslq 0x10(%rsp),%rsi
    5c04:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    5c09:	e9 7e fe ff ff       	jmp    5a8c <fwp_mem_free+0x9c>
    5c0e:	66 90                	xchg   %ax,%ax
    5c10:	c3                   	ret
    5c11:	48 89 d7             	mov    %rdx,%rdi
    5c14:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    5c19:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
    5c1e:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
    5c23:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    5c28:	e8 83 fb ff ff       	call   57b0 <fwp_rc_forget_slot>
    5c2d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    5c32:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
    5c37:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    5c3c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    5c41:	e9 f0 fe ff ff       	jmp    5b36 <fwp_mem_free+0x146>
    5c46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    5c4d:	00 00 00 

0000000000005c50 <fwp_heap_alloc_big>:
    5c50:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
    5c57:	00 00 40 
    5c5a:	41 57                	push   %r15
    5c5c:	41 56                	push   %r14
    5c5e:	41 55                	push   %r13
    5c60:	41 54                	push   %r12
    5c62:	55                   	push   %rbp
    5c63:	53                   	push   %rbx
    5c64:	48 83 ec 08          	sub    $0x8,%rsp
    5c68:	48 39 f8             	cmp    %rdi,%rax
    5c6b:	0f 82 fa 00 00 00    	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5c71:	48 8d af ff ff 00 00 	lea    0xffff(%rdi),%rbp
    5c78:	49 89 fd             	mov    %rdi,%r13
    5c7b:	41 89 f6             	mov    %esi,%r14d
    5c7e:	48 c1 ed 10          	shr    $0x10,%rbp
    5c82:	48 89 ef             	mov    %rbp,%rdi
    5c85:	e8 c6 e1 ff ff       	call   3e50 <fwp_heap_chunks>
    5c8a:	be 01 00 00 00       	mov    $0x1,%esi
    5c8f:	48 8d 1c 80          	lea    (%rax,%rax,4),%rbx
    5c93:	49 89 c4             	mov    %rax,%r12
    5c96:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
    5c9d:	00 
    5c9e:	48 03 3d 73 2f 06 00 	add    0x62f73(%rip),%rdi        # 68c18 <fwp_heap+0x13f8>
    5ca5:	c6 07 02             	movb   $0x2,(%rdi)
    5ca8:	44 88 77 01          	mov    %r14b,0x1(%rdi)
    5cac:	89 6f 0c             	mov    %ebp,0xc(%rdi)
    5caf:	4c 89 6f 10          	mov    %r13,0x10(%rdi)
    5cb3:	e8 88 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cb8:	48 83 fd 01          	cmp    $0x1,%rbp
    5cbc:	76 47                	jbe    5d05 <fwp_heap_alloc_big+0xb5>
    5cbe:	4c 01 e5             	add    %r12,%rbp
    5cc1:	48 8d 1c dd 28 00 00 	lea    0x28(,%rbx,8),%rbx
    5cc8:	00 
    5cc9:	4c 8d 3d 50 1b 06 00 	lea    0x61b50(%rip),%r15        # 67820 <fwp_heap>
    5cd0:	4c 8d 74 ad 00       	lea    0x0(%rbp,%rbp,4),%r14
    5cd5:	49 c1 e6 03          	shl    $0x3,%r14
    5cd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    5ce0:	49 8b af f8 13 00 00 	mov    0x13f8(%r15),%rbp
    5ce7:	31 f6                	xor    %esi,%esi
    5ce9:	48 01 dd             	add    %rbx,%rbp
    5cec:	48 83 c3 28          	add    $0x28,%rbx
    5cf0:	48 89 ef             	mov    %rbp,%rdi
    5cf3:	e8 48 fb ff ff       	call   5840 <fwp_rc_prepare_chunk>
    5cf8:	c6 45 00 03          	movb   $0x3,0x0(%rbp)
    5cfc:	44 89 65 0c          	mov    %r12d,0xc(%rbp)
    5d00:	49 39 de             	cmp    %rbx,%r14
    5d03:	75 db                	jne    5ce0 <fwp_heap_alloc_big+0x90>
    5d05:	49 c1 e4 10          	shl    $0x10,%r12
    5d09:	4c 03 25 c0 2e 06 00 	add    0x62ec0(%rip),%r12        # 68bd0 <fwp_heap+0x13b0>
    5d10:	4c 89 ea             	mov    %r13,%rdx
    5d13:	31 f6                	xor    %esi,%esi
    5d15:	4c 89 e7             	mov    %r12,%rdi
    5d18:	e8 93 d7 ff ff       	call   34b0 <memset@plt>
    5d1d:	4c 89 e8             	mov    %r13,%rax
    5d20:	48 03 05 19 2f 06 00 	add    0x62f19(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5d27:	72 42                	jb     5d6b <fwp_heap_alloc_big+0x11b>
    5d29:	48 39 05 18 2f 06 00 	cmp    %rax,0x62f18(%rip)        # 68c48 <fwp_heap+0x1428>
    5d30:	48 89 05 09 2f 06 00 	mov    %rax,0x62f09(%rip)        # 68c40 <fwp_heap+0x1420>
    5d37:	73 07                	jae    5d40 <fwp_heap_alloc_big+0xf0>
    5d39:	48 89 05 08 2f 06 00 	mov    %rax,0x62f08(%rip)        # 68c48 <fwp_heap+0x1428>
    5d40:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5d44:	4c 89 e0             	mov    %r12,%rax
    5d47:	f2 49 0f 2a c5       	cvtsi2sd %r13,%xmm0
    5d4c:	f2 0f 58 05 04 2f 06 	addsd  0x62f04(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5d53:	00 
    5d54:	f2 0f 11 05 fc 2e 06 	movsd  %xmm0,0x62efc(%rip)        # 68c58 <fwp_heap+0x1438>
    5d5b:	00 
    5d5c:	48 83 c4 08          	add    $0x8,%rsp
    5d60:	5b                   	pop    %rbx
    5d61:	5d                   	pop    %rbp
    5d62:	41 5c                	pop    %r12
    5d64:	41 5d                	pop    %r13
    5d66:	41 5e                	pop    %r14
    5d68:	41 5f                	pop    %r15
    5d6a:	c3                   	ret
    5d6b:	e8 a0 e0 ff ff       	call   3e10 <fwp_heap_oom>

0000000000005d70 <fwp_heap_alloc_slow>:
    5d70:	53                   	push   %rbx
    5d71:	48 89 f9             	mov    %rdi,%rcx
    5d74:	41 89 f1             	mov    %esi,%r9d
    5d77:	48 83 ec 10          	sub    $0x10,%rsp
    5d7b:	8b 05 43 2e 06 00    	mov    0x62e43(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5d81:	85 c0                	test   %eax,%eax
    5d83:	0f 84 c7 00 00 00    	je     5e50 <fwp_heap_alloc_slow+0xe0>
    5d89:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5d90:	0f 87 dd 00 00 00    	ja     5e73 <fwp_heap_alloc_slow+0x103>
    5d96:	48 8d 41 0f          	lea    0xf(%rcx),%rax
    5d9a:	48 8d 3d 7f 1a 06 00 	lea    0x61a7f(%rip),%rdi        # 67820 <fwp_heap>
    5da1:	49 63 f1             	movslq %r9d,%rsi
    5da4:	48 c1 e8 04          	shr    $0x4,%rax
    5da8:	44 0f b6 94 07 a0 0f 	movzbl 0xfa0(%rdi,%rax,1),%r10d
    5daf:	00 00 
    5db1:	41 0f b6 c2          	movzbl %r10b,%eax
    5db5:	4c 89 d2             	mov    %r10,%rdx
    5db8:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
    5dbc:	8b 9c 87 00 0f 00 00 	mov    0xf00(%rdi,%rax,4),%ebx
    5dc3:	48 69 c6 c0 03 00 00 	imul   $0x3c0,%rsi,%rax
    5dca:	4a 8d 04 c0          	lea    (%rax,%r8,8),%rax
    5dce:	48 01 f8             	add    %rdi,%rax
    5dd1:	4c 8b 00             	mov    (%rax),%r8
    5dd4:	4d 85 c0             	test   %r8,%r8
    5dd7:	0f 84 ab 00 00 00    	je     5e88 <fwp_heap_alloc_slow+0x118>
    5ddd:	49 8b 10             	mov    (%r8),%rdx
    5de0:	48 f7 d2             	not    %rdx
    5de3:	48 89 10             	mov    %rdx,(%rax)
    5de6:	41 83 f9 01          	cmp    $0x1,%r9d
    5dea:	4c 89 c7             	mov    %r8,%rdi
    5ded:	48 0f 45 cb          	cmovne %rbx,%rcx
    5df1:	31 f6                	xor    %esi,%esi
    5df3:	48 89 ca             	mov    %rcx,%rdx
    5df6:	e8 b5 d6 ff ff       	call   34b0 <memset@plt>
    5dfb:	49 89 c0             	mov    %rax,%r8
    5dfe:	48 89 d8             	mov    %rbx,%rax
    5e01:	48 03 05 38 2e 06 00 	add    0x62e38(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5e08:	0f 82 d9 00 00 00    	jb     5ee7 <fwp_heap_alloc_slow+0x177>
    5e0e:	48 39 05 33 2e 06 00 	cmp    %rax,0x62e33(%rip)        # 68c48 <fwp_heap+0x1428>
    5e15:	48 89 05 24 2e 06 00 	mov    %rax,0x62e24(%rip)        # 68c40 <fwp_heap+0x1420>
    5e1c:	73 07                	jae    5e25 <fwp_heap_alloc_slow+0xb5>
    5e1e:	48 89 05 23 2e 06 00 	mov    %rax,0x62e23(%rip)        # 68c48 <fwp_heap+0x1428>
    5e25:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5e29:	4c 89 c0             	mov    %r8,%rax
    5e2c:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
    5e31:	f2 0f 58 05 1f 2e 06 	addsd  0x62e1f(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5e38:	00 
    5e39:	f2 0f 11 05 17 2e 06 	movsd  %xmm0,0x62e17(%rip)        # 68c58 <fwp_heap+0x1438>
    5e40:	00 
    5e41:	48 83 c4 10          	add    $0x10,%rsp
    5e45:	5b                   	pop    %rbx
    5e46:	c3                   	ret
    5e47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    5e4e:	00 00 
    5e50:	89 74 24 08          	mov    %esi,0x8(%rsp)
    5e54:	48 89 3c 24          	mov    %rdi,(%rsp)
    5e58:	e8 53 ef ff ff       	call   4db0 <fwp_heap_init>
    5e5d:	48 8b 0c 24          	mov    (%rsp),%rcx
    5e61:	44 8b 4c 24 08       	mov    0x8(%rsp),%r9d
    5e66:	48 81 f9 00 40 00 00 	cmp    $0x4000,%rcx
    5e6d:	0f 86 23 ff ff ff    	jbe    5d96 <fwp_heap_alloc_slow+0x26>
    5e73:	48 83 c4 10          	add    $0x10,%rsp
    5e77:	44 89 ce             	mov    %r9d,%esi
    5e7a:	48 89 cf             	mov    %rcx,%rdi
    5e7d:	5b                   	pop    %rbx
    5e7e:	e9 cd fd ff ff       	jmp    5c50 <fwp_heap_alloc_big>
    5e83:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    5e88:	4c 8b 40 08          	mov    0x8(%rax),%r8
    5e8c:	4d 85 c0             	test   %r8,%r8
    5e8f:	74 1f                	je     5eb0 <fwp_heap_alloc_slow+0x140>
    5e91:	4c 8b 58 10          	mov    0x10(%rax),%r11
    5e95:	4d 29 c3             	sub    %r8,%r11
    5e98:	49 39 db             	cmp    %rbx,%r11
    5e9b:	72 13                	jb     5eb0 <fwp_heap_alloc_slow+0x140>
    5e9d:	49 8d 14 18          	lea    (%r8,%rbx,1),%rdx
    5ea1:	48 89 50 08          	mov    %rdx,0x8(%rax)
    5ea5:	e9 3c ff ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    5eb0:	48 69 f6 c0 03 00 00 	imul   $0x3c0,%rsi,%rsi
    5eb7:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
    5ebb:	44 89 ca             	mov    %r9d,%edx
    5ebe:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    5ec3:	44 89 0c 24          	mov    %r9d,(%rsp)
    5ec7:	48 8d 04 c6          	lea    (%rsi,%rax,8),%rax
    5ecb:	44 89 d6             	mov    %r10d,%esi
    5ece:	48 01 c7             	add    %rax,%rdi
    5ed1:	e8 6a fa ff ff       	call   5940 <fwp_heap_refill>
    5ed6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    5edb:	44 8b 0c 24          	mov    (%rsp),%r9d
    5edf:	49 89 c0             	mov    %rax,%r8
    5ee2:	e9 ff fe ff ff       	jmp    5de6 <fwp_heap_alloc_slow+0x76>
    5ee7:	e8 24 df ff ff       	call   3e10 <fwp_heap_oom>
    5eec:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000005ef0 <fwp_heap_alloc>:
    5ef0:	53                   	push   %rbx
    5ef1:	48 89 fa             	mov    %rdi,%rdx
    5ef4:	48 83 ec 10          	sub    $0x10,%rsp
    5ef8:	8b 1d ea 35 06 00    	mov    0x635ea(%rip),%ebx        # 694e8 <iteration_active>
    5efe:	8b 05 c0 2c 06 00    	mov    0x62cc0(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    5f04:	85 db                	test   %ebx,%ebx
    5f06:	0f 85 04 01 00 00    	jne    6010 <fwp_heap_alloc+0x120>
    5f0c:	85 c0                	test   %eax,%eax
    5f0e:	0f 84 ac 01 00 00    	je     60c0 <fwp_heap_alloc+0x1d0>
    5f14:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    5f1b:	0f 87 9f 01 00 00    	ja     60c0 <fwp_heap_alloc+0x1d0>
    5f21:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    5f25:	48 8d 05 f4 18 06 00 	lea    0x618f4(%rip),%rax        # 67820 <fwp_heap>
    5f2c:	48 c1 e9 04          	shr    $0x4,%rcx
    5f30:	0f b6 bc 08 a0 0f 00 	movzbl 0xfa0(%rax,%rcx,1),%edi
    5f37:	00 
    5f38:	48 63 ce             	movslq %esi,%rcx
    5f3b:	48 69 c9 c0 03 00 00 	imul   $0x3c0,%rcx,%rcx
    5f42:	44 8b 84 b8 00 0f 00 	mov    0xf00(%rax,%rdi,4),%r8d
    5f49:	00 
    5f4a:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
    5f4e:	48 8d 0c f9          	lea    (%rcx,%rdi,8),%rcx
    5f52:	48 01 c8             	add    %rcx,%rax
    5f55:	48 8b 08             	mov    (%rax),%rcx
    5f58:	48 85 c9             	test   %rcx,%rcx
    5f5b:	0f 84 ff 00 00 00    	je     6060 <fwp_heap_alloc+0x170>
    5f61:	48 8b 39             	mov    (%rcx),%rdi
    5f64:	48 f7 d7             	not    %rdi
    5f67:	48 89 38             	mov    %rdi,(%rax)
    5f6a:	83 fe 01             	cmp    $0x1,%esi
    5f6d:	48 89 cf             	mov    %rcx,%rdi
    5f70:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    5f75:	49 0f 45 d0          	cmovne %r8,%rdx
    5f79:	31 f6                	xor    %esi,%esi
    5f7b:	e8 30 d5 ff ff       	call   34b0 <memset@plt>
    5f80:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    5f85:	48 89 c1             	mov    %rax,%rcx
    5f88:	4c 89 c0             	mov    %r8,%rax
    5f8b:	48 03 05 ae 2c 06 00 	add    0x62cae(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5f92:	0f 82 35 01 00 00    	jb     60cd <fwp_heap_alloc+0x1dd>
    5f98:	48 39 05 a9 2c 06 00 	cmp    %rax,0x62ca9(%rip)        # 68c48 <fwp_heap+0x1428>
    5f9f:	48 89 05 9a 2c 06 00 	mov    %rax,0x62c9a(%rip)        # 68c40 <fwp_heap+0x1420>
    5fa6:	73 07                	jae    5faf <fwp_heap_alloc+0xbf>
    5fa8:	48 89 05 99 2c 06 00 	mov    %rax,0x62c99(%rip)        # 68c48 <fwp_heap+0x1428>
    5faf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fb3:	f2 49 0f 2a c0       	cvtsi2sd %r8,%xmm0
    5fb8:	f2 0f 58 05 98 2c 06 	addsd  0x62c98(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    5fbf:	00 
    5fc0:	f2 0f 11 05 90 2c 06 	movsd  %xmm0,0x62c90(%rip)        # 68c58 <fwp_heap+0x1438>
    5fc7:	00 
    5fc8:	85 db                	test   %ebx,%ebx
    5fca:	74 33                	je     5fff <fwp_heap_alloc+0x10f>
    5fcc:	48 8b 05 6d 2c 06 00 	mov    0x62c6d(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    5fd3:	48 85 c0             	test   %rax,%rax
    5fd6:	0f 88 ac 00 00 00    	js     6088 <fwp_heap_alloc+0x198>
    5fdc:	66 0f ef c0          	pxor   %xmm0,%xmm0
    5fe0:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    5fe5:	f2 0f 5c 05 db 34 06 	subsd  0x634db(%rip),%xmm0        # 694c8 <iteration_start_charge>
    5fec:	00 
    5fed:	66 0f 2f 05 cb 34 06 	comisd 0x634cb(%rip),%xmm0        # 694c0 <iteration_peak>
    5ff4:	00 
    5ff5:	76 08                	jbe    5fff <fwp_heap_alloc+0x10f>
    5ff7:	f2 0f 11 05 c1 34 06 	movsd  %xmm0,0x634c1(%rip)        # 694c0 <iteration_peak>
    5ffe:	00 
    5fff:	48 83 c4 10          	add    $0x10,%rsp
    6003:	48 89 c8             	mov    %rcx,%rax
    6006:	5b                   	pop    %rbx
    6007:	c3                   	ret
    6008:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    600f:	00 
    6010:	85 f6                	test   %esi,%esi
    6012:	74 34                	je     6048 <fwp_heap_alloc+0x158>
    6014:	48 83 05 c4 34 06 00 	addq   $0x1,0x634c4(%rip)        # 694e0 <iteration_requests>
    601b:	01 
    601c:	48 01 3d b5 34 06 00 	add    %rdi,0x634b5(%rip)        # 694d8 <iteration_bytes>
    6023:	85 c0                	test   %eax,%eax
    6025:	74 0d                	je     6034 <fwp_heap_alloc+0x144>
    6027:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    602e:	0f 86 ed fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6034:	48 89 d7             	mov    %rdx,%rdi
    6037:	e8 34 fd ff ff       	call   5d70 <fwp_heap_alloc_slow>
    603c:	48 89 c1             	mov    %rax,%rcx
    603f:	eb 8b                	jmp    5fcc <fwp_heap_alloc+0xdc>
    6041:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6048:	85 c0                	test   %eax,%eax
    604a:	74 0d                	je     6059 <fwp_heap_alloc+0x169>
    604c:	48 81 ff 00 40 00 00 	cmp    $0x4000,%rdi
    6053:	0f 86 c8 fe ff ff    	jbe    5f21 <fwp_heap_alloc+0x31>
    6059:	31 f6                	xor    %esi,%esi
    605b:	eb d7                	jmp    6034 <fwp_heap_alloc+0x144>
    605d:	0f 1f 00             	nopl   (%rax)
    6060:	48 8b 48 08          	mov    0x8(%rax),%rcx
    6064:	48 85 c9             	test   %rcx,%rcx
    6067:	74 0c                	je     6075 <fwp_heap_alloc+0x185>
    6069:	48 8b 78 10          	mov    0x10(%rax),%rdi
    606d:	48 29 cf             	sub    %rcx,%rdi
    6070:	4c 39 c7             	cmp    %r8,%rdi
    6073:	73 3b                	jae    60b0 <fwp_heap_alloc+0x1c0>
    6075:	48 89 d7             	mov    %rdx,%rdi
    6078:	e8 f3 fc ff ff       	call   5d70 <fwp_heap_alloc_slow>
    607d:	48 89 c1             	mov    %rax,%rcx
    6080:	e9 43 ff ff ff       	jmp    5fc8 <fwp_heap_alloc+0xd8>
    6085:	0f 1f 00             	nopl   (%rax)
    6088:	48 89 c2             	mov    %rax,%rdx
    608b:	83 e0 01             	and    $0x1,%eax
    608e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6092:	48 d1 ea             	shr    $1,%rdx
    6095:	48 09 c2             	or     %rax,%rdx
    6098:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    609d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    60a1:	e9 3f ff ff ff       	jmp    5fe5 <fwp_heap_alloc+0xf5>
    60a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    60ad:	00 00 00 
    60b0:	4a 8d 3c 01          	lea    (%rcx,%r8,1),%rdi
    60b4:	48 89 78 08          	mov    %rdi,0x8(%rax)
    60b8:	e9 ad fe ff ff       	jmp    5f6a <fwp_heap_alloc+0x7a>
    60bd:	0f 1f 00             	nopl   (%rax)
    60c0:	48 83 c4 10          	add    $0x10,%rsp
    60c4:	48 89 d7             	mov    %rdx,%rdi
    60c7:	5b                   	pop    %rbx
    60c8:	e9 a3 fc ff ff       	jmp    5d70 <fwp_heap_alloc_slow>
    60cd:	e8 3e dd ff ff       	call   3e10 <fwp_heap_oom>
    60d2:	0f 1f 00             	nopl   (%rax)
    60d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    60dc:	00 00 00 00 

00000000000060e0 <fwp_data.part.0.constprop.0>:
    60e0:	41 56                	push   %r14
    60e2:	8b 05 dc 2a 06 00    	mov    0x62adc(%rip),%eax        # 68bc4 <fwp_heap+0x13a4>
    60e8:	41 89 fe             	mov    %edi,%r14d
    60eb:	41 55                	push   %r13
    60ed:	44 8b 2d f4 33 06 00 	mov    0x633f4(%rip),%r13d        # 694e8 <iteration_active>
    60f4:	41 54                	push   %r12
    60f6:	49 89 f4             	mov    %rsi,%r12
    60f9:	55                   	push   %rbp
    60fa:	53                   	push   %rbx
    60fb:	45 85 ed             	test   %r13d,%r13d
    60fe:	0f 84 1c 01 00 00    	je     6220 <fwp_data.part.0.constprop.0+0x140>
    6104:	48 83 05 d4 33 06 00 	addq   $0x1,0x633d4(%rip)        # 694e0 <iteration_requests>
    610b:	01 
    610c:	48 83 05 c4 33 06 00 	addq   $0x18,0x633c4(%rip)        # 694d8 <iteration_bytes>
    6113:	18 
    6114:	85 c0                	test   %eax,%eax
    6116:	0f 84 8c 01 00 00    	je     62a8 <fwp_data.part.0.constprop.0+0x1c8>
    611c:	0f b6 05 9f 26 06 00 	movzbl 0x6269f(%rip),%eax        # 687c2 <fwp_heap+0xfa2>
    6123:	48 8d 15 f6 16 06 00 	lea    0x616f6(%rip),%rdx        # 67820 <fwp_heap>
    612a:	8b ac 82 00 0f 00 00 	mov    0xf00(%rdx,%rax,4),%ebp
    6131:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
    6135:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
    6139:	48 8b 18             	mov    (%rax),%rbx
    613c:	48 85 db             	test   %rbx,%rbx
    613f:	0f 84 fb 00 00 00    	je     6240 <fwp_data.part.0.constprop.0+0x160>
    6145:	48 8b 13             	mov    (%rbx),%rdx
    6148:	48 f7 d2             	not    %rdx
    614b:	48 89 10             	mov    %rdx,(%rax)
    614e:	48 83 fd 18          	cmp    $0x18,%rbp
    6152:	76 1b                	jbe    616f <fwp_data.part.0.constprop.0+0x8f>
    6154:	48 8d 45 e7          	lea    -0x19(%rbp),%rax
    6158:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
    615c:	31 f6                	xor    %esi,%esi
    615e:	48 c1 e8 03          	shr    $0x3,%rax
    6162:	48 8d 14 c5 08 00 00 	lea    0x8(,%rax,8),%rdx
    6169:	00 
    616a:	e8 41 d3 ff ff       	call   34b0 <memset@plt>
    616f:	48 89 e8             	mov    %rbp,%rax
    6172:	48 03 05 c7 2a 06 00 	add    0x62ac7(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    6179:	0f 82 3d 01 00 00    	jb     62bc <fwp_data.part.0.constprop.0+0x1dc>
    617f:	48 39 05 c2 2a 06 00 	cmp    %rax,0x62ac2(%rip)        # 68c48 <fwp_heap+0x1428>
    6186:	48 89 05 b3 2a 06 00 	mov    %rax,0x62ab3(%rip)        # 68c40 <fwp_heap+0x1420>
    618d:	73 07                	jae    6196 <fwp_data.part.0.constprop.0+0xb6>
    618f:	48 89 05 b2 2a 06 00 	mov    %rax,0x62ab2(%rip)        # 68c48 <fwp_heap+0x1428>
    6196:	66 0f ef c0          	pxor   %xmm0,%xmm0
    619a:	f2 48 0f 2a c5       	cvtsi2sd %rbp,%xmm0
    619f:	f2 0f 58 05 b1 2a 06 	addsd  0x62ab1(%rip),%xmm0        # 68c58 <fwp_heap+0x1438>
    61a6:	00 
    61a7:	f2 0f 11 05 a9 2a 06 	movsd  %xmm0,0x62aa9(%rip)        # 68c58 <fwp_heap+0x1438>
    61ae:	00 
    61af:	45 85 ed             	test   %r13d,%r13d
    61b2:	74 33                	je     61e7 <fwp_data.part.0.constprop.0+0x107>
    61b4:	48 8b 05 85 2a 06 00 	mov    0x62a85(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    61bb:	48 85 c0             	test   %rax,%rax
    61be:	0f 88 a4 00 00 00    	js     6268 <fwp_data.part.0.constprop.0+0x188>
    61c4:	66 0f ef c0          	pxor   %xmm0,%xmm0
    61c8:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    61cd:	f2 0f 5c 05 f3 32 06 	subsd  0x632f3(%rip),%xmm0        # 694c8 <iteration_start_charge>
    61d4:	00 
    61d5:	66 0f 2f 05 e3 32 06 	comisd 0x632e3(%rip),%xmm0        # 694c0 <iteration_peak>
    61dc:	00 
    61dd:	76 08                	jbe    61e7 <fwp_data.part.0.constprop.0+0x107>
    61df:	f2 0f 11 05 d9 32 06 	movsd  %xmm0,0x632d9(%rip)        # 694c0 <iteration_peak>
    61e6:	00 
    61e7:	b8 02 00 00 00       	mov    $0x2,%eax
    61ec:	66 41 0f 6e c6       	movd   %r14d,%xmm0
    61f1:	66 0f 6e c8          	movd   %eax,%xmm1
    61f5:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
    61f9:	66 0f d6 03          	movq   %xmm0,(%rbx)
    61fd:	49 8b 04 24          	mov    (%r12),%rax
    6201:	48 89 43 08          	mov    %rax,0x8(%rbx)
    6205:	49 8b 44 24 08       	mov    0x8(%r12),%rax
    620a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    620e:	48 89 d8             	mov    %rbx,%rax
    6211:	5b                   	pop    %rbx
    6212:	5d                   	pop    %rbp
    6213:	41 5c                	pop    %r12
    6215:	41 5d                	pop    %r13
    6217:	41 5e                	pop    %r14
    6219:	c3                   	ret
    621a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6220:	85 c0                	test   %eax,%eax
    6222:	0f 85 f4 fe ff ff    	jne    611c <fwp_data.part.0.constprop.0+0x3c>
    6228:	31 f6                	xor    %esi,%esi
    622a:	bf 18 00 00 00       	mov    $0x18,%edi
    622f:	e8 bc fc ff ff       	call   5ef0 <fwp_heap_alloc>
    6234:	48 89 c3             	mov    %rax,%rbx
    6237:	eb ae                	jmp    61e7 <fwp_data.part.0.constprop.0+0x107>
    6239:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6240:	48 8b 58 08          	mov    0x8(%rax),%rbx
    6244:	48 85 db             	test   %rbx,%rbx
    6247:	74 47                	je     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6249:	48 8b 50 10          	mov    0x10(%rax),%rdx
    624d:	48 29 da             	sub    %rbx,%rdx
    6250:	48 39 ea             	cmp    %rbp,%rdx
    6253:	72 3b                	jb     6290 <fwp_data.part.0.constprop.0+0x1b0>
    6255:	48 8d 14 2b          	lea    (%rbx,%rbp,1),%rdx
    6259:	48 89 50 08          	mov    %rdx,0x8(%rax)
    625d:	e9 ec fe ff ff       	jmp    614e <fwp_data.part.0.constprop.0+0x6e>
    6262:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6268:	48 89 c2             	mov    %rax,%rdx
    626b:	83 e0 01             	and    $0x1,%eax
    626e:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6272:	48 d1 ea             	shr    $1,%rdx
    6275:	48 09 c2             	or     %rax,%rdx
    6278:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    627d:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    6281:	e9 47 ff ff ff       	jmp    61cd <fwp_data.part.0.constprop.0+0xed>
    6286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    628d:	00 00 00 
    6290:	31 f6                	xor    %esi,%esi
    6292:	bf 18 00 00 00       	mov    $0x18,%edi
    6297:	e8 54 fc ff ff       	call   5ef0 <fwp_heap_alloc>
    629c:	48 89 c3             	mov    %rax,%rbx
    629f:	e9 0b ff ff ff       	jmp    61af <fwp_data.part.0.constprop.0+0xcf>
    62a4:	0f 1f 40 00          	nopl   0x0(%rax)
    62a8:	31 f6                	xor    %esi,%esi
    62aa:	bf 18 00 00 00       	mov    $0x18,%edi
    62af:	e8 3c fc ff ff       	call   5ef0 <fwp_heap_alloc>
    62b4:	48 89 c3             	mov    %rax,%rbx
    62b7:	e9 f8 fe ff ff       	jmp    61b4 <fwp_data.part.0.constprop.0+0xd4>
    62bc:	e8 4f db ff ff       	call   3e10 <fwp_heap_oom>
    62c1:	0f 1f 40 00          	nopl   0x0(%rax)
    62c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    62cc:	00 00 00 00 

00000000000062d0 <fwp_tape_reserve>:
    62d0:	41 57                	push   %r15
    62d2:	41 56                	push   %r14
    62d4:	41 55                	push   %r13
    62d6:	41 54                	push   %r12
    62d8:	55                   	push   %rbp
    62d9:	53                   	push   %rbx
    62da:	48 83 ec 18          	sub    $0x18,%rsp
    62de:	48 81 fe ff ff ff 7f 	cmp    $0x7fffffff,%rsi
    62e5:	0f 87 cd 01 00 00    	ja     64b8 <fwp_tape_reserve+0x1e8>
    62eb:	48 8b 5f 18          	mov    0x18(%rdi),%rbx
    62ef:	48 89 fd             	mov    %rdi,%rbp
    62f2:	48 39 f3             	cmp    %rsi,%rbx
    62f5:	0f 8d 18 01 00 00    	jge    6413 <fwp_tape_reserve+0x143>
    62fb:	48 85 db             	test   %rbx,%rbx
    62fe:	b8 40 00 00 00       	mov    $0x40,%eax
    6303:	48 0f 44 d8          	cmove  %rax,%rbx
    6307:	48 39 f3             	cmp    %rsi,%rbx
    630a:	7d 24                	jge    6330 <fwp_tape_reserve+0x60>
    630c:	48 81 fb ff ff ff 3f 	cmp    $0x3fffffff,%rbx
    6313:	0f 8f 0f 01 00 00    	jg     6428 <fwp_tape_reserve+0x158>
    6319:	48 01 db             	add    %rbx,%rbx
    631c:	48 39 f3             	cmp    %rsi,%rbx
    631f:	7c eb                	jl     630c <fwp_tape_reserve+0x3c>
    6321:	0f 1f 40 00          	nopl   0x0(%rax)
    6325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    632c:	00 00 00 00 
    6330:	4c 8d 2c dd 00 00 00 	lea    0x0(,%rbx,8),%r13
    6337:	00 
    6338:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    633c:	ba 01 00 00 00       	mov    $0x1,%edx
    6341:	4c 8b 75 60          	mov    0x60(%rbp),%r14
    6345:	4c 89 ee             	mov    %r13,%rsi
    6348:	4c 8b 65 10          	mov    0x10(%rbp),%r12
    634c:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
    6350:	e8 1b ee ff ff       	call   5170 <ad_raw_realloc>
    6355:	48 85 c0             	test   %rax,%rax
    6358:	0f 84 66 01 00 00    	je     64c4 <fwp_tape_reserve+0x1f4>
    635e:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    6362:	48 89 45 20          	mov    %rax,0x20(%rbp)
    6366:	4d 29 fc             	sub    %r15,%r12
    6369:	48 8d 14 90          	lea    (%rax,%rdx,4),%rdx
    636d:	48 89 55 28          	mov    %rdx,0x28(%rbp)
    6371:	4d 85 f6             	test   %r14,%r14
    6374:	0f 84 f6 00 00 00    	je     6470 <fwp_tape_reserve+0x1a0>
    637a:	49 8b 56 60          	mov    0x60(%r14),%rdx
    637e:	48 39 da             	cmp    %rbx,%rdx
    6381:	7d 78                	jge    63fb <fwp_tape_reserve+0x12b>
    6383:	48 89 d9             	mov    %rbx,%rcx
    6386:	4d 8b 7e 40          	mov    0x40(%r14),%r15
    638a:	be 02 00 00 00       	mov    $0x2,%esi
    638f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    6394:	48 c1 e1 04          	shl    $0x4,%rcx
    6398:	48 89 cf             	mov    %rcx,%rdi
    639b:	48 89 0c 24          	mov    %rcx,(%rsp)
    639f:	e8 4c fb ff ff       	call   5ef0 <fwp_heap_alloc>
    63a4:	49 89 c5             	mov    %rax,%r13
    63a7:	4d 85 ff             	test   %r15,%r15
    63aa:	74 27                	je     63d3 <fwp_tape_reserve+0x103>
    63ac:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    63b1:	48 8b 0c 24          	mov    (%rsp),%rcx
    63b5:	48 89 c7             	mov    %rax,%rdi
    63b8:	4c 89 fe             	mov    %r15,%rsi
    63bb:	48 c1 e2 04          	shl    $0x4,%rdx
    63bf:	48 39 ca             	cmp    %rcx,%rdx
    63c2:	48 0f 47 d1          	cmova  %rcx,%rdx
    63c6:	e8 b5 d1 ff ff       	call   3580 <memcpy@plt>
    63cb:	4c 89 ff             	mov    %r15,%rdi
    63ce:	e8 1d f6 ff ff       	call   59f0 <fwp_mem_free>
    63d3:	49 8b 7e 60          	mov    0x60(%r14),%rdi
    63d7:	48 89 da             	mov    %rbx,%rdx
    63da:	31 f6                	xor    %esi,%esi
    63dc:	48 29 fa             	sub    %rdi,%rdx
    63df:	48 c1 e7 04          	shl    $0x4,%rdi
    63e3:	48 c1 e2 04          	shl    $0x4,%rdx
    63e7:	4c 01 ef             	add    %r13,%rdi
    63ea:	e8 c1 d0 ff ff       	call   34b0 <memset@plt>
    63ef:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    63f3:	48 8b 45 20          	mov    0x20(%rbp),%rax
    63f7:	49 89 5e 60          	mov    %rbx,0x60(%r14)
    63fb:	4d 85 e4             	test   %r12,%r12
    63fe:	75 4b                	jne    644b <fwp_tape_reserve+0x17b>
    6400:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6407:	00 
    6408:	4c 01 e8             	add    %r13,%rax
    640b:	48 89 5d 18          	mov    %rbx,0x18(%rbp)
    640f:	48 89 45 28          	mov    %rax,0x28(%rbp)
    6413:	48 83 c4 18          	add    $0x18,%rsp
    6417:	5b                   	pop    %rbx
    6418:	5d                   	pop    %rbp
    6419:	41 5c                	pop    %r12
    641b:	41 5d                	pop    %r13
    641d:	41 5e                	pop    %r14
    641f:	41 5f                	pop    %r15
    6421:	c3                   	ret
    6422:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6428:	bb ff ff ff 7f       	mov    $0x7fffffff,%ebx
    642d:	e9 fe fe ff ff       	jmp    6330 <fwp_tape_reserve+0x60>
    6432:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
    6439:	00 
    643a:	e8 b1 d1 ff ff       	call   35f0 <memmove@plt>
    643f:	4c 03 6d 30          	add    0x30(%rbp),%r13
    6443:	48 8b 45 20          	mov    0x20(%rbp),%rax
    6447:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
    644b:	48 8b 75 28          	mov    0x28(%rbp),%rsi
    644f:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    6456:	00 
    6457:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
    645e:	00 
    645f:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6463:	e8 88 d1 ff ff       	call   35f0 <memmove@plt>
    6468:	48 8b 45 20          	mov    0x20(%rbp),%rax
    646c:	eb 9a                	jmp    6408 <fwp_tape_reserve+0x138>
    646e:	66 90                	xchg   %ax,%ax
    6470:	48 89 de             	mov    %rbx,%rsi
    6473:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    6477:	ba 02 00 00 00       	mov    $0x2,%edx
    647c:	48 c1 e6 04          	shl    $0x4,%rsi
    6480:	e8 eb ec ff ff       	call   5170 <ad_raw_realloc>
    6485:	48 85 c0             	test   %rax,%rax
    6488:	74 3a                	je     64c4 <fwp_tape_reserve+0x1f4>
    648a:	48 8b 55 18          	mov    0x18(%rbp),%rdx
    648e:	48 89 45 30          	mov    %rax,0x30(%rbp)
    6492:	4a 8d 3c 28          	lea    (%rax,%r13,1),%rdi
    6496:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
    649a:	48 89 75 38          	mov    %rsi,0x38(%rbp)
    649e:	4d 85 e4             	test   %r12,%r12
    64a1:	75 8f                	jne    6432 <fwp_tape_reserve+0x162>
    64a3:	48 89 7d 38          	mov    %rdi,0x38(%rbp)
    64a7:	48 8b 45 20          	mov    0x20(%rbp),%rax
    64ab:	4c 8d 2c 9d 00 00 00 	lea    0x0(,%rbx,4),%r13
    64b2:	00 
    64b3:	e9 50 ff ff ff       	jmp    6408 <fwp_tape_reserve+0x138>
    64b8:	48 8d 3d e8 4c 00 00 	lea    0x4ce8(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    64bf:	e8 6c df ff ff       	call   4430 <fwp_trap>
    64c4:	48 89 ef             	mov    %rbp,%rdi
    64c7:	e8 a4 d7 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    64cc:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
    64d0:	48 85 ff             	test   %rdi,%rdi
    64d3:	74 05                	je     64da <fwp_tape_reserve+0x20a>
    64d5:	e8 d6 eb ff ff       	call   50b0 <ad_raw_free.part.0>
    64da:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
    64de:	48 85 ff             	test   %rdi,%rdi
    64e1:	74 05                	je     64e8 <fwp_tape_reserve+0x218>
    64e3:	e8 c8 eb ff ff       	call   50b0 <ad_raw_free.part.0>
    64e8:	48 8b 7d 40          	mov    0x40(%rbp),%rdi
    64ec:	48 85 ff             	test   %rdi,%rdi
    64ef:	74 05                	je     64f6 <fwp_tape_reserve+0x226>
    64f1:	e8 ba eb ff ff       	call   50b0 <ad_raw_free.part.0>
    64f6:	31 c9                	xor    %ecx,%ecx
    64f8:	31 c0                	xor    %eax,%eax
    64fa:	31 d2                	xor    %edx,%edx
    64fc:	be 01 00 00 00       	mov    $0x1,%esi
    6501:	89 55 04             	mov    %edx,0x4(%rbp)
    6504:	66 0f ef c0          	pxor   %xmm0,%xmm0
    6508:	ba 13 00 00 00       	mov    $0x13,%edx
    650d:	48 8d 3d f4 4a 00 00 	lea    0x4af4(%rip),%rdi        # b008 <_IO_stdin_used+0x8>
    6514:	48 89 4d 48          	mov    %rcx,0x48(%rbp)
    6518:	48 89 4d 18          	mov    %rcx,0x18(%rbp)
    651c:	48 8b 0d 1d 8b 00 00 	mov    0x8b1d(%rip),%rcx        # f040 <stderr@GLIBC_2.2.5>
    6523:	48 89 45 40          	mov    %rax,0x40(%rbp)
    6527:	0f 11 45 20          	movups %xmm0,0x20(%rbp)
    652b:	0f 11 45 30          	movups %xmm0,0x30(%rbp)
    652f:	0f 11 45 08          	movups %xmm0,0x8(%rbp)
    6533:	e8 28 d1 ff ff       	call   3660 <fwrite@plt>
    6538:	31 ff                	xor    %edi,%edi
    653a:	e8 61 d0 ff ff       	call   35a0 <fflush@plt>
    653f:	bf 66 00 00 00       	mov    $0x66,%edi
    6544:	e8 37 d1 ff ff       	call   3680 <_Exit@plt>
    6549:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000006550 <f141.constprop.0>:
    6550:	41 57                	push   %r15
    6552:	41 56                	push   %r14
    6554:	41 55                	push   %r13
    6556:	41 54                	push   %r12
    6558:	49 89 f4             	mov    %rsi,%r12
    655b:	55                   	push   %rbp
    655c:	48 89 fd             	mov    %rdi,%rbp
    655f:	53                   	push   %rbx
    6560:	48 83 ec 08          	sub    $0x8,%rsp
    6564:	48 85 ff             	test   %rdi,%rdi
    6567:	79 09                	jns    6572 <f141.constprop.0+0x22>
    6569:	48 85 f6             	test   %rsi,%rsi
    656c:	0f 88 fe 00 00 00    	js     6670 <f141.constprop.0+0x120>
    6572:	48 89 f8             	mov    %rdi,%rax
    6575:	48 09 f0             	or     %rsi,%rax
    6578:	0f 89 d2 00 00 00    	jns    6650 <f141.constprop.0+0x100>
    657e:	48 89 f8             	mov    %rdi,%rax
    6581:	48 c1 f8 20          	sar    $0x20,%rax
    6585:	48 85 ff             	test   %rdi,%rdi
    6588:	0f 88 02 01 00 00    	js     6690 <f141.constprop.0+0x140>
    658e:	4c 8b 3d 8b 57 00 00 	mov    0x578b(%rip),%r15        # bd20 <msg.4+0xb0>
    6595:	48 89 c7             	mov    %rax,%rdi
    6598:	e8 73 e1 ff ff       	call   4710 <fwp_tape_of>
    659d:	48 89 c3             	mov    %rax,%rbx
    65a0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    65a5:	0f 85 16 01 00 00    	jne    66c1 <f141.constprop.0+0x171>
    65ab:	4c 8b 68 10          	mov    0x10(%rax),%r13
    65af:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    65b6:	0f 8f f9 00 00 00    	jg     66b5 <f141.constprop.0+0x165>
    65bc:	89 e8                	mov    %ebp,%eax
    65be:	49 39 c5             	cmp    %rax,%r13
    65c1:	0f 8e e2 00 00 00    	jle    66a9 <f141.constprop.0+0x159>
    65c7:	4d 85 e4             	test   %r12,%r12
    65ca:	78 0c                	js     65d8 <f141.constprop.0+0x88>
    65cc:	44 89 e0             	mov    %r12d,%eax
    65cf:	49 39 c5             	cmp    %rax,%r13
    65d2:	0f 8e d1 00 00 00    	jle    66a9 <f141.constprop.0+0x159>
    65d8:	4d 89 ee             	mov    %r13,%r14
    65db:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    65df:	48 89 df             	mov    %rbx,%rdi
    65e2:	49 8d 76 01          	lea    0x1(%r14),%rsi
    65e6:	e8 e5 fc ff ff       	call   62d0 <fwp_tape_reserve>
    65eb:	48 8b 43 20          	mov    0x20(%rbx),%rax
    65ef:	4d 85 e4             	test   %r12,%r12
    65f2:	48 8b 0d 27 57 00 00 	mov    0x5727(%rip),%rcx        # bd20 <msg.4+0xb0>
    65f9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
    6600:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6604:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6608:	4c 0f 48 e2          	cmovs  %rdx,%r12
    660c:	4a 89 0c f0          	mov    %rcx,(%rax,%r14,8)
    6610:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6614:	46 89 24 b0          	mov    %r12d,(%rax,%r14,4)
    6618:	48 8b 43 38          	mov    0x38(%rbx),%rax
    661c:	4e 89 3c f0          	mov    %r15,(%rax,%r14,8)
    6620:	49 8d 45 01          	lea    0x1(%r13),%rax
    6624:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6628:	48 83 c4 08          	add    $0x8,%rsp
    662c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6633:	ff ff ff 
    6636:	48 21 e8             	and    %rbp,%rax
    6639:	5b                   	pop    %rbx
    663a:	5d                   	pop    %rbp
    663b:	4c 09 e8             	or     %r13,%rax
    663e:	41 5c                	pop    %r12
    6640:	41 5d                	pop    %r13
    6642:	41 5e                	pop    %r14
    6644:	41 5f                	pop    %r15
    6646:	c3                   	ret
    6647:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    664e:	00 00 
    6650:	48 89 f0             	mov    %rsi,%rax
    6653:	48 c1 ff 20          	sar    $0x20,%rdi
    6657:	48 c1 f8 20          	sar    $0x20,%rax
    665b:	48 39 c7             	cmp    %rax,%rdi
    665e:	0f 84 2a ff ff ff    	je     658e <f141.constprop.0+0x3e>
    6664:	48 8d 3d 65 53 00 00 	lea    0x5365(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    666b:	e8 c0 dd ff ff       	call   4430 <fwp_trap>
    6670:	48 83 c4 08          	add    $0x8,%rsp
    6674:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    667b:	5b                   	pop    %rbx
    667c:	5d                   	pop    %rbp
    667d:	41 5c                	pop    %r12
    667f:	41 5d                	pop    %r13
    6681:	41 5e                	pop    %r14
    6683:	41 5f                	pop    %r15
    6685:	c3                   	ret
    6686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    668d:	00 00 00 
    6690:	48 89 f0             	mov    %rsi,%rax
    6693:	48 89 f5             	mov    %rsi,%rbp
    6696:	45 31 ff             	xor    %r15d,%r15d
    6699:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    66a0:	48 c1 f8 20          	sar    $0x20,%rax
    66a4:	e9 ec fe ff ff       	jmp    6595 <f141.constprop.0+0x45>
    66a9:	48 8d 3d 12 4b 00 00 	lea    0x4b12(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    66b0:	e8 7b dd ff ff       	call   4430 <fwp_trap>
    66b5:	48 8d 3d eb 4a 00 00 	lea    0x4aeb(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    66bc:	e8 6f dd ff ff       	call   4430 <fwp_trap>
    66c1:	48 8d 3d 50 53 00 00 	lea    0x5350(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    66c8:	e8 63 dd ff ff       	call   4430 <fwp_trap>
    66cd:	0f 1f 00             	nopl   (%rax)

00000000000066d0 <w120>:
    66d0:	66 0f 28 d0          	movapd %xmm0,%xmm2
    66d4:	41 57                	push   %r15
    66d6:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
    66da:	41 56                	push   %r14
    66dc:	41 55                	push   %r13
    66de:	41 54                	push   %r12
    66e0:	49 89 f4             	mov    %rsi,%r12
    66e3:	55                   	push   %rbp
    66e4:	48 89 fd             	mov    %rdi,%rbp
    66e7:	53                   	push   %rbx
    66e8:	48 83 ec 38          	sub    $0x38,%rsp
    66ec:	f2 0f 11 04 24       	movsd  %xmm0,(%rsp)
    66f1:	f2 0f 11 54 24 08    	movsd  %xmm2,0x8(%rsp)
    66f7:	48 85 ff             	test   %rdi,%rdi
    66fa:	0f 88 d0 04 00 00    	js     6bd0 <w120+0x500>
    6700:	49 89 ff             	mov    %rdi,%r15
    6703:	f2 0f 11 4c 24 10    	movsd  %xmm1,0x10(%rsp)
    6709:	49 c1 ff 20          	sar    $0x20,%r15
    670d:	4c 89 ff             	mov    %r15,%rdi
    6710:	e8 fb df ff ff       	call   4710 <fwp_tape_of>
    6715:	48 89 c3             	mov    %rax,%rbx
    6718:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    671d:	0f 85 45 05 00 00    	jne    6c68 <w120+0x598>
    6723:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6727:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    672e:	0f 8f 28 05 00 00    	jg     6c5c <w120+0x58c>
    6734:	89 e8                	mov    %ebp,%eax
    6736:	49 39 c5             	cmp    %rax,%r13
    6739:	0f 8e 11 05 00 00    	jle    6c50 <w120+0x580>
    673f:	4d 89 ee             	mov    %r13,%r14
    6742:	4c 2b 73 08          	sub    0x8(%rbx),%r14
    6746:	48 89 df             	mov    %rbx,%rdi
    6749:	49 8d 76 01          	lea    0x1(%r14),%rsi
    674d:	e8 7e fb ff ff       	call   62d0 <fwp_tape_reserve>
    6752:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6756:	f2 0f 10 24 24       	movsd  (%rsp),%xmm4
    675b:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
    6761:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6765:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6769:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    676f:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6773:	42 89 2c b0          	mov    %ebp,(%rax,%r14,4)
    6777:	48 8b 43 38          	mov    0x38(%rbx),%rax
    677b:	f2 42 0f 11 24 f0    	movsd  %xmm4,(%rax,%r14,8)
    6781:	49 8d 45 01          	lea    0x1(%r13),%rax
    6785:	49 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%r14
    678c:	ff ff ff 
    678f:	49 21 ee             	and    %rbp,%r14
    6792:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6796:	4d 09 ee             	or     %r13,%r14
    6799:	4d 89 f5             	mov    %r14,%r13
    679c:	49 c1 fd 20          	sar    $0x20,%r13
    67a0:	4d 85 e4             	test   %r12,%r12
    67a3:	78 10                	js     67b5 <w120+0xe5>
    67a5:	4c 89 e0             	mov    %r12,%rax
    67a8:	48 c1 f8 20          	sar    $0x20,%rax
    67ac:	4c 39 e8             	cmp    %r13,%rax
    67af:	0f 85 87 04 00 00    	jne    6c3c <w120+0x56c>
    67b5:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    67bb:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    67c1:	4d 39 ef             	cmp    %r13,%r15
    67c4:	0f 84 d6 03 00 00    	je     6ba0 <w120+0x4d0>
    67ca:	f2 0f 10 1d 4e 55 00 	movsd  0x554e(%rip),%xmm3        # bd20 <msg.4+0xb0>
    67d1:	00 
    67d2:	f2 0f 10 25 4e 55 00 	movsd  0x554e(%rip),%xmm4        # bd28 <msg.4+0xb8>
    67d9:	00 
    67da:	f2 0f 11 5c 24 10    	movsd  %xmm3,0x10(%rsp)
    67e0:	f2 0f 11 5c 24 18    	movsd  %xmm3,0x18(%rsp)
    67e6:	f2 0f 11 64 24 20    	movsd  %xmm4,0x20(%rsp)
    67ec:	4c 89 ef             	mov    %r13,%rdi
    67ef:	e8 1c df ff ff       	call   4710 <fwp_tape_of>
    67f4:	48 89 c3             	mov    %rax,%rbx
    67f7:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    67fc:	0f 85 66 04 00 00    	jne    6c68 <w120+0x598>
    6802:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    6806:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    680d:	0f 8f 49 04 00 00    	jg     6c5c <w120+0x58c>
    6813:	44 89 f0             	mov    %r14d,%eax
    6816:	49 39 c7             	cmp    %rax,%r15
    6819:	0f 8e 31 04 00 00    	jle    6c50 <w120+0x580>
    681f:	4d 85 e4             	test   %r12,%r12
    6822:	78 0c                	js     6830 <w120+0x160>
    6824:	44 89 e0             	mov    %r12d,%eax
    6827:	49 39 c7             	cmp    %rax,%r15
    682a:	0f 8e 20 04 00 00    	jle    6c50 <w120+0x580>
    6830:	4c 89 f9             	mov    %r15,%rcx
    6833:	48 2b 4b 08          	sub    0x8(%rbx),%rcx
    6837:	48 89 df             	mov    %rbx,%rdi
    683a:	48 8d 71 01          	lea    0x1(%rcx),%rsi
    683e:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    6843:	e8 88 fa ff ff       	call   62d0 <fwp_tape_reserve>
    6848:	48 8b 43 20          	mov    0x20(%rbx),%rax
    684c:	4d 85 e4             	test   %r12,%r12
    684f:	48 8b 73 28          	mov    0x28(%rbx),%rsi
    6853:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
    6858:	f2 0f 10 74 24 20    	movsd  0x20(%rsp),%xmm6
    685e:	f2 0f 10 5c 24 18    	movsd  0x18(%rsp),%xmm3
    6864:	44 89 34 88          	mov    %r14d,(%rax,%rcx,4)
    6868:	48 8b 43 30          	mov    0x30(%rbx),%rax
    686c:	f2 0f 11 34 c8       	movsd  %xmm6,(%rax,%rcx,8)
    6871:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    6878:	49 0f 49 c4          	cmovns %r12,%rax
    687c:	4d 8d 67 01          	lea    0x1(%r15),%r12
    6880:	89 04 8e             	mov    %eax,(%rsi,%rcx,4)
    6883:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6887:	f2 0f 11 1c c8       	movsd  %xmm3,(%rax,%rcx,8)
    688c:	4c 89 63 10          	mov    %r12,0x10(%rbx)
    6890:	48 85 ed             	test   %rbp,%rbp
    6893:	0f 88 0e 04 00 00    	js     6ca7 <w120+0x5d7>
    6899:	48 89 e8             	mov    %rbp,%rax
    689c:	48 c1 f8 20          	sar    $0x20,%rax
    68a0:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    68a5:	49 39 c5             	cmp    %rax,%r13
    68a8:	74 1a                	je     68c4 <w120+0x1f4>
    68aa:	48 89 c7             	mov    %rax,%rdi
    68ad:	e8 5e de ff ff       	call   4710 <fwp_tape_of>
    68b2:	48 89 c3             	mov    %rax,%rbx
    68b5:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    68ba:	0f 85 a8 03 00 00    	jne    6c68 <w120+0x598>
    68c0:	4c 8b 60 10          	mov    0x10(%rax),%r12
    68c4:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    68cb:	0f 8f 8b 03 00 00    	jg     6c5c <w120+0x58c>
    68d1:	89 e8                	mov    %ebp,%eax
    68d3:	4c 39 e0             	cmp    %r12,%rax
    68d6:	0f 8d 74 03 00 00    	jge    6c50 <w120+0x580>
    68dc:	4c 89 e0             	mov    %r12,%rax
    68df:	48 2b 43 08          	sub    0x8(%rbx),%rax
    68e3:	48 89 df             	mov    %rbx,%rdi
    68e6:	48 8d 70 01          	lea    0x1(%rax),%rsi
    68ea:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    68ef:	e8 dc f9 ff ff       	call   62d0 <fwp_tape_reserve>
    68f4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    68f9:	48 8b 53 20          	mov    0x20(%rbx),%rdx
    68fd:	48 8b 0d 24 54 00 00 	mov    0x5424(%rip),%rcx        # bd28 <msg.4+0xb8>
    6904:	f2 0f 10 74 24 08    	movsd  0x8(%rsp),%xmm6
    690a:	89 2c 82             	mov    %ebp,(%rdx,%rax,4)
    690d:	48 8b 53 30          	mov    0x30(%rbx),%rdx
    6911:	66 0f 28 ee          	movapd %xmm6,%xmm5
    6915:	f2 0f 10 7c 24 10    	movsd  0x10(%rsp),%xmm7
    691b:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
    691f:	48 8b 53 28          	mov    0x28(%rbx),%rdx
    6923:	f2 0f 59 ee          	mulsd  %xmm6,%xmm5
    6927:	c7 04 82 ff ff ff ff 	movl   $0xffffffff,(%rdx,%rax,4)
    692e:	48 8b 53 38          	mov    0x38(%rbx),%rdx
    6932:	f2 0f 11 3c c2       	movsd  %xmm7,(%rdx,%rax,8)
    6937:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    693c:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6940:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6947:	ff ff ff 
    694a:	48 21 c5             	and    %rax,%rbp
    694d:	f2 0f 11 6c 24 20    	movsd  %xmm5,0x20(%rsp)
    6953:	4c 09 e5             	or     %r12,%rbp
    6956:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    695d:	ff ff ff 
    6960:	49 21 c6             	and    %rax,%r14
    6963:	4d 09 fe             	or     %r15,%r14
    6966:	4d 89 f4             	mov    %r14,%r12
    6969:	49 c1 fc 20          	sar    $0x20,%r12
    696d:	4c 3b 64 24 18       	cmp    0x18(%rsp),%r12
    6972:	74 16                	je     698a <w120+0x2ba>
    6974:	4c 89 e7             	mov    %r12,%rdi
    6977:	e8 94 dd ff ff       	call   4710 <fwp_tape_of>
    697c:	48 89 c3             	mov    %rax,%rbx
    697f:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6984:	0f 85 de 02 00 00    	jne    6c68 <w120+0x598>
    698a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
    698e:	49 81 ff fe ff ff 7f 	cmp    $0x7ffffffe,%r15
    6995:	0f 8f c1 02 00 00    	jg     6c5c <w120+0x58c>
    699b:	44 89 f0             	mov    %r14d,%eax
    699e:	49 39 c7             	cmp    %rax,%r15
    69a1:	0f 8e a9 02 00 00    	jle    6c50 <w120+0x580>
    69a7:	4d 89 fd             	mov    %r15,%r13
    69aa:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    69ae:	48 89 df             	mov    %rbx,%rdi
    69b1:	49 8d 75 01          	lea    0x1(%r13),%rsi
    69b5:	e8 16 f9 ff ff       	call   62d0 <fwp_tape_reserve>
    69ba:	48 8b 43 20          	mov    0x20(%rbx),%rax
    69be:	f2 0f 10 6c 24 08    	movsd  0x8(%rsp),%xmm5
    69c4:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69c8:	48 8b 43 30          	mov    0x30(%rbx),%rax
    69cc:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    69d2:	48 8b 43 28          	mov    0x28(%rbx),%rax
    69d6:	46 89 34 a8          	mov    %r14d,(%rax,%r13,4)
    69da:	48 8b 43 38          	mov    0x38(%rbx),%rax
    69de:	f2 42 0f 11 2c e8    	movsd  %xmm5,(%rax,%r13,8)
    69e4:	4d 8d 6f 01          	lea    0x1(%r15),%r13
    69e8:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    69ef:	ff ff ff 
    69f2:	49 21 c6             	and    %rax,%r14
    69f5:	4c 89 6b 10          	mov    %r13,0x10(%rbx)
    69f9:	4d 09 fe             	or     %r15,%r14
    69fc:	4d 89 f7             	mov    %r14,%r15
    69ff:	49 c1 ff 20          	sar    $0x20,%r15
    6a03:	4d 39 e7             	cmp    %r12,%r15
    6a06:	74 1d                	je     6a25 <w120+0x355>
    6a08:	4c 89 ff             	mov    %r15,%rdi
    6a0b:	e8 00 dd ff ff       	call   4710 <fwp_tape_of>
    6a10:	48 89 c3             	mov    %rax,%rbx
    6a13:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6a18:	0f 85 4a 02 00 00    	jne    6c68 <w120+0x598>
    6a1e:	4c 8b 68 10          	mov    0x10(%rax),%r13
    6a22:	4d 89 fc             	mov    %r15,%r12
    6a25:	49 81 fd fe ff ff 7f 	cmp    $0x7ffffffe,%r13
    6a2c:	0f 8f 2a 02 00 00    	jg     6c5c <w120+0x58c>
    6a32:	44 89 f0             	mov    %r14d,%eax
    6a35:	4c 39 e8             	cmp    %r13,%rax
    6a38:	0f 8d 12 02 00 00    	jge    6c50 <w120+0x580>
    6a3e:	f2 0f 10 3d ea 52 00 	movsd  0x52ea(%rip),%xmm7        # bd30 <msg.4+0xc0>
    6a45:	00 
    6a46:	f2 0f 59 7c 24 20    	mulsd  0x20(%rsp),%xmm7
    6a4c:	4d 89 ef             	mov    %r13,%r15
    6a4f:	48 89 df             	mov    %rbx,%rdi
    6a52:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
    6a58:	f2 0f 5c 1c 24       	subsd  (%rsp),%xmm3
    6a5d:	4c 2b 7b 08          	sub    0x8(%rbx),%r15
    6a61:	49 8d 77 01          	lea    0x1(%r15),%rsi
    6a65:	f2 0f 11 1c 24       	movsd  %xmm3,(%rsp)
    6a6a:	f2 0f 11 7c 24 08    	movsd  %xmm7,0x8(%rsp)
    6a70:	e8 5b f8 ff ff       	call   62d0 <fwp_tape_reserve>
    6a75:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6a79:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    6a7e:	48 8b 15 ab 52 00 00 	mov    0x52ab(%rip),%rdx        # bd30 <msg.4+0xc0>
    6a85:	46 89 34 b8          	mov    %r14d,(%rax,%r15,4)
    6a89:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6a8d:	66 0f 28 e3          	movapd %xmm3,%xmm4
    6a91:	f2 0f 59 e3          	mulsd  %xmm3,%xmm4
    6a95:	4a 89 14 f8          	mov    %rdx,(%rax,%r15,8)
    6a99:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6a9d:	42 c7 04 b8 ff ff ff 	movl   $0xffffffff,(%rax,%r15,4)
    6aa4:	ff 
    6aa5:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6aa9:	4a c7 04 f8 00 00 00 	movq   $0x0,(%rax,%r15,8)
    6ab0:	00 
    6ab1:	49 8d 45 01          	lea    0x1(%r13),%rax
    6ab5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6ab9:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6ac0:	ff ff ff 
    6ac3:	49 21 c6             	and    %rax,%r14
    6ac6:	f2 0f 11 64 24 10    	movsd  %xmm4,0x10(%rsp)
    6acc:	4d 09 ee             	or     %r13,%r14
    6acf:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    6ad3:	0f 84 57 01 00 00    	je     6c30 <w120+0x560>
    6ad9:	48 89 ef             	mov    %rbp,%rdi
    6adc:	48 c1 ff 20          	sar    $0x20,%rdi
    6ae0:	4c 39 e7             	cmp    %r12,%rdi
    6ae3:	74 13                	je     6af8 <w120+0x428>
    6ae5:	e8 26 dc ff ff       	call   4710 <fwp_tape_of>
    6aea:	48 89 c3             	mov    %rax,%rbx
    6aed:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
    6af2:	0f 85 70 01 00 00    	jne    6c68 <w120+0x598>
    6af8:	4c 8b 63 10          	mov    0x10(%rbx),%r12
    6afc:	49 81 fc fe ff ff 7f 	cmp    $0x7ffffffe,%r12
    6b03:	0f 8f 53 01 00 00    	jg     6c5c <w120+0x58c>
    6b09:	89 e8                	mov    %ebp,%eax
    6b0b:	4c 39 e0             	cmp    %r12,%rax
    6b0e:	0f 8d 3c 01 00 00    	jge    6c50 <w120+0x580>
    6b14:	4d 89 e5             	mov    %r12,%r13
    6b17:	4c 2b 6b 08          	sub    0x8(%rbx),%r13
    6b1b:	48 89 df             	mov    %rbx,%rdi
    6b1e:	49 8d 75 01          	lea    0x1(%r13),%rsi
    6b22:	e8 a9 f7 ff ff       	call   62d0 <fwp_tape_reserve>
    6b27:	48 8b 43 20          	mov    0x20(%rbx),%rax
    6b2b:	f2 0f 10 14 24       	movsd  (%rsp),%xmm2
    6b30:	48 89 ef             	mov    %rbp,%rdi
    6b33:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b37:	48 8b 43 30          	mov    0x30(%rbx),%rax
    6b3b:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b41:	48 8b 43 28          	mov    0x28(%rbx),%rax
    6b45:	42 89 2c a8          	mov    %ebp,(%rax,%r13,4)
    6b49:	48 8b 43 38          	mov    0x38(%rbx),%rax
    6b4d:	f2 42 0f 11 14 e8    	movsd  %xmm2,(%rax,%r13,8)
    6b53:	49 8d 44 24 01       	lea    0x1(%r12),%rax
    6b58:	48 89 43 10          	mov    %rax,0x10(%rbx)
    6b5c:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    6b63:	ff ff ff 
    6b66:	48 21 c7             	and    %rax,%rdi
    6b69:	4c 09 e7             	or     %r12,%rdi
    6b6c:	f2 0f 10 7c 24 08    	movsd  0x8(%rsp),%xmm7
    6b72:	f2 0f 58 7c 24 10    	addsd  0x10(%rsp),%xmm7
    6b78:	4c 89 f6             	mov    %r14,%rsi
    6b7b:	66 48 0f 7e fb       	movq   %xmm7,%rbx
    6b80:	e8 cb f9 ff ff       	call   6550 <f141.constprop.0>
    6b85:	48 83 c4 38          	add    $0x38,%rsp
    6b89:	66 48 0f 6e c3       	movq   %rbx,%xmm0
    6b8e:	5b                   	pop    %rbx
    6b8f:	5d                   	pop    %rbp
    6b90:	41 5c                	pop    %r12
    6b92:	41 5d                	pop    %r13
    6b94:	41 5e                	pop    %r14
    6b96:	41 5f                	pop    %r15
    6b98:	c3                   	ret
    6b99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    6ba0:	f2 0f 10 3d 78 51 00 	movsd  0x5178(%rip),%xmm7        # bd20 <msg.4+0xb0>
    6ba7:	00 
    6ba8:	f2 0f 10 15 78 51 00 	movsd  0x5178(%rip),%xmm2        # bd28 <msg.4+0xb8>
    6baf:	00 
    6bb0:	f2 0f 11 7c 24 10    	movsd  %xmm7,0x10(%rsp)
    6bb6:	f2 0f 11 7c 24 18    	movsd  %xmm7,0x18(%rsp)
    6bbc:	f2 0f 11 54 24 20    	movsd  %xmm2,0x20(%rsp)
    6bc2:	e9 3b fc ff ff       	jmp    6802 <w120+0x132>
    6bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6bce:	00 00 
    6bd0:	f2 0f 5c 4c 24 08    	subsd  0x8(%rsp),%xmm1
    6bd6:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6bdc:	48 85 f6             	test   %rsi,%rsi
    6bdf:	0f 89 8f 00 00 00    	jns    6c74 <w120+0x5a4>
    6be5:	f2 0f 10 4c 24 08    	movsd  0x8(%rsp),%xmm1
    6beb:	f2 0f 10 05 2d 51 00 	movsd  0x512d(%rip),%xmm0        # bd20 <msg.4+0xb0>
    6bf2:	00 
    6bf3:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
    6bfa:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c01:	f2 0f 5c 04 24       	subsd  (%rsp),%xmm0
    6c06:	f2 0f 59 c9          	mulsd  %xmm1,%xmm1
    6c0a:	f2 0f 59 0d 1e 51 00 	mulsd  0x511e(%rip),%xmm1        # bd30 <msg.4+0xc0>
    6c11:	00 
    6c12:	f2 0f 59 c0          	mulsd  %xmm0,%xmm0
    6c16:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
    6c1c:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
    6c22:	e9 45 ff ff ff       	jmp    6b6c <w120+0x49c>
    6c27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    6c2e:	00 00 
    6c30:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    6c37:	e9 30 ff ff ff       	jmp    6b6c <w120+0x49c>
    6c3c:	48 8d 3d 8d 4d 00 00 	lea    0x4d8d(%rip),%rdi        # b9d0 <_IO_stdin_used+0x9d0>
    6c43:	e8 e8 d7 ff ff       	call   4430 <fwp_trap>
    6c48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6c4f:	00 
    6c50:	48 8d 3d 6b 45 00 00 	lea    0x456b(%rip),%rdi        # b1c2 <_IO_stdin_used+0x1c2>
    6c57:	e8 d4 d7 ff ff       	call   4430 <fwp_trap>
    6c5c:	48 8d 3d 44 45 00 00 	lea    0x4544(%rip),%rdi        # b1a7 <_IO_stdin_used+0x1a7>
    6c63:	e8 c8 d7 ff ff       	call   4430 <fwp_trap>
    6c68:	48 8d 3d a9 4d 00 00 	lea    0x4da9(%rip),%rdi        # ba18 <_IO_stdin_used+0xa18>
    6c6f:	e8 bc d7 ff ff       	call   4430 <fwp_trap>
    6c74:	f2 0f 10 35 a4 50 00 	movsd  0x50a4(%rip),%xmm6        # bd20 <msg.4+0xb0>
    6c7b:	00 
    6c7c:	49 89 f5             	mov    %rsi,%r13
    6c7f:	49 89 f6             	mov    %rsi,%r14
    6c82:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
    6c89:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
    6c90:	00 00 
    6c92:	49 c1 fd 20          	sar    $0x20,%r13
    6c96:	f2 0f 11 74 24 10    	movsd  %xmm6,0x10(%rsp)
    6c9c:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6ca2:	e9 45 fb ff ff       	jmp    67ec <w120+0x11c>
    6ca7:	f2 0f 10 64 24 08    	movsd  0x8(%rsp),%xmm4
    6cad:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
    6cb2:	48 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%rbp
    6cb9:	66 0f 28 f4          	movapd %xmm4,%xmm6
    6cbd:	f2 0f 59 f4          	mulsd  %xmm4,%xmm6
    6cc1:	f2 0f 11 74 24 20    	movsd  %xmm6,0x20(%rsp)
    6cc7:	e9 8a fc ff ff       	jmp    6956 <w120+0x286>
    6ccc:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000006cd0 <fwp_rc_share>:
    6cd0:	48 8b 05 21 1f 06 00 	mov    0x61f21(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    6cd7:	48 2b 3d f2 1e 06 00 	sub    0x61ef2(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    6cde:	48 c1 e0 10          	shl    $0x10,%rax
    6ce2:	48 39 c7             	cmp    %rax,%rdi
    6ce5:	73 4a                	jae    6d31 <fwp_rc_share+0x61>
    6ce7:	48 89 f8             	mov    %rdi,%rax
    6cea:	48 c1 e8 10          	shr    $0x10,%rax
    6cee:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6cf2:	48 8b 05 1f 1f 06 00 	mov    0x61f1f(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    6cf9:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
    6cfd:	48 8b 50 20          	mov    0x20(%rax),%rdx
    6d01:	48 85 d2             	test   %rdx,%rdx
    6d04:	74 2b                	je     6d31 <fwp_rc_share+0x61>
    6d06:	0f b6 08             	movzbl (%rax),%ecx
    6d09:	80 f9 02             	cmp    $0x2,%cl
    6d0c:	74 2a                	je     6d38 <fwp_rc_share+0x68>
    6d0e:	80 f9 01             	cmp    $0x1,%cl
    6d11:	75 1e                	jne    6d31 <fwp_rc_share+0x61>
    6d13:	8b 48 18             	mov    0x18(%rax),%ecx
    6d16:	0f b7 ff             	movzwl %di,%edi
    6d19:	8b 40 1c             	mov    0x1c(%rax),%eax
    6d1c:	48 0f af f9          	imul   %rcx,%rdi
    6d20:	48 c1 ef 20          	shr    $0x20,%rdi
    6d24:	48 39 c7             	cmp    %rax,%rdi
    6d27:	73 08                	jae    6d31 <fwp_rc_share+0x61>
    6d29:	48 01 fa             	add    %rdi,%rdx
    6d2c:	80 3a 00             	cmpb   $0x0,(%rdx)
    6d2f:	75 0d                	jne    6d3e <fwp_rc_share+0x6e>
    6d31:	c3                   	ret
    6d32:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6d38:	66 85 ff             	test   %di,%di
    6d3b:	74 ef                	je     6d2c <fwp_rc_share+0x5c>
    6d3d:	c3                   	ret
    6d3e:	50                   	push   %rax
    6d3f:	48 8d 3d 02 4d 00 00 	lea    0x4d02(%rip),%rdi        # ba48 <_IO_stdin_used+0xa48>
    6d46:	e8 e5 d6 ff ff       	call   4430 <fwp_trap>
    6d4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000006d50 <fwp_rc_free_obj>:
    6d50:	48 8b 15 a1 1e 06 00 	mov    0x61ea1(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6d57:	48 89 f8             	mov    %rdi,%rax
    6d5a:	48 2b 05 6f 1e 06 00 	sub    0x61e6f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6d61:	48 c1 e2 10          	shl    $0x10,%rdx
    6d65:	48 39 d0             	cmp    %rdx,%rax
    6d68:	73 5b                	jae    6dc5 <fwp_rc_free_obj+0x75>
    6d6a:	48 89 c2             	mov    %rax,%rdx
    6d6d:	48 c1 ea 10          	shr    $0x10,%rdx
    6d71:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6d75:	48 8b 15 9c 1e 06 00 	mov    0x61e9c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6d7c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    6d80:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    6d84:	48 85 c9             	test   %rcx,%rcx
    6d87:	74 3c                	je     6dc5 <fwp_rc_free_obj+0x75>
    6d89:	0f b6 32             	movzbl (%rdx),%esi
    6d8c:	40 80 fe 02          	cmp    $0x2,%sil
    6d90:	74 2e                	je     6dc0 <fwp_rc_free_obj+0x70>
    6d92:	40 80 fe 01          	cmp    $0x1,%sil
    6d96:	75 2d                	jne    6dc5 <fwp_rc_free_obj+0x75>
    6d98:	8b 72 18             	mov    0x18(%rdx),%esi
    6d9b:	0f b7 c0             	movzwl %ax,%eax
    6d9e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6da1:	48 0f af c6          	imul   %rsi,%rax
    6da5:	48 c1 e8 20          	shr    $0x20,%rax
    6da9:	48 39 d0             	cmp    %rdx,%rax
    6dac:	73 17                	jae    6dc5 <fwp_rc_free_obj+0x75>
    6dae:	48 01 c1             	add    %rax,%rcx
    6db1:	80 39 01             	cmpb   $0x1,(%rcx)
    6db4:	75 0f                	jne    6dc5 <fwp_rc_free_obj+0x75>
    6db6:	e9 35 ec ff ff       	jmp    59f0 <fwp_mem_free>
    6dbb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    6dc0:	66 85 c0             	test   %ax,%ax
    6dc3:	74 ec                	je     6db1 <fwp_rc_free_obj+0x61>
    6dc5:	c3                   	ret
    6dc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6dcd:	00 00 00 

0000000000006dd0 <fwp_rc_dup>:
    6dd0:	f3 0f 1e fa          	endbr64
    6dd4:	48 8b 05 1d 1e 06 00 	mov    0x61e1d(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    6ddb:	48 2b 3d ee 1d 06 00 	sub    0x61dee(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    6de2:	48 c1 e0 10          	shl    $0x10,%rax
    6de6:	48 39 c7             	cmp    %rax,%rdi
    6de9:	73 60                	jae    6e4b <fwp_rc_dup+0x7b>
    6deb:	48 89 f8             	mov    %rdi,%rax
    6dee:	48 c1 e8 10          	shr    $0x10,%rax
    6df2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    6df6:	48 8b 05 1b 1e 06 00 	mov    0x61e1b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    6dfd:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    6e01:	48 8b 42 20          	mov    0x20(%rdx),%rax
    6e05:	48 85 c0             	test   %rax,%rax
    6e08:	74 41                	je     6e4b <fwp_rc_dup+0x7b>
    6e0a:	0f b6 0a             	movzbl (%rdx),%ecx
    6e0d:	80 f9 02             	cmp    $0x2,%cl
    6e10:	74 3e                	je     6e50 <fwp_rc_dup+0x80>
    6e12:	80 f9 01             	cmp    $0x1,%cl
    6e15:	75 34                	jne    6e4b <fwp_rc_dup+0x7b>
    6e17:	8b 4a 18             	mov    0x18(%rdx),%ecx
    6e1a:	0f b7 ff             	movzwl %di,%edi
    6e1d:	8b 52 1c             	mov    0x1c(%rdx),%edx
    6e20:	48 0f af f9          	imul   %rcx,%rdi
    6e24:	48 c1 ef 20          	shr    $0x20,%rdi
    6e28:	48 39 d7             	cmp    %rdx,%rdi
    6e2b:	73 1e                	jae    6e4b <fwp_rc_dup+0x7b>
    6e2d:	48 01 f8             	add    %rdi,%rax
    6e30:	0f b6 10             	movzbl (%rax),%edx
    6e33:	84 d2                	test   %dl,%dl
    6e35:	74 14                	je     6e4b <fwp_rc_dup+0x7b>
    6e37:	8b 0d ab 26 06 00    	mov    0x626ab(%rip),%ecx        # 694e8 <iteration_active>
    6e3d:	85 c9                	test   %ecx,%ecx
    6e3f:	75 1f                	jne    6e60 <fwp_rc_dup+0x90>
    6e41:	80 fa fd             	cmp    $0xfd,%dl
    6e44:	77 2a                	ja     6e70 <fwp_rc_dup+0xa0>
    6e46:	83 c2 01             	add    $0x1,%edx
    6e49:	88 10                	mov    %dl,(%rax)
    6e4b:	c3                   	ret
    6e4c:	0f 1f 40 00          	nopl   0x0(%rax)
    6e50:	66 85 ff             	test   %di,%di
    6e53:	74 db                	je     6e30 <fwp_rc_dup+0x60>
    6e55:	c3                   	ret
    6e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6e5d:	00 00 00 
    6e60:	48 83 05 68 26 06 00 	addq   $0x1,0x62668(%rip)        # 694d0 <iteration_retains>
    6e67:	01 
    6e68:	eb d7                	jmp    6e41 <fwp_rc_dup+0x71>
    6e6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    6e70:	48 89 c7             	mov    %rax,%rdi
    6e73:	e9 18 e8 ff ff       	jmp    5690 <fwp_rc_wide_dup>
    6e78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    6e7f:	00 

0000000000006e80 <fwp_owned_entry173>:
    6e80:	f3 0f 1e fa          	endbr64
    6e84:	48 83 ec 38          	sub    $0x38,%rsp
    6e88:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6e8d:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6e94:	00 00 
    6e96:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6e9b:	31 c0                	xor    %eax,%eax
    6e9d:	48 8b 07             	mov    (%rdi),%rax
    6ea0:	48 03 47 10          	add    0x10(%rdi),%rax
    6ea4:	0f 80 c2 00 00 00    	jo     6f6c <fwp_owned_entry173+0xec>
    6eaa:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6eaf:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6eb4:	31 ff                	xor    %edi,%edi
    6eb6:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6eba:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6ebf:	e8 1c f2 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6ec4:	48 8b 15 2d 1d 06 00 	mov    0x61d2d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6ecb:	48 89 c6             	mov    %rax,%rsi
    6ece:	48 2b 05 fb 1c 06 00 	sub    0x61cfb(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6ed5:	48 c1 e2 10          	shl    $0x10,%rdx
    6ed9:	48 39 d0             	cmp    %rdx,%rax
    6edc:	73 4f                	jae    6f2d <fwp_owned_entry173+0xad>
    6ede:	48 89 c2             	mov    %rax,%rdx
    6ee1:	48 c1 ea 10          	shr    $0x10,%rdx
    6ee5:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6ee9:	48 8b 15 28 1d 06 00 	mov    0x61d28(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6ef0:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ef4:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ef8:	48 85 d2             	test   %rdx,%rdx
    6efb:	74 30                	je     6f2d <fwp_owned_entry173+0xad>
    6efd:	0f b6 39             	movzbl (%rcx),%edi
    6f00:	40 80 ff 02          	cmp    $0x2,%dil
    6f04:	74 42                	je     6f48 <fwp_owned_entry173+0xc8>
    6f06:	40 80 ff 01          	cmp    $0x1,%dil
    6f0a:	75 21                	jne    6f2d <fwp_owned_entry173+0xad>
    6f0c:	8b 79 18             	mov    0x18(%rcx),%edi
    6f0f:	0f b7 c0             	movzwl %ax,%eax
    6f12:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    6f15:	48 0f af c7          	imul   %rdi,%rax
    6f19:	48 c1 e8 20          	shr    $0x20,%rax
    6f1d:	48 39 c8             	cmp    %rcx,%rax
    6f20:	73 0b                	jae    6f2d <fwp_owned_entry173+0xad>
    6f22:	48 01 c2             	add    %rax,%rdx
    6f25:	80 3a ff             	cmpb   $0xff,(%rdx)
    6f28:	74 26                	je     6f50 <fwp_owned_entry173+0xd0>
    6f2a:	c6 02 01             	movb   $0x1,(%rdx)
    6f2d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    6f32:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    6f39:	00 00 
    6f3b:	75 34                	jne    6f71 <fwp_owned_entry173+0xf1>
    6f3d:	48 89 f0             	mov    %rsi,%rax
    6f40:	48 83 c4 38          	add    $0x38,%rsp
    6f44:	c3                   	ret
    6f45:	0f 1f 00             	nopl   (%rax)
    6f48:	66 85 c0             	test   %ax,%ax
    6f4b:	75 e0                	jne    6f2d <fwp_owned_entry173+0xad>
    6f4d:	eb d6                	jmp    6f25 <fwp_owned_entry173+0xa5>
    6f4f:	90                   	nop
    6f50:	48 89 d7             	mov    %rdx,%rdi
    6f53:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
    6f58:	48 89 14 24          	mov    %rdx,(%rsp)
    6f5c:	e8 4f e8 ff ff       	call   57b0 <fwp_rc_forget_slot>
    6f61:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    6f66:	48 8b 14 24          	mov    (%rsp),%rdx
    6f6a:	eb be                	jmp    6f2a <fwp_owned_entry173+0xaa>
    6f6c:	e8 6f c7 ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    6f71:	e8 da c4 ff ff       	call   3450 <__stack_chk_fail@plt>
    6f76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    6f7d:	00 00 00 

0000000000006f80 <e173>:
    6f80:	f3 0f 1e fa          	endbr64
    6f84:	53                   	push   %rbx
    6f85:	48 83 ec 30          	sub    $0x30,%rsp
    6f89:	f3 0f 7e 47 08       	movq   0x8(%rdi),%xmm0
    6f8e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    6f95:	00 00 
    6f97:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    6f9c:	31 c0                	xor    %eax,%eax
    6f9e:	48 8b 07             	mov    (%rdi),%rax
    6fa1:	48 03 47 10          	add    0x10(%rdi),%rax
    6fa5:	0f 80 c9 00 00 00    	jo     7074 <e173+0xf4>
    6fab:	66 48 0f 6e c8       	movq   %rax,%xmm1
    6fb0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    6fb5:	31 ff                	xor    %edi,%edi
    6fb7:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
    6fbb:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    6fc0:	e8 1b f1 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    6fc5:	48 8b 15 2c 1c 06 00 	mov    0x61c2c(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    6fcc:	48 89 c3             	mov    %rax,%rbx
    6fcf:	48 2b 05 fa 1b 06 00 	sub    0x61bfa(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    6fd6:	48 c1 e2 10          	shl    $0x10,%rdx
    6fda:	48 39 d0             	cmp    %rdx,%rax
    6fdd:	73 4f                	jae    702e <e173+0xae>
    6fdf:	48 89 c2             	mov    %rax,%rdx
    6fe2:	48 c1 ea 10          	shr    $0x10,%rdx
    6fe6:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    6fea:	48 8b 15 27 1c 06 00 	mov    0x61c27(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    6ff1:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    6ff5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    6ff9:	48 85 d2             	test   %rdx,%rdx
    6ffc:	74 30                	je     702e <e173+0xae>
    6ffe:	0f b6 31             	movzbl (%rcx),%esi
    7001:	40 80 fe 02          	cmp    $0x2,%sil
    7005:	74 49                	je     7050 <e173+0xd0>
    7007:	40 80 fe 01          	cmp    $0x1,%sil
    700b:	75 21                	jne    702e <e173+0xae>
    700d:	8b 71 18             	mov    0x18(%rcx),%esi
    7010:	0f b7 c0             	movzwl %ax,%eax
    7013:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7016:	48 0f af c6          	imul   %rsi,%rax
    701a:	48 c1 e8 20          	shr    $0x20,%rax
    701e:	48 39 c8             	cmp    %rcx,%rax
    7021:	73 0b                	jae    702e <e173+0xae>
    7023:	48 01 c2             	add    %rax,%rdx
    7026:	80 3a ff             	cmpb   $0xff,(%rdx)
    7029:	74 35                	je     7060 <e173+0xe0>
    702b:	c6 02 01             	movb   $0x1,(%rdx)
    702e:	48 89 df             	mov    %rbx,%rdi
    7031:	e8 9a fc ff ff       	call   6cd0 <fwp_rc_share>
    7036:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    703b:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    7042:	00 00 
    7044:	75 33                	jne    7079 <e173+0xf9>
    7046:	48 83 c4 30          	add    $0x30,%rsp
    704a:	48 89 d8             	mov    %rbx,%rax
    704d:	5b                   	pop    %rbx
    704e:	c3                   	ret
    704f:	90                   	nop
    7050:	66 85 c0             	test   %ax,%ax
    7053:	75 d9                	jne    702e <e173+0xae>
    7055:	eb cf                	jmp    7026 <e173+0xa6>
    7057:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    705e:	00 00 
    7060:	48 89 d7             	mov    %rdx,%rdi
    7063:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7068:	e8 43 e7 ff ff       	call   57b0 <fwp_rc_forget_slot>
    706d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    7072:	eb b7                	jmp    702b <e173+0xab>
    7074:	e8 67 c6 ff ff       	call   36e0 <fwp_trap_overflow.constprop.0>
    7079:	e8 d2 c3 ff ff       	call   3450 <__stack_chk_fail@plt>
    707e:	66 90                	xchg   %ax,%ax

0000000000007080 <fwp_closure_drop>:
    7080:	48 8b 15 71 1b 06 00 	mov    0x61b71(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7087:	48 89 f8             	mov    %rdi,%rax
    708a:	48 2b 05 3f 1b 06 00 	sub    0x61b3f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7091:	48 c1 e2 10          	shl    $0x10,%rdx
    7095:	48 39 d0             	cmp    %rdx,%rax
    7098:	73 6b                	jae    7105 <fwp_closure_drop+0x85>
    709a:	48 89 c2             	mov    %rax,%rdx
    709d:	48 c1 ea 10          	shr    $0x10,%rdx
    70a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    70a5:	48 8b 15 6c 1b 06 00 	mov    0x61b6c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    70ac:	48 8d 0c ca          	lea    (%rdx,%rcx,8),%rcx
    70b0:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    70b4:	48 85 d2             	test   %rdx,%rdx
    70b7:	74 4c                	je     7105 <fwp_closure_drop+0x85>
    70b9:	0f b6 31             	movzbl (%rcx),%esi
    70bc:	40 80 fe 02          	cmp    $0x2,%sil
    70c0:	74 3e                	je     7100 <fwp_closure_drop+0x80>
    70c2:	40 80 fe 01          	cmp    $0x1,%sil
    70c6:	75 3d                	jne    7105 <fwp_closure_drop+0x85>
    70c8:	8b 71 18             	mov    0x18(%rcx),%esi
    70cb:	0f b7 c0             	movzwl %ax,%eax
    70ce:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    70d1:	48 0f af c6          	imul   %rsi,%rax
    70d5:	48 c1 e8 20          	shr    $0x20,%rax
    70d9:	48 39 c8             	cmp    %rcx,%rax
    70dc:	73 27                	jae    7105 <fwp_closure_drop+0x85>
    70de:	48 01 c2             	add    %rax,%rdx
    70e1:	0f b6 02             	movzbl (%rdx),%eax
    70e4:	84 c0                	test   %al,%al
    70e6:	74 1d                	je     7105 <fwp_closure_drop+0x85>
    70e8:	3c 01                	cmp    $0x1,%al
    70ea:	74 24                	je     7110 <fwp_closure_drop+0x90>
    70ec:	3c ff                	cmp    $0xff,%al
    70ee:	74 48                	je     7138 <fwp_closure_drop+0xb8>
    70f0:	83 e8 01             	sub    $0x1,%eax
    70f3:	88 02                	mov    %al,(%rdx)
    70f5:	c3                   	ret
    70f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    70fd:	00 00 00 
    7100:	66 85 c0             	test   %ax,%ax
    7103:	74 dc                	je     70e1 <fwp_closure_drop+0x61>
    7105:	c3                   	ret
    7106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    710d:	00 00 00 
    7110:	64 48 8b 04 25 f8 ff 	mov    %fs:0xfffffffffffffff8,%rax
    7117:	ff ff 
    7119:	48 85 c0             	test   %rax,%rax
    711c:	74 12                	je     7130 <fwp_closure_drop+0xb0>
    711e:	48 89 fe             	mov    %rdi,%rsi
    7121:	48 89 c7             	mov    %rax,%rdi
    7124:	e9 67 d3 ff ff       	jmp    4490 <fwp_closure_drop_push>
    7129:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7130:	e9 0b d5 ff ff       	jmp    4640 <fwp_closure_drop.part.0>
    7135:	0f 1f 00             	nopl   (%rax)
    7138:	48 89 d0             	mov    %rdx,%rax
    713b:	48 8d 35 de 06 06 00 	lea    0x606de(%rip),%rsi        # 67820 <fwp_heap>
    7142:	48 83 ec 18          	sub    $0x18,%rsp
    7146:	48 c1 e8 11          	shr    $0x11,%rax
    714a:	48 31 d0             	xor    %rdx,%rax
    714d:	48 89 c1             	mov    %rax,%rcx
    7150:	48 c1 e9 09          	shr    $0x9,%rcx
    7154:	48 31 c8             	xor    %rcx,%rax
    7157:	0f b6 c8             	movzbl %al,%ecx
    715a:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    7161:	00 
    7162:	48 85 c0             	test   %rax,%rax
    7165:	75 22                	jne    7189 <fwp_closure_drop+0x109>
    7167:	eb 59                	jmp    71c2 <fwp_closure_drop+0x142>
    7169:	90                   	nop
    716a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7171:	00 00 00 00 
    7175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    717c:	00 00 00 00 
    7180:	48 8b 41 10          	mov    0x10(%rcx),%rax
    7184:	48 85 c0             	test   %rax,%rax
    7187:	74 39                	je     71c2 <fwp_closure_drop+0x142>
    7189:	48 89 c1             	mov    %rax,%rcx
    718c:	48 39 10             	cmp    %rdx,(%rax)
    718f:	75 ef                	jne    7180 <fwp_closure_drop+0x100>
    7191:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7195:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    7199:	48 89 48 08          	mov    %rcx,0x8(%rax)
    719d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    71a4:	74 05                	je     71ab <fwp_closure_drop+0x12b>
    71a6:	48 83 c4 18          	add    $0x18,%rsp
    71aa:	c3                   	ret
    71ab:	48 89 d7             	mov    %rdx,%rdi
    71ae:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    71b3:	e8 f8 e5 ff ff       	call   57b0 <fwp_rc_forget_slot>
    71b8:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    71bd:	c6 02 fe             	movb   $0xfe,(%rdx)
    71c0:	eb e4                	jmp    71a6 <fwp_closure_drop+0x126>
    71c2:	48 8d 3d df 47 00 00 	lea    0x47df(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    71c9:	e8 62 d2 ff ff       	call   4430 <fwp_trap>
    71ce:	66 90                	xchg   %ax,%ax

00000000000071d0 <fwp_owned_tape_release>:
    71d0:	48 85 ff             	test   %rdi,%rdi
    71d3:	0f 84 f7 00 00 00    	je     72d0 <fwp_owned_tape_release+0x100>
    71d9:	41 54                	push   %r12
    71db:	55                   	push   %rbp
    71dc:	53                   	push   %rbx
    71dd:	48 8b 07             	mov    (%rdi),%rax
    71e0:	48 85 c0             	test   %rax,%rax
    71e3:	74 08                	je     71ed <fwp_owned_tape_release+0x1d>
    71e5:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    71e9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    71ed:	48 8b 57 08          	mov    0x8(%rdi),%rdx
    71f1:	48 85 d2             	test   %rdx,%rdx
    71f4:	74 03                	je     71f9 <fwp_owned_tape_release+0x29>
    71f6:	48 89 02             	mov    %rax,(%rdx)
    71f9:	48 8b 57 10          	mov    0x10(%rdi),%rdx
    71fd:	48 89 fb             	mov    %rdi,%rbx
    7200:	48 8b 42 68          	mov    0x68(%rdx),%rax
    7204:	48 85 c0             	test   %rax,%rax
    7207:	0f 84 89 00 00 00    	je     7296 <fwp_owned_tape_release+0xc6>
    720d:	48 8b 4f 50          	mov    0x50(%rdi),%rcx
    7211:	48 39 4f 58          	cmp    %rcx,0x58(%rdi)
    7215:	7e 47                	jle    725e <fwp_owned_tape_release+0x8e>
    7217:	31 ed                	xor    %ebp,%ebp
    7219:	eb 0d                	jmp    7228 <fwp_owned_tape_release+0x58>
    721b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7220:	48 8b 43 10          	mov    0x10(%rbx),%rax
    7224:	48 8b 40 68          	mov    0x68(%rax),%rax
    7228:	48 8b 53 40          	mov    0x40(%rbx),%rdx
    722c:	49 89 ec             	mov    %rbp,%r12
    722f:	48 83 c5 01          	add    $0x1,%rbp
    7233:	49 c1 e4 04          	shl    $0x4,%r12
    7237:	4a 8b 3c 22          	mov    (%rdx,%r12,1),%rdi
    723b:	ff d0                	call   *%rax
    723d:	48 8b 43 40          	mov    0x40(%rbx),%rax
    7241:	4a 8b 7c 20 08       	mov    0x8(%rax,%r12,1),%rdi
    7246:	48 8b 43 10          	mov    0x10(%rbx),%rax
    724a:	ff 50 68             	call   *0x68(%rax)
    724d:	48 8b 43 58          	mov    0x58(%rbx),%rax
    7251:	48 2b 43 50          	sub    0x50(%rbx),%rax
    7255:	48 39 e8             	cmp    %rbp,%rax
    7258:	7f c6                	jg     7220 <fwp_owned_tape_release+0x50>
    725a:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    725e:	31 ed                	xor    %ebp,%ebp
    7260:	48 83 7b 68 00       	cmpq   $0x0,0x68(%rbx)
    7265:	7e 28                	jle    728f <fwp_owned_tape_release+0xbf>
    7267:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    726e:	00 00 
    7270:	48 8b 43 48          	mov    0x48(%rbx),%rax
    7274:	48 8b 3c e8          	mov    (%rax,%rbp,8),%rdi
    7278:	48 3b 7b 20          	cmp    0x20(%rbx),%rdi
    727c:	74 07                	je     7285 <fwp_owned_tape_release+0xb5>
    727e:	ff 52 68             	call   *0x68(%rdx)
    7281:	48 8b 53 10          	mov    0x10(%rbx),%rdx
    7285:	48 83 c5 01          	add    $0x1,%rbp
    7289:	48 39 6b 68          	cmp    %rbp,0x68(%rbx)
    728d:	7f e1                	jg     7270 <fwp_owned_tape_release+0xa0>
    728f:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
    7293:	ff 52 68             	call   *0x68(%rdx)
    7296:	48 8b 7b 28          	mov    0x28(%rbx),%rdi
    729a:	e8 e1 fd ff ff       	call   7080 <fwp_closure_drop>
    729f:	48 8b 7b 30          	mov    0x30(%rbx),%rdi
    72a3:	e8 d8 fd ff ff       	call   7080 <fwp_closure_drop>
    72a8:	48 8b 7b 38          	mov    0x38(%rbx),%rdi
    72ac:	e8 cf fd ff ff       	call   7080 <fwp_closure_drop>
    72b1:	48 8b 7b 40          	mov    0x40(%rbx),%rdi
    72b5:	e8 36 e7 ff ff       	call   59f0 <fwp_mem_free>
    72ba:	48 8b 7b 48          	mov    0x48(%rbx),%rdi
    72be:	e8 2d e7 ff ff       	call   59f0 <fwp_mem_free>
    72c3:	48 89 df             	mov    %rbx,%rdi
    72c6:	5b                   	pop    %rbx
    72c7:	5d                   	pop    %rbp
    72c8:	41 5c                	pop    %r12
    72ca:	e9 21 e7 ff ff       	jmp    59f0 <fwp_mem_free>
    72cf:	90                   	nop
    72d0:	c3                   	ret
    72d1:	0f 1f 40 00          	nopl   0x0(%rax)
    72d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    72dc:	00 00 00 00 

00000000000072e0 <fwp_tape_finish>:
    72e0:	f3 0f 1e fa          	endbr64
    72e4:	41 55                	push   %r13
    72e6:	41 54                	push   %r12
    72e8:	55                   	push   %rbp
    72e9:	53                   	push   %rbx
    72ea:	48 83 ec 48          	sub    $0x48,%rsp
    72ee:	64 48 8b 3c 25 28 00 	mov    %fs:0x28,%rdi
    72f5:	00 00 
    72f7:	48 89 7c 24 38       	mov    %rdi,0x38(%rsp)
    72fc:	48 8d 3d 9d 7d 01 00 	lea    0x17d9d(%rip),%rdi        # 1f0a0 <fwp_tape_workspace>
    7303:	e8 18 de ff ff       	call   5120 <fwp_tape_buffers_dispose>
    7308:	48 83 3d d8 7d 01 00 	cmpq   $0x0,0x17dd8(%rip)        # 1f0e8 <fwp_ntapes>
    730f:	00 
    7310:	48 c7 05 6d 7d 01 00 	movq   $0x0,0x17d6d(%rip)        # 1f088 <fwp_tape_cached_bytes>
    7317:	00 00 00 00 
    731b:	7e 79                	jle    7396 <fwp_tape_finish+0xb6>
    731d:	45 31 e4             	xor    %r12d,%r12d
    7320:	31 ed                	xor    %ebp,%ebp
    7322:	0f 1f 00             	nopl   (%rax)
    7325:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    732c:	00 00 00 00 
    7330:	48 8b 1d b9 7d 01 00 	mov    0x17db9(%rip),%rbx        # 1f0f0 <fwp_tapes>
    7337:	48 83 c5 01          	add    $0x1,%rbp
    733b:	4c 01 e3             	add    %r12,%rbx
    733e:	49 83 c4 68          	add    $0x68,%r12
    7342:	48 89 df             	mov    %rbx,%rdi
    7345:	e8 26 c9 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    734a:	f3 0f 6f 43 30       	movdqu 0x30(%rbx),%xmm0
    734f:	f3 0f 6f 4b 20       	movdqu 0x20(%rbx),%xmm1
    7354:	48 89 e7             	mov    %rsp,%rdi
    7357:	48 8b 43 40          	mov    0x40(%rbx),%rax
    735b:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    735f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    7364:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7369:	f3 0f 7e 43 18       	movq   0x18(%rbx),%xmm0
    736e:	0f 16 43 48          	movhps 0x48(%rbx),%xmm0
    7372:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    7377:	e8 a4 dd ff ff       	call   5120 <fwp_tape_buffers_dispose>
    737c:	48 8b 7b 60          	mov    0x60(%rbx),%rdi
    7380:	e8 4b fe ff ff       	call   71d0 <fwp_owned_tape_release>
    7385:	48 39 2d 5c 7d 01 00 	cmp    %rbp,0x17d5c(%rip)        # 1f0e8 <fwp_ntapes>
    738c:	48 c7 43 60 00 00 00 	movq   $0x0,0x60(%rbx)
    7393:	00 
    7394:	7f 9a                	jg     7330 <fwp_tape_finish+0x50>
    7396:	48 8b 3d 53 7d 01 00 	mov    0x17d53(%rip),%rdi        # 1f0f0 <fwp_tapes>
    739d:	48 85 ff             	test   %rdi,%rdi
    73a0:	74 05                	je     73a7 <fwp_tape_finish+0xc7>
    73a2:	e8 09 dd ff ff       	call   50b0 <ad_raw_free.part.0>
    73a7:	48 c7 05 3e 7d 01 00 	movq   $0x0,0x17d3e(%rip)        # 1f0f0 <fwp_tapes>
    73ae:	00 00 00 00 
    73b2:	48 c7 05 23 7d 01 00 	movq   $0x0,0x17d23(%rip)        # 1f0e0 <fwp_tapes_cap>
    73b9:	00 00 00 00 
    73bd:	48 c7 05 20 7d 01 00 	movq   $0x0,0x17d20(%rip)        # 1f0e8 <fwp_ntapes>
    73c4:	00 00 00 00 
    73c8:	48 c7 05 05 7d 01 00 	movq   $0x0,0x17d05(%rip)        # 1f0d8 <fwp_tape_next_slot>
    73cf:	00 00 00 00 
    73d3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    73d8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    73df:	00 00 
    73e1:	75 0b                	jne    73ee <fwp_tape_finish+0x10e>
    73e3:	48 83 c4 48          	add    $0x48,%rsp
    73e7:	5b                   	pop    %rbx
    73e8:	5d                   	pop    %rbp
    73e9:	41 5c                	pop    %r12
    73eb:	41 5d                	pop    %r13
    73ed:	c3                   	ret
    73ee:	e8 5d c0 ff ff       	call   3450 <__stack_chk_fail@plt>
    73f3:	66 90                	xchg   %ax,%ax
    73f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    73fc:	00 00 00 00 

0000000000007400 <fwp_tape_scope_release>:
    7400:	f3 0f 1e fa          	endbr64
    7404:	41 55                	push   %r13
    7406:	41 54                	push   %r12
    7408:	55                   	push   %rbp
    7409:	53                   	push   %rbx
    740a:	48 83 ec 48          	sub    $0x48,%rsp
    740e:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    7415:	00 00 
    7417:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
    741c:	48 63 07             	movslq (%rdi),%rax
    741f:	85 c0                	test   %eax,%eax
    7421:	0f 88 e8 00 00 00    	js     750f <fwp_tape_scope_release+0x10f>
    7427:	49 bc c5 4e ec c4 4e 	movabs $0x4ec4ec4ec4ec4ec5,%r12
    742e:	ec c4 4e 
    7431:	48 89 fb             	mov    %rdi,%rbx
    7434:	48 89 e5             	mov    %rsp,%rbp
    7437:	eb 1f                	jmp    7458 <fwp_tape_scope_release+0x58>
    7439:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7440:	e8 db dc ff ff       	call   5120 <fwp_tape_buffers_dispose>
    7445:	4c 89 ef             	mov    %r13,%rdi
    7448:	e8 83 fd ff ff       	call   71d0 <fwp_owned_tape_release>
    744d:	48 63 03             	movslq (%rbx),%rax
    7450:	85 c0                	test   %eax,%eax
    7452:	0f 88 b7 00 00 00    	js     750f <fwp_tape_scope_release+0x10f>
    7458:	4c 6b c0 68          	imul   $0x68,%rax,%r8
    745c:	48 8b 35 8d 7c 01 00 	mov    0x17c8d(%rip),%rsi        # 1f0f0 <fwp_tapes>
    7463:	4c 01 c6             	add    %r8,%rsi
    7466:	48 89 f7             	mov    %rsi,%rdi
    7469:	e8 02 c8 ff ff       	call   3c70 <fwp_tape_unlink_scope>
    746e:	f3 0f 6f 46 30       	movdqu 0x30(%rsi),%xmm0
    7473:	f3 0f 6f 4e 20       	movdqu 0x20(%rsi),%xmm1
    7478:	c7 46 04 00 00 00 00 	movl   $0x0,0x4(%rsi)
    747f:	48 8b 46 40          	mov    0x40(%rsi),%rax
    7483:	4c 8b 6e 60          	mov    0x60(%rsi),%r13
    7487:	48 c7 46 40 00 00 00 	movq   $0x0,0x40(%rsi)
    748e:	00 
    748f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
    7494:	f3 0f 7e 46 18       	movq   0x18(%rsi),%xmm0
    7499:	0f 16 46 48          	movhps 0x48(%rsi),%xmm0
    749d:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
    74a2:	66 0f ef c0          	pxor   %xmm0,%xmm0
    74a6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    74ab:	48 c7 46 60 00 00 00 	movq   $0x0,0x60(%rsi)
    74b2:	00 
    74b3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    74ba:	00 
    74bb:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
    74c2:	00 
    74c3:	0f 29 0c 24          	movaps %xmm1,(%rsp)
    74c7:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
    74cb:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
    74cf:	0f 11 46 08          	movups %xmm0,0x8(%rsi)
    74d3:	81 3e fe 7f 00 00    	cmpl   $0x7ffe,(%rsi)
    74d9:	77 18                	ja     74f3 <fwp_tape_scope_release+0xf3>
    74db:	49 c1 f8 03          	sar    $0x3,%r8
    74df:	4d 0f af c4          	imul   %r12,%r8
    74e3:	4c 3b 05 ee 7b 01 00 	cmp    0x17bee(%rip),%r8        # 1f0d8 <fwp_tape_next_slot>
    74ea:	7d 07                	jge    74f3 <fwp_tape_scope_release+0xf3>
    74ec:	4c 89 05 e5 7b 01 00 	mov    %r8,0x17be5(%rip)        # 1f0d8 <fwp_tape_next_slot>
    74f3:	48 89 ef             	mov    %rbp,%rdi
    74f6:	4d 85 ed             	test   %r13,%r13
    74f9:	0f 85 41 ff ff ff    	jne    7440 <fwp_tape_scope_release+0x40>
    74ff:	e8 3c dd ff ff       	call   5240 <fwp_tape_buffers_release>
    7504:	48 63 03             	movslq (%rbx),%rax
    7507:	85 c0                	test   %eax,%eax
    7509:	0f 89 49 ff ff ff    	jns    7458 <fwp_tape_scope_release+0x58>
    750f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
    7514:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    751b:	00 00 
    751d:	75 0b                	jne    752a <fwp_tape_scope_release+0x12a>
    751f:	48 83 c4 48          	add    $0x48,%rsp
    7523:	5b                   	pop    %rbx
    7524:	5d                   	pop    %rbp
    7525:	41 5c                	pop    %r12
    7527:	41 5d                	pop    %r13
    7529:	c3                   	ret
    752a:	e8 21 bf ff ff       	call   3450 <__stack_chk_fail@plt>
    752f:	90                   	nop

0000000000007530 <fwp_drop4>:
    7530:	48 8b 0d c1 16 06 00 	mov    0x616c1(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7537:	48 89 f8             	mov    %rdi,%rax
    753a:	48 2b 05 8f 16 06 00 	sub    0x6168f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7541:	48 c1 e1 10          	shl    $0x10,%rcx
    7545:	48 39 c8             	cmp    %rcx,%rax
    7548:	0f 83 42 01 00 00    	jae    7690 <fwp_drop4+0x160>
    754e:	48 83 ec 18          	sub    $0x18,%rsp
    7552:	48 89 fa             	mov    %rdi,%rdx
    7555:	4c 8d 05 c4 02 06 00 	lea    0x602c4(%rip),%r8        # 67820 <fwp_heap>
    755c:	48 89 c1             	mov    %rax,%rcx
    755f:	4d 8b 88 f8 13 00 00 	mov    0x13f8(%r8),%r9
    7566:	48 c1 e9 10          	shr    $0x10,%rcx
    756a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    756e:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    7572:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7576:	48 85 c9             	test   %rcx,%rcx
    7579:	74 40                	je     75bb <fwp_drop4+0x8b>
    757b:	0f b6 3e             	movzbl (%rsi),%edi
    757e:	40 80 ff 02          	cmp    $0x2,%dil
    7582:	74 3c                	je     75c0 <fwp_drop4+0x90>
    7584:	40 80 ff 01          	cmp    $0x1,%dil
    7588:	75 31                	jne    75bb <fwp_drop4+0x8b>
    758a:	8b 7e 18             	mov    0x18(%rsi),%edi
    758d:	0f b7 c0             	movzwl %ax,%eax
    7590:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7593:	48 0f af c7          	imul   %rdi,%rax
    7597:	48 c1 e8 20          	shr    $0x20,%rax
    759b:	48 39 f0             	cmp    %rsi,%rax
    759e:	73 1b                	jae    75bb <fwp_drop4+0x8b>
    75a0:	48 01 c1             	add    %rax,%rcx
    75a3:	0f b6 01             	movzbl (%rcx),%eax
    75a6:	84 c0                	test   %al,%al
    75a8:	74 11                	je     75bb <fwp_drop4+0x8b>
    75aa:	3c 01                	cmp    $0x1,%al
    75ac:	74 22                	je     75d0 <fwp_drop4+0xa0>
    75ae:	3c ff                	cmp    $0xff,%al
    75b0:	0f 84 0a 01 00 00    	je     76c0 <fwp_drop4+0x190>
    75b6:	83 e8 01             	sub    $0x1,%eax
    75b9:	88 01                	mov    %al,(%rcx)
    75bb:	48 83 c4 18          	add    $0x18,%rsp
    75bf:	c3                   	ret
    75c0:	66 85 c0             	test   %ax,%ax
    75c3:	74 de                	je     75a3 <fwp_drop4+0x73>
    75c5:	48 83 c4 18          	add    $0x18,%rsp
    75c9:	c3                   	ret
    75ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    75d0:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    75d4:	49 8b 88 d8 13 00 00 	mov    0x13d8(%r8),%rcx
    75db:	48 89 f8             	mov    %rdi,%rax
    75de:	48 c1 e1 10          	shl    $0x10,%rcx
    75e2:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    75e9:	48 39 c8             	cmp    %rcx,%rax
    75ec:	73 62                	jae    7650 <fwp_drop4+0x120>
    75ee:	48 89 c1             	mov    %rax,%rcx
    75f1:	48 c1 e9 10          	shr    $0x10,%rcx
    75f5:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    75f9:	49 8d 34 c9          	lea    (%r9,%rcx,8),%rsi
    75fd:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    7601:	48 85 c9             	test   %rcx,%rcx
    7604:	74 4a                	je     7650 <fwp_drop4+0x120>
    7606:	44 0f b6 0e          	movzbl (%rsi),%r9d
    760a:	41 80 f9 02          	cmp    $0x2,%r9b
    760e:	0f 84 9c 00 00 00    	je     76b0 <fwp_drop4+0x180>
    7614:	41 80 f9 01          	cmp    $0x1,%r9b
    7618:	75 36                	jne    7650 <fwp_drop4+0x120>
    761a:	44 8b 4e 18          	mov    0x18(%rsi),%r9d
    761e:	0f b7 c0             	movzwl %ax,%eax
    7621:	8b 76 1c             	mov    0x1c(%rsi),%esi
    7624:	49 0f af c1          	imul   %r9,%rax
    7628:	48 c1 e8 20          	shr    $0x20,%rax
    762c:	48 39 f0             	cmp    %rsi,%rax
    762f:	73 1f                	jae    7650 <fwp_drop4+0x120>
    7631:	48 01 c1             	add    %rax,%rcx
    7634:	0f b6 01             	movzbl (%rcx),%eax
    7637:	84 c0                	test   %al,%al
    7639:	74 15                	je     7650 <fwp_drop4+0x120>
    763b:	3c 01                	cmp    $0x1,%al
    763d:	74 59                	je     7698 <fwp_drop4+0x168>
    763f:	3c ff                	cmp    $0xff,%al
    7641:	0f 84 ff 00 00 00    	je     7746 <fwp_drop4+0x216>
    7647:	83 e8 01             	sub    $0x1,%eax
    764a:	88 01                	mov    %al,(%rcx)
    764c:	0f 1f 40 00          	nopl   0x0(%rax)
    7650:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    7654:	48 89 d7             	mov    %rdx,%rdi
    7657:	48 89 0c 24          	mov    %rcx,(%rsp)
    765b:	e8 f0 f6 ff ff       	call   6d50 <fwp_rc_free_obj>
    7660:	4c 8d 05 b9 01 06 00 	lea    0x601b9(%rip),%r8        # 67820 <fwp_heap>
    7667:	48 8b 04 24          	mov    (%rsp),%rax
    766b:	49 8b 90 d8 13 00 00 	mov    0x13d8(%r8),%rdx
    7672:	49 2b 80 b0 13 00 00 	sub    0x13b0(%r8),%rax
    7679:	48 c1 e2 10          	shl    $0x10,%rdx
    767d:	48 39 d0             	cmp    %rdx,%rax
    7680:	0f 83 35 ff ff ff    	jae    75bb <fwp_drop4+0x8b>
    7686:	48 8b 14 24          	mov    (%rsp),%rdx
    768a:	e9 cd fe ff ff       	jmp    755c <fwp_drop4+0x2c>
    768f:	90                   	nop
    7690:	c3                   	ret
    7691:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7698:	48 89 14 24          	mov    %rdx,(%rsp)
    769c:	e8 af f6 ff ff       	call   6d50 <fwp_rc_free_obj>
    76a1:	48 8b 14 24          	mov    (%rsp),%rdx
    76a5:	eb a9                	jmp    7650 <fwp_drop4+0x120>
    76a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    76ae:	00 00 
    76b0:	66 85 c0             	test   %ax,%ax
    76b3:	75 9b                	jne    7650 <fwp_drop4+0x120>
    76b5:	e9 7a ff ff ff       	jmp    7634 <fwp_drop4+0x104>
    76ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    76c0:	48 89 c8             	mov    %rcx,%rax
    76c3:	48 c1 e8 11          	shr    $0x11,%rax
    76c7:	48 31 c8             	xor    %rcx,%rax
    76ca:	48 89 c2             	mov    %rax,%rdx
    76cd:	48 c1 ea 09          	shr    $0x9,%rdx
    76d1:	48 31 d0             	xor    %rdx,%rax
    76d4:	0f b6 d0             	movzbl %al,%edx
    76d7:	49 8b 84 d0 48 14 00 	mov    0x1448(%r8,%rdx,8),%rax
    76de:	00 
    76df:	48 85 c0             	test   %rax,%rax
    76e2:	75 29                	jne    770d <fwp_drop4+0x1dd>
    76e4:	e9 e3 00 00 00       	jmp    77cc <fwp_drop4+0x29c>
    76e9:	90                   	nop
    76ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76f1:	00 00 00 00 
    76f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    76fc:	00 00 00 00 
    7700:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7704:	48 85 c0             	test   %rax,%rax
    7707:	0f 84 bf 00 00 00    	je     77cc <fwp_drop4+0x29c>
    770d:	48 89 c2             	mov    %rax,%rdx
    7710:	48 39 08             	cmp    %rcx,(%rax)
    7713:	75 eb                	jne    7700 <fwp_drop4+0x1d0>
    7715:	48 8b 50 08          	mov    0x8(%rax),%rdx
    7719:	48 83 ea 01          	sub    $0x1,%rdx
    771d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7721:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7728:	0f 85 8d fe ff ff    	jne    75bb <fwp_drop4+0x8b>
    772e:	48 89 cf             	mov    %rcx,%rdi
    7731:	48 89 0c 24          	mov    %rcx,(%rsp)
    7735:	e8 76 e0 ff ff       	call   57b0 <fwp_rc_forget_slot>
    773a:	48 8b 0c 24          	mov    (%rsp),%rcx
    773e:	c6 01 fe             	movb   $0xfe,(%rcx)
    7741:	e9 75 fe ff ff       	jmp    75bb <fwp_drop4+0x8b>
    7746:	48 89 ce             	mov    %rcx,%rsi
    7749:	48 c1 ee 11          	shr    $0x11,%rsi
    774d:	48 31 ce             	xor    %rcx,%rsi
    7750:	48 89 f0             	mov    %rsi,%rax
    7753:	48 c1 e8 09          	shr    $0x9,%rax
    7757:	48 31 c6             	xor    %rax,%rsi
    775a:	40 0f b6 f6          	movzbl %sil,%esi
    775e:	49 8b 84 f0 48 14 00 	mov    0x1448(%r8,%rsi,8),%rax
    7765:	00 
    7766:	48 85 c0             	test   %rax,%rax
    7769:	75 1e                	jne    7789 <fwp_drop4+0x259>
    776b:	eb 5f                	jmp    77cc <fwp_drop4+0x29c>
    776d:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    7774:	00 
    7775:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    777c:	00 00 00 00 
    7780:	48 8b 46 10          	mov    0x10(%rsi),%rax
    7784:	48 85 c0             	test   %rax,%rax
    7787:	74 43                	je     77cc <fwp_drop4+0x29c>
    7789:	48 89 c6             	mov    %rax,%rsi
    778c:	48 39 08             	cmp    %rcx,(%rax)
    778f:	75 ef                	jne    7780 <fwp_drop4+0x250>
    7791:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7795:	48 83 ee 01          	sub    $0x1,%rsi
    7799:	48 89 70 08          	mov    %rsi,0x8(%rax)
    779d:	48 81 fe fe 00 00 00 	cmp    $0xfe,%rsi
    77a4:	0f 85 a6 fe ff ff    	jne    7650 <fwp_drop4+0x120>
    77aa:	48 89 cf             	mov    %rcx,%rdi
    77ad:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    77b2:	48 89 0c 24          	mov    %rcx,(%rsp)
    77b6:	e8 f5 df ff ff       	call   57b0 <fwp_rc_forget_slot>
    77bb:	48 8b 0c 24          	mov    (%rsp),%rcx
    77bf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    77c4:	c6 01 fe             	movb   $0xfe,(%rcx)
    77c7:	e9 84 fe ff ff       	jmp    7650 <fwp_drop4+0x120>
    77cc:	48 8d 3d d5 41 00 00 	lea    0x41d5(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    77d3:	e8 58 cc ff ff       	call   4430 <fwp_trap>
    77d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77df:	00 

00000000000077e0 <fwp_arg_drop37>:
    77e0:	f3 0f 1e fa          	endbr64
    77e4:	85 f6                	test   %esi,%esi
    77e6:	75 04                	jne    77ec <fwp_arg_drop37+0xc>
    77e8:	85 d2                	test   %edx,%edx
    77ea:	75 04                	jne    77f0 <fwp_arg_drop37+0x10>
    77ec:	c3                   	ret
    77ed:	0f 1f 00             	nopl   (%rax)
    77f0:	48 8b 3f             	mov    (%rdi),%rdi
    77f3:	e9 38 fd ff ff       	jmp    7530 <fwp_drop4>
    77f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    77ff:	00 

0000000000007800 <fwp_task_dispose>:
    7800:	53                   	push   %rbx
    7801:	80 7f 50 00          	cmpb   $0x0,0x50(%rdi)
    7805:	0f 84 1b bf ff ff    	je     3726 <fwp_task_dispose.cold>
    780b:	48 89 fb             	mov    %rdi,%rbx
    780e:	48 83 7f 10 00       	cmpq   $0x0,0x10(%rdi)
    7813:	0f 85 0d bf ff ff    	jne    3726 <fwp_task_dispose.cold>
    7819:	48 8b 7f 78          	mov    0x78(%rdi),%rdi
    781d:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    7824:	48 c7 43 78 00 00 00 	movq   $0x0,0x78(%rbx)
    782b:	00 
    782c:	c6 43 53 00          	movb   $0x0,0x53(%rbx)
    7830:	48 85 ff             	test   %rdi,%rdi
    7833:	74 07                	je     783c <fwp_task_dispose+0x3c>
    7835:	48 85 c0             	test   %rax,%rax
    7838:	74 02                	je     783c <fwp_task_dispose+0x3c>
    783a:	ff d0                	call   *%rax
    783c:	48 8b bb a8 00 00 00 	mov    0xa8(%rbx),%rdi
    7843:	e8 a8 e1 ff ff       	call   59f0 <fwp_mem_free>
    7848:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    784f:	00 00 00 00 
    7853:	83 7b 5c 01          	cmpl   $0x1,0x5c(%rbx)
    7857:	74 6f                	je     78c8 <fwp_task_dispose+0xc8>
    7859:	48 8b 15 98 13 06 00 	mov    0x61398(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7860:	48 89 d8             	mov    %rbx,%rax
    7863:	48 2b 05 66 13 06 00 	sub    0x61366(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    786a:	48 c1 e2 10          	shl    $0x10,%rdx
    786e:	48 39 d0             	cmp    %rdx,%rax
    7871:	73 4c                	jae    78bf <fwp_task_dispose+0xbf>
    7873:	48 89 c2             	mov    %rax,%rdx
    7876:	48 c1 ea 10          	shr    $0x10,%rdx
    787a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    787e:	48 8b 15 93 13 06 00 	mov    0x61393(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7885:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7889:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    788d:	48 85 c9             	test   %rcx,%rcx
    7890:	74 2d                	je     78bf <fwp_task_dispose+0xbf>
    7892:	0f b6 32             	movzbl (%rdx),%esi
    7895:	40 80 fe 02          	cmp    $0x2,%sil
    7899:	74 3d                	je     78d8 <fwp_task_dispose+0xd8>
    789b:	40 80 fe 01          	cmp    $0x1,%sil
    789f:	75 1e                	jne    78bf <fwp_task_dispose+0xbf>
    78a1:	8b 72 18             	mov    0x18(%rdx),%esi
    78a4:	0f b7 c0             	movzwl %ax,%eax
    78a7:	8b 52 1c             	mov    0x1c(%rdx),%edx
    78aa:	48 0f af c6          	imul   %rsi,%rax
    78ae:	48 c1 e8 20          	shr    $0x20,%rax
    78b2:	48 39 d0             	cmp    %rdx,%rax
    78b5:	73 08                	jae    78bf <fwp_task_dispose+0xbf>
    78b7:	48 01 c1             	add    %rax,%rcx
    78ba:	80 39 01             	cmpb   $0x1,(%rcx)
    78bd:	74 09                	je     78c8 <fwp_task_dispose+0xc8>
    78bf:	5b                   	pop    %rbx
    78c0:	c3                   	ret
    78c1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78c8:	48 89 df             	mov    %rbx,%rdi
    78cb:	5b                   	pop    %rbx
    78cc:	e9 1f e1 ff ff       	jmp    59f0 <fwp_mem_free>
    78d1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    78d8:	66 85 c0             	test   %ax,%ax
    78db:	74 dd                	je     78ba <fwp_task_dispose+0xba>
    78dd:	5b                   	pop    %rbx
    78de:	c3                   	ret
    78df:	90                   	nop

00000000000078e0 <fwp_free_zombie>:
    78e0:	48 8b 15 09 ff 05 00 	mov    0x5ff09(%rip),%rdx        # 677f0 <fwp_zombie>
    78e7:	48 85 d2             	test   %rdx,%rdx
    78ea:	0f 84 98 00 00 00    	je     7988 <fwp_free_zombie+0xa8>
    78f0:	48 3b 15 09 ff 05 00 	cmp    0x5ff09(%rip),%rdx        # 67800 <fwp_cur>
    78f7:	0f 84 8b 00 00 00    	je     7988 <fwp_free_zombie+0xa8>
    78fd:	48 83 ec 18          	sub    $0x18,%rsp
    7901:	48 63 05 cc f8 05 00 	movslq 0x5f8cc(%rip),%rax        # 671d4 <fwp_stack_pool_n>
    7908:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    790c:	83 f8 3f             	cmp    $0x3f,%eax
    790f:	7f 7f                	jg     7990 <fwp_free_zombie+0xb0>
    7911:	8d 48 01             	lea    0x1(%rax),%ecx
    7914:	89 0d ba f8 05 00    	mov    %ecx,0x5f8ba(%rip)        # 671d4 <fwp_stack_pool_n>
    791a:	48 8d 0d bf f8 05 00 	lea    0x5f8bf(%rip),%rcx        # 671e0 <fwp_stack_pool>
    7921:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
    7925:	48 8b 8a 30 01 00 00 	mov    0x130(%rdx),%rcx
    792c:	66 0f ef c0          	pxor   %xmm0,%xmm0
    7930:	48 8b 82 38 01 00 00 	mov    0x138(%rdx),%rax
    7937:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
    793b:	48 85 c9             	test   %rcx,%rcx
    793e:	0f 84 fc 00 00 00    	je     7a40 <fwp_free_zombie+0x160>
    7944:	48 89 81 38 01 00 00 	mov    %rax,0x138(%rcx)
    794b:	48 85 c0             	test   %rax,%rax
    794e:	74 07                	je     7957 <fwp_free_zombie+0x77>
    7950:	48 89 88 30 01 00 00 	mov    %rcx,0x130(%rax)
    7957:	8b 42 5c             	mov    0x5c(%rdx),%eax
    795a:	66 0f ef c0          	pxor   %xmm0,%xmm0
    795e:	48 c7 05 87 fe 05 00 	movq   $0x0,0x5fe87(%rip)        # 677f0 <fwp_zombie>
    7965:	00 00 00 00 
    7969:	0f 11 82 30 01 00 00 	movups %xmm0,0x130(%rdx)
    7970:	85 c0                	test   %eax,%eax
    7972:	74 34                	je     79a8 <fwp_free_zombie+0xc8>
    7974:	83 f8 01             	cmp    $0x1,%eax
    7977:	0f 84 b3 00 00 00    	je     7a30 <fwp_free_zombie+0x150>
    797d:	48 83 c4 18          	add    $0x18,%rsp
    7981:	c3                   	ret
    7982:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7988:	c3                   	ret
    7989:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7990:	48 8b 72 18          	mov    0x18(%rdx),%rsi
    7994:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    7999:	e8 22 bc ff ff       	call   35c0 <munmap@plt>
    799e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    79a3:	eb 80                	jmp    7925 <fwp_free_zombie+0x45>
    79a5:	0f 1f 00             	nopl   (%rax)
    79a8:	48 8b 0d 49 12 06 00 	mov    0x61249(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    79af:	48 89 d0             	mov    %rdx,%rax
    79b2:	48 2b 05 17 12 06 00 	sub    0x61217(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    79b9:	48 c1 e1 10          	shl    $0x10,%rcx
    79bd:	48 39 c8             	cmp    %rcx,%rax
    79c0:	73 bb                	jae    797d <fwp_free_zombie+0x9d>
    79c2:	48 89 c1             	mov    %rax,%rcx
    79c5:	48 c1 e9 10          	shr    $0x10,%rcx
    79c9:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    79cd:	48 8b 0d 44 12 06 00 	mov    0x61244(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    79d4:	48 8d 34 f1          	lea    (%rcx,%rsi,8),%rsi
    79d8:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
    79dc:	48 85 c9             	test   %rcx,%rcx
    79df:	74 9c                	je     797d <fwp_free_zombie+0x9d>
    79e1:	0f b6 3e             	movzbl (%rsi),%edi
    79e4:	40 80 ff 02          	cmp    $0x2,%dil
    79e8:	74 66                	je     7a50 <fwp_free_zombie+0x170>
    79ea:	40 80 ff 01          	cmp    $0x1,%dil
    79ee:	75 8d                	jne    797d <fwp_free_zombie+0x9d>
    79f0:	8b 7e 18             	mov    0x18(%rsi),%edi
    79f3:	0f b7 c0             	movzwl %ax,%eax
    79f6:	8b 76 1c             	mov    0x1c(%rsi),%esi
    79f9:	48 0f af c7          	imul   %rdi,%rax
    79fd:	48 c1 e8 20          	shr    $0x20,%rax
    7a01:	48 39 f0             	cmp    %rsi,%rax
    7a04:	0f 83 73 ff ff ff    	jae    797d <fwp_free_zombie+0x9d>
    7a0a:	48 01 c1             	add    %rax,%rcx
    7a0d:	0f b6 01             	movzbl (%rcx),%eax
    7a10:	84 c0                	test   %al,%al
    7a12:	0f 84 65 ff ff ff    	je     797d <fwp_free_zombie+0x9d>
    7a18:	3c 01                	cmp    $0x1,%al
    7a1a:	74 14                	je     7a30 <fwp_free_zombie+0x150>
    7a1c:	3c ff                	cmp    $0xff,%al
    7a1e:	74 3b                	je     7a5b <fwp_free_zombie+0x17b>
    7a20:	83 e8 01             	sub    $0x1,%eax
    7a23:	88 01                	mov    %al,(%rcx)
    7a25:	e9 53 ff ff ff       	jmp    797d <fwp_free_zombie+0x9d>
    7a2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7a30:	48 89 d7             	mov    %rdx,%rdi
    7a33:	48 83 c4 18          	add    $0x18,%rsp
    7a37:	e9 c4 fd ff ff       	jmp    7800 <fwp_task_dispose>
    7a3c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a40:	48 89 05 81 fd 05 00 	mov    %rax,0x5fd81(%rip)        # 677c8 <fwp_tasks_active>
    7a47:	e9 ff fe ff ff       	jmp    794b <fwp_free_zombie+0x6b>
    7a4c:	0f 1f 40 00          	nopl   0x0(%rax)
    7a50:	66 85 c0             	test   %ax,%ax
    7a53:	0f 85 24 ff ff ff    	jne    797d <fwp_free_zombie+0x9d>
    7a59:	eb b2                	jmp    7a0d <fwp_free_zombie+0x12d>
    7a5b:	48 89 ca             	mov    %rcx,%rdx
    7a5e:	48 8d 35 bb fd 05 00 	lea    0x5fdbb(%rip),%rsi        # 67820 <fwp_heap>
    7a65:	48 c1 ea 11          	shr    $0x11,%rdx
    7a69:	48 31 ca             	xor    %rcx,%rdx
    7a6c:	48 89 d0             	mov    %rdx,%rax
    7a6f:	48 c1 e8 09          	shr    $0x9,%rax
    7a73:	48 31 c2             	xor    %rax,%rdx
    7a76:	0f b6 d2             	movzbl %dl,%edx
    7a79:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    7a80:	00 
    7a81:	48 85 c0             	test   %rax,%rax
    7a84:	75 23                	jne    7aa9 <fwp_free_zombie+0x1c9>
    7a86:	eb 5c                	jmp    7ae4 <fwp_free_zombie+0x204>
    7a88:	66 90                	xchg   %ax,%ax
    7a8a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a91:	00 00 00 00 
    7a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7a9c:	00 00 00 00 
    7aa0:	48 8b 42 10          	mov    0x10(%rdx),%rax
    7aa4:	48 85 c0             	test   %rax,%rax
    7aa7:	74 3b                	je     7ae4 <fwp_free_zombie+0x204>
    7aa9:	48 89 c2             	mov    %rax,%rdx
    7aac:	48 39 08             	cmp    %rcx,(%rax)
    7aaf:	75 ef                	jne    7aa0 <fwp_free_zombie+0x1c0>
    7ab1:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7ab5:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    7ab9:	48 89 50 08          	mov    %rdx,0x8(%rax)
    7abd:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    7ac4:	0f 85 b3 fe ff ff    	jne    797d <fwp_free_zombie+0x9d>
    7aca:	48 89 cf             	mov    %rcx,%rdi
    7acd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    7ad2:	e8 d9 dc ff ff       	call   57b0 <fwp_rc_forget_slot>
    7ad7:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    7adc:	c6 01 fe             	movb   $0xfe,(%rcx)
    7adf:	e9 99 fe ff ff       	jmp    797d <fwp_free_zombie+0x9d>
    7ae4:	48 8d 3d bd 3e 00 00 	lea    0x3ebd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    7aeb:	e8 40 c9 ff ff       	call   4430 <fwp_trap>

0000000000007af0 <fwp_block>:
    7af0:	48 83 ec 08          	sub    $0x8,%rsp
    7af4:	48 8b 05 ed fc 05 00 	mov    0x5fced(%rip),%rax        # 677e8 <fwp_ready_head>
    7afb:	48 85 c0             	test   %rax,%rax
    7afe:	0f 84 1c 01 00 00    	je     7c20 <fwp_block+0x130>
    7b04:	90                   	nop
    7b05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    7b0c:	00 00 00 00 
    7b10:	48 8b 90 00 01 00 00 	mov    0x100(%rax),%rdx
    7b17:	48 89 15 ca fc 05 00 	mov    %rdx,0x5fcca(%rip)        # 677e8 <fwp_ready_head>
    7b1e:	48 85 d2             	test   %rdx,%rdx
    7b21:	0f 84 19 01 00 00    	je     7c40 <fwp_block+0x150>
    7b27:	48 8b 15 d2 fc 05 00 	mov    0x5fcd2(%rip),%rdx        # 67800 <fwp_cur>
    7b2e:	c6 40 54 00          	movb   $0x0,0x54(%rax)
    7b32:	48 39 c2             	cmp    %rax,%rdx
    7b35:	0f 84 d5 00 00 00    	je     7c10 <fwp_block+0x120>
    7b3b:	48 8b 0d 46 19 06 00 	mov    0x61946(%rip),%rcx        # 69488 <fwp_state_owners>
    7b42:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
    7b46:	48 89 05 b3 fc 05 00 	mov    %rax,0x5fcb3(%rip)        # 67800 <fwp_cur>
    7b4d:	f3 0f 7e 05 5b 19 06 	movq   0x6195b(%rip),%xmm0        # 694b0 <fwp_foreign_callbacks>
    7b54:	00 
    7b55:	0f 16 05 44 19 06 00 	movhps 0x61944(%rip),%xmm0        # 694a0 <fwp_state>
    7b5c:	f3 0f 7e 0d 44 19 06 	movq   0x61944(%rip),%xmm1        # 694a8 <fwp_handlers>
    7b63:	00 
    7b64:	0f 11 82 a0 00 00 00 	movups %xmm0,0xa0(%rdx)
    7b6b:	48 89 8a c0 00 00 00 	mov    %rcx,0xc0(%rdx)
    7b72:	0f 16 0d 3f 19 06 00 	movhps 0x6193f(%rip),%xmm1        # 694b8 <fwp_cleanups>
    7b79:	f3 0f 7e 05 17 19 06 	movq   0x61917(%rip),%xmm0        # 69498 <fwp_state_len>
    7b80:	00 
    7b81:	0f 16 05 08 19 06 00 	movhps 0x61908(%rip),%xmm0        # 69490 <fwp_state_cap>
    7b88:	0f 11 8a 90 00 00 00 	movups %xmm1,0x90(%rdx)
    7b8f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
    7b96:	48 8b 70 08          	mov    0x8(%rax),%rsi
    7b9a:	0f 11 82 b0 00 00 00 	movups %xmm0,0xb0(%rdx)
    7ba1:	48 89 0d 00 19 06 00 	mov    %rcx,0x61900(%rip)        # 694a8 <fwp_handlers>
    7ba8:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
    7baf:	48 89 0d 02 19 06 00 	mov    %rcx,0x61902(%rip)        # 694b8 <fwp_cleanups>
    7bb6:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
    7bbd:	48 89 0d ec 18 06 00 	mov    %rcx,0x618ec(%rip)        # 694b0 <fwp_foreign_callbacks>
    7bc4:	48 8b 88 a8 00 00 00 	mov    0xa8(%rax),%rcx
    7bcb:	48 89 0d ce 18 06 00 	mov    %rcx,0x618ce(%rip)        # 694a0 <fwp_state>
    7bd2:	48 8b 88 b0 00 00 00 	mov    0xb0(%rax),%rcx
    7bd9:	48 89 0d b8 18 06 00 	mov    %rcx,0x618b8(%rip)        # 69498 <fwp_state_len>
    7be0:	48 8b 88 b8 00 00 00 	mov    0xb8(%rax),%rcx
    7be7:	48 89 0d a2 18 06 00 	mov    %rcx,0x618a2(%rip)        # 69490 <fwp_state_cap>
    7bee:	48 8b 88 c0 00 00 00 	mov    0xc0(%rax),%rcx
    7bf5:	48 89 0d 8c 18 06 00 	mov    %rcx,0x6188c(%rip)        # 69488 <fwp_state_owners>
    7bfc:	e8 7f b8 ff ff       	call   3480 <swapcontext@plt>
    7c01:	f3 0f 1e fa          	endbr64
    7c05:	e8 d6 fc ff ff       	call   78e0 <fwp_free_zombie>
    7c0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7c10:	8b 05 ba f5 05 00    	mov    0x5f5ba(%rip),%eax        # 671d0 <fwp_slice>
    7c16:	85 c0                	test   %eax,%eax
    7c18:	74 36                	je     7c50 <fwp_block+0x160>
    7c1a:	48 83 c4 08          	add    $0x8,%rsp
    7c1e:	c3                   	ret
    7c1f:	90                   	nop
    7c20:	e8 cb d7 ff ff       	call   53f0 <fwp_poll_events>
    7c25:	48 8b 05 bc fb 05 00 	mov    0x5fbbc(%rip),%rax        # 677e8 <fwp_ready_head>
    7c2c:	48 85 c0             	test   %rax,%rax
    7c2f:	0f 85 db fe ff ff    	jne    7b10 <fwp_block+0x20>
    7c35:	eb e9                	jmp    7c20 <fwp_block+0x130>
    7c37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7c3e:	00 00 
    7c40:	48 c7 05 95 fb 05 00 	movq   $0x0,0x5fb95(%rip)        # 677e0 <fwp_ready_tail>
    7c47:	00 00 00 00 
    7c4b:	e9 d7 fe ff ff       	jmp    7b27 <fwp_block+0x37>
    7c50:	48 8d 3d 88 35 00 00 	lea    0x3588(%rip),%rdi        # b1df <_IO_stdin_used+0x1df>
    7c57:	e8 34 b7 ff ff       	call   3390 <getenv@plt>
    7c5c:	ba 10 27 00 00       	mov    $0x2710,%edx
    7c61:	48 85 c0             	test   %rax,%rax
    7c64:	74 05                	je     7c6b <fwp_block+0x17b>
    7c66:	80 38 00             	cmpb   $0x0,(%rax)
    7c69:	75 0b                	jne    7c76 <fwp_block+0x186>
    7c6b:	89 15 5f f5 05 00    	mov    %edx,0x5f55f(%rip)        # 671d0 <fwp_slice>
    7c71:	48 83 c4 08          	add    $0x8,%rsp
    7c75:	c3                   	ret
    7c76:	ba 0a 00 00 00       	mov    $0xa,%edx
    7c7b:	31 f6                	xor    %esi,%esi
    7c7d:	48 89 c7             	mov    %rax,%rdi
    7c80:	e8 bb b8 ff ff       	call   3540 <strtoll@plt>
    7c85:	48 8d 50 ff          	lea    -0x1(%rax),%rdx
    7c89:	48 81 fa fe ff ff 7f 	cmp    $0x7ffffffe,%rdx
    7c90:	ba ff ff ff 7f       	mov    $0x7fffffff,%edx
    7c95:	0f 46 d0             	cmovbe %eax,%edx
    7c98:	eb d1                	jmp    7c6b <fwp_block+0x17b>
    7c9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)

0000000000007ca0 <fwp_caps173>:
    7ca0:	f3 0f 1e fa          	endbr64
    7ca4:	85 f6                	test   %esi,%esi
    7ca6:	74 08                	je     7cb0 <fwp_caps173+0x10>
    7ca8:	c3                   	ret
    7ca9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    7cb0:	48 8b 15 41 0f 06 00 	mov    0x60f41(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7cb7:	48 89 f8             	mov    %rdi,%rax
    7cba:	48 2b 05 0f 0f 06 00 	sub    0x60f0f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7cc1:	48 c1 e2 10          	shl    $0x10,%rdx
    7cc5:	48 39 d0             	cmp    %rdx,%rax
    7cc8:	73 de                	jae    7ca8 <fwp_caps173+0x8>
    7cca:	48 89 c2             	mov    %rax,%rdx
    7ccd:	48 c1 ea 10          	shr    $0x10,%rdx
    7cd1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7cd5:	48 8b 15 3c 0f 06 00 	mov    0x60f3c(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7cdc:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7ce0:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
    7ce4:	48 85 c9             	test   %rcx,%rcx
    7ce7:	74 bf                	je     7ca8 <fwp_caps173+0x8>
    7ce9:	0f b6 32             	movzbl (%rdx),%esi
    7cec:	40 80 fe 02          	cmp    $0x2,%sil
    7cf0:	74 2e                	je     7d20 <fwp_caps173+0x80>
    7cf2:	40 80 fe 01          	cmp    $0x1,%sil
    7cf6:	75 b0                	jne    7ca8 <fwp_caps173+0x8>
    7cf8:	8b 72 18             	mov    0x18(%rdx),%esi
    7cfb:	0f b7 c0             	movzwl %ax,%eax
    7cfe:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d01:	48 0f af c6          	imul   %rsi,%rax
    7d05:	48 c1 e8 20          	shr    $0x20,%rax
    7d09:	48 39 d0             	cmp    %rdx,%rax
    7d0c:	73 9a                	jae    7ca8 <fwp_caps173+0x8>
    7d0e:	48 01 c1             	add    %rax,%rcx
    7d11:	80 39 01             	cmpb   $0x1,(%rcx)
    7d14:	75 92                	jne    7ca8 <fwp_caps173+0x8>
    7d16:	e9 d5 dc ff ff       	jmp    59f0 <fwp_mem_free>
    7d1b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7d20:	66 85 c0             	test   %ax,%ax
    7d23:	74 ec                	je     7d11 <fwp_caps173+0x71>
    7d25:	c3                   	ret
    7d26:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7d2d:	00 00 00 

0000000000007d30 <fwp_args37>:
    7d30:	f3 0f 1e fa          	endbr64
    7d34:	85 d2                	test   %edx,%edx
    7d36:	74 04                	je     7d3c <fwp_args37+0xc>
    7d38:	85 f6                	test   %esi,%esi
    7d3a:	74 04                	je     7d40 <fwp_args37+0x10>
    7d3c:	c3                   	ret
    7d3d:	0f 1f 00             	nopl   (%rax)
    7d40:	48 8b 15 b1 0e 06 00 	mov    0x60eb1(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7d47:	48 8b 07             	mov    (%rdi),%rax
    7d4a:	48 2b 05 7f 0e 06 00 	sub    0x60e7f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7d51:	48 c1 e2 10          	shl    $0x10,%rdx
    7d55:	48 39 d0             	cmp    %rdx,%rax
    7d58:	73 e2                	jae    7d3c <fwp_args37+0xc>
    7d5a:	48 89 c2             	mov    %rax,%rdx
    7d5d:	48 c1 ea 10          	shr    $0x10,%rdx
    7d61:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    7d65:	48 8b 15 ac 0e 06 00 	mov    0x60eac(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    7d6c:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    7d70:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    7d74:	48 85 ff             	test   %rdi,%rdi
    7d77:	74 c3                	je     7d3c <fwp_args37+0xc>
    7d79:	0f b6 0a             	movzbl (%rdx),%ecx
    7d7c:	80 f9 02             	cmp    $0x2,%cl
    7d7f:	74 4f                	je     7dd0 <fwp_args37+0xa0>
    7d81:	80 f9 01             	cmp    $0x1,%cl
    7d84:	75 b6                	jne    7d3c <fwp_args37+0xc>
    7d86:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7d89:	0f b7 c0             	movzwl %ax,%eax
    7d8c:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7d8f:	48 0f af c1          	imul   %rcx,%rax
    7d93:	48 c1 e8 20          	shr    $0x20,%rax
    7d97:	48 39 d0             	cmp    %rdx,%rax
    7d9a:	73 a0                	jae    7d3c <fwp_args37+0xc>
    7d9c:	48 01 c7             	add    %rax,%rdi
    7d9f:	0f b6 07             	movzbl (%rdi),%eax
    7da2:	84 c0                	test   %al,%al
    7da4:	74 96                	je     7d3c <fwp_args37+0xc>
    7da6:	8b 15 3c 17 06 00    	mov    0x6173c(%rip),%edx        # 694e8 <iteration_active>
    7dac:	85 d2                	test   %edx,%edx
    7dae:	75 10                	jne    7dc0 <fwp_args37+0x90>
    7db0:	3c fd                	cmp    $0xfd,%al
    7db2:	77 22                	ja     7dd6 <fwp_args37+0xa6>
    7db4:	83 c0 01             	add    $0x1,%eax
    7db7:	88 07                	mov    %al,(%rdi)
    7db9:	c3                   	ret
    7dba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7dc0:	48 83 05 08 17 06 00 	addq   $0x1,0x61708(%rip)        # 694d0 <iteration_retains>
    7dc7:	01 
    7dc8:	eb e6                	jmp    7db0 <fwp_args37+0x80>
    7dca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    7dd0:	66 85 c0             	test   %ax,%ax
    7dd3:	74 ca                	je     7d9f <fwp_args37+0x6f>
    7dd5:	c3                   	ret
    7dd6:	e9 b5 d8 ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7ddb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)

0000000000007de0 <fwp_caps37>:
    7de0:	f3 0f 1e fa          	endbr64
    7de4:	48 83 ec 18          	sub    $0x18,%rsp
    7de8:	48 89 f8             	mov    %rdi,%rax
    7deb:	8b 7f 04             	mov    0x4(%rdi),%edi
    7dee:	85 ff                	test   %edi,%edi
    7df0:	0f 84 9a 00 00 00    	je     7e90 <fwp_caps37+0xb0>
    7df6:	48 8b 78 08          	mov    0x8(%rax),%rdi
    7dfa:	85 f6                	test   %esi,%esi
    7dfc:	0f 85 9e 00 00 00    	jne    7ea0 <fwp_caps37+0xc0>
    7e02:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    7e07:	e8 24 f7 ff ff       	call   7530 <fwp_drop4>
    7e0c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    7e11:	48 8b 0d e0 0d 06 00 	mov    0x60de0(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    7e18:	48 89 c2             	mov    %rax,%rdx
    7e1b:	48 2b 15 ae 0d 06 00 	sub    0x60dae(%rip),%rdx        # 68bd0 <fwp_heap+0x13b0>
    7e22:	48 c1 e1 10          	shl    $0x10,%rcx
    7e26:	48 39 ca             	cmp    %rcx,%rdx
    7e29:	73 6d                	jae    7e98 <fwp_caps37+0xb8>
    7e2b:	48 89 d1             	mov    %rdx,%rcx
    7e2e:	48 c1 e9 10          	shr    $0x10,%rcx
    7e32:	48 8d 34 89          	lea    (%rcx,%rcx,4),%rsi
    7e36:	48 8b 0d db 0d 06 00 	mov    0x60ddb(%rip),%rcx        # 68c18 <fwp_heap+0x13f8>
    7e3d:	48 8d 0c f1          	lea    (%rcx,%rsi,8),%rcx
    7e41:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    7e45:	48 85 f6             	test   %rsi,%rsi
    7e48:	74 4e                	je     7e98 <fwp_caps37+0xb8>
    7e4a:	0f b6 39             	movzbl (%rcx),%edi
    7e4d:	40 80 ff 02          	cmp    $0x2,%dil
    7e51:	0f 84 c9 00 00 00    	je     7f20 <fwp_caps37+0x140>
    7e57:	40 80 ff 01          	cmp    $0x1,%dil
    7e5b:	75 3b                	jne    7e98 <fwp_caps37+0xb8>
    7e5d:	8b 79 18             	mov    0x18(%rcx),%edi
    7e60:	0f b7 d2             	movzwl %dx,%edx
    7e63:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7e66:	48 0f af d7          	imul   %rdi,%rdx
    7e6a:	48 c1 ea 20          	shr    $0x20,%rdx
    7e6e:	48 39 ca             	cmp    %rcx,%rdx
    7e71:	73 25                	jae    7e98 <fwp_caps37+0xb8>
    7e73:	48 01 d6             	add    %rdx,%rsi
    7e76:	80 3e 01             	cmpb   $0x1,(%rsi)
    7e79:	75 1d                	jne    7e98 <fwp_caps37+0xb8>
    7e7b:	48 89 c7             	mov    %rax,%rdi
    7e7e:	48 83 c4 18          	add    $0x18,%rsp
    7e82:	e9 69 db ff ff       	jmp    59f0 <fwp_mem_free>
    7e87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    7e8e:	00 00 
    7e90:	85 f6                	test   %esi,%esi
    7e92:	0f 84 79 ff ff ff    	je     7e11 <fwp_caps37+0x31>
    7e98:	48 83 c4 18          	add    $0x18,%rsp
    7e9c:	c3                   	ret
    7e9d:	0f 1f 00             	nopl   (%rax)
    7ea0:	48 8b 05 51 0d 06 00 	mov    0x60d51(%rip),%rax        # 68bf8 <fwp_heap+0x13d8>
    7ea7:	48 2b 3d 22 0d 06 00 	sub    0x60d22(%rip),%rdi        # 68bd0 <fwp_heap+0x13b0>
    7eae:	48 c1 e0 10          	shl    $0x10,%rax
    7eb2:	48 39 c7             	cmp    %rax,%rdi
    7eb5:	73 e1                	jae    7e98 <fwp_caps37+0xb8>
    7eb7:	48 89 f8             	mov    %rdi,%rax
    7eba:	48 c1 e8 10          	shr    $0x10,%rax
    7ebe:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    7ec2:	48 8b 05 4f 0d 06 00 	mov    0x60d4f(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    7ec9:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    7ecd:	48 8b 42 20          	mov    0x20(%rdx),%rax
    7ed1:	48 85 c0             	test   %rax,%rax
    7ed4:	74 c2                	je     7e98 <fwp_caps37+0xb8>
    7ed6:	0f b6 0a             	movzbl (%rdx),%ecx
    7ed9:	80 f9 02             	cmp    $0x2,%cl
    7edc:	74 52                	je     7f30 <fwp_caps37+0x150>
    7ede:	80 f9 01             	cmp    $0x1,%cl
    7ee1:	75 b5                	jne    7e98 <fwp_caps37+0xb8>
    7ee3:	8b 4a 18             	mov    0x18(%rdx),%ecx
    7ee6:	0f b7 ff             	movzwl %di,%edi
    7ee9:	8b 52 1c             	mov    0x1c(%rdx),%edx
    7eec:	48 0f af f9          	imul   %rcx,%rdi
    7ef0:	48 c1 ef 20          	shr    $0x20,%rdi
    7ef4:	48 39 d7             	cmp    %rdx,%rdi
    7ef7:	73 9f                	jae    7e98 <fwp_caps37+0xb8>
    7ef9:	48 01 f8             	add    %rdi,%rax
    7efc:	0f b6 10             	movzbl (%rax),%edx
    7eff:	84 d2                	test   %dl,%dl
    7f01:	74 95                	je     7e98 <fwp_caps37+0xb8>
    7f03:	8b 0d df 15 06 00    	mov    0x615df(%rip),%ecx        # 694e8 <iteration_active>
    7f09:	85 c9                	test   %ecx,%ecx
    7f0b:	75 33                	jne    7f40 <fwp_caps37+0x160>
    7f0d:	80 fa fd             	cmp    $0xfd,%dl
    7f10:	77 38                	ja     7f4a <fwp_caps37+0x16a>
    7f12:	83 c2 01             	add    $0x1,%edx
    7f15:	88 10                	mov    %dl,(%rax)
    7f17:	e9 7c ff ff ff       	jmp    7e98 <fwp_caps37+0xb8>
    7f1c:	0f 1f 40 00          	nopl   0x0(%rax)
    7f20:	66 85 d2             	test   %dx,%dx
    7f23:	0f 85 6f ff ff ff    	jne    7e98 <fwp_caps37+0xb8>
    7f29:	e9 48 ff ff ff       	jmp    7e76 <fwp_caps37+0x96>
    7f2e:	66 90                	xchg   %ax,%ax
    7f30:	66 85 ff             	test   %di,%di
    7f33:	0f 85 5f ff ff ff    	jne    7e98 <fwp_caps37+0xb8>
    7f39:	eb c1                	jmp    7efc <fwp_caps37+0x11c>
    7f3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7f40:	48 83 05 88 15 06 00 	addq   $0x1,0x61588(%rip)        # 694d0 <iteration_retains>
    7f47:	01 
    7f48:	eb c3                	jmp    7f0d <fwp_caps37+0x12d>
    7f4a:	48 89 c7             	mov    %rax,%rdi
    7f4d:	48 83 c4 18          	add    $0x18,%rsp
    7f51:	e9 3a d7 ff ff       	jmp    5690 <fwp_rc_wide_dup>
    7f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    7f5d:	00 00 00 

0000000000007f60 <fwp_drop0>:
    7f60:	f3 0f 1e fa          	endbr64
    7f64:	48 8b 15 8d 0c 06 00 	mov    0x60c8d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    7f6b:	48 89 f8             	mov    %rdi,%rax
    7f6e:	48 2b 05 5b 0c 06 00 	sub    0x60c5b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    7f75:	48 c1 e2 10          	shl    $0x10,%rdx
    7f79:	48 39 d0             	cmp    %rdx,%rax
    7f7c:	0f 83 36 01 00 00    	jae    80b8 <fwp_drop0+0x158>
    7f82:	48 83 ec 18          	sub    $0x18,%rsp
    7f86:	48 8d 35 93 f8 05 00 	lea    0x5f893(%rip),%rsi        # 67820 <fwp_heap>
    7f8d:	48 89 c2             	mov    %rax,%rdx
    7f90:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    7f97:	48 c1 ea 10          	shr    $0x10,%rdx
    7f9b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    7f9f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    7fa3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    7fa7:	48 85 d2             	test   %rdx,%rdx
    7faa:	74 42                	je     7fee <fwp_drop0+0x8e>
    7fac:	44 0f b6 01          	movzbl (%rcx),%r8d
    7fb0:	41 80 f8 02          	cmp    $0x2,%r8b
    7fb4:	74 42                	je     7ff8 <fwp_drop0+0x98>
    7fb6:	41 80 f8 01          	cmp    $0x1,%r8b
    7fba:	75 32                	jne    7fee <fwp_drop0+0x8e>
    7fbc:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    7fc0:	0f b7 c0             	movzwl %ax,%eax
    7fc3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    7fc6:	49 0f af c0          	imul   %r8,%rax
    7fca:	48 c1 e8 20          	shr    $0x20,%rax
    7fce:	48 39 c8             	cmp    %rcx,%rax
    7fd1:	73 1b                	jae    7fee <fwp_drop0+0x8e>
    7fd3:	48 01 c2             	add    %rax,%rdx
    7fd6:	0f b6 02             	movzbl (%rdx),%eax
    7fd9:	84 c0                	test   %al,%al
    7fdb:	74 11                	je     7fee <fwp_drop0+0x8e>
    7fdd:	3c 01                	cmp    $0x1,%al
    7fdf:	74 27                	je     8008 <fwp_drop0+0xa8>
    7fe1:	3c ff                	cmp    $0xff,%al
    7fe3:	0f 84 e7 00 00 00    	je     80d0 <fwp_drop0+0x170>
    7fe9:	83 e8 01             	sub    $0x1,%eax
    7fec:	88 02                	mov    %al,(%rdx)
    7fee:	48 83 c4 18          	add    $0x18,%rsp
    7ff2:	c3                   	ret
    7ff3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    7ff8:	66 85 c0             	test   %ax,%ax
    7ffb:	74 d9                	je     7fd6 <fwp_drop0+0x76>
    7ffd:	48 83 c4 18          	add    $0x18,%rsp
    8001:	c3                   	ret
    8002:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8008:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    800f:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8016:	48 89 f8             	mov    %rdi,%rax
    8019:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    801d:	48 29 c8             	sub    %rcx,%rax
    8020:	48 c1 e2 10          	shl    $0x10,%rdx
    8024:	48 39 d0             	cmp    %rdx,%rax
    8027:	73 71                	jae    809a <fwp_drop0+0x13a>
    8029:	49 89 c2             	mov    %rax,%r10
    802c:	49 c1 ea 10          	shr    $0x10,%r10
    8030:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8034:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8038:	4d 8b 51 20          	mov    0x20(%r9),%r10
    803c:	4d 85 d2             	test   %r10,%r10
    803f:	74 59                	je     809a <fwp_drop0+0x13a>
    8041:	45 0f b6 19          	movzbl (%r9),%r11d
    8045:	41 80 fb 02          	cmp    $0x2,%r11b
    8049:	74 75                	je     80c0 <fwp_drop0+0x160>
    804b:	41 80 fb 01          	cmp    $0x1,%r11b
    804f:	75 49                	jne    809a <fwp_drop0+0x13a>
    8051:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8055:	0f b7 c0             	movzwl %ax,%eax
    8058:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    805c:	49 0f af c3          	imul   %r11,%rax
    8060:	48 c1 e8 20          	shr    $0x20,%rax
    8064:	4c 39 c8             	cmp    %r9,%rax
    8067:	73 31                	jae    809a <fwp_drop0+0x13a>
    8069:	49 01 c2             	add    %rax,%r10
    806c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8070:	75 28                	jne    809a <fwp_drop0+0x13a>
    8072:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8077:	e8 74 d9 ff ff       	call   59f0 <fwp_mem_free>
    807c:	48 8d 35 9d f7 05 00 	lea    0x5f79d(%rip),%rsi        # 67820 <fwp_heap>
    8083:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8088:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    808f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8096:	48 c1 e2 10          	shl    $0x10,%rdx
    809a:	4c 89 c0             	mov    %r8,%rax
    809d:	48 29 c8             	sub    %rcx,%rax
    80a0:	48 39 d0             	cmp    %rdx,%rax
    80a3:	0f 83 45 ff ff ff    	jae    7fee <fwp_drop0+0x8e>
    80a9:	4c 89 c7             	mov    %r8,%rdi
    80ac:	e9 dc fe ff ff       	jmp    7f8d <fwp_drop0+0x2d>
    80b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80b8:	c3                   	ret
    80b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    80c0:	66 85 c0             	test   %ax,%ax
    80c3:	75 d5                	jne    809a <fwp_drop0+0x13a>
    80c5:	eb a5                	jmp    806c <fwp_drop0+0x10c>
    80c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    80ce:	00 00 
    80d0:	48 89 d0             	mov    %rdx,%rax
    80d3:	48 c1 e8 11          	shr    $0x11,%rax
    80d7:	48 31 d0             	xor    %rdx,%rax
    80da:	48 89 c1             	mov    %rax,%rcx
    80dd:	48 c1 e9 09          	shr    $0x9,%rcx
    80e1:	48 31 c8             	xor    %rcx,%rax
    80e4:	0f b6 c8             	movzbl %al,%ecx
    80e7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    80ee:	00 
    80ef:	48 85 c0             	test   %rax,%rax
    80f2:	75 15                	jne    8109 <fwp_drop0+0x1a9>
    80f4:	eb 4e                	jmp    8144 <fwp_drop0+0x1e4>
    80f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    80fd:	00 00 00 
    8100:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8104:	48 85 c0             	test   %rax,%rax
    8107:	74 3b                	je     8144 <fwp_drop0+0x1e4>
    8109:	48 89 c1             	mov    %rax,%rcx
    810c:	48 39 10             	cmp    %rdx,(%rax)
    810f:	75 ef                	jne    8100 <fwp_drop0+0x1a0>
    8111:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8115:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8119:	48 89 48 08          	mov    %rcx,0x8(%rax)
    811d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8124:	0f 85 c4 fe ff ff    	jne    7fee <fwp_drop0+0x8e>
    812a:	48 89 d7             	mov    %rdx,%rdi
    812d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8132:	e8 79 d6 ff ff       	call   57b0 <fwp_rc_forget_slot>
    8137:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    813c:	c6 02 fe             	movb   $0xfe,(%rdx)
    813f:	e9 aa fe ff ff       	jmp    7fee <fwp_drop0+0x8e>
    8144:	48 8d 3d 5d 38 00 00 	lea    0x385d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    814b:	e8 e0 c2 ff ff       	call   4430 <fwp_trap>

0000000000008150 <fwp_drop1>:
    8150:	f3 0f 1e fa          	endbr64
    8154:	48 8b 15 9d 0a 06 00 	mov    0x60a9d(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    815b:	48 89 f8             	mov    %rdi,%rax
    815e:	48 2b 05 6b 0a 06 00 	sub    0x60a6b(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8165:	48 c1 e2 10          	shl    $0x10,%rdx
    8169:	48 39 d0             	cmp    %rdx,%rax
    816c:	0f 83 36 01 00 00    	jae    82a8 <fwp_drop1+0x158>
    8172:	48 83 ec 18          	sub    $0x18,%rsp
    8176:	48 8d 35 a3 f6 05 00 	lea    0x5f6a3(%rip),%rsi        # 67820 <fwp_heap>
    817d:	48 89 c2             	mov    %rax,%rdx
    8180:	4c 8b 8e f8 13 00 00 	mov    0x13f8(%rsi),%r9
    8187:	48 c1 ea 10          	shr    $0x10,%rdx
    818b:	48 8d 14 92          	lea    (%rdx,%rdx,4),%rdx
    818f:	49 8d 0c d1          	lea    (%r9,%rdx,8),%rcx
    8193:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    8197:	48 85 d2             	test   %rdx,%rdx
    819a:	74 42                	je     81de <fwp_drop1+0x8e>
    819c:	44 0f b6 01          	movzbl (%rcx),%r8d
    81a0:	41 80 f8 02          	cmp    $0x2,%r8b
    81a4:	74 42                	je     81e8 <fwp_drop1+0x98>
    81a6:	41 80 f8 01          	cmp    $0x1,%r8b
    81aa:	75 32                	jne    81de <fwp_drop1+0x8e>
    81ac:	44 8b 41 18          	mov    0x18(%rcx),%r8d
    81b0:	0f b7 c0             	movzwl %ax,%eax
    81b3:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    81b6:	49 0f af c0          	imul   %r8,%rax
    81ba:	48 c1 e8 20          	shr    $0x20,%rax
    81be:	48 39 c8             	cmp    %rcx,%rax
    81c1:	73 1b                	jae    81de <fwp_drop1+0x8e>
    81c3:	48 01 c2             	add    %rax,%rdx
    81c6:	0f b6 02             	movzbl (%rdx),%eax
    81c9:	84 c0                	test   %al,%al
    81cb:	74 11                	je     81de <fwp_drop1+0x8e>
    81cd:	3c 01                	cmp    $0x1,%al
    81cf:	74 27                	je     81f8 <fwp_drop1+0xa8>
    81d1:	3c ff                	cmp    $0xff,%al
    81d3:	0f 84 e7 00 00 00    	je     82c0 <fwp_drop1+0x170>
    81d9:	83 e8 01             	sub    $0x1,%eax
    81dc:	88 02                	mov    %al,(%rdx)
    81de:	48 83 c4 18          	add    $0x18,%rsp
    81e2:	c3                   	ret
    81e3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    81e8:	66 85 c0             	test   %ax,%ax
    81eb:	74 d9                	je     81c6 <fwp_drop1+0x76>
    81ed:	48 83 c4 18          	add    $0x18,%rsp
    81f1:	c3                   	ret
    81f2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    81f8:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    81ff:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    8206:	48 89 f8             	mov    %rdi,%rax
    8209:	4c 8b 47 10          	mov    0x10(%rdi),%r8
    820d:	48 29 c8             	sub    %rcx,%rax
    8210:	48 c1 e2 10          	shl    $0x10,%rdx
    8214:	48 39 d0             	cmp    %rdx,%rax
    8217:	73 71                	jae    828a <fwp_drop1+0x13a>
    8219:	49 89 c2             	mov    %rax,%r10
    821c:	49 c1 ea 10          	shr    $0x10,%r10
    8220:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    8224:	4f 8d 0c d1          	lea    (%r9,%r10,8),%r9
    8228:	4d 8b 51 20          	mov    0x20(%r9),%r10
    822c:	4d 85 d2             	test   %r10,%r10
    822f:	74 59                	je     828a <fwp_drop1+0x13a>
    8231:	45 0f b6 19          	movzbl (%r9),%r11d
    8235:	41 80 fb 02          	cmp    $0x2,%r11b
    8239:	74 75                	je     82b0 <fwp_drop1+0x160>
    823b:	41 80 fb 01          	cmp    $0x1,%r11b
    823f:	75 49                	jne    828a <fwp_drop1+0x13a>
    8241:	45 8b 59 18          	mov    0x18(%r9),%r11d
    8245:	0f b7 c0             	movzwl %ax,%eax
    8248:	45 8b 49 1c          	mov    0x1c(%r9),%r9d
    824c:	49 0f af c3          	imul   %r11,%rax
    8250:	48 c1 e8 20          	shr    $0x20,%rax
    8254:	4c 39 c8             	cmp    %r9,%rax
    8257:	73 31                	jae    828a <fwp_drop1+0x13a>
    8259:	49 01 c2             	add    %rax,%r10
    825c:	41 80 3a 01          	cmpb   $0x1,(%r10)
    8260:	75 28                	jne    828a <fwp_drop1+0x13a>
    8262:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
    8267:	e8 84 d7 ff ff       	call   59f0 <fwp_mem_free>
    826c:	48 8d 35 ad f5 05 00 	lea    0x5f5ad(%rip),%rsi        # 67820 <fwp_heap>
    8273:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    8278:	48 8b 96 d8 13 00 00 	mov    0x13d8(%rsi),%rdx
    827f:	48 8b 8e b0 13 00 00 	mov    0x13b0(%rsi),%rcx
    8286:	48 c1 e2 10          	shl    $0x10,%rdx
    828a:	4c 89 c0             	mov    %r8,%rax
    828d:	48 29 c8             	sub    %rcx,%rax
    8290:	48 39 d0             	cmp    %rdx,%rax
    8293:	0f 83 45 ff ff ff    	jae    81de <fwp_drop1+0x8e>
    8299:	4c 89 c7             	mov    %r8,%rdi
    829c:	e9 dc fe ff ff       	jmp    817d <fwp_drop1+0x2d>
    82a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82a8:	c3                   	ret
    82a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    82b0:	66 85 c0             	test   %ax,%ax
    82b3:	75 d5                	jne    828a <fwp_drop1+0x13a>
    82b5:	eb a5                	jmp    825c <fwp_drop1+0x10c>
    82b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    82be:	00 00 
    82c0:	48 89 d0             	mov    %rdx,%rax
    82c3:	48 c1 e8 11          	shr    $0x11,%rax
    82c7:	48 31 d0             	xor    %rdx,%rax
    82ca:	48 89 c1             	mov    %rax,%rcx
    82cd:	48 c1 e9 09          	shr    $0x9,%rcx
    82d1:	48 31 c8             	xor    %rcx,%rax
    82d4:	0f b6 c8             	movzbl %al,%ecx
    82d7:	48 8b 84 ce 48 14 00 	mov    0x1448(%rsi,%rcx,8),%rax
    82de:	00 
    82df:	48 85 c0             	test   %rax,%rax
    82e2:	75 25                	jne    8309 <fwp_drop1+0x1b9>
    82e4:	eb 5e                	jmp    8344 <fwp_drop1+0x1f4>
    82e6:	0f 1f 40 00          	nopl   0x0(%rax)
    82ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82f1:	00 00 00 00 
    82f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    82fc:	00 00 00 00 
    8300:	48 8b 41 10          	mov    0x10(%rcx),%rax
    8304:	48 85 c0             	test   %rax,%rax
    8307:	74 3b                	je     8344 <fwp_drop1+0x1f4>
    8309:	48 89 c1             	mov    %rax,%rcx
    830c:	48 39 10             	cmp    %rdx,(%rax)
    830f:	75 ef                	jne    8300 <fwp_drop1+0x1b0>
    8311:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8315:	48 8d 4e ff          	lea    -0x1(%rsi),%rcx
    8319:	48 89 48 08          	mov    %rcx,0x8(%rax)
    831d:	48 81 f9 fe 00 00 00 	cmp    $0xfe,%rcx
    8324:	0f 85 b4 fe ff ff    	jne    81de <fwp_drop1+0x8e>
    832a:	48 89 d7             	mov    %rdx,%rdi
    832d:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    8332:	e8 79 d4 ff ff       	call   57b0 <fwp_rc_forget_slot>
    8337:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    833c:	c6 02 fe             	movb   $0xfe,(%rdx)
    833f:	e9 9a fe ff ff       	jmp    81de <fwp_drop1+0x8e>
    8344:	48 8d 3d 5d 36 00 00 	lea    0x365d(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    834b:	e8 e0 c0 ff ff       	call   4430 <fwp_trap>

0000000000008350 <fwp_drop10>:
    8350:	48 8b 0d a1 08 06 00 	mov    0x608a1(%rip),%rcx        # 68bf8 <fwp_heap+0x13d8>
    8357:	48 89 f8             	mov    %rdi,%rax
    835a:	48 2b 05 6f 08 06 00 	sub    0x6086f(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8361:	48 c1 e1 10          	shl    $0x10,%rcx
    8365:	48 39 c8             	cmp    %rcx,%rax
    8368:	0f 83 c2 01 00 00    	jae    8530 <fwp_drop10+0x1e0>
    836e:	48 83 ec 18          	sub    $0x18,%rsp
    8372:	48 89 fa             	mov    %rdi,%rdx
    8375:	48 8d 35 a4 f4 05 00 	lea    0x5f4a4(%rip),%rsi        # 67820 <fwp_heap>
    837c:	48 89 c1             	mov    %rax,%rcx
    837f:	4c 8b 86 f8 13 00 00 	mov    0x13f8(%rsi),%r8
    8386:	48 c1 e9 10          	shr    $0x10,%rcx
    838a:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    838e:	49 8d 3c c8          	lea    (%r8,%rcx,8),%rdi
    8392:	48 8b 4f 20          	mov    0x20(%rdi),%rcx
    8396:	48 85 c9             	test   %rcx,%rcx
    8399:	74 46                	je     83e1 <fwp_drop10+0x91>
    839b:	44 0f b6 0f          	movzbl (%rdi),%r9d
    839f:	41 80 f9 02          	cmp    $0x2,%r9b
    83a3:	0f 84 d7 00 00 00    	je     8480 <fwp_drop10+0x130>
    83a9:	41 80 f9 01          	cmp    $0x1,%r9b
    83ad:	75 32                	jne    83e1 <fwp_drop10+0x91>
    83af:	44 8b 4f 18          	mov    0x18(%rdi),%r9d
    83b3:	0f b7 c0             	movzwl %ax,%eax
    83b6:	8b 7f 1c             	mov    0x1c(%rdi),%edi
    83b9:	49 0f af c1          	imul   %r9,%rax
    83bd:	48 c1 e8 20          	shr    $0x20,%rax
    83c1:	48 39 f8             	cmp    %rdi,%rax
    83c4:	73 1b                	jae    83e1 <fwp_drop10+0x91>
    83c6:	48 01 c1             	add    %rax,%rcx
    83c9:	0f b6 01             	movzbl (%rcx),%eax
    83cc:	84 c0                	test   %al,%al
    83ce:	74 11                	je     83e1 <fwp_drop10+0x91>
    83d0:	3c 01                	cmp    $0x1,%al
    83d2:	74 1c                	je     83f0 <fwp_drop10+0xa0>
    83d4:	3c ff                	cmp    $0xff,%al
    83d6:	0f 84 5c 01 00 00    	je     8538 <fwp_drop10+0x1e8>
    83dc:	83 e8 01             	sub    $0x1,%eax
    83df:	88 01                	mov    %al,(%rcx)
    83e1:	48 83 c4 18          	add    $0x18,%rsp
    83e5:	c3                   	ret
    83e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    83ed:	00 00 00 
    83f0:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    83f7:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    83fe:	48 89 d0             	mov    %rdx,%rax
    8401:	49 89 d1             	mov    %rdx,%r9
    8404:	48 c1 e1 10          	shl    $0x10,%rcx
    8408:	48 29 f8             	sub    %rdi,%rax
    840b:	48 83 3a 00          	cmpq   $0x0,(%rdx)
    840f:	78 7f                	js     8490 <fwp_drop10+0x140>
    8411:	48 39 c8             	cmp    %rcx,%rax
    8414:	73 cb                	jae    83e1 <fwp_drop10+0x91>
    8416:	48 89 c1             	mov    %rax,%rcx
    8419:	48 c1 e9 10          	shr    $0x10,%rcx
    841d:	48 8d 0c 89          	lea    (%rcx,%rcx,4),%rcx
    8421:	49 8d 0c c8          	lea    (%r8,%rcx,8),%rcx
    8425:	48 8b 71 20          	mov    0x20(%rcx),%rsi
    8429:	48 85 f6             	test   %rsi,%rsi
    842c:	74 b3                	je     83e1 <fwp_drop10+0x91>
    842e:	0f b6 39             	movzbl (%rcx),%edi
    8431:	40 80 ff 02          	cmp    $0x2,%dil
    8435:	74 39                	je     8470 <fwp_drop10+0x120>
    8437:	40 80 ff 01          	cmp    $0x1,%dil
    843b:	75 a4                	jne    83e1 <fwp_drop10+0x91>
    843d:	8b 79 18             	mov    0x18(%rcx),%edi
    8440:	0f b7 c0             	movzwl %ax,%eax
    8443:	8b 49 1c             	mov    0x1c(%rcx),%ecx
    8446:	48 0f af c7          	imul   %rdi,%rax
    844a:	48 c1 e8 20          	shr    $0x20,%rax
    844e:	48 39 c8             	cmp    %rcx,%rax
    8451:	73 8e                	jae    83e1 <fwp_drop10+0x91>
    8453:	48 01 c6             	add    %rax,%rsi
    8456:	80 3e 01             	cmpb   $0x1,(%rsi)
    8459:	75 86                	jne    83e1 <fwp_drop10+0x91>
    845b:	48 89 d7             	mov    %rdx,%rdi
    845e:	48 83 c4 18          	add    $0x18,%rsp
    8462:	e9 89 d5 ff ff       	jmp    59f0 <fwp_mem_free>
    8467:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    846e:	00 00 
    8470:	66 85 c0             	test   %ax,%ax
    8473:	74 e1                	je     8456 <fwp_drop10+0x106>
    8475:	48 83 c4 18          	add    $0x18,%rsp
    8479:	c3                   	ret
    847a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8480:	66 85 c0             	test   %ax,%ax
    8483:	0f 84 40 ff ff ff    	je     83c9 <fwp_drop10+0x79>
    8489:	48 83 c4 18          	add    $0x18,%rsp
    848d:	c3                   	ret
    848e:	66 90                	xchg   %ax,%ax
    8490:	48 8b 52 08          	mov    0x8(%rdx),%rdx
    8494:	48 39 c8             	cmp    %rcx,%rax
    8497:	73 74                	jae    850d <fwp_drop10+0x1bd>
    8499:	49 89 c2             	mov    %rax,%r10
    849c:	49 c1 ea 10          	shr    $0x10,%r10
    84a0:	4f 8d 14 92          	lea    (%r10,%r10,4),%r10
    84a4:	4f 8d 04 d0          	lea    (%r8,%r10,8),%r8
    84a8:	4d 8b 50 20          	mov    0x20(%r8),%r10
    84ac:	4d 85 d2             	test   %r10,%r10
    84af:	74 5c                	je     850d <fwp_drop10+0x1bd>
    84b1:	45 0f b6 18          	movzbl (%r8),%r11d
    84b5:	41 80 fb 02          	cmp    $0x2,%r11b
    84b9:	74 6d                	je     8528 <fwp_drop10+0x1d8>
    84bb:	41 80 fb 01          	cmp    $0x1,%r11b
    84bf:	75 4c                	jne    850d <fwp_drop10+0x1bd>
    84c1:	45 8b 58 18          	mov    0x18(%r8),%r11d
    84c5:	0f b7 c0             	movzwl %ax,%eax
    84c8:	45 8b 40 1c          	mov    0x1c(%r8),%r8d
    84cc:	49 0f af c3          	imul   %r11,%rax
    84d0:	48 c1 e8 20          	shr    $0x20,%rax
    84d4:	4c 39 c0             	cmp    %r8,%rax
    84d7:	73 34                	jae    850d <fwp_drop10+0x1bd>
    84d9:	49 01 c2             	add    %rax,%r10
    84dc:	41 80 3a 01          	cmpb   $0x1,(%r10)
    84e0:	75 2b                	jne    850d <fwp_drop10+0x1bd>
    84e2:	4c 89 cf             	mov    %r9,%rdi
    84e5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
    84ea:	e8 01 d5 ff ff       	call   59f0 <fwp_mem_free>
    84ef:	48 8d 35 2a f3 05 00 	lea    0x5f32a(%rip),%rsi        # 67820 <fwp_heap>
    84f6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    84fb:	48 8b 8e d8 13 00 00 	mov    0x13d8(%rsi),%rcx
    8502:	48 8b be b0 13 00 00 	mov    0x13b0(%rsi),%rdi
    8509:	48 c1 e1 10          	shl    $0x10,%rcx
    850d:	48 89 d0             	mov    %rdx,%rax
    8510:	48 29 f8             	sub    %rdi,%rax
    8513:	48 39 c8             	cmp    %rcx,%rax
    8516:	0f 82 60 fe ff ff    	jb     837c <fwp_drop10+0x2c>
    851c:	e9 c0 fe ff ff       	jmp    83e1 <fwp_drop10+0x91>
    8521:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8528:	66 85 c0             	test   %ax,%ax
    852b:	75 e0                	jne    850d <fwp_drop10+0x1bd>
    852d:	eb ad                	jmp    84dc <fwp_drop10+0x18c>
    852f:	90                   	nop
    8530:	c3                   	ret
    8531:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    8538:	48 89 c8             	mov    %rcx,%rax
    853b:	48 c1 e8 11          	shr    $0x11,%rax
    853f:	48 31 c8             	xor    %rcx,%rax
    8542:	48 89 c2             	mov    %rax,%rdx
    8545:	48 c1 ea 09          	shr    $0x9,%rdx
    8549:	48 31 d0             	xor    %rdx,%rax
    854c:	0f b6 d0             	movzbl %al,%edx
    854f:	48 8b 84 d6 48 14 00 	mov    0x1448(%rsi,%rdx,8),%rax
    8556:	00 
    8557:	48 85 c0             	test   %rax,%rax
    855a:	75 0d                	jne    8569 <fwp_drop10+0x219>
    855c:	eb 46                	jmp    85a4 <fwp_drop10+0x254>
    855e:	66 90                	xchg   %ax,%ax
    8560:	48 8b 42 10          	mov    0x10(%rdx),%rax
    8564:	48 85 c0             	test   %rax,%rax
    8567:	74 3b                	je     85a4 <fwp_drop10+0x254>
    8569:	48 89 c2             	mov    %rax,%rdx
    856c:	48 39 08             	cmp    %rcx,(%rax)
    856f:	75 ef                	jne    8560 <fwp_drop10+0x210>
    8571:	48 8b 70 08          	mov    0x8(%rax),%rsi
    8575:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    8579:	48 89 50 08          	mov    %rdx,0x8(%rax)
    857d:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    8584:	0f 85 57 fe ff ff    	jne    83e1 <fwp_drop10+0x91>
    858a:	48 89 cf             	mov    %rcx,%rdi
    858d:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    8592:	e8 19 d2 ff ff       	call   57b0 <fwp_rc_forget_slot>
    8597:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    859c:	c6 01 fe             	movb   $0xfe,(%rcx)
    859f:	e9 3d fe ff ff       	jmp    83e1 <fwp_drop10+0x91>
    85a4:	48 8d 3d fd 33 00 00 	lea    0x33fd(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    85ab:	e8 80 be ff ff       	call   4430 <fwp_trap>

00000000000085b0 <f37>:
    85b0:	41 57                	push   %r15
    85b2:	41 56                	push   %r14
    85b4:	41 55                	push   %r13
    85b6:	41 54                	push   %r12
    85b8:	55                   	push   %rbp
    85b9:	53                   	push   %rbx
    85ba:	48 83 ec 38          	sub    $0x38,%rsp
    85be:	48 8b 15 33 06 06 00 	mov    0x60633(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    85c5:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    85ca:	48 c1 e2 10          	shl    $0x10,%rdx
    85ce:	64 48 8b 0c 25 28 00 	mov    %fs:0x28,%rcx
    85d5:	00 00 
    85d7:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
    85dc:	48 8b 0d ed 05 06 00 	mov    0x605ed(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    85e3:	48 85 ff             	test   %rdi,%rdi
    85e6:	0f 84 5e 03 00 00    	je     894a <f37+0x39a>
    85ec:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    85f1:	4c 8b 68 10          	mov    0x10(%rax),%r13
    85f5:	4c 89 e8             	mov    %r13,%rax
    85f8:	48 29 c8             	sub    %rcx,%rax
    85fb:	48 39 d0             	cmp    %rdx,%rax
    85fe:	0f 83 2c 03 00 00    	jae    8930 <f37+0x380>
    8604:	48 89 c2             	mov    %rax,%rdx
    8607:	48 c1 ea 10          	shr    $0x10,%rdx
    860b:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    860f:	48 8b 15 02 06 06 00 	mov    0x60602(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8616:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    861a:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    861e:	48 85 ff             	test   %rdi,%rdi
    8621:	0f 84 09 03 00 00    	je     8930 <f37+0x380>
    8627:	0f b6 0a             	movzbl (%rdx),%ecx
    862a:	80 f9 02             	cmp    $0x2,%cl
    862d:	0f 84 8d 02 00 00    	je     88c0 <f37+0x310>
    8633:	80 f9 01             	cmp    $0x1,%cl
    8636:	75 24                	jne    865c <f37+0xac>
    8638:	8b 4a 18             	mov    0x18(%rdx),%ecx
    863b:	0f b7 c0             	movzwl %ax,%eax
    863e:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8641:	48 0f af c1          	imul   %rcx,%rax
    8645:	48 c1 e8 20          	shr    $0x20,%rax
    8649:	48 39 d0             	cmp    %rdx,%rax
    864c:	73 0e                	jae    865c <f37+0xac>
    864e:	48 01 c7             	add    %rax,%rdi
    8651:	0f b6 07             	movzbl (%rdi),%eax
    8654:	84 c0                	test   %al,%al
    8656:	0f 85 84 02 00 00    	jne    88e0 <f37+0x330>
    865c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8661:	48 8b 40 10          	mov    0x10(%rax),%rax
    8665:	ba 01 00 00 00       	mov    $0x1,%edx
    866a:	48 85 c0             	test   %rax,%rax
    866d:	74 0e                	je     867d <f37+0xcd>
    866f:	90                   	nop
    8670:	48 8b 40 10          	mov    0x10(%rax),%rax
    8674:	48 83 c2 01          	add    $0x1,%rdx
    8678:	48 85 c0             	test   %rax,%rax
    867b:	75 f3                	jne    8670 <f37+0xc0>
    867d:	4d 85 ed             	test   %r13,%r13
    8680:	0f 84 da 02 00 00    	je     8960 <f37+0x3b0>
    8686:	4c 89 e8             	mov    %r13,%rax
    8689:	31 db                	xor    %ebx,%ebx
    868b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8690:	48 8b 40 10          	mov    0x10(%rax),%rax
    8694:	48 83 c3 01          	add    $0x1,%rbx
    8698:	48 85 c0             	test   %rax,%rax
    869b:	75 f3                	jne    8690 <f37+0xe0>
    869d:	48 39 d3             	cmp    %rdx,%rbx
    86a0:	48 0f 47 da          	cmova  %rdx,%rbx
    86a4:	48 89 d8             	mov    %rbx,%rax
    86a7:	48 c1 e8 3c          	shr    $0x3c,%rax
    86ab:	0f 85 bd 03 00 00    	jne    8a6e <f37+0x4be>
    86b1:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
    86b5:	be 02 00 00 00       	mov    $0x2,%esi
    86ba:	48 8d 3c ed 08 00 00 	lea    0x8(,%rbp,8),%rdi
    86c1:	00 
    86c2:	e8 29 d8 ff ff       	call   5ef0 <fwp_heap_alloc>
    86c7:	48 89 28             	mov    %rbp,(%rax)
    86ca:	48 8b 15 27 05 06 00 	mov    0x60527(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    86d1:	49 89 c4             	mov    %rax,%r12
    86d4:	48 2b 05 f5 04 06 00 	sub    0x604f5(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    86db:	48 c1 e2 10          	shl    $0x10,%rdx
    86df:	48 39 d0             	cmp    %rdx,%rax
    86e2:	73 57                	jae    873b <f37+0x18b>
    86e4:	48 89 c2             	mov    %rax,%rdx
    86e7:	48 c1 ea 10          	shr    $0x10,%rdx
    86eb:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    86ef:	48 8b 15 22 05 06 00 	mov    0x60522(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    86f6:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    86fa:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    86fe:	48 85 ed             	test   %rbp,%rbp
    8701:	74 38                	je     873b <f37+0x18b>
    8703:	0f b6 0a             	movzbl (%rdx),%ecx
    8706:	80 f9 02             	cmp    $0x2,%cl
    8709:	0f 84 11 02 00 00    	je     8920 <f37+0x370>
    870f:	80 f9 01             	cmp    $0x1,%cl
    8712:	75 27                	jne    873b <f37+0x18b>
    8714:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8717:	0f b7 c0             	movzwl %ax,%eax
    871a:	8b 52 1c             	mov    0x1c(%rdx),%edx
    871d:	48 0f af c1          	imul   %rcx,%rax
    8721:	48 c1 e8 20          	shr    $0x20,%rax
    8725:	48 39 d0             	cmp    %rdx,%rax
    8728:	73 11                	jae    873b <f37+0x18b>
    872a:	48 01 c5             	add    %rax,%rbp
    872d:	80 7d 00 ff          	cmpb   $0xff,0x0(%rbp)
    8731:	0f 84 97 02 00 00    	je     89ce <f37+0x41e>
    8737:	c6 45 00 01          	movb   $0x1,0x0(%rbp)
    873b:	48 85 db             	test   %rbx,%rbx
    873e:	74 5d                	je     879d <f37+0x1ed>
    8740:	48 c1 e3 04          	shl    $0x4,%rbx
    8744:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
    8749:	4c 89 e5             	mov    %r12,%rbp
    874c:	4d 89 ef             	mov    %r13,%r15
    874f:	4c 01 e3             	add    %r12,%rbx
    8752:	0f 1f 00             	nopl   (%rax)
    8755:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    875c:	00 00 00 00 
    8760:	49 8b 46 08          	mov    0x8(%r14),%rax
    8764:	49 8b 4f 08          	mov    0x8(%r15),%rcx
    8768:	48 83 c5 10          	add    $0x10,%rbp
    876c:	f2 0f 10 40 08       	movsd  0x8(%rax),%xmm0
    8771:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    8775:	48 8b 78 10          	mov    0x10(%rax),%rdi
    8779:	f2 0f 10 49 08       	movsd  0x8(%rcx),%xmm1
    877e:	e8 4d df ff ff       	call   66d0 <w120>
    8783:	66 48 0f 6e d0       	movq   %rax,%xmm2
    8788:	66 0f 6c c2          	punpcklqdq %xmm2,%xmm0
    878c:	0f 11 45 f8          	movups %xmm0,-0x8(%rbp)
    8790:	4d 8b 7f 10          	mov    0x10(%r15),%r15
    8794:	4d 8b 76 10          	mov    0x10(%r14),%r14
    8798:	48 39 eb             	cmp    %rbp,%rbx
    879b:	75 c3                	jne    8760 <f37+0x1b0>
    879d:	4c 89 ef             	mov    %r13,%rdi
    87a0:	31 db                	xor    %ebx,%ebx
    87a2:	e8 89 ed ff ff       	call   7530 <fwp_drop4>
    87a7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    87ac:	e8 7f ed ff ff       	call   7530 <fwp_drop4>
    87b1:	4d 8b 2c 24          	mov    (%r12),%r13
    87b5:	66 0f ef c0          	pxor   %xmm0,%xmm0
    87b9:	48 c7 c7 ff ff ff ff 	mov    $0xffffffffffffffff,%rdi
    87c0:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
    87c7:	4d 85 ed             	test   %r13,%r13
    87ca:	74 32                	je     87fe <f37+0x24e>
    87cc:	0f 1f 40 00          	nopl   0x0(%rax)
    87d0:	f2 41 0f 58 44 dc 08 	addsd  0x8(%r12,%rbx,8),%xmm0
    87d7:	49 8b 74 dc 10       	mov    0x10(%r12,%rbx,8),%rsi
    87dc:	48 83 c3 02          	add    $0x2,%rbx
    87e0:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
    87e6:	e8 65 dd ff ff       	call   6550 <f141.constprop.0>
    87eb:	4c 39 eb             	cmp    %r13,%rbx
    87ee:	f2 0f 10 44 24 08    	movsd  0x8(%rsp),%xmm0
    87f4:	48 89 c7             	mov    %rax,%rdi
    87f7:	72 d7                	jb     87d0 <f37+0x220>
    87f9:	66 49 0f 7e c5       	movq   %xmm0,%r13
    87fe:	4c 89 e7             	mov    %r12,%rdi
    8801:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    8806:	e8 45 fb ff ff       	call   8350 <fwp_drop10>
    880b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    8810:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
    8815:	31 ff                	xor    %edi,%edi
    8817:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
    881c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    8821:	e8 ba d8 ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    8826:	48 8b 15 cb 03 06 00 	mov    0x603cb(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    882d:	48 89 c5             	mov    %rax,%rbp
    8830:	48 2b 05 99 03 06 00 	sub    0x60399(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8837:	48 c1 e2 10          	shl    $0x10,%rdx
    883b:	48 39 d0             	cmp    %rdx,%rax
    883e:	73 55                	jae    8895 <f37+0x2e5>
    8840:	48 89 c2             	mov    %rax,%rdx
    8843:	48 c1 ea 10          	shr    $0x10,%rdx
    8847:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    884b:	48 8b 15 c6 03 06 00 	mov    0x603c6(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    8852:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    8856:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    885a:	48 85 db             	test   %rbx,%rbx
    885d:	74 36                	je     8895 <f37+0x2e5>
    885f:	0f b6 0a             	movzbl (%rdx),%ecx
    8862:	80 f9 02             	cmp    $0x2,%cl
    8865:	0f 84 a5 00 00 00    	je     8910 <f37+0x360>
    886b:	80 f9 01             	cmp    $0x1,%cl
    886e:	75 25                	jne    8895 <f37+0x2e5>
    8870:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8873:	0f b7 c0             	movzwl %ax,%eax
    8876:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8879:	48 0f af c1          	imul   %rcx,%rax
    887d:	48 c1 e8 20          	shr    $0x20,%rax
    8881:	48 39 d0             	cmp    %rdx,%rax
    8884:	73 0f                	jae    8895 <f37+0x2e5>
    8886:	48 01 c3             	add    %rax,%rbx
    8889:	80 3b ff             	cmpb   $0xff,(%rbx)
    888c:	0f 84 2f 01 00 00    	je     89c1 <f37+0x411>
    8892:	c6 03 01             	movb   $0x1,(%rbx)
    8895:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    889a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    88a1:	00 00 
    88a3:	0f 85 d1 01 00 00    	jne    8a7a <f37+0x4ca>
    88a9:	48 83 c4 38          	add    $0x38,%rsp
    88ad:	48 89 e8             	mov    %rbp,%rax
    88b0:	5b                   	pop    %rbx
    88b1:	5d                   	pop    %rbp
    88b2:	41 5c                	pop    %r12
    88b4:	41 5d                	pop    %r13
    88b6:	41 5e                	pop    %r14
    88b8:	41 5f                	pop    %r15
    88ba:	c3                   	ret
    88bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    88c0:	66 85 c0             	test   %ax,%ax
    88c3:	0f 85 93 fd ff ff    	jne    865c <f37+0xac>
    88c9:	0f b6 07             	movzbl (%rdi),%eax
    88cc:	84 c0                	test   %al,%al
    88ce:	0f 84 88 fd ff ff    	je     865c <f37+0xac>
    88d4:	90                   	nop
    88d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    88dc:	00 00 00 00 
    88e0:	8b 15 02 0c 06 00    	mov    0x60c02(%rip),%edx        # 694e8 <iteration_active>
    88e6:	85 d2                	test   %edx,%edx
    88e8:	75 56                	jne    8940 <f37+0x390>
    88ea:	3c fd                	cmp    $0xfd,%al
    88ec:	0f 87 4b 01 00 00    	ja     8a3d <f37+0x48d>
    88f2:	83 c0 01             	add    $0x1,%eax
    88f5:	88 07                	mov    %al,(%rdi)
    88f7:	31 d2                	xor    %edx,%edx
    88f9:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
    88ff:	0f 85 57 fd ff ff    	jne    865c <f37+0xac>
    8905:	e9 73 fd ff ff       	jmp    867d <f37+0xcd>
    890a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8910:	66 85 c0             	test   %ax,%ax
    8913:	0f 85 7c ff ff ff    	jne    8895 <f37+0x2e5>
    8919:	e9 6b ff ff ff       	jmp    8889 <f37+0x2d9>
    891e:	66 90                	xchg   %ax,%ax
    8920:	66 85 c0             	test   %ax,%ax
    8923:	0f 85 12 fe ff ff    	jne    873b <f37+0x18b>
    8929:	e9 ff fd ff ff       	jmp    872d <f37+0x17d>
    892e:	66 90                	xchg   %ax,%ax
    8930:	4c 89 e8             	mov    %r13,%rax
    8933:	e9 2d fd ff ff       	jmp    8665 <f37+0xb5>
    8938:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    893f:	00 
    8940:	48 83 05 88 0b 06 00 	addq   $0x1,0x60b88(%rip)        # 694d0 <iteration_retains>
    8947:	01 
    8948:	eb a0                	jmp    88ea <f37+0x33a>
    894a:	48 f7 d9             	neg    %rcx
    894d:	48 39 d1             	cmp    %rdx,%rcx
    8950:	0f 82 85 00 00 00    	jb     89db <f37+0x42b>
    8956:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    895d:	00 00 00 
    8960:	be 02 00 00 00       	mov    $0x2,%esi
    8965:	bf 08 00 00 00       	mov    $0x8,%edi
    896a:	e8 81 d5 ff ff       	call   5ef0 <fwp_heap_alloc>
    896f:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
    8976:	48 8b 15 7b 02 06 00 	mov    0x6027b(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    897d:	49 89 c4             	mov    %rax,%r12
    8980:	48 2b 05 49 02 06 00 	sub    0x60249(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    8987:	48 c1 e2 10          	shl    $0x10,%rdx
    898b:	48 39 d0             	cmp    %rdx,%rax
    898e:	0f 83 b3 00 00 00    	jae    8a47 <f37+0x497>
    8994:	48 89 c2             	mov    %rax,%rdx
    8997:	45 31 ed             	xor    %r13d,%r13d
    899a:	48 c1 ea 10          	shr    $0x10,%rdx
    899e:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    89a2:	48 8b 15 6f 02 06 00 	mov    0x6026f(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    89a9:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    89ad:	48 8b 6a 20          	mov    0x20(%rdx),%rbp
    89b1:	48 85 ed             	test   %rbp,%rbp
    89b4:	0f 84 e3 fd ff ff    	je     879d <f37+0x1ed>
    89ba:	31 db                	xor    %ebx,%ebx
    89bc:	e9 42 fd ff ff       	jmp    8703 <f37+0x153>
    89c1:	48 89 df             	mov    %rbx,%rdi
    89c4:	e8 e7 cd ff ff       	call   57b0 <fwp_rc_forget_slot>
    89c9:	e9 c4 fe ff ff       	jmp    8892 <f37+0x2e2>
    89ce:	48 89 ef             	mov    %rbp,%rdi
    89d1:	e8 da cd ff ff       	call   57b0 <fwp_rc_forget_slot>
    89d6:	e9 5c fd ff ff       	jmp    8737 <f37+0x187>
    89db:	48 89 c8             	mov    %rcx,%rax
    89de:	48 c1 e8 10          	shr    $0x10,%rax
    89e2:	48 8d 14 80          	lea    (%rax,%rax,4),%rdx
    89e6:	48 8b 05 2b 02 06 00 	mov    0x6022b(%rip),%rax        # 68c18 <fwp_heap+0x13f8>
    89ed:	48 8d 14 d0          	lea    (%rax,%rdx,8),%rdx
    89f1:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    89f5:	48 85 ff             	test   %rdi,%rdi
    89f8:	0f 84 62 ff ff ff    	je     8960 <f37+0x3b0>
    89fe:	0f b6 02             	movzbl (%rdx),%eax
    8a01:	3c 02                	cmp    $0x2,%al
    8a03:	74 4a                	je     8a4f <f37+0x49f>
    8a05:	3c 01                	cmp    $0x1,%al
    8a07:	0f 85 53 ff ff ff    	jne    8960 <f37+0x3b0>
    8a0d:	0f b7 c1             	movzwl %cx,%eax
    8a10:	8b 4a 18             	mov    0x18(%rdx),%ecx
    8a13:	8b 52 1c             	mov    0x1c(%rdx),%edx
    8a16:	48 0f af c1          	imul   %rcx,%rax
    8a1a:	48 c1 e8 20          	shr    $0x20,%rax
    8a1e:	48 39 d0             	cmp    %rdx,%rax
    8a21:	0f 83 39 ff ff ff    	jae    8960 <f37+0x3b0>
    8a27:	48 01 c7             	add    %rax,%rdi
    8a2a:	0f b6 07             	movzbl (%rdi),%eax
    8a2d:	84 c0                	test   %al,%al
    8a2f:	0f 84 2b ff ff ff    	je     8960 <f37+0x3b0>
    8a35:	45 31 ed             	xor    %r13d,%r13d
    8a38:	e9 a3 fe ff ff       	jmp    88e0 <f37+0x330>
    8a3d:	e8 4e cc ff ff       	call   5690 <fwp_rc_wide_dup>
    8a42:	e9 b0 fe ff ff       	jmp    88f7 <f37+0x347>
    8a47:	45 31 ed             	xor    %r13d,%r13d
    8a4a:	e9 4e fd ff ff       	jmp    879d <f37+0x1ed>
    8a4f:	81 e1 ff ff 00 00    	and    $0xffff,%ecx
    8a55:	49 89 cd             	mov    %rcx,%r13
    8a58:	0f 85 02 ff ff ff    	jne    8960 <f37+0x3b0>
    8a5e:	0f b6 07             	movzbl (%rdi),%eax
    8a61:	84 c0                	test   %al,%al
    8a63:	0f 85 77 fe ff ff    	jne    88e0 <f37+0x330>
    8a69:	e9 f2 fe ff ff       	jmp    8960 <f37+0x3b0>
    8a6e:	48 8d 3d 76 27 00 00 	lea    0x2776(%rip),%rdi        # b1eb <_IO_stdin_used+0x1eb>
    8a75:	e8 b6 b9 ff ff       	call   4430 <fwp_trap>
    8a7a:	e8 d1 a9 ff ff       	call   3450 <__stack_chk_fail@plt>
    8a7f:	90                   	nop

0000000000008a80 <fwp_owned_entry37>:
    8a80:	f3 0f 1e fa          	endbr64
    8a84:	48 8b 3f             	mov    (%rdi),%rdi
    8a87:	e9 24 fb ff ff       	jmp    85b0 <f37>
    8a8c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000008a90 <e37>:
    8a90:	f3 0f 1e fa          	endbr64
    8a94:	53                   	push   %rbx
    8a95:	48 8b 1f             	mov    (%rdi),%rbx
    8a98:	48 89 df             	mov    %rbx,%rdi
    8a9b:	e8 30 e2 ff ff       	call   6cd0 <fwp_rc_share>
    8aa0:	48 89 df             	mov    %rbx,%rdi
    8aa3:	e8 08 fb ff ff       	call   85b0 <f37>
    8aa8:	48 89 c3             	mov    %rax,%rbx
    8aab:	48 89 c7             	mov    %rax,%rdi
    8aae:	e8 1d e2 ff ff       	call   6cd0 <fwp_rc_share>
    8ab3:	48 89 d8             	mov    %rbx,%rax
    8ab6:	5b                   	pop    %rbx
    8ab7:	c3                   	ret
    8ab8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8abf:	00 

0000000000008ac0 <fwp_write>:
    8ac0:	41 57                	push   %r15
    8ac2:	41 56                	push   %r14
    8ac4:	41 55                	push   %r13
    8ac6:	41 54                	push   %r12
    8ac8:	55                   	push   %rbp
    8ac9:	53                   	push   %rbx
    8aca:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
    8ad1:	64 4c 8b 24 25 28 00 	mov    %fs:0x28,%r12
    8ad8:	00 00 
    8ada:	4c 89 a4 24 88 02 00 	mov    %r12,0x288(%rsp)
    8ae1:	00 
    8ae2:	49 89 d4             	mov    %rdx,%r12
    8ae5:	8b 12                	mov    (%rdx),%edx
    8ae7:	83 fa 19             	cmp    $0x19,%edx
    8aea:	77 6a                	ja     8b56 <fwp_write+0x96>
    8aec:	48 89 f5             	mov    %rsi,%rbp
    8aef:	89 d0                	mov    %edx,%eax
    8af1:	89 ce                	mov    %ecx,%esi
    8af3:	48 89 fb             	mov    %rdi,%rbx
    8af6:	48 8d 0d 03 31 00 00 	lea    0x3103(%rip),%rcx        # bc00 <_IO_stdin_used+0xc00>
    8afd:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
    8b01:	48 01 c8             	add    %rcx,%rax
    8b04:	3e ff e0             	notrack jmp *%rax
    8b07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b0e:	00 00 
    8b10:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
    8b14:	48 8b 45 00          	mov    0x0(%rbp),%rax
    8b18:	48 89 ca             	mov    %rcx,%rdx
    8b1b:	48 85 c9             	test   %rcx,%rcx
    8b1e:	0f 88 9c 0c 00 00    	js     97c0 <fwp_write+0xd00>
    8b24:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8b2b:	00 
    8b2c:	48 89 c6             	mov    %rax,%rsi
    8b2f:	4c 89 e7             	mov    %r12,%rdi
    8b32:	e8 e9 ae ff ff       	call   3a20 <fwp_fmt_u128>
    8b37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8b3e:	00 00 
    8b40:	4c 89 e7             	mov    %r12,%rdi
    8b43:	e8 f8 a8 ff ff       	call   3440 <strlen@plt>
    8b48:	4c 89 e6             	mov    %r12,%rsi
    8b4b:	48 89 df             	mov    %rbx,%rdi
    8b4e:	48 89 c2             	mov    %rax,%rdx
    8b51:	e8 7a b5 ff ff       	call   40d0 <buf_put>
    8b56:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8b5d:	00 
    8b5e:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8b65:	00 00 
    8b67:	0f 85 28 04 00 00    	jne    8f95 <fwp_write+0x4d5>
    8b6d:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8b74:	5b                   	pop    %rbx
    8b75:	5d                   	pop    %rbp
    8b76:	41 5c                	pop    %r12
    8b78:	41 5d                	pop    %r13
    8b7a:	41 5e                	pop    %r14
    8b7c:	41 5f                	pop    %r15
    8b7e:	c3                   	ret
    8b7f:	90                   	nop
    8b80:	49 89 e9             	mov    %rbp,%r9
    8b83:	4c 8d 05 8b 26 00 00 	lea    0x268b(%rip),%r8        # b215 <_IO_stdin_used+0x215>
    8b8a:	b9 00 02 00 00       	mov    $0x200,%ecx
    8b8f:	ba 02 00 00 00       	mov    $0x2,%edx
    8b94:	be 00 02 00 00       	mov    $0x200,%esi
    8b99:	31 c0                	xor    %eax,%eax
    8b9b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8ba2:	00 
    8ba3:	e8 f8 a7 ff ff       	call   33a0 <__snprintf_chk@plt>
    8ba8:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    8baf:	00 
    8bb0:	e8 8b a8 ff ff       	call   3440 <strlen@plt>
    8bb5:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    8bbc:	00 
    8bbd:	48 89 df             	mov    %rbx,%rdi
    8bc0:	48 89 c2             	mov    %rax,%rdx
    8bc3:	e8 08 b5 ff ff       	call   40d0 <buf_put>
    8bc8:	eb 8c                	jmp    8b56 <fwp_write+0x96>
    8bca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8bd0:	49 89 e9             	mov    %rbp,%r9
    8bd3:	4c 8d 05 36 26 00 00 	lea    0x2636(%rip),%r8        # b210 <_IO_stdin_used+0x210>
    8bda:	eb ae                	jmp    8b8a <fwp_write+0xca>
    8bdc:	0f 1f 40 00          	nopl   0x0(%rax)
    8be0:	83 fa 13             	cmp    $0x13,%edx
    8be3:	48 8d 05 1c 26 00 00 	lea    0x261c(%rip),%rax        # b206 <_IO_stdin_used+0x206>
    8bea:	48 8d 35 1a 26 00 00 	lea    0x261a(%rip),%rsi        # b20b <_IO_stdin_used+0x20b>
    8bf1:	ba 04 00 00 00       	mov    $0x4,%edx
    8bf6:	48 0f 44 f0          	cmove  %rax,%rsi
    8bfa:	45 31 ed             	xor    %r13d,%r13d
    8bfd:	e8 ce b4 ff ff       	call   40d0 <buf_put>
    8c02:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    8c07:	0f 84 a3 08 00 00    	je     94b0 <fwp_write+0x9f0>
    8c0d:	41 83 3c 24 13       	cmpl   $0x13,(%r12)
    8c12:	4b 8d 44 2d 00       	lea    0x0(%r13,%r13,1),%rax
    8c17:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8c1c:	48 89 df             	mov    %rbx,%rdi
    8c1f:	49 0f 44 c5          	cmove  %r13,%rax
    8c23:	31 c9                	xor    %ecx,%ecx
    8c25:	48 8b 74 c5 08       	mov    0x8(%rbp,%rax,8),%rsi
    8c2a:	e8 91 fe ff ff       	call   8ac0 <fwp_write>
    8c2f:	41 83 3c 24 12       	cmpl   $0x12,(%r12)
    8c34:	0f 84 6e 09 00 00    	je     95a8 <fwp_write+0xae8>
    8c3a:	49 83 c5 01          	add    $0x1,%r13
    8c3e:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    8c42:	0f 83 68 08 00 00    	jae    94b0 <fwp_write+0x9f0>
    8c48:	ba 02 00 00 00       	mov    $0x2,%edx
    8c4d:	48 8d 35 01 26 00 00 	lea    0x2601(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8c54:	48 89 df             	mov    %rbx,%rdi
    8c57:	e8 74 b4 ff ff       	call   40d0 <buf_put>
    8c5c:	eb af                	jmp    8c0d <fwp_write+0x14d>
    8c5e:	66 90                	xchg   %ax,%ax
    8c60:	ba 06 00 00 00       	mov    $0x6,%edx
    8c65:	48 8d 35 c2 25 00 00 	lea    0x25c2(%rip),%rsi        # b22e <_IO_stdin_used+0x22e>
    8c6c:	48 83 c5 10          	add    $0x10,%rbp
    8c70:	e8 5b b4 ff ff       	call   40d0 <buf_put>
    8c75:	48 89 ef             	mov    %rbp,%rdi
    8c78:	e8 c3 a7 ff ff       	call   3440 <strlen@plt>
    8c7d:	48 89 ee             	mov    %rbp,%rsi
    8c80:	48 89 df             	mov    %rbx,%rdi
    8c83:	48 89 c2             	mov    %rax,%rdx
    8c86:	e8 45 b4 ff ff       	call   40d0 <buf_put>
    8c8b:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8c90:	ba 01 00 00 00       	mov    $0x1,%edx
    8c95:	48 89 df             	mov    %rbx,%rdi
    8c98:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8c9d:	e8 2e b4 ff ff       	call   40d0 <buf_put>
    8ca2:	e9 af fe ff ff       	jmp    8b56 <fwp_write+0x96>
    8ca7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8cae:	00 00 
    8cb0:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8cb7:	00 
    8cb8:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8cbf:	00 00 
    8cc1:	0f 85 ce 02 00 00    	jne    8f95 <fwp_write+0x4d5>
    8cc7:	ba 0a 00 00 00       	mov    $0xa,%edx
    8ccc:	48 8d 35 47 25 00 00 	lea    0x2547(%rip),%rsi        # b21a <_IO_stdin_used+0x21a>
    8cd3:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
    8cda:	48 89 df             	mov    %rbx,%rdi
    8cdd:	5b                   	pop    %rbx
    8cde:	5d                   	pop    %rbp
    8cdf:	41 5c                	pop    %r12
    8ce1:	41 5d                	pop    %r13
    8ce3:	41 5e                	pop    %r14
    8ce5:	41 5f                	pop    %r15
    8ce7:	e9 e4 b3 ff ff       	jmp    40d0 <buf_put>
    8cec:	0f 1f 40 00          	nopl   0x0(%rax)
    8cf0:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
    8cf5:	4d 85 ed             	test   %r13,%r13
    8cf8:	0f 84 02 0c 00 00    	je     9900 <fwp_write+0xe40>
    8cfe:	48 8d 35 5d 25 00 00 	lea    0x255d(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    8d05:	4c 89 ef             	mov    %r13,%rdi
    8d08:	e8 13 a8 ff ff       	call   3520 <strcmp@plt>
    8d0d:	41 89 c1             	mov    %eax,%r9d
    8d10:	85 c0                	test   %eax,%eax
    8d12:	0f 84 6c 0c 00 00    	je     9984 <fwp_write+0xec4>
    8d18:	4c 89 ef             	mov    %r13,%rdi
    8d1b:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    8d20:	e8 1b a7 ff ff       	call   3440 <strlen@plt>
    8d25:	4c 89 ee             	mov    %r13,%rsi
    8d28:	48 89 df             	mov    %rbx,%rdi
    8d2b:	48 89 c2             	mov    %rax,%rdx
    8d2e:	e8 9d b3 ff ff       	call   40d0 <buf_put>
    8d33:	ba 01 00 00 00       	mov    $0x1,%edx
    8d38:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8d3d:	48 89 df             	mov    %rbx,%rdi
    8d40:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    8d45:	e8 86 b3 ff ff       	call   40d0 <buf_put>
    8d4a:	ba 01 00 00 00       	mov    $0x1,%edx
    8d4f:	4c 89 fe             	mov    %r15,%rsi
    8d52:	48 89 df             	mov    %rbx,%rdi
    8d55:	c6 44 24 3f 7b       	movb   $0x7b,0x3f(%rsp)
    8d5a:	e8 71 b3 ff ff       	call   40d0 <buf_put>
    8d5f:	41 8b 54 24 10       	mov    0x10(%r12),%edx
    8d64:	45 31 f6             	xor    %r14d,%r14d
    8d67:	85 d2                	test   %edx,%edx
    8d69:	0f 8e 81 0a 00 00    	jle    97f0 <fwp_write+0xd30>
    8d6f:	45 31 ed             	xor    %r13d,%r13d
    8d72:	4d 85 ed             	test   %r13,%r13
    8d75:	0f 85 75 07 00 00    	jne    94f0 <fwp_write+0xa30>
    8d7b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    8d82:	00 
    8d83:	45 85 f6             	test   %r14d,%r14d
    8d86:	0f 84 84 07 00 00    	je     9510 <fwp_write+0xa50>
    8d8c:	49 8b 44 24 20       	mov    0x20(%r12),%rax
    8d91:	4a 8b 74 ed 08       	mov    0x8(%rbp,%r13,8),%rsi
    8d96:	48 89 df             	mov    %rbx,%rdi
    8d99:	49 83 c5 01          	add    $0x1,%r13
    8d9d:	48 8b 14 08          	mov    (%rax,%rcx,1),%rdx
    8da1:	31 c9                	xor    %ecx,%ecx
    8da3:	e8 18 fd ff ff       	call   8ac0 <fwp_write>
    8da8:	45 39 6c 24 10       	cmp    %r13d,0x10(%r12)
    8dad:	7f c3                	jg     8d72 <fwp_write+0x2b2>
    8daf:	45 85 f6             	test   %r14d,%r14d
    8db2:	0f 84 38 0a 00 00    	je     97f0 <fwp_write+0xd30>
    8db8:	b8 29 00 00 00       	mov    $0x29,%eax
    8dbd:	ba 01 00 00 00       	mov    $0x1,%edx
    8dc2:	4c 89 fe             	mov    %r15,%rsi
    8dc5:	48 89 df             	mov    %rbx,%rdi
    8dc8:	88 44 24 3f          	mov    %al,0x3f(%rsp)
    8dcc:	e8 ff b2 ff ff       	call   40d0 <buf_put>
    8dd1:	e9 80 fd ff ff       	jmp    8b56 <fwp_write+0x96>
    8dd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8ddd:	00 00 00 
    8de0:	ba 01 00 00 00       	mov    $0x1,%edx
    8de5:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    8dea:	c6 44 24 3f 5b       	movb   $0x5b,0x3f(%rsp)
    8def:	e8 dc b2 ff ff       	call   40d0 <buf_put>
    8df4:	48 85 ed             	test   %rbp,%rbp
    8df7:	0f 84 93 06 00 00    	je     9490 <fwp_write+0x9d0>
    8dfd:	48 8b 75 08          	mov    0x8(%rbp),%rsi
    8e01:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    8e06:	31 c9                	xor    %ecx,%ecx
    8e08:	48 89 df             	mov    %rbx,%rdi
    8e0b:	e8 b0 fc ff ff       	call   8ac0 <fwp_write>
    8e10:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
    8e14:	48 85 ed             	test   %rbp,%rbp
    8e17:	0f 84 73 06 00 00    	je     9490 <fwp_write+0x9d0>
    8e1d:	ba 02 00 00 00       	mov    $0x2,%edx
    8e22:	48 8d 35 2c 24 00 00 	lea    0x242c(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    8e29:	48 89 df             	mov    %rbx,%rdi
    8e2c:	e8 9f b2 ff ff       	call   40d0 <buf_put>
    8e31:	eb ca                	jmp    8dfd <fwp_write+0x33d>
    8e33:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    8e38:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
    8e3c:	85 f6                	test   %esi,%esi
    8e3e:	0f 84 fc 07 00 00    	je     9640 <fwp_write+0xb80>
    8e44:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8e4b:	00 
    8e4c:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8e53:	00 00 
    8e55:	0f 85 3a 01 00 00    	jne    8f95 <fwp_write+0x4d5>
    8e5b:	48 8d 75 08          	lea    0x8(%rbp),%rsi
    8e5f:	4c 89 ea             	mov    %r13,%rdx
    8e62:	e9 6c fe ff ff       	jmp    8cd3 <fwp_write+0x213>
    8e67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    8e6e:	00 00 
    8e70:	48 8d 6c 24 3f       	lea    0x3f(%rsp),%rbp
    8e75:	ba 01 00 00 00       	mov    $0x1,%edx
    8e7a:	c6 44 24 3f 3c       	movb   $0x3c,0x3f(%rsp)
    8e7f:	48 89 ee             	mov    %rbp,%rsi
    8e82:	e8 49 b2 ff ff       	call   40d0 <buf_put>
    8e87:	4d 8b 64 24 08       	mov    0x8(%r12),%r12
    8e8c:	4c 89 e7             	mov    %r12,%rdi
    8e8f:	e8 ac a5 ff ff       	call   3440 <strlen@plt>
    8e94:	4c 89 e6             	mov    %r12,%rsi
    8e97:	48 89 df             	mov    %rbx,%rdi
    8e9a:	48 89 c2             	mov    %rax,%rdx
    8e9d:	e8 2e b2 ff ff       	call   40d0 <buf_put>
    8ea2:	ba 01 00 00 00       	mov    $0x1,%edx
    8ea7:	48 89 ee             	mov    %rbp,%rsi
    8eaa:	48 89 df             	mov    %rbx,%rdi
    8ead:	c6 44 24 3f 3e       	movb   $0x3e,0x3f(%rsp)
    8eb2:	e8 19 b2 ff ff       	call   40d0 <buf_put>
    8eb7:	e9 9a fc ff ff       	jmp    8b56 <fwp_write+0x96>
    8ebc:	0f 1f 40 00          	nopl   0x0(%rax)
    8ec0:	66 48 0f 6e cd       	movq   %rbp,%xmm1
    8ec5:	66 0f 2e c9          	ucomisd %xmm1,%xmm1
    8ec9:	0f 8a 8e 0b 00 00    	jp     9a5d <fwp_write+0xf9d>
    8ecf:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8ed3:	66 0f 54 05 25 2e 00 	andpd  0x2e25(%rip),%xmm0        # bd00 <msg.4+0x90>
    8eda:	00 
    8edb:	bd 01 00 00 00       	mov    $0x1,%ebp
    8ee0:	66 0f 2e 05 50 2e 00 	ucomisd 0x2e50(%rip),%xmm0        # bd38 <msg.4+0xc8>
    8ee7:	00 
    8ee8:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    8eef:	00 
    8ef0:	0f 87 b2 09 00 00    	ja     98a8 <fwp_write+0xde8>
    8ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    8efd:	00 00 00 
    8f00:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8f04:	89 ee                	mov    %ebp,%esi
    8f06:	4c 89 e7             	mov    %r12,%rdi
    8f09:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
    8f0e:	e8 3d b8 ff ff       	call   4750 <fwp_format_g.constprop.0>
    8f13:	31 f6                	xor    %esi,%esi
    8f15:	4c 89 e7             	mov    %r12,%rdi
    8f18:	e8 e3 a4 ff ff       	call   3400 <strtod@plt>
    8f1d:	f2 0f 10 0c 24       	movsd  (%rsp),%xmm1
    8f22:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
    8f26:	7a 06                	jp     8f2e <fwp_write+0x46e>
    8f28:	0f 84 e9 01 00 00    	je     9117 <fwp_write+0x657>
    8f2e:	83 c5 01             	add    $0x1,%ebp
    8f31:	83 fd 12             	cmp    $0x12,%ebp
    8f34:	75 ca                	jne    8f00 <fwp_write+0x440>
    8f36:	be 11 00 00 00       	mov    $0x11,%esi
    8f3b:	66 0f 28 c1          	movapd %xmm1,%xmm0
    8f3f:	4c 89 e7             	mov    %r12,%rdi
    8f42:	e8 09 b8 ff ff       	call   4750 <fwp_format_g.constprop.0>
    8f47:	e9 cb 01 00 00       	jmp    9117 <fwp_write+0x657>
    8f4c:	0f 1f 40 00          	nopl   0x0(%rax)
    8f50:	48 83 fd 01          	cmp    $0x1,%rbp
    8f54:	0f 84 e6 08 00 00    	je     9840 <fwp_write+0xd80>
    8f5a:	48 83 fd ff          	cmp    $0xffffffffffffffff,%rbp
    8f5e:	b8 02 00 00 00       	mov    $0x2,%eax
    8f63:	ba 01 00 00 00       	mov    $0x1,%edx
    8f68:	48 0f 44 d0          	cmove  %rax,%rdx
    8f6c:	48 8d 35 8b 22 00 00 	lea    0x228b(%rip),%rsi        # b1fe <_IO_stdin_used+0x1fe>
    8f73:	48 8d 05 89 22 00 00 	lea    0x2289(%rip),%rax        # b203 <_IO_stdin_used+0x203>
    8f7a:	48 0f 44 f0          	cmove  %rax,%rsi
    8f7e:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    8f85:	00 
    8f86:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    8f8d:	00 00 
    8f8f:	0f 84 3e fd ff ff    	je     8cd3 <fwp_write+0x213>
    8f95:	e8 b6 a4 ff ff       	call   3450 <__stack_chk_fail@plt>
    8f9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    8fa0:	4d 63 64 24 48       	movslq 0x48(%r12),%r12
    8fa5:	49 8d 74 24 02       	lea    0x2(%r12),%rsi
    8faa:	e8 61 b0 ff ff       	call   4010 <buf_grow>
    8faf:	4c 8b 4b 08          	mov    0x8(%rbx),%r9
    8fb3:	41 ba 30 74 00 00    	mov    $0x7430,%r10d
    8fb9:	4c 03 0b             	add    (%rbx),%r9
    8fbc:	66 45 89 11          	mov    %r10w,(%r9)
    8fc0:	45 85 e4             	test   %r12d,%r12d
    8fc3:	0f 8e 07 05 00 00    	jle    94d0 <fwp_write+0xa10>
    8fc9:	49 b8 56 55 55 55 55 	movabs $0x5555555555555556,%r8
    8fd0:	55 55 55 
    8fd3:	4b 8d 7c 21 01       	lea    0x1(%r9,%r12,1),%rdi
    8fd8:	49 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r10
    8fdf:	aa aa aa 
    8fe2:	49 83 c1 01          	add    $0x1,%r9
    8fe6:	eb 45                	jmp    902d <fwp_write+0x56d>
    8fe8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    8fef:	00 
    8ff0:	be 01 00 00 00       	mov    $0x1,%esi
    8ff5:	b8 2d 00 00 00       	mov    $0x2d,%eax
    8ffa:	88 07                	mov    %al,(%rdi)
    8ffc:	48 89 e8             	mov    %rbp,%rax
    8fff:	49 f7 e8             	imul   %r8
    9002:	48 89 e8             	mov    %rbp,%rax
    9005:	48 c1 f8 3f          	sar    $0x3f,%rax
    9009:	48 29 c2             	sub    %rax,%rdx
    900c:	48 85 c9             	test   %rcx,%rcx
    900f:	0f 95 c0             	setne  %al
    9012:	48 c1 ed 3f          	shr    $0x3f,%rbp
    9016:	48 83 ef 01          	sub    $0x1,%rdi
    901a:	48 21 c5             	and    %rax,%rbp
    901d:	48 29 ea             	sub    %rbp,%rdx
    9020:	48 8d 2c 32          	lea    (%rdx,%rsi,1),%rbp
    9024:	49 39 f9             	cmp    %rdi,%r9
    9027:	0f 84 a3 04 00 00    	je     94d0 <fwp_write+0xa10>
    902d:	48 89 e8             	mov    %rbp,%rax
    9030:	49 f7 e8             	imul   %r8
    9033:	48 89 e8             	mov    %rbp,%rax
    9036:	48 c1 f8 3f          	sar    $0x3f,%rax
    903a:	48 89 d1             	mov    %rdx,%rcx
    903d:	48 29 c1             	sub    %rax,%rcx
    9040:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
    9044:	48 89 e9             	mov    %rbp,%rcx
    9047:	48 29 c1             	sub    %rax,%rcx
    904a:	48 8d 41 03          	lea    0x3(%rcx),%rax
    904e:	49 f7 e2             	mul    %r10
    9051:	b8 30 00 00 00       	mov    $0x30,%eax
    9056:	48 89 d6             	mov    %rdx,%rsi
    9059:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
    905d:	48 d1 ee             	shr    $1,%rsi
    9060:	48 01 f2             	add    %rsi,%rdx
    9063:	48 8d 71 03          	lea    0x3(%rcx),%rsi
    9067:	48 29 d6             	sub    %rdx,%rsi
    906a:	74 8e                	je     8ffa <fwp_write+0x53a>
    906c:	48 83 fe 01          	cmp    $0x1,%rsi
    9070:	0f 85 7a ff ff ff    	jne    8ff0 <fwp_write+0x530>
    9076:	31 f6                	xor    %esi,%esi
    9078:	b8 2b 00 00 00       	mov    $0x2b,%eax
    907d:	e9 78 ff ff ff       	jmp    8ffa <fwp_write+0x53a>
    9082:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9088:	66 0f 6e cd          	movd   %ebp,%xmm1
    908c:	0f 2e c9             	ucomiss %xmm1,%xmm1
    908f:	0f 8a c8 09 00 00    	jp     9a5d <fwp_write+0xf9d>
    9095:	0f 28 c1             	movaps %xmm1,%xmm0
    9098:	0f 54 05 51 2c 00 00 	andps  0x2c51(%rip),%xmm0        # bcf0 <msg.4+0x80>
    909f:	0f 2e 05 5e 1f 00 00 	ucomiss 0x1f5e(%rip),%xmm0        # b004 <_IO_stdin_used+0x4>
    90a6:	0f 87 24 08 00 00    	ja     98d0 <fwp_write+0xe10>
    90ac:	66 0f ef d2          	pxor   %xmm2,%xmm2
    90b0:	41 bd 01 00 00 00    	mov    $0x1,%r13d
    90b6:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    90bd:	00 
    90be:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
    90c2:	66 49 0f 7e d7       	movq   %xmm2,%r15
    90c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    90ce:	00 00 
    90d0:	44 89 ee             	mov    %r13d,%esi
    90d3:	66 49 0f 6e c7       	movq   %r15,%xmm0
    90d8:	4c 89 e7             	mov    %r12,%rdi
    90db:	f3 0f 11 0c 24       	movss  %xmm1,(%rsp)
    90e0:	e8 6b b6 ff ff       	call   4750 <fwp_format_g.constprop.0>
    90e5:	31 f6                	xor    %esi,%esi
    90e7:	4c 89 e7             	mov    %r12,%rdi
    90ea:	e8 b1 a3 ff ff       	call   34a0 <strtof@plt>
    90ef:	f3 0f 10 0c 24       	movss  (%rsp),%xmm1
    90f4:	0f 2e c8             	ucomiss %xmm0,%xmm1
    90f7:	7a 02                	jp     90fb <fwp_write+0x63b>
    90f9:	74 1c                	je     9117 <fwp_write+0x657>
    90fb:	41 83 c5 01          	add    $0x1,%r13d
    90ff:	41 83 fd 0a          	cmp    $0xa,%r13d
    9103:	75 cb                	jne    90d0 <fwp_write+0x610>
    9105:	be 09 00 00 00       	mov    $0x9,%esi
    910a:	66 49 0f 6e c7       	movq   %r15,%xmm0
    910f:	4c 89 e7             	mov    %r12,%rdi
    9112:	e8 39 b6 ff ff       	call   4750 <fwp_format_g.constprop.0>
    9117:	4c 89 e7             	mov    %r12,%rdi
    911a:	e8 71 b0 ff ff       	call   4190 <fwp_finish_float>
    911f:	e9 1c fa ff ff       	jmp    8b40 <fwp_write+0x80>
    9124:	0f 1f 40 00          	nopl   0x0(%rax)
    9128:	48 8b 75 00          	mov    0x0(%rbp),%rsi
    912c:	48 8b 55 08          	mov    0x8(%rbp),%rdx
    9130:	48 8d ac 24 80 00 00 	lea    0x80(%rsp),%rbp
    9137:	00 
    9138:	48 89 ef             	mov    %rbp,%rdi
    913b:	e8 e0 a8 ff ff       	call   3a20 <fwp_fmt_u128>
    9140:	48 89 ef             	mov    %rbp,%rdi
    9143:	e8 f8 a2 ff ff       	call   3440 <strlen@plt>
    9148:	48 89 ee             	mov    %rbp,%rsi
    914b:	48 89 df             	mov    %rbx,%rdi
    914e:	48 89 c2             	mov    %rax,%rdx
    9151:	e8 7a af ff ff       	call   40d0 <buf_put>
    9156:	e9 fb f9 ff ff       	jmp    8b56 <fwp_write+0x96>
    915b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9160:	ba 06 00 00 00       	mov    $0x6,%edx
    9165:	48 8d 35 ec 20 00 00 	lea    0x20ec(%rip),%rsi        # b258 <_IO_stdin_used+0x258>
    916c:	41 bd 00 00 00 00    	mov    $0x0,%r13d
    9172:	e8 59 af ff ff       	call   40d0 <buf_put>
    9177:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    917e:	ff ff 7f 
    9181:	48 23 55 00          	and    0x0(%rbp),%rdx
    9185:	0f 84 86 02 00 00    	je     9411 <fwp_write+0x951>
    918b:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    9190:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9194:	48 85 d2             	test   %rdx,%rdx
    9197:	0f 84 ae 00 00 00    	je     924b <fwp_write+0x78b>
    919d:	8b 0a                	mov    (%rdx),%ecx
    919f:	83 f9 1c             	cmp    $0x1c,%ecx
    91a2:	0f 84 58 06 00 00    	je     9800 <fwp_write+0xd40>
    91a8:	83 f9 1b             	cmp    $0x1b,%ecx
    91ab:	0f 87 9a 00 00 00    	ja     924b <fwp_write+0x78b>
    91b1:	be 01 00 00 00       	mov    $0x1,%esi
    91b6:	48 d3 e6             	shl    %cl,%rsi
    91b9:	f7 c6 42 00 00 0c    	test   $0xc000042,%esi
    91bf:	0f 85 4b 04 00 00    	jne    9610 <fwp_write+0xb50>
    91c5:	f7 c6 84 04 00 00    	test   $0x484,%esi
    91cb:	0f 85 0f 04 00 00    	jne    95e0 <fwp_write+0xb20>
    91d1:	83 e6 21             	and    $0x21,%esi
    91d4:	74 75                	je     924b <fwp_write+0x78b>
    91d6:	4a 8d 74 2d 08       	lea    0x8(%rbp,%r13,1),%rsi
    91db:	48 85 ff             	test   %rdi,%rdi
    91de:	79 07                	jns    91e7 <fwp_write+0x727>
    91e0:	48 8b 75 10          	mov    0x10(%rbp),%rsi
    91e4:	4c 01 ee             	add    %r13,%rsi
    91e7:	48 0f be 3e          	movsbq (%rsi),%rdi
    91eb:	85 c9                	test   %ecx,%ecx
    91ed:	40 0f b6 f7          	movzbl %dil,%esi
    91f1:	48 0f 44 f7          	cmove  %rdi,%rsi
    91f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    91fc:	00 00 00 00 
    9200:	31 c9                	xor    %ecx,%ecx
    9202:	48 89 df             	mov    %rbx,%rdi
    9205:	49 83 c5 01          	add    $0x1,%r13
    9209:	e8 b2 f8 ff ff       	call   8ac0 <fwp_write>
    920e:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
    9215:	ff ff 7f 
    9218:	48 23 55 00          	and    0x0(%rbp),%rdx
    921c:	49 39 d5             	cmp    %rdx,%r13
    921f:	0f 83 ec 01 00 00    	jae    9411 <fwp_write+0x951>
    9225:	ba 02 00 00 00       	mov    $0x2,%edx
    922a:	48 89 df             	mov    %rbx,%rdi
    922d:	48 8d 35 21 20 00 00 	lea    0x2021(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    9234:	e8 97 ae ff ff       	call   40d0 <buf_put>
    9239:	49 8b 54 24 38       	mov    0x38(%r12),%rdx
    923e:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
    9242:	48 85 d2             	test   %rdx,%rdx
    9245:	0f 85 52 ff ff ff    	jne    919d <fwp_write+0x6dd>
    924b:	4a 8d 4c ed 08       	lea    0x8(%rbp,%r13,8),%rcx
    9250:	48 85 ff             	test   %rdi,%rdi
    9253:	0f 88 cf 05 00 00    	js     9828 <fwp_write+0xd68>
    9259:	48 8b 31             	mov    (%rcx),%rsi
    925c:	eb a2                	jmp    9200 <fwp_write+0x740>
    925e:	66 90                	xchg   %ax,%ax
    9260:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9267:	00 
    9268:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    926f:	00 00 
    9271:	0f 85 1e fd ff ff    	jne    8f95 <fwp_write+0x4d5>
    9277:	ba 08 00 00 00       	mov    $0x8,%edx
    927c:	48 8d 35 a2 1f 00 00 	lea    0x1fa2(%rip),%rsi        # b225 <_IO_stdin_used+0x225>
    9283:	e9 4b fa ff ff       	jmp    8cd3 <fwp_write+0x213>
    9288:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    928f:	00 
    9290:	89 e8                	mov    %ebp,%eax
    9292:	48 81 fd ff 0f 00 00 	cmp    $0xfff,%rbp
    9299:	76 03                	jbe    929e <fwp_write+0x7de>
    929b:	8b 45 00             	mov    0x0(%rbp),%eax
    929e:	41 89 c6             	mov    %eax,%r14d
    92a1:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    92a6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
    92ab:	4e 8b 2c f0          	mov    (%rax,%r14,8),%r13
    92af:	4c 89 ef             	mov    %r13,%rdi
    92b2:	e8 89 a1 ff ff       	call   3440 <strlen@plt>
    92b7:	4c 89 ee             	mov    %r13,%rsi
    92ba:	48 89 df             	mov    %rbx,%rdi
    92bd:	48 89 c2             	mov    %rax,%rdx
    92c0:	e8 0b ae ff ff       	call   40d0 <buf_put>
    92c5:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    92ca:	42 8b 34 b0          	mov    (%rax,%r14,4),%esi
    92ce:	85 f6                	test   %esi,%esi
    92d0:	0f 8e 80 f8 ff ff    	jle    8b56 <fwp_write+0x96>
    92d6:	45 31 ed             	xor    %r13d,%r13d
    92d9:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    92de:	4a 8b 44 ed 08       	mov    0x8(%rbp,%r13,8),%rax
    92e3:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    92e8:	ba 01 00 00 00       	mov    $0x1,%edx
    92ed:	4c 89 fe             	mov    %r15,%rsi
    92f0:	48 89 04 24          	mov    %rax,(%rsp)
    92f4:	49 8b 44 24 30       	mov    0x30(%r12),%rax
    92f9:	48 8b 04 f8          	mov    (%rax,%rdi,8),%rax
    92fd:	48 89 df             	mov    %rbx,%rdi
    9300:	4e 8b 34 e8          	mov    (%rax,%r13,8),%r14
    9304:	c6 44 24 3f 20       	movb   $0x20,0x3f(%rsp)
    9309:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
    930e:	e8 bd ad ff ff       	call   40d0 <buf_put>
    9313:	41 8b 06             	mov    (%r14),%eax
    9316:	83 f8 0e             	cmp    $0xe,%eax
    9319:	0f 84 71 02 00 00    	je     9590 <fwp_write+0xad0>
    931f:	83 f8 10             	cmp    $0x10,%eax
    9322:	0f 84 38 02 00 00    	je     9560 <fwp_write+0xaa0>
    9328:	83 f8 0a             	cmp    $0xa,%eax
    932b:	0f 84 7f 04 00 00    	je     97b0 <fwp_write+0xcf0>
    9331:	0f 8f f9 00 00 00    	jg     9430 <fwp_write+0x970>
    9337:	83 f8 03             	cmp    $0x3,%eax
    933a:	0f 8f 50 04 00 00    	jg     9790 <fwp_write+0xcd0>
    9340:	85 c0                	test   %eax,%eax
    9342:	78 10                	js     9354 <fwp_write+0x894>
    9344:	48 8b 04 24          	mov    (%rsp),%rax
    9348:	48 c1 e8 3f          	shr    $0x3f,%rax
    934c:	85 c0                	test   %eax,%eax
    934e:	0f 85 f9 00 00 00    	jne    944d <fwp_write+0x98d>
    9354:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9359:	48 8b 34 24          	mov    (%rsp),%rsi
    935d:	31 c9                	xor    %ecx,%ecx
    935f:	48 89 df             	mov    %rbx,%rdi
    9362:	e8 59 f7 ff ff       	call   8ac0 <fwp_write>
    9367:	49 8b 44 24 28       	mov    0x28(%r12),%rax
    936c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    9371:	49 83 c5 01          	add    $0x1,%r13
    9375:	44 39 2c b8          	cmp    %r13d,(%rax,%rdi,4)
    9379:	0f 8f 5f ff ff ff    	jg     92de <fwp_write+0x81e>
    937f:	e9 d2 f7 ff ff       	jmp    8b56 <fwp_write+0x96>
    9384:	0f 1f 40 00          	nopl   0x0(%rax)
    9388:	ba 06 00 00 00       	mov    $0x6,%edx
    938d:	48 8d 35 b7 1e 00 00 	lea    0x1eb7(%rip),%rsi        # b24b <_IO_stdin_used+0x24b>
    9394:	45 31 ed             	xor    %r13d,%r13d
    9397:	e8 34 ad ff ff       	call   40d0 <buf_put>
    939c:	48 83 7d 00 00       	cmpq   $0x0,0x0(%rbp)
    93a1:	75 19                	jne    93bc <fwp_write+0x8fc>
    93a3:	eb 6c                	jmp    9411 <fwp_write+0x951>
    93a5:	0f 1f 00             	nopl   (%rax)
    93a8:	ba 02 00 00 00       	mov    $0x2,%edx
    93ad:	48 8d 35 a1 1e 00 00 	lea    0x1ea1(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    93b4:	48 89 df             	mov    %rbx,%rdi
    93b7:	e8 14 ad ff ff       	call   40d0 <buf_put>
    93bc:	46 0f b6 4c 2d 08    	movzbl 0x8(%rbp,%r13,1),%r9d
    93c2:	b9 00 02 00 00       	mov    $0x200,%ecx
    93c7:	31 c0                	xor    %eax,%eax
    93c9:	49 83 c5 01          	add    $0x1,%r13
    93cd:	4c 8d 05 7e 1e 00 00 	lea    0x1e7e(%rip),%r8        # b252 <_IO_stdin_used+0x252>
    93d4:	ba 02 00 00 00       	mov    $0x2,%edx
    93d9:	be 00 02 00 00       	mov    $0x200,%esi
    93de:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93e5:	00 
    93e6:	e8 b5 9f ff ff       	call   33a0 <__snprintf_chk@plt>
    93eb:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    93f2:	00 
    93f3:	e8 48 a0 ff ff       	call   3440 <strlen@plt>
    93f8:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    93ff:	00 
    9400:	48 89 df             	mov    %rbx,%rdi
    9403:	48 89 c2             	mov    %rax,%rdx
    9406:	e8 c5 ac ff ff       	call   40d0 <buf_put>
    940b:	4c 3b 6d 00          	cmp    0x0(%rbp),%r13
    940f:	72 97                	jb     93a8 <fwp_write+0x8e8>
    9411:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    9416:	ba 01 00 00 00       	mov    $0x1,%edx
    941b:	48 89 df             	mov    %rbx,%rdi
    941e:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    9423:	e8 a8 ac ff ff       	call   40d0 <buf_put>
    9428:	e9 29 f7 ff ff       	jmp    8b56 <fwp_write+0x96>
    942d:	0f 1f 00             	nopl   (%rax)
    9430:	83 f8 0b             	cmp    $0xb,%eax
    9433:	0f 85 1b ff ff ff    	jne    9354 <fwp_write+0x894>
    9439:	f2 0f 10 1c 24       	movsd  (%rsp),%xmm3
    943e:	66 0f 50 c3          	movmskpd %xmm3,%eax
    9442:	83 e0 01             	and    $0x1,%eax
    9445:	85 c0                	test   %eax,%eax
    9447:	0f 84 07 ff ff ff    	je     9354 <fwp_write+0x894>
    944d:	4c 89 fe             	mov    %r15,%rsi
    9450:	48 89 df             	mov    %rbx,%rdi
    9453:	ba 01 00 00 00       	mov    $0x1,%edx
    9458:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    945d:	e8 6e ac ff ff       	call   40d0 <buf_put>
    9462:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    9467:	48 8b 34 24          	mov    (%rsp),%rsi
    946b:	31 c9                	xor    %ecx,%ecx
    946d:	48 89 df             	mov    %rbx,%rdi
    9470:	e8 4b f6 ff ff       	call   8ac0 <fwp_write>
    9475:	ba 01 00 00 00       	mov    $0x1,%edx
    947a:	4c 89 fe             	mov    %r15,%rsi
    947d:	48 89 df             	mov    %rbx,%rdi
    9480:	c6 44 24 3f 29       	movb   $0x29,0x3f(%rsp)
    9485:	e8 46 ac ff ff       	call   40d0 <buf_put>
    948a:	e9 d8 fe ff ff       	jmp    9367 <fwp_write+0x8a7>
    948f:	90                   	nop
    9490:	ba 01 00 00 00       	mov    $0x1,%edx
    9495:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    949a:	48 89 df             	mov    %rbx,%rdi
    949d:	c6 44 24 3f 5d       	movb   $0x5d,0x3f(%rsp)
    94a2:	e8 29 ac ff ff       	call   40d0 <buf_put>
    94a7:	e9 aa f6 ff ff       	jmp    8b56 <fwp_write+0x96>
    94ac:	0f 1f 40 00          	nopl   0x0(%rax)
    94b0:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    94b5:	ba 01 00 00 00       	mov    $0x1,%edx
    94ba:	48 89 df             	mov    %rbx,%rdi
    94bd:	c6 44 24 3f 7d       	movb   $0x7d,0x3f(%rsp)
    94c2:	e8 09 ac ff ff       	call   40d0 <buf_put>
    94c7:	e9 8a f6 ff ff       	jmp    8b56 <fwp_write+0x96>
    94cc:	0f 1f 40 00          	nopl   0x0(%rax)
    94d0:	48 8b 43 08          	mov    0x8(%rbx),%rax
    94d4:	48 8b 13             	mov    (%rbx),%rdx
    94d7:	49 8d 44 04 02       	lea    0x2(%r12,%rax,1),%rax
    94dc:	48 89 43 08          	mov    %rax,0x8(%rbx)
    94e0:	c6 04 02 00          	movb   $0x0,(%rdx,%rax,1)
    94e4:	e9 6d f6 ff ff       	jmp    8b56 <fwp_write+0x96>
    94e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    94f0:	ba 02 00 00 00       	mov    $0x2,%edx
    94f5:	48 8d 35 59 1d 00 00 	lea    0x1d59(%rip),%rsi        # b255 <_IO_stdin_used+0x255>
    94fc:	48 89 df             	mov    %rbx,%rdi
    94ff:	e8 cc ab ff ff       	call   40d0 <buf_put>
    9504:	e9 72 f8 ff ff       	jmp    8d7b <fwp_write+0x2bb>
    9509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9510:	49 8b 44 24 18       	mov    0x18(%r12),%rax
    9515:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
    951a:	4a 8b 34 e8          	mov    (%rax,%r13,8),%rsi
    951e:	48 89 f7             	mov    %rsi,%rdi
    9521:	48 89 34 24          	mov    %rsi,(%rsp)
    9525:	e8 16 9f ff ff       	call   3440 <strlen@plt>
    952a:	48 8b 34 24          	mov    (%rsp),%rsi
    952e:	48 89 df             	mov    %rbx,%rdi
    9531:	48 89 c2             	mov    %rax,%rdx
    9534:	e8 97 ab ff ff       	call   40d0 <buf_put>
    9539:	ba 03 00 00 00       	mov    $0x3,%edx
    953e:	48 8d 35 33 1d 00 00 	lea    0x1d33(%rip),%rsi        # b278 <_IO_stdin_used+0x278>
    9545:	48 89 df             	mov    %rbx,%rdi
    9548:	e8 83 ab ff ff       	call   40d0 <buf_put>
    954d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    9552:	e9 35 f8 ff ff       	jmp    8d8c <fwp_write+0x2cc>
    9557:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    955e:	00 00 
    9560:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    9565:	48 8b 78 08          	mov    0x8(%rax),%rdi
    9569:	48 85 ff             	test   %rdi,%rdi
    956c:	0f 84 e2 fd ff ff    	je     9354 <fwp_write+0x894>
    9572:	48 8d 35 e9 1c 00 00 	lea    0x1ce9(%rip),%rsi        # b262 <_IO_stdin_used+0x262>
    9579:	e8 a2 9f ff ff       	call   3520 <strcmp@plt>
    957e:	85 c0                	test   %eax,%eax
    9580:	0f 95 c0             	setne  %al
    9583:	0f b6 c0             	movzbl %al,%eax
    9586:	e9 c1 fd ff ff       	jmp    934c <fwp_write+0x88c>
    958b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    9590:	31 c0                	xor    %eax,%eax
    9592:	48 81 3c 24 ff 0f 00 	cmpq   $0xfff,(%rsp)
    9599:	00 
    959a:	0f 97 c0             	seta   %al
    959d:	e9 aa fd ff ff       	jmp    934c <fwp_write+0x88c>
    95a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    95a8:	48 89 df             	mov    %rbx,%rdi
    95ab:	ba 02 00 00 00       	mov    $0x2,%edx
    95b0:	48 8d 35 a8 1c 00 00 	lea    0x1ca8(%rip),%rsi        # b25f <_IO_stdin_used+0x25f>
    95b7:	e8 14 ab ff ff       	call   40d0 <buf_put>
    95bc:	4c 89 e8             	mov    %r13,%rax
    95bf:	49 8b 54 24 40       	mov    0x40(%r12),%rdx
    95c4:	31 c9                	xor    %ecx,%ecx
    95c6:	48 c1 e0 04          	shl    $0x4,%rax
    95ca:	48 89 df             	mov    %rbx,%rdi
    95cd:	48 8b 74 05 10       	mov    0x10(%rbp,%rax,1),%rsi
    95d2:	e8 e9 f4 ff ff       	call   8ac0 <fwp_write>
    95d7:	e9 5e f6 ff ff       	jmp    8c3a <fwp_write+0x17a>
    95dc:	0f 1f 40 00          	nopl   0x0(%rax)
    95e0:	4a 8d 74 ad 08       	lea    0x8(%rbp,%r13,4),%rsi
    95e5:	48 85 ff             	test   %rdi,%rdi
    95e8:	79 0c                	jns    95f6 <fwp_write+0xb36>
    95ea:	4a 8d 34 ad 00 00 00 	lea    0x0(,%r13,4),%rsi
    95f1:	00 
    95f2:	48 03 75 10          	add    0x10(%rbp),%rsi
    95f6:	48 63 3e             	movslq (%rsi),%rdi
    95f9:	83 f9 02             	cmp    $0x2,%ecx
    95fc:	89 fe                	mov    %edi,%esi
    95fe:	48 0f 44 f7          	cmove  %rdi,%rsi
    9602:	e9 f9 fb ff ff       	jmp    9200 <fwp_write+0x740>
    9607:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    960e:	00 00 
    9610:	4b 8d 74 2d 00       	lea    0x0(%r13,%r13,1),%rsi
    9615:	4c 8d 44 35 08       	lea    0x8(%rbp,%rsi,1),%r8
    961a:	48 85 ff             	test   %rdi,%rdi
    961d:	0f 88 0f 03 00 00    	js     9932 <fwp_write+0xe72>
    9623:	49 0f bf 38          	movswq (%r8),%rdi
    9627:	83 f9 01             	cmp    $0x1,%ecx
    962a:	0f b7 f7             	movzwl %di,%esi
    962d:	48 0f 44 f7          	cmove  %rdi,%rsi
    9631:	e9 ca fb ff ff       	jmp    9200 <fwp_write+0x740>
    9636:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    963d:	00 00 00 
    9640:	ba 01 00 00 00       	mov    $0x1,%edx
    9645:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    964a:	48 83 c5 08          	add    $0x8,%rbp
    964e:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9653:	e8 78 aa ff ff       	call   40d0 <buf_put>
    9658:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    965d:	4e 8d 64 2d 00       	lea    0x0(%rbp,%r13,1),%r12
    9662:	4d 85 ed             	test   %r13,%r13
    9665:	75 46                	jne    96ad <fwp_write+0xbed>
    9667:	e9 04 01 00 00       	jmp    9770 <fwp_write+0xcb0>
    966c:	0f 1f 40 00          	nopl   0x0(%rax)
    9670:	41 80 f9 09          	cmp    $0x9,%r9b
    9674:	0f 84 d6 00 00 00    	je     9750 <fwp_write+0xc90>
    967a:	41 80 f9 0a          	cmp    $0xa,%r9b
    967e:	0f 85 9c 00 00 00    	jne    9720 <fwp_write+0xc60>
    9684:	ba 02 00 00 00       	mov    $0x2,%edx
    9689:	48 8d 35 ab 1b 00 00 	lea    0x1bab(%rip),%rsi        # b23b <_IO_stdin_used+0x23b>
    9690:	48 89 df             	mov    %rbx,%rdi
    9693:	e8 38 aa ff ff       	call   40d0 <buf_put>
    9698:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    969f:	00 
    96a0:	48 83 c5 01          	add    $0x1,%rbp
    96a4:	49 39 ec             	cmp    %rbp,%r12
    96a7:	0f 84 c3 00 00 00    	je     9770 <fwp_write+0xcb0>
    96ad:	44 0f be 4d 00       	movsbl 0x0(%rbp),%r9d
    96b2:	41 80 f9 0d          	cmp    $0xd,%r9b
    96b6:	74 28                	je     96e0 <fwp_write+0xc20>
    96b8:	7e b6                	jle    9670 <fwp_write+0xbb0>
    96ba:	41 80 f9 22          	cmp    $0x22,%r9b
    96be:	74 40                	je     9700 <fwp_write+0xc40>
    96c0:	41 80 f9 5c          	cmp    $0x5c,%r9b
    96c4:	75 5a                	jne    9720 <fwp_write+0xc60>
    96c6:	ba 02 00 00 00       	mov    $0x2,%edx
    96cb:	48 8d 35 66 1b 00 00 	lea    0x1b66(%rip),%rsi        # b238 <_IO_stdin_used+0x238>
    96d2:	48 89 df             	mov    %rbx,%rdi
    96d5:	e8 f6 a9 ff ff       	call   40d0 <buf_put>
    96da:	eb c4                	jmp    96a0 <fwp_write+0xbe0>
    96dc:	0f 1f 40 00          	nopl   0x0(%rax)
    96e0:	ba 02 00 00 00       	mov    $0x2,%edx
    96e5:	48 8d 35 55 1b 00 00 	lea    0x1b55(%rip),%rsi        # b241 <_IO_stdin_used+0x241>
    96ec:	48 89 df             	mov    %rbx,%rdi
    96ef:	e8 dc a9 ff ff       	call   40d0 <buf_put>
    96f4:	eb aa                	jmp    96a0 <fwp_write+0xbe0>
    96f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    96fd:	00 00 00 
    9700:	ba 02 00 00 00       	mov    $0x2,%edx
    9705:	48 8d 35 29 1b 00 00 	lea    0x1b29(%rip),%rsi        # b235 <_IO_stdin_used+0x235>
    970c:	48 89 df             	mov    %rbx,%rdi
    970f:	e8 bc a9 ff ff       	call   40d0 <buf_put>
    9714:	eb 8a                	jmp    96a0 <fwp_write+0xbe0>
    9716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    971d:	00 00 00 
    9720:	41 80 f9 1f          	cmp    $0x1f,%r9b
    9724:	0f 86 2e 01 00 00    	jbe    9858 <fwp_write+0xd98>
    972a:	41 80 f9 7f          	cmp    $0x7f,%r9b
    972e:	0f 84 24 01 00 00    	je     9858 <fwp_write+0xd98>
    9734:	ba 01 00 00 00       	mov    $0x1,%edx
    9739:	4c 89 fe             	mov    %r15,%rsi
    973c:	48 89 df             	mov    %rbx,%rdi
    973f:	44 88 4c 24 3f       	mov    %r9b,0x3f(%rsp)
    9744:	e8 87 a9 ff ff       	call   40d0 <buf_put>
    9749:	e9 52 ff ff ff       	jmp    96a0 <fwp_write+0xbe0>
    974e:	66 90                	xchg   %ax,%ax
    9750:	ba 02 00 00 00       	mov    $0x2,%edx
    9755:	48 8d 35 e2 1a 00 00 	lea    0x1ae2(%rip),%rsi        # b23e <_IO_stdin_used+0x23e>
    975c:	48 89 df             	mov    %rbx,%rdi
    975f:	e8 6c a9 ff ff       	call   40d0 <buf_put>
    9764:	e9 37 ff ff ff       	jmp    96a0 <fwp_write+0xbe0>
    9769:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9770:	ba 01 00 00 00       	mov    $0x1,%edx
    9775:	4c 89 fe             	mov    %r15,%rsi
    9778:	48 89 df             	mov    %rbx,%rdi
    977b:	c6 44 24 3f 22       	movb   $0x22,0x3f(%rsp)
    9780:	e8 4b a9 ff ff       	call   40d0 <buf_put>
    9785:	e9 cc f3 ff ff       	jmp    8b56 <fwp_write+0x96>
    978a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9790:	83 f8 04             	cmp    $0x4,%eax
    9793:	0f 85 bb fb ff ff    	jne    9354 <fwp_write+0x894>
    9799:	48 8b 04 24          	mov    (%rsp),%rax
    979d:	48 8b 40 08          	mov    0x8(%rax),%rax
    97a1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    97a6:	48 c1 e8 3f          	shr    $0x3f,%rax
    97aa:	e9 96 fc ff ff       	jmp    9445 <fwp_write+0x985>
    97af:	90                   	nop
    97b0:	8b 0c 24             	mov    (%rsp),%ecx
    97b3:	31 c0                	xor    %eax,%eax
    97b5:	85 c9                	test   %ecx,%ecx
    97b7:	0f 98 c0             	sets   %al
    97ba:	e9 86 fc ff ff       	jmp    9445 <fwp_write+0x985>
    97bf:	90                   	nop
    97c0:	48 f7 d8             	neg    %rax
    97c3:	48 8d bc 24 81 00 00 	lea    0x81(%rsp),%rdi
    97ca:	00 
    97cb:	c6 84 24 80 00 00 00 	movb   $0x2d,0x80(%rsp)
    97d2:	2d 
    97d3:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    97da:	00 
    97db:	48 83 d2 00          	adc    $0x0,%rdx
    97df:	48 89 c6             	mov    %rax,%rsi
    97e2:	48 f7 da             	neg    %rdx
    97e5:	e8 36 a2 ff ff       	call   3a20 <fwp_fmt_u128>
    97ea:	e9 51 f3 ff ff       	jmp    8b40 <fwp_write+0x80>
    97ef:	90                   	nop
    97f0:	b8 7d 00 00 00       	mov    $0x7d,%eax
    97f5:	e9 c3 f5 ff ff       	jmp    8dbd <fwp_write+0x2fd>
    97fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9800:	4c 89 e9             	mov    %r13,%rcx
    9803:	48 c1 e1 04          	shl    $0x4,%rcx
    9807:	48 8d 74 0d 08       	lea    0x8(%rbp,%rcx,1),%rsi
    980c:	48 85 ff             	test   %rdi,%rdi
    980f:	0f 89 eb f9 ff ff    	jns    9200 <fwp_write+0x740>
    9815:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9819:	48 89 ce             	mov    %rcx,%rsi
    981c:	e9 df f9 ff ff       	jmp    9200 <fwp_write+0x740>
    9821:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9828:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
    982f:	00 
    9830:	48 03 4d 10          	add    0x10(%rbp),%rcx
    9834:	e9 20 fa ff ff       	jmp    9259 <fwp_write+0x799>
    9839:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9840:	ba 02 00 00 00       	mov    $0x2,%edx
    9845:	48 8d 35 b4 19 00 00 	lea    0x19b4(%rip),%rsi        # b200 <_IO_stdin_used+0x200>
    984c:	e9 2d f7 ff ff       	jmp    8f7e <fwp_write+0x4be>
    9851:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    9858:	4c 8d 05 e5 19 00 00 	lea    0x19e5(%rip),%r8        # b244 <_IO_stdin_used+0x244>
    985f:	b9 10 00 00 00       	mov    $0x10,%ecx
    9864:	31 c0                	xor    %eax,%eax
    9866:	ba 02 00 00 00       	mov    $0x2,%edx
    986b:	be 10 00 00 00       	mov    $0x10,%esi
    9870:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9877:	00 
    9878:	e8 23 9b ff ff       	call   33a0 <__snprintf_chk@plt>
    987d:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
    9884:	00 
    9885:	e8 b6 9b ff ff       	call   3440 <strlen@plt>
    988a:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
    9891:	00 
    9892:	48 89 df             	mov    %rbx,%rdi
    9895:	48 89 c2             	mov    %rax,%rdx
    9898:	e8 33 a8 ff ff       	call   40d0 <buf_put>
    989d:	e9 fe fd ff ff       	jmp    96a0 <fwp_write+0xbe0>
    98a2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    98a8:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98ac:	48 8d 35 47 19 00 00 	lea    0x1947(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    98b3:	48 8d 05 3f 19 00 00 	lea    0x193f(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    98ba:	4c 89 e7             	mov    %r12,%rdi
    98bd:	66 0f 2f c8          	comisd %xmm0,%xmm1
    98c1:	48 0f 46 f0          	cmovbe %rax,%rsi
    98c5:	e8 16 9b ff ff       	call   33e0 <strcpy@plt>
    98ca:	e9 71 f2 ff ff       	jmp    8b40 <fwp_write+0x80>
    98cf:	90                   	nop
    98d0:	66 0f ef c0          	pxor   %xmm0,%xmm0
    98d4:	48 8d 35 1f 19 00 00 	lea    0x191f(%rip),%rsi        # b1fa <_IO_stdin_used+0x1fa>
    98db:	48 8d 05 17 19 00 00 	lea    0x1917(%rip),%rax        # b1f9 <_IO_stdin_used+0x1f9>
    98e2:	0f 2f c8             	comiss %xmm0,%xmm1
    98e5:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    98ec:	00 
    98ed:	4c 89 e7             	mov    %r12,%rdi
    98f0:	48 0f 46 f0          	cmovbe %rax,%rsi
    98f4:	e8 e7 9a ff ff       	call   33e0 <strcpy@plt>
    98f9:	e9 42 f2 ff ff       	jmp    8b40 <fwp_write+0x80>
    98fe:	66 90                	xchg   %ax,%ax
    9900:	45 8b 44 24 10       	mov    0x10(%r12),%r8d
    9905:	45 85 c0             	test   %r8d,%r8d
    9908:	75 34                	jne    993e <fwp_write+0xe7e>
    990a:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
    9911:	00 
    9912:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    9919:	00 00 
    991b:	0f 85 74 f6 ff ff    	jne    8f95 <fwp_write+0x4d5>
    9921:	ba 02 00 00 00       	mov    $0x2,%edx
    9926:	48 8d 35 48 19 00 00 	lea    0x1948(%rip),%rsi        # b275 <_IO_stdin_used+0x275>
    992d:	e9 a1 f3 ff ff       	jmp    8cd3 <fwp_write+0x213>
    9932:	48 03 75 10          	add    0x10(%rbp),%rsi
    9936:	49 89 f0             	mov    %rsi,%r8
    9939:	e9 e5 fc ff ff       	jmp    9623 <fwp_write+0xb63>
    993e:	41 8b 7c 24 48       	mov    0x48(%r12),%edi
    9943:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9948:	85 ff                	test   %edi,%edi
    994a:	0f 84 fa f3 ff ff    	je     8d4a <fwp_write+0x28a>
    9950:	ba 01 00 00 00       	mov    $0x1,%edx
    9955:	48 8d 74 24 3f       	lea    0x3f(%rsp),%rsi
    995a:	48 89 df             	mov    %rbx,%rdi
    995d:	c6 44 24 3f 28       	movb   $0x28,0x3f(%rsp)
    9962:	e8 69 a7 ff ff       	call   40d0 <buf_put>
    9967:	41 8b 44 24 10       	mov    0x10(%r12),%eax
    996c:	4c 8d 7c 24 3f       	lea    0x3f(%rsp),%r15
    9971:	41 be 01 00 00 00    	mov    $0x1,%r14d
    9977:	85 c0                	test   %eax,%eax
    9979:	0f 8f f0 f3 ff ff    	jg     8d6f <fwp_write+0x2af>
    997f:	e9 34 f4 ff ff       	jmp    8db8 <fwp_write+0x2f8>
    9984:	48 8b 45 08          	mov    0x8(%rbp),%rax
    9988:	49 89 c5             	mov    %rax,%r13
    998b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
    9990:	49 89 c4             	mov    %rax,%r12
    9993:	49 c1 fd 3f          	sar    $0x3f,%r13
    9997:	4c 09 e8             	or     %r13,%rax
    999a:	0f 84 a7 00 00 00    	je     9a47 <fwp_write+0xf87>
    99a0:	48 8d 2d 19 39 00 00 	lea    0x3919(%rip),%rbp        # d2c0 <units.0>
    99a7:	4d 89 e7             	mov    %r12,%r15
    99aa:	48 8b 45 08          	mov    0x8(%rbp),%rax
    99ae:	4c 8d 44 24 20       	lea    0x20(%rsp),%r8
    99b3:	4c 89 ff             	mov    %r15,%rdi
    99b6:	4c 89 ee             	mov    %r13,%rsi
    99b9:	44 89 0c 24          	mov    %r9d,(%rsp)
    99bd:	48 99                	cqto
    99bf:	48 89 d1             	mov    %rdx,%rcx
    99c2:	48 89 c2             	mov    %rax,%rdx
    99c5:	e8 56 10 00 00       	call   aa20 <__divmodti4>
    99ca:	44 8b 0c 24          	mov    (%rsp),%r9d
    99ce:	48 89 c1             	mov    %rax,%rcx
    99d1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    99d6:	48 0b 44 24 28       	or     0x28(%rsp),%rax
    99db:	0f 84 94 00 00 00    	je     9a75 <fwp_write+0xfb5>
    99e1:	41 83 c1 01          	add    $0x1,%r9d
    99e5:	48 83 c5 10          	add    $0x10,%rbp
    99e9:	41 83 f9 05          	cmp    $0x5,%r9d
    99ed:	75 bb                	jne    99aa <fwp_write+0xeea>
    99ef:	4d 85 ed             	test   %r13,%r13
    99f2:	79 53                	jns    9a47 <fwp_write+0xf87>
    99f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    99f9:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    99fe:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9a03:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9a08:	48 99                	cqto
    9a0a:	48 f7 d8             	neg    %rax
    9a0d:	48 83 d2 00          	adc    $0x0,%rdx
    9a11:	48 89 c6             	mov    %rax,%rsi
    9a14:	48 f7 da             	neg    %rdx
    9a17:	e8 04 a0 ff ff       	call   3a20 <fwp_fmt_u128>
    9a1c:	49 89 e8             	mov    %rbp,%r8
    9a1f:	ba 00 02 00 00       	mov    $0x200,%edx
    9a24:	be 02 00 00 00       	mov    $0x2,%esi
    9a29:	31 c0                	xor    %eax,%eax
    9a2b:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a32:	00 
    9a33:	48 8d 0d 36 18 00 00 	lea    0x1836(%rip),%rcx        # b270 <_IO_stdin_used+0x270>
    9a3a:	4c 89 e7             	mov    %r12,%rdi
    9a3d:	e8 7e 9c ff ff       	call   36c0 <__sprintf_chk@plt>
    9a42:	e9 f9 f0 ff ff       	jmp    8b40 <fwp_write+0x80>
    9a47:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9a4c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    9a51:	31 d2                	xor    %edx,%edx
    9a53:	48 89 ef             	mov    %rbp,%rdi
    9a56:	e8 c5 9f ff ff       	call   3a20 <fwp_fmt_u128>
    9a5b:	eb bf                	jmp    9a1c <fwp_write+0xf5c>
    9a5d:	c7 84 24 80 00 00 00 	movl   $0x4e614e,0x80(%rsp)
    9a64:	4e 61 4e 00 
    9a68:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9a6f:	00 
    9a70:	e9 cb f0 ff ff       	jmp    8b40 <fwp_write+0x80>
    9a75:	44 89 0c 24          	mov    %r9d,(%rsp)
    9a79:	48 89 c8             	mov    %rcx,%rax
    9a7c:	48 85 d2             	test   %rdx,%rdx
    9a7f:	78 51                	js     9ad2 <fwp_write+0x1012>
    9a81:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9a86:	48 89 c6             	mov    %rax,%rsi
    9a89:	48 89 ef             	mov    %rbp,%rdi
    9a8c:	e8 8f 9f ff ff       	call   3a20 <fwp_fmt_u128>
    9a91:	44 8b 0c 24          	mov    (%rsp),%r9d
    9a95:	49 63 c1             	movslq %r9d,%rax
    9a98:	49 89 e8             	mov    %rbp,%r8
    9a9b:	ba 00 02 00 00       	mov    $0x200,%edx
    9aa0:	be 02 00 00 00       	mov    $0x2,%esi
    9aa5:	48 c1 e0 04          	shl    $0x4,%rax
    9aa9:	48 8d 3d 10 38 00 00 	lea    0x3810(%rip),%rdi        # d2c0 <units.0>
    9ab0:	4c 8d a4 24 80 00 00 	lea    0x80(%rsp),%r12
    9ab7:	00 
    9ab8:	4c 8b 0c 07          	mov    (%rdi,%rax,1),%r9
    9abc:	48 8d 0d a8 17 00 00 	lea    0x17a8(%rip),%rcx        # b26b <_IO_stdin_used+0x26b>
    9ac3:	4c 89 e7             	mov    %r12,%rdi
    9ac6:	31 c0                	xor    %eax,%eax
    9ac8:	e8 f3 9b ff ff       	call   36c0 <__sprintf_chk@plt>
    9acd:	e9 6e f0 ff ff       	jmp    8b40 <fwp_write+0x80>
    9ad2:	48 f7 d8             	neg    %rax
    9ad5:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
    9ada:	c6 44 24 40 2d       	movb   $0x2d,0x40(%rsp)
    9adf:	48 8d 6c 24 40       	lea    0x40(%rsp),%rbp
    9ae4:	48 83 d2 00          	adc    $0x0,%rdx
    9ae8:	48 89 c6             	mov    %rax,%rsi
    9aeb:	48 f7 da             	neg    %rdx
    9aee:	e8 2d 9f ff ff       	call   3a20 <fwp_fmt_u128>
    9af3:	44 8b 0c 24          	mov    (%rsp),%r9d
    9af7:	eb 9c                	jmp    9a95 <fwp_write+0xfd5>
    9af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)

0000000000009b00 <fwp_main_thread>:
    9b00:	f3 0f 1e fa          	endbr64
    9b04:	41 57                	push   %r15
    9b06:	41 56                	push   %r14
    9b08:	41 55                	push   %r13
    9b0a:	41 54                	push   %r12
    9b0c:	55                   	push   %rbp
    9b0d:	53                   	push   %rbx
    9b0e:	48 81 ec 28 01 00 00 	sub    $0x128,%rsp
    9b15:	8b 3d a9 f0 05 00    	mov    0x5f0a9(%rip),%edi        # 68bc4 <fwp_heap+0x13a4>
    9b1b:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
    9b22:	00 00 
    9b24:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
    9b2b:	00 
    9b2c:	31 c0                	xor    %eax,%eax
    9b2e:	85 ff                	test   %edi,%edi
    9b30:	0f 84 72 07 00 00    	je     a2a8 <fwp_main_thread+0x7a8>
    9b36:	8b 35 8c f0 05 00    	mov    0x5f08c(%rip),%esi        # 68bc8 <fwp_heap+0x13a8>
    9b3c:	85 f6                	test   %esi,%esi
    9b3e:	0f 85 4c 07 00 00    	jne    a290 <fwp_main_thread+0x790>
    9b44:	48 8d 05 35 55 00 00 	lea    0x5535(%rip),%rax        # f080 <alt.5>
    9b4b:	48 8d 6c 24 20       	lea    0x20(%rsp),%rbp
    9b50:	31 f6                	xor    %esi,%esi
    9b52:	48 c7 05 63 d6 05 00 	movq   $0x40000000,0x5d663(%rip)        # 671c0 <fwp_main_stack_size>
    9b59:	00 00 00 40 
    9b5d:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
    9b62:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
    9b67:	48 89 c7             	mov    %rax,%rdi
    9b6a:	48 89 2d 57 d6 05 00 	mov    %rbp,0x5d657(%rip)        # 671c8 <fwp_main_stack_top>
    9b71:	48 c7 44 24 50 00 00 	movq   $0x10000,0x50(%rsp)
    9b78:	01 00 
    9b7a:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
    9b81:	00 
    9b82:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
    9b87:	e8 14 9b ff ff       	call   36a0 <sigaltstack@plt>
    9b8c:	85 c0                	test   %eax,%eax
    9b8e:	0f 85 43 0e 00 00    	jne    a9d7 <fwp_main_thread+0xed7>
    9b94:	31 c0                	xor    %eax,%eax
    9b96:	b9 12 00 00 00       	mov    $0x12,%ecx
    9b9b:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9ba2:	00 
    9ba3:	f3 48 ab             	rep stos %rax,(%rdi)
    9ba6:	48 8d 05 73 a1 ff ff 	lea    -0x5e8d(%rip),%rax        # 3d20 <fwp_segv>
    9bad:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
    9bb4:	00 
    9bb5:	c7 84 24 08 01 00 00 	movl   $0x8000004,0x108(%rsp)
    9bbc:	04 00 00 08 
    9bc0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
    9bc7:	00 
    9bc8:	48 8d 9c 24 80 00 00 	lea    0x80(%rsp),%rbx
    9bcf:	00 
    9bd0:	e8 8b 99 ff ff       	call   3560 <sigemptyset@plt>
    9bd5:	85 c0                	test   %eax,%eax
    9bd7:	0f 85 fa 0d 00 00    	jne    a9d7 <fwp_main_thread+0xed7>
    9bdd:	31 d2                	xor    %edx,%edx
    9bdf:	48 89 de             	mov    %rbx,%rsi
    9be2:	bf 0b 00 00 00       	mov    $0xb,%edi
    9be7:	e8 04 98 ff ff       	call   33f0 <sigaction@plt>
    9bec:	85 c0                	test   %eax,%eax
    9bee:	0f 85 e3 0d 00 00    	jne    a9d7 <fwp_main_thread+0xed7>
    9bf4:	31 d2                	xor    %edx,%edx
    9bf6:	48 89 de             	mov    %rbx,%rsi
    9bf9:	bf 07 00 00 00       	mov    $0x7,%edi
    9bfe:	e8 ed 97 ff ff       	call   33f0 <sigaction@plt>
    9c03:	85 c0                	test   %eax,%eax
    9c05:	0f 85 cc 0d 00 00    	jne    a9d7 <fwp_main_thread+0xed7>
    9c0b:	48 8b 05 2e f0 05 00 	mov    0x5f02e(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    9c12:	48 85 c0             	test   %rax,%rax
    9c15:	0f 88 35 06 00 00    	js     a250 <fwp_main_thread+0x750>
    9c1b:	66 0f ef c0          	pxor   %xmm0,%xmm0
    9c1f:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
    9c24:	48 8d 3d d5 a5 ff ff 	lea    -0x5a2b(%rip),%rdi        # 4200 <ad_raw_report>
    9c2b:	f2 0f 11 05 95 f8 05 	movsd  %xmm0,0x5f895(%rip)        # 694c8 <iteration_start_charge>
    9c32:	00 
    9c33:	c7 05 ab f8 05 00 01 	movl   $0x1,0x5f8ab(%rip)        # 694e8 <iteration_active>
    9c3a:	00 00 00 
    9c3d:	e8 ee 0f 00 00       	call   ac30 <atexit>
    9c42:	85 c0                	test   %eax,%eax
    9c44:	0f 85 aa 0d 00 00    	jne    a9f4 <fwp_main_thread+0xef4>
    9c4a:	8b 0d 18 54 00 00    	mov    0x5418(%rip),%ecx        # f068 <st.3>
    9c50:	85 c9                	test   %ecx,%ecx
    9c52:	0f 84 60 06 00 00    	je     a2b8 <fwp_main_thread+0x7b8>
    9c58:	48 8b 2d a1 db 05 00 	mov    0x5dba1(%rip),%rbp        # 67800 <fwp_cur>
    9c5f:	48 85 ed             	test   %rbp,%rbp
    9c62:	0f 84 08 03 00 00    	je     9f70 <fwp_main_thread+0x470>
    9c68:	44 0f b6 65 52       	movzbl 0x52(%rbp),%r12d
    9c6d:	c6 45 52 01          	movb   $0x1,0x52(%rbp)
    9c71:	48 89 eb             	mov    %rbp,%rbx
    9c74:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9c79:	0f 84 41 01 00 00    	je     9dc0 <fwp_main_thread+0x2c0>
    9c7f:	48 83 7d 60 00       	cmpq   $0x0,0x60(%rbp)
    9c84:	0f 84 16 02 00 00    	je     9ea0 <fwp_main_thread+0x3a0>
    9c8a:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9c8e:	0f 84 fc 01 00 00    	je     9e90 <fwp_main_thread+0x390>
    9c94:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9c98:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9c9c:	0f 85 7e 02 00 00    	jne    9f20 <fwp_main_thread+0x420>
    9ca2:	48 8b 43 60          	mov    0x60(%rbx),%rax
    9ca6:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9cad:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9cb1:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9cb8:	00 00 00 00 
    9cbc:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9cc3:	48 85 d2             	test   %rdx,%rdx
    9cc6:	74 07                	je     9ccf <fwp_main_thread+0x1cf>
    9cc8:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9ccf:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9cd3:	48 85 c0             	test   %rax,%rax
    9cd6:	74 34                	je     9d0c <fwp_main_thread+0x20c>
    9cd8:	48 89 43 68          	mov    %rax,0x68(%rbx)
    9cdc:	48 8b 05 f5 da 05 00 	mov    0x5daf5(%rip),%rax        # 677d8 <fwp_timers>
    9ce3:	c6 43 55 01          	movb   $0x1,0x55(%rbx)
    9ce7:	48 c7 83 08 01 00 00 	movq   $0x0,0x108(%rbx)
    9cee:	00 00 00 00 
    9cf2:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    9cf9:	48 85 c0             	test   %rax,%rax
    9cfc:	74 07                	je     9d05 <fwp_main_thread+0x205>
    9cfe:	48 89 98 08 01 00 00 	mov    %rbx,0x108(%rax)
    9d05:	48 89 1d cc da 05 00 	mov    %rbx,0x5dacc(%rip)        # 677d8 <fwp_timers>
    9d0c:	c6 43 56 00          	movb   $0x0,0x56(%rbx)
    9d10:	e8 db dd ff ff       	call   7af0 <fwp_block>
    9d15:	48 8b 8b 18 01 00 00 	mov    0x118(%rbx),%rcx
    9d1c:	48 85 c9             	test   %rcx,%rcx
    9d1f:	74 47                	je     9d68 <fwp_main_thread+0x268>
    9d21:	48 8b 93 20 01 00 00 	mov    0x120(%rbx),%rdx
    9d28:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9d2f:	48 85 d2             	test   %rdx,%rdx
    9d32:	0f 84 28 02 00 00    	je     9f60 <fwp_main_thread+0x460>
    9d38:	48 89 82 28 01 00 00 	mov    %rax,0x128(%rdx)
    9d3f:	48 8b 83 28 01 00 00 	mov    0x128(%rbx),%rax
    9d46:	48 85 c0             	test   %rax,%rax
    9d49:	74 07                	je     9d52 <fwp_main_thread+0x252>
    9d4b:	48 89 90 20 01 00 00 	mov    %rdx,0x120(%rax)
    9d52:	48 c7 83 28 01 00 00 	movq   $0x0,0x128(%rbx)
    9d59:	00 00 00 00 
    9d5d:	66 0f ef d2          	pxor   %xmm2,%xmm2
    9d61:	0f 11 93 18 01 00 00 	movups %xmm2,0x118(%rbx)
    9d68:	48 8b 0d 91 da 05 00 	mov    0x5da91(%rip),%rcx        # 67800 <fwp_cur>
    9d6f:	80 7b 55 00          	cmpb   $0x0,0x55(%rbx)
    9d73:	0f 84 97 01 00 00    	je     9f10 <fwp_main_thread+0x410>
    9d79:	48 8b 93 08 01 00 00 	mov    0x108(%rbx),%rdx
    9d80:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    9d87:	48 85 d2             	test   %rdx,%rdx
    9d8a:	0f 84 20 04 00 00    	je     a1b0 <fwp_main_thread+0x6b0>
    9d90:	48 89 82 10 01 00 00 	mov    %rax,0x110(%rdx)
    9d97:	48 85 c0             	test   %rax,%rax
    9d9a:	74 07                	je     9da3 <fwp_main_thread+0x2a3>
    9d9c:	48 89 90 08 01 00 00 	mov    %rdx,0x108(%rax)
    9da3:	66 0f ef db          	pxor   %xmm3,%xmm3
    9da7:	c6 43 55 00          	movb   $0x0,0x55(%rbx)
    9dab:	0f 11 9b 08 01 00 00 	movups %xmm3,0x108(%rbx)
    9db2:	48 89 cb             	mov    %rcx,%rbx
    9db5:	48 83 7d 28 00       	cmpq   $0x0,0x28(%rbp)
    9dba:	0f 85 bf fe ff ff    	jne    9c7f <fwp_main_thread+0x17f>
    9dc0:	48 83 3d d0 f6 05 00 	cmpq   $0x0,0x5f6d0(%rip)        # 69498 <fwp_state_len>
    9dc7:	00 
    9dc8:	44 88 65 52          	mov    %r12b,0x52(%rbp)
    9dcc:	0f 84 10 04 00 00    	je     a1e2 <fwp_main_thread+0x6e2>
    9dd2:	48 39 1d 1f da 05 00 	cmp    %rbx,0x5da1f(%rip)        # 677f8 <fwp_root>
    9dd9:	c7 05 9d 52 01 00 00 	movl   $0x0,0x1529d(%rip)        # 1f080 <fwp_exit_code>
    9de0:	00 00 00 
    9de3:	0f 85 28 0c 00 00    	jne    aa11 <fwp_main_thread+0xf11>
    9de9:	48 85 db             	test   %rbx,%rbx
    9dec:	0f 84 a4 01 00 00    	je     9f96 <fwp_main_thread+0x496>
    9df2:	48 8b 15 cf d9 05 00 	mov    0x5d9cf(%rip),%rdx        # 677c8 <fwp_tasks_active>
    9df9:	c6 43 52 01          	movb   $0x1,0x52(%rbx)
    9dfd:	48 85 d2             	test   %rdx,%rdx
    9e00:	0f 84 90 01 00 00    	je     9f96 <fwp_main_thread+0x496>
    9e06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9e0d:	00 00 00 
    9e10:	80 7a 50 00          	cmpb   $0x0,0x50(%rdx)
    9e14:	75 08                	jne    9e1e <fwp_main_thread+0x31e>
    9e16:	48 89 d7             	mov    %rdx,%rdi
    9e19:	e8 f2 a2 ff ff       	call   4110 <fwp_cancel_tree.part.0>
    9e1e:	48 8b 92 38 01 00 00 	mov    0x138(%rdx),%rdx
    9e25:	48 85 d2             	test   %rdx,%rdx
    9e28:	75 e6                	jne    9e10 <fwp_main_thread+0x310>
    9e2a:	eb 31                	jmp    9e5d <fwp_main_thread+0x35d>
    9e2c:	0f 1f 40 00          	nopl   0x0(%rax)
    9e30:	48 89 98 00 01 00 00 	mov    %rbx,0x100(%rax)
    9e37:	48 89 1d a2 d9 05 00 	mov    %rbx,0x5d9a2(%rip)        # 677e0 <fwp_ready_tail>
    9e3e:	e8 ad dc ff ff       	call   7af0 <fwp_block>
    9e43:	e8 98 da ff ff       	call   78e0 <fwp_free_zombie>
    9e48:	48 83 3d 78 d9 05 00 	cmpq   $0x0,0x5d978(%rip)        # 677c8 <fwp_tasks_active>
    9e4f:	00 
    9e50:	0f 84 40 01 00 00    	je     9f96 <fwp_main_thread+0x496>
    9e56:	48 8b 1d 9b d9 05 00 	mov    0x5d99b(%rip),%rbx        # 677f8 <fwp_root>
    9e5d:	80 7b 54 00          	cmpb   $0x0,0x54(%rbx)
    9e61:	75 db                	jne    9e3e <fwp_main_thread+0x33e>
    9e63:	80 7b 50 00          	cmpb   $0x0,0x50(%rbx)
    9e67:	75 d5                	jne    9e3e <fwp_main_thread+0x33e>
    9e69:	48 8b 05 70 d9 05 00 	mov    0x5d970(%rip),%rax        # 677e0 <fwp_ready_tail>
    9e70:	c6 43 54 01          	movb   $0x1,0x54(%rbx)
    9e74:	48 c7 83 00 01 00 00 	movq   $0x0,0x100(%rbx)
    9e7b:	00 00 00 00 
    9e7f:	48 85 c0             	test   %rax,%rax
    9e82:	75 ac                	jne    9e30 <fwp_main_thread+0x330>
    9e84:	48 89 1d 5d d9 05 00 	mov    %rbx,0x5d95d(%rip)        # 677e8 <fwp_ready_head>
    9e8b:	eb aa                	jmp    9e37 <fwp_main_thread+0x337>
    9e8d:	0f 1f 00             	nopl   (%rax)
    9e90:	e8 0b a7 ff ff       	call   45a0 <fwp_now_ns>
    9e95:	48 3b 45 60          	cmp    0x60(%rbp),%rax
    9e99:	0f 8d 21 03 00 00    	jge    a1c0 <fwp_main_thread+0x6c0>
    9e9f:	90                   	nop
    9ea0:	80 7d 51 00          	cmpb   $0x0,0x51(%rbp)
    9ea4:	0f 85 ea fd ff ff    	jne    9c94 <fwp_main_thread+0x194>
    9eaa:	48 8b 45 60          	mov    0x60(%rbp),%rax
    9eae:	48 8d 55 40          	lea    0x40(%rbp),%rdx
    9eb2:	80 7b 52 00          	cmpb   $0x0,0x52(%rbx)
    9eb6:	0f 85 ea fd ff ff    	jne    9ca6 <fwp_main_thread+0x1a6>
    9ebc:	48 8b 4b 60          	mov    0x60(%rbx),%rcx
    9ec0:	48 85 c9             	test   %rcx,%rcx
    9ec3:	0f 84 dd fd ff ff    	je     9ca6 <fwp_main_thread+0x1a6>
    9ec9:	48 39 c8             	cmp    %rcx,%rax
    9ecc:	48 89 ce             	mov    %rcx,%rsi
    9ecf:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9ed6:	48 8b 55 40          	mov    0x40(%rbp),%rdx
    9eda:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9ee1:	00 00 00 00 
    9ee5:	48 0f 4e f0          	cmovle %rax,%rsi
    9ee9:	48 85 c0             	test   %rax,%rax
    9eec:	48 89 c8             	mov    %rcx,%rax
    9eef:	48 89 93 28 01 00 00 	mov    %rdx,0x128(%rbx)
    9ef6:	48 0f 45 c6          	cmovne %rsi,%rax
    9efa:	48 85 d2             	test   %rdx,%rdx
    9efd:	74 07                	je     9f06 <fwp_main_thread+0x406>
    9eff:	48 89 9a 20 01 00 00 	mov    %rbx,0x120(%rdx)
    9f06:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9f0a:	e9 c9 fd ff ff       	jmp    9cd8 <fwp_main_thread+0x1d8>
    9f0f:	90                   	nop
    9f10:	48 89 cb             	mov    %rcx,%rbx
    9f13:	e9 5c fd ff ff       	jmp    9c74 <fwp_main_thread+0x174>
    9f18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f1f:	00 
    9f20:	48 8b 45 40          	mov    0x40(%rbp),%rax
    9f24:	48 89 93 18 01 00 00 	mov    %rdx,0x118(%rbx)
    9f2b:	48 c7 83 20 01 00 00 	movq   $0x0,0x120(%rbx)
    9f32:	00 00 00 00 
    9f36:	48 89 83 28 01 00 00 	mov    %rax,0x128(%rbx)
    9f3d:	48 85 c0             	test   %rax,%rax
    9f40:	0f 84 6a 09 00 00    	je     a8b0 <fwp_main_thread+0xdb0>
    9f46:	48 89 98 20 01 00 00 	mov    %rbx,0x120(%rax)
    9f4d:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    9f51:	e9 b6 fd ff ff       	jmp    9d0c <fwp_main_thread+0x20c>
    9f56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    9f5d:	00 00 00 
    9f60:	48 89 01             	mov    %rax,(%rcx)
    9f63:	e9 de fd ff ff       	jmp    9d46 <fwp_main_thread+0x246>
    9f68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
    9f6f:	00 
    9f70:	48 83 3d 20 f5 05 00 	cmpq   $0x0,0x5f520(%rip)        # 69498 <fwp_state_len>
    9f77:	00 
    9f78:	0f 84 62 02 00 00    	je     a1e0 <fwp_main_thread+0x6e0>
    9f7e:	48 83 3d 72 d8 05 00 	cmpq   $0x0,0x5d872(%rip)        # 677f8 <fwp_root>
    9f85:	00 
    9f86:	c7 05 f0 50 01 00 00 	movl   $0x0,0x150f0(%rip)        # 1f080 <fwp_exit_code>
    9f8d:	00 00 00 
    9f90:	0f 85 76 0a 00 00    	jne    aa0c <fwp_main_thread+0xf0c>
    9f96:	e8 45 d9 ff ff       	call   78e0 <fwp_free_zombie>
    9f9b:	48 83 3d 45 d8 05 00 	cmpq   $0x0,0x5d845(%rip)        # 677e8 <fwp_ready_head>
    9fa2:	00 
    9fa3:	0f 85 82 97 ff ff    	jne    372b <fwp_main_thread.cold>
    9fa9:	48 83 3d 27 d8 05 00 	cmpq   $0x0,0x5d827(%rip)        # 677d8 <fwp_timers>
    9fb0:	00 
    9fb1:	0f 85 74 97 ff ff    	jne    372b <fwp_main_thread.cold>
    9fb7:	8b 05 17 d2 05 00    	mov    0x5d217(%rip),%eax        # 671d4 <fwp_stack_pool_n>
    9fbd:	85 c0                	test   %eax,%eax
    9fbf:	74 3c                	je     9ffd <fwp_main_thread+0x4fd>
    9fc1:	83 e8 01             	sub    $0x1,%eax
    9fc4:	4c 8d 25 15 d2 05 00 	lea    0x5d215(%rip),%r12        # 671e0 <fwp_stack_pool>
    9fcb:	48 63 d8             	movslq %eax,%rbx
    9fce:	89 c0                	mov    %eax,%eax
    9fd0:	48 89 da             	mov    %rbx,%rdx
    9fd3:	48 29 c2             	sub    %rax,%rdx
    9fd6:	48 8d 6a ff          	lea    -0x1(%rdx),%rbp
    9fda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    9fe0:	49 8b 3c dc          	mov    (%r12,%rbx,8),%rdi
    9fe4:	89 1d ea d1 05 00    	mov    %ebx,0x5d1ea(%rip)        # 671d4 <fwp_stack_pool_n>
    9fea:	be 00 00 00 10       	mov    $0x10000000,%esi
    9fef:	48 83 eb 01          	sub    $0x1,%rbx
    9ff3:	e8 c8 95 ff ff       	call   35c0 <munmap@plt>
    9ff8:	48 39 dd             	cmp    %rbx,%rbp
    9ffb:	75 e3                	jne    9fe0 <fwp_main_thread+0x4e0>
    9ffd:	8b 3d 0d 50 00 00    	mov    0x500d(%rip),%edi        # f010 <fwp_epfd>
    a003:	85 ff                	test   %edi,%edi
    a005:	78 05                	js     a00c <fwp_main_thread+0x50c>
    a007:	e8 b4 94 ff ff       	call   34c0 <close@plt>
    a00c:	4c 8b 25 cd d3 05 00 	mov    0x5d3cd(%rip),%r12        # 673e0 <fwp_nfdws>
    a013:	48 8b 2d ce d3 05 00 	mov    0x5d3ce(%rip),%rbp        # 673e8 <fwp_fdws>
    a01a:	31 db                	xor    %ebx,%ebx
    a01c:	c7 05 ea 4f 00 00 ff 	movl   $0xffffffff,0x4fea(%rip)        # f010 <fwp_epfd>
    a023:	ff ff ff 
    a026:	4d 85 e4             	test   %r12,%r12
    a029:	74 32                	je     a05d <fwp_main_thread+0x55d>
    a02b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
    a030:	48 8b 7c dd 00       	mov    0x0(%rbp,%rbx,8),%rdi
    a035:	48 85 ff             	test   %rdi,%rdi
    a038:	74 1a                	je     a054 <fwp_main_thread+0x554>
    a03a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
    a03e:	0f 85 e7 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a044:	48 83 7f 08 00       	cmpq   $0x0,0x8(%rdi)
    a049:	0f 85 dc 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a04f:	e8 9c b9 ff ff       	call   59f0 <fwp_mem_free>
    a054:	48 83 c3 01          	add    $0x1,%rbx
    a058:	49 39 dc             	cmp    %rbx,%r12
    a05b:	75 d3                	jne    a030 <fwp_main_thread+0x530>
    a05d:	48 89 ef             	mov    %rbp,%rdi
    a060:	e8 8b b9 ff ff       	call   59f0 <fwp_mem_free>
    a065:	48 8b 15 8c d7 05 00 	mov    0x5d78c(%rip),%rdx        # 677f8 <fwp_root>
    a06c:	48 c7 05 71 d3 05 00 	movq   $0x0,0x5d371(%rip)        # 673e8 <fwp_fdws>
    a073:	00 00 00 00 
    a077:	48 c7 05 5e d3 05 00 	movq   $0x0,0x5d35e(%rip)        # 673e0 <fwp_nfdws>
    a07e:	00 00 00 00 
    a082:	48 85 d2             	test   %rdx,%rdx
    a085:	74 4e                	je     a0d5 <fwp_main_thread+0x5d5>
    a087:	48 83 7a 28 00       	cmpq   $0x0,0x28(%rdx)
    a08c:	0f 85 99 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a092:	48 83 ba a8 00 00 00 	cmpq   $0x0,0xa8(%rdx)
    a099:	00 
    a09a:	0f 85 8b 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a0a0:	48 83 3d f0 f3 05 00 	cmpq   $0x0,0x5f3f0(%rip)        # 69498 <fwp_state_len>
    a0a7:	00 
    a0a8:	0f 85 7d 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a0ae:	48 83 3d d2 f3 05 00 	cmpq   $0x0,0x5f3d2(%rip)        # 69488 <fwp_state_owners>
    a0b5:	00 
    a0b6:	0f 85 6f 96 ff ff    	jne    372b <fwp_main_thread.cold>
    a0bc:	b9 79 00 00 00       	mov    $0x79,%ecx
    a0c1:	31 c0                	xor    %eax,%eax
    a0c3:	48 8d 3d 36 d3 05 00 	lea    0x5d336(%rip),%rdi        # 67400 <fwp_root_context>
    a0ca:	f3 48 ab             	rep stos %rax,(%rdi)
    a0cd:	48 89 d7             	mov    %rdx,%rdi
    a0d0:	e8 1b b9 ff ff       	call   59f0 <fwp_mem_free>
    a0d5:	66 0f 6f 05 d3 50 04 	movdqa 0x450d3(%rip),%xmm0        # 4f1b0 <ad_raw_live+0x10>
    a0dc:	00 
    a0dd:	66 0f d4 05 bb 50 04 	paddq  0x450bb(%rip),%xmm0        # 4f1a0 <ad_raw_live>
    a0e4:	00 
    a0e5:	48 c7 05 10 d7 05 00 	movq   $0x0,0x5d710(%rip)        # 67800 <fwp_cur>
    a0ec:	00 00 00 00 
    a0f0:	48 8b 05 49 eb 05 00 	mov    0x5eb49(%rip),%rax        # 68c40 <fwp_heap+0x1420>
    a0f7:	48 c7 05 f6 d6 05 00 	movq   $0x0,0x5d6f6(%rip)        # 677f8 <fwp_root>
    a0fe:	00 00 00 00 
    a102:	c7 05 dc f3 05 00 00 	movl   $0x0,0x5f3dc(%rip)        # 694e8 <iteration_active>
    a109:	00 00 00 
    a10c:	66 0f 6f c8          	movdqa %xmm0,%xmm1
    a110:	66 0f 73 d9 08       	psrldq $0x8,%xmm1
    a115:	66 0f d4 c1          	paddq  %xmm1,%xmm0
    a119:	66 0f d6 05 d7 4f 01 	movq   %xmm0,0x14fd7(%rip)        # 1f0f8 <ad_raw_before_shutdown>
    a120:	00 
    a121:	48 85 c0             	test   %rax,%rax
    a124:	0f 88 46 01 00 00    	js     a270 <fwp_main_thread+0x770>
    a12a:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a12e:	f2 48 0f 2a c8       	cvtsi2sd %rax,%xmm1
    a133:	f2 0f 5c 0d 8d f3 05 	subsd  0x5f38d(%rip),%xmm1        # 694c8 <iteration_start_charge>
    a13a:	00 
    a13b:	48 8b 3d fe 4e 00 00 	mov    0x4efe(%rip),%rdi        # f040 <stderr@GLIBC_2.2.5>
    a142:	48 8d 15 57 19 00 00 	lea    0x1957(%rip),%rdx        # baa0 <_IO_stdin_used+0xaa0>
    a149:	be 02 00 00 00       	mov    $0x2,%esi
    a14e:	f2 0f 10 05 6a f3 05 	movsd  0x5f36a(%rip),%xmm0        # 694c0 <iteration_peak>
    a155:	00 
    a156:	4c 8b 0d 73 f3 05 00 	mov    0x5f373(%rip),%r9        # 694d0 <iteration_retains>
    a15d:	b8 02 00 00 00       	mov    $0x2,%eax
    a162:	4c 8b 05 6f f3 05 00 	mov    0x5f36f(%rip),%r8        # 694d8 <iteration_bytes>
    a169:	48 8b 0d 70 f3 05 00 	mov    0x5f370(%rip),%rcx        # 694e0 <iteration_requests>
    a170:	e8 fb 94 ff ff       	call   3670 <__fprintf_chk@plt>
    a175:	48 8b 3d a4 4e 00 00 	mov    0x4ea4(%rip),%rdi        # f020 <stdout@GLIBC_2.2.5>
    a17c:	e8 1f 94 ff ff       	call   35a0 <fflush@plt>
    a181:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
    a188:	00 
    a189:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
    a190:	00 00 
    a192:	0f 85 57 08 00 00    	jne    a9ef <fwp_main_thread+0xeef>
    a198:	48 81 c4 28 01 00 00 	add    $0x128,%rsp
    a19f:	31 c0                	xor    %eax,%eax
    a1a1:	5b                   	pop    %rbx
    a1a2:	5d                   	pop    %rbp
    a1a3:	41 5c                	pop    %r12
    a1a5:	41 5d                	pop    %r13
    a1a7:	41 5e                	pop    %r14
    a1a9:	41 5f                	pop    %r15
    a1ab:	c3                   	ret
    a1ac:	0f 1f 40 00          	nopl   0x0(%rax)
    a1b0:	48 89 05 21 d6 05 00 	mov    %rax,0x5d621(%rip)        # 677d8 <fwp_timers>
    a1b7:	e9 db fb ff ff       	jmp    9d97 <fwp_main_thread+0x297>
    a1bc:	0f 1f 40 00          	nopl   0x0(%rax)
    a1c0:	80 7d 50 00          	cmpb   $0x0,0x50(%rbp)
    a1c4:	0f 85 d6 fc ff ff    	jne    9ea0 <fwp_main_thread+0x3a0>
    a1ca:	48 89 ef             	mov    %rbp,%rdi
    a1cd:	e8 3e 9f ff ff       	call   4110 <fwp_cancel_tree.part.0>
    a1d2:	e9 c9 fc ff ff       	jmp    9ea0 <fwp_main_thread+0x3a0>
    a1d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a1de:	00 00 
    a1e0:	31 db                	xor    %ebx,%ebx
    a1e2:	48 83 3d 9e f2 05 00 	cmpq   $0x0,0x5f29e(%rip)        # 69488 <fwp_state_owners>
    a1e9:	00 
    a1ea:	0f 85 e2 fb ff ff    	jne    9dd2 <fwp_main_thread+0x2d2>
    a1f0:	48 8b 3d a9 f2 05 00 	mov    0x5f2a9(%rip),%rdi        # 694a0 <fwp_state>
    a1f7:	e8 f4 b7 ff ff       	call   59f0 <fwp_mem_free>
    a1fc:	48 c7 05 99 f2 05 00 	movq   $0x0,0x5f299(%rip)        # 694a0 <fwp_state>
    a203:	00 00 00 00 
    a207:	48 c7 05 7e f2 05 00 	movq   $0x0,0x5f27e(%rip)        # 69490 <fwp_state_cap>
    a20e:	00 00 00 00 
    a212:	48 85 db             	test   %rbx,%rbx
    a215:	0f 84 6f 07 00 00    	je     a98a <fwp_main_thread+0xe8a>
    a21b:	48 3b 1d d6 d5 05 00 	cmp    0x5d5d6(%rip),%rbx        # 677f8 <fwp_root>
    a222:	48 c7 83 a8 00 00 00 	movq   $0x0,0xa8(%rbx)
    a229:	00 00 00 00 
    a22d:	48 c7 83 b8 00 00 00 	movq   $0x0,0xb8(%rbx)
    a234:	00 00 00 00 
    a238:	c7 05 3e 4e 01 00 00 	movl   $0x0,0x14e3e(%rip)        # 1f080 <fwp_exit_code>
    a23f:	00 00 00 
    a242:	0f 84 aa fb ff ff    	je     9df2 <fwp_main_thread+0x2f2>
    a248:	e9 de 94 ff ff       	jmp    372b <fwp_main_thread.cold>
    a24d:	0f 1f 00             	nopl   (%rax)
    a250:	48 89 c2             	mov    %rax,%rdx
    a253:	83 e0 01             	and    $0x1,%eax
    a256:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a25a:	48 d1 ea             	shr    $1,%rdx
    a25d:	48 09 c2             	or     %rax,%rdx
    a260:	f2 48 0f 2a c2       	cvtsi2sd %rdx,%xmm0
    a265:	f2 0f 58 c0          	addsd  %xmm0,%xmm0
    a269:	e9 b6 f9 ff ff       	jmp    9c24 <fwp_main_thread+0x124>
    a26e:	66 90                	xchg   %ax,%ax
    a270:	48 89 c2             	mov    %rax,%rdx
    a273:	83 e0 01             	and    $0x1,%eax
    a276:	66 0f ef c9          	pxor   %xmm1,%xmm1
    a27a:	48 d1 ea             	shr    $1,%rdx
    a27d:	48 09 c2             	or     %rax,%rdx
    a280:	f2 48 0f 2a ca       	cvtsi2sd %rdx,%xmm1
    a285:	f2 0f 58 c9          	addsd  %xmm1,%xmm1
    a289:	e9 a5 fe ff ff       	jmp    a133 <fwp_main_thread+0x633>
    a28e:	66 90                	xchg   %ax,%ax
    a290:	48 8d 3d 09 aa ff ff 	lea    -0x55f7(%rip),%rdi        # 4ca0 <fwp_heap_report>
    a297:	e8 94 09 00 00       	call   ac30 <atexit>
    a29c:	e9 a3 f8 ff ff       	jmp    9b44 <fwp_main_thread+0x44>
    a2a1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a2a8:	e8 03 ab ff ff       	call   4db0 <fwp_heap_init>
    a2ad:	e9 84 f8 ff ff       	jmp    9b36 <fwp_main_thread+0x36>
    a2b2:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a2b8:	48 8d 05 91 de ff ff 	lea    -0x216f(%rip),%rax        # 8150 <fwp_drop1>
    a2bf:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a2c3:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
    a2ca:	00 00 
    a2cc:	41 bc ff 7f 00 00    	mov    $0x7fff,%r12d
    a2d2:	66 48 0f 6e e0       	movq   %rax,%xmm4
    a2d7:	48 8b 05 da f1 05 00 	mov    0x5f1da(%rip),%rax        # 694b8 <fwp_cleanups>
    a2de:	4c 8d 3d 3b d5 05 00 	lea    0x5d53b(%rip),%r15        # 67820 <fwp_heap>
    a2e5:	48 89 2d cc f1 05 00 	mov    %rbp,0x5f1cc(%rip)        # 694b8 <fwp_cleanups>
    a2ec:	66 0f 6c c4          	punpcklqdq %xmm4,%xmm0
    a2f0:	31 ed                	xor    %ebp,%ebp
    a2f2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    a2f7:	48 8d 05 b2 98 ff ff 	lea    -0x674e(%rip),%rax        # 3bb0 <fwp_range_release>
    a2fe:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    a303:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    a308:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
    a30d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    a312:	eb 3d                	jmp    a351 <fwp_main_thread+0x851>
    a314:	0f 1f 40 00          	nopl   0x0(%rax)
    a318:	80 f9 01             	cmp    $0x1,%cl
    a31b:	75 29                	jne    a346 <fwp_main_thread+0x846>
    a31d:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a320:	0f b7 c0             	movzwl %ax,%eax
    a323:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a326:	48 0f af c1          	imul   %rcx,%rax
    a32a:	48 c1 e8 20          	shr    $0x20,%rax
    a32e:	48 39 d0             	cmp    %rdx,%rax
    a331:	73 13                	jae    a346 <fwp_main_thread+0x846>
    a333:	49 01 c5             	add    %rax,%r13
    a336:	41 80 7d 00 ff       	cmpb   $0xff,0x0(%r13)
    a33b:	0f 84 af 05 00 00    	je     a8f0 <fwp_main_thread+0xdf0>
    a341:	41 c6 45 00 01       	movb   $0x1,0x0(%r13)
    a346:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a34b:	49 83 ec 01          	sub    $0x1,%r12
    a34f:	72 7f                	jb     a3d0 <fwp_main_thread+0x8d0>
    a351:	48 89 de             	mov    %rbx,%rsi
    a354:	bf 01 00 00 00       	mov    $0x1,%edi
    a359:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
    a360:	00 
    a361:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
    a366:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
    a36d:	00 
    a36e:	e8 6d bd ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a373:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a37a:	48 89 c5             	mov    %rax,%rbp
    a37d:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a384:	48 c1 e2 10          	shl    $0x10,%rdx
    a388:	48 39 d0             	cmp    %rdx,%rax
    a38b:	73 b9                	jae    a346 <fwp_main_thread+0x846>
    a38d:	48 89 c2             	mov    %rax,%rdx
    a390:	48 c1 ea 10          	shr    $0x10,%rdx
    a394:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a398:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a39f:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a3a3:	4c 8b 6a 20          	mov    0x20(%rdx),%r13
    a3a7:	4d 85 ed             	test   %r13,%r13
    a3aa:	74 9a                	je     a346 <fwp_main_thread+0x846>
    a3ac:	0f b6 0a             	movzbl (%rdx),%ecx
    a3af:	80 f9 02             	cmp    $0x2,%cl
    a3b2:	0f 85 60 ff ff ff    	jne    a318 <fwp_main_thread+0x818>
    a3b8:	66 85 c0             	test   %ax,%ax
    a3bb:	0f 84 75 ff ff ff    	je     a336 <fwp_main_thread+0x836>
    a3c1:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
    a3c6:	49 83 ec 01          	sub    $0x1,%r12
    a3ca:	73 85                	jae    a351 <fwp_main_thread+0x851>
    a3cc:	0f 1f 40 00          	nopl   0x0(%rax)
    a3d0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
    a3d5:	66 0f 6f 05 33 19 00 	movdqa 0x1933(%rip),%xmm0        # bd10 <msg.4+0xa0>
    a3dc:	00 
    a3dd:	48 89 de             	mov    %rbx,%rsi
    a3e0:	bf 01 00 00 00       	mov    $0x1,%edi
    a3e5:	48 89 05 cc f0 05 00 	mov    %rax,0x5f0cc(%rip)        # 694b8 <fwp_cleanups>
    a3ec:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
    a3f3:	00 
    a3f4:	e8 e7 bc ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a3f9:	48 8b 15 f8 e7 05 00 	mov    0x5e7f8(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a400:	49 89 c4             	mov    %rax,%r12
    a403:	48 2b 05 c6 e7 05 00 	sub    0x5e7c6(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    a40a:	48 c1 e2 10          	shl    $0x10,%rdx
    a40e:	48 39 d0             	cmp    %rdx,%rax
    a411:	73 55                	jae    a468 <fwp_main_thread+0x968>
    a413:	48 89 c2             	mov    %rax,%rdx
    a416:	48 c1 ea 10          	shr    $0x10,%rdx
    a41a:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a41e:	48 8b 15 f3 e7 05 00 	mov    0x5e7f3(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    a425:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a429:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a42d:	48 85 db             	test   %rbx,%rbx
    a430:	74 36                	je     a468 <fwp_main_thread+0x968>
    a432:	0f b6 0a             	movzbl (%rdx),%ecx
    a435:	80 f9 02             	cmp    $0x2,%cl
    a438:	0f 84 a2 04 00 00    	je     a8e0 <fwp_main_thread+0xde0>
    a43e:	80 f9 01             	cmp    $0x1,%cl
    a441:	75 25                	jne    a468 <fwp_main_thread+0x968>
    a443:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a446:	0f b7 c0             	movzwl %ax,%eax
    a449:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a44c:	48 0f af c1          	imul   %rcx,%rax
    a450:	48 c1 e8 20          	shr    $0x20,%rax
    a454:	48 39 d0             	cmp    %rdx,%rax
    a457:	73 0f                	jae    a468 <fwp_main_thread+0x968>
    a459:	48 01 c3             	add    %rax,%rbx
    a45c:	80 3b ff             	cmpb   $0xff,(%rbx)
    a45f:	0f 84 4b 05 00 00    	je     a9b0 <fwp_main_thread+0xeb0>
    a465:	c6 03 01             	movb   $0x1,(%rbx)
    a468:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
    a46d:	bf 01 00 00 00       	mov    $0x1,%edi
    a472:	4c 89 64 24 78       	mov    %r12,0x78(%rsp)
    a477:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
    a47e:	00 f0 3f 
    a481:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
    a486:	e8 55 bc ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a48b:	48 8b 15 66 e7 05 00 	mov    0x5e766(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a492:	49 89 c4             	mov    %rax,%r12
    a495:	48 2b 05 34 e7 05 00 	sub    0x5e734(%rip),%rax        # 68bd0 <fwp_heap+0x13b0>
    a49c:	48 c1 e2 10          	shl    $0x10,%rdx
    a4a0:	48 39 d0             	cmp    %rdx,%rax
    a4a3:	73 55                	jae    a4fa <fwp_main_thread+0x9fa>
    a4a5:	48 89 c2             	mov    %rax,%rdx
    a4a8:	48 c1 ea 10          	shr    $0x10,%rdx
    a4ac:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a4b0:	48 8b 15 61 e7 05 00 	mov    0x5e761(%rip),%rdx        # 68c18 <fwp_heap+0x13f8>
    a4b7:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a4bb:	48 8b 5a 20          	mov    0x20(%rdx),%rbx
    a4bf:	48 85 db             	test   %rbx,%rbx
    a4c2:	74 36                	je     a4fa <fwp_main_thread+0x9fa>
    a4c4:	0f b6 0a             	movzbl (%rdx),%ecx
    a4c7:	80 f9 02             	cmp    $0x2,%cl
    a4ca:	0f 84 00 04 00 00    	je     a8d0 <fwp_main_thread+0xdd0>
    a4d0:	80 f9 01             	cmp    $0x1,%cl
    a4d3:	75 25                	jne    a4fa <fwp_main_thread+0x9fa>
    a4d5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a4d8:	0f b7 c0             	movzwl %ax,%eax
    a4db:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a4de:	48 0f af c1          	imul   %rcx,%rax
    a4e2:	48 c1 e8 20          	shr    $0x20,%rax
    a4e6:	48 39 d0             	cmp    %rdx,%rax
    a4e9:	73 0f                	jae    a4fa <fwp_main_thread+0x9fa>
    a4eb:	48 01 c3             	add    %rax,%rbx
    a4ee:	80 3b ff             	cmpb   $0xff,(%rbx)
    a4f1:	0f 84 c6 04 00 00    	je     a9bd <fwp_main_thread+0xebd>
    a4f7:	c6 03 01             	movb   $0x1,(%rbx)
    a4fa:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
    a4ff:	bf 01 00 00 00       	mov    $0x1,%edi
    a504:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
    a509:	48 b8 33 33 33 33 33 	movabs $0xbff3333333333333,%rax
    a510:	33 f3 bf 
    a513:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
    a518:	e8 c3 bb ff ff       	call   60e0 <fwp_data.part.0.constprop.0>
    a51d:	48 8b 15 d4 e6 05 00 	mov    0x5e6d4(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a524:	48 8b 0d a5 e6 05 00 	mov    0x5e6a5(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a52b:	49 89 c4             	mov    %rax,%r12
    a52e:	48 89 d6             	mov    %rdx,%rsi
    a531:	48 29 c8             	sub    %rcx,%rax
    a534:	48 c1 e6 10          	shl    $0x10,%rsi
    a538:	48 39 f0             	cmp    %rsi,%rax
    a53b:	73 65                	jae    a5a2 <fwp_main_thread+0xaa2>
    a53d:	48 89 c6             	mov    %rax,%rsi
    a540:	48 c1 ee 10          	shr    $0x10,%rsi
    a544:	48 8d 3c b6          	lea    (%rsi,%rsi,4),%rdi
    a548:	48 8b 35 c9 e6 05 00 	mov    0x5e6c9(%rip),%rsi        # 68c18 <fwp_heap+0x13f8>
    a54f:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
    a553:	48 8b 5e 20          	mov    0x20(%rsi),%rbx
    a557:	48 85 db             	test   %rbx,%rbx
    a55a:	74 46                	je     a5a2 <fwp_main_thread+0xaa2>
    a55c:	0f b6 3e             	movzbl (%rsi),%edi
    a55f:	40 80 ff 02          	cmp    $0x2,%dil
    a563:	0f 84 57 03 00 00    	je     a8c0 <fwp_main_thread+0xdc0>
    a569:	40 80 ff 01          	cmp    $0x1,%dil
    a56d:	75 33                	jne    a5a2 <fwp_main_thread+0xaa2>
    a56f:	8b 7e 18             	mov    0x18(%rsi),%edi
    a572:	0f b7 c0             	movzwl %ax,%eax
    a575:	8b 76 1c             	mov    0x1c(%rsi),%esi
    a578:	48 0f af c7          	imul   %rdi,%rax
    a57c:	48 c1 e8 20          	shr    $0x20,%rax
    a580:	48 39 f0             	cmp    %rsi,%rax
    a583:	73 1d                	jae    a5a2 <fwp_main_thread+0xaa2>
    a585:	48 01 c3             	add    %rax,%rbx
    a588:	80 3b ff             	cmpb   $0xff,(%rbx)
    a58b:	0f 84 39 04 00 00    	je     a9ca <fwp_main_thread+0xeca>
    a591:	c6 03 01             	movb   $0x1,(%rbx)
    a594:	48 8b 0d 35 e6 05 00 	mov    0x5e635(%rip),%rcx        # 68bd0 <fwp_heap+0x13b0>
    a59b:	48 8b 15 56 e6 05 00 	mov    0x5e656(%rip),%rdx        # 68bf8 <fwp_heap+0x13d8>
    a5a2:	49 89 ed             	mov    %rbp,%r13
    a5a5:	e9 13 02 00 00       	jmp    a7bd <fwp_main_thread+0xcbd>
    a5aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a5b0:	80 f9 01             	cmp    $0x1,%cl
    a5b3:	75 3f                	jne    a5f4 <fwp_main_thread+0xaf4>
    a5b5:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a5b8:	0f b7 c0             	movzwl %ax,%eax
    a5bb:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a5be:	48 0f af c1          	imul   %rcx,%rax
    a5c2:	48 c1 e8 20          	shr    $0x20,%rax
    a5c6:	48 39 d0             	cmp    %rdx,%rax
    a5c9:	73 29                	jae    a5f4 <fwp_main_thread+0xaf4>
    a5cb:	48 01 c7             	add    %rax,%rdi
    a5ce:	0f b6 07             	movzbl (%rdi),%eax
    a5d1:	84 c0                	test   %al,%al
    a5d3:	74 1f                	je     a5f4 <fwp_main_thread+0xaf4>
    a5d5:	8b 15 0d ef 05 00    	mov    0x5ef0d(%rip),%edx        # 694e8 <iteration_active>
    a5db:	85 d2                	test   %edx,%edx
    a5dd:	74 08                	je     a5e7 <fwp_main_thread+0xae7>
    a5df:	48 83 05 e9 ee 05 00 	addq   $0x1,0x5eee9(%rip)        # 694d0 <iteration_retains>
    a5e6:	01 
    a5e7:	3c fd                	cmp    $0xfd,%al
    a5e9:	0f 87 91 03 00 00    	ja     a980 <fwp_main_thread+0xe80>
    a5ef:	83 c0 01             	add    $0x1,%eax
    a5f2:	88 07                	mov    %al,(%rdi)
    a5f4:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
    a5f9:	66 0f ef c0          	pxor   %xmm0,%xmm0
    a5fd:	b9 01 00 00 00       	mov    $0x1,%ecx
    a602:	4c 89 e6             	mov    %r12,%rsi
    a605:	48 8d 15 94 45 00 00 	lea    0x4594(%rip),%rdx        # eba0 <d0>
    a60c:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
    a611:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
    a618:	00 00 
    a61a:	e8 a1 e4 ff ff       	call   8ac0 <fwp_write>
    a61f:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
    a624:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
    a629:	48 8d 05 3c 0a 00 00 	lea    0xa3c(%rip),%rax        # b06c <_IO_stdin_used+0x6c>
    a630:	48 85 c9             	test   %rcx,%rcx
    a633:	48 0f 44 c8          	cmove  %rax,%rcx
    a637:	49 83 fe f6          	cmp    $0xfffffffffffffff6,%r14
    a63b:	0f 87 a2 03 00 00    	ja     a9e3 <fwp_main_thread+0xee3>
    a641:	49 8d 7e 09          	lea    0x9(%r14),%rdi
    a645:	be 01 00 00 00       	mov    $0x1,%esi
    a64a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
    a64f:	e8 9c b8 ff ff       	call   5ef0 <fwp_heap_alloc>
    a654:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a659:	4c 89 f2             	mov    %r14,%rdx
    a65c:	4c 89 30             	mov    %r14,(%rax)
    a65f:	48 89 c3             	mov    %rax,%rbx
    a662:	48 8d 78 08          	lea    0x8(%rax),%rdi
    a666:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
    a66b:	e8 10 8f ff ff       	call   3580 <memcpy@plt>
    a670:	42 c6 44 33 08 00    	movb   $0x0,0x8(%rbx,%r14,1)
    a676:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
    a67b:	e8 30 8d ff ff       	call   33b0 <free@plt>
    a680:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a687:	48 89 d8             	mov    %rbx,%rax
    a68a:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a691:	48 c1 e2 10          	shl    $0x10,%rdx
    a695:	48 39 d0             	cmp    %rdx,%rax
    a698:	73 55                	jae    a6ef <fwp_main_thread+0xbef>
    a69a:	48 89 c2             	mov    %rax,%rdx
    a69d:	48 c1 ea 10          	shr    $0x10,%rdx
    a6a1:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a6a5:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a6ac:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a6b0:	48 8b 72 20          	mov    0x20(%rdx),%rsi
    a6b4:	48 85 f6             	test   %rsi,%rsi
    a6b7:	74 36                	je     a6ef <fwp_main_thread+0xbef>
    a6b9:	0f b6 0a             	movzbl (%rdx),%ecx
    a6bc:	80 f9 02             	cmp    $0x2,%cl
    a6bf:	0f 84 4b 01 00 00    	je     a810 <fwp_main_thread+0xd10>
    a6c5:	80 f9 01             	cmp    $0x1,%cl
    a6c8:	75 25                	jne    a6ef <fwp_main_thread+0xbef>
    a6ca:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a6cd:	0f b7 c0             	movzwl %ax,%eax
    a6d0:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a6d3:	48 0f af c1          	imul   %rcx,%rax
    a6d7:	48 c1 e8 20          	shr    $0x20,%rax
    a6db:	48 39 d0             	cmp    %rdx,%rax
    a6de:	73 0f                	jae    a6ef <fwp_main_thread+0xbef>
    a6e0:	48 01 c6             	add    %rax,%rsi
    a6e3:	80 3e ff             	cmpb   $0xff,(%rsi)
    a6e6:	0f 84 44 01 00 00    	je     a830 <fwp_main_thread+0xd30>
    a6ec:	c6 06 01             	movb   $0x1,(%rsi)
    a6ef:	4c 89 e7             	mov    %r12,%rdi
    a6f2:	e8 69 d8 ff ff       	call   7f60 <fwp_drop0>
    a6f7:	48 8b 13             	mov    (%rbx),%rdx
    a6fa:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    a6ff:	be 01 00 00 00       	mov    $0x1,%esi
    a704:	48 8b 0d 75 ed 05 00 	mov    0x5ed75(%rip),%rcx        # 69480 <fwp_prog_out>
    a70b:	e8 50 8f ff ff       	call   3660 <fwrite@plt>
    a710:	48 8b 35 69 ed 05 00 	mov    0x5ed69(%rip),%rsi        # 69480 <fwp_prog_out>
    a717:	bf 0a 00 00 00       	mov    $0xa,%edi
    a71c:	e8 af 8d ff ff       	call   34d0 <fputc@plt>
    a721:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a728:	48 89 d8             	mov    %rbx,%rax
    a72b:	49 2b 87 b0 13 00 00 	sub    0x13b0(%r15),%rax
    a732:	48 c1 e2 10          	shl    $0x10,%rdx
    a736:	48 39 d0             	cmp    %rdx,%rax
    a739:	73 67                	jae    a7a2 <fwp_main_thread+0xca2>
    a73b:	48 89 c2             	mov    %rax,%rdx
    a73e:	48 c1 ea 10          	shr    $0x10,%rdx
    a742:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a746:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a74d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a751:	4c 8b 72 20          	mov    0x20(%rdx),%r14
    a755:	4d 85 f6             	test   %r14,%r14
    a758:	74 48                	je     a7a2 <fwp_main_thread+0xca2>
    a75a:	0f b6 0a             	movzbl (%rdx),%ecx
    a75d:	80 f9 02             	cmp    $0x2,%cl
    a760:	0f 84 ea 00 00 00    	je     a850 <fwp_main_thread+0xd50>
    a766:	80 f9 01             	cmp    $0x1,%cl
    a769:	75 37                	jne    a7a2 <fwp_main_thread+0xca2>
    a76b:	8b 4a 18             	mov    0x18(%rdx),%ecx
    a76e:	0f b7 c0             	movzwl %ax,%eax
    a771:	8b 52 1c             	mov    0x1c(%rdx),%edx
    a774:	48 0f af c1          	imul   %rcx,%rax
    a778:	48 c1 e8 20          	shr    $0x20,%rax
    a77c:	48 39 d0             	cmp    %rdx,%rax
    a77f:	73 21                	jae    a7a2 <fwp_main_thread+0xca2>
    a781:	49 01 c6             	add    %rax,%r14
    a784:	41 0f b6 06          	movzbl (%r14),%eax
    a788:	84 c0                	test   %al,%al
    a78a:	74 16                	je     a7a2 <fwp_main_thread+0xca2>
    a78c:	3c 01                	cmp    $0x1,%al
    a78e:	0f 84 0c 01 00 00    	je     a8a0 <fwp_main_thread+0xda0>
    a794:	3c ff                	cmp    $0xff,%al
    a796:	0f 84 64 01 00 00    	je     a900 <fwp_main_thread+0xe00>
    a79c:	83 e8 01             	sub    $0x1,%eax
    a79f:	41 88 06             	mov    %al,(%r14)
    a7a2:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a7a6:	4d 85 ed             	test   %r13,%r13
    a7a9:	0f 84 c1 00 00 00    	je     a870 <fwp_main_thread+0xd70>
    a7af:	49 8b 8f b0 13 00 00 	mov    0x13b0(%r15),%rcx
    a7b6:	49 8b 97 d8 13 00 00 	mov    0x13d8(%r15),%rdx
    a7bd:	4c 89 e0             	mov    %r12,%rax
    a7c0:	48 c1 e2 10          	shl    $0x10,%rdx
    a7c4:	48 29 c8             	sub    %rcx,%rax
    a7c7:	48 39 d0             	cmp    %rdx,%rax
    a7ca:	0f 83 24 fe ff ff    	jae    a5f4 <fwp_main_thread+0xaf4>
    a7d0:	48 89 c2             	mov    %rax,%rdx
    a7d3:	48 c1 ea 10          	shr    $0x10,%rdx
    a7d7:	48 8d 0c 92          	lea    (%rdx,%rdx,4),%rcx
    a7db:	49 8b 97 f8 13 00 00 	mov    0x13f8(%r15),%rdx
    a7e2:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
    a7e6:	48 8b 7a 20          	mov    0x20(%rdx),%rdi
    a7ea:	48 85 ff             	test   %rdi,%rdi
    a7ed:	0f 84 01 fe ff ff    	je     a5f4 <fwp_main_thread+0xaf4>
    a7f3:	0f b6 0a             	movzbl (%rdx),%ecx
    a7f6:	80 f9 02             	cmp    $0x2,%cl
    a7f9:	0f 85 b1 fd ff ff    	jne    a5b0 <fwp_main_thread+0xab0>
    a7ff:	66 85 c0             	test   %ax,%ax
    a802:	0f 85 ec fd ff ff    	jne    a5f4 <fwp_main_thread+0xaf4>
    a808:	e9 c1 fd ff ff       	jmp    a5ce <fwp_main_thread+0xace>
    a80d:	0f 1f 00             	nopl   (%rax)
    a810:	66 85 c0             	test   %ax,%ax
    a813:	0f 85 d6 fe ff ff    	jne    a6ef <fwp_main_thread+0xbef>
    a819:	80 3e ff             	cmpb   $0xff,(%rsi)
    a81c:	0f 85 ca fe ff ff    	jne    a6ec <fwp_main_thread+0xbec>
    a822:	0f 1f 00             	nopl   (%rax)
    a825:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a82c:	00 00 00 00 
    a830:	48 89 f7             	mov    %rsi,%rdi
    a833:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
    a838:	e8 73 af ff ff       	call   57b0 <fwp_rc_forget_slot>
    a83d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    a842:	e9 a5 fe ff ff       	jmp    a6ec <fwp_main_thread+0xbec>
    a847:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a84e:	00 00 
    a850:	66 85 c0             	test   %ax,%ax
    a853:	0f 84 2b ff ff ff    	je     a784 <fwp_main_thread+0xc84>
    a859:	4d 8b 6d 10          	mov    0x10(%r13),%r13
    a85d:	4d 85 ed             	test   %r13,%r13
    a860:	0f 85 49 ff ff ff    	jne    a7af <fwp_main_thread+0xcaf>
    a866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    a86d:	00 00 00 
    a870:	4c 89 e7             	mov    %r12,%rdi
    a873:	e8 e8 d6 ff ff       	call   7f60 <fwp_drop0>
    a878:	48 89 ef             	mov    %rbp,%rdi
    a87b:	e8 e0 d6 ff ff       	call   7f60 <fwp_drop0>
    a880:	48 c7 05 d5 47 00 00 	movq   $0x0,0x47d5(%rip)        # f060 <v.2>
    a887:	00 00 00 00 
    a88b:	c7 05 d3 47 00 00 01 	movl   $0x1,0x47d3(%rip)        # f068 <st.3>
    a892:	00 00 00 
    a895:	e9 be f3 ff ff       	jmp    9c58 <fwp_main_thread+0x158>
    a89a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    a8a0:	48 89 df             	mov    %rbx,%rdi
    a8a3:	e8 48 b1 ff ff       	call   59f0 <fwp_mem_free>
    a8a8:	e9 f5 fe ff ff       	jmp    a7a2 <fwp_main_thread+0xca2>
    a8ad:	0f 1f 00             	nopl   (%rax)
    a8b0:	48 89 5d 40          	mov    %rbx,0x40(%rbp)
    a8b4:	e9 53 f4 ff ff       	jmp    9d0c <fwp_main_thread+0x20c>
    a8b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
    a8c0:	66 85 c0             	test   %ax,%ax
    a8c3:	0f 85 d9 fc ff ff    	jne    a5a2 <fwp_main_thread+0xaa2>
    a8c9:	e9 ba fc ff ff       	jmp    a588 <fwp_main_thread+0xa88>
    a8ce:	66 90                	xchg   %ax,%ax
    a8d0:	66 85 c0             	test   %ax,%ax
    a8d3:	0f 85 21 fc ff ff    	jne    a4fa <fwp_main_thread+0x9fa>
    a8d9:	e9 10 fc ff ff       	jmp    a4ee <fwp_main_thread+0x9ee>
    a8de:	66 90                	xchg   %ax,%ax
    a8e0:	66 85 c0             	test   %ax,%ax
    a8e3:	0f 85 7f fb ff ff    	jne    a468 <fwp_main_thread+0x968>
    a8e9:	e9 6e fb ff ff       	jmp    a45c <fwp_main_thread+0x95c>
    a8ee:	66 90                	xchg   %ax,%ax
    a8f0:	4c 89 ef             	mov    %r13,%rdi
    a8f3:	e8 b8 ae ff ff       	call   57b0 <fwp_rc_forget_slot>
    a8f8:	e9 44 fa ff ff       	jmp    a341 <fwp_main_thread+0x841>
    a8fd:	0f 1f 00             	nopl   (%rax)
    a900:	4c 89 f0             	mov    %r14,%rax
    a903:	48 c1 e8 11          	shr    $0x11,%rax
    a907:	4c 31 f0             	xor    %r14,%rax
    a90a:	48 89 c2             	mov    %rax,%rdx
    a90d:	48 c1 ea 09          	shr    $0x9,%rdx
    a911:	48 31 d0             	xor    %rdx,%rax
    a914:	0f b6 d0             	movzbl %al,%edx
    a917:	49 8b 84 d7 48 14 00 	mov    0x1448(%r15,%rdx,8),%rax
    a91e:	00 
    a91f:	48 85 c0             	test   %rax,%rax
    a922:	75 29                	jne    a94d <fwp_main_thread+0xe4d>
    a924:	e9 d7 00 00 00       	jmp    aa00 <fwp_main_thread+0xf00>
    a929:	90                   	nop
    a92a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a931:	00 00 00 00 
    a935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
    a93c:	00 00 00 00 
    a940:	48 8b 42 10          	mov    0x10(%rdx),%rax
    a944:	48 85 c0             	test   %rax,%rax
    a947:	0f 84 b3 00 00 00    	je     aa00 <fwp_main_thread+0xf00>
    a94d:	48 89 c2             	mov    %rax,%rdx
    a950:	4c 3b 30             	cmp    (%rax),%r14
    a953:	75 eb                	jne    a940 <fwp_main_thread+0xe40>
    a955:	48 8b 70 08          	mov    0x8(%rax),%rsi
    a959:	48 8d 56 ff          	lea    -0x1(%rsi),%rdx
    a95d:	48 89 50 08          	mov    %rdx,0x8(%rax)
    a961:	48 81 fa fe 00 00 00 	cmp    $0xfe,%rdx
    a968:	0f 85 34 fe ff ff    	jne    a7a2 <fwp_main_thread+0xca2>
    a96e:	4c 89 f7             	mov    %r14,%rdi
    a971:	e8 3a ae ff ff       	call   57b0 <fwp_rc_forget_slot>
    a976:	41 c6 06 fe          	movb   $0xfe,(%r14)
    a97a:	e9 23 fe ff ff       	jmp    a7a2 <fwp_main_thread+0xca2>
    a97f:	90                   	nop
    a980:	e8 0b ad ff ff       	call   5690 <fwp_rc_wide_dup>
    a985:	e9 6a fc ff ff       	jmp    a5f4 <fwp_main_thread+0xaf4>
    a98a:	48 83 3d 66 ce 05 00 	cmpq   $0x0,0x5ce66(%rip)        # 677f8 <fwp_root>
    a991:	00 
    a992:	c7 05 e4 46 01 00 00 	movl   $0x0,0x146e4(%rip)        # 1f080 <fwp_exit_code>
    a999:	00 00 00 
    a99c:	0f 84 f4 f5 ff ff    	je     9f96 <fwp_main_thread+0x496>
    a9a2:	e9 84 8d ff ff       	jmp    372b <fwp_main_thread.cold>
    a9a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
    a9ae:	00 00 
    a9b0:	48 89 df             	mov    %rbx,%rdi
    a9b3:	e8 f8 ad ff ff       	call   57b0 <fwp_rc_forget_slot>
    a9b8:	e9 a8 fa ff ff       	jmp    a465 <fwp_main_thread+0x965>
    a9bd:	48 89 df             	mov    %rbx,%rdi
    a9c0:	e8 eb ad ff ff       	call   57b0 <fwp_rc_forget_slot>
    a9c5:	e9 2d fb ff ff       	jmp    a4f7 <fwp_main_thread+0x9f7>
    a9ca:	48 89 df             	mov    %rbx,%rdi
    a9cd:	e8 de ad ff ff       	call   57b0 <fwp_rc_forget_slot>
    a9d2:	e9 ba fb ff ff       	jmp    a591 <fwp_main_thread+0xa91>
    a9d7:	48 8d 3d 9a 10 00 00 	lea    0x109a(%rip),%rdi        # ba78 <_IO_stdin_used+0xa78>
    a9de:	e8 4d 9a ff ff       	call   4430 <fwp_trap>
    a9e3:	48 8d 3d ad 08 00 00 	lea    0x8ad(%rip),%rdi        # b297 <_IO_stdin_used+0x297>
    a9ea:	e8 41 9a ff ff       	call   4430 <fwp_trap>
    a9ef:	e8 5c 8a ff ff       	call   3450 <__stack_chk_fail@plt>
    a9f4:	48 8d 3d 81 08 00 00 	lea    0x881(%rip),%rdi        # b27c <_IO_stdin_used+0x27c>
    a9fb:	e8 e0 95 ff ff       	call   3fe0 <ad_raw_fail>
    aa00:	48 8d 3d a1 0f 00 00 	lea    0xfa1(%rip),%rdi        # b9a8 <_IO_stdin_used+0x9a8>
    aa07:	e8 24 9a ff ff       	call   4430 <fwp_trap>
    aa0c:	e9 1a 8d ff ff       	jmp    372b <fwp_main_thread.cold>
    aa11:	e9 15 8d ff ff       	jmp    372b <fwp_main_thread.cold>
    aa16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aa1d:	00 00 00 

000000000000aa20 <__divmodti4>:
    aa20:	f3 0f 1e fa          	endbr64
    aa24:	55                   	push   %rbp
    aa25:	49 89 f1             	mov    %rsi,%r9
    aa28:	49 89 d2             	mov    %rdx,%r10
    aa2b:	48 89 fe             	mov    %rdi,%rsi
    aa2e:	49 89 cb             	mov    %rcx,%r11
    aa31:	48 89 e5             	mov    %rsp,%rbp
    aa34:	41 57                	push   %r15
    aa36:	41 56                	push   %r14
    aa38:	41 55                	push   %r13
    aa3a:	41 54                	push   %r12
    aa3c:	53                   	push   %rbx
    aa3d:	4c 89 c3             	mov    %r8,%rbx
    aa40:	45 31 c0             	xor    %r8d,%r8d
    aa43:	4d 85 c9             	test   %r9,%r9
    aa46:	79 12                	jns    aa5a <__divmodti4+0x3a>
    aa48:	31 ff                	xor    %edi,%edi
    aa4a:	48 f7 de             	neg    %rsi
    aa4d:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
    aa54:	4c 19 cf             	sbb    %r9,%rdi
    aa57:	49 89 f9             	mov    %rdi,%r9
    aa5a:	4c 89 d8             	mov    %r11,%rax
    aa5d:	4d 85 db             	test   %r11,%r11
    aa60:	0f 88 1a 01 00 00    	js     ab80 <__divmodti4+0x160>
    aa66:	4c 89 d9             	mov    %r11,%rcx
    aa69:	49 89 f3             	mov    %rsi,%r11
    aa6c:	75 62                	jne    aad0 <__divmodti4+0xb0>
    aa6e:	4d 89 c4             	mov    %r8,%r12
    aa71:	4d 39 d1             	cmp    %r10,%r9
    aa74:	0f 83 46 01 00 00    	jae    abc0 <__divmodti4+0x1a0>
    aa7a:	4c 89 d8             	mov    %r11,%rax
    aa7d:	4c 89 ca             	mov    %r9,%rdx
    aa80:	49 f7 f2             	div    %r10
    aa83:	49 89 c3             	mov    %rax,%r11
    aa86:	31 c0                	xor    %eax,%eax
    aa88:	48 89 d6             	mov    %rdx,%rsi
    aa8b:	31 ff                	xor    %edi,%edi
    aa8d:	4c 89 d9             	mov    %r11,%rcx
    aa90:	48 89 c2             	mov    %rax,%rdx
    aa93:	48 89 c8             	mov    %rcx,%rax
    aa96:	4d 85 e4             	test   %r12,%r12
    aa99:	74 0a                	je     aaa5 <__divmodti4+0x85>
    aa9b:	48 f7 d8             	neg    %rax
    aa9e:	48 83 d2 00          	adc    $0x0,%rdx
    aaa2:	48 f7 da             	neg    %rdx
    aaa5:	4d 85 c0             	test   %r8,%r8
    aaa8:	74 0a                	je     aab4 <__divmodti4+0x94>
    aaaa:	48 f7 de             	neg    %rsi
    aaad:	48 83 d7 00          	adc    $0x0,%rdi
    aab1:	48 f7 df             	neg    %rdi
    aab4:	48 89 33             	mov    %rsi,(%rbx)
    aab7:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    aabb:	5b                   	pop    %rbx
    aabc:	41 5c                	pop    %r12
    aabe:	41 5d                	pop    %r13
    aac0:	41 5e                	pop    %r14
    aac2:	41 5f                	pop    %r15
    aac4:	5d                   	pop    %rbp
    aac5:	c3                   	ret
    aac6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    aacd:	00 00 00 
    aad0:	4d 89 c4             	mov    %r8,%r12
    aad3:	49 39 c1             	cmp    %rax,%r9
    aad6:	0f 82 ce 00 00 00    	jb     abaa <__divmodti4+0x18a>
    aadc:	31 ff                	xor    %edi,%edi
    aade:	f3 48 0f bd f8       	lzcnt  %rax,%rdi
    aae3:	48 63 c7             	movslq %edi,%rax
    aae6:	be 40 00 00 00       	mov    $0x40,%esi
    aaeb:	c4 e2 c1 f7 c9       	shlx   %rdi,%rcx,%rcx
    aaf0:	c4 42 c1 f7 fb       	shlx   %rdi,%r11,%r15
    aaf5:	48 29 c6             	sub    %rax,%rsi
    aaf8:	c4 c2 cb f7 c2       	shrx   %rsi,%r10,%rax
    aafd:	48 09 c8             	or     %rcx,%rax
    ab00:	c4 c2 cb f7 d1       	shrx   %rsi,%r9,%rdx
    ab05:	c4 42 c1 f7 d2       	shlx   %rdi,%r10,%r10
    ab0a:	49 89 c6             	mov    %rax,%r14
    ab0d:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
    ab11:	c4 c2 c1 f7 c1       	shlx   %rdi,%r9,%rax
    ab16:	c4 42 cb f7 cb       	shrx   %rsi,%r11,%r9
    ab1b:	49 09 c1             	or     %rax,%r9
    ab1e:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
    ab22:	4c 89 c8             	mov    %r9,%rax
    ab25:	49 f7 f6             	div    %r14
    ab28:	48 89 d1             	mov    %rdx,%rcx
    ab2b:	49 89 c3             	mov    %rax,%r11
    ab2e:	49 89 c1             	mov    %rax,%r9
    ab31:	49 f7 e2             	mul    %r10
    ab34:	49 89 c6             	mov    %rax,%r14
    ab37:	49 89 d2             	mov    %rdx,%r10
    ab3a:	48 39 d1             	cmp    %rdx,%rcx
    ab3d:	72 07                	jb     ab46 <__divmodti4+0x126>
    ab3f:	75 17                	jne    ab58 <__divmodti4+0x138>
    ab41:	49 39 c7             	cmp    %rax,%r15
    ab44:	73 12                	jae    ab58 <__divmodti4+0x138>
    ab46:	48 2b 45 c0          	sub    -0x40(%rbp),%rax
    ab4a:	48 1b 55 c8          	sbb    -0x38(%rbp),%rdx
    ab4e:	4d 8d 4b ff          	lea    -0x1(%r11),%r9
    ab52:	49 89 d2             	mov    %rdx,%r10
    ab55:	49 89 c6             	mov    %rax,%r14
    ab58:	4c 89 f8             	mov    %r15,%rax
    ab5b:	4c 29 f0             	sub    %r14,%rax
    ab5e:	4c 19 d1             	sbb    %r10,%rcx
    ab61:	c4 e2 c3 f7 c0       	shrx   %rdi,%rax,%rax
    ab66:	c4 e2 c9 f7 f1       	shlx   %rsi,%rcx,%rsi
    ab6b:	c4 e2 c3 f7 c9       	shrx   %rdi,%rcx,%rcx
    ab70:	48 09 c6             	or     %rax,%rsi
    ab73:	48 89 cf             	mov    %rcx,%rdi
    ab76:	31 c0                	xor    %eax,%eax
    ab78:	4c 89 c9             	mov    %r9,%rcx
    ab7b:	e9 10 ff ff ff       	jmp    aa90 <__divmodti4+0x70>
    ab80:	4c 89 d0             	mov    %r10,%rax
    ab83:	4c 89 da             	mov    %r11,%rdx
    ab86:	4d 89 c4             	mov    %r8,%r12
    ab89:	49 89 f3             	mov    %rsi,%r11
    ab8c:	48 f7 d8             	neg    %rax
    ab8f:	49 f7 d4             	not    %r12
    ab92:	48 83 d2 00          	adc    $0x0,%rdx
    ab96:	49 89 c2             	mov    %rax,%r10
    ab99:	48 f7 da             	neg    %rdx
    ab9c:	48 89 d1             	mov    %rdx,%rcx
    ab9f:	0f 84 cc fe ff ff    	je     aa71 <__divmodti4+0x51>
    aba5:	49 39 d1             	cmp    %rdx,%r9
    aba8:	73 46                	jae    abf0 <__divmodti4+0x1d0>
    abaa:	4c 89 cf             	mov    %r9,%rdi
    abad:	31 c0                	xor    %eax,%eax
    abaf:	31 c9                	xor    %ecx,%ecx
    abb1:	e9 da fe ff ff       	jmp    aa90 <__divmodti4+0x70>
    abb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    abbd:	00 00 00 
    abc0:	4d 85 d2             	test   %r10,%r10
    abc3:	75 0d                	jne    abd2 <__divmodti4+0x1b2>
    abc5:	b8 01 00 00 00       	mov    $0x1,%eax
    abca:	31 d2                	xor    %edx,%edx
    abcc:	49 f7 f2             	div    %r10
    abcf:	49 89 c2             	mov    %rax,%r10
    abd2:	4c 89 c8             	mov    %r9,%rax
    abd5:	31 d2                	xor    %edx,%edx
    abd7:	49 f7 f2             	div    %r10
    abda:	49 89 c1             	mov    %rax,%r9
    abdd:	4c 89 d8             	mov    %r11,%rax
    abe0:	49 f7 f2             	div    %r10
    abe3:	49 89 c3             	mov    %rax,%r11
    abe6:	4c 89 c8             	mov    %r9,%rax
    abe9:	e9 9a fe ff ff       	jmp    aa88 <__divmodti4+0x68>
    abee:	66 90                	xchg   %ax,%ax
    abf0:	45 31 f6             	xor    %r14d,%r14d
    abf3:	f3 4c 0f bd f2       	lzcnt  %rdx,%r14
    abf8:	44 89 f7             	mov    %r14d,%edi
    abfb:	45 85 f6             	test   %r14d,%r14d
    abfe:	0f 85 df fe ff ff    	jne    aae3 <__divmodti4+0xc3>
    ac04:	4c 39 ca             	cmp    %r9,%rdx
    ac07:	72 17                	jb     ac20 <__divmodti4+0x200>
    ac09:	31 c9                	xor    %ecx,%ecx
    ac0b:	48 39 c6             	cmp    %rax,%rsi
    ac0e:	73 10                	jae    ac20 <__divmodti4+0x200>
    ac10:	4c 89 cf             	mov    %r9,%rdi
    ac13:	31 c0                	xor    %eax,%eax
    ac15:	e9 76 fe ff ff       	jmp    aa90 <__divmodti4+0x70>
    ac1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    ac20:	4c 89 de             	mov    %r11,%rsi
    ac23:	b9 01 00 00 00       	mov    $0x1,%ecx
    ac28:	48 29 c6             	sub    %rax,%rsi
    ac2b:	49 19 d1             	sbb    %rdx,%r9
    ac2e:	eb e0                	jmp    ac10 <__divmodti4+0x1f0>

000000000000ac30 <atexit>:
    ac30:	f3 0f 1e fa          	endbr64
    ac34:	48 8b 15 cd 43 00 00 	mov    0x43cd(%rip),%rdx        # f008 <__dso_handle>
    ac3b:	31 f6                	xor    %esi,%esi
    ac3d:	e9 fe 89 ff ff       	jmp    3640 <__cxa_atexit@plt>

Disassembly of section .fini:

000000000000ac44 <_fini>:
    ac44:	f3 0f 1e fa          	endbr64
    ac48:	48 83 ec 08          	sub    $0x8,%rsp
    ac4c:	48 83 c4 08          	add    $0x8,%rsp
    ac50:	c3                   	ret
